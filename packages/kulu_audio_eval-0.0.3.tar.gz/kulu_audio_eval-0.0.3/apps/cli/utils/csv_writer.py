"""CSV export for transcript segments."""

from __future__ import annotations

import csv
import json
import logging
from pathlib import Path

log = logging.getLogger(__name__)


def _format_timestamp(seconds: float) -> str:
    """Format seconds as MM:SS (zero-padded)."""
    total_seconds = int(seconds)
    minutes = total_seconds // 60
    secs = total_seconds % 60
    return f"{minutes:02d}:{secs:02d}"


def _merge_overlapping_cutouts(cutouts: list[dict]) -> list[dict]:
    """Merge overlapping cutout intervals; return non-overlapping list.

    Each input dict must have start_ms and end_ms. Intervals that overlap
    (including adjacent) are merged into one. Returns list of dicts with
    start_ms and end_ms.
    """
    if not cutouts:
        return []
    intervals: list[tuple[float, float]] = []
    for c in cutouts:
        try:
            s = float(c["start_ms"])
            e = float(c["end_ms"])
        except (TypeError, KeyError, ValueError):
            continue
        if e < s:
            continue
        intervals.append((s, e))
    if not intervals:
        return []
    intervals.sort(key=lambda x: x[0])
    merged: list[tuple[float, float]] = [intervals[0]]
    for s, e in intervals[1:]:
        last_s, last_e = merged[-1]
        if s <= last_e:
            merged[-1] = (last_s, max(last_e, e))
        else:
            merged.append((s, e))
    return [{"start_ms": s, "end_ms": e} for s, e in merged]


def _normalized_cutout_count(cutouts: list[dict]) -> int:
    """Return count of cutouts after merging overlapping intervals."""
    return len(_merge_overlapping_cutouts(cutouts))


def _validate_cutouts_for_segment(
    cutouts: list[dict], start_s: float, end_s: float, segment_id: int
) -> list[dict]:
    """Keep only cutouts whose interval falls within [start_s, end_s].

    Each cutout must have start_ms and end_ms (absolute milliseconds).
    Invalid entries are dropped and logged.
    """
    if not cutouts:
        return []
    start_ms = start_s * 1000.0
    end_ms = end_s * 1000.0
    valid: list[dict] = []
    for i, c in enumerate(cutouts):
        try:
            c_start = float(c["start_ms"])
            c_end = float(c["end_ms"])
        except (TypeError, KeyError):
            log.warning(
                "Segment %s: drop cutout %s (missing or invalid start_ms/end_ms)",
                segment_id,
                i + 1,
            )
            continue
        if c_start < start_ms - 1.0:
            log.warning(
                "Segment %s: drop cutout %s (start %.1fms before segment start %.1fms)",
                segment_id,
                i + 1,
                c_start,
                start_ms,
            )
            continue
        if c_end > end_ms + 1.0:
            log.warning(
                "Segment %s: drop cutout %s (end %.1fms after segment end %.1fms)",
                segment_id,
                i + 1,
                c_end,
                end_ms,
            )
            continue
        valid.append(c)
    return valid


def _format_failed_response_display(failures: list[dict]) -> str:
    """Format failed_response list for display as 'Type: xx. Reason: xx.' per item."""
    if not failures:
        return ""
    parts: list[str] = []
    for f in failures:
        t = (f.get("type") or "").strip()
        r = (f.get("reason") or "").strip()
        if not r.endswith("."):
            r = r + "." if r else r
        parts.append(f"Type: {t}. Reason: {r}")
    return " ".join(parts)


def _transcript_header_display_name(name: str) -> str:
    """Convert transcript column key to display header (strip y_pred_ prefix, titleize)."""
    s = name.replace("y_pred_", "", 1) if name.startswith("y_pred_") else name
    s = s.replace("_", " ").title()
    s = s.replace(" To Respond", " Response")
    if s == "Start Ms":
        s = "Agent Start Ms"
    if s == "Failed Response":
        s = "Failure Inference"
    if name == "agent_transcription":
        return "Agent Transcription"
    return s


def write_transcript_csv(
    segments: list[dict],
    csv_path: str,
    include_text_columns: bool = True,
    use_display_headers: bool = False,
    omit_columns: list[str] | None = None,
) -> None:
    """Write transcript.csv with one row per segment.

    Columns: timestamp, audio_chunk, segment_id, start_ms, end_ms, end_speech_ms,
    y_pred_speaker, y_pred_turn, e2e_turn_gap_latency_ms, y_pred_cutout,
    y_pred_cutouts_normalized_count (non-overlapping cutout count),
    y_pred_failed_response (JSON array of failure dicts),
    [text[, text_eng] if include_text_columns], y_pred_cutouts.

    Args:
        segments: List of dicts with keys: start (s), end (s), text,
                  audio_chunk, segment_id, speaker (str), turn (int).
                  Optional: text_eng, cutouts or y_pred_cutouts, e2e_turn_gap_latency_ms,
                  end_speech_s (end of speech in seconds, from energy detection; written as end_speech_ms).
        csv_path: Output CSV file path.
        include_text_columns: If False, omit text and text_eng columns (e.g. for agent_transcript.csv).
        use_display_headers: If True, write header row with titleized names and y_pred_ prefix removed
                             (for agent_transcript.csv only).
        omit_columns: If set, exclude these column keys from the output (e.g. for agent_transcript.csv).
    """
    fieldnames = [
        "timestamp",
        "audio_chunk",
        "segment_id",
        "start_ms",
        "end_ms",
        "end_speech_ms",
        "y_pred_after_cutout_start_ms",
        "y_pred_speaker",
        "y_pred_turn",
        "y_pred_e2e_turn_gap_latency_ms",
        "y_pred_e2e_barge_in_latency_ms",
        "y_pred_total_e2e_latency_ms",
        "y_pred_cutout",
        "y_pred_cutouts_normalized_count",
        "y_pred_failed_response",
    ]
    if include_text_columns:
        fieldnames.append("text")
        if segments and "text_eng" in segments[0]:
            fieldnames.append("text_eng")
    fieldnames.append("y_pred_cutouts")

    if omit_columns:
        # Explicit column order for agent_transcript: timestamp, turn, agent transcription, user previous end speech, agent start, then rest
        fieldnames = [
            "timestamp",
            "y_pred_turn",
            "agent_transcription",
            "user_previous_end_speech_ms",
            "start_ms",
            "y_pred_e2e_turn_gap_latency_ms",
            "y_pred_e2e_barge_in_latency_ms",
            "y_pred_total_e2e_latency_ms",
            "y_pred_cutouts_normalized_count",
            "y_pred_failed_response",
            "y_pred_cutouts",
        ]
        fieldnames = [f for f in fieldnames if f not in omit_columns]

    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        if use_display_headers:
            writer = csv.writer(f)
            writer.writerow([_transcript_header_display_name(f) for f in fieldnames])
        else:
            dict_writer = csv.DictWriter(f, fieldnames=fieldnames)
            dict_writer.writeheader()
        for seg in segments:
            start_s = seg["start"]
            end_s = seg["end"]
            segment_id = seg.get("segment_id", 0)
            raw_pred: list[dict] = seg.get("y_pred_cutouts", seg.get("cutouts", []))
            raw_actual: list[dict] = seg.get("y_actual_cutouts", [])
            pred_cutouts = _validate_cutouts_for_segment(
                raw_pred, start_s, end_s, segment_id
            )
            actual_cutouts = _validate_cutouts_for_segment(
                raw_actual, start_s, end_s, segment_id
            )
            seg["y_pred_cutouts"] = pred_cutouts
            seg["y_actual_cutouts"] = actual_cutouts
            seg["cutouts"] = pred_cutouts
            failures: list[dict] = seg.get("failed_response", [])

            e2e_turn_gap_latency_ms: str | int = seg.get("e2e_turn_gap_latency_ms", "")
            pred_cutout_flag = "1" if pred_cutouts else ""

            end_speech_ms_val: str | int = ""
            if "end_speech_s" in seg and seg["end_speech_s"] is not None:
                try:
                    end_speech_ms_val = int(float(seg["end_speech_s"]) * 1000)
                except (TypeError, ValueError):
                    pass
            user_previous_end_speech_ms_val: str | int = ""
            if (
                "user_previous_end_speech_s" in seg
                and seg["user_previous_end_speech_s"] is not None
            ):
                try:
                    user_previous_end_speech_ms_val = int(
                        float(seg["user_previous_end_speech_s"]) * 1000
                    )
                except (TypeError, ValueError):
                    pass

            # E2E turn gap = Agent Start Ms - User Previous End Speech Ms (None when overlapping/barge-in)
            if isinstance(user_previous_end_speech_ms_val, int):
                agent_start_ms = int(seg["start"] * 1000)
                raw_gap = agent_start_ms - user_previous_end_speech_ms_val
                e2e_turn_gap_latency_ms = raw_gap if raw_gap >= 0 else ""

            # After-cutout start: when the agent resumes after the last detected cutout
            # (barge-in or mid-speech dropout). Uses the cutout's own end_ms so the value
            # reflects the actual audio gap rather than the previous turn's end time.
            after_cutout_start_ms_val: str | int = ""
            if seg.get("speaker") == "agent" and pred_cutouts:
                last_end = max(float(c.get("end_ms", 0)) for c in pred_cutouts)
                after_cutout_start_ms_val = int(round(last_end))

            # Barge-in and total latencies pre-computed by pipeline stage 8 and stored on segment
            e2e_barge_in_latency_ms: str | int = seg.get("e2e_barge_in_latency_ms", "")
            total_e2e_latency_ms: str | int = seg.get("total_e2e_latency_ms", "")

            # Relabel cutouts as barge-in type when barge-in latency is confirmed
            if isinstance(e2e_barge_in_latency_ms, int) and e2e_barge_in_latency_ms > 0:
                pred_cutouts = [
                    {**c, "type": "cutout_e2e_barge_in_latency"} for c in pred_cutouts
                ]

            normalized_count = _normalized_cutout_count(pred_cutouts)
            failed_response_val: str = (
                _format_failed_response_display(failures)
                if use_display_headers
                else (json.dumps(failures) if failures else "")
            )

            row: dict[str, str | int] = {
                "timestamp": _format_timestamp(seg["start"]),
                "audio_chunk": seg["audio_chunk"],
                "segment_id": seg["segment_id"],
                "start_ms": int(seg["start"] * 1000),
                "end_ms": int(seg["end"] * 1000),
                "end_speech_ms": end_speech_ms_val,
                "y_pred_after_cutout_start_ms": after_cutout_start_ms_val,
                "y_pred_speaker": seg.get("speaker", ""),
                "y_pred_turn": seg.get("turn", ""),
                "y_pred_e2e_turn_gap_latency_ms": e2e_turn_gap_latency_ms,
                "y_pred_e2e_barge_in_latency_ms": e2e_barge_in_latency_ms,
                "y_pred_total_e2e_latency_ms": total_e2e_latency_ms,
                "y_pred_cutout": pred_cutout_flag,
                "y_pred_cutouts_normalized_count": normalized_count,
                "y_pred_failed_response": failed_response_val,
                "y_pred_cutouts": json.dumps(pred_cutouts) if pred_cutouts else "",
            }
            if "user_previous_end_speech_ms" in fieldnames:
                row["user_previous_end_speech_ms"] = user_previous_end_speech_ms_val
            if "agent_transcription" in fieldnames:
                row["agent_transcription"] = seg.get("text_eng") or seg.get("text", "")
            if include_text_columns:
                row["text"] = seg["text"]
                if "text_eng" in fieldnames:
                    row["text_eng"] = seg.get("text_eng", "")
            if use_display_headers:
                writer.writerow([row.get(f, "") for f in fieldnames])
            else:
                dict_writer.writerow(row)


def write_speaker_timeline_csv(
    segments: list[dict],
    csv_path: str,
    turn_latencies: list[dict] | None = None,
) -> None:
    """Write latency_plot.csv with plot data (timeline bars + latency gaps).

    Each row represents a segment on the speaker timeline plot. Columns
    capture the visual data: position, duration, speaker colour lane,
    anomaly markers, and latency gap to the next agent response.

    Args:
        segments: Annotated segments with keys: segment_id, start (s),
                  end (s), speaker, turn, audio_chunk, cutouts,
                  failed_response, e2e_turn_gap_latency_ms.
        csv_path: Output CSV file path.
        turn_latencies: Per-turn latency records (turn_number, user_end,
                        agent_start, e2e_turn_gap_latency_ms).  Used to populate the
                        latency gap columns on the last user segment of
                        each turn.
    """
    latency_by_turn: dict[int, dict] = {}
    if turn_latencies:
        for tl in turn_latencies:
            latency_by_turn[tl["turn_number"]] = tl

    fieldnames = [
        "segment_id",
        "audio_chunk",
        "start_s",
        "end_s",
        "duration_s",
        "speaker",
        "turn",
        "cutout",
        "failed_response",
        "e2e_turn_gap_latency_ms",
        "latency_gap_start_s",
        "latency_gap_end_s",
    ]

    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for seg in segments:
            start_s = seg["start"]
            end_s = seg["end"]
            cutouts: list[dict] = seg.get("cutouts", [])
            failures: list[dict] = seg.get("failed_response", [])

            # Latency gap: applies to the agent segment that responded
            turn_num = seg.get("turn")
            lat = latency_by_turn.get(turn_num, {}) if turn_num else {}
            is_agent_response = seg.get("speaker") == "agent" and lat
            latency_ms = lat.get("e2e_turn_gap_latency_ms", "") if is_agent_response else ""
            gap_start = (
                round(lat["user_end"], 3)
                if is_agent_response and "user_end" in lat
                else ""
            )
            gap_end = (
                round(lat["agent_start"], 3)
                if is_agent_response and "agent_start" in lat
                else ""
            )

            row: dict[str, str | int | float] = {
                "segment_id": seg["segment_id"],
                "audio_chunk": seg.get("audio_chunk", ""),
                "start_s": round(start_s, 3),
                "end_s": round(end_s, 3),
                "duration_s": round(end_s - start_s, 3),
                "speaker": seg.get("speaker", ""),
                "turn": seg.get("turn", ""),
                "cutout": "1" if cutouts else "",
                "failed_response": "1" if failures else "",
                "e2e_turn_gap_latency_ms": (
                    int(round(latency_ms)) if isinstance(latency_ms, float) else ""
                ),
                "latency_gap_start_s": gap_start,
                "latency_gap_end_s": gap_end,
            }
            writer.writerow(row)


def _format_ms_as_m_ss(ms: float | int) -> str:
    """Format milliseconds as M:SS (minute:second)."""
    ms_int = int(round(float(ms)))
    total_sec = ms_int / 1000.0
    m = int(total_sec // 60)
    s = int(total_sec % 60)
    return f"{m}:{s:02d}"


def _format_ms_as_time(ms: float | int) -> str:
    """Format milliseconds as minute:second and ms (e.g. 0 min 01 sec (1214 ms))."""
    ms_int = int(round(float(ms)))
    m_ss = _format_ms_as_m_ss(ms_int)
    m, s = m_ss.split(":")
    return f"{int(m)} min {s} sec ({ms_int} ms)"


def write_evaluation_summary_csv(
    output_dir: str,
    segments: list[dict],
    failed_responses: list[dict],
    turn_latencies: list[dict],
    latency_stats: dict[str, float | int] | None,
) -> None:
    """Write evaluation_summary.csv (vertical layout: metric, value).

    Conventions:
    - Summary time values: "N min SS sec (xxx ms)" (minute:second and ms). Empty if none.
    - Cutout timestamps: M:SS-M:SS (start-end ms).
    """
    agent_cutouts: list[dict] = []
    for seg in segments:
        if (seg.get("speaker") or "") == "agent":
            raw = (
                seg.get("cutouts")
                or seg.get("y_pred_cutouts")
                or seg.get("y_actual_cutouts")
                or []
            )
            agent_cutouts.extend(raw if isinstance(raw, list) else [])

    def cutout_duration_ms(c: dict) -> float:
        try:
            return float(c.get("end_ms", 0)) - float(c.get("start_ms", 0))
        except (TypeError, ValueError):
            return 0.0

    def cutout_timestamps_str(cutouts_list: list[dict]) -> str:
        if not cutouts_list:
            return ""
        parts: list[str] = []
        for c in cutouts_list:
            try:
                s_ms = float(c.get("start_ms", 0))
                e_ms = float(c.get("end_ms", 0))
                s_int = int(round(s_ms))
                e_int = int(round(e_ms))
                start_time = _format_ms_as_m_ss(s_int)
                end_time = _format_ms_as_m_ss(e_int)
                parts.append(f"{start_time}-{end_time} ({s_int}-{e_int} ms)")
            except (TypeError, ValueError, KeyError):
                continue
        return ", ".join(parts)

    # Normalized count = merge overlapping intervals then count
    agent_cutouts_merged = _merge_overlapping_cutouts(agent_cutouts)
    normalized_count = _normalized_cutout_count(agent_cutouts)
    agent_dur_ms = sum(cutout_duration_ms(c) for c in agent_cutouts_merged)

    # For timestamps: prefer cutout_mid when there are dupes (same/overlapping with other types)
    agent_cutouts_mid = [c for c in agent_cutouts if c.get("type") == "cutout_mid"]
    cutouts_for_timestamps = (
        _merge_overlapping_cutouts(agent_cutouts_mid)
        if agent_cutouts_mid
        else agent_cutouts_merged
    )

    agent_avg_dur_ms = (
        agent_dur_ms / len(agent_cutouts_merged) if agent_cutouts_merged else 0.0
    )
    agent_cutouts_val = (
        f"Total count: {normalized_count}, "
        f"Average duration: {_format_ms_as_time(agent_avg_dur_ms)}"
        if agent_cutouts_merged
        else ""
    )

    rows: list[tuple[str, str | int | float]] = [
        ("agent_cutouts", agent_cutouts_val),
        (
            "agent_cutouts_timestamps_ms",
            cutout_timestamps_str(cutouts_for_timestamps),
        ),
        ("failure_inference_count", len(failed_responses)),
    ]

    if latency_stats is not None:
        latency_val = (
            f"Average: {_format_ms_as_time(latency_stats.get('mean_ms', 0))}, "
            f"Min: {_format_ms_as_time(latency_stats.get('min_ms', 0))}, "
            f"Max: {_format_ms_as_time(latency_stats.get('max_ms', 0))}"
        )
        rows.append(("e2e_turn_gap_latency_ms", latency_val))
    else:
        rows.append(("e2e_turn_gap_latency_ms", ""))

    out = Path(output_dir)

    def metric_display_label(s: str) -> str:
        """Titleize metric key and use friendly names."""
        if s == "failure_inference_count":
            return "Failure Inference Count"
        label = s.replace("_", " ").title()
        label = label.replace(" To Respond", " Response")
        return label

    csv_path = out / "evaluation_summary.csv"
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["metric", "value"])
        for metric, value in rows:
            writer.writerow([metric_display_label(metric), value])
    log.debug("Wrote %s", csv_path)
