"""Speaker timeline visualization for annotated turn segments."""

from __future__ import annotations

import logging
import os
from pathlib import Path

import numpy as np

os.environ.setdefault("MPLBACKEND", "Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import seaborn as sns

log = logging.getLogger(__name__)

# Seaborn style and palette (agent from palette, user=grey, latency=orange)
sns.set_theme(style="whitegrid", palette="colorblind")
_PALETTE = sns.color_palette(n_colors=2)
_AGENT_COLOR = _PALETTE[0]
_USER_COLOR = "#6B7280"
_WAVE_SILENCE_COLOR = "#B0B0B0"
_WAVE_SILENCE_ALPHA = 0.5
_WAVE_SEGMENT_ALPHA = 0.95
_WAVE_LINEWIDTH = 1.0  # Envelope outline so waveform is visible


# Flag colors
_LATENCY_COLOR = "#EA580C"


def plot_speaker_timeline_with_flags(
    segments: list[dict],
    turn_latencies: list[dict],
    output_path: str,
    audio_duration_s: float | None = None,
    audio_data: np.ndarray | None = None,
    sample_rate: int | None = None,
) -> None:
    """Speaker timeline with latency gaps.

    Single-panel waveform (agent/user colored) with orange shaded
    latency gap regions between user end and agent start, with latency value
    labels.

    Args:
        segments: Annotated segments.
        turn_latencies: Per-turn latency records from latency_metrics.
        output_path: Path to save the PNG file.
        audio_duration_s: Total audio duration in seconds.
        audio_data: Mono audio array (float32).
        sample_rate: Sample rate in Hz.
    """
    if not segments:
        log.warning("No segments to plot (with_flags)")
        return

    max_time = audio_duration_s or max(s["end"] for s in segments)
    has_wave = audio_data is not None and sample_rate is not None

    fig, ax = plt.subplots(1, 1, figsize=(28, 3))

    # --- Waveform: one panel, no grey; black=agent, orange=user ---
    if has_wave:
        assert audio_data is not None and sample_rate is not None
        total_samples = len(audio_data)
        target_points = min(total_samples, int(max_time * 2000))
        step = max(1, total_samples // target_points)
        wave = audio_data[::step]
        time_axis = np.linspace(0, max_time, len(wave))

        peak = np.max(np.abs(wave))
        if peak > 0:
            wave = wave / peak

        for seg in segments:
            speaker = seg["speaker"]
            color = _AGENT_COLOR if speaker == "agent" else _USER_COLOR

            start_idx = int(seg["start"] / max_time * len(wave))
            end_idx = int(seg["end"] / max_time * len(wave))
            start_idx = max(0, min(start_idx, len(wave) - 1))
            end_idx = max(start_idx + 1, min(end_idx, len(wave)))

            seg_time = time_axis[start_idx:end_idx]
            seg_wave = wave[start_idx:end_idx]
            ax.fill_between(
                seg_time,
                seg_wave,
                -seg_wave,
                color=color,
                alpha=_WAVE_SEGMENT_ALPHA,
                linewidth=0,
            )
            ax.plot(
                seg_time,
                seg_wave,
                color=color,
                linewidth=_WAVE_LINEWIDTH,
                alpha=1.0,
                solid_capstyle="round",
            )
            ax.plot(
                seg_time,
                -seg_wave,
                color=color,
                linewidth=_WAVE_LINEWIDTH,
                alpha=1.0,
                solid_capstyle="round",
            )

    # --- Speaker bars (all on same panel) ---
    bar_height = 0.15
    bar_y = 0.85

    for seg in segments:
        speaker = seg["speaker"]
        start = seg["start"]
        duration = seg["end"] - seg["start"]
        color = _AGENT_COLOR if speaker == "agent" else _USER_COLOR

        ax.barh(
            bar_y,
            duration,
            left=start,
            height=bar_height,
            color=color,
            edgecolor="white",
            linewidth=0.5,
            alpha=0.9,
        )

        if duration > 2.0:
            ax.text(
                start + duration / 2,
                bar_y,
                f"T{seg.get('turn', '')}",
                ha="center",
                va="center",
                fontsize=7,
                color="white",
                fontweight="bold",
            )

    # --- Latency gaps ---
    for tlat in turn_latencies:
        user_end = tlat["user_end"]
        agent_start = tlat["agent_start"]
        latency_ms = tlat.get("e2e_turn_gap_latency_ms")
        if not latency_ms or latency_ms <= 0:
            continue
        ax.axvspan(
            user_end,
            agent_start,
            color=_LATENCY_COLOR,
            alpha=0.2,
            linewidth=0,
        )
        mid = (user_end + agent_start) / 2
        ax.annotate(
            f"{int(latency_ms)}ms",
            xy=(mid, -0.75),
            fontsize=6,
            color=_LATENCY_COLOR,
            ha="center",
            va="center",
            fontweight="bold",
            bbox=dict(
                boxstyle="round,pad=0.15",
                facecolor="white",
                edgecolor=_LATENCY_COLOR,
                alpha=0.8,
                linewidth=0.5,
            ),
        )

    # --- Axes config ---
    ax.set_xlim(0, max_time)
    if has_wave:
        ax.set_ylim(-1.1, 1.1)
    else:
        ax.set_ylim(-0.5, 1.5)
    ax.set_ylabel("Amplitude")
    ax.set_yticks([-1, 0, 1])
    ax.grid(axis="x", alpha=0.3)

    if max_time > 120:

        def _fmt_mmss(x: float, _pos: object) -> str:
            m, s = divmod(int(x), 60)
            return f"{m}:{s:02d}"

        ax.xaxis.set_major_formatter(plt.FuncFormatter(_fmt_mmss))

    ax.set_xlabel("Time (seconds)")

    # Legend
    legend_handles: list[mpatches.Patch] = [
        mpatches.Patch(color=_AGENT_COLOR, label="Agent"),
        mpatches.Patch(color=_USER_COLOR, label="User"),
        mpatches.Patch(color=_LATENCY_COLOR, alpha=0.3, label="Latency gap"),
    ]
    ax.legend(handles=legend_handles, loc="upper right", fontsize=7, ncol=2)

    ax.set_title("Latency Plot")
    fig.tight_layout()

    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, dpi=150, bbox_inches="tight")
    plt.close(fig)
    log.debug("Saved speaker timeline with flags to %s", output_path)
