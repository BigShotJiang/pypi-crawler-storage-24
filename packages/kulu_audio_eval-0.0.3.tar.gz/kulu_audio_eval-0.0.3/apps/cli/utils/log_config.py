"""Logging configuration: Rich handler, time format, and third-party levels.

Configure once at app entry (e.g. in the evaluate command). All other code
uses standard logging (logging.getLogger(__name__)) and is unaffected.
"""

from __future__ import annotations

import logging
import os
import sys
from datetime import datetime
from typing import Callable

from rich.console import Console
from rich.logging import RichHandler
from rich.text import Text

__all__ = ["configure_logging"]


def _make_time_formatter() -> Callable[[datetime], Text]:
    """First log shows full datetime; rest show time only."""
    first = [True]

    def format_time(d: datetime) -> Text:
        if first[0]:
            first[0] = False
            return Text(d.strftime("%Y-%m-%d %H:%M:%S"))
        return Text(d.strftime("%H:%M:%S"))

    return format_time


def _suppress_noisy_loggers(*, verbose: bool) -> None:
    """At INFO: raise level for HTTP and transcription libs so they only show at DEBUG."""
    if verbose:
        return
    for name in (
        "httpx",
        "httpcore",
        "urllib3",
    ):
        logging.getLogger(name).setLevel(logging.WARNING)


def configure_logging(*, verbose: bool = False) -> None:
    """Configure logging for the CLI: Rich on stderr, datetime on first line, time only after.

    Call once at application entry (e.g. at the start of the evaluate command).
    When verbose is False (default): root level INFO, third-party libs (HTTP) set to WARNING.
    When verbose is True: root level DEBUG, third-party libs unchanged so those messages show.
    """
    log_level = logging.DEBUG if verbose else logging.INFO
    root = logging.getLogger()
    root.handlers.clear()
    root.setLevel(log_level)
    handler = RichHandler(
        console=Console(file=sys.stderr),
        show_time=True,
        show_level=True,
        show_path=False,
        rich_tracebacks=True,
        log_time_format=_make_time_formatter(),
    )
    handler.setLevel(log_level)
    root.addHandler(handler)
    _suppress_noisy_loggers(verbose=verbose)
