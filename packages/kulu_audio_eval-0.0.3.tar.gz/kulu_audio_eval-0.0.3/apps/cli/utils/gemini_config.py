"""Shared Gemini API configuration for failure inference and translation.

Both features process items in batches (e.g. 10 turns/segments per batch)
and run batches in parallel. Use these defaults so behavior is consistent
and config is DRY.
"""

from __future__ import annotations

from google import genai

# Default model for both failure inference and translation
GEMINI_MODEL = "gemini-2.0-flash"

# Process this many turns/segments per Gemini call (same for both features)
GEMINI_BATCH_SIZE = 10

# Max parallel batch requests
GEMINI_MAX_WORKERS = 4


def create_gemini_client(config: dict) -> genai.Client | None:
    """Create a Gemini client from config. Returns None if GEMINI_API_KEY is missing."""
    api_key = config.get("GEMINI_API_KEY")
    if not api_key:
        return None
    return genai.Client(api_key=str(api_key))
