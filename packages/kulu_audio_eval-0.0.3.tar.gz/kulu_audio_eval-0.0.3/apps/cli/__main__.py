"""Entry point for `python -m cli`."""

from __future__ import annotations

import os
import sys

# Use non-GUI matplotlib backend so worker threads never touch tkinter (avoids
# "RuntimeError: main thread is not in main loop" when translation runs in threads).
os.environ.setdefault("MPLBACKEND", "Agg")


def main() -> None:
    from cli.cli import cli

    cli()


if __name__ == "__main__":
    main()
