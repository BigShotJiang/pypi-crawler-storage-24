from typing import Any, Callable
from warnings import warn

from sqlmodel import SQLModel

from sqlmodel_dump.deserializer import Deserializer
from sqlmodel_dump.serializer import Serializer


class SQLModelDump:
    _ref: dict[str, Any] = {}
    _class: dict[str, type[Any]] = {}

    _max_depth: int
    _self_ref: bool

    _attr_to_key: dict[str | type[Any], list[str]] | None
    _key_factory: Callable[[Any], str] | None
    _ref_alternative: Callable[[str], Any] | None

    def __init__(
        self,
        max_depth: int = 3,
        self_ref: bool = False,
        key_factory: Callable[[Any], str] | None = None,
        attr_to_key: dict[str | type[Any], list[str]] | None = None,
        ref_alternative: Callable[[str], Any] | None = None,
    ) -> None:
        """
        SQLModel dumping manager

        ## What is self_ref mode?

        With self_ref set to `False`, the Relationship reference will be stored in `SQLModelDump._ref` dict.
        This is the default mode and need a garbage collector in order not to raise the memory leak error..

        **Example:**
        Return object:
        ```
        {
            "__type": "model",
            "__class": "Enrollment",
            "id": "f2915205-831c-4941-b116-7c76b27ebd2f",
            "classroom": {
                "__type": "relationship",
                "__class": "Class",
                "__ref": "Class:b607a4a3-4a10-453b-aed4-cd575ebb6c36" # An address to the reference in `_ref` object
            },
            ...
        }
        ```
        `_ref` object
        ```
        {
            "Class:b607a4a3-4a10-453b-aed4-cd575ebb6c36": { # The relationship value
                "__type": "model",
                "__class": "Class",
                "id": "b607a4a3-4a10-453b-aed4-cd575ebb6c36",
                "name": "Test Class",
                "subject": "Test",
                "teacher_id": "3135756c-be25-41a5-a6a8-be2c6f667c99",
                "teacher": {
                    "__type": "relationship",
                    "__class": "Teacher",
                    "__ref": "Teacher:3135756c-be25-41a5-a6a8-be2c6f667c99" # Reference to another object
                }
            },
            ...
        }
        ```

        With self_ref set to `True`, the reference will be stored in the result object itself.
        This can help eliminate the garbage collector but the result object size will be significantly increased

        **Example:**
        ```
        {
            "__type": "model",
            "__class": "Enrollment",
            "id": "ae4efb62-cd94-47bf-a6e7-3f9c93703c00",
            "class_id": "bdd2df1c-5b33-467b-9c0b-a1e69f4324b2",
            "classroom": {
                "__type": "relationship",
                "__class": "Class",
                "__ref": "Class:bdd2df1c-5b33-467b-9c0b-a1e69f4324b2",
                "__val": { # The relationship will be store in itself
                    "__type": "model",
                    "__class": "Class",
                    "id": "bdd2df1c-5b33-467b-9c0b-a1e69f4324b2",
                    "created_at": {
                        "__type": "datetime",
                        "__val": 1772292084.449564
                    },
                    "updated_at": {
                        "__type": "datetime",
                        "__val": 1772292084.449624
                    },
                    "name": "Test Class",
                    "subject": "Test",
                    ...
                }
            },
            ...
        }
        ```

        :param int max_depth: control how deep the serializer and deserializer will go
        :param bool self_ref: Use self_ref mode
        :param dict attr_to_key: A map of class or class name and keys that will be used to create the reference key. For example, if you want class Enrollment use its class_id and student_id for reference key, it should be { Enrollment: ["class_id", "student_id"] }. This is the alternative way to modify the reference key.
        :param Callable key_factory: A custom function to produce the key for reference, should accept only one args is the reference object
        :prarm Callable ref_alternative: A function to call when a reference is missing, could be an async function
        :param AbstractEventLoop running_loop: The current event loop to pass to deserializer to run ref_alternative if it is an async function
        """
        if attr_to_key and key_factory:
            warn("attr_to_key and key_factory is both set, key_factory will be used")
        self._max_depth = max_depth
        self._self_ref = self_ref
        self._attr_to_key = attr_to_key
        self._attr_to_key = attr_to_key
        self._key_factory = key_factory
        self._ref_alternative = ref_alternative

    def dumps(self, obj: SQLModel) -> dict[str, Any]:
        """
        Dump the SQLModel into dict

        :param SQLModel obj: Obj to dump
        :return dict[str, Any]: The dumped object
        """
        serializer = Serializer(
            self_ref=self._self_ref,
            max_depth=self._max_depth,
            attr_to_key=self._attr_to_key,
            key_factory=self._key_factory,
        )
        dumps = serializer.serialize(obj)
        self._ref |= serializer.ref
        self._class |= serializer.base_class
        return dumps

    def loads(self, obj: Any) -> Any:
        """
        Loads the object

        :param Any obj: The object to load
        :return: The loaded object
        """
        deserializer = Deserializer(
            get_class=self._class.get,
            get_ref=self._ref.get,
            self_ref=self._self_ref,
            max_depth=self._max_depth,
            ref_alternative=self._ref_alternative,
        )
        return deserializer.deserialize(obj)
