# Newscatcher Python Library

[![fern shield](https://img.shields.io/badge/%F0%9F%8C%BF-Built%20with%20Fern-brightgreen)](https://buildwithfern.com?utm_source=github&utm_medium=github&utm_campaign=readme&utm_source=https%3A%2F%2Fgithub.com%2FNewscatcher%2Fnewscatcher-catchall-python)
[![pypi](https://img.shields.io/pypi/v/newscatcher-catchall-sdk)](https://pypi.python.org/pypi/newscatcher-catchall-sdk)

The Newscatcher Python library provides convenient access to the Newscatcher APIs from Python.

## Table of Contents

- [Documentation](#documentation)
- [Installation](#installation)
- [Reference](#reference)
- [Usage](#usage)
- [Async Client](#async-client)
- [Exception Handling](#exception-handling)
- [Advanced](#advanced)
  - [Access Raw Response Data](#access-raw-response-data)
  - [Retries](#retries)
  - [Timeouts](#timeouts)
  - [Custom Client](#custom-client)
- [Contributing](#contributing)
- [Support](#support)

## Documentation

API reference documentation is available [here](https://www.newscatcherapi.com/docs/web-search-api/api-reference/jobs/initialize-job).

## Installation

```sh
pip install newscatcher-catchall-sdk
```

## Reference

A full reference for this library is available [here](https://github.com/Newscatcher/newscatcher-catchall-python/blob/HEAD/./reference.md).

## Usage

Instantiate and use the client with the following:

```python
from newscatcher_catchall import CatchAllApi
import datetime

client = CatchAllApi(
    api_key="<value>",
)

client.jobs.create_job(
    query="Series B funding rounds for SaaS startups",
    context="Focus on funding amount and company name",
    limit=10,
    start_date=datetime.datetime.fromisoformat("2026-02-18T00:00:00+00:00"),
    end_date=datetime.datetime.fromisoformat("2026-02-23T00:00:00+00:00"),
    mode="base",
)
```

## Async Client

The SDK also exports an `async` client so that you can make non-blocking calls to our API. Note that if you are constructing an Async httpx client class to pass into this client, use `httpx.AsyncClient()` instead of `httpx.Client()` (e.g. for the `httpx_client` parameter of this client).

```python
import asyncio
import datetime

from newscatcher_catchall import AsyncCatchAllApi

client = AsyncCatchAllApi(
    api_key="<value>",
)


async def main() -> None:
    await client.jobs.create_job(
        query="Series B funding rounds for SaaS startups",
        context="Focus on funding amount and company name",
        limit=10,
        start_date=datetime.datetime.fromisoformat("2026-02-18T00:00:00+00:00"),
        end_date=datetime.datetime.fromisoformat("2026-02-23T00:00:00+00:00"),
        mode="base",
    )


asyncio.run(main())
```

## Exception Handling

When the API returns a non-success status code (4xx or 5xx response), a subclass of the following error
will be thrown.

```python
from newscatcher_catchall.core.api_error import ApiError

try:
    client.jobs.create_job(...)
except ApiError as e:
    print(e.status_code)
    print(e.body)
```

## Advanced

### Access Raw Response Data

The SDK provides access to raw response data, including headers, through the `.with_raw_response` property.
The `.with_raw_response` property returns a "raw" client that can be used to access the `.headers` and `.data` attributes.

```python
from newscatcher_catchall import CatchAllApi

client = CatchAllApi(...)
response = client.jobs.with_raw_response.create_job(...)
print(response.headers)  # access the response headers
print(response.status_code)  # access the response status code
print(response.data)  # access the underlying object
```

### Retries

The SDK is instrumented with automatic retries with exponential backoff. A request will be retried as long
as the request is deemed retryable and the number of retry attempts has not grown larger than the configured
retry limit (default: 2).

A request is deemed retryable when any of the following HTTP status codes is returned:

- [408](https://developer.mozilla.org/en-US/docs/Web/HTTP/Status/408) (Timeout)
- [429](https://developer.mozilla.org/en-US/docs/Web/HTTP/Status/429) (Too Many Requests)
- [5XX](https://developer.mozilla.org/en-US/docs/Web/HTTP/Status/500) (Internal Server Errors)

Use the `max_retries` request option to configure this behavior.

```python
client.jobs.create_job(..., request_options={
    "max_retries": 1
})
```

### Timeouts

The SDK defaults to a 60 second timeout. You can configure this with a timeout option at the client or request level.

```python
from newscatcher_catchall import CatchAllApi

client = CatchAllApi(..., timeout=20.0)

# Override timeout for a specific method
client.jobs.create_job(..., request_options={
    "timeout_in_seconds": 1
})
```

### Custom Client

You can override the `httpx` client to customize it for your use-case. Some common use-cases include support for proxies
and transports.

```python
import httpx
from newscatcher_catchall import CatchAllApi

client = CatchAllApi(
    ...,
    httpx_client=httpx.Client(
        proxy="http://my.test.proxy.example.com",
        transport=httpx.HTTPTransport(local_address="0.0.0.0"),
    ),
)
```

## Contributing

While we value open-source contributions to this SDK, this library is generated programmatically.
Additions made directly to this library would have to be moved over to our generation code,
otherwise they would be overwritten upon the next generated release. Feel free to open a PR as
a proof of concept, but know that we will not be able to merge it as-is. We suggest opening
an issue first to discuss with us!

On the other hand, contributions to the README are always very welcome!
## Support

- Documentation: [newscatcherapi.com/docs/web-search-api](https://www.newscatcherapi.com/docs/web-search-api/get-started/introduction)
- Support: <support@newscatcherapi.com>




