"""Error hierarchy for the alice CLI."""

from __future__ import annotations

import click


class AliceCLIError(click.ClickException):
    """Base error for all alice CLI errors."""

    def __init__(self, message: str) -> None:
        super().__init__(message)


class AuthError(AliceCLIError):
    """STS/SSO authentication failures."""

    def __init__(self, message: str) -> None:
        super().__init__(message)


class SecretError(AliceCLIError):
    """Secrets Manager retrieval or validation failures."""

    def __init__(self, message: str) -> None:
        super().__init__(message)


class DependencyError(AliceCLIError):
    """Missing external dependency (aws cli, jq, python version)."""

    def __init__(self, message: str) -> None:
        super().__init__(message)


class LockerError(AliceCLIError):
    """Cloud Locker storage failures (S3 unreachable, index corruption, etc.)."""

    def __init__(self, message: str) -> None:
        super().__init__(message)
