"""Cloud Locker — per-user S3 storage with local fallback."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

import boto3
from botocore.exceptions import BotoCoreError, ClientError
from filelock import FileLock, Timeout

from alice_cli.console import err_console
from alice_cli.errors import LockerError
from alice_cli.models import CLIConfig, IndexEntry, LockerIndex, SessionRecord, TokenUsage
from alice_cli.session_record import build_index_entry, deserialize_record, serialize_record

_LOCKER_DIR = Path.home() / ".alice" / "locker"
_LOCK_TIMEOUT = 10  # seconds


class CloudLocker:
    """Per-user S3 storage with local fallback."""

    def __init__(self, config: CLIConfig, jhed: str, bucket: str) -> None:
        self._config = config
        self._jhed = jhed
        self._bucket = bucket
        self._namespace = config.namespace
        self._environment = config.environment

        # Build the boto3 S3 client.  The Bedrock API keys are scoped to
        # model invocation and do NOT have S3 access, so prefer the SSO
        # profile for bucket operations.  Only fall back to API keys when
        # no profile is available at all.
        if config.profile:
            session = boto3.Session(
                profile_name=config.profile,
                region_name=config.region,
            )
            self._s3 = session.client("s3")
        elif config.bedrock_secret_key:
            self._s3 = boto3.client(
                "s3",
                region_name=config.region,
                aws_access_key_id=config.bedrock_access_key,
                aws_secret_access_key=config.bedrock_secret_key,
            )
        else:
            session = boto3.Session(region_name=config.region)
            self._s3 = session.client("s3")

    # ── public API ────────────────────────────────────────────────────

    def persist(self, record: SessionRecord, category: str) -> None:
        """Write session object + update index. Falls back to local on S3 failure."""
        body = serialize_record(record).encode("utf-8")
        s3_key = self._s3_key(category, record.id)

        try:
            # 1. Upload the session object
            self._s3.put_object(
                Bucket=self._bucket,
                Key=s3_key,
                Body=body,
                ContentType="application/json",
                ServerSideEncryption="AES256",
            )

            # 2. Download current index, append, re-upload
            index = self._download_index()
            entry = build_index_entry(record)
            index.entries.append(entry)
            self._upload_index(index)

            # 3. Sync any pending local sessions
            self.sync_pending()

        except (ClientError, BotoCoreError) as exc:
            err_console.print(
                f"[yellow]⚠ Cloud Locker unavailable: {exc}. Session saved locally.[/yellow]"
            )
            self._write_local_with_lock(record, category)

    def load_index(self) -> LockerIndex:
        """Download and parse the index manifest. Falls back to local."""
        try:
            return self._download_index()
        except (ClientError, BotoCoreError):
            return self._load_local_index()

    def load_session(self, session_id: str, category: str) -> SessionRecord:
        """Download and deserialize a single session object."""
        s3_key = self._s3_key(category, session_id)
        try:
            resp = self._s3.get_object(Bucket=self._bucket, Key=s3_key)
            body = resp["Body"].read().decode("utf-8")
            return deserialize_record(body)
        except (ClientError, BotoCoreError):
            # Try local fallback
            local = self._local_path(category, session_id)
            if local.exists():
                return deserialize_record(local.read_text(encoding="utf-8"))
            raise LockerError(f"Session {session_id} not found in S3 or local cache.")

    def sync_pending(self) -> int:
        """Upload locally cached sessions to S3. Returns count synced."""
        if not _LOCKER_DIR.exists():
            return 0

        synced = 0
        # Walk category subdirectories (chat, invoke, batch, compare, dialog)
        for category_dir in _LOCKER_DIR.iterdir():
            if not category_dir.is_dir():
                continue
            category = category_dir.name
            for session_file in category_dir.glob("*.json"):
                session_id = session_file.stem
                s3_key = self._s3_key(category, session_id)
                try:
                    body = session_file.read_bytes()
                    self._s3.put_object(
                        Bucket=self._bucket,
                        Key=s3_key,
                        Body=body,
                        ContentType="application/json",
                        ServerSideEncryption="AES256",
                    )
                    # Upload succeeded — also ensure the index entry exists
                    record = deserialize_record(body.decode("utf-8"))
                    entry = build_index_entry(record)
                    self._ensure_index_entry(entry)

                    # Remove the local file after successful sync
                    session_file.unlink()
                    synced += 1
                except (ClientError, BotoCoreError):
                    # S3 still unreachable — leave local file for next attempt
                    pass

        # Clean up empty category directories
        for category_dir in _LOCKER_DIR.iterdir():
            if category_dir.is_dir() and not any(category_dir.iterdir()):
                category_dir.rmdir()

        return synced

    # ── S3 key construction ───────────────────────────────────────────

    def _s3_key(self, category: str, session_id: str) -> str:
        """Build: {namespace}/{environment}/{jhed}/{category}/{session_id}.json"""
        return f"{self._namespace}/{self._environment}/{self._jhed}/{category}/{session_id}.json"

    def _index_key(self) -> str:
        """Build: {namespace}/{environment}/{jhed}/index.json"""
        return f"{self._namespace}/{self._environment}/{self._jhed}/index.json"

    # ── local path construction ───────────────────────────────────────

    def _local_path(self, category: str, session_id: str) -> Path:
        """Build: ~/.alice/locker/{category}/{session_id}.json"""
        return _LOCKER_DIR / category / f"{session_id}.json"

    def _local_index_path(self) -> Path:
        """Return: ~/.alice/locker/index.json"""
        return _LOCKER_DIR / "index.json"

    # ── local fallback with filelock ──────────────────────────────────

    def _write_local_with_lock(self, record: SessionRecord, category: str) -> None:
        """Write session + update local index under filelock."""
        # Write the session file
        local = self._local_path(category, record.id)
        local.parent.mkdir(parents=True, exist_ok=True)
        local.write_text(serialize_record(record), encoding="utf-8")

        # Update the local index under a file lock
        index_path = self._local_index_path()
        lock_path = index_path.with_suffix(".json.lock")
        index_path.parent.mkdir(parents=True, exist_ok=True)

        try:
            with FileLock(lock_path, timeout=_LOCK_TIMEOUT):
                index = self._load_local_index()
                entry = build_index_entry(record)
                index.entries.append(entry)
                index_path.write_text(
                    json.dumps(_serialize_index(index), ensure_ascii=False),
                    encoding="utf-8",
                )
        except Timeout:
            raise LockerError(
                "Could not acquire lock on local index — "
                "another alice process may be writing. Try again shortly."
            )

    # ── S3 index helpers ──────────────────────────────────────────────

    def _download_index(self) -> LockerIndex:
        """Download and parse the S3 index. Returns empty index if not found."""
        try:
            resp = self._s3.get_object(Bucket=self._bucket, Key=self._index_key())
            raw = resp["Body"].read().decode("utf-8")
            return _parse_index(raw)
        except ClientError as exc:
            if exc.response["Error"]["Code"] == "NoSuchKey":
                return LockerIndex(entries=[])
            raise

    def _upload_index(self, index: LockerIndex) -> None:
        """Serialize and upload the index to S3."""
        body = json.dumps(_serialize_index(index), ensure_ascii=False).encode("utf-8")
        self._s3.put_object(
            Bucket=self._bucket,
            Key=self._index_key(),
            Body=body,
            ContentType="application/json",
            ServerSideEncryption="AES256",
        )

    def backfill_tokens(self, entries: list[IndexEntry]) -> tuple[list[IndexEntry], int]:
        """Backfill token data for index entries missing it.

        Loads the full session record from S3/local for each entry whose
        ``tokens`` field is ``None`` and copies the token data across.
        Returns the updated list and the count of entries that were filled.

        The S3 index is re-uploaded if any entries were patched.
        """
        categories = ("chat", "invoke", "dialog", "summarize", "batch", "compare")
        filled = 0

        for entry in entries:
            if entry.tokens is not None:
                continue
            for cat in categories:
                try:
                    record = self.load_session(entry.id, cat)
                    if record.tokens is not None:
                        entry.tokens = record.tokens
                        filled += 1
                    break
                except Exception:
                    continue

        # Persist the patched index so future calls don't need to backfill again
        if filled:
            try:
                index = self._download_index()
                patched_map = {e.id: e.tokens for e in entries if e.tokens is not None}
                for ie in index.entries:
                    if ie.tokens is None and ie.id in patched_map:
                        ie.tokens = patched_map[ie.id]
                self._upload_index(index)
            except (ClientError, BotoCoreError):
                pass  # Best-effort

        return entries, filled

    def _ensure_index_entry(self, entry: IndexEntry) -> None:
        """Add entry to S3 index if not already present."""
        try:
            index = self._download_index()
            existing_ids = {e.id for e in index.entries}
            if entry.id not in existing_ids:
                index.entries.append(entry)
                self._upload_index(index)
        except (ClientError, BotoCoreError):
            pass  # Best-effort during sync

    # ── local index helpers ───────────────────────────────────────────

    def _load_local_index(self) -> LockerIndex:
        """Load and parse the local index. Returns empty on missing/corrupt."""
        index_path = self._local_index_path()
        if not index_path.exists():
            return LockerIndex(entries=[])
        try:
            raw = index_path.read_text(encoding="utf-8")
            return _parse_index(raw)
        except (json.JSONDecodeError, KeyError, TypeError):
            # Corrupted index — rename to .bak and start fresh
            bak = index_path.with_suffix(".json.bak")
            index_path.rename(bak)
            return LockerIndex(entries=[])


# ── module-level helpers ──────────────────────────────────────────────


def _parse_index(raw: str) -> LockerIndex:
    """Parse a JSON string into a LockerIndex."""
    data: dict[str, Any] = json.loads(raw)
    entries: list[IndexEntry] = []
    for item in data.get("entries", []):
        tokens_raw = item.get("tokens")
        tokens = (
            TokenUsage(
                input=tokens_raw["input"],
                output=tokens_raw["output"],
                total=tokens_raw["total"],
            )
            if tokens_raw is not None
            else None
        )
        entries.append(
            IndexEntry(
                id=item["id"],
                type=item["type"],
                timestamp=item["timestamp"],
                model=item["model"],
                prompt_preview=item["prompt_preview"],
                tokens=tokens,
            )
        )
    return LockerIndex(entries=entries)


def _serialize_index(index: LockerIndex) -> dict[str, Any]:
    """Convert a LockerIndex to a JSON-serializable dict."""
    return {
        "entries": [
            {
                "id": e.id,
                "type": e.type,
                "timestamp": e.timestamp,
                "model": e.model,
                "prompt_preview": e.prompt_preview,
                "tokens": (
                    {"input": e.tokens.input, "output": e.tokens.output, "total": e.tokens.total}
                    if e.tokens is not None
                    else None
                ),
            }
            for e in index.entries
        ]
    }
