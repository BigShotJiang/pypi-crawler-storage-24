"""JHED detection from STS/SSO caller identity."""

from __future__ import annotations

import boto3
from botocore.exceptions import BotoCoreError, ClientError

from alice_cli import personality
from alice_cli.errors import AuthError
from alice_cli.models import JHEDResult


def detect_identity_from_key(access_key: str | None) -> str:
    """Extract a display name from the Bedrock access key alias.

    The ``BEDROCK_ACCESS_KEY`` (``service_credential_alias``) follows the
    pattern ``BedrockAPIKey-<JHED>-at-<ACCOUNT>``.  We extract the JHED
    portion when the pattern matches, otherwise return the raw value.

    Returns ``"unknown"`` when the access key is empty / absent.
    """
    if not access_key:
        return "unknown"

    # Pattern: BedrockAPIKey-<jhed>-at-<account_id>
    if access_key.startswith("BedrockAPIKey-") and "-at-" in access_key:
        return access_key.removeprefix("BedrockAPIKey-").split("-at-", maxsplit=1)[0]

    return access_key


def detect_jhed(profile: str | None, region: str) -> JHEDResult:
    """Call STS get-caller-identity and extract the JHED from the ARN session name.

    Args:
        profile: AWS CLI profile name, or None if not provided.
        region: AWS region to use for the STS call.

    Returns:
        JHEDResult with jhed, session_name, and full ARN.

    Raises:
        AuthError: If no profile is provided, STS call fails, or JHED cannot be extracted.
    """
    if profile is None:
        raise AuthError(personality.error_no_profile())

    try:
        session = boto3.Session(profile_name=profile, region_name=region)
        sts = session.client("sts")
        identity = sts.get_caller_identity()
    except (ClientError, BotoCoreError):
        raise AuthError(personality.error_sso_expired(profile))

    arn: str = identity["Arn"]
    # ARN format: arn:aws:sts::ACCOUNT:assumed-role/ROLE/session_name
    session_name = arn.rsplit("/", maxsplit=1)[-1]

    if "@" not in session_name:
        raise AuthError(personality.error_jhed_extraction(session_name))

    jhed = session_name.split("@", maxsplit=1)[0]

    return JHEDResult(jhed=jhed, session_name=session_name, arn=arn)
