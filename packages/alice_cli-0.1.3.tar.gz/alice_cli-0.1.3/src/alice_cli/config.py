"""Configuration resolution with CLI > env var > stored > default precedence."""

from __future__ import annotations

import os

from alice_cli.models import CLIConfig
from alice_cli.store import load_stored_credentials

_DEFAULT_NAMESPACE = "drcc"
_DEFAULT_ENVIRONMENT = "ai"
_DEFAULT_REGION = "us-east-1"


def resolve_config(
    profile: str | None,
    region: str | None,
    namespace: str | None,
    environment: str | None,
    quiet: bool,
    api_key: str | None = None,
) -> CLIConfig:
    """Resolve CLI configuration with precedence: CLI option > env var > stored > default.

    Parameters that are ``None`` were not supplied on the command line, so the
    corresponding environment variable (if set) takes effect before the
    hard-coded default.

    The *api_key* parameter (from ``--api-key`` or ``BEDROCK_SECRET_KEY``)
    enables API-key mode, which bypasses SSO and Secrets Manager entirely.
    ``BEDROCK_ACCESS_KEY`` is also read from the environment when available.

    When no CLI flags or env vars provide auth, stored credentials from
    ``~/.alice/credentials.json`` (written by ``alice auth``) are used.
    """
    stored = load_stored_credentials()

    resolved_namespace = (
        namespace
        if namespace is not None
        else os.environ.get("ALICE_NAMESPACE", _DEFAULT_NAMESPACE)
    )

    resolved_environment = (
        environment
        if environment is not None
        else os.environ.get("ALICE_ENVIRONMENT", _DEFAULT_ENVIRONMENT)
    )

    resolved_region = region if region is not None else _DEFAULT_REGION

    # api_key already resolves from --api-key or BEDROCK_SECRET_KEY via Click envvar
    resolved_secret_key = api_key
    resolved_access_key = os.environ.get("BEDROCK_ACCESS_KEY") if resolved_secret_key else None

    # Fall back to stored credentials when nothing was provided via CLI/env.
    # Prefer stored API keys over stored profile for Bedrock model calls —
    # API keys don't require an active SSO session.  However, the SSO
    # profile is always needed for services like S3 (Cloud Locker), so
    # carry it forward independently of how the Bedrock key was resolved.
    resolved_profile = profile
    if not resolved_profile and not resolved_secret_key:
        if stored.bedrock_secret_key:
            resolved_secret_key = stored.bedrock_secret_key
            resolved_access_key = stored.bedrock_access_key

    # Always load the stored SSO profile when no explicit profile was
    # provided — even when Bedrock API keys are active — so that S3
    # operations can use SSO-scoped credentials.
    if not resolved_profile and stored.profile:
        resolved_profile = stored.profile

    if stored.region and region is None:
        resolved_region = stored.region

    # Load stored inference profile ARNs when using stored credentials
    resolved_inference_arns: dict[str, str] | None = None
    if not profile and not api_key and stored.inference_profile_arns:
        resolved_inference_arns = stored.inference_profile_arns

    return CLIConfig(
        profile=resolved_profile,
        region=resolved_region,
        namespace=resolved_namespace,
        environment=resolved_environment,
        quiet=quiet,
        bedrock_access_key=resolved_access_key,
        bedrock_secret_key=resolved_secret_key,
        inference_profile_arns=resolved_inference_arns,
    )
