"""Persistent credential store at ~/.alice/credentials.json."""

from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass
from pathlib import Path

_STORE_DIR = Path.home() / ".alice"
_STORE_FILE = _STORE_DIR / "credentials.json"


@dataclass
class StoredCredentials:
    """Credentials persisted between CLI sessions."""

    profile: str | None = None
    region: str | None = None
    bedrock_access_key: str | None = None
    bedrock_secret_key: str | None = None
    inference_profile_arns: dict[str, str] | None = None


def load_stored_credentials() -> StoredCredentials:
    """Load credentials from disk, returning defaults if the file is missing."""
    if not _STORE_FILE.exists():
        return StoredCredentials()
    try:
        data = json.loads(_STORE_FILE.read_text())
        return StoredCredentials(
            profile=data.get("profile"),
            region=data.get("region"),
            bedrock_access_key=data.get("bedrock_access_key"),
            bedrock_secret_key=data.get("bedrock_secret_key"),
            inference_profile_arns=data.get("inference_profile_arns"),
        )
    except (json.JSONDecodeError, OSError):
        return StoredCredentials()


def save_stored_credentials(creds: StoredCredentials) -> Path:
    """Write credentials to disk. Returns the path written."""
    _STORE_DIR.mkdir(parents=True, exist_ok=True)
    _STORE_FILE.write_text(json.dumps(asdict(creds), indent=2) + "\n")
    # Restrict permissions to owner only
    os.chmod(_STORE_FILE, 0o600)
    return _STORE_FILE


def clear_stored_credentials() -> None:
    """Remove the stored credentials file if it exists."""
    _STORE_FILE.unlink(missing_ok=True)
