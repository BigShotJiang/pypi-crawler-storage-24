"""alice status — Check SSO session, identity, and connectivity."""

from __future__ import annotations

import click

from alice_cli import personality
from alice_cli.auth import detect_identity_from_key, detect_jhed
from alice_cli.console import print_banner, print_status, print_table, spinner
from alice_cli.errors import AuthError


@click.command("status")
@click.pass_context
def status(ctx: click.Context) -> None:
    """Check SSO session, identity, and connectivity."""
    config = ctx.obj["config"]

    print_banner(personality.BANNER, config.quiet)

    rows: list[list[str]] = []

    with spinner(personality.status_checking_session(), config.quiet):
        try:
            result = detect_jhed(config.profile, config.region)
            rows.append(["JHED", result.jhed])
            rows.append(["Session", result.session_name])
            account = result.arn.split(":")[4]
            rows.append(["Account", account])
        except AuthError:
            if config.bedrock_secret_key and not config.profile:
                identity = detect_identity_from_key(config.bedrock_access_key)
                rows.append(["Auth", "API key mode (SSO bypassed)"])
                if identity and identity != "unknown":
                    rows.append(["Identity", identity])
            else:
                print_status(
                    "SSO session is not active. Run: aws sso login",
                    config.quiet,
                )

    rows.append(["Region", config.region])
    rows.append(["Namespace", config.namespace])
    rows.append(["Environment", config.environment])

    print_table(title="ALiCE Status", columns=["Setting", "Value"], rows=rows)
