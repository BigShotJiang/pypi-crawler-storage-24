"""alice invoke — Invoke a Bedrock model with a prompt."""

from __future__ import annotations

import boto3
import click
from botocore.exceptions import ClientError

from alice_cli import personality
from alice_cli.auth import detect_identity_from_key, detect_jhed
from alice_cli.console import (
    err_console,
    print_banner,
    print_rule,
    print_status,
    print_success,
    spinner,
)
from alice_cli.errors import AliceCLIError
from alice_cli.models import DEFAULT_MODEL_ALIAS, SaveFormat, model_help_text, resolve_model_id
from alice_cli.save import save_session
from alice_cli.secrets import build_secret_path, fetch_credentials


@click.command("invoke", context_settings={"ignore_unknown_options": True})
@click.option("--model-id", default=DEFAULT_MODEL_ALIAS, help=model_help_text())
@click.option("-o", "--output", "save_path", default=None, type=click.Path(), help="Write session output to a local file")
@click.option("-f", "--format", "fmt", default="markdown", type=click.Choice(["markdown", "json", "text"], case_sensitive=False), help="Output file format (default: markdown)")
@click.argument("prompt", nargs=-1, type=click.UNPROCESSED, required=True)
@click.pass_context
def invoke_cmd(ctx: click.Context, model_id: str, save_path: str | None, fmt: str, prompt: tuple[str, ...]) -> None:
    """Invoke a Bedrock model with a prompt."""
    config = ctx.obj["config"]

    prompt_text = " ".join(prompt).strip()
    if not prompt_text:
        raise AliceCLIError("Please provide a prompt after the options.")

    print_banner(personality.BANNER, config.quiet)

    if config.bedrock_secret_key and not config.profile:
        # API-key mode: skip STS identity detection and Secrets Manager
        identity = detect_identity_from_key(config.bedrock_access_key)
        print_status(personality.status_using_api_key(identity), config.quiet)

        resolved_id = resolve_model_id(model_id, config.inference_profile_arns)

        session = boto3.Session(
            aws_access_key_id=config.bedrock_access_key,
            aws_secret_access_key=config.bedrock_secret_key,
            region_name=config.region,
        )
        client = session.client("bedrock-runtime")

        with spinner(personality.status_invoking_model(model_id), config.quiet):
            try:
                response = client.converse(
                    modelId=resolved_id,
                    messages=[
                        {
                            "role": "user",
                            "content": [{"text": prompt_text}],
                        }
                    ],
                    inferenceConfig={"maxTokens": 4096},
                )
            except ClientError as exc:
                raise AliceCLIError(f"Bedrock API error: {exc}") from exc
    else:
        # SSO profile mode: detect identity and fetch credentials
        with spinner(personality.status_detecting_identity(), config.quiet):
            result = detect_jhed(config.profile, config.region)
        print_status(personality.status_identity_detected(result.jhed), config.quiet)

        secret_path = build_secret_path(config.namespace, config.environment, result.jhed)
        with spinner(personality.status_fetching_secret(), config.quiet):
            creds = fetch_credentials(config.profile, config.region, secret_path)

        resolved_id = resolve_model_id(model_id, creds.inference_profile_arns)
        if resolved_id != model_id:
            print_status(personality.status_resolved_profile(model_id), config.quiet)

        session = boto3.Session(profile_name=config.profile, region_name=config.region)
        client = session.client("bedrock-runtime")

        with spinner(personality.status_invoking_model(model_id), config.quiet):
            try:
                response = client.converse(
                    modelId=resolved_id,
                    messages=[
                        {
                            "role": "user",
                            "content": [{"text": prompt_text}],
                        }
                    ],
                    inferenceConfig={"maxTokens": 4096},
                )
            except ClientError as exc:
                raise AliceCLIError(f"Bedrock API error: {exc}") from exc

    # Parse and display response
    output_message = response.get("output", {}).get("message", {})
    content_blocks = output_message.get("content", [])
    text_parts = [block["text"] for block in content_blocks if "text" in block]
    output_text = "\n".join(text_parts)

    print_success(personality.status_model_ready(model_id), config.quiet)
    print_rule(config.quiet)
    if output_text.strip():
        from rich.markdown import Markdown

        err_console.print(Markdown(output_text))
    else:
        err_console.print("[dim](empty response)[/dim]")

    if save_path:
        save_session(
            path=save_path,
            prompt=prompt_text,
            model=model_id,
            content=output_text,
            quiet=config.quiet,
            fmt=SaveFormat(fmt.lower()),
        )
