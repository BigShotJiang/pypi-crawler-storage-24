"""alice list-aliases — Show available model aliases."""

from __future__ import annotations

import click

from alice_cli.console import print_table
from alice_cli.models import DEFAULT_MODEL_ALIAS, MODEL_ALIASES


@click.command("list-aliases")
@click.pass_context
def list_aliases(ctx: click.Context) -> None:
    """Show available model aliases and their Bedrock model IDs."""
    rows: list[list[str]] = []
    for m in MODEL_ALIASES:
        default_marker = " (default)" if m.alias == DEFAULT_MODEL_ALIAS else ""
        rows.append([m.alias + default_marker, m.description, m.model_id])

    print_table(
        title="Model Aliases",
        columns=["Alias", "Description", "Model ID"],
        rows=rows,
    )
