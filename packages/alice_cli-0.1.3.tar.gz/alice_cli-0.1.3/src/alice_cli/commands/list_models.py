"""alice list-models — List available Bedrock foundation models."""

from __future__ import annotations

import boto3
import click
from botocore.exceptions import ClientError

from alice_cli import personality
from alice_cli.console import print_banner, print_table, spinner
from alice_cli.errors import AliceCLIError


@click.command("list-models")
@click.pass_context
def list_models(ctx: click.Context) -> None:
    """List available Bedrock foundation models."""
    config = ctx.obj["config"]

    print_banner(personality.BANNER, config.quiet)

    session = boto3.Session(profile_name=config.profile, region_name=config.region)
    client = session.client("bedrock")

    with spinner(personality.status_fetching_models(), config.quiet):
        try:
            response = client.list_foundation_models()
        except ClientError as exc:
            raise AliceCLIError(f"Bedrock API error: {exc}") from exc

    summaries = response.get("modelSummaries", [])

    rows: list[list[str]] = []
    for model in summaries:
        rows.append(
            [
                model.get("modelId", ""),
                model.get("modelName", ""),
                model.get("providerName", ""),
                ", ".join(model.get("inputModalities", [])),
                ", ".join(model.get("outputModalities", [])),
            ]
        )

    print_table(
        title="Bedrock Foundation Models",
        columns=["Model ID", "Model Name", "Provider", "Input Modalities", "Output Modalities"],
        rows=rows,
    )
