"""Secrets Manager credential retrieval and validation."""

from __future__ import annotations

import json

import boto3
from botocore.exceptions import BotoCoreError, ClientError

from alice_cli import personality
from alice_cli.errors import SecretError
from alice_cli.models import CredentialSet


def build_secret_path(namespace: str, environment: str, jhed: str) -> str:
    """Construct the Secrets Manager path for a JHED's Bedrock API key.

    Args:
        namespace: Organizational prefix (e.g. "drcc").
        environment: Deployment stage (e.g. "ai").
        jhed: The user's JHED identifier.

    Returns:
        The full secret path: {namespace}/{environment}/bedrock-api-keys/{jhed}@jhu.edu
    """
    return f"{namespace}/{environment}/bedrock-api-keys/{jhed}@jhu.edu"


def fetch_inference_profiles(
    access_key: str, secret_key: str, region: str, secret_path: str
) -> dict[str, str]:
    """Retrieve inference profile ARNs from Secrets Manager using API key credentials.

    Returns an empty dict if the secret cannot be read or has no ARNs.
    """
    try:
        session = boto3.Session(
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key,
            region_name=region,
        )
        client = session.client("secretsmanager")
        response = client.get_secret_value(SecretId=secret_path)
        secret = json.loads(response["SecretString"])
        return secret.get("inference_profile_arns", {})
    except (ClientError, BotoCoreError, json.JSONDecodeError, KeyError):
        return {}


def _fetch_secret_json(profile: str, region: str, secret_path: str) -> dict:
    """Retrieve and parse a secret's JSON payload.

    Returns the parsed dict. Raises SecretError on failure.
    """
    try:
        session = boto3.Session(profile_name=profile, region_name=region)
        client = session.client("secretsmanager")
        response = client.get_secret_value(SecretId=secret_path)
    except (ClientError, BotoCoreError):
        raise SecretError(personality.error_secret_not_found(secret_path))

    return json.loads(response["SecretString"])


def fetch_credentials(profile: str, region: str, secret_path: str) -> CredentialSet:
    """Retrieve and validate Bedrock credentials from Secrets Manager.

    Args:
        profile: AWS CLI profile name.
        region: AWS region for the Secrets Manager call.
        secret_path: Full secret path in Secrets Manager.

    Returns:
        A CredentialSet with the parsed credentials.

    Raises:
        SecretError: If the secret is not found, revoked, or has an empty credential.
    """
    try:
        session = boto3.Session(profile_name=profile, region_name=region)
        client = session.client("secretsmanager")
        response = client.get_secret_value(SecretId=secret_path)
    except (ClientError, BotoCoreError):
        raise SecretError(personality.error_secret_not_found(secret_path))

    raw_json: str = response["SecretString"]
    secret = json.loads(raw_json)

    if secret.get("status") == "REVOKED":
        raise SecretError(personality.error_revoked())

    credential_secret = secret.get("service_credential_secret", "")
    if not credential_secret:
        raise SecretError(personality.error_empty_credential())

    return CredentialSet(
        bearer_token=credential_secret,
        access_key=secret.get("service_credential_alias", ""),
        secret_key=credential_secret,
        region=secret.get("region", region),
        status=secret.get("status", ""),
        raw_json=raw_json,
        inference_profile_arns=secret.get("inference_profile_arns", {}),
    )
