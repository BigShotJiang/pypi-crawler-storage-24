"""Amber retro color palette for the ALiCE TUI."""

AMBER = "#FFB000"  # Primary text — warm amber
AMBER_DIM = "#CC8800"  # Secondary/dim text
AMBER_BRIGHT = "#FFD866"  # Highlights, selected items
AMBER_BG = "#1A1100"  # Background — near-black with warm tint
AMBER_BG_LIGHT = "#2A1F00"  # Elevated surfaces (panels, modals)
AMBER_BORDER = "#805800"  # Borders and dividers
AMBER_ERROR = "#FF6600"  # Errors — orange-amber
AMBER_SUCCESS = "#88CC00"  # Success indicators — yellow-green
RETRO_BLUE = "#0A1628"  # Output panel background — retro terminal blue
RETRO_BLUE_BORDER = "#1A3A5C"  # Output panel border
