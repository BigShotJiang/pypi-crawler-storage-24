"""Monospace terminal clock widget for the ALiCE TUI."""

from __future__ import annotations

from datetime import datetime

from textual.reactive import reactive
from textual.widgets import Static


class TerminalClock(Static):
    """Displays a running HH:MM:SS clock, updated every second."""

    DEFAULT_CSS = """
    TerminalClock {
        dock: bottom;
        width: 100%;
        height: 1;
        background: #2A1F00;
        color: #CC8800;
        text-align: right;
        padding: 0 2;
    }
    """

    time_text: reactive[str] = reactive("")

    def on_mount(self) -> None:
        self.time_text = self._now()
        self.set_interval(1.0, self._tick)

    def _tick(self) -> None:
        self.time_text = self._now()

    def watch_time_text(self, value: str) -> None:
        self.update(value)

    @staticmethod
    def _now() -> str:
        now = datetime.now()
        return f"▌ {now:%H:%M:%S} ▐"
