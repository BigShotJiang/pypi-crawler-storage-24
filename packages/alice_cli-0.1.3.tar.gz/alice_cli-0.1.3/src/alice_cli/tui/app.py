"""ALiCE TUI — retro amber terminal interface."""

from __future__ import annotations

import shutil
import subprocess

from textual.app import App
from textual.binding import Binding

from alice_cli.models import CLIConfig
from alice_cli.personality import HINT_FONT, RECOMMENDED_FONTS
from alice_cli.tui.screens.home import HomeScreen


def _detect_terminal_font() -> str | None:
    """Best-effort detection of the current terminal font on macOS.

    Returns the font family name if it can be determined, otherwise ``None``.
    Works for iTerm2 (via its AppleScript API) and Terminal.app (via defaults).
    """
    # iTerm2
    osascript = shutil.which("osascript")
    if osascript:
        try:
            result = subprocess.run(
                [
                    osascript,
                    "-e",
                    'tell application "iTerm2" to get the name of the font '
                    "of current session of current window",
                ],
                capture_output=True,
                text=True,
                timeout=2,
            )
            if result.returncode == 0 and result.stdout.strip():
                return result.stdout.strip()
        except (subprocess.TimeoutExpired, OSError):
            pass

    # Terminal.app
    defaults = shutil.which("defaults")
    if defaults:
        try:
            result = subprocess.run(
                [defaults, "read", "com.apple.Terminal", "Default Window Settings"],
                capture_output=True,
                text=True,
                timeout=2,
            )
            profile = result.stdout.strip() if result.returncode == 0 else "Basic"
            result = subprocess.run(
                [
                    defaults,
                    "read",
                    "com.apple.Terminal",
                    f"Window Settings.{profile}.Font",
                ],
                capture_output=True,
                text=True,
                timeout=2,
            )
            if result.returncode == 0 and result.stdout.strip():
                return result.stdout.strip()
        except (subprocess.TimeoutExpired, OSError):
            pass

    return None


class AliceTUIApp(App):
    """ALiCE TUI — retro amber terminal interface."""

    CSS_PATH = "theme.tcss"
    TITLE = "ALiCE · JH DRCC"
    BINDINGS = [
        Binding("q", "quit", "Quit"),
        Binding("escape", "pop_screen", "Back"),
    ]

    def __init__(self, config: CLIConfig) -> None:
        super().__init__()
        self.alice_config = config

    def on_mount(self) -> None:
        self.push_screen(HomeScreen())
        self._check_font()

    def _check_font(self) -> None:
        """Show a one-time hint if the terminal font isn't one of the recommended ones."""
        font = _detect_terminal_font()
        if font is None:
            # Can't detect — don't nag.
            return
        if not any(rec.lower() in font.lower() for rec in RECOMMENDED_FONTS):
            self.notify(HINT_FONT, severity="information", timeout=6)

    def action_quit(self) -> None:
        from alice_cli.tui.screens.quit import QuitScreen

        self.push_screen(QuitScreen())
