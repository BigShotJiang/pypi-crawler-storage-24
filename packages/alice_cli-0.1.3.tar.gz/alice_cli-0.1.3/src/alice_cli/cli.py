"""Top-level Click group and global options for the alice CLI."""

from __future__ import annotations

import click

from alice_cli import __version__
from alice_cli.config import resolve_config
from alice_cli.errors import AliceCLIError
from alice_cli.models import CLIConfig


def launch_tui(config: CLIConfig) -> None:
    """Launch the interactive TUI mode.

    Lazily imports ``textual`` so CLI-only users never pay for the dependency.
    Raises :class:`AliceCLIError` if the ``textual`` extra is not installed.
    """
    try:
        from alice_cli.tui.app import AliceTUIApp
    except ImportError:
        raise AliceCLIError(
            "TUI mode needs the 'textual' package.\n"
            "  Install it with: poetry install --extras tui"
        )
    app = AliceTUIApp(config)
    app.run()


@click.group(invoke_without_command=True)
@click.option("--profile", envvar="AWS_PROFILE", default=None, help="AWS CLI profile")
@click.option("--region", default=None, help="AWS region (default: us-east-1)")
@click.option("--namespace", default=None, help="Resource namespace (default: drcc)")
@click.option("--environment", default=None, help="Deployment environment (default: ai)")
@click.option("--api-key", envvar="BEDROCK_SECRET_KEY", default=None, help="Bedrock API key (skips SSO/Secrets Manager; or set BEDROCK_SECRET_KEY)")
@click.option("--quiet", is_flag=True, help="Suppress banner and status messages")
@click.option("--tui", is_flag=True, help="Launch interactive TUI mode")
@click.version_option(version=__version__)
@click.pass_context
def cli(
    ctx: click.Context,
    profile: str | None,
    region: str | None,
    namespace: str | None,
    environment: str | None,
    api_key: str | None,
    quiet: bool,
    tui: bool,
) -> None:
    """ALiCE — Your AI research companion at Johns Hopkins."""
    ctx.ensure_object(dict)
    ctx.obj["config"] = resolve_config(
        profile, region, namespace, environment, quiet, api_key
    )
    if tui:
        launch_tui(ctx.obj["config"])
        ctx.exit()


from alice_cli.commands.appraise import appraise_cmd  # noqa: E402
from alice_cli.commands.auth import auth  # noqa: E402
from alice_cli.commands.batch import batch_cmd  # noqa: E402
from alice_cli.commands.chat import chat_cmd  # noqa: E402
from alice_cli.commands.compare import compare_cmd  # noqa: E402
from alice_cli.commands.compose import compose  # noqa: E402
from alice_cli.commands.config_cmd import config_cmd  # noqa: E402
from alice_cli.commands.diagnose import diagnose_cmd  # noqa: E402
from alice_cli.commands.dialog import dialog_cmd  # noqa: E402
from alice_cli.commands.get_key import get_key  # noqa: E402
from alice_cli.commands.get_secret import get_secret  # noqa: E402
from alice_cli.commands.invoke import invoke_cmd  # noqa: E402
from alice_cli.commands.list_aliases import list_aliases  # noqa: E402
from alice_cli.commands.list_models import list_models  # noqa: E402
from alice_cli.commands.list_secrets import list_secrets  # noqa: E402
from alice_cli.commands.recall import recall_cmd  # noqa: E402
from alice_cli.commands.run import run_cmd  # noqa: E402
from alice_cli.commands.status import status  # noqa: E402
from alice_cli.commands.summarize import summarize_cmd  # noqa: E402

cli.add_command(appraise_cmd)
cli.add_command(auth)
cli.add_command(batch_cmd)
cli.add_command(chat_cmd)
cli.add_command(compare_cmd)
cli.add_command(compose)
cli.add_command(config_cmd)
cli.add_command(diagnose_cmd)
cli.add_command(dialog_cmd)
cli.add_command(get_key)
cli.add_command(get_secret)
cli.add_command(invoke_cmd)
cli.add_command(list_aliases)
cli.add_command(list_models)
cli.add_command(list_secrets)
cli.add_command(recall_cmd)
cli.add_command(run_cmd)
cli.add_command(status)
cli.add_command(summarize_cmd)
