"""ALiCE voice: banners, messages, hints, errors.

All user-facing text lives here so ALiCE speaks with one consistent voice.
Messages use Rich markup for styling.
"""

from __future__ import annotations

from alice_cli.logo import LOGO

# --- ASCII Art Banner ---
BANNER = LOGO


# --- Greetings ---
def greeting(jhed: str) -> str:
    """Friendly greeting when JHED is detected."""
    return f"Hello, {jhed}! ALiCE here — let me grab your credentials."


# --- Success Messages ---
SUCCESS_KEY_RETRIEVED = "Your Bedrock key is ready. Happy researching!"
SUCCESS_CLAUDE_LAUNCH = "Launching Claude Code for you — enjoy the ride."


# --- Error Messages (warm but clear) ---
def error_no_profile() -> str:
    """Error when no AWS profile is available."""
    return (
        "I need an AWS profile or a Bedrock API key to get started.\n"
        "  Use --profile <NAME>, set AWS_PROFILE, or provide --api-key / BEDROCK_API_KEY."
    )


def error_sso_expired(profile: str) -> str:
    """Error when SSO session has expired."""
    return (
        f"Your SSO session seems to have expired.\n"
        f"  Run: aws sso login --profile {profile}\n"
        f"  Then try again — I'll be right here."
    )


def error_jhed_extraction(session_name: str) -> str:
    """Error when JHED cannot be extracted from session name."""
    return (
        f"I couldn't figure out your JHED from the session: {session_name}\n"
        "  This usually means the SSO session name isn't in the expected email format."
    )


def error_revoked() -> str:
    """Error when Bedrock access has been revoked."""
    return (
        "It looks like your Bedrock access has been revoked.\n"
        "  Reach out to the DRCC team to get this sorted out."
    )


def error_empty_credential() -> str:
    """Error when credential exists but is empty."""
    return (
        "Your secret exists but the credential is empty — it may need rotation.\n"
        "  Contact the DRCC team for help."
    )


def error_secret_not_found(secret_path: str) -> str:
    """Error when secret is not found in Secrets Manager."""
    return (
        f"I couldn't find a secret at: {secret_path}\n"
        "  Make sure your email is in the staff list and your SSO session is active."
    )


def error_dependency_missing(name: str, install_hint: str) -> str:
    """Error when a required dependency is missing."""
    return (
        f"I need '{name}' to continue, but it's not installed.\n"
        f"  Install it with: {install_hint}"
    )


def error_python_version(current: str, minimum: str) -> str:
    """Error when Python version is too old."""
    return (
        f"Python {minimum}+ is required, but you're running {current}.\n"
        "  Please upgrade Python and try again."
    )


def error_claude_not_found() -> str:
    """Error when claude command is not on PATH."""
    return (
        "I can't find 'claude' on your PATH.\n"
        "  Install Claude Code first: https://docs.anthropic.com/en/docs/claude-code"
    )


# --- Font Recommendation ---
RECOMMENDED_FONTS = ("Source Code Pro", "Fira Code")
HINT_FONT = (
    "For the best experience, set your terminal font to "
    "Source Code Pro or Fira Code."
)

# --- Contextual Hints ---
HINT_EVAL_USAGE = "Tip: eval $(alice get-key --eval) loads credentials into your shell."
HINT_CLAUDE_SHORTCUT = "Tip: alice auth --claude launches Claude Code in one step."


# --- Status Messages ---
def status_detecting_identity() -> str:
    """Status message while checking identity."""
    return "Checking your identity..."


def status_fetching_secret() -> str:
    """Status message while fetching credentials."""
    return "Fetching your Bedrock credentials..."


def status_identity_detected(jhed: str) -> str:
    """Status message when identity is detected."""
    return f"Detected identity: {jhed}"


def status_invoking_model(model_id: str) -> str:
    """Status message while waiting for a model response."""
    return f"Thinking… (model: [bold]{model_id}[/bold])"


def status_model_ready(model_id: str) -> str:
    """Status message after a successful model invocation."""
    return f"Response from [bold]{model_id}[/bold]"


def status_resolved_profile(alias: str) -> str:
    """Status message when an alias is resolved to an inference profile ARN."""
    return f"Using inference profile for [bold]{alias}[/bold]"


def error_no_inference_profile(alias: str) -> str:
    """Error when the user's secret has no inference profile for the requested alias."""
    return (
        f"No inference profile found for '{alias}' in your credentials.\n"
        "  Run 'alice list-aliases' to see available models, or pass a full model ID."
    )


def status_fetching_models() -> str:
    """Status message while listing foundation models."""
    return "Fetching available foundation models…"


def status_checking_session() -> str:
    """Status message while checking SSO session."""
    return "Checking SSO session…"


def status_using_api_key(identity: str = "") -> str:
    """Status message when using a direct API key instead of SSO."""
    if identity and identity != "unknown":
        return f"Using Bedrock API key as [bold]{identity}[/bold]"
    return "Using Bedrock API key"


# --- Compose Wizard Messages ---
def compose_greeting() -> str:
    """Greeting when starting the compose wizard."""
    return "Let's build an agent together — I'll walk you through it."


SUCCESS_AGENT_COMPOSED = "Your Strands agent is ready to go. Happy building!"
