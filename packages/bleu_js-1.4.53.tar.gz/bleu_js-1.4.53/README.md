# Bleu.js

**Quantum-enhanced AI platform: cloud API, CLI, and Python SDK.** [bleujs.org](https://bleujs.org) — *Get your first API call in under two minutes.*

[![Python 3.11+](https://img.shields.io/badge/python-3.11%2B-blue.svg)](https://www.python.org/downloads/)
[![Security: 9.5/10](https://img.shields.io/badge/Security-9.5%2F10-brightgreen.svg)]()
[![Status: Beta](https://img.shields.io/badge/Status-Beta-yellow.svg)]()

![Bleu.js Demo](https://github.com/HelloblueAI/Bleu.js/assets/81389644/ddfc34a4-a992-441c-9cf4-c5feeeb43568)

<div align="left">
  <a href="https://htmlpreview.github.io/?https://github.com/HelloblueAI/Bleu.js/blob/main/simple_animated_demo.html" target="_blank">
    <img src="https://img.shields.io/badge/Try%20Live%20Demo-blue?style=for-the-badge&logo=github" alt="Live Demo" />
  </a>
  <a href="https://htmlpreview.github.io/?https://github.com/HelloblueAI/Bleu.js/blob/main/api_playground.html" target="_blank">
    <img src="https://img.shields.io/badge/API%20Playground-green?style=for-the-badge&logo=github" alt="API Playground" />
  </a>
</div>

Bleu.js is a cutting-edge quantum-enhanced AI platform that combines classical machine learning with quantum computing capabilities.

**Efficient by default, powerful by choice.** We do *not* ship torch, shap, or numba in the default install. That keeps `pip install bleu-js` fast and reliable (no build failures, works everywhere) so you get the full **API + CLI + core** in one command. When you need heavy ML, quantum, or deep learning, add optional extras: `[ml]`, `[quantum]`, `[deep]`, or `[all]`. One product, one install command, zero friction for the majority of users—and a clear path to full power when you need it.

- **Who it's for:** ML engineers, researchers, and developers building quantum-enhanced AI, cloud APIs, or CLI tools.
- **Security & data:** API keys and secrets are not stored in the repo. For reporting vulnerabilities and deployment checklist, see [SECURITY.md](SECURITY.md).
- **Status:** Beta. [Changelog](CHANGELOG.md) · [Roadmap](docs/ROADMAP.md)
- **Evaluating Bleu.js or submitting for an award?** See [Evaluation & awards](docs/EVALUATION_AND_AWARDS.md).
- **Production:** [Installation & deployment](docs/INSTALLATION.md); use env-based secrets and see [SECURITY.md](SECURITY.md) for the deployment checklist; [Release checklist](docs/RELEASE_CHECKLIST.md) for cutting a version.

**Standards we follow** — Clean repo (one product surface, backend in a [separate repo](docs/BACKEND_REPO.md)); security-first (no secrets in tree, [SECURITY.md](SECURITY.md)); single source of truth for dependencies ([Dependabot doc](docs/DEPENDABOT_AND_DEPENDENCIES.md)); [API contract and response shapes](docs/API_CLIENT_GUIDE.md#api-contract-and-response-shapes); [Code of Conduct](CODE_OF_CONDUCT.md) and [Contributing](CONTRIBUTING.md). **Product app:** [Product architecture](docs/PRODUCT_ARCHITECTURE.md) (one app = `src/main.py` for bleujs.org). **Why we build it this way:** [Product philosophy](docs/PRODUCT_PHILOSOPHY.md). **Project structure:** Two repos (this one + [Bleujs.-backend](https://github.com/HelloblueAI/Bleujs.-backend)) — see [Repositories and sync](docs/REPOSITORIES.md).

---

### Get started in 60 seconds

**1. Install** (Python 3.11+):

```bash
pip install bleu-js
```

**2. Get an API key** at [bleujs.org](https://bleujs.org), then set it:

```bash
export BLEUJS_API_KEY="bleujs_sk_your_key_here"
# or: bleu config set api-key bleujs_sk_your_key_here
```

**3. Run:**

```bash
bleu chat "Say hello in one word."
```

Or in Python:

```python
from bleujs.api_client import BleuAPIClient
print(BleuAPIClient().chat([{"role": "user", "content": "Say hello."}]).content)
```

**4. Verify** (optional): `bleu version` or `bleujs version` · `bleu health` or `bleujs health` (checks API connection; both command names work)

**Full walkthrough:** [Get started](docs/GET_STARTED.md) · **Quick reference:** [QUICKSTART](docs/QUICKSTART.md) · **API & CLI docs:** [API Client Guide](docs/API_CLIENT_GUIDE.md)

---

### Install & first run (details)

**Requirements:** Python 3.11+

**Fast install (recommended)** — small download, API + CLI in seconds:

```bash
pip install bleu-js
```

**Quick test (SDK):** Get an API key at [bleujs.org](https://bleujs.org), then:

```python
from bleujs.api_client import BleuAPIClient
c = BleuAPIClient(api_key="bleujs_sk_...")
print(c.chat([{"role": "user", "content": "Say hi in one word."}]).content)
```

**Quick test (CLI):** `export BLEUJS_API_KEY=bleujs_sk_...` then `bleu chat "Hello"` (or `bleujs chat "Hello"`).

**What you get:** Cloud API client and CLI (above), core `BleuJS` for local processing. Add extras only when you need them: `pip install "bleu-js[ml]"` (XGBoost, scikit-learn), `bleu-js[quantum]` (Qiskit, PennyLane), `bleu-js[deep]` (PyTorch, TensorFlow), or `bleu-js[all]` for the full stack.

**Local app (self-host):** Copy [`.env.example`](.env.example) to `.env` and set your secrets; then run `python main.py` from the repo root. See [SECURITY.md](SECURITY.md) and [INSTALLATION](docs/INSTALLATION.md).

**More:** [Get started](docs/GET_STARTED.md) · [Full installation](docs/INSTALLATION.md) · [Quick start](docs/QUICKSTART.md) · [API client guide](docs/API_CLIENT_GUIDE.md)

## SDK – Cloud API

**Access Bleu.js via REST API at [bleujs.org](https://bleujs.org)**

The Bleu.js Python client is built to **best-in-market** standards: automatic retries with exponential backoff and `Retry-After` support, separate connect/read timeouts, rich error types (`RateLimitError.retry_after`), and robust handling of multiple API response shapes. See [API Client Guide – Best practices](docs/API_CLIENT_GUIDE.md#-best-practices-production).

### Quick Start with SDK

```bash
# Fast install (API client + CLI)
pip install bleu-js
```

```python
from bleujs.api_client import BleuAPIClient

# Get your API key from https://bleujs.org
client = BleuAPIClient(api_key="bleujs_sk_...")

# Chat completion
response = client.chat([
    {"role": "user", "content": "What is quantum computing?"}
])
print(response.content)

# Text generation
response = client.generate("Write a haiku about AI:")
print(response.text)

# Embeddings
response = client.embed(["text1", "text2"])
print(response.embeddings)

# List models
models = client.list_models()
```

**[Complete SDK Documentation](./docs/API_CLIENT_GUIDE.md)** · **[Get API Key](https://bleujs.org)** · **[Examples](examples/README.md)**

### Async Client

```python
import asyncio
from bleujs.api_client import AsyncBleuAPIClient

async def main():
    async with AsyncBleuAPIClient(api_key="bleujs_sk_...") as client:
        response = await client.chat([
            {"role": "user", "content": "Hello!"}
        ])
        print(response.content)

asyncio.run(main())
```

### Bleu CLI – Command Line Interface

Access Bleu.js from the terminal with the Bleu CLI.

#### Installation

```bash
# Fast install (includes CLI)
pip install bleu-js
```

#### Quick Start

```bash
# Set your API key
bleu config set api-key bleujs_sk_...

# Or use environment variable
export BLEUJS_API_KEY=bleujs_sk_...

# Chat with AI
bleu chat "What is quantum computing?"

# Generate text
bleu generate "Write a story about AI" --max-tokens 500

# Create embeddings
bleu embed "Hello world" "Goodbye world"

# List available models
bleu models list
```

#### Configuration

```bash
# Set API key
bleu config set api-key <your-api-key>

# View configuration
bleu config show

# Get specific config value
bleu config get api-key
```

#### Commands

**Chat Completions**

```bash
# Simple chat
bleu chat "Explain quantum computing"

# With system message and custom temperature
bleu chat "Write code" --system "You are a Python expert" --temperature 0.9

# Read from file
bleu chat --file prompt.txt

# JSON output
bleu chat "Hello" --json
```

**Text Generation**

```bash
# Generate text
bleu generate "Once upon a time"

# With custom parameters
bleu generate "Write a haiku" --temperature 0.8 --max-tokens 100

# Read prompt from file
bleu generate --file prompt.txt
```

**Embeddings**

```bash
# Embed multiple texts
bleu embed "text1" "text2" "text3"

# Embed from files
bleu embed --file text1.txt --file text2.txt

# JSON output
bleu embed "Hello world" --json
```

**Model Management**

```bash
# List all models
bleu models list

# Get model details
bleu models info bleu-chat-v1

# JSON output
bleu models list --json
```

**Utilities**

You can use either `bleu` or `bleujs` (both are installed):

```bash
# Check API health
bleu health   # or: bleujs health

# Show version
bleu version  # or: bleujs version

# Show help
bleu --help
bleu chat --help
```

#### Advanced Usage

**Piping and Input**

```bash
# Pipe input
echo "Hello world" | bleu chat

# Read from stdin
bleu generate < prompt.txt
```

**JSON Output**

```bash
# Get structured output
bleu chat "Hello" --json | jq '.content'
bleu models list --json | jq '.[].id'
```

**Environment Variables**

```bash
# Use environment variable instead of config
export BLEUJS_API_KEY=bleujs_sk_...
bleu chat "Hello"
```

#### CLI Features

- **Easy Configuration** – Simple API key management
- **Multiple Input Methods** – Arguments, files, or stdin
- **JSON Support** – Structured output for automation
- **Error Handling** – Clear error messages and suggestions
- **Model Management** – List and inspect available models
- **Health Checks** – Verify API connectivity

**[Complete CLI Documentation](./docs/API_CLIENT_GUIDE.md#cli-usage)** | **[Get API Key](https://bleujs.org)**

---

### Quick Install

```bash
# Install from PyPI (Recommended - latest release)
pip install --upgrade bleu-js

# Or install from GitHub (latest main)
pip install git+https://github.com/HelloblueAI/Bleu.js.git

# Or clone and install
git clone https://github.com/HelloblueAI/Bleu.js.git
cd Bleu.js
poetry install
```

**See full installation guide:** [INSTALLATION.md](./docs/INSTALLATION.md)

### Upgrade to Latest Version

```bash
# Upgrade from PyPI to latest
pip install --upgrade bleu-js

# Or upgrade from GitHub to latest main
pip install --upgrade git+https://github.com/HelloblueAI/Bleu.js.git
```

**What's new:** Comprehensive Bleu CLI (`bleu chat`, `bleu generate`, `bleu embed`, `bleu models`, etc.), SDK improvements, and more. See [CHANGELOG.md](./CHANGELOG.md) for full details.

**Get started at a glance:**

```mermaid
flowchart LR
    A["pip install bleu-js"] --> B{Use case?}
    B -->|Cloud API & CLI| C[Set API key → bleu chat / SDK]
    B -->|Quantum & teleport| D["pip install 'bleu-js[quantum]'"]
    B -->|ML / XGBoost| E["pip install 'bleu-js[ml]'"]
    C --> F[bleu chat / SDK]
    D --> G[bleu quantum teleport]
    E --> H[BleuJS + HybridTrainer]
```

> **Note:** Bleu.js is an advanced Python package for quantum-enhanced computer vision and AI. Node.js subprojects (plugins/tools) are experimental and not part of the official PyPI release. For the latest stable version, use the Python package from GitHub.

### [![Hugging Face](https://img.shields.io/badge/Hugging%20Face-Models-yellow?style=flat-square&logo=huggingface)](https://huggingface.co/helloblueai) Pre-trained Models

We provide pre-trained models on [Hugging Face](https://huggingface.co/helloblueai) for easy integration:

- **[Bleu.js XGBoost Classifier](https://huggingface.co/helloblueai/bleu-xgboost-classifier)** - Quantum-enhanced XGBoost classification model
  - Ready-to-use XGBoost model with quantum-enhanced features
  - Includes model weights and preprocessing scaler
  - Complete model card with usage examples

```python
from huggingface_hub import hf_hub_download
import pickle

# Download and use the model
model_path = hf_hub_download(
    repo_id="helloblueai/bleu-xgboost-classifier",
    filename="xgboost_model_latest.pkl"
)

with open(model_path, 'rb') as f:
    model = pickle.load(f)
```

### Important Documentation

**For users**

- **[Security policy & reporting](SECURITY.md)** - No secrets in repo; how to report vulnerabilities; deployment checklist
- **[User Concerns & FAQ](./docs/USER_CONCERNS_AND_FAQ.md)** - Addresses common concerns about documentation, dependencies, resources, and use cases
- **[API Reference](./docs/API_REFERENCE.md)** - Complete API documentation
- **[Resource Requirements](./docs/RESOURCE_REQUIREMENTS.md)** - System requirements and use case guidance
- **[Dependency Management](./docs/DEPENDENCY_MANAGEMENT.md)** - Managing dependencies and resolving conflicts
- **[Dependabot and dependency security](./docs/DEPENDABOT_AND_DEPENDENCIES.md)** - Why we keep scan scope minimal; do not re-add backend
- **[Backend repo](docs/BACKEND_REPO.md)** - Node/Express backend lives in a separate repo; export script and setup
- **[Repositories and sync](docs/REPOSITORIES.md)** - How the two repos work together (API contract, where to contribute)
- **[Community & Maintenance](./docs/COMMUNITY_AND_MAINTENANCE.md)** - Support channels and maintenance status

### Version

- **Single source of truth:** `src/bleujs/__init__.py` → `__version__`
- **Installed package:** `from bleujs import __version__` or `bleu version` / `bleujs version`
- **In-repo / API:** `from src.version import get_version` (used by the main app, `/health`, and FastAPI)

### For Contributors

- **[Contributing Guide](./docs/CONTRIBUTING.md)** - Complete guide for contributors
- **[Contributor Guide](./docs/CONTRIBUTOR_GUIDE.md)** - Quick start for new contributors
- **[Poetry: what to use from now on](docs/POETRY_FIX.md)** - Use `pipx run poetry` if `poetry` is broken; commands and fixes
- **[Onboarding Guide](./docs/ONBOARDING.md)** - Get started in 10 minutes
- **[Code of Conduct](./CODE_OF_CONDUCT.md)** - Community standards

## Quantum-Enhanced Vision System Achievements

### State-of-the-Art Performance Metrics

_Vision/quantum benchmarks (specific workloads):_

- **Detection Accuracy**: 18.90% confidence with 2.82% uncertainty
- **Processing Speed**: 23.73ms inference time
- **Quantum Advantage**: 1.95x speedup over classical methods
- **Energy Efficiency**: 95.56% resource utilization
- **Memory Efficiency**: 1.94MB memory usage
- **Qubit Stability**: 0.9556 stability score

### Quantum Performance Metrics

```mermaid
pie title Current vs Target Performance
    "Qubit Stability (95.6%)" : 95.6
    "Quantum Advantage (78.0%)" : 78.0
    "Energy Efficiency (95.6%)" : 95.6
    "Memory Efficiency (97.0%)" : 97.0
    "Processing Speed (118.7%)" : 118.7
    "Detection Accuracy (75.6%)" : 75.6
```

**Performance Breakdown:**

- **Qubit Stability**: 0.9556/1.0 (95.6% of target)
- **Quantum Advantage**: 1.95x/2.5x (78.0% of target)
- **Energy Efficiency**: 95.56%/100% (95.6% of target)
- **Memory Efficiency**: 1.94MB/2.0MB (97.0% of target)
- **Processing Speed**: 23.73ms/20ms (118.7% - exceeding target!)
- **Detection Accuracy**: 18.90%/25% (75.6% of target)

### Advanced Quantum Features

- **Quantum State Representation**
  - Advanced amplitude and phase tracking
  - Entanglement map optimization
  - Coherence score monitoring
  - Quantum fidelity measurement

- **Quantum Transformations**
  - Phase rotation with enhanced coupling
  - Nearest-neighbor entanglement interactions
  - Non-linear quantum activation
  - Adaptive noise regularization

- **Real-Time Monitoring**
  - Comprehensive metrics tracking
  - Resource utilization monitoring
  - Performance optimization
  - System health checks

### Production-Ready Components

- **Robust Error Handling**
  - Comprehensive exception management
  - Graceful degradation
  - Detailed error logging
  - System recovery mechanisms

## Key Features

**Platform overview:**

```mermaid
flowchart TB
    subgraph Users
        U1[CLI]
        U2[Python SDK]
        U3[Cloud API]
    end
    subgraph Bleu["Bleu.js core"]
        Q[Quantum]
        M[ML pipeline]
        A[API client]
    end
    U1 --> A
    U2 --> Q
    U2 --> M
    U2 --> A
    U3 --> A
    Q --> T[Teleportation]
    Q --> F[Feature extraction]
    M --> X[XGBoost / Hybrid]
```

- **Quantum Computing Integration**: Advanced quantum algorithms for enhanced processing
- **Multi-Modal AI Processing**: Cross-domain learning capabilities
- **Military-Grade Security**: Advanced security protocols with continuous updates
- **Performance Optimization**: Real-time monitoring and optimization
- **Neural Architecture Search**: Automated design and optimization
- **Quantum-Resistant Encryption**: Future-proof security measures
- **Cross-Modal Learning**: Unified models across different data types
- **Real-time Translation**: Context preservation in translations
- **Automated Security**: AI-powered threat detection
- **Self-Improving Models**: Continuous learning and adaptation

### Installation options

**Fast install (default)** — small download, API + CLI only (~seconds):

```bash
pip install bleu-js
```

**Add only what you need:**

| Extra | Use case |
|-------|----------|
| `pip install bleu-js` | Default: API client + CLI (start here) |
| `pip install "bleu-js[ml]"` | Pandas, scikit-learn, XGBoost |
| `pip install "bleu-js[quantum]"` | Qiskit, PennyLane |
| `pip install "bleu-js[deep]"` | PyTorch, TensorFlow |
| `pip install "bleu-js[all]"` | Full stack (ML + quantum + deep + server) |

**Troubleshooting**
If you encounter dependency conflicts, try:

```bash
# Use virtual environment
python3 -m venv bleujs-env
source bleujs-env/bin/activate
pip install bleu-js
```

**Prerequisites**

- Python 3.11+ (see [Installation](docs/INSTALLATION.md))
- Docker (optional, for containerized deployment)
- CUDA-capable GPU (optional, for quantum/ML workloads)
- 16GB+ RAM (recommended)

### Quick Start

```python
from bleujs import BleuJS

# Initialize the quantum-enhanced system
bleu = BleuJS(
    quantum_mode=True,
    model_path="models/quantum_xgboost.pkl",
    device="cuda"  # Use GPU if available
)

# Process your data
results = bleu.process(
    input_data="your_data",
    quantum_features=True,
    attention_mechanism="quantum"
)
```

### Development

- **Run tests:** `pytest tests/ -q` (optional: `pip install pytest pytest-asyncio` for async tests)
- **Version:** `from bleujs import get_version` or `from src.version import get_version`
- **API exceptions (SDK):** `from bleujs import BleuAPIError, RateLimitError, AuthenticationError, NetworkError, ValidationError`
- **Server exceptions (app only):** `from src import ServiceUnavailable, RateLimitExceeded` when running the FastAPI app
- **How to contribute:** see [Contributing Guide](./docs/CONTRIBUTING.md)

### Reliability

- When dependencies are unavailable, the API returns **503 Service Unavailable** (circuit breaker). **SDK:** catch `BleuAPIError`, `RateLimitError` from `bleujs`. **Server (self-hosted app):** use `ServiceUnavailable` and `RateLimitExceeded` from `src` for middleware/error handling.

### CI/CD Pipeline

Bleu.js uses GitHub Actions for automated CI/CD. Key features:

- **Automated Testing**: Unit tests, integration tests, and performance benchmarks
- **Code Quality Checks**: Black, isort, flake8, mypy, and security scans
- **Security Scanning**: Bandit, Safety, and Semgrep integration
- **Performance Monitoring**: Real-time performance tracking and optimization
- **Deployment Automation**: Automated deployment to staging and production
- **Quality Gates**: SonarQube integration with quality thresholds

For local CI/CD testing, you can use the `act` tool to run GitHub Actions workflows locally. See [GitHub Actions documentation](https://docs.github.com/en/actions) for details.

## API Documentation

For complete API documentation, see [API Reference](./docs/API_REFERENCE.md).

## Examples

**Run ready-made scripts:** See [examples/](examples/) and [examples/README.md](examples/README.md) for API vs local examples and how to run them.

### Quantum Feature Extraction

```python
from bleujs.quantum import QuantumFeatureExtractor

# Initialize feature extractor
extractor = QuantumFeatureExtractor(
    num_qubits=4,
    entanglement_type="full"
)

# Extract quantum features
features = extractor.extract(
    data=your_data,
    use_entanglement=True
)
```

### Quantum Teleportation

Run the standard three-qubit teleportation protocol (simulator or IBM Quantum). See [docs/QUANTUM_TELEPORTATION.md](docs/QUANTUM_TELEPORTATION.md) for research notes and citations (Bennett et al. 1993).

**To run it after cloning:** install with the quantum extra, then use the CLI or Python API. For real IBM hardware, add the `ibm` extra and set `QISKIT_IBM_TOKEN`.

```bash
pip install -e ".[quantum]"                    # simulator only
pip install -e ".[quantum,ibm]"                # + IBM Quantum (set QISKIT_IBM_TOKEN)
```

```python
from bleujs.teleportation import build_teleportation_circuit, run_teleportation_simulator

qc = build_teleportation_circuit(theta=1.234)
out = run_teleportation_simulator(theta=1.234, shots=2048)
print(out["counts"])
```

```bash
bleu quantum teleport --theta 0.9 --shots 1024
bleu quantum teleport --ibm --shots 1024   # IBM Quantum (set QISKIT_IBM_TOKEN)
```

### Hybrid Model Training

```python
from bleujs.ml import HybridTrainer

# Initialize trainer
trainer = HybridTrainer(
    model_type="xgboost",
    quantum_components=True
)

# Train the model
model = trainer.train(
    X_train=X_train,
    y_train=y_train,
    quantum_features=True
)
```

## Docker Setup

### Quick Start

```bash
# Clone the repository
git clone https://github.com/HelloblueAI/Bleu.js.git
cd Bleu.js

# Start all services
docker-compose up -d

# Access the services:
# - Frontend: http://localhost:3000
# - Backend API: http://localhost:4003
# - MongoDB Express: http://localhost:8081
```

### Available Services

- **Backend API**: FastAPI server (port 4003)
  - Main API endpoint
  - RESTful interface
  - Swagger documentation available
- **Core Engine**: Quantum processing engine (port 6000)
  - Quantum computing operations
  - Real-time processing
  - GPU acceleration support
- **MongoDB**: Database (port 27017)
  - Primary data store
  - Document-based storage
  - Replication support
- **Redis**: Caching layer (port 6379)
  - In-memory caching
  - Session management
  - Real-time data
- **Eggs Generator**: AI model service (port 5000)
  - Model inference
  - Training pipeline
  - Model management
- **MongoDB Express**: Database admin interface (port 8081)
  - Database management
  - Query interface
  - Performance monitoring

### Service Dependencies

```mermaid
graph LR
    A[Frontend] --> B[Backend API]
    B --> C[Core Engine]
    B --> D[MongoDB]
    B --> E[Redis]
    C --> F[Eggs Generator]
    D --> G[MongoDB Express]
```

### Health Check Endpoints

- Backend API: `http://localhost:4003/health`
- Core Engine: `http://localhost:6000/health`
- Eggs Generator: `http://localhost:5000/health`
- MongoDB Express: `http://localhost:8081/health`

### Development Mode

```bash
# Start with live reload
docker-compose -f docker-compose.yml -f docker-compose.dev.yml up -d

# View logs
docker-compose logs -f

# Rebuild specific service
docker-compose up -d --build <service-name>
```

### Production Mode

```bash
# Start in production mode
docker-compose -f docker-compose.yml -f docker-compose.prod.yml up -d

# Scale workers
docker-compose up -d --scale worker=3
```

### Environment Variables

Create a `.env` file in the root directory:

```env
MONGODB_URI=mongodb://admin:pass@mongo:27017/bleujs?authSource=admin
REDIS_HOST=redis
PORT=4003
```

### Common Commands

```bash
# Stop all services
docker-compose down

# View service status
docker-compose ps

# View logs of specific service
docker-compose logs <service-name>

# Enter container shell
docker-compose exec <service-name> bash

# Run tests
docker-compose run test
```

### Troubleshooting

1. **Services not starting**: Check logs with `docker-compose logs`
2. **Database connection issues**: Ensure MongoDB is running with `docker-compose ps`
3. **Permission errors**: Make sure volumes have correct permissions
4. **After OS upgrade (e.g. Pop!\_OS)** / **"permission denied" on Docker**: Add your user to the `docker` group once: `sudo usermod -aG docker $USER`, then log out and back in (or run `newgrp docker`). See [docs/DOCKER_AFTER_OS_UPGRADE.md](docs/DOCKER_AFTER_OS_UPGRADE.md). Run `./scripts/docker-verify-and-run.sh` to verify Docker and optionally start the stack.

### Data Persistence

Data is persisted in Docker volumes:

- MongoDB data: `mongo-data` volume
- Logs: `./logs` directory
- Application data: `./data` directory

## Performance Metrics

_Targets and benchmarks; actual results depend on workload and environment._

### Core Performance

- Processing Speed: up to 10x faster than traditional AI with quantum acceleration
- Accuracy: up to 93.6% in code-analysis workloads with continuous improvement
- Security: Military-grade encryption with quantum resistance
- Scalability: Infinite with intelligent cluster management
- Resource Usage: Optimized for maximum efficiency with auto-scaling
- Response Time: Sub-millisecond with intelligent caching
- Uptime: 99.999% with automatic failover
- Model Size: 10x smaller than competitors with advanced compression
- Memory Usage: 50% more efficient with smart allocation
- Training Speed: 5x faster than industry standard with distributed computing

### Global Impact

- 3K+ Active Developers with growing community
- 100,000+ Projects Analyzed with continuous learning
- 100x Faster Processing with quantum acceleration
- 0 Security Breaches with military-grade protection
- 15+ Countries Served with global infrastructure

### Enterprise Features

- All Core Features with priority access
- Military-Grade Security with custom protocols
- Custom Integration with dedicated engineers
- Dedicated Support Team with direct access
- SLA Guarantees with financial backing
- Custom Training with specialized curriculum
- White-label Options with branding control

## System Architecture

```mermaid
graph TB
    subgraph Frontend
        UI[User Interface]
        API[API Client]
    end

    subgraph Backend
        QE[Quantum Engine]
        ML[ML Pipeline]
        DB[(Database)]
    end

    subgraph Quantum Processing
        QC[Quantum Core]
        QA[Quantum Attention]
        QF[Quantum Features]
    end

    UI --> API
    API --> QE
    API --> ML
    QE --> QC
    QC --> QA
    QC --> QF
    ML --> DB
    QE --> DB
```

## Data Flow

```mermaid
sequenceDiagram
    participant User
    participant Frontend
    participant QuantumEngine
    participant MLPipeline
    participant Database

    User->>Frontend: Submit Data
    Frontend->>QuantumEngine: Process Request
    QuantumEngine->>QuantumEngine: Quantum Feature Extraction
    QuantumEngine->>MLPipeline: Enhanced Features
    MLPipeline->>Database: Store Results
    Database-->>Frontend: Return Results
    Frontend-->>User: Display Results
```

## Model Architecture

```mermaid
graph LR
    subgraph Input
        I[Input Data]
        F[Feature Extraction]
    end

    subgraph Quantum Layer
        Q[Quantum Processing]
        A[Attention Mechanism]
        E[Entanglement]
    end

    subgraph Classical Layer
        C[Classical Processing]
        N[Neural Network]
        X[XGBoost]
    end

    subgraph Output
        O[Output]
        P[Post-processing]
    end

    I --> F
    F --> Q
    Q --> A
    A --> E
    E --> C
    C --> N
    N --> X
    X --> P
    P --> O
```

## What’s next & keep improving

- **[Roadmap](docs/ROADMAP.md)** — Planned features and status.
- **[Changelog](CHANGELOG.md)** — Latest changes and releases.
- **[Product philosophy](docs/PRODUCT_PHILOSOPHY.md)** — How we stay efficient by default and powerful by choice.
- **Contributing** — See below; we keep improving and enhancing the SDK, CLI, and docs.

---

## Contributing

We welcome contributions. New to the repo? **[Start with a good first issue](https://github.com/HelloblueAI/Bleu.js/issues?q=is%3Aopen+is%3Aissue+label%3A%22good+first+issue%22)** or fix a typo, add a test, or improve docs.

### Quick Links

- **[Contributing Guide](docs/CONTRIBUTING.md)** - Complete guide for contributors
- **[Contributor Guide](docs/CONTRIBUTOR_GUIDE.md)** - Quick start (5 min)
- **[Onboarding Guide](docs/ONBOARDING.md)** - Get started in 10 minutes
- **[Code of Conduct](CODE_OF_CONDUCT.md)** - Community standards

### Ways to Contribute

- **Report bugs** - Help us find and fix issues
- **Suggest features** - Share your ideas
- **Improve documentation** - Make docs better for everyone
- **Add tests** - Improve test coverage
- **Write code** - Fix bugs, add features
- **Help others** - Answer questions in Discussions
- **Review PRs** - Help review pull requests

### Getting Started

1. **Read the guides:**
   - [Contributor Guide](docs/CONTRIBUTOR_GUIDE.md) - Start here!
   - [Contributing Guide](docs/CONTRIBUTING.md) - Full details

2. **Find something to work on:**
   - [Good first issues](https://github.com/HelloblueAI/Bleu.js/issues?q=is%3Aopen+is%3Aissue+label%3A%22good+first+issue%22)
   - [All issues](https://github.com/HelloblueAI/Bleu.js/issues)

3. **Make your first contribution:**
   - Fix a typo
   - Add a test
   - Improve documentation

**Questions?** Open a [Discussion](https://github.com/HelloblueAI/Bleu.js/discussions) or [Issue](https://github.com/HelloblueAI/Bleu.js/issues)!

### Contributors

Thank you to all contributors who help make Bleu.js better!

<!-- Contributors will be automatically added by all-contributors bot -->
<!-- See: https://allcontributors.org/ -->

**Want to be recognized?** Make a contribution and you'll be added to our contributors list!

## Development Setup

**Poetry (what to use from now on):** This repo uses Poetry. If `poetry` fails with `PoetryCoreException` or `InvalidRequirement`, use Poetry via pipx for all commands: `pipx run poetry install --extras all`, `pipx run poetry lock`, `pipx run poetry run pytest`, etc. Full list and fixes: [Poetry: what to use from now on](docs/POETRY_FIX.md).

### Running the Development Server

**Quick Start (No Configuration Required):**

The application now includes development defaults, so you can start the server immediately:

```bash
# Start the development server (uses SQLite by default)
python -m uvicorn src.main:app --reload --port 8002

# Or specify SQLite explicitly
DATABASE_URL="sqlite:///./bleujs.db" python -m uvicorn src.main:app --reload --port 8002
```

**What Works Out of the Box:**

- SQLite database (no PostgreSQL required for development)
- Development secret keys (auto-generated defaults)
- All core features functional
- API documentation at http://localhost:8002/docs

**For Production:**

- Set proper `SECRET_KEY`, `JWT_SECRET_KEY`, `JWT_SECRET`, and `ENCRYPTION_KEY` in environment variables
- Use PostgreSQL for production: `DATABASE_URL=postgresql://user:pass@host:port/dbname`

For complete development setup instructions, see [Contributing Guide](./docs/CONTRIBUTING.md).

## Bleu OS – Quantum-Enhanced Operating System

Linux distribution optimized for quantum computing and AI workloads.

### What is Bleu OS?

Bleu OS is a specialized Linux distribution designed from the ground up for quantum computing and AI workloads, with native Bleu.js integration.

**Key Features:**

- **2x faster** quantum circuit execution
- **1.5x faster** ML training
- **3.75x faster** boot time
- Quantum-resistant security
- Zero-config Bleu.js integration

### Get Bleu OS Now

**Docker (Recommended - 5 minutes):**

```bash
docker pull bleuos/bleu-os:latest
docker run -it --gpus all bleuos/bleu-os:latest
```

**Download ISO:**

- Visit [GitHub Releases](https://github.com/HelloblueAI/Bleu.js/releases)
- Download `bleu-os-1.0.0-x86_64.iso`
- Create bootable USB and install

**Cloud Deployment:**

- **AWS:** Search "Bleu OS" in Marketplace
- **GCP:** Available in GCP Marketplace
- **Azure:** Available in Azure Marketplace

**Learn more:**

- [User Guide](./bleu-os/USER_GUIDE.md) - How to use Bleu OS
- [How Users Get It](./bleu-os/HOW_USERS_GET_IT.md) - All distribution methods
- [Quick Start](./bleu-os/QUICKSTART.md) - Get started in 5 minutes

## Additional Resources

### Documentation

- **[Roadmap](./docs/ROADMAP.md)** - Development plans and future features
- **[Changelog](./docs/CHANGELOG.md)** - Version history and release notes
- **[Product architecture](docs/PRODUCT_ARCHITECTURE.md)** - One product app, what runs at bleujs.org
- **[API Client Guide](docs/API_CLIENT_GUIDE.md)** - SDK and API documentation
- **[Bleu OS Documentation](./bleu-os/README.md)** - Operating system documentation

### Community & Support

- **[Community & Maintenance](./docs/COMMUNITY_AND_MAINTENANCE.md)** - Support channels and maintenance status
- **[User Concerns & FAQ](./docs/USER_CONCERNS_AND_FAQ.md)** - Common questions and answers
- **[Contributing Guide](./docs/CONTRIBUTING.md)** - How to contribute to the project
- **[Onboarding Guide](./docs/ONBOARDING.md)** - Get started in 10 minutes

### Quick Links

- **GitHub Repository**: [HelloblueAI/Bleu.js](https://github.com/HelloblueAI/Bleu.js)
- **Hugging Face Models**: [helloblueai/bleu-xgboost-classifier](https://huggingface.co/helloblueai/bleu-xgboost-classifier)
- **Issues**: [Report a Bug](https://github.com/HelloblueAI/Bleu.js/issues)
- **Discussions**: [Join the Discussion](https://github.com/HelloblueAI/Bleu.js/discussions)

### Contact & Support

- **General Support**: support@helloblue.ai
- **Security Issues**: security@helloblue.ai (do NOT use public issues)
- **Commercial Inquiries**: support@helloblue.ai

---


[![AI](https://img.shields.io/badge/AI-NLP%20%7C%20Decision%20Tree-purple?style=flat-square&logo=ai)](https://github.com/HelloblueAI/Bleu.js)

[![Platform Support](https://img.shields.io/badge/Platform-Linux-green)](https://github.com/HelloblueAI/Bleu.js)
[![Maintained](https://img.shields.io/badge/Maintained-Yes-brightgreen?style=flat-square&logo=github)](https://github.com/HelloblueAI/Bleu.js)
[![version](https://img.shields.io/badge/version-1.4.x-0ff?style=flat)](https://pypi.org/project/bleu-js/)
[![Neural Networks](https://img.shields.io/badge/Neural%20Networks-Convolutional%20%7C%20Recurrent-red?style=flat-square&logo=pytorch)](https://github.com/HelloblueAI/Bleu.js)
[![Deep Learning](https://img.shields.io/badge/Deep%20Learning-TensorFlow%20%7C%20PyTorch-orange?style=flat-square&logo=tensorflow)](https://github.com/HelloblueAI/Bleu.js)
[![Machine Learning](https://img.shields.io/badge/Machine%20Learning-Supervised%20%7C%20Unsupervised-blue?style=flat-square&logo=python)](https://github.com/HelloblueAI/Bleu.js)
[![Reinforcement Learning](https://img.shields.io/badge/Reinforcement%20Learning-Q%20Learning%20%7C%20Deep%20Q-blueviolet?style=flat-square&logo=google)](https://github.com/HelloblueAI/Bleu.js)
[![Data Science](https://img.shields.io/badge/Data%20Science-Pandas%20%7C%20Numpy-yellow?style=flat-square&logo=python)](https://github.com/HelloblueAI/Bleu.js)
[![Visualization](https://img.shields.io/badge/Visualization-Matplotlib%20%7C%20Seaborn-green?style=flat-square&logo=chart)](https://github.com/HelloblueAI/Bleu.js)
[![Scalability](https://img.shields.io/badge/Scalability-Auto--Scales%20with%20Demand-007bff?style=flat&logo=server)](https://github.com/HelloblueAI/Bleu.js)
[![Open Source Excellence](https://img.shields.io/badge/Award-Open%20Source%20Excellence-blueviolet?style=flat-square&logo=opensourceinitiative)](https://github.com/HelloblueAI/Bleu.js)
[![Top Developer Tool](https://img.shields.io/badge/Award-Top%20Developer%20Tool-green?style=flat-square&logo=githubactions)](https://github.com/HelloblueAI/Bleu.js)
[![GitHub CI/CD](https://img.shields.io/github/actions/workflow/status/HelloblueAI/Bleu.js/main.yml?logo=github-actions&label=CI/CD)](https://github.com/HelloblueAI/Bleu.js)
[![AI Performance Leader](https://img.shields.io/badge/Performance-Leader-orange?style=flat-square&logo=fastapi)](https://github.com/HelloblueAI/Bleu.js)
[![Tests Passing](https://img.shields.io/badge/Tests-Passing-brightgreen?style=flat)](https://github.com/HelloblueAI/Bleu.js)
[![SonarQube Grade](https://img.shields.io/badge/SonarQube-Coverage%2041%25-brightgreen)](https://sonarcloud.io/project/overview?id=HelloblueAI_Bleu.js)
[![Quantum Computing](https://img.shields.io/badge/Quantum-Qiskit%20%7C%20Cirq%20%7C%20PennyLane-blue?style=flat&logo=quantum)](https://github.com/HelloblueAI/Bleu.js)
[![Quantum Enhanced](https://img.shields.io/badge/Quantum%20Enhanced-AI%20Platform-purple?style=flat)](https://github.com/HelloblueAI/Bleu.js)
[![Quantum ML](https://img.shields.io/badge/Quantum%20ML-XGBoost%20Enhanced-green?style=flat)](https://github.com/HelloblueAI/Bleu.js)
[![MIT License](https://img.shields.io/badge/License-MIT-brightgreen?style=flat-square&logo=opensource)](https://github.com/HelloblueAI/Bleu.js)

This software is maintained by Helloblue Inc., a company dedicated to advanced innovations in AI solutions.

## License

Bleu.js is licensed under the [MIT License](https://github.com/HelloblueAI/Bleu.js/blob/main/LICENSE.md)
