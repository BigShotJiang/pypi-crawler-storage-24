"""
Utility functions for Bleu.js
"""

import logging
import sys


def get_version() -> str:
    """Return the Bleu.js package version."""
    try:
        from .. import __version__

        return __version__
    except ImportError:
        try:
            import importlib.metadata

            return importlib.metadata.version("bleu-js")
        except Exception as e:
            logging.getLogger(__name__).warning(
                "Could not resolve bleu-js version: %s; using 0.0.0", e
            )
            return "0.0.0"


def setup_logging(level: int = logging.INFO) -> None:
    """
    Setup logging configuration.

    Args:
        level: Logging level (default: INFO)
    """
    logging.basicConfig(
        level=level,
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        handlers=[logging.StreamHandler(sys.stdout)],
    )


def get_device() -> str:
    """
    Detect and return the best available computing device.

    Returns:
        str: 'cuda' if CUDA-capable GPU is available, otherwise 'cpu'

    Example:
        >>> device = get_device()
        >>> print(f"Using device: {device}")
    """
    try:
        import torch

        if torch.cuda.is_available():
            return "cuda"
    except ImportError:
        pass

    return "cpu"


def check_dependencies(group: str = "core") -> dict:
    """
    Check if required dependencies are installed.

    Args:
        group: Dependency group to check ('core', 'quantum', 'ml', 'all')

    Returns:
        dict: Status of each dependency

    Example:
        >>> status = check_dependencies('quantum')
        >>> print(status)
    """
    dependencies = {
        "core": ["numpy", "pandas"],
        "quantum": ["qiskit", "pennylane"],
        "ml": ["torch", "tensorflow", "xgboost"],
    }

    if group == "all":
        check_list = [dep for deps in dependencies.values() for dep in deps]
    else:
        check_list = dependencies.get(group, [])

    status = {}
    for dep in check_list:
        try:
            __import__(dep)
            status[dep] = "installed"
        except ImportError:
            status[dep] = "missing"

    return status
