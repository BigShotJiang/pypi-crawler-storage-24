"""Universal audio markup tags supported by narrate-gpt.

Every TTS backend must handle each tag listed here by either passing it
through natively or stripping / converting it to a backend-specific equivalent.

To add a new tag:
  1. Add its regex pattern to MARKUP_TAGS below.
  2. Add a handler for every backend in BACKEND_HANDLERS.
"""

from __future__ import annotations

import re
from typing import Callable

# Each entry: (tag_name, compiled regex that matches the full tag)
MARKUP_TAGS: dict[str, re.Pattern[str]] = {
    "break": re.compile(r'<break\s+time="[^"]*"\s*/>'),
}

# Per-backend handlers: tag_name -> callable(match) -> replacement string.
# A backend that supports a tag natively can use _passthrough.
_passthrough = lambda m: m.group(0)
_strip = lambda m: ""

BACKEND_HANDLERS: dict[str, dict[str, Callable]] = {
    "inworld": {
        "break": _passthrough,
    },
    "openai": {
        "break": _strip,
    },
}


def translate_markup(text: str, backend: str) -> str:
    """Translate universal markup tags for the given TTS backend."""
    handlers = BACKEND_HANDLERS.get(backend)
    if handlers is None:
        raise ValueError(
            f"Unknown TTS backend: {backend!r}. "
            f"Supported backends: {sorted(BACKEND_HANDLERS)}"
        )
    for tag_name, pattern in MARKUP_TAGS.items():
        handler = handlers.get(tag_name)
        if handler is None:
            raise NotImplementedError(
                f"Backend {backend!r} has no handler for markup tag {tag_name!r}. "
                "Every backend must handle all tags in MARKUP_TAGS."
            )
        text = pattern.sub(handler, text)
    return text
