"""High-level interface to Inworld's TTS streaming API.

Implements a similar interface to OpenAITTS for interchangeability.
"""

from __future__ import annotations

import asyncio
import base64
import json
import os
import wave
from contextlib import asynccontextmanager
from enum import Enum
from typing import AsyncGenerator, Optional

import httpx
from openai.helpers import LocalAudioPlayer
from pydantic import BaseModel, Field
from tqdm import tqdm

from narrate_gpt.constants import translate_markup
from narrate_gpt.tts import AudioFormat

MAX_TEXT_LENGTH = 2000


def _chunk_text(text: str, max_length: int = MAX_TEXT_LENGTH) -> list[str]:
    """Split *text* into pieces that each fit within *max_length* characters.

    Split-point priority (highest → lowest):
      1. Newline characters
      2. Sentence endings  (. ? !)
      3. Sentence breaks   (; --)
      4. Commas
      5. Whitespace
      6. Hard cut (no good split point)
    """
    if len(text) <= max_length:
        return [text]

    window = text[:max_length]

    # (delimiter_to_search, chars_to_keep_with_left_chunk)
    strategies: list[tuple[str, int]] = [
        ("\n", 1),
        (". ", 1),
        ("? ", 1),
        ("! ", 1),
        ("; ", 1),
        (" -- ", 3),
        (", ", 1),
        (" ", 0),
    ]

    for delim, offset in strategies:
        idx = window.rfind(delim)
        if idx > 0:
            split = idx + offset
            left = text[:split].rstrip()
            right = text[split:].lstrip()
            if left and right:
                return [left] + _chunk_text(right, max_length)

    # No delimiter found – hard cut at max_length.
    return [text[:max_length]] + _chunk_text(text[max_length:], max_length)


class AudioEncoding(str, Enum):
    """Supported audio encodings for Inworld TTS."""

    LINEAR16 = "LINEAR16"


class InworldTTSConfig(BaseModel):
    """Configuration for Inworld TTS."""

    api_key: Optional[str] = Field(
        default=None,
        description="Inworld API key (falls back to INWORLD_API_KEY env var)",
    )
    base_url: str = Field(
        default="https://api.inworld.ai/tts/v1/voice:stream",
        description="Inworld TTS streaming endpoint",
    )
    model_id: str = Field(
        default="inworld-tts-1.5-max", description="Inworld TTS model id"
    )
    voice_id: str = Field(default="Mark", description="Inworld voice id")
    audio_encoding: AudioEncoding = Field(
        default=AudioEncoding.LINEAR16,
        description="Audio encoding (LINEAR16 recommended)",
    )
    sample_rate_hertz: int = Field(
        default=24000,
        description="Sample rate for LINEAR16 audio (use 24000 for LocalAudioPlayer)",
    )
    channels: int = Field(default=1, description="Number of audio channels")


class _InworldStreamResponse:
    """Minimal streamed response interface compatible with LocalAudioPlayer."""

    def __init__(
        self,
        generator: AsyncGenerator[bytes, None],
    ) -> None:
        self._generator = generator

    async def iter_bytes(self, chunk_size: int = 1024) -> AsyncGenerator[bytes, None]:
        buffer = bytearray()
        async for chunk in self._generator:
            if not chunk:
                continue
            buffer.extend(chunk)
            while len(buffer) >= chunk_size:
                yield bytes(buffer[:chunk_size])
                del buffer[:chunk_size]
        if buffer:
            yield bytes(buffer)

    async def read(self) -> bytes:
        return b"".join([chunk async for chunk in self.iter_bytes()])


class InworldTTS:
    """Args:
    config: InworldTTSConfig object with TTS settings.
    """

    def __init__(self, config: Optional[InworldTTSConfig] = None) -> None:
        self.config = config or InworldTTSConfig()

    def _get_api_key(self) -> str:
        api_key = self.config.api_key or os.getenv("INWORLD_API_KEY")
        if not api_key:
            raise ValueError("Missing Inworld API key (set INWORLD_API_KEY)")
        return api_key

    @asynccontextmanager
    async def request(
        self,
        text: str,
        model: str | None = None,
        voice: str | None = None,
        format: AudioFormat | None = None,
        audio_encoding: AudioEncoding | None = None,
        sample_rate_hertz: int | None = None,
        max_concurrency: int = 4,
    ):
        if format is not None and format not in {AudioFormat.PCM, AudioFormat.WAV}:
            raise ValueError("Inworld TTS only supports PCM/WAV output")

        text = translate_markup(text, "inworld")
        chunks = _chunk_text(text)
        resolved_encoding = audio_encoding or self.config.audio_encoding
        resolved_sample_rate = sample_rate_hertz or self.config.sample_rate_hertz

        headers = {
            "Authorization": f"Basic {self._get_api_key()}",
            "Content-Type": "application/json",
            "Connection": "keep-alive",
        }

        async def fetch_chunk(
            client: httpx.AsyncClient,
            chunk_text: str,
            semaphore: asyncio.Semaphore,
        ) -> bytes:
            async with semaphore:
                payload = {
                    "text": chunk_text,
                    "voice_id": voice or self.config.voice_id,
                    "model_id": model or self.config.model_id,
                    "audio_config": {
                        "audio_encoding": resolved_encoding.value,
                        "sample_rate_hertz": resolved_sample_rate,
                    },
                }
                pcm_parts: list[bytes] = []
                async with client.stream(
                    "POST",
                    self.config.base_url,
                    json=payload,
                    headers=headers,
                ) as response:
                    try:
                        response.raise_for_status()
                    except httpx.HTTPStatusError as e:
                        raise RuntimeError(
                            "Inworld TTS request failed"
                        ) from e

                    async for line in response.aiter_lines():
                        if not line:
                            continue
                        try:
                            data = json.loads(line)
                        except json.JSONDecodeError:
                            continue
                        result = data.get("result") or {}
                        audio_content = result.get("audioContent")
                        if not audio_content:
                            continue
                        audio_chunk = base64.b64decode(audio_content)
                        if len(audio_chunk) > 44:
                            pcm_parts.append(audio_chunk[44:])
                return b"".join(pcm_parts)

        async def combined_pcm_generator() -> AsyncGenerator[bytes, None]:
            semaphore = asyncio.Semaphore(max_concurrency)
            async with httpx.AsyncClient(timeout=None) as client:
                tasks = [
                    asyncio.create_task(fetch_chunk(client, ct, semaphore))
                    for ct in chunks
                ]
                progress = tqdm(total=len(tasks), desc="TTS", unit="chunk")
                for task in tasks:
                    result = await task
                    progress.update(1)
                    if result:
                        yield result
                progress.close()

        yield _InworldStreamResponse(combined_pcm_generator())

    async def save(
        self,
        text: str,
        path: str,
        model: str | None = None,
        voice: str | None = None,
        format: AudioFormat | None = None,
        audio_encoding: AudioEncoding | None = None,
        sample_rate_hertz: int | None = None,
        max_concurrency: int = 4,
    ) -> None:
        """Convert text to speech and save it to a WAV file."""
        resolved_sample_rate = sample_rate_hertz or self.config.sample_rate_hertz

        async with self.request(
            text=text,
            model=model,
            voice=voice,
            format=format,
            audio_encoding=audio_encoding,
            sample_rate_hertz=resolved_sample_rate,
            max_concurrency=max_concurrency,
        ) as response:
            pcm_bytes = await response.read()

        with wave.open(path, "wb") as wf:
            wf.setnchannels(self.config.channels)
            wf.setsampwidth(2)
            wf.setframerate(resolved_sample_rate)
            wf.writeframes(pcm_bytes)

    async def play(
        self,
        text: str,
        model: str | None = None,
        voice: str | None = None,
        audio_encoding: AudioEncoding | None = None,
        sample_rate_hertz: int | None = None,
        max_concurrency: int = 4,
    ) -> None:
        """Convert text to speech and play it using LocalAudioPlayer.

        Note: LocalAudioPlayer uses a fixed 24kHz sample rate. For accurate
        playback, set sample_rate_hertz to 24000.
        """
        resolved_sample_rate = sample_rate_hertz or self.config.sample_rate_hertz
        if resolved_sample_rate != 24000:
            raise ValueError(
                "LocalAudioPlayer only supports 24000Hz audio; "
                "set sample_rate_hertz=24000"
            )

        async with self.request(
            text=text,
            model=model,
            voice=voice,
            format=AudioFormat.PCM,
            audio_encoding=audio_encoding,
            sample_rate_hertz=resolved_sample_rate,
            max_concurrency=max_concurrency,
        ) as response:
            await LocalAudioPlayer().play(response)


if __name__ == "__main__":
    import asyncio

    tts = InworldTTS()
    asyncio.run(tts.save("Hello from Inworld TTS!", "./inworld.wav"))
