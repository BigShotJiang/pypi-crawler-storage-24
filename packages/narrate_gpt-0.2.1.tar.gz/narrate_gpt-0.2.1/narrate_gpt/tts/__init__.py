from __future__ import annotations

from enum import Enum
from typing import TYPE_CHECKING, Optional, Union

if TYPE_CHECKING:
    from narrate_gpt.tts.inworld import InworldTTS
    from narrate_gpt.tts.openai import OpenAITTS


class AudioFormat(str, Enum):
    """Supported audio output formats."""

    MP3 = "mp3"  # Default format for general use
    OPUS = "opus"  # For internet streaming, low latency
    AAC = "aac"  # Digital audio compression (YouTube, iOS, Android)
    FLAC = "flac"  # Lossless audio compression
    WAV = "wav"  # Uncompressed audio, low latency
    PCM = "pcm"  # Raw 24kHz 16-bit samples


def load_tts(
    tts_provider: Optional[str] = None, **kwargs
) -> Union[InworldTTS, OpenAITTS]:
    """Load a TTS instance by provider name.

    Args:
        tts_provider: The TTS provider to use ("inworld" or "openai").
        **kwargs: Passed through to the provider's config constructor.
    """
    if tts_provider is None:
        tts_provider = "inworld"

    if tts_provider == "inworld":
        from narrate_gpt.tts.inworld import InworldTTS, InworldTTSConfig

        return InworldTTS(config=InworldTTSConfig(**kwargs) if kwargs else None)
    elif tts_provider == "openai":
        from narrate_gpt.tts.openai import OpenAITTS, OpenAITTSConfig

        return OpenAITTS(config=OpenAITTSConfig(**kwargs) if kwargs else None)
    else:
        raise ValueError(
            f"Unknown TTS provider: {tts_provider!r}. "
            "Supported providers: 'inworld', 'openai'"
        )


__all__ = [
    "AudioFormat",
    "load_tts",
]
