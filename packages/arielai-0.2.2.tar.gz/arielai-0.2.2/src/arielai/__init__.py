"""
ArielAI — Build chatbots in minutes.

Quick start (free, no API key)::

    from arielai import Chatbot
    Chatbot().launch()

With OpenAI::

    Chatbot(openai_api_key="sk-...").launch()          # GPT-4o-mini
    Chatbot("gpt-4o", backend="openai", openai_api_key="sk-...").launch()

Branded UI::

    from arielai import Chatbot, ChatUI
    bot = Chatbot(openai_api_key="sk-...")
    ChatUI(bot, brand_name="Nova", accent="violet").launch()
"""

from .chatbot import Chatbot
from .ui import ChatUI, ACCENT_COLORS
from .models import list_presets, get_preset, ModelPreset, PRESETS, DEFAULT_MODELS
from .backends import (
    BaseBackend,
    TransformersBackend,
    OllamaBackend,
    HFInferenceBackend,
    OpenAIBackend,
    create_backend,
    auto_select_backend,
)

__version__ = "0.2.2"
__author__ = "ArielAI Contributors"

__all__ = [
    "Chatbot",
    "ChatUI",
    "launch",
    "list_presets",
    "get_preset",
    "ModelPreset",
    "PRESETS",
    "DEFAULT_MODELS",
    "ACCENT_COLORS",
    "BaseBackend",
    "TransformersBackend",
    "OllamaBackend",
    "HFInferenceBackend",
    "OpenAIBackend",
    "create_backend",
    "auto_select_backend",
]


def launch(
    model: str = None,
    *,
    backend: str = None,
    openai_api_key: str = None,
    title: str = "ArielAI",
    system_prompt: str = "You are a helpful AI assistant. Be concise and clear.",
    share: bool = False,
    **kwargs,
) -> None:
    """
    One-liner to launch a chatbot immediately.

    Example::

        import arielai
        arielai.launch()
        arielai.launch(openai_api_key="sk-...")
    """
    bot = Chatbot(model=model, backend=backend, title=title,
                  system_prompt=system_prompt, openai_api_key=openai_api_key,
                  **kwargs)
    bot.launch(share=share)
