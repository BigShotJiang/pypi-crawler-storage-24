from arielai import Chatbot, ChatUI

bot = Chatbot(
    model="microsoft/DialoGPT-medium",
    backend="transformers",
    system_prompt=(
        "You are Nova, a friendly and knowledgeable AI assistant. "
        "You give clear, concise answers and are always polite."
    ),
    streaming=True,
    max_new_tokens=400,
    temperature=0.75,
    placeholder="Ask Nova anything...",
    examples=[
        "What is machine learning?",
        "Explain quantum computing in simple terms.",
        "Write a haiku about the ocean.",
        "Give me 3 tips for learning Python faster.",
    ],
)

ui = ChatUI(
    bot,
    brand_name="Nova AI",
    tagline="Your intelligent assistant, available 24/7",
    accent="violet",
    dark_mode=True,
    show_footer=True,
    footer_text="Nova AI · Powered by ArielAI",
    footer_link="https://pypi.org/project/arielai/",
)

ui.launch(share=False)
