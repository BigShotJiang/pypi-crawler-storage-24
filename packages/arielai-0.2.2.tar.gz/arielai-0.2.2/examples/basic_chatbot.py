"""
Basic chatbot example using ArielAI.

Run with:
    python examples/basic_chatbot.py
"""

from arielai import Chatbot

bot = Chatbot(
    model="microsoft/DialoGPT-medium",
    title="My First Chatbot",
    description="Powered by DialoGPT and ArielAI",
)

bot.launch()
