"""
Preset chatbot example — the fastest way to get started.

Run with:
    python examples/preset_chatbot.py
"""

import arielai
from arielai import Chatbot, list_presets

# Print available presets
print("Available presets:")
for name, description in list_presets().items():
    print(f"  {name}: {description}")
print()

# Launch using a preset
bot = Chatbot.from_preset(
    "tiny",
    title="Tiny Chatbot (preset)",
)
bot.launch()
