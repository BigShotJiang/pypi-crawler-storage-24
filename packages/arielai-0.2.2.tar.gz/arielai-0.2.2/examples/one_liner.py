"""
The absolute minimum to launch a chatbot with ArielAI.

Run with:
    python examples/one_liner.py
"""

import arielai

arielai.launch("microsoft/DialoGPT-medium")
