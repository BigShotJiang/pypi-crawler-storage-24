"""
Custom chatbot example — demonstrates the full range of Chatbot options.

Run with:
    python examples/custom_chatbot.py
"""

from arielai import Chatbot

bot = Chatbot(
    model="HuggingFaceH4/zephyr-7b-beta",
    backend="transformers",
    title="Zephyr Assistant",
    description="An intelligent assistant powered by Zephyr-7B",
    system_prompt=(
        "You are a knowledgeable and friendly AI assistant. "
        "Be concise, accurate, and helpful."
    ),
    placeholder="Ask me anything...",
    max_new_tokens=512,
    temperature=0.7,
    streaming=True,
    theme="soft",
    examples=[
        "What is the capital of France?",
        "Explain quantum entanglement simply.",
        "Write a haiku about coding.",
    ],
)

bot.launch(share=False)
