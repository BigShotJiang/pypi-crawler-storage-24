"""
Ollama-powered chatbot example.

Requires Ollama to be installed and running: https://ollama.ai
Pull a model first:
    ollama pull llama3

Then run:
    python examples/ollama_chatbot.py
"""

from arielai import Chatbot

bot = Chatbot(
    model="llama3",
    backend="ollama",
    title="LLaMA 3 via Ollama",
    description="Locally-hosted LLaMA 3, no cloud required",
    system_prompt="You are a helpful AI assistant.",
    streaming=True,
    examples=[
        "Tell me a fun fact.",
        "What are the best practices for REST API design?",
        "Help me debug my Python code.",
    ],
)

bot.launch()
