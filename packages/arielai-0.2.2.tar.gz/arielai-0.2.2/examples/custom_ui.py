"""
ChatUI example — polished branded frontend with custom colors and dark mode.

Run with:
    python examples/custom_ui.py
"""

from arielai import Chatbot, ChatUI

bot = Chatbot(
    model="microsoft/DialoGPT-medium",
    system_prompt="You are a friendly and helpful AI assistant.",
    streaming=True,
    examples=[
        "Tell me something interesting.",
        "What can you help me with?",
        "Write a short poem.",
    ],
)

ui = ChatUI(
    bot,
    brand_name="My AI Assistant",
    tagline="Powered by open-source AI",
    accent="indigo",
    dark_mode=False,
    footer_text="Built with ArielAI",
    footer_link="https://github.com/arielai/arielai",
)

ui.launch()
