"""
Dark mode ChatUI example.

Run with:
    python examples/dark_ui.py
"""

from arielai import Chatbot, ChatUI

bot = Chatbot(
    model="microsoft/DialoGPT-medium",
    streaming=True,
)

ui = ChatUI(
    bot,
    brand_name="NightBot",
    tagline="Your late-night AI companion",
    accent="violet",
    dark_mode=True,
)

ui.launch()
