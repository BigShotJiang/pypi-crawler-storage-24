"""Unit tests for ChatUI v0.2.0."""

import pytest
from arielai import ChatUI, ACCENT_COLORS
from arielai.backends import BaseBackend
from arielai.chatbot import Chatbot


class MockBackend(BaseBackend):
    def generate(self, message, history, **kwargs):
        return f"Echo: {message}"


@pytest.fixture
def bot():
    return Chatbot(model="test-model", backend_instance=MockBackend())


class TestChatUIInit:
    def test_defaults(self, bot):
        ui = ChatUI(bot)
        assert ui.dark_mode is True
        assert ui.show_footer is True

    def test_custom(self, bot):
        ui = ChatUI(bot, brand_name="Nova", accent="rose", dark_mode=False)
        assert ui.brand_name == "Nova"
        assert ui.accent == ACCENT_COLORS["rose"]
        assert ui.dark_mode is False

    def test_hex_accent(self, bot):
        ui = ChatUI(bot, accent="#ff6b6b")
        assert ui.accent == "#ff6b6b"

    def test_tagline_includes_model(self, bot):
        ui = ChatUI(bot)
        assert "test-model" in ui.tagline


class TestAccentColors:
    def test_all_present(self):
        for key in ("indigo", "violet", "rose", "emerald", "amber", "blue", "cyan", "slate"):
            assert key in ACCENT_COLORS

    def test_all_hex(self):
        for name, val in ACCENT_COLORS.items():
            assert val.startswith("#"), f"Accent {name!r} is not hex"

    def test_list_accents(self, bot):
        ui = ChatUI(bot)
        assert isinstance(ui.list_accents(), dict)


class TestCSSGeneration:
    def test_css_contains_accent(self, bot):
        ui = ChatUI(bot, accent="#abcdef")
        css = ui._make_css()
        assert "#abcdef" in css

    def test_extra_css_injected(self, bot):
        ui = ChatUI(bot, extra_css=".my-class { color: red; }")
        css = ui._make_css()
        assert ".my-class" in css
