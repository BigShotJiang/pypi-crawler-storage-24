"""Server lifecycle management (start, stop, status)."""

from __future__ import annotations

import os
import shutil
import signal
import subprocess
import sys
import time

from llama_buddy.config import (
    CONFIG_DIR,
    LOG_FILE,
    PRESET_FILE,
    ensure_config_dir,
    read_pid,
    remove_pid,
    write_pid,
)
from llama_buddy.console import console

WATCHDOG_PID_FILE = CONFIG_DIR / "watchdog.pid"


def is_process_running(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except OSError:
        return False


def find_server_binary() -> str | None:
    return shutil.which("llama-server")


def _start_watchdog(settings) -> None:
    """Spawn the idle-model watchdog as a background process."""
    if settings.idle_timeout <= 0:
        return

    _stop_watchdog()

    poll_interval = max(30, settings.idle_timeout // 10)
    log_fh = open(LOG_FILE, "a")
    proc = subprocess.Popen(
        [
            sys.executable, "-m", "llama_buddy.watchdog",
            str(settings.port), str(poll_interval),
        ],
        stdout=log_fh,
        stderr=subprocess.STDOUT,
        start_new_session=True,
    )
    log_fh.close()
    ensure_config_dir()
    WATCHDOG_PID_FILE.write_text(str(proc.pid))


def _stop_watchdog() -> None:
    """Stop the idle-model watchdog if running."""
    if not WATCHDOG_PID_FILE.exists():
        return
    text = WATCHDOG_PID_FILE.read_text().strip()
    WATCHDOG_PID_FILE.unlink(missing_ok=True)
    if not text:
        return
    try:
        pid = int(text)
    except ValueError:
        return
    if is_process_running(pid):
        os.kill(pid, signal.SIGTERM)


EFFECTIVE_PRESET_FILE = CONFIG_DIR / "models.effective.ini"


def _build_effective_preset(global_ctx: int) -> None:
    """Write a copy of the preset with per-model context clamped to native max.

    llama-server allocates KV cache based on ctx-size even when the model's
    native context is smaller, wasting VRAM. This writes clamped ``c`` values
    into a temporary INI so the user's preset stays untouched.
    """
    import io

    from llama_buddy.config import read_preset
    from llama_buddy.models import get_model_meta

    preset = read_preset()

    if global_ctx > 0:
        for section in preset.sections():
            if section in ("DEFAULT", "*"):
                continue
            meta = get_model_meta(section)
            native_str = meta.get("context_length", "")
            if not native_str:
                continue
            native = int(native_str.replace(",", ""))
            try:
                model_ctx = int(preset.get(section, "c", fallback="0"))
            except ValueError:
                model_ctx = 0
            effective = model_ctx or global_ctx
            if effective > native:
                preset.set(section, "c", str(native))

    buf = io.StringIO()
    preset.write(buf)
    ensure_config_dir()
    EFFECTIVE_PRESET_FILE.write_text(buf.getvalue())


def start(extra_args: list[str] | None = None) -> None:
    from llama_buddy.settings import load_settings

    pid = read_pid()
    if pid is not None and is_process_running(pid):
        console.print(
            f"llama-server is already running [dim](PID {pid})[/dim].",
            style="yellow",
        )
        return

    binary = find_server_binary()
    if binary is None:
        console.print(
            "llama-server not found. Please install llama.cpp.",
            style="red",
        )
        raise SystemExit(1)

    if not PRESET_FILE.exists():
        console.print(f"No preset file at {PRESET_FILE}", style="red")
        console.print(
            "Add models first with: [bold]llb download <model>[/bold]"
        )
        raise SystemExit(1)

    settings = load_settings()
    ensure_config_dir()
    _build_effective_preset(settings.ctx_size)

    log_fh = open(LOG_FILE, "a")

    cmd = [binary, "--models-preset", str(EFFECTIVE_PRESET_FILE)]
    cmd.extend(settings.to_server_args())
    if extra_args:
        cmd.extend(extra_args)

    proc = subprocess.Popen(
        cmd,
        stdout=log_fh,
        stderr=subprocess.STDOUT,
        start_new_session=True,
    )
    log_fh.close()
    write_pid(proc.pid)
    console.print(
        f"llama-server started [dim](PID {proc.pid})[/dim].", style="green"
    )

    _start_watchdog(settings)


def stop() -> None:
    _stop_watchdog()

    pid = read_pid()
    if pid is None:
        console.print("llama-server is not running.", style="yellow")
        return

    if not is_process_running(pid):
        console.print(
            f"llama-server [dim](PID {pid})[/dim] is not running. "
            "Cleaning up.",
            style="yellow",
        )
        remove_pid()
        return

    os.kill(pid, signal.SIGTERM)
    for _ in range(20):
        if not is_process_running(pid):
            break
        time.sleep(0.25)
    else:
        os.kill(pid, signal.SIGKILL)

    remove_pid()
    EFFECTIVE_PRESET_FILE.unlink(missing_ok=True)
    console.print("llama-server stopped.", style="green")


def restart(extra_args: list[str] | None = None) -> None:
    stop()
    start(extra_args)


def is_running() -> bool:
    """Check if the llama-server is currently running."""
    pid = read_pid()
    return pid is not None and is_process_running(pid)


def restart_if_running() -> None:
    """Restart the server if it is currently running."""
    if is_running():
        console.print("Restarting llama-server…", style="dim")
        restart()


def status() -> None:
    pid = read_pid()
    if pid is None or not is_process_running(pid):
        if pid is not None:
            remove_pid()
        console.print("llama-server is [red]not running[/red].")
        return

    console.print(
        f"llama-server is [green]running[/green] [dim](PID {pid})[/dim]."
    )
