import os
import subprocess
import sys
from pathlib import Path

import click


@click.command()
def setup_cmd():
    """Bootstrap a complete FortressCodeAI development environment."""

    project_root = Path(__file__).resolve().parents[3]
    venv_path = project_root / ".venv"

    # 1. Create virtual environment
    if not venv_path.exists():
        click.echo("Creating virtual environment...")
        subprocess.check_call([sys.executable, "-m", "venv", str(venv_path)])

    # 2. Determine pip inside venv
    pip = venv_path / ("Scripts/pip.exe" if os.name == "nt" else "bin/pip")

    # 3. Install package in editable mode
    click.echo("Installing FortressCodeAI in editable mode...")
    subprocess.check_call([str(pip), "install", "-e", "."])

    # 4. Install dev dependencies
    dev_requirements = project_root / "requirements-dev.txt"
    if dev_requirements.exists():
        click.echo("Installing development dependencies...")
        subprocess.check_call([str(pip), "install", "-r", str(dev_requirements)])

    click.echo("\nEnvironment ready.")
    click.echo("Activate with:")
    click.echo("  source .venv/bin/activate" if os.name != "nt" else "  .venv\\Scripts\\activate")
