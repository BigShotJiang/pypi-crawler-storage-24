from __future__ import annotations

import click

from fortresscodeai.cli.commands.doctor import doctor_cmd
from fortresscodeai.cli.commands.down import down_cmd
from fortresscodeai.cli.commands.logs import logs_cmd
from fortresscodeai.cli.commands.setup import setup_cmd
from fortresscodeai.cli.commands.status import status_cmd
from fortresscodeai.cli.commands.up import up_cmd


@click.group(
    help=(
        "FortressCodeAI CLI\n"
        "Governance-first automation platform for teams, agencies, and engineering orgs."
    )
)
def cli() -> None:
    """Root FortressCodeAI CLI entrypoint."""
    pass


# Primary lifecycle commands
cli.add_command(setup_cmd, "setup")
cli.add_command(up_cmd, "up")
cli.add_command(down_cmd, "down")

# Operational commands
cli.add_command(status_cmd, "status")
cli.add_command(logs_cmd, "logs")
cli.add_command(doctor_cmd, "doctor")

if __name__ == "__main__":
     cli()
