"""macroforecast.pipeline — Layer 2: Forecasting experiment and model grid."""

from macroforecast.pipeline.components import (
    CVScheme,
    CVSchemeType,
    LossFunction,
    Nonlinearity,
    Regularization,
    Window,
)
from macroforecast.pipeline.estimator import MacrocastEstimator, SequenceEstimator
from macroforecast.pipeline.experiment import FeatureSpec, ForecastExperiment, ModelSpec
from macroforecast.pipeline.features import FeatureBuilder
from macroforecast.pipeline.horserace import HorseRaceGrid
from macroforecast.pipeline.models import (
    GBModel,
    KRRModel,
    LSTMModel,
    NNModel,
    RFModel,
    SVRLinearModel,
    SVRRBFModel,
    XGBoostModel,
)
from macroforecast.pipeline.r_models import (
    AdaptiveLassoModel,
    ARDIModel,
    ARModel,
    BoogingModel,
    BVARModel,
    ElasticNetModel,
    GroupLassoModel,
    LassoModel,
    RidgeModel,
    RModelEstimator,
    TVPRidgeModel,
)
from macroforecast.pipeline.results import ForecastRecord, ResultSet

__all__ = [
    # components
    "CVScheme",
    "CVSchemeType",
    "LossFunction",
    "Nonlinearity",
    "Regularization",
    "Window",
    # estimator ABCs
    "MacrocastEstimator",
    "SequenceEstimator",
    # features
    "FeatureBuilder",
    # results
    "ForecastRecord",
    "ResultSet",
    # Python models
    "KRRModel",
    "SVRRBFModel",
    "SVRLinearModel",
    "RFModel",
    "XGBoostModel",
    "GBModel",
    "NNModel",
    "LSTMModel",
    # R model bridge
    "RModelEstimator",
    "ARModel",
    "ARDIModel",
    "RidgeModel",
    "LassoModel",
    "AdaptiveLassoModel",
    "GroupLassoModel",
    "ElasticNetModel",
    "TVPRidgeModel",
    "BoogingModel",
    "BVARModel",
    # experiment
    "ModelSpec",
    "FeatureSpec",
    "ForecastExperiment",
    # horse race grid
    "HorseRaceGrid",
]
