"""macroforecast.replication — Replication helpers for published papers."""

from macroforecast.replication.clss2021 import CLSS2021, get_preset

__all__ = [
    "CLSS2021",
    "get_preset",
]
