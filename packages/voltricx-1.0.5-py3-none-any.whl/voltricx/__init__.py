"""
Voltricx
~~~~~~~~

A modern, simple, and powerful Lavalink wrapper for discord.py and its derivatives.
Built with performance and ease of use in mind.
"""

__title__ = "Voltricx"
__author__ = "@JustNixx and @Dipendra-creator"
__license__ = "MIT"
__copyright__ = "Copyright 2026-Present (c) @JustNixx and @Dipendra-creator"
__version__ = "1.0.5"

from .typings import *
from .hypercache import HyperCache
from .pool import Pool
from .filters import Filters, Karaoke, Timescale, Tremolo, Vibrato, Rotation, Distortion, ChannelMix, LowPass
from .node import Node
from .player import Player
from .queue import Queue
from .utils import *
from .logger import voltricx_logger
from .exceptions import *
from .typings.track import Playable, Playlist

__all__ = (
    "Node",
    "Pool",
    "Player",
    "Queue",
    "Filters",
    "Karaoke",
    "Timescale",
    "Tremolo",
    "Vibrato",
    "Rotation",
    "Distortion",
    "ChannelMix",
    "LowPass",
    "HyperCache",
    "Playable",
    "Playlist",
    "voltricx_logger",
    "__version__",
    "__title__",
    "__author__",
    "__license__",
    "__copyright__",
)
