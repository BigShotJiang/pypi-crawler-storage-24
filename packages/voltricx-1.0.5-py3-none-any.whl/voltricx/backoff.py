from __future__ import annotations

import random
from typing import Optional


class Backoff:
    """An implementation of an Exponential Backoff.

    Parameters
    ----------
    base: int
        The base time to multiply exponentially. Defaults to 1.
    maximum: float
        The maximum wait time. Defaults to 30.0
    max_tries: Optional[int]
        The amount of times to backoff before resetting. Defaults to 5.
        If set to None, backoff will run indefinitely.
    """

    def __init__(
        self, *, base: int = 1, maximum: float = 30.0, max_tries: int | None = 5
    ) -> None:
        self.base: int = base
        self.maximum: float = maximum
        self.max_tries: int | None = max_tries
        self.retries: int = 1
        self._last_wait: float = 0

    def calculate(self) -> float:
        exponent = min((self.retries**2), self.maximum)
        wait = random.uniform(0, (self.base * 2) * exponent)

        if wait <= self._last_wait:
            wait = self._last_wait * 2

        self._last_wait = wait

        if wait > self.maximum:
            wait = self.maximum
            self.retries = 0
            self._last_wait = 0

        if self.max_tries and self.retries >= self.max_tries:
            self.retries = 0
            self._last_wait = 0

        self.retries += 1

        return wait

    def reset(self) -> None:
        self.retries = 1
        self._last_wait = 0
