
from __future__ import annotations

from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from .typings.node import ErrorResponse
    from .typings.common import TrackException

class VoltricxException(Exception):
    """Base voltricx Exception class."""

RevvLinkException = VoltricxException

class NodeException(VoltricxException):
    """Error raised when an Unknown or Generic error occurs on a Node."""
    def __init__(self, msg: Optional[str] = None, status: Optional[int] = None) -> None:
        super().__init__(msg)
        self.status = status

class LavalinkException(VoltricxException):
    """Exception raised when Lavalink returns an invalid response."""
    def __init__(self, data: ErrorResponse, msg: Optional[str] = None) -> None:
        self.timestamp = data.timestamp
        self.status = data.status
        self.error = data.error
        self.trace = data.trace
        self.path = data.path

        if not msg:
            msg = (
                f"Lavalink API Error: status={self.status}, error={self.error}, path={self.path}"
            )
        super().__init__(msg)

class LavalinkLoadException(VoltricxException):
    """Exception raised when an error occurred loading tracks via Lavalink."""
    def __init__(self, data: TrackException, msg: Optional[str] = None) -> None:
        self.message = data.message
        self.severity = data.severity
        self.cause = data.cause

        if not msg:
            msg = f"Lavalink Load Error: {self.message} (Severity: {self.severity})"
        super().__init__(msg)

class InvalidNodeException(VoltricxException):
    """Exception raised when a Node is invalid or not found."""

class ChannelTimeoutException(VoltricxException):
    """Exception raised when connecting to a voice channel times out."""

class InvalidChannelStateException(VoltricxException):
    """Exception raised when a Player tries to connect to an invalid channel."""

class QueueEmpty(VoltricxException):
    """Exception raised when you try to retrieve from an empty queue."""
