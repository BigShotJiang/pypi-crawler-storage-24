from __future__ import annotations

import asyncio
import logging
from typing import TYPE_CHECKING, Any, Optional, Union, ClassVar, Iterable

import discord

from .hypercache import HyperCache
from .node import Node
from .typings.enums import NodeStatus, LoadType
from .typings.track import Playable, Playlist, Search, TrackException
from .exceptions import InvalidNodeException, LavalinkLoadException
from .logger import voltricx_logger

if TYPE_CHECKING:
    from .typings.common import HyperCacheConfig
    from .typings.node import NodeConfig

logger: logging.Logger = logging.getLogger(__name__)

# High-fidelity region map ported from original logic
REGIONS: dict[str, list[str]] = {
    "asia": ["bom", "maa", "nrt", "hnd", "sin", "kul", "bkk", "cgn", "icn", "hkg", "tpe", "syd", "mel", "akl"],
    "eu": ["ams", "fra", "ber", "lhr", "lon", "cdg", "mad", "bcg", "waw", "mil", "rom", "arn", "hel", "osl", "cph", "prg", "bud", "vie"],
    "us": ["iad", "atl", "mia", "bos", "jfk", "ord", "dfw", "lax", "sea", "sjc", "phx", "den"],
    "southamerica": ["gru", "scl", "eze", "lim", "bog"],
    "africa": ["jnb", "cpt", "nbo"],
    "middleeast": ["dxb", "auh", "ruh", "tel"],
}

class Pool:
    """
    Central manager for Lavalink nodes and global caching.
    
    Provides high-fidelity node selection, region mapping, and track search.
    """
    __nodes: ClassVar[dict[str, Node]] = {}
    __cache: ClassVar[Optional[HyperCache]] = None
    _regions: ClassVar[dict[str, list[str]]] = REGIONS
    _tasks: ClassVar[set[asyncio.Task[Any]]] = set()
    _client: ClassVar[Optional[discord.Client]] = None
    _default_search_source: ClassVar[Optional[str]] = None

    @classmethod
    async def connect(
        cls, 
        *,
        client: discord.Client,
        nodes: Iterable[NodeConfig], 
        cache_config: Optional[Union[dict[str, Any], "HyperCacheConfig"]] = None,
        regions: Optional[dict[str, list[str]]] = None,
        default_search_source: Optional[str] = None
    ) -> dict[str, Node]:
        """
        Connect to multiple Lavalink nodes and initialize global systems.
        """
        if regions:
            cls._regions = regions

        cls._client = client
        cls._default_search_source = default_search_source

        if cache_config:
            cls.__cache = HyperCache.from_config(cache_config)
            if voltricx_logger.enabled:
                voltricx_logger.system("HyperCache system initialized for Pool.")

        coros = []
        for config in nodes:
            node = Node(config=config, client=client)
            coros.append(cls._add_node(node))
        
        await asyncio.gather(*coros)
        
        # Wait up to 5 seconds for all nodes to show as connected
        deadline = asyncio.get_event_loop().time() + 5.0
        while asyncio.get_event_loop().time() < deadline:
            connected_nodes = [n for n in cls.__nodes.values() if n.status == NodeStatus.connected]
            if len(connected_nodes) == len(cls.__nodes):
                break
            await asyncio.sleep(0.5)

        cls._display_report()
        
        return cls.__nodes

    @classmethod
    async def _add_node(cls, node: Node) -> None:
        """Register and connect a Node."""
        if node.identifier in cls.__nodes:
            if voltricx_logger.enabled:
                voltricx_logger.warning(f"Node identifier '{node.identifier}' already in use. Skipping.")
            return
            
        try:
            await node.connect()
            cls.__nodes[node.identifier] = node
        except Exception as e:
            if voltricx_logger.enabled:
                voltricx_logger.error(f"Failed to connect Node {node.identifier}: {e}")

    @classmethod
    def _display_report(cls) -> None:
        """Cosmetic report of node connection statuses."""
        connected = [n for n in cls.__nodes.values() if n.status == NodeStatus.connected]
        total = len(cls.__nodes)
        
        print(f"\n\033[93m[Lavalink]\033[0m Node connection report (\033[92m{len(connected)}\033[0m/\033[93m{total}\033[0m connected)\n")
        for node in cls.__nodes.values():
            color = "\033[92m" if node.status == NodeStatus.connected else "\033[91m"
            status_text = "CONNECTED" if node.status == NodeStatus.connected else "FAILED"
            print(f"  {color}[{status_text}]\033[0m \033[94m{node.identifier:<10}\033[0m {color}{node.uri:<30}\033[0m \033[2mregion=\033[0m\033[36m{node.config.region}\033[0m")
        print("")

    @classmethod
    def get_node(cls, identifier: Optional[str] = None, *, region: Optional[str] = None) -> Node:
        """
        Retrieve a node by identifier or find the healthiest one.
        """
        if identifier:
            if identifier not in cls.__nodes:
                raise InvalidNodeException(f"Node '{identifier}' not found in Pool.")
            return cls.__nodes[identifier]

        connected_nodes = [n for n in cls.__nodes.values() if n.status == NodeStatus.connected]
        if not connected_nodes:
            raise InvalidNodeException("No connected nodes available in Pool.")

        if region:
            region_nodes = [n for n in connected_nodes if n.config.region == region]
            if region_nodes:
                return min(region_nodes, key=lambda n: n.penalty)
            if voltricx_logger.enabled:
                voltricx_logger.debug(f"No nodes found for region '{region}'. Falling back to global selection.")
            
        return min(connected_nodes, key=lambda n: n.penalty)

    @classmethod
    def region_from_endpoint(cls, endpoint: Optional[str]) -> str:
        """Map a Discord voice endpoint string to a region name."""
        if not endpoint:
            return "global"
            
        endpoint = endpoint.lower()
        for region, prefix_list in cls._regions.items():
            for prefix in prefix_list:
                if prefix in endpoint:
                    return region
        return "global"

    @classmethod
    async def fetch_tracks(cls, query: str, *, region: Optional[str] = None, node: Optional[Node] = None) -> Union[list[Playable], Playlist]:
        """Fetch tracks from Lavalink with global cache support."""
        if cls._default_search_source and not (query.startswith("http") or ":" in query):
            if " " in query:
                query = f"{cls._default_search_source}:\"{query}\""
            else:
                query = f"{cls._default_search_source}:{query}"

        # Tier 1: Cache Check
        if cls.__cache:
            cached = cls.__cache.get_query(query)
            if cached:
                return cached

        # Tier 2: Lavalink Request
        connected_nodes = [n for n in cls.__nodes.values() if n.status == NodeStatus.connected]
        if region:
            connected_nodes = [n for n in connected_nodes if n.config.region == region]
        
        if not connected_nodes:
            # Fallback to general selection if a region was specified but no nodes found
            connected_nodes = [n for n in cls.__nodes.values() if n.status == NodeStatus.connected]
            
        if not connected_nodes:
            raise InvalidNodeException("No connected nodes available in Pool.")

        # Sort nodes by penalty to try the healthiest first
        connected_nodes.sort(key=lambda n: n.penalty)
        
        last_exception = None
        result = []

        for target_node in connected_nodes:
            if voltricx_logger.enabled:
                voltricx_logger.debug(f"Attempting track load on node {target_node.identifier} with query: {query}")
            try:
                data = await target_node.load_tracks(query)
                load_type = data.get("loadType")
                result_data = data.get("data", {})
                
                if load_type == LoadType.track:
                    result = [Playable(**result_data)]
                elif load_type == LoadType.playlist:
                    result = Playlist(**result_data)
                elif load_type == LoadType.search:
                    result = [Playable(**t) for t in result_data]
                elif load_type == LoadType.error:
                    if voltricx_logger.enabled:
                        voltricx_logger.warning(f"Node {target_node.identifier} failed track load: {result_data.get('message', 'Unknown error')}")
                    
                    # Instantiate TrackException model before passing to exception class
                    error_payload = TrackException(**result_data)
                    last_exception = LavalinkLoadException(data=error_payload)
                    continue
                else:
                    # empty or unknown
                    continue
                
                if result:
                    if voltricx_logger.enabled:
                        voltricx_logger.info(f"Successfully loaded tracks from node {target_node.identifier}")
                    break
            except Exception as e:
                if voltricx_logger.enabled:
                    voltricx_logger.error(f"Error loading tracks from node {target_node.identifier}: {e}")
                last_exception = e
                continue

        if not result and last_exception:
            raise last_exception
        
        # Tier 3: Cache Population
        if cls.__cache and result:
            cls.__cache.put_query(query, result if isinstance(result, list) else result.tracks)
            
        return result

    @classmethod
    async def _handle_node_failover(cls, node: Node) -> None:
        """Deep port of the original failover logic to migrate players."""
        players = node.players
        if not players:
            return

        healthy_nodes = []
        for _ in range(50):
            healthy_nodes = [n for n in cls.__nodes.values() if n.status == NodeStatus.connected and n != node]
            if healthy_nodes:
                break
            await asyncio.sleep(0.1)

        if not healthy_nodes:
            if voltricx_logger.enabled:
                voltricx_logger.warning(f"Node {node.identifier} failing, but no candidate nodes available for failover.")
            return

        target_node = min(healthy_nodes, key=lambda n: n.penalty)
        if voltricx_logger.enabled:
            voltricx_logger.info(f"Failing over {len(players)} players from {node.identifier} to {target_node.identifier}")

        if cls._client:
            cls._client.dispatch("voltricx_failover", node, target_node, list(players.values()))

        for player in players.values():
            endpoint = player._voice_state.get("endpoint")
            region = cls.region_from_endpoint(endpoint)
            
            region_candidates = [n for n in healthy_nodes if n.config.region == region]
            new_node = min(region_candidates or healthy_nodes, key=lambda n: n.penalty)
            
            if voltricx_logger.enabled:
                voltricx_logger.node(f"Failing over player for guild {player.guild.id} from {node.identifier} to {new_node.identifier}")
            
            try:
                await player.migrate_to(new_node)
            except Exception as e:
                if voltricx_logger.enabled:
                    voltricx_logger.error(f"Failover failed for guild {player.guild.id}: {e}")

    @classmethod
    async def close(cls) -> None:
        """Shutdown all nodes and clear systems."""
        for node in cls.__nodes.copy().values():
            await node.disconnect(force=True)
        cls.__nodes.clear()
        cls.__cache = None

    @classmethod
    def get_cache_stats(cls) -> dict[str, int]:
        """Expose current HyperCache stats if initialized."""
        cache = cls.__cache
        if cache:
            return cache.get_stats()
        return {"l1_queries": 0, "l2_tracks": 0}

    @classmethod
    def get_cache_entries(cls) -> dict[str, list[str]]:
        """Expose current HyperCache entries if initialized."""
        cache = cls.__cache
        if cache:
            return cache.get_entries()
        return {}

    @classmethod
    def get_random_cached_track(cls) -> Optional[Playable]:
        """Retrieve a random track from the global HyperCache L2."""
        if cls.__cache:
            return cls.__cache.get_random_track()
        return None

    @classmethod
    def export_cache_data(cls) -> dict[str, Any]:
        """Export the full state of the HyperCache."""
        if not cls.__cache:
            return {"l1": {}, "l2": {}}
        
        return {
            "l1": cls.__cache.l1._data, # LRU OrderedDict: query -> track_ids
            "l2": {tid: getattr(t, 'title', str(t)) for tid, t in cls.__cache.l2._data.items()} # ID -> Title
        }

    @classmethod
    def nodes(cls) -> dict[str, Node]:
        """Returns a snapshot of current node registry."""
        return cls.__nodes.copy()
