from pydantic import BaseModel, ConfigDict

class LavalinkBaseModel(BaseModel):
    model_config = ConfigDict(populate_by_name=True)
