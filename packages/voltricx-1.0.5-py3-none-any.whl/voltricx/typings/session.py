from __future__ import annotations

from typing import Optional
from pydantic import Field
from .base import LavalinkBaseModel

class Session(LavalinkBaseModel):
    resuming: bool = Field(validation_alias="resumingEnabled")
    timeout: int = Field(validation_alias="timeoutSeconds")

class SessionUpdatePayload(LavalinkBaseModel):
    resuming: Optional[bool] = Field(None, alias="resumingEnabled")
    timeout: Optional[int] = Field(None, alias="timeoutSeconds")
