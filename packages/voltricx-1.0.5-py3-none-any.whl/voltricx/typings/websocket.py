from __future__ import annotations

from typing import Literal, Annotated, Union, Optional
from pydantic import Field
from .base import LavalinkBaseModel
from .player import PlayerState
from .node import MemoryStats, CPUStats, FrameStats
from .events import EventPayload
from .enums import OpCode

class ReadyOp(LavalinkBaseModel):
    op: Literal[OpCode.ready] = OpCode.ready
    resumed: bool
    session_id: str = Field(alias="sessionId")

class PlayerUpdateOp(LavalinkBaseModel):
    op: Literal[OpCode.player_update] = OpCode.player_update
    guild_id: str = Field(alias="guildId")
    state: PlayerState

class StatsOp(LavalinkBaseModel):
    op: Literal[OpCode.stats] = OpCode.stats
    players: int
    playing_players: int = Field(alias="playingPlayers")
    uptime: int
    memory: MemoryStats
    cpu: CPUStats
    frame_stats: Optional[FrameStats] = Field(None, alias="frameStats")

# DAVE Protocol Events-initiates MLS handshake
class DAVEProtocolChangeEvent(LavalinkBaseModel):
    op: Literal["dave"]
    type: Literal["protocolChange"]
    guild_id: str = Field(alias="guildId")
    protocol: str  # "udp" or "kcp"
    encryption_key: str = Field(alias="encryptionKey")

# DAVE prepare transition event - epoch/key rotation
class DAVEPrepareTransitionEvent(LavalinkBaseModel):
    op: Literal["dave"]
    type: Literal["prepareTransition"]
    guild_id: str = Field(alias="guildId")
    epoch: int  # MLS epoch for key rotation
    next_encryption_key: str = Field(alias="nextEncryptionKey")

DavePayload = Annotated[
    Union[DAVEProtocolChangeEvent, DAVEPrepareTransitionEvent],
    Field(discriminator="type")
]

WebSocketPayload = Annotated[
    Union[
        ReadyOp,
        PlayerUpdateOp,
        StatsOp,
        EventPayload,
        DavePayload
    ],
    Field(discriminator="op")
]
