from enum import Enum

class QueueMode(str, Enum):
    normal = "normal"
    loop = "loop"
    loop_all = "loop_all"

class Severity(str, Enum):
    common = "common"
    suspicious = "suspicious"
    fault = "fault"

class OpCode(str, Enum):
    ready = "ready"
    player_update = "playerUpdate"
    stats = "stats"
    event = "event"
    dave = "dave"

class EventType(str, Enum):
    track_start = "TrackStartEvent"
    track_end = "TrackEndEvent"
    track_exception = "TrackExceptionEvent"
    track_stuck = "TrackStuckEvent"
    websocket_closed = "WebSocketClosedEvent"

class TrackEndReason(str, Enum):
    finished = "finished"
    load_failed = "loadFailed"
    stopped = "stopped"
    replaced = "replaced"
    cleanup = "cleanup"

class IPBlockType(str, Enum):
    inet4 = "Inet4Address"
    inet6 = "Inet6Address"

class RoutePlannerClass(str, Enum):
    rotating_ip = "RotatingIpRoutePlanner"
    nano_ip = "NanoIpRoutePlanner"
    rotating_nano_ip = "RotatingNanoIpRoutePlanner"
    balancing_ip = "BalancingIpRoutePlanner"

class LoadType(str, Enum):
    track = "track"
    playlist = "playlist"
    search = "search"
    empty = "empty"
    error = "error"

class NodeStatus(str, Enum):
    connected = "connected"
    connecting = "connecting"
    disconnected = "disconnected"

class AutoPlayMode(str, Enum):
    enabled = "enabled"
    partial = "partial"
    disabled = "disabled"
