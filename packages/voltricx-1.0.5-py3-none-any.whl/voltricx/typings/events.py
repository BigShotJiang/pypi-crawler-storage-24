from __future__ import annotations

from typing import Optional, Literal, Annotated, Union
from pydantic import Field
from .base import LavalinkBaseModel
from .track import Playable
from .common import TrackException
from .enums import EventType, TrackEndReason

class TrackStartEvent(LavalinkBaseModel):
    op: Literal["event"]
    type: Literal[EventType.track_start] = EventType.track_start
    guild_id: str = Field(alias="guildId")
    track: Playable

class TrackEndEvent(LavalinkBaseModel):
    op: Literal["event"]
    type: Literal[EventType.track_end] = EventType.track_end
    guild_id: str = Field(alias="guildId")
    track: Playable
    reason: TrackEndReason

class TrackExceptionEvent(LavalinkBaseModel):
    op: Literal["event"]
    type: Literal[EventType.track_exception] = EventType.track_exception
    guild_id: str = Field(alias="guildId")
    track: Playable
    exception: TrackException

class TrackStuckEvent(LavalinkBaseModel):
    op: Literal["event"]
    type: Literal[EventType.track_stuck] = EventType.track_stuck
    guild_id: str = Field(alias="guildId")
    track: Playable
    threshold_ms: int = Field(alias="thresholdMs")

class WebSocketClosedEvent(LavalinkBaseModel):
    op: Literal["event"]
    type: Literal[EventType.websocket_closed] = EventType.websocket_closed
    guild_id: str = Field(alias="guildId")
    code: int
    reason: str
    by_remote: bool = Field(alias="byRemote")

EventPayload = Annotated[
    Union[
        TrackStartEvent, 
        TrackEndEvent, 
        TrackExceptionEvent, 
        TrackStuckEvent, 
        WebSocketClosedEvent
    ],
    Field(discriminator="type")
]
