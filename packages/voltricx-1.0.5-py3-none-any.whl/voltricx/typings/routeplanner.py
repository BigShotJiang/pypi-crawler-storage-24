from typing import Optional, Literal
from pydantic import Field
from .base import LavalinkBaseModel
from .enums import IPBlockType, RoutePlannerClass

class IPBlock(LavalinkBaseModel):
    type: IPBlockType
    size: str

class FailingAddress(LavalinkBaseModel):
    failing_address: str = Field(alias="failingAddress")
    failing_timestamp: int = Field(alias="failingTimestamp")
    failing_time: str = Field(alias="failingTime")

class RoutePlannerDetails(LavalinkBaseModel):
    ip_block: IPBlock = Field(alias="ipBlock")
    failing_addresses: list[FailingAddress] = Field(alias="failingAddresses")
    rotate_index: Optional[str] = Field(None, alias="rotateIndex")
    ip_index: Optional[str] = Field(None, alias="ipIndex")
    current_address: Optional[str] = Field(None, alias="currentAddress")
    current_address_index: Optional[str] = Field(None, alias="currentAddressIndex")
    block_index: Optional[str] = Field(None, alias="blockIndex")

class RoutePlannerStatus(LavalinkBaseModel):
    planner_class: Optional[RoutePlannerClass] = Field(None, alias="class")
    details: Optional[RoutePlannerDetails] = None

class RoutePlannerFreeAddressPayload(LavalinkBaseModel):
    address: str
