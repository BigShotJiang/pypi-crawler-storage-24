from typing import Optional, Any
from pydantic import Field
from .base import LavalinkBaseModel

class Equalizer(LavalinkBaseModel):
    band: int
    gain: float

# EqualizerFilter model is replaced by a direct list in Filters

class Karaoke(LavalinkBaseModel):
    level: float = 1.0
    mono_level: float = Field(1.0, alias="monoLevel")
    filter_band: float = Field(220.0, alias="filterBand")
    filter_width: float = Field(100.0, alias="filterWidth")

class Timescale(LavalinkBaseModel):
    speed: float = 1.0
    pitch: float = 1.0
    rate: float = 1.0

class Tremolo(LavalinkBaseModel):
    frequency: float = 2.0
    depth: float = 0.5

class Vibrato(LavalinkBaseModel):
    frequency: float = 2.0
    depth: float = 0.5

class Rotation(LavalinkBaseModel):
    rotation_hz: float = Field(0.0, alias="rotationHz")

class Distortion(LavalinkBaseModel):
    sin_offset: float = Field(0.0, alias="sinOffset")
    sin_scale: float = Field(1.0, alias="sinScale")
    cos_offset: float = Field(0.0, alias="cosOffset")
    cos_scale: float = Field(1.0, alias="cosScale")
    tan_offset: float = Field(0.0, alias="tanOffset")
    tan_scale: float = Field(1.0, alias="tanScale")
    offset: float = 0.0
    scale: float = 1.0

class ChannelMix(LavalinkBaseModel):
    left_to_left: float = Field(1.0, alias="leftToLeft")
    left_to_right: float = Field(0.0, alias="leftToRight")
    right_to_left: float = Field(0.0, alias="rightToLeft")
    right_to_right: float = Field(1.0, alias="rightToRight")

class LowPass(LavalinkBaseModel):
    smoothing: float = 20.0

class Filters(LavalinkBaseModel):
    volume: float = 1.0
    equalizer: list[Equalizer] = Field(default_factory=list)
    karaoke: Karaoke = Field(default_factory=Karaoke)
    timescale: Timescale = Field(default_factory=Timescale)
    tremolo: Tremolo = Field(default_factory=Tremolo)
    vibrato: Vibrato = Field(default_factory=Vibrato)
    rotation: Rotation = Field(default_factory=Rotation)
    distortion: Distortion = Field(default_factory=Distortion)
    channel_mix: ChannelMix = Field(default_factory=ChannelMix, alias="channelMix")
    low_pass: LowPass = Field(default_factory=LowPass, alias="lowPass")
    plugin_filters: dict[str, Any] = Field(default_factory=dict, alias="pluginFilters")
