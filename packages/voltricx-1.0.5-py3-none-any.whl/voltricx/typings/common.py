from __future__ import annotations

from typing import Optional, Any, Union
from pydantic import Field
from .base import LavalinkBaseModel
from .enums import Severity, QueueMode

class TrackException(LavalinkBaseModel):
    message: Optional[str] = None
    severity: Severity
    cause: str
    cause_stack_trace: str = Field(alias="causeStackTrace")

class DiscordVoiceStateUpdateData(LavalinkBaseModel):
    guild_id: str = Field(alias="guild_id")
    channel_id: Optional[str] = Field(None, alias="channel_id")
    self_mute: bool = Field(alias="self_mute")
    self_deaf: bool = Field(alias="self_deaf")

class DiscordVoiceStateUpdate(LavalinkBaseModel):
    op: int = Field(4, alias="op")
    d: DiscordVoiceStateUpdateData

class HyperCacheConfig(LavalinkBaseModel):
    capacity: int = 100
    track_capacity: int = 1000
    decay_factor: float = 0.5
    decay_threshold: int = 1000

class QueueConfig(LavalinkBaseModel):
    max_history_size: int = 100
    atomic_default: bool = True
