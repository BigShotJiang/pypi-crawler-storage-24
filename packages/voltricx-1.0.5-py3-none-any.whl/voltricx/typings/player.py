from typing import Optional, Any
from pydantic import Field
from .base import LavalinkBaseModel
from .track import Playable
from .filters import Filters

class VoiceState(LavalinkBaseModel):
    token: str
    endpoint: str
    session_id: str = Field(alias="sessionId")
    channel_id: Optional[str] = Field(None, alias="channelId")

class PlayerState(LavalinkBaseModel):
    time: int
    position: int
    connected: bool
    ping: int

class Player(LavalinkBaseModel):
    guild_id: str = Field(alias="guildId")
    track: Optional[Playable] = None
    volume: int
    paused: bool
    state: PlayerState
    voice: VoiceState
    filters: Filters
    seamless_play: Optional[bool] = Field(None, alias="seamlessPlay")

class UpdatePlayerTrack(LavalinkBaseModel):
    encoded: Optional[str] = None
    identifier: Optional[str] = None
    user_data: dict[str, Any] = Field(default_factory=dict, alias="userData")

class UpdatePlayerPayload(LavalinkBaseModel):
    track: Optional[UpdatePlayerTrack] = None
    position: Optional[int] = None
    end_time: Optional[int] = Field(None, alias="endTime")
    volume: Optional[int] = None
    paused: Optional[bool] = None
    filters: Optional[dict[str, Any]] = None
    voice: Optional[VoiceState] = None
