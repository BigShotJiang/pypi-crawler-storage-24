from typing import Optional, Any
from pydantic import Field
from .base import LavalinkBaseModel

class NodeConfig(LavalinkBaseModel):
    identifier: str
    uri: str
    password: str
    region: Optional[str] = "global"
    heartbeat: float = 15.0
    retries: Optional[int] = None
    resume_timeout: int = 60
    inactive_player_timeout: Optional[int] = 300
    inactive_channel_tokens: Optional[int] = 3

class Version(LavalinkBaseModel):
    semver: str
    major: int
    minor: int
    patch: int
    pre_release: Optional[str] = Field(None, alias="preRelease")
    build: Optional[str] = None

class Git(LavalinkBaseModel):
    branch: str
    commit: str
    commit_time: int = Field(alias="commitTime")

class Plugin(LavalinkBaseModel):
    name: str
    version: str

class NodeInfo(LavalinkBaseModel):
    version: Version
    build_time: int = Field(alias="buildTime")
    git: Git
    jvm: str
    lavaplayer: str
    source_managers: list[str] = Field(alias="sourceManagers")
    filters: list[str]
    plugins: list[Plugin]

class MemoryStats(LavalinkBaseModel):
    free: int
    used: int
    allocated: int
    reservable: int

class CPUStats(LavalinkBaseModel):
    cores: int
    system_load: float = Field(alias="systemLoad")
    lavalink_load: float = Field(alias="lavalinkLoad")

class FrameStats(LavalinkBaseModel):
    sent: int
    nulled: int
    deficit: int

class NodeHeaders(LavalinkBaseModel):
    authorization: str = Field(alias="Authorization")
    user_id: str = Field(alias="User-Id")
    client_name: str = Field(alias="Client-Name")
    session_id: Optional[str] = Field(None, alias="Session-Id")

class ErrorResponse(LavalinkBaseModel):
    timestamp: int
    status: int
    error: str
    trace: Optional[str] = None
    message: str
    path: str
