import argparse
import platform
import subprocess
import sys

import voltricx

parser = argparse.ArgumentParser(prog="voltricx")
parser.add_argument(
    "--version", action="store_true", help="Get version and debug information for voltricx."
)

args = parser.parse_args()

def get_debug_info() -> None:
    python_info = "\n".join(sys.version.split("\n"))
    
    try:
        java_version_output = subprocess.check_output(["java", "-version"], stderr=subprocess.STDOUT)
        java_version = f"\n{' ' * 8}- ".join(v for v in java_version_output.decode().split("\r\n") if v)
    except Exception:
        java_version = "Version Not Found"

    info: str = f"""
    voltricx: {voltricx.__version__}

    Python:
        - {python_info}
    System:
        - {platform.platform()}
    Java:
        - {java_version}
    """

    print(info)

if args.version:
    get_debug_info()
