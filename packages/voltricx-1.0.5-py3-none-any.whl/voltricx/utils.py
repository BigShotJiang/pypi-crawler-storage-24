from __future__ import annotations

from types import SimpleNamespace
from typing import TYPE_CHECKING, Any, Iterator, Optional, Union

if TYPE_CHECKING:
    import discord

__all__ = (
    "ExtrasNamespace",
    "Namespace",
    "build_basic_layout",
)

class Namespace(SimpleNamespace):
    """
    An iterable subclass of SimpleNamespace.
    """
    def __iter__(self) -> Iterator[tuple[str, Any]]:
        return iter(self.__dict__.items())

class ExtrasNamespace(Namespace):
    """
    A subclass of Namespace for handling arbitrary track or playlist data.
    
    Supports initialization from a dictionary and/or keyword arguments.
    Ported with high fidelity from the original codebase.
    """
    def __init__(self, _dict: dict[str, Any] = {}, /, **kwargs: Any) -> None:
        updated = _dict | kwargs
        super().__init__(**updated)

def build_basic_layout(
    description: str,
    title: Optional[str] = None,
    image_url: Optional[str] = None,
    accent_color: Optional[discord.Color] = None,
) -> Any:
    """
    Builds a basic LayoutView container for Discord UI responses.
    
    This helper is used throughout the Player and other components for 
    sending standardized UI messages.
    """
    import discord

    # Note: These components are assumed to be part of the discord.py 
    # environment or specific UI extensions used by Voltricx.
    view = discord.ui.LayoutView()
    items = []

    if title:
        items.append(discord.ui.TextDisplay(content=f"## {title}"))

    items.append(discord.ui.TextDisplay(content=description))

    if accent_color:
        container = discord.ui.Container(*items, accent_color=accent_color)
    else:
        container = discord.ui.Container(*items)

    if image_url:
        section = discord.ui.Section(
            title if title else "",
            description if not title else "",
            accessory=discord.ui.Thumbnail(image_url),
        )
        if not title and items:
            items.pop()
        view.add_item(section)

    view.add_item(container)
    return view
