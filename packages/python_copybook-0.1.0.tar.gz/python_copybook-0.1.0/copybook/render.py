"""COBOL copybook renderers.

This module converts CobolNode trees back into COBOL copybook strings.
It is intentionally separate from tree.py (which builds trees) and
parser.py (which reads them) — rendering is a distinct concern.

Renderers
---------
    render_copybook(roots, indent_size)
        Renders a full tree back to a COBOL copybook string. Depth-based
        indentation is applied so hierarchy is visually clear. Level numbers
        and field name casing are preserved from the source.

    render_flat_copybook(nodes, record_name)
        Renders a flat list of nodes (typically from build_flat_tree()) as
        a single-level copybook with all fields at level 05 under one 01 record.

Indentation model
-----------------
    Fixed-format COBOL has two meaningful indent positions:

        Area A — column 8  (7 leading spaces)  — for 01 / 77 level fields
        Area B — column 12 (11 leading spaces) — for all subordinate fields

    Within Area B, render_copybook adds optional depth-based indent so that
    nested fields are visually offset from their parents. This is cosmetic —
    level numbers carry the actual structure — but makes the output readable.

    The indent_size parameter controls how many extra spaces are added per
    depth level beyond the root. Defaults to 4. Set to 0 for flat output
    where all non-root fields align at Area B.

    Continuation lines (statements that span multiple physical lines) always
    use CONTINUATION_INDENT regardless of depth, to distinguish them from
    new field declarations.
"""

from __future__ import annotations

import re

from copybook.models import CobolNode
from copybook.patterns import AREA_A_INDENT, AREA_B_INDENT, CONTINUATION_INDENT


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _indent_for_depth(depth: int, indent_size: int) -> str:
    """Compute the indent string for a given tree depth.

    Root fields (depth 0) always use Area A indent. All other fields
    use Area B indent plus additional spaces per depth level.

    Args:
        depth: Tree depth of the current node. 0 = root (01/77 level).
        indent_size: Number of extra spaces to add per depth level
            beyond the root. 0 produces flat Area B alignment.

    Returns:
        The full indent string to prepend to the field's declaration line.
    """
    if depth == 0:
        return AREA_A_INDENT
    return AREA_B_INDENT + (" " * indent_size * (depth - 1))


def _render_node_lines(
    node: CobolNode,
    depth: int = 0,
    indent_size: int = 4,
) -> list[str]:
    """Render a single node's declaration as one or more output lines.

    Uses the original CobolLine objects from the field's statement to
    reconstruct the declaration text verbatim, with only the leading
    indent adjusted for depth.

    Single-line statements produce one output line. Multi-line statements
    (e.g. a REDEFINES clause that wrapped across two physical lines) produce
    one line per source line, with continuation lines at CONTINUATION_INDENT
    so they are visually distinct from new field declarations.

    Args:
        node: The CobolNode to render.
        depth: Tree depth of this node. 0 = root (01/77). Controls indent.
        indent_size: Extra spaces per depth level beyond root. Defaults to 4.

    Returns:
        A list of strings, one per output line for this node's declaration.
    """
    source_lines = node.cobol_field.statement.source_lines
    indent = _indent_for_depth(depth, indent_size)
    output = []

    output.append(f"{indent}{source_lines[0].area.strip()}")
    for continuation in source_lines[1:]:
        output.append(f"{CONTINUATION_INDENT}{continuation.area.strip()}")

    return output


# ---------------------------------------------------------------------------
# Public renderers
# ---------------------------------------------------------------------------


def render_copybook(
    roots: list[CobolNode],
    indent_size: int = 4,
) -> str:
    """Render a full COBOL copybook string from a tree of CobolNodes.

    Walks the tree in source order and reconstructs each field's declaration
    using the original statement area text. Level numbers and field name
    casing are preserved exactly as parsed from the source copybook.

    Depth-based indentation is applied within Area B so that child fields
    are visually offset from their parents. This is cosmetic — the level
    numbers carry the actual hierarchy — but makes the output readable.

    Multi-line statements are rendered with continuation lines at
    CONTINUATION_INDENT, regardless of depth.

    Args:
        roots: Root-level CobolNode objects from build_tree().
        indent_size: Number of extra spaces to add per depth level beyond
            the root. Defaults to 4. Set to 0 for flat Area B alignment.

    Returns:
        A string containing a valid fixed-format COBOL copybook definition
        with lines joined by newlines.

    Example (indent_size=4):
        '       01  Claim-Record.'
        '           12 Insured-Details.'
        '               15 Insured-Policy-No PIC 9(07).'
        '               15 Insured-Last-Name PIC X(15).'
        '           12 Policy-Details.'
        '               15 Policy-Type PIC 9.'
        '                   88 Private VALUE 1.'
    """
    output_lines: list[str] = []

    def _walk(node: CobolNode, depth: int) -> None:
        output_lines.extend(
            _render_node_lines(node, depth=depth, indent_size=indent_size)
        )
        for child in node.children:
            _walk(child, depth + 1)

    for root in roots:
        _walk(root, depth=0)

    return "\n".join(output_lines)


def _remap_level(area: str, new_level: int = 5) -> str:
    """Replace the leading level number in a statement area string.

    Used when rendering a flat copybook where all fields are remapped to
    level 05 regardless of their original level number.

    Args:
        area: Statement area text starting with a level number.
            e.g. '15 POLICY-TYPE PIC 9.'
        new_level: The level number to substitute in. Defaults to 5,
            which renders as '05'.

    Returns:
        Area string with the leading level number replaced.
            e.g. '05 POLICY-TYPE PIC 9.'
    """
    return re.sub(r"^\d+", f"{new_level:02}", area.strip())


def render_flat_copybook(
    nodes: list[CobolNode],
    record_name: str = "FLAT-RECORD",
) -> str:
    """Render a flat COBOL copybook with all fields at level 05.

    Intended for use with the output of build_flat_tree(), which produces
    a non-overlapping linear list of elementary fields. All fields are
    remapped to level 05 under a single 01 record header.

    The original area text from each field's source lines is used verbatim
    with only the level number remapped, so spacing, clause ordering, and
    field name casing are preserved from the source copybook.

    Multi-line statements are rendered with continuation lines at
    CONTINUATION_INDENT.

    Args:
        nodes: List of CobolNode objects, typically from build_flat_tree().
            Can also accept output from build_tree() if REDEFINES fields
            should be included in the flat output.
        record_name: Name for the generated 01 record header.

    Returns:
        A string containing a flat COBOL copybook definition with lines
        joined by newlines.

    Example output:
        '       01  FLAT-CLAIMREC.'
        '           05 INSURED-POLICY-NO        PIC 9(07).'
        '           05 INSURED-LAST-NAME        PIC X(15).'
    """
    output_lines = [f"{AREA_A_INDENT}01  {record_name}."]

    for node in nodes:
        source_lines = node.cobol_field.statement.source_lines
        first = _remap_level(source_lines[0].area.strip())
        output_lines.append(f"{AREA_B_INDENT}{first}")
        for continuation in source_lines[1:]:
            output_lines.append(f"{CONTINUATION_INDENT}{continuation.area.strip()}")

    return "\n".join(output_lines)
