"""COBOL copybook tree builders and copybook renderers.

This module provides two tree views over a flat list of CobolField objects,
and two copybook rendering functions that produce COBOL output from those trees.

Tree builders
-------------
    build_tree(fields)
        Full hierarchy — mirrors the source copybook structure exactly.
        Includes group fields, elementary fields, level-88 condition names,
        and REDEFINES fields. Use when you need the complete picture.

    build_flat_tree(fields)
        Elementary fields only — no groups, no level-88s, no REDEFINES.
        All nodes are unlinked (no parent or children).
        Use for offset calculation or any non-overlapping linear record view.

Renderers
---------
    render_copybook(roots)
        Renders a full tree back to a COBOL copybook string, preserving
        original level numbers and field name casing.

    render_flat_copybook(roots, record_name)
        Renders a flat tree as a single-level copybook with all fields at
        level 05 under a new 01 record.
"""

from __future__ import annotations

import re

from copybook.models import CobolField, CobolNode
from copybook.patterns import AREA_A_INDENT, AREA_B_INDENT, CONTINUATION_INDENT


# ---------------------------------------------------------------------------
# Tree builders
# ---------------------------------------------------------------------------


def build_tree(fields: list[CobolField]) -> list[CobolNode]:
    """Build a full hierarchy tree from a flat list of CobolFields.

    Walks the flat field list in source order. Uses a stack to track the
    current path from the root — when a field with a lower level number
    is encountered, the stack is popped back to the nearest ancestor.

    Includes all field types: groups, elementary fields, level-88 condition
    names, and REDEFINES fields. The tree mirrors the source copybook exactly.

    Args:
        fields: Flat list of CobolField objects in source order, as returned
            by parse_fields().

    Returns:
        List of root-level CobolNode objects (level 01 or 77). All other
        nodes are reachable via .children on each node.
    """
    roots: list[CobolNode] = []
    stack: list[CobolNode] = []

    for f in fields:
        node = CobolNode(cobol_field=f)

        # Pop ancestors at the same or deeper level — they are closed
        while stack and stack[-1].level >= f.level:
            stack.pop()

        if stack:
            node.parent = stack[-1]
            stack[-1].children.append(node)
        else:
            node.parent = None
            roots.append(node)

        stack.append(node)

    return roots


def build_flat_tree(fields: list[CobolField]) -> list[CobolNode]:
    """Build a flat list of nodes containing only elementary non-overlapping fields.

    Builds a full tree internally, then walks it to collect only the fields
    that represent actual storage — excluding:
        - Group fields (no PIC clause — storage is defined by their children)
        - Level-88 condition names (no storage, named boolean conditions only)
        - REDEFINES fields and all their descendants (overlapping storage)

    All returned nodes are unlinked: parent is None and children is empty.
    This produces a simple linear sequence suitable for byte offset calculation
    or any use case requiring a non-overlapping view of the record.

    Args:
        fields: Flat list of CobolField objects in source order from parse_fields().

    Returns:
        List of unlinked CobolNode objects in source order, one per elementary
        non-overlapping field.
    """
    full_tree = build_tree(fields)
    result: list[CobolNode] = []

    def _walk(node: CobolNode, in_redefine: bool = False) -> None:
        """Recursively collect elementary non-redefining fields.

        Args:
            node: Current node being visited.
            in_redefine: True if any ancestor of this node has a REDEFINES
                clause. Propagated downward so entire subtrees under a
                REDEFINES field are excluded.
        """
        if node.cobol_field.is_condition:
            return

        currently_redefining = in_redefine or node.cobol_field.is_redefine

        if not node.cobol_field.is_group and not currently_redefining:
            # Unlinked node — no parent or children in the flat view
            result.append(CobolNode(cobol_field=node.cobol_field))

        for child in node.children:
            _walk(child, currently_redefining)

    for root in full_tree:
        _walk(root)

    return result


# ---------------------------------------------------------------------------
# Renderers
# ---------------------------------------------------------------------------


def _render_node_lines(node: CobolNode, is_root: bool = False) -> list[str]:
    """Render a single node's declaration as one or more output lines.

    Uses the original CobolLine objects from the field's statement to
    reconstruct the declaration text. The first line uses the appropriate
    indent for its position in the output (Area A for root fields, Area B
    for all others). Continuation lines use a deeper indent so they are
    visually distinct from new field declarations.

    Args:
        node: The CobolNode to render.
        is_root: True if this node is a root-level field (level 01 or 77).
            Root fields are rendered at Area A indent; all others at Area B.

    Returns:
        A list of strings, one per output line for this declaration.
    """
    source_lines = node.cobol_field.statement.source_lines
    first_indent = AREA_A_INDENT if is_root else AREA_B_INDENT
    output = []

    if len(source_lines) == 1:
        output.append(f"{first_indent}{source_lines[0].area.strip()}")
    else:
        output.append(f"{first_indent}{source_lines[0].area.strip()}")
        for continuation in source_lines[1:]:
            output.append(f"{CONTINUATION_INDENT}{continuation.area.strip()}")

    return output


def render_copybook(roots: list[CobolNode]) -> str:
    """Render a full COBOL copybook string from a tree of CobolNodes.

    Walks the tree in source order and reconstructs each field's declaration
    using the original statement area text. Preserves the original level
    numbers, field name casing, clause ordering, and inter-field spacing
    exactly as they appeared in the source copybook.

    Multi-line statements (e.g. REDEFINES that wrapped across two physical
    lines) are rendered with continuation lines at CONTINUATION_INDENT so
    they are visually distinct from new field declarations.

    Args:
        roots: Root-level CobolNode objects from build_tree().

    Returns:
        A string containing a valid fixed-format COBOL copybook definition
        with lines joined by newlines.
    """
    output_lines: list[str] = []

    def _walk(node: CobolNode, is_root: bool = False) -> None:
        output_lines.extend(_render_node_lines(node, is_root=is_root))
        for child in node.children:
            _walk(child, is_root=False)

    for root in roots:
        _walk(root, is_root=True)

    return "\n".join(output_lines)


def _remap_level(area: str, new_level: int = 5) -> str:
    """Replace the leading level number in a statement area string.

    Used when rendering a flat copybook where all fields are remapped to
    level 05 regardless of their original level.

    Args:
        area: Statement area text starting with a level number.
            e.g. '15 POLICY-TYPE PIC 9.'
        new_level: The level number to substitute in. Defaults to 5,
            which renders as '05'.

    Returns:
        Area string with the leading level number replaced.
            e.g. '05 POLICY-TYPE PIC 9.'
    """
    return re.sub(r"^\d+", f"{new_level:02}", area.strip())


def render_flat_copybook(
    nodes: list[CobolNode],
    record_name: str = "FLAT-RECORD",
) -> str:
    """Render a flat COBOL copybook with all fields at level 05.

    Intended for use with the output of build_flat_tree(), which produces
    a non-overlapping linear list of elementary fields. All fields are
    remapped to level 05 under a single 01 record header.

    The original area text from each field's source lines is used verbatim
    (with only the level number remapped), so spacing, clause ordering, and
    field name casing are preserved from the source copybook.

    Args:
        nodes: List of CobolNode objects, typically from build_flat_tree().
        record_name: Name for the generated 01 record header.

    Returns:
        A string containing a flat COBOL copybook definition with lines
        joined by newlines.

    Example output:
        '       01  FLAT-CLAIMREC.
        '           05 INSURED-POLICY-NO        PIC 9(07).
        '           05 POLICY-BENEFIT-DATE-X REDEFINES
        '                  POLICY-BENEFIT-DATE-NUM PIC X(08).
    """
    output_lines = [f"{AREA_A_INDENT}01  {record_name}."]

    for node in nodes:
        source_lines = node.cobol_field.statement.source_lines

        if len(source_lines) == 1:
            remapped = _remap_level(source_lines[0].area.strip())
            output_lines.append(f"{AREA_B_INDENT}{remapped}")
        else:
            first = _remap_level(source_lines[0].area.strip())
            output_lines.append(f"{AREA_B_INDENT}{first}")
            for continuation in source_lines[1:]:
                output_lines.append(f"{CONTINUATION_INDENT}{continuation.area.strip()}")

    return "\n".join(output_lines)
