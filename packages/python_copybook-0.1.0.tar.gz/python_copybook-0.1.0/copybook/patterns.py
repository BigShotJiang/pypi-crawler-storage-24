"""COBOL copybook regex patterns, layout constants, and reserved words.

This module is the single source of truth for:

    - Regex patterns used to parse COBOL data field clauses
    - Fixed-format column layout constants for rendering output
    - The COBOL reserved word set used to annotate statements

All patterns use re.IGNORECASE so callers never need to normalise case
before searching. Each pattern captures exactly one logical value — none
of the patterns here are monolithic or order-dependent.

Design note:
    Clause patterns (PIC_RE, REDEFINES_RE, etc.) are applied as independent
    re.search() calls on the remainder of a statement, not as a single
    combined pattern. This means clause order in the source never matters.
"""

import re
from pathlib import Path

RESERVED_WORDS_TXT = Path(
    "/Users/soho/repositories/python-copybook/copybook/reserved_words.txt"
)

# ---------------------------------------------------------------------------
# Fixed-format column layout constants
# ---------------------------------------------------------------------------

# Column 8 is the start of Area A in fixed-format COBOL (0-indexed col 7).
# Level 01 and 77 entries must start in Area A.
AREA_A_INDENT = " " * 7

# Column 12 is the start of Area B in fixed-format COBOL (0-indexed col 11).
# All subordinate entries (05, 10, etc.) and statements start in Area B.
AREA_B_INDENT = " " * 11

# Continuation lines in rendered output are indented past the field name
# to make it visually clear they are part of the previous declaration.
CONTINUATION_INDENT = " " * 18

# ---------------------------------------------------------------------------
# Statement prefix — level number and field name
# ---------------------------------------------------------------------------

# Matches the fixed opening of any data definition: a level number followed
# by the field name. The colon (:) is included in the name character class
# to support copybook templates that use :tag: style replacement tokens
# e.g. '15 :CDT:-Full-Date PIC 9(8).'.
PREFIX_RE = re.compile(
    r"^(\d+)\s+"  # level number — one or more digits
    r"([\w:-]+)",  # field name — word chars, hyphens, colons
    re.IGNORECASE,
)

# ---------------------------------------------------------------------------
# Clause patterns — each captures exactly one value
# ---------------------------------------------------------------------------

# PIC / PICTURE clause — the data type descriptor.
# Matches: PIC X(10), PICTURE S9(7)V99, PIC Z(9).99, PIC $,$$9.99
# Character class covers all standard COBOL PIC symbols:
#   9 X S V A Z B — type/sign/decimal symbols
#   ( )           — repetition counts e.g. 9(07)
#   / + - $ , .   — editing symbols for display formatting
#   *             — zero-suppression symbol
PIC_RE = re.compile(
    r"(?:PIC|PICTURE)\s+([\w9XSVAZB()/+\-$,.*]+)",
    re.IGNORECASE,
)

# REDEFINES clause — this field overlays the storage of another field.
# Captures the target field name e.g. 'REDEFINES Policy-Benefit-Date-Num'
# → 'Policy-Benefit-Date-Num'. Colon included for :tag: tokens.
REDEFINES_RE = re.compile(
    r"REDEFINES\s+([\w:-]+)",
    re.IGNORECASE,
)

# RENAMES clause — level 66 only. Creates an alternative name for a range
# of fields. Captures the first field name in the range.
RENAMES_RE = re.compile(
    r"RENAMES\s+([\w:-]+)",
    re.IGNORECASE,
)

# RENAMES THRU/THROUGH — captures the last field name in a RENAMES range.
# Must be searched separately from RENAMES_RE to get the end of the range.
RENAMES_THRU_RE = re.compile(
    r"RENAMES\s+[\w:-]+\s+(?:THRU|THROUGH)\s+([\w:-]+)",
    re.IGNORECASE,
)

# USAGE clause — specifies the internal storage format of the field.
# The USAGE keyword itself is optional in COBOL (e.g. 'COMP-3.' is valid
# without writing 'USAGE COMP-3.'). The (?:USAGE\s+)? handles both forms.
# Supported values:
#   COMP / COMP-1 / COMP-2 / COMP-3 / COMP-4 / COMP-5 / COMP-X
#   COMPUTATIONAL / COMPUTATIONAL-1 ... COMPUTATIONAL-X (long-form aliases)
#   PACKED-DECIMAL (alias for COMP-3)
#   BINARY         (alias for COMP-4 on many platforms)
#   DISPLAY        (the default — human-readable character storage)
USAGE_RE = re.compile(
    r"(?:USAGE\s+)?"
    r"(COMP-[0-9X]|COMPUTATIONAL(?:-[0-9X])?|PACKED-DECIMAL|BINARY|DISPLAY)",
    re.IGNORECASE,
)

# OCCURS clause — defines an array. Captures minimum (fixed) size and
# optional maximum size for variable-length arrays.
# Matches: OCCURS 10 TIMES, OCCURS 1 TO 10 TIMES
OCCURS_RE = re.compile(
    r"OCCURS\s+(\d+)(?:\s+TO\s+(\d+))?\s+TIMES",
    re.IGNORECASE,
)

# DEPENDING ON clause — names the field that holds the current array size
# at runtime. Only present on variable-length OCCURS arrays.
DEPENDING_RE = re.compile(
    r"DEPENDING\s+ON\s+([\w:-]+)",
    re.IGNORECASE,
)

# INDEXED BY clause — names the internal index used to subscript an OCCURS
# table. The index is not a regular data field; it has its own storage.
INDEXED_BY_RE = re.compile(
    r"INDEXED\s+BY\s+([\w:-]+)",
    re.IGNORECASE,
)

# VALUE / VALUES clause — initial value or condition values (level 88).
# Handles three value formats:
#   '[^']*'    — single-quoted string literal e.g. 'HELLO'
#   "[^"]*"    — double-quoted string literal e.g. "HELLO"
#   [^\s.][^.]*— unquoted value e.g. 1, ZEROS, 1 THRU 12, 'A' 'B' 'C'
# The VALUES ARE form (level 88 multiple values) is also matched by
# the optional ARE keyword.
VALUE_RE = re.compile(
    r"VALUES?\s+(?:ARE\s+)?('[^']*'|\"[^\"]*\"|[^\s.][^.]*)",
    re.IGNORECASE,
)


# ---------------------------------------------------------------------------
# Reserved words
# ---------------------------------------------------------------------------


def load_reserved_words() -> frozenset[str]:
    """Load the COBOL reserved word list from a text file.

    The file is expected to contain one reserved word per line, optionally
    followed by a bracketed qualifier e.g. 'BINARY-CHAR [200X]'. Qualifiers
    and blank lines are ignored. Words are returned uppercased.

    If no path is provided, the default reserved_words.txt file bundled
    alongside this module is used.

    Args:
        path: Optional path to an alternative reserved words file.

    Returns:
        A frozenset of uppercased COBOL reserved word strings.
    """

    words = set()
    with open(RESERVED_WORDS_TXT, "r") as f:
        for line in f:
            word = line.strip().split()[0] if line.strip() else None
            if word and not word.startswith("#"):
                words.add(word.upper())
    return frozenset(words)


RESERVED_WORDS: frozenset[str] = load_reserved_words()
