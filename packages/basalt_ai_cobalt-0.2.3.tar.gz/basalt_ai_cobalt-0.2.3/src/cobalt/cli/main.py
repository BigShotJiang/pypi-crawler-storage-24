"""Cobalt CLI — entry point for `cobalt` command."""

from __future__ import annotations

import asyncio
import glob
import importlib.util
import sys
import warnings
import webbrowser
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

app = typer.Typer(
    name="cobalt",
    help="Unit testing for AI Agents 🧪",
    add_completion=False,
)
console = Console()


def _run_async_experiment(main_fn):
    """Run an async experiment main(), suppressing noisy asyncio cleanup errors.

    asyncio.run() closes the event loop after completion, which causes pending
    httpx/aiohttp cleanup tasks to raise 'Event loop is closed' RuntimeErrors.
    These are harmless but pollute CI logs. We install a custom exception
    handler to silence them.
    """
    loop = asyncio.new_event_loop()

    def _quiet_exception_handler(loop, context):
        exc = context.get("exception")
        if isinstance(exc, RuntimeError) and "Event loop is closed" in str(exc):
            return
        # For any other exception, use the default handler.
        loop.default_exception_handler(context)

    loop.set_exception_handler(_quiet_exception_handler)
    try:
        return loop.run_until_complete(main_fn())
    finally:
        # Shut down async generators and executor, then close — mirroring asyncio.run().
        try:
            _cancel_all_tasks(loop)
            loop.run_until_complete(loop.shutdown_asyncgens())
            loop.run_until_complete(loop.shutdown_default_executor())
        finally:
            loop.close()


def _cancel_all_tasks(loop):
    """Cancel and gather all pending tasks on the loop."""
    to_cancel = asyncio.all_tasks(loop)
    if not to_cancel:
        return
    for task in to_cancel:
        task.cancel()
    loop.run_until_complete(asyncio.gather(*to_cancel, return_exceptions=True))


# ---------------------------------------------------------------------------
# run
# ---------------------------------------------------------------------------


@app.command()
def run(
    file: Optional[str] = typer.Option(None, "--file", "-f", help="Path to a specific .cobalt.py file."),
    ci: bool = typer.Option(False, "--ci", help="Exit code 1 if thresholds are violated."),
    concurrency: Optional[int] = typer.Option(None, "--concurrency", "-c", help="Override concurrency."),
    filter_: Optional[str] = typer.Option(None, "--filter", help="Run only experiments matching this string."),
) -> None:
    """Discover and run experiment files."""
    from cobalt.config import load_config

    config = load_config()

    if file:
        experiment_files = [Path(file)]
    else:
        pattern = config.test_match[0] if config.test_match else "**/*.cobalt.py"
        experiment_files = [Path(p) for p in glob.glob(pattern, recursive=True)]

    if not experiment_files:
        console.print("[yellow]No experiment files found.[/yellow]")
        raise typer.Exit(0)

    console.print(f"[bold]Found {len(experiment_files)} experiment file(s)[/bold]")

    # Suppress noisy warnings from user code and third-party libraries
    # (unclosed sockets, renamed packages, etc.) that clutter CI output.
    warnings.filterwarnings("ignore", category=ResourceWarning)
    warnings.filterwarnings("ignore", category=RuntimeWarning)
    warnings.filterwarnings("ignore", category=DeprecationWarning)

    # Suppress onnxruntime C++ warnings (e.g. PCI bus ID pattern mismatch).
    # Level 3 = ERROR (suppresses WARNING-level messages from the C++ runtime).
    import os
    os.environ.setdefault("ORT_LOG_LEVEL", "3")

    all_reports = []

    for exp_file in experiment_files:
        console.print(f"\n[cyan]Running:[/cyan] {exp_file}")
        spec = importlib.util.spec_from_file_location("_cobalt_exp", exp_file)
        if spec is None or spec.loader is None:
            console.print(f"[red]Failed to load {exp_file}[/red]")
            continue

        module = importlib.util.module_from_spec(spec)
        try:
            spec.loader.exec_module(module)  # type: ignore[union-attr]
        except SystemExit:
            pass
        except Exception as exc:
            console.print(f"[red]Error in {exp_file}: {exc}[/red]")
            continue

        # If the module has a main() coroutine that wasn't auto-called,
        # run it now and collect the report.
        main_fn = getattr(module, "main", None)
        if main_fn is not None and asyncio.iscoroutinefunction(main_fn):
            try:
                report = _run_async_experiment(main_fn)
                if report is not None:
                    all_reports.append(report)
            except Exception as exc:
                console.print(f"[red]Error running {exp_file}: {exc}[/red]")

    # CI threshold validation
    any_violation = False
    if ci:
        from cobalt.ci import validate_and_report
        any_violation = validate_and_report(all_reports)

    if ci and any_violation:
        raise typer.Exit(1)


# ---------------------------------------------------------------------------
# init
# ---------------------------------------------------------------------------


@app.command()
def init() -> None:
    """Create example experiment and cobalt.toml config."""
    experiments_dir = Path("experiments")
    experiments_dir.mkdir(exist_ok=True)

    example = experiments_dir / "my-agent.cobalt.py"
    if not example.exists():
        example.write_text(
            '''\
"""Example Cobalt experiment."""

import asyncio
from cobalt import Dataset, Evaluator, experiment


async def my_agent(text: str) -> str:
    """Replace with your real agent call."""
    return f"Echo: {text}"


dataset = Dataset.from_items([
    {"input": "What is 2+2?", "expected_output": "4"},
    {"input": "Capital of France?", "expected_output": "Paris"},
])

evaluators = [
    Evaluator(
        name="exact-match",
        type="function",
        fn=lambda ctx: __import__("cobalt").types.EvalResult(
            score=1.0 if str(ctx.item.get("expected_output", "")) in str(ctx.output) else 0.0
        ),
    ),
]


async def main() -> None:
    await experiment(
        "my-agent",
        dataset,
        runner=lambda ctx: my_agent(ctx.item["input"]).then(
            lambda out: __import__("cobalt").types.ExperimentResult(output=out)
        ),
        evaluators=evaluators,
    )


if __name__ == "__main__":
    asyncio.run(main())
''',
            encoding="utf-8",
        )
        console.print(f"[green]Created:[/green] {example}")

    config_file = Path("cobalt.toml")
    if not config_file.exists():
        config_file.write_text(
            """\
[judge]
model = "gpt-4o-mini"
provider = "openai"
# api_key = "sk-..."  # or set OPENAI_API_KEY env var

[experiment]
concurrency = 5
timeout = 30
test_dir = "./experiments"
""",
            encoding="utf-8",
        )
        console.print(f"[green]Created:[/green] {config_file}")

    console.print("\n[bold green]✓ Cobalt initialised.[/bold green] Run: [cyan]cobalt run[/cyan]")


# ---------------------------------------------------------------------------
# history
# ---------------------------------------------------------------------------


@app.command()
def history(
    limit: int = typer.Option(20, "--limit", "-n"),
    experiment_name: Optional[str] = typer.Option(None, "--experiment", "-e"),
) -> None:
    """List recent experiment runs."""
    from cobalt.storage.db import HistoryDB

    with HistoryDB() as db:
        runs = db.list_runs(experiment=experiment_name, limit=limit)

    if not runs:
        console.print("[yellow]No runs found.[/yellow]")
        return

    table = Table(show_header=True, header_style="bold")
    table.add_column("ID", style="dim")
    table.add_column("Name")
    table.add_column("Timestamp")
    table.add_column("Items", justify="right")
    table.add_column("Duration", justify="right")
    table.add_column("Scores")

    for run in runs:
        scores_str = "  ".join(f"{k}={v:.2f}" for k, v in run.avg_scores.items())
        table.add_row(
            run.id,
            run.name,
            run.timestamp[:19],
            str(run.total_items),
            f"{run.duration_ms:.0f}ms",
            scores_str,
        )
    console.print(table)


# ---------------------------------------------------------------------------
# compare
# ---------------------------------------------------------------------------


@app.command()
def compare(
    run_id_1: str = typer.Argument(..., help="First run ID"),
    run_id_2: str = typer.Argument(..., help="Second run ID"),
) -> None:
    """Compare two experiment runs side by side."""
    from cobalt.storage.results import load_result

    r1 = load_result(run_id_1)
    r2 = load_result(run_id_2)

    if r1 is None:
        console.print(f"[red]Run not found:[/red] {run_id_1}")
        raise typer.Exit(1)
    if r2 is None:
        console.print(f"[red]Run not found:[/red] {run_id_2}")
        raise typer.Exit(1)

    all_evaluators = sorted(set(list(r1.summary.scores.keys()) + list(r2.summary.scores.keys())))

    table = Table(show_header=True, header_style="bold")
    table.add_column("Evaluator")
    table.add_column(f"[cyan]{r1.name}[/cyan] ({run_id_1[:6]})", justify="right")
    table.add_column(f"[magenta]{r2.name}[/magenta] ({run_id_2[:6]})", justify="right")
    table.add_column("Δ", justify="right")

    for name in all_evaluators:
        s1 = r1.summary.scores.get(name)
        s2 = r2.summary.scores.get(name)
        v1 = f"{s1.avg:.3f}" if s1 else "—"
        v2 = f"{s2.avg:.3f}" if s2 else "—"
        if s1 and s2:
            delta = s2.avg - s1.avg
            color = "green" if delta > 0 else ("red" if delta < 0 else "dim")
            delta_str = f"[{color}]{delta:+.3f}[/{color}]"
        else:
            delta_str = "—"
        table.add_row(name, v1, v2, delta_str)

    console.print(table)


# ---------------------------------------------------------------------------
# clean
# ---------------------------------------------------------------------------


@app.command()
def clean(
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation."),
) -> None:
    """Delete all stored results and reset the history database."""
    import shutil
    from cobalt.storage.db import _DB_PATH
    from cobalt.storage.results import _RESULTS_DIR

    if not yes:
        typer.confirm("This will delete all results. Continue?", abort=True)

    if _RESULTS_DIR.exists():
        shutil.rmtree(_RESULTS_DIR)
        console.print(f"[green]Deleted:[/green] {_RESULTS_DIR}")

    if _DB_PATH.exists():
        _DB_PATH.unlink()
        console.print(f"[green]Deleted:[/green] {_DB_PATH}")

    console.print("[bold green]✓ Cleaned.[/bold green]")


# ---------------------------------------------------------------------------
# mcp
# ---------------------------------------------------------------------------


@app.command()
def mcp() -> None:
    """Start the Cobalt MCP server (stdio transport) for Claude / MCP clients.

    Configure in Claude Desktop (~/Library/Application Support/Claude/claude_desktop_config.json):

    \\b
    {
      "mcpServers": {
        "cobalt": {
          "command": "cobalt",
          "args": ["mcp"],
          "env": { "OPENAI_API_KEY": "sk-..." }
        }
      }
    }
    """
    from cobalt.mcp.server import main as mcp_main

    mcp_main()


# ---------------------------------------------------------------------------
# ui (dashboard)
# ---------------------------------------------------------------------------


@app.command()
def ui(
    port: int = typer.Option(4000, "--port", "-p", help="Port to bind the dashboard server."),
    no_open: bool = typer.Option(False, "--no-open", help="Don't automatically open browser."),
    host: str = typer.Option("127.0.0.1", "--host", help="Host interface to bind."),
) -> None:
    """Start the local Cobalt dashboard at http://localhost:<port>."""
    try:
        import uvicorn
    except ImportError:
        console.print(
            "[red]uvicorn not installed.[/red] Run: pip install 'cobalt-ai[dashboard]'"
        )
        raise typer.Exit(1)

    from cobalt.dashboard.server import app as dashboard_app

    url = f"http://{host}:{port}"
    console.print(f"[bold green]✓ Cobalt Dashboard[/bold green] → [cyan]{url}[/cyan]")

    if not no_open:
        import threading
        import time

        def _open():
            time.sleep(0.8)
            webbrowser.open(url)

        threading.Thread(target=_open, daemon=True).start()

    uvicorn.run(dashboard_app, host=host, port=port, log_level="warning")


def main() -> None:
    app()


if __name__ == "__main__":
    main()
