# Copyright (c) 2026 Antonin Sulc
# Licensed under the MIT License. See LICENSE file for details.

"""
APEBench-style PDE problems (arXiv 2411.00180).

Implements the same PDE equations as APEBench for comparison with FastLSQ and PIELM.
Domain: space-time (x, t) with periodic BCs in x. Parameters match APEBench defaults.
"""

import torch
import numpy as np

from fastlsq.utils import device


# ======================================================================
# 1D Advection: ∂u/∂t = -c ∂u/∂x  (APEBench adv)
# ======================================================================

class Advection1D:
    """1D Advection: u_t + c u_x = 0 on [0,L] x [0,T], periodic in x.

    APEBench default: L=1, c from γ1 (CFL). Exact: u(t,x) = u_0(x - ct).
    """

    def __init__(self, L=1.0, c=0.5, T=0.5, K=5, seed=42):
        self.name = "Advection 1D"
        self.dim = 2  # (x, t)
        self.L = L
        self.c = c
        self.T = T
        self.K = K
        rng = np.random.default_rng(seed)
        self.o = rng.uniform(-0.5, 0.5)
        self.a = rng.uniform(-1, 1, K)
        self.b = rng.uniform(-1, 1, K)

    def _fourier_ic(self, x):
        """Initial condition: truncated Fourier series at t=0."""
        x_np = x.cpu().numpy() if x.is_cuda else x.numpy()
        out = np.full((len(x_np), 1), self.o, dtype=np.float64)
        for k in range(1, self.K + 1):
            kk = k * 2 * np.pi / self.L
            out += self.a[k - 1] * np.sin(kk * x_np[:, 0:1])
            out += self.b[k - 1] * np.cos(kk * x_np[:, 0:1])
        out = np.clip(out, -1, 1)
        return torch.tensor(out, dtype=x.dtype, device=x.device)

    def exact(self, x):
        """u(t,x) = u_0(x - c*t) for periodic domain."""
        x_shifted = (x[:, 0:1] - self.c * x[:, 1:2]) % self.L
        x_ic = torch.cat([x_shifted, torch.zeros_like(x_shifted)], dim=1)
        return self._fourier_ic(x_ic)

    def exact_grad(self, x):
        """Gradient (u_x, u_t)."""
        eps = 1e-6
        xp = x.clone()
        xp[:, 0] += eps
        xm = x.clone()
        xm[:, 0] -= eps
        u_x = (self.exact(xp) - self.exact(xm)) / (2 * eps)
        xp = x.clone()
        xp[:, 1] += eps
        xm = x.clone()
        xm[:, 1] -= eps
        u_t = (self.exact(xp) - self.exact(xm)) / (2 * eps)
        return torch.cat([u_x, u_t], dim=1)

    def get_train_data(self, n_pde=5000, n_bc=1000):
        x_pde = torch.rand(n_pde, 2, device=device)
        x_pde[:, 0] *= self.L
        x_pde[:, 1] *= self.T

        # IC at t=0
        n_ic = n_bc // 2
        x_ic = torch.cat([
            torch.rand(n_ic, 1, device=device) * self.L,
            torch.zeros(n_ic, 1, device=device),
        ], dim=1)
        u_ic = self._fourier_ic(x_ic)

        # Periodic BC: u(0,t) = u(L,t)
        n_per = n_bc - n_ic
        t_per = torch.rand(n_per, 1, device=device) * self.T
        x_left = torch.cat([torch.zeros(n_per, 1, device=device), t_per], dim=1)
        x_right = torch.cat([torch.full((n_per, 1), self.L, device=device), t_per], dim=1)
        u_left = self.exact(x_left)
        u_right = self.exact(x_right)

        bcs = [
            (x_ic, u_ic, "dirichlet"),
            (x_left, u_left, "dirichlet"),
            (x_right, u_right, "dirichlet"),
        ]
        return x_pde, bcs, None

    def build(self, slv, x_pde, bcs, f_pde):
        basis = slv.basis
        cache = basis.cache(x_pde)
        dh = basis.gradient(x_pde, cache=cache)
        u_t = dh[:, 1, :]
        u_x = dh[:, 0, :]
        A = u_t + self.c * u_x
        b = torch.zeros(len(x_pde), 1, device=device)
        As, bs = [A], [b]
        w = 100.0
        for (pts, vals, type_) in bcs:
            h = basis.evaluate(pts)
            As.append(h * w)
            bs.append(vals * w)
        return torch.cat(As), torch.cat(bs)

    def get_test_points(self, n=5000):
        x = torch.rand(n, 2, device=device)
        x[:, 0] *= self.L
        x[:, 1] *= self.T
        return x


# ======================================================================
# 1D Diffusion: ∂u/∂t = ν ∂²u/∂x²  (APEBench diff)
# ======================================================================

class Diffusion1D:
    """1D Diffusion: u_t - ν u_xx = 0 on [0,L] x [0,T], periodic in x."""

    def __init__(self, L=1.0, nu=0.01, T=0.5, K=5, seed=42):
        self.name = "Diffusion 1D"
        self.dim = 2
        self.L = L
        self.nu = nu
        self.T = T
        self.K = K
        rng = np.random.default_rng(seed)
        self.o = rng.uniform(-0.5, 0.5)
        self.a = rng.uniform(-1, 1, K)
        self.b = rng.uniform(-1, 1, K)

    def _fourier_ic(self, x):
        x_np = x.cpu().numpy() if x.is_cuda else x.numpy()
        out = np.full((len(x_np), 1), self.o, dtype=np.float64)
        for k in range(1, self.K + 1):
            kk = k * 2 * np.pi / self.L
            out += self.a[k - 1] * np.sin(kk * x_np[:, 0:1])
            out += self.b[k - 1] * np.cos(kk * x_np[:, 0:1])
        out = np.clip(out, -1, 1)
        return torch.tensor(out, dtype=x.dtype, device=x.device)

    def exact(self, x):
        """Fourier series solution: u = sum_k exp(-ν k² (2π/L)² t) * [a_k sin + b_k cos]."""
        x_np = x.cpu().numpy() if x.is_cuda else x.numpy()
        xx, tt = x_np[:, 0:1], x_np[:, 1:2]
        out = np.full_like(xx, self.o, dtype=np.float64)
        for k in range(1, self.K + 1):
            kk = k * 2 * np.pi / self.L
            decay = np.exp(-self.nu * kk ** 2 * tt)
            out += decay * (self.a[k - 1] * np.sin(kk * xx) + self.b[k - 1] * np.cos(kk * xx))
        return torch.tensor(out, dtype=x.dtype, device=x.device)

    def exact_grad(self, x):
        eps = 1e-6
        g = []
        for d in range(2):
            xp, xm = x.clone(), x.clone()
            xp[:, d] += eps
            xm[:, d] -= eps
            g.append((self.exact(xp) - self.exact(xm)) / (2 * eps))
        return torch.cat(g, dim=1)

    def get_train_data(self, n_pde=5000, n_bc=1000):
        x_pde = torch.rand(n_pde, 2, device=device)
        x_pde[:, 0] *= self.L
        x_pde[:, 1] *= self.T

        n_ic = n_bc // 2
        x_ic = torch.cat([
            torch.rand(n_ic, 1, device=device) * self.L,
            torch.zeros(n_ic, 1, device=device),
        ], dim=1)
        u_ic = self._fourier_ic(x_ic)

        n_per = n_bc - n_ic
        t_per = torch.rand(n_per, 1, device=device) * self.T
        x_left = torch.cat([torch.zeros(n_per, 1, device=device), t_per], dim=1)
        x_right = torch.cat([torch.full((n_per, 1), self.L, device=device), t_per], dim=1)
        u_left = self.exact(x_left)
        u_right = self.exact(x_right)

        bcs = [
            (x_ic, u_ic, "dirichlet"),
            (x_left, u_left, "dirichlet"),
            (x_right, u_right, "dirichlet"),
        ]
        return x_pde, bcs, None

    def build(self, slv, x_pde, bcs, f_pde):
        basis = slv.basis
        cache = basis.cache(x_pde)
        dh = basis.gradient(x_pde, cache=cache)
        u_t = dh[:, 1, :]
        lap = basis.laplacian(x_pde, dims=[0], cache=cache)
        A = u_t - self.nu * lap
        b = torch.zeros(len(x_pde), 1, device=device)
        As, bs = [A], [b]
        w = 100.0
        for (pts, vals, type_) in bcs:
            h = basis.evaluate(pts)
            As.append(h * w)
            bs.append(vals * w)
        return torch.cat(As), torch.cat(bs)

    def get_test_points(self, n=5000):
        x = torch.rand(n, 2, device=device)
        x[:, 0] *= self.L
        x[:, 1] *= self.T
        return x


# ======================================================================
# 1D Burgers (time-dependent): ∂u/∂t = -½ ∂(u²)/∂x + ν ∂²u/∂x²  (APEBench burgers)
# ======================================================================

class Burgers1D_Time:
    """1D Viscous Burgers: u_t + u u_x - ν u_xx = 0.

    Conservative form: u_t = -½ ∂(u²)/∂x + ν u_xx = -u u_x + ν u_xx.
    """

    def __init__(self, L=1.0, nu=0.01, T=0.3, K=3, seed=42):
        self.name = "Burgers 1D (time)"
        self.dim = 2
        self.L = L
        self.nu = nu
        self.T = T
        self.K = K
        self.lam_bc = 100.0
        rng = np.random.default_rng(seed)
        self.o = 0.0
        self.a = rng.uniform(-0.5, 0.5, K)
        self.b = rng.uniform(-0.5, 0.5, K)

    def _fourier_ic(self, x):
        x_np = x.cpu().numpy() if x.is_cuda else x.numpy()
        out = np.full((len(x_np), 1), self.o, dtype=np.float64)
        for k in range(1, self.K + 1):
            kk = k * 2 * np.pi / self.L
            out += self.a[k - 1] * np.sin(kk * x_np[:, 0:1])
            out += self.b[k - 1] * np.cos(kk * x_np[:, 0:1])
        out = np.clip(out, -1, 1)
        return torch.tensor(out, dtype=x.dtype, device=x.device)

    def exact(self, x):
        """Reference from spectral solver (computed externally). Fallback: IC."""
        return self._fourier_ic(x)

    def exact_grad(self, x):
        eps = 1e-6
        g = []
        for d in range(2):
            xp, xm = x.clone(), x.clone()
            xp[:, d] += eps
            xm[:, d] -= eps
            g.append((self.exact(xp) - self.exact(xm)) / (2 * eps))
        return torch.cat(g, dim=1)

    def get_train_data(self, n_pde=5000, n_bc=1000):
        x_pde = torch.rand(n_pde, 2, device=device)
        x_pde[:, 0] *= self.L
        x_pde[:, 1] *= self.T

        n_ic = n_bc // 2
        x_ic = torch.cat([
            torch.rand(n_ic, 1, device=device) * self.L,
            torch.zeros(n_ic, 1, device=device),
        ], dim=1)
        u_ic = self._fourier_ic(x_ic)

        n_per = n_bc - n_ic
        t_per = torch.rand(n_per, 1, device=device) * self.T
        x_left = torch.cat([torch.zeros(n_per, 1, device=device), t_per], dim=1)
        x_right = torch.cat([torch.full((n_per, 1), self.L, device=device), t_per], dim=1)
        u_left = self._fourier_ic(x_left)
        u_right = self._fourier_ic(x_right)

        bcs = [(x_ic, u_ic), (x_left, u_left), (x_right, u_right)]
        return x_pde, bcs, None

    def build_newton_step(self, solver, x_pde, bcs, f_pde):
        basis = solver.basis
        cache = basis.cache(x_pde)
        H = basis.evaluate(x_pde, cache=cache)
        dh = basis.gradient(x_pde, cache=cache)
        u_x = dh[:, 0, :]
        u_t = dh[:, 1, :]
        lap = basis.laplacian(x_pde, dims=[0], cache=cache)

        u_k = H @ solver.beta
        ux_k = u_x @ solver.beta
        R = (u_t @ solver.beta) + u_k * ux_k - self.nu * (lap @ solver.beta)
        J_pde = u_t + (u_k * u_x) + (ux_k * H) - self.nu * lap

        rows_J, rows_b = [J_pde], [-R]
        for (x_bc, u_bc) in bcs:
            H_bc = basis.evaluate(x_bc)
            rows_J.append(self.lam_bc * H_bc)
            rows_b.append(self.lam_bc * (u_bc - H_bc @ solver.beta))
        return torch.cat(rows_J, 0), torch.cat(rows_b, 0)

    def build_linear_init(self, solver, x_pde, bcs, f_pde):
        basis = solver.basis
        cache = basis.cache(x_pde)
        dh = basis.gradient(x_pde, cache=cache)
        u_t = dh[:, 1, :]
        lap = basis.laplacian(x_pde, dims=[0], cache=cache)
        A = u_t - self.nu * lap
        b = torch.zeros(len(x_pde), 1, device=device)
        rows_A, rows_b = [A], [b]
        for (x_bc, u_bc) in bcs:
            H_bc = basis.evaluate(x_bc)
            rows_A.append(self.lam_bc * H_bc)
            rows_b.append(self.lam_bc * u_bc)
        return torch.cat(rows_A, 0), torch.cat(rows_b, 0)

    def get_test_points(self, n=5000):
        x = torch.rand(n, 2, device=device)
        x[:, 0] *= self.L
        x[:, 1] *= self.T
        return x
