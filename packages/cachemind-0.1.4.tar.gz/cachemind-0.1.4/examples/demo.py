from cachemind import CacheMind

cache = CacheMind()

print(cache.query("What is AI?"))
print(cache.query("Explain AI"))

print(cache.metrics.get_stats())