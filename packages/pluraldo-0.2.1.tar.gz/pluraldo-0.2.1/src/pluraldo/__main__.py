import pluraldo

pluraldo.cli()
