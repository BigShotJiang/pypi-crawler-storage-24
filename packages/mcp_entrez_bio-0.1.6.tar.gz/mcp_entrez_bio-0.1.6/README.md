# mcp-entrez-bio

An MCP (Model Context Protocol) server for interacting with NCBI Entrez via Biopython.

## Features
- Search PubMed with boolean queries (`pubmed_esearch`)
- Fetch PubMed abstracts as plain text (`pubmed_efetch_abstracts`)
- Automatic rate-limiting conforming to NCBI guidelines

## Prerequisites
Provide your NCBI credentials via environment variables for higher rate limits (10 requests/s vs 3 requests/s without API key):
```bash
export NCBI_EMAIL="your_email@example.com"
export NCBI_API_KEY="your_api_key_here"  # Optional but recommended
```

## Installation & Usage

Install using standard python tools or `uv`:
```bash
uv tool install .
```

Run the server directly via standard MCP stdio:
```bash
mcp-entrez
```
