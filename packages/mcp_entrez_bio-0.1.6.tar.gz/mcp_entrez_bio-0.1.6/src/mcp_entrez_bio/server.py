from mcp.server.fastmcp import FastMCP
from pydantic import Field
from typing import List, Dict, Any
from typing import Literal
import sys
from pathlib import Path

if sys.version_info >= (3, 11):
    import tomllib
else:
    import tomli as tomllib

from .entrez import EntrezClient

# Create the FastMCP server instance
mcp = FastMCP("mcp-entrez-bio")

_client: EntrezClient | None = None

def get_client() -> EntrezClient:
    global _client
    if _client is None:
        _client = EntrezClient()
    return _client

@mcp.tool()
async def pubmed_esearch(
    query: str = Field(..., description="Boolean search query for PubMed (e.g., '(cancer[Title/Abstract]) AND therapy'). Must be in English."),
    limit: int = Field(default=20, ge=1, le=200, description="Number of PMIDs to return (1–200). Default is 20. Use a higher value when broad coverage is needed."),
    sort: Literal["relevance", "pub_date", "most+recent"] = Field(
        default="relevance",
        description="Sort order: 'relevance' (PubMed Best Match, default), 'pub_date' (newest first), 'most+recent' (most recently indexed first)."
    )
) -> List[str]:
    """
    Search PubMed using a boolean query and return a list of matching PubMed IDs (PMIDs).
    Results are sorted by relevance (Best Match) by default. Use this tool first to find relevant PMIDs,
    then pass them to the efetch or metadata tools to retrieve abstracts or full citation info.
    """
    client = get_client()
    return await client.esearch_pubmed(query=query, retmax=limit, sort=sort)

@mcp.tool()
async def pubmed_efetch_abstracts(
    pmids: List[str] = Field(..., description="A list of PubMed IDs (PMIDs) to fetch abstracts for. E.g., ['123456', '789012'].")
) -> Dict[str, str]:
    """
    Fetch the PubMed records corresponding to the given list of PubMed IDs and extract their
    abstracts into plain text format. The returned dictionary maps each PMID to its abstract string.
    """
    client = get_client()
    return await client.efetch_pubmed_abstracts(pmids)

@mcp.tool()
async def pubmed_get_paper_metadata(
    pmid: str = Field(..., description="A single PubMed ID (PMID) to fetch citation metadata for. E.g., '123456'.")
) -> Dict[str, Any]:
    """
    Fetch comprehensive metadata for a specific PubMed article, including Title, Authors (list),
    Journal info, Publication Date, DOI, and an auto-generated MLA/APA-style citation string.
    """
    client = get_client()
    return await client.get_paper_metadata(pmid)

@mcp.tool()
async def pubmed_get_full_text_links(
    pmid: str = Field(..., description="A single PubMed ID (PMID) to find full-text links for. E.g., '123456'.")
) -> List[Dict[str, str]]:
    """
    Discover external links to the full text of a PubMed article.
    Returns a list of providers (e.g., 'PMC', 'Elsevier', 'Nature', 'DOI') and their corresponding URLs.
    """
    client = get_client()
    return await client.get_full_text_links(pmid)

@mcp.prompt()
def mcp_entrez_prompt() -> str:
    """Get the standard LLM prompt instructions for using this MCP server from pyproject.toml."""
    pyproject_path = Path(__file__).parent.parent.parent / "pyproject.toml"
    try:
        with open(pyproject_path, "rb") as f:
            data = tomllib.load(f)
        return data.get("tool", {}).get("mcp-entrez-bio", {}).get("prompts", {}).get("default", "Prompt instructions not found.")
    except Exception as e:
        return f"Error loading instructions: {str(e)}"
