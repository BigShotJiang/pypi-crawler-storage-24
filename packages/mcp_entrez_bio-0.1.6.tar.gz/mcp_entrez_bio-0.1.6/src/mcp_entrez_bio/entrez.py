import os
import time
import asyncio
from typing import List, Dict
from Bio import Entrez
from dotenv import load_dotenv

load_dotenv()

class RateLimiter:
    """Simple token bucket rate limiter for NCBI API."""
    def __init__(self, calls_per_second: float):
        self.interval = 1.0 / calls_per_second
        self.last_call = 0.0
        self.lock = asyncio.Lock()

    async def wait(self):
        async with self.lock:
            now = time.time()
            elapsed = now - self.last_call
            if elapsed < self.interval:
                await asyncio.sleep(self.interval - elapsed)
            self.last_call = time.time()

class EntrezClient:
    """Client for NCBI Entrez wrapper using Biopython with automatic rate limiting."""
    
    def __init__(self):
        self.email = os.environ.get("NCBI_EMAIL")
        self.api_key = os.environ.get("NCBI_API_KEY")
        
        if not self.email or not self.api_key:
            raise ValueError("NCBI_EMAIL and NCBI_API_KEY environment variables are required. Please set them in your .env file or environment.")
        
        Entrez.email = self.email
        Entrez.api_key = self.api_key
        # NCBI allows up to 10 requests / second with an API key
        self.rate_limiter = RateLimiter(9.0)  # slightly below 10 for safety

    async def esearch_pubmed(self, query: str, retmax: int = 20, sort: str = "relevance") -> List[str]:
        """
        Wrap Entrez.esearch for Boolean retrieval of PubMed IDs.
        Default sort is 'relevance' (Best Match). Also supports 'pub_date' and 'most+recent'.
        """
        await self.rate_limiter.wait()
        
        def _search():
            with Entrez.esearch(db="pubmed", term=query, retmax=retmax, sort=sort) as handle:
                return Entrez.read(handle)
                
        record = await asyncio.to_thread(_search)
        return record.get("IdList", [])

    async def efetch_pubmed_abstracts(self, pmids: List[str]) -> Dict[str, str]:
        """
        Wrap Entrez.efetch to extract PubMed abstracts and convert to plain text.
        """
        if not pmids:
            return {}
            
        await self.rate_limiter.wait()
        
        def _fetch():
            id_list = ",".join(pmids)
            with Entrez.efetch(db="pubmed", id=id_list, retmode="xml") as handle:
                return Entrez.read(handle)
                
        records = await asyncio.to_thread(_fetch)
        
        abstracts = {}
        pubmed_articles = records.get("PubmedArticle", [])
        for article in pubmed_articles:
            try:
                medline = article["MedlineCitation"]
                pmid = str(medline["PMID"])
                
                article_data = medline.get("Article", {})
                abstract_data = article_data.get("Abstract", {})
                abstract_texts = abstract_data.get("AbstractText", [])
                
                if abstract_texts:
                    abstract_plain = " ".join([str(text) for text in abstract_texts])
                    abstracts[pmid] = abstract_plain
            except (KeyError, IndexError, TypeError):
                continue
                
        return abstracts
        
    async def get_paper_metadata(self, pmid: str) -> Dict[str, str]:
        """
        Fetch structured metadata for a single PubMed ID to generate citations.
        Returns title, authors, journal, pub_date, doi, and a formatted citation.
        """
        await self.rate_limiter.wait()
        
        def _fetch():
            with Entrez.efetch(db="pubmed", id=pmid, retmode="xml") as handle:
                return Entrez.read(handle)
                
        records = await asyncio.to_thread(_fetch)
        pubmed_articles = records.get("PubmedArticle", [])
        
        if not pubmed_articles:
            return {"error": "No article found for this PMID."}
            
        article_node = pubmed_articles[0]["MedlineCitation"]["Article"]
        
        # 1. Title
        title = article_node.get("ArticleTitle", "")
        
        # 2. Authors
        authors = []
        author_list = article_node.get("AuthorList", [])
        for author in author_list:
            if "LastName" in author and "Initials" in author:
                authors.append(f"{author['LastName']} {author['Initials']}")
            elif "CollectiveName" in author:
                authors.append(author["CollectiveName"])
                
        # 3. Journal
        journal_info = article_node.get("Journal", {})
        journal_title = journal_info.get("Title", "")
        journal_iso = journal_info.get("ISOAbbreviation", journal_title)
        
        # 4. Pub Date
        pub_date = ""
        journal_issue = journal_info.get("JournalIssue", {})
        pub_date_node = journal_issue.get("PubDate", {})
        if "Year" in pub_date_node:
            pub_date = pub_date_node["Year"]
            if "Month" in pub_date_node:
                pub_date += f" {pub_date_node['Month']}"
                if "Day" in pub_date_node:
                    pub_date += f" {pub_date_node['Day']}"
        elif "MedlineDate" in pub_date_node:
            pub_date = pub_date_node["MedlineDate"]
            
        # 5. DOI
        doi = ""
        elocation_ids = article_node.get("ELocationID", [])
        for eloc in elocation_ids:
            if eloc.attributes.get("EIdType") == "doi":
                doi = str(eloc)
                break
                
        # 6. MLA-style Citation string
        authors_str = ", ".join(authors[:3])
        if len(authors) > 3:
            authors_str += ", et al"
        
        citation = f"{authors_str}. \"{title}\" {journal_iso} ({pub_date})."
        if doi:
            citation += f" doi: {doi}"
            
        return {
            "title": str(title),
            "authors": authors,
            "journal": str(journal_title),
            "journal_abbr": str(journal_iso),
            "pub_date": str(pub_date),
            "doi": str(doi),
            "citation_format": citation
        }
        
    async def get_full_text_links(self, pmid: str) -> List[Dict[str, str]]:
        """
        Find external full-text links for a PMID using Entrez.elink with cmd='llinks'.
        Returns a list of dictionaries containing link providers and URLs.
        """
        await self.rate_limiter.wait()
        
        def _get_links():
            with Entrez.elink(dbfrom="pubmed", id=pmid, cmd="llinks") as handle:
                return Entrez.read(handle)
                
        records = await asyncio.to_thread(_get_links)
        
        links_data = []
        if not records:
            return links_data
            
        id_url_list = records[0].get("IdUrlList", {})
        id_url_sets = id_url_list.get("IdUrlSet", [])
        
        for url_set in id_url_sets:
            for obj in url_set.get("ObjUrl", []):
                provider = obj.get("Provider", {}).get("NameAbbr", "Unknown Provider")
                url = str(obj.get("Url", ""))
                if url:
                    links_data.append({
                        "provider": str(provider),
                        "url": url
                    })
                    
        # Check if we should explicitly add a DOI mirror if a DOI exists but no provider gave a pure link
        # though usually llinks includes the DOI redirect. 
        # But we can also check for PMC links directly:
        metadata = await self.get_paper_metadata(pmid)
        if metadata.get("doi"):
            doi_url = f"https://doi.org/{metadata['doi']}"
            if not any("doi.org" in l["url"] for l in links_data):
                links_data.append({"provider": "DOI", "url": doi_url})
                
        return links_data
