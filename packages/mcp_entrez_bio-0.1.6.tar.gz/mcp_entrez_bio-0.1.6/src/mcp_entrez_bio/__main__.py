import sys
from .server import mcp

def main():
    """
    Entry point for the mcp-entrez-bio server.
    Handles NCBI API configuration and starts the standard FastMCP stdio interface.
    """
    mcp.run()

if __name__ == "__main__":
    sys.exit(main())
