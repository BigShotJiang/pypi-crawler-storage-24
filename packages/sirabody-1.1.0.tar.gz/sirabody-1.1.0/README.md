# SirAbody GUI Library

Modern PySide6 GUI toolkit with **realistic rain physics**, dark theme, and beautiful buttons.

![Python](https://img.shields.io/badge/Python-3.8+-blue)
![PySide6](https://img.shields.io/badge/PySide6-6.5+-green)
![License](https://img.shields.io/badge/License-MIT-yellow)

## Install

```bash
pip install sirabody
```

---

## Easy Mode (For Beginners)

**One line. That's it.**

```python
import sirabody

sirabody.easy("My App", ["Button 1", "Button 2", "Button 3"])
```

### With a callback

```python
import sirabody

def clicked(button_name):
    print(f"{button_name} was clicked!")

sirabody.easy("My App", ["Save", "Load", "Settings"], on_click=clicked)
```

### Easy Mode Options

| Parameter      | Type       | Description                           |
|----------------|------------|---------------------------------------|
| `title`        | `str`      | App title (required)                  |
| `button_names` | `list`     | List of button name strings (required)|
| `subtitle`     | `str`      | Subtitle text                         |
| `on_click`     | `callable` | Called with button name on click      |

Colors are assigned automatically!

---

## Master Mode (Full Control)

For developers who want to customize **everything**.

```python
from sirabody import SirAbodyApp

def on_click_1():
    print("Button 1!")

app = SirAbodyApp(
    title="My App",
    subtitle="Built with SirAbody",
    title_color="#00BFFF",

    buttons=[
        {"text": "Button 1", "color": "#FFD700", "callback": on_click_1},
        {"text": "Button 2", "color": "#FF6B6B"},
        {"text": "Button 3", "color": "#69F0AE"},
        {"text": "Button 4", "color": "#40C4FF"},
    ],
    columns=2,

    # Rain customization
    rain_config={
        "rain_color": (220, 245, 255),
        "rain_speed": (6, 14),
        "rain_count": 100,
        "splash_enabled": True,
        "mouse_interaction": True,
    },

    version="v1.0",
)
app.run()
```

### Button Options

| Key           | Type       | Default     | Description                  |
|---------------|------------|-------------|------------------------------|
| `text`        | `str`      | Required    | Button label                 |
| `color`       | `str`      | `#E0F7FA`   | Text color (hex)             |
| `callback`    | `callable` | `None`      | Function to call on click    |
| `bg_color`    | `str`      | `#2a2a2a`   | Background color             |
| `hover_color` | `str`      | `#3a3a3a`   | Hover background color       |

### App Options

| Parameter      | Type   | Default                      | Description                           |
|----------------|--------|------------------------------|---------------------------------------|
| `title`        | `str`  | `"SirAbody"`                 | Header title                          |
| `subtitle`     | `str`  | `"Application"`              | Header subtitle                       |
| `buttons`      | `list` | `[]`                         | List of button dicts                  |
| `version`      | `str`  | `"v1.0"`                     | Footer version text                   |
| `website_url`  | `str`  | `"https://www.SirAbody.com"` | Website link button URL               |
| `discord_url`  | `str`  | `"https://discord.gg/509"`   | Discord link button URL               |
| `window_title` | `str`  | Same as `title`              | Taskbar window title                  |
| `icon_path`    | `str`  | `None`                       | Path to .ico file                     |
| `title_color`  | `str`  | `"#00BFFF"`                  | Title text color                      |
| `bg_opacity`   | `int`  | `180`                        | Background opacity (0-255)            |
| `rain_enabled` | `bool` | `True`                       | Enable/disable rain                   |
| `columns`      | `int`  | `2`                          | Number of button columns              |
| `status_text`  | `str`  | `"Ready"`                    | Default footer status                 |
| `status_color` | `str`  | `"#90EE90"`                  | Status text color                     |
| `rain_config`  | `dict` | `{}`                         | Rain customization (see below)        |
| `width`        | `int`  | `900`                        | Window width                          |
| `height`       | `int`  | `650`                        | Window height                         |

### Rain Config Options

| Key                  | Type    | Default             | Description                              |
|----------------------|---------|---------------------|------------------------------------------|
| `rain_color`         | `tuple` | `(220, 245, 255)`   | Drop color (R, G, B)                     |
| `splash_color`       | `tuple` | `(200, 240, 255)`   | Splash particle color (R, G, B)          |
| `rain_speed`         | `tuple` | `(6, 14)`           | Speed range (min, max)                   |
| `rain_length`        | `tuple` | `(15, 30)`          | Drop length range (min, max)             |
| `rain_count`         | `int`   | `100`               | Foreground drop count                    |
| `rain_count_bg`      | `int`   | `150`               | Background drop count                    |
| `splash_enabled`     | `bool`  | `True`              | Enable splash particles on collision     |
| `mouse_interaction`  | `bool`  | `True`              | Drops interact with mouse cursor         |
| `mouse_radius`       | `int`   | `25`                | Mouse collision radius in pixels         |
| `collision_enabled`  | `bool`  | `True`              | Drops collide with buttons               |
| `physics_fps`        | `int`   | `120`               | Physics engine tick rate                 |
| `wind_strength`      | `float` | `0.3`               | Wind effect on window drag               |
| `sparkle_enabled`    | `bool`  | `True`              | Sparkle at drop head                     |
| `sparkle_color`      | `tuple` | `(255,255,255,240)` | Sparkle color (R, G, B, A)               |

---

## Runtime Control (Master Mode)

```python
# Change status bar
window.set_status("Processing...", "#FFA500")

# Show/hide progress bar
window.set_progress(50, "#69F0AE")   # 50%
window.set_progress(-1)               # Hide

# Enable/disable buttons
window.set_buttons_enabled(False)

# Get a specific button
btn = window.get_button(0)

# Control rain at runtime
rain = window.get_rain()
rain.set_rain_color(255, 0, 0)       # Red rain!
rain.set_rain_count(300)              # More drops
rain.set_rain_speed(15, 30)           # Faster
rain.set_wind(0.8)                    # Stronger wind
```

---

## Individual Components

```python
from sirabody import ModernButton, CircularLinkButton, RainOverlay, GlowFrame
```

| Component            | Description                                    |
|----------------------|------------------------------------------------|
| `ModernButton`       | Dark themed button with hover/press effects    |
| `CircularLinkButton` | Round button with web/discord icon + URL       |
| `RainOverlay`        | Physics-based rain widget (120Hz)              |
| `GlowFrame`          | Transparent container frame                    |

---

## License

MIT License - Made by **SirAbody**
