"""
Main application window with rain effect, buttons grid, header, and footer.
النافذة الرئيسية مع تأثير المطر وشبكة الأزرار والهيدر والفوتر.

=== Easy Mode ===
    >>> import sirabody
    >>> sirabody.easy("My App", ["Button 1", "Button 2"])

=== Master Mode ===
    >>> from sirabody import SirAbodyWindow, RainOverlay
    >>> # Full control over everything
"""

import sys
import os
import math
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QLabel,
                               QVBoxLayout, QHBoxLayout, QProgressBar, QGridLayout)
from PySide6.QtCore import Qt, QPoint
from PySide6.QtGui import QFont, QIcon

from .rain import RainOverlay
from .components import ModernButton, CircularLinkButton, GlowFrame


# ═══════════════════════════════════════════════════════════════
#  Color Presets (for Easy Mode)
# ═══════════════════════════════════════════════════════════════

# ألوان جاهزة ودورية - كل زر يأخذ لون تلقائي
_EASY_COLORS = [
    "#FFD700",  # ذهبي
    "#FF6B6B",  # أحمر وردي
    "#69F0AE",  # أخضر نعناعي
    "#40C4FF",  # أزرق سماوي
    "#9B59B6",  # بنفسجي
    "#1ABC9C",  # فيروزي
    "#FF9800",  # برتقالي
    "#E91E63",  # وردي
    "#00BCD4",  # سيان
    "#8BC34A",  # أخضر فاتح
]


class SirAbodyWindow(QMainWindow):
    """النافذة الرئيسية مع تأثير المطر وتخطيط الأزرار.

    هذا الكلاس يعطيك تحكم كامل (Master Mode).
    للاستخدام السهل، استخدم sirabody.easy() بدلاً منه.

    Args:
        title (str): عنوان التطبيق (يظهر في الهيدر)
        subtitle (str): عنوان فرعي
        buttons (list[dict]): قائمة أزرار، كل زر dict فيه:
            - ``"text"`` (str): نص الزر (مطلوب)
            - ``"color"`` (str): لون النص (اختياري، افتراضي "#E0F7FA")
            - ``"callback"`` (callable): الدالة (اختياري)
            - ``"bg_color"`` (str): لون خلفية الزر (اختياري)
            - ``"hover_color"`` (str): لون hover (اختياري)
        version (str): نص الإصدار في الفوتر
        website_url (str): رابط الموقع (زر أيسر)
        discord_url (str): رابط الديسكورد (زر أيمن)
        window_title (str): عنوان النافذة في شريط المهام
        icon_path (str): مسار أيقونة النافذة
        title_color (str): لون العنوان الرئيسي
        bg_opacity (int): شفافية الخلفية (0-255)
        rain_enabled (bool): تفعيل/تعطيل تأثير المطر
        columns (int): عدد أعمدة الأزرار
        status_text (str): نص الحالة الافتراضي
        status_color (str): لون نص الحالة
        rain_config (dict): إعدادات المطر المتقدمة (Master Mode) - يتم تمريرها مباشرة لـ RainOverlay:
            - ``"rain_color"`` (tuple): لون القطرات (R, G, B)
            - ``"splash_color"`` (tuple): لون الرذاذ (R, G, B)
            - ``"rain_speed"`` (tuple): سرعة القطرات (min, max)
            - ``"rain_length"`` (tuple): طول القطرات (min, max)
            - ``"rain_count"`` (int): عدد القطرات للطبقة الأمامية
            - ``"rain_count_bg"`` (int): عدد القطرات للطبقة الخلفية
            - ``"splash_enabled"`` (bool): تفعيل الرذاذ
            - ``"mouse_interaction"`` (bool): تفاعل الماوس
            - ``"mouse_radius"`` (int): نصف قطر تفاعل الماوس
            - ``"collision_enabled"`` (bool): تصادم مع الأزرار
            - ``"physics_fps"`` (int): سرعة الفيزياء
            - ``"wind_strength"`` (float): قوة الرياح
            - ``"sparkle_enabled"`` (bool): لمعان القطرات
            - ``"sparkle_color"`` (tuple): لون اللمعان (R, G, B, A)
        width (int): عرض النافذة (افتراضي: 900)
        height (int): ارتفاع النافذة (افتراضي: 650)

    Example (Master Mode):
        >>> window = SirAbodyWindow(
        ...     title="My App",
        ...     rain_config={
        ...         "rain_color": (255, 100, 100),  # مطر أحمر
        ...         "rain_count": 300,
        ...         "rain_speed": (10, 25),
        ...     },
        ...     buttons=[{"text": "Click", "color": "#FFD700", "callback": fn}]
        ... )
    """
    def __init__(self,
                 title="SirAbody",
                 subtitle="Application",
                 buttons=None,
                 version="v1.0",
                 website_url="https://www.SirAbody.com",
                 discord_url="https://discord.gg/509",
                 window_title=None,
                 icon_path=None,
                 title_color="#00BFFF",
                 bg_opacity=180,
                 rain_enabled=True,
                 columns=2,
                 status_text="Ready",
                 status_color="#90EE90",
                 rain_config=None,
                 width=900,
                 height=650):
        super().__init__()

        self._title_text = title
        self._subtitle_text = subtitle
        self._button_configs = buttons or []
        self._version = version
        self._website_url = website_url
        self._discord_url = discord_url
        self._title_color = title_color
        self._bg_opacity = bg_opacity
        self._rain_enabled = rain_enabled
        self._columns = columns
        self._status_text = status_text
        self._status_color = status_color
        self._rain_config = rain_config or {}

        self.setWindowTitle(window_title or title)
        self.resize(width, height)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.last_pos = QPoint(0, 0)

        # Central Widget
        self.central_widget = QWidget()
        self.setCentralWidget(self.central_widget)
        self.central_widget.setStyleSheet(
            f"background-color: rgba(10, 10, 10, {self._bg_opacity}); border-radius: 20px;"
        )

        self.main_layout = QVBoxLayout(self.central_widget)
        self.main_layout.setContentsMargins(0, 0, 0, 0)

        # Rain Layers
        if self._rain_enabled:
            # Shared rain params
            shared_params = {k: v for k, v in self._rain_config.items()
                            if k not in ('rain_count', 'rain_count_bg')}

            bg_count = self._rain_config.get('rain_count_bg', 150)
            fg_count = self._rain_config.get('rain_count', 100)

            self.rain_bg = RainOverlay(self.central_widget, is_foreground=False,
                                       rain_count=bg_count, **shared_params)
            self.rain_bg.lower()

            self.rain_fg = RainOverlay(self.central_widget, is_foreground=True,
                                       rain_count=fg_count, **shared_params)
            self.rain_fg.raise_()
        else:
            self.rain_bg = None
            self.rain_fg = None

        # Build UI
        self._button_widgets = []
        self._setup_header()
        self._setup_buttons()
        self._setup_footer()

    def moveEvent(self, event):
        curr = self.pos()
        if not self.last_pos.isNull():
            dx = curr.x() - self.last_pos.x()
            if self.rain_bg:
                self.rain_bg.apply_inertia(dx)
            if self.rain_fg:
                self.rain_fg.apply_inertia(dx)
        self.last_pos = curr
        super().moveEvent(event)

    def resizeEvent(self, event):
        if self.rain_bg:
            self.rain_bg.resize(self.width(), self.height())
            self.rain_bg.lower()
        if self.rain_fg:
            self.rain_fg.resize(self.width(), self.height())
            self.rain_fg.raise_()
        super().resizeEvent(event)

    def _setup_header(self):
        header_container = QWidget()
        header_layout = QVBoxLayout(header_container)
        header_layout.setContentsMargins(0, 40, 0, 20)

        title = QLabel(self._title_text)
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet(
            f"color: {self._title_color}; font-family: 'Segoe UI'; font-size: 38px; font-weight: bold;"
        )

        subtitle = QLabel(self._subtitle_text)
        subtitle.setAlignment(Qt.AlignCenter)
        subtitle.setStyleSheet("color: #aaa; font-family: 'Segoe UI'; font-size: 14px;")

        header_layout.addWidget(title)
        header_layout.addWidget(subtitle)
        self.main_layout.addWidget(header_container)

    def _setup_buttons(self):
        self.btn_frame = GlowFrame()
        num_buttons = len(self._button_configs)
        rows = math.ceil(num_buttons / self._columns) if num_buttons > 0 else 1
        frame_height = rows * 70 + (rows + 1) * 20 + 60
        self.btn_frame.setFixedSize(700, frame_height)

        grid = QGridLayout(self.btn_frame)
        grid.setSpacing(20)
        grid.setContentsMargins(40, 40, 40, 40)

        self._button_widgets = []
        for i, btn_config in enumerate(self._button_configs):
            text = btn_config.get("text", f"Button {i + 1}")
            color = btn_config.get("color", "#E0F7FA")
            callback = btn_config.get("callback", None)
            start_bg = btn_config.get("bg_color", "#2a2a2a")
            hover_bg = btn_config.get("hover_color", "#3a3a3a")

            btn = ModernButton(text, start_color=start_bg, hover_color=hover_bg, text_color=color)
            if callback:
                btn.clicked.connect(callback)

            row = i // self._columns
            col = i % self._columns
            grid.addWidget(btn, row, col)
            self._button_widgets.append(btn)

        hbox = QHBoxLayout()
        hbox.addStretch()
        hbox.addWidget(self.btn_frame)
        hbox.addStretch()
        self.main_layout.addLayout(hbox)
        self.main_layout.addStretch()

    def _setup_footer(self):
        footer_container = GlowFrame()
        footer_container.setFixedHeight(70)
        footer_container.setStyleSheet(
            "QFrame { background-color: #121212; border-top: 1px solid #333; border-radius: 0px; }"
        )
        layout = QHBoxLayout(footer_container)
        layout.setContentsMargins(20, 0, 20, 0)

        self.btn_web = CircularLinkButton("web", self._website_url, color="#1e1e1e", hover_color="#333")
        layout.addWidget(self.btn_web)
        layout.addSpacing(15)

        self.status_label = QLabel(self._status_text)
        self.status_label.setStyleSheet(
            f"color: {self._status_color}; font-size: 13px; font-weight: bold;"
        )
        self.status_label.setFixedWidth(250)
        layout.addWidget(self.status_label)

        layout.addStretch()

        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setFixedHeight(8)
        self.progress_bar.setFixedWidth(200)
        self.progress_bar.setStyleSheet("""
            QProgressBar { background-color: #222; border: 0px; border-radius: 4px; }
            QProgressBar::chunk { background-color: #00BFFF; border-radius: 4px; }
        """)
        self.progress_bar.hide()
        layout.addWidget(self.progress_bar)

        layout.addStretch()

        version_label = QLabel(self._version)
        version_label.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
        version_label.setStyleSheet("color: #555; font-size: 12px;")
        layout.addWidget(version_label)
        layout.addSpacing(15)

        self.btn_discord = CircularLinkButton("discord", self._discord_url, color="#1e1e1e", hover_color="#5865F2")
        layout.addWidget(self.btn_discord)

        self.main_layout.addWidget(footer_container)

    # ═════════════════════════════════════════════════════════
    #  Public API
    # ═════════════════════════════════════════════════════════

    def set_status(self, text, color=None):
        """تحديث نص الحالة في الفوتر.

        Args:
            text (str): النص الجديد
            color (str, optional): لون النص

        Example:
            >>> window.set_status("Processing...", "#FFA500")
        """
        self.status_label.setText(text)
        if color:
            self.status_label.setStyleSheet(f"color: {color}; font-size: 13px; font-weight: bold;")

    def set_progress(self, value, color="#00BFFF"):
        """تحديث شريط التقدم.

        Args:
            value (int): القيمة (0-100). ارسل -1 لإخفاء الشريط.
            color (str): لون الشريط

        Example:
            >>> window.set_progress(50, "#69F0AE")
            >>> window.set_progress(-1)  # Hide
        """
        if value < 0:
            self.progress_bar.hide()
            return
        self.progress_bar.show()
        self.progress_bar.setValue(value)
        self.progress_bar.setStyleSheet(f"""
            QProgressBar {{ background-color: #222; border: 0px; border-radius: 4px; }}
            QProgressBar::chunk {{ background-color: {color}; border-radius: 4px; }}
        """)

    def set_buttons_enabled(self, enabled):
        """تفعيل أو تعطيل جميع الأزرار.

        Args:
            enabled (bool): True للتفعيل، False للتعطيل
        """
        for btn in self._button_widgets:
            btn.setEnabled(enabled)

    def get_button(self, index):
        """الحصول على زر بالفهرس.

        Args:
            index (int): رقم الزر (يبدأ من 0)

        Returns:
            ModernButton or None
        """
        if 0 <= index < len(self._button_widgets):
            return self._button_widgets[index]
        return None

    def get_rain(self):
        """الحصول على طبقة المطر الأمامية للتحكم المباشر.

        Returns:
            RainOverlay or None

        Example (Master Mode):
            >>> rain = window.get_rain()
            >>> rain.set_rain_color(255, 0, 0)  # مطر أحمر
            >>> rain.set_rain_count(300)          # عدد أكثر
        """
        return self.rain_fg

    def get_rain_bg(self):
        """الحصول على طبقة المطر الخلفية.

        Returns:
            RainOverlay or None
        """
        return self.rain_bg


# ═══════════════════════════════════════════════════════════════
#  SirAbodyApp (Master Mode Runner)
# ═══════════════════════════════════════════════════════════════

class SirAbodyApp:
    """غلاف مريح لتشغيل التطبيق.

    يدعم جميع خيارات SirAbodyWindow.

    Example:
        >>> app = SirAbodyApp(
        ...     title="My App",
        ...     buttons=[
        ...         {"text": "Button 1", "color": "#FFD700", "callback": fn1},
        ...     ],
        ... )
        >>> app.run()
    """
    def __init__(self, **kwargs):
        self._kwargs = kwargs
        self._app = None
        self._window = None

    def run(self):
        """تشغيل التطبيق."""
        QApplication.setAttribute(Qt.AA_UseDesktopOpenGL)

        self._app = QApplication(sys.argv)

        icon_path = self._kwargs.pop("icon_path", None)
        if icon_path and os.path.exists(icon_path):
            self._app.setWindowIcon(QIcon(icon_path))

        font = QFont("Segoe UI", 10)
        self._app.setFont(font)

        self._window = SirAbodyWindow(**self._kwargs)
        self._window.show()
        sys.exit(self._app.exec())

    @property
    def window(self):
        """الوصول للنافذة الرئيسية."""
        return self._window


# ═══════════════════════════════════════════════════════════════
#  Easy Mode
# ═══════════════════════════════════════════════════════════════

def easy(title, button_names, subtitle="", on_click=None, **kwargs):
    """Easy Mode - أسهل طريقة لإنشاء واجهة رسومية.

    طريقتين للاستخدام:

    الطريقة 1 - قائمة أسماء (list):
        >>> sirabody.easy("My App", ["Button 1", "Button 2"])

    الطريقة 2 - قاموس اسم:وظيفة (dict) - الأسهل!:
        >>> sirabody.easy("My App", {
        ...     "Google": open_google,
        ...     "YouTube": open_youtube,
        ... })

    Args:
        title (str): عنوان التطبيق
        button_names: إما list بأسماء الأزرار أو dict بأسماء ووظائف
            - list: ["Button 1", "Button 2"] (مجرد أسماء)
            - dict: {"Button 1": function1, "Button 2": function2} (اسم + وظيفة)
        subtitle (str): عنوان فرعي (اختياري)
        on_click (callable): دالة تُستدعى عند الضغط (فقط مع list)
        **kwargs: أي خيارات إضافية من SirAbodyApp
    """
    buttons = []

    # الطريقة 2: dict = {"اسم الزر": الوظيفة}
    if isinstance(button_names, dict):
        for i, (name, func) in enumerate(button_names.items()):
            color = _EASY_COLORS[i % len(_EASY_COLORS)]
            btn = {"text": name, "color": color, "callback": func}
            buttons.append(btn)

    # الطريقة 1: list = ["اسم الزر"]
    else:
        for i, name in enumerate(button_names):
            color = _EASY_COLORS[i % len(_EASY_COLORS)]
            btn = {"text": name, "color": color}
            if on_click:
                btn["callback"] = (lambda n: lambda: on_click(n))(name)
            buttons.append(btn)

    app = SirAbodyApp(
        title=title,
        subtitle=subtitle,
        buttons=buttons,
        **kwargs
    )
    app.run()


def resource_path(relative_path):
    """الحصول على المسار الكامل للملف (يدعم PyInstaller).

    Args:
        relative_path (str): المسار النسبي

    Returns:
        str: المسار الكامل
    """
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)
