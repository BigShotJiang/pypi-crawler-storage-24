"""
UI components: ModernButton, CircularLinkButton, GlowFrame.
عناصر الواجهة: أزرار حديثة، أزرار دائرية، إطار شفاف.
"""

from PySide6.QtWidgets import QPushButton, QFrame
from PySide6.QtCore import Qt, QPoint, QRect, QUrl
from PySide6.QtGui import QPainter, QColor, QFont, QPen, QDesktopServices, QPainterPath


class ModernButton(QPushButton):
    """زر حديث بتأثيرات hover و pressed.

    Args:
        text: نص الزر
        start_color: لون الخلفية العادي (افتراضي: "#2a2a2a")
        hover_color: لون الخلفية عند المرور (افتراضي: "#3a3a3a")
        text_color: لون النص (افتراضي: "#E0F7FA")
        parent: العنصر الأب

    Example:
        >>> btn = ModernButton("Click Me", text_color="#FFD700")
        >>> btn.clicked.connect(my_function)
    """
    def __init__(self, text, start_color="#2a2a2a", hover_color="#3a3a3a", text_color="#E0F7FA", parent=None):
        super().__init__(text, parent)
        self.setCursor(Qt.PointingHandCursor)
        self.setFixedHeight(50)
        self.setFont(QFont("Segoe UI", 11, QFont.Bold))

        self.setStyleSheet(f"""
            QPushButton {{
                background-color: {start_color};
                color: {text_color};
                border: 1px solid #444;
                border-radius: 10px;
                padding: 10px;
            }}
            QPushButton:hover {{
                background-color: {hover_color};
                border: 1px solid {text_color};
                color: {text_color};
            }}
            QPushButton:pressed {{
                background-color: #1a1a1a;
            }}
            QPushButton:disabled {{
                background-color: #1a1a1a;
                color: #555;
                border: 1px solid #222;
            }}
        """)


class CircularLinkButton(QPushButton):
    """زر دائري مع أيقونة SVG يفتح رابط في المتصفح.

    Args:
        icon_type: نوع الأيقونة ('web' أو 'discord')
        url: الرابط اللي يفتحه الزر
        color: لون الخلفية (افتراضي: "#2a2a2a")
        hover_color: لون الخلفية عند المرور (افتراضي: "#3a3a3a")
        parent: العنصر الأب

    Example:
        >>> btn = CircularLinkButton("discord", "https://discord.gg/my-server")
    """
    def __init__(self, icon_type, url, color="#2a2a2a", hover_color="#3a3a3a", parent=None):
        super().__init__(parent)
        self.setCursor(Qt.PointingHandCursor)
        self.setFixedSize(50, 50)
        self.url = url
        self.icon_type = icon_type
        self.base_color = QColor(color)
        self.hover_color = QColor(hover_color)
        self.current_color = self.base_color
        self.clicked.connect(self.open_link)

    def open_link(self):
        QDesktopServices.openUrl(QUrl(self.url))

    def enterEvent(self, event):
        self.current_color = self.hover_color
        self.update()
        super().enterEvent(event)

    def leaveEvent(self, event):
        self.current_color = self.base_color
        self.update()
        super().leaveEvent(event)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        # Background circle
        painter.setPen(Qt.NoPen)
        painter.setBrush(self.current_color)
        painter.drawEllipse(0, 0, self.width(), self.height())

        # Border
        painter.setBrush(Qt.NoBrush)
        painter.setPen(QPen(QColor("#444"), 1))
        painter.drawEllipse(0, 0, self.width(), self.height())

        # Icon
        painter.setPen(QPen(Qt.white, 2))
        painter.setBrush(Qt.NoBrush)
        cx, cy = self.width() // 2, self.height() // 2

        if self.icon_type == 'web':
            r = 10
            painter.drawEllipse(QPoint(cx, cy), r, r)
            painter.drawEllipse(QPoint(cx, cy), r, r // 2.5)
            painter.drawEllipse(QPoint(cx, cy), r // 2.5, r)

        elif self.icon_type == 'discord':
            w, h = 22, 16
            rect = QRect(cx - w // 2, cy - h // 2, w, h)
            path = QPainterPath()
            path.addRoundedRect(rect, 5, 5)
            painter.setBrush(Qt.white)
            painter.setPen(Qt.NoPen)
            painter.drawPath(path)
            painter.setBrush(self.current_color)
            painter.drawEllipse(cx - 5, cy - 2, 3, 3)
            painter.drawEllipse(cx + 2, cy - 2, 3, 3)


class GlowFrame(QFrame):
    """إطار شفاف بدون حدود (يستخدم كحاوية للمحتوى)."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet("""
            QFrame {
                background-color: transparent;
                border: none;
            }
        """)
