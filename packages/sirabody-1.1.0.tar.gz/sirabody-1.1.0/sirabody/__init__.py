"""
SirAbody GUI Library
====================
Modern PySide6 GUI toolkit with realistic rain physics.

=== Easy Mode (أسهل شي بالحياة) ===

    >>> import sirabody
    >>>
    >>> app = sirabody.App("My App")
    >>> app.add("Google", link="https://google.com")
    >>> app.add("YouTube", link="https://youtube.com")
    >>> app.add("Say Hello", message="Hello World!")
    >>> app.run()

=== Master Mode (تحكم كامل) ===

    >>> from sirabody import SirAbodyApp
    >>> app = SirAbodyApp(
    ...     title="My App",
    ...     buttons=[{"text": "Click", "color": "#FFD700", "callback": fn}],
    ...     rain_config={"rain_color": (255, 0, 0)},
    ... )
    >>> app.run()
"""

__version__ = "1.1.0"
__author__ = "SirAbody"

# Easy Mode
from .easy import App

# Master Mode
from .window import SirAbodyApp, SirAbodyWindow, easy, resource_path
from .components import ModernButton, CircularLinkButton, GlowFrame
from .rain import RainOverlay

__all__ = [
    # Easy Mode
    "App",
    "easy",
    # Master Mode
    "SirAbodyApp",
    "SirAbodyWindow",
    "ModernButton",
    "CircularLinkButton",
    "GlowFrame",
    "RainOverlay",
    # Utility
    "resource_path",
]
