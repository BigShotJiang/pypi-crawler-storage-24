"""Entry type enumeration."""

from enum import Enum


class EntryType(str, Enum):
    """Delay entry type enum.

    Used to specify the entry direction relative to price movement.

    Values:
        FAVORABLE: Enter on price pullback (better entry price)
        ADVERSE: Enter on price continuation (worse entry price)
    """

    FAVORABLE = "favorable"
    ADVERSE = "adverse"
