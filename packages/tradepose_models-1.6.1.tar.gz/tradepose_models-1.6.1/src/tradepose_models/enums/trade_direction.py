"""Trade direction enumeration."""

from enum import Enum


class TradeDirection(str, Enum):
    """Trade direction enum.

    Used to specify the trading direction in Blueprint.
    String values match Rust's TradeDirection enum.
    """

    LONG = "Long"
    SHORT = "Short"

    def to_int(self) -> int:
        """Convert to integer multiplier (1=Long, -1=Short).

        Matches Rust's direction_multiplier() function.
        """
        if self == TradeDirection.LONG:
            return 1
        return -1

    @classmethod
    def from_int(cls, value: int) -> "TradeDirection":
        """Create from integer multiplier (1=Long, -1=Short)."""
        if value == 1:
            return cls.LONG
        elif value == -1:
            return cls.SHORT
        else:
            raise ValueError(f"Invalid direction int: {value}. Expected 1 or -1.")
