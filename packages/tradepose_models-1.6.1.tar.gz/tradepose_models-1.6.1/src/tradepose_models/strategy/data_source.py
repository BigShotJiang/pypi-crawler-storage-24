"""DataSource Model

Declares an (instrument, freq) pair for multi-instrument OHLCV loading.
"""

from typing import Optional

from pydantic import BaseModel, Field

from ..enums import Freq


class DataSource(BaseModel):
    """Multi-instrument data source declaration.

    Tells the engine which (instrument, freq) combinations to load from DB,
    enabling cross-instrument indicators to resolve via MarketDataEngine resample.
    """

    instrument: str = Field(..., description="Instrument key (e.g. 'FTMO:swap:XAUUSD')")
    instrument_id: Optional[int] = Field(
        None, description="Instrument DB ID (populated by Gateway)"
    )
    freq: Freq = Field(..., description="Base loading frequency for this instrument")
