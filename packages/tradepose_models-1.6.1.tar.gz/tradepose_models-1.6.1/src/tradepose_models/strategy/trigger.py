"""
Trigger Model

Provides the Trigger class for entry/exit triggers with conditions and price expressions.
"""

from typing import Any, List

import polars as pl
from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    field_serializer,
    field_validator,
)

from ..enums import OrderStrategy
from ..indicators import PolarsExprField, PolarsExprType


class Trigger(BaseModel):
    """進出場觸發器

    使用方式：
    - 讀取：trigger.conditions 直接得到 List[pl.Expr]
    - 寫入：可直接賦值 pl.col("close") > 100

    offset_expr 說明：
    - offset_expr 代表距離（如 col("atr") * 2.0）
    - 最終價格由 order_strategy + direction 自動計算
    - 例如：StopLoss Long 會計算 entry_price - offset
    """

    name: str = Field(..., description="觸發器名稱")
    order_strategy: OrderStrategy = Field(..., description="訂單策略（OrderStrategy enum）")
    priority: int = Field(..., description="優先級（1-100，數字越小優先級越高）")

    # 使用 PolarsExprType 以支援 JSON Schema 生成
    conditions: List[PolarsExprType] = Field(
        default_factory=list, description="條件列表（Polars Expr）"
    )
    offset_expr: PolarsExprType = Field(
        ...,
        description="偏移量表達式（Polars Expr）。Rust 端會根據 order_strategy 和 direction 轉換為實際價格。",
    )
    note: str = Field(default="", description="觸發器備註")

    @field_validator("order_strategy", mode="before")
    @classmethod
    def convert_order_strategy(cls, v: Any) -> OrderStrategy:
        """自動轉換字串為 OrderStrategy enum（保持 API 兼容性）"""
        if isinstance(v, str):
            try:
                return OrderStrategy(v)
            except ValueError:
                valid_values = [e.value for e in OrderStrategy]
                raise ValueError(
                    f"Invalid order_strategy: '{v}'. Valid values: {', '.join(valid_values)}"
                )
        return v

    @field_validator("conditions", mode="before")
    @classmethod
    def validate_conditions(cls, v: Any) -> List[pl.Expr]:
        """自動轉換 conditions 為 List[pl.Expr]"""
        if not v:
            return []

        result = []
        for item in v:
            result.append(PolarsExprField.deserialize(item))
        return result

    @field_validator("offset_expr", mode="before")
    @classmethod
    def validate_offset_expr(cls, v: Any) -> pl.Expr:
        """自動轉換 offset_expr 為 pl.Expr"""
        if v is None:
            raise ValueError("offset_expr 是必填欄位")
        return PolarsExprField.deserialize(v)

    @field_serializer("conditions")
    def serialize_conditions(self, conditions: List[pl.Expr]) -> List[dict]:
        """序列化 conditions 為 dict 列表（與服務器格式一致）"""
        return [PolarsExprField.serialize(expr) for expr in conditions]

    @field_serializer("offset_expr")
    def serialize_offset_expr(self, offset_expr: pl.Expr) -> dict:
        """序列化 offset_expr 為 dict（與服務器格式一致）"""
        return PolarsExprField.serialize(offset_expr)

    model_config = ConfigDict(
        arbitrary_types_allowed=True  # 允許 pl.Expr 這種自定義類型
    )
