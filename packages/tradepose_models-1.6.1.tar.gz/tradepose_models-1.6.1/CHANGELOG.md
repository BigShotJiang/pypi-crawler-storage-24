# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.6.0] - 2026-03-24

### Breaking Changes

- 移除 `TradeDirection.BOTH` — 所有策略設定必須改為明確的 `LONG` / `SHORT`
- 移除 `EntryType` enum — `BlueprintBuilder.sweep()` 的 `entry_type` 參數改接受 `str`
- `StrategyParams.sweep()` 改名為 `_sweep()` — 強調應透過 `BlueprintBuilder.sweep()` 進行 sweep

### Added

- `StrategyParams` — 輕量級策略參數基類，支援 `instrument`, `base_freq`, `trade_direction`, `tz` (ZoneInfo)
- `StrategyParams` 繼承 ABC，強制子類實作 `create_strategy() -> StrategyConfig` 抽象方法
- `StrategyConfig.tz: str` — Rust engine 時區轉換欄位（預設 "UTC"）
- `DataSource(instrument, freq)` — 多商品 OHLCV 依賴宣告
- `StrategyConfig.data_sources: list[DataSource]`
- `RunRequest` — 新 Pydantic model，含 mutual-exclusion validator（`blueprint_ids` 與 `portfolio_id` 二擇一）
- 新增 `AccountSource`: Pepperstone / IC Markets / Exness（timezone: Europe/Athens）
- `AccountSource.timezone()` 和 `AccountSource.tz_offset()` 動態時區解析
- `expected_loss` fields persist — blueprint INSERT 寫入 expected loss 欄位 (#808)

### Changed

- `StrategyConfig` — 新增 `adv_bp_map`, `adv_bp_summary`, `get_adv_bp()`, `with_adv_blueprints()`, `indicator_map`, `get_indicator()` 便捷方法
- MarketProfile Indicator API 改為 structured mode config — `create_daily_mode()`, `create_weekly_mode()`, `create_intraday_mode()`
- Scope 模組重構 — 新增 `types.py`（`TRADES_SCHEMA`, analysis scope levels, entry/exit reason enums）
- `expected_loss_pct` → `expected_loss_point` — 移除 legacy MAE calculator，改用 point-based 計算
- Schema 欄位擴展為 TEXT，改善 blueprint 計算 (#806)

### Fixed

- MT5 `market_type` silent fallback — 未知 market type 不再拋錯，改為靜默降級 (#887)
- Instrument upsert 遺漏 `point_value` 欄位 (#888)

## [1.5.0] - 2026-02-07

### Added

- `get_indicator(name)` — 透過名稱查找指標的便捷方法
- `Trigger.note` — 觸發條件備註欄位

### Fixed

- Market Profile anchor_ts 邏輯修正（IB mode）

## [1.4.0] - 2026-02-05

### Added

- `Instrument.point_value` — 用於 position sizing 的合約乘數
- `broker_time` 欄位 — MT5 server timestamp 支援
- Exit hypo price pre-calculation with entry fallback
- `expected_loss_pct` — 當 `adverse_exit_hypo_price` 為 NULL 時的 SL 計算

### Fixed

- `Indicator` validation：移除與 Rust upper limits 不一致的驗證

## [1.3.0] - 2026-01-22

### Added

- `BlueprintBuilder.priority` 改為 optional，預設值 1

## [1.2.0] - 2026-01-19

### Added

- `EngagementContext` and Signal execution framework for engagement management
- `TradesPersistedEvent` for stream communication between worker and gateway
- `account_source` parameter for MT5 accounts differentiation

### Fixed

- `WithJsonSchema` annotation for `pl.Expr` fields to fix OpenAPI schema generation

## [1.1.0] - 2025-12-21

### Added

- `BatchOHLCVDownloadEvent.end_time`: 結束時間欄位（None = 自動填為 now + 30 天）
- `BatchOHLCVDownloadEvent.force_full`: 強制完整下載欄位（忽略 DB 現有資料）

### Fixed

- 使用 timezone-aware `datetime.now(timezone.utc)` 取代已棄用的 `datetime.utcnow()`

## [1.0.0] - 2025-11-29

### Breaking Changes

- First stable release with breaking changes from 0.1.x series

### Added

- Stable API for all models

## [0.1.0] - 2025-11-29 (deprecated)

### Added

- Initial release
- Pydantic models for strategy configuration (StrategyConfig, Blueprint, Trigger)
- Enums: Freq, IndicatorType, OrderStrategy, TradeDirection, TrendType
- Export models: ExportRequest, ExportResponse
- Billing models: DetailedUsageResponse
- Auth models: API key management (ApiKeyResponse, CreateApiKeyResponse)
- Indicator models and specifications
- Polars schema definitions for trades and performance data
