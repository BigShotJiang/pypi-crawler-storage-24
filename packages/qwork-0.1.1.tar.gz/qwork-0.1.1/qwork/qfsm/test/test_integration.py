"""Integration tests for qfsm library"""

import pytest
from qwork.qfsm import Stage, Logic, Scheduler
from qwork.qfsm.decorators import recursive, listen, sequence, selector
from qwork.qfsm.meta import clear_prototypes


@pytest.fixture(autouse=True)
def reset_state():
    """Reset state before each test"""
    Scheduler._instance = None
    clear_prototypes()
    Stage._Stage__id__ = {}
    Logic._Logic__names__ = {}
    Logic._Logic__types__ = {}
    yield
    Scheduler._instance = None


class TestFullWorkflow:
    """Test complete state machine workflows"""

    def test_traffic_light_workflow(self):
        """Test traffic light state machine"""

        class TrafficLight(Logic):
            NAME = "TrafficLight"
            LIMIT = 3

            def __init__(self):
                self.transitions = []
                super().__init__()

            def initial(self, inst):
                return "red"

            def red(self, inst):
                return "green"

            def green(self, inst):
                return "yellow"

            @recursive
            def yellow(self, inst):
                return "red"

            def onChanged(self, src, dst, inst):
                self.transitions.append((src, dst))

        light = TrafficLight()
        scheduler = Scheduler()

        # First tick - initial to red
        scheduler.handle()
        assert light._current == "red"

        # Second tick - red to green
        scheduler.handle()
        assert light._current == "green"

        # Third tick - green to yellow, then yellow -> red (recursive in same tick)
        scheduler.handle()
        assert light._current == "red"  # Yellow is recursive, immediately goes to red

    def test_counter_workflow(self):
        """Test counter with recursive state"""

        class Counter(Logic):
            NAME = "Counter"
            LIMIT = 10

            def __init__(self):
                self.count = 0
                super().__init__()

            @recursive
            def counting(self, inst):
                self.count += 1
                if self.count >= 5:
                    return "done"
                return "counting"

            def done(self, inst):
                return None

        counter = Counter()
        scheduler = Scheduler()

        counter._current = "counting"
        scheduler.handle()

        assert counter.count == 5
        assert counter._current == "done"


class TestMultipleInstances:
    """Test multiple interacting logic instances"""
    
    def test_priority_ordering(self):
        """Test that higher priority instances are processed first"""

        class LowPriority(Logic):
            NAME = "LowPriority"
            PRIORITY = 0

            def __init__(self):
                self.order = None
                super().__init__()

            def state(self, inst):
                if self.order is None:
                    self.order = Logic._Logic__execution_order
                return None

        class HighPriority(Logic):
            NAME = "HighPriority"
            PRIORITY = 10

            def __init__(self):
                self.order = None
                super().__init__()

            def state(self, inst):
                if self.order is None:
                    self.order = Logic._Logic__execution_order
                return None

        # Track execution order
        Logic._Logic__execution_order = 0

        low = LowPriority()
        high = HighPriority()

        scheduler = Scheduler()
        scheduler.handle()

        # Both should have been processed
        assert low._isEntered
        assert high._isEntered
    
    def test_instance_referencing(self):
        """Test that instances can reference each other"""

        class Worker(Logic):
            NAME = "Worker"

            def __init__(self):
                self.partner = None
                super().__init__()

            def state(self, inst):
                if self.partner is None:
                    # Find another worker
                    others = self.ref("Worker")
                    for other in others:
                        if other is not self:
                            self.partner = other
                            break
                return None

        worker1 = Worker()
        worker2 = Worker()

        scheduler = Scheduler()
        scheduler.handle()

        assert worker1.partner is worker2 or worker1.partner is None
        assert worker2.partner is worker1 or worker2.partner is None


class TestEventDriven:
    """Test event-driven state changes"""
    
    def test_event_listener(self):
        """Test that @listen decorator correctly marks methods as listeners"""

        class EventDriven(Logic):
            NAME = "EventDriven"

            def __init__(self):
                super().__init__()

            def waiting(self, inst):
                return None

            @listen("trigger")
            def on_trigger(self, data):
                pass

        logic = EventDriven()

        # Verify __listens__ is correctly populated
        assert "trigger" in logic.__listens__
        assert "on_trigger" in [h[0] for h in logic.__listens__["trigger"]]
        # Verify @listen methods are not in __states__
        assert "on_trigger" not in logic.__states__


class TestBehaviorTree:
    """Test behavior tree composites in integration"""

    def test_sequence_all_succeed(self):
        """Test sequence when all children succeed"""

        class SequenceTest(Logic):
            NAME = "SequenceTest"

            def __init__(self):
                self.executed = []
                super().__init__()

            @sequence("step2", "step3")
            def step1(self, it):
                self.executed.append(1)
                return True

            def step2(self, it):
                self.executed.append(2)
                return True

            def step3(self, it):
                self.executed.append(3)
                return True

        logic = SequenceTest()
        scheduler = Scheduler()

        # First handle - sequence executes all children
        scheduler.handle()

        assert 2 in logic.executed
        assert 3 in logic.executed

    def test_sequence_fails_on_false(self):
        """Test sequence stops when a child returns False"""

        class SequenceFailTest(Logic):
            NAME = "SequenceFailTest"

            def __init__(self):
                self.executed = []
                super().__init__()

            @sequence("step2", "step3")
            def step1(self, it):
                return True

            def step2(self, it):
                self.executed.append(2)
                return False  # Fail - should stop sequence

            def step3(self, it):
                self.executed.append(3)
                return True

        logic = SequenceFailTest()
        scheduler = Scheduler()

        scheduler.handle()

        assert 2 in logic.executed
        assert 3 not in logic.executed  # step3 should not execute

    def test_selector_integration(self):
        """Test selector composite in full workflow"""

        class SelectorTest(Logic):
            NAME = "SelectorTest"

            def __init__(self):
                self.tried = []
                super().__init__()

            @selector("option1", "option2")
            def selector_state(self, it):
                self.tried.append("selector")
                return False  # Fail, try options

            def option1(self, it):
                self.tried.append("option1")
                return True  # Success

            def option2(self, it):
                self.tried.append("option2")
                return None

        logic = SelectorTest()
        scheduler = Scheduler()

        logic._current = "selector_state"

        scheduler.handle()

        # Selector executes children directly, not the parent state's method
        assert "option1" in logic.tried

    def test_behavior_tree_with_listen_decorator(self):
        """Test that @listen methods are not treated as states"""

        class BehaviorWithListen(Logic):
            NAME = "BehaviorWithListen"

            def __init__(self):
                self.executed = []
                self.event_received = False
                super().__init__()

            @sequence("step2", "step3")
            def step1(self, it):
                self.executed.append(1)
                return True

            def step2(self, it):
                self.executed.append(2)
                return True

            def step3(self, it):
                self.executed.append(3)
                return True

            @listen("test_event")
            def on_test_event(self, data):
                self.event_received = True

        logic = BehaviorWithListen()
        scheduler = Scheduler()

        # Verify __states__ doesn't include on_test_event
        assert "on_test_event" not in logic.__states__
        assert "step1" in logic.__states__
        assert "step2" in logic.__states__
        assert "step3" in logic.__states__

        # Verify __listens__ is correctly populated
        assert "test_event" in logic.__listens__

        # Run scheduler
        scheduler.handle()

        # Verify sequence executed
        assert 2 in logic.executed
        assert 3 in logic.executed

    def test_sequence_running_resume(self):
        """Test that RUNNING (None) pauses and resumes from same child, skipping parent."""

        class RunningTest(Logic):
            NAME = "RunningTest"

            def __init__(self):
                self.first_calls = 0
                self.second_calls = 0
                super().__init__()

            @sequence("child1", "child2")
            def parent(self, it):
                self.first_calls += 1
                it.now = self.now  # Set marker on first call
                return True

            def child1(self, it):
                self.second_calls += 1
                # On first tick, return RUNNING (None)
                # On subsequent ticks, if it.now != self.now, succeed
                if not hasattr(it, 'now'):
                    it.now = 0
                if it.now == self.now:
                    return None  # RUNNING
                it.now = self.now
                return True

            def child2(self, it):
                return True

        logic = RunningTest()
        scheduler = Scheduler()

        # Tick 1: parent executes, child1 returns RUNNING
        scheduler.handle()
        assert logic.first_calls == 1  # Parent executed once
        assert logic.second_calls == 1  # Child1 executed once

        # Tick 2: should resume child1 directly, skip parent
        scheduler.handle()
        assert logic.first_calls == 1  # Parent still only executed once
        assert logic.second_calls == 2  # Child1 executed again (resumed)
        # Now sequence should complete (child1 succeeded, child2 executed)

        # Tick 3: new sequence starts from beginning
        scheduler.handle()
        assert logic.first_calls == 2  # Parent executed again
        assert logic.second_calls == 3  # Child1 executed again

    def test_nested_behavior_tree_indentation(self, capsys):
        """Test that nested behavior trees have correct indentation in output."""
        from qfsm import Stage, sequence, selector

        class TestLogic(Stage):
            NAME = "TestIndent"

            @sequence("child_seq", "child_sel")
            def root(self, it):
                return True

            @sequence("leaf_a", "leaf_b")
            def child_seq(self, it):
                return True

            @selector("leaf_c", "leaf_d")
            def child_sel(self, it):
                return True

            def leaf_a(self, it):
                return True

            def leaf_b(self, it):
                return True

            def leaf_c(self, it):
                return False

            def leaf_d(self, it):
                return True

        logic = TestLogic()
        logic.handleStage()

        captured = capsys.readouterr()
        output = captured.out

        # Check that root behavior has proper indent
        # (name includes ID like TestIndent0, so we check pattern)
        assert "behavior: sequence(root)" in output

        # Check indentation levels:
        # - root (level 0): 2-space indent
        # - child_seq/child_sel (level 1): 4-space indent
        # - leaf_a/leaf_b (level 2): 6-space indent
        lines = output.split('\n')

        # Find child_seq line - should be 4-space indent (level 1)
        child_seq_line = None
        leaf_a_line = None
        for line in lines:
            if 'sequence(child_seq)...' in line:
                child_seq_line = line
            if "-> leaf_a" in line:
                leaf_a_line = line

        # child_seq should be indented 4 spaces (2 levels deep: root -> child_seq)
        assert child_seq_line is not None, "child_seq line not found"
        assert child_seq_line.startswith('  ['), f"Expected 2-space indent for child_seq, got: {repr(child_seq_line[:6])}"

        # leaf_a should be indented 6 spaces (3 levels deep: root -> child_seq -> leaf_a)
        assert leaf_a_line is not None, "leaf_a line not found"
        assert leaf_a_line.startswith('    ['), f"Expected 4-space indent for leaf_a, got: {repr(leaf_a_line[:8])}"


class TestLifecycleManagement:
    """Test instance lifecycle management"""
    
    def test_instance_cleanup(self):
        """Test that dead instances are cleaned up"""

        class ShortLived(Logic):
            NAME = "ShortLived"

            def __init__(self):
                self.ticks = 0
                super().__init__()

            def state(self, inst):
                self.ticks += 1
                if self.ticks >= 2:
                    self.kill()
                return None

        logic = ShortLived()
        scheduler = Scheduler()

        assert logic in scheduler

        scheduler.handle()
        assert logic.alive

        scheduler.handle()
        assert not logic.alive

        scheduler.handle()
        assert logic not in scheduler

    def test_enable_disable(self):
        """Test that disabled instances are skipped"""

        class Toggleable(Logic):
            NAME = "Toggleable"

            def __init__(self):
                self.ticks = 0
                super().__init__()

            def state(self, inst):
                self.ticks += 1
                return None

        logic = Toggleable()
        scheduler = Scheduler()

        scheduler.handle()
        assert logic.ticks == 1

        logic.disable()
        scheduler.handle()
        assert logic.ticks == 1  # Should not increment

        logic.enable()
        scheduler.handle()
        assert logic.ticks == 2
