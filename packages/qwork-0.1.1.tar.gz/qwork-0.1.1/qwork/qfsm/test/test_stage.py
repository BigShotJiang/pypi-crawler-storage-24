"""Tests for Stage class"""

import pytest
from qwork.qfsm.stage import Stage, _NamedNode
from qwork.qfsm.meta import clear_prototypes, StageMachineMeta
from qwork.qfsm.decorators import recursive, behavior, sequence, selector, parallel


@pytest.fixture(autouse=True)
def reset_state():
    """Reset state before each test"""
    clear_prototypes()
    StageMachineMeta._StageMachineMeta__ID_PROTOS__ = {}
    yield


class TestNamedNode:
    """Test _NamedNode base class"""
    
    def test_parent_child_relationship(self):
        """Test parent-child relationships"""
        parent = _NamedNode()
        parent._name = "parent"
        child = _NamedNode()
        child._name = "child"
        
        parent._add_child(child)

        assert child.parent is parent
        assert child in parent._children

    def test_remove_child(self):
        """Test removing a child"""
        parent = _NamedNode()
        parent._name = "parent"
        child = _NamedNode()
        child._name = "child"

        parent._add_child(child)
        parent._remove_child(child)
        
        assert child.parent is None
        assert child not in parent._children


class TestStageInit:
    """Test Stage initialization"""
    
    def test_stage_requires_name(self):
        """Test that Stage requires NAME"""
        
        class BadStage(Stage):
            NAME = ""
        
        with pytest.raises(ValueError):
            BadStage()
    
    def test_stage_rejects_digit_suffix_name(self):
        """Test that Stage rejects NAME ending with digit"""

        with pytest.raises(ValueError):
            class BadStage(Stage):
                NAME = "BadStage1"
    
    def test_stage_generates_unique_ids(self):
        """Test that Stage generates unique IDs"""
        
        class TestStage(Stage):
            NAME = "TestStage"
        
        stage1 = TestStage()
        stage2 = TestStage()
        
        assert stage1.uid != stage2.uid
        assert stage1.uid == 0
        assert stage2.uid == 1
    
    def test_stage_full_name(self):
        """Test that Stage generates full name with uid"""
        
        class TestStage(Stage):
            NAME = "TestStage"
        
        stage = TestStage()
        
        assert stage.name == "TestStage0"
        assert stage._name == "TestStage0"


class TestStageStates:
    """Test state execution"""
    
    def test_stage_executes_initial_state(self):
        """Test that stage executes initial state"""
        
        class TestStage(Stage):
            NAME = "TestStage"
            
            def initial(self, inst):
                return None
        
        stage = TestStage()
        stage._current = "initial"
        
        result = stage.handleStage(log=False)
        
        assert stage.current == "initial"
    
    def test_stage_transitions_state(self):
        """Test that stage transitions on state return"""
        
        class TestStage(Stage):
            NAME = "TestStage"
            
            def state_a(self, inst):
                return "state_b"
            
            def state_b(self, inst):
                return None
        
        stage = TestStage()
        stage._current = "state_a"
        
        stage.handleStage(log=False)
        
        assert stage.current == "state_b"
    
    def test_stage_recursive_execution(self):
        """Test recursive state execution"""
        
        class TestStage(Stage):
            NAME = "TestStage"
            
            @recursive
            def counter(self, inst):
                if not hasattr(self, 'count'):
                    self.count = 0
                self.count += 1
                if self.count >= 3:
                    return "done"
                return "counter"
            
            def done(self, inst):
                return None
        
        stage = TestStage()
        stage._current = "counter"
        
        stage.handleStage(log=False)
        
        assert stage.count == 3
        assert stage.current == "done"


class TestStageBehaviorTree:
    """Test behavior tree composites"""
    
    def test_behavior_transition(self):
        """Test @behavior decorator"""
        
        class TestStage(Stage):
            NAME = "TestStage"
            
            @behavior("second")
            def first(self, inst):
                return True  # Success triggers behavior
            
            def second(self, inst):
                return None
        
        stage = TestStage()
        stage._current = "first"
        
        stage.handleStage(log=False)
        
        assert stage.current == "second"
    
    def test_sequence_execution(self):
        """Test @sequence decorator"""
        
        class TestStage(Stage):
            NAME = "TestStage"
            
            @sequence("b", "c")
            def a(self, inst):
                return True

            def b(self, inst):
                return True
            
            def c(self, inst):
                return None
        
        stage = TestStage()
        stage._current = "a"
        
        # First call enters sequence
        stage.handleStage(log=False)
        # Should be at "b" now
        assert stage.current == "b"
    
    def test_selector_execution(self):
        """Test @selector decorator"""
        
        class TestStage(Stage):
            NAME = "TestStage"
            
            @selector("b", "c")
            def a(self, inst):
                return False  # Failure triggers selector

            def b(self, inst):
                return True  # Success stops selector
            
            def c(self, inst):
                return None
        
        stage = TestStage()
        stage._current = "a"
        
        stage.handleStage(log=False)
        
        # After a fails, should try b
        assert stage.current == "b"


class TestStageHooks:
    """Test lifecycle hooks"""
    
    def test_onchanged_hook(self):
        """Test onChanged hook is called"""
        
        class TestStage(Stage):
            NAME = "TestStage"
            
            def __init__(self):
                super().__init__()
                self.changes = []
            
            def state_a(self, inst):
                return "state_b"
            
            def state_b(self, inst):
                return None
            
            def onChanged(self, src, dst, inst):
                self.changes.append((src, dst))
        
        stage = TestStage()
        stage._current = "state_a"
        
        stage.handleStage(log=False)
        
        assert ("state_a", "state_b") in stage.changes
    
    def test_onloading_hook(self):
        """Test onLoading hook is called"""
        
        class TestStage(Stage):
            NAME = "TestStage"
            
            def __init__(self):
                self.loaded = False
                super().__init__()
            
            def onLoading(self, it):
                self.loaded = True
        
        stage = TestStage()
        
        assert stage.loaded


class TestStageProperties:
    """Test Stage properties"""
    
    def test_inst_property(self):
        """Test inst property"""
        
        class TestStage(Stage):
            NAME = "TestStage"
        
        mock_inst = object()
        stage = TestStage(mock_inst)
        
        assert stage.inst is mock_inst
    
    def test_current_property(self):
        """Test current property"""
        
        class TestStage(Stage):
            NAME = "TestStage"
            
            def my_state(self, inst):
                return None
        
        stage = TestStage()
        stage._current = "my_state"
        
        assert stage.current == "my_state"
    
    def test_current_setter_validates(self):
        """Test current setter validates state"""
        
        class TestStage(Stage):
            NAME = "TestStage"
            
            def valid_state(self, inst):
                return None
        
        stage = TestStage()
        
        with pytest.raises(ValueError):
            stage.current = "invalid_state"
