"""Tests for decorators"""

import pytest
from qwork.qfsm.decorators import (
    recursive, listen, behavior,
    sequence, selector, parallel
)
from qwork.qfsm.stage import Stage
from qwork.qfsm.meta import clear_prototypes


@pytest.fixture(autouse=True)
def reset_state():
    """Reset state before each test"""
    clear_prototypes()
    Stage._Stage__id__ = {}
    yield


class TestRecursiveDecorator:
    """Test @recursive decorator"""
    
    def test_recursive_marked(self):
        """Test that @recursive marks method"""
        
        class TestStage(Stage):
            NAME = "TestStage"
            
            @recursive
            def my_state(self, inst):
                return None
        
        assert "my_state" in TestStage.__recursive__
    
    def test_recursive_inheritance(self):
        """Test that @recursive is inherited"""
        
        class BaseStage(Stage):
            NAME = "BaseStage"
            
            @recursive
            def base_state(self, inst):
                return None
        
        class DerivedStage(BaseStage):
            NAME = "DerivedStage"
            
            def derived_state(self, inst):
                return None
        
        assert "base_state" in DerivedStage.__recursive__


class TestListenDecorator:
    """Test @listen decorator"""
    
    def test_listen_marked(self):
        """Test that @listen marks method"""
        
        class TestStage(Stage):
            NAME = "TestStage"
            
            @listen("event1")
            def handler1(self, data):
                pass
            
            @listen("event2", "source1", "source2")
            def handler2(self, data):
                pass
        
        assert "event1" in TestStage.__listens__
        assert "handler1" in [h[0] for h in TestStage.__listens__["event1"]]
        
        assert "event2" in TestStage.__listens__
        handlers = TestStage.__listens__["event2"]
        assert any(h[0] == "handler2" and list(h[1]) == ["source1", "source2"] for h in handlers)
    
    def test_listen_inheritance(self):
        """Test that @listen is inherited"""
        
        class BaseStage(Stage):
            NAME = "BaseStage"
            
            @listen("event1")
            def handler1(self, data):
                pass
        
        class DerivedStage(BaseStage):
            NAME = "DerivedStage"
            
            @listen("event2")
            def handler2(self, data):
                pass
        
        assert "event1" in DerivedStage.__listens__
        assert "event2" in DerivedStage.__listens__


class TestBehaviorDecorator:
    """Test @behavior decorator"""
    
    def test_behavior_marked(self):
        """Test that @behavior marks state transition"""
        
        class TestStage(Stage):
            NAME = "TestStage"
            
            @behavior("next_state")
            def current_state(self, inst):
                return True
            
            def next_state(self, inst):
                return None
        
        assert "current_state" in TestStage.__behaviors__
        assert TestStage.__behaviors__["current_state"]["children"] == "next_state"
        assert TestStage.__behaviors__["current_state"]["composite"] is None


class TestSequenceDecorator:
    """Test @sequence decorator"""
    
    def test_sequence_marked(self):
        """Test that @sequence marks composite"""
        
        class TestStage(Stage):
            NAME = "TestStage"
            
            @sequence("b", "c")
            def a(self, inst):
                return True
            
            def b(self, inst):
                return True
            
            def c(self, inst):
                return None
        
        assert "a" in TestStage.__behaviors__
        assert TestStage.__behaviors__["a"]["children"] == ["b", "c"]
        assert TestStage.__behaviors__["a"]["composite"] == "sequence"


class TestSelectorDecorator:
    """Test @selector decorator"""
    
    def test_selector_marked(self):
        """Test that @selector marks composite"""
        
        class TestStage(Stage):
            NAME = "TestStage"
            
            @selector("b", "c")
            def a(self, inst):
                return False
            
            def b(self, inst):
                return True
            
            def c(self, inst):
                return None
        
        assert "a" in TestStage.__behaviors__
        assert TestStage.__behaviors__["a"]["children"] == ["b", "c"]
        assert TestStage.__behaviors__["a"]["composite"] == "selector"


class TestParallelDecorator:
    """Test @parallel decorator"""
    
    def test_parallel_marked(self):
        """Test that @parallel marks composite"""
        
        class TestStage(Stage):
            NAME = "TestStage"
            
            @parallel("b", "c")
            def a(self, inst):
                return True
            
            def b(self, inst):
                return True
            
            def c(self, inst):
                return None
        
        assert "a" in TestStage.__behaviors__
        assert TestStage.__behaviors__["a"]["children"] == ["b", "c"]
        assert TestStage.__behaviors__["a"]["composite"] == "parallel"


class TestDecoratorCombinations:
    """Test combining decorators"""
    
    def test_recursive_and_behavior(self):
        """Test @recursive with @behavior"""
        
        class TestStage(Stage):
            NAME = "TestStage"
            
            @recursive
            @behavior("next")
            def current(self, inst):
                return True
            
            def next(self, inst):
                return None
        
        assert "current" in TestStage.__recursive__
        assert "current" in TestStage.__behaviors__
