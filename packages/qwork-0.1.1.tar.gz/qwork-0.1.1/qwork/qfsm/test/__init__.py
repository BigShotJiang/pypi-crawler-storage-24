"""
qfsm test package

Run tests with: python -m pytest qfsm/test/ -v
"""

__all__ = []
