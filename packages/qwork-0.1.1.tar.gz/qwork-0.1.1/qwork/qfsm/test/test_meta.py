"""Tests for StageMachineMeta metaclass"""

import pytest
from qwork.qfsm.meta import StageMachineMeta, get_prototype, list_prototypes, clear_prototypes


class TestStateDiscovery:
    """Test automatic state discovery"""
    
    def test_basic_state_discovery(self):
        """Test that methods become states"""
        clear_prototypes()
        
        class TestStage(metaclass=StageMachineMeta):
            NAME = "TestStage"
            
            def state_a(self, inst):
                return "state_b"
            
            def state_b(self, inst):
                return "state_a"
        
        assert "state_a" in TestStage.__states__
        assert "state_b" in TestStage.__states__
    
    def test_private_methods_not_states(self):
        """Test that _private methods are not states"""
        clear_prototypes()
        
        class TestStage(metaclass=StageMachineMeta):
            NAME = "TestStage"
            
            def public_state(self, inst):
                return None
            
            def _private_method(self):
                pass
        
        assert "public_state" in TestStage.__states__
        assert "_private_method" not in TestStage.__states__
    
    def test_uppercase_methods_not_states(self):
        """Test that UPPERCASE methods are not states"""
        clear_prototypes()
        
        class TestStage(metaclass=StageMachineMeta):
            NAME = "TestStage"
            
            def normal_state(self, inst):
                return None
            
            def CONSTANT(self):
                pass
        
        assert "normal_state" in TestStage.__states__
        assert "CONSTANT" not in TestStage.__states__
    
    def test_ignored_methods_not_states(self):
        """Test that ignored methods are not states"""
        clear_prototypes()
        
        class TestStage(metaclass=StageMachineMeta):
            NAME = "TestStage"
            
            def normal_state(self, inst):
                return None
            
            def onLoading(self, it, k, *children):
                pass
        
        assert "normal_state" in TestStage.__states__
        assert "onLoading" not in TestStage.__states__


class TestClassRegistration:
    """Test automatic class registration"""
    
    def test_class_registered(self):
        """Test that classes with NAME are registered"""
        clear_prototypes()
        
        class TestStage(metaclass=StageMachineMeta):
            NAME = "TestStage"
            
            def state_a(self, inst):
                return None
        
        proto = get_prototype("TestStage")
        assert proto is TestStage
    
    def test_base_classes_not_registered(self):
        """Test that base classes are not registered"""
        clear_prototypes()
        
        class Stage(metaclass=StageMachineMeta):
            NAME = "Stage"
        
        class Logic(Stage):
            NAME = "Logic"
        
        assert get_prototype("Stage") is None
        assert get_prototype("Logic") is None
    
    def test_name_validation(self):
        """Test that NAME ending with digit is rejected"""
        clear_prototypes()
        
        with pytest.raises(ValueError):
            class BadStage(metaclass=StageMachineMeta):
                NAME = "BadStage1"


class TestInheritance:
    """Test state and decorator inheritance"""
    
    def test_states_inherited(self):
        """Test that states are inherited from parent"""
        clear_prototypes()
        
        class BaseStage(metaclass=StageMachineMeta):
            NAME = "BaseStage"
            
            def base_state(self, inst):
                return None
        
        class DerivedStage(BaseStage):
            NAME = "DerivedStage"
            
            def derived_state(self, inst):
                return None
        
        assert "base_state" in DerivedStage.__states__
        assert "derived_state" in DerivedStage.__states__
    
    def test_recursive_inherited(self):
        """Test that recursive markers are inherited"""
        clear_prototypes()
        
        class BaseStage(metaclass=StageMachineMeta):
            NAME = "BaseStage"
            
            def base_state(self, inst):
                return None
        
        BaseStage.__recursive__ = {"base_state"}
        
        class DerivedStage(BaseStage):
            NAME = "DerivedStage"
            
            def derived_state(self, inst):
                return None
        
        assert "base_state" in DerivedStage.__recursive__


class TestPrototypeFunctions:
    """Test prototype utility functions"""
    
    def test_get_prototype(self):
        """Test get_prototype function"""
        clear_prototypes()
        
        class TestStage(metaclass=StageMachineMeta):
            NAME = "TestStage"
        
        assert get_prototype("TestStage") is TestStage
        assert get_prototype("NonExistent") is None
    
    def test_list_prototypes(self):
        """Test list_prototypes function"""
        clear_prototypes()
        
        class TestStageAlpha(metaclass=StageMachineMeta):
            NAME = "TestStageAlpha"
        
        class TestStageBeta(metaclass=StageMachineMeta):
            NAME = "TestStageBeta"
        
        protos = list_prototypes()
        assert "TestStageAlpha" in protos
        assert "TestStageBeta" in protos
    
    def test_clear_prototypes(self):
        """Test clear_prototypes function"""
        clear_prototypes()
        
        class TestStage(metaclass=StageMachineMeta):
            NAME = "TestStage"
        
        assert get_prototype("TestStage") is TestStage
        clear_prototypes()
        assert get_prototype("TestStage") is None
