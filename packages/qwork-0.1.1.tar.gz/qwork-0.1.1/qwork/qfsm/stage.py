"""
qfsm Stage Module - Base class for finite state machines

This module provides the Stage base class with automatic state discovery,
behavior tree support, and recursive state execution.
"""

from __future__ import annotations

from typing import Any, ClassVar, Self
from collections.abc import Callable

from qwork.qfsm.meta import StageMachineMeta
from qwork.qfsm.scheduler import Scheduler
from qwork.qfsm.utils import EventSystem, getES

import inspect
import ast

# Color support
try:
    from colorama import init as colorama_init, Fore, Style
    colorama_init(autoreset=True)
    _COLOR_AVAILABLE = True
except ImportError:
    _COLOR_AVAILABLE = False
    # Dummy color classes for when colorama is not available
    class _DummyColor:
        def __getattr__(self, name: str) -> str:
            return ''
    Fore = _DummyColor()
    Style = _DummyColor()

class _NamedNode:
    """
    Base class for named nodes in the FSM hierarchy.

    Provides basic naming and identification functionality.
    """

    NAME: ClassVar[str] = ""

    def __init__(self) -> None:
        self._uid: int = 0
        self._name: str = self.NAME
        self.__parent: _NamedNode | None = None
        self.__children: list[_NamedNode] = []

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}({self._name})"

    def __hash__(self) -> int:
        return hash((self.__class__, self._uid))

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, _NamedNode):
            return NotImplemented
        return self._uid == other._uid and self.__class__ == other.__class__

    @property
    def parent(self) -> _NamedNode | None:
        """Get parent node."""
        return self.__parent

    @property
    def _children(self) -> list[_NamedNode]:
        """Get child nodes."""
        return self.__children

    def _add_child(self, child: _NamedNode) -> None:
        """Add a child node."""
        if child.__parent is not None:
            child.__parent._remove_child(child)
        self.__children.append(child)
        child.__parent = self

    def _remove_child(self, child: _NamedNode) -> None:
        """Remove a child node."""
        if child in self.__children:
            self.__children.remove(child)
            child.__parent = None


class BlackBoard(object):
    """Data container that can be bound to a Stage instance.

    Users can freely add any attributes to store shared data.
    """
    pass


class Stage(_NamedNode, metaclass=StageMachineMeta):
    """
    Base class for finite state machines with automatic state discovery.
    
    Features:
    - Automatic state discovery via StageMachineMeta
    - Recursive state execution with configurable limit
    - Behavior tree support (sequence, selector, parallel)
    - Event system integration
    - Lifecycle hooks (onLoading, onChanged)
    
    Class Attributes:
        NAME: The display name for this stage type
        LOG: Whether to log state transitions
        LIMIT: Maximum recursive calls per tick (default: 24)
    
    Example:
        class MyStage(Stage):
            NAME = "MyStage"
            
            def idle(self):
                if self.should_work:
                    return "working"
            
            def working(self):
                if self.work_done:
                    return "idle"
    """
    
    # Class attributes
    NAME: ClassVar[str] = "Stage"
    LOG: ClassVar[bool] = True
    LIMIT: ClassVar[int] = 24
    
    # Class-level state tracking (populated by metaclass)
    __states__: ClassVar[list[str]] = []
    __recursive__: ClassVar[set[str]] = set()
    __listens__: ClassVar[dict[str, list[tuple[str, tuple[str, ...]]]]] = {}
    __behaviors__: ClassVar[dict[str, dict[str, Any]]] = {}


    def __init__(self, inst: Any = None) -> None:
        """
        Initialize the Stage.
        
        Args:
            inst: The bound instance (e.g., game entity, component owner)
        """
        super().__init__()
        
        # Instance attributes
        self._inst: Any = inst or BlackBoard()
        self._current: str | None = None
        self._recursive_left: int = self.LIMIT
        self._states_length: int = len(self.__states__)
        self._uid: int = StageMachineMeta.requireId(self.NAME)
        self._name: str = f"{self.NAME}{self._uid}"
        
        # Event system
        self._eda: EventSystem = getES()
        
        # Behavior tree context
        self._bhead: str | None = None
        self._bhcontext: dict[str, Any] = {}
        
        # Initialize to first state if available
        if self.__states__:
            self._current = self.__states__[0]

        self.__login_event__()
        self.onLoading(self._inst)

    def __login_event__(self):
        for attr in dir(self):
            if attr.startswith("_") or attr in StageMachineMeta.IGNORES:
                continue
            val = getattr(self, attr)
            if callable(val) and hasattr(val, "_listen_event"):
                if not isinstance(val._listen_event, str):
                    raise TypeError(f"[Inner System Load]: method '{attr}'._listen_event get type '{type(val._listen_event)}', which ecpected str.")
                self.listenFor(val._listen_event, val)

    def __del__(self):
        for attr in dir(self):
            if attr.startswith("_") or attr in StageMachineMeta.IGNORES:
                continue
            val = getattr(self, attr)
            if callable(val) and hasattr(val, "_listen_event"):
                if not isinstance(val._listen_event, str):
                    raise TypeError(
                        f"[Inner System Load]: method '{attr}'._listen_event get type '{type(val._listen_event)}', which ecpected str.")
                self.cancelListen(val._listen_event, val)


    @property
    def uid(self) -> int:
        """Get unique identifier."""
        return self._uid

    @property
    def name(self) -> str:
        """Get full name with uid."""
        return self._name

    @property
    def current(self) -> str | None:
        """Get current state name."""
        return self._current

    @current.setter
    def current(self, value: str | None) -> None:
        """Set current state with validation."""
        if value is not None and value not in self.__states__:
            raise ValueError(f"Invalid state: {value}")
        self._current = value

    def onLoading(self, inst: Any) -> None:
        """
        Lifecycle hook called after initialization.

        Override this to perform setup after the stage is loaded.

        Args:
            inst: The bound instance
        """
        pass

    def onChanged(self, src: str | None, dst: str | None, inst: Any) -> None:
        """
        Lifecycle hook called when state changes.

        Override this to react to state transitions.

        Args:
            src: Source state name (None if initial)
            dst: Destination state name (None if terminal)
            inst: The bound instance
        """
        pass
    
    def handleStage(self, log: bool = True) -> str | None:
        """
        Execute the current state and handle transitions.
        
        This is the main execution method that:
        1. Calls the current state method
        2. Handles return values (state transitions)
        3. Supports recursive state execution
        4. Handles behavior tree composites
        
        Args:
            log: Whether to log state transitions
            
        Returns:
            The final state after execution, or None if no states
            
        Example:
            >>> stage = MyStage()
            >>> stage.handleStage()  # Execute one tick
        """
        if not self._current or self._states_length == 0:
            return None
        
        # Reset recursive counter at start of tick
        self._recursive_left = self.LIMIT
        
        # Execute current state (with recursion support)
        result = self._execute_state(self._current, log)
        
        return result
    
    def _execute_state(self, state_name: str, log: bool) -> str | None:
        """
        Execute a single state and handle its result.
        
        Args:
            state_name: Name of state to execute
            log: Whether to log transitions
            
        Returns:
            Final state after execution
        """
        if self._recursive_left <= 0:
            # Limit reached, stop recursion
            return state_name
        
        self._recursive_left -= 1
        
        # Get the state method
        state_method = getattr(self, state_name, None)
        if state_method is None or not callable(state_method):
            return state_name
        
        # Check if this is a behavior tree composite
        behavior_info = self.__behaviors__.get(state_name)
        if behavior_info:
            return self._handle_behavior(state_name, behavior_info, log)
        
        # Execute the state method
        try:
            result = state_method(self._inst)
        except Exception as e:
            # Log error but don't crash
            if log and self.LOG:
                print(f"[{self._name}] Error in state '{state_name}': {e}")
            return state_name

        # Handle result
        handled_result = self._handle_result(state_name, result, log)

        # For behavior tree children: preserve None (RUN) semantics
        # _handle_result converts None to state_name, but we need None for RUN
        if self._bhead is not None and result is None and handled_result == state_name:
            return None

        return handled_result
    
    def _handle_result(
        self, 
        state_name: str, 
        result: Any, 
        log: bool
    ) -> str | None:
        """
        Handle the return value from a state method.
        
        Return value meanings:
        - str: Transition to named state
        - True/None: Success, stay in current state
        - False: Failure (for behavior trees)
        
        Args:
            state_name: Current state name
            result: Return value from state method
            log: Whether to log
            
        Returns:
            Final state after handling result
        """
        # String result = state transition
        if isinstance(result, str):
            if result in self.__states__ or result in self.__behaviors__:
                if log and self.LOG:
                    print(f"[{self._name}] {state_name} -> {result}")

                # Call onChanged hook
                old_state = self._current
                self._current = result
                self.onChanged(old_state, result, self._inst)
                self.pushEvent("changed", {
                    "inst": self,
                    "old": old_state,
                    "new": result
                })

                # Only execute new state if it's marked as recursive
                if result in self.__recursive__ and self._recursive_left > 0:
                    return self._execute_state(result, log)

                return result
            else:
                # Unknown state, log warning
                if log and self.LOG:
                    print(f"[{self._name}] Unknown state: {result}")
                return state_name
        
        # None or True = success, stay in state
        if result is None or result is True:
            # Check if recursive state should continue
            if state_name in self.__recursive__ and self._recursive_left > 0:
                return self._execute_state(state_name, log)
            return state_name
        
        # False = failure (for behavior trees)
        if result is False:
            return False  # type: ignore[return-value]
        
        # Unknown result type, stay in current state
        return state_name
    
    def _handle_behavior(
        self,
        state_name: str,
        behavior_info: dict[str, Any],
        log: bool
    ) -> str | None:
        """
        Handle behavior tree composite execution with RUN support.

        Supports:
        - sequence: Execute all children in order, fail if any fails
        - selector: Execute children until one succeeds
        - parallel: Execute all children, succeed if any succeeds

        RUN (None) semantics:
        - Child returns None: pause execution, stay in current state, resume next tick
        - Uses _bhead and _bhcontext to track execution state across ticks

        Args:
            state_name: Name of behavior state
            behavior_info: Behavior configuration dict
            log: Whether to log

        Returns:
            Result state, False for failure, or None for RUN
        """
        children: list[str] = behavior_info.get('children', [])
        composite: str | None = behavior_info.get('composite')

        if not children:
            return state_name

        # Check if resuming: state has context stored in _bhcontext
        is_resuming = state_name in self._bhcontext

        # Calculate indent level based on behavior stack depth
        # Root behavior: indent_level = 0 (0 spaces)
        # Nested behaviors: indent_level = stack_depth (2, 4, 6... spaces)
        context_stack: list[str] = self._bhcontext.get("stack", [])
        if state_name == self._bhead:
            # Root level behavior (first entry or resuming)
            indent_level = 0
        else:
            # Nested behavior: indent based on stack depth
            indent_level = len(context_stack)
        indent = "  " * indent_level

        bold_name = f"{Style.BRIGHT}{self._name}{Style.RESET_ALL}" if _COLOR_AVAILABLE else self._name
        # Root behavior prints [name], nested behaviors don't
        prefix = f"[{bold_name}] " if indent_level == 0 else ""

        if self._bhead is None:
            self._bhead = state_name
        if not self._bhcontext:
            self._bhcontext = {"stack": []}

        # Execute parent state's method body ONLY on first entry (not when resuming from RUN)
        # When resuming, we skip parent and continue from where we left off
        if not is_resuming:
            state_method = getattr(self, state_name, None)
            if state_method is not None and callable(state_method):
                try:
                    parent_result = state_method(self._inst)
                except Exception as e:
                    if log and self.LOG:
                        print(f"[{self._name}] Error in behavior parent '{state_name}': {e}")
                    parent_result = None

                # Handle parent result
                # - String: transition to that state (override behavior tree)
                # - True/None: continue to execute children
                # - False: behavior fails immediately
                if isinstance(parent_result, str):
                    self._reset_behavior_context()
                    return self._handle_result(state_name, parent_result, log)
                if parent_result is False:
                    # Parent failed, behavior fails immediately
                    if log and self.LOG:
                        print(f"{indent}{prefix}-> {state_name} [{Fore.RED}FAIL{Fore.RESET}]")
                    self._reset_behavior_context()
                    return False
                # Success: print OK and continue to children
                if log and self.LOG:
                    children_str = ', '.join(children)
                    print(f"{indent}{prefix}-> {state_name} [{Fore.GREEN}OK{Fore.RESET}]")
                    print(f"{indent}  {Fore.BLUE}.{composite or 'simple'}{Fore.RESET} -> {children_str}")
            else:
                # No parent method, just print OK
                if log and self.LOG:
                    children_str = ', '.join(children)
                    print(f"{indent}{prefix}-> {state_name} [{Fore.GREEN}OK{Fore.RESET}]")
                    print(f"{indent}  {Fore.BLUE}.{composite or 'simple'}{Fore.RESET} -> {children_str}")
        else:
            # Resuming: print simplified output
            if log and self.LOG:
                print(f"{indent}{prefix}-> {state_name} {Fore.BLUE}...{Fore.RESET}")

        match composite:
            case 'sequence':
                return self._execute_sequence(state_name, children, log)
            case 'selector':
                return self._execute_selector(state_name, children, log)
            case 'parallel':
                return self._execute_parallel(state_name, children, log)
            case _:
                # Simple behavior - transition to single child
                self._reset_behavior_context()
                if isinstance(children, str):
                    return self._transition_to(children, state_name, log)
                elif len(children) == 1:
                    return self._transition_to(children[0], state_name, log)
                return state_name

    def _reset_behavior_context(self) -> None:
        """Reset behavior tree execution context."""
        self._bhead = None
        self._bhcontext = {}
    
    def _execute_sequence(self, parent_name: str, children: list[str], log: bool) -> str | None:
        """
        Execute children in sequence (all must succeed).

        RUN (None) handling:
        - If a child returns None, pause and resume from the same child next tick
        - Uses _bhcontext to track current index across ticks

        Args:
            parent_name: Name of the parent behavior state
            children: List of child state names
            log: Whether to log

        Returns:
            Last successful state, False if any fails, or None if RUN
        """
        max_len = getattr(self, '__max_state_len__', 0)
        bold_name = f"{Style.BRIGHT}{self._name}{Style.RESET_ALL}" if _COLOR_AVAILABLE else self._name
        context_stack: list[str] = self._bhcontext.get("stack", [])

        # Check if this is first entry or resuming
        is_first_entry = parent_name not in self._bhcontext

        # Get or initialize sequence context
        if is_first_entry:
            seq_context = {"index": 0}
            self._bhcontext[parent_name] = seq_context
            # First time: push to stack for calculating children's indent
            if parent_name not in context_stack:
                context_stack.append(parent_name)
        else:
            seq_context = self._bhcontext[parent_name]
            # Resuming: ensure stack contains this parent at the top
            if parent_name not in context_stack:
                context_stack.append(parent_name)
            else:
                # Remove any items above this parent
                while context_stack and context_stack[-1] != parent_name:
                    context_stack.pop()

        # Calculate indent based on nesting depth
        # Root's children: 2 spaces, nested children: 4, 6... spaces
        indent_level = len(context_stack)
        child_indent = "  " * indent_level if indent_level > 0 else "  "
        result_indent = "  " * (indent_level - 1) if indent_level > 1 else ""

        current_index = seq_context["index"]

        # Execute from current index
        while current_index < len(children):
            child = children[current_index]

            if child not in self.__states__ and child not in self.__behaviors__:
                if log and self.LOG:
                    padded = child.ljust(max_len)
                    print(f"{child_indent}-> {padded} [{Fore.RED}UNKNOWN - FAIL{Fore.RESET}]")
                self._reset_behavior_context()
                return False  # type: ignore[return-value]

            # Check if child is a behavior composite
            child_behavior = self.__behaviors__.get(child)
            is_child_behavior = child_behavior is not None

            if log and self.LOG:
                if not is_child_behavior:
                    # Only print prefix for non-behavior children
                    padded = child.ljust(max_len)
                    print(f"{child_indent}-> {padded}", end=" ")

            result = self._execute_state(child, log)

            # RUN (None): pause execution, resume next tick
            if result is None:
                if log and self.LOG and not is_child_behavior:
                    print(f"[{Fore.YELLOW}RUN{Fore.RESET}]")
                # Update context for next tick
                seq_context["index"] = current_index
                return None

            # False result means failure
            if result is False:
                if log and self.LOG and not is_child_behavior:
                    print(f"[{Fore.RED}FAIL{Fore.RESET}]")
                # Print parent failure and cleanup
                if log and self.LOG:
                    print(f"{result_indent}<- {parent_name} [{Fore.RED}FAIL{Fore.RESET}]")
                # Pop from stack and clean up
                if context_stack and context_stack[-1] == parent_name:
                    context_stack.pop()
                if parent_name in self._bhcontext:
                    del self._bhcontext[parent_name]
                # If this was the root behavior, reset context
                if self._bhead == parent_name:
                    self._reset_behavior_context()
                return False  # type: ignore[return-value]

            # Success - behavior child handles its own output
            if log and self.LOG and not is_child_behavior:
                print(f"[{Fore.GREEN}OK{Fore.RESET}]")

            # Move to next child
            current_index += 1
            seq_context["index"] = current_index

        # All children completed successfully
        if log and self.LOG:
            print(f"{result_indent}<- {parent_name} [{Fore.GREEN}OK{Fore.RESET}]")

        # Pop from stack and clean up
        if context_stack and context_stack[-1] == parent_name:
            context_stack.pop()
        if parent_name in self._bhcontext:
            del self._bhcontext[parent_name]

        # If this was the root behavior, reset context
        if self._bhead == parent_name:
            self._reset_behavior_context()

        return children[-1]  # Return last child name as success
    
    def _execute_selector(self, parent_name: str, children: list[str], log: bool) -> str | None:
        """
        Execute children until one succeeds.

        RUN (None) handling:
        - If a child returns None, pause and resume from the same child next tick
        - If a child returns True/success, the selector succeeds
        - If a child returns False/failure, try the next child

        Args:
            parent_name: Name of the parent behavior state
            children: List of child state names
            log: Whether to log

        Returns:
            First successful state, False if all fail, or None if RUN
        """
        max_len = getattr(self, '__max_state_len__', 0)
        bold_name = f"{Style.BRIGHT}{self._name}{Style.RESET_ALL}" if _COLOR_AVAILABLE else self._name
        context_stack: list[str] = self._bhcontext.get("stack", [])

        # Check if this is first entry or resuming
        is_first_entry = parent_name not in self._bhcontext

        # Get or initialize selector context
        if is_first_entry:
            sel_context = {"index": 0}
            self._bhcontext[parent_name] = sel_context
            # First time: push to stack
            context_stack.append(parent_name)
        else:
            sel_context = self._bhcontext[parent_name]
            # Resuming: ensure stack contains this parent at the top
            if parent_name not in context_stack:
                context_stack.append(parent_name)
            else:
                while context_stack and context_stack[-1] != parent_name:
                    context_stack.pop()

        # Calculate indent based on nesting depth
        # Root's children: 2 spaces, nested children: 4, 6... spaces
        indent_level = len(context_stack)
        child_indent = "  " * indent_level if indent_level > 0 else "  "
        result_indent = "  " * (indent_level - 1) if indent_level > 1 else ""

        current_index = sel_context["index"]

        # Execute from current index
        while current_index < len(children):
            child = children[current_index]

            if child not in self.__states__ and child not in self.__behaviors__:
                if log and self.LOG:
                    padded = child.ljust(max_len)
                    print(f"{child_indent}-> {padded} [{Fore.YELLOW}UNKNOWN - SKIP{Fore.RESET}]")
                current_index += 1
                sel_context["index"] = current_index
                continue

            if log and self.LOG:
                padded = child.ljust(max_len)
                print(f"{child_indent}-> {padded}", end=" ")

            result = self._execute_state(child, log)

            # RUN (None): pause execution, resume next tick
            if result is None:
                if log and self.LOG:
                    print(f"[{Fore.YELLOW}RUN{Fore.RESET}]")
                # Update context for next tick
                sel_context["index"] = current_index
                return None

            # Success (non-False, non-None result)
            if result is not False:
                if log and self.LOG:
                    print(f"[{Fore.GREEN}OK{Fore.RESET}]")
                # Clean up
                if context_stack and context_stack[-1] == parent_name:
                    context_stack.pop()
                if parent_name in self._bhcontext:
                    del self._bhcontext[parent_name]
                if self._bhead == parent_name:
                    self._reset_behavior_context()
                return result

            # Failure: try next child
            if log and self.LOG:
                print(f"[{Fore.RED}FAIL{Fore.RESET} - try next]")
            current_index += 1
            sel_context["index"] = current_index

        # All failed
        if log and self.LOG:
            print(f"{result_indent}<- {parent_name} [{Fore.RED}ALL FAILED{Fore.RESET}]")

        # Clean up
        if context_stack and context_stack[-1] == parent_name:
            context_stack.pop()
        if parent_name in self._bhcontext:
            del self._bhcontext[parent_name]
        if self._bhead == parent_name:
            self._reset_behavior_context()

        return False  # type: ignore[return-value]

    def _execute_parallel(self, parent_name: str, children: list[str], log: bool) -> str | None:
        """
        Execute all children (any can succeed).

        RUN (None) handling:
        - If any child returns None, the parallel returns None (RUN)
        - Tracks which children have completed across ticks

        Args:
            parent_name: Name of the parent behavior state
            children: List of child state names
            log: Whether to log

        Returns:
            First successful state, False if all fail, or None if RUN
        """
        max_len = getattr(self, '__max_state_len__', 0)
        bold_name = f"{Style.BRIGHT}{self._name}{Style.RESET_ALL}" if _COLOR_AVAILABLE else self._name
        context_stack: list[str] = self._bhcontext.get("stack", [])

        # Check if this is first entry or resuming
        is_first_entry = parent_name not in self._bhcontext

        # Get or initialize parallel context
        if is_first_entry:
            para_context = {"history": [False] * len(children), "completed": 0}
            self._bhcontext[parent_name] = para_context
            context_stack.append(parent_name)
        else:
            para_context = self._bhcontext[parent_name]
            # Resuming: ensure stack contains this parent at the top
            if parent_name not in context_stack:
                context_stack.append(parent_name)
            else:
                while context_stack and context_stack[-1] != parent_name:
                    context_stack.pop()

        # Calculate indent based on nesting depth
        # Root's children: 2 spaces, nested children: 4, 6... spaces
        indent_level = len(context_stack)
        child_indent = "  " * indent_level if indent_level > 0 else "  "
        result_indent = "  " * (indent_level - 1) if indent_level > 1 else ""

        history = para_context["history"]
        any_running = False
        any_success = False
        last_result: str | None = None

        for i, child in enumerate(children):
            # Skip already completed children
            if history[i]:
                continue

            if child not in self.__states__ and child not in self.__behaviors__:
                if log and self.LOG:
                    padded = child.ljust(max_len)
                    print(f"{child_indent}-> {padded} [{Fore.YELLOW}UNKNOWN - SKIP{Fore.RESET}]")
                history[i] = True
                para_context["completed"] += 1
                continue

            if log and self.LOG:
                padded = child.ljust(max_len)
                print(f"{child_indent}-> {padded}", end=" ")

            result = self._execute_state(child, log)
            last_result = result

            # RUN (None): mark as running
            if result is None:
                if log and self.LOG:
                    print(f"[{Fore.YELLOW}RUN{Fore.RESET}]")
                any_running = True
                continue

            # Mark as completed
            history[i] = True
            para_context["completed"] += 1

            # Track success
            if result is not False:
                any_success = True
                if log and self.LOG:
                    print(f"[{Fore.GREEN}OK{Fore.RESET}]")
            else:
                if log and self.LOG:
                    print(f"[{Fore.RED}FAIL{Fore.RESET}]")

        # If any child is still running, return None
        if any_running:
            return None

        # All children completed
        if log and self.LOG:
            if any_success:
                print(f"{result_indent}<- {parent_name} [{Fore.GREEN}AT LEAST ONE OK{Fore.RESET}]")
            else:
                print(f"{result_indent}<- {parent_name} [{Fore.RED}ALL FAILED{Fore.RESET}]")

        # Clean up
        if context_stack and context_stack[-1] == parent_name:
            context_stack.pop()
        if parent_name in self._bhcontext:
            del self._bhcontext[parent_name]
        if self._bhead == parent_name:
            self._reset_behavior_context()

        return last_result if any_success else False  # type: ignore[return-value]

    def _transition_to(
        self, 
        new_state: str, 
        old_state: str, 
        log: bool
    ) -> str | None:
        """
        Transition to a new state.
        
        Args:
            new_state: State to transition to
            old_state: Current state name
            log: Whether to log
            
        Returns:
            New state name or None
        """
        if new_state not in self.__states__ and new_state not in self.__behaviors__:
            return old_state
        
        if log and self.LOG:
            print(f"[{self._name}] {old_state} -> {new_state}")
        
        self._current = new_state

        # Reset behavior context on state transition
        if self._bhead is not None:
            self._reset_behavior_context()

        self.onChanged(old_state, new_state, self._inst)
        self.pushEvent("changed", {
            "inst": self,
            "old": old_state,
            "new": new_state
        })

        return new_state

    @property
    def uid(self) -> int:
        """Unique instance identifier."""
        return self._uid

    @property
    def name(self) -> str:
        return self._name

    @property
    def inst(self) -> Any:
        return self._inst

    @property
    def current_state(self) -> str | None:
        """Get the current state name."""
        return self._current

    @property
    def states(self) -> list[str]:
        """Get list of all available states."""
        return self.__states__.copy()
    
    @property
    def recursive_states(self) -> set[str]:
        """Get set of recursive state names."""
        return self.__recursive__.copy()

    @property
    def now(self) -> int:
        """Get current scheduler tick (read-only)."""
        try:
            return Scheduler().tick
        except Exception:
            return 0

    def goto(self, state_name: str) -> bool:
        """
        Manually transition to a state.
        
        Args:
            state_name: Target state name
            
        Returns:
            True if transition succeeded
        """
        if state_name not in self.__states__ and state_name not in self.__behaviors__:
            return False
        
        old_state = self._current
        self._current = state_name
        self.onChanged(old_state, state_name, self._inst)
        return True

    # ========================================================================
    # Event Methods
    # ========================================================================

    def listenFor(self, event: str, callback: Any, *sources: str) -> Self:
        """
        Register an event listener.

        Args:
            event: Event name to listen for
            callback: Function to call when event occurs
            *sources: Optional source filters

        Returns:
            self for method chaining
        """
        self._eda.listenFor(event, callback, *sources)
        return self

    def cancelListen(self, event: str, callback: Any | None = None) -> bool:
        """
        Cancel an event listener.

        Args:
            event: Event name to stop listening for
            callback: Specific callback to remove (None = all)

        Returns:
            True if listener was removed
        """
        return self._eda.cancelListen(event, callback)

    def pushEvent(self, event: str, data: Any = None, *targets: str) -> int:
        """
        Push an event to listeners.

        Args:
            event: Event name to push
            data: Event data
            *targets: Optional target filters

        Returns:
            Number of listeners that received the event
        """
        # print("stage: ", event, data)
        return self._eda.pushEvent(event, data, *targets)

    @classmethod
    def extractNodes(cls) -> Dict[str, Dict[str, Any]]:
        """
        静态分析当前 Stage 类的所有状态方法，提取：
        - 文档字符串 (doc)
        - 函数体源代码 (code)
        - 所有静态返回的目标状态 (targets)
        - 装饰器列表 (decorates)

        适用于 Python 3.8+ (已针对 3.10+ 优化)
        """
        result = {}
        states = cls.__states__

        try:
            source_file = inspect.getsourcefile(cls)
            if not source_file:
                raise FileNotFoundError(f"Source file not found for {cls.__name__}")

            with open(source_file, 'r', encoding='utf-8') as f:
                source = f.read()
        except Exception as e:
            raise RuntimeError(f"Cannot access source code: {e}") from e

        try:
            module_ast = ast.parse(source)
        except SyntaxError as e:
            raise RuntimeError(f"Syntax error in source file: {e}") from e

        # 找到当前类定义
        target_class_node = None
        for node in ast.walk(module_ast):
            if isinstance(node, ast.ClassDef) and node.name == cls.__name__:
                target_class_node = node
                break

        if not target_class_node:
            raise RuntimeError(f"Class {cls.__name__} not found in source file")

        # 遍历类中的所有方法
        for node in target_class_node.body:
            if isinstance(node, ast.FunctionDef) and node.name in states:
                state_name = node.name

                # 【核心修复点 2】从源文本提取代码体
                code = cls._extract_function_body(source, node)

                # 提取目标状态
                targets = cls._extract_static_targets(node, state_name)

                # 提取非 property 装饰器列表
                decorates = []
                for decorator in node.decorator_list:
                    # 排除 property 装饰器
                    if isinstance(decorator, ast.Name) and decorator.id == 'property':
                        continue
                    # 排除 property() 调用
                    elif isinstance(decorator, ast.Call) and isinstance(decorator.func, ast.Name) and decorator.func.id == 'property':
                        continue

                    # 获取装饰器名称 (处理链式调用如 @dec1 @dec2)
                    decor_name = cls._get_decorator_name(decorator)
                    if decor_name:
                        decorates.append(decor_name)

                result[state_name] = {
                    "code": code,
                    "targets": targets,
                    "decorates": decorates
                }

        return result

    @staticmethod
    def _extract_function_body(source: str, func_node: ast.FunctionDef) -> str:
        """
        从源码字符串中提取函数体，去除 'def ...:' 行和公共缩进。
        适用于 Python 3.8+ (依赖 end_lineno)
        """
        start_line = func_node.lineno

        # Python 3.8+ 保证有 end_lineno
        if not hasattr(func_node, 'end_lineno'):
            raise RuntimeError("AST node missing end_lineno. Requires Python 3.8+")

        end_line = func_node.end_lineno

        lines = source.splitlines()

        # 边界检查 (行号从 1 开始，列表索引从 0 开始)
        if start_line > len(lines) or end_line > len(lines):
            return ""

        # 截取函数定义行到结束行的所有内容
        func_lines = lines[start_line - 1: end_line]

        # 去掉第一行 (def ...)
        body_lines = func_lines[1:]

        if not body_lines:
            return ""

        # 计算公共缩进
        first_body_line = body_lines[0]
        indent = len(first_body_line) - len(first_body_line.lstrip())

        cleaned_lines = []
        for line in body_lines:
            if line.strip() == "":
                cleaned_lines.append("")
            elif len(line) >= indent:
                cleaned_lines.append(line[indent:])
            else:
                # 防止缩进异常导致截断错误
                cleaned_lines.append(line)

        return "\n".join(cleaned_lines).rstrip()

    @staticmethod
    def _extract_static_targets(func_node: ast.FunctionDef, current_state: str) -> List[str]:
        """
        使用 AST 静态分析函数中所有 return 的字符串字面量目标。
        兼容 Python 3.8+ (ast.Constant)
        """
        targets = set()

        def _visit(node, depth=0):
            if isinstance(node, ast.Return):
                value = node.value
                if value is None:
                    return

                # Python 3.8+ 统一使用 ast.Constant
                if isinstance(value, ast.Constant):
                    if isinstance(value.value, str):
                        target = value.value
                        if target != current_state:
                            targets.add(target)
                # 兼容性兜底 (理论上 3.10+ 不需要，但保留以防万一)
                elif hasattr(ast, 'Str') and isinstance(value, ast.Str):
                    if value.s != current_state:
                        targets.add(value.s)

            elif isinstance(node, ast.If):
                for child in node.body:
                    _visit(child, depth + 1)
                for child in node.orelse:
                    _visit(child, depth + 1)

            elif isinstance(node, ast.IfExp):  # 三元表达式
                _visit(node.body, depth + 1)
                _visit(node.orelse, depth + 1)

            # 递归遍历子节点
            for child in ast.iter_child_nodes(node):
                _visit(child, depth + 1)

        # 从函数体开始递归
        for stmt in func_node.body:
            _visit(stmt)

        return sorted(list(targets))

    @staticmethod
    def _get_decorator_name(decorator: ast.expr) -> str | None:
        """
        从 AST 装饰器节点提取名称字符串。
        支持简单名称、属性访问 (obj.method) 和带参数的调用 (func(arg))。
        """
        if isinstance(decorator, ast.Name):
            return decorator.id
        elif isinstance(decorator, ast.Attribute):
            # 处理 obj.attr 形式
            return decorator.attr
        elif isinstance(decorator, ast.Call):
            # 处理 func(arg) 形式，只取函数名
            if isinstance(decorator.func, ast.Name):
                return decorator.func.id
            elif isinstance(decorator.func, ast.Attribute):
                return decorator.func.attr
        return None

__all__ = [
    'Stage',
    '_NamedNode',
]
