"""
QFSM Demo - 完整示例程序

展示:
1. 基本的FSM状态切换
2. 事件系统通信
3. 优先级调度
4. 实例间引用
5. 生命周期管理

场景: 简单的游戏AI系统
- Player: 玩家角色，可以移动和攻击
- Enemy: 敌人AI，有巡逻、追击、攻击状态
- GameManager: 游戏管理器，处理游戏事件
"""

from __future__ import annotations

import time
from typing import Any

from qwork.qfsm.logic import Logic
from qwork.qfsm.scheduler import Scheduler


class GameEntity:
    """游戏实体基类，模拟游戏对象"""
    def __init__(self, name: str, x: float = 0, y: float = 0):
        self.name = name
        self.x = x
        self.y = y
        self.health = 100
        self.is_active = True

    def distance_to(self, other: GameEntity) -> float:
        """计算到另一个实体的距离"""
        return ((self.x - other.x) ** 2 + (self.y - other.y) ** 2) ** 0.5

    def __repr__(self) -> str:
        return f"{self.name}({self.x:.1f}, {self.y:.1f})"


class GameManager(Logic):
    """
    游戏管理器 - 最高优先级
    负责管理游戏整体状态和事件分发
    """
    NAME = "GameManager"
    PRIORITY = 100  # 最高优先级，先执行

    def __init__(self) -> None:
        super().__init__(None)
        self.tick_count = 0
        self.game_over = False
        print("[GameManager] 游戏管理器启动")

    def onStart(self) -> None:
        """游戏开始时调用"""
        print("[GameManager] 游戏开始!")
        # 监听游戏事件
        self.listenFor("enemy_died", self._on_enemy_died)
        self.listenFor("player_died", self._on_player_died)

    def _on_enemy_died(self, data: Any) -> None:
        """敌人死亡事件处理"""
        enemy_name = data.get("name", "Unknown") if isinstance(data, dict) else data
        print(f"[GameManager] 敌人 {enemy_name} 被消灭!")

    def _on_player_died(self, data: Any) -> None:
        """玩家死亡事件处理"""
        print("[GameManager] 玩家死亡! 游戏结束!")
        self.game_over = True

    def onStep(self) -> None:
        """每tick执行"""
        self.tick_count += 1
        if self.tick_count % 10 == 0:
            print(f"[GameManager] === Tick {self.tick_count} ===")

    def idle(self) -> str | None:
        """空闲状态 - 检查游戏是否结束"""
        if self.game_over:
            return "game_over"
        return None

    def game_over(self) -> str | None:
        """游戏结束状态"""
        print("[GameManager] 游戏结束状态")
        # 通知所有对象清理
        self.pushEvent("game_over", None)
        self.kill()  # 结束管理器
        return None


class Player(Logic):
    """
    玩家控制器
    状态: idle -> move -> attack -> idle
    """
    NAME = "Player"
    PRIORITY = 50

    def __init__(self, entity: GameEntity) -> None:
        super().__init__(entity)
        self._inst: GameEntity = entity
        self.target: GameEntity | None = None
        self.attack_cooldown = 0
        print(f"[Player] 玩家 {entity.name} 创建在 {entity}")

    def onStart(self) -> None:
        print(f"[Player] 玩家 {self._inst.name} 准备就绪")

    def onStep(self) -> None:
        """每tick更新"""
        if self.attack_cooldown > 0:
            self.attack_cooldown -= 1

    def idle(self) -> str | None:
        """空闲状态 - 寻找最近的敌人"""
        # 获取所有敌人实例
        enemies = self.ref("Enemy")
        if enemies:
            if isinstance(enemies, list):
                # 找到最近的敌人
                self.target = min(enemies, key=lambda e: e._inst.distance_to(self._inst))._inst
            else:
                self.target = enemies._inst

            distance = self._inst.distance_to(self.target)
            if distance > 2.0:
                return "move"
            else:
                return "attack"
        return None

    def move(self) -> str | None:
        """移动状态 - 向目标移动"""
        if not self.target or self.target.health <= 0:
            return "idle"

        # 简单的移动逻辑
        dx = self.target.x - self._inst.x
        dy = self.target.y - self._inst.y
        distance = (dx ** 2 + dy ** 2) ** 0.5

        if distance <= 2.0:
            return "attack"

        # 移动 (归一化方向 * 速度)
        speed = 1.5
        if distance > 0:
            self._inst.x += (dx / distance) * speed
            self._inst.y += (dy / distance) * speed

        print(f"[Player] 移动到 ({self._inst.x:.1f}, {self._inst.y:.1f}), "
              f"目标距离: {distance:.1f}")
        return "move"

    def attack(self) -> str | None:
        """攻击状态"""
        if not self.target or self.target.health <= 0:
            return "idle"

        if self.attack_cooldown > 0:
            return "attack"

        # 执行攻击
        damage = 25
        self.target.health -= damage
        self.attack_cooldown = 3  # 3 tick冷却

        print(f"[Player] 攻击 {self.target.name} 造成 {damage} 伤害! "
              f"剩余生命: {self.target.health}")

        if self.target.health <= 0:
            # 发送敌人死亡事件
            self.pushEvent("enemy_died", {"name": self.target.name})
            self.target = None
            return "idle"

        return "attack"


class Enemy(Logic):
    """
    敌人AI
    状态: patrol -> chase -> attack -> patrol
    """
    NAME = "Enemy"
    PRIORITY = 40

    def __init__(self, entity: GameEntity, patrol_points: list[tuple[float, float]]) -> None:
        super().__init__(entity)
        self._inst: GameEntity = entity
        self.patrol_points = patrol_points
        self.current_point = 0
        self.player: Player | None = None
        self.attack_cooldown = 0
        self.alert_range = 5.0
        self.attack_range = 2.0
        print(f"[Enemy] 敌人 {entity.name} 创建在 {entity}")

    def onStart(self) -> None:
        print(f"[Enemy] 敌人 {self._inst.name} 开始巡逻")
        # 监听游戏结束事件
        self.listenFor("game_over", self._on_game_over)

    def _on_game_over(self, data: Any) -> None:
        """游戏结束时停止"""
        print(f"[Enemy] {self._inst.name} 收到游戏结束信号")
        self.kill()

    def onStep(self) -> None:
        """每tick更新"""
        if self.attack_cooldown > 0:
            self.attack_cooldown -= 1

        # 死亡检查
        if self._inst.health <= 0:
            self.kill()

    def _find_player(self) -> Player | None:
        """查找玩家实例"""
        player = self.ref("Player")
        return player[0] if isinstance(player, list) else player

    def patrol(self) -> str | None:
        """巡逻状态"""
        # 检查玩家是否在警戒范围
        player = self._find_player()
        if player and player._inst.health > 0:
            distance = self._inst.distance_to(player._inst)
            if distance <= self.alert_range:
                print(f"[Enemy] {self._inst.name} 发现玩家! 距离: {distance:.1f}")
                self.player = player
                return "chase"

        # 巡逻移动
        target = self.patrol_points[self.current_point]
        dx = target[0] - self._inst.x
        dy = target[1] - self._inst.y
        distance = (dx ** 2 + dy ** 2) ** 0.5

        if distance < 0.5:
            # 到达巡逻点，前往下一个
            self.current_point = (self.current_point + 1) % len(self.patrol_points)
            print(f"[Enemy] {self._inst.name} 到达巡逻点，前往下一个")
        else:
            # 移动
            speed = 0.8
            self._inst.x += (dx / distance) * speed
            self._inst.y += (dy / distance) * speed

        return None

    def chase(self) -> str | None:
        """追击状态"""
        if not self.player or self.player._inst.health <= 0:
            return "patrol"

        distance = self._inst.distance_to(self.player._inst)

        # 如果距离太远，返回巡逻
        if distance > self.alert_range * 1.5:
            print(f"[Enemy] {self._inst.name} 丢失目标")
            self.player = None
            return "patrol"

        # 如果在攻击范围内，切换攻击
        if distance <= self.attack_range:
            return "attack"

        # 向玩家移动
        dx = self.player._inst.x - self._inst.x
        dy = self.player._inst.y - self._inst.y
        speed = 1.2
        self._inst.x += (dx / distance) * speed
        self._inst.y += (dy / distance) * speed

        print(f"[Enemy] {self._inst.name} 追击玩家到 ({self._inst.x:.1f}, {self._inst.y:.1f})")
        return "chase"

    def attack(self) -> str | None:
        """攻击状态"""
        if not self.player or self.player._inst.health <= 0:
            return "patrol"

        distance = self._inst.distance_to(self.player._inst)
        if distance > self.attack_range:
            return "chase"

        if self.attack_cooldown > 0:
            return "attack"

        # 执行攻击
        damage = 15
        self.player._inst.health -= damage
        self.attack_cooldown = 4

        print(f"[Enemy] {self._inst.name} 攻击玩家造成 {damage} 伤害! "
              f"玩家剩余生命: {self.player._inst.health}")

        if self.player._inst.health <= 0:
            self.pushEvent("player_died", {"name": self.player._inst.name})

        return "attack"

    def onStop(self) -> None:
        print(f"[Enemy] 敌人 {self._inst.name} 被销毁")


def main():
    """主程序 - 运行Demo"""
    print("=" * 60)
    print("QFSM Demo - 游戏AI状态机示例")
    print("=" * 60)

    # 创建调度器
    scheduler = Scheduler()

    # 注册所有逻辑类
    scheduler.login(GameManager)
    scheduler.login(Player)
    scheduler.login(Enemy)

    # 创建游戏管理器
    game_manager = GameManager()

    # 创建玩家
    player_entity = GameEntity("Hero", x=0, y=0)
    player = Player(player_entity)

    # 创建敌人
    enemy1_entity = GameEntity("Slime", x=10, y=10)
    enemy1 = Enemy(enemy1_entity, patrol_points=[(10, 10), (15, 10), (15, 15), (10, 15)])

    enemy2_entity = GameEntity("Goblin", x=-8, y=8)
    enemy2 = Enemy(enemy2_entity, patrol_points=[(-8, 8), (-5, 8), (-5, 12), (-8, 12)])

    print("\n" + "=" * 60)
    print("开始游戏循环 (最多50个tick)")
    print("=" * 60 + "\n")

    # 游戏主循环
    max_ticks = 50
    tick_delay = 0.3  # 每个tick之间的延迟(秒)

    for tick in range(max_ticks):
        if not game_manager.alive:
            print("\n[Main] 游戏管理器已停止")
            break

        scheduler.handle()  # ← 执行一个tick

        # 打印当前状态
        print(f"\n[Tick {tick + 1}] 玩家HP: {player_entity.health}, "
              f"敌人1 HP: {enemy1_entity.health}, 敌人2 HP: {enemy2_entity.health}")

        # 检查是否所有敌人都被消灭
        if not enemy1.alive and not enemy2.alive:
            print("\n[Main] 所有敌人都被消灭! 胜利!")
            break

        # 玩家死亡检查
        if player_entity.health <= 0:
            print("\n[Main] 玩家死亡! 游戏结束!")
            break

        time.sleep(tick_delay)

    print("\n" + "=" * 60)
    print("Demo 结束")
    print(f"总tick数: {game_manager.tick_count}")
    print(f"玩家最终状态: {player_entity}")
    print(f"敌人1存活: {enemy1.alive}")
    print(f"敌人2存活: {enemy2.alive}")
    print("=" * 60)


if __name__ == "__main__":
    main()
