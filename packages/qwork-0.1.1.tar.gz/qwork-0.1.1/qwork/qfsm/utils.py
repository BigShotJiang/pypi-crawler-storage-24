from efr import EventSystem as _EventSystem
from efr import EventFramework

__event_system__ = None


class EventSystem(_EventSystem):
    """Extended EventSystem with source filtering support."""

    def pushEvent(self, event, data, *targets, source=None):
        """
        Push event with optional source information.

        Args:
            event: Event name
            data: Event data dict
            *targets: Target names
            source: Source identifier (stored in data)
        """
        if source is not None:
            if not isinstance(data, dict):
                data = {"_data": data}
            data = dict(data)
            data["source"] = source
        super().pushEvent(event, data, *targets)


def getES():
    global __event_system__
    if __event_system__ is None:
        ef = EventFramework(name="fsm", log_level="INFO")
        __event_system__ = EventSystem(ef)
        ef.start()
    return __event_system__

