"""
QFSM - Quick Finite State Machine Library

A Python 3.14+ finite state machine library with decorators and event system.

Basic Usage:
    from qfsm import Stage, Logic, Scheduler
    from qfsm.decorators import recursive, listen, sequence

    class MyLogic(Logic):
        NAME = "MyLogic"
        
        def initial(self, inst):
            return "running"

        def running(self, inst):
            return None

    # Auto-registered with Scheduler
    logic = MyLogic()
    
    # Run scheduler
    scheduler = Scheduler()
    scheduler.handle()
"""

from qwork.qfsm.meta import (
    StageMachineMeta,
    get_prototype,
    list_prototypes,
    clear_prototypes,
)

from qwork.qfsm.scheduler import Scheduler

from qwork.qfsm.stage import Stage, _NamedNode

from qwork.qfsm.logic import Logic

from qwork.qfsm.decorators import (
    recursive,
    listen,
    behavior,
    sequence,
    selector,
    parallel,
    process_fsm_markers,
)

from qwork.qfsm.utils import (
    EventSystem,
    getES,
)

__version__ = '0.1.0'
__all__ = [
    # Core classes
    'StageMachineMeta',
    'Scheduler',
    'Stage',
    'Logic',
    '_NamedNode',
    # Decorators
    'recursive',
    'listen',
    'behavior',
    'sequence',
    'selector',
    'parallel',
    'process_fsm_markers',
    # Events
    'EventSystem',
    'getES',
    # Utility functions
    'get_prototype',
    'list_prototypes',
    'clear_prototypes',
]
