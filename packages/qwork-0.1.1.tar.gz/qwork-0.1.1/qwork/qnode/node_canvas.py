"""
节点画布模块 - 主视图组件
处理所有的用户交互：拖拽、选择、连接、右键菜单等
"""

import math
import json
from typing import Optional, List, Dict, Any
from dataclasses import dataclass, field

from PyQt6.QtWidgets import (
    QGraphicsView, QGraphicsScene, QGraphicsItem,
    QGraphicsPathItem, QMenu, QMessageBox, QApplication
)
from PyQt6.QtCore import Qt, QPointF, QRectF, pyqtSignal
from PyQt6.QtGui import (
    QPainter, QBrush, QPen, QColor, QPainterPath, QTransform,
    QContextMenuEvent, QMouseEvent, QKeyEvent, QWheelEvent
)

from qwork.qnode.node_item import NodeItem
from qwork.qnode.connection_item import ConnectionItem
from qwork.qnode.arrow_item import ArrowItem
from qwork.qnode.selection_rect import SelectionRect
from qwork.qnode.style_panel import StylePanel
from qwork.qnode.enums import NodeShape, ConnectionType
from qwork.qnode.layout_utils import DenseLayoutEngine, ViewportFitter


@dataclass
class AtomOperation:
    """原子操作 - 记录单个可追踪的修改"""
    NULL: str = field(default="</$NULL>", repr=False)

    old: Any = None
    new: Any = None
    jpath: List[str] = field(default_factory=list)
    act: bool = True

    def __postInit(self):
        """初始化后将 NULL 字符串转为常量引用"""
        if self.old == "</$NULL>":
            self.old = AtomOperation.NULL
        if self.new == "</$NULL>":
            self.new = AtomOperation.NULL


class NodeCanvas(QGraphicsView):
    """
    节点画布 - 主视图组件
    处理所有的用户交互：拖拽、选择、连接、右键菜单等
    """
    
    nodeSelected = pyqtSignal(object)  # 节点选中信号
    connectionCreated = pyqtSignal(object)  # 连接创建信号
    
    def __init__(self, parent: Optional['QWidget'] = None) -> None:
        super().__init__(parent)

        # 创建场景
        self._scene: QGraphicsScene = QGraphicsScene(self)
        self._scene.setSceneRect(-5000, -5000, 10000, 10000)
        self.setScene(self._scene)

        # 连接场景的选择改变信号
        self._scene.selectionChanged.connect(self._onSelectionChanged)
        
        # 设置渲染选项
        self.setRenderHints(QPainter.RenderHint.Antialiasing | QPainter.RenderHint.SmoothPixmapTransform)
        self.setViewportUpdateMode(QGraphicsView.ViewportUpdateMode.FullViewportUpdate)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)
        self.setTransformationAnchor(QGraphicsView.ViewportAnchor.AnchorUnderMouse)
        self.setResizeAnchor(QGraphicsView.ViewportAnchor.AnchorViewCenter)
        
        # 拖拽模式
        self.setDragMode(QGraphicsView.DragMode.NoDrag)
        
        # 状态变量
        self._nodes: List[NodeItem] = []
        self._connections: List[ConnectionItem] = []
        self._start_node: Optional[NodeItem] = None  # 起点节点
        self._drag_start_pos: Optional[QPointF] = None
        self._temp_connection: Optional[QGraphicsPathItem] = None
        self._source_node_for_connection: Optional[NodeItem] = None
        self._selection_rect: Optional[SelectionRect] = None
        self._selection_start_pos: Optional[QPointF] = None
        self._is_panning: bool = False
        self._pan_start_pos: Optional[QPointF] = None
        self._is_creating_connection: bool = False
        
        # 框选状态（修改：不需要按alt，直接拖动即可框选）
        self._is_selecting: bool = False
        
        # 箭头拖拽状态
        self._dragged_arrow: Optional[ArrowItem] = None
        self._original_connection: Optional[ConnectionItem] = None
        self._original_is_bidirectional: bool = False
        self._temp_new_connection: Optional[QGraphicsPathItem] = None

        # 修改追踪系统
        self._changed: bool = False
        self._json_file_path: Optional[str] = None

        # 拖拽位置追踪
        self._drag_start_positions: Dict[int, QPointF] = {}

        # 创建样式面板（初始隐藏）
        self._style_panel: StylePanel = StylePanel(self)
        self._style_panel.setGeometry(10, self.height() - 60, self.width() - 20, 50)
        self._style_panel.hide()

        # 连接样式改变信号
        self._style_panel.styleChanged.connect(self._onStyleChanged)

        # 设置背景
        self._setupBackground()

        # 启用鼠标跟踪
        self.setMouseTracking(True)
    
    def _setupBackground(self) -> None:
        """设置画布背景"""
        self.setBackgroundBrush(QBrush(QColor("#F0F0F0")))
    
    @property
    def changed(self) -> bool:
        """画布是否有未保存的修改"""
        return self._changed

    @changed.setter
    def changed(self, value: bool) -> None:
        """设置修改状态，自动更新窗口标题"""
        if self._changed != value:
            self._changed = value
            self._updateWindowTitle()

    def _updateWindowTitle(self) -> None:
        """更新窗口标题显示"""
        parent = self.parent()
        while parent and parent.parent() is not None:
            parent = parent.parent()

        if parent and hasattr(parent, 'setWindowTitle'):
            software_name = "NodeCanvasWidget"

            if self._json_file_path:
                import os
                file_name = os.path.basename(self._json_file_path)
            else:
                file_name = "New Graph"

            title = f"{software_name} - {file_name}"
            if self._changed:
                title += " *"

            parent.setWindowTitle(title)

    def setJsonFilePath(self, file_path: Optional[str]) -> None:
        """设置当前 JSON 文件路径"""
        if self._json_file_path != file_path:
            self._json_file_path = file_path
            self._updateWindowTitle()

    def getJsonFilePath(self) -> Optional[str]:
        """获取当前 JSON 文件路径"""
        return self._json_file_path

    def resetChangedState(self) -> None:
        """重置修改状态（Save 成功后调用）"""
        self.changed = False

    def _onSelectionChanged(self) -> None:
        """选择改变时更新样式面板"""
        selected_nodes = [item for item in self._scene.selectedItems() if isinstance(item, NodeItem)]
        self._style_panel.setSelectedNodes(selected_nodes)
        self.nodeSelected.emit(selected_nodes[0] if selected_nodes else None)

    def _onStyleChanged(self) -> None:
        """样式改变时设置修改状态"""
        self.changed = True

    @property
    def nodes(self) -> List[NodeItem]:
        """获取所有节点"""
        return self._nodes.copy()
    
    @property
    def connections(self) -> List[ConnectionItem]:
        """获取所有连接"""
        return self._connections.copy()
    
    @property
    def startNode(self) -> Optional[NodeItem]:
        """获取起点节点"""
        return self._start_node

    @startNode.setter
    def startNode(self, node: Optional[NodeItem]) -> None:
        """设置起点节点"""
        # 清除旧的起点标记
        if self._start_node is not None and self._start_node != node:
            self._start_node.setStartMarkerVisible(False)

        self._start_node = node

        # 设置新的起点标记
        if node is not None:
            node.setStartMarkerVisible(True)
    
    def addNode(self, name: str, position: Optional[QPointF] = None, 
                shape: NodeShape = NodeShape.ELLIPSE) -> NodeItem:
        """
        添加一个新节点

        Args:
            name: 节点名称
            position: 节点位置，默认为画布中心
            shape: 节点形状

        Returns:
            创建的节点项
        """
        if position is None:
            position = self.mapToScene(self.viewport().rect().center())

        node = NodeItem(name, position, shape)
        self._scene.addItem(node)
        self._nodes.append(node)
        
        # 连接节点信号
        node.editRequested.connect(self._onNodeEditRequested)
        
        self.changed = True
        return node
    
    def removeNode(self, node: NodeItem) -> None:
        """移除节点"""
        if node not in self._nodes:
            return
        
        # 移除相关连接
        connections_to_remove = [conn for conn in self._connections 
                                if conn.sourceNode == node or conn.targetNode == node]
        for conn in connections_to_remove:
            self.removeConnection(conn)
        
        # 从场景中移除
        self._scene.removeItem(node)
        self._nodes.remove(node)
        
        # 如果删除的是起点节点，清除起点标记
        if self._start_node == node:
            self._start_node = None
        
        self.changed = True
    
    def addConnection(self, source_node: NodeItem, target_node: NodeItem,
                     is_bidirectional: bool = False,
                     connection_type: ConnectionType = ConnectionType.BEZIER) -> ConnectionItem:
        """
        添加两个节点之间的连接

        Args:
            source_node: 源节点
            target_node: 目标节点
            is_bidirectional: 是否是双向连接
            connection_type: 连线类型

        Returns:
            创建的连接线项
        """
        # 检查是否已存在连接
        for conn in self._connections:
            # 1. 检查源节点到目标节点的直接连接（严格重复）
            if conn.sourceNode == source_node and conn.targetNode == target_node:
                conn.flashError()  # 闪烁显示错误
                return conn

            # 2. 检查反向连接（目标到源的连接）
            if conn.sourceNode == target_node and conn.targetNode == source_node:
                # 反向连接已存在，将其转换为双向连线
                if conn.isBidirectional:
                    conn.flashError()  # 已经是双向，闪烁错误
                    return conn
                conn.isBidirectional = True
                conn.updatePath()
                self.changed = True
                return conn

        connection = ConnectionItem(source_node, target_node, is_bidirectional, connection_type)
        self._scene.addItem(connection)
        self._connections.append(connection)
        
        # 添加箭头到场景
        self._scene.addItem(connection.targetArrow)
        if connection.sourceArrow:
            self._scene.addItem(connection.sourceArrow)
        
        # 设置箭头拖拽回调
        connection.setArrowDragCallbacks(
            started=self._onArrowDragStarted,
            moved=self._onArrowDragMoved,
            finished=self._onArrowDragFinished
        )
        
        self.changed = True
        self.connectionCreated.emit(connection)
        return connection
    
    def removeConnection(self, connection: ConnectionItem) -> None:
        """移除连接"""
        if connection not in self._connections:
            return
        
        # 移除箭头
        connection.removeArrows()
        
        # 从场景中移除
        self._scene.removeItem(connection)
        self._connections.remove(connection)
        
        self.changed = True
    
    def _onNodeEditRequested(self, node: NodeItem) -> None:
        """节点编辑请求回调"""
        # 如果节点有自定义编辑器，打开它
        if node.editorClass:
            editor = node.editorClass(node)
            editor.setWindowTitle(editor.getTitle())
            editor.show()
    
    def _onArrowDragStarted(self, pos: QPointF) -> None:
        """箭头拖拽开始回调"""
        arrow = self.sender()
        if isinstance(arrow, ArrowItem):
            self._dragged_arrow = arrow
            self._original_connection = arrow.connection
            self._original_is_bidirectional = self._original_connection.isBidirectional
    
    def _onArrowDragMoved(self, pos: QPointF) -> None:
        """箭头拖拽移动回调"""
        pass
    
    def _onArrowDragFinished(self, pos: QPointF, is_success: bool) -> None:
        """箭头拖拽结束回调"""
        if not is_success and self._original_connection:
            # 连接失败，闪烁错误
            self._original_connection.flashError()
        
        self._dragged_arrow = None
        self._original_connection = None
        self._original_is_bidirectional = False
    
    def mousePressEvent(self, event: QMouseEvent) -> None:
        """鼠标按下事件"""
        scene_pos = self.mapToScene(event.pos())

        # 检查是否有节点正在编辑名称
        for node in self._nodes:
            if node.isEditingName:
                # 检查点击是否在代理控件内
                proxy = getattr(node, '_name_edit_proxy', None)
                if proxy and proxy.sceneBoundingRect().contains(scene_pos):
                    # 点击在编辑区域内，不处理
                    break
                else:
                    # 点击在编辑区域外，完成编辑
                    node._finishNameEdit()
                    # 继续处理其他鼠标事件
                    break

        if event.button() == Qt.MouseButton.MiddleButton:
            # 中键按下 - 开始平移
            self._is_panning = True
            self._pan_start_pos = event.pos()
            self.setCursor(Qt.CursorShape.ClosedHandCursor)
            event.accept()
            return
        
        elif event.button() == Qt.MouseButton.LeftButton:
            # 获取点击位置的图元
            items = self._scene.items(scene_pos)
            
            # 检查是否点击了箭头
            arrow_clicked = False
            for item in items:
                if isinstance(item, ArrowItem):
                    arrow_clicked = True
                    break
            
            if not arrow_clicked:
                # 检查是否点击了节点（用于创建连接）
                node_clicked = None
                for item in items:
                    if isinstance(item, NodeItem):
                        node_clicked = item
                        break
                
                if node_clicked:
                    # 检查是否点击在节点边缘（用于创建连接）
                    if self._is_on_node_edge(node_clicked, scene_pos):
                        # 从边缘拖拽 - 创建连接
                        self._is_creating_connection = True
                        self._source_node_for_connection = node_clicked
                        self._drag_start_pos = scene_pos

                        # 创建临时连接线
                        self._temp_connection = QGraphicsPathItem()
                        pen = QPen(QColor("#666666"), 2, Qt.PenStyle.DashLine)
                        self._temp_connection.setPen(pen)
                        self._temp_connection.setZValue(5)
                        self._scene.addItem(self._temp_connection)

                        event.accept()
                        return
                    else:
                        # 从内部拖拽 - 移动节点
                        # 记录拖拽起始位置用于移动追踪
                        self._drag_start_positions[id(node_clicked)] = node_clicked.pos()
                        # 调用父类处理拖拽
                        super().mousePressEvent(event)
                        return
                else:
                    # 没有点击节点，开始框选
                    self._is_selecting = True
                    self._selection_start_pos = scene_pos
                    
                    # 创建框选矩形
                    self._selection_rect = SelectionRect()
                    self._selection_rect.setRect(QRectF(scene_pos, scene_pos))
                    self._scene.addItem(self._selection_rect)
                    
                    # 如果没有按住Ctrl，清除当前选中
                    if not (event.modifiers() & Qt.KeyboardModifier.ControlModifier):
                        for node in self._nodes:
                            node.setSelected(False)
                    
                    event.accept()
                    return
        
        super().mousePressEvent(event)
    
    def mouseMoveEvent(self, event: QMouseEvent) -> None:
        """鼠标移动事件"""
        scene_pos = self.mapToScene(event.pos())
        
        if self._is_panning and self._pan_start_pos:
            # 平移画布
            delta = event.pos() - self._pan_start_pos
            self.horizontalScrollBar().setValue(
                self.horizontalScrollBar().value() - delta.x()
            )
            self.verticalScrollBar().setValue(
                self.verticalScrollBar().value() - delta.y()
            )
            self._pan_start_pos = event.pos()
            event.accept()
            return
        
        elif self._is_creating_connection and self._temp_connection:
            # 更新临时连接线
            if self._source_node_for_connection:
                source_pos = self._source_node_for_connection.sceneBoundingRect().center()
                
                # 创建路径
                path = QPainterPath()
                path.moveTo(source_pos)
                
                # 使用贝塞尔曲线
                dx = scene_pos.x() - source_pos.x()
                dy = scene_pos.y() - source_pos.y()
                distance = math.sqrt(dx * dx + dy * dy)
                offset = min(distance * 0.5, 150)
                
                if abs(dx) > abs(dy):
                    ctrl1 = QPointF(source_pos.x() + offset * (1 if dx > 0 else -1), source_pos.y())
                    ctrl2 = QPointF(scene_pos.x() - offset * (1 if dx > 0 else -1), scene_pos.y())
                else:
                    ctrl1 = QPointF(source_pos.x(), source_pos.y() + offset * (1 if dy > 0 else -1))
                    ctrl2 = QPointF(scene_pos.x(), scene_pos.y() - offset * (1 if dy > 0 else -1))
                
                path.cubicTo(ctrl1, ctrl2, scene_pos)
                self._temp_connection.setPath(path)
            
            event.accept()
            return
        
        elif self._is_selecting and self._selection_rect:
            # 更新框选矩形
            rect = QRectF(self._selection_start_pos, scene_pos).normalized()
            self._selection_rect.setRect(rect)
            
            # 选中矩形内的节点
            for node in self._nodes:
                node_rect = node.sceneBoundingRect()
                if rect.intersects(node_rect):
                    node.setSelected(True)
                else:
                    # 如果没有按住Ctrl，取消选中矩形外的节点
                    if not (event.modifiers() & Qt.KeyboardModifier.ControlModifier):
                        node.setSelected(False)
            
            event.accept()
            return
        
        super().mouseMoveEvent(event)
    
    def mouseReleaseEvent(self, event: QMouseEvent) -> None:
        """鼠标释放事件"""
        scene_pos = self.mapToScene(event.pos())
        
        if event.button() == Qt.MouseButton.MiddleButton:
            # 中键释放 - 结束平移
            self._is_panning = False
            self._pan_start_pos = None
            self.setCursor(Qt.CursorShape.ArrowCursor)
            event.accept()
            return
        
        elif event.button() == Qt.MouseButton.LeftButton:
            if self._is_creating_connection:
                # 完成连接创建
                if self._temp_connection:
                    self._scene.removeItem(self._temp_connection)
                    self._temp_connection = None
                
                # 查找目标节点
                items = self._scene.items(scene_pos)
                target_node = None
                for item in items:
                    if isinstance(item, NodeItem) and item != self._source_node_for_connection:
                        target_node = item
                        break
                
                if target_node and self._source_node_for_connection:
                    # 创建连接
                    self.addConnection(self._source_node_for_connection, target_node)
                
                self._is_creating_connection = False
                self._source_node_for_connection = None
                self._drag_start_pos = None
                event.accept()
                return
            
            elif self._is_selecting:
                # 完成框选
                if self._selection_rect:
                    self._scene.removeItem(self._selection_rect)
                    self._selection_rect = None
                
                self._is_selecting = False
                self._selection_start_pos = None
                event.accept()
                return
        
        super().mouseReleaseEvent(event)
    
    def mouseDoubleClickEvent(self, event: QMouseEvent) -> None:
        """鼠标双击事件"""
        scene_pos = self.mapToScene(event.pos())
        items = self._scene.items(scene_pos)
        
        # 查找双击的节点
        for item in items:
            if isinstance(item, NodeItem):
                # 如果节点有自定义编辑器，打开它
                if item.editorClass:
                    editor = item.editorClass(item)
                    editor.setWindowTitle(editor.getTitle())
                    editor.show()
                else:
                    # 默认行为：发射编辑请求信号
                    item.editRequested.emit(item)
                event.accept()
                return
        
        super().mouseDoubleClickEvent(event)
    
    def wheelEvent(self, event: QWheelEvent) -> None:
        """鼠标滚轮事件 - 缩放"""
        # 获取当前缩放因子
        current_transform = self.transform()
        current_scale = current_transform.m11()
        
        # 计算新的缩放因子
        delta = event.angleDelta().y()
        scale_factor = 1.1 if delta > 0 else 0.9
        new_scale = current_scale * scale_factor
        
        # 限制缩放范围
        if 0.1 <= new_scale <= 5.0:
            self.scale(scale_factor, scale_factor)
        
        event.accept()
    
    def contextMenuEvent(self, event: QContextMenuEvent) -> None:
        """右键菜单事件 - 根据点击位置显示不同菜单"""
        scene_pos = self.mapToScene(event.pos())
        item = self._scene.itemAt(scene_pos, QTransform())

        # 向上查找顶层图元
        top_item = item
        while top_item and top_item.parentItem():
            top_item = top_item.parentItem()

        # 检查是否是连接线的子项（箭头）
        connection_parent = None
        check_item = item
        while check_item:
            if isinstance(check_item, ConnectionItem):
                connection_parent = check_item
                break
            check_item = check_item.parentItem()

        if isinstance(top_item, NodeItem):
            # 在节点上右键
            self._showNodeContextMenu(top_item, event.globalPos())
        elif isinstance(top_item, ArrowItem):
            # 在箭头上右键
            self._showArrowContextMenu(top_item, event.globalPos())
        elif isinstance(top_item, ConnectionItem) or connection_parent:
            # 在连接线上右键（包括点击连接线本身或其子项）
            conn = top_item if isinstance(top_item, ConnectionItem) else connection_parent
            self._showConnectionContextMenu(conn, event.globalPos())
        else:
            # 在空白画布上右键
            self._showCanvasContextMenu(scene_pos, event.globalPos())

    def _showNodeContextMenu(self, node: NodeItem, pos) -> None:
        """显示节点右键菜单"""
        from qwork.qnode.enums import NodeShape

        menu = QMenu(self)

        # 编辑和重命名
        edit_action = menu.addAction("Edit")
        rename_action = menu.addAction("Rename")
        delete_action = menu.addAction("Delete")
        menu.addSeparator()

        # 形状切换子菜单
        shape_menu = menu.addMenu("Shape")
        ellipse_action = shape_menu.addAction("Ellipse")
        ellipse_action.setCheckable(True)
        ellipse_action.setChecked(node.nodeShape == NodeShape.ELLIPSE)

        rect_action = shape_menu.addAction("Rectangle")
        rect_action.setCheckable(True)
        rect_action.setChecked(node.nodeShape == NodeShape.RECTANGLE)

        diamond_action = shape_menu.addAction("Diamond")
        diamond_action.setCheckable(True)
        diamond_action.setChecked(node.nodeShape == NodeShape.DIAMOND)

        menu.addSeparator()

        # 设置起点
        set_start_action = menu.addAction("Set as Start Node")
        set_start_action.setEnabled(self._start_node != node)

        action = menu.exec(pos)
        if action == edit_action:
            self._onNodeEditRequested(node)
        elif action == rename_action:
            # TODO: 实现重命名功能
            pass
        elif action == delete_action:
            self.removeNode(node)
        elif action == ellipse_action:
            node.nodeShape = NodeShape.ELLIPSE
        elif action == rect_action:
            node.nodeShape = NodeShape.RECTANGLE
        elif action == diamond_action:
            node.nodeShape = NodeShape.DIAMOND
        elif action == set_start_action:
            self.startNode = node

    def _showArrowContextMenu(self, arrow: ArrowItem, pos) -> None:
        """显示箭头右键菜单"""
        menu = QMenu(self)

        remove_action = menu.addAction("Remove Connection")
        action = menu.exec(pos)
        if action == remove_action:
            connection = arrow.connection
            self.removeConnection(connection)

    def _showConnectionContextMenu(self, connection: ConnectionItem, pos) -> None:
        """显示连接线右键菜单"""
        menu = QMenu(self)

        # 切换连接类型
        toggle_type_action = menu.addAction("Toggle Line Type (Bezier/Straight)")
        menu.addSeparator()
        remove_action = menu.addAction("Delete Connection")

        action = menu.exec(pos)
        if action == toggle_type_action:
            connection.toggleConnectionType()
        elif action == remove_action:
            self.removeConnection(connection)

    def _showCanvasContextMenu(self, scene_pos: QPointF, pos) -> None:
        """显示画布右键菜单"""
        menu = QMenu(self)

        # 添加节点
        add_node_action = menu.addAction("Add Node")
        menu.addSeparator()

        # 布局动作
        layout_menu = menu.addMenu("Layout")

        compact_action = layout_menu.addAction("Compact")
        compact_action.triggered.connect(lambda: self._onLayout("compact"))

        circular_action = layout_menu.addAction("Circular")
        circular_action.triggered.connect(lambda: self._onLayout("circular"))

        grid_action = layout_menu.addAction("Grid")
        grid_action.triggered.connect(lambda: self._onLayout("grid"))

        hierarchical_action = layout_menu.addAction("Hierarchical")
        hierarchical_action.triggered.connect(lambda: self._onLayout("hierarchical"))

        force_action = layout_menu.addAction("Force Directed")
        force_action.triggered.connect(lambda: self._onLayout("force"))

        menu.addSeparator()

        # 自动适应视口
        fit_viewport_action = menu.addAction("Fit to Viewport")

        action = menu.exec(pos)
        if action == add_node_action:
            self._onAddNodeAt(scene_pos)
        elif action == fit_viewport_action:
            self._onFitViewport()
    
    def _onAddNodeAt(self, pos: QPointF) -> None:
        """在指定位置添加节点"""
        node_count = len(self._nodes)
        name = f"Node{node_count + 1}"
        self.addNode(name, pos)
    
    def _onLayout(self, strategy: str) -> None:
        """执行自动布局"""
        engine = DenseLayoutEngine(self)
        engine.autoLayout(strategy)
    
    def _onFitViewport(self) -> None:
        """自动适应视口"""
        fitter = ViewportFitter(self)
        fitter.fitViewport()

    def _is_on_node_edge(self, node: NodeItem, pos: QPointF) -> bool:
        """
        检查位置是否在节点边缘（用于创建连接）
        根据节点形状使用不同的检测逻辑
        """
        # 获取节点的本地坐标
        local_pos = node.mapFromScene(pos)
        center = node.rect().center()
        shape = node.nodeShape

        if shape == NodeShape.ELLIPSE:
            # 圆形：使用距离判定
            radius = node.radius
            distance = math.sqrt(
                (local_pos.x() - center.x()) ** 2 +
                (local_pos.y() - center.y()) ** 2
            )
            # 边缘区域：内圈75%到外圈100%
            return radius * 0.75 <= distance <= radius * 1.05

        elif shape == NodeShape.RECTANGLE:
            # 矩形：检查是否在边框区域内
            rect = node.rect()
            half_w = rect.width() / 2
            half_h = rect.height() / 2
            corner_radius = min(half_w, half_h) * 0.2

            # 内矩形边界（不含圆角的区域）
            inner_w = half_w - corner_radius
            inner_h = half_h - corner_radius

            # 计算到中心的距离（带符号，用于判断象限）
            dx = local_pos.x() - center.x()
            dy = local_pos.y() - center.y()
            adx = abs(dx)
            ady = abs(dy)

            # 检查是否在外矩形内（放宽一点边界）
            in_outer_rect = adx <= half_w * 1.02 and ady <= half_h * 1.02
            if not in_outer_rect:
                return False

            # 检查是否在内矩形外（即在边缘区域）
            in_inner_rect = adx <= inner_w and ady <= inner_h
            if in_inner_rect:
                return False

            # 在边框区域（包括直边和圆角区域）
            # 检查是否在圆角区域内
            if adx > inner_w and ady > inner_h:
                # 在圆角区域，需要找到正确的圆角圆心
                # 根据象限确定圆角圆心
                corner_cx = inner_w if dx > 0 else -inner_w
                corner_cy = inner_h if dy > 0 else -inner_h

                # 计算到圆角圆心的距离
                corner_dist = math.sqrt((dx - corner_cx) ** 2 + (dy - corner_cy) ** 2)
                # 圆角区域：距离小于圆角半径
                return corner_dist <= corner_radius * 1.02

            # 在直边区域
            return True

        elif shape == NodeShape.DIAMOND:
            # 菱形：检查是否在菱形边框区域内
            radius = node.radius
            dx = abs(local_pos.x() - center.x())
            dy = abs(local_pos.y() - center.y())

            # 菱形边界条件：|dx|/half_w + |dy|/half_h <= 1
            # 对于正方形菱形，half_w = half_h = radius
            outer_dist = (dx + dy) / radius

            # 内菱形边界（75%区域）
            inner_factor = 0.75
            inner_dist = (dx + dy) / (radius * inner_factor)

            # 边缘区域：在内菱形外，外菱形内
            return inner_dist >= 1 and outer_dist <= 1.05

        return False
    
    def keyPressEvent(self, event: QKeyEvent) -> None:
        """键盘按下事件"""
        if event.key() == Qt.Key.Key_Delete:
            # 删除选中的节点和连接
            self._deleteSelected()
            event.accept()
            return
        
        super().keyPressEvent(event)
    
    def _deleteSelected(self) -> None:
        """删除选中的节点和连接"""
        # 删除选中的节点
        nodes_to_remove = [node for node in self._nodes if node.isSelected()]
        for node in nodes_to_remove:
            self.removeNode(node)
        
        # 删除选中的连接（通过箭头）
        connections_to_remove = []
        for conn in self._connections:
            if conn.targetArrow.isSelected():
                connections_to_remove.append(conn)
            elif conn.sourceArrow and conn.sourceArrow.isSelected():
                connections_to_remove.append(conn)
        
        for conn in connections_to_remove:
            self.removeConnection(conn)
    
    def export(self, filter_empty: bool = False) -> dict:
        """
        导出画布数据为字典

        Args:
            filter_empty: 是否过滤空内容

        Returns:
            包含画布数据的字典
        """
        data = {
            "nodes": [],
            "connections": [],
            "start_node_id": None
        }

        # 导出节点
        for node in self._nodes:
            node_data = node.toDict()
            data["nodes"].append(node_data)

        # 导出连接
        for conn in self._connections:
            conn_data = {
                "source_id": id(conn.sourceNode),
                "target_id": id(conn.targetNode),
                "is_bidirectional": conn.isBidirectional,
                "connection_type": conn.connectionType.name
            }
            data["connections"].append(conn_data)

        # 导出起点节点
        if self._start_node:
            data["start_node_id"] = id(self._start_node)

        return data

    def exportToJson(self, filter_empty: bool = False) -> str:
        """
        导出画布数据为 JSON 字符串

        Args:
            filter_empty: 是否过滤空内容

        Returns:
            JSON 字符串
        """
        return json.dumps(self.export(filter_empty), indent=2, ensure_ascii=False)

    def _importDict(self, data: dict):
        """
        从字典数据构造画布节点和连接。
        将 code、targets、decorates 直接存入 node.data。

        参数:
            data (dict): 包含 'node_id': {code, targets, decorates} 的结构化数据
        """
        # 清除现有内容
        self.clear()

        node_map = {}  # 用于存储已创建的节点 ID 到 NodeItem 的映射

        # 第一步：创建所有节点并存储自定义数据
        for node_id, node_info in data.items():
            # 提取数据字段
            code_val = node_info.get('code', '')
            targets_val = node_info.get('targets', [])
            decorates_val = node_info.get('decorates', [])

            # 生成默认位置（避免重叠，实际可结合布局算法）
            import random
            x = random.randint(50, 800)
            y = random.randint(50, 600)

            # 创建节点，名称使用 node_id
            new_node = self.addNode(node_id, QPointF(x, y))
            node_map[node_id] = new_node

            # 将原始数据结构存入 node.data
            new_node.data['code'] = code_val
            new_node.data['targets'] = targets_val
            new_node.data['decorates'] = decorates_val

        # 第二步：根据 targets 创建连接
        for node_id, node_info in data.items():
            source_node = node_map.get(node_id)
            if not source_node:
                continue

            targets_list = node_info.get('targets', [])
            for target_id in targets_list:
                target_node = node_map.get(target_id)
                if target_node:
                    # 添加单向连接
                    self.addConnection(source_node, target_node, is_bidirectional=False)

        # 第三步：处理特殊装饰器逻辑（如 'listen'）
        # 此处仅做标记或初始化相关逻辑，具体实现取决于外部事件系统
        for node_id, node_info in data.items():
            decorates_list = node_info.get('decorates', [])
            if 'listen' in decorates_list:
                node_item = node_map.get(node_id)
                if node_item:
                    # 标记该节点为监听器，方便后续逻辑判断
                    node_item.data['is_listener'] = True
                    # 可根据需要在此处绑定信号槽或初始化监听状态

        # 可选：应用紧凑布局使节点整齐排列
        try:
            from qwork.qnode.layout_utils import DenseLayoutEngine
            engine = DenseLayoutEngine(self)
            engine.autoLayout("compact")
        except ImportError:
            pass

    def importData(self, data: dict | str) -> None:
        """
        从数据导入画布

        Args:
            data: 字典或 JSON 字符串
        """
        # 如果传入的是字符串，解析为字典
        if isinstance(data, str):
            try:
                data = json.loads(data)
            except json.JSONDecodeError as e:
                QMessageBox.critical(self, "Error", f"Invalid JSON: {e}")
                return

        if data.get("nodes") is None:
            # 非json格式
            try:
                self._importDict(data)
            except Exception as e:
                print(f"Can not parse data. For it's neither a json or a dict. Details:{e}")
            return
        # 清除现有内容
        self.clear()
        
        # 创建节点映射（旧id -> 新节点）
        node_map = {}

        # 导入节点
        for node_data in data.get("nodes", []):
            name = node_data.get("name", "Unnamed")
            pos_data = node_data.get("position", {"x": 0, "y": 0})
            position = QPointF(pos_data.get("x", 0), pos_data.get("y", 0))
            shape_name = node_data.get("shape", "ELLIPSE")
            try:
                shape = NodeShape[shape_name]
            except KeyError:
                shape = NodeShape.ELLIPSE
            
            node = self.addNode(name, position, shape)
            
            # 复制数据
            if "data" in node_data:
                node.data.update(node_data["data"])
            
            old_id = node_data.get("id")
            if old_id is not None:
                node_map[old_id] = node
        
        # 导入连接
        for conn_data in data.get("connections", []):
            source_id = conn_data.get("source_id")
            target_id = conn_data.get("target_id")
            is_bidirectional = conn_data.get("is_bidirectional", False)
            connection_type_name = conn_data.get("connection_type", "BEZIER")
            try:
                connection_type = ConnectionType[connection_type_name]
            except KeyError:
                connection_type = ConnectionType.BEZIER
            
            if source_id in node_map and target_id in node_map:
                source_node = node_map[source_id]
                target_node = node_map[target_id]
                self.addConnection(source_node, target_node, is_bidirectional, connection_type)
        
        # 设置起点节点
        start_node_id = data.get("start_node_id")
        if start_node_id in node_map:
            self.startNode = node_map[start_node_id]
        
        self.changed = False
    
    def clear(self) -> None:
        """清空画布"""
        # 移除所有连接
        for conn in self._connections[:]:
            self.removeConnection(conn)

        # 移除所有节点
        for node in self._nodes[:]:
            self._scene.removeItem(node)
        self._nodes.clear()

        self._start_node = None
        self.changed = False

    def resizeEvent(self, event) -> None:
        """窗口大小改变事件 - 更新样式面板位置"""
        super().resizeEvent(event)
        # 更新样式面板位置（贴合底部，margin 10）
        if hasattr(self, '_style_panel'):
            panel_height = 50
            panel_y = self.height() - panel_height - 10
            self._style_panel.setGeometry(10, panel_y, self.width() - 20, panel_height)
