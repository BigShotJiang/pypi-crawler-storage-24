"""
枚举定义模块

遵循代码规范:
- enum类不能定义函数，数据和方法必须分离
"""

from enum import Enum, auto


class NodeState(Enum):
    """节点状态枚举"""
    IDLE = auto()
    HOVER = auto()
    SELECTED = auto()


class NodeShape(Enum):
    """节点形状枚举"""
    ELLIPSE = auto()    # 椭圆形/圆形
    RECTANGLE = auto()  # 矩形
    DIAMOND = auto()    # 菱形


class ArrowState(Enum):
    """箭头状态枚举"""
    IDLE = auto()
    HOVER = auto()
    SELECTED = auto()


class ConnectionType(Enum):
    """连线类型枚举"""
    BEZIER = auto()     # 贝塞尔曲线
    STRAIGHT = auto()   # 直线
