"""
qnode库测试模块

使用PyQt6的测试框架测试所有功能
"""

import sys
import unittest
from typing import Optional

from PyQt6.QtWidgets import QApplication, QGraphicsScene
from PyQt6.QtCore import Qt, QPointF, QRectF
from PyQt6.QtTest import QTest

# 确保qnode在路径中
sys.path.insert(0, '/mnt/okcomputer/output')

from qnode import (
    NodeCanvas, NodeItem, ConnectionItem, ArrowItem,
    NodeState, NodeShape, ArrowState, ConnectionType,
    NodeStyle, ConnectionStyle, ArrowStyle,
    SelectionRect, QNodeEditor
)


class TestEnums(unittest.TestCase):
    """测试枚举类"""
    
    def testNodeState(self) -> None:
        """测试NodeState枚举"""
        self.assertEqual(NodeState.IDLE.name, "IDLE")
        self.assertEqual(NodeState.HOVER.name, "HOVER")
        self.assertEqual(NodeState.SELECTED.name, "SELECTED")
    
    def testNodeShape(self) -> None:
        """测试NodeShape枚举"""
        self.assertEqual(NodeShape.ELLIPSE.name, "ELLIPSE")
        self.assertEqual(NodeShape.RECTANGLE.name, "RECTANGLE")
        self.assertEqual(NodeShape.DIAMOND.name, "DIAMOND")
    
    def testArrowState(self) -> None:
        """测试ArrowState枚举"""
        self.assertEqual(ArrowState.IDLE.name, "IDLE")
        self.assertEqual(ArrowState.HOVER.name, "HOVER")
        self.assertEqual(ArrowState.SELECTED.name, "SELECTED")
    
    def testConnectionType(self) -> None:
        """测试ConnectionType枚举"""
        self.assertEqual(ConnectionType.BEZIER.name, "BEZIER")
        self.assertEqual(ConnectionType.STRAIGHT.name, "STRAIGHT")


class TestStyles(unittest.TestCase):
    """测试样式类"""
    
    def testNodeStyle(self) -> None:
        """测试NodeStyle"""
        style = NodeStyle()
        self.assertIsNotNone(style.idle_fill)
        self.assertIsNotNone(style.idle_stroke)
        self.assertIsNotNone(style.hover_overlay)
        self.assertIsNotNone(style.selected_stroke)
        self.assertIsNotNone(style.selected_overlay)
        self.assertEqual(style.stroke_width, 2.0)
        self.assertIsNotNone(style.text_color)
    
    def testConnectionStyle(self) -> None:
        """测试ConnectionStyle"""
        style = ConnectionStyle()
        self.assertIsNotNone(style.normal_color)
        self.assertIsNotNone(style.selected_color)
        self.assertIsNotNone(style.hover_color)
        self.assertEqual(style.stroke_width, 2.0)
        self.assertEqual(style.selected_stroke_width, 3.0)
    
    def testArrowStyle(self) -> None:
        """测试ArrowStyle"""
        style = ArrowStyle()
        self.assertIsNotNone(style.normal_color)
        self.assertIsNotNone(style.selected_color)
        self.assertIsNotNone(style.hover_color)
        self.assertEqual(style.arrow_size, 12.0)
        self.assertEqual(style.stroke_width, 2.0)


class TestNodeItem(unittest.TestCase):
    """测试NodeItem类"""
    
    @classmethod
    def setUpClass(cls) -> None:
        """设置测试类"""
        cls.app = QApplication.instance()
        if cls.app is None:
            cls.app = QApplication(sys.argv)
    
    def setUp(self) -> None:
        """设置每个测试"""
        self.scene = QGraphicsScene()
        self.node = NodeItem("TestNode", QPointF(100, 100), NodeShape.ELLIPSE)
        self.scene.addItem(self.node)
    
    def tearDown(self) -> None:
        """清理每个测试"""
        self.scene.clear()
    
    def testNodeCreation(self) -> None:
        """测试节点创建"""
        self.assertEqual(self.node.name, "TestNode")
        self.assertEqual(self.node.pos(), QPointF(100, 100))
        self.assertEqual(self.node.nodeShape, NodeShape.ELLIPSE)
        self.assertEqual(self.node.state, NodeState.IDLE)
    
    def testNodeNameChange(self) -> None:
        """测试节点名称修改"""
        self.node.name = "NewName"
        self.assertEqual(self.node.name, "NewName")
    
    def testNodeShapeChange(self) -> None:
        """测试节点形状修改"""
        self.node.nodeShape = NodeShape.RECTANGLE
        self.assertEqual(self.node.nodeShape, NodeShape.RECTANGLE)
        
        self.node.nodeShape = NodeShape.DIAMOND
        self.assertEqual(self.node.nodeShape, NodeShape.DIAMOND)
    
    def testNodeData(self) -> None:
        """测试节点数据"""
        # 数据字典应该是可修改的
        self.node.data["key"] = "value"
        self.assertEqual(self.node.data["key"], "value")
        
        self.node.data["number"] = 42
        self.assertEqual(self.node.data["number"], 42)
    
    def testNodeEditorClass(self) -> None:
        """测试节点编辑器类"""
        self.assertIsNone(self.node.editorClass)
        
        # 设置编辑器类
        class TestEditor(QNodeEditor):
            pass
        
        self.node.editorClass = TestEditor
        self.assertEqual(self.node.editorClass, TestEditor)
    
    def testNodeSelection(self) -> None:
        """测试节点选择"""
        self.node.setSelected(True)
        self.assertTrue(self.node.isSelected())
        self.assertEqual(self.node.state, NodeState.SELECTED)
        
        self.node.setSelected(False)
        self.assertFalse(self.node.isSelected())
        self.assertEqual(self.node.state, NodeState.IDLE)
    
    def testNodeToDict(self) -> None:
        """测试节点转字典"""
        self.node.data["test"] = "data"
        data = self.node.toDict()
        
        self.assertIn("id", data)
        self.assertEqual(data["name"], "TestNode")
        self.assertEqual(data["shape"], "ELLIPSE")
        self.assertIn("position", data)
        self.assertIn("data", data)
        self.assertEqual(data["data"]["test"], "data")
    
    def testNodeFromDict(self) -> None:
        """测试节点从字典更新"""
        data = {
            "name": "UpdatedName",
            "shape": "RECTANGLE",
            "position": {"x": 200, "y": 300},
            "data": {"custom": "value"}
        }
        self.node.fromDict(data)
        
        self.assertEqual(self.node.name, "UpdatedName")
        self.assertEqual(self.node.nodeShape, NodeShape.RECTANGLE)
        self.assertEqual(self.node.pos(), QPointF(200, 300))
        self.assertEqual(self.node.data["custom"], "value")
    
    def testGetEdgePointEllipse(self) -> None:
        """测试圆形节点边缘点计算"""
        self.node.shape = NodeShape.ELLIPSE
        center = self.node.sceneBoundingRect().center()
        target = QPointF(center.x() + 200, center.y())
        edge = self.node.getEdgePoint(target)
        
        # 边缘点应该在中心右侧
        self.assertGreater(edge.x(), center.x())
    
    def testGetEdgePointRectangle(self) -> None:
        """测试矩形节点边缘点计算"""
        self.node.shape = NodeShape.RECTANGLE
        center = self.node.sceneBoundingRect().center()
        target = QPointF(center.x() + 200, center.y())
        edge = self.node.getEdgePoint(target)
        
        # 边缘点应该在中心右侧
        self.assertGreater(edge.x(), center.x())
    
    def testGetEdgePointDiamond(self) -> None:
        """测试菱形节点边缘点计算"""
        self.node.shape = NodeShape.DIAMOND
        center = self.node.sceneBoundingRect().center()
        target = QPointF(center.x() + 200, center.y())
        edge = self.node.getEdgePoint(target)

        # 边缘点应该在中心右侧
        self.assertGreater(edge.x(), center.x())

    def testSetColor(self) -> None:
        """测试设置节点颜色"""
        from PyQt6.QtGui import QColor

        # 设置新颜色
        new_color = QColor(255, 0, 0)  # 红色
        self.node.setColor(new_color)

        # 验证颜色已设置
        self.assertEqual(self.node._style.idle_fill, new_color)

    def testSetBorder(self) -> None:
        """测试设置节点边框"""
        from PyQt6.QtGui import QColor

        # 设置边框宽度和颜色
        border_color = QColor(0, 255, 0)  # 绿色
        self.node.setBorder(3, border_color)

        # 验证边框设置
        self.assertEqual(self.node._style.stroke_width, 3)
        self.assertEqual(self.node._style.idle_stroke, border_color)

        # 测试无边框（宽度<=0）
        self.node.setBorder(0)
        # 应该设置NoPen
        pen = self.node.pen()
        self.assertEqual(pen.style(), Qt.PenStyle.NoPen)

    def testNodeNameEditingState(self) -> None:
        """测试节点名称编辑状态"""
        # 初始状态应该不在编辑
        self.assertFalse(self.node.isEditingName)

        # 开始编辑
        self.node._startNameEdit()
        self.assertTrue(self.node.isEditingName)

        # 完成编辑
        self.node._finishNameEdit()
        self.assertFalse(self.node.isEditingName)

    def testNodeNameEditCancel(self) -> None:
        """测试取消节点名称编辑（保持原名称）"""
        original_name = self.node.name

        # 开始编辑
        self.node._startNameEdit()
        self.assertTrue(self.node.isEditingName)

        # 修改文本但不确认
        if self.node._name_edit:
            self.node._name_edit.setText("NewName")

        # 直接调用_finishNameEdit（模拟点击外部取消）
        self.node._finishNameEdit()

        # 由于文本被修改了，名称应该改变
        # 如果要测试取消功能，需要更复杂的逻辑
        self.assertFalse(self.node.isEditingName)

    def testNodeNameEditProxyWidget(self) -> None:
        """测试节点名称编辑使用QGraphicsProxyWidget"""
        # 开始编辑
        self.node._startNameEdit()
        self.assertTrue(self.node.isEditingName)

        # 检查代理控件存在
        self.assertTrue(hasattr(self.node, '_name_edit_proxy'))
        self.assertIsNotNone(self.node._name_edit_proxy)

        # 检查代理控件的父项是节点本身
        self.assertEqual(self.node._name_edit_proxy.parentItem(), self.node)

        # 完成编辑
        self.node._finishNameEdit()
        self.assertFalse(self.node.isEditingName)


class TestConnectionItem(unittest.TestCase):
    """测试ConnectionItem类"""
    
    @classmethod
    def setUpClass(cls) -> None:
        """设置测试类"""
        cls.app = QApplication.instance()
        if cls.app is None:
            cls.app = QApplication(sys.argv)
    
    def setUp(self) -> None:
        """设置每个测试"""
        self.scene = QGraphicsScene()
        self.source_node = NodeItem("Source", QPointF(0, 0))
        self.target_node = NodeItem("Target", QPointF(200, 0))
        self.scene.addItem(self.source_node)
        self.scene.addItem(self.target_node)
        
        self.connection = ConnectionItem(
            self.source_node, self.target_node,
            is_bidirectional=False,
            connection_type=ConnectionType.BEZIER
        )
        self.scene.addItem(self.connection)
        self.scene.addItem(self.connection.targetArrow)
    
    def tearDown(self) -> None:
        """清理每个测试"""
        self.connection.removeArrows()
        self.scene.removeItem(self.connection)
        self.scene.clear()
    
    def testConnectionCreation(self) -> None:
        """测试连接创建"""
        self.assertEqual(self.connection.sourceNode, self.source_node)
        self.assertEqual(self.connection.targetNode, self.target_node)
        self.assertFalse(self.connection.isBidirectional)
        self.assertEqual(self.connection.connectionType, ConnectionType.BEZIER)
    
    def testConnectionTypeToggle(self) -> None:
        """测试连接类型切换"""
        self.assertEqual(self.connection.connectionType, ConnectionType.BEZIER)
        
        self.connection.toggleConnectionType()
        self.assertEqual(self.connection.connectionType, ConnectionType.STRAIGHT)
        
        self.connection.toggleConnectionType()
        self.assertEqual(self.connection.connectionType, ConnectionType.BEZIER)
    
    def testBidirectionalToggle(self) -> None:
        """测试双向连接切换"""
        self.assertFalse(self.connection.isBidirectional)
        
        self.connection.isBidirectional = True
        self.assertTrue(self.connection.isBidirectional)
        self.assertIsNotNone(self.connection.sourceArrow)
        
        self.connection.isBidirectional = False
        self.assertFalse(self.connection.isBidirectional)
        self.assertIsNone(self.connection.sourceArrow)
    
    def testSwapDirection(self) -> None:
        """测试连接方向交换"""
        original_source = self.connection.sourceNode
        original_target = self.connection.targetNode
        
        self.connection.swapDirection()

        self.assertEqual(self.connection.sourceNode, original_target)
        self.assertEqual(self.connection.targetNode, original_source)

    def testConnectionSetColor(self) -> None:
        """测试设置连接线颜色"""
        from PyQt6.QtGui import QColor

        new_color = QColor(255, 0, 0)  # 红色
        self.connection.setColor(new_color)

        # 验证颜色已设置
        self.assertEqual(self.connection._style.normal_color, new_color)

    def testConnectionSetBorder(self) -> None:
        """测试设置连接线边框（线宽）"""
        from PyQt6.QtGui import QColor

        # 设置线宽和颜色
        border_color = QColor(0, 255, 0)  # 绿色
        self.connection.setBorder(5, border_color)

        # 验证设置
        self.assertEqual(self.connection._style.stroke_width, 5)


class TestArrowItem(unittest.TestCase):
    """测试ArrowItem类"""
    
    @classmethod
    def setUpClass(cls) -> None:
        """设置测试类"""
        cls.app = QApplication.instance()
        if cls.app is None:
            cls.app = QApplication(sys.argv)
    
    def setUp(self) -> None:
        """设置每个测试"""
        self.scene = QGraphicsScene()
        self.source_node = NodeItem("Source", QPointF(0, 0))
        self.target_node = NodeItem("Target", QPointF(200, 0))
        self.scene.addItem(self.source_node)
        self.scene.addItem(self.target_node)
        
        self.connection = ConnectionItem(self.source_node, self.target_node)
        self.scene.addItem(self.connection)
        self.arrow = self.connection.targetArrow
    
    def tearDown(self) -> None:
        """清理每个测试"""
        self.connection.removeArrows()
        self.scene.removeItem(self.connection)
        self.scene.clear()
    
    def testArrowCreation(self) -> None:
        """测试箭头创建"""
        self.assertEqual(self.arrow.connection, self.connection)
        self.assertFalse(self.arrow.isSourceArrow)
    
    def testArrowSelection(self) -> None:
        """测试箭头选择"""
        self.arrow.setSelected(True)
        self.assertTrue(self.arrow.isSelected())

        self.arrow.setSelected(False)
        self.assertFalse(self.arrow.isSelected())

    def testArrowSetColor(self) -> None:
        """测试设置箭头颜色"""
        from PyQt6.QtGui import QColor

        new_color = QColor(255, 0, 0)  # 红色
        self.arrow.setColor(new_color)

        # 验证颜色已设置
        self.assertEqual(self.arrow._style.normal_color, new_color)

    def testArrowSetBorder(self) -> None:
        """测试设置箭头边框"""
        from PyQt6.QtGui import QColor

        # 设置边框宽度和颜色
        border_color = QColor(0, 255, 0)  # 绿色
        self.arrow.setBorder(3, border_color)

        # 验证设置
        self.assertEqual(self.arrow._style.stroke_width, 3)


class TestSelectionRect(unittest.TestCase):
    """测试SelectionRect类"""
    
    @classmethod
    def setUpClass(cls) -> None:
        """设置测试类"""
        cls.app = QApplication.instance()
        if cls.app is None:
            cls.app = QApplication(sys.argv)
    
    def setUp(self) -> None:
        """设置每个测试"""
        self.scene = QGraphicsScene()
        self.selection_rect = SelectionRect()
        self.scene.addItem(self.selection_rect)
    
    def tearDown(self) -> None:
        """清理每个测试"""
        self.scene.clear()
    
    def testSelectionRectCreation(self) -> None:
        """测试框选矩形创建"""
        self.assertIsNotNone(self.selection_rect)
        self.assertEqual(self.selection_rect.zValue(), 1000)

    def testSelectionRectSetColor(self) -> None:
        """测试设置框选矩形颜色"""
        from PyQt6.QtGui import QColor

        new_color = QColor(255, 0, 0, 100)  # 半透明红色
        self.selection_rect.setColor(new_color)

        # 验证颜色已设置
        self.assertEqual(self.selection_rect._fill_color, new_color)

    def testSelectionRectSetBorder(self) -> None:
        """测试设置框选矩形边框"""
        from PyQt6.QtGui import QColor

        # 设置边框宽度和颜色
        border_color = QColor(0, 255, 0)  # 绿色
        self.selection_rect.setBorder(3, border_color)

        # 验证设置
        self.assertEqual(self.selection_rect._border_width, 3)
        self.assertEqual(self.selection_rect._border_color, border_color)


class TestNodeCanvas(unittest.TestCase):
    """测试NodeCanvas类"""
    
    @classmethod
    def setUpClass(cls) -> None:
        """设置测试类"""
        cls.app = QApplication.instance()
        if cls.app is None:
            cls.app = QApplication(sys.argv)
    
    def setUp(self) -> None:
        """设置每个测试"""
        self.canvas = NodeCanvas()
        self.canvas.resize(800, 600)
        self.canvas.show()
    
    def tearDown(self) -> None:
        """清理每个测试"""
        self.canvas.close()
    
    def testCanvasCreation(self) -> None:
        """测试画布创建"""
        self.assertIsNotNone(self.canvas.scene())
        self.assertEqual(len(self.canvas.nodes), 0)
        self.assertEqual(len(self.canvas.connections), 0)
    
    def testAddNode(self) -> None:
        """测试添加节点"""
        node = self.canvas.addNode("TestNode", QPointF(100, 100))
        self.assertIn(node, self.canvas.nodes)
        self.assertEqual(node.name, "TestNode")
    
    def testRemoveNode(self) -> None:
        """测试移除节点"""
        node = self.canvas.addNode("TestNode")
        self.canvas.removeNode(node)
        self.assertNotIn(node, self.canvas.nodes)
    
    def testAddConnection(self) -> None:
        """测试添加连接"""
        node1 = self.canvas.addNode("Node1", QPointF(0, 0))
        node2 = self.canvas.addNode("Node2", QPointF(200, 0))
        
        connection = self.canvas.addConnection(node1, node2)
        self.assertIn(connection, self.canvas.connections)
        self.assertEqual(connection.sourceNode, node1)
        self.assertEqual(connection.targetNode, node2)
    
    def testRemoveConnection(self) -> None:
        """测试移除连接"""
        node1 = self.canvas.addNode("Node1")
        node2 = self.canvas.addNode("Node2")
        connection = self.canvas.addConnection(node1, node2)
        
        self.canvas.removeConnection(connection)
        self.assertNotIn(connection, self.canvas.connections)
    
    def testStartNode(self) -> None:
        """测试起点节点"""
        node = self.canvas.addNode("StartNode")
        self.canvas.startNode = node
        
        self.assertEqual(self.canvas.startNode, node)
    
    def testExportImport(self) -> None:
        """测试导出导入"""
        # 创建一些节点和连接
        node1 = self.canvas.addNode("Node1", QPointF(0, 0))
        node2 = self.canvas.addNode("Node2", QPointF(100, 100))
        self.canvas.addConnection(node1, node2)
        self.canvas.startNode = node1
        
        # 导出（现在返回字典）
        data = self.canvas.export()
        self.assertIsInstance(data, dict)
        self.assertIn("nodes", data)
        self.assertIn("connections", data)

        # 测试导出为 JSON 字符串
        json_str = self.canvas.exportToJson()
        self.assertIsInstance(json_str, str)
        self.assertIn("nodes", json_str)

        # 清空
        self.canvas.clear()
        self.assertEqual(len(self.canvas.nodes), 0)
        self.assertEqual(len(self.canvas.connections), 0)

        # 导入字典
        self.canvas.importData(data)
        self.assertEqual(len(self.canvas.nodes), 2)
        self.assertEqual(len(self.canvas.connections), 1)
    
    def testClear(self) -> None:
        """测试清空画布"""
        node1 = self.canvas.addNode("Node1")
        node2 = self.canvas.addNode("Node2")
        self.canvas.addConnection(node1, node2)
        
        self.canvas.clear()
        self.assertEqual(len(self.canvas.nodes), 0)
        self.assertEqual(len(self.canvas.connections), 0)
    
    def testChangedState(self) -> None:
        """测试修改状态"""
        self.assertFalse(self.canvas.changed)

        self.canvas.addNode("TestNode")
        self.assertTrue(self.canvas.changed)

    def testClickOutsideToCancelNameEdit(self) -> None:
        """测试点击画布外部取消节点名称编辑"""
        # 添加节点
        node = self.canvas.addNode("TestNode", QPointF(100, 100))

        # 开始编辑
        node._startNameEdit()
        self.assertTrue(node.isEditingName)

        # 获取编辑控件的位置（在节点中心）
        proxy_rect = node._name_edit_proxy.sceneBoundingRect()
        edit_center = proxy_rect.center()

        # 模拟点击画布外部（远离编辑控件）
        outside_pos = QPointF(edit_center.x() + 200, edit_center.y() + 200)

        # 创建鼠标事件
        from PyQt6.QtWidgets import QApplication
        from PyQt6.QtCore import QPoint

        # 将场景坐标转换为视图坐标
        view_pos = self.canvas.mapFromScene(outside_pos)

        # 发送鼠标按下事件
        QTest.mouseClick(self.canvas.viewport(), Qt.MouseButton.LeftButton,
                        pos=view_pos)

        # 检查编辑是否被取消
        self.assertFalse(node.isEditingName)

    def testEdgeDetectionEllipse(self) -> None:
        """测试圆形节点边缘检测"""
        node = self.canvas.addNode("EllipseNode", QPointF(100, 100), NodeShape.ELLIPSE)
        center = node.sceneBoundingRect().center()
        radius = node.radius

        # 边缘位置（应该检测到）
        edge_pos = QPointF(center.x() + radius * 0.9, center.y())
        self.assertTrue(self.canvas._is_on_node_edge(node, edge_pos))

        # 中心位置（不应该检测到）
        center_pos = QPointF(center.x() + radius * 0.5, center.y())
        self.assertFalse(self.canvas._is_on_node_edge(node, center_pos))

        # 外部位置（不应该检测到）
        outside_pos = QPointF(center.x() + radius * 1.2, center.y())
        self.assertFalse(self.canvas._is_on_node_edge(node, outside_pos))

    def testEdgeDetectionRectangle(self) -> None:
        """测试矩形节点边缘检测，包括角落区域"""
        node = self.canvas.addNode("RectNode", QPointF(100, 100), NodeShape.RECTANGLE)
        center = node.sceneBoundingRect().center()
        rect = node.rect()
        half_w = rect.width() / 2
        half_h = rect.height() / 2

        # 右边缘位置（应该检测到）
        right_edge = QPointF(center.x() + half_w * 0.9, center.y())
        self.assertTrue(self.canvas._is_on_node_edge(node, right_edge))

        # 左边缘位置（应该检测到）
        left_edge = QPointF(center.x() - half_w * 0.9, center.y())
        self.assertTrue(self.canvas._is_on_node_edge(node, left_edge))

        # 上边缘位置（应该检测到）
        top_edge = QPointF(center.x(), center.y() - half_h * 0.9)
        self.assertTrue(self.canvas._is_on_node_edge(node, top_edge))

        # 下边缘位置（应该检测到）
        bottom_edge = QPointF(center.x(), center.y() + half_h * 0.9)
        self.assertTrue(self.canvas._is_on_node_edge(node, bottom_edge))

        # 角落区域（应该检测到）- 在圆角边缘附近
        # 计算一个更靠近实际边界的测试点
        inner_w = half_w - min(half_w, half_h) * 0.2
        inner_h = half_h - min(half_w, half_h) * 0.2
        # 在角落附近，稍微超出内矩形边界
        corner_pos = QPointF(center.x() + inner_w * 1.05, center.y() + inner_h * 1.05)
        self.assertTrue(self.canvas._is_on_node_edge(node, corner_pos))

        # 中心位置（不应该检测到）
        center_pos = QPointF(center.x(), center.y())
        self.assertFalse(self.canvas._is_on_node_edge(node, center_pos))

        # 外部位置（不应该检测到）
        outside_pos = QPointF(center.x() + half_w * 1.2, center.y())
        self.assertFalse(self.canvas._is_on_node_edge(node, outside_pos))

    def testEdgeDetectionRectangleCorners(self) -> None:
        """测试矩形节点四个角落的边缘检测"""
        node = self.canvas.addNode("RectNode", QPointF(100, 100), NodeShape.RECTANGLE)
        center = node.sceneBoundingRect().center()
        rect = node.rect()
        half_w = rect.width() / 2
        half_h = rect.height() / 2
        corner_radius = min(half_w, half_h) * 0.2
        inner_w = half_w - corner_radius
        inner_h = half_h - corner_radius

        # 测试四个角落（在圆角边缘附近）
        # 需要确保测试点在 inner_w/h 之外，但在 half_w/h 之内
        # 使用 inner_w * 1.1 确保在圆角区域内
        corners = [
            ("左下", QPointF(center.x() - inner_w * 1.1, center.y() + inner_h * 1.1)),
            ("右下", QPointF(center.x() + inner_w * 1.1, center.y() + inner_h * 1.1)),
            ("左上", QPointF(center.x() - inner_w * 1.1, center.y() - inner_h * 1.1)),
            ("右上", QPointF(center.x() + inner_w * 1.1, center.y() - inner_h * 1.1)),
        ]

        for name, pos in corners:
            with self.subTest(corner=name):
                self.assertTrue(
                    self.canvas._is_on_node_edge(node, pos),
                    f"{name}角落应该被检测为边缘区域"
                )

    def testEdgeDetectionDiamond(self) -> None:
        """测试菱形节点边缘检测"""
        node = self.canvas.addNode("DiamondNode", QPointF(100, 100), NodeShape.DIAMOND)
        center = node.sceneBoundingRect().center()
        radius = node.radius

        # 右顶点边缘位置（应该检测到）
        right_edge = QPointF(center.x() + radius * 0.9, center.y())
        self.assertTrue(self.canvas._is_on_node_edge(node, right_edge))

        # 上顶点边缘位置（应该检测到）
        top_edge = QPointF(center.x(), center.y() - radius * 0.9)
        self.assertTrue(self.canvas._is_on_node_edge(node, top_edge))

        # 中心位置（不应该检测到）
        center_pos = QPointF(center.x() + radius * 0.3, center.y() + radius * 0.3)
        self.assertFalse(self.canvas._is_on_node_edge(node, center_pos))

        # 外部位置（不应该检测到）
        outside_pos = QPointF(center.x() + radius * 1.2, center.y())
        self.assertFalse(self.canvas._is_on_node_edge(node, outside_pos))

    def testDuplicateConnectionFlashError(self) -> None:
        """测试重复连接时触发错误闪烁"""
        node1 = self.canvas.addNode("Node1", QPointF(0, 0))
        node2 = self.canvas.addNode("Node2", QPointF(200, 0))

        # 创建第一个连接
        conn1 = self.canvas.addConnection(node1, node2)
        self.assertEqual(len(self.canvas.connections), 1)

        # 尝试创建重复连接，应该返回已存在的连接并触发 flashError
        conn2 = self.canvas.addConnection(node1, node2)
        self.assertEqual(conn1, conn2)  # 返回同一个连接
        self.assertEqual(len(self.canvas.connections), 1)  # 连接数量不变

    def testReverseConnectionBecomesBidirectional(self) -> None:
        """测试反向连接转换为双向连接"""
        node1 = self.canvas.addNode("Node1", QPointF(0, 0))
        node2 = self.canvas.addNode("Node2", QPointF(200, 0))

        # 创建 node1 -> node2 的连接
        conn1 = self.canvas.addConnection(node1, node2)
        self.assertFalse(conn1.isBidirectional)
        self.assertEqual(len(self.canvas.connections), 1)

        # 创建反向连接 node2 -> node1，应该将原连接变为双向
        conn2 = self.canvas.addConnection(node2, node1)
        self.assertTrue(conn1.isBidirectional)  # 原连接变为双向
        self.assertEqual(conn1, conn2)  # 返回同一个连接
        self.assertEqual(len(self.canvas.connections), 1)  # 连接数量不变

    def testDuplicateBidirectionalConnectionFlashError(self) -> None:
        """测试重复双向连接时触发错误闪烁"""
        node1 = self.canvas.addNode("Node1", QPointF(0, 0))
        node2 = self.canvas.addNode("Node2", QPointF(200, 0))

        # 创建双向连接
        conn1 = self.canvas.addConnection(node1, node2, is_bidirectional=True)
        self.assertTrue(conn1.isBidirectional)

        # 尝试创建反向连接，应该触发 flashError
        conn2 = self.canvas.addConnection(node2, node1)
        self.assertEqual(conn1, conn2)
        self.assertTrue(conn1.isBidirectional)  # 保持双向


class TestQNodeEditor(unittest.TestCase):
    """测试QNodeEditor类"""
    
    @classmethod
    def setUpClass(cls) -> None:
        """设置测试类"""
        cls.app = QApplication.instance()
        if cls.app is None:
            cls.app = QApplication(sys.argv)
    
    def setUp(self) -> None:
        """设置每个测试"""
        self.scene = QGraphicsScene()
        self.node = NodeItem("TestNode")
        self.scene.addItem(self.node)
        self.editor = QNodeEditor(self.node)
    
    def tearDown(self) -> None:
        """清理每个测试"""
        self.editor.close()
        self.scene.clear()
    
    def testEditorCreation(self) -> None:
        """测试编辑器创建"""
        self.assertEqual(self.editor.node, self.node)
    
    def testEditorTitle(self) -> None:
        """测试编辑器标题"""
        title = self.editor.getTitle()
        self.assertIn("TestNode", title)
    
    def testEditorSaveLoad(self) -> None:
        """测试编辑器保存和加载"""
        self.assertTrue(self.editor.save())
        self.assertTrue(self.editor.load())


class TestNodeShapes(unittest.TestCase):
    """测试不同节点形状"""
    
    @classmethod
    def setUpClass(cls) -> None:
        """设置测试类"""
        cls.app = QApplication.instance()
        if cls.app is None:
            cls.app = QApplication(sys.argv)
    
    def testEllipseShape(self) -> None:
        """测试椭圆形"""
        node = NodeItem("EllipseNode", shape=NodeShape.ELLIPSE)
        self.assertEqual(node.nodeShape, NodeShape.ELLIPSE)
        
        # 测试边缘点计算
        center = QPointF(100, 100)
        node.setPos(center)
        target = QPointF(200, 100)
        edge = node.getEdgePoint(target)
        self.assertIsNotNone(edge)
    
    def testRectangleShape(self) -> None:
        """测试矩形"""
        node = NodeItem("RectNode", shape=NodeShape.RECTANGLE)
        self.assertEqual(node.nodeShape, NodeShape.RECTANGLE)
        
        # 测试边缘点计算
        center = QPointF(100, 100)
        node.setPos(center)
        target = QPointF(200, 100)
        edge = node.getEdgePoint(target)
        self.assertIsNotNone(edge)
    
    def testDiamondShape(self) -> None:
        """测试菱形"""
        node = NodeItem("DiamondNode", shape=NodeShape.DIAMOND)
        self.assertEqual(node.nodeShape, NodeShape.DIAMOND)
        
        # 测试边缘点计算
        center = QPointF(100, 100)
        node.setPos(center)
        target = QPointF(200, 100)
        edge = node.getEdgePoint(target)
        self.assertIsNotNone(edge)


class TestConnectionTypes(unittest.TestCase):
    """测试不同连接类型"""
    
    @classmethod
    def setUpClass(cls) -> None:
        """设置测试类"""
        cls.app = QApplication.instance()
        if cls.app is None:
            cls.app = QApplication(sys.argv)
    
    def setUp(self) -> None:
        """设置每个测试"""
        self.scene = QGraphicsScene()
        self.source_node = NodeItem("Source", QPointF(0, 0))
        self.target_node = NodeItem("Target", QPointF(200, 0))
        self.scene.addItem(self.source_node)
        self.scene.addItem(self.target_node)
    
    def tearDown(self) -> None:
        """清理每个测试"""
        self.scene.clear()
    
    def testBezierConnection(self) -> None:
        """测试贝塞尔曲线连接"""
        connection = ConnectionItem(
            self.source_node, self.target_node,
            connection_type=ConnectionType.BEZIER
        )
        self.scene.addItem(connection)
        self.scene.addItem(connection.targetArrow)
        
        self.assertEqual(connection.connectionType, ConnectionType.BEZIER)
        
        connection.removeArrows()
        self.scene.removeItem(connection)
    
    def testStraightConnection(self) -> None:
        """测试直线连接"""
        connection = ConnectionItem(
            self.source_node, self.target_node,
            connection_type=ConnectionType.STRAIGHT
        )
        self.scene.addItem(connection)
        self.scene.addItem(connection.targetArrow)
        
        self.assertEqual(connection.connectionType, ConnectionType.STRAIGHT)
        
        connection.removeArrows()
        self.scene.removeItem(connection)


def RunAllTests() -> None:
    """运行所有测试"""
    # 创建测试套件
    loader = unittest.TestLoader()
    suite = unittest.TestSuite()
    
    # 添加所有测试类
    suite.addTests(loader.loadTestsFromTestCase(TestEnums))
    suite.addTests(loader.loadTestsFromTestCase(TestStyles))
    suite.addTests(loader.loadTestsFromTestCase(TestNodeItem))
    suite.addTests(loader.loadTestsFromTestCase(TestConnectionItem))
    suite.addTests(loader.loadTestsFromTestCase(TestArrowItem))
    suite.addTests(loader.loadTestsFromTestCase(TestSelectionRect))
    suite.addTests(loader.loadTestsFromTestCase(TestNodeCanvas))
    suite.addTests(loader.loadTestsFromTestCase(TestQNodeEditor))
    suite.addTests(loader.loadTestsFromTestCase(TestNodeShapes))
    suite.addTests(loader.loadTestsFromTestCase(TestConnectionTypes))
    
    # 运行测试
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    
    # 返回测试结果
    return result.wasSuccessful()


if __name__ == "__main__":
    success = RunAllTests()
    sys.exit(0 if success else 1)
