"""
样式配置模块

遵循代码规范:
- dataclass类不能定义函数，数据和方法必须分离
- 常量形式的变量，必须全大写，使用_连接
"""

from dataclasses import dataclass, field
from PyQt6.QtGui import QColor


# 默认颜色常量
DEFAULT_IDLE_FILL = "#F5F5F5"
DEFAULT_IDLE_STROKE = "#666666"
DEFAULT_HOVER_OVERLAY = "#FFFAF0"
DEFAULT_SELECTED_STROKE = "#FF8C00"
DEFAULT_SELECTED_OVERLAY = "#FFF8DC"
DEFAULT_TEXT_COLOR = "#333333"

DEFAULT_CONNECTION_NORMAL = "#666666"
DEFAULT_CONNECTION_SELECTED = "#FF8C00"
DEFAULT_CONNECTION_HOVER = "#999999"

DEFAULT_ARROW_NORMAL = "#666666"
DEFAULT_ARROW_SELECTED = "#FF8C00"
DEFAULT_ARROW_HOVER = "#FF1493"


@dataclass
class NodeStyle:
    """节点样式配置"""
    # Idle状态
    idle_fill: QColor = field(default_factory=lambda: QColor(DEFAULT_IDLE_FILL))
    idle_stroke: QColor = field(default_factory=lambda: QColor(DEFAULT_IDLE_STROKE))
    # Hover状态叠加
    hover_overlay: QColor = field(default_factory=lambda: QColor(DEFAULT_HOVER_OVERLAY))
    # 选中状态
    selected_stroke: QColor = field(default_factory=lambda: QColor(DEFAULT_SELECTED_STROKE))
    selected_overlay: QColor = field(default_factory=lambda: QColor(DEFAULT_SELECTED_OVERLAY))
    # 通用
    stroke_width: float = 2.0
    text_color: QColor = field(default_factory=lambda: QColor(DEFAULT_TEXT_COLOR))


@dataclass
class ConnectionStyle:
    """连接线样式配置"""
    normal_color: QColor = field(default_factory=lambda: QColor(DEFAULT_CONNECTION_NORMAL))
    selected_color: QColor = field(default_factory=lambda: QColor(DEFAULT_CONNECTION_SELECTED))
    hover_color: QColor = field(default_factory=lambda: QColor(DEFAULT_CONNECTION_HOVER))
    stroke_width: float = 2.0
    selected_stroke_width: float = 3.0


@dataclass
class ArrowStyle:
    """箭头样式配置"""
    normal_color: QColor = field(default_factory=lambda: QColor(DEFAULT_ARROW_NORMAL))
    selected_color: QColor = field(default_factory=lambda: QColor(DEFAULT_ARROW_SELECTED))
    hover_color: QColor = field(default_factory=lambda: QColor(DEFAULT_ARROW_HOVER))
    arrow_size: float = 12.0
    stroke_width: float = 2.0
