"""
qnode 演示示例 - 展示节点图编辑器的基本功能
"""
import sys
sys.path.insert(0, 'F:\\Python\\Python314\\Lib\\site-packages')

from PyQt6.QtWidgets import QApplication, QVBoxLayout, QHBoxLayout, QWidget, QPushButton, QLabel, QComboBox
from PyQt6.QtCore import QPointF, Qt
from qwork.qnode import NodeCanvasWindow, NodeCanvas, NodeShape, ConnectionType
from qwork.qnode.layout_utils import DenseLayoutEngine, ViewportFitter


class DemoWindow(QWidget):
    """演示窗口 - 包含控制面板和节点画布"""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("QNode 演示 - 节点图编辑器")
        self.resize(1200, 800)

        # 主布局
        layout = QHBoxLayout(self)

        # 左侧控制面板
        controlPanel = self.CreateControlPanel()
        layout.addWidget(controlPanel, 0)

        # 右侧节点画布窗口
        self.nodeWindow = NodeCanvasWindow()
        self.canvas = self.nodeWindow.canvas
        layout.addWidget(self.nodeWindow, 1)

        # 初始化一些示例节点
        self.InitDemoNodes()

    def CreateControlPanel(self):
        """创建控制面板"""
        panel = QWidget()
        panel.setFixedWidth(250)
        panel.setStyleSheet("background-color: #2d2d2d; color: white; padding: 10px;")

        layout = QVBoxLayout(panel)
        layout.setAlignment(Qt.AlignmentFlag.AlignTop)

        # 标题
        title = QLabel("QNode 演示控制面板")
        title.setStyleSheet("font-size: 16px; font-weight: bold; margin-bottom: 10px;")
        layout.addWidget(title)

        # 添加节点区域
        layout.addWidget(QLabel("--- 添加节点 ---"))

        self.shapeCombo = QComboBox()
        self.shapeCombo.addItems(["椭圆 (开始/结束)", "矩形 (处理)", "菱形 (决策)"])
        layout.addWidget(self.shapeCombo)

        addBtn = QPushButton("添加节点")
        addBtn.clicked.connect(self.AddNode)
        layout.addWidget(addBtn)

        layout.addSpacing(20)

        # 布局算法区域
        layout.addWidget(QLabel("--- 自动布局 ---"))

        self.layoutCombo = QComboBox()
        self.layoutCombo.addItems(["紧凑", "环形", "网格", "层次", "力导向"])
        layout.addWidget(self.layoutCombo)

        layoutBtn = QPushButton("应用布局")
        layoutBtn.clicked.connect(self.ApplyLayout)
        layout.addWidget(layoutBtn)

        layout.addSpacing(20)

        # 视图控制区域
        layout.addWidget(QLabel("--- 视图控制 ---"))

        fitBtn = QPushButton("适配视口")
        fitBtn.clicked.connect(self.FitViewport)
        layout.addWidget(fitBtn)

        centerBtn = QPushButton("居中节点")
        centerBtn.clicked.connect(self.CenterNodes)
        layout.addWidget(centerBtn)

        layout.addSpacing(20)

        # 导入/导出区域
        layout.addWidget(QLabel("--- 导入/导出 ---"))

        exportBtn = QPushButton("导出为 JSON")
        exportBtn.clicked.connect(self.ExportJson)
        layout.addWidget(exportBtn)

        importBtn = QPushButton("从 JSON 导入")
        importBtn.clicked.connect(self.ImportJson)
        layout.addWidget(importBtn)

        clearBtn = QPushButton("清空画布")
        clearBtn.clicked.connect(self.ClearCanvas)
        layout.addWidget(clearBtn)

        layout.addSpacing(20)

        # 帮助信息
        helpLabel = QLabel(
            "--- 操作说明 ---\n"
            "• 左键拖拽: 框选\n"
            "• Ctrl+点击: 多选\n"
            "• 从节点拖拽: 创建连接\n"
            "• 双击节点: 编辑\n"
            "• 右键连接: 切换线条类型\n"
            "• 中键拖拽: 平移\n"
            "• 滚轮: 缩放\n"
            "• Delete: 删除"
        )
        helpLabel.setStyleSheet("color: #aaa; font-size: 11px;")
        layout.addWidget(helpLabel)

        layout.addStretch()

        return panel

    def InitDemoNodes(self):
        """初始化演示节点"""
        # 创建流程图示例
        start = self.canvas.addNode("开始", QPointF(0, 0), NodeShape.ELLIPSE)

        inputNode = self.canvas.addNode("输入数据", QPointF(200, -100), NodeShape.RECTANGLE)
        process = self.canvas.addNode("处理数据", QPointF(400, 0), NodeShape.RECTANGLE)
        decision = self.canvas.addNode("验证?", QPointF(600, 0), NodeShape.DIAMOND)
        success = self.canvas.addNode("成功", QPointF(800, -100), NodeShape.RECTANGLE)
        error = self.canvas.addNode("错误处理", QPointF(800, 100), NodeShape.RECTANGLE)
        end = self.canvas.addNode("结束", QPointF(1000, 0), NodeShape.ELLIPSE)

        # 创建连接
        self.canvas.addConnection(start, inputNode)
        self.canvas.addConnection(inputNode, process)
        self.canvas.addConnection(process, decision)
        self.canvas.addConnection(decision, success)
        self.canvas.addConnection(decision, error)
        self.canvas.addConnection(success, end)
        self.canvas.addConnection(error, end)

        # 设置起始节点
        self.canvas.startNode = start

        # 适配视口 - 使用较小的边距确保节点清晰可见
        from PyQt6.QtCore import QTimer
        QTimer.singleShot(100, self._fitViewportOnStartup)

    def _fitViewportOnStartup(self):
        """启动时适配视口"""
        fitter = ViewportFitter(self.canvas)
        # 使用较小的边距(20)确保图形清晰可见
        fitter.fitViewport(margin=20.0)
        # 限制最小缩放比例，避免图形过小
        current_scale = self.canvas.transform().m11()
        if current_scale < 0.8:
            self.canvas.resetTransform()
            self.canvas.scale(0.8, 0.8)

    def AddNode(self):
        """添加新节点"""
        shapeIdx = self.shapeCombo.currentIndex()
        shape = [NodeShape.ELLIPSE, NodeShape.RECTANGLE, NodeShape.DIAMOND][shapeIdx]
        name = ["开始/结束", "处理节点", "决策节点"][shapeIdx]

        # 在随机位置添加节点
        import random
        x = random.randint(-200, 200)
        y = random.randint(-200, 200)
        node = self.canvas.addNode(name, QPointF(x, y), shape)

    def ApplyLayout(self):
        """应用布局算法"""
        layoutNames = ["compact", "circular", "grid", "hierarchical", "force"]
        layoutName = layoutNames[self.layoutCombo.currentIndex()]

        engine = DenseLayoutEngine(self.canvas)
        engine.autoLayout(layoutName)

    def FitViewport(self):
        """适配视口"""
        fitter = ViewportFitter(self.canvas)
        fitter.fitViewport()

    def CenterNodes(self):
        """居中节点"""
        fitter = ViewportFitter(self.canvas)
        fitter.centerOnNodes()

    def ExportJson(self):
        """导出为 JSON"""
        from PyQt6.QtWidgets import QFileDialog

        json_str = self.canvas.exportToJson()
        filePath, _ = QFileDialog.getSaveFileName(
            self, "导出图", "graph.json", "JSON 文件 (*.json)"
        )
        if filePath:
            with open(filePath, 'w', encoding='utf-8') as f:
                f.write(json_str)
            print(f"已导出到: {filePath}")

    def ImportJson(self):
        """从 JSON 导入"""
        import json
        from PyQt6.QtWidgets import QFileDialog

        filePath, _ = QFileDialog.getOpenFileName(
            self, "导入图", "", "JSON 文件 (*.json)"
        )
        if filePath:
            with open(filePath, 'r', encoding='utf-8') as f:
                data = json.load(f)
            self.canvas.importData(data)
            print(f"已从 {filePath} 导入")

    def ClearCanvas(self):
        """清空画布"""
        self.canvas.clear()


def main():
    """主函数"""
    app = QApplication(sys.argv)

    # 设置应用样式
    app.setStyle('Fusion')

    # 创建并显示演示窗口
    window = DemoWindow()
    window.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
