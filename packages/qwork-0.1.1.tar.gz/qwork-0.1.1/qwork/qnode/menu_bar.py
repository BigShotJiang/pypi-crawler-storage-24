"""
菜单栏模块 - 提供文件、编辑、视图等菜单
"""

from typing import Optional, Callable

from PyQt6.QtWidgets import QMenuBar, QMenu, QFileDialog, QMessageBox
from PyQt6.QtCore import pyqtSignal, QObject
from PyQt6.QtGui import QKeySequence, QAction


class MenuBar(QMenuBar):
    """
    菜单栏 - 提供文件、编辑、视图等菜单
    """
    
    # 信号
    newGraphRequested = pyqtSignal()
    openGraphRequested = pyqtSignal(str)
    saveGraphRequested = pyqtSignal()
    saveAsGraphRequested = pyqtSignal(str)
    exportGraphRequested = pyqtSignal()
    importGraphRequested = pyqtSignal(str)
    exitRequested = pyqtSignal()
    
    def __init__(self, parent: Optional['QWidget'] = None) -> None:
        super().__init__(parent)
        
        self._createFileMenu()
        self._createEditMenu()
        self._createViewMenu()
        self._createLayoutMenu()
    
    def _createFileMenu(self) -> None:
        """创建文件菜单"""
        file_menu = self.addMenu("File")
        
        # New
        new_action = QAction("New", self)
        new_action.setShortcut(QKeySequence.StandardKey.New)
        new_action.triggered.connect(self.newGraphRequested.emit)
        file_menu.addAction(new_action)
        
        # Open
        open_action = QAction("Open...", self)
        open_action.setShortcut(QKeySequence.StandardKey.Open)
        open_action.triggered.connect(self._onOpen)
        file_menu.addAction(open_action)
        
        file_menu.addSeparator()
        
        # Save
        save_action = QAction("Save", self)
        save_action.setShortcut(QKeySequence.StandardKey.Save)
        save_action.triggered.connect(self.saveGraphRequested.emit)
        file_menu.addAction(save_action)
        
        # Save As
        save_as_action = QAction("Save As...", self)
        save_as_action.setShortcut(QKeySequence.StandardKey.SaveAs)
        save_as_action.triggered.connect(self._onSaveAs)
        file_menu.addAction(save_as_action)
        
        file_menu.addSeparator()
        
        # Export
        export_action = QAction("Export...", self)
        export_action.triggered.connect(self._onExport)
        file_menu.addAction(export_action)
        
        # Import
        import_action = QAction("Import...", self)
        import_action.triggered.connect(self._onImport)
        file_menu.addAction(import_action)
        
        file_menu.addSeparator()
        
        # Exit
        exit_action = QAction("Exit", self)
        exit_action.setShortcut(QKeySequence.StandardKey.Quit)
        exit_action.triggered.connect(self.exitRequested.emit)
        file_menu.addAction(exit_action)
    
    def _createEditMenu(self) -> None:
        """创建编辑菜单"""
        edit_menu = self.addMenu("Edit")
        
        # Delete
        delete_action = QAction("Delete", self)
        delete_action.setShortcut(QKeySequence.StandardKey.Delete)
        delete_action.triggered.connect(self._onDelete)
        edit_menu.addAction(delete_action)
        
        # Select All
        select_all_action = QAction("Select All", self)
        select_all_action.setShortcut(QKeySequence.StandardKey.SelectAll)
        select_all_action.triggered.connect(self._onSelectAll)
        edit_menu.addAction(select_all_action)
    
    def _createViewMenu(self) -> None:
        """创建视图菜单"""
        view_menu = self.addMenu("View")
        
        # Zoom In
        zoom_in_action = QAction("Zoom In", self)
        zoom_in_action.setShortcut(QKeySequence.StandardKey.ZoomIn)
        zoom_in_action.triggered.connect(self._onZoomIn)
        view_menu.addAction(zoom_in_action)
        
        # Zoom Out
        zoom_out_action = QAction("Zoom Out", self)
        zoom_out_action.setShortcut(QKeySequence.StandardKey.ZoomOut)
        zoom_out_action.triggered.connect(self._onZoomOut)
        view_menu.addAction(zoom_out_action)
        
        # Fit to Viewport
        fit_viewport_action = QAction("Fit to Viewport", self)
        fit_viewport_action.triggered.connect(self._onFitViewport)
        view_menu.addAction(fit_viewport_action)
        
        # Reset Zoom
        reset_zoom_action = QAction("Reset Zoom", self)
        reset_zoom_action.triggered.connect(self._onResetZoom)
        view_menu.addAction(reset_zoom_action)
    
    def _createLayoutMenu(self) -> None:
        """创建布局菜单"""
        layout_menu = self.addMenu("Layout")
        
        # Compact
        compact_action = QAction("Compact", self)
        compact_action.triggered.connect(lambda: self._onLayout("compact"))
        layout_menu.addAction(compact_action)
        
        # Circular
        circular_action = QAction("Circular", self)
        circular_action.triggered.connect(lambda: self._onLayout("circular"))
        layout_menu.addAction(circular_action)
        
        # Grid
        grid_action = QAction("Grid", self)
        grid_action.triggered.connect(lambda: self._onLayout("grid"))
        layout_menu.addAction(grid_action)
        
        # Hierarchical
        hierarchical_action = QAction("Hierarchical", self)
        hierarchical_action.triggered.connect(lambda: self._onLayout("hierarchical"))
        layout_menu.addAction(hierarchical_action)
        
        # Force Directed
        force_action = QAction("Force Directed", self)
        force_action.triggered.connect(lambda: self._onLayout("force"))
        layout_menu.addAction(force_action)
    
    def _onOpen(self) -> None:
        """打开文件"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Open Graph", "", "JSON Files (*.json);;All Files (*)"
        )
        if file_path:
            self.openGraphRequested.emit(file_path)
    
    def _onSaveAs(self) -> None:
        """另存为"""
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Save Graph As", "", "JSON Files (*.json);;All Files (*)"
        )
        if file_path:
            self.saveAsGraphRequested.emit(file_path)
    
    def _onExport(self) -> None:
        """导出"""
        file_path, _ = QFileDialog.getSaveFileName(
            self, "Export Graph", "", "JSON Files (*.json);;All Files (*)"
        )
        if file_path:
            self.exportGraphRequested.emit()
    
    def _onImport(self) -> None:
        """导入"""
        file_path, _ = QFileDialog.getOpenFileName(
            self, "Import Graph", "", "JSON Files (*.json);;All Files (*)"
        )
        if file_path:
            self.importGraphRequested.emit(file_path)
    
    def _onDelete(self) -> None:
        """删除选中"""
        # 通过父窗口获取画布并删除选中项
        parent = self.parent()
        if parent and hasattr(parent, 'canvas'):
            canvas = parent.canvas
            # 删除选中的节点
            for node in canvas.nodes[:]:
                if node.isSelected():
                    canvas.removeNode(node)
    
    def _onSelectAll(self) -> None:
        """全选"""
        parent = self.parent()
        if parent and hasattr(parent, 'canvas'):
            canvas = parent.canvas
            for node in canvas.nodes:
                node.setSelected(True)
    
    def _onZoomIn(self) -> None:
        """放大"""
        parent = self.parent()
        if parent and hasattr(parent, 'canvas'):
            parent.canvas.scale(1.1, 1.1)
    
    def _onZoomOut(self) -> None:
        """缩小"""
        parent = self.parent()
        if parent and hasattr(parent, 'canvas'):
            parent.canvas.scale(0.9, 0.9)
    
    def _onFitViewport(self) -> None:
        """适应视口"""
        parent = self.parent()
        if parent and hasattr(parent, 'canvas'):
            from qwork.qnode.layout_utils import ViewportFitter
            fitter = ViewportFitter(parent.canvas)
            fitter.fitViewport()
    
    def _onResetZoom(self) -> None:
        """重置缩放"""
        parent = self.parent()
        if parent and hasattr(parent, 'canvas'):
            parent.canvas.resetTransform()
    
    def _onLayout(self, strategy: str) -> None:
        """执行布局"""
        parent = self.parent()
        if parent and hasattr(parent, 'canvas'):
            from qwork.qnode.layout_utils import DenseLayoutEngine
            engine = DenseLayoutEngine(parent.canvas)
            engine.autoLayout(strategy)
