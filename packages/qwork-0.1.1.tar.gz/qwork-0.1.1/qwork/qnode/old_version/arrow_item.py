"""
箭头项模块 - 表示连接线上的独立箭头
"""

import math
from typing import Optional, TYPE_CHECKING, Callable

from PyQt6.QtWidgets import QGraphicsItem, QGraphicsPathItem, QGraphicsSceneMouseEvent
from PyQt6.QtCore import Qt, QPointF, QRectF
from PyQt6.QtGui import QPainterPath, QPen, QColor, QBrush, QPainterPathStroker, QTransform

from qwork.qnode.old_version.styles import ArrowStyle
from qwork.qnode.old_version.enums import ArrowState

if TYPE_CHECKING:
    from qwork.qnode.old_version.connection_item import ConnectionItem


class ArrowItem(QGraphicsPathItem):
    """
    箭头项 - 表示连接线上的独立箭头，可单独选中和拖拽
    """
    
    def __init__(
        self,
        connection: 'ConnectionItem',
        is_source_arrow: bool = False,
        parent: Optional[QGraphicsItem] = None
    ) -> None:
        """
        初始化箭头项
        
        Args:
            connection: 所属的连接线
            is_source_arrow: 是否是源端箭头（反向箭头）
            parent: 父项
        """
        super().__init__(parent)
        
        self._connection: 'ConnectionItem' = connection
        self._is_source_arrow: bool = is_source_arrow
        self._style: ArrowStyle = ArrowStyle()
        self._state: ArrowState = ArrowState.IDLE
        self._arrow_tip: QPointF = QPointF(0, 0)
        self._arrow_direction: QPointF = QPointF(1, 0)  # 箭头指向的方向
        
        # 回调函数（由NodeCanvas设置）
        self._drag_started_callback: Optional[Callable[[QPointF], None]] = None
        self._drag_moved_callback: Optional[Callable[[QPointF], None]] = None
        self._drag_finished_callback: Optional[Callable[[QPointF, bool], None]] = None
        
        # 设置可选项标志
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsSelectable, True)
        self.setAcceptHoverEvents(True)
        self.setZValue(10)  # 确保箭头在连线上方
        
        # 初始化样式
        self._setup_style()
        
        # 拖拽状态
        self._is_dragging: bool = False
        self._drag_start_pos: Optional[QPointF] = None
    
    def _setup_style(self) -> None:
        """设置箭头样式"""
        self._normal_pen = QPen(self._style.normal_color, self._style.stroke_width)
        self._normal_pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        self._normal_pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)

        self._selected_pen = QPen(self._style.selected_color, self._style.stroke_width + 1)
        self._selected_pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        self._selected_pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)

        self._hover_pen = QPen(self._style.hover_color, self._style.stroke_width + 1)
        self._hover_pen.setCapStyle(Qt.PenCapStyle.RoundCap)
        self._hover_pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)

        self.setPen(self._normal_pen)
        self.setBrush(QBrush(self._style.normal_color))

    def set_arrow_size(self, size: float) -> None:
        """设置箭头大小"""
        self._style.arrow_size = size
    
    def set_drag_callbacks(
        self,
        started: Optional[Callable[[QPointF], None]] = None,
        moved: Optional[Callable[[QPointF], None]] = None,
        finished: Optional[Callable[[QPointF, bool], None]] = None
    ) -> None:
        """设置拖拽回调函数"""
        self._drag_started_callback = started
        self._drag_moved_callback = moved
        self._drag_finished_callback = finished
    
    @property
    def connection(self) -> 'ConnectionItem':
        """获取所属的连接线"""
        return self._connection
    
    @property
    def is_source_arrow(self) -> bool:
        """是否是源端箭头"""
        return self._is_source_arrow
    
    @property
    def arrow_tip(self) -> QPointF:
        """获取箭头尖端位置"""
        return self._arrow_tip
    
    @property
    def arrow_direction(self) -> QPointF:
        """获取箭头指向的方向"""
        return self._arrow_direction
    
    def update_arrow(
        self,
        tip_pos: QPointF,
        direction: QPointF,
        from_pos: QPointF
    ) -> None:
        """
        更新箭头形状和位置
        
        Args:
            tip_pos: 箭头尖端位置
            direction: 箭头指向的方向（单位向量）
            from_pos: 箭头的起始位置（用于计算角度）
        """
        self._arrow_tip = tip_pos
        self._arrow_direction = direction
        
        # 计算箭头两个底点
        arrow_angle = math.pi / 6  # 30度
        arrow_size = self._style.arrow_size
        
        # 根据方向向量计算垂直向量
        dx = direction.x()
        dy = direction.y()
        
        # 计算两个底点
        base1 = QPointF(
            tip_pos.x() - arrow_size * (dx * math.cos(arrow_angle) - dy * math.sin(arrow_angle)),
            tip_pos.y() - arrow_size * (dx * math.sin(arrow_angle) + dy * math.cos(arrow_angle))
        )
        base2 = QPointF(
            tip_pos.x() - arrow_size * (dx * math.cos(-arrow_angle) - dy * math.sin(-arrow_angle)),
            tip_pos.y() - arrow_size * (dx * math.sin(-arrow_angle) + dy * math.cos(-arrow_angle))
        )
        
        # 创建箭头路径（三角形）
        path = QPainterPath()
        path.moveTo(tip_pos)
        path.lineTo(base1)
        path.lineTo(base2)
        path.closeSubpath()
        
        self.setPath(path)
        self._apply_style()
    
    def _apply_style(self) -> None:
        """应用当前状态的样式"""
        if self._state == ArrowState.HOVER:
            self.setPen(self._hover_pen)
            self.setBrush(QBrush(self._style.hover_color))
        elif self.isSelected():
            self.setPen(self._selected_pen)
            self.setBrush(QBrush(self._style.selected_color))
        else:
            self.setPen(self._normal_pen)
            self.setBrush(QBrush(self._style.normal_color))
    
    def boundingRect(self) -> QRectF:
        """获取边界矩形，添加一些边距以便更容易选中"""
        rect = super().boundingRect()
        margin = 8.0
        return rect.adjusted(-margin, -margin, margin, margin)
    
    def shape(self) -> QPainterPath:
        """获取形状，用于命中测试"""
        path = super().shape()
        # 扩大形状以便更容易选中
        stroke = QPainterPathStroker()
        stroke.setWidth(10)
        return stroke.createStroke(path)
    
    def hoverEnterEvent(self, event) -> None:
        """鼠标进入事件"""
        self._state = ArrowState.HOVER
        self._apply_style()
        super().hoverEnterEvent(event)
    
    def hoverLeaveEvent(self, event) -> None:
        """鼠标离开事件"""
        self._state = ArrowState.IDLE
        self._apply_style()
        super().hoverLeaveEvent(event)
    
    def mousePressEvent(self, event: QGraphicsSceneMouseEvent) -> None:
        """鼠标按下事件 - 开始拖拽"""
        if event.button() == Qt.MouseButton.LeftButton:
            self._is_dragging = True
            self._drag_start_pos = event.scenePos()
            self.setSelected(True)
            if self._drag_started_callback:
                self._drag_started_callback(event.scenePos())
            event.accept()
        else:
            super().mousePressEvent(event)
    
    def mouseMoveEvent(self, event: QGraphicsSceneMouseEvent) -> None:
        """鼠标移动事件 - 拖拽中"""
        if self._is_dragging:
            if self._drag_moved_callback:
                self._drag_moved_callback(event.scenePos())
            event.accept()
        else:
            super().mouseMoveEvent(event)
    
    def mouseReleaseEvent(self, event: QGraphicsSceneMouseEvent) -> None:
        """鼠标释放事件 - 结束拖拽"""
        if self._is_dragging and event.button() == Qt.MouseButton.LeftButton:
            self._is_dragging = False
            # 检查是否连接到了节点
            scene = self.scene()
            is_success = False
            if scene:
                from .node_item import NodeItem
                from .node_item import NodeItem
                from .connection_item import ConnectionItem
                # 获取该位置的所有项，查找节点（连接线和箭头可能覆盖在节点上）
                items = scene.items(event.scenePos())
                target_node = None
                for item in items:
                    if isinstance(item, NodeItem):
                        target_node = item
                        break
                    # 如果是连接线，跳过继续查找
                    if isinstance(item, ConnectionItem):
                        continue

                is_success = target_node is not None
            
            if self._drag_finished_callback:
                self._drag_finished_callback(event.scenePos(), is_success)
            
            event.accept()
        else:
            super().mouseReleaseEvent(event)
    
    def itemChange(self, change: QGraphicsItem.GraphicsItemChange, value):
        """项状态改变事件"""
        if change == QGraphicsItem.GraphicsItemChange.ItemSelectedChange:
            self._apply_style()
        return super().itemChange(change, value)
