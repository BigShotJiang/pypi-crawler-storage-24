"""
主窗口模块
"""

from PyQt6.QtWidgets import QMainWindow, QWidget, QVBoxLayout, QSplitter, QHBoxLayout, QMessageBox
from PyQt6.QtCore import QPointF, QPoint, Qt

from qwork.qnode.old_version.node_canvas import NodeCanvas
from qwork.qnode.old_version.menu_bar import MenuBar

# AI GUI 导入（可选）
try:
    from ai.ai_gui import QChatWidget as AIGuiWindow
    from ai.canvas_api import CanvasAPI
    from ai.canvas_tools import create_canvas_tools, get_tool_definitions, create_tool_executor
    AI_AVAILABLE = True
except ImportError:
    AI_AVAILABLE = False


class NodeCanvasWindow(QMainWindow):
    """节点画布主窗口"""

    def __init__(self) -> None:
        super().__init__()
        self.setGeometry(100, 100, 1600, 900)

        # 创建中央部件
        self._central_widget = QWidget()
        self.setCentralWidget(self._central_widget)

        # 创建主布局
        self._layout = QHBoxLayout(self._central_widget)
        self._layout.setContentsMargins(0, 0, 0, 0)
        self._layout.setSpacing(0)

        # 创建分割器：左侧画布，右侧 AI GUI
        self._splitter = QSplitter(Qt.Orientation.Horizontal)
        self._layout.addWidget(self._splitter)

        # 创建画布容器（用于菜单栏定位）
        self._canvas_container = QWidget()
        self._canvas_layout = QVBoxLayout(self._canvas_container)
        self._canvas_layout.setContentsMargins(0, 0, 0, 0)
        self._canvas_layout.setSpacing(0)

        # 创建画布
        self._canvas = NodeCanvas()
        self._canvas_layout.addWidget(self._canvas)

        # 添加到分割器左侧
        self._splitter.addWidget(self._canvas_container)

        # 创建 AI GUI（如果可用）
        self._ai_gui = None
        if AI_AVAILABLE:
            self._setup_ai_gui()

        # 设置分割比例（画布:AI = 2:1）
        # 延迟设置分割比例，确保窗口已布局完成
        from PyQt6.QtCore import QTimer
        QTimer.singleShot(100, lambda: self._splitter.setSizes([800, 400]))

        # 创建菜单栏（作为主窗口的子部件，但放在中央部件上方）
        self._menu_bar = MenuBar(self._canvas, self)
        self._menu_bar.set_geometry(0, -30, 400, 30)  # 初始隐藏在上方

        # 启用鼠标跟踪以检测菜单栏触发区域
        self.setMouseTracking(True)
        self._central_widget.setMouseTracking(True)
        self._canvas.setMouseTracking(True)

        # 为子部件安装事件过滤器，确保菜单栏能接收鼠标事件
        self._central_widget.installEventFilter(self)
        self._canvas_container.installEventFilter(self)
        self._canvas.viewport().installEventFilter(self)
        self._splitter.installEventFilter(self)

        # 设置初始窗口标题（不创建默认节点，保持画布干净）
        self._canvas._update_window_title()

    def _setup_ai_gui(self):
        """设置 AI GUI"""
        try:
            # 创建画布 API
            canvas_api = CanvasAPI(self._canvas)

            # 创建工具执行器和工具定义（包含 PSA 工具）
            tool_executor = create_tool_executor(canvas_api, include_psa=True)
            tool_definitions = get_tool_definitions(include_psa=True)

            # 创建 AI GUI（不设置 parent，让 splitter 管理）
            self._ai_gui = AIGuiWindow(
                canvas=self._canvas,
                tool_definitions=tool_definitions,
                tool_executor=tool_executor
            )
            self._ai_gui.setMinimumWidth(350)

            # 添加到分割器右侧
            self._splitter.addWidget(self._ai_gui)
            self._ai_gui.setVisible(True)

        except Exception as e:
            self._ai_gui = None

    def mouseMoveEvent(self, event):
        """鼠标移动事件 - 传递给菜单栏检测"""
        # 获取鼠标在中央部件中的位置
        pos = self._central_widget.mapFromGlobal(event.globalPosition().toPoint())
        self._menu_bar.handle_mouse_move(pos)
        super().mouseMoveEvent(event)

    def eventFilter(self, obj, event):
        """事件过滤器 - 转发子部件的鼠标事件到菜单栏"""
        if event.type() == event.Type.MouseMove:
            # 将鼠标位置映射到中央部件坐标系
            pos = self._central_widget.mapFromGlobal(event.globalPosition().toPoint())
            self._menu_bar.handle_mouse_move(pos)
        return super().eventFilter(obj, event)

    def toggle_ai_gui(self, visible: bool = True):
        """切换 AI GUI 的显示/隐藏

        Args:
            visible: True 显示，False 隐藏
        """
        if not self._ai_gui:
            return

        # 获取 AI GUI 在 splitter 中的索引
        ai_index = self._splitter.indexOf(self._ai_gui)
        if ai_index < 0:
            return

        if visible:
            # 显示 AI GUI
            self._ai_gui.setVisible(True)
            self._ai_gui.show()
            self._ai_gui.raise_()

            # 获取当前 splitter 总宽度
            total_width = self._splitter.width()
            left_width = int(total_width * 0.7)  # 左侧 70%
            right_width = total_width - left_width  # 右侧 30%

            if right_width < 350:
                right_width = 350
                left_width = total_width - right_width

            self._splitter.setSizes([left_width, right_width])
        else:
            # 隐藏 AI GUI - 将大小设为 0
            sizes = self._splitter.sizes()
            if len(sizes) >= 2:
                self._splitter.setSizes([sizes[0] + sizes[1], 0])

    def replace_canvas(self, new_canvas: NodeCanvas, reset_ai: bool = False):
        """替换当前画布（用于导入）"""
        # 停止 AI 生成，如果是 new graph 则重置对话
        self._stop_ai(reset=reset_ai)

        # 关闭所有编辑窗口
        self._canvas.close_all_edit_windows()

        # 移除旧画布
        self._canvas_layout.removeWidget(self._canvas)
        self._canvas.deleteLater()

        # 设置新画布
        self._canvas = new_canvas
        self._canvas_layout.addWidget(self._canvas)

        # 启用鼠标跟踪
        self._canvas.setMouseTracking(True)

        # 强制刷新视图
        self._canvas.viewport().update()
        self._canvas.update()

        # 更新菜单栏的画布引用
        self._menu_bar._canvas = new_canvas

        # 更新窗口标题
        self._canvas._update_window_title()

        # 更新 AI GUI 的画布引用（如果有）
        if self._ai_gui:
            try:
                from ai.canvas_api import CanvasAPI, BackupManager

                # 获取实际的 ChatWidget（包含 messages 等属性）
                chat_widget = getattr(self._ai_gui, 'chat_widget', self._ai_gui)

                # 1. 更新 QChatWidget 和 ChatWidget 的画布引用
                self._ai_gui._canvas = self._canvas
                if chat_widget is not self._ai_gui:
                    chat_widget._canvas = self._canvas

                # 2. 重新创建工具执行器（使用新的 canvas）
                canvas_api = CanvasAPI(self._canvas)
                tool_executor = create_tool_executor(canvas_api, include_psa=True)
                tool_definitions = get_tool_definitions(include_psa=True)
                self._ai_gui._tool_executor = tool_executor
                self._ai_gui._tool_definitions = tool_definitions
                if chat_widget is not self._ai_gui:
                    chat_widget._tool_executor = tool_executor
                    chat_widget._tool_definitions = tool_definitions

                # 3. 重新初始化 BackupManager（清除旧引用和备份）
                if self._canvas:
                    new_backup_manager = BackupManager()
                    self._ai_gui._backup_manager = new_backup_manager
                    if chat_widget is not self._ai_gui:
                        chat_widget._backup_manager = new_backup_manager
                else:
                    self._ai_gui._backup_manager = None
                    if chat_widget is not self._ai_gui:
                        chat_widget._backup_manager = None

                # 4. 获取当前的 health check 状态（先读取所有状态，再重置）
                if chat_widget is not self._ai_gui:
                    hc_was_passed = getattr(chat_widget, '_health_check_passed', False)
                    hc_was_in_progress = getattr(chat_widget, '_health_check_in_progress', False)
                    print(f"[MainWindow] Before reset: passed={hc_was_passed}, in_progress={hc_was_in_progress}")
                    # 重置 flag（为下次 new/load 做准备）
                    chat_widget._health_check_passed = False
                    chat_widget._health_check_in_progress = False
                    # 同时重置 _ai_gui 的 flag（保持一致性）
                    self._ai_gui._health_check_passed = False
                    self._ai_gui._health_check_in_progress = False
                else:
                    hc_was_passed = getattr(self._ai_gui, '_health_check_passed', False)
                    hc_was_in_progress = getattr(self._ai_gui, '_health_check_in_progress', False)
                    print(f"[MainWindow] Before reset: passed={hc_was_passed}, in_progress={hc_was_in_progress}")
                    self._ai_gui._health_check_passed = False
                    self._ai_gui._health_check_in_progress = False

                # 5. 处理对话重置
                if reset_ai and chat_widget is not self._ai_gui:
                    if hasattr(chat_widget, 'messages'):
                        system_msgs = [m for m in chat_widget.messages if m.role == "system"]
                        chat_widget.messages = system_msgs[:1] if system_msgs else []
                    if hasattr(chat_widget, 'message_widgets'):
                        for widget in chat_widget.message_widgets[:]:
                            widget.deleteLater()
                        chat_widget.message_widgets.clear()
                    if hasattr(chat_widget, '_conversation_counter'):
                        chat_widget._conversation_counter = 0
                    if hasattr(chat_widget, '_user_message_indices'):
                        chat_widget._user_message_indices = []

                # 6. 只在 health check 之前未通过且未在运行时重启
                check_health_target = chat_widget if hasattr(chat_widget, '_check_health') else self._ai_gui
                print(f"[MainWindow] Decision: passed={hc_was_passed}, was_in_progress={hc_was_in_progress}")
                if hasattr(check_health_target, '_check_health') and not hc_was_passed and not hc_was_in_progress:
                    print(f"[MainWindow] Triggering _check_health")
                    check_health_target._check_health()
                else:
                    print(f"[MainWindow] Skipping health check")

            except Exception as e:
                print(f"[MainWindow] Failed to update AI GUI: {e}")

    def _add_sample_nodes(self) -> None:
        """添加默认节点：两个节点和一个连接"""
        # ROOT 已由画布自动创建，这里只添加示例节点

        # 创建"开始"节点并标记为起点（放在 ROOT 左上方，避免重叠）
        start_node = self._canvas.add_node("开始", QPointF(-200, -150))
        self._canvas.start_node = start_node

        # 创建"结束"节点（放在 ROOT 左下方，避免重叠）
        end_node = self._canvas.add_node("结束", QPointF(-200, 150))

        # 创建连接
        self._canvas.add_connection(start_node, end_node)

    def _stop_ai(self, reset: bool = False):
        """
        停止 AI 生成，可选择重置对话

        Args:
            reset: 是否重置对话历史
        """
        if self._ai_gui and hasattr(self._ai_gui, 'stop_and_reset'):
            try:
                self._ai_gui.stop_and_reset(reset=reset)
            except Exception:
                pass

    def closeEvent(self, event):
        """关闭主窗口时先关闭所有子窗口并保存数据"""
        # 停止 AI 生成（不重置，因为程序要关闭了）
        self._stop_ai(reset=False)

        # 先保存所有打开的 edit 窗口（这可能会改变 changed 状态）
        self._canvas.save_all_edit_windows()

        # 检查是否有未保存的修改
        if self._canvas.changed:
            # 临时取消所有 edit 窗口的置顶，确保对话框不被遮挡
            self._canvas.set_edit_windows_stay_on_top(False)

            reply = QMessageBox.question(
                self,
                "Unsaved Changes",
                "The graph has unsaved changes. Do you want to save before exiting?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No | QMessageBox.StandardButton.Cancel,
                QMessageBox.StandardButton.Yes
            )

            if reply == QMessageBox.StandardButton.Yes:
                # 用户选择保存，调用保存逻辑
                saved = self._menu_bar._perform_save()
                if not saved:
                    # 保存失败或用户取消保存，恢复置顶并阻止关闭
                    self._canvas.set_edit_windows_stay_on_top(True)
                    event.ignore()
                    return
            elif reply == QMessageBox.StandardButton.Cancel:
                # 用户选择取消，恢复置顶并阻止关闭
                self._canvas.set_edit_windows_stay_on_top(True)
                event.ignore()
                return
            # 用户选择 No，继续关闭

        # 关闭所有编辑窗口
        self._canvas.close_all_edit_windows()

        # 自动保存画布数据到文件
        self._auto_save_canvas()

        event.accept()

    def _auto_save_canvas(self):
        """自动保存画布数据到文件"""
        import os
        from PyQt6.QtCore import QStandardPaths

        # 获取自动保存目录（应用程序数据目录）
        app_data_dir = QStandardPaths.writableLocation(QStandardPaths.StandardLocation.AppDataLocation)
        if not app_data_dir:
            app_data_dir = os.path.expanduser("~/.node_canvas")

        # 确保目录存在
        os.makedirs(app_data_dir, exist_ok=True)

        # 自动保存文件路径
        auto_save_path = os.path.join(app_data_dir, "autosave.json")

        try:
            # 导出画布数据
            json_content = self._canvas.export()

            # 保存到文件
            with open(auto_save_path, 'w', encoding='utf-8') as f:
                f.write(json_content)

        except Exception as e:
            pass


def main() -> None:
    """主函数"""
    import sys
    from PyQt6.QtWidgets import QApplication
    
    app = QApplication(sys.argv)
    
    # 设置应用程序样式
    app.setStyle('Fusion')
    
    # 创建并显示主窗口
    window = NodeCanvasWindow()
    window.show()
    
    sys.exit(app.exec())


if __name__ == "__main__":
    main()

