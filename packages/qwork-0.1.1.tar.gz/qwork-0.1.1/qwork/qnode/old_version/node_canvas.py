"""
节点画布模块 - 主视图组件
处理所有的用户交互：拖拽、选择、连接、右键菜单等
"""

import math
import json
import warnings
from datetime import datetime
from typing import Optional, List, Dict, Any, Union
from collections import deque
from dataclasses import dataclass, field

from PyQt6.QtWidgets import (
    QGraphicsView, QGraphicsScene, QGraphicsItem,
    QGraphicsPathItem, QMenu, QMessageBox, QApplication
)
from PyQt6.QtCore import Qt, QPointF, QRectF, pyqtSignal
from PyQt6.QtGui import (
    QPainter, QBrush, QPen, QColor, QPainterPath, QTransform,
    QContextMenuEvent, QMouseEvent, QKeyEvent, QWheelEvent
)

from qwork.qnode.old_version.node_item import NodeItem
from qwork.qnode.old_version.connection_item import ConnectionItem
from qwork.qnode.old_version.arrow_item import ArrowItem
from qwork.qnode.old_version.selection_rect import SelectionRect
from qwork.qnode.old_version.node_edit_window import NodeEditWindow, close_all_edit_windows
from qwork.qnode.old_version.root_item import RootItem
from qwork.qnode.old_version.class_edit_window import ClassEditWindow


@dataclass
class AtomOperation:
    """原子操作 - 记录单个可追踪的修改"""
    NULL: str = field(default="</$NULL>", repr=False)

    old: Any = None  # 原始值，如果是 NULL 表示新增操作
    new: Any = None  # 新值，如果是 NULL 表示删除操作
    jpath: List[str] = field(default_factory=list)  # JSON 路径
    act: bool = True  # 操作状态：True=已应用，False=已撤销

    def __post_init__(self):
        """初始化后将 NULL 字符串转为常量引用"""
        if self.old == "</$NULL>":
            self.old = AtomOperation.NULL
        if self.new == "</$NULL>":
            self.new = AtomOperation.NULL

    def is_create(self) -> bool:
        """是否是新增操作"""
        return self.old == AtomOperation.NULL

    def is_delete(self) -> bool:
        """是否是删除操作"""
        return self.new == AtomOperation.NULL

    def is_update(self) -> bool:
        """是否是更新操作"""
        return self.old != AtomOperation.NULL and self.new != AtomOperation.NULL

    def __str__(self) -> str:
        """返回操作的字符串描述"""
        path = "/".join(self.jpath) if self.jpath else "root"
        if self.is_create():
            return f"Create at [{path}]: {self.new}"
        elif self.is_delete():
            return f"Delete at [{path}]: {self.old}"
        else:
            return f"Update at [{path}]: {self.old} -> {self.new}"

    def _get_value_at_path(self, data: dict, path: List[str]) -> Any:
        """根据路径获取值，支持 nodes/connections 列表按 id 查找"""
        current = data
        for i, key in enumerate(path):
            if isinstance(current, dict) and key in current:
                current = current[key]
            elif isinstance(current, list):
                # 对于列表（如 nodes, connections），通过 id 或索引查找
                found = False
                # 先尝试按 id 查找
                for item in current:
                    if isinstance(item, dict) and str(item.get('id', '')) == key:
                        current = item
                        found = True
                        break
                # 再尝试按索引查找
                if not found and key.isdigit():
                    idx = int(key)
                    if idx < len(current):
                        current = current[idx]
                        found = True
                if not found:
                    return AtomOperation.NULL
            else:
                return AtomOperation.NULL
        return current

    def _set_value_at_path(self, data: dict, path: List[str], value: Any) -> bool:
        """根据路径设置值，支持 nodes/connections 列表按 id 查找"""
        if not path:
            return False

        # 特殊处理：如果路径是 ['nodes', 'id'] 或 ['connections', 'id'] 或 ['roots', 'id']
        # 或者 ['nodes', 'id', 'field'] 或 ['connections', 'id', 'field'] 或 ['roots', 'id', 'field']
        if len(path) >= 2 and path[0] in ('nodes', 'connections', 'roots'):
            list_key = path[0]
            target_id = path[1]
            target_list = data.get(list_key, [])

            if not isinstance(target_list, list):
                return False

            # 查找目标项的索引
            target_idx = -1
            for idx, item in enumerate(target_list):
                if isinstance(item, dict) and str(item.get('id', '')) == target_id:
                    target_idx = idx
                    break

            # 如果还有第三级路径（如 ['nodes', 'id', 'position']）
            if len(path) >= 3 and target_idx >= 0:
                # 修改节点内部的某个字段
                target_item = target_list[target_idx]
                if not isinstance(target_item, dict):
                    return False
                # 处理剩余的子路径
                current = target_item
                for key in path[2:-1]:
                    if key not in current:
                        current[key] = {}
                    current = current[key]
                last_key = path[-1]
                if value == AtomOperation.NULL:
                    if last_key in current:
                        del current[last_key]
                else:
                    current[last_key] = value
                return True

            if value == AtomOperation.NULL:
                # 删除操作
                if target_idx >= 0:
                    target_list.pop(target_idx)
                    return True
                return False
            else:
                # 添加或更新操作
                if target_idx >= 0:
                    target_list[target_idx] = value
                else:
                    target_list.append(value)
                return True

        # 默认路径处理
        current = data
        for key in path[:-1]:
            if isinstance(current, dict):
                if key not in current:
                    current[key] = {}
                current = current[key]
            elif isinstance(current, list) and key.isdigit():
                idx = int(key)
                if idx < 0 or idx >= len(current):
                    return False
                current = current[idx]
            else:
                return False

        last_key = path[-1]
        if isinstance(current, dict):
            if value == AtomOperation.NULL:
                if last_key in current:
                    del current[last_key]
            else:
                current[last_key] = value
            return True
        elif isinstance(current, list) and last_key.isdigit():
            idx = int(last_key)
            if value == AtomOperation.NULL:
                if idx < len(current):
                    current.pop(idx)
            else:
                if idx == len(current):
                    current.append(value)
                elif idx < len(current):
                    current[idx] = value
            return True
        return False

    def rollback(self, json_data: dict = None) -> Union[dict, bool]:
        """
        回滚操作（撤销）

        只能在 act=True 时工作，否则返回 False

        Args:
            json_data: 要修改的 JSON 数据，None 表示获取当前画布 JSON

        Returns:
            修改后的 JSON dict，或 False（验证失败）
        """
        if not self.act:
            return False

        # 如果没有提供 json_data，获取当前画布的
        if json_data is None:
            return False

        # 验证当前状态是否符合预期（new 值应该存在）
        current = self._get_value_at_path(json_data, self.jpath)
        # 对于 Create 操作，只要节点存在（不是 NULL）就认为匹配
        if self.is_create():
            if current == AtomOperation.NULL:
                return False
        # 对于 Delete 操作，验证节点应该不存在
        elif self.is_delete():
            pass  # 删除操作不验证
        # 对于 Update 操作，验证当前值存在即可（不要求严格等于 new，因为重新导入后可能略有不同）
        elif current == AtomOperation.NULL:
            return False

        # 执行回滚：恢复到 old 值
        if not self._set_value_at_path(json_data, self.jpath, self.old):
            return False

        self.act = False
        return json_data

    def apply(self, json_data: dict = None) -> Union[dict, bool]:
        """
        应用操作（重做）

        只能在 act=False 时工作，否则返回 False

        Args:
            json_data: 要修改的 JSON 数据，None 表示获取当前画布 JSON

        Returns:
            修改后的 JSON dict，或 False（验证失败）
        """
        if self.act:
            return False

        # 如果没有提供 json_data，获取当前画布的
        if json_data is None:
            return False

        # 验证当前状态是否符合预期（old 值应该存在或为空）
        current = self._get_value_at_path(json_data, self.jpath)
        # 对于 Delete 操作，只要节点存在即可
        if self.is_delete():
            if current == AtomOperation.NULL:
                return False
        # 对于 Create 操作，验证节点应该不存在
        elif self.is_create():
            pass  # 创建操作不验证
        # 对于 Update 操作，验证当前值存在即可
        elif current == AtomOperation.NULL:
            return False

        # 执行应用：设置为 new 值
        if not self._set_value_at_path(json_data, self.jpath, self.new):
            return False

        self.act = True
        return json_data


class LimitedActionStack:
    """
    有限大小的操作栈，支持 Undo/Redo

    结构：
    - _undo_stack: 已执行的操作（从旧到新）
    - _redo_stack: 被撤销的操作（从新到旧）
    - 新操作 push 时，清空 redo_stack
    """

    def __init__(self, max_size: int = 100):
        self._max_size = max_size
        self._undo_stack: deque = deque(maxlen=max_size)
        self._redo_stack: deque = deque(maxlen=max_size)

    def push(self, operation: AtomOperation) -> None:
        """推送操作到栈（会清空 redo 栈）"""
        self._undo_stack.append(operation)
        # 新操作会丢弃 redo 历史
        self._redo_stack.clear()

    def can_undo(self) -> bool:
        """是否可以撤销"""
        return bool(self._undo_stack)

    def can_redo(self) -> bool:
        """是否可以重做"""
        return bool(self._redo_stack)

    def undo(self) -> Optional[AtomOperation]:
        """
        撤销操作：将最近的操作从 undo 栈移到 redo 栈

        Returns:
            被撤销的操作，如果没有可撤销的返回 None
        """
        if not self._undo_stack:
            return None
        operation = self._undo_stack.pop()
        self._redo_stack.append(operation)
        return operation

    def redo(self) -> Optional[AtomOperation]:
        """
        重做操作：将最近的操作从 redo 栈移回 undo 栈

        Returns:
            被重做的操作，如果没有可重做的返回 None
        """
        if not self._redo_stack:
            return None
        operation = self._redo_stack.pop()
        self._undo_stack.append(operation)
        return operation

    def clear(self) -> None:
        """清空所有栈"""
        self._undo_stack.clear()
        self._redo_stack.clear()

    def __len__(self) -> int:
        return len(self._undo_stack)

    def __bool__(self) -> bool:
        return bool(self._undo_stack)

    def get_all(self) -> List[AtomOperation]:
        """获取所有 undo 操作（从旧到新）"""
        return list(self._undo_stack)


class NodeCanvas(QGraphicsView):
    """
    节点画布 - 主视图组件
    处理所有的用户交互：拖拽、选择、连接、右键菜单等
    """
    
    def __init__(self, parent: Optional['QWidget'] = None, *, create_default_root: bool = True) -> None:
        super().__init__(parent)

        # 创建场景
        self._scene: QGraphicsScene = QGraphicsScene(self)
        self._scene.setSceneRect(-5000, -5000, 10000, 10000)
        self.setScene(self._scene)
        
        # 设置渲染选项
        self.setRenderHints(QPainter.RenderHint.Antialiasing | QPainter.RenderHint.SmoothPixmapTransform)
        self.setViewportUpdateMode(QGraphicsView.ViewportUpdateMode.FullViewportUpdate)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOn)
        self.setTransformationAnchor(QGraphicsView.ViewportAnchor.AnchorUnderMouse)
        self.setResizeAnchor(QGraphicsView.ViewportAnchor.AnchorViewCenter)
        
        # 拖拽模式 - 使用 RubberBandDrag 以支持项拖拽，但普通框选被禁用
        self.setDragMode(QGraphicsView.DragMode.RubberBandDrag)
        
        # 状态变量
        self._nodes: List[NodeItem] = []
        self._connections: List[ConnectionItem] = []
        self._nodes_creation_order: List[NodeItem] = []  # 按创建顺序存储节点
        self._start_node: Optional[NodeItem] = None  # 起点节点
        self._drag_start_pos: Optional[QPointF] = None
        self._temp_connection: Optional[QGraphicsPathItem] = None
        self._source_node_for_connection: Optional[NodeItem] = None
        self._selection_rect: Optional[SelectionRect] = None
        self._selection_start_pos: Optional[QPointF] = None
        self._is_panning: bool = False
        self._pan_start_pos: Optional[QPointF] = None
        self._is_creating_connection: bool = False
        
        # 箭头拖拽状态
        self._dragged_arrow: Optional[ArrowItem] = None
        self._original_connection: Optional[ConnectionItem] = None
        self._original_is_bidirectional: bool = False
        self._temp_new_connection: Optional[QGraphicsPathItem] = None

        # Alt框选状态
        self._is_alt_selecting: bool = False
        self._alt_selection_start_pos: Optional[QPointF] = None

        # 节点到编辑窗口的映射
        self._node_edit_windows: Dict[NodeItem, NodeEditWindow] = {}

        # ROOT 图元管理
        self._root_items: List[RootItem] = []
        self._root_edit_windows: Dict[RootItem, ClassEditWindow] = {}

        # 修改追踪系统
        self._action_stack = LimitedActionStack(max_size=100)
        self._changed: bool = False
        self._is_batch_operation: bool = False  # 批操作标志（如布局）
        self._batch_operations: List[AtomOperation] = []  # 批操作暂存

        # 当前打开的 JSON 文件路径
        self._json_file_path: Optional[str] = None

        # 拖拽位置追踪（用于检测节点/ROOT移动）
        self._drag_start_positions: Dict[int, QPointF] = {}  # id(item) -> 起始位置

        # 设置背景
        self._setup_background()

        # 启用鼠标跟踪
        self.setMouseTracking(True)

        # 连接箭头信号
        self._setup_arrow_signals()

        # 创建默认 ROOT（根据参数决定）
        if create_default_root:
            self._create_default_root()

    def _create_default_root(self) -> None:
        """创建默认 ROOT 图元"""
        if not self._root_items:
            root = RootItem(0, 0, 60.0, "MyClass")
            self._scene.addItem(root)
            self._root_items.append(root)
            root._signal_helper.edit_requested.connect(self._open_root_edit_window)

    def _setup_background(self) -> None:
        """设置画布背景"""
        self.setBackgroundBrush(QBrush(QColor("#F0F0F0")))
    
    def _setup_arrow_signals(self) -> None:
        """设置箭头信号连接（在添加箭头时调用）"""
        pass  # 箭头信号在创建时动态连接

    # =========================================================================
    # 修改追踪系统
    # =========================================================================

    @property
    def changed(self) -> bool:
        """画布是否有未保存的修改"""
        return self._changed

    @changed.setter
    def changed(self, value: bool) -> None:
        """
        设置修改状态，自动更新窗口标题

        Args:
            value: 新的修改状态
        """
        if self._changed != value:
            self._changed = value
            # 通知父窗口更新标题
            self._update_window_title()

    def _update_window_title(self) -> None:
        """更新窗口标题显示

        格式: NodeCanvasWidget - <filename or 'New Graph'> [*]
        """
        # 获取顶级主窗口（parent 为 None 的窗口）
        parent = self.parent()
        while parent and parent.parent() is not None:
            parent = parent.parent()

        if parent and hasattr(parent, 'setWindowTitle'):
            # 基础软件名称
            software_name = "NodeCanvasWidget"

            # 文件名部分
            if self._json_file_path:
                import os
                file_name = os.path.basename(self._json_file_path)
            else:
                file_name = "New Graph"

            # 构建标题
            title = f"{software_name} - {file_name}"
            if self._changed:
                title += " *"

            parent.setWindowTitle(title)

    def set_json_file_path(self, file_path: Optional[str]) -> None:
        """
        设置当前 JSON 文件路径

        Args:
            file_path: 文件路径，None 表示未命名的新图
        """
        if self._json_file_path != file_path:
            self._json_file_path = file_path
            self._update_window_title()

    def get_json_file_path(self) -> Optional[str]:
        """获取当前 JSON 文件路径"""
        return self._json_file_path

    def _push_operation(self, operation: AtomOperation) -> None:
        """
        推送操作到栈

        Args:
            operation: 原子操作
        """
        if self._is_batch_operation:
            # 批操作模式下暂存
            self._batch_operations.append(operation)
        else:
            # 正常推送并标记修改
            self._action_stack.push(operation)
            self.changed = True

    def start_batch_operation(self) -> None:
        """开始批操作（如布局）"""
        self._is_batch_operation = True
        self._batch_operations = []

    def end_batch_operation(self) -> None:
        """结束批操作，将暂存的操作合并推送"""
        self._is_batch_operation = False
        if self._batch_operations:
            # 批操作只算作一次修改，推送一个代表操作
            batch_op = AtomOperation(
                old=None,
                new=None,
                jpath=['__batch__', f'{len(self._batch_operations)}_operations']
            )
            self._action_stack.push(batch_op)
            self._batch_operations = []
            self.changed = True

    def reset_changed_state(self) -> None:
        """重置修改状态（Save 成功后调用）"""
        self.changed = False

    def clear_action_stack(self) -> None:
        """清空操作栈（新建画布时调用）"""
        self._action_stack.clear()
        self.changed = False

    def _update_operation_ids(self, node_map: dict) -> None:
        """更新操作栈中的节点 id 映射

        Args:
            node_map: 旧 id 到新节点的映射字典
        """
        # 构建旧 id -> 新 id 的映射
        id_map = {old_id: id(new_node) for old_id, new_node in node_map.items()}

        # 更新 undo 栈中的操作
        for operation in self._action_stack._undo_stack:
            if len(operation.jpath) >= 2 and operation.jpath[0] == 'nodes':
                old_id_str = operation.jpath[1]
                try:
                    old_id = int(old_id_str)
                    if old_id in id_map:
                        operation.jpath[1] = str(id_map[old_id])
                except ValueError:
                    pass

        # 更新 redo 栈中的操作
        for operation in self._action_stack._redo_stack:
            if len(operation.jpath) >= 2 and operation.jpath[0] == 'nodes':
                old_id_str = operation.jpath[1]
                try:
                    old_id = int(old_id_str)
                    if old_id in id_map:
                        operation.jpath[1] = str(id_map[old_id])
                except ValueError:
                    pass

    def can_undo(self) -> bool:
        """检查是否可以撤销"""
        return self._action_stack.can_undo()

    def can_redo(self) -> bool:
        """检查是否可以重做"""
        return self._action_stack.can_redo()

    def undo(self) -> bool:
        """
        撤销最近一次操作

        Returns:
            True: 撤销成功
            False: 没有可撤销的操作
        """
        operation = self._action_stack.undo()
        if operation is None:
            return False

        # 获取当前画布 JSON
        try:
            current_json = json.loads(self.export())
        except Exception as e:
            print(f"[DEBUG] undo failed: cannot export JSON - {e}")
            # 恢复操作状态
            self._action_stack.redo()
            return False

        # 回滚操作
        result = operation.rollback(current_json)
        if result is False:
            print(f"[DEBUG] undo failed: rollback returned False for {operation}")
            # 恢复操作状态
            self._action_stack.redo()
            QMessageBox.warning(self, "Undo Failed", f"无法撤销操作:\n{operation}")
            return False

        # 导入修改后的 JSON
        try:
            node_map = self._import_from_json(result)
            # 更新操作栈中的 id 映射（旧 id -> 新 id）
            self._update_operation_ids(node_map)
        except Exception as e:
            import traceback
            print(f"[DEBUG] undo failed: import error - {e}")
            traceback.print_exc()
            QMessageBox.critical(self, "Error", f"Undo import failed: {e}")
            return False

        self.changed = True
        self.refresh()
        return True

    def redo(self) -> bool:
        """
        重做最近一次撤销的操作

        Returns:
            True: 重做成功
            False: 没有可重做的操作
        """
        operation = self._action_stack.redo()
        if operation is None:
            return False

        # 获取当前画布 JSON
        try:
            current_json = json.loads(self.export())
        except Exception as e:
            print(f"[DEBUG] redo failed: cannot export JSON - {e}")
            # 恢复操作状态
            self._action_stack.undo()
            return False

        # 应用操作
        result = operation.apply(current_json)
        if result is False:
            print(f"[DEBUG] redo failed: apply returned False for {operation}")
            # 恢复操作状态
            self._action_stack.undo()
            QMessageBox.warning(self, "Redo Failed", f"无法重做操作:\n{operation}")
            return False

        # 导入修改后的 JSON
        try:
            node_map = self._import_from_json(result)
            # 更新操作栈中的 id 映射（旧 id -> 新 id）
            self._update_operation_ids(node_map)
        except Exception as e:
            print(f"[DEBUG] redo failed: import error - {e}")
            QMessageBox.critical(self, "Error", f"Redo import failed: {e}")
            return False

        self.changed = True
        self.refresh()
        return True

    def _import_from_json(self, json_data: dict) -> dict:
        """从 JSON 数据导入（用于 undo/redo）

        Returns:
            old_id_to_new_node: 旧 id 到新节点的映射字典
        """
        # 先关闭所有编辑窗口
        self.close_all_edit_windows()

        # 清除现有内容但保留 ROOT
        for node in list(self._nodes):
            self._remove_node_internal(node)
        for conn in list(self._connections):
            self._remove_connection_internal(conn)

        # 导入节点
        nodes_data = json_data.get('nodes', [])
        node_map = {}  # old_id -> new_node

        for node_data in nodes_data:
            name = node_data.get('name', 'Unnamed')
            pos_data = node_data.get('position', {'x': 0, 'y': 0})
            position = QPointF(pos_data.get('x', 0), pos_data.get('y', 0))

            node = NodeItem(name, position)
            node._connection_texts = node_data.get('connection_texts', {})
            node._connection_order = node_data.get('connection_order', [])

            self._scene.addItem(node)
            self._nodes.append(node)
            self._nodes_creation_order.append(node)

            old_id = node_data.get('id')
            if old_id is not None:
                node_map[old_id] = node

        # 导入连接
        connections_data = json_data.get('connections', [])
        for conn_data in connections_data:
            source_id = conn_data.get('source_id')
            target_id = conn_data.get('target_id')

            if source_id in node_map and target_id in node_map:
                source_node = node_map[source_id]
                target_node = node_map[target_id]
                self.add_connection(source_node, target_node)

        # 设置起点节点
        start_node_id = json_data.get('start_node_id')
        if start_node_id in node_map:
            self._start_node = node_map[start_node_id]
            if self._start_node:
                self._start_node.set_as_start(True)

        # 更新 ROOT（如果存在）
        roots_data = json_data.get('roots', [])
        if roots_data and self._root_items:
            root_data = roots_data[0]
            root = self._root_items[0]
            root.name = root_data.get('name', 'MyClass')
            root.logic_type = root_data.get('logic_type', 'CreepLogic')
            root.class_contents = root_data.get('class_contents', {})
            root.class_settings_values = root_data.get('class_settings_values', {})
            # 更新 ROOT 位置
            pos_data = root_data.get('position', {'x': 0, 'y': 0})
            root.setPos(pos_data.get('x', 0), pos_data.get('y', 0))

        return node_map

    def _remove_node_internal(self, node: NodeItem) -> None:
        """内部删除节点（不记录操作）"""
        # 移除相关连接
        for conn in list(self._connections):
            if conn.source_node == node or conn.target_node == node:
                self._remove_connection_internal(conn)

        # 从场景中移除
        self._scene.removeItem(node)

        # 从列表中移除
        if node in self._nodes:
            self._nodes.remove(node)
        if node in self._nodes_creation_order:
            self._nodes_creation_order.remove(node)

        # 如果删除的是起点节点，清除起点标记
        if self._start_node == node:
            self._start_node = None

    def _remove_connection_internal(self, conn) -> None:
        """内部删除连接（不记录操作）"""
        self._scene.removeItem(conn)
        if conn in self._connections:
            self._connections.remove(conn)

    def refresh(self) -> None:
        """
        刷新画布视图

        在 undo/redo 等操作后调用，用于刷新节点、连接等图元的显示
        """
        # 刷新所有节点
        for node in self._nodes:
            node.update()

        # 刷新所有连接
        for conn in self._connections:
            conn.update()

        # 刷新所有 ROOT
        for root in self._root_items:
            root.update()

        # 刷新视图
        self.viewport().update()
        self._scene.update()

    @property
    def nodes(self) -> List[NodeItem]:
        """获取按创建顺序排列的所有节点"""
        return self._nodes_creation_order.copy()

    def get_safe_name(self, name: str, exclude_node: Optional[NodeItem] = None) -> str:
        """
        获取安全化的节点名称，确保不重复

        Args:
            name: 原始名称
            exclude_node: 排除的节点（用于重命名时排除自身）

        Returns:
            唯一的、安全化的名称
        """
        # 先获取基础安全名
        base_safe_name = NodeItem._sanitize_name(name)
        safe_name = base_safe_name

        # 获取所有其他节点的安全名
        existing_names = {n.safe_name for n in self._nodes if n != exclude_node}

        # 如果冲突，添加数字后缀
        counter = 1
        while safe_name in existing_names:
            safe_name = f"{base_safe_name}_{counter}"
            counter += 1

        return safe_name

    def is_safe_name_available(self, name: str, exclude_node: Optional[NodeItem] = None) -> bool:
        """
        检查安全化名称是否可用（不重复）

        Args:
            name: 原始名称
            exclude_node: 排除的节点（用于重命名时排除自身）

        Returns:
            如果可用返回 True，否则返回 False
        """
        safe_name = NodeItem._sanitize_name(name)
        existing_names = {n.safe_name for n in self._nodes if n != exclude_node}

        return safe_name not in existing_names

    @property
    def start_node(self) -> Optional[NodeItem]:
        """获取起点节点"""
        return self._start_node

    @start_node.setter
    def start_node(self, node: Optional[NodeItem]) -> None:
        """设置起点节点"""
        # 清除旧的起点标记
        if self._start_node is not None and self._start_node != node:
            self._start_node.set_start_marker_visible(False)

        self._start_node = node

        # 设置新的起点标记
        if node is not None:
            node.set_start_marker_visible(True)

    def _open_node_edit_window(self, node: NodeItem) -> None:
        """打开节点的编辑窗口"""
        if node in self._node_edit_windows:
            # 窗口已存在，激活它
            window = self._node_edit_windows[node]
            window.raise_()
            window.activateWindow()
        else:
            # 创建新窗口，记录原始数据用于后续比较
            original_name = node.name
            original_connection_texts = getattr(node, '_connection_texts', {}).copy()
            window = NodeEditWindow.get_or_create(node, None)  # None表示独立窗口

            # 获取 ROOT 的类定义代码并传递给编辑器
            root_class_code = self._get_root_class_code()
            if root_class_code:
                window.set_root_class_code(root_class_code)

            # 连接信号，保存原始数据
            window.closed.connect(
                lambda: self._on_edit_window_closed(node, original_name, original_connection_texts)
            )
            window.highlight_connection_requested.connect(
                lambda target: self._highlight_connection(node, target)
            )
            window.show()
            self._node_edit_windows[node] = window

    def _get_root_class_code(self) -> str:
        """获取 ROOT 的类定义代码（用于 self. 补全）"""
        if not self._root_items:
            return ""
        # 获取第一个 ROOT 的类头部代码（包含导入、类定义、NAME、RECIPE、类变量等）
        root = self._root_items[0]
        return root.generate_class_header()

    def _on_edit_window_closed(self, node: NodeItem, original_name: str = "", original_connection_texts: dict = None) -> None:
        """编辑窗口关闭时的回调"""
        if node in self._node_edit_windows:
            del self._node_edit_windows[node]

        # 检查名称是否有变化
        if original_name and original_name != node.name:
            # 追踪名称修改操作
            self._push_operation(AtomOperation(
                old=original_name,
                new=node.name,
                jpath=['nodes', str(id(node)), 'name']
            ))

        # 检查连接文本是否有变化
        current_connection_texts = getattr(node, '_connection_texts', {})
        if original_connection_texts is not None and original_connection_texts != current_connection_texts:
            # 追踪连接文本修改操作
            self._push_operation(AtomOperation(
                old=original_connection_texts,
                new=current_connection_texts.copy(),
                jpath=['nodes', str(id(node)), 'connection_texts']
            ))

    def _highlight_connection(self, source_node: NodeItem, target_node: NodeItem) -> None:
        """
        高亮显示从源节点到目标节点的连线

        Args:
            source_node: 源节点
            target_node: 目标节点
        """
        for conn in self._connections:
            if conn.source_node == source_node and conn.target_node == target_node:
                conn.flash_highlight()
                break

    def save_all_edit_windows(self) -> None:
        """保存所有打开的编辑窗口的内容（不关闭窗口）"""
        # 保存所有 NodeEditWindow
        for window in list(self._node_edit_windows.values()):
            # 触发保存 - 保存所有修改的标签页并同步到节点
            if hasattr(window, 'editor') and hasattr(window.editor, 'save_all_modified_tabs'):
                window.editor.save_all_modified_tabs()
            if hasattr(window, '_save_to_node'):
                window._save_to_node()

        # 保存所有 ClassEditWindow
        for window in list(self._root_edit_windows.values()):
            if hasattr(window, '_editor') and hasattr(window._editor, 'save_all_modified_tabs'):
                window._editor.save_all_modified_tabs()
            if hasattr(window, '_save_to_root'):
                window._save_to_root()

    def set_edit_windows_stay_on_top(self, stay_on_top: bool) -> None:
        """
        设置所有 edit 窗口的置顶状态

        Args:
            stay_on_top: True 置顶，False 不置顶
        """
        from PyQt6.QtCore import Qt

        # 设置所有 NodeEditWindow
        for window in list(self._node_edit_windows.values()):
            try:
                window.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint, stay_on_top)
                window.show()
            except Exception:
                pass

        # 设置所有 ClassEditWindow
        for window in list(self._root_edit_windows.values()):
            try:
                window.setWindowFlag(Qt.WindowType.WindowStaysOnTopHint, stay_on_top)
                window.show()
            except Exception:
                pass

    def close_all_edit_windows(self) -> None:
        """关闭所有编辑窗口"""
        for window in list(self._node_edit_windows.values()):
            window.close()
        self._node_edit_windows.clear()

        # 关闭所有 ROOT 编辑窗口
        for window in list(self._root_edit_windows.values()):
            window.close()
        self._root_edit_windows.clear()
    
    def add_node(self, name: str, position: Optional[QPointF] = None, skip_default_position: bool = False) -> NodeItem:
        """
        添加一个新节点

        Args:
            name: 节点名称
            position: 节点位置，默认为画布中心
            skip_default_position: 如果为True，不计算默认位置（用于导入时）

        Returns:
            创建的节点项
        """
        if position is None and not skip_default_position:
            position = self.mapToScene(self.viewport().rect().center())
        elif position is None:
            position = QPointF(0, 0)  # 临时位置，后续会设置

        node = NodeItem(name, position)
        self._scene.addItem(node)

        # 设置默认文档注释
        node._connection_texts = {
            '__doc__': '"""\n这是一个注释\n"""',
            '__begin__': '',
            '__end__': ''
        }
        self._nodes.append(node)
        self._nodes_creation_order.append(node)  # 记录创建顺序

        # 如果是第一个节点，自动设为起点
        if len(self._nodes) == 1:
            self.start_node = node

        # 连接节点的edit_requested信号
        node.edit_requested.connect(self._open_node_edit_window)

        # 初始化节点的连接列表
        node._connections = []
        node._connection_order = []
        # 连接文本字典已在上面设置默认值

        # 追踪新增节点操作 - 使用与 _serialize_data 一致的格式
        self._push_operation(AtomOperation(
            old=AtomOperation.NULL,
            new={
                'name': name,
                'position': {'x': position.x(), 'y': position.y()},
                'id': id(node)
            },
            jpath=['nodes', str(id(node))]
        ))

        return node

    def add_root(self, name: str = "MyClass", position: Optional[QPointF] = None) -> Optional[RootItem]:
        """
        添加一个 ROOT 图元

        Args:
            name: ROOT 名称
            position: 位置，默认为画布中心

        Returns:
            创建的 RootItem，如果已有 ROOT 则返回 None
        """
        # 拒绝在已有 ROOT 时继续添加
        if self._root_items:
            print("Error: Root already exists, cannot add another one")
            return None

        if position is None:
            position = self.mapToScene(self.viewport().rect().center())

        root = RootItem(position.x(), position.y(), 60.0, name)
        self._scene.addItem(root)
        self._root_items.append(root)

        # 连接编辑请求信号
        root._signal_helper.edit_requested.connect(self._open_root_edit_window)

        # 追踪新增 ROOT 操作 - 使用与 _serialize_data 一致的格式
        self._push_operation(AtomOperation(
            old=AtomOperation.NULL,
            new={
                'name': name,
                'position': {'x': position.x(), 'y': position.y()},
                'id': id(root),
                'logic_type': 'CreepLogic',
                'class_contents': {},
                'class_settings_values': {}
            },
            jpath=['roots', str(id(root))]
        ))

        return root

    def remove_root(self, root: RootItem) -> None:
        """
        移除一个 ROOT 图元

        Args:
            root: 要移除的 ROOT 图元
        """
        # 记录 ROOT 信息用于追踪
        root_name = root.name
        root_pos = root.pos()
        root_id = str(id(root))

        # 关闭对应的编辑窗口
        if root in self._root_edit_windows:
            self._root_edit_windows[root].close()

        # 从列表中移除
        if root in self._root_items:
            self._root_items.remove(root)
            self._scene.removeItem(root)

        # 追踪删除 ROOT 操作
        self._push_operation(AtomOperation(
            old={'name': root_name, 'pos': (root_pos.x(), root_pos.y())},
            new=AtomOperation.NULL,
            jpath=['roots', root_id]
        ))

    def _open_root_edit_window(self, root: RootItem) -> None:
        """打开 ROOT 的编辑窗口"""
        if root in self._root_edit_windows:
            # 窗口已存在，激活它
            window = self._root_edit_windows[root]
            window.raise_()
            window.activateWindow()
        else:
            # 创建新窗口，记录原始数据用于后续比较
            original_name = root.name
            original_contents = root.class_contents.copy() if hasattr(root, 'class_contents') else {}
            window = ClassEditWindow.get_or_create(root, None)
            # 连接信号，保存原始数据
            window.closed.connect(
                lambda: self._on_root_edit_window_closed(root, original_name, original_contents)
            )
            window.show()
            self._root_edit_windows[root] = window

    def _on_root_edit_window_closed(self, root: RootItem, original_name: str = "", original_contents: dict = None) -> None:
        """ROOT 编辑窗口关闭时的回调"""
        if root in self._root_edit_windows:
            del self._root_edit_windows[root]

        # 检查名称是否有变化
        if original_name and original_name != root.name:
            # 追踪名称修改操作
            self._push_operation(AtomOperation(
                old=original_name,
                new=root.name,
                jpath=['roots', str(id(root)), 'name']
            ))

        # 检查 class_contents 是否有变化
        current_contents = root.class_contents if hasattr(root, 'class_contents') else {}
        if original_contents is not None and original_contents != current_contents:
            # 追踪内容修改操作
            self._push_operation(AtomOperation(
                old=original_contents,
                new=current_contents.copy(),
                jpath=['roots', str(id(root)), 'class_contents']
            ))

    def remove_node(self, node: NodeItem) -> None:
        """
        移除一个节点及其所有连接

        Args:
            node: 要移除的节点
        """
        # 记录节点信息用于追踪
        node_name = node.name
        node_pos = node.pos()
        node_id = str(id(node))

        # 关闭对应的编辑窗口
        if node in self._node_edit_windows:
            self._node_edit_windows[node].close()

        # 移除与此节点相关的所有连接
        connections_to_remove = [
            conn for conn in self._connections
            if conn.source_node == node or conn.target_node == node
        ]

        for conn in connections_to_remove:
            self.remove_connection(conn)

        # 移除节点
        if node in self._nodes:
            self._nodes.remove(node)
            self._scene.removeItem(node)

        # 从创建顺序列表中移除
        if node in self._nodes_creation_order:
            self._nodes_creation_order.remove(node)

        # 如果移除的是起点节点，清除起点
        if self._start_node == node:
            self._start_node = None

        # 追踪删除节点操作
        self._push_operation(AtomOperation(
            old={'name': node_name, 'pos': (node_pos.x(), node_pos.y())},
            new=AtomOperation.NULL,
            jpath=['nodes', node_id]
        ))

    def _get_bidirectional_partners(self, node: NodeItem) -> List[NodeItem]:
        """
        获取与指定节点双向连接的所有伙伴节点

        Args:
            node: 要查找的节点

        Returns:
            与该节点双向连接的节点列表（不包括节点自身）
        """
        partners = []
        for conn in self._connections:
            if conn.is_bidirectional:
                if conn.source_node == node:
                    partners.append(conn.target_node)
                elif conn.target_node == node:
                    partners.append(conn.source_node)
        return partners

    def add_connection(self, source: NodeItem, target: NodeItem, check_partners: bool = True) -> Optional[ConnectionItem]:
        """
        添加两个节点之间的连接

        Args:
            source: 源节点
            target: 目标节点
            check_partners: 是否检查源节点的双向连接伙伴（从节点边缘拖拽时为True，拖拽箭头时为False）

        Returns:
            创建的连接项，如果连接已存在则返回None
        """
        # 检查是否已存在相同方向的连接
        # 简化逻辑：只检查严格重复的连接和直接的反向连接
        for conn in self._connections:
            # 1. 检查源节点到目标节点的直接连接（严格检查）
            if conn.source_node == source and conn.target_node == target:
                conn.flash_error()
                return None

            # 2. 检查反向连接（目标到源的连接）
            # 只有当目标直接到源有连接时才转换为双向
            # 修复：不使用 source_partners，只检查直接的反向连接
            if conn.source_node == target and conn.target_node == source:
                # 反向连接已存在，将其转换为双向连线
                if conn.is_bidirectional:
                    conn.flash_error()
                    return None
                conn.is_bidirectional = True
                conn.update_path()
                # 为新创建的源端箭头连接信号
                if conn.source_arrow:
                    self._connect_arrow_signals(conn.source_arrow)

                # 更新源节点的连接列表
                if target not in source._connections:
                    source._connections.append(target)

                # 更新源节点的编辑窗口列表
                if source in self._node_edit_windows:
                    self._node_edit_windows[source].update_connection_list()

                # 更新目标节点的连接列表（双向）
                if source not in target._connections:
                    target._connections.append(source)

                # 更新目标节点的编辑窗口列表
                if target in self._node_edit_windows:
                    self._node_edit_windows[target].update_connection_list()

                return conn

        connection = ConnectionItem(source, target)
        self._scene.addItem(connection)
        self._connections.append(connection)

        # 追踪新增连接操作
        self._push_operation(AtomOperation(
            old=AtomOperation.NULL,
            new={'source': source.name, 'target': target.name},
            jpath=['connections', f'{id(source)}->{id(target)}']
        ))

        # 强制更新路径，确保箭头被添加到场景并显示
        connection.update_path()

        # 连接箭头信号
        self._connect_arrow_signals(connection.target_arrow)
        if connection.source_arrow:
            self._connect_arrow_signals(connection.source_arrow)

        # 更新源节点的连接列表
        if target not in source._connections:
            source._connections.append(target)

        # 更新源节点的编辑窗口列表
        if source in self._node_edit_windows:
            self._node_edit_windows[source].update_connection_list()

        return connection
    
    def _connect_arrow_signals(self, arrow: ArrowItem) -> None:
        """连接箭头信号（使用回调函数）"""
        arrow.set_drag_callbacks(
            started=self._on_arrow_drag_started,
            moved=self._on_arrow_drag_moved,
            finished=self._on_arrow_drag_finished
        )
    
    def _disconnect_arrow_signals(self, arrow: ArrowItem) -> None:
        """断开箭头信号"""
        arrow.set_drag_callbacks(None, None, None)
    
    def _on_arrow_drag_started(self, pos: QPointF) -> None:
        """箭头拖拽开始"""
        # 找到当前被拖拽的箭头
        for conn in self._connections:
            for arrow in conn.arrows:
                if arrow._is_dragging:
                    self._dragged_arrow = arrow
                    self._original_connection = arrow.connection
                    self._original_is_bidirectional = arrow.connection.is_bidirectional

                    # 创建临时连接线
                    self._temp_new_connection = QGraphicsPathItem()
                    pen = QPen(QColor("#666666"), 2, Qt.PenStyle.DashLine)
                    self._temp_new_connection.setPen(pen)
                    self._scene.addItem(self._temp_new_connection)
                    return
    
    def _on_arrow_drag_moved(self, pos: QPointF) -> None:
        """箭头拖拽移动"""
        if self._dragged_arrow and self._temp_new_connection and self._original_connection:
            # 根据拖拽的箭头类型确定虚线起点
            if self._dragged_arrow.is_source_arrow:
                # 拖拽源端箭头（反向箭头），从目标节点中心发出
                start_pos = self._original_connection.target_node.sceneBoundingRect().center()
            else:
                # 拖拽目标端箭头（正向箭头），从源节点中心发出
                start_pos = self._original_connection.source_node.sceneBoundingRect().center()

            path = QPainterPath()
            path.moveTo(start_pos)
            path.lineTo(pos)
            self._temp_new_connection.setPath(path)

    def _on_arrow_drag_finished(self, pos: QPointF, success: bool) -> None:
        """箭头拖拽结束"""
        # 移除临时连接线
        if self._temp_new_connection:
            self._scene.removeItem(self._temp_new_connection)
            self._temp_new_connection = None

        if self._dragged_arrow and self._original_connection:
            connection = self._original_connection
            
            if success:
                # 查找目标节点
                item = self._scene.itemAt(pos, QTransform())
                target_node = None
                while item:
                    if isinstance(item, NodeItem):
                        target_node = item
                        break
                    item = item.parentItem()

                if target_node:
                    # 确定新连接的源节点和目标节点
                    # 从箭头的起点创建新连接
                    # is_source_arrow=False: target_arrow 从 source_node 发出 -> 新源节点是 source_node
                    # is_source_arrow=True: source_arrow 从 target_node 发出 -> 新源节点是 target_node
                    if self._dragged_arrow.is_source_arrow:
                        # 拖拽的是源端箭头（从 target_node 发出，指向 source_node）
                        # 新源节点是 target_node
                        new_source = connection.target_node
                        new_target = target_node
                    else:
                        # 拖拽的是目标端箭头（从 source_node 发出，指向 target_node）
                        # 新源节点是 source_node
                        new_source = connection.source_node
                        new_target = target_node

                    # 检查是否是同一连接
                    if new_source != new_target:
                        # 保存原始连接的状态
                        orig_source = connection.source_node
                        orig_target = connection.target_node
                        orig_is_source_arrow = self._dragged_arrow.is_source_arrow
                        orig_is_bidirectional = self._original_is_bidirectional

                        # 检查是否拖拽回同一个目标（连接未改变）
                        same_target = (new_source == orig_source and new_target == orig_target) or \
                           (orig_is_bidirectional and new_source == orig_target and new_target == orig_source)
                        if same_target:
                            # 拖拽回同一目标，不做任何操作
                            new_conn = None
                        else:
                            # 先尝试创建新连接（如果失败会闪烁）
                            # 拖拽箭头时，不检查源节点的双向伙伴（check_partners=False）
                            new_conn = self.add_connection(new_source, new_target, check_partners=False)

                        if new_conn is not None:
                            # 新连接创建成功
                            # 处理原始连接：如果是双向连接，保留未拖拽方向的连接
                            if orig_is_bidirectional:
                                # 双向连接需要特殊处理：保留未拖拽方向的连接
                                if orig_is_source_arrow:
                                    # 拖拽的是源端箭头 (B->A)
                                    # 原连接: target_arrow=A->B, source_arrow=B->A
                                    # 需要保留: A->B (target_arrow)
                                    # 移除: B->A (source_arrow)
                                    # 直接设置为单向即可，会移除 source_arrow
                                    connection.is_bidirectional = False
                                    # 重新连接信号
                                    self._connect_arrow_signals(connection.target_arrow)
                                else:
                                    # 拖拽的是目标端箭头 (A->B)
                                    # 原连接: target_arrow=A->B, source_arrow=B->A
                                    # 需要保留: B->A (source_arrow)
                                    # 移除: A->B (target_arrow)
                                    # 先交换方向，使要保留的箭头成为 target_arrow
                                    connection.swap_direction()
                                    # 然后设置为单向，这会移除 source_arrow (原 target_arrow)
                                    connection.is_bidirectional = False
                                    # 重新连接信号
                                    self._connect_arrow_signals(connection.target_arrow)
                            else:
                                # 单向连接，直接删除
                                self.remove_connection(connection)
                        else:
                            # 新连接创建失败（已存在），恢复原始连接
                            # 注意：add_connection 内部已经闪烁了已存在的连接，这里不再闪烁
                            if orig_is_bidirectional:
                                # 恢复双向状态
                                connection.is_bidirectional = True
                                connection.update_path()
                                if connection.source_arrow:
                                    self._connect_arrow_signals(connection.source_arrow)
                    else:
                        # 连接到同一节点，恢复并闪烁
                        connection.flash_error()
                else:
                    # 没有连接到节点，恢复并闪烁
                    connection.flash_error()
            else:
                # 连接失败，恢复并闪烁
                connection.flash_error()
            
            self._dragged_arrow = None
            self._original_connection = None
            self._original_is_bidirectional = False
    
    def _flash_connection(self, connection: ConnectionItem) -> None:
        """闪烁连接表示失败"""
        connection.flash_error()
    
    def remove_connection(self, connection: ConnectionItem) -> None:
        """
        移除一个连接
        
        Args:
            connection: 要移除的连接
        """
        if connection in self._connections:
            source = connection.source_node
            target = connection.target_node
            
            # 断开箭头信号
            self._disconnect_arrow_signals(connection.target_arrow)
            if connection.source_arrow:
                self._disconnect_arrow_signals(connection.source_arrow)
            
            # 移除箭头
            connection.remove_arrows()
            
            # 移除连接
            self._connections.remove(connection)
            self._scene.removeItem(connection)
            
            # 更新源节点的连接列表
            if target in source._connections:
                source._connections.remove(target)
            
            # 更新目标节点的连接列表（如果是双向）
            if connection.is_bidirectional and source in target._connections:
                target._connections.remove(source)
            
            # 更新编辑窗口列表
            if source in self._node_edit_windows:
                self._node_edit_windows[source].update_connection_list()
            if target in self._node_edit_windows:
                self._node_edit_windows[target].update_connection_list()
    
    def contextMenuEvent(self, event: QContextMenuEvent) -> None:
        """右键菜单事件"""
        scene_pos = self.mapToScene(event.pos())
        item = self._scene.itemAt(scene_pos, QTransform())

        menu = QMenu(self)

        if isinstance(item, NodeItem):
            # 在节点上右键
            # 头部添加编辑和重命名
            edit_action = menu.addAction("🔧编辑")
            rename_action = menu.addAction("✒️重命名")
            copy_action = menu.addAction("📑复制")
            delete_action = menu.addAction("❌删除")
            menu.addSeparator()

            change_shape_action = menu.addAction("🪢改变形状")
            set_start_action = menu.addAction("🔷 设定起点")

            # 添加 Recursive 标记菜单项
            if item.is_recursive:
                recursive_action = menu.addAction("✖️ 取消标记 Recursive")
            else:
                recursive_action = menu.addAction("♾️ 标记为 Recursive")

            action = menu.exec(event.globalPos())
            if action == edit_action:
                self._open_node_edit_window(item)
            elif action == rename_action:
                item._start_editing()
            elif action == copy_action:
                item.copy()
            elif action == delete_action:
                self.remove_node(item)
            elif action == change_shape_action:
                item.toggle_shape()
            elif action == set_start_action:
                self.start_node = item  # 使用 setter 会处理标记的显示
            elif action == recursive_action:
                item.toggle_recursive()

        elif isinstance(item, ArrowItem):
            # 在箭头上右键 - 移除单个箭头（如果只有一个箭头就移除整个连线）
            remove_arrow_action = menu.addAction("移除连接")
            action = menu.exec(event.globalPos())
            if action == remove_arrow_action:
                connection = item.connection
                if connection.is_bidirectional:
                    # 双向连接：移除点击的那个箭头，变成单向
                    if item.is_source_arrow:
                        # 点击的是源端箭头（反向箭头），保留正向
                        connection.is_bidirectional = False
                    else:
                        # 点击的是目标端箭头（正向箭头），保留反向
                        # 先交换方向，再设为单向
                        connection.swap_direction()
                        connection.is_bidirectional = False
                else:
                    # 单向连接：移除整个连线
                    self.remove_connection(connection)

        elif isinstance(item, ConnectionItem):
            # 在连接线上右键 - 移除整个连线
            remove_line_action = menu.addAction("❌删除")
            action = menu.exec(event.globalPos())
            if action == remove_line_action:
                self.remove_connection(item)

        elif isinstance(item, RootItem):
            # 在 ROOT 图元上右键
            edit_action = menu.addAction("🔧编辑")
            rename_action = menu.addAction("✒️重命名")
            menu.addSeparator()

            action = menu.exec(event.globalPos())
            if action == edit_action:
                self._open_root_edit_window(item)
            elif action == rename_action:
                item._start_editing()

        else:
            # 在空白画布上右键
            new_node_action = menu.addAction("+ 新节点")

            # 添加粘贴菜单项（检查剪贴板是否为有效的JSON格式）
            clipboard = QApplication.clipboard()
            clipboard_text = clipboard.text()
            can_paste = False
            try:
                clipboard_json = json.loads(clipboard_text)
                # 进一步检查是否包含必要的字段（name）
                if isinstance(clipboard_json, dict) and "name" in clipboard_json:
                    can_paste = True
            except (json.JSONDecodeError, ValueError):
                pass

            paste_action = menu.addAction("📰粘贴")
            paste_action.setEnabled(can_paste)

            # 添加移动ROOT菜单项（如果ROOT存在则启用，否则禁用）
            move_root_action = menu.addAction("移动ROOT到此处")
            move_root_action.setEnabled(len(self._root_items) > 0)

            menu.addSeparator()

            # 添加自动适应视口菜单项（始终启用）
            fit_viewport_action = menu.addAction("📺自动适应")

            # 添加自动布局菜单项（如果有节点则启用）
            auto_layout_action = menu.addAction("📐 自动布局")
            auto_layout_action.setEnabled(len(self._nodes) > 0)

            action = menu.exec(event.globalPos())
            if action == new_node_action:
                # 直接创建默认名称的节点
                default_name = f"节点{len(self._nodes) + 1}"
                self.add_node(default_name, scene_pos)
            elif action == paste_action and can_paste:
                # 从剪贴板粘贴节点
                try:
                    node = NodeItem.from_json(clipboard_text, position=scene_pos)
                    self._scene.addItem(node)
                    self._nodes.append(node)
                    self._nodes_creation_order.append(node)

                    # 设置默认文档注释（如果没有）
                    if not hasattr(node, '_connection_texts') or not node._connection_texts:
                        node._connection_texts = {
                            '__doc__': '"""\n这是一个注释\n"""',
                            '__begin__': '',
                            '__end__': ''
                        }

                    # 如果是第一个节点，自动设为起点
                    if len(self._nodes) == 1:
                        self.start_node = node

                    # 连接节点的edit_requested信号
                    node.edit_requested.connect(self._open_node_edit_window)

                    # 初始化节点的连接列表
                    node._connections = []
                    node._connection_order = []

                except ValueError as e:
                    QMessageBox.warning(self, "粘贴失败", f"无法创建节点: {e}")
            elif action == move_root_action:
                # 移动ROOT到点击位置
                if len(self._root_items) > 0:
                    root = self._root_items[0]
                    root.setPos(scene_pos)
                    # 如果有编辑窗口打开，更新其位置追踪（如果需要）
                    if hasattr(root, '_edit_window_open') and root._edit_window_open:
                        # 通知ROOT位置已改变（如果需要）
                        pass
            elif action == fit_viewport_action:
                # 执行自动适配视口
                self.fit_viewport(min_scale=0.5, max_scale=1.6, padding_ratio=0.1)
            elif action == auto_layout_action:
                # 执行自动布局
                self.auto_layout("compact")

        super().contextMenuEvent(event)
    
    def _clear_all_selection(self) -> None:
        """清除所有选中状态"""
        self._scene.clearSelection()

    def mousePressEvent(self, event: QMouseEvent) -> None:
        """鼠标按下事件"""
        scene_pos = self.mapToScene(event.pos())

        if event.button() == Qt.MouseButton.LeftButton:
            item = self._scene.itemAt(scene_pos, QTransform())

            # 检查是否处于Alt框选模式
            if self._is_alt_selecting:
                # Alt框选模式下，无论点击哪里，都清空选择并开始框选
                self._clear_all_selection()
                self._alt_selection_start_pos = scene_pos
                self._start_selection_rect(scene_pos)
                event.accept()
                return

            # 点击空白处时，清除所有选中（Ctrl+点击除外）
            if item is None:
                if not (event.modifiers() & Qt.KeyboardModifier.ControlModifier):
                    self._clear_all_selection()

            # 检查是否点击在箭头上
            if isinstance(item, ArrowItem):
                # 点击箭头时，同时选中连接线和另一个箭头
                connection = item.connection
                connection.set_selected(True)
                # 让视图正常处理事件，使箭头可以开始拖拽
                super().mousePressEvent(event)
                return

            # 检查是否点击在连接线上（但不是箭头）
            if isinstance(item, ConnectionItem):
                # 点击连接线，同时选中两个箭头
                item.set_selected(True)
                event.accept()
                return

            # 检查是否点击在节点上（开始创建连接）
            if isinstance(item, NodeItem):
                # 检查是否是拖拽创建连接（从节点边缘开始）
                if self._is_on_node_edge(item, scene_pos):
                    self._is_creating_connection = True
                    self._source_node_for_connection = item
                    self._drag_start_pos = scene_pos
                    self.setDragMode(QGraphicsView.DragMode.RubberBandDrag)
                    self._create_temp_connection(scene_pos)
                    return

                # 普通点击节点 - 记录起始位置用于移动追踪
                self._drag_start_positions[id(item)] = item.pos()
                item.setSelected(True)
                super().mousePressEvent(event)
                return

            # 检查是否点击在 ROOT 上
            if isinstance(item, RootItem):
                # ROOT 不能被连线，普通点击即可 - 记录起始位置用于移动追踪
                self._drag_start_positions[id(item)] = item.pos()
                item.setSelected(True)
                super().mousePressEvent(event)
                return

            else:
                # 点击空白处，不进行框选（框选只能通过Alt+拖拽）
                event.accept()
                return

        elif event.button() == Qt.MouseButton.MiddleButton:
            # 中键平移
            self._is_panning = True
            self._pan_start_pos = event.pos()
            self.setCursor(Qt.CursorShape.ClosedHandCursor)

        super().mousePressEvent(event)
    
    def mouseMoveEvent(self, event: QMouseEvent) -> None:
        """鼠标移动事件"""
        scene_pos = self.mapToScene(event.pos())

        # 优先处理Alt框选
        if self._is_alt_selecting and self._selection_rect:
            # 更新框选矩形
            self._update_selection_rect(scene_pos)
            return

        if self._is_creating_connection and self._temp_connection:
            # 更新临时连接线
            self._update_temp_connection(scene_pos)
            return

        if self._selection_rect and not self._is_alt_selecting:
            # 普通框选（保留原有逻辑，虽然现在不会触发）
            self._update_selection_rect(scene_pos)
            return

        if self._is_panning and self._pan_start_pos:
            # 平移视图
            delta = event.pos() - self._pan_start_pos
            self._pan_start_pos = event.pos()
            self.horizontalScrollBar().setValue(
                self.horizontalScrollBar().value() - delta.x()
            )
            self.verticalScrollBar().setValue(
                self.verticalScrollBar().value() - delta.y()
            )
            return

        super().mouseMoveEvent(event)
    
    def mouseReleaseEvent(self, event: QMouseEvent) -> None:
        """鼠标释放事件"""
        scene_pos = self.mapToScene(event.pos())

        if event.button() == Qt.MouseButton.LeftButton:
            if self._is_creating_connection:
                # 完成连接创建
                self._finish_connection_creation(scene_pos)
                self._is_creating_connection = False
                self._source_node_for_connection = None
                self._drag_start_pos = None
                self.setDragMode(QGraphicsView.DragMode.RubberBandDrag)

            if self._is_alt_selecting and self._selection_rect:
                # Alt框选模式下，应用框选
                self._finish_selection_rect()
                # 保持Alt状态，直到Alt键释放
                return

            if self._selection_rect and not self._is_alt_selecting:
                # 普通框选完成（保留原有逻辑）
                self._finish_selection_rect()

        elif event.button() == Qt.MouseButton.MiddleButton:
            # 结束平移
            self._is_panning = False
            self._pan_start_pos = None
            self.setCursor(Qt.CursorShape.ArrowCursor)

        # 检查节点/ROOT 位置变化
        self._check_item_movements()

        super().mouseReleaseEvent(event)

    def _check_item_movements(self) -> None:
        """检查并记录节点/ROOT 的移动"""
        if not self._drag_start_positions:
            return

        for item_id, start_pos in self._drag_start_positions.items():
            # 查找对应的节点或 ROOT
            item = None
            for node in self._nodes:
                if id(node) == item_id:
                    item = node
                    item_type = 'nodes'
                    break
            if item is None:
                for root in self._root_items:
                    if id(root) == item_id:
                        item = root
                        item_type = 'roots'
                        break

            if item is not None:
                end_pos = item.pos()
                # 检查位置是否有显著变化
                if (abs(end_pos.x() - start_pos.x()) > 1 or
                    abs(end_pos.y() - start_pos.y()) > 1):
                    # 推送移动操作 - 使用与 _serialize_data 一致的格式
                    self._push_operation(AtomOperation(
                        old={'x': start_pos.x(), 'y': start_pos.y()},
                        new={'x': end_pos.x(), 'y': end_pos.y()},
                        jpath=[item_type, str(item_id), 'position']
                    ))

        # 清空拖拽起始位置记录
        self._drag_start_positions.clear()
    
    def _is_on_node_edge(self, node: NodeItem, pos: QPointF) -> bool:
        """检查位置是否在节点边缘（用于创建连接）"""
        center = node.sceneBoundingRect().center()
        radius = node.radius
        distance = math.sqrt(
            (pos.x() - center.x()) ** 2 + (pos.y() - center.y()) ** 2
        )
        # 允许在节点边缘一定范围内开始拖拽
        return distance >= radius * 0.7
    
    def _create_temp_connection(self, start_pos: QPointF) -> None:
        """创建临时连接线"""
        if self._source_node_for_connection:
            # 创建一个临时的连接线项
            self._temp_connection = QGraphicsPathItem()
            pen = QPen(QColor("#666666"), 2, Qt.PenStyle.DashLine)
            self._temp_connection.setPen(pen)
            self._scene.addItem(self._temp_connection)
    
    def _update_temp_connection(self, end_pos: QPointF) -> None:
        """更新临时连接线"""
        if self._source_node_for_connection and self._temp_connection:
            source_center = self._source_node_for_connection.sceneBoundingRect().center()
            
            # 创建贝塞尔曲线路径
            path = QPainterPath()
            path.moveTo(source_center)
            
            dx = end_pos.x() - source_center.x()
            dy = end_pos.y() - source_center.y()
            distance = math.sqrt(dx * dx + dy * dy)
            offset = min(distance * 0.5, 150)
            
            if abs(dx) > abs(dy):
                ctrl1 = QPointF(source_center.x() + offset * (1 if dx > 0 else -1), source_center.y())
                ctrl2 = QPointF(end_pos.x() - offset * (1 if dx > 0 else -1), end_pos.y())
            else:
                ctrl1 = QPointF(source_center.x(), source_center.y() + offset * (1 if dy > 0 else -1))
                ctrl2 = QPointF(end_pos.x(), end_pos.y() - offset * (1 if dy > 0 else -1))
            
            path.cubicTo(ctrl1, ctrl2, end_pos)
            self._temp_connection.setPath(path)
    
    def _finish_connection_creation(self, end_pos: QPointF) -> None:
        """完成连接创建"""
        # 移除临时连接线
        if self._temp_connection:
            self._scene.removeItem(self._temp_connection)
            self._temp_connection = None
        
        if self._source_node_for_connection:
            # 查找目标节点
            item = self._scene.itemAt(end_pos, QTransform())
            
            # 向上查找到NodeItem
            target_node = None
            while item:
                if isinstance(item, NodeItem):
                    target_node = item
                    break
                item = item.parentItem()
            
            # 创建连接
            if target_node and target_node != self._source_node_for_connection:
                self.add_connection(self._source_node_for_connection, target_node)
    
    def _start_selection_rect(self, start_pos: QPointF) -> None:
        """开始框选"""
        self._selection_rect = SelectionRect()
        self._selection_rect.setRect(QRectF(start_pos, start_pos))
        self._scene.addItem(self._selection_rect)
        self._selection_start_pos = start_pos
    
    def _update_selection_rect(self, current_pos: QPointF) -> None:
        """更新框选矩形"""
        if self._selection_rect and self._selection_start_pos:
            rect = QRectF(self._selection_start_pos, current_pos).normalized()
            self._selection_rect.setRect(rect)
            
            # 实时选择矩形内的节点
            for item in self._scene.items(rect):
                if isinstance(item, NodeItem):
                    item.setSelected(True)
    
    def _finish_selection_rect(self) -> None:
        """完成框选"""
        if self._selection_rect:
            self._scene.removeItem(self._selection_rect)
            self._selection_rect = None
            self._selection_start_pos = None

    def _cancel_alt_selection(self) -> None:
        """取消Alt框选（仅在框选未完成时调用）"""
        # 如果还在进行框选（鼠标未松开），则取消框选并清除已选中的节点
        if self._selection_rect:
            self._scene.removeItem(self._selection_rect)
            self._selection_rect = None
            self._selection_start_pos = None
            # 清除所有已选中的节点（因为实时选择已经在拖拽过程中应用）
            self._clear_all_selection()
        # 重置Alt状态
        self._is_alt_selecting = False
        self._alt_selection_start_pos = None
        self.setCursor(Qt.CursorShape.ArrowCursor)

    def keyPressEvent(self, event: QKeyEvent) -> None:
        """键盘按下事件"""
        if event.key() == Qt.Key.Key_Delete:
            # 删除选中的项
            self._delete_selected_items()
            return

        # 检测Alt键按下，进入框选模式
        if event.key() == Qt.Key.Key_Alt and not event.isAutoRepeat() and not self._is_alt_selecting:
            self._is_alt_selecting = True
            self.setCursor(Qt.CursorShape.CrossCursor)
            event.accept()
            return

        super().keyPressEvent(event)

    def keyReleaseEvent(self, event: QKeyEvent) -> None:
        """键盘释放事件"""
        # 检测Alt键释放，如果在框选状态则取消
        if event.key() == Qt.Key.Key_Alt and self._is_alt_selecting:
            self._cancel_alt_selection()
            event.accept()
            return

        super().keyReleaseEvent(event)
    
    def _delete_selected_items(self) -> None:
        """删除选中的项"""
        # 收集要删除的项
        nodes_to_remove: List[NodeItem] = []
        connections_to_remove: List[ConnectionItem] = []
        
        for item in self._scene.selectedItems():
            if isinstance(item, NodeItem):
                nodes_to_remove.append(item)
            elif isinstance(item, ArrowItem):
                # 如果选中了箭头，删除整个连接
                if item.connection not in connections_to_remove:
                    connections_to_remove.append(item.connection)
            elif isinstance(item, ConnectionItem):
                if item not in connections_to_remove:
                    connections_to_remove.append(item)
        
        # 删除连接
        for conn in connections_to_remove:
            self.remove_connection(conn)
        
        # 删除节点
        for node in nodes_to_remove:
            self.remove_node(node)
    
    def wheelEvent(self, event: QWheelEvent) -> None:
        """滚轮事件 - 缩放"""
        # 获取缩放因子
        delta = event.angleDelta().y()
        zoom_factor = 1.15 if delta > 0 else 1 / 1.15
        
        # 限制缩放范围
        current_scale = self.transform().m11()
        if (zoom_factor > 1 and current_scale > 5) or (zoom_factor < 1 and current_scale < 0.2):
            return
        
        self.scale(zoom_factor, zoom_factor)

    # =========================================================================
    # 导入/导出 API (实验性，接口可能会更改)
    # =========================================================================

    def _serialize_data(self, filter_empty: bool = False) -> dict:
        """
        序列化画布数据为字典

        Args:
            filter_empty: 是否过滤空白的代码内容（用于Save/SaveAs时设为True）

        Returns:
            包含画布所有数据的字典
        """
        # 序列化节点（按创建顺序）
        nodes_data = []
        for node in self._nodes_creation_order:
            pos = node.pos()
            node_data = {
                "id": id(node),
                "name": node.name,
                "position": {"x": pos.x(), "y": pos.y()}
            }

            # 只导出非默认值的字段
            if node.radius != 40.0:  # 默认半径
                node_data["radius"] = node.radius

            # 获取节点的连接文本字典
            connection_texts = getattr(node, '_connection_texts', {})
            if filter_empty:
                # 保存到文件时：过滤掉空白内容
                connection_texts = {k: v for k, v in connection_texts.items() if v and v.strip()}
            else:
                # API获取时：使用 node.to_dict() 获取完整字段
                connection_texts = node.to_dict().get("connection_texts", {})
            if connection_texts:
                node_data["connection_texts"] = connection_texts

            # 导出 recursive 标记（只导出为 True 的情况）
            if getattr(node, 'is_recursive', False):
                node_data["is_recursive"] = True

            nodes_data.append(node_data)

        # 序列化连接
        connections_data = []
        for conn in self._connections:
            conn_data = {
                "source_id": id(conn.source_node),
                "target_id": id(conn.target_node)
            }
            # 只导出非默认值的字段
            if conn.is_bidirectional:
                conn_data["is_bidirectional"] = True
            connections_data.append(conn_data)

        # 序列化 ROOT 图元
        roots_data = []
        for root in self._root_items:
            pos = root.pos()
            # 根据 filter_empty 决定是否过滤空白内容
            if filter_empty:
                # 保存到文件时：过滤掉空白内容
                class_contents = {k: v for k, v in root.class_contents.items() if v and v.strip()}
            else:
                # API获取时：使用 to_dict() 获取完整字段
                class_contents = root.to_dict().get("class_contents", {})
            root_data = {
                "id": id(root),
                "name": root.name,
                "position": {"x": pos.x(), "y": pos.y()},
                "logic_type": root.logic_type,
                "import_from": getattr(root, 'import_from', 'builtin'),
                "class_contents": class_contents,
                "class_settings_values": root.class_settings_values
            }
            roots_data.append(root_data)

        # 构建导出数据
        data = {
            "version": "2.2.0",  # 版本升级到 2.2.0，支持 ROOT 导出和 recursive 标记
            "nodes": nodes_data,
            "connections": connections_data,
            "roots": roots_data
        }

        # 起点节点ID（只在有时导出）
        if self._start_node:
            data["start_node_id"] = id(self._start_node)

        return data

    def _generate_python_code(self) -> str:
        """
        生成Python代码

        Returns:
            生成的Python类代码字符串
        """
        # 获取类
        if not self._root_items:
            return "# No class defined"

        root = self._root_items[0]

        # 收集节点方法
        node_methods = []
        visited = set()
        start_node = self._start_node

        if start_node:
            self._collect_node_methods_to_list(node_methods, start_node, visited)

        # 生成完整类代码
        return root.generate_full_class(node_methods=node_methods)

    def _collect_node_methods_to_list(self, node_methods: list, node: 'NodeItem', visited: set):
        """递归收集节点方法代码到列表"""
        if node in visited:
            return

        visited.add(node)

        # 调用 NodeItem 自己的方法生成代码
        method_code = node.generate_method_code(base_indent="    ")
        if method_code:
            node_methods.append(method_code)

        # 递归处理出边连接
        for conn in self._connections:
            if conn.source_node is node:
                self._collect_node_methods_to_list(node_methods, conn.target_node, visited)

    def _collect_node_methods(self, lines: list, node: 'NodeItem', visited: set):
        """递归收集节点方法代码"""
        if node in visited:
            return

        visited.add(node)

        # 调用 NodeItem 自己的方法生成代码
        method_code = node.generate_method_code(base_indent="    ")
        if method_code:
            lines.append(method_code)
            lines.append("")

        # 递归处理出边连接
        for conn in self._connections:
            if conn.source_node is node:
                self._collect_node_methods(lines, conn.target_node, visited)

    def _deserialize_data(self, data: dict, clear_existing: bool = True) -> None:
        """
        从字典反序列化画布数据

        Args:
            data: 包含画布数据的字典
            clear_existing: 是否清除现有数据，默认为 True

        Raises:
            ValueError: 数据格式无效
        """
        import warnings

        # 版本检查（警告但不阻止）
        version = data.get("version", "unknown")
        if version not in ["1.0.0", "2.0.0", "2.1.0", "2.2.0"]:
            warnings.warn(f"JSON版本 {version} 与当前版本 2.2.0 可能不兼容", UserWarning)

        # 清除现有数据（如果需要）
        if clear_existing:
            self.clear_all()

        # 创建节点映射 (原ID -> 新节点)
        id_to_node: Dict[int, NodeItem] = {}

        # 获取节点创建顺序（如果存在）
        node_order = data.get("node_order", [])
        nodes_data_list = data.get("nodes", [])

        # 按创建顺序排序节点数据
        if node_order:
            node_data_dict = {node["id"]: node for node in nodes_data_list}
            sorted_nodes_data = []
            for node_id in node_order:
                if node_id in node_data_dict:
                    sorted_nodes_data.append(node_data_dict[node_id])
            # 添加可能不在顺序列表中的节点
            for node in nodes_data_list:
                if node["id"] not in node_order:
                    sorted_nodes_data.append(node)
            nodes_data_list = sorted_nodes_data

        # 导入节点（处理安全化名称重名）
        for node_data in nodes_data_list:
            node_id = node_data["id"]
            name = node_data["name"]
            pos = node_data["position"]
            radius = node_data.get("radius", 40.0)
            connection_texts = node_data.get("connection_texts", {})

            # 获取唯一的安全化名称（自动处理重名）
            unique_name = self.get_safe_name(name)

            # 创建节点（跳过默认位置计算，直接使用set_position设置正确位置）
            node = self.add_node(unique_name, skip_default_position=True)
            node.set_position(pos["x"], pos["y"])

            # 设置原始显示名称（触发setter更新文本显示）
            node.name = name
            # 设置安全名（确保唯一性）
            node._safe_name = unique_name

            # 设置半径（如果与默认值不同）
            if radius != node.radius:
                node.radius = radius

            # 恢复节点的文本内容（合并到默认值中，而不是替换）
            if connection_texts:
                node._connection_texts.update(connection_texts)

            # 恢复 recursive 标记
            if node_data.get("is_recursive", False):
                node.set_recursive(True)

            id_to_node[node_id] = node

        # 导入连接
        for conn_data in data.get("connections", []):
            source_id = conn_data["source_id"]
            target_id = conn_data["target_id"]
            is_bidirectional = conn_data.get("is_bidirectional", False)

            # 查找对应的节点
            source_node = id_to_node.get(source_id)
            target_node = id_to_node.get(target_id)

            if source_node and target_node:
                # 创建连接（不使用伙伴检查，因为我们是精确重建）
                conn = self.add_connection(source_node, target_node, check_partners=False)
                if conn and is_bidirectional:
                    conn.is_bidirectional = True
                    conn.update_path()
            else:
                warnings.warn(f"跳过连接: 找不到源节点或目标节点 ({source_id} -> {target_id})", UserWarning)

        # 重新映射 connection_texts 中的 conn_{{id}} 键
        # 建立旧目标ID到新目标节点的映射
        old_target_id_to_new_node: Dict[int, NodeItem] = {}
        for conn_data in data.get("connections", []):
            old_source_id = conn_data["source_id"]
            old_target_id = conn_data["target_id"]
            if old_source_id in id_to_node and old_target_id in id_to_node:
                old_target_id_to_new_node[old_target_id] = id_to_node[old_target_id]

        # 遍历每个节点，更新其 _connection_texts 中的 conn_{{id}} 键
        for old_node_id, node in id_to_node.items():
            if hasattr(node, '_connection_texts') and node._connection_texts:
                new_texts = {}
                for key, value in list(node._connection_texts.items()):
                    if key.startswith('conn_'):
                        # 提取旧的连接目标ID
                        try:
                            old_conn_id = int(key.split('_')[1])
                            # 查找新的目标节点
                            if old_conn_id in old_target_id_to_new_node:
                                new_target = old_target_id_to_new_node[old_conn_id]
                                new_key = f"conn_{id(new_target)}"
                                new_texts[new_key] = value
                            else:
                                # 如果找不到映射，保留原键（可能有问题）
                                new_texts[key] = value
                        except (ValueError, IndexError):
                            new_texts[key] = value
                    else:
                        new_texts[key] = value
                node._connection_texts = new_texts

        # 设置起点节点
        start_node_id = data.get("start_node_id")
        if start_node_id and start_node_id in id_to_node:
            self.start_node = id_to_node[start_node_id]

        # 导入 ROOT 图元
        for root_data in data.get("roots", []):
            name = root_data.get("name", "MyClass")
            pos = root_data.get("position", {"x": 0, "y": 0})
            logic_type = root_data.get("logic_type", "CreepLogic")
            import_from = root_data.get("import_from", "builtin")  # 缺省使用 builtin
            class_contents = root_data.get("class_contents", {})
            class_settings_values = root_data.get("class_settings_values", {})

            # 创建 ROOT
            root = self.add_root(name, QPointF(pos["x"], pos["y"]))

            # 设置类型
            root.logic_type = logic_type

            # 设置导入来源
            root.import_from = import_from

            # 恢复内容
            if class_contents:
                root.class_contents = class_contents

            # 恢复设置值
            if class_settings_values:
                root.class_settings_values = class_settings_values

    def export(self, filter_empty: bool = False) -> str:
        """
        导出画布状态为JSON字符串

        Args:
            filter_empty: 是否过滤空白的代码内容（用于Save/SaveAs时设为True）

        Returns:
            JSON格式的字符串，包含所有节点和连接信息

        Note:
            此API为实验性接口，后续版本可能会更改格式或结构
        """
        data = self._serialize_data(filter_empty=filter_empty)
        return json.dumps(data, indent=2, ensure_ascii=False)

    @staticmethod
    def Import(json_code: str) -> 'NodeCanvas':
        """
        从JSON字符串导入画布状态

        Args:
            json_code: JSON格式的字符串，包含节点和连接信息

        Returns:
            新的NodeCanvas实例，包含导入的节点和连接

        Raises:
            ValueError: JSON格式无效或版本不兼容

        Note:
            此API为实验性接口，后续版本可能会更改参数或返回值
        """
        # 解析JSON
        try:
            data = json.loads(json_code)
        except json.JSONDecodeError as e:
            raise ValueError(f"无效的JSON格式: {e}")

        # 创建新的画布实例并反序列化数据
        canvas = NodeCanvas(create_default_root=False)
        canvas._deserialize_data(data, clear_existing=False)

        return canvas

    # =========================================================================
    # 重叠检测与布局 API
    # =========================================================================

    def check_overlaps(self, check_node_node: bool = True,
                      check_node_connection: bool = True,
                      check_connection_connection: bool = True,
                      check_node_root: bool = True,
                      check_root_root: bool = True,
                      check_connection_root: bool = True) -> List:
        """
        检查图元之间的重叠情况

        检测哪些图元之间发生了重叠：
        - 节点（圆形）之间：判断圆形本身是否相交
        - 连线之间：判断贝塞尔曲线本身是否相交
        - 节点与连线之间：判断圆形是否与曲线相交
        - ROOT（圆形）与其他图元：判断圆形是否相交
        - 连线与ROOT之间：判断连线是否与类定义圆圈相交

        Args:
            check_node_node: 是否检查节点之间的重叠
            check_node_connection: 是否检查节点与连接线的重叠
            check_connection_connection: 是否检查连接线之间的重叠
            check_node_root: 是否检查节点与ROOT的重叠
            check_root_root: 是否检查ROOT之间的重叠
            check_connection_root: 是否检查连接线与ROOT的重叠

        Returns:
            重叠对列表，每个元素包含两个发生重叠的图元及其类型信息

        Example:
            overlaps = canvas.check_overlaps()
            for pair in overlaps:
                print(f"重叠: {pair.item1.name} <-> {pair.item2.name}")
        """
        from .layout_utils import OverlapDetector
        detector = OverlapDetector(self)
        return detector.find_all_overlaps(
            check_node_node=check_node_node,
            check_node_connection=check_node_connection,
            check_connection_connection=check_connection_connection,
            check_node_root=check_node_root,
            check_root_root=check_root_root,
            check_connection_root=check_connection_root
        )

    def get_overlap_summary(self) -> dict:
        """
        获取重叠统计信息

        Returns:
            包含各类重叠数量的字典，例如：
            {
                "total": 5,
                "node_node": 2,
                "node_connection": 1,
                "connection_connection": 0,
                "node_root": 1,
                "root_root": 1
            }
        """
        from .layout_utils import OverlapDetector
        detector = OverlapDetector(self)
        return detector.get_overlap_summary()

    def has_overlaps(self) -> bool:
        """检查是否存在任何重叠"""
        return len(self.check_overlaps()) > 0

    def auto_layout(self, strategy: str = "compact", items: List = None) -> None:
        """
        自动布局图元，尽可能密集地避免重叠

        可用的布局策略：
        - "compact": 紧凑布局（默认），综合多种策略自动选择最佳方案
        - "circular": 圆形布局，将图元排列在同心圆上
        - "grid": 网格布局，将图元排列成规则的网格
        - "hierarchical": 层次布局，基于连接关系按层级排列
        - "force": 力导向布局，模拟物理力使图元均匀分布

        Args:
            strategy: 布局策略名称
            items: 要布局的图元列表，如果为None则布局所有图元

        Example:
            # 使用默认的紧凑布局
            canvas.auto_layout()

            # 使用圆形布局
            canvas.auto_layout("circular")

            # 只布局选中的节点
            selected = [item for item in canvas.scene().selectedItems()
                       if isinstance(item, NodeItem)]
            canvas.auto_layout("compact", selected)
        """
        from .layout_utils import DenseLayoutEngine
        engine = DenseLayoutEngine(self)

        if items is None:
            items = list(self._nodes) + list(self._root_items)

        # 开始批操作（布局只算一次修改）
        self.start_batch_operation()

        if strategy == "compact":
            engine.layout_compact(items)
        elif strategy == "circular":
            engine.layout_circular(items)
        elif strategy == "grid":
            engine.layout_grid(items)
        elif strategy == "hierarchical":
            engine.layout_hierarchical(items)
        elif strategy == "force":
            engine.layout_force_directed(items)
        else:
            engine.layout_compact(items)

        # 更新所有连接线
        for conn in self._connections:
            conn.update_path()

        # 结束批操作
        self.end_batch_operation()

    def layout_circular(self, items: List = None, center: QPointF = None) -> None:
        """圆形布局 - 将图元排列在同心圆上"""
        from .layout_utils import DenseLayoutEngine
        engine = DenseLayoutEngine(self)
        if items is None:
            items = list(self._nodes) + list(self._root_items)
        engine.layout_circular(items, center)
        for conn in self._connections:
            conn.update_path()

    def layout_grid(self, items: List = None, cols: int = None) -> None:
        """网格布局 - 将图元排列成规则的网格"""
        from .layout_utils import DenseLayoutEngine
        engine = DenseLayoutEngine(self)
        if items is None:
            items = list(self._nodes) + list(self._root_items)
        engine.layout_grid(items, cols=cols)
        for conn in self._connections:
            conn.update_path()

    def layout_hierarchical(self, items: List = None) -> None:
        """层次布局 - 基于连接关系按层级排列"""
        from .layout_utils import DenseLayoutEngine
        engine = DenseLayoutEngine(self)
        if items is None:
            items = list(self._nodes) + list(self._root_items)
        engine.layout_hierarchical(items)
        for conn in self._connections:
            conn.update_path()

    def layout_force_directed(self, items: List = None, iterations: int = 100) -> None:
        """力导向布局 - 模拟物理力使图元均匀分布"""
        from .layout_utils import DenseLayoutEngine
        engine = DenseLayoutEngine(self)
        if items is None:
            items = list(self._nodes) + list(self._root_items)
        engine.layout_force_directed(items, iterations=iterations)
        for conn in self._connections:
            conn.update_path()

    def resolve_overlaps(self, max_iterations: int = 100) -> bool:
        """
        尝试解决所有重叠问题

        使用力导向布局迭代地移动图元，直到没有重叠或达到最大迭代次数

        Args:
            max_iterations: 最大迭代次数

        Returns:
            是否成功解决所有重叠（True表示没有重叠了）
        """
        from .layout_utils import OverlapDetector, DenseLayoutEngine
        detector = OverlapDetector(self)
        engine = DenseLayoutEngine(self)

        items = list(self._nodes) + list(self._root_items)

        for i in range(max_iterations):
            overlaps = detector.find_all_overlaps()

            if not overlaps:
                return True

            # 使用力导向布局逐步解决重叠
            engine.layout_force_directed(
                items,
                iterations=5,
                repulsion_strength=10000.0 * (1 + i * 0.1)
            )

        # 最终检查
        return len(detector.find_all_overlaps()) == 0

    def set_layout_margin(self, margin: float) -> None:
        """
        设置布局时的最小间距

        Args:
            margin: 图元之间的最小间距（像素）
        """
        from .layout_utils import DenseLayoutEngine
        engine = DenseLayoutEngine(self)
        engine.set_margin(margin)

    def fit_viewport(
        self,
        min_scale: float = 0.5,
        max_scale: float = 1.6,
        padding_ratio: float = 0.1
    ) -> Dict[str, Any]:
        """
        自动适配视口，确保所有图元可见且视口中心与质心对齐

        根据所有 node 和 root 的半径作为质量，计算质心和包围盒，
        然后设置合适的缩放比例和视口位置。

        Args:
            min_scale: 最小缩放比例
            max_scale: 最大缩放比例
            padding_ratio: 内边距比例（相对于包围盒大小）

        Returns:
            包含适配结果的字典：
            {
                "success": bool,
                "center": QPointF,      # 质心位置（scene 坐标）
                "scale": float,         # 应用的缩放比例
                "bounding_rect": QRectF # 计算的包围盒
            }

        Example:
            result = canvas.fit_viewport(min_scale=0.2, max_scale=3.0)
            if result["success"]:
                print(f"视口已适配: 缩放={result['scale']:.2f}, 质心={result['center']}")
        """
        from .layout_utils import ViewportFitter
        fitter = ViewportFitter(self)
        return fitter.fit_viewport(min_scale, max_scale, padding_ratio)

    def reset_viewport(self) -> None:
        """
        重置视口到默认状态（缩放 1.0，位置在原点）
        """
        self.resetTransform()
        self.centerOn(0, 0)

    def check_viewport(self) -> Dict[str, Any]:
        """
        检查当前视口是否合适

        检查两个条件：
        1. 中心偏差：质心与视口中心的距离是否超出40%画布可视区域高度
        2. 缩放偏差：图元包围盒面积与视口面积的偏差是否在[-0.4, 0.4]范围内

        Returns:
            检查结果字典：
            {
                "center_offset": float,  # 中心偏差（像素）
                "scale_offset": float,   # 缩放偏差（面积比例）
                "center_ok": bool,       # 中心位置是否合理
                "scale_ok": bool,        # 缩放比例是否合理
                "ok": bool               # 整体是否合理（and逻辑）
            }
        """
        from .layout_utils import check_viewport
        return check_viewport(self)

    def check_graph_validity(self) -> dict:
        """
        检查当前画布图的合理性

        Returns:
            检查结果字典，包含：
            - 合理性: str - "不合理" / "基本合理" / "完全合理"
            - 详情: dict - 各检查项的结果详情
            - 错误列表: List[str] - 失败的检查描述
            - 建议列表: List[str] - 改进建议
        """
        from .code_utils import check_graph_validity

        # 调用检查函数，传入 canvas 以执行布局相关检查
        # json 参数默认为 None，会从 canvas 自动导出
        return check_graph_validity(canvas=self)

