"""
枚举定义模块
"""

from enum import Enum, auto


class NodeState(Enum):
    """节点状态枚举"""
    IDLE = auto()
    HOVER = auto()
    SELECTED = auto()


class ArrowState(Enum):
    """箭头状态枚举"""
    IDLE = auto()
    HOVER = auto()
    SELECTED = auto()


class NodeShape(Enum):
    """节点形状枚举"""
    ELLIPSE = auto()  # 椭圆形/圆形
    RECTANGLE = auto()  # 矩形
