"""
画布菜单栏模块
实现一个自动隐藏的顶部菜单栏，鼠标靠近时滑入，离开时滑出
"""

from PyQt6.QtWidgets import (
    QWidget, QHBoxLayout, QPushButton, QMenu, QFileDialog,
    QLabel, QFrame, QInputDialog, QMessageBox, QDialog,
    QVBoxLayout, QTextEdit, QDialogButtonBox
)
from PyQt6.QtCore import Qt, QTimer, pyqtSignal, QPropertyAnimation, QEasingCurve, QPoint
from PyQt6.QtGui import QAction
from typing import TYPE_CHECKING, Dict, List, Any
import json

if TYPE_CHECKING:
    from .node_canvas import NodeCanvas

# 导入 JsonEdit 对话框
import sys
sys.path.insert(0, 'C:/Users/22290/Desktop/node')
from jsonedit import JsonEditorFactory


class MenuBar(QWidget):
    """
    自动隐藏的顶部菜单栏

    功能：
    - 鼠标靠近左上方区域(x:0-400, y:0-50)时下滑进入视野
    - 鼠标移出范围1s后重新上划消失
    - 包含 Files 菜单（Import/Export）
    """

    def __init__(self, canvas: 'NodeCanvas', parent=None):
        super().__init__(parent)

        self._canvas = canvas
        self._is_visible = False
        self._mouse_in_trigger_area = False
        self._mouse_in_menu = False

        # 设置窗口属性
        self.setFixedHeight(30)
        self.setFixedWidth(400)

        # 初始位置：在父窗口上方（隐藏状态）
        self._hidden_y = -30
        self._visible_y = 0

        # 创建布局
        self._setup_ui()

        # 创建定时器（用于延迟隐藏）
        self._hide_timer = QTimer()
        self._hide_timer.setSingleShot(True)
        self._hide_timer.timeout.connect(self._hide)

        # 创建动画
        self._animation = QPropertyAnimation(self, b"pos")
        self._animation.setEasingCurve(QEasingCurve.Type.InOutQuad)
        self._animation.setDuration(200)  # 200ms动画

        # 设置样式
        self._apply_style()

    def _setup_ui(self):
        """设置UI界面"""
        layout = QHBoxLayout(self)
        layout.setContentsMargins(10, 2, 10, 2)
        layout.setSpacing(10)
        layout.setAlignment(Qt.AlignmentFlag.AlignLeft)

        # Files 菜单按钮
        self._files_button = QPushButton("Files")
        self._files_button.setFixedHeight(26)
        self._files_button.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: #333333;
                border: none;
                padding: 4px 12px;
                font-size: 13px;
                text-align: left;
            }
            QPushButton:hover {
                background-color: #e0e0e0;
                border-radius: 4px;
            }
            QPushButton:pressed {
                background-color: #d0d0d0;
            }
        """)

        # 创建下拉菜单
        self._files_menu = QMenu(self)
        self._files_menu.setStyleSheet("""
            QMenu {
                background-color: #ffffff;
                border: 1px solid #cccccc;
                padding: 4px;
            }
            QMenu::item {
                padding: 6px 24px;
                color: #333333;
                font-size: 13px;
            }
            QMenu::item:selected {
                background-color: #5a9bd5;
                color: white;
            }
            QMenu::separator {
                height: 1px;
                background-color: #cccccc;
                margin: 4px 8px;
            }
        """)

        # New 子菜单
        self._new_menu = QMenu("New", self)
        self._new_menu.setStyleSheet(self._files_menu.styleSheet())

        new_graph_action = QAction("Graph", self)
        new_graph_action.triggered.connect(self._on_new_graph)
        self._new_menu.addAction(new_graph_action)

        new_node_action = QAction("Node", self)
        new_node_action.triggered.connect(self._on_new_node)
        self._new_menu.addAction(new_node_action)

        self._files_menu.addMenu(self._new_menu)

        self._files_menu.addSeparator()

        # Load 动作
        self._load_action = QAction("Load", self)
        self._load_action.triggered.connect(self._on_load)
        self._files_menu.addAction(self._load_action)

        # Save 动作
        self._save_action = QAction("Save", self)
        self._save_action.triggered.connect(self._on_save)
        self._files_menu.addAction(self._save_action)

        # Save As 动作
        self._save_as_action = QAction("Save As...", self)
        self._save_as_action.triggered.connect(self._on_save_as)
        self._files_menu.addAction(self._save_as_action)

        self._files_menu.addSeparator()

        # Export 子菜单
        self._export_menu = QMenu("Export", self)
        self._export_menu.setStyleSheet(self._files_menu.styleSheet())

        # Export JSON 动作
        self._export_json_action = QAction("Export JSON", self)
        self._export_json_action.triggered.connect(self._on_export_json)
        self._export_menu.addAction(self._export_json_action)

        # Export Python 动作
        self._export_python_action = QAction("Export Python", self)
        self._export_python_action.triggered.connect(self._on_export_python)
        self._export_menu.addAction(self._export_python_action)

        self._files_menu.addMenu(self._export_menu)

        # 连接按钮点击
        self._files_button.clicked.connect(self._show_files_menu)

        # JSON 文件路径记录
        self._json_file_path: Optional[str] = None

        layout.addWidget(self._files_button)

        # Edit 菜单按钮
        self._edit_button = QPushButton("Edit")
        self._edit_button.setFixedHeight(26)
        self._edit_button.setStyleSheet(self._files_button.styleSheet())

        # 创建 Edit 下拉菜单
        self._edit_menu = QMenu(self)
        self._edit_menu.setStyleSheet(self._files_menu.styleSheet())

        # Undo 操作
        self._undo_action = QAction("Undo", self)
        self._undo_action.triggered.connect(self._on_undo)
        self._undo_action.setEnabled(False)
        self._edit_menu.addAction(self._undo_action)

        # Redo 操作
        self._redo_action = QAction("Redo", self)
        self._redo_action.triggered.connect(self._on_redo)
        self._redo_action.setEnabled(False)
        self._edit_menu.addAction(self._redo_action)

        # 连接按钮点击
        self._edit_button.clicked.connect(self._show_edit_menu)

        # 连接菜单显示信号，更新菜单项状态
        self._edit_menu.aboutToShow.connect(self._update_edit_menu)

        layout.addWidget(self._edit_button)

        # API 菜单按钮
        self._api_button = QPushButton("API")
        self._api_button.setFixedHeight(26)
        self._api_button.setStyleSheet(self._files_button.styleSheet())

        # 创建 API 下拉菜单
        self._api_menu = QMenu(self)
        self._api_menu.setStyleSheet(self._files_menu.styleSheet())
        self._setup_api_menu()

        # 连接按钮点击
        self._api_button.clicked.connect(self._show_api_menu)

        layout.addWidget(self._api_button)

        # AI 菜单按钮
        self._ai_button = QPushButton("AI")
        self._ai_button.setFixedHeight(26)
        self._ai_button.setStyleSheet(self._files_button.styleSheet())

        # 创建 AI 下拉菜单
        self._ai_menu = QMenu(self)
        self._ai_menu.setStyleSheet(self._files_menu.styleSheet())

        # Config 操作
        self._config_action = QAction("Config", self)
        self._config_action.triggered.connect(self._on_open_config)
        self._ai_menu.addAction(self._config_action)

        # 分隔线
        self._ai_menu.addSeparator()

        # GUI 操作
        self._gui_action = QAction("GUI", self)
        self._gui_action.triggered.connect(self._on_open_gui)
        self._ai_menu.addAction(self._gui_action)

        # 连接按钮点击
        self._ai_button.clicked.connect(self._show_ai_menu)

        # AI GUI 窗口引用
        self._ai_gui_window = None

        # AI GUI 嵌入状态
        self._ai_gui_embedded = False

        # 连接菜单显示信号，更新菜单项状态
        self._ai_menu.aboutToShow.connect(self._update_ai_menu)

        layout.addWidget(self._ai_button)
        layout.addStretch()

    def _show_files_menu(self):
        """显示 Files 下拉菜单"""
        # 在按钮下方显示菜单
        pos = self._files_button.mapToGlobal(self._files_button.rect().bottomLeft())
        self._files_menu.exec(pos)

    def _show_api_menu(self):
        """显示 API 下拉菜单"""
        pos = self._api_button.mapToGlobal(self._api_button.rect().bottomLeft())
        self._api_menu.exec(pos)

    def _show_ai_menu(self):
        """显示 AI 下拉菜单"""
        pos = self._ai_button.mapToGlobal(self._ai_button.rect().bottomLeft())
        self._ai_menu.exec(pos)

    def _show_edit_menu(self):
        """显示 Edit 下拉菜单"""
        pos = self._edit_button.mapToGlobal(self._edit_button.rect().bottomLeft())
        self._edit_menu.exec(pos)

    def _update_edit_menu(self):
        """更新 Edit 菜单项状态"""
        can_undo = self._canvas.can_undo()
        can_redo = self._canvas.can_redo()

        self._undo_action.setEnabled(can_undo)
        self._redo_action.setEnabled(can_redo)

        # 更新显示文本
        if can_undo:
            self._undo_action.setText("Undo")
        else:
            self._undo_action.setText("Undo (无操作)")

        if can_redo:
            self._redo_action.setText("Redo")
        else:
            self._redo_action.setText("Redo (无操作)")

    def _on_undo(self):
        """执行 Undo"""
        success = self._canvas.undo()
        print(f"[DEBUG] _on_undo result: {success}")

    def _on_redo(self):
        """执行 Redo"""
        success = self._canvas.redo()
        print(f"[DEBUG] _on_redo result: {success}")

    def _on_open_config(self):
        """打开 AI 配置对话框"""
        try:
            from ai.qsettings import show_settings_dialog
            show_settings_dialog(parent=self)
        except Exception as e:
            print(f"Failed to open AI Config: {e}")
            import traceback
            traceback.print_exc()
            QMessageBox.critical(self, "Error", f"Failed to open AI Config: {e}")

    def _update_ai_menu(self):
        """更新 AI 菜单项状态"""
        # 检查 AI GUI 是否显示
        is_visible = self._check_ai_gui_visible()
        if is_visible:
            self._gui_action.setText("● GUI")
        else:
            self._gui_action.setText("GUI")

    def _check_ai_gui_visible(self) -> bool:
        """检查 AI GUI 是否可见"""
        # 首先检查嵌入模式
        parent = self.parent()
        if parent and hasattr(parent, '_ai_gui') and parent._ai_gui:
            # 检查分割器中的 AI GUI 是否可见
            if hasattr(parent, '_splitter'):
                ai_gui = parent._ai_gui
                return ai_gui.isVisible() and ai_gui.width() > 100
        # 然后检查独立窗口模式
        if self._ai_gui_window is not None and self._ai_gui_window.isVisible():
            return True
        return False

    def set_ai_gui_visible(self, visible: bool):
        """设置 AI GUI 可见状态（供外部调用）"""
        self._ai_gui_embedded = visible

    def _setup_api_menu(self):
        """设置 API 菜单"""
        # Get 类型功能 - 直接打印到控制台
        get_menu = QMenu("Get", self)
        get_menu.setStyleSheet(self._files_menu.styleSheet())

        get_graph_action = QAction("Get Graph", self)
        get_graph_action.triggered.connect(self._on_get_graph)
        get_menu.addAction(get_graph_action)

        get_code_action = QAction("Get Generated Code", self)
        get_code_action.triggered.connect(self._on_get_generated_code)
        get_menu.addAction(get_code_action)

        get_node_action = QAction("Get Node", self)
        get_node_action.triggered.connect(self._on_get_node)
        get_menu.addAction(get_node_action)

        get_class_action = QAction("Get Class", self)
        get_class_action.triggered.connect(self._on_get_class)
        get_menu.addAction(get_class_action)

        get_all_nodes_action = QAction("Get All Nodes", self)
        get_all_nodes_action.triggered.connect(self._on_get_all_nodes)
        get_menu.addAction(get_all_nodes_action)

        get_menu.addSeparator()

        # 检查图合理性
        get_validity_action = QAction("Get Validity", self)
        get_validity_action.triggered.connect(self._on_get_validity)
        get_menu.addAction(get_validity_action)

        self._api_menu.addMenu(get_menu)

        # Set 类型功能 - 弹出对话框输入
        set_menu = QMenu("Set", self)
        set_menu.setStyleSheet(self._files_menu.styleSheet())

        set_node_action = QAction("Set Node", self)
        set_node_action.triggered.connect(self._on_set_node)
        set_menu.addAction(set_node_action)

        set_class_action = QAction("Set Class", self)
        set_class_action.triggered.connect(self._on_set_class)
        set_menu.addAction(set_class_action)

        self._api_menu.addMenu(set_menu)

        # Layout 子菜单
        self._api_menu.addSeparator()
        layout_menu = QMenu("Layout", self)
        layout_menu.setStyleSheet(self._files_menu.styleSheet())

        check_overlaps_action = QAction("Check Overlaps", self)
        check_overlaps_action.triggered.connect(self._on_check_overlaps)
        layout_menu.addAction(check_overlaps_action)

        check_viewport_action = QAction("Check Viewport", self)
        check_viewport_action.triggered.connect(self._on_check_viewport)
        layout_menu.addAction(check_viewport_action)

        layout_menu.addSeparator()

        auto_layout_menu = QMenu("Auto Layout", self)
        auto_layout_menu.setStyleSheet(self._files_menu.styleSheet())

        layout_compact_action = QAction("Compact", self)
        layout_compact_action.triggered.connect(lambda: self._on_auto_layout("compact"))
        auto_layout_menu.addAction(layout_compact_action)

        layout_circular_action = QAction("Circular", self)
        layout_circular_action.triggered.connect(lambda: self._on_auto_layout("circular"))
        auto_layout_menu.addAction(layout_circular_action)

        layout_grid_action = QAction("Grid", self)
        layout_grid_action.triggered.connect(lambda: self._on_auto_layout("grid"))
        auto_layout_menu.addAction(layout_grid_action)

        layout_hierarchical_action = QAction("Hierarchical", self)
        layout_hierarchical_action.triggered.connect(lambda: self._on_auto_layout("hierarchical"))
        auto_layout_menu.addAction(layout_hierarchical_action)

        layout_force_action = QAction("Force Directed", self)
        layout_force_action.triggered.connect(lambda: self._on_auto_layout("force"))
        auto_layout_menu.addAction(layout_force_action)

        layout_menu.addMenu(auto_layout_menu)

        # Zoom to Fit 作为 Layout 子菜单下的独立设置项
        fit_viewport_action = QAction("Zoom to Fit", self)
        fit_viewport_action.triggered.connect(self._on_fit_viewport)
        layout_menu.addAction(fit_viewport_action)

        self._api_menu.addMenu(layout_menu)

    def _get_api(self):
        """获取 CanvasAPI 实例"""
        from ai.canvas_api import CanvasAPI
        return CanvasAPI(self._canvas)

    def _on_open_gui(self):
        """打开 AI GUI - 使用嵌入到主窗口的方式"""
        try:
            # 获取父窗口（NodeCanvasWindow）
            parent = self.parent()
            if parent and hasattr(parent, 'toggle_ai_gui'):
                # 调用主窗口的方法显示 AI GUI
                parent.toggle_ai_gui(visible=True)
            else:
                # 如果父窗口没有该方法，回退到独立窗口模式
                self._open_gui_standalone()
        except Exception as e:
            print(f"Failed to open AI GUI: {e}")
            import traceback
            traceback.print_exc()
            QMessageBox.critical(self, "Error", f"Failed to open AI GUI: {e}")

    def _open_gui_standalone(self):
        """打开独立的 AI GUI 窗口（回退方案）"""
        from ai.ai_gui import QChatWidget
        from ai.canvas_api import CanvasAPI
        from ai.canvas_tools import create_tool_executor, get_tool_definitions

        # 如果窗口已存在且可见，则激活它
        if self._ai_gui_window is not None:
            if self._ai_gui_window.isVisible():
                self._ai_gui_window.activateWindow()
                self._ai_gui_window.raise_()
                return
            else:
                self._ai_gui_window = None

        # 创建 CanvasAPI 实例和工具
        canvas_api = CanvasAPI(self._canvas)
        tool_definitions = get_tool_definitions(include_psa=True)
        tool_executor = create_tool_executor(canvas_api, include_psa=True)

        # 创建并显示新的 AI GUI 窗口
        self._ai_gui_window = QChatWidget(
            canvas=self._canvas,
            tool_definitions=tool_definitions,
            tool_executor=tool_executor
        )
        self._ai_gui_window.show()

    # ==================== Get 类型功能 ====================

    def _on_get_graph(self):
        """获取完整图数据"""
        try:
            api = self._get_api()
            data = api.get_graph()
            # 使用 JsonEdit 显示结果
            dialog = JsonEditorFactory.create_dialog(self, data=data)
            dialog.setWindowTitle("Graph Data")
            dialog.btn_cancel.hide()
            dialog.btn_ok.setText("Close")
            dialog.exec()
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Get Graph failed: {e}")

    def _on_get_generated_code(self):
        """获取生成的 Python 代码"""
        try:
            api = self._get_api()
            code = api.get_generated_code()
            # 使用 pyedit 显示生成的 Python 代码
            dialog = QDialog(self)
            dialog.setWindowTitle("Generated Python Code")
            dialog.setMinimumSize(900, 700)

            layout = QVBoxLayout(dialog)
            layout.setContentsMargins(0, 0, 0, 0)

            # 创建 PythonEditor
            from pyedit import PythonEditor
            editor = PythonEditor()
            editor.set_code(code)
            layout.addWidget(editor)

            # 添加关闭按钮
            btn_box = QDialogButtonBox(QDialogButtonBox.StandardButton.Close)
            btn_box.rejected.connect(dialog.reject)
            layout.addWidget(btn_box)

            dialog.exec()
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Get Generated Code failed: {e}")

    def _on_get_node(self):
        """获取节点数据 - 弹出对话框输入节点ID"""
        node_id_str, ok = QInputDialog.getText(self, "Get Node", "Enter Node ID:")
        if not ok or not node_id_str:
            return
        try:
            node_id = int(node_id_str)
            api = self._get_api()
            data = api.get_node(node_id)
            # 使用 JsonEdit 显示结果
            if data is None:
                data = {"error": f"Node {node_id} not found"}
            dialog = JsonEditorFactory.create_dialog(self, data=data)
            dialog.setWindowTitle(f"Node {node_id} Data")
            dialog.btn_cancel.hide()
            dialog.btn_ok.setText("Close")
            dialog.exec()
        except ValueError:
            QMessageBox.warning(self, "Warning", "Node ID must be an integer")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Get Node failed: {e}")

    def _on_get_class(self):
        """获取类数据"""
        try:
            api = self._get_api()
            data = api.get_class()
            # 使用 JsonEdit 显示结果
            if data is None:
                data = {"error": "No class data"}
            dialog = JsonEditorFactory.create_dialog(self, data=data)
            dialog.setWindowTitle("Class Data")
            dialog.btn_cancel.hide()
            dialog.btn_ok.setText("Close")
            dialog.exec()
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Get Class failed: {e}")

    def _on_get_all_nodes(self):
        """获取所有节点列表"""
        try:
            api = self._get_api()
            data = api.get_all_nodes()
            # 使用 JsonEdit 显示结果
            dialog = JsonEditorFactory.create_dialog(self, data=data)
            dialog.setWindowTitle("All Nodes")
            dialog.btn_cancel.hide()
            dialog.btn_ok.setText("Close")
            dialog.exec()
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Get All Nodes failed: {e}")

    # ==================== Set 类型功能 ====================

    def _on_set_node(self):
        """设置节点数据 - 弹出对话框输入 JSON"""
        dialog = JsonInputDialog(self, "Set Node", "Enter node JSON data (must contain 'id' field):")
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return

        json_text = dialog.get_text()
        if not json_text:
            return

        try:
            data = json.loads(json_text)
            api = self._get_api()
            error = api.set_node(data)
            if error:
                QMessageBox.warning(self, "Warning", f"Set Node failed: {error}")
            else:
                print(f"Set Node: Success")
                QMessageBox.information(self, "Success", "Node updated successfully")
        except json.JSONDecodeError as e:
            QMessageBox.warning(self, "Warning", f"Invalid JSON: {e}")
        except Exception as e:
            print(f"Set Node failed: {e}")
            QMessageBox.critical(self, "Error", f"Set Node failed: {e}")

    def _on_set_class(self):
        """设置类数据 - 弹出对话框输入 JSON"""
        dialog = JsonInputDialog(self, "Set Class", "Enter class JSON data:")
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return

        json_text = dialog.get_text()
        if not json_text:
            return

        try:
            data = json.loads(json_text)
            api = self._get_api()
            error = api.set_class(data)
            if error:
                QMessageBox.warning(self, "Warning", f"Set Class failed: {error}")
            else:
                QMessageBox.information(self, "Success", "Class updated successfully")
        except json.JSONDecodeError as e:
            QMessageBox.warning(self, "Warning", f"Invalid JSON: {e}")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Set Class failed: {e}")

    # ==================== Layout 功能 ====================

    def _on_check_overlaps(self):
        """检查图元重叠情况"""
        try:
            api = self._get_api()
            result = api.check_overlaps()

            # 显示结果对话框
            if result['has_overlaps']:
                msg = f"Found {result['overlap_count']} overlaps.\n\n"
                msg += f"Node-Node: {result['summary'].get('node_node', 0)}\n"
                msg += f"Node-Connection: {result['summary'].get('node_connection', 0)}\n"
                msg += f"Connection-Connection: {result['summary'].get('connection_connection', 0)}\n"
                msg += f"Node-Root: {result['summary'].get('node_root', 0)}\n"
                msg += f"Root-Root: {result['summary'].get('root_root', 0)}\n"
                msg += f"Connection-Root: {result['summary'].get('connection_root', 0)}"
                QMessageBox.information(self, "Overlap Check Result", msg)
            else:
                QMessageBox.information(self, "Overlap Check Result", "No overlaps found!")

        except Exception as e:
            QMessageBox.critical(self, "Error", f"Check Overlaps failed: {e}")

    def _on_auto_layout(self, strategy: str):
        """自动布局"""
        try:
            api = self._get_api()
            result = api.auto_layout(strategy)

            if result['success']:
                QMessageBox.information(
                    self,
                    "Layout Complete",
                    f"Layout strategy: {strategy}\n"
                    f"Nodes: {result['node_count']}\n"
                    f"Roots: {result['root_count']}"
                )
            else:
                error_msg = result.get('error', 'Unknown error')
                QMessageBox.warning(self, "Layout Failed", f"Auto layout failed:\n{error_msg}")

        except Exception as e:
            QMessageBox.critical(self, "Error", f"Auto Layout failed: {e}")

    def _on_fit_viewport(self):
        """自动适配视口"""
        try:
            api = self._get_api()
            result = api.fit_viewport(min_scale=0.5, max_scale=1.6, padding_ratio=0.1)

            if result['success']:
                center = result['center']
                QMessageBox.information(
                    self,
                    "Viewport Fitted",
                    f"视口已自动适配\n\n"
                    f"缩放比例: {result['scale']:.2f}\n"
                    f"质心位置: ({center['x']:.1f}, {center['y']:.1f})\n"
                    f"节点数: {result['node_count']}\n"
                    f"类定义数: {result['root_count']}"
                )
            else:
                error_msg = result.get('error', 'Unknown error')
                QMessageBox.warning(self, "Fit Failed", f"视口适配失败:\n{error_msg}")

        except Exception as e:
            QMessageBox.critical(self, "Error", f"视口适配失败: {e}")

    def _on_check_viewport(self):
        """检查视口是否合适"""
        try:
            api = self._get_api()
            result = api.check_viewport()

            if result['success']:
                ok_status = "✓ 合理" if result['ok'] else "✗ 不合理"
                center_status = "✓" if result['center_ok'] else "✗"
                scale_status = "✓" if result['scale_ok'] else "✗"

                QMessageBox.information(
                    self,
                    "Viewport Check Result",
                    f"视口检查结果: {ok_status}\n\n"
                    f"中心偏差: {result['center_offset']:.1f} 像素\n"
                    f"  {center_status} 中心位置: {'合理' if result['center_ok'] else '超出阈值'}\n\n"
                    f"缩放偏差: {result['scale_offset']*100:+.1f}%\n"
                    f"  {scale_status} 缩放比例: {'合理' if result['scale_ok'] else '超出范围'}"
                )
            else:
                error_msg = result.get('error', 'Unknown error')
                QMessageBox.warning(self, "Check Failed", f"视口检查失败:\n{error_msg}")

        except Exception as e:
            QMessageBox.critical(self, "Error", f"视口检查失败: {e}")

    def _on_get_validity(self):
        """检查图的合理性"""
        try:
            api = self._get_api()
            result = api.get_validity()

            if result['success']:
                validity = result['合理性']
                errors = result['错误列表']
                suggestions = result['建议列表']

                # 构建消息
                if validity == "完全合理":
                    icon = QMessageBox.Icon.Information
                    title = "合理性检查通过"
                    msg = "✅ 完全合理\n\n所有检查项均通过！"
                elif validity == "基本合理":
                    icon = QMessageBox.Icon.Warning
                    title = "合理性检查 - 建议改进"
                    msg = "⚠️ 基本合理\n\n关键检查通过，但以下建议可进一步改进:\n"
                    for suggestion in suggestions:
                        msg += f"\n• {suggestion}"
                else:  # 不合理
                    icon = QMessageBox.Icon.Critical
                    title = "合理性检查失败"
                    msg = "❌ 不合理\n\n存在以下问题需要修复:\n"
                    for error in errors:
                        msg += f"\n• {error}"

                # 构建详细信息文本
                details = []
                for check_name, check_result in result['详情'].items():
                    status = "✓" if check_result['通过'] else "✗"
                    details.append(f"{status} {check_name}: {check_result['描述']}")

                # 显示详细信息对话框
                msg_box = QMessageBox(self)
                msg_box.setIcon(icon)
                msg_box.setWindowTitle(title)

                # 如果有详细信息，添加到消息中
                if details:
                    detailed_info = "\n".join(details)
                    full_msg = f"{msg}\n\n详细检查项:\n{detailed_info}"
                    msg_box.setText(full_msg)
                else:
                    msg_box.setText(msg)

                msg_box.setStandardButtons(QMessageBox.StandardButton.Ok)
                msg_box.exec()
            else:
                error_msg = result.get('error', 'Unknown error')
                QMessageBox.warning(self, "Check Failed", f"合理性检查失败:\n{error_msg}")

        except Exception as e:
            QMessageBox.critical(self, "Error", f"合理性检查失败: {e}")

    def _apply_style(self):
        """应用样式"""
        self.setStyleSheet("""
            MenuBar {
                background-color: #f5f5f5;
                border-bottom: 1px solid #cccccc;
            }
        """)

    # ==================== New 功能 ====================

    def _check_unsaved_changes(self) -> bool:
        """
        检查是否有未保存的修改，如有则询问用户

        注意：在检查前会先保存所有打开的 edit 窗口

        Returns:
            True: 可以继续操作（已保存或无需保存）
            False: 用户取消操作
        """
        # 先保存所有打开的 edit 窗口（这可能会改变 changed 状态）
        self._canvas.save_all_edit_windows()

        if not self._canvas.changed:
            return True

        # 临时取消所有 edit 窗口的置顶，确保对话框不被遮挡
        self._canvas.set_edit_windows_stay_on_top(False)

        reply = QMessageBox.question(
            self,
            "Unsaved Changes",
            "The graph has unsaved changes. Do you want to save?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No | QMessageBox.StandardButton.Cancel,
            QMessageBox.StandardButton.Yes
        )

        if reply == QMessageBox.StandardButton.Yes:
            # 用户选择保存
            result = self._perform_save()
            if not result:
                # 保存失败或取消，恢复 edit 窗口置顶
                self._canvas.set_edit_windows_stay_on_top(True)
            return result
        elif reply == QMessageBox.StandardButton.Cancel:
            # 用户选择取消，恢复 edit 窗口置顶
            self._canvas.set_edit_windows_stay_on_top(True)
            return False
        # 用户选择 No，继续操作（不恢复置顶，因为接下来会关闭 edit 窗口）
        return True

    def _perform_save(self) -> bool:
        """
        执行保存操作

        Returns:
            True: 保存成功或已有路径直接保存
            False: 保存失败或用户取消
        """
        if self._json_file_path:
            # 已有路径，直接覆盖保存
            try:
                json_content = self._canvas.export(filter_empty=True)
                with open(self._json_file_path, 'w', encoding='utf-8') as f:
                    f.write(json_content)
                # Save 成功，重置 changed 状态并更新文件路径
                self._canvas.set_json_file_path(self._json_file_path)
                self._canvas.reset_changed_state()
                return True
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Save failed: {e}")
                return False
        else:
            # 没有路径，调用 Save As
            return self._perform_save_as()

    def _perform_save_as(self) -> bool:
        """
        执行另存为操作

        Returns:
            True: 保存成功
            False: 保存失败或用户取消
        """
        # 如果有记录的路径，使用它作为起始目录
        start_dir = self._json_file_path if self._json_file_path else ""

        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "Save JSON As",
            start_dir,
            "JSON Files (*.json);;All Files (*.*)"
        )

        if file_path:
            try:
                json_content = self._canvas.export(filter_empty=True)
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(json_content)
                # 记录保存路径并更新画布
                self._json_file_path = file_path
                self._canvas.set_json_file_path(file_path)
                self._canvas.reset_changed_state()
                return True
            except Exception as e:
                QMessageBox.critical(self, "Error", f"Save failed: {e}")
                return False
        return False

    def _on_new_graph(self):
        """新建画布"""
        try:
            # 检查是否有未保存的修改（会先保存所有 edit 窗口）
            if not self._check_unsaved_changes():
                return  # 用户取消

            # 关闭所有 edit 窗口
            self._canvas.close_all_edit_windows()

            # 创建新的空画布并替换当前画布
            from .node_canvas import NodeCanvas
            new_canvas = NodeCanvas()

            # 新画布没有未保存的修改
            new_canvas.clear_action_stack()

            self._canvas_imported(new_canvas, reset_ai=True)
            self._json_file_path = None
        except Exception as e:
            QMessageBox.critical(self, "Error", f"New graph failed: {e}")

    def _on_new_node(self):
        """在画布中心新建节点"""
        try:
            default_name = f"节点{len(self._canvas._nodes) + 1}"
            viewport_rect = self._canvas.viewport().rect()
            center_pos = self._canvas.mapToScene(viewport_rect.center())
            self._canvas.add_node(default_name, center_pos)
        except Exception as e:
            QMessageBox.critical(self, "Error", f"New node failed: {e}")

    # ==================== Load/Save 功能 ====================

    def _on_load(self):
        """加载 JSON 文件，记录打开位置"""
        # 检查是否有未保存的修改（会先保存所有 edit 窗口）
        if not self._check_unsaved_changes():
            return  # 用户取消

        # 如果有记录的路径，使用它作为起始目录
        start_dir = self._json_file_path if self._json_file_path else ""

        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Load JSON",
            start_dir,
            "JSON Files (*.json);;All Files (*.*)"
        )

        if file_path:
            try:
                # 关闭所有 edit 窗口
                self._canvas.close_all_edit_windows()

                with open(file_path, 'r', encoding='utf-8') as f:
                    json_content = f.read()

                # 导入到画布
                from .node_canvas import NodeCanvas
                new_canvas = NodeCanvas.Import(json_content)

                # 设置文件路径（在替换画布之前）
                new_canvas.set_json_file_path(file_path)
                # 加载的文件不算作有修改
                new_canvas.clear_action_stack()

                # 触发导入完成，让主窗口替换画布（重置AI对话）
                self._canvas_imported(new_canvas, reset_ai=True)

                # 记录打开位置
                self._json_file_path = file_path

            except Exception as e:
                QMessageBox.critical(self, "Error", f"Load failed: {e}")

    def _on_save(self):
        """保存 JSON 文件，如果有记录的路径直接覆盖，否则询问"""
        self._perform_save()

    def _on_save_as(self):
        """另存为 JSON 文件，固定询问位置"""
        self._perform_save_as()

    def _on_export_json(self):
        """导出 JSON（保留兼容性的独立导出功能）"""
        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "Export to JSON",
            "",
            "JSON Files (*.json);;All Files (*.*)"
        )

        if file_path:
            try:
                json_content = self._canvas.export(filter_empty=True)
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(json_content)
            except Exception as e:
                pass

    def _on_export_python(self):
        """处理 Export Python 动作 - 将所有节点和ROOT导出为Python代码"""
        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "Export to Python",
            "",
            "Python Files (*.py);;All Files (*.*)"
        )

        if file_path:
            try:
                # 生成Python代码
                python_code = self._generate_python_code()

                # 保存到文件
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(python_code)

            except Exception as e:
                QMessageBox.critical(self, "Error", f"Export failed: {e}")

    def _generate_python_code(self) -> str:
        """
        生成完整的Python代码文件
        节点函数作为ROOT类的方法导出
        """
        lines: List[str] = []

        # 添加文件头
        lines.append("# Generated Python Code from Node Canvas")
        lines.append("# ====================================")
        lines.append("")

        # 1. 添加导入语句
        lines.append("from builtin import *")
        lines.append("")

        # 2. 导出ROOT类（包含节点函数作为方法）
        if hasattr(self._canvas, '_root_items') and self._canvas._root_items:
            # 使用第一个ROOT作为主类
            root = self._canvas._root_items[0]
            root_code = self._generate_root_class_with_methods(root)
            lines.append(root_code)
        else:
            # 没有ROOT时，导出为独立函数
            lines.append("# ==================== Node Functions ====================")
            lines.append("")
            for node in getattr(self._canvas, '_nodes_creation_order', []):
                node_code = self._generate_node_function_standalone(node)
                if node_code:
                    lines.append(node_code)
                    lines.append("")

        return "\n".join(lines)

    def _generate_root_class_with_methods(self, root) -> str:
        """生成ROOT类的Python代码，包含所有节点函数作为方法"""
        lines: List[str] = []

        # 获取类名和逻辑类型
        class_name = root.name
        logic_type = getattr(root, 'logic_type', 'CreepLogic')

        # 类定义行
        lines.append(f"class {class_name}({logic_type}):")

        # 获取类设置定义和当前值
        class_settings_def = getattr(root, 'class_settings', [])
        class_settings_values = getattr(root, 'class_settings_values', {})

        # 创建设置定义的字典（name -> default）
        settings_defaults = {s['name']: s.get('default') for s in class_settings_def}

        # 添加 NAME 属性（必导出，与类同名但不能以数字结尾）
        # 去除类名末尾的数字
        base_name = class_name.rstrip('0123456789')
        if not base_name:  # 如果类名全是数字，使用默认名称
            base_name = 'MyClass'
        lines.append(f"    NAME = '{base_name}'")

        # 导出与默认值不同的属性
        for attr_name, attr_value in class_settings_values.items():
            if attr_name == 'NAME':
                # NAME 已经处理了，跳过
                continue
            if attr_value is None or attr_value == '':
                # 空值不导出
                continue

            # 获取默认值
            default_value = settings_defaults.get(attr_name)

            # 如果当前值与默认值不同，则导出
            if attr_value != default_value:
                if isinstance(attr_value, str):
                    lines.append(f"    {attr_name} = '{attr_value}'")
                else:
                    lines.append(f"    {attr_name} = {attr_value}")

        # 获取类内容
        class_contents = getattr(root, 'class_contents', {})

        # 类文档（如果不是默认值则导出）
        DEFAULT_CLASS_DOC = '"""\n这是一个注释\n"""'
        doc_content = class_contents.get('__doc__', '').strip()
        if doc_content and doc_content != DEFAULT_CLASS_DOC:
            lines.append('    """')
            for line in doc_content.split('\n'):
                lines.append(f"    {line}")
            lines.append('    """')

        # 添加类定义内容 (__cdef__)
        cdef_content = class_contents.get('__cdef__', '').strip()
        if cdef_content:
            for line in cdef_content.split('\n'):
                if line.strip():
                    lines.append(f"    {line}")
                else:
                    lines.append("")

        # 添加空行（如果有任何类属性）
        if len(lines) > 1:
            lines.append("")

        # 添加节点函数作为类方法
        if hasattr(self._canvas, '_nodes_creation_order') and self._canvas._nodes_creation_order:
            lines.append("    # ==================== Node Functions ====================")
            lines.append("")

            for node in self._canvas._nodes_creation_order:
                method_code = self._generate_node_method(node)
                if method_code:
                    # 缩进方法代码（类体内）
                    indented_lines = []
                    for line in method_code.split('\n'):
                        if line.strip():
                            indented_lines.append(f"    {line}")
                        else:
                            indented_lines.append("")
                    lines.extend(indented_lines)
                    lines.append("")

        # 如果没有内容，添加pass
        if len(lines) == 1:  # 只有类定义行
            lines.append("    pass")

        return "\n".join(lines)

    def _generate_node_method(self, node) -> str:
        """生成节点作为类方法的Python代码"""
        connection_texts = getattr(node, '_connection_texts', {}) or {}
        safe_name = getattr(node, 'safe_name', node.name.replace(' ', '_'))

        lines: List[str] = []

        # 获取连接顺序
        connection_order = getattr(node, '_connection_order', [])
        all_connections = getattr(node, '_connections', [])

        ordered_connections = []
        for target in connection_order:
            if target in all_connections:
                ordered_connections.append(target)
        for target in all_connections:
            if target not in ordered_connections:
                ordered_connections.append(target)

        # 方法定义（带self参数）
        # 如果是 recursive 节点，添加装饰器
        if getattr(node, 'is_recursive', False):
            lines.append(f"@recursive")
        lines.append(f"def {safe_name}(self, c: Creep, k: GlobalKnowledge, *refs):")

        # 文档字符串（如果不是默认值则导出）
        DEFAULT_DOC = '"""\n这是一个注释\n"""'
        doc_text = connection_texts.get('__doc__', '').strip()
        if doc_text and doc_text != DEFAULT_DOC:
            lines.append('    """')
            for line in doc_text.split('\n'):
                lines.append(f"    {line}")
            lines.append('    """')

        # 进入节点代码
        begin_text = connection_texts.get('__begin__', '').strip()
        if begin_text:
            # 添加标记注释（去除原有缩进，统一添加4空格）
            import textwrap
            dedented_begin = textwrap.dedent(begin_text)
            lines.append("    # $Begin:begin")
            for line in dedented_begin.split('\n'):
                lines.append(f"    {line}")
            lines.append("    # $End:begin")

        # 连接处理 - 为所有连接生成子函数
        if ordered_connections:
            for target_node in ordered_connections:
                conn_key = f"conn_{id(target_node)}"
                conn_text = connection_texts.get(conn_key, '').strip()
                target_safe_name = getattr(target_node, 'safe_name', target_node.name.replace(' ', '_'))

                lines.append(f"")
                lines.append(f"    def _to_{target_safe_name}():")

                if conn_text:
                    lines.append(f"        # $Begin:{target_node.name}")
                    # 处理连接代码的缩进：去除原有缩进，统一添加8空格
                    import textwrap
                    dedented_text = textwrap.dedent(conn_text)
                    for line in dedented_text.split('\n'):
                        lines.append(f"        {line}")
                    lines.append(f"        # $End:{target_node.name}")
                else:
                    lines.append(f"        # $Begin:{target_node.name}")
                    lines.append(f"        pass")
                    lines.append(f"        # $End:{target_node.name}")

            # 生成 if-elif 调用链
            lines.append("")
            for i, target_node in enumerate(ordered_connections):
                target_safe_name = getattr(target_node, 'safe_name', target_node.name.replace(' ', '_'))

                if i == 0:
                    prefix = "if"
                else:
                    prefix = "elif"

                lines.append(f"    {prefix} _to_{target_safe_name}():")
                lines.append(f"        return \"{target_safe_name}\"")

        # 退出节点代码
        end_text = connection_texts.get('__end__', '').strip()
        if end_text:
            lines.append("")
            lines.append("    # $Begin:end")
            for line in end_text.split('\n'):
                lines.append(f"    {line}")

        # 如果没有内容，添加pass
        if len(lines) <= 1:
            lines.append("    pass")

        return "\n".join(lines)

    def _generate_root_class(self, root) -> str:
        """生成ROOT类的Python代码（不包含方法）"""
        lines: List[str] = []

        class_name = root.name
        logic_type = getattr(root, 'logic_type', 'CreepLogic')

        lines.append(f"class {class_name}({logic_type}):")

        # 获取类设置定义和当前值
        class_settings_def = getattr(root, 'class_settings', [])
        class_settings_values = getattr(root, 'class_settings_values', {})

        # 创建设置定义的字典（name -> default）
        settings_defaults = {s['name']: s.get('default') for s in class_settings_def}

        # 添加 NAME 属性（必导出，与类同名但不能以数字结尾）
        base_name = class_name.rstrip('0123456789')
        if not base_name:
            base_name = 'MyClass'
        lines.append(f"    NAME = '{base_name}'")

        # 导出与默认值不同的属性
        for attr_name, attr_value in class_settings_values.items():
            if attr_name == 'NAME':
                continue
            if attr_value is None or attr_value == '':
                continue

            # 获取默认值
            default_value = settings_defaults.get(attr_name)

            # 如果当前值与默认值不同，则导出
            if attr_value != default_value:
                if isinstance(attr_value, str):
                    lines.append(f"    {attr_name} = '{attr_value}'")
                else:
                    lines.append(f"    {attr_name} = {attr_value}")

        class_contents = getattr(root, 'class_contents', {})

        # 类文档（如果不是默认值则导出）
        DEFAULT_CLASS_DOC = '"""\n这是一个注释\n"""'
        doc_content = class_contents.get('__doc__', '').strip()
        if doc_content and doc_content != DEFAULT_CLASS_DOC:
            lines.append('    """')
            for line in doc_content.split('\n'):
                lines.append(f"    {line}")
            lines.append('    """')

        cdef_content = class_contents.get('__cdef__', '').strip()
        if cdef_content:
            for line in cdef_content.split('\n'):
                if line.strip():
                    lines.append(f"    {line}")
                else:
                    lines.append("")

        if len(lines) == 1:
            lines.append("    pass")

        return "\n".join(lines)

    def _generate_node_function_standalone(self, node) -> str:
        """生成节点函数的Python代码"""
        # 获取节点的代码内容（确保总是返回字典）
        connection_texts = getattr(node, '_connection_texts', {}) or {}

        safe_name = getattr(node, 'safe_name', node.name.replace(' ', '_'))

        lines: List[str] = []

        # 获取连接顺序
        connection_order = getattr(node, '_connection_order', [])
        all_connections = getattr(node, '_connections', [])

        # 按顺序排列连接
        ordered_connections = []
        for target in connection_order:
            if target in all_connections:
                ordered_connections.append(target)
        for target in all_connections:
            if target not in ordered_connections:
                ordered_connections.append(target)

        # 函数定义
        # 如果是 recursive 节点，添加装饰器
        if getattr(node, 'is_recursive', False):
            lines.append(f"@recursive")
        lines.append(f"def {safe_name}(c: Creep, k: GlobalKnowledge, *refs):")

        # 文档字符串（如果不是默认值则导出）
        DEFAULT_DOC = '"""\n这是一个注释\n"""'
        doc_text = connection_texts.get('__doc__', '').strip()
        if doc_text and doc_text != DEFAULT_DOC:
            lines.append('    """')
            for line in doc_text.split('\n'):
                lines.append(f"    {line}")
            lines.append('    """')

        # 进入节点代码
        begin_text = connection_texts.get('__begin__', '').strip()
        if begin_text:
            # 添加标记注释（去除原有缩进，统一添加4空格）
            import textwrap
            dedented_begin = textwrap.dedent(begin_text)
            lines.append("    # $Begin:begin")
            for line in dedented_begin.split('\n'):
                lines.append(f"    {line}")
            lines.append("    # $End:begin")

        # 连接处理 - 为所有连接生成子函数（即使没有内容也生成空函数）
        if ordered_connections:
            # 先生成所有子函数定义
            for target_node in ordered_connections:
                conn_key = f"conn_{id(target_node)}"
                conn_text = connection_texts.get(conn_key, '').strip()
                target_safe_name = getattr(target_node, 'safe_name', target_node.name.replace(' ', '_'))

                # 子函数定义（总是生成，即使没有内容）
                lines.append(f"")
                lines.append(f"    def _to_{target_safe_name}():")

                if conn_text:
                    # 有内容时添加标记和内容（去除原有缩进，统一添加4空格）
                    import textwrap
                    dedented_text = textwrap.dedent(conn_text)
                    lines.append(f"        # $Begin:{target_node.name}")
                    for line in dedented_text.split('\n'):
                        lines.append(f"        {line}")
                    lines.append(f"        # $End:{target_node.name}")
                else:
                    # 没有内容时添加pass占位
                    lines.append(f"        # $Begin:{target_node.name}")
                    lines.append(f"        pass")
                    lines.append(f"        # $End:{target_node.name}")

            # 生成 if-elif 调用链
            lines.append("")
            for i, target_node in enumerate(ordered_connections):
                target_safe_name = getattr(target_node, 'safe_name', target_node.name.replace(' ', '_'))

                if i == 0:
                    prefix = "if"
                else:
                    prefix = "elif"

                lines.append(f"    {prefix} _to_{target_safe_name}():")
                lines.append(f"        return \"{target_safe_name}\"")

        # 退出节点代码
        end_text = connection_texts.get('__end__', '').strip()
        if end_text:
            lines.append("")
            lines.append("    # $Begin:end")
            for line in end_text.split('\n'):
                lines.append(f"    {line}")

        # 如果没有内容，添加pass
        if len(lines) <= 1:  # 只有函数定义行
            lines.append("    pass")

        return "\n".join(lines)

    def _canvas_imported(self, new_canvas, reset_ai: bool = False):
        """导入完成后的处理 - 需要主窗口替换画布

        Args:
            new_canvas: 新的画布实例
            reset_ai: 是否重置 AI 对话（用于 new graph）
        """
        # 同步文件路径（从画布到菜单栏）
        self._json_file_path = new_canvas.get_json_file_path()

        # 这里通过父窗口来替换画布
        parent = self.parent()
        if parent and hasattr(parent, 'replace_canvas'):
            parent.replace_canvas(new_canvas, reset_ai=reset_ai)

    def set_geometry(self, x: int, y: int, width: int, height: int):
        """设置几何位置和大小"""
        self.setGeometry(x, y, width, height)
        self._hidden_y = -height
        self._visible_y = 0

    def eventFilter(self, obj, event):
        """事件过滤器 - 捕获父窗口的鼠标移动"""
        if event.type() == event.Type.MouseMove:
            # 转换鼠标位置到父窗口坐标系
            if self.parent():
                pos = self.parent().mapFromGlobal(event.globalPosition().toPoint())
                self.handle_mouse_move(pos)
        return super().eventFilter(obj, event)

    def handle_mouse_move(self, pos: QPoint):
        """
        处理鼠标移动事件

        Args:
            pos: 鼠标在父窗口中的位置
        """
        # 检查是否在触发区域 (x:0-400, y:0-50)
        in_trigger = (0 <= pos.x() <= 400) and (0 <= pos.y() <= 50)

        if in_trigger and not self._is_visible:
            self._show()
        elif not in_trigger and not self._mouse_in_menu and self._is_visible:
            # 启动隐藏定时器
            if not self._hide_timer.isActive():
                self._hide_timer.start(1000)  # 1秒后隐藏

        self._mouse_in_trigger_area = in_trigger

    def enterEvent(self, event):
        """鼠标进入菜单栏"""
        self._mouse_in_menu = True
        # 取消隐藏定时器
        if self._hide_timer.isActive():
            self._hide_timer.stop()
        super().enterEvent(event)

    def leaveEvent(self, event):
        """鼠标离开菜单栏"""
        self._mouse_in_menu = False
        # 启动隐藏定时器
        if self._is_visible and not self._mouse_in_trigger_area:
            if not self._hide_timer.isActive():
                self._hide_timer.start(1000)
        super().leaveEvent(event)

    def _show(self):
        """显示菜单栏（下滑动画）"""
        if self._is_visible:
            return

        self._is_visible = True

        # 停止可能正在运行的隐藏动画
        if self._animation.state() == QPropertyAnimation.State.Running:
            self._animation.stop()

        # 下滑动画
        self._animation.setStartValue(self.pos())
        self._animation.setEndValue(QPoint(self.x(), self._visible_y))
        self._animation.start()

    def _hide(self):
        """隐藏菜单栏（上滑动画）"""
        if not self._is_visible:
            return

        # 检查鼠标是否还在菜单栏内
        if self._mouse_in_menu:
            return

        self._is_visible = False

        # 停止可能正在运行的显示动画
        if self._animation.state() == QPropertyAnimation.State.Running:
            self._animation.stop()

        # 上滑动画
        self._animation.setStartValue(self.pos())
        self._animation.setEndValue(QPoint(self.x(), self._hidden_y))
        self._animation.start()


class JsonInputDialog(QDialog):
    """JSON 输入对话框"""

    def __init__(self, parent=None, title="Input", label="Enter JSON:"):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setMinimumWidth(400)
        self.setMinimumHeight(300)

        layout = QVBoxLayout(self)

        # 标签
        label_widget = QLabel(label)
        layout.addWidget(label_widget)

        # 文本编辑区
        self._text_edit = QTextEdit()
        self._text_edit.setPlaceholderText('{"key": "value"}')
        layout.addWidget(self._text_edit)

        # 按钮
        button_box = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel
        )
        button_box.accepted.connect(self.accept)
        button_box.rejected.connect(self.reject)
        layout.addWidget(button_box)

    def get_text(self) -> str:
        """获取输入的文本"""
        return self._text_edit.toPlainText().strip()

    def set_text(self, text: str) -> None:
        """设置文本"""
        self._text_edit.setPlainText(text)

    def set_read_only(self, read_only: bool) -> None:
        """设置只读模式"""
        self._text_edit.setReadOnly(read_only)
