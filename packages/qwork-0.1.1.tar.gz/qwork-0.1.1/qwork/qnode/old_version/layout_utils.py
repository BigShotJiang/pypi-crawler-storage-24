"""
布局工具模块 - 提供图元重叠检测和自动布局功能
"""

import math
import random
from typing import List, Tuple, Optional, Set, Dict, Union, TYPE_CHECKING, Any
from dataclasses import dataclass

from PyQt6.QtCore import QPointF, QRectF
from PyQt6.QtGui import QPainterPath, QTransform

if TYPE_CHECKING:
    from .connection_item import ConnectionItem
    from .arrow_item import ArrowItem
    from .node_canvas import NodeCanvas

# 延迟导入避免循环依赖
NodeItem = None
RootItem = None

def _get_node_item_class():
    global NodeItem
    if NodeItem is None:
        from .node_item import NodeItem as _NodeItem
        NodeItem = _NodeItem
    return NodeItem

def _get_root_item_class():
    global RootItem
    if RootItem is None:
        from .root_item import RootItem as _RootItem
        RootItem = _RootItem
    return RootItem


@dataclass
class OverlapPair:
    """重叠对 - 记录两个发生重叠的图元"""
    item1: object
    item2: object
    item1_type: str
    item2_type: str
    overlap_area: Optional[float] = None  # 重叠区域面积（如果有意义）

    def __repr__(self) -> str:
        return f"OverlapPair({self.item1_type} <-> {self.item2_type})"


class Circle:
    """圆形几何表示"""
    def __init__(self, center: QPointF, radius: float):
        self.center = center
        self.radius = radius
    
    def contains_point(self, point: QPointF) -> bool:
        """检查点是否在圆内"""
        dx = point.x() - self.center.x()
        dy = point.y() - self.center.y()
        return dx * dx + dy * dy <= self.radius * self.radius
    
    def distance_to_point(self, point: QPointF) -> float:
        """计算圆心到点的距离"""
        dx = point.x() - self.center.x()
        dy = point.y() - self.center.y()
        return math.sqrt(dx * dx + dy * dy)
    
    def intersects_circle(self, other: 'Circle') -> bool:
        """检查两个圆是否相交"""
        distance = self.distance_to_point(other.center)
        return distance < (self.radius + other.radius)
    
    def get_overlap_depth(self, other: 'Circle') -> float:
        """获取两个圆的重叠深度（负数表示不重叠）"""
        distance = self.distance_to_point(other.center)
        return (self.radius + other.radius) - distance


class LineSegment:
    """线段几何表示"""
    def __init__(self, p1: QPointF, p2: QPointF):
        self.p1 = p1
        self.p2 = p2
    
    def length(self) -> float:
        """线段长度"""
        dx = self.p2.x() - self.p1.x()
        dy = self.p2.y() - self.p1.y()
        return math.sqrt(dx * dx + dy * dy)
    
    def distance_to_point(self, point: QPointF) -> float:
        """点到线段的最短距离"""
        # 向量投影法
        dx = self.p2.x() - self.p1.x()
        dy = self.p2.y() - self.p1.y()
        
        if dx == 0 and dy == 0:
            # 退化为点
            return math.sqrt((point.x() - self.p1.x())**2 + (point.y() - self.p1.y())**2)
        
        # 计算投影参数 t
        t = max(0, min(1, ((point.x() - self.p1.x()) * dx + (point.y() - self.p1.y()) * dy) / (dx * dx + dy * dy)))
        
        # 投影点
        proj_x = self.p1.x() + t * dx
        proj_y = self.p1.y() + t * dy
        
        return math.sqrt((point.x() - proj_x)**2 + (point.y() - proj_y)**2)
    
    def intersects_segment(self, other: 'LineSegment', tolerance: float = 1.0) -> bool:
        """检查两条线段是否相交（考虑容差）"""
        # 使用叉积法判断线段相交
        def cross_product(a: QPointF, b: QPointF) -> float:
            return a.x() * b.y() - a.y() * b.x()
        
        def subtract(a: QPointF, b: QPointF) -> QPointF:
            return QPointF(a.x() - b.x(), a.y() - b.y())
        
        r = subtract(self.p2, self.p1)
        s = subtract(other.p2, other.p1)
        
        rxs = cross_product(r, s)
        qp = subtract(other.p1, self.p1)
        
        if abs(rxs) < 1e-10:
            # 平行或共线
            if abs(cross_product(qp, r)) < 1e-10:
                # 共线，检查是否重叠
                def on_segment(p: QPointF, q: QPointF, r: QPointF) -> bool:
                    return (q.x() <= max(p.x(), r.x()) + tolerance and 
                            q.x() >= min(p.x(), r.x()) - tolerance and
                            q.y() <= max(p.y(), r.y()) + tolerance and 
                            q.y() >= min(p.y(), r.y()) - tolerance)
                
                return (on_segment(self.p1, other.p1, self.p2) or 
                        on_segment(self.p1, other.p2, self.p2) or
                        on_segment(other.p1, self.p1, other.p2) or 
                        on_segment(other.p1, self.p2, other.p2))
            return False
        
        t = cross_product(qp, s) / rxs
        u = cross_product(qp, r) / rxs
        
        return -tolerance <= t <= 1 + tolerance and -tolerance <= u <= 1 + tolerance


class OverlapDetector:
    """图元重叠检测器"""
    
    def __init__(self, canvas: 'NodeCanvas'):
        self.canvas = canvas
        self.nodes: List['NodeItem'] = []
        self.connections: List['ConnectionItem'] = []
        self.roots: List['RootItem'] = []
    
    def refresh_items(self) -> None:
        """刷新图元列表"""
        self.nodes = list(self.canvas._nodes)
        self.connections = list(self.canvas._connections)
        self.roots = list(self.canvas._root_items)
    
    def get_node_circle(self, node: 'NodeItem') -> Circle:
        """获取节点的圆形几何表示"""
        center = node.sceneBoundingRect().center()
        return Circle(center, node.radius)
    
    def get_root_circle(self, root: 'RootItem') -> Circle:
        """获取ROOT的圆形几何表示"""
        center = root.sceneBoundingRect().center()
        return Circle(center, root._radius)
    
    def sample_bezier_curve(self, path: QPainterPath, num_samples: int = 50) -> List[QPointF]:
        """对贝塞尔曲线进行采样，获取点列表"""
        if path.isEmpty():
            return []
        
        points = []
        length = path.length()
        if length < 1e-6:
            return [path.pointAtPercent(0)]
        
        for i in range(num_samples + 1):
            t = i / num_samples
            points.append(path.pointAtPercent(t))
        
        return points
    
    def get_connection_segments(self, conn: 'ConnectionItem', segment_length: float = 10.0) -> List[LineSegment]:
        """将连接线分割为线段列表"""
        path = conn.path()
        if path.isEmpty():
            return []
        
        points = self.sample_bezier_curve(path)
        if len(points) < 2:
            return []
        
        segments = []
        for i in range(len(points) - 1):
            segments.append(LineSegment(points[i], points[i + 1]))
        
        return segments
    
    def check_node_node_overlap(self, node1: 'NodeItem', node2: 'NodeItem') -> bool:
        """检查两个节点（圆形）是否重叠"""
        circle1 = self.get_node_circle(node1)
        circle2 = self.get_node_circle(node2)
        return circle1.intersects_circle(circle2)
    
    def check_node_root_overlap(self, node: 'NodeItem', root: 'RootItem') -> bool:
        """检查节点与ROOT是否重叠"""
        node_circle = self.get_node_circle(node)
        root_circle = self.get_root_circle(root)
        return node_circle.intersects_circle(root_circle)
    
    def check_root_root_overlap(self, root1: 'RootItem', root2: 'RootItem') -> bool:
        """检查两个ROOT是否重叠"""
        circle1 = self.get_root_circle(root1)
        circle2 = self.get_root_circle(root2)
        return circle1.intersects_circle(circle2)
    
    def check_node_connection_overlap(self, node: 'NodeItem', conn: 'ConnectionItem',
                                       tolerance: float = 2.0) -> bool:
        """检查节点（圆形）与连接线是否重叠"""
        circle = self.get_node_circle(node)
        segments = self.get_connection_segments(conn)

        # 检查连接线的两个端点是否在节点内（这是正常情况，不算重叠）
        # 获取连接的源节点和目标节点
        source = conn.source_node
        target = conn.target_node

        for segment in segments:
            # 跳过与端点非常近的部分
            source_dist = circle.distance_to_point(source.sceneBoundingRect().center())
            target_dist = circle.distance_to_point(target.sceneBoundingRect().center())

            # 如果节点是连接的端点之一，跳过靠近端点的部分
            is_endpoint_segment = False
            if circle.distance_to_point(segment.p1) < node.radius * 1.5:
                if source_dist < node.radius * 2 or target_dist < node.radius * 2:
                    is_endpoint_segment = True

            if not is_endpoint_segment:
                # 检查线段是否与圆相交
                dist = segment.distance_to_point(circle.center)
                if dist < circle.radius - tolerance:
                    return True

        return False

    def check_connection_root_overlap(self, conn: 'ConnectionItem', root: 'RootItem',
                                       tolerance: float = 2.0) -> bool:
        """检查连接线与ROOT（类定义）是否重叠"""
        circle = self.get_root_circle(root)
        segments = self.get_connection_segments(conn)

        # 获取连接的源节点和目标节点
        source = conn.source_node
        target = conn.target_node

        for segment in segments:
            # 检查线段是否与圆相交
            dist = segment.distance_to_point(circle.center)
            if dist < circle.radius - tolerance:
                return True

        return False
    
    def check_connection_connection_overlap(self, conn1: 'ConnectionItem', conn2: 'ConnectionItem',
                                             tolerance: float = 3.0) -> bool:
        """检查两条连接线是否重叠"""
        # 如果是同一条连接，不算重叠
        if conn1 is conn2:
            return False
        
        # 如果两条连接共享节点，在节点附近不算重叠
        shared_nodes = set()
        nodes1 = {conn1.source_node, conn1.target_node}
        nodes2 = {conn2.source_node, conn2.target_node}
        shared_nodes = nodes1 & nodes2
        
        segments1 = self.get_connection_segments(conn1)
        segments2 = self.get_connection_segments(conn2)
        
        for seg1 in segments1:
            for seg2 in segments2:
                # 计算两条线段的最近距离
                dist = self._segment_distance(seg1, seg2)
                if dist < tolerance:
                    # 检查是否是在共享节点附近的正常连接
                    if not self._is_near_shared_node(seg1, seg2, shared_nodes):
                        return True
        
        return False
    
    def _segment_distance(self, seg1: LineSegment, seg2: LineSegment) -> float:
        """计算两条线段之间的最短距离"""
        # 如果相交，距离为0
        if seg1.intersects_segment(seg2):
            return 0.0
        
        # 否则取四个端点到另一线段距离的最小值
        distances = [
            seg1.distance_to_point(seg2.p1),
            seg1.distance_to_point(seg2.p2),
            seg2.distance_to_point(seg1.p1),
            seg2.distance_to_point(seg1.p2)
        ]
        
        return min(distances)
    
    def _is_near_shared_node(self, seg1: LineSegment, seg2: LineSegment, 
                              shared_nodes: Set['NodeItem']) -> bool:
        """检查两条线段是否靠近共享节点（正常连接不算重叠）"""
        if not shared_nodes:
            return False
        
        for node in shared_nodes:
            center = node.sceneBoundingRect().center()
            radius = node.radius
            
            # 如果两条线段都靠近同一个节点，可能是正常连接
            dist1 = min(LineSegment(center, seg1.p1).length(), LineSegment(center, seg1.p2).length())
            dist2 = min(LineSegment(center, seg2.p1).length(), LineSegment(center, seg2.p2).length())
            
            if dist1 < radius * 2 and dist2 < radius * 2:
                return True
        
        return False
    
    def find_all_overlaps(self, check_node_node: bool = True,
                         check_node_connection: bool = True,
                         check_connection_connection: bool = True,
                         check_node_root: bool = True,
                         check_root_root: bool = True,
                         check_connection_root: bool = True) -> List[OverlapPair]:
        """
        查找所有重叠的图元对

        Args:
            check_node_node: 是否检查节点之间的重叠
            check_node_connection: 是否检查节点与连接线的重叠
            check_connection_connection: 是否检查连接线之间的重叠
            check_node_root: 是否检查节点与ROOT的重叠
            check_root_root: 是否检查ROOT之间的重叠
            check_connection_root: 是否检查连接线与ROOT的重叠

        Returns:
            重叠对列表
        """
        self.refresh_items()
        overlaps = []

        # 1. 检查节点之间的重叠
        if check_node_node:
            for i, node1 in enumerate(self.nodes):
                for node2 in self.nodes[i + 1:]:
                    if self.check_node_node_overlap(node1, node2):
                        circle1 = self.get_node_circle(node1)
                        circle2 = self.get_node_circle(node2)
                        overlap_depth = circle1.get_overlap_depth(circle2)
                        overlaps.append(OverlapPair(
                            node1, node2, "Node", "Node",
                            overlap_area=overlap_depth if overlap_depth > 0 else 0
                        ))

        # 2. 检查节点与连接线的重叠
        if check_node_connection:
            for node in self.nodes:
                for conn in self.connections:
                    # 跳过节点自身的连接
                    if conn.source_node == node or conn.target_node == node:
                        continue
                    if self.check_node_connection_overlap(node, conn):
                        overlaps.append(OverlapPair(node, conn, "Node", "Connection"))

        # 3. 检查连接线之间的重叠
        if check_connection_connection:
            for i, conn1 in enumerate(self.connections):
                for conn2 in self.connections[i + 1:]:
                    if self.check_connection_connection_overlap(conn1, conn2):
                        overlaps.append(OverlapPair(conn1, conn2, "Connection", "Connection"))

        # 4. 检查节点与ROOT的重叠
        if check_node_root:
            for node in self.nodes:
                for root in self.roots:
                    if self.check_node_root_overlap(node, root):
                        circle1 = self.get_node_circle(node)
                        circle2 = self.get_root_circle(root)
                        overlap_depth = circle1.get_overlap_depth(circle2)
                        overlaps.append(OverlapPair(
                            node, root, "Node", "Root",
                            overlap_depth if overlap_depth > 0 else 0
                        ))

        # 5. 检查ROOT之间的重叠
        if check_root_root:
            for i, root1 in enumerate(self.roots):
                for root2 in self.roots[i + 1:]:
                    if self.check_root_root_overlap(root1, root2):
                        circle1 = self.get_root_circle(root1)
                        circle2 = self.get_root_circle(root2)
                        overlap_depth = circle1.get_overlap_depth(circle2)
                        overlaps.append(OverlapPair(
                            root1, root2, "Root", "Root",
                            overlap_depth if overlap_depth > 0 else 0
                        ))

        # 6. 检查连接线与ROOT的重叠
        if check_connection_root:
            for conn in self.connections:
                for root in self.roots:
                    if self.check_connection_root_overlap(conn, root):
                        overlaps.append(OverlapPair(conn, root, "Connection", "Root"))

        return overlaps
    
    def get_overlap_summary(self) -> Dict[str, int]:
        """获取重叠统计信息"""
        overlaps = self.find_all_overlaps()
        summary = {
            "total": len(overlaps),
            "node_node": 0,
            "node_connection": 0,
            "connection_connection": 0,
            "node_root": 0,
            "root_root": 0,
            "connection_root": 0
        }
        
        for pair in overlaps:
            key = f"{pair.item1_type.lower()}_{pair.item2_type.lower()}"
            if key in summary:
                summary[key] += 1
            else:
                # 处理反向的情况
                reverse_key = f"{pair.item2_type.lower()}_{pair.item1_type.lower()}"
                if reverse_key in summary:
                    summary[reverse_key] += 1
        
        return summary


class DenseLayoutEngine:
    """密集布局引擎 - 尽可能密集地排列图元，避免重叠"""
    
    def __init__(self, canvas: 'NodeCanvas'):
        self.canvas = canvas
        self.detector = OverlapDetector(canvas)
        self.margin: float = 20.0  # 图元之间的最小间距
    
    def set_margin(self, margin: float) -> None:
        """设置图元之间的最小间距"""
        self.margin = margin
    
    def get_item_radius(self, item: Union['NodeItem', 'RootItem']) -> float:
        """获取图元的有效半径（包含边距）"""
        if hasattr(item, 'radius'):
            return item.radius + self.margin
        elif hasattr(item, '_radius'):
            return item._radius + self.margin
        return 50.0
    
    def get_item_center(self, item: Union['NodeItem', 'RootItem']) -> QPointF:
        """获取图元的中心点"""
        return item.sceneBoundingRect().center()
    
    def set_item_center(self, item: Union['NodeItem', 'RootItem'], center: QPointF) -> None:
        """设置图元的中心点"""
        # NodeItem 和 RootItem 都使用 setPos 设置位置
        # 但 NodeItem 的坐标系是以中心为原点的（通过 setRect(-radius, -radius, ... 实现）
        # RootItem 也是类似的实现
        item.setPos(center)
    
    def calculate_bounding_circle(self, items: List[Union['NodeItem', 'RootItem']]) -> Tuple[QPointF, float]:
        """
        计算一组图元的最小包围圆
        
        Returns:
            (中心点, 半径)
        """
        if not items:
            return QPointF(0, 0), 0.0
        
        # 计算中心点
        total_x, total_y = 0.0, 0.0
        for item in items:
            center = self.get_item_center(item)
            total_x += center.x()
            total_y += center.y()
        
        avg_x = total_x / len(items)
        avg_y = total_y / len(items)
        center = QPointF(avg_x, avg_y)
        
        # 计算半径
        max_radius = 0.0
        for item in items:
            item_center = self.get_item_center(item)
            radius = self.get_item_radius(item)
            dist = math.sqrt((item_center.x() - center.x())**2 + (item_center.y() - center.y())**2)
            max_radius = max(max_radius, dist + radius)
        
        return center, max_radius
    
    def layout_circular(self, items: List[Union['NodeItem', 'RootItem']], 
                        center: QPointF = None,
                        start_radius: float = None) -> None:
        """
        圆形布局 - 将图元排列在同心圆上
        
        Args:
            items: 要布局的图元列表
            center: 圆心位置，默认为画布中心
            start_radius: 起始半径，默认为自动计算
        """
        if not items:
            return
        
        if center is None:
            # 使用画布中心
            viewport_rect = self.canvas.viewport().rect()
            center = self.canvas.mapToScene(viewport_rect.center())
        
        # 按半径排序，大的放在外层
        sorted_items = sorted(items, key=lambda x: self.get_item_radius(x), reverse=True)
        
        # 计算每个圆环能容纳的图元数量
        current_radius = start_radius or self.get_item_radius(sorted_items[0])
        current_circle_items = []
        
        for item in sorted_items:
            item_radius = self.get_item_radius(item)
            
            # 检查当前圆环是否还能容纳
            if current_circle_items:
                # 估算当前圆环已占用的角度
                total_angle_needed = sum(2 * math.asin(self.get_item_radius(x) / current_radius) 
                                        for x in current_circle_items)
                remaining_angle = 2 * math.pi - total_angle_needed
                this_angle = 2 * math.asin(item_radius / current_radius)
                
                if this_angle > remaining_angle * 0.9:  # 留一些余量
                    # 当前圆环满了，开始新的圆环
                    self._place_on_circle(current_circle_items, center, current_radius)
                    current_circle_items = []
                    current_radius += item_radius * 2 + self.margin
            
            current_circle_items.append(item)
        
        # 放置最后一组
        if current_circle_items:
            self._place_on_circle(current_circle_items, center, current_radius)
    
    def _place_on_circle(self, items: List[Union['NodeItem', 'RootItem']], 
                         center: QPointF, radius: float) -> None:
        """将图元均匀放置在圆上"""
        if not items:
            return
        
        n = len(items)
        angle_step = 2 * math.pi / n
        
        for i, item in enumerate(items):
            angle = i * angle_step
            x = center.x() + radius * math.cos(angle)
            y = center.y() + radius * math.sin(angle)
            self.set_item_center(item, QPointF(x, y))
    
    def layout_grid(self, items: List[Union['NodeItem', 'RootItem']],
                    start_pos: QPointF = None,
                    cols: int = None) -> None:
        """
        网格布局 - 将图元排列成网格
        
        Args:
            items: 要布局的图元列表
            start_pos: 起始位置，默认为画布中心
            cols: 列数，默认为自动计算
        """
        if not items:
            return
        
        if start_pos is None:
            viewport_rect = self.canvas.viewport().rect()
            start_pos = self.canvas.mapToScene(viewport_rect.center())
        
        # 计算最大半径作为单元格大小
        max_radius = max(self.get_item_radius(item) for item in items)
        cell_size = max_radius * 2
        
        # 自动计算列数
        if cols is None:
            cols = max(1, int(math.sqrt(len(items))))
        
        # 计算起始位置（使网格居中）
        rows = (len(items) + cols - 1) // cols
        grid_width = cols * cell_size
        grid_height = rows * cell_size
        
        start_x = start_pos.x() - grid_width / 2 + max_radius
        start_y = start_pos.y() - grid_height / 2 + max_radius
        
        # 放置图元
        for i, item in enumerate(items):
            row = i // cols
            col = i % cols
            x = start_x + col * cell_size
            y = start_y + row * cell_size
            self.set_item_center(item, QPointF(x, y))
    
    def layout_force_directed(self, items: List[Union['NodeItem', 'RootItem']],
                              iterations: int = 100,
                              repulsion_strength: float = 5000.0,
                              attraction_strength: float = 0.01,
                              damping: float = 0.8) -> None:
        """
        力导向布局 - 模拟物理力使图元均匀分布
        
        Args:
            items: 要布局的图元列表
            iterations: 迭代次数
            repulsion_strength: 排斥力强度
            attraction_strength: 吸引力强度（向中心）
            damping: 阻尼系数
        """
        if len(items) < 2:
            return
        
        # 初始化速度
        velocities = {id(item): QPointF(0, 0) for item in items}
        
        # 计算中心点
        center = QPointF(0, 0)
        for item in items:
            c = self.get_item_center(item)
            center.setX(center.x() + c.x())
            center.setY(center.y() + c.y())
        center.setX(center.x() / len(items))
        center.setY(center.y() / len(items))
        
        for _ in range(iterations):
            # 计算每个图元受到的力
            forces = {id(item): QPointF(0, 0) for item in items}
            
            # 1. 排斥力（图元之间）
            for i, item1 in enumerate(items):
                for item2 in items[i + 1:]:
                    center1 = self.get_item_center(item1)
                    center2 = self.get_item_center(item2)
                    
                    dx = center1.x() - center2.x()
                    dy = center1.y() - center2.y()
                    dist_sq = dx * dx + dy * dy
                    
                    if dist_sq < 1e-6:
                        # 随机偏移避免除零
                        dx, dy = (random.random() - 0.5) * 10, (random.random() - 0.5) * 10
                        dist_sq = dx * dx + dy * dy
                    
                    dist = math.sqrt(dist_sq)
                    min_dist = self.get_item_radius(item1) + self.get_item_radius(item2)
                    
                    # 只有当距离小于最小距离时才产生强排斥力
                    if dist < min_dist * 2:
                        force_magnitude = repulsion_strength * (min_dist * 2 - dist) / (dist * min_dist)
                        
                        fx = (dx / dist) * force_magnitude
                        fy = (dy / dist) * force_magnitude
                        
                        forces[id(item1)].setX(forces[id(item1)].x() + fx)
                        forces[id(item1)].setY(forces[id(item1)].y() + fy)
                        forces[id(item2)].setX(forces[id(item2)].x() - fx)
                        forces[id(item2)].setY(forces[id(item2)].y() - fy)
            
            # 2. 吸引力（向中心）
            for item in items:
                item_center = self.get_item_center(item)
                dx = center.x() - item_center.x()
                dy = center.y() - item_center.y()
                
                forces[id(item)].setX(forces[id(item)].x() + dx * attraction_strength)
                forces[id(item)].setY(forces[id(item)].y() + dy * attraction_strength)
            
            # 更新位置和速度
            for item in items:
                # 更新速度
                v = velocities[id(item)]
                v.setX((v.x() + forces[id(item)].x()) * damping)
                v.setY((v.y() + forces[id(item)].y()) * damping)
                
                # 更新位置
                item_center = self.get_item_center(item)
                new_x = item_center.x() + v.x()
                new_y = item_center.y() + v.y()
                self.set_item_center(item, QPointF(new_x, new_y))
    
    def layout_hierarchical(self, items: List[Union['NodeItem', 'RootItem']],
                           levels: Dict[Union['NodeItem', 'RootItem'], int] = None) -> None:
        """
        层次布局 - 根据层级将图元排列在不同水平线上
        
        Args:
            items: 要布局的图元列表
            levels: 每个图元的层级字典，如果为None则自动计算
        """
        if not items:
            return
        
        # 自动计算层级（基于连接关系）
        if levels is None:
            levels = self._calculate_hierarchy_levels(items)
        
        # 按层级分组
        level_groups: Dict[int, List[Union['NodeItem', 'RootItem']]] = {}
        for item in items:
            level = levels.get(item, 0)
            if level not in level_groups:
                level_groups[level] = []
            level_groups[level].append(item)
        
        # 计算布局参数
        max_radius = max(self.get_item_radius(item) for item in items)
        level_height = max_radius * 2.5
        
        # 计算画布中心
        viewport_rect = self.canvas.viewport().rect()
        center_x = self.canvas.mapToScene(viewport_rect.center()).x()
        
        # 放置每个层级的图元
        sorted_levels = sorted(level_groups.keys())
        min_level = min(sorted_levels)
        
        for level in sorted_levels:
            level_items = level_groups[level]
            y = (level - min_level) * level_height
            
            # 水平居中排列
            total_width = len(level_items) * max_radius * 2
            start_x = center_x - total_width / 2 + max_radius
            
            for i, item in enumerate(level_items):
                x = start_x + i * max_radius * 2
                self.set_item_center(item, QPointF(x, y))
    
    def _calculate_hierarchy_levels(self, items: List[Union['NodeItem', 'RootItem']]) -> Dict[Union['NodeItem', 'RootItem'], int]:
        """基于连接关系计算层级"""
        levels = {item: 0 for item in items}
        
        # 构建邻接表（只考虑items中的节点）
        item_set = set(items)
        adjacency = {item: [] for item in items}
        
        for conn in self.canvas._connections:
            if conn.source_node in item_set and conn.target_node in item_set:
                adjacency[conn.source_node].append(conn.target_node)
        
        # 拓扑排序计算层级
        changed = True
        max_iterations = len(items) * 2
        iteration = 0
        
        while changed and iteration < max_iterations:
            changed = False
            iteration += 1
            
            for item in items:
                for neighbor in adjacency[item]:
                    if levels[neighbor] <= levels[item]:
                        levels[neighbor] = levels[item] + 1
                        changed = True
        
        return levels
    
    def layout_compact(self, items: List[Union['NodeItem', 'RootItem']] = None) -> None:
        """
        紧凑布局 - 使用多种策略尽可能密集地排列图元
        
        这是主要的布局方法，会自动选择最佳策略
        
        Args:
            items: 要布局的图元列表，如果为None则使用所有图元
        """
        if items is None:
            items = list(self.canvas._nodes) + list(self.canvas._root_items)
        
        if not items:
            return
        
        # 分离节点和ROOT
        NodeItemCls = _get_node_item_class()
        RootItemCls = _get_root_item_class()
        nodes = [item for item in items if isinstance(item, NodeItemCls)]
        roots = [item for item in items if isinstance(item, RootItemCls)]
        
        # 1. 首先使用力导向布局打散重叠
        self.layout_force_directed(nodes, iterations=50, repulsion_strength=10000.0)
        
        # 2. 如果有连接关系，尝试层次布局
        if len(self.canvas._connections) > 0 and len(nodes) > 2:
            self.layout_hierarchical(nodes)
        
        # 3. 微调：使用力导向布局优化间距
        self.layout_force_directed(nodes, iterations=30, repulsion_strength=3000.0)
        
        # 4. 放置ROOT（放在节点区域的旁边）
        if roots:
            self._place_roots_compact(roots, nodes)
        
        # 5. 更新连接线
        self._update_connections()
    
    def _place_roots_compact(self, roots: List['RootItem'], nodes: List['NodeItem']) -> None:
        """紧凑放置ROOT图元"""
        if not roots:
            return
        
        # 计算节点区域的边界
        if nodes:
            min_x = min(self.get_item_center(n).x() - self.get_item_radius(n) for n in nodes)
            max_x = max(self.get_item_center(n).x() + self.get_item_radius(n) for n in nodes)
            min_y = min(self.get_item_center(n).y() - self.get_item_radius(n) for n in nodes)
            max_y = max(self.get_item_center(n).y() + self.get_item_radius(n) for n in nodes)
            
            # 将ROOT放在节点区域的右侧
            root_x = max_x + max(self.get_item_radius(r) for r in roots) * 2
            root_y_start = (min_y + max_y) / 2
        else:
            viewport_rect = self.canvas.viewport().rect()
            center = self.canvas.mapToScene(viewport_rect.center())
            root_x = center.x()
            root_y_start = center.y()
        
        # 垂直排列ROOT
        max_root_radius = max(self.get_item_radius(r) for r in roots)
        current_y = root_y_start - len(roots) * max_root_radius
        
        for root in roots:
            radius = self.get_item_radius(root)
            self.set_item_center(root, QPointF(root_x, current_y))
            current_y += radius * 2 + self.margin
    
    def _update_connections(self) -> None:
        """更新所有连接线的路径"""
        for conn in self.canvas._connections:
            conn.update_path()
    
    def auto_layout(self, strategy: str = "compact") -> None:
        """
        自动布局入口方法
        
        Args:
            strategy: 布局策略，可选 "compact", "circular", "grid", "hierarchical", "force"
        """
        items = list(self.canvas._nodes) + list(self.canvas._root_items)
        
        if strategy == "compact":
            self.layout_compact(items)
        elif strategy == "circular":
            self.layout_circular(items)
        elif strategy == "grid":
            self.layout_grid(items)
        elif strategy == "hierarchical":
            self.layout_hierarchical(items)
        elif strategy == "force":
            self.layout_force_directed(items)
        else:
            self.layout_compact(items)
        
        # 最终更新连接线
        self._update_connections()


# 便捷函数
def check_overlaps(canvas: 'NodeCanvas') -> List[OverlapPair]:
    """
    检查画布上所有图元的重叠情况
    
    Args:
        canvas: 节点画布
    
    Returns:
        重叠对列表
    """
    detector = OverlapDetector(canvas)
    return detector.find_all_overlaps()


def auto_layout(canvas: 'NodeCanvas', strategy: str = "compact") -> None:
    """
    对画布上的所有图元进行自动布局
    
    Args:
        canvas: 节点画布
        strategy: 布局策略，可选 "compact", "circular", "grid", "hierarchical", "force"
    """
    engine = DenseLayoutEngine(canvas)
    engine.auto_layout(strategy)


def resolve_overlaps(canvas: 'NodeCanvas', max_iterations: int = 100) -> bool:
    """
    尝试解决所有重叠问题
    
    Args:
        canvas: 节点画布
        max_iterations: 最大迭代次数
    
    Returns:
        是否成功解决所有重叠
    """
    detector = OverlapDetector(canvas)
    engine = DenseLayoutEngine(canvas)
    
    for i in range(max_iterations):
        overlaps = detector.find_all_overlaps()
        
        if not overlaps:
            return True
        
        # 使用力导向布局逐步解决重叠
        items = list(canvas._nodes) + list(canvas._root_items)
        engine.layout_force_directed(items, iterations=5, repulsion_strength=10000.0 * (1 + i * 0.1))
    
    # 最终检查
    return len(detector.find_all_overlaps()) == 0


class ViewportFitter:
    """
    视口适配器 - 根据所有 node 和 root 自动计算合适的视口缩放和位置

    质量模型：质量 = 半径
    质心计算：加权平均位置
    """

    def __init__(self, canvas: 'NodeCanvas'):
        self.canvas = canvas

    def _get_item_radius(self, item: Union['NodeItem', 'RootItem']) -> float:
        """获取图元的半径（质量）"""
        if hasattr(item, 'radius'):
            return item.radius
        elif hasattr(item, '_radius'):
            return item._radius
        return 50.0  # 默认半径

    def _get_item_center(self, item: Union['NodeItem', 'RootItem']) -> QPointF:
        """获取图元的中心点位置"""
        return item.sceneBoundingRect().center()

    def calculate_center_of_mass(self, items: List[Union['NodeItem', 'RootItem']]) -> Optional[QPointF]:
        """
        计算图元系统的质心（质量 = 半径）

        Args:
            items: 图元列表

        Returns:
            质心位置，如果列表为空返回 None
        """
        if not items:
            return None

        total_mass = 0.0
        weighted_x = 0.0
        weighted_y = 0.0

        for item in items:
            center = self._get_item_center(item)
            mass = self._get_item_radius(item)
            total_mass += mass
            weighted_x += center.x() * mass
            weighted_y += center.y() * mass

        if total_mass == 0:
            return QPointF(0, 0)

        return QPointF(weighted_x / total_mass, weighted_y / total_mass)

    def calculate_bounding_rect(
        self,
        items: List[Union['NodeItem', 'RootItem']],
        padding_ratio: float = 0.1
    ) -> QRectF:
        """
        计算图元的包围盒

        Args:
            items: 图元列表
            padding_ratio: 内边距比例（相对于包围盒大小）

        Returns:
            包围矩形（scene 坐标）
        """
        if not items:
            return QRectF(-100, -100, 200, 200)  # 默认空区域

        min_x = float('inf')
        min_y = float('inf')
        max_x = float('-inf')
        max_y = float('-inf')

        for item in items:
            center = self._get_item_center(item)
            radius = self._get_item_radius(item)
            min_x = min(min_x, center.x() - radius)
            min_y = min(min_y, center.y() - radius)
            max_x = max(max_x, center.x() + radius)
            max_y = max(max_y, center.y() + radius)

        # 添加内边距
        width = max_x - min_x
        height = max_y - min_y
        padding_x = width * padding_ratio
        padding_y = height * padding_ratio

        return QRectF(
            min_x - padding_x,
            min_y - padding_y,
            width + 2 * padding_x,
            height + 2 * padding_y
        )

    def fit_viewport(
        self,
        min_scale: float = 0.5,
        max_scale: float = 1.6,
        padding_ratio: float = 0.1,
        animation_duration: int = 0
    ) -> Dict[str, Any]:
        """
        自动适配视口，确保所有图元可见且视口中心与质心对齐

        Args:
            min_scale: 最小缩放比例
            max_scale: 最大缩放比例
            padding_ratio: 内边距比例
            animation_duration: 动画持续时间（毫秒），0 表示无动画

        Returns:
            包含适配结果的字典：
            {
                "success": bool,
                "center": QPointF,  # 质心位置
                "scale": float,     # 应用的缩放比例
                "bounding_rect": QRectF  # 计算的包围盒
            }
        """
        # 获取所有图元
        items = list(self.canvas._nodes) + list(self.canvas._root_items)

        if not items:
            return {
                "success": False,
                "center": QPointF(0, 0),
                "scale": 1.0,
                "bounding_rect": QRectF(-100, -100, 200, 200),
                "error": "No items to fit"
            }

        # 计算质心
        center_of_mass = self.calculate_center_of_mass(items)

        # 计算包围盒
        bounding_rect = self.calculate_bounding_rect(items, padding_ratio)

        # 获取视口大小
        viewport_rect = self.canvas.viewport().rect()
        viewport_width = viewport_rect.width()
        viewport_height = viewport_rect.height()

        if viewport_width <= 0 or viewport_height <= 0:
            return {
                "success": False,
                "center": center_of_mass,
                "scale": 1.0,
                "bounding_rect": bounding_rect,
                "error": "Invalid viewport size"
            }

        # 计算合适的缩放比例
        # 目标是让包围盒完全适应视口
        rect_width = bounding_rect.width()
        rect_height = bounding_rect.height()

        if rect_width <= 0 or rect_height <= 0:
            scale = 1.0
        else:
            # 计算水平和垂直方向需要的缩放
            scale_x = viewport_width / rect_width
            scale_y = viewport_height / rect_height
            # 取较小的值，确保整个包围盒都能显示
            scale = min(scale_x, scale_y)

        # 限制缩放范围
        scale = max(min_scale, min(max_scale, scale))

        # 应用变换
        if animation_duration > 0:
            # 使用动画（可选实现）
            self._animate_viewport(center_of_mass, scale, animation_duration)
        else:
            # 直接设置
            self._apply_viewport_transform(center_of_mass, scale)

        return {
            "success": True,
            "center": center_of_mass,
            "scale": scale,
            "bounding_rect": bounding_rect
        }

    def _apply_viewport_transform(self, center: QPointF, scale: float) -> None:
        """
        应用视口变换

        Args:
            center: 视口中心位置（scene 坐标）
            scale: 缩放比例
        """
        # 使用更可靠的方式：重置变换 -> 缩放 -> 居中
        self.canvas.resetTransform()
        self.canvas.scale(scale, scale)
        self.canvas.centerOn(center)

    def _animate_viewport(
        self,
        target_center: QPointF,
        target_scale: float,
        duration: int
    ) -> None:
        """
        动画过渡到目标视口（简化实现）

        Args:
            target_center: 目标中心
            target_scale: 目标缩放
            duration: 动画持续时间（毫秒）
        """
        # 这里可以实现动画效果
        # 简化版本：直接应用
        self._apply_viewport_transform(target_center, target_scale)


def fit_viewport(
    canvas: 'NodeCanvas',
    min_scale: float = 0.1,
    max_scale: float = 5.0,
    padding_ratio: float = 0.1
) -> Dict[str, Any]:
    """
    便捷函数：自动适配画布视口

    Args:
        canvas: 节点画布
        min_scale: 最小缩放比例
        max_scale: 最大缩放比例
        padding_ratio: 内边距比例

    Returns:
        适配结果字典

    Example:
        result = fit_viewport(canvas, min_scale=0.2, max_scale=3.0)
        if result["success"]:
            print(f"Viewport fitted: scale={result['scale']:.2f}, center={result['center']}")
    """
    fitter = ViewportFitter(canvas)
    return fitter.fit_viewport(min_scale, max_scale, padding_ratio)


def reset_viewport(canvas: 'NodeCanvas') -> None:
    """
    重置视口到默认状态（缩放 1.0，位置在原点）

    Args:
        canvas: 节点画布
    """
    canvas.resetTransform()
    canvas.centerOn(0, 0)


def check_viewport(canvas: 'NodeCanvas') -> Dict[str, Any]:
    """
    检查当前视口是否合适

    检查两个条件：
    1. 中心偏差：质心与视口中心的距离是否超出40%画布可视区域高度
    2. 缩放偏差：图元包围盒面积与视口面积的偏差是否在[-0.4, 0.4]范围内

    Args:
        canvas: 节点画布

    Returns:
        检查结果字典：
        {
            "center_offset": float,  # 中心偏差（像素）
            "scale_offset": float,   # 缩放偏差（面积比例）
            "center_ok": bool,       # 中心位置是否合理
            "scale_ok": bool,        # 缩放比例是否合理
            "ok": bool               # 整体是否合理（and逻辑）
        }
    """
    fitter = ViewportFitter(canvas)

    # 获取所有图元
    items = list(canvas._nodes) + list(canvas._root_items)

    if not items:
        return {
            "center_offset": 0.0,
            "scale_offset": 0.0,
            "center_ok": True,
            "scale_ok": True,
            "ok": True
        }

    # 计算质心
    center_of_mass = fitter.calculate_center_of_mass(items)

    # 获取视口信息
    viewport_rect = canvas.viewport().rect()
    viewport_width = viewport_rect.width()
    viewport_height = viewport_rect.height()

    if viewport_width <= 0 or viewport_height <= 0:
        return {
            "center_offset": 0.0,
            "scale_offset": 0.0,
            "center_ok": False,
            "scale_ok": False,
            "ok": False
        }

    # 获取当前视口中心（scene坐标）
    viewport_center = canvas.mapToScene(viewport_rect.center())

    # 计算中心偏差（质心与视口中心的距离）
    center_offset = math.sqrt(
        (center_of_mass.x() - viewport_center.x()) ** 2 +
        (center_of_mass.y() - viewport_center.y()) ** 2
    )

    # 计算40%画布高度的阈值
    height_threshold = viewport_height * 0.4

    # 中心合理性：距离差是否超出40%画布高度
    center_ok = center_offset <= height_threshold

    # 计算图元包围盒
    bounding_rect = fitter.calculate_bounding_rect(items, padding_ratio=0.0)
    # 获取当前缩放
    current_scale = canvas.transform().m11()

    # 计算包围盒面积（scene坐标）
    bounding_area_scene = bounding_rect.width() * bounding_rect.height() * 4  # 修正系数4
    # 转换为像素面积（视觉实际大小）
    bounding_area_pixel = bounding_area_scene * (current_scale ** 2)

    # 计算视口面积（像素）
    viewport_area_pixel = viewport_width * viewport_height

    if viewport_area_pixel <= 0:
        scale_offset = 0.0
        scale_ok = False
    else:
        # 缩放偏差 = (包围盒像素面积 - 视口像素面积) / 视口像素面积
        # 这表示包围盒相对于视口的"占满程度"
        scale_offset = (bounding_area_pixel - viewport_area_pixel) / viewport_area_pixel

        # 缩放合理性：偏差是否在[-0.4, 0.4]范围内
        scale_ok = -0.6 <= scale_offset <= 0.4

        # 特殊条件判断
        # 如果缩放偏差<0且当前缩放>=1.6，或缩放偏差>0且当前缩放<=0.5
        # 则缩放合理性一定为True
        if (scale_offset < 0 and current_scale >= 1.6) or \
           (scale_offset > 0 and current_scale <= 0.5):
            scale_ok = True

    return {
        "center_offset": center_offset,
        "scale_offset": scale_offset,
        "center_ok": center_ok,
        "scale_ok": scale_ok,
        "ok": center_ok and scale_ok
    }
