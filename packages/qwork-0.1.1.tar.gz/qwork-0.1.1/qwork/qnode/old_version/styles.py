"""
样式配置模块
"""

from dataclasses import dataclass, field
from PyQt6.QtGui import QColor


@dataclass
class NodeStyle:
    """节点样式配置"""
    # Idle状态
    idle_fill: QColor = field(default_factory=lambda: QColor("#F5F5F5"))
    idle_stroke: QColor = field(default_factory=lambda: QColor("#666666"))
    # Hover状态叠加
    hover_overlay: QColor = field(default_factory=lambda: QColor("#FFFAF0"))
    # 选中状态
    selected_stroke: QColor = field(default_factory=lambda: QColor("#FF8C00"))
    selected_overlay: QColor = field(default_factory=lambda: QColor("#FFF8DC"))
    # 通用
    stroke_width: float = 2.0
    text_color: QColor = field(default_factory=lambda: QColor("#333333"))


@dataclass
class ConnectionStyle:
    """连接线样式配置"""
    normal_color: QColor = field(default_factory=lambda: QColor("#666666"))
    selected_color: QColor = field(default_factory=lambda: QColor("#FF8C00"))
    hover_color: QColor = field(default_factory=lambda: QColor("#999999"))
    stroke_width: float = 2.0
    selected_stroke_width: float = 3.0


@dataclass
class ArrowStyle:
    """箭头样式配置"""
    normal_color: QColor = field(default_factory=lambda: QColor("#666666"))
    selected_color: QColor = field(default_factory=lambda: QColor("#FF8C00"))
    hover_color: QColor = field(default_factory=lambda: QColor("#FF1493"))  # 洋粉红色
    arrow_size: float = 12.0
    stroke_width: float = 2.0
