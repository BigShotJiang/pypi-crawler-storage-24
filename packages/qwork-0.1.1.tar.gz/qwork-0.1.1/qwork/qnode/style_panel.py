"""
样式面板模块 - 用于编辑选中节点的样式
贴合在canvas下方，支持多节点样式编辑
"""

from typing import List, Optional
from PyQt6.QtWidgets import (
    QWidget, QHBoxLayout, QVBoxLayout, QLabel, QPushButton,
    QComboBox, QSpinBox, QSlider, QColorDialog,
    QFrame, QSizePolicy
)
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QColor, QFontDatabase

from qwork.qnode.node_item import NodeItem


class ColorButton(QPushButton):
    """颜色选择按钮 - 圆形带颜色显示"""

    def __init__(self, parent=None, color: QColor = QColor(128, 128, 128)):
        super().__init__(parent)
        self._color = color
        self.setFixedSize(24, 24)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self._updateStyle()

    def _updateStyle(self):
        """更新按钮样式"""
        self.setStyleSheet(f"""
            ColorButton {{
                background-color: {self._color.name()};
                border: 2px solid #c0c0c0;
                border-radius: 12px;
            }}
            ColorButton:hover {{
                border: 2px solid #808080;
            }}
            ColorButton:pressed {{
                border: 2px solid #404040;
            }}
        """)

    def setColor(self, color: QColor):
        """设置按钮显示的颜色"""
        self._color = color
        self._updateStyle()

    def getColor(self) -> QColor:
        """获取当前颜色"""
        return self._color


class StylePanel(QWidget):
    """
    样式面板 - 用于编辑选中节点的样式
    当画布上有节点被选中时显示，贴合在canvas下方
    """

    # 信号定义
    styleChanged = pyqtSignal()  # 样式改变信号

    def __init__(self, parent: Optional[QWidget] = None) -> None:
        """
        初始化样式面板

        Args:
            parent: 父窗口（通常是NodeCanvas）
        """
        super().__init__(parent)

        self._selected_nodes: List[NodeItem] = []
        self._is_updating_ui: bool = False

        self._setupUI()
        self._connectSignals()
        self.hide()

    def _setupUI(self) -> None:
        """设置UI组件"""
        # 主布局
        main_layout = QHBoxLayout(self)
        main_layout.setContentsMargins(15, 6, 15, 6)
        main_layout.setSpacing(12)

        # 1. 字体区域
        font_group = self._createFontGroup()
        main_layout.addWidget(font_group)

        # 分隔线
        main_layout.addWidget(self._createSeparator())

        # 2. 填充色区域
        fill_group = self._createFillColorGroup()
        main_layout.addWidget(fill_group)

        # 分隔线
        main_layout.addWidget(self._createSeparator())

        # 3. 边框区域
        border_group = self._createBorderGroup()
        main_layout.addWidget(border_group)

        # 分隔线
        main_layout.addWidget(self._createSeparator())

        # 4. 大小区域
        size_group = self._createSizeGroup()
        main_layout.addWidget(size_group)

        # 弹性空间
        main_layout.addStretch()

        # 设置面板样式 - 参考Excel样式
        self.setStyleSheet("""
            /* 面板整体样式 */
            StylePanel {
                background-color: #f3f3f3;
                border-top: 1px solid #d4d4d4;
                border-bottom: 1px solid #d4d4d4;
            }

            /* 标签样式 */
            QLabel {
                color: #424242;
                font-size: 12px;
                font-family: "Segoe UI", "Microsoft YaHei", sans-serif;
            }

            /* 下拉框样式 */
            QComboBox {
                padding: 4px 8px;
                border: 1px solid #c8c8c8;
                background-color: white;
                border-radius: 2px;
                min-height: 22px;
                font-size: 12px;
            }
            QComboBox:hover {
                border: 1px solid #a0a0a0;
            }
            QComboBox:focus {
                border: 1px solid #2b579a;
            }
            QComboBox::drop-down {
                border: none;
                width: 20px;
            }
            QComboBox::down-arrow {
                image: none;
                border-left: 4px solid transparent;
                border-right: 4px solid transparent;
                border-top: 5px solid #666;
                width: 0;
                height: 0;
            }

            /* 数字输入框样式 */
            QSpinBox {
                padding: 4px 8px;
                border: 1px solid #c8c8c8;
                background-color: white;
                border-radius: 2px;
                min-height: 22px;
                font-size: 12px;
            }
            QSpinBox:hover {
                border: 1px solid #a0a0a0;
            }
            QSpinBox:focus {
                border: 1px solid #2b579a;
            }
            QSpinBox::up-button, QSpinBox::down-button {
                width: 16px;
                border: none;
                background: #f0f0f0;
            }
            QSpinBox::up-button:hover, QSpinBox::down-button:hover {
                background: #e0e0e0;
            }
            QSpinBox::up-button {
                border-bottom: 1px solid #c8c8c8;
            }

            /* 滑块样式 */
            QSlider::groove:horizontal {
                height: 4px;
                background: #e0e0e0;
                border-radius: 2px;
            }
            QSlider::sub-page:horizontal {
                background: #2b579a;
                border-radius: 2px;
            }
            QSlider::handle:horizontal {
                width: 14px;
                height: 14px;
                margin: -5px 0;
                background: white;
                border: 1px solid #a0a0a0;
                border-radius: 7px;
            }
            QSlider::handle:horizontal:hover {
                background: #f0f0f0;
                border: 1px solid #808080;
            }

            /* 增量按钮样式 (A+, A-, B+, B-, R+, R-) */
            QPushButton#incrementBtn {
                padding: 2px 6px;
                border: 1px solid #c8c8c8;
                background-color: white;
                border-radius: 2px;
                font-size: 11px;
                font-weight: bold;
                color: #424242;
                min-width: 24px;
                min-height: 22px;
            }
            QPushButton#incrementBtn:hover {
                background-color: #e5f3ff;
                border: 1px solid #2b579a;
            }
            QPushButton#incrementBtn:pressed {
                background-color: #cce4ff;
            }

            /* 颜色按钮基础样式 */
            ColorButton {
                border-radius: 12px;
            }
        """)

    def _createFontGroup(self) -> QFrame:
        """创建字体选择区域"""
        frame = QFrame()
        layout = QHBoxLayout(frame)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)

        # 字体选择
        font_label = QLabel("字体:")
        font_label.setStyleSheet("font-weight: bold;")
        layout.addWidget(font_label)

        self._font_combo = QComboBox()
        self._font_combo.setFixedWidth(110)
        fonts = QFontDatabase.families()
        self._font_combo.addItem("-")
        self._font_combo.addItems(fonts[:20])  # 只添加前20个常用字体
        self._font_combo.setCurrentIndex(0)
        layout.addWidget(self._font_combo)

        # 字号
        size_label = QLabel("字号:")
        layout.addWidget(size_label)

        self._font_size_spin = QSpinBox()
        self._font_size_spin.setRange(6, 72)
        self._font_size_spin.setValue(12)
        self._font_size_spin.setFixedWidth(50)
        self._font_size_spin.setSpecialValueText("-")
        layout.addWidget(self._font_size_spin)

        # A+ A- 按钮
        self._font_size_up_btn = QPushButton("A+")
        self._font_size_up_btn.setObjectName("incrementBtn")
        self._font_size_up_btn.setToolTip("增大字号")
        layout.addWidget(self._font_size_up_btn)

        self._font_size_down_btn = QPushButton("A-")
        self._font_size_down_btn.setObjectName("incrementBtn")
        self._font_size_down_btn.setToolTip("减小字号")
        layout.addWidget(self._font_size_down_btn)

        return frame

    def _createFillColorGroup(self) -> QFrame:
        """创建填充色选择区域"""
        frame = QFrame()
        layout = QHBoxLayout(frame)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)

        label = QLabel("填充色:")
        label.setStyleSheet("font-weight: bold;")
        layout.addWidget(label)

        self._fill_color_btn = ColorButton(color=QColor(128, 128, 128))
        self._fill_color_btn.setToolTip("点击选择填充颜色")
        layout.addWidget(self._fill_color_btn)

        return frame

    def _createBorderGroup(self) -> QFrame:
        """创建边框选择区域"""
        frame = QFrame()
        layout = QHBoxLayout(frame)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)

        # 厚度标签和滑块
        label = QLabel("边框:")
        label.setStyleSheet("font-weight: bold;")
        layout.addWidget(label)

        self._border_slider = QSlider(Qt.Orientation.Horizontal)
        self._border_slider.setRange(0, 10)
        self._border_slider.setValue(1)
        self._border_slider.setFixedWidth(70)
        layout.addWidget(self._border_slider)

        # 厚度值显示
        self._border_value_label = QLabel("1")
        self._border_value_label.setFixedWidth(15)
        self._border_value_label.setStyleSheet("color: #666;")
        layout.addWidget(self._border_value_label)

        # B+ B- 按钮
        self._border_up_btn = QPushButton("B+")
        self._border_up_btn.setObjectName("incrementBtn")
        self._border_up_btn.setToolTip("增加边框厚度")
        layout.addWidget(self._border_up_btn)

        self._border_down_btn = QPushButton("B-")
        self._border_down_btn.setObjectName("incrementBtn")
        self._border_down_btn.setToolTip("减小边框厚度")
        layout.addWidget(self._border_down_btn)

        # 边框颜色
        self._border_color_btn = ColorButton(color=QColor(51, 51, 51))
        self._border_color_btn.setToolTip("点击选择边框颜色")
        layout.addWidget(self._border_color_btn)

        return frame

    def _createSizeGroup(self) -> QFrame:
        """创建大小选择区域"""
        frame = QFrame()
        layout = QHBoxLayout(frame)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)

        label = QLabel("节点大小:")
        label.setStyleSheet("font-weight: bold;")
        layout.addWidget(label)

        self._size_slider = QSlider(Qt.Orientation.Horizontal)
        self._size_slider.setRange(20, 150)
        self._size_slider.setValue(40)
        self._size_slider.setFixedWidth(90)
        layout.addWidget(self._size_slider)

        self._size_value_label = QLabel("40")
        self._size_value_label.setFixedWidth(25)
        self._size_value_label.setStyleSheet("color: #666;")
        layout.addWidget(self._size_value_label)

        # R+ R- 按钮
        self._size_up_btn = QPushButton("R+")
        self._size_up_btn.setObjectName("incrementBtn")
        self._size_up_btn.setToolTip("增大节点")
        layout.addWidget(self._size_up_btn)

        self._size_down_btn = QPushButton("R-")
        self._size_down_btn.setObjectName("incrementBtn")
        self._size_down_btn.setToolTip("减小节点")
        layout.addWidget(self._size_down_btn)

        return frame

    def _createSeparator(self) -> QFrame:
        """创建垂直分隔线"""
        line = QFrame()
        line.setFrameShape(QFrame.Shape.VLine)
        line.setStyleSheet("color: #d4d4d4; margin: 0 4px;")
        line.setFixedWidth(2)
        return line

    def _connectSignals(self) -> None:
        """连接信号槽"""
        # 字体变化
        self._font_combo.currentTextChanged.connect(self._onFontChanged)
        self._font_size_spin.valueChanged.connect(self._onFontSizeChanged)
        self._font_size_up_btn.clicked.connect(self._onFontSizeUp)
        self._font_size_down_btn.clicked.connect(self._onFontSizeDown)

        # 填充色
        self._fill_color_btn.clicked.connect(self._onFillColorClicked)

        # 边框
        self._border_slider.valueChanged.connect(self._onBorderWidthChanged)
        self._border_up_btn.clicked.connect(self._onBorderUp)
        self._border_down_btn.clicked.connect(self._onBorderDown)
        self._border_color_btn.clicked.connect(self._onBorderColorClicked)

        # 大小
        self._size_slider.valueChanged.connect(self._onSizeChanged)
        self._size_up_btn.clicked.connect(self._onSizeUp)
        self._size_down_btn.clicked.connect(self._onSizeDown)

    # ========== 事件处理方法（与之前相同）==========

    def _onFontChanged(self, font_family: str) -> None:
        """字体改变"""
        if self._is_updating_ui or font_family == "-":
            return
        for node in self._selected_nodes:
            node.setFont(family=font_family)
        self.styleChanged.emit()

    def _onFontSizeChanged(self, size: int) -> None:
        """字号改变（绝对设置）"""
        if self._is_updating_ui:
            return
        for node in self._selected_nodes:
            node.setFont(size=size)
        self.styleChanged.emit()

    def _onFontSizeUp(self) -> None:
        """字号增加（相对调整）"""
        for node in self._selected_nodes:
            current_size = node.fontSize
            node.setFont(size=current_size + 1)
        self._updateUIFromNodes()
        self.styleChanged.emit()

    def _onFontSizeDown(self) -> None:
        """字号减小（相对调整）"""
        for node in self._selected_nodes:
            current_size = node.fontSize
            if current_size > 6:
                node.setFont(size=current_size - 1)
        self._updateUIFromNodes()
        self.styleChanged.emit()

    def _onFillColorClicked(self) -> None:
        """点击填充色按钮"""
        color = QColorDialog.getColor(
            self._fill_color_btn.getColor(),
            self,
            "选择填充颜色"
        )
        if color.isValid():
            self._fill_color_btn.setColor(color)
            for node in self._selected_nodes:
                node.setColor(color)
            self.styleChanged.emit()

    def _onBorderWidthChanged(self, width: int) -> None:
        """边框厚度改变（绝对设置）"""
        if self._is_updating_ui:
            return
        self._border_value_label.setText(str(width))
        for node in self._selected_nodes:
            if width == 0:
                node.setBorder(0)
            else:
                current_color = node.strokeColor
                node.setBorder(width, current_color)
        self.styleChanged.emit()

    def _onBorderUp(self) -> None:
        """边框增加（相对调整）"""
        for node in self._selected_nodes:
            current_width = int(node.strokeWidth)
            if current_width < 10:
                current_color = node.strokeColor
                node.setBorder(current_width + 1, current_color)
        self._updateUIFromNodes()
        self.styleChanged.emit()

    def _onBorderDown(self) -> None:
        """边框减小（相对调整）"""
        for node in self._selected_nodes:
            current_width = int(node.strokeWidth)
            if current_width > 0:
                current_color = node.strokeColor
                node.setBorder(max(0, current_width - 1), current_color)
        self._updateUIFromNodes()
        self.styleChanged.emit()

    def _onBorderColorClicked(self) -> None:
        """点击边框色按钮"""
        color = QColorDialog.getColor(
            self._border_color_btn.getColor(),
            self,
            "选择边框颜色"
        )
        if color.isValid():
            self._border_color_btn.setColor(color)
            for node in self._selected_nodes:
                current_width = int(node.strokeWidth)
                if current_width > 0:
                    node.setBorder(current_width, color)
            self.styleChanged.emit()

    def _onSizeChanged(self, size: int) -> None:
        """大小改变（绝对设置）"""
        if self._is_updating_ui:
            return
        self._size_value_label.setText(str(size))
        for node in self._selected_nodes:
            node.setRadius(size)
        self.styleChanged.emit()

    def _onSizeUp(self) -> None:
        """大小增加（相对调整）"""
        for node in self._selected_nodes:
            current_radius = node.radius
            node.setRadius(current_radius + 5)
        self._updateUIFromNodes()
        self.styleChanged.emit()

    def _onSizeDown(self) -> None:
        """大小减小（相对调整）"""
        for node in self._selected_nodes:
            current_radius = node.radius
            if current_radius > 20:
                node.setRadius(current_radius - 5)
        self._updateUIFromNodes()
        self.styleChanged.emit()

    # ========== 公共方法（与之前相同）==========

    def setSelectedNodes(self, nodes: List[NodeItem]) -> None:
        """
        设置当前选中的节点列表

        Args:
            nodes: 选中的节点列表
        """
        self._selected_nodes = nodes

        if not nodes:
            self.hide()
            return

        self.show()
        self._updateUIFromNodes()

    def _updateUIFromNodes(self) -> None:
        """从节点数据更新UI显示（处理混合状态）"""
        if not self._selected_nodes:
            return

        self._is_updating_ui = True

        # 1. 检查字体家族是否一致
        font_families = set(node.fontFamily for node in self._selected_nodes)
        if len(font_families) == 1:
            family = font_families.pop()
            index = self._font_combo.findText(family)
            if index >= 0:
                self._font_combo.setCurrentIndex(index)
            else:
                self._font_combo.setCurrentText(family)
        else:
            self._font_combo.setCurrentIndex(0)

        # 2. 检查字号是否一致
        font_sizes = set(node.fontSize for node in self._selected_nodes)
        if len(font_sizes) == 1:
            self._font_size_spin.setValue(font_sizes.pop())
        else:
            self._font_size_spin.setValue(6)

        # 3. 检查填充色是否一致
        fill_colors = set(node.fillColor.name() for node in self._selected_nodes)
        if len(fill_colors) == 1:
            color = QColor(fill_colors.pop())
            self._fill_color_btn.setColor(color)
        else:
            self._fill_color_btn.setColor(QColor(128, 128, 128))

        # 4. 检查边框厚度是否一致
        border_widths = set(int(node.strokeWidth) for node in self._selected_nodes)
        if len(border_widths) == 1:
            width = border_widths.pop()
            self._border_slider.setValue(width)
            self._border_value_label.setText(str(width))
        else:
            self._border_slider.setValue(1)
            self._border_value_label.setText("-")

        # 5. 检查边框颜色是否一致
        border_colors = set(node.strokeColor.name() for node in self._selected_nodes)
        if len(border_colors) == 1:
            color = QColor(border_colors.pop())
            self._border_color_btn.setColor(color)
        else:
            self._border_color_btn.setColor(QColor(128, 128, 128))

        # 6. 检查大小是否一致
        sizes = set(int(node.radius) for node in self._selected_nodes)
        if len(sizes) == 1:
            size = sizes.pop()
            self._size_slider.setValue(size)
            self._size_value_label.setText(str(size))
        else:
            self._size_slider.setValue(40)
            self._size_value_label.setText("-")

        self._is_updating_ui = False

    def getSelectedNodes(self) -> List[NodeItem]:
        """获取当前选中的节点列表"""
        return self._selected_nodes.copy()
