from qwork.qfsm import Logic
from PyQt6.QtWidgets import QWidget, QHBoxLayout, QVBoxLayout


class QFlowChart(QWidget):
    pass
