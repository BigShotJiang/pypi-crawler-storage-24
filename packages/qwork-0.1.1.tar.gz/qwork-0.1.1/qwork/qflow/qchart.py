"""
qflow.qchart - PyQt6 widget for visualizing qfsm Stage/Logic state machines

This module provides QFlowChart, a reusable widget that visualizes qfsm state
machines with interactive execution controls.

Example:
    from qwork.qflow.qchart import QFlowChart
    from qwork.qfsm import Logic
    from PyQt6.QtWidgets import QApplication

    class MyLogic(Logic):
        NAME = "MyLogic"

        def start(self, inst):
            return "running"

        def running(self, inst):
            return None  # Stay in this state

    app = QApplication([])
    logic = MyLogic()
    chart = QFlowChart(logic=logic)
    chart.show()
    app.exec()
"""

from __future__ import annotations

from typing import Any, Optional

from PyQt6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel
)
from PyQt6.QtCore import Qt, QPointF, pyqtSignal, QObject, QTimer
from PyQt6.QtGui import QColor

from qwork.qfsm.stage import Stage
from qwork.qfsm.scheduler import Scheduler
from qwork.qfsm.utils import getES
from qwork.qnode.node_canvas import NodeCanvas
from qwork.qnode.enums import NodeShape, ConnectionType
from qwork.qnode.layout_utils import DenseLayoutEngine, ViewportFitter


class _EventBridge(QObject):
    """Bridge to marshal events from any thread to main thread via Qt signals."""
    stateChanged = pyqtSignal(dict)

    def __init__(self, handler: callable) -> None:
        super().__init__()
        self._handler = handler
        self.stateChanged.connect(self._onStateChanged)

    def _onStateChanged(self, data: dict) -> None:
        self._handler(data)

    def onEvent(self, data: dict) -> None:
        """Called from any thread - emits signal to main thread."""
        self.stateChanged.emit(data)


class QFlowChart(QWidget):
    """
    PyQt6 widget for visualizing and interacting with qfsm state machines.

    Features:
    - Visual node graph display (auto-generated from Stage/Logic states)
    - Step-by-step execution with manual control
    - Auto-execution mode
    - State highlighting and transitions
    - Thread-safe event handling

    Attributes:
        stage: The Stage/Logic instance being visualized
        scheduler: The Scheduler singleton instance

    Example:
        # Simple usage with default controls
        logic = MyLogic()
        chart = QFlowChart(logic=logic)
        chart.show()

        # Custom control (no built-in buttons)
        chart = QFlowChart(logic=logic, show_controls=False)
        chart.doStep()  # Manual step
    """

    # Default colors
    COLOR_DEFAULT = "#F5F5F5"
    COLOR_BORDER = "#666666"
    COLOR_ACTIVE = "#4CAF50"
    COLOR_ACTIVE_BORDER = "#2E7D32"
    COLOR_FINISHED = "#FF6B6B"

    def __init__(
        self,
        stage: Stage | None = None,
        show_controls: bool = True,
        parent: QWidget | None = None
    ) -> None:
        """
        Initialize QFlowChart.

        Args:
            stage: Stage/Logic instance to visualize (can be set later via setStage)
            show_controls: Whether to show control buttons (step)
            parent: Parent widget
        """
        super().__init__(parent)

        # Core components
        self._stage: Stage | None = None
        self._scheduler: Scheduler = Scheduler()
        self._event_bridge: _EventBridge | None = None

        # Node mapping: state_name -> NodeItem
        self._nodemap: dict[str, Any] = {}
        self._current_node: Any | None = None

        # UI options
        self._show_controls = show_controls

        # Layout pending flag (for deferred layout when viewport not ready)
        self._layout_pending = False

        # Setup UI
        self._setupUi()

        # Set stage if provided
        if stage is not None:
            self.setStage(stage)
            

    def _setupUi(self) -> None:
        """Setup the user interface."""
        self._layout = QVBoxLayout(self)
        self._layout.setContentsMargins(10, 10, 10, 10)
        self._layout.setSpacing(10)

        # Node Canvas
        self._canvas = NodeCanvas(self)
        self._layout.addWidget(self._canvas, stretch=1)

        # Control panel
        self._ctrl_layout = QHBoxLayout()
        self._ctrl_layout.setSpacing(10)

        # Info label
        self._infolbl = QLabel("State: - | Now: 0")
        self._infolbl.setStyleSheet("""
            QLabel {
                background-color: #333;
                color: #0F0;
                padding: 8px 15px;
                border-radius: 4px;
                font-family: Consolas, Monaco, monospace;
                font-size: 12px;
                font-weight: bold;
            }
        """)
        self._ctrl_layout.addWidget(self._infolbl)
        self._ctrl_layout.addStretch()

        # Control buttons
        if self._show_controls:
            self._btn_step = QPushButton("Next Step")
            self._btn_step.setToolTip("Execute one step")
            self._btn_step.clicked.connect(self.doStep)
            self._btn_step.setStyleSheet("""
                QPushButton {
                    background-color: #4CAF50;
                    color: white;
                    padding: 8px 20px;
                    font-weight: bold;
                }
                QPushButton:hover {
                    background-color: #45a049;
                }
                QPushButton:disabled {
                    background-color: #cccccc;
                    color: #666666;
                }
            """)
            self._ctrl_layout.addWidget(self._btn_step)

        self._layout.addLayout(self._ctrl_layout)

    @property
    def stage(self) -> Stage | None:
        """Get the current Stage/Logic instance."""
        return self._stage

    @property
    def scheduler(self) -> Scheduler:
        """Get the scheduler instance."""
        return self._scheduler

    def setStage(self, stage: Stage) -> None:
        """
        Set or change the Stage/Logic instance to visualize.

        Args:
            stage: Stage/Logic instance to visualize
        """
        # Cleanup previous
        self._cleanup()

        self._stage = stage

        # Build node graph from stage states
        self._buildGraph()

        # Setup event bridge for async updates
        self._event_bridge = _EventBridge(self._onStateChanged)
        stage.listenFor("changed", self._event_bridge.onEvent)

        # Initial highlight and info update
        current = stage.current
        self._highlightNode(current or "-")
        self._updateInfo(current)

        self._updateButtons()
        

    def _buildGraph(self) -> None:
        """Build node graph from stage states with auto-layout."""
        self._canvas.clear()
        self._nodemap.clear()
        self._current_node = None

        if self._stage is None:
            return

        states = self._stage.states
        if not states:
            return

        # Create nodes at origin first (layout engine will position them)
        for state in states:
            shape = self._getShapeForState(state)
            node = self._canvas.addNode(state, QPointF(0, 0), shape)
            self._nodemap[state] = node

        # Create edges between states
        self._createEdges(states)

        # Apply auto layout and fit viewport
        self._doAutoLayout()

    def _doAutoLayout(self) -> None:
        """Apply auto-layout and fit viewport to show all nodes."""
        if not self._nodemap:
            return

        # Check if viewport is ready (has valid size)
        viewport = self._canvas.viewport()
        if viewport.width() <= 0 or viewport.height() <= 0:
            # Viewport not ready, defer layout
            self._layout_pending = True
            return

        self._layout_pending = False
        node_count = len(self._nodemap)

        if node_count == 1:
            # Single node: just center it
            ViewportFitter(self._canvas).centerOnNodes()
        elif node_count > 1:
            # Multiple nodes: apply hierarchical layout
            engine = DenseLayoutEngine(self._canvas)
            engine.autoLayout("hierarchical")
            # Fit viewport with margin to show all nodes
            ViewportFitter(self._canvas).fitViewport(margin=50)

        # Force update
        self._canvas.viewport().update()

    def relayout(self) -> None:
        """
        Re-apply auto-layout to current graph.

        Call this after manual node movement or when the graph needs reorganization.
        """
        self._doAutoLayout()

    def _fitViewport(self) -> None:
        """Fit viewport to show all nodes without recalculating layout."""
        if not self._nodemap:
            return

        viewport = self._canvas.viewport()
        if viewport.width() <= 0 or viewport.height() <= 0:
            return

        node_count = len(self._nodemap)
        if node_count == 1:
            ViewportFitter(self._canvas).centerOnNodes()
        else:
            ViewportFitter(self._canvas).fitViewport(margin=50)

        self._canvas.viewport().update()

    def showEvent(self, event) -> None:
        """Handle widget show event - perform deferred layout if needed."""
        super().showEvent(event)

        # If layout was deferred due to viewport not being ready, do it now
        if self._layout_pending and self._nodemap:
            # Use single shot timer to ensure viewport has correct size
            QTimer.singleShot(0, self._doAutoLayout)

    def resizeEvent(self, event) -> None:
        """Handle resize event - re-fit viewport to new size."""
        super().resizeEvent(event)

        # Only refit if we have nodes and layout is not pending
        if self._nodemap and not self._layout_pending:
            # Use timer to avoid excessive refitting during resize
            QTimer.singleShot(100, self._fitViewport)

    def _getShapeForState(self, state: str) -> NodeShape:
        """Determine node shape based on state name."""
        lower = state.lower()
        if "entry" in lower or lower == "start":
            return NodeShape.ELLIPSE
        if "exit" in lower or lower == "end" or lower == "stop":
            return NodeShape.ELLIPSE
        if "decision" in lower or "check" in lower or "if" in lower:
            return NodeShape.DIAMOND
        return NodeShape.RECTANGLE

    def _createEdges(self, states: list[str]) -> None:
        """
        Create edges between states based on possible transitions.

        This is a best-effort approach since Stage doesn't expose
        explicit transition information directly.
        """
        # For now, create edges based on naming patterns
        # A more sophisticated approach would parse the AST
        for i, state in enumerate(states):
            if i < len(states) - 1:
                next_state = states[i + 1]
                if state in self._nodemap and next_state in self._nodemap:
                    self._canvas.addConnection(
                        self._nodemap[state],
                        self._nodemap[next_state],
                        connection_type=ConnectionType.BEZIER
                    )

    def _highlightNode(self, state: str) -> None:
        """Highlight the current active node."""
        # Reset previous
        if self._current_node is not None:
            self._current_node.setColor(QColor(self.COLOR_DEFAULT))
            self._current_node.setBorder(2, QColor(self.COLOR_BORDER))

        # Highlight new
        if state in self._nodemap:
            node = self._nodemap[state]
            node.setColor(QColor(self.COLOR_ACTIVE))
            node.setBorder(2, QColor(self.COLOR_ACTIVE_BORDER))
            self._current_node = node

        self._canvas.viewport().update()

    def _updateInfo(self, state: str | None = None) -> None:
        """Update the info label."""
        if state is None:
            state = self._stage.current if self._stage else "-"
        now = self._stage.now if self._stage else 0
        self._infolbl.setText(f"State: {state} | Now: {now}")

    def _isFinished(self) -> bool:
        """Check if execution has finished."""
        if self._stage is None:
            return True
        # Check for Logic instances
        if hasattr(self._stage, "alive"):
            return not self._stage.alive
        # Check if current state is exit-like
        if self._stage.current in ("exit", "end", "stop", None):
            return True
        return False

    def _updateButtons(self) -> None:
        """Update button states."""
        if not self._show_controls:
            return
        self._btn_step.setEnabled(not self._isFinished())

    def doStep(self) -> None:
        """
        Execute one step of the state machine.

        Triggers an immediate scheduler tick.
        Safe to call from UI thread.
        """
        if self._isFinished():
            return

        self._scheduler.handle()

    def doRun(self, ticks: int = 1) -> None:
        """
        Execute multiple steps.

        Args:
            ticks: Number of ticks to execute
        """
        for _ in range(ticks):
            if self._isFinished():
                break
            self.doStep()

    def _onStateChanged(self, data: dict) -> None:
        """Handle state change event from event system."""
        to_state = data.get("new")

        if to_state:
            self._highlightNode(to_state)
            self._updateInfo(to_state)

        self._updateButtons()

        # Visual feedback for finished state
        if to_state in ("exit", "end", "stop"):
            self._infolbl.setStyleSheet("""
                QLabel {
                    background-color: #333;
                    color: #FF6B6B;
                    padding: 8px 15px;
                    border-radius: 4px;
                    font-family: Consolas, Monaco, monospace;
                    font-size: 12px;
                    font-weight: bold;
                }
            """)

    def _cleanup(self) -> None:
        """Cleanup resources."""
        # Cancel listener from current stage
        if self._stage is not None and self._event_bridge is not None:
            try:
                self._stage.cancelListen("changed", self._event_bridge.onEvent)
            except Exception:
                pass

        # Delete event bridge
        if self._event_bridge is not None:
            self._event_bridge.deleteLater()
            self._event_bridge = None

        self._stage = None

    def kill(self) -> None:
        """
        Kill the underlying Stage/Logic instance.

        This marks the logic as not alive and triggers cleanup.
        Safe to call multiple times.
        """
        if self._stage is not None and hasattr(self._stage, "kill"):
            self._stage.kill()

    def closeEvent(self, event) -> None:
        """Handle widget close - automatically kills the stage."""
        self.kill()
        self._cleanup()
        event.accept()


__all__ = [
    "QFlowChart",
]
