"""
qflow.chart - IChart interface for qnode <-> qfsm conversion

This module provides the IChart interface that serves as a data carrier
describing a node graph and its logic, enabling conversion between:
- qnode JSON format (visual node graph)
- qfsm Stage/Logic classes (finite state machine)
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, ClassVar, Type, TYPE_CHECKING, Union
from dataclasses import dataclass, field

if TYPE_CHECKING:
    from qwork.qfsm.stage import Stage
    from qwork.qfsm.logic import Logic


@dataclass
class ChartNode:
    """
    Data class representing a node in the chart.

    Attributes:
        nid: Unique node identifier
        name: Node display name
        ntype: Node type (state, logic, entry, exit, etc.)
        shape: Visual shape (ellipse, rectangle, diamond)
        data: Custom node data
        states: List of state names if this is a compound node
    """
    nid: str
    name: str
    ntype: str = "state"
    shape: str = "rectangle"
    data: dict[str, Any] = field(default_factory=dict)
    states: list[str] = field(default_factory=list)


@dataclass
class ChartEdge:
    """
    Data class representing an edge/connection in the chart.

    Attributes:
        eid: Unique edge identifier
        src: Source node ID
        dst: Destination node ID
        label: Edge label/condition
        etype: Edge type (transition, event, flow)
        bidirectional: Whether edge is bidirectional
    """
    eid: str
    src: str
    dst: str
    label: str = ""
    etype: str = "transition"
    bidirectional: bool = False


@dataclass
class ChartLogic:
    """
    Data class representing logic configuration for a node.

    Attributes:
        node_id: Associated node ID
        logic_type: Logic class type (Stage, Logic, etc.)
        priority: Execution priority for Logic instances
        decorators: List of decorators to apply
        states: State method definitions
        listeners: Event listener definitions
    """
    node_id: str
    logic_type: str = "Stage"
    priority: int = 0
    decorators: list[dict[str, Any]] = field(default_factory=list)
    states: dict[str, str] = field(default_factory=dict)
    listeners: list[dict[str, Any]] = field(default_factory=list)


class IChart(ABC):
    """
    Interface for chart data conversion between qnode and qfsm.

    IChart serves as a bridge between:
    - qnode: Visual node graph representation (JSON)
    - qfsm: Finite state machine implementation (Stage/Logic)

    Implementations should handle:
    1. Parsing qnode JSON into internal node/edge representation
    2. Generating qfsm-compatible class definitions
    3. Converting visual graphs to executable state machines

    Example:
        # Load from qnode JSON
        chart = MyChart()
        chart.fromJson(json_data)

        # Generate qfsm Stage class
        stage_code = chart.toFsmStage()

        # Or create runtime instance
        stage = chart.createStage()
    """

    # Class-level metadata
    NAME: ClassVar[str] = "IChart"
    VERSION: ClassVar[str] = "1.0"

    def __init__(
        self,
        src: dict[str, Any] | 'Stage' | Type['Stage'] | 'Logic' | Type['Logic'] | None = None
    ):
        """
        Initialize chart, optionally from existing data.

        Args:
            src: Source data to initialize from:
                - dict: JSON data (qnode format or extractNodes format)
                - Stage: Parse from Stage instance or class
                - Logic: Parse from Logic instance or class
                - None: Create empty chart

        Note:
            IChart is an abstract base class. Use Chart for concrete implementation.
        """
        self._nodes: dict[str, ChartNode] = {}
        self._edges: dict[str, ChartEdge] = {}
        self._logics: dict[str, ChartLogic] = {}
        self._metadata: dict[str, Any] = {}

        if src is not None:
            self._initFrom(src)

    def _initFrom(
        self, src: dict[str, Any] | 'Stage' | Type['Stage'] | 'Logic' | Type['Logic']
    ) -> None:
        """Initialize chart from various source types (to be implemented by subclasses)."""
        raise NotImplementedError("Subclasses must implement _initFrom")

    # -------------------------------------------------------------------------
    # Properties
    # -------------------------------------------------------------------------

    @property
    def nodes(self) -> list[ChartNode]:
        """Get all nodes in the chart."""
        return list(self._nodes.values())

    @property
    def edges(self) -> list[ChartEdge]:
        """Get all edges in the chart."""
        return list(self._edges.values())

    @property
    def logics(self) -> list[ChartLogic]:
        """Get all logic configurations."""
        return list(self._logics.values())

    @property
    def startnode(self) -> str | None:
        """Get start node ID."""
        return self._metadata.get("startnode")

    @startnode.setter
    def startnode(self, nid: str | None) -> None:
        """Set start node ID."""
        self._metadata["startnode"] = nid

    # -------------------------------------------------------------------------
    # Node/Edge Management
    # -------------------------------------------------------------------------

    def addNode(self, node: ChartNode) -> None:
        """Add a node to the chart."""
        self._nodes[node.nid] = node

    def removeNode(self, nid: str) -> ChartNode | None:
        """Remove a node and return it, or None if not found."""
        return self._nodes.pop(nid, None)

    def getNode(self, nid: str) -> ChartNode | None:
        """Get node by ID."""
        return self._nodes.get(nid)

    def addEdge(self, edge: ChartEdge) -> None:
        """Add an edge to the chart."""
        self._edges[edge.eid] = edge

    def removeEdge(self, eid: str) -> ChartEdge | None:
        """Remove an edge and return it, or None if not found."""
        return self._edges.pop(eid, None)

    def getEdge(self, eid: str) -> ChartEdge | None:
        """Get edge by ID."""
        return self._edges.get(eid)

    def addLogic(self, logic: ChartLogic) -> None:
        """Add logic configuration for a node."""
        self._logics[logic.node_id] = logic

    def getLogic(self, nid: str) -> ChartLogic | None:
        """Get logic configuration for node."""
        return self._logics.get(nid)

    # -------------------------------------------------------------------------
    # Abstract Methods - Import/Export
    # -------------------------------------------------------------------------

    @abstractmethod
    def fromJson(self, data: dict[str, Any]) -> IChart:
        """
        Load chart from qnode JSON format.
        When converting to visual representation, auto-layout should be applied.

        Args:
            data: qnode exported JSON as dict

        Returns:
            Self for chaining
        """
        pass

    @abstractmethod
    def toJson(self) -> dict[str, Any]:
        """
        Export chart to qnode JSON format.

        Returns:
            Dict compatible with qnode import
        """
        pass

    @abstractmethod
    def toStage(self, inst: Any | None = None) -> 'Stage':
        """
        Create qfsm Stage instance from chart.

        Args:
            inst: Optional bound instance

        Returns:
            qfsm Stage instance
        """
        pass

    @abstractmethod
    def toLogic(self, inst: Any | None = None) -> 'Logic':
        """
        Create qfsm Logic instance from chart.

        Args:
            inst: Optional bound instance

        Returns:
            qfsm Logic instance
        """
        pass

    @abstractmethod
    def fromStage(self, stage: 'Stage') -> IChart:
        """
        Load chart from qfsm Stage instance.

        Args:
            stage: qfsm Stage instance to parse

        Returns:
            Self for chaining
        """
        pass

    @abstractmethod
    def fromLogic(self, logic: 'Logic') -> IChart:
        """
        Load chart from qfsm Logic instance.

        Args:
            logic: qfsm Logic instance to parse

        Returns:
            Self for chaining
        """
        pass

    @abstractmethod
    def toImage(self, width: int = 800, height: int = 600) -> Any:
        """
        Render chart to an image.

        Args:
            width: Image width in pixels
            height: Image height in pixels

        Returns:
            PIL Image object
        """
        pass

    # -------------------------------------------------------------------------
    # Utility Methods
    # -------------------------------------------------------------------------

    def clearChart(self) -> None:
        """Clear all nodes, edges and logics."""
        self._nodes.clear()
        self._edges.clear()
        self._logics.clear()
        self._metadata.clear()

    def getOutgoing(self, nid: str) -> list[ChartEdge]:
        """Get all outgoing edges from a node."""
        return [e for e in self._edges.values() if e.src == nid]

    def getIncoming(self, nid: str) -> list[ChartEdge]:
        """Get all incoming edges to a node."""
        return [e for e in self._edges.values() if e.dst == nid]

    def getConnected(self, nid: str) -> list[str]:
        """Get IDs of all nodes connected to given node."""
        connected = set()
        for edge in self._edges.values():
            if edge.src == nid:
                connected.add(edge.dst)
            elif edge.dst == nid:
                connected.add(edge.src)
        return list(connected)

    def validChart(self) -> tuple[bool, str]:
        """
        Validate chart integrity.

        Returns:
            Tuple of (is_valid, error_message)
        """
        # Check start node exists
        if self.startnode and self.startnode not in self._nodes:
            return False, f"Start node '{self.startnode}' not found"

        # Check edge endpoints exist
        for edge in self._edges.values():
            if edge.src not in self._nodes:
                return False, f"Edge {edge.eid}: source '{edge.src}' not found"
            if edge.dst not in self._nodes:
                return False, f"Edge {edge.eid}: destination '{edge.dst}' not found"

        # Check logic references exist
        for logic in self._logics.values():
            if logic.node_id not in self._nodes:
                return False, f"Logic for non-existent node '{logic.node_id}'"

        return True, ""

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(nodes={len(self._nodes)}, edges={len(self._edges)})"


class Chart(IChart):
    """
    Chart implementation of IChart interface.

    Provides bidirectional conversion between:
    - qnode JSON format (visual node graph)
    - qfsm Stage/Logic instances (executable state machines)

    Example:
        # Load from qnode JSON
        chart = Chart()
        chart.fromJson(json_data)

        # Convert to Stage instance
        stage = chart.toStage()

        # Or convert from existing Stage
        chart2 = Chart()
        chart2.fromStage(existing_stage)
        json_data = chart2.toJson()
    """

    NAME = "Chart"
    VERSION = "1.0"

    def __init__(
        self,
        src: dict[str, Any] | 'Stage' | Type['Stage'] | 'Logic' | Type['Logic'] | None = None
    ):
        """
        Initialize Chart, optionally from existing data.

        Args:
            src: Source data to initialize from:
                - dict: JSON data (qnode format or extractNodes format)
                - Stage: Parse from Stage instance or class
                - Logic: Parse from Logic instance or class
                - None: Create empty chart

        Example:
            # From JSON
            chart = Chart(json_data)

            # From Stage instance
            chart = Chart(my_stage)

            # From Stage class (no instantiation)
            chart = Chart(MyStage)

            # From Logic instance
            chart = Chart(my_logic)

            # From Logic class (no instantiation)
            chart = Chart(MyLogic)

            # Empty
            chart = Chart()
        """
        super().__init__(None)  # Don't init from src in parent, handle here
        self._stageClass: Type['Stage'] | None = None
        self._logicClass: Type['Logic'] | None = None

        if src is not None:
            self._initFrom(src)

    def _initFrom(
        self, src: dict[str, Any] | 'Stage' | Type['Stage'] | 'Logic' | Type['Logic']
    ) -> None:
        """Initialize chart from various source types."""
        if isinstance(src, dict):
            self.fromJson(src)
            return

        from qwork.qfsm.stage import Stage
        from qwork.qfsm.logic import Logic

        # Check if it's a Logic (instance or class)
        if isinstance(src, Logic) or (isinstance(src, type) and issubclass(src, Logic)):
            self.fromLogic(src)
        # Check if it's a Stage (instance or class)
        elif isinstance(src, Stage) or (isinstance(src, type) and issubclass(src, Stage)):
            self.fromStage(src)
        else:
            raise TypeError(f"Unsupported source type: {type(src).__name__}")

    def fromJson(self, data: dict[str, Any]) -> 'Chart':
        """
        Load chart from JSON format.

        Supports two formats:
        1. Standard qnode JSON: {"nodes": [...], "connections": [...]}
        2. extractNodes format: {state_name: {code, targets, decorates}}

        Args:
            data: JSON data as dict

        Returns:
            Self for chaining
        """
        self.clearChart()

        # Detect format: extractNodes format has no "nodes" key
        if "nodes" not in data and "connections" not in data:
            self._fromExtractNodesFormat(data)
            return self

        # Standard qnode JSON format
        # Load start node
        if "start_node_id" in data:
            start_id = data["start_node_id"]
            if start_id is not None:
                self.startnode = str(start_id)

        # Load nodes
        for node_data in data.get("nodes", []):
            node = ChartNode(
                nid=str(node_data["id"]),
                name=node_data.get("name", ""),
                ntype=node_data.get("type", "state"),
                shape=node_data.get("shape", "rectangle").lower(),
                data=node_data.get("data", {}),
                states=node_data.get("data", {}).get("states", [])
            )
            self.addNode(node)

        # Load connections as edges
        for conn_data in data.get("connections", []):
            edge = ChartEdge(
                eid=f"edge_{conn_data['source_id']}_{conn_data['target_id']}",
                src=str(conn_data["source_id"]),
                dst=str(conn_data["target_id"]),
                label=conn_data.get("label", ""),
                etype=conn_data.get("connection_type", "transition").lower(),
                bidirectional=conn_data.get("is_bidirectional", False)
            )
            self.addEdge(edge)

        return self

    def _fromExtractNodesFormat(self, data: dict[str, Any]) -> None:
        """
        Load from extractNodes() format: {state_name: {code, targets, decorates}}.

        Compatible with old _importDict() behavior.
        """
        node_map = {}  # name -> nid

        # Create nodes
        for i, (state_name, info) in enumerate(data.items()):
            nid = f"state_{i}"
            node_map[state_name] = nid

            node_data = {
                "code": info.get("code", ""),
                "targets": info.get("targets", []),
                "decorates": info.get("decorates", [])
            }

            node = ChartNode(
                nid=nid,
                name=state_name,
                ntype="state",
                shape="ellipse",
                data=node_data
            )
            self.addNode(node)

        # Create edges from targets
        for state_name, info in data.items():
            src_nid = node_map[state_name]
            for target in info.get("targets", []):
                if target in node_map:
                    dst_nid = node_map[target]
                    edge = ChartEdge(
                        eid=f"edge_{state_name}_{target}",
                        src=src_nid,
                        dst=dst_nid,
                        label=f"{state_name}->{target}",
                        etype="transition"
                    )
                    self.addEdge(edge)

        # Set start node
        if data:
            self.startnode = "state_0"

    def toJson(self) -> dict[str, Any]:
        """
        Export chart to qnode JSON format.

        Returns:
            Dict compatible with qnode import
        """
        nodes = []
        for node in self._nodes.values():
            node_data = {
                "id": node.nid,
                "name": node.name,
                "shape": node.shape.upper(),
                "type": node.ntype,
                "data": node.data.copy()
            }
            nodes.append(node_data)

        connections = []
        for edge in self._edges.values():
            conn_data = {
                "source_id": edge.src,
                "target_id": edge.dst,
                "label": edge.label,
                "is_bidirectional": edge.bidirectional,
                "connection_type": edge.etype.upper()
            }
            connections.append(conn_data)

        return {
            "nodes": nodes,
            "connections": connections,
            "start_node_id": self.startnode
        }

    def toStage(self, inst: Any | None = None) -> 'Stage':
        """
        Create qfsm Stage instance from chart.

        Dynamically creates a Stage subclass based on the chart structure
        and instantiates it.

        Args:
            inst: Optional bound instance

        Returns:
            qfsm Stage instance
        """
        if self._stageClass is None:
            self._stageClass = self._createStageClass()
        return self._stageClass(inst)

    def toLogic(self, inst: Any | None = None) -> 'Logic':
        """
        Create qfsm Logic instance from chart.

        Dynamically creates a Logic subclass based on the chart structure
        and instantiates it.

        Args:
            inst: Optional bound instance

        Returns:
            qfsm Logic instance
        """
        if self._logicClass is None:
            self._logicClass = self._createLogicClass()
        return self._logicClass(inst)

    def fromStage(self, src: 'Stage' | Type['Stage']) -> 'Chart':
        """
        Load chart from qfsm Stage instance or class.

        Parses the Stage's states, code, targets, and decorates into nodes and edges.
        Output format compatible with extractNodes().

        Args:
            src: qfsm Stage instance or class to parse

        Returns:
            Self for chaining

        Example:
            # From instance
            chart = Chart(my_stage)

            # From class (without instantiation)
            chart = Chart(MyStage)
        """
        import ast
        import inspect

        self.clearChart()

        # Handle class vs instance
        if isinstance(src, type):
            stage_class = src
            stage_instance = None
        else:
            stage_class = src.__class__
            stage_instance = src

        states = getattr(stage_class, "__states__", [])

        # Get source code for AST analysis
        try:
            source_file = inspect.getsourcefile(stage_class)
            if source_file:
                with open(source_file, 'r', encoding='utf-8') as f:
                    source = f.read()
                module_ast = ast.parse(source)

                # Find class definition
                class_node = None
                for node in ast.walk(module_ast):
                    if isinstance(node, ast.ClassDef) and node.name == stage_class.__name__:
                        class_node = node
                        break
            else:
                class_node = None
                source = ""
        except Exception:
            class_node = None
            source = ""

        # Build state -> method node mapping
        method_nodes = {}
        if class_node:
            for node in class_node.body:
                if isinstance(node, ast.FunctionDef) and node.name in states:
                    method_nodes[node.name] = node

        # Create node for each state with full data
        for i, state_name in enumerate(states):
            node_data = {"is_recursive": state_name in getattr(stage_class, "__recursive__", set())}

            # Extract code, targets, decorates from AST
            func_node = method_nodes.get(state_name)
            if func_node and source:
                # Extract function body code
                node_data["code"] = self._extractFunctionBody(source, func_node)

                # Extract targets (return string constants)
                node_data["targets"] = self._extractStaticTargets(func_node, state_name)

                # Extract decorates (excluding property)
                node_data["decorates"] = self._extractDecorators(func_node)

            node = ChartNode(
                nid=f"state_{i}",
                name=state_name,
                ntype="state",
                shape="ellipse",
                data=node_data
            )
            self.addNode(node)

            # Create edges from targets
            for target in node_data.get("targets", []):
                if target in states:
                    edge = ChartEdge(
                        eid=f"edge_{state_name}_{target}",
                        src=f"state_{i}",
                        dst=f"state_{states.index(target)}",
                        label=f"{state_name}->{target}",
                        etype="transition"
                    )
                    self.addEdge(edge)

        # Set start node to first state if exists
        if states:
            self.startnode = "state_0"

        return self

    def fromLogic(self, src: 'Logic' | Type['Logic']) -> 'Chart':
        """
        Load chart from qfsm Logic instance or class.

        Parses the Logic's states and properties into nodes and logic config.

        Args:
            src: qfsm Logic instance or class to parse

        Returns:
            Self for chaining

        Example:
            # From instance
            chart = Chart(my_logic)

            # From class (without instantiation)
            chart = Chart(MyLogic)
        """
        # Handle class vs instance
        if isinstance(src, type):
            logic_class = src
        else:
            logic_class = src.__class__

        self.fromStage(src)

        # Add logic-specific metadata
        for node in self._nodes.values():
            node.data["priority"] = getattr(logic_class, "PRIORITY", 0)
            node.data["logic_name"] = getattr(logic_class, "NAME", "Logic")

        return self

    def _createStageClass(self) -> Type['Stage']:
        """
        Dynamically create a Stage subclass from chart nodes/edges.

        Returns:
            New Stage subclass
        """
        # Build state methods from nodes
        methods: dict[str, Any] = {}

        for node in self._nodes.values():
            if node.ntype == "state":
                # Find outgoing transitions for this state
                outgoing = self.getOutgoing(node.nid)
                if outgoing:
                    # Create state method that returns target state
                    target_edge = outgoing[0]
                    target_node = self._nodes.get(target_edge.dst)
                    if target_node:
                        def makeStateMethod(target: str):
                            def stateMethod(self, inst: Any) -> str | None:
                                return target
                            return stateMethod
                        methods[node.name] = makeStateMethod(target_node.name)
                else:
                    # Terminal state
                    def makeTerminalState():
                        def terminalState(self, inst: Any) -> None:
                            return None
                        return terminalState
                    methods[node.name] = makeTerminalState()

        # Create the class
        from qwork.qfsm.stage import Stage
        class_name = "ChartStage"
        return type(
            class_name,
            (Stage,),
            {
                "NAME": class_name,
                **methods
            }
        )

    def _createLogicClass(self) -> Type['Logic']:
        """
        Dynamically create a Logic subclass from chart nodes/edges.

        Returns:
            New Logic subclass
        """
        # Get base Stage class methods
        stage_class = self._createStageClass()

        # Extract methods from stage class (excluding __states__ etc)
        methods = {}
        for attr_name in dir(stage_class):
            if not attr_name.startswith("__") and not attr_name.endswith("__"):
                attr = getattr(stage_class, attr_name)
                if callable(attr) and not isinstance(attr, type):
                    methods[attr_name] = attr

        # Create Logic subclass
        from qwork.qfsm.logic import Logic
        class_name = "ChartLogic"
        return type(
            class_name,
            (Logic,),
            {
                "NAME": class_name,
                "PRIORITY": 0,
                **methods
            }
        )

    def _extractFunctionBody(self, source: str, func_node: Any) -> str:
        """Extract function body from source, removing def line and common indent."""
        import ast
        start_line = func_node.lineno
        end_line = getattr(func_node, 'end_lineno', start_line)

        lines = source.splitlines()
        if start_line > len(lines) or end_line > len(lines):
            return ""

        func_lines = lines[start_line - 1:end_line]
        body_lines = func_lines[1:]  # Remove def line

        if not body_lines:
            return ""

        # Calculate common indent
        first_body = body_lines[0]
        indent = len(first_body) - len(first_body.lstrip())

        cleaned = []
        for line in body_lines:
            if line.strip() == "":
                cleaned.append("")
            elif len(line) >= indent:
                cleaned.append(line[indent:])
            else:
                cleaned.append(line)

        return "\n".join(cleaned).rstrip()

    def _extractStaticTargets(self, func_node: Any, current_state: str) -> list[str]:
        """Extract return string constants as targets."""
        import ast
        targets = set()

        def _visit(node):
            if isinstance(node, ast.Return) and node.value:
                if isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
                    if node.value.value != current_state:
                        targets.add(node.value.value)
                elif hasattr(ast, 'Str') and isinstance(node.value, ast.Str):
                    if node.value.s != current_state:
                        targets.add(node.value.s)
            elif isinstance(node, (ast.If, ast.IfExp)):
                for child in ast.iter_child_nodes(node):
                    _visit(child)
            else:
                for child in ast.iter_child_nodes(node):
                    _visit(child)

        for stmt in func_node.body:
            _visit(stmt)

        return sorted(list(targets))

    def _extractDecorators(self, func_node: Any) -> list[str]:
        """Extract decorator names (excluding property)."""
        import ast
        decorates = []
        for dec in func_node.decorator_list:
            # Skip property decorator
            if isinstance(dec, ast.Name) and dec.id == 'property':
                continue
            if isinstance(dec, ast.Call) and isinstance(dec.func, ast.Name) and dec.func.id == 'property':
                continue

            # Get decorator name
            name = self._getDecoratorName(dec)
            if name:
                decorates.append(name)
        return decorates

    def _getDecoratorName(self, decorator: Any) -> str | None:
        """Get decorator name from AST node."""
        import ast
        if isinstance(decorator, ast.Name):
            return decorator.id
        elif isinstance(decorator, ast.Attribute):
            return decorator.attr
        elif isinstance(decorator, ast.Call):
            if isinstance(decorator.func, ast.Name):
                return decorator.func.id
            elif isinstance(decorator.func, ast.Attribute):
                return decorator.func.attr
        return None

    def toImage(self, width: int = 1200, height: int = 800) -> Any:
        """
        Render chart to a PNG image using qnode's PyQt6 components.

        Uses off-screen rendering with NodeCanvas for high-quality output.

        Args:
            width: Image width in pixels
            height: Image height in pixels

        Returns:
            PIL Image object
        """
        from PyQt6.QtWidgets import QApplication
        from PyQt6.QtCore import Qt, QRectF, QPointF
        from PyQt6.QtGui import QPainter, QPixmap, QColor
        from qwork.qnode import NodeCanvas, NodeShape, ConnectionType
        from qwork.qnode.layout_utils import DenseLayoutEngine, ViewportFitter
        from PIL import Image
        import tempfile
        import os

        # Create QApplication if needed (for off-screen rendering)
        app = QApplication.instance()
        if app is None:
            app = QApplication([])

        # Create canvas in off-screen mode
        canvas = NodeCanvas()
        canvas.setRenderHints(
            QPainter.RenderHint.Antialiasing |
            QPainter.RenderHint.SmoothPixmapTransform |
            QPainter.RenderHint.TextAntialiasing
        )

        # Prepare export data
        export_data = self.toJson()

        # Map shape strings to NodeShape
        shape_map = {
            "ellipse": NodeShape.ELLIPSE,
            "rectangle": NodeShape.RECTANGLE,
            "diamond": NodeShape.DIAMOND
        }

        # Create node mapping
        node_map = {}

        # Add nodes with random initial positions (layout will fix them)
        import random
        for node_data in export_data.get("nodes", []):
            nid = node_data["id"]
            name = node_data.get("name", "Unnamed")
            shape_name = node_data.get("shape", "ELLIPSE").lower()
            shape = shape_map.get(shape_name, NodeShape.ELLIPSE)

            # Random initial position (will be adjusted by layout)
            pos = QPointF(random.randint(-400, 400), random.randint(-300, 300))

            node = canvas.addNode(name, pos, shape)
            node.data.update(node_data.get("data", {}))
            node_map[nid] = node

        # Add connections
        for conn_data in export_data.get("connections", []):
            src_id = conn_data.get("source_id")
            dst_id = conn_data.get("target_id")

            if src_id in node_map and dst_id in node_map:
                is_bidir = conn_data.get("is_bidirectional", False)
                conn_type = ConnectionType.BEZIER  # Always use bezier for nice curves

                conn = canvas.addConnection(
                    node_map[src_id], node_map[dst_id],
                    is_bidirectional=is_bidir,
                    connection_type=conn_type
                )
                # Set label if available
                label = conn_data.get("label", "")
                if label and hasattr(conn, '_label_item'):
                    conn._label_item.setPlainText(label)

        # Apply auto layout
        if len(node_map) > 0:
            engine = DenseLayoutEngine(canvas)
            engine.autoLayout("compact")

            # Fit to viewport with padding
            fitter = ViewportFitter(canvas)
            fitter.fitViewport(margin=50)

        # Get scene bounding rect after layout
        scene_rect = canvas._scene.itemsBoundingRect()
        scene_rect = scene_rect.adjusted(-40, -40, 40, 40)  # Add padding

        # Calculate scale to fit scene into output image while maintaining aspect ratio
        scale_x = width / scene_rect.width()
        scale_y = height / scene_rect.height()
        scale = min(scale_x, scale_y) * 0.9  # 0.9 factor for some margin

        # Calculate the rendered scene size
        render_width = scene_rect.width() * scale
        render_height = scene_rect.height() * scale

        # Center the rendered scene in the output image
        offset_x = (width - render_width) / 2
        offset_y = (height - render_height) / 2

        # Create target rect (centered in output image)
        target_rect = QRectF(offset_x, offset_y, render_width, render_height)

        # Create pixmap for rendering
        pixmap = QPixmap(width, height)
        pixmap.fill(QColor(248, 250, 252))  # Light background

        # Render scene to pixmap
        painter = QPainter(pixmap)
        painter.setRenderHints(
            QPainter.RenderHint.Antialiasing |
            QPainter.RenderHint.SmoothPixmapTransform |
            QPainter.RenderHint.TextAntialiasing
        )

        # Render scene centered in the output image
        canvas._scene.render(
            painter,
            target_rect,
            scene_rect,
            Qt.AspectRatioMode.KeepAspectRatio
        )
        painter.end()

        # Convert QPixmap to PIL Image
        # Save to temp file (QPixmap doesn't support BytesIO directly in PyQt6)
        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tmp:
            tmp_path = tmp.name

        pixmap.save(tmp_path, "PNG")

        # Open with PIL and copy to memory (to allow temp file deletion on Windows)
        with Image.open(tmp_path) as img_temp:
            img = img_temp.copy()

        # Clean up temp file
        try:
            os.unlink(tmp_path)
        except PermissionError:
            pass  # File may still be locked on Windows

        return img
