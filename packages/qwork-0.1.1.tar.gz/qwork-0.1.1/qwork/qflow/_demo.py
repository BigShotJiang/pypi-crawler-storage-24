"""qflow._demo - Minimal demo for QFlowChart"""

from __future__ import annotations

from PyQt6.QtWidgets import QApplication, QMainWindow

from qwork.qflow.qchart import QFlowChart
from qwork.qfsm.logic import Logic


class DemoLogic(Logic):
    """entry -> running -> exit"""
    NAME = "DemoLogic"

    def entry(self, inst): return "running"
    def running(self, inst): return "exit" if self.now >= 3 else "running"
    def exit(self, inst): self._alive = False


class DemoWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("QFlowChart Demo")
        self.setGeometry(100, 100, 1000, 700)
        
        self.setCentralWidget(QFlowChart(DemoLogic(), parent=self))


if __name__ == "__main__":
    import sys

    app = QApplication(sys.argv)
    window = DemoWindow()
    window.show()
    sys.exit(app.exec())
