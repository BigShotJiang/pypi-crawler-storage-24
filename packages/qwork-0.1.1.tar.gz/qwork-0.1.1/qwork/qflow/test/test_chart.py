"""
qflow.chart module tests

Tests for IChart interface and FlowChart implementation.
"""

import unittest
from typing import Any

from qwork.qflow.chart import IChart, ChartNode, ChartEdge, ChartLogic
from qwork.qflow._demo import FlowChart, DemoChart
from qwork.qfsm.stage import Stage
from qwork.qfsm.logic import Logic


# Pre-defined Stage class for source extraction tests
class TestExtractStage(Stage):
    """Test Stage for code extraction tests."""
    NAME = "TestExtractStage"

    def idle(self, inst: Any) -> str:
        x = 1
        y = 2
        return "working"

    def working(self, inst: Any) -> str:
        return "idle"


class TestChartNode(unittest.TestCase):
    """Test ChartNode dataclass."""

    def testDefaultCreation(self) -> None:
        """Test creating ChartNode with defaults."""
        node = ChartNode(nid="n1", name="TestNode")
        self.assertEqual(node.nid, "n1")
        self.assertEqual(node.name, "TestNode")
        self.assertEqual(node.ntype, "state")
        self.assertEqual(node.shape, "rectangle")
        self.assertEqual(node.data, {})
        self.assertEqual(node.states, [])

    def testFullCreation(self) -> None:
        """Test creating ChartNode with all fields."""
        node = ChartNode(
            nid="n2",
            name="FullNode",
            ntype="logic",
            shape="ellipse",
            data={"key": "value"},
            states=["idle", "active"]
        )
        self.assertEqual(node.nid, "n2")
        self.assertEqual(node.name, "FullNode")
        self.assertEqual(node.ntype, "logic")
        self.assertEqual(node.shape, "ellipse")
        self.assertEqual(node.data["key"], "value")
        self.assertEqual(node.states, ["idle", "active"])


class TestChartEdge(unittest.TestCase):
    """Test ChartEdge dataclass."""

    def testDefaultCreation(self) -> None:
        """Test creating ChartEdge with defaults."""
        edge = ChartEdge(eid="e1", src="n1", dst="n2")
        self.assertEqual(edge.eid, "e1")
        self.assertEqual(edge.src, "n1")
        self.assertEqual(edge.dst, "n2")
        self.assertEqual(edge.label, "")
        self.assertEqual(edge.etype, "transition")
        self.assertFalse(edge.bidirectional)

    def testFullCreation(self) -> None:
        """Test creating ChartEdge with all fields."""
        edge = ChartEdge(
            eid="e2",
            src="n1",
            dst="n3",
            label="condition",
            etype="flow",
            bidirectional=True
        )
        self.assertEqual(edge.eid, "e2")
        self.assertEqual(edge.label, "condition")
        self.assertEqual(edge.etype, "flow")
        self.assertTrue(edge.bidirectional)


class TestChartLogic(unittest.TestCase):
    """Test ChartLogic dataclass."""

    def testDefaultCreation(self) -> None:
        """Test creating ChartLogic with defaults."""
        logic = ChartLogic(node_id="n1")
        self.assertEqual(logic.node_id, "n1")
        self.assertEqual(logic.logic_type, "Stage")
        self.assertEqual(logic.priority, 0)
        self.assertEqual(logic.decorators, [])
        self.assertEqual(logic.states, {})
        self.assertEqual(logic.listeners, [])

    def testFullCreation(self) -> None:
        """Test creating ChartLogic with all fields."""
        logic = ChartLogic(
            node_id="n2",
            logic_type="Logic",
            priority=10,
            decorators=[{"type": "sequence"}],
            states={"idle": "pass"},
            listeners=[{"event": "tick"}]
        )
        self.assertEqual(logic.node_id, "n2")
        self.assertEqual(logic.logic_type, "Logic")
        self.assertEqual(logic.priority, 10)
        self.assertEqual(len(logic.decorators), 1)


class TestIChart(unittest.TestCase):
    """Test IChart base class."""

    def testInit(self) -> None:
        """Test IChart initialization."""
        chart = FlowChart()
        self.assertEqual(chart.nodes, [])
        self.assertEqual(chart.edges, [])
        self.assertEqual(chart.logics, [])
        self.assertIsNone(chart.startnode)

    def testAddNode(self) -> None:
        """Test adding nodes."""
        chart = FlowChart()
        node = ChartNode(nid="n1", name="Node1")
        chart.addNode(node)
        self.assertEqual(len(chart.nodes), 1)
        self.assertEqual(chart.getNode("n1"), node)

    def testRemoveNode(self) -> None:
        """Test removing nodes."""
        chart = FlowChart()
        node = ChartNode(nid="n1", name="Node1")
        chart.addNode(node)
        removed = chart.removeNode("n1")
        self.assertEqual(removed, node)
        self.assertIsNone(chart.getNode("n1"))

    def testAddEdge(self) -> None:
        """Test adding edges."""
        chart = FlowChart()
        edge = ChartEdge(eid="e1", src="n1", dst="n2")
        chart.addEdge(edge)
        self.assertEqual(len(chart.edges), 1)
        self.assertEqual(chart.getEdge("e1"), edge)

    def testRemoveEdge(self) -> None:
        """Test removing edges."""
        chart = FlowChart()
        edge = ChartEdge(eid="e1", src="n1", dst="n2")
        chart.addEdge(edge)
        removed = chart.removeEdge("e1")
        self.assertEqual(removed, edge)
        self.assertIsNone(chart.getEdge("e1"))

    def testGetOutgoing(self) -> None:
        """Test getting outgoing edges."""
        chart = FlowChart()
        chart.addNode(ChartNode(nid="n1", name="Node1"))
        chart.addNode(ChartNode(nid="n2", name="Node2"))
        chart.addNode(ChartNode(nid="n3", name="Node3"))
        edge1 = ChartEdge(eid="e1", src="n1", dst="n2")
        edge2 = ChartEdge(eid="e2", src="n1", dst="n3")
        edge3 = ChartEdge(eid="e3", src="n2", dst="n3")
        chart.addEdge(edge1)
        chart.addEdge(edge2)
        chart.addEdge(edge3)

        outgoing = chart.getOutgoing("n1")
        self.assertEqual(len(outgoing), 2)
        self.assertIn(edge1, outgoing)
        self.assertIn(edge2, outgoing)

    def testGetIncoming(self) -> None:
        """Test getting incoming edges."""
        chart = FlowChart()
        chart.addNode(ChartNode(nid="n1", name="Node1"))
        chart.addNode(ChartNode(nid="n2", name="Node2"))
        chart.addNode(ChartNode(nid="n3", name="Node3"))
        edge1 = ChartEdge(eid="e1", src="n1", dst="n3")
        edge2 = ChartEdge(eid="e2", src="n2", dst="n3")
        chart.addEdge(edge1)
        chart.addEdge(edge2)

        incoming = chart.getIncoming("n3")
        self.assertEqual(len(incoming), 2)

    def testGetConnected(self) -> None:
        """Test getting connected nodes."""
        chart = FlowChart()
        chart.addNode(ChartNode(nid="n1", name="Node1"))
        chart.addNode(ChartNode(nid="n2", name="Node2"))
        chart.addNode(ChartNode(nid="n3", name="Node3"))
        chart.addEdge(ChartEdge(eid="e1", src="n1", dst="n2"))
        chart.addEdge(ChartEdge(eid="e2", src="n1", dst="n3", bidirectional=True))

        connected = chart.getConnected("n1")
        self.assertEqual(len(connected), 2)
        self.assertIn("n2", connected)
        self.assertIn("n3", connected)

    def testStartnode(self) -> None:
        """Test start node property."""
        chart = FlowChart()
        chart.startnode = "entry"
        self.assertEqual(chart.startnode, "entry")

    def testClearChart(self) -> None:
        """Test clearing chart."""
        chart = FlowChart()
        chart.addNode(ChartNode(nid="n1", name="Node1"))
        chart.addEdge(ChartEdge(eid="e1", src="n1", dst="n2"))
        chart.startnode = "n1"

        chart.clearChart()
        self.assertEqual(chart.nodes, [])
        self.assertEqual(chart.edges, [])
        self.assertIsNone(chart.startnode)

    def testValidChart(self) -> None:
        """Test chart validation."""
        chart = FlowChart()
        chart.addNode(ChartNode(nid="n1", name="Node1"))
        chart.addNode(ChartNode(nid="n2", name="Node2"))
        chart.addEdge(ChartEdge(eid="e1", src="n1", dst="n2"))

        valid, msg = chart.validChart()
        self.assertTrue(valid)
        self.assertEqual(msg, "")

    def testValidChartMissingStart(self) -> None:
        """Test validation with missing start node."""
        chart = FlowChart()
        chart.startnode = "missing"

        valid, msg = chart.validChart()
        self.assertFalse(valid)
        self.assertIn("Start node", msg)

    def testValidChartMissingEdgeSrc(self) -> None:
        """Test validation with missing edge source."""
        chart = FlowChart()
        chart.addNode(ChartNode(nid="n1", name="Node1"))
        chart.addEdge(ChartEdge(eid="e1", src="missing", dst="n1"))

        valid, msg = chart.validChart()
        self.assertFalse(valid)
        self.assertIn("source", msg)


class TestFlowChartJson(unittest.TestCase):
    """Test FlowChart JSON import/export."""

    def testFromJson(self) -> None:
        """Test loading from JSON."""
        json_data = {
            "nodes": [
                {"id": "n1", "name": "Entry", "shape": "ELLIPSE", "type": "entry", "data": {}},
                {"id": "n2", "name": "State1", "shape": "RECTANGLE", "type": "state", "data": {}}
            ],
            "connections": [
                {"source_id": "n1", "target_id": "n2", "is_bidirectional": False, "connection_type": "FLOW"}
            ],
            "start_node_id": "n1"
        }

        chart = FlowChart()
        chart.fromJson(json_data)

        self.assertEqual(len(chart.nodes), 2)
        self.assertEqual(len(chart.edges), 1)
        self.assertEqual(chart.startnode, "n1")
        self.assertEqual(chart.getNode("n1").name, "Entry")

    def testToJson(self) -> None:
        """Test exporting to JSON."""
        chart = FlowChart()
        chart.addNode(ChartNode(nid="n1", name="Entry", ntype="entry", shape="ellipse"))
        chart.addNode(ChartNode(nid="n2", name="State1", ntype="state", shape="rectangle"))
        chart.addEdge(ChartEdge(eid="e1", src="n1", dst="n2", etype="flow"))
        chart.startnode = "n1"

        json_data = chart.toJson()

        self.assertEqual(len(json_data["nodes"]), 2)
        self.assertEqual(len(json_data["connections"]), 1)
        self.assertEqual(json_data["start_node_id"], "n1")

    def testRoundTripJson(self) -> None:
        """Test JSON round-trip conversion."""
        original = FlowChart()
        original.addNode(ChartNode(nid="n1", name="Entry", ntype="entry"))
        original.addNode(ChartNode(nid="n2", name="Process", ntype="state"))
        original.addEdge(ChartEdge(eid="e1", src="n1", dst="n2"))
        original.startnode = "n1"

        json_data = original.toJson()
        restored = FlowChart()
        restored.fromJson(json_data)

        self.assertEqual(len(restored.nodes), 2)
        self.assertEqual(len(restored.edges), 1)
        self.assertEqual(restored.startnode, "n1")


class TestFlowChartStage(unittest.TestCase):
    """Test FlowChart Stage conversion."""

    def testToStage(self) -> None:
        """Test converting to Stage instance."""
        chart = DemoChart()
        stage = chart.toStage()

        self.assertIsInstance(stage, Stage)

    def testFromStage(self) -> None:
        """Test loading from Stage instance."""
        class TestStage(Stage):
            NAME = "TestStage"

            def idle(self, inst: Any) -> str:
                return "working"

            def working(self, inst: Any) -> str:
                return "idle"

        original = TestStage()
        chart = FlowChart()
        chart.fromStage(original)

        self.assertGreater(len(chart.nodes), 0)


class TestFlowChartLogic(unittest.TestCase):
    """Test FlowChart Logic conversion."""

    def testToLogic(self) -> None:
        """Test converting to Logic instance."""
        chart = DemoChart()
        logic = chart.toLogic()

        self.assertIsInstance(logic, Logic)

    def testFromLogic(self) -> None:
        """Test loading from Logic instance."""
        class TestLogic(Logic):
            NAME = "TestLogic"
            PRIORITY = 5

            def idle(self, inst: Any) -> str:
                return "active"

            def active(self, inst: Any) -> str:
                return "idle"

        original = TestLogic()
        chart = FlowChart()
        chart.fromLogic(original)

        self.assertGreater(len(chart.nodes), 0)
        # Check priority metadata
        for node in chart.nodes:
            self.assertEqual(node.data.get("priority"), 5)


class TestExtractNodesCompatibility(unittest.TestCase):
    """Test FlowChart compatibility with extractNodes/_importDict format."""

    def testFromStageExtractsCode(self) -> None:
        """Test fromStage extracts function body code."""
        # Use a pre-defined class from test file for reliable source extraction
        stage = TestExtractStage()
        chart = FlowChart()
        chart.fromStage(stage)

        # Check code is extracted (code field exists)
        idle_node = chart.getNode("state_0")
        self.assertIsNotNone(idle_node)
        self.assertIn("code", idle_node.data)
        # Verify return statement is in code
        self.assertIn('return "working"', idle_node.data["code"])
        # Verify body statements are extracted
        self.assertIn("x = 1", idle_node.data["code"])
        self.assertIn("y = 2", idle_node.data["code"])

    def testFromStageExtractsTargets(self) -> None:
        """Test fromStage extracts return targets."""
        class TestStage(Stage):
            NAME = "TestStage"

            def idle(self, inst: Any) -> str:
                return "working"

            def working(self, inst: Any) -> str:
                return "idle"

        stage = TestStage()
        chart = FlowChart()
        chart.fromStage(stage)

        idle_node = chart.getNode("state_0")
        self.assertIn("targets", idle_node.data)
        self.assertEqual(idle_node.data["targets"], ["working"])

        working_node = chart.getNode("state_1")
        self.assertEqual(working_node.data["targets"], ["idle"])

    def testFromStageCreatesEdgesFromTargets(self) -> None:
        """Test fromStage creates edges from extracted targets."""
        class TestStage(Stage):
            NAME = "TestStage"

            def idle(self, inst: Any) -> str:
                return "working"

            def working(self, inst: Any) -> str:
                return "idle"

        stage = TestStage()
        chart = FlowChart()
        chart.fromStage(stage)

        # Should have edges: idle -> working, working -> idle
        self.assertEqual(len(chart.edges), 2)

    def testFromJsonExtractNodesFormat(self) -> None:
        """Test fromJson can load extractNodes format."""
        extract_nodes_data = {
            "idle": {
                "code": "x = 1\\nreturn 'working'",
                "targets": ["working"],
                "decorates": ["listen"]
            },
            "working": {
                "code": "return 'idle'",
                "targets": ["idle"],
                "decorates": []
            }
        }

        chart = FlowChart()
        chart.fromJson(extract_nodes_data)

        self.assertEqual(len(chart.nodes), 2)

        idle_node = chart.getNode("state_0")
        self.assertEqual(idle_node.name, "idle")
        self.assertEqual(idle_node.data["code"], "x = 1\\nreturn 'working'")
        self.assertEqual(idle_node.data["targets"], ["working"])
        self.assertEqual(idle_node.data["decorates"], ["listen"])

    def testToJsonOutputsNodeData(self) -> None:
        """Test toJson outputs node data including code/targets/decorates."""
        chart = FlowChart()
        node = ChartNode(
            nid="n1",
            name="idle",
            ntype="state",
            data={
                "code": "return 'working'",
                "targets": ["working"],
                "decorates": ["listen"]
            }
        )
        chart.addNode(node)

        json_data = chart.toJson()

        self.assertEqual(len(json_data["nodes"]), 1)
        self.assertEqual(json_data["nodes"][0]["data"]["code"], "return 'working'")
        self.assertEqual(json_data["nodes"][0]["data"]["targets"], ["working"])
        self.assertEqual(json_data["nodes"][0]["data"]["decorates"], ["listen"])

    def testExtractNodesRoundTrip(self) -> None:
        """Test extractNodes -> fromJson round trip preserves data."""
        original_data = {
            "idle": {
                "code": "x = 1\\ny = 2\\nreturn 'working'",
                "targets": ["working"],
                "decorates": []
            },
            "working": {
                "code": "return 'idle'",
                "targets": ["idle"],
                "decorates": ["sequence"]
            }
        }

        chart = FlowChart()
        chart.fromJson(original_data)

        # Verify nodes created correctly
        self.assertEqual(len(chart.nodes), 2)

        # Verify edges created from targets
        self.assertEqual(len(chart.edges), 2)

        # Get node by name
        idle_node = None
        for node in chart.nodes:
            if node.name == "idle":
                idle_node = node
                break

        self.assertIsNotNone(idle_node)
        self.assertEqual(idle_node.data["code"], "x = 1\\ny = 2\\nreturn 'working'")


class TestDemoChart(unittest.TestCase):
    """Test DemoChart factory function."""

    def testDemoChart(self) -> None:
        """Test creating demo chart."""
        chart = DemoChart()

        self.assertEqual(len(chart.nodes), 4)
        self.assertEqual(len(chart.edges), 4)
        self.assertEqual(chart.startnode, "entry")

    def testDemoChartValid(self) -> None:
        """Test demo chart is valid."""
        chart = DemoChart()
        valid, msg = chart.validChart()
        self.assertTrue(valid, msg)


if __name__ == "__main__":
    unittest.main()
