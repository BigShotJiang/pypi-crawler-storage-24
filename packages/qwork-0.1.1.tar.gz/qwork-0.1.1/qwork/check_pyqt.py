"""
检查 qwork 项目中是否还有 PyQt5 的引用
"""
import os
import sys
from pathlib import Path

def CheckPyqt(dirpath):
    """
    检查目录下的所有 .py 文件是否包含 PyQt5 的引用
    忽略注释行中的 PyQt5 提及
    """
    _root = Path(dirpath)
    _pyqt5_files = []

    for _f in _root.rglob("*.py"):
        # 跳过本文件
        if _f.name == "check_pyqt.py":
            continue

        try:
            with open(_f, "r", encoding="utf-8") as _fp:
                _lines = _fp.readlines()
                for _line in _lines:
                    _stripped = _line.strip()
                    # 跳过注释行（以 # 开头）
                    if _stripped.startswith("#"):
                        continue
                    if "PyQt5" in _line:
                        _pyqt5_files.append(str(_f))
                        break
        except Exception as _e:
            print(f"Error reading {_f}: {_e}")

    return _pyqt5_files


if __name__ == "__main__":
    _root_dir = Path(__file__).parent
    _files = CheckPyqt(_root_dir)

    print("=" * 60)
    print(f"Scanning: {_root_dir}")
    print("=" * 60)

    if _files:
        print(f"\nFound {len(_files)} file(s) containing 'PyQt5':")
        for _f in _files:
            print(f"  - {_f}")
        sys.exit(1)
    else:
        print("\nNo PyQt5 references found.")
        print("All files are using PyQt6!")
        sys.exit(0)
