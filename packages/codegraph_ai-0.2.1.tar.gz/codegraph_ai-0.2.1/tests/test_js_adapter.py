"""Tests for the JavaScript / TypeScript adapter."""

from __future__ import annotations

import pytest

from codegraph.adapters.js_adapter import JsAdapter


@pytest.fixture()
def adapter():
    return JsAdapter()


# ---------------------------------------------------------------------------
# Basic function declarations
# ---------------------------------------------------------------------------

BASIC_JS = b"""\
import { Router } from "express";

/**
 * Handle incoming request.
 */
function handleRequest(req, res) {
    const data = parseBody(req);
    sendResponse(res, data);
}

function parseBody(req) {
    return req.body;
}
"""


class TestFunctionDeclaration:
    def test_function_count(self, adapter):
        result = adapter.parse_file(BASIC_JS, "routes.js")
        assert len(result.functions) == 2

    def test_function_names(self, adapter):
        result = adapter.parse_file(BASIC_JS, "routes.js")
        names = {f.name for f in result.functions}
        assert names == {"handleRequest", "parseBody"}

    def test_function_calls(self, adapter):
        result = adapter.parse_file(BASIC_JS, "routes.js")
        handle = next(f for f in result.functions if f.name == "handleRequest")
        assert "parseBody" in handle.call_names
        assert "sendResponse" in handle.call_names

    def test_jsdoc(self, adapter):
        result = adapter.parse_file(BASIC_JS, "routes.js")
        handle = next(f for f in result.functions if f.name == "handleRequest")
        assert "Handle incoming request" in handle.doc_comment

    def test_import(self, adapter):
        result = adapter.parse_file(BASIC_JS, "routes.js")
        assert len(result.imports) == 1
        assert result.imports[0].target_module == "express"


# ---------------------------------------------------------------------------
# Arrow functions
# ---------------------------------------------------------------------------

ARROW_JS = b"""\
/** Fetch user from database. */
const getUser = async (id) => {
    const user = await db.findById(id);
    return user;
};

const add = (a, b) => a + b;
"""


class TestArrowFunction:
    def test_arrow_count(self, adapter):
        result = adapter.parse_file(ARROW_JS, "util.js")
        assert len(result.functions) == 2

    def test_arrow_names(self, adapter):
        result = adapter.parse_file(ARROW_JS, "util.js")
        names = {f.name for f in result.functions}
        assert names == {"getUser", "add"}

    def test_arrow_calls(self, adapter):
        result = adapter.parse_file(ARROW_JS, "util.js")
        gu = next(f for f in result.functions if f.name == "getUser")
        assert "findById" in gu.call_names

    def test_arrow_doc(self, adapter):
        result = adapter.parse_file(ARROW_JS, "util.js")
        gu = next(f for f in result.functions if f.name == "getUser")
        assert "Fetch user" in gu.doc_comment


# ---------------------------------------------------------------------------
# TypeScript with classes
# ---------------------------------------------------------------------------

TS_CLASS = b"""\
import { Database } from "./db";

export class UserService {
    /** Find user by ID */
    async getById(id: number): Promise<User> {
        return await fetchUser(id);
    }

    create(data: UserInput): User {
        validateInput(data);
        return saveUser(data);
    }
}

export class AdminService {
    delete(id: number): void {
        removeUser(id);
    }
}
"""


class TestTypeScriptClass:
    def test_class_count(self, adapter):
        result = adapter.parse_file(TS_CLASS, "service.ts")
        assert len(result.classes) == 2

    def test_class_names(self, adapter):
        result = adapter.parse_file(TS_CLASS, "service.ts")
        names = {c.name for c in result.classes}
        assert names == {"UserService", "AdminService"}

    def test_method_count(self, adapter):
        result = adapter.parse_file(TS_CLASS, "service.ts")
        us = next(c for c in result.classes if c.name == "UserService")
        assert len(us.method_names) == 2

    def test_methods_extracted_as_functions(self, adapter):
        result = adapter.parse_file(TS_CLASS, "service.ts")
        fn_names = {f.name for f in result.functions}
        assert "getById" in fn_names
        assert "create" in fn_names
        assert "delete" in fn_names

    def test_method_class_name(self, adapter):
        result = adapter.parse_file(TS_CLASS, "service.ts")
        gb = next(f for f in result.functions if f.name == "getById")
        assert gb.class_name == "UserService"

    def test_method_calls(self, adapter):
        result = adapter.parse_file(TS_CLASS, "service.ts")
        create = next(f for f in result.functions if f.name == "create")
        assert "validateInput" in create.call_names
        assert "saveUser" in create.call_names

    def test_method_jsdoc(self, adapter):
        result = adapter.parse_file(TS_CLASS, "service.ts")
        gb = next(f for f in result.functions if f.name == "getById")
        assert "Find user by ID" in gb.doc_comment

    def test_import(self, adapter):
        result = adapter.parse_file(TS_CLASS, "service.ts")
        assert len(result.imports) == 1
        assert result.imports[0].target_module == "./db"


# ---------------------------------------------------------------------------
# CommonJS require
# ---------------------------------------------------------------------------

CJS_CODE = b"""\
const path = require("path");
const fs = require("fs");

function readConfig(configPath) {
    const full = path.resolve(configPath);
    return fs.readFileSync(full, "utf-8");
}
"""


class TestCommonJS:
    def test_require_imports(self, adapter):
        result = adapter.parse_file(CJS_CODE, "config.js")
        mods = {i.target_module for i in result.imports}
        assert mods == {"path", "fs"}

    def test_function_still_extracted(self, adapter):
        result = adapter.parse_file(CJS_CODE, "config.js")
        assert len(result.functions) == 1
        assert result.functions[0].name == "readConfig"


# ---------------------------------------------------------------------------
# Exported functions
# ---------------------------------------------------------------------------

EXPORT_CODE = b"""\
export function greet(name) {
    return sayHello(name);
}

export default function main() {
    greet("world");
}
"""


class TestExport:
    def test_exported_functions(self, adapter):
        result = adapter.parse_file(EXPORT_CODE, "main.js")
        names = {f.name for f in result.functions}
        assert "greet" in names
        assert "main" in names

    def test_exported_function_calls(self, adapter):
        result = adapter.parse_file(EXPORT_CODE, "main.js")
        greet = next(f for f in result.functions if f.name == "greet")
        assert "sayHello" in greet.call_names


# ---------------------------------------------------------------------------
# Extension handling
# ---------------------------------------------------------------------------


class TestExtensions:
    def test_supported_extensions(self, adapter):
        exts = adapter.supported_extensions()
        for ext in [".js", ".ts", ".tsx", ".jsx", ".mjs", ".cjs"]:
            assert ext in exts

    def test_can_handle(self, adapter):
        assert adapter.can_handle("src/index.ts")
        assert adapter.can_handle("lib/utils.js")
        assert adapter.can_handle("comp.tsx")
        assert not adapter.can_handle("main.py")
        assert not adapter.can_handle("style.css")


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------


class TestEdgeCases:
    def test_empty_file(self, adapter):
        result = adapter.parse_file(b"", "empty.ts")
        assert result.functions == []
        assert result.classes == []
        assert result.imports == []

    def test_jsx_file(self, adapter):
        code = b"""\
import React from "react";

function App() {
    return <div>Hello</div>;
}
"""
        result = adapter.parse_file(code, "App.jsx")
        assert len(result.functions) == 1
        assert result.functions[0].name == "App"

    def test_file_path_in_id(self, adapter):
        code = b"function foo() {}"
        result = adapter.parse_file(code, "src/utils/helpers.ts")
        assert result.functions[0].file_path == "src/utils/helpers.ts"
        assert "src/utils/helpers.ts" in result.functions[0].qualified_name
