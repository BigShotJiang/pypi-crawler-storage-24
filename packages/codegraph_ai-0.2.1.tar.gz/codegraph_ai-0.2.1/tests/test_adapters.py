"""Tests for the Python tree-sitter adapter."""

from codegraph.adapters.python_adapter import PythonAdapter


SAMPLE_CODE = b'''\
import os
from pathlib import Path


def greet(name: str) -> str:
    """Say hello."""
    msg = format_msg(name)
    print(msg)
    return msg


def format_msg(name: str) -> str:
    return f"Hello, {name}"


class Processor:
    """A simple processor."""

    def __init__(self, data: list):
        self.data = data

    def run(self):
        """Run processing."""
        result = self.transform()
        return result

    def transform(self):
        return [x * 2 for x in self.data]
'''


DECORATED_CODE = b'''\
import functools


def decorator(fn):
    @functools.wraps(fn)
    def wrapper(*args, **kwargs):
        return fn(*args, **kwargs)
    return wrapper


@decorator
def decorated_func(x: int) -> int:
    """A decorated function."""
    return helper(x)


def helper(x: int) -> int:
    return x + 1
'''


class TestPythonAdapterBasic:
    def setup_method(self):
        self.adapter = PythonAdapter()

    def test_supported_extensions(self):
        assert self.adapter.supported_extensions() == [".py"]

    def test_can_handle(self):
        assert self.adapter.can_handle("foo/bar.py")
        assert not self.adapter.can_handle("foo/bar.js")

    def test_parse_functions(self):
        result = self.adapter.parse_file(SAMPLE_CODE, "sample.py")
        names = [f.name for f in result.functions]
        assert "greet" in names
        assert "format_msg" in names

    def test_function_signature(self):
        result = self.adapter.parse_file(SAMPLE_CODE, "sample.py")
        greet = next(f for f in result.functions if f.name == "greet")
        assert "name: str" in greet.signature
        assert "-> str" in greet.signature

    def test_function_docstring(self):
        result = self.adapter.parse_file(SAMPLE_CODE, "sample.py")
        greet = next(f for f in result.functions if f.name == "greet")
        assert greet.doc_comment == "Say hello."

    def test_function_calls(self):
        result = self.adapter.parse_file(SAMPLE_CODE, "sample.py")
        greet = next(f for f in result.functions if f.name == "greet")
        assert "format_msg" in greet.call_names
        assert "print" in greet.call_names

    def test_function_lines(self):
        result = self.adapter.parse_file(SAMPLE_CODE, "sample.py")
        greet = next(f for f in result.functions if f.name == "greet")
        assert greet.start_line >= 1
        assert greet.end_line > greet.start_line

    def test_qualified_name_top_level(self):
        result = self.adapter.parse_file(SAMPLE_CODE, "sample.py")
        greet = next(f for f in result.functions if f.name == "greet")
        assert greet.qualified_name == "sample.py:greet"


class TestPythonAdapterClasses:
    def setup_method(self):
        self.adapter = PythonAdapter()

    def test_class_extracted(self):
        result = self.adapter.parse_file(SAMPLE_CODE, "sample.py")
        assert len(result.classes) == 1
        cls = result.classes[0]
        assert cls.name == "Processor"
        assert cls.qualified_name == "sample.py:Processor"

    def test_class_methods(self):
        result = self.adapter.parse_file(SAMPLE_CODE, "sample.py")
        cls = result.classes[0]
        assert "__init__" in cls.method_names
        assert "run" in cls.method_names
        assert "transform" in cls.method_names

    def test_methods_in_functions_list(self):
        result = self.adapter.parse_file(SAMPLE_CODE, "sample.py")
        names = [f.name for f in result.functions]
        assert "__init__" in names
        assert "run" in names

    def test_method_class_name(self):
        result = self.adapter.parse_file(SAMPLE_CODE, "sample.py")
        run_fn = next(f for f in result.functions if f.name == "run")
        assert run_fn.class_name == "Processor"
        assert "Processor.run" in run_fn.qualified_name

    def test_method_calls(self):
        result = self.adapter.parse_file(SAMPLE_CODE, "sample.py")
        run_fn = next(f for f in result.functions if f.name == "run")
        assert "transform" in run_fn.call_names


class TestPythonAdapterImports:
    def setup_method(self):
        self.adapter = PythonAdapter()

    def test_import_statement(self):
        result = self.adapter.parse_file(SAMPLE_CODE, "sample.py")
        modules = [i.target_module for i in result.imports]
        assert "os" in modules

    def test_from_import(self):
        result = self.adapter.parse_file(SAMPLE_CODE, "sample.py")
        modules = [i.target_module for i in result.imports]
        assert "pathlib" in modules

    def test_import_source_path(self):
        result = self.adapter.parse_file(SAMPLE_CODE, "sample.py")
        for imp in result.imports:
            assert imp.source_path == "sample.py"


class TestPythonAdapterDecorated:
    def setup_method(self):
        self.adapter = PythonAdapter()

    def test_decorated_function_extracted(self):
        result = self.adapter.parse_file(DECORATED_CODE, "deco.py")
        names = [f.name for f in result.functions]
        assert "decorated_func" in names

    def test_decorated_function_docstring(self):
        result = self.adapter.parse_file(DECORATED_CODE, "deco.py")
        fn = next(f for f in result.functions if f.name == "decorated_func")
        assert fn.doc_comment == "A decorated function."

    def test_decorated_function_calls(self):
        result = self.adapter.parse_file(DECORATED_CODE, "deco.py")
        fn = next(f for f in result.functions if f.name == "decorated_func")
        assert "helper" in fn.call_names


class TestPythonAdapterEdgeCases:
    def setup_method(self):
        self.adapter = PythonAdapter()

    def test_empty_file(self):
        result = self.adapter.parse_file(b"", "empty.py")
        assert result.functions == []
        assert result.classes == []
        assert result.imports == []

    def test_syntax_error_partial(self):
        """Adapter should still produce partial results on broken code."""
        code = b"def foo():\n    return 1\n\ndef bar(:\n    pass\n"
        result = self.adapter.parse_file(code, "broken.py")
        # At least the valid function should be found
        names = [f.name for f in result.functions]
        assert "foo" in names

    def test_file_path_in_id(self):
        result = self.adapter.parse_file(b"def f(): pass", "sub/dir/mod.py")
        assert result.functions[0].file_path == "sub/dir/mod.py"
