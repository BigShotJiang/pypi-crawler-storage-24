"""Unit tests for bug_locator — root cause ranking and report formatting."""

from __future__ import annotations

from codegraph.bug_locator import (
    RootCauseCandidate,
    BugAnalysisResult,
    rank_root_causes,
    _strip_markdown,
)
from codegraph.bug_parser import ParsedIssue


class TestStripMarkdown:
    def test_removes_code_blocks(self):
        text = "before\n```python\ncode\n```\nafter"
        assert "code" not in _strip_markdown(text)

    def test_removes_inline_code(self):
        text = "The `foo` function"
        assert "`" not in _strip_markdown(text)

    def test_removes_image_links(self):
        text = "See ![screenshot](http://example.com/img.png)"
        result = _strip_markdown(text)
        assert "http://" not in result

    def test_preserves_link_text(self):
        text = "See [documentation](http://example.com)"
        result = _strip_markdown(text)
        assert "documentation" in result
        assert "http://" not in result


class TestRankRootCauses:
    def test_direct_mention_scored_highest(self):
        path_matches = [{
            "extracted_path": "src/main.py",
            "matched_file": "src/main.py",
            "functions": [
                {"name": "handle_request", "qualified_name": "main.handle_request"},
                {"name": "validate", "qualified_name": "main.validate"},
            ],
        }]
        candidates = rank_root_causes(
            path_matches=path_matches,
            semantic_matches=[],
            caller_traces=[],
            extracted_funcs=["handle_request"],
        )
        assert len(candidates) >= 1
        top = candidates[0]
        assert top.function_name == "handle_request"
        assert top.score >= 1.0  # direct mention (1.0) + file match doesn't double

    def test_semantic_matches_scored(self):
        semantic_matches = [
            {"name": "process_data", "file_path": "src/processor.py", "score": 0.85},
            {"name": "transform", "file_path": "src/transform.py", "score": 0.70},
        ]
        candidates = rank_root_causes(
            path_matches=[],
            semantic_matches=semantic_matches,
            caller_traces=[],
            extracted_funcs=[],
        )
        assert len(candidates) == 2
        assert candidates[0].function_name == "process_data"
        assert candidates[0].score == pytest.approx(0.85, abs=0.01)

    def test_caller_traces_scored(self):
        caller_traces = [{
            "function": "leaf_func",
            "callers": [
                {"name": "mid_func", "file": "src/mid.py", "hops": 1, "relevance": 0.5},
                {"name": "top_func", "file": "src/top.py", "hops": 2, "relevance": 0.3},
            ],
        }]
        candidates = rank_root_causes(
            path_matches=[],
            semantic_matches=[],
            caller_traces=caller_traces,
            extracted_funcs=[],
        )
        assert len(candidates) == 2
        # mid_func (1 hop) should score higher than top_func (2 hops)
        mid = next(c for c in candidates if c.function_name == "mid_func")
        top = next(c for c in candidates if c.function_name == "top_func")
        assert mid.score > top.score

    def test_combined_scoring(self):
        path_matches = [{
            "extracted_path": "src/handler.py",
            "matched_file": "src/handler.py",
            "functions": [
                {"name": "handle", "qualified_name": "handler.handle"},
            ],
        }]
        semantic_matches = [
            {"name": "handle", "file_path": "src/handler.py", "score": 0.9},
        ]
        candidates = rank_root_causes(
            path_matches=path_matches,
            semantic_matches=semantic_matches,
            caller_traces=[],
            extracted_funcs=["handle"],
        )
        # handle should have score = 1.0 (mentioned) + 0.9 (semantic)
        assert len(candidates) >= 1
        assert candidates[0].function_name == "handle"
        assert candidates[0].score >= 1.5

    def test_topk_limit(self):
        semantic_matches = [
            {"name": f"func_{i}", "file_path": f"src/f{i}.py", "score": 0.5}
            for i in range(20)
        ]
        candidates = rank_root_causes(
            path_matches=[],
            semantic_matches=semantic_matches,
            caller_traces=[],
            extracted_funcs=[],
            topk=5,
        )
        assert len(candidates) == 5

    def test_empty_inputs(self):
        candidates = rank_root_causes(
            path_matches=[],
            semantic_matches=[],
            caller_traces=[],
            extracted_funcs=[],
        )
        assert candidates == []

    def test_deduplication(self):
        path_matches = [{
            "extracted_path": "src/main.py",
            "matched_file": "src/main.py",
            "functions": [
                {"name": "foo", "qualified_name": "main.foo"},
            ],
        }]
        semantic_matches = [
            {"name": "foo", "file_path": "src/main.py", "score": 0.8},
        ]
        candidates = rank_root_causes(
            path_matches=path_matches,
            semantic_matches=semantic_matches,
            caller_traces=[],
            extracted_funcs=[],
        )
        # foo@src/main.py should appear once with combined score
        foo_candidates = [c for c in candidates if c.function_name == "foo"]
        assert len(foo_candidates) == 1
        assert foo_candidates[0].score > 0.8  # semantic + file match


class TestBugAnalysisResultFormat:
    def test_format_report_with_candidates(self):
        issue = ParsedIssue(
            owner="test", repo="repo", number=42,
            title="Test bug",
            body="Some body",
            labels=["bug"],
            extracted_paths=["src/main.py"],
            extracted_funcs=["handle"],
            linked_commits=["abc123"],
        )
        result = BugAnalysisResult(
            issue=issue,
            candidates=[
                RootCauseCandidate("handle", "src/main.py", 1.5,
                                   ["mentioned in issue", "semantic match (0.90)"]),
            ],
            path_matches=1,
            semantic_matches=1,
            caller_traces=0,
            analysis_time_ms=42.5,
        )
        report = result.format_report()
        assert "test/repo#42" in report
        assert "Test bug" in report
        assert "handle" in report
        assert "src/main.py" in report
        assert "1.500" in report

    def test_format_report_empty(self):
        issue = ParsedIssue(
            owner="test", repo="repo", number=1,
            title="Empty bug",
            body="",
        )
        result = BugAnalysisResult(issue=issue)
        report = result.format_report()
        assert "No root cause candidates" in report


# Need pytest for approx
import pytest
