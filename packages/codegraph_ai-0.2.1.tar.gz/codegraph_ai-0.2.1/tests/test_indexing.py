"""Tests for the indexing pipeline (Module 3).

Uses the ``mini_repo`` and ``scope`` fixtures from conftest.py.
"""


class TestIndexing:
    """Index the mini_repo and verify graph + vector state."""

    def test_index_runs(self, scope, mini_repo):
        """Indexing should complete without errors."""
        scope.index(mini_repo, languages=["python"])

    def test_file_count(self, scope, mini_repo):
        scope.index(mini_repo, languages=["python"])
        rows = list(scope.conn.execute(
            "MATCH (f:File) RETURN count(f)"
        ))
        # api/__init__.py, api/routes.py, api/users.py,
        # reports/__init__.py, reports/builder.py,
        # db/__init__.py, db/query.py,
        # parsers/__init__.py, parsers/json_parser.py, parsers/yaml_parser.py
        assert rows[0][0] == 10

    def test_function_count(self, scope, mini_repo):
        scope.index(mini_repo, languages=["python"])
        rows = list(scope.conn.execute(
            "MATCH (f:Function) RETURN count(f)"
        ))
        # handle_request, get_user_stats, build_report,
        # execute_query, parse_json, parse_yaml = 6
        assert rows[0][0] == 6

    def test_calls_edges(self, scope, mini_repo):
        """Verify call edges are created."""
        scope.index(mini_repo, languages=["python"])
        rows = list(scope.conn.execute(
            "MATCH ()-[e:CALLS]->() RETURN count(e)"
        ))
        # handle_request -> get_user_stats
        # get_user_stats -> build_report
        # build_report -> execute_query
        assert rows[0][0] >= 3

    def test_defines_func_edges(self, scope, mini_repo):
        scope.index(mini_repo, languages=["python"])
        rows = list(scope.conn.execute(
            "MATCH ()-[e:DEFINES_FUNC]->() RETURN count(e)"
        ))
        assert rows[0][0] == 6

    def test_module_nodes(self, scope, mini_repo):
        scope.index(mini_repo, languages=["python"])
        rows = list(scope.conn.execute(
            "MATCH (m:Module) RETURN m.path_prefix"
        ))
        prefixes = {r[0] for r in rows}
        assert "api" in prefixes
        assert "db" in prefixes
        assert "parsers" in prefixes
        assert "reports" in prefixes

    def test_belongs_to_edges(self, scope, mini_repo):
        scope.index(mini_repo, languages=["python"])
        rows = list(scope.conn.execute(
            "MATCH ()-[e:BELONGS_TO]->() RETURN count(e)"
        ))
        assert rows[0][0] >= 4

    def test_embedding_cache(self, scope, mini_repo):
        scope.index(mini_repo, languages=["python"])
        assert len(scope._emb_cache) == 6

    def test_zvec_vectors(self, scope, mini_repo):
        scope.index(mini_repo, languages=["python"])
        assert scope.collection.stats.doc_count == 6


class TestIndexingEdgeCases:
    def test_empty_repo(self, scope, tmp_dir):
        import os
        empty = os.path.join(tmp_dir, "empty_repo")
        os.makedirs(empty)
        scope.index(empty, languages=["python"])
        rows = list(scope.conn.execute(
            "MATCH (f:File) RETURN count(f)"
        ))
        assert rows[0][0] == 0
