"""Tests for Use Case 1: Impact Analysis (Module 4).

Call chain in mini_repo:
  handle_request -> get_user_stats -> build_report -> execute_query
"""

import pytest


class TestImpactAnalysis:
    """Test the impact() method."""

    @pytest.fixture(autouse=True)
    def _indexed(self, scope, mini_repo):
        """Index the mini repo once for every test."""
        scope.index(mini_repo, languages=["python"])
        self.scope = scope

    def test_callers_found(self):
        results = self.scope.impact(
            function="execute_query",
            change="return type changed from list to DataFrame",
        )
        names = [r.name for r in results]
        # build_report (1 hop), get_user_stats (2 hops),
        # handle_request (3 hops)
        assert "build_report" in names

    def test_relevance_scores(self):
        results = self.scope.impact(
            function="execute_query",
            change="return type changed from list to DataFrame",
        )
        # All scores should be between -1 and 1 (cosine with normalized vecs)
        for r in results:
            assert -1.0 <= r.relevance <= 1.0

    def test_results_sorted_by_relevance(self):
        results = self.scope.impact(
            function="execute_query",
            change="return type changed from list to DataFrame",
        )
        scores = [r.relevance for r in results]
        assert scores == sorted(scores, reverse=True)

    def test_hop_distance(self):
        results = self.scope.impact(
            function="execute_query",
            change="return type changed",
        )
        build = next((r for r in results if r.name == "build_report"), None)
        if build is not None:
            assert build.hop_distance >= 1

    def test_function_not_found(self):
        results = self.scope.impact(
            function="nonexistent_func",
            change="anything",
        )
        assert results == []

    def test_no_callers(self):
        results = self.scope.impact(
            function="handle_request",
            change="anything",
        )
        # handle_request is the top of the chain — no one calls it
        assert results == []
