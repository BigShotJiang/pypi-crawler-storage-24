"""Tests for Use Case 3: Cross-Locate (Module 6)."""

import pytest

from codegraph.models import CrossLocateResult


class TestCrossLocate:
    """Test the cross_locate() method."""

    @pytest.fixture(autouse=True)
    def _indexed(self, scope, mini_repo):
        scope.index(mini_repo, languages=["python"])
        self.scope = scope

    def test_returns_cross_locate_result(self):
        result = self.scope.cross_locate("query database SQL")
        assert isinstance(result, CrossLocateResult)

    def test_seeds_returned(self):
        result = self.scope.cross_locate("query database SQL")
        assert len(result.seeds) > 0

    def test_seed_has_required_fields(self):
        result = self.scope.cross_locate("query database SQL")
        for seed in result.seeds:
            assert "name" in seed
            assert "score" in seed
            assert "file_path" in seed

    def test_seeds_sorted_by_score(self):
        result = self.scope.cross_locate("query database SQL")
        scores = [s["score"] for s in result.seeds]
        assert scores == sorted(scores, reverse=True)

    def test_clusters_cover_all_seeds(self):
        result = self.scope.cross_locate("query database SQL")
        clustered_names = set()
        for cluster in result.clusters:
            clustered_names.update(cluster)
        seed_names = {s["name"] for s in result.seeds}
        assert seed_names == clustered_names

    def test_connection_fields(self):
        result = self.scope.cross_locate("query database SQL")
        for conn in result.connections:
            assert "from" in conn
            assert "to" in conn
            assert "distance" in conn


class TestVectorOnlySearch:
    """Test the vector_only_search() comparison method."""

    @pytest.fixture(autouse=True)
    def _indexed(self, scope, mini_repo):
        scope.index(mini_repo, languages=["python"])
        self.scope = scope

    def test_returns_list(self):
        results = self.scope.vector_only_search("database query")
        assert isinstance(results, list)

    def test_result_has_id_and_score(self):
        results = self.scope.vector_only_search("database query")
        for r in results:
            assert "id" in r
            assert "score" in r


class TestFindClusters:
    """Test the _find_clusters() internal method directly."""

    def test_connected_pairs(self, scope, mini_repo):
        seeds = [{"name": "A"}, {"name": "B"}, {"name": "C"}]
        connections = [{"from": "A", "to": "B", "distance": 1, "via": []}]
        clusters = scope._find_clusters(seeds, connections)
        # A-B should be in one cluster, C alone
        assert len(clusters) == 2
        for cluster in clusters:
            if "A" in cluster:
                assert "B" in cluster

    def test_no_connections(self, scope, mini_repo):
        seeds = [{"name": "X"}, {"name": "Y"}]
        clusters = scope._find_clusters(seeds, [])
        assert len(clusters) == 2

    def test_all_connected(self, scope, mini_repo):
        seeds = [{"name": "A"}, {"name": "B"}, {"name": "C"}]
        connections = [
            {"from": "A", "to": "B", "distance": 1, "via": []},
            {"from": "B", "to": "C", "distance": 1, "via": []},
        ]
        clusters = scope._find_clusters(seeds, connections)
        assert len(clusters) == 1
        assert set(clusters[0]) == {"A", "B", "C"}
