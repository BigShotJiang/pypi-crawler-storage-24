"""Unit tests for issue_cache — file-based caching of parsed issues."""

from __future__ import annotations

import json
import os
import tempfile
import time
from pathlib import Path
from unittest import mock

import pytest

from codegraph.bug_parser import ParsedIssue
from codegraph import issue_cache


@pytest.fixture(autouse=True)
def temp_cache_dir(tmp_path):
    """Redirect cache to a temp directory for test isolation."""
    cache_dir = str(tmp_path / "issue_cache")
    with mock.patch.object(issue_cache, "_CACHE_DIR", cache_dir):
        yield cache_dir


def _make_issue(number: int = 42, owner: str = "test", repo: str = "repo") -> ParsedIssue:
    return ParsedIssue(
        owner=owner,
        repo=repo,
        number=number,
        title=f"Test issue #{number}",
        body="This is a test body with src/main.py",
        labels=["bug"],
        extracted_paths=["src/main.py"],
        extracted_funcs=["handle_request"],
        extracted_locations=[("src/main.py", 42)],
        linked_commits=["abc123"],
        fetched_at=int(time.time()),
    )


class TestGetCachePath:
    def test_path_format(self):
        path = issue_cache.get_cache_path("owner", "repo", 123)
        assert path.name == "owner_repo_123.json"


class TestSaveAndLoad:
    def test_save_creates_file(self, temp_cache_dir):
        issue = _make_issue()
        issue_cache.save_to_cache(issue)

        path = issue_cache.get_cache_path("test", "repo", 42)
        assert path.exists()
        data = json.loads(path.read_text())
        assert data["number"] == 42
        assert data["title"] == "Test issue #42"

    def test_load_returns_issue(self, temp_cache_dir):
        issue = _make_issue()
        issue_cache.save_to_cache(issue)

        loaded = issue_cache.load_cached_issue("test", "repo", 42)
        assert loaded is not None
        assert loaded.number == 42
        assert loaded.title == "Test issue #42"
        assert loaded.extracted_paths == ["src/main.py"]
        assert loaded.extracted_funcs == ["handle_request"]
        assert loaded.linked_commits == ["abc123"]

    def test_load_nonexistent(self, temp_cache_dir):
        loaded = issue_cache.load_cached_issue("nonexistent", "repo", 999)
        assert loaded is None

    def test_roundtrip_locations(self, temp_cache_dir):
        issue = _make_issue()
        issue.extracted_locations = [("src/main.py", 42), ("src/db.py", 15)]
        issue_cache.save_to_cache(issue)

        loaded = issue_cache.load_cached_issue("test", "repo", 42)
        assert loaded is not None
        assert ("src/main.py", 42) in loaded.extracted_locations
        assert ("src/db.py", 15) in loaded.extracted_locations


class TestCacheTTL:
    def test_expired_cache(self, temp_cache_dir):
        issue = _make_issue()
        issue.fetched_at = int(time.time()) - 7200
        issue_cache.save_to_cache(issue)

        loaded = issue_cache.load_cached_issue("test", "repo", 42, ttl=3600)
        assert loaded is None

    def test_fresh_cache(self, temp_cache_dir):
        issue = _make_issue()
        issue_cache.save_to_cache(issue)

        loaded = issue_cache.load_cached_issue("test", "repo", 42, ttl=3600)
        assert loaded is not None

    def test_no_ttl(self, temp_cache_dir):
        issue = _make_issue()
        issue.fetched_at = 1  # very old
        issue_cache.save_to_cache(issue)

        loaded = issue_cache.load_cached_issue("test", "repo", 42, ttl=None)
        assert loaded is not None


class TestClearCache:
    def test_clear_all(self, temp_cache_dir):
        for i in range(5):
            issue_cache.save_to_cache(_make_issue(number=i, owner="a", repo="b"))

        count = issue_cache.clear_cache()
        assert count == 5

        for i in range(5):
            assert issue_cache.load_cached_issue("a", "b", i) is None

    def test_clear_by_owner(self, temp_cache_dir):
        issue_cache.save_to_cache(_make_issue(number=1, owner="alice", repo="x"))
        issue_cache.save_to_cache(_make_issue(number=2, owner="bob", repo="y"))

        count = issue_cache.clear_cache(owner="alice")
        assert count == 1
        assert issue_cache.load_cached_issue("alice", "x", 1) is None
        assert issue_cache.load_cached_issue("bob", "y", 2) is not None

    def test_clear_by_owner_repo(self, temp_cache_dir):
        issue_cache.save_to_cache(_make_issue(number=1, owner="alice", repo="x"))
        issue_cache.save_to_cache(_make_issue(number=2, owner="alice", repo="y"))

        count = issue_cache.clear_cache(owner="alice", repo="x")
        assert count == 1
        assert issue_cache.load_cached_issue("alice", "x", 1) is None
        assert issue_cache.load_cached_issue("alice", "y", 2) is not None

    def test_clear_empty(self, temp_cache_dir):
        count = issue_cache.clear_cache()
        assert count == 0
