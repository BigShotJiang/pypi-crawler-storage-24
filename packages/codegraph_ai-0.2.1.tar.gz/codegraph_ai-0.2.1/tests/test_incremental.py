"""Tests for incremental update (Layer 4).

Each test creates a real git repo, indexes it, makes commits,
and verifies that incremental_update correctly detects and processes
only the changed files.
"""

from __future__ import annotations

import os
import subprocess
from pathlib import Path

import pytest


def _git(repo: str, *args: str) -> str:
    """Run a git command in *repo* and return stdout."""
    r = subprocess.run(
        ["git", *args],
        cwd=repo, capture_output=True, text=True, check=True,
    )
    return r.stdout.strip()


def _write_and_commit(repo: str, files: dict[str, str], message: str) -> str:
    """Write files, stage, commit, and return the new commit hash."""
    for rel, content in files.items():
        full = os.path.join(repo, rel)
        os.makedirs(os.path.dirname(full), exist_ok=True)
        Path(full).write_text(content)
    _git(repo, "add", "-A")
    _git(repo, "commit", "-m", message)
    return _git(repo, "rev-parse", "HEAD")


def _delete_and_commit(repo: str, paths: list[str], message: str) -> str:
    """Delete files, stage, commit, and return the new commit hash."""
    for rel in paths:
        full = os.path.join(repo, rel)
        if os.path.exists(full):
            os.remove(full)
    _git(repo, "add", "-A")
    _git(repo, "commit", "-m", message)
    return _git(repo, "rev-parse", "HEAD")


# ============================================================================
# Fixtures
# ============================================================================


@pytest.fixture()
def git_repo(tmp_dir) -> str:
    """Create a git repo with an initial two-file commit."""
    repo = os.path.join(tmp_dir, "git_repo")
    os.makedirs(repo)

    _git(repo, "init")
    _git(repo, "config", "user.email", "test@codegraph.dev")
    _git(repo, "config", "user.name", "CodeScope Test")

    _write_and_commit(repo, {
        "main.py": (
            "from utils import helper\n\n\n"
            "def main():\n"
            "    return helper()\n"
        ),
        "utils.py": (
            "def helper():\n"
            "    return 'hello'\n\n\n"
            "def unused():\n"
            "    return 'unused'\n"
        ),
    }, "initial commit")

    return repo


# ============================================================================
# Tests: State Persistence
# ============================================================================


class TestStatePersistence:
    """Verify that index() saves state in the graph (no external file)."""

    def test_commit_saved_in_graph(self, scope, git_repo):
        scope.index(git_repo, languages=["python"])
        meta = scope._load_commit()
        assert meta is not None
        assert len(meta["last_commit"]) == 40

    def test_no_external_state_file(self, scope, git_repo):
        scope.index(git_repo, languages=["python"])
        state_file = os.path.join(scope.db_dir, "index_state.json")
        assert not os.path.exists(state_file)

    def test_functions_restored_from_graph(self, scope, git_repo):
        scope.index(git_repo, languages=["python"])
        funcs, calls, imports, classes = scope._restore_from_graph()
        func_names = {v["name"] for v in funcs.values()}
        assert "main" in func_names
        assert "helper" in func_names
        assert "unused" in func_names

    def test_embeddings_stored_in_graph(self, scope, git_repo):
        scope.index(git_repo, languages=["python"])
        rows = list(scope.conn.execute(
            "MATCH (f:Function) WHERE f.embedding <> '' RETURN f.id"
        ))
        assert len(rows) == 3

    def test_call_raw_stored_in_graph(self, scope, git_repo):
        scope.index(git_repo, languages=["python"])
        rows = list(scope.conn.execute(
            "MATCH (f:Function {name: 'main'}) RETURN f.call_raw"
        ))
        assert len(rows) == 1
        assert "helper" in rows[0][0]

    def test_import_raw_stored_in_graph(self, scope, git_repo):
        scope.index(git_repo, languages=["python"])
        rows = list(scope.conn.execute(
            "MATCH (f:File {id: 'main.py'}) RETURN f.import_raw"
        ))
        assert len(rows) == 1
        assert "utils" in rows[0][0]


# ============================================================================
# Tests: No-op Update (same commit)
# ============================================================================


class TestNoOpUpdate:
    """When HEAD hasn't changed, incremental_update is a no-op."""

    def test_same_commit_returns_empty_report(self, scope, git_repo):
        scope.index(git_repo, languages=["python"])
        report = scope.incremental_update(git_repo)
        assert report.commit_before == report.commit_after
        assert len(report.files_added) == 0
        assert len(report.files_modified) == 0
        assert len(report.files_deleted) == 0


# ============================================================================
# Tests: Add File
# ============================================================================


class TestAddFile:
    """Test incremental update when a new file is added."""

    def test_new_file_detected(self, scope, git_repo):
        scope.index(git_repo, languages=["python"])

        _write_and_commit(git_repo, {
            "extras.py": (
                "def extra_func(x: int) -> int:\n"
                "    return x * 2\n"
            ),
        }, "add extras module")

        report = scope.incremental_update(git_repo)
        assert "extras.py" in report.files_added
        assert report.functions_added >= 1
        assert report.embeddings_computed >= 1

    def test_new_function_in_graph(self, scope, git_repo):
        scope.index(git_repo, languages=["python"])

        _write_and_commit(git_repo, {
            "extras.py": (
                "def extra_func(x: int) -> int:\n"
                "    return x * 2\n"
            ),
        }, "add extras module")

        scope.incremental_update(git_repo)

        rows = list(scope.conn.execute(
            "MATCH (f:Function {name: 'extra_func'}) RETURN f.file_path"
        ))
        assert len(rows) == 1
        assert rows[0][0] == "extras.py"

    def test_old_functions_preserved(self, scope, git_repo):
        scope.index(git_repo, languages=["python"])

        _write_and_commit(git_repo, {
            "extras.py": "def extra_func(): pass\n",
        }, "add extras")

        scope.incremental_update(git_repo)

        rows = list(scope.conn.execute(
            "MATCH (f:Function) RETURN f.name"
        ))
        names = {r[0] for r in rows}
        assert "main" in names
        assert "helper" in names
        assert "unused" in names
        assert "extra_func" in names

    def test_embeddings_reused(self, scope, git_repo):
        scope.index(git_repo, languages=["python"])

        _write_and_commit(git_repo, {
            "extras.py": "def extra_func(): pass\n",
        }, "add extras")

        report = scope.incremental_update(git_repo)
        assert report.embeddings_reused >= 3
        assert report.embeddings_computed >= 1


# ============================================================================
# Tests: Modify File
# ============================================================================


class TestModifyFile:
    """Test incremental update when an existing file is modified."""

    def test_modified_file_detected(self, scope, git_repo):
        scope.index(git_repo, languages=["python"])

        _write_and_commit(git_repo, {
            "utils.py": (
                "def helper():\n"
                "    return 'modified hello'\n\n\n"
                "def unused():\n"
                "    return 'still unused'\n\n\n"
                "def brand_new():\n"
                "    return 'added in modification'\n"
            ),
        }, "modify utils.py and add brand_new")

        report = scope.incremental_update(git_repo)
        assert "utils.py" in report.files_modified
        assert report.functions_added >= 1

    def test_new_function_from_modified_file(self, scope, git_repo):
        scope.index(git_repo, languages=["python"])

        _write_and_commit(git_repo, {
            "utils.py": (
                "def helper():\n"
                "    return 'v2'\n\n\n"
                "def brand_new():\n"
                "    return 'new'\n"
            ),
        }, "modify utils")

        scope.incremental_update(git_repo)

        rows = list(scope.conn.execute(
            "MATCH (f:Function {name: 'brand_new'}) RETURN f.file_path"
        ))
        assert len(rows) == 1

    def test_call_edges_updated_after_modify(self, scope, git_repo):
        """After modifying utils.py, main.py -> helper CALLS edge still exists."""
        scope.index(git_repo, languages=["python"])

        _write_and_commit(git_repo, {
            "utils.py": (
                "def helper():\n"
                "    return 'v2'\n"
            ),
        }, "modify utils")

        scope.incremental_update(git_repo)

        rows = list(scope.conn.execute(
            "MATCH (a:Function {name: 'main'})-[:CALLS]->(b:Function {name: 'helper'}) "
            "RETURN a.name, b.name"
        ))
        assert len(rows) >= 1


# ============================================================================
# Tests: Delete File
# ============================================================================


class TestDeleteFile:
    """Test incremental update when a file is deleted."""

    def test_deleted_file_detected(self, scope, git_repo):
        scope.index(git_repo, languages=["python"])

        _delete_and_commit(git_repo, ["utils.py"], "remove utils")

        report = scope.incremental_update(git_repo)
        assert "utils.py" in report.files_deleted
        assert report.functions_removed >= 2

    def test_deleted_functions_gone_from_graph(self, scope, git_repo):
        scope.index(git_repo, languages=["python"])

        _delete_and_commit(git_repo, ["utils.py"], "remove utils")
        scope.incremental_update(git_repo)

        rows = list(scope.conn.execute(
            "MATCH (f:Function {name: 'helper'}) RETURN f.id"
        ))
        assert len(rows) == 0

    def test_deleted_file_node_gone(self, scope, git_repo):
        scope.index(git_repo, languages=["python"])

        _delete_and_commit(git_repo, ["utils.py"], "remove utils")
        scope.incremental_update(git_repo)

        rows = list(scope.conn.execute(
            "MATCH (f:File {id: 'utils.py'}) RETURN f.id"
        ))
        assert len(rows) == 0


# ============================================================================
# Tests: Multi-step Updates
# ============================================================================


class TestMultiStepUpdates:
    """Run multiple incremental updates in sequence."""

    def test_two_updates_in_sequence(self, scope, git_repo):
        scope.index(git_repo, languages=["python"])

        # Update 1: add a file
        _write_and_commit(git_repo, {
            "new1.py": "def func1(): return 1\n",
        }, "add new1")
        r1 = scope.incremental_update(git_repo)
        assert "new1.py" in r1.files_added

        # Update 2: modify the added file
        _write_and_commit(git_repo, {
            "new1.py": (
                "def func1(): return 1\n\n"
                "def func2(): return 2\n"
            ),
        }, "modify new1")
        r2 = scope.incremental_update(git_repo)
        assert "new1.py" in r2.files_modified
        assert r2.functions_added >= 1

    def test_add_then_delete(self, scope, git_repo):
        scope.index(git_repo, languages=["python"])

        _write_and_commit(git_repo, {
            "temp.py": "def temp_func(): pass\n",
        }, "add temp")
        r1 = scope.incremental_update(git_repo)
        assert "temp.py" in r1.files_added

        _delete_and_commit(git_repo, ["temp.py"], "remove temp")
        r2 = scope.incremental_update(git_repo)
        assert "temp.py" in r2.files_deleted

        rows = list(scope.conn.execute(
            "MATCH (f:Function {name: 'temp_func'}) RETURN f.id"
        ))
        assert len(rows) == 0

    def test_mixed_add_modify_delete(self, scope, git_repo):
        scope.index(git_repo, languages=["python"])

        _write_and_commit(git_repo, {
            "utils.py": "def helper(): return 'v2'\n",
            "brand_new.py": "def new_entry(): pass\n",
        }, "modify utils + add brand_new")
        _delete_and_commit(git_repo, ["main.py"], "remove main")

        report = scope.incremental_update(git_repo)

        assert "brand_new.py" in report.files_added
        assert "utils.py" in report.files_modified
        assert "main.py" in report.files_deleted

        rows = list(scope.conn.execute(
            "MATCH (f:Function) RETURN f.name"
        ))
        names = {r[0] for r in rows}
        assert "new_entry" in names
        assert "helper" in names
        assert "main" not in names


# ============================================================================
# Tests: Report Quality
# ============================================================================


class TestReportQuality:
    """Verify that UpdateReport has correct metadata."""

    def test_commits_differ(self, scope, git_repo):
        scope.index(git_repo, languages=["python"])

        _write_and_commit(git_repo, {
            "x.py": "def x(): pass\n",
        }, "add x")

        report = scope.incremental_update(git_repo)
        assert report.commit_before != report.commit_after
        assert len(report.commit_before) == 40
        assert len(report.commit_after) == 40

    def test_duration_recorded(self, scope, git_repo):
        scope.index(git_repo, languages=["python"])

        _write_and_commit(git_repo, {
            "x.py": "def x(): pass\n",
        }, "add x")

        report = scope.incremental_update(git_repo)
        assert report.duration_ms > 0

    def test_summary_output(self, scope, git_repo):
        scope.index(git_repo, languages=["python"])

        _write_and_commit(git_repo, {
            "x.py": "def x(): pass\n",
        }, "add x")

        report = scope.incremental_update(git_repo)
        text = report.summary()
        assert "x.py" in text
        assert report.commit_after[:8] in text


# ============================================================================
# Tests: Non-Supported Files Ignored
# ============================================================================


class TestFileFiltering:
    """Non-Python files should be ignored during incremental update."""

    def test_txt_file_ignored(self, scope, git_repo):
        scope.index(git_repo, languages=["python"])

        _write_and_commit(git_repo, {
            "notes.txt": "some notes\n",
        }, "add notes")

        report = scope.incremental_update(git_repo)
        assert len(report.files_added) == 0
        assert len(report.files_modified) == 0
