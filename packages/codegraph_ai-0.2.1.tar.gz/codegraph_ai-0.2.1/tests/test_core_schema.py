"""Tests for CodeScope schema initialization (Module 2)."""


class TestSchemaInit:
    """Verify that neug schema tables and zvec collection are created."""

    def test_node_tables_exist(self, scope):
        for table in ("File", "Function", "Class", "Module"):
            rows = list(scope.conn.execute(
                f"MATCH (n:{table}) RETURN count(n)"
            ))
            assert rows[0][0] == 0, f"Table {table} should be empty initially"

    def test_rel_tables_exist(self, scope):
        """Creating edges on empty tables should not error."""
        # We just verify the queries compile — they return 0 rows.
        for rel in ("CALLS", "DEFINES_FUNC", "DEFINES_CLASS",
                     "HAS_METHOD", "IMPORTS", "BELONGS_TO"):
            rows = list(scope.conn.execute(
                f"MATCH ()-[r:{rel}]->() RETURN count(r)"
            ))
            assert rows[0][0] == 0

    def test_zvec_collection_accessible(self, scope):
        assert scope.collection is not None
        assert scope.collection.schema.name == "functions"

    def test_embedding_cache_empty(self, scope):
        assert len(scope._emb_cache) == 0

    def test_close_and_cleanup(self, tmp_dir):
        import os
        from codegraph.core import CodeScope
        cs = CodeScope(db_dir=os.path.join(tmp_dir, "close_test"))
        cs.close()
        # Should not raise
