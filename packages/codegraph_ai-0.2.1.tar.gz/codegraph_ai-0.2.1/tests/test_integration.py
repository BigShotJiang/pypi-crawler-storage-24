"""End-to-end integration tests using the sample_project.

These tests index the full sample_project and run all 3 use cases,
verifying that non-empty, reasonable results are produced.
"""

from __future__ import annotations

import os
import shutil
import tempfile

import pytest

from codegraph.core import CodeScope
from codegraph.models import CrossLocateResult

SAMPLE_PROJECT = os.path.join(
    os.path.dirname(__file__), "..", "sample_project"
)


@pytest.fixture(scope="module")
def indexed_scope():
    """Create, index, and yield a CodeScope instance over sample_project.

    Scoped to the module so indexing happens only once for all tests.
    """
    db_dir = tempfile.mkdtemp(prefix="codegraph_integration_")
    cs = CodeScope(db_dir=os.path.join(db_dir, "cs_db"))
    cs.index(os.path.abspath(SAMPLE_PROJECT), languages=["python"])
    yield cs
    cs.close()
    shutil.rmtree(db_dir, ignore_errors=True)


# =========================================================================
# Indexing verification
# =========================================================================


class TestIntegrationIndexing:
    def test_file_count(self, indexed_scope):
        rows = list(indexed_scope.conn.execute(
            "MATCH (f:File) RETURN count(f)"
        ))
        # 26 Python files in sample_project
        assert rows[0][0] == 26

    def test_function_count(self, indexed_scope):
        rows = list(indexed_scope.conn.execute(
            "MATCH (f:Function) RETURN count(f)"
        ))
        # Should have a meaningful number of functions
        assert rows[0][0] >= 20

    def test_call_edges_exist(self, indexed_scope):
        rows = list(indexed_scope.conn.execute(
            "MATCH ()-[e:CALLS]->() RETURN count(e)"
        ))
        assert rows[0][0] >= 5

    def test_module_nodes_exist(self, indexed_scope):
        rows = list(indexed_scope.conn.execute(
            "MATCH (m:Module) RETURN m.path_prefix"
        ))
        prefixes = {r[0] for r in rows}
        for expected in ("api", "auth", "db", "parsers", "reports",
                         "utils", "validators", "middleware", "exporters"):
            assert expected in prefixes, f"Missing module: {expected}"


# =========================================================================
# Use Case 1: Impact Analysis
# =========================================================================


class TestIntegrationImpact:
    def test_impact_execute_query(self, indexed_scope):
        results = indexed_scope.impact(
            function="execute_query",
            change="return type changed from list[dict] to DataFrame",
            max_hops=3,
        )
        assert len(results) > 0
        names = [r.name for r in results]
        # build_report directly calls execute_query
        assert "build_report" in names

    def test_impact_results_sorted(self, indexed_scope):
        results = indexed_scope.impact(
            function="execute_query",
            change="return type changed",
        )
        scores = [r.relevance for r in results]
        assert scores == sorted(scores, reverse=True)

    def test_impact_no_callers(self, indexed_scope):
        results = indexed_scope.impact(
            function="handle_request",
            change="anything",
        )
        # handle_request is top of chain
        assert results == []


# =========================================================================
# Use Case 2: Module-Scoped Search
# =========================================================================


class TestIntegrationSimilar:
    def test_similar_parsers(self, indexed_scope):
        results = indexed_scope.similar(
            function="parse_json",
            scope="parsers",
            topk=5,
        )
        assert len(results) > 0
        names = [r.name for r in results]
        # parse_yaml is very similar to parse_json
        assert "parse_yaml" in names

    def test_similar_stays_in_scope(self, indexed_scope):
        results = indexed_scope.similar(
            function="parse_json",
            scope="parsers",
        )
        for r in results:
            assert "parsers" in r.file_path

    def test_similar_sorted(self, indexed_scope):
        results = indexed_scope.similar(
            function="parse_json",
            scope="parsers",
        )
        scores = [r.score for r in results]
        assert scores == sorted(scores, reverse=True)


# =========================================================================
# Use Case 3: Cross-Locate
# =========================================================================


class TestIntegrationCrossLocate:
    def test_cross_locate_returns_result(self, indexed_scope):
        result = indexed_scope.cross_locate(
            "database query execution SQL",
            topk=6,
        )
        assert isinstance(result, CrossLocateResult)

    def test_cross_locate_has_seeds(self, indexed_scope):
        result = indexed_scope.cross_locate("database query SQL")
        assert len(result.seeds) > 0

    def test_cross_locate_clusters(self, indexed_scope):
        result = indexed_scope.cross_locate("database query SQL")
        assert len(result.clusters) > 0
        # Every seed should appear in exactly one cluster
        clustered = set()
        for cluster in result.clusters:
            clustered.update(cluster)
        seed_names = {s["name"] for s in result.seeds}
        assert seed_names == clustered


# =========================================================================
# Vector-only comparison
# =========================================================================


class TestIntegrationVectorOnly:
    def test_vector_only_search(self, indexed_scope):
        results = indexed_scope.vector_only_search(
            "parse file data", topk=5
        )
        assert len(results) > 0
        for r in results:
            assert "id" in r
            assert "score" in r


# =========================================================================
# Cleanup
# =========================================================================


class TestCleanup:
    def test_close_does_not_raise(self):
        db_dir = tempfile.mkdtemp(prefix="codegraph_cleanup_test_")
        cs = CodeScope(db_dir=os.path.join(db_dir, "cs_db"))
        cs.close()  # should not raise
        shutil.rmtree(db_dir, ignore_errors=True)
