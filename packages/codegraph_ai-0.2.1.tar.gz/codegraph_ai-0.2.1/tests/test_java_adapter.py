"""Unit tests for the Java language adapter."""

from __future__ import annotations

import pytest

from codegraph.adapters.java_adapter import JavaAdapter


@pytest.fixture
def adapter():
    return JavaAdapter()


SAMPLE_JAVA = b"""\
package com.example.app;

import java.util.List;
import java.util.Map;
import java.util.*;
import static java.lang.Math.abs;
import static org.junit.Assert.*;

/**
 * A sample class demonstrating Java features.
 * This is the main documentation.
 */
@Deprecated
public class Foo<T extends Comparable<T>> extends AbstractFoo<T> implements Serializable, Cloneable {
    private int count;

    /**
     * Does something with items.
     * @param items the list of items
     * @param x the count
     */
    @Override
    @SuppressWarnings("unchecked")
    public void doSomething(List<String> items, int x) {
        items.add("hello");
        helper();
        this.count++;
        Bar bar = new Bar();
        bar.process();
        String.valueOf(42);
        super.cleanup();
    }

    public static <T> List<T> sort(List<T> items) {
        return items;
    }

    public Foo(int x) {
        super(x);
    }

    class Inner extends Outer.InnerBase {
        void innerMethod() {
            doSomething(null, 0);
        }
    }
}
"""


class TestClassExtraction:
    def test_main_class(self, adapter):
        result = adapter.parse_file(SAMPLE_JAVA, "com/example/Foo.java")
        class_names = [c.name for c in result.classes]
        assert "Foo" in class_names

    def test_class_base_classes(self, adapter):
        result = adapter.parse_file(SAMPLE_JAVA, "com/example/Foo.java")
        foo = next(c for c in result.classes if c.name == "Foo")
        assert "AbstractFoo" in foo.base_classes
        assert "Serializable" in foo.base_classes
        assert "Cloneable" in foo.base_classes

    def test_inner_class(self, adapter):
        result = adapter.parse_file(SAMPLE_JAVA, "com/example/Foo.java")
        class_names = [c.name for c in result.classes]
        assert "Foo.Inner" in class_names

    def test_inner_class_base(self, adapter):
        result = adapter.parse_file(SAMPLE_JAVA, "com/example/Foo.java")
        inner = next(c for c in result.classes if c.name == "Foo.Inner")
        assert len(inner.base_classes) > 0

    def test_class_method_names(self, adapter):
        result = adapter.parse_file(SAMPLE_JAVA, "com/example/Foo.java")
        foo = next(c for c in result.classes if c.name == "Foo")
        assert "doSomething" in foo.method_names
        assert "sort" in foo.method_names
        assert "<init>" in foo.method_names


class TestMethodExtraction:
    def test_method_count(self, adapter):
        result = adapter.parse_file(SAMPLE_JAVA, "com/example/Foo.java")
        foo_methods = [f for f in result.functions if f.class_name == "Foo"]
        assert len(foo_methods) == 3  # doSomething, sort, <init>

    def test_method_signature(self, adapter):
        result = adapter.parse_file(SAMPLE_JAVA, "com/example/Foo.java")
        do_something = next(
            f for f in result.functions
            if f.name == "doSomething" and f.class_name == "Foo"
        )
        assert "public" in do_something.signature
        assert "void" in do_something.signature
        assert "doSomething" in do_something.signature
        assert "List<String>" in do_something.signature

    def test_generic_method_signature(self, adapter):
        result = adapter.parse_file(SAMPLE_JAVA, "com/example/Foo.java")
        sort_fn = next(
            f for f in result.functions
            if f.name == "sort" and f.class_name == "Foo"
        )
        assert "static" in sort_fn.signature
        assert "<T>" in sort_fn.signature
        assert "List<T>" in sort_fn.signature

    def test_constructor(self, adapter):
        result = adapter.parse_file(SAMPLE_JAVA, "com/example/Foo.java")
        init = next(
            f for f in result.functions
            if f.name == "<init>" and f.class_name == "Foo"
        )
        assert "Foo" in init.signature
        assert "(int x)" in init.signature

    def test_javadoc(self, adapter):
        result = adapter.parse_file(SAMPLE_JAVA, "com/example/Foo.java")
        do_something = next(
            f for f in result.functions
            if f.name == "doSomething" and f.class_name == "Foo"
        )
        assert "Does something with items" in do_something.doc_comment

    def test_qualified_name(self, adapter):
        result = adapter.parse_file(SAMPLE_JAVA, "com/example/Foo.java")
        do_something = next(
            f for f in result.functions
            if f.name == "doSomething" and f.class_name == "Foo"
        )
        assert do_something.qualified_name == "com/example/Foo.java:Foo.doSomething"

    def test_inner_class_method(self, adapter):
        result = adapter.parse_file(SAMPLE_JAVA, "com/example/Foo.java")
        inner_method = next(
            f for f in result.functions if f.name == "innerMethod"
        )
        assert inner_method.class_name == "Foo.Inner"
        assert "Foo.Inner.innerMethod" in inner_method.qualified_name


class TestCallExtraction:
    def test_receiver_call(self, adapter):
        result = adapter.parse_file(SAMPLE_JAVA, "com/example/Foo.java")
        do_something = next(
            f for f in result.functions
            if f.name == "doSomething" and f.class_name == "Foo"
        )
        assert "add" in do_something.call_names
        assert "process" in do_something.call_names

    def test_static_call(self, adapter):
        result = adapter.parse_file(SAMPLE_JAVA, "com/example/Foo.java")
        do_something = next(
            f for f in result.functions
            if f.name == "doSomething" and f.class_name == "Foo"
        )
        assert "valueOf" in do_something.call_names

    def test_implicit_this_call(self, adapter):
        result = adapter.parse_file(SAMPLE_JAVA, "com/example/Foo.java")
        do_something = next(
            f for f in result.functions
            if f.name == "doSomething" and f.class_name == "Foo"
        )
        assert "helper" in do_something.call_names

    def test_super_call(self, adapter):
        result = adapter.parse_file(SAMPLE_JAVA, "com/example/Foo.java")
        do_something = next(
            f for f in result.functions
            if f.name == "doSomething" and f.class_name == "Foo"
        )
        assert "cleanup" in do_something.call_names

    def test_new_constructor_call(self, adapter):
        result = adapter.parse_file(SAMPLE_JAVA, "com/example/Foo.java")
        do_something = next(
            f for f in result.functions
            if f.name == "doSomething" and f.class_name == "Foo"
        )
        assert "Bar.<init>" in do_something.call_names

    def test_call_receiver_info(self, adapter):
        result = adapter.parse_file(SAMPLE_JAVA, "com/example/Foo.java")
        do_something = next(
            f for f in result.functions
            if f.name == "doSomething" and f.class_name == "Foo"
        )
        bar_call = next(
            c for c in do_something.calls if c.callee_name == "process"
        )
        assert bar_call.receiver == "bar"


class TestImportExtraction:
    def test_single_import(self, adapter):
        result = adapter.parse_file(SAMPLE_JAVA, "com/example/Foo.java")
        modules = [i.target_module for i in result.imports]
        assert "java.util.List" in modules
        assert "java.util.Map" in modules

    def test_wildcard_import(self, adapter):
        result = adapter.parse_file(SAMPLE_JAVA, "com/example/Foo.java")
        wildcard = next(
            i for i in result.imports if i.target_module == "java.util"
        )
        assert wildcard.imported_names == ["*"]

    def test_static_import(self, adapter):
        result = adapter.parse_file(SAMPLE_JAVA, "com/example/Foo.java")
        static_abs = next(
            i for i in result.imports if "Math" in i.target_module
        )
        assert "abs" in static_abs.imported_names

    def test_static_wildcard_import(self, adapter):
        result = adapter.parse_file(SAMPLE_JAVA, "com/example/Foo.java")
        static_wc = next(
            i for i in result.imports if "Assert" in i.target_module
        )
        assert static_wc.imported_names == ["*"]

    def test_import_names(self, adapter):
        result = adapter.parse_file(SAMPLE_JAVA, "com/example/Foo.java")
        list_import = next(
            i for i in result.imports if i.target_module == "java.util.List"
        )
        assert "List" in list_import.imported_names


class TestInterfaceAndEnum:
    INTERFACE_JAVA = b"""\
package com.example;

interface Readable<T> extends Closeable {
    T read();
    default void close() {}
}
"""

    ENUM_JAVA = b"""\
package com.example;

enum Color implements Serializable {
    RED, GREEN, BLUE;

    public String display() { return name().toLowerCase(); }
}
"""

    def test_interface(self, adapter):
        result = adapter.parse_file(self.INTERFACE_JAVA, "Readable.java")
        assert len(result.classes) == 1
        cls = result.classes[0]
        assert cls.name == "Readable"
        assert "Closeable" in cls.base_classes
        assert "read" in cls.method_names
        assert "close" in cls.method_names

    def test_enum(self, adapter):
        result = adapter.parse_file(self.ENUM_JAVA, "Color.java")
        assert len(result.classes) == 1
        cls = result.classes[0]
        assert cls.name == "Color"
        assert "Serializable" in cls.base_classes
        assert "display" in cls.method_names

    def test_enum_method_calls(self, adapter):
        result = adapter.parse_file(self.ENUM_JAVA, "Color.java")
        display = next(f for f in result.functions if f.name == "display")
        assert "name" in display.call_names
        assert "toLowerCase" in display.call_names


class TestEdgeCases:
    SYNTAX_ERROR_JAVA = b"""\
public class Broken {
    public void foo( {
        // missing closing paren
    }
}
"""

    ABSTRACT_CLASS = b"""\
public abstract class AbstractHandler {
    abstract void handle(String input);
    protected final void log(String msg) {}
}
"""

    LAMBDA_JAVA = b"""\
import java.util.function.Consumer;

public class LambdaTest {
    public void run() {
        Consumer<String> printer = s -> System.out.println(s);
        Runnable r = () -> doWork();
    }
}
"""

    def test_syntax_error_no_crash(self, adapter):
        result = adapter.parse_file(self.SYNTAX_ERROR_JAVA, "Broken.java")
        assert result is not None

    def test_abstract_class(self, adapter):
        result = adapter.parse_file(self.ABSTRACT_CLASS, "AbstractHandler.java")
        cls = result.classes[0]
        assert cls.name == "AbstractHandler"
        assert "handle" in cls.method_names
        assert "log" in cls.method_names

    def test_lambda_calls(self, adapter):
        result = adapter.parse_file(self.LAMBDA_JAVA, "LambdaTest.java")
        run = next(f for f in result.functions if f.name == "run")
        assert "println" in run.call_names or "doWork" in run.call_names

    def test_can_handle(self, adapter):
        assert adapter.can_handle("Foo.java")
        assert not adapter.can_handle("Foo.py")
        assert not adapter.can_handle("Foo.class")

    def test_language_name(self, adapter):
        assert adapter.language_name() == "java"
