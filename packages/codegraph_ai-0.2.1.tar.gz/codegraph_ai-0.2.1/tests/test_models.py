"""Tests for codegraph.models dataclasses."""

from codegraph.models import (
    CrossLocateResult,
    ImpactResult,
    ParsedClass,
    ParsedFunction,
    ParsedImport,
    ParseResult,
    SimilarResult,
)


class TestImpactResult:
    def test_basic_creation(self):
        r = ImpactResult(
            name="foo",
            qualified_name="mod.py:foo",
            file_path="mod.py",
            hop_distance=2,
            relevance=0.85,
        )
        assert r.name == "foo"
        assert r.hop_distance == 2
        assert r.relevance == 0.85

    def test_equality(self):
        a = ImpactResult("f", "q", "p", 1, 0.5)
        b = ImpactResult("f", "q", "p", 1, 0.5)
        assert a == b


class TestSimilarResult:
    def test_basic(self):
        r = SimilarResult(name="bar", signature="def bar()", file_path="b.py", score=0.9)
        assert r.score == 0.9


class TestCrossLocateResult:
    def test_defaults(self):
        r = CrossLocateResult()
        assert r.seeds == []
        assert r.connections == []
        assert r.clusters == []


class TestParsedFunction:
    def test_defaults(self):
        f = ParsedFunction(
            name="fn",
            qualified_name="a.py:fn",
            signature="def fn()",
            file_path="a.py",
            start_line=1,
            end_line=3,
        )
        assert f.doc_comment == ""
        assert f.call_names == []
        assert f.class_name is None


class TestParsedClass:
    def test_defaults(self):
        c = ParsedClass(
            name="Cls",
            qualified_name="a.py:Cls",
            file_path="a.py",
            start_line=1,
            end_line=10,
        )
        assert c.method_names == []


class TestParsedImport:
    def test_creation(self):
        i = ParsedImport(source_path="a.py", target_module="os")
        assert i.target_module == "os"


class TestParseResult:
    def test_defaults(self):
        pr = ParseResult()
        assert pr.functions == []
        assert pr.classes == []
        assert pr.imports == []
