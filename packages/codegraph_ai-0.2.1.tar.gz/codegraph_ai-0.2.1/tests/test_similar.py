"""Tests for Use Case 2: Module-Scoped Semantic Search (Module 5).

parsers/ module contains: parse_json, parse_yaml
"""

import pytest


class TestModuleScopedSearch:
    """Test the similar() method."""

    @pytest.fixture(autouse=True)
    def _indexed(self, scope, mini_repo):
        scope.index(mini_repo, languages=["python"])
        self.scope = scope

    def test_similar_in_scope(self):
        results = self.scope.similar(
            function="parse_json",
            scope="parsers",
        )
        names = [r.name for r in results]
        assert "parse_yaml" in names

    def test_results_within_scope(self):
        results = self.scope.similar(
            function="parse_json",
            scope="parsers",
        )
        # All results should be from parsers/
        for r in results:
            assert "parsers" in r.file_path

    def test_excludes_other_modules(self):
        results = self.scope.similar(
            function="parse_json",
            scope="parsers",
        )
        names = [r.name for r in results]
        # Functions from api/ or db/ should NOT appear
        assert "execute_query" not in names
        assert "handle_request" not in names

    def test_sorted_by_score(self):
        results = self.scope.similar(
            function="parse_json",
            scope="parsers",
        )
        scores = [r.score for r in results]
        assert scores == sorted(scores, reverse=True)

    def test_function_not_found(self):
        results = self.scope.similar(
            function="nonexistent",
            scope="parsers",
        )
        assert results == []

    def test_empty_scope(self):
        results = self.scope.similar(
            function="parse_json",
            scope="nonexistent_module",
        )
        assert results == []
