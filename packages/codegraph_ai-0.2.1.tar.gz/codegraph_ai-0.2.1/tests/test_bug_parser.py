"""Unit tests for bug_parser — file path, function name, and stack trace extraction."""

from __future__ import annotations

from codegraph.bug_parser import (
    ParsedIssue,
    extract_file_paths,
    extract_function_names,
    extract_stack_trace_locations,
    parse_issue,
)


# ===== extract_file_paths =====

class TestExtractFilePaths:
    def test_python_paths(self):
        text = "The error is in src/main.py and also in utils/helpers.py:42"
        paths = extract_file_paths(text)
        assert "src/main.py" in paths
        assert "utils/helpers.py" in paths

    def test_javascript_paths(self):
        text = "Check src/components/Button.tsx and lib/api/client.js"
        paths = extract_file_paths(text)
        assert "src/components/Button.tsx" in paths
        assert "lib/api/client.js" in paths

    def test_c_paths(self):
        text = "kernel/sched/core.c and include/linux/sched.h are involved"
        paths = extract_file_paths(text)
        assert "kernel/sched/core.c" in paths
        assert "include/linux/sched.h" in paths

    def test_typescript_paths(self):
        text = "The bug is in src/gateway/index.ts and src/channels/discord.ts"
        paths = extract_file_paths(text)
        assert "src/gateway/index.ts" in paths
        assert "src/channels/discord.ts" in paths

    def test_no_urls(self):
        text = "See https://github.com/owner/repo/blob/main/src/main.py for details"
        paths = extract_file_paths(text)
        # Should not extract the URL-embedded path
        assert not any("github.com" in p for p in paths)

    def test_deduplication(self):
        text = "src/main.py is broken. Also src/main.py needs fixing."
        paths = extract_file_paths(text)
        assert paths.count("src/main.py") == 1

    def test_empty_text(self):
        assert extract_file_paths("") == []

    def test_no_paths(self):
        text = "This is just a regular bug report with no file references."
        assert extract_file_paths(text) == []

    def test_go_paths(self):
        text = "Error in pkg/server/handler.go"
        paths = extract_file_paths(text)
        assert "pkg/server/handler.go" in paths

    def test_rust_paths(self):
        text = "src/lib.rs panicked at src/parser/mod.rs:42"
        paths = extract_file_paths(text)
        assert "src/lib.rs" in paths
        assert "src/parser/mod.rs" in paths


# ===== extract_function_names =====

class TestExtractFunctionNames:
    def test_python_stack_trace(self):
        text = '''Traceback (most recent call last):
  File "src/main.py", line 42, in handle_request
    result = process_data(input)
  File "src/processor.py", line 15, in process_data
    return transform(data)
'''
        funcs = extract_function_names(text)
        assert "handle_request" in funcs
        assert "process_data" in funcs

    def test_c_stack_trace(self):
        text = """#0 0x00007ff in schedule () at kernel/sched/core.c:6218
#1 0x00008ff in do_fork () at kernel/fork.c:2100
#2 0x00009ff in sys_clone () at kernel/fork.c:2530
"""
        funcs = extract_function_names(text)
        assert "schedule" in funcs
        assert "do_fork" in funcs
        assert "sys_clone" in funcs

    def test_javascript_stack_trace(self):
        text = """Error: connection refused
    at connect (src/net/client.js:42:10)
    at handleMessage (src/gateway/ws.js:100:5)
"""
        funcs = extract_function_names(text)
        assert "connect" in funcs
        assert "handleMessage" in funcs

    def test_backtick_function_refs(self):
        text = "The `process_data()` function crashes when called from `handle_request()`"
        funcs = extract_function_names(text)
        assert "process_data" in funcs
        assert "handle_request" in funcs

    def test_empty_text(self):
        assert extract_function_names("") == []

    def test_skips_common_words(self):
        text = '''File "test.py", line 1, in self
File "test.py", line 2, in None'''
        funcs = extract_function_names(text)
        assert "self" not in funcs
        assert "None" not in funcs

    def test_deduplication(self):
        text = '''File "a.py", line 1, in foo
File "b.py", line 2, in foo'''
        funcs = extract_function_names(text)
        assert funcs.count("foo") == 1


# ===== extract_stack_trace_locations =====

class TestExtractStackTraceLocations:
    def test_python_locations(self):
        text = '''File "src/main.py", line 42, in handle_request
File "src/db.py", line 15, in query'''
        locs = extract_stack_trace_locations(text)
        assert ("src/main.py", 42) in locs
        assert ("src/db.py", 15) in locs

    def test_c_locations(self):
        text = "#0 0x00007ff in schedule () at kernel/sched/core.c:6218"
        locs = extract_stack_trace_locations(text)
        assert ("kernel/sched/core.c", 6218) in locs

    def test_js_locations(self):
        text = "    at connect (src/net/client.js:42:10)"
        locs = extract_stack_trace_locations(text)
        assert ("src/net/client.js", 42) in locs

    def test_path_with_line_number(self):
        text = "See src/main.py:42 for the error"
        locs = extract_stack_trace_locations(text)
        assert ("src/main.py", 42) in locs

    def test_empty(self):
        assert extract_stack_trace_locations("") == []


# ===== parse_issue =====

class TestParseIssue:
    def test_basic_parsing(self):
        raw = {
            "number": 42,
            "title": "Crash in scheduler",
            "body": "The error is in kernel/sched/core.c\n\nStack:\n"
                    'File "kernel/sched/core.c", line 100, in schedule',
            "labels": ["bug", "scheduler"],
            "linked_commits": ["abc123"],
        }
        parsed = parse_issue(raw, "torvalds", "linux")

        assert parsed.owner == "torvalds"
        assert parsed.repo == "linux"
        assert parsed.number == 42
        assert parsed.title == "Crash in scheduler"
        assert "bug" in parsed.labels
        assert "kernel/sched/core.c" in parsed.extracted_paths
        assert "schedule" in parsed.extracted_funcs
        assert "abc123" in parsed.linked_commits
        assert parsed.fetched_at > 0

    def test_empty_body(self):
        raw = {
            "number": 1,
            "title": "Something is broken",
            "body": "",
            "labels": [],
            "linked_commits": [],
        }
        parsed = parse_issue(raw, "owner", "repo")
        assert parsed.number == 1
        assert parsed.extracted_paths == []
        assert parsed.extracted_funcs == []

    def test_complex_issue(self):
        raw = {
            "number": 999,
            "title": "Gateway crashes when processing WhatsApp messages",
            "body": """
When sending a message via WhatsApp, the gateway crashes with:

```
Traceback (most recent call last):
  File "src/gateway/handler.py", line 42, in handle_message
    result = process_whatsapp(msg)
  File "src/channels/whatsapp.py", line 100, in process_whatsapp
    parsed = parse_message(msg.body)
  File "src/parsers/message.py", line 55, in parse_message
    return json.loads(raw)
```

Related files: src/gateway/config.ts
The `validate_input()` function should prevent this.
""",
            "labels": ["bug", "whatsapp", "gateway"],
            "linked_commits": ["deadbeef1234"],
        }
        parsed = parse_issue(raw, "openclaw", "openclaw")

        assert "src/gateway/handler.py" in parsed.extracted_paths
        assert "src/channels/whatsapp.py" in parsed.extracted_paths
        assert "src/parsers/message.py" in parsed.extracted_paths
        assert "src/gateway/config.ts" in parsed.extracted_paths

        assert "handle_message" in parsed.extracted_funcs
        assert "process_whatsapp" in parsed.extracted_funcs
        assert "parse_message" in parsed.extracted_funcs
        assert "validate_input" in parsed.extracted_funcs

        assert ("src/gateway/handler.py", 42) in parsed.extracted_locations
