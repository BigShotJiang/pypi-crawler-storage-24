"""Tests for Layer 2/3 features: richer embeddings, dead code, hotspots, etc."""

from __future__ import annotations

import os
from pathlib import Path

import pytest


# ============================================================================
# Fixtures
# ============================================================================


@pytest.fixture()
def inheritance_repo(tmp_dir) -> str:
    """Repo with class inheritance for INHERITS / class_hierarchy tests."""
    root = os.path.join(tmp_dir, "inherit_repo")
    files = {
        "base.py": (
            "class Animal:\n"
            "    def speak(self) -> str:\n"
            "        return ''\n"
            "\n"
            "    def move(self) -> str:\n"
            "        return 'moving'\n"
        ),
        "dog.py": (
            "from base import Animal\n"
            "\n"
            "\n"
            "class Dog(Animal):\n"
            "    def speak(self) -> str:\n"
            "        return 'woof'\n"
            "\n"
            "    def fetch(self) -> str:\n"
            "        sound = self.speak()\n"
            "        return f'fetching with {sound}'\n"
        ),
        "guide_dog.py": (
            "from dog import Dog\n"
            "\n"
            "\n"
            "class GuideDog(Dog):\n"
            "    def guide(self) -> str:\n"
            "        self.move()\n"
            "        return 'guiding'\n"
        ),
    }
    for rel, content in files.items():
        full = os.path.join(root, rel)
        os.makedirs(os.path.dirname(full), exist_ok=True)
        Path(full).write_text(content)
    return root


@pytest.fixture()
def dead_code_repo(tmp_dir) -> str:
    """Repo with a mix of called and uncalled functions."""
    root = os.path.join(tmp_dir, "dead_repo")
    files = {
        "main.py": (
            "from helpers import active_helper\n"
            "\n"
            "\n"
            "def main():\n"
            "    result = active_helper()\n"
            "    return result\n"
        ),
        "helpers.py": (
            "def active_helper() -> str:\n"
            "    return 'used'\n"
            "\n"
            "\n"
            "def orphan_func() -> str:\n"
            "    \"\"\"Nobody calls this.\"\"\"\n"
            "    return 'unused'\n"
            "\n"
            "\n"
            "def another_orphan(x: int) -> int:\n"
            "    \"\"\"Also never called.\"\"\"\n"
            "    return x + 1\n"
        ),
    }
    for rel, content in files.items():
        full = os.path.join(root, rel)
        os.makedirs(os.path.dirname(full), exist_ok=True)
        Path(full).write_text(content)
    return root


@pytest.fixture()
def circular_repo(tmp_dir) -> str:
    """Repo with circular imports: a -> b -> c -> a."""
    root = os.path.join(tmp_dir, "circ_repo")
    files = {
        "mod_a.py": (
            "from mod_b import func_b\n"
            "\n"
            "def func_a():\n"
            "    return func_b()\n"
        ),
        "mod_b.py": (
            "from mod_c import func_c\n"
            "\n"
            "def func_b():\n"
            "    return func_c()\n"
        ),
        "mod_c.py": (
            "from mod_a import func_a\n"
            "\n"
            "def func_c():\n"
            "    return func_a()\n"
        ),
    }
    for rel, content in files.items():
        full = os.path.join(root, rel)
        os.makedirs(os.path.dirname(full), exist_ok=True)
        Path(full).write_text(content)
    return root


@pytest.fixture()
def coupling_repo(tmp_dir) -> str:
    """Repo with two modules that call into each other."""
    root = os.path.join(tmp_dir, "coupling_repo")
    files = {
        "core/__init__.py": "",
        "core/engine.py": (
            "from core.utils import format_output\n"
            "\n"
            "def run_engine(data):\n"
            "    return format_output(data)\n"
            "\n"
            "def get_status():\n"
            "    return 'running'\n"
        ),
        "core/utils.py": (
            "def format_output(data):\n"
            "    return str(data)\n"
        ),
        "io/__init__.py": "",
        "io/reader.py": (
            "from core.engine import run_engine, get_status\n"
            "\n"
            "def read_and_process(path):\n"
            "    run_engine(path)\n"
            "    return get_status()\n"
        ),
        "io/writer.py": (
            "from core.utils import format_output\n"
            "\n"
            "def write_data(data):\n"
            "    formatted = format_output(data)\n"
            "    return formatted\n"
        ),
    }
    for rel, content in files.items():
        full = os.path.join(root, rel)
        os.makedirs(os.path.dirname(full), exist_ok=True)
        Path(full).write_text(content)
    return root


@pytest.fixture()
def hotspot_repo(tmp_dir) -> str:
    """Repo where one function is called by many and calls many."""
    root = os.path.join(tmp_dir, "hotspot_repo")
    files = {
        "hub.py": (
            "from leaf import leaf_a, leaf_b, leaf_c\n"
            "\n"
            "def hub_func():\n"
            "    \"\"\"Central hub with high fan-out.\"\"\"\n"
            "    leaf_a()\n"
            "    leaf_b()\n"
            "    leaf_c()\n"
        ),
        "leaf.py": (
            "def leaf_a():\n"
            "    return 'a'\n"
            "\n"
            "def leaf_b():\n"
            "    return 'b'\n"
            "\n"
            "def leaf_c():\n"
            "    return 'c'\n"
        ),
        "caller1.py": (
            "from hub import hub_func\n"
            "\n"
            "def use_hub_1():\n"
            "    return hub_func()\n"
        ),
        "caller2.py": (
            "from hub import hub_func\n"
            "\n"
            "def use_hub_2():\n"
            "    return hub_func()\n"
        ),
    }
    for rel, content in files.items():
        full = os.path.join(root, rel)
        os.makedirs(os.path.dirname(full), exist_ok=True)
        Path(full).write_text(content)
    return root


@pytest.fixture()
def scope_aware_repo(tmp_dir) -> str:
    """Repo for testing scope-aware call resolution.

    Has two classes with a method named 'execute', to verify
    self.execute() resolves to the correct class.
    """
    root = os.path.join(tmp_dir, "scope_repo")
    files = {
        "db.py": (
            "class DbClient:\n"
            "    def execute(self, sql: str):\n"
            "        return []\n"
            "\n"
            "    def run_query(self, q: str):\n"
            "        return self.execute(q)\n"
        ),
        "http.py": (
            "class HttpClient:\n"
            "    def execute(self, url: str):\n"
            "        return '200 OK'\n"
            "\n"
            "    def fetch(self, endpoint: str):\n"
            "        return self.execute(endpoint)\n"
        ),
    }
    for rel, content in files.items():
        full = os.path.join(root, rel)
        os.makedirs(os.path.dirname(full), exist_ok=True)
        Path(full).write_text(content)
    return root


# ============================================================================
# Tests: Inheritance / INHERITS
# ============================================================================


class TestInheritance:
    """Test INHERITS edge creation and class_hierarchy query."""

    def test_inherits_edges_created(self, scope, inheritance_repo):
        scope.index(inheritance_repo, languages=["python"])
        rows = list(scope.conn.execute(
            "MATCH (c:Class)-[:INHERITS]->(base:Class) "
            "RETURN c.name, base.name"
        ))
        pairs = {(r[0], r[1]) for r in rows}
        assert ("Dog", "Animal") in pairs
        assert ("GuideDog", "Dog") in pairs

    def test_class_hierarchy_all(self, scope, inheritance_repo):
        scope.index(inheritance_repo, languages=["python"])
        hierarchy = scope.class_hierarchy()
        child_parent = {(h["child"], h["parent"]) for h in hierarchy}
        assert ("Dog", "Animal") in child_parent
        assert ("GuideDog", "Dog") in child_parent

    def test_class_hierarchy_single(self, scope, inheritance_repo):
        scope.index(inheritance_repo, languages=["python"])
        chain = scope.class_hierarchy(class_name="GuideDog")
        parents = [h["parent"] for h in chain]
        assert "Dog" in parents

    def test_self_call_resolves_to_own_class(self, scope, inheritance_repo):
        """Dog.fetch() calls self.speak() -> should resolve to Dog.speak."""
        scope.index(inheritance_repo, languages=["python"])
        rows = list(scope.conn.execute(
            "MATCH (a:Function {name: 'fetch'})-[:CALLS]->(b:Function) "
            "RETURN b.name, b.file_path"
        ))
        names = [r[0] for r in rows]
        assert "speak" in names
        speak_files = [r[1] for r in rows if r[0] == "speak"]
        assert any("dog.py" in f for f in speak_files)

    def test_base_class_method_resolution(self, scope, inheritance_repo):
        """GuideDog.guide() calls self.move() which is on Animal (base class)."""
        scope.index(inheritance_repo, languages=["python"])
        rows = list(scope.conn.execute(
            "MATCH (a:Function {name: 'guide'})-[:CALLS]->(b:Function) "
            "RETURN b.name, b.file_path"
        ))
        names = [r[0] for r in rows]
        assert "move" in names


# ============================================================================
# Tests: Scope-Aware Call Resolution
# ============================================================================


class TestScopeAwareResolution:
    """Test that self.method() resolves to the correct class, not globally."""

    def test_self_execute_stays_within_class(self, scope, scope_aware_repo):
        scope.index(scope_aware_repo, languages=["python"])
        # DbClient.run_query calls self.execute -> DbClient.execute (in db.py)
        rows = list(scope.conn.execute(
            "MATCH (a:Function {name: 'run_query'})-[:CALLS]->(b:Function) "
            "RETURN b.name, b.file_path"
        ))
        assert len(rows) >= 1
        targets = [(r[0], r[1]) for r in rows]
        assert any(n == "execute" and "db.py" in f for n, f in targets)
        assert not any(n == "execute" and "http.py" in f for n, f in targets)

    def test_http_fetch_stays_within_class(self, scope, scope_aware_repo):
        scope.index(scope_aware_repo, languages=["python"])
        rows = list(scope.conn.execute(
            "MATCH (a:Function {name: 'fetch'})-[:CALLS]->(b:Function) "
            "RETURN b.name, b.file_path"
        ))
        assert len(rows) >= 1
        targets = [(r[0], r[1]) for r in rows]
        assert any(n == "execute" and "http.py" in f for n, f in targets)
        assert not any(n == "execute" and "db.py" in f for n, f in targets)


# ============================================================================
# Tests: Dead Code Detection
# ============================================================================


class TestDeadCode:
    """Test dead_code() identifies uncalled functions."""

    def test_orphans_detected(self, scope, dead_code_repo):
        scope.index(dead_code_repo, languages=["python"])
        dead = scope.dead_code()
        names = {d.name for d in dead}
        assert "orphan_func" in names
        assert "another_orphan" in names

    def test_called_function_not_flagged(self, scope, dead_code_repo):
        scope.index(dead_code_repo, languages=["python"])
        dead = scope.dead_code()
        names = {d.name for d in dead}
        assert "active_helper" not in names

    def test_entry_point_not_flagged(self, scope, dead_code_repo):
        scope.index(dead_code_repo, languages=["python"])
        dead = scope.dead_code()
        names = {d.name for d in dead}
        assert "main" not in names

    def test_result_has_required_fields(self, scope, dead_code_repo):
        scope.index(dead_code_repo, languages=["python"])
        dead = scope.dead_code()
        assert len(dead) > 0
        d = dead[0]
        assert d.name
        assert d.file_path
        assert d.reason == "no callers"


# ============================================================================
# Tests: Circular Dependency Detection
# ============================================================================


class TestCircularDeps:
    """Test circular_deps() finds import cycles."""

    def test_cycle_detected(self, scope, circular_repo):
        scope.index(circular_repo, languages=["python"])
        cycles = scope.circular_deps()
        assert len(cycles) > 0

    def test_cycle_contains_expected_files(self, scope, circular_repo):
        scope.index(circular_repo, languages=["python"])
        cycles = scope.circular_deps()
        all_files = set()
        for cycle in cycles:
            all_files.update(cycle)
        assert any("mod_a" in f for f in all_files)
        assert any("mod_b" in f for f in all_files)
        assert any("mod_c" in f for f in all_files)

    def test_no_cycles_in_acyclic_repo(self, scope, dead_code_repo):
        scope.index(dead_code_repo, languages=["python"])
        cycles = scope.circular_deps()
        assert len(cycles) == 0


# ============================================================================
# Tests: Hotspot Analysis
# ============================================================================


class TestHotspots:
    """Test hotspots() ranking by fan-in * fan-out."""

    def test_hub_is_top_hotspot(self, scope, hotspot_repo):
        scope.index(hotspot_repo, languages=["python"])
        spots = scope.hotspots(topk=5)
        assert len(spots) > 0
        assert spots[0].name == "hub_func"

    def test_hub_fan_metrics(self, scope, hotspot_repo):
        scope.index(hotspot_repo, languages=["python"])
        spots = scope.hotspots(topk=10)
        hub = next(s for s in spots if s.name == "hub_func")
        assert hub.fan_in >= 2
        assert hub.fan_out >= 3

    def test_leaf_has_zero_fan_out(self, scope, hotspot_repo):
        scope.index(hotspot_repo, languages=["python"])
        spots = scope.hotspots(topk=20)
        leaf_a = next((s for s in spots if s.name == "leaf_a"), None)
        assert leaf_a is not None
        assert leaf_a.fan_out == 0

    def test_topk_limits_results(self, scope, hotspot_repo):
        scope.index(hotspot_repo, languages=["python"])
        spots = scope.hotspots(topk=2)
        assert len(spots) <= 2

    def test_sorted_by_risk_descending(self, scope, hotspot_repo):
        scope.index(hotspot_repo, languages=["python"])
        spots = scope.hotspots(topk=10)
        for i in range(len(spots) - 1):
            assert spots[i].risk_score >= spots[i + 1].risk_score


# ============================================================================
# Tests: Module Coupling
# ============================================================================


class TestModuleCoupling:
    """Test module_coupling() finds cross-module dependencies."""

    def test_coupling_detected(self, scope, coupling_repo):
        scope.index(coupling_repo, languages=["python"])
        coupling = scope.module_coupling()
        assert len(coupling) > 0

    def test_core_io_coupling(self, scope, coupling_repo):
        scope.index(coupling_repo, languages=["python"])
        coupling = scope.module_coupling()
        module_pairs = {(c.module_a, c.module_b) for c in coupling}
        has_core_io = any(
            ("core" in a and "io" in b) or ("io" in a and "core" in b)
            for a, b in module_pairs
        )
        assert has_core_io

    def test_coupling_has_function_details(self, scope, coupling_repo):
        scope.index(coupling_repo, languages=["python"])
        coupling = scope.module_coupling()
        assert len(coupling) > 0
        c = coupling[0]
        assert len(c.functions_involved) > 0

    def test_sorted_by_total_calls(self, scope, coupling_repo):
        scope.index(coupling_repo, languages=["python"])
        coupling = scope.module_coupling()
        for i in range(len(coupling) - 1):
            total_i = coupling[i].calls_a_to_b + coupling[i].calls_b_to_a
            total_j = coupling[i + 1].calls_a_to_b + coupling[i + 1].calls_b_to_a
            assert total_i >= total_j


# ============================================================================
# Tests: Enriched Embeddings (Layer 2)
# ============================================================================


class TestEnrichedEmbeddings:
    """Verify that function body text is included in embeddings."""

    def test_body_in_embedding_cache(self, scope, dead_code_repo):
        scope.index(dead_code_repo, languages=["python"])
        assert len(scope._emb_cache) > 0

    def test_similar_functions_benefit_from_body(self, scope, hotspot_repo):
        """Functions with similar bodies should score higher than before."""
        scope.index(hotspot_repo, languages=["python"])
        assert len(scope._emb_cache) >= 3


# ============================================================================
# Tests: Integration with sample_project
# ============================================================================


class TestSampleProjectAdvanced:
    """Run Layer 2/3 queries against the real sample_project."""

    @pytest.fixture(autouse=True)
    def _setup(self, scope):
        sample = os.path.join(
            os.path.dirname(__file__), "..", "sample_project"
        )
        if os.path.isdir(sample):
            scope.index(os.path.abspath(sample), languages=["python"])
            self.cs = scope
            self.available = True
        else:
            self.available = False

    def test_dead_code_finds_candidates(self):
        if not self.available:
            pytest.skip("sample_project not found")
        dead = self.cs.dead_code()
        assert len(dead) > 0
        names = {d.name for d in dead}
        assert "generate_salt" in names or "dict_to_json" in names or len(names) > 3

    def test_hotspots_returns_results(self):
        if not self.available:
            pytest.skip("sample_project not found")
        spots = self.cs.hotspots(topk=5)
        assert len(spots) > 0
        assert spots[0].risk_score > 1.0

    def test_module_coupling_returns_results(self):
        if not self.available:
            pytest.skip("sample_project not found")
        coupling = self.cs.module_coupling()
        assert len(coupling) > 0

    def test_inherits_in_sample_project(self):
        if not self.available:
            pytest.skip("sample_project not found")
        hierarchy = self.cs.class_hierarchy()
        child_parent = {(h["child"], h["parent"]) for h in hierarchy}
        assert ("JsonParser", "BaseParser") in child_parent
        assert ("CsvParser", "BaseParser") in child_parent
        assert ("SqliteConnection", "BaseConnection") in child_parent

    def test_dead_code_sorted(self):
        if not self.available:
            pytest.skip("sample_project not found")
        dead = self.cs.dead_code()
        for i in range(len(dead) - 1):
            key_i = (dead[i].file_path, dead[i].name)
            key_j = (dead[i + 1].file_path, dead[i + 1].name)
            assert key_i <= key_j
