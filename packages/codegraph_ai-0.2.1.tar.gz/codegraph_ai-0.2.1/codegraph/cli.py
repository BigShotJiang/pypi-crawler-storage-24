#!/usr/bin/env python3
"""CodeScope CLI — unified command-line interface for code intelligence.

Usage::

    codegraph init                        # index current repo
    codegraph init --repo /path/to/repo   # index a specific repo
    codegraph open                        # open index, print summary
    codegraph query "who calls free_irq?" # ask a question
    codegraph analyze                     # generate architecture report
    codegraph status                      # show index health
    codegraph ingest --commits 500        # ingest git history
    codegraph server                      # start MCP server
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import time

DB_DEFAULT = ".codegraph"


def _find_db(explicit: str | None) -> str:
    """Resolve database path: explicit > .codegraph in cwd > error."""
    if explicit:
        return explicit
    if os.path.isdir(DB_DEFAULT):
        return DB_DEFAULT
    return DB_DEFAULT


def _detect_languages(repo_path: str) -> list[str]:
    from pathlib import Path

    ext_map = {
        ".py": "python", ".c": "c", ".h": "c",
        ".js": "javascript", ".jsx": "javascript",
        ".ts": "typescript", ".tsx": "typescript",
        ".mjs": "javascript", ".cjs": "javascript",
        ".java": "java",
    }
    counts: dict[str, int] = {}
    exclude = {".git", "node_modules", "__pycache__", ".venv", "venv", "build", "dist"}
    for f in Path(repo_path).rglob("*"):
        if f.is_file() and not any(p in exclude for p in f.parts):
            lang = ext_map.get(f.suffix)
            if lang:
                counts[lang] = counts.get(lang, 0) + 1
    if not counts:
        return ["python"]
    return sorted(counts, key=counts.get, reverse=True)[:2]


def _clean_locks(db_dir: str) -> None:
    """Remove stale lock files left by crashed processes."""
    import signal

    neug_lock = os.path.join(db_dir, "graph.db", "neugdb.lock")
    if os.path.exists(neug_lock):
        os.remove(neug_lock)

    zvec_lock = os.path.join(db_dir, "vectors", "LOCK")
    if os.path.isdir(os.path.join(db_dir, "vectors")) and not os.path.exists(zvec_lock):
        open(zvec_lock, "w").close()


def _open_cs(db_dir: str, *, auto_fix_locks: bool = True):
    """Open a CodeScope instance, auto-fixing lock issues on first failure."""
    os.environ.setdefault("HF_HUB_OFFLINE", "1")
    os.environ.setdefault("TRANSFORMERS_OFFLINE", "1")

    from codegraph.core import CodeScope

    try:
        return CodeScope(db_dir)
    except RuntimeError as e:
        err = str(e).lower()
        if auto_fix_locks and ("lock" in err or "locked" in err):
            print(f"Lock issue detected, auto-cleaning: {e}", file=sys.stderr)
            _clean_locks(db_dir)
            return CodeScope(db_dir)
        raise


def _count_stats(cs) -> dict[str, int]:
    stats = {}
    for label in ("File", "Function", "Class", "Module", "Commit"):
        rows = list(cs.conn.execute(f"MATCH (n:{label}) RETURN count(n)"))
        stats[label] = rows[0][0] if rows else 0
    for rel in ("CALLS", "TOUCHES", "MODIFIES"):
        rows = list(cs.conn.execute(f"MATCH ()-[r:{rel}]->() RETURN count(r)"))
        stats[rel] = rows[0][0] if rows else 0
    return stats


# =========================================================================
# Subcommands
# =========================================================================


def cmd_init(args: argparse.Namespace) -> None:
    """Create a new index for a repository."""
    repo = os.path.abspath(args.repo)
    db_dir = args.db

    if not os.path.isdir(repo):
        print(f"Error: {repo} is not a directory", file=sys.stderr)
        sys.exit(1)

    if args.lang == "auto":
        languages = _detect_languages(repo)
        print(f"Auto-detected languages: {languages}")
    else:
        languages = [args.lang]

    print(f"Repository:  {repo}")
    print(f"Database:    {db_dir}")
    print(f"Languages:   {languages}")
    print()

    cs = _open_cs(db_dir)
    try:
        t0 = time.time()
        cs.index(repo, languages=languages)
        elapsed = time.time() - t0
        print(f"\nIndexing complete ({elapsed:.1f}s)")

        if args.commits and args.commits > 0:
            print(f"\nIngesting {args.commits} commits...")
            t1 = time.time()
            first = min(args.commits, 500)
            cs.ingest_commits(
                repo, f"HEAD~{first}", "HEAD",
                languages=languages, skip_modifies=True, skip_merges=False,
            )
            remaining = args.commits - first
            while remaining > 0:
                chunk = min(remaining, 500)
                n = cs.ingest_more_commits(
                    repo, count=chunk,
                    languages=languages, skip_modifies=True,
                )
                remaining -= chunk
                if n == 0:
                    break
            print(f"Commit ingestion complete ({time.time() - t1:.1f}s)")

            if args.backfill_limit and args.backfill_limit > 0:
                print(f"\nBackfilling MODIFIES edges (limit={args.backfill_limit})...")
                t2 = time.time()
                cs.backfill_modifies(repo, languages=languages, limit=args.backfill_limit)
                print(f"Backfill complete ({time.time() - t2:.1f}s)")

        stats = _count_stats(cs)
        print(f"\n{'='*60}")
        print("INDEX CREATED")
        print(f"{'='*60}")
        for k, v in stats.items():
            print(f"  {k:12s}: {v:>10,}")
        print()
        print(f"Use 'codegraph status' to see detailed state.")
        print(f"Use 'codegraph query \"<question>\"' to ask questions.")
    finally:
        cs.close()


def cmd_open(args: argparse.Namespace) -> None:
    """Open an existing index and print summary."""
    db_dir = _find_db(args.db)

    if not os.path.isdir(db_dir):
        print(f"Error: database not found at {db_dir}", file=sys.stderr)
        print(f"Run 'codegraph init' first to create an index.", file=sys.stderr)
        sys.exit(1)

    cs = _open_cs(db_dir)
    try:
        print(cs.summary())
    finally:
        cs.close()


def cmd_query(args: argparse.Namespace) -> None:
    """Ask a question against the index."""
    db_dir = _find_db(args.db)

    if not os.path.isdir(db_dir):
        print(f"Error: database not found at {db_dir}", file=sys.stderr)
        sys.exit(1)

    cs = _open_cs(db_dir)
    try:
        from codegraph.qa import codegraph_query
        result = codegraph_query(cs, args.question)
        if args.json:
            output = {
                "question": result.question,
                "category": result.category.value,
                "retrieval_time_ms": result.retrieval_time_ms,
                "entities": result.entities,
                "context_items": [
                    {"type": c.type, "content": c.content,
                     "source": c.source, "score": c.score}
                    for c in result.context_items
                ],
            }
            print(json.dumps(output, indent=2, ensure_ascii=False))
        else:
            print(result.to_context_string())
    finally:
        cs.close()


def cmd_analyze(args: argparse.Namespace) -> None:
    """Generate a comprehensive architecture analysis report."""
    db_dir = _find_db(args.db)

    if not os.path.isdir(db_dir):
        print(f"Error: database not found at {db_dir}", file=sys.stderr)
        sys.exit(1)

    cs = _open_cs(db_dir)
    try:
        from codegraph.analyzer import generate_report
        output = args.output
        if not output:
            os.makedirs("reports", exist_ok=True)
            base = os.path.basename(os.path.abspath(db_dir)).lstrip(".")
            if not base or base == "codegraph":
                base = os.path.basename(os.getcwd())
            output = os.path.join("reports", f"{base}-analysis.md")

        print(f"Generating architecture analysis report...")
        print(f"Output: {output}")
        t0 = time.time()
        report = generate_report(cs)
        elapsed = time.time() - t0

        os.makedirs(os.path.dirname(output) or ".", exist_ok=True)
        with open(output, "w") as f:
            f.write(report)
        print(f"Report generated in {elapsed:.1f}s ({len(report):,} chars)")
        print(f"Saved to: {output}")
    finally:
        cs.close()


def cmd_status(args: argparse.Namespace) -> None:
    """Show index health, counts, and backfill progress."""
    db_dir = _find_db(args.db)

    if not os.path.isdir(db_dir):
        print(f"Error: database not found at {db_dir}", file=sys.stderr)
        sys.exit(1)

    cs = _open_cs(db_dir)
    try:
        stats = _count_stats(cs)

        print(f"{'='*60}")
        print(f"CodeScope Index Status: {os.path.abspath(db_dir)}")
        print(f"{'='*60}")
        print()
        print("Graph:")
        for k in ("File", "Function", "Class", "Module", "Commit"):
            print(f"  {k:12s}: {stats.get(k, 0):>10,}")
        print()
        print("Edges:")
        for k in ("CALLS", "TOUCHES", "MODIFIES"):
            print(f"  {k:12s}: {stats.get(k, 0):>10,}")

        bf_rows = list(cs.conn.execute(
            "MATCH (c:Commit) WHERE c.version_tag = 'bf' RETURN count(c)"))
        bf = bf_rows[0][0] if bf_rows else 0
        total_commits = stats.get("Commit", 0)
        not_bf = total_commits - bf

        print()
        print(f"Backfill: {bf}/{total_commits} commits have MODIFIES edges")
        if not_bf > 0:
            print(f"  {not_bf} commits still need backfill")

        vec_path = os.path.join(db_dir, "vectors")
        if os.path.isdir(vec_path):
            vec_count = stats.get("Function", 0)
            print(f"\nVectors: {vec_count:,} function embeddings")
        else:
            print(f"\nVectors: not built yet")

        print(f"\n{'='*60}")
        print("Suggested next steps:")
        print(f"{'='*60}")
        if stats.get("Function", 0) == 0:
            print("  codegraph init --repo <path>")
        elif total_commits == 0:
            print("  codegraph ingest --commits 500")
        elif not_bf > 0:
            suggest = min(not_bf, 500)
            print(f"  codegraph ingest --backfill-limit {suggest}")
        else:
            print("  codegraph analyze          # generate report")
            print("  codegraph query \"<question>\"  # ask questions")
        print()
    finally:
        cs.close()


def cmd_ingest(args: argparse.Namespace) -> None:
    """Ingest additional git history into an existing index."""
    repo = os.path.abspath(args.repo)
    db_dir = _find_db(args.db)

    if not os.path.isdir(repo):
        print(f"Error: {repo} is not a directory", file=sys.stderr)
        sys.exit(1)

    if not os.path.isdir(db_dir):
        print(f"Error: database not found at {db_dir}", file=sys.stderr)
        print(f"Run 'codegraph init' first.", file=sys.stderr)
        sys.exit(1)

    if args.lang == "auto":
        languages = _detect_languages(repo)
    else:
        languages = [args.lang]

    print(f"Repository:  {repo}")
    print(f"Database:    {db_dir}")
    print(f"Languages:   {languages}")

    cs = _open_cs(db_dir)
    try:
        if args.commits and args.commits > 0:
            print(f"\nIngesting {args.commits} commits...")
            t0 = time.time()
            first = min(args.commits, args.batch)
            cs.ingest_commits(
                repo, f"HEAD~{first}", "HEAD",
                languages=languages, skip_modifies=True, skip_merges=False,
            )
            remaining = args.commits - first
            total_ingested = first
            while remaining > 0:
                chunk = min(remaining, args.batch)
                n = cs.ingest_more_commits(
                    repo, count=chunk,
                    languages=languages, skip_modifies=True,
                )
                total_ingested += n
                remaining -= chunk
                if n == 0:
                    break
            print(f"Ingested {total_ingested} commits ({time.time() - t0:.1f}s)")

        if args.backfill_limit and args.backfill_limit > 0:
            print(f"\nBackfilling MODIFIES edges (limit={args.backfill_limit})...")
            t1 = time.time()
            n = cs.backfill_modifies(repo, languages=languages, limit=args.backfill_limit)
            print(f"Backfilled {n} commits ({time.time() - t1:.1f}s)")

        if args.vectors:
            print("\nRebuilding vectors...")
            t2 = time.time()
            cs.build_vectors()
            print(f"Vectors rebuilt ({time.time() - t2:.1f}s)")

        stats = _count_stats(cs)
        print(f"\nFinal state:")
        for k, v in stats.items():
            print(f"  {k}: {v:,}")
    finally:
        cs.close()


def cmd_fetch_issue(args: argparse.Namespace) -> None:
    """Fetch and parse a single GitHub issue."""
    from codegraph.issue_fetcher import fetch_and_parse_issue

    parsed = fetch_and_parse_issue(
        args.owner, args.repo, args.number,
        use_cache=not args.no_cache,
    )

    print(f"Issue #{parsed.number}: {parsed.title}")
    print(f"Labels: {', '.join(parsed.labels) or 'none'}")
    print()

    if parsed.extracted_paths:
        print(f"Extracted file paths ({len(parsed.extracted_paths)}):")
        for p in parsed.extracted_paths:
            print(f"  - {p}")
        print()

    if parsed.extracted_funcs:
        print(f"Extracted function names ({len(parsed.extracted_funcs)}):")
        for f in parsed.extracted_funcs:
            print(f"  - {f}")
        print()

    if parsed.extracted_locations:
        print(f"Stack trace locations ({len(parsed.extracted_locations)}):")
        for path, line in parsed.extracted_locations:
            print(f"  - {path}:{line}")
        print()

    if parsed.linked_commits:
        print(f"Linked commits ({len(parsed.linked_commits)}):")
        for c in parsed.linked_commits:
            print(f"  - {c[:12]}")
        print()

    if not any([parsed.extracted_paths, parsed.extracted_funcs,
                parsed.extracted_locations, parsed.linked_commits]):
        print("No structured data extracted from issue body.")
        print("The issue may not contain stack traces or file references.")


def cmd_fetch_bugs(args: argparse.Namespace) -> None:
    """Fetch and parse top-k bug issues."""
    from codegraph.issue_fetcher import fetch_and_parse_top_bugs

    issues = fetch_and_parse_top_bugs(
        args.owner, args.repo,
        k=args.top,
        label=args.label,
        use_cache=not args.no_cache,
    )

    print(f"Found {len(issues)} bug issues in {args.owner}/{args.repo}:")
    print()
    for issue in issues:
        paths_count = len(issue.extracted_paths)
        funcs_count = len(issue.extracted_funcs)
        print(f"  #{issue.number}: {issue.title}")
        print(f"    Labels: {', '.join(issue.labels) or 'none'}")
        print(f"    Extracted: {paths_count} paths, {funcs_count} functions")
        print()


def cmd_analyze_bug(args: argparse.Namespace) -> None:
    """Analyze a GitHub issue against the code graph."""
    db_dir = _find_db(args.db)

    if not os.path.isdir(db_dir):
        print(f"Error: database not found at {db_dir}", file=sys.stderr)
        print(f"Run 'codegraph init' first.", file=sys.stderr)
        sys.exit(1)

    cs = _open_cs(db_dir)
    try:
        result = cs.analyze_issue(
            args.owner, args.repo, args.number,
            use_cache=not args.no_cache,
            topk=args.topk,
        )
        print(result.format_report())
    finally:
        cs.close()


def cmd_analyze_bugs(args: argparse.Namespace) -> None:
    """Analyze top-k bug issues against the code graph."""
    db_dir = _find_db(args.db)

    if not os.path.isdir(db_dir):
        print(f"Error: database not found at {db_dir}", file=sys.stderr)
        sys.exit(1)

    cs = _open_cs(db_dir)
    try:
        results = cs.analyze_top_bugs(
            args.owner, args.repo,
            k=args.top,
            label=args.label,
            use_cache=not args.no_cache,
            topk_per_issue=args.topk,
        )

        for result in results:
            print(result.format_report())
            print()

        # Aggregate hotspot summary
        if len(results) > 1:
            print("=" * 70)
            print("AGGREGATE BUG HOTSPOT SUMMARY")
            print("=" * 70)
            file_counts: dict[str, int] = {}
            func_counts: dict[str, int] = {}
            for r in results:
                for c in r.candidates[:5]:
                    file_counts[c.file_path] = file_counts.get(c.file_path, 0) + 1
                    func_counts[c.function_name] = func_counts.get(c.function_name, 0) + 1

            if file_counts:
                print("\nMost frequently implicated files:")
                for fpath, count in sorted(file_counts.items(), key=lambda x: -x[1])[:10]:
                    print(f"  {fpath}: appears in {count} bug analyses")

            if func_counts:
                print("\nMost frequently implicated functions:")
                for fname, count in sorted(func_counts.items(), key=lambda x: -x[1])[:10]:
                    print(f"  {fname}: appears in {count} bug analyses")

            print("=" * 70)
    finally:
        cs.close()


def cmd_server(args: argparse.Namespace) -> None:
    """Start the MCP server."""
    db_dir = _find_db(args.db)
    os.environ["CODESCOPE_DB_DIR"] = os.path.abspath(db_dir)
    if args.repo:
        os.environ["CODESCOPE_REPO_PATH"] = os.path.abspath(args.repo)

    from codegraph.mcp_server import mcp
    mcp.run()


# =========================================================================
# Main
# =========================================================================


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="codegraph",
        description="CodeScope — graph + vector code intelligence CLI",
    )
    sub = parser.add_subparsers(dest="command", help="Available commands")

    # -- init --
    p_init = sub.add_parser("init", help="Create a new index for a repository")
    p_init.add_argument("--repo", default=".", help="Path to repository (default: .)")
    p_init.add_argument("--db", default=DB_DEFAULT, help=f"Database directory (default: {DB_DEFAULT})")
    p_init.add_argument("--lang", default="auto", help="Language: auto, python, c, javascript, typescript, java (default: auto)")
    p_init.add_argument("--commits", type=int, default=0, help="Number of git commits to ingest (default: 0)")
    p_init.add_argument("--backfill-limit", type=int, default=0, help="Max commits to backfill MODIFIES edges (default: 0)")

    # -- open --
    p_open = sub.add_parser("open", help="Open an existing index and print summary")
    p_open.add_argument("--db", default=None, help=f"Database directory (default: {DB_DEFAULT})")

    # -- query --
    p_query = sub.add_parser("query", help="Ask a question against the index")
    p_query.add_argument("question", help="The question to ask")
    p_query.add_argument("--db", default=None, help=f"Database directory (default: {DB_DEFAULT})")
    p_query.add_argument("--topk", type=int, default=10, help="Max results (default: 10)")
    p_query.add_argument("--json", action="store_true", help="Output as JSON")

    # -- analyze --
    p_analyze = sub.add_parser("analyze", help="Generate architecture analysis report")
    p_analyze.add_argument("--db", default=None, help=f"Database directory (default: {DB_DEFAULT})")
    p_analyze.add_argument("--output", "-o", default=None, help="Output file path (default: reports/<name>-analysis.md)")

    # -- status --
    p_status = sub.add_parser("status", help="Show index health and statistics")
    p_status.add_argument("--db", default=None, help=f"Database directory (default: {DB_DEFAULT})")

    # -- ingest --
    p_ingest = sub.add_parser("ingest", help="Ingest git history into an existing index")
    p_ingest.add_argument("--repo", default=".", help="Path to repository (default: .)")
    p_ingest.add_argument("--db", default=None, help=f"Database directory (default: {DB_DEFAULT})")
    p_ingest.add_argument("--lang", default="auto", help="Language (default: auto)")
    p_ingest.add_argument("--commits", type=int, default=500, help="Commits to ingest (default: 500)")
    p_ingest.add_argument("--batch", type=int, default=500, help="Batch size (default: 500)")
    p_ingest.add_argument("--backfill-limit", type=int, default=0, help="Max commits to backfill (default: 0)")
    p_ingest.add_argument("--vectors", action="store_true", help="Rebuild vectors after ingestion")

    # -- fetch-issue --
    p_fi = sub.add_parser("fetch-issue", help="Fetch and parse a single GitHub issue")
    p_fi.add_argument("owner", help="GitHub repo owner")
    p_fi.add_argument("repo", help="GitHub repo name")
    p_fi.add_argument("number", type=int, help="Issue number")
    p_fi.add_argument("--no-cache", action="store_true", help="Skip cache")

    # -- fetch-bugs --
    p_fb = sub.add_parser("fetch-bugs", help="Fetch top-k bug issues from a repo")
    p_fb.add_argument("owner", help="GitHub repo owner")
    p_fb.add_argument("repo", help="GitHub repo name")
    p_fb.add_argument("--top", type=int, default=10, help="Number of issues (default: 10)")
    p_fb.add_argument("--label", default="bug", help="Issue label to filter (default: bug)")
    p_fb.add_argument("--no-cache", action="store_true", help="Skip cache")

    # -- analyze-bug --
    p_ab = sub.add_parser("analyze-bug", help="Analyze a GitHub issue against code graph")
    p_ab.add_argument("owner", help="GitHub repo owner")
    p_ab.add_argument("repo", help="GitHub repo name")
    p_ab.add_argument("number", type=int, help="Issue number")
    p_ab.add_argument("--db", default=None, help=f"Database directory (default: {DB_DEFAULT})")
    p_ab.add_argument("--topk", type=int, default=10, help="Top candidates (default: 10)")
    p_ab.add_argument("--no-cache", action="store_true", help="Skip issue cache")

    # -- analyze-bugs --
    p_abs = sub.add_parser("analyze-bugs", help="Analyze top-k bugs against code graph")
    p_abs.add_argument("owner", help="GitHub repo owner")
    p_abs.add_argument("repo", help="GitHub repo name")
    p_abs.add_argument("--db", default=None, help=f"Database directory (default: {DB_DEFAULT})")
    p_abs.add_argument("--top", type=int, default=10, help="Number of issues (default: 10)")
    p_abs.add_argument("--label", default="bug", help="Issue label (default: bug)")
    p_abs.add_argument("--topk", type=int, default=5, help="Candidates per issue (default: 5)")
    p_abs.add_argument("--no-cache", action="store_true", help="Skip issue cache")

    # -- server --
    p_server = sub.add_parser("server", help="Start the MCP server")
    p_server.add_argument("--db", default=None, help=f"Database directory (default: {DB_DEFAULT})")
    p_server.add_argument("--repo", default=None, help="Path to repository")

    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    dispatch = {
        "init": cmd_init,
        "open": cmd_open,
        "query": cmd_query,
        "analyze": cmd_analyze,
        "status": cmd_status,
        "ingest": cmd_ingest,
        "fetch-issue": cmd_fetch_issue,
        "fetch-bugs": cmd_fetch_bugs,
        "analyze-bug": cmd_analyze_bug,
        "analyze-bugs": cmd_analyze_bugs,
        "server": cmd_server,
    }
    dispatch[args.command](args)


if __name__ == "__main__":
    main()
