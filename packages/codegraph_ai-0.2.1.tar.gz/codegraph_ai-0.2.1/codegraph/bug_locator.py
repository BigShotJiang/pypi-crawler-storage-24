"""Bug-to-Code Locator — maps parsed bug content to relevant code locations
using existing CodeScope capabilities.
"""

from __future__ import annotations

import logging
import re
import time
from dataclasses import dataclass, field

from codegraph.bug_parser import ParsedIssue

_log = logging.getLogger(__name__)


@dataclass
class RootCauseCandidate:
    """A potential root cause code location for a bug."""

    function_name: str
    file_path: str
    score: float
    reasons: list[str] = field(default_factory=list)

    def __repr__(self) -> str:
        return (
            f"RootCauseCandidate({self.function_name}, {self.file_path}, "
            f"score={self.score:.3f}, reasons={self.reasons})"
        )


@dataclass
class BugAnalysisResult:
    """Complete result of a bug root-cause analysis."""

    issue: ParsedIssue
    candidates: list[RootCauseCandidate] = field(default_factory=list)
    path_matches: int = 0
    semantic_matches: int = 0
    caller_traces: int = 0
    analysis_time_ms: float = 0.0

    def format_report(self) -> str:
        """Format the analysis result as a human-readable report."""
        lines = [
            "=" * 70,
            f"Bug Analysis: {self.issue.owner}/{self.issue.repo}#{self.issue.number}",
            "=" * 70,
            f"Title: {self.issue.title}",
            f"Labels: {', '.join(self.issue.labels) or 'none'}",
            "",
        ]

        if self.issue.extracted_paths:
            lines.append(f"Extracted file paths ({len(self.issue.extracted_paths)}):")
            for p in self.issue.extracted_paths:
                lines.append(f"  - {p}")
            lines.append("")

        if self.issue.extracted_funcs:
            lines.append(f"Extracted function names ({len(self.issue.extracted_funcs)}):")
            for f in self.issue.extracted_funcs:
                lines.append(f"  - {f}")
            lines.append("")

        if self.issue.linked_commits:
            lines.append(f"Linked commits ({len(self.issue.linked_commits)}):")
            for c in self.issue.linked_commits:
                lines.append(f"  - {c[:12]}")
            lines.append("")

        lines.append(f"Analysis: {self.path_matches} path matches, "
                      f"{self.semantic_matches} semantic matches, "
                      f"{self.caller_traces} caller traces")
        lines.append(f"Time: {self.analysis_time_ms:.0f}ms")
        lines.append("")

        if self.candidates:
            lines.append(f"Root Cause Candidates (top {len(self.candidates)}):")
            lines.append("-" * 70)
            for i, c in enumerate(self.candidates, 1):
                lines.append(f"  {i}. {c.function_name}")
                lines.append(f"     File:  {c.file_path}")
                lines.append(f"     Score: {c.score:.3f}")
                lines.append(f"     Why:   {'; '.join(c.reasons)}")
                lines.append("")
        else:
            lines.append("No root cause candidates found.")
            lines.append("Tip: ensure the code graph is indexed for this repository.")

        lines.append("=" * 70)
        return "\n".join(lines)


def _cesc(value: str) -> str:
    """Escape value for Cypher string literal."""
    return (
        value
        .replace("\\", "\\\\")
        .replace("'", "\\'")
        .replace("\n", "\\n")
        .replace("\r", "\\r")
        .replace("\t", "\\t")
    )


def resolve_paths_to_files(cs, extracted_paths: list[str]) -> list[dict]:
    """Match extracted file paths to File nodes in the code graph.

    Returns list of dicts with keys: extracted_path, matched_file, functions.
    """
    if not extracted_paths:
        return []

    # NeuG's ENDS WITH / CONTAINS have limitations with path strings,
    # so we fetch all file paths once and do matching in Python.
    all_files_rows = list(cs.conn.execute(
        "MATCH (f:File) RETURN f.path"
    ))
    all_file_paths = [row[0] for row in all_files_rows if row[0]]

    results = []
    for path in extracted_paths:
        matched_file = None

        # Strategy 1: exact match
        if path in all_file_paths:
            matched_file = path
        else:
            # Strategy 2: suffix match (e.g., "core.c" matches "kernel/sched/core.c")
            suffix = "/" + path if "/" in path else path
            for fp in all_file_paths:
                if fp == path or fp.endswith(suffix):
                    matched_file = fp
                    break

            # Strategy 3: filename-only match
            if matched_file is None:
                filename = path.split("/")[-1]
                for fp in all_file_paths:
                    if fp.endswith("/" + filename) or fp == filename:
                        matched_file = fp
                        break

        # Get functions defined in the matched file
        funcs = []
        if matched_file:
            func_rows = list(cs.conn.execute(
                f"MATCH (f:File {{path: '{_cesc(matched_file)}'}})"
                f"-[:DEFINES_FUNC]->(fn:Function) "
                f"RETURN fn.name, fn.qualified_name"
            ))
            funcs = [{"name": r[0], "qualified_name": r[1] or r[0]} for r in func_rows]

        results.append({
            "extracted_path": path,
            "matched_file": matched_file,
            "functions": funcs,
        })

    return results


def _strip_markdown(text: str) -> str:
    """Remove markdown formatting for cleaner embedding input."""
    text = re.sub(r"```[\s\S]*?```", "", text)
    text = re.sub(r"`[^`]+`", "", text)
    text = re.sub(r"!\[.*?\]\(.*?\)", "", text)
    text = re.sub(r"\[([^\]]+)\]\(.*?\)", r"\1", text)
    text = re.sub(r"#{1,6}\s+", "", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def find_semantic_matches(cs, issue_text: str, topk: int = 10) -> list[dict]:
    """Use cross_locate() to find functions semantically related to the bug.

    Returns a list of seed dicts from CrossLocateResult.
    """
    processed = _strip_markdown(issue_text)
    if len(processed) > 1000:
        processed = processed[:1000]

    if not processed.strip():
        return []

    try:
        result = cs.cross_locate(processed, topk=topk)
        return result.seeds
    except Exception as e:
        _log.warning("Semantic search failed: %s", e)
        return []


def trace_callers(cs, function_names: list[str], max_hops: int = 2) -> list[dict]:
    """For each mentioned function, find its callers using impact().

    Returns list of dicts with keys: function, callers.
    """
    results = []

    for func_name in function_names:
        # Check if function exists in graph
        check = list(cs.conn.execute(
            f"MATCH (f:Function {{name: '{_cesc(func_name)}'}}) "
            f"WHERE f.is_historical = 0 "
            f"RETURN f.name, f.file_path LIMIT 5"
        ))

        if not check:
            continue

        try:
            impacts = cs.impact(func_name, "bug analysis", max_hops=max_hops)
            callers = []
            for imp in impacts:
                callers.append({
                    "name": imp.name,
                    "file": imp.file_path,
                    "hops": imp.hop_distance,
                    "relevance": imp.relevance,
                })
            if callers:
                results.append({
                    "function": func_name,
                    "file": check[0][1] or "",
                    "callers": callers,
                })
        except Exception as e:
            _log.warning("Impact analysis failed for %s: %s", func_name, e)

    return results


def rank_root_causes(
    path_matches: list[dict],
    semantic_matches: list[dict],
    caller_traces: list[dict],
    extracted_funcs: list[str],
    topk: int = 10,
) -> list[RootCauseCandidate]:
    """Combine all signals into a ranked list of root cause candidates.

    Scoring:
      - Direct mention in issue (extracted func): +1.0
      - In file mentioned in issue: +0.8
      - Semantic match: +score (0.0-1.0)
      - Caller of mentioned function: +0.5 / hop_distance
    """
    scores: dict[str, float] = {}
    reasons: dict[str, list[str]] = {}
    file_paths: dict[str, str] = {}

    def _add(func_name: str, file_path: str, score: float, reason: str) -> None:
        key = f"{func_name}@{file_path}"
        scores[key] = scores.get(key, 0.0) + score
        reasons.setdefault(key, []).append(reason)
        file_paths[key] = file_path

    extracted_set = set(extracted_funcs)

    # Score functions from path matches (deduplicate by name within each file)
    for pm in path_matches:
        if pm["matched_file"]:
            seen_in_file: set[str] = set()
            for func in pm["functions"]:
                name = func["name"]
                if name in seen_in_file:
                    continue
                seen_in_file.add(name)
                fpath = pm["matched_file"]
                if name in extracted_set:
                    _add(name, fpath, 1.0, "mentioned in issue")
                else:
                    _add(name, fpath, 0.8, f"in mentioned file {pm['extracted_path']}")

    # Score semantic matches
    for seed in semantic_matches:
        name = seed.get("name", "")
        fpath = seed.get("file_path", "")
        sim_score = seed.get("score", 0.0)
        if name:
            _add(name, fpath, sim_score, f"semantic match ({sim_score:.2f})")

    # Score callers
    for trace in caller_traces:
        for caller in trace["callers"]:
            hops = max(caller.get("hops", 1), 1)
            caller_score = 0.5 / hops
            _add(
                caller["name"], caller["file"],
                caller_score,
                f"caller of {trace['function']} ({hops} hop{'s' if hops > 1 else ''})"
            )

    # Also add directly mentioned functions (even if not in path matches)
    for func_name in extracted_funcs:
        check = []
        try:
            # We import _cesc locally to avoid circular imports
            check = list()
        except Exception:
            pass
        for key in list(scores.keys()):
            if key.startswith(f"{func_name}@"):
                break
        else:
            # Not yet scored — try to find in the combined data
            pass

    # Build candidates
    candidates = []
    for key, score in scores.items():
        parts = key.split("@", 1)
        func_name = parts[0]
        fpath = parts[1] if len(parts) > 1 else ""
        candidates.append(RootCauseCandidate(
            function_name=func_name,
            file_path=fpath,
            score=score,
            reasons=reasons.get(key, []),
        ))

    candidates.sort(key=lambda c: -c.score)
    return candidates[:topk]


def analyze_bug(
    cs,
    issue: ParsedIssue,
    topk: int = 10,
) -> BugAnalysisResult:
    """Full bug-to-code analysis pipeline.

    Args:
        cs: CodeScope instance (must be open with indexed data)
        issue: Parsed issue data
        topk: Number of top candidates to return

    Returns:
        BugAnalysisResult with ranked root cause candidates.
    """
    t0 = time.time()

    # Step 1: resolve extracted file paths to graph nodes
    path_results = resolve_paths_to_files(cs, issue.extracted_paths)
    n_path_matches = sum(1 for p in path_results if p["matched_file"])

    # Step 2: semantic search using issue text
    issue_text = f"{issue.title}\n\n{issue.body}"
    semantic_results = find_semantic_matches(cs, issue_text, topk=topk)

    # Step 3: trace callers of mentioned functions
    caller_results = trace_callers(cs, issue.extracted_funcs, max_hops=2)

    # Step 4: rank and combine
    candidates = rank_root_causes(
        path_matches=path_results,
        semantic_matches=semantic_results,
        caller_traces=caller_results,
        extracted_funcs=issue.extracted_funcs,
        topk=topk,
    )

    elapsed_ms = (time.time() - t0) * 1000

    return BugAnalysisResult(
        issue=issue,
        candidates=candidates,
        path_matches=n_path_matches,
        semantic_matches=len(semantic_results),
        caller_traces=len(caller_results),
        analysis_time_ms=elapsed_ms,
    )
