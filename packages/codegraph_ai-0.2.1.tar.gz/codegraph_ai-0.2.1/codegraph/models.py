"""Data models for CodeScope.

Public result types returned by the three core use cases, plus internal
models used during the indexing pipeline.
"""

from __future__ import annotations

from dataclasses import dataclass, field


# ---------------------------------------------------------------------------
# Public result types (returned by CodeScope use-case methods)
# ---------------------------------------------------------------------------


@dataclass
class ImpactResult:
    """One caller affected by a change, with graph + vector metadata."""

    name: str
    qualified_name: str
    file_path: str
    hop_distance: int
    relevance: float


@dataclass
class SimilarResult:
    """A function similar to a target, found within a module scope."""

    name: str
    signature: str
    file_path: str
    score: float


@dataclass
class CrossLocateResult:
    """Result of a cross-locate query: seeds, connections, clusters."""

    seeds: list[dict] = field(default_factory=list)
    connections: list[dict] = field(default_factory=list)
    clusters: list[list[str]] = field(default_factory=list)


@dataclass
class DeadCodeResult:
    """A function with no callers that is not an entry point."""

    name: str
    qualified_name: str
    file_path: str
    reason: str


@dataclass
class HotspotResult:
    """A function ranked by structural risk (fan-in x fan-out)."""

    name: str
    file_path: str
    fan_in: int
    fan_out: int
    risk_score: float


@dataclass
class CouplingResult:
    """Cross-module coupling between two modules."""

    module_a: str
    module_b: str
    calls_a_to_b: int
    calls_b_to_a: int
    functions_involved: list[str] = field(default_factory=list)


@dataclass
class ChangeAttributionResult:
    """A commit that modified a specific function."""

    commit_hash: str
    message: str
    author: str
    timestamp: int
    change_type: str


@dataclass
class CoChangeResult:
    """A function frequently co-modified with a target function."""

    function_name: str
    file_path: str
    co_change_count: int
    shared_commits: list[str] = field(default_factory=list)


@dataclass
class IntentSearchResult:
    """A commit found by semantic search on its message."""

    commit_hash: str
    message: str
    similarity_score: float
    functions_modified: list[str] = field(default_factory=list)


@dataclass
class StabilityEntry:
    """One function's stability profile: connectivity vs modification."""

    name: str
    file_path: str
    fan_in: int
    modify_count: int


@dataclass
class StabilityAnalysis:
    """Result of the Stability Principle analysis."""

    top_functions: list[StabilityEntry]
    total_checked: int
    modified_count: int
    unmodified_count: int


@dataclass
class LayerEntry:
    """One module with its layer score and metrics."""

    module: str
    incoming: int
    outgoing: int
    layer_score: float


@dataclass
class BridgeFunction:
    """A function called from many distinct modules."""

    name: str
    file_path: str
    module_count: int
    total_callers: int


@dataclass
class CommitModularity:
    """One commit's modularity profile."""

    commit_hash: str
    message: str
    funcs_modified: int
    modules_touched: int


@dataclass
class HotColdEntry:
    """One module's modification density."""

    module: str
    total_functions: int
    modified_functions: int
    density: float


@dataclass
class SemanticCrossPollinationHit:
    """A semantically similar function found in a distant subsystem."""

    name: str
    file_path: str
    module: str
    score: float
    connected: bool
    connection_distance: int


@dataclass
class UpdateReport:
    """Summary of an incremental index update."""

    commit_before: str
    commit_after: str
    files_added: list[str] = field(default_factory=list)
    files_modified: list[str] = field(default_factory=list)
    files_deleted: list[str] = field(default_factory=list)
    functions_added: int = 0
    functions_removed: int = 0
    edges_recomputed: int = 0
    embeddings_computed: int = 0
    embeddings_reused: int = 0
    duration_ms: float = 0.0

    def summary(self) -> str:
        lines = [
            f"Incremental update: {self.commit_before[:8]}..{self.commit_after[:8]}",
            f"  Files: +{len(self.files_added)} modified={len(self.files_modified)} "
            f"-{len(self.files_deleted)}",
            f"  Functions: +{self.functions_added} -{self.functions_removed}",
            f"  Embeddings: {self.embeddings_computed} computed, "
            f"{self.embeddings_reused} reused",
            f"  Call edges recomputed: {self.edges_recomputed}",
            f"  Duration: {self.duration_ms:.0f}ms",
        ]
        if self.files_added:
            lines.append("  Added:")
            for f in self.files_added:
                lines.append(f"    + {f}")
        if self.files_modified:
            lines.append("  Modified:")
            for f in self.files_modified:
                lines.append(f"    ~ {f}")
        if self.files_deleted:
            lines.append("  Deleted:")
            for f in self.files_deleted:
                lines.append(f"    - {f}")
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Internal models used during parsing / indexing
# ---------------------------------------------------------------------------


@dataclass
class CallInfo:
    """A function/method call with receiver context for scope-aware resolution."""

    callee_name: str
    receiver: str | None = None
    raw_expression: str = ""


@dataclass
class ParsedFunction:
    """A function (or method) extracted from source code."""

    name: str
    qualified_name: str
    signature: str
    file_path: str
    start_line: int
    end_line: int
    doc_comment: str = ""
    call_names: list[str] = field(default_factory=list)
    calls: list[CallInfo] = field(default_factory=list)
    class_name: str | None = None


@dataclass
class ParsedClass:
    """A class extracted from source code."""

    name: str
    qualified_name: str
    file_path: str
    start_line: int
    end_line: int
    method_names: list[str] = field(default_factory=list)
    base_classes: list[str] = field(default_factory=list)


@dataclass
class ParsedImport:
    """A file-level import relationship."""

    source_path: str
    target_module: str
    imported_names: list[str] = field(default_factory=list)
    is_relative: bool = False
    relative_level: int = 0


@dataclass
class ParseResult:
    """Aggregated parse output for a single source file."""

    functions: list[ParsedFunction] = field(default_factory=list)
    classes: list[ParsedClass] = field(default_factory=list)
    imports: list[ParsedImport] = field(default_factory=list)
