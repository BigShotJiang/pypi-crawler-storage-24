"""CodeScope: Graph + Vector Code Intelligence powered by neug and zvec."""
