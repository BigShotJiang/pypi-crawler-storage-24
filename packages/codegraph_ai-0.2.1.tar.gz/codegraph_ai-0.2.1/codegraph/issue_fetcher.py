"""Unified Issue Fetcher API — combines GitHub client, parser, and cache."""

from __future__ import annotations

import logging

from codegraph.bug_parser import ParsedIssue, parse_issue
from codegraph.github_client import fetch_issue, fetch_top_bugs
from codegraph.issue_cache import load_cached_issue, save_to_cache

_log = logging.getLogger(__name__)


def fetch_and_parse_issue(
    owner: str,
    repo: str,
    number: int,
    use_cache: bool = True,
) -> ParsedIssue:
    """Fetch an issue from GitHub (or cache), parse content, return structured data.

    Flow:
      1. Check cache if use_cache=True
      2. If cache miss, fetch via GraphQL
      3. Parse body for paths, funcs, stack traces
      4. Save to cache
      5. Return ParsedIssue
    """
    if use_cache:
        cached = load_cached_issue(owner, repo, number)
        if cached is not None:
            _log.info("Cache hit for %s/%s#%d", owner, repo, number)
            return cached

    _log.info("Fetching %s/%s#%d from GitHub...", owner, repo, number)
    raw = fetch_issue(owner, repo, number)
    parsed = parse_issue(raw, owner, repo)

    if use_cache:
        save_to_cache(parsed)

    return parsed


def fetch_and_parse_top_bugs(
    owner: str,
    repo: str,
    k: int = 10,
    label: str = "bug",
    use_cache: bool = True,
) -> list[ParsedIssue]:
    """Fetch and parse top-k bug issues.

    Checks cache per-issue; only fetches uncached ones from the API.
    """
    raw_issues = fetch_top_bugs(owner, repo, k=k, label=label)

    results: list[ParsedIssue] = []
    for raw in raw_issues:
        number = raw["number"]
        if use_cache:
            cached = load_cached_issue(owner, repo, number)
            if cached is not None:
                results.append(cached)
                continue

        parsed = parse_issue(raw, owner, repo)
        if use_cache:
            save_to_cache(parsed)
        results.append(parsed)

    return results
