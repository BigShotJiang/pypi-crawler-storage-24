"""CodeScope MCP Server — expose code intelligence as MCP tools.

Start with::

    fastmcp run codegraph/mcp_server.py

Or programmatically::

    python -m codegraph.mcp_server --db-dir ./my_db --repo ./my_repo

Environment variables (override CLI args):
    CODESCOPE_DB_DIR   — path to the neug/zvec database directory
    CODESCOPE_REPO_PATH — path to the git repository
    CODESCOPE_LANGUAGES — comma-separated languages (default: "c")
"""

from __future__ import annotations

import json
import os

from fastmcp import FastMCP

mcp = FastMCP(
    "CodeScope",
    instructions=(
        "CodeScope is a code intelligence engine backed by a graph database "
        "(neug) and vector index (zvec).  It indexes source code into a "
        "two-layer knowledge graph: Structure (functions, calls, imports) "
        "and Evolution (commits, change attribution, co-change patterns).  "
        "Intent queries are answered by combining function vector search "
        "with commit graph traversal.  Use the tools below to answer "
        "questions about the indexed codebase."
    ),
)

_cs = None


def _get_cs():
    global _cs
    if _cs is not None:
        return _cs
    db_dir = os.environ.get("CODESCOPE_DB_DIR", ".codegraph_db")
    if not os.path.isdir(db_dir):
        raise RuntimeError(
            f"Database directory not found: {db_dir}. "
            f"Set CODESCOPE_DB_DIR or run indexing first."
        )
    os.environ.setdefault("HF_HUB_OFFLINE", "1")
    from codegraph.core import CodeScope
    _cs = CodeScope(db_dir)
    return _cs


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------


@mcp.tool
def codegraph_query(question: str) -> str:
    """Ask a natural-language question about the indexed codebase.

    Automatically classifies the question (structural / historical /
    intentional / semantic) and retrieves relevant evidence from the
    knowledge graph.  Returns structured context with citations.

    Examples:
      - "Who calls jv_free?"
      - "What are the hotspots in src/?"
      - "Why were memory leaks fixed?"
      - "How has f_nan changed over time?"
      - "Find functions related to memory management"
    """
    from codegraph.qa import codegraph_query as _query
    cs = _get_cs()
    result = _query(cs, question)
    return result.to_context_string()


@mcp.tool
def codegraph_impact(function_name: str, change_description: str = "refactor") -> str:
    """Find all callers of a function, ranked by semantic relevance to a
    change description.  Uses graph traversal (zero false positives) +
    vector ranking.

    Args:
        function_name: Name of the function to analyze.
        change_description: Description of the planned change.
    """
    cs = _get_cs()
    results = cs.impact(function_name, change_description, max_hops=3)
    if not results:
        return f"No callers found for '{function_name}'."
    lines = [f"Impact analysis for '{function_name}' ({len(results)} callers):"]
    for r in results[:20]:
        lines.append(
            f"  {r.name} ({r.file_path}) — "
            f"hop={r.hop_distance}, relevance={r.relevance:.3f}"
        )
    return "\n".join(lines)


@mcp.tool
def codegraph_hotspots(topk: int = 10) -> str:
    """Return the top functions ranked by structural risk (fan_in x fan_out).

    High risk = many callers AND many callees — changes here are dangerous.
    """
    cs = _get_cs()
    results = cs.hotspots(topk=topk)
    lines = [f"Top {len(results)} hotspots:"]
    for r in results:
        lines.append(
            f"  {r.name} ({r.file_path}) — "
            f"fan_in={r.fan_in}, fan_out={r.fan_out}, risk={r.risk_score:.0f}"
        )
    return "\n".join(lines)


@mcp.tool
def codegraph_dead_code() -> str:
    """Find functions with no callers that are not entry points.

    Returns dead code candidates that may be safe to remove.
    """
    cs = _get_cs()
    results = cs.dead_code()
    lines = [f"Found {len(results)} dead code candidates:"]
    for r in results[:30]:
        lines.append(f"  {r.name} ({r.file_path}) — {r.reason}")
    if len(results) > 30:
        lines.append(f"  ... and {len(results) - 30} more")
    return "\n".join(lines)


@mcp.tool
def codegraph_history(function_name: str, file_path: str | None = None) -> str:
    """Show the change history of a function — which commits modified it,
    who authored them, and why (commit messages).

    Args:
        function_name: Name of the function.
        file_path: Optional file path to disambiguate same-name functions.
    """
    cs = _get_cs()
    results = cs.change_attribution(function_name, file_path, limit=20)
    if not results:
        return f"No change history found for '{function_name}'."
    lines = [f"Change history for '{function_name}' ({len(results)} commits):"]
    for a in results:
        lines.append(
            f"  {a.commit_hash[:8]} [{a.change_type}] "
            f"{a.author}: {a.message[:100]}"
        )
    return "\n".join(lines)


@mcp.tool
def codegraph_intent(query: str, topk: int = 10) -> str:
    """Find commits relevant to a natural-language intent query.

    Uses function vector search to find semantically related code, then
    reverse-traverses MODIFIES edges to discover commits.  Commit messages
    are ranked by relevance to the query.

    Use this to answer "why" questions — e.g., "fix memory leak",
    "race condition in scheduler", "performance optimization".

    Args:
        query: Natural-language description of the intent to search for.
        topk: Number of results to return.
    """
    cs = _get_cs()
    results = cs.intent_search(query, topk=topk)
    if not results:
        return f"No commits found matching '{query}'."
    lines = [f"Intent search for '{query}' ({len(results)} results):"]
    for r in results:
        funcs = ", ".join(r.functions_modified[:5]) if r.functions_modified else "none"
        lines.append(
            f"  [{r.similarity_score:.3f}] {r.commit_hash[:8]}: "
            f"{r.message[:80]}"
        )
        lines.append(f"    Modified: {funcs}")
    return "\n".join(lines)


@mcp.tool
def codegraph_cochange(function_name: str, file_path: str | None = None) -> str:
    """Find functions frequently co-modified with the target function but
    NOT connected by direct CALLS edges.  These reveal hidden/implicit
    coupling invisible to structural analysis.

    Args:
        function_name: Name of the function.
        file_path: Optional file path to disambiguate.
    """
    cs = _get_cs()
    results = cs.co_change(function_name, file_path, min_commits=1, topk=10)
    if not results:
        return f"No co-change partners found for '{function_name}'."
    lines = [
        f"Co-change analysis for '{function_name}' "
        f"({len(results)} implicitly coupled functions):"
    ]
    for c in results:
        commits = ", ".join(h[:8] for h in c.shared_commits[:3])
        lines.append(
            f"  {c.function_name} ({c.file_path}) — "
            f"co-changed {c.co_change_count}x in [{commits}]"
        )
    return "\n".join(lines)


@mcp.tool
def codegraph_coupling(topk: int = 10) -> str:
    """Discover cross-module coupling via CALLS edges.

    Returns module pairs ranked by total cross-boundary function calls.
    """
    cs = _get_cs()
    results = cs.module_coupling(topk=topk)
    if not results:
        return "No cross-module coupling detected."
    lines = [f"Module coupling ({len(results)} pairs):"]
    for r in results:
        lines.append(
            f"  {r.module_a} <-> {r.module_b}: "
            f"{r.calls_a_to_b}+{r.calls_b_to_a} cross-calls"
        )
    return "\n".join(lines)


@mcp.tool
def codegraph_stability(topk: int = 50) -> str:
    """Prove the Stable Dependencies Principle: the most-called functions
    should be the least frequently modified.

    Returns the top-K most-called functions with their modification counts,
    plus an overall stability ratio.

    Args:
        topk: Number of top functions to analyze.
    """
    cs = _get_cs()
    result = cs.stability_analysis(topk=topk)
    ratio = (
        result.unmodified_count / result.total_checked * 100
        if result.total_checked else 0
    )
    lines = [
        f"Stability Principle ({result.total_checked} top functions checked):",
        f"  Modified: {result.modified_count}",
        f"  Unmodified: {result.unmodified_count} ({ratio:.0f}%)",
        "",
        f"  {'Function':<40} {'Fan-in':>8} {'Mods':>6}",
    ]
    for e in result.top_functions[:20]:
        lines.append(f"  {e.name:<40} {e.fan_in:>8} {e.modify_count:>6}")
    return "\n".join(lines)


@mcp.tool
def codegraph_layers(topk: int = 30) -> str:
    """Automatically discover the architectural layering of the codebase.

    Computes infrastructure score (incoming - outgoing cross-module calls)
    for each module. High scores = foundation; low scores = leaf consumers.

    Args:
        topk: Number of modules to return.
    """
    cs = _get_cs()
    layers = cs.layer_discovery(topk=topk)
    lines = [
        f"Automatic Layer Discovery ({len(layers)} modules):",
        f"  {'Module':<35} {'Score':>8} {'In':>7} {'Out':>7}",
    ]
    for e in layers:
        lines.append(
            f"  {e.module:<35} {e.layer_score:>+8.0f} "
            f"{e.incoming:>7} {e.outgoing:>7}"
        )
    return "\n".join(lines)


@mcp.tool
def codegraph_bridges(topk: int = 30) -> str:
    """Find bridge functions — called from the most distinct modules.

    These are the true cross-subsystem API: the load-bearing walls of
    the architecture.

    Args:
        topk: Number of top functions to return.
    """
    cs = _get_cs()
    bridges = cs.bridge_functions(topk=topk)
    lines = [
        f"Bridge Functions ({len(bridges)} cross-subsystem APIs):",
        f"  {'Function':<35} {'Modules':>8} {'Callers':>8}",
    ]
    for b in bridges:
        lines.append(f"  {b.name:<35} {b.module_count:>8} {b.total_callers:>8}")
    return "\n".join(lines)


@mcp.tool
def codegraph_commit_modularity(topk: int = 20) -> str:
    """Score each commit by how many modules it affects.

    Focused commits (1 module) indicate good encapsulation.
    Scattered commits (many modules) reveal cross-cutting changes.

    Args:
        topk: Number of commits to return (most scattered first).
    """
    cs = _get_cs()
    results = cs.commit_modularity(topk=topk)
    if not results:
        return "No MODIFIES data available — ingest commits first."
    lines = [
        f"Commit Modularity ({len(results)} commits):",
        f"  {'Commit':<12} {'Modules':>8} {'Funcs':>6}  Message",
    ]
    for c in results:
        msg = (c.message or "")[:50].replace("\n", " ")
        lines.append(
            f"  {c.commit_hash[:10]:<12} "
            f"{c.modules_touched:>8} {c.funcs_modified:>6}  {msg}"
        )
    return "\n".join(lines)


@mcp.tool
def codegraph_hot_cold(topk: int = 30) -> str:
    """Map modification density per module: frozen core vs hot periphery.

    Low density = stable infrastructure. High density = active development.

    Args:
        topk: Number of modules to return (hottest first).
    """
    cs = _get_cs()
    entries = cs.hot_cold_map(topk=topk)
    if not entries:
        return "No MODIFIES data — ingest commits first."
    lines = [
        f"Hot/Cold Map ({len(entries)} modules):",
        f"  {'Module':<35} {'Total':>7} {'Modified':>9} {'Density':>8}",
    ]
    for e in entries:
        lines.append(
            f"  {e.module:<35} {e.total_functions:>7} "
            f"{e.modified_functions:>9} {e.density:>8.1%}"
        )
    return "\n".join(lines)


@mcp.tool
def codegraph_cross_pollination(query: str, topk: int = 10) -> str:
    """Find semantically similar functions across structurally distant
    subsystems using vector search + graph distance analysis.

    Reveals shared design patterns — the conceptual vocabulary encoded
    in code structure but never formally documented.

    Args:
        query: Semantic query (e.g. "memory allocation failure handling").
        topk: Number of results per module to return.
    """
    cs = _get_cs()
    hits = cs.semantic_cross_pollination(query, topk=topk)
    if not hits:
        return f"No results for '{query}'."
    lines = [f"Cross-Pollination for '{query}' ({len(hits)} modules):"]
    for h in hits:
        conn = (
            f"connected (dist={h.connection_distance})"
            if h.connected else "isolated"
        )
        lines.append(
            f"  [{h.score:.3f}] {h.name:<30} ({h.module:<25}) {conn}"
        )
    return "\n".join(lines)


@mcp.tool
def codegraph_stats() -> str:
    """Return a summary of the indexed codebase: file/function/edge counts,
    largest subsystems, most-called functions, etc.
    """
    cs = _get_cs()
    return cs.summary()


@mcp.tool
def codegraph_cypher(query: str, limit: int = 50) -> str:
    """Execute a raw Cypher query against the code knowledge graph.

    This is the most powerful tool — use it to compose arbitrary analyses
    that the pre-built tools cannot cover.  Returns up to `limit` rows
    as JSON.

    ## Graph Schema

    Node tables:
      - File(id, fqn, path, language, loc, is_external)
      - Function(id, fqn, name, qualified_name, signature, file_path,
                 start_line, end_line, doc_comment, class_name, language,
                 is_historical)
      - Class(id, fqn, name, qualified_name, file_path, start_line, end_line)
      - Module(id, fqn, name, path_prefix)
      - Commit(id, fqn, hash, message, author, timestamp, version_tag)
      - Metadata(id, value)

    Relationship tables:
      - CALLS(Function → Function)
      - DEFINES_FUNC(File → Function)
      - DEFINES_CLASS(File → Class)
      - HAS_METHOD(Class → Function)
      - IMPORTS(File → File)
      - BELONGS_TO(File → Module)
      - INHERITS(Class → Class)
      - MODIFIES(Commit → Function)
      - TOUCHES(Commit → File)

    ## Example Queries

    Count nodes:
      MATCH (f:Function) WHERE f.is_historical = 0 RETURN count(f)

    Top-10 most-called functions:
      MATCH (caller:Function)-[:CALLS]->(f:Function)
      RETURN f.name, f.file_path, count(caller) AS fan_in
      ORDER BY fan_in DESC LIMIT 10

    Functions in a specific module:
      MATCH (f:Function)<-[:DEFINES_FUNC]-(file:File)-[:BELONGS_TO]->(m:Module)
      WHERE m.path_prefix = 'kernel/sched'
      RETURN f.name, file.path LIMIT 20

    Cross-module call pattern:
      MATCH (f1:Function)-[:CALLS]->(f2:Function),
            (file1:File)-[:DEFINES_FUNC]->(f1),
            (file2:File)-[:DEFINES_FUNC]->(f2),
            (file1)-[:BELONGS_TO]->(m1:Module),
            (file2)-[:BELONGS_TO]->(m2:Module)
      WHERE m1.id <> m2.id
      RETURN m1.path_prefix, m2.path_prefix, count(*) AS calls
      ORDER BY calls DESC LIMIT 20

    Functions modified by a commit:
      MATCH (c:Commit)-[:MODIFIES]->(f:Function)
      WHERE c.hash STARTS WITH 'abc123'
      RETURN f.name, f.file_path

    Ghost functions (deleted/renamed):
      MATCH (f:Function) WHERE f.is_historical = 1
      RETURN f.name, f.file_path LIMIT 20

    Args:
        query: A valid Cypher query string.
        limit: Maximum rows to return (default 50).
    """
    cs = _get_cs()
    try:
        rows = list(cs.conn.execute(query))
    except Exception as e:
        return f"Cypher error: {e}"
    if not rows:
        return "(no results)"
    truncated = rows[:limit]
    lines = [json.dumps(list(row), default=str) for row in truncated]
    result = "[\n" + ",\n".join(lines) + "\n]"
    if len(rows) > limit:
        result += f"\n... ({len(rows)} total rows, showing first {limit})"
    return result


@mcp.tool
def codegraph_vector_search(query: str, topk: int = 10) -> str:
    """Semantic search over all indexed functions using vector embeddings.

    Finds functions whose code is semantically similar to the query,
    regardless of naming or file location.  Returns function names,
    file paths, modules, and similarity scores.

    Use this to discover:
    - Functions implementing similar patterns across subsystems
    - Code related to a concept (e.g. "error handling", "buffer management")
    - Semantic duplicates or near-duplicates

    Args:
        query: Natural-language description of the code pattern to search for.
        topk: Number of results to return.
    """
    import zvec as _zvec
    cs = _get_cs()
    query_vec = cs.model.encode(query, normalize_embeddings=True).tolist()
    hits = cs.collection.query(
        _zvec.VectorQuery("code_emb", vector=query_vec),
        topk=topk,
    )
    if not hits:
        return f"No results for '{query}'."
    results = []
    for h in hits:
        rows = list(cs.conn.execute(
            f"MATCH (f:Function {{id: '{h.id}'}})"
            f"<-[:DEFINES_FUNC]-(file:File)"
            f"-[:BELONGS_TO]->(m:Module) "
            f"RETURN f.name, f.file_path, m.path_prefix"
        ))
        if rows:
            name, fpath, mod = rows[0]
            results.append(
                f"  [{h.score:.3f}] {name} ({fpath}) [{mod}]"
            )
        else:
            results.append(
                f"  [{h.score:.3f}] {h.id} (no graph link)"
            )
    header = f"Semantic search for '{query}' ({len(results)} results):"
    return header + "\n" + "\n".join(results)


@mcp.tool
def codegraph_schema() -> str:
    """Return the full graph schema: all node tables with their properties,
    all relationship tables with their source and target types, and current
    counts for each.

    Use this to understand what data is available before writing Cypher
    queries with codegraph_cypher().
    """
    cs = _get_cs()
    stats = cs._get_stats()

    schema_text = """Graph Schema
============

Node Tables:
  File(id, fqn, path, language, loc, is_external)
  Function(id, fqn, name, qualified_name, signature, file_path,
           start_line, end_line, doc_comment, class_name, language,
           is_historical)
  Class(id, fqn, name, qualified_name, file_path, start_line, end_line)
  Module(id, fqn, name, path_prefix)
  Commit(id, fqn, hash, message, author, timestamp, version_tag)

Relationship Tables:
  CALLS(Function → Function)
  DEFINES_FUNC(File → Function)
  DEFINES_CLASS(File → Class)
  HAS_METHOD(Class → Function)
  IMPORTS(File → File)
  BELONGS_TO(File → Module)
  INHERITS(Class → Class)
  MODIFIES(Commit → Function)
  TOUCHES(Commit → File)

Current Counts:
"""
    for k, v in sorted(stats.items()):
        schema_text += f"  {k}: {v:,}\n"
    return schema_text


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="CodeScope MCP Server")
    parser.add_argument("--db-dir", default=os.environ.get("CODESCOPE_DB_DIR", ".codegraph_db"))
    parser.add_argument("--repo", default=os.environ.get("CODESCOPE_REPO_PATH", "."))
    parser.add_argument("--transport", choices=["stdio", "sse"], default="stdio")
    args = parser.parse_args()

    os.environ["CODESCOPE_DB_DIR"] = args.db_dir
    os.environ["CODESCOPE_REPO_PATH"] = args.repo

    mcp.run(transport=args.transport)
