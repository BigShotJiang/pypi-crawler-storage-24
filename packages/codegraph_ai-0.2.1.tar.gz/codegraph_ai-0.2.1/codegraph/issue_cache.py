"""Simple file-based cache for parsed GitHub issues.

Cache location: ``~/.codegraph/issue_cache/{owner}_{repo}_{number}.json``
"""

from __future__ import annotations

import json
import logging
import os
import time
from pathlib import Path

from codegraph.bug_parser import ParsedIssue

_log = logging.getLogger(__name__)

_CACHE_DIR = os.path.join(os.path.expanduser("~"), ".codegraph", "issue_cache")


def get_cache_path(owner: str, repo: str, number: int) -> Path:
    """Return the path to the cache file for a given issue."""
    return Path(_CACHE_DIR) / f"{owner}_{repo}_{number}.json"


def _issue_to_dict(issue: ParsedIssue) -> dict:
    """Serialize a ParsedIssue to a JSON-safe dict."""
    return {
        "owner": issue.owner,
        "repo": issue.repo,
        "number": issue.number,
        "title": issue.title,
        "body": issue.body,
        "labels": issue.labels,
        "extracted_paths": issue.extracted_paths,
        "extracted_funcs": issue.extracted_funcs,
        "extracted_locations": [list(loc) for loc in issue.extracted_locations],
        "linked_commits": issue.linked_commits,
        "fetched_at": issue.fetched_at,
    }


def _dict_to_issue(d: dict) -> ParsedIssue:
    """Deserialize a dict back to a ParsedIssue."""
    return ParsedIssue(
        owner=d["owner"],
        repo=d["repo"],
        number=d["number"],
        title=d["title"],
        body=d["body"],
        labels=d.get("labels", []),
        extracted_paths=d.get("extracted_paths", []),
        extracted_funcs=d.get("extracted_funcs", []),
        extracted_locations=[tuple(loc) for loc in d.get("extracted_locations", [])],
        linked_commits=d.get("linked_commits", []),
        fetched_at=d.get("fetched_at", 0),
    )


def load_cached_issue(
    owner: str, repo: str, number: int, ttl: int | None = None
) -> ParsedIssue | None:
    """Load a parsed issue from cache.

    Args:
        owner: GitHub repo owner
        repo: GitHub repo name
        number: Issue number
        ttl: Optional time-to-live in seconds. If set and the cached entry
             is older than ttl seconds, returns None.

    Returns:
        ParsedIssue if found and not expired, else None.
    """
    path = get_cache_path(owner, repo, number)
    if not path.exists():
        return None

    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as e:
        _log.warning("Failed to read cache file %s: %s", path, e)
        return None

    if ttl is not None:
        fetched_at = data.get("fetched_at", 0)
        if time.time() - fetched_at > ttl:
            _log.debug("Cache expired for %s/%s#%d", owner, repo, number)
            return None

    return _dict_to_issue(data)


def save_to_cache(issue: ParsedIssue) -> None:
    """Save a parsed issue to the file cache."""
    path = get_cache_path(issue.owner, issue.repo, issue.number)
    path.parent.mkdir(parents=True, exist_ok=True)

    data = _issue_to_dict(issue)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    _log.debug("Cached issue %s/%s#%d", issue.owner, issue.repo, issue.number)


def clear_cache(owner: str | None = None, repo: str | None = None) -> int:
    """Clear cache files. Returns count of files deleted.

    If owner and repo are given, only clear that repo's cache.
    If only owner is given, clear all repos for that owner.
    If neither, clear all cache files.
    """
    cache_dir = Path(_CACHE_DIR)
    if not cache_dir.exists():
        return 0

    count = 0
    for f in cache_dir.glob("*.json"):
        name = f.stem
        if owner and not name.startswith(f"{owner}_"):
            continue
        if owner and repo and not name.startswith(f"{owner}_{repo}_"):
            continue
        f.unlink()
        count += 1

    return count
