"""CodeScope Architecture Analyzer — automated report generation.

Takes a ``CodeScope`` instance and produces a comprehensive markdown
report with Mermaid diagrams covering structure, dependencies, evolution,
and semantic patterns.
"""

from __future__ import annotations

import time
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from codegraph.core import CodeScope


@dataclass
class _AnalysisData:
    """Intermediate container for all analysis results."""
    files: int = 0
    files_ext: int = 0
    functions: int = 0
    functions_hist: int = 0
    classes: int = 0
    modules: int = 0
    calls: int = 0
    imports: int = 0
    commits: int = 0
    commits_bf: int = 0
    touches: int = 0
    modifies: int = 0
    vectors: int = 0

    top_modules: list = field(default_factory=list)
    top_fan_in: list = field(default_factory=list)
    top_fan_out: list = field(default_factory=list)
    bridge_functions: list = field(default_factory=list)
    cross_coupling: list = field(default_factory=list)
    layer_infra: list = field(default_factory=list)
    layer_mid: list = field(default_factory=list)
    layer_consumer: list = field(default_factory=list)
    dead_code_by_subsystem: list = field(default_factory=list)
    hotfiles: list = field(default_factory=list)
    subsystem_counts: list = field(default_factory=list)


def _q(cs: CodeScope, cypher: str) -> list:
    """Execute a Cypher query, return list of tuples."""
    return list(cs.conn.execute(cypher))


def _collect_overview(cs: CodeScope, d: _AnalysisData) -> None:
    """Collect basic count statistics."""
    for label, attr in [
        ("File", "files"), ("Function", "functions"),
        ("Class", "classes"), ("Module", "modules"), ("Commit", "commits"),
    ]:
        rows = _q(cs, f"MATCH (n:{label}) RETURN count(n)")
        setattr(d, attr, rows[0][0] if rows else 0)

    rows = _q(cs, "MATCH (f:File) WHERE f.is_external = 1 RETURN count(f)")
    d.files_ext = rows[0][0] if rows else 0
    d.files -= d.files_ext

    rows = _q(cs, "MATCH (f:Function) WHERE f.is_historical = 1 RETURN count(f)")
    d.functions_hist = rows[0][0] if rows else 0

    for rel, attr in [
        ("CALLS", "calls"), ("IMPORTS", "imports"),
        ("TOUCHES", "touches"), ("MODIFIES", "modifies"),
    ]:
        rows = _q(cs, f"MATCH ()-[r:{rel}]->() RETURN count(r)")
        setattr(d, attr, rows[0][0] if rows else 0)

    rows = _q(cs, "MATCH (c:Commit) WHERE c.version_tag = 'bf' RETURN count(c)")
    d.commits_bf = rows[0][0] if rows else 0

    d.vectors = d.functions


def _collect_modules(cs: CodeScope, d: _AnalysisData) -> None:
    rows = _q(cs, """
        MATCH (f:Function)<-[:DEFINES_FUNC]-(file:File)-[:BELONGS_TO]->(m:Module)
        WHERE f.is_historical = 0
        RETURN m.path_prefix, count(f) AS func_count
        ORDER BY func_count DESC LIMIT 20
    """)
    d.top_modules = [(r[0], r[1]) for r in rows]

    rows = _q(cs, "MATCH (m:Module) RETURN m.path_prefix LIMIT 5000")
    top_level: dict[str, int] = Counter()
    for (p,) in rows:
        top_level[p.split("/")[0]] += 1
    d.subsystem_counts = top_level.most_common(15)


def _collect_fanin_fanout(cs: CodeScope, d: _AnalysisData) -> None:
    rows = _q(cs, """
        MATCH (caller:Function)-[:CALLS]->(f:Function)
        WHERE f.is_historical = 0
        RETURN f.name, f.file_path, count(caller) AS fan_in
        ORDER BY fan_in DESC LIMIT 20
    """)
    d.top_fan_in = [(r[0], r[1] or "", r[2]) for r in rows]

    rows = _q(cs, """
        MATCH (f:Function)-[:CALLS]->(callee:Function)
        WHERE f.is_historical = 0
        RETURN f.name, f.file_path, count(callee) AS fan_out
        ORDER BY fan_out DESC LIMIT 15
    """)
    d.top_fan_out = [(r[0], r[1] or "", r[2]) for r in rows]


def _collect_bridges(cs: CodeScope, d: _AnalysisData) -> None:
    rows = _q(cs, """
        MATCH (caller:Function)-[:CALLS]->(f:Function),
              (cf:File)-[:DEFINES_FUNC]->(caller),
              (cf)-[:BELONGS_TO]->(m:Module)
        WHERE f.is_historical = 0
        RETURN f.name, f.file_path,
               count(DISTINCT m.path_prefix) AS module_count,
               count(caller) AS total_callers
        ORDER BY module_count DESC LIMIT 20
    """)
    d.bridge_functions = [(r[0], r[1] or "", r[2], r[3]) for r in rows]


def _collect_coupling(cs: CodeScope, d: _AnalysisData) -> None:
    rows = _q(cs, """
        MATCH (a:Function)-[:CALLS]->(b:Function),
              (fa:File)-[:DEFINES_FUNC]->(a),
              (fb:File)-[:DEFINES_FUNC]->(b),
              (fa)-[:BELONGS_TO]->(ma:Module),
              (fb)-[:BELONGS_TO]->(mb:Module)
        WHERE ma.path_prefix <> mb.path_prefix
        RETURN ma.path_prefix, mb.path_prefix, count(*) AS calls
        ORDER BY calls DESC LIMIT 20
    """)
    d.cross_coupling = [(r[0], r[1], r[2]) for r in rows]


def _collect_layers(cs: CodeScope, d: _AnalysisData) -> None:
    mod_fi: dict[str, int] = {}
    rows = _q(cs, """
        MATCH (caller:Function)-[:CALLS]->(f:Function),
              (ff:File)-[:DEFINES_FUNC]->(f),
              (ff)-[:BELONGS_TO]->(m:Module)
        RETURN m.path_prefix, count(*) AS fi
        ORDER BY fi DESC LIMIT 40
    """)
    for r in rows:
        mod_fi[r[0]] = r[1]

    mod_fo: dict[str, int] = {}
    rows = _q(cs, """
        MATCH (f:Function)-[:CALLS]->(callee:Function),
              (ff:File)-[:DEFINES_FUNC]->(f),
              (ff)-[:BELONGS_TO]->(m:Module)
        RETURN m.path_prefix, count(*) AS fo
        ORDER BY fo DESC LIMIT 40
    """)
    for r in rows:
        mod_fo[r[0]] = r[1]

    all_mods = set(list(mod_fi.keys())[:30] + list(mod_fo.keys())[:30])
    for m in all_mods:
        fi = mod_fi.get(m, 0)
        fo = mod_fo.get(m, 0)
        total = fi + fo
        if total == 0:
            continue
        ratio = fi / total
        entry = (m, fi, fo, ratio)
        if ratio > 0.65:
            d.layer_infra.append(entry)
        elif ratio >= 0.45:
            d.layer_mid.append(entry)
        else:
            d.layer_consumer.append(entry)

    d.layer_infra.sort(key=lambda x: -x[3])
    d.layer_mid.sort(key=lambda x: -x[3])
    d.layer_consumer.sort(key=lambda x: x[3])


def _collect_dead_code(cs: CodeScope, d: _AnalysisData) -> None:
    rows = _q(cs, """
        MATCH (f:Function)<-[:DEFINES_FUNC]-(file:File)-[:BELONGS_TO]->(m:Module)
        WHERE f.is_historical = 0
        RETURN m.path_prefix, count(f) AS total
        ORDER BY total DESC LIMIT 200
    """)
    mod_total: dict[str, int] = {}
    for r in rows:
        top = r[0].split("/")[0]
        mod_total[top] = mod_total.get(top, 0) + r[1]

    rows2 = _q(cs, """
        MATCH (caller:Function)-[:CALLS]->(f:Function),
              (file:File)-[:DEFINES_FUNC]->(f),
              (file)-[:BELONGS_TO]->(m:Module)
        WHERE f.is_historical = 0
        RETURN m.path_prefix, count(DISTINCT f.id) AS with_callers
        ORDER BY with_callers DESC LIMIT 200
    """)
    mod_called: dict[str, int] = {}
    for r in rows2:
        top = r[0].split("/")[0]
        mod_called[top] = mod_called.get(top, 0) + r[1]

    entries = []
    for top in sorted(mod_total.keys(), key=lambda x: -mod_total[x]):
        total = mod_total[top]
        called = mod_called.get(top, 0)
        dead = total - called
        pct = dead / total * 100 if total > 0 else 0
        entries.append((top, total, called, dead, pct))
    d.dead_code_by_subsystem = entries


def _collect_evolution(cs: CodeScope, d: _AnalysisData) -> None:
    if d.commits == 0:
        return
    rows = _q(cs, """
        MATCH (c:Commit)-[:TOUCHES]->(f:File)
        RETURN f.path, count(c) AS commits
        ORDER BY commits DESC LIMIT 20
    """)
    d.hotfiles = [(r[0] or "?", r[1]) for r in rows]


# =========================================================================
# Report Rendering
# =========================================================================


def _render_report(d: _AnalysisData) -> str:
    lines: list[str] = []
    w = lines.append

    w("# CodeScope Architecture Analysis Report\n")
    w(f"*Generated by CodeScope*\n")
    w("---\n")

    # -- Overview --
    w("## 1. Codebase Overview\n")
    w("| Metric | Value |")
    w("|--------|-------|")
    w(f"| Source files | {d.files:,} (+{d.files_ext:,} external) |")
    w(f"| Functions | {d.functions:,} (+{d.functions_hist:,} historical) |")
    w(f"| Static call edges | {d.calls:,} |")
    w(f"| Import edges | {d.imports:,} |")
    w(f"| Classes/structs | {d.classes:,} |")
    w(f"| Modules | {d.modules:,} |")
    if d.commits > 0:
        w(f"| Commits indexed | {d.commits:,} (backfilled: {d.commits_bf:,}) |")
        w(f"| TOUCHES edges | {d.touches:,} |")
        w(f"| MODIFIES edges | {d.modifies:,} |")
    w(f"| Vector embeddings | {d.vectors:,} |")
    w("")

    # -- Subsystem Distribution --
    if d.subsystem_counts:
        w("## 2. Subsystem Distribution\n")
        w("| Subsystem | Modules |")
        w("|-----------|---------|")
        for name, cnt in d.subsystem_counts:
            w(f"| `{name}/` | {cnt:,} |")
        w("")

    # -- Top Modules --
    if d.top_modules:
        w("### Largest Modules by Function Count\n")
        w("| Module | Functions |")
        w("|--------|-----------|")
        for name, cnt in d.top_modules[:15]:
            w(f"| `{name}` | {cnt:,} |")
        w("")

    # -- Architectural Layers --
    if d.layer_infra or d.layer_mid or d.layer_consumer:
        w("## 3. Architectural Layers\n")
        w("Layers are derived from **call direction ratio** "
          "(inbound / total calls). Modules that are only called by others "
          "(ratio=1.0) are pure infrastructure; modules that only call others "
          "(ratio=0.0) are pure consumers.\n")

        w("```mermaid")
        w("graph TB")
        w("    subgraph consumer [Consumer Layer - ratio below 0.45]")
        for m, fi, fo, r in d.layer_consumer[:5]:
            safe = m.replace("/", "_").replace("-", "_").replace(".", "_")
            w(f'        {safe}["{m}<br/>outbound={fo:,}"]')
        w("    end")
        w("    subgraph mid [Mid Layer - ratio 0.45 to 0.65]")
        for m, fi, fo, r in d.layer_mid[:5]:
            safe = m.replace("/", "_").replace("-", "_").replace(".", "_")
            w(f'        {safe}["{m}<br/>in={fi:,} out={fo:,}"]')
        w("    end")
        w("    subgraph infra [Infrastructure Layer - ratio above 0.65]")
        for m, fi, fo, r in d.layer_infra[:5]:
            safe = m.replace("/", "_").replace("-", "_").replace(".", "_")
            w(f'        {safe}["{m}<br/>inbound={fi:,}"]')
        w("    end")
        w("    consumer --> mid")
        w("    mid --> infra")
        w("```\n")

        if d.layer_infra:
            w("### Infrastructure Layer (ratio > 0.65)\n")
            w("| Module | Inbound | Outbound | Ratio |")
            w("|--------|---------|----------|-------|")
            for m, fi, fo, r in d.layer_infra:
                w(f"| `{m}` | {fi:,} | {fo:,} | {r:.2f} |")
            w("")

        if d.layer_mid:
            w("### Mid Layer (ratio 0.45 - 0.65)\n")
            w("| Module | Inbound | Outbound | Ratio |")
            w("|--------|---------|----------|-------|")
            for m, fi, fo, r in d.layer_mid[:15]:
                w(f"| `{m}` | {fi:,} | {fo:,} | {r:.2f} |")
            w("")

        if d.layer_consumer:
            w("### Consumer Layer (ratio < 0.45)\n")
            w("| Module | Inbound | Outbound | Ratio |")
            w("|--------|---------|----------|-------|")
            for m, fi, fo, r in d.layer_consumer[:10]:
                w(f"| `{m}` | {fi:,} | {fo:,} | {r:.2f} |")
            w("")

    # -- Bridge Functions --
    if d.bridge_functions:
        w("## 4. Bridge Functions (Cross-Module API)\n")
        w("Functions called from the most distinct modules — the implicit API "
          "contract of the codebase.\n")
        w("| Function | Modules | Callers | Location |")
        w("|----------|---------|---------|----------|")
        for name, fpath, mods, callers in d.bridge_functions:
            w(f"| `{name}` | {mods} | {callers:,} | `{fpath}` |")
        w("")

    # -- Fan-in / Fan-out --
    if d.top_fan_in:
        w("## 5. Structural Hotspots\n")
        w("### Most-Called Functions (highest fan-in)\n")
        w("| Function | Fan-in | Location |")
        w("|----------|--------|----------|")
        for name, fpath, fi in d.top_fan_in[:15]:
            w(f"| `{name}` | {fi:,} | `{fpath}` |")
        w("")

    if d.top_fan_out:
        w("### Most Complex Functions (highest fan-out)\n")
        w("| Function | Fan-out | Location |")
        w("|----------|---------|----------|")
        for name, fpath, fo in d.top_fan_out[:10]:
            w(f"| `{name}` | {fo} | `{fpath}` |")
        w("")

    # -- Cross-Module Coupling --
    if d.cross_coupling:
        w("## 6. Cross-Module Coupling\n")
        w("| Source Module | Target Module | Calls |")
        w("|--------------|---------------|-------|")
        for src, dst, calls in d.cross_coupling[:15]:
            w(f"| `{src}` | `{dst}` | {calls:,} |")
        w("")

    # -- Evolution --
    if d.hotfiles:
        w("## 7. Evolution Hotspots\n")
        w("Most frequently modified files across indexed commits.\n")
        w("| File | Commits |")
        w("|------|---------|")
        for fpath, cnt in d.hotfiles:
            w(f"| `{fpath}` | {cnt} |")
        w("")

    # -- Dead Code --
    if d.dead_code_by_subsystem:
        w("## 8. Dead Code Density\n")
        w("Functions without any static callers, grouped by top-level "
          "subsystem. High percentages in callback-heavy subsystems "
          "(drivers, arch) are expected false positives.\n")
        w("| Subsystem | Total | With Callers | Dead | Dead % |")
        w("|-----------|-------|--------------|------|--------|")
        for top, total, called, dead, pct in d.dead_code_by_subsystem:
            if total < 500:
                continue
            w(f"| `{top}` | {total:,} | {called:,} | {dead:,} | {pct:.1f}% |")
        w("")

    w("---\n")
    w("*All data from CodeScope graph database (neug) and vector index (zvec). "
      "No estimates or approximations.*\n")

    return "\n".join(lines)


# =========================================================================
# Public API
# =========================================================================


def generate_report(cs: CodeScope) -> str:
    """Run all analyses and return a markdown report string."""
    d = _AnalysisData()

    steps = [
        ("Collecting overview...", _collect_overview),
        ("Analyzing modules...", _collect_modules),
        ("Analyzing call graph...", _collect_fanin_fanout),
        ("Finding bridge functions...", _collect_bridges),
        ("Measuring coupling...", _collect_coupling),
        ("Discovering layers...", _collect_layers),
        ("Scanning dead code...", _collect_dead_code),
        ("Analyzing evolution...", _collect_evolution),
    ]

    for msg, fn in steps:
        print(f"  {msg}", flush=True)
        t0 = time.time()
        fn(cs, d)
        print(f"    done ({time.time() - t0:.1f}s)")

    print("  Rendering report...")
    return _render_report(d)
