"""C source code adapter using tree-sitter.

Handles ``.c`` and ``.h`` files.
Extracts:
  - Function definitions (including kernel macro-wrapped patterns)
  - Function calls (direct and via field expressions like ``ptr->method()``)
  - ``#include`` directives (system and local)
  - ``struct``/``union``/``enum`` definitions as Class nodes
  - ``static`` scoping for translation-unit-local functions
  - Kernel macros: ``SYSCALL_DEFINE*``, ``EXPORT_SYMBOL*``,
    ``module_init``/``module_exit``
"""

from __future__ import annotations

import re

from tree_sitter_language_pack import get_parser

from codegraph.adapters.base import BaseAdapter
from codegraph.models import (
    CallInfo,
    ParsedClass,
    ParsedFunction,
    ParsedImport,
    ParseResult,
)

_SYSCALL_RE = re.compile(r"^SYSCALL_DEFINE\d$")
_EXPORT_MACROS = frozenset({"EXPORT_SYMBOL", "EXPORT_SYMBOL_GPL"})
_MODULE_MACROS = frozenset({"module_init", "module_exit"})

_STATIC_MARKER = "__static__"


def _node_text(node) -> str:
    return node.text.decode("utf-8") if node and node.text else ""


def _extract_c_doc(node) -> str:
    """Extract a preceding block comment (``/* ... */``) as documentation."""
    prev = node.prev_sibling
    if prev is None or prev.type != "comment":
        return ""
    text = _node_text(prev)
    if not text.startswith("/*"):
        return ""
    text = text[2:]
    if text.endswith("*/"):
        text = text[:-2]
    lines = text.splitlines()
    cleaned: list[str] = []
    for line in lines:
        line = line.strip()
        if line.startswith("*"):
            line = line[1:].strip()
        if line:
            cleaned.append(line)
    return " ".join(cleaned)


def _build_c_signature(type_text: str, declarator_text: str) -> str:
    return f"{type_text} {declarator_text}"


def _get_function_name(func_declarator_node) -> str:
    """Walk down nested declarators to find the identifier name."""
    node = func_declarator_node
    while node is not None:
        decl = node.child_by_field_name("declarator")
        if decl is None:
            return _node_text(node)
        if decl.type == "identifier":
            return _node_text(decl)
        if decl.type == "function_declarator":
            node = decl
            continue
        if decl.type in ("pointer_declarator", "parenthesized_declarator"):
            inner = decl.child_by_field_name("declarator")
            if inner and inner.type == "identifier":
                return _node_text(inner)
            if inner and inner.type == "function_declarator":
                node = inner
                continue
            return _node_text(decl)
        return _node_text(decl)
    return "unknown"


def _collect_calls(node, calls: list[CallInfo]) -> None:
    """Recursively collect function calls from a C AST subtree."""
    if node.type == "call_expression":
        func = node.child_by_field_name("function")
        if func:
            if func.type == "field_expression":
                obj_node = func.child_by_field_name("argument")
                field_node = func.child_by_field_name("field")
                receiver = _node_text(obj_node) if obj_node else None
                callee = _node_text(field_node) if field_node else _node_text(func)
                calls.append(CallInfo(
                    callee_name=callee,
                    receiver=receiver,
                    raw_expression=_node_text(func),
                ))
            else:
                callee = _node_text(func)
                calls.append(CallInfo(
                    callee_name=callee,
                    receiver=None,
                    raw_expression=callee,
                ))
    for child in node.children:
        _collect_calls(child, calls)


class CAdapter(BaseAdapter):
    """Extract functions, structs, calls and includes from C files."""

    def __init__(self) -> None:
        self._parser = get_parser("c")

    def language_name(self) -> str:
        return "c"

    def supported_extensions(self) -> list[str]:
        return [".c", ".h"]

    def parse_file(self, source: bytes, file_path: str) -> ParseResult:
        tree = self._parser.parse(source)
        root = tree.root_node

        functions: list[ParsedFunction] = []
        classes: list[ParsedClass] = []
        imports: list[ParsedImport] = []

        exported_symbols: set[str] = set()
        module_entry_points: set[str] = set()

        self._walk(
            root, file_path, functions, classes, imports,
            exported_symbols, module_entry_points,
        )

        self._apply_export_overrides(functions, exported_symbols)

        # Deduplicate functions from #ifdef/#else branches — keep the one
        # with the largest body (most likely the real implementation vs stub).
        seen_funcs: dict[str, int] = {}
        for idx, fn in enumerate(functions):
            key = f"{fn.file_path}:{fn.name}"
            if key in seen_funcs:
                prev_idx = seen_funcs[key]
                prev_fn = functions[prev_idx]
                prev_span = prev_fn.end_line - prev_fn.start_line
                cur_span = fn.end_line - fn.start_line
                if cur_span > prev_span:
                    seen_funcs[key] = idx
            else:
                seen_funcs[key] = idx
        functions = [functions[i] for i in sorted(seen_funcs.values())]

        seen_class_ids: set[str] = set()
        unique_classes: list[ParsedClass] = []
        for cls in classes:
            key = f"{cls.file_path}:{cls.name}"
            if key not in seen_class_ids:
                seen_class_ids.add(key)
                unique_classes.append(cls)
        classes = unique_classes

        return ParseResult(functions=functions, classes=classes, imports=imports)

    def _walk(
        self,
        node,
        file_path: str,
        functions: list[ParsedFunction],
        classes: list[ParsedClass],
        imports: list[ParsedImport],
        exported_symbols: set[str],
        module_entry_points: set[str],
    ) -> None:
        children = list(node.children)
        i = 0
        while i < len(children):
            child = children[i]

            if child.type == "function_definition":
                self._extract_function(child, file_path, functions)

            elif child.type == "declaration":
                self._extract_declaration(child, file_path, classes)

            elif child.type in (
                "struct_specifier", "union_specifier", "enum_specifier",
            ):
                self._extract_struct_like(child, file_path, classes)

            elif child.type == "type_definition":
                self._extract_typedef(child, file_path, classes)

            elif child.type == "preproc_include":
                self._extract_include(child, file_path, imports)

            elif child.type == "expression_statement":
                self._handle_expression_stmt(
                    child, children, i, file_path,
                    functions, exported_symbols, module_entry_points,
                )

            elif child.type in (
                "preproc_ifdef", "preproc_if", "preproc_else",
                "preproc_elif", "preproc_function_def",
            ):
                self._walk(
                    child, file_path, functions, classes, imports,
                    exported_symbols, module_entry_points,
                )

            i += 1

    def _extract_function(
        self,
        node,
        file_path: str,
        functions: list[ParsedFunction],
    ) -> None:
        is_static = False
        for child in node.children:
            if child.type == "storage_class_specifier":
                if _node_text(child).strip() == "static":
                    is_static = True

        type_node = node.child_by_field_name("type")
        decl_node = node.child_by_field_name("declarator")
        body_node = node.child_by_field_name("body")

        if decl_node is None:
            return

        name = _get_function_name(decl_node)
        type_text = _node_text(type_node) if type_node else ""
        decl_text = _node_text(decl_node)
        sig = _build_c_signature(type_text, decl_text)

        doc = _extract_c_doc(node)

        calls: list[CallInfo] = []
        if body_node:
            _collect_calls(body_node, calls)

        start_line = node.start_point[0] + 1
        end_line = node.end_point[0] + 1
        qualified = f"{file_path}:{name}"

        functions.append(
            ParsedFunction(
                name=name,
                qualified_name=qualified,
                signature=sig,
                file_path=file_path,
                start_line=start_line,
                end_line=end_line,
                doc_comment=doc,
                call_names=[c.callee_name for c in calls],
                calls=calls,
                class_name=_STATIC_MARKER if is_static else None,
            )
        )

    def _extract_declaration(
        self,
        node,
        file_path: str,
        classes: list[ParsedClass],
    ) -> None:
        """Handle top-level ``declaration`` nodes that may contain struct/union/enum.

        Only extracts struct-like types that contain a body (i.e., definitions,
        not bare type references in variable declarations).
        """
        type_node = node.child_by_field_name("type")
        if type_node and type_node.type in (
            "struct_specifier", "union_specifier", "enum_specifier",
        ):
            if type_node.child_by_field_name("body") is not None:
                self._extract_struct_like(type_node, file_path, classes)

    def _extract_struct_like(
        self,
        node,
        file_path: str,
        classes: list[ParsedClass],
    ) -> None:
        """Extract struct/union/enum as a ParsedClass."""
        kind = node.type.replace("_specifier", "")  # struct, union, enum
        name_node = node.child_by_field_name("name")
        body_node = node.child_by_field_name("body")

        if name_node is None:
            return

        name = _node_text(name_node)
        display_name = f"{kind} {name}"
        qualified = f"{file_path}:{display_name}"

        member_names: list[str] = []
        if body_node:
            for child in body_node.children:
                if child.type == "field_declaration":
                    decl = child.child_by_field_name("declarator")
                    if decl:
                        member_names.append(_node_text(decl))
                elif child.type == "enumerator":
                    n = child.child_by_field_name("name")
                    if n:
                        member_names.append(_node_text(n))

        start_line = node.start_point[0] + 1
        end_line = node.end_point[0] + 1

        classes.append(
            ParsedClass(
                name=display_name,
                qualified_name=qualified,
                file_path=file_path,
                start_line=start_line,
                end_line=end_line,
                method_names=member_names,
                base_classes=[],
            )
        )

    def _extract_typedef(
        self,
        node,
        file_path: str,
        classes: list[ParsedClass],
    ) -> None:
        """Handle ``typedef struct { ... } name_t;``."""
        type_node = node.child_by_field_name("type")
        decl_node = node.child_by_field_name("declarator")

        if type_node is None or type_node.type not in (
            "struct_specifier", "union_specifier", "enum_specifier",
        ):
            return

        inner_name = type_node.child_by_field_name("name")
        typedef_name = _node_text(decl_node) if decl_node else None

        if inner_name:
            self._extract_struct_like(type_node, file_path, classes)
        elif typedef_name:
            kind = type_node.type.replace("_specifier", "")
            display_name = f"{kind} {typedef_name}"
            qualified = f"{file_path}:{display_name}"

            member_names: list[str] = []
            body_node = type_node.child_by_field_name("body")
            if body_node:
                for child in body_node.children:
                    if child.type == "field_declaration":
                        d = child.child_by_field_name("declarator")
                        if d:
                            member_names.append(_node_text(d))
                    elif child.type == "enumerator":
                        n = child.child_by_field_name("name")
                        if n:
                            member_names.append(_node_text(n))

            start_line = node.start_point[0] + 1
            end_line = node.end_point[0] + 1

            classes.append(
                ParsedClass(
                    name=display_name,
                    qualified_name=qualified,
                    file_path=file_path,
                    start_line=start_line,
                    end_line=end_line,
                    method_names=member_names,
                    base_classes=[],
                )
            )

    def _extract_include(
        self,
        node,
        file_path: str,
        imports: list[ParsedImport],
    ) -> None:
        path_node = node.child_by_field_name("path")
        if path_node is None:
            return

        if path_node.type == "system_lib_string":
            raw = _node_text(path_node)
            target = raw.strip("<>")
            is_relative = False
        elif path_node.type == "string_literal":
            for child in path_node.children:
                if child.type == "string_content":
                    target = _node_text(child)
                    break
            else:
                raw = _node_text(path_node)
                target = raw.strip('"')
            is_relative = True
        else:
            return

        imports.append(
            ParsedImport(
                source_path=file_path,
                target_module=target,
                imported_names=[],
                is_relative=is_relative,
            )
        )

    def _handle_expression_stmt(
        self,
        stmt_node,
        siblings: list,
        index: int,
        file_path: str,
        functions: list[ParsedFunction],
        exported_symbols: set[str],
        module_entry_points: set[str],
    ) -> None:
        """Handle expression statements that may be kernel macro invocations."""
        for child in stmt_node.children:
            if child.type != "call_expression":
                continue
            func = child.child_by_field_name("function")
            args = child.child_by_field_name("arguments")
            if func is None:
                continue

            macro_name = _node_text(func)

            if _SYSCALL_RE.match(macro_name):
                self._extract_syscall(
                    child, siblings, index, file_path, functions,
                )
            elif macro_name in _EXPORT_MACROS:
                if args:
                    for a in args.children:
                        if a.is_named and a.type == "identifier":
                            exported_symbols.add(_node_text(a))
            elif macro_name in _MODULE_MACROS:
                if args:
                    for a in args.children:
                        if a.is_named and a.type == "identifier":
                            module_entry_points.add(_node_text(a))

    def _extract_syscall(
        self,
        call_node,
        siblings: list,
        index: int,
        file_path: str,
        functions: list[ParsedFunction],
    ) -> None:
        """Create a Function node for ``SYSCALL_DEFINE*(name, ...){ body }``."""
        args = call_node.child_by_field_name("arguments")
        if args is None:
            return

        first_arg = None
        for child in args.children:
            if child.is_named:
                first_arg = _node_text(child)
                break
        if not first_arg:
            return

        sys_name = f"sys_{first_arg}"

        body_node = None
        for j in range(index + 1, min(index + 3, len(siblings))):
            if siblings[j].type == "compound_statement":
                body_node = siblings[j]
                break

        calls: list[CallInfo] = []
        if body_node:
            _collect_calls(body_node, calls)

        macro_text = _node_text(call_node)
        start_line = call_node.start_point[0] + 1
        end_line = (body_node.end_point[0] + 1) if body_node else start_line

        functions.append(
            ParsedFunction(
                name=sys_name,
                qualified_name=f"{file_path}:{sys_name}",
                signature=macro_text,
                file_path=file_path,
                start_line=start_line,
                end_line=end_line,
                doc_comment="",
                call_names=[c.callee_name for c in calls],
                calls=calls,
                class_name=None,
            )
        )

    @staticmethod
    def _apply_export_overrides(
        functions: list[ParsedFunction],
        exported_symbols: set[str],
    ) -> None:
        """If a static function is also EXPORT_SYMBOL'd, remove the static marker."""
        if not exported_symbols:
            return
        for fn in functions:
            if fn.class_name == _STATIC_MARKER and fn.name in exported_symbols:
                fn.class_name = None
