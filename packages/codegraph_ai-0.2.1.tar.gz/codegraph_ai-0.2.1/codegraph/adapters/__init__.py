"""CodeScope language adapters for parsing source code via tree-sitter."""
