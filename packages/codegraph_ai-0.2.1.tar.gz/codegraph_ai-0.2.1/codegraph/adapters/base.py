"""Abstract base class for language-specific source code adapters."""

from __future__ import annotations

from abc import ABC, abstractmethod

from codegraph.models import ParseResult


class BaseAdapter(ABC):
    """Parse a single source file and extract structural information."""

    @abstractmethod
    def language_name(self) -> str:
        """Return the canonical language name, e.g. ``'python'``, ``'c'``."""
        ...

    @abstractmethod
    def supported_extensions(self) -> list[str]:
        """Return file extensions this adapter handles, e.g. ['.py']."""
        ...

    @abstractmethod
    def parse_file(self, source: bytes, file_path: str) -> ParseResult:
        """Parse *source* bytes and return structured code elements.

        Parameters
        ----------
        source:
            Raw bytes of the source file.
        file_path:
            Repository-relative path used to generate unique IDs.
        """
        ...

    def can_handle(self, file_path: str) -> bool:
        """Return ``True`` if *file_path* has a supported extension."""
        return any(file_path.endswith(ext) for ext in self.supported_extensions())
