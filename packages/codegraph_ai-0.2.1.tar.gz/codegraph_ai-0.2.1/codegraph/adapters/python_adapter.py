"""Python source code adapter using tree-sitter."""

from __future__ import annotations

from tree_sitter_language_pack import get_parser

from codegraph.adapters.base import BaseAdapter
from codegraph.models import (
    CallInfo,
    ParsedClass,
    ParsedFunction,
    ParsedImport,
    ParseResult,
)


def _node_text(node) -> str:
    """Return the UTF-8 text of a tree-sitter node."""
    return node.text.decode("utf-8") if node.text else ""


def _extract_docstring(body_node) -> str:
    """Return the leading docstring of a function/class body, if any."""
    if body_node is None or body_node.child_count == 0:
        return ""
    first = body_node.children[0]
    # tree-sitter-python may represent the docstring as:
    #   1. expression_statement > string
    #   2. string  (directly under block)
    string_node = None
    if first.type == "expression_statement" and first.child_count > 0:
        candidate = first.children[0]
        if candidate.type == "string":
            string_node = candidate
    elif first.type == "string":
        string_node = first

    if string_node is not None:
        # Try extracting from string_content child first (newer grammar)
        for child in string_node.children:
            if child.type == "string_content":
                return _node_text(child).strip()
        # Fallback: strip surrounding quotes manually
        raw = _node_text(string_node)
        for q in ('"""', "'''", '"', "'"):
            if raw.startswith(q) and raw.endswith(q):
                return raw[len(q) : -len(q)].strip()
        return raw
    return ""


def _build_signature(func_node, source_lines: list[str]) -> str:
    """Build a human-readable signature from a function_definition node."""
    name_node = func_node.child_by_field_name("name")
    params_node = func_node.child_by_field_name("parameters")
    ret_node = func_node.child_by_field_name("return_type")

    name = _node_text(name_node) if name_node else "?"
    params = _node_text(params_node) if params_node else "()"
    ret = ""
    if ret_node:
        ret = f" -> {_node_text(ret_node)}"
    return f"def {name}{params}{ret}"


def _collect_calls(node, calls: list[CallInfo]) -> None:
    """Recursively collect function calls with receiver context."""
    if node.type == "call":
        func = node.child_by_field_name("function")
        if func:
            if func.type == "attribute":
                obj_node = func.child_by_field_name("object")
                attr_node = func.child_by_field_name("attribute")
                receiver = _node_text(obj_node) if obj_node else None
                callee = _node_text(attr_node) if attr_node else _node_text(func)
                if receiver and "." in receiver:
                    receiver = receiver.rsplit(".", 1)[-1]
                calls.append(CallInfo(
                    callee_name=callee,
                    receiver=receiver,
                    raw_expression=_node_text(func),
                ))
            else:
                callee = _node_text(func)
                calls.append(CallInfo(
                    callee_name=callee,
                    receiver=None,
                    raw_expression=callee,
                ))
    for child in node.children:
        _collect_calls(child, calls)


class PythonAdapter(BaseAdapter):
    """Extract functions, classes, calls and imports from Python files."""

    def __init__(self) -> None:
        self._parser = get_parser("python")

    # -- BaseAdapter interface ------------------------------------------------

    def language_name(self) -> str:
        return "python"

    def supported_extensions(self) -> list[str]:
        return [".py"]

    def parse_file(self, source: bytes, file_path: str) -> ParseResult:
        tree = self._parser.parse(source)
        root = tree.root_node
        source_lines = source.decode("utf-8", errors="replace").splitlines()

        functions: list[ParsedFunction] = []
        classes: list[ParsedClass] = []
        imports: list[ParsedImport] = []

        self._walk_top_level(
            root, file_path, source_lines, functions, classes, imports
        )
        return ParseResult(functions=functions, classes=classes, imports=imports)

    # -- Internal helpers -----------------------------------------------------

    def _walk_top_level(
        self,
        node,
        file_path: str,
        source_lines: list[str],
        functions: list[ParsedFunction],
        classes: list[ParsedClass],
        imports: list[ParsedImport],
    ) -> None:
        """Walk top-level children of *node* and populate lists."""
        for child in node.children:
            if child.type == "function_definition":
                self._extract_function(
                    child, file_path, source_lines, functions, class_name=None
                )
            elif child.type == "decorated_definition":
                inner = _decorated_inner(child)
                if inner is not None and inner.type == "function_definition":
                    self._extract_function(
                        inner, file_path, source_lines, functions, class_name=None
                    )
                elif inner is not None and inner.type == "class_definition":
                    self._extract_class(
                        inner, file_path, source_lines, functions, classes
                    )
            elif child.type == "class_definition":
                self._extract_class(
                    child, file_path, source_lines, functions, classes
                )
            elif child.type in ("import_statement", "import_from_statement"):
                self._extract_import(child, file_path, imports)

    def _extract_function(
        self,
        func_node,
        file_path: str,
        source_lines: list[str],
        functions: list[ParsedFunction],
        class_name: str | None,
    ) -> None:
        name_node = func_node.child_by_field_name("name")
        name = _node_text(name_node) if name_node else "unknown"
        start_line = func_node.start_point[0] + 1
        end_line = func_node.end_point[0] + 1

        qualified = f"{file_path}:{name}" if not class_name else f"{file_path}:{class_name}.{name}"
        sig = _build_signature(func_node, source_lines)

        body_node = func_node.child_by_field_name("body")
        doc = _extract_docstring(body_node)

        calls: list[CallInfo] = []
        if body_node:
            _collect_calls(body_node, calls)

        functions.append(
            ParsedFunction(
                name=name,
                qualified_name=qualified,
                signature=sig,
                file_path=file_path,
                start_line=start_line,
                end_line=end_line,
                doc_comment=doc,
                call_names=[c.callee_name for c in calls],
                calls=calls,
                class_name=class_name,
            )
        )

    def _extract_class(
        self,
        class_node,
        file_path: str,
        source_lines: list[str],
        functions: list[ParsedFunction],
        classes: list[ParsedClass],
    ) -> None:
        name_node = class_node.child_by_field_name("name")
        cls_name = _node_text(name_node) if name_node else "unknown"
        start_line = class_node.start_point[0] + 1
        end_line = class_node.end_point[0] + 1
        qualified = f"{file_path}:{cls_name}"

        base_classes: list[str] = []
        superclasses = class_node.child_by_field_name("superclasses")
        if superclasses:
            for child in superclasses.children:
                if child.is_named:
                    text = _node_text(child)
                    if text and text not in ("object",):
                        base_classes.append(text)

        method_names: list[str] = []
        body = class_node.child_by_field_name("body")
        if body:
            for child in body.children:
                if child.type == "function_definition":
                    m_name = _node_text(child.child_by_field_name("name"))
                    method_names.append(m_name)
                    self._extract_function(
                        child, file_path, source_lines, functions, class_name=cls_name
                    )
                elif child.type == "decorated_definition":
                    inner = _decorated_inner(child)
                    if inner is not None and inner.type == "function_definition":
                        m_name = _node_text(inner.child_by_field_name("name"))
                        method_names.append(m_name)
                        self._extract_function(
                            inner, file_path, source_lines, functions, class_name=cls_name
                        )

        classes.append(
            ParsedClass(
                name=cls_name,
                qualified_name=qualified,
                file_path=file_path,
                start_line=start_line,
                end_line=end_line,
                method_names=method_names,
                base_classes=base_classes,
            )
        )

    @staticmethod
    def _extract_import(
        node,
        file_path: str,
        imports: list[ParsedImport],
    ) -> None:
        """Extract import with imported names and relative import support."""
        if node.type == "import_statement":
            for child in node.children:
                if child.type == "dotted_name":
                    imports.append(
                        ParsedImport(
                            source_path=file_path,
                            target_module=_node_text(child),
                        )
                    )
                elif child.type == "aliased_import":
                    name_node = child.child_by_field_name("name")
                    if name_node:
                        imports.append(
                            ParsedImport(
                                source_path=file_path,
                                target_module=_node_text(name_node),
                            )
                        )
        elif node.type == "import_from_statement":
            module_node = node.child_by_field_name("module_name")
            if module_node is None:
                return

            raw_module = _node_text(module_node)

            is_relative = False
            relative_level = 0
            target_module = raw_module

            if module_node.type == "relative_import":
                is_relative = True
                for ch in raw_module:
                    if ch == ".":
                        relative_level += 1
                    else:
                        break
                target_module = raw_module[relative_level:]
            elif raw_module.startswith("."):
                is_relative = True
                for ch in raw_module:
                    if ch == ".":
                        relative_level += 1
                    else:
                        break
                target_module = raw_module[relative_level:]

            imported_names: list[str] = []
            past_import = False
            for child in node.children:
                if not child.is_named and _node_text(child) == "import":
                    past_import = True
                    continue
                if not past_import:
                    continue
                if child.type == "dotted_name":
                    imported_names.append(_node_text(child))
                elif child.type == "aliased_import":
                    name_node = child.child_by_field_name("name")
                    if name_node:
                        imported_names.append(_node_text(name_node))
                elif child.type == "wildcard_import":
                    imported_names.append("*")

            imports.append(
                ParsedImport(
                    source_path=file_path,
                    target_module=target_module,
                    imported_names=imported_names,
                    is_relative=is_relative,
                    relative_level=relative_level,
                )
            )


# -- Utilities ---------------------------------------------------------------


def _decorated_inner(node):
    """Return the actual definition node wrapped by a decorated_definition."""
    for child in node.children:
        if child.type in ("function_definition", "class_definition"):
            return child
    return None
