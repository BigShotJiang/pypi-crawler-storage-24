"""Bug content parser — extracts file paths, function names, and stack traces
from GitHub issue body text.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field


@dataclass
class ParsedIssue:
    """Structured representation of a parsed GitHub issue."""

    owner: str
    repo: str
    number: int
    title: str
    body: str
    labels: list[str] = field(default_factory=list)
    extracted_paths: list[str] = field(default_factory=list)
    extracted_funcs: list[str] = field(default_factory=list)
    extracted_locations: list[tuple[str, int]] = field(default_factory=list)
    linked_commits: list[str] = field(default_factory=list)
    fetched_at: int = 0


# ---------------------------------------------------------------------------
# Regex patterns
# ---------------------------------------------------------------------------

# Common source file extensions (non-capturing, longer variants first)
_FILE_EXT = r"\.(?:tsx|jsx|mjs|cjs|cpp|hpp|yml|yaml|scss|toml|swift|py|js|ts|c|h|cc|go|rs|rb|java|kt|sh|json|md|css|html)"

# File path pattern: at least one slash, ending with a known extension
# Avoids matching URLs by requiring no "://" before the path
_PATH_RE = re.compile(
    r"(?<![:/])(?<!\w)"           # not preceded by :// or word char
    r"((?:[\w\-.]+/)+[\w\-.]+" + _FILE_EXT + r")"
    r"(?::(\d+))?",               # optional :line_number
    re.MULTILINE,
)

# URL pattern to filter out
_URL_RE = re.compile(r"https?://\S+")

# Markdown image/link pattern
_MD_LINK_RE = re.compile(r"!?\[.*?\]\(.*?\)")

# Python stack trace: File "path", line N, in func
_PY_TRACE_RE = re.compile(
    r'File\s+"([^"]+)",\s+line\s+(\d+),\s+in\s+(\w+)',
    re.MULTILINE,
)

# C/C++ stack trace: #N 0x... in func () at path:line
_C_TRACE_RE = re.compile(
    r"#\d+\s+(?:0x[\da-fA-F]+\s+in\s+)?(\w+)\s*\([^)]*\)\s+at\s+([\w/.]+):(\d+)",
    re.MULTILINE,
)

# JavaScript/Node stack trace: at func (path:line:col) or at path:line:col
_JS_TRACE_RE = re.compile(
    r"at\s+(?:(\w[\w.]*)\s+\()?([\w/.\\-]+):(\d+):\d+\)?",
    re.MULTILINE,
)

# Go stack trace: package/path.funcName(args)\n\tpath:line
_GO_TRACE_RE = re.compile(
    r"([\w/.]+)\.(\w+)\([^)]*\)\n\s+([\w/.]+):(\d+)",
    re.MULTILINE,
)

# Rust stack trace / backtrace: N: module::func at path:line
_RUST_TRACE_RE = re.compile(
    r"\d+:\s+(?:[\w:]+::)?(\w+)\s+at\s+([\w/.]+):(\d+)",
    re.MULTILINE,
)

# Generic function-like references: `func_name()` or func_name()
_FUNC_REF_RE = re.compile(
    r"(?:`(\w{2,60})\(\s*\)`)|"           # `func()`
    r"(?:(?:^|\s)(\w{2,60})\s*\(\s*\))",  # plain func()
    re.MULTILINE,
)

# "in function_name" or "in `function_name`"
_IN_FUNC_RE = re.compile(
    r"\bin\s+`?(\w{2,60})`?(?:\s|$|,|\.|:)",
    re.MULTILINE,
)


def _strip_markdown_noise(text: str) -> str:
    """Remove URLs and markdown links to avoid false positive path extraction."""
    text = _URL_RE.sub("", text)
    text = _MD_LINK_RE.sub("", text)
    return text


def extract_file_paths(text: str) -> list[str]:
    """Extract file paths with common source extensions from text.

    Returns deduplicated list preserving first-seen order.
    """
    cleaned = _strip_markdown_noise(text)
    paths: list[str] = []
    seen: set[str] = set()
    for match in _PATH_RE.finditer(cleaned):
        path = match.group(1)
        if path not in seen:
            seen.add(path)
            paths.append(path)
    return paths


def extract_function_names(text: str) -> list[str]:
    """Extract function names from stack traces and inline references.

    Returns deduplicated list preserving first-seen order.
    """
    funcs: list[str] = []
    seen: set[str] = set()

    def _add(name: str) -> None:
        if name and name not in seen and len(name) >= 2:
            # skip common non-function words
            skip = {
                "the", "and", "for", "not", "with", "from", "this", "that",
                "def", "class", "import", "return", "yield", "raise", "None",
                "True", "False", "self", "cls", "async", "await", "function",
                "const", "let", "var", "if", "else", "elif", "try", "except",
                "catch", "throw", "new", "delete", "typeof", "instanceof",
                "File", "Error", "Bug", "Issue", "line",
            }
            if name not in skip:
                seen.add(name)
                funcs.append(name)

    for m in _PY_TRACE_RE.finditer(text):
        _add(m.group(3))
    for m in _C_TRACE_RE.finditer(text):
        _add(m.group(1))
    for m in _JS_TRACE_RE.finditer(text):
        if m.group(1):
            parts = m.group(1).split(".")
            _add(parts[-1])
    for m in _GO_TRACE_RE.finditer(text):
        _add(m.group(2))
    for m in _RUST_TRACE_RE.finditer(text):
        _add(m.group(1))
    for m in _FUNC_REF_RE.finditer(text):
        _add(m.group(1) or m.group(2))

    return funcs


def extract_stack_trace_locations(text: str) -> list[tuple[str, int]]:
    """Extract (file, line) pairs from stack traces across languages."""
    locations: list[tuple[str, int]] = []
    seen: set[tuple[str, int]] = set()

    def _add(path: str, line: int) -> None:
        pair = (path, line)
        if pair not in seen:
            seen.add(pair)
            locations.append(pair)

    for m in _PY_TRACE_RE.finditer(text):
        _add(m.group(1), int(m.group(2)))
    for m in _C_TRACE_RE.finditer(text):
        _add(m.group(2), int(m.group(3)))
    for m in _JS_TRACE_RE.finditer(text):
        _add(m.group(2), int(m.group(3)))
    for m in _GO_TRACE_RE.finditer(text):
        _add(m.group(3), int(m.group(4)))
    for m in _RUST_TRACE_RE.finditer(text):
        _add(m.group(2), int(m.group(3)))

    # Also extract from generic path:line patterns
    for m in _PATH_RE.finditer(_strip_markdown_noise(text)):
        if m.group(2):
            _add(m.group(1), int(m.group(2)))

    return locations


def parse_issue(raw: dict, owner: str, repo: str) -> ParsedIssue:
    """Parse a raw issue dict (from github_client) into a ParsedIssue.

    Combines title + body for extraction.
    """
    import time

    title = raw.get("title", "")
    body = raw.get("body", "")
    full_text = f"{title}\n\n{body}"

    return ParsedIssue(
        owner=owner,
        repo=repo,
        number=raw["number"],
        title=title,
        body=body,
        labels=raw.get("labels", []),
        extracted_paths=extract_file_paths(full_text),
        extracted_funcs=extract_function_names(full_text),
        extracted_locations=extract_stack_trace_locations(full_text),
        linked_commits=raw.get("linked_commits", []),
        fetched_at=int(time.time()),
    )
