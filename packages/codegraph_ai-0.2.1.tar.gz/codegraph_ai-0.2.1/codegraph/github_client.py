"""GitHub GraphQL client for fetching issues via the `gh` CLI.

Uses subprocess to call `gh api graphql`, leveraging the user's existing
GitHub authentication.
"""

from __future__ import annotations

import json
import logging
import shutil
import subprocess

_log = logging.getLogger(__name__)

_SINGLE_ISSUE_QUERY = """
query($owner: String!, $repo: String!, $number: Int!) {
  repository(owner: $owner, name: $repo) {
    issue(number: $number) {
      number
      title
      body
      createdAt
      closedAt
      state
      labels(first: 10) { nodes { name } }
      timelineItems(itemTypes: [CROSS_REFERENCED_EVENT], first: 20) {
        nodes {
          ... on CrossReferencedEvent {
            source {
              ... on PullRequest {
                number
                mergeCommit { oid }
              }
            }
          }
        }
      }
    }
  }
}
"""

_TOP_BUGS_QUERY = """
query($owner: String!, $repo: String!, $label: String!, $first: Int!) {
  repository(owner: $owner, name: $repo) {
    issues(
      first: $first,
      labels: [$label],
      states: [OPEN, CLOSED],
      orderBy: {field: CREATED_AT, direction: DESC}
    ) {
      nodes {
        number
        title
        body
        createdAt
        closedAt
        state
        labels(first: 10) { nodes { name } }
        timelineItems(itemTypes: [CROSS_REFERENCED_EVENT], first: 20) {
          nodes {
            ... on CrossReferencedEvent {
              source {
                ... on PullRequest {
                  number
                  mergeCommit { oid }
                }
              }
            }
          }
        }
      }
    }
  }
}
"""


class GitHubClientError(Exception):
    """Raised when a GitHub API call fails."""


def _ensure_gh() -> str:
    """Return the path to the ``gh`` binary, or raise."""
    path = shutil.which("gh")
    if path is None:
        raise GitHubClientError(
            "GitHub CLI (gh) is not installed. "
            "Install it from https://cli.github.com/ and run `gh auth login`."
        )
    return path


def _run_graphql(query: str, variables: dict) -> dict:
    """Execute a GraphQL query via ``gh api graphql``."""
    gh = _ensure_gh()
    cmd = [
        gh, "api", "graphql",
        "-f", f"query={query}",
    ]
    for key, value in variables.items():
        flag = "-F" if isinstance(value, int) else "-f"
        cmd.extend([flag, f"{key}={value}"])

    _log.debug("Running: %s", " ".join(cmd))
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)

    if result.returncode != 0:
        stderr = result.stderr.strip()
        if "401" in stderr or "auth" in stderr.lower():
            raise GitHubClientError(
                f"GitHub authentication failed. Run `gh auth login` first.\n{stderr}"
            )
        if "rate limit" in stderr.lower() or "403" in stderr:
            raise GitHubClientError(f"GitHub API rate limit exceeded.\n{stderr}")
        raise GitHubClientError(f"gh api graphql failed (exit {result.returncode}): {stderr}")

    try:
        data = json.loads(result.stdout)
    except json.JSONDecodeError as e:
        raise GitHubClientError(f"Invalid JSON response from gh: {e}") from e

    if "errors" in data:
        msgs = "; ".join(e.get("message", str(e)) for e in data["errors"])
        raise GitHubClientError(f"GraphQL errors: {msgs}")

    return data


def _extract_linked_commits(issue_data: dict) -> list[str]:
    """Pull merge-commit SHAs from cross-referenced PRs."""
    commits = []
    timeline = issue_data.get("timelineItems", {}).get("nodes", [])
    for item in timeline:
        source = item.get("source") if isinstance(item, dict) else None
        if source and isinstance(source, dict):
            merge = source.get("mergeCommit")
            if merge and merge.get("oid"):
                commits.append(merge["oid"])
    return commits


def fetch_issue(owner: str, repo: str, number: int) -> dict:
    """Fetch a single issue by number.

    Returns a dict with keys: number, title, body, createdAt, closedAt,
    state, labels, linked_commits.
    """
    variables = {"owner": owner, "repo": repo, "number": number}
    data = _run_graphql(_SINGLE_ISSUE_QUERY, variables)

    issue = data.get("data", {}).get("repository", {}).get("issue")
    if issue is None:
        raise GitHubClientError(f"Issue #{number} not found in {owner}/{repo}")

    labels = [n["name"] for n in issue.get("labels", {}).get("nodes", [])]
    linked_commits = _extract_linked_commits(issue)

    return {
        "number": issue["number"],
        "title": issue["title"],
        "body": issue.get("body") or "",
        "createdAt": issue.get("createdAt"),
        "closedAt": issue.get("closedAt"),
        "state": issue.get("state", "OPEN"),
        "labels": labels,
        "linked_commits": linked_commits,
    }


def fetch_top_bugs(
    owner: str, repo: str, k: int = 10, label: str = "bug"
) -> list[dict]:
    """Fetch top-k issues with the given label, newest first.

    Returns a list of dicts with the same shape as ``fetch_issue``.
    """
    variables = {"owner": owner, "repo": repo, "label": label, "first": k}
    data = _run_graphql(_TOP_BUGS_QUERY, variables)

    nodes = (
        data.get("data", {})
        .get("repository", {})
        .get("issues", {})
        .get("nodes", [])
    )

    results = []
    for issue in nodes:
        labels = [n["name"] for n in issue.get("labels", {}).get("nodes", [])]
        linked_commits = _extract_linked_commits(issue)
        results.append({
            "number": issue["number"],
            "title": issue["title"],
            "body": issue.get("body") or "",
            "createdAt": issue.get("createdAt"),
            "closedAt": issue.get("closedAt"),
            "state": issue.get("state", "OPEN"),
            "labels": labels,
            "linked_commits": linked_commits,
        })

    return results
