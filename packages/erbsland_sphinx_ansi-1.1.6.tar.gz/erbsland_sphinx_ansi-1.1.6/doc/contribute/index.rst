***********************
Contributing Guidelines
***********************

.. toctree::
    :maxdepth: 2
    :hidden:

    code-of-conduct.rst
    code-style.rst
    write-a-unittest.rst

Thank you for considering a contribution to this project!
We truly appreciate your time and effort, and we’re excited to collaborate with you.  

.. div:: sd-fs-4 sd-font-weight-bold

    Code of Conduct

By contributing to this project, you agree to follow our :doc:`Code of Conduct <code-of-conduct>`.  
Please take a moment to read it—it helps us maintain a **welcoming, respectful, and inclusive community** for everyone.

.. button-ref:: code-of-conduct
    :ref-type: doc
    :color: primary
    :align: center

    Read the Code of Conduct →

.. div:: sd-fs-4 sd-font-weight-bold

    How You Can Contribute

We welcome contributions of all kinds. Here are a few ways to get involved:

* **Found a bug?** Please `open an issue <https://github.com/erbsland-dev/erbsland-sphinx-ansi/issues/new>`_ to let us know.
* **Have a feature request?** We’d love to hear your ideas—just `open an issue <https://github.com/erbsland-dev/erbsland-sphinx-ansi/issues/new>`_.
* **Have a question?** Feel free to `start a discussion <https://github.com/erbsland-dev/erbsland-sphinx-ansi/discussions>`_. We’re glad to help!

Even small contributions, such as improving documentation, fixing typos, or clarifying error messages, are valuable and appreciated.  

.. div:: sd-fs-4 sd-font-weight-bold

    Pull Requests

We encourage pull requests, but to avoid duplicate work and make sure we’re aligned, please **reach out first** by:  

* starting a `discussion <https://github.com/erbsland-dev/erbsland-sphinx-ansi/discussions>`_, or
* `opening an issue <https://github.com/erbsland-dev/erbsland-sphinx-ansi/issues/new>`_.

This helps us review your idea early and ensure your contribution fits well into the project’s direction.  

Before submitting, please also review:  

* :doc:`code-style` for our Python coding conventions.  
* :doc:`write-a-unittest` for writing and running tests.  

Well-tested, clean, and documented contributions have the best chance of being merged quickly.  

.. div:: sd-fs-4 sd-font-weight-bold

    About the Use of Artificial Intelligence

We value contributions that are thoughtfully crafted by humans.  
Using tools to improve clarity or catch mistakes is perfectly fine, but **all contributions must be reviewed and validated by you before submission**.  

To keep the project safe and maintainable:  

* We regularly scan the codebase for vulnerabilities and similar issues with automated tools.  
* Automatically generated issues or pull requests **without meaningful human input** will not be accepted.  

Our goal is to keep this project reliable, transparent, and easy to contribute to—for everyone.

