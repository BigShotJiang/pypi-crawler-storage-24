"""Native tests for PowerPath Pydantic models."""

from __future__ import annotations

from timeback_powerpath import (
    AssignmentResult,
    Attempt,
    BulkResult,
    ExternalTestCreateResponse,
    GetAttemptsResponse,
    LessonPlanCreateResponse,
    PaginationMeta,
    PowerPathTestQuestion,
    ResetPlacementResponse,
)
from timeback_powerpath import (
    TestAssignment as PowerPathTestAssignment,
)
from timeback_powerpath import (
    TestAssignmentsListResponse as PowerPathTestAssignmentsListResponse,
)


def test_test_assignment_parses_camel_case() -> None:
    ta = PowerPathTestAssignment.model_validate(
        {
            "sourcedId": "ta-1",
            "studentSourcedId": "student-1",
            "studentEmail": "student@example.com",
            "assignedByUserSourcedId": None,
            "subject": "Math",
            "grade": "3",
            "assignmentStatus": "assigned",
        }
    )
    assert ta.sourced_id == "ta-1"


def test_list_response_parses_pagination() -> None:
    result = PowerPathTestAssignmentsListResponse.model_validate(
        {
            "testAssignments": [
                {
                    "sourcedId": "ta-1",
                    "studentSourcedId": "student-1",
                    "studentEmail": "s@e.com",
                    "assignedByUserSourcedId": None,
                    "subject": "Math",
                    "grade": "3",
                    "assignmentStatus": "assigned",
                }
            ],
            "totalCount": 1,
            "pageCount": 1,
            "pageNumber": 1,
            "offset": 0,
            "limit": 100,
        }
    )
    assert result.total_count == 1


def test_other_response_models_parse() -> None:
    assert (
        PaginationMeta.model_validate(
            {"totalCount": 1, "pageCount": 1, "pageNumber": 1, "offset": 0, "limit": 10}
        ).total_count
        == 1
    )
    assert (
        AssignmentResult.model_validate(
            {"assignmentId": "a-1", "lessonId": "l-1", "resourceId": "r-1"}
        ).assignment_id
        == "a-1"
    )
    assert (
        Attempt.model_validate(
            {
                "attempt": 1,
                "score": 85.0,
                "scoreStatus": "fully graded",
                "xp": 10,
                "startedAt": "2024-01-01T00:00:00Z",
                "completedAt": None,
            }
        ).score
        == 85.0
    )
    assert (
        ExternalTestCreateResponse.model_validate(
            {
                "lessonType": "test-out",
                "lessonId": "l-1",
                "courseComponentId": "cc-1",
                "resourceId": "r-1",
                "toolProvider": "mastery-track",
            }
        ).lesson_type
        == "test-out"
    )
    assert (
        PowerPathTestQuestion.model_validate(
            {
                "id": "q-1",
                "index": 0,
                "title": "Question 1",
                "url": "https://example.com/q1",
                "difficulty": "medium",
            }
        ).id
        == "q-1"
    )
    assert (
        BulkResult.model_validate(
            {
                "success": True,
                "results": [{"assignmentId": "a-1", "lessonId": "l-1", "resourceId": "r-1"}],
                "errors": [],
            }
        ).success
        is True
    )
    assert (
        LessonPlanCreateResponse.model_validate({"lessonPlanId": "lp-1"}).lesson_plan_id == "lp-1"
    )
    assert (
        ResetPlacementResponse.model_validate(
            {"success": True, "placementResultsDeleted": 1, "onboardingReset": True}
        ).onboarding_reset
        is True
    )
    assert (
        len(
            GetAttemptsResponse.model_validate(
                {
                    "attempts": [
                        {
                            "attempt": 1,
                            "score": 80,
                            "scoreStatus": "fully graded",
                            "xp": 10,
                            "startedAt": "2024-01-01T00:00:00Z",
                            "completedAt": "2024-01-01T00:30:00Z",
                        }
                    ]
                }
            ).attempts
        )
        == 1
    )
