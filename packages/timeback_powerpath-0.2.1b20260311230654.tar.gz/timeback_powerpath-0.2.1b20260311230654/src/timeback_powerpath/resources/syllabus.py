"""
Syllabus Resource

PowerPath syllabus operations.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any
from urllib.parse import quote

from timeback_common import serialize_input, validate_non_empty_string, validate_with_schema

from ..types.inputs import SyllabusQueryParams
from ..types.responses import SyllabusResponse

if TYPE_CHECKING:
    from ..lib.transport import Transport


class SyllabusResource:
    """Syllabus resource for PowerPath APIs."""

    def __init__(self, transport: Transport) -> None:
        self._transport = transport

    @property
    def _base_path(self) -> str:
        return self._transport.paths.base

    async def get(
        self,
        course_sourced_id: str,
        params: SyllabusQueryParams | dict[str, Any] | None = None,
    ) -> SyllabusResponse:
        """Get syllabus for a course."""
        validate_non_empty_string(course_sourced_id, "course_sourced_id")
        if params is None:
            params = SyllabusQueryParams()
        validate_with_schema(SyllabusQueryParams, params, "syllabus query params")
        body = await self._transport.get(
            f"{self._base_path}/syllabus/{quote(course_sourced_id, safe='')}",
            params=serialize_input(params, SyllabusQueryParams),
        )
        return SyllabusResponse.model_validate(body)
