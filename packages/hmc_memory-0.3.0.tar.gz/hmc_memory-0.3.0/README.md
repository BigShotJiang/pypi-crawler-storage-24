# MemoryAI — Python SDK

[![PyPI](https://img.shields.io/pypi/v/hmc-memory)](https://pypi.org/project/hmc-memory/)
[![Python](https://img.shields.io/pypi/pyversions/hmc-memory)](https://pypi.org/project/hmc-memory/)

Persistent memory for AI agents. Store, recall, and manage context across sessions.

## Install

```bash
pip install hmc-memory
```

## Quick Start

```python
from memoryai import MemoryAI

mem = MemoryAI(api_key="hm_sk_...", base_url="https://memoryai.dev")

# Bootstrap — load context at session start
ctx = mem.bootstrap(task_description="Fix auth bug", project_name="my-app")
print(ctx["context_block"])

# Store — save what you learn
mem.store("User prefers dark mode", tags=["preferences"], priority="hot")

# Recall — search memory
for r in mem.recall("user preferences"):
    print(f"[{r.score:.0%}] {r.content}")

# Learn — store action + result + lesson
mem.learn(action="Fixed N+1 query", result="Response time 2s → 50ms", lesson="Always check ORM queries")

# Compact — save session context for later
mem.compact("Session transcript...", task_context="Refactoring auth")

mem.close()
```

## Async

```python
from memoryai import AsyncMemoryAI

async with AsyncMemoryAI(api_key="hm_sk_...", base_url="https://memoryai.dev") as mem:
    await mem.store("Important context", tags=["project"])
    results = await mem.recall("project context")
```

## IDE Integration (MCP)

Works with Cursor, VS Code, Claude Desktop, Windsurf, Kiro, and OpenClaw via MCP server. See [Integration Guide](https://github.com/memoryai-dev/memoryai/blob/main/INTEGRATION-GUIDE.md).

## Features

- 4-layer memory: L1 cache → L3 vector+FTS → L2 deep reasoning → L4 archive
- Neural graph with spreading activation for associative recall
- Entity extraction (files, people, packages, URLs)
- Session recovery and context monitoring
- Snapshot/restore for safe rollbacks
- Collective knowledge pool (anonymized, opt-in)
- Content dedup and contradiction detection
- Hot/warm/cold tiering with automatic retention

## Legacy Imports

Backward compatible — these still work:

```python
from cortexmemory import MemoryAI      # OK
from hybridmemory import HybridMemory  # OK — alias for MemoryAI
```

## Get an API Key

```bash
curl -X POST https://memoryai.dev/v1/admin/provision \
  -H "Content-Type: application/json" \
  -d '{"name": "my-agent", "tos_accepted": true}'
```

## Links

- PyPI: https://pypi.org/project/hmc-memory/
- Website: https://memoryai.dev
- Integration Guide: [INTEGRATION-GUIDE.md](https://github.com/memoryai-dev/memoryai/blob/main/INTEGRATION-GUIDE.md)
