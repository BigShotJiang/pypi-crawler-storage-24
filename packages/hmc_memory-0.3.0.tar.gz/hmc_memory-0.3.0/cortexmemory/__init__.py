"""Backward compatibility — use `from memoryai import ...` instead."""
from memoryai import *  # noqa: F401,F403
from memoryai import __all__, __version__  # noqa: F811
