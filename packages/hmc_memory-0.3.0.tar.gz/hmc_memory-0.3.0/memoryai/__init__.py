"""MemoryAI Python SDK — persistent AI memory as a service."""
from memoryai.client import (
    MemoryAI,
    AsyncMemoryAI,
    MemoryResult,
    StoreResult,
    CompactResult,
    IndexProjectResult,
    Stats,
    CollectiveResult,
    ContributeResult,
    ConfirmResult,
    CollectiveStats,
    L2StoreResult,
    L2RecallResult,
    L2CompressResult,
    L2Stats,
    ShardInfo,
    SynthesisStats,
)

# Backward compatibility aliases
HybridMemory = MemoryAI
AsyncHybridMemory = AsyncMemoryAI

__all__ = [
    "MemoryAI",
    "AsyncMemoryAI",
    "HybridMemory",
    "AsyncHybridMemory",
    "MemoryResult",
    "StoreResult",
    "CompactResult",
    "IndexProjectResult",
    "Stats",
    "CollectiveResult",
    "ContributeResult",
    "ConfirmResult",
    "CollectiveStats",
    "L2StoreResult",
    "L2RecallResult",
    "L2CompressResult",
    "L2Stats",
    "ShardInfo",
    "SynthesisStats",
]
__version__ = "0.3.0"
