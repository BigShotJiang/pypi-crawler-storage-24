"""nopac - AI-powered insight into US PAC actions."""

from .version import __version__

__all__ = ["__version__"]
