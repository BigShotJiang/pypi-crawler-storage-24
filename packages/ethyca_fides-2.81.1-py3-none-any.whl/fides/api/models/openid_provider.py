import enum

from sqlalchemy import ARRAY, Boolean, Column, String
from sqlalchemy import Enum as EnumColumn
from sqlalchemy.ext.declarative import declared_attr

from fides.api.db.base_class import Base
from fides.api.db.encryption_utils import encrypted_type


class ProviderEnum(enum.Enum):
    google = "google"
    okta = "okta"
    azure = "azure"
    custom = "custom"


class OpenIDProvider(Base):
    """The DB ORM model for OpenIDProvider."""

    identifier = Column(String, unique=True, index=True)
    name = Column(String)
    provider = Column(EnumColumn(ProviderEnum))
    client_id = Column(
        encrypted_type(type_in=String()),
        nullable=False,
    )
    client_secret = Column(
        encrypted_type(type_in=String()),
        nullable=False,
    )
    domain = Column(String, nullable=True)  # Used for Okta provider
    authorization_url = Column(String, nullable=True)  # Used for Custom provider
    token_url = Column(String, nullable=True)  # Used for Custom provider
    user_info_url = Column(String, nullable=True)  # Used for Custom provider
    scopes = Column(ARRAY(String), nullable=True)  # Used for Custom provider
    email_field = Column(String, nullable=True)  # Used for Custom provider
    verify_email = Column(
        Boolean, default=True, nullable=False
    )  # Used for Custom provider
    verify_email_field = Column(String, nullable=True)  # Used for Custom provider

    @declared_attr
    def __tablename__(self) -> str:
        return "openid_provider"
