"""Run a command on a GPU sandbox with optional workspace sync."""
from __future__ import annotations

import logging
import os
import shlex
from collections.abc import Awaitable, Callable
from pathlib import Path

import trio

from wafer.dtypes import (
    Tool,
    ToolCall,
    ToolFunction,
    ToolFunctionParameter,
    ToolResult,
    ToolResultDelta,
)

logger = logging.getLogger(__name__)

MAX_OUTPUT_SIZE = 30_000

SANDBOX_RUN_TOOL = Tool(
    type="function",
    function=ToolFunction(
        name="sandbox_run",
        description=(
            "Run a command on a GPU sandbox. Syncs your workspace to the target, "
            "executes the command with full GPU access, and returns stdout/stderr. "
            "Use for compilation, benchmarks, profiling, and any GPU work. "
            "Prefer this over bash('wafer sandbox run ...')."
        ),
        parameters=ToolFunctionParameter(
            type="object",
            properties={
                "command": {
                    "type": "string",
                    "description": "Command to execute on the GPU (e.g. 'nvcc -O3 -o main main.cu && ./main')",
                },
                "target": {
                    "type": "string",
                    "description": "GPU target name (e.g. 'b200', 'mi355x'). Omit to use the default target.",
                },
                "sync": {
                    "type": "boolean",
                    "description": "Sync workspace to sandbox before running (default: true)",
                },
                "timeout": {
                    "type": "integer",
                    "description": "Timeout in seconds (default: 1200)",
                },
            },
        ),
        required=["command"],
    ),
)


def _resolve_target_name(explicit: str | None) -> str:
    """Resolve target name from explicit arg, env vars, or fail."""
    if explicit:
        return explicit
    from_env = os.environ.get("WAFER_TARGET_NAME") or os.environ.get("WAFER_DEFAULT_TARGET")
    assert from_env, (
        "No target specified and WAFER_TARGET_NAME / WAFER_DEFAULT_TARGET not set. "
        "Pass target='b200' or similar."
    )
    return from_env


async def exec_sandbox_run(
    tool_call: ToolCall,
    working_dir: Path,
    on_output: Callable[[ToolResultDelta], Awaitable[None]] | None = None,
) -> ToolResult:
    """Execute a command on a GPU sandbox with streaming output."""
    try:
        return await _exec_sandbox_run_inner(tool_call, working_dir, on_output)
    except BaseExceptionGroup as eg:
        # Unwrap trio ExceptionGroup to surface the actual error
        actual = eg.exceptions[0] if eg.exceptions else eg
        logger.error("sandbox_run failed: %s", actual, exc_info=True)
        return ToolResult(
            tool_call_id=tool_call.id,
            is_error=True,
            content=f"sandbox_run failed: {actual}",
            error=str(actual),
        )
    except Exception as e:
        logger.error("sandbox_run failed: %s", e, exc_info=True)
        return ToolResult(
            tool_call_id=tool_call.id,
            is_error=True,
            content=f"sandbox_run failed: {e}",
            error=str(e),
        )


async def _exec_sandbox_run_inner(
    tool_call: ToolCall,
    working_dir: Path,
    on_output: Callable[[ToolResultDelta], Awaitable[None]] | None = None,
) -> ToolResult:
    """Inner implementation of sandbox_run."""
    command = tool_call.args.get("command", "")
    assert command, "command is required"

    target_arg: str | None = tool_call.args.get("target")
    do_sync: bool = tool_call.args.get("sync", True)
    timeout: int = tool_call.args.get("timeout", 1200)
    idle_timeout: int = 600

    target_name = _resolve_target_name(target_arg)

    # Phase 1: resolve/create sandbox (sync, in thread)
    def _resolve_sandbox():
        from wafer.sandbox.operations import resolve_or_create_sandbox
        return resolve_or_create_sandbox(target_name, json_output=True)

    sandbox = await trio.to_thread.run_sync(_resolve_sandbox)

    work_dir_for_meta = f"/tmp/{working_dir.resolve().name}" if working_dir.is_dir() else None
    if on_output:
        await on_output(ToolResultDelta(
            tool_call_id=tool_call.id,
            delta=f"[sandbox_meta:{sandbox.id}:{sandbox.target_name}:{work_dir_for_meta or '/tmp/workspace'}]\n",
        ))

    # Phase 2: sync workspace (sync, in thread)
    work_dir: str | None = None
    if do_sync and working_dir.is_dir():
        from wafer.targets.operations import get_target_ssh_info, sync_to_target

        def _load_target():
            from wafer.targets.operations import load_target
            return load_target(sandbox.target_name)

        target_config = await trio.to_thread.run_sync(_load_target, abandon_on_cancel=True)
        ssh_info = await get_target_ssh_info(target_config)
        resolved = working_dir.resolve()
        work_dir = f"/tmp/{resolved.name}"

        if on_output:
            await on_output(ToolResultDelta(
                tool_call_id=tool_call.id,
                delta="[workspace] Syncing workspace...\n",
            ))

        await trio.to_thread.run_sync(
            lambda: sync_to_target(ssh_info, resolved, remote_path=work_dir),
            abandon_on_cancel=True,
        )
        logger.info("sandbox_run synced %s to %s:%s", resolved, ssh_info.host, work_dir)

    # Phase 3: run command with streaming (async, in main event loop)
    cmd_str = command
    if work_dir:
        cmd_str = f"cd {shlex.quote(work_dir)} && {command}"

    streamed_bytes = 0

    async def _on_ssh_output(chunk: str) -> None:
        nonlocal streamed_bytes
        streamed_bytes += len(chunk)
        if streamed_bytes > MAX_OUTPUT_SIZE:
            return
        await on_output(ToolResultDelta(tool_call_id=tool_call.id, delta=chunk))

    from wafer.sandbox import SandboxSession

    session = SandboxSession(sandbox)
    await session.connect()
    try:
        output, exit_code, _meta = await session.run_command(
            cmd_str, timeout, no_change_timeout=idle_timeout,
            on_output=_on_ssh_output if on_output else None,
        )
    finally:
        if session._client is not None:
            await session._client.close()

    # Touch sandbox to keep alive
    def _touch():
        from wafer.sandbox.operations import db_touch_sandbox
        db_touch_sandbox(sandbox.id, sandbox.timeout_hours)

    await trio.to_thread.run_sync(_touch)

    if len(output) > MAX_OUTPUT_SIZE:
        output = output[:MAX_OUTPUT_SIZE] + "\n\n... (output truncated)"

    if exit_code != 0:
        return ToolResult(
            tool_call_id=tool_call.id,
            is_error=True,
            content=output or "(no output)",
            error=f"Command exited with code {exit_code}",
        )
    return ToolResult(
        tool_call_id=tool_call.id,
        is_error=False,
        content=output or "(no output)",
    )
