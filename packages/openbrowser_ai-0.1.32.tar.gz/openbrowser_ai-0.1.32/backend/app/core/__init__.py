"""Core configuration and utilities."""

