"""CLI sub-package (Typer)."""
