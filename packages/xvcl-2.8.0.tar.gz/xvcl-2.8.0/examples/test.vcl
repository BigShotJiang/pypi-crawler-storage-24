# IPCrypt-Deterministic Implementation

# === LOOKUP TABLES ===

# Byte (0-255) to 2-digit hex
table byte_to_hex STRING {
    "0": "00", 
    "1": "01", 
    "2": "02", 
    "3": "03", 
    "4": "04", 
    "5": "05", 
    "6": "06", 
    "7": "07", 
    "8": "08", 
    "9": "09", 
    "10": "0a", 
    "11": "0b", 
    "12": "0c", 
    "13": "0d", 
    "14": "0e", 
    "15": "0f", 
    "16": "10", 
    "17": "11", 
    "18": "12", 
    "19": "13", 
    "20": "14", 
    "21": "15", 
    "22": "16", 
    "23": "17", 
    "24": "18", 
    "25": "19", 
    "26": "1a", 
    "27": "1b", 
    "28": "1c", 
    "29": "1d", 
    "30": "1e", 
    "31": "1f", 
    "32": "20", 
    "33": "21", 
    "34": "22", 
    "35": "23", 
    "36": "24", 
    "37": "25", 
    "38": "26", 
    "39": "27", 
    "40": "28", 
    "41": "29", 
    "42": "2a", 
    "43": "2b", 
    "44": "2c", 
    "45": "2d", 
    "46": "2e", 
    "47": "2f", 
    "48": "30", 
    "49": "31", 
    "50": "32", 
    "51": "33", 
    "52": "34", 
    "53": "35", 
    "54": "36", 
    "55": "37", 
    "56": "38", 
    "57": "39", 
    "58": "3a", 
    "59": "3b", 
    "60": "3c", 
    "61": "3d", 
    "62": "3e", 
    "63": "3f", 
    "64": "40", 
    "65": "41", 
    "66": "42", 
    "67": "43", 
    "68": "44", 
    "69": "45", 
    "70": "46", 
    "71": "47", 
    "72": "48", 
    "73": "49", 
    "74": "4a", 
    "75": "4b", 
    "76": "4c", 
    "77": "4d", 
    "78": "4e", 
    "79": "4f", 
    "80": "50", 
    "81": "51", 
    "82": "52", 
    "83": "53", 
    "84": "54", 
    "85": "55", 
    "86": "56", 
    "87": "57", 
    "88": "58", 
    "89": "59", 
    "90": "5a", 
    "91": "5b", 
    "92": "5c", 
    "93": "5d", 
    "94": "5e", 
    "95": "5f", 
    "96": "60", 
    "97": "61", 
    "98": "62", 
    "99": "63", 
    "100": "64", 
    "101": "65", 
    "102": "66", 
    "103": "67", 
    "104": "68", 
    "105": "69", 
    "106": "6a", 
    "107": "6b", 
    "108": "6c", 
    "109": "6d", 
    "110": "6e", 
    "111": "6f", 
    "112": "70", 
    "113": "71", 
    "114": "72", 
    "115": "73", 
    "116": "74", 
    "117": "75", 
    "118": "76", 
    "119": "77", 
    "120": "78", 
    "121": "79", 
    "122": "7a", 
    "123": "7b", 
    "124": "7c", 
    "125": "7d", 
    "126": "7e", 
    "127": "7f", 
    "128": "80", 
    "129": "81", 
    "130": "82", 
    "131": "83", 
    "132": "84", 
    "133": "85", 
    "134": "86", 
    "135": "87", 
    "136": "88", 
    "137": "89", 
    "138": "8a", 
    "139": "8b", 
    "140": "8c", 
    "141": "8d", 
    "142": "8e", 
    "143": "8f", 
    "144": "90", 
    "145": "91", 
    "146": "92", 
    "147": "93", 
    "148": "94", 
    "149": "95", 
    "150": "96", 
    "151": "97", 
    "152": "98", 
    "153": "99", 
    "154": "9a", 
    "155": "9b", 
    "156": "9c", 
    "157": "9d", 
    "158": "9e", 
    "159": "9f", 
    "160": "a0", 
    "161": "a1", 
    "162": "a2", 
    "163": "a3", 
    "164": "a4", 
    "165": "a5", 
    "166": "a6", 
    "167": "a7", 
    "168": "a8", 
    "169": "a9", 
    "170": "aa", 
    "171": "ab", 
    "172": "ac", 
    "173": "ad", 
    "174": "ae", 
    "175": "af", 
    "176": "b0", 
    "177": "b1", 
    "178": "b2", 
    "179": "b3", 
    "180": "b4", 
    "181": "b5", 
    "182": "b6", 
    "183": "b7", 
    "184": "b8", 
    "185": "b9", 
    "186": "ba", 
    "187": "bb", 
    "188": "bc", 
    "189": "bd", 
    "190": "be", 
    "191": "bf", 
    "192": "c0", 
    "193": "c1", 
    "194": "c2", 
    "195": "c3", 
    "196": "c4", 
    "197": "c5", 
    "198": "c6", 
    "199": "c7", 
    "200": "c8", 
    "201": "c9", 
    "202": "ca", 
    "203": "cb", 
    "204": "cc", 
    "205": "cd", 
    "206": "ce", 
    "207": "cf", 
    "208": "d0", 
    "209": "d1", 
    "210": "d2", 
    "211": "d3", 
    "212": "d4", 
    "213": "d5", 
    "214": "d6", 
    "215": "d7", 
    "216": "d8", 
    "217": "d9", 
    "218": "da", 
    "219": "db", 
    "220": "dc", 
    "221": "dd", 
    "222": "de", 
    "223": "df", 
    "224": "e0", 
    "225": "e1", 
    "226": "e2", 
    "227": "e3", 
    "228": "e4", 
    "229": "e5", 
    "230": "e6", 
    "231": "e7", 
    "232": "e8", 
    "233": "e9", 
    "234": "ea", 
    "235": "eb", 
    "236": "ec", 
    "237": "ed", 
    "238": "ee", 
    "239": "ef", 
    "240": "f0", 
    "241": "f1", 
    "242": "f2", 
    "243": "f3", 
    "244": "f4", 
    "245": "f5", 
    "246": "f6", 
    "247": "f7", 
    "248": "f8", 
    "249": "f9", 
    "250": "fa", 
    "251": "fb", 
    "252": "fc", 
    "253": "fd", 
    "254": "fe", 
    "255": "ff"
}

sub wtf {
    set req.http.X-Func-ip_to_hex128-Return = "WTF";
}

sub ip_to_hex128 {
    declare local var.input_ip IP;
    set var.input_ip = req.http.X-Func-ip_to_hex128-ip;

    declare local var.return_value STRING;
    declare local var.is_ipv4 BOOL;
    set var.is_ipv4 = addr.is_ipv4(var.input_ip);

    if (var.is_ipv4) {
        # IPv4: Convert to IPv4-mapped IPv6 format
        # Format: 00000000000000000000ffff + 8 hex digits for IPv4
        declare local var.ipv4_hex STRING;
        set var.ipv4_hex = "00000000000000000000ffff";

        # Extract each octet and convert to hex
        set var.ipv4_hex = var.ipv4_hex + table.lookup(byte_to_hex, std.itoa(addr.extract_bits(var.input_ip, 24, 8)));
        set var.ipv4_hex = var.ipv4_hex + table.lookup(byte_to_hex, std.itoa(addr.extract_bits(var.input_ip, 16, 8)));
        set var.ipv4_hex = var.ipv4_hex + table.lookup(byte_to_hex, std.itoa(addr.extract_bits(var.input_ip, 8, 8)));
        set var.ipv4_hex = var.ipv4_hex + table.lookup(byte_to_hex, std.itoa(addr.extract_bits(var.input_ip, 0, 8)));

        set var.return_value = var.ipv4_hex;
    } else {
        # IPv6: Extract all 16 bytes
        declare local var.ipv6_hex STRING;
        set var.ipv6_hex = "";

        # Extract all 16 bytes (128 bits) from the IPv6 address
        set var.ipv6_hex = var.ipv6_hex + table.lookup(byte_to_hex, std.itoa(addr.extract_bits(var.input_ip, 120, 8)));
        set var.ipv6_hex = var.ipv6_hex + table.lookup(byte_to_hex, std.itoa(addr.extract_bits(var.input_ip, 112, 8)));
        set var.ipv6_hex = var.ipv6_hex + table.lookup(byte_to_hex, std.itoa(addr.extract_bits(var.input_ip, 104, 8)));
        set var.ipv6_hex = var.ipv6_hex + table.lookup(byte_to_hex, std.itoa(addr.extract_bits(var.input_ip, 96, 8)));
        set var.ipv6_hex = var.ipv6_hex + table.lookup(byte_to_hex, std.itoa(addr.extract_bits(var.input_ip, 88, 8)));
        set var.ipv6_hex = var.ipv6_hex + table.lookup(byte_to_hex, std.itoa(addr.extract_bits(var.input_ip, 80, 8)));
        set var.ipv6_hex = var.ipv6_hex + table.lookup(byte_to_hex, std.itoa(addr.extract_bits(var.input_ip, 72, 8)));
        set var.ipv6_hex = var.ipv6_hex + table.lookup(byte_to_hex, std.itoa(addr.extract_bits(var.input_ip, 64, 8)));
        set var.ipv6_hex = var.ipv6_hex + table.lookup(byte_to_hex, std.itoa(addr.extract_bits(var.input_ip, 56, 8)));
        set var.ipv6_hex = var.ipv6_hex + table.lookup(byte_to_hex, std.itoa(addr.extract_bits(var.input_ip, 48, 8)));
        set var.ipv6_hex = var.ipv6_hex + table.lookup(byte_to_hex, std.itoa(addr.extract_bits(var.input_ip, 40, 8)));
        set var.ipv6_hex = var.ipv6_hex + table.lookup(byte_to_hex, std.itoa(addr.extract_bits(var.input_ip, 32, 8)));
        set var.ipv6_hex = var.ipv6_hex + table.lookup(byte_to_hex, std.itoa(addr.extract_bits(var.input_ip, 24, 8)));
        set var.ipv6_hex = var.ipv6_hex + table.lookup(byte_to_hex, std.itoa(addr.extract_bits(var.input_ip, 16, 8)));
        set var.ipv6_hex = var.ipv6_hex + table.lookup(byte_to_hex, std.itoa(addr.extract_bits(var.input_ip, 8, 8)));
        set var.ipv6_hex = var.ipv6_hex + table.lookup(byte_to_hex, std.itoa(addr.extract_bits(var.input_ip, 0, 8)));

        set var.return_value = var.ipv6_hex;
    }

    set req.http.X-Func-ip_to_hex128-Return = var.return_value;
}

sub hex128_to_ipv6 {
    declare local var.hex128 STRING;
    set var.hex128 = req.http.X-Func-hex128_to_ipv6-hex128;

    declare local var.return_value STRING;

    # Convert to standard IPv6 format by:
    # 1. Grouping into 8 groups of 4 hex digits
    # 2. Using std.str2ip to get canonical formatting
    #
    # Format as IPv6: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx
    declare local var.ipv6_str STRING;
    set var.ipv6_str =
        substr(var.hex128, 0, 4) + ":" +
        substr(var.hex128, 4, 4) + ":" +
        substr(var.hex128, 8, 4) + ":" +
        substr(var.hex128, 12, 4) + ":" +
        substr(var.hex128, 16, 4) + ":" +
        substr(var.hex128, 20, 4) + ":" +
        substr(var.hex128, 24, 4) + ":" +
        substr(var.hex128, 28, 4);

    # Convert to IP and back to STRING to get canonical format
    declare local var.ip_val IP;
    set var.ip_val = std.str2ip(var.ipv6_str, "::1");

    # Now convert back to string to get canonical format
    set var.return_value = var.ip_val;

    set req.http.X-Func-hex128_to_ipv6-Return = var.return_value;
}

sub ipcrypt_deterministic_encrypt {
    declare local var.input_ip IP;
    declare local var.key STRING;
    set var.input_ip = req.http.X-Func-ipcrypt_deterministic_encrypt-ip;
    set var.key = req.http.X-Func-ipcrypt_deterministic_encrypt-key;

    declare local var.return_value STRING;

    # Step 1: Convert IP to 16-byte (128-bit) hex representation
    set req.http.X-Func-ip_to_hex128-ip = var.input_ip;
    call ip_to_hex128;
    declare local var.hex128 STRING;
    set var.hex128 = req.http.X-Func-ip_to_hex128-Return;

    # Step 2: Encrypt using AES-128 (use CBC with zero IV to simulate ECB)
    declare local var.zero_iv STRING;
    set var.zero_iv = "00000000000000000000000000000000";
    declare local var.encrypted_hex STRING;
    set var.encrypted_hex = crypto.encrypt_hex(aes128, cbc, nopad, var.key, var.zero_iv, var.hex128);

    # Step 3: Convert to IPv6 format
    set req.http.X-Func-hex128_to_ipv6-hex128 = var.encrypted_hex;
    call hex128_to_ipv6;
    set var.return_value = req.http.X-Func-hex128_to_ipv6-Return;

    set req.http.X-Func-ipcrypt_deterministic_encrypt-Return = var.return_value;
}

sub ipcrypt_deterministic_decrypt {
    declare local var.encrypted_ip IP;
    declare local var.key STRING;
    set var.encrypted_ip = req.http.X-Func-ipcrypt_deterministic_decrypt-encrypted_ip;
    set var.key = req.http.X-Func-ipcrypt_deterministic_decrypt-key;

    declare local var.return_value STRING;

    # Step 1: Convert encrypted IP to hex
    set req.http.X-Func-ip_to_hex128-ip = var.encrypted_ip;
    call ip_to_hex128;
    declare local var.encrypted_hex STRING;
    set var.encrypted_hex = req.http.X-Func-ip_to_hex128-Return;

    # Step 2: Decrypt using AES-128 (use CBC with zero IV to simulate ECB)
    declare local var.zero_iv STRING;
    set var.zero_iv = "00000000000000000000000000000000";
    declare local var.decrypted_hex STRING;
    set var.decrypted_hex = crypto.decrypt_hex(aes128, cbc, nopad, var.key, var.zero_iv, var.encrypted_hex);

    # Step 3: Convert to IPv6 format
    set req.http.X-Func-hex128_to_ipv6-hex128 = var.decrypted_hex;
    call hex128_to_ipv6;
    set var.return_value = req.http.X-Func-hex128_to_ipv6-Return;

    set req.http.X-Func-ipcrypt_deterministic_decrypt-Return = var.return_value;
}

sub vcl_deliver {
#FASTLY DELIVER

    set req.http.X-Func-ip_to_hex128-ip = client.ip;
    set req.http.X-Func-ipcrypt_deterministic_encrypt-ip = client.ip;
    set req.http.X-Func-ipcrypt_deterministic_encrypt-key = "3608bca1e44ea6c4d268eb6db0226027";
    call ipcrypt_deterministic_encrypt;
    call ip_to_hex128;
    set resp.http.X-Prout = req.http.X-Func-ip_to_hex128-Return;
    set resp.http.X-Prout2 = req.http.X-Func-ipcrypt_deterministic_encrypt-Return;

    return(deliver);
}

sub vcl_recv {
#FASTLY RECV

  # Added comment
    # Test ipcrypt-deterministic with test vectors

    # Test vector 1: 0.0.0.0
    set req.http.X-Func-ipcrypt_deterministic_encrypt-ip = "0.0.0.0";
    set req.http.X-Func-ipcrypt_deterministic_encrypt-key = "0123456789abcdeffedcba9876543210";
#    call ipcrypt_deterministic_encrypt;
    set req.http.X-Test1-Result = req.http.X-Func-ipcrypt_deterministic_encrypt-Return;
    set req.http.X-Test1-Expected = "bde9:6789:d353:824c:d7c6:f58a:6bd2:26eb";

    return(lookup);
}
