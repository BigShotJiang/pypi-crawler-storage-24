# User-Agent MD5 Hash Example
# This XVCL code computes the MD5 hash of the User-Agent header

# Inline macro for zero-overhead MD5 computation

# Function to compute User-Agent hash with optional prefix

sub vcl_recv {
#FASTLY RECV

  # Method 1: Direct computation
  declare local var.ua_hash STRING;
  set var.ua_hash = digest.hash_md5(req.http.User-Agent);
  set req.http.X-UA-MD5 = var.ua_hash;

  # Method 2: Using the inline macro (zero overhead)
  set req.http.X-UA-MD5-Macro = digest.hash_md5((req.http.User-Agent));

  # Method 3: Using the function with a prefix
  declare local var.ua_hash_prefixed STRING;
  set req.http.X-Func-compute_ua_hash-ua = req.http.User-Agent;
  set req.http.X-Func-compute_ua_hash-prefix = "md5:";
  call compute_ua_hash;
  set var.ua_hash_prefixed = req.http.X-Func-compute_ua_hash-Return;
  set req.http.X-UA-MD5-Prefixed = var.ua_hash_prefixed;

  return(lookup);
}

// Function: compute_ua_hash
//@recv, hash, hit, miss, pass, fetch, error, deliver, log
sub compute_ua_hash {

  declare local var.ua STRING;
  declare local var.prefix STRING;

  set var.ua = req.http.X-Func-compute_ua_hash-ua;
  set var.prefix = req.http.X-Func-compute_ua_hash-prefix;

  declare local var.return_value STRING;

  declare local var.hash STRING;
  set var.hash = digest.hash_md5(var.ua);
  if (var.prefix != "") {
    set var.hash = var.prefix + var.hash;
  }
  set var.return_value = var.hash;

  set req.http.X-Func-compute_ua_hash-Return = var.return_value;
}
