# IPCrypt-NDX
#
# ipcrypt-ndx uses:
# - AES-XTS tweakable block cipher
# - 32-byte key (split into two 16-byte AES-128 keys)
# - 16-byte random tweak
# - Output: 32 bytes (tweak || ciphertext)

backend test_backend {
    .host = "127.0.0.1";
    .port = "8080";
}

# === CONSTANTS ===

# Test vectors from draft-denis-ipcrypt

# Test tweaks

# === LOOKUP TABLES ===

# XOR lookup table for hex digits (256 entries: 0x0^0x0 through 0xf^0xf)
table hex_xor STRING {
    "00": "0"#if not (a == 15 and b == 15)
,#endif

    "01": "1"#if not (a == 15 and b == 15)
,#endif

    "02": "2"#if not (a == 15 and b == 15)
,#endif

    "03": "3"#if not (a == 15 and b == 15)
,#endif

    "04": "4"#if not (a == 15 and b == 15)
,#endif

    "05": "5"#if not (a == 15 and b == 15)
,#endif

    "06": "6"#if not (a == 15 and b == 15)
,#endif

    "07": "7"#if not (a == 15 and b == 15)
,#endif

    "08": "8"#if not (a == 15 and b == 15)
,#endif

    "09": "9"#if not (a == 15 and b == 15)
,#endif

    "0a": "a"#if not (a == 15 and b == 15)
,#endif

    "0b": "b"#if not (a == 15 and b == 15)
,#endif

    "0c": "c"#if not (a == 15 and b == 15)
,#endif

    "0d": "d"#if not (a == 15 and b == 15)
,#endif

    "0e": "e"#if not (a == 15 and b == 15)
,#endif

    "0f": "f"#if not (a == 15 and b == 15)
,#endif

    "10": "1"#if not (a == 15 and b == 15)
,#endif

    "11": "0"#if not (a == 15 and b == 15)
,#endif

    "12": "3"#if not (a == 15 and b == 15)
,#endif

    "13": "2"#if not (a == 15 and b == 15)
,#endif

    "14": "5"#if not (a == 15 and b == 15)
,#endif

    "15": "4"#if not (a == 15 and b == 15)
,#endif

    "16": "7"#if not (a == 15 and b == 15)
,#endif

    "17": "6"#if not (a == 15 and b == 15)
,#endif

    "18": "9"#if not (a == 15 and b == 15)
,#endif

    "19": "8"#if not (a == 15 and b == 15)
,#endif

    "1a": "b"#if not (a == 15 and b == 15)
,#endif

    "1b": "a"#if not (a == 15 and b == 15)
,#endif

    "1c": "d"#if not (a == 15 and b == 15)
,#endif

    "1d": "c"#if not (a == 15 and b == 15)
,#endif

    "1e": "f"#if not (a == 15 and b == 15)
,#endif

    "1f": "e"#if not (a == 15 and b == 15)
,#endif

    "20": "2"#if not (a == 15 and b == 15)
,#endif

    "21": "3"#if not (a == 15 and b == 15)
,#endif

    "22": "0"#if not (a == 15 and b == 15)
,#endif

    "23": "1"#if not (a == 15 and b == 15)
,#endif

    "24": "6"#if not (a == 15 and b == 15)
,#endif

    "25": "7"#if not (a == 15 and b == 15)
,#endif

    "26": "4"#if not (a == 15 and b == 15)
,#endif

    "27": "5"#if not (a == 15 and b == 15)
,#endif

    "28": "a"#if not (a == 15 and b == 15)
,#endif

    "29": "b"#if not (a == 15 and b == 15)
,#endif

    "2a": "8"#if not (a == 15 and b == 15)
,#endif

    "2b": "9"#if not (a == 15 and b == 15)
,#endif

    "2c": "e"#if not (a == 15 and b == 15)
,#endif

    "2d": "f"#if not (a == 15 and b == 15)
,#endif

    "2e": "c"#if not (a == 15 and b == 15)
,#endif

    "2f": "d"#if not (a == 15 and b == 15)
,#endif

    "30": "3"#if not (a == 15 and b == 15)
,#endif

    "31": "2"#if not (a == 15 and b == 15)
,#endif

    "32": "1"#if not (a == 15 and b == 15)
,#endif

    "33": "0"#if not (a == 15 and b == 15)
,#endif

    "34": "7"#if not (a == 15 and b == 15)
,#endif

    "35": "6"#if not (a == 15 and b == 15)
,#endif

    "36": "5"#if not (a == 15 and b == 15)
,#endif

    "37": "4"#if not (a == 15 and b == 15)
,#endif

    "38": "b"#if not (a == 15 and b == 15)
,#endif

    "39": "a"#if not (a == 15 and b == 15)
,#endif

    "3a": "9"#if not (a == 15 and b == 15)
,#endif

    "3b": "8"#if not (a == 15 and b == 15)
,#endif

    "3c": "f"#if not (a == 15 and b == 15)
,#endif

    "3d": "e"#if not (a == 15 and b == 15)
,#endif

    "3e": "d"#if not (a == 15 and b == 15)
,#endif

    "3f": "c"#if not (a == 15 and b == 15)
,#endif

    "40": "4"#if not (a == 15 and b == 15)
,#endif

    "41": "5"#if not (a == 15 and b == 15)
,#endif

    "42": "6"#if not (a == 15 and b == 15)
,#endif

    "43": "7"#if not (a == 15 and b == 15)
,#endif

    "44": "0"#if not (a == 15 and b == 15)
,#endif

    "45": "1"#if not (a == 15 and b == 15)
,#endif

    "46": "2"#if not (a == 15 and b == 15)
,#endif

    "47": "3"#if not (a == 15 and b == 15)
,#endif

    "48": "c"#if not (a == 15 and b == 15)
,#endif

    "49": "d"#if not (a == 15 and b == 15)
,#endif

    "4a": "e"#if not (a == 15 and b == 15)
,#endif

    "4b": "f"#if not (a == 15 and b == 15)
,#endif

    "4c": "8"#if not (a == 15 and b == 15)
,#endif

    "4d": "9"#if not (a == 15 and b == 15)
,#endif

    "4e": "a"#if not (a == 15 and b == 15)
,#endif

    "4f": "b"#if not (a == 15 and b == 15)
,#endif

    "50": "5"#if not (a == 15 and b == 15)
,#endif

    "51": "4"#if not (a == 15 and b == 15)
,#endif

    "52": "7"#if not (a == 15 and b == 15)
,#endif

    "53": "6"#if not (a == 15 and b == 15)
,#endif

    "54": "1"#if not (a == 15 and b == 15)
,#endif

    "55": "0"#if not (a == 15 and b == 15)
,#endif

    "56": "3"#if not (a == 15 and b == 15)
,#endif

    "57": "2"#if not (a == 15 and b == 15)
,#endif

    "58": "d"#if not (a == 15 and b == 15)
,#endif

    "59": "c"#if not (a == 15 and b == 15)
,#endif

    "5a": "f"#if not (a == 15 and b == 15)
,#endif

    "5b": "e"#if not (a == 15 and b == 15)
,#endif

    "5c": "9"#if not (a == 15 and b == 15)
,#endif

    "5d": "8"#if not (a == 15 and b == 15)
,#endif

    "5e": "b"#if not (a == 15 and b == 15)
,#endif

    "5f": "a"#if not (a == 15 and b == 15)
,#endif

    "60": "6"#if not (a == 15 and b == 15)
,#endif

    "61": "7"#if not (a == 15 and b == 15)
,#endif

    "62": "4"#if not (a == 15 and b == 15)
,#endif

    "63": "5"#if not (a == 15 and b == 15)
,#endif

    "64": "2"#if not (a == 15 and b == 15)
,#endif

    "65": "3"#if not (a == 15 and b == 15)
,#endif

    "66": "0"#if not (a == 15 and b == 15)
,#endif

    "67": "1"#if not (a == 15 and b == 15)
,#endif

    "68": "e"#if not (a == 15 and b == 15)
,#endif

    "69": "f"#if not (a == 15 and b == 15)
,#endif

    "6a": "c"#if not (a == 15 and b == 15)
,#endif

    "6b": "d"#if not (a == 15 and b == 15)
,#endif

    "6c": "a"#if not (a == 15 and b == 15)
,#endif

    "6d": "b"#if not (a == 15 and b == 15)
,#endif

    "6e": "8"#if not (a == 15 and b == 15)
,#endif

    "6f": "9"#if not (a == 15 and b == 15)
,#endif

    "70": "7"#if not (a == 15 and b == 15)
,#endif

    "71": "6"#if not (a == 15 and b == 15)
,#endif

    "72": "5"#if not (a == 15 and b == 15)
,#endif

    "73": "4"#if not (a == 15 and b == 15)
,#endif

    "74": "3"#if not (a == 15 and b == 15)
,#endif

    "75": "2"#if not (a == 15 and b == 15)
,#endif

    "76": "1"#if not (a == 15 and b == 15)
,#endif

    "77": "0"#if not (a == 15 and b == 15)
,#endif

    "78": "f"#if not (a == 15 and b == 15)
,#endif

    "79": "e"#if not (a == 15 and b == 15)
,#endif

    "7a": "d"#if not (a == 15 and b == 15)
,#endif

    "7b": "c"#if not (a == 15 and b == 15)
,#endif

    "7c": "b"#if not (a == 15 and b == 15)
,#endif

    "7d": "a"#if not (a == 15 and b == 15)
,#endif

    "7e": "9"#if not (a == 15 and b == 15)
,#endif

    "7f": "8"#if not (a == 15 and b == 15)
,#endif

    "80": "8"#if not (a == 15 and b == 15)
,#endif

    "81": "9"#if not (a == 15 and b == 15)
,#endif

    "82": "a"#if not (a == 15 and b == 15)
,#endif

    "83": "b"#if not (a == 15 and b == 15)
,#endif

    "84": "c"#if not (a == 15 and b == 15)
,#endif

    "85": "d"#if not (a == 15 and b == 15)
,#endif

    "86": "e"#if not (a == 15 and b == 15)
,#endif

    "87": "f"#if not (a == 15 and b == 15)
,#endif

    "88": "0"#if not (a == 15 and b == 15)
,#endif

    "89": "1"#if not (a == 15 and b == 15)
,#endif

    "8a": "2"#if not (a == 15 and b == 15)
,#endif

    "8b": "3"#if not (a == 15 and b == 15)
,#endif

    "8c": "4"#if not (a == 15 and b == 15)
,#endif

    "8d": "5"#if not (a == 15 and b == 15)
,#endif

    "8e": "6"#if not (a == 15 and b == 15)
,#endif

    "8f": "7"#if not (a == 15 and b == 15)
,#endif

    "90": "9"#if not (a == 15 and b == 15)
,#endif

    "91": "8"#if not (a == 15 and b == 15)
,#endif

    "92": "b"#if not (a == 15 and b == 15)
,#endif

    "93": "a"#if not (a == 15 and b == 15)
,#endif

    "94": "d"#if not (a == 15 and b == 15)
,#endif

    "95": "c"#if not (a == 15 and b == 15)
,#endif

    "96": "f"#if not (a == 15 and b == 15)
,#endif

    "97": "e"#if not (a == 15 and b == 15)
,#endif

    "98": "1"#if not (a == 15 and b == 15)
,#endif

    "99": "0"#if not (a == 15 and b == 15)
,#endif

    "9a": "3"#if not (a == 15 and b == 15)
,#endif

    "9b": "2"#if not (a == 15 and b == 15)
,#endif

    "9c": "5"#if not (a == 15 and b == 15)
,#endif

    "9d": "4"#if not (a == 15 and b == 15)
,#endif

    "9e": "7"#if not (a == 15 and b == 15)
,#endif

    "9f": "6"#if not (a == 15 and b == 15)
,#endif

    "a0": "a"#if not (a == 15 and b == 15)
,#endif

    "a1": "b"#if not (a == 15 and b == 15)
,#endif

    "a2": "8"#if not (a == 15 and b == 15)
,#endif

    "a3": "9"#if not (a == 15 and b == 15)
,#endif

    "a4": "e"#if not (a == 15 and b == 15)
,#endif

    "a5": "f"#if not (a == 15 and b == 15)
,#endif

    "a6": "c"#if not (a == 15 and b == 15)
,#endif

    "a7": "d"#if not (a == 15 and b == 15)
,#endif

    "a8": "2"#if not (a == 15 and b == 15)
,#endif

    "a9": "3"#if not (a == 15 and b == 15)
,#endif

    "aa": "0"#if not (a == 15 and b == 15)
,#endif

    "ab": "1"#if not (a == 15 and b == 15)
,#endif

    "ac": "6"#if not (a == 15 and b == 15)
,#endif

    "ad": "7"#if not (a == 15 and b == 15)
,#endif

    "ae": "4"#if not (a == 15 and b == 15)
,#endif

    "af": "5"#if not (a == 15 and b == 15)
,#endif

    "b0": "b"#if not (a == 15 and b == 15)
,#endif

    "b1": "a"#if not (a == 15 and b == 15)
,#endif

    "b2": "9"#if not (a == 15 and b == 15)
,#endif

    "b3": "8"#if not (a == 15 and b == 15)
,#endif

    "b4": "f"#if not (a == 15 and b == 15)
,#endif

    "b5": "e"#if not (a == 15 and b == 15)
,#endif

    "b6": "d"#if not (a == 15 and b == 15)
,#endif

    "b7": "c"#if not (a == 15 and b == 15)
,#endif

    "b8": "3"#if not (a == 15 and b == 15)
,#endif

    "b9": "2"#if not (a == 15 and b == 15)
,#endif

    "ba": "1"#if not (a == 15 and b == 15)
,#endif

    "bb": "0"#if not (a == 15 and b == 15)
,#endif

    "bc": "7"#if not (a == 15 and b == 15)
,#endif

    "bd": "6"#if not (a == 15 and b == 15)
,#endif

    "be": "5"#if not (a == 15 and b == 15)
,#endif

    "bf": "4"#if not (a == 15 and b == 15)
,#endif

    "c0": "c"#if not (a == 15 and b == 15)
,#endif

    "c1": "d"#if not (a == 15 and b == 15)
,#endif

    "c2": "e"#if not (a == 15 and b == 15)
,#endif

    "c3": "f"#if not (a == 15 and b == 15)
,#endif

    "c4": "8"#if not (a == 15 and b == 15)
,#endif

    "c5": "9"#if not (a == 15 and b == 15)
,#endif

    "c6": "a"#if not (a == 15 and b == 15)
,#endif

    "c7": "b"#if not (a == 15 and b == 15)
,#endif

    "c8": "4"#if not (a == 15 and b == 15)
,#endif

    "c9": "5"#if not (a == 15 and b == 15)
,#endif

    "ca": "6"#if not (a == 15 and b == 15)
,#endif

    "cb": "7"#if not (a == 15 and b == 15)
,#endif

    "cc": "0"#if not (a == 15 and b == 15)
,#endif

    "cd": "1"#if not (a == 15 and b == 15)
,#endif

    "ce": "2"#if not (a == 15 and b == 15)
,#endif

    "cf": "3"#if not (a == 15 and b == 15)
,#endif

    "d0": "d"#if not (a == 15 and b == 15)
,#endif

    "d1": "c"#if not (a == 15 and b == 15)
,#endif

    "d2": "f"#if not (a == 15 and b == 15)
,#endif

    "d3": "e"#if not (a == 15 and b == 15)
,#endif

    "d4": "9"#if not (a == 15 and b == 15)
,#endif

    "d5": "8"#if not (a == 15 and b == 15)
,#endif

    "d6": "b"#if not (a == 15 and b == 15)
,#endif

    "d7": "a"#if not (a == 15 and b == 15)
,#endif

    "d8": "5"#if not (a == 15 and b == 15)
,#endif

    "d9": "4"#if not (a == 15 and b == 15)
,#endif

    "da": "7"#if not (a == 15 and b == 15)
,#endif

    "db": "6"#if not (a == 15 and b == 15)
,#endif

    "dc": "1"#if not (a == 15 and b == 15)
,#endif

    "dd": "0"#if not (a == 15 and b == 15)
,#endif

    "de": "3"#if not (a == 15 and b == 15)
,#endif

    "df": "2"#if not (a == 15 and b == 15)
,#endif

    "e0": "e"#if not (a == 15 and b == 15)
,#endif

    "e1": "f"#if not (a == 15 and b == 15)
,#endif

    "e2": "c"#if not (a == 15 and b == 15)
,#endif

    "e3": "d"#if not (a == 15 and b == 15)
,#endif

    "e4": "a"#if not (a == 15 and b == 15)
,#endif

    "e5": "b"#if not (a == 15 and b == 15)
,#endif

    "e6": "8"#if not (a == 15 and b == 15)
,#endif

    "e7": "9"#if not (a == 15 and b == 15)
,#endif

    "e8": "6"#if not (a == 15 and b == 15)
,#endif

    "e9": "7"#if not (a == 15 and b == 15)
,#endif

    "ea": "4"#if not (a == 15 and b == 15)
,#endif

    "eb": "5"#if not (a == 15 and b == 15)
,#endif

    "ec": "2"#if not (a == 15 and b == 15)
,#endif

    "ed": "3"#if not (a == 15 and b == 15)
,#endif

    "ee": "0"#if not (a == 15 and b == 15)
,#endif

    "ef": "1"#if not (a == 15 and b == 15)
,#endif

    "f0": "f"#if not (a == 15 and b == 15)
,#endif

    "f1": "e"#if not (a == 15 and b == 15)
,#endif

    "f2": "d"#if not (a == 15 and b == 15)
,#endif

    "f3": "c"#if not (a == 15 and b == 15)
,#endif

    "f4": "b"#if not (a == 15 and b == 15)
,#endif

    "f5": "a"#if not (a == 15 and b == 15)
,#endif

    "f6": "9"#if not (a == 15 and b == 15)
,#endif

    "f7": "8"#if not (a == 15 and b == 15)
,#endif

    "f8": "7"#if not (a == 15 and b == 15)
,#endif

    "f9": "6"#if not (a == 15 and b == 15)
,#endif

    "fa": "5"#if not (a == 15 and b == 15)
,#endif

    "fb": "4"#if not (a == 15 and b == 15)
,#endif

    "fc": "3"#if not (a == 15 and b == 15)
,#endif

    "fd": "2"#if not (a == 15 and b == 15)
,#endif

    "fe": "1"#if not (a == 15 and b == 15)
,#endif

    "ff": "0"#if not (a == 15 and b == 15)
,#endif

}

# === HELPER FUNCTIONS ===

# XOR two 128-bit hex strings (32 hex characters)

# === AES-XTS IMPLEMENTATION ===

# AES-XTS Encrypt for single block (128 bits)
# Key is 32 bytes (64 hex chars, split into K1 and K2)
# Tweak is 16 bytes (32 hex chars)
# Block is 16 bytes (32 hex chars)

# AES-XTS Decrypt for single block (128 bits)

# === TEST HARNESS ===

sub vcl_recv {
    #FASTLY RECV

    declare local var.output STRING;
    declare local var.expected STRING;
    declare local var.match STRING;
    declare local var.full_output STRING;

    log "=== IPCrypt-NDX Test Vectors (draft-denis-ipcrypt) ===";
    log "Testing AES-XTS encryption with official test vectors";
    log "";

    # Test vector 1: IPv4 0.0.0.0
    # Key: 0123456789abcdeffedcba98765432101032547698badcfeefcdab8967452301
    # IP: 0.0.0.0 -> 00000000000000000000ffff00000000
    # Tweak: 21bd1834bc088cd2b4ecbe30b70898d7
    # Expected output (ciphertext only): 82db0d4125fdace61db35b8339f20ee5
    # Expected full output: 21bd1834bc088cd2b4ecbe30b70898d782db0d4125fdace61db35b8339f20ee5

    set req.http.X-Func-aes_xts_encrypt-key = "0123456789abcdeffedcba98765432101032547698badcfeefcdab8967452301";
    set req.http.X-Func-aes_xts_encrypt-tweak = "21bd1834bc088cd2b4ecbe30b70898d7";
    set req.http.X-Func-aes_xts_encrypt-block = "00000000000000000000ffff00000000";
    call aes_xts_encrypt;
    set var.output = req.http.X-Func-aes_xts_encrypt-Return;
    set var.expected = "82db0d4125fdace61db35b8339f20ee5";
    set var.full_output = "21bd1834bc088cd2b4ecbe30b70898d7" + var.output;

    if (var.output == var.expected) {
        set var.match = "PASS";
    } else {
        set var.match = "FAIL";
    }

    log "Test 1: 0.0.0.0";
    log "  Ciphertext: " + var.output;
    log "  Expected:   " + var.expected + " [" + var.match + "]";
    log "  Full:       " + var.full_output;
    log "";

    # Test vector 2: IPv4 255.255.255.255
    # Key: 1032547698badcfeefcdab89674523010123456789abcdeffedcba9876543210
    # IP: 255.255.255.255 -> 00000000000000000000ffffffffffff
    # Tweak: 21bd1834bc088cd2b4ecbe30b70898d7
    # Expected output (ciphertext only): 76c7dbd1ae4802a2dd95ad4f88273535
    # Expected full output: 21bd1834bc088cd2b4ecbe30b70898d776c7dbd1ae4802a2dd95ad4f88273535

    set req.http.X-Func-aes_xts_encrypt-key = "1032547698badcfeefcdab89674523010123456789abcdeffedcba9876543210";
    set req.http.X-Func-aes_xts_encrypt-tweak = "21bd1834bc088cd2b4ecbe30b70898d7";
    set req.http.X-Func-aes_xts_encrypt-block = "00000000000000000000ffffffffffff";
    call aes_xts_encrypt;
    set var.output = req.http.X-Func-aes_xts_encrypt-Return;
    set var.expected = "76c7dbd1ae4802a2dd95ad4f88273535";
    set var.full_output = "21bd1834bc088cd2b4ecbe30b70898d7" + var.output;

    if (var.output == var.expected) {
        set var.match = "PASS";
    } else {
        set var.match = "FAIL";
    }

    log "Test 2: 255.255.255.255";
    log "  Ciphertext: " + var.output;
    log "  Expected:   " + var.expected + " [" + var.match + "]";
    log "  Full:       " + var.full_output;
    log "";

    # Test vector 3: IPv4 192.0.2.1
    # Key: 2b7e151628aed2a6abf7158809cf4f3c3c4fcf098815f7aba6d2ae2816157e2b
    # IP: 192.0.2.1 -> 00000000000000000000ffffc0000201
    # Tweak: 21bd1834bc088cd2b4ecbe30b70898d7
    # Expected output (ciphertext only): 259e85ebaa000667d2437ac7e2208d71
    # Expected full output: 21bd1834bc088cd2b4ecbe30b70898d7259e85ebaa000667d2437ac7e2208d71

    set req.http.X-Func-aes_xts_encrypt-key = "2b7e151628aed2a6abf7158809cf4f3c3c4fcf098815f7aba6d2ae2816157e2b";
    set req.http.X-Func-aes_xts_encrypt-tweak = "21bd1834bc088cd2b4ecbe30b70898d7";
    set req.http.X-Func-aes_xts_encrypt-block = "00000000000000000000ffffc0000201";
    call aes_xts_encrypt;
    set var.output = req.http.X-Func-aes_xts_encrypt-Return;
    set var.expected = "259e85ebaa000667d2437ac7e2208d71";
    set var.full_output = "21bd1834bc088cd2b4ecbe30b70898d7" + var.output;

    if (var.output == var.expected) {
        set var.match = "PASS";
    } else {
        set var.match = "FAIL";
    }

    log "Test 3: 192.0.2.1";
    log "  Ciphertext: " + var.output;
    log "  Expected:   " + var.expected + " [" + var.match + "]";
    log "  Full:       " + var.full_output;
    log "";

    # Additional test vectors from JSON

    # Test vector 4: IPv6 2001:db8:85a3::8a2e:370:7334
    # Key: 0123456789abcdeffedcba98765432101032547698badcfeefcdab8967452301
    # IP: 2001:db8:85a3::8a2e:370:7334 -> 20010db885a3000000008a2e03707334
    # Tweak: 21bd1834bc088cd2b4ecbe30b70898d7
    # Expected (from test vectors): 21bd1834bc088cd2b4ecbe30b70898d7fe8d52464555ef3458e4a6eefe14eb28
    # Ciphertext only: fe8d52464555ef3458e4a6eefe14eb28

    set req.http.X-Func-aes_xts_encrypt-key = "0123456789abcdeffedcba98765432101032547698badcfeefcdab8967452301";
    set req.http.X-Func-aes_xts_encrypt-tweak = "21bd1834bc088cd2b4ecbe30b70898d7";
    set req.http.X-Func-aes_xts_encrypt-block = "20010db885a3000000008a2e03707334";
    call aes_xts_encrypt;
    set var.output = req.http.X-Func-aes_xts_encrypt-Return;
    set var.expected = "fe8d52464555ef3458e4a6eefe14eb28";
    set var.full_output = "21bd1834bc088cd2b4ecbe30b70898d7" + var.output;

    if (var.output == var.expected) {
        set var.match = "PASS";
    } else {
        set var.match = "FAIL";
    }

    log "Test 4: 2001:db8:85a3::8a2e:370:7334";
    log "  Ciphertext: " + var.output;
    log "  Expected:   " + var.expected + " [" + var.match + "]";
    log "  Full:       " + var.full_output;
    log "";

    # Test vector 5: IPv4 192.0.2.1 (different key)
    # Key: 1032547698badcfeefcdab89674523010123456789abcdeffedcba9876543210
    # IP: 192.0.2.1 -> 00000000000000000000ffffc0000201
    # Tweak: 21bd1834bc088cd2b4ecbe30b70898d7
    # Expected (from JSON line 96-101): 21bd1834bc088cd2b4ecbe30b70898d7c9487dffa9292855845d234bd1d72395
    # Ciphertext only: c9487dffa9292855845d234bd1d72395

    set req.http.X-Func-aes_xts_encrypt-key = "1032547698badcfeefcdab89674523010123456789abcdeffedcba9876543210";
    set req.http.X-Func-aes_xts_encrypt-tweak = "21bd1834bc088cd2b4ecbe30b70898d7";
    set req.http.X-Func-aes_xts_encrypt-block = "00000000000000000000ffffc0000201";
    call aes_xts_encrypt;
    set var.output = req.http.X-Func-aes_xts_encrypt-Return;
    set var.expected = "c9487dffa9292855845d234bd1d72395";
    set var.full_output = "21bd1834bc088cd2b4ecbe30b70898d7" + var.output;

    if (var.output == var.expected) {
        set var.match = "PASS";
    } else {
        set var.match = "FAIL";
    }

    log "Test 5: 192.0.2.1 (different key)";
    log "  Ciphertext: " + var.output;
    log "  Expected:   " + var.expected + " [" + var.match + "]";
    log "  Full:       " + var.full_output;
    log "";

    log "=== All test vectors completed ===";

    error 200;
}


// ============================================================================
// GENERATED FUNCTION SUBROUTINES
// ============================================================================

// Function: xor_hex_128
//@recv, hash, hit, miss, pass, fetch, error, deliver, log
sub xor_hex_128 {

  declare local var.a STRING;
  declare local var.b STRING;

  set var.a = req.http.X-Func-xor_hex_128-a;
  set var.b = req.http.X-Func-xor_hex_128-b;

  declare local var.return_value STRING;

  declare local var.result STRING;
  set var.result = "";
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 0, 1) + substr(var.b, 0, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 1, 1) + substr(var.b, 1, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 2, 1) + substr(var.b, 2, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 3, 1) + substr(var.b, 3, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 4, 1) + substr(var.b, 4, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 5, 1) + substr(var.b, 5, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 6, 1) + substr(var.b, 6, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 7, 1) + substr(var.b, 7, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 8, 1) + substr(var.b, 8, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 9, 1) + substr(var.b, 9, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 10, 1) + substr(var.b, 10, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 11, 1) + substr(var.b, 11, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 12, 1) + substr(var.b, 12, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 13, 1) + substr(var.b, 13, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 14, 1) + substr(var.b, 14, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 15, 1) + substr(var.b, 15, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 16, 1) + substr(var.b, 16, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 17, 1) + substr(var.b, 17, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 18, 1) + substr(var.b, 18, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 19, 1) + substr(var.b, 19, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 20, 1) + substr(var.b, 20, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 21, 1) + substr(var.b, 21, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 22, 1) + substr(var.b, 22, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 23, 1) + substr(var.b, 23, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 24, 1) + substr(var.b, 24, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 25, 1) + substr(var.b, 25, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 26, 1) + substr(var.b, 26, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 27, 1) + substr(var.b, 27, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 28, 1) + substr(var.b, 28, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 29, 1) + substr(var.b, 29, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 30, 1) + substr(var.b, 30, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 31, 1) + substr(var.b, 31, 1));
  set var.return_value = var.result;

  set req.http.X-Func-xor_hex_128-Return = var.return_value;
}

// Function: aes_xts_encrypt
//@recv, hash, hit, miss, pass, fetch, error, deliver, log
sub aes_xts_encrypt {

  declare local var.key STRING;
  declare local var.tweak STRING;
  declare local var.block STRING;

  set var.key = req.http.X-Func-aes_xts_encrypt-key;
  set var.tweak = req.http.X-Func-aes_xts_encrypt-tweak;
  set var.block = req.http.X-Func-aes_xts_encrypt-block;

  declare local var.return_value STRING;

  declare local var.k1 STRING;
  set var.k1 = substr(var.key, 0, 32);
  declare local var.k2 STRING;
  set var.k2 = substr(var.key, 32, 32);
  declare local var.zero_iv STRING;
  set var.zero_iv = "00000000000000000000000000000000";

  # Encrypt var.tweak with K2 to get ET
  declare local var.et STRING;
  set var.et = crypto.encrypt_hex(aes128, cbc, nopad, var.k2, var.zero_iv, var.tweak);

  # XOR var.block with ET
  declare local var.block_xor_et STRING;
  set req.http.X-Func-xor_hex_128-a = var.block;
  set req.http.X-Func-xor_hex_128-b = var.et;
  call xor_hex_128;
  set var.block_xor_et = req.http.X-Func-xor_hex_128-Return;

  # Encrypt with K1
  declare local var.encrypted STRING;
  set var.encrypted = crypto.encrypt_hex(aes128, cbc, nopad, var.k1, var.zero_iv, var.block_xor_et);

  # XOR result with ET
  declare local var.ciphertext STRING;
  set req.http.X-Func-xor_hex_128-a = var.encrypted;
  set req.http.X-Func-xor_hex_128-b = var.et;
  call xor_hex_128;
  set var.ciphertext = req.http.X-Func-xor_hex_128-Return;

  set var.return_value = var.ciphertext;

  set req.http.X-Func-aes_xts_encrypt-Return = var.return_value;
}

// Function: aes_xts_decrypt
//@recv, hash, hit, miss, pass, fetch, error, deliver, log
sub aes_xts_decrypt {

  declare local var.key STRING;
  declare local var.tweak STRING;
  declare local var.ciphertext STRING;

  set var.key = req.http.X-Func-aes_xts_decrypt-key;
  set var.tweak = req.http.X-Func-aes_xts_decrypt-tweak;
  set var.ciphertext = req.http.X-Func-aes_xts_decrypt-ciphertext;

  declare local var.return_value STRING;

  declare local var.k1 STRING;
  set var.k1 = substr(var.key, 0, 32);
  declare local var.k2 STRING;
  set var.k2 = substr(var.key, 32, 32);
  declare local var.zero_iv STRING;
  set var.zero_iv = "00000000000000000000000000000000";

  # Encrypt var.tweak with K2 to get ET
  declare local var.et STRING;
  set var.et = crypto.encrypt_hex(aes128, cbc, nopad, var.k2, var.zero_iv, var.tweak);

  # XOR var.ciphertext with ET
  declare local var.cipher_xor_et STRING;
  set req.http.X-Func-xor_hex_128-a = var.ciphertext;
  set req.http.X-Func-xor_hex_128-b = var.et;
  call xor_hex_128;
  set var.cipher_xor_et = req.http.X-Func-xor_hex_128-Return;

  # Decrypt with K1
  declare local var.decrypted STRING;
  set var.decrypted = crypto.decrypt_hex(aes128, cbc, nopad, var.k1, var.zero_iv, var.cipher_xor_et);

  # XOR result with ET
  declare local var.plaintext STRING;
  set req.http.X-Func-xor_hex_128-a = var.decrypted;
  set req.http.X-Func-xor_hex_128-b = var.et;
  call xor_hex_128;
  set var.plaintext = req.http.X-Func-xor_hex_128-Return;

  set var.return_value = var.plaintext;

  set req.http.X-Func-aes_xts_decrypt-Return = var.return_value;
}
