# IPCrypt-PFX
#
# This version uses:
# - #const for repeated constants
# - #inline macros for repetitive code patterns
# - Better organization and less code duplication

backend test_backend {
    .host = "127.0.0.1";
    .port = "8080";
}

# === CONSTANTS ===

# Test keys for test vectors 1-4

# Test keys for test vectors 5-16

# === LOOKUP TABLES ===

# XOR lookup table for hex digits (256 entries: 0x0^0x0 through 0xf^0xf)
table hex_xor STRING {
    "00": "0"#if not (a == 15 and b == 15)
,#endif

    "01": "1"#if not (a == 15 and b == 15)
,#endif

    "02": "2"#if not (a == 15 and b == 15)
,#endif

    "03": "3"#if not (a == 15 and b == 15)
,#endif

    "04": "4"#if not (a == 15 and b == 15)
,#endif

    "05": "5"#if not (a == 15 and b == 15)
,#endif

    "06": "6"#if not (a == 15 and b == 15)
,#endif

    "07": "7"#if not (a == 15 and b == 15)
,#endif

    "08": "8"#if not (a == 15 and b == 15)
,#endif

    "09": "9"#if not (a == 15 and b == 15)
,#endif

    "0a": "a"#if not (a == 15 and b == 15)
,#endif

    "0b": "b"#if not (a == 15 and b == 15)
,#endif

    "0c": "c"#if not (a == 15 and b == 15)
,#endif

    "0d": "d"#if not (a == 15 and b == 15)
,#endif

    "0e": "e"#if not (a == 15 and b == 15)
,#endif

    "0f": "f"#if not (a == 15 and b == 15)
,#endif

    "10": "1"#if not (a == 15 and b == 15)
,#endif

    "11": "0"#if not (a == 15 and b == 15)
,#endif

    "12": "3"#if not (a == 15 and b == 15)
,#endif

    "13": "2"#if not (a == 15 and b == 15)
,#endif

    "14": "5"#if not (a == 15 and b == 15)
,#endif

    "15": "4"#if not (a == 15 and b == 15)
,#endif

    "16": "7"#if not (a == 15 and b == 15)
,#endif

    "17": "6"#if not (a == 15 and b == 15)
,#endif

    "18": "9"#if not (a == 15 and b == 15)
,#endif

    "19": "8"#if not (a == 15 and b == 15)
,#endif

    "1a": "b"#if not (a == 15 and b == 15)
,#endif

    "1b": "a"#if not (a == 15 and b == 15)
,#endif

    "1c": "d"#if not (a == 15 and b == 15)
,#endif

    "1d": "c"#if not (a == 15 and b == 15)
,#endif

    "1e": "f"#if not (a == 15 and b == 15)
,#endif

    "1f": "e"#if not (a == 15 and b == 15)
,#endif

    "20": "2"#if not (a == 15 and b == 15)
,#endif

    "21": "3"#if not (a == 15 and b == 15)
,#endif

    "22": "0"#if not (a == 15 and b == 15)
,#endif

    "23": "1"#if not (a == 15 and b == 15)
,#endif

    "24": "6"#if not (a == 15 and b == 15)
,#endif

    "25": "7"#if not (a == 15 and b == 15)
,#endif

    "26": "4"#if not (a == 15 and b == 15)
,#endif

    "27": "5"#if not (a == 15 and b == 15)
,#endif

    "28": "a"#if not (a == 15 and b == 15)
,#endif

    "29": "b"#if not (a == 15 and b == 15)
,#endif

    "2a": "8"#if not (a == 15 and b == 15)
,#endif

    "2b": "9"#if not (a == 15 and b == 15)
,#endif

    "2c": "e"#if not (a == 15 and b == 15)
,#endif

    "2d": "f"#if not (a == 15 and b == 15)
,#endif

    "2e": "c"#if not (a == 15 and b == 15)
,#endif

    "2f": "d"#if not (a == 15 and b == 15)
,#endif

    "30": "3"#if not (a == 15 and b == 15)
,#endif

    "31": "2"#if not (a == 15 and b == 15)
,#endif

    "32": "1"#if not (a == 15 and b == 15)
,#endif

    "33": "0"#if not (a == 15 and b == 15)
,#endif

    "34": "7"#if not (a == 15 and b == 15)
,#endif

    "35": "6"#if not (a == 15 and b == 15)
,#endif

    "36": "5"#if not (a == 15 and b == 15)
,#endif

    "37": "4"#if not (a == 15 and b == 15)
,#endif

    "38": "b"#if not (a == 15 and b == 15)
,#endif

    "39": "a"#if not (a == 15 and b == 15)
,#endif

    "3a": "9"#if not (a == 15 and b == 15)
,#endif

    "3b": "8"#if not (a == 15 and b == 15)
,#endif

    "3c": "f"#if not (a == 15 and b == 15)
,#endif

    "3d": "e"#if not (a == 15 and b == 15)
,#endif

    "3e": "d"#if not (a == 15 and b == 15)
,#endif

    "3f": "c"#if not (a == 15 and b == 15)
,#endif

    "40": "4"#if not (a == 15 and b == 15)
,#endif

    "41": "5"#if not (a == 15 and b == 15)
,#endif

    "42": "6"#if not (a == 15 and b == 15)
,#endif

    "43": "7"#if not (a == 15 and b == 15)
,#endif

    "44": "0"#if not (a == 15 and b == 15)
,#endif

    "45": "1"#if not (a == 15 and b == 15)
,#endif

    "46": "2"#if not (a == 15 and b == 15)
,#endif

    "47": "3"#if not (a == 15 and b == 15)
,#endif

    "48": "c"#if not (a == 15 and b == 15)
,#endif

    "49": "d"#if not (a == 15 and b == 15)
,#endif

    "4a": "e"#if not (a == 15 and b == 15)
,#endif

    "4b": "f"#if not (a == 15 and b == 15)
,#endif

    "4c": "8"#if not (a == 15 and b == 15)
,#endif

    "4d": "9"#if not (a == 15 and b == 15)
,#endif

    "4e": "a"#if not (a == 15 and b == 15)
,#endif

    "4f": "b"#if not (a == 15 and b == 15)
,#endif

    "50": "5"#if not (a == 15 and b == 15)
,#endif

    "51": "4"#if not (a == 15 and b == 15)
,#endif

    "52": "7"#if not (a == 15 and b == 15)
,#endif

    "53": "6"#if not (a == 15 and b == 15)
,#endif

    "54": "1"#if not (a == 15 and b == 15)
,#endif

    "55": "0"#if not (a == 15 and b == 15)
,#endif

    "56": "3"#if not (a == 15 and b == 15)
,#endif

    "57": "2"#if not (a == 15 and b == 15)
,#endif

    "58": "d"#if not (a == 15 and b == 15)
,#endif

    "59": "c"#if not (a == 15 and b == 15)
,#endif

    "5a": "f"#if not (a == 15 and b == 15)
,#endif

    "5b": "e"#if not (a == 15 and b == 15)
,#endif

    "5c": "9"#if not (a == 15 and b == 15)
,#endif

    "5d": "8"#if not (a == 15 and b == 15)
,#endif

    "5e": "b"#if not (a == 15 and b == 15)
,#endif

    "5f": "a"#if not (a == 15 and b == 15)
,#endif

    "60": "6"#if not (a == 15 and b == 15)
,#endif

    "61": "7"#if not (a == 15 and b == 15)
,#endif

    "62": "4"#if not (a == 15 and b == 15)
,#endif

    "63": "5"#if not (a == 15 and b == 15)
,#endif

    "64": "2"#if not (a == 15 and b == 15)
,#endif

    "65": "3"#if not (a == 15 and b == 15)
,#endif

    "66": "0"#if not (a == 15 and b == 15)
,#endif

    "67": "1"#if not (a == 15 and b == 15)
,#endif

    "68": "e"#if not (a == 15 and b == 15)
,#endif

    "69": "f"#if not (a == 15 and b == 15)
,#endif

    "6a": "c"#if not (a == 15 and b == 15)
,#endif

    "6b": "d"#if not (a == 15 and b == 15)
,#endif

    "6c": "a"#if not (a == 15 and b == 15)
,#endif

    "6d": "b"#if not (a == 15 and b == 15)
,#endif

    "6e": "8"#if not (a == 15 and b == 15)
,#endif

    "6f": "9"#if not (a == 15 and b == 15)
,#endif

    "70": "7"#if not (a == 15 and b == 15)
,#endif

    "71": "6"#if not (a == 15 and b == 15)
,#endif

    "72": "5"#if not (a == 15 and b == 15)
,#endif

    "73": "4"#if not (a == 15 and b == 15)
,#endif

    "74": "3"#if not (a == 15 and b == 15)
,#endif

    "75": "2"#if not (a == 15 and b == 15)
,#endif

    "76": "1"#if not (a == 15 and b == 15)
,#endif

    "77": "0"#if not (a == 15 and b == 15)
,#endif

    "78": "f"#if not (a == 15 and b == 15)
,#endif

    "79": "e"#if not (a == 15 and b == 15)
,#endif

    "7a": "d"#if not (a == 15 and b == 15)
,#endif

    "7b": "c"#if not (a == 15 and b == 15)
,#endif

    "7c": "b"#if not (a == 15 and b == 15)
,#endif

    "7d": "a"#if not (a == 15 and b == 15)
,#endif

    "7e": "9"#if not (a == 15 and b == 15)
,#endif

    "7f": "8"#if not (a == 15 and b == 15)
,#endif

    "80": "8"#if not (a == 15 and b == 15)
,#endif

    "81": "9"#if not (a == 15 and b == 15)
,#endif

    "82": "a"#if not (a == 15 and b == 15)
,#endif

    "83": "b"#if not (a == 15 and b == 15)
,#endif

    "84": "c"#if not (a == 15 and b == 15)
,#endif

    "85": "d"#if not (a == 15 and b == 15)
,#endif

    "86": "e"#if not (a == 15 and b == 15)
,#endif

    "87": "f"#if not (a == 15 and b == 15)
,#endif

    "88": "0"#if not (a == 15 and b == 15)
,#endif

    "89": "1"#if not (a == 15 and b == 15)
,#endif

    "8a": "2"#if not (a == 15 and b == 15)
,#endif

    "8b": "3"#if not (a == 15 and b == 15)
,#endif

    "8c": "4"#if not (a == 15 and b == 15)
,#endif

    "8d": "5"#if not (a == 15 and b == 15)
,#endif

    "8e": "6"#if not (a == 15 and b == 15)
,#endif

    "8f": "7"#if not (a == 15 and b == 15)
,#endif

    "90": "9"#if not (a == 15 and b == 15)
,#endif

    "91": "8"#if not (a == 15 and b == 15)
,#endif

    "92": "b"#if not (a == 15 and b == 15)
,#endif

    "93": "a"#if not (a == 15 and b == 15)
,#endif

    "94": "d"#if not (a == 15 and b == 15)
,#endif

    "95": "c"#if not (a == 15 and b == 15)
,#endif

    "96": "f"#if not (a == 15 and b == 15)
,#endif

    "97": "e"#if not (a == 15 and b == 15)
,#endif

    "98": "1"#if not (a == 15 and b == 15)
,#endif

    "99": "0"#if not (a == 15 and b == 15)
,#endif

    "9a": "3"#if not (a == 15 and b == 15)
,#endif

    "9b": "2"#if not (a == 15 and b == 15)
,#endif

    "9c": "5"#if not (a == 15 and b == 15)
,#endif

    "9d": "4"#if not (a == 15 and b == 15)
,#endif

    "9e": "7"#if not (a == 15 and b == 15)
,#endif

    "9f": "6"#if not (a == 15 and b == 15)
,#endif

    "a0": "a"#if not (a == 15 and b == 15)
,#endif

    "a1": "b"#if not (a == 15 and b == 15)
,#endif

    "a2": "8"#if not (a == 15 and b == 15)
,#endif

    "a3": "9"#if not (a == 15 and b == 15)
,#endif

    "a4": "e"#if not (a == 15 and b == 15)
,#endif

    "a5": "f"#if not (a == 15 and b == 15)
,#endif

    "a6": "c"#if not (a == 15 and b == 15)
,#endif

    "a7": "d"#if not (a == 15 and b == 15)
,#endif

    "a8": "2"#if not (a == 15 and b == 15)
,#endif

    "a9": "3"#if not (a == 15 and b == 15)
,#endif

    "aa": "0"#if not (a == 15 and b == 15)
,#endif

    "ab": "1"#if not (a == 15 and b == 15)
,#endif

    "ac": "6"#if not (a == 15 and b == 15)
,#endif

    "ad": "7"#if not (a == 15 and b == 15)
,#endif

    "ae": "4"#if not (a == 15 and b == 15)
,#endif

    "af": "5"#if not (a == 15 and b == 15)
,#endif

    "b0": "b"#if not (a == 15 and b == 15)
,#endif

    "b1": "a"#if not (a == 15 and b == 15)
,#endif

    "b2": "9"#if not (a == 15 and b == 15)
,#endif

    "b3": "8"#if not (a == 15 and b == 15)
,#endif

    "b4": "f"#if not (a == 15 and b == 15)
,#endif

    "b5": "e"#if not (a == 15 and b == 15)
,#endif

    "b6": "d"#if not (a == 15 and b == 15)
,#endif

    "b7": "c"#if not (a == 15 and b == 15)
,#endif

    "b8": "3"#if not (a == 15 and b == 15)
,#endif

    "b9": "2"#if not (a == 15 and b == 15)
,#endif

    "ba": "1"#if not (a == 15 and b == 15)
,#endif

    "bb": "0"#if not (a == 15 and b == 15)
,#endif

    "bc": "7"#if not (a == 15 and b == 15)
,#endif

    "bd": "6"#if not (a == 15 and b == 15)
,#endif

    "be": "5"#if not (a == 15 and b == 15)
,#endif

    "bf": "4"#if not (a == 15 and b == 15)
,#endif

    "c0": "c"#if not (a == 15 and b == 15)
,#endif

    "c1": "d"#if not (a == 15 and b == 15)
,#endif

    "c2": "e"#if not (a == 15 and b == 15)
,#endif

    "c3": "f"#if not (a == 15 and b == 15)
,#endif

    "c4": "8"#if not (a == 15 and b == 15)
,#endif

    "c5": "9"#if not (a == 15 and b == 15)
,#endif

    "c6": "a"#if not (a == 15 and b == 15)
,#endif

    "c7": "b"#if not (a == 15 and b == 15)
,#endif

    "c8": "4"#if not (a == 15 and b == 15)
,#endif

    "c9": "5"#if not (a == 15 and b == 15)
,#endif

    "ca": "6"#if not (a == 15 and b == 15)
,#endif

    "cb": "7"#if not (a == 15 and b == 15)
,#endif

    "cc": "0"#if not (a == 15 and b == 15)
,#endif

    "cd": "1"#if not (a == 15 and b == 15)
,#endif

    "ce": "2"#if not (a == 15 and b == 15)
,#endif

    "cf": "3"#if not (a == 15 and b == 15)
,#endif

    "d0": "d"#if not (a == 15 and b == 15)
,#endif

    "d1": "c"#if not (a == 15 and b == 15)
,#endif

    "d2": "f"#if not (a == 15 and b == 15)
,#endif

    "d3": "e"#if not (a == 15 and b == 15)
,#endif

    "d4": "9"#if not (a == 15 and b == 15)
,#endif

    "d5": "8"#if not (a == 15 and b == 15)
,#endif

    "d6": "b"#if not (a == 15 and b == 15)
,#endif

    "d7": "a"#if not (a == 15 and b == 15)
,#endif

    "d8": "5"#if not (a == 15 and b == 15)
,#endif

    "d9": "4"#if not (a == 15 and b == 15)
,#endif

    "da": "7"#if not (a == 15 and b == 15)
,#endif

    "db": "6"#if not (a == 15 and b == 15)
,#endif

    "dc": "1"#if not (a == 15 and b == 15)
,#endif

    "dd": "0"#if not (a == 15 and b == 15)
,#endif

    "de": "3"#if not (a == 15 and b == 15)
,#endif

    "df": "2"#if not (a == 15 and b == 15)
,#endif

    "e0": "e"#if not (a == 15 and b == 15)
,#endif

    "e1": "f"#if not (a == 15 and b == 15)
,#endif

    "e2": "c"#if not (a == 15 and b == 15)
,#endif

    "e3": "d"#if not (a == 15 and b == 15)
,#endif

    "e4": "a"#if not (a == 15 and b == 15)
,#endif

    "e5": "b"#if not (a == 15 and b == 15)
,#endif

    "e6": "8"#if not (a == 15 and b == 15)
,#endif

    "e7": "9"#if not (a == 15 and b == 15)
,#endif

    "e8": "6"#if not (a == 15 and b == 15)
,#endif

    "e9": "7"#if not (a == 15 and b == 15)
,#endif

    "ea": "4"#if not (a == 15 and b == 15)
,#endif

    "eb": "5"#if not (a == 15 and b == 15)
,#endif

    "ec": "2"#if not (a == 15 and b == 15)
,#endif

    "ed": "3"#if not (a == 15 and b == 15)
,#endif

    "ee": "0"#if not (a == 15 and b == 15)
,#endif

    "ef": "1"#if not (a == 15 and b == 15)
,#endif

    "f0": "f"#if not (a == 15 and b == 15)
,#endif

    "f1": "e"#if not (a == 15 and b == 15)
,#endif

    "f2": "d"#if not (a == 15 and b == 15)
,#endif

    "f3": "c"#if not (a == 15 and b == 15)
,#endif

    "f4": "b"#if not (a == 15 and b == 15)
,#endif

    "f5": "a"#if not (a == 15 and b == 15)
,#endif

    "f6": "9"#if not (a == 15 and b == 15)
,#endif

    "f7": "8"#if not (a == 15 and b == 15)
,#endif

    "f8": "7"#if not (a == 15 and b == 15)
,#endif

    "f9": "6"#if not (a == 15 and b == 15)
,#endif

    "fa": "5"#if not (a == 15 and b == 15)
,#endif

    "fb": "4"#if not (a == 15 and b == 15)
,#endif

    "fc": "3"#if not (a == 15 and b == 15)
,#endif

    "fd": "2"#if not (a == 15 and b == 15)
,#endif

    "fe": "1"#if not (a == 15 and b == 15)
,#endif

    "ff": "0"#if not (a == 15 and b == 15)
,#endif

}

# Hex digit to 4-bit binary (16 entries)
table hex_to_bin4 STRING {
    "0": "0000"#if i < 15
,#endif

    "1": "0001"#if i < 15
,#endif

    "2": "0010"#if i < 15
,#endif

    "3": "0011"#if i < 15
,#endif

    "4": "0100"#if i < 15
,#endif

    "5": "0101"#if i < 15
,#endif

    "6": "0110"#if i < 15
,#endif

    "7": "0111"#if i < 15
,#endif

    "8": "1000"#if i < 15
,#endif

    "9": "1001"#if i < 15
,#endif

    "a": "1010"#if i < 15
,#endif

    "b": "1011"#if i < 15
,#endif

    "c": "1100"#if i < 15
,#endif

    "d": "1101"#if i < 15
,#endif

    "e": "1110"#if i < 15
,#endif

    "f": "1111"#if i < 15
,#endif

}

# 4-bit binary to hex digit (16 entries)
table bin4_to_hex STRING {
    "0000": "0"#if i < 15
,#endif

    "0001": "1"#if i < 15
,#endif

    "0010": "2"#if i < 15
,#endif

    "0011": "3"#if i < 15
,#endif

    "0100": "4"#if i < 15
,#endif

    "0101": "5"#if i < 15
,#endif

    "0110": "6"#if i < 15
,#endif

    "0111": "7"#if i < 15
,#endif

    "1000": "8"#if i < 15
,#endif

    "1001": "9"#if i < 15
,#endif

    "1010": "a"#if i < 15
,#endif

    "1011": "b"#if i < 15
,#endif

    "1100": "c"#if i < 15
,#endif

    "1101": "d"#if i < 15
,#endif

    "1110": "e"#if i < 15
,#endif

    "1111": "f"#if i < 15
,#endif

}

# 8-bit binary to decimal string (256 entries)
table bin8_to_dec STRING {
    "00000000": "0"#if i < 255
,#endif

    "00000001": "1"#if i < 255
,#endif

    "00000010": "2"#if i < 255
,#endif

    "00000011": "3"#if i < 255
,#endif

    "00000100": "4"#if i < 255
,#endif

    "00000101": "5"#if i < 255
,#endif

    "00000110": "6"#if i < 255
,#endif

    "00000111": "7"#if i < 255
,#endif

    "00001000": "8"#if i < 255
,#endif

    "00001001": "9"#if i < 255
,#endif

    "00001010": "10"#if i < 255
,#endif

    "00001011": "11"#if i < 255
,#endif

    "00001100": "12"#if i < 255
,#endif

    "00001101": "13"#if i < 255
,#endif

    "00001110": "14"#if i < 255
,#endif

    "00001111": "15"#if i < 255
,#endif

    "00010000": "16"#if i < 255
,#endif

    "00010001": "17"#if i < 255
,#endif

    "00010010": "18"#if i < 255
,#endif

    "00010011": "19"#if i < 255
,#endif

    "00010100": "20"#if i < 255
,#endif

    "00010101": "21"#if i < 255
,#endif

    "00010110": "22"#if i < 255
,#endif

    "00010111": "23"#if i < 255
,#endif

    "00011000": "24"#if i < 255
,#endif

    "00011001": "25"#if i < 255
,#endif

    "00011010": "26"#if i < 255
,#endif

    "00011011": "27"#if i < 255
,#endif

    "00011100": "28"#if i < 255
,#endif

    "00011101": "29"#if i < 255
,#endif

    "00011110": "30"#if i < 255
,#endif

    "00011111": "31"#if i < 255
,#endif

    "00100000": "32"#if i < 255
,#endif

    "00100001": "33"#if i < 255
,#endif

    "00100010": "34"#if i < 255
,#endif

    "00100011": "35"#if i < 255
,#endif

    "00100100": "36"#if i < 255
,#endif

    "00100101": "37"#if i < 255
,#endif

    "00100110": "38"#if i < 255
,#endif

    "00100111": "39"#if i < 255
,#endif

    "00101000": "40"#if i < 255
,#endif

    "00101001": "41"#if i < 255
,#endif

    "00101010": "42"#if i < 255
,#endif

    "00101011": "43"#if i < 255
,#endif

    "00101100": "44"#if i < 255
,#endif

    "00101101": "45"#if i < 255
,#endif

    "00101110": "46"#if i < 255
,#endif

    "00101111": "47"#if i < 255
,#endif

    "00110000": "48"#if i < 255
,#endif

    "00110001": "49"#if i < 255
,#endif

    "00110010": "50"#if i < 255
,#endif

    "00110011": "51"#if i < 255
,#endif

    "00110100": "52"#if i < 255
,#endif

    "00110101": "53"#if i < 255
,#endif

    "00110110": "54"#if i < 255
,#endif

    "00110111": "55"#if i < 255
,#endif

    "00111000": "56"#if i < 255
,#endif

    "00111001": "57"#if i < 255
,#endif

    "00111010": "58"#if i < 255
,#endif

    "00111011": "59"#if i < 255
,#endif

    "00111100": "60"#if i < 255
,#endif

    "00111101": "61"#if i < 255
,#endif

    "00111110": "62"#if i < 255
,#endif

    "00111111": "63"#if i < 255
,#endif

    "01000000": "64"#if i < 255
,#endif

    "01000001": "65"#if i < 255
,#endif

    "01000010": "66"#if i < 255
,#endif

    "01000011": "67"#if i < 255
,#endif

    "01000100": "68"#if i < 255
,#endif

    "01000101": "69"#if i < 255
,#endif

    "01000110": "70"#if i < 255
,#endif

    "01000111": "71"#if i < 255
,#endif

    "01001000": "72"#if i < 255
,#endif

    "01001001": "73"#if i < 255
,#endif

    "01001010": "74"#if i < 255
,#endif

    "01001011": "75"#if i < 255
,#endif

    "01001100": "76"#if i < 255
,#endif

    "01001101": "77"#if i < 255
,#endif

    "01001110": "78"#if i < 255
,#endif

    "01001111": "79"#if i < 255
,#endif

    "01010000": "80"#if i < 255
,#endif

    "01010001": "81"#if i < 255
,#endif

    "01010010": "82"#if i < 255
,#endif

    "01010011": "83"#if i < 255
,#endif

    "01010100": "84"#if i < 255
,#endif

    "01010101": "85"#if i < 255
,#endif

    "01010110": "86"#if i < 255
,#endif

    "01010111": "87"#if i < 255
,#endif

    "01011000": "88"#if i < 255
,#endif

    "01011001": "89"#if i < 255
,#endif

    "01011010": "90"#if i < 255
,#endif

    "01011011": "91"#if i < 255
,#endif

    "01011100": "92"#if i < 255
,#endif

    "01011101": "93"#if i < 255
,#endif

    "01011110": "94"#if i < 255
,#endif

    "01011111": "95"#if i < 255
,#endif

    "01100000": "96"#if i < 255
,#endif

    "01100001": "97"#if i < 255
,#endif

    "01100010": "98"#if i < 255
,#endif

    "01100011": "99"#if i < 255
,#endif

    "01100100": "100"#if i < 255
,#endif

    "01100101": "101"#if i < 255
,#endif

    "01100110": "102"#if i < 255
,#endif

    "01100111": "103"#if i < 255
,#endif

    "01101000": "104"#if i < 255
,#endif

    "01101001": "105"#if i < 255
,#endif

    "01101010": "106"#if i < 255
,#endif

    "01101011": "107"#if i < 255
,#endif

    "01101100": "108"#if i < 255
,#endif

    "01101101": "109"#if i < 255
,#endif

    "01101110": "110"#if i < 255
,#endif

    "01101111": "111"#if i < 255
,#endif

    "01110000": "112"#if i < 255
,#endif

    "01110001": "113"#if i < 255
,#endif

    "01110010": "114"#if i < 255
,#endif

    "01110011": "115"#if i < 255
,#endif

    "01110100": "116"#if i < 255
,#endif

    "01110101": "117"#if i < 255
,#endif

    "01110110": "118"#if i < 255
,#endif

    "01110111": "119"#if i < 255
,#endif

    "01111000": "120"#if i < 255
,#endif

    "01111001": "121"#if i < 255
,#endif

    "01111010": "122"#if i < 255
,#endif

    "01111011": "123"#if i < 255
,#endif

    "01111100": "124"#if i < 255
,#endif

    "01111101": "125"#if i < 255
,#endif

    "01111110": "126"#if i < 255
,#endif

    "01111111": "127"#if i < 255
,#endif

    "10000000": "128"#if i < 255
,#endif

    "10000001": "129"#if i < 255
,#endif

    "10000010": "130"#if i < 255
,#endif

    "10000011": "131"#if i < 255
,#endif

    "10000100": "132"#if i < 255
,#endif

    "10000101": "133"#if i < 255
,#endif

    "10000110": "134"#if i < 255
,#endif

    "10000111": "135"#if i < 255
,#endif

    "10001000": "136"#if i < 255
,#endif

    "10001001": "137"#if i < 255
,#endif

    "10001010": "138"#if i < 255
,#endif

    "10001011": "139"#if i < 255
,#endif

    "10001100": "140"#if i < 255
,#endif

    "10001101": "141"#if i < 255
,#endif

    "10001110": "142"#if i < 255
,#endif

    "10001111": "143"#if i < 255
,#endif

    "10010000": "144"#if i < 255
,#endif

    "10010001": "145"#if i < 255
,#endif

    "10010010": "146"#if i < 255
,#endif

    "10010011": "147"#if i < 255
,#endif

    "10010100": "148"#if i < 255
,#endif

    "10010101": "149"#if i < 255
,#endif

    "10010110": "150"#if i < 255
,#endif

    "10010111": "151"#if i < 255
,#endif

    "10011000": "152"#if i < 255
,#endif

    "10011001": "153"#if i < 255
,#endif

    "10011010": "154"#if i < 255
,#endif

    "10011011": "155"#if i < 255
,#endif

    "10011100": "156"#if i < 255
,#endif

    "10011101": "157"#if i < 255
,#endif

    "10011110": "158"#if i < 255
,#endif

    "10011111": "159"#if i < 255
,#endif

    "10100000": "160"#if i < 255
,#endif

    "10100001": "161"#if i < 255
,#endif

    "10100010": "162"#if i < 255
,#endif

    "10100011": "163"#if i < 255
,#endif

    "10100100": "164"#if i < 255
,#endif

    "10100101": "165"#if i < 255
,#endif

    "10100110": "166"#if i < 255
,#endif

    "10100111": "167"#if i < 255
,#endif

    "10101000": "168"#if i < 255
,#endif

    "10101001": "169"#if i < 255
,#endif

    "10101010": "170"#if i < 255
,#endif

    "10101011": "171"#if i < 255
,#endif

    "10101100": "172"#if i < 255
,#endif

    "10101101": "173"#if i < 255
,#endif

    "10101110": "174"#if i < 255
,#endif

    "10101111": "175"#if i < 255
,#endif

    "10110000": "176"#if i < 255
,#endif

    "10110001": "177"#if i < 255
,#endif

    "10110010": "178"#if i < 255
,#endif

    "10110011": "179"#if i < 255
,#endif

    "10110100": "180"#if i < 255
,#endif

    "10110101": "181"#if i < 255
,#endif

    "10110110": "182"#if i < 255
,#endif

    "10110111": "183"#if i < 255
,#endif

    "10111000": "184"#if i < 255
,#endif

    "10111001": "185"#if i < 255
,#endif

    "10111010": "186"#if i < 255
,#endif

    "10111011": "187"#if i < 255
,#endif

    "10111100": "188"#if i < 255
,#endif

    "10111101": "189"#if i < 255
,#endif

    "10111110": "190"#if i < 255
,#endif

    "10111111": "191"#if i < 255
,#endif

    "11000000": "192"#if i < 255
,#endif

    "11000001": "193"#if i < 255
,#endif

    "11000010": "194"#if i < 255
,#endif

    "11000011": "195"#if i < 255
,#endif

    "11000100": "196"#if i < 255
,#endif

    "11000101": "197"#if i < 255
,#endif

    "11000110": "198"#if i < 255
,#endif

    "11000111": "199"#if i < 255
,#endif

    "11001000": "200"#if i < 255
,#endif

    "11001001": "201"#if i < 255
,#endif

    "11001010": "202"#if i < 255
,#endif

    "11001011": "203"#if i < 255
,#endif

    "11001100": "204"#if i < 255
,#endif

    "11001101": "205"#if i < 255
,#endif

    "11001110": "206"#if i < 255
,#endif

    "11001111": "207"#if i < 255
,#endif

    "11010000": "208"#if i < 255
,#endif

    "11010001": "209"#if i < 255
,#endif

    "11010010": "210"#if i < 255
,#endif

    "11010011": "211"#if i < 255
,#endif

    "11010100": "212"#if i < 255
,#endif

    "11010101": "213"#if i < 255
,#endif

    "11010110": "214"#if i < 255
,#endif

    "11010111": "215"#if i < 255
,#endif

    "11011000": "216"#if i < 255
,#endif

    "11011001": "217"#if i < 255
,#endif

    "11011010": "218"#if i < 255
,#endif

    "11011011": "219"#if i < 255
,#endif

    "11011100": "220"#if i < 255
,#endif

    "11011101": "221"#if i < 255
,#endif

    "11011110": "222"#if i < 255
,#endif

    "11011111": "223"#if i < 255
,#endif

    "11100000": "224"#if i < 255
,#endif

    "11100001": "225"#if i < 255
,#endif

    "11100010": "226"#if i < 255
,#endif

    "11100011": "227"#if i < 255
,#endif

    "11100100": "228"#if i < 255
,#endif

    "11100101": "229"#if i < 255
,#endif

    "11100110": "230"#if i < 255
,#endif

    "11100111": "231"#if i < 255
,#endif

    "11101000": "232"#if i < 255
,#endif

    "11101001": "233"#if i < 255
,#endif

    "11101010": "234"#if i < 255
,#endif

    "11101011": "235"#if i < 255
,#endif

    "11101100": "236"#if i < 255
,#endif

    "11101101": "237"#if i < 255
,#endif

    "11101110": "238"#if i < 255
,#endif

    "11101111": "239"#if i < 255
,#endif

    "11110000": "240"#if i < 255
,#endif

    "11110001": "241"#if i < 255
,#endif

    "11110010": "242"#if i < 255
,#endif

    "11110011": "243"#if i < 255
,#endif

    "11110100": "244"#if i < 255
,#endif

    "11110101": "245"#if i < 255
,#endif

    "11110110": "246"#if i < 255
,#endif

    "11110111": "247"#if i < 255
,#endif

    "11111000": "248"#if i < 255
,#endif

    "11111001": "249"#if i < 255
,#endif

    "11111010": "250"#if i < 255
,#endif

    "11111011": "251"#if i < 255
,#endif

    "11111100": "252"#if i < 255
,#endif

    "11111101": "253"#if i < 255
,#endif

    "11111110": "254"#if i < 255
,#endif

    "11111111": "255"#if i < 255
,#endif

}

# === INLINE MACROS ===

# Extract LSB from hex string and check if even (returns 0) or odd (returns 1)

# === HELPER FUNCTIONS ===

# XOR two 128-bit hex strings

# AES-128 ECB (using CBC with zero IV)

# Convert hex to binary (128-bit)

# Convert binary to hex (128-bit)

# Shift binary left one bit and append bit

# Convert 32-bit binary to IPv4 address string

# Convert 128-bit binary to IPv6 address string

# === MAIN ENCRYPTION FUNCTION ===

# Encrypt IP address using ipcrypt-pfx

# === TEST HARNESS ===

sub vcl_recv {
    #FASTLY RECV

    declare local var.input_ip IP;
    declare local var.output_ip IP;
    declare local var.expected STRING;

    log "=== IPCrypt-PFX Test Vectors (draft-denis-ipcrypt) ===";
    log "=== Testing all 16 official test vectors ===";
    log "";

    # Test vector 1: IPv4 0.0.0.0
    set var.input_ip = std.str2ip("0.0.0.0", "0.0.0.0");
    set req.http.X-Func-ipcrypt_pfx_encrypt-input_ip = var.input_ip;
    set req.http.X-Func-ipcrypt_pfx_encrypt-key1 = "0123456789abcdeffedcba9876543210";
    set req.http.X-Func-ipcrypt_pfx_encrypt-key2 = "1032547698badcfeefcdab8967452301";
    call ipcrypt_pfx_encrypt;
    set var.output_ip = req.http.X-Func-ipcrypt_pfx_encrypt-Return;
    set var.expected = "151.82.155.134";
    log "Test 1: 0.0.0.0 -> " + std.ip2str(var.output_ip) + " (expected: " + var.expected + ")";

    # Test vector 2: IPv4 255.255.255.255
    set var.input_ip = std.str2ip("255.255.255.255", "0.0.0.0");
    set req.http.X-Func-ipcrypt_pfx_encrypt-input_ip = var.input_ip;
    set req.http.X-Func-ipcrypt_pfx_encrypt-key1 = "0123456789abcdeffedcba9876543210";
    set req.http.X-Func-ipcrypt_pfx_encrypt-key2 = "1032547698badcfeefcdab8967452301";
    call ipcrypt_pfx_encrypt;
    set var.output_ip = req.http.X-Func-ipcrypt_pfx_encrypt-Return;
    set var.expected = "94.185.169.89";
    log "Test 2: 255.255.255.255 -> " + std.ip2str(var.output_ip) + " (expected: " + var.expected + ")";

    # Test vector 3: IPv4 192.0.2.1
    set var.input_ip = std.str2ip("192.0.2.1", "0.0.0.0");
    set req.http.X-Func-ipcrypt_pfx_encrypt-input_ip = var.input_ip;
    set req.http.X-Func-ipcrypt_pfx_encrypt-key1 = "0123456789abcdeffedcba9876543210";
    set req.http.X-Func-ipcrypt_pfx_encrypt-key2 = "1032547698badcfeefcdab8967452301";
    call ipcrypt_pfx_encrypt;
    set var.output_ip = req.http.X-Func-ipcrypt_pfx_encrypt-Return;
    set var.expected = "100.115.72.131";
    log "Test 3: 192.0.2.1 -> " + std.ip2str(var.output_ip) + " (expected: " + var.expected + ")";

    # Test vector 4: IPv6 2001:db8::1
    set var.input_ip = std.str2ip("2001:db8::1", "::");
    set req.http.X-Func-ipcrypt_pfx_encrypt-input_ip = var.input_ip;
    set req.http.X-Func-ipcrypt_pfx_encrypt-key1 = "0123456789abcdeffedcba9876543210";
    set req.http.X-Func-ipcrypt_pfx_encrypt-key2 = "1032547698badcfeefcdab8967452301";
    call ipcrypt_pfx_encrypt;
    set var.output_ip = req.http.X-Func-ipcrypt_pfx_encrypt-Return;
    set var.expected = "c180:5dd4:2587:3524:30ab:fa65:6ab6:f88";
    log "Test 4: 2001:db8::1 -> " + std.ip2str(var.output_ip) + " (expected: " + var.expected + ")";

    # Test vector 5: IPv4 10.0.0.47
    set var.input_ip = std.str2ip("10.0.0.47", "0.0.0.0");
    set req.http.X-Func-ipcrypt_pfx_encrypt-input_ip = var.input_ip;
    set req.http.X-Func-ipcrypt_pfx_encrypt-key1 = "2b7e151628aed2a6abf7158809cf4f3c";
    set req.http.X-Func-ipcrypt_pfx_encrypt-key2 = "a9f5ba40db214c3798f2e1c23456789a";
    call ipcrypt_pfx_encrypt;
    set var.output_ip = req.http.X-Func-ipcrypt_pfx_encrypt-Return;
    set var.expected = "19.214.210.244";
    log "Test 5: 10.0.0.47 -> " + std.ip2str(var.output_ip) + " (expected: " + var.expected + ")";

    # Test vector 6: IPv4 10.0.0.129
    set var.input_ip = std.str2ip("10.0.0.129", "0.0.0.0");
    set req.http.X-Func-ipcrypt_pfx_encrypt-input_ip = var.input_ip;
    set req.http.X-Func-ipcrypt_pfx_encrypt-key1 = "2b7e151628aed2a6abf7158809cf4f3c";
    set req.http.X-Func-ipcrypt_pfx_encrypt-key2 = "a9f5ba40db214c3798f2e1c23456789a";
    call ipcrypt_pfx_encrypt;
    set var.output_ip = req.http.X-Func-ipcrypt_pfx_encrypt-Return;
    set var.expected = "19.214.210.80";
    log "Test 6: 10.0.0.129 -> " + std.ip2str(var.output_ip) + " (expected: " + var.expected + ")";

    # Test vector 7: IPv4 10.0.0.234
    set var.input_ip = std.str2ip("10.0.0.234", "0.0.0.0");
    set req.http.X-Func-ipcrypt_pfx_encrypt-input_ip = var.input_ip;
    set req.http.X-Func-ipcrypt_pfx_encrypt-key1 = "2b7e151628aed2a6abf7158809cf4f3c";
    set req.http.X-Func-ipcrypt_pfx_encrypt-key2 = "a9f5ba40db214c3798f2e1c23456789a";
    call ipcrypt_pfx_encrypt;
    set var.output_ip = req.http.X-Func-ipcrypt_pfx_encrypt-Return;
    set var.expected = "19.214.210.30";
    log "Test 7: 10.0.0.234 -> " + std.ip2str(var.output_ip) + " (expected: " + var.expected + ")";

    # Test vector 8: IPv4 172.16.5.193
    set var.input_ip = std.str2ip("172.16.5.193", "0.0.0.0");
    set req.http.X-Func-ipcrypt_pfx_encrypt-input_ip = var.input_ip;
    set req.http.X-Func-ipcrypt_pfx_encrypt-key1 = "2b7e151628aed2a6abf7158809cf4f3c";
    set req.http.X-Func-ipcrypt_pfx_encrypt-key2 = "a9f5ba40db214c3798f2e1c23456789a";
    call ipcrypt_pfx_encrypt;
    set var.output_ip = req.http.X-Func-ipcrypt_pfx_encrypt-Return;
    set var.expected = "210.78.229.136";
    log "Test 8: 172.16.5.193 -> " + std.ip2str(var.output_ip) + " (expected: " + var.expected + ")";

    # Test vector 9: IPv4 172.16.97.42
    set var.input_ip = std.str2ip("172.16.97.42", "0.0.0.0");
    set req.http.X-Func-ipcrypt_pfx_encrypt-input_ip = var.input_ip;
    set req.http.X-Func-ipcrypt_pfx_encrypt-key1 = "2b7e151628aed2a6abf7158809cf4f3c";
    set req.http.X-Func-ipcrypt_pfx_encrypt-key2 = "a9f5ba40db214c3798f2e1c23456789a";
    call ipcrypt_pfx_encrypt;
    set var.output_ip = req.http.X-Func-ipcrypt_pfx_encrypt-Return;
    set var.expected = "210.78.179.241";
    log "Test 9: 172.16.97.42 -> " + std.ip2str(var.output_ip) + " (expected: " + var.expected + ")";

    # Test vector 10: IPv4 172.16.248.177
    set var.input_ip = std.str2ip("172.16.248.177", "0.0.0.0");
    set req.http.X-Func-ipcrypt_pfx_encrypt-input_ip = var.input_ip;
    set req.http.X-Func-ipcrypt_pfx_encrypt-key1 = "2b7e151628aed2a6abf7158809cf4f3c";
    set req.http.X-Func-ipcrypt_pfx_encrypt-key2 = "a9f5ba40db214c3798f2e1c23456789a";
    call ipcrypt_pfx_encrypt;
    set var.output_ip = req.http.X-Func-ipcrypt_pfx_encrypt-Return;
    set var.expected = "210.78.121.215";
    log "Test 10: 172.16.248.177 -> " + std.ip2str(var.output_ip) + " (expected: " + var.expected + ")";

    # Test vector 11: IPv6 2001:db8::a5c9:4e2f:bb91:5a7d
    set var.input_ip = std.str2ip("2001:db8::a5c9:4e2f:bb91:5a7d", "::");
    set req.http.X-Func-ipcrypt_pfx_encrypt-input_ip = var.input_ip;
    set req.http.X-Func-ipcrypt_pfx_encrypt-key1 = "2b7e151628aed2a6abf7158809cf4f3c";
    set req.http.X-Func-ipcrypt_pfx_encrypt-key2 = "a9f5ba40db214c3798f2e1c23456789a";
    call ipcrypt_pfx_encrypt;
    set var.output_ip = req.http.X-Func-ipcrypt_pfx_encrypt-Return;
    set var.expected = "7cec:702c:1243:f70:1956:125:b9bd:1aba";
    log "Test 11: 2001:db8::a5c9:4e2f:bb91:5a7d -> " + std.ip2str(var.output_ip) + " (expected: " + var.expected + ")";

    # Test vector 12: IPv6 2001:db8::7234:d8f1:3c6e:9a52
    set var.input_ip = std.str2ip("2001:db8::7234:d8f1:3c6e:9a52", "::");
    set req.http.X-Func-ipcrypt_pfx_encrypt-input_ip = var.input_ip;
    set req.http.X-Func-ipcrypt_pfx_encrypt-key1 = "2b7e151628aed2a6abf7158809cf4f3c";
    set req.http.X-Func-ipcrypt_pfx_encrypt-key2 = "a9f5ba40db214c3798f2e1c23456789a";
    call ipcrypt_pfx_encrypt;
    set var.output_ip = req.http.X-Func-ipcrypt_pfx_encrypt-Return;
    set var.expected = "7cec:702c:1243:f70:a3ef:c8e:95c1:cd0d";
    log "Test 12: 2001:db8::7234:d8f1:3c6e:9a52 -> " + std.ip2str(var.output_ip) + " (expected: " + var.expected + ")";

    # Test vector 13: IPv6 2001:db8::f1e0:937b:26d4:8c1a
    set var.input_ip = std.str2ip("2001:db8::f1e0:937b:26d4:8c1a", "::");
    set req.http.X-Func-ipcrypt_pfx_encrypt-input_ip = var.input_ip;
    set req.http.X-Func-ipcrypt_pfx_encrypt-key1 = "2b7e151628aed2a6abf7158809cf4f3c";
    set req.http.X-Func-ipcrypt_pfx_encrypt-key2 = "a9f5ba40db214c3798f2e1c23456789a";
    call ipcrypt_pfx_encrypt;
    set var.output_ip = req.http.X-Func-ipcrypt_pfx_encrypt-Return;
    set var.expected = "7cec:702c:1243:f70:443c:c8e:6a62:b64d";
    log "Test 13: 2001:db8::f1e0:937b:26d4:8c1a -> " + std.ip2str(var.output_ip) + " (expected: " + var.expected + ")";

    # Test vector 14: IPv6 2001:db8:3a5c:0:e7d1:4b9f:2c8a:f673
    set var.input_ip = std.str2ip("2001:db8:3a5c:0:e7d1:4b9f:2c8a:f673", "::");
    set req.http.X-Func-ipcrypt_pfx_encrypt-input_ip = var.input_ip;
    set req.http.X-Func-ipcrypt_pfx_encrypt-key1 = "2b7e151628aed2a6abf7158809cf4f3c";
    set req.http.X-Func-ipcrypt_pfx_encrypt-key2 = "a9f5ba40db214c3798f2e1c23456789a";
    call ipcrypt_pfx_encrypt;
    set var.output_ip = req.http.X-Func-ipcrypt_pfx_encrypt-Return;
    set var.expected = "7cec:702c:3503:bef:e616:96bd:be33:a9b9";
    log "Test 14: 2001:db8:3a5c:0:e7d1:4b9f:2c8a:f673 -> " + std.ip2str(var.output_ip) + " (expected: " + var.expected + ")";

    # Test vector 15: IPv6 2001:db8:9f27:0:b4e2:7a3d:5f91:c8e6
    set var.input_ip = std.str2ip("2001:db8:9f27:0:b4e2:7a3d:5f91:c8e6", "::");
    set req.http.X-Func-ipcrypt_pfx_encrypt-input_ip = var.input_ip;
    set req.http.X-Func-ipcrypt_pfx_encrypt-key1 = "2b7e151628aed2a6abf7158809cf4f3c";
    set req.http.X-Func-ipcrypt_pfx_encrypt-key2 = "a9f5ba40db214c3798f2e1c23456789a";
    call ipcrypt_pfx_encrypt;
    set var.output_ip = req.http.X-Func-ipcrypt_pfx_encrypt-Return;
    set var.expected = "7cec:702c:a504:b74e:194a:3d90:b047:2d1a";
    log "Test 15: 2001:db8:9f27:0:b4e2:7a3d:5f91:c8e6 -> " + std.ip2str(var.output_ip) + " (expected: " + var.expected + ")";

    # Test vector 16: IPv6 2001:db8:d8b4:0:193c:a5e7:8b2f:46d1
    set var.input_ip = std.str2ip("2001:db8:d8b4:0:193c:a5e7:8b2f:46d1", "::");
    set req.http.X-Func-ipcrypt_pfx_encrypt-input_ip = var.input_ip;
    set req.http.X-Func-ipcrypt_pfx_encrypt-key1 = "2b7e151628aed2a6abf7158809cf4f3c";
    set req.http.X-Func-ipcrypt_pfx_encrypt-key2 = "a9f5ba40db214c3798f2e1c23456789a";
    call ipcrypt_pfx_encrypt;
    set var.output_ip = req.http.X-Func-ipcrypt_pfx_encrypt-Return;
    set var.expected = "7cec:702c:f840:aa67:1b8:e84f:ac9d:77fb";
    log "Test 16: 2001:db8:d8b4:0:193c:a5e7:8b2f:46d1 -> " + std.ip2str(var.output_ip) + " (expected: " + var.expected + ")";

    log "";
    log "=== All 16 test vectors completed ===";

    error 200;
}


// ============================================================================
// GENERATED FUNCTION SUBROUTINES
// ============================================================================

// Function: xor_hex_128
//@recv, hash, hit, miss, pass, fetch, error, deliver, log
sub xor_hex_128 {

  declare local var.a STRING;
  declare local var.b STRING;

  set var.a = req.http.X-Func-xor_hex_128-a;
  set var.b = req.http.X-Func-xor_hex_128-b;

  declare local var.return_value STRING;

  declare local var.result STRING;
  set var.result = "";
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 0, 1) + substr(var.b, 0, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 1, 1) + substr(var.b, 1, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 2, 1) + substr(var.b, 2, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 3, 1) + substr(var.b, 3, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 4, 1) + substr(var.b, 4, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 5, 1) + substr(var.b, 5, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 6, 1) + substr(var.b, 6, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 7, 1) + substr(var.b, 7, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 8, 1) + substr(var.b, 8, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 9, 1) + substr(var.b, 9, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 10, 1) + substr(var.b, 10, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 11, 1) + substr(var.b, 11, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 12, 1) + substr(var.b, 12, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 13, 1) + substr(var.b, 13, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 14, 1) + substr(var.b, 14, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 15, 1) + substr(var.b, 15, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 16, 1) + substr(var.b, 16, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 17, 1) + substr(var.b, 17, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 18, 1) + substr(var.b, 18, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 19, 1) + substr(var.b, 19, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 20, 1) + substr(var.b, 20, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 21, 1) + substr(var.b, 21, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 22, 1) + substr(var.b, 22, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 23, 1) + substr(var.b, 23, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 24, 1) + substr(var.b, 24, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 25, 1) + substr(var.b, 25, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 26, 1) + substr(var.b, 26, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 27, 1) + substr(var.b, 27, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 28, 1) + substr(var.b, 28, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 29, 1) + substr(var.b, 29, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 30, 1) + substr(var.b, 30, 1));
  set var.result = var.result + table.lookup(hex_xor, substr(var.a, 31, 1) + substr(var.b, 31, 1));
  set var.return_value = var.result;

  set req.http.X-Func-xor_hex_128-Return = var.return_value;
}

// Function: aes_ecb_128
//@recv, hash, hit, miss, pass, fetch, error, deliver, log
sub aes_ecb_128 {

  declare local var.key STRING;
  declare local var.input STRING;

  set var.key = req.http.X-Func-aes_ecb_128-key;
  set var.input = req.http.X-Func-aes_ecb_128-input;

  declare local var.return_value STRING;

  declare local var.zero_iv STRING;
  set var.zero_iv = "00000000000000000000000000000000";
  declare local var.output STRING;
  set var.output = crypto.encrypt_hex(aes128, cbc, nopad, var.key, var.zero_iv, var.input);
  set var.return_value = var.output;

  set req.http.X-Func-aes_ecb_128-Return = var.return_value;
}

// Function: hex128_to_bin128
//@recv, hash, hit, miss, pass, fetch, error, deliver, log
sub hex128_to_bin128 {

  declare local var.hex128 STRING;

  set var.hex128 = req.http.X-Func-hex128_to_bin128-hex128;

  declare local var.return_value STRING;

  declare local var.bin128 STRING;
  set var.bin128 = "";
  set var.bin128 = var.bin128 + table.lookup(hex_to_bin4, substr(var.hex128, 0, 1));
  set var.bin128 = var.bin128 + table.lookup(hex_to_bin4, substr(var.hex128, 1, 1));
  set var.bin128 = var.bin128 + table.lookup(hex_to_bin4, substr(var.hex128, 2, 1));
  set var.bin128 = var.bin128 + table.lookup(hex_to_bin4, substr(var.hex128, 3, 1));
  set var.bin128 = var.bin128 + table.lookup(hex_to_bin4, substr(var.hex128, 4, 1));
  set var.bin128 = var.bin128 + table.lookup(hex_to_bin4, substr(var.hex128, 5, 1));
  set var.bin128 = var.bin128 + table.lookup(hex_to_bin4, substr(var.hex128, 6, 1));
  set var.bin128 = var.bin128 + table.lookup(hex_to_bin4, substr(var.hex128, 7, 1));
  set var.bin128 = var.bin128 + table.lookup(hex_to_bin4, substr(var.hex128, 8, 1));
  set var.bin128 = var.bin128 + table.lookup(hex_to_bin4, substr(var.hex128, 9, 1));
  set var.bin128 = var.bin128 + table.lookup(hex_to_bin4, substr(var.hex128, 10, 1));
  set var.bin128 = var.bin128 + table.lookup(hex_to_bin4, substr(var.hex128, 11, 1));
  set var.bin128 = var.bin128 + table.lookup(hex_to_bin4, substr(var.hex128, 12, 1));
  set var.bin128 = var.bin128 + table.lookup(hex_to_bin4, substr(var.hex128, 13, 1));
  set var.bin128 = var.bin128 + table.lookup(hex_to_bin4, substr(var.hex128, 14, 1));
  set var.bin128 = var.bin128 + table.lookup(hex_to_bin4, substr(var.hex128, 15, 1));
  set var.bin128 = var.bin128 + table.lookup(hex_to_bin4, substr(var.hex128, 16, 1));
  set var.bin128 = var.bin128 + table.lookup(hex_to_bin4, substr(var.hex128, 17, 1));
  set var.bin128 = var.bin128 + table.lookup(hex_to_bin4, substr(var.hex128, 18, 1));
  set var.bin128 = var.bin128 + table.lookup(hex_to_bin4, substr(var.hex128, 19, 1));
  set var.bin128 = var.bin128 + table.lookup(hex_to_bin4, substr(var.hex128, 20, 1));
  set var.bin128 = var.bin128 + table.lookup(hex_to_bin4, substr(var.hex128, 21, 1));
  set var.bin128 = var.bin128 + table.lookup(hex_to_bin4, substr(var.hex128, 22, 1));
  set var.bin128 = var.bin128 + table.lookup(hex_to_bin4, substr(var.hex128, 23, 1));
  set var.bin128 = var.bin128 + table.lookup(hex_to_bin4, substr(var.hex128, 24, 1));
  set var.bin128 = var.bin128 + table.lookup(hex_to_bin4, substr(var.hex128, 25, 1));
  set var.bin128 = var.bin128 + table.lookup(hex_to_bin4, substr(var.hex128, 26, 1));
  set var.bin128 = var.bin128 + table.lookup(hex_to_bin4, substr(var.hex128, 27, 1));
  set var.bin128 = var.bin128 + table.lookup(hex_to_bin4, substr(var.hex128, 28, 1));
  set var.bin128 = var.bin128 + table.lookup(hex_to_bin4, substr(var.hex128, 29, 1));
  set var.bin128 = var.bin128 + table.lookup(hex_to_bin4, substr(var.hex128, 30, 1));
  set var.bin128 = var.bin128 + table.lookup(hex_to_bin4, substr(var.hex128, 31, 1));
  set var.return_value = var.bin128;

  set req.http.X-Func-hex128_to_bin128-Return = var.return_value;
}

// Function: bin128_to_hex128
//@recv, hash, hit, miss, pass, fetch, error, deliver, log
sub bin128_to_hex128 {

  declare local var.bin128 STRING;

  set var.bin128 = req.http.X-Func-bin128_to_hex128-bin128;

  declare local var.return_value STRING;

  declare local var.hex128 STRING;
  set var.hex128 = "";
  declare local var.nibble STRING;
  set var.nibble = "";
  set var.nibble = substr(var.bin128, 0, 4);
  set var.hex128 = var.hex128 + table.lookup(bin4_to_hex, var.nibble);
  set var.nibble = substr(var.bin128, 4, 4);
  set var.hex128 = var.hex128 + table.lookup(bin4_to_hex, var.nibble);
  set var.nibble = substr(var.bin128, 8, 4);
  set var.hex128 = var.hex128 + table.lookup(bin4_to_hex, var.nibble);
  set var.nibble = substr(var.bin128, 12, 4);
  set var.hex128 = var.hex128 + table.lookup(bin4_to_hex, var.nibble);
  set var.nibble = substr(var.bin128, 16, 4);
  set var.hex128 = var.hex128 + table.lookup(bin4_to_hex, var.nibble);
  set var.nibble = substr(var.bin128, 20, 4);
  set var.hex128 = var.hex128 + table.lookup(bin4_to_hex, var.nibble);
  set var.nibble = substr(var.bin128, 24, 4);
  set var.hex128 = var.hex128 + table.lookup(bin4_to_hex, var.nibble);
  set var.nibble = substr(var.bin128, 28, 4);
  set var.hex128 = var.hex128 + table.lookup(bin4_to_hex, var.nibble);
  set var.nibble = substr(var.bin128, 32, 4);
  set var.hex128 = var.hex128 + table.lookup(bin4_to_hex, var.nibble);
  set var.nibble = substr(var.bin128, 36, 4);
  set var.hex128 = var.hex128 + table.lookup(bin4_to_hex, var.nibble);
  set var.nibble = substr(var.bin128, 40, 4);
  set var.hex128 = var.hex128 + table.lookup(bin4_to_hex, var.nibble);
  set var.nibble = substr(var.bin128, 44, 4);
  set var.hex128 = var.hex128 + table.lookup(bin4_to_hex, var.nibble);
  set var.nibble = substr(var.bin128, 48, 4);
  set var.hex128 = var.hex128 + table.lookup(bin4_to_hex, var.nibble);
  set var.nibble = substr(var.bin128, 52, 4);
  set var.hex128 = var.hex128 + table.lookup(bin4_to_hex, var.nibble);
  set var.nibble = substr(var.bin128, 56, 4);
  set var.hex128 = var.hex128 + table.lookup(bin4_to_hex, var.nibble);
  set var.nibble = substr(var.bin128, 60, 4);
  set var.hex128 = var.hex128 + table.lookup(bin4_to_hex, var.nibble);
  set var.nibble = substr(var.bin128, 64, 4);
  set var.hex128 = var.hex128 + table.lookup(bin4_to_hex, var.nibble);
  set var.nibble = substr(var.bin128, 68, 4);
  set var.hex128 = var.hex128 + table.lookup(bin4_to_hex, var.nibble);
  set var.nibble = substr(var.bin128, 72, 4);
  set var.hex128 = var.hex128 + table.lookup(bin4_to_hex, var.nibble);
  set var.nibble = substr(var.bin128, 76, 4);
  set var.hex128 = var.hex128 + table.lookup(bin4_to_hex, var.nibble);
  set var.nibble = substr(var.bin128, 80, 4);
  set var.hex128 = var.hex128 + table.lookup(bin4_to_hex, var.nibble);
  set var.nibble = substr(var.bin128, 84, 4);
  set var.hex128 = var.hex128 + table.lookup(bin4_to_hex, var.nibble);
  set var.nibble = substr(var.bin128, 88, 4);
  set var.hex128 = var.hex128 + table.lookup(bin4_to_hex, var.nibble);
  set var.nibble = substr(var.bin128, 92, 4);
  set var.hex128 = var.hex128 + table.lookup(bin4_to_hex, var.nibble);
  set var.nibble = substr(var.bin128, 96, 4);
  set var.hex128 = var.hex128 + table.lookup(bin4_to_hex, var.nibble);
  set var.nibble = substr(var.bin128, 100, 4);
  set var.hex128 = var.hex128 + table.lookup(bin4_to_hex, var.nibble);
  set var.nibble = substr(var.bin128, 104, 4);
  set var.hex128 = var.hex128 + table.lookup(bin4_to_hex, var.nibble);
  set var.nibble = substr(var.bin128, 108, 4);
  set var.hex128 = var.hex128 + table.lookup(bin4_to_hex, var.nibble);
  set var.nibble = substr(var.bin128, 112, 4);
  set var.hex128 = var.hex128 + table.lookup(bin4_to_hex, var.nibble);
  set var.nibble = substr(var.bin128, 116, 4);
  set var.hex128 = var.hex128 + table.lookup(bin4_to_hex, var.nibble);
  set var.nibble = substr(var.bin128, 120, 4);
  set var.hex128 = var.hex128 + table.lookup(bin4_to_hex, var.nibble);
  set var.nibble = substr(var.bin128, 124, 4);
  set var.hex128 = var.hex128 + table.lookup(bin4_to_hex, var.nibble);
  set var.return_value = var.hex128;

  set req.http.X-Func-bin128_to_hex128-Return = var.return_value;
}

// Function: shift_left_append
//@recv, hash, hit, miss, pass, fetch, error, deliver, log
sub shift_left_append {

  declare local var.bin128 STRING;
  declare local var.append_bit INTEGER;

  set var.bin128 = req.http.X-Func-shift_left_append-bin128;
  set var.append_bit = std.atoi(req.http.X-Func-shift_left_append-append_bit);

  declare local var.return_value STRING;

  declare local var.shifted STRING;
  set var.shifted = substr(var.bin128, 1, 127);
  declare local var.result STRING;
  set var.result = "";
  if (var.append_bit == 0) {
    set var.result = var.shifted + "0";
  } else {
    set var.result = var.shifted + "1";
  }
  set var.return_value = var.result;

  set req.http.X-Func-shift_left_append-Return = var.return_value;
}

// Function: bin32_to_ipv4
//@recv, hash, hit, miss, pass, fetch, error, deliver, log
sub bin32_to_ipv4 {

  declare local var.bin32 STRING;

  set var.bin32 = req.http.X-Func-bin32_to_ipv4-bin32;

  declare local var.return_value STRING;

  declare local var.byte0 STRING;
  set var.byte0 = table.lookup(bin8_to_dec, substr(var.bin32, 0, 8));
  declare local var.byte1 STRING;
  set var.byte1 = table.lookup(bin8_to_dec, substr(var.bin32, 8, 8));
  declare local var.byte2 STRING;
  set var.byte2 = table.lookup(bin8_to_dec, substr(var.bin32, 16, 8));
  declare local var.byte3 STRING;
  set var.byte3 = table.lookup(bin8_to_dec, substr(var.bin32, 24, 8));
  declare local var.ip_str STRING;
  set var.ip_str = var.byte0 + "." + var.byte1 + "." + var.byte2 + "." + var.byte3;
  set var.return_value = var.ip_str;

  set req.http.X-Func-bin32_to_ipv4-Return = var.return_value;
}

// Function: bin128_to_ipv6
//@recv, hash, hit, miss, pass, fetch, error, deliver, log
sub bin128_to_ipv6 {

  declare local var.bin128 STRING;

  set var.bin128 = req.http.X-Func-bin128_to_ipv6-bin128;

  declare local var.return_value STRING;

  declare local var.hex128 STRING;
  set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
  call bin128_to_hex128;
  set var.hex128 = req.http.X-Func-bin128_to_hex128-Return;
  declare local var.ip_str STRING;
  set var.ip_str = substr(var.hex128, 0, 4) + ":" + substr(var.hex128, 4, 4) + ":" + substr(var.hex128, 8, 4) + ":" + substr(var.hex128, 12, 4) + ":" + substr(var.hex128, 16, 4) + ":" + substr(var.hex128, 20, 4) + ":" + substr(var.hex128, 24, 4) + ":" + substr(var.hex128, 28, 4);
  set var.return_value = var.ip_str;

  set req.http.X-Func-bin128_to_ipv6-Return = var.return_value;
}

// Function: ipcrypt_pfx_encrypt
//@recv, hash, hit, miss, pass, fetch, error, deliver, log
sub ipcrypt_pfx_encrypt {

  declare local var.input_ip IP;
  declare local var.key1 STRING;
  declare local var.key2 STRING;

  set var.input_ip = req.http.X-Func-ipcrypt_pfx_encrypt-input_ip;
  set var.key1 = req.http.X-Func-ipcrypt_pfx_encrypt-key1;
  set var.key2 = req.http.X-Func-ipcrypt_pfx_encrypt-key2;

  declare local var.return_value IP;

  declare local var.is_ipv4 BOOL;
  set var.is_ipv4 = addr.is_ipv4(var.input_ip);
  declare local var.padded_prefix STRING;
  set var.padded_prefix = "";
  declare local var.encrypted_bits STRING;
  set var.encrypted_bits = "";
  declare local var.output_ip IP;
  set var.output_ip = std.str2ip("0.0.0.0", "0.0.0.0");
  declare local var.original_bit INTEGER;
  set var.original_bit = 0;
  declare local var.cipher_bit INTEGER;
  set var.cipher_bit = 0;
  declare local var.cipher_bit_char STRING;
  set var.cipher_bit_char = "";
  declare local var.e1 STRING;
  set var.e1 = "";
  declare local var.e2 STRING;
  set var.e2 = "";
  declare local var.e STRING;
  set var.e = "";
  declare local var.bin128 STRING;
  set var.bin128 = "";
  declare local var.ip_str STRING;
  set var.ip_str = "";

  if (var.is_ipv4) {
    # IPv4 mode: encrypt only last 32 bits
    set var.padded_prefix = "0000000100000000000000000000ffff";
    set var.encrypted_bits = "";
    log "ipcrypt-pfx: IPv4 mode (32 iterations)";
  } else {
    # IPv6 mode: encrypt all 128 bits
    set var.padded_prefix = "00000000000000000000000000000001";
    set var.encrypted_bits = "";
    log "ipcrypt-pfx: IPv6 mode (128 iterations)";
  }

  if (var.is_ipv4) {
    # === IPv4 PATH: 32 iterations ===

    # Extract bit 31 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 31, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB (last hex digit, check if even/odd)
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix: convert to binary, shift left, append original_bit, convert back to hex
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 30 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 30, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB (last hex digit, check if even/odd)
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix: convert to binary, shift left, append original_bit, convert back to hex
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 29 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 29, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB (last hex digit, check if even/odd)
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix: convert to binary, shift left, append original_bit, convert back to hex
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 28 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 28, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB (last hex digit, check if even/odd)
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix: convert to binary, shift left, append original_bit, convert back to hex
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 27 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 27, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB (last hex digit, check if even/odd)
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix: convert to binary, shift left, append original_bit, convert back to hex
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 26 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 26, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB (last hex digit, check if even/odd)
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix: convert to binary, shift left, append original_bit, convert back to hex
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 25 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 25, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB (last hex digit, check if even/odd)
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix: convert to binary, shift left, append original_bit, convert back to hex
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 24 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 24, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB (last hex digit, check if even/odd)
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix: convert to binary, shift left, append original_bit, convert back to hex
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 23 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 23, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB (last hex digit, check if even/odd)
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix: convert to binary, shift left, append original_bit, convert back to hex
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 22 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 22, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB (last hex digit, check if even/odd)
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix: convert to binary, shift left, append original_bit, convert back to hex
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 21 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 21, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB (last hex digit, check if even/odd)
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix: convert to binary, shift left, append original_bit, convert back to hex
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 20 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 20, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB (last hex digit, check if even/odd)
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix: convert to binary, shift left, append original_bit, convert back to hex
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 19 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 19, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB (last hex digit, check if even/odd)
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix: convert to binary, shift left, append original_bit, convert back to hex
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 18 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 18, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB (last hex digit, check if even/odd)
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix: convert to binary, shift left, append original_bit, convert back to hex
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 17 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 17, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB (last hex digit, check if even/odd)
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix: convert to binary, shift left, append original_bit, convert back to hex
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 16 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 16, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB (last hex digit, check if even/odd)
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix: convert to binary, shift left, append original_bit, convert back to hex
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 15 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 15, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB (last hex digit, check if even/odd)
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix: convert to binary, shift left, append original_bit, convert back to hex
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 14 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 14, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB (last hex digit, check if even/odd)
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix: convert to binary, shift left, append original_bit, convert back to hex
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 13 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 13, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB (last hex digit, check if even/odd)
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix: convert to binary, shift left, append original_bit, convert back to hex
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 12 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 12, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB (last hex digit, check if even/odd)
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix: convert to binary, shift left, append original_bit, convert back to hex
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 11 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 11, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB (last hex digit, check if even/odd)
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix: convert to binary, shift left, append original_bit, convert back to hex
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 10 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 10, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB (last hex digit, check if even/odd)
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix: convert to binary, shift left, append original_bit, convert back to hex
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 9 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 9, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB (last hex digit, check if even/odd)
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix: convert to binary, shift left, append original_bit, convert back to hex
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 8 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 8, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB (last hex digit, check if even/odd)
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix: convert to binary, shift left, append original_bit, convert back to hex
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 7 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 7, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB (last hex digit, check if even/odd)
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix: convert to binary, shift left, append original_bit, convert back to hex
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 6 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 6, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB (last hex digit, check if even/odd)
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix: convert to binary, shift left, append original_bit, convert back to hex
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 5 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 5, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB (last hex digit, check if even/odd)
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix: convert to binary, shift left, append original_bit, convert back to hex
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 4 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 4, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB (last hex digit, check if even/odd)
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix: convert to binary, shift left, append original_bit, convert back to hex
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 3 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 3, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB (last hex digit, check if even/odd)
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix: convert to binary, shift left, append original_bit, convert back to hex
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 2 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 2, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB (last hex digit, check if even/odd)
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix: convert to binary, shift left, append original_bit, convert back to hex
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 1 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 1, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB (last hex digit, check if even/odd)
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix: convert to binary, shift left, append original_bit, convert back to hex
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 0 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 0, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB (last hex digit, check if even/odd)
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix: convert to binary, shift left, append original_bit, convert back to hex
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Convert 32-bit result to IPv4
    set req.http.X-Func-bin32_to_ipv4-bin32 = var.encrypted_bits;
    call bin32_to_ipv4;
    set var.ip_str = req.http.X-Func-bin32_to_ipv4-Return;
    set var.output_ip = std.str2ip(var.ip_str, "0.0.0.0");

  } else {
    # === IPv6 PATH: 128 iterations ===

    # Extract bit 127 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 127, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 126 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 126, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 125 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 125, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 124 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 124, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 123 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 123, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 122 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 122, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 121 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 121, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 120 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 120, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 119 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 119, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 118 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 118, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 117 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 117, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 116 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 116, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 115 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 115, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 114 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 114, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 113 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 113, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 112 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 112, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 111 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 111, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 110 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 110, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 109 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 109, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 108 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 108, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 107 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 107, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 106 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 106, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 105 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 105, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 104 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 104, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 103 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 103, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 102 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 102, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 101 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 101, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 100 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 100, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 99 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 99, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 98 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 98, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 97 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 97, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 96 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 96, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 95 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 95, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 94 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 94, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 93 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 93, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 92 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 92, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 91 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 91, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 90 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 90, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 89 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 89, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 88 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 88, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 87 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 87, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 86 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 86, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 85 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 85, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 84 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 84, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 83 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 83, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 82 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 82, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 81 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 81, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 80 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 80, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 79 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 79, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 78 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 78, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 77 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 77, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 76 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 76, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 75 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 75, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 74 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 74, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 73 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 73, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 72 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 72, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 71 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 71, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 70 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 70, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 69 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 69, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 68 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 68, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 67 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 67, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 66 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 66, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 65 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 65, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 64 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 64, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 63 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 63, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 62 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 62, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 61 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 61, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 60 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 60, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 59 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 59, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 58 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 58, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 57 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 57, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 56 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 56, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 55 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 55, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 54 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 54, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 53 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 53, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 52 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 52, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 51 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 51, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 50 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 50, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 49 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 49, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 48 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 48, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 47 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 47, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 46 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 46, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 45 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 45, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 44 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 44, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 43 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 43, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 42 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 42, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 41 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 41, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 40 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 40, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 39 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 39, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 38 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 38, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 37 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 37, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 36 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 36, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 35 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 35, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 34 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 34, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 33 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 33, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 32 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 32, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 31 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 31, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 30 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 30, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 29 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 29, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 28 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 28, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 27 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 27, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 26 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 26, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 25 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 25, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 24 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 24, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 23 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 23, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 22 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 22, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 21 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 21, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 20 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 20, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 19 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 19, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 18 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 18, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 17 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 17, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 16 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 16, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 15 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 15, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 14 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 14, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 13 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 13, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 12 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 12, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 11 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 11, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 10 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 10, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 9 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 9, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 8 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 8, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 7 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 7, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 6 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 6, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 5 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 5, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 4 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 4, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 3 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 3, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 2 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 2, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 1 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 1, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Extract bit 0 directly (addr.extract_bits requires literal position)
    set var.original_bit = addr.extract_bits(var.input_ip, 0, 1);

    # Encrypt padded_prefix with K1
    set req.http.X-Func-aes_ecb_128-key = var.key1;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e1 = req.http.X-Func-aes_ecb_128-Return;

    # Encrypt padded_prefix with K2
    set req.http.X-Func-aes_ecb_128-key = var.key2;
    set req.http.X-Func-aes_ecb_128-input = var.padded_prefix;
    call aes_ecb_128;
    set var.e2 = req.http.X-Func-aes_ecb_128-Return;

    # XOR the two AES outputs
    set req.http.X-Func-xor_hex_128-a = var.e1;
    set req.http.X-Func-xor_hex_128-b = var.e2;
    call xor_hex_128;
    set var.e = req.http.X-Func-xor_hex_128-Return;

    # Extract LSB
    set var.cipher_bit_char = substr(var.e, 31, 1);
    if (var.cipher_bit_char == "0" || var.cipher_bit_char == "2" || var.cipher_bit_char == "4" || var.cipher_bit_char == "6" || var.cipher_bit_char == "8" || var.cipher_bit_char == "a" || var.cipher_bit_char == "c" || var.cipher_bit_char == "e") {
      set var.cipher_bit = 0;
    } else {
      set var.cipher_bit = 1;
    }

    # XOR cipher_bit with original_bit
    if (var.original_bit == var.cipher_bit) {
      set var.encrypted_bits = var.encrypted_bits + "0";
    } else {
      set var.encrypted_bits = var.encrypted_bits + "1";
    }

    # Update padded_prefix
    set req.http.X-Func-hex128_to_bin128-hex128 = var.padded_prefix;
    call hex128_to_bin128;
    set var.bin128 = req.http.X-Func-hex128_to_bin128-Return;
    set req.http.X-Func-shift_left_append-bin128 = var.bin128;
    set req.http.X-Func-shift_left_append-append_bit = std.itoa(var.original_bit);
    call shift_left_append;
    set var.bin128 = req.http.X-Func-shift_left_append-Return;
    set req.http.X-Func-bin128_to_hex128-bin128 = var.bin128;
    call bin128_to_hex128;
    set var.padded_prefix = req.http.X-Func-bin128_to_hex128-Return;

    # Convert 128-bit result to IPv6
    set req.http.X-Func-bin128_to_ipv6-bin128 = var.encrypted_bits;
    call bin128_to_ipv6;
    set var.ip_str = req.http.X-Func-bin128_to_ipv6-Return;
    set var.output_ip = std.str2ip(var.ip_str, "::");
  }

  set var.return_value = var.output_ip;

  set req.http.X-Func-ipcrypt_pfx_encrypt-Return = var.return_value;
}
