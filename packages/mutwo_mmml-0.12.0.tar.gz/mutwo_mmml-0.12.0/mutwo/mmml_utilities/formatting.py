import re


__all__ = ("beauty_format_mmml",)

# regex to match either quoted strings or non-whitespace sequences
_field_pattern = re.compile(r"""("[^"]*"|'[^']*'|\S+)""")


def beauty_format_mmml(text: str) -> str:
    """
    Aligns columns in MMML-like files while preserving indentation, comments, and quoted strings.
    Accepts a single string input and returns a formatted string.
    """
    lines = text.split("\n")
    formatted_lines = []
    buffer = []
    current_indent = None

    for line in lines:
        stripped = line.lstrip()
        if not stripped or stripped.startswith("#"):
            if buffer:
                formatted_lines.extend(_align_buffer(buffer))
                buffer = []
            formatted_lines.append(line.rstrip())
            continue

        indent = line[: len(line) - len(stripped)]

        if current_indent is None:
            current_indent = indent

        if indent != current_indent:
            if buffer:
                formatted_lines.extend(_align_buffer(buffer))
                buffer = []
            current_indent = indent

        buffer.append(line.rstrip())

    if buffer:
        formatted_lines.extend(_align_buffer(buffer))

    return "\n".join(formatted_lines)


def _align_buffer(lines):
    """
    Align columns for a group of lines with the same indentation.
    Uses regex to preserve quotes.
    """
    if not lines:
        return []

    split_lines = []
    for line in lines:
        indent = line[: len(line) - len(line.lstrip())]
        content = line[len(indent) :]
        fields = _field_pattern.findall(content)
        split_lines.append((indent, fields))

    max_cols = max(len(fields) for _, fields in split_lines)
    col_widths = [0] * max_cols
    for _, fields in split_lines:
        for i, f in enumerate(fields):
            col_widths[i] = max(col_widths[i], len(f))

    aligned_lines = []
    for indent, fields in split_lines:
        aligned = []
        for i, f in enumerate(fields):
            padding = col_widths[i] - len(f) + 1 if i < len(fields) - 1 else 0
            aligned.append(f + " " * padding)
        aligned_lines.append(indent + "".join(aligned))

    return aligned_lines
