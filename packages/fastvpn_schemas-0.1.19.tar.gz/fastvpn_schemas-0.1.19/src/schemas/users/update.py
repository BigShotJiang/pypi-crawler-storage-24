from typing import Optional

from pydantic import BaseModel, Field


class UserUpdate(BaseModel):
    telegram_id: Optional[int] = Field(default=None, ge=1)
