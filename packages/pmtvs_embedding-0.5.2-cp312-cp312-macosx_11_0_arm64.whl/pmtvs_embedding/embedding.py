"""
Time-Delay Embedding

Functions for constructing and optimizing time-delay embeddings for
dynamical systems analysis (Takens' theorem).
"""

import numpy as np
from typing import Optional, Tuple

import pmtvs_embedding._rust as _rust


def delay_embedding(
    signal: np.ndarray,
    dim: int,
    tau: int = 1
) -> np.ndarray:
    """
    Construct time-delay embedding matrix.

    Parameters
    ----------
    signal : np.ndarray
        Input time series (1D)
    dim : int
        Embedding dimension (m)
    tau : int
        Time delay (default: 1)

    Returns
    -------
    np.ndarray
        Embedding matrix of shape (N - (dim-1)*tau, dim)
    """
    signal = np.ascontiguousarray(np.asarray(signal, dtype=np.float64).flatten())
    return np.asarray(_rust.delay_embedding(signal, dim, tau))


def optimal_embedding_dimension(
    signal: np.ndarray,
    tau: int = 1,
    max_dim: int = 10,
    threshold: float = 0.95
) -> int:
    """
    Find optimal embedding dimension using Cao's method.

    Parameters
    ----------
    signal : np.ndarray
        Input time series
    tau : int
        Time delay
    max_dim : int
        Maximum dimension to search
    threshold : float
        E1 saturation threshold (default: 0.95)

    Returns
    -------
    int
        Optimal embedding dimension
    """
    signal = np.ascontiguousarray(np.asarray(signal, dtype=np.float64).flatten())
    return int(_rust.optimal_embedding_dimension(signal, tau, max_dim, threshold))


def mutual_information_delay(
    signal: np.ndarray,
    max_lag: int = 50,
    n_bins: int = 16
) -> int:
    """
    Find optimal time delay using mutual information.

    Parameters
    ----------
    signal : np.ndarray
        Input time series
    max_lag : int
        Maximum lag to search
    n_bins : int
        Number of bins for histogram

    Returns
    -------
    int
        Optimal time delay
    """
    signal = np.ascontiguousarray(np.asarray(signal, dtype=np.float64).flatten())
    return int(_rust.mutual_information_delay(signal, max_lag, n_bins))


def false_nearest_neighbors(
    signal: np.ndarray,
    tau: int = 1,
    max_dim: int = 10,
    r_threshold: float = 15.0,
    a_threshold: float = 2.0
) -> Tuple[np.ndarray, int]:
    """
    Find optimal embedding dimension using false nearest neighbors.

    Parameters
    ----------
    signal : np.ndarray
        Input time series
    tau : int
        Time delay
    max_dim : int
        Maximum dimension to search
    r_threshold : float
        Distance ratio threshold
    a_threshold : float
        Attractor size threshold

    Returns
    -------
    tuple
        (fnn_percentages, optimal_dimension)
    """
    signal = np.ascontiguousarray(np.asarray(signal, dtype=np.float64).flatten())
    fnn_arr, opt_dim = _rust.false_nearest_neighbors(
        signal, tau, max_dim, r_threshold, a_threshold
    )
    return np.asarray(fnn_arr), int(opt_dim)


def multivariate_embedding(
    signals: np.ndarray,
    dim: int = 3,
    tau: int = 1
) -> np.ndarray:
    """
    Construct multivariate time-delay embedding from multiple signals.

    Parameters
    ----------
    signals : np.ndarray
        Input signals, shape (n_signals, n_samples) or (n_samples, n_signals)
    dim : int
        Embedding dimension per signal
    tau : int
        Time delay

    Returns
    -------
    np.ndarray
        Joint embedding matrix of shape (n_vectors, n_signals * dim)
    """
    signals = np.asarray(signals, dtype=np.float64)

    if signals.ndim == 1:
        return delay_embedding(signals, dim, tau)

    signals = np.ascontiguousarray(signals)
    return np.asarray(_rust.multivariate_embedding(signals, dim, tau))
