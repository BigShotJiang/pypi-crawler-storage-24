"""
pmtvs-embedding — Time-delay embedding for dynamical systems analysis.

numpy in, array out.
"""

__version__ = "0.5.1"
BACKEND = "rust"

try:
    import pmtvs_embedding._rust  # noqa: F401 — validates Rust extension is loadable
except ImportError as e:
    raise ImportError(
        f"\n\nRust extension not found: {e}\n"
        f"The pmtvs framework requires compiled Rust extensions.\n"
        f"Install with: cd packages/pmtvs-embedding && maturin develop --release\n"
        f"Or rebuild the Docker image.\n"
    ) from e

# --- Public API ---
from pmtvs_embedding.embedding import (
    delay_embedding,
    optimal_embedding_dimension,
    mutual_information_delay,
    false_nearest_neighbors,
    multivariate_embedding,
)

__all__ = [
    "__version__",
    "BACKEND",
    "delay_embedding",
    "optimal_embedding_dimension",
    "mutual_information_delay",
    "false_nearest_neighbors",
    "multivariate_embedding",
]
