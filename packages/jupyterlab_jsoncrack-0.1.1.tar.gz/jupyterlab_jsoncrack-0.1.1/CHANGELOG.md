# Changelog

<!-- <START NEW CHANGELOG ENTRY> -->

## 0.1.1

([Full Changelog](https://github.com/jtpio/jupyterlab-jsoncrack/compare/250d1bea5dddce97ec1fd19fc8ed7e02305a54e0...3497c3d5bb91971e55880b5002a1c150dfdaebeb))

✨ First Release ✨

### Contributors to this release

The following people contributed discussions, new ideas, code and documentation contributions, and review.
See [our definition of contributors](https://github-activity.readthedocs.io/en/latest/use/#how-does-this-tool-define-contributions-in-the-reports).

([GitHub contributors page for this release](https://github.com/jtpio/jupyterlab-jsoncrack/graphs/contributors?from=2026-03-21&to=2026-03-21&type=c))

@jtpio ([activity](https://github.com/search?q=repo%3Ajtpio%2Fjupyterlab-jsoncrack+involves%3Ajtpio+updated%3A2026-03-21..2026-03-21&type=Issues))

<!-- <END NEW CHANGELOG ENTRY> -->
