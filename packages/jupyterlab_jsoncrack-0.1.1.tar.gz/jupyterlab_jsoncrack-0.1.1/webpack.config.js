const BROKEN_SOURCE_MAP_PACKAGES = [
  /[\\/]node_modules[\\/]@reaviz[\\/]react-use-fuzzy[\\/]/,
  /[\\/]node_modules[\\/]calculate-size[\\/]/,
  /[\\/]node_modules[\\/]react-highlight-words[\\/]/
];

/**
 * Filter out noisy webpack warnings emitted by third-party packages that ship
 * invalid source maps. These warnings do not reflect issues in this extension.
 */
function ignoreBrokenSourceMapWarnings(warning) {
  const resource = warning?.module?.resource ?? '';
  const message = warning?.message ?? '';
  const matchesKnownPackage = BROKEN_SOURCE_MAP_PACKAGES.some(pattern =>
    pattern.test(resource)
  );

  if (!matchesKnownPackage) {
    return false;
  }

  return (
    message.includes('Failed to parse source map') ||
    message.includes('Invalid dependencies have been reported')
  );
}

module.exports = {
  ignoreWarnings: [ignoreBrokenSourceMapWarnings]
};
