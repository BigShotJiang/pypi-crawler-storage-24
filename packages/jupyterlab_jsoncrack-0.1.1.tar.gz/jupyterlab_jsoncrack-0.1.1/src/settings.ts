import { IThemeManager } from '@jupyterlab/apputils';
import { ISettingRegistry } from '@jupyterlab/settingregistry';
import { CanvasThemeMode, LayoutDirection } from 'jsoncrack-react';
import { SUPPORTED_FILE_TYPES } from './formats';

export const PLUGIN_ID = 'jupyterlab-jsoncrack:plugin';
export const FACTORY_NAME = 'JSON Crack';
export { SUPPORTED_FILE_TYPES };

export interface IJSONCrackSettings {
  layoutDirection: LayoutDirection;
  trackpadZoom: boolean;
  centerOnLayout: boolean;
  maxRenderableNodes: number;
  useAsDefaultViewer: boolean;
}

export type JSONCrackSelectSettingKey = 'layoutDirection';
type JSONCrackBooleanSettingKey =
  | 'trackpadZoom'
  | 'centerOnLayout'
  | 'useAsDefaultViewer';

export interface ISelectOption<T extends string> {
  label: string;
  value: T;
}

export const LAYOUT_DIRECTION_OPTIONS: ISelectOption<LayoutDirection>[] = [
  { label: 'Right', value: 'RIGHT' },
  { label: 'Down', value: 'DOWN' },
  { label: 'Left', value: 'LEFT' },
  { label: 'Up', value: 'UP' }
];

const DEFAULT_SETTINGS: IJSONCrackSettings = {
  layoutDirection: 'RIGHT',
  trackpadZoom: false,
  centerOnLayout: true,
  maxRenderableNodes: 1500,
  useAsDefaultViewer: false
};

function isLayoutDirection(value: unknown): value is LayoutDirection {
  return (
    value === 'RIGHT' || value === 'DOWN' || value === 'LEFT' || value === 'UP'
  );
}

function readBooleanSetting(
  settings: ISettingRegistry.ISettings,
  key: JSONCrackBooleanSettingKey
): boolean {
  const value = settings.get(key).composite;
  return typeof value === 'boolean' ? value : DEFAULT_SETTINGS[key];
}

function readLayoutDirectionSetting(
  settings: ISettingRegistry.ISettings
): LayoutDirection {
  const value = settings.get('layoutDirection').composite;
  return isLayoutDirection(value) ? value : DEFAULT_SETTINGS.layoutDirection;
}

function readMaxRenderableNodes(settings: ISettingRegistry.ISettings): number {
  const value = settings.get('maxRenderableNodes').composite;
  return typeof value === 'number' && Number.isInteger(value) && value > 0
    ? value
    : DEFAULT_SETTINGS.maxRenderableNodes;
}

/**
 * Read the effective JSON Crack settings.
 */
export function getJSONCrackSettings(
  settings: ISettingRegistry.ISettings | null
): IJSONCrackSettings {
  if (!settings) {
    return { ...DEFAULT_SETTINGS };
  }

  return readSettings(settings);
}

/**
 * Derive the JSON Crack theme from the active JupyterLab theme.
 */
export function getJSONCrackTheme(
  themeManager: IThemeManager | null
): CanvasThemeMode {
  const theme = themeManager?.theme;
  return theme && !themeManager.isLight(theme) ? 'dark' : 'light';
}

function readSettings(
  settings: ISettingRegistry.ISettings
): IJSONCrackSettings {
  return {
    layoutDirection: readLayoutDirectionSetting(settings),
    trackpadZoom: readBooleanSetting(settings, 'trackpadZoom'),
    centerOnLayout: readBooleanSetting(settings, 'centerOnLayout'),
    maxRenderableNodes: readMaxRenderableNodes(settings),
    useAsDefaultViewer: readBooleanSetting(settings, 'useAsDefaultViewer')
  };
}
