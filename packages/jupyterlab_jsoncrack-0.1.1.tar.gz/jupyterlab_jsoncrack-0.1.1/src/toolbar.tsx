import { ReactWidget } from '@jupyterlab/apputils';
import { ISettingRegistry } from '@jupyterlab/settingregistry';
import { Widget } from '@lumino/widgets';
import * as React from 'react';

import {
  IJSONCrackSettings,
  ISelectOption,
  LAYOUT_DIRECTION_OPTIONS,
  getJSONCrackSettings,
  JSONCrackSelectSettingKey
} from './settings';

interface IJSONCrackSelectToolbarItemOptions<
  K extends JSONCrackSelectSettingKey
> {
  settings: ISettingRegistry.ISettings | null;
  settingKey: K;
  label: string;
  tooltip: string;
  options: Array<ISelectOption<IJSONCrackSettings[K]>>;
}

/**
 * Base class for toolbar widgets backed by shared settings.
 */
abstract class JSONCrackSettingsToolbarItem extends ReactWidget {
  constructor(settings: ISettingRegistry.ISettings | null, className: string) {
    super();
    this.addClass(className);
    this._settings = settings;
    this._settings?.changed.connect(this._onSettingsChanged, this);
  }

  dispose(): void {
    if (this.isDisposed) {
      return;
    }

    this._settings?.changed.disconnect(this._onSettingsChanged, this);
    super.dispose();
  }

  protected get settings(): IJSONCrackSettings {
    return getJSONCrackSettings(this._settings);
  }

  protected get toolbarSettings(): ISettingRegistry.ISettings | null {
    return this._settings;
  }

  protected setSetting<K extends JSONCrackSelectSettingKey>(
    key: K,
    value: IJSONCrackSettings[K]
  ): void {
    if (!this._settings) {
      return;
    }

    void this._settings.set(key, value).catch(reason => {
      console.error(`Failed to update JSON Crack setting "${key}".`, reason);
    });
  }

  private _onSettingsChanged(): void {
    this.update();
  }

  private readonly _settings: ISettingRegistry.ISettings | null;
}
/**
 * Toolbar select for JSON Crack enum settings.
 */
export class JSONCrackSelectToolbarItem<
  K extends JSONCrackSelectSettingKey
> extends JSONCrackSettingsToolbarItem {
  constructor(options: IJSONCrackSelectToolbarItemOptions<K>) {
    super(options.settings, 'jp-jupyterlab-jsoncrackToolbarSelectWrapper');
    this._settingKey = options.settingKey;
    this._label = options.label;
    this._tooltip = options.tooltip;
    this._options = options.options;
  }

  protected render(): JSX.Element {
    const value = this.settings[this._settingKey];

    return (
      <label
        className="jp-jupyterlab-jsoncrackToolbarSelect"
        title={this._tooltip}
      >
        <select
          aria-label={this._label}
          className="jp-mod-styled"
          disabled={this.toolbarSettings === null}
          onChange={event => {
            const nextValue = this._options.find(
              option => option.value === event.target.value
            );

            if (nextValue) {
              this.setSetting(this._settingKey, nextValue.value);
            }
          }}
          value={value}
        >
          {this._options.map(option => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
      </label>
    );
  }

  private readonly _label: string;
  private readonly _options: Array<ISelectOption<IJSONCrackSettings[K]>>;
  private readonly _settingKey: K;
  private readonly _tooltip: string;
}

/**
 * Create the layout direction toolbar item.
 */
export function createLayoutDirectionToolbarItem(
  settings: ISettingRegistry.ISettings | null
): Widget {
  return new JSONCrackSelectToolbarItem({
    settings,
    settingKey: 'layoutDirection',
    label: 'Layout',
    tooltip: 'Choose the graph layout direction.',
    options: LAYOUT_DIRECTION_OPTIONS
  });
}
