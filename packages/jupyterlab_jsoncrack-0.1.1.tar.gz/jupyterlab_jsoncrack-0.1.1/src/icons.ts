import { LabIcon } from '@jupyterlab/ui-components';

const jsonCrackSvgstr = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16">
  <path
    class="jp-icon3"
    fill="#616161"
    d="M4 2H2.75A1.75 1.75 0 0 0 1 3.75V5h1.5V3.75c0-.14.11-.25.25-.25H4V2zm9.25 0H12v1.5h1.25c.14 0 .25.11.25.25V5H15V3.75A1.75 1.75 0 0 0 13.25 2zM1 11v1.25C1 13.22 1.78 14 2.75 14H4v-1.5H2.75a.25.25 0 0 1-.25-.25V11H1zm12.5 0v1.25a.25.25 0 0 1-.25.25H12V14h1.25c.97 0 1.75-.78 1.75-1.75V11H13.5z"
  />
  <path
    class="jp-icon3"
    fill="none"
    stroke="#616161"
    stroke-linecap="round"
    stroke-linejoin="round"
    stroke-width="1.4"
    d="M5.25 10.25L8 5.75l2.75 4.5"
  />
  <circle class="jp-icon3" cx="5.25" cy="10.25" r="1.25" fill="#616161" />
  <circle class="jp-icon3" cx="8" cy="5.75" r="1.25" fill="#616161" />
  <circle class="jp-icon3" cx="10.75" cy="10.25" r="1.25" fill="#616161" />
</svg>
`;

/**
 * Icon used for JSON Crack document widgets.
 */
export const jsonCrackIcon = new LabIcon({
  name: 'jupyterlab-jsoncrack:document',
  svgstr: jsonCrackSvgstr
});
