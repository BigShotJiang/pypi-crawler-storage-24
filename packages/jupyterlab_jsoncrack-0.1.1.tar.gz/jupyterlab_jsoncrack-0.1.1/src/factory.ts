import { IThemeManager } from '@jupyterlab/apputils';
import {
  ABCWidgetFactory,
  DocumentRegistry,
  DocumentWidget
} from '@jupyterlab/docregistry';
import { ISettingRegistry } from '@jupyterlab/settingregistry';

import { FACTORY_NAME, SUPPORTED_FILE_TYPES } from './settings';
import { JSONCrackViewer } from './viewer';

/**
 * Main document widget for JSON Crack views.
 */
export class JSONCrackDocumentWidget extends DocumentWidget<
  JSONCrackViewer,
  DocumentRegistry.ICodeModel
> {}

export interface IJSONCrackWidgetFactoryOptions {
  settings: ISettingRegistry.ISettings | null;
  themeManager: IThemeManager | null;
  toolbarFactory?: NonNullable<
    DocumentRegistry.IWidgetFactoryOptions<JSONCrackDocumentWidget>['toolbarFactory']
  >;
}

/**
 * Widget factory that opens supported text documents in a JSON Crack widget.
 */
export class JSONCrackWidgetFactory extends ABCWidgetFactory<
  JSONCrackDocumentWidget,
  DocumentRegistry.ICodeModel
> {
  constructor(options: IJSONCrackWidgetFactoryOptions) {
    super({
      name: FACTORY_NAME,
      label: FACTORY_NAME,
      fileTypes: [...SUPPORTED_FILE_TYPES],
      defaultRendered: [...SUPPORTED_FILE_TYPES],
      modelName: 'text',
      readOnly: true,
      toolbarFactory: options.toolbarFactory
    });
    this._settings = options.settings;
    this._themeManager = options.themeManager;
  }

  protected createNewWidget(
    context: DocumentRegistry.IContext<DocumentRegistry.ICodeModel>
  ): JSONCrackDocumentWidget {
    const content = new JSONCrackViewer({
      context,
      settings: this._settings,
      themeManager: this._themeManager
    });
    const widget = new JSONCrackDocumentWidget({ content, context });

    widget.addClass('jp-jupyterlab-jsoncrackDocument');
    widget.title.caption = `${FACTORY_NAME} - ${context.localPath}`;

    return widget;
  }

  private readonly _settings: ISettingRegistry.ISettings | null;
  private readonly _themeManager: IThemeManager | null;
}
