import { csv2json } from 'json-2-csv';
import { load } from 'js-yaml';

export const SUPPORTED_FILE_TYPES = ['json', 'yaml', 'csv'] as const;

export type JSONCrackDocumentFormat =
  | (typeof SUPPORTED_FILE_TYPES)[number]
  | 'unknown';

export type JSONCrackRenderableInput = string | object | unknown[];

export interface IPreparedJSONCrackInput {
  data: JSONCrackRenderableInput | null;
  error: string | null;
}

const CSV_PARSE_OPTIONS = {
  excelBOM: true,
  trimFieldValues: true,
  trimHeaderFields: true,
  wrapBooleans: true
};

function isObject(value: unknown): value is object {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function normalizeRootValue(value: unknown): JSONCrackRenderableInput {
  if (Array.isArray(value)) {
    return value;
  }

  if (isObject(value)) {
    return value;
  }

  return { value: value ?? null };
}

function getErrorMessage(reason: unknown): string {
  return reason instanceof Error
    ? reason.message
    : 'Unable to parse this document.';
}

/**
 * Infer the document format from the current file path.
 */
export function getJSONCrackDocumentFormat(
  path: string
): JSONCrackDocumentFormat {
  const lowerPath = path.toLowerCase();

  if (lowerPath.endsWith('.yaml') || lowerPath.endsWith('.yml')) {
    return 'yaml';
  }

  if (lowerPath.endsWith('.csv')) {
    return 'csv';
  }

  if (lowerPath.endsWith('.json')) {
    return 'json';
  }

  return 'unknown';
}

/**
 * Prepare raw document content for consumption by jsoncrack-react.
 */
export function prepareJSONCrackInput(
  source: string,
  format: JSONCrackDocumentFormat
): IPreparedJSONCrackInput {
  if (source.trim().length === 0) {
    return { data: null, error: null };
  }

  try {
    if (format === 'yaml') {
      return {
        data: normalizeRootValue(load(source)),
        error: null
      };
    }

    if (format === 'csv') {
      return {
        data: normalizeRootValue(csv2json(source, CSV_PARSE_OPTIONS)),
        error: null
      };
    }

    return { data: source, error: null };
  } catch (reason) {
    return {
      data: null,
      error: getErrorMessage(reason)
    };
  }
}
