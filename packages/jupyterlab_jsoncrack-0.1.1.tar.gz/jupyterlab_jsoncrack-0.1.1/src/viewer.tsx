import { IThemeManager, ReactWidget } from '@jupyterlab/apputils';
import { DocumentRegistry } from '@jupyterlab/docregistry';
import { ISettingRegistry } from '@jupyterlab/settingregistry';
import { JSONCrack } from 'jsoncrack-react';
import { Message } from '@lumino/messaging';
import * as React from 'react';
import { ViewPort } from 'react-zoomable-ui';

import { jsonCrackIcon } from './icons';
import {
  IJSONCrackSettings,
  FACTORY_NAME,
  getJSONCrackSettings,
  getJSONCrackTheme
} from './settings';
import {
  JSONCrackRenderableInput,
  getJSONCrackDocumentFormat,
  prepareJSONCrackInput
} from './formats';

interface IJSONCrackPanelProps {
  isReady: boolean;
  input: JSONCrackRenderableInput | null;
  formatError: string | null;
  settings: IJSONCrackSettings;
  theme: 'light' | 'dark';
  onViewportCreate: (viewport: ViewPort) => void;
}

interface IJSONCrackViewerOptions {
  context: DocumentRegistry.IContext<DocumentRegistry.ICodeModel>;
  settings: ISettingRegistry.ISettings | null;
  themeManager: IThemeManager | null;
}

/**
 * React surface for the JSON Crack canvas.
 */
function JSONCrackPanel(props: IJSONCrackPanelProps): JSX.Element {
  const [parseError, setParseError] = React.useState<string | null>(null);
  const viewerError = props.formatError ?? parseError;

  if (!props.isReady) {
    return (
      <div className="jp-jupyterlab-jsoncrackPlaceholder">
        <p>Loading document…</p>
      </div>
    );
  }

  if (!props.input && !viewerError) {
    return (
      <div className="jp-jupyterlab-jsoncrackPlaceholder">
        <p>The current document is empty.</p>
      </div>
    );
  }

  return (
    <div className="jp-jupyterlab-jsoncrackSurface">
      {viewerError ? (
        <div className="jp-jupyterlab-jsoncrackBanner" role="alert">
          Unable to render this document: {viewerError}
        </div>
      ) : null}
      {props.input ? (
        <div className="jp-jupyterlab-jsoncrackCanvas">
          <JSONCrack
            json={props.input}
            theme={props.theme}
            layoutDirection={props.settings.layoutDirection}
            showControls={true}
            showGrid={true}
            trackpadZoom={props.settings.trackpadZoom}
            centerOnLayout={props.settings.centerOnLayout}
            maxRenderableNodes={props.settings.maxRenderableNodes}
            className="jp-jupyterlab-jsoncrackCanvasRoot"
            style={{ height: '100%' }}
            onViewportCreate={props.onViewportCreate}
            onParse={() => {
              setParseError(null);
            }}
            onParseError={error => {
              setParseError(error.message);
            }}
            renderNodeLimitExceeded={(nodeCount, maxRenderableNodes) => (
              <div className="jp-jupyterlab-jsoncrackPlaceholder">
                <p>
                  Rendering stopped at {nodeCount.toLocaleString()} nodes
                  because the current limit is{' '}
                  {maxRenderableNodes.toLocaleString()}.
                </p>
                <p>
                  Increase <code>maxRenderableNodes</code> in the extension
                  settings to allow larger graphs.
                </p>
              </div>
            )}
          />
        </div>
      ) : (
        <div className="jp-jupyterlab-jsoncrackPlaceholder">
          <p>Check the document syntax and try again.</p>
        </div>
      )}
    </div>
  );
}

/**
 * Document content widget backed by jsoncrack-react.
 */
export class JSONCrackViewer extends ReactWidget {
  constructor(options: IJSONCrackViewerOptions) {
    super();
    this.addClass('jp-jupyterlab-jsoncrackViewer');
    this.title.icon = jsonCrackIcon;
    this.title.iconLabel = FACTORY_NAME;
    this._context = options.context;
    this._settings = options.settings;
    this._themeManager = options.themeManager;

    this._context.model.contentChanged.connect(this._onContentChanged, this);
    this._context.pathChanged.connect(this._onPathChanged, this);
    this._settings?.changed.connect(this._onSettingsChanged, this);
    this._themeManager?.themeChanged.connect(this._onThemeChanged, this);

    void this._context.ready.then(() => {
      if (!this.isDisposed) {
        this.update();
      }
    });
  }

  dispose(): void {
    if (this.isDisposed) {
      return;
    }
    this._context.model.contentChanged.disconnect(this._onContentChanged, this);
    this._context.pathChanged.disconnect(this._onPathChanged, this);
    this._settings?.changed.disconnect(this._onSettingsChanged, this);
    this._themeManager?.themeChanged.disconnect(this._onThemeChanged, this);
    super.dispose();
  }

  protected render(): JSX.Element {
    const settings = getJSONCrackSettings(this._settings);
    const preparedInput = prepareJSONCrackInput(
      this._context.model.toString(),
      getJSONCrackDocumentFormat(this._context.localPath)
    );

    return (
      <JSONCrackPanel
        isReady={this._context.isReady}
        input={preparedInput.data}
        formatError={preparedInput.error}
        settings={settings}
        theme={getJSONCrackTheme(this._themeManager)}
        onViewportCreate={this._onViewportCreate}
      />
    );
  }

  protected onAfterShow(msg: Message): void {
    super.onAfterShow(msg);
    this._scheduleViewportRefresh();
  }

  private _onContentChanged(): void {
    this.update();
  }

  private _onPathChanged(): void {
    this.update();
  }

  private _onSettingsChanged(): void {
    this.update();
  }

  private _onThemeChanged(): void {
    this.update();
  }

  private readonly _context: DocumentRegistry.IContext<DocumentRegistry.ICodeModel>;
  private _onViewportCreate = (viewport: ViewPort): void => {
    this._viewport = viewport;
  };

  /**
   * Refresh the cached container bounds after the widget becomes visible again.
   */
  private _scheduleViewportRefresh(): void {
    requestAnimationFrame(() => {
      if (!this.isDisposed) {
        this._viewport?.updateContainerSize();
      }
    });
  }

  private readonly _settings: ISettingRegistry.ISettings | null;
  private readonly _themeManager: IThemeManager | null;
  private _viewport: ViewPort | null = null;
}
