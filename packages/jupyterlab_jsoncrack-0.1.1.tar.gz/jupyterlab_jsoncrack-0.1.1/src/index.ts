import {
  JupyterFrontEnd,
  JupyterFrontEndPlugin
} from '@jupyterlab/application';
import {
  createToolbarFactory,
  IThemeManager,
  IToolbarWidgetRegistry
} from '@jupyterlab/apputils';

import { ISettingRegistry } from '@jupyterlab/settingregistry';
import { ITranslator, nullTranslator } from '@jupyterlab/translation';

import { JSONCrackWidgetFactory } from './factory';
import { jsonCrackIcon } from './icons';
import {
  FACTORY_NAME,
  PLUGIN_ID,
  SUPPORTED_FILE_TYPES,
  getJSONCrackSettings
} from './settings';
import { createLayoutDirectionToolbarItem } from './toolbar';

/**
 * Load the extension settings and fall back to defaults on failure.
 */
async function loadSettings(
  settingRegistry: ISettingRegistry
): Promise<ISettingRegistry.ISettings | null> {
  try {
    return await settingRegistry.load(PLUGIN_ID);
  } catch (reason) {
    console.error('Failed to load JSON Crack settings.', reason);
    return null;
  }
}

/**
 * Apply or clear the default widget override for supported text formats.
 */
function applyDefaultViewerSetting(
  app: JupyterFrontEnd,
  settings: ISettingRegistry.ISettings | null
): void {
  try {
    const defaultViewer = getJSONCrackSettings(settings).useAsDefaultViewer
      ? FACTORY_NAME
      : undefined;

    SUPPORTED_FILE_TYPES.forEach(fileType => {
      app.docRegistry.setDefaultWidgetFactory(fileType, defaultViewer);
    });
  } catch (reason) {
    console.warn('Failed to update the default JSON Crack viewer.', reason);
  }
}

/**
 * Register the toolbar item factories used by the JSON Crack viewer.
 */
function registerToolbarItems(
  toolbarRegistry: IToolbarWidgetRegistry,
  settings: () => ISettingRegistry.ISettings | null
): void {
  toolbarRegistry.addFactory(FACTORY_NAME, 'layoutDirection', () =>
    createLayoutDirectionToolbarItem(settings())
  );
}

/**
 * Register a synthetic file type so the file browser can resolve an icon for
 * the JSON Crack entry in the "Open With" submenu.
 */
function registerOpenWithIcon(app: JupyterFrontEnd): void {
  app.docRegistry.addFileType({
    name: FACTORY_NAME,
    displayName: FACTORY_NAME,
    extensions: [],
    mimeTypes: [],
    contentType: 'file',
    fileFormat: 'text',
    icon: jsonCrackIcon
  });
}

/**
 * Initialization data for the jupyterlab-jsoncrack extension.
 */
const plugin: JupyterFrontEndPlugin<void> = {
  id: PLUGIN_ID,
  description:
    'Use JSON Crack as a document viewer for JSON, YAML, and CSV files.',
  autoStart: true,
  requires: [ISettingRegistry],
  optional: [IToolbarWidgetRegistry, IThemeManager, ITranslator],
  activate: async (
    app: JupyterFrontEnd,
    settingRegistry: ISettingRegistry,
    toolbarRegistry: IToolbarWidgetRegistry | null,
    themeManager: IThemeManager | null,
    translator_: ITranslator | null
  ): Promise<void> => {
    const translator = translator_ ?? nullTranslator;
    let settings: ISettingRegistry.ISettings | null = null;
    const getSettings = () => settings;

    let toolbarFactory: ReturnType<typeof createToolbarFactory> | undefined;

    if (toolbarRegistry) {
      registerToolbarItems(toolbarRegistry, getSettings);
      toolbarFactory = createToolbarFactory(
        toolbarRegistry,
        settingRegistry,
        FACTORY_NAME,
        PLUGIN_ID,
        translator
      );
    }

    settings = await loadSettings(settingRegistry);

    const factory = new JSONCrackWidgetFactory({
      settings,
      themeManager,
      toolbarFactory
    });

    registerOpenWithIcon(app);
    app.docRegistry.addWidgetFactory(factory);
    applyDefaultViewerSetting(app, settings);

    settings?.changed.connect(() => {
      applyDefaultViewerSetting(app, settings);
    });
  }
};

export default plugin;
