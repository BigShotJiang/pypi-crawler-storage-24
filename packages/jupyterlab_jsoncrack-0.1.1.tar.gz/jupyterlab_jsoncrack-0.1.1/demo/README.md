# JupyterLab JSON Crack Demo

This directory contains a JupyterLite deployment for showcasing
[`jupyterlab-jsoncrack`](https://github.com/jtpio/jupyterlab-jsoncrack).

The demo bundles the local extension from the repository root and configures
JSON Crack as the default opener for `.json`, `.yaml`, `.yml`, and `.csv`
files.

## Local development

```bash
uv sync --locked
uv run jupyter lite build
uv run jupyter lite serve
```

Once the site is running, open `jsoncrack_demo.ipynb` from the file browser and
then double-click any bundled supported document to open it in JSON Crack.
