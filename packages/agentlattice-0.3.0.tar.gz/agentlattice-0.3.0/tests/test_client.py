"""
Tests for the AgentLattice Python SDK — mirrors the TS sdk.test.ts coverage.

All HTTP is mocked via respx. Tests run with asyncio_mode="auto" (pytest-asyncio).
"""

import pytest
import respx
import httpx

from agentlattice import (
    AgentLattice,
    AgentLatticeError,
    AgentLatticeDeniedError,
    AgentLatticeTimeoutError,
)

FAKE_API_KEY = "al_test_key_abc123"
BASE_URL = "http://localhost:3000"


def make_client(**kwargs):
    return AgentLattice(
        api_key=FAKE_API_KEY,
        base_url=BASE_URL,
        gate_poll_interval_ms=10,  # fast for tests
        **kwargs,
    )


# ── Constructor ────────────────────────────────────────────────────────────────

def test_constructor_raises_without_api_key():
    with pytest.raises(AgentLatticeError) as exc_info:
        AgentLattice(api_key="")
    assert exc_info.value.code == "MISSING_API_KEY"


def test_constructor_strips_trailing_slash():
    al = AgentLattice(api_key=FAKE_API_KEY, base_url="https://example.com/")
    assert al._base_url == "https://example.com"


# ── execute() ─────────────────────────────────────────────────────────────────

@respx.mock
async def test_execute_submits_action_and_returns_result():
    route = respx.post(f"{BASE_URL}/api/v1/actions").mock(
        return_value=httpx.Response(
            200,
            json={"status": "executed", "audit_event_id": "ae-123"},
        )
    )

    al = make_client()
    result = await al.execute("code.commit")

    assert result.status == "executed"
    assert result.audit_event_id == "ae-123"
    assert route.called
    request = route.calls[0].request
    assert request.headers["Authorization"] == f"Bearer {FAKE_API_KEY}"
    assert "X-AL-Event-ID" in request.headers


@respx.mock
async def test_execute_raises_on_401():
    respx.post(f"{BASE_URL}/api/v1/actions").mock(
        return_value=httpx.Response(
            401,
            json={"error": "INVALID_API_KEY"},
        )
    )

    al = make_client()
    with pytest.raises(AgentLatticeError) as exc_info:
        await al.execute("code.commit")
    assert exc_info.value.code == "INVALID_API_KEY"


@respx.mock
async def test_execute_returns_result_for_202_approval_pending():
    respx.post(f"{BASE_URL}/api/v1/actions").mock(
        return_value=httpx.Response(
            202,
            json={
                "status": "requested",
                "audit_event_id": "ae-456",
                "approval_id": "apr-789",
            },
        )
    )

    al = make_client()
    result = await al.execute("file.delete")
    assert result.status == "requested"
    assert result.approval_id == "apr-789"


@respx.mock
async def test_execute_respects_provided_event_id():
    route = respx.post(f"{BASE_URL}/api/v1/actions").mock(
        return_value=httpx.Response(
            200,
            json={"status": "executed", "audit_event_id": "ae-idem"},
        )
    )

    from agentlattice import ActionOptions

    al = make_client()
    await al.execute("code.commit", ActionOptions(event_id="my-custom-id"))

    request = route.calls[0].request
    assert request.headers["X-AL-Event-ID"] == "my-custom-id"


@respx.mock
async def test_execute_returns_enriched_result_with_denial_fields():
    conditions = [{"field": "pr_size", "operator": "lt", "expected": 100, "result": False}]
    respx.post(f"{BASE_URL}/api/v1/actions").mock(
        return_value=httpx.Response(
            200,
            json={
                "status": "denied",
                "denial_reason": "CONDITIONS_DENIED",
                "audit_event_id": "ae-exec-deny",
                "policy_name": "PR merge policy",
                "conditions_evaluated": conditions,
            },
        )
    )

    al = make_client()
    result = await al.execute("pr.merge")
    assert result.status == "denied"
    assert result.denial_reason == "CONDITIONS_DENIED"
    assert result.policy_name == "PR merge policy"
    assert len(result.conditions_evaluated) == 1
    assert result.conditions_evaluated[0].field == "pr_size"
    assert result.conditions_evaluated[0].result is False


@respx.mock
async def test_execute_returns_policy_name_on_executed_status():
    respx.post(f"{BASE_URL}/api/v1/actions").mock(
        return_value=httpx.Response(
            200,
            json={
                "status": "executed",
                "audit_event_id": "ae-exec-ok",
                "policy_name": "Auto-execute policy",
            },
        )
    )

    al = make_client()
    result = await al.execute("file.read")
    assert result.status == "executed"
    assert result.policy_name == "Auto-execute policy"


# ── gate() ────────────────────────────────────────────────────────────────────

@respx.mock
async def test_gate_resolves_immediately_if_auto_executed():
    respx.post(f"{BASE_URL}/api/v1/actions").mock(
        return_value=httpx.Response(
            200,
            json={"status": "executed", "audit_event_id": "ae-auto"},
        )
    )

    al = make_client()
    result = await al.gate("read.file")
    assert result is None


@respx.mock
async def test_gate_raises_on_policy_not_found():
    respx.post(f"{BASE_URL}/api/v1/actions").mock(
        return_value=httpx.Response(
            403,
            json={"status": "policy_not_found", "audit_event_id": "ae-nopol"},
        )
    )

    al = make_client()
    with pytest.raises(AgentLatticeError):
        await al.gate("unknown.action")


@respx.mock
async def test_gate_polls_and_resolves_when_approved():
    poll_count = 0

    def actions_handler(request):
        return httpx.Response(
            202,
            json={
                "status": "requested",
                "audit_event_id": "ae-poll",
                "approval_id": "apr-poll",
            },
        )

    def poll_handler(request):
        nonlocal poll_count
        poll_count += 1
        status = "pending" if poll_count < 3 else "approved"
        return httpx.Response(200, json={"status": status})

    respx.post(f"{BASE_URL}/api/v1/actions").mock(side_effect=actions_handler)
    respx.get(f"{BASE_URL}/api/approvals/apr-poll/status").mock(side_effect=poll_handler)

    al = make_client(gate_poll_timeout_ms=5_000)
    await al.gate("pr.merge")
    assert poll_count == 3


@respx.mock
async def test_gate_raises_denied_if_approval_denied():
    respx.post(f"{BASE_URL}/api/v1/actions").mock(
        return_value=httpx.Response(
            202,
            json={
                "status": "requested",
                "audit_event_id": "ae-deny",
                "approval_id": "apr-deny",
            },
        )
    )
    respx.get(f"{BASE_URL}/api/approvals/apr-deny/status").mock(
        return_value=httpx.Response(200, json={"status": "denied"})
    )

    al = make_client()
    with pytest.raises(AgentLatticeDeniedError):
        await al.gate("dangerous.action")


@respx.mock
async def test_gate_immediate_denied_conditions_denied():
    conditions = [{"field": "pr_size", "operator": "lt", "expected": 100, "result": False}]
    respx.post(f"{BASE_URL}/api/v1/actions").mock(
        return_value=httpx.Response(
            200,
            json={
                "status": "denied",
                "denial_reason": "CONDITIONS_DENIED",
                "audit_event_id": "ae-cond-deny",
                "policy_name": "PR merge policy",
                "conditions_evaluated": conditions,
            },
        )
    )

    al = make_client()
    with pytest.raises(AgentLatticeDeniedError) as exc_info:
        await al.gate("pr.merge")

    err = exc_info.value
    assert err.reason == "CONDITIONS_DENIED"
    assert err.policy == "PR merge policy"
    assert len(err.conditions) == 1
    assert err.conditions[0].field == "pr_size"
    assert err.approval_id is None


@respx.mock
async def test_gate_immediate_denied_policy_tampered():
    respx.post(f"{BASE_URL}/api/v1/actions").mock(
        return_value=httpx.Response(
            200,
            json={
                "status": "denied",
                "denial_reason": "POLICY_TAMPERED",
                "audit_event_id": "ae-tamper",
                "policy_name": "PR merge policy",
                "conditions_evaluated": [],
            },
        )
    )

    al = make_client()
    with pytest.raises(AgentLatticeDeniedError) as exc_info:
        await al.gate("pr.merge")

    err = exc_info.value
    assert err.reason == "POLICY_TAMPERED"
    assert err.conditions == []


@respx.mock
async def test_gate_poll_denial_carries_denied_by_reviewer_and_approval_id():
    respx.post(f"{BASE_URL}/api/v1/actions").mock(
        return_value=httpx.Response(
            202,
            json={
                "status": "requested",
                "audit_event_id": "ae-reviewer-deny",
                "approval_id": "apr-reviewer",
            },
        )
    )
    respx.get(f"{BASE_URL}/api/approvals/apr-reviewer/status").mock(
        return_value=httpx.Response(200, json={"status": "denied"})
    )

    al = make_client()
    with pytest.raises(AgentLatticeDeniedError) as exc_info:
        await al.gate("dangerous.action")

    err = exc_info.value
    assert err.approval_id == "apr-reviewer"
    assert err.reason == "DENIED_BY_REVIEWER"


@respx.mock
async def test_gate_raises_timeout_when_poll_deadline_exceeded():
    respx.post(f"{BASE_URL}/api/v1/actions").mock(
        return_value=httpx.Response(
            202,
            json={
                "status": "requested",
                "audit_event_id": "ae-timeout",
                "approval_id": "apr-timeout",
            },
        )
    )
    respx.get(f"{BASE_URL}/api/approvals/apr-timeout/status").mock(
        return_value=httpx.Response(200, json={"status": "pending"})
    )

    al = make_client(gate_poll_timeout_ms=25)  # 25ms deadline, 10ms interval
    with pytest.raises(AgentLatticeTimeoutError) as exc_info:
        await al.gate("slow.action")

    assert exc_info.value.approval_id == "apr-timeout"


# ── Sync wrappers ─────────────────────────────────────────────────────────────

@respx.mock
def test_gate_sync_approves_and_returns_none():
    respx.post(f"{BASE_URL}/api/v1/actions").mock(
        return_value=httpx.Response(
            200,
            json={"status": "executed", "audit_event_id": "ae-sync-gate"},
        )
    )
    al = make_client()
    result = al.gate_sync("read.file")
    assert result is None


@respx.mock
def test_execute_sync_returns_action_result():
    respx.post(f"{BASE_URL}/api/v1/actions").mock(
        return_value=httpx.Response(
            200,
            json={"status": "executed", "audit_event_id": "ae-sync-exec"},
        )
    )
    al = make_client()
    result = al.execute_sync("code.commit")
    assert result.status == "executed"
    assert result.audit_event_id == "ae-sync-exec"
