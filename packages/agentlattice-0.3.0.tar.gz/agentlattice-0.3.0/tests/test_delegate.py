"""
Tests for AgentLattice Python SDK delegation support.

Covers: DelegationContext lifecycle, DelegatedAgent header injection,
client-side validation, parallel delegations, and sync wrappers.
"""

import asyncio

import httpx
import pytest
import respx

from agentlattice.client import (
    AgentLattice,
    AgentLatticeError,
    DelegatedAgent,
    DelegationContext,
)

BASE_URL = "https://agentlattice.com"
PARENT_KEY = "al_parent_key_abc123"
CHILD_KEY = "al_child_key_xyz789"
DELEGATION_ID = "deleg_test_001"


def _delegate_response():
    return httpx.Response(
        200,
        json={
            "delegation_id": DELEGATION_ID,
            "child_api_key": CHILD_KEY,
        },
    )


def _action_response(status="executed"):
    return httpx.Response(
        200,
        json={
            "status": status,
            "audit_event_id": "evt_test_001",
        },
    )


# ── TestDelegate: async context manager lifecycle ────────────────────────────


class TestDelegate:
    """DelegationContext __aenter__ / __aexit__ lifecycle."""

    @pytest.mark.asyncio
    @respx.mock
    async def test_aenter_calls_post_delegate(self):
        """__aenter__ POSTs to /api/v1/delegate and returns a DelegatedAgent."""
        route = respx.post(f"{BASE_URL}/api/v1/delegate").mock(
            return_value=_delegate_response()
        )
        revoke = respx.delete(f"{BASE_URL}/api/v1/delegate/{DELEGATION_ID}").mock(
            return_value=httpx.Response(200)
        )

        al = AgentLattice(api_key=PARENT_KEY, base_url=BASE_URL)
        async with al.delegate("worker", capabilities=["read"], ttl=60) as sub:
            assert isinstance(sub, DelegatedAgent)

        assert route.called
        req = route.calls.last.request
        assert req.headers["authorization"] == f"Bearer {PARENT_KEY}"

    @pytest.mark.asyncio
    @respx.mock
    async def test_aexit_calls_delete_normal(self):
        """__aexit__ DELETEs the delegation on normal exit."""
        respx.post(f"{BASE_URL}/api/v1/delegate").mock(
            return_value=_delegate_response()
        )
        revoke = respx.delete(f"{BASE_URL}/api/v1/delegate/{DELEGATION_ID}").mock(
            return_value=httpx.Response(200)
        )

        al = AgentLattice(api_key=PARENT_KEY, base_url=BASE_URL)
        async with al.delegate("worker", capabilities=["read"], ttl=60):
            pass

        assert revoke.called

    @pytest.mark.asyncio
    @respx.mock
    async def test_aexit_calls_delete_on_exception(self):
        """__aexit__ DELETEs the delegation even when an exception occurs."""
        respx.post(f"{BASE_URL}/api/v1/delegate").mock(
            return_value=_delegate_response()
        )
        revoke = respx.delete(f"{BASE_URL}/api/v1/delegate/{DELEGATION_ID}").mock(
            return_value=httpx.Response(200)
        )

        al = AgentLattice(api_key=PARENT_KEY, base_url=BASE_URL)
        with pytest.raises(RuntimeError, match="boom"):
            async with al.delegate("worker", capabilities=["read"], ttl=60):
                raise RuntimeError("boom")

        assert revoke.called

    @pytest.mark.asyncio
    @respx.mock
    async def test_exception_propagates_after_cleanup(self):
        """The original exception propagates even after cleanup succeeds."""
        respx.post(f"{BASE_URL}/api/v1/delegate").mock(
            return_value=_delegate_response()
        )
        respx.delete(f"{BASE_URL}/api/v1/delegate/{DELEGATION_ID}").mock(
            return_value=httpx.Response(200)
        )

        al = AgentLattice(api_key=PARENT_KEY, base_url=BASE_URL)
        with pytest.raises(ValueError, match="intentional"):
            async with al.delegate("worker", capabilities=["write"], ttl=120):
                raise ValueError("intentional")

    @pytest.mark.asyncio
    @respx.mock
    async def test_auto_cleanup_on_error(self):
        """Cleanup is attempted even if the DELETE endpoint returns 500 initially."""
        respx.post(f"{BASE_URL}/api/v1/delegate").mock(
            return_value=_delegate_response()
        )
        # First call 500, second call 200 (retry logic in _cleanup_delegation)
        revoke = respx.delete(f"{BASE_URL}/api/v1/delegate/{DELEGATION_ID}").mock(
            side_effect=[
                httpx.Response(500),
                httpx.Response(200),
            ]
        )

        al = AgentLattice(api_key=PARENT_KEY, base_url=BASE_URL)
        async with al.delegate("worker", capabilities=["read"], ttl=60):
            pass

        assert revoke.call_count == 2


# ── TestDelegatedAgent: header injection ─────────────────────────────────────


class TestDelegatedAgent:
    """DelegatedAgent injects correct headers on execute() and gate()."""

    @pytest.mark.asyncio
    @respx.mock
    async def test_execute_sends_delegation_id_header(self):
        """execute() includes X-AL-Delegation-ID in the request."""
        route = respx.post(f"{BASE_URL}/api/v1/actions").mock(
            return_value=_action_response()
        )

        agent = DelegatedAgent(
            api_key=CHILD_KEY,
            base_url=BASE_URL,
            delegation_id=DELEGATION_ID,
            parent_api_key=PARENT_KEY,
        )
        await agent.execute("read_data")

        req = route.calls.last.request
        assert req.headers["x-al-delegation-id"] == DELEGATION_ID

    @pytest.mark.asyncio
    @respx.mock
    async def test_execute_sends_child_api_key(self):
        """execute() authenticates with the child_api_key, not the parent."""
        route = respx.post(f"{BASE_URL}/api/v1/actions").mock(
            return_value=_action_response()
        )

        agent = DelegatedAgent(
            api_key=CHILD_KEY,
            base_url=BASE_URL,
            delegation_id=DELEGATION_ID,
            parent_api_key=PARENT_KEY,
        )
        await agent.execute("read_data")

        req = route.calls.last.request
        assert req.headers["authorization"] == f"Bearer {CHILD_KEY}"

    @pytest.mark.asyncio
    @respx.mock
    async def test_gate_works_with_delegation_id(self):
        """gate() succeeds when action is executed, delegation_id still sent."""
        route = respx.post(f"{BASE_URL}/api/v1/actions").mock(
            return_value=_action_response("executed")
        )

        agent = DelegatedAgent(
            api_key=CHILD_KEY,
            base_url=BASE_URL,
            delegation_id=DELEGATION_ID,
            parent_api_key=PARENT_KEY,
        )
        await agent.gate("read_data")  # should not raise

        req = route.calls.last.request
        assert req.headers["x-al-delegation-id"] == DELEGATION_ID


# ── TestClientSideValidation ─────────────────────────────────────────────────


class TestClientSideValidation:
    """Client-side validation before any network call."""

    def test_raises_if_capabilities_empty(self):
        al = AgentLattice(api_key=PARENT_KEY, base_url=BASE_URL)
        with pytest.raises(AgentLatticeError, match="non-empty"):
            al.delegate("worker", capabilities=[], ttl=60)

    def test_raises_if_ttl_zero(self):
        al = AgentLattice(api_key=PARENT_KEY, base_url=BASE_URL)
        with pytest.raises(AgentLatticeError, match="positive"):
            al.delegate("worker", capabilities=["read"], ttl=0)

    def test_raises_if_ttl_negative(self):
        al = AgentLattice(api_key=PARENT_KEY, base_url=BASE_URL)
        with pytest.raises(AgentLatticeError, match="positive"):
            al.delegate("worker", capabilities=["read"], ttl=-10)


# ── TestParallel ─────────────────────────────────────────────────────────────


class TestParallel:
    """ParallelDelegation runs N delegations concurrently."""

    @pytest.mark.asyncio
    @respx.mock
    async def test_parallel_runs_n_concurrently(self):
        """parallel() enters all contexts via asyncio.gather, returns ordered list."""
        ids = ["deleg_a", "deleg_b", "deleg_c"]
        keys = ["key_a", "key_b", "key_c"]

        respx.post(f"{BASE_URL}/api/v1/delegate").mock(
            side_effect=[
                httpx.Response(200, json={"delegation_id": ids[i], "child_api_key": keys[i]})
                for i in range(3)
            ]
        )
        for did in ids:
            respx.delete(f"{BASE_URL}/api/v1/delegate/{did}").mock(
                return_value=httpx.Response(200)
            )

        al = AgentLattice(api_key=PARENT_KEY, base_url=BASE_URL)
        contexts = [
            al.delegate(f"worker-{i}", capabilities=["cap"], ttl=60)
            for i in range(3)
        ]

        async with AgentLattice.parallel(*contexts) as agents:
            assert len(agents) == 3
            for i, agent in enumerate(agents):
                assert isinstance(agent, DelegatedAgent)
                assert agent._delegation_id == ids[i]

    @pytest.mark.asyncio
    @respx.mock
    async def test_parallel_returns_results_in_order(self):
        """Results from parallel delegations maintain input order."""
        ids = ["deleg_first", "deleg_second"]
        keys = ["key_first", "key_second"]

        respx.post(f"{BASE_URL}/api/v1/delegate").mock(
            side_effect=[
                httpx.Response(200, json={"delegation_id": ids[i], "child_api_key": keys[i]})
                for i in range(2)
            ]
        )
        for did in ids:
            respx.delete(f"{BASE_URL}/api/v1/delegate/{did}").mock(
                return_value=httpx.Response(200)
            )

        al = AgentLattice(api_key=PARENT_KEY, base_url=BASE_URL)
        ctx_a = al.delegate("first", capabilities=["a"], ttl=30)
        ctx_b = al.delegate("second", capabilities=["b"], ttl=30)

        async with AgentLattice.parallel(ctx_a, ctx_b) as agents:
            assert agents[0]._delegation_id == "deleg_first"
            assert agents[1]._delegation_id == "deleg_second"


# ── TestSyncWrappers ─────────────────────────────────────────────────────────


class TestSyncWrappers:
    """Synchronous delegation wrappers work from a non-async context."""

    @respx.mock
    def test_delegate_sync_works(self):
        """delegate_sync() creates and cleans up a delegation synchronously."""
        respx.post(f"{BASE_URL}/api/v1/delegate").mock(
            return_value=_delegate_response()
        )
        revoke = respx.delete(f"{BASE_URL}/api/v1/delegate/{DELEGATION_ID}").mock(
            return_value=httpx.Response(200)
        )

        al = AgentLattice(api_key=PARENT_KEY, base_url=BASE_URL)
        with al.delegate_sync("worker", capabilities=["read"], ttl=60) as sub:
            assert isinstance(sub, DelegatedAgent)
            assert sub._delegation_id == DELEGATION_ID

        assert revoke.called
