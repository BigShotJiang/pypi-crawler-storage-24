"""
agentlattice — Governance SDK for AI agents.

Usage:
    import asyncio
    from agentlattice import AgentLattice, AgentLatticeDeniedError

    al = AgentLattice(api_key="al_...")

    # gate() blocks until approved (or raises if denied/timeout)
    async def main():
        await al.gate("code.commit")

    asyncio.run(main())

    # Sync wrappers if you're not in an async context
    al.gate_sync("code.commit")
"""

from agentlattice.client import (
    AgentLattice,
    AgentLatticeError,
    AgentLatticeDeniedError,
    AgentLatticeTimeoutError,
    ActionResult,
    ActionOptions,
    ConditionResult,
    DelegatedAgent,
    DelegationContext,
    SyncDelegationContext,
    ParallelDelegation,
    SyncParallelDelegation,
)

__all__ = [
    "AgentLattice",
    "AgentLatticeError",
    "AgentLatticeDeniedError",
    "AgentLatticeTimeoutError",
    "ActionResult",
    "ActionOptions",
    "ConditionResult",
    "DelegatedAgent",
    "DelegationContext",
    "SyncDelegationContext",
    "ParallelDelegation",
    "SyncParallelDelegation",
]

__version__ = "0.3.0"
