"""
AgentLattice Python SDK — async-first governance client.

Mirrors the TypeScript SDK behavior exactly:
- execute() → submit action, return immediately
- gate()     → submit action, block until approved (or raise)
- *_sync()   → synchronous wrappers for non-async contexts
"""

from __future__ import annotations

import asyncio
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import httpx


# ── Types ─────────────────────────────────────────────────────────────────────

@dataclass
class ConditionResult:
    field: str
    operator: str
    expected: Any
    result: bool

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "ConditionResult":
        return cls(
            field=d["field"],
            operator=d["operator"],
            expected=d["expected"],
            result=d["result"],
        )


@dataclass
class ActionResult:
    status: str  # "executed" | "requested" | "denied" | "timed_out" | "policy_not_found"
    audit_event_id: str
    approval_id: Optional[str] = None
    message: Optional[str] = None
    timeout_at: Optional[str] = None
    denial_reason: Optional[str] = None
    policy_name: Optional[str] = None
    conditions_evaluated: List[ConditionResult] = field(default_factory=list)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "ActionResult":
        return cls(
            status=d["status"],
            audit_event_id=d["audit_event_id"],
            approval_id=d.get("approval_id"),
            message=d.get("message"),
            timeout_at=d.get("timeout_at"),
            denial_reason=d.get("denial_reason"),
            policy_name=d.get("policy_name"),
            conditions_evaluated=[
                ConditionResult.from_dict(c)
                for c in d.get("conditions_evaluated", [])
            ],
        )


@dataclass
class ActionOptions:
    data_accessed: Optional[List[Dict[str, Any]]] = None
    metadata: Optional[Dict[str, Any]] = None
    event_id: Optional[str] = None


# ── Errors ────────────────────────────────────────────────────────────────────

class AgentLatticeError(Exception):
    def __init__(self, code: str, message: str, details: Any = None) -> None:
        super().__init__(message)
        self.code = code
        self.details = details


class AgentLatticeDeniedError(AgentLatticeError):
    def __init__(
        self,
        approval_id: Optional[str],
        reason: Optional[str] = None,
        policy: Optional[str] = None,
        conditions: Optional[List[ConditionResult]] = None,
    ) -> None:
        if approval_id:
            msg = f"Action was denied (approval_id: {approval_id})"
        else:
            msg = f"Action was denied{f' ({reason})' if reason else ''}"
        super().__init__("ACTION_DENIED", msg)
        self.approval_id = approval_id
        self.reason = reason
        self.policy = policy
        self.conditions = conditions or []


class AgentLatticeTimeoutError(AgentLatticeError):
    def __init__(self, approval_id: str) -> None:
        super().__init__(
            "APPROVAL_TIMEOUT",
            f"Approval timed out (approval_id: {approval_id})",
        )
        self.approval_id = approval_id


# ── Client ────────────────────────────────────────────────────────────────────

_DEFAULT_BASE_URL = "https://agentlattice.com"
_DEFAULT_GATE_POLL_TIMEOUT_MS = 8 * 60 * 60 * 1000  # 8 hours
_DEFAULT_GATE_POLL_INTERVAL_MS = 5_000
_RETRY_BACKOFF_S = [1.0, 2.0, 4.0]  # exponential backoff for 5xx / network errors


class AgentLattice:
    """
    Governance-aware client for AI agents.

    Parameters
    ----------
    api_key:
        Bearer token from your operator config's API key.
    base_url:
        AgentLattice API base URL. Defaults to https://agentlattice.com.
        Override for self-hosted or staging environments.
    gate_poll_timeout_ms:
        How long (ms) gate() should poll for approval resolution.
        Defaults to 8 hours (matching the default policy timeout).
    gate_poll_interval_ms:
        Poll interval when waiting for approval. Defaults to 5000ms.
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = _DEFAULT_BASE_URL,
        gate_poll_timeout_ms: int = _DEFAULT_GATE_POLL_TIMEOUT_MS,
        gate_poll_interval_ms: int = _DEFAULT_GATE_POLL_INTERVAL_MS,
    ) -> None:
        if not api_key or not api_key.strip():
            raise AgentLatticeError("MISSING_API_KEY", "AgentLattice requires an api_key")
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._gate_poll_timeout_ms = gate_poll_timeout_ms
        self._gate_poll_interval_ms = gate_poll_interval_ms

    # ── Class methods: programmatic agent creation ───────────────────────────

    @classmethod
    async def register(
        cls,
        service_key: str,
        name: str,
        *,
        description: Optional[str] = None,
        base_url: str = _DEFAULT_BASE_URL,
        gate_poll_timeout_ms: int = _DEFAULT_GATE_POLL_TIMEOUT_MS,
        gate_poll_interval_ms: int = _DEFAULT_GATE_POLL_INTERVAL_MS,
    ) -> tuple["AgentLattice", Dict[str, Any]]:
        """
        Programmatically create a new agent using an org-level service key.
        Returns a configured AgentLattice client and the new agent's config dict.

        Usage:
            client, config = await AgentLattice.register(service_key, "my-agent")
            await client.execute("test.hello")
        """
        url = base_url.rstrip("/")
        async with httpx.AsyncClient(timeout=30.0) as http:
            response = await http.post(
                f"{url}/api/agents/register",
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {service_key}",
                },
                json={"name": name, "description": description},
            )

        if not response.is_success:
            try:
                body = response.json()
            except Exception:
                body = {}
            raise AgentLatticeError(
                body.get("error", "REGISTER_FAILED"),
                f"Register returned {response.status_code}",
                body,
            )

        data = response.json()
        client = cls(
            api_key=data["api_key"],
            base_url=url,
            gate_poll_timeout_ms=gate_poll_timeout_ms,
            gate_poll_interval_ms=gate_poll_interval_ms,
        )
        config = {
            "id": data["id"],
            "name": data["name"],
            "api_key": data["api_key"],
            "created_at": data["created_at"],
        }
        return client, config

    @classmethod
    def register_sync(
        cls,
        service_key: str,
        name: str,
        **kwargs: Any,
    ) -> tuple["AgentLattice", Dict[str, Any]]:
        """Synchronous wrapper around register()."""
        return _run_coro_sync(cls.register(service_key, name, **kwargs))

    # ── Async API ─────────────────────────────────────────────────────────────

    async def execute(
        self,
        action_type: str,
        options: Optional[ActionOptions] = None,
    ) -> ActionResult:
        """
        Submit an action and return immediately with the result.

        If the policy requires approval, status will be "requested" with an
        approval_id. Does not block.

        Retries up to 3 times with exponential backoff on 5xx / network errors.
        """
        opts = options or ActionOptions()
        event_id = opts.event_id or str(uuid.uuid4())

        async with httpx.AsyncClient(timeout=30.0) as client:
            for attempt, backoff in enumerate([*_RETRY_BACKOFF_S, None]):
                # Regenerate timestamp on each attempt to avoid replaying a stale value
                payload = {
                    "action_type": action_type,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "data_accessed": opts.data_accessed or [],
                    "metadata": opts.metadata or {},
                }
                try:
                    response = await client.post(
                        f"{self._base_url}/api/v1/actions",
                        headers={
                            "Content-Type": "application/json",
                            "Authorization": f"Bearer {self._api_key}",
                            "X-AL-Event-ID": event_id,
                        },
                        json=payload,
                    )
                except httpx.RequestError as exc:
                    if backoff is not None:
                        await asyncio.sleep(backoff)
                        continue
                    raise AgentLatticeError(
                        "NETWORK_ERROR",
                        f"Network error: {exc}",
                        exc,
                    )

                if not response.is_success and response.status_code not in (202, 409):
                    try:
                        body = response.json()
                    except Exception:
                        body = {}

                    # Retry on 5xx transient errors
                    if response.status_code >= 500 and backoff is not None:
                        await asyncio.sleep(backoff)
                        continue

                    raise AgentLatticeError(
                        body.get("error", "API_ERROR"),
                        f"AgentLattice API returned {response.status_code}",
                        body,
                    )

                return ActionResult.from_dict(response.json())

        # Unreachable — loop always returns or raises
        raise AgentLatticeError("INTERNAL", "Unexpected retry loop exit")

    async def gate(
        self,
        action_type: str,
        options: Optional[ActionOptions] = None,
    ) -> None:
        """
        Submit an action and block until it is approved or denied.

        Raises AgentLatticeDeniedError if denied.
        Raises AgentLatticeTimeoutError if approval times out.

        Use this when your agent MUST have approval before proceeding.
        For fire-and-forget (e.g., logging), use execute() instead.
        """
        result = await self.execute(action_type, options)

        if result.status == "executed":
            return

        if result.status == "policy_not_found":
            raise AgentLatticeError(
                "POLICY_NOT_FOUND",
                f"No policy configured for action_type '{action_type}'. Action blocked.",
                result,
            )

        if result.status == "denied":
            # Immediate denial — policy conditions or tamper check. No approval_id.
            raise AgentLatticeDeniedError(
                result.approval_id,
                result.denial_reason,
                result.policy_name,
                result.conditions_evaluated,
            )

        if result.status != "requested" or not result.approval_id:
            raise AgentLatticeError(
                "UNEXPECTED_STATUS",
                f"Unexpected status: {result.status}",
                result,
            )

        # Poll for approval resolution
        approval_id = result.approval_id
        deadline_ms = _now_ms() + self._gate_poll_timeout_ms

        async with httpx.AsyncClient(timeout=30.0) as client:
            while _now_ms() < deadline_ms:
                await asyncio.sleep(self._gate_poll_interval_ms / 1000)

                try:
                    poll_response = await client.get(
                        f"{self._base_url}/api/approvals/{approval_id}/status",
                        headers={"Authorization": f"Bearer {self._api_key}"},
                    )
                except httpx.RequestError:
                    # Transient network error during poll — keep trying until deadline
                    continue

                if not poll_response.is_success:
                    if 400 <= poll_response.status_code < 500:
                        # Permanent client error (approval not found, auth failure) — abort
                        raise AgentLatticeError(
                            "POLL_ERROR",
                            f"Approval status check failed with {poll_response.status_code}",
                            {"approval_id": approval_id},
                        )
                    # Transient server error — keep trying until deadline
                    continue

                poll_data = poll_response.json()
                poll_status = poll_data.get("status", "")

                if poll_status == "approved":
                    return

                if poll_status == "denied":
                    # Human reviewer denied — approvalId present, no conditions data
                    raise AgentLatticeDeniedError(approval_id, "DENIED_BY_REVIEWER")

                if poll_status == "timed_out":
                    raise AgentLatticeTimeoutError(approval_id)

                # "pending" or "escalated" — keep polling

        # Exhausted our local poll timeout
        raise AgentLatticeTimeoutError(approval_id)

    # ── Delegation ──────────────────────────────────────────────────────────

    def delegate(
        self,
        name: str,
        *,
        capabilities: List[str],
        ttl: int,
    ) -> "DelegationContext":
        """
        Create a scoped ephemeral sub-agent as an async context manager.

        Usage:
            async with al.delegate("data-processor",
                capabilities=["read_data", "write_results"],
                ttl=300
            ) as sub:
                await sub.execute("read_data")
                await sub.execute("write_results")
        """
        if not capabilities:
            raise AgentLatticeError("INVALID_CAPABILITIES", "capabilities must be a non-empty list")
        if ttl <= 0:
            raise AgentLatticeError("INVALID_TTL", "ttl must be a positive number")

        return DelegationContext(
            parent_api_key=self._api_key,
            base_url=self._base_url,
            name=name,
            capabilities=capabilities,
            ttl_seconds=ttl,
        )

    def delegate_sync(
        self,
        name: str,
        *,
        capabilities: List[str],
        ttl: int,
    ) -> "SyncDelegationContext":
        """Synchronous context manager wrapper around delegate()."""
        if not capabilities:
            raise AgentLatticeError("INVALID_CAPABILITIES", "capabilities must be a non-empty list")
        if ttl <= 0:
            raise AgentLatticeError("INVALID_TTL", "ttl must be a positive number")

        return SyncDelegationContext(
            parent_api_key=self._api_key,
            base_url=self._base_url,
            name=name,
            capabilities=capabilities,
            ttl_seconds=ttl,
        )

    @staticmethod
    def parallel(*delegates: "DelegationContext") -> "ParallelDelegation":
        """
        Run N delegations concurrently via asyncio.gather.
        If any raises, ALL are cleaned up.
        """
        return ParallelDelegation(list(delegates))

    @staticmethod
    def parallel_sync(*delegates: "DelegationContext") -> "SyncParallelDelegation":
        """Synchronous wrapper around parallel()."""
        return SyncParallelDelegation(list(delegates))

    # ── Sync wrappers ─────────────────────────────────────────────────────────

    def execute_sync(
        self,
        action_type: str,
        options: Optional[ActionOptions] = None,
    ) -> ActionResult:
        """Synchronous wrapper around execute(). Works in both sync and async contexts."""
        return _run_coro_sync(self.execute(action_type, options))

    def gate_sync(
        self,
        action_type: str,
        options: Optional[ActionOptions] = None,
    ) -> None:
        """Synchronous wrapper around gate(). Works in both sync and async contexts."""
        _run_coro_sync(self.gate(action_type, options))


# ── Helpers ───────────────────────────────────────────────────────────────────

def _now_ms() -> int:
    import time
    return int(time.time() * 1000)


_CLEANUP_RETRY_BACKOFF_S = [1.0, 2.0, 4.0]


async def _cleanup_delegation(
    base_url: str, parent_api_key: str, delegation_id: str
) -> None:
    """Revoke a delegation with retry + backoff."""
    for attempt, backoff in enumerate([*_CLEANUP_RETRY_BACKOFF_S, None]):
        try:
            async with httpx.AsyncClient(timeout=30.0) as http:
                response = await http.delete(
                    f"{base_url}/api/v1/delegate/{delegation_id}",
                    headers={"Authorization": f"Bearer {parent_api_key}"},
                )
            if response.is_success or response.status_code == 404:
                return
            if response.status_code >= 500 and backoff is not None:
                await asyncio.sleep(backoff)
                continue
            return
        except httpx.RequestError:
            if backoff is not None:
                await asyncio.sleep(backoff)
                continue
            import warnings
            warnings.warn(
                f"Delegation cleanup failed after retries for {delegation_id}"
            )


class DelegatedAgent:
    """
    A scoped sub-agent created by al.delegate(). All calls include
    X-AL-Delegation-ID so the server enforces scope at action time.
    """

    def __init__(
        self,
        api_key: str,
        base_url: str,
        delegation_id: str,
        parent_api_key: str,
    ) -> None:
        self._client = AgentLattice(api_key=api_key, base_url=base_url)
        self._delegation_id = delegation_id
        self._api_key = api_key
        self._base_url = base_url
        self._parent_api_key = parent_api_key

    async def execute(
        self,
        action_type: str,
        options: Optional[ActionOptions] = None,
    ) -> ActionResult:
        """Execute an action as the delegated agent."""
        opts = options or ActionOptions()
        event_id = opts.event_id or str(uuid.uuid4())

        async with httpx.AsyncClient(timeout=30.0) as http:
            response = await http.post(
                f"{self._base_url}/api/v1/actions",
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {self._api_key}",
                    "X-AL-Event-ID": event_id,
                    "X-AL-Delegation-ID": self._delegation_id,
                },
                json={
                    "action_type": action_type,
                    "timestamp": datetime.now(timezone.utc).isoformat(),
                    "data_accessed": opts.data_accessed or [],
                    "metadata": opts.metadata or {},
                },
            )

        if not response.is_success and response.status_code not in (202, 409):
            try:
                body = response.json()
            except Exception:
                body = {}
            raise AgentLatticeError(
                body.get("error", "API_ERROR"),
                f"AgentLattice API returned {response.status_code}",
                body,
            )

        return ActionResult.from_dict(response.json())

    def execute_sync(
        self, action_type: str, options: Optional[ActionOptions] = None
    ) -> ActionResult:
        return _run_coro_sync(self.execute(action_type, options))

    async def gate(
        self,
        action_type: str,
        options: Optional[ActionOptions] = None,
    ) -> None:
        """Gate an action as the delegated agent."""
        result = await self.execute(action_type, options)
        if result.status == "executed":
            return
        if result.status == "denied":
            raise AgentLatticeDeniedError(result.approval_id, result.denial_reason)
        raise AgentLatticeError(
            "UNEXPECTED_STATUS",
            f"Unexpected status: {result.status}",
        )

    def gate_sync(
        self, action_type: str, options: Optional[ActionOptions] = None
    ) -> None:
        _run_coro_sync(self.gate(action_type, options))

    def delegate(
        self,
        name: str,
        *,
        capabilities: List[str],
        ttl: int,
    ) -> "DelegationContext":
        """Create a sub-sub-delegation (chaining). Scope narrows further."""
        return self._client.delegate(name, capabilities=capabilities, ttl=ttl)


class DelegationContext:
    """Async context manager for delegation lifecycle."""

    def __init__(
        self,
        parent_api_key: str,
        base_url: str,
        name: str,
        capabilities: List[str],
        ttl_seconds: int,
    ) -> None:
        self._parent_api_key = parent_api_key
        self._base_url = base_url
        self._name = name
        self._capabilities = capabilities
        self._ttl_seconds = ttl_seconds
        self._delegation_id: Optional[str] = None

    async def __aenter__(self) -> DelegatedAgent:
        async with httpx.AsyncClient(timeout=30.0) as http:
            response = await http.post(
                f"{self._base_url}/api/v1/delegate",
                headers={
                    "Content-Type": "application/json",
                    "Authorization": f"Bearer {self._parent_api_key}",
                },
                json={
                    "name": self._name,
                    "capabilities": self._capabilities,
                    "ttl_seconds": self._ttl_seconds,
                },
            )

        if not response.is_success:
            try:
                body = response.json()
            except Exception:
                body = {}
            raise AgentLatticeError(
                body.get("error", "DELEGATE_FAILED"),
                f"Delegate returned {response.status_code}",
                body,
            )

        try:
            data = response.json()
        except Exception as e:
            # Server returned 2xx but malformed JSON. We can't extract the
            # delegation_id, so cleanup in __aexit__ won't be able to revoke.
            # The cron sweep will catch it when TTL expires.
            raise AgentLatticeError(
                "DELEGATE_PARSE_ERROR",
                f"Server returned {response.status_code} but response was not valid JSON: {e}",
                {},
            )

        self._delegation_id = data["delegation_id"]

        return DelegatedAgent(
            api_key=data["child_api_key"],
            base_url=self._base_url,
            delegation_id=data["delegation_id"],
            parent_api_key=self._parent_api_key,
        )

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        if self._delegation_id:
            await _cleanup_delegation(
                self._base_url, self._parent_api_key, self._delegation_id
            )


class SyncDelegationContext:
    """Synchronous context manager wrapper for delegation lifecycle."""

    def __init__(self, **kwargs: Any) -> None:
        self._ctx = DelegationContext(**kwargs)

    def __enter__(self) -> DelegatedAgent:
        return _run_coro_sync(self._ctx.__aenter__())

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        _run_coro_sync(self._ctx.__aexit__(exc_type, exc_val, exc_tb))


class ParallelDelegation:
    """Async context manager that enters N delegation contexts concurrently."""

    def __init__(self, contexts: List[DelegationContext]) -> None:
        self._contexts = contexts
        self._agents: List[DelegatedAgent] = []

    async def __aenter__(self) -> List[DelegatedAgent]:
        self._agents = await asyncio.gather(
            *(ctx.__aenter__() for ctx in self._contexts)
        )
        return self._agents

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        # Clean up ALL delegations, collecting errors
        results = await asyncio.gather(
            *(ctx.__aexit__(exc_type, exc_val, exc_tb) for ctx in self._contexts),
            return_exceptions=True,
        )
        errors = [r for r in results if isinstance(r, Exception)]
        if errors:
            import warnings
            for e in errors:
                warnings.warn(f"Delegation cleanup error: {e}")


class SyncParallelDelegation:
    """Synchronous wrapper for ParallelDelegation."""

    def __init__(self, contexts: List[DelegationContext]) -> None:
        self._parallel = ParallelDelegation(contexts)

    def __enter__(self) -> List[DelegatedAgent]:
        return _run_coro_sync(self._parallel.__aenter__())

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        _run_coro_sync(self._parallel.__aexit__(exc_type, exc_val, exc_tb))


def _run_coro_sync(coro: Any) -> Any:
    """
    Run a coroutine from a synchronous context.

    If called from inside a running event loop (e.g. LangGraph, FastAPI,
    CrewAI), executes in a new thread with its own event loop to avoid
    ``asyncio.run() cannot be called when another event loop is running``.
    """
    import concurrent.futures
    try:
        asyncio.get_running_loop()
        # Running inside an async context — dispatch to a thread pool.
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            return pool.submit(asyncio.run, coro).result()
    except RuntimeError:
        # No running loop — safe to call asyncio.run directly.
        return asyncio.run(coro)
