# xlsx_formula_compiler

Translate modern Excel formulas into OOXML-compliant syntax (e.g., adding _xlfn. prefixes) for seamless use with xlsxwriter.

## Installation
```
uv add xlsx_formula_compiler
# or
pip install xlsx_formula_compiler
```

## Why do I need this?

Modern Excel features like Dynamic Arrays (the # operator) or functions like XLOOKUP require specific XML prefixes (_xlfn., _xlws.) to be recognized correctly by Excel when generated via libraries like xlsxwriter.

This library automates that translation so you can write formulas as they appear in the Excel formula bar.

## Quick Start

```python
from xlsx_formula_compiler import compile_formula

# Convert a dynamic array formula
raw_formula = "=A1#"
compiled = compile_formula(raw_formula)
print(compiled) 
# Output: _xlfn.ANCHORARRAY(A1)

# Use with xlsxwriter
import xlsxwriter
workbook = xlsxwriter.Workbook('demo.xlsx')
worksheet = workbook.add_worksheet()
worksheet.write_dynamic_array_formula('B1', compiled)
workbook.close()
```

## License
Apache License 2.0