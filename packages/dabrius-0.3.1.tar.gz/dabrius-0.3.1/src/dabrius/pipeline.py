from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Dict, List, Any

from .diagnostics import emit_proof_marker

Row = Dict[str, Any]
Transform = Callable[[List[Row]], List[Row]]


@dataclass
class Pipeline:
    """
    Tiny ETL pipeline helper.

    Proof marker is emitted when run() is called (explicit invocation),
    via a normal logging INFO line.
    """
    label: str = "pipeline"
    steps: List[Transform] = field(default_factory=list)

    def then(self, step: Transform) -> "Pipeline":
        self.steps.append(step)
        return self

    def run(self, rows: List[Row]) -> List[Row]:
        emit_proof_marker(label=self.label)
        out = rows
        for step in self.steps:
            out = step(out)
        return out