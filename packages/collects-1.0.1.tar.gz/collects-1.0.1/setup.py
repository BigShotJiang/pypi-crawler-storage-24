from setuptools import setup

setup(  name= 'collects', 
        version='1.0.1', 
        description='collects', 
        packages=['collects'],
		author='ops',
		license="Python Script",
        install_requires = ["blessings ~= 1.7"],
        extras_require={
            "dev": [
                "pytest>=3.2",
            ],
        },
    )

