"""Event ingestion for SitRep."""
