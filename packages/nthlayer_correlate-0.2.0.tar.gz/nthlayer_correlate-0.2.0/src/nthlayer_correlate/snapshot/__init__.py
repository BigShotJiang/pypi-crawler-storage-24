"""Snapshot generation for SitRep."""
