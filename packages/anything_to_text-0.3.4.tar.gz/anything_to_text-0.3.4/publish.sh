#!/bin/bash
set -e

echo "================================"
echo "  Publishing anything-to-text"
echo "================================"
echo ""

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# Create venv if it doesn't exist
if [ ! -f ".venv/bin/python" ]; then
    echo "Creating virtual environment..."
    python3 -m venv .venv
fi

# Activate virtual environment
source .venv/bin/activate

# Ensure build and twine are installed
if ! python -m build --version &>/dev/null; then
    echo "Installing build tools..."
    pip install build twine -q
fi

# Clean previous builds
echo "Cleaning previous builds..."
rm -rf dist/ build/ src/*.egg-info *.egg-info

# Build
echo "Building package..."
python -m build

# Show what was built
echo ""
echo "Built files:"
ls -lh dist/

# Upload to PyPI
echo ""
echo "Uploading to PyPI..."
twine upload dist/*

echo ""
echo "================================"
echo "  Published successfully!"
echo "================================"
echo ""
echo "Verify at: https://pypi.org/project/anything-to-text/"
