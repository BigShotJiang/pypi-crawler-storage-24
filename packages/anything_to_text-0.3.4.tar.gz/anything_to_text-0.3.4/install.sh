#!/bin/bash
set -e

echo "=== Building anything-to-text ==="

bash build.sh

echo "=== Installing anything-to-text ==="
pip install dist/anything_to_text-*.whl
anything-to-text --version