#!/bin/bash
set -e

echo "=== Building anything-to-text ==="

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

# Create venv if it doesn't exist
if [ ! -f ".venv/bin/python" ]; then
    echo "Creating virtual environment..."
    python3 -m venv .venv
fi

# Activate virtual environment
source .venv/bin/activate

# Ensure build is installed
if ! python -m build --version &>/dev/null; then
    echo "Installing build module..."
    pip install build -q
fi

# Clean previous builds
echo "Cleaning previous builds..."
rm -rf dist/ build/ src/*.egg-info *.egg-info

# Build
echo "Building package..."
python -m build

echo ""
echo "=== Build complete ==="
echo "Created files:"
ls -lh dist/

echo ""
echo "=== To publish ==="
echo ""
echo "Test locally first:"
echo "  pip install dist/anything_to_text-*.whl"
echo "  anything-to-text --version"
echo ""
echo "Upload to PyPI:"
echo "  twine upload dist/*"
