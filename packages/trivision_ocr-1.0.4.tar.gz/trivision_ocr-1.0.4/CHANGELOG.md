# Changelog

All notable changes to this project will be documented here.

## [1.0.0] — 2026-03-22

### Added
- **PyPI Release**: Rebranded and packaged for PyPI deployment as `trivision-ocr`.
- **Stage 0 — Adaptive Preprocessor**: Hough-line median deskew (robust on sparse engineering diagrams), CLAHE contrast enhancement, Otsu + adaptive binarization, optional EDSR 2× super-resolution.
- **Stage 1 — Three-Engine OCR**: Tesseract (LSTM+CTC), PaddleOCR (PP-OCRv5 DBNet+SVTR), EasyOCR (CRAFT+CRNN). GPU engines run sequentially to avoid CUDA context conflicts.
- **Stage 2 — Confidence-Weighted Voter**: IoU spatial grouping, per-engine weighting, agreement bonus (+15% per agreeing engine).
- **Stage 3 — Domain Post-Corrector**: SymSpell spell correction with domain vocabulary protection (PRV, FCV, GV, BFP, HDPE, …).
- Vision API-compatible JSON output with bonus `engine_count` and `confidence` fields.
- `ocr-pipeline` CLI entry point.
- `download_models.py` for one-time model file downloads.
- `setup_venv.bat` for Windows venv bootstrap (CPU default, `gpu` argument for CUDA).
- `MANIFEST.in` for proper package distribution.
- Centralised `logger.py` for structured timestamped logging.
- Unit test suite (`tests/test_voter.py`) — 7 tests, no GPU required.
