"""
test_voter.py — Unit tests for voter.py.

These tests require NO GPU, NO OCR engines, and NO model downloads.
Run with:  pytest tests/test_voter.py -v
"""

from __future__ import annotations

import pytest

from ocr_pipeline.voter import iou, text_similarity, vote


# ── IoU tests ────────────────────────────────────────────────────────────────


def test_iou_overlap():
    """Two heavily overlapping boxes should return a high IoU."""
    box1 = [0, 0, 100, 50]
    box2 = [10, 5, 110, 55]
    result = iou(box1, box2)
    assert 0.6 < result < 1.0, f"Expected IoU ~0.65, got {result}"


def test_iou_identical():
    """Identical boxes must return exactly 1.0."""
    box = [10, 20, 200, 100]
    assert iou(box, box) == pytest.approx(1.0)


def test_iou_no_overlap():
    """Non-overlapping boxes must return 0.0."""
    box1 = [0, 0, 50, 50]
    box2 = [100, 100, 200, 200]
    assert iou(box1, box2) == pytest.approx(0.0)


def test_iou_area2_fix():
    """
    Regression test for the area2 bug in the original design:
      (box2[0] - box2[0]) was always 0, making area2=0 → union=area1 → wrong IoU.
    Verify that area2 is computed correctly.
    """
    # box1: 100×100 = 10000 area, box2: 50×50 = 2500 area, no overlap
    box1 = [0, 0, 100, 100]
    box2 = [200, 200, 250, 250]
    result = iou(box1, box2)
    # If area2 were 0, union would be 10000 and iou could be non-zero; it must be 0
    assert result == pytest.approx(0.0), (
        f"area2 bug: expected 0.0 for non-overlapping boxes, got {result}"
    )


# ── Text similarity tests ─────────────────────────────────────────────────────


def test_text_similarity_identical():
    assert text_similarity("PRV-101", "PRV-101") == pytest.approx(1.0)


def test_text_similarity_partial():
    score = text_similarity("valve", "walve")
    assert 0.7 < score < 1.0, f"Expected high similarity for close strings, got {score}"


def test_text_similarity_no_match():
    score = text_similarity("PRV", "XYZ")
    assert score < 0.5, f"Expected low similarity for unrelated strings, got {score}"


# ── Vote integration tests ────────────────────────────────────────────────────


def _make_det(text, conf, bbox, engine):
    return {"text": text, "confidence": conf, "bbox": bbox, "engine": engine}


def test_vote_single_engine():
    """Single-engine results should pass through unchanged (one output per input)."""
    detections = [
        _make_det("PRV-101", 0.95, [0, 0, 100, 30], "paddleocr"),
        _make_det("FCV-200", 0.90, [200, 0, 400, 30], "paddleocr"),
    ]
    result = vote([detections, [], []])
    assert len(result) == 2
    texts = {r["text"] for r in result}
    assert "PRV-101" in texts
    assert "FCV-200" in texts


def test_vote_agreement_bonus():
    """
    When all 3 engines agree, the score should exceed a single-engine score.
    The winner should be the text all three agreed on.
    """
    bbox = [0, 0, 100, 30]
    paddle = [_make_det("PRV", 0.90, bbox, "paddleocr")]
    easy   = [_make_det("PRV", 0.85, bbox, "easyocr")]
    tess   = [_make_det("PRV", 0.80, bbox, "tesseract")]

    result = vote([paddle, easy, tess])
    assert len(result) == 1
    assert result[0]["text"] == "PRV"
    # engine_count should be 3 (all engines found the same region)
    assert result[0]["engine_count"] == 3
    # confidence should be boosted above the raw paddle score
    assert result[0]["confidence"] > 0.90 * 0.45  # base score alone


def test_vote_no_overlap():
    """Non-overlapping detections from different engines must remain separate."""
    paddle = [_make_det("PRV", 0.90, [0,   0, 100, 30], "paddleocr")]
    easy   = [_make_det("FCV", 0.85, [200, 0, 400, 30], "easyocr")]
    result = vote([paddle, easy, []])
    assert len(result) == 2


def test_vote_empty():
    """All empty engine results should return an empty list without error."""
    result = vote([[], [], []])
    assert result == []
