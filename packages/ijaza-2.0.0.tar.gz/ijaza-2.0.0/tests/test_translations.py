"""Tests for translation support."""

import pytest
from ijaza.translations import (
    TranslationProvider,
    TranslationConfig,
    TRUSTED_EDITIONS,
    DEFAULT_EDITIONS,
)
from ijaza import QuranValidator, LLMProcessor


class TestTranslationConfig:
    def test_default_config_has_en_and_de(self):
        config = TranslationConfig()
        assert 'en' in config.editions
        assert 'de' in config.editions

    def test_default_editions(self):
        assert DEFAULT_EDITIONS['en'] == 'en.sahih'
        assert DEFAULT_EDITIONS['de'] == 'de.bubenheim'

    def test_trusted_editions_non_empty(self):
        assert len(TRUSTED_EDITIONS) > 0
        assert 'en.sahih' in TRUSTED_EDITIONS
        assert 'de.bubenheim' in TRUSTED_EDITIONS


class TestTranslationProvider:
    def _get_provider(self):
        provider = TranslationProvider()
        try:
            provider.get_translation(1, 1, 'en')
        except FileNotFoundError:
            pytest.skip("Translation data files not yet fetched")
        return provider

    def test_get_translation_en(self):
        provider = self._get_provider()
        text = provider.get_translation(1, 1, 'en')
        assert text is not None
        assert isinstance(text, str)
        assert len(text) > 0

    def test_get_translation_de(self):
        provider = self._get_provider()
        text = provider.get_translation(1, 1, 'de')
        assert text is not None
        assert isinstance(text, str)
        assert len(text) > 0

    def test_get_translations_returns_all_langs(self):
        provider = self._get_provider()
        translations = provider.get_translations(1, 1)
        assert 'en' in translations
        assert 'de' in translations

    def test_fatiha_english_translation_content(self):
        provider = self._get_provider()
        text = provider.get_translation(1, 1, 'en')
        assert text is not None
        # Sahih International translation of Al-Fatiha 1:1
        assert 'Allah' in text or 'name' in text.lower()

    def test_last_verse_exists(self):
        provider = self._get_provider()
        # An-Nas 114:6
        text = provider.get_translation(114, 6, 'en')
        assert text is not None

    def test_missing_lang_returns_none(self):
        provider = TranslationProvider(TranslationConfig(editions={'fr': 'fr.nonexistent'}))
        result = provider.get_translation(1, 1, 'fr')
        assert result is None

    def test_unconfigured_lang_returns_none(self):
        provider = TranslationProvider(TranslationConfig(editions={'en': 'en.sahih'}))
        result = provider.get_translation(1, 1, 'de')
        assert result is None

    def test_custom_edition_config(self):
        config = TranslationConfig(editions={'en': 'en.pickthall'})
        provider = TranslationProvider(config)
        assert provider.config.editions['en'] == 'en.pickthall'

    def test_is_edition_available(self):
        provider = self._get_provider()
        assert provider.is_edition_available('en.sahih')

    def test_is_edition_unavailable(self):
        provider = TranslationProvider()
        assert not provider.is_edition_available('xx.nonexistent')


class TestValidatorWithTranslations:
    def _get_provider(self):
        provider = TranslationProvider()
        try:
            provider.get_translation(1, 1, 'en')
        except FileNotFoundError:
            pytest.skip("Translation data files not yet fetched")
        return provider

    def test_translations_populated_in_result(self):
        provider = self._get_provider()
        validator = QuranValidator(translation_provider=provider)
        verse = validator.get_verse(1, 1)
        assert verse is not None
        result = validator.validate(verse.text)
        assert result.is_valid
        assert 'en' in result.translations
        assert len(result.translations['en']) > 0

    def test_translations_include_german(self):
        provider = self._get_provider()
        validator = QuranValidator(translation_provider=provider)
        verse = validator.get_verse(1, 1)
        assert verse is not None
        result = validator.validate(verse.text)
        assert 'de' in result.translations
        assert len(result.translations['de']) > 0

    def test_no_translations_when_provider_not_set(self):
        validator = QuranValidator()
        verse = validator.get_verse(1, 1)
        assert verse is not None
        result = validator.validate(verse.text)
        assert result.is_valid
        assert result.translations == {}

    def test_no_match_has_empty_translations(self):
        provider = self._get_provider()
        validator = QuranValidator(translation_provider=provider)
        result = validator.validate("مرحبا كيف حالك اليوم")
        assert not result.is_valid
        assert result.translations == {}


class TestLLMProcessorWithTranslations:
    def _get_provider(self):
        provider = TranslationProvider()
        try:
            provider.get_translation(1, 1, 'en')
        except FileNotFoundError:
            pytest.skip("Translation data files not yet fetched")
        return provider

    def test_quote_analysis_has_translations(self):
        provider = self._get_provider()
        processor = LLMProcessor(translation_provider=provider)
        # Process text with a known verse reference
        text = '<quran ref="1:1">بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ</quran>'
        result = processor.process(text)
        assert len(result.quotes) == 1
        assert 'en' in result.quotes[0].translations
