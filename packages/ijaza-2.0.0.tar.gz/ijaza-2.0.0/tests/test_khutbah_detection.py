"""User-style integration tests for khutbah text processing."""

from ijaza import LLMProcessor, QuranValidator


KHUTBAH_TEXT = (
    "خليله أشهد أنّه بلغ الرسالة وأدى الأمانة ونصح للأمة\n"
    "ونصح للأمّة وكشف الله به الغمّة، وجاهد في سبيل الله حق جهاده حتّى آتاه اليقين.\n"
    "أما بعد يقول الله عز وجل: يا أيها الذين آمنوا\n"
    "اتقوا الله حق تقاته ولا تموتن إلا وأنتم مسلمون."
)


def test_processes_untagged_khutbah_text():
    processor = LLMProcessor()
    result = processor.process(KHUTBAH_TEXT)

    assert len(result.quotes) == 1
    assert result.all_valid is False

    quote = result.quotes[0]
    assert quote.reference == "3:102"
    assert quote.is_valid is True
    assert quote.was_corrected is True
    assert quote.detection_method == "fuzzy"
    assert quote.confidence >= 0.85

    assert len(result.warnings) == 1
    assert "3:102" in result.warnings[0]


def test_corrected_output_contains_authentic_verse():
    validator = QuranValidator()
    expected_verse = validator.get_verse(surah=3, ayah=102)
    assert expected_verse is not None

    processor = LLMProcessor()
    result = processor.process(KHUTBAH_TEXT)

    assert expected_verse.text in result.corrected_text


def test_detect_and_validate_finds_only_one_valid_ayah_segment():
    validator = QuranValidator()
    detection = validator.detect_and_validate(KHUTBAH_TEXT)

    assert detection.detected is True

    valid_segments = [
        segment for segment in detection.segments
        if segment.validation and segment.validation.is_valid
    ]
    assert len(valid_segments) == 1
    assert valid_segments[0].validation.reference == "3:102"
    assert valid_segments[0].validation.match_type == "fuzzy"
