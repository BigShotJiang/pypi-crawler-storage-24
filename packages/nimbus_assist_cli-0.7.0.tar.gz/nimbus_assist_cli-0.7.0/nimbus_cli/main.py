"""nimbus-cli entrypoint."""

from __future__ import annotations

import click
from rich.console import Console

console = Console()


@click.command()
@click.option("--init", "do_init", is_flag=True, default=False,
              help="Validate AWS credentials and set up the Bedrock RAG pipeline.")
@click.option("--suggest-fix", "do_suggest", is_flag=True, default=False,
              help="Get an AI-powered fix suggestion.")
@click.option("--text", "problem_text", default=None,
              help="The security problem to fix (used with --suggest-fix).")
@click.option("--region", "region", default=None,
              help="AWS region for the RAG pipeline (default: us-east-1).")
@click.option("--reconfigure", "do_reconfigure", is_flag=True, default=False,
              help="Clear saved config and re-init with current AWS credentials.")
@click.option("--destroy", "do_destroy", is_flag=True, default=False,
              help="Delete all AWS resources created by --init and remove local config.")
def main(
    do_init: bool,
    do_suggest: bool,
    problem_text: str | None,
    region: str | None,
    do_reconfigure: bool,
    do_destroy: bool,
) -> None:
    """Nimbus CLI — AWS Security AI fix suggestions powered by Bedrock.

    \b
    First time setup:
      nimbus-cli --init
      nimbus-cli --init --region us-east-1

    \b
    Switch AWS account or refresh credentials:
      nimbus-cli --reconfigure

    \b
    Daily use:
      nimbus-cli --suggest-fix --text "S3 bucket is publicly accessible"
      nimbus-cli --suggest-fix --text "EC2 instance has no IMDSv2 enforced"

    \b
    Tear down all AWS resources:
      nimbus-cli --destroy
    """
    if do_destroy:
        _do_destroy()
        return

    if do_reconfigure:
        _do_reconfigure(region)
        return

    if do_init:
        _do_init(region)
        return

    if do_suggest:
        if not problem_text:
            console.print("[red]--text is required with --suggest-fix.[/red]")
            console.print("Example: [cyan]nimbus-cli --suggest-fix --text \"S3 bucket is public\"[/cyan]")
            raise SystemExit(1)
        _do_suggest(problem_text)
        return

    ctx = click.get_current_context()
    click.echo(ctx.get_help())


def _do_init(region: str | None = None) -> None:
    """Run first-time setup: validate credentials and provision RAG pipeline."""
    from nimbus_core import NimbusClient
    from nimbus_core.infra import check_aws_credentials

    console.print()
    console.rule("[cyan]Nimbus CLI — Initializing RAG Pipeline")
    console.print()

    # Default to us-east-1 for best Bedrock model support
    effective_region = region or "us-east-1"

    try:
        account_id, effective_region = check_aws_credentials(effective_region)
    except RuntimeError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1)

    console.print(f"  [green]✓[/green] AWS credentials valid")
    console.print(f"  [dim]Account:[/dim]  [cyan]{account_id}[/cyan]")
    console.print(f"  [dim]Region:[/dim]   [cyan]{effective_region}[/cyan]")
    console.print()

    client = NimbusClient(region=effective_region)

    def on_step(step: int, description: str) -> None:
        console.rule(f"[dim]Step {step}/5 — {description}")

    try:
        result = client.init(on_step=on_step)
    except Exception as e:
        console.print(f"[red]Init failed:[/red] {e}")
        raise SystemExit(1)

    console.print()
    console.rule("[green]Init complete")
    console.print()
    console.print(f"  [dim]Account:[/dim]  [cyan]{result.account_id}[/cyan]")
    console.print(f"  [dim]Region:[/dim]   [cyan]{result.region}[/cyan]")
    console.print(f"  [dim]KB ID:[/dim]    [cyan]{result.kb_id}[/cyan]")
    console.print(f"  [dim]Config:[/dim]   [cyan]~/.nimbus-cli.json[/cyan]")
    console.print()
    console.print("  Run [cyan]nimbus-cli --suggest-fix --text \"your problem\"[/cyan] to get AI fixes.")
    console.print()


def _do_suggest(text: str) -> None:
    """Get AI fix suggestion — calls Bedrock directly, no server needed."""
    from nimbus_core import NimbusClient
    from rich.markdown import Markdown
    from rich.panel import Panel

    client = NimbusClient()

    with console.status("Analyzing...", spinner="dots"):
        try:
            result = client.suggest_fix(text)
        except RuntimeError as e:
            console.print(f"[red]{e}[/red]")
            if "No Knowledge Base configured" in str(e):
                console.print("Run [cyan]nimbus-cli --init[/cyan] first.")
            raise SystemExit(1)

    console.print()
    console.print(Panel(text, title="[bold cyan]Problem[/bold cyan]", border_style="cyan"))
    console.print()
    console.print(Panel(
        Markdown(result.remediation),
        title="[bold green]AI Suggested Fix[/bold green]",
        border_style="green",
        padding=(1, 2),
    ))
    console.print()


def _do_destroy() -> None:
    """Delete all AWS resources created by --init."""
    from nimbus_core import NimbusClient

    console.print()
    console.rule("[red]Nimbus CLI — Destroying RAG Pipeline")
    console.print()
    console.print("  This will delete all AWS resources created by [cyan]--init[/cyan]:")
    console.print("    • Bedrock Knowledge Base")
    console.print("    • S3 documents bucket (and all contents)")
    console.print("    • S3 Vectors bucket and index")
    console.print("    • IAM role")
    console.print("    • Local config (~/.nimbus-cli.json)")
    console.print()

    if not click.confirm("  Are you sure?", default=False):
        console.print("  [dim]Cancelled.[/dim]")
        return

    console.print()
    client = NimbusClient()

    def on_step(step: int, description: str) -> None:
        console.rule(f"[dim]Step {step}/5 — {description}")

    try:
        errors = client.destroy(on_step=on_step)
    except RuntimeError as e:
        console.print(f"[red]{e}[/red]")
        raise SystemExit(1)

    console.print()
    if errors:
        console.rule("[yellow]Destroy partially failed")
        console.print()
        console.print("  [yellow]Some resources could not be deleted:[/yellow]")
        for err in errors:
            console.print(f"    [red]•[/red] {err}")
        console.print()
        console.print("  Config kept at [cyan]~/.nimbus-cli.json[/cyan] — run [cyan]--destroy[/cyan] again to retry.")
        console.print()
        raise SystemExit(1)
    else:
        console.rule("[green]Destroy complete")
        console.print()
        console.print("  All AWS resources and local config have been removed.")
        console.print("  To uninstall the CLI: [cyan]pipx uninstall nimbus-assist-cli[/cyan]")
        console.print()


def _do_reconfigure(region: str | None = None) -> None:
    """Clear config and re-init, preserving the existing region unless overridden."""
    import json
    from nimbus_core.client import _CONFIG_PATH

    console.print()
    console.rule("[yellow]Nimbus CLI — Reconfigure")
    console.print()

    existing_region: str | None = None

    # Read region from existing config before deleting it.
    if _CONFIG_PATH.exists():
        try:
            existing = json.loads(_CONFIG_PATH.read_text())
            existing_region = existing.get("bedrock_region") or existing.get("region")
        except Exception:
            pass

    # If user explicitly passed a different region, warn and confirm.
    if region and existing_region and region != existing_region:
        console.print(f"  [yellow]Warning:[/yellow] existing infra is in [cyan]{existing_region}[/cyan].")
        console.print(f"  Switching to [cyan]{region}[/cyan] will create new infra there.")
        console.print(f"  The old infra in [cyan]{existing_region}[/cyan] will [bold]not[/bold] be deleted automatically.")
        console.print()
        if not click.confirm("  Continue and switch region?", default=False):
            console.print("  [dim]Cancelled. Run [cyan]nimbus-cli --destroy[/cyan] first to clean up old infra.[/dim]")
            return
    else:
        # No explicit region override — stay in the existing region.
        region = region or existing_region

    if _CONFIG_PATH.exists():
        _CONFIG_PATH.unlink()
        console.print("  [dim]Config cleared.[/dim]")

    if region:
        console.print(f"  [dim]Using region:[/dim] [cyan]{region}[/cyan]")

    _do_init(region)


if __name__ == "__main__":
    main()
