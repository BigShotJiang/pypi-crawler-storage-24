# nimbus-cli

AWS Security AI fix suggestions powered by Bedrock — no server needed.

## Install

```bash
pip install nimbus-assist-cli
```

Or with `pipx` for isolated CLI installs (recommended):

```bash
pipx install nimbus-assist-cli
```

## Prerequisites

- AWS credentials configured (`aws configure` or env vars)
- Bedrock model access enabled:
  - `amazon.titan-embed-text-v2:0`
  - `anthropic.claude-haiku-4-5-20251001-v1:0`

## Usage

### First-time setup

```bash
nimbus-cli --init
# or specify a region (default: us-east-1)
nimbus-cli --init --region us-east-2
```

Validates AWS credentials and provisions the RAG pipeline (S3 docs bucket, S3 Vectors, Bedrock KB).

### Get AI fix suggestions

```bash
nimbus-cli --suggest-fix --text "S3 bucket is publicly accessible"
nimbus-cli --suggest-fix --text "EC2 instance has no IMDSv2 enforced"
nimbus-cli --suggest-fix --text "IAM role has wildcard * permissions"
```

Calls Bedrock directly — no backend server required.

### Switch AWS account or refresh credentials

```bash
nimbus-cli --reconfigure
```

Clears `~/.nimbus-cli.json` and re-runs init with current credentials.
