# ReplicateScience Python SDK

Programmable protocol library for reproducible science. Search, compare, and export experimental protocols extracted from published papers.

## Installation

```bash
pip install replicatescience
```

## Quick Start

```python
import replicatescience as rs

# Configure your API key (or set RS_API_KEY env var)
rs.configure(api_key="rs_live_YOUR_KEY")

# Search protocols by keyword + species
results = rs.search("fear conditioning", species="mouse")
for p in results.protocols:
    print(f"{p.slug}: {p.name} ({p.step_count} steps)")

# Get full protocol detail
protocol = rs.get("smith-fear-conditioning-2024")

# Compare two protocols
diff = rs.diff(
    rs.get("smith-fear-conditioning-2024"),
    rs.get("jones-fear-conditioning-2023"),
)
print(diff.summary)
print(diff.to_markdown())

# Export to YAML
rs.save(protocol, "protocols/fear-conditioning.yaml")
```

## CLI

```bash
# Search from terminal
rs search "pcr" --species mouse --limit 5

# Get a protocol
rs get smith-fear-conditioning-2024 --format yaml > protocol.yaml

# Diff two protocols
rs diff smith-2024 jones-2023
```

## API Key

Get your free API key at [replicatescience.com/developers](https://replicatescience.com/developers).

| Plan | Requests/Day | Exports/Day |
|------|-------------|-------------|
| Free | 100 | 10 |
| Pro | 5,000 | Unlimited |
| Institutional | 50,000 | Unlimited |

## Links

- [Documentation](https://replicatescience.com/developers)
- [API Reference (OpenAPI)](https://replicatescience.com/api/v1/openapi.json)
- [GitHub](https://github.com/ShuhanCS/replicatescience-python)
