"""ReplicateScience Python SDK — programmable protocol library for reproducible science."""

from replicatescience.client import Client
from replicatescience.models import (
    Equipment,
    EquipmentDetail,
    Pagination,
    Protocol,
    ProtocolDetail,
    ProtocolDiff,
    RateLimit,
    SearchResult,
    SearchResults,
)

__version__ = "0.1.0"
__all__ = [
    "configure",
    "search",
    "get",
    "diff",
    "save",
    "load",
    "get_equipment",
    "search_equipment",
    "me",
    "Client",
    "Protocol",
    "ProtocolDetail",
    "ProtocolDiff",
    "Equipment",
    "EquipmentDetail",
    "SearchResult",
    "SearchResults",
    "Pagination",
    "RateLimit",
]

_default_client: Client | None = None


def _get_client() -> Client:
    global _default_client
    if _default_client is None:
        _default_client = Client()
    return _default_client


def configure(
    api_key: str | None = None,
    base_url: str | None = None,
) -> None:
    """Configure the default client.

    Args:
        api_key: Your ReplicateScience API key (rs_live_...).
            Falls back to RS_API_KEY environment variable.
        base_url: API base URL. Defaults to https://replicatescience.com.
    """
    global _default_client
    _default_client = Client(api_key=api_key, base_url=base_url)


def search(
    query: str,
    *,
    species: str | None = None,
    strain: str | None = None,
    type: str | None = None,
    year_min: int | None = None,
    year_max: int | None = None,
    sort: str | None = None,
    page: int = 1,
    limit: int = 20,
) -> SearchResults:
    """Search protocols by keyword and filters."""
    return _get_client().search_protocols(
        query,
        species=species,
        strain=strain,
        type=type,
        year_min=year_min,
        year_max=year_max,
        sort=sort,
        page=page,
        limit=limit,
    )


def get(slug: str) -> ProtocolDetail:
    """Get full protocol detail by slug."""
    return _get_client().get_protocol(slug)


def diff(a: ProtocolDetail, b: ProtocolDetail) -> ProtocolDiff:
    """Compare two protocols and return their differences."""
    return ProtocolDiff.compute(a, b)


def save(protocol: ProtocolDetail, path: str) -> None:
    """Export a protocol to a YAML or JSON file."""
    from replicatescience.export import save_protocol

    save_protocol(protocol, path)


def load(path: str) -> ProtocolDetail:
    """Load a protocol from a YAML or JSON file."""
    from replicatescience.export import load_protocol

    return load_protocol(path)


def get_equipment(slug: str) -> EquipmentDetail:
    """Get full equipment detail by slug."""
    return _get_client().get_equipment(slug)


def search_equipment(
    query: str | None = None,
    *,
    category: str | None = None,
    manufacturer: str | None = None,
    page: int = 1,
    limit: int = 20,
) -> SearchResults:
    """Search equipment."""
    return _get_client().search_equipment(
        query, category=category, manufacturer=manufacturer, page=page, limit=limit
    )


def me() -> dict:
    """Get API key info and rate limits."""
    return _get_client().me()
