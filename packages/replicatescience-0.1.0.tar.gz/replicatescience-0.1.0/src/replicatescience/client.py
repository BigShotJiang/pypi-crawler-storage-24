"""HTTP client for the ReplicateScience API."""

from __future__ import annotations

import os

import httpx

from replicatescience.models import (
    Equipment,
    EquipmentDetail,
    Pagination,
    Protocol,
    ProtocolDetail,
    RateLimit,
    SearchResult,
    SearchResults,
)

DEFAULT_BASE_URL = "https://replicatescience.com"


class ReplicateScienceError(Exception):
    """Base exception for ReplicateScience API errors."""

    def __init__(self, message: str, status_code: int | None = None):
        super().__init__(message)
        self.status_code = status_code


class AuthenticationError(ReplicateScienceError):
    pass


class NotFoundError(ReplicateScienceError):
    pass


class RateLimitError(ReplicateScienceError):
    def __init__(self, message: str, resets_at: str | None = None):
        super().__init__(message, status_code=429)
        self.resets_at = resets_at


class Client:
    """ReplicateScience API client."""

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float = 30.0,
    ):
        self.api_key = api_key or os.environ.get("RS_API_KEY", "")
        self.base_url = (base_url or DEFAULT_BASE_URL).rstrip("/")
        self._http = httpx.Client(
            base_url=self.base_url,
            timeout=timeout,
            headers=self._headers(),
        )

    def _headers(self) -> dict[str, str]:
        h: dict[str, str] = {"User-Agent": "replicatescience-python/0.1.0"}
        if self.api_key:
            h["Authorization"] = f"Bearer {self.api_key}"
        return h

    def _request(self, method: str, path: str, **kwargs) -> dict:
        resp = self._http.request(method, path, **kwargs)
        if resp.status_code == 401:
            raise AuthenticationError(
                "Missing or invalid API key. Set RS_API_KEY or call rs.configure(api_key=...).",
                status_code=401,
            )
        if resp.status_code == 404:
            raise NotFoundError(
                f"Resource not found: {path}",
                status_code=404,
            )
        if resp.status_code == 429:
            body = resp.json()
            raise RateLimitError(
                body.get("error", "Rate limit exceeded."),
                resets_at=resp.headers.get("X-RateLimit-Reset"),
            )
        resp.raise_for_status()
        return resp.json()

    def _get(self, path: str, params: dict | None = None) -> dict:
        return self._request("GET", path, params=params)

    def search_protocols(
        self,
        query: str,
        *,
        species: str | None = None,
        strain: str | None = None,
        type: str | None = None,
        year_min: int | None = None,
        year_max: int | None = None,
        sort: str | None = None,
        page: int = 1,
        limit: int = 20,
    ) -> SearchResults:
        params: dict = {"q": query, "page": page, "limit": limit}
        if species:
            params["species"] = species
        if strain:
            params["strain"] = strain
        if type:
            params["type"] = type
        if year_min is not None:
            params["year_min"] = year_min
        if year_max is not None:
            params["year_max"] = year_max
        if sort:
            params["sort"] = sort

        data = self._get("/api/v1/protocols", params=params)
        protocols = [Protocol.from_dict(p) for p in data.get("data", [])]
        pagination = (
            Pagination.from_dict(data["pagination"]) if "pagination" in data else None
        )
        rate_limit = (
            RateLimit.from_dict(data["rate_limit"]) if "rate_limit" in data else None
        )
        return SearchResults(
            protocols=protocols,
            equipment=[],
            results=[],
            pagination=pagination,
            rate_limit=rate_limit,
        )

    def get_protocol(self, slug: str) -> ProtocolDetail:
        data = self._get(f"/api/v1/protocols/{slug}")
        return ProtocolDetail.from_dict(data["data"])

    def get_protocol_equipment(self, slug: str) -> list[Equipment]:
        data = self._get(f"/api/v1/protocols/{slug}/equipment")
        return [Equipment.from_dict(e) for e in data.get("data", [])]

    def export_protocol(self, slug: str, format: str = "json") -> dict | str:
        data = self._get(f"/api/v1/protocols/{slug}/export", params={"format": format})
        return data

    def search_equipment(
        self,
        query: str | None = None,
        *,
        category: str | None = None,
        manufacturer: str | None = None,
        page: int = 1,
        limit: int = 20,
    ) -> SearchResults:
        params: dict = {"page": page, "limit": limit}
        if query:
            params["q"] = query
        if category:
            params["category"] = category
        if manufacturer:
            params["manufacturer"] = manufacturer

        data = self._get("/api/v1/equipment", params=params)
        equipment = [EquipmentDetail.from_dict(e) for e in data.get("data", [])]
        pagination = (
            Pagination.from_dict(data["pagination"]) if "pagination" in data else None
        )
        rate_limit = (
            RateLimit.from_dict(data["rate_limit"]) if "rate_limit" in data else None
        )
        return SearchResults(
            protocols=[],
            equipment=equipment,
            results=[],
            pagination=pagination,
            rate_limit=rate_limit,
        )

    def get_equipment(self, slug: str) -> EquipmentDetail:
        data = self._get(f"/api/v1/equipment/{slug}")
        return EquipmentDetail.from_dict(data["data"])

    def unified_search(
        self,
        query: str,
        *,
        type: str | None = None,
        page: int = 1,
        limit: int = 20,
    ) -> SearchResults:
        params: dict = {"q": query, "page": page, "limit": limit}
        if type:
            params["type"] = type

        data = self._get("/api/v1/search", params=params)
        results = [SearchResult.from_dict(r) for r in data.get("data", [])]
        pagination = (
            Pagination.from_dict(data["pagination"]) if "pagination" in data else None
        )
        rate_limit = (
            RateLimit.from_dict(data["rate_limit"]) if "rate_limit" in data else None
        )
        return SearchResults(
            protocols=[],
            equipment=[],
            results=results,
            pagination=pagination,
            rate_limit=rate_limit,
        )

    def me(self) -> dict:
        data = self._get("/api/v1/me")
        return data["data"]

    def close(self) -> None:
        self._http.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
