"""Export and import protocols as YAML/JSON files."""

from __future__ import annotations

import json
from pathlib import Path

import yaml

from replicatescience.models import ProtocolDetail


def save_protocol(protocol: ProtocolDetail, path: str) -> None:
    """Save a protocol to a YAML or JSON file."""
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    data = protocol.to_dict()

    if p.suffix in (".yaml", ".yml"):
        with open(p, "w", encoding="utf-8") as f:
            yaml.dump(data, f, default_flow_style=False, sort_keys=False, allow_unicode=True)
    elif p.suffix == ".json":
        with open(p, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    else:
        raise ValueError(f"Unsupported format: {p.suffix}. Use .yaml, .yml, or .json")


def load_protocol(path: str) -> ProtocolDetail:
    """Load a protocol from a YAML or JSON file."""
    p = Path(path)

    if p.suffix in (".yaml", ".yml"):
        with open(p, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
    elif p.suffix == ".json":
        with open(p, "r", encoding="utf-8") as f:
            data = json.load(f)
    else:
        raise ValueError(f"Unsupported format: {p.suffix}. Use .yaml, .yml, or .json")

    return ProtocolDetail.from_dict(data)
