"""Data models for ReplicateScience API responses."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Pagination:
    page: int
    limit: int
    total: int
    next: str | None = None
    previous: str | None = None

    @classmethod
    def from_dict(cls, d: dict) -> Pagination:
        return cls(
            page=d["page"],
            limit=d["limit"],
            total=d["total"],
            next=d.get("next"),
            previous=d.get("previous"),
        )


@dataclass
class RateLimit:
    limit: int
    remaining: int
    resets_at: str

    @classmethod
    def from_dict(cls, d: dict) -> RateLimit:
        return cls(
            limit=d["limit"],
            remaining=d["remaining"],
            resets_at=d["resets_at"],
        )


@dataclass
class Paper:
    title: str
    doi: str | None = None
    authors: list[str] = field(default_factory=list)
    journal: str | None = None
    year: int | None = None

    @classmethod
    def from_dict(cls, d: dict) -> Paper:
        return cls(
            title=d["title"],
            doi=d.get("doi"),
            authors=d.get("authors", []),
            journal=d.get("journal"),
            year=d.get("year"),
        )

    def to_dict(self) -> dict:
        return {
            "title": self.title,
            "doi": self.doi,
            "authors": self.authors,
            "journal": self.journal,
            "year": self.year,
        }


@dataclass
class ProcedureStep:
    number: int
    title: str | None
    description: str
    duration: str | None = None
    evidence: str | None = None

    @classmethod
    def from_dict(cls, d: dict) -> ProcedureStep:
        return cls(
            number=d["number"],
            title=d.get("title"),
            description=d["description"],
            duration=d.get("duration"),
            evidence=d.get("evidence"),
        )

    def to_dict(self) -> dict:
        return {
            "number": self.number,
            "title": self.title,
            "description": self.description,
            "duration": self.duration,
            "evidence": self.evidence,
        }


@dataclass
class EvidenceQuote:
    quote: str
    context: str

    @classmethod
    def from_dict(cls, d: dict) -> EvidenceQuote:
        return cls(quote=d["quote"], context=d["context"])

    def to_dict(self) -> dict:
        return {"quote": self.quote, "context": self.context}


@dataclass
class Equipment:
    id: str
    name: str
    slug: str
    category: str | None = None
    manufacturer: str | None = None
    model_number: str | None = None
    rrid: str | None = None
    product_url: str | None = None
    price_estimate: float | None = None

    @classmethod
    def from_dict(cls, d: dict) -> Equipment:
        return cls(
            id=d["id"],
            name=d["name"],
            slug=d["slug"],
            category=d.get("category"),
            manufacturer=d.get("manufacturer"),
            model_number=d.get("model_number"),
            rrid=d.get("rrid"),
            product_url=d.get("product_url"),
            price_estimate=d.get("price_estimate"),
        )

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "slug": self.slug,
            "category": self.category,
            "manufacturer": self.manufacturer,
            "model_number": self.model_number,
            "rrid": self.rrid,
            "product_url": self.product_url,
            "price_estimate": self.price_estimate,
        }


@dataclass
class Product:
    name: str
    url: str
    price: float | None
    sku: str

    @classmethod
    def from_dict(cls, d: dict) -> Product:
        return cls(
            name=d["name"],
            url=d["url"],
            price=d.get("price"),
            sku=d["sku"],
        )

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "url": self.url,
            "price": self.price,
            "sku": self.sku,
        }


@dataclass
class EquipmentDetail(Equipment):
    aliases: list[str] = field(default_factory=list)
    description: str | None = None
    product: Product | None = None
    protocol_count: int = 0
    url: str = ""

    @classmethod
    def from_dict(cls, d: dict) -> EquipmentDetail:
        product = None
        if d.get("product"):
            product = Product.from_dict(d["product"])
        return cls(
            id=d["id"],
            name=d["name"],
            slug=d["slug"],
            category=d.get("category"),
            manufacturer=d.get("manufacturer"),
            model_number=d.get("model_number"),
            rrid=d.get("rrid"),
            product_url=d.get("product_url"),
            price_estimate=d.get("price_estimate"),
            aliases=d.get("aliases", []),
            description=d.get("description"),
            product=product,
            protocol_count=d.get("protocol_count", 0),
            url=d.get("url", ""),
        )


@dataclass
class Protocol:
    id: str
    name: str
    slug: str
    paper: Paper
    type: str | None = None
    species: str | None = None
    strain: str | None = None
    equipment_count: int = 0
    step_count: int = 0
    evidence_score: float | None = None
    tags: list[str] = field(default_factory=list)
    url: str = ""
    created_at: str = ""

    @classmethod
    def from_dict(cls, d: dict) -> Protocol:
        return cls(
            id=d["id"],
            name=d["name"],
            slug=d["slug"],
            paper=Paper.from_dict(d["paper"]),
            type=d.get("type"),
            species=d.get("species"),
            strain=d.get("strain"),
            equipment_count=d.get("equipment_count", 0),
            step_count=d.get("step_count", 0),
            evidence_score=d.get("evidence_score"),
            tags=d.get("tags", []),
            url=d.get("url", ""),
            created_at=d.get("created_at", ""),
        )

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "slug": self.slug,
            "paper": self.paper.to_dict(),
            "type": self.type,
            "species": self.species,
            "strain": self.strain,
            "equipment_count": self.equipment_count,
            "step_count": self.step_count,
            "evidence_score": self.evidence_score,
            "tags": self.tags,
            "url": self.url,
            "created_at": self.created_at,
        }


@dataclass
class ProtocolDetail(Protocol):
    brain_regions: list[str] = field(default_factory=list)
    steps: list[ProcedureStep] = field(default_factory=list)
    equipment: list[Equipment] = field(default_factory=list)
    subjects: dict[str, Any] | None = None
    analysis: dict[str, Any] | None = None
    evidence_quotes: list[EvidenceQuote] = field(default_factory=list)

    @classmethod
    def from_dict(cls, d: dict) -> ProtocolDetail:
        return cls(
            id=d["id"],
            name=d["name"],
            slug=d["slug"],
            paper=Paper.from_dict(d["paper"]),
            type=d.get("type"),
            species=d.get("species"),
            strain=d.get("strain"),
            equipment_count=d.get("equipment_count", 0),
            step_count=d.get("step_count", 0),
            evidence_score=d.get("evidence_score"),
            tags=d.get("tags", []),
            url=d.get("url", ""),
            created_at=d.get("created_at", ""),
            brain_regions=d.get("brain_regions", []),
            steps=[ProcedureStep.from_dict(s) for s in d.get("steps", [])],
            equipment=[Equipment.from_dict(e) for e in d.get("equipment", [])],
            subjects=d.get("subjects"),
            analysis=d.get("analysis"),
            evidence_quotes=[
                EvidenceQuote.from_dict(q) for q in d.get("evidence_quotes", [])
            ],
        )

    def to_dict(self) -> dict:
        base = super().to_dict()
        base.update(
            {
                "brain_regions": self.brain_regions,
                "steps": [s.to_dict() for s in self.steps],
                "equipment": [e.to_dict() for e in self.equipment],
                "subjects": self.subjects,
                "analysis": self.analysis,
                "evidence_quotes": [q.to_dict() for q in self.evidence_quotes],
            }
        )
        return base


@dataclass
class SearchResult:
    type: str
    id: str
    name: str
    slug: str
    description: str
    url: str

    @classmethod
    def from_dict(cls, d: dict) -> SearchResult:
        return cls(
            type=d["type"],
            id=d["id"],
            name=d["name"],
            slug=d["slug"],
            description=d.get("description", ""),
            url=d.get("url", ""),
        )


@dataclass
class SearchResults:
    protocols: list[Protocol]
    equipment: list[Equipment]
    results: list[SearchResult]
    pagination: Pagination | None = None
    rate_limit: RateLimit | None = None


@dataclass
class DiffChange:
    field: str
    label: str
    old: Any
    new: Any


@dataclass
class ProtocolDiff:
    protocol_a: str
    protocol_b: str
    changes: list[DiffChange] = field(default_factory=list)

    @property
    def summary(self) -> str:
        n = len(self.changes)
        sections = len({c.field.split(".")[0] for c in self.changes})
        if n == 0:
            return "No differences found."
        return f"{n} change{'s' if n != 1 else ''} across {sections} section{'s' if sections != 1 else ''}"

    def to_markdown(self) -> str:
        lines = [
            f"# Protocol Diff",
            f"**A:** {self.protocol_a}",
            f"**B:** {self.protocol_b}",
            f"**Summary:** {self.summary}",
            "",
        ]
        for c in self.changes:
            lines.append(f"## {c.label}")
            lines.append(f"- **A:** {c.old}")
            lines.append(f"- **B:** {c.new}")
            lines.append("")
        return "\n".join(lines)

    @classmethod
    def compute(cls, a: ProtocolDetail, b: ProtocolDetail) -> ProtocolDiff:
        changes: list[DiffChange] = []

        # Compare metadata fields
        for field_name, label in [
            ("name", "Name"),
            ("type", "Type"),
            ("species", "Species"),
            ("strain", "Strain"),
        ]:
            va = getattr(a, field_name)
            vb = getattr(b, field_name)
            if va != vb:
                changes.append(DiffChange(field=field_name, label=label, old=va, new=vb))

        # Compare tags
        if set(a.tags) != set(b.tags):
            changes.append(
                DiffChange(field="tags", label="Tags", old=a.tags, new=b.tags)
            )

        # Compare brain regions
        if set(a.brain_regions) != set(b.brain_regions):
            changes.append(
                DiffChange(
                    field="brain_regions",
                    label="Brain Regions",
                    old=a.brain_regions,
                    new=b.brain_regions,
                )
            )

        # Compare step count
        if a.step_count != b.step_count:
            changes.append(
                DiffChange(
                    field="steps.count",
                    label="Step Count",
                    old=a.step_count,
                    new=b.step_count,
                )
            )

        # Compare individual steps
        max_steps = max(len(a.steps), len(b.steps))
        for i in range(max_steps):
            sa = a.steps[i] if i < len(a.steps) else None
            sb = b.steps[i] if i < len(b.steps) else None
            if sa is None:
                changes.append(
                    DiffChange(
                        field=f"steps.{i + 1}",
                        label=f"Step {i + 1}",
                        old="(missing)",
                        new=sb.description if sb else "",
                    )
                )
            elif sb is None:
                changes.append(
                    DiffChange(
                        field=f"steps.{i + 1}",
                        label=f"Step {i + 1}",
                        old=sa.description,
                        new="(missing)",
                    )
                )
            elif sa.description != sb.description:
                changes.append(
                    DiffChange(
                        field=f"steps.{i + 1}",
                        label=f"Step {i + 1}: {sa.title or sb.title or ''}".strip(": "),
                        old=sa.description,
                        new=sb.description,
                    )
                )

        # Compare equipment
        equip_a = {e.slug for e in a.equipment}
        equip_b = {e.slug for e in b.equipment}
        if equip_a != equip_b:
            only_a = equip_a - equip_b
            only_b = equip_b - equip_a
            if only_a:
                changes.append(
                    DiffChange(
                        field="equipment.removed",
                        label="Equipment (only in A)",
                        old=sorted(only_a),
                        new="(not present)",
                    )
                )
            if only_b:
                changes.append(
                    DiffChange(
                        field="equipment.added",
                        label="Equipment (only in B)",
                        old="(not present)",
                        new=sorted(only_b),
                    )
                )

        return cls(
            protocol_a=a.slug,
            protocol_b=b.slug,
            changes=changes,
        )
