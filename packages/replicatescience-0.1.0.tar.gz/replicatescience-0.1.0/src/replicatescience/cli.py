"""CLI interface for ReplicateScience."""

from __future__ import annotations

import json
import sys

import click
import yaml

import replicatescience as rs


@click.group()
@click.version_option(rs.__version__, prog_name="replicatescience")
@click.option("--api-key", envvar="RS_API_KEY", help="API key (or set RS_API_KEY)")
def main(api_key: str | None):
    """ReplicateScience CLI — search, compare, and export scientific protocols."""
    if api_key:
        rs.configure(api_key=api_key)


@main.command()
@click.argument("query")
@click.option("--species", help="Filter by species")
@click.option("--strain", help="Filter by strain")
@click.option("--type", "exp_type", help="Filter by experiment type")
@click.option("--limit", default=20, help="Max results", show_default=True)
@click.option("--page", default=1, help="Page number", show_default=True)
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def search(
    query: str,
    species: str | None,
    strain: str | None,
    exp_type: str | None,
    limit: int,
    page: int,
    as_json: bool,
):
    """Search protocols by keyword."""
    results = rs.search(
        query, species=species, strain=strain, type=exp_type, limit=limit, page=page
    )

    if as_json:
        click.echo(json.dumps([p.to_dict() for p in results.protocols], indent=2))
        return

    if not results.protocols:
        click.echo("No protocols found.")
        return

    for p in results.protocols:
        click.echo(f"  {p.slug}")
        click.echo(f"    {p.name}")
        meta = []
        if p.species:
            meta.append(p.species)
        if p.strain:
            meta.append(p.strain)
        meta.append(f"{p.step_count} steps")
        meta.append(f"{p.equipment_count} equipment")
        click.echo(f"    {' | '.join(meta)}")
        click.echo()

    if results.pagination:
        pg = results.pagination
        click.echo(f"Page {pg.page} of {(pg.total + pg.limit - 1) // pg.limit} ({pg.total} total)")


@main.command("get")
@click.argument("slug")
@click.option("--format", "fmt", type=click.Choice(["text", "json", "yaml"]), default="text", show_default=True)
def get_protocol(slug: str, fmt: str):
    """Get full protocol detail by slug."""
    protocol = rs.get(slug)

    if fmt == "json":
        click.echo(json.dumps(protocol.to_dict(), indent=2))
    elif fmt == "yaml":
        click.echo(yaml.dump(protocol.to_dict(), default_flow_style=False, sort_keys=False))
    else:
        click.echo(f"# {protocol.name}")
        click.echo(f"Paper: {protocol.paper.title}")
        if protocol.paper.doi:
            click.echo(f"DOI: {protocol.paper.doi}")
        click.echo(f"Species: {protocol.species or 'N/A'} | Strain: {protocol.strain or 'N/A'}")
        click.echo(f"Tags: {', '.join(protocol.tags) if protocol.tags else 'None'}")
        click.echo()

        if protocol.steps:
            click.echo("## Steps")
            for step in protocol.steps:
                title = f" — {step.title}" if step.title else ""
                duration = f" ({step.duration})" if step.duration else ""
                click.echo(f"  {step.number}. {step.description[:100]}{title}{duration}")
            click.echo()

        if protocol.equipment:
            click.echo("## Equipment")
            for eq in protocol.equipment:
                mfr = f" ({eq.manufacturer})" if eq.manufacturer else ""
                click.echo(f"  - {eq.name}{mfr}")


@main.command()
@click.argument("slug_a")
@click.argument("slug_b")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def diff(slug_a: str, slug_b: str, as_json: bool):
    """Compare two protocols."""
    # Load from file or API
    a = _load_or_fetch(slug_a)
    b = _load_or_fetch(slug_b)

    result = rs.diff(a, b)

    if as_json:
        out = {
            "protocol_a": result.protocol_a,
            "protocol_b": result.protocol_b,
            "summary": result.summary,
            "changes": [
                {"field": c.field, "label": c.label, "old": c.old, "new": c.new}
                for c in result.changes
            ],
        }
        click.echo(json.dumps(out, indent=2))
    else:
        click.echo(result.to_markdown())


def _load_or_fetch(slug_or_path: str) -> rs.ProtocolDetail:
    """Load a protocol from a local file or fetch by slug."""
    if slug_or_path.endswith((".yaml", ".yml", ".json")):
        return rs.load(slug_or_path)
    return rs.get(slug_or_path)


@main.command()
def whoami():
    """Show API key info and rate limits."""
    info = rs.me()
    click.echo(f"Email: {info.get('email', 'N/A')}")
    click.echo(f"Name: {info.get('name', 'N/A')}")
    click.echo(f"Tier: {info.get('tier', 'N/A')}")
    rl = info.get("rate_limit", {})
    click.echo(f"Rate limit: {rl.get('remaining', '?')}/{rl.get('limit', '?')} remaining")
    click.echo(f"Resets at: {rl.get('resets_at', 'N/A')}")
