# ReplicateScience Python SDK

## What This Is
Python SDK + CLI for the ReplicateScience API. Wraps https://replicatescience.com/api/v1/ endpoints. Published to PyPI as `replicatescience`.

**PyPI:** https://pypi.org/project/replicatescience/
**GitHub:** https://github.com/ShuhanCS/replicatescience-python
**API docs:** https://replicatescience.com/developers

## Structure
- `src/replicatescience/` — package source (src layout)
- `src/replicatescience/__init__.py` — top-level convenience functions (search, get, diff, save, load)
- `src/replicatescience/client.py` — HTTP client using httpx
- `src/replicatescience/models.py` — dataclass models matching API types
- `src/replicatescience/export.py` — YAML/JSON file export/import
- `src/replicatescience/cli.py` — Click CLI (`rs` command)

## Key Decisions
- Models match `src/types/api.ts` from the main replicatescience repo (snake_case)
- Uses httpx (not requests) for modern async-ready HTTP
- src layout for clean packaging
- Hatchling build backend (fast, modern)
- CLI entry point: `rs` (registered in pyproject.toml)

## Development
```bash
pip install -e ".[dev]"   # editable install
python -m pytest tests/   # run tests
python -m build           # build dist
twine upload dist/*       # publish to PyPI
```

## Rules
- Version in both `pyproject.toml` and `__init__.py` — keep in sync
- Models must stay in sync with the main replicatescience API types
- Never store or log API keys
