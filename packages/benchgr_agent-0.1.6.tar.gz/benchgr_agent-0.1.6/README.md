# benchgr-agent

GPU Benchmark Agent for [BenchGR Leaderboard](https://benchgr-frontend.vercel.app).

## Install
pip install benchgr-agent

## Usage
# Check your GPU
benchgr info

# Run benchmark (no submit)
benchgr run --no-submit

# Run and submit to leaderboard
benchgr run --api-key YOUR_API_KEY
