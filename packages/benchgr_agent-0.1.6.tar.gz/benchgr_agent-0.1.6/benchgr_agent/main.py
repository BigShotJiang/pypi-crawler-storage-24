import argparse
import sys
import json
import os
from benchgr_agent.benchmark import (
    get_gpu_info,
    run_inference_benchmark,
    run_cuda_benchmark,
    run_memory_bandwidth_benchmark,
    submit_results
)

CONFIG_FILE = os.path.join(os.path.expanduser("~"), ".benchgr_config.json")

def save_api_key(api_key):
    with open(CONFIG_FILE, "w") as f:
        json.dump({"api_key": api_key}, f)
    print(f"✅ API key saved! Now run: benchgr run")

def load_api_key():
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "r") as f:
            return json.load(f).get("api_key")
    return None

def main():
    parser = argparse.ArgumentParser(
        prog="benchgr",
        description="BenchGR — GPU Benchmark Agent"
    )
    subparsers = parser.add_subparsers(dest="command")

    # benchgr run
    run_parser = subparsers.add_parser("run", help="Run benchmark and submit")
    run_parser.add_argument("--api-key", type=str, help="Your BenchGR API key", default=None)
    run_parser.add_argument("--no-submit", action="store_true", help="Run without submitting")

    # benchgr info
    subparsers.add_parser("info", help="Show detected GPU info")

    # benchgr config set-key
    config_parser = subparsers.add_parser("config", help="Configure benchgr settings")
    config_subparsers = config_parser.add_subparsers(dest="config_command")
    setkey_parser = config_subparsers.add_parser("set-key", help="Save your API key")
    setkey_parser.add_argument("api_key", type=str, help="Your BenchGR API key")

    args = parser.parse_args()

    if args.command == "info":
        gpu, err = get_gpu_info()
        if err:
            print(f"❌ {err}")
        else:
            print(f"✅ GPU: {gpu['gpu_name']}")
            print(f"   VRAM: {gpu['vram_gb']} GB")

    elif args.command == "config":
        if args.config_command == "set-key":
            save_api_key(args.api_key)
        else:
            print("Usage: benchgr config set-key YOUR_API_KEY")

    elif args.command == "run":
        print("=" * 50)
        print("       🚀 BenchGR GPU Benchmark Agent")
        print("=" * 50)

        gpu, err = get_gpu_info()
        if err:
            print(f"❌ {err}")
            sys.exit(1)

        print(f"✅ Detected GPU: {gpu['gpu_name']} ({gpu['vram_gb']} GB VRAM)\n")

        tokens_per_sec = run_inference_benchmark()
        tflops = run_cuda_benchmark()
        mem_bw = run_memory_bandwidth_benchmark()

        results = {
            "gpu_name": gpu["gpu_name"],
            "vram_gb": gpu["vram_gb"],
            "tokens_per_sec": tokens_per_sec,
            "tflops_fp16": tflops,
            "memory_bw_gbps": mem_bw,
        }

        print("\n" + "=" * 50)
        print("📊 BENCHMARK RESULTS")
        print("=" * 50)
        print(f"  GPU         : {gpu['gpu_name']}")
        print(f"  Tokens/sec  : {tokens_per_sec} tok/s")
        print(f"  TFLOPS FP16 : {tflops} TFLOPS")
        print(f"  Mem BW      : {mem_bw} GB/s")
        print("=" * 50)

        if not args.no_submit:
            api_key = args.api_key or load_api_key()
            if not api_key:
                print("\n⚠️  No API key found. Set it first:")
                print("   benchgr config set-key YOUR_API_KEY")
                return

            print("\n📤 Submitting to leaderboard...")
            response = submit_results(api_key, results)
            if "error" in response:
                print(f"❌ Submission failed: {response['error']}")
            else:
                print(f"✅ Submitted! Check your rank at:")
                print(f"   👉 https://benchgr-frontend.vercel.app/leaderboard")
        else:
            print("\n✅ Done! (Results not submitted)")

    else:
        print("Usage:")
        print("  benchgr config set-key YOUR_API_KEY")
        print("  benchgr run")
        print("  benchgr info")
        print("  benchgr run --no-submit")

if __name__ == "__main__":
    main()
