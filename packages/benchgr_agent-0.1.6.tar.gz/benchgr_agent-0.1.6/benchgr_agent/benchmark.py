import time
import torch
import numpy as np
from transformers import AutoTokenizer, AutoModelForCausalLM

BACKEND_URL = "https://benchgr-backend.vercel.app"
MODEL_ID = "TinyLlama/TinyLlama-1.1B-Chat-v1.0"


def get_gpu_info():
    if not torch.cuda.is_available():
        return None, "No CUDA GPU detected. Please run on a CUDA-enabled GPU."
    
    gpu_name = torch.cuda.get_device_name(0)
    vram_total = torch.cuda.get_device_properties(0).total_memory / (1024 ** 3)
    return {"gpu_name": gpu_name, "vram_gb": round(vram_total, 2)}, None


def run_inference_benchmark():
    print("📥 Loading TinyLlama 1.1B (first run may take 1-2 mins to download ~600MB)...")
    
    tokenizer = AutoTokenizer.from_pretrained(MODEL_ID)
    model = AutoModelForCausalLM.from_pretrained(
        MODEL_ID,
        torch_dtype=torch.float16,
    ).to("cuda")
    model.eval()

    prompt = "Explain what a GPU does in simple terms."
    inputs = tokenizer(prompt, return_tensors="pt").to("cuda")

    # Warmup pass
    with torch.no_grad():
        model.generate(**inputs, max_new_tokens=20)

    # Actual benchmark — 3 runs averaged
    total_tokens = 0
    total_time = 0.0
    runs = 3

    print("⚡ Running inference benchmark (3 passes)...")
    for i in range(runs):
        torch.cuda.synchronize()
        start = time.perf_counter()
        with torch.no_grad():
            output = model.generate(**inputs, max_new_tokens=100)
        torch.cuda.synchronize()
        end = time.perf_counter()

        tokens_generated = output.shape[1] - inputs["input_ids"].shape[1]
        total_tokens += tokens_generated
        total_time += (end - start)
        print(f"   Pass {i+1}: {tokens_generated / (end - start):.1f} tok/s")

    tokens_per_sec = round(total_tokens / total_time, 2)
    return tokens_per_sec


def run_cuda_benchmark():
    print("🔢 Running CUDA matrix benchmark...")
    size = 4096
    a = torch.randn(size, size, device="cuda", dtype=torch.float16)
    b = torch.randn(size, size, device="cuda", dtype=torch.float16)

    # Warmup
    torch.matmul(a, b)
    torch.cuda.synchronize()

    runs = 10
    start = time.perf_counter()
    for _ in range(runs):
        torch.matmul(a, b)
    torch.cuda.synchronize()
    end = time.perf_counter()

    avg_ms = ((end - start) / runs) * 1000
    # TFLOPS = (2 * N^3) / (time_in_seconds * 1e12)
    tflops = round((2 * size**3) / ((avg_ms / 1000) * 1e12), 2)
    return tflops


def run_memory_bandwidth_benchmark():
    print("💾 Running memory bandwidth benchmark...")
    size = 256 * 1024 * 1024 // 4  # 256MB of float32
    a = torch.ones(size, device="cuda", dtype=torch.float32)
    b = torch.empty(size, device="cuda", dtype=torch.float32)

    torch.cuda.synchronize()
    start = time.perf_counter()
    for _ in range(5):
        b.copy_(a)
    torch.cuda.synchronize()
    end = time.perf_counter()

    mem_bw_gbps = round((5 * 256 * 2) / (end - start), 2)  # GB/s (read + write)
    return mem_bw_gbps


def submit_results(api_key, results):
    import requests
    try:
        resp = requests.post(
            f"{BACKEND_URL}/api/results/submit",
            params={"api_key": api_key},
            json=results,
            timeout=10
        )
        return resp.json()
    except Exception as e:
        return {"error": str(e)}
