"""
corpis/engine/update.py

Update a file's logic record after a code change.
The agent's description of WHY the change was made becomes a permanent,
dated changelog entry — turning the record into an architectural decision log.

Usage (CLI):  corpis update <path/to/file> "<what changed and why>"
"""

import os
import sys
import re
import json
import time
import threading
from datetime import date, datetime
from dotenv import load_dotenv

from corpis.engine.paths import get_corpis_dir, get_repo_root

try:
    import chromadb
    from chromadb.utils import embedding_functions
    from openai import OpenAI
except ImportError:
    print("  Error: Dependencies not found. Run: pip install corpis")
    exit(1)

# ── Terminal ──────────────────────────────────────────────────────────────────
def _c(*codes): return "".join(f"\033[{c}m" for c in codes)

RESET       = _c(0)
BOLD        = _c(1)
DIM         = _c(2)
ITALIC      = _c(3)
FG_BCYAN    = _c(96)
FG_BGREEN   = _c(92)
FG_BYELLOW  = _c(93)
FG_BMAGENTA = _c(95)
FG_WHITE    = _c(97)
FG_GRAY     = _c(90)

INTERACTIVE = sys.stdout.isatty()

def term_width():
    try:
        return os.get_terminal_size().columns
    except OSError:
        return 80

def clear_line():
    sys.stdout.write("\r\033[K")
    sys.stdout.flush()

def hr(char="─", color=FG_GRAY, indent=4):
    w = max(term_width() - indent * 2, 20)
    print(f"{' ' * indent}{color}{DIM}{char * w}{RESET}")

def spinner_thread(label, stop_event):
    frames = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
    i = 0
    while not stop_event.is_set():
        sys.stdout.write(f"\r     {FG_BCYAN}{frames[i % len(frames)]}{RESET}  {DIM}{label}{RESET}")
        sys.stdout.flush()
        time.sleep(0.075)
        i += 1
    clear_line()

def with_spinner(label, fn):
    if not INTERACTIVE:
        return fn()
    stop = threading.Event()
    t = threading.Thread(target=spinner_thread, args=(label, stop), daemon=True)
    t.start()
    try:
        result = fn()
    finally:
        stop.set(); t.join()
    return result

# ── Helpers ───────────────────────────────────────────────────────────────────
def slugify(text):
    text = text.lower().strip()
    text = re.sub(r"[^\w\s-]", "", text)
    text = re.sub(r"[\s_]+", "-", text)
    text = re.sub(r"-+", "-", text)
    return text[:60].strip("-") or "general"

def logic_id_for(rel_path):
    from hashlib import md5
    return md5(rel_path.encode()).hexdigest()[:8]

def unique_doc_path(docs_path, folder, filename, exclude=None):
    base      = os.path.join(docs_path, folder, filename)
    candidate = f"{base}.md"
    counter   = 2
    while os.path.exists(candidate) and candidate != exclude:
        candidate = f"{base}-{counter}.md"
        counter  += 1
    return candidate

def parse_doc_sections(content):
    s = {}
    m = re.match(r"^# (.+)", content, re.MULTILINE)
    s["title"] = m.group(1).strip() if m else ""

    m = re.search(r"## Purpose\n(.*?)(?=\n## |\n---)", content, re.DOTALL)
    s["purpose"] = m.group(1).strip() if m else ""

    m = re.search(r"## How It Works\n(.*?)(?=\n---)", content, re.DOTALL)
    s["technical"] = m.group(1).strip() if m else ""

    m = re.search(r"(---\n.*?)(?=\n## Changelog|\Z)", content, re.DOTALL)
    s["footer"] = m.group(1).strip() if m else ""

    m = re.search(r"## Changelog\n\n(.*)", content, re.DOTALL)
    raw_cl = m.group(1).strip() if m else ""
    s["changelog"] = "" if raw_cl == "*(no changes recorded yet)*" else raw_cl

    return s

def write_doc_file(path, title, purpose, technical, footer, changelog=""):
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"# {title}\n\n")
        f.write(f"## Purpose\n{purpose}\n\n")
        f.write(f"## How It Works\n{technical}\n\n")
        f.write(f"{footer}\n\n")
        f.write("## Changelog\n\n")
        f.write((changelog.strip() + "\n") if changelog.strip() else "*(no changes recorded yet)*\n")

# ── LLM calls ─────────────────────────────────────────────────────────────────
def _str(val):
    if isinstance(val, list):
        return "\n".join(
            item if str(item).startswith("- ") else f"- {item}"
            for item in val
        )
    return str(val).strip() if val else ""

def distill_logic(client_ai, code_block, file_path):
    prompt = (
        f"File: {file_path}\n"
        f"Code:\n{code_block}\n\n"
        "Return a JSON object with exactly these keys:\n"
        "  folder    — a short, lowercase business-domain slug.\n"
        "  title     — a descriptive, human-readable name for this logic.\n"
        "  purpose   — 2-4 sentences explaining WHY this logic exists.\n"
        "  technical — HOW it works: key mechanisms. Use bullet points (- item).\n"
        "Respond with valid JSON only, no markdown fences."
    )
    response = client_ai.chat.completions.create(
        model="gpt-4o",
        response_format={"type": "json_object"},
        messages=[
            {"role": "system", "content": "You are a senior technical architect analysing a codebase for Corpis."},
            {"role": "user",   "content": prompt},
        ],
    )
    data      = json.loads(response.choices[0].message.content)
    folder    = slugify(data.get("folder",    "general"))
    title     = _str(data.get("title",        "Logic Record")) or "Logic Record"
    filename  = slugify(title) or "logic"
    purpose   = _str(data.get("purpose",      ""))
    technical = _str(data.get("technical",    ""))
    return folder, filename, title, purpose, technical

def generate_update(client_ai, existing_doc, file_path, code_block, change_description):
    now    = datetime.now().strftime("%Y-%m-%d %H:%M")
    prompt = (
        f"File: {file_path}\n"
        f"Agent's change description: \"{change_description}\"\n"
        f"Timestamp: {now}\n\n"
        f"Current code (preview):\n{code_block}\n\n"
        f"Existing logic record:\n{existing_doc}\n\n"
        "Return a JSON object with:\n"
        "  updated_purpose — rewritten '## Purpose' text reflecting the current state. "
        "2-4 sentences on WHY it exists now.\n"
        "  changelog_entry — a new changelog entry in this exact format:\n"
        f"    ### {now} — <short imperative title>\n"
        "    <2-4 sentences: what changed, why, any alternatives or tradeoffs.>\n"
        "Respond with valid JSON only, no markdown fences."
    )
    response = client_ai.chat.completions.create(
        model="gpt-4o",
        response_format={"type": "json_object"},
        messages=[
            {"role": "system", "content": "You are maintaining an architectural decision log for a codebase."},
            {"role": "user",   "content": prompt},
        ],
    )
    data = json.loads(response.choices[0].message.content)
    return (
        _str(data.get("updated_purpose", "")),
        _str(data.get("changelog_entry", "")),
    )

# ── Cache invalidation ────────────────────────────────────────────────────────
def invalidate_cache(cache_path, doc_rel):
    if not os.path.isdir(cache_path):
        return 0
    try:
        ef = embedding_functions.OpenAIEmbeddingFunction(
            api_key=os.getenv("OPENAI_API_KEY"),
            model_name="text-embedding-3-small"
        )
        cc = chromadb.PersistentClient(path=cache_path).get_or_create_collection(
            name="answer_cache", embedding_function=ef,
            metadata={"hnsw:space": "cosine"},
        )
        if cc.count() == 0:
            return 0
        all_entries = cc.get()
        stale_ids = [
            eid for eid, meta in zip(all_entries["ids"], all_entries["metadatas"])
            if doc_rel in meta.get("doc_files", "").split("|")
        ]
        if stale_ids:
            cc.delete(ids=stale_ids)
        return len(stale_ids)
    except Exception:
        return 0

# ── Core ──────────────────────────────────────────────────────────────────────
def init_db(db_path):
    chroma_client = chromadb.PersistentClient(path=db_path)
    ef = embedding_functions.OpenAIEmbeddingFunction(
        api_key=os.getenv("OPENAI_API_KEY"),
        model_name="text-embedding-3-small"
    )
    return chroma_client.get_or_create_collection(
        name="logic_ledger",
        embedding_function=ef,
        metadata={"hnsw:space": "cosine"},
    )

def update_file(file_path, change_description):
    corpis_dir = get_corpis_dir()
    repo_root  = get_repo_root()
    db_path    = os.path.join(corpis_dir, "db")
    docs_path  = os.path.join(corpis_dir, "docs")
    cache_path = os.path.join(corpis_dir, "cache")

    load_dotenv(os.path.join(corpis_dir, ".env"))
    client_ai = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

    abs_path = os.path.abspath(file_path)
    if not os.path.isfile(abs_path):
        print(f"\n  {FG_BYELLOW}⚠  File not found: {file_path}{RESET}\n")
        sys.exit(1)

    rel = os.path.relpath(abs_path, repo_root)

    with open(abs_path, "r", encoding="utf-8", errors="ignore") as f:
        content = f.read()

    if not content.strip():
        print(f"\n  {FG_BYELLOW}⚠  File is empty, nothing to index.{RESET}\n")
        sys.exit(0)

    collection = init_db(db_path)
    lid        = logic_id_for(rel)

    existing     = collection.get(ids=[lid])
    is_new       = not existing["ids"]
    old_doc_rel  = None if is_new else existing["metadatas"][0].get("doc_file")
    old_doc_abs  = os.path.join(docs_path, old_doc_rel) if old_doc_rel else None
    existing_doc = ""
    if old_doc_abs and os.path.isfile(old_doc_abs):
        with open(old_doc_abs, "r", encoding="utf-8") as f:
            existing_doc = f.read()

    if INTERACTIVE:
        print()
        print(f"  {BOLD}{FG_BCYAN}◈  Corpis update{RESET}  {FG_GRAY}·{RESET}  {DIM}{rel}{RESET}")
        hr("▔", FG_BCYAN, indent=2)
        print()

    if is_new:
        folder, filename, title, purpose, technical = with_spinner(
            "Distilling logic…",
            lambda: distill_logic(client_ai, content[:3000], rel)
        )
        new_doc_path = unique_doc_path(docs_path, folder, filename)
        os.makedirs(os.path.dirname(new_doc_path), exist_ok=True)
        doc_rel = os.path.relpath(new_doc_path, docs_path)

        footer          = f"---\n**Source:** `{rel}`  \n**Domain:** `{folder}`  \n**Logic ID:** `{lid}`"
        changelog_entry = f"### {datetime.now().strftime('%Y-%m-%d %H:%M')} — Initial record\n{change_description}"
        write_doc_file(new_doc_path, title, purpose, technical, footer, changelog_entry)

    else:
        updated_purpose, changelog_entry = with_spinner(
            "Generating changelog entry…",
            lambda: generate_update(client_ai, existing_doc, rel, content[:3000], change_description)
        )
        parts = parse_doc_sections(existing_doc)
        if updated_purpose:
            parts["purpose"] = updated_purpose

        new_changelog = (
            (parts["changelog"].strip() + "\n\n" + changelog_entry)
            if parts["changelog"].strip()
            else changelog_entry
        )

        new_doc_path = old_doc_abs
        doc_rel      = old_doc_rel
        folder       = existing["metadatas"][0].get("domain", "general")
        purpose      = parts["purpose"]
        technical    = parts["technical"]
        write_doc_file(new_doc_path, parts["title"], purpose, technical, parts["footer"], new_changelog)

    embed_text = f"file: {rel}\ndomain: {folder}\nPURPOSE: {purpose}\nTECHNICAL: {technical}"
    collection.upsert(
        documents=[embed_text],
        ids=[lid],
        metadatas={
            "source_file": rel,
            "doc_file":    doc_rel,
            "description": purpose,
            "domain":      folder,
        },
    )

    action        = "added" if is_new else "updated"
    n_invalidated = invalidate_cache(cache_path, doc_rel)

    if INTERACTIVE:
        print(f"     {FG_BGREEN}✓{RESET}  record {action}  {FG_GRAY}→{RESET}  {FG_BCYAN}{doc_rel}{RESET}")
        print()
        if n_invalidated:
            print(f"     {FG_BGREEN}✓{RESET}  invalidated {n_invalidated} cached "
                  f"answer{'s' if n_invalidated != 1 else ''} referencing this record")
            print()
        hr("─", FG_GRAY, indent=4)
        print()
        for line in changelog_entry.splitlines():
            stripped = line.lstrip()
            if stripped.startswith("### "):
                print(f"     {BOLD}{FG_WHITE}{stripped[4:]}{RESET}")
            else:
                print(f"     {FG_GRAY}{line}{RESET}")
        print()
        hr("▁", FG_BCYAN, indent=2)
        print()
        print(f"  {FG_GRAY}Corpus is current. Embedding refreshed.{RESET}")
        print()
    else:
        inv = f", {n_invalidated} cache entr{'ies' if n_invalidated != 1 else 'y'} invalidated" if n_invalidated else ""
        print(f"corpis: record {action} ({doc_rel}){inv}")


# ── Entry point (direct invocation) ──────────────────────────────────────────
if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(f"\n  {FG_BYELLOW}Usage:{RESET}  corpis update <file> \"<what changed and why>\"\n")
        sys.exit(1)
    update_file(sys.argv[1], sys.argv[2])
