"""
Shared path resolution for Corpis engine modules.

When installed as a pip package the engine scripts live in site-packages, so
__file__-relative paths no longer reach the project's corpis/ data directory.
All engine modules import from here instead of computing paths via __file__.
"""

import os


def get_corpis_dir() -> str:
    """
    Return the path to the corpis/ data directory.
    Defaults to corpis/ inside the current working directory (the project root).
    Override with CORPIS_DIR env var if needed.
    """
    return os.environ.get("CORPIS_DIR", os.path.join(os.getcwd(), "corpis"))


def get_repo_root() -> str:
    """
    Return the repository root (parent of corpis/).
    Defaults to the current working directory.
    Override with CORPIS_REPO_ROOT env var if needed.
    """
    return os.environ.get("CORPIS_REPO_ROOT", os.getcwd())


def ensure_dirs():
    """Create the corpis data directories if they don't exist."""
    corpis_dir = get_corpis_dir()
    for sub in ("docs", "db", "cache"):
        os.makedirs(os.path.join(corpis_dir, sub), exist_ok=True)
