"""
corpis/engine/query.py

Interactive TUI chat interface for querying the Corpis knowledge corpus.
When stdin is not a tty (piped), suppresses all TUI output and prints only
the plain answer text.

Usage (CLI):  corpis query
              echo "question" | corpis query
"""

import os
import sys
import json
import time
import uuid
import textwrap
import threading
from datetime import date, datetime
from dotenv import load_dotenv

from corpis.engine.paths import get_corpis_dir

try:
    import chromadb
    from chromadb.utils import embedding_functions
    from openai import OpenAI
except ImportError:
    print("  Error: Dependencies not found. Run: pip install corpis")
    exit(1)

# ── Terminal ──────────────────────────────────────────────────────────────────
def _c(*codes): return "".join(f"\033[{c}m" for c in codes)

RESET   = _c(0)
BOLD    = _c(1)
DIM     = _c(2)
ITALIC  = _c(3)

FG_CYAN     = _c(36)
FG_BCYAN    = _c(96)
FG_BLUE     = _c(34)
FG_BBLUE    = _c(94)
FG_GREEN    = _c(32)
FG_BGREEN   = _c(92)
FG_YELLOW   = _c(33)
FG_MAGENTA  = _c(35)
FG_BMAGENTA = _c(95)
FG_WHITE    = _c(97)
FG_GRAY     = _c(90)

BG_DARK  = _c(48, 5, 234)
BG_RESET = _c(49)

INTERACTIVE = sys.stdin.isatty()

def term_width():
    try:
        return os.get_terminal_size().columns
    except OSError:
        return 80

# ── Setup (lazy — resolved at call time so CWD is correct) ───────────────────
_state = {}

def _setup():
    if _state:
        return
    corpis_dir = get_corpis_dir()
    load_dotenv(os.path.join(corpis_dir, ".env"))
    db_path    = os.path.join(corpis_dir, "db")
    cache_path = os.path.join(corpis_dir, "cache")

    if not os.path.isdir(db_path):
        print("  Error: corpus not found. Run `corpis init` then `corpis genesis` first.")
        sys.exit(1)

    ef = embedding_functions.OpenAIEmbeddingFunction(
        api_key=os.getenv("OPENAI_API_KEY"),
        model_name="text-embedding-3-small"
    )
    chroma_client = chromadb.PersistentClient(path=db_path)
    collection = chroma_client.get_or_create_collection(
        name="logic_ledger",
        embedding_function=ef,
        metadata={"hnsw:space": "cosine"},
    )
    os.makedirs(cache_path, exist_ok=True)
    cache_client = chromadb.PersistentClient(path=cache_path)
    cache_collection = cache_client.get_or_create_collection(
        name="answer_cache",
        embedding_function=ef,
        metadata={"hnsw:space": "cosine"},
    )
    client_ai = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

    _state.update({
        "corpis_dir":       corpis_dir,
        "docs_path":        os.path.join(corpis_dir, "docs"),
        "collection":       collection,
        "cache_collection": cache_collection,
        "client_ai":        client_ai,
    })

# ── UI Helpers ────────────────────────────────────────────────────────────────
CACHE_THRESHOLD = 0.25   # cosine distance — below this = same question (paraphrase-tolerant)

def clear_line():
    sys.stdout.write("\r\033[K")
    sys.stdout.flush()

def spinner(label, stop_event):
    frames = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
    i = 0
    while not stop_event.is_set():
        frame = f"{FG_BCYAN}{frames[i % len(frames)]}{RESET}"
        sys.stdout.write(f"\r     {frame}  {DIM}{label}{RESET}")
        sys.stdout.flush()
        time.sleep(0.075)
        i += 1
    clear_line()

def with_spinner(label, fn):
    if not INTERACTIVE:
        return fn()
    stop = threading.Event()
    t = threading.Thread(target=spinner, args=(label, stop), daemon=True)
    t.start()
    try:
        result = fn()
    finally:
        stop.set(); t.join()
    return result

def hr(char="─", color=FG_GRAY, indent=4):
    w = max(term_width() - indent * 2, 20)
    print(f"{' ' * indent}{color}{DIM}{char * w}{RESET}")

def print_banner():
    w = term_width()
    pad = max((w - 44) // 2, 2)
    sp  = " " * pad
    print()
    print(f"{sp}{BOLD}{FG_BCYAN}╭{'─' * 42}╮{RESET}")
    print(f"{sp}{BOLD}{FG_BCYAN}│{RESET}{'':^42}{BOLD}{FG_BCYAN}│{RESET}")
    print(f"{sp}{BOLD}{FG_BCYAN}│{RESET}  {BOLD}{FG_WHITE}◈  CORPIS{RESET}  {FG_GRAY}·{RESET}  {ITALIC}{FG_BCYAN}Knowledge Agent{RESET}{'':^16}{BOLD}{FG_BCYAN}│{RESET}")
    print(f"{sp}{BOLD}{FG_BCYAN}│{RESET}{'':^42}{BOLD}{FG_BCYAN}│{RESET}")
    print(f"{sp}{BOLD}{FG_BCYAN}╰{'─' * 42}╯{RESET}")
    print()
    print(f"{sp}{FG_GRAY}Ask anything about your codebase.{RESET}")
    print(f"{sp}{FG_GRAY}Type {BOLD}{FG_WHITE}exit{RESET}{FG_GRAY} to quit  ·  {BOLD}{FG_WHITE}clear{RESET}{FG_GRAY} to reset  ·  {BOLD}{FG_WHITE}!{RESET}{FG_GRAY} prefix to bypass cache{RESET}")
    print()

def print_user_msg(text):
    w     = min(term_width() - 12, 72)
    lines = textwrap.wrap(text, width=w) or [text]
    box_w = max(len(l) for l in lines) + 4
    pad   = max(term_width() - box_w - 4, 4)
    sp    = " " * pad
    print()
    print(f"{sp}{FG_BBLUE}{BOLD}you{RESET}")
    print(f"{sp}{FG_BLUE}╭{'─' * box_w}╮{RESET}")
    for line in lines:
        inner = line.ljust(box_w - 2)
        print(f"{sp}{FG_BLUE}│{RESET} {FG_WHITE}{BOLD}{inner}{RESET} {FG_BLUE}│{RESET}")
    print(f"{sp}{FG_BLUE}╰{'─' * box_w}╯{RESET}")

def print_assistant_msg(answer, source_file, doc_filename, doc_tokens):
    w          = min(term_width() - 10, 74)
    indent     = "     "
    paragraphs = answer.strip().split("\n")
    print()
    print(f"  {BOLD}{FG_BCYAN}◈ corpis{RESET}  {FG_GRAY}{ITALIC}Knowledge Agent{RESET}")
    hr("▔", FG_BCYAN, indent=2)
    print()
    for para in paragraphs:
        if not para.strip():
            print(); continue
        stripped = para.lstrip()
        if stripped.startswith(("**", "##", "###")):
            cleaned = stripped.replace("**", "").replace("###", "").replace("##", "").strip()
            print(f"{indent}{BOLD}{FG_WHITE}{cleaned}{RESET}")
        elif stripped.startswith(("- ", "* ", "• ")):
            body    = stripped[2:]
            wrapped = textwrap.wrap(body, width=w - 6)
            print(f"{indent}  {FG_BCYAN}◦{RESET}  {wrapped[0]}")
            for cont in wrapped[1:]:
                print(f"{indent}     {cont}")
        else:
            for line in textwrap.wrap(para, width=w):
                print(f"{indent}{line}")
    print()
    hr("▁", FG_BCYAN, indent=2)
    print()
    print(f"  {FG_GRAY}╰─{RESET}  {FG_GRAY}source{RESET}  {FG_BMAGENTA}{source_file}{RESET}  {FG_GRAY}·{RESET}  {DIM}{doc_filename}{RESET}")
    print(f"     {FG_GRAY}tokens{RESET}  {FG_YELLOW}~{int(doc_tokens)}{RESET}  {FG_GRAY}(saved ~90 % context){RESET}")
    print()

def print_error(msg):
    print(f"\n  {FG_YELLOW}⚠  {BOLD}{msg}{RESET}\n")

def human_age(iso_timestamp):
    try:
        then  = datetime.fromisoformat(iso_timestamp).date()
        delta = (date.today() - then).days
        if delta == 0:   return "today"
        if delta == 1:   return "yesterday"
        if delta < 30:   return f"{delta} days ago"
        if delta < 365:  return f"{delta // 30} months ago"
        return iso_timestamp[:10]
    except Exception:
        return iso_timestamp[:10]

def print_cached_answer(entry):
    answer    = entry["answer"]
    sources   = entry["sources"]
    age       = human_age(entry["timestamp"])
    w         = min(term_width() - 10, 74)
    indent    = "     "
    print()
    print(f"  {BOLD}{FG_BCYAN}◈ corpis{RESET}  {FG_GRAY}{ITALIC}Knowledge Agent{RESET}  "
          f"{FG_GRAY}·{RESET}  {FG_BGREEN}cached{RESET}  {FG_GRAY}{DIM}{age}{RESET}")
    hr("▔", FG_BCYAN, indent=2)
    print()
    for para in answer.strip().split("\n"):
        if not para.strip():
            print(); continue
        stripped = para.lstrip()
        if stripped.startswith(("**", "##", "###")):
            cleaned = stripped.replace("**","").replace("###","").replace("##","").strip()
            print(f"{indent}{BOLD}{FG_WHITE}{cleaned}{RESET}")
        elif stripped.startswith(("- ", "* ", "• ")):
            body    = stripped[2:]
            wrapped = textwrap.wrap(body, width=w - 6)
            print(f"{indent}  {FG_BCYAN}◦{RESET}  {wrapped[0]}")
            for cont in wrapped[1:]:
                print(f"{indent}     {cont}")
        else:
            for line in textwrap.wrap(para, width=w):
                print(f"{indent}{line}")
    print()
    hr("▁", FG_BCYAN, indent=2)
    print()
    print(f"  {FG_GRAY}╰─{RESET}  {FG_GRAY}source{RESET}  {FG_BMAGENTA}{sources}{RESET}")
    print(f"     {FG_GRAY}prefix with{RESET}  {BOLD}!{RESET}  {FG_GRAY}to force a fresh answer{RESET}")
    print()

def score_pct(distance):
    return max(0, round((1 - distance / 2) * 100))

def score_bar(pct, width=8):
    filled = round(pct / 100 * width)
    bar    = "█" * filled + "░" * (width - filled)
    color  = FG_BGREEN if pct >= 70 else (FG_YELLOW if pct >= 40 else FG_GRAY)
    return f"{color}{bar}{RESET}"

def print_scout_list(candidates):
    print()
    print(f"  {BOLD}{FG_BCYAN}◈ scouting corpus{RESET}  {FG_GRAY}·{RESET}  {DIM}{len(candidates)} candidates{RESET}")
    hr("▔", FG_BCYAN, indent=2)
    print()
    print(f"  {FG_GRAY}  #  score              domain          record{RESET}")
    print(f"  {FG_GRAY}  {'─'*3}  {'─'*18}  {'─'*14}  {'─'*36}{RESET}")
    for i, c in enumerate(candidates, 1):
        pct    = c["score"]
        bar    = score_bar(pct)
        num    = f"{FG_GRAY}{i:>3}{RESET}"
        score  = f"{bar} {BOLD}{pct:>3}%{RESET}"
        domain = f"{FG_BMAGENTA}{c['domain']:<14}{RESET}"
        doc    = f"{FG_BCYAN}{c['doc_file']}{RESET}"
        desc   = c.get("description", "")
        print(f"  {num}  {score}  {domain}  {doc}")
        if desc:
            print(f"       {' ':>18}  {' ':>14}  {FG_GRAY}{DIM}{desc}{RESET}")
    print()

def print_reading(selected_docs):
    for doc in selected_docs:
        print(f"     {FG_BGREEN}▸{RESET}  reading  {FG_BCYAN}{doc}{RESET}")
    print()

# ── Cache ─────────────────────────────────────────────────────────────────────
def cache_lookup(question):
    cc = _state["cache_collection"]
    if cc.count() == 0:
        return None
    results = cc.query(query_texts=[question], n_results=1)
    if not results["ids"] or not results["ids"][0]:
        return None
    if results["distances"][0][0] > CACHE_THRESHOLD:
        return None
    meta = results["metadatas"][0][0]
    return {
        "answer":    meta["answer"],
        "sources":   meta["sources"],
        "doc_files": meta["doc_files"],
        "timestamp": meta["timestamp"],
        "question":  meta["question"],
    }

def cache_write(question, answer, sources, doc_files):
    _state["cache_collection"].add(
        documents=[question],
        ids=[str(uuid.uuid4())],
        metadatas={
            "question":  question,
            "answer":    answer,
            "sources":   "|".join(sources),
            "doc_files": "|".join(doc_files),
            "timestamp": datetime.now().isoformat(),
        },
    )

# ── Core ──────────────────────────────────────────────────────────────────────
def chat_with_corpis(user_query, force_fresh=False):
    collection = _state["collection"]
    client_ai  = _state["client_ai"]
    docs_path  = _state["docs_path"]

    # ── Cache check ───────────────────────────────────────────────────────────
    if not force_fresh:
        hit = with_spinner("Checking cache…", lambda: cache_lookup(user_query))
        if hit:
            if INTERACTIVE:
                print_cached_answer(hit)
            else:
                print(hit["answer"])
            return

    # ── Stage 1: Scout ────────────────────────────────────────────────────────
    n_candidates = min(8, max(1, collection.count()))
    results = with_spinner(
        "Scouting knowledge base…",
        lambda: collection.query(query_texts=[user_query], n_results=n_candidates)
    )

    if not results["ids"] or not results["ids"][0]:
        print_error("No matching logic records found. Has genesis been run?")
        return

    candidates = []
    for meta, dist in zip(results["metadatas"][0], results["distances"][0]):
        candidates.append({
            "doc_file":    meta["doc_file"],
            "source_file": meta["source_file"],
            "domain":      meta.get("domain", "—"),
            "description": meta.get("description", ""),
            "score":       score_pct(dist),
        })

    if INTERACTIVE:
        print_scout_list(candidates)

    # ── Stage 2: AI selects which records to read ─────────────────────────────
    scores     = [c["score"] for c in candidates]
    score_span = max(scores) - min(scores)
    all_low    = max(scores) < 75

    if len(candidates) <= 3 or score_span < 15 or all_low:
        selected_indices = list(range(1, len(candidates) + 1))
    else:
        candidate_list = "\n".join(
            f"{i+1}. [{c['score']}% · {c['domain']}] {c['doc_file']}\n   {c['description']}"
            for i, c in enumerate(candidates)
        )
        selection_resp = with_spinner(
            "Selecting relevant records…",
            lambda: client_ai.chat.completions.create(
                model="gpt-4o",
                response_format={"type": "json_object"},
                messages=[
                    {
                        "role": "system",
                        "content": (
                            "You are the Corpis Knowledge Agent selecting logic records to read. "
                            "Rules:\n"
                            "- For broad or overview questions select ALL candidates.\n"
                            "- For specific questions, select only the most relevant 1-3 records.\n"
                            "- A lower-scored record is still worth reading if its description is "
                            "clearly relevant to the question.\n"
                            "Return JSON: {\"selected\": [1, 2, 3]} using 1-based indices."
                        ),
                    },
                    {
                        "role": "user",
                        "content": (
                            f"QUESTION: {user_query}\n\n"
                            f"CANDIDATES:\n{candidate_list}\n\n"
                            "Which record numbers should I read?"
                        ),
                    },
                ],
            )
        )
        try:
            selected_indices = json.loads(selection_resp.choices[0].message.content).get("selected", [1])
            selected_indices = [i for i in selected_indices if 1 <= i <= len(candidates)]
        except Exception:
            selected_indices = [1]
        if not selected_indices:
            selected_indices = [1]

    selected = [candidates[i - 1] for i in selected_indices]
    if INTERACTIVE:
        print_reading([c["doc_file"] for c in selected])

    # ── Stage 3: Read selected records and synthesise ─────────────────────────
    context_blocks = []
    for c in selected:
        doc_path = os.path.join(docs_path, c["doc_file"])
        try:
            with open(doc_path, "r") as f:
                context_blocks.append(
                    f"=== {c['doc_file']} (source: {c['source_file']}) ===\n{f.read()}"
                )
        except FileNotFoundError:
            context_blocks.append(f"=== {c['doc_file']} — FILE NOT FOUND ===")

    combined_context = "\n\n".join(context_blocks)
    sources    = [c["source_file"] for c in selected]
    doc_files  = [c["doc_file"] for c in selected]
    doc_tokens = len(combined_context.split()) * 1.3

    answer_resp = with_spinner(
        "Synthesising answer…",
        lambda: client_ai.chat.completions.create(
            model="gpt-4o",
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are the Corpis Knowledge Agent. Use the provided Logic Records to "
                        "answer the user's question. Be concise and professional.\n\n"
                        "Important:\n"
                        "- For broad questions, synthesise from the collective picture across ALL "
                        "records — even if no single record states the answer directly.\n"
                        "- For specific questions, focus on the most relevant record and cite it.\n"
                        "- Never say you don't know if the answer can be reasonably inferred."
                    ),
                },
                {
                    "role": "user",
                    "content": f"LOGIC RECORDS:\n{combined_context}\n\nQUESTION: {user_query}",
                },
            ],
        )
    )

    answer = answer_resp.choices[0].message.content

    if INTERACTIVE:
        print_assistant_msg(answer, "  ".join(sources), "  ".join(doc_files), doc_tokens)
    else:
        print(answer)

    cache_write(user_query, answer, sources, doc_files)


# ── Entry point ───────────────────────────────────────────────────────────────
def run():
    _setup()

    if not INTERACTIVE:
        q = sys.stdin.read().strip()
        if q:
            force_fresh = q.startswith("!")
            if force_fresh:
                q = q[1:].lstrip()
            if q:
                chat_with_corpis(q, force_fresh=force_fresh)
        sys.exit(0)

    print_banner()
    cache_collection = _state["cache_collection"]

    while True:
        try:
            hr(indent=2)
            prompt = f"  {FG_BBLUE}{BOLD}›{RESET} "
            q = input(prompt).strip()
        except (KeyboardInterrupt, EOFError):
            print(f"\n\n  {FG_GRAY}Goodbye.{RESET}\n")
            break

        if not q:
            continue
        if q.lower() in {"exit", "quit", "bye"}:
            print(f"\n  {FG_GRAY}Goodbye.{RESET}\n")
            break
        if q.lower() == "clear":
            os.system("clear")
            print_banner()
            continue
        if q.lower() == "clear cache":
            n = cache_collection.count()
            cache_collection.delete(ids=cache_collection.get()["ids"])
            print(f"\n  {FG_BGREEN}✓{RESET}  Cleared {n} cached answer{'s' if n != 1 else ''}.\n")
            continue

        force_fresh = q.startswith("!")
        if force_fresh:
            q = q[1:].lstrip()
            if not q:
                continue

        print_user_msg(q)
        chat_with_corpis(q, force_fresh=force_fresh)


if __name__ == "__main__":
    run()
