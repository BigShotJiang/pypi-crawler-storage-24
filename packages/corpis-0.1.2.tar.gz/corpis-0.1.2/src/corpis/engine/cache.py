"""
corpis/engine/cache.py

Browse and manage the Corpis semantic answer cache.
Navigate with arrow keys, delete entries, or clear all.

Usage (CLI):  corpis cache
"""

import os
import sys
import textwrap
from datetime import date, datetime
from dotenv import load_dotenv

from corpis.engine.paths import get_corpis_dir

try:
    import chromadb
    from chromadb.utils import embedding_functions
except ImportError:
    print("  Error: Dependencies not found. Run: pip install corpis")
    exit(1)

# ── Terminal ──────────────────────────────────────────────────────────────────
def _c(*codes): return "".join(f"\033[{c}m" for c in codes)

RESET       = _c(0)
BOLD        = _c(1)
DIM         = _c(2)
ITALIC      = _c(3)
FG_BCYAN    = _c(96)
FG_BBLUE    = _c(94)
FG_BGREEN   = _c(92)
FG_BYELLOW  = _c(93)
FG_BMAGENTA = _c(95)
FG_WHITE    = _c(97)
FG_GRAY     = _c(90)
FG_YELLOW   = _c(33)
BG_SEL      = _c(48, 5, 237)

def term_width():
    try:
        return os.get_terminal_size().columns
    except OSError:
        return 80

def term_height():
    try:
        return os.get_terminal_size().lines
    except OSError:
        return 24

def clear_screen():
    sys.stdout.write("\033[2J\033[H")
    sys.stdout.flush()

def hide_cursor():
    sys.stdout.write("\033[?25l")
    sys.stdout.flush()

def show_cursor():
    sys.stdout.write("\033[?25h")
    sys.stdout.flush()

def hr(char="─", color=FG_GRAY, indent=4):
    w = max(term_width() - indent * 2, 20)
    print(f"{' ' * indent}{color}{DIM}{char * w}{RESET}")

def human_age(iso_timestamp):
    try:
        then  = datetime.fromisoformat(iso_timestamp).date()
        delta = (date.today() - then).days
        if delta == 0:  return "today"
        if delta == 1:  return "yesterday"
        if delta < 30:  return f"{delta}d ago"
        if delta < 365: return f"{delta // 30}mo ago"
        return iso_timestamp[:10]
    except Exception:
        return iso_timestamp[:10]

# ── Raw terminal input ────────────────────────────────────────────────────────
import tty
import termios

def getch():
    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        ch = sys.stdin.read(1)
        if ch == "\033":
            ch2 = sys.stdin.read(1)
            if ch2 == "[":
                ch3 = sys.stdin.read(1)
                return f"\033[{ch3}"
        return ch
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)

# ── Data ──────────────────────────────────────────────────────────────────────
def load_cache():
    corpis_dir = get_corpis_dir()
    cache_path = os.path.join(corpis_dir, "cache")
    load_dotenv(os.path.join(corpis_dir, ".env"))

    if not os.path.isdir(cache_path):
        return [], None
    try:
        ef = embedding_functions.OpenAIEmbeddingFunction(
            api_key=os.getenv("OPENAI_API_KEY"),
            model_name="text-embedding-3-small"
        )
        cc = chromadb.PersistentClient(path=cache_path).get_or_create_collection(
            name="answer_cache",
            embedding_function=ef,
            metadata={"hnsw:space": "cosine"},
        )
        if cc.count() == 0:
            return [], cc
        raw = cc.get()
        entries = []
        for eid, meta in zip(raw["ids"], raw["metadatas"]):
            entries.append({
                "id":        eid,
                "question":  meta.get("question", ""),
                "answer":    meta.get("answer", ""),
                "sources":   meta.get("sources", ""),
                "doc_files": meta.get("doc_files", ""),
                "timestamp": meta.get("timestamp", ""),
            })
        entries.sort(key=lambda e: e["timestamp"], reverse=True)
        return entries, cc
    except Exception as e:
        print(f"\n  Error loading cache: {e}\n")
        return [], None

# ── Rendering ─────────────────────────────────────────────────────────────────
def render_list(entries, selected, scroll_offset):
    w      = term_width()
    h      = term_height()
    pane   = min(w // 2, 52)
    list_h = h - 8

    clear_screen()
    print(f"  {BOLD}{FG_BCYAN}◈  Corpis Cache Browser{RESET}  {FG_GRAY}·{RESET}  {DIM}{len(entries)} entr{'ies' if len(entries) != 1 else 'y'}{RESET}")
    hr("▔", FG_BCYAN, indent=2)
    print()

    visible = entries[scroll_offset : scroll_offset + list_h]
    for i, entry in enumerate(visible):
        idx     = scroll_offset + i
        is_sel  = idx == selected
        q       = entry["question"]
        age     = human_age(entry["timestamp"])
        q_trunc = q[:pane - 14] + "…" if len(q) > pane - 14 else q

        if is_sel:
            print(f"  {BG_SEL}{FG_WHITE}{BOLD} › {q_trunc:<{pane - 10}} {RESET}  {FG_GRAY}{age}{RESET}")
        else:
            print(f"    {FG_GRAY}{q_trunc:<{pane - 10}}{RESET}  {FG_GRAY}{DIM}{age}{RESET}")

    print()
    hr("▁", FG_BCYAN, indent=2)
    print()
    print(f"  {FG_GRAY}↑ ↓  navigate  ·  {BOLD}{FG_WHITE}enter{RESET}{FG_GRAY}  view  ·  "
          f"{BOLD}{FG_WHITE}d{RESET}{FG_GRAY}  delete  ·  "
          f"{BOLD}{FG_WHITE}D{RESET}{FG_GRAY}  delete all  ·  "
          f"{BOLD}{FG_WHITE}q{RESET}{FG_GRAY}  quit{RESET}")

def render_detail(entry, entries, selected):
    w       = term_width()
    indent  = "     "
    wrap_w  = min(w - 12, 80)

    clear_screen()
    age = human_age(entry["timestamp"])
    print(f"  {BOLD}{FG_BCYAN}◈  Cache Entry{RESET}  {FG_GRAY}·{RESET}  {FG_BGREEN}{age}{RESET}  "
          f"{FG_GRAY}·{RESET}  {DIM}{selected + 1} of {len(entries)}{RESET}")
    hr("▔", FG_BCYAN, indent=2)
    print()

    q        = entry["question"]
    q_lines  = textwrap.wrap(q, width=wrap_w) or [q]
    box_w    = max(len(l) for l in q_lines) + 4
    pad      = max(w - box_w - 4, 4)
    sp       = " " * pad
    print(f"{sp}{FG_BBLUE}{BOLD}question{RESET}")
    print(f"{sp}{FG_BBLUE}╭{'─' * box_w}╮{RESET}")
    for line in q_lines:
        inner = line.ljust(box_w - 2)
        print(f"{sp}{FG_BBLUE}│{RESET} {FG_WHITE}{BOLD}{inner}{RESET} {FG_BBLUE}│{RESET}")
    print(f"{sp}{FG_BBLUE}╰{'─' * box_w}╯{RESET}")
    print()

    print(f"  {BOLD}{FG_BCYAN}◈ corpis{RESET}  {FG_GRAY}{ITALIC}Knowledge Agent{RESET}")
    hr("▔", FG_BCYAN, indent=2)
    print()

    for para in entry["answer"].strip().split("\n"):
        if not para.strip():
            print(); continue
        stripped = para.lstrip()
        if stripped.startswith(("**", "##", "###")):
            cleaned = stripped.replace("**","").replace("###","").replace("##","").strip()
            print(f"{indent}{BOLD}{FG_WHITE}{cleaned}{RESET}")
        elif stripped.startswith(("- ", "* ", "• ")):
            body    = stripped[2:]
            wrapped = textwrap.wrap(body, width=wrap_w - 6)
            if wrapped:
                print(f"{indent}  {FG_BCYAN}◦{RESET}  {wrapped[0]}")
                for cont in wrapped[1:]:
                    print(f"{indent}     {cont}")
        else:
            for line in textwrap.wrap(para, width=wrap_w):
                print(f"{indent}{line}")

    print()
    hr("▁", FG_BCYAN, indent=2)
    print()

    sources   = entry["sources"].replace("|", "  ·  ")
    doc_files = entry["doc_files"].replace("|", "  ·  ")
    print(f"  {FG_GRAY}╰─{RESET}  {FG_GRAY}source{RESET}  {FG_BMAGENTA}{sources}{RESET}")
    print(f"     {FG_GRAY}docs{RESET}    {DIM}{doc_files}{RESET}")
    print(f"     {FG_GRAY}cached{RESET}  {FG_BGREEN}{age}{RESET}  {FG_GRAY}{DIM}({entry['timestamp'][:19]}){RESET}")
    print()
    hr(indent=2)
    print()
    print(f"  {FG_GRAY}← esc  back  ·  "
          f"{BOLD}{FG_WHITE}d{RESET}{FG_GRAY}  delete this entry  ·  "
          f"{BOLD}{FG_WHITE}↑ ↓{RESET}{FG_GRAY}  prev / next{RESET}")

# ── Main loop ─────────────────────────────────────────────────────────────────
def run():
    entries, cc = load_cache()

    if not entries:
        print(f"\n  {FG_BYELLOW}◈  Cache is empty.{RESET}  No answers have been stored yet.\n")
        return

    selected      = 0
    scroll_offset = 0
    view          = "list"

    hide_cursor()
    try:
        while True:
            h      = term_height()
            list_h = h - 8

            if view == "list":
                if selected < scroll_offset:
                    scroll_offset = selected
                elif selected >= scroll_offset + list_h:
                    scroll_offset = selected - list_h + 1
                render_list(entries, selected, scroll_offset)
            else:
                render_detail(entries[selected], entries, selected)

            key = getch()

            if key in ("\033[A", "k"):
                selected = max(0, selected - 1)

            elif key in ("\033[B", "j"):
                selected = min(len(entries) - 1, selected + 1)

            elif key in ("\r", "\n", "\033[C"):
                if view == "list" and entries:
                    view = "detail"

            elif key in ("\033[D", "\033"):
                if view == "detail":
                    view = "list"

            elif key == "d":
                if entries and cc:
                    cc.delete(ids=[entries[selected]["id"]])
                    entries.pop(selected)
                    if not entries:
                        clear_screen()
                        print(f"\n  {FG_BGREEN}✓{RESET}  Cache is now empty.\n")
                        break
                    selected = min(selected, len(entries) - 1)
                    view = "list"

            elif key == "D":
                if entries and cc:
                    all_ids = [e["id"] for e in entries]
                    cc.delete(ids=all_ids)
                    clear_screen()
                    print(f"\n  {FG_BGREEN}✓{RESET}  Cleared {len(all_ids)} cached "
                          f"answer{'s' if len(all_ids) != 1 else ''}.\n")
                    break

            elif key in ("q", "Q"):
                clear_screen()
                break

    finally:
        show_cursor()
        print()


if __name__ == "__main__":
    run()
