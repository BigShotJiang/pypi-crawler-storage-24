"""
corpis/engine/genesis.py

One-time ingestion: walks the repository, distils every source file into a
structured logic record, and builds the vector index.

Usage (CLI):  corpis genesis [--reset]
"""

import os
import sys
import re
import json
import shutil
import time
import threading
import argparse
from dotenv import load_dotenv

from corpis.engine.paths import get_corpis_dir, get_repo_root, ensure_dirs

try:
    import chromadb
    from chromadb.utils import embedding_functions
    from openai import OpenAI
except ImportError:
    print("  Error: Dependencies not found. Run: pip install corpis")
    exit(1)

# ── Terminal ──────────────────────────────────────────────────────────────────
def _c(*codes): return "".join(f"\033[{c}m" for c in codes)

RESET       = _c(0)
BOLD        = _c(1)
DIM         = _c(2)
ITALIC      = _c(3)
FG_CYAN     = _c(36)
FG_BCYAN    = _c(96)
FG_BLUE     = _c(34)
FG_BBLUE    = _c(94)
FG_GREEN    = _c(32)
FG_BGREEN   = _c(92)
FG_YELLOW   = _c(33)
FG_BYELLOW  = _c(93)
FG_RED      = _c(31)
FG_MAGENTA  = _c(35)
FG_BMAGENTA = _c(95)
FG_WHITE    = _c(97)
FG_GRAY     = _c(90)

def term_width():
    try:
        return os.get_terminal_size().columns
    except OSError:
        return 80

def clear_line():
    sys.stdout.write("\r\033[K")
    sys.stdout.flush()

def hr(char="─", color=FG_GRAY, indent=4):
    w = max(term_width() - indent * 2, 20)
    print(f"{' ' * indent}{color}{DIM}{char * w}{RESET}")

def print_banner():
    w   = term_width()
    pad = max((w - 44) // 2, 2)
    sp  = " " * pad
    print()
    print(f"{sp}{BOLD}{FG_BCYAN}╭{'─' * 42}╮{RESET}")
    print(f"{sp}{BOLD}{FG_BCYAN}│{RESET}{'':^42}{BOLD}{FG_BCYAN}│{RESET}")
    print(f"{sp}{BOLD}{FG_BCYAN}│{RESET}  {BOLD}{FG_WHITE}◈  CORPIS{RESET}  {FG_GRAY}·{RESET}  {ITALIC}{FG_BCYAN}Genesis Engine{RESET}{'':^18}{BOLD}{FG_BCYAN}│{RESET}")
    print(f"{sp}{BOLD}{FG_BCYAN}│{RESET}{'':^42}{BOLD}{FG_BCYAN}│{RESET}")
    print(f"{sp}{BOLD}{FG_BCYAN}╰{'─' * 42}╯{RESET}")
    print()

def spinner_thread(label, stop_event):
    frames = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
    i = 0
    while not stop_event.is_set():
        frame = f"{FG_BCYAN}{frames[i % len(frames)]}{RESET}"
        sys.stdout.write(f"\r     {frame}  {DIM}{label}{RESET}")
        sys.stdout.flush()
        time.sleep(0.075)
        i += 1
    clear_line()

def with_spinner(label, fn):
    stop = threading.Event()
    t = threading.Thread(target=spinner_thread, args=(label, stop), daemon=True)
    t.start()
    try:
        result = fn()
    finally:
        stop.set(); t.join()
    return result

def print_step(icon, color, label, detail=""):
    detail_str = f"  {FG_GRAY}{DIM}{detail}{RESET}" if detail else ""
    print(f"     {color}{icon}{RESET}  {label}{detail_str}")

def print_file_result(index, total, source_rel, doc_rel, ok=True):
    icon  = f"{FG_BGREEN}✓{RESET}" if ok else f"{FG_YELLOW}⚠{RESET}"
    num   = f"{FG_GRAY}{index:>3}/{total}{RESET}"
    src   = f"{DIM}{source_rel}{RESET}"
    arrow = f"{FG_GRAY}→{RESET}"
    doc   = f"{FG_BCYAN}{doc_rel}{RESET}" if ok else f"{FG_YELLOW}{source_rel}{RESET}"
    if ok:
        print(f"     {icon}  {num}  {src}  {arrow}  {doc}")
    else:
        print(f"     {icon}  {num}  {doc}")

def print_summary(total, skipped, elapsed, agent_results):
    processed = total - skipped
    print()
    hr("▁", FG_BCYAN, indent=2)
    print()
    print(f"  {BOLD}{FG_BGREEN}◈  Genesis complete{RESET}")
    print()
    print(f"     {FG_GRAY}files processed{RESET}   {BOLD}{FG_WHITE}{processed}{RESET}")
    print(f"     {FG_GRAY}files skipped  {RESET}   {DIM}{skipped}{RESET}")
    print(f"     {FG_GRAY}elapsed        {RESET}   {FG_YELLOW}{elapsed:.1f}s{RESET}")
    print()
    for filename, created in agent_results.items():
        action = f"{FG_BGREEN}created{RESET}" if created else f"{FG_YELLOW}updated{RESET}"
        print(f"     {FG_GRAY}{filename:<12}{RESET}   {action}")
    print()
    print(f"  {FG_GRAY}Your corpus is ready. Run {BOLD}{FG_WHITE}corpis query{RESET}{FG_GRAY} to start asking questions.{RESET}")
    print()

# ── Agent file content ────────────────────────────────────────────────────────
CORPIS_SECTION_START = "<!-- corpis:start -->"
CORPIS_SECTION_END   = "<!-- corpis:end -->"

CORPIS_SECTION_CLAUDE = f"""{CORPIS_SECTION_START}
## Corpis — Codebase Knowledge

This repo has a knowledge layer called Corpis. It has already analysed every source
file and built a searchable record of what each piece of logic does and why.

**Before reading any source files to answer a question about the codebase, you MUST
query Corpis first.** Do not use Glob, Grep, or Read to explore source files when
the user is asking about intent, purpose, architecture, or history. Corpis knows this.

### How to query

```bash
echo "<question>" | corpis query
```

**Relay the output directly to the user. Do not re-summarise, re-analyse, or add
your own reasoning on top of it.** The Corpis answer is the answer. If it was
previously cached, it is still the answer — present it immediately without thinking.

### When to use Corpis

Use Corpis whenever the user asks:
- What this app / feature / module does
- Why something was built a certain way
- What has changed and why
- How a particular flow or system works
- Anything about intent, design decisions, or history

Only fall back to reading source files directly if Corpis explicitly says it has no
record for the topic, or if the user asks for raw code (not explanation).

### After modifying a file

After every file you create or modify, run:

```bash
corpis update <path/to/file> "<what you changed and why>"
```

Your description becomes a permanent changelog entry in the logic record so future
agents understand the decision. Any cached answers referencing that file are
automatically invalidated.

### After deleting a file

```bash
corpis delete <path/to/file>
```
{CORPIS_SECTION_END}"""

CORPIS_SECTION_AGENTS = f"""{CORPIS_SECTION_START}
## Corpis — Codebase Knowledge Agent

This repository has a knowledge layer called Corpis. Every source file has been
analysed and distilled into a structured logic record: purpose, mechanics, and
decision history. Records are stored in `corpis/docs/` and indexed in a vector
database for semantic search.

### Rule: query before reading

Before reading source files to answer questions about the codebase, call Corpis:

```bash
echo "<question>" | corpis query
```

Use this for any question about what the code does, why it exists, how a flow works,
or what has changed. Only read source files directly if Corpis has no record for the
topic or the user explicitly needs raw code.

### After modifying a file

```bash
corpis update <path/to/file> "<what changed and why>"
```

This updates the logic record and invalidates any stale cached answers.

### After deleting a file

```bash
corpis delete <path/to/file>
```

### Corpus layout

```
corpis/
  docs/        ← logic records by business domain
  db/          ← vector database
  cache/       ← semantic answer cache
```
{CORPIS_SECTION_END}"""

CORPIS_SECTION_GEMINI = CORPIS_SECTION_AGENTS

CORPIS_SECTIONS = {
    "CLAUDE.md":  CORPIS_SECTION_CLAUDE,
    "AGENTS.md":  CORPIS_SECTION_AGENTS,
    "GEMINI.md":  CORPIS_SECTION_GEMINI,
}

def write_agent_file(filename):
    repo_root   = get_repo_root()
    agents_path = os.path.join(repo_root, filename)
    exists      = os.path.isfile(agents_path)
    title       = os.path.splitext(filename)[0].upper()
    section     = CORPIS_SECTIONS.get(filename, CORPIS_SECTION_AGENTS)

    if not exists:
        with open(agents_path, "w", encoding="utf-8") as f:
            f.write(f"# {title}\n\n")
            f.write(section.strip() + "\n")
        return True  # created

    with open(agents_path, "r", encoding="utf-8") as f:
        content = f.read()

    if CORPIS_SECTION_START in content:
        before = content[:content.index(CORPIS_SECTION_START)]
        after  = content[content.index(CORPIS_SECTION_END) + len(CORPIS_SECTION_END):]
        new_content = before.rstrip() + "\n\n" + section.strip() + "\n" + after.lstrip()
        with open(agents_path, "w", encoding="utf-8") as f:
            f.write(new_content)
        return False  # updated

    with open(agents_path, "a", encoding="utf-8") as f:
        f.write("\n\n" + section.strip() + "\n")
    return False  # appended

def write_all_agent_files():
    results = {}
    for filename in ("AGENTS.md", "CLAUDE.md", "GEMINI.md"):
        results[filename] = write_agent_file(filename)
    return results

# ── Helpers ───────────────────────────────────────────────────────────────────
def slugify(text):
    text = text.lower().strip()
    text = re.sub(r"[^\w\s-]", "", text)
    text = re.sub(r"[\s_]+", "-", text)
    text = re.sub(r"-+", "-", text)
    return text[:60].strip("-") or "general"

def unique_doc_path(docs_path, folder, filename):
    base      = os.path.join(docs_path, folder, filename)
    candidate = f"{base}.md"
    counter   = 2
    while os.path.exists(candidate):
        candidate = f"{base}-{counter}.md"
        counter  += 1
    return candidate

def _str(val):
    if isinstance(val, list):
        return "\n".join(
            item if str(item).startswith("- ") else f"- {item}"
            for item in val
        )
    return str(val).strip() if val else ""

def distill_logic(client_ai, code_block, file_path):
    prompt = (
        f"File: {file_path}\n"
        f"Code:\n{code_block}\n\n"
        "Return a JSON object with exactly these keys:\n"
        "  folder    — a short, lowercase business-domain slug (e.g. 'finance', 'auth', "
        "'notifications', 'data-pipeline', 'api', 'ui'). Use 'general' only as a last resort.\n"
        "  title     — a descriptive, human-readable name for this logic (not just the filename). "
        "E.g. 'Next.js Security & Build Configuration', 'Invoice Tiered Pricing Engine'.\n"
        "  purpose   — 2-4 sentences explaining WHY this logic exists: what business problem "
        "it solves, why it was built this way, and what would break without it.\n"
        "  technical — HOW it works: key mechanisms, data flows, patterns used. "
        "Use bullet points (- item). Be specific and implementation-focused.\n"
        "Respond with valid JSON only, no markdown fences."
    )
    try:
        response = client_ai.chat.completions.create(
            model="gpt-4o",
            response_format={"type": "json_object"},
            messages=[
                {"role": "system", "content": "You are a senior technical architect analysing a codebase for Corpis."},
                {"role": "user",   "content": prompt},
            ],
        )
        data      = json.loads(response.choices[0].message.content)
        folder    = slugify(data.get("folder",    "general"))
        title     = _str(data.get("title",        "Logic Record"))
        filename  = slugify(title) or "logic"
        purpose   = _str(data.get("purpose",      ""))
        technical = _str(data.get("technical",    ""))
        return folder, filename, title, purpose, technical
    except Exception as e:
        return "general", "unknown-logic", "Unknown Logic", "", f"Error: {e}"

def get_all_files(root_dir):
    valid_exts = (".py", ".ts", ".js", ".go")
    files = []
    for root, _, filenames in os.walk(root_dir):
        if any(skip in root for skip in ("corpis", ".git", "node_modules", "__pycache__", "src/corpis")):
            continue
        for name in filenames:
            if name.endswith(valid_exts):
                files.append(os.path.join(root, name))
    return files

def confirm_reset(docs_path, db_path):
    print()
    print(f"  {FG_BYELLOW}{BOLD}⚠  Reset mode{RESET}")
    hr("─", FG_YELLOW, indent=2)
    print(f"     This will permanently delete:")
    print(f"     {FG_BMAGENTA}  docs/{RESET}   {FG_GRAY}(all logic records){RESET}")
    print(f"     {FG_BMAGENTA}  db/{RESET}      {FG_GRAY}(vector database){RESET}")
    hr("─", FG_YELLOW, indent=2)
    try:
        ans = input(f"  {FG_BYELLOW}{BOLD}›{RESET} Type {BOLD}yes{RESET} to confirm: ").strip().lower()
    except (KeyboardInterrupt, EOFError):
        print(f"\n  {FG_GRAY}Aborted.{RESET}\n")
        sys.exit(0)
    if ans != "yes":
        print(f"\n  {FG_GRAY}Aborted.{RESET}\n")
        sys.exit(0)

def do_reset(docs_path, db_path, cache_path):
    for path, label in [(docs_path, "docs"), (db_path, "db"), (cache_path, "cache")]:
        if os.path.exists(path):
            stop = threading.Event()
            t = threading.Thread(target=spinner_thread, args=(f"Wiping {label}/…", stop), daemon=True)
            t.start()
            shutil.rmtree(path)
            stop.set(); t.join()
            print_step("✓", FG_BGREEN, f"Cleared {label}/")
        else:
            print_step("–", FG_GRAY, f"{label}/ not found, skipping")
    print()

# ── Core ──────────────────────────────────────────────────────────────────────
def run_genesis(reset=False):
    corpis_dir = get_corpis_dir()
    repo_root  = get_repo_root()
    db_path    = os.path.join(corpis_dir, "db")
    docs_path  = os.path.join(corpis_dir, "docs")
    cache_path = os.path.join(corpis_dir, "cache")

    load_dotenv(os.path.join(corpis_dir, ".env"))
    client_ai = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

    print_banner()

    if reset:
        confirm_reset(docs_path, db_path)
        do_reset(docs_path, db_path, cache_path)

    os.makedirs(docs_path,  exist_ok=True)
    os.makedirs(db_path,    exist_ok=True)
    os.makedirs(cache_path, exist_ok=True)

    # Init DB after optional reset
    chroma_client = chromadb.PersistentClient(path=db_path)
    ef = embedding_functions.OpenAIEmbeddingFunction(
        api_key=os.getenv("OPENAI_API_KEY"),
        model_name="text-embedding-3-small"
    )
    collection = chroma_client.get_or_create_collection(
        name="logic_ledger",
        embedding_function=ef,
        metadata={"hnsw:space": "cosine"},
    )

    files = get_all_files(repo_root)
    total = len(files)

    print(f"  {FG_BCYAN}{BOLD}◈  Scanning repository{RESET}")
    print(f"     {FG_GRAY}found{RESET}  {BOLD}{FG_WHITE}{total} file{'s' if total != 1 else ''}{RESET}  "
          f"{FG_GRAY}matching{RESET}  {DIM}.py  .ts  .js  .go{RESET}")
    print()
    hr("▔", FG_BCYAN, indent=2)
    print()

    skipped = 0
    start   = time.time()

    for i, full_path in enumerate(files, 1):
        rel = os.path.relpath(full_path, repo_root)

        with open(full_path, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()

        if not content.strip():
            skipped += 1
            print_file_result(i, total, rel, rel, ok=False)
            continue

        label = f"{rel}  ({i}/{total})"
        folder, filename, title, purpose, technical = with_spinner(
            f"Distilling  {label}",
            lambda c=content, r=rel: distill_logic(client_ai, c[:3000], r)
        )

        from hashlib import md5
        logic_id = md5(rel.encode()).hexdigest()[:8]
        md_path  = unique_doc_path(docs_path, folder, filename)
        os.makedirs(os.path.dirname(md_path), exist_ok=True)
        doc_rel  = os.path.relpath(md_path, docs_path)

        with open(md_path, "w", encoding="utf-8") as md_file:
            md_file.write(f"# {title}\n\n")
            md_file.write(f"## Purpose\n{purpose}\n\n")
            md_file.write(f"## How It Works\n{technical}\n\n")
            md_file.write(f"---\n**Source:** `{rel}`  \n")
            md_file.write(f"**Domain:** `{folder}`  \n")
            md_file.write(f"**Logic ID:** `{logic_id}`\n\n")
            md_file.write("## Changelog\n\n*(no changes recorded yet)*\n")

        embed_text = f"file: {rel}\ndomain: {folder}\nPURPOSE: {purpose}\nTECHNICAL: {technical}"
        collection.add(
            documents=[embed_text],
            ids=[logic_id],
            metadatas={
                "source_file": rel,
                "doc_file":    doc_rel,
                "description": purpose,
                "domain":      folder,
            },
        )
        print_file_result(i, total, rel, doc_rel, ok=True)

    agent_results = with_spinner("Writing agent files…", write_all_agent_files)
    elapsed = time.time() - start
    print_summary(total, skipped, elapsed, agent_results)


# ── Entry point (direct invocation) ──────────────────────────────────────────
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Corpis Genesis — ingest your codebase.")
    parser.add_argument("--reset", action="store_true",
                        help="Wipe docs/ and db/ before ingesting.")
    args = parser.parse_args()
    run_genesis(reset=args.reset)
