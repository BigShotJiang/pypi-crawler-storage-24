"""
corpis.cli — entry point for the `corpis` command.

Subcommands:
  corpis init                          Scaffold Corpis in the current project
  corpis genesis [--reset]             Run full corpus ingestion
  corpis query                         Interactive TUI / piped query
  corpis update <file> "<why>"         Update a file's logic record
  corpis cache                         Browse the answer cache
  corpis delete <file>                 Remove a file's record from the corpus
"""

import argparse
import os
import sys


def cmd_init():
    """Scaffold the corpis/ data directory and write agent instruction files."""
    from corpis.engine.paths import get_corpis_dir, get_repo_root

    # ── Terminal colours (minimal, no deps) ──────────────────────────────────
    def _c(*codes): return "".join(f"\033[{c}m" for c in codes)
    RESET   = _c(0); BOLD = _c(1); DIM = _c(2)
    BCYAN   = _c(96); BGREEN = _c(92); BYELLOW = _c(93); GRAY = _c(90); WHITE = _c(97)

    cwd        = os.getcwd()
    corpis_dir = get_corpis_dir()
    repo_root  = get_repo_root()

    print()
    print(f"  {BOLD}{BCYAN}◈  Corpis init{RESET}  {GRAY}·{RESET}  {DIM}{cwd}{RESET}")
    print()

    # Create data directories
    for sub in ("docs", "db", "cache"):
        path = os.path.join(corpis_dir, sub)
        os.makedirs(path, exist_ok=True)
        print(f"     {BGREEN}✓{RESET}  {path}")

    # Create .env stub
    env_path = os.path.join(corpis_dir, ".env")
    if not os.path.exists(env_path):
        with open(env_path, "w") as f:
            f.write("OPENAI_API_KEY=\n")
        print(f"     {BGREEN}✓{RESET}  {env_path}  {GRAY}(add your key){RESET}")
    else:
        print(f"     {DIM}–{RESET}  {env_path}  {GRAY}(already exists){RESET}")

    # Add entries to .gitignore
    gitignore_path = os.path.join(repo_root, ".gitignore")
    ignore_entries = ["corpis/.env", "corpis/db/", "corpis/cache/"]
    if os.path.exists(gitignore_path):
        with open(gitignore_path, "r") as f:
            existing = f.read()
        missing = [e for e in ignore_entries if e not in existing]
        if missing:
            with open(gitignore_path, "a") as f:
                f.write("\n# Corpis\n")
                for entry in missing:
                    f.write(f"{entry}\n")
            print(f"     {BGREEN}✓{RESET}  .gitignore  {GRAY}(added corpis entries){RESET}")
        else:
            print(f"     {DIM}–{RESET}  .gitignore  {GRAY}(already has corpis entries){RESET}")
    else:
        with open(gitignore_path, "w") as f:
            f.write("# Corpis\n")
            for entry in ignore_entries:
                f.write(f"{entry}\n")
        print(f"     {BGREEN}✓{RESET}  .gitignore  {GRAY}(created){RESET}")

    # Write agent instruction files
    from corpis.engine.genesis import write_all_agent_files
    agent_results = write_all_agent_files()
    for filename, created in agent_results.items():
        action = "created" if created else "updated"
        print(f"     {BGREEN}✓{RESET}  {filename}  {GRAY}({action}){RESET}")

    print()
    print(f"  {GRAY}Corpis is ready. Open {BOLD}{WHITE}corpis/.env{RESET}{GRAY} and add your OPENAI_API_KEY,")
    print(f"  then run {BOLD}{WHITE}corpis genesis{RESET}{GRAY} to ingest your codebase.{RESET}")
    print()


def cmd_delete(file_path):
    """Remove a file's logic record and doc from the corpus."""
    from corpis.engine.paths import get_corpis_dir, get_repo_root
    from dotenv import load_dotenv
    import chromadb
    from hashlib import md5

    def _c(*codes): return "".join(f"\033[{c}m" for c in codes)
    RESET = _c(0); BOLD = _c(1); DIM = _c(2)
    BCYAN = _c(96); BGREEN = _c(92); BYELLOW = _c(93); GRAY = _c(90)

    corpis_dir = get_corpis_dir()
    repo_root  = get_repo_root()
    db_path    = os.path.join(corpis_dir, "db")
    docs_path  = os.path.join(corpis_dir, "docs")

    load_dotenv(os.path.join(corpis_dir, ".env"))

    abs_path = os.path.abspath(file_path)
    rel      = os.path.relpath(abs_path, repo_root)
    lid      = md5(rel.encode()).hexdigest()[:8]

    col  = chromadb.PersistentClient(path=db_path).get_collection("logic_ledger")
    meta = col.get(ids=[lid])["metadatas"]

    if not meta:
        print(f"\n  {BYELLOW}⚠  No record found for {rel}{RESET}\n")
        sys.exit(1)

    doc_file = meta[0].get("doc_file", "")
    doc_abs  = os.path.join(docs_path, doc_file)

    col.delete(ids=[lid])

    if doc_file and os.path.isfile(doc_abs):
        os.remove(doc_abs)
        print(f"\n  {BGREEN}✓{RESET}  Deleted record  {GRAY}→{RESET}  {BCYAN}{doc_file}{RESET}")
    else:
        print(f"\n  {BGREEN}✓{RESET}  Deleted record for {DIM}{rel}{RESET}")

    print()


def main():
    parser = argparse.ArgumentParser(
        prog="corpis",
        description="Corpis — codebase knowledge layer for AI coding agents.",
    )
    sub = parser.add_subparsers(dest="command", metavar="<command>")

    sub.add_parser("init",    help="Scaffold Corpis in the current project")

    gen = sub.add_parser("genesis", help="Run full corpus ingestion")
    gen.add_argument("--reset", action="store_true",
                     help="Wipe docs/ and db/ before ingesting (fresh start)")

    sub.add_parser("query",   help="Query the corpus (interactive TUI or piped)")

    upd = sub.add_parser("update",  help="Update a file's logic record")
    upd.add_argument("file_path",   metavar="<file>")
    upd.add_argument("description", metavar="<description>",
                     help="What changed and why")

    sub.add_parser("cache",   help="Browse the answer cache")

    dlt = sub.add_parser("delete",  help="Remove a file's record from the corpus")
    dlt.add_argument("file_path",   metavar="<file>")

    # `corpis` with no subcommand → launch query TUI
    args = parser.parse_args()

    if args.command == "init":
        cmd_init()

    elif args.command == "genesis":
        from corpis.engine.genesis import run_genesis
        run_genesis(reset=args.reset)

    elif args.command in ("query", None):
        from corpis.engine.query import run
        run()

    elif args.command == "update":
        from corpis.engine.update import update_file
        update_file(args.file_path, args.description)

    elif args.command == "cache":
        from corpis.engine.cache import run
        run()

    elif args.command == "delete":
        cmd_delete(args.file_path)

    else:
        parser.print_help()


if __name__ == "__main__":
    main()
