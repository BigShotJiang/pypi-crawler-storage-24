from typing import TYPE_CHECKING

from beanie.odm.utils.encoder import Encoder

if TYPE_CHECKING:
    from beanie.odm.documents import Document


def get_dict(
    document: "Document",
    to_db: bool = False,
    exclude: set[str] | None = None,
    keep_nulls: bool = True,
):
    if exclude is None:
        exclude = set()
    if document.id is None:
        exclude.add("_id")
    include = set()
    if document.get_settings().use_revision:
        include.add("revision_id")
    # Explicit excludes take precedence over includes
    include -= exclude
    encoder = Encoder(
        exclude=exclude, include=include, to_db=to_db, keep_nulls=keep_nulls
    )
    return encoder.encode(document)


def get_nulls(
    document: "Document",
    exclude: set[str] | None = None,
):
    dictionary = get_dict(document, exclude=exclude, keep_nulls=True)
    return filter_none(dictionary)


def get_top_level_nones(
    document: "Document",
    exclude: set[str] | None = None,
):
    if exclude is None:
        exclude = set()
    # revision_id is managed separately by SetRevisionId in the update
    # pipeline - including it here would conflict with the $set that
    # SetRevisionId produces, causing a MongoDB OperationFailure.
    if document.get_settings().use_revision:
        exclude.add("revision_id")
    dictionary = get_dict(document, exclude=exclude, keep_nulls=True)
    return {k: v for k, v in dictionary.items() if v is None}


def filter_none(d):
    result = {}
    for k, v in d.items():
        if isinstance(v, dict):
            filtered = filter_none(v)
            if filtered:
                result[k] = filtered
        elif v is None:
            result[k] = v
    return result
