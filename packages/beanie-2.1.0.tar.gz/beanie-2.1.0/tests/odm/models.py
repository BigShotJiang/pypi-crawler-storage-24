import datetime
from collections.abc import Callable
from enum import Enum
from ipaddress import (
    IPv4Address,
    IPv4Interface,
    IPv4Network,
    IPv6Address,
    IPv6Interface,
    IPv6Network,
)
from pathlib import Path
from typing import (  # noqa: UP035
    Annotated,
    Any,
    ClassVar,
    List,
    Optional,
)
from uuid import UUID, uuid4

import pymongo
from bson import Regex
from pydantic import (
    UUID4,
    BaseModel,
    ConfigDict,
    EmailStr,
    Field,
    HttpUrl,
    PrivateAttr,
    RootModel,
    SecretBytes,
    SecretStr,
    validate_call,
)
from pydantic_core import core_schema
from pymongo import IndexModel

from beanie import (
    DecimalAnnotation,
    Document,
    DocumentWithSoftDelete,
    Indexed,
    Insert,
    Replace,
    Save,
    Update,
    ValidateOnSave,
)
from beanie.odm.actions import (
    Delete,
    after_event,
    before_event,
)
from beanie.odm.custom_types import re
from beanie.odm.custom_types.bson.binary import BsonBinary
from beanie.odm.fields import BackLink, Link, PydanticObjectId
from beanie.odm.settings.timeseries import TimeSeriesConfig
from beanie.odm.union_doc import UnionDoc
from beanie.odm.utils.update_merge import ActionConflictResolution


class Color:
    def __init__(self, value):
        self.value = value

    def as_rgb(self):
        return self.value

    def as_hex(self):
        return self.value

    @classmethod
    def _validate(cls, value: Any) -> "Color":
        if isinstance(value, Color):
            return value
        if isinstance(value, dict):
            return Color(value["value"])
        return Color(value)

    @classmethod
    def __get_pydantic_core_schema__(
        cls,
        _source_type: type[Any],
        _handler: Callable[[Any], core_schema.CoreSchema],
    ) -> core_schema.CoreSchema:
        return core_schema.json_or_python_schema(
            json_schema=core_schema.str_schema(),
            python_schema=core_schema.no_info_plain_validator_function(
                cls._validate
            ),
        )


class Extra(str, Enum):
    allow = "allow"


class Option2(BaseModel):
    f: float


class Option1(BaseModel):
    s: str


class Nested(BaseModel):
    integer: int
    option_1: Option1
    union: Option1 | Option2
    optional: Option2 | None = None


class GeoObject(BaseModel):
    type: str = "Point"
    coordinates: tuple[float, float]


class Sample(Document):
    timestamp: datetime.datetime
    increment: Indexed(int)
    integer: Indexed(int)
    float_num: float
    string: str
    nested: Nested
    optional: Option2 | None = None
    union: Option1 | Option2
    geo: GeoObject
    const: str = "TEST"


class DocumentTestModelWithSoftDelete(DocumentWithSoftDelete):
    test_int: int
    test_str: str


class SubDocument(BaseModel):
    test_str: str
    test_int: int = 42


class DocumentTestModel(Document):
    test_int: int
    test_doc: SubDocument
    test_str: str
    test_list: list[SubDocument]

    class Settings:
        use_cache = True
        cache_expiration_time = datetime.timedelta(seconds=10)
        cache_capacity = 5
        use_state_management = True


class DocumentTestModelWithLink(Document):
    test_link: Link[DocumentTestModel]

    class Settings:
        use_cache = True
        cache_expiration_time = datetime.timedelta(seconds=10)
        cache_capacity = 5
        use_state_management = True


class DocumentTestModelWithCustomCollectionName(Document):
    test_int: int
    test_list: list[SubDocument]
    test_str: str

    class Settings:
        name = "custom"
        class_id = "different_class_id"


class DocumentTestModelWithSimpleIndex(Document):
    test_int: Indexed(int)
    test_list: list[SubDocument]
    test_str: Indexed(str, index_type=pymongo.TEXT)


class DocumentTestModelWithIndexFlags(Document):
    test_int: Indexed(int, sparse=True)
    test_str: Indexed(str, index_type=pymongo.DESCENDING, unique=True)


class DocumentTestModelWithIndexFlagsAliases(Document):
    test_int: Indexed(int, sparse=True) = Field(alias="testInt")
    test_str: Indexed(str, index_type=pymongo.DESCENDING, unique=True) = Field(
        alias="testStr"
    )


class DocumentTestModelIndexFlagsAnnotated(Document):
    str_index: Indexed(str, index_type=pymongo.TEXT)
    str_index_annotated: Indexed(str, index_type=pymongo.ASCENDING)
    uuid_index_annotated: Annotated[UUID4, Indexed(unique=True)]


class DocumentTestModelWithComplexIndex(Document):
    test_int: int
    test_list: list[SubDocument]
    test_str: str

    class Settings:
        name = "docs_with_index"
        indexes = [
            "test_int",
            [
                ("test_int", pymongo.ASCENDING),
                ("test_str", pymongo.DESCENDING),
            ],
            IndexModel(
                [("test_str", pymongo.DESCENDING)],
                name="test_string_index_DESCENDING",
            ),
        ]


class DocumentTestModelWithDroppedIndex(Document):
    test_int: int
    test_list: list[SubDocument]
    test_str: str

    class Settings:
        name = "docs_with_index"
        indexes = [
            "test_int",
        ]


class DocumentTestModelStringImport(Document):
    test_int: int


class DocumentTestModelFailInspection(Document):
    test_int_2: int

    class Settings:
        name = "DocumentTestModel"


class DocumentWithDeprecatedHiddenField(Document):
    test_hidden: list[str] | None = Field(
        default=None, json_schema_extra={"hidden": True}
    )


class DocumentWithCustomIdUUID(Document):
    id: UUID = Field(default_factory=uuid4)
    name: str


class DocumentWithCustomIdInt(Document):
    id: int
    name: str


class DocumentWithCustomFiledsTypes(Document):
    color: Color
    decimal: DecimalAnnotation
    secret_bytes: SecretBytes
    secret_string: SecretStr
    ipv4address: IPv4Address
    ipv4interface: IPv4Interface
    ipv4network: IPv4Network
    ipv6address: IPv6Address
    ipv6interface: IPv6Interface
    ipv6network: IPv6Network
    timedelta: datetime.timedelta
    set_type: set[str]
    tuple_type: tuple[int, str]
    path: Path

    class Settings:
        bson_encoders = {Color: vars}

    model_config = ConfigDict(
        arbitrary_types_allowed=True,
    )


class DocumentWithBsonEncodersFiledsTypes(Document):
    color: Color
    timestamp: datetime.datetime

    class Settings:
        bson_encoders = {
            Color: lambda c: c.as_rgb(),
            datetime.datetime: lambda o: o.isoformat(timespec="microseconds"),
        }

    model_config = ConfigDict(
        arbitrary_types_allowed=True,
    )


class DocumentWithActions(Document):
    name: str
    num_1: int = 0
    num_2: int = 10
    num_3: int = 100
    _private_num: int = PrivateAttr(default=100)

    class Inner:
        inner_num_1 = 0
        inner_num_2 = 0

    @before_event(Insert)
    def capitalize_name(self):
        self.name = self.name.capitalize()

    @before_event([Insert, Replace, Save])
    async def add_one(self):
        self.num_1 += 1

    @after_event(Insert)
    def num_2_change(self):
        self.num_2 -= 1

    @after_event(Replace)
    def num_3_change(self):
        self.num_3 -= 1

    @before_event(Delete)
    def inner_num_to_one(self):
        self.Inner.inner_num_1 = 1

    @after_event(Delete)
    def inner_num_to_two(self):
        self.Inner.inner_num_2 = 2

    @before_event(Update)
    def inner_num_to_one_2(self):
        self._private_num += 1

    @after_event(Update)
    def inner_num_to_two_2(self):
        self.num_2 -= 1


class DocumentWithActions2(Document):
    name: str
    num_1: int = 0
    num_2: int = 10
    num_3: int = 100
    _private_num: int = PrivateAttr(default=100)

    class Inner:
        inner_num_1 = 0
        inner_num_2 = 0

    @before_event(Insert)
    def capitalize_name(self):
        self.name = self.name.capitalize()

    @before_event(Insert, Replace, Save)
    async def add_one(self):
        self.num_1 += 1

    @after_event(Insert)
    def num_2_change(self):
        self.num_2 -= 1

    @after_event(Replace)
    def num_3_change(self):
        self.num_3 -= 1

    @before_event(Delete)
    def inner_num_to_one(self):
        self.Inner.inner_num_1 = 1

    @after_event(Delete)
    def inner_num_to_two(self):
        self.Inner.inner_num_2 = 2

    @before_event(Update)
    def inner_num_to_one_2(self):
        self._private_num += 1

    @after_event(Update)
    def inner_num_to_two_2(self):
        self.num_2 -= 1


class InheritedDocumentWithActions(DocumentWithActions): ...


class DocumentWithUpdateFieldAction(Document):
    """Document where before_event(Update) modifies a regular persisted field."""

    name: str
    tag: str | None = None

    @before_event(Update)
    def set_tag(self):
        self.tag = "updated"


class DocumentWithValidateOnSaveAction(Document):
    """Document with before_event + validate_on_save to test ordering."""

    name: str
    normalized_name: str | None = None

    @before_event(Insert, Replace, Save)
    def normalize(self):
        self.normalized_name = self.name.strip().lower()

    class Settings:
        validate_on_save = True


class DocumentWithActionWinsStrategy(Document):
    """Document using ACTION_WINS conflict resolution."""

    name: str
    tag: str | None = None

    @before_event(Update)
    def set_tag(self):
        self.tag = "action_value"

    class Settings:
        action_conflict_resolution = ActionConflictResolution.ACTION_WINS


class InternalDoc(BaseModel):
    _private_field: str = PrivateAttr(default="TEST_PRIVATE")
    num: int = 100
    string: str = "test"
    lst: list[int] = [1, 2, 3, 4, 5]

    def change_private(self):
        self._private_field = "PRIVATE_CHANGED"

    def get_private(self):
        return self._private_field


class DocumentWithTurnedOnStateManagement(Document):
    num_1: int
    num_2: int
    internal: InternalDoc

    class Settings:
        use_state_management = True


class DocumentWithTurnedOnStateManagementWithCustomId(Document):
    id: int
    num_1: int
    num_2: int

    class Settings:
        use_state_management = True


class DocumentWithTurnedOnReplaceObjects(Document):
    num_1: int
    num_2: int
    internal: InternalDoc

    class Settings:
        use_state_management = True
        state_management_replace_objects = True


class DocumentWithTurnedOnSavePrevious(Document):
    num_1: int
    num_2: int
    internal: InternalDoc

    class Settings:
        use_state_management = True
        state_management_save_previous = True


class DocumentWithTurnedOffStateManagement(Document):
    num_1: int
    num_2: int


class DocumentWithValidationOnSave(Document):
    num_1: int
    num_2: int
    related: PydanticObjectId = Field(default_factory=PydanticObjectId)

    @after_event(ValidateOnSave)
    def num_2_plus_1(self):
        self.num_2 += 1

    class Settings:
        validate_on_save = True
        use_state_management = True


class DocumentWithRevisionTurnedOn(Document):
    num_1: int
    num_2: int

    class Settings:
        use_revision = True
        use_state_management = True


class DocumentWithRevisionAndUniqueField(Document):
    num_1: int
    num_2: int
    unique_field: Indexed(str, unique=True)

    class Settings:
        use_revision = True
        use_state_management = True


class DocumentWithPydanticConfig(Document):
    model_config = ConfigDict(validate_assignment=True)

    num_1: int


class DocumentWithExtras(Document):
    model_config = ConfigDict(extra="allow")

    num_1: int


class Yard(Document):
    v: int
    w: int


class Lock(Document):
    k: int


class Window(Document):
    x: int
    y: int
    lock: Link[Lock] | None = None


class WindowWithValidationOnSave(Document):
    x: int
    y: int
    lock: Link[Lock] | None = None

    class Settings:
        validate_on_save = True


class Door(Document):
    t: int = 10
    window: Link[Window] | None = None
    locks: list[Link[Lock]] | None = None


class Roof(Document):
    r: int = 100


class House(Document):
    windows: list[Link[Window]]
    door: Link[Door]
    roof: Link[Roof] | None = None
    yards: list[Link[Yard]] | None = None
    height: Indexed(int) = 2
    name: Indexed(str)

    model_config = ConfigDict(
        extra="allow",
    )


class DocumentForEncodingTest(Document):
    bytes_field: bytes | None = None
    datetime_field: datetime.datetime | None = None


class DocumentWithTimeseries(Document):
    ts: datetime.datetime = Field(default_factory=datetime.datetime.now)

    class Settings:
        timeseries = TimeSeriesConfig(time_field="ts", expire_after_seconds=2)


class DocumentWithStringField(Document):
    string_field: str


class DocumentForEncodingTestDate(Document):
    date_field: datetime.date = Field(default_factory=datetime.date.today)


class DocumentUnion(UnionDoc):
    class Settings:
        name = "multi_model"
        class_id = "123"


class DocumentMultiModelOne(Document):
    int_filed: int = 0
    shared: int = 0

    class Settings:
        union_doc = DocumentUnion
        name = "multi_one"
        class_id = "123"


class DocumentMultiModelTwo(Document):
    str_filed: str = "test"
    shared: int = 0
    linked_doc: Link[DocumentMultiModelOne] | None = None

    class Settings:
        union_doc = DocumentUnion
        name = "multi_two"
        class_id = "123"


class DocumentTestModelWithModelConfigExtraAllow(Document):
    model_config = ConfigDict(
        extra="allow",
    )


class YardWithRevision(Document):
    v: int
    w: int

    class Settings:
        use_revision = True
        use_state_management = True


class LockWithRevision(Document):
    k: int

    class Settings:
        use_revision = True
        use_state_management = True


class WindowWithRevision(Document):
    x: int
    y: int
    lock: Link[LockWithRevision]

    class Settings:
        use_revision = True
        use_state_management = True


class HouseWithRevision(Document):
    windows: list[Link[WindowWithRevision]]

    class Settings:
        use_revision = True
        use_state_management = True


# classes for inheritance test
class Vehicle(Document):
    """Root parent for testing flat inheritance"""

    #               Vehicle
    #              /   |   \
    #             /    |    \
    #        Bicycle  Bike  Car
    #                         \
    #                          \
    #                          Bus
    color: str

    @after_event(Insert)
    def on_object_create(self):
        # this event will be triggered for all children too (self will have corresponding type)
        ...

    class Settings:
        is_root = True


class Bicycle(Vehicle):
    frame: int
    wheels: int


class Fuelled(BaseModel):
    """Just a mixin"""

    fuel: str | None = None


class Car(Vehicle, Fuelled):
    body: str


class Bike(Vehicle, Fuelled): ...


class Bus(Car, Fuelled):
    seats: int


class Owner(Document):
    name: str
    vehicles: list[Link[Vehicle]] = []


# classes for inheritance test with custom class_ids
class VehicleWithCustomClassId(Document):
    """Root parent for testing flat inheritance"""

    # Model hierarchy (names without the WithCustomClassId suffix)
    #
    #               Vehicle
    #              /   |   \
    #             /    |    \
    #        Bicycle  Bike  Car
    #                         \
    #                          \
    #                          Bus
    color: str

    @after_event(Insert)
    def on_object_create(self):
        # this event will be triggered for all children too (self will have corresponding type)
        ...

    class Settings:
        is_root = True
        name = "vehicles-custom-class-id"
        class_id = "type"


class BicycleWithCustomClassId(VehicleWithCustomClassId):
    class Settings:
        class_id_value = "bicycle"

    type: str = "bicycle"
    frame: int
    wheels: int


class CarWithCustomClassId(VehicleWithCustomClassId, Fuelled):
    class Settings:
        class_id_value = "car"

    type: str = "car"
    body: str


class BikeWithCustomClassId(VehicleWithCustomClassId, Fuelled):
    class Settings:
        class_id_value = "bike"

    type: str = "bike"


class BusWithCustomClassId(CarWithCustomClassId, Fuelled):
    # Do not set, must be inferred from class name and parent class.
    # class Settings:
    #     class_id_value = "bus"

    type: str = "car.BusWithCustomClassId"
    seats: int


class OwnerLinksToCustomClassId(Document):
    name: str
    vehicles: list[Link[VehicleWithCustomClassId]] = []


class MixinNonRoot(BaseModel):
    id: int = Field(..., ge=1, le=254)


class MyDocNonRoot(Document):
    class Settings:
        use_state_management = True


class DocNonRoot(MixinNonRoot, MyDocNonRoot):
    name: str


class Doc2NonRoot(MyDocNonRoot):
    name: str


class Child(BaseModel):
    child_field: str


class SampleWithMutableObjects(Document):
    d: dict[str, Child]
    lst: list[Child]


class SampleLazyParsing(Document):
    i: int
    s: str
    lst: list[int] = Field(
        [],
    )

    model_config = ConfigDict(
        validate_assignment=True,
    )

    class Settings:
        lazy_parsing = True
        use_state_management = True


class RootDocument(Document):
    name: str
    link_root: Link[Document]


class ADocument(RootDocument):
    surname: str
    link_a: Link[Document]

    class Settings:
        name = "B"


class BDocument(RootDocument):
    email: str
    link_b: Link[Document]

    class Settings:
        name = "B"


class StateAndDecimalFieldModel(Document):
    amt: DecimalAnnotation
    other_amt: DecimalAnnotation = Field(
        decimal_places=1, multiple_of=0.5, default=0
    )

    class Settings:
        name = "amounts"
        use_revision = True
        use_state_management = True


class Region(Document):
    state: str | None = "TEST"
    city: str | None = "TEST"
    district: str | None = "TEST"


class UsersAddresses(Document):
    region_id: Link[Region] | None = None
    phone_number: str | None = None
    street: str | None = None


class AddressView(BaseModel):
    id: PydanticObjectId | None = Field(alias="_id", default=None)
    phone_number: str | None = None
    street: str | None = None
    state: str | None = None
    city: str | None = None
    district: str | None = None

    class Settings:
        projection = {
            "id": "$_id",
            "phone_number": 1,
            "street": 1,
            "sub_district": "$region_id.sub_district",
            "city": "$region_id.city",
            "state": "$region_id.state",
        }


class SelfLinked(Document):
    item: Link["SelfLinked"] | None = None
    s: str

    class Settings:
        max_nesting_depth = 2


class LoopedLinksA(Document):
    b: Link["LoopedLinksB"]
    s: str

    class Settings:
        max_nesting_depths_per_field = {"b": 2}


class LoopedLinksB(Document):
    a: Link[LoopedLinksA] | None = None
    s: str


class DocWithCollectionInnerClass(Document):
    s: str

    class Collection:
        name = "test"


class DocumentWithDecimalField(Document):
    amt: DecimalAnnotation
    other_amt: DecimalAnnotation = Field(
        decimal_places=1, multiple_of=0.5, default=DecimalAnnotation(0)
    )

    model_config = ConfigDict(
        validate_assignment=True,
    )

    class Settings:
        name = "amounts"
        use_revision = True
        use_state_management = True
        indexes = [
            pymongo.IndexModel(
                keys=[("amt", pymongo.ASCENDING)], name="amt_ascending"
            ),
            pymongo.IndexModel(
                keys=[("other_amt", pymongo.DESCENDING)],
                name="other_amt_descending",
            ),
        ]


class ModelWithOptionalField(BaseModel):
    s: str | None = None
    i: int


class DocumentWithKeepNullsFalse(Document):
    o: str | None = None
    m: ModelWithOptionalField

    class Settings:
        keep_nulls = False
        use_state_management = True


class DocumentWithRevisionAndKeepNullsFalse(Document):
    name: str
    description: str | None = None

    class Settings:
        use_revision = True
        keep_nulls = False


class DocumentWithExcludedField(Document):
    included_field: int
    excluded_field: int | None = Field(default=None, exclude=True)


class DocumentWithFrozenField(Document):
    name: str
    immutable_value: str = Field(frozen=True)

    class Settings:
        name = "docs_with_frozen_field"


class ReleaseElemMatch(BaseModel):
    major_ver: int
    minor_ver: int
    build_ver: int


class PackageElemMatch(Document):
    releases: list[ReleaseElemMatch] = []


class DocumentToBeLinked(Document):
    s: str = "TEST"


class DocumentWithListOfLinks(Document):
    links: list[Link[DocumentToBeLinked]]
    s: str = "TEST"


class DocumentWithLink(Document):
    link: Link["DocumentWithBackLink"]
    s: str = "TEST"


class DocumentWithListLink(Document):
    link: list[Link["DocumentWithListBackLink"]]
    s: str = "TEST"


class DocumentWithOptionalLink(Document):
    link: Link["DocumentWithBackLink"] | None
    s: str = "TEST"


class DocumentWithUnionTypeExpressionOptionalLink(Document):
    link: Link[DocumentToBeLinked] | None = None
    link_list: list[Link[DocumentToBeLinked]] | None = None


class DocumentWithOptionalTypingOptionalLink(Document):
    link: Optional[Link[DocumentToBeLinked]] = None  # noqa: UP045
    link_list: Optional[List[Link[DocumentToBeLinked]]] = None  # noqa: UP006, UP045


class DocumentWithBackLink(Document):
    back_link: BackLink[DocumentWithLink] = Field(
        json_schema_extra={"original_field": "link"},
    )
    i: int = 1


class DocumentWithOptionalBackLink(Document):
    back_link: BackLink[DocumentWithLink] | None = Field(
        json_schema_extra={"original_field": "link"},
    )
    i: int = 1


class DocumentWithListBackLink(Document):
    back_link: list[BackLink[DocumentWithListLink]] = Field(
        json_schema_extra={"original_field": "link"},
    )
    i: int = 1


class DocumentWithOptionalListBackLink(Document):
    back_link: list[BackLink[DocumentWithListLink]] | None = Field(
        json_schema_extra={"original_field": "link"},
    )
    i: int = 1


class DocumentWithUnionTypeExpressionOptionalBackLink(Document):
    back_link_list: list[BackLink[DocumentWithListLink]] | None = Field(
        json_schema_extra={"original_field": "link"}
    )
    back_link: BackLink[DocumentWithLink] | None = Field(
        json_schema_extra={"original_field": "link"}
    )

    i: int = 1


class DocumentWithOptionalTypingOptionalBackLink(Document):
    back_link_list: Optional[List[BackLink[DocumentWithListLink]]] = Field(  # noqa: UP006, UP045
        json_schema_extra={"original_field": "link"}
    )
    back_link: Optional[BackLink[DocumentWithLink]] = Field(  # noqa: UP045
        json_schema_extra={"original_field": "link"}
    )
    i: int = 1


class DocumentWithTimeStampToTestConsistency(Document):
    ts: datetime.datetime = Field(
        default_factory=lambda: datetime.datetime.now(datetime.timezone.utc)
    )


class DocumentWithIndexMerging1(Document):
    class Settings:
        indexes = [
            "s1",
            [
                ("s2", pymongo.ASCENDING),
            ],
            IndexModel(
                [("s3", pymongo.ASCENDING)],
                name="s3_index",
            ),
            IndexModel(
                [("s4", pymongo.ASCENDING)],
                name="s4_index",
            ),
        ]


class DocumentWithIndexMerging2(DocumentWithIndexMerging1):
    class Settings:
        merge_indexes = True
        indexes = [
            "s0",
            "s1",
            [
                ("s2", pymongo.DESCENDING),
            ],
            IndexModel(
                [("s3", pymongo.DESCENDING)],
                name="s3_index",
            ),
        ]


class DocumentWithCustomInit(Document):
    s: ClassVar[str] = "TEST"

    @classmethod
    async def custom_init(cls):
        cls.s = "TEST2"


class LinkDocumentForTextSeacrh(Document):
    i: int


class DocumentWithTextIndexAndLink(Document):
    s: str
    link: Link[LinkDocumentForTextSeacrh]

    class Settings:
        indexes = [
            pymongo.IndexModel(
                [("s", pymongo.TEXT)],
                name="text_index",
            )
        ]


class DocumentWithList(Document):
    list_values: list[str]


class DocumentWithBsonBinaryField(Document):
    binary_field: BsonBinary


class IterableRootList(RootModel[list[int]]):
    """RootModel with custom __iter__ that yields non-tuple values."""

    def __iter__(self):
        return iter(self.root)


class DocumentWithRootModelAsAField(Document):
    pets: RootModel[list[str]]


class DocumentWithCustomIterRootModel(Document):
    """Document with a RootModel field that overrides __iter__."""

    items: IterableRootList = Field(
        default_factory=lambda: IterableRootList([])
    )


class DocWithCallWrapper(Document):
    name: str

    @validate_call
    def foo(self, bar: str) -> None:
        print(f"foo {bar}")


class DocumentWithHttpUrlField(Document):
    url_field: HttpUrl


class DocumentWithComplexDictKey(Document):
    dict_field: dict[UUID, datetime.datetime]


class DocumentWithIndexedObjectId(Document):
    pyid: Indexed(PydanticObjectId)
    uuid: Annotated[UUID4, Indexed(unique=True)]
    email: Annotated[EmailStr, Indexed(unique=True)]


class DocumentToTestSync(Document):
    s: str = "TEST"
    i: int = 1
    n: Nested = Nested(
        integer=1, option_1=Option1(s="test"), union=Option1(s="test")
    )
    o: Option2 | None = None
    d: dict[str, Any] = {}

    class Settings:
        use_state_management = True


class DocumentWithLinkForNesting(Document):
    link: Link["DocumentWithBackLinkForNesting"]
    s: str

    class Settings:
        max_nesting_depths_per_field = {"link": 0}


class DocumentWithBackLinkForNesting(Document):
    back_link: BackLink[DocumentWithLinkForNesting] = Field(
        json_schema_extra={"original_field": "link"},
    )
    i: int

    class Settings:
        max_nesting_depths_per_field = {"back_link": 5}


class LongSelfLink(Document):
    link: Link["LongSelfLink"] | None = None

    class Settings:
        max_nesting_depth = 50


class DictEnum(str, Enum):
    RED = "Red"
    BLUE = "Blue"


class DocumentWithEnumKeysDict(Document):
    color: dict[DictEnum, str]


class BsonRegexDoc(Document):
    regex: Regex | None = None

    model_config = ConfigDict(
        arbitrary_types_allowed=True,
    )


class NativeRegexDoc(Document):
    regex: re.Pattern | None


# Models for testing alias resolution in nested fields (#937, #945)
class NestedWithAlias(BaseModel):
    unit_class: str = Field(alias="unitClass")
    item_count: int = Field(alias="itemCount")


class NestedDeep(BaseModel):
    inner: NestedWithAlias = Field(alias="innerAlias")


class DocumentWithNestedAlias(Document):
    nested_field: NestedWithAlias

    class Settings:
        name = "docs_with_nested_alias"


class DocumentWithDeepNestedAlias(Document):
    deep: NestedDeep

    class Settings:
        name = "docs_with_deep_nested_alias"


class DocumentWithAliasedLink(Document):
    linked: Link["DocumentToBeLinked"] = Field(alias="linkedAlias")

    class Settings:
        name = "docs_with_aliased_link"
