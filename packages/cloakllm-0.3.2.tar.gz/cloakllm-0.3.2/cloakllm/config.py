"""
CloakLLM configuration.

All settings have sensible defaults. Override via:
    config = ShieldConfig(log_dir="./my-audit-logs", spacy_model="en_core_web_lg")
    shield = Shield(config=config)

Or via environment variables:
    CLOAKLLM_LOG_DIR=./my-audit-logs
    CLOAKLLM_SPACY_MODEL=en_core_web_lg
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional


@dataclass
class ShieldConfig:
    """Configuration for CloakLLM."""

    # --- Detection ---
    spacy_model: str = field(
        default_factory=lambda: os.getenv("CLOAKLLM_SPACY_MODEL", "en_core_web_sm")
    )
    # Entity types to detect via spaCy NER
    ner_entity_types: set[str] = field(
        default_factory=lambda: {"PERSON", "ORG", "GPE", "LOC", "FAC", "NORP", "EMAIL", "PHONE"}
    )
    # Enable/disable regex-based detection
    detect_emails: bool = True
    detect_phones: bool = True
    detect_ssns: bool = True
    detect_credit_cards: bool = True
    detect_api_keys: bool = True
    detect_ip_addresses: bool = True
    detect_iban: bool = True
    # Custom patterns: list of (name, regex_pattern) tuples
    custom_patterns: list[tuple[str, str]] = field(default_factory=list)
    # Custom LLM categories: list of (name, description) tuples for semantic detection
    custom_llm_categories: list[tuple[str, str]] = field(default_factory=list)

    # --- LLM Detection (Pass 3: local LLM via Ollama) ---
    llm_detection: bool = field(
        default_factory=lambda: os.getenv("CLOAKLLM_LLM_DETECTION", "false").lower() == "true"
    )
    llm_model: str = field(
        default_factory=lambda: os.getenv("CLOAKLLM_LLM_MODEL", "llama3.2")
    )
    llm_ollama_url: str = field(
        default_factory=lambda: os.getenv("CLOAKLLM_OLLAMA_URL", "http://localhost:11434")
    )
    llm_timeout: float = 10.0
    llm_confidence: float = 0.85

    # --- Tokenization ---
    # Mode: "tokenize" (reversible tokens) or "redact" (irreversible [CATEGORY_REDACTED])
    mode: str = "tokenize"
    # Use descriptive tokens like [PERSON_0] vs opaque tokens like [TKN_A3F2]
    descriptive_tokens: bool = True

    # --- Entity Hashing ---
    # Enable per-entity HMAC-SHA256 hashing in entity_details (for cross-document linkage)
    entity_hashing: bool = field(
        default_factory=lambda: os.getenv("CLOAKLLM_ENTITY_HASHING", "false").lower() == "true"
    )
    # HMAC key — if empty and entity_hashing is True, a random key is auto-generated per session
    entity_hash_key: str = field(
        default_factory=lambda: os.getenv("CLOAKLLM_ENTITY_HASH_KEY", "")
    )

    # --- Audit Logging ---
    audit_enabled: bool = True
    log_dir: Path = field(
        default_factory=lambda: Path(os.getenv("CLOAKLLM_LOG_DIR", "./cloakllm_audit"))
    )
    # Log original values (set False for maximum privacy - only hashes logged)
    log_original_values: bool = False

    # --- OpenTelemetry ---
    otel_enabled: bool = field(
        default_factory=lambda: os.getenv("CLOAKLLM_OTEL_ENABLED", "false").lower() == "true"
    )
    otel_service_name: str = field(
        default_factory=lambda: os.getenv("OTEL_SERVICE_NAME", "cloakllm")
    )

    # --- Attestation (Ed25519 signing) ---
    # Pre-loaded DeploymentKeyPair object (from cloakllm.attestation)
    attestation_key: Optional[Any] = None
    # Path to keypair JSON file (loaded on Shield init)
    attestation_key_path: Optional[str] = field(
        default_factory=lambda: os.getenv("CLOAKLLM_SIGNING_KEY_PATH", None)
    )

    # --- LiteLLM Integration ---
    # Auto-sanitize on request, auto-desanitize on response
    auto_mode: bool = True
    # Skip sanitization for these model prefixes (e.g., local models)
    skip_models: list[str] = field(default_factory=list)

    def __post_init__(self):
        self.log_dir = Path(self.log_dir)
        if self.mode not in ("tokenize", "redact"):
            raise ValueError(f"Invalid mode '{self.mode}'. Must be 'tokenize' or 'redact'.")
        import re as _re
        for name, _desc in self.custom_llm_categories:
            if not _re.match(r'^[A-Z][A-Z0-9_]*$', name):
                raise ValueError(
                    f"Invalid custom LLM category name '{name}'. "
                    "Must match ^[A-Z][A-Z0-9_]*$"
                )
