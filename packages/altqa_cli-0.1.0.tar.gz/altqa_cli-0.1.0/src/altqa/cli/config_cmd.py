"""altqa config — view and manage project configuration."""

from __future__ import annotations

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from altqa.config.manager import config_exists, load_config

console = Console()


def run_config_show() -> None:
    """Display the current altqa.json configuration."""
    if not config_exists():
        console.print("[red]No altqa.json found. Run [bold]altqa init[/bold] first.[/red]")
        raise typer.Exit(code=1)

    config = load_config()

    table = Table(
        title="AltQA Configuration",
        show_header=True,
        header_style="bold magenta",
        expand=False,
    )
    table.add_column("Setting", style="cyan")
    table.add_column("Value")

    table.add_row("App URL", config.app_url)
    table.add_row("", "")

    table.add_row("LLM Provider", config.llm.provider)
    table.add_row("LLM Model", config.llm.model)
    api_display = config.llm.api_key_env or "[dim]not required[/dim]"
    table.add_row("LLM API Key Env", api_display)
    table.add_row("", "")

    table.add_row("Jira URL", config.jira.base_url)
    table.add_row("Jira Project", config.jira.project_key)
    table.add_row("Jira Email", config.jira.email)
    table.add_row("Jira Token Env", config.jira.api_key_env)
    table.add_row("", "")

    table.add_row("Browser", config.browser.type)
    table.add_row("Headless", str(config.browser.headless))
    table.add_row("", "")

    table.add_row("Flows Dir", config.flows_dir)
    table.add_row("Logs Dir", config.logs_dir)

    console.print()
    console.print(table)
    console.print()
