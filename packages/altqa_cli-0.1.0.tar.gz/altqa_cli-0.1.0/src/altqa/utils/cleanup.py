"""Post-run cleanup utilities."""

from __future__ import annotations

import logging
from pathlib import Path

log = logging.getLogger("altqa.cleanup")


def remove_screenshots(screenshots_dir: str | Path) -> int:
    """Delete all .png files from *screenshots_dir*. Returns count removed."""
    d = Path(screenshots_dir)
    if not d.is_dir():
        return 0
    removed = 0
    for img in d.glob("*.png"):
        try:
            img.unlink()
            removed += 1
        except OSError:
            log.debug("Could not delete %s", img)
    if removed:
        log.info("Cleaned up %d screenshot(s) from %s", removed, d)
    return removed
