"""Pipeline execution result data structures."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any

from altqa.agents.failure_analyzer import BugReport
from altqa.browser.health import HealthIssue, IssueSeverity
from altqa.flows.runner import FlowResult


class ExecutionPath(str, Enum):
    TEST_CASES = "test_cases"
    TICKET_ANALYSIS = "ticket_analysis"


@dataclass
class BugFiled:
    """Record of a bug sub-task created in Jira."""
    jira_key: str
    jira_url: str
    summary: str
    severity: str
    flow_name: str
    step_number: int


@dataclass
class PipelineResult:
    """Aggregate outcome of a full `altqa run` execution."""
    ticket_key: str
    execution_path: ExecutionPath
    flow_results: list[FlowResult] = field(default_factory=list)
    bugs_filed: list[BugFiled] = field(default_factory=list)
    bug_reports: list[BugReport] = field(default_factory=list)
    error: str | None = None

    @property
    def total_flows(self) -> int:
        return len(self.flow_results)

    @property
    def passed_flows(self) -> int:
        return sum(1 for fr in self.flow_results if fr.passed)

    @property
    def failed_flows(self) -> int:
        return sum(1 for fr in self.flow_results if not fr.passed)

    @property
    def all_passed(self) -> bool:
        return all(fr.passed for fr in self.flow_results) and not self.error

    @property
    def total_steps(self) -> int:
        return sum(len(fr.steps) for fr in self.flow_results)

    @property
    def passed_steps(self) -> int:
        return sum(sum(1 for s in fr.steps if s.passed) for fr in self.flow_results)

    @property
    def total_duration_ms(self) -> float:
        return sum(fr.duration_ms for fr in self.flow_results)

    @property
    def all_health_issues(self) -> list[HealthIssue]:
        issues: list[HealthIssue] = []
        for fr in self.flow_results:
            issues.extend(fr.health_issues)
        return issues

    @property
    def critical_health_issues(self) -> list[HealthIssue]:
        return [i for i in self.all_health_issues if i.severity == IssueSeverity.CRITICAL]

    @property
    def health_warnings(self) -> list[HealthIssue]:
        return [i for i in self.all_health_issues if i.severity == IssueSeverity.WARNING]

    @property
    def exit_code(self) -> int:
        """0 = all passed, 1 = bugs found, 2 = execution error."""
        if self.error:
            return 2
        if self.failed_flows > 0:
            return 1
        return 0

    def summary(self) -> dict[str, Any]:
        return {
            "ticket": self.ticket_key,
            "path": self.execution_path.value,
            "flows_total": self.total_flows,
            "flows_passed": self.passed_flows,
            "flows_failed": self.failed_flows,
            "steps_total": self.total_steps,
            "steps_passed": self.passed_steps,
            "bugs_filed": len(self.bugs_filed),
            "health_issues": len(self.all_health_issues),
            "health_critical": len(self.critical_health_issues),
            "health_warnings": len(self.health_warnings),
            "duration_ms": round(self.total_duration_ms, 1),
            "exit_code": self.exit_code,
        }
