"""Pydantic models for altqa.json configuration."""

from __future__ import annotations

from pydantic import BaseModel, Field


LLM_PROVIDERS: dict[str, list[str]] = {
    "openai": ["gpt-4o", "gpt-4o-mini", "gpt-4.1", "gpt-4.1-mini", "o3-mini"],
    "anthropic": ["claude-sonnet-4-20250514", "claude-3-5-haiku-20241022"],
    "ollama": ["llama3", "mistral", "codellama", "phi3"],
    "gemini": ["gemini-2.5-pro", "gemini-2.5-flash", "gemini-2.0-flash"],
    "groq": ["llama-3.3-70b-versatile", "mixtral-8x7b-32768"],
}

BROWSER_TYPES = ["chromium", "firefox", "webkit"]


class LLMConfig(BaseModel):
    provider: str = Field(description="LLM provider name (openai, anthropic, ollama, gemini, groq)")
    model: str = Field(description="Model identifier for the chosen provider")
    api_key: str = Field(default="", description="API key (stored directly)")
    api_key_env: str = Field(
        default="ALTQA_LLM_KEY",
        description="Environment variable name that holds the API key (fallback)",
    )


class JiraConfig(BaseModel):
    base_url: str = Field(description="Jira instance URL (e.g. https://team.atlassian.net)")
    project_key: str = Field(description="Jira project key (e.g. PROJ)")
    email: str = Field(description="Jira account email")
    api_token: str = Field(default="", description="Jira API token (stored directly)")
    api_key_env: str = Field(
        default="ALTQA_JIRA_TOKEN",
        description="Environment variable name that holds the Jira API token (fallback)",
    )


class BrowserConfig(BaseModel):
    type: str = Field(default="chromium", description="Browser engine: chromium, firefox, or webkit")
    headless: bool = Field(default=False, description="Run browser in headless mode")


class AltQAConfig(BaseModel):
    app_url: str = Field(description="Target application URL to test")
    llm: LLMConfig
    jira: JiraConfig
    browser: BrowserConfig = Field(default_factory=BrowserConfig)
    flows_dir: str = Field(default="flows/")
    logs_dir: str = Field(default="logs/")
