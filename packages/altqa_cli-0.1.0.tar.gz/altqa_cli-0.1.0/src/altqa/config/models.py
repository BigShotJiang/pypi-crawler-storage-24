"""Resolve user's LLM provider choice into an Agno model instance."""

from __future__ import annotations

from typing import Any

from .schema import LLMConfig


def resolve_model(llm_config: LLMConfig) -> Any:
    """Return an Agno model instance for the configured provider + model id.

    Imports are deferred so only the chosen provider's SDK is required at
    runtime.  If `api_key` is set directly in config, it's passed to the
    model; otherwise the SDK picks it up from the standard env var.
    """
    import os

    provider = llm_config.provider.lower()
    api_key = llm_config.api_key or os.environ.get(llm_config.api_key_env, "") or None

    if provider == "openai":
        from agno.models.openai import OpenAIResponses
        return OpenAIResponses(id=llm_config.model, api_key=api_key)

    if provider == "anthropic":
        from agno.models.anthropic import Claude
        return Claude(id=llm_config.model, api_key=api_key)

    if provider == "ollama":
        from agno.models.ollama import Ollama
        return Ollama(id=llm_config.model)

    if provider == "gemini":
        from agno.models.google import Gemini
        return Gemini(id=llm_config.model, api_key=api_key)

    if provider == "groq":
        from agno.models.groq import Groq
        return Groq(id=llm_config.model, api_key=api_key)

    raise ValueError(
        f"Unknown LLM provider '{provider}'. "
        f"Supported: openai, anthropic, ollama, gemini, groq"
    )
