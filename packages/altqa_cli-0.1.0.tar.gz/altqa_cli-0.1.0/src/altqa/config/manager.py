"""Read and write altqa.json project configuration."""

from __future__ import annotations

import json
from pathlib import Path

from .schema import AltQAConfig

CONFIG_FILENAME = "altqa.json"


def find_config_path(start: Path | None = None) -> Path:
    """Return the path to altqa.json in the given (or current) directory."""
    root = start or Path.cwd()
    return root / CONFIG_FILENAME


def config_exists(start: Path | None = None) -> bool:
    return find_config_path(start).is_file()


def load_config(start: Path | None = None) -> AltQAConfig:
    """Load and validate altqa.json from *start* directory."""
    path = find_config_path(start)
    if not path.is_file():
        raise FileNotFoundError(
            f"No {CONFIG_FILENAME} found in {path.parent}. Run 'altqa init' first."
        )
    raw = json.loads(path.read_text())
    return AltQAConfig.model_validate(raw)


def save_config(config: AltQAConfig, start: Path | None = None) -> Path:
    """Write validated config to altqa.json and return the path."""
    path = find_config_path(start)
    path.write_text(
        json.dumps(config.model_dump(), indent=2) + "\n"
    )
    return path
