"""AltQA — AI-powered QA automation CLI."""

__version__ = "0.1.0"