from setuptools import setup, find_packages

setup(
    name="mooneuropa",
    version="0.1.0",
    description="Named after Jupiter's icy moon — audio analysis, synthesis and effects",
    author="Moon Europa Contributors",
    packages=find_packages(),
    python_requires=">=3.8",
    install_requires=[
        "numpy>=1.21",
        "scipy>=1.7",
        "soundfile>=0.11",
        "sounddevice>=0.4",
    ],
    extras_require={
        "mp3": ["audioread>=2.1"],
        "viz": ["matplotlib>=3.4"],
        "all": ["audioread>=2.1", "matplotlib>=3.4"],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "Topic :: Multimedia :: Sound/Audio",
        "Topic :: Multimedia :: Sound/Audio :: Analysis",
        "Topic :: Scientific/Engineering :: Information Analysis",
    ],
)
