"""
Moon Europa — Python Audio Library
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Named after Europa, the icy moon of Jupiter hiding an ocean beneath its surface.
Just like Europa conceals depths of mystery, this library gives you deep control over audio.

    >>> import europa
    >>> audio = europa.load("song.mp3")
    >>> europa.play(audio)

    >>> mfcc = europa.feature.mfcc(audio)
    >>> bpm, beats = europa.analysis.beat_track(audio)
    >>> stretched = europa.effects.time_stretch(audio, rate=1.5)
"""

__version__ = "0.1.0"
__author__ = "Moon Europa Contributors"
__description__ = "A Python audio library named after Jupiter's icy moon."

from .core.audio import Audio
from .core.load import load
from .core.save import save
from .core.convert import to_mono, to_stereo, resample, normalize, trim_silence, pad
from .io.playback import play, stop, pause, resume
from .io.record import record
from . import feature
from . import effects
from . import synthesis
from . import analysis
from . import display
from . import utils
