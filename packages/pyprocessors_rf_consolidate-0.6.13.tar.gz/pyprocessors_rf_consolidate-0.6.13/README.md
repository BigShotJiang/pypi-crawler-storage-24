# pyprocessors_rf_consolidate

[![license](https://img.shields.io/github/license/oterrier/pyprocessors_rf_consolidate)](https://github.com/oterrier/pyprocessors_rf_consolidate/blob/master/LICENSE)
[![tests](https://github.com/oterrier/pyprocessors_rf_consolidate/workflows/tests/badge.svg)](https://github.com/oterrier/pyprocessors_rf_consolidate/actions?query=workflow%3Atests)
[![codecov](https://img.shields.io/codecov/c/github/oterrier/pyprocessors_rf_consolidate)](https://codecov.io/gh/oterrier/pyprocessors_rf_consolidate)
[![docs](https://img.shields.io/readthedocs/pyprocessors_rf_consolidate)](https://pyprocessors_rf_consolidate.readthedocs.io)
[![version](https://img.shields.io/pypi/v/pyprocessors_rf_consolidate)](https://pypi.org/project/pyprocessors_rf_consolidate/)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pyprocessors_rf_consolidate)](https://pypi.org/project/pyprocessors_rf_consolidate/)

RFConsolidate annotations coming from different annotators

## Installation

You can simply `pip install pyprocessors_rf_consolidate`.

## Developing

### Pre-requisites

You will need to install [uv](https://docs.astral.sh/uv/):

```
curl -LsSf https://astral.sh/uv/install.sh | sh
```

Clone the repository:

```
git clone https://github.com/oterrier/pyprocessors_rf_consolidate
```

### Install dependencies

```
uv sync --extra test
```

### Running the test suite

```
uv run pytest
```

### Linting

```
uv run ruff check .
uv run ruff format --check .
```

### Building the documentation

```
uv run --extra docs sphinx-build docs docs/_build
```

The built documentation is available at `docs/_build/index.html`.

## SBOM & vulnerability check

Install the SBOM dependencies:

```
uv sync --extra sbom
```

Generate a CycloneDX SBOM from the current environment:

```
uv run cyclonedx-py environment -o sbom.cdx.json --output-format json
```

Audit dependencies for known vulnerabilities:

```
uv run pip-audit --format json --output audit-report.json
```

To fail on any known vulnerability (useful in CI):

```
uv run pip-audit --strict
```
