from __future__ import annotations

import copy
from dataclasses import dataclass
from typing import Any, Dict, List, Optional


_DEFAULT_BASE_URL_BY_PROVIDER: Dict[str, str] = {
    "openai": "https://api.openai.com/v1",
}


def _merge_tools_into_tooling(merged: Dict[str, Any], tool_names: List[str]) -> None:
    """Append tool names into the first ``type: function`` tooling block, or add one."""
    names = [t.strip() for t in tool_names if isinstance(t, str) and t.strip()]
    if not names:
        return

    raw = merged.get("tooling")
    if raw is None:
        merged["tooling"] = [
            {"type": "function", "config": {"tools": [{"name": n} for n in names]}},
        ]
        return

    # internal config might store tooling blocks as typed `ToolingConfig` objects.
    # Convert them into dict blocks so later parsing won't see raw dicts mixed with objects.
    def _tooling_item_to_dict(item: Any) -> Any:
        if isinstance(item, dict):
            return item
        if hasattr(item, "__dict__"):
            d = dict(vars(item))
            cfg = d.get("config")
            if cfg is not None and not isinstance(cfg, dict) and hasattr(cfg, "__dict__"):
                d["config"] = dict(vars(cfg))
            return d
        return item

    tooling = copy.deepcopy(raw) if isinstance(raw, list) else []
    if not isinstance(tooling, list):
        tooling = []
    tooling = [_tooling_item_to_dict(b) for b in tooling]

    for block in tooling:
        if not isinstance(block, dict):
            continue
        if str(block.get("type", "")).lower() != "function":
            continue
        cfg = block.setdefault("config", {})
        if not isinstance(cfg, dict):
            cfg = {}
            block["config"] = cfg
        tools_list = cfg.setdefault("tools", [])
        if not isinstance(tools_list, list):
            tools_list = []
            cfg["tools"] = tools_list
        seen = {
            str(t.get("name")).strip()
            for t in tools_list
            if isinstance(t, dict) and t.get("name") is not None
        }
        for n in names:
            if n not in seen:
                tools_list.append({"name": n})
                seen.add(n)
        merged["tooling"] = tooling
        return

    tooling.append({"type": "function", "config": {"tools": [{"name": n} for n in names]}})
    merged["tooling"] = tooling


@dataclass
class AgentConfig:
    model: str
    provider: str = "openai"
    api_key: Optional[str] = None
    base_url: Optional[str] = None
    temperature: Optional[float] = None
    top_p: Optional[float] = None
    max_tokens: Optional[int] = None
    skills: Optional[List[str]] = None
    # Function tool names (e.g. from @register_tool); merged into YAML ``tooling`` without removing existing entries.
    tools: Optional[List[str]] = None
    system_prompt: Optional[str] = None

    def to_internal_config(self, yaml_config: Dict[str, Any]) -> Dict[str, Any]:
        merged = dict(yaml_config)
        provider = (self.provider or merged.get("provider") or "openai").strip().lower()
        if provider not in {"openai", "gemini"}:
            provider = "gemini"
        if self.model:
            merged["name"] = self.model
        merged["provider"] = provider
        if self.api_key:
            merged["api_key"] = self.api_key
        if self.base_url:
            merged["base_url"] = self.base_url
        else:
            default_base_url = _DEFAULT_BASE_URL_BY_PROVIDER.get(provider)
            if default_base_url:
                merged.setdefault("base_url", default_base_url)
        if self.system_prompt:
            merged["role"] = self.system_prompt

        params = dict(merged.get("params") or {})
        if self.temperature is not None:
            params["temperature"] = self.temperature
        if self.top_p is not None:
            params["top_p"] = self.top_p
        if self.max_tokens is not None:
            params["max_tokens"] = self.max_tokens
        if params:
            merged["params"] = params

        if self.skills is not None:
            skills_list = (
                [self.skills]
                if isinstance(self.skills, str)
                else list(self.skills)
            )
            skills_list = [s.strip() for s in skills_list if isinstance(s, str) and s.strip()]
            merged["skills"] = {
                "enabled": True,
                "allow": [{"name": name} for name in skills_list],
            }

        if self.tools is not None:
            tool_names = (
                [self.tools]
                if isinstance(self.tools, str)
                else list(self.tools)
            )
            _merge_tools_into_tooling(merged, list(tool_names))

        return merged
