from __future__ import annotations


class ChatDevError(Exception):
    """Base exception for public ChatDev SDK errors."""


__all__ = ["ChatDevError"]
