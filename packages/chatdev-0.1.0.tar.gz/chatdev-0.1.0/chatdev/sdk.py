"""Public SDK entry for executing workflows programmatically."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
import sys
from typing import Any, Dict, MutableMapping, Optional, Sequence, Union

from .config import AgentConfig
from .result import ChatDevResult

_INTERNAL_ROOT = Path(__file__).resolve().parents[1] / "_internal"
if _INTERNAL_ROOT.exists():
    internal_path = str(_INTERNAL_ROOT)
    if internal_path not in sys.path:
        sys.path.append(internal_path)

from check.check import load_config
from entity.enums import LogLevel
from entity.graph_config import GraphConfig
from entity.messages import Message
from runtime.bootstrap.schema import ensure_schema_registry_populated
from server.settings import YAML_DIR
from utils.attachments import AttachmentStore
from utils.exceptions import ValidationError
from utils.task_input import TaskInputBuilder
from workflow.graph import GraphExecutor
from workflow.graph_context import GraphContext

OUTPUT_ROOT = Path("WareHouse")


@dataclass
class WorkflowMetaInfo:
    session_name: str
    yaml_file: str
    log_id: Optional[str]
    outputs: Optional[Dict[str, Any]]
    token_usage: Optional[Dict[str, Any]]
    output_dir: Path


@dataclass
class WorkflowRunResult:
    final_message: Optional[Message]
    meta_info: WorkflowMetaInfo


def _normalize_session_name(yaml_path: Path, session_name: Optional[str]) -> str:
    if session_name and session_name.strip():
        return session_name.strip()
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    return f"sdk_{yaml_path.stem}_{timestamp}"


def _resolve_yaml_path(yaml_file: Union[str, Path]) -> Path:
    candidate = Path(yaml_file).expanduser()
    if candidate.is_absolute():
        return candidate
    if candidate.exists():
        return candidate
    project_root = Path(__file__).resolve().parents[1]
    yaml_root = YAML_DIR if YAML_DIR.is_absolute() else (project_root / YAML_DIR)
    return (yaml_root / candidate).expanduser()


def _build_task_input(
    graph_context: GraphContext,
    prompt: str,
    attachments: Sequence[Union[str, Path]],
) -> Union[str, list[Message]]:
    if not attachments:
        return prompt
    attachments_dir = graph_context.directory / "code_workspace" / "attachments"
    attachments_dir.mkdir(parents=True, exist_ok=True)
    store = AttachmentStore(attachments_dir)
    builder = TaskInputBuilder(store)
    normalized_paths = [str(Path(path).expanduser()) for path in attachments]
    return builder.build_from_file_paths(prompt, normalized_paths)


def _as_node_config(node: Any) -> MutableMapping[str, Any]:
    config = getattr(node, "config", None)
    if isinstance(config, MutableMapping):
        return config
    if hasattr(config, "__dict__"):
        return config.__dict__
    raise TypeError(f"Node '{getattr(node, 'id', '?')}' config is not mutable mapping-like")


def _apply_agent_configs(design: Any, agent_configs: Optional[Dict[str, AgentConfig]]) -> None:
    if not design or not hasattr(design, "graph") or not agent_configs:
        return

    # NOTE:
    # - 内部执行引擎期待 `node.config.tooling` 是 `ToolingConfig` 对象列表，
    #   而不是纯 dict。
    # - 我们在这里“直接修改 typed config 的字段”，避免把 tooling/skills 变成 dict 导致
    #   `node.tools` / 其他 property 在运行时崩溃。
    from entity.configs.node.agent import AgentConfig as InternalAgentConfig  # type: ignore
    from entity.configs.node.skills import AgentSkillsConfig  # type: ignore
    from entity.configs.node.tooling import FunctionToolConfig, ToolingConfig  # type: ignore

    for node in getattr(design.graph, "nodes", []):
        node_id = getattr(node, "id", None)
        if not node_id or node_id not in agent_configs:
            continue

        public_cfg = agent_configs[node_id]
        internal_cfg = getattr(node, "config", None)
        if internal_cfg is None:
            continue
        if not isinstance(internal_cfg, InternalAgentConfig):
            # 目前 SDK 仅支持覆盖 agent/model 类型节点的 agent config。
            continue

        # ---- 基础模型配置覆盖 ----
        if public_cfg.model:
            internal_cfg.name = public_cfg.model
        if public_cfg.provider:
            internal_cfg.provider = (public_cfg.provider or "").strip().lower()
        if public_cfg.api_key:
            internal_cfg.api_key = public_cfg.api_key
        if public_cfg.base_url:
            internal_cfg.base_url = public_cfg.base_url
        if public_cfg.system_prompt:
            internal_cfg.role = public_cfg.system_prompt

        # ---- params 覆盖 ----
        if public_cfg.temperature is not None:
            internal_cfg.params["temperature"] = public_cfg.temperature
        if public_cfg.top_p is not None:
            internal_cfg.params["top_p"] = public_cfg.top_p
        if public_cfg.max_tokens is not None:
            internal_cfg.params["max_tokens"] = public_cfg.max_tokens

        # ---- skills 覆盖 ----
        if public_cfg.skills is not None:
            skills_list = (
                [public_cfg.skills]
                if isinstance(public_cfg.skills, str)
                else list(public_cfg.skills)
            )
            skills_list = [s.strip() for s in skills_list if isinstance(s, str) and s.strip()]
            internal_cfg.skills = AgentSkillsConfig.from_dict(
                {"enabled": True, "allow": skills_list},
                path=f"{getattr(internal_cfg, 'path', 'agent')}.skills",
            )

        # ---- tools 覆盖/合并 ----
        if public_cfg.tools is not None:
            tool_names = (
                [public_cfg.tools]
                if isinstance(public_cfg.tools, str)
                else list(public_cfg.tools)
            )
            tool_names = [t.strip() for t in tool_names if isinstance(t, str) and t.strip()]
            if tool_names:
                tooling = list(getattr(internal_cfg, "tooling", []) or [])

                # 找到第一个 function 类型 tooling，用它来合并工具列表
                fn_tool_idx = None
                for idx, tool_cfg in enumerate(tooling):
                    if isinstance(tool_cfg, ToolingConfig) and tool_cfg.type.lower() == "function":
                        fn_tool_idx = idx
                        break

                if fn_tool_idx is None:
                    new_tooling = ToolingConfig.from_dict(
                        {"type": "function", "config": {"tools": [{"name": n} for n in tool_names]}},
                        path=f"{getattr(internal_cfg, 'path', 'agent')}.tooling[0]",
                    )
                    tooling.append(new_tooling)
                else:
                    existing_tool_names: list[str] = []
                    fn_cfg = tooling[fn_tool_idx].as_config(FunctionToolConfig)
                    if fn_cfg and isinstance(fn_cfg.tools, list):
                        for item in fn_cfg.tools:
                            if isinstance(item, dict):
                                name = item.get("name")
                                if isinstance(name, str) and name.strip():
                                    existing_tool_names.append(name.strip())

                    combined = []
                    seen = set()
                    for n in existing_tool_names + tool_names:
                        if n not in seen:
                            combined.append(n)
                            seen.add(n)

                    tooling[fn_tool_idx] = ToolingConfig.from_dict(
                        {"type": "function", "config": {"tools": [{"name": n} for n in combined]}},
                        path=f"{getattr(internal_cfg, 'path', 'agent')}.tooling[{fn_tool_idx}]",
                    )

                internal_cfg.tooling = tooling


def _default_target_node_id(design: Any) -> Optional[str]:
    """Pick a node id to attach a lone AgentConfig: first agent/model, else first node with id."""
    nodes = list(getattr(getattr(design, "graph", None), "nodes", []) or [])
    for node in nodes:
        ntype = getattr(node, "type", None)
        if ntype in ("agent", "model"):
            nid = getattr(node, "id", None)
            if isinstance(nid, str) and nid.strip():
                return nid.strip()
    for node in nodes:
        nid = getattr(node, "id", None)
        if isinstance(nid, str) and nid.strip():
            return nid.strip()
    return None


def _coerce_agent_configs(
    design: Any, agent_configs: Optional[Union[AgentConfig, Dict[str, AgentConfig]]]
) -> Optional[Dict[str, AgentConfig]]:
    """Turn a single AgentConfig into {default_node_id: cfg}; pass dict through."""
    if agent_configs is None:
        return None
    if isinstance(agent_configs, AgentConfig):
        node_id = _default_target_node_id(design)
        if not node_id:
            raise ValueError(
                "agent_configs was a single AgentConfig, but the workflow has no nodes with an id "
                "to attach it to. Use a dict mapping node id -> AgentConfig instead."
            )
        return {node_id: agent_configs}
    if isinstance(agent_configs, dict):
        return dict(agent_configs)
    raise TypeError(
        "agent_configs must be None, an AgentConfig, or a dict[str, AgentConfig], "
        f"got {type(agent_configs).__name__}"
    )


def run_workflow(
    yaml_file: Union[str, Path],
    task_prompt: str,
    attachments: Optional[Sequence[Union[str, Path]]] = None,
    variables: Optional[Dict[str, Any]] = None,
    agent_configs: Optional[Union[AgentConfig, Dict[str, AgentConfig]]] = None,
    session_name: Optional[str] = None,
    fn_module: Optional[str] = None,
    log_level: Optional[Union[LogLevel, str]] = None,
) -> ChatDevResult:
    """Run a workflow YAML and return a ``ChatDevResult``.

    If ``agent_configs`` is a single ``AgentConfig``, it is applied to the **first**
    node in the graph whose ``type`` is ``agent`` or ``model`` (same order as in the YAML).
    If there is none, the first node with a non-empty ``id`` is used. To target a specific
    node, pass ``dict[node_id, AgentConfig]`` instead.
    """
    ensure_schema_registry_populated()
    yaml_path = _resolve_yaml_path(yaml_file)
    if not yaml_path.exists():
        raise FileNotFoundError(f"YAML file not found: {yaml_path}")

    attachments = attachments or []
    if (not task_prompt or not task_prompt.strip()) and not attachments:
        raise ValidationError(
            "Task prompt cannot be empty",
            details={"task_prompt_provided": bool(task_prompt)},
        )

    design = load_config(yaml_path, fn_module=fn_module, vars_override=variables)
    _apply_agent_configs(design, _coerce_agent_configs(design, agent_configs))
    normalized_session = _normalize_session_name(yaml_path, session_name)

    graph_config = GraphConfig.from_definition(
        design.graph,
        name=normalized_session,
        output_root=OUTPUT_ROOT,
        source_path=str(yaml_path),
        vars=design.vars,
    )

    if log_level:
        resolved_level = LogLevel(log_level) if isinstance(log_level, str) else log_level
        graph_config.log_level = resolved_level
        graph_config.definition.log_level = resolved_level

    graph_context = GraphContext(config=graph_config)
    task_input = _build_task_input(graph_context, task_prompt, attachments)
    executor = GraphExecutor.execute_graph(graph_context, task_input)
    final_message = executor.get_final_output_message()
    logger = executor.log_manager.get_logger() if executor.log_manager else None
    token_usage = executor.token_tracker.get_token_usage() if executor.token_tracker else None

    raw_result = WorkflowRunResult(
        final_message=final_message,
        meta_info=WorkflowMetaInfo(
            session_name=normalized_session,
            yaml_file=str(yaml_path),
            log_id=logger.workflow_id if logger else None,
            outputs=executor.outputs,
            token_usage=token_usage,
            output_dir=graph_context.directory,
        ),
    )
    return ChatDevResult.from_raw(raw_result)
