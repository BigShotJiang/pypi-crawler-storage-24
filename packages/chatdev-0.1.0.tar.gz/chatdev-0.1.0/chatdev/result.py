from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, List, Optional

from .exceptions import ChatDevError

try:
    from entity.messages import Message
except Exception:  # pragma: no cover
    Message = Any  # type: ignore


@dataclass
class ChatDevResult:
    success: bool
    final_message: Optional[str]
    output_dir: Optional[Path]
    artifacts: List[Path]
    logs: List[Any]
    error: Optional[ChatDevError] = None
    raw_result: Any | None = None

    @classmethod
    def from_raw(cls, raw_result: Any) -> "ChatDevResult":
        final_text: Optional[str] = None
        final_message = getattr(raw_result, "final_message", None)
        if final_message is not None:
            try:
                if isinstance(final_message, Message):
                    final_text = final_message.text_content()
                else:
                    final_text = str(final_message)
            except Exception:
                final_text = None

        output_dir = None
        meta_info = getattr(raw_result, "meta_info", None)
        if meta_info is not None:
            output_dir = getattr(meta_info, "output_dir", None)

        return cls(
            success=True,
            final_message=final_text,
            output_dir=output_dir,
            artifacts=[],
            logs=[],
            error=None,
            raw_result=raw_result,
        )
