"""
llm-guard-kit framework integrations.

Available adapters:
    LangChain  : QppgLangChainCallback   (pip install "llm-guard-kit[langchain]")
    OpenAI     : score_assistants_run    (pip install "llm-guard-kit[openai]")
    LlamaIndex : QppgLlamaIndexCallback  (pip install "llm-guard-kit[llamaindex]")
    Haystack   : QppgHaystackMonitor     (pip install "llm-guard-kit[haystack]")
"""
