"""
QPPG: Quantum-Principled Primitive Genesis

A physics-principled framework for bifurcation-based clustering,
novelty detection, and LLM trust verification.

Core modules:
    qppg.core       - Multi-well energy landscape with mu-controlled bifurcation
    qppg.encoder    - LLM semantic encoding (description + embedding pipeline)
    qppg.trust      - Trust verification for LLM outputs
    qppg.novelty    - Online novelty detection with transform library
    qppg.blindness  - Blindness detection + energy accounting (Layer 3)

Quick start:
    from qppg import TrustScorer, SolutionGenerator
    from qppg import QPPGSubstrate, QPPGOnlineClusterer
    from qppg import NoveltyEngine, LLMEncoder
"""

__version__ = "0.1.0"

# Core substrate
from .core import QPPGSubstrate, QPPGOnlineClusterer
from .core import compute_jacobian, jacobian_signature, signature_distance

# Trust engine
from .trust import TrustScorer, SolutionGenerator, extract_numerical_answer

# Encoder
from .encoder import LLMEncoder, LLMTransformDescriber, TextEmbedder

# Novelty engine
from .novelty import NoveltyEngine, TransformLibrary, TransformCategory

# Blindness detection (Layer 3)
from .blindness import BlindnessDetector, EnergyAccountant
from .blindness import InputClassification, BlindnessSignals, EnergyBudgetState

__all__ = [
    # Core
    "QPPGSubstrate",
    "QPPGOnlineClusterer",
    "compute_jacobian",
    "jacobian_signature",
    "signature_distance",
    # Trust
    "TrustScorer",
    "SolutionGenerator",
    "extract_numerical_answer",
    # Encoder
    "LLMEncoder",
    "LLMTransformDescriber",
    "TextEmbedder",
    # Novelty
    "NoveltyEngine",
    "TransformLibrary",
    "TransformCategory",
    # Blindness (Layer 3)
    "BlindnessDetector",
    "EnergyAccountant",
    "InputClassification",
    "BlindnessSignals",
    "EnergyBudgetState",
]
