"""tests/test_trust_selective_router.py — Unit tests for SelectiveVerificationRouter."""
import pytest
from unittest.mock import MagicMock

pytestmark = pytest.mark.unit

STEPS = [
    {"thought": "thinking", "action_type": "Search",
     "action_arg": "query", "observation": "result"},
]


def _make_mock_guard(behavioral_risk=0.3, risk_score=0.3):
    """Create a mock AgentGuard."""
    mock_guard = MagicMock()
    # Set scalar attributes used internally by SelectiveVerificationRouter
    mock_guard._alert_threshold = 0.70
    # Mock _scorer.score() for behavioral pre-score
    mock_lf = MagicMock()
    mock_lf.risk_score = behavioral_risk
    mock_lf.failure_mode = None
    mock_lf.components = {}
    mock_guard._scorer.score.return_value = mock_lf
    # Mock full score_chain()
    mock_result = MagicMock()
    mock_result.risk_score = risk_score
    mock_result.confidence_tier = "HIGH" if risk_score < 0.5 else "LOW"
    mock_guard.score_chain.return_value = mock_result
    return mock_guard


class TestImport:
    def test_import(self):
        from llm_guard.trust.selective_router import SelectiveVerificationRouter
        assert SelectiveVerificationRouter is not None


class TestInstantiation:
    def test_default_threshold(self):
        from llm_guard.trust.selective_router import SelectiveVerificationRouter
        guard = _make_mock_guard()
        router = SelectiveVerificationRouter(guard)
        assert router._high_threshold == 0.50

    def test_custom_threshold(self):
        from llm_guard.trust.selective_router import SelectiveVerificationRouter
        guard = _make_mock_guard()
        router = SelectiveVerificationRouter(guard, high_threshold=0.4)
        assert router._high_threshold == 0.4


class TestRouting:
    def test_low_risk_bypasses_guard(self):
        from llm_guard.trust.selective_router import SelectiveVerificationRouter
        guard = _make_mock_guard(behavioral_risk=0.2)  # below threshold
        router = SelectiveVerificationRouter(guard)
        result = router.route("Q", STEPS, "A")
        assert result is not None
        # Should bypass full guard
        guard.score_chain.assert_not_called()

    def test_high_risk_uses_full_pipeline(self):
        from llm_guard.trust.selective_router import SelectiveVerificationRouter
        guard = _make_mock_guard(behavioral_risk=0.8)  # above threshold
        router = SelectiveVerificationRouter(guard)
        result = router.route("Q", STEPS, "A")
        guard.score_chain.assert_called_once()

    def test_empty_steps_escalates(self):
        from llm_guard.trust.selective_router import SelectiveVerificationRouter
        guard = _make_mock_guard(behavioral_risk=0.1)
        router = SelectiveVerificationRouter(guard)
        result = router.route("Q", [], "A")
        # Empty steps always escalate
        guard.score_chain.assert_called_once()

    def test_score_chain_alias(self):
        from llm_guard.trust.selective_router import SelectiveVerificationRouter
        guard = _make_mock_guard(behavioral_risk=0.8)
        router = SelectiveVerificationRouter(guard)
        result = router.score_chain("Q", STEPS, "A")
        assert result is not None


class TestRoutingStats:
    def test_initial_stats_zero(self):
        from llm_guard.trust.selective_router import SelectiveVerificationRouter
        guard = _make_mock_guard()
        router = SelectiveVerificationRouter(guard)
        stats = router.routing_stats()
        assert stats["bypassed"] == 0
        assert stats["full_pipeline"] == 0

    def test_bypass_counted(self):
        from llm_guard.trust.selective_router import SelectiveVerificationRouter
        guard = _make_mock_guard(behavioral_risk=0.1)
        router = SelectiveVerificationRouter(guard)
        router.route("Q", STEPS, "A")
        stats = router.routing_stats()
        assert stats["bypassed"] == 1
        assert stats["full_pipeline"] == 0

    def test_full_pipeline_counted(self):
        from llm_guard.trust.selective_router import SelectiveVerificationRouter
        guard = _make_mock_guard(behavioral_risk=0.9)
        router = SelectiveVerificationRouter(guard)
        router.route("Q", STEPS, "A")
        stats = router.routing_stats()
        assert stats["full_pipeline"] == 1
