"""
Tests for v0.59.0 D1: calibrate_sc_weight() on AgentGuard
"""
import pytest
from llm_guard.scoring.agent_guard import AgentGuard


def test_calibrate_sc_weight_sets_adaptive():
    g = AgentGuard()
    # correlated pairs -> AUROC > 0.55 -> weight = 0.1
    pairs = [(0.1 if l == 0 else 0.9, l) for l in ([0] * 10 + [1] * 10)]
    result = g.calibrate_sc_weight(pairs)
    assert g._adaptive_sc_weight == 0.1
    assert result == 0.1


def test_calibrate_sc_weight_zeros_when_auroc_low():
    g = AgentGuard()
    # anti-correlated -> AUROC < 0.55 -> weight = 0.0
    pairs = [(0.9 if l == 0 else 0.1, l) for l in ([0] * 10 + [1] * 10)]
    result = g.calibrate_sc_weight(pairs)
    assert g._adaptive_sc_weight == 0.0
    assert result == 0.0


def test_calibrate_sc_weight_uses_only_first_20():
    g = AgentGuard()
    # first 20 correlated, rest anti-correlated -- result should be 0.1
    first20 = [(0.1 if l == 0 else 0.9, l) for l in ([0] * 10 + [1] * 10)]
    rest = [(0.9 if l == 0 else 0.1, l) for l in ([0] * 50 + [1] * 50)]
    result = g.calibrate_sc_weight(first20 + rest)
    assert g._adaptive_sc_weight == 0.1
    assert result == 0.1


# ── D2: enable_judge_routing() tests ─────────────────────────────────────────

def test_enable_judge_routing_sets_flag():
    g = AgentGuard()
    g.enable_judge_routing(openai_client=None)
    assert g._judge_routing_enabled is True


def test_judge_routing_task_type_stored():
    g = AgentGuard()
    g.enable_judge_routing()
    assert g._openai_client_for_routing is None


# ── D3: SemanticEntropyScorer tests ──────────────────────────────────────────

def test_semantic_entropy_scorer_basic():
    from llm_guard import SemanticEntropyScorer
    scorer = SemanticEntropyScorer()
    answers_diverse = ["Paris", "Berlin", "London", "Tokyo", "Sydney"]
    answers_same = ["Paris", "Paris", "Paris"]
    risk_diverse = scorer.score(answers_diverse)
    risk_same = scorer.score(answers_same)
    assert 0.0 <= risk_diverse <= 1.0
    assert risk_diverse > risk_same


def test_semantic_entropy_scorer_single():
    from llm_guard import SemanticEntropyScorer
    scorer = SemanticEntropyScorer()
    assert scorer.score(["Paris"]) == 0.5


# ── D4: RetrievalGroundingVerifier tests ──────────────────────────────────────

def test_retrieval_grounding_verifier_basic():
    from llm_guard import RetrievalGroundingVerifier
    v = RetrievalGroundingVerifier()
    answer = "The Eiffel Tower is in Paris, France."
    contexts = ["The Eiffel Tower is located in Paris.", "Paris is the capital of France."]
    result = v.verify(answer, contexts)
    assert 0.0 <= result.risk <= 1.0
    assert result.grounded is True


def test_retrieval_grounding_verifier_no_contexts():
    from llm_guard import RetrievalGroundingVerifier
    v = RetrievalGroundingVerifier()
    result = v.verify("Paris", [])
    assert result.risk == 0.5
    assert result.grounded is False


# ── D5: HalluFieldScorer tests ────────────────────────────────────────────────

def test_hallufield_scorer_experimental():
    from llm_guard import HalluFieldScorer
    scorer = HalluFieldScorer()
    assert scorer.experimental is True


def test_hallufield_scorer_high_risk():
    import math
    from llm_guard import HalluFieldScorer
    scorer = HalluFieldScorer()
    low_conf = [math.log(0.3)] * 5
    high_conf = [math.log(0.95)] * 5
    r_low = scorer.score_from_logprobs(low_conf)
    r_high = scorer.score_from_logprobs(high_conf)
    assert r_low.risk > r_high.risk
    assert 0.0 <= r_low.risk <= 1.0
