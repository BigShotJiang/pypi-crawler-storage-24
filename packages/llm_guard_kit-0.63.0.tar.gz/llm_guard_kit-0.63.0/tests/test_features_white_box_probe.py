"""tests/test_features_white_box_probe.py — Unit tests for WhiteBoxProbe."""
import pytest
import numpy as np

pytestmark = pytest.mark.unit


class TestImport:
    def test_import(self):
        from llm_guard.features.white_box_probe import WhiteBoxProbe
        assert WhiteBoxProbe is not None


class TestInstantiation:
    def test_construction_no_model_load(self):
        from llm_guard.features.white_box_probe import WhiteBoxProbe
        # Should not load a real model during __init__
        probe = WhiteBoxProbe.__new__(WhiteBoxProbe)
        assert probe is not None

    def test_default_attributes(self):
        from llm_guard.features.white_box_probe import WhiteBoxProbe
        from unittest.mock import patch, MagicMock
        # Patch the model loading to avoid downloading
        with patch.object(WhiteBoxProbe, "__init__", lambda self, **kw: None):
            probe = WhiteBoxProbe()
            probe._model = None
            probe._tokenizer = None
            probe._probe = None
            probe._fitted = False
        assert not probe._fitted

    def test_probe_ensemble_blend(self):
        from llm_guard.features.white_box_probe import probe_ensemble_blend
        result = probe_ensemble_blend(0.6, 0.7, alpha=0.25)
        expected = 0.25 * 0.6 + 0.75 * 0.7
        assert result == pytest.approx(expected, abs=1e-6)

    def test_probe_ensemble_blend_default_alpha(self):
        from llm_guard.features.white_box_probe import probe_ensemble_blend
        result = probe_ensemble_blend(0.5, 0.5)
        assert 0.0 <= result <= 1.0


class TestProbeEnsembleBlend:
    def test_alpha_zero_uses_ptrue_only(self):
        from llm_guard.features.white_box_probe import probe_ensemble_blend
        # alpha=0 → all ptrue
        result = probe_ensemble_blend(0.3, 0.8, alpha=0.0)
        assert result == pytest.approx(0.8, abs=1e-6)

    def test_alpha_one_uses_probe_only(self):
        from llm_guard.features.white_box_probe import probe_ensemble_blend
        # alpha=1 → all probe
        result = probe_ensemble_blend(0.3, 0.8, alpha=1.0)
        assert result == pytest.approx(0.3, abs=1e-6)

    def test_range(self):
        from llm_guard.features.white_box_probe import probe_ensemble_blend
        for ps, pt in [(0.0, 0.0), (1.0, 1.0), (0.3, 0.7), (0.8, 0.2)]:
            result = probe_ensemble_blend(ps, pt)
            assert 0.0 <= result <= 1.0
