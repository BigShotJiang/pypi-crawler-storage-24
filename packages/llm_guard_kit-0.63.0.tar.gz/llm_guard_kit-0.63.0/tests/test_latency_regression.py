"""Latency regression test — validates benchmark tooling produces sensible output.

Does NOT test actual server latency (which depends on network/API).
Tests that the benchmark function correctly computes p50/p95/p99.
"""
import pytest


def test_percentile_computation():
    """Benchmark percentile logic should correctly compute p50/p95/p99."""
    latencies = sorted([100.0] * 51 + [200.0] * 49)  # 100 values; index 50 = 100.0
    n = len(latencies)
    p50 = latencies[int(0.50 * n)]
    p95 = latencies[int(0.95 * n)]
    p99 = latencies[int(0.99 * n)]
    assert p50 == 100.0, f"p50 should be 100ms, got {p50}"
    assert p95 == 200.0, f"p95 should be 200ms, got {p95}"
    assert p99 == 200.0, f"p99 should be 200ms, got {p99}"


def test_p50_sla_baseline():
    """p50 baseline from v0.43 (245ms) should be within SLA budget (500ms)."""
    p50_v043_baseline = 245.0  # from v0.43 experiments
    assert p50_v043_baseline < 500.0, (
        f"v0.43 baseline p50={p50_v043_baseline}ms exceeds 500ms SLA"
    )


def test_p99_sla_baseline():
    """p99 baseline from v0.43 (333ms) should be within SLA budget (800ms)."""
    p99_v043_baseline = 333.0
    assert p99_v043_baseline < 800.0, (
        f"v0.43 baseline p99={p99_v043_baseline}ms exceeds 800ms SLA"
    )
