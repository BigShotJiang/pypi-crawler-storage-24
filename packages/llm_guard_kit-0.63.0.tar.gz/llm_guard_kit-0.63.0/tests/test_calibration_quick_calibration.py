"""tests/test_calibration_quick_calibration.py — Unit tests for llm_guard.calibration.quick_calibration."""
import pytest
from unittest.mock import MagicMock

pytestmark = pytest.mark.unit


def _make_chains(n=25):
    chains = []
    for i in range(n):
        chains.append({
            "question": f"Q{i}",
            "steps": [{"thought": "t", "action_type": "Search",
                        "observation": "obs", "action_arg": "q"}],
            "final_answer": f"A{i}",
            "correct": (i % 2 == 0),
        })
    return chains


class TestImport:
    def test_import(self):
        from llm_guard.calibration.quick_calibration import QuickCalibrator
        assert QuickCalibrator is not None


class TestInstantiation:
    def test_default_construction(self):
        from llm_guard.calibration.quick_calibration import QuickCalibrator
        cal = QuickCalibrator()
        assert cal._min_chains == 20
        assert not cal.is_fitted

    def test_custom_min_chains(self):
        from llm_guard.calibration.quick_calibration import QuickCalibrator
        cal = QuickCalibrator(min_chains=10)
        assert cal._min_chains == 10

    def test_domain_none_initially(self):
        from llm_guard.calibration.quick_calibration import QuickCalibrator
        cal = QuickCalibrator()
        assert cal.domain is None

    def test_min_chains_needed(self):
        from llm_guard.calibration.quick_calibration import QuickCalibrator
        cal = QuickCalibrator(min_chains=15)
        assert cal.min_chains_needed() == 15


class TestFit:
    def _make_fitted_cal(self, mock_guard=None):
        from llm_guard.calibration.quick_calibration import QuickCalibrator
        if mock_guard is None:
            mock_guard = MagicMock()
            mock_result = MagicMock()
            mock_result.behavioral_score = 0.5
            mock_guard.score_chain.return_value = mock_result
            mock_guard.calibrate_isotonic = MagicMock()
            mock_guard._iso_calibrator = None
        cal = QuickCalibrator(min_chains=20, guard=mock_guard)
        cal.fit(_make_chains(25), domain="test")
        return cal

    def test_fit_too_few_raises(self):
        from llm_guard.calibration.quick_calibration import QuickCalibrator
        cal = QuickCalibrator(min_chains=20)
        with pytest.raises(ValueError, match="20"):
            cal.fit(_make_chains(5))

    def test_fit_marks_fitted(self):
        cal = self._make_fitted_cal()
        assert cal.is_fitted

    def test_domain_set_after_fit(self):
        cal = self._make_fitted_cal()
        assert cal.domain == "test"

    def test_score_raises_before_fit(self):
        from llm_guard.calibration.quick_calibration import QuickCalibrator
        cal = QuickCalibrator(min_chains=20)
        with pytest.raises(RuntimeError):
            cal.score("Q", [], "A")

    def test_repr(self):
        from llm_guard.calibration.quick_calibration import QuickCalibrator
        cal = QuickCalibrator()
        r = repr(cal)
        assert "QuickCalibrator" in r
