"""tests/test_healing_debate_verifier.py — Unit tests for DebateVerifier."""
import pytest
import warnings
from unittest.mock import MagicMock, patch

pytestmark = pytest.mark.unit

QUESTION = "Who founded Apple?"
ANSWERS = ["Steve Jobs", "Tim Cook", "Bill Gates"]
EVIDENCES = ["Jobs co-founded Apple in 1976.", "", ""]


class TestImport:
    def test_import_verifier(self):
        from llm_guard.healing.debate_verifier import DebateVerifier
        assert DebateVerifier is not None

    def test_import_result(self):
        from llm_guard.healing.debate_verifier import DebateResult
        assert DebateResult is not None


class TestInstantiation:
    def test_no_key_construction(self):
        from llm_guard.healing.debate_verifier import DebateVerifier
        v = DebateVerifier(api_key="")
        assert v is not None

    def test_custom_threshold(self):
        from llm_guard.healing.debate_verifier import DebateVerifier
        v = DebateVerifier(api_key="", disagree_threshold=0.5)
        # disagree_threshold sets _thresh internally
        assert v._thresh == pytest.approx(0.5, abs=0.01)


class TestAgreement:
    def test_same_answers_agree(self):
        from llm_guard.healing.debate_verifier import DebateVerifier
        v = DebateVerifier(api_key="")
        result = v.verify(QUESTION, ["Paris", "Paris", "Paris"])
        assert result.debate_triggered is False
        assert result.routing == "trusted"
        assert result.confidence > 0.8

    def test_agree_returns_verdict_zero(self):
        from llm_guard.healing.debate_verifier import DebateVerifier
        v = DebateVerifier(api_key="")
        result = v.verify(QUESTION, ["Paris", "Paris"])
        assert result.verdict == 0

    def test_agree_risk_is_low(self):
        from llm_guard.healing.debate_verifier import DebateVerifier
        v = DebateVerifier(api_key="")
        result = v.verify(QUESTION, ["Same answer", "Same answer"])
        assert result.risk < 0.3


class TestDisagreementWithMockedAPI:
    def test_disagreement_triggers_debate(self):
        from llm_guard.healing.debate_verifier import DebateVerifier
        v = DebateVerifier(api_key="sk-ant-fake")
        # Force disagree: set thresh very high so mean F1 < thresh
        v._thresh = 1.0
        with patch.object(v, "_call_mediator", return_value=(1, 0.8, "Agent 1 has better evidence.")):
            result = v.verify(QUESTION, ANSWERS, EVIDENCES)
        assert result.debate_triggered is True

    def test_override_agent0_when_non_zero_verdict(self):
        from llm_guard.healing.debate_verifier import DebateVerifier
        v = DebateVerifier(api_key="sk-ant-fake")
        v._thresh = 1.0
        with patch.object(v, "_call_mediator", return_value=(1, 0.8, "Agent 1 has better evidence.")):
            result = v.verify(QUESTION, ANSWERS, EVIDENCES)
        if result.debate_triggered:
            assert result.override_agent0 == (result.verdict != 0)

    def test_risk_is_complement_of_confidence(self):
        from llm_guard.healing.debate_verifier import DebateVerifier
        v = DebateVerifier(api_key="sk-ant-fake")
        v._thresh = 1.0
        with patch.object(v, "_call_mediator", return_value=(1, 0.7, "Agent 1 wins.")):
            result = v.verify(QUESTION, ANSWERS, EVIDENCES)
        assert result.risk == pytest.approx(1.0 - result.confidence, abs=0.01)

    def test_n_agents_field(self):
        from llm_guard.healing.debate_verifier import DebateVerifier
        v = DebateVerifier(api_key="")
        result = v.verify(QUESTION, ["A", "A", "A"])  # agree case
        assert result.n_agents == 3


class TestDebateResult:
    def test_dataclass_fields(self):
        from llm_guard.healing.debate_verifier import DebateResult
        r = DebateResult(
            verdict=0, confidence=0.9, risk=0.1, routing="trusted",
            override_agent0=False, debate_triggered=False,
            reason="All agree.", n_agents=2
        )
        assert r.verdict == 0
        assert r.n_agents == 2
