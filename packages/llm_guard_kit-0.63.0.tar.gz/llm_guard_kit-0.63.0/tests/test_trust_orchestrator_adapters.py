"""tests/test_trust_orchestrator_adapters.py — Unit tests for AutoGenAdapter and CrewAIAdapter."""
import pytest
from unittest.mock import MagicMock

pytestmark = pytest.mark.unit

AUTOGEN_MESSAGES = [
    {"role": "assistant", "name": "SearchAgent", "content": "Let me search for this.",
     "tool_calls": [{"function": {"name": "search", "arguments": '{"query": "capital France"}'}}]},
    {"role": "tool", "name": "tool", "content": "Paris is the capital."},
    {"role": "assistant", "name": "SearchAgent", "content": "The answer is Paris."},
]


class TestImport:
    def test_import_autogen_adapter(self):
        from llm_guard.trust.orchestrator_adapters import AutoGenAdapter
        assert AutoGenAdapter is not None

    def test_import_crewai_adapter(self):
        from llm_guard.trust.orchestrator_adapters import CrewAIAdapter
        assert CrewAIAdapter is not None


class TestAutoGenAdapter:
    def _make_mock_guard(self):
        mock_guard = MagicMock()
        mock_result = MagicMock()
        mock_result.risk_score = 0.3
        mock_result.confidence_tier = "HIGH"
        mock_result.behavioral_score = 0.3
        mock_guard.score_chain.return_value = mock_result
        return mock_guard

    def test_instantiation(self):
        from llm_guard.trust.orchestrator_adapters import AutoGenAdapter
        guard = self._make_mock_guard()
        adapter = AutoGenAdapter(guard)
        assert adapter is not None

    def test_score_from_messages_returns_result(self):
        from llm_guard.trust.orchestrator_adapters import AutoGenAdapter
        guard = self._make_mock_guard()
        adapter = AutoGenAdapter(guard)
        result = adapter.score_from_messages(
            messages=AUTOGEN_MESSAGES,
            question="What is the capital of France?",
            final_answer="Paris",
        )
        assert result is not None
        assert hasattr(result, "risk_score")

    def test_to_trust_object(self):
        from llm_guard.trust.orchestrator_adapters import AutoGenAdapter
        from llm_guard.trust.trust_object import A2ATrustObject
        guard = self._make_mock_guard()
        adapter = AutoGenAdapter(guard)
        mock_result = MagicMock()
        mock_result.risk_score = 0.3
        mock_result.confidence_tier = "HIGH"
        mock_result.failure_mode = None
        mock_result.step_count = 2
        mock_result.judge_label = None
        trust = adapter.to_trust_object(mock_result, answer="Paris")
        assert isinstance(trust, A2ATrustObject)
        assert trust.answer == "Paris"

    def test_empty_messages(self):
        from llm_guard.trust.orchestrator_adapters import AutoGenAdapter
        guard = self._make_mock_guard()
        adapter = AutoGenAdapter(guard)
        result = adapter.score_from_messages(
            messages=[],
            question="Q?",
            final_answer="A",
        )
        assert result is not None


class TestCrewAIAdapter:
    def _make_mock_guard(self):
        mock_guard = MagicMock()
        mock_result = MagicMock()
        mock_result.risk_score = 0.4
        mock_result.confidence_tier = "MEDIUM"
        mock_result.behavioral_score = 0.4
        mock_guard.score_chain.return_value = mock_result
        return mock_guard

    def test_instantiation(self):
        from llm_guard.trust.orchestrator_adapters import CrewAIAdapter
        guard = self._make_mock_guard()
        adapter = CrewAIAdapter(guard)
        assert adapter is not None

    def test_score_from_task_output_dict(self):
        from llm_guard.trust.orchestrator_adapters import CrewAIAdapter
        guard = self._make_mock_guard()
        adapter = CrewAIAdapter(guard)
        task_output = {
            "output": "The answer is 42.",
            "steps": [{"thought": "thinking", "action_type": "Search",
                       "action_arg": "query", "observation": "result"}],
        }
        result = adapter.score_from_task_output(
            task_output, question="What is the answer?"
        )
        assert result is not None

    def test_to_trust_object(self):
        from llm_guard.trust.orchestrator_adapters import CrewAIAdapter
        from llm_guard.trust.trust_object import A2ATrustObject
        guard = self._make_mock_guard()
        adapter = CrewAIAdapter(guard)
        mock_result = MagicMock()
        mock_result.risk_score = 0.4
        mock_result.confidence_tier = "MEDIUM"
        mock_result.failure_mode = None
        mock_result.step_count = 1
        mock_result.judge_label = None
        trust = adapter.to_trust_object(mock_result, answer="42")
        assert isinstance(trust, A2ATrustObject)
