"""tests/test_trust_trust_object.py — Unit tests for A2ATrustObject and TrustHop."""
import pytest

pytestmark = pytest.mark.unit


def _make_trust():
    from llm_guard.trust.trust_object import A2ATrustObject
    return A2ATrustObject(
        answer="Paris",
        risk_score=0.3,
        confidence_tier="HIGH",
        failure_mode=None,
        step_count=2,
        judge_label="GOOD",
        downstream_hint="proceed",
        should_rewrite=False,
    )


class TestImport:
    def test_import_trust_object(self):
        from llm_guard.trust.trust_object import A2ATrustObject
        assert A2ATrustObject is not None

    def test_import_trust_hop(self):
        from llm_guard.trust.trust_object import TrustHop
        assert TrustHop is not None

    def test_import_temporal_validity(self):
        from llm_guard.trust.trust_object import TemporalValidity
        assert TemporalValidity is not None


class TestA2ATrustObjectCreation:
    def test_basic_fields(self):
        t = _make_trust()
        assert t.answer == "Paris"
        assert t.risk_score == 0.3
        assert t.confidence_tier == "HIGH"

    def test_should_rewrite_high(self):
        t = _make_trust()
        assert t.should_rewrite is False

    def test_should_rewrite_low(self):
        from llm_guard.trust.trust_object import A2ATrustObject
        t = A2ATrustObject(
            answer="?", risk_score=0.8, confidence_tier="LOW",
            failure_mode="retrieval_fail", step_count=5,
            judge_label=None, downstream_hint="rewrite_query",
            should_rewrite=True,
        )
        assert t.should_rewrite is True


class TestSerialisation:
    def test_to_dict(self):
        t = _make_trust()
        d = t.to_dict()
        assert isinstance(d, dict)
        assert "risk_score" in d
        assert "confidence_tier" in d

    def test_from_dict_roundtrip(self):
        from llm_guard.trust.trust_object import A2ATrustObject
        t = _make_trust()
        d = t.to_dict()
        t2 = A2ATrustObject.from_dict(d)
        assert t2.risk_score == t.risk_score
        assert t2.confidence_tier == t.confidence_tier
        assert t2.answer == t.answer


class TestTrustHop:
    def test_basic_creation(self):
        from llm_guard.trust.trust_object import TrustHop
        hop = TrustHop(agent_id="agent-1", risk_score=0.4, timestamp=1234567890.0)
        assert hop.agent_id == "agent-1"
        assert hop.risk_score == 0.4

    def test_to_dict(self):
        from llm_guard.trust.trust_object import TrustHop
        hop = TrustHop(agent_id="a1", risk_score=0.5, timestamp=1000.0)
        d = hop.to_dict()
        assert d["agent_id"] == "a1"
        assert d["risk_score"] == 0.5

    def test_from_dict(self):
        from llm_guard.trust.trust_object import TrustHop
        d = {"agent_id": "a2", "risk_score": 0.7, "timestamp": 2000.0}
        hop = TrustHop.from_dict(d)
        assert hop.agent_id == "a2"


class TestAddHopAndVerify:
    def test_add_hop(self):
        from llm_guard.trust.trust_object import A2ATrustObject
        t = _make_trust()
        t.add_hop("agent-2", secret="test-key")
        assert len(t.trust_chain) == 1
        assert t.trust_chain[0].agent_id == "agent-2"

    def test_verify_chain_valid(self):
        from llm_guard.trust.trust_object import A2ATrustObject
        t = _make_trust()
        t.add_hop("agent-2", secret="test-key")
        valid = t.verify_chain({"agent-2": "test-key"})
        assert valid is True

    def test_verify_chain_wrong_key(self):
        from llm_guard.trust.trust_object import A2ATrustObject
        t = _make_trust()
        t.add_hop("agent-2", secret="correct-key")
        valid = t.verify_chain({"agent-2": "wrong-key"})
        assert valid is False


class TestTemporalValidity:
    def test_default_not_sensitive(self):
        from llm_guard.trust.trust_object import TemporalValidity
        tv = TemporalValidity()
        assert not tv.is_time_sensitive
        assert tv.tv_risk == 0.0

    def test_to_from_dict(self):
        from llm_guard.trust.trust_object import TemporalValidity
        tv = TemporalValidity(is_time_sensitive=True, tv_risk=0.6)
        tv2 = TemporalValidity.from_dict(tv.to_dict())
        assert tv2.is_time_sensitive is True
        assert tv2.tv_risk == pytest.approx(0.6)
