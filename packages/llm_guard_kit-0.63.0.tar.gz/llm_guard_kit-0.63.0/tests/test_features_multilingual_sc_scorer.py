"""tests/test_features_multilingual_sc_scorer.py — Unit tests for MultilingualSCScorer."""
import pytest
import numpy as np
from unittest.mock import MagicMock, patch

pytestmark = pytest.mark.unit

CHAINS = [
    {"question": f"Q{i}", "steps": [
        {"action_type": "Search", "observation": f"obs {i}"}
    ], "final_answer": f"A{i}"}
    for i in range(15)
]
LABELS = np.array([i % 2 for i in range(15)], dtype=np.int64)


class TestImport:
    def test_import(self):
        from llm_guard.features.multilingual_sc_scorer import MultilingualSCScorer
        assert MultilingualSCScorer is not None


class TestInstantiation:
    def test_construction(self):
        from llm_guard.features.multilingual_sc_scorer import MultilingualSCScorer
        scorer = MultilingualSCScorer(model_path="fake-model")
        assert scorer.model_path == "fake-model"
        assert not scorer.is_fitted

    def test_custom_c(self):
        from llm_guard.features.multilingual_sc_scorer import MultilingualSCScorer
        scorer = MultilingualSCScorer(model_path="x", C=0.5)
        assert scorer.C == 0.5

    def test_unfitted_raises(self):
        from llm_guard.features.multilingual_sc_scorer import MultilingualSCScorer
        scorer = MultilingualSCScorer(model_path="fake-model")
        with pytest.raises(RuntimeError):
            scorer.score_chain(CHAINS[0])


class TestFitAndScore:
    def _make_mock_extractor(self):
        mock_ext = MagicMock()
        mock_ext.extract_features.return_value = np.random.randn(12).astype(float)
        return mock_ext

    def test_fit_marks_fitted(self):
        from llm_guard.features.multilingual_sc_scorer import MultilingualSCScorer
        scorer = MultilingualSCScorer(model_path="fake-model")
        mock_ext = self._make_mock_extractor()
        with patch.object(scorer, "_get_extractor", return_value=mock_ext):
            scorer.fit(CHAINS, LABELS)
        assert scorer.is_fitted

    def test_score_chain_range(self):
        from llm_guard.features.multilingual_sc_scorer import MultilingualSCScorer
        scorer = MultilingualSCScorer(model_path="fake-model")
        mock_ext = self._make_mock_extractor()
        with patch.object(scorer, "_get_extractor", return_value=mock_ext):
            scorer.fit(CHAINS, LABELS)
            risk = scorer.score_chain(CHAINS[0])
        assert 0.0 <= risk <= 1.0

    def test_extract_features_shape(self):
        from llm_guard.features.multilingual_sc_scorer import MultilingualSCScorer
        scorer = MultilingualSCScorer(model_path="fake-model")
        mock_ext = self._make_mock_extractor()
        with patch.object(scorer, "_get_extractor", return_value=mock_ext):
            feat = scorer.extract_features(CHAINS[0])
        assert feat.shape == (12,)
