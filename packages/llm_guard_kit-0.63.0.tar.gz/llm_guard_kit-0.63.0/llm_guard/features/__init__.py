"""Feature extraction components for llm-guard-kit."""

from llm_guard.features.mechanism_layer import (
    FEATURE_NAMES,
    PHASE_B_FEATURE_NAMES,
    tokenize,
    vocab_entropy,
    MechanismFeatureExtractor,
    load_halueval_qa,
    load_halueval_summarization,
    load_halueval_dialogue,
    load_truthfulqa,
    load_sycophancy,
    load_pubmed_qa,
    load_quality_context_drift,
    load_arc_research,
    EnsembleMechanismClassifier,
    SemanticConsistencyChecker,
    bootstrap_ci,
    run_cv_experiment,
)
from llm_guard.features.multilingual_sc_scorer import MultilingualSCScorer
from llm_guard.features.step_extractor import (
    StepExtractor,
    LLMReActExtractor,
)
from llm_guard.features.step_normalizer import (
    normalize_steps,
    validate_step_coverage,
)
from llm_guard.features.step_transformer import (
    encode_step,
    StepTransformerVerifier,
)
from llm_guard.features.tool_call_extractor import ToolCallExtractor
from llm_guard.features.visual_caption_bridge import VisualCaptionBridge
from llm_guard.features.white_box_probe import (
    ProbeResult,
    WhiteBoxProbe,
    probe_ensemble_blend,
)

# MECHANISM_FEATURE_NAMES is an alias for FEATURE_NAMES (exported from memory notes)
MECHANISM_FEATURE_NAMES = FEATURE_NAMES

__all__ = [
    "FEATURE_NAMES",
    "MECHANISM_FEATURE_NAMES",
    "PHASE_B_FEATURE_NAMES",
    "tokenize",
    "vocab_entropy",
    "MechanismFeatureExtractor",
    "load_halueval_qa",
    "load_halueval_summarization",
    "load_halueval_dialogue",
    "load_truthfulqa",
    "load_sycophancy",
    "load_pubmed_qa",
    "load_quality_context_drift",
    "load_arc_research",
    "EnsembleMechanismClassifier",
    "SemanticConsistencyChecker",
    "bootstrap_ci",
    "run_cv_experiment",
    "MultilingualSCScorer",
    "StepExtractor",
    "LLMReActExtractor",
    "normalize_steps",
    "validate_step_coverage",
    "encode_step",
    "StepTransformerVerifier",
    "ToolCallExtractor",
    "VisualCaptionBridge",
    "ProbeResult",
    "WhiteBoxProbe",
    "probe_ensemble_blend",
]
