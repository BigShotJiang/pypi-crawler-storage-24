"""
llm_guard_mcp — MCP server for llm-guard-kit
Exposes AgentGuard scoring, metrics tracking, and RL feedback loop
as Claude/Cursor tools via Model Context Protocol.
"""

__version__ = "0.1.0"
