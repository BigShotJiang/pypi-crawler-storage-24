# /sm-buff

Triage CI results and review feedback for a pull request.

Usage: Run `sm buff <PR_NUMBER>` after CI completes or review feedback lands.

1. Run `sm buff <PR_NUMBER>`.
2. Summarize what passed, what failed, and what needs attention.
3. Propose a concrete remediation plan for each actionable item.

This converts raw feedback into your next set of tasks. Never mark a failing check as resolved without actually fixing it.
