# Code Audit Lab SaaS Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Launch codeauditlab.com — a SaaS wrapper around isologic that lets users scan GitHub repos for EU AI Act compliance from the browser, get compliance scores, generate PDF reports, and embed badges.

**Architecture:** FastAPI backend wrapping the isologic Python scanner. Static HTML/Tailwind/Alpine.js frontend served by nginx. PostgreSQL (Docker) for scan history/users. Stripe for payments. Nginx reverse proxy on OVH (51.210.24.170), DNS via Cloudflare.

**Tech Stack:** Python 3.12, FastAPI, isologic (existing), PostgreSQL, Docker, Tailwind CSS, Alpine.js, Stripe, WeasyPrint (PDF), nginx, Cloudflare DNS

---

## Phase 1: Infrastructure (Tasks 1-3)

### Task 1: DNS + Nginx Setup

**Files:**
- Create: `/etc/nginx/sites-available/codeauditlab` (on OVH)

**Step 1: Add codeauditlab.com to Cloudflare**

In Namecheap, change nameservers to Cloudflare. Then in Cloudflare:
- A record: `codeauditlab.com` → `51.210.24.170` (proxied)
- A record: `www.codeauditlab.com` → `51.210.24.170` (proxied)
- SSL mode: Full

**Step 2: Create nginx server block on OVH**

```bash
ssh root@51.210.24.170
```

Create `/etc/nginx/sites-available/codeauditlab`:
```nginx
server {
    listen 80;
    listen 443 ssl;
    server_name codeauditlab.com www.codeauditlab.com;

    ssl_certificate /etc/nginx/ssl/origin.crt;
    ssl_certificate_key /etc/nginx/ssl/origin.key;

    # Frontend static files
    root /opt/codeauditlab/frontend;
    index index.html;

    # API proxy
    location /api/ {
        proxy_pass http://127.0.0.1:8090/api/;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 120s;
    }

    # Badge SVGs
    location /badge/ {
        proxy_pass http://127.0.0.1:8090/badge/;
        proxy_cache_valid 200 5m;
    }

    # Frontend SPA fallback
    location / {
        try_files $uri $uri/ /index.html;
    }
}
```

**Step 3: Enable site and reload nginx**

```bash
ln -s /etc/nginx/sites-available/codeauditlab /etc/nginx/sites-enabled/
nginx -t && systemctl reload nginx
```

**Step 4: Verify**

```bash
curl -I https://codeauditlab.com
```
Expected: 200 or 301 (once Cloudflare propagates)

**Step 5: Commit** (local repo)

```bash
git add -A && git commit -m "infra: nginx config for codeauditlab.com on OVH"
```

---

### Task 2: Project Structure + Database

**Files:**
- Create: `/opt/codeauditlab/` directory structure on OVH
- Create: `docker-compose.yml` (PostgreSQL)
- Create: `backend/requirements.txt`
- Create: `backend/app/__init__.py`

**Step 1: Create project structure on OVH**

```bash
ssh root@51.210.24.170
mkdir -p /opt/codeauditlab/{backend/app,frontend,data}
cd /opt/codeauditlab
```

**Step 2: Create docker-compose.yml for PostgreSQL**

```yaml
services:
  db:
    image: postgres:16-alpine
    container_name: codeauditlab-db
    restart: unless-stopped
    environment:
      POSTGRES_DB: codeauditlab
      POSTGRES_USER: codeauditlab
      POSTGRES_PASSWORD: CAL_db_2026_secure!
    volumes:
      - ./data/postgres:/var/lib/postgresql/data
    ports:
      - "127.0.0.1:5434:5432"
```

**Step 3: Start database**

```bash
cd /opt/codeauditlab && docker compose up -d
```

**Step 4: Create requirements.txt**

```
fastapi>=0.115.0
uvicorn[standard]>=0.34.0
sqlalchemy>=2.0
asyncpg>=0.30.0
psycopg2-binary>=2.9
python-multipart>=0.0.18
httpx>=0.28.0
weasyprint>=63.0
stripe>=11.0.0
click>=8.0
rich>=13.0
pydantic>=2.0
python-dotenv>=1.0
```

**Step 5: Create Python venv and install**

```bash
cd /opt/codeauditlab/backend
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

**Step 6: Copy isologic source into backend**

```bash
# From local machine:
scp -r local-projects/isologic/src/isologic root@51.210.24.170:/opt/codeauditlab/backend/app/isologic
```

**Step 7: Commit**

```bash
git add -A && git commit -m "infra: project structure, database, dependencies"
```

---

### Task 3: FastAPI Backend Core

**Files:**
- Create: `backend/app/main.py`
- Create: `backend/app/models.py`
- Create: `backend/app/schemas.py`
- Create: `backend/app/database.py`
- Create: `backend/.env`

**Step 1: Write database models (`backend/app/database.py`)**

```python
"""Database connection and session management."""
import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, DeclarativeBase
from dotenv import load_dotenv

load_dotenv()

DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql://codeauditlab:CAL_db_2026_secure!@127.0.0.1:5434/codeauditlab"
)

engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(bind=engine)


class Base(DeclarativeBase):
    pass


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
```

**Step 2: Write models (`backend/app/models.py`)**

```python
"""SQLAlchemy models."""
from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, Text, DateTime, JSON, Float
from app.database import Base


class Scan(Base):
    __tablename__ = "scans"

    id = Column(Integer, primary_key=True, autoincrement=True)
    repo_url = Column(String(500), nullable=True)
    repo_name = Column(String(200), nullable=True)
    scan_hash = Column(String(64), unique=True, index=True)
    files_scanned = Column(Integer, default=0)
    compliance_score = Column(Float, nullable=True)
    summary = Column(JSON, nullable=True)
    classifications = Column(JSON, nullable=True)
    frameworks_detected = Column(JSON, nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    ip_address = Column(String(45), nullable=True)
    is_paid = Column(Integer, default=0)
```

**Step 3: Write schemas (`backend/app/schemas.py`)**

```python
"""Pydantic request/response schemas."""
from pydantic import BaseModel


class ScanRequest(BaseModel):
    repo_url: str


class ScanResponse(BaseModel):
    scan_id: str
    repo_name: str
    files_scanned: int
    compliance_score: float
    summary: dict
    classifications: list[dict]
    frameworks_detected: dict
    deadline_days: int
    badge_url: str

    class Config:
        from_attributes = True
```

**Step 4: Write main app (`backend/app/main.py`)**

```python
"""Code Audit Lab — FastAPI backend."""
from __future__ import annotations

import hashlib
import os
import shutil
import subprocess
import tempfile
from datetime import datetime, timezone
from pathlib import Path

from fastapi import FastAPI, HTTPException, Request, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response
from sqlalchemy.orm import Session

from app.database import Base, engine, get_db
from app.models import Scan
from app.schemas import ScanRequest, ScanResponse

# Import isologic scanner
from app.isologic.scanner import scan
from app.isologic.classifier import classify, RiskLevel

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Code Audit Lab", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://codeauditlab.com", "https://www.codeauditlab.com"],
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

DEADLINE = datetime(2026, 8, 2, tzinfo=timezone.utc)


def _days_until_deadline() -> int:
    delta = DEADLINE - datetime.now(timezone.utc)
    return max(0, delta.days)


def _compliance_score(summary: dict) -> float:
    """Calculate 0-100 compliance score. Higher = more compliant."""
    weights = {"unacceptable": -50, "high": -20, "limited": -5, "gpai": -3, "minimal": 0, "unknown": -10}
    total_systems = sum(summary.values()) or 1
    penalty = sum(summary.get(level, 0) * w for level, w in weights.items())
    score = max(0, min(100, 100 + (penalty / total_systems)))
    return round(score, 1)


def _clone_repo(repo_url: str) -> Path:
    """Clone a public GitHub repo to a temp directory."""
    tmp = Path(tempfile.mkdtemp(prefix="cal_"))
    try:
        subprocess.run(
            ["git", "clone", "--depth=1", "--single-branch", repo_url, str(tmp / "repo")],
            capture_output=True, text=True, timeout=60, check=True,
        )
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as e:
        shutil.rmtree(tmp, ignore_errors=True)
        raise HTTPException(status_code=400, detail=f"Could not clone repo: {e}")
    return tmp / "repo"


@app.get("/api/health")
async def health():
    return {"status": "ok", "deadline_days": _days_until_deadline()}


@app.post("/api/scan", response_model=ScanResponse)
async def scan_repo(req: ScanRequest, request: Request, db: Session = Depends(get_db)):
    repo_url = req.repo_url.strip()

    # Validate URL
    if not repo_url.startswith(("https://github.com/", "https://gitlab.com/")):
        raise HTTPException(400, "Only public GitHub/GitLab repos supported")

    # Extract repo name
    parts = repo_url.rstrip("/").split("/")
    repo_name = f"{parts[-2]}/{parts[-1]}" if len(parts) >= 2 else repo_url

    # Check cache
    scan_hash = hashlib.sha256(repo_url.encode()).hexdigest()[:16]
    existing = db.query(Scan).filter_by(scan_hash=scan_hash).first()
    if existing:
        return ScanResponse(
            scan_id=existing.scan_hash,
            repo_name=existing.repo_name,
            files_scanned=existing.files_scanned,
            compliance_score=existing.compliance_score,
            summary=existing.summary,
            classifications=existing.classifications,
            frameworks_detected=existing.frameworks_detected,
            deadline_days=_days_until_deadline(),
            badge_url=f"https://codeauditlab.com/badge/{existing.scan_hash}.svg",
        )

    # Clone and scan
    repo_path = _clone_repo(repo_url)
    try:
        scan_result = scan(repo_path, max_files=10_000)
        report = classify(scan_result)

        summary = {level.value: count for level, count in report.summary.items()}
        classifications_data = [
            {
                "file": c.detection.file.replace(str(repo_path), ""),
                "line": c.detection.line,
                "framework": c.detection.framework,
                "description": c.detection.description,
                "risk_level": c.risk_level.value,
                "annex": c.annex,
                "reason": c.reason,
                "obligations": c.obligations,
                "deadline": c.deadline,
            }
            for c in report.classifications
        ]
        score = _compliance_score(summary)

        # Save to DB
        db_scan = Scan(
            repo_url=repo_url,
            repo_name=repo_name,
            scan_hash=scan_hash,
            files_scanned=scan_result.files_scanned,
            compliance_score=score,
            summary=summary,
            classifications=classifications_data,
            frameworks_detected=scan_result.frameworks,
            ip_address=request.client.host if request.client else None,
        )
        db.add(db_scan)
        db.commit()

        return ScanResponse(
            scan_id=scan_hash,
            repo_name=repo_name,
            files_scanned=scan_result.files_scanned,
            compliance_score=score,
            summary=summary,
            classifications=classifications_data,
            frameworks_detected=scan_result.frameworks,
            deadline_days=_days_until_deadline(),
            badge_url=f"https://codeauditlab.com/badge/{scan_hash}.svg",
        )
    finally:
        shutil.rmtree(repo_path.parent, ignore_errors=True)


@app.get("/badge/{scan_hash}.svg")
async def get_badge(scan_hash: str, db: Session = Depends(get_db)):
    """Generate compliance badge SVG."""
    existing = db.query(Scan).filter_by(scan_hash=scan_hash).first()
    if not existing:
        raise HTTPException(404, "Scan not found")

    score = existing.compliance_score
    if score >= 80:
        color = "#4c1"
        label = "Compliant"
    elif score >= 50:
        color = "#dfb317"
        label = "Needs Review"
    else:
        color = "#e05d44"
        label = "High Risk"

    svg = f'''<svg xmlns="http://www.w3.org/2000/svg" width="220" height="20">
  <linearGradient id="b" x2="0" y2="100%">
    <stop offset="0" stop-color="#bbb" stop-opacity=".1"/>
    <stop offset="1" stop-opacity=".1"/>
  </linearGradient>
  <mask id="a"><rect width="220" height="20" rx="3" fill="#fff"/></mask>
  <g mask="url(#a)">
    <rect width="120" height="20" fill="#555"/>
    <rect x="120" width="100" height="20" fill="{color}"/>
    <rect width="220" height="20" fill="url(#b)"/>
  </g>
  <g fill="#fff" text-anchor="middle" font-family="DejaVu Sans,sans-serif" font-size="11">
    <text x="60" y="14">EU AI Act</text>
    <text x="170" y="14">{label} {score:.0f}/100</text>
  </g>
</svg>'''

    return Response(content=svg, media_type="image/svg+xml",
                    headers={"Cache-Control": "public, max-age=300"})


@app.get("/api/stats")
async def stats(db: Session = Depends(get_db)):
    """Public stats for landing page."""
    total = db.query(Scan).count()
    return {
        "total_scans": total,
        "deadline_days": _days_until_deadline(),
    }
```

**Step 5: Create .env file**

```bash
DATABASE_URL=postgresql://codeauditlab:CAL_db_2026_secure!@127.0.0.1:5434/codeauditlab
STRIPE_SECRET_KEY=sk_test_placeholder
STRIPE_PRICE_REPORT=price_placeholder
```

**Step 6: Test the API starts**

```bash
cd /opt/codeauditlab/backend
source .venv/bin/activate
uvicorn app.main:app --host 127.0.0.1 --port 8090 --reload
```

Test: `curl http://127.0.0.1:8090/api/health`
Expected: `{"status":"ok","deadline_days":145}`

**Step 7: Create systemd service**

Create `/etc/systemd/system/codeauditlab.service`:
```ini
[Unit]
Description=Code Audit Lab API
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/codeauditlab/backend
Environment=PATH=/opt/codeauditlab/backend/.venv/bin:/usr/local/bin:/usr/bin
ExecStart=/opt/codeauditlab/backend/.venv/bin/uvicorn app.main:app --host 127.0.0.1 --port 8090 --workers 2
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

```bash
systemctl daemon-reload && systemctl enable --now codeauditlab
```

**Step 8: Commit**

```bash
git add -A && git commit -m "feat: FastAPI backend with scan, badge, and stats endpoints"
```

---

## Phase 2: Landing Page (Task 4)

### Task 4: Frontend Landing Page

**Files:**
- Create: `frontend/index.html`
- Create: `frontend/styles.css` (Tailwind via CDN)

**Step 1: Create landing page**

Create `frontend/index.html` — single HTML file with Tailwind CDN + Alpine.js:

Key sections:
1. **Hero** — "Scan your codebase for EU AI Act compliance" + GitHub URL input + "Scan Now" button
2. **Countdown** — "XX days until Aug 2, 2026 deadline. EUR 35M fines."
3. **How it works** — 3-step: Paste URL → Get risk classification → Generate compliance docs
4. **Live scan results** — appears after scanning, shows risk summary table, compliance score, frameworks detected, classifications
5. **Pricing** — Free (CLI) / Pro $29/mo / Team $99/mo / Enterprise
6. **Stats** — "X repos scanned" (from /api/stats)
7. **Footer** — GitHub link, pip install, Apache 2.0

Alpine.js handles:
- Form submission → POST /api/scan
- Loading spinner during scan
- Results display
- Countdown timer calculation

**Step 2: Deploy to OVH**

```bash
scp -r frontend/* root@51.210.24.170:/opt/codeauditlab/frontend/
```

**Step 3: Verify**

Visit `https://codeauditlab.com` — should show landing page.

**Step 4: Commit**

```bash
git add -A && git commit -m "feat: landing page with scan form, countdown, pricing"
```

---

## Phase 3: Enhancements (Tasks 5-7)

### Task 5: PDF Compliance Report Generator

**Files:**
- Create: `backend/app/pdf_report.py`
- Modify: `backend/app/main.py` — add `/api/report/{scan_hash}/pdf` endpoint

**Step 1: Write PDF generator using WeasyPrint**

Generates a branded PDF with:
- Code Audit Lab header + logo
- Compliance score badge
- Risk summary table
- Detailed classifications
- Obligation checklists
- EU AI Act article references
- Timestamp + scan hash for authenticity

**Step 2: Add endpoint**

```python
@app.get("/api/report/{scan_hash}/pdf")
async def download_pdf(scan_hash: str, db: Session = Depends(get_db)):
    # ... generate PDF, return as download
```

**Step 3: Commit**

```bash
git add -A && git commit -m "feat: PDF compliance report generator"
```

---

### Task 6: Compliance Score in CLI

**Files:**
- Modify: `src/isologic/cli.py` — add `--score` flag and countdown timer
- Modify: `src/isologic/reporter.py` — add score calculation + countdown display

**Step 1: Add compliance score calculation to reporter**

Same algorithm as backend `_compliance_score()`.

**Step 2: Add countdown to terminal output**

Show "XX days until Aug 2, 2026 — high-risk AI system rules enforceable" in footer.

**Step 3: Add `isologic badge` command**

Generates SVG badge file or prints badge URL if scan was uploaded.

**Step 4: Commit**

```bash
git add -A && git commit -m "feat: compliance score + countdown in CLI output"
```

---

### Task 7: Systemd + Monitoring

**Files:**
- Create: `scripts/deploy.sh` — deployment script
- Create: `scripts/backup-db.sh` — database backup

**Step 1: Create deploy script**

```bash
#!/bin/bash
# Deploy Code Audit Lab
cd /opt/codeauditlab
git pull
cd backend && source .venv/bin/activate && pip install -r requirements.txt
systemctl restart codeauditlab
echo "Deployed at $(date)"
```

**Step 2: Create DB backup cron**

```bash
0 3 * * * pg_dump -h 127.0.0.1 -p 5434 -U codeauditlab codeauditlab | gzip > /opt/codeauditlab/data/backups/cal-$(date +\%Y\%m\%d).sql.gz
```

**Step 3: Commit**

```bash
git add -A && git commit -m "ops: deploy script and database backups"
```

---

## Execution Order

| # | Task | Time | Dependencies |
|---|------|------|-------------|
| 1 | DNS + Nginx | 15min | None |
| 2 | Project Structure + DB | 15min | None |
| 3 | FastAPI Backend | 30min | Task 2 |
| 4 | Landing Page | 30min | Task 1, 3 |
| 5 | PDF Reports | 20min | Task 3 |
| 6 | CLI Score + Countdown | 15min | None |
| 7 | Deploy + Monitoring | 10min | Task 3 |

**Total: ~2.5 hours to MVP live at codeauditlab.com**

Tasks 1+2 can run in parallel. Task 6 is independent.
