# CodeAuditLab / Isologic Launch Content

*Ready to copy-paste. All stats verified against real scan data.*

---

## 1. Hacker News -- Show HN

### Title (78 chars)

```
Show HN: Isologic -- Scan your codebase for EU AI Act compliance in one command
```

### Body

```
Hey HN,

I built isologic, an open-source CLI tool that scans your codebase and tells you which of your AI systems fall under the EU AI Act, what risk category they're in, and what you need to do about it.

    pip install isologic && isologic audit .

It walks your Python/JS/TS files, config files, and dependency manifests, matches against 60+ regex patterns for AI frameworks (OpenAI, Anthropic, HuggingFace, LangChain, PyTorch, TensorFlow, etc.) and use cases (recruitment AI, credit scoring, biometrics, medical diagnosis, etc.), then classifies each detection by EU AI Act risk level: unacceptable, high, limited, GPAI, or minimal.

I ran it against huggingface/transformers: 4,175 files scanned, 5,275 AI system detections, 93.7 compliance score. The full result is on codeauditlab.com if you want to see what a real scan looks like.

Some context on why this matters right now:

- Prohibited AI practices (social scoring, workplace emotion recognition) are already enforceable since Feb 2, 2025. Fines: EUR 35M or 7% of global turnover.
- High-risk AI system requirements (recruitment, credit scoring, medical, education, law enforcement) hit Aug 2, 2026 -- 143 days from today.
- GPAI model obligations have been in effect since Aug 2, 2025.

No code leaves your machine. No AI APIs called. Pure static analysis using regex pattern matching. Exit codes work in CI (0 = clean, 1 = high-risk found, 2 = prohibited practice found), so you can gate deployments on compliance.

Limitations I want to be upfront about: it's pattern-based, not AST analysis, so there will be false positives. It can't determine deployment context from code alone. A `face_recognition` import might be for unlocking your phone (minimal risk) or for public surveillance (prohibited). The tool flags it; you decide.

Open source, Apache 2.0: https://github.com/masterkenai121/isologic

The web scanner is at codeauditlab.com -- paste any public GitHub/GitLab URL and get instant risk classification + a compliance badge for your README.

Happy to answer questions about the EU AI Act classification logic or the detection patterns.
```

---

## 2. Dev.to Article

### Title

```
Your AI Code Has 143 Days to Comply with the EU AI Act. Here's How to Check.
```

### Tags

```
ai, opensource, python, compliance
```

### Article Body

```markdown
The EU AI Act (Regulation 2024/1689) is not a proposal. It is law. And the clock is ticking.

**Feb 2, 2025** -- Prohibited AI practices became enforceable. If your code does real-time biometric identification in public spaces, social scoring, or workplace emotion recognition, you are already in violation. Penalties: up to EUR 35 million or 7% of global annual turnover, whichever is higher.

**Aug 2, 2025** -- GPAI (General-Purpose AI) model obligations took effect. If you're building on OpenAI, Anthropic, Gemini, or any foundation model, you have transparency and documentation requirements right now.

**Aug 2, 2026** -- High-risk AI system requirements become enforceable. That's 143 days away. If your AI touches recruitment, credit scoring, medical diagnosis, education assessment, or law enforcement, you need conformity assessments, quality management systems, CE marking, and EU database registration. Ready?

Most engineering teams I've talked to have a vague awareness that "something about EU AI regulation is happening" and zero inventory of which of their systems are actually affected. That's what I built isologic to fix.

## What is isologic?

isologic is an open-source Python CLI that scans your codebase and classifies every detected AI system by EU AI Act risk level. One command, no cloud, no signup:

```bash
pip install isologic
isologic audit .
```

Here's what the output looks like:

```
$ isologic audit ./my-project

+-- isologic audit --+
| Files scanned: 847 |
+--------------------+

       Risk Summary
+--------------+-------+----------------------------------+
| Risk Level   | Count | Status                           |
+--------------+-------+----------------------------------+
| HIGH         |     2 | Conformity assessment required   |
| GPAI         |     3 | GPAI obligations (Articles 51-56)|
| LIMITED      |     1 | Transparency obligations apply   |
| MINIMAL      |     1 | No mandatory obligations         |
+--------------+-------+----------------------------------+
```

Each detection includes the specific EU AI Act article/annex reference, a checklist of obligations, and the enforcement deadline.

## Real-world example: huggingface/transformers

I pointed isologic at the huggingface/transformers repository:

- **4,175 files** scanned
- **5,275 AI system detections** across Python files, configs, and dependency manifests
- **93.7 compliance score** (out of 100)
- Detected frameworks: HuggingFace Transformers, PyTorch, TensorFlow, OpenAI, and more
- Risk classifications: GPAI obligations for the core framework, plus use-case detections for content generation, retrieval systems, and image generation

That score is high because transformers is a general-purpose library, not a deployment of a high-risk application. Your recruitment-ranking microservice would score very differently.

## How it works

isologic uses static analysis with 60+ regex patterns across three categories:

1. **Framework detection** -- Python imports (`from openai import ...`), JS/TS imports (`import "@anthropic-ai/sdk"`), and client instantiations (`Anthropic()`, `OpenAI()`) for 30+ frameworks
2. **Use-case detection** -- Patterns that indicate specific high-risk applications: `resume_parser`, `credit_score`, `face_recognition`, `emotion_detect`, `medical_diagnos`, etc.
3. **Dependency scanning** -- Checks `requirements.txt`, `package.json`, `pyproject.toml`, and `Pipfile` for AI package dependencies

Use-case detections always take priority over framework detections. An `import openai` is GPAI (limited obligations). But `import openai` combined with `candidate_ranking` is high-risk recruitment AI (conformity assessment required).

No code leaves your machine. No AI APIs are called. Zero dependencies beyond `click` and `rich`.

## CI/CD integration

isologic returns meaningful exit codes:

| Exit Code | Meaning |
|-----------|---------|
| 0 | No high-risk or prohibited AI detected |
| 1 | High-risk AI systems found |
| 2 | Prohibited (unacceptable) AI practices found |

Drop it into your GitHub Actions workflow:

```yaml
name: EU AI Act Compliance
on: [push, pull_request]
jobs:
  compliance:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
      - run: pip install isologic
      - run: isologic audit . --json -o compliance-report.json
      - uses: actions/upload-artifact@v4
        with:
          name: compliance-report
          path: compliance-report.json
```

## Save reports

```bash
# JSON report for programmatic consumption
isologic audit . -o report.json

# Markdown report for your compliance team
isologic audit . -f md -o compliance-report

# Pipe JSON to jq
isologic audit . --json | jq '.summary'
```

## Add a compliance badge

Scan your repo on [codeauditlab.com](https://codeauditlab.com), then add the badge to your README:

```markdown
[![EU AI Act](https://codeauditlab.com/badge/YOUR_SCAN_HASH.svg)](https://codeauditlab.com)
```

The badge shows your compliance score (0-100) with color coding: green for compliant, yellow for needs review, red for high risk. Think codecov, but for EU AI Act compliance.

## PDF compliance reports

Need a formal compliance document for your legal team? codeauditlab.com generates branded PDF reports with risk summaries, detailed classifications, obligation checklists, and EU AI Act article references. $9.99 per report.

## Limitations (honest ones)

- **Pattern-based, not AST** -- regex matching will produce false positives. A variable named `face_recognition_config` in a gaming app is not biometric surveillance, but isologic will flag it.
- **Cannot determine deployment context** -- the same code can be minimal risk or prohibited depending on where and how it's deployed. isologic flags potential issues; human judgment decides.
- **Use-case detection relies on naming conventions** -- if your recruitment AI module is called `utils.py`, isologic might miss it.
- **This is not legal advice** -- isologic is an engineering tool for finding AI systems in your code. For legal compliance, work with a qualified professional.

## What's next

- AST-based analysis for Python to dramatically reduce false positives
- Docker/Kubernetes config scanning for deployment context
- More use-case patterns (migration/border control, critical infrastructure, democratic process manipulation)
- GitLab CI/CD template
- VS Code extension

## Get started

```bash
pip install isologic
isologic audit .
isologic info  # Show EU AI Act dates, penalties, risk categories
```

GitHub: [github.com/masterkenai121/isologic](https://github.com/masterkenai121/isologic)
Web scanner: [codeauditlab.com](https://codeauditlab.com)
License: Apache 2.0

The deadline is Aug 2, 2026. 143 days. Know your exposure now, not when the fine lands.
```

---

## 3. Twitter/X Thread

### Tweet 1

```
We ran an EU AI Act compliance scanner against huggingface/transformers.

4,175 files. 5,275 AI system detections. 93.7 compliance score.

Prohibited AI practices are ALREADY enforceable. High-risk rules hit in 143 days.

Here's how to check your own codebase in 10 seconds:
```

### Tweet 2

```
pip install isologic && isologic audit .

That's it. One command. Scans your Python/JS/TS files for 30+ AI frameworks, matches use cases against EU AI Act risk categories, tells you exactly what you need to do.

No cloud. No signup. No code leaves your machine. Apache 2.0.
```

### Tweet 3

```
The EU AI Act risk levels, simplified:

PROHIBITED -- Social scoring, workplace emotion recognition. Already illegal. EUR 35M fines.

HIGH RISK -- Recruitment AI, credit scoring, medical diagnosis, education. Conformity assessment required by Aug 2, 2026.

GPAI -- Using OpenAI/Anthropic/Gemini APIs. Documentation + transparency obligations since Aug 2025.
```

### Tweet 4

```
isologic exit codes work in CI:

0 = clean
1 = high-risk AI found
2 = prohibited practice detected

Drop it in GitHub Actions, gate your deployments on EU AI Act compliance.

Your legal team will thank you. Or at least stop asking "which of our systems use AI?"
```

### Tweet 5

```
We also built codeauditlab.com -- paste any public GitHub repo URL, get:

- Instant risk classification
- Compliance score 0-100
- Compliance badge for your README (like codecov)
- PDF compliance reports ($9.99)

143 days until the Aug 2, 2026 deadline. Know your exposure.
```

### Tweet 6

```
Honest limitations:

- Pattern-based (regex, not AST) -- false positives happen
- Can't determine deployment context from code alone
- face_recognition import could be phone unlock or public surveillance
- This is an engineering tool, not legal advice

Open source. PRs welcome. github.com/masterkenai121/isologic
```

### Tweet 7

```
If you're shipping AI features to EU users, you have two choices:

1. Spend 10 seconds: pip install isologic && isologic audit .
2. Spend EUR 35,000,000 later

The math seems clear.

codeauditlab.com | github.com/masterkenai121/isologic
```

---

## 4. Reddit r/programming Post

### Title

```
I built an open-source EU AI Act compliance scanner that scans your codebase in one command (Python CLI, Apache 2.0)
```

### Body

```
The EU AI Act is law. Not proposed, not pending -- enforceable. Prohibited practices have been live since Feb 2, 2025. High-risk AI system requirements hit Aug 2, 2026 (143 days away). If your AI touches recruitment, credit scoring, medical diagnosis, education, or law enforcement, you need conformity assessments, QMS, and EU database registration by that date. Penalties scale up to EUR 35M or 7% of global turnover.

I built `isologic` because every engineering team I've seen has the same problem: they're using AI everywhere but have zero inventory of what falls under which EU AI Act category. Legal asks "which systems use AI?" and engineering shrugs.

**What it does:**

```
pip install isologic
isologic audit .
```

Walks your codebase (Python, JS, TS, config files, dependency manifests), matches against 60+ regex patterns for AI frameworks and use cases, classifies each detection by EU AI Act risk level (unacceptable/high/limited/GPAI/minimal), and outputs specific article references + obligation checklists.

**Real scan: huggingface/transformers**

4,175 files scanned, 5,275 detections, 93.7 compliance score. High score because it's a general-purpose library, not a deployment of a high-risk application.

**How classification works:**

Use-case patterns take priority over framework patterns. Detecting `import openai` alone = GPAI (Articles 51-56, documentation obligations). Detecting `import openai` + `candidate_ranking` in the same codebase = high-risk recruitment AI (Annex III, conformity assessment required).

The tool detects 30+ frameworks (OpenAI, Anthropic, HuggingFace, LangChain, PyTorch, TensorFlow, Vercel AI SDK, CrewAI, AutoGen, etc.) and 15+ use cases (biometrics, emotion recognition, recruitment, credit scoring, medical, education, law enforcement, autonomous vehicles, social scoring, deepfakes, chatbots, RAG, etc.).

**CI/CD:**

Exit code 0 = clean, 1 = high-risk found, 2 = prohibited practice. Drop it in GitHub Actions and gate your pipeline.

**What it is NOT:**

- Not AST analysis. It's regex. False positives will happen. A variable named `face_recognition_utils` in a gaming engine will get flagged.
- Not a legal opinion. It's an engineering tool that finds AI systems and maps them to regulation categories. Work with actual lawyers for compliance.
- Not complete. 60+ patterns cover the major frameworks, but there's always more. Contributions welcome.

Zero dependencies beyond click and rich. No network calls. No telemetry. Apache 2.0.

There's also a web version at codeauditlab.com where you can scan any public GitHub repo without installing anything, get a compliance badge for your README, and download PDF compliance reports.

Source: https://github.com/masterkenai121/isologic

Interested in feedback on detection patterns, classification logic, and what frameworks or use cases I'm missing.
```

---

## 5. LinkedIn Post

### Post

```
The EU AI Act's high-risk AI system requirements become enforceable on August 2, 2026. That is 143 days away.

If your engineering teams are building AI features that touch recruitment, credit scoring, medical diagnosis, educational assessment, or law enforcement, those systems will require conformity assessments, quality management systems, CE marking, and EU AI database registration.

Prohibited AI practices -- social scoring, real-time public biometric identification, workplace emotion recognition -- are already enforceable. Since February 2025. Penalties reach EUR 35 million or 7% of global annual turnover.

The first question every CTO and VP of Engineering needs to answer: which of our systems are affected?

Most organizations cannot answer that question today. AI capabilities are embedded across microservices, internal tools, and third-party integrations. No single team has complete visibility.

We built isologic to solve that specific problem. It is an open-source CLI tool (Apache 2.0) that scans a codebase and produces an inventory of every AI system, classified by EU AI Act risk level, with specific article references and obligation checklists.

One command: pip install isologic && isologic audit .

No data leaves your infrastructure. Pure static analysis. Runs in CI/CD pipelines with meaningful exit codes (0 = compliant, 1 = high-risk detected, 2 = prohibited practice found).

We scanned huggingface/transformers as a benchmark: 4,175 files, 5,275 AI system detections, classified across GPAI, limited, and minimal risk categories.

The web version at codeauditlab.com offers instant scanning of any public GitHub repository, compliance scoring (0-100), README badges, and downloadable PDF compliance reports for legal and compliance teams.

The deadline is fixed. The regulation is final. The only variable is preparation.

GitHub: github.com/masterkenai121/isologic
Web: codeauditlab.com
```

---

## Quick Reference

| Platform | Character count | Link to include |
|----------|----------------|-----------------|
| HN title | 78 chars | github.com/masterkenai121/isologic |
| Dev.to | ~1,100 words | codeauditlab.com + GitHub |
| Twitter thread | 7 tweets | codeauditlab.com + GitHub |
| Reddit | ~450 words | GitHub + codeauditlab.com |
| LinkedIn | ~280 words | GitHub + codeauditlab.com |

**Key stats to use everywhere:**
- 4,175 files / 5,275 detections / 93.7 score (huggingface/transformers)
- 143 days until Aug 2, 2026
- EUR 35M / 7% turnover penalties
- 60+ detection patterns, 30+ frameworks
- Prohibited practices enforceable since Feb 2, 2025
- GPAI obligations in effect since Aug 2, 2025
