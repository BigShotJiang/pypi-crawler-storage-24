# Isologic Launch Strategy

*Last updated: 2026-03-03*

---

## Table of Contents

1. [Positioning](#1-positioning)
2. [Competitive Landscape](#2-competitive-landscape)
3. [Timing — Why NOW](#3-timing--why-now)
4. [Launch Sequence (Day-by-Day)](#4-launch-sequence-day-by-day)
5. [Content Assets Needed](#5-content-assets-needed)
6. [Community Building](#6-community-building)
7. [SEO Strategy](#7-seo-strategy)
8. [Viral Hooks](#8-viral-hooks)
9. [Metrics to Track](#9-metrics-to-track)

---

## 1. Positioning

### The One-Liner

> **Scan your codebase for EU AI Act compliance in one command.**

### Elevator Pitch (30 seconds)

The EU AI Act is now law. Prohibited AI practices are already enforceable with fines up to EUR 35 million or 7% of global turnover. High-risk system rules hit in August 2026. Most companies using AI have no idea which of their systems are affected.

Isologic is `pip install isologic && isologic audit .` — one command that scans your codebase, finds every AI system, classifies it by EU AI Act risk level, and tells you exactly what you need to do and by when. No cloud, no signup, no data leaves your machine.

### Messaging That Resonates (by audience)

**Developers:** "Run `isologic audit .` in your CI pipeline. Know your EU AI Act exposure before your legal team does."

**CTOs / Engineering Leaders:** "Your team is shipping AI features. Do you know which ones need conformity assessments before August 2026? Find out in 30 seconds."

**Compliance / Legal:** "Get a machine-readable inventory of every AI system in your codebase, classified by EU AI Act risk tier, with article references and deadline dates."

**VP of Sales / Revenue:** "EU AI Act compliance is already becoming a sales blocker for AI SaaS in enterprise procurement. Enterprise procurement teams are creating AI scorecards. Have your compliance report ready."

### Core Differentiators vs. Everything Else

| Isologic | Enterprise GRC Platforms (Credo AI, Vanta, Holistic AI) | MCP-based Tools (ark-forge) | Web Checkers (EU official, trail-ml) |
|----------|-------------------------------------------------------|---------------------------|--------------------------------------|
| `pip install`, runs in 5 seconds | 6-month enterprise sales cycle | Requires MCP server setup | Manual questionnaire |
| Scans actual code | Manual inventory input | Scans code but MCP-coupled | No code analysis |
| Free, open source, forever | $50K-200K/year | Free tier, 10 scans/day | Free but surface-level |
| CI/CD native (exit codes) | Dashboard-first | Editor-first | Web-only |
| Offline, no data leaves machine | Cloud SaaS | Local but MCP dependency | Cloud |
| Python CLI, zero config | Complex onboarding | Requires MCP ecosystem | N/A |

---

## 2. Competitive Landscape

### Direct Competitors (code-scanning for EU AI Act)

1. **ark-forge/mcp-eu-ai-act** — MCP-based scanner. Similar feature set (scans .py, .js, .ts, etc.). Key weakness: requires MCP server setup, has a paid tier (5 EUR/month for Pro), free tier limited to 10 scans/day. Isologic advantage: pure CLI, no MCP dependency, no rate limits, fully open source.

2. **EuConform** (Hiepler/EuConform) — Offline-first, browser-based. Uses Ollama for risk classification. Launched on HN in January 2026. Key weakness: requires Ollama running, browser-based rather than CLI, focuses on bias testing rather than codebase scanning. Isologic advantage: no LLM dependency, pure static analysis, CI/CD native.

3. **desiorac/mcp-eu-ai-act** — Another MCP server variant. Same MCP coupling limitation.

4. **ARQNXS/eu-ai-act-compliance-checker** — GitHub project, limited traction.

### Indirect Competitors (GRC platforms with AI Act features)

- **Credo AI** — Enterprise AI governance. Gartner darling. $$$$.
- **Vanta** — Added EU AI Act compliance module. Enterprise pricing.
- **Holistic AI** — Risk calculator and compliance platform.
- **EU Official Compliance Checker** — Manual web questionnaire at artificialintelligenceact.eu.

### Key Insight

None of the existing tools offer what Isologic offers: a `pip install` CLI that scans actual code, works offline, runs in CI/CD, and is completely free and open source. The MCP tools require ecosystem buy-in. The enterprise tools require budget approval. The web tools require manual input. Isologic is the only one that a developer can run in 10 seconds with zero friction.

---

## 3. Timing — Why NOW

### The Enforcement Calendar Creates Urgency

```
ALREADY LIVE (since Feb 2, 2025):
  - Prohibited AI practices enforceable NOW
  - Fines: up to EUR 35M / 7% of global turnover
  - Social scoring, manipulative AI, real-time biometric ID = ILLEGAL

ALREADY LIVE (since Aug 2, 2025):
  - GPAI model obligations in effect
  - Technical documentation, copyright compliance, training data summaries required
  - AI Office has oversight (full enforcement powers from Aug 2026)

COMING (Aug 2, 2026 — 5 MONTHS AWAY):
  - HIGH-RISK system requirements become fully enforceable
  - Conformity assessments, CE marking, EU database registration
  - Post-market monitoring, incident reporting
  - Full market surveillance framework active
  - Fines: up to EUR 15M / 3% of global turnover

COMING (Aug 2, 2027):
  - High-risk AI in regulated products (medical, automotive, etc.)
```

### Why March 2026 Is the Perfect Launch Window

1. **5 months before the big deadline.** August 2, 2026 is when high-risk AI system rules become enforceable. Companies are in active planning mode NOW. The European Commission recently missed its own deadline for guidance on high-risk systems — companies are scrambling without clear direction.

2. **EU AI Act compliance is already a sales blocker.** Enterprise procurement teams are creating AI compliance scorecards. SaaS vendors without compliance documentation are losing deals TODAY, not in August.

3. **The "AI Act compliance" HN thread is fresh.** Multiple recent Show HN posts about EU AI Act tools indicate the developer community is actively searching for solutions. The "Ask HN: How are you handling EU AI Act compliance as a developer?" thread shows genuine demand and confusion.

4. **The Digital Omnibus uncertainty.** The European Commission proposed potentially delaying high-risk deadlines to December 2027 — but only conditionally. This creates MORE urgency, not less: companies cannot bet on a delay that may never come.

5. **Open source developers are confused.** The Linux Foundation published guidance noting that open source AI developers "may be unaware that these obligations can apply to them." This is a massive underserved audience.

6. **40% of enterprise AI systems have unclear risk classification.** An appliedAI study of 106 enterprise AI systems found 18% were high-risk, 42% low-risk, and 40% unclear. The "unclear" bucket is where Isologic shines — turning ambiguity into actionable classification.

---

## 4. Launch Sequence (Day-by-Day)

### Pre-Launch Checklist (3-5 days before)

- [ ] GitHub repo is public, clean, with good README (already done)
- [ ] `pip install isologic` works from PyPI
- [ ] Demo GIF recorded (terminal recording of `isologic audit` on a sample project)
- [ ] Sample project with mixed risk levels created (for people to test against)
- [ ] Blog post drafted on dev.to (saved as draft, not published)
- [ ] Twitter/X thread drafted
- [ ] LinkedIn post drafted
- [ ] 5-10 developer friends/contacts briefed — ask them to try it and be ready to comment authentically on HN (NOT to upvote — HN detects voting rings)
- [ ] GitHub Issues seeded with 3-5 "good first issue" labels for contributors

### Day 1 (Tuesday) — Hacker News Launch

**Why Tuesday:** Tuesday-Thursday between 8-10 AM PT / 11 AM-1 PM ET is peak HN traffic. Tuesday gives the full week of momentum. Posting on "Show HN" puts you on the dedicated Show tab, which is less competitive than the main page.

**HN Post Title (options, in order of preference):**

```
Show HN: Isologic – Scan your codebase for EU AI Act compliance (open source)
```

Why this title works:
- "Show HN:" — categorizes correctly, appears on Show tab
- "Isologic" — establishes the name
- "Scan your codebase" — concrete action, not vague
- "EU AI Act compliance" — the regulatory hook (fear + relevance)
- "(open source)" — trust signal, HN loves open source

**Alternate titles to A/B test (pick one):**

```
Show HN: I built a CLI that scans your code for EU AI Act compliance risks
Show HN: Isologic – pip install, one command, know your EU AI Act exposure
Show HN: Isologic – EU AI Act compliance scanner for codebases (Python CLI)
```

**HN Post Body:**

```
Isologic scans your codebase and classifies every AI system by EU AI Act
risk level — unacceptable, high, limited, GPAI, or minimal.

  pip install isologic
  isologic audit .

It detects 30+ AI frameworks (OpenAI, Anthropic, HuggingFace, LangChain,
PyTorch, TensorFlow, etc.) and 11 high-risk use cases (hiring AI, credit
scoring, biometrics, medical diagnosis, etc.).

Output: risk summary table, per-file classifications with EU AI Act article
references, obligation checklists, and enforcement deadlines.

Why I built this: The EU AI Act is now law. Prohibited practices are already
enforceable (since Feb 2025). High-risk system rules hit Aug 2, 2026 — 5
months away. Most teams have no inventory of their AI systems, let alone
risk classifications.

No data leaves your machine. No AI APIs called. Pure static analysis.
Returns exit codes for CI/CD integration.

Apache 2.0. Contributions welcome.

https://github.com/masterkenai121/isologic
```

**Comment Strategy (first 30 minutes are critical):**

Immediately after posting, add a detailed founder comment:

```
Author here. Happy to answer questions.

Background: I kept seeing enterprise compliance tools charging $50-200K/year
for AI governance dashboards, while individual developers and small teams
had nothing. The EU AI Act affects everyone using AI in or selling to the EU,
not just enterprises.

Current limitations I'm upfront about:
- Pattern-based detection, not AST analysis (AST is on the roadmap)
- Cannot determine deployment context from code alone
- Use-case detection relies on naming conventions
- This is guidance, not legal advice

What I'd love feedback on:
- Are the risk classifications reasonable?
- What frameworks/use cases am I missing?
- Would you actually put this in your CI pipeline?

The 30+ framework patterns and 11 use-case rules are all in the source if
anyone wants to audit the classification logic.
```

**Engagement rules:**
- Respond to the first 10 comments within 30 minutes
- Be honest about limitations — HN punishes marketing speak
- Engage with technical criticism constructively
- If someone finds a false positive, say "Great catch, I'll fix that" and actually open an issue
- Do NOT share a direct link and ask friends to upvote — HN's ring detection will kill your post

### Day 1 (Tuesday) — Twitter/X Thread (2-3 hours after HN post)

Post between 1-3 PM ET. The thread:

```
Tweet 1:
I just open-sourced isologic — a CLI that scans your codebase for EU AI Act
compliance.

pip install isologic
isologic audit .

It finds every AI system in your code and tells you: risk level, what
articles apply, what you need to do, and by when.

Free. Offline. Open source. [thread]

Tweet 2:
The EU AI Act is NOW LAW.

- Feb 2025: Prohibited practices already enforceable
- Aug 2025: GPAI obligations in effect
- Aug 2026: High-risk system rules (5 months away)

Penalties: up to EUR 35M or 7% of global turnover.

Most companies have zero inventory of their AI systems.

Tweet 3:
isologic detects 30+ AI frameworks:

OpenAI, Anthropic, HuggingFace, LangChain, PyTorch, TensorFlow, Vertex AI,
Bedrock, Azure OpenAI, Ollama, CrewAI, AutoGen...

And 11 high-risk use cases:
- Hiring/recruitment AI
- Credit scoring
- Biometric identification
- Medical diagnosis
- Education assessment
- Law enforcement
...mapped to specific EU AI Act articles.

Tweet 4:
What you get:

[Attach demo GIF showing terminal output]

- Risk summary table
- Per-file classifications
- EU AI Act article references
- Obligation checklists with deadlines
- Exit codes for CI/CD (0 = clean, 1 = high-risk, 2 = prohibited)

Tweet 5:
What it does NOT do:

- No data leaves your machine
- No AI/LLM calls
- No signup, no cloud, no telemetry
- Pure static analysis with regex patterns

It also won't replace a lawyer. It's a triage tool — know your exposure,
then get proper legal review for what matters.

Tweet 6:
I built this because compliance shouldn't require a $100K enterprise
contract.

Every team using AI in the EU (or selling to EU customers) needs to know
their risk classification. This gets you from "no idea" to "clear inventory"
in one command.

GitHub: https://github.com/masterkenai121/isologic
pip install isologic

Contributions welcome. Apache 2.0.

Tweet 7:
If you're a CTO, head of engineering, or compliance lead:

Run this on your codebase today. Share the report with your legal team.

If you're a developer:

Add it to your CI pipeline. Know your exposure before someone asks.

The August 2026 deadline won't move. Your audit trail starts now.
```

**Twitter engagement strategy:**
- Quote-tweet from the isologic account with additional context
- Reply to every question in the first 2 hours
- Tag relevant accounts: @EUAIAct, relevant EU tech policy accounts
- Use hashtags sparingly: #EUAIAct #opensource #compliance (max 2-3)

### Day 2 (Wednesday) — Reddit Blitz

Post to these subreddits, each with a tailored title and approach. **CRITICAL: Do not cross-post the same text. Each subreddit needs unique framing.**

**r/programming (4.7M members)** — Technical angle
```
Title: Show r/programming: I built a CLI that scans codebases for EU AI Act
compliance — detects 30+ AI frameworks, classifies risk levels, outputs
action items

Body: [Technical description, code examples, how the pattern matching works,
link to GitHub]
```

**r/Python (1.3M members)** — Python ecosystem angle
```
Title: isologic — a Python CLI to scan your codebase for EU AI Act compliance
(pip install isologic)

Body: [Focus on Python packaging, Click + Rich stack, how patterns work,
how to extend it, contribution opportunities]
```

**r/MachineLearning (3.1M members)** — ML practitioner angle
```
Title: Open source tool to classify your ML systems by EU AI Act risk level
— scans code for framework usage and maps to regulatory categories

Body: [Focus on what ML systems are high-risk, which frameworks trigger what
classifications, the appliedAI stat about 40% of systems being unclear]
```

**r/devops (300K members)** — CI/CD angle
```
Title: EU AI Act compliance check in your CI pipeline — isologic returns
exit codes (0=clean, 1=high-risk, 2=prohibited)

Body: [GitHub Actions example, exit code explanation, how to gate deploys
on compliance status]
```

**r/europeanunion or r/europrivacy** — Policy/regulation angle
```
Title: Open source tool to check if your AI systems comply with the EU AI
Act — free, offline, scans actual code

Body: [Focus on the regulation itself, deadlines, what the tool finds,
the problem of companies not knowing their exposure]
```

**r/legaltech** — Legal professional angle
```
Title: CLI tool that generates EU AI Act compliance reports from codebases
— risk classifications, article references, obligation checklists

Body: [Focus on the markdown report output, how legal teams can use it,
the gap between legal understanding and engineering reality]
```

**r/opensource (350K members)** — Community angle
```
Title: I open-sourced isologic — EU AI Act compliance scanner for codebases
(Apache 2.0)

Body: [Focus on the open source ethos, why compliance tooling should be
free, contributing guide, good first issues]
```

**Reddit rules:**
- Post each 2-4 hours apart (not all at once — looks spammy)
- Read each subreddit's rules before posting
- Engage with every comment for 24 hours
- Do not be promotional — be helpful and technical
- If a mod removes your post, do not repost. Message the mod team.

### Day 3 (Thursday) — Dev.to Article

**Title:** "I Scanned My Codebase for EU AI Act Compliance — Here's What I Found"

**Structure:**
1. Hook: "I ran a single command on our production codebase and discovered we have 2 high-risk AI systems, 3 GPAI models, and 1 system that's technically already illegal under EU AI Act prohibited practices."
2. The problem: What the EU AI Act requires, the deadlines, the penalties
3. The solution: Walk through `isologic audit` step by step on a real-ish project
4. The output: Show the terminal output, explain each classification
5. What to do next: For each risk level, what are the obligations
6. How it works under the hood: Pattern matching, classification logic
7. Limitations and roadmap: Be honest
8. Call to action: pip install, GitHub star, contribute

**Tags:** `python`, `opensource`, `ai`, `compliance`

This article should be 1500-2000 words with embedded code blocks and screenshots of terminal output.

### Day 4 (Friday) — LinkedIn for Business Audience

**LinkedIn Post (for personal profile, NOT company page — personal posts get 5-10x more reach):**

```
The EU AI Act high-risk deadline is 5 months away (August 2, 2026).

Penalties: up to EUR 35M or 7% of global annual turnover.

I keep hearing the same thing from engineering leaders:

"We know we need to comply, but we don't even know which of our AI systems
are affected."

So I built isologic — an open-source CLI that scans your codebase and
classifies every AI system by EU AI Act risk level.

One command: isologic audit .

What you get:
-- Which AI frameworks your team is using (30+ detected)
-- Which use cases trigger high-risk classification
-- Specific EU AI Act article references
-- Obligation checklists with deadline dates
-- A report you can hand to your legal team TODAY

What it doesn't do:
-- No data leaves your machine
-- No AI/LLM calls, no cloud, no signup
-- Not legal advice — it's a triage tool

If you're a CTO, VP Engineering, or compliance lead:

Run this on your codebase. Get the inventory done.
The conformity assessment, documentation, and CE marking requirements
for August 2026 are substantial. You need to know your exposure now,
not in July.

Free, open source, Apache 2.0:
https://github.com/masterkenai121/isologic

pip install isologic

If your company uses AI and sells to EU customers, this applies to you.
The "we'll figure it out later" window is closing.

#EUAIAct #AICompliance #OpenSource #AIGovernance
```

### Day 5-7 (Weekend) — Follow-Up Content

- Respond to all GitHub issues that came in during the week
- Publish a follow-up tweet: "X people scanned their codebases this week. Top finding: Y% had at least one high-risk AI system they didn't know about." (Use real numbers from telemetry or GitHub stars/issues)
- Write a short Hashnode cross-post of the dev.to article (adapted, not identical)
- Start engaging in the HN "Ask HN" thread about EU AI Act compliance if still active
- Post in relevant Discord servers (Python Discord, MLOps Community, etc.)

---

## 5. Content Assets Needed

### Must-Have Before Launch

1. **Demo GIF (30 seconds)** — Terminal recording showing:
   - `pip install isologic` (fast)
   - `isologic audit ./sample-project`
   - The risk summary table appearing
   - Scrolling through classifications
   - Tool: use `asciinema` or `terminalizer` or `vhs` (Charm's VHS is best for polished GIFs)

2. **Sample Project** — A small repo in `/examples/sample-project/` containing:
   - A file using OpenAI API (minimal risk)
   - A file using LangChain RAG (limited risk / GPAI)
   - A file that looks like hiring/recruitment AI (high risk)
   - A file with emotion recognition patterns (unacceptable)
   - This lets anyone clone and immediately see Isologic in action

3. **Static social image** — For Twitter/LinkedIn/Reddit link previews:
   - Terminal screenshot or styled mock of the risk summary table
   - Text: "isologic — EU AI Act compliance scanner"
   - Use GitHub's social preview (Settings > Social preview)

### Post-Launch Content Pipeline

| Week | Article / Content | Platform | Angle |
|------|------------------|----------|-------|
| 1 | "I Scanned My Codebase for EU AI Act Compliance" | Dev.to | Developer experience |
| 2 | "EU AI Act Risk Classification: A Developer's Guide" | Dev.to / Blog | Educational deep-dive |
| 3 | "Adding EU AI Act Compliance Checks to Your CI/CD Pipeline" | Dev.to | DevOps/practical |
| 4 | "The 11 High-Risk AI Use Cases Under EU AI Act (And How to Detect Them in Code)" | Blog / LinkedIn | CTO/compliance audience |
| 5 | "Why EU AI Act Compliance Is Becoming a Sales Blocker for AI SaaS" | LinkedIn | Business/revenue angle |
| 6 | "Open Source EU AI Act Compliance: Why Vendor Lock-In Is the Wrong Approach" | Blog | Thought leadership |
| 8 | "isologic v0.2: AST-Based Analysis, Dependency Scanning, and More" | GitHub Release / Dev.to | Feature announcement |

### Report Templates

Create three example reports that people can reference:
1. **Clean project** — Minimal risk, no action items (for comparison)
2. **Typical SaaS startup** — Mix of GPAI and limited risk systems
3. **Red-flag project** — High-risk and prohibited use cases detected

These go in the README or a `/docs/examples/` directory.

---

## 6. Community Building

### GitHub Repository Optimization

- **GitHub Topics:** `eu-ai-act`, `compliance`, `ai-governance`, `security`, `static-analysis`, `cli`, `python`, `audit`, `risk-assessment`, `regulation`
- **Social Preview Image:** Custom image showing the terminal output
- **GitHub Discussions:** Enable and seed with categories:
  - "Show & Tell" — people share their scan results
  - "Feature Requests" — what people want next
  - "EU AI Act Questions" — regulatory Q&A (NOT legal advice)
  - "False Positives / Negatives" — reporting detection issues
- **Issue Labels:** `good first issue`, `help wanted`, `detection-pattern`, `use-case`, `framework`, `documentation`
- **Seed 5-8 "good first issue" items:**
  - "Add detection pattern for [framework X]"
  - "Add use-case rule for [domain Y]"
  - "Improve README: add section on Z"
  - "Add test case for [scenario]"

### Contributing Guide

The existing CONTRIBUTING.md should emphasize:
- Adding detection patterns is the easiest way to contribute (just regex + metadata)
- No deep knowledge of EU AI Act needed for framework detection contributions
- Use-case rules welcome but should cite specific Annex III references
- Tests required for new patterns

### Discord vs. GitHub Discussions

**Recommendation: Start with GitHub Discussions only.** Do not create a Discord server at launch.

Why:
- Discord requires constant moderation and activity to not feel dead
- GitHub Discussions keeps everything searchable and indexed
- You can always upgrade to Discord later when you have 500+ stars
- GitHub Discussions has lower friction for developers (they're already on GitHub)

### Maintainer Responsiveness (Critical for Adoption)

Research shows 40.6% of developers abandon tools if setup is painful, and response time on GitHub issues within 48 hours is a critical trust signal.

Rules:
- Respond to every GitHub issue within 24 hours (even if just "Thanks, looking into this")
- Merge simple PRs (typo fixes, new detection patterns) within 48 hours
- Triage and label issues daily for the first month
- Thank every contributor publicly

---

## 7. SEO Strategy

### Primary Keywords (high intent, regulatory urgency)

| Keyword / Phrase | Search Intent | Content to Rank |
|-----------------|---------------|-----------------|
| `eu ai act compliance tool` | Solution seeking | GitHub README, landing page |
| `eu ai act compliance checker` | Solution seeking | README, dev.to article |
| `eu ai act risk assessment tool` | Solution seeking | README |
| `eu ai act scanner` | Solution seeking | README, blog post |
| `eu ai act codebase audit` | Solution seeking | Blog post |
| `eu ai act high risk ai systems` | Educational | Blog: "11 High-Risk Use Cases" |
| `eu ai act penalties` | Fear-driven | README "Why" section |
| `eu ai act compliance checklist` | Planning | Markdown report output |
| `eu ai act deadline 2026` | Urgency | Blog: timing content |
| `eu ai act python` | Developer-specific | README, PyPI description |
| `ai compliance open source` | Value-driven | README, blog post |
| `eu ai act ci cd` | DevOps-specific | Blog: CI/CD integration post |

### Long-Tail Keywords (lower volume, higher conversion)

- `how to check if my ai system complies with eu ai act`
- `eu ai act compliance for startups`
- `eu ai act risk classification tool free`
- `scan codebase for ai act compliance`
- `eu ai act open source developer tool`
- `eu ai act conformity assessment tool`
- `python eu ai act compliance`
- `github actions eu ai act`
- `ai act annex iii high risk systems list`

### SEO Actions

1. **PyPI page** — The pyproject.toml description and keywords are already solid. Make sure the PyPI long description (from README) renders well.
2. **GitHub README** — Already contains key terms naturally. Good as-is.
3. **Dev.to articles** — Target 2-3 primary keywords per article. Dev.to has strong domain authority on Google.
4. **Consider a landing page** at isologic.ai — Even a single page with the README content will outrank GitHub for branded searches and can be optimized for key terms.

---

## 8. Viral Hooks

These are the psychological triggers that make Isologic shareable.

### Hook 1: Fear of Fines (Loss Aversion)

**Message:** "EUR 35 million. Or 7% of your global turnover. Whichever is higher. That's the penalty for prohibited AI practices under the EU AI Act — and it's already enforceable."

**Why it works:** Loss aversion is twice as powerful as gain seeking. People share warnings with their networks. This is the GDPR playbook — the fines drove compliance tool adoption more than anything else.

**Usage:** Lead with this in LinkedIn posts, CTO-targeted content, and the "Why" section of every piece of content.

### Hook 2: The One-Command Audit (Simplicity)

**Message:** "pip install isologic && isologic audit . — Know your EU AI Act exposure in 30 seconds."

**Why it works:** Developers share tools that feel magical. The gap between "I don't know my compliance status" and "I have a full risk inventory" should be exactly one command. This is the trivy/snyk playbook — frictionless security scanning.

**Usage:** Lead with this in developer-targeted content. The demo GIF should show exactly this flow.

### Hook 3: "Are You Compliant?" (Identity / Status)

**Message:** "I ran isologic on our codebase. We had 2 high-risk AI systems we didn't know about."

**Why it works:** Creates social proof and FOMO. When developers share their scan results, it prompts others to check theirs. The "I didn't know about" framing normalizes not knowing while creating urgency to find out.

**Usage:** Encourage people to share their results on Twitter/LinkedIn. Create a "share your scan" prompt in the tool's terminal output (tasteful, not aggressive).

### Hook 4: The Countdown Clock (Time Pressure)

**Message:** "August 2, 2026. X days away. High-risk AI system requirements become enforceable."

**Why it works:** Deadlines create action. GDPR saw a massive spike in compliance tool adoption in the 6 months before enforcement. We are in that window RIGHT NOW for the EU AI Act high-risk deadline.

**Usage:** Include a dynamic countdown in the `isologic info` command output. Reference the specific date in all content.

### Hook 5: "This Affects You Too" (Scope Surprise)

**Message:** "If you use OpenAI/Anthropic/HuggingFace APIs in your product and have EU customers, the EU AI Act applies to you. Even if you're a US company."

**Why it works:** Many developers and companies assume the EU AI Act only applies to EU companies. The extraterritorial scope (similar to GDPR) is a genuine surprise that prompts immediate action. The Linux Foundation noted that open source developers "may be unaware that these obligations can apply to them."

**Usage:** Dev.to articles, Twitter threads, LinkedIn posts. Frame it as helpful education, not fearmongering.

### Hook 6: Compliance as Sales Enablement (Business Value)

**Message:** "Enterprise procurement teams are already requiring EU AI Act compliance documentation. No compliance report = no deal."

**Why it works:** Translates regulatory burden into revenue protection. CTOs and VPs of Sales will share this because it reframes compliance from cost center to revenue enabler.

**Usage:** LinkedIn posts, CTO-targeted content. Reference the real trend of EU AI Act compliance becoming a procurement requirement.

---

## 9. Metrics to Track

### Week 1 Targets

| Metric | Target | Stretch |
|--------|--------|---------|
| GitHub Stars | 200 | 500 |
| PyPI Downloads | 500 | 1,500 |
| HN Points | 50 | 150 |
| HN Comments | 20 | 50 |
| Twitter Impressions | 10K | 50K |
| Dev.to Article Views | 1K | 5K |
| GitHub Issues Opened | 5 | 15 |
| First External PR | 1 | 3 |

### Month 1 Targets

| Metric | Target | Stretch |
|--------|--------|---------|
| GitHub Stars | 500 | 2,000 |
| PyPI Downloads (total) | 2,000 | 10,000 |
| GitHub Contributors | 3 | 10 |
| Blog/article mentions | 2 | 5 |
| Newsletter mentions | 1 | 3 |

### Tracking Setup

- **PyPI downloads:** Use pypistats.org or `pip install pypistats`
- **GitHub traffic:** Settings > Insights > Traffic (referrers, popular content)
- **Star history:** Use star-history.com for the public chart
- **HN tracking:** Use hn.algolia.com to monitor mentions
- **Twitter/X:** Native analytics for the thread
- **Dev.to:** Built-in analytics dashboard

---

## Appendix A: Launch Day Timetable (Day 1 — Tuesday)

| Time (ET) | Action |
|-----------|--------|
| 10:30 AM | Final check: pip install works, README renders on GitHub |
| 11:00 AM | Post to Hacker News (Show HN) |
| 11:05 AM | Post founder comment on HN |
| 11:05-11:30 AM | Respond to first HN comments (critical window) |
| 11:30 AM | Text/DM 5-10 developer contacts: "Just launched this, would love your honest take" (do NOT send HN link asking for upvotes) |
| 1:00 PM | Post Twitter/X thread |
| 1:30 PM | Continue engaging HN comments |
| 3:00 PM | Post to r/programming |
| 5:00 PM | Post to r/Python |
| Evening | Continue engaging all platforms, respond to GitHub issues |

## Appendix B: Distribution Channels Checklist

| Channel | Post? | Timing | Notes |
|---------|-------|--------|-------|
| Hacker News (Show HN) | Yes | Day 1 | Primary launch channel |
| Twitter/X | Yes | Day 1 | Thread format |
| r/programming | Yes | Day 2 | Technical angle |
| r/Python | Yes | Day 2 | Python ecosystem |
| r/MachineLearning | Yes | Day 2 | ML practitioner angle |
| r/devops | Yes | Day 2 | CI/CD angle |
| r/europrivacy | Yes | Day 3 | Regulatory angle |
| r/legaltech | Yes | Day 3 | Legal professional angle |
| r/opensource | Yes | Day 3 | Community angle |
| Dev.to | Yes | Day 3 | Long-form article |
| LinkedIn (personal) | Yes | Day 4 | Business/CTO audience |
| Hashnode | Yes | Day 5 | Cross-post adapted article |
| Python Discord | Maybe | Day 5 | Only if you're an active member |
| MLOps Community Slack | Maybe | Day 5 | Only if you're an active member |
| Product Hunt | No | Later | Not ideal for CLI developer tools |
| Indie Hackers | Maybe | Week 2 | If traction warrants it |
| Lobste.rs | Maybe | Week 2 | Invite-only, technical audience |

## Appendix C: Competitive Intelligence Sources

Keep tabs on these for ongoing positioning:

- [ark-forge/mcp-eu-ai-act](https://github.com/ark-forge/mcp-eu-ai-act) — Closest competitor
- [Hiepler/EuConform](https://github.com/Hiepler/EuConform) — Offline-first browser tool
- [EU AI Act Compliance Checker](https://artificialintelligenceact.eu/assessment/eu-ai-act-compliance-checker/) — Official web tool
- [Vanta EU AI Act](https://www.vanta.com/products/eu-ai-act) — Enterprise platform
- [Credo AI](https://www.credo.ai/) — Enterprise governance
- [Holistic AI Risk Calculator](https://www.holisticai.com/eu-ai-act-risk-calculator) — Web risk calculator
- [HN: "Ask HN: How are you handling EU AI Act compliance?"](https://news.ycombinator.com/item?id=47169864) — Ongoing developer discussion

## Appendix D: Research Sources

This strategy was informed by the following sources:

- [EU AI Act Implementation Timeline](https://artificialintelligenceact.eu/implementation-timeline/)
- [EU AI Act Penalties — Article 99](https://artificialintelligenceact.eu/article/99/)
- [DLA Piper: Latest Wave of Obligations Under the EU AI Act](https://www.dlapiper.com/en-us/insights/publications/2025/08/latest-wave-of-obligations-under-the-eu-ai-act-take-effect)
- [EU AI Act News 2026: Compliance Requirements & Deadlines](https://axis-intelligence.com/eu-ai-act-news-2026/)
- [LegalNodes: EU AI Act 2026 Updates](https://www.legalnodes.com/article/eu-ai-act-2026-updates-compliance-requirements-and-business-risks)
- [Cranium: Navigating the EU AI Act August 2025 Deadline](https://cranium.ai/resources/blog/navigating-the-eu-ai-act-august-2025-deadline-gpai-compliance-penalties-and-enforcement/)
- [IAPP: European Commission Misses Deadline for High-Risk Guidance](https://iapp.org/news/a/european-commission-misses-deadline-for-ai-act-guidance-on-high-risk-systems/)
- [Linux Foundation: What Open Source Developers Need to Know](https://linuxfoundation.eu/newsroom/ai-act-explainer)
- [How to Launch a Dev Tool on Hacker News — MarkePear](https://www.markepear.dev/blog/dev-tool-hacker-news-launch)
- [How to Crush Your Hacker News Launch — DEV Community](https://dev.to/dfarrell/how-to-crush-your-hacker-news-launch-10jk)
- [Catchy Agency: What 202 Open Source Developers Taught Us About Tool Adoption](https://www.catchyagency.com/post/what-202-open-source-developers-taught-us-about-tool-adoption)
- [Centraleyes: Top 13 AI Compliance Tools of 2026](https://www.centraleyes.com/top-ai-compliance-tools/)
- [Orrick: The EU AI Act — 6 Steps to Take Before August 2026](https://www.orrick.com/en/Insights/2025/11/The-EU-AI-Act-6-Steps-to-Take-Before-2-August-2026)

---

## 10. Feature Roadmap

*Updated: 2026-03-10 — based on competitive analysis of Credo AI, Holistic AI, Vanta, ark-forge*

### What Enterprise Buyers Actually Pay $50K-200K/yr For

| What They Pay For | Description | isologic Status |
|---|---|---|
| **AI Inventory & Discovery** | Find every AI system across org, including shadow AI | Partial — scans code only |
| **Risk Classification** | Map each system to EU AI Act risk tiers | **Done** — core strength |
| **Technical Documentation** | Auto-generate Annex IV docs (conformity assessments) | **Missing — #1 priority** |
| **Continuous Monitoring** | Ongoing compliance checks, drift detection | Missing — one-shot only |
| **Audit Trail & Evidence** | Timestamped exportable compliance records | Partial — JSON/MD reports |

### Tier 1 — Free CLI Upgrades (drives adoption, do first)

1. **Dependency scanning** — parse `requirements.txt`, `package.json`, `pyproject.toml`, `Pipfile`, `poetry.lock` for AI deps (not just imports in source code)
2. **Remote repo scan** — `isologic audit https://github.com/org/repo` — scan without cloning locally
3. **Compliance score** — single 0-100 number per project (shareable, viral — "we scored 87/100")
4. **Countdown timer** in output — "X days until Aug 2, 2026 high-risk deadline"
5. **Badge generator** — `isologic badge .` → SVG badge for README ("EU AI Act: Compliant" / "3 High-Risk Systems")
6. **AST-based analysis** for Python (upgrade from regex patterns — fewer false positives)
7. **Docker/deployment config scanning** — detect AI in Dockerfiles, k8s manifests, docker-compose

### Tier 2 — SaaS Features (Code Audit Lab — what you charge for)

1. **Web Dashboard** — scan repos from browser, view risk trends over time, share with team
2. **Annex IV Documentation Generator** — THE killer feature. Auto-generate structured technical documentation for each high-risk AI system from scan results + AI. This is what companies MUST produce by Aug 2026 and nobody wants to write manually.
3. **Paste GitHub URL → Get Report** — landing page feature, zero friction, viral growth hack
4. **Team management** — invite compliance/legal to view reports
5. **Scheduled scans** — webhook on every push, track compliance drift over time
6. **Compliance certificate PDF** — timestamped document for enterprise procurement questionnaires
7. **Email alerts** — notify when new high-risk systems detected or classification changes

### Tier 3 — Enterprise Features ($10K+ deals)

1. **SSO/SAML authentication**
2. **Self-hosted deployment option** (Docker)
3. **Custom policy packs** — sector-specific rules (fintech, healthcare, HR tech, defense)
4. **Jira/Linear integration** — auto-create tickets for non-compliant systems
5. **Deployer vs Provider view** — different compliance perspectives (Holistic AI differentiator)
6. **Org-wide discovery** — scan all repos across GitHub org automatically
7. **API access** — other tools integrate your scanner programmatically

---

## 11. Monetization & Pricing

### Pricing Model (Trivy/Snyk playbook — free CLI, paid SaaS)

| Tier | Price | What You Get |
|------|-------|------|
| **Free** | $0 forever | CLI tool, unlimited local scans, CI/CD exit codes, JSON/MD reports, badge generator |
| **Pro** | $29/mo per repo | Dashboard, scheduled scans, compliance score history, Annex IV doc generator, compliance certificate PDF |
| **Team** | $99/mo (5 repos) | Everything in Pro + team access, Jira integration, email alerts, priority support |
| **Enterprise** | $499/mo+ (custom) | Everything in Team + SSO, self-hosted, custom policies, SLA, dedicated onboarding |

### Additional Revenue Streams

1. **One-time compliance report** — $49 per repo for timestamped PDF compliance report. Companies need this for procurement questionnaires RIGHT NOW. No subscription needed.
2. **API access** — $0.10/scan for other tools integrating the scanner
3. **Consulting upsell** — "Your scan found 3 high-risk systems. Book a 1-hour review with our EU AI Act compliance expert." $500/session. Outsource to EU AI Act lawyers on rev-share.
4. **White-label** — consulting firms and law firms use your scanner under their brand. $2K-5K/mo.
5. **GitHub Sponsors** — open source supporters funding development

### Revenue Projections (Conservative)

| Month | Free Users | Pro | Team | Enterprise | One-time Reports | MRR |
|-------|-----------|-----|------|-----------|-----------------|-----|
| 1 | 500 | 5 | 0 | 0 | 10 | $635 |
| 3 | 2,000 | 20 | 3 | 0 | 30 | $1,377 |
| 6 | 5,000 | 50 | 10 | 2 | 50 | $3,938 |
| 12 | 15,000 | 150 | 30 | 5 | 100 | $10,820 |

---

## 12. Viral Growth Strategy

### The Trivy Playbook (22K+ GitHub stars, free → massive adoption)

- **Zero friction**: `pip install → one command → value` ✅ already there
- **CI/CD native**: exit codes + GitHub Action ✅ already there
- **Badge in README**: every repo that uses it advertises you for free
- **Compliance score**: shareable number → "We scored 94/100 on EU AI Act"

### Viral Growth Hacks (Priority Order)

#### Hack 1: "Scan Any Public Repo" on Landing Page
Paste a GitHub URL → see results instantly. No signup. People will:
- Scan their own repos (leads)
- Scan competitors' repos (drama → shares)
- Scan famous projects (content → press)

This is THE growth hack. Build this first on the landing page.

#### Hack 2: Compliance Badge Movement
Like the Snyk badge. Generate SVG badges for READMEs:
- `![EU AI Act: Compliant](https://codeauditlab.com/badge/org/repo.svg)`
- Every repo that adds it = free billboard for Code Audit Lab
- Badge links back to your full report page

#### Hack 3: Public Leaderboard
"Most compliant open-source AI projects" — ranked by compliance score.
- Projects compete to score higher → they link back to you
- Media picks it up → "LangChain scores 72/100, AutoGen scores 89/100"
- Weekly updates → recurring content

#### Hack 4: Scan Famous Projects, Publish Results
Scan LangChain, AutoGen, CrewAI, Hugging Face Transformers, etc.
- Publish findings as blog post: "We scanned the top 20 AI frameworks for EU AI Act compliance"
- Tag the maintainers → they share it
- HN post → "EU AI Act compliance scores for popular AI frameworks"

#### Hack 5: Free Compliance Reports for YC Companies
Scan all YC AI startups (public repos), publish anonymized aggregate results.
- "73% of YC AI startups have at least one unclassified high-risk system"
- Guaranteed HN front page material

#### Hack 6: Countdown Widget
Embeddable "X days until EU AI Act enforcement" widget for blogs/sites.
- Links back to Code Audit Lab
- Free distribution across compliance blogs

#### Hack 7: "Is YOUR Startup Compliant?" Twitter Thread
Post thread → invite people to reply with their repo URL → scan live → share results.
- Engagement bait that actually provides value
- Each scan = a potential lead

---

## 13. Outreach Strategy

### Channel 1: Cold Email (Enterprise, $5K-50K deals)

**Target ICP (Ideal Customer Profile)**:
- CTOs, VP Engineering, Head of Compliance
- At companies using AI (OpenAI/Anthropic/HuggingFace in their stack)
- Selling to EU customers OR based in EU/UK
- 50-5000 employees (mid-market sweet spot — big enough to need compliance, small enough to not have in-house governance team)

**Where to find them**:
- LinkedIn Sales Nav: filter by title + "AI" + EU/UK company
- GitHub: search for orgs using OpenAI/Anthropic/HuggingFace in public repos
- Job boards: companies hiring "AI compliance" or "AI governance" = active buyers
- Crunchbase: EU-based AI startups with recent funding rounds

**Cold Email Sequence**:

```
Email 1 — Value-first (Day 0)
Subject: Your AI systems and Aug 2, 2026

Hi {name},

I ran our open-source EU AI Act scanner on {company}'s public repos
and found {X} AI systems that may need classification before the
August deadline.

Happy to share the full report — no strings attached.

The scanner is free: pip install isologic
Or I can send you a PDF compliance report for your repos.

{your name}
```

```
Email 2 — Follow-up with insight (Day 3)
Subject: Re: Your AI systems and Aug 2, 2026

Quick follow-up — I noticed {company} uses {framework} in
{specific repo}. Under Annex III, {use case} may classify as
high-risk, which means conformity assessment before Aug 2.

I attached the scan results. The full Annex IV documentation
generator is what most teams use next.

Happy to walk through it.
```

```
Email 3 — Social proof (Day 7)
Subject: How {similar company} handled their EU AI Act audit

{similar company} ran the same scan and found 4 systems needing
classification. They had their compliance docs ready in 2 weeks
using our Annex IV generator.

August is 5 months away. Want me to send your report?
```

### Channel 2: Partnership Outreach

**Law firms specializing in EU AI Act**:
- They need a technical tool to recommend to clients
- Offer: white-label scanner + rev-share on referrals
- Find them: LinkedIn search "EU AI Act" + "partner" at law firms

**DevSecOps platforms (Snyk, Aikido, SonarQube, Panto)**:
- Integration partner — you handle AI Act, they handle security scanning
- Offer: free integration, co-marketing
- Reach out to partnership/BD teams directly

**Consulting firms (Big 4, boutiques doing AI governance)**:
- White-label your scanner for their clients
- Offer: $2K-5K/mo white-label license
- Big 4 are already selling EU AI Act consulting at $500/hr

### Channel 3: Community-Led Growth

1. **Dev.to / Hashnode series** — weekly "EU AI Act for Developers" column → build authority → organic leads
2. **Webinar: "Scan Your Codebase Live"** — attendees submit repos, scan on screen. Lead gen goldmine.
3. **GitHub Discussions** — answer EU AI Act questions → establish as the go-to tool
4. **Conference talks** — submit to PyCon, DevSecCon, EU AI Act conferences
5. **Newsletter** — weekly EU AI Act updates + compliance tips. Builds email list for Pro conversion.

### Channel 4: Content Marketing / SEO

Target these high-intent keywords with dedicated content:

| Content | Target Keyword | Format |
|---------|---------------|--------|
| "How to check EU AI Act compliance for your codebase" | eu ai act compliance tool | Blog |
| "EU AI Act Annex IV documentation template" | annex iv template | Blog + downloadable template |
| "EU AI Act risk classification: developer guide" | eu ai act risk levels | Blog |
| "Adding EU AI Act checks to GitHub Actions" | eu ai act ci cd | Tutorial |
| "EU AI Act penalties: what developers need to know" | eu ai act fines | Blog |
| "Free EU AI Act compliance scanner" | free ai act scanner | Landing page |

---

## 14. The Killer Feature — Annex IV Documentation Generator

This is the **single feature** that separates "free CLI tool" from "company paying $10K/yr."

### Why It Matters

Every high-risk AI system MUST have technical documentation per Annex IV before Aug 2, 2026. This includes:

1. General description of the AI system
2. Detailed description of elements and development process
3. Information about monitoring, functioning and control
4. Risk management system description
5. Data governance and management practices
6. Post-market monitoring plan
7. Changes to the system throughout lifecycle
8. List of applied harmonized standards
9. Copy of EU declaration of conformity

### How We Build It

1. **Scan** — isologic identifies framework, use case, risk level (already works)
2. **Extract** — pull architecture info from code: dependencies, model types, data flows, API patterns
3. **Generate** — use LLM (local Ollama or API) to draft each Annex IV section from extracted data
4. **Review** — human reviews/edits generated docs in dashboard or exports to DOCX/PDF
5. **Certify** — generate timestamped compliance certificate

### Pricing for Doc Generator

- **Free**: scan + risk classification (CLI)
- **Pro ($29/mo)**: scan + doc generator + PDF export + compliance certificate
- **One-time**: $49/report for non-subscribers (no commitment needed)

This is the GDPR cookie consent banner moment — every company needs it, nobody wants to DIY it, and the deadline creates urgency.

---

## 15. Brand: Code Audit Lab

### Rebrand Strategy

- **Domain**: [TBD — Namecheap]
- **Open source CLI**: stays as `isologic` on PyPI and GitHub
- **SaaS product**: branded as **Code Audit Lab** (or domain name)
- **Relationship**: "Code Audit Lab — powered by isologic" (like Snyk uses open source Trivy competitor)

### Landing Page Structure

```
[Hero]
Scan your codebase for EU AI Act compliance.
One command. Zero friction. Free.
[Paste GitHub URL] [Scan Now]

[Countdown]
XX days until high-risk AI system rules are enforceable.
EUR 35M fines. 7% of global turnover.

[How it works]
1. Paste URL or run CLI
2. Get risk classification for every AI system
3. Generate Annex IV compliance docs
4. Export PDF for your legal team

[Pricing]
Free / Pro $29/mo / Team $99/mo / Enterprise

[Social proof]
X repos scanned / X AI systems classified / X companies compliant

[Leaderboard]
Top 10 most compliant open-source AI projects

[Footer]
Open source: github.com/masterkenai121/isologic
```
