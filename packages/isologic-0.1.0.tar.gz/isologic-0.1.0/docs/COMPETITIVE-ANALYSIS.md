I now have comprehensive research data. Let me compile the competitive analysis report.

---

## EU AI Act Compliance Tools -- Competitive Landscape Analysis (March 2026)

### Market Context

The high-risk AI system enforcement deadline is **August 2, 2026** -- roughly 143 days away. Penalties: up to EUR 35M or 7% of global turnover. Only 18% of organizations have fully implemented AI governance frameworks despite 88% using AI operationally. This is the window.

The market splits into two distinct tiers:

---

### TIER 1: Enterprise Governance Platforms (GRC-oriented, $10K-$200K/yr)

These are designed for compliance teams, not developers.

**1. Credo AI** ($105M valuation, $39.3M raised, 11-50 employees)
- **Offer**: SaaS governance platform. Custom pricing via sales call.
- **Features**: AI inventory management, risk classification per Annex III/IV, automated technical documentation, audit trails, workflow automation (claims 60% reduction in manual effort). Integrates with AWS, Azure, GCP.
- **Weaknesses**: Enterprise-only pricing (estimated $50K-$200K/yr). No code scanning -- it's a governance/documentation platform, not a developer tool. No CLI. No free tier. Requires months of onboarding.

**2. Holistic AI** (London-based, VC-funded)
- **Offer**: SaaS governance platform. Custom pricing.
- **Features**: AI inventory discovery and onboarding, risk scoring (efficacy, robustness, privacy, bias, explainability), real-time drift monitoring, audit-ready evidence, compliance mapping for EU AI Act + NIST RMF + ISO 42001. Bias auditing capability.
- **Weaknesses**: Enterprise pricing. No codebase scanning -- it's model-level governance. No developer self-serve. No CLI.

**3. Vanta** ($10K-$30K/yr base, audits extra $10K-$50K)
- **Offer**: SaaS compliance automation with EU AI Act module. 400+ integrations.
- **Features**: AI system classification by risk level, policy templates, evidence collection automation, post-market monitoring. Can cross-map from NIST AI RMF and ISO 42001.
- **Weaknesses**: Primarily a SOC 2/ISO platform that bolted on an AI Act module. No code scanning. Not purpose-built for AI Act. Heavy onboarding.

**4. Trail (trail-ml.com)**
- **Offer**: SaaS "AI Governance Copilot." Free trial available, pricing not public.
- **Features**: AI use-case registry, risk classification, 500+ curated risks/controls library, automated model/data/code documentation, ISO 42001 certification pathway, EU AI Act compliance checker tool (web-based questionnaire). Free 1-hour workshop.
- **Weaknesses**: Questionnaire-based, not code-scanning. Targets compliance managers, not developers. No CLI. No badge system.

---

### TIER 2: Developer-Focused / Code-Scanning Tools (Free-$99/mo)

This is CodeAuditLab's actual competitive set.

**5. Arkforge MCP EU AI Act Scanner** (open source, free)
- **Offer**: MCP server (Model Context Protocol) for Claude Desktop/Cursor. Python CLI via `pip install mcp`.
- **Features**: Scans .py/.js/.ts/.java/.go/.rs/.cpp files + dependency files. Detects AI framework usage. Checks for required documentation files (RISK_MANAGEMENT.md, TRANSPARENCY.md, etc.). JSON output.
- **Weaknesses**: MCP-only (requires Claude Desktop or compatible tool). No web interface. No compliance score. No badge. No PDF reports. Pattern-matching only. No use-case risk classification -- just framework detection and doc-file checks. Single developer project.

**6. AIR Blackbox** (open source, Apache 2.0, 21 repos)
- **Offer**: OpenAI-compatible reverse proxy + compliance scanner. `pip install air-compliance && air-compliance scan .`
- **Features**: Runtime audit logging with HMAC-SHA256 tamper-evident chains. Trust layers for LangChain/CrewAI/AutoGen/OpenAI (~3 lines of setup). ConsentGate for risk-classifying tool calls. InjectionDetector. Maps to 6 EU AI Act articles (9, 10, 11, 12, 14, 15). Claims 97% of AI agent code fails Article 9.
- **Weaknesses**: Focused on runtime observability for AI agents, not codebase compliance scanning. Requires code changes to integrate trust layers. No compliance score. No badge. No PDF reports. No web interface. Agent-framework-specific (LangChain/CrewAI/AutoGen).

**7. Inkog** (new entrant, commercial)
- **Offer**: "Pre-flight check for AI agents." MCP server + CLI. Supports LangChain, CrewAI, and 15+ frameworks.
- **Features**: Vulnerability scanning (infinite loops, prompt injection, missing guardrails). AGENTS.md governance validation. EU AI Act compliance reports (also NIST AI RMF, ISO 42001, OWASP LLM Top 10). MLBOM generation. Multi-agent security auditing. Static analysis -- agent never runs. Runs on every PR.
- **Weaknesses**: Agent-focused (not general AI codebase scanning). Relatively new. No public pricing found. No compliance badge. Targets agent security more than regulatory compliance.

**8. EuConform** (open source, MIT + EUPL-1.2)
- **Offer**: Browser-based tool. 100% offline. Uses local Ollama.
- **Features**: Risk classification (Articles 5-15), bias evaluation using CrowS-Pairs, automatic Annex IV PDF reports. Supports Llama/Mistral/Qwen. WCAG 2.2 AA accessible. GDPR-by-design (no data leaves machine).
- **Weaknesses**: Browser-only (no CLI, no CI/CD integration). Requires local Ollama for LLM-based analysis. Not a code scanner -- it's a questionnaire/assessment tool with bias testing. No GitHub repo scanning. No badge.

**9. Protectron.ai** (new commercial SaaS, launched Jan 2026)
- **Offer**: SaaS platform at EUR 99/month. Free risk assessment.
- **Features**: Questionnaire-based risk classification with automated compliance roadmap. Conformity assessment guidance. EU database registration assistance. Compliance badge (after 30 days of SDK logging). SOC 2 compliant. EU data residency.
- **Weaknesses**: Questionnaire-based, not code scanning. Requires SDK integration for badge. EUR 99/month ongoing cost. New/unproven. No CLI.

**10. AgentBouncr** (open-core, Elastic License v2 core, commercial enterprise)
- **Offer**: Governance middleware for AI agents. Sits between agents and tools.
- **Features**: Permission layer, JSON/YAML policy engine, append-only SHA-256 hash-chained audit trail, injection detection, kill switch. Vendor-agnostic.
- **Weaknesses**: Runtime governance layer, not a compliance scanner. Requires code integration. Enterprise dashboard is commercial. Not EU AI Act-specific.

**11. EU Official Compliance Checker** (free, European Commission)
- **Offer**: Web-based questionnaire at artificialintelligenceact.eu.
- **Features**: Official tool from the EU. Walks through obligations based on your AI system type.
- **Weaknesses**: Self-described as "a simplification" and "still a work in progress." Questionnaire-based, not code scanning. No automation. No CI/CD. No developer tooling.

**12. AI Verify (IMDA Singapore)** (open source, free)
- **Offer**: Desktop toolkit for testing AI models against 11 governance principles.
- **Features**: Standardized tests for transparency, explainability, fairness, robustness, safety. Supports traditional ML and GenAI (as of May 2025 update). 50+ companies piloted. Runs entirely within enterprise environment.
- **Weaknesses**: Singapore-focused governance framework, not EU AI Act-specific. Model testing toolkit, not codebase scanner. Heavy setup. Desktop-only. No web scan. No CI/CD integration.

---

### CodeAuditLab Advantages -- What We Have That Nobody Else Does

| Advantage | Closest Competitor | Their Gap |
|---|---|---|
| **Free instant scan of any public GitHub repo (no signup)** | Nobody offers this. Arkforge requires MCP setup. Protectron needs signup + SDK. Enterprise tools need months of onboarding. | Zero friction to first value. Paste URL, get results. |
| **CLI tool via `pip install isologic`** | Arkforge (MCP-only), AIR Blackbox (agent-specific). Neither is a general codebase scanner installable via pip. | Only general-purpose EU AI Act codebase scanner available as a pip package. |
| **Compliance score (0-100)** | Nobody else calculates a single numeric compliance score from code scanning. Holistic AI has risk scores but from manual assessment. | Quantified, comparable, trackable over time. |
| **Compliance badge for README** | Protectron has a badge but requires 30 days of SDK logging + EUR 99/mo. | Instant badge after free scan. |
| **PDF reports ($9.99)** | EuConform generates PDFs but from questionnaires, not code scans. Enterprise tools charge $10K+. | Code-scan-based PDF at $9.99 vs $10K+. |
| **No data leaves machine (CLI mode)** | EuConform (browser-only). AI Verify (desktop-only). | CLI + offline = CI/CD compatible + air-gapped environments. |
| **File:line detection with article references** | Arkforge detects frameworks but no risk classification. AIR Blackbox maps to 6 articles but only for agent code. | Specific `src/hiring/ranker.py:15` with "Annex III, 4(a-b)" -- actionable for developers. |
| **Countdown to deadline** | Some marketing pages mention it. No tool integrates it into scan results. | Urgency built into the product experience. |
| **30+ AI frameworks detected (Python + JS/TS)** | Arkforge covers similar breadth. Others are narrower. | Broadest framework coverage in the developer tool tier. |
| **CI/CD exit codes** | Nobody else in this category has meaningful exit codes for pipeline integration. | `isologic audit .` returns 0/1/2 -- plug directly into GitHub Actions. |

---

### Gaps to Close -- What Competitors Offer That CodeAuditLab Lacks

| Gap | Who Has It | Priority | Rationale |
|---|---|---|---|
| **Runtime monitoring / observability** | AIR Blackbox, Arthur AI, AgentBouncr | LOW | Different product category. Not needed for launch positioning. |
| **Bias testing / fairness evaluation** | Holistic AI, EuConform, AI Verify | MEDIUM | Differentiator for high-risk classification. Could add as a premium feature. |
| **MCP server integration** | Arkforge, Inkog, AIR Blackbox | HIGH | MCP is the emerging developer standard. Wrapping isologic as an MCP server would make it available in Claude Desktop, Cursor, and other AI coding tools -- massive distribution channel. |
| **AGENTS.md / governance file validation** | Inkog | LOW | Nice-to-have. Niche to agent developers. |
| **Tamper-evident audit trails** | AIR Blackbox, AgentBouncr | LOW | Runtime feature, not static analysis. |
| **ISO 42001 / NIST RMF cross-mapping** | Vanta, Trail, Inkog, Holistic AI | MEDIUM | Enterprise buyers want to see framework coverage beyond just EU AI Act. Add to PDF report. |
| **Remediation guidance / auto-fix** | Nobody does this well yet | HIGH | First-mover opportunity. "Here's the violation, here's the fix" -- like how ESLint offers `--fix`. Could be the killer differentiator. |
| **AST-based analysis (vs regex)** | Nobody in this tier | MEDIUM | Mentioned in isologic's own Contributing section. Would reduce false positives and increase credibility. |
| **Dependency file scanning** | Arkforge scans requirements.txt/package.json | HIGH | Low-hanging fruit. Detect AI frameworks from dependency manifests without scanning source code. Already noted as a TODO. |
| **Multi-framework compliance reports** | Inkog (OWASP LLM Top 10 + NIST + ISO) | MEDIUM | "One scan, multiple frameworks" is compelling for enterprise buyers. |
| **Stripe payment integration for PDF** | Not clear if implemented | HIGH | The $9.99 PDF is the revenue model. Must be frictionless. |
| **SEO/content marketing around deadline** | Protectron, Trail, Arkforge (aggressive DEV.to posting) | HIGH | Arkforge's CEO has 8+ DEV.to posts driving traffic. CodeAuditLab needs similar content velocity before Aug 2026. |

---

### Positioning Summary

CodeAuditLab occupies a unique niche: **the only tool that combines free web-based GitHub repo scanning, a pip-installable CLI, compliance scoring, README badges, and affordable PDF reports -- all focused specifically on EU AI Act code compliance.**

The enterprise platforms (Credo AI, Holistic AI, Vanta, Trail) are governance tools for compliance teams, priced at $10K-$200K/yr, with zero code scanning capability. They are not competitors -- they are potential integration partners.

The developer tools (Arkforge, AIR Blackbox, Inkog, EuConform) each address a narrow slice: agent-only scanning, MCP-only access, runtime-only monitoring, or browser-only questionnaires. None offer the full loop of scan-classify-score-badge-report that CodeAuditLab delivers.

**Launch messaging should emphasize:**
1. "Paste a GitHub URL. Get your compliance score in 30 seconds. No signup."
2. "143 days until EUR 35M fines. Do you know which of your AI systems are affected?"
3. "$9.99 PDF report vs $50K enterprise governance platforms"
4. "`pip install isologic` -- EU AI Act compliance in your CI/CD pipeline"
5. "No data leaves your machine. No AI APIs called. Pure static analysis."

**Highest-priority gaps to close before launch:**
1. Add dependency file scanning (requirements.txt, package.json) -- quick win
2. Build an MCP server wrapper -- massive distribution through AI coding tools
3. Get content marketing live (DEV.to, Hacker News Show HN, r/MachineLearning)
4. Confirm Stripe is wired for PDF purchase flow

---

Sources:
- [Trail - AI Governance Copilot](https://www.trail-ml.com/)
- [Holistic AI Platform](https://www.holisticai.com/)
- [Credo AI - Pricing & Features](https://www.softwaresuggest.com/credo-ai)
- [Credo AI - AWS Marketplace](https://aws.amazon.com/marketplace/pp/prodview-x67krdatcdday)
- [Vanta EU AI Act](https://www.vanta.com/products/eu-ai-act)
- [Vanta Pricing](https://www.secureleap.tech/blog/vanta-review-pricing-top-alternatives-for-compliance-automation)
- [AI Verify Foundation](https://aiverifyfoundation.sg/what-is-ai-verify/)
- [Arkforge MCP EU AI Act Scanner - GitHub](https://github.com/ark-forge/mcp-eu-ai-act)
- [AIR Blackbox - GitHub](https://github.com/airblackbox)
- [AIR Blackbox Show HN](https://news.ycombinator.com/item?id=47247314)
- [Inkog - Pre-Flight Check for AI Agents](https://inkog.io)
- [EuConform - GitHub](https://github.com/Hiepler/EuConform)
- [EuConform Show HN](https://news.ycombinator.com/item?id=46557823)
- [Protectron.ai](https://protectron.ai/)
- [Protectron Medium Article](https://medium.com/@cyriaczeh/how-i-built-an-eu-ai-act-compliance-saas-platform-in-72-hours-and-why-enterprise-tools-charging-28730ae3000d)
- [AgentBouncr - GitHub](https://github.com/agentbouncr/agentbouncr)
- [AgentBouncr Show HN](https://news.ycombinator.com/item?id=47087311)
- [EU AI Act Compliance Checker (Official)](https://artificialintelligenceact.eu/assessment/eu-ai-act-compliance-checker/)
- [Top 13 AI Compliance Tools - Centraleyes](https://www.centraleyes.com/top-ai-compliance-tools/)
- [5 AI Compliance Companies - Sprinto](https://sprinto.com/blog/ai-compliance-companies/)
- [Best EU AI Act Compliance Software - VenVera](https://venvera.com/best/eu-ai-act-compliance-software/)
- [Best Tools for AI Governance 2026 - Maxim](https://www.getmaxim.ai/articles/best-tools-for-ai-governance-in-2026/)
- [Hacker News: Ask HN - How are you handling EU AI Act compliance](https://news.ycombinator.com/item?id=47169864)