# Contributing to Isologic

## Setup

```bash
git clone https://github.com/masterkenai121/isologic.git
cd isologic
pip install -e ".[dev]"
pytest
```

Requires Python 3.10+.

## Adding Detection Patterns

Detection patterns live in `src/isologic/scanner.py` as three lists of `(regex, framework_name, description)` tuples:

- **`IMPORT_PATTERNS`** -- Python import/instantiation patterns (e.g., `import openai`, `Anthropic()`).
- **`JS_PATTERNS`** -- JavaScript/TypeScript import patterns (e.g., `require("openai")`, `import "@anthropic-ai/sdk"`).
- **`USE_CASE_PATTERNS`** -- Language-agnostic patterns that identify specific AI use cases (e.g., `face_recognition`, `credit_scor`, `resume_pars`). These drive risk classification and take priority over framework patterns.

To add a new pattern:

1. Pick the correct list based on what you are detecting.
2. Add a tuple: `(r"your_regex", "framework-id", "Human-readable description")`.
3. Use non-capturing groups `(?:...)` and keep regexes case-insensitive-safe.
4. Add a test that verifies your pattern matches expected code and does not false-positive on unrelated code.

## Adding Risk Classification Rules

Classification rules live in `src/isologic/classifier.py` as two dictionaries:

- **`USE_CASE_RULES`** -- Keyed by use-case ID (matching `framework` field from `USE_CASE_PATTERNS`). These are checked first and represent specific high-risk or prohibited applications. Each value is a tuple of `(RiskLevel, annex_reference, reason, obligations_list, deadline)`.

- **`FRAMEWORK_RULES`** -- Keyed by framework ID (matching `framework` field from `IMPORT_PATTERNS` / `JS_PATTERNS`). Used when no use-case rule matches. Same tuple structure.

Use-case rules always take priority over framework rules. When adding a rule, cite the specific EU AI Act article or annex reference, and include actionable obligations.

## Running Tests

```bash
pytest                  # run all tests
pytest -v               # verbose output
pytest --cov=isologic   # with coverage
```

## Pull Request Process

1. Fork the repository and create a branch from `main`.
2. Make your changes. Add tests for new patterns or rules.
3. Run `pytest` and `ruff check src/` before submitting.
4. Open a pull request with a clear description of what changed and why.

## Areas That Need Work

- AST-based analysis for Python (reduce false positives from regex matching)
- More framework and use-case detection patterns
- Dependency file scanning (`requirements.txt`, `package.json`, `pyproject.toml`)
- Docker and deployment config scanning
- Expanded test coverage
