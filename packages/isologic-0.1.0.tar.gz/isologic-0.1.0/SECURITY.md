# Security Policy

## How Isologic Works

Isologic is a local static analysis tool. When you run it:

- All scanning happens on your machine. No code, file contents, or scan results are transmitted anywhere.
- No network requests are made. No AI APIs, telemetry endpoints, or external services are contacted during scanning.
- No data is collected. Isologic reads files, matches regex patterns, and writes reports locally.

## Reporting Security Issues

If you discover a security vulnerability in Isologic, please report it by opening an issue at:

https://github.com/masterkenai121/isologic/issues

Include a description of the issue, steps to reproduce, and the potential impact. We will respond as quickly as possible.

## Scope

Isologic is a developer tool that reads source files and produces compliance reports. It does not:

- Execute or evaluate scanned code
- Install dependencies or modify your project
- Access credentials, API keys, or secrets (config file scanning only checks for service name references, not key values)
