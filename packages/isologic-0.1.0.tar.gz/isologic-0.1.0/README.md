# isologic

**EU AI Act compliance scanner for codebases.**

[![PyPI version](https://img.shields.io/pypi/v/isologic.svg?color=blue&logo=pypi&logoColor=white)](https://pypi.org/project/isologic)
[![Python 3.10+](https://img.shields.io/badge/Python-3.10%2B-blue?logo=python&logoColor=white)](https://www.python.org/downloads/release/python-3100/)
[![License](https://img.shields.io/badge/License-Apache%202.0-yellow.svg)](LICENSE)
[![CI](https://github.com/masterkenai121/isologic/workflows/CI/badge.svg)](https://github.com/masterkenai121/isologic/actions?query=workflow%3ACI)

Detect, classify, and audit AI systems in your code against EU AI Act (Regulation 2024/1689) requirements. Get actionable compliance reports with risk classifications, obligation checklists, and enforcement deadlines.

```
$ isologic audit ./my-project

╭──── isologic audit ────╮
│ Isologic EU AI Act      │
│ Compliance Audit        │
│ Files scanned: 847      │
╰────────────────────────╯

       Risk Summary
┌──────────────┬───────┬──────────────────────────────────┐
│ Risk Level   │ Count │ Status                           │
├──────────────┼───────┼──────────────────────────────────┤
│ HIGH         │     2 │ Conformity assessment required   │
│ GPAI         │     3 │ GPAI obligations (Articles 51-56)│
│ LIMITED      │     1 │ Transparency obligations apply   │
│ MINIMAL      │     1 │ No mandatory obligations         │
└──────────────┴───────┴──────────────────────────────────┘
```

## Why

The EU AI Act is now law. Key deadlines:

| Date | What |
|------|------|
| **Feb 2, 2025** | Prohibited AI practices enforceable |
| **Aug 2, 2025** | GPAI model obligations in effect |
| **Aug 2, 2026** | High-risk AI system requirements |
| **Aug 2, 2027** | High-risk AI in regulated products |

Penalties: up to **EUR 35M or 7% of global annual turnover**.

Most companies using AI have no idea which of their systems are affected, what risk category they fall into, or what they need to do. `isologic` scans your codebase and tells you.

## Install

```bash
pip install isologic
```

Or install from source:

```bash
git clone https://github.com/masterkenai121/isologic.git
cd isologic
pip install -e .
```

Requires Python 3.10+.

## Usage

### Scan a project

```bash
isologic audit .
isologic audit ./my-project
isologic audit /path/to/code
```

### Save reports

```bash
# JSON report
isologic audit . -o report.json

# Markdown report
isologic audit . -f md -o compliance-report

# JSON to stdout (for piping)
isologic audit . --json | jq '.summary'
```

### CI/CD integration

`isologic` returns meaningful exit codes:

| Exit Code | Meaning |
|-----------|---------|
| 0 | No high-risk or prohibited AI detected |
| 1 | High-risk AI systems found |
| 2 | Prohibited (unacceptable) AI practices found |

```yaml
# GitHub Actions example
- name: EU AI Act compliance check
  run: |
    pip install isologic
    isologic audit . --json -o compliance-report.json
```

### EU AI Act reference

```bash
isologic info
```

Shows key dates, risk categories, and penalties.

## What it detects

### AI Frameworks (30+)

Python: OpenAI, Anthropic, Google GenAI, Vertex AI, HuggingFace (Transformers, Diffusers, Datasets), LangChain, LangGraph, CrewAI, AutoGen, Swarm, PyTorch, TensorFlow, Keras, scikit-learn, Ollama, LiteLLM, Cohere, Mistral, Replicate, Stability AI, AWS Bedrock, Azure OpenAI

JavaScript/TypeScript: OpenAI, Anthropic, Google GenAI, LangChain, Vercel AI SDK, Replicate, Cohere, HuggingFace Inference, Ollama, Mistral

Config files: API key references, service configurations

### AI Use Cases

| Use Case | Risk Level | EU AI Act Reference |
|----------|-----------|-------------------|
| Biometric identification | Unacceptable/High | Article 5 / Annex III, 1 |
| Emotion recognition | Unacceptable | Article 5(1)(f) |
| Recruitment / hiring AI | High | Annex III, 4 |
| Credit scoring | High | Annex III, 5(b) |
| Medical diagnosis | High | Annex III, 5(c) |
| Education assessment | High | Annex III, 3(a) |
| Law enforcement | High | Annex III, 6-7 |
| Autonomous vehicles | High | Annex I / Annex III, 2 |
| RAG / retrieval systems | Limited | Article 50 |
| AI agents / tool use | Limited | Article 50 |
| Content generation | Limited | Article 50 |

### Risk Classification

Each detected AI system is classified into one of six risk levels:

- **UNACCEPTABLE** — Prohibited practices. Must cease immediately.
- **HIGH** — Requires conformity assessment, QMS, CE marking, EU database registration.
- **LIMITED** — Transparency obligations (users must know they're interacting with AI).
- **GPAI** — General-purpose AI model obligations (Articles 51-56).
- **MINIMAL** — No mandatory obligations.
- **UNKNOWN** — Manual assessment needed.

## Output formats

### Terminal (default)

Rich, colored terminal output with summary tables, detailed classifications, and action items.

### JSON

```json
{
  "version": "0.1.0",
  "timestamp": "2026-03-03T12:00:00+00:00",
  "path": "/path/to/project",
  "files_scanned": 847,
  "summary": {
    "high": 2,
    "gpai": 3,
    "limited": 1
  },
  "classifications": [
    {
      "file": "src/hiring/ranker.py",
      "line": 15,
      "framework": "recruitment",
      "risk_level": "high",
      "annex": "Annex III, 4(a-b)",
      "obligations": ["Conduct conformity assessment before Aug 2, 2026", "..."],
      "deadline": "Aug 2, 2026"
    }
  ]
}
```

### Markdown

Full compliance report with checkboxes for required actions, suitable for sharing with legal/compliance teams.

## How it works

1. **Scan** — Recursively walks your codebase, matching Python/JS/TS files against 60+ regex patterns for AI framework imports, API calls, and use-case indicators.
2. **Classify** — Maps each detection to EU AI Act risk categories using use-case rules (highest priority) and framework rules. Deduplicates per file.
3. **Report** — Generates actionable output with specific EU AI Act article references, obligation checklists, and enforcement deadlines.

No code leaves your machine. No AI APIs are called. Pure static analysis.

## Limitations

- **False positives from pattern matching** — isologic uses regex, not AST analysis. A variable named `face_recognition_config` in a gaming app will trigger a biometric identification flag even though no actual biometric processing occurs. Similarly, a comment like `# TODO: add credit scoring` will flag as high-risk credit scoring.
- **Cannot determine deployment context** — the same `openai.ChatCompletion.create()` call could power a harmless chatbot (minimal risk) or an automated hiring decision (high risk). isologic flags the detection; you determine the context.
- **Use-case detection relies on naming conventions** — if your recruitment AI module is named `candidate_utils.py` instead of something containing "hiring" or "recruit", it may be missed.
- **Framework detection is not risk classification** — detecting `import tensorflow` tells you AI is present, not what risk category it belongs to. Risk depends on application, which requires human judgment.
- **Not legal advice** — isologic is an engineering tool that surfaces potential compliance obligations. It does not replace qualified legal counsel on EU AI Act compliance.

## FAQ

**Q: Does isologic execute or evaluate my code?**
A: No. It only reads files and matches regex patterns. No code is executed.

**Q: What if isologic flags a false positive?**
A: Pattern-based detection will produce some false positives. The tool flags potential issues; human review decides actual risk.

**Q: Does isologic send my code anywhere?**
A: No. All scanning is local. Zero network calls, zero telemetry.

**Q: Can I get a compliance badge for my README?**
A: Yes. Scan any public repo at [codeauditlab.com](https://codeauditlab.com) and get a compliance badge.

**Q: Does it support JavaScript/TypeScript?**
A: Yes. Scans .js, .ts, .jsx, .tsx, .mjs, and .cjs files alongside Python.

## Contributing

Pull requests welcome. Areas that need work:

- More framework detection patterns
- AST-based analysis for Python
- Dependency file scanning (requirements.txt, package.json)
- Docker/deployment config scanning
- More use-case detection patterns
- Test coverage

## License

Apache 2.0
