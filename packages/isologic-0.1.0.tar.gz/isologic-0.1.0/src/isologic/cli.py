"""Isologic CLI — EU AI Act compliance scanner."""

from __future__ import annotations

import sys
from pathlib import Path

import click
from rich.console import Console

from isologic import __version__
from isologic.classifier import classify
from isologic.reporter import print_report, save_report, to_json
from isologic.scanner import scan

console = Console()


@click.group()
@click.version_option(version=__version__, prog_name="isologic")
def main():
    """Isologic — EU AI Act compliance scanner.

    Detect, classify, and audit AI systems in your codebase against
    EU AI Act (Regulation 2024/1689) requirements.
    """


@main.command()
@click.argument("path", default=".", type=click.Path(exists=True))
@click.option("--output", "-o", type=click.Path(), help="Save report to file")
@click.option("--format", "-f", "fmt", type=click.Choice(["json", "md"]), default="json",
              help="Output format (json or md)")
@click.option("--json", "json_stdout", is_flag=True, help="Output JSON to stdout")
@click.option("--max-files", type=int, default=10_000, help="Max files to scan")
def audit(path: str, output: str | None, fmt: str, json_stdout: bool, max_files: int):
    """Scan a codebase for AI systems and classify per EU AI Act.

    Scans Python and JavaScript/TypeScript files for AI framework usage,
    API calls, and use-case patterns. Classifies each detected system
    by EU AI Act risk level (unacceptable, high, limited, minimal, GPAI).

    Examples:

        isologic audit .

        isologic audit ./my-project --output report.json

        isologic audit /path/to/code --format md -o compliance-report

        isologic audit . --json | jq '.summary'
    """
    target = Path(path).resolve()

    if not json_stdout:
        console.print(f"\n[bold blue]Scanning:[/bold blue] {target}")

    # Scan
    result = scan(target, max_files=max_files)

    # Classify
    report = classify(result)

    # Output
    if json_stdout:
        click.echo(to_json(report))
        return

    print_report(report, console)

    if output:
        saved = save_report(report, output, fmt)
        console.print(f"[green]Report saved to: {saved}[/green]\n")

    # Exit code: 2 for unacceptable, 1 for high-risk, 0 otherwise
    if report.has_unacceptable:
        sys.exit(2)
    elif report.has_high_risk:
        sys.exit(1)


@main.command()
def info():
    """Show EU AI Act key dates and risk categories."""
    console.print()
    console.print("[bold]EU AI Act (Regulation 2024/1689) — Key Information[/bold]")
    console.print()

    console.print("[bold]Key Dates:[/bold]")
    console.print("  [red]Feb 2, 2025[/red]  — Prohibited AI practices enforceable")
    console.print("  [magenta]Aug 2, 2025[/magenta]  — GPAI model obligations in effect")
    console.print("  [yellow]Aug 2, 2026[/yellow]  — High-risk AI system requirements (Annex III)")
    console.print("  [cyan]Aug 2, 2027[/cyan]  — High-risk AI in regulated products (Annex I)")
    console.print()

    console.print("[bold]Risk Categories:[/bold]")
    console.print("  [bold red]UNACCEPTABLE[/bold red] — Banned. Social scoring, real-time public biometric ID,")
    console.print("                    emotion recognition at work/school, manipulative AI.")
    console.print("  [bold yellow]HIGH RISK[/bold yellow]     — Requires conformity assessment, QMS, CE marking,")
    console.print("                    EU database registration. Annex III categories:")
    console.print("                    recruitment, credit scoring, education, law enforcement,")
    console.print("                    migration, critical infrastructure, medical devices.")
    console.print("  [cyan]LIMITED[/cyan]       — Transparency obligations. Chatbots, deepfakes,")
    console.print("                    emotion recognition (non-banned contexts).")
    console.print("  [green]MINIMAL[/green]       — No mandatory obligations. Spam filters, games, etc.")
    console.print("  [magenta]GPAI[/magenta]          — General-purpose AI model obligations (Articles 51-56).")
    console.print()

    console.print("[bold]Penalties:[/bold]")
    console.print("  Prohibited practices:  EUR 35M or 7% of global annual turnover")
    console.print("  High-risk violations:  EUR 15M or 3% of global annual turnover")
    console.print("  Incorrect information: EUR 7.5M or 1% of global annual turnover")
    console.print()

    console.print("[bold]Reference:[/bold] https://artificialintelligenceact.eu/")
    console.print()


if __name__ == "__main__":
    main()
