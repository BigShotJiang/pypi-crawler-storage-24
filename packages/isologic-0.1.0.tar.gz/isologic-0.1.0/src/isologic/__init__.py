"""Isologic — EU AI Act compliance scanner for codebases."""

__version__ = "0.1.0"
