"""Generate compliance reports in multiple formats."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich.tree import Tree

from isologic.classifier import ClassificationReport, RiskLevel

RISK_COLORS = {
    RiskLevel.UNACCEPTABLE: "bold red",
    RiskLevel.HIGH: "bold yellow",
    RiskLevel.LIMITED: "cyan",
    RiskLevel.MINIMAL: "green",
    RiskLevel.GPAI: "magenta",
    RiskLevel.UNKNOWN: "dim",
}

RISK_ICONS = {
    RiskLevel.UNACCEPTABLE: "XX",
    RiskLevel.HIGH: "!!",
    RiskLevel.LIMITED: "->",
    RiskLevel.MINIMAL: "ok",
    RiskLevel.GPAI: "GP",
    RiskLevel.UNKNOWN: "??",
}


def compliance_score(summary: dict[str, int]) -> float:
    """Calculate 0-100 compliance score. Higher = more compliant."""
    weights = {"unacceptable": -50, "high": -20, "limited": -5, "gpai": -3, "minimal": 0, "unknown": -10}
    total_systems = sum(summary.values()) or 1
    penalty = sum(summary.get(level, 0) * w for level, w in weights.items())
    score = max(0.0, min(100.0, 100.0 + (penalty / total_systems)))
    return round(score, 1)


def print_report(report: ClassificationReport, console: Console | None = None) -> None:
    """Print a rich terminal report."""
    console = console or Console()
    scan = report.scan_result

    # Header
    console.print()
    console.print(
        Panel(
            f"[bold]Isologic EU AI Act Compliance Audit[/bold]\n"
            f"Path: {scan.path}\n"
            f"Date: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}\n"
            f"Files scanned: {scan.files_scanned}",
            title="[bold blue]isologic audit[/bold blue]",
            border_style="blue",
        )
    )

    if scan.errors:
        for err in scan.errors:
            console.print(f"  [yellow]Warning: {err}[/yellow]")

    if not report.classifications:
        console.print("\n  [green]No AI systems detected in this codebase.[/green]")
        console.print("  If you expected detections, check that the path contains Python/JS source files.\n")
        return

    # Summary
    console.print()
    summary_table = Table(title="Risk Summary", show_header=True, header_style="bold")
    summary_table.add_column("Risk Level", style="bold")
    summary_table.add_column("Count", justify="right")
    summary_table.add_column("Status")

    risk_order = [
        RiskLevel.UNACCEPTABLE, RiskLevel.HIGH, RiskLevel.LIMITED,
        RiskLevel.GPAI, RiskLevel.MINIMAL, RiskLevel.UNKNOWN,
    ]
    for level in risk_order:
        count = report.summary.get(level, 0)
        if count == 0:
            continue
        color = RISK_COLORS[level]
        if level == RiskLevel.UNACCEPTABLE:
            status = "[bold red]PROHIBITED - IMMEDIATE ACTION REQUIRED[/bold red]"
        elif level == RiskLevel.HIGH:
            status = "[yellow]Conformity assessment required by deadline[/yellow]"
        elif level == RiskLevel.GPAI:
            status = "[magenta]GPAI obligations (Articles 51-56)[/magenta]"
        elif level == RiskLevel.LIMITED:
            status = "[cyan]Transparency obligations apply[/cyan]"
        elif level == RiskLevel.MINIMAL:
            status = "[green]No mandatory obligations[/green]"
        else:
            status = "[dim]Manual assessment needed[/dim]"
        summary_table.add_row(f"[{color}]{level.value.upper()}[/{color}]", str(count), status)

    console.print(summary_table)

    # Frameworks detected
    console.print()
    fw_table = Table(title="AI Frameworks Detected", show_header=True, header_style="bold")
    fw_table.add_column("Framework")
    fw_table.add_column("Occurrences", justify="right")
    for fw, count in sorted(scan.frameworks.items(), key=lambda x: -x[1]):
        fw_table.add_row(fw, str(count))
    console.print(fw_table)

    # Use cases detected
    if scan.use_cases:
        console.print()
        uc_table = Table(title="AI Use Cases Detected", show_header=True, header_style="bold")
        uc_table.add_column("Use Case")
        uc_table.add_column("Occurrences", justify="right")
        for uc, count in sorted(scan.use_cases.items(), key=lambda x: -x[1]):
            uc_table.add_row(uc, str(count))
        console.print(uc_table)

    # Detailed classifications
    console.print()
    console.print("[bold]Detailed Classifications[/bold]")
    console.print()

    for i, c in enumerate(report.classifications, 1):
        d = c.detection
        color = RISK_COLORS[c.risk_level]
        icon = RISK_ICONS[c.risk_level]

        console.print(f"  [{color}][{icon}] {c.risk_level.value.upper()}[/{color}] — {d.framework}")
        console.print(f"      File: {d.file}:{d.line}")
        console.print(f"      {d.description}")
        console.print(f"      Annex: {c.annex}")
        console.print(f"      Deadline: {c.deadline}")
        console.print(f"      [dim]{c.reason[:200]}[/dim]")
        console.print()

    # Action items
    if report.requires_action:
        console.print()
        action_tree = Tree("[bold red]REQUIRED ACTIONS[/bold red]")

        if report.has_unacceptable:
            branch = action_tree.add("[bold red]UNACCEPTABLE RISK — IMMEDIATE[/bold red]")
            for c in report.classifications:
                if c.risk_level == RiskLevel.UNACCEPTABLE:
                    sub = branch.add(f"{c.detection.framework} ({c.detection.file})")
                    for ob in c.obligations:
                        sub.add(ob)

        if report.has_high_risk:
            branch = action_tree.add("[bold yellow]HIGH RISK — Before Aug 2, 2026[/bold yellow]")
            for c in report.classifications:
                if c.risk_level == RiskLevel.HIGH:
                    sub = branch.add(f"{c.detection.framework} ({c.detection.file})")
                    for ob in c.obligations:
                        sub.add(ob)

        console.print(action_tree)

    # Footer
    console.print()
    total = sum(report.summary.values())
    console.print(
        Panel(
            f"Total AI systems classified: {total}\n"
            f"Unacceptable: {report.summary.get(RiskLevel.UNACCEPTABLE, 0)} | "
            f"High: {report.summary.get(RiskLevel.HIGH, 0)} | "
            f"Limited: {report.summary.get(RiskLevel.LIMITED, 0)} | "
            f"GPAI: {report.summary.get(RiskLevel.GPAI, 0)} | "
            f"Minimal: {report.summary.get(RiskLevel.MINIMAL, 0)} | "
            f"Unknown: {report.summary.get(RiskLevel.UNKNOWN, 0)}\n\n"
            f"[dim]Isologic v0.1.0 — isologic.ai — Apache 2.0 License[/dim]",
            title="[bold]Audit Complete[/bold]",
            border_style="blue",
        )
    )

    # Compliance score
    score_val = compliance_score({level.value: count for level, count in report.summary.items()})
    if score_val >= 80:
        score_color = "green"
    elif score_val >= 50:
        score_color = "yellow"
    else:
        score_color = "red"
    console.print(f"\n[bold]Compliance Score:[/bold] [{score_color}]{score_val}/100[/{score_color}]")

    # Deadline countdown
    deadline = datetime(2026, 8, 2, tzinfo=timezone.utc)
    days_left = max(0, (deadline - datetime.now(timezone.utc)).days)
    if days_left > 0:
        console.print(f"[dim]{days_left} days until Aug 2, 2026 — high-risk AI system rules enforceable[/dim]")
    else:
        console.print("[bold red]EU AI Act high-risk rules are NOW enforceable[/bold red]")

    console.print()


def to_json(report: ClassificationReport) -> str:
    """Export report as JSON."""
    data = {
        "version": "0.1.0",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "path": report.scan_result.path,
        "files_scanned": report.scan_result.files_scanned,
        "summary": {level.value: count for level, count in report.summary.items()},
        "compliance_score": compliance_score({level.value: count for level, count in report.summary.items()}),
        "frameworks_detected": report.scan_result.frameworks,
        "use_cases_detected": report.scan_result.use_cases,
        "classifications": [
            {
                "file": c.detection.file,
                "line": c.detection.line,
                "framework": c.detection.framework,
                "description": c.detection.description,
                "risk_level": c.risk_level.value,
                "annex": c.annex,
                "reason": c.reason,
                "obligations": c.obligations,
                "deadline": c.deadline,
            }
            for c in report.classifications
        ],
        "errors": report.scan_result.errors,
    }
    return json.dumps(data, indent=2)


def to_markdown(report: ClassificationReport) -> str:
    """Export report as Markdown."""
    lines = [
        "# Isologic EU AI Act Compliance Audit Report",
        "",
        f"**Path:** `{report.scan_result.path}`  ",
        f"**Date:** {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M UTC')}  ",
        f"**Files scanned:** {report.scan_result.files_scanned}  ",
        "",
        "## Risk Summary",
        "",
        "| Risk Level | Count | Status |",
        "|-----------|-------|--------|",
    ]

    status_text = {
        RiskLevel.UNACCEPTABLE: "PROHIBITED — IMMEDIATE ACTION",
        RiskLevel.HIGH: "Conformity assessment required",
        RiskLevel.LIMITED: "Transparency obligations",
        RiskLevel.GPAI: "GPAI obligations (Art. 51-56)",
        RiskLevel.MINIMAL: "No mandatory obligations",
        RiskLevel.UNKNOWN: "Manual assessment needed",
    }

    for level in [RiskLevel.UNACCEPTABLE, RiskLevel.HIGH, RiskLevel.LIMITED,
                  RiskLevel.GPAI, RiskLevel.MINIMAL, RiskLevel.UNKNOWN]:
        count = report.summary.get(level, 0)
        if count > 0:
            lines.append(f"| **{level.value.upper()}** | {count} | {status_text[level]} |")

    score_val = compliance_score({level.value: count for level, count in report.summary.items()})
    lines.append(f"\n## Compliance Score: {score_val}/100\n")

    lines.extend(["", "## Detected AI Systems", ""])

    for c in report.classifications:
        d = c.detection
        lines.extend([
            f"### [{c.risk_level.value.upper()}] {d.framework}",
            "",
            f"- **File:** `{d.file}:{d.line}`",
            f"- **Description:** {d.description}",
            f"- **EU AI Act Reference:** {c.annex}",
            f"- **Deadline:** {c.deadline}",
            f"- **Assessment:** {c.reason}",
            "",
            "**Required Actions:**",
            "",
        ])
        for ob in c.obligations:
            lines.append(f"- [ ] {ob}")
        lines.append("")

    lines.extend([
        "---",
        "",
        f"*Generated by Isologic v0.1.0 — [isologic.ai](https://isologic.ai) — Apache 2.0*",
    ])

    return "\n".join(lines)


def save_report(report: ClassificationReport, output_path: str, fmt: str = "json") -> str:
    """Save report to file."""
    path = Path(output_path)
    if fmt == "json":
        content = to_json(report)
        if not path.suffix:
            path = path.with_suffix(".json")
    elif fmt == "md":
        content = to_markdown(report)
        if not path.suffix:
            path = path.with_suffix(".md")
    else:
        raise ValueError(f"Unknown format: {fmt}")

    path.write_text(content, encoding="utf-8")
    return str(path)
