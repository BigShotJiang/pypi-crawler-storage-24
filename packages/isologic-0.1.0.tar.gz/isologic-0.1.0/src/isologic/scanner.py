"""Scan codebases for AI system usage patterns."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

# ---------------------------------------------------------------------------
# Detection patterns: (regex, framework_name, description)
# ---------------------------------------------------------------------------

IMPORT_PATTERNS: list[tuple[str, str, str]] = [
    # OpenAI
    (r"(?:from\s+openai|import\s+openai)", "openai", "OpenAI API client"),
    (r"(?:from\s+openai|import\s+openai).*(?:ChatCompletion|chat\.completions)", "openai", "OpenAI Chat Completions"),
    (r"OpenAI\s*\(", "openai", "OpenAI client instantiation"),
    # Anthropic
    (r"(?:from\s+anthropic|import\s+anthropic)", "anthropic", "Anthropic API client"),
    (r"Anthropic\s*\(", "anthropic", "Anthropic client instantiation"),
    # Google / Gemini
    (r"(?:from\s+google\.generativeai|import\s+google\.generativeai)", "google-genai", "Google Generative AI"),
    (r"(?:from\s+vertexai|import\s+vertexai)", "google-vertex", "Google Vertex AI"),
    # HuggingFace
    (r"(?:from\s+transformers|import\s+transformers)", "huggingface", "HuggingFace Transformers"),
    (r"(?:from\s+diffusers|import\s+diffusers)", "huggingface", "HuggingFace Diffusers (image generation)"),
    (r"(?:from\s+datasets|import\s+datasets)", "huggingface", "HuggingFace Datasets"),
    (r"pipeline\s*\(\s*[\"']", "huggingface", "HuggingFace pipeline()"),
    # LangChain
    (r"(?:from\s+langchain|import\s+langchain)", "langchain", "LangChain framework"),
    (r"(?:from\s+langgraph|import\s+langgraph)", "langgraph", "LangGraph agent framework"),
    # Multi-agent frameworks
    (r"(?:from\s+crewai|import\s+crewai)", "crewai", "CrewAI multi-agent framework"),
    (r"(?:from\s+autogen|import\s+autogen)", "autogen", "AutoGen multi-agent framework"),
    (r"(?:from\s+swarm|import\s+swarm)", "swarm", "OpenAI Swarm agent framework"),
    (r"(?:from\s+agency_swarm|import\s+agency_swarm)", "agency-swarm", "Agency Swarm multi-agent"),
    (r"(?:from\s+phidata|import\s+phidata)", "phidata", "Phidata agent framework"),
    # PyTorch / TensorFlow
    (r"(?:from\s+torch|import\s+torch)\b", "pytorch", "PyTorch"),
    (r"(?:from\s+tensorflow|import\s+tensorflow)", "tensorflow", "TensorFlow"),
    (r"(?:from\s+keras|import\s+keras)", "keras", "Keras"),
    # scikit-learn
    (r"(?:from\s+sklearn|import\s+sklearn)", "sklearn", "scikit-learn ML"),
    # Ollama
    (r"(?:from\s+ollama|import\s+ollama)", "ollama", "Ollama local LLM"),
    # LiteLLM / routing
    (r"(?:from\s+litellm|import\s+litellm)", "litellm", "LiteLLM multi-provider router"),
    # Cohere
    (r"(?:from\s+cohere|import\s+cohere)", "cohere", "Cohere API"),
    # Mistral
    (r"(?:from\s+mistralai|import\s+mistralai)", "mistral", "Mistral AI API"),
    # Replicate
    (r"(?:from\s+replicate|import\s+replicate)", "replicate", "Replicate API"),
    # Stability AI
    (r"(?:from\s+stability_sdk|import\s+stability_sdk)", "stability", "Stability AI SDK"),
    # AWS Bedrock
    (r"bedrock-runtime", "aws-bedrock", "AWS Bedrock"),
    (r"(?:from\s+boto3|import\s+boto3).*bedrock", "aws-bedrock", "AWS Bedrock via boto3"),
    # Azure OpenAI
    (r"AzureOpenAI\s*\(", "azure-openai", "Azure OpenAI client"),
    # Groq
    (r"(?:from\s+groq|import\s+groq)", "groq", "Groq API client"),
    (r"Groq\s*\(", "groq", "Groq client instantiation"),
    # Together AI
    (r"(?:from\s+together|import\s+together)\b", "together", "Together AI client"),
    (r"Together\s*\(", "together", "Together AI client instantiation"),
    # Fireworks AI
    (r"(?:from\s+fireworks\.client|import\s+fireworks)", "fireworks", "Fireworks AI client"),
    (r"Fireworks\s*\(", "fireworks", "Fireworks AI client instantiation"),
    # vLLM
    (r"(?:from\s+vllm|import\s+vllm)", "vllm", "vLLM inference engine"),
    # llama-cpp-python
    (r"(?:from\s+llama_cpp|import\s+llama_cpp)", "llama-cpp", "llama-cpp-python bindings"),
    # Instructor
    (r"(?:from\s+instructor|import\s+instructor)", "instructor", "Instructor structured outputs"),
    # DSPy
    (r"(?:from\s+dspy|import\s+dspy)", "dspy", "DSPy framework"),
    # Haystack
    (r"(?:from\s+haystack|import\s+haystack)", "haystack", "Haystack NLP framework"),
    # Unstructured
    (r"(?:from\s+unstructured|import\s+unstructured)", "unstructured", "Unstructured document processing"),
    # Marvin
    (r"(?:from\s+marvin|import\s+marvin)", "marvin", "Marvin AI framework"),
]

# Patterns that suggest specific AI USE CASES (beyond just framework detection)
USE_CASE_PATTERNS: list[tuple[str, str, str]] = [
    # Biometric / face recognition
    (r"(?:face_recognition|deepface|insightface|FaceAnalysis|RetinaFace)", "biometric", "Facial recognition / biometric"),
    (r"(?:emotion[_\s]?detect|sentiment[_\s]?analy|affect[_\s]?recog)", "emotion", "Emotion recognition / sentiment analysis"),
    # Recruitment / HR
    (r"(?:resume[_\s]?pars|cv[_\s]?screen|candidate[_\s]?rank|hiring[_\s]?score)", "recruitment", "AI-assisted recruitment"),
    # Credit / financial scoring
    (r"(?:credit[_\s]?scor|risk[_\s]?scor|loan[_\s]?approv|creditworth)", "credit-scoring", "Credit/risk scoring"),
    # Content generation
    (r"(?:generate|completion|chat).*(?:text|content|response|message)", "content-gen", "AI content generation"),
    # Image generation
    (r"(?:DALL|dall[_-]?e|stable[_\s]?diffusion|midjourney|image[_\s]?generat)", "image-gen", "AI image generation"),
    # Code generation
    (r"(?:code[_\s]?generat|copilot|code[_\s]?complet)", "code-gen", "AI code generation"),
    # Medical / health
    (r"(?:medical[_\s]?diagnos|clinical[_\s]?decision|health[_\s]?predict|patient[_\s]?risk)", "medical", "Medical/health AI"),
    # Education
    (r"(?:student[_\s]?assess|grade[_\s]?predict|learning[_\s]?analy|exam[_\s]?scor)", "education", "Educational assessment AI"),
    # Law enforcement
    (r"(?:predictive[_\s]?polic|crime[_\s]?predict|recidivism|suspect[_\s]?ident)", "law-enforcement", "Law enforcement AI"),
    # Autonomous vehicles
    (r"(?:self[_\s]?driv|autonom[_\s]?vehicl|adas|lane[_\s]?detect)", "autonomous", "Autonomous systems"),
    # RAG / retrieval
    (r"(?:retriev|RAG|vector[_\s]?stor|embeddings?[_\s]?search|chromadb|pinecone|weaviate|qdrant|faiss)", "rag", "Retrieval-augmented generation"),
    # Agent / tool use
    (r"(?:tool[_\s]?use|function[_\s]?call|agent[_\s]?execut|ReAct|tool_choice)", "agent", "AI agent / tool use"),
    # Social scoring
    (r"social[_\s]?scor", "social-scoring", "Social scoring system"),
    # Deepfake
    (r"(?:deepfake|face[_\s]?swap)", "deepfake", "Deepfake / face swap"),
    # Content moderation
    (r"(?:content[_\s]?moderat|toxicity[_\s]?detect)", "content-moderation", "Content moderation / toxicity detection"),
    # Chatbot / conversational AI
    (r"(?:chatbot|conversational[_\s]?ai|virtual[_\s]?assistant)", "chatbot", "Chatbot / conversational AI"),
    # Recommendation engine
    (r"(?:recommend[_\s]?engine|collaborative[_\s]?filter)", "recommendation", "Recommendation engine"),
]

# JavaScript/TypeScript patterns
JS_PATTERNS: list[tuple[str, str, str]] = [
    (r"(?:require|import).*['\"]openai['\"]", "openai", "OpenAI JS SDK"),
    (r"(?:require|import).*['\"]@anthropic-ai/sdk['\"]", "anthropic", "Anthropic JS SDK"),
    (r"(?:require|import).*['\"]@google/generative-ai['\"]", "google-genai", "Google GenAI JS SDK"),
    (r"(?:require|import).*['\"]langchain['\"]", "langchain", "LangChain JS"),
    (r"(?:require|import).*['\"]@langchain/", "langchain", "LangChain JS modules"),
    (r"(?:require|import).*['\"]ai['\"]", "vercel-ai", "Vercel AI SDK"),
    (r"(?:require|import).*['\"]@ai-sdk/", "vercel-ai", "Vercel AI SDK modules"),
    (r"(?:require|import).*['\"]replicate['\"]", "replicate", "Replicate JS SDK"),
    (r"(?:require|import).*['\"]cohere-ai['\"]", "cohere", "Cohere JS SDK"),
    (r"(?:require|import).*['\"]@huggingface/inference['\"]", "huggingface", "HuggingFace Inference JS"),
    (r"(?:require|import).*['\"]ollama['\"]", "ollama", "Ollama JS SDK"),
    (r"(?:require|import).*['\"]@mistralai/", "mistral", "Mistral AI JS SDK"),
    (r"(?:require|import).*['\"]groq-sdk['\"]", "groq", "Groq JS SDK"),
    (r"(?:require|import).*['\"]together-ai['\"]", "together", "Together AI JS SDK"),
    (r"(?:require|import).*['\"]@fireworks-ai/", "fireworks", "Fireworks AI JS SDK"),
    (r"(?:require|import).*['\"]llamaindex['\"]", "llamaindex", "LlamaIndex JS SDK"),
]

EXTENSIONS_PYTHON = {".py", ".pyw"}
EXTENSIONS_JS = {".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs"}
EXTENSIONS_CONFIG = {".json", ".yaml", ".yml", ".toml", ".env"}
SKIP_DIRS = {
    "node_modules", ".git", "__pycache__", ".venv", "venv", "env",
    ".eggs", "dist", "build", ".tox", ".mypy_cache", ".ruff_cache",
    ".pytest_cache", "egg-info", ".next", ".nuxt",
}


@dataclass
class Detection:
    """A single detected AI system usage."""
    file: str
    line: int
    framework: str
    description: str
    snippet: str
    category: str = "framework"  # "framework" or "use-case"


@dataclass
class ScanResult:
    """Aggregated scan results."""
    path: str
    files_scanned: int = 0
    detections: list[Detection] = field(default_factory=list)
    frameworks: dict[str, int] = field(default_factory=dict)
    use_cases: dict[str, int] = field(default_factory=dict)
    errors: list[str] = field(default_factory=list)

    @property
    def total_detections(self) -> int:
        return len(self.detections)

    @property
    def unique_frameworks(self) -> set[str]:
        return set(self.frameworks.keys())

    @property
    def unique_use_cases(self) -> set[str]:
        return set(self.use_cases.keys())


def _should_skip(path: Path) -> bool:
    return any(part in SKIP_DIRS for part in path.parts)


def _scan_file(filepath: Path, patterns: list[tuple[str, str, str]], category: str) -> list[Detection]:
    detections = []
    try:
        content = filepath.read_text(encoding="utf-8", errors="ignore")
    except (OSError, PermissionError):
        return detections

    lines = content.split("\n")
    for line_num, line in enumerate(lines, 1):
        stripped = line.strip()
        if not stripped or stripped.startswith("#") or stripped.startswith("//"):
            continue
        for pattern, framework, description in patterns:
            if re.search(pattern, stripped, re.IGNORECASE):
                detections.append(Detection(
                    file=str(filepath),
                    line=line_num,
                    framework=framework,
                    description=description,
                    snippet=stripped[:120],
                    category=category,
                ))
                break  # one detection per line
    return detections


def _scan_config_files(filepath: Path) -> list[Detection]:
    """Check config files for AI service references."""
    detections = []
    try:
        content = filepath.read_text(encoding="utf-8", errors="ignore").lower()
    except (OSError, PermissionError):
        return detections

    config_hints = [
        ("openai", "openai", "OpenAI API key/config reference"),
        ("anthropic", "anthropic", "Anthropic API key/config reference"),
        ("huggingface", "huggingface", "HuggingFace config reference"),
        ("hugging_face", "huggingface", "HuggingFace config reference"),
        ("bedrock", "aws-bedrock", "AWS Bedrock config reference"),
        ("azure.openai", "azure-openai", "Azure OpenAI config reference"),
        ("vertex_ai", "google-vertex", "Google Vertex AI config reference"),
        ("replicate", "replicate", "Replicate config reference"),
        ("cohere", "cohere", "Cohere config reference"),
        ("mistral", "mistral", "Mistral AI config reference"),
    ]

    for keyword, framework, description in config_hints:
        if keyword in content:
            detections.append(Detection(
                file=str(filepath),
                line=0,
                framework=framework,
                description=description,
                snippet=f"Config file references '{keyword}'",
                category="config",
            ))
    return detections


# AI packages to detect in dependency files
_DEP_AI_PACKAGES: list[tuple[str, str, str]] = [
    ("openai", "openai", "OpenAI API client"),
    ("anthropic", "anthropic", "Anthropic API client"),
    ("langchain", "langchain", "LangChain framework"),
    ("langchain-core", "langchain", "LangChain core"),
    ("langchain-community", "langchain", "LangChain community"),
    ("langchain-openai", "langchain", "LangChain OpenAI integration"),
    ("langgraph", "langgraph", "LangGraph agent framework"),
    ("transformers", "huggingface", "HuggingFace Transformers"),
    ("diffusers", "huggingface", "HuggingFace Diffusers"),
    ("datasets", "huggingface", "HuggingFace Datasets"),
    ("torch", "pytorch", "PyTorch"),
    ("torchvision", "pytorch", "PyTorch Vision"),
    ("torchaudio", "pytorch", "PyTorch Audio"),
    ("tensorflow", "tensorflow", "TensorFlow"),
    ("keras", "keras", "Keras"),
    ("scikit-learn", "sklearn", "scikit-learn"),
    ("sklearn", "sklearn", "scikit-learn"),
    ("ollama", "ollama", "Ollama local LLM"),
    ("litellm", "litellm", "LiteLLM multi-provider router"),
    ("cohere", "cohere", "Cohere API"),
    ("mistralai", "mistral", "Mistral AI API"),
    ("replicate", "replicate", "Replicate API"),
    ("stability-sdk", "stability", "Stability AI SDK"),
    ("boto3", "aws-bedrock", "AWS SDK (possible Bedrock usage)"),
    ("google-generativeai", "google-genai", "Google Generative AI"),
    ("google-cloud-aiplatform", "google-vertex", "Google Vertex AI"),
    ("crewai", "crewai", "CrewAI multi-agent framework"),
    ("autogen", "autogen", "AutoGen multi-agent framework"),
    ("pyautogen", "autogen", "AutoGen multi-agent framework"),
    ("phidata", "phidata", "Phidata agent framework"),
    ("groq", "groq", "Groq API client"),
    ("together", "together", "Together AI client"),
    ("fireworks-ai", "fireworks", "Fireworks AI client"),
    ("vllm", "vllm", "vLLM inference engine"),
    ("llama-cpp-python", "llama-cpp", "llama-cpp-python bindings"),
    ("instructor", "instructor", "Instructor structured outputs"),
    ("dspy-ai", "dspy", "DSPy framework"),
    ("dspy", "dspy", "DSPy framework"),
    ("farm-haystack", "haystack", "Haystack NLP framework"),
    ("haystack-ai", "haystack", "Haystack NLP framework"),
    ("unstructured", "unstructured", "Unstructured document processing"),
    ("marvin", "marvin", "Marvin AI framework"),
    ("chromadb", "rag", "ChromaDB vector store"),
    ("pinecone-client", "rag", "Pinecone vector store"),
    ("weaviate-client", "rag", "Weaviate vector store"),
    ("qdrant-client", "rag", "Qdrant vector store"),
    ("faiss-cpu", "rag", "FAISS vector search"),
    ("faiss-gpu", "rag", "FAISS vector search (GPU)"),
    # JS-specific package names (appear in package.json)
    ("@anthropic-ai/sdk", "anthropic", "Anthropic JS SDK"),
    ("@google/generative-ai", "google-genai", "Google GenAI JS SDK"),
    ("@langchain/core", "langchain", "LangChain JS core"),
    ("@langchain/openai", "langchain", "LangChain OpenAI JS"),
    ("ai", "vercel-ai", "Vercel AI SDK"),
    ("@ai-sdk/openai", "vercel-ai", "Vercel AI SDK OpenAI"),
    ("cohere-ai", "cohere", "Cohere JS SDK"),
    ("@huggingface/inference", "huggingface", "HuggingFace Inference JS"),
    ("@mistralai/mistralai", "mistral", "Mistral AI JS SDK"),
    ("groq-sdk", "groq", "Groq JS SDK"),
    ("together-ai", "together", "Together AI JS SDK"),
    ("@fireworks-ai/client", "fireworks", "Fireworks AI JS SDK"),
    ("llamaindex", "llamaindex", "LlamaIndex JS SDK"),
]

DEPENDENCY_FILES = {"requirements.txt", "Pipfile", "pyproject.toml", "package.json"}


def _scan_dependency_file(filepath: Path) -> list[Detection]:
    """Scan dependency/manifest files for AI package references."""
    detections: list[Detection] = []
    try:
        content = filepath.read_text(encoding="utf-8", errors="ignore")
    except (OSError, PermissionError):
        return detections

    filename = filepath.name
    content_lower = content.lower()

    for pkg_name, framework, description in _DEP_AI_PACKAGES:
        pkg_lower = pkg_name.lower()
        found = False

        if filename == "requirements.txt":
            # Match package name at start of line, possibly with version specifier
            # e.g., "openai>=1.0", "torch", "langchain==0.1.0"
            if re.search(
                r"(?m)^\s*" + re.escape(pkg_lower) + r"(?:\s*[>=<!~\[]|$)",
                content_lower,
            ):
                found = True

        elif filename == "package.json":
            # Match "package-name": "version" in dependencies or devDependencies
            if re.search(
                r"[\"']" + re.escape(pkg_lower) + r"[\"']\s*:",
                content_lower,
            ):
                found = True

        elif filename == "Pipfile":
            # Match package = "version" or package = {version = "..."}
            # Pipfile uses the package name as a key
            if re.search(
                r"(?m)^\s*" + re.escape(pkg_lower) + r"\s*=",
                content_lower,
            ):
                found = True

        elif filename == "pyproject.toml":
            # Match in dependencies list: "package>=version" or as a string in an array
            # Also matches [tool.poetry.dependencies] style
            if re.search(
                r"[\"']" + re.escape(pkg_lower) + r"(?:[\"'\s>=<!~\[])",
                content_lower,
            ):
                found = True

        if found:
            detections.append(Detection(
                file=str(filepath),
                line=0,
                framework=framework,
                description=f"{description} (dependency)",
                snippet=f"Dependency file '{filename}' lists '{pkg_name}'",
                category="dependency",
            ))

    return detections


def scan(path: str | Path, max_files: int = 10_000) -> ScanResult:
    """Scan a directory or file for AI system usage.

    Args:
        path: Directory or file to scan.
        max_files: Safety limit on files to scan.

    Returns:
        ScanResult with all detections.
    """
    path = Path(path).resolve()
    result = ScanResult(path=str(path))

    if path.is_file():
        files = [path]
    elif path.is_dir():
        files = []
        for p in path.rglob("*"):
            if p.is_file() and not _should_skip(p):
                files.append(p)
                if len(files) >= max_files:
                    result.errors.append(f"Hit {max_files} file limit, scan may be incomplete")
                    break
    else:
        result.errors.append(f"Path does not exist: {path}")
        return result

    for fp in files:
        suffix = fp.suffix.lower()
        detections: list[Detection] = []

        if fp.name in DEPENDENCY_FILES:
            detections.extend(_scan_dependency_file(fp))
        elif suffix in EXTENSIONS_PYTHON:
            detections.extend(_scan_file(fp, IMPORT_PATTERNS, "framework"))
            detections.extend(_scan_file(fp, USE_CASE_PATTERNS, "use-case"))
        elif suffix in EXTENSIONS_JS:
            detections.extend(_scan_file(fp, JS_PATTERNS, "framework"))
            detections.extend(_scan_file(fp, USE_CASE_PATTERNS, "use-case"))
        elif suffix in EXTENSIONS_CONFIG:
            detections.extend(_scan_config_files(fp))
        else:
            continue

        result.files_scanned += 1
        result.detections.extend(detections)

        for d in detections:
            if d.category in ("framework", "config", "dependency"):
                result.frameworks[d.framework] = result.frameworks.get(d.framework, 0) + 1
            else:
                result.use_cases[d.framework] = result.use_cases.get(d.framework, 0) + 1

    return result
