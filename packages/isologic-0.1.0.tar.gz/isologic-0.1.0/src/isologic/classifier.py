"""EU AI Act risk classification engine.

Maps detected AI systems to risk categories per EU AI Act (Regulation 2024/1689).
Reference: https://artificialintelligenceact.eu/
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from isologic.scanner import Detection, ScanResult


class RiskLevel(str, Enum):
    UNACCEPTABLE = "unacceptable"
    HIGH = "high"
    LIMITED = "limited"
    MINIMAL = "minimal"
    GPAI = "gpai"  # General-purpose AI — separate obligations
    UNKNOWN = "unknown"


@dataclass
class RiskClassification:
    """Classification of a detected AI system."""
    detection: Detection
    risk_level: RiskLevel
    annex: str  # e.g., "Annex III, 3(a)" or "Article 5"
    reason: str
    obligations: list[str]
    deadline: str  # enforcement deadline


# ---------------------------------------------------------------------------
# Classification rules
# ---------------------------------------------------------------------------

# Use-case based classifications (highest priority — these override framework)
USE_CASE_RULES: dict[str, tuple[RiskLevel, str, str, list[str], str]] = {
    "biometric": (
        RiskLevel.UNACCEPTABLE,
        "Article 5(1)(d-f)",
        "Real-time biometric identification in public spaces is prohibited. "
        "Remote biometric identification for law enforcement is high-risk (Annex III, 1).",
        [
            "IMMEDIATE: Determine if system performs real-time biometric ID in public spaces",
            "If real-time public biometric: MUST CEASE operations (prohibited since Feb 2, 2025)",
            "If remote biometric for law enforcement: requires conformity assessment",
            "If biometric for access control only: may be limited risk — conduct detailed assessment",
        ],
        "Feb 2, 2025 (prohibited practices) / Aug 2, 2026 (high-risk)",
    ),
    "emotion": (
        RiskLevel.UNACCEPTABLE,
        "Article 5(1)(f)",
        "Emotion recognition in workplace and educational institutions is prohibited. "
        "Emotion recognition in other contexts may be limited risk.",
        [
            "IMMEDIATE: Determine context of emotion recognition deployment",
            "If used in workplace or school: MUST CEASE (prohibited since Feb 2, 2025)",
            "If used in other contexts: classify as limited risk, requires transparency",
        ],
        "Feb 2, 2025",
    ),
    "recruitment": (
        RiskLevel.HIGH,
        "Annex III, 4(a-b)",
        "AI used in recruitment, candidate screening, or hiring decisions "
        "is classified as high-risk under Annex III, area 4.",
        [
            "Conduct conformity assessment before Aug 2, 2026",
            "Implement Quality Management System (QMS)",
            "Prepare technical documentation per Article 11",
            "Ensure human oversight per Article 14",
            "Register in EU AI database",
            "Implement bias testing and monitoring",
            "Provide transparency to candidates about AI use",
        ],
        "Aug 2, 2026",
    ),
    "credit-scoring": (
        RiskLevel.HIGH,
        "Annex III, 5(b)",
        "AI used for creditworthiness assessment or credit scoring of natural persons "
        "is high-risk under Annex III, area 5.",
        [
            "Conduct conformity assessment before Aug 2, 2026",
            "Implement QMS per Article 17",
            "Ensure data governance per Article 10",
            "Implement human oversight per Article 14",
            "Provide explanations to affected individuals",
            "Conduct bias and fairness testing",
            "Register in EU AI database",
        ],
        "Aug 2, 2026",
    ),
    "medical": (
        RiskLevel.HIGH,
        "Annex III, 5(c) / Annex I (if medical device)",
        "AI for medical diagnosis or clinical decision support is high-risk. "
        "If classified as a medical device, additional Annex I obligations apply (Aug 2, 2027).",
        [
            "Determine if system qualifies as medical device under MDR 2017/745",
            "Conduct conformity assessment",
            "Implement clinical evaluation per MDR if applicable",
            "Ensure human oversight (clinician in the loop)",
            "Implement data governance for health data (GDPR Article 9)",
            "Register in EU AI database",
        ],
        "Aug 2, 2026 (Annex III) / Aug 2, 2027 (Annex I medical devices)",
    ),
    "education": (
        RiskLevel.HIGH,
        "Annex III, 3(a)",
        "AI used to determine access to or assess students in educational institutions "
        "is high-risk under Annex III, area 3.",
        [
            "Conduct conformity assessment before Aug 2, 2026",
            "Implement QMS",
            "Ensure transparency to students and parents",
            "Implement human oversight for consequential decisions",
            "Conduct bias testing across demographics",
            "Register in EU AI database",
        ],
        "Aug 2, 2026",
    ),
    "law-enforcement": (
        RiskLevel.HIGH,
        "Annex III, 6-7",
        "AI used in law enforcement (profiling, evidence evaluation, crime prediction) "
        "is high-risk under Annex III, areas 6-7.",
        [
            "Conduct fundamental rights impact assessment",
            "Conduct conformity assessment",
            "Implement strict human oversight",
            "Ensure transparency and accountability",
            "Register in EU AI database",
            "Notify national supervisory authority",
        ],
        "Aug 2, 2026",
    ),
    "autonomous": (
        RiskLevel.HIGH,
        "Annex I, Section A / Annex III, 2",
        "Autonomous vehicles and safety-critical AI systems are high-risk.",
        [
            "Conduct conformity assessment per relevant sectoral legislation",
            "Implement safety management system",
            "Ensure human override capability",
            "Extensive testing and validation",
            "Register in EU AI database",
        ],
        "Aug 2, 2027 (Annex I products)",
    ),
    "social-scoring": (
        RiskLevel.UNACCEPTABLE,
        "Article 5(1)(c)",
        "AI systems that evaluate or classify natural persons based on social behaviour "
        "or personal characteristics leading to detrimental treatment (social scoring) "
        "are prohibited under the EU AI Act.",
        [
            "IMMEDIATE: MUST CEASE operations — social scoring is a prohibited practice",
            "No exceptions: prohibition applies to both public and private entities",
            "Review all scoring systems for social-scoring characteristics",
            "Document and remove any social scoring functionality",
        ],
        "Feb 2, 2025 (prohibited practices)",
    ),
    "deepfake": (
        RiskLevel.LIMITED,
        "Article 50(4)",
        "AI systems generating or manipulating image, audio, or video content "
        "(deepfakes) must comply with transparency obligations. Users must disclose "
        "that content has been artificially generated or manipulated.",
        [
            "Label all AI-generated/manipulated content clearly",
            "Implement technical solutions for content provenance (e.g., C2PA)",
            "Ensure transparency to recipients that content is AI-generated",
            "Maintain records of generated deepfake content",
        ],
        "Aug 2, 2026",
    ),
    "content-moderation": (
        RiskLevel.LIMITED,
        "Article 50",
        "AI-based content moderation and toxicity detection systems require transparency. "
        "Users must be informed when AI is used to moderate content.",
        [
            "Disclose AI use in content moderation to users",
            "Implement appeal/review mechanisms for moderation decisions",
            "Ensure human oversight for consequential moderation actions",
            "Document moderation criteria and model performance metrics",
        ],
        "Aug 2, 2026",
    ),
    "chatbot": (
        RiskLevel.LIMITED,
        "Article 50",
        "Chatbots and conversational AI must comply with transparency obligations. "
        "Users must be informed they are interacting with an AI system.",
        [
            "Clearly disclose AI nature of the chatbot to users before interaction",
            "Provide option to request human interaction where appropriate",
            "Document the chatbot's capabilities and limitations",
            "Implement mechanisms to handle user complaints",
        ],
        "Aug 2, 2026",
    ),
    "recommendation": (
        RiskLevel.MINIMAL,
        "No specific high-risk obligations",
        "Recommendation engines and collaborative filtering are typically minimal risk "
        "unless used in contexts that significantly affect individuals (e.g., content "
        "that impacts opinions on political matters).",
        [
            "Verify recommendation system does not fall under high-risk categories",
            "If recommending content that impacts democratic processes: reassess risk level",
            "Consider transparency about AI-driven recommendations to users",
        ],
        "N/A (minimal risk)",
    ),
}

# Framework-based classifications (for when no specific use case is detected)
FRAMEWORK_RULES: dict[str, tuple[RiskLevel, str, str, list[str], str]] = {
    "openai": (
        RiskLevel.GPAI,
        "Article 51-56 (GPAI provisions)",
        "OpenAI models are general-purpose AI. Obligations depend on whether you are a "
        "PROVIDER (building on the API) or DEPLOYER (using outputs). "
        "GPAI providers (OpenAI) have separate obligations under Articles 51-56.",
        [
            "Determine your role: provider vs deployer",
            "If provider (building products on API): ensure downstream transparency",
            "Document which OpenAI models are used and for what purpose",
            "Assess if your APPLICATION (not the model) falls under high-risk categories",
            "Maintain records of API usage for auditing",
        ],
        "Aug 2, 2025 (GPAI rules already in effect)",
    ),
    "anthropic": (
        RiskLevel.GPAI,
        "Article 51-56 (GPAI provisions)",
        "Anthropic Claude models are general-purpose AI with similar obligations to OpenAI.",
        [
            "Determine your role: provider vs deployer",
            "If provider (building products on API): ensure downstream transparency",
            "Document which Claude models are used and for what purpose",
            "Assess if your APPLICATION falls under high-risk categories",
            "Maintain records of API usage for auditing",
        ],
        "Aug 2, 2025 (GPAI rules already in effect)",
    ),
    "google-genai": (
        RiskLevel.GPAI,
        "Article 51-56",
        "Google Gemini / Generative AI models are general-purpose AI.",
        [
            "Same obligations as other GPAI usage",
            "Document model selection and purpose",
            "Assess application-level risk classification",
        ],
        "Aug 2, 2025",
    ),
    "google-vertex": (
        RiskLevel.GPAI,
        "Article 51-56",
        "Google Vertex AI may involve GPAI models and custom model training.",
        [
            "Document all models deployed via Vertex",
            "Assess each model's risk classification based on application",
            "If fine-tuning: you may become a PROVIDER with additional obligations",
        ],
        "Aug 2, 2025",
    ),
    "mistral": (
        RiskLevel.GPAI,
        "Article 51-56",
        "Mistral AI models are general-purpose AI.",
        [
            "Same obligations as other GPAI usage",
            "Document model selection and purpose",
            "Assess application-level risk classification",
        ],
        "Aug 2, 2025",
    ),
    "huggingface": (
        RiskLevel.GPAI,
        "Article 51-56 / varies by model",
        "HuggingFace hosts thousands of models. Risk depends on which model and how it is used. "
        "Fine-tuning or training your own model may make you a PROVIDER.",
        [
            "Inventory all models downloaded/used from HuggingFace",
            "Classify each model by intended use and risk level",
            "If fine-tuning: assess if you become a provider under Article 25",
            "Document model provenance and licensing",
        ],
        "Varies",
    ),
    "langchain": (
        RiskLevel.LIMITED,
        "Article 50 (transparency)",
        "LangChain is an orchestration framework. Risk depends on what it orchestrates. "
        "At minimum, transparency obligations apply (users must know they interact with AI).",
        [
            "Audit all chains/agents for high-risk use cases",
            "Ensure transparency: disclose AI interaction to end users",
            "If chains include high-risk applications, classify accordingly",
            "Document data flows through chains",
        ],
        "Aug 2, 2026",
    ),
    "langgraph": (
        RiskLevel.LIMITED,
        "Article 50 / potentially high-risk depending on use",
        "LangGraph builds agent workflows. Multi-agent systems require careful classification.",
        [
            "Map all agent workflows and their decision authority",
            "Classify each workflow by EU AI Act risk category",
            "Implement human oversight for consequential decisions",
            "Document agent interaction patterns and failure modes",
        ],
        "Aug 2, 2026",
    ),
    "crewai": (
        RiskLevel.LIMITED,
        "Article 50 / potentially high-risk",
        "CrewAI orchestrates multiple AI agents. Classification depends on what agents DO.",
        [
            "Inventory all agents and their capabilities",
            "Classify each agent's decision authority by risk level",
            "Implement error budgets and human oversight for agent chains",
            "Document inter-agent communication and failure modes",
            "Assess compound error amplification (Chandrasekhar limit)",
        ],
        "Aug 2, 2026",
    ),
    "autogen": (
        RiskLevel.LIMITED,
        "Article 50 / potentially high-risk",
        "AutoGen multi-agent framework. Same considerations as CrewAI.",
        [
            "Inventory all agents and their capabilities",
            "Classify each agent's decision authority by risk level",
            "Implement human oversight for consequential decisions",
            "Document inter-agent communication patterns",
        ],
        "Aug 2, 2026",
    ),
    "swarm": (
        RiskLevel.LIMITED,
        "Article 50 / potentially high-risk",
        "OpenAI Swarm agent framework. Classification depends on agent authority.",
        [
            "Inventory all agents and their capabilities",
            "Classify agent decision authority by risk level",
            "Implement human-in-the-loop for consequential actions",
        ],
        "Aug 2, 2026",
    ),
    "pytorch": (
        RiskLevel.UNKNOWN,
        "Depends on application",
        "PyTorch is a general ML framework. Risk depends entirely on what model is built and deployed.",
        [
            "Identify what models are trained/deployed with PyTorch",
            "Classify each model by its application and risk level",
            "If training custom models: assess provider obligations",
        ],
        "Varies",
    ),
    "tensorflow": (
        RiskLevel.UNKNOWN,
        "Depends on application",
        "TensorFlow is a general ML framework. Risk depends on application.",
        [
            "Identify what models are trained/deployed with TensorFlow",
            "Classify each model by its application and risk level",
        ],
        "Varies",
    ),
    "keras": (
        RiskLevel.UNKNOWN,
        "Depends on application",
        "Keras is a high-level ML framework. Risk depends on application.",
        [
            "Identify models built with Keras and their deployment context",
            "Classify by application risk level",
        ],
        "Varies",
    ),
    "sklearn": (
        RiskLevel.MINIMAL,
        "No specific obligations (typically minimal risk)",
        "scikit-learn is typically used for traditional ML (classification, regression, clustering). "
        "Most applications are minimal risk unless used for high-risk decisions.",
        [
            "Verify sklearn models are not used for high-risk decisions (hiring, credit, medical)",
            "If used for high-risk decisions: reclassify accordingly",
        ],
        "N/A (minimal risk)",
    ),
    "rag": (
        RiskLevel.LIMITED,
        "Article 50 (transparency)",
        "RAG systems must be transparent about AI-generated content. "
        "Risk depends on what decisions the RAG output informs.",
        [
            "Ensure transparency: users know responses are AI-generated",
            "If RAG informs high-risk decisions: classify accordingly",
            "Document data sources and retrieval pipeline",
        ],
        "Aug 2, 2026",
    ),
    "agent": (
        RiskLevel.LIMITED,
        "Article 50 / potentially high-risk",
        "AI agents with tool use / function calling require assessment of what actions they can take.",
        [
            "Inventory all tools/functions the agent can call",
            "Assess risk level based on agent's decision authority",
            "Implement human oversight for irreversible actions",
            "Document tool use patterns and failure modes",
        ],
        "Aug 2, 2026",
    ),
    "groq": (
        RiskLevel.GPAI,
        "Article 51-56 (GPAI provisions)",
        "Groq provides access to GPAI models (e.g., Llama). Classification depends on model and use.",
        [
            "Determine your role: provider vs deployer",
            "Document which models are accessed via Groq and for what purpose",
            "Assess if your APPLICATION falls under high-risk categories",
        ],
        "Aug 2, 2025",
    ),
    "together": (
        RiskLevel.GPAI,
        "Article 51-56 (GPAI provisions)",
        "Together AI provides access to various GPAI models. Classification depends on model and use.",
        [
            "Document which models are accessed via Together AI",
            "Assess application-level risk classification",
            "Determine provider vs deployer obligations",
        ],
        "Aug 2, 2025",
    ),
    "fireworks": (
        RiskLevel.GPAI,
        "Article 51-56 (GPAI provisions)",
        "Fireworks AI provides model inference. Classification depends on model and use.",
        [
            "Document which models are accessed via Fireworks AI",
            "Assess application-level risk classification",
            "Determine provider vs deployer obligations",
        ],
        "Aug 2, 2025",
    ),
    "vllm": (
        RiskLevel.GPAI,
        "Article 51-56 / varies by model",
        "vLLM is a high-performance inference engine. Risk depends on which model is served.",
        [
            "Identify which models are deployed via vLLM",
            "Classify each model by intended use and risk level",
            "If serving fine-tuned models: assess provider obligations",
        ],
        "Varies",
    ),
    "llama-cpp": (
        RiskLevel.GPAI,
        "Article 51-56 / varies by model",
        "llama-cpp-python runs LLMs locally. Risk depends on which model and application.",
        [
            "Identify which models are loaded via llama-cpp",
            "Classify each model by intended use and risk level",
            "Document model provenance and quantization details",
        ],
        "Varies",
    ),
    "instructor": (
        RiskLevel.LIMITED,
        "Article 50 (transparency)",
        "Instructor provides structured outputs from LLMs. Risk depends on underlying model and use case.",
        [
            "Document which LLM provider is used with Instructor",
            "Assess if structured output is used for high-risk decisions",
            "Ensure transparency about AI-generated structured data",
        ],
        "Aug 2, 2026",
    ),
    "dspy": (
        RiskLevel.LIMITED,
        "Article 50 (transparency)",
        "DSPy is a framework for programming LLMs. Risk depends on the application built.",
        [
            "Document which LLM models DSPy connects to",
            "Audit DSPy programs for high-risk use cases",
            "Ensure transparency about AI-driven decisions",
        ],
        "Aug 2, 2026",
    ),
    "haystack": (
        RiskLevel.LIMITED,
        "Article 50 (transparency)",
        "Haystack is an NLP framework for building search and RAG pipelines. "
        "Transparency obligations apply at minimum.",
        [
            "Audit all pipelines for high-risk use cases",
            "Ensure transparency: disclose AI interaction to end users",
            "Document data flows and model usage in pipelines",
        ],
        "Aug 2, 2026",
    ),
    "unstructured": (
        RiskLevel.MINIMAL,
        "No specific obligations (typically minimal risk)",
        "Unstructured is a document processing library. Typically minimal risk unless "
        "processed documents feed into high-risk decision systems.",
        [
            "Verify processed documents do not feed high-risk AI decisions",
            "If feeding high-risk systems: classify the downstream system accordingly",
        ],
        "N/A (minimal risk)",
    ),
    "marvin": (
        RiskLevel.LIMITED,
        "Article 50 (transparency)",
        "Marvin is an AI framework for building applications with LLMs. "
        "Risk depends on the specific application.",
        [
            "Document which LLM models Marvin connects to",
            "Assess application-level risk classification",
            "Ensure transparency about AI interaction to users",
        ],
        "Aug 2, 2026",
    ),
    "llamaindex": (
        RiskLevel.LIMITED,
        "Article 50 (transparency)",
        "LlamaIndex is a data framework for LLM applications. Typically used for RAG. "
        "Transparency obligations apply.",
        [
            "Audit all indices and query engines for high-risk use cases",
            "Ensure transparency: disclose AI-generated responses to users",
            "Document data sources and retrieval pipeline",
        ],
        "Aug 2, 2026",
    ),
}

# Default for unknown frameworks
DEFAULT_CLASSIFICATION = (
    RiskLevel.UNKNOWN,
    "Requires assessment",
    "Could not automatically determine risk level. Manual assessment required.",
    [
        "Manually assess the AI system's purpose and deployment context",
        "Determine if it falls under Annex III high-risk categories",
        "Document the system and its intended use",
    ],
    "Varies",
)


def classify_detection(detection: Detection) -> RiskClassification:
    """Classify a single detection per EU AI Act risk categories."""
    # Use-case rules take priority (they indicate specific high-risk applications)
    if detection.category == "use-case" and detection.framework in USE_CASE_RULES:
        risk, annex, reason, obligations, deadline = USE_CASE_RULES[detection.framework]
        return RiskClassification(
            detection=detection,
            risk_level=risk,
            annex=annex,
            reason=reason,
            obligations=obligations,
            deadline=deadline,
        )

    # Framework-based rules
    if detection.framework in FRAMEWORK_RULES:
        risk, annex, reason, obligations, deadline = FRAMEWORK_RULES[detection.framework]
        return RiskClassification(
            detection=detection,
            risk_level=risk,
            annex=annex,
            reason=reason,
            obligations=obligations,
            deadline=deadline,
        )

    # Default
    risk, annex, reason, obligations, deadline = DEFAULT_CLASSIFICATION
    return RiskClassification(
        detection=detection,
        risk_level=risk,
        annex=annex,
        reason=reason,
        obligations=obligations,
        deadline=deadline,
    )


@dataclass
class ClassificationReport:
    """Full classification report for a scan."""
    scan_result: ScanResult
    classifications: list[RiskClassification]
    summary: dict[RiskLevel, int]

    @property
    def has_unacceptable(self) -> bool:
        return self.summary.get(RiskLevel.UNACCEPTABLE, 0) > 0

    @property
    def has_high_risk(self) -> bool:
        return self.summary.get(RiskLevel.HIGH, 0) > 0

    @property
    def requires_action(self) -> bool:
        return self.has_unacceptable or self.has_high_risk


def classify(scan_result: ScanResult) -> ClassificationReport:
    """Classify all detections in a scan result."""
    classifications = []
    summary: dict[RiskLevel, int] = {}

    # Deduplicate: one classification per (framework, use-case) per file
    seen: set[tuple[str, str, str]] = set()

    for detection in scan_result.detections:
        key = (detection.file, detection.framework, detection.category)
        if key in seen:
            continue
        seen.add(key)

        classification = classify_detection(detection)
        classifications.append(classification)
        summary[classification.risk_level] = summary.get(classification.risk_level, 0) + 1

    return ClassificationReport(
        scan_result=scan_result,
        classifications=classifications,
        summary=summary,
    )
