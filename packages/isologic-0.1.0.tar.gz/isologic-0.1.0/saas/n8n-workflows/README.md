# CodeAuditLab Email Nurture Workflow — n8n Integration Guide

## Overview

A 5-email nurture sequence triggered when a user completes their first scan on CodeAuditLab. The sequence runs over 21 days:

| Email | Delay | Subject | Purpose |
|-------|-------|---------|---------|
| 1 | Immediate | Your EU AI Act Compliance Report | Scan results + PDF download |
| 2 | Day 2 | X Days Until the EU AI Act Deadline | Urgency + education |
| 3 | Day 5 | Your EU AI Act Compliance Roadmap | Step-by-step guide + CI/CD |
| 4 | Day 10 | Automated Compliance Monitoring | Pro plan pitch ($29/mo) |
| 5 | Day 21 | Last Chance Before Rates Increase | Final conversion push |

## Importing into n8n

1. Open your n8n instance
2. Go to **Workflows** > click the **...** menu (top right) > **Import from File**
3. Select `email-nurture.json`
4. The workflow will appear as "CodeAuditLab Email Nurture Sequence"
5. **Before activating**: configure the SMTP credential (see below)

## SMTP Credential Setup

1. In n8n, go to **Credentials** > **Add Credential** > **SMTP**
2. Name it: `CodeAuditLab SMTP`
3. Configure:

```
Host:     mail.codeauditlab.com   (or your SMTP provider)
Port:     587
User:     compliance@codeauditlab.com
Password: <your SMTP password>
SSL/TLS:  STARTTLS
```

4. After saving, open the workflow and update each "Send Email" node to use this credential
   - The workflow JSON has placeholder `SMTP_CREDENTIAL_ID` — n8n will prompt you to select the credential on first open

### Recommended SMTP providers

- **Amazon SES** — cheapest at scale ($0.10/1000 emails), requires domain verification
- **Postmark** — best deliverability for transactional email, $1.25/1000 emails
- **Resend** — developer-friendly, 3000 free emails/month
- **Self-hosted (Mautic/Postal)** — if running on the OVH server, configure postfix with DKIM/SPF/DMARC

## Webhook Configuration

### Webhook URL

After importing and activating the workflow, n8n generates a webhook URL. It will be:

```
https://<your-n8n-domain>/webhook/codeauditlab-nurture
```

For testing (workflow not activated):
```
https://<your-n8n-domain>/webhook-test/codeauditlab-nurture
```

### Webhook Payload Format

Send a `POST` request with `Content-Type: application/json`:

```json
{
  "email": "user@example.com",
  "name": "Jane Developer",
  "repo_name": "acme-corp/ml-pipeline",
  "scan_id": "a1b2c3d4e5f67890",
  "compliance_score": 72.5,
  "files_scanned": 1847,
  "summary": {
    "high": 3,
    "limited": 5,
    "minimal": 12,
    "unacceptable": 0,
    "gpai": 1,
    "unknown": 2
  },
  "frameworks_detected": {
    "tensorflow": 8,
    "scikit-learn": 3,
    "opencv": 2
  }
}
```

### Field Reference

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `email` | string | Yes | User's email address |
| `name` | string | No | User's display name (defaults to "there") |
| `repo_name` | string | Yes | Repository name (e.g. `owner/repo`) |
| `scan_id` | string | Yes | The scan hash from the `/api/scan` response |
| `compliance_score` | number | Yes | Score 0-100 from the scan |
| `files_scanned` | number | Yes | Number of files analyzed |
| `summary` | object | Yes | Risk level counts from the scan |
| `frameworks_detected` | object | Yes | Map of framework names to detection counts |

## FastAPI Backend Integration

Add this to the FastAPI backend (`main.py`) to fire the webhook after a successful scan. Add it inside the `scan_repo` endpoint, after the `db.commit()` call:

```python
import httpx

N8N_WEBHOOK_URL = os.getenv(
    "N8N_NURTURE_WEBHOOK",
    "https://<your-n8n-domain>/webhook/codeauditlab-nurture"
)

async def _trigger_nurture(email: str, name: str, scan_data: dict):
    """Fire-and-forget webhook to n8n nurture sequence."""
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            await client.post(N8N_WEBHOOK_URL, json={
                "email": email,
                "name": name,
                "repo_name": scan_data["repo_name"],
                "scan_id": scan_data["scan_id"],
                "compliance_score": scan_data["compliance_score"],
                "files_scanned": scan_data["files_scanned"],
                "summary": scan_data["summary"],
                "frameworks_detected": scan_data["frameworks_detected"],
            })
    except Exception:
        pass  # Non-critical — don't fail the scan if nurture webhook fails
```

Then call it from the scan endpoint:

```python
# After db.commit() in scan_repo():
if req.email:  # Only if user provided email
    import asyncio
    asyncio.create_task(_trigger_nurture(
        email=req.email,
        name=req.name or "there",
        scan_data={
            "repo_name": repo_name,
            "scan_id": scan_hash,
            "compliance_score": score,
            "files_scanned": scan_result.files_scanned,
            "summary": summary,
            "frameworks_detected": scan_result.frameworks,
        }
    ))
```

This requires adding `email` and `name` as optional fields to the `ScanRequest` schema:

```python
class ScanRequest(BaseModel):
    repo_url: str
    email: str | None = None
    name: str | None = None
```

## Testing

### Manual test with curl

```bash
curl -X POST https://<your-n8n-domain>/webhook-test/codeauditlab-nurture \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "name": "Test User",
    "repo_name": "test-org/test-repo",
    "scan_id": "abc123def456",
    "compliance_score": 65.0,
    "files_scanned": 500,
    "summary": {"high": 2, "limited": 3, "minimal": 8, "unacceptable": 0, "gpai": 0, "unknown": 1},
    "frameworks_detected": {"tensorflow": 5, "pytorch": 2}
  }'
```

Use the `-test` webhook URL so n8n executes without the workflow being active (manual/test mode).

### Verifying wait nodes

n8n wait nodes persist through restarts. To test the full sequence faster during development:
1. Open the workflow
2. Temporarily change wait durations to minutes instead of days
3. Run a test
4. Restore the original day values before activating

## Unsubscribe Handling

Each email includes an unsubscribe link pointing to:
```
https://codeauditlab.com/unsubscribe?email=<user_email>
```

You need to implement this endpoint in the FastAPI backend. It should:
1. Mark the user as unsubscribed in the database
2. Before the FastAPI webhook fires, check if the user has unsubscribed
3. Show a confirmation page

Alternatively, if using a dedicated email provider (SES, Postmark), use their built-in unsubscribe/suppression list features.
