#!/bin/bash
# Backup Code Audit Lab PostgreSQL database
set -euo pipefail

SERVER="root@51.210.24.170"
BACKUP_DIR="/opt/codeauditlab/data/backups"
DATE=$(date +%Y%m%d_%H%M%S)

echo "Backing up codeauditlab database..."
ssh "$SERVER" "mkdir -p $BACKUP_DIR && docker exec codeauditlab-db pg_dump -U codeauditlab codeauditlab | gzip > $BACKUP_DIR/cal-$DATE.sql.gz"
echo "Backup saved to $BACKUP_DIR/cal-$DATE.sql.gz"

# Cleanup old backups (keep last 30)
ssh "$SERVER" "cd $BACKUP_DIR && ls -t cal-*.sql.gz 2>/dev/null | tail -n +31 | xargs -r rm --"
echo "Old backups cleaned up."
