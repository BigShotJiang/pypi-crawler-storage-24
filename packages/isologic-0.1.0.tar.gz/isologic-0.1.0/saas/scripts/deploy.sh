#!/bin/bash
# Deploy Code Audit Lab to OVH (51.210.24.170)
set -euo pipefail

SERVER="root@51.210.24.170"
REMOTE_DIR="/opt/codeauditlab"

echo "=== Code Audit Lab Deploy ==="
echo "Deploying to $SERVER..."

# Sync backend code
echo "[1/4] Syncing backend..."
scp -r ../backend/app/database.py "$SERVER:$REMOTE_DIR/backend/app/database.py"
scp -r ../backend/app/models.py "$SERVER:$REMOTE_DIR/backend/app/models.py"
scp -r ../backend/app/schemas.py "$SERVER:$REMOTE_DIR/backend/app/schemas.py"
scp -r ../backend/app/main.py "$SERVER:$REMOTE_DIR/backend/app/main.py"
scp -r ../backend/app/pdf_report.py "$SERVER:$REMOTE_DIR/backend/app/pdf_report.py" 2>/dev/null || true

# Sync frontend
echo "[2/4] Syncing frontend..."
scp -r ../frontend/index.html "$SERVER:$REMOTE_DIR/frontend/index.html"

# Sync isologic core
echo "[3/4] Syncing isologic scanner..."
scp -r ../../src/isologic/* "$SERVER:$REMOTE_DIR/backend/app/isologic/"

# Restart service
echo "[4/4] Restarting service..."
ssh "$SERVER" "systemctl restart codeauditlab"

# Verify
echo ""
echo "Verifying..."
sleep 2
HEALTH=$(ssh "$SERVER" "curl -s http://127.0.0.1:8090/api/health")
echo "Health: $HEALTH"
echo ""
echo "=== Deploy complete at $(date) ==="
