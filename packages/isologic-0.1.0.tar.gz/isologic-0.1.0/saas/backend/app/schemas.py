"""Pydantic request/response schemas."""
from pydantic import BaseModel, EmailStr


class ScanRequest(BaseModel):
    repo_url: str
    email: str | None = None
    name: str | None = None


class ScanResponse(BaseModel):
    scan_id: str
    scan_hash: str
    repo_name: str
    files_scanned: int
    compliance_score: float
    summary: dict
    classifications: list[dict]
    frameworks_detected: dict
    deadline_days: int
    badge_url: str

    class Config:
        from_attributes = True


# --- Auth schemas ---

class AuthRegister(BaseModel):
    email: EmailStr
    password: str


class AuthLogin(BaseModel):
    email: EmailStr
    password: str


class AuthToken(BaseModel):
    access_token: str
    token_type: str = "bearer"


class UserOut(BaseModel):
    id: int
    email: str
    is_paid: bool

    class Config:
        from_attributes = True


# --- Stripe schemas ---

class CheckoutRequest(BaseModel):
    scan_hash: str
