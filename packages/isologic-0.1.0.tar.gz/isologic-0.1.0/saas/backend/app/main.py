"""Code Audit Lab — FastAPI backend."""
from __future__ import annotations

import hashlib
import os
import shutil
import subprocess
import tempfile
from datetime import datetime, timezone
from pathlib import Path

import httpx
import stripe
from fastapi import FastAPI, HTTPException, Request, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import Response
from sqlalchemy.orm import Session

from app.database import Base, engine, get_db
from app.models import Scan, User
from app.schemas import (
    ScanRequest, ScanResponse,
    AuthRegister, AuthLogin, AuthToken, UserOut,
    CheckoutRequest,
)
from app.auth import hash_password, verify_password, create_access_token, get_current_user

from app.isologic.scanner import scan
from app.isologic.classifier import classify, RiskLevel
from app.pdf_report import generate_pdf

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Code Audit Lab", version="1.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "https://codeauditlab.com",
        "https://www.codeauditlab.com",
        "https://checkout.stripe.com",
    ],
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
    allow_credentials=True,
)

# --- Stripe config ---
stripe.api_key = os.getenv("STRIPE_SECRET_KEY", "")
STRIPE_WEBHOOK_SECRET = os.getenv("STRIPE_WEBHOOK_SECRET", "")

# Cache for the Stripe Price ID (created once)
_stripe_price_id: str | None = None

DEADLINE = datetime(2026, 8, 2, tzinfo=timezone.utc)

N8N_NURTURE_WEBHOOK = os.getenv(
    "N8N_NURTURE_WEBHOOK",
    "http://127.0.0.1:5678/webhook/codeauditlab-nurture"
)


async def _trigger_nurture(email: str, name: str, scan_data: dict):
    """Fire-and-forget webhook to n8n nurture sequence."""
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            await client.post(N8N_NURTURE_WEBHOOK, json={
                "email": email,
                "name": name,
                "repo_name": scan_data["repo_name"],
                "scan_id": scan_data["scan_id"],
                "compliance_score": scan_data["compliance_score"],
                "files_scanned": scan_data["files_scanned"],
                "summary": scan_data["summary"],
                "frameworks_detected": scan_data["frameworks_detected"],
            })
    except Exception:
        pass  # Non-critical — don't fail the scan if nurture webhook fails


def _days_until_deadline() -> int:
    delta = DEADLINE - datetime.now(timezone.utc)
    return max(0, delta.days)


def _compliance_score(summary: dict) -> float:
    """Calculate 0-100 compliance score. Higher = more compliant."""
    weights = {"unacceptable": -50, "high": -20, "limited": -5, "gpai": -3, "minimal": 0, "unknown": -10}
    total_systems = sum(summary.values()) or 1
    penalty = sum(summary.get(level, 0) * w for level, w in weights.items())
    score = max(0, min(100, 100 + (penalty / total_systems)))
    return round(score, 1)


def _clone_repo(repo_url: str) -> Path:
    """Clone a public GitHub repo to a temp directory."""
    tmp = Path(tempfile.mkdtemp(prefix="cal_"))
    try:
        subprocess.run(
            ["git", "clone", "--depth=1", "--single-branch", repo_url, str(tmp / "repo")],
            capture_output=True, text=True, timeout=60, check=True,
        )
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as e:
        shutil.rmtree(tmp, ignore_errors=True)
        raise HTTPException(status_code=400, detail=f"Could not clone repo: {e}")
    return tmp / "repo"


def _get_or_create_stripe_price() -> str:
    """Get or create the Stripe Price for CodeAuditLab Pro Report."""
    global _stripe_price_id
    if _stripe_price_id:
        return _stripe_price_id

    # Check .env for cached price
    env_price = os.getenv("STRIPE_PRICE_REPORT", "")
    if env_price and env_price.startswith("price_") and env_price != "price_placeholder":
        _stripe_price_id = env_price
        return _stripe_price_id

    # Search for existing product
    products = stripe.Product.search(query='name:"CodeAuditLab Pro Report"', limit=1)
    if products.data:
        product = products.data[0]
        prices = stripe.Price.list(product=product.id, active=True, limit=1)
        if prices.data:
            _stripe_price_id = prices.data[0].id
            return _stripe_price_id
    else:
        product = stripe.Product.create(
            name="CodeAuditLab Pro Report",
            description="Full EU AI Act compliance PDF report with risk classifications and remediation steps",
        )

    price = stripe.Price.create(
        product=product.id,
        unit_amount=999,  # $9.99
        currency="usd",
    )
    _stripe_price_id = price.id
    return _stripe_price_id


# ========== Health ==========

@app.get("/api/health")
async def health():
    return {"status": "ok", "deadline_days": _days_until_deadline()}


# ========== Auth ==========

@app.post("/api/auth/register", response_model=AuthToken)
async def register(body: AuthRegister, db: Session = Depends(get_db)):
    existing = db.query(User).filter_by(email=body.email).first()
    if existing:
        raise HTTPException(400, "Email already registered")
    if len(body.password) < 8:
        raise HTTPException(400, "Password must be at least 8 characters")
    user = User(
        email=body.email,
        password_hash=hash_password(body.password),
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    token = create_access_token(user.id, user.email)
    return AuthToken(access_token=token)


@app.post("/api/auth/login", response_model=AuthToken)
async def login(body: AuthLogin, db: Session = Depends(get_db)):
    user = db.query(User).filter_by(email=body.email).first()
    if not user or not verify_password(body.password, user.password_hash):
        raise HTTPException(401, "Invalid email or password")
    token = create_access_token(user.id, user.email)
    return AuthToken(access_token=token)


@app.get("/api/auth/me", response_model=UserOut)
async def me(user: User = Depends(get_current_user)):
    return user


# ========== Scan (public) ==========

@app.post("/api/scan", response_model=ScanResponse)
async def scan_repo(req: ScanRequest, request: Request, db: Session = Depends(get_db)):
    repo_url = req.repo_url.strip()

    if not repo_url.startswith(("https://github.com/", "https://gitlab.com/")):
        raise HTTPException(400, "Only public GitHub/GitLab repos supported")

    parts = repo_url.rstrip("/").split("/")
    repo_name = f"{parts[-2]}/{parts[-1]}" if len(parts) >= 2 else repo_url

    scan_hash = hashlib.sha256(repo_url.encode()).hexdigest()[:16]
    existing = db.query(Scan).filter_by(scan_hash=scan_hash).first()
    if existing:
        return ScanResponse(
            scan_id=existing.scan_hash,
            scan_hash=existing.scan_hash,
            repo_name=existing.repo_name,
            files_scanned=existing.files_scanned,
            compliance_score=existing.compliance_score,
            summary=existing.summary,
            classifications=existing.classifications,
            frameworks_detected=existing.frameworks_detected,
            deadline_days=_days_until_deadline(),
            badge_url=f"https://codeauditlab.com/badge/{existing.scan_hash}.svg",
        )

    repo_path = _clone_repo(repo_url)
    try:
        scan_result = scan(repo_path, max_files=10_000)
        report = classify(scan_result)

        summary = {level.value: count for level, count in report.summary.items()}
        classifications_data = [
            {
                "file": c.detection.file.replace(str(repo_path), ""),
                "line": c.detection.line,
                "framework": c.detection.framework,
                "description": c.detection.description,
                "risk_level": c.risk_level.value,
                "annex": c.annex,
                "reason": c.reason,
                "obligations": c.obligations,
                "deadline": c.deadline,
            }
            for c in report.classifications
        ]
        score = _compliance_score(summary)

        db_scan = Scan(
            repo_url=repo_url,
            repo_name=repo_name,
            scan_hash=scan_hash,
            files_scanned=scan_result.files_scanned,
            compliance_score=score,
            summary=summary,
            classifications=classifications_data,
            frameworks_detected=scan_result.frameworks,
            ip_address=request.client.host if request.client else None,
        )
        db.add(db_scan)
        db.commit()

        # Trigger email nurture if user provided email
        if getattr(req, "email", None):
            import asyncio
            asyncio.create_task(_trigger_nurture(
                email=req.email,
                name=getattr(req, "name", None) or "there",
                scan_data={
                    "repo_name": repo_name,
                    "scan_id": scan_hash,
                    "compliance_score": score,
                    "files_scanned": scan_result.files_scanned,
                    "summary": summary,
                    "frameworks_detected": scan_result.frameworks,
                },
            ))

        return ScanResponse(
            scan_id=scan_hash,
            scan_hash=scan_hash,
            repo_name=repo_name,
            files_scanned=scan_result.files_scanned,
            compliance_score=score,
            summary=summary,
            classifications=classifications_data,
            frameworks_detected=scan_result.frameworks,
            deadline_days=_days_until_deadline(),
            badge_url=f"https://codeauditlab.com/badge/{scan_hash}.svg",
        )
    finally:
        shutil.rmtree(repo_path.parent, ignore_errors=True)


# ========== Badge ==========

@app.get("/badge/{scan_hash}.svg")
async def get_badge(scan_hash: str, db: Session = Depends(get_db)):
    """Generate compliance badge SVG."""
    existing = db.query(Scan).filter_by(scan_hash=scan_hash).first()
    if not existing:
        raise HTTPException(404, "Scan not found")

    score = existing.compliance_score
    if score >= 80:
        color = "#4c1"
        label = "Compliant"
    elif score >= 50:
        color = "#dfb317"
        label = "Needs Review"
    else:
        color = "#e05d44"
        label = "High Risk"

    svg = f"""<svg xmlns="http://www.w3.org/2000/svg" width="220" height="20">
  <linearGradient id="b" x2="0" y2="100%">
    <stop offset="0" stop-color="#bbb" stop-opacity=".1"/>
    <stop offset="1" stop-opacity=".1"/>
  </linearGradient>
  <mask id="a"><rect width="220" height="20" rx="3" fill="#fff"/></mask>
  <g mask="url(#a)">
    <rect width="120" height="20" fill="#555"/>
    <rect x="120" width="100" height="20" fill="{color}"/>
    <rect width="220" height="20" fill="url(#b)"/>
  </g>
  <g fill="#fff" text-anchor="middle" font-family="DejaVu Sans,sans-serif" font-size="11">
    <text x="60" y="14">EU AI Act</text>
    <text x="170" y="14">{label} {score:.0f}/100</text>
  </g>
</svg>"""

    return Response(content=svg, media_type="image/svg+xml",
                    headers={"Cache-Control": "public, max-age=300"})


# ========== PDF Report (auth required) ==========

@app.get("/api/report/{scan_hash}/pdf")
async def download_pdf_report(
    scan_hash: str,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Download PDF compliance report. Requires auth + paid status."""
    if not user.is_paid:
        raise HTTPException(403, "Payment required. Purchase a Pro Report to download PDFs.")

    existing = db.query(Scan).filter_by(scan_hash=scan_hash).first()
    if not existing:
        raise HTTPException(404, "Scan not found")

    scan_data = {
        "compliance_score": existing.compliance_score,
        "repo_name": existing.repo_name,
        "summary": existing.summary,
        "classifications": existing.classifications,
        "frameworks_detected": existing.frameworks_detected,
        "scan_hash": existing.scan_hash,
        "files_scanned": existing.files_scanned,
    }
    pdf_bytes = generate_pdf(scan_data)
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename=compliance-report-{scan_hash}.pdf"},
    )


# ========== Stripe Checkout ==========

@app.post("/api/checkout")
async def create_checkout_session(
    body: CheckoutRequest,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """Create a Stripe Checkout Session for a Pro Report."""
    existing = db.query(Scan).filter_by(scan_hash=body.scan_hash).first()
    if not existing:
        raise HTTPException(404, "Scan not found")

    if user.is_paid:
        raise HTTPException(400, "You already have paid access")

    price_id = _get_or_create_stripe_price()

    session = stripe.checkout.Session.create(
        mode="payment",
        payment_method_types=["card"],
        line_items=[{"price": price_id, "quantity": 1}],
        success_url=f"https://codeauditlab.com/report/{body.scan_hash}?payment=success",
        cancel_url=f"https://codeauditlab.com/report/{body.scan_hash}?payment=cancelled",
        client_reference_id=str(user.id),
        customer_email=user.email,
        metadata={"scan_hash": body.scan_hash, "user_id": str(user.id)},
    )
    return {"checkout_url": session.url, "session_id": session.id}


@app.post("/api/webhook/stripe")
async def stripe_webhook(request: Request, db: Session = Depends(get_db)):
    """Handle Stripe webhook events."""
    payload = await request.body()
    sig_header = request.headers.get("stripe-signature", "")

    if STRIPE_WEBHOOK_SECRET:
        try:
            event = stripe.Webhook.construct_event(payload, sig_header, STRIPE_WEBHOOK_SECRET)
        except (ValueError, stripe.error.SignatureVerificationError):
            raise HTTPException(400, "Invalid webhook signature")
    else:
        import json
        event = json.loads(payload)

    if event.get("type") == "checkout.session.completed":
        session_data = event["data"]["object"]
        user_id = session_data.get("client_reference_id")
        if user_id:
            user = db.query(User).filter_by(id=int(user_id)).first()
            if user:
                user.is_paid = True
                user.stripe_customer_id = session_data.get("customer")
                db.commit()

    return {"status": "ok"}


# ========== Stats ==========

@app.get("/api/stats")
async def stats(db: Session = Depends(get_db)):
    """Public stats for landing page."""
    total = db.query(Scan).count()
    return {
        "total_scans": total,
        "deadline_days": _days_until_deadline(),
    }
