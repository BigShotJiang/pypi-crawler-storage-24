"""PDF compliance report generator using WeasyPrint."""
from __future__ import annotations
from datetime import datetime, timezone
from io import BytesIO
from weasyprint import HTML


def generate_pdf(scan_data: dict) -> bytes:
    """Generate a branded PDF compliance report from scan data."""
    score = scan_data.get("compliance_score", 0)
    repo_name = scan_data.get("repo_name", "Unknown")
    summary = scan_data.get("summary", {})
    classifications = scan_data.get("classifications", [])
    frameworks = scan_data.get("frameworks_detected", {})
    scan_hash = scan_data.get("scan_hash", "")
    files_scanned = scan_data.get("files_scanned", 0)

    if score >= 80:
        score_color = "#22c55e"
        score_label = "Compliant"
    elif score >= 50:
        score_color = "#eab308"
        score_label = "Needs Review"
    else:
        score_color = "#ef4444"
        score_label = "High Risk"

    deadline = datetime(2026, 8, 2, tzinfo=timezone.utc)
    days_left = max(0, (deadline - datetime.now(timezone.utc)).days)
    generated_at = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

    # Build risk summary rows
    risk_levels = ["unacceptable", "high", "limited", "gpai", "minimal", "unknown"]
    risk_colors = {
        "unacceptable": "#dc2626", "high": "#ef4444", "limited": "#f59e0b",
        "gpai": "#8b5cf6", "minimal": "#22c55e", "unknown": "#6b7280"
    }
    risk_labels = {
        "unacceptable": "UNACCEPTABLE — Prohibited", "high": "HIGH — Conformity assessment required",
        "limited": "LIMITED — Transparency obligations", "gpai": "GPAI — Model obligations (Art. 51-56)",
        "minimal": "MINIMAL — No mandatory obligations", "unknown": "UNKNOWN — Manual review needed"
    }

    summary_rows = ""
    for level in risk_levels:
        count = summary.get(level, 0)
        if count > 0:
            summary_rows += f'''
            <tr>
                <td style="padding:8px 12px;border-bottom:1px solid #e5e7eb;">
                    <span style="display:inline-block;width:12px;height:12px;border-radius:50%;background:{risk_colors[level]};margin-right:8px;vertical-align:middle;"></span>
                    {level.upper()}
                </td>
                <td style="padding:8px 12px;border-bottom:1px solid #e5e7eb;text-align:center;font-weight:bold;">{count}</td>
                <td style="padding:8px 12px;border-bottom:1px solid #e5e7eb;font-size:0.85em;color:#6b7280;">{risk_labels[level]}</td>
            </tr>'''

    # Build classifications rows
    classification_rows = ""
    for c in classifications:
        risk = c.get("risk_level", "unknown")
        color = risk_colors.get(risk, "#6b7280")
        obligations_html = ""
        for ob in c.get("obligations", []):
            obligations_html += f"<li style='margin-bottom:4px;'>{ob}</li>"

        classification_rows += f'''
        <tr>
            <td style="padding:10px;border-bottom:1px solid #e5e7eb;font-family:monospace;font-size:0.85em;">{c.get("file", "")}</td>
            <td style="padding:10px;border-bottom:1px solid #e5e7eb;text-align:center;">{c.get("line", "")}</td>
            <td style="padding:10px;border-bottom:1px solid #e5e7eb;">{c.get("framework", "")}</td>
            <td style="padding:10px;border-bottom:1px solid #e5e7eb;">
                <span style="background:{color};color:white;padding:2px 8px;border-radius:4px;font-size:0.8em;font-weight:bold;">{risk.upper()}</span>
            </td>
            <td style="padding:10px;border-bottom:1px solid #e5e7eb;font-size:0.85em;">{c.get("reason", "")}</td>
        </tr>'''
        if obligations_html:
            classification_rows += f'''
            <tr>
                <td colspan="5" style="padding:6px 10px 12px 30px;border-bottom:2px solid #e5e7eb;background:#f9fafb;">
                    <strong style="font-size:0.85em;">Required Actions:</strong>
                    <ul style="margin:4px 0 0 16px;padding:0;font-size:0.85em;">{obligations_html}</ul>
                </td>
            </tr>'''

    # Build frameworks list
    fw_items = ""
    for fw, count in (frameworks or {}).items():
        fw_items += f"<span style='display:inline-block;background:#eff6ff;border:1px solid #bfdbfe;padding:4px 10px;border-radius:16px;margin:3px;font-size:0.85em;'>{fw} ({count})</span>"

    html_content = f'''<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <style>
        @page {{ size: A4; margin: 2cm; }}
        body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; color: #1f2937; line-height: 1.5; font-size: 10pt; }}
        h1 {{ color: #1e3a5f; margin: 0; }}
        h2 {{ color: #1e3a5f; border-bottom: 2px solid #3b82f6; padding-bottom: 6px; margin-top: 28px; }}
        table {{ width: 100%; border-collapse: collapse; }}
        th {{ background: #1e3a5f; color: white; padding: 10px 12px; text-align: left; font-size: 0.9em; }}
    </style>
</head>
<body>
    <div style="display:flex;justify-content:space-between;align-items:center;border-bottom:3px solid #3b82f6;padding-bottom:16px;margin-bottom:24px;">
        <div>
            <h1>Code Audit Lab</h1>
            <p style="margin:4px 0 0;color:#6b7280;font-size:0.9em;">EU AI Act Compliance Report</p>
        </div>
        <div style="text-align:right;">
            <div style="font-size:2.5em;font-weight:bold;color:{score_color};">{score:.0f}</div>
            <div style="font-size:0.85em;color:{score_color};font-weight:bold;">{score_label}</div>
        </div>
    </div>

    <table style="margin-bottom:24px;">
        <tr>
            <td style="padding:6px 0;"><strong>Repository:</strong> {repo_name}</td>
            <td style="padding:6px 0;"><strong>Files Scanned:</strong> {files_scanned}</td>
        </tr>
        <tr>
            <td style="padding:6px 0;"><strong>Scan ID:</strong> <code>{scan_hash}</code></td>
            <td style="padding:6px 0;"><strong>Generated:</strong> {generated_at}</td>
        </tr>
        <tr>
            <td colspan="2" style="padding:6px 0;"><strong>Deadline:</strong> {days_left} days until Aug 2, 2026 — high-risk AI system rules enforceable</td>
        </tr>
    </table>

    <h2>Risk Summary</h2>
    <table>
        <thead>
            <tr>
                <th>Risk Level</th>
                <th style="text-align:center;">Count</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>{summary_rows}</tbody>
    </table>

    <h2>Detected Frameworks</h2>
    <div style="margin:12px 0;">{fw_items if fw_items else "<p style='color:#6b7280;'>No AI frameworks detected.</p>"}</div>

    <h2>Detailed Classifications</h2>
    {"<table><thead><tr><th>File</th><th>Line</th><th>Framework</th><th>Risk</th><th>Reason</th></tr></thead><tbody>" + classification_rows + "</tbody></table>" if classification_rows else "<p style='color:#6b7280;'>No AI systems classified.</p>"}

    <div style="margin-top:40px;padding-top:16px;border-top:2px solid #e5e7eb;color:#9ca3af;font-size:0.8em;text-align:center;">
        <p>Generated by Code Audit Lab (codeauditlab.com) — Powered by isologic</p>
        <p>This report provides guidance based on static code analysis. It does not constitute legal advice.</p>
        <p>EU AI Act (Regulation 2024/1689) — Compliance deadline: August 2, 2026</p>
    </div>
</body>
</html>'''

    pdf_bytes = HTML(string=html_content).write_pdf()
    return pdf_bytes
