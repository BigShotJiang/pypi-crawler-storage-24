"""Tests for isologic.classifier — EU AI Act risk classification engine."""

from __future__ import annotations

import pytest

from isologic.classifier import (
    DEFAULT_CLASSIFICATION,
    FRAMEWORK_RULES,
    USE_CASE_RULES,
    ClassificationReport,
    RiskClassification,
    RiskLevel,
    classify,
    classify_detection,
)
from isologic.scanner import Detection, ScanResult


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_detection(
    framework: str,
    category: str = "framework",
    file: str = "app.py",
    line: int = 1,
    description: str = "test detection",
    snippet: str = "import something",
) -> Detection:
    return Detection(
        file=file,
        line=line,
        framework=framework,
        description=description,
        snippet=snippet,
        category=category,
    )


def _make_scan_result(detections: list[Detection], path: str = "/project") -> ScanResult:
    return ScanResult(
        path=path,
        files_scanned=len({d.file for d in detections}),
        detections=detections,
    )


# =========================================================================
# 1. USE_CASE_RULES — each use case maps to correct risk level, annex, deadline
# =========================================================================

class TestUseCaseRules:
    """Verify every entry in USE_CASE_RULES produces the expected classification."""

    def test_biometric_is_unacceptable(self):
        det = _make_detection("biometric", category="use-case")
        cls = classify_detection(det)
        assert cls.risk_level == RiskLevel.UNACCEPTABLE
        assert "Article 5" in cls.annex
        assert "2025" in cls.deadline

    def test_emotion_is_unacceptable(self):
        det = _make_detection("emotion", category="use-case")
        cls = classify_detection(det)
        assert cls.risk_level == RiskLevel.UNACCEPTABLE
        assert "Article 5" in cls.annex
        assert "Feb 2, 2025" in cls.deadline

    def test_recruitment_is_high(self):
        det = _make_detection("recruitment", category="use-case")
        cls = classify_detection(det)
        assert cls.risk_level == RiskLevel.HIGH
        assert "Annex III" in cls.annex
        assert "Aug 2, 2026" in cls.deadline

    def test_credit_scoring_is_high(self):
        det = _make_detection("credit-scoring", category="use-case")
        cls = classify_detection(det)
        assert cls.risk_level == RiskLevel.HIGH
        assert "Annex III, 5(b)" == cls.annex
        assert "Aug 2, 2026" in cls.deadline

    def test_medical_is_high(self):
        det = _make_detection("medical", category="use-case")
        cls = classify_detection(det)
        assert cls.risk_level == RiskLevel.HIGH
        assert "Annex III" in cls.annex or "Annex I" in cls.annex
        assert "2026" in cls.deadline or "2027" in cls.deadline

    def test_education_is_high(self):
        det = _make_detection("education", category="use-case")
        cls = classify_detection(det)
        assert cls.risk_level == RiskLevel.HIGH
        assert "Annex III, 3(a)" == cls.annex
        assert "Aug 2, 2026" in cls.deadline

    def test_law_enforcement_is_high(self):
        det = _make_detection("law-enforcement", category="use-case")
        cls = classify_detection(det)
        assert cls.risk_level == RiskLevel.HIGH
        assert "Annex III, 6-7" == cls.annex
        assert "Aug 2, 2026" in cls.deadline

    def test_autonomous_is_high(self):
        det = _make_detection("autonomous", category="use-case")
        cls = classify_detection(det)
        assert cls.risk_level == RiskLevel.HIGH
        assert "Annex I" in cls.annex
        assert "2027" in cls.deadline

    def test_all_use_case_keys_covered(self):
        """Ensure we tested every key in the rules dict."""
        expected = {"biometric", "emotion", "recruitment", "credit-scoring",
                    "medical", "education", "law-enforcement", "autonomous",
                    "social-scoring", "deepfake", "content-moderation",
                    "chatbot", "recommendation"}
        assert set(USE_CASE_RULES.keys()) == expected


# =========================================================================
# 2. FRAMEWORK_RULES — at least 10 frameworks
# =========================================================================

class TestFrameworkRules:

    @pytest.mark.parametrize("fw", ["openai", "anthropic", "google-genai", "google-vertex", "mistral", "huggingface"])
    def test_gpai_frameworks(self, fw: str):
        det = _make_detection(fw)
        cls = classify_detection(det)
        assert cls.risk_level == RiskLevel.GPAI
        assert "51" in cls.annex or "56" in cls.annex  # Article 51-56

    @pytest.mark.parametrize("fw", ["langchain", "langgraph", "crewai", "autogen", "swarm", "rag", "agent"])
    def test_limited_frameworks(self, fw: str):
        det = _make_detection(fw)
        cls = classify_detection(det)
        assert cls.risk_level == RiskLevel.LIMITED

    @pytest.mark.parametrize("fw", ["pytorch", "tensorflow", "keras"])
    def test_unknown_frameworks(self, fw: str):
        det = _make_detection(fw)
        cls = classify_detection(det)
        assert cls.risk_level == RiskLevel.UNKNOWN

    def test_sklearn_is_minimal(self):
        det = _make_detection("sklearn")
        cls = classify_detection(det)
        assert cls.risk_level == RiskLevel.MINIMAL

    def test_framework_rule_has_obligations(self):
        """Every framework rule should have at least one obligation."""
        for fw, (_, _, _, obligations, _) in FRAMEWORK_RULES.items():
            assert len(obligations) > 0, f"Framework '{fw}' has no obligations"

    def test_framework_rule_has_deadline(self):
        """Every framework rule should have a non-empty deadline."""
        for fw, (_, _, _, _, deadline) in FRAMEWORK_RULES.items():
            assert len(deadline) > 0, f"Framework '{fw}' has empty deadline"


# =========================================================================
# 3. DEFAULT classification for unknown frameworks
# =========================================================================

class TestDefaultClassification:

    def test_unknown_framework_gets_default(self):
        det = _make_detection("some-unknown-lib")
        cls = classify_detection(det)
        assert cls.risk_level == RiskLevel.UNKNOWN
        assert cls.annex == "Requires assessment"
        assert "manual" in cls.reason.lower() or "Manual" in cls.reason

    def test_default_has_obligations(self):
        det = _make_detection("nonexistent-framework-xyz")
        cls = classify_detection(det)
        assert len(cls.obligations) > 0

    def test_default_deadline(self):
        det = _make_detection("mystery-ai")
        cls = classify_detection(det)
        assert cls.deadline == "Varies"


# =========================================================================
# 4. Use-case rules override framework rules (priority logic)
# =========================================================================

class TestUseCaseOverridesFramework:

    def test_use_case_biometric_overrides_framework_openai(self):
        """A detection with category='use-case' and framework='biometric'
        should use USE_CASE_RULES even if 'biometric' were in FRAMEWORK_RULES."""
        det = _make_detection("biometric", category="use-case")
        cls = classify_detection(det)
        assert cls.risk_level == RiskLevel.UNACCEPTABLE
        # Confirm it used the USE_CASE_RULES entry
        assert cls.annex == USE_CASE_RULES["biometric"][1]

    def test_framework_category_skips_use_case_rules(self):
        """If category is 'framework', use-case rules should NOT apply even
        if the framework name matches a use-case key."""
        det = _make_detection("biometric", category="framework")
        cls = classify_detection(det)
        # 'biometric' is not in FRAMEWORK_RULES, so it should get DEFAULT
        assert cls.risk_level == RiskLevel.UNKNOWN
        assert cls.annex == "Requires assessment"

    def test_use_case_category_with_framework_name_falls_through(self):
        """If category='use-case' but framework is NOT in USE_CASE_RULES,
        it falls to FRAMEWORK_RULES or default."""
        det = _make_detection("openai", category="use-case")
        cls = classify_detection(det)
        # 'openai' is NOT in USE_CASE_RULES, so falls to FRAMEWORK_RULES
        assert cls.risk_level == RiskLevel.GPAI

    def test_mixed_detections_classified_independently(self):
        """A scan with both use-case and framework detections should
        classify each independently."""
        d1 = _make_detection("recruitment", category="use-case", file="hr.py")
        d2 = _make_detection("openai", category="framework", file="app.py")
        sr = _make_scan_result([d1, d2])
        report = classify(sr)
        risk_levels = {c.risk_level for c in report.classifications}
        assert RiskLevel.HIGH in risk_levels
        assert RiskLevel.GPAI in risk_levels


# =========================================================================
# 5. ClassificationReport properties
# =========================================================================

class TestClassificationReportProperties:

    def test_has_unacceptable_true(self):
        det = _make_detection("biometric", category="use-case")
        sr = _make_scan_result([det])
        report = classify(sr)
        assert report.has_unacceptable is True

    def test_has_unacceptable_false(self):
        det = _make_detection("openai")
        sr = _make_scan_result([det])
        report = classify(sr)
        assert report.has_unacceptable is False

    def test_has_high_risk_true(self):
        det = _make_detection("recruitment", category="use-case")
        sr = _make_scan_result([det])
        report = classify(sr)
        assert report.has_high_risk is True

    def test_has_high_risk_false(self):
        det = _make_detection("sklearn")
        sr = _make_scan_result([det])
        report = classify(sr)
        assert report.has_high_risk is False

    def test_requires_action_unacceptable(self):
        det = _make_detection("emotion", category="use-case")
        sr = _make_scan_result([det])
        report = classify(sr)
        assert report.requires_action is True

    def test_requires_action_high(self):
        det = _make_detection("medical", category="use-case")
        sr = _make_scan_result([det])
        report = classify(sr)
        assert report.requires_action is True

    def test_requires_action_false_for_limited(self):
        det = _make_detection("langchain")
        sr = _make_scan_result([det])
        report = classify(sr)
        assert report.requires_action is False

    def test_requires_action_false_for_minimal(self):
        det = _make_detection("sklearn")
        sr = _make_scan_result([det])
        report = classify(sr)
        assert report.requires_action is False

    def test_requires_action_false_for_gpai(self):
        det = _make_detection("openai")
        sr = _make_scan_result([det])
        report = classify(sr)
        assert report.requires_action is False


# =========================================================================
# 6. Deduplication in classify()
# =========================================================================

class TestDeduplication:

    def test_same_framework_same_file_deduplicates(self):
        d1 = _make_detection("openai", file="app.py", line=1)
        d2 = _make_detection("openai", file="app.py", line=10)
        sr = _make_scan_result([d1, d2])
        report = classify(sr)
        assert len(report.classifications) == 1

    def test_same_framework_different_files_keeps_both(self):
        d1 = _make_detection("openai", file="app.py")
        d2 = _make_detection("openai", file="utils.py")
        sr = _make_scan_result([d1, d2])
        report = classify(sr)
        assert len(report.classifications) == 2

    def test_different_frameworks_same_file_keeps_both(self):
        d1 = _make_detection("openai", file="app.py")
        d2 = _make_detection("anthropic", file="app.py")
        sr = _make_scan_result([d1, d2])
        report = classify(sr)
        assert len(report.classifications) == 2

    def test_different_category_same_framework_file_keeps_both(self):
        """Same file+framework but different category should NOT deduplicate."""
        d1 = _make_detection("openai", category="framework", file="app.py")
        d2 = _make_detection("openai", category="config", file="app.py")
        sr = _make_scan_result([d1, d2])
        report = classify(sr)
        assert len(report.classifications) == 2

    def test_triple_duplicate_collapses_to_one(self):
        detections = [_make_detection("pytorch", file="model.py", line=i) for i in range(3)]
        sr = _make_scan_result(detections)
        report = classify(sr)
        assert len(report.classifications) == 1


# =========================================================================
# 7. Summary counts are correct
# =========================================================================

class TestSummaryCounts:

    def test_single_gpai_summary(self):
        det = _make_detection("openai")
        sr = _make_scan_result([det])
        report = classify(sr)
        assert report.summary[RiskLevel.GPAI] == 1
        assert len(report.summary) == 1

    def test_mixed_risk_levels_summary(self):
        d1 = _make_detection("biometric", category="use-case", file="bio.py")
        d2 = _make_detection("recruitment", category="use-case", file="hr.py")
        d3 = _make_detection("openai", file="app.py")
        d4 = _make_detection("langchain", file="chain.py")
        sr = _make_scan_result([d1, d2, d3, d4])
        report = classify(sr)
        assert report.summary[RiskLevel.UNACCEPTABLE] == 1
        assert report.summary[RiskLevel.HIGH] == 1
        assert report.summary[RiskLevel.GPAI] == 1
        assert report.summary[RiskLevel.LIMITED] == 1

    def test_summary_counts_after_dedup(self):
        """Duplicates should not inflate summary counts."""
        d1 = _make_detection("openai", file="app.py", line=1)
        d2 = _make_detection("openai", file="app.py", line=5)
        d3 = _make_detection("anthropic", file="app.py")
        sr = _make_scan_result([d1, d2, d3])
        report = classify(sr)
        assert report.summary[RiskLevel.GPAI] == 2  # openai + anthropic
        assert len(report.classifications) == 2

    def test_summary_keys_match_classifications(self):
        d1 = _make_detection("sklearn", file="ml.py")
        d2 = _make_detection("crewai", file="agents.py")
        sr = _make_scan_result([d1, d2])
        report = classify(sr)
        levels_from_classifications = {c.risk_level for c in report.classifications}
        assert set(report.summary.keys()) == levels_from_classifications


# =========================================================================
# 8. Empty scan result produces empty report
# =========================================================================

class TestEmptyScanResult:

    def test_empty_detections_empty_report(self):
        sr = ScanResult(path="/empty", files_scanned=0, detections=[])
        report = classify(sr)
        assert len(report.classifications) == 0
        assert report.summary == {}

    def test_empty_report_properties(self):
        sr = ScanResult(path="/empty", files_scanned=0, detections=[])
        report = classify(sr)
        assert report.has_unacceptable is False
        assert report.has_high_risk is False
        assert report.requires_action is False

    def test_empty_report_scan_result_preserved(self):
        sr = ScanResult(path="/my/project", files_scanned=42, detections=[])
        report = classify(sr)
        assert report.scan_result is sr
        assert report.scan_result.path == "/my/project"
        assert report.scan_result.files_scanned == 42


# =========================================================================
# Additional edge-case tests
# =========================================================================

class TestEdgeCases:

    def test_classification_preserves_detection_reference(self):
        det = _make_detection("openai")
        cls = classify_detection(det)
        assert cls.detection is det

    def test_risk_level_enum_values(self):
        assert RiskLevel.UNACCEPTABLE.value == "unacceptable"
        assert RiskLevel.HIGH.value == "high"
        assert RiskLevel.LIMITED.value == "limited"
        assert RiskLevel.MINIMAL.value == "minimal"
        assert RiskLevel.GPAI.value == "gpai"
        assert RiskLevel.UNKNOWN.value == "unknown"

    def test_risk_level_is_str_enum(self):
        """RiskLevel inherits from str, so it should be usable as a string."""
        assert isinstance(RiskLevel.HIGH, str)
        assert RiskLevel.HIGH == "high"

    def test_default_classification_tuple_structure(self):
        risk, annex, reason, obligations, deadline = DEFAULT_CLASSIFICATION
        assert risk == RiskLevel.UNKNOWN
        assert isinstance(annex, str)
        assert isinstance(reason, str)
        assert isinstance(obligations, list)
        assert isinstance(deadline, str)

    def test_classify_returns_classification_report(self):
        sr = ScanResult(path="/x", detections=[])
        report = classify(sr)
        assert isinstance(report, ClassificationReport)

    def test_classify_detection_returns_risk_classification(self):
        det = _make_detection("openai")
        cls = classify_detection(det)
        assert isinstance(cls, RiskClassification)
