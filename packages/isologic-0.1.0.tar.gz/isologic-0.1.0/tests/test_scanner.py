"""Comprehensive tests for isologic.scanner module."""

from __future__ import annotations

import os
from pathlib import Path

import pytest

from isologic.scanner import (
    EXTENSIONS_CONFIG,
    EXTENSIONS_JS,
    EXTENSIONS_PYTHON,
    IMPORT_PATTERNS,
    JS_PATTERNS,
    SKIP_DIRS,
    USE_CASE_PATTERNS,
    Detection,
    ScanResult,
    _scan_config_files,
    _scan_file,
    _should_skip,
    scan,
)


# -----------------------------------------------------------------------
# Helpers
# -----------------------------------------------------------------------

def _write(tmp_path: Path, name: str, content: str) -> Path:
    """Create a file inside tmp_path and return its path."""
    fp = tmp_path / name
    fp.parent.mkdir(parents=True, exist_ok=True)
    fp.write_text(content, encoding="utf-8")
    return fp


# =======================================================================
# 1. IMPORT_PATTERNS — Python framework detection
# =======================================================================


class TestImportPatternsOpenAI:
    """OpenAI import patterns."""

    def test_import_openai(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "import openai\n")
        dets = _scan_file(fp, IMPORT_PATTERNS, "framework")
        assert any(d.framework == "openai" for d in dets)

    def test_from_openai(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "from openai import ChatCompletion\n")
        dets = _scan_file(fp, IMPORT_PATTERNS, "framework")
        assert any(d.framework == "openai" for d in dets)

    def test_openai_client_instantiation(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", 'client = OpenAI(api_key="sk-...")\n')
        dets = _scan_file(fp, IMPORT_PATTERNS, "framework")
        assert any(d.framework == "openai" for d in dets)

    def test_azure_openai_client(self, tmp_path: Path):
        # AzureOpenAI( also matches the openai "OpenAI\s*\(" pattern first due to break-on-first-match.
        # The scanner stops at the first matching pattern per line.
        fp = _write(tmp_path, "app.py", "client = AzureOpenAI(endpoint='...')\n")
        dets = _scan_file(fp, IMPORT_PATTERNS, "framework")
        assert any(d.framework in ("azure-openai", "openai") for d in dets)


class TestImportPatternsAnthropic:
    """Anthropic import patterns."""

    def test_import_anthropic(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "import anthropic\n")
        dets = _scan_file(fp, IMPORT_PATTERNS, "framework")
        assert any(d.framework == "anthropic" for d in dets)

    def test_anthropic_client(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "client = Anthropic()\n")
        dets = _scan_file(fp, IMPORT_PATTERNS, "framework")
        assert any(d.framework == "anthropic" for d in dets)


class TestImportPatternsGoogle:
    """Google / Gemini import patterns."""

    def test_google_generativeai(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "import google.generativeai as genai\n")
        dets = _scan_file(fp, IMPORT_PATTERNS, "framework")
        assert any(d.framework == "google-genai" for d in dets)

    def test_vertexai(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "from vertexai.language_models import TextGenerationModel\n")
        dets = _scan_file(fp, IMPORT_PATTERNS, "framework")
        assert any(d.framework == "google-vertex" for d in dets)


class TestImportPatternsHuggingFace:
    """HuggingFace import patterns."""

    def test_transformers(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "from transformers import AutoModel\n")
        dets = _scan_file(fp, IMPORT_PATTERNS, "framework")
        assert any(d.framework == "huggingface" for d in dets)

    def test_diffusers(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "import diffusers\n")
        dets = _scan_file(fp, IMPORT_PATTERNS, "framework")
        assert any(d.framework == "huggingface" for d in dets)

    def test_datasets(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "from datasets import load_dataset\n")
        dets = _scan_file(fp, IMPORT_PATTERNS, "framework")
        assert any(d.framework == "huggingface" for d in dets)

    def test_pipeline(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", 'result = pipeline("sentiment-analysis")\n')
        dets = _scan_file(fp, IMPORT_PATTERNS, "framework")
        assert any(d.framework == "huggingface" for d in dets)


class TestImportPatternsLangChain:
    """LangChain / LangGraph patterns."""

    def test_langchain(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "from langchain import LLMChain\n")
        dets = _scan_file(fp, IMPORT_PATTERNS, "framework")
        assert any(d.framework == "langchain" for d in dets)

    def test_langgraph(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "from langgraph.graph import StateGraph\n")
        dets = _scan_file(fp, IMPORT_PATTERNS, "framework")
        assert any(d.framework == "langgraph" for d in dets)


class TestImportPatternsMultiAgent:
    """Multi-agent framework patterns."""

    def test_crewai(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "from crewai import Agent, Crew\n")
        dets = _scan_file(fp, IMPORT_PATTERNS, "framework")
        assert any(d.framework == "crewai" for d in dets)

    def test_autogen(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "import autogen\n")
        dets = _scan_file(fp, IMPORT_PATTERNS, "framework")
        assert any(d.framework == "autogen" for d in dets)

    def test_swarm(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "from swarm import Swarm\n")
        dets = _scan_file(fp, IMPORT_PATTERNS, "framework")
        assert any(d.framework == "swarm" for d in dets)

    def test_agency_swarm(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "from agency_swarm import Agency\n")
        dets = _scan_file(fp, IMPORT_PATTERNS, "framework")
        assert any(d.framework == "agency-swarm" for d in dets)

    def test_phidata(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "from phidata.agent import Agent\n")
        dets = _scan_file(fp, IMPORT_PATTERNS, "framework")
        assert any(d.framework == "phidata" for d in dets)


class TestImportPatternsPyTorchTF:
    """PyTorch, TensorFlow, Keras, scikit-learn."""

    def test_pytorch(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "import torch\n")
        dets = _scan_file(fp, IMPORT_PATTERNS, "framework")
        assert any(d.framework == "pytorch" for d in dets)

    def test_pytorch_from(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "from torch.nn import Linear\n")
        dets = _scan_file(fp, IMPORT_PATTERNS, "framework")
        assert any(d.framework == "pytorch" for d in dets)

    def test_tensorflow(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "import tensorflow as tf\n")
        dets = _scan_file(fp, IMPORT_PATTERNS, "framework")
        assert any(d.framework == "tensorflow" for d in dets)

    def test_keras(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "from keras.layers import Dense\n")
        dets = _scan_file(fp, IMPORT_PATTERNS, "framework")
        assert any(d.framework == "keras" for d in dets)

    def test_sklearn(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "from sklearn.ensemble import RandomForestClassifier\n")
        dets = _scan_file(fp, IMPORT_PATTERNS, "framework")
        assert any(d.framework == "sklearn" for d in dets)


class TestImportPatternsProviders:
    """Ollama, LiteLLM, Cohere, Mistral, Replicate, Stability, AWS Bedrock."""

    def test_ollama(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "import ollama\n")
        dets = _scan_file(fp, IMPORT_PATTERNS, "framework")
        assert any(d.framework == "ollama" for d in dets)

    def test_litellm(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "from litellm import completion\n")
        dets = _scan_file(fp, IMPORT_PATTERNS, "framework")
        assert any(d.framework == "litellm" for d in dets)

    def test_cohere(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "import cohere\n")
        dets = _scan_file(fp, IMPORT_PATTERNS, "framework")
        assert any(d.framework == "cohere" for d in dets)

    def test_mistral(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "from mistralai.client import MistralClient\n")
        dets = _scan_file(fp, IMPORT_PATTERNS, "framework")
        assert any(d.framework == "mistral" for d in dets)

    def test_replicate(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "import replicate\n")
        dets = _scan_file(fp, IMPORT_PATTERNS, "framework")
        assert any(d.framework == "replicate" for d in dets)

    def test_stability(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "from stability_sdk import client\n")
        dets = _scan_file(fp, IMPORT_PATTERNS, "framework")
        assert any(d.framework == "stability" for d in dets)

    def test_bedrock_runtime(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", 'client = boto3.client("bedrock-runtime")\n')
        dets = _scan_file(fp, IMPORT_PATTERNS, "framework")
        assert any(d.framework == "aws-bedrock" for d in dets)


# =======================================================================
# 2. USE_CASE_PATTERNS
# =======================================================================


class TestUseCasePatterns:
    """Each use case pattern group."""

    def test_biometric_face_recognition(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "from insightface.app import FaceAnalysis\n")
        dets = _scan_file(fp, USE_CASE_PATTERNS, "use-case")
        assert any(d.framework == "biometric" for d in dets)

    def test_biometric_deepface(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "import deepface\n")
        dets = _scan_file(fp, USE_CASE_PATTERNS, "use-case")
        assert any(d.framework == "biometric" for d in dets)

    def test_emotion_detection(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "result = emotion_detect(frame)\n")
        dets = _scan_file(fp, USE_CASE_PATTERNS, "use-case")
        assert any(d.framework == "emotion" for d in dets)

    def test_sentiment_analysis(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "scores = sentiment_analysis(text)\n")
        dets = _scan_file(fp, USE_CASE_PATTERNS, "use-case")
        assert any(d.framework == "emotion" for d in dets)

    def test_recruitment(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "ranking = candidate_rank(applicants)\n")
        dets = _scan_file(fp, USE_CASE_PATTERNS, "use-case")
        assert any(d.framework == "recruitment" for d in dets)

    def test_resume_parsing(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "data = resume_parser.extract(pdf)\n")
        dets = _scan_file(fp, USE_CASE_PATTERNS, "use-case")
        assert any(d.framework == "recruitment" for d in dets)

    def test_credit_scoring(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "score = credit_scoring_model.predict(features)\n")
        dets = _scan_file(fp, USE_CASE_PATTERNS, "use-case")
        assert any(d.framework == "credit-scoring" for d in dets)

    def test_risk_scoring(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "value = risk_score(applicant)\n")
        dets = _scan_file(fp, USE_CASE_PATTERNS, "use-case")
        assert any(d.framework == "credit-scoring" for d in dets)

    def test_content_gen(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", 'response = generate_text(prompt="hello")\n')
        dets = _scan_file(fp, USE_CASE_PATTERNS, "use-case")
        assert any(d.framework == "content-gen" for d in dets)

    def test_image_gen_dalle(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "img = DALL_E_generate(prompt)\n")
        dets = _scan_file(fp, USE_CASE_PATTERNS, "use-case")
        assert any(d.framework == "image-gen" for d in dets)

    def test_image_gen_stable_diffusion(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "pipe = stable_diffusion(model_id)\n")
        dets = _scan_file(fp, USE_CASE_PATTERNS, "use-case")
        assert any(d.framework == "image-gen" for d in dets)

    def test_code_gen(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "output = code_generation(snippet)\n")
        dets = _scan_file(fp, USE_CASE_PATTERNS, "use-case")
        assert any(d.framework == "code-gen" for d in dets)

    def test_medical(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "diagnosis = medical_diagnosis(symptoms)\n")
        dets = _scan_file(fp, USE_CASE_PATTERNS, "use-case")
        assert any(d.framework == "medical" for d in dets)

    def test_patient_risk(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "risk = patient_risk_predictor(data)\n")
        dets = _scan_file(fp, USE_CASE_PATTERNS, "use-case")
        assert any(d.framework == "medical" for d in dets)

    def test_education_student_assessment(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "grade = student_assessment(answers)\n")
        dets = _scan_file(fp, USE_CASE_PATTERNS, "use-case")
        assert any(d.framework == "education" for d in dets)

    def test_education_grade_predict(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "predicted = grade_prediction(student_data)\n")
        dets = _scan_file(fp, USE_CASE_PATTERNS, "use-case")
        assert any(d.framework == "education" for d in dets)

    def test_law_enforcement(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "result = predictive_policing(area_data)\n")
        dets = _scan_file(fp, USE_CASE_PATTERNS, "use-case")
        assert any(d.framework == "law-enforcement" for d in dets)

    def test_recidivism(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "score = recidivism_model.predict(offender)\n")
        dets = _scan_file(fp, USE_CASE_PATTERNS, "use-case")
        assert any(d.framework == "law-enforcement" for d in dets)

    def test_autonomous(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "detections = lane_detect(frame)\n")
        dets = _scan_file(fp, USE_CASE_PATTERNS, "use-case")
        assert any(d.framework == "autonomous" for d in dets)

    def test_self_driving(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "control = self_driving_module.step(obs)\n")
        dets = _scan_file(fp, USE_CASE_PATTERNS, "use-case")
        assert any(d.framework == "autonomous" for d in dets)

    def test_rag_chromadb(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "db = chromadb.Client()\n")
        dets = _scan_file(fp, USE_CASE_PATTERNS, "use-case")
        assert any(d.framework == "rag" for d in dets)

    def test_rag_pinecone(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "index = pinecone.Index('my-index')\n")
        dets = _scan_file(fp, USE_CASE_PATTERNS, "use-case")
        assert any(d.framework == "rag" for d in dets)

    def test_rag_faiss(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "index = faiss.IndexFlatL2(d)\n")
        dets = _scan_file(fp, USE_CASE_PATTERNS, "use-case")
        assert any(d.framework == "rag" for d in dets)

    def test_agent_tool_use(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", 'response = client.chat(tool_choice="auto")\n')
        dets = _scan_file(fp, USE_CASE_PATTERNS, "use-case")
        assert any(d.framework == "agent" for d in dets)

    def test_agent_function_calling(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "result = function_calling(messages)\n")
        dets = _scan_file(fp, USE_CASE_PATTERNS, "use-case")
        assert any(d.framework == "agent" for d in dets)


# =======================================================================
# 3. JS_PATTERNS
# =======================================================================


class TestJSPatterns:
    """JavaScript/TypeScript SDK patterns."""

    def test_js_openai_require(self, tmp_path: Path):
        fp = _write(tmp_path, "index.js", "const OpenAI = require('openai');\n")
        dets = _scan_file(fp, JS_PATTERNS, "framework")
        assert any(d.framework == "openai" for d in dets)

    def test_js_openai_import(self, tmp_path: Path):
        fp = _write(tmp_path, "index.ts", "import OpenAI from 'openai';\n")
        dets = _scan_file(fp, JS_PATTERNS, "framework")
        assert any(d.framework == "openai" for d in dets)

    def test_js_anthropic(self, tmp_path: Path):
        fp = _write(tmp_path, "index.ts", "import Anthropic from '@anthropic-ai/sdk';\n")
        dets = _scan_file(fp, JS_PATTERNS, "framework")
        assert any(d.framework == "anthropic" for d in dets)

    def test_js_google_genai(self, tmp_path: Path):
        fp = _write(tmp_path, "app.mjs", "import { GoogleGenerativeAI } from '@google/generative-ai';\n")
        dets = _scan_file(fp, JS_PATTERNS, "framework")
        assert any(d.framework == "google-genai" for d in dets)

    def test_js_langchain(self, tmp_path: Path):
        fp = _write(tmp_path, "agent.js", "const { ChatOpenAI } = require('langchain');\n")
        dets = _scan_file(fp, JS_PATTERNS, "framework")
        assert any(d.framework == "langchain" for d in dets)

    def test_js_langchain_modules(self, tmp_path: Path):
        fp = _write(tmp_path, "agent.ts", "import { ChatOpenAI } from '@langchain/openai';\n")
        dets = _scan_file(fp, JS_PATTERNS, "framework")
        assert any(d.framework == "langchain" for d in dets)

    def test_js_vercel_ai(self, tmp_path: Path):
        fp = _write(tmp_path, "app.tsx", "import { useChat } from 'ai';\n")
        dets = _scan_file(fp, JS_PATTERNS, "framework")
        assert any(d.framework == "vercel-ai" for d in dets)

    def test_js_vercel_ai_sdk_modules(self, tmp_path: Path):
        fp = _write(tmp_path, "route.ts", "import { streamText } from '@ai-sdk/openai';\n")
        dets = _scan_file(fp, JS_PATTERNS, "framework")
        assert any(d.framework == "vercel-ai" for d in dets)

    def test_js_replicate(self, tmp_path: Path):
        fp = _write(tmp_path, "gen.js", "const Replicate = require('replicate');\n")
        dets = _scan_file(fp, JS_PATTERNS, "framework")
        assert any(d.framework == "replicate" for d in dets)

    def test_js_cohere(self, tmp_path: Path):
        fp = _write(tmp_path, "search.cjs", "const cohere = require('cohere-ai');\n")
        dets = _scan_file(fp, JS_PATTERNS, "framework")
        assert any(d.framework == "cohere" for d in dets)

    def test_js_huggingface(self, tmp_path: Path):
        fp = _write(tmp_path, "infer.js", "import { HfInference } from '@huggingface/inference';\n")
        dets = _scan_file(fp, JS_PATTERNS, "framework")
        assert any(d.framework == "huggingface" for d in dets)

    def test_js_ollama(self, tmp_path: Path):
        fp = _write(tmp_path, "local.js", "import ollama from 'ollama';\n")
        dets = _scan_file(fp, JS_PATTERNS, "framework")
        assert any(d.framework == "ollama" for d in dets)

    def test_js_mistral(self, tmp_path: Path):
        fp = _write(tmp_path, "chat.ts", "import { Mistral } from '@mistralai/mistralai';\n")
        dets = _scan_file(fp, JS_PATTERNS, "framework")
        assert any(d.framework == "mistral" for d in dets)


# =======================================================================
# 4. Config file scanning
# =======================================================================


class TestConfigScanning:
    """_scan_config_files should detect AI service references."""

    def test_json_openai_key(self, tmp_path: Path):
        fp = _write(tmp_path, "config.json", '{"OPENAI_API_KEY": "sk-..."}\n')
        dets = _scan_config_files(fp)
        assert any(d.framework == "openai" for d in dets)
        assert all(d.category == "config" for d in dets)

    def test_yaml_anthropic(self, tmp_path: Path):
        fp = _write(tmp_path, "config.yaml", "provider: anthropic\nmodel: claude-3\n")
        dets = _scan_config_files(fp)
        assert any(d.framework == "anthropic" for d in dets)

    def test_env_huggingface(self, tmp_path: Path):
        fp = _write(tmp_path, ".env", "HUGGINGFACE_TOKEN=hf_abc123\n")
        dets = _scan_config_files(fp)
        assert any(d.framework == "huggingface" for d in dets)

    def test_toml_hugging_face(self, tmp_path: Path):
        fp = _write(tmp_path, "config.toml", 'hugging_face_hub = "latest"\n')
        dets = _scan_config_files(fp)
        assert any(d.framework == "huggingface" for d in dets)

    def test_bedrock_in_config(self, tmp_path: Path):
        fp = _write(tmp_path, "infra.yaml", "service: bedrock\nregion: us-east-1\n")
        dets = _scan_config_files(fp)
        assert any(d.framework == "aws-bedrock" for d in dets)

    def test_azure_openai_in_config(self, tmp_path: Path):
        fp = _write(tmp_path, "settings.json", '{"endpoint": "azure.openai.com/v1"}\n')
        dets = _scan_config_files(fp)
        assert any(d.framework == "azure-openai" for d in dets)

    def test_vertex_ai_in_config(self, tmp_path: Path):
        fp = _write(tmp_path, "gcp.yaml", "vertex_ai:\n  project: my-proj\n")
        dets = _scan_config_files(fp)
        assert any(d.framework == "google-vertex" for d in dets)

    def test_replicate_in_config(self, tmp_path: Path):
        fp = _write(tmp_path, "env.yaml", "replicate_token: r8_xyz\n")
        dets = _scan_config_files(fp)
        assert any(d.framework == "replicate" for d in dets)

    def test_cohere_in_config(self, tmp_path: Path):
        fp = _write(tmp_path, "providers.yml", "cohere:\n  api_key: abc\n")
        dets = _scan_config_files(fp)
        assert any(d.framework == "cohere" for d in dets)

    def test_mistral_in_config(self, tmp_path: Path):
        fp = _write(tmp_path, "llm.json", '{"provider": "mistral"}\n')
        dets = _scan_config_files(fp)
        assert any(d.framework == "mistral" for d in dets)

    def test_multiple_providers_in_one_config(self, tmp_path: Path):
        fp = _write(tmp_path, "multi.yaml", "openai: true\nanthropic: true\ncohere: true\n")
        dets = _scan_config_files(fp)
        frameworks = {d.framework for d in dets}
        assert "openai" in frameworks
        assert "anthropic" in frameworks
        assert "cohere" in frameworks

    def test_no_match_in_config(self, tmp_path: Path):
        fp = _write(tmp_path, "app.json", '{"name": "myapp", "port": 3000}\n')
        dets = _scan_config_files(fp)
        assert len(dets) == 0

    def test_config_detection_line_is_zero(self, tmp_path: Path):
        """Config detections always have line=0 (whole-file match)."""
        fp = _write(tmp_path, "cfg.json", '{"openai": true}\n')
        dets = _scan_config_files(fp)
        assert all(d.line == 0 for d in dets)

    def test_config_snippet_format(self, tmp_path: Path):
        fp = _write(tmp_path, "cfg.yaml", "openai_key: sk-test\n")
        dets = _scan_config_files(fp)
        assert dets[0].snippet.startswith("Config file references")


# =======================================================================
# 5. _should_skip — directory skipping
# =======================================================================


class TestShouldSkip:
    """_should_skip must return True for blacklisted directories."""

    @pytest.mark.parametrize("dirname", list(SKIP_DIRS))
    def test_skip_dir(self, dirname: str):
        p = Path(f"/project/{dirname}/some_file.py")
        assert _should_skip(p) is True

    def test_does_not_skip_normal_dir(self):
        p = Path("/project/src/app.py")
        assert _should_skip(p) is False

    def test_nested_skip_dir(self):
        p = Path("/project/deps/node_modules/pkg/index.js")
        assert _should_skip(p) is True

    def test_skip_dot_git(self):
        p = Path("/repo/.git/objects/ab/cdef1234")
        assert _should_skip(p) is True

    def test_skip_pycache(self):
        p = Path("/project/src/__pycache__/module.cpython-312.pyc")
        assert _should_skip(p) is True

    def test_skip_venv(self):
        p = Path("/project/.venv/lib/python3.12/site-packages/openai/__init__.py")
        assert _should_skip(p) is True


# =======================================================================
# 6. Edge cases
# =======================================================================


class TestEdgeCases:
    """Empty files, binary, comment-only, snippet truncation, max_files."""

    def test_empty_file(self, tmp_path: Path):
        fp = _write(tmp_path, "empty.py", "")
        dets = _scan_file(fp, IMPORT_PATTERNS, "framework")
        assert dets == []

    def test_whitespace_only_file(self, tmp_path: Path):
        fp = _write(tmp_path, "blank.py", "   \n\n  \n")
        dets = _scan_file(fp, IMPORT_PATTERNS, "framework")
        assert dets == []

    def test_comment_only_python(self, tmp_path: Path):
        fp = _write(tmp_path, "comments.py", "# import openai\n# from anthropic import Client\n")
        dets = _scan_file(fp, IMPORT_PATTERNS, "framework")
        assert dets == []

    def test_comment_only_js(self, tmp_path: Path):
        fp = _write(tmp_path, "comments.js", "// import openai from 'openai';\n// require('anthropic');\n")
        dets = _scan_file(fp, JS_PATTERNS, "framework")
        assert dets == []

    def test_binary_file_handled_gracefully(self, tmp_path: Path):
        fp = tmp_path / "binary.py"
        fp.write_bytes(b"\x00\x01\x02\x03import openai\xff\xfe")
        dets = _scan_file(fp, IMPORT_PATTERNS, "framework")
        # Should not raise; binary is read with errors="ignore"
        assert isinstance(dets, list)

    def test_snippet_truncated_to_120_chars(self, tmp_path: Path):
        long_line = "x = " + "openai" + "a" * 200 + "\n"
        fp = _write(tmp_path, "long.py", long_line)
        dets = _scan_file(fp, IMPORT_PATTERNS, "framework")
        # There is no matching import pattern here, so no detection;
        # let's use something that matches
        long_import = "from openai import " + "A" * 200 + "\n"
        fp2 = _write(tmp_path, "long2.py", long_import)
        dets2 = _scan_file(fp2, IMPORT_PATTERNS, "framework")
        assert len(dets2) > 0
        assert len(dets2[0].snippet) == 120

    def test_max_files_limit(self, tmp_path: Path):
        """scan() should stop after max_files files."""
        for i in range(20):
            _write(tmp_path, f"mod{i}.py", "import openai\n")
        result = scan(tmp_path, max_files=5)
        assert result.files_scanned == 5
        assert any("limit" in e.lower() for e in result.errors)

    def test_nonexistent_path(self, tmp_path: Path):
        result = scan(tmp_path / "does_not_exist")
        assert len(result.errors) > 0
        assert "does not exist" in result.errors[0].lower()

    def test_permission_error_graceful(self, tmp_path: Path):
        """_scan_file handles OSError/PermissionError without crashing."""
        fp = tmp_path / "noperm.py"
        fp.write_text("import openai\n")
        fp.chmod(0o000)
        try:
            dets = _scan_file(fp, IMPORT_PATTERNS, "framework")
            # Should return empty list, not raise
            assert isinstance(dets, list)
        finally:
            fp.chmod(0o644)

    def test_one_detection_per_line(self, tmp_path: Path):
        """Scanner breaks after first match per line."""
        fp = _write(tmp_path, "multi.py", "import openai; import anthropic\n")
        dets = _scan_file(fp, IMPORT_PATTERNS, "framework")
        # Only 1 detection per line (breaks after first match)
        assert len(dets) == 1

    def test_case_insensitive_matching(self, tmp_path: Path):
        fp = _write(tmp_path, "app.py", "Import OpenAI\n")
        dets = _scan_file(fp, IMPORT_PATTERNS, "framework")
        assert any(d.framework == "openai" for d in dets)

    def test_unsupported_extension_ignored(self, tmp_path: Path):
        """Files with unsupported extensions are not scanned."""
        _write(tmp_path, "readme.md", "import openai\n")
        _write(tmp_path, "image.png", "fake data")
        result = scan(tmp_path)
        assert result.files_scanned == 0
        assert result.total_detections == 0


# =======================================================================
# 7. ScanResult properties
# =======================================================================


class TestScanResultProperties:
    """Verify ScanResult aggregation and computed properties."""

    def test_total_detections(self, tmp_path: Path):
        _write(tmp_path, "a.py", "import openai\nimport anthropic\n")
        result = scan(tmp_path)
        assert result.total_detections >= 2

    def test_unique_frameworks(self, tmp_path: Path):
        _write(tmp_path, "a.py", "import openai\n")
        _write(tmp_path, "b.py", "import anthropic\n")
        _write(tmp_path, "c.py", "import openai\n")
        result = scan(tmp_path)
        assert "openai" in result.unique_frameworks
        assert "anthropic" in result.unique_frameworks

    def test_unique_use_cases(self, tmp_path: Path):
        _write(tmp_path, "face.py", "from insightface.app import FaceAnalysis\n")
        _write(tmp_path, "credit.py", "score = credit_scoring(data)\n")
        result = scan(tmp_path)
        assert "biometric" in result.unique_use_cases
        assert "credit-scoring" in result.unique_use_cases

    def test_frameworks_count(self, tmp_path: Path):
        _write(tmp_path, "a.py", "import openai\n")
        _write(tmp_path, "b.py", "from openai import Client\n")
        result = scan(tmp_path)
        assert result.frameworks.get("openai", 0) >= 2

    def test_use_cases_count(self, tmp_path: Path):
        _write(tmp_path, "a.py", "x = chromadb.Client()\n")
        _write(tmp_path, "b.py", "y = pinecone.connect()\n")
        result = scan(tmp_path)
        assert result.use_cases.get("rag", 0) >= 2

    def test_empty_result(self, tmp_path: Path):
        _write(tmp_path, "clean.py", "print('hello world')\n")
        result = scan(tmp_path)
        assert result.total_detections == 0
        assert result.unique_frameworks == set()
        assert result.unique_use_cases == set()
        assert result.files_scanned == 1

    def test_errors_list_empty_on_success(self, tmp_path: Path):
        _write(tmp_path, "ok.py", "x = 1\n")
        result = scan(tmp_path)
        assert result.errors == []


# =======================================================================
# 8. Single file scanning vs directory scanning
# =======================================================================


class TestScanModes:
    """scan() with a single file path vs a directory path."""

    def test_scan_single_python_file(self, tmp_path: Path):
        fp = _write(tmp_path, "single.py", "import torch\n")
        result = scan(fp)
        assert result.files_scanned == 1
        assert "pytorch" in result.unique_frameworks

    def test_scan_single_js_file(self, tmp_path: Path):
        fp = _write(tmp_path, "app.ts", "import OpenAI from 'openai';\n")
        result = scan(fp)
        assert result.files_scanned == 1
        assert "openai" in result.unique_frameworks

    def test_scan_single_config_file(self, tmp_path: Path):
        fp = _write(tmp_path, "config.yaml", "provider: anthropic\n")
        result = scan(fp)
        assert result.files_scanned == 1
        assert "anthropic" in result.unique_frameworks

    def test_scan_directory_recursive(self, tmp_path: Path):
        _write(tmp_path, "src/main.py", "import openai\n")
        _write(tmp_path, "lib/utils.py", "import torch\n")
        _write(tmp_path, "config.json", '{"anthropic": true}\n')
        result = scan(tmp_path)
        assert result.files_scanned == 3
        assert "openai" in result.unique_frameworks
        assert "pytorch" in result.unique_frameworks
        assert "anthropic" in result.unique_frameworks

    def test_scan_directory_skips_node_modules(self, tmp_path: Path):
        _write(tmp_path, "src/app.py", "import openai\n")
        _write(tmp_path, "node_modules/openai/index.js", "const x = require('openai');\n")
        result = scan(tmp_path)
        # Only src/app.py should be scanned
        assert result.files_scanned == 1

    def test_scan_directory_skips_venv(self, tmp_path: Path):
        _write(tmp_path, "app.py", "import anthropic\n")
        _write(tmp_path, ".venv/lib/python3.12/site-packages/anthropic/__init__.py", "import anthropic\n")
        result = scan(tmp_path)
        assert result.files_scanned == 1

    def test_scan_mixed_py_and_js(self, tmp_path: Path):
        _write(tmp_path, "backend.py", "import openai\n")
        _write(tmp_path, "frontend.tsx", "import { useChat } from 'ai';\n")
        result = scan(tmp_path)
        assert "openai" in result.unique_frameworks
        assert "vercel-ai" in result.unique_frameworks

    def test_scan_string_path_accepted(self, tmp_path: Path):
        """scan() accepts str as well as Path."""
        _write(tmp_path, "app.py", "import openai\n")
        result = scan(str(tmp_path))
        assert result.files_scanned == 1


# =======================================================================
# 9. Detection dataclass
# =======================================================================


class TestDetectionDataclass:
    """Test Detection fields and defaults."""

    def test_detection_fields(self):
        d = Detection(
            file="/test.py",
            line=5,
            framework="openai",
            description="OpenAI API client",
            snippet="import openai",
        )
        assert d.file == "/test.py"
        assert d.line == 5
        assert d.framework == "openai"
        assert d.description == "OpenAI API client"
        assert d.snippet == "import openai"
        assert d.category == "framework"  # default

    def test_detection_category_override(self):
        d = Detection(
            file="/test.py",
            line=10,
            framework="biometric",
            description="Face recognition",
            snippet="face_recognition.detect()",
            category="use-case",
        )
        assert d.category == "use-case"


# =======================================================================
# 10. Extension sets / constants
# =======================================================================


class TestConstants:
    """Ensure the extension and skip sets contain expected values."""

    def test_python_extensions(self):
        assert ".py" in EXTENSIONS_PYTHON
        assert ".pyw" in EXTENSIONS_PYTHON

    def test_js_extensions(self):
        for ext in (".js", ".jsx", ".ts", ".tsx", ".mjs", ".cjs"):
            assert ext in EXTENSIONS_JS

    def test_config_extensions(self):
        for ext in (".json", ".yaml", ".yml", ".toml", ".env"):
            assert ext in EXTENSIONS_CONFIG

    def test_skip_dirs_has_common_entries(self):
        for d in ("node_modules", ".git", "__pycache__", ".venv", "dist", "build"):
            assert d in SKIP_DIRS

    def test_import_patterns_count(self):
        assert len(IMPORT_PATTERNS) >= 30

    def test_use_case_patterns_count(self):
        assert len(USE_CASE_PATTERNS) >= 13

    def test_js_patterns_count(self):
        assert len(JS_PATTERNS) >= 11


# =======================================================================
# 11. Integration: use cases detected together with frameworks
# =======================================================================


class TestIntegration:
    """Full scan that detects frameworks AND use cases in one pass."""

    def test_framework_and_use_case_together(self, tmp_path: Path):
        code = (
            "import openai\n"
            "from insightface.app import FaceAnalysis\n"
            "score = credit_scoring(data)\n"
        )
        _write(tmp_path, "app.py", code)
        result = scan(tmp_path)
        assert "openai" in result.unique_frameworks
        assert "biometric" in result.unique_use_cases
        assert "credit-scoring" in result.unique_use_cases

    def test_js_use_cases_detected(self, tmp_path: Path):
        """USE_CASE_PATTERNS are also applied to JS files."""
        code = (
            "import OpenAI from 'openai';\n"
            "const result = face_recognition(img);\n"
        )
        _write(tmp_path, "app.js", code)
        result = scan(tmp_path)
        assert "openai" in result.unique_frameworks
        assert "biometric" in result.unique_use_cases

    def test_config_counted_as_framework(self, tmp_path: Path):
        """Config detections go into frameworks dict, not use_cases."""
        _write(tmp_path, "cfg.json", '{"openai": "sk-key"}\n')
        result = scan(tmp_path)
        assert "openai" in result.frameworks
        assert "openai" not in result.use_cases

    def test_path_stored_as_resolved_absolute(self, tmp_path: Path):
        _write(tmp_path, "x.py", "import openai\n")
        result = scan(tmp_path)
        assert os.path.isabs(result.path)
