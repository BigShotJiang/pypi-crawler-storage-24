"""Tests for isologic CLI (Click commands via CliRunner)."""

from __future__ import annotations

import json
import os
from pathlib import Path

import pytest
from click.testing import CliRunner

from isologic import __version__
from isologic.cli import main


@pytest.fixture
def runner():
    """Provide a Click CliRunner."""
    return CliRunner()


# ---------------------------------------------------------------------------
# Helper: create temporary source files inside tmp_path
# ---------------------------------------------------------------------------

def _write_file(directory: Path, name: str, content: str) -> Path:
    """Write a file into *directory* and return its path."""
    fp = directory / name
    fp.write_text(content, encoding="utf-8")
    return fp


# ---------------------------------------------------------------------------
# 1. --version flag
# ---------------------------------------------------------------------------

def test_version_flag(runner: CliRunner):
    """--version outputs the current version string."""
    result = runner.invoke(main, ["--version"])
    assert result.exit_code == 0
    assert __version__ in result.output
    assert "isologic" in result.output


# ---------------------------------------------------------------------------
# 2. audit with no AI files -> exit 0, "No AI systems detected"
# ---------------------------------------------------------------------------

def test_audit_no_ai_files(runner: CliRunner, tmp_path: Path):
    """Scanning a directory with no AI imports yields exit 0 and a clean message."""
    _write_file(tmp_path, "app.py", "print('hello world')\n")
    result = runner.invoke(main, ["audit", str(tmp_path)])
    assert result.exit_code == 0
    assert "No AI systems detected" in result.output


# ---------------------------------------------------------------------------
# 3. audit with high-risk AI file -> exit code 1
# ---------------------------------------------------------------------------

def test_audit_high_risk_exit_code(runner: CliRunner, tmp_path: Path):
    """A file with a high-risk use case (recruitment) triggers exit code 1."""
    _write_file(
        tmp_path,
        "hr_tool.py",
        "from sklearn import svm\nresume_parser = candidate_ranking(data)\n",
    )
    result = runner.invoke(main, ["audit", str(tmp_path)])
    assert result.exit_code == 1


# ---------------------------------------------------------------------------
# 4. audit with unacceptable AI file -> exit code 2
# ---------------------------------------------------------------------------

def test_audit_unacceptable_exit_code(runner: CliRunner, tmp_path: Path):
    """A file with face_recognition (biometric) triggers exit code 2."""
    _write_file(
        tmp_path,
        "face.py",
        "from face_recognition import load_image_file\n",
    )
    result = runner.invoke(main, ["audit", str(tmp_path)])
    assert result.exit_code == 2


# ---------------------------------------------------------------------------
# 5. audit with --json flag outputs valid JSON to stdout
# ---------------------------------------------------------------------------

def test_audit_json_stdout(runner: CliRunner, tmp_path: Path):
    """--json emits parseable JSON to stdout."""
    _write_file(tmp_path, "bot.py", "from openai import OpenAI\n")
    result = runner.invoke(main, ["audit", str(tmp_path), "--json"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert "summary" in data
    assert "classifications" in data
    assert "files_scanned" in data
    assert data["files_scanned"] >= 1


# ---------------------------------------------------------------------------
# 6. audit with --output saves file
# ---------------------------------------------------------------------------

def test_audit_output_saves_json_file(runner: CliRunner, tmp_path: Path):
    """--output writes a report file to disk."""
    _write_file(tmp_path, "bot.py", "from openai import OpenAI\n")
    report_path = tmp_path / "report"
    result = runner.invoke(main, ["audit", str(tmp_path), "--output", str(report_path)])
    # exit code 0 because openai is GPAI, not high-risk
    assert result.exit_code == 0
    saved = tmp_path / "report.json"
    assert saved.exists()
    data = json.loads(saved.read_text(encoding="utf-8"))
    assert "classifications" in data


# ---------------------------------------------------------------------------
# 7. audit with --format md saves markdown file
# ---------------------------------------------------------------------------

def test_audit_format_md_saves_markdown(runner: CliRunner, tmp_path: Path):
    """--format md + --output produces a .md file."""
    _write_file(tmp_path, "bot.py", "from openai import OpenAI\n")
    report_path = tmp_path / "compliance"
    result = runner.invoke(
        main,
        ["audit", str(tmp_path), "--output", str(report_path), "--format", "md"],
    )
    assert result.exit_code == 0
    saved = tmp_path / "compliance.md"
    assert saved.exists()
    content = saved.read_text(encoding="utf-8")
    assert "# Isologic EU AI Act Compliance Audit Report" in content


# ---------------------------------------------------------------------------
# 8. audit with --max-files limits scanning
# ---------------------------------------------------------------------------

def test_audit_max_files_limits_scan(runner: CliRunner, tmp_path: Path):
    """--max-files caps the number of files processed."""
    for i in range(5):
        _write_file(tmp_path, f"mod{i}.py", "from openai import OpenAI\n")

    result = runner.invoke(main, ["audit", str(tmp_path), "--json", "--max-files", "2"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    # We asked for max 2 files; scanner should honour that
    assert data["files_scanned"] <= 2


# ---------------------------------------------------------------------------
# 9. info command shows key dates and risk categories
# ---------------------------------------------------------------------------

def test_info_command(runner: CliRunner):
    """info subcommand prints EU AI Act reference material."""
    result = runner.invoke(main, ["info"])
    assert result.exit_code == 0
    assert "EU AI Act" in result.output
    assert "Feb 2, 2025" in result.output
    assert "Aug 2, 2026" in result.output
    assert "UNACCEPTABLE" in result.output
    assert "HIGH RISK" in result.output
    assert "GPAI" in result.output
    assert "Penalties" in result.output


# ---------------------------------------------------------------------------
# 10. audit on non-existent path -> error
# ---------------------------------------------------------------------------

def test_audit_nonexistent_path(runner: CliRunner):
    """Pointing audit at a missing path should fail."""
    result = runner.invoke(main, ["audit", "/tmp/definitely-not-a-real-path-xyz123"])
    assert result.exit_code != 0


# ---------------------------------------------------------------------------
# 11. audit on single file works
# ---------------------------------------------------------------------------

def test_audit_single_file(runner: CliRunner, tmp_path: Path):
    """Audit can be invoked on a single file instead of a directory."""
    fp = _write_file(tmp_path, "agent.py", "from langchain import LLMChain\n")
    result = runner.invoke(main, ["audit", str(fp), "--json"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["files_scanned"] == 1
    assert len(data["classifications"]) >= 1
    assert any(c["framework"] == "langchain" for c in data["classifications"])


# ---------------------------------------------------------------------------
# 12. --json and --output together (json takes precedence for stdout)
# ---------------------------------------------------------------------------

def test_audit_json_and_output_together(runner: CliRunner, tmp_path: Path):
    """When both --json and --output are given, --json writes to stdout."""
    _write_file(tmp_path, "bot.py", "from openai import OpenAI\n")
    report_path = tmp_path / "report"
    result = runner.invoke(
        main,
        ["audit", str(tmp_path), "--json", "--output", str(report_path)],
    )
    # --json causes early return with JSON on stdout (no file save)
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert "classifications" in data


# ---------------------------------------------------------------------------
# Additional tests (13+)
# ---------------------------------------------------------------------------

def test_audit_gpai_detection(runner: CliRunner, tmp_path: Path):
    """OpenAI import is classified as GPAI, which is not high-risk -> exit 0."""
    _write_file(tmp_path, "chatbot.py", "from openai import OpenAI\nclient = OpenAI()\n")
    result = runner.invoke(main, ["audit", str(tmp_path), "--json"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert "gpai" in data["summary"]


def test_audit_emotion_recognition_unacceptable(runner: CliRunner, tmp_path: Path):
    """Emotion detection pattern triggers unacceptable risk -> exit 2."""
    _write_file(
        tmp_path,
        "monitor.py",
        "result = emotion_detect(video_frame)\n",
    )
    result = runner.invoke(main, ["audit", str(tmp_path)])
    assert result.exit_code == 2


def test_audit_credit_scoring_high_risk(runner: CliRunner, tmp_path: Path):
    """Credit scoring pattern triggers high risk -> exit 1."""
    _write_file(
        tmp_path,
        "lending.py",
        "score = credit_score_model.predict(features)\n",
    )
    result = runner.invoke(main, ["audit", str(tmp_path)])
    assert result.exit_code == 1


def test_audit_javascript_detection(runner: CliRunner, tmp_path: Path):
    """JavaScript AI SDK imports are detected."""
    _write_file(
        tmp_path,
        "index.js",
        'import OpenAI from "openai";\nconst client = new OpenAI();\n',
    )
    result = runner.invoke(main, ["audit", str(tmp_path), "--json"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["files_scanned"] >= 1
    assert "openai" in data["frameworks_detected"]


def test_audit_multiple_frameworks(runner: CliRunner, tmp_path: Path):
    """Multiple AI frameworks in one project are all detected."""
    _write_file(
        tmp_path,
        "multi.py",
        "from openai import OpenAI\nfrom anthropic import Anthropic\nfrom langchain import LLMChain\n",
    )
    result = runner.invoke(main, ["audit", str(tmp_path), "--json"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    detected = set(data["frameworks_detected"].keys())
    assert "openai" in detected
    assert "anthropic" in detected
    assert "langchain" in detected


def test_audit_empty_directory(runner: CliRunner, tmp_path: Path):
    """Scanning an empty directory -> exit 0, no detections."""
    result = runner.invoke(main, ["audit", str(tmp_path), "--json"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["files_scanned"] == 0
    assert data["classifications"] == []


def test_audit_json_output_has_required_fields(runner: CliRunner, tmp_path: Path):
    """JSON output contains all expected top-level keys."""
    _write_file(tmp_path, "bot.py", "from openai import OpenAI\n")
    result = runner.invoke(main, ["audit", str(tmp_path), "--json"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    expected_keys = {
        "version", "timestamp", "path", "files_scanned",
        "summary", "frameworks_detected", "use_cases_detected",
        "classifications", "errors",
    }
    assert expected_keys.issubset(set(data.keys()))


def test_audit_classification_fields_complete(runner: CliRunner, tmp_path: Path):
    """Each classification entry in JSON has all required fields."""
    _write_file(tmp_path, "bot.py", "from openai import OpenAI\n")
    result = runner.invoke(main, ["audit", str(tmp_path), "--json"])
    data = json.loads(result.output)
    for c in data["classifications"]:
        assert "file" in c
        assert "line" in c
        assert "framework" in c
        assert "risk_level" in c
        assert "annex" in c
        assert "reason" in c
        assert "obligations" in c
        assert isinstance(c["obligations"], list)
        assert "deadline" in c


def test_audit_skips_venv_and_node_modules(runner: CliRunner, tmp_path: Path):
    """Directories like .venv and node_modules are skipped."""
    venv_dir = tmp_path / ".venv"
    venv_dir.mkdir()
    _write_file(venv_dir, "hidden.py", "from openai import OpenAI\n")

    node_dir = tmp_path / "node_modules"
    node_dir.mkdir()
    _write_file(node_dir, "lib.js", 'import OpenAI from "openai";\n')

    # Only a clean file in the root
    _write_file(tmp_path, "main.py", "print('no ai here')\n")

    result = runner.invoke(main, ["audit", str(tmp_path), "--json"])
    assert result.exit_code == 0
    data = json.loads(result.output)
    assert data["frameworks_detected"] == {}


def test_audit_medical_high_risk(runner: CliRunner, tmp_path: Path):
    """Medical diagnosis pattern triggers high risk -> exit 1."""
    _write_file(
        tmp_path,
        "diagnosis.py",
        "result = medical_diagnosis_model.predict(patient_data)\n",
    )
    result = runner.invoke(main, ["audit", str(tmp_path)])
    assert result.exit_code == 1


def test_audit_report_saved_text(runner: CliRunner, tmp_path: Path):
    """Console output mentions the saved report path."""
    _write_file(tmp_path, "bot.py", "from openai import OpenAI\n")
    report_path = tmp_path / "out"
    result = runner.invoke(
        main,
        ["audit", str(tmp_path), "--output", str(report_path)],
    )
    assert result.exit_code == 0
    assert "Report saved to" in result.output
