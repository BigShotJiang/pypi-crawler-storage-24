"""Tests for isologic.reporter — report generation in JSON, Markdown, and terminal."""

from __future__ import annotations

import json

import pytest
from rich.console import Console

from isologic.classifier import ClassificationReport, RiskClassification, RiskLevel
from isologic.reporter import (
    RISK_COLORS,
    RISK_ICONS,
    compliance_score,
    print_report,
    save_report,
    to_json,
    to_markdown,
)
from isologic.scanner import Detection, ScanResult


# ---------------------------------------------------------------------------
# Fixtures / helpers
# ---------------------------------------------------------------------------


def _make_detection(
    *,
    file: str = "app.py",
    line: int = 10,
    framework: str = "openai",
    description: str = "OpenAI API client",
    snippet: str = "import openai",
    category: str = "framework",
) -> Detection:
    return Detection(
        file=file,
        line=line,
        framework=framework,
        description=description,
        snippet=snippet,
        category=category,
    )


def _make_classification(
    risk_level: RiskLevel = RiskLevel.MINIMAL,
    *,
    framework: str = "sklearn",
    annex: str = "No specific obligations",
    reason: str = "Minimal risk",
    obligations: list[str] | None = None,
    deadline: str = "N/A",
    file: str = "model.py",
    line: int = 1,
    category: str = "framework",
) -> RiskClassification:
    return RiskClassification(
        detection=_make_detection(
            file=file, line=line, framework=framework, category=category,
        ),
        risk_level=risk_level,
        annex=annex,
        reason=reason,
        obligations=obligations or ["Check compliance"],
        deadline=deadline,
    )


def _make_scan_result(
    *,
    path: str = "/tmp/project",
    files_scanned: int = 42,
    frameworks: dict[str, int] | None = None,
    use_cases: dict[str, int] | None = None,
    errors: list[str] | None = None,
) -> ScanResult:
    return ScanResult(
        path=path,
        files_scanned=files_scanned,
        frameworks=frameworks or {},
        use_cases=use_cases or {},
        errors=errors or [],
    )


def _make_report(
    classifications: list[RiskClassification] | None = None,
    summary: dict[RiskLevel, int] | None = None,
    **scan_kwargs,
) -> ClassificationReport:
    if classifications is None:
        classifications = []
    if summary is None:
        summary = {}
        for c in classifications:
            summary[c.risk_level] = summary.get(c.risk_level, 0) + 1
    return ClassificationReport(
        scan_result=_make_scan_result(**scan_kwargs),
        classifications=classifications,
        summary=summary,
    )


# ---------------------------------------------------------------------------
# RISK_COLORS and RISK_ICONS
# ---------------------------------------------------------------------------


class TestRiskDicts:
    """RISK_COLORS and RISK_ICONS must cover every RiskLevel."""

    def test_risk_colors_cover_all_levels(self):
        for level in RiskLevel:
            assert level in RISK_COLORS, f"Missing RISK_COLORS entry for {level}"

    def test_risk_icons_cover_all_levels(self):
        for level in RiskLevel:
            assert level in RISK_ICONS, f"Missing RISK_ICONS entry for {level}"

    def test_risk_colors_values_are_strings(self):
        for level, color in RISK_COLORS.items():
            assert isinstance(color, str) and len(color) > 0

    def test_risk_icons_values_are_two_chars(self):
        for level, icon in RISK_ICONS.items():
            assert isinstance(icon, str) and len(icon) == 2


# ---------------------------------------------------------------------------
# compliance_score()
# ---------------------------------------------------------------------------


class TestComplianceScore:
    """Compliance score calculation matches SaaS backend algorithm."""

    def test_empty_summary_returns_100(self):
        assert compliance_score({}) == 100.0

    def test_all_minimal_returns_100(self):
        assert compliance_score({"minimal": 5}) == 100.0

    def test_single_unacceptable_penalises_heavily(self):
        score = compliance_score({"unacceptable": 1})
        assert score == 50.0

    def test_single_high_risk(self):
        score = compliance_score({"high": 1})
        assert score == 80.0

    def test_single_limited(self):
        score = compliance_score({"limited": 1})
        assert score == 95.0

    def test_single_gpai(self):
        score = compliance_score({"gpai": 1})
        assert score == 97.0

    def test_single_unknown(self):
        score = compliance_score({"unknown": 1})
        assert score == 90.0

    def test_mixed_systems(self):
        score = compliance_score({"unacceptable": 1, "minimal": 3})
        # penalty = -50 + 0 = -50, total = 4, score = 100 + (-50/4) = 87.5
        assert score == 87.5

    def test_score_never_below_zero(self):
        # All unacceptable: penalty/total = -50, score = 50. Verify >= 0.
        score = compliance_score({"unacceptable": 10})
        assert score >= 0.0
        assert score == 50.0

    def test_score_never_above_100(self):
        score = compliance_score({"minimal": 100})
        assert score == 100.0

    def test_score_is_rounded_to_one_decimal(self):
        score = compliance_score({"high": 1, "minimal": 2})
        # penalty = -20, total = 3, score = 100 + (-20/3) = 93.333... -> 93.3
        assert score == 93.3


# ---------------------------------------------------------------------------
# to_json()
# ---------------------------------------------------------------------------


class TestToJson:
    """JSON export should produce valid, well-structured output."""

    def test_valid_json(self):
        report = _make_report()
        raw = to_json(report)
        data = json.loads(raw)  # must not raise
        assert isinstance(data, dict)

    def test_top_level_keys(self):
        report = _make_report()
        data = json.loads(to_json(report))
        expected_keys = {
            "version", "timestamp", "path", "files_scanned",
            "summary", "compliance_score", "frameworks_detected",
            "use_cases_detected", "classifications", "errors",
        }
        assert set(data.keys()) == expected_keys

    def test_version_field(self):
        data = json.loads(to_json(_make_report()))
        assert data["version"] == "0.1.0"

    def test_timestamp_is_iso(self):
        data = json.loads(to_json(_make_report()))
        # ISO 8601 basic check: contains 'T' and ends with '+00:00' or 'Z'
        ts = data["timestamp"]
        assert "T" in ts

    def test_path_matches_scan(self):
        report = _make_report(path="/my/project")
        data = json.loads(to_json(report))
        assert data["path"] == "/my/project"

    def test_files_scanned_matches_scan(self):
        report = _make_report(files_scanned=99)
        data = json.loads(to_json(report))
        assert data["files_scanned"] == 99

    def test_empty_classifications(self):
        report = _make_report()
        data = json.loads(to_json(report))
        assert data["classifications"] == []
        assert data["summary"] == {}

    def test_single_classification_structure(self):
        c = _make_classification(RiskLevel.HIGH, framework="openai", annex="Annex III")
        report = _make_report(classifications=[c])
        data = json.loads(to_json(report))

        assert len(data["classifications"]) == 1
        entry = data["classifications"][0]
        assert entry["risk_level"] == "high"
        assert entry["framework"] == "openai"
        assert entry["annex"] == "Annex III"
        assert isinstance(entry["obligations"], list)
        assert "file" in entry
        assert "line" in entry
        assert "description" in entry
        assert "reason" in entry
        assert "deadline" in entry

    def test_multiple_risk_levels_in_summary(self):
        classifications = [
            _make_classification(RiskLevel.HIGH, framework="openai", file="a.py"),
            _make_classification(RiskLevel.MINIMAL, framework="sklearn", file="b.py"),
            _make_classification(RiskLevel.GPAI, framework="anthropic", file="c.py"),
            _make_classification(RiskLevel.UNACCEPTABLE, framework="deepface", file="d.py", category="use-case"),
        ]
        report = _make_report(classifications=classifications)
        data = json.loads(to_json(report))

        assert data["summary"]["high"] == 1
        assert data["summary"]["minimal"] == 1
        assert data["summary"]["gpai"] == 1
        assert data["summary"]["unacceptable"] == 1
        assert len(data["classifications"]) == 4

    def test_errors_propagated(self):
        report = _make_report(errors=["file limit hit", "permission denied"])
        data = json.loads(to_json(report))
        assert data["errors"] == ["file limit hit", "permission denied"]

    def test_frameworks_detected(self):
        report = _make_report(frameworks={"openai": 3, "pytorch": 1})
        data = json.loads(to_json(report))
        assert data["frameworks_detected"] == {"openai": 3, "pytorch": 1}

    def test_use_cases_detected(self):
        report = _make_report(use_cases={"biometric": 2})
        data = json.loads(to_json(report))
        assert data["use_cases_detected"] == {"biometric": 2}

    def test_compliance_score_in_json(self):
        c = _make_classification(RiskLevel.HIGH, framework="openai")
        report = _make_report(classifications=[c])
        data = json.loads(to_json(report))
        assert "compliance_score" in data
        assert isinstance(data["compliance_score"], float)
        assert 0 <= data["compliance_score"] <= 100

    def test_compliance_score_matches_algorithm(self):
        c = _make_classification(RiskLevel.UNACCEPTABLE, framework="deepface")
        report = _make_report(classifications=[c])
        data = json.loads(to_json(report))
        assert data["compliance_score"] == 50.0


# ---------------------------------------------------------------------------
# to_markdown()
# ---------------------------------------------------------------------------


class TestToMarkdown:
    """Markdown export should produce well-structured text."""

    def test_starts_with_h1(self):
        md = to_markdown(_make_report())
        assert md.startswith("# Isologic EU AI Act Compliance Audit Report")

    def test_contains_path(self):
        md = to_markdown(_make_report(path="/my/codebase"))
        assert "`/my/codebase`" in md

    def test_contains_files_scanned(self):
        md = to_markdown(_make_report(files_scanned=123))
        assert "123" in md

    def test_risk_summary_table_header(self):
        md = to_markdown(_make_report())
        assert "| Risk Level | Count | Status |" in md

    def test_empty_classifications_no_systems_section(self):
        md = to_markdown(_make_report())
        assert "## Detected AI Systems" in md
        # Should still have the section header but no ### subsections
        assert "###" not in md

    def test_classification_subsection(self):
        c = _make_classification(RiskLevel.HIGH, framework="openai")
        md = to_markdown(_make_report(classifications=[c]))
        assert "### [HIGH] openai" in md

    def test_obligations_checkboxes(self):
        c = _make_classification(
            RiskLevel.LIMITED,
            obligations=["Disclose AI use", "Document data flows"],
        )
        md = to_markdown(_make_report(classifications=[c]))
        assert "- [ ] Disclose AI use" in md
        assert "- [ ] Document data flows" in md

    def test_all_risk_levels_in_summary_table(self):
        classifications = [
            _make_classification(RiskLevel.UNACCEPTABLE, file="a.py"),
            _make_classification(RiskLevel.HIGH, file="b.py"),
            _make_classification(RiskLevel.LIMITED, file="c.py"),
            _make_classification(RiskLevel.GPAI, file="d.py"),
            _make_classification(RiskLevel.MINIMAL, file="e.py"),
            _make_classification(RiskLevel.UNKNOWN, file="f.py"),
        ]
        md = to_markdown(_make_report(classifications=classifications))
        assert "**UNACCEPTABLE**" in md
        assert "**HIGH**" in md
        assert "**LIMITED**" in md
        assert "**GPAI**" in md
        assert "**MINIMAL**" in md
        assert "**UNKNOWN**" in md

    def test_footer_contains_version(self):
        md = to_markdown(_make_report())
        assert "Isologic v0.1.0" in md

    def test_classification_details(self):
        c = _make_classification(
            RiskLevel.HIGH,
            framework="openai",
            annex="Annex III, 4(a)",
            reason="Recruitment AI is high-risk",
            deadline="Aug 2, 2026",
            file="recruit.py",
            line=55,
        )
        md = to_markdown(_make_report(classifications=[c]))
        assert "`recruit.py:55`" in md
        assert "Annex III, 4(a)" in md
        assert "Recruitment AI is high-risk" in md
        assert "Aug 2, 2026" in md

    def test_multiple_classifications_each_get_subsection(self):
        classifications = [
            _make_classification(RiskLevel.HIGH, framework="openai", file="a.py"),
            _make_classification(RiskLevel.MINIMAL, framework="sklearn", file="b.py"),
        ]
        md = to_markdown(_make_report(classifications=classifications))
        assert md.count("###") == 2

    def test_compliance_score_in_markdown(self):
        c = _make_classification(RiskLevel.HIGH, framework="openai")
        md = to_markdown(_make_report(classifications=[c]))
        assert "Compliance Score:" in md
        assert "/100" in md


# ---------------------------------------------------------------------------
# save_report()
# ---------------------------------------------------------------------------


class TestSaveReport:
    """File saving with auto-extension and format validation."""

    def test_save_json_creates_file(self, tmp_path):
        report = _make_report(
            classifications=[_make_classification(RiskLevel.MINIMAL)],
        )
        out = save_report(report, str(tmp_path / "report.json"), fmt="json")
        assert out.endswith(".json")
        content = (tmp_path / "report.json").read_text()
        data = json.loads(content)
        assert data["version"] == "0.1.0"

    def test_save_md_creates_file(self, tmp_path):
        report = _make_report(
            classifications=[_make_classification(RiskLevel.HIGH)],
        )
        out = save_report(report, str(tmp_path / "report.md"), fmt="md")
        assert out.endswith(".md")
        content = (tmp_path / "report.md").read_text()
        assert content.startswith("# Isologic")

    def test_save_json_auto_extension(self, tmp_path):
        report = _make_report()
        out = save_report(report, str(tmp_path / "report"), fmt="json")
        assert out.endswith(".json")
        assert (tmp_path / "report.json").exists()

    def test_save_md_auto_extension(self, tmp_path):
        report = _make_report()
        out = save_report(report, str(tmp_path / "report"), fmt="md")
        assert out.endswith(".md")
        assert (tmp_path / "report.md").exists()

    def test_save_unknown_format_raises(self, tmp_path):
        report = _make_report()
        with pytest.raises(ValueError, match="Unknown format"):
            save_report(report, str(tmp_path / "report"), fmt="csv")

    def test_save_json_content_is_valid(self, tmp_path):
        c = _make_classification(RiskLevel.GPAI, framework="anthropic")
        report = _make_report(classifications=[c])
        save_report(report, str(tmp_path / "out.json"), fmt="json")
        data = json.loads((tmp_path / "out.json").read_text())
        assert len(data["classifications"]) == 1
        assert data["classifications"][0]["risk_level"] == "gpai"

    def test_save_md_content_has_checkboxes(self, tmp_path):
        c = _make_classification(
            RiskLevel.LIMITED,
            obligations=["Ensure transparency"],
        )
        report = _make_report(classifications=[c])
        save_report(report, str(tmp_path / "out.md"), fmt="md")
        content = (tmp_path / "out.md").read_text()
        assert "- [ ] Ensure transparency" in content

    def test_save_preserves_existing_extension(self, tmp_path):
        report = _make_report()
        out = save_report(report, str(tmp_path / "report.txt"), fmt="json")
        # Already has .txt suffix, so no .json is added
        assert out.endswith(".txt")
        assert (tmp_path / "report.txt").exists()


# ---------------------------------------------------------------------------
# print_report()
# ---------------------------------------------------------------------------


class TestPrintReport:
    """Terminal output should not crash and should handle edge cases."""

    def _capture(self, report: ClassificationReport) -> str:
        """Render report to a string via a recording Console."""
        console = Console(file=None, record=True, width=120)
        print_report(report, console=console)
        return console.export_text()

    def test_empty_classifications_shows_no_ai_message(self):
        text = self._capture(_make_report())
        assert "No AI systems detected" in text

    def test_with_classifications_does_not_crash(self):
        c = _make_classification(RiskLevel.MINIMAL)
        text = self._capture(_make_report(
            classifications=[c],
            frameworks={"sklearn": 1},
        ))
        assert "MINIMAL" in text

    def test_unacceptable_risk_shows_action_tree(self):
        c = _make_classification(
            RiskLevel.UNACCEPTABLE,
            framework="deepface",
            obligations=["MUST CEASE operations"],
            category="use-case",
        )
        text = self._capture(_make_report(
            classifications=[c],
            frameworks={"deepface": 1},
        ))
        assert "REQUIRED ACTIONS" in text
        assert "UNACCEPTABLE" in text
        assert "MUST CEASE" in text

    def test_high_risk_shows_action_tree(self):
        c = _make_classification(
            RiskLevel.HIGH,
            framework="openai",
            obligations=["Conduct conformity assessment"],
        )
        text = self._capture(_make_report(
            classifications=[c],
            frameworks={"openai": 1},
        ))
        assert "REQUIRED ACTIONS" in text
        assert "HIGH RISK" in text

    def test_limited_risk_no_action_tree(self):
        c = _make_classification(RiskLevel.LIMITED, framework="langchain")
        text = self._capture(_make_report(
            classifications=[c],
            frameworks={"langchain": 1},
        ))
        assert "REQUIRED ACTIONS" not in text

    def test_errors_displayed(self):
        text = self._capture(_make_report(errors=["something went wrong"]))
        assert "something went wrong" in text

    def test_use_cases_table_shown(self):
        c = _make_classification(
            RiskLevel.HIGH,
            framework="biometric",
            category="use-case",
        )
        report = _make_report(
            classifications=[c],
            frameworks={},
            use_cases={"biometric": 2},
        )
        # Need at least one framework for the frameworks table
        report.scan_result.frameworks = {"deepface": 1}
        text = self._capture(report)
        assert "biometric" in text

    def test_footer_shows_totals(self):
        classifications = [
            _make_classification(RiskLevel.HIGH, file="a.py"),
            _make_classification(RiskLevel.MINIMAL, file="b.py"),
        ]
        text = self._capture(_make_report(
            classifications=classifications,
            frameworks={"openai": 1, "sklearn": 1},
        ))
        assert "Total AI systems classified: 2" in text

    def test_multiple_unacceptable_listed(self):
        classifications = [
            _make_classification(
                RiskLevel.UNACCEPTABLE, framework="biometric",
                file="a.py", obligations=["Stop biometric"],
            ),
            _make_classification(
                RiskLevel.UNACCEPTABLE, framework="emotion",
                file="b.py", obligations=["Stop emotion"],
            ),
        ]
        text = self._capture(_make_report(
            classifications=classifications,
            frameworks={"biometric": 1, "emotion": 1},
        ))
        assert "Stop biometric" in text
        assert "Stop emotion" in text

    def test_print_report_with_all_risk_levels(self):
        """Ensure every risk level renders without error."""
        classifications = [
            _make_classification(level, file=f"{level.value}.py", framework=f"fw-{level.value}")
            for level in RiskLevel
        ]
        # Must have frameworks for the table
        frameworks = {f"fw-{level.value}": 1 for level in RiskLevel}
        text = self._capture(_make_report(
            classifications=classifications,
            frameworks=frameworks,
        ))
        for level in RiskLevel:
            assert level.value.upper() in text

    def test_compliance_score_shown_in_terminal(self):
        """Compliance score appears in terminal output."""
        c = _make_classification(RiskLevel.HIGH, framework="openai")
        text = self._capture(_make_report(
            classifications=[c],
            frameworks={"openai": 1},
        ))
        assert "Compliance Score:" in text
        assert "/100" in text

    def test_deadline_countdown_shown_in_terminal(self):
        """Deadline countdown appears in terminal output."""
        c = _make_classification(RiskLevel.MINIMAL)
        text = self._capture(_make_report(
            classifications=[c],
            frameworks={"sklearn": 1},
        ))
        assert "Aug 2, 2026" in text
