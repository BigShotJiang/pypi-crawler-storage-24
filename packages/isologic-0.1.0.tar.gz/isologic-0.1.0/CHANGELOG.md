# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2026-03-12

### Added
- Initial release of isologic
- EU AI Act compliance scanner for Python and JavaScript/TypeScript codebases
- 30+ AI framework detection patterns (OpenAI, Anthropic, HuggingFace, LangChain, PyTorch, TensorFlow, Ollama, and more)
- 15+ high-risk use-case patterns (recruitment, credit scoring, biometric identification, emotion recognition, medical diagnosis)
- Six-level risk classification (Unacceptable, High, Limited, GPAI, Minimal, Unknown)
- Rich terminal output with colored tables and action items
- JSON report export for CI/CD integration
- Markdown report export for compliance teams
- Exit codes for CI/CD gating (0 = compliant, 1 = high-risk, 2 = prohibited)
- EU AI Act deadline and penalty reference via `isologic info`
- Support for Python 3.10, 3.11, 3.12, 3.13
- GitHub Actions CI workflow

### Known Limitations
- Pattern-based detection (regex) — false positives possible
- Cannot determine deployment context from code alone
- Use-case detection relies on naming conventions

[0.1.0]: https://github.com/masterkenai121/isologic/releases/tag/v0.1.0
