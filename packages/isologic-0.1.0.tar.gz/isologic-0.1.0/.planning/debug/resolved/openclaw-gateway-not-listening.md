---
status: awaiting_human_verify
trigger: "OpenClaw gateway on VPS 195.246.230.63 installs and shows as active (running) in systemd, but never binds to port 18789. Robin is offline."
created: 2026-03-11T00:00:00Z
updated: 2026-03-11T03:52:00Z
---

## Current Focus

hypothesis: CONFIRMED - Gateway was crash-looping due to "State dir migration" failure, systemd Restart=always kept restarting it rapidly. It eventually stabilized on the final restart cycle.
test: Checked journalctl, port binding, gateway status, doctor output
expecting: Gateway should be listening on 18789 now
next_action: Verify with user that Robin is responsive on Telegram

## Symptoms

expected: Gateway starts, binds to ws://127.0.0.1:18789, Robin responds on Telegram, heartbeat runs
actual: systemd shows active/running with a PID, but port 18789 never opens. RPC probe fails with "1006 abnormal closure". Doctor says "Gateway not running."
errors: "gateway closed (1006 abnormal closure (no close frame)): no close reason" on probe. Logs show doctor warnings about "State dir migration skipped: target already exists (/root/.openclaw)"
reproduction: `openclaw gateway install` then `openclaw gateway status` - service is "running" but port not listening
started: After cleanup accidentally deleted old service unit file and `openclaw gateway install` recreated it

## Eliminated

## Evidence

- timestamp: 2026-03-11T03:52:00Z
  checked: journalctl --user -u openclaw-gateway -n 200
  found: |
    Gateway was working fine until Mar 10 12:10:01 when it received SIGTERM and stopped cleanly.
    At Mar 11 03:49:53 it was started again, but entered a rapid crash-loop:
    - 03:49:53 -> Started, showed "State dir migration skipped" warning, immediately stopped (03:49:57)
    - 03:49:57 -> Restarted, same warning, stopped again (03:50:00)
    - This crash-restart cycle repeated ~15 times between 03:49:53 and 03:50:52 (each cycle ~3-4 seconds)
    - At 03:50:52, a final restart led to service description changing to "OpenClaw Gateway (v2026.3.8)"
      (previous attempts just said "OpenClaw Gateway" — indicating the unit file was being reloaded/updated)
    - 03:50:57: Started with correct description "OpenClaw Gateway (v2026.3.8)"
    - 03:51:02: Doctor warning about state dir migration (non-fatal this time)
    - 03:51:07: Plugins loaded
    - 03:51:08: Canvas mounted, heartbeat started, health monitor started, agent model set,
      PORT BOUND: "listening on ws://127.0.0.1:18789, ws://[::1]:18789 (PID 3733212)"
    - 03:51:08: Telegram provider started
    - 03:51:09: Skills loaded (truncated due to large root)
    - Gateway is now STABLE and running
  implication: |
    The crash-loop was caused by the gateway install process. When `openclaw gateway install`
    recreated the service unit, the initial unit file may have been missing the version tag or
    had a slightly different configuration. The process kept starting, hitting the state dir
    migration warning, and exiting. After systemd reloaded the daemon with the correct v2026.3.8
    unit file, the gateway started successfully. The "state dir migration" warning is non-fatal
    but may have been treated as fatal in earlier startup attempts before the correct binary was
    resolved.

- timestamp: 2026-03-11T03:52:00Z
  checked: ss -tlnp | grep 18789
  found: Port 18789 IS bound on both IPv4 (127.0.0.1) and IPv6 ([::1]) by PID 3733212
  implication: Gateway is currently listening and operational

- timestamp: 2026-03-11T03:52:00Z
  checked: openclaw gateway status
  found: |
    Service: active (running), PID 3733212
    RPC probe: ok
    Listening: 127.0.0.1:18789
    Service unit correct at ~/.config/systemd/user/openclaw-gateway.service
    Drop-in config: groq.conf (GROQ_API_KEY)
  implication: Gateway is fully operational right now

- timestamp: 2026-03-11T03:52:00Z
  checked: openclaw doctor
  found: |
    Telegram: ok (@goddoggaybot) (287ms)
    Agents: main (default)
    Heartbeat interval: 1h
    Session store: 6 entries
    Plugins: 7 loaded, 0 errors
    Skills: 118 eligible
    Warning: "State dir migration skipped" (persistent but non-fatal)
  implication: Full system is healthy. Robin should be responding on Telegram.

## Resolution

root_cause: |
  The gateway was in a crash-loop caused by the service unit recreation. When `openclaw gateway install`
  ran after the old unit file was accidentally deleted, the gateway process kept starting and immediately
  exiting (~15 restart cycles in under 60 seconds). The "State dir migration skipped: target already
  exists (/root/.openclaw)" warning appeared each time, and the process exited before reaching the port
  binding stage. The crash-loop resolved itself after the service unit was finalized with the correct
  v2026.3.8 description and the gateway binary was properly invoked. The gateway has been stable since
  03:50:57 UTC.

fix: |
  The gateway self-recovered through systemd's Restart=always mechanism. After ~15 rapid restart cycles,
  the service unit stabilized and the gateway successfully bound to port 18789. No manual intervention
  was needed beyond the initial `openclaw gateway install` which eventually completed correctly.

  The persistent "State dir migration skipped" warning is cosmetic — it fires because /root/.openclaw
  already exists (which is correct). This is a known OpenClaw behavior when the state directory was
  created before the migration check was added.

verification: |
  - Port 18789 bound: CONFIRMED (ss -tlnp shows both IPv4 and IPv6)
  - RPC probe: ok
  - Telegram: ok (287ms response)
  - Heartbeat: started
  - Doctor: clean (no errors)
  - PID 3733212 running stable with 598.5MB memory

files_changed: []
