"""Simple chatbot using OpenAI."""
from openai import OpenAI

client = OpenAI()

def get_response(prompt: str) -> str:
    response = client.chat.completions.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}],
    )
    return response.choices[0].message.content
