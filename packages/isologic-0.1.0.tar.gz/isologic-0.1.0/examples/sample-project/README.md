# Sample Project

A demo project with mixed AI risk levels for testing isologic.

Run: `isologic audit .` from this directory.
