"""Content analysis with emotion detection."""
from transformers import pipeline

def analyze_sentiment(text: str):
    emotion_detector = pipeline("sentiment-analysis")
    return emotion_detector(text)
