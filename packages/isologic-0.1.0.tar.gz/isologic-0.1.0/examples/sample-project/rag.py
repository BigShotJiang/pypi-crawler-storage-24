"""RAG pipeline with vector search."""
from langchain import LLMChain
from langchain.vectorstores import Chroma

def search_and_respond(query: str):
    # Retrieval-augmented generation pipeline
    vector_store = Chroma(collection_name="docs")
    results = vector_store.similarity_search(query)
    return results
