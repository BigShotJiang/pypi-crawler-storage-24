from __future__ import annotations

import json
from pathlib import Path

from one_run.manifest import load_manifest
from one_run.payloads import validate_result_payload
from one_run.templating import validate_placeholders


def validate_manifest(config_path: str, *, json_output: bool = False) -> int:
    manifest_path = Path(config_path).resolve()
    manifest = load_manifest(manifest_path)
    validate_placeholders(manifest.entrypoint.command)

    if json_output:
        print(json.dumps(validate_result_payload(
            manifest=str(manifest_path),
            valid=True,
            backend=manifest.backend.kind,
            environment=manifest.environment.kind,
        )))
        return 0

    print(f"manifest={manifest_path}")
    print("valid=true")
    print(f"backend={manifest.backend.kind}")
    print(f"environment={manifest.environment.kind}")
    return 0
