from __future__ import annotations

import argparse
import os

from one_run import __version__
from one_run.constants import AUTOMATION_ENV_VAR
from one_run.commands.ls_cmd import list_runs
from one_run.commands.ps_cmd import list_processes
from one_run.commands.cancel_cmd import cancel_run
from one_run.commands.gc_cmd import gc_runs
from one_run.commands.run_cmd import run_local
from one_run.commands.status_cmd import show_status
from one_run.commands.submit_cmd import submit_slurm
from one_run.commands.tail_cmd import tail_run_log
from one_run.commands.validate_cmd import validate_manifest
from one_run.errors import OneRunError


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="one-run", description="ml run wrapper for reprodusible experiments and documentation")
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    parser.add_argument(
        "--automation",
        action="store_true",
        help=f"prefer machine-readable output defaults (also enabled by {AUTOMATION_ENV_VAR}=1)",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    run_p = sub.add_parser("run", help="execute a local run")
    run_p.add_argument("config", help="path to manifest yaml")
    run_p.add_argument("-w", "--watch", action="store_true", help="run in background and return immediately")
    run_p.add_argument("--json", action="store_true", help="print machine-readable result json")

    submit_p = sub.add_parser("submit", help="submit a slurm run")
    submit_p.add_argument("config", help="path to manifest yaml")
    submit_p.add_argument("--json", action="store_true", help="print machine-readable result json")

    status_p = sub.add_parser("status", help="show run status")
    status_p.add_argument("run_id", help="run identifier")
    status_p.add_argument("--json", action="store_true", help="print status payload as json")
    status_p.add_argument("-l", "--long", action="store_true", help="print extended status fields")
    status_p.add_argument("--wait", action="store_true", help="wait until run reaches terminal state")
    status_p.add_argument("--timeout", help="max wait duration, e.g. 30m")
    status_p.add_argument("--interval", type=float, default=2.0, help="poll interval in seconds (default: 2)")

    cancel_p = sub.add_parser("cancel", help="cancel a running run")
    cancel_p.add_argument("run_id", help="run identifier")
    cancel_p.add_argument("--force", action="store_true", help="force kill local run / kill signal for slurm")
    cancel_p.add_argument("--json", action="store_true", help="print machine-readable result json")

    validate_p = sub.add_parser("validate", help="validate manifest only")
    validate_p.add_argument("config", help="path to manifest yaml")
    validate_p.add_argument("--json", action="store_true", help="print machine-readable result json")

    tail_p = sub.add_parser("tail", help="show run logs")
    tail_p.add_argument("run_id", help="run identifier")
    tail_p.add_argument("-n", "--lines", type=int, default=30, help="number of lines from the end")
    tail_p.add_argument("-f", "--follow", action="store_true", help="follow log output")
    tail_p.add_argument("--stderr", action="store_true", help="tail stderr instead of stdout")
    tail_p.add_argument("--since", help="show logs only for runs updated within duration (e.g. 10m, 2h)")

    ls_p = sub.add_parser("ls", help="list runs")
    ls_p.add_argument("--long", "-l", action="store_true", help="show detailed columns")
    ls_p.add_argument(
        "--state",
        choices=["pending", "running", "success", "failed"],
        help="filter by run state",
    )
    ls_p.add_argument("--tag", action="append", help="filter by tag (can be used multiple times)")
    ls_p.add_argument("--group-by-tag", action="store_true", help="group output by tag")
    ls_p.add_argument("--json", action="store_true", help="print machine-readable json")

    ps_p = sub.add_parser("ps", help="list active runs")
    ps_p.add_argument(
        "--state",
        choices=["pending", "running"],
        help="filter by active state",
    )
    ps_p.add_argument("--tag", action="append", help="filter by tag (can be used multiple times)")
    ps_p.add_argument("--json", action="store_true", help="print machine-readable json")
    ps_p.add_argument("-w", "--watch", action="store_true", help="refresh process table continuously")
    ps_p.add_argument("--interval", type=float, default=2.0, help="watch refresh interval in seconds (default: 2)")

    gc_p = sub.add_parser("gc", help="cleanup run directories")
    gc_p.add_argument("--state", choices=["pending", "running", "success", "failed"], help="filter by run state")
    gc_p.add_argument("--older-than", help="delete runs older than duration, e.g. 7d")
    gc_p.add_argument("--dry-run", action="store_true", help="show what would be deleted")
    gc_p.add_argument("--json", action="store_true", help="print machine-readable result json")
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    automation_mode = args.automation or os.getenv(AUTOMATION_ENV_VAR) == "1"

    try:
        if args.command == "run":
            return run_local(args.config, watch=args.watch, json_output=(args.json or automation_mode))
        if args.command == "submit":
            return submit_slurm(args.config, json_output=(args.json or automation_mode))
        if args.command == "status":
            return show_status(
                args.run_id,
                json_output=(args.json or automation_mode),
                long=args.long,
                wait=args.wait,
                timeout=args.timeout,
                interval_sec=args.interval,
            )
        if args.command == "cancel":
            return cancel_run(args.run_id, force=args.force, json_output=(args.json or automation_mode))
        if args.command == "validate":
            return validate_manifest(args.config, json_output=(args.json or automation_mode))
        if args.command == "tail":
            return tail_run_log(args.run_id, stderr=args.stderr, follow=args.follow, lines=args.lines, since=args.since)
        if args.command == "ls":
            return list_runs(
                state_filter=args.state,
                long=args.long,
                tags=args.tag,
                group_by_tag=args.group_by_tag,
                json_output=(args.json or automation_mode),
            )
        if args.command == "ps":
            return list_processes(
                state_filter=args.state,
                tags=args.tag,
                json_output=(args.json or automation_mode),
                watch=args.watch,
                interval_sec=args.interval,
            )
        if args.command == "gc":
            return gc_runs(
                state=args.state,
                older_than=args.older_than,
                dry_run=args.dry_run,
                json_output=(args.json or automation_mode),
            )
    except OneRunError as exc:
        parser.exit(status=1, message=f"error: {exc}\n")

    parser.exit(status=2, message="unknown command\n")
    return 2
