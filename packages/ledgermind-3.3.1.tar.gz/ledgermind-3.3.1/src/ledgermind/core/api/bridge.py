import os
import re
import logging
import json
import time
from typing import List, Optional, Dict, Any, TYPE_CHECKING
from ledgermind.core.core.schemas import MemoryDecision
from ledgermind.core.stores.semantic_store.loader import MemoryLoader

if TYPE_CHECKING:
    from ledgermind.core.api.memory import Memory

logger = logging.getLogger(__name__)

class Bridge:
    """
    High-level bridge for integrating LedgerMind into CLI tools.
    """
    
    def __init__(self, memory_path: str = "../.ledgermind", relevance_threshold: float = 0.85, retention_turns: int = 10, vector_model: Optional[str] = None, default_cli: Optional[List[str]] = None, memory_instance: Optional['Memory'] = None):
        self.memory_path = os.path.abspath(memory_path)
        if memory_instance:
            self._memory = memory_instance
        else:
            # Lazy import to break circular dependency
            from ledgermind.core.api.memory import Memory
            try:
                self._memory = Memory(storage_path=self.memory_path, vector_model=vector_model)
            except Exception as e:
                logger.critical(f"Failed to initialize LedgerMind Core: {e}")
                raise RuntimeError(f"Memory initialization failed. Check permissions for {memory_path}")
            
        self.relevance_threshold = relevance_threshold
        self.retention_turns = retention_turns
        self.default_cli = default_cli or ["gemini"]
        self._active_context_ids: Dict[str, int] = {}
        self._turn_counter = 0

    def reset_session(self):
        self._active_context_ids.clear()
        self._turn_counter = 0

    def emit(self, event_name: str, data: Any):
        """Simple event logging for now."""
        logger.debug(f"Bridge Event: {event_name} -> {data}")

    def _find_relevant_memories(self, prompt: str, limit: int = 3, exclude_ids: Optional[set[str]] = None) -> List[Dict[str, Any]]:
        try:
            results = self._memory.search_decisions(prompt, limit=limit, mode="balanced")
            memories = []
            exclude = exclude_ids or set()
            
            for item in results:
                fid = item.get('id')
                if fid in exclude: continue
                    
                score = item.get('score', 0)
                if score >= self.relevance_threshold:
                    path = os.path.join(self.memory_path, "semantic", fid)
                    
                    # Core fields we want to return
                    # We only return: target, title, compressive_rationale, strengths, objections, consequences
                    memory_item = {
                        "id": fid,
                        "target": item.get('target'),
                        "title": item.get('title'),
                        "compressive_rationale": item.get('compressive_rationale'),
                        "strengths": item.get('strengths', []),
                        "objections": item.get('objections', []),
                        "consequences": item.get('consequences', [])
                    }
                    
                    # Check for "..." placeholders and load from file if found
                    placeholders = ["...", "…"]
                    needs_load = any(
                        (isinstance(v, str) and v in placeholders) or 
                        (isinstance(v, list) and any(x in placeholders for x in v))
                        for v in memory_item.values()
                    )
                    
                    if needs_load and os.path.exists(path):
                        try:
                            with open(path, 'r', encoding='utf-8') as f:
                                raw_content = f.read()
                            data, body = MemoryLoader.parse(raw_content)
                            if data:
                                ctx = data.get("context", {})
                                if memory_item["target"] in placeholders:
                                    memory_item["target"] = ctx.get("target") or data.get("target")
                                if memory_item["title"] in placeholders:
                                    memory_item["title"] = data.get("title")
                                if memory_item["compressive_rationale"] in placeholders:
                                    memory_item["compressive_rationale"] = ctx.get("compressive_rationale")
                                if not memory_item["strengths"] or memory_item["strengths"] == placeholders:
                                    memory_item["strengths"] = ctx.get("strengths") or []
                                if not memory_item["objections"] or memory_item["objections"] == placeholders:
                                    memory_item["objections"] = ctx.get("objections") or []
                                if not memory_item["consequences"] or memory_item["consequences"] == placeholders:
                                    memory_item["consequences"] = ctx.get("consequences") or []
                        except Exception as e:
                            logger.error(f"Failed to load full memory from {path}: {e}")

                    # One final sweep to ensure no remaining placeholders in the returned dict
                    for k, v in memory_item.items():
                        if isinstance(v, str) and v in placeholders:
                            memory_item[k] = ""
                        elif isinstance(v, list):
                            memory_item[k] = [x for x in v if x not in placeholders]

                    memories.append(memory_item)
            return memories
        except Exception as e:
            logger.error(f"Error searching memories: {e}")
            return []

    def get_context_for_prompt(self, prompt: str, limit: int = 3) -> str:
        memories = self._find_relevant_memories(prompt, limit=limit)
        if not memories: return ""
        json_data = json.dumps({"source": "ledgermind", "memories": memories}, indent=2, ensure_ascii=False)
        return f"[LEDGERMIND KNOWLEDGE BASE ACTIVE]\n{json_data}"

    def execute_with_memory(self, command_args: List[str], user_prompt: str, stream: bool = True) -> str:
        """
        High-level orchestration with SLIDING WINDOW CONTEXT DEDUPLICATION:
        1. Manages turn counter and prunes old context from cache.
        2. Injects NEW context (excluding recently injected ones).
        3. Executes external command.
        4. Records interaction.
        """
        import subprocess
        import sys

        self._turn_counter += 1

        # Prune old memories from cache based on retention_turns
        cutoff = self._turn_counter - self.retention_turns
        # Keep only memories injected within the retention window
        active_ids = {k for k, v in self._active_context_ids.items() if v > cutoff}
        self._active_context_ids = {k: v for k, v in self._active_context_ids.items() if k in active_ids}

        # 1. Get Context (Only NEW memories not in active_ids)
        memories = self._find_relevant_memories(user_prompt, exclude_ids=active_ids)

        context_str = ""
        if memories:
            # Add to active cache with current turn number
            for m in memories:
                self._active_context_ids[m['id']] = self._turn_counter

            json_data = json.dumps({
                "source": "ledgermind",
                "memories": memories
            }, indent=2, ensure_ascii=False)
            context_str = f"[LEDGERMIND KNOWLEDGE BASE ACTIVE]\n{json_data}"

        # 2. Prepare Augmented Prompt
        augmented_prompt = f"{context_str}\n\n{user_prompt}" if context_str else user_prompt

        # 3. Execute CLI with Streaming
        cmd = command_args + [augmented_prompt]
        if stream:
            proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            output = []
            try:
                for line in proc.stdout:
                    sys.stdout.write(line)
                    sys.stdout.flush()
                    output.append(line)
                proc.wait()
                result = ''.join(output)
                # 4. Record interaction
                self.record_interaction(user_prompt, result, success=(proc.returncode == 0))
                return result
            except KeyboardInterrupt:
                proc.terminate()
                raise
            finally:
                if proc.returncode is None:
                    proc.terminate()
        else:
            result = subprocess.run(cmd, capture_output=True, text=True).stdout
            self.record_interaction(user_prompt, result, success=True)
            return result

    def record_decision(self, title: str, target: str, rationale: str, consequences: Optional[List[str]] = None) -> MemoryDecision:
        return self._memory.record_decision(title, target, rationale, consequences)

    def supersede_decision(self, title: str, target: str, rationale: str, old_decision_ids: List[str], enrichment_status: str = "pending") -> MemoryDecision:
        return self._memory.supersede_decision(title, target, rationale, old_decision_ids, enrichment_status=enrichment_status)

    def accept_proposal(self, proposal_id: str) -> MemoryDecision:
        return self._memory.accept_proposal(proposal_id)

    def search_decisions(self, query: str, limit: int = 5, mode: str = "balanced") -> List[Dict[str, Any]]:
        return self._memory.search_decisions(query, limit=limit, mode=mode)

    def get_decisions(self) -> List[str]:
        return self._memory.get_decisions()

    def forget(self, decision_id: str):
        self._memory.forget(decision_id)

    def get_decision_history(self, decision_id: str) -> List[Dict[str, Any]]:
        return self._memory.get_decision_history(decision_id)

    def generate_knowledge_graph(self, target: Optional[str] = None) -> str:
        return self._memory.generate_knowledge_graph(target)

    def update_decision(self, decision_id: str, updates: Dict[str, Any], commit_msg: str) -> bool:
        return self._memory.update_decision(decision_id, updates, commit_msg)

    def record_interaction(self, prompt: str, response: str, success: bool = True, metadata: Optional[Dict[str, Any]] = None):
        try:
            ctx = {"layer": "cli_integration", "success": success}
            if metadata: ctx.update(metadata)
            # Record prompt first
            self._memory.process_event(source="agent", kind="prompt", content=prompt or "[NO PROMPT]")
            # Then record result
            self._memory.process_event(source="agent", kind="result", content=response or "[NO RESPONSE]", context=ctx)
        except Exception as e:
            logger.error(f"Error recording interaction: {e}")

    def run_maintenance(self) -> Dict[str, Any]:
        try:
            report = self._memory.run_decay()
            return {"status": "success", "forgotten": report.semantic_forgotten}
        except Exception as e:
            logger.error(f"Maintenance error: {e}")
            return {"status": "error", "message": str(e)}

    def check_health(self) -> Dict[str, Any]:
        """Health check for the memory system."""
        return self._memory.check_environment()

    def get_stats(self) -> Dict[str, Any]:
        """Returns statistics about the memory system."""
        try:
            mem_stats = self._memory.get_stats()
            return {
                "health": self.check_health(),
                "semantic_count": mem_stats.get("semantic_total", 0),
                "episodic_count": self._memory.episodic.count_events() if hasattr(self._memory.episodic, 'count_events') else "unknown",
            }
        except Exception as e:
            logger.error(f"Error getting stats: {e}")
            return {
                "health": {},
                "semantic_count": 0,
                "episodic_count": "unknown"
            }

    @property
    def memory(self) -> 'Memory':
        return self._memory

# Alias for backward compatibility
IntegrationBridge = Bridge
