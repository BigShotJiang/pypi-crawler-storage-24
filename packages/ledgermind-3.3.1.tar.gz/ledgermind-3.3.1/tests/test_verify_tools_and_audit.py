
import os
import shutil
import unittest
import unittest.mock
import json
import time
import logging
from ledgermind.core.api.memory import Memory
from ledgermind.server.server import MCPServer
from ledgermind.server.background import BackgroundWorker

class TestTools(unittest.TestCase):
    def setUp(self):
        self.test_dir = "./temp_test_tools"
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir)
        os.makedirs(self.test_dir)
        
        # Clean up any stale worker.pid from previous runs
        worker_pid_file = os.path.join(self.test_dir, "worker.pid")
        if os.path.exists(worker_pid_file):
            os.remove(worker_pid_file)
        
        self.memory = Memory(storage_path=self.test_dir)

        # Patch BackgroundWorker to avoid SQLite concurrency issues in unit tests
        self.patcher = unittest.mock.patch.object(BackgroundWorker, "start")
        self.patcher.start()

        self.server = MCPServer(self.memory, storage_path=self.test_dir, start_worker=False)

    def tearDown(self):
        self.patcher.stop()
        
        # Release objects to unlock SQLite databases
        self.server = None
        self.memory = None
        
        # Shutdown any logging handlers to free files
        for logger_name in ["agent_memory_audit", "ledgermind.server.audit"]:
            l = logging.getLogger(logger_name)
            for handler in l.handlers[:]:
                handler.close()
                l.removeHandler(handler)
        
        import gc
        gc.collect() # Force garbage collection
            
        if os.path.exists(self.test_dir):
            import time
            # Retry loop for robust directory removal on Windows/Busy CI
            for _ in range(5):
                try:
                    shutil.rmtree(self.test_dir)
                    break
                except OSError:
                    time.sleep(0.5)

    def test_audit_logs_tool(self):
        print("Testing Audit Logs Tool...")
        # 1. Trigger some activity
        class MockRequest:
            def __init__(self, query, limit, mode, offset=0):
                self.query = query
                self.limit = limit
                self.mode = mode
                self.offset = offset
                self.namespace = "default"
            def model_dump(self):
                return {"query": self.query, "limit": self.limit, "mode": self.mode}

        self.server.handle_search(MockRequest('test search query long enough', 1, 'balanced'))
        time.sleep(1)
        
        # 2. Get logs via tool logic
        logs = self.server.audit_logger.get_logs(limit=5)
        self.assertGreater(len(logs), 0, "Audit logs should contain records")
        logs_str = "".join(logs)
        self.assertIn("search_decisions", logs_str)
        print("✓ Audit Logs OK.")

    def test_decision_history(self):
        print("Testing Decision History (Git integration)...")
        dec = self.memory.record_decision("Evolution Decision Title", "evolution", "Initial version rationale long enough")
        fid = dec.metadata['file_id']
        
        # 2. Update it
        self.memory.supersede_decision("Evolution v2 Title", "evolution", "Updated version rationale long enough", [fid])
        
        # 3. Check history
        history = self.memory.get_decision_history(fid)
        self.assertGreaterEqual(len(history), 1, "Should show git history for the file")
        print(f"History entries: {len(history)}")
        print("✓ Decision History OK.")

    def test_api_specification(self):
        print("Testing API Specification Tool...")
        from ledgermind.server.specification import MCPApiSpecification
        from ledgermind.server.contracts import MCP_API_VERSION
        spec = MCPApiSpecification.generate_full_spec()
        self.assertEqual(spec['mcp_api_version'], MCP_API_VERSION)
        self.assertIn("record_decision", spec['tools'])
        print("✓ API Specification OK.")

if __name__ == "__main__":
    unittest.main()
