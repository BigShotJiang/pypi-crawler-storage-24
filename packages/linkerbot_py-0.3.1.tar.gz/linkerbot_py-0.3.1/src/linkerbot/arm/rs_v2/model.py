from pydantic import BaseModel


class RsV2Error(BaseModel): ...
