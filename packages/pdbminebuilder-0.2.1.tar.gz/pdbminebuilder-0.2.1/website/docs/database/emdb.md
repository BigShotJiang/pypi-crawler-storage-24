---
sidebar_position: 8
---

# emdb Schema

- **Primary Key**: `emdb_id`
- **Tables**: 79

## brief_summary

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| docid | bigint |  |
| deposition_date | date |  |
| header_release_date | date |  |
| map_release_date | date |  |
| modification_date | date |  |
| update_date | timestamp without time zone |  |
| content | jsonb |  |
| keywords | text[] |  |

## audit_conform

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| dict_location | text | A file name or uniform resource locator (URL) for the dictionary to which the current data block conforms. |
| dict_name | text | The string identifying the highest-level dictionary defining data names used in this file. |
| dict_version | text | The version number of the dictionary to which the current data block conforms. |

## chem_comp

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| formula | text | The formula for the chemical component. Formulae are written according to the following rules: (1) Only recognized element symbols may be used. (2) Each element symbol is followed by a 'count' number. A count of '1' may be omitted. (3) A space or parenthesis must separate each cluster of (element symbol + count), but in general parentheses are not used. (4) The order of elements depends on whether carbon is present or not. If carbon is present, the order should be: C, then H, then the other elements in alphabetical order of their symbol. If carbon is not present, the elements are listed purely in alphabetic order of their symbol. This is the 'Hill' system used by Chemical Abstracts. |
| formula_weight | double precision | Formula mass in daltons of the chemical component. |
| id | text | The value of _chem_comp.id must uniquely identify each item in the CHEM_COMP list. For protein polymer entities, this is the three-letter code for the amino acid. For nucleic acid polymer entities, this is the one-letter code for the base. |
| mon_nstd_flag | text | 'yes' indicates that this is a 'standard' monomer, 'no' indicates that it is 'nonstandard'. Nonstandard monomers should be described in more detail using the _chem_comp.mon_nstd_parent, _chem_comp.mon_nstd_class and _chem_comp.mon_nstd_details data items. |
| name | text | The full name of the component. |
| type | text | For standard polymer components, the type of the monomer. Note that monomers that will form polymers are of three types: linking monomers, monomers with some type of N-terminal (or 5') cap and monomers with some type of C-terminal (or 3') cap. |
| pdbx_synonyms | text | Synonym list for the component. |

## citation

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| country | text | The country/region of publication; relevant for books and book chapters. |
| id | text | The value of _citation.id must uniquely identify a record in the CITATION list. The _citation.id 'primary' should be used to indicate the citation that the author(s) consider to be the most pertinent to the contents of the data block. Note that this item need not be a number; it can be any unique identifier. |
| journal_abbrev | text | Abbreviated name of the cited journal as given in the Chemical Abstracts Service Source Index. |
| journal_id_ASTM | text | The American Society for Testing and Materials (ASTM) code assigned to the journal cited (also referred to as the CODEN designator of the Chemical Abstracts Service); relevant for journal articles. |
| journal_id_CSD | text | The Cambridge Structural Database (CSD) code assigned to the journal cited; relevant for journal articles. This is also the system used at the Protein Data Bank (PDB). |
| journal_id_ISSN | text | The International Standard Serial Number (ISSN) code assigned to the journal cited; relevant for journal articles. |
| journal_volume | text | Volume number of the journal cited; relevant for journal articles. |
| page_first | text | The first page of the citation; relevant for journal articles, books and book chapters. |
| page_last | text | The last page of the citation; relevant for journal articles, books and book chapters. |
| title | text | The title of the citation; relevant for journal articles, books and book chapters. |
| year | integer | The year of the citation; relevant for journal articles, books and book chapters. |
| database_id_CSD | text | Identifier ('refcode') of the database record in the Cambridge Structural Database that contains details of the cited structure. |
| pdbx_database_id_DOI | text | Document Object Identifier used by doi.org to uniquely specify bibliographic entry. |
| pdbx_database_id_PubMed | integer | Ascession number used by PubMed to categorize a specific bibliographic entry. |
| unpublished_flag | text | Flag to indicate that this citation will not be published. |

## citation_author

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| citation_id | text | This data item is a pointer to _citation.id in the CITATION category. |
| name | text | Name of an author of the citation; relevant for journal articles, books and book chapters. The family name(s), followed by a comma and including any dynastic components, precedes the first name(s) or initial(s). |
| ordinal | integer | This data item defines the order of the author's name in the list of authors of a citation. |
| identifier_ORCID | text | The Open Researcher and Contributor ID (ORCID). |

## database_2

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| database_id | text | An abbreviation that identifies the database. |
| database_code | text | The code assigned by the database identified in _database_2.database_id. |
| pdbx_database_accession | text | Extended accession code issued for for _database_2.database_code assigned by the database identified in _database_2.database_id. |
| pdbx_DOI | text | Document Object Identifier (DOI) for this entry registered with http://crossref.org. |

## em_2d_crystal_entity

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| angle_gamma | double precision | Unit-cell angle gamma in degrees. |
| c_sampling_length | double precision | Length used to sample the reciprocal lattice lines in the c-direction. |
| image_processing_id | text | pointer to _em_image_processing.id in the EM_IMAGE_PROCESSING category. |
| id | text | PRIMARY KEY |
| entity_assembly_id | text | Corresponding key in _em_entity_assembly category. |
| length_a | double precision | Unit-cell length a in angstroms. |
| length_b | double precision | Unit-cell length b in angstroms. |
| length_c | double precision | Thickness of 2D crystal |
| space_group_name_H-M | text | There are 17 plane groups classified as oblique, rectangular, square, and hexagonal. To describe the symmetry of 2D crystals of biological molecules, plane groups are expanded to equivalent noncentrosymmetric space groups. The 2D crystal plane corresponds to the 'ab' plane of the space group. Enumerated space group descriptions include the plane group number in parentheses, the H-M plane group symbol, and the plane group class. |

## em_3d_crystal_entity

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| angle_alpha | double precision | Unit-cell angle alpha in degrees. |
| angle_beta | double precision | Unit-cell angle beta in degrees. |
| angle_gamma | double precision | Unit-cell angle gamma in degrees. |
| image_processing_id | text | pointer to _em_image_processing.id in the EM_IMAGE_PROCESSING category. |
| id | text | PRIMARY KEY |
| length_a | double precision | Unit-cell length a in angstroms. |
| length_b | double precision | Unit-cell length b in angstroms. |
| length_c | double precision | Unit-cell length c in angstroms. |
| space_group_name | text | Space group name. |
| space_group_num | integer | Space group number. |

## em_3d_fitting

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| id | text | The value of _em_3d_fitting.id must uniquely identify a fitting procedure of atomic coordinates into 3dem reconstructed map volume. |
| entry_id | text | This data item is a pointer to _entry_id in the ENTRY category. |
| method | text | The method used to fit atomic coordinates into the 3dem reconstructed map. |
| target_criteria | text | The measure used to assess quality of fit of the atomic coordinates in the 3DEM map volume. |
| details | text | Any additional details regarding fitting of atomic coordinates into the 3DEM volume, including data and considerations from other methods used in computation of the model. |
| overall_b_value | double precision | The overall B (temperature factor) value for the 3d-em volume. |
| ref_space | text | A flag to indicate whether fitting was carried out in real or reciprocal refinement space. |
| ref_protocol | text | The refinement protocol used. |

## em_3d_fitting_list

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| id | text | PRIMARY KEY |
| 3d_fitting_id | text | The value of _em_3d_fitting_list.3d_fitting_id is a pointer to _em_3d_fitting.id in the 3d_fitting category |
| pdb_entry_id | text | The PDB code for the entry used in fitting. |
| pdb_chain_id | text | The ID of the biopolymer chain used for fitting, e.g., A. Please note that only one chain can be specified per instance. If all chains of a particular structure have been used for fitting, this field can be left blank. |
| pdb_chain_residue_range | text | Residue range for the identified chain. |
| details | text | Details about the model used in fitting. |
| chain_id | text | The ID of the biopolymer chain used for fitting, e.g., A. Please note that only one chain can be specified per instance. If all chains of a particular structure have been used for fitting, this field can be left blank. |
| chain_residue_range | text | The residue ranges of the initial model used in this fitting. |
| source_name | text | This item identifies the resource of initial model used for refinement |
| type | text | This item describes the type of the initial model was generated |
| accession_code | text | This item identifies an accession code of the resource where the initial model is used |
| initial_refinement_model_id | integer | The value of _em_3d_fitting.initial_refinement_model_id itentifies the id in the _pdbx_initial_refinement_model |

## em_3d_reconstruction

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| entry_id | text | This data item is a pointer to _entry.id in the ENTRY category. |
| id | text | PRIMARY KEY |
| method | text | The algorithm method used for the 3d-reconstruction. |
| algorithm | text | The reconstruction algorithm/technique used to generate the map. |
| details | text | Any additional details used in the 3d reconstruction. |
| resolution | double precision | The final resolution (in angstroms) of the 3D reconstruction. |
| resolution_method | text | The method used to determine the final resolution of the 3d reconstruction. The Fourier Shell Correlation criterion as a measure of resolution is based on the concept of splitting the (2D) data set into two halves; averaging each and comparing them using the Fourier Ring Correlation (FRC) technique. |
| nominal_pixel_size | double precision | The nominal pixel size of the projection set of images in Angstroms. |
| actual_pixel_size | double precision | The actual pixel size of the projection set of images in Angstroms. |
| num_particles | integer | The number of 2D projections or 3D subtomograms used in the 3d reconstruction |
| num_class_averages | integer | The number of classes used in the final 3d reconstruction |
| fsc_type | text | Half-set refinement protocol (semi-independent or gold standard) |
| refinement_type | text | Indicates details on how the half-map used for resolution determination (usually by FSC) have been generated. |
| image_processing_id | text | Foreign key to the EM_IMAGE_PROCESSING category |
| symmetry_type | text | The type of symmetry applied to the reconstruction |

## em_admin

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| current_status | text | This data item indicates the current status of the EMDB entry. |
| deposition_date | date | date of the entry deposition |
| deposition_site | text | entry deposition site |
| details | text | EMDB administration details |
| entry_id | text | This data item is a pointer to _entry.id. |
| last_update | date | date of last update to the file |
| map_release_date | date | date of map release for this entry |
| header_release_date | date | date of header information release for this entry |
| title | text | Title for the EMDB entry. |
| process_site | text | The site where the file was deposited. |
| composite_map | text | Indicates whether the authors have declared that this is a composite map deposition |

## em_author_list

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| author | text | Author of the EMDB entry in PDB format: Taylor, T.J. |
| identifier_ORCID | text | The Open Researcher and Contributor ID (ORCID). |
| ordinal | integer | ID 1 corresponds to the main author of the entry |

## em_buffer

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| id | text | PRIMARY KEY |
| specimen_id | text | pointer to _em_specimen.id |
| name | text | The name of the buffer. |
| details | text | Additional details about the buffer. |
| pH | double precision | The pH of the sample buffer. |

## em_buffer_component

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| buffer_id | text | Foreign key to the entry category. |
| concentration | double precision | The concentration of the sample (arbitrary units). |
| concentration_units | text | Units for the sample concentration value. |
| formula | text | formula for buffer component |
| id | text | PRIMARY KEY |
| name | text | name of the buffer component |

## em_crystal_formation

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| atmosphere | text | The type of atmosphere in which crystals were grown |
| details | text | Description of growth of a 2D, 3D, or helical crystal array. |
| id | text | PRIMARY KEY |
| instrument | text | Instrument used to prepare the crystalline array |
| lipid_mixture | text | Description of the lipid mixture used for crystallization |
| lipid_protein_ratio | double precision | The molar ratio of lipid to protein in the crystallized sample |
| specimen_id | text | Foreign key relationship to the em_specimen category |
| temperature | integer | The value of the temperature in kelvin used for growing the crystals. |
| time | integer | Time period for array crystallization, in time unit indicated (min, hr, day, month, year) |
| time_unit | text | Time unit for array crystallization |

## em_ctf_correction

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| details | text | Any additional details about CTF correction |
| em_image_processing_id | text | Foreign key to the EM_IMAGE_PROCESSING category |
| id | text | PRIMARY KEY |
| type | text | Type of CTF correction applied |

## em_db_reference

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| access_code | text | Unique identifier for a provided link. |
| db_name | text | The name of the database containing the related entry. |
| details | text | A description of the related entry. |
| id | text | PRIMARY KEY |
| relationship | text | Indicates relationship of this entry with other entries in PDB and EMDB. |

## em_db_reference_auxiliary

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| id | text | PRIMARY KEY |
| link_type | text | Type of auxiliary data stored at the indicated link. |

## em_diffraction

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| camera_length | double precision | The camera length (in millimeters). The camera length is the product of the objective focal length and the combined magnification of the intermediate and projector lenses when the microscope is operated in the diffraction mode. |
| id | text | PRIMARY KEY |
| imaging_id | text | Foreign key to the EM_IMAGING category |
| tilt_angle_list | text | Comma-separated list of tilt angles (in degrees) used in the electron diffraction experiment. |

## em_diffraction_shell

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| em_diffraction_stats_id | text | Pointer to EM CRYSTALLOGRAPHY STATS |
| fourier_space_coverage | double precision | Completeness of the structure factor data within this resolution shell, in percent |
| high_resolution | double precision | High resolution limit for this shell (angstroms) |
| id | text | PRIMARY KEY |
| low_resolution | double precision | Low resolution limit for this shell (angstroms) |
| multiplicity | double precision | Multiplicity (average number of measurements) for the structure factors in this resolution shell |
| num_structure_factors | integer | Number of measured structure factors in this resolution shell |
| phase_residual | double precision | Phase residual for this resolution shell, in degrees |

## em_diffraction_stats

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| details | text | Any addition details about the structure factor measurements |
| fourier_space_coverage | double precision | Completeness of the structure factor data within the defined space group at the reported resolution (percent). |
| high_resolution | double precision | High resolution limit of the structure factor data, in angstroms |
| id | text | PRIMARY KEY |
| image_processing_id | text | Pointer to _em_image_processing.id |
| num_intensities_measured | integer | Total number of diffraction intensities measured (before averaging) |
| num_structure_factors | integer | Number of structure factors obtained (merged amplitudes + phases) |
| overall_phase_error | double precision | Overall phase error in degrees |
| overall_phase_residual | double precision | Overall phase residual in degrees |
| phase_error_rejection_criteria | text | Criteria used to reject phases |
| r_merge | double precision | Rmerge value (percent) |
| r_sym | double precision | Rsym value (percent) |

## em_embedding

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| details | text | Staining procedure used in the specimen preparation. |
| id | text | PRIMARY KEY |
| material | text | The embedding material. |
| specimen_id | text | Foreign key relationship to the EM SPECIMEN category |

## em_entity_assembly

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| id | text | PRIMARY KEY |
| parent_id | integer | The parent of this assembly. This data item is an internal category pointer to _em_entity_assembly.id. By convention, the full assembly (top of hierarchy) is assigned parent id 0 (zero). |
| source | text | The type of source (e.g., natural source) for the component (sample or sample subcomponent) |
| type | text | The general type of the sample or sample subcomponent. |
| name | text | The name of the sample or sample subcomponent. |
| details | text | Additional details about the sample or sample subcomponent. |
| synonym | text | Alternative name of the component. |
| entity_id_list | text | macromolecules associated with this component, if defined as comma separated list of entity ids (integers). |
| chimera | text | An indication if an assembly is contains a chimeric polymer |

## em_entity_assembly_molwt

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| entity_assembly_id | text | A reference to em_entity_assembly.id which uniquely identifies one sample or sample subcomponent of the imaged specimen. |
| experimental_flag | text | Identifies whether the given molecular weight was derived experimentally. |
| id | text | PRIMARY KEY |
| units | text | Molecular weight units. |
| value | double precision | The molecular weight of the sample or sample subcomponent |

## em_entity_assembly_naturalsource

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| cell | text | The cell type from which the component was obtained. |
| cellular_location | text | The cellular location of the component. |
| entity_assembly_id | text | Pointer to the assembly component defined in the EM ENTITY ASSEMBLY category. |
| id | text | PRIMARY KEY |
| ncbi_tax_id | integer | The NCBI taxonomy id for the natural organism source of the component. |
| organism | text | The scientific name of the source organism for the component |
| organelle | text | The organelle from which the component was obtained. |
| organ | text | The organ of the organism from which the component was obtained. |
| strain | text | The strain of the natural organism from which the component was obtained, if relevant. |
| tissue | text | The tissue of the natural organism from which the component was obtained. |
| details | text | Additional details describing this natural source. |

## em_entity_assembly_recombinant

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| cell | text | The cell of the host organism from which the expressed component was obtained, if relevant. |
| entity_assembly_id | text | Pointer to the expressed component described in the EM ENTITY ASSEMBLY category. |
| id | text | PRIMARY KEY |
| ncbi_tax_id | integer | The NCBI taxonomy id of the expression host used to produce the component. |
| organism | text | Expression system host organism used to produce the component. |
| plasmid | text | The plasmid used to produce the component in the expression system. |
| strain | text | The strain of the host organism from which the expresed component was obtained, if relevant. |

## em_euler_angle_assignment

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| details | text | Any additional details about euler angle assignment |
| id | text | PRIMARY KEY |
| image_processing_id | text | Foreign key to the EM_IMAGE_PROCESSING category |
| order | text | Stage of the reconstruction in which the angle assignments were made. |
| proj_matching_angular_sampling | double precision | Angular sampling of projection matching |
| proj_matching_merit_function | text | Overall figure of merit for projection matching |
| proj_matching_num_projections | integer | Number of reference projections used for euler angle assignment |
| type | text | The procedure used to assigned euler angles. |

## em_experiment

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| entry_id | text | This data item is a pointer to _entry.id in the ENTRY category. |
| id | text | PRIMARY KEY |
| reconstruction_method | text | The reconstruction method used in the EM experiment. |
| aggregation_state | text | The aggregation/assembly state of the imaged specimen. |
| entity_assembly_id | text | Foreign key to the EM_ENTITY_ASSEMBLY category |

## em_fiducial_markers

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| diameter | double precision | Diameter of the fiducial markers |
| em_tomography_specimen_id | text | Foreign key relationship to the EM TOMOGRAPHY SPECIMEN category |
| id | text | PRIMARY KEY |
| manufacturer | text | Manufacturer source for the fiducial markers |

## em_final_classification

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| avg_num_images_per_class | integer | The average number of images per class in the final 2D/3D classification |
| details | text | Additional details about the final 2D/3D classification |
| id | text | PRIMARY KEY |
| image_processing_id | text | Foreign key to the EM_IMAGE_PROCESSING category |
| num_classes | integer | The number of classes used in the final 2D/3D classification |
| type | text | Space (2D/3D) for the classification. |

## em_focused_ion_beam

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| current | double precision | Current of the ion beam, in nanoamperes (nA) |
| details | text | Additional details about FIB milling |
| duration | double precision | Milling time in seconds |
| em_tomography_specimen_id | text | Foreign key relationship to the EM TOMOGRAPHY SPECIMEN category |
| final_thickness | integer | Final sample thickness |
| id | text | PRIMARY KEY |
| initial_thickness | integer | Initial sample thickness |
| instrument | text | The instrument used for focused ion beam sectioning |
| ion | text | The ion source used to ablate the specimen |
| temperature | integer | Temperature of the sample during milling, in kelvins |
| voltage | integer | Voltage applied to the ion source, in kilovolts |

## em_grid_pretreatment

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| atmosphere | text | The atmosphere used for glow discharge of the em grid. |
| id | text | PRIMARY KEY |
| pressure | double precision | Pressure of the glow discharge chamber, in pascals |
| sample_support_id | text | Pointer to EM SAMPLE SUPPORT |
| time | integer | Time period for glow discharge of the em grid, in seconds |
| type | text | Type of grid pretreatment |

## em_helical_entity

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| id | text | PRIMARY KEY |
| entity_assembly_id | text | The value of _em_helical_entity.entity_assembly_id identifies a particular assembly component. This data item is a pointer to _em_entity_assembly.id in the EM_ENTITY_ASSEMBLY category. |
| image_processing_id | text | This data item is a pointer to _em_image_processing.id. |
| details | text | Any other details regarding the helical assembly |
| axial_symmetry | text | Symmetry of the helical axis, either cyclic (Cn) or dihedral (Dn), where n&gt;=1. |
| angular_rotation_per_subunit | double precision | The angular rotation per helical subunit in degrees. Negative values indicate left-handed helices; positive values indicate right handed helices. |
| axial_rise_per_subunit | double precision | The axial rise per subunit in the helical assembly. |

## em_high_pressure_freezing

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| details | text | Additional details about high pressure freezing. |
| em_tomography_specimen_id | text | Foreign key relationship to the EM TOMOGRAPHY SPECIMEN category |
| id | text | PRIMARY KEY |
| instrument | text | The instrument used for high pressure freezing. |

## em_image_processing

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| details | text | Method details. |
| id | text | PRIMARY KEY |
| image_recording_id | text | Foreign key to the EM_IMAGE_RECORDING |

## em_image_recording

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| average_exposure_time | double precision | The average exposure time for each image. |
| avg_electron_dose_per_subtomogram | double precision | The average total electron dose received by the specimen for each subtomogram (electrons per square angstrom). |
| avg_electron_dose_per_image | double precision | The electron dose received by the specimen per image (electrons per square angstrom). |
| details | text | Any additional details about image recording. |
| detector_mode | text | The detector mode used during image recording. |
| film_or_detector_model | text | The detector type used for recording images. Usually film , CCD camera or direct electron detector. |
| id | text | PRIMARY KEY |
| imaging_id | text | This data item the id of the microscopy settings used in the imaging. |
| num_diffraction_images | integer | The number of diffraction images collected. |
| num_grids_imaged | integer | Number of grids in the microscopy session |
| num_real_images | integer | The number of micrograph images collected. |

## em_image_scans

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| entry_id | text | This data item is a pointer to _entry.id in the ENTRY category. |
| id | text | The value of _em_image_scans.id must uniquely identify the images scanned. |
| scanner_model | text | The scanner model. |
| sampling_size | double precision | The sampling step size (microns) set on the scanner. |
| dimension_height | integer | Height of scanned image, in pixels |
| dimension_width | integer | Width of scanned image, in pixels |
| frames_per_image | integer | Total number of time-slice (movie) frames taken per image. |
| image_recording_id | text | foreign key linked to _em_image_recording |
| used_frames_per_image | text | Range of time-slice (movie) frames used for the reconstruction. |

## em_imaging

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| entry_id | text | This data item is a pointer to _entry.id in the ENTRY category. |
| id | text | PRIMARY KEY |
| residual_tilt | double precision | Residual tilt of the electron beam (in miliradians) |
| sample_support_id | text | This data item is a pointer to _em_sample_support.id in the EM_SAMPLE_SUPPORT category. |
| detector_id | text | The value of _em_imaging.detector_id must uniquely identify the type of detector used in the experiment. |
| scans_id | text | The value of _em_imaging.scans_id must uniquely identify the image_scans used in the experiment. |
| microscope_id | text | This data item is a pointer to _em_microscope.id in the EM_MICROSCOPE category. |
| microscope_model | text | The name of the model of microscope. |
| specimen_holder_model | text | The name of the model of specimen holder used during imaging. |
| details | text | Any additional imaging details. |
| date | date | Date (YYYY-MM-DD) of imaging experiment or the date at which a series of experiments began. |
| accelerating_voltage | integer | A value of accelerating voltage (in kV) used for imaging. |
| illumination_mode | text | The mode of illumination. |
| mode | text | The mode of imaging. |
| nominal_cs | double precision | The spherical aberration coefficient (Cs) in millimeters, of the objective lens. |
| nominal_defocus_min | double precision | The minimum defocus value of the objective lens (in nanometers) used to obtain the recorded images. Negative values refer to overfocus. |
| nominal_defocus_max | double precision | The maximum defocus value of the objective lens (in nanometers) used to obtain the recorded images. Negative values refer to overfocus. |
| calibrated_defocus_min | double precision | The minimum calibrated defocus value of the objective lens (in nanometers) used to obtain the recorded images. Negative values refer to overfocus. |
| calibrated_defocus_max | double precision | The maximum calibrated defocus value of the objective lens (in nanometers) used to obtain the recorded images. Negative values refer to overfocus. |
| nominal_magnification | integer | The magnification indicated by the microscope readout. |
| calibrated_magnification | integer | The magnification value obtained for a known standard just prior to, during or just after the imaging experiment. |
| electron_source | text | The source of electrons. The electron gun. |
| recording_temperature_minimum | double precision | The specimen temperature minimum (kelvin) for the duration of imaging. |
| recording_temperature_maximum | double precision | The specimen temperature maximum (kelvin) for the duration of imaging. |
| alignment_procedure | text | The type of procedure used to align the microscope electron beam. |
| c2_aperture_diameter | double precision | The open diameter of the c2 condenser lens, in microns. |
| specimen_id | text | Foreign key to the EM_SPECIMEN category |
| cryogen | text | Cryogen type used to maintain the specimen stage temperature during imaging in the microscope. |

## em_imaging_optics

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| chr_aberration_corrector | text | Chromatic aberration corrector information |
| energyfilter_lower | text | The energy filter range lower value in electron volts (eV) set by spectrometer. |
| energyfilter_slit_width | double precision | The energy filter range slit width in electron volts (eV). |
| energyfilter_name | text | The type of energy filter spectrometer |
| energyfilter_upper | text | The energy filter range upper value in electron volts (eV) set by spectrometer. |
| id | text | PRIMARY KEY |
| imaging_id | text | Foreign key to the EM IMAGING category |
| phase_plate | text | Phase plate information |
| sph_aberration_corrector | text | Spherical aberration corrector information |
| details | text | Details on the use of the phase plate |

## em_map

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| annotation_details | text | map annotation details |
| axis_order_fast | text | The map axis that corresponds to Columns. (CCP4 HEADER WORD 17 MAPC 1=x, 2=y, 3=z) |
| axis_order_medium | text | The map axis that corresponds to Rows. (CCP4 map header word 18 MAPR 1=x, 2=y, 3=z) |
| axis_order_slow | text | The map axis that corresponds to Sections. (CCP4 map header word 19 MAPS 1=x, 2=y, 3=z) |
| cell_a | double precision | Map unit cell length parameter a. (CCP4 map header word 11) |
| cell_b | double precision | Map unit cell length parameter b. (CCP4 map header word 12) |
| cell_c | double precision | Map unit cell length parameter c. (CCP4 map header word 13) |
| cell_alpha | double precision | Value of map unit cell angle parameter alpha in degrees. (CCP4 map header word 14) |
| cell_beta | double precision | Value of map unit cell angle parameter beta in degrees. (CCP4 map header word 15) |
| cell_gamma | double precision | Value of map unit cell angle parameter gamma in degrees. (CCP4 map header word 16) |
| contour_level | double precision | recommended contour level for viewing the map |
| contour_level_source | text | source of the recommended contour level |
| data_type | text | The map data_type describes the data structure of the map voxels. (CCP4 map header word 4 MODE) EMDB currently holds MODE=0,1,and 2 maps; the majority are MODE=2. MAPS with MODES other than 2 and 0 may not work in CCP4 programs. MODE = 0: 8 bits, density stored as a signed byte (-128 to 127, ISO/IEC 10967) MODE = 1: 16 bits, density stored as a signed integer (-32768 to 32767, ISO/IEC 10967) MODE = 2: 32 bits, density stored as a floating point number (IEEE 754) |
| dimensions_col | integer | The number of columns in the map. (CCP4 map header word 1 NC) |
| dimensions_row | integer | The number of rows in the map. (CCP4 map header word 2 NR) |
| dimensions_sec | integer | The number of sections in the map. (CCP4 map header word 3 NS) |
| endian_type | text | map file endian type |
| file | text | Map file name. |
| format | text | map format |
| id | integer | PRIMARY KEY |
| partition | integer | Identifies the archive file partition number of any map file |
| entry_id | text | This data item is a pointer to the ENTRY category. |
| label | text | text stored in the label field of the CCP4 map header (WORDS 57-256) |
| limit_col | integer | The final column position of the map relative to the Cartesian coordinate origin in voxel grid units. (derived = .origin_col + .dimensions_col -1) |
| limit_row | integer | The final row position of the map relative to the Cartesian coordinate origin in voxel grid units. (derived = .origin_row + .dimensions_row -1) |
| limit_sec | integer | The final section position of the map relative to the Cartesian coordinate origin in voxel grid units. (derived -- .origin_sec + .dimensions_sec -1) |
| origin_col | integer | The position of the first column of the map relative to the Cartesian coordinate origin in voxel grid units. (CCP4 map header word 5 NCSTART) |
| origin_row | integer | The position of the first row of the map relative to the Cartesian coordinate origin in voxel grid units. (CCP4 map header word 6 NRSTART) |
| origin_sec | integer | The position of the first section of the map relative to the Cartesian coordinate origin in voxel grid units. (CCP4 map header word 7 NSSTART) |
| pixel_spacing_x | double precision | The length in angstroms of one voxel along the X axis. |
| pixel_spacing_y | double precision | The length in angstroms of one voxel along the Y axis. |
| pixel_spacing_z | double precision | The length in angstroms of one voxel along the Z axis. |
| size_kb | bigint | map storage size in Kilobytes (before compression) |
| spacing_x | integer | The number of intervals per cell repeat in X. (CCP4 map header word 8 NX) |
| spacing_y | integer | The number of intervals per cell repeat in Y. (CCP4 map header word 9 NY) |
| spacing_z | integer | The number of intervals per cell repeat in Z. (CCP4 map header word 10 NZ) |
| statistics_average | double precision | Mean (average) density value of the map. |
| statistics_maximum | double precision | Maximum density value of the map. |
| statistics_minimum | double precision | Minimum density value of the map. |
| statistics_std | double precision | The standard deviation of the map density values. |
| symmetry_space_group | integer | The space group number for the map. The value is 1 unless the sample is crystalline. (CCP4 map header word 23 ISPG) |
| type | text | Map type |

## em_obsolete

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| date | date | Dated when the entry made obsolete the other entry |
| details | text | Description of the reason(s) for entry obsoletion |
| entry | text | Entry made obsolete |
| id | text | PRIMARY KEY |

## em_particle_selection

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| details | text | Additional detail such as description of filters used, if selection was manual or automated, and/or template details. |
| id | text | PRIMARY KEY |
| image_processing_id | text | The value of _em_particle_selection.image_processing_id points to the EM_IMAGE_PROCESSING category. |
| num_particles_selected | bigint | The number of particles selected from the projection set of images. |

## em_sample_support

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| id | text | PRIMARY KEY |
| film_material | text | The support material covering the em grid. |
| grid_material | text | The name of the material from which the grid is made. |
| grid_mesh_size | integer | The value of the mesh size (divisions per inch) of the em grid. |
| grid_type | text | A description of the grid type. |
| pretreatment | text | A description of the grid plus support film pretreatment. |
| details | text | Any additional details concerning the sample support. |
| specimen_id | text | This data item is a pointer to _em_sample_preparation.id in the EM_SPECIMEN category. |

## em_single_particle_entity

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| entry_id | text | This data item is a pointer to _entry.id in the ENTRY category. |
| id | integer | PRIMARY KEY |
| image_processing_id | text | pointer to _em_image_processing.id. |
| point_symmetry | text | Point symmetry symbol, either Cn, Dn, T, O, or I |

## em_software

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| category | text | The purpose of the software. |
| details | text | Details about the software used. |
| id | text | PRIMARY KEY |
| image_processing_id | text | pointer to _em_image_processing.id in the EM_IMAGE_PROCESSING category. |
| fitting_id | text | pointer to _em_3d_fitting.id in the EM_3D_FITTING category. |
| imaging_id | text | pointer to _em_imaging.id in the EM_IMAGING category. |
| name | text | The name of the software package used, e.g., RELION. Depositors are strongly encouraged to provide a value in this field. |
| version | text | The version of the software. |

## em_specimen

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| concentration | double precision | The concentration (in milligrams per milliliter, mg/ml) of the complex in the sample. |
| details | text | A description of any additional details of the specimen preparation. |
| embedding_applied | boolean | 'YES' indicates that the specimen has been embedded. |
| experiment_id | text | Pointer to _em_experiment.id. |
| id | text | PRIMARY KEY |
| shadowing_applied | boolean | 'YES' indicates that the specimen has been shadowed. |
| staining_applied | boolean | 'YES' indicates that the specimen has been stained. |
| vitrification_applied | boolean | 'YES' indicates that the specimen was vitrified by cryopreservation. |

## em_staining

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| details | text | Staining procedure used in the specimen preparation. |
| id | text | PRIMARY KEY |
| material | text | The staining material. |
| specimen_id | text | Foreign key relationship to the EM SPECIMEN category |
| type | text | type of staining |

## em_start_model

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text | EMDB id of the map used as the startup model |
| details | text | Any additional details about generating the startup model |
| id | text | PRIMARY KEY |
| image_processing_id | text | Foreign key to the EM_IMAGE_PROCESSING category |
| insilico_model | text | Description of the "in silico" model used to generate the startup model |
| orthogonal_tilt_angle1 | double precision | Tilt angle for the 1st image set of the orthogonal tilt pairs |
| orthogonal_tilt_angle2 | double precision | Tilt angle for the 2nd image set of the orthogonal tilt pairs |
| orthogonal_tilt_num_images | integer | number of images used to generate the orthogonal tilt startup model |
| other | text | Description of other method/source used to generate the startup model |
| pdb_id | text | PDB id of the model coordinates used to generate the startup model |
| random_conical_tilt_angle | double precision | Angular difference between the conical tilt images used to generate the startup model |
| random_conical_tilt_num_images | integer | number of images used to generate the random conical tilt startup model |
| type | text | Type of startup model (map density) used to initiate the reconstruction |

## em_supersede

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| entry | text | Newer entry that replaces this entry |
| id | text | PRIMARY KEY |

## em_support_film

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| id | text | PRIMARY KEY |
| material | text | The support material covering the em grid. |
| sample_support_id | text | Pointer to EM SAMPLE SUPPORT |
| thickness | double precision | Thickness of the support film, in angstroms |
| topology | text | The topology of the material from which the grid is made. |

## em_tomography

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| axis1_angle_increment | double precision | The angle increment of specimen tilting to obtain the recorded images (axis 1). |
| axis1_max_angle | double precision | The maximum angle at which the specimen was tilted to obtain recorded images (axis 1). |
| axis1_min_angle | double precision | The minimum angle at which the specimen was tilted to obtain recorded images (axis 1). |
| axis2_angle_increment | double precision | The angle increment of specimen tilting to obtain the recorded images (axis 2). |
| axis2_max_angle | double precision | The maximum angle at which the specimen was tilted to obtain recorded images (axis 2). |
| axis2_min_angle | double precision | The minimum angle at which the specimen was tilted to obtain recorded images (axis 2). |
| id | text | PRIMARY KEY |
| imaging_id | text | Foreign key to the EM IMAGING category |

## em_tomography_specimen

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| cryo_protectant | text | The type of cryo-protectant used during specimen preparation. |
| details | text | Any additional details about specimen preparation. |
| fiducial_markers | text | 'YES' indicates that fiducial markers were used in the specimen preparation |
| high_pressure_freezing | text | 'YES' indicates that high pressure freezing was used in the specimen preparation |
| id | text | PRIMARY KEY |
| sectioning | text | The type of sectioning performed during specimen preparation. |
| specimen_id | text | Foreign key relationship to the EM SPECIMEN category |

## em_ultramicrotomy

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| details | text | Additional details about the ultramicrotomy sample preparation |
| em_tomography_specimen_id | text | Foreign key relationship to the EM TOMOGRAPHY SPECIMEN category |
| final_thickness | integer | Final thickness of the sectioned sample, in nanometers |
| id | text | PRIMARY KEY |
| instrument | text | Ultramicrotome instrument used for sectioning |
| temperature | integer | Temperature of the sample during microtome sectioning, in kelvins |

## em_virus_entity

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| id | text | PRIMARY KEY |
| virus_type | text | The type of virus. |
| virus_isolate | text | The isolate from which the virus was obtained. |
| entity_assembly_id | text | This data item is a pointer to _em_virus_entity.id in the ENTITY_ASSEMBLY category. |
| enveloped | text | Flag to indicate if the virus is enveloped or not. |
| empty | text | Flag to indicate if the virus is empty or not. |

## em_virus_natural_host

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| entity_assembly_id | text | Pointer to _em_entity_assembly.id. |
| id | text | PRIMARY KEY |
| ncbi_tax_id | integer | The NCBI taxonomy id for the natural host organism of the virus |
| organism | text | The host organism from which the virus was isolated. |
| strain | text | The strain of the host organism from which the virus was obtained, if relevant. |

## em_virus_shell

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| diameter | double precision | The value of the diameter (in angstroms) for this virus shell. |
| entity_assembly_id | text | The value of _em_virus_shell.entity_assembly_id is a pointer to _em_entity_assembly.id category. |
| id | text | PRIMARY KEY |
| name | text | The name for this virus shell. |
| triangulation | integer | The triangulation number, T, describes the organization of subunits within an icosahedron. T is defined as T= h^2 + h*k + k^2, where h and k are positive integers that define the position of the five-fold vertex on the original hexagonal net. |

## em_virus_synthetic

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| entity_assembly_id | text | Pointer to _em_entity_assembly.id. |
| id | text | PRIMARY KEY |
| organism | text | The host organism from which the virus was isolated. |
| ncbi_tax_id | integer | The NCBI taxonomy ID of the host species from which the virus was isolated |
| strain | text | The strain of the host organism from which the virus was obtained, if relevant. |

## em_vitrification

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| entry_id | text | This data item is a pointer to _entry.id in the ENTRY category. |
| id | text | PRIMARY KEY |
| specimen_id | text | This data item is a pointer to _em_specimen.id |
| cryogen_name | text | This is the name of the cryogen. |
| humidity | double precision | Relative humidity (%) of air surrounding the specimen just prior to vitrification. |
| temp | double precision | The vitrification temperature (in kelvin), e.g., temperature of the plunge instrument cryogen bath. |
| chamber_temperature | double precision | The temperature (in kelvin) of the sample just prior to vitrification. |
| instrument | text | The type of instrument used in the vitrification process. |
| details | text | Any additional details relating to vitrification. |

## em_volume_selection

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| details | text | Any additional details used for selecting volumes. |
| id | text | PRIMARY KEY |
| image_processing_id | text | The value of _em_volume_selection.image_processing_id points to the EM_IMAGE_PROCESSING category. |
| method | text | The method used for selecting volumes. |
| num_tomograms | integer | The number of tomograms used in the extraction/selection |
| num_volumes_extracted | integer | The number of volumes selected from the projection set of images. |
| reference_model | text | Description of reference model used for volume selection |

## entity

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| details | text | A description of special aspects of the entity. |
| formula_weight | double precision | Formula mass in daltons of the entity. |
| id | text | The value of _entity.id must uniquely identify a record in the ENTITY list. Note that this item need not be a number; it can be any unique identifier. |
| src_method | text | The method by which the sample for the entity was produced. Entities isolated directly from natural sources (tissues, soil samples etc.) are expected to have further information in the ENTITY_SRC_NAT category. Entities isolated from genetically manipulated sources are expected to have further information in the ENTITY_SRC_GEN category. |
| type | text | Defines the type of the entity. Polymer entities are expected to have corresponding ENTITY_POLY and associated entries. Non-polymer entities are expected to have corresponding CHEM_COMP and associated entries. Water entities are not expected to have corresponding entries in the ENTITY category. |
| pdbx_description | text | A description of the entity. Corresponds to the compound name in the PDB format. |
| pdbx_number_of_molecules | integer | A place holder for the number of molecules of the entity in the entry. |
| pdbx_mutation | text | Details about any entity mutation(s). |
| pdbx_fragment | text | Entity fragment description(s). |
| pdbx_ec | text | Enzyme Commission (EC) number(s) |

## entity_poly

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| entity_id | text | This data item is a pointer to _entity.id in the ENTITY category. |
| type | text | The type of the polymer. |
| pdbx_seq_one_letter_code | text | Sequence of protein or nucleic acid polymer in standard one-letter codes of amino acids or nucleotides. Non-standard amino acids/nucleotides are represented by their Chemical Component Dictionary (CCD) codes in parenthesis. Deoxynucleotides are represented by the specially-assigned 2-letter CCD codes in parenthesis, with 'D' prefix added to their ribonucleotide counterparts. For hybrid polymer, each residue is represented by the code of its individual type. A cyclic polymer is represented in linear sequence from the chosen start to end. A for Alanine or Adenosine-5'-monophosphate C for Cysteine or Cytidine-5'-monophosphate D for Aspartic acid E for Glutamic acid F for Phenylalanine G for Glycine or Guanosine-5'-monophosphate H for Histidine I for Isoleucine or Inosinic Acid L for Leucine K for Lysine M for Methionine N for Asparagine or Unknown ribonucleotide O for Pyrrolysine P for Proline Q for Glutamine R for Arginine S for Serine T for Threonine U for Selenocysteine or Uridine-5'-monophosphate V for Valine W for Tryptophan Y for Tyrosine (DA) for 2'-deoxyadenosine-5'-monophosphate (DC) for 2'-deoxycytidine-5'-monophosphate (DG) for 2'-deoxyguanosine-5'-monophosphate (DT) for Thymidine-5'-monophosphate (MSE) for Selenomethionine (SEP) for Phosphoserine (TPO) for Phosphothreonine (PTR) for Phosphotyrosine (PCA) for Pyroglutamic acid (UNK) for Unknown amino acid (ACE) for Acetylation cap (NH2) for Amidation cap |

## entity_src_gen

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| entity_id | text | This data item is a pointer to _entity.id in the ENTITY category. |
| gene_src_common_name | text | The common name of the natural organism from which the gene was obtained. |
| gene_src_details | text | A description of special aspects of the natural organism from which the gene was obtained. |
| gene_src_genus | text | The genus of the natural organism from which the gene was obtained. |
| gene_src_species | text | The species of the natural organism from which the gene was obtained. |
| gene_src_strain | text | The strain of the natural organism from which the gene was obtained, if relevant. |
| gene_src_tissue | text | The tissue of the natural organism from which the gene was obtained. |
| pdbx_gene_src_gene | text | Identifies the gene. |
| pdbx_gene_src_scientific_name | text | Scientific name of the organism. |
| pdbx_gene_src_variant | text | Identifies the variant. |
| pdbx_gene_src_cell_line | text | The specific line of cells. |
| pdbx_gene_src_atcc | text | American Type Culture Collection tissue culture number. |
| pdbx_gene_src_organ | text | Organized group of tissues that carries on a specialized function. |
| pdbx_gene_src_cell | text | Cell type. |
| pdbx_host_org_organ | text | Specific organ which expressed the molecule. |
| pdbx_host_org_organelle | text | Specific organelle which expressed the molecule. |
| pdbx_host_org_cellular_location | text | Identifies the location inside (or outside) the cell which expressed the molecule. |
| pdbx_host_org_strain | text | The strain of the organism in which the entity was expressed. |
| pdbx_description | text | Information on the source which is not given elsewhere. |
| host_org_common_name | text | The common name of the organism that served as host for the production of the entity. Where full details of the protein production are available it would be expected that this item be derived from _entity_src_gen_express.host_org_common_name or via _entity_src_gen_express.host_org_tax_id |
| host_org_details | text | A description of special aspects of the organism that served as host for the production of the entity. Where full details of the protein production are available it would be expected that this item would derived from _entity_src_gen_express.host_org_details |
| plasmid_details | text | A description of special aspects of the plasmid that produced the entity in the host organism. Where full details of the protein production are available it would be expected that this item would be derived from _pdbx_construct.details of the construct pointed to from _entity_src_gen_express.plasmid_id. |
| plasmid_name | text | The name of the plasmid that produced the entity in the host organism. Where full details of the protein production are available it would be expected that this item would be derived from _pdbx_construct.name of the construct pointed to from _entity_src_gen_express.plasmid_id. |
| pdbx_host_org_variant | text | Variant of the organism used as the expression system. Where full details of the protein production are available it would be expected that this item be derived from entity_src_gen_express.host_org_variant or via _entity_src_gen_express.host_org_tax_id |
| pdbx_host_org_cell_line | text | A specific line of cells used as the expression system. Where full details of the protein production are available it would be expected that this item would be derived from entity_src_gen_express.host_org_cell_line |
| pdbx_host_org_atcc | text | Americal Tissue Culture Collection of the expression system. Where full details of the protein production are available it would be expected that this item would be derived from _entity_src_gen_express.host_org_culture_collection |
| pdbx_host_org_culture_collection | text | Culture collection of the expression system. Where full details of the protein production are available it would be expected that this item would be derived somehwere, but exactly where is not clear. |
| pdbx_host_org_cell | text | Cell type from which the gene is derived. Where entity.target_id is provided this should be derived from details of the target. |
| pdbx_host_org_scientific_name | text | The scientific name of the organism that served as host for the production of the entity. Where full details of the protein production are available it would be expected that this item would be derived from _entity_src_gen_express.host_org_scientific_name or via _entity_src_gen_express.host_org_tax_id |
| pdbx_host_org_tissue | text | The specific tissue which expressed the molecule. Where full details of the protein production are available it would be expected that this item would be derived from _entity_src_gen_express.host_org_tissue |
| pdbx_host_org_vector | text | Identifies the vector used. Where full details of the protein production are available it would be expected that this item would be derived from _entity_src_gen_clone.vector_name. |
| pdbx_host_org_vector_type | text | Identifies the type of vector used (plasmid, virus, or cosmid). Where full details of the protein production are available it would be expected that this item would be derived from _entity_src_gen_express.vector_type. |
| pdbx_gene_src_ncbi_taxonomy_id | text | NCBI Taxonomy identifier for the gene source organism. Reference: Wheeler DL, Chappey C, Lash AE, Leipe DD, Madden TL, Schuler GD, Tatusova TA, Rapp BA (2000). Database resources of the National Center for Biotechnology Information. Nucleic Acids Res 2000 Jan 1;28(1):10-4 Benson DA, Karsch-Mizrachi I, Lipman DJ, Ostell J, Rapp BA, Wheeler DL (2000). GenBank. Nucleic Acids Res 2000 Jan 1;28(1):15-18. |
| pdbx_host_org_ncbi_taxonomy_id | text | NCBI Taxonomy identifier for the expression system organism. Reference: Wheeler DL, Chappey C, Lash AE, Leipe DD, Madden TL, Schuler GD, Tatusova TA, Rapp BA (2000). Database resources of the National Center for Biotechnology Information. Nucleic Acids Res 2000 Jan 1;28(1):10-4 Benson DA, Karsch-Mizrachi I, Lipman DJ, Ostell J, Rapp BA, Wheeler DL (2000). GenBank. Nucleic Acids Res 2000 Jan 1;28(1):15-18. |
| pdbx_src_id | integer | This data item is an ordinal identifier for entity_src_gen data records. |
| pdbx_alt_source_flag | text | This data item identifies cases in which an alternative source modeled. |
| pdbx_seq_type | text | This data item povides additional information about the sequence type. |
| pdbx_beg_seq_num | integer | The beginning polymer sequence position for the polymer section corresponding to this source. A reference to the sequence position in the entity_poly category. |
| pdbx_end_seq_num | integer | The ending polymer sequence position for the polymer section corresponding to this source. A reference to the sequence position in the entity_poly category. |

## entity_src_nat

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| common_name | text | The common name of the organism from which the entity was isolated. |
| details | text | A description of special aspects of the organism from which the entity was isolated. |
| entity_id | text | This data item is a pointer to _entity.id in the ENTITY category. |
| genus | text | The genus of the organism from which the entity was isolated. |
| strain | text | The strain of the organism from which the entity was isolated. |
| tissue | text | The tissue of the organism from which the entity was isolated. |
| pdbx_organism_scientific | text | Scientific name of the organism of the natural source. |
| pdbx_variant | text | Identifies the variant. |
| pdbx_cell_line | text | The specific line of cells. |
| pdbx_atcc | text | Americal Tissue Culture Collection number. |
| pdbx_cellular_location | text | Identifies the location inside (or outside) the cell. |
| pdbx_organ | text | Organized group of tissues that carries on a specialized function. |
| pdbx_cell | text | A particular cell type. |
| pdbx_plasmid_details | text | Details about the plasmid. |
| pdbx_ncbi_taxonomy_id | text | NCBI Taxonomy identifier for the source organism. Reference: Wheeler DL, Chappey C, Lash AE, Leipe DD, Madden TL, Schuler GD, Tatusova TA, Rapp BA (2000). Database resources of the National Center for Biotechnology Information. Nucleic Acids Res 2000 Jan 1;28(1):10-4 Benson DA, Karsch-Mizrachi I, Lipman DJ, Ostell J, Rapp BA, Wheeler DL (2000). GenBank. Nucleic Acids Res 2000 Jan 1;28(1):15-18. |
| pdbx_src_id | integer | This data item is an ordinal identifier for entity_src_nat data records. |
| pdbx_alt_source_flag | text | This data item identifies cases in which an alternative source modeled. |
| pdbx_beg_seq_num | integer | The beginning polymer sequence position for the polymer section corresponding to this source. A reference to the sequence position in the entity_poly category. |
| pdbx_end_seq_num | integer | The ending polymer sequence position for the polymer section corresponding to this source. A reference to the sequence position in the entity_poly category. |

## entry

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| id | text | The value of _entry.id identifies the data block. Note that this item need not be a number; it can be any unique identifier. |

## exptl

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| entry_id | text | This data item is a pointer to _entry.id in the ENTRY category. |
| method | text | The method used in the experiment. |

## link_entry_pdbjplus

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| db_name | text |  |
| db_accession | text[] |  |

## pdbx_audit_revision_category

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| ordinal | integer | A unique identifier for the pdbx_audit_revision_category record. |
| revision_ordinal | integer | A pointer to _pdbx_audit_revision_history.ordinal |
| data_content_type | text | The type of file that the pdbx_audit_revision_history record refers to. |
| category | text | The category updated in the pdbx_audit_revision_category record. |

## pdbx_audit_revision_details

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| ordinal | integer | A unique identifier for the pdbx_audit_revision_details record. |
| revision_ordinal | integer | A pointer to _pdbx_audit_revision_history.ordinal |
| data_content_type | text | The type of file that the pdbx_audit_revision_history record refers to. |
| provider | text | The provider of the revision. |
| type | text | A type classification of the revision |
| description | text | Additional details describing the revision. |
| details | text | Further details describing the revision. |

## pdbx_audit_revision_group

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| ordinal | integer | A unique identifier for the pdbx_audit_revision_group record. |
| revision_ordinal | integer | A pointer to _pdbx_audit_revision_history.ordinal |
| data_content_type | text | The type of file that the pdbx_audit_revision_history record refers to. |
| group | text | The collection of categories updated with this revision. |

## pdbx_audit_revision_history

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| ordinal | integer | A unique identifier for the pdbx_audit_revision_history record. |
| data_content_type | text | The type of file that the pdbx_audit_revision_history record refers to. |
| major_revision | integer | The major version number of deposition release. |
| minor_revision | integer | The minor version number of deposition release. |
| revision_date | date | The release date of the revision |
| part_number | integer | The part number of the content_type file correspondng to this milestone file |

## pdbx_audit_revision_item

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| ordinal | integer | A unique identifier for the pdbx_audit_revision_item record. |
| revision_ordinal | integer | A pointer to _pdbx_audit_revision_history.ordinal |
| data_content_type | text | The type of file that the pdbx_audit_revision_history record refers to. |
| item | text | A high level explanation the author has provided for submitting a revision. |

## pdbx_audit_support

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| funding_organization | text | The name of the organization providing funding support for the entry. |
| country | text | The country/region providing the funding support for the entry. |
| grant_number | text | The grant number associated with this source of support. |
| details | text | Additional details regarding the funding of this entry |
| ordinal | integer | A unique sequential integer identifier for each source of support for this entry. |

## pdbx_database_related

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| db_name | text | The name of the database containing the related entry. |
| details | text | A description of the related entry. |
| db_id | text | The identifying code in the related database. |
| content_type | text | The identifying content type of the related entry. |

## pdbx_entity_nonpoly

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| entity_id | text | This data item is a pointer to _entity.id in the ENTITY category. |
| comp_id | text | This data item is a pointer to _chem_comp.id in the CHEM_COMP category. |
| name | text | A name for the non-polymer entity |

## pdbx_entity_src_syn

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| details | text | A description of special aspects of the source for the synthetic entity. |
| organism_scientific | text | The scientific name of the organism from which the sequence of the synthetic entity was derived. |
| organism_common_name | text | The common name of the organism from which the sequence of the synthetic entity was derived. |
| strain | text | The strain of the organism from which the sequence of the synthetic entity was derived. |
| ncbi_taxonomy_id | text | NCBI Taxonomy identifier of the organism from which the sequence of the synthetic entity was derived. Reference: Wheeler DL, Chappey C, Lash AE, Leipe DD, Madden TL, Schuler GD, Tatusova TA, Rapp BA (2000). Database resources of the National Center for Biotechnology Information. Nucleic Acids Res 2000 Jan 1;28(1):10-4 Benson DA, Karsch-Mizrachi I, Lipman DJ, Ostell J, Rapp BA, Wheeler DL (2000). GenBank. Nucleic Acids Res 2000 Jan 1;28(1):15-18. |
| entity_id | text | This data item is a pointer to _entity.id in the ENTITY category. |
| pdbx_src_id | integer | This data item is an ordinal identifier for pdbx_entity_src_syn data records. |
| pdbx_alt_source_flag | text | This data item identifies cases in which an alternative source modeled. |
| pdbx_beg_seq_num | integer | The beginning polymer sequence position for the polymer section corresponding to this source. A reference to the sequence position in the entity_poly category. |
| pdbx_end_seq_num | integer | The ending polymer sequence position for the polymer section corresponding to this source. A reference to the sequence position in the entity_poly category. |

## pdbx_initial_refinement_model

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| id | integer | A unique identifier for the starting model record. |
| type | text | This item describes the type of the initial model was generated |
| source_name | text | This item identifies the resource of initial model used for refinement |
| accession_code | text | This item identifies an accession code of the resource where the initial model is used |
| details | text | A description of special aspects of the initial model |

## struct_keywords

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| entry_id | text | This data item is a pointer to _entry.id in the ENTRY category. |
| text | text | Keywords describing this structure. |
| pdbx_keywords | text | Terms characterizing the macromolecular structure. |
| pdbx_details | text | Keywords describing this structure. This is constructed by the PROGRAM for the PDB KEYWRD record. |

## struct_ref

| Column | Type | Description |
|--------|------|-------------|
| emdb_id | text |  |
| db_code | text | The code for this entity or biological unit or for a closely related entity or biological unit in the named database. |
| db_name | text | The name of the database containing reference information about this entity or biological unit. |
| entity_id | text | This data item is a pointer to _entity.id in the ENTITY category. |
| id | text | The value of _struct_ref.id must uniquely identify a record in the STRUCT_REF list. Note that this item need not be a number; it can be any unique identifier. |
