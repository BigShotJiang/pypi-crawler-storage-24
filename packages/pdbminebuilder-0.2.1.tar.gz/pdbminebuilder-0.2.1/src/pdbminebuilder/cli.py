"""CLI interface using typer + rich."""

import logging
from datetime import datetime
from pathlib import Path
from typing import Annotated, Optional

import typer
from rich.console import Console

from pdbminebuilder import __version__
from pdbminebuilder.config import load_config

app = typer.Typer(
    name="pmb",
    help="pdb-mine-builder - Build a Mine-schema database from PDB data.",
    rich_markup_mode="rich",
)
console = Console()


def setup_logging(log_file: Path | None, verbose: bool = False) -> logging.Logger:
    """Configure logging with optional file output.

    Args:
        log_file: Path to log file (None for no file logging)
        verbose: If True, set DEBUG level; otherwise INFO

    Returns:
        Configured logger
    """
    logger = logging.getLogger("pmb")
    logger.setLevel(logging.DEBUG if verbose else logging.INFO)

    # Clear existing handlers
    logger.handlers.clear()

    # Console handler (only warnings and errors)
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.WARNING)
    console_handler.setFormatter(logging.Formatter("%(levelname)s: %(message)s"))
    logger.addHandler(console_handler)

    # File handler (if specified)
    if log_file:
        log_file.parent.mkdir(parents=True, exist_ok=True)
        file_handler = logging.FileHandler(log_file, mode="w", encoding="utf-8")
        file_handler.setLevel(logging.DEBUG if verbose else logging.INFO)
        file_handler.setFormatter(
            logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
        )
        logger.addHandler(file_handler)
        console.print(f"[dim]Logging to: {log_file}[/dim]")

    return logger


def version_callback(value: bool) -> None:
    if value:
        console.print(f"pmb version {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: Annotated[
        Optional[bool],
        typer.Option("--version", "-v", callback=version_callback, is_eager=True),
    ] = None,
) -> None:
    """pdb-mine-builder - Build a Mine-schema database from PDB data."""
    pass


@app.command()
def sync(
    targets: Annotated[
        Optional[list[str]],
        typer.Argument(
            help="Sync targets: pdbj, pdbj-json, cc, cc-json, ccmodel, ccmodel-json, prd, prd-json, prd-family, vrpt, contacts, schemas"
        ),
    ] = None,
    config: Annotated[
        Path,
        typer.Option("--config", "-c", help="Config file path"),
    ] = Path("config.yml"),
    dry_run: Annotated[
        bool,
        typer.Option(
            "--dry-run", "-n", help="Show what would be synced without actually syncing"
        ),
    ] = False,
) -> None:
    """Synchronize data from PDBj via rsync."""
    from pdbminebuilder.commands.sync import run_sync

    settings = load_config(config)
    run_sync(settings, targets or [], dry_run=dry_run)


@app.command()
def update(
    pipelines: Annotated[
        Optional[list[str]],
        typer.Argument(
            help="Pipelines: pdbj, cc, ccmodel, prd, prd_family, vrpt, contacts, emdb, ihm (format via config)"
        ),
    ] = None,
    config: Annotated[
        Path,
        typer.Option("--config", "-c", help="Config file path"),
    ] = Path("config.yml"),
    limit: Annotated[
        Optional[int],
        typer.Option("--limit", "-l", help="Limit number of entries to process"),
    ] = None,
    workers: Annotated[
        Optional[int],
        typer.Option(
            "--workers", "-w", help="Number of worker processes (overrides config)"
        ),
    ] = None,
    log: Annotated[
        Optional[Path],
        typer.Option(
            "--log",
            help="Log file path (default: logs/<pipeline>_YYYYMMDD_HHMMSS.log)",
        ),
    ] = None,
    verbose: Annotated[
        bool,
        typer.Option("--verbose", "-v", help="Enable verbose (DEBUG) logging"),
    ] = False,
    force: Annotated[
        bool,
        typer.Option(
            "--force",
            "-f",
            help="Reprocess all entries ignoring cached mtimes (pdbj, vrpt, contacts only)",
        ),
    ] = False,
) -> None:
    """Run database update pipelines."""
    from pdbminebuilder.commands.update import run_update

    # Setup logging with pipeline name in filename
    if log is None:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        if pipelines and len(pipelines) == 1:
            # Single pipeline: use pipeline name
            log_name = pipelines[0].replace("-", "_")
        elif pipelines:
            # Multiple pipelines: use "multi"
            log_name = "multi"
        else:
            # All pipelines
            log_name = "all"
        log = Path(f"logs/{log_name}_{timestamp}.log")
    logger = setup_logging(log, verbose)

    settings = load_config(config)
    if workers is not None:
        settings.rdb.nworkers = workers

    logger.info(f"Starting update: pipelines={pipelines or 'all'}, limit={limit}")
    run_update(settings, pipelines or [], limit=limit, force=force)
    logger.info("Update completed")


@app.command()
def load(
    pipelines: Annotated[
        Optional[list[str]],
        typer.Argument(
            help="Pipelines: pdbj, cc, ccmodel, prd, prd_family, vrpt, contacts"
        ),
    ] = None,
    config: Annotated[
        Path,
        typer.Option("--config", "-c", help="Config file path"),
    ] = Path("config.yml"),
    limit: Annotated[
        Optional[int],
        typer.Option("--limit", "-l", help="Limit number of entries to process"),
    ] = None,
    workers: Annotated[
        Optional[int],
        typer.Option(
            "--workers", "-w", help="Number of worker processes (overrides config)"
        ),
    ] = None,
    log: Annotated[
        Optional[Path],
        typer.Option(
            "--log",
            help="Log file path (default: logs/load_<pipeline>_YYYYMMDD_HHMMSS.log)",
        ),
    ] = None,
    verbose: Annotated[
        bool,
        typer.Option("--verbose", "-v", help="Enable verbose (DEBUG) logging"),
    ] = False,
    force: Annotated[
        bool,
        typer.Option("--force", "-f", help="Skip TRUNCATE confirmation prompt"),
    ] = False,
) -> None:
    """Bulk load data using COPY protocol (TRUNCATE + COPY).

    Significantly faster than 'update' for initial/full database loads.
    WARNING: This will TRUNCATE all tables in the target schema before loading.

    Examples:
        pmb load pdbj --limit 1000 --force
        pmb load cc ccmodel prd --force
    """
    from pdbminebuilder.commands.load import run_load

    if log is None:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        if pipelines and len(pipelines) == 1:
            log_name = f"load_{pipelines[0].replace('-', '_')}"
        elif pipelines:
            log_name = "load_multi"
        else:
            log_name = "load_all"
        log = Path(f"logs/{log_name}_{timestamp}.log")
    logger = setup_logging(log, verbose)

    settings = load_config(config)
    if workers is not None:
        settings.rdb.nworkers = workers

    logger.info(f"Starting load: pipelines={pipelines or []}, limit={limit}")
    run_load(settings, pipelines or [], limit=limit, force=force)
    logger.info("Load completed")


@app.command(name="all")
def run_all(
    config: Annotated[
        Path,
        typer.Option("--config", "-c", help="Config file path"),
    ] = Path("config.yml"),
) -> None:
    """Run full sync and update cycle."""
    from pdbminebuilder.commands.sync import run_sync
    from pdbminebuilder.commands.update import run_update

    settings = load_config(config)
    console.print("[bold blue]Starting full sync and update cycle...[/bold blue]")

    console.print("\n[bold]Phase 1: Sync[/bold]")
    run_sync(settings, [], dry_run=False)

    console.print("\n[bold]Phase 2: Update[/bold]")
    run_update(settings, [])

    console.print("\n[bold green]Full cycle completed![/bold green]")


@app.command(name="setup-rdkit")
def setup_rdkit(
    config: Annotated[
        Path,
        typer.Option("--config", "-c", help="Config file path"),
    ] = Path("config.yml"),
) -> None:
    """Setup RDKit extension and SQL functions.

    Creates RDKit extension, mol column on cc.brief_summary,
    and loads chemical search functions (similar_compounds, substructure_search, etc.).

    This is automatically run by the cc pipeline, but can be run
    independently to add functions to an existing database.
    """
    from pdbminebuilder.pipelines.cc import _ensure_rdkit_setup

    settings = load_config(config)
    console.print("[bold]Setting up RDKit extension and functions...[/bold]")
    _ensure_rdkit_setup(settings.rdb.constring)
    console.print("[bold green]RDKit setup completed![/bold green]")


@app.command()
def test(
    pipelines: Annotated[
        Optional[list[str]],
        typer.Argument(help="Pipelines to test"),
    ] = None,
    config: Annotated[
        Path,
        typer.Option("--config", "-c", help="Config file path"),
    ] = Path("config.test.yml"),
    drop: Annotated[
        bool,
        typer.Option("--drop", "-d", help="Drop existing test database"),
    ] = False,
    limit: Annotated[
        int,
        typer.Option("--limit", "-l", help="Limit number of files to process"),
    ] = 10,
    workers: Annotated[
        Optional[int],
        typer.Option(
            "--workers", "-w", help="Number of worker processes (overrides config)"
        ),
    ] = None,
) -> None:
    """Create test database and validate pipelines."""
    from pdbminebuilder.commands.test import run_test

    settings = load_config(config)
    if workers is not None:
        settings.rdb.nworkers = workers
    run_test(settings, pipelines or [], drop=drop, limit=limit)


@app.command()
def reset(
    schemas: Annotated[
        Optional[list[str]],
        typer.Argument(
            help="Schemas to reset: pdbj, cc, ccmodel, prd, prd_family, vrpt, contacts, emdb, ihm (or 'all')"
        ),
    ] = None,
    config: Annotated[
        Path,
        typer.Option("--config", "-c", help="Config file path"),
    ] = Path("config.yml"),
    force: Annotated[
        bool,
        typer.Option("--force", "-f", help="Skip confirmation prompt"),
    ] = False,
) -> None:
    """Drop and reset database schemas (for testing/reloading).

    Examples:
        pmb reset cc          # Reset cc schema only
        pmb reset cc pdbj     # Reset cc and pdbj schemas
        pmb reset all         # Reset ALL schemas (dangerous!)
        pmb reset all -f      # Reset all without confirmation
    """
    from pdbminebuilder.commands.reset import run_reset

    settings = load_config(config)
    run_reset(settings, schemas or [], force=force)


@app.command()
def query(
    sql: Annotated[
        Optional[str],
        typer.Argument(help="SQL query to execute"),
    ] = None,
    file: Annotated[
        Optional[Path],
        typer.Option("--file", "-f", help="Read SQL from file"),
    ] = None,
    config: Annotated[
        Path,
        typer.Option("--config", "-c", help="Config file path"),
    ] = Path("config.yml"),
    format: Annotated[
        str,
        typer.Option("--format", "-F", help="Output format: table, csv, json, parquet"),
    ] = "table",
    output: Annotated[
        Optional[Path],
        typer.Option("--output", "-o", help="Output file path (required for parquet)"),
    ] = None,
    limit: Annotated[
        Optional[int],
        typer.Option("--limit", "-l", help="Max rows to display (table format only)"),
    ] = None,
) -> None:
    """Execute SQL query and display results.

    Examples:
        pmb query "SELECT * FROM cc.brief_summary LIMIT 5"
        pmb query -f query.sql --format csv > out.csv
        pmb query "SELECT * FROM cc.brief_summary" -F parquet -o out.parquet
        pmb query "SELECT * FROM cc.brief_summary LIMIT 10" -F json
    """
    from pdbminebuilder.commands.query import OutputFormat, run_query

    if sql is None and file is None:
        console.print("[red]Error: provide SQL as argument or use --file.[/red]")
        raise typer.Exit(1)

    if file is not None:
        if not file.exists():
            console.print(f"[red]Error: file not found: {file}[/red]")
            raise typer.Exit(1)
        sql = file.read_text(encoding="utf-8").strip()

    try:
        output_format = OutputFormat(format)
    except ValueError:
        console.print(
            f"[red]Error: invalid format '{format}'. Use: table, csv, json, parquet[/red]"
        )
        raise typer.Exit(1)

    settings = load_config(config)
    run_query(
        settings, sql, output_format=output_format, output_file=output, max_rows=limit
    )


@app.command()
def stats(
    config: Annotated[
        Path,
        typer.Option("--config", "-c", help="Config file path"),
    ] = Path("config.yml"),
) -> None:
    """Show database statistics.

    Displays table counts, row counts, and last update timestamps
    for each schema in the database.
    """
    from pdbminebuilder.commands.stats import run_stats

    settings = load_config(config)
    run_stats(settings)


if __name__ == "__main__":
    app()
