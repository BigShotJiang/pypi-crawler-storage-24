__version__ = "2.1.0"

from .server import mcp as create_server

__all__ = ["create_server"]
