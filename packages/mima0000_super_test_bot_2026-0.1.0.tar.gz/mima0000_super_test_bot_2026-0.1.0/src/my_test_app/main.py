import typer
from rich import print

app = typer.Typer()

@app.command()
def hello(name: str = "朋友"):
    """
    这是一个测试命令
    """
    print(f"[bold green]Hello {name}![/bold green] 你的第一个 PyPI 包运行成功了！")

if __name__ == "__main__":
    app()