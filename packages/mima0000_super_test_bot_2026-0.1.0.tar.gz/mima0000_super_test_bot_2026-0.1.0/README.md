# My Test App
这是一个用来学习 Hatch 和 PyPI 打包的测试项目。
## 安装
`pip install .`
## 使用
`hi --help`