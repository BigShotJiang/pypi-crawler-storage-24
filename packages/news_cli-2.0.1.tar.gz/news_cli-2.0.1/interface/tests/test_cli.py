"""
Tests for the CLI interface — all news fetching is mocked.
"""

import json
from datetime import datetime, timezone
from unittest.mock import patch

from click.testing import CliRunner

from interface.cli.cli import _fmt_date, main
from news.src.google_news import Article

_NOW_ISO = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

FAKE_ARTICLES = [
    Article("Headline One", "Description one", "https://example.com/1", _NOW_ISO),
    Article("Headline Two", "Description two", "https://example.com/2", _NOW_ISO),
]


# ── _fmt_date ────────────────────────────────────────────────────────────────


def test_fmt_date_formats_iso_string():
    assert _fmt_date("2025-06-15T14:30:00Z") == "Jun 15, 2025 14:30"


def test_fmt_date_returns_empty_for_none():
    assert _fmt_date(None) == ""


def test_fmt_date_returns_original_on_invalid():
    assert _fmt_date("not-a-date") == "not-a-date"


# ── --search ─────────────────────────────────────────────────────────────────


def test_search_flag():
    runner = CliRunner()
    with patch("interface.cli.cli.get_keyword_news", return_value=FAKE_ARTICLES):
        result = runner.invoke(main, ["--search", "AI"], input="\n")
    assert result.exit_code == 0
    assert "Headline One" in result.output


def test_search_short_flag():
    runner = CliRunner()
    with patch("interface.cli.cli.get_keyword_news", return_value=FAKE_ARTICLES):
        result = runner.invoke(main, ["-s", "AI"], input="\n")
    assert result.exit_code == 0
    assert "Headline One" in result.output


# ── --country ────────────────────────────────────────────────────────────────


def test_country_flag():
    runner = CliRunner()
    with patch("interface.cli.cli.get_headlines", return_value=FAKE_ARTICLES) as mock_fn:
        result = runner.invoke(main, ["--country", "gb"], input="\n")
    assert result.exit_code == 0
    assert "Headline One" in result.output
    mock_fn.assert_called_once()


def test_country_short_flag():
    runner = CliRunner()
    with patch("interface.cli.cli.get_headlines", return_value=FAKE_ARTICLES):
        result = runner.invoke(main, ["-c", "in"], input="\n")
    assert result.exit_code == 0


# ── --topic ──────────────────────────────────────────────────────────────────


def test_topic_flag():
    runner = CliRunner()
    with patch("interface.cli.cli.get_headlines", return_value=FAKE_ARTICLES):
        result = runner.invoke(main, ["--topic", "technology"], input="\n")
    assert result.exit_code == 0
    assert "Headline One" in result.output


def test_topic_rejects_invalid_value():
    runner = CliRunner()
    with patch("interface.cli.cli.get_headlines", return_value=FAKE_ARTICLES):
        result = runner.invoke(main, ["--topic", "astrology"])
    assert result.exit_code != 0


# ── --search + --country / --topic combined ───────────────────────────────────


def test_search_and_country_combined():
    runner = CliRunner()
    with patch("interface.cli.cli.get_keyword_news", return_value=FAKE_ARTICLES) as mock_fn:
        result = runner.invoke(main, ["--search", "ai", "--country", "gb"], input="\n")
    assert result.exit_code == 0
    call_kwargs = mock_fn.call_args[1]
    assert call_kwargs.get("country") == "gb"


def test_search_and_topic_combined():
    runner = CliRunner()
    with patch("interface.cli.cli.get_keyword_news", return_value=FAKE_ARTICLES) as mock_fn:
        result = runner.invoke(main, ["--search", "ai", "--topic", "health"], input="\n")
    assert result.exit_code == 0
    call_kwargs = mock_fn.call_args[1]
    assert call_kwargs.get("topic") == "health"


# ── --sort ───────────────────────────────────────────────────────────────────


def test_sort_flag_passed_to_keyword_news():
    runner = CliRunner()
    with patch("interface.cli.cli.get_keyword_news", return_value=FAKE_ARTICLES) as mock_fn:
        runner.invoke(main, ["--search", "ai", "--sort", "relevancy"], input="\n")
    assert mock_fn.call_args[1].get("sort") == "relevancy"


def test_sort_rejects_invalid_value():
    runner = CliRunner()
    with patch("interface.cli.cli.get_keyword_news", return_value=FAKE_ARTICLES):
        result = runner.invoke(main, ["--search", "ai", "--sort", "magic"])
    assert result.exit_code != 0


# ── --lang ───────────────────────────────────────────────────────────────────


def test_lang_flag():
    runner = CliRunner()
    with patch("interface.cli.cli.get_keyword_news", return_value=FAKE_ARTICLES):
        result = runner.invoke(main, ["--search", "paris", "--lang", "fr"], input="\n")
    assert result.exit_code == 0


def test_lang_rejects_invalid_code():
    runner = CliRunner()
    with patch("interface.cli.cli.get_headlines", return_value=FAKE_ARTICLES):
        result = runner.invoke(main, ["--lang", "xx"])
    assert result.exit_code != 0


# ── --limit ──────────────────────────────────────────────────────────────────


def test_limit_flag():
    runner = CliRunner()
    with patch("interface.cli.cli.get_headlines", return_value=FAKE_ARTICLES):
        result = runner.invoke(main, ["--limit", "1"], input="\n")
    assert result.exit_code == 0
    assert "Headline One" in result.output
    assert "Headline Two" not in result.output


def test_limit_short_flag():
    runner = CliRunner()
    with patch("interface.cli.cli.get_headlines", return_value=FAKE_ARTICLES):
        result = runner.invoke(main, ["-n", "1"], input="\n")
    assert result.exit_code == 0
    assert "Headline Two" not in result.output


def test_limit_rejects_zero():
    runner = CliRunner()
    with patch("interface.cli.cli.get_headlines", return_value=FAKE_ARTICLES):
        result = runner.invoke(main, ["--limit", "0"])
    assert result.exit_code != 0


def test_limit_rejects_over_100():
    runner = CliRunner()
    with patch("interface.cli.cli.get_headlines", return_value=FAKE_ARTICLES):
        result = runner.invoke(main, ["--limit", "101"])
    assert result.exit_code != 0


# ── --json ───────────────────────────────────────────────────────────────────


def test_json_flag():
    runner = CliRunner()
    with patch("interface.cli.cli.get_headlines", return_value=FAKE_ARTICLES):
        result = runner.invoke(main, ["--json"])
    assert result.exit_code == 0
    data = json.loads(result.output.strip())
    assert data[0]["title"] == "Headline One"
    assert data[0]["url"] == "https://example.com/1"


# ── no-results contextual messages ───────────────────────────────────────────


def test_no_results_with_country_mentions_us_fallback():
    runner = CliRunner()
    with patch("interface.cli.cli.get_headlines", return_value=[]):
        result = runner.invoke(main, ["--country", "in"])
    assert result.exit_code == 0
    # Rich may wrap the line, so check key phrases independently
    assert "country" in result.output
    assert "us" in result.output


def test_no_results_with_search_suggests_broader_terms():
    runner = CliRunner()
    with patch("interface.cli.cli.get_keyword_news", return_value=[]):
        result = runner.invoke(main, ["--search", "xyzzy"])
    assert result.exit_code == 0
    assert "xyzzy" in result.output


def test_no_results_default_suggests_search():
    runner = CliRunner()
    with patch("interface.cli.cli.get_headlines", return_value=[]):
        result = runner.invoke(main, [])
    assert result.exit_code == 0
    assert "--search" in result.output


# ── --sort warning ────────────────────────────────────────────────────────────


def test_sort_warning_shown_with_country():
    runner = CliRunner()
    with patch("interface.cli.cli.get_headlines", return_value=FAKE_ARTICLES):
        result = runner.invoke(main, ["--country", "us", "--sort", "relevancy"], input="\n")
    assert result.exit_code == 0
    assert "ignored" in result.output


def test_sort_warning_not_shown_with_search_only():
    runner = CliRunner()
    with patch("interface.cli.cli.get_keyword_news", return_value=FAKE_ARTICLES):
        result = runner.invoke(main, ["--search", "ai", "--sort", "relevancy"], input="\n")
    assert result.exit_code == 0
    assert "ignored" not in result.output


# ── API error surfaces to user ────────────────────────────────────────────────


def test_api_error_shown_to_user():
    from common.tln_exceptions import TLNException

    runner = CliRunner()
    with patch(
        "interface.cli.cli.get_headlines",
        side_effect=TLNException("Your API key is invalid. (code: apiKeyInvalid)"),
    ):
        result = runner.invoke(main, [])
    assert result.exit_code == 0
    assert "Error:" in result.output
    assert "API key" in result.output


# ── default behaviour ────────────────────────────────────────────────────────


def test_default_uses_get_headlines_with_us():
    runner = CliRunner()
    with patch("interface.cli.cli.get_headlines", return_value=FAKE_ARTICLES) as mock_fn:
        runner.invoke(main, [], input="\n")
    mock_fn.assert_called_once()
    call_kwargs = mock_fn.call_args[1]
    assert call_kwargs.get("country") == "us"
