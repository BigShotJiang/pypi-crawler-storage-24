"""
CLI interface
"""

import json as json_module
import logging
import webbrowser
from datetime import datetime
from typing import Optional

import click
from rich.console import Console
from rich.table import Table

from common.tln_exceptions import TLNException
from news.src.google_news import get_headlines, get_keyword_news

console = Console()

_TOPICS = ["business", "entertainment", "general", "health", "science", "sports", "technology"]
_LANGS = ["ar", "de", "en", "es", "fr", "he", "it", "nl", "no", "pt", "ru", "sv", "zh"]
_SORTS = ["relevancy", "popularity", "date"]


def _fmt_date(iso_str: Optional[str]) -> str:
    """Format an ISO 8601 date string to 'MMM DD, YYYY HH:MM'."""
    if not iso_str:
        return ""
    try:
        dt = datetime.fromisoformat(iso_str.replace("Z", "+00:00"))
        return dt.strftime("%b %d, %Y %H:%M")
    except ValueError:
        return iso_str


def _no_results_hint(search: Optional[str], country: Optional[str], topic: Optional[str]) -> str:
    """Return a contextual hint when the API returns no articles."""
    if country:
        return (
            f"No headlines found for --country [bold]{country}[/bold]. "
            "Your API plan may only support [bold]--country us[/bold]. "
            "Try [bold]--search[/bold] for global keyword search."
        )
    if topic and not search:
        return (
            f"No headlines found for --topic [bold]{topic}[/bold]. "
            "Try adding [bold]--search[/bold] with a keyword."
        )
    if search:
        return (
            f'No results for [bold]"{search}"[/bold]. '
            "Try broader keywords or remove --country/--topic filters."
        )
    return (
        "No articles found. "
        "Try [bold]--search[/bold] for keyword search or [bold]--country us[/bold] for US headlines."  # noqa: E501
    )


@click.command(
    help=(
        "Read the news from your terminal.\n\n"
        "Shows top headlines by default (US, last 7 days). "
        "Use --search for keyword search, --country or --topic to filter."
    )
)
@click.option(
    "-s",
    "--search",
    default=None,
    help="Keywords to search for. Supports AND/OR/NOT, e.g. 'AI AND health'.",
)
@click.option(
    "-c",
    "--country",
    default=None,
    metavar="CODE",
    help="2-letter country code: us, gb, in, fr, de, au, ...",
)
@click.option(
    "-t",
    "--topic",
    default=None,
    type=click.Choice(_TOPICS, case_sensitive=False),
    help="Topic category.",
)
@click.option(
    "-l",
    "--lang",
    default="en",
    show_default=True,
    type=click.Choice(_LANGS, case_sensitive=False),
    help="Article language.",
)
@click.option(
    "--sort",
    default="popularity",
    show_default=True,
    type=click.Choice(_SORTS, case_sensitive=False),
    help="Sort order for --search results (ignored when --country/--topic is set).",
)
@click.option(
    "-n",
    "--limit",
    default=20,
    show_default=True,
    type=click.IntRange(1, 100),
    help="Number of articles to show.",
)
@click.option(
    "--json",
    "output_json",
    is_flag=True,
    default=False,
    help="Output results as JSON for scripting.",
)
@click.option("--verbose", is_flag=True, default=False, help="Enable debug logging.")
def main(
    search: Optional[str],
    country: Optional[str],
    topic: Optional[str],
    lang: str,
    sort: str,
    limit: int,
    output_json: bool,
    verbose: bool,
) -> None:
    if verbose:
        logging.basicConfig(level=logging.DEBUG, format="%(name)s %(levelname)s %(message)s")
    else:
        logging.basicConfig(level=logging.WARNING)

    # Warn about --sort being silently ignored for top-headlines
    if sort != "popularity" and (country is not None or topic is not None):
        console.print(
            f"[yellow]Note:[/yellow] --sort [bold]{sort}[/bold] is ignored when using "
            "--country or --topic (top-headlines doesn't support sorting)."
        )

    try:
        if search is not None:
            result = get_keyword_news(lang, keyword=search, country=country, topic=topic, sort=sort)
        else:
            result = get_headlines(lang, country=country or "us", topic=topic)
    except TLNException as e:
        console.print(f"[red]Error:[/red] {e}")
        return

    result = result[:limit]

    if not result:
        console.print(f"[yellow]{_no_results_hint(search, country, topic)}[/yellow]")
        return

    if output_json:
        articles = [
            {
                "title": r.title,
                "description": r.description,
                "url": r.url,
                "published_at": r.published_at,
            }
            for r in result
        ]
        console.print_json(json_module.dumps(articles))
        return

    table = Table(show_header=True, header_style="bold cyan", show_lines=False)
    table.add_column("#", style="dim", width=4, justify="right")
    table.add_column("Title", no_wrap=False)
    table.add_column("Published", style="dim", width=20)

    url_map = {}
    for i, article in enumerate(result, start=1):
        table.add_row(str(i), article.title or "N/A", _fmt_date(article.published_at))
        url_map[i] = article.url

    console.print(table)

    value = click.prompt(
        "\nOpen article # in browser (press Enter to exit)",
        type=int,
        default=0,
        show_default=False,
    )
    while 0 < value <= len(result):
        article_url = url_map.get(value)
        if article_url:
            webbrowser.open(article_url)
        else:
            console.print("[red]No URL for that article.[/red]")
        value = click.prompt(
            "Open article # in browser (press Enter to exit)",
            type=int,
            default=0,
            show_default=False,
        )

    console.print("[dim]Ciao! Come back for the next bulletin.[/dim]")


if __name__ == "__main__":
    main()
