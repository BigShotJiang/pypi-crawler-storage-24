"""
Get API configuration
"""

import json
import logging
import os

from common.tln_exceptions import TLNException

logger = logging.getLogger(__name__)


def get_api(source: str) -> dict:
    """
    Get API config for the given source. The API key is read from the
    NEWS_API_KEY environment variable (takes precedence over app_settings.json).

    :param source: The service provider (e.g. "newsapi")
    :return: config dict
    :raises TLNException: if source is not found
    """
    with open(os.path.join(os.path.dirname(__file__), "app_settings.json")) as fp:
        data = json.load(fp)

    config = data.get(source)
    if config is None:
        raise TLNException(f"Unknown source '{source}'. Valid sources: {list(data.keys())}")

    # Environment variable takes precedence over the JSON file
    env_key = os.environ.get("NEWS_API_KEY")
    if env_key:
        config = dict(config)
        config["api_key"] = env_key
        logger.debug("Using NEWS_API_KEY from environment")
    elif not config.get("api_key"):
        raise TLNException(
            "No API key found. Set the NEWS_API_KEY environment variable. "
            "Get a free key at https://newsapi.org/register"
        )

    return config
