"""
Fetch news from NewsAPI.org
"""

import logging
import time
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import List, Optional, Tuple

import requests

from common.get_api import get_api
from common.tln_exceptions import TLNException

logger = logging.getLogger(__name__)

MAX_AGE_DAYS = 7

# Fallback sources used when no country or topic is specified
_DEFAULT_SOURCES = "google-news,abc-news,reuters"

# Maps the user-facing --sort value to the NewsAPI sortBy param
SORT_MAP = {
    "relevancy": "relevancy",
    "popularity": "popularity",
    "date": "publishedAt",
}


@dataclass
class Article:
    title: Optional[str]
    description: Optional[str]
    url: Optional[str]
    published_at: Optional[str]


def _make_request(url: str, params: dict) -> requests.Response:
    """GET with exponential backoff for 429/5xx errors (up to 3 attempts)."""
    response = requests.get(url, params=params, timeout=10)
    for attempt in range(1, 3):
        if response.status_code != 429 and response.status_code < 500:
            break
        wait = 2**attempt
        logger.warning(
            "HTTP %s — retrying in %ds (attempt %d/3)",
            response.status_code,
            wait,
            attempt,
        )
        time.sleep(wait)
        response = requests.get(url, params=params, timeout=10)
    return response


def _process_response(data: dict) -> List[Article]:
    """Convert the NewsAPI JSON response into a list of Article objects.

    Raises TLNException if the API returned an error body.
    """
    if data.get("status") == "error":
        code = data.get("code", "unknown")
        message = data.get("message", "Unknown API error")
        raise TLNException(f"{message} (code: {code})")
    return [
        Article(
            title=article.get("title"),
            description=article.get("description"),
            url=article.get("url"),
            published_at=article.get("publishedAt"),
        )
        for article in data.get("articles", [])
    ]


def _week_ago_iso() -> str:
    """ISO 8601 UTC string for exactly MAX_AGE_DAYS days ago."""
    cutoff = datetime.now(timezone.utc) - timedelta(days=MAX_AGE_DAYS)
    return cutoff.strftime("%Y-%m-%dT%H:%M:%SZ")


def _filter_recent(articles: List[Article]) -> List[Article]:
    """Drop articles older than MAX_AGE_DAYS. Articles with no date are excluded."""
    cutoff = datetime.now(timezone.utc) - timedelta(days=MAX_AGE_DAYS)
    kept = []
    for article in articles:
        if not article.published_at:
            continue
        try:
            dt = datetime.fromisoformat(article.published_at.replace("Z", "+00:00"))
            if dt >= cutoff:
                kept.append(article)
        except ValueError:
            kept.append(article)
    return kept


def _base_payload(lang: Optional[str] = None) -> Tuple[dict, str]:
    """Return a (payload, base_url) tuple pre-filled with auth and optional language."""
    api_details = get_api("newsapi")
    payload: dict = {"apiKey": api_details["api_key"]}
    if lang:
        payload["language"] = lang
    return payload, api_details["url"]


def get_headlines(
    lang: str,
    country: Optional[str] = None,
    topic: Optional[str] = None,
) -> List[Article]:
    """
    Fetch current top headlines from the past week.

    Language filtering is skipped when a country is specified — the country
    already scopes the language context and sending language=en would exclude
    non-English headlines (e.g. news -c in would return nothing).

    :param lang: two-letter language code (e.g. "en", "fr")
    :param country: ISO 3166-1 alpha-2 country code (e.g. "us", "gb")
    :param topic: category — business | entertainment | general |
                  health | science | sports | technology
    :return: list of Article objects, empty on error
    """
    # Don't send language when filtering by country — it conflicts
    payload, url = _base_payload(None if country else lang)
    if country:
        payload["country"] = country.lower()
    elif topic:
        payload["category"] = topic.lower()
    else:
        payload["sources"] = _DEFAULT_SOURCES

    try:
        response = _make_request(url + "top-headlines/", payload)
        response.raise_for_status()
        return _filter_recent(_process_response(response.json()))
    except requests.exceptions.HTTPError as e:
        logger.error("API error fetching headlines: %s — %s", e, response.text)
    except requests.exceptions.RequestException as e:
        logger.error("Network error fetching headlines: %s", e)
    return []


def get_keyword_news(
    lang: str,
    keyword: str,
    country: Optional[str] = None,
    topic: Optional[str] = None,
    sort: str = "popularity",
) -> List[Article]:
    """
    Search for articles matching a keyword, limited to the past week.

    When country or topic is provided, uses top-headlines (fast, title-level
    matching). Without either, uses the everything endpoint for full-content
    search across all sources.

    :param lang: two-letter language code
    :param keyword: search term (supports AND/OR/NOT operators)
    :param country: ISO 3166-1 alpha-2 country code
    :param topic: category filter (see get_headlines)
    :param sort: relevancy | popularity | date (ignored for top-headlines)
    :return: list of Article objects, empty on error
    """
    if country or topic:
        # top-headlines: skip language when country is set (same reason as get_headlines)
        path = "top-headlines/"
        payload, url = _base_payload(None if country else lang)
        payload["q"] = keyword
        if country:
            payload["country"] = country.lower()
        elif topic:
            payload["category"] = topic.lower()
        client_filter = True
    else:
        path = "everything/"
        payload, url = _base_payload(lang)
        payload["q"] = keyword
        payload["sortBy"] = SORT_MAP.get(sort, "popularity")
        payload["from"] = _week_ago_iso()
        client_filter = False

    try:
        response = _make_request(url + path, payload)
        response.raise_for_status()
        articles = _process_response(response.json())
        return _filter_recent(articles) if client_filter else articles
    except requests.exceptions.HTTPError as e:
        logger.error("API error fetching keyword news: %s — %s", e, response.text)
    except requests.exceptions.RequestException as e:
        logger.error("Network error fetching keyword news: %s", e)
    return []
