"""
Tests for google_news module — all HTTP calls are mocked.
"""

from datetime import datetime, timedelta, timezone
from unittest.mock import MagicMock, patch

import pytest

from news.src.google_news import (
    Article,
    _filter_recent,
    _week_ago_iso,
    get_headlines,
    get_keyword_news,
)

_NOW_ISO = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
_OLD_ISO = (datetime.now(timezone.utc) - timedelta(days=10)).strftime("%Y-%m-%dT%H:%M:%SZ")

FAKE_ARTICLE = {
    "title": "Test headline",
    "description": "Test description",
    "url": "https://example.com/article",
    "publishedAt": _NOW_ISO,
}

FAKE_RESPONSE_BODY = {"status": "ok", "totalResults": 1, "articles": [FAKE_ARTICLE]}


@pytest.fixture(autouse=True)
def api_key(monkeypatch):
    """Ensure NEWS_API_KEY is set for all tests so get_api() doesn't raise."""
    monkeypatch.setenv("NEWS_API_KEY", "test-key")


def _mock_response(body: dict, status_code: int = 200) -> MagicMock:
    mock = MagicMock()
    mock.status_code = status_code
    mock.json.return_value = body
    mock.raise_for_status.return_value = None
    return mock


# ── Article dataclass ────────────────────────────────────────────────────────


def test_article_has_expected_fields():
    a = Article(
        title="T", description="D", url="https://x.com", published_at="2025-01-01T00:00:00Z"
    )
    assert a.title == "T"
    assert a.description == "D"
    assert a.url == "https://x.com"
    assert a.published_at == "2025-01-01T00:00:00Z"


# ── _filter_recent ───────────────────────────────────────────────────────────


def test_filter_recent_keeps_new_articles():
    recent = Article("T", "D", "https://x.com", _NOW_ISO)
    assert _filter_recent([recent]) == [recent]


def test_filter_recent_drops_old_articles():
    old = Article("T", "D", "https://x.com", _OLD_ISO)
    assert _filter_recent([old]) == []


def test_filter_recent_drops_articles_with_no_date():
    assert _filter_recent([Article("T", "D", "https://x.com", None)]) == []


def test_week_ago_iso_format():
    iso = _week_ago_iso()
    dt = datetime.strptime(iso, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
    delta = datetime.now(timezone.utc) - dt
    assert 6 <= delta.days <= 7


# ── get_headlines ────────────────────────────────────────────────────────────


def test_get_headlines_returns_articles():
    with patch("requests.get", return_value=_mock_response(FAKE_RESPONSE_BODY)):
        headlines = get_headlines("en", country="us")
    assert len(headlines) == 1
    assert headlines[0].title == "Test headline"


def test_get_headlines_passes_country():
    with patch("requests.get", return_value=_mock_response(FAKE_RESPONSE_BODY)) as mock_get:
        get_headlines("en", country="gb")
    params = mock_get.call_args.kwargs.get("params") or mock_get.call_args[1].get("params", {})
    assert params.get("country") == "gb"


def test_get_headlines_passes_topic():
    with patch("requests.get", return_value=_mock_response(FAKE_RESPONSE_BODY)) as mock_get:
        get_headlines("en", topic="technology")
    params = mock_get.call_args.kwargs.get("params") or mock_get.call_args[1].get("params", {})
    assert params.get("category") == "technology"
    assert "country" not in params


def test_get_headlines_falls_back_to_sources_when_no_country_or_topic():
    with patch("requests.get", return_value=_mock_response(FAKE_RESPONSE_BODY)) as mock_get:
        get_headlines("en")
    params = mock_get.call_args.kwargs.get("params") or mock_get.call_args[1].get("params", {})
    assert "sources" in params
    assert "country" not in params
    assert "category" not in params


def test_get_headlines_filters_old_articles():
    old_body = {
        "status": "ok",
        "totalResults": 1,
        "articles": [dict(FAKE_ARTICLE, publishedAt=_OLD_ISO)],
    }
    with patch("requests.get", return_value=_mock_response(old_body)):
        assert get_headlines("en", country="us") == []


def test_get_headlines_raises_on_api_error_body():
    """API returns 200 but with status=error — should raise TLNException."""
    from common.tln_exceptions import TLNException

    error_body = {"status": "error", "code": "apiKeyInvalid", "message": "Your API key is invalid."}
    with patch("requests.get", return_value=_mock_response(error_body)):
        with pytest.raises(TLNException, match="Your API key is invalid."):
            get_headlines("en")


def test_get_headlines_returns_empty_on_http_error():
    import requests as req

    mock = _mock_response({}, status_code=404)
    mock.raise_for_status.side_effect = req.exceptions.HTTPError("404")
    with patch("requests.get", return_value=mock):
        assert get_headlines("en") == []


def test_get_headlines_returns_empty_on_network_error():
    import requests as req

    with patch("requests.get", side_effect=req.exceptions.ConnectionError("no network")):
        assert get_headlines("en") == []


# ── get_keyword_news ─────────────────────────────────────────────────────────


def test_get_keyword_news_returns_articles():
    with patch("requests.get", return_value=_mock_response(FAKE_RESPONSE_BODY)):
        data = get_keyword_news("fr", "coronavirus")
    assert len(data) == 1
    assert data[0].url == "https://example.com/article"


def test_get_keyword_news_uses_everything_without_country_or_topic():
    with patch("requests.get", return_value=_mock_response(FAKE_RESPONSE_BODY)) as mock_get:
        get_keyword_news("en", "python")
    assert "everything" in mock_get.call_args[0][0]


def test_get_keyword_news_everything_passes_from_param():
    with patch("requests.get", return_value=_mock_response(FAKE_RESPONSE_BODY)) as mock_get:
        get_keyword_news("en", "python")
    params = mock_get.call_args.kwargs.get("params") or mock_get.call_args[1].get("params", {})
    assert "from" in params


def test_get_keyword_news_everything_respects_sort():
    with patch("requests.get", return_value=_mock_response(FAKE_RESPONSE_BODY)) as mock_get:
        get_keyword_news("en", "python", sort="relevancy")
    params = mock_get.call_args.kwargs.get("params") or mock_get.call_args[1].get("params", {})
    assert params.get("sortBy") == "relevancy"


def test_get_keyword_news_sort_date_maps_to_publishedat():
    with patch("requests.get", return_value=_mock_response(FAKE_RESPONSE_BODY)) as mock_get:
        get_keyword_news("en", "python", sort="date")
    params = mock_get.call_args.kwargs.get("params") or mock_get.call_args[1].get("params", {})
    assert params.get("sortBy") == "publishedAt"


def test_get_keyword_news_with_country_uses_top_headlines():
    with patch("requests.get", return_value=_mock_response(FAKE_RESPONSE_BODY)) as mock_get:
        get_keyword_news("en", "python", country="gb")
    assert "top-headlines" in mock_get.call_args[0][0]


def test_get_keyword_news_with_topic_uses_top_headlines():
    with patch("requests.get", return_value=_mock_response(FAKE_RESPONSE_BODY)) as mock_get:
        get_keyword_news("en", "python", topic="technology")
    assert "top-headlines" in mock_get.call_args[0][0]


def test_get_keyword_news_top_headlines_no_from_param():
    """top-headlines doesn't support `from` — must not be sent."""
    with patch("requests.get", return_value=_mock_response(FAKE_RESPONSE_BODY)) as mock_get:
        get_keyword_news("en", "python", country="us")
    params = mock_get.call_args.kwargs.get("params") or mock_get.call_args[1].get("params", {})
    assert "from" not in params


def test_get_keyword_news_returns_empty_on_network_error():
    import requests as req

    with patch("requests.get", side_effect=req.exceptions.ConnectionError("no network")):
        assert get_keyword_news("en", "python") == []


# ── Retry logic ──────────────────────────────────────────────────────────────


def test_retry_on_429():
    import requests as req

    rate_limited = _mock_response({}, status_code=429)
    rate_limited.raise_for_status.side_effect = req.exceptions.HTTPError("429")
    success = _mock_response(FAKE_RESPONSE_BODY, status_code=200)

    with patch("requests.get", side_effect=[rate_limited, success]) as mock_get:
        with patch("time.sleep"):
            data = get_keyword_news("en", "test")

    assert mock_get.call_count == 2
    assert len(data) == 1


def test_retry_on_500():
    import requests as req

    server_error = _mock_response({}, status_code=500)
    server_error.raise_for_status.side_effect = req.exceptions.HTTPError("500")
    success = _mock_response(FAKE_RESPONSE_BODY, status_code=200)

    with patch("requests.get", side_effect=[server_error, success]) as mock_get:
        with patch("time.sleep"):
            data = get_keyword_news("en", "test")

    assert mock_get.call_count == 2
    assert len(data) == 1
