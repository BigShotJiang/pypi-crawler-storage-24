# The Local News CLI

Get the latest news straight from your terminal. Powered by [NewsAPI.org](https://newsapi.org).

- Top headlines by country or topic
- Full-text keyword search with `AND`/`OR`/`NOT`
- Articles from the past 7 days only
- Open any article in your browser directly from the CLI

![demo](resources/news-cli_v2.gif)

---

## Install

```bash
pip install news-cli
```

Or with uv:

```bash
uv tool install news-cli
```

---

## Setup

Get a free API key at [newsapi.org/register](https://newsapi.org/register), then set it as an environment variable:

```bash
export NEWS_API_KEY=your_key_here
```

Add that line to your `~/.zshrc` or `~/.bashrc` to make it permanent.

---

## Usage

```
news [OPTIONS]

Options:
  -s, --search TEXT    Keywords to search for. Supports AND/OR/NOT.
  -c, --country TEXT   2-letter country code: us, gb, in, fr, de, au, ...
  -t, --topic TEXT     business | entertainment | general | health |
                       science | sports | technology
  -l, --lang TEXT      Article language: en, fr, de, es, ar, zh, ...  [default: en]
      --sort TEXT      relevancy | popularity | date  [default: popularity]
                       (only applies to --search without --country/--topic)
  -n, --limit INT      Number of articles to show (1–100)  [default: 20]
      --json           Output as JSON for scripting
      --verbose        Enable debug logging
      --help           Show this message and exit
```

---

## Examples

```bash
# Top headlines (defaults to US)
news

# Headlines for a specific country
news --country gb
news -c in

# Headlines by topic
news --topic technology
news -t health

# Search for a keyword
news --search "climate change"
news -s "AI AND regulation"

# Combine: search within a country or topic
news --search "election" --country us
news -s "startup" -t technology

# Filter by language
news --search "économie" --lang fr

# Sort search results by date
news --search "SpaceX" --sort date

# Show more results
news -n 50

# Pipe to jq or other tools
news --json | jq '.[].title'
```

---

## Troubleshooting

**`No API key found`** — set the `NEWS_API_KEY` environment variable (see Setup above).

**`No articles found`** — the combination of filters returned nothing. Try a broader country, drop the topic filter, or change the language.

**Results seem old** — the CLI only shows articles from the past 7 days. For older content, use the NewsAPI directly.
