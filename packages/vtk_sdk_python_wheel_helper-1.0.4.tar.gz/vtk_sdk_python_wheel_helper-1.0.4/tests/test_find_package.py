"""
This creates a venv and does pip install basic_project_sdk in it, then build another project that consummes the sdk
"""

from pathlib import Path
from .venv import VEnv

def test_find_package(virtualenv: VEnv, curdir: Path, wheelhouse: Path, basic_project_sdk):
    test_src = (curdir / "packages" / "find_package").as_posix()
    virtualenv.module(
        "pip", "install", test_src,
        "--find-links", wheelhouse.as_posix(),
        "--no-index",
        "--verbose"
    )
