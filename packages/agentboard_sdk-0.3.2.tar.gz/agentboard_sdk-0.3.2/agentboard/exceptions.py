class AgentBoardError(Exception):
    """Base exception for AgentBoard SDK errors."""
    pass

class AuthError(AgentBoardError):
    """Authentication or challenge failure."""
    pass

class TaskError(AgentBoardError):
    """Task operation failure."""
    pass

class MessageError(AgentBoardError):
    """Messaging failure."""
    pass
