from setuptools import setup, find_packages
import os

# Read README for long description
this_directory = os.path.abspath(os.path.dirname(__file__))
try:
    with open(os.path.join(this_directory, 'README.md'), encoding='utf-8') as f:
        long_description = f.read()
except FileNotFoundError:
    long_description = 'A Python package for thermodynamic cycle modelling'

setup(
    name='Thermosim',                           # ← your PyPI package name
    version='3.0.0',                              # ← NEW version number
    description='A Python package for thermodynamic cycle modelling and analysis',
    long_description=long_description,
    long_description_content_type='text/markdown',
    author='Md. Waheduzzaman Basunia Nouman',                           # ← change to your name
    author_email='md.waheduzzaman.nouman@gmail.com',        # ← change to your email
    url='https://github.com/Nouman090/ThermoSim',  # ← your GitHub URL
    project_urls={
        "Bug Tracker": "https://github.com/Nouman090/ThermoSim/issues",
        "Source": "https://github.com/Nouman090/ThermoSim",
        "Wiki": "https://github.com/Nouman090/ThermoSim/wiki"
    },
    packages=find_packages(exclude=['tests', 'tests.*']),
    include_package_data=True,
    package_data={
        'ThermoSim': ['*.json'],       # include T66.json inside the package
    },
    install_requires=[
        'CoolProp',
        'scipy',
        'matplotlib',
        'numpy',
        'pandas',
    ],
    extras_require={
        'optimization': ['pymoo'],
        'test': ['pytest'],
        'all': ['pymoo', 'pytest'],
    },
    python_requires='>=3.8',
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Science/Research',
        'Intended Audience :: Education',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Topic :: Scientific/Engineering',
        'Topic :: Scientific/Engineering :: Physics',
    ],
    keywords='thermodynamics, rankine, brayton, ORC, power cycle, exergy, CoolProp',
)