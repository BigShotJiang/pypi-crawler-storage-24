from logsentry_agent.run import CircuitBreaker


def test_circuit_breaker_opens_and_blocks_until_cooldown():
    breaker = CircuitBreaker(threshold=2, open_seconds=30, half_open_probe_count=1)
    now = 100.0
    breaker.failure(now)
    assert breaker.state == "closed"
    breaker.failure(now)
    assert breaker.state == "open"
    assert breaker.allow(now + 1) is False


def test_circuit_breaker_half_open_probe_success_closes():
    breaker = CircuitBreaker(threshold=1, open_seconds=10, half_open_probe_count=1)
    breaker.failure(10.0)
    assert breaker.state == "open"
    assert breaker.allow(21.0) is True
    assert breaker.state == "half_open"
    breaker.success()
    assert breaker.state == "closed"
    assert breaker.consecutive_failures == 0


def test_circuit_breaker_half_open_probe_failure_reopens():
    breaker = CircuitBreaker(threshold=1, open_seconds=10, half_open_probe_count=1)
    breaker.failure(10.0)
    assert breaker.allow(21.0) is True
    breaker.failure(21.0)
    assert breaker.state == "open"
    assert breaker.allow(22.0) is False
