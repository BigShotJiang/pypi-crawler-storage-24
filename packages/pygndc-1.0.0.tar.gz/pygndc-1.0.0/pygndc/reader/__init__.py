"""
I/O module for GNDC.

This module provides classes for reading and writing compressed data.
"""

from pygndc.reader.reader import GNDCReader

__all__ = ['GNDCReader']
