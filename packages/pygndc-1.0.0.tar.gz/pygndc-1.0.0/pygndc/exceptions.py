"""
Custom exceptions for pygndc.
"""


class GNDCError(Exception):
    """Base exception for pygndc."""
    pass


class ConfigError(GNDCError):
    """Configuration related errors."""
    pass


class DataLoadError(GNDCError):
    """Data loading errors."""
    pass


class ModelError(GNDCError):
    """Model related errors."""
    pass


class CompressionError(GNDCError):
    """Compression related errors."""
    pass


class DecompressionError(GNDCError):
    """Decompression related errors."""
    pass


class FileFormatError(GNDCError):
    """File format related errors."""
    pass


class DeviceError(GNDCError):
    """Device (GPU/CPU) related errors."""
    pass


class CoordinateError(GNDCError):
    """Coordinate out-of-bounds or transformation errors."""
    pass
