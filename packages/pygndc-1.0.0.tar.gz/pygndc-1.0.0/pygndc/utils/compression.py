"""
Decompression utilities for pygndc reader.
"""

import zstandard as zstd


def fast_decompress(data_bytes):
    """
    Decompress data using ZSTD.

    Args:
        data_bytes: Compressed bytes

    Returns:
        Decompressed bytes
    """
    dctx = zstd.ZstdDecompressor()
    return dctx.decompress(data_bytes)
