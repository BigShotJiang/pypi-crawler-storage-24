"""
Config utilities for pygndc.
"""

import os


SENSOR_CONFIGS = {
    "sentinel2": {
        "n_bands": 10,
        "bands": ["B02", "B03", "B04", "B05", "B06", "B07", "B08", "B8A", "B11", "B12"],
        "resolution": 10,
    },
    "landsat": {
        "n_bands": 7,
        "bands": ["B1", "B2", "B3", "B4", "B5", "B6", "B7"],
        "resolution": 30,
    },
    "modis": {
        "n_bands": 7,
        "bands": ["B1", "B2", "B3", "B4", "B5", "B6", "B7"],
        "resolution": 500,
    },
    "higlass": {
        "n_bands": 1,
        "bands": ["LAI"],
        "resolution": 500,
    },
}


def generate_config_template(sensor: str, output_path: str):
    """
    Generate a configuration template for the specified sensor.
    
    Args:
        sensor: Sensor type (sentinel2, landsat, modis, higlass)
        output_path: Path to save the config file
    """
    import yaml
    
    sensor_info = SENSOR_CONFIGS.get(sensor, SENSOR_CONFIGS["sentinel2"])
    
    config = {
        "project": {
            "name": f"{sensor.upper()} Compression",
            "description": f"Compression configuration for {sensor.upper()} data"
        },
        "paths": {
            "input_folder": "./data/tiffs",
            "output_model": "./output/model.gndc"
        },
        "data": {
            "dataset_mode": "standard",
            "n_bands": sensor_info["n_bands"],
            "global_start_date": "2024-01-01",
            "global_end_date": "2024-12-31",
            "data_scale": 0.1,
            "input_valid_range": [0, 10],
            "input_p99_removal": False
        },
        "training": {
            "epochs": 20,
            "lr": 0.01,
            "use_log": False,
            "cords_norm_mode": 2,
            "force_zero_training": False,
            "train_dtype": "float16",
            "train_loss_type": "MSE",
            "xy_hash_size": 23,
            "xy_base_resolution": 128,
            "xy_n_levels": 12,
            "xy_per_level_scale": 1.41,
            "xy_features_per_level": 4,
            "t_hash_size": 22,
            "t_base_resolution": 64,
            "t_n_levels": 10,
            "t_per_level_scale": 1.5,
            "t_features_per_level": 4,
            "spatial_scale": 0.05,
            "decoder_hidden": 128,
            "n_hidden_layers": 5,
            "enable_deformation": False,
            "ref_t_for_deformation": -1.0
        },
        "output": {
            "quantization_bit": 16,
            "mask_mode": "dynamic",
            "out_dtype": "int8",
            "save_residuals": False,
            "residual_threshold": 0.5,
            "residual_dtype": "int8"
        }
    }
    
    os.makedirs(os.path.dirname(output_path) if os.path.dirname(output_path) else ".", exist_ok=True)
    
    with open(output_path, 'w') as f:
        yaml.dump(config, f, default_flow_style=False, sort_keys=False)
    
    print(f"Config template saved to {output_path}")
