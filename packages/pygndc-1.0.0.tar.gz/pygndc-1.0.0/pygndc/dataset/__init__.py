"""
Dataset module for pygndc.

Provides the high-level GNDCDataset API for GDAL/rasterio-style access.
"""

from pygndc.dataset.dataset import GNDCDataset

__all__ = ["GNDCDataset"]
