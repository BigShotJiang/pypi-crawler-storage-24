"""
Models module for GNDC.

This module provides neural network architectures for geospatial data.
"""
