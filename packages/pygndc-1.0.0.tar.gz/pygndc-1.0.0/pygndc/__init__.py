"""
pygndc - Geographic Neural Data Cube

A Python library for compressing geospatial time-series data using neural networks

Quick Start:
    import pygndc

    # High-level API (recommended)
    with pygndc.open("satellite.gndc") as ds:
        print(ds.crs, ds.bounds, ds.shape)
        frame = ds.read(t=0)                       # (H, W, C)
        frame = ds.read_at_time("2024-06-15")      # continuous interpolation
        ts = ds.sample(lon=116.5, lat=39.9)        # (T, C) point query

    # Low-level API (backward compatible)
    reader = pygndc.GNDCReader()
    reader.load("model.gndc")
    frame = reader.reconstruct_single_frame(0)
"""

# Fix Intel OpenMP conflict
import os
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

from pygndc._version import __version__, __author__, __license__

# Public API - Reader
from pygndc.reader import GNDCReader

# Public API - Dataset (high-level)
from pygndc.dataset import GNDCDataset

# Public API - Analysis
from pygndc.analysis import (
    compute_ndvi,
    compute_evi,
    compute_ndwi,
    compute_ndmi,
    compute_temporal_gradient,
    compute_spatial_gradient
)

# Public API - Viewer
from pygndc.viewer import GNDCInteractiveViewer, start_viewer

def open(path: str, mode: str = "auto") -> GNDCDataset:
    """
    Open a .gndc file and return a GNDCDataset.

    This is the recommended entry point for working with .gndc files.

    Args:
        path: Path to the .gndc file.
        mode: Inference mode.
            - 'auto': auto-detect best available (default)
            - 'tcnn_cuda': tinycudann on GPU (fastest)
            - 'torch_gpu': pure PyTorch on GPU
            - 'torch_cpu': pure PyTorch on CPU

    Returns:
        GNDCDataset instance.

    Examples:
        >>> ds = pygndc.open("data.gndc")
        >>> with pygndc.open("data.gndc", mode="torch_cpu") as ds:
        ...     frame = ds.read(t=0)
    """
    return GNDCDataset(path, mode=mode)


__all__ = [
    # Version info
    "__version__",
    "__author__",
    "__license__",
    # High-level API
    "open",
    "GNDCDataset",
    # Reader
    "GNDCReader",
    # Analysis
    "compute_ndvi",
    "compute_evi",
    "compute_ndwi",
    "compute_ndmi",
    "compute_temporal_gradient",
    "compute_spatial_gradient",
    # Viewer
    "GNDCInteractiveViewer",
    "start_viewer",
]
