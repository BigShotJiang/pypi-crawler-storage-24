"""
pygndc version information.
"""

__version__ = "1.0.0"
__author__ = "Jianbo Qi"
__email__ = "jianboqi@126.com"
__license__ = "MIT"
__url__ = "https://github.com/jianboqi/pygndc"

VERSION = __version__
