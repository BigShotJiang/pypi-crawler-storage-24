"""
Interop module for pygndc.

Provides adapters for rasterio, xarray, and GeoTIFF export.
"""

from pygndc.interop.interop import (
    frame_to_rasterio,
    dataset_to_xarray,
    save_frame_as_tif,
    save_all_tifs,
)

__all__ = [
    "frame_to_rasterio",
    "dataset_to_xarray",
    "save_frame_as_tif",
    "save_all_tifs",
]
