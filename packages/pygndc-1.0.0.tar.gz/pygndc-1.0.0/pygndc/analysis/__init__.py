"""
Analysis module for GNDC.

This module provides functions for analyzing compressed geospatial data,
including vegetation indices and derivatives.
"""

from pygndc.analysis.vegetation import (
    compute_ndvi,
    compute_evi,
    compute_ndwi,
    compute_ndmi,
    compute_temporal_gradient,
    compute_spatial_gradient
)

__all__ = [
    'compute_ndvi',
    'compute_evi',
    'compute_ndwi',
    'compute_ndmi',
    'compute_temporal_gradient',
    'compute_spatial_gradient'
]
