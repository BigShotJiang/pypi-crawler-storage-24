import unittest
from types import SimpleNamespace
from unittest import mock

from paypertranscript.ui.pages.home_page import HomePage


class _FakeLabel:
    def __init__(self) -> None:
        self.text = ""
        self.text_format = None

    def setText(self, value: str) -> None:
        self.text = value

    def setTextFormat(self, value: object) -> None:
        self.text_format = value


class _FakeCard:
    def __init__(self) -> None:
        self.value = None

    def set_value(self, value: str) -> None:
        self.value = value


class _FakeButton:
    def __init__(self) -> None:
        self.enabled = None

    def setEnabled(self, value: bool) -> None:
        self.enabled = value


class _FakeNoSessionLabel:
    def __init__(self) -> None:
        self.visible = None

    def setVisible(self, value: bool) -> None:
        self.visible = value


class _FakeGrid:
    def count(self) -> int:
        return 0

    def takeAt(self, _index: int) -> object:
        return None

    def addWidget(self, *args: object, **kwargs: object) -> None:
        return None


class _FakeConfig:
    def __init__(self) -> None:
        self.calls: list[str] = []
        self.values = {
            "general.hold_hotkey": ["ctrl", "cmd"],
            "general.toggle_hotkey": None,
            "api.stt_model": "whisper-large-v3-turbo",
            "api.llm_model": "openai/gpt-oss-20b",
            "general.language": "en",
        }

    def get(self, key: str, default: object = None) -> object:
        self.calls.append(key)
        return self.values.get(key, default)


class HomePageConfigKeyTests(unittest.TestCase):
    def test_refresh_reads_general_language_key(self) -> None:
        cfg = _FakeConfig()
        page = SimpleNamespace(
            _config=cfg,
            _session_logger=None,
            _get_last_transcription=lambda: None,
            _hotkey_value=_FakeLabel(),
            _model_value=_FakeLabel(),
            _status_value=_FakeLabel(),
            _card_sessions=_FakeCard(),
            _card_cost=_FakeCard(),
            _card_audio=_FakeCard(),
            _recent_grid=_FakeGrid(),
            _btn_copy=_FakeButton(),
            _no_sessions_label=_FakeNoSessionLabel(),
        )

        with mock.patch("paypertranscript.ui.pages.home_page.load_api_key", return_value="api-key"):
            HomePage._refresh(page)

        self.assertIn("general.language", cfg.calls)
        self.assertNotIn("stt.language", cfg.calls)
        self.assertIn("English", page._status_value.text)
