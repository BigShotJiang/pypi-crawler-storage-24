import io
import json
import importlib.util
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from unittest import mock

_SCRIPT_PATH = Path(__file__).resolve().parents[1] / "scripts" / "release.py"
_SPEC = importlib.util.spec_from_file_location("release_script", _SCRIPT_PATH)
release_script = importlib.util.module_from_spec(_SPEC)
assert _SPEC is not None and _SPEC.loader is not None
_SPEC.loader.exec_module(release_script)


class ReleaseScriptTests(unittest.TestCase):
    def test_get_repo_slug_parses_https_and_ssh(self) -> None:
        with mock.patch.object(release_script, "_run", return_value="https://github.com/acme/paypertranscript.git"):
            self.assertEqual(release_script._get_repo_slug(), "acme/paypertranscript")

        with mock.patch.object(release_script, "_run", return_value="git@github.com:acme/paypertranscript.git"):
            self.assertEqual(release_script._get_repo_slug(), "acme/paypertranscript")

        with mock.patch.object(release_script, "_run", return_value="https://example.com/not-github"):
            self.assertIsNone(release_script._get_repo_slug())

    def test_watch_workflow_success_prints_repo_specific_links(self) -> None:
        runs = [
            {
                "databaseId": 123,
                "status": "completed",
                "conclusion": "success",
                "createdAt": "2026-01-01T00:00:00Z",
                "displayTitle": "publish v1.2.3",
            }
        ]

        out = io.StringIO()
        with (
            mock.patch.object(release_script, "_run", return_value=json.dumps(runs)),
            mock.patch.object(release_script.time, "sleep"),
            redirect_stdout(out),
        ):
            release_script._watch_workflow("v1.2.3", "1.2.3", "acme/paypertranscript")

        text = out.getvalue()
        self.assertIn("https://pypi.org/project/PayPerTranscript/1.2.3/", text)
        self.assertIn("https://github.com/acme/paypertranscript/releases/tag/v1.2.3", text)
