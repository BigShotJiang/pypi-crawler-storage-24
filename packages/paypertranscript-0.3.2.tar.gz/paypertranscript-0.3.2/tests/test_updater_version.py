import unittest

from paypertranscript.core import updater


class UpdaterVersionTests(unittest.TestCase):
    def test_pep440_version_comparisons(self) -> None:
        self.assertTrue(updater.is_update_available("0.3.1rc1", "0.3.1"))
        self.assertTrue(updater.is_update_available("0.3.1", "0.3.1.post1"))
        self.assertFalse(updater.is_update_available("0.3.1", "0.3.1rc1"))

    def test_invalid_versions_return_false(self) -> None:
        self.assertFalse(updater.is_update_available("0.3.1", "invalid"))
        self.assertFalse(updater.is_update_available("invalid", "0.3.1"))
