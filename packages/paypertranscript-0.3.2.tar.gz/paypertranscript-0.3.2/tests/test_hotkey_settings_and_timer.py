import unittest
from types import SimpleNamespace
from unittest import mock

from PySide6.QtCore import Qt

from paypertranscript.core.hotkey import HotkeyListener
from paypertranscript.ui.app import PayPerTranscriptApp
from paypertranscript.ui.pages.settings_page import SettingsPage


class _FakeConfig:
    def __init__(self, values: dict[str, object] | None = None) -> None:
        self.values = values or {}
        self.set_calls: list[tuple[str, object]] = []

    def get(self, key: str, default: object = None) -> object:
        return self.values.get(key, default)

    def set(self, key: str, value: object) -> None:
        self.values[key] = value
        self.set_calls.append((key, value))


class _FakeTimer:
    def __init__(self) -> None:
        self.interval = 0
        self._active = False
        self.start_calls = 0
        self.stop_calls = 0

    def setInterval(self, value: int) -> None:
        self.interval = value

    def isActive(self) -> bool:
        return self._active

    def start(self) -> None:
        self._active = True
        self.start_calls += 1

    def stop(self) -> None:
        self._active = False
        self.stop_calls += 1


class HotkeySettingsTimerTests(unittest.TestCase):
    def test_hotkey_listener_disables_toggle_when_none(self) -> None:
        listener = HotkeyListener(
            hold_hotkey=["ctrl", "cmd"],
            toggle_hotkey=["ctrl", "alt"],
            on_hold_start=lambda: None,
            on_hold_stop=lambda: None,
            on_toggle=lambda: None,
        )

        listener.update_hotkeys(toggle_hotkey=None)

        self.assertEqual(listener._toggle_keys, [])
        self.assertEqual(listener._toggle_modifier_groups, [])

    def test_settings_page_toggle_none_updates_listener_immediately(self) -> None:
        cfg = _FakeConfig()
        listener = mock.Mock()
        page = SimpleNamespace(
            _updating=False,
            _config=cfg,
            _hotkey_listener=listener,
        )

        SettingsPage._on_toggle_hotkey_changed(page, 0)

        self.assertIn(("general.toggle_hotkey", None), cfg.set_calls)
        listener.update_hotkeys.assert_called_once_with(toggle_hotkey=None)

    def test_settings_page_update_callbacks_fire(self) -> None:
        cfg = _FakeConfig()
        callback = mock.Mock()
        page = SimpleNamespace(
            _updating=False,
            _config=cfg,
            _on_update_settings_changed=callback,
        )

        SettingsPage._on_auto_update_changed(page, Qt.CheckState.Checked.value)
        SettingsPage._on_interval_changed(page, 6)

        self.assertIn(("updates.auto_update", True), cfg.set_calls)
        self.assertIn(("updates.check_interval_hours", 6), cfg.set_calls)
        self.assertEqual(callback.call_count, 2)

    def test_app_update_timer_reconfigures_live(self) -> None:
        cfg = _FakeConfig({
            "updates.check_interval_hours": "2",
            "updates.auto_update": True,
        })
        timer = _FakeTimer()
        app = SimpleNamespace(_config=cfg, _update_timer=timer)

        PayPerTranscriptApp._apply_update_timer_from_config(app)

        self.assertEqual(timer.interval, 2 * 3600 * 1000)
        self.assertTrue(timer.isActive())
        self.assertEqual(timer.start_calls, 1)

        cfg.values["updates.auto_update"] = False
        cfg.values["updates.check_interval_hours"] = 0
        PayPerTranscriptApp._apply_update_timer_from_config(app)

        self.assertEqual(timer.interval, 1 * 3600 * 1000)
        self.assertFalse(timer.isActive())
        self.assertEqual(timer.stop_calls, 1)
