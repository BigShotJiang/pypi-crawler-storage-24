"""Clipboard-basierte Texteinfuegung fuer PayPerTranscript.

Sichert die Zwischenablage, kopiert den Text, simuliert Ctrl+V,
und stellt die alte Zwischenablage wieder her.
"""

import time
from collections.abc import Iterator

import pyautogui

from paypertranscript.core.clipboard_manager import (
    restore_clipboard,
    set_clipboard_text,
    snapshot_clipboard,
)
from paypertranscript.core.logging import get_logger

log = get_logger("core.text_inserter")

# pyautogui: Kein FAILSAFE (App laeuft im Hintergrund),
# keine Pause zwischen Aktionen (Latenz minimieren)
pyautogui.FAILSAFE = False
pyautogui.PAUSE = 0


# Clipboard-Wiederherstellung: Retry-Konfiguration
_CLIPBOARD_RESTORE_RETRIES = 3
_CLIPBOARD_RESTORE_DELAY = 0.05  # 50ms zwischen Versuchen


def _restore_clipboard(snapshot: object) -> None:
    """Stellt die Zwischenablage wieder her mit Retry-Logik.

    Andere Apps (Clipboard-Manager, Password-Manager) koennen die
    Zwischenablage kurzzeitig sperren. Daher mehrere Versuche.
    """
    for attempt in range(1, _CLIPBOARD_RESTORE_RETRIES + 1):
        if restore_clipboard(snapshot):
            return

        if attempt < _CLIPBOARD_RESTORE_RETRIES:
            time.sleep(_CLIPBOARD_RESTORE_DELAY)
        else:
            log.warning(
                "Zwischenablage konnte nicht wiederhergestellt werden (nach %d Versuchen)",
                _CLIPBOARD_RESTORE_RETRIES,
            )


def insert_text(text: str) -> None:
    """Fuegt Text an der aktuellen Cursor-Position ein.

    Ablauf:
    1. Aktuelle Zwischenablage sichern
    2. Text in Zwischenablage kopieren
    3. Ctrl+V simulieren
    4. 50ms warten (Ziel-App verarbeitet Paste)
    5. Alte Zwischenablage wiederherstellen

    Args:
        text: Der einzufuegende Text.
    """
    if not text:
        log.warning("insert_text aufgerufen mit leerem Text - uebersprungen")
        return

    # 1. Aktuelle Zwischenablage sichern
    old_clipboard = snapshot_clipboard()

    try:
        # 2. Text in Zwischenablage kopieren
        if not set_clipboard_text(text):
            raise RuntimeError("Clipboard konnte nicht beschrieben werden")

        # 3. Ctrl+V simulieren
        pyautogui.hotkey("ctrl", "v")

        # 4. Warten, damit die Ziel-App den Paste verarbeiten kann
        time.sleep(0.05)

        log.info("Text eingefuegt (%d Zeichen)", len(text))

    except Exception as e:
        log.error("Text-Einfuegung fehlgeschlagen: %s", e)
        raise

    finally:
        # 5. Alte Zwischenablage wiederherstellen
        _restore_clipboard(old_clipboard)


# Intervall (Sekunden) zwischen Chunk-Pastes bei Streaming-Typing
_STREAM_INTERVAL = 0.15


def insert_text_streaming(chunks: Iterator[str]) -> str:
    """Fuegt Text chunk-weise an der Cursor-Position ein (Live-Typing).

    Chunks werden gesammelt und in ~150ms-Intervallen per Clipboard+Paste
    eingefuegt. Bei Fehler wird der gesamte gesammelte Text als Fallback
    komplett eingefuegt.

    Args:
        chunks: Iterator der Text-Chunks (z.B. von LLM-Streaming).

    Returns:
        Der insgesamt eingefuegte Text.
    """
    old_clipboard = snapshot_clipboard()

    buffer = ""
    total_inserted = 0
    full_text_parts: list[str] = []

    try:
        last_paste = time.monotonic()
        for chunk in chunks:
            full_text_parts.append(chunk)
            buffer += chunk
            now = time.monotonic()
            if now - last_paste >= _STREAM_INTERVAL and buffer:
                if not set_clipboard_text(buffer):
                    raise RuntimeError("Clipboard konnte nicht beschrieben werden")
                pyautogui.hotkey("ctrl", "v")
                time.sleep(0.05)
                total_inserted += len(buffer)
                buffer = ""
                last_paste = now

        # Restlichen Buffer einfuegen
        if buffer:
            if not set_clipboard_text(buffer):
                raise RuntimeError("Clipboard konnte nicht beschrieben werden")
            pyautogui.hotkey("ctrl", "v")
            time.sleep(0.05)
            total_inserted += len(buffer)

        log.info("Streaming-Text eingefuegt (%d Zeichen)", total_inserted)

    except Exception as e:
        log.error("Streaming-Einfuegung fehlgeschlagen: %s - versuche Fallback", e)
        # Fallback: alles was noch nicht eingefuegt wurde komplett pasten
        if buffer:
            try:
                if set_clipboard_text(buffer):
                    pyautogui.hotkey("ctrl", "v")
                    time.sleep(0.05)
            except Exception:
                log.error("Auch Fallback-Paste fehlgeschlagen")

    finally:
        _restore_clipboard(old_clipboard)

    return "".join(full_text_parts)
