"""Transkriptions-Pipeline fuer PayPerTranscript.

Orchestriert: WAV-Datei -> STT -> (optional) LLM-Formatierung -> Text-Einfuegung.
"""

from __future__ import annotations

import threading
from collections.abc import Callable
from concurrent.futures import Future
from datetime import datetime, timezone
from pathlib import Path

import soundfile as sf

from paypertranscript.core.config import ConfigManager
from paypertranscript.core.cost_tracker import calculate_total_cost
from paypertranscript.core.logging import get_logger
from paypertranscript.core.session_logger import SessionLogger
from paypertranscript.core.text_inserter import insert_text, insert_text_streaming
from paypertranscript.core.window_detector import WindowInfo
from paypertranscript.providers.base import AbstractLLMProvider, AbstractSTTProvider, ProviderError

# Status-Strings fuer on_status Callback
STATUS_STT_START = "stt_start"
STATUS_STT_DONE = "stt_done"
STATUS_LLM_START = "llm_start"
STATUS_DONE = "done"
STATUS_ERROR = "error"
STATUS_LLM_FALLBACK = "llm_fallback"

log = get_logger("pipeline.transcription")

# Halluzinationsfilter: Whisper halluziniert bei kurzen Aufnahmen ohne Sprache
_HALLUCINATION_PATTERNS = [
    "copyright", "untertitel", "subtitles by",
    "thanks for watching", "thank you for watching",
    "sous-titres", "amara.org",
]
_HALLUCINATION_MAX_DURATION = 5.0

# Maximale Zeichen fuer Kontext im LLM-Prompt
_MAX_CONTEXT_CHARS = 2000

# Generischer Prompt fuer den Fall ohne Window-Mapping aber mit markiertem Kontext
_GENERIC_CONTEXT_PROMPT = (
    "Du bist ein Transkriptions-Assistent. "
    "Deine Aufgabe: Gib den transkribierten Text wieder und korrigiere dabei "
    "Schreibweisen von Eigennamen und Fachbegriffen anhand des bereitgestellten Kontexts. "
    "Gib NUR den korrigierten transkribierten Text aus. "
    "Beantworte keine Fragen, fuege keine Erklaerungen hinzu."
)


def _enrich_prompt_with_context(system_prompt: str, selected_text: str) -> str:
    """Reichert einen System-Prompt mit markiertem Kontext-Text an.

    Args:
        system_prompt: Der bestehende System-Prompt.
        selected_text: Markierter Text aus dem aktiven Fenster.

    Returns:
        Angereicherter System-Prompt.
    """
    # Auf maximale Laenge kuerzen
    if len(selected_text) > _MAX_CONTEXT_CHARS:
        selected_text = selected_text[:_MAX_CONTEXT_CHARS]
        log.debug("Kontext auf %d Zeichen gekuerzt", _MAX_CONTEXT_CHARS)

    return (
        f"{system_prompt}\n\n"
        "Der Nutzer hat folgenden Text im aktiven Fenster markiert.\n"
        "Verwende die darin enthaltenen Schreibweisen fuer Eigennamen und Fachbegriffe:\n"
        f"<selected_context>\n{selected_text}\n</selected_context>"
    )


def _is_hallucination(text: str, audio_duration: float) -> bool:
    """Prueft ob ein STT-Ergebnis eine Whisper-Halluzination ist.

    Bei kurzen Aufnahmen (< 5s) ohne Sprache halluziniert Whisper
    stereotypische Strings wie "Copyright Australian Broadcasting Corporation".

    Args:
        text: STT-Ergebnis.
        audio_duration: Audio-Dauer in Sekunden.

    Returns:
        True wenn der Text als Halluzination erkannt wurde.
    """
    if audio_duration >= _HALLUCINATION_MAX_DURATION:
        return False
    text_lower = text.lower()
    return any(pattern in text_lower for pattern in _HALLUCINATION_PATTERNS)


# Maximale Prompt-Laenge fuer Whisper (224 Tokens).
# Konservative Schaetzung: ~4 Zeichen pro Token fuer gemischten DE/EN Text.
_MAX_PROMPT_CHARS = 896


def _build_word_list_prompt(words: list[str]) -> str:
    """Baut den Wortlisten-Prompt fuer Whisper.

    Format: "Korrekte Schreibweisen: Wort1, Wort2, Wort3"
    Wird auf _MAX_PROMPT_CHARS gekuerzt falls noetig.

    Args:
        words: Liste korrekter Schreibweisen.

    Returns:
        Prompt-String oder leerer String wenn keine Woerter.
    """
    if not words:
        return ""

    prefix = "Correct spellings: "
    word_str = ", ".join(words)
    prompt = prefix + word_str

    if len(prompt) > _MAX_PROMPT_CHARS:
        prompt = prompt[:_MAX_PROMPT_CHARS]
        # Am letzten Komma abschneiden (kein halbes Wort)
        last_comma = prompt.rfind(",")
        if last_comma > len(prefix):
            prompt = prompt[:last_comma]
        log.warning(
            "Wortlisten-Prompt gekuerzt auf %d Zeichen (max %d)",
            len(prompt),
            _MAX_PROMPT_CHARS,
        )

    return prompt


class TranscriptionPipeline:
    """Orchestriert die Transkriptions-Pipeline.

    WAV-Datei + WindowInfo -> STT -> (optional) LLM-Formatierung -> Text-Einfuegung.
    """

    def __init__(
        self,
        stt_provider: AbstractSTTProvider,
        config: ConfigManager,
        llm_provider: AbstractLLMProvider | None = None,
        session_logger: SessionLogger | None = None,
    ) -> None:
        self._stt = stt_provider
        self._llm = llm_provider
        self._config = config
        self._session_logger = session_logger
        self.last_transcription: str | None = None
        self.last_wav_path: Path | None = None
        log.info(
            "TranscriptionPipeline initialisiert (LLM: %s, Tracking: %s)",
            "aktiv" if llm_provider else "deaktiviert",
            "aktiv" if session_logger else "deaktiviert",
        )

    def _resolve_formatting(self, window: WindowInfo | None) -> tuple[str | None, str]:
        """Loest Window-Mapping auf und gibt System-Prompt + Kategorie-Key zurueck.

        Matching-Reihenfolge:
        1. Exaktes Match auf process_name (z.B. "WhatsApp.Root.exe")
        2. Substring-Match auf window_title, case-insensitive (z.B. "Gmail" matcht
           "Gmail - Google Chrome"). Erster Treffer gewinnt.

        Args:
            window: Info ueber das aktive Fenster.

        Returns:
            Tuple (system_prompt, category_key). Beide koennen leer/None sein.
        """
        if not window or not window.process_name:
            return None, ""

        mappings: dict[str, str] = self._config.get("formatting.window_mappings", {})

        # 1. Exaktes Match auf Prozessname
        category_key = mappings.get(window.process_name, "")

        # 2. Substring-Match auf Fenstertitel (case-insensitive)
        if not category_key and window.window_title:
            title_lower = window.window_title.lower()
            for pattern, cat_key in mappings.items():
                if pattern.lower() in title_lower:
                    category_key = cat_key
                    log.info(
                        "Window-Mapping (Titel-Match): '%s' in '%s' -> '%s'",
                        pattern,
                        window.window_title,
                        cat_key,
                    )
                    break

        if not category_key:
            return None, ""

        categories: dict = self._config.get("formatting.categories", {})
        category = categories.get(category_key)
        if not category or "prompt" not in category:
            log.warning(
                "Kategorie '%s' fuer '%s' nicht gefunden oder ohne Prompt",
                category_key,
                window.process_name,
            )
            return None, category_key

        log.info(
            "Window-Mapping: %s -> Kategorie '%s'",
            window.process_name,
            category_key,
        )
        return category["prompt"], category_key

    def _log_session(
        self,
        audio_duration: float,
        llm_used: bool,
        llm_input_tokens: int,
        llm_output_tokens: int,
        window: WindowInfo | None,
        category_key: str,
        transcript_text: str = "",
    ) -> None:
        """Berechnet Kosten und loggt die Session in tracking.json."""
        if not self._session_logger or audio_duration <= 0:
            return

        cost = calculate_total_cost(
            audio_duration_seconds=audio_duration,
            llm_input_tokens=llm_input_tokens,
            llm_output_tokens=llm_output_tokens,
            llm_model=self._config.get("api.llm_model", ""),
        )

        session_data = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "audio_duration_seconds": round(cost.audio_duration_seconds, 2),
            "billed_seconds": round(cost.billed_seconds, 2),
            "stt_cost_usd": round(cost.stt_cost_usd, 8),
            "stt_model": self._config.get("api.stt_model", "whisper-large-v3-turbo"),
            "llm_used": llm_used,
            "llm_model": self._config.get("api.llm_model", "openai/gpt-oss-20b") if llm_used else "",
            "llm_input_tokens": llm_input_tokens,
            "llm_output_tokens": llm_output_tokens,
            "llm_cost_usd": round(cost.llm_cost_usd, 8),
            "total_cost_usd": round(cost.total_cost_usd, 8),
            "window_process": window.process_name if window else "",
            "window_title": window.window_title if window else "",
            "category": category_key,
            "language": self._config.get("general.language", "de"),
        }

        if self._config.get("data.save_transcripts", False) and transcript_text:
            session_data["transcript_text"] = transcript_text

        try:
            self._session_logger.log_session(session_data)
        except Exception as e:
            log.warning("Session konnte nicht geloggt werden: %s", e)

    def process(
        self,
        wav_path: Path,
        window: WindowInfo | None = None,
        on_status: Callable[[str], None] | None = None,
        audio_duration: float | None = None,
        context_future: Future[str] | None = None,
    ) -> None:
        """Verarbeitet eine Aufnahme: STT -> (LLM) -> Text-Einfuegung.

        Args:
            wav_path: Pfad zur WAV-Datei.
            window: Info ueber das Fenster bei Aufnahme-Start.
            on_status: Optionaler Callback fuer Status-Updates (UI-Integration).
                       Wird mit STATUS_*-Konstanten aufgerufen.
            audio_duration: Audio-Dauer in Sekunden (fuer Kosten-Tracking).
            context_future: Optionales Future mit markiertem Text aus dem aktiven Fenster.
        """
        def _notify(status: str, detail: str = "") -> None:
            if on_status:
                try:
                    on_status(status, detail)
                except TypeError:
                    try:
                        on_status(status)
                    except Exception:
                        pass
                except Exception:
                    pass

        self.last_wav_path = wav_path
        self.last_transcription = None

        try:
            # Audio-Dauer: entweder uebergeben oder aus WAV-Datei berechnen
            if audio_duration is None:
                try:
                    info = sf.info(str(wav_path))
                    audio_duration = info.duration
                except Exception:
                    audio_duration = 0.0

            # Sprache und Wortliste aus Config
            language = self._config.get("general.language", "de")
            words = self._config.get("words.misspelled_words", [])
            prompt = _build_word_list_prompt(words)

            # STT-Transkription
            log.info("Pipeline: Starte STT fuer %s", wav_path.name)
            _notify(STATUS_STT_START)
            text = self._stt.transcribe(wav_path, language=language, prompt=prompt)
            _notify(STATUS_STT_DONE)

            if not text:
                log.info("Pipeline: STT lieferte leeren Text - uebersprungen")
                _notify(STATUS_ERROR, "Kein Text erkannt")
                return

            if _is_hallucination(text, audio_duration):
                log.info("Pipeline: Halluzination erkannt (%.1fs) - uebersprungen", audio_duration)
                _notify(STATUS_ERROR, "Keine Sprache erkannt")
                return

            # LLM-Formatierung (falls Window-Mapping existiert)
            system_prompt, category_key = self._resolve_formatting(window)

            # Kontext aus Future holen (sollte laengst fertig sein)
            selected_context = ""
            if context_future is not None:
                try:
                    selected_context = context_future.result(timeout=0.5)
                    if selected_context:
                        log.info("Pipeline: Kontext verfuegbar (%d Zeichen)", len(selected_context))
                except Exception as e:
                    log.warning("Pipeline: Context-Future fehlgeschlagen: %s", e)

            # Prompt mit Kontext anreichern
            if selected_context:
                if system_prompt:
                    system_prompt = _enrich_prompt_with_context(system_prompt, selected_context)
                elif self._llm:
                    # Kein Window-Mapping, aber Kontext vorhanden -> generischer LLM-Call
                    system_prompt = _enrich_prompt_with_context(
                        _GENERIC_CONTEXT_PROMPT, selected_context
                    )
                    log.info("Pipeline: Generischer Kontext-Prompt (kein Window-Mapping)")

            llm_used = False
            llm_input_tokens = 0
            llm_output_tokens = 0

            # Helper: Text sicher einfuegen mit Fehlerbehandlung
            insert_ok = True

            def _do_insert(txt: str) -> None:
                nonlocal insert_ok
                self.last_transcription = txt
                try:
                    insert_text(txt)
                except Exception as e:
                    insert_ok = False
                    log.error("Pipeline: Text-Einfuegung fehlgeschlagen: %s", e)
                    _notify(STATUS_ERROR, f"Text-Einfuegung fehlgeschlagen: {e}")

            def _do_insert_stream(chunks_iter: object) -> None:
                nonlocal insert_ok
                try:
                    inserted_text = insert_text_streaming(chunks_iter)
                    self.last_transcription = inserted_text
                except Exception as e:
                    insert_ok = False
                    log.error("Pipeline: Streaming-Einfuegung fehlgeschlagen: %s", e)
                    _notify(STATUS_ERROR, f"Text-Einfuegung fehlgeschlagen: {e}")

            if system_prompt and self._llm:
                _notify(STATUS_LLM_START)
                try:
                    streaming = self._config.get("general.streaming_typing", False)
                    if streaming:
                        log.info("Pipeline: LLM-Formatierung (streaming)")
                        chunks = self._llm.format_text_stream(system_prompt, text)
                        _do_insert_stream(chunks)
                    else:
                        log.info("Pipeline: LLM-Formatierung (non-streaming)")
                        formatted = self._llm.format_text(system_prompt, text)
                        if formatted:
                            text = formatted
                        else:
                            log.warning("Pipeline: LLM lieferte leeren Text - verwende Rohtext")
                        _do_insert(text)

                    llm_used = True
                    usage = self._llm.last_usage
                    if usage:
                        llm_input_tokens = usage.get("prompt_tokens", 0)
                        llm_output_tokens = usage.get("completion_tokens", 0)

                except ProviderError as e:
                    log.warning("Pipeline: LLM-Fehler - Fallback auf Rohtext: %s", e)
                    _notify(STATUS_LLM_FALLBACK, str(e))
                    _do_insert(text)
            else:
                # Kein Mapping oder kein LLM-Provider -> Rohtext direkt einfuegen
                log.info("Pipeline: Fuege Rohtext ein (%d Zeichen)", len(text))
                _do_insert(text)

            if not insert_ok:
                return

            # Kosten berechnen & Session loggen
            self._log_session(
                audio_duration=audio_duration,
                llm_used=llm_used,
                llm_input_tokens=llm_input_tokens,
                llm_output_tokens=llm_output_tokens,
                window=window,
                category_key=category_key,
                transcript_text=self.last_transcription or "",
            )

            _notify(STATUS_DONE)
            log.info(
                "Pipeline: Erfolgreich abgeschlossen fuer %s (Fenster: %s)",
                wav_path.name,
                window.process_name if window else "(unbekannt)",
            )

        except ProviderError as e:
            msg = str(e).split(": ", 1)[0] if ": " in str(e) else str(e)
            log.error("Pipeline: STT-Fehler - %s", e)
            _notify(STATUS_ERROR, msg)
        except Exception as e:
            log.error("Pipeline: Unerwarteter Fehler - %s", e, exc_info=True)
            _notify(STATUS_ERROR, "Unerwarteter Fehler")

    def process_async(
        self,
        wav_path: Path,
        window: WindowInfo | None = None,
        on_status: Callable[[str], None] | None = None,
        audio_duration: float | None = None,
        context_future: Future[str] | None = None,
    ) -> threading.Thread:
        """Startet die Pipeline in einem Hintergrund-Thread.

        Args:
            wav_path: Pfad zur WAV-Datei.
            window: Info ueber das Fenster bei Aufnahme-Start.
            on_status: Optionaler Callback fuer Status-Updates.
            audio_duration: Audio-Dauer in Sekunden (fuer Kosten-Tracking).
            context_future: Optionales Future mit markiertem Text aus dem aktiven Fenster.

        Returns:
            Der gestartete Thread (fuer Tests / Monitoring).
        """
        thread = threading.Thread(
            target=self.process,
            args=(wav_path, window, on_status, audio_duration, context_future),
            daemon=True,
            name="pipeline-worker",
        )
        thread.start()
        log.debug("Pipeline-Thread gestartet fuer %s", wav_path.name)
        return thread
