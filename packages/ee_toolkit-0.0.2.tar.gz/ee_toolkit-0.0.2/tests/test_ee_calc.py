"""
Unit tests for ee-calc.

Run with:
    python -m pytest tests/ -v
"""
import math
import pytest

from ee_toolkit.units      import parse_si, fmt_si
from ee_toolkit.filters    import rc_cutoff, lc_resonance
from ee_toolkit.opamp      import (
    noninv_gain, inv_gain,
    integrator_corner, integrator_gain_at,
    differentiator_corner, differentiator_gain_at,
)
from ee_toolkit.eseries    import find_nearest, decompose
from ee_toolkit.oscillator import lc_resonance as osc_lc   # same formula


# ---------------------------------------------------------------------------
# units
# ---------------------------------------------------------------------------

class TestParseSi:
    def test_kilo(self):        assert parse_si('10k')   == pytest.approx(10_000)
    def test_nano(self):        assert parse_si('100n')  == pytest.approx(100e-9)
    def test_mega(self):        assert parse_si('3.3M')  == pytest.approx(3.3e6)
    def test_micro(self):       assert parse_si('4.7u')  == pytest.approx(4.7e-6)
    def test_pico(self):        assert parse_si('22p')   == pytest.approx(22e-12)
    def test_milli(self):       assert parse_si('1m')    == pytest.approx(1e-3)
    def test_plain(self):       assert parse_si('220')   == pytest.approx(220)
    def test_giga(self):        assert parse_si('1G')    == pytest.approx(1e9)
    def test_float(self):       assert parse_si('4.7k')  == pytest.approx(4700)
    def test_invalid(self):
        with pytest.raises(ValueError):
            parse_si('abc')


class TestFmtSi:
    def test_khz(self):         assert 'k' in fmt_si(15_920, 'Hz')
    def test_mhz(self):         assert 'M' in fmt_si(159.15e6, 'Hz')
    def test_nano(self):        assert 'n' in fmt_si(100e-9, 'F')
    def test_unit_appended(self):
        s = fmt_si(1000, 'Ω')
        assert 'Ω' in s


# ---------------------------------------------------------------------------
# RC filter
# ---------------------------------------------------------------------------

class TestRcCutoff:
    def test_classic(self):
        # R=1k, C=100n → f ≈ 1591.5 Hz
        f = rc_cutoff(1_000, 100e-9)
        assert f == pytest.approx(1 / (2 * math.pi * 1_000 * 100e-9), rel=1e-6)

    def test_10k_100n(self):
        f = rc_cutoff(10_000, 100e-9)
        assert f == pytest.approx(159.15, rel=1e-3)


# ---------------------------------------------------------------------------
# LC filter / oscillator
# ---------------------------------------------------------------------------

class TestLcResonance:
    def test_10u_100p(self):
        # L=10µH C=100pF → f ≈ 159.15 MHz
        f = lc_resonance(10e-6, 100e-12)
        assert f == pytest.approx(159.155e6, rel=1e-3)

    def test_symmetry(self):
        assert lc_resonance(10e-6, 100e-12) == pytest.approx(
            osc_lc(10e-6, 100e-12)
        )


# ---------------------------------------------------------------------------
# Op-amp amplifiers
# ---------------------------------------------------------------------------

class TestOpampGain:
    def test_noninv_x11(self):
        assert noninv_gain(100_000, 10_000) == pytest.approx(11.0)

    def test_noninv_unity(self):
        # Both resistors equal → gain = 2
        assert noninv_gain(10_000, 10_000) == pytest.approx(2.0)

    def test_noninv_buffer_ish(self):
        # Very large Rf, very large R1 – gain still = 1 + Rf/R1
        assert noninv_gain(0, 10_000) == pytest.approx(1.0)

    def test_inv_minus10(self):
        assert inv_gain(100_000, 10_000) == pytest.approx(-10.0)

    def test_inv_unity(self):
        assert inv_gain(10_000, 10_000) == pytest.approx(-1.0)


# ---------------------------------------------------------------------------
# Op-amp integrator
# ---------------------------------------------------------------------------

class TestIntegrator:
    def test_corner_freq(self):
        # R=10k, C=100n → f₀ = 159.15 Hz
        f = integrator_corner(10_000, 100e-9)
        assert f == pytest.approx(159.155, rel=1e-3)

    def test_gain_at_corner(self):
        # At the corner frequency gain magnitude should be 1
        r, c = 10_000, 100e-9
        f0 = integrator_corner(r, c)
        assert integrator_gain_at(r, c, f0) == pytest.approx(1.0, rel=1e-6)

    def test_gain_below_corner(self):
        # At f = f0/10 → gain = 10
        r, c = 10_000, 100e-9
        f0 = integrator_corner(r, c)
        assert integrator_gain_at(r, c, f0 / 10) == pytest.approx(10.0, rel=1e-6)


# ---------------------------------------------------------------------------
# Op-amp differentiator
# ---------------------------------------------------------------------------

class TestDifferentiator:
    def test_corner_freq(self):
        f = differentiator_corner(10_000, 100e-9)
        assert f == pytest.approx(159.155, rel=1e-3)

    def test_gain_at_corner(self):
        r, c = 10_000, 100e-9
        f0 = differentiator_corner(r, c)
        assert differentiator_gain_at(r, c, f0) == pytest.approx(1.0, rel=1e-6)

    def test_gain_above_corner(self):
        # At f = 10·f0 → gain = 10
        r, c = 10_000, 100e-9
        f0 = differentiator_corner(r, c)
        assert differentiator_gain_at(r, c, f0 * 10) == pytest.approx(10.0, rel=1e-6)


# ---------------------------------------------------------------------------
# E-series
# ---------------------------------------------------------------------------

class TestFindNearest:
    def test_exact_e24(self):
        results = find_nearest(10_000, 'E24', 1)
        assert results[0][0] == pytest.approx(10_000)
        assert results[0][1] == pytest.approx(0.0, abs=1e-6)

    def test_nearest_is_closest(self):
        # 10.5k → nearest should be 10k or 11k
        results = find_nearest(10_500, 'E24', 2)
        values = [r[0] for r in results]
        assert any(abs(v - 10_000) < 1 or abs(v - 11_000) < 1 for v in values)

    def test_returns_n_results(self):
        results = find_nearest(10_000, 'E24', 5)
        assert len(results) == 5


class TestDecompose:
    def test_series_sum(self):
        results = decompose(10_500, 'E24', 'series', 3)
        v1, v2, err = results[0]
        actual = v1 + v2
        assert actual == pytest.approx(10_500, rel=0.15)   # within 15 %

    def test_parallel(self):
        results = decompose(4_700, 'E24', 'parallel', 3)
        v1, v2, _ = results[0]
        actual = (v1 * v2) / (v1 + v2)
        assert actual == pytest.approx(4_700, rel=0.15)
