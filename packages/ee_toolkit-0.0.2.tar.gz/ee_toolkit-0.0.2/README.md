# ee-toolkit

[![PyPI - Version](https://img.shields.io/pypi/v/ee-toolkit.svg)](https://pypi.org/project/ee-toolkit)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/ee-toolkit.svg)](https://pypi.org/project/ee-toolkit)

A command-line EE calculator

This is essentially the cli version of many of the online 'electronics' focussed calculators
for all the usual things like filter cutoff frequencies or resonances or resistor approximations

## License

`ee-toolkit` is licensed under the terms of the GPL-v3 license.

## Install

```bash
pip install ee-toolkit
```

## Commands

### `filter`
```bash
ee-calc filter rc --r 10k --c 100n          # RC cutoff
ee-calc filter lc --l 10u --c 100p          # LC resonance
```

### `eseries`
```bash
ee-calc eseries find --value 10.5k                        # nearest E24 values
ee-calc eseries find --value 47n --series E96 --unit F    # E96 capacitor
ee-calc eseries decompose --value 10.5k --combo series    # two-resistor series
ee-calc eseries decompose --value 10.5k --combo parallel  # two-resistor parallel
```

### `oscillator`
```bash
ee-calc oscillator lc --l 10u --c 100p                    # LC tank
ee-calc oscillator colpitts --l 10u --c1 100p --c2 100p   # Colpitts
ee-calc oscillator hartley  --l1 5u  --l2 5u  --c 100p    # Hartley
```

### `opamp`
```bash
ee-calc opamp noninv --rf 100k --r1 10k              # non-inverting gain
ee-calc opamp inv    --rf 100k --r1 10k              # inverting gain
ee-calc opamp integrator    --r 10k --c 100n         # integrator corner freq
ee-calc opamp integrator    --r 10k --c 100n --freq 500   # gain at 500 Hz
ee-calc opamp differentiator --r 10k --c 100n             # differentiator corner freq
ee-calc opamp differentiator --r 10k --c 100n --freq 2k   # gain at 2 kHz
```

## SI prefixes

All value inputs accept SI prefixes: `G M k m u µ n p f`

```
10k  → 10 000
100n → 100 × 10⁻⁹
4.7M → 4 700 000
```

## Run tests

```bash
python -m pytest tests/ -v
```
