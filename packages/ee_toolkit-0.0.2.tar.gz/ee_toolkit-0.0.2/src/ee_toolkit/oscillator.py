"""
Oscillator resonance frequency calculations.

LC oscillator / tank circuit:
  f₀ = 1 / (2π · √(L · C))

Colpitts / Hartley (two reactive elements in series → C_total or L_total):
  Colpitts:  C_eff = (C1 · C2) / (C1 + C2)  → f₀ = 1 / (2π · √(L · C_eff))
  Hartley:   L_eff = L1 + L2                 → f₀ = 1 / (2π · √(L_eff · C))
"""
import math
import click
from .units import parse_si, fmt_si
from .filters import lc_resonance


# ---------------------------------------------------------------------------
# Click command group
# ---------------------------------------------------------------------------

@click.group()
def oscillator_group():
    """Oscillator resonance frequency calculations (LC, Colpitts, Hartley)."""


@oscillator_group.command('lc')
@click.option('--l', 'l_str', required=True, metavar='VALUE',
              help='Inductance, e.g. 10u, 1m')
@click.option('--c', 'c_str', required=True, metavar='VALUE',
              help='Capacitance, e.g. 100p, 10n')
def cmd_lc(l_str, c_str):
    """LC tank oscillator resonance frequency.

    \b
    f₀ = 1 / (2π · √(L · C))

    Example:
      ee-calc oscillator lc --l 10u --c 100p
    """
    l = parse_si(l_str)
    c = parse_si(c_str)
    f = lc_resonance(l, c)
    click.echo("LC oscillator")
    click.echo(f"  L  = {fmt_si(l, 'H')}")
    click.echo(f"  C  = {fmt_si(c, 'F')}")
    click.echo(f"  f₀ = {fmt_si(f, 'Hz')}")
    click.echo(f"  ω₀ = {2*math.pi*f:.6g} rad/s")


@oscillator_group.command('colpitts')
@click.option('--l', 'l_str', required=True, metavar='VALUE',
              help='Inductance, e.g. 10u')
@click.option('--c1', 'c1_str', required=True, metavar='VALUE',
              help='Capacitor 1, e.g. 100p')
@click.option('--c2', 'c2_str', required=True, metavar='VALUE',
              help='Capacitor 2, e.g. 100p')
def cmd_colpitts(l_str, c1_str, c2_str):
    """Colpitts oscillator resonance frequency.

    \b
    C_eff = (C1 · C2) / (C1 + C2)
    f₀    = 1 / (2π · √(L · C_eff))

    Example:
      ee-calc oscillator colpitts --l 10u --c1 100p --c2 100p
    """
    l  = parse_si(l_str)
    c1 = parse_si(c1_str)
    c2 = parse_si(c2_str)
    c_eff = (c1 * c2) / (c1 + c2)
    f = lc_resonance(l, c_eff)
    click.echo("Colpitts oscillator")
    click.echo(f"  L     = {fmt_si(l, 'H')}")
    click.echo(f"  C1    = {fmt_si(c1, 'F')}")
    click.echo(f"  C2    = {fmt_si(c2, 'F')}")
    click.echo(f"  C_eff = {fmt_si(c_eff, 'F')}  (series combination)")
    click.echo(f"  f₀    = {fmt_si(f, 'Hz')}")


@oscillator_group.command('hartley')
@click.option('--l1', 'l1_str', required=True, metavar='VALUE',
              help='Inductor 1, e.g. 5u')
@click.option('--l2', 'l2_str', required=True, metavar='VALUE',
              help='Inductor 2, e.g. 5u')
@click.option('--c', 'c_str', required=True, metavar='VALUE',
              help='Capacitance, e.g. 100p')
def cmd_hartley(l1_str, l2_str, c_str):
    """Hartley oscillator resonance frequency.

    \b
    L_eff = L1 + L2
    f₀    = 1 / (2π · √(L_eff · C))

    Example:
      ee-calc oscillator hartley --l1 5u --l2 5u --c 100p
    """
    l1 = parse_si(l1_str)
    l2 = parse_si(l2_str)
    c  = parse_si(c_str)
    l_eff = l1 + l2
    f = lc_resonance(l_eff, c)
    click.echo("Hartley oscillator")
    click.echo(f"  L1    = {fmt_si(l1, 'H')}")
    click.echo(f"  L2    = {fmt_si(l2, 'H')}")
    click.echo(f"  L_eff = {fmt_si(l_eff, 'H')}  (series combination)")
    click.echo(f"  C     = {fmt_si(c, 'F')}")
    click.echo(f"  f₀    = {fmt_si(f, 'Hz')}")
