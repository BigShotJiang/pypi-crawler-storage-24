"""EE Calculator – a collection of common electrical engineering calculations."""

__version__ = "0.1.0"
