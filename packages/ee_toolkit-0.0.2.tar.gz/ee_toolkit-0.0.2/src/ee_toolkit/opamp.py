"""
Op-amp circuit calculations.

Amplifiers
----------
  Non-inverting:  Gain = 1 + Rf / R1
  Inverting:      Gain = -(Rf / R1)

Integrator  (inverting)
-----------------------
  Corner frequency:  f = 1 / (2π · R · C)
  Gain at frequency: |A(f)| = 1 / (2π · f · R · C)   [no DC description – ideal]

Differentiator  (inverting)
---------------------------
  Corner frequency:  f = 1 / (2π · R · C)
  Gain at frequency: |A(f)| = 2π · f · R · C
"""
import math
import click
from .units import parse_si, fmt_si


# ---------------------------------------------------------------------------
# Pure math helpers
# ---------------------------------------------------------------------------

def noninv_gain(rf: float, r1: float) -> float:
    """Non-inverting amplifier closed-loop gain."""
    return 1.0 + rf / r1


def inv_gain(rf: float, r1: float) -> float:
    """Inverting amplifier closed-loop gain (negative = phase-inverting)."""
    return -(rf / r1)


def integrator_corner(r: float, c: float) -> float:
    """Integrator corner frequency (Hz) — same as RC cutoff."""
    return 1.0 / (2.0 * math.pi * r * c)


def integrator_gain_at(r: float, c: float, freq: float) -> float:
    """Ideal integrator magnitude gain at *freq* Hz."""
    return 1.0 / (2.0 * math.pi * freq * r * c)


def differentiator_corner(r: float, c: float) -> float:
    """Differentiator corner frequency (Hz)."""
    return 1.0 / (2.0 * math.pi * r * c)


def differentiator_gain_at(r: float, c: float, freq: float) -> float:
    """Ideal differentiator magnitude gain at *freq* Hz."""
    return 2.0 * math.pi * freq * r * c


# ---------------------------------------------------------------------------
# Click command group
# ---------------------------------------------------------------------------

@click.group()
def opamp_group():
    """Op-amp circuit calculations (gain, integrator, differentiator)."""


# ── Non-inverting amplifier ─────────────────────────────────────────────────
@opamp_group.command('noninv')
@click.option('--rf', 'rf_str', required=True, metavar='VALUE',
              help='Feedback resistor, e.g. 100k')
@click.option('--r1', 'r1_str', required=True, metavar='VALUE',
              help='Input/ground resistor, e.g. 10k')
def cmd_noninv(rf_str, r1_str):
    """Non-inverting amplifier closed-loop gain.

    \b
    Gain = 1 + Rf / R1

    Example:
      ee-calc opamp noninv --rf 100k --r1 10k   →  Gain = +11
    """
    rf = parse_si(rf_str)
    r1 = parse_si(r1_str)
    g = noninv_gain(rf, r1)
    click.echo("Non-inverting amplifier")
    click.echo(f"  Rf  = {fmt_si(rf, 'Ω')}")
    click.echo(f"  R1  = {fmt_si(r1, 'Ω')}")
    click.echo(f"  Gain = 1 + Rf/R1 = {g:.6g}  ({20*math.log10(abs(g)):.2f} dB)")


# ── Inverting amplifier ─────────────────────────────────────────────────────
@opamp_group.command('inv')
@click.option('--rf', 'rf_str', required=True, metavar='VALUE',
              help='Feedback resistor, e.g. 100k')
@click.option('--r1', 'r1_str', required=True, metavar='VALUE',
              help='Input resistor, e.g. 10k')
def cmd_inv(rf_str, r1_str):
    """Inverting amplifier closed-loop gain.

    \b
    Gain = -(Rf / R1)

    Example:
      ee-calc opamp inv --rf 100k --r1 10k   →  Gain = -10
    """
    rf = parse_si(rf_str)
    r1 = parse_si(r1_str)
    g = inv_gain(rf, r1)
    click.echo("Inverting amplifier")
    click.echo(f"  Rf   = {fmt_si(rf, 'Ω')}")
    click.echo(f"  R1   = {fmt_si(r1, 'Ω')}")
    click.echo(f"  Gain = -(Rf/R1) = {g:.6g}  ({20*math.log10(abs(g)):.2f} dB)")


# ── Integrator ──────────────────────────────────────────────────────────────
@opamp_group.command('integrator')
@click.option('--r', 'r_str', required=True, metavar='VALUE',
              help='Input resistor, e.g. 10k')
@click.option('--c', 'c_str', required=True, metavar='VALUE',
              help='Feedback capacitor, e.g. 100n')
@click.option('--freq', 'freq_str', default=None, metavar='VALUE',
              help='Optional: evaluate gain magnitude at this frequency, e.g. 1k')
def cmd_integrator(r_str, c_str, freq_str):
    """Inverting op-amp integrator.

    \b
    Corner frequency:  f₀ = 1 / (2π · R · C)
    Gain magnitude:   |A(f)| = 1 / (2π · f · R · C)  =  f₀ / f

    Example:
      ee-calc opamp integrator --r 10k --c 100n
      ee-calc opamp integrator --r 10k --c 100n --freq 500
    """
    r = parse_si(r_str)
    c = parse_si(c_str)
    f0 = integrator_corner(r, c)
    click.echo("Inverting integrator")
    click.echo(f"  R  = {fmt_si(r, 'Ω')}")
    click.echo(f"  C  = {fmt_si(c, 'F')}")
    click.echo(f"  Corner frequency f₀ = {fmt_si(f0, 'Hz')}")
    click.echo(f"  (Unity-gain frequency where |A| = 1)")
    if freq_str:
        freq = parse_si(freq_str)
        gain = integrator_gain_at(r, c, freq)
        click.echo(f"\n  At f = {fmt_si(freq, 'Hz')}:")
        click.echo(f"    |A| = {gain:.6g}  ({20*math.log10(gain):.2f} dB)")


# ── Differentiator ──────────────────────────────────────────────────────────
@opamp_group.command('differentiator')
@click.option('--r', 'r_str', required=True, metavar='VALUE',
              help='Feedback resistor, e.g. 10k')
@click.option('--c', 'c_str', required=True, metavar='VALUE',
              help='Input capacitor, e.g. 100n')
@click.option('--freq', 'freq_str', default=None, metavar='VALUE',
              help='Optional: evaluate gain magnitude at this frequency, e.g. 1k')
def cmd_differentiator(r_str, c_str, freq_str):
    """Inverting op-amp differentiator.

    \b
    Corner frequency:  f₀ = 1 / (2π · R · C)
    Gain magnitude:   |A(f)| = 2π · f · R · C  =  f / f₀

    Example:
      ee-calc opamp differentiator --r 10k --c 100n
      ee-calc opamp differentiator --r 10k --c 100n --freq 2k
    """
    r = parse_si(r_str)
    c = parse_si(c_str)
    f0 = differentiator_corner(r, c)
    click.echo("Inverting differentiator")
    click.echo(f"  R  = {fmt_si(r, 'Ω')}")
    click.echo(f"  C  = {fmt_si(c, 'F')}")
    click.echo(f"  Corner frequency f₀ = {fmt_si(f0, 'Hz')}")
    click.echo(f"  (Unity-gain frequency where |A| = 1)")
    if freq_str:
        freq = parse_si(freq_str)
        gain = differentiator_gain_at(r, c, freq)
        click.echo(f"\n  At f = {fmt_si(freq, 'Hz')}:")
        click.echo(f"    |A| = {gain:.6g}  ({20*math.log10(gain):.2f} dB)")
