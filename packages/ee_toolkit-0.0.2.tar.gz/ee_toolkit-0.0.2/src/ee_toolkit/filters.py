"""
Filter cutoff / resonance frequency calculations.

RC filter:    f = 1 / (2π · R · C)
LC filter:    f = 1 / (2π · √(L · C))
RC band-pass: two cascaded RC stages (HPF + LPF)
"""
import math
from .units import parse_si, fmt_si


def rc_cutoff(r: float, c: float) -> float:
    """Return the -3 dB cutoff frequency of an RC filter (Hz)."""
    return 1.0 / (2.0 * math.pi * r * c)


def lc_resonance(l: float, c: float) -> float:
    """Return the resonance frequency of an LC network (Hz)."""
    return 1.0 / (2.0 * math.pi * math.sqrt(l * c))


def rc_bandpass(r_hp: float, c_hp: float, r_lp: float, c_lp: float):
    """Return (f_low, f_high, f_centre, bandwidth) for a two-stage RC band-pass.

    The high-pass stage (R_hp, C_hp) sets the lower -3 dB edge;
    the low-pass stage (R_lp, C_lp) sets the upper -3 dB edge.
    """
    f_low  = rc_cutoff(r_hp, c_hp)
    f_high = rc_cutoff(r_lp, c_lp)
    if f_low > f_high:
        raise ValueError(
            f"High-pass cutoff ({f_low:.3g} Hz) must be lower than "
            f"low-pass cutoff ({f_high:.3g} Hz)."
        )
    f_centre   = math.sqrt(f_low * f_high)
    bandwidth  = f_high - f_low
    return f_low, f_high, f_centre, bandwidth


# ---------------------------------------------------------------------------
# Click commands
# ---------------------------------------------------------------------------
import click


@click.group()
def filter_group():
    """Filter frequency calculations (RC, LC, RC band-pass)."""


@filter_group.command('rc')
@click.option('--r', 'r_str', required=True, metavar='VALUE',
              help='Resistance, e.g. 10k, 4.7M, 220')
@click.option('--c', 'c_str', required=True, metavar='VALUE',
              help='Capacitance, e.g. 100n, 10u, 220p')
@click.option('--type', 'ftype', default='low',
              type=click.Choice(['low', 'high'], case_sensitive=False),
              show_default=True, help='Filter type (informational).')
def cmd_rc(r_str, c_str, ftype):
    """RC filter -3 dB cutoff frequency.

    \b
    f = 1 / (2π · R · C)

    Example:
      ee-calc filter rc --r 10k --c 100n
    """
    r = parse_si(r_str)
    c = parse_si(c_str)
    f = rc_cutoff(r, c)
    click.echo(f"RC {ftype}-pass filter")
    click.echo(f"  R = {fmt_si(r, 'Ω')}")
    click.echo(f"  C = {fmt_si(c, 'F')}")
    click.echo(f"  Cutoff frequency f₋₃dB = {fmt_si(f, 'Hz')}")


@filter_group.command('lc')
@click.option('--l', 'l_str', required=True, metavar='VALUE',
              help='Inductance, e.g. 10u, 1m, 470n')
@click.option('--c', 'c_str', required=True, metavar='VALUE',
              help='Capacitance, e.g. 100p, 10n, 1u')
def cmd_lc(l_str, c_str):
    """LC filter resonance frequency.

    \b
    f = 1 / (2π · √(L · C))

    Example:
      ee-calc filter lc --l 10u --c 100p
    """
    l = parse_si(l_str)
    c = parse_si(c_str)
    f = lc_resonance(l, c)
    click.echo("LC filter / resonator")
    click.echo(f"  L = {fmt_si(l, 'H')}")
    click.echo(f"  C = {fmt_si(c, 'F')}")
    click.echo(f"  Resonance frequency f₀ = {fmt_si(f, 'Hz')}")

@filter_group.command('bp')
@click.option('--r1', 'r1_str', required=True, metavar='VALUE',
              help='High-pass resistance, e.g. 10k')
@click.option('--c1', 'c1_str', required=True, metavar='VALUE',
              help='High-pass capacitance, e.g. 100n')
@click.option('--r2', 'r2_str', required=True, metavar='VALUE',
              help='Low-pass resistance, e.g. 10k')
@click.option('--c2', 'c2_str', required=True, metavar='VALUE',
              help='Low-pass capacitance, e.g. 10n')
def cmd_bp(r1_str, c1_str, r2_str, c2_str):
    """RC band-pass filter (cascaded high-pass + low-pass stages).

    \b
    f_low  = 1 / (2π · R1 · C1)   ← high-pass edge
    f_high = 1 / (2π · R2 · C2)   ← low-pass edge
    f₀     = √(f_low · f_high)    ← geometric centre
    BW     = f_high − f_low

    Example:
      ee-calc filter bp --r1 10k --c1 100n --r2 10k --c2 10n
    """
    r1 = parse_si(r1_str)
    c1 = parse_si(c1_str)
    r2 = parse_si(r2_str)
    c2 = parse_si(c2_str)
    try:
        f_low, f_high, f_centre, bw = rc_bandpass(r1, c1, r2, c2)
    except ValueError as exc:
        raise click.UsageError(str(exc)) from exc
    click.echo("RC band-pass filter")
    click.echo(f"  High-pass stage  R1 = {fmt_si(r1, 'Ω')},  C1 = {fmt_si(c1, 'F')}")
    click.echo(f"  Low-pass  stage  R2 = {fmt_si(r2, 'Ω')},  C2 = {fmt_si(c2, 'F')}")
    click.echo(f"  Lower edge  f_low  = {fmt_si(f_low,    'Hz')}")
    click.echo(f"  Upper edge  f_high = {fmt_si(f_high,   'Hz')}")
    click.echo(f"  Centre freq f₀     = {fmt_si(f_centre, 'Hz')}")
    click.echo(f"  Bandwidth   BW     = {fmt_si(bw,       'Hz')}")
