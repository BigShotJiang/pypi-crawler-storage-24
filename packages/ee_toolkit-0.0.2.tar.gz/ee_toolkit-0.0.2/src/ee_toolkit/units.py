"""
Shared utilities: SI prefix parsing and pretty-printing.
"""
import re

_PREFIX_MAP = {
    'G': 1e9,
    'M': 1e6,
    'k': 1e3,
    'K': 1e3,
    '':  1.0,
    'm': 1e-3,
    'u': 1e-6,
    'µ': 1e-6,
    'n': 1e-9,
    'p': 1e-12,
    'f': 1e-15,
}

_SI_SCALE = [
    (1e9,  'G'),
    (1e6,  'M'),
    (1e3,  'k'),
    (1.0,  ''),
    (1e-3, 'm'),
    (1e-6, 'µ'),
    (1e-9, 'n'),
    (1e-12,'p'),
]

_UNIT_RE = re.compile(
    r'^\s*([+-]?[0-9]*\.?[0-9]+(?:[eE][+-]?[0-9]+)?)'
    r'\s*([GMkKmuµnpf]?)\s*$'
)


def parse_si(text: str) -> float:
    """
    Parse a string with an optional SI prefix into a float.

    Examples
    --------
    >>> parse_si('10k')   # 10 000
    10000.0
    >>> parse_si('100n')  # 100e-9
    1e-07
    >>> parse_si('3.3M')  # 3 300 000
    3300000.0
    """
    m = _UNIT_RE.match(text)
    if not m:
        raise ValueError(
            f"Cannot parse '{text}' – expected a number with an optional SI prefix "
            "(G M k m u µ n p f)."
        )
    number = float(m.group(1))
    prefix = m.group(2)
    return number * _PREFIX_MAP[prefix]


def fmt_si(value: float, unit: str = '', decimals: int = 4) -> str:
    """
    Format *value* with an SI prefix and optional unit string.

    Examples
    --------
    >>> fmt_si(15920.0, 'Hz')
    '15.92 kHz'
    >>> fmt_si(1e-9, 'F')
    '1.0 nF'
    """
    for scale, prefix in _SI_SCALE:
        if abs(value) >= scale:
            return f"{value / scale:.{decimals}g} {prefix}{unit}"
    # Fallback for very small values
    scale, prefix = _SI_SCALE[-1]
    return f"{value / scale:.{decimals}g} {prefix}{unit}"
