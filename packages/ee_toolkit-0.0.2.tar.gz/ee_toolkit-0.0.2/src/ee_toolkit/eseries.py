"""
E-series resistor / capacitor standard value look-up.

Supported series: E12, E24, E48, E96, E192
"""
import math
from typing import List, Tuple, Literal
import click
from .units import parse_si, fmt_si


# ---------------------------------------------------------------------------
# E-series base values (one decade, 3 significant figures)
# ---------------------------------------------------------------------------

_E12 = [1.0, 1.2, 1.5, 1.8, 2.2, 2.7, 3.3, 3.9, 4.7, 5.6, 6.8, 8.2]

_E24 = [
    1.0, 1.1, 1.2, 1.3, 1.5, 1.6, 1.8, 2.0, 2.2, 2.4, 2.7, 3.0,
    3.3, 3.6, 3.9, 4.3, 4.7, 5.1, 5.6, 6.2, 6.8, 7.5, 8.2, 9.1,
]

_E48 = [
    1.00, 1.05, 1.10, 1.15, 1.21, 1.27, 1.33, 1.40, 1.47, 1.54, 1.62, 1.69,
    1.78, 1.87, 1.96, 2.05, 2.15, 2.26, 2.37, 2.49, 2.61, 2.74, 2.87, 3.01,
    3.16, 3.32, 3.48, 3.65, 3.83, 4.02, 4.22, 4.42, 4.64, 4.87, 5.11, 5.36,
    5.62, 5.90, 6.19, 6.49, 6.81, 7.15, 7.50, 7.87, 8.25, 8.66, 9.09, 9.53,
]

_E96 = [
    1.00, 1.02, 1.05, 1.07, 1.10, 1.13, 1.15, 1.18, 1.21, 1.24, 1.27, 1.30,
    1.33, 1.37, 1.40, 1.43, 1.47, 1.50, 1.54, 1.58, 1.62, 1.65, 1.69, 1.74,
    1.78, 1.82, 1.87, 1.91, 1.96, 2.00, 2.05, 2.10, 2.15, 2.21, 2.26, 2.32,
    2.37, 2.43, 2.49, 2.55, 2.61, 2.67, 2.74, 2.80, 2.87, 2.94, 3.01, 3.09,
    3.16, 3.24, 3.32, 3.40, 3.48, 3.57, 3.65, 3.74, 3.83, 3.92, 4.02, 4.12,
    4.22, 4.32, 4.42, 4.53, 4.64, 4.75, 4.87, 4.99, 5.11, 5.23, 5.36, 5.49,
    5.62, 5.76, 5.90, 6.04, 6.19, 6.34, 6.49, 6.65, 6.81, 6.98, 7.15, 7.32,
    7.50, 7.68, 7.87, 8.06, 8.25, 8.45, 8.66, 8.87, 9.09, 9.31, 9.53, 9.76,
]

# E192 computed from IEC 60063 formula: round(10^(i/192), 2 sig figs)
def _make_e192() -> List[float]:
    vals = []
    for i in range(192):
        raw = 10 ** (i / 192)
        # round to 3 significant figures
        mag = math.floor(math.log10(raw))
        rounded = round(raw / 10**mag, 2) * 10**mag
        vals.append(round(rounded, 6))
    return vals

_E192 = _make_e192()

SERIES = {
    'E12':  _E12,
    'E24':  _E24,
    'E48':  _E48,
    'E96':  _E96,
    'E192': _E192,
}


def all_values(series: str) -> List[float]:
    """Return all standard values across all decades (1Ω … 10MΩ typical)."""
    base = SERIES[series.upper()]
    result = []
    for exp in range(-2, 8):       # 0.01 … 10 000 000
        for b in base:
            result.append(round(b * (10 ** exp), 12))
    return sorted(result)


def find_nearest(target: float, series: str, n: int = 3) -> List[Tuple[float, float]]:
    """
    Return the *n* closest standard values to *target* (value, error_pct).
    """
    candidates = all_values(series)
    ranked = sorted(candidates, key=lambda v: abs(v - target))[:n]
    return [(v, (v - target) / target * 100) for v in ranked]


def decompose(
    target: float,
    series: str,
    mode: Literal['series', 'parallel'],
    n_results: int = 5,
) -> List[Tuple[float, float, float]]:
    """
    Find the best two-component (series or parallel) combination from *series*
    that approximates *target*.

    Returns list of (v1, v2, error_pct) sorted by |error|.
    """
    base_vals = all_values(series)
    # Limit search space: only values within a factor of target
    lo, hi = target * 0.001, target * 1000
    candidates = [v for v in base_vals if lo <= v <= hi]

    results = []
    seen = set()

    for v1 in candidates:
        if mode == 'series':
            v2_ideal = target - v1
        else:  # parallel
            if v1 == target:
                continue
            v2_ideal = (target * v1) / (v1 - target)

        if v2_ideal <= 0:
            continue

        # Find nearest E-series value for v2
        nearest = min(candidates, key=lambda v: abs(v - v2_ideal))
        v2 = nearest

        if mode == 'series':
            actual = v1 + v2
        else:
            actual = (v1 * v2) / (v1 + v2)

        err = (actual - target) / target * 100
        key = (round(min(v1, v2), 12), round(max(v1, v2), 12))
        if key not in seen:
            seen.add(key)
            results.append((v1, v2, err))

    results.sort(key=lambda x: abs(x[2]))
    return results[:n_results]


# ---------------------------------------------------------------------------
# Click commands
# ---------------------------------------------------------------------------

_SERIES_CHOICE = click.Choice(['E12', 'E24', 'E48', 'E96', 'E192'],
                               case_sensitive=False)


@click.group()
def eseries_group():
    """E-series standard value look-up (E12 … E192)."""


@eseries_group.command('find')
@click.option('--value', 'val_str', required=True, metavar='VALUE',
              help='Target value, e.g. 10.5k, 220, 4.7M')
@click.option('--series', default='E24', show_default=True,
              type=_SERIES_CHOICE, help='E-series to search.')
@click.option('-n', 'n', default=3, show_default=True,
              help='Number of nearest values to show.')
@click.option('--unit', default='Ω', show_default=True,
              help='Unit label for display (Ω, F, H…)')
def cmd_find(val_str, series, n, unit):
    """Find the closest E-series standard values to a target.

    \b
    Example:
      ee-calc eseries find --value 10.5k
      ee-calc eseries find --value 47n --series E48 --unit F
    """
    target = parse_si(val_str)
    results = find_nearest(target, series, n)
    click.echo(f"Target : {fmt_si(target, unit)}  (series {series.upper()})")
    click.echo(f"{'Rank':<5} {'Value':<14} {'Error':>8}")
    click.echo("─" * 30)
    for i, (v, err) in enumerate(results, 1):
        marker = " ◀" if i == 1 else ""
        click.echo(f"  {i:<3} {fmt_si(v, unit):<14} {err:>+7.3f}%{marker}")


@eseries_group.command('decompose')
@click.option('--value', 'val_str', required=True, metavar='VALUE',
              help='Target value, e.g. 10.5k')
@click.option('--series', default='E24', show_default=True,
              type=_SERIES_CHOICE, help='E-series to use.')
@click.option('--combo', default='series',
              type=click.Choice(['series', 'parallel'], case_sensitive=False),
              show_default=True, help='Combination type.')
@click.option('-n', 'n', default=5, show_default=True,
              help='Number of combinations to show.')
@click.option('--unit', default='Ω', show_default=True,
              help='Unit label for display (Ω, F, H…)')
def cmd_decompose(val_str, series, combo, n, unit):
    """Find two E-series values (series or parallel) that approximate a target.

    \b
    Example:
      ee-calc eseries decompose --value 10.5k
      ee-calc eseries decompose --value 10.5k --combo parallel
    """
    target = parse_si(val_str)
    results = decompose(target, series, combo, n)
    sym = '+' if combo == 'series' else '∥'
    click.echo(f"Target : {fmt_si(target, unit)}  "
               f"(series {series.upper()}, {combo} combination)")
    click.echo(f"{'Rank':<5} {'V1':<14} {'V2':<14} {'Result':<14} {'Error':>8}")
    click.echo("─" * 58)
    for i, (v1, v2, err) in enumerate(results, 1):
        if combo == 'series':
            actual = v1 + v2
        else:
            actual = (v1 * v2) / (v1 + v2)
        marker = " ◀" if i == 1 else ""
        click.echo(
            f"  {i:<3} {fmt_si(v1, unit):<14} {fmt_si(v2, unit):<14} "
            f"{fmt_si(actual, unit):<14} {err:>+7.3f}%{marker}"
        )
