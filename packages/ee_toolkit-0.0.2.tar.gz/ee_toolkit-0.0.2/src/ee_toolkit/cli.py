"""
Main Click entry point for ee-calc.

Commands:
  filter      RC and LC filter cutoff frequencies
  eseries     E-series standard value lookup
  oscillator  LC/Colpitts/Hartley resonance frequencies
  opamp       Op-amp gain, integrator, differentiator
"""
import click
from .filters    import filter_group
from .eseries    import eseries_group
from .oscillator import oscillator_group
from .opamp      import opamp_group


@click.group()
@click.version_option(package_name='ee-calc')
def cli():
    """EE Calculator — quick electrical engineering calculations.

    \b
    Sub-commands:
      filter      RC / LC filter cutoff frequency
      eseries     Nearest E-series value / two-component decomposition
      oscillator  LC, Colpitts, Hartley resonance frequency
      opamp       Inverting / non-inverting gain, integrator, differentiator

    Run  ee-calc COMMAND --help  for details on a command.
    """


cli.add_command(filter_group,     name='filter')
cli.add_command(eseries_group,    name='eseries')
cli.add_command(oscillator_group, name='oscillator')
cli.add_command(opamp_group,      name='opamp')
