# SPDX-FileCopyrightText: 2026-present Alexander Becker <nabla.becker@mailbox.org>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.2"
