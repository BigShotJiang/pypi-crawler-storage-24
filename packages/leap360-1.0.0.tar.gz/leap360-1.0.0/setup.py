import os
from setuptools import setup, find_packages

setup(
    name="leap360",
    version="1.0.0",
    description="Leap360 AI Governance SDK for Python",
    long_description=open("README.md", "r", encoding="utf-8").read() if os.path.exists("README.md") else "AI Observability SDK",
    long_description_content_type="text/markdown",
    author="Leap360",
    author_email="hello@leap360.ai",
    url="https://github.com/LeapTheLimit/Leap360-AI",
    packages=find_packages(),
    install_requires=[
        "requests>=2.25.1",
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.7",
)
