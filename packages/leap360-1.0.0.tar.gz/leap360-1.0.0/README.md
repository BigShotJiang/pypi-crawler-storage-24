# Leap360 AI Governance - Python SDK

The official Python client for Leap360. Add one line of code to get real-time observability, security guardrails, and cost tracking for your AI applications.

## Installation

```bash
pip install leap360
```

## Authentication

Make sure you've authenticated using the Leap360 CLI or set the API key perfectly.

```bash
npx leap360 login
```

Alternatively, you can manually set the environment variable:
```bash
export LEAP360_API_KEY="your-api-key"
```

## Quick Start

Wrap your existing AI clients in a single line. The `Leap360Tracer` automatically hooks into library responses without introducing latency.

```python
from leap360 import Leap360Tracer
from openai import OpenAI

# Initialize the Tracer (pulls from ~/.leap360/config.json securely)
tracer = Leap360Tracer(service_name="customer-support-agent")

# Wrap your existing OpenAI client magically
client = tracer.wrap(OpenAI())

# Make requests as usual - Leap360 natively tracks tokens, latency, and compliance
response = client.chat.completions.create(
    model="gpt-4",
    messages=[{"role": "user", "content": "How do I upgrade my account?"}]
)
print(response.choices[0].message.content)
```
