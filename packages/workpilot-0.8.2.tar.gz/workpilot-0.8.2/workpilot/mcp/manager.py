"""MCP Manager — centralized MCP server lifecycle manager.

Replaces scattered MCP state in Runtime (``_mcp_clients``, ``_connected_mcp``)
with a single orchestrator that handles connection, namespace, progressive
loading, and graceful shutdown.
"""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from typing import Any

from loguru import logger

from workpilot.agent.tools.registry import ToolRegistry
from workpilot.config.schema import MCPServerConfig, ProvidersConfig
from workpilot.mcp.auth import pre_connect_agency_check, resolve_auth_headers
from workpilot.mcp.client import MCPClient
from workpilot.mcp.health import MCPHealthMonitor
from workpilot.mcp.types import ConnectionState, MCPCapabilities, ServerInfo


class MCPManager:
    """Centralized MCP server lifecycle manager."""

    def __init__(
        self,
        configs: dict[str, MCPServerConfig],
        registry: ToolRegistry,
        security_profile: str | None = None,
        on_tools_registered: Callable[[list[str]], None] | None = None,
        providers: ProvidersConfig | None = None,
    ) -> None:
        self._configs = configs
        self._registry = registry
        self._security_profile = security_profile
        self._on_tools_registered = on_tools_registered
        self._providers = providers

        # Connection state
        self._clients: dict[str, MCPClient] = {}
        self._states: dict[str, ConnectionState] = {name: ConnectionState.IDLE for name in configs}
        # Health monitor (lazy init)
        self._health_monitor: MCPHealthMonitor | None = None
        # Cached tool descriptors (for progressive loading — describe action)
        self._tool_cache: dict[str, list[dict[str, Any]]] = {}
        # Registered tool names per server (for unregistration)
        self._registered_tools: dict[str, list[str]] = {}

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _server_timeout(self, name: str) -> float:
        """Return the effective timeout (seconds) for a server's operations."""
        config = self._configs.get(name)
        if config is None:
            return 60.0  # unknown server → standard default
        if config.timeout is not None:
            return max(1.0, float(config.timeout))  # clamp to ≥1s
        return 120.0 if config.is_agency else 60.0

    # ------------------------------------------------------------------
    # Connection lifecycle
    # ------------------------------------------------------------------

    async def connect_server(
        self, name: str, *, force: bool = False, auto_describe: bool = True
    ) -> str:
        """Connect a single MCP server.

        Returns a one-line summary for the LLM (progressive loading step 1).
        Tools are cached but NOT registered into the function calling schema
        until ``describe_server()`` is called.

        Args:
            name: Server name.
            force: Force reconnect even if already connected.
            auto_describe: If True and ≤5 tools, auto-describe (register tools).
                Set False for warm-up (connect only, no registration).
        """
        if not force and self._states.get(name) == ConnectionState.CONNECTED:
            # Verify the client is actually still connected (adapter may have
            # disconnected it on ConnectionError without updating manager state)
            client = self._clients.get(name)
            if client and client.is_connected:
                return f"MCP server '{name}' is already connected."
            # Stale state — fall through to reconnect
            logger.info(f"MCP server '{name}': stale CONNECTED state, reconnecting")
            force = True

        config = self._configs.get(name)
        if not config:
            available = [n for n, c in self._configs.items() if c.enabled]
            return f"Unknown MCP server '{name}'. Available: {', '.join(available)}"

        if not config.enabled:
            return f"MCP server '{name}' is disabled. Enable it in workpilot.yaml."

        # Clean up old connection on force reconnect
        if force:
            if self._health_monitor:
                self._health_monitor.stop_monitoring(name)
            old_client = self._clients.pop(name, None)
            if old_client:
                try:
                    await old_client.disconnect()
                except Exception:
                    pass
            # Clear old registrations so describe_server re-registers
            old_ns = f"MCP_{config.namespace or name}_"
            self._registry.unregister_prefix(old_ns)
            self._registered_tools.pop(name, None)

        self._states[name] = ConnectionState.CONNECTING

        # Agency pre-flight check
        if config.is_agency:
            ok, msg = await pre_connect_agency_check()
            if not ok:
                logger.warning(f"MCP server '{name}': Agency auth issue: {msg}")
                # Still attempt connection — Agency may prompt interactively

        try:
            # Resolve auth headers and merge with static extra headers
            headers = {
                **config.headers,
                **(await resolve_auth_headers(config, self._providers)),
            }

            client = MCPClient(
                command=config.command,
                args=config.args,
                url=config.url,
                headers=headers or None,
                name=name,
            )
            timeout = self._server_timeout(name)
            await client.connect(timeout=timeout)

            # Cache tool descriptors (do NOT register yet — progressive loading)
            try:
                descriptors = await client.list_tools(timeout=timeout)
            except Exception as exc:
                logger.warning(f"MCP server '{name}': failed to list tools: {exc}")
                descriptors = []

            self._clients[name] = client
            self._states[name] = ConnectionState.CONNECTED
            self._tool_cache[name] = descriptors

            # Start health monitoring
            if self._health_monitor is None:
                self._health_monitor = MCPHealthMonitor(self)
            await self._health_monitor.start_monitoring(name)

            # Wire up reconnect callbacks:
            # - _receive_loop uses trigger_reconnect (transport already dead,
            #   wakes the monitor loop which runs check_server then _reconnect)
            # - probe_and_reconnect uses reconnect_now (probe already confirmed
            #   server is unreachable, skip redundant check_server ping and
            #   spawn a dedicated reconnect task directly)
            health_monitor = self._health_monitor
            client._on_connection_lost = lambda: health_monitor.trigger_reconnect(name)
            client._on_probe_failed = lambda: health_monitor.reconnect_now(name)

            caps = client.capabilities
            logger.debug(f"MCP server '{name}': connected, {len(descriptors)} tools cached")

            # Smart shortcut: ≤5 tools → auto-describe (saves an LLM round)
            if auto_describe and len(descriptors) <= 5:
                return await self.describe_server(name)

            return self._build_summary(name, config, descriptors, caps)

        except Exception as exc:
            self._states[name] = ConnectionState.DISCONNECTED
            logger.error(f"MCP server '{name}' failed to start: {exc}")
            return f"Failed to connect MCP server '{name}': {exc}"

    async def describe_server(self, name: str, *, keyword: str | None = None) -> str:
        """Return full server capabilities: tools, resources, prompts.

        Auto-connects if not already connected. Registers tools into the
        ToolRegistry so the LLM can call them in the next turn.

        Args:
            name: Server name.
            keyword: Optional filter — only tools whose name or description
                contains this keyword (case-insensitive) are returned.
        """
        # Auto-connect if needed
        if self._states.get(name) != ConnectionState.CONNECTED:
            result = await self.connect_server(name)
            if self._states.get(name) != ConnectionState.CONNECTED:
                return result  # connection failed — return error

        descriptors = self._tool_cache.get(name, [])
        client = self._clients.get(name)
        config = self._configs.get(name)
        ns = (config.namespace if config and config.namespace else name) if config else name

        # Register tools if not already registered
        if name not in self._registered_tools or not self._registered_tools[name]:
            self._register_cached_tools(name)

        sections: list[str] = []

        # --- Tools section ---
        if descriptors:
            if keyword:
                kw = keyword.lower()
                filtered = [
                    d
                    for d in descriptors
                    if kw in d.get("name", "").lower() or kw in d.get("description", "").lower()
                ]
            else:
                filtered = descriptors

            if filtered:
                tool_lines: list[str] = []
                for desc in filtered:
                    raw_name = desc.get("name", "")
                    tool_desc = desc.get("description", "")
                    params = desc.get("inputSchema", {}).get("properties", {})
                    required = desc.get("inputSchema", {}).get("required", [])
                    param_str = ", ".join(
                        f"{k}: {v.get('type', 'any')}{'?' if k not in required else ''}"
                        for k, v in params.items()
                    )
                    tool_lines.append(f"  MCP_{ns}_{raw_name}({param_str}) — {tool_desc}")
                suffix = f", filtered by '{keyword}'" if keyword else ""
                sections.append(
                    f"Tools ({len(filtered)}/{len(descriptors)}{suffix}):\n" + "\n".join(tool_lines)
                )
            elif keyword:
                sections.append(f"Tools: no matches for '{keyword}' ({len(descriptors)} total)")
        else:
            sections.append("Tools: none")

        # --- Resources section ---
        timeout = self._server_timeout(name)
        if client:
            try:
                resources = await client.list_resources(timeout=timeout)
                if resources:
                    res_lines = [
                        f"  {r.get('uri', '?')} — {r.get('name', '')}: {r.get('description', '')}"
                        for r in resources
                    ]
                    sections.append(f"Resources ({len(resources)}):\n" + "\n".join(res_lines))
            except Exception:
                pass  # server doesn't support resources

        # --- Prompts section ---
        if client:
            try:
                prompts = await client.list_prompts(timeout=timeout)
                if prompts:
                    prompt_lines: list[str] = []
                    for p in prompts:
                        pname = p.get("name", "?")
                        pdesc = p.get("description", "")
                        pargs = p.get("arguments", [])
                        arg_str = ", ".join(a.get("name", "") for a in pargs) if pargs else ""
                        prompt_lines.append(f"  {pname}({arg_str}) — {pdesc}")
                    sections.append(f"Prompts ({len(prompts)}):\n" + "\n".join(prompt_lines))
            except Exception:
                pass  # server doesn't support prompts

        return f"MCP server '{name}':\n\n" + "\n\n".join(sections)

    async def read_resource(self, name: str, uri: str) -> str:
        """Read a resource from a connected server by URI."""
        client = self._clients.get(name)
        if client is None:
            return f"MCP server '{name}' is not connected."
        try:
            return await client.read_resource(uri, timeout=self._server_timeout(name))
        except Exception as exc:
            return f"Failed to read resource '{uri}' from '{name}': {exc}"

    async def get_prompt(
        self, name: str, prompt: str, arguments: dict[str, str] | None = None
    ) -> str:
        """Get a rendered prompt from a connected server."""
        client = self._clients.get(name)
        if client is None:
            return f"MCP server '{name}' is not connected."
        try:
            return await client.get_prompt(prompt, arguments, timeout=self._server_timeout(name))
        except Exception as exc:
            return f"Failed to get prompt '{prompt}' from '{name}': {exc}"

    async def disconnect_server(self, name: str) -> None:
        """Disconnect a server and unregister its tools."""
        # Stop health monitor
        if self._health_monitor:
            self._health_monitor.stop_monitoring(name)

        # Unregister tools
        config = self._configs.get(name)
        ns = (config.namespace if config and config.namespace else name) if config else name
        prefix = f"MCP_{ns}_"
        self._registry.unregister_prefix(prefix)
        self._registered_tools.pop(name, None)
        self._tool_cache.pop(name, None)

        # Disconnect client
        client = self._clients.pop(name, None)
        if client:
            try:
                await client.disconnect()
            except Exception as exc:
                logger.warning(f"MCP server '{name}' disconnect error: {exc}")

        self._states[name] = ConnectionState.DISCONNECTED

    async def disconnect_all(self) -> None:
        """Graceful shutdown of all connected servers."""
        if self._health_monitor:
            self._health_monitor.stop_all()
        names = list(self._clients.keys())
        for name in names:
            await self.disconnect_server(name)

    async def warm_up(self, timeout: float = 4.0) -> None:
        """Connect all enabled servers at startup with a per-server deadline.

        Each server is started as a background task. If it doesn't respond
        within ``timeout`` seconds the task keeps running in the background
        (e.g. waiting for an Agency auth popup). A 1s pause between servers
        avoids rapid-fire login dialogs.

        Connection failures are logged (state DISCONNECTED); the server can be
        connected later by the agent when needed.
        """
        enabled = [name for name, cfg in self._configs.items() if cfg.enabled]
        if not enabled:
            return

        logger.debug(f"MCP warm-up: connecting {len(enabled)} servers sequentially")
        for i, name in enumerate(enabled):
            tag = f"[{i + 1}/{len(enabled)}]"
            task = asyncio.create_task(
                self.connect_server(name, auto_describe=False),
                name=f"mcp-warmup-{name}",
            )
            try:
                result = await asyncio.wait_for(asyncio.shield(task), timeout=timeout)
                logger.debug(f"MCP warm-up {tag} {name}: OK — {result[:100]}")
            except TimeoutError:
                # Task keeps running in background — connect_server will register
                # tools and start health monitoring when the connection succeeds
                # (e.g. after an Agency auth popup completes).
                logger.info(
                    f"MCP warm-up {tag} {name}: still connecting in background"
                    f" (no response in {timeout}s)"
                )

                def _on_done(t: asyncio.Task, _name: str = name) -> None:
                    exc = t.exception() if not t.cancelled() else None
                    if exc:
                        self._states[_name] = ConnectionState.IDLE
                        logger.warning(f"MCP background connect '{_name}' failed: {exc}")

                task.add_done_callback(_on_done)
            except Exception as exc:
                self._states[name] = ConnectionState.IDLE
                logger.warning(f"MCP warm-up {tag} {name}: failed — {exc}")

            # Pause between servers to avoid rapid-fire login popups
            if i < len(enabled) - 1:
                await asyncio.sleep(1.0)

        connected = len(self.get_connected_servers())
        logger.info(f"MCP warm-up done: {connected}/{len(enabled)} servers connected")

    # ------------------------------------------------------------------
    # Discovery
    # ------------------------------------------------------------------

    def list_servers(self) -> list[ServerInfo]:
        """List all configured servers with connection status."""
        result: list[ServerInfo] = []
        for name, config in self._configs.items():
            state = self._states.get(name, ConnectionState.IDLE)
            if not config.enabled:
                state = ConnectionState.IDLE  # disabled servers are always idle
            tool_count = len(self._registered_tools.get(name, []))
            result.append(
                ServerInfo(
                    name=name,
                    state=state,
                    is_agency=config.is_agency,
                    enabled=config.enabled,
                    description=config.description,
                    tool_count=tool_count,
                )
            )
        return result

    def get_connected_servers(self) -> list[str]:
        """Return names of currently connected servers."""
        return [name for name, state in self._states.items() if state == ConnectionState.CONNECTED]

    def get_server_status(self, name: str) -> ServerInfo | None:
        """Get detailed status for a single server."""
        config = self._configs.get(name)
        if not config:
            return None
        return ServerInfo(
            name=name,
            state=self._states.get(name, ConnectionState.IDLE),
            is_agency=config.is_agency,
            enabled=config.enabled,
            description=config.description,
            tool_count=len(self._registered_tools.get(name, [])),
        )

    def build_system_prompt_summary(self) -> str:
        """Build one-line-per-server summary for system prompt injection.

        Only includes connected servers. Each line ≤100 chars.
        """
        connected = self.get_connected_servers()
        if not connected:
            return ""
        lines: list[str] = []
        for name in connected:
            config = self._configs.get(name)
            if config and config.description:
                summary = config.description
            else:
                descriptors = self._tool_cache.get(name, [])
                summary = self._short_summary(name, config, descriptors)
            tool_count = len(self._registered_tools.get(name, []))
            tools_info = f" ({tool_count} tools)" if tool_count > 0 else ""
            lines.append(f"  MCP_{name}{tools_info} — {summary}")
        return "MCP servers connected:\n" + "\n".join(lines)

    def get_client(self, name: str) -> MCPClient | None:
        """Get the MCPClient for a connected server."""
        return self._clients.get(name)

    def agency_servers(self) -> list[str]:
        """List all servers where command == 'agency'."""
        return [name for name, cfg in self._configs.items() if cfg.is_agency]

    def tool_namespace(self, name: str) -> str:
        """Return the tool namespace for a server (may differ from server name)."""
        config = self._configs.get(name)
        return config.namespace or name if config and config.namespace else name

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _register_cached_tools(self, name: str) -> None:
        """Synchronously register cached tool descriptors into the ToolRegistry."""
        config = self._configs.get(name)
        client = self._clients.get(name)
        if not client or not config:
            return

        descriptors = self._tool_cache.get(name, [])
        ns = config.namespace or name

        from workpilot.mcp.adapter import MCPToolAdapter, _resolve_server_config

        approval, timeout, risk_level = _resolve_server_config(config, self._security_profile)
        streaming = client.capabilities.streaming

        registered: list[str] = []
        for descriptor in descriptors:
            raw_name = descriptor.get("name", "")
            if not raw_name:
                continue
            reg_name = f"MCP_{ns}_{raw_name}"
            if self._registry.get(reg_name) is not None:
                continue
            adapter = MCPToolAdapter(
                descriptor,
                client,
                approval=approval,
                server_name=ns,
                timeout=timeout,
                risk_level=risk_level,
                streaming=streaming,
            )
            try:
                self._registry.register(adapter)
                self._registry.activate(reg_name)
                registered.append(reg_name)
            except ValueError:
                pass

        self._registered_tools[name] = registered
        logger.debug(
            f"MCP server '{name}': registered {len(registered)} tools into function calling"
        )

        # Notify agent loop to include these tools in its schema
        if registered and self._on_tools_registered:
            self._on_tools_registered(registered)

    @staticmethod
    def _build_summary(
        name: str,
        config: MCPServerConfig,
        descriptors: list[dict[str, Any]],
        caps: MCPCapabilities | None = None,
    ) -> str:
        """One-line connect summary for LLM."""
        info = [f"Tools: {len(descriptors)}"]
        if caps and caps.resources:
            info.append("Resources: yes")
        if caps and caps.prompts:
            info.append("Prompts: yes")
        return (
            f"Connected to MCP_{name} — {' | '.join(info)}.\n"
            f'Call tools(name="MCP_{name}", action="describe") to see tool details.'
        )

    @staticmethod
    def _short_summary(
        name: str,
        config: MCPServerConfig | None,
        descriptors: list[dict[str, Any]],
    ) -> str:
        """Short summary for system prompt (≤100 chars)."""
        if not descriptors:
            return "connected, no tools"
        # Collect unique verbs from tool names for a quick summary
        tool_names = [d.get("name", "") for d in descriptors[:5]]
        snippet = ", ".join(tool_names)
        if len(descriptors) > 5:
            snippet += f" +{len(descriptors) - 5} more"
        # Truncate to ~100 chars
        if len(snippet) > 95:
            snippet = snippet[:92] + "..."
        return snippet
