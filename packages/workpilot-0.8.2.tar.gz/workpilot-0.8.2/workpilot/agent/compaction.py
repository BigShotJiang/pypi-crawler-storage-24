"""
Context compaction — 3-tier context window management.

Prevents context overflow by progressively summarizing older messages:
- Tier 1 (80%): summarize older messages with fast model, keep recent 10
- Tier 2 (85%): aggressive summary, keep recent 5
- Tier 3 (95%): truncate oldest messages (no LLM call), keep recent 3

MEMORY.md (facts) is never compacted — bounded by design (8KB).

IMPORTANT: Split points must never break tool-call groups. An assistant
message with ``tool_calls`` and its corresponding ``tool`` result messages
must always stay together — OpenAI rejects orphaned tool messages.
"""

from __future__ import annotations

from enum import Enum
from typing import Any

from loguru import logger


class CompactionTier(str, Enum):
    NONE = "none"
    TIER1 = "tier1"  # 80% — summarize, keep 10
    TIER2 = "tier2"  # 85% — aggressive, keep 5
    TIER3 = "tier3"  # 95% — truncate, keep 3


# Token estimation: max of two heuristics to avoid under-counting code.
# - Word count × 1.3  — accurate for natural language (IronClaw heuristic)
# - Char count / 4     — accurate for code / structured content
_TOKEN_MULTIPLIER = 1.3


def estimate_tokens(messages: list[dict[str, Any]]) -> int:
    """Estimate token count from messages.

    Uses the higher of two heuristics (word-based and char-based) to avoid
    under-counting code-heavy content where tokens are denser than prose.
    """
    total_words = 0
    total_chars = 0
    for msg in messages:
        content = msg.get("content") or ""
        if isinstance(content, str):
            total_words += len(content.split())
            total_chars += len(content)
        # Count tool_calls as ~50 words / ~200 chars each
        tool_calls = msg.get("tool_calls", [])
        total_words += len(tool_calls) * 50
        total_chars += len(tool_calls) * 200
    return max(int(total_words * _TOKEN_MULTIPLIER), total_chars // 4)


def check_threshold(
    messages: list[dict[str, Any]],
    context_limit: int,
) -> CompactionTier:
    """Determine which compaction tier applies based on estimated usage."""
    tokens = estimate_tokens(messages)
    usage = tokens / context_limit if context_limit > 0 else 0.0

    if usage >= 0.95:
        return CompactionTier.TIER3
    elif usage >= 0.85:
        return CompactionTier.TIER2
    elif usage >= 0.80:
        return CompactionTier.TIER1
    return CompactionTier.NONE


def _safe_split_index(non_system: list[dict[str, Any]], keep_recent: int) -> int:
    """Find the split index that doesn't break tool-call groups.

    Returns the index into *non_system* where the "kept" portion starts.
    The split is adjusted backwards so that an ``assistant`` message with
    ``tool_calls`` is never separated from its subsequent ``tool`` results.
    """
    if keep_recent >= len(non_system):
        return 0

    idx = len(non_system) - keep_recent

    # Walk backward: if we'd start at a 'tool' message, include its parent
    # assistant message (and any sibling tool messages) too.
    while idx > 0 and non_system[idx].get("role") == "tool":
        idx -= 1

    # If we landed on the assistant message with tool_calls, include it.
    # (It's fine to keep one extra message rather than break the group.)
    return idx


def compact_tier3(messages: list[dict[str, Any]], keep_recent: int = 3) -> list[dict[str, Any]]:
    """Tier 3: truncate oldest messages, no LLM call. Keep system + recent N."""
    system_msgs = [m for m in messages if m.get("role") == "system"]
    non_system = [m for m in messages if m.get("role") != "system"]

    if len(non_system) <= keep_recent:
        return messages

    split = _safe_split_index(non_system, keep_recent)
    kept = non_system[split:]
    removed = len(non_system) - len(kept)
    logger.info(
        "Compaction tier 3: truncated {} messages, kept {} recent",
        removed,
        len(kept),
    )
    return (
        system_msgs
        + [
            {
                "role": "system",
                "content": f"[Context compacted: {removed} older messages removed]",
            }
        ]
        + kept
    )


def build_summary_prompt(messages_to_summarize: list[dict[str, Any]]) -> str:
    """Build a prompt for LLM to summarize older messages."""
    lines = []
    for msg in messages_to_summarize:
        role = msg.get("role", "unknown")
        content = msg.get("content") or ""
        if isinstance(content, str) and content:
            preview = content[:200] + ("..." if len(content) > 200 else "")
            lines.append(f"[{role}] {preview}")
    conversation = "\n".join(lines)

    return (
        "Summarize the following conversation concisely. Focus on:\n"
        "- Key decisions made\n"
        "- Important information exchanged (file paths, code patterns, error messages)\n"
        "- Actions taken and their outcomes\n"
        "- Pending tasks or open questions\n"
        "Preserve specific details that would prevent duplicate work.\n\n"
        f"{conversation}\n\n"
        "Summary:"
    )


async def compact_with_llm(
    messages: list[dict[str, Any]],
    provider: Any,
    model: str,
    keep_recent: int,
) -> list[dict[str, Any]]:
    """Compact by summarizing older messages with an LLM call.

    Args:
        messages: Full message list.
        provider: LLMProvider instance.
        model: Model to use for summarization.
        keep_recent: Number of recent non-system messages to preserve.

    Returns:
        Compacted message list with summary replacing older messages.
    """
    system_msgs = [m for m in messages if m.get("role") == "system"]
    non_system = [m for m in messages if m.get("role") != "system"]

    if len(non_system) <= keep_recent:
        return messages

    split = _safe_split_index(non_system, keep_recent)
    to_summarize = non_system[:split]
    to_keep = non_system[split:]

    prompt = build_summary_prompt(to_summarize)
    try:
        response = await provider.complete(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.1,
            max_tokens=1024,
        )
        summary = response.content
        logger.info(
            "Compaction: summarized {} messages into {} chars, kept {} recent",
            len(to_summarize),
            len(summary),
            keep_recent,
        )
    except Exception as exc:
        logger.error("Compaction LLM call failed: {}, falling back to truncation", exc)
        return compact_tier3(messages, keep_recent=keep_recent)

    return (
        system_msgs
        + [
            {
                "role": "system",
                "content": f"[Conversation summary — {len(to_summarize)} messages compacted]\n{summary}",
            }
        ]
        + to_keep
    )


class ContextCompactor:
    """Manages context window compaction for the agent loop.

    Call ``maybe_compact()`` before each LLM call. It checks estimated
    token usage against the context limit and applies the appropriate
    compaction tier.
    """

    def __init__(
        self,
        context_limit: int = 128_000,
        provider: Any = None,
        model: str = "auto",
    ) -> None:
        self._context_limit = context_limit
        self._provider = provider
        self._model = model

    async def maybe_compact(self, messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Check and apply compaction if needed. Returns (possibly compacted) messages."""
        tier = check_threshold(messages, self._context_limit)

        if tier == CompactionTier.NONE:
            return messages

        if tier == CompactionTier.TIER3:
            return compact_tier3(messages, keep_recent=3)

        if self._provider is None:
            # No provider for LLM summarization — fall back to truncation
            keep = 5 if tier == CompactionTier.TIER2 else 10
            return compact_tier3(messages, keep_recent=keep)

        keep = 5 if tier == CompactionTier.TIER2 else 10
        return await compact_with_llm(messages, self._provider, self._model, keep_recent=keep)
