"""
CronTool — lets the agent manage scheduled jobs at runtime.

The agent can list, add, remove, enable, and disable jobs.
Dynamic jobs persist to .workpilot/cron/jobs.json.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from workpilot.agent.tools.base import Tool, ToolMetadata

if TYPE_CHECKING:
    from workpilot.agent.tools.registry import ToolRegistry
    from workpilot.cron.service import SchedulerService


class CronTool(Tool):
    """Agent-facing tool for managing scheduled jobs (nanobot CronTool pattern)."""

    def __init__(self, scheduler: SchedulerService, registry: ToolRegistry | None = None) -> None:
        self._scheduler = scheduler
        self._registry = registry

    @property
    def name(self) -> str:
        return "cron"

    @property
    def description(self) -> str:
        return (
            "Manage scheduled jobs. Prefer tool mode for reminders; agent mode for complex tasks."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["list", "add", "remove", "enable", "disable", "describe"],
                    "description": (
                        "list = show all; add = create; remove = delete; "
                        "enable/disable = toggle; describe = show details."
                    ),
                },
                "job_id": {
                    "type": "string",
                    "description": (
                        "Short descriptive name for the job (e.g. 'drink-water', 'standup-reminder'). "
                        "Required for remove/enable/disable/describe. For add, provide a meaningful name."
                    ),
                },
                "schedule": {
                    "type": "string",
                    "description": (
                        "In SECONDS: 'at:+60' = 1 min; 'at:+3600' = 1 hr; "
                        "'at:2026-03-04T15:00:00' = specific time; "
                        "'at' = immediate; 3600 = repeat every hour; "
                        "'0 9 * * *' = cron. Required for add."
                    ),
                },
                "prompt": {
                    "type": "string",
                    "description": (
                        "Agent mode: task for LLM to execute. Use for complex tasks needing reasoning. "
                        "Mutually exclusive with tool."
                    ),
                },
                "tool": {
                    "type": "string",
                    "description": (
                        "Tool mode (PREFERRED for reminders): tool name to execute directly, no LLM. "
                        "Use tool='notify' with arguments={channel:'*', content:'your message'} for reminders. "
                        "Mutually exclusive with prompt."
                    ),
                },
                "arguments": {
                    "type": "object",
                    "description": (
                        "Arguments for tool mode (required when tool is set). "
                        'Example: {"channel": "*", "content": "Time to drink water!"}'
                    ),
                },
                "approved": {
                    "type": "boolean",
                    "description": (
                        "Set to true to confirm scheduling a tool that requires approval. "
                        "The user must explicitly agree before you set this."
                    ),
                },
                "notify_channels": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Result delivery channels. ['*'] = all active channels.",
                },
            },
            "required": ["action"],
        }

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(risk_level="low", approval="auto", tier="standard")

    async def execute(self, **kwargs: Any) -> str:
        action = kwargs.get("action", "")

        if action == "list":
            jobs = self._scheduler.list_jobs()
            if not jobs:
                return "No scheduled jobs."
            lines = ["Scheduled jobs:"]
            for j in jobs:
                status = "enabled" if j["enabled"] else "DISABLED"
                next_run = j.get("next_run") or "N/A"
                mode = j.get("mode", "tool" if j.get("tool") else "agent")
                lines.append(
                    f"  {j['name']}: {j['trigger_type']} ({j['schedule']}) "
                    f"mode={mode} agent={j['agent']} [{status}] next={next_run}"
                )
            return "\n".join(lines)

        elif action == "add":
            schedule = kwargs.get("schedule")
            tool_name = kwargs.get("tool")
            arguments = kwargs.get("arguments")
            prompt = kwargs.get("prompt")

            if not schedule:
                return "Error: 'schedule' is required for add."
            if tool_name and prompt:
                return "Error: 'tool' and 'prompt' are mutually exclusive."
            if not tool_name and not prompt:
                return "Error: either 'tool' or 'prompt' is required for add."
            if tool_name and arguments is None:
                return "Error: 'arguments' is required when 'tool' is set."

            # Tool mode: check if target tool requires approval
            if tool_name and self._registry:
                target = self._registry.get(tool_name)
                if not target:
                    return f"Error: unknown tool '{tool_name}'."
                approval = target.metadata.approval
                if approval in ("auto", "always"):
                    approved = kwargs.get("approved", False)
                    if not approved:
                        risk = target.metadata.risk_level
                        return (
                            f"Tool '{tool_name}' (risk={risk}, approval={approval}) requires "
                            f"user confirmation to schedule. Ask the user to confirm, "
                            f"then call again with approved=true."
                        )

            import re as _re

            job_id = kwargs.get("job_id")
            if not job_id:
                # Derive a short name from the prompt or tool (first few words, slugified)
                source = prompt or tool_name or "task"
                slug = _re.sub(r"[^a-z0-9]+", "-", source[:40].lower()).strip("-")
                job_id = slug or "task"
            # Ensure unique name by appending suffix if already exists
            existing = {j["name"] for j in self._scheduler.list_jobs()}
            if job_id in existing:
                base = job_id
                for i in range(2, 100):
                    job_id = f"{base}-{i}"
                    if job_id not in existing:
                        break
                else:
                    import uuid as _uuid

                    job_id = f"{base}-{_uuid.uuid4().hex[:6]}"
            notify_channels = kwargs.get("notify_channels") or ["*"]
            try:
                self._scheduler.add_job(
                    name=job_id,
                    schedule=schedule,
                    prompt=prompt or "",
                    tool=tool_name,
                    arguments=arguments,
                    notify_channels=notify_channels,
                    dynamic=True,
                    channel=kwargs.get("_channel"),
                    channel_id=kwargs.get("_channel_id"),
                )
            except ValueError as exc:
                return f"Error: {exc}"
            mode_info = f", tool={tool_name}" if tool_name else ""
            return f"Job '{job_id}' added (schedule={schedule}{mode_info})."

        elif action == "remove":
            job_id = kwargs.get("job_id")
            if not job_id:
                return "Error: 'job_id' is required for remove."
            if job_id not in {j["name"] for j in self._scheduler.list_jobs()}:
                return f"Error: job '{job_id}' not found."
            self._scheduler.remove_job(job_id)
            return f"Job '{job_id}' removed."

        elif action == "enable":
            job_id = kwargs.get("job_id")
            if not job_id:
                return "Error: 'job_id' is required for enable."
            if job_id not in {j["name"] for j in self._scheduler.list_jobs()}:
                return f"Error: job '{job_id}' not found."
            self._scheduler.enable(job_id)
            return f"Job '{job_id}' enabled."

        elif action == "disable":
            job_id = kwargs.get("job_id")
            if not job_id:
                return "Error: 'job_id' is required for disable."
            if job_id not in {j["name"] for j in self._scheduler.list_jobs()}:
                return f"Error: job '{job_id}' not found."
            self._scheduler.disable(job_id)
            return f"Job '{job_id}' disabled."

        elif action == "describe":
            job_id = kwargs.get("job_id")
            if not job_id:
                return "Error: 'job_id' is required for describe."
            jobs_by_name = {j["name"]: j for j in self._scheduler.list_jobs()}
            job = jobs_by_name.get(job_id)
            if not job:
                return f"Error: job '{job_id}' not found."
            mode = job.get("mode", "tool" if job.get("tool") else "agent")
            tool_line = f"\nTool: {job['tool']}" if job.get("tool") else ""
            return (
                f"Job: {job['name']}\n"
                f"Schedule: {job['trigger_type']} ({job['schedule']})\n"
                f"Mode: {mode}\n"
                f"Agent: {job['agent']}\n"
                f"Status: {'enabled' if job['enabled'] else 'DISABLED'}\n"
                f"Next run: {job.get('next_run') or 'N/A'}\n"
                f"Failures: {job['failure_count']}"
                f"{tool_line}"
            )

        return f"Unknown action: {action}"
