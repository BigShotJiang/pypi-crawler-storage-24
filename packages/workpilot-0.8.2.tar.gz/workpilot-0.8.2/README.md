# WorkPilot

**An autonomous AI assistant that codes, communicates, and ships across your entire Microsoft stack — proactively and securely.**

Most AI coding tools require you to send your code to a third-party cloud. WorkPilot runs entirely on your machine, inside your corporate network. Your source code, credentials, and conversations never leave your infrastructure — yet your team can still reach WorkPilot directly from Microsoft Teams.

[![CI](https://github.com/gim-home/WorkPilot/actions/workflows/workpilot-ci.yml/badge.svg)](https://github.com/gim-home/WorkPilot/actions/workflows/workpilot-ci.yml)
[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/)

---

## Why WorkPilot for enterprise?

Most AI assistants are cloud-hosted SaaS — acceptable for personal use, not for organizations with data governance requirements. WorkPilot takes the opposite approach:

- **Your infra, your data.** The assistant runs on your own machine or VM. Nothing is persisted outside your network.
- **Your identity provider.** Authentication flows through Microsoft Entra ID (Azure AD). No separate accounts or API keys to manage.
- **Your compliance posture.** Four security profiles (`open` → `standard` → `controlled` → `restricted`) let security teams tune autonomy without touching code.
- **Your Microsoft stack.** Native Teams bot, Outlook, Graph API, and Azure DevOps integration — WorkPilot lives where your org already works.

---

## Install

**Requirements:** Python 3.11+

### pip install (recommended)

```bash
pip install --upgrade workpilot
workpilot version              # verify installation
workpilot init                 # guided setup — creates workpilot.local.yaml
workpilot                      # smart start — init if needed, then launch server
```

### One-click bootstrap

The bootstrap scripts automatically install Python 3.13 if needed, configure pip, install WorkPilot from PyPI, and verify the CLI is on your PATH.

**Windows (PowerShell):**
```powershell
irm https://aka.ms/workpilot/install.ps1 | iex
```

**macOS / Linux:**
```bash
curl -fsSL https://aka.ms/workpilot/install.sh | bash
```

### Platform notes

| Platform | Notes |
|----------|-------|
| **Windows** | If `workpilot` isn't found after install, ensure `%APPDATA%\Python\Python3x\Scripts` is on your PATH, or use the PowerShell bootstrap script above. |
| **macOS** | You may need `python3` instead of `python`. Homebrew: `brew install python@3.11` |
| **Linux** | Use your distro's package manager (e.g., `sudo apt install python3.11 python3.11-venv`) if Python 3.11+ isn't available. |

> **Tip:** Using a virtual environment is recommended for isolated installs:
> ```bash
> python -m venv .venv && source .venv/bin/activate  # or .venv\Scripts\activate on Windows
> pip install workpilot
> ```

> **Teams user?** [Add WorkPilot to Teams](https://teams.microsoft.com/l/chat/0/0?users=28:98647cd1-f31c-46e7-ad1a-b65f742a54bf) *(Microsoft Preview)* then run `workpilot s` to bring WorkPilot online.

---

## What it does

| | |
|--|--|
| **Write & edit code** | Reads, writes, refactors, and debugs across your entire codebase |
| **Run commands** | Shell, git, tests, build tools — sandboxed with deny-pattern controls |
| **Browse & search** | Web search, HTTP requests, Playwright browser automation |
| **Talk to Microsoft 365** | Teams messages, Outlook email, Graph API, Azure DevOps |
| **Schedule work** | Cron jobs, event triggers, recurring automated tasks |

---

## Three ways to use it

### 1. Terminal
```bash
workpilot chat               # interactive REPL
workpilot run "write tests"  # one-shot
```

### 2. Self-hosted web UI
```bash
workpilot serve     # http://localhost:3003
```
Chat UI, REST API, WebSocket, and OpenAI-compatible endpoint — all on your own server.

### 3. Microsoft Teams + Web Chat
```bash
workpilot cloud   # authenticate with Entra ID — Teams messages reach WorkPilot
```
A stateless Cloud Gateway relays messages between Teams and your machine. Nothing is stored in the cloud. If the assistant is offline, Teams users receive an instant notification with reconnection instructions.

---

## Security architecture

WorkPilot implements defense-in-depth security at every layer:

### Access control
- **Entra ID SSO** — MSAL authentication for Teams and Web Chat; no passwords, no shared secrets
- **Security profiles** — tune the autonomy level across your deployment without modifying code

### Runtime protection
- **3-phase tool hook pipeline** — preflight classifiers reject suspicious actions *before* execution; postflight scanners redact credentials from *tool output*
- **Security Classifier** — a fast secondary LLM reviews every tool call; results are cached for 5 minutes to minimize cost
- **Command sandbox** — configurable deny patterns block destructive shell commands (`rm -rf`, `curl | bash`, etc.)
- **Path sandbox** — workspace restriction and SSRF protection prevent access outside permitted directories

### Observability & incident response
- **Audit log** — append-only record of every tool call, message, and security event; auto-redacted before writing
- **Secret redaction** — API keys, JWT tokens, AWS credentials, and high-entropy strings masked in real time
- **E-stop** — global kill switch triggered manually or automatically on credential leak detection; halts all processing and returns 503 on the gateway

---

## Built-in agents

| Agent | Purpose |
|-------|---------|
| `default` | Full-capability orchestrator — user-facing |
| `explorer` | Fast, read-only search — 10× cheaper, spawned automatically |
| `security` | Internal Security Classifier — not user-facing |

Templates (`coder`, `reviewer`, `tester`, `researcher`, `communicator`) can be enabled per-project in `workpilot.yaml`.

---

## Development

```bash
git clone https://github.com/gim-home/WorkPilot.git
cd WorkPilot
pip install -e ".[dev]"        # editable install with dev dependencies
pip install -e ".[all]"        # editable install with all optional deps
pytest tests/ -v
python -m ruff check && python -m ruff format
```

All changes via pull request. Never push directly to `main`.

---

## Links

- [Official Website](https://aka.ms/workpilot)
- [Add to Microsoft Teams](https://teams.microsoft.com/l/chat/0/0?users=28:98647cd1-f31c-46e7-ad1a-b65f742a54bf) *(Preview)*
- [Architecture docs](design/core-infra.md)
- [Cloud Gateway (.NET)](cloud_gateway/)
