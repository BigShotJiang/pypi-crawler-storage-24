# DataFlow-CV

> **Where Vibe Coding meets CV data.** 🌊
> Convert & visualize datasets. Built with the flow of Claude Code.

![Python Version](https://img.shields.io/badge/python-3.8%20|%203.9%20|%203.10%20|%203.11%20|%203.12-blue)
![License](https://img.shields.io/badge/license-MIT-green)
![Version](https://img.shields.io/badge/version-0.2.1-orange)
![Development Status](https://img.shields.io/badge/status-alpha-yellow)

A data processing library for computer vision datasets, focusing on format conversion and visualization between LabelMe, COCO, and YOLO formats. Provides both a CLI and Python API.

## Table of Contents

- [DataFlow-CV](#dataflow-cv)
  - [Table of Contents](#table-of-contents)
  - [Project Structure](#project-structure)
  - [Requirements](#requirements)
    - [Core Dependencies](#core-dependencies)
  - [Quick Start](#quick-start)
    - [Installation](#installation)
    - [Command Line Usage](#command-line-usage)
    - [Python API Usage](#python-api-usage)
    - [CLI Reference](#cli-reference)
      - [Global Options](#global-options)
      - [Conversion Commands](#conversion-commands)
      - [Visualization Commands](#visualization-commands)
      - [Configuration Command](#configuration-command)
      - [Getting Help](#getting-help)
    - [Segmentation Support](#segmentation-support)
    - [Running Tests](#running-tests)
    - [Examples](#examples)
  - [License](#license)

## Project Structure

```
dataflow/
├── __init__.py              # Package exports and convenience functions
├── cli.py                   # Command-line interface
├── config.py                # Configuration management
├── convert/                 # Format conversion module
│   ├── __init__.py
│   ├── base.py             # Converter base class
│   ├── coco_to_yolo.py     # COCO to YOLO converter
│   └── yolo_to_coco.py     # YOLO to COCO converter
├── visualize/               # Annotation visualization module
│   ├── __init__.py
│   ├── base.py            # Visualizer base class
│   ├── yolo.py            # YOLO annotation visualizer
│   ├── coco.py            # COCO annotation visualizer
│   └── labelme.py         # LabelMe annotation visualizer
└── label/                   # Label format handlers module
    ├── __init__.py
    ├── yolo.py            # YOLO format handler
    ├── coco.py            # COCO format handler
    └── labelme.py         # LabelMe format handler
tests/
├── __init__.py
├── convert/                # Conversion tests
│   ├── __init__.py
│   ├── test_coco_to_yolo.py
│   └── test_yolo_to_coco.py
├── visualize/              # Visualization tests
│   ├── __init__.py
│   ├── test_yolo.py
│   ├── test_coco.py
│   ├── test_labelme.py
│   └── test_generic.py    # Generic visualizer tests
├── run_tests.py           # Test runner
samples/
├── __init__.py
├── example_usage.py       # Quick usage demonstration
├── cli/                   # CLI usage examples
│   ├── __init__.py
│   ├── convert/
│   │   ├── cli_coco_to_yolo.py
│   │   └── cli_yolo_to_coco.py
│   └── visualize/
│       ├── cli_yolo.py
│       ├── cli_coco.py
│       └── cli_labelme.py
└── api/                   # Python API examples
    ├── __init__.py
    ├── convert/
    │   ├── api_coco_to_yolo.py
    │   └── api_yolo_to_coco.py
    └── visualize/
        ├── api_yolo.py
        ├── api_coco.py
        └── api_labelme.py
```

## Requirements

### Core Dependencies
- Python 3.8 or higher
- Linux environment (POSIX compatible, assumes POSIX paths)
- `click` >= 8.1.0 – CLI framework
- `numpy` >= 2.0.0 – numerical operations
- `opencv-python` >= 4.8.0 – image processing (optional, used for some image operations)
- `Pillow` >= 10.0.0 – image reading (optional, used for reading image dimensions)

## Quick Start

### Installation

```bash
# Regular installation from source
pip install .

# Editable installation (development mode)
# Due to setuptools compatibility, use python setup.py develop (not pip install -e .)
python setup.py develop
# After editable installation, use python -m dataflow.cli instead of the dataflow command
```

### Command Line Usage

Global options: `--verbose` (`-v`) for progress output, `--overwrite` to replace existing files.

```bash
# COCO to YOLO conversion (use --segmentation for polygon annotations)
dataflow convert coco2yolo annotations.json output_dir/
dataflow convert coco2yolo annotations.json output_dir/ --segmentation

# YOLO to COCO conversion
dataflow convert yolo2coco images/ labels/ classes.names output.json

# Visualize YOLO annotations (use --save to export images)
dataflow visualize yolo images/ labels/ classes.names
dataflow visualize yolo images/ labels/ classes.names --save output_dir/

# Visualize COCO annotations (use --save to export images)
dataflow visualize coco images/ annotations.json
dataflow visualize coco images/ annotations.json --save output_dir/

# Visualize LabelMe annotations (use --save to export images)
dataflow visualize labelme images/ labels/
dataflow visualize labelme images/ labels/ --save output_dir/

# Show configuration
dataflow config

# Get help
dataflow --help
dataflow convert coco2yolo --help
dataflow visualize yolo --help
dataflow visualize labelme --help
```

See the [CLI Reference](#cli-reference) below for detailed usage.

### Python API Usage

```python
import dataflow

# COCO to YOLO conversion (pass segmentation=True for polygon annotations)
result = dataflow.coco_to_yolo("annotations.json", "output_dir")
result = dataflow.coco_to_yolo("annotations.json", "output_dir", segmentation=True)
print(f"Processed {result['images_processed']} images")

# YOLO to COCO conversion
result = dataflow.yolo_to_coco("images/", "labels/", "classes.names", "output.json")
print(f"Generated {result['annotations_processed']} annotations")

# Visualize YOLO annotations (save_dir is optional)
result = dataflow.visualize_yolo("images/", "labels/", "classes.names")
result = dataflow.visualize_yolo("images/", "labels/", "classes.names", save_dir="output_dir/")
print(f"Visualized {result['images_processed']} images")

# Visualize COCO annotations (save_dir is optional)
result = dataflow.visualize_coco("images/", "annotations.json")
result = dataflow.visualize_coco("images/", "annotations.json", save_dir="output_dir/")
print(f"Visualized {result['images_processed']} images")

# Visualize LabelMe annotations (save_dir is optional)
result = dataflow.visualize_labelme("images/", "labels/")
result = dataflow.visualize_labelme("images/", "labels/", save_dir="output_dir/")
print(f"Visualized {result['images_processed']} images")
print(f"Classes found: {result['classes_found']}")
```

### CLI Reference

The CLI follows a hierarchical structure: `dataflow <main‑task> <sub‑task> [arguments]`. Global options can be placed before the main task.

#### Global Options
- `--verbose`, `-v`: Enable verbose output (progress information)
- `--overwrite`: Overwrite existing files

#### Conversion Commands

**COCO to YOLO**
```bash
dataflow convert coco2yolo COCO_JSON_PATH OUTPUT_DIR [--segmentation]
```
- `COCO_JSON_PATH`: Path to COCO JSON annotation file
- `OUTPUT_DIR`: Directory where `labels/` and `class.names` will be created
- `--segmentation`, `-s`: Handle segmentation annotations (polygon format)

**YOLO to COCO**
```bash
dataflow convert yolo2coco IMAGE_DIR YOLO_LABELS_DIR YOLO_CLASS_PATH COCO_JSON_PATH
```
- `IMAGE_DIR`: Directory containing image files
- `YOLO_LABELS_DIR`: Directory containing YOLO label files (`.txt`)
- `YOLO_CLASS_PATH`: Path to YOLO class names file (e.g., `class.names`)
- `COCO_JSON_PATH`: Path to save COCO JSON file

#### Visualization Commands

**Visualize YOLO annotations**
```bash
dataflow visualize yolo IMAGE_DIR LABEL_DIR CLASS_PATH [--save SAVE_DIR]
```
- `IMAGE_DIR`: Directory containing image files
- `LABEL_DIR`: Directory containing YOLO label files (`.txt`)
- `CLASS_PATH`: Path to class names file (e.g., `class.names`)
- `--save SAVE_DIR`: Optional directory to save visualized images

**Visualize COCO annotations**
```bash
dataflow visualize coco IMAGE_DIR ANNOTATION_JSON [--save SAVE_DIR]
```
- `IMAGE_DIR`: Directory containing image files
- `ANNOTATION_JSON`: Path to COCO JSON annotation file
- `--save SAVE_DIR`: Optional directory to save visualized images

**Visualize LabelMe annotations**
```bash
dataflow visualize labelme IMAGE_DIR LABEL_DIR [--save SAVE_DIR]
```
- `IMAGE_DIR`: Directory containing image files
- `LABEL_DIR`: Directory containing LabelMe JSON files
- `--save SAVE_DIR`: Optional directory to save visualized images

#### Configuration Command
```bash
dataflow config
```
Shows the current configuration (file extensions, default values, CLI context).

#### Getting Help
```bash
dataflow --help
dataflow convert --help
dataflow convert coco2yolo --help
dataflow convert yolo2coco --help
dataflow visualize --help
dataflow visualize yolo --help
dataflow visualize coco --help
dataflow visualize labelme --help
```

### Segmentation Support

DataFlow-CV supports both bounding box and polygon segmentation annotations across all formats:

**YOLO Segmentation Format**
- Detection format: `class_id x_center y_center width height` (normalized coordinates)
- Segmentation format: `class_id x1 y1 x2 y2 ...` (polygon vertices, normalized)
- YOLO segmentation files have the same `.txt` extension as detection files

**COCO Segmentation Format**
- Polygon coordinates in `segmentation` field (list of `[x1, y1, x2, y2, ...]`)
- Both single-polygon and multi-polygon annotations are supported

**LabelMe Segmentation Format**
- Rectangle shapes (`shape_type: "rectangle"`) for bounding box annotations
- Polygon shapes (`shape_type: "polygon"`) for segmentation annotations
- Each JSON file contains `shapes` array with annotation data

**Usage Examples**

```bash
# Convert COCO to YOLO with segmentation annotations
dataflow convert coco2yolo annotations.json output_dir/ --segmentation

# Visualize YOLO annotations in strict segmentation mode (only polygons)
dataflow visualize yolo images/ labels/ classes.names --segmentation

# Visualize COCO annotations in strict segmentation mode
dataflow visualize coco images/ annotations.json --segmentation

# Visualize LabelMe annotations in strict segmentation mode (only polygons)
dataflow visualize labelme images/ labels/ --segmentation
```

**Python API**
```python
# Convert COCO to YOLO with segmentation
result = dataflow.coco_to_yolo("annotations.json", "output_dir", segmentation=True)

# Visualize in strict segmentation mode
result = dataflow.visualize_yolo("images/", "labels/", "classes.names", segmentation=True)
result = dataflow.visualize_labelme("images/", "labels/", segmentation=True)
```

**Notes**
- Without the `--segmentation` flag, both bounding boxes and polygons are processed automatically
- With `--segmentation` flag, only valid polygon annotations are processed (strict mode)
- YOLO segmentation format requires at least 3 points (6 coordinates)
- COCO segmentation polygons are automatically converted to YOLO normalized coordinates
- LabelMe format supports both rectangle (`shape_type: "rectangle"`) and polygon (`shape_type: "polygon"`) shapes
- In segmentation mode, LabelMe visualizer rejects rectangle shapes and only accepts polygon shapes

### Running Tests

```bash
# Run all tests
python tests/run_tests.py

# Run specific test
python tests/run_tests.py --test TestCocoToYoloConverter

# With verbose output
python tests/run_tests.py -v
```

### Examples

Check the `samples/` directory for detailed usage examples:

- `samples/cli/convert/` - CLI conversion examples
- `samples/cli/visualize/` - CLI visualization examples
- `samples/api/convert/` - Python API conversion examples
- `samples/api/visualize/` - Python API visualization examples

## License

[MIT License](LICENSE) © 2026 zjykzj