# labor-market-mcp-server

[![PyPI version](https://badge.fury.io/py/labor-market-mcp-server.svg)](https://pypi.org/project/labor-market-mcp-server/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)](https://www.python.org/downloads/)

MCP-Server für weltweite Arbeitsmarktdaten — Arbeitslosigkeit, Löhne, Beschäftigung und Berufsaussichten.

> **Kostenlos** — Keine API-Keys benötigt. Nutzt BLS (USA) und Eurostat (EU) offizielle APIs.

## Tools (5)

| Tool | Beschreibung |
|------|-------------|
| `get_us_unemployment` | US-Arbeitslosenquote + Trend (BLS, saisonbereinigt) |
| `get_eu_unemployment` | EU/Länder-Arbeitslosenquote (Eurostat, 20 Länder) |
| `compare_unemployment` | Mehrere Länder/Regionen vergleichen |
| `get_us_wage_data` | Durchschnittliche Stundenlöhne + Wochenstunden (USA) |
| `get_us_employment_situation` | Payrolls, Partizipationsrate, Beschäftigungsquote |
| `get_us_sector_employment` | Beschäftigung nach Branche (11 Sektoren) |
| `get_occupation_outlook` | Berufsaussichten + KI-Auswirkungen (BLS OOH 2024-2025) |

## Installation

```bash
pip install labor-market-mcp-server
```

## Konfiguration (Claude Desktop)

```json
{
  "mcpServers": {
    "labor-market": {
      "command": "labor-market-server"
    }
  }
}
```

## Beispiele

```python
# US-Arbeitslosigkeit der letzten 12 Monate
get_us_unemployment(months=12)

# Deutschland vs. Eurozone vs. Spanien
compare_unemployment(countries=["DE", "ES", "EA20", "EU27_2020"])

# Tech-Sektor Beschäftigung USA
get_us_sector_employment(sector="information", months=12)

# Berufsaussichten für AI-Engineer
get_occupation_outlook(occupation="ai_ml_engineer")

# Alle Berufe nach Wachstum sortiert
get_occupation_outlook()
```

## Datenquellen

- **BLS (Bureau of Labor Statistics)**: Offizielle US-Arbeitsdaten, 500 kostenlose Abfragen/Tag
- **Eurostat**: EU-Statistikbehörde, kostenlos ohne Key

## Verfügbare EU-Länder

`DE, FR, IT, ES, PL, NL, BE, SE, AT, DK, FI, PT, GR, CZ, RO, HU, SK, HR, EU27_2020, EA20`

## Verfügbare US-Sektoren

`mining_logging, construction, manufacturing, trade_transport, information, financial, professional_business, education_health, leisure_hospitality, other_services, government, all`

## Verfügbare Berufe (OOH)

`software_developer, data_scientist, ai_ml_engineer, nurse, truck_driver, accountant, graphic_designer, healthcare_manager, electrician, customer_service_rep`

## Links

- [PyPI](https://pypi.org/project/labor-market-mcp-server/)
- [GitHub](https://github.com/AiAgentKarl/labor-market-mcp-server)
- [BLS API Docs](https://www.bls.gov/developers/)
- [Eurostat API Docs](https://ec.europa.eu/eurostat/web/sdmx-web-services)

---

Part of the [AI Agent Karl](https://github.com/AiAgentKarl) MCP Server Collection.
