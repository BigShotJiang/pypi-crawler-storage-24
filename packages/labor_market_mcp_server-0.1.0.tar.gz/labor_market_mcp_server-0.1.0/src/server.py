"""Labor Market MCP Server — Arbeitsmarktdaten für AI-Agents.

Bietet:
- US-Arbeitslosenquote und Beschäftigungssituation (BLS)
- EU-Arbeitslosenquote nach Land (Eurostat)
- Ländervergleich Arbeitslosigkeit
- Lohn- und Gehaltsdaten USA
- Branchenanalyse Beschäftigung
- Berufsaussichten und KI-Auswirkungen (BLS OOH)
"""

from mcp.server.fastmcp import FastMCP

from src.tools.unemployment import register_unemployment_tools
from src.tools.wages import register_wage_tools
from src.tools.sectors import register_sector_tools

# FastMCP Server erstellen
mcp = FastMCP(
    "Labor Market MCP Server",
    instructions=(
        "Gibt AI-Agents Zugriff auf weltweite Arbeitsmarktdaten: "
        "US-Beschäftigung und Löhne (BLS), EU-Arbeitslosenquoten (Eurostat), "
        "Branchenanalyse nach Sektor und Berufsaussichten inklusive KI-Auswirkungen. "
        "Alle Daten kostenlos ohne API-Key."
    ),
)

# Tool-Gruppen registrieren
register_unemployment_tools(mcp)
register_wage_tools(mcp)
register_sector_tools(mcp)


def main():
    """Server starten."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
