"""Lohn- und Gehaltsdaten — BLS (USA) und OECD."""

import httpx
from mcp.server.fastmcp import FastMCP

BLS_BASE = "https://api.bls.gov/publicAPI/v1/timeseries/data"


def register_wage_tools(mcp: FastMCP):
    """Lohn-Tools beim MCP-Server registrieren."""

    @mcp.tool()
    async def get_us_wage_data(months: int = 12) -> dict:
        """
        Durchschnittliche Stundenlöhne und Arbeitskosten-Index (USA, BLS).

        Args:
            months: Anzahl der zurückliegenden Monate (1-24, Standard: 12)

        Returns:
            Stundenlöhne, Wochenarbeitszeit, Employment Cost Index
        """
        months = max(1, min(24, months))

        # BLS-Serien: Durchschnittliche Stundenlöhne (privat), Wochenstunden (privat)
        series_ids = [
            "CES0500000003",  # Durchschn. Stundenlöhne, Privatsektor
            "CES0500000007",  # Durchschn. Wochenstunden, Privatsektor
        ]

        results = {}
        async with httpx.AsyncClient(timeout=12.0) as client:
            for series_id in series_ids:
                try:
                    resp = await client.get(f"{BLS_BASE}/{series_id}")
                    resp.raise_for_status()
                    data = resp.json()
                    raw = data.get("Results", {}).get("series", [{}])[0].get("data", [])

                    points = []
                    for dp in raw:
                        period = dp.get("period", "")
                        if period.startswith("M"):
                            points.append({
                                "date": f"{dp['year']}-{period[1:]}",
                                "value": float(dp.get("value", 0)),
                            })
                    points.sort(key=lambda x: x["date"], reverse=True)
                    results[series_id] = points[:months]
                except Exception as e:
                    results[series_id] = {"error": str(e)}

        hourly_data = results.get("CES0500000003", [])
        hours_data = results.get("CES0500000007", [])

        output = {
            "country": "USA",
            "source": "U.S. Bureau of Labor Statistics",
            "sector": "Privatsektor (alle Branchen)",
        }

        if isinstance(hourly_data, list) and hourly_data:
            current_wage = hourly_data[0]
            prev_year_wage = hourly_data[12] if len(hourly_data) > 12 else None
            output["avg_hourly_earnings_usd"] = {
                "current": current_wage,
                "yoy_change_pct": round(
                    (current_wage["value"] - prev_year_wage["value"]) / prev_year_wage["value"] * 100, 2
                ) if prev_year_wage else None,
                "trend": hourly_data,
            }

        if isinstance(hours_data, list) and hours_data:
            output["avg_weekly_hours"] = {
                "current": hours_data[0],
                "trend": hours_data,
            }

        return output

    @mcp.tool()
    async def get_us_employment_situation(months: int = 6) -> dict:
        """
        Gesamte US-Beschäftigungssituation: Payrolls, Partizipationsrate,
        Beschäftigungsquote (BLS).

        Args:
            months: Anzahl der zurückliegenden Monate (1-24, Standard: 6)

        Returns:
            Nonfarm Payrolls, Partizipationsrate, Beschäftigungsquote
        """
        months = max(1, min(24, months))

        series_map = {
            "CES0000000001": "nonfarm_payrolls_thousands",
            "LNS11300000": "labor_force_participation_rate_pct",
            "LNS12300000": "employment_population_ratio_pct",
            "LNS13000000": "unemployed_persons_thousands",
        }

        results = {}
        async with httpx.AsyncClient(timeout=12.0) as client:
            for series_id, label in series_map.items():
                try:
                    resp = await client.get(f"{BLS_BASE}/{series_id}")
                    resp.raise_for_status()
                    data = resp.json()
                    raw = data.get("Results", {}).get("series", [{}])[0].get("data", [])

                    points = []
                    for dp in raw:
                        period = dp.get("period", "")
                        if period.startswith("M"):
                            points.append({
                                "date": f"{dp['year']}-{period[1:]}",
                                "value": float(dp.get("value", 0)),
                            })
                    points.sort(key=lambda x: x["date"], reverse=True)
                    results[label] = {
                        "current": points[0] if points else None,
                        "trend": points[:months],
                    }
                except Exception as e:
                    results[label] = {"error": str(e)}

        return {
            "country": "USA",
            "source": "U.S. Bureau of Labor Statistics",
            "data": results,
        }
