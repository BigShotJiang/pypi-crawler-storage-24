"""Arbeitslosigkeits-Tools — BLS (USA) und Eurostat (EU)."""

import httpx
from mcp.server.fastmcp import FastMCP

# BLS API Endpunkt (ohne Key, v1)
BLS_BASE = "https://api.bls.gov/publicAPI/v1/timeseries/data"
# Eurostat API Endpunkt
EUROSTAT_BASE = "https://ec.europa.eu/eurostat/api/dissemination/statistics/1.0/data"

# Eurostat Ländercodes (ISO 2)
EU_COUNTRIES = {
    "DE": "Deutschland", "FR": "Frankreich", "IT": "Italien",
    "ES": "Spanien", "PL": "Polen", "NL": "Niederlande",
    "BE": "Belgien", "SE": "Schweden", "AT": "Österreich",
    "DK": "Dänemark", "FI": "Finnland", "PT": "Portugal",
    "GR": "Griechenland", "CZ": "Tschechien", "RO": "Rumänien",
    "HU": "Ungarn", "SK": "Slowakei", "HR": "Kroatien",
    "EU27_2020": "EU (27 Länder)", "EA20": "Eurozone (20 Länder)",
}


def register_unemployment_tools(mcp: FastMCP):
    """Arbeitslosigkeits-Tools beim MCP-Server registrieren."""

    @mcp.tool()
    async def get_us_unemployment(months: int = 12) -> dict:
        """
        Aktuelle US-Arbeitslosenquote und historische Daten (BLS).

        Args:
            months: Anzahl der zurückliegenden Monate (1-36, Standard: 12)

        Returns:
            Aktuelle Rate, Trend, Jahresvergleich
        """
        months = max(1, min(36, months))
        url = f"{BLS_BASE}/LNS14000000"

        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                resp = await client.get(url)
                resp.raise_for_status()
                data = resp.json()

            series = data.get("Results", {}).get("series", [])
            if not series:
                return {"error": "Keine BLS-Daten verfügbar"}

            # Datenpunkte extrahieren und nach Datum sortieren
            raw = series[0].get("data", [])
            points = []
            for dp in raw:
                # Format: year=2024, period=M01 -> 2024-01
                year = dp.get("year", "")
                period = dp.get("period", "")
                if period.startswith("M"):
                    month_num = period[1:]
                    points.append({
                        "date": f"{year}-{month_num}",
                        "rate": float(dp.get("value", 0)),
                    })

            # Chronologisch sortieren (neueste zuerst)
            points.sort(key=lambda x: x["date"], reverse=True)
            recent = points[:months]

            if not recent:
                return {"error": "Keine Datenpunkte gefunden"}

            current = recent[0]
            prev_month = recent[1] if len(recent) > 1 else None
            prev_year = recent[12] if len(recent) > 12 else None

            result = {
                "country": "USA",
                "indicator": "Arbeitslosenquote (saisonbereinigt)",
                "source": "U.S. Bureau of Labor Statistics",
                "current": {
                    "date": current["date"],
                    "rate_pct": current["rate"],
                },
                "trend": recent,
            }

            if prev_month:
                result["change_vs_prev_month"] = round(current["rate"] - prev_month["rate"], 1)
            if prev_year:
                result["change_vs_prev_year"] = round(current["rate"] - prev_year["rate"], 1)

            return result

        except httpx.HTTPError as e:
            return {"error": f"BLS API Fehler: {str(e)}"}
        except Exception as e:
            return {"error": f"Fehler: {str(e)}"}

    @mcp.tool()
    async def get_eu_unemployment(country: str = "EU27_2020", months: int = 12) -> dict:
        """
        Arbeitslosenquote für EU-Länder oder die Eurozone (Eurostat).

        Args:
            country: ISO-2-Ländercode (z.B. DE, FR, ES) oder EU27_2020, EA20
            months: Anzahl der zurückliegenden Monate (1-24, Standard: 12)

        Returns:
            Aktuelle Rate und historischer Trend
        """
        country = country.upper().strip()
        if country not in EU_COUNTRIES:
            available = ", ".join(sorted(EU_COUNTRIES.keys()))
            return {
                "error": f"Unbekannter Ländercode '{country}'",
                "available_countries": available,
            }

        months = max(1, min(24, months))

        try:
            async with httpx.AsyncClient(timeout=15.0) as client:
                resp = await client.get(
                    f"{EUROSTAT_BASE}/une_rt_m",
                    params={
                        "geo": country,
                        "s_adj": "SA",      # saisonbereinigt
                        "age": "TOTAL",
                        "sex": "T",
                        "unit": "PC_ACT",   # Prozent der Erwerbsbevölkerung
                        "lang": "en",
                        "format": "JSON",
                    },
                    timeout=15.0,
                )
                resp.raise_for_status()
                data = resp.json()

            # Zeitreihen-Index extrahieren
            dimension = data.get("dimension", {})
            time_index = dimension.get("time", {}).get("category", {}).get("index", {})
            values = data.get("value", {})

            if not time_index or not values:
                return {"error": "Keine Eurostat-Daten verfügbar für dieses Land"}

            # Datenpunkte zusammenbauen
            points = []
            for time_key, idx in time_index.items():
                val = values.get(str(idx))
                if val is not None:
                    points.append({"date": time_key, "rate": float(val)})

            # Neueste zuerst
            points.sort(key=lambda x: x["date"], reverse=True)
            recent = points[:months]

            if not recent:
                return {"error": "Keine Datenpunkte nach Filterung"}

            current = recent[0]
            prev_month = recent[1] if len(recent) > 1 else None
            prev_year = recent[12] if len(recent) > 12 else None

            result = {
                "country": EU_COUNTRIES[country],
                "country_code": country,
                "indicator": "Arbeitslosenquote (saisonbereinigt)",
                "source": "Eurostat",
                "current": {
                    "date": current["date"],
                    "rate_pct": current["rate"],
                },
                "trend": recent,
            }

            if prev_month:
                result["change_vs_prev_month"] = round(current["rate"] - prev_month["rate"], 2)
            if prev_year:
                result["change_vs_prev_year"] = round(current["rate"] - prev_year["rate"], 2)

            return result

        except httpx.HTTPError as e:
            return {"error": f"Eurostat API Fehler: {str(e)}"}
        except Exception as e:
            return {"error": f"Fehler: {str(e)}"}

    @mcp.tool()
    async def compare_unemployment(countries: list = None) -> dict:
        """
        Arbeitslosigkeit mehrerer Länder/Regionen vergleichen.

        Args:
            countries: Liste von ISO-2-Ländercodes (z.B. ["DE", "FR", "ES", "EA20"])
                       Standard: ["DE", "FR", "ES", "IT", "EU27_2020"]

        Returns:
            Vergleichstabelle mit aktuellen Raten und Trends
        """
        if countries is None:
            countries = ["DE", "FR", "ES", "IT", "EU27_2020"]

        results = {}
        async with httpx.AsyncClient(timeout=15.0) as client:
            for country in countries[:8]:  # Max 8 Länder pro Abfrage
                country = country.upper().strip()
                if country not in EU_COUNTRIES:
                    results[country] = {"error": f"Unbekannter Code: {country}"}
                    continue
                try:
                    resp = await client.get(
                        f"{EUROSTAT_BASE}/une_rt_m",
                        params={
                            "geo": country,
                            "s_adj": "SA",
                            "age": "TOTAL",
                            "sex": "T",
                            "unit": "PC_ACT",
                            "lang": "en",
                            "format": "JSON",
                        },
                    )
                    resp.raise_for_status()
                    data = resp.json()

                    time_index = data.get("dimension", {}).get("time", {}).get("category", {}).get("index", {})
                    values = data.get("value", {})

                    points = []
                    for time_key, idx in time_index.items():
                        val = values.get(str(idx))
                        if val is not None:
                            points.append({"date": time_key, "rate": float(val)})

                    points.sort(key=lambda x: x["date"], reverse=True)
                    if points:
                        current = points[0]
                        prev_year = points[12] if len(points) > 12 else None
                        results[country] = {
                            "name": EU_COUNTRIES[country],
                            "latest_date": current["date"],
                            "rate_pct": current["rate"],
                            "change_vs_prev_year": round(current["rate"] - prev_year["rate"], 2) if prev_year else None,
                        }
                except Exception as e:
                    results[country] = {"error": str(e)}

        # Sortiert nach Rate
        comparison = sorted(
            [{"code": k, **v} for k, v in results.items() if "error" not in v],
            key=lambda x: x.get("rate_pct", 999),
        )

        return {
            "source": "Eurostat",
            "comparison": comparison,
            "errors": {k: v for k, v in results.items() if "error" in v},
        }
