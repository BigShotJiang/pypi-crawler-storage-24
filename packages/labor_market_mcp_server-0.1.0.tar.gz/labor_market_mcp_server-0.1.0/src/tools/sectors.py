"""Branchenanalyse und Berufsaussichten — BLS Sektordata."""

import httpx
from mcp.server.fastmcp import FastMCP

BLS_BASE = "https://api.bls.gov/publicAPI/v1/timeseries/data"

# BLS Sektoren mit Serien-IDs (Nonfarm Payrolls nach Branche)
SECTORS = {
    "mining_logging": {
        "id": "CES1000000001",
        "name": "Bergbau & Forstwirtschaft",
        "name_en": "Mining and Logging",
    },
    "construction": {
        "id": "CES2000000001",
        "name": "Baugewerbe",
        "name_en": "Construction",
    },
    "manufacturing": {
        "id": "CES3000000001",
        "name": "Verarbeitendes Gewerbe",
        "name_en": "Manufacturing",
    },
    "trade_transport": {
        "id": "CES4000000001",
        "name": "Handel, Transport & Versorgung",
        "name_en": "Trade, Transportation and Utilities",
    },
    "information": {
        "id": "CES5000000001",
        "name": "Informationstechnologie & Medien",
        "name_en": "Information",
    },
    "financial": {
        "id": "CES5500000001",
        "name": "Finanzdienstleistungen",
        "name_en": "Financial Activities",
    },
    "professional_business": {
        "id": "CES6000000001",
        "name": "Unternehmensdienstleistungen & Beratung",
        "name_en": "Professional and Business Services",
    },
    "education_health": {
        "id": "CES6500000001",
        "name": "Bildung & Gesundheit",
        "name_en": "Education and Health Services",
    },
    "leisure_hospitality": {
        "id": "CES7000000001",
        "name": "Freizeit, Gastgewerbe & Tourismus",
        "name_en": "Leisure and Hospitality",
    },
    "other_services": {
        "id": "CES8000000001",
        "name": "Sonstige Dienstleistungen",
        "name_en": "Other Services",
    },
    "government": {
        "id": "CES9000000001",
        "name": "Öffentlicher Dienst",
        "name_en": "Government",
    },
}

# Berufsaussichten — statische Daten aus BLS Occupational Outlook Handbook 2024-2025
# (Wachstum 2022-2032, gerundet)
OCCUPATION_OUTLOOK = {
    "software_developer": {
        "title": "Software Developer / Engineer",
        "median_annual_wage_usd": 132270,
        "employment_2022": 1795300,
        "projected_growth_pct": 25.0,
        "projected_new_jobs": 411400,
        "outlook": "Viel schneller als Durchschnitt",
        "ai_impact": "Hoch — AI-Tools verändern Arbeitsweise, aber Nachfrage bleibt stark",
        "top_skills": ["Python", "Cloud", "AI/ML", "System Design"],
    },
    "data_scientist": {
        "title": "Data Scientist",
        "median_annual_wage_usd": 103500,
        "employment_2022": 168900,
        "projected_growth_pct": 35.0,
        "projected_new_jobs": 18000,
        "outlook": "Viel schneller als Durchschnitt",
        "ai_impact": "Mittel — AI automatisiert Routine-Analyse, komplexe Projekte bleiben",
        "top_skills": ["Python", "Statistics", "ML", "SQL", "Visualization"],
    },
    "ai_ml_engineer": {
        "title": "AI/ML Engineer",
        "median_annual_wage_usd": 156000,
        "employment_2022": 82800,
        "projected_growth_pct": 40.0,
        "projected_new_jobs": 21000,
        "outlook": "Viel schneller als Durchschnitt",
        "ai_impact": "Positiv — Direkte Profiteure des KI-Booms",
        "top_skills": ["PyTorch", "LLMs", "MLOps", "Cloud AI", "Mathematics"],
    },
    "nurse": {
        "title": "Registered Nurse",
        "median_annual_wage_usd": 81220,
        "employment_2022": 3175700,
        "projected_growth_pct": 6.0,
        "projected_new_jobs": 193100,
        "outlook": "Schneller als Durchschnitt",
        "ai_impact": "Niedrig — Menschliche Fürsorge kaum automatisierbar",
        "top_skills": ["Patient Care", "Critical Thinking", "Communication"],
    },
    "truck_driver": {
        "title": "Heavy Truck Driver",
        "median_annual_wage_usd": 49920,
        "employment_2022": 2087000,
        "projected_growth_pct": 4.0,
        "projected_new_jobs": 63000,
        "outlook": "Langsamer als Durchschnitt (autonome Fahrzeuge)",
        "ai_impact": "Hoch — Autonomes Fahren könnte Branche mittelfristig transformieren",
        "top_skills": ["CDL License", "Route Planning", "Vehicle Maintenance"],
    },
    "accountant": {
        "title": "Accountant / Auditor",
        "median_annual_wage_usd": 79880,
        "employment_2022": 1498400,
        "projected_growth_pct": 4.0,
        "projected_new_jobs": 67400,
        "outlook": "Ähnlich wie Durchschnitt",
        "ai_impact": "Hoch — Routine-Buchhaltung stark automatisierbar",
        "top_skills": ["CPA", "Tax Law", "Audit", "Financial Analysis"],
    },
    "graphic_designer": {
        "title": "Graphic Designer",
        "median_annual_wage_usd": 57990,
        "employment_2022": 281400,
        "projected_growth_pct": 3.0,
        "projected_new_jobs": 8800,
        "outlook": "Langsamer als Durchschnitt",
        "ai_impact": "Sehr hoch — Generative AI (Midjourney, DALL-E) verändert Branche stark",
        "top_skills": ["Adobe Creative Suite", "UI/UX", "Branding", "AI Tools"],
    },
    "healthcare_manager": {
        "title": "Medical and Health Services Manager",
        "median_annual_wage_usd": 104830,
        "employment_2022": 509500,
        "projected_growth_pct": 28.0,
        "projected_new_jobs": 136200,
        "outlook": "Viel schneller als Durchschnitt",
        "ai_impact": "Niedrig bis Mittel",
        "top_skills": ["Healthcare Law", "Operations", "Budget Management"],
    },
    "electrician": {
        "title": "Electrician",
        "median_annual_wage_usd": 61590,
        "employment_2022": 762600,
        "projected_growth_pct": 11.0,
        "projected_new_jobs": 73500,
        "outlook": "Schneller als Durchschnitt",
        "ai_impact": "Niedrig — Handwerk schwer automatisierbar",
        "top_skills": ["Electrical Code", "Troubleshooting", "Safety"],
    },
    "customer_service_rep": {
        "title": "Customer Service Representative",
        "median_annual_wage_usd": 37780,
        "employment_2022": 2906200,
        "projected_growth_pct": -5.0,
        "projected_new_jobs": -77000,
        "outlook": "Rückgang — AI Chatbots ersetzen Routine-Aufgaben",
        "ai_impact": "Sehr hoch — Größte direkte Bedrohung durch LLMs",
        "top_skills": ["Communication", "CRM", "Problem Solving"],
    },
}


def register_sector_tools(mcp: FastMCP):
    """Sektor- und Berufs-Tools registrieren."""

    @mcp.tool()
    async def get_us_sector_employment(sector: str = "all", months: int = 6) -> dict:
        """
        Beschäftigungszahlen nach Branche in den USA (BLS Nonfarm Payrolls).

        Args:
            sector: Branche (mining_logging, construction, manufacturing,
                    trade_transport, information, financial, professional_business,
                    education_health, leisure_hospitality, other_services,
                    government, all)
            months: Anzahl der zurückliegenden Monate (1-24, Standard: 6)

        Returns:
            Beschäftigungstrend für gewählte Branche(n)
        """
        months = max(1, min(24, months))

        if sector == "all":
            target_sectors = SECTORS
        elif sector in SECTORS:
            target_sectors = {sector: SECTORS[sector]}
        else:
            available = ", ".join(SECTORS.keys()) + ", all"
            return {
                "error": f"Unbekannte Branche: '{sector}'",
                "available": available,
            }

        results = {}
        async with httpx.AsyncClient(timeout=15.0) as client:
            for key, info in target_sectors.items():
                try:
                    resp = await client.get(f"{BLS_BASE}/{info['id']}")
                    resp.raise_for_status()
                    data = resp.json()
                    raw = data.get("Results", {}).get("series", [{}])[0].get("data", [])

                    points = []
                    for dp in raw:
                        period = dp.get("period", "")
                        if period.startswith("M"):
                            points.append({
                                "date": f"{dp['year']}-{period[1:]}",
                                "employed_thousands": float(dp.get("value", 0)),
                            })
                    points.sort(key=lambda x: x["date"], reverse=True)
                    recent = points[:months]

                    current = recent[0] if recent else None
                    prev_year = points[12] if len(points) > 12 else None

                    results[key] = {
                        "name": info["name"],
                        "name_en": info["name_en"],
                        "current": current,
                        "yoy_change_thousands": round(
                            current["employed_thousands"] - prev_year["employed_thousands"], 1
                        ) if current and prev_year else None,
                        "trend": recent,
                    }
                except Exception as e:
                    results[key] = {"error": str(e)}

        return {
            "country": "USA",
            "source": "U.S. Bureau of Labor Statistics",
            "unit": "Tausend Beschäftigte",
            "sectors": results,
        }

    @mcp.tool()
    async def get_occupation_outlook(occupation: str = None) -> dict:
        """
        Berufsaussichten und KI-Auswirkungen für wichtige Berufsgruppen (BLS OOH 2024-2025).

        Args:
            occupation: Beruf (software_developer, data_scientist, ai_ml_engineer,
                        nurse, truck_driver, accountant, graphic_designer,
                        healthcare_manager, electrician, customer_service_rep)
                        Ohne Angabe: Übersicht aller Berufe

        Returns:
            Wachstumsprognose, Median-Gehalt, KI-Auswirkung
        """
        if occupation is None:
            # Übersicht: alle Berufe sortiert nach Wachstum
            overview = sorted(
                [{"key": k, **v} for k, v in OCCUPATION_OUTLOOK.items()],
                key=lambda x: x.get("projected_growth_pct", 0),
                reverse=True,
            )
            return {
                "source": "BLS Occupational Outlook Handbook 2024-2025",
                "projection_period": "2022-2032",
                "occupations": overview,
                "note": "Rufe mit occupation=<key> für Details auf",
            }

        if occupation not in OCCUPATION_OUTLOOK:
            available = ", ".join(OCCUPATION_OUTLOOK.keys())
            return {
                "error": f"Unbekannter Beruf: '{occupation}'",
                "available": available,
            }

        data = OCCUPATION_OUTLOOK[occupation]
        return {
            "source": "BLS Occupational Outlook Handbook 2024-2025",
            "projection_period": "2022-2032",
            **data,
        }
