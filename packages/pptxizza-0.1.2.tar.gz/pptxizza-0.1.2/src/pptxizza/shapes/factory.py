from typing import Optional, Any
from lxml import etree
from ..xml_utils import NAMESPACES

from .base_shape import BaseShape
from .shape import Shape
from .rect import Rect
from .circle import Circle
from .picture import Picture
from .graphic_frame import GraphicFrame
from .chart import Chart
from .bar_chart import BarChart
from .pie_chart import PieChart
from .line_chart import LineChart
from .table import Table

def shape_factory(element: etree._Element, slide: Optional[Any] = None) -> BaseShape:
    """
    Creates and returns the appropriate shape wrapper class based on the XML tag and internal properties.
    
    Args:
        element (etree._Element): The raw lxml element to wrap.
        slide (Slide): The origin slide wrapper. Needed to resolve complex types like detailed Charts.
        
    Returns:
        BaseShape: A specific instance subclassing BaseShape depending on the element type.
    """
    tag = element.tag
    shape: BaseShape
    
    if tag.endswith("}sp"):
        prst = element.xpath(".//a:prstGeom", namespaces=NAMESPACES)
        if prst:
            shape_type = prst[0].get("prst")
            if shape_type == "rect":
                shape = Rect(xml_element=element)
            elif shape_type == "ellipse":
                shape = Circle(xml_element=element)
            else:
                shape = Shape(xml_element=element)
        else:
            shape = Shape(xml_element=element)
            
    elif tag.endswith("}pic"):
        shape = Picture(xml_element=element)
        
    elif tag.endswith("}graphicFrame"):
        chart_refs = element.xpath(".//c:chart", namespaces=NAMESPACES)
        if chart_refs and slide is not None:
            rId = chart_refs[0].get(f"{{{NAMESPACES['r']}}}id")
            rel = slide._package.get_rels(slide.part_name).rels.get(rId)
            
            if rel:
                target = rel['Target']
                if target.startswith("../"):
                    target = target[3:]
                chart_part_name = f"ppt/{target}"
                chart_xml = slide._package.get_xml_part(chart_part_name)
                
                if chart_xml is not None:
                    if chart_xml.xpath(".//c:barChart", namespaces=NAMESPACES) or chart_xml.xpath(".//c:bar3DChart", namespaces=NAMESPACES):
                        shape = BarChart(xml_element=element)
                    elif chart_xml.xpath(".//c:pieChart", namespaces=NAMESPACES) or chart_xml.xpath(".//c:pie3DChart", namespaces=NAMESPACES):
                        shape = PieChart(xml_element=element)
                    elif chart_xml.xpath(".//c:lineChart", namespaces=NAMESPACES) or chart_xml.xpath(".//c:line3DChart", namespaces=NAMESPACES):
                        shape = LineChart(xml_element=element)
                    else:
                        shape = Chart(xml_element=element)
                else:
                    shape = Chart(xml_element=element)
            else:
                shape = Chart(xml_element=element)
        else:
            shape = GraphicFrame(xml_element=element)
            if shape.is_chart():
                shape = Chart(xml_element=element)
            elif shape.is_table():
                shape = Table(xml_element=element)
                
    else:
        shape = BaseShape(xml_element=element)
        
    shape.slide = slide
    return shape
