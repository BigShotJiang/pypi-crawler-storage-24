from lxml import etree
from typing import Optional, Union
from ..util import Length
from ..xml_utils import xpath, NAMESPACES, parse_xml
from .base_shape import BaseShape
from .format import FontFormat

class Shape(BaseShape):
    """
    Represents a standard AutoShape or TextBox (<p:sp>).
    """
    def __init__(self, text: str = "", x: Union[int, Length] = 0, y: Union[int, Length] = 0, cx: Union[int, Length] = 0, cy: Union[int, Length] = 0, xml_element: Optional[etree._Element] = None) -> None:
        """
        Initializes a Textbox Shape that can be added to a Presentation slide.
        
        Args:
            text (str): Optional initial text.
            x (int): Optional initial X coordinate in EMUs.
            y (int): Optional initial Y coordinate in EMUs.
            cx (int): Optional initial width in EMUs.
            cy (int): Optional initial height in EMUs.
            xml_element (Optional[etree._Element]): Existing XML node to wrap. If None, it creates a new one.
        """
        if xml_element is None:
            shape_xml = f'''
            <p:sp xmlns:a="{NAMESPACES["a"]}" xmlns:p="{NAMESPACES["p"]}">
                <p:nvSpPr>
                    <p:cNvPr id="0" name="TextBox"/>
                    <p:cNvSpPr txBox="1"/>
                    <p:nvPr/>
                </p:nvSpPr>
                <p:spPr>
                    <a:xfrm>
                        <a:off x="{int(x)}" y="{int(y)}"/>
                        <a:ext cx="{int(cx)}" cy="{int(cy)}"/>
                    </a:xfrm>
                    <a:prstGeom prst="rect">
                        <a:avLst/>
                    </a:prstGeom>
                    <a:noFill/>
                </p:spPr>
                <p:txBody>
                    <a:bodyPr wrap="square" rtlCol="0" anchor="t"/>
                    <a:lstStyle/>
                    <a:p>
                        <a:r>
                            <a:rPr lang="en-US"/>
                            <a:t>{text}</a:t>
                        </a:r>
                    </a:p>
                </p:txBody>
            </p:sp>
            '''
            xml_element = parse_xml(shape_xml.encode('utf-8'))
        super().__init__(xml_element)
    
    @property
    def text(self) -> str:
        """
        Gets or sets the text inside the shape. 
        Note that getting the text extracts all unformatted text nodes and joins them.
        Setting the text with a string replaces the first paragraph's text and clears others.
        Setting the text with a Text object completely replaces the text formatting structure.
        
        Returns:
            str: The raw text content of the shape.
        """
        texts = xpath(self._element, ".//a:t/text()")
        return "".join(texts)

    @text.setter
    def text(self, value: Union[str, 'Any']) -> None:
        from ..text import Text
        if isinstance(value, Text):
            txBody = xpath(self._element, ".//p:txBody")
            if txBody:
                paragraphs = xpath(txBody[0], "a:p")
                for p in paragraphs:
                    txBody[0].remove(p)
                txBody[0].append(value.to_xml_element())
        else:
            t_nodes = xpath(self._element, ".//a:t")
            if t_nodes:
                t_nodes[0].text = value
                # Clear out others
                for node in t_nodes[1:]:
                    parent = node.getparent()
                    if parent is not None:
                        parent.remove(node)

    @property
    def font(self) -> FontFormat:
        """
        Gets the FontFormat object for this shape, allowing styling of text size, color, and font name.
        
        Returns:
            FontFormat: The format object to adjust typography.
        """
        return FontFormat(self)
