from pathlib import Path

import pytest

from juist.justfiles.models import ParameterKind, Scope
from juist.justfiles.parser import JustfileParser


@pytest.fixture
def data_justfile() -> Path:
    return Path(__file__).parent / "data" / "justfile"


def test_parse_justfile(data_justfile):
    source = JustfileParser().parse(data_justfile, Scope.local)

    assert source.name == "justfile"
    assert source.path == data_justfile

    recipes = {r.name: r for r in source.recipes}
    assert set(recipes) == {"bootstrap", "upgrade-deps", "script1", "script2"}

    assert recipes["bootstrap"].doc == "Set up development environment"
    assert recipes["bootstrap"].parameters == []
    assert recipes["bootstrap"].dependencies == []

    assert recipes["upgrade-deps"].dependencies == ["bootstrap"]

    assert recipes["script1"].parameters == []

    args = recipes["script2"].parameters[0]
    assert args.name == "ARGS"
    assert args.kind == ParameterKind.variadic
    assert args.default is None


def test_parse_justfile_not_found():
    with pytest.raises(FileNotFoundError):
        JustfileParser().parse(Path("nonexistent/justfile"), Scope.local)
