from pathlib import Path

from juist.justfiles.parser import JustfileParser

source = JustfileParser().parse(Path("justfile"))

print(source.model_dump_json(indent=2))
