# juist

[![Release](https://img.shields.io/github/v/release/fpgmaas/juist)](https://img.shields.io/github/v/release/fpgmaas/juist)
[![Build status](https://img.shields.io/github/actions/workflow/status/fpgmaas/juist/main.yml?branch=main)](https://github.com/fpgmaas/juist/actions/workflows/main.yml?query=branch%3Amain)
[![Commit activity](https://img.shields.io/github/commit-activity/m/fpgmaas/juist)](https://img.shields.io/github/commit-activity/m/fpgmaas/juist)
[![License](https://img.shields.io/github/license/fpgmaas/juist)](https://img.shields.io/github/license/fpgmaas/juist)

This is a template repository for Python projects that use uv for their dependency management.
