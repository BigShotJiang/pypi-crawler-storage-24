"""Textual agent workspace shell with split-pane layout (PR-C gated path)."""

from __future__ import annotations

import asyncio
import base64
import inspect
import json
import re
import shlex
import time
from collections.abc import Callable, Sequence
from dataclasses import dataclass
from secrets import SystemRandom
from textwrap import wrap
from typing import TYPE_CHECKING, Any, Literal, cast

from rich.errors import MarkupError as _MarkupError
from rich.markup import escape as _escape_markup
from rich.table import Table as RichTable
from rich.text import Text as RichText

from glaip_sdk._version import __version__ as SDK_VERSION
from glaip_sdk.branding import ERROR as _DANGER_COLOR
from glaip_sdk.cli.constants import MASK_SENSITIVE_FIELDS
from glaip_sdk.cli.slash.tui.agent_model_picker_app import (
    AgentModelPickerInput,
    AgentModelPickerScreen,
)
from glaip_sdk.cli.slash.tui.agent_tools_picker_app import (
    AgentResourcePickerInput,
    AgentToolsPickerScreen,
)
from glaip_sdk.cli.slash.tui.agent_workspace_foundation import (
    AGENT_WORKSPACE_THEME,
    MODEL_LABEL_PLACEHOLDER,
    format_summary_rows,
    format_utc_timestamp,
    get_workspace_logo_text,
    workspace_label,
)
from glaip_sdk.cli.slash.tui.agent_workspace_shell_styles import build_workspace_css
from glaip_sdk.cli.slash.tui.background_tasks import cancel_worker_group
from glaip_sdk.cli.slash.tui.command_palette import (
    PaletteAction,
    build_palette_actions,
    filter_palette_actions,
    get_palette_action_static_metadata,
    get_palette_slash_static_metadata,
)
from glaip_sdk.cli.slash.tui.page_chrome import (
    PageChrome,
    get_page_chrome,
)
from glaip_sdk.cli.slash.tui.screenshot_capture import WorkspaceScreenshotCaptureMixin

try:  # pragma: no cover - optional dependency guard
    from glaip_sdk.cli.slash.tui.indicators import PulseIndicator as _PulseIndicator
except Exception:  # pragma: no cover - textual unavailable
    _PulseIndicator = None

try:  # pragma: no cover - optional dependency guard
    from glaip_sdk.cli.slash.tui.toast import ClipboardToastMixin as _ClipboardToastMixin

    ClipboardToastMixin = _ClipboardToastMixin  # type: ignore[assignment]
except Exception:  # pragma: no cover - textual unavailable

    class ClipboardToastMixin:  # type: ignore[no-redef]
        """Fallback mixin when Textual is unavailable."""

        def _copy_to_clipboard(self, text: str, *, label: str | None = None) -> None:
            """No-op fallback."""
            pass


try:  # pragma: no cover - optional dependency guard
    from glaip_sdk.cli.slash.tui.keybind_shortcuts import close_shortcuts as _close_shortcuts
except Exception:  # pragma: no cover - textual unavailable
    _close_shortcuts = None

if TYPE_CHECKING:  # pragma: no cover - typing only
    from textual.app import App, ComposeResult
    from textual.binding import Binding
    from textual.containers import Container, Horizontal, Vertical
    from textual.events import Key
    from textual.reactive import reactive
    from textual.widgets import Button, Static, TextArea
    from textual.widgets import Input as TextInput
    from textual.worker import Worker, WorkerState
else:  # pragma: no cover - textual unavailable
    try:
        from textual.app import App, ComposeResult
        from textual.binding import Binding
        from textual.containers import Container, Horizontal, Vertical
        from textual.reactive import reactive
        from textual.widgets import Button, Static, TextArea
        from textual.widgets import Input as TextInput
        from textual.worker import Worker, WorkerState
    except Exception:  # pragma: no cover - textual unavailable
        App = None  # type: ignore[assignment]
        ComposeResult = None  # type: ignore[assignment]
        Binding = None  # type: ignore[assignment]
        Button = None  # type: ignore[assignment]
        Container = None  # type: ignore[assignment]
        Horizontal = None  # type: ignore[assignment]
        Vertical = None  # type: ignore[assignment]
        TextInput = None  # type: ignore[assignment]
        Static = None  # type: ignore[assignment]
        TextArea = None  # type: ignore[assignment]
        Worker = None  # type: ignore[assignment]
        WorkerState = None  # type: ignore[assignment]
        reactive = None  # type: ignore[assignment]


TEXTUAL_SUPPORTED = App is not None and TextArea is not None and Static is not None and Button is not None

APP_QUIT_ACTION = "app.quit"
COMPOSER_ID = "workspace-composer"
TRANSCRIPT_ID = "messages"
DETAILS_ID = "agent-info"
SIDEBAR_ID = "right-sidebar"
LEFT_COLUMN_ID = "left-column"
AGENT_CONTEXT_NAME_ID = "agent-context-name"
AGENT_CONTEXT_ACCOUNT_ID = "agent-context-account"
HOME_CONTEXT_BRAND_ID = "home-context-brand"
HOME_CONTEXT_ACCOUNT_ID = "home-context-account"
HOME_CONTEXT_BLOCK_ID = "home-context-block"
HEADER_ROW_ID = "header-row"
CONTEXT_BLOCK_ID = "context-block"
TRANSCRIPT_SCROLL_ID = "messages-scroll"
KEYBAR_ROW_ID = "keybar-row"
KEYBAR_LEFT_ID = "keybar-left"
KEYBAR_RIGHT_ID = "keybar-right"
COMMAND_LOADING_ID = "command-loading"
SLASH_WRAP_ID = "slash-wrap"
SLASH_ROWS_ID = "slash-rows"
PALETTE_WRAP_ID = "palette-wrap"
PALETTE_ROWS_ID = "palette-rows"
PALETTE_SEARCH_ID = "palette-search"
PALETTE_SECTION_ID = "palette-section"
TRANSCRIPT_MAX_LINES = 500

WorkspaceEventKind = Literal["message", "command", "exit"]
WorkspaceSlashRoute = Literal["transition", "inline_status", "exit"]
WorkspaceShellMode = Literal["agent", "home"]
StatusSummaryProvider = Callable[[], list[str]] | Callable[[list[str]], list[str]]
DetailsProvider = Callable[[], list[str]]
TranscriptSink = Callable[[list[str]], None]
MessageRunProvider = Callable[..., str | tuple[str, list[str]] | None]
ModelPickerProvider = Callable[[], AgentModelPickerInput]
ResourcePickerProvider = Callable[[], AgentResourcePickerInput]
ModelApplyProvider = Callable[[str], Any]
ResourceApplyProvider = Callable[[list[str]], Any]


@dataclass(frozen=True)
class AgentWorkspacePickerBindings:
    """Picker providers/apply handlers bundled for the agent workspace shell."""

    model_picker_provider: ModelPickerProvider | None = None
    model_apply_provider: ModelApplyProvider | None = None
    tools_picker_provider: ResourcePickerProvider | None = None
    tools_apply_provider: ResourceApplyProvider | None = None
    mcps_picker_provider: ResourcePickerProvider | None = None
    mcps_apply_provider: ResourceApplyProvider | None = None


WORKSPACE_THEME = AGENT_WORKSPACE_THEME
WORKSPACE_CAPTURE_PATH_ENV = WorkspaceScreenshotCaptureMixin.CAPTURE_PATH_ENV
WORKSPACE_CAPTURE_DELAY_ENV = WorkspaceScreenshotCaptureMixin.CAPTURE_DELAY_ENV
COMMAND_TRANSITION_DELAY_SECONDS = 0.35
INLINE_RUNNING_TICK_SECONDS = 1.0
ESCAPE_CONFIRM_TIMEOUT_SECONDS = 2.5
WORKSPACE_INLINE_WORKER_GROUP = "workspace-inline"
_ANSI_RE = re.compile(r"\x1B\[[0-?]*[ -/]*[@-~]")
_MD_INLINE_CODE_RE = re.compile(r"`([^`\n]+)`")
_MD_BOLD_RE = re.compile(r"\*\*([^*\n]+)\*\*")
_MD_ITALIC_RE = re.compile(r"(?<!\*)\*([^*\n]+)\*(?!\*)")
_HTTP_URL_RE = re.compile(r"https?://[^\s<>{}\[\]`*]+", re.IGNORECASE)
_WORKSPACE_EXIT_COMMAND = "/exit"
_DETAILS_COMMAND = "/details"
_PROMPT_COMMAND = "/prompt"
_MODELS_COMMAND = "/models"
_TOOLS_COMMAND = "/tools"
_MCPS_COMMAND = "/mcps"
_HELP_COMMAND = "/help"
_RUNS_COMMAND = "/runs"
_SCHEDULES_COMMAND = "/schedules"
_STATUS_COMMAND = "/status"
_Q_EXIT_COMMAND = "/q"
_AGENTS_COMMAND = "/agents"
_ACCOUNTS_COMMAND = "/accounts"
_TRANSCRIPTS_COMMAND = "/transcripts"
_UPDATE_COMMAND = "/update"
_ESCAPE_CONFIRM_BACK = "back"
_ESCAPE_CONFIRM_EXIT_TERMINAL = "exit_terminal"
_DETAILS_SENTINEL = "\u0000DETAILS\u0000"
_RUN_DIVIDER_SENTINEL = "\u0000RUN\u0000"
_DETAILS_KEY_COLOR = WORKSPACE_THEME["accent"]
_DETAILS_VALUE_DIM = WORKSPACE_THEME["info"]


@dataclass(frozen=True)
class _WorkspaceSlashCommand:
    """Slash command metadata for workspace routing and dropdown inventory."""

    name: str
    description: str
    route: WorkspaceSlashRoute = "transition"
    visible_in_dropdown: bool = True
    aliases: tuple[str, ...] = ()


_AGENT_WORKSPACE_SLASH_COMMANDS: tuple[_WorkspaceSlashCommand, ...] = (
    _WorkspaceSlashCommand(_DETAILS_COMMAND, "Show selected agent details"),
    _WorkspaceSlashCommand(_MCPS_COMMAND, "Attach or detach MCPs inline"),
    _WorkspaceSlashCommand(_MODELS_COMMAND, "Change the active agent model inline"),
    _WorkspaceSlashCommand(_PROMPT_COMMAND, "Edit selected agent prompt"),
    _WorkspaceSlashCommand(_RUNS_COMMAND, "Browse remote run history"),
    _WorkspaceSlashCommand(_SCHEDULES_COMMAND, "Manage recurring schedules"),
    _WorkspaceSlashCommand(_STATUS_COMMAND, "Show quick diagnostics", route="inline_status"),
    _WorkspaceSlashCommand(_TOOLS_COMMAND, "Attach or detach tools inline"),
    _WorkspaceSlashCommand(_TRANSCRIPTS_COMMAND, "Review transcript cache"),
    _WorkspaceSlashCommand(_HELP_COMMAND, "Show slash command help", visible_in_dropdown=True, aliases=("/?",)),
    _WorkspaceSlashCommand(_WORKSPACE_EXIT_COMMAND, "Exit workspace context", route="exit"),
    _WorkspaceSlashCommand(_Q_EXIT_COMMAND, "Exit workspace context", route="exit"),
)

_HOME_WORKSPACE_SLASH_COMMANDS: tuple[_WorkspaceSlashCommand, ...] = (
    _WorkspaceSlashCommand(_ACCOUNTS_COMMAND, "Manage accounts"),
    _WorkspaceSlashCommand(_AGENTS_COMMAND, "Open agent selector"),
    _WorkspaceSlashCommand(_STATUS_COMMAND, "Show connection diagnostics", route="inline_status"),
    _WorkspaceSlashCommand(_HELP_COMMAND, "Show command help", aliases=("/?",), visible_in_dropdown=False),
    _WorkspaceSlashCommand(_TRANSCRIPTS_COMMAND, "Review transcript cache"),
    _WorkspaceSlashCommand(_UPDATE_COMMAND, "Upgrade CLI package"),
    _WorkspaceSlashCommand(_WORKSPACE_EXIT_COMMAND, "Close slash home", route="exit"),
    _WorkspaceSlashCommand(_Q_EXIT_COMMAND, "Close slash home", route="exit"),
)


def _build_workspace_command_index(
    commands: tuple[_WorkspaceSlashCommand, ...],
) -> dict[str, _WorkspaceSlashCommand]:
    """Build token->command metadata map for routing and validation."""
    index: dict[str, _WorkspaceSlashCommand] = {}
    for command in commands:
        for token in (command.name, *command.aliases):
            lowered = token.lower()
            existing = index.get(lowered)
            if existing is not None and existing is not command:
                raise ValueError(f"Duplicate workspace slash command token: {token}")
            index[lowered] = command
    return index


def _build_workspace_dropdown_commands(commands: tuple[_WorkspaceSlashCommand, ...]) -> tuple[tuple[str, str], ...]:
    """Build sorted dropdown inventory from slash command metadata."""
    return tuple(
        (command.name, command.description)
        for command in sorted(
            (item for item in commands if item.visible_in_dropdown),
            key=lambda item: item.name.lower(),
        )
    )


_WORKSPACE_SLASH_COMMANDS_BY_MODE: dict[WorkspaceShellMode, tuple[_WorkspaceSlashCommand, ...]] = {
    "agent": _AGENT_WORKSPACE_SLASH_COMMANDS,
    "home": _HOME_WORKSPACE_SLASH_COMMANDS,
}

_WORKSPACE_COMMAND_INDEX_BY_MODE: dict[WorkspaceShellMode, dict[str, _WorkspaceSlashCommand]] = {
    mode: _build_workspace_command_index(commands) for mode, commands in _WORKSPACE_SLASH_COMMANDS_BY_MODE.items()
}

_WORKSPACE_ALLOWED_SLASH_COMMANDS_BY_MODE: dict[WorkspaceShellMode, frozenset[str]] = {
    mode: frozenset(token for token, command in command_index.items() if command.route != "exit")
    for mode, command_index in _WORKSPACE_COMMAND_INDEX_BY_MODE.items()
}

_WORKSPACE_DROPDOWN_COMMANDS_BY_MODE: dict[WorkspaceShellMode, tuple[tuple[str, str], ...]] = {
    mode: _build_workspace_dropdown_commands(commands) for mode, commands in _WORKSPACE_SLASH_COMMANDS_BY_MODE.items()
}

# Backward-compatible aliases for existing tests and runtime call sites.
_WORKSPACE_SLASH_COMMANDS = _WORKSPACE_SLASH_COMMANDS_BY_MODE["agent"]
_WORKSPACE_COMMAND_INDEX = _WORKSPACE_COMMAND_INDEX_BY_MODE["agent"]
_WORKSPACE_ALLOWED_SLASH_COMMANDS = _WORKSPACE_ALLOWED_SLASH_COMMANDS_BY_MODE["agent"]
_WORKSPACE_DROPDOWN_COMMANDS = _WORKSPACE_DROPDOWN_COMMANDS_BY_MODE["agent"]
_TIP_RANDOM = SystemRandom()

_TRANSCRIPT_USER_FG = "#d9e4f2"
_TRANSCRIPT_USER_BG = "#1a2431"
_TRANSCRIPT_USER_TEXT = "#d3dfed"
_TRANSCRIPT_COMMAND_FG = "#f2d7a7"
_TRANSCRIPT_COMMAND_BG = "#2a2118"
_TRANSCRIPT_STATUS_FG = "#c7d8ca"
_TRANSCRIPT_STATUS_BG = "#1c2a21"
_TRANSCRIPT_SYSTEM_FG = "#c7d0dc"
_TRANSCRIPT_SYSTEM_BG = "#1f2733"
_TRANSCRIPT_AGENT_FG = "#d7e3f4"
_TRANSCRIPT_AGENT_BG = "#1b2532"
_TRANSCRIPT_AGENT_TEXT = "#cfdcf1"
_TRANSCRIPT_AGENT_HERO_BG = "#22364d"
_TRANSCRIPT_AGENT_HERO_TEXT = "#eaf3ff"
_TRANSCRIPT_AGENT_CODE_FG = "#b9d7ff"
_TRANSCRIPT_AGENT_CODE_BG = "#152336"
_TRANSCRIPT_USER_LABEL = "USER>"
_TRANSCRIPT_AGENT_LABEL = "AGENT>"
_TRANSCRIPT_STEP_TOOL = "#8fc8e8"
_TRANSCRIPT_STEP_PARAM = "#8fa0b3"
_TRANSCRIPT_STEP_FINAL = "#8fc79f"
_TRANSCRIPT_STEP_KEY = "#a9d2ff"
_TRANSCRIPT_STEP_MUTED = "#8fa0b3"
_RUN_FAILED_PREFIX = "run failed:"
_MAX_VISIBLE_SLASH_ROWS = 9
_MAX_VISIBLE_PALETTE_ROWS = 9
_MAX_PALETTE_WIDTH = 72
_MIN_PALETTE_WIDTH = 20
_PALETTE_SIDE_GUTTER = 4
_PALETTE_CHROME_WIDTH = 6
_PALETTE_ROW_INSET = 1
_TOOL_PARAMS_MAX_LINES = 14
_TOOL_PARAMS_MAX_LINE_LEN = 220
_ACTIVITY_DETAIL_MAX_LEN = 260
_STREAM_STATUS_CALLBACK_ARG = "stream_status_callback"
_STREAM_REPLY_CALLBACK_ARG = "stream_reply_callback"
_SLASH_COMMAND_TOKEN_RE = re.compile(r"(?<![/\w])(/[a-z?][a-z0-9_-]*)(?![\w-])", re.IGNORECASE)
_AGENT_TAG_TOKEN_RE = re.compile(r"\^(\d+)")
_BRACKETED_AGENT_NAME_RE = re.compile(r"\[([A-Za-z][A-Za-z0-9_.-]*)\]")
_LEADING_AGENT_NAME_RE = re.compile(r"^\s*([A-Za-z][A-Za-z0-9_.-]*)")
_SUPERSCRIPT_DIGIT_MAP = str.maketrans("0123456789", "⁰¹²³⁴⁵⁶⁷⁸⁹")

_HOME_HEADER_BRAND_TEXT = "GL AIP"
_LOGO_BASE = "#005cb8"
_LOGO_GLOW = "#40b4e5"
_LOGO_PEAK = "#ffffff"
_LOGO_TICK_SECONDS = 0.11
_LOGO_EDGE_PAUSE_SECONDS = 1.0
_AGENT_TAG_COLOR = WORKSPACE_THEME["heading"]
_SELECTED_ROW_STYLE = "bold #2b1600 on #f2b266"

# Activity type prefixes (extracted to avoid literal duplication)
_PREFIX_TOOL = "tool:"
_PREFIX_TOOL_CALL = "tool_call:"
_PREFIX_TOOL_RESULT = "tool_result:"
_PREFIX_TOOL_DONE = "tool_done:"
_PREFIX_HANDOFF = "handoff:"
_PREFIX_SUBAGENT = "subagent:"
_PREFIX_TOOL_PARAMS = "tool_params:"
_PREFIX_STATUS = "status:"
_PREFIX_RUN = "run:"
_PREFIX_RUN_RESULT = "run_result:"
_PREFIX_REASONING = "reasoning:"
_PREFIX_ACTION = "action:"
_PREFIX_FINAL = "final:"
_PREFIX_COMPLETED_IN = "completed in "
_PREFIX_FINISHED_IN = "finished in "
_PREFIX_RUNNING = "[~] running"
_PREFIX_TOKEN_USAGE = "token usage:"
_PREFIX_RUNNING_TEXT = "Running..."
_PREFIX_TITLE = "#title"


def _get_workspace_label() -> str:
    return workspace_label()


def _highlight_slash_commands(text: str) -> str:
    """Highlight slash command tokens using the command chip palette."""
    escaped_text = str(text or "")
    if "/" not in escaped_text:
        return escaped_text

    def _replace(match: re.Match[str]) -> str:
        token = match.group(1)
        return f"[{_TRANSCRIPT_COMMAND_FG} on {_TRANSCRIPT_COMMAND_BG}]{token}[/]"

    return _SLASH_COMMAND_TOKEN_RE.sub(_replace, escaped_text)


def _escape_with_slash_highlights(text: str) -> str:
    """Escape Rich markup and apply slash-command highlighting."""
    return _highlight_slash_commands(_escape_markup(str(text or "")))


def _agent_tag_for_name(name: str, agent_tags: dict[str, int]) -> str:
    """Return stable `name^N` label for one delegated agent name."""
    cleaned = str(name or "").strip()
    if not cleaned:
        return cleaned
    current = agent_tags.get(cleaned)
    if current is None:
        current = len(agent_tags) + 1
        agent_tags[cleaned] = current
    return f"{cleaned}^{current}"


def _tag_bracketed_agent_names(text: str, agent_tags: dict[str, int]) -> str:
    """Tag owner labels in `[agent_name]` blocks."""

    def _replace(match: re.Match[str]) -> str:
        name = match.group(1)
        return f"[{_agent_tag_for_name(name, agent_tags)}]"

    return _BRACKETED_AGENT_NAME_RE.sub(_replace, text)


def _tag_leading_agent_name(text: str, agent_tags: dict[str, int]) -> str:
    """Tag the leading delegated agent token while preserving suffix details."""
    raw_text = str(text or "")
    match = _LEADING_AGENT_NAME_RE.match(raw_text)
    if match is None:
        return text
    start, end = match.span(1)
    name = match.group(1)
    tagged_name = _agent_tag_for_name(name, agent_tags)
    return f"{raw_text[:start]}{tagged_name}{raw_text[end:]}"


def _annotate_activity_agent_tags(activity: str, agent_tags: dict[str, int] | None) -> str:
    """Inject stable `^N` markers for delegated agent labels in activity rows."""
    if agent_tags is None:
        return activity

    lowered = str(activity or "").strip().lower()
    if lowered.startswith((_PREFIX_TOOL, _PREFIX_TOOL_CALL, _PREFIX_TOOL_RESULT, _PREFIX_TOOL_DONE)):
        prefix, detail = activity.split(":", 1)
        return f"{prefix}: {_tag_bracketed_agent_names(detail.strip(), agent_tags)}"
    if lowered.startswith((_PREFIX_HANDOFF, _PREFIX_SUBAGENT)):
        prefix, detail = activity.split(":", 1)
        tagged = _tag_bracketed_agent_names(detail.strip(), agent_tags)
        tagged = _tag_leading_agent_name(tagged, agent_tags)
        return f"{prefix}: {tagged}"
    return activity


def _render_agent_tag_superscripts(text: str) -> str:
    """Render `^N` markers as light superscript tags in transcript rows."""

    def _replace(match: re.Match[str]) -> str:
        digits = str(match.group(1)).translate(_SUPERSCRIPT_DIGIT_MAP)
        return f"[{_AGENT_TAG_COLOR}]{digits}[/]"

    return _AGENT_TAG_TOKEN_RE.sub(_replace, str(text or ""))


def _next_logo_pulse_state(step: int, direction: int, max_width: int, step_size: int) -> tuple[int, int, bool]:
    """Compute next logo pulse step and edge reversal state."""
    low_edge = -4
    high_edge = max_width + 4
    next_step = step + (direction * step_size)
    reversed_edge = False
    next_direction = direction

    if next_step > high_edge:
        overflow = next_step - high_edge
        next_step = high_edge - overflow
        next_direction = -1
        reversed_edge = True
    elif next_step < low_edge:
        overflow = low_edge - next_step
        next_step = low_edge + overflow
        next_direction = 1
        reversed_edge = True
    return next_step, next_direction, reversed_edge


def _logo_style_for_distance(distance: int) -> str:
    """Return logo style token for pulse distance."""
    if distance <= 0:
        return f"bold {_LOGO_PEAK}"
    if distance == 1:
        return f"bold {_LOGO_GLOW}"
    if distance == 2:
        return "bold #31b2eb"
    return f"bold {_LOGO_BASE}"


def _render_shining_logo(lines: Sequence[str], pulse_step: int) -> RichText:
    """Render logo lines with moving shine band at pulse step."""
    logo = RichText()
    for line_index, line in enumerate(lines):
        for column_index, char in enumerate(line):
            if char == " ":
                logo.append(" ")
                continue
            distance = abs(column_index - pulse_step)
            logo.append(char, style=_logo_style_for_distance(distance))
        if line_index < len(lines) - 1:
            logo.append("\n")
    return logo


def _map_logo_pulse_step(step: int, source_width: int, target_width: int) -> int:
    """Map pulse step from one logo width domain into another."""
    if source_width <= 0 or target_width <= 0:
        return step
    source_span = source_width + 8
    target_span = target_width + 8
    normalized = (step + 4) / source_span
    return int(round((normalized * target_span) - 4))


@dataclass(frozen=True)
class AgentWorkspaceDetails:
    """Resolved agent metadata shown in workspace shell."""

    id: str
    name: str
    account_id: str = ""
    description: str = ""
    type: str = ""
    framework: str = ""
    version: str = ""
    model_label: str = ""
    tools_summary: str = "0"
    mcps_summary: str = "0"
    sub_agents_summary: str = "0"
    tool_ids: tuple[str, ...] = ()
    mcp_ids: tuple[str, ...] = ()
    tool_names: tuple[str, ...] = ()
    mcp_names: tuple[str, ...] = ()
    sub_agent_names: tuple[str, ...] = ()
    updated_at: str = ""


@dataclass(frozen=True)
class AgentWorkspaceEvent:
    """Result emitted by the workspace shell."""

    kind: WorkspaceEventKind
    value: str = ""


def _wrap_multiline(value: str, *, width: int, break_on_hyphens: bool = True) -> str:
    if not value:
        return "-"
    lines = wrap(value, width=width, break_long_words=True, break_on_hyphens=break_on_hyphens)
    return "\n".join(lines) if lines else value


def _summary_count(value: str) -> str:
    token = (value or "").strip().split(" ", 1)[0]
    return token if token.isdigit() else value.strip() or "0"


def _resource_summary_count_for_command(command_text: str, details: AgentWorkspaceDetails) -> int | None:
    """Return the refreshed sidebar count for the resource command that just saved."""
    if command_text == _TOOLS_COMMAND:
        token = _summary_count(details.tools_summary)
        return int(token) if token.isdigit() else None
    if command_text == _MCPS_COMMAND:
        token = _summary_count(details.mcps_summary)
        return int(token) if token.isdigit() else None
    return None


def _resource_ids_for_command(command_text: str, details: AgentWorkspaceDetails) -> tuple[str, ...] | None:
    """Return refreshed resource ids when workspace details include identity data."""
    if command_text == _TOOLS_COMMAND:
        resource_ids = tuple(sorted(item for item in details.tool_ids if item))
        if resource_ids:
            return resource_ids
        token = _summary_count(details.tools_summary)
        if details.tool_names or (token.isdigit() and int(token) > 0):
            return None
        return ()
    if command_text == _MCPS_COMMAND:
        resource_ids = tuple(sorted(item for item in details.mcp_ids if item))
        if resource_ids:
            return resource_ids
        token = _summary_count(details.mcps_summary)
        if details.mcp_names or (token.isdigit() and int(token) > 0):
            return None
        return ()
    return None


def _resource_name_summary_for_command(command_text: str, details: AgentWorkspaceDetails) -> str:
    """Summarize refreshed resource labels for status messages."""
    if command_text == _TOOLS_COMMAND:
        names = [name for name in details.tool_names if name]
    elif command_text == _MCPS_COMMAND:
        names = [name for name in details.mcp_names if name]
    else:
        names = []
    if not names:
        return "none"
    preview = names[:3]
    suffix = "" if len(names) <= 3 else f", +{len(names) - 3} more"
    return ", ".join(preview) + suffix


def _summarize_pending_resource_names(payload: AgentResourcePickerInput, selected_ids: Sequence[str]) -> str:
    """Summarize selected resource labels for loading and saved status messages."""
    selected_set = {item for item in selected_ids if item}
    names = [option.label for option in payload.options if option.id in selected_set]
    if not names:
        return "none"
    preview = names[:3]
    suffix = "" if len(names) <= 3 else f", +{len(names) - 3} more"
    return ", ".join(preview) + suffix


def _sample_workspace_tip_order(count: int) -> list[int]:
    """Return a securely randomized permutation for idle workspace tips."""
    return _TIP_RANDOM.sample(list(range(count)), k=count)


def _format_named_list(*, title: str, items: tuple[str, ...], color: str) -> str:
    heading = WORKSPACE_THEME["heading"]
    muted = WORKSPACE_THEME["muted"]
    value_color = WORKSPACE_THEME["info"]
    header = f"[bold {heading}]{_escape_markup(title)}[/]"
    if not items:
        return f"{header}\n[{muted}]- none[/]"

    max_items = 5
    rendered = [f"[{color}]•[/] [{value_color}]{_escape_markup(name)}[/]" for name in items[:max_items]]
    extra = len(items) - max_items
    if extra > 0:
        rendered.append(f"[{muted}]• +{extra} more[/]")
    return "\n".join([header, *rendered])


def _format_details_section(title: str, body: str) -> str:
    heading = WORKSPACE_THEME["heading"]
    return f"[bold {heading}]{_escape_markup(title)}[/]\n{body}"


def _format_details(details: AgentWorkspaceDetails) -> str:
    key_color = WORKSPACE_THEME["accent"]
    value_color = WORKSPACE_THEME["info"]
    model_label = _escape_markup(details.model_label or MODEL_LABEL_PLACEHOLDER)
    overview = format_summary_rows(
        [
            ("id", details.id or "-"),
            ("description", _escape_markup(details.description or "-")),
            ("type", details.type or "config"),
            ("framework", details.framework or "-"),
            ("version", details.version or "-"),
            ("model", model_label),
            ("updated_at", format_utc_timestamp(details.updated_at)),
        ],
        key_color=key_color,
        value_color=value_color,
    )

    tools = _format_named_list(
        title=f"Tools ({_summary_count(details.tools_summary)})",
        items=details.tool_names,
        color=WORKSPACE_THEME["tools"],
    )
    mcps = _format_named_list(
        title=f"MCPs ({_summary_count(details.mcps_summary)})",
        items=details.mcp_names,
        color=WORKSPACE_THEME["mcps"],
    )
    sub_agents = _format_named_list(
        title=f"Sub-agents ({_summary_count(details.sub_agents_summary)})",
        items=details.sub_agent_names,
        color=WORKSPACE_THEME["heading"],
    )
    return "\n\n".join([_format_details_section("Overview", overview), tools, mcps, sub_agents])


def _format_sidebar_header(details: AgentWorkspaceDetails) -> str:
    name = _escape_markup(details.name or "-")
    account = _wrap_multiline(_escape_markup(details.account_id or "-"), width=44)
    account_color = WORKSPACE_THEME["account"]
    heading = WORKSPACE_THEME["heading"]
    return f"[bold {heading}]{name}[/]\n[{account_color}]{account}[/]"


def _format_agent_context_name(details: AgentWorkspaceDetails) -> str:
    return _escape_markup(details.name or "-")


def _format_agent_context_account(details: AgentWorkspaceDetails) -> str:
    account_color = WORKSPACE_THEME["account"]
    return f"[{account_color}]{_escape_markup(details.account_id or '-')}[/]"


def _format_home_context_account(details: AgentWorkspaceDetails) -> str:
    account_color = WORKSPACE_THEME["account"]
    return f"[{account_color}]{_escape_markup(details.account_id or '-')}[/]"


def _format_transcript(lines: list[str]) -> str:
    if not lines:
        return ""
    normalized: list[str] = []
    agent_tags: dict[str, int] = {}
    # Track details block state
    in_details_block = False
    details_title_found = False

    for raw in lines:
        cleaned = _ANSI_RE.sub("", str(raw))
        if cleaned.startswith(_DETAILS_SENTINEL):
            if not in_details_block:
                in_details_block = True
                details_title_found = False

            content = cleaned[len(_DETAILS_SENTINEL) :].strip()
            # First non-empty line that is not a section header is the title
            is_section_header = content.startswith("[") and content.endswith("]")
            if content and not details_title_found and not is_section_header:
                normalized.append(
                    _sanitize_transcript_markup(
                        _format_details_transcript_line(cleaned[len(_DETAILS_SENTINEL) :], is_title=True), cleaned
                    )
                )
                details_title_found = True
            else:
                normalized.append(
                    _sanitize_transcript_markup(
                        _format_details_transcript_line(cleaned[len(_DETAILS_SENTINEL) :], is_title=False), cleaned
                    )
                )
        else:
            in_details_block = False
            normalized.append(
                _sanitize_transcript_markup(
                    _format_transcript_line_with_agent_tags(raw, agent_tags=agent_tags), cleaned
                )
            )
    return "\n".join(normalized)


def _sanitize_transcript_markup(formatted: str, fallback_raw: str) -> str:
    """Guard transcript rendering against malformed Rich markup rows."""
    if not formatted:
        return ""
    try:
        RichText.from_markup(formatted)
        return formatted
    except _MarkupError:
        return _escape_markup(str(fallback_raw).strip())


def _activity_detail(activity: str) -> str:
    """Return activity row detail after the first ':' separator."""
    if ":" not in activity:
        return ""
    return activity.split(":", 1)[1].strip()


def _legacy_status_to_activity_line(raw_body: str) -> str:
    """Map legacy `Status:` rows into canonical activity prefixes."""
    body = _render_status_body(str(raw_body or "").strip())
    lowered = body.lower()
    if lowered in {"running", _PREFIX_RUNNING}:
        return f"{_PREFIX_RUN} {_PREFIX_RUNNING}"

    if lowered.startswith("[ok] "):
        normalized = body.split("]", 1)[1].strip() if "]" in body else body
        return f"{_PREFIX_RUN_RESULT} {normalized or 'completed'}"
    if lowered.startswith("[x] "):
        normalized = body.split("]", 1)[1].strip() if "]" in body else body
        return f"{_PREFIX_RUN_RESULT} {normalized or f'{_RUN_FAILED_PREFIX} unknown error'}"

    if lowered.startswith((_PREFIX_COMPLETED_IN, _RUN_FAILED_PREFIX, _PREFIX_TOKEN_USAGE)):
        return f"{_PREFIX_RUN_RESULT} {body}"

    return f"{_PREFIX_STATUS} {body}"


def _format_labeled_transcript_line(stripped: str) -> str | None:
    """Format transcript rows with fixed labels (You/Cmd/System/Agent)."""
    if stripped.startswith("You:"):
        body = _escape_with_slash_highlights(stripped[4:].strip())
        return (
            f"[bold {_TRANSCRIPT_USER_FG} on {_TRANSCRIPT_USER_BG}]{_TRANSCRIPT_USER_LABEL}[/]"
            f" [{_TRANSCRIPT_USER_TEXT} on {_TRANSCRIPT_USER_BG}]{body}[/]"
        )

    if stripped.startswith("Cmd:"):
        body = _escape_with_slash_highlights(stripped[4:].strip())
        return f"[bold {_TRANSCRIPT_COMMAND_FG} on {_TRANSCRIPT_COMMAND_BG}]Cmd:[/] [{_TRANSCRIPT_STEP_MUTED}]{body}[/]"

    if stripped.startswith("System:"):
        body_raw = stripped[7:].strip()
        body = _escape_with_slash_highlights(body_raw)
        if body_raw.startswith("/"):
            return (
                f"[bold {_TRANSCRIPT_COMMAND_FG} on {_TRANSCRIPT_COMMAND_BG}]Cmd:[/]"
                f" [{_TRANSCRIPT_STEP_MUTED}]{body}[/]"
            )
        return (
            f"[bold {_TRANSCRIPT_SYSTEM_FG} on {_TRANSCRIPT_SYSTEM_BG}]System:[/] [{_TRANSCRIPT_STEP_MUTED}]{body}[/]"
        )

    if stripped.startswith("Agent Final:"):
        body = _render_agent_markdown_inline(stripped[12:].strip())
        return (
            f"[bold {_TRANSCRIPT_AGENT_FG} on {_TRANSCRIPT_AGENT_HERO_BG}]{_TRANSCRIPT_AGENT_LABEL}[/]"
            f" [bold {_TRANSCRIPT_AGENT_HERO_TEXT}]{body}[/]"
        )

    if stripped.startswith("Agent:"):
        body = _render_agent_markdown_inline(stripped[6:].strip())
        return (
            f"[bold {_TRANSCRIPT_AGENT_FG} on {_TRANSCRIPT_AGENT_BG}]{_TRANSCRIPT_AGENT_LABEL}[/]"
            f" [{_TRANSCRIPT_AGENT_TEXT}]{body}[/]"
        )

    if stripped.startswith("Status:"):
        body_raw = stripped[7:].strip()
        if body_raw.startswith(("[ok]", "[x]", "[~]")):
            body = _escape_markup(body_raw)
            return (
                f"[bold {_TRANSCRIPT_STATUS_FG} on {_TRANSCRIPT_STATUS_BG}]Status:[/]"
                f" [{_TRANSCRIPT_STATUS_FG}]{body}[/]"
            )
        legacy_line = _legacy_status_to_activity_line(body_raw)
        return _format_activity_transcript_line(legacy_line)

    return None


def _format_run_divider_line(value: str) -> str:
    """Render a subtle run-start divider before each user prompt."""
    label = _escape_markup(str(value or "").strip() or "Run")
    rail = "─" * 10
    return f"[{_TRANSCRIPT_STEP_MUTED}]{rail} {label} {rail}[/]"


def _format_activity_transcript_line(activity: str) -> str:
    """Format normalized activity rows using compact step renderer rules."""
    lowered = activity.lower()
    detail = _activity_detail(activity)
    if lowered.startswith(_PREFIX_SUBAGENT):
        return _render_subagent_box(detail)
    if lowered.startswith(_PREFIX_TOOL_PARAMS):
        return _render_tool_params_block(detail)

    normalized = _render_step_bullet(activity)
    color = _step_line_color(activity)
    highlighted = _highlight_slash_commands(_render_agent_tag_superscripts(_escape_markup(normalized)))
    if lowered.startswith(_PREFIX_TOOL_CALL):
        return f"[bold {color}]{highlighted}[/]"
    return f"[{color}]{highlighted}[/]"


def _format_transcript_line_with_agent_tags(raw: str, *, agent_tags: dict[str, int]) -> str:
    """Format one transcript row with stable delegated-agent tag numbering."""
    return _format_transcript_line_core(raw, agent_tags=agent_tags)


def _format_transcript_line(raw: str) -> str:
    """Format one transcript row without delegated-agent tag state."""
    return _format_transcript_line_core(raw, agent_tags=None)


def _format_transcript_line_core(raw: str, *, agent_tags: dict[str, int] | None) -> str:
    cleaned = _ANSI_RE.sub("", str(raw))

    if cleaned.startswith(_DETAILS_SENTINEL):
        return _format_details_transcript_line(cleaned[len(_DETAILS_SENTINEL) :])

    if cleaned.startswith(_RUN_DIVIDER_SENTINEL):
        return _format_run_divider_line(cleaned[len(_RUN_DIVIDER_SENTINEL) :])

    stripped = cleaned.strip()
    if not stripped:
        return ""

    labeled = _format_labeled_transcript_line(stripped)
    if labeled is not None:
        return labeled

    activity = _coerce_activity_line(stripped)
    if activity is None:
        return _escape_with_slash_highlights(stripped)

    tagged_activity = _annotate_activity_agent_tags(activity, agent_tags)
    return _format_activity_transcript_line(tagged_activity)


def _looks_like_uuid(value: str) -> bool:
    """Return True when string matches canonical UUID format."""
    cleaned = str(value or "").strip().lower()
    if len(cleaned) != 36:
        return False
    # 8-4-4-4-12
    parts = cleaned.split("-")
    if len(parts) != 5 or [len(p) for p in parts] != [8, 4, 4, 4, 12]:
        return False
    return all(ch in "0123456789abcdef" for ch in cleaned.replace("-", ""))


def _split_trailing_url_punctuation(value: str) -> tuple[str, str]:
    """Remove trailing punctuation that should not become part of the link target."""
    trimmed = str(value or "")
    trailing = ""

    while trimmed and trimmed[-1] in ".,;:!?":
        trailing = trimmed[-1] + trailing
        trimmed = trimmed[:-1]

    while trimmed.endswith(")") and trimmed.count("(") < trimmed.count(")"):
        trailing = ")" + trailing
        trimmed = trimmed[:-1]

    if not trimmed:
        return str(value or ""), ""

    return trimmed, trailing


def _render_explicit_hyperlink(value: str, *, color: str | None = None, underline: bool = False) -> str:
    """Emit Rich/Textual hyperlink markup while preserving the visible URL text."""
    url = str(value or "").strip()
    if not url:
        return ""

    click_action = f'app.open_url_token("{_encode_url_click_token(url)}")'
    markup_url = json.dumps(url)
    markup_text = _escape_markup(url)
    style = " ".join(part for part in (color, "underline" if underline else None) if part)
    if style:
        return f"[@click={click_action}][link={markup_url}][{style}]{markup_text}[/][/][/]"
    return f"[@click={click_action}][link={markup_url}]{markup_text}[/][/]"


def _capture_http_url_placeholders(
    text: str,
    *,
    color: str | None = None,
    underline: bool = False,
) -> tuple[str, list[str]]:
    """Replace plain URLs with placeholders so escaping/markdown stays stable."""
    replacements: list[str] = []

    def _replace(match: re.Match[str]) -> str:
        candidate = match.group(0)
        url, trailing = _split_trailing_url_punctuation(candidate)
        index = len(replacements)
        replacements.append(
            f"{_render_explicit_hyperlink(url, color=color, underline=underline)}{_escape_markup(trailing)}"
        )
        return f"\u0000URL{index}\u0000"

    return _HTTP_URL_RE.sub(_replace, text), replacements


def _render_inline_code_span(value: str) -> str:
    """Render inline code while preserving app-openable URLs inside the code span."""
    code = str(value or "").strip()
    if not code:
        return f"[{_TRANSCRIPT_AGENT_CODE_FG} on {_TRANSCRIPT_AGENT_CODE_BG}]  [/]"

    without_urls, url_spans = _capture_http_url_placeholders(code)
    escaped = _escape_markup(without_urls)
    for index, url_markup in enumerate(url_spans):
        token = f"\u0000URL{index}\u0000"
        escaped = escaped.replace(token, url_markup)
    return f"[{_TRANSCRIPT_AGENT_CODE_FG} on {_TRANSCRIPT_AGENT_CODE_BG}] {escaped} [/]"


def _encode_url_click_token(value: str) -> str:
    """Encode a URL into a Textual-safe click action token."""
    return base64.urlsafe_b64encode(str(value or "").encode("utf-8")).decode("ascii")


def _decode_url_click_token(value: str) -> str | None:
    """Decode a Textual click action token back into the original URL."""
    try:
        padding = "=" * (-len(value) % 4)
        return base64.urlsafe_b64decode(f"{value}{padding}".encode("ascii")).decode("utf-8")
    except Exception:
        return None


def _format_details_transcript_value(value: str) -> str:
    raw = str(value or "").strip()
    if not raw:
        return f"[{_DETAILS_VALUE_DIM}]-[/]"

    escaped = _escape_markup(raw)
    if raw.lower() in {"null", "none"}:
        return f"[{_DETAILS_VALUE_DIM}]null[/]"

    if _looks_like_uuid(raw):
        return f"[{_TRANSCRIPT_AGENT_CODE_FG} on {_TRANSCRIPT_AGENT_CODE_BG}]{escaped}[/]"

    if f"open {_PROMPT_COMMAND}" in raw:
        prompt_markup = f"[{_TRANSCRIPT_COMMAND_FG} on {_TRANSCRIPT_COMMAND_BG}]{_PROMPT_COMMAND}[/]"
        escaped = escaped.replace(_PROMPT_COMMAND, prompt_markup)
        return f"[{_DETAILS_VALUE_DIM}]{escaped}[/]"

    if "(trimmed;" in raw:
        return f"[{_DETAILS_VALUE_DIM}]{escaped}[/]"

    if raw.startswith("/"):
        url_color = WORKSPACE_THEME["success"]
        return f"[{url_color} underline]{escaped}[/]"

    if raw.lower().startswith("https://") or (raw.lower().startswith("http" + "://") and "localhost" in raw.lower()):
        url, trailing = _split_trailing_url_punctuation(raw)
        url_color = WORKSPACE_THEME["success"]
        return f"{_render_explicit_hyperlink(url, color=url_color, underline=True)}{_escape_markup(trailing)}"

    # Highlight UUIDs within the text (e.g., "catapa-prod (uuid)")
    uuid_pattern = r"([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})"

    def replace_uuid(match: re.Match[str]) -> str:
        uuid = match.group(1)
        # Highlight UUID without extra padding inside the markup
        return f"[{_TRANSCRIPT_AGENT_CODE_FG} on {_TRANSCRIPT_AGENT_CODE_BG}]{uuid}[/]"

    escaped_with_uuids = re.sub(uuid_pattern, replace_uuid, escaped, flags=re.IGNORECASE)

    # Regular values use dim color to differentiate from keys
    return f"[{_DETAILS_VALUE_DIM}]{escaped_with_uuids}[/]"


# Known section headers for details output
_DETAILS_SECTIONS = frozenset({"overview", "configuration", "tools", "mcps", "sub-agents", "metadata", "others"})


def _format_details_transcript_line(raw: str, *, is_title: bool = False) -> str:
    """Render a details-only transcript row.

    Input rows are tagged using `_DETAILS_SENTINEL` so this styling does not
    impact unrelated transcript content.
    """
    content = str(raw or "").rstrip("\n")
    if not content.strip():
        return ""

    stripped = content.strip()

    # Title line (agent name at the top)
    if is_title:
        heading = WORKSPACE_THEME["heading"]
        return f"[bold {heading}]{_escape_markup(stripped)}[/]"

    # Account line (special sentinel from agent_session)
    if "\u0000ACCOUNT\u0000" in content:
        account_val = content.split("\u0000ACCOUNT\u0000", 1)[1].strip()
        account_color = WORKSPACE_THEME["account"]
        return f"[{account_color}]{_escape_markup(account_val)}[/]"

    # Section headers ([Identity], [Behavior], etc.)
    if stripped.startswith("[") and stripped.endswith("]"):
        section_name = stripped[1:-1].lower()
        if section_name in _DETAILS_SECTIONS:
            heading = WORKSPACE_THEME["heading"]
            # Escape opening bracket so Rich/Textual renders literal [Section].
            literal_header = f"\\{stripped}"
            return f"[bold {heading}]{literal_header}[/]"

    if stripped.startswith("-"):
        return _format_details_bullet_line(content)

    if ":" not in stripped:
        return _escape_markup(stripped)

    key_raw, _, value_raw = stripped.partition(":")
    key = key_raw.strip()
    value = value_raw.lstrip()
    key_lower = key.lower()

    if key_lower in MASK_SENSITIVE_FIELDS:
        key_markup = f"[bold {_DANGER_COLOR}]{_escape_markup(key)}:[/]"
        value_markup = f"[{_DANGER_COLOR}]{_escape_markup(value) or '-'}[/]"
        return f"{key_markup} {value_markup}".rstrip()

    key_markup = f"[bold {_DETAILS_KEY_COLOR}]{_escape_markup(key)}:[/]"
    if not value:
        return f"{key_markup}"
    value_markup = _format_details_transcript_value(value)
    # Ensure exactly one space between key and value
    return f"{key_markup} {value_markup}".rstrip()


def _format_details_bullet_line(content: str) -> str:
    """Render hierarchical detail bullets with key/value coloring."""
    leading = len(content) - len(content.lstrip(" "))
    stripped = content.strip()
    body = stripped[1:].strip() if stripped.startswith("-") else stripped
    bullet_prefix = f"{' ' * leading}[{_DETAILS_VALUE_DIM}]-[/]"

    if not body:
        return bullet_prefix

    if ":" not in body:
        return f"{bullet_prefix} {_format_details_transcript_value(body)}"

    key_raw, _, value_raw = body.partition(":")
    key = key_raw.strip()
    value = value_raw.lstrip()

    if key.lower() in MASK_SENSITIVE_FIELDS:
        key_markup = f"[bold {_DANGER_COLOR}]{_escape_markup(key)}:[/]"
        if not value:
            return f"{bullet_prefix} {key_markup}"
        value_markup = f"[{_DANGER_COLOR}]{_escape_markup(value)}[/]"
        return f"{bullet_prefix} {key_markup} {value_markup}"

    key_markup = f"[bold {_DETAILS_KEY_COLOR}]{_escape_markup(key)}:[/]"
    if not value:
        return f"{bullet_prefix} {key_markup}"
    return f"{bullet_prefix} {key_markup} {_format_details_transcript_value(value)}"


def _render_agent_markdown_inline(text: str) -> str:
    """Render safe inline markdown subset in agent rows."""
    raw = str(text or "").strip()
    if not raw:
        return "-"

    code_spans: list[str] = []

    def _capture_code(match: re.Match[str]) -> str:
        index = len(code_spans)
        code_spans.append(match.group(1).strip())
        return f"\u0000CODE{index}\u0000"

    without_code = _MD_INLINE_CODE_RE.sub(_capture_code, raw)
    without_code_or_urls, url_spans = _capture_http_url_placeholders(without_code)
    escaped = _escape_markup(without_code_or_urls)
    escaped = _MD_BOLD_RE.sub(lambda m: f"[bold]{m.group(1)}[/]", escaped)
    escaped = _MD_ITALIC_RE.sub(lambda m: f"[italic]{m.group(1)}[/]", escaped)

    for index, url_markup in enumerate(url_spans):
        token = f"\u0000URL{index}\u0000"
        escaped = escaped.replace(token, url_markup)

    for index, code in enumerate(code_spans):
        token = f"\u0000CODE{index}\u0000"
        escaped = escaped.replace(token, _render_inline_code_span(code))

    return escaped


def _render_status_body(raw_body: str) -> str:
    """Render status body with concise semantic markers."""
    body = str(raw_body or "").strip()
    lowered = body.lower()
    if lowered == "running":
        return _PREFIX_RUNNING
    if lowered.startswith(_PREFIX_COMPLETED_IN):
        return f"[ok] {body}"
    if lowered.startswith(_RUN_FAILED_PREFIX):
        return f"[x] {body}"
    return body


def _coerce_activity_line(text: str) -> str | None:
    """Normalize known activity rows into canonical prefix form."""
    candidate = str(text or "").strip()
    if not candidate:
        return None

    if candidate.startswith("-"):
        candidate = candidate.lstrip("- ").strip()
    if not candidate:
        return None

    lowered = candidate.lower()
    prefixes = (
        "step:",
        _PREFIX_TOOL,
        _PREFIX_TOOL_CALL,
        _PREFIX_TOOL_RESULT,
        _PREFIX_TOOL_PARAMS,
        _PREFIX_TOOL_DONE,
        _PREFIX_ACTION,
        _PREFIX_HANDOFF,
        _PREFIX_SUBAGENT,
        _PREFIX_REASONING,
        _PREFIX_STATUS,
        _PREFIX_RUN,
        _PREFIX_RUN_RESULT,
        _PREFIX_FINAL,
    )
    if lowered.startswith(prefixes):
        return candidate

    if lowered.startswith("run "):
        legacy_body = candidate[4:].strip()
        legacy_lowered = legacy_body.lower()
        if legacy_lowered.startswith(
            (
                "[~]",
                "[ok]",
                "[x]",
                "running",
                "queued",
                _PREFIX_COMPLETED_IN,
                _PREFIX_FINISHED_IN,
                _RUN_FAILED_PREFIX,
                "failed:",
                _PREFIX_TOKEN_USAGE,
            )
        ):
            canonical = _legacy_status_to_activity_line(legacy_body)
            if canonical.startswith((_PREFIX_RUN, _PREFIX_RUN_RESULT)):
                return canonical
            if canonical.startswith(_PREFIX_STATUS):
                return f"{_PREFIX_RUN} {canonical.split(':', 1)[1].strip()}"
    return None


def _skip_space_chars(text: str, start: int) -> int:
    """Return next index after contiguous whitespace from start."""
    index = max(0, start)
    while index < len(text) and text[index].isspace():
        index += 1
    return index


def _find_unescaped_quote(text: str, start: int) -> int | None:
    """Find next unescaped double quote starting at index, else None."""
    escaped = False
    cursor = max(0, start)
    while cursor < len(text):
        char = text[cursor]
        if escaped:
            escaped = False
        elif char == "\\":
            escaped = True
        elif char == '"':
            return cursor
        cursor += 1
    return None


def _split_tool_param_key_value(line: str) -> tuple[str, str, str] | None:
    """Parse one JSON-ish `"key": value` line without regex backtracking risk."""
    if not line:
        return None

    key_open = _skip_space_chars(line, 0)
    if key_open >= len(line) or line[key_open] != '"':
        return None

    key_start = key_open + 1
    key_end = _find_unescaped_quote(line, key_start)
    if key_end is None:
        return None

    colon_index = _skip_space_chars(line, key_end + 1)
    if colon_index >= len(line) or line[colon_index] != ":":
        return None

    value_start = _skip_space_chars(line, colon_index + 1)
    return line[:key_open], line[key_start:key_end], line[value_start:]


def _render_tool_params_line(raw_line: str) -> str:
    """Render one formatted params line with key/value emphasis when possible."""
    line = str(raw_line or "").rstrip()
    if not line:
        return ""
    if len(line) > _TOOL_PARAMS_MAX_LINE_LEN:
        line = f"{line[: _TOOL_PARAMS_MAX_LINE_LEN - 3]}..."

    parsed = _split_tool_param_key_value(line)
    if parsed is not None:
        indent, key_raw, value_raw = parsed
        key = _escape_markup(key_raw)
        value = value_raw.strip()
        if value:
            value_markup = f"[{_DETAILS_VALUE_DIM}]{_escape_markup(value)}[/]"
            return f"{indent}[bold {_TRANSCRIPT_STEP_KEY}]{key}[/]: {value_markup}"
        return f"{indent}[bold {_TRANSCRIPT_STEP_KEY}]{key}[/]:"

    return f"[{_DETAILS_VALUE_DIM}]{_escape_markup(line)}[/]"


def _truncate_activity_detail(detail: str, *, max_len: int = _ACTIVITY_DETAIL_MAX_LEN) -> str:
    """Keep activity detail readable by trimming noisy long payloads."""
    compact = " ".join(str(detail or "").split()).strip()
    if len(compact) <= max_len:
        return compact
    head = max(1, int(max_len * 0.74))
    tail = max(8, max_len - head - 5)
    return f"{compact[:head]} ... {compact[-tail:]}"


def _render_tool_params_block(detail: str) -> str:
    """Render params rows as structured JSON when possible."""
    raw = str(detail or "").strip()
    if not raw:
        return f"[{_TRANSCRIPT_STEP_PARAM}]params {{}}[/]"

    compact = " ".join(raw.split()).strip()
    try:
        parsed = json.loads(raw)
    except Exception:
        if len(compact) > _TOOL_PARAMS_MAX_LINE_LEN:
            compact = f"{compact[: _TOOL_PARAMS_MAX_LINE_LEN - 3]}..."
        return f"[{_TRANSCRIPT_STEP_PARAM}]params {_escape_markup(compact)}[/]"

    serialized = json.dumps(parsed, ensure_ascii=False, indent=2)
    lines = serialized.splitlines()
    overflow = max(0, len(lines) - _TOOL_PARAMS_MAX_LINES)
    visible_lines = lines[:_TOOL_PARAMS_MAX_LINES]

    rendered = [f"[{_TRANSCRIPT_STEP_PARAM}]params[/]"]
    for line in visible_lines:
        formatted = _render_tool_params_line(line)
        if formatted:
            rendered.append(formatted)
    if overflow > 0:
        rendered.append(f"[{_DETAILS_VALUE_DIM}]... +{overflow} lines[/]")
    return "\n".join(rendered)


def _render_subagent_box(detail: str) -> str:
    """Render sub-agent delegation in a dedicated transcript box."""
    raw = " ".join(str(detail or "").split()).strip()
    if raw.lower().startswith("sub-agent:"):
        raw = raw.split(":", 1)[1].strip()
    if raw.lower().startswith("sub agent:"):
        raw = raw.split(":", 1)[1].strip()
    label = raw or "unknown"
    content = f"sub-agent: {label}"

    max_width = 76
    if len(content) > max_width:
        content = f"{content[: max_width - 1]}…"
    inner_width = max(24, len(content))
    line = "─" * (inner_width + 2)
    padded = _escape_markup(content.ljust(inner_width))
    color = _TRANSCRIPT_STEP_MUTED
    return "\n".join(
        (
            f"[{color}]╭{line}╮[/]",
            f"[{color}]│ {padded} │[/]",
            f"[{color}]╰{line}╯[/]",
        )
    )


def _extract_prefixed_activity_detail(cleaned: str, prefix: str) -> str | None:
    """Return activity detail when row starts with `prefix`."""
    lowered = cleaned.lower()
    if not lowered.startswith(prefix):
        return None
    return cleaned[len(prefix) :].strip()


def _render_step_with_label(detail: str, label: str) -> str:
    """Render `<label> <detail>` with fallback to label only."""
    trimmed = _truncate_activity_detail(detail)
    return f"{label} {trimmed}" if trimmed else label


def _render_done_step(detail: str) -> str:
    """Render completion rows with explicit done marker."""
    trimmed = _truncate_activity_detail(detail)
    if not trimmed:
        return "Completed"

    lowered = trimmed.lower()
    if lowered.startswith(_RUN_FAILED_PREFIX):
        reason = trimmed.split(":", 1)[1].strip() if ":" in trimmed else ""
        return f"Failed: {reason or 'unknown error'}"
    if lowered.startswith("failed:"):
        reason = trimmed.split(":", 1)[1].strip() if ":" in trimmed else ""
        return f"Failed: {reason or 'unknown error'}"
    if lowered.startswith("failed in "):
        return f"Failed in {trimmed[len('failed in ') :].strip()}"
    if lowered.startswith("finished in "):
        return f"Completed in {trimmed[len('finished in ') :].strip()}"
    if lowered.startswith(_PREFIX_COMPLETED_IN):
        return f"Completed in {trimmed[len(_PREFIX_COMPLETED_IN) :].strip()}"

    return f"Completed: {trimmed}"


def _render_named_tool_completion(tool_name: str, completion: str) -> str:
    """Render one named tool completion row."""
    normalized_tool_name = _truncate_activity_detail(tool_name.strip())
    if not normalized_tool_name:
        return completion
    if completion.startswith("Completed in "):
        return f"{normalized_tool_name} completed in {completion[len('Completed in ') :]}"
    if completion.startswith("Failed:"):
        return f"{normalized_tool_name} failed:{completion[len('Failed:') :]}"
    if completion == "Completed":
        return f"{normalized_tool_name} completed"
    return f"{normalized_tool_name} {completion.lower()}"


def _render_tool_result_step(detail: str) -> str:
    """Render tool completion rows without repeating tool names."""
    cleaned = str(detail or "").strip()
    if not cleaned:
        return "Completed"

    if "|" in cleaned:
        tool_name, outcome = cleaned.split("|", 1)
        parsed_outcome = _truncate_activity_detail(outcome.strip())
        if parsed_outcome:
            completion = _render_done_step(parsed_outcome)
            return _render_named_tool_completion(tool_name, completion)
    return _render_done_step(cleaned)


def _render_params_step(detail: str) -> str:
    """Render params rows with object fallback marker."""
    return _render_step_with_label(detail, "params") if detail else "params {}"


def _render_delegate_step(detail: str) -> str:
    """Render delegate/handoff rows without repeating obvious prefixes."""
    cleaned = _truncate_activity_detail(detail)
    if not cleaned:
        return "Delegated to sub-agent"
    lowered = cleaned.lower()
    if lowered.startswith("delegated to "):
        return cleaned
    if lowered.startswith("delegate to "):
        return f"Delegated to {cleaned[len('delegate to ') :].strip()}"
    if lowered.startswith("delegate "):
        return f"Delegated to {cleaned[len('delegate ') :].strip()}"
    if lowered.startswith("sub-agent:"):
        cleaned = cleaned.split(":", 1)[1].strip()
    if lowered.startswith("sub agent:"):
        cleaned = cleaned.split(":", 1)[1].strip()
    return f"Delegated to {cleaned}" if cleaned else "Delegated to sub-agent"


def _render_status_step(detail: str) -> str:
    """Render status rows using the detail body when present."""
    trimmed = _truncate_activity_detail(detail)
    return trimmed or "Working..."


def _render_run_step(detail: str) -> str:
    """Render run-state rows without legacy status labels."""
    trimmed = _truncate_activity_detail(detail)
    if not trimmed:
        return _PREFIX_RUNNING_TEXT

    lowered = trimmed.lower()
    if lowered in {_PREFIX_RUNNING, "running"}:
        return _PREFIX_RUNNING_TEXT
    if lowered.startswith(_RUN_FAILED_PREFIX):
        reason = trimmed.split(":", 1)[1].strip() if ":" in trimmed else ""
        return f"Failed: {reason or 'unknown error'}"
    if lowered == "queued":
        return "Queued"
    return f"Run: {trimmed}"


def _render_run_result_step(detail: str) -> str:
    """Render final run outcome rows using compact result wording."""
    trimmed = _truncate_activity_detail(detail)
    if not trimmed:
        return "Completed"
    lowered = trimmed.lower()
    if lowered.startswith(_RUN_FAILED_PREFIX):
        reason = trimmed.split(":", 1)[1].strip() if ":" in trimmed else ""
        return f"Failed: {reason or 'unknown error'}"
    if lowered.startswith(_PREFIX_FINISHED_IN):
        return f"Completed in {trimmed[len(_PREFIX_FINISHED_IN) :].strip()}"
    if lowered.startswith(_PREFIX_COMPLETED_IN):
        return f"Completed in {trimmed[len(_PREFIX_COMPLETED_IN) :].strip()}"
    if lowered.startswith(_PREFIX_TOKEN_USAGE):
        usage = trimmed.split(":", 1)[1].strip() if ":" in trimmed else ""
        return f"Token usage: {usage}" if usage else "Token usage"
    return _render_done_step(trimmed)


_STEP_BULLET_RENDERERS: tuple[tuple[str, Callable[[str], str]], ...] = (
    ("step:", lambda detail: detail or "step"),
    (_PREFIX_TOOL, lambda detail: _render_step_with_label(detail, "tool")),
    (_PREFIX_TOOL_CALL, lambda detail: _render_step_with_label(detail, "tool")),
    (_PREFIX_TOOL_RESULT, _render_tool_result_step),
    (_PREFIX_TOOL_DONE, _render_done_step),
    (_PREFIX_TOOL_PARAMS, _render_params_step),
    (_PREFIX_ACTION, lambda detail: _render_step_with_label(detail, "action")),
    (_PREFIX_HANDOFF, _render_delegate_step),
    (_PREFIX_REASONING, lambda detail: _render_step_with_label(detail, "thinking")),
    (_PREFIX_STATUS, _render_status_step),
    (_PREFIX_RUN, _render_run_step),
    (_PREFIX_RUN_RESULT, _render_run_result_step),
    (_PREFIX_FINAL, _render_done_step),
)


def _render_step_bullet(body: str) -> str:
    """Render compact activity rows with semantic markers and spacing."""
    cleaned = str(body or "").strip()
    if not cleaned:
        return "-"

    for prefix, renderer in _STEP_BULLET_RENDERERS:
        detail = _extract_prefixed_activity_detail(cleaned, prefix)
        if detail is not None:
            return renderer(detail)

    return cleaned


def _tool_result_step_color(lowered: str) -> str:
    """Return the color for completed tool rows."""
    failure_markers = ("failed", "error", "aborted", "cancelled", "stopped")
    return _DANGER_COLOR if any(marker in lowered for marker in failure_markers) else _TRANSCRIPT_STEP_MUTED


def _run_step_color(lowered: str) -> str:
    """Return the color for in-flight run rows."""
    if _PREFIX_RUNNING in lowered or lowered.endswith("running"):
        return _TRANSCRIPT_STATUS_FG
    if "failed" in lowered:
        return _DANGER_COLOR
    return _TRANSCRIPT_STEP_MUTED


def _run_result_step_color(lowered: str) -> str:
    """Return the color for final run outcome rows."""
    if "failed" in lowered or " error" in lowered:
        return _DANGER_COLOR
    if "completed in" in lowered or "finished in" in lowered or "success" in lowered:
        return _TRANSCRIPT_STEP_FINAL
    return _TRANSCRIPT_STEP_MUTED


def _step_line_color(body: str) -> str:
    """Return per-step color token for compact transcript rows."""
    lowered = str(body or "").strip().lower()
    if lowered.startswith(_PREFIX_RUN_RESULT):
        return _run_result_step_color(lowered)
    if lowered.startswith(_PREFIX_RUN):
        return _run_step_color(lowered)
    if lowered.startswith((_PREFIX_TOOL, _PREFIX_TOOL_CALL)):
        return _TRANSCRIPT_STEP_TOOL
    if lowered.startswith((_PREFIX_TOOL_RESULT, _PREFIX_TOOL_DONE)):
        return _tool_result_step_color(lowered)
    if lowered.startswith(_PREFIX_TOOL_PARAMS):
        return _TRANSCRIPT_STEP_PARAM
    if lowered.startswith((_PREFIX_HANDOFF, _PREFIX_ACTION, _PREFIX_SUBAGENT)):
        return _TRANSCRIPT_STEP_MUTED
    if lowered.startswith(_PREFIX_REASONING):
        return _TRANSCRIPT_STEP_MUTED
    if lowered.startswith((_PREFIX_FINAL, "status: [ok]", "status: [x]")):
        return _TRANSCRIPT_STEP_FINAL
    return _TRANSCRIPT_STEP_MUTED


if TEXTUAL_SUPPORTED:
    WORKSPACE_CSS = build_workspace_css(WORKSPACE_THEME)

    class WorkspaceComposer(TextArea):
        """Multiline composer with Enter-to-send and Alt/Shift+Enter newline."""

        @staticmethod
        def _cursor_end_location(text: str) -> tuple[int, int]:
            lines = str(text or "").splitlines()
            if not lines:
                return (0, 0)
            return (len(lines) - 1, len(lines[-1]))

        # Compatibility surface: tests and call sites expect Input-like APIs.
        @property
        def value(self) -> str:
            """Expose Input-compatible value alias backed by TextArea text."""
            return self.text

        @value.setter
        def value(self, text: str) -> None:
            self.text = text
            self.cursor_location = self._cursor_end_location(text)

        @property
        def cursor_position(self) -> int:
            """Expose Input-compatible cursor column for single-line tests."""
            return int(getattr(self, "cursor_location", (0, 0))[1])

        @cursor_position.setter
        def cursor_position(self, position: int) -> None:
            lines = str(self.text or "").splitlines()
            if not lines:
                self.cursor_location = (0, 0)
                return
            if len(lines) > 1:
                self.cursor_location = (len(lines) - 1, len(lines[-1]))
                return
            self.cursor_location = (0, max(0, min(int(position), len(lines[0]))))

        @staticmethod
        def _event_key_candidates(event: Key) -> list[str]:  # type: ignore[name-defined]
            """Return normalized key and alias candidates for one event."""
            candidates = [str(event.key or "").lower()]
            aliases = getattr(event, "aliases", None)
            if isinstance(aliases, list):
                candidates.extend(str(alias or "").lower() for alias in aliases)
            return candidates

        @staticmethod
        def _enter_key_behavior(candidates: Sequence[str]) -> tuple[bool, bool]:
            """Return `(is_enter, wants_newline)` for the supplied key aliases."""
            is_enter = False
            for candidate in candidates:
                parts = [part for part in candidate.split("+") if part]
                if not parts:
                    continue
                base = parts[-1]
                modifiers = set(parts[:-1])
                if base == "return":
                    base = "enter"
                if base == "m" and "ctrl" in modifiers:
                    base = "enter"
                if base != "enter":
                    continue
                is_enter = True
                if modifiers.intersection({"alt", "meta", "shift"}):
                    return True, True
            return is_enter, False

        @staticmethod
        def _stop_key_event(event: Key) -> None:  # type: ignore[name-defined]
            """Stop default key handling for custom Enter behavior."""
            event.stop()
            prevent_default = getattr(event, "prevent_default", None)
            if callable(prevent_default):
                prevent_default()

        async def _on_key(self, event: Key) -> None:  # type: ignore[name-defined]
            """Submit on Enter while keeping Alt/Shift+Enter as newline shortcuts."""
            if self.disabled:
                return

            is_enter, wants_newline = WorkspaceComposer._enter_key_behavior(
                WorkspaceComposer._event_key_candidates(event)
            )

            if is_enter and wants_newline:
                WorkspaceComposer._stop_key_event(event)
                self.insert("\n")
                return

            if is_enter:
                WorkspaceComposer._stop_key_event(event)
                submit = getattr(self.app, "action_submit_composer", None)
                if callable(submit):
                    submit()
                return

            await super()._on_key(event)

    # Backward-compatible alias for existing runtime/tests that reference `Input`.
    Input = WorkspaceComposer

    class AgentWorkspaceShellApp(App[AgentWorkspaceEvent | None], WorkspaceScreenshotCaptureMixin, ClipboardToastMixin):
        """Gated workspace shell for agent context with split-pane layout."""

        CSS = WORKSPACE_CSS

        ENABLE_COMMAND_PALETTE = False
        COMMAND_PALETTE_BINDING = ""

        BINDINGS = [
            *(
                _close_shortcuts(escape_action="close_overlay_or_exit", quit_action=APP_QUIT_ACTION)
                if _close_shortcuts is not None
                else (
                    Binding("escape", "close_overlay_or_exit", "Close", priority=True, show=True),
                    Binding("q", APP_QUIT_ACTION, "Close", priority=True, show=False),
                )
            ),
            Binding("ctrl+c", APP_QUIT_ACTION, "Quit", show=False),
            Binding("ctrl+b", "toggle_sidebar", "Agent Details", show=True, priority=True, key_display="ctrl+b"),
            Binding("ctrl+g", "quick_agents_selector", "Quick /agents", show=False, priority=True),
            Binding("pageup", "transcript_page_up", "Scroll Up", show=False),
            Binding("pagedown", "transcript_page_down", "Scroll Down", show=False),
            Binding("ctrl+p", "command_palette", "Commands", show=False, priority=True),
            Binding("ctrl+t", "transcript_hint", "Transcript", show=False),
            Binding("ctrl+shift+c", "copy_last_details", "Copy Details", show=False),
        ]

        CSS_NAME = ""

        palette_open: reactive[bool] = reactive(False)
        palette_query: reactive[str] = reactive("")
        palette_selected_index: reactive[int] = reactive(0)

        def __init__(
            self,
            *,
            details: AgentWorkspaceDetails,
            transcript_lines: list[str] | None = None,
            composer_placeholder: str,
            status_summary_provider: StatusSummaryProvider | None = None,
            details_provider: DetailsProvider | None = None,
            transcript_sink: TranscriptSink | None = None,
            message_run_provider: MessageRunProvider | None = None,
            picker_bindings: AgentWorkspacePickerBindings | None = None,
            mode: WorkspaceShellMode = "agent",
            page_chrome: PageChrome | None = None,
        ) -> None:
            """Initialize app state for a single workspace interaction turn."""
            super().__init__()
            picker_bindings = picker_bindings or AgentWorkspacePickerBindings()

            if page_chrome is None:
                page_chrome = get_page_chrome(mode)

            self._page_chrome = page_chrome
            self._details = details
            self._transcript_lines = list(transcript_lines or [])[-TRANSCRIPT_MAX_LINES:]
            self._composer_placeholder = composer_placeholder
            self._status_summary_provider = status_summary_provider
            self._details_provider = details_provider
            self._transcript_sink = transcript_sink
            self._message_run_provider = message_run_provider
            self._model_picker_provider = picker_bindings.model_picker_provider
            self._model_apply_provider = picker_bindings.model_apply_provider
            self._tools_picker_provider = picker_bindings.tools_picker_provider
            self._tools_apply_provider = picker_bindings.tools_apply_provider
            self._mcps_picker_provider = picker_bindings.mcps_picker_provider
            self._mcps_apply_provider = picker_bindings.mcps_apply_provider
            self._mode = mode
            self._slash_commands = _WORKSPACE_SLASH_COMMANDS_BY_MODE[mode]
            self._command_index = _WORKSPACE_COMMAND_INDEX_BY_MODE[mode]
            self._slash_dropdown_commands = _WORKSPACE_DROPDOWN_COMMANDS_BY_MODE[mode]
            self._sidebar_visible = mode == "agent"
            self._workspace_label = _get_workspace_label()
            self._workspace_tip_order: list[int] = []
            self._workspace_tip_index = 0
            self._tip_rotate_seconds = page_chrome.tip_rotate_seconds
            self._workspace_tips = page_chrome.tips
            self._pending_command_event: AgentWorkspaceEvent | None = None
            self._inline_status_running = False
            self._inline_details_running = False
            self._inline_message_running = False
            self._inline_picker_running = False
            self._inline_running_started_at: float | None = None
            self._inline_running_status_index: int | None = None
            self._slash_selected_index = 0
            self._slash_filtered: list[tuple[str, str]] = []
            self._slash_scroll_offset = 0
            self._palette_actions: list[PaletteAction] = []
            self._palette_filtered: list[PaletteAction] = []
            self._palette_selected_index = 0
            self._palette_scroll_offset = 0
            self._last_details_lines: list[str] | None = None
            self._composer_history: list[str] = []
            self._composer_history_index: int | None = None
            self._composer_history_draft = ""
            self._inline_streamed_status_lines: list[str] = []
            self._inline_streamed_status_set: set[str] = set()
            self._inline_streamed_status_counts: dict[str, int] = {}
            self._pending_inline_completion_line: str | None = None
            self._pending_inline_post_status_lines: list[str] = []
            self._inline_stream_reply_index: int | None = None
            self._inline_stream_reply_text = ""
            self._logo_lines = get_workspace_logo_text().splitlines()
            self._logo_max_width = max((len(line) for line in self._logo_lines), default=0)
            self._home_brand_lines = _HOME_HEADER_BRAND_TEXT.splitlines()
            self._home_brand_max_width = max((len(line) for line in self._home_brand_lines), default=0)
            self._logo_pulse_step = 0
            self._logo_pulse_dir = 1
            self._logo_step_size = 1
            self._logo_resume_at = 0.0
            self._escape_confirm_target: str | None = None
            self._escape_confirm_timer: Any | None = None
            self._escape_confirm_hint_visible = False
            self._workspace_tip_order = self._build_workspace_tip_order()
            self._workspace_tip_index = 0

        def _compose_header(self, has_turns: bool) -> ComposeResult:
            """Render the workspace header row."""
            surface_label = f"{self._workspace_label}:{self._mode}"
            with Container(id=HEADER_ROW_ID):
                yield Static(surface_label, id="workspace")
                if self._mode == "agent":
                    with Vertical(id=CONTEXT_BLOCK_ID):
                        yield Static(_format_agent_context_name(self._details), id=AGENT_CONTEXT_NAME_ID)
                        yield Static(_format_agent_context_account(self._details), id=AGENT_CONTEXT_ACCOUNT_ID)
                    return
                with Vertical(id=HOME_CONTEXT_BLOCK_ID):
                    yield Static(
                        _HOME_HEADER_BRAND_TEXT,
                        id=HOME_CONTEXT_BRAND_ID,
                        classes="" if has_turns else "-hidden",
                    )
                    yield Static(
                        _format_home_context_account(self._details),
                        id=HOME_CONTEXT_ACCOUNT_ID,
                        classes="" if has_turns else "-hidden",
                    )

        def _compose_chat_column(self, has_turns: bool) -> ComposeResult:
            """Render the transcript, composer, slash menu, and footer rows."""
            tip_text = self._current_tip_text()
            with Container(id="center-wrapper", classes="-has-turns" if has_turns else ""):
                with Vertical(id="chat-column", classes="-has-turns" if has_turns else ""):
                    if not has_turns:
                        yield Static(get_workspace_logo_text(), id="title")
                    with Container(id=TRANSCRIPT_SCROLL_ID, classes="-has-turns" if has_turns else ""):
                        yield Static(
                            _format_transcript(self._transcript_lines),
                            id=TRANSCRIPT_ID,
                            classes="-has-turns" if has_turns else "",
                        )

            with Container(id="prompt-row"):
                with Container(id="composer-box"):
                    yield Input(
                        placeholder=self._composer_placeholder,
                        id=COMPOSER_ID,
                    )

            yield Container(
                Vertical(Static(id=SLASH_ROWS_ID), classes="slash-menu"),
                id=SLASH_WRAP_ID,
                classes="-hidden",
            )

            yield Container(
                Vertical(
                    Horizontal(
                        Static("Commands", classes="palette-title"),
                        Static("esc", classes="palette-esc"),
                        classes="palette-header",
                    ),
                    TextInput(placeholder="Search commands...", id=PALETTE_SEARCH_ID),
                    Static("Suggested", id=PALETTE_SECTION_ID, classes="palette-section"),
                    Static(id=PALETTE_ROWS_ID),
                    classes="palette",
                ),
                id=PALETTE_WRAP_ID,
                classes="-hidden",
            )

            with Container(id="hints-row", classes="-spaced-top"):
                yield Static(tip_text, id="tip")

            with Container(id="footer-row"):
                if _PulseIndicator is not None:
                    yield _PulseIndicator(
                        "Ready",
                        id=COMMAND_LOADING_ID,
                        variant="info",
                        width=30,
                        speed_ms=80,
                        low_motion=False,
                        pause_at_edges=True,
                        classes="-hidden",
                    )
                else:
                    yield Static("Ready", id=COMMAND_LOADING_ID, classes="-hidden")
                yield Static(f"v{SDK_VERSION}", id="footer-version")

        def _compose_sidebar(self) -> ComposeResult:
            """Render the optional agent sidebar."""
            if self._mode != "agent":
                return
            with Vertical(id=SIDEBAR_ID, classes="" if self._sidebar_visible else "-hidden"):
                yield Static(_format_sidebar_header(self._details), id="sidebar-header")
                with Container(id="sidebar-details-container"):
                    yield Static(_format_details(self._details), id=DETAILS_ID)
                yield Button("View Full Details", id="view-details-btn", variant="primary")

        def _compose_keybar(self) -> ComposeResult:
            """Render the bottom keybar row."""
            keybar_hint = self._keybar_left_text()
            with Container(id=KEYBAR_ROW_ID, classes="-hidden"):
                yield Static(keybar_hint, id=KEYBAR_LEFT_ID)
                yield Static("", id=KEYBAR_RIGHT_ID)

        def compose(self) -> ComposeResult:
            """Render docked workspace mirroring demo_agent_context layout."""
            has_turns = bool(self._transcript_lines)
            with Container(id="root"):
                with Vertical(id=LEFT_COLUMN_ID):
                    yield from self._compose_header(has_turns)
                    yield from self._compose_chat_column(has_turns)
                yield from self._compose_sidebar()
            yield from self._compose_keybar()

        def _keybar_left_text(self) -> str:
            """Render bottom keybar using PageChrome visible_actions."""
            visible_actions = self._page_chrome.visible_actions
            if not visible_actions:
                return "[bold #f2b266]ctrl+p[/] Commands   [bold #f2b266]esc[/] Close"
            parts = []
            for action in visible_actions:
                parts.append(f"[bold #f2b266]{action.key}[/] {action.label}")
            parts.append("[bold #f2b266]esc[/] Close")
            return "   ".join(parts)

        def on_mount(self) -> None:
            """Focus composer input when the workspace opens."""
            self.query_one(f"#{COMPOSER_ID}", Input).focus()
            self._refresh_transcript_widget()
            self._refresh_chrome_visibility()
            self._refresh_slash_menu("")
            self._render_logo()
            self.set_interval(_LOGO_TICK_SECONDS, self._tick_logo)
            self.set_interval(self._tip_rotate_seconds, self._rotate_workspace_tip)

        def on_resize(self, _: Any) -> None:
            """Reposition floating overlays when the viewport changes."""
            if self._is_slash_open():
                self._position_slash_menu()
            if self._is_palette_open():
                self._position_palette_menu()

        def _current_tip_text(self) -> str:
            """Return the current idle tip text for the active shell mode."""
            if not self._workspace_tips:
                return ""
            if self._mode == "home":
                return self._workspace_tips[0]
            if not self._workspace_tip_order:
                self._workspace_tip_order = self._build_workspace_tip_order()
            current_index = self._workspace_tip_order[self._workspace_tip_index % len(self._workspace_tip_order)]
            return self._workspace_tips[current_index]

        def get_palette_action_metadata(
            self,
            *,
            action: str,
            title: str,
            category: str,
            hint_text: str | None,
        ) -> dict[str, Any]:
            """Return page-sensitive palette metadata for non-slash actions."""
            normalized = action.split(".")[-1]

            static = get_palette_action_static_metadata(normalized)
            if static:
                result = dict(static)
                if normalized in {"close_overlay_or_exit", "quit"} or action == APP_QUIT_ACTION:
                    result["title"] = self._palette_exit_title()
                result["display_rank"] = self._palette_action_display_rank(
                    normalized,
                    default=int(result.get("display_rank", 500)),
                )
                hidden = self._palette_action_hidden_state(normalized)
                if hidden is not None:
                    result["hidden"] = hidden
                return result

            return {
                "title": title,
                "category": category,
                "hint_text": hint_text,
                "display_rank": 500,
            }

        def get_palette_slash_metadata(
            self,
            *,
            action: str,
            title: str,
            category: str,
            hint_text: str | None,
            route: str,
            aliases: tuple[str, ...],
        ) -> dict[str, Any]:
            """Return page-sensitive palette metadata for slash commands."""
            static = get_palette_slash_static_metadata(action)
            if static:
                result = dict(static)
                result["title"] = self._palette_slash_title(action, fallback_title=str(result.get("title", title)))
                result["hint_text"] = self._palette_slash_hint_text(action, hint_text, aliases)
                result["display_rank"] = self._palette_slash_display_rank(
                    action,
                    default=int(result.get("display_rank", 500)),
                )
                return result

            return {
                "title": title,
                "category": "Command" if category == "Slash" else category,
                "hint_text": hint_text,
                "keywords": (route,),
                "callback_rank": 50,
                "display_rank": 500,
            }

        def _palette_exit_title(self) -> str:
            """Return the page-specific label for leaving the current surface."""
            return "Exit workspace" if self._mode == "agent" else "Close launcher"

        def _palette_action_hidden_state(self, normalized: str) -> bool | None:
            """Return whether a static action should be hidden for the active page."""
            hidden_actions = {
                "quick_agents_selector": self._mode != "home",
                "toggle_sidebar": self._mode != "agent",
                "copy_last_details": self._mode != "agent",
            }
            if normalized in hidden_actions:
                return hidden_actions[normalized]
            if normalized in {"transcript_page_up", "transcript_page_down"}:
                return not bool(self._transcript_lines)
            return None

        def _palette_action_display_rank(self, normalized: str, *, default: int) -> int:
            """Return the curated blank-query rank for one workspace action."""
            if self._mode == "home":
                ranks = {
                    "quick_agents_selector": 100,
                    "transcript_hint": 320,
                    "close_overlay_or_exit": 980,
                    "quit": 990,
                }
            else:
                ranks = {
                    "toggle_sidebar": 300,
                    "transcript_hint": 340,
                    "copy_last_details": 320,
                    "close_overlay_or_exit": 980,
                    "quit": 990,
                }
            return ranks.get(normalized, default)

        def _palette_slash_title(self, action: str, *, fallback_title: str) -> str:
            """Return the page-specific slash-command palette title."""
            if action in {_WORKSPACE_EXIT_COMMAND, _Q_EXIT_COMMAND}:
                return self._palette_exit_title()
            if action == _STATUS_COMMAND:
                return "Show quick diagnostics" if self._mode == "agent" else "Show connection diagnostics"
            return fallback_title

        def _palette_slash_hint_text(
            self,
            action: str,
            hint_text: str | None,
            aliases: tuple[str, ...],
        ) -> str | None:
            """Return the displayed hint text for one slash-command palette row."""
            if action in {_WORKSPACE_EXIT_COMMAND, _Q_EXIT_COMMAND}:
                alternate = _Q_EXIT_COMMAND if action == _WORKSPACE_EXIT_COMMAND else _WORKSPACE_EXIT_COMMAND
                return ", ".join(dict.fromkeys((action, *aliases, alternate)))
            if action == _HELP_COMMAND:
                return ", ".join(dict.fromkeys((action, *aliases)))
            return hint_text

        def _palette_slash_display_rank(self, action: str, *, default: int) -> int:
            """Return the curated blank-query rank for one slash-command destination."""
            if self._mode == "home":
                ranks = {
                    _AGENTS_COMMAND: 100,
                    _ACCOUNTS_COMMAND: 120,
                    _STATUS_COMMAND: 140,
                    _HELP_COMMAND: 160,
                    _UPDATE_COMMAND: 180,
                    _TRANSCRIPTS_COMMAND: 320,
                    _WORKSPACE_EXIT_COMMAND: 980,
                    _Q_EXIT_COMMAND: 980,
                }
            else:
                ranks = {
                    _DETAILS_COMMAND: 100,
                    _RUNS_COMMAND: 120,
                    _STATUS_COMMAND: 140,
                    _MODELS_COMMAND: 180,
                    _SCHEDULES_COMMAND: 220,
                    _PROMPT_COMMAND: 240,
                    _TOOLS_COMMAND: 260,
                    _MCPS_COMMAND: 280,
                    _TRANSCRIPTS_COMMAND: 320,
                    _HELP_COMMAND: 360,
                    _WORKSPACE_EXIT_COMMAND: 980,
                    _Q_EXIT_COMMAND: 980,
                }
            return ranks.get(action, default)

        def _build_workspace_tip_order(self) -> list[int]:
            """Return a shuffled tip order so idle guidance starts and rotates less predictably."""
            tips = self._workspace_tips
            if not tips:
                return []
            return _sample_workspace_tip_order(len(tips))

        def _rotate_workspace_tip(self) -> None:
            """Rotate idle tips only while the empty shell landing view is visible."""
            if not self._workspace_tips or self._transcript_lines:
                return
            if not self._workspace_tip_order:
                self._workspace_tip_order = self._build_workspace_tip_order()
                self._workspace_tip_index = 0
            else:
                self._workspace_tip_index += 1
                if self._workspace_tip_index >= len(self._workspace_tip_order):
                    self._workspace_tip_order = self._build_workspace_tip_order()
                    self._workspace_tip_index = 0
            try:
                tip = self.query_one("#tip", Static)
            except Exception:  # pragma: no cover - defensive query guard
                return
            tip.update(self._current_tip_text())

        def on_unmount(self) -> None:  # pragma: no cover - UI lifecycle hook
            """Cancel in-flight inline workers when workspace unmounts."""
            cancel_worker_group(self, WORKSPACE_INLINE_WORKER_GROUP)
            self._inline_status_running = False
            self._inline_details_running = False
            self._inline_message_running = False
            self._inline_picker_running = False
            parent_on_unmount = getattr(super(), "on_unmount", None)
            if callable(parent_on_unmount):
                parent_on_unmount()  # type: ignore[misc]

        def _tick_logo(self) -> None:
            """Animate workspace logo pulse while logo nodes are visible."""
            has_center_logo = bool(list(self.query(_PREFIX_TITLE)))
            has_header_brand = bool(list(self.query(f"#{HOME_CONTEXT_BRAND_ID}")))
            if not has_center_logo and not has_header_brand:
                return

            now = time.monotonic()
            if now < self._logo_resume_at:
                return

            step, direction, reversed_edge = _next_logo_pulse_state(
                self._logo_pulse_step,
                self._logo_pulse_dir,
                self._logo_max_width,
                self._logo_step_size,
            )
            self._logo_pulse_step = step
            self._logo_pulse_dir = direction
            if reversed_edge:
                self._logo_resume_at = now + _LOGO_EDGE_PAUSE_SECONDS
            self._render_logo()

        def _render_logo(self) -> None:
            """Render animated GL AIP logo across home and workspace surfaces."""
            title_nodes = [node for node in self.query(_PREFIX_TITLE) if isinstance(node, Static)]
            if title_nodes:
                logo = _render_shining_logo(self._logo_lines, self._logo_pulse_step)
                update_title = getattr(title_nodes[0], "update", None)
                if callable(update_title):
                    update_title(logo)

            brand_nodes = [node for node in self.query(f"#{HOME_CONTEXT_BRAND_ID}") if isinstance(node, Static)]
            if not brand_nodes:
                return

            brand_step = _map_logo_pulse_step(
                self._logo_pulse_step,
                self._logo_max_width,
                self._home_brand_max_width,
            )
            brand = _render_shining_logo(self._home_brand_lines, brand_step)
            update_brand = getattr(brand_nodes[0], "update", None)
            if callable(update_brand):
                update_brand(brand)

        def _is_slash_open(self) -> bool:
            """Return True when slash suggestion dropdown is currently visible."""
            try:
                return not self.query_one(f"#{SLASH_WRAP_ID}", Container).has_class("-hidden")
            except Exception:  # pragma: no cover - defensive Textual query guard
                return False

        def _close_slash_menu(self) -> None:
            """Hide slash dropdown and clear selection state."""
            self._slash_filtered = []
            self._slash_selected_index = 0
            self._slash_scroll_offset = 0
            try:
                self.query_one(f"#{SLASH_WRAP_ID}", Container).add_class("-hidden")
            except Exception:  # pragma: no cover - defensive Textual query guard
                pass

        def _refresh_slash_menu(self, value: str) -> None:
            """Refresh slash dropdown suggestions from current composer text."""
            if (
                self._pending_command_event is not None
                or self._inline_status_running
                or self._inline_message_running
                or self._inline_picker_running
            ):
                self._close_slash_menu()
                return

            if "\n" in str(value or ""):
                self._close_slash_menu()
                return

            trimmed = value.lstrip()
            if not trimmed.startswith("/"):
                self._close_slash_menu()
                return

            query = trimmed[1:].strip().lower()
            if query:
                filtered = [
                    item
                    for item in self._slash_dropdown_commands
                    if query in item[0][1:].lower() or query in item[1].lower()
                ]
            else:
                filtered = list(self._slash_dropdown_commands)

            self._slash_filtered = filtered
            self._slash_selected_index = 0
            self._slash_scroll_offset = 0
            self._sync_slash_scroll_window()
            self._refresh_slash_rows()
            self._position_slash_menu()
            try:
                self.query_one(f"#{SLASH_WRAP_ID}", Container).remove_class("-hidden")
            except Exception:  # pragma: no cover - defensive Textual query guard
                pass

        def _sync_slash_scroll_window(self) -> None:
            """Keep slash selected row within the visible dropdown window."""
            total = len(self._slash_filtered)
            if total <= 0:
                self._slash_scroll_offset = 0
                return

            self._slash_selected_index = max(0, min(self._slash_selected_index, total - 1))
            visible = max(1, min(_MAX_VISIBLE_SLASH_ROWS, total))
            max_offset = max(0, total - visible)
            self._slash_scroll_offset = max(0, min(self._slash_scroll_offset, max_offset))

            if self._slash_selected_index < self._slash_scroll_offset:
                self._slash_scroll_offset = self._slash_selected_index
                return
            if self._slash_selected_index >= self._slash_scroll_offset + visible:
                self._slash_scroll_offset = self._slash_selected_index - visible + 1

        def _refresh_slash_rows(self) -> None:
            """Render slash dropdown rows with current highlight state."""
            try:
                rows = self.query_one(f"#{SLASH_ROWS_ID}", Static)
            except Exception:  # pragma: no cover - defensive Textual query guard
                return

            if not self._slash_filtered:
                rows.update(RichText("No matching slash commands", style=WORKSPACE_THEME["muted"]))
                return

            self._sync_slash_scroll_window()
            total = len(self._slash_filtered)
            visible = max(1, min(_MAX_VISIBLE_SLASH_ROWS, total))
            start = self._slash_scroll_offset
            end = min(total, start + visible)

            table = RichTable.grid(expand=True)
            table.add_column(ratio=1)
            table.add_column(ratio=2)

            for idx, (command, description) in enumerate(self._slash_filtered[start:end], start=start):
                if idx == self._slash_selected_index:
                    command_text = RichText(command, style=_SELECTED_ROW_STYLE)
                    desc_text = RichText(description, style=_SELECTED_ROW_STYLE)
                else:
                    command_text = RichText(command, style=WORKSPACE_THEME["text"])
                    desc_text = RichText(description, style=WORKSPACE_THEME["muted"])
                table.add_row(command_text, desc_text)

            rows.update(table)

        def _position_slash_menu(self) -> None:
            """Anchor slash dropdown near composer cursor location."""
            try:
                composer_box = self.query_one("#composer-box", Container)
                composer = self.query_one(f"#{COMPOSER_ID}", Input)
                slash_wrap = self.query_one(f"#{SLASH_WRAP_ID}", Container)

                region = composer_box.region
                menu_width = 72
                menu_height = self._estimate_slash_menu_height(len(self._slash_filtered))
                x, y = self._clamp_slash_menu_offset(
                    screen_width=int(self.size.width),
                    screen_height=int(self.size.height),
                    anchor_x=int(region.x + 2 + int(composer.cursor_position)),
                    anchor_y=int(region.y + region.height - 1),
                    composer_top=int(region.y),
                    menu_width=menu_width,
                    menu_height=menu_height,
                )
                slash_wrap.styles.offset = (x, y)
            except Exception:  # pragma: no cover - defensive Textual region guard
                pass

        @staticmethod
        def _estimate_slash_menu_height(row_count: int) -> int:
            """Estimate menu height from row count within CSS min/max bounds."""
            return min(11, max(5, int(row_count) + 2))

        @staticmethod
        def _clamp_slash_menu_offset(
            *,
            screen_width: int,
            screen_height: int,
            anchor_x: int,
            anchor_y: int,
            composer_top: int,
            menu_width: int,
            menu_height: int,
        ) -> tuple[int, int]:
            """Clamp slash menu offset to the visible viewport.

            When there isn't enough room below the composer, place the menu above it.
            """
            max_x = max(0, int(screen_width) - int(menu_width) - 2)
            x = min(max(int(anchor_x), 0), max_x)

            max_y = max(0, int(screen_height) - int(menu_height) - 1)
            y = max(0, int(anchor_y))
            if y > max_y:
                y = max(0, int(composer_top) - int(menu_height))
            y = min(y, max_y)
            return x, y

        def _is_palette_open(self) -> bool:
            """Return True when the floating command palette is visible."""
            return self.palette_open

        def _close_palette(self, *, restore_focus: bool = True) -> None:
            """Hide the floating palette and optionally restore focus to the composer."""
            self._palette_filtered = []
            self._palette_selected_index = 0
            self._palette_scroll_offset = 0
            self.palette_open = False
            self.palette_query = ""
            self.palette_selected_index = 0
            try:
                self.query_one(f"#{PALETTE_WRAP_ID}", Container).add_class("-hidden")
            except Exception:  # pragma: no cover - defensive Textual query guard
                pass

            if not restore_focus:
                return

            composer = self.query_one(f"#{COMPOSER_ID}", Input)
            composer.focus()

        def _open_palette(self) -> None:
            """Open the floating command palette anchored to the workspace shell."""
            if (
                self._pending_command_event is not None
                or self._inline_status_running
                or self._inline_details_running
                or self._inline_message_running
                or self._inline_picker_running
            ):
                return

            self._close_slash_menu()
            self._palette_actions = build_palette_actions(self)
            self._palette_selected_index = 0
            self._palette_scroll_offset = 0
            self.palette_open = True
            self.palette_query = ""
            self.palette_selected_index = 0

            search = self.query_one(f"#{PALETTE_SEARCH_ID}", TextInput)
            search.value = ""
            self._refresh_palette_results("")
            self._position_palette_menu()
            self.query_one(f"#{PALETTE_WRAP_ID}", Container).remove_class("-hidden")
            search.focus()

        def _refresh_palette_results(self, query: str) -> None:
            """Recompute command palette matches for the current query."""
            self._palette_filtered = filter_palette_actions(self._palette_actions, query)
            self._palette_selected_index = 0
            self.palette_query = query
            self.palette_selected_index = 0
            self._palette_scroll_offset = 0
            self._refresh_palette_rows(query)
            self._position_palette_menu()

        def _sync_palette_scroll_window(self) -> None:
            """Keep the selected palette row within the visible window."""
            total = len(self._palette_filtered)
            if total <= 0:
                self._palette_scroll_offset = 0
                return

            self._palette_selected_index = max(0, min(self._palette_selected_index, total - 1))
            visible = max(1, min(_MAX_VISIBLE_PALETTE_ROWS, total))
            max_offset = max(0, total - visible)
            self._palette_scroll_offset = max(0, min(self._palette_scroll_offset, max_offset))

            if self._palette_selected_index < self._palette_scroll_offset:
                self._palette_scroll_offset = self._palette_selected_index
                return
            if self._palette_selected_index >= self._palette_scroll_offset + visible:
                self._palette_scroll_offset = self._palette_selected_index - visible + 1

        def _palette_pane_bounds(self) -> tuple[int, int, int, int]:
            """Return the active workspace pane bounds used for palette centering."""
            try:
                pane = self.query_one(f"#{LEFT_COLUMN_ID}", Vertical)
                region = pane.region
                return (int(region.x), int(region.y), max(1, int(region.width)), max(1, int(region.height)))
            except Exception:  # pragma: no cover - defensive Textual lifecycle guard
                return (0, 0, max(1, int(self.size.width)), max(1, int(self.size.height)))

        @staticmethod
        def _palette_menu_width(pane_width: int) -> int:
            """Return a responsive palette width based on the active pane width."""
            available_width = max(_MIN_PALETTE_WIDTH, int(pane_width) - _PALETTE_SIDE_GUTTER)
            return min(_MAX_PALETTE_WIDTH, available_width)

        @staticmethod
        def _truncate_palette_text(value: str, max_width: int) -> str:
            """Truncate palette row text with an ellipsis when it exceeds the allowed width."""
            normalized = " ".join(str(value or "").split())
            if max_width <= 0:
                return ""
            if len(normalized) <= max_width:
                return normalized
            if max_width <= 3:
                return "." * max_width
            return f"{normalized[: max_width - 3].rstrip()}..."

        @staticmethod
        def _palette_row_layout(content_width: int) -> tuple[int, int] | None:
            """Return label/hint widths for two-column rows, or None for label-only layout."""
            if content_width < 36:
                return None
            hint_width = min(24, max(12, content_width // 3))
            label_width = max(12, content_width - hint_width - 2)
            return label_width, hint_width

        def _palette_render_width(self) -> int:
            """Return the current palette content width available for row rendering."""
            _, _, pane_width, _ = self._palette_pane_bounds()
            return max(12, self._palette_menu_width(pane_width) - _PALETTE_CHROME_WIDTH)

        def _render_palette_row(
            self,
            action: PaletteAction,
            *,
            selected: bool,
            content_width: int,
            row_layout: tuple[int, int] | None,
        ) -> RichText:
            """Render one palette row with responsive hint fallback."""
            label_text = action.display_text
            hint_text = action.hint_text or ""
            if selected:
                return self._render_selected_palette_row(label_text, hint_text, content_width, row_layout)
            return self._render_unselected_palette_row(label_text, hint_text, content_width, row_layout)

        def _render_selected_palette_row(
            self,
            label_text: str,
            hint_text: str,
            content_width: int,
            row_layout: tuple[int, int] | None,
        ) -> RichText:
            """Render the highlighted palette row."""
            selected_style = _SELECTED_ROW_STYLE
            line = RichText(style=selected_style)
            line.append(" " * _PALETTE_ROW_INSET, style=selected_style)
            if row_layout is None:
                line.append(self._truncate_palette_text(label_text, content_width), style=selected_style)
                line.append(" " * _PALETTE_ROW_INSET, style=selected_style)
                return line

            label_width, hint_width = row_layout
            line.append(self._truncate_palette_text(label_text, label_width).ljust(label_width), style=selected_style)
            line.append("  ", style=selected_style)
            line.append(self._truncate_palette_text(hint_text, hint_width).rjust(hint_width), style=selected_style)
            line.append(" " * _PALETTE_ROW_INSET, style=selected_style)
            return line

        def _render_unselected_palette_row(
            self,
            label_text: str,
            hint_text: str,
            content_width: int,
            row_layout: tuple[int, int] | None,
        ) -> RichText:
            """Render a non-selected palette row."""
            line = RichText()
            line.append(" " * _PALETTE_ROW_INSET)
            if row_layout is None:
                line.append(self._truncate_palette_text(label_text, content_width), style=WORKSPACE_THEME["text"])
                line.append(" " * _PALETTE_ROW_INSET)
                return line

            label_width, hint_width = row_layout
            line.append(
                self._truncate_palette_text(label_text, label_width).ljust(label_width), style=WORKSPACE_THEME["text"]
            )
            line.append("  ")
            line.append(
                self._truncate_palette_text(hint_text, hint_width).rjust(hint_width), style=WORKSPACE_THEME["muted"]
            )
            line.append(" " * _PALETTE_ROW_INSET)
            return line

        def _refresh_palette_rows(self, query: str) -> None:
            """Render the floating command palette rows."""
            rows = self.query_one(f"#{PALETTE_ROWS_ID}", Static)
            section = self.query_one(f"#{PALETTE_SECTION_ID}", Static)

            section.update("Results" if query.strip() else "Suggested")

            if not self._palette_filtered:
                rows.update(
                    RichText("No matching commands - try /runs, /help, or a shortcut.", style=WORKSPACE_THEME["muted"])
                )
                return

            self._sync_palette_scroll_window()
            total = len(self._palette_filtered)
            visible = max(1, min(_MAX_VISIBLE_PALETTE_ROWS, total))
            start = self._palette_scroll_offset
            end = min(total, start + visible)
            content_width = max(8, self._palette_render_width() - (_PALETTE_ROW_INSET * 2))
            row_layout = self._palette_row_layout(content_width)
            rendered = RichText()

            for idx, action in enumerate(self._palette_filtered[start:end], start=start):
                if rendered:
                    rendered.append("\n")
                line = self._render_palette_row(
                    action,
                    selected=idx == self._palette_selected_index,
                    content_width=content_width,
                    row_layout=row_layout,
                )
                rendered.append_text(line)

            rows.update(rendered)

        def _position_palette_menu(self) -> None:
            """Center the floating command palette over the workspace surface."""
            try:
                palette_wrap = self.query_one(f"#{PALETTE_WRAP_ID}", Container)
                pane_x, pane_y, pane_width, pane_height = self._palette_pane_bounds()
                menu_width = self._palette_menu_width(pane_width)
                menu_height = self._estimate_palette_menu_height(len(self._palette_filtered))
                x = pane_x + max(0, (pane_width - menu_width) // 2)
                y = pane_y + max(0, (pane_height - menu_height) // 2)
                palette_wrap.styles.width = menu_width
                palette_wrap.styles.offset = (x, y)
            except Exception:  # pragma: no cover - defensive Textual region guard
                pass

        def _refresh_open_palette_layout(self) -> None:
            """Reflow the open commands overlay after workspace geometry changes."""
            if not self._is_palette_open():
                return
            self._refresh_palette_rows(self.palette_query)
            self._position_palette_menu()

        @staticmethod
        def _estimate_palette_menu_height(row_count: int) -> int:
            """Estimate floating palette height from visible rows."""
            visible_rows = max(1, min(_MAX_VISIBLE_PALETTE_ROWS, int(row_count or 0)))
            return min(18, max(11, visible_rows + 7))

        def _activate_palette_selection(self) -> None:
            """Run the selected palette action and close the floating overlay."""
            if not self._palette_filtered:
                return

            selected = self._palette_filtered[self._palette_selected_index]
            self._close_palette(restore_focus=False)
            selected.callback()

        def action_toggle_sidebar(self) -> None:
            """Toggle right sidebar visibility."""
            if self._mode != "agent":
                return
            self._sidebar_visible = not self._sidebar_visible
            sidebar = self.query_one(f"#{SIDEBAR_ID}", Vertical)
            if self._sidebar_visible:
                sidebar.remove_class("-hidden")
            else:
                sidebar.add_class("-hidden")
            self._refresh_chrome_visibility()
            refresh_after_layout = getattr(self, "call_after_refresh", None)
            if self._is_palette_open() and callable(refresh_after_layout):
                refresh_after_layout(self._refresh_open_palette_layout)
            elif self._is_palette_open():
                self._refresh_open_palette_layout()

        def action_quick_agents_selector(self) -> None:
            """Prefill /agents and keep slash menu open in home mode."""
            if self._mode != "home":
                return
            composer = self.query_one(f"#{COMPOSER_ID}", Input)
            composer.value = _AGENTS_COMMAND
            composer.cursor_position = len(composer.value)
            self._refresh_slash_menu(composer.value)
            composer.focus()

        def _escape_confirmation_message(self) -> str:
            """Return user-facing confirmation copy for boundary ESC actions."""
            if self._mode == "home":
                return "Press Enter or Esc again to exit to terminal. Any other key cancels."
            return "Press Enter or Esc again to go back. Any other key cancels."

        def _show_escape_confirmation_hint(self) -> None:
            """Show an inline footer hint while ESC confirmation is armed."""
            message = self._escape_confirmation_message()
            try:
                loading = self.query_one(f"#{COMMAND_LOADING_ID}", Static)
            except Exception:  # pragma: no cover - defensive Textual lifecycle guard
                loading = None

            if loading is None:
                return

            update_message = getattr(loading, "update_message", None)
            if callable(update_message):
                update_message(message)
            else:
                loading.update(message)
            loading.remove_class("-hidden")
            loading.add_class("-active")
            start = getattr(loading, "start", None)
            if callable(start):
                start()

            self._escape_confirm_hint_visible = True

            try:
                tip = self.query_one("#tip", Static)
                tip.add_class("-hidden")
            except Exception:  # pragma: no cover - defensive Textual lifecycle guard
                pass

        def _hide_escape_confirmation_hint(self) -> None:
            """Hide footer hint shown by ESC confirmation flow."""
            if not self._escape_confirm_hint_visible:
                return
            self._escape_confirm_hint_visible = False

            if (
                self._pending_command_event is not None
                or self._inline_status_running
                or self._inline_details_running
                or self._inline_message_running
                or self._inline_picker_running
            ):
                return

            try:
                loading = self.query_one(f"#{COMMAND_LOADING_ID}", Static)
            except Exception:  # pragma: no cover - defensive Textual lifecycle guard
                loading = None

            if loading is not None:
                stop = getattr(loading, "stop", None)
                if callable(stop):
                    stop()
                loading.remove_class("-active")
                loading.add_class("-hidden")

            try:
                tip = self.query_one("#tip", Static)
                tip.remove_class("-hidden")
            except Exception:  # pragma: no cover - defensive Textual lifecycle guard
                pass

        def _clear_escape_confirmation(self) -> None:
            """Clear ESC confirmation state, timeout, and hint visibility."""
            self._escape_confirm_target = None
            timer = self._escape_confirm_timer
            self._escape_confirm_timer = None
            stop = getattr(timer, "stop", None)
            if callable(stop):
                stop()
            self._hide_escape_confirmation_hint()

        def _arm_escape_confirmation(self) -> None:
            """Arm ESC confirmation timeout for close-boundary actions."""
            target = _ESCAPE_CONFIRM_EXIT_TERMINAL if self._mode == "home" else _ESCAPE_CONFIRM_BACK
            self._clear_escape_confirmation()
            self._escape_confirm_target = target
            self._show_escape_confirmation_hint()
            self._escape_confirm_timer = self.set_timer(ESCAPE_CONFIRM_TIMEOUT_SECONDS, self._clear_escape_confirmation)

        def _should_require_escape_confirmation(self) -> bool:
            """Return True when ESC should require a confirmation step."""
            return True

        def _confirm_close_from_escape(self) -> None:
            """Finalize a confirmed ESC close action."""
            self._clear_escape_confirmation()
            self.exit(None)

        def action_close_overlay_or_exit(self) -> None:
            """Close slash dropdown first; otherwise exit workspace shell."""
            if self._is_palette_open():
                self._close_palette()
                self._clear_escape_confirmation()
                return

            if self._is_slash_open():
                self._close_slash_menu()
                composer = self.query_one(f"#{COMPOSER_ID}", Input)
                composer.focus()
                self._clear_escape_confirmation()
                return

            if self._should_require_escape_confirmation():
                if self._escape_confirm_target is not None:
                    self._confirm_close_from_escape()
                    return
                self._arm_escape_confirmation()
                return

            self._clear_escape_confirmation()
            self.exit(None)

        def action_transcript_page_up(self) -> None:
            """Scroll transcript viewport upward by one page."""
            transcript_scroll = self.query_one(f"#{TRANSCRIPT_SCROLL_ID}")
            scroll_page_up = getattr(transcript_scroll, "scroll_page_up", None)
            if callable(scroll_page_up):
                scroll_page_up(animate=False)

        def action_transcript_page_down(self) -> None:
            """Scroll transcript viewport downward by one page."""
            transcript_scroll = self.query_one(f"#{TRANSCRIPT_SCROLL_ID}")
            scroll_page_down = getattr(transcript_scroll, "scroll_page_down", None)
            if callable(scroll_page_down):
                scroll_page_down(animate=False)

        def action_submit_composer(self) -> None:
            """Emit message/command/exit event from composer input."""
            if self._escape_confirm_target is not None:
                self._confirm_close_from_escape()
                return

            if (
                self._pending_command_event is not None
                or self._inline_status_running
                or self._inline_details_running
                or self._inline_message_running
                or self._inline_picker_running
            ):
                return

            composer = self.query_one(f"#{COMPOSER_ID}", Input)
            value = (composer.value or "").strip()
            if not value:
                return

            if value.startswith("/") and self._is_slash_open() and self._slash_filtered:
                selected_idx = max(0, min(self._slash_selected_index, len(self._slash_filtered) - 1))
                selected_command, _ = self._slash_filtered[selected_idx]
                value = selected_command
                composer.value = selected_command

            self._close_slash_menu()
            self._remember_composer_history(value)
            self._reset_composer_history_navigation()

            if value.startswith("/"):
                self._handle_slash_submit(value)
                return

            if self._mode == "home":
                self._append_user_entry(value)
                self._append_transcript_line(
                    "Status: This screen only accepts slash commands. Type / to browse commands."
                )
                composer.value = ""
                composer.disabled = False
                composer.focus()
                self._refresh_chrome_visibility()
                return

            if self._message_run_provider is not None:
                self._run_inline_message(value)
                return

            self.exit(AgentWorkspaceEvent(kind="message", value=value))

        def _handle_slash_submit(self, value: str) -> None:
            """Process a slash command submission."""
            command = value.split(maxsplit=1)[0].lower()
            command_meta = self._command_index.get(command)
            if command_meta is None:
                self._reject_workspace_command(value)
                return

            if command_meta.route == "exit":
                self.exit(AgentWorkspaceEvent(kind="exit", value=value))
                return

            if command_meta.route == "inline_status" and self._status_summary_provider is not None:
                self._run_inline_status(value)
                return

            if (
                command == _MODELS_COMMAND
                and callable(self._model_picker_provider)
                and callable(self._model_apply_provider)
            ):
                self._run_inline_model_picker(value)
                return

            if (
                command == _TOOLS_COMMAND
                and callable(self._tools_picker_provider)
                and callable(self._tools_apply_provider)
            ):
                self._run_inline_resource_picker(
                    value,
                    picker_provider=self._tools_picker_provider,
                    apply_provider=self._tools_apply_provider,
                    picker_factory=AgentToolsPickerScreen,
                )
                return

            if (
                command == _MCPS_COMMAND
                and callable(self._mcps_picker_provider)
                and callable(self._mcps_apply_provider)
            ):
                self._run_inline_resource_picker(
                    value,
                    picker_provider=self._mcps_picker_provider,
                    apply_provider=self._mcps_apply_provider,
                    picker_factory=AgentToolsPickerScreen,
                )
                return

            if command in {_HELP_COMMAND, "/?"}:
                self._run_inline_help(value)
                return

            if command == _DETAILS_COMMAND and callable(self._details_provider):
                self._run_inline_details(value)
                return

            self._queue_command_transition(value)

        def _remember_composer_history(self, value: str) -> None:
            """Append submitted command/message into in-session composer history."""
            text = str(value or "").strip()
            if not text:
                return
            self._composer_history.append(text)

        def _reset_composer_history_navigation(self) -> None:
            """Reset composer history cursor after manual edits/submissions."""
            self._composer_history_index = None
            self._composer_history_draft = ""

        def _composer_has_focus(self) -> bool:
            """Return True when key events originate from the composer input."""
            focused = getattr(self, "focused", None)
            return isinstance(focused, Input) and focused.id == COMPOSER_ID

        def _navigate_composer_history(self, direction: str) -> bool:
            """Navigate command/query history using shell-style up/down keys."""
            if direction not in {"up", "down"}:
                return False
            if not self._composer_history:
                return False

            composer = self.query_one(f"#{COMPOSER_ID}", Input)
            if "\n" in (composer.value or ""):
                return False
            index = self._composer_history_index
            if direction == "up":
                if index is None:
                    self._composer_history_draft = composer.value
                    index = len(self._composer_history) - 1
                else:
                    index = max(0, index - 1)
            else:
                if index is None:
                    return False
                if index >= len(self._composer_history) - 1:
                    composer.value = self._composer_history_draft
                    composer.cursor_position = len(composer.value)
                    self._composer_history_index = None
                    self._refresh_slash_menu(composer.value)
                    return True
                index += 1

            self._composer_history_index = index
            composer.value = self._composer_history[index]
            composer.cursor_position = len(composer.value)
            self._refresh_slash_menu(composer.value)
            return True

        def _run_inline_help(self, command_text: str) -> None:
            """Append descriptive help hints without leaving the workspace."""
            self._append_command_entry(command_text)

            context_label = "Home Launcher" if self._mode == "home" else "Workspace"
            help_lines = [f"System: Available {context_label} Commands:"]
            unique_commands = sorted(
                {item.name: item for item in self._slash_commands}.values(),
                key=lambda item: item.name.lower(),
            )
            for command in unique_commands:
                help_lines.append(f"  {command.name:<12} - {command.description}")
            help_lines.append("")
            if self._mode == "home":
                help_lines.append("Tip: Type / to browse commands. Use /agents as your primary entrypoint.")
            else:
                help_lines.append("Tip: Type / to browse commands. Use /status for quick inline diagnostics.")

            for line in help_lines:
                self._append_transcript_line(line)

            composer = self.query_one(f"#{COMPOSER_ID}", Input)
            composer.value = ""
            composer.disabled = False
            composer.focus()
            self._refresh_chrome_visibility()

        def _run_inline_details(self, command_text: str) -> None:
            """Execute details provider and keep users on the current workspace surface."""
            self._inline_details_running = True
            composer = self.query_one(f"#{COMPOSER_ID}", Input)
            composer.disabled = True

            loading = self.query_one(f"#{COMMAND_LOADING_ID}", Static)
            update_message = getattr(loading, "update_message", None)
            if callable(update_message):
                update_message(f"Loading {command_text}...")
            else:
                loading.update(f"Loading {command_text}...")
            loading.remove_class("-hidden")
            loading.add_class("-active")
            start = getattr(loading, "start", None)
            if callable(start):
                start()

            tip = self.query_one("#tip", Static)
            tip.add_class("-hidden")

            self.run_worker(
                self._run_inline_details_task(command_text),
                name="workspace-inline-details",
                group=WORKSPACE_INLINE_WORKER_GROUP,
                exclusive=True,
            )

        async def _run_inline_details_task(self, command_text: str) -> None:
            """Run inline details provider in a Textual worker."""
            try:
                lines = await asyncio.to_thread(self._run_inline_details_provider)
            except Exception as exc:  # pragma: no cover - defensive runtime guard
                lines = [f"{_DETAILS_SENTINEL}details:", f"{_DETAILS_SENTINEL}  error: {exc}"]
            self._finalize_inline_details(command_text, lines)

        def _run_inline_details_provider(self) -> list[str]:
            """Collect details lines from the configured provider."""
            provider = self._details_provider
            if not callable(provider):
                return []
            return list(provider())

        def _finalize_inline_details(self, command_text: str, lines: list[str]) -> None:
            """Render details output, store for copy, and restore workspace controls."""
            self._last_details_lines = list(lines) if lines else None
            self._append_command_entry(command_text)
            if lines:
                for line in lines:
                    self._append_transcript_line(line)
            else:
                self._append_transcript_line("System: Details unavailable")

            loading = self.query_one(f"#{COMMAND_LOADING_ID}", Static)
            stop = getattr(loading, "stop", None)
            if callable(stop):
                stop()
            loading.remove_class("-active")
            loading.add_class("-hidden")

            composer = self.query_one(f"#{COMPOSER_ID}", Input)
            composer.value = ""
            composer.disabled = False
            composer.focus()

            self._inline_details_running = False
            self._refresh_chrome_visibility()
            self._schedule_followup_capture()

        def _set_inline_loading_state(self, message: str) -> None:
            """Show the footer loading state and disable the composer."""
            composer = self.query_one(f"#{COMPOSER_ID}", Input)
            composer.disabled = True

            loading = self.query_one(f"#{COMMAND_LOADING_ID}", Static)
            update_message = getattr(loading, "update_message", None)
            if callable(update_message):
                update_message(message)
            else:
                loading.update(message)
            loading.remove_class("-hidden")
            loading.add_class("-active")
            start = getattr(loading, "start", None)
            if callable(start):
                start()

            tip = self.query_one("#tip", Static)
            tip.add_class("-hidden")

        def _restore_composer_after_inline_flow(self) -> None:
            """Restore composer and footer chrome after inline operations."""
            loading = self.query_one(f"#{COMMAND_LOADING_ID}", Static)
            stop = getattr(loading, "stop", None)
            if callable(stop):
                stop()
            loading.remove_class("-active")
            loading.add_class("-hidden")

            composer = self.query_one(f"#{COMPOSER_ID}", Input)
            composer.value = ""
            composer.disabled = False
            composer.focus()
            self._refresh_chrome_visibility()

        def _run_inline_model_picker(self, command_text: str) -> None:
            """Fetch model picker data and open the overlay inline."""
            picker_provider = self._model_picker_provider
            apply_provider = self._model_apply_provider
            if not callable(picker_provider) or not callable(apply_provider):
                self._queue_command_transition(command_text)
                return

            self._inline_picker_running = True
            self._set_inline_loading_state(f"Loading {command_text}...")
            self.run_worker(
                self._run_inline_model_picker_task(command_text, picker_provider, apply_provider),
                name="workspace-inline-model-picker",
                group=WORKSPACE_INLINE_WORKER_GROUP,
                exclusive=True,
            )

        async def _run_inline_model_picker_task(
            self,
            command_text: str,
            picker_provider: ModelPickerProvider,
            apply_provider: ModelApplyProvider,
        ) -> None:
            """Collect model picker data without blocking the Textual event loop."""
            try:
                payload = await asyncio.to_thread(picker_provider)
            except Exception as exc:  # pragma: no cover - defensive runtime guard
                self._finalize_inline_picker_failure(command_text, exc)
                return
            self._present_inline_model_picker(command_text, payload, apply_provider)

        def _present_inline_model_picker(
            self,
            command_text: str,
            payload: AgentModelPickerInput,
            apply_provider: ModelApplyProvider,
        ) -> None:
            """Open the model picker overlay once its payload is ready."""
            self._inline_picker_running = False
            self._append_command_entry(command_text)
            if not payload.options:
                self._append_transcript_line("System: No models are available for this account.")
                self._restore_composer_after_inline_flow()
                self._schedule_followup_capture()
                return

            self._restore_composer_after_inline_flow()
            self.push_screen(
                AgentModelPickerScreen(payload),
                lambda selected_id: self._handle_model_picker_result(
                    command_text,
                    payload,
                    apply_provider,
                    cast(str | None, selected_id),
                ),
            )
            self._schedule_followup_capture()

        def _handle_model_picker_result(
            self,
            command_text: str,
            payload: AgentModelPickerInput,
            apply_provider: ModelApplyProvider,
            selected_id: str | None,
        ) -> None:
            """Apply a chosen model or record a cancelled picker flow."""
            if not selected_id:
                self._append_workspace_status(f"{command_text} cancelled")
                self._restore_composer_after_inline_flow()
                self._schedule_followup_capture()
                return

            if selected_id == (payload.selected_id or ""):
                self._append_workspace_status(f"{command_text} unchanged")
                self._restore_composer_after_inline_flow()
                self._schedule_followup_capture()
                return

            selected_label = next((option.label for option in payload.options if option.id == selected_id), selected_id)
            self._inline_picker_running = True
            self._set_inline_loading_state(f"Saving {command_text} -> {selected_label}...")
            self.run_worker(
                self._apply_inline_model_selection(command_text, selected_id, selected_label, apply_provider),
                name="workspace-inline-model-apply",
                group=WORKSPACE_INLINE_WORKER_GROUP,
                exclusive=True,
            )

        async def _apply_inline_model_selection(
            self,
            command_text: str,
            selected_id: str,
            selected_label: str,
            apply_provider: ModelApplyProvider,
        ) -> None:
            """Persist selected model and refresh workspace metadata."""
            try:
                updated_details = await asyncio.to_thread(apply_provider, selected_id)
            except Exception as exc:  # pragma: no cover - defensive runtime guard
                self._finalize_inline_picker_failure(command_text, exc)
                return
            self._details = updated_details
            self._refresh_workspace_details_widgets()
            actual_label = str(getattr(updated_details, "model_label", "") or MODEL_LABEL_PLACEHOLDER)
            if actual_label != selected_label:
                self._append_workspace_status(
                    f"{command_text} saved with refresh mismatch (requested {selected_label}; server {actual_label})"
                )
            else:
                self._append_workspace_status(f"{command_text} saved: {selected_label}")
            self._inline_picker_running = False
            self._restore_composer_after_inline_flow()
            self._schedule_followup_capture()

        def _run_inline_resource_picker(
            self,
            command_text: str,
            *,
            picker_provider: ResourcePickerProvider,
            apply_provider: ResourceApplyProvider,
            picker_factory: type[AgentToolsPickerScreen],
        ) -> None:
            """Fetch tools/MCP picker data and open the overlay inline."""
            self._inline_picker_running = True
            self._set_inline_loading_state(f"Loading {command_text}...")
            self.run_worker(
                self._run_inline_resource_picker_task(
                    command_text,
                    picker_provider=picker_provider,
                    apply_provider=apply_provider,
                    picker_factory=picker_factory,
                ),
                name=f"workspace-inline-{command_text.strip('/').replace('-', '_')}-picker",
                group=WORKSPACE_INLINE_WORKER_GROUP,
                exclusive=True,
            )

        async def _run_inline_resource_picker_task(
            self,
            command_text: str,
            *,
            picker_provider: ResourcePickerProvider,
            apply_provider: ResourceApplyProvider,
            picker_factory: type[AgentToolsPickerScreen],
        ) -> None:
            """Collect multi-select picker data without blocking the event loop."""
            try:
                payload = await asyncio.to_thread(picker_provider)
            except Exception as exc:  # pragma: no cover - defensive runtime guard
                self._finalize_inline_picker_failure(command_text, exc)
                return
            self._present_inline_resource_picker(
                command_text,
                payload=payload,
                apply_provider=apply_provider,
                picker_factory=picker_factory,
            )

        def _present_inline_resource_picker(
            self,
            command_text: str,
            *,
            payload: AgentResourcePickerInput,
            apply_provider: ResourceApplyProvider,
            picker_factory: type[AgentToolsPickerScreen],
        ) -> None:
            """Open tools/MCP picker once its payload is ready."""
            self._inline_picker_running = False
            self._append_command_entry(command_text)
            if not payload.options:
                self._append_transcript_line(f"System: No resources are available for {command_text}.")
                self._restore_composer_after_inline_flow()
                self._schedule_followup_capture()
                return

            self._restore_composer_after_inline_flow()
            self.push_screen(
                picker_factory(payload),
                lambda selected_ids: self._handle_resource_picker_result(
                    command_text,
                    payload=payload,
                    apply_provider=apply_provider,
                    selected_ids=cast(list[str] | None, selected_ids),
                ),
            )
            self._schedule_followup_capture()

        def _handle_resource_picker_result(
            self,
            command_text: str,
            *,
            payload: AgentResourcePickerInput,
            apply_provider: ResourceApplyProvider,
            selected_ids: list[str] | None,
        ) -> None:
            """Apply selected tools/MCPs or record a cancelled picker flow."""
            current_ids = sorted(item for item in payload.selected_ids if item)
            normalized_ids = sorted(item for item in (selected_ids or []) if item)
            if selected_ids is None:
                self._append_workspace_status(f"{command_text} cancelled")
                self._restore_composer_after_inline_flow()
                self._schedule_followup_capture()
                return

            if normalized_ids == current_ids:
                self._append_workspace_status(f"{command_text} unchanged")
                self._restore_composer_after_inline_flow()
                self._schedule_followup_capture()
                return

            pending_summary = _summarize_pending_resource_names(payload, normalized_ids)
            self._inline_picker_running = True
            self._set_inline_loading_state(f"Saving {command_text} -> {pending_summary}...")
            self.run_worker(
                self._apply_inline_resource_selection(command_text, payload, normalized_ids, apply_provider),
                name=f"workspace-inline-{command_text.strip('/').replace('-', '_')}-apply",
                group=WORKSPACE_INLINE_WORKER_GROUP,
                exclusive=True,
            )

        async def _apply_inline_resource_selection(
            self,
            command_text: str,
            payload: AgentResourcePickerInput,
            selected_ids: list[str],
            apply_provider: ResourceApplyProvider,
        ) -> None:
            """Persist selected tools/MCPs and refresh workspace metadata."""
            try:
                updated_details = await asyncio.to_thread(apply_provider, selected_ids)
            except Exception as exc:  # pragma: no cover - defensive runtime guard
                self._finalize_inline_picker_failure(command_text, exc)
                return
            self._details = updated_details
            self._refresh_workspace_details_widgets()
            expected_ids = tuple(sorted(item for item in selected_ids if item))
            actual_ids = _resource_ids_for_command(command_text, updated_details)
            pending_summary = _summarize_pending_resource_names(payload, selected_ids)
            if actual_ids is not None and actual_ids != expected_ids:
                actual_summary = _resource_name_summary_for_command(command_text, updated_details)
                self._append_workspace_status(
                    f"{command_text} saved with refresh mismatch "
                    f"(requested {len(expected_ids)}: {pending_summary}; server {actual_summary})"
                )
            else:
                expected_count = len(selected_ids)
                actual_count = _resource_summary_count_for_command(command_text, updated_details)
                if actual_ids is None and actual_count is not None and actual_count != expected_count:
                    self._append_workspace_status(
                        f"{command_text} saved with refresh mismatch "
                        f"(requested {expected_count}: {pending_summary}; server {actual_count})"
                    )
                else:
                    self._append_workspace_status(
                        f"{command_text} saved ({expected_count} selected: {pending_summary})"
                    )
            self._inline_picker_running = False
            self._restore_composer_after_inline_flow()
            self._schedule_followup_capture()

        def _finalize_inline_picker_failure(self, command_text: str, exc: Exception) -> None:
            """Restore shell state after a picker load/apply failure."""
            self._inline_picker_running = False
            self._append_workspace_status(f"{command_text} failed: {exc}")
            self._restore_composer_after_inline_flow()
            self._schedule_followup_capture()

        def _refresh_workspace_details_widgets(self) -> None:
            """Refresh visible detail widgets after inline agent updates."""
            if self._mode != "agent":
                return
            try:
                self.query_one("#sidebar-header", Static).update(_format_sidebar_header(self._details))
                self.query_one(f"#{DETAILS_ID}", Static).update(_format_details(self._details))
                self.query_one(f"#{AGENT_CONTEXT_NAME_ID}", Static).update(_format_agent_context_name(self._details))
                self.query_one(f"#{AGENT_CONTEXT_ACCOUNT_ID}", Static).update(
                    _format_agent_context_account(self._details)
                )
            except Exception:  # pragma: no cover - defensive Textual query guard
                pass

        def _run_inline_message(self, message_text: str) -> None:
            """Execute agent message run while keeping users on workspace surface."""
            self._append_user_entry(message_text)
            self._append_transcript_line("")
            self._append_transcript_line("run: [~] running")
            self._inline_running_started_at = time.monotonic()
            self._inline_running_status_index = len(self._transcript_lines) - 1
            self._inline_streamed_status_lines = []
            self._inline_streamed_status_set = set()
            self._inline_streamed_status_counts = {}
            self._pending_inline_completion_line = None
            self._pending_inline_post_status_lines = []
            self._inline_stream_reply_index = None
            self._inline_stream_reply_text = ""

            composer = self.query_one(f"#{COMPOSER_ID}", Input)
            composer.value = ""
            composer.disabled = True

            loading = self.query_one(f"#{COMMAND_LOADING_ID}", Static)
            update_message = getattr(loading, "update_message", None)
            if callable(update_message):
                update_message(_PREFIX_RUNNING_TEXT)
            else:
                loading.update(_PREFIX_RUNNING_TEXT)
            loading.remove_class("-hidden")
            loading.add_class("-active")
            start = getattr(loading, "start", None)
            if callable(start):
                start()

            tip = self.query_one("#tip", Static)
            tip.add_class("-hidden")

            self._inline_message_running = True
            self.set_timer(INLINE_RUNNING_TICK_SECONDS, self._tick_inline_running_status)
            self.run_worker(
                self._run_inline_message_task(message_text),
                name="workspace-inline-message",
                group=WORKSPACE_INLINE_WORKER_GROUP,
                exclusive=True,
            )

        def _tick_inline_running_status(self) -> None:
            """Update elapsed running time while inline message execution is active."""
            if not self._inline_message_running:
                return

            started_at = self._inline_running_started_at
            if started_at is not None:
                elapsed_seconds = max(1, int(time.monotonic() - started_at))
                elapsed_label = f"{_PREFIX_RUNNING_TEXT} {elapsed_seconds}s"
                try:
                    loading = self.query_one(f"#{COMMAND_LOADING_ID}", Static)
                except Exception:  # pragma: no cover - defensive UI lifecycle guard
                    loading = None
                if loading is not None:
                    update_message = getattr(loading, "update_message", None)
                    if callable(update_message):
                        update_message(elapsed_label)
                    else:
                        loading.update(elapsed_label)

            if self._inline_message_running:
                self.set_timer(INLINE_RUNNING_TICK_SECONDS, self._tick_inline_running_status)

        async def _run_inline_message_task(self, message_text: str) -> None:
            """Run inline message provider in a Textual worker."""
            try:
                reply, status_lines = await asyncio.to_thread(self._run_inline_message_provider, message_text)
                self._finalize_inline_message(reply, status_lines)
            except Exception as exc:  # pragma: no cover - defensive runtime guard
                self._finalize_inline_message(None, [f"{_RUN_FAILED_PREFIX} {exc}"])

        def _run_inline_message_provider(self, message_text: str) -> tuple[str | None, list[str]]:
            """Execute message provider and normalize reply/status lines."""
            provider = self._message_run_provider
            if provider is None:
                return None, []

            if self._provider_accepts_stream_callbacks(provider):
                result = provider(
                    message_text,
                    **{
                        _STREAM_STATUS_CALLBACK_ARG: self._on_stream_status_line,
                        _STREAM_REPLY_CALLBACK_ARG: self._on_stream_reply_chunk,
                    },
                )
            else:
                result = provider(message_text)
            return self._parse_message_run_result(result)

        @staticmethod
        def _parse_message_run_result(result: str | tuple[str, list[str]] | None) -> tuple[str | None, list[str]]:
            """Normalize message provider return shape."""
            if result is None:
                return None, []
            if isinstance(result, tuple) and len(result) == 2:
                reply, status_lines = result
                return str(reply or "").strip() or None, [str(line) for line in status_lines if str(line).strip()]
            return str(result or "").strip() or None, []

        @staticmethod
        def _provider_accepts_stream_callbacks(provider: MessageRunProvider) -> bool:
            """Return True when provider supports stream callback keyword arguments."""
            try:
                params = inspect.signature(provider).parameters.values()
            except (TypeError, ValueError):
                return False

            names: set[str] = set()
            for parameter in params:
                if parameter.kind == inspect.Parameter.VAR_KEYWORD:
                    return True
                names.add(parameter.name)

            return {
                _STREAM_STATUS_CALLBACK_ARG,
                _STREAM_REPLY_CALLBACK_ARG,
            }.issubset(names)

        def _dispatch_inline_stream_callback(self, callback: Callable[..., None], *args: Any) -> None:
            """Dispatch stream updates from worker thread into the Textual app thread."""
            call_from_thread = getattr(self, "call_from_thread", None)
            if callable(call_from_thread):
                try:
                    call_from_thread(callback, *args)
                    return
                except Exception:
                    pass
            callback(*args)

        def _on_stream_status_line(self, line: str) -> None:
            """Queue one streamed status row from provider emissions."""
            self._dispatch_inline_stream_callback(self._append_stream_status_line, line)

        def _on_stream_reply_chunk(self, chunk: str) -> None:
            """Queue one streamed reply chunk from provider emissions."""
            self._dispatch_inline_stream_callback(self._append_stream_reply_chunk, chunk)

        def _append_stream_status_line(self, line: str) -> None:
            """Append one streamed status line while deduplicating noisy repeats."""
            cleaned = str(line or "").strip()
            if not cleaned:
                return

            normalized_completion = self._normalize_inline_completion_line(cleaned)
            if normalized_completion is not None:
                self._pending_inline_completion_line = normalized_completion
                return
            if AgentWorkspaceShellApp._is_post_response_status_line(cleaned):
                if cleaned not in self._pending_inline_post_status_lines:
                    self._pending_inline_post_status_lines.append(cleaned)
                return
            if self._is_noisy_inline_status_line(cleaned):
                return
            if self._is_failure_status_line(cleaned):
                return
            if cleaned in self._inline_streamed_status_set and not self._is_repeatable_inline_status_line(cleaned):
                return

            self._inline_streamed_status_set.add(cleaned)
            self._inline_streamed_status_lines.append(cleaned)
            self._inline_streamed_status_counts[cleaned] = self._inline_streamed_status_counts.get(cleaned, 0) + 1
            reply_index = self._inline_stream_reply_index
            insert_at = reply_index
            if reply_index is not None and reply_index > 0 and not str(self._transcript_lines[reply_index - 1]).strip():
                insert_at = reply_index - 1
            spacer_lines = self._append_stream_event_spacer(cleaned, insert_at=insert_at)

            if reply_index is None or insert_at is None:
                self._append_transcript_line(cleaned)
                return

            self._insert_transcript_line(insert_at + spacer_lines, cleaned)
            self._inline_stream_reply_index = reply_index + spacer_lines + 1

        def _append_stream_event_spacer(self, status_line: str, *, insert_at: int | None = None) -> int:
            """Insert one blank line between event groups while keeping blocks compact."""
            if not self._is_stream_event_boundary(status_line):
                return 0

            if insert_at is None:
                if not self._transcript_lines or not str(self._transcript_lines[-1]).strip():
                    return 0
            else:
                insert_at = max(0, min(insert_at, len(self._transcript_lines)))
                if insert_at > 0 and not str(self._transcript_lines[insert_at - 1]).strip():
                    return 0

            previous = self._latest_nonempty_transcript_line(before_index=insert_at)
            if previous is None:
                return 0

            if self._is_stream_event_boundary(previous) or previous.lower().startswith(
                (
                    _PREFIX_TOOL_PARAMS,
                    _PREFIX_TOOL_DONE,
                    _PREFIX_TOOL_RESULT,
                    f"{_PREFIX_RUN} {_PREFIX_RUNNING}",
                    f"status: {_PREFIX_RUNNING}",
                )
            ):
                if insert_at is None:
                    self._append_transcript_line("")
                else:
                    self._insert_transcript_line(insert_at, "")
                return 1

            return 0

        @staticmethod
        def _is_repeatable_inline_status_line(status_line: str) -> bool:
            """Return True for streamed status rows that may repeat across retries."""
            lowered = str(status_line or "").strip().lower()
            return lowered.startswith((_PREFIX_TOOL_CALL, _PREFIX_TOOL_PARAMS, _PREFIX_TOOL_RESULT, _PREFIX_HANDOFF))

        def _latest_nonempty_transcript_line(self, *, before_index: int | None = None) -> str | None:
            """Return the latest non-empty transcript line, if any."""
            if before_index is None:
                candidates = self._transcript_lines
            else:
                before_index = max(0, min(before_index, len(self._transcript_lines)))
                candidates = self._transcript_lines[:before_index]

            for raw in reversed(candidates):
                cleaned = str(raw or "").strip()
                if cleaned:
                    return cleaned
            return None

        @staticmethod
        def _is_stream_event_boundary(line: str) -> bool:
            """Return True when streamed status line starts a new visual event block."""
            lowered = str(line or "").strip().lower()
            return lowered.startswith(
                (_PREFIX_TOOL_CALL, _PREFIX_HANDOFF, _PREFIX_SUBAGENT, _PREFIX_REASONING, _PREFIX_ACTION)
            )

        def _append_stream_reply_chunk(self, chunk: str) -> None:
            """Append streamed reply text in-place inside a single Agent row."""
            text = str(chunk or "")
            if not text:
                return

            if self._inline_stream_reply_index is None:
                if self._transcript_lines and str(self._transcript_lines[-1]).strip():
                    self._append_transcript_line("")
                self._append_transcript_line("Agent Final: ")
                self._inline_stream_reply_index = len(self._transcript_lines) - 1

            self._inline_stream_reply_text += text
            self._replace_transcript_line(
                self._inline_stream_reply_index,
                f"Agent Final: {self._inline_stream_reply_text}",
            )

        def _replace_transcript_line(self, index: int | None, value: str) -> None:
            """Replace one transcript row in place and refresh the rendered widget."""
            if index is None:
                return
            if index < 0 or index >= len(self._transcript_lines):
                return
            self._transcript_lines[index] = value

            transcript_sink = self._transcript_sink
            if callable(transcript_sink):
                transcript_sink(list(self._transcript_lines))

            self._refresh_transcript_widget()
            self._refresh_chrome_visibility()

        def _insert_transcript_line(self, index: int, value: str) -> None:
            """Insert one transcript row at a specific index and refresh widgets."""
            insert_at = max(0, min(index, len(self._transcript_lines)))
            self._transcript_lines.insert(insert_at, value)

            transcript_sink = self._transcript_sink
            if callable(transcript_sink):
                transcript_sink(list(self._transcript_lines))

            self._refresh_transcript_widget()
            self._refresh_chrome_visibility()

        def _finalize_inline_message(self, reply: str | None, status_lines: list[str]) -> None:
            """Restore workspace controls and append final agent run summary lines."""
            failure_line = self._derive_inline_failure_status(reply, status_lines)

            completion_line, detail_lines, post_status_lines = self._split_inline_status_lines(
                status_lines,
                failure_line=failure_line,
            )
            if completion_line is None:
                completion_line = self._pending_inline_completion_line
            merged_post_status_lines = list(self._pending_inline_post_status_lines)
            merged_post_status_lines.extend(post_status_lines)
            token_usage_line, remaining_post_status_lines = self._split_token_usage_from_post_status(
                merged_post_status_lines
            )

            self._append_inline_message_detail_lines(detail_lines)
            self._finalize_inline_stream_reply_line(reply, failure_line=failure_line)
            self._append_inline_completion_line(
                completion_line,
                failure_line=failure_line,
                token_usage_line=token_usage_line,
            )
            self._append_inline_post_status_lines(remaining_post_status_lines)

            self._inline_streamed_status_lines = []
            self._inline_streamed_status_set = set()
            self._inline_streamed_status_counts = {}
            self._pending_inline_completion_line = None
            self._pending_inline_post_status_lines = []
            self._inline_stream_reply_index = None
            self._inline_stream_reply_text = ""
            self._inline_running_started_at = None
            self._inline_running_status_index = None
            self._inline_message_running = False
            self._finalize_inline_status()

        def _append_inline_message_detail_lines(self, detail_lines: list[str]) -> None:
            """Append post-run detail lines while avoiding duplicate streamed rows."""
            if self._inline_streamed_status_lines:
                for detail_line in detail_lines:
                    if self._consume_streamed_status_occurrence(detail_line):
                        continue
                    self._append_transcript_line(detail_line)
                return

            rendered_details = self._format_inline_detail_lines(detail_lines)
            for detail_line in rendered_details:
                self._append_transcript_line(detail_line)

        def _append_inline_completion_line(
            self,
            completion_line: str | None,
            *,
            failure_line: str | None = None,
            token_usage_line: str | None = None,
        ) -> None:
            """Append one terminal Status row when run completion info is available."""
            if completion_line and completion_line in self._inline_streamed_status_set:
                return

            status_body: str | None = None
            if failure_line:
                normalized_failure = AgentWorkspaceShellApp._normalize_failure_status_line(failure_line)
                status_body = f"[x] {normalized_failure}"
            elif completion_line:
                status_body = _render_status_body(completion_line)

            normalized_usage = AgentWorkspaceShellApp._normalize_token_usage_status_line(token_usage_line or "")
            if status_body is None and not normalized_usage:
                return

            if normalized_usage:
                if status_body is None:
                    status_body = normalized_usage
                else:
                    status_body = f"{status_body} | {normalized_usage}"

            line = f"Status: {status_body}"
            if self._transcript_lines and str(self._transcript_lines[-1]).strip() == line:
                return

            self._append_transcript_line(line)

        @staticmethod
        def _split_token_usage_from_post_status(status_lines: list[str]) -> tuple[str | None, list[str]]:
            """Extract first token-usage footer and return remaining post-status rows."""
            seen: set[str] = set()
            token_usage_line: str | None = None
            remaining: list[str] = []
            for raw_line in status_lines:
                cleaned = AgentWorkspaceShellApp._prepare_post_status_line(raw_line, seen=seen)
                if cleaned is None:
                    continue
                normalized_usage = AgentWorkspaceShellApp._normalize_token_usage_status_line(cleaned)
                if normalized_usage is not None:
                    if token_usage_line is None:
                        token_usage_line = normalized_usage
                    continue
                remaining.append(cleaned)
            return token_usage_line, remaining

        @staticmethod
        def _normalize_token_usage_status_line(status_line: str) -> str | None:
            """Normalize token-usage status rows while tolerating legacy prefixes."""
            cleaned = str(status_line or "").strip()
            if not cleaned:
                return None
            lowered = cleaned.lower()
            if lowered.startswith(_PREFIX_STATUS):
                body = cleaned.split(":", 1)[1].strip()
                return AgentWorkspaceShellApp._normalize_token_usage_status_line(body)
            if lowered.startswith(_PREFIX_TOKEN_USAGE):
                return cleaned
            return None

        def _append_inline_post_status_lines(self, status_lines: list[str]) -> None:
            """Append post-response status footer rows while preserving order."""
            seen: set[str] = set()
            for raw_line in status_lines:
                cleaned = self._prepare_post_status_line(raw_line, seen=seen)
                if cleaned is None:
                    continue

                if self._consume_streamed_status_occurrence(cleaned):
                    continue

                line = self._canonical_post_status_line(cleaned)
                if self._transcript_ends_with_line(line):
                    continue
                self._append_transcript_line(line)

        @staticmethod
        def _prepare_post_status_line(raw_line: str, *, seen: set[str]) -> str | None:
            """Normalize one post-status candidate and dedupe by first-seen order."""
            cleaned = str(raw_line or "").strip()
            if not cleaned or cleaned in seen:
                return None
            seen.add(cleaned)
            return cleaned

        @staticmethod
        def _canonical_post_status_line(cleaned: str) -> str:
            """Render one post-status footer line without legacy `Status:` labels."""
            if cleaned.lower().startswith(_PREFIX_STATUS):
                body = cleaned.split(":", 1)[1].strip()
                return f"{_PREFIX_STATUS} {body}" if body else _PREFIX_STATUS
            lowered = cleaned.lower()
            if lowered.startswith(
                (
                    _PREFIX_STATUS,
                    _PREFIX_RUN,
                    _PREFIX_RUN_RESULT,
                    "tool_",
                    _PREFIX_TOOL,
                    _PREFIX_HANDOFF,
                    _PREFIX_REASONING,
                )
            ):
                return cleaned
            return f"status: {cleaned}"

        def _transcript_ends_with_line(self, line: str) -> bool:
            """Return True when transcript tail already matches `line`."""
            return bool(self._transcript_lines and str(self._transcript_lines[-1]).strip() == line)

        def _consume_streamed_status_occurrence(self, line: str) -> bool:
            """Return True and decrement count when line already arrived via streaming."""
            cleaned = str(line or "").strip()
            if not cleaned:
                return False
            count = self._inline_streamed_status_counts.get(cleaned, 0)
            if count <= 0:
                return False
            if count == 1:
                self._inline_streamed_status_counts.pop(cleaned, None)
            else:
                self._inline_streamed_status_counts[cleaned] = count - 1
            return True

        def _finalize_inline_stream_reply_line(self, reply: str | None, *, failure_line: str | None) -> None:
            """Finalize the AGENT row using streamed chunks or terminal reply text."""
            if self._inline_stream_reply_index is None:
                self._append_inline_reply_line(reply, failure_line=failure_line)
                return

            final_reply = str(reply or self._inline_stream_reply_text).strip()
            if final_reply:
                self._replace_transcript_line(self._inline_stream_reply_index, f"Agent Final: {final_reply}")
                return
            if failure_line is None:
                self._replace_transcript_line(self._inline_stream_reply_index, "Agent: Run finished.")

        def _split_inline_status_lines(
            self,
            status_lines: list[str],
            *,
            failure_line: str | None,
        ) -> tuple[str | None, list[str], list[str]]:
            """Return completion label, detail rows, and post-response status footer rows."""
            completion_line: str | None = None
            detail_lines: list[str] = []
            post_status_lines: list[str] = []

            for raw_line in status_lines:
                cleaned = str(raw_line).strip()
                if not cleaned:
                    continue

                if self._is_noisy_inline_status_line(cleaned):
                    continue

                if AgentWorkspaceShellApp._is_post_response_status_line(cleaned):
                    post_status_lines.append(cleaned)
                    continue

                norm_completion = self._normalize_inline_completion_line(cleaned)
                if norm_completion is not None:
                    completion_line = norm_completion
                    continue

                if failure_line is not None and self._is_failure_status_line(cleaned):
                    continue
                detail_lines.append(cleaned)

            return completion_line, detail_lines, post_status_lines

        @staticmethod
        def _format_inline_detail_lines(detail_lines: list[str]) -> list[str]:
            """Group tool lifecycle rows into compact blocks with clear boundaries."""
            entries = AgentWorkspaceShellApp._parse_inline_detail_entries(detail_lines)
            rendered = AgentWorkspaceShellApp._render_inline_detail_entries(entries)
            while rendered and not rendered[-1].strip():
                rendered.pop()
            return rendered

        @staticmethod
        def _parse_inline_detail_entries(detail_lines: list[str]) -> list[str | dict[str, Any]]:
            """Parse inline detail rows into rendered text rows and structured blocks."""
            entries: list[str | dict[str, Any]] = []
            tool_blocks: list[dict[str, Any]] = []
            open_by_name: dict[str, list[dict[str, Any]]] = {}
            for raw_line in detail_lines:
                line = str(raw_line or "").strip()
                if not line:
                    continue
                AgentWorkspaceShellApp._consume_inline_detail_line(
                    line,
                    entries=entries,
                    tool_blocks=tool_blocks,
                    open_by_name=open_by_name,
                )
            return entries

        @staticmethod
        def _consume_inline_detail_line(
            line: str,
            *,
            entries: list[str | dict[str, Any]],
            tool_blocks: list[dict[str, Any]],
            open_by_name: dict[str, list[dict[str, Any]]],
        ) -> None:
            """Consume one inline detail row into block entries."""
            lowered = line.lower()
            handlers: tuple[tuple[str, Callable[..., None]], ...] = (
                (_PREFIX_TOOL_CALL, AgentWorkspaceShellApp._consume_tool_call_line),
                (_PREFIX_TOOL_PARAMS, AgentWorkspaceShellApp._consume_tool_params_line),
                (_PREFIX_TOOL_RESULT, AgentWorkspaceShellApp._consume_tool_result_line),
                (_PREFIX_HANDOFF, AgentWorkspaceShellApp._consume_handoff_line),
            )
            for prefix, handler in handlers:
                if lowered.startswith(prefix):
                    handler(line, entries=entries, tool_blocks=tool_blocks, open_by_name=open_by_name)
                    return
            entries.append(line)

        @staticmethod
        def _consume_tool_call_line(
            line: str,
            *,
            entries: list[str | dict[str, Any]],
            tool_blocks: list[dict[str, Any]],
            open_by_name: dict[str, list[dict[str, Any]]],
        ) -> None:
            """Start a tool lifecycle block from a tool_call row."""
            tool_name = line.split(":", 1)[1].strip() or "tool"
            block: dict[str, Any] = {
                "kind": "tool",
                "name": tool_name,
                "params": [],
                "completion": None,
            }
            tool_blocks.append(block)
            entries.append(block)
            key = AgentWorkspaceShellApp._normalize_tool_name(tool_name)
            open_by_name.setdefault(key, []).append(block)

        @staticmethod
        def _consume_tool_params_line(
            line: str,
            *,
            entries: list[str | dict[str, Any]],
            tool_blocks: list[dict[str, Any]],
            open_by_name: dict[str, list[dict[str, Any]]],
        ) -> None:
            """Attach params rows to the latest open tool block when available."""
            del open_by_name
            params_value = line.split(":", 1)[1].strip()
            block = AgentWorkspaceShellApp._latest_open_tool_block(tool_blocks)
            if block is not None and params_value:
                block["params"].append(params_value)
                return
            entries.append(line)

        @staticmethod
        def _consume_tool_result_line(
            line: str,
            *,
            entries: list[str | dict[str, Any]],
            tool_blocks: list[dict[str, Any]],
            open_by_name: dict[str, list[dict[str, Any]]],
        ) -> None:
            """Attach tool_result rows to matching tool_call blocks."""
            tool_name, outcome = AgentWorkspaceShellApp._parse_tool_result_line(line)
            block = AgentWorkspaceShellApp._pop_open_tool_block(open_by_name, tool_blocks, tool_name)
            if block is None:
                entries.append(f"tool_done: {outcome or 'finished'}")
                return
            block["completion"] = outcome or "finished"

        @staticmethod
        def _consume_handoff_line(
            line: str,
            *,
            entries: list[str | dict[str, Any]],
            tool_blocks: list[dict[str, Any]],
            open_by_name: dict[str, list[dict[str, Any]]],
        ) -> None:
            """Append handoff rows as explicit sub-agent entries."""
            del tool_blocks, open_by_name
            handoff = line.split(":", 1)[1].strip() or "sub-agent"
            entries.append({"kind": "subagent", "title": handoff})

        @staticmethod
        def _render_inline_detail_entries(entries: list[str | dict[str, Any]]) -> list[str]:
            """Render parsed inline detail entries into transcript lines."""
            rendered: list[str] = []
            for entry in entries:
                chunk: list[str] = []
                if isinstance(entry, str):
                    line = entry.strip()
                    if line:
                        chunk.append(line)
                else:
                    AgentWorkspaceShellApp._append_rendered_inline_detail_block(entry, chunk)

                if not chunk:
                    continue

                if rendered and rendered[-1].strip():
                    rendered.append("")
                rendered.extend(chunk)
            return rendered

        @staticmethod
        def _append_rendered_inline_detail_block(block: dict[str, Any], rendered: list[str]) -> None:
            """Render one structured inline detail block."""
            kind = str(block.get("kind") or "")
            if kind == "subagent":
                rendered.append(f"subagent: {str(block.get('title') or '').strip()}")
                return

            completion = str(block.get("completion") or "").strip()
            if not completion:
                return

            rendered.append(f"tool: {block['name']}")
            for params_line in block.get("params", []):
                rendered.append(f"tool_params: {params_line}")
            rendered.append(f"tool_done: {completion}")

        @staticmethod
        def _normalize_tool_name(value: str) -> str:
            """Normalize tool names for call/result matching."""
            return " ".join(str(value or "").strip().lower().split())

        @staticmethod
        def _latest_open_tool_block(tool_blocks: list[dict[str, Any]]) -> dict[str, Any] | None:
            """Return the most recent tool block that has no completion yet."""
            for block in reversed(tool_blocks):
                if not block.get("completion"):
                    return block
            return None

        @staticmethod
        def _pop_open_tool_block(
            open_by_name: dict[str, list[dict[str, Any]]],
            tool_blocks: list[dict[str, Any]],
            tool_name: str,
        ) -> dict[str, Any] | None:
            """Pop the oldest open tool block for a matching tool name."""
            key = AgentWorkspaceShellApp._normalize_tool_name(tool_name)
            queue = open_by_name.get(key) or []
            if queue:
                block = queue.pop(0)
                if not queue:
                    open_by_name.pop(key, None)
                return block
            return AgentWorkspaceShellApp._latest_open_tool_block(tool_blocks)

        @staticmethod
        def _parse_tool_result_line(line: str) -> tuple[str, str | None]:
            """Parse tool_result rows into tool-name and normalized completion text."""
            detail = line.split(":", 1)[1].strip() if ":" in line else line.strip()
            if not detail:
                return "tool", "finished"

            tool_name = detail
            outcome: str | None = None
            if "|" in detail:
                left, right = detail.split("|", 1)
                tool_name = left.strip() or "tool"
                outcome = right.strip() or None

            lowered = (outcome or "").lower()
            if outcome is None:
                if "failed" in detail.lower():
                    outcome = "failed"
                else:
                    outcome = "finished"
            elif lowered.startswith("ok "):
                outcome = outcome[3:].strip()
            elif lowered in {"running", "in_progress"}:
                outcome = "finished"

            return tool_name, outcome

        def on_worker_state_changed(self, event: Worker.StateChanged) -> None:
            """Track worker lifecycle for debugging and error handling."""
            worker = event.worker
            state = event.state
            if state == WorkerState.ERROR:
                self.log.error(f"Worker {worker.name} failed: {worker.error}")
            elif state == WorkerState.CANCELLED:
                self.log.warning(f"Worker {worker.name} was cancelled")
            elif state == WorkerState.SUCCESS:
                self.log.info(f"Worker {worker.name} completed successfully")

        def _append_inline_reply_line(self, reply: str | None, *, failure_line: str | None) -> None:
            """Append terminal reply line after status rows are rendered."""
            if reply:
                if self._transcript_lines and str(self._transcript_lines[-1]).strip():
                    self._append_transcript_line("")
                self._append_transcript_line(f"Agent Final: {reply}")
                return
            if failure_line is None:
                if self._transcript_lines and str(self._transcript_lines[-1]).strip():
                    self._append_transcript_line("")
                self._append_transcript_line("Agent: Run finished.")

        @staticmethod
        def _is_noisy_inline_status_line(status_line: str) -> bool:
            """Return True for noisy run-id rows that add little user value."""
            lowered = status_line.lower().strip()
            return bool(re.match(r"^run\s+[a-z0-9_-]+\s+(completed|finished|done)$", lowered))

        @staticmethod
        def _normalize_inline_completion_line(status_line: str) -> str | None:
            """Map duration/completion metadata rows into one canonical completion label."""
            lowered = status_line.lower().strip()
            if lowered.startswith(_PREFIX_RUN_RESULT):
                body = status_line.split(":", 1)[1].strip()
                return AgentWorkspaceShellApp._normalize_inline_completion_line(body)
            if lowered.startswith("run result "):
                body = status_line[len("run result ") :].strip()
                return AgentWorkspaceShellApp._normalize_inline_completion_line(body)
            if lowered.startswith(_PREFIX_STATUS):
                body = status_line.split(":", 1)[1].strip()
                normalized = AgentWorkspaceShellApp._normalize_inline_completion_line(body)
                if normalized is not None:
                    return normalized
            if lowered.startswith(("[ok] ", "[~] ", "[x] ")):
                body = status_line.split("]", 1)[1].strip() if "]" in status_line else ""
                normalized = AgentWorkspaceShellApp._normalize_inline_completion_line(body)
                if normalized is not None:
                    return normalized
            if lowered.startswith(_PREFIX_COMPLETED_IN):
                return status_line.strip()
            if lowered.startswith("duration:"):
                duration = status_line.split(":", 1)[1].strip()
                if duration:
                    return f"{_PREFIX_COMPLETED_IN}{duration}"
            return None

        @staticmethod
        def _is_post_response_status_line(status_line: str) -> bool:
            """Return True when status row should render in the post-response footer."""
            lowered = str(status_line or "").strip().lower()
            if lowered.startswith(_PREFIX_RUN_RESULT):
                return True
            return AgentWorkspaceShellApp._normalize_token_usage_status_line(status_line) is not None

        @staticmethod
        def _derive_inline_failure_status(reply: str | None, status_lines: list[str]) -> str | None:
            """Return a concise failure status row when inline run completed without a response."""
            text = (reply or "").strip()
            lowered = text.lower()

            if lowered.startswith(_RUN_FAILED_PREFIX):
                reason = text.split(":", 1)[1].strip() if ":" in text else ""
                return f"{_RUN_FAILED_PREFIX} {reason or 'unknown error'}"

            failure_detail = next(
                (line.strip() for line in status_lines if AgentWorkspaceShellApp._is_failure_status_line(line)),
                None,
            )
            if failure_detail is not None:
                return AgentWorkspaceShellApp._normalize_failure_status_line(failure_detail)

            if "no agent response received" in lowered or "no final response available" in lowered:
                return f"{_RUN_FAILED_PREFIX} no final response available"

            return None

        @staticmethod
        def _is_failure_status_line(status_line: str) -> bool:
            """Return True when a status line denotes a failed/aborted run."""
            lowered = status_line.lower().strip()
            return lowered.startswith(_RUN_FAILED_PREFIX) or lowered.startswith("error:") or lowered.startswith("abort")

        @staticmethod
        def _normalize_failure_status_line(status_line: str) -> str:
            """Convert a failure-like status row into canonical run-failed form."""
            cleaned = status_line.strip()
            lowered = cleaned.lower()

            if lowered.startswith(_RUN_FAILED_PREFIX):
                reason = cleaned.split(":", 1)[1].strip() if ":" in cleaned else ""
                return f"{_RUN_FAILED_PREFIX} {reason or 'unknown error'}"

            return f"{_RUN_FAILED_PREFIX} {cleaned}"

        def _reject_workspace_command(self, command_text: str) -> None:
            """Keep unsupported slash commands in-place with a concise inline hint."""
            self._append_command_entry(command_text)
            self._append_transcript_line(f"Status: {command_text} is not available here. Type /help to view commands.")
            composer = self.query_one(f"#{COMPOSER_ID}", Input)
            composer.value = ""
            composer.disabled = False
            composer.focus()

        def _queue_command_transition(self, command_text: str) -> None:
            """Show in-page pulse before leaving to execute slash command."""
            self._append_command_entry(command_text)
            self._append_transcript_line(f"Status: Opening {command_text}...")
            self._pending_command_event = AgentWorkspaceEvent(kind="command", value=command_text)

            composer = self.query_one(f"#{COMPOSER_ID}", Input)
            composer.disabled = True

            loading = self.query_one(f"#{COMMAND_LOADING_ID}", Static)
            update_message = getattr(loading, "update_message", None)
            if callable(update_message):
                update_message(f"Opening {command_text}...")
            else:
                loading.update(f"Opening {command_text}...")
            loading.remove_class("-hidden")
            loading.add_class("-active")
            start = getattr(loading, "start", None)
            if callable(start):
                start()

            tip = self.query_one("#tip", Static)
            tip.add_class("-hidden")

            self.set_timer(COMMAND_TRANSITION_DELAY_SECONDS, self._flush_pending_command)

        def _flush_pending_command(self) -> None:
            """Exit app with pending slash command event after pulse delay."""
            if self._pending_command_event is None:
                return
            event = self._pending_command_event
            self._pending_command_event = None
            self.exit(event)

        def _run_inline_status(self, command_text: str) -> None:
            """Execute /status and keep users on the current workspace surface."""
            self._inline_status_running = True
            composer = self.query_one(f"#{COMPOSER_ID}", Input)
            composer.disabled = True

            loading = self.query_one(f"#{COMMAND_LOADING_ID}", Static)
            update_message = getattr(loading, "update_message", None)
            if callable(update_message):
                update_message(f"Checking {command_text}...")
            else:
                loading.update(f"Checking {command_text}...")
            loading.remove_class("-hidden")
            loading.add_class("-active")
            start = getattr(loading, "start", None)
            if callable(start):
                start()

            tip = self.query_one("#tip", Static)
            tip.add_class("-hidden")

            self.run_worker(
                self._run_inline_status_task(command_text),
                name="workspace-inline-status",
                group=WORKSPACE_INLINE_WORKER_GROUP,
                exclusive=True,
            )

        async def _run_inline_status_task(self, command_text: str) -> None:
            """Run inline status provider in a worker thread."""
            try:
                lines = await asyncio.to_thread(self._run_inline_status_provider, command_text)
            except Exception as exc:  # pragma: no cover - defensive
                lines = [f"Status unavailable: {exc}"]
            self._complete_inline_status(command_text, lines)

        def _run_inline_status_provider(self, command_text: str) -> list[str]:
            """Collect status lines from the configured status provider."""
            provider = self._status_summary_provider
            return self._collect_inline_status_lines(provider, command_text)

        def _complete_inline_status(self, command_text: str, lines: list[str]) -> None:
            """Finish inline /status execution and refresh transcript content."""
            self._append_command_entry(command_text)
            if lines:
                for line in lines:
                    self._append_transcript_line(f"Status: [ok] {line}")
            else:
                self._append_transcript_line("Status: [x] unavailable")

            self._finalize_inline_status()

        @staticmethod
        def _collect_inline_status_lines(provider: StatusSummaryProvider | None, command_text: str) -> list[str]:
            """Collect inline status lines while preserving command arguments when supported."""
            if not callable(provider):
                return []

            if AgentWorkspaceShellApp._status_provider_accepts_args(provider):
                provider_with_args = cast(Callable[[list[str]], list[str]], provider)
                return list(provider_with_args(AgentWorkspaceShellApp._status_command_args(command_text)))

            provider_no_args = cast(Callable[[], list[str]], provider)
            return list(provider_no_args())

        @staticmethod
        def _status_provider_accepts_args(provider: StatusSummaryProvider) -> bool:
            """Return True when provider signature accepts one or more parameters."""
            try:
                return bool(inspect.signature(provider).parameters)
            except (TypeError, ValueError):
                return False

        @staticmethod
        def _status_command_args(command_text: str) -> list[str]:
            """Parse slash command text and return only argument tokens."""
            try:
                tokens = shlex.split(command_text)
            except ValueError:
                return []

            if len(tokens) <= 1:
                return []
            return list(tokens[1:])

        def _append_transcript_line(self, line: str) -> None:
            """Append one line and refresh transcript widget/state classes."""
            self._transcript_lines.append(line)
            if len(self._transcript_lines) > TRANSCRIPT_MAX_LINES:
                self._transcript_lines = self._transcript_lines[-TRANSCRIPT_MAX_LINES:]
            transcript_sink = self._transcript_sink
            if callable(transcript_sink):
                transcript_sink(list(self._transcript_lines))

            messages = self.query_one(f"#{TRANSCRIPT_ID}", Static)
            messages.update(_format_transcript(self._transcript_lines))
            messages.add_class("-has-turns")
            transcript_scroll = self.query_one(f"#{TRANSCRIPT_SCROLL_ID}")
            transcript_scroll.add_class("-has-turns")
            scroll_end = getattr(transcript_scroll, "scroll_end", None)
            if callable(scroll_end):
                scroll_end(animate=False)

            chat = self.query_one("#chat-column", Vertical)
            chat.add_class("-has-turns")

            wrapper = self.query_one("#center-wrapper", Container)
            wrapper.add_class("-has-turns")

            title_nodes = list(self.query(_PREFIX_TITLE))
            for node in title_nodes:
                node.remove()

            self._refresh_chrome_visibility()

        def _refresh_transcript_widget(self) -> None:
            """Refresh transcript rendering and keep focus on the latest entries."""
            try:
                messages = self.query_one(f"#{TRANSCRIPT_ID}", Static)
            except Exception:
                return
            messages.update(_format_transcript(self._transcript_lines))
            if self._transcript_lines:
                messages.add_class("-has-turns")
            else:
                messages.remove_class("-has-turns")
            transcript_scroll = self.query_one(f"#{TRANSCRIPT_SCROLL_ID}")
            if self._transcript_lines:
                transcript_scroll.add_class("-has-turns")
            else:
                transcript_scroll.remove_class("-has-turns")
            scroll_end = getattr(transcript_scroll, "scroll_end", None)
            if callable(scroll_end):
                scroll_end(animate=False)

        def _transcript_overflows_viewport(self) -> bool:
            """Return True when transcript lines likely exceed visible viewport."""
            if not self._transcript_lines:
                return False

            try:
                transcript_scroll = self.query_one(f"#{TRANSCRIPT_SCROLL_ID}")
                region_height = int(getattr(transcript_scroll.region, "height", 0) or 0)
                virtual_height = int(getattr(getattr(transcript_scroll, "virtual_size", None), "height", 0) or 0)
                if region_height <= 2 or virtual_height <= 0:
                    return len(self._transcript_lines) > 12
                return virtual_height > region_height
            except Exception:
                return len(self._transcript_lines) > 12

        def _refresh_context_visibility(self, *, has_turns: bool) -> None:
            """Refresh header context widgets based on mode and sidebar state."""
            if self._mode == "agent":
                self._set_context_hidden(
                    (AGENT_CONTEXT_NAME_ID, AGENT_CONTEXT_ACCOUNT_ID),
                    hidden=self._sidebar_visible,
                )
                return

            self._set_context_hidden((HOME_CONTEXT_BRAND_ID, HOME_CONTEXT_ACCOUNT_ID), hidden=not has_turns)

        def _set_context_hidden(self, ids: tuple[str, ...], *, hidden: bool) -> None:
            """Apply hidden state to the queried header context nodes."""
            for node_id in ids:
                for node in self.query(f"#{node_id}"):
                    if hidden:
                        node.add_class("-hidden")
                    else:
                        node.remove_class("-hidden")

        def _refresh_keybar_visibility(self, *, overflow: bool) -> None:
            """Refresh keybar contents based on transcript overflow state."""
            keybar_row = self.query_one(f"#{KEYBAR_ROW_ID}", Container)
            keybar_left = self.query_one(f"#{KEYBAR_LEFT_ID}", Static)
            keybar_right = self.query_one(f"#{KEYBAR_RIGHT_ID}", Static)
            keybar_row.remove_class("-hidden")
            keybar_left.update(self._keybar_left_text())
            keybar_right.update("[#c4cede]pgup/pgdn scroll[/]" if overflow else "")

        def _refresh_chrome_visibility(self) -> None:
            """Show tip/keybar only when contextually useful."""
            has_turns = bool(self._transcript_lines)
            tip = self.query_one("#tip", Static)
            if has_turns:
                tip.add_class("-hidden")
            else:
                tip.remove_class("-hidden")

            self._refresh_context_visibility(has_turns=has_turns)
            self._refresh_keybar_visibility(overflow=self._transcript_overflows_viewport())

            if self._is_slash_open():
                self._position_slash_menu()

        def _append_command_entry(self, command_text: str) -> None:
            """Append a command line with spacing separation from prior entries."""
            if self._transcript_lines and str(self._transcript_lines[-1]).strip():
                self._append_transcript_line("")
            self._append_transcript_line(f"Cmd: {command_text}")

        def _append_workspace_status(self, body: str) -> None:
            """Append one status line to the transcript."""
            self._append_transcript_line(f"Status: {body}")

        def _next_run_index(self) -> int:
            """Return the next user-run index based on transcript history."""
            run_count = sum(1 for line in self._transcript_lines if str(line).startswith("You:"))
            return run_count + 1

        def _append_user_entry(self, message_text: str) -> None:
            """Append a user message line with spacing separation from prior entries."""
            if self._transcript_lines and str(self._transcript_lines[-1]).strip():
                self._append_transcript_line("")
            self._append_transcript_line(f"{_RUN_DIVIDER_SENTINEL}Run {self._next_run_index()}")
            self._append_transcript_line(f"You: {message_text}")

        def _finalize_inline_status(self) -> None:
            """Restore workspace controls after inline /status completes."""
            loading = self.query_one(f"#{COMMAND_LOADING_ID}", Static)
            stop = getattr(loading, "stop", None)
            if callable(stop):
                stop()
            loading.remove_class("-active")
            loading.add_class("-hidden")

            composer = self.query_one(f"#{COMPOSER_ID}", Input)
            composer.value = ""
            composer.disabled = False
            composer.focus()

            self._inline_status_running = False
            self._refresh_chrome_visibility()
            self._schedule_followup_capture()

        def _schedule_followup_capture(self) -> None:
            """Re-capture screenshots after transcript updates when capture env is set."""
            self._schedule_screenshot_capture(allow_repeat=True)

        def _handle_palette_navigation(self, key: str) -> bool:
            """Handle keyboard scrolling/navigation when the palette is open."""
            if not self._is_palette_open() or not self._palette_filtered:
                return False
            if key not in {"up", "down", "pageup", "pagedown", "home", "end"}:
                return False

            total = len(self._palette_filtered)
            page_size = max(1, min(_MAX_VISIBLE_PALETTE_ROWS - 1, total))
            if key == "home":
                self._palette_selected_index = 0
            elif key == "end":
                self._palette_selected_index = total - 1
            elif key == "pageup":
                self._palette_selected_index = max(0, self._palette_selected_index - page_size)
            elif key == "pagedown":
                self._palette_selected_index = min(total - 1, self._palette_selected_index + page_size)
            else:
                step = -1 if key == "up" else 1
                self._palette_selected_index = (self._palette_selected_index + step) % total
            self.palette_selected_index = self._palette_selected_index
            query = self.query_one(f"#{PALETTE_SEARCH_ID}", TextInput).value
            self._refresh_palette_rows(query)
            return True

        def _handle_slash_navigation(self, key: str) -> bool:
            """Handle Up/Down slash-menu selection changes when the dropdown is open."""
            if not self._is_slash_open() or not self._slash_filtered:
                return False
            if key not in {"up", "down"}:
                return False

            step = -1 if key == "up" else 1
            self._slash_selected_index = (self._slash_selected_index + step) % len(self._slash_filtered)
            self._refresh_slash_rows()
            return True

        def on_key(self, event: Any) -> None:
            """Handle slash-menu navigation and shell-style composer history recall."""
            if self._escape_confirm_target is not None and event.key not in {"escape", "enter"}:
                self._clear_escape_confirmation()

            if self._handle_palette_navigation(event.key):
                event.stop()
                return

            if self._handle_slash_navigation(event.key):
                event.stop()
                return
            if self._is_slash_open():
                return

            if event.key in {"up", "down"} and self._composer_has_focus():
                if self._navigate_composer_history(event.key):
                    event.stop()

        def on_input_submitted(self, event: Any) -> None:
            """Submit workspace composer when Enter is pressed inside the input."""
            if event.input.id == PALETTE_SEARCH_ID:
                event.stop()
                self._activate_palette_selection()
                return

            if event.input.id != COMPOSER_ID:
                return
            event.stop()
            self.action_submit_composer()

        def on_input_changed(self, event: Any) -> None:
            """Refresh slash suggestions as the composer value changes."""
            if event.input.id == PALETTE_SEARCH_ID:
                self._refresh_palette_results(event.value)
                return

            if event.input.id != COMPOSER_ID:
                return
            self._clear_escape_confirmation()
            self._refresh_slash_menu(event.value)

        def on_text_area_changed(self, event: Any) -> None:
            """Refresh slash suggestions as the composer value changes."""
            if (event.text_area.id or "") != COMPOSER_ID:
                return
            self._clear_escape_confirmation()
            self._refresh_slash_menu(event.text_area.text)

        def on_button_pressed(self, event: Button.Pressed) -> None:
            """Handle sidebar button presses."""
            if event.button.id == "view-details-btn":
                self._trigger_details_command()

        def _trigger_details_command(self) -> None:
            """Trigger the details command via the inline provider."""
            if self._details_provider is not None and callable(self._details_provider):
                self._run_inline_details(_DETAILS_COMMAND)
            else:
                # Fallback: set the composer text and submit
                composer = self.query_one(f"#{COMPOSER_ID}", Input)
                composer.value = _DETAILS_COMMAND
                self.action_submit_composer()

        def action_noop(self) -> None:
            """No-op action used to shadow disabled shortcuts."""

        def action_open_url_token(self, token: str) -> None:
            """Open a URL encoded into a click-safe token."""
            url = _decode_url_click_token(token)
            if url:
                self.open_url(url)

        def action_command_palette(self) -> None:
            """Open the TUI command palette."""
            if self._is_palette_open():
                self._close_palette()
                return
            self._open_palette()

        def run_palette_slash_command(self, command_text: str) -> None:
            """Execute a slash command selected from the command palette."""
            if (
                self._pending_command_event is not None
                or self._inline_status_running
                or self._inline_details_running
                or self._inline_message_running
                or self._inline_picker_running
            ):
                return

            self._remember_composer_history(command_text)
            self._reset_composer_history_navigation()
            self._handle_slash_submit(command_text)

        def action_transcript_hint(self) -> None:
            """Open transcript viewer route when available."""
            if (
                self._pending_command_event is not None
                or self._inline_status_running
                or self._inline_details_running
                or self._inline_message_running
                or self._inline_picker_running
            ):
                return

            command_meta = self._command_index.get(_TRANSCRIPTS_COMMAND)
            if command_meta is not None and command_meta.route == "transition":
                self._close_slash_menu()
                self._remember_composer_history(_TRANSCRIPTS_COMMAND)
                self._reset_composer_history_navigation()
                self._queue_command_transition(_TRANSCRIPTS_COMMAND)
                return

            tip = self.query_one("#tip", Static)
            tip.update("Transcript viewer is available via /transcripts.")
            tip.remove_class("-hidden")

        def action_copy_last_details(self) -> None:
            """Copy the last details output to clipboard."""
            if self._last_details_lines:
                # Remove sentinel markers and join lines
                clean_lines = []
                for line in self._last_details_lines:
                    clean = line.replace("\u0000DETAILS\u0000", "").strip()
                    if clean:
                        clean_lines.append(clean)
                text = "\n".join(clean_lines)
                self._copy_to_clipboard(text, label="Agent details")
            else:
                # Show hint that no details are available
                tip = self.query_one("#tip", Static)
                tip.update(f"Run {_DETAILS_COMMAND} first to copy agent configuration.")
                tip.remove_class("-hidden")


def run_agent_workspace_shell(
    *,
    details: AgentWorkspaceDetails,
    transcript_lines: list[str] | None,
    status_summary_provider: StatusSummaryProvider | None = None,
    details_provider: DetailsProvider | None = None,
    transcript_sink: TranscriptSink | None = None,
    message_run_provider: MessageRunProvider | None = None,
    picker_bindings: AgentWorkspacePickerBindings | None = None,
    mode: WorkspaceShellMode = "agent",
    page_chrome: PageChrome | None = None,
) -> AgentWorkspaceEvent | None:
    """Run workspace shell and return selected event.

    Returns None when Textual support is unavailable.
    """
    if not TEXTUAL_SUPPORTED:  # pragma: no cover - optional dependency
        return None

    if page_chrome is None:
        page_chrome = get_page_chrome(mode)

    app = AgentWorkspaceShellApp(
        details=details,
        transcript_lines=transcript_lines,
        composer_placeholder=page_chrome.placeholder,
        status_summary_provider=status_summary_provider,
        details_provider=details_provider,
        transcript_sink=transcript_sink,
        message_run_provider=message_run_provider,
        picker_bindings=picker_bindings,
        mode=mode,
        page_chrome=page_chrome,
    )
    return app.run()
