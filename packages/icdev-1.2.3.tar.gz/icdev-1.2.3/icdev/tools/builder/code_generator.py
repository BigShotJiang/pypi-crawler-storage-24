#!/usr/bin/env python3
# CUI // SP-CTI
"""Code Generator — generates implementation code from specifications.

Implements:
- generate_from_spec(project_path, spec, language) -> creates source files
- Generates modules in Python, Java, Go, TypeScript, Rust, and C#
- Applies CUI header in correct comment style per language
- Logs audit trail event (code_generated)
- CLI: python tools/builder/code_generator.py --project-path PATH --spec "REST API endpoint for users" --language python
"""

import argparse
import json
import re
import sqlite3
from pathlib import Path
from typing import Any, Dict, List, Optional
from icdev._paths import get_project_root

BASE_DIR = get_project_root()
DB_PATH = BASE_DIR / "data" / "icdev.db"


def _build_profile_context(project_id, task_type="code_generation"):
    """Build dev profile context for LLM prompt injection (Phase 34, D187).

    Calls inject_for_task() to extract relevant dimensions as markdown.
    Returns empty string if no profile exists (graceful fallback).
    """
    try:
        from icdev.tools.builder.dev_profile_manager import inject_for_task
        context = inject_for_task(project_id, task_type)
        return context or ""
    except (ImportError, Exception):
        return ""

CUI_HEADER = '''\
# CUI // SP-CTI
# Controlled by: Department of Defense
# CUI Category: CTI
# Distribution: D
# POC: ICDEV™ System Administrator
'''

CUI_HEADER_C_STYLE = '''\
// CUI // SP-CTI
// Controlled by: Department of Defense
// CUI Category: CTI
// Distribution: D
// POC: ICDEV™ System Administrator
'''

CUI_HEADERS = {
    "python": CUI_HEADER,
    "java": CUI_HEADER_C_STYLE,
    "go": CUI_HEADER_C_STYLE,
    "typescript": CUI_HEADER_C_STYLE,
    "rust": CUI_HEADER_C_STYLE,
    "csharp": CUI_HEADER_C_STYLE,
}


def _slugify(text: str) -> str:
    """Convert text to a Python-safe module name."""
    slug = re.sub(r"[^\w\s]", "", text.lower().strip())
    slug = re.sub(r"[\s-]+", "_", slug)
    slug = re.sub(r"_+", "_", slug).strip("_")
    return slug[:60]


def _detect_spec_type(spec: str) -> str:
    """Detect the type of code to generate from the spec text."""
    spec_lower = spec.lower()
    # Phase 19: Agentic spec types (check before generic types to avoid false matches)
    if any(kw in spec_lower for kw in ["agent skill", "a2a skill", "skill handler", "register_skill", "dispatch"]):
        return "agent_skill"
    elif any(kw in spec_lower for kw in ["llm service", "bedrock", "inference", "llm client"]):
        return "llm_service"
    elif any(kw in spec_lower for kw in ["prompt template", "hardprompt", "prompt manager"]):
        return "prompt_template"
    elif any(kw in spec_lower for kw in ["collaborate", "multi-agent", "handoff", "agent collaboration"]):
        return "agent_collaboration"
    elif any(kw in spec_lower for kw in ["model config", "agent card", "agent config"]):
        return "model_config"
    # Phase 26: MOSA interface spec types
    elif any(kw in spec_lower for kw in ["mosa interface", "interface contract", "icd interface",
                                          "open interface", "modular interface"]):
        return "mosa_interface"
    # Original spec types
    elif any(kw in spec_lower for kw in ["api", "endpoint", "rest", "route", "http"]):
        return "api"
    elif any(kw in spec_lower for kw in ["model", "schema", "table", "database", "orm"]):
        return "model"
    elif any(kw in spec_lower for kw in ["service", "business logic", "handler", "processor"]):
        return "service"
    elif any(kw in spec_lower for kw in ["cli", "command", "argparse", "command-line"]):
        return "cli"
    elif any(kw in spec_lower for kw in ["util", "helper", "utility", "common"]):
        return "utility"
    elif any(kw in spec_lower for kw in ["middleware", "decorator", "wrapper"]):
        return "middleware"
    elif any(kw in spec_lower for kw in ["config", "settings", "configuration"]):
        return "config"
    else:
        return "module"


def _extract_entity_name(spec: str) -> str:
    """Extract the primary entity/resource name from the spec."""
    spec_lower = spec.lower()
    # Try common patterns: "... for users", "... for orders", "User management"
    patterns = [
        r"for\s+(\w+)",
        r"(\w+)\s+management",
        r"(\w+)\s+service",
        r"(\w+)\s+api",
        r"(\w+)\s+endpoint",
        r"(\w+)\s+model",
        r"(\w+)\s+handler",
    ]
    for pattern in patterns:
        match = re.search(pattern, spec_lower)
        if match:
            name = match.group(1)
            # Skip generic words
            if name not in ("a", "an", "the", "rest", "api", "http", "new", "simple", "basic"):
                return name
    # Fallback: use slugified spec
    return _slugify(spec)[:20] or "module"


def _generate_api_code(entity: str, spec: str, secure: bool = True) -> str:
    """Generate a Flask/FastAPI API endpoint module.

    Args:
        entity: Resource name (e.g. "user", "contract").
        spec: Specification text.
        secure: Include auth decorators and input validation (D-EPSEC-5).
                Set to False only via --no-auth CLI flag.
    """
    class_name = entity.capitalize()

    # Auth decorator and validation helper — self-contained (no external import)
    auth_block = ""
    if secure:
        auth_block = '''
from functools import wraps


def require_auth(f):
    """Require authenticated user (NIST AC-3). Self-contained decorator."""
    @wraps(f)
    def decorated(*args, **kwargs):
        from flask import g
        user = getattr(g, "current_user", None)
        if not user:
            return jsonify({"error": "Authentication required"}), 401
        return f(*args, **kwargs)
    return decorated


def _validate_fields(data, required=None):
    """Validate input fields (NIST SI-10). Returns error message or None."""
    if not isinstance(data, dict):
        return "Request body must be a JSON object"
    if required:
        missing = [f for f in required if f not in data or data[f] is None]
        if missing:
            return f"Missing required fields: {', '.join(missing)}"
    return None

'''

    # Route decorators
    auth_dec = "\n    @require_auth" if secure else ""

    # Validation on write methods
    validate_create = ""
    validate_update = ""
    if secure:
        validate_create = '''
        err = _validate_fields(data)
        if err:
            return jsonify({{"error": err}}), 400'''
        validate_update = '''
        err = _validate_fields(data)
        if err:
            return jsonify({{"error": err}}), 400'''

    return f'''{CUI_HEADER}
"""API endpoints for {entity} resource.

Spec: {spec}
Generated by ICDEV™ Builder - code_generator.py
"""

import json
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

try:
    from flask import Blueprint, jsonify, request
except ImportError:
    Blueprint = None
{auth_block}

def create_blueprint() -> "Blueprint":
    """Create and return the {entity} API blueprint."""
    bp = Blueprint("{entity}", __name__, url_prefix="/api/{entity}")

    # In-memory store (replace with database in production)
    _store: Dict[str, dict] = {{}}

    @bp.route("", methods=["GET"]){auth_dec}
    def list_{entity}():
        """List all {entity} records.

        Returns:
            JSON array of {entity} records.
        """
        items = list(_store.values())
        return jsonify({{"data": items, "count": len(items)}})

    @bp.route("/<item_id>", methods=["GET"]){auth_dec}
    def get_{entity}(item_id: str):
        """Get a single {entity} by ID.

        Args:
            item_id: The unique identifier.

        Returns:
            JSON object of the {entity} record, or 404.
        """
        item = _store.get(item_id)
        if not item:
            return jsonify({{"error": f"{class_name} not found: {{item_id}}"}}), 404
        return jsonify(item)

    @bp.route("", methods=["POST"]){auth_dec}
    def create_{entity}():
        """Create a new {entity} record.

        Expects:
            JSON body with {entity} data.

        Returns:
            Created {entity} record with generated ID.
        """
        data = request.get_json(silent=True) or {{}}{validate_create}
        item_id = str(uuid.uuid4())
        record = {{
            "id": item_id,
            **data,
            "created_at": datetime.now(timezone.utc).isoformat() + "Z",
            "updated_at": datetime.now(timezone.utc).isoformat() + "Z",
        }}
        _store[item_id] = record
        return jsonify(record), 201

    @bp.route("/<item_id>", methods=["PUT"]){auth_dec}
    def update_{entity}(item_id: str):
        """Update an existing {entity} record.

        Args:
            item_id: The unique identifier.

        Returns:
            Updated {entity} record, or 404.
        """
        if item_id not in _store:
            return jsonify({{"error": f"{class_name} not found: {{item_id}}"}}), 404
        data = request.get_json(silent=True) or {{}}{validate_update}
        _store[item_id].update(data)
        _store[item_id]["updated_at"] = datetime.now(timezone.utc).isoformat() + "Z"
        return jsonify(_store[item_id])

    @bp.route("/<item_id>", methods=["DELETE"]){auth_dec}
    def delete_{entity}(item_id: str):
        """Delete a {entity} record.

        Args:
            item_id: The unique identifier.

        Returns:
            204 No Content on success, or 404.
        """
        if item_id not in _store:
            return jsonify({{"error": f"{class_name} not found: {{item_id}}"}}), 404
        del _store[item_id]
        return "", 204

    return bp


# Standalone usage
if __name__ == "__main__":
    try:
        from flask import Flask
        app = Flask(__name__)
        app.register_blueprint(create_blueprint())
        app.run(debug=os.environ.get("FLASK_DEBUG", "false").lower() == "true", port=5000)
    except ImportError:
        print("Flask is required. Install with: pip install flask")
'''


def _generate_model_code(entity: str, spec: str) -> str:
    """Generate a data model module."""
    class_name = entity.capitalize()
    return f'''{CUI_HEADER}
"""Data model for {entity}.

Spec: {spec}
Generated by ICDEV™ Builder - code_generator.py
"""

import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional


@dataclass
class {class_name}:
    """Represents a {entity} entity.

    Attributes:
        id: Unique identifier (UUID).
        name: Human-readable name.
        description: Optional description.
        status: Current status (active, inactive, archived).
        metadata: Additional key-value metadata.
        created_at: Creation timestamp (ISO 8601).
        updated_at: Last update timestamp (ISO 8601).
    """
    id: str = ""
    name: str = ""
    description: str = ""
    status: str = "active"
    metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: str = ""
    updated_at: str = ""

    def __post_init__(self) -> None:
        if not self.id:
            self.id = str(uuid.uuid4())
        now = datetime.now(timezone.utc).isoformat() + "Z"
        if not self.created_at:
            self.created_at = now
        if not self.updated_at:
            self.updated_at = now

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to dictionary."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "{class_name}":
        """Deserialize from dictionary."""
        return cls(
            id=data.get("id", ""),
            name=data.get("name", ""),
            description=data.get("description", ""),
            status=data.get("status", "active"),
            metadata=data.get("metadata", {{}}) ,
            created_at=data.get("created_at", ""),
            updated_at=data.get("updated_at", ""),
        )

    def validate(self) -> List[str]:
        """Validate the model. Returns list of validation errors."""
        errors = []
        if not self.name:
            errors.append("name is required")
        if self.status not in ("active", "inactive", "archived"):
            errors.append(f"invalid status: {{self.status}}")
        return errors


class {class_name}Repository:
    """Repository for {entity} CRUD operations.

    Uses SQLite for persistence. Replace with production database as needed.
    """

    def __init__(self, db_path: str) -> None:
        self.db_path = db_path

    def create(self, item: {class_name}) -> {class_name}:
        """Create a new {entity} record."""
        import sqlite3
        conn = sqlite3.connect(self.db_path)
        try:
            c = conn.cursor()
            c.execute(
                "INSERT INTO {entity} (id, name, description, status, metadata, created_at, updated_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                (item.id, item.name, item.description, item.status,
                 str(item.metadata), item.created_at, item.updated_at),
            )
            conn.commit()
        finally:
            conn.close()
        return item

    def get(self, item_id: str) -> Optional[{class_name}]:
        """Get a {entity} by ID."""
        import sqlite3
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            c = conn.cursor()
            c.execute("SELECT * FROM {entity} WHERE id = ?", (item_id,))
            row = c.fetchone()
            if row:
                return {class_name}.from_dict(dict(row))
            return None
        finally:
            conn.close()

    def list_all(self) -> List[{class_name}]:
        """List all {entity} records."""
        import sqlite3
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        try:
            c = conn.cursor()
            c.execute("SELECT * FROM {entity} ORDER BY created_at DESC")
            return [{class_name}.from_dict(dict(row)) for row in c.fetchall()]
        finally:
            conn.close()

    def delete(self, item_id: str) -> bool:
        """Delete a {entity} by ID."""
        import sqlite3
        conn = sqlite3.connect(self.db_path)
        try:
            c = conn.cursor()
            c.execute("DELETE FROM {entity} WHERE id = ?", (item_id,))
            conn.commit()
            return c.rowcount > 0
        finally:
            conn.close()
'''


def _generate_service_code(entity: str, spec: str) -> str:
    """Generate a service/business logic module."""
    class_name = entity.capitalize()
    return f'''{CUI_HEADER}
"""Service layer for {entity} business logic.

Spec: {spec}
Generated by ICDEV™ Builder - code_generator.py
"""

import logging
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class {class_name}Service:
    """Business logic for {entity} operations.

    Encapsulates validation, transformation, and coordination logic
    separate from HTTP handling and data access.
    """

    def __init__(self, repository: Any = None) -> None:
        """Initialize the service.

        Args:
            repository: Data access object for {entity} persistence.
        """
        self.repository = repository

    def create(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new {entity}.

        Args:
            data: Input data for the new {entity}.

        Returns:
            The created {entity} as a dict.

        Raises:
            ValueError: If validation fails.
        """
        errors = self._validate(data)
        if errors:
            raise ValueError(f"Validation failed: {{'; '.join(errors)}}")

        data["created_at"] = datetime.now(timezone.utc).isoformat() + "Z"
        data["updated_at"] = data["created_at"]

        if self.repository:
            result = self.repository.create(data)
            logger.info(f"{class_name} created: {{result.get('id', 'unknown')}}")
            return result
        return data

    def get(self, item_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve a {entity} by ID.

        Args:
            item_id: Unique identifier.

        Returns:
            The {entity} dict or None if not found.
        """
        if self.repository:
            return self.repository.get(item_id)
        return None

    def update(self, item_id: str, data: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Update an existing {entity}.

        Args:
            item_id: Unique identifier.
            data: Fields to update.

        Returns:
            Updated {entity} dict, or None if not found.
        """
        data["updated_at"] = datetime.now(timezone.utc).isoformat() + "Z"
        if self.repository:
            return self.repository.update(item_id, data)
        return data

    def delete(self, item_id: str) -> bool:
        """Delete a {entity}.

        Args:
            item_id: Unique identifier.

        Returns:
            True if deleted, False if not found.
        """
        if self.repository:
            return self.repository.delete(item_id)
        return False

    def list_all(self, filters: Optional[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """List {entity} records with optional filtering.

        Args:
            filters: Optional filter criteria.

        Returns:
            List of {entity} dicts.
        """
        if self.repository:
            return self.repository.list_all(filters)
        return []

    def _validate(self, data: Dict[str, Any]) -> List[str]:
        """Validate {entity} data.

        Args:
            data: Data to validate.

        Returns:
            List of validation error messages (empty if valid).
        """
        errors = []
        if not data.get("name"):
            errors.append("name is required")
        return errors
'''


def _generate_cli_code(entity: str, spec: str) -> str:
    """Generate a CLI tool module."""
    return f'''{CUI_HEADER}
"""CLI tool for {entity}.

Spec: {spec}
Generated by ICDEV™ Builder - code_generator.py
"""

import argparse
import json
import sys
from typing import Any, Dict


def handle_create(args: argparse.Namespace) -> None:
    """Handle the create command."""
    data = {{"name": args.name}}
    if args.description:
        data["description"] = args.description
    print(json.dumps({{"status": "created", "data": data}}, indent=2))


def handle_list(args: argparse.Namespace) -> None:
    """Handle the list command."""
    print(json.dumps({{"status": "ok", "data": [], "count": 0}}, indent=2))


def handle_get(args: argparse.Namespace) -> None:
    """Handle the get command."""
    print(json.dumps({{"status": "ok", "id": args.id}}, indent=2))


def handle_delete(args: argparse.Namespace) -> None:
    """Handle the delete command."""
    print(json.dumps({{"status": "deleted", "id": args.id}}, indent=2))


def main() -> None:
    """Entry point for the {entity} CLI."""
    parser = argparse.ArgumentParser(description="{entity} CLI tool")
    sub = parser.add_subparsers(dest="command", help="Available commands")

    # create
    p_create = sub.add_parser("create", help="Create a new {entity}")
    p_create.add_argument("--name", required=True, help="Name")
    p_create.add_argument("--description", help="Description")

    # list
    sub.add_parser("list", help="List all {entity} records")

    # get
    p_get = sub.add_parser("get", help="Get a {entity} by ID")
    p_get.add_argument("--id", required=True, help="ID")

    # delete
    p_del = sub.add_parser("delete", help="Delete a {entity}")
    p_del.add_argument("--id", required=True, help="ID")

    parser.add_argument("--json", action="store_true", dest="json_output", help="JSON output")
    args = parser.parse_args()

    if not args.command:
        parser.print_help()
        sys.exit(1)

    handlers = {{
        "create": handle_create,
        "list": handle_list,
        "get": handle_get,
        "delete": handle_delete,
    }}
    handlers[args.command](args)


if __name__ == "__main__":
    main()
'''


def _generate_module_code(entity: str, spec: str) -> str:
    """Generate a generic Python module."""
    class_name = entity.capitalize()
    return f'''{CUI_HEADER}
"""Module: {entity}

Spec: {spec}
Generated by ICDEV™ Builder - code_generator.py
"""

import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class {class_name}:
    """Main class for {entity} functionality.

    Provides core operations as defined by the specification.
    """

    def __init__(self, config: Optional[Dict[str, Any]] = None) -> None:
        """Initialize {class_name}.

        Args:
            config: Optional configuration dictionary.
        """
        self.config = config or {{}}
        logger.info(f"{class_name} initialized")

    def process(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Process input data and return results.

        Args:
            data: Input data to process.

        Returns:
            Processed result dictionary.
        """
        logger.info(f"Processing data: {{list(data.keys())}}")
        result = {{
            "status": "processed",
            "input_keys": list(data.keys()),
            "output": data,
        }}
        return result

    def validate(self, data: Dict[str, Any]) -> List[str]:
        """Validate input data.

        Args:
            data: Data to validate.

        Returns:
            List of validation error messages (empty if valid).
        """
        errors = []
        if not data:
            errors.append("data cannot be empty")
        return errors
'''


# ---------------------------------------------------------------------------
# Java code generators
# ---------------------------------------------------------------------------

def _generate_java_api_code(entity: str, spec: str, secure: bool = True) -> str:
    """Generate a Spring Boot REST controller (Java)."""
    class_name = entity.capitalize()
    auth_import = ""
    auth_ann = ""
    valid_ann = ""
    if secure:
        auth_import = "\nimport org.springframework.security.access.prepost.PreAuthorize;\nimport jakarta.validation.Valid;"
        auth_ann = '\n    @PreAuthorize("isAuthenticated()")'
        valid_ann = "@Valid "
    return f'''{CUI_HEADER_C_STYLE}
package com.icdev.api;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
{auth_import}
import java.util.*;

/**
 * REST API controller for {entity}.
 *
 * Spec: {spec}
 * Generated by ICDEV™ Builder - code_generator.py
 */
@RestController
@RequestMapping("/api/{entity}")
public class {class_name}Controller {{

    private final {class_name}Service service;

    public {class_name}Controller({class_name}Service service) {{
        this.service = service;
    }}

    @GetMapping{auth_ann}
    public ResponseEntity<List<Map<String, Object>>> list() {{
        List<Map<String, Object>> items = service.listAll();
        return ResponseEntity.ok(items);
    }}

    @GetMapping("/{{id}}"){auth_ann}
    public ResponseEntity<Map<String, Object>> get(@PathVariable String id) {{
        Map<String, Object> item = service.getById(id);
        if (item == null) {{
            return ResponseEntity.notFound().build();
        }}
        return ResponseEntity.ok(item);
    }}

    @PostMapping{auth_ann}
    public ResponseEntity<Map<String, Object>> create({valid_ann}@RequestBody Map<String, Object> data) {{
        Map<String, Object> created = service.create(data);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }}

    @PutMapping("/{{id}}"){auth_ann}
    public ResponseEntity<Map<String, Object>> update(@PathVariable String id, {valid_ann}@RequestBody Map<String, Object> data) {{
        Map<String, Object> updated = service.update(id, data);
        if (updated == null) {{
            return ResponseEntity.notFound().build();
        }}
        return ResponseEntity.ok(updated);
    }}

    @DeleteMapping("/{{id}}"){auth_ann}
    public ResponseEntity<Void> delete(@PathVariable String id) {{
        boolean deleted = service.delete(id);
        if (!deleted) {{
            return ResponseEntity.notFound().build();
        }}
        return ResponseEntity.noContent().build();
    }}
}}
'''


def _generate_java_model_code(entity: str, spec: str) -> str:
    """Generate a JPA entity model (Java)."""
    class_name = entity.capitalize()
    return f'''{CUI_HEADER_C_STYLE}
package com.icdev.model;

import jakarta.persistence.*;
import java.time.Instant;
import java.util.UUID;

/**
 * Data model for {entity}.
 *
 * Spec: {spec}
 * Generated by ICDEV™ Builder - code_generator.py
 */
@Entity
@Table(name = "{entity}")
public class {class_name} {{

    @Id
    private String id;

    @Column(nullable = false)
    private String name;

    private String description;

    @Column(nullable = false)
    private String status = "active";

    @Column(name = "created_at", nullable = false)
    private Instant createdAt;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    public {class_name}() {{
        this.id = UUID.randomUUID().toString();
        this.createdAt = Instant.now();
        this.updatedAt = Instant.now();
    }}

    public {class_name}(String name, String description) {{
        this();
        this.name = name;
        this.description = description;
    }}

    // Getters and setters
    public String getId() {{ return id; }}
    public void setId(String id) {{ this.id = id; }}

    public String getName() {{ return name; }}
    public void setName(String name) {{ this.name = name; }}

    public String getDescription() {{ return description; }}
    public void setDescription(String description) {{ this.description = description; }}

    public String getStatus() {{ return status; }}
    public void setStatus(String status) {{ this.status = status; }}

    public Instant getCreatedAt() {{ return createdAt; }}
    public void setCreatedAt(Instant createdAt) {{ this.createdAt = createdAt; }}

    public Instant getUpdatedAt() {{ return updatedAt; }}
    public void setUpdatedAt(Instant updatedAt) {{ this.updatedAt = updatedAt; }}

    @PreUpdate
    protected void onUpdate() {{
        this.updatedAt = Instant.now();
    }}
}}
'''


def _generate_java_service_code(entity: str, spec: str) -> str:
    """Generate a Spring service class (Java)."""
    class_name = entity.capitalize()
    return f'''{CUI_HEADER_C_STYLE}
package com.icdev.service;

import com.icdev.model.{class_name};
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.logging.Logger;

/**
 * Service layer for {entity} business logic.
 *
 * Spec: {spec}
 * Generated by ICDEV™ Builder - code_generator.py
 */
@Service
public class {class_name}Service {{

    private static final Logger logger = Logger.getLogger({class_name}Service.class.getName());
    private final Map<String, Map<String, Object>> store = new LinkedHashMap<>();

    public {class_name}Service() {{
        logger.info("{class_name}Service initialized");
    }}

    public Map<String, Object> create(Map<String, Object> data) {{
        String id = UUID.randomUUID().toString();
        data.put("id", id);
        data.put("created_at", java.time.Instant.now().toString());
        data.put("updated_at", java.time.Instant.now().toString());
        store.put(id, data);
        logger.info("{class_name} created: " + id);
        return data;
    }}

    public Map<String, Object> getById(String id) {{
        return store.get(id);
    }}

    public List<Map<String, Object>> listAll() {{
        return new ArrayList<>(store.values());
    }}

    public Map<String, Object> update(String id, Map<String, Object> data) {{
        if (!store.containsKey(id)) {{
            return null;
        }}
        store.get(id).putAll(data);
        store.get(id).put("updated_at", java.time.Instant.now().toString());
        return store.get(id);
    }}

    public boolean delete(String id) {{
        return store.remove(id) != null;
    }}
}}
'''


# ---------------------------------------------------------------------------
# Go code generators
# ---------------------------------------------------------------------------

def _generate_go_api_code(entity: str, spec: str, secure: bool = True) -> str:
    """Generate a net/http handler (Go)."""
    auth_check = ""
    if secure:
        auth_check = """
    // Auth middleware check (NIST AC-3)
    if !authMiddleware(w, r) {{
        return
    }}"""
    auth_func = ""
    if secure:
        auth_func = """
// authMiddleware verifies the request is authenticated (NIST AC-3).
// Replace with your actual auth mechanism.
func authMiddleware(w http.ResponseWriter, r *http.Request) bool {{
    token := r.Header.Get("Authorization")
    if token == "" {{
        http.Error(w, `{{"error":"authentication required"}}`, http.StatusUnauthorized)
        return false
    }}
    return true
}}
"""
    return f'''{CUI_HEADER_C_STYLE}
package api

// API handlers for {entity}.
//
// Spec: {spec}
// Generated by ICDEV™ Builder - code_generator.py

import (
    "encoding/json"
    "net/http"
    "strings"
    "sync"
)
{auth_func}
type {entity.capitalize()}Handler struct {{
    mu    sync.RWMutex
    store map[string]map[string]interface{{}}
}}

func New{entity.capitalize()}Handler() *{entity.capitalize()}Handler {{
    return &{entity.capitalize()}Handler{{
        store: make(map[string]map[string]interface{{}}),
    }}
}}

func (h *{entity.capitalize()}Handler) ServeHTTP(w http.ResponseWriter, r *http.Request) {{
    w.Header().Set("Content-Type", "application/json"){auth_check}
    switch r.Method {{
    case http.MethodGet:
        h.handleGet(w, r)
    case http.MethodPost:
        h.handlePost(w, r)
    case http.MethodPut:
        h.handlePut(w, r)
    case http.MethodDelete:
        h.handleDelete(w, r)
    default:
        http.Error(w, `{{"error":"method not allowed"}}`, http.StatusMethodNotAllowed)
    }}
}}

func (h *{entity.capitalize()}Handler) handleGet(w http.ResponseWriter, r *http.Request) {{
    id := strings.TrimPrefix(r.URL.Path, "/api/{entity}/")
    h.mu.RLock()
    defer h.mu.RUnlock()
    if id == "" || id == "/api/{entity}" {{
        items := make([]map[string]interface{{}}, 0, len(h.store))
        for _, v := range h.store {{
            items = append(items, v)
        }}
        json.NewEncoder(w).Encode(map[string]interface{{}}{{"data": items, "count": len(items)}})
        return
    }}
    item, ok := h.store[id]
    if !ok {{
        http.Error(w, `{{"error":"not found"}}`, http.StatusNotFound)
        return
    }}
    json.NewEncoder(w).Encode(item)
}}

func (h *{entity.capitalize()}Handler) handlePost(w http.ResponseWriter, r *http.Request) {{
    var data map[string]interface{{}}
    if err := json.NewDecoder(r.Body).Decode(&data); err != nil {{
        http.Error(w, `{{"error":"invalid json"}}`, http.StatusBadRequest)
        return
    }}
    h.mu.Lock()
    defer h.mu.Unlock()
    // TODO: Generate UUID for id
    data["id"] = "generated-id"
    h.store[data["id"].(string)] = data
    w.WriteHeader(http.StatusCreated)
    json.NewEncoder(w).Encode(data)
}}

func (h *{entity.capitalize()}Handler) handlePut(w http.ResponseWriter, r *http.Request) {{
    id := strings.TrimPrefix(r.URL.Path, "/api/{entity}/")
    h.mu.Lock()
    defer h.mu.Unlock()
    if _, ok := h.store[id]; !ok {{
        http.Error(w, `{{"error":"not found"}}`, http.StatusNotFound)
        return
    }}
    var data map[string]interface{{}}
    if err := json.NewDecoder(r.Body).Decode(&data); err != nil {{
        http.Error(w, `{{"error":"invalid json"}}`, http.StatusBadRequest)
        return
    }}
    for k, v := range data {{
        h.store[id][k] = v
    }}
    json.NewEncoder(w).Encode(h.store[id])
}}

func (h *{entity.capitalize()}Handler) handleDelete(w http.ResponseWriter, r *http.Request) {{
    id := strings.TrimPrefix(r.URL.Path, "/api/{entity}/")
    h.mu.Lock()
    defer h.mu.Unlock()
    if _, ok := h.store[id]; !ok {{
        http.Error(w, `{{"error":"not found"}}`, http.StatusNotFound)
        return
    }}
    delete(h.store, id)
    w.WriteHeader(http.StatusNoContent)
}}
'''


def _generate_go_model_code(entity: str, spec: str) -> str:
    """Generate a Go struct model with JSON tags."""
    class_name = entity.capitalize()
    return f'''{CUI_HEADER_C_STYLE}
package model

// {class_name} represents the {entity} data model.
//
// Spec: {spec}
// Generated by ICDEV™ Builder - code_generator.py

import (
    "encoding/json"
    "time"
)

type {class_name} struct {{
    ID          string                 `json:"id"`
    Name        string                 `json:"name"`
    Description string                 `json:"description,omitempty"`
    Status      string                 `json:"status"`
    Metadata    map[string]interface{{}} `json:"metadata,omitempty"`
    CreatedAt   time.Time              `json:"created_at"`
    UpdatedAt   time.Time              `json:"updated_at"`
}}

func New{class_name}(name, description string) *{class_name} {{
    now := time.Now().UTC()
    return &{class_name}{{
        ID:          "generated-id", // TODO: Use UUID library
        Name:        name,
        Description: description,
        Status:      "active",
        Metadata:    make(map[string]interface{{}}),
        CreatedAt:   now,
        UpdatedAt:   now,
    }}
}}

func (m *{class_name}) ToJSON() ([]byte, error) {{
    return json.Marshal(m)
}}

func {class_name}FromJSON(data []byte) (*{class_name}, error) {{
    var m {class_name}
    if err := json.Unmarshal(data, &m); err != nil {{
        return nil, err
    }}
    return &m, nil
}}

func (m *{class_name}) Validate() []string {{
    var errors []string
    if m.Name == "" {{
        errors = append(errors, "name is required")
    }}
    validStatuses := map[string]bool{{"active": true, "inactive": true, "archived": true}}
    if !validStatuses[m.Status] {{
        errors = append(errors, "invalid status: "+m.Status)
    }}
    return errors
}}
'''


def _generate_go_service_code(entity: str, spec: str) -> str:
    """Generate a Go service with interface."""
    class_name = entity.capitalize()
    return f'''{CUI_HEADER_C_STYLE}
package service

// {class_name}Service provides business logic for {entity} operations.
//
// Spec: {spec}
// Generated by ICDEV™ Builder - code_generator.py

import (
    "fmt"
    "log"
    "sync"
)

// {class_name}Repository defines the data access interface.
type {class_name}Repository interface {{
    Create(data map[string]interface{{}}) (map[string]interface{{}}, error)
    GetByID(id string) (map[string]interface{{}}, error)
    ListAll() ([]map[string]interface{{}}, error)
    Update(id string, data map[string]interface{{}}) (map[string]interface{{}}, error)
    Delete(id string) error
}}

// {class_name}Service encapsulates business logic for {entity}.
type {class_name}Service struct {{
    mu   sync.RWMutex
    repo {class_name}Repository
}}

// New{class_name}Service creates a new service instance.
func New{class_name}Service(repo {class_name}Repository) *{class_name}Service {{
    return &{class_name}Service{{repo: repo}}
}}

// Create validates and creates a new {entity}.
func (s *{class_name}Service) Create(data map[string]interface{{}}) (map[string]interface{{}}, error) {{
    if err := s.validate(data); err != nil {{
        return nil, err
    }}
    s.mu.Lock()
    defer s.mu.Unlock()
    result, err := s.repo.Create(data)
    if err != nil {{
        return nil, fmt.Errorf("failed to create {entity}: %w", err)
    }}
    log.Printf("{class_name} created: %v", result["id"])
    return result, nil
}}

// GetByID retrieves a {entity} by its ID.
func (s *{class_name}Service) GetByID(id string) (map[string]interface{{}}, error) {{
    s.mu.RLock()
    defer s.mu.RUnlock()
    return s.repo.GetByID(id)
}}

// ListAll returns all {entity} records.
func (s *{class_name}Service) ListAll() ([]map[string]interface{{}}, error) {{
    s.mu.RLock()
    defer s.mu.RUnlock()
    return s.repo.ListAll()
}}

// Update modifies an existing {entity}.
func (s *{class_name}Service) Update(id string, data map[string]interface{{}}) (map[string]interface{{}}, error) {{
    s.mu.Lock()
    defer s.mu.Unlock()
    return s.repo.Update(id, data)
}}

// Delete removes a {entity} by ID.
func (s *{class_name}Service) Delete(id string) error {{
    s.mu.Lock()
    defer s.mu.Unlock()
    return s.repo.Delete(id)
}}

func (s *{class_name}Service) validate(data map[string]interface{{}}) error {{
    if _, ok := data["name"]; !ok {{
        return fmt.Errorf("validation failed: name is required")
    }}
    return nil
}}
'''


# ---------------------------------------------------------------------------
# TypeScript code generators
# ---------------------------------------------------------------------------

def _generate_typescript_api_code(entity: str, spec: str, secure: bool = True) -> str:
    """Generate an Express router (TypeScript)."""
    class_name = entity.capitalize()
    auth_import = ""
    auth_mw = ""
    validate_import = ""
    validate_post = ""
    validate_put = ""
    if secure:
        auth_import = "\nimport { authMiddleware } from './middleware/auth';"
        auth_mw = ", authMiddleware"
        validate_import = """

/**
 * Validate required fields in request body (NIST SI-10).
 */
function validateBody(body: Record<string, unknown>, required: string[]): string | null {{
    if (!body || typeof body !== 'object') return 'Request body must be a JSON object';
    const missing = required.filter(f => !(f in body));
    return missing.length ? `Missing required fields: ${{missing.join(', ')}}` : null;
}}"""
        validate_post = """
        const err = validateBody(req.body, []);
        if (err) return res.status(400).json({{ error: err }});"""
        validate_put = """
        const err = validateBody(req.body, []);
        if (err) return res.status(400).json({{ error: err }});"""
    return f'''{CUI_HEADER_C_STYLE}
/**
 * API routes for {entity}.
 *
 * Spec: {spec}
 * Generated by ICDEV™ Builder - code_generator.py
 */

import {{ Router, Request, Response }} from 'express';
import {{ {class_name}Service }} from './{entity}.service';{auth_import}

const router = Router();
const service = new {class_name}Service();
{validate_import}

/**
 * GET /api/{entity} - List all {entity} records.
 */
router.get('/'{auth_mw}, async (req: Request, res: Response) => {{
    try {{
        const items = await service.listAll();
        res.json({{ data: items, count: items.length }});
    }} catch (err) {{
        res.status(500).json({{ error: 'Internal server error' }});
    }}
}});

/**
 * GET /api/{entity}/:id - Get a single {entity} by ID.
 */
router.get('/:id'{auth_mw}, async (req: Request, res: Response) => {{
    try {{
        const item = await service.getById(req.params.id);
        if (!item) {{
            return res.status(404).json({{ error: '{class_name} not found' }});
        }}
        res.json(item);
    }} catch (err) {{
        res.status(500).json({{ error: 'Internal server error' }});
    }}
}});

/**
 * POST /api/{entity} - Create a new {entity}.
 */
router.post('/'{auth_mw}, async (req: Request, res: Response) => {{
    try {{{validate_post}
        const created = await service.create(req.body);
        res.status(201).json(created);
    }} catch (err) {{
        res.status(400).json({{ error: (err as Error).message }});
    }}
}});

/**
 * PUT /api/{entity}/:id - Update an existing {entity}.
 */
router.put('/:id'{auth_mw}, async (req: Request, res: Response) => {{
    try {{{validate_put}
        const updated = await service.update(req.params.id, req.body);
        if (!updated) {{
            return res.status(404).json({{ error: '{class_name} not found' }});
        }}
        res.json(updated);
    }} catch (err) {{
        res.status(400).json({{ error: (err as Error).message }});
    }}
}});

/**
 * DELETE /api/{entity}/:id - Delete a {entity}.
 */
router.delete('/:id'{auth_mw}, async (req: Request, res: Response) => {{
    try {{
        const deleted = await service.delete(req.params.id);
        if (!deleted) {{
            return res.status(404).json({{ error: '{class_name} not found' }});
        }}
        res.status(204).send();
    }} catch (err) {{
        res.status(500).json({{ error: 'Internal server error' }});
    }}
}});

export default router;
'''


def _generate_typescript_model_code(entity: str, spec: str) -> str:
    """Generate a TypeScript interface and class model."""
    class_name = entity.capitalize()
    return f'''{CUI_HEADER_C_STYLE}
/**
 * Data model for {entity}.
 *
 * Spec: {spec}
 * Generated by ICDEV™ Builder - code_generator.py
 */

export interface I{class_name} {{
    id: string;
    name: string;
    description?: string;
    status: 'active' | 'inactive' | 'archived';
    metadata?: Record<string, unknown>;
    createdAt: string;
    updatedAt: string;
}}

export class {class_name} implements I{class_name} {{
    id: string;
    name: string;
    description: string;
    status: 'active' | 'inactive' | 'archived';
    metadata: Record<string, unknown>;
    createdAt: string;
    updatedAt: string;

    constructor(data: Partial<I{class_name}> = {{}}) {{
        const now = new Date().toISOString();
        this.id = data.id || crypto.randomUUID();
        this.name = data.name || '';
        this.description = data.description || '';
        this.status = data.status || 'active';
        this.metadata = data.metadata || {{}};
        this.createdAt = data.createdAt || now;
        this.updatedAt = data.updatedAt || now;
    }}

    toJSON(): I{class_name} {{
        return {{
            id: this.id,
            name: this.name,
            description: this.description,
            status: this.status,
            metadata: this.metadata,
            createdAt: this.createdAt,
            updatedAt: this.updatedAt,
        }};
    }}

    validate(): string[] {{
        const errors: string[] = [];
        if (!this.name) {{
            errors.push('name is required');
        }}
        if (!['active', 'inactive', 'archived'].includes(this.status)) {{
            errors.push(`invalid status: ${{this.status}}`);
        }}
        return errors;
    }}
}}
'''


def _generate_typescript_service_code(entity: str, spec: str) -> str:
    """Generate a TypeScript service class."""
    class_name = entity.capitalize()
    return f'''{CUI_HEADER_C_STYLE}
/**
 * Service layer for {entity} business logic.
 *
 * Spec: {spec}
 * Generated by ICDEV™ Builder - code_generator.py
 */

import {{ I{class_name}, {class_name} }} from './{entity}.model';

export interface I{class_name}Repository {{
    create(data: Partial<I{class_name}>): Promise<I{class_name}>;
    getById(id: string): Promise<I{class_name} | null>;
    listAll(): Promise<I{class_name}[]>;
    update(id: string, data: Partial<I{class_name}>): Promise<I{class_name} | null>;
    delete(id: string): Promise<boolean>;
}}

export class {class_name}Service {{
    private repository: I{class_name}Repository;

    constructor(repository?: I{class_name}Repository) {{
        this.repository = repository || new InMemory{class_name}Repository();
    }}

    async create(data: Partial<I{class_name}>): Promise<I{class_name}> {{
        const entity = new {class_name}(data);
        const errors = entity.validate();
        if (errors.length > 0) {{
            throw new Error(`Validation failed: ${{errors.join('; ')}}`);
        }}
        return this.repository.create(entity.toJSON());
    }}

    async getById(id: string): Promise<I{class_name} | null> {{
        return this.repository.getById(id);
    }}

    async listAll(): Promise<I{class_name}[]> {{
        return this.repository.listAll();
    }}

    async update(id: string, data: Partial<I{class_name}>): Promise<I{class_name} | null> {{
        return this.repository.update(id, data);
    }}

    async delete(id: string): Promise<boolean> {{
        return this.repository.delete(id);
    }}
}}

class InMemory{class_name}Repository implements I{class_name}Repository {{
    private store = new Map<string, I{class_name}>();

    async create(data: I{class_name}): Promise<I{class_name}> {{
        this.store.set(data.id, data);
        return data;
    }}

    async getById(id: string): Promise<I{class_name} | null> {{
        return this.store.get(id) || null;
    }}

    async listAll(): Promise<I{class_name}[]> {{
        return Array.from(this.store.values());
    }}

    async update(id: string, data: Partial<I{class_name}>): Promise<I{class_name} | null> {{
        const existing = this.store.get(id);
        if (!existing) return null;
        const updated = {{ ...existing, ...data, updatedAt: new Date().toISOString() }};
        this.store.set(id, updated);
        return updated;
    }}

    async delete(id: string): Promise<boolean> {{
        return this.store.delete(id);
    }}
}}
'''


# ---------------------------------------------------------------------------
# Rust code generators
# ---------------------------------------------------------------------------

def _generate_rust_api_code(entity: str, spec: str, secure: bool = True) -> str:
    """Generate Actix-web handlers (Rust)."""
    class_name = entity.capitalize()
    auth_use = ""
    auth_guard = ""
    if secure:
        auth_use = "\nuse actix_web::HttpRequest;"
        auth_guard = """

/// Auth guard — verify request has valid authorization (NIST AC-3).
fn require_auth(req: &HttpRequest) -> Result<(), HttpResponse> {{
    match req.headers().get("Authorization") {{
        Some(_) => Ok(()),
        None => Err(HttpResponse::Unauthorized().json(json!({{ "error": "Authentication required" }}))),
    }}
}}
"""

    auth_check_list = ""
    auth_check_get = ""
    auth_check_create = ""
    auth_check_delete = ""
    if secure:
        auth_check_list = """
    if let Err(resp) = require_auth(&req) {{ return resp; }}"""
        auth_check_get = """
    if let Err(resp) = require_auth(&req) {{ return resp; }}"""
        auth_check_create = """
    if let Err(resp) = require_auth(&req) {{ return resp; }}"""
        auth_check_delete = """
    if let Err(resp) = require_auth(&req) {{ return resp; }}"""

    req_param_list = ", req: HttpRequest" if secure else ""
    req_param_get = "\n    req: HttpRequest," if secure else ""
    req_param_create = "\n    req: HttpRequest," if secure else ""
    req_param_delete = "\n    req: HttpRequest," if secure else ""

    return f'''{CUI_HEADER_C_STYLE}
//! API handlers for {entity}.
//!
//! Spec: {spec}
//! Generated by ICDEV™ Builder - code_generator.py

use actix_web::{{web, HttpResponse, Responder}};
use serde_json::json;
use std::sync::Mutex;
use std::collections::HashMap;{auth_use}

pub struct {class_name}State {{
    pub store: Mutex<HashMap<String, serde_json::Value>>,
}}

impl {class_name}State {{
    pub fn new() -> Self {{
        {class_name}State {{
            store: Mutex::new(HashMap::new()),
        }}
    }}
}}
{auth_guard}
pub async fn list_{entity}(data: web::Data<{class_name}State>{req_param_list}) -> impl Responder {{{auth_check_list}
    let store = data.store.lock().unwrap();
    let items: Vec<&serde_json::Value> = store.values().collect();
    HttpResponse::Ok().json(json!({{ "data": items, "count": items.len() }}))
}}

pub async fn get_{entity}(
    data: web::Data<{class_name}State>,
    path: web::Path<String>,{req_param_get}
) -> impl Responder {{{auth_check_get}
    let id = path.into_inner();
    let store = data.store.lock().unwrap();
    match store.get(&id) {{
        Some(item) => HttpResponse::Ok().json(item),
        None => HttpResponse::NotFound().json(json!({{ "error": "{class_name} not found" }})),
    }}
}}

pub async fn create_{entity}(
    data: web::Data<{class_name}State>,
    body: web::Json<serde_json::Value>,{req_param_create}
) -> impl Responder {{{auth_check_create}
    let mut store = data.store.lock().unwrap();
    let id = uuid::Uuid::new_v4().to_string();
    let mut record = body.into_inner();
    record["id"] = json!(id.clone());
    store.insert(id, record.clone());
    HttpResponse::Created().json(record)
}}

pub async fn delete_{entity}(
    data: web::Data<{class_name}State>,
    path: web::Path<String>,{req_param_delete}
) -> impl Responder {{{auth_check_delete}
    let id = path.into_inner();
    let mut store = data.store.lock().unwrap();
    match store.remove(&id) {{
        Some(_) => HttpResponse::NoContent().finish(),
        None => HttpResponse::NotFound().json(json!({{ "error": "{class_name} not found" }})),
    }}
}}

pub fn configure(cfg: &mut web::ServiceConfig) {{
    cfg.service(
        web::resource("/api/{entity}")
            .route(web::get().to(list_{entity}))
            .route(web::post().to(create_{entity}))
    )
    .service(
        web::resource("/api/{entity}/{{id}}")
            .route(web::get().to(get_{entity}))
            .route(web::delete().to(delete_{entity}))
    );
}}
'''


def _generate_rust_model_code(entity: str, spec: str) -> str:
    """Generate a Rust struct with serde Serialize/Deserialize."""
    class_name = entity.capitalize()
    return f'''{CUI_HEADER_C_STYLE}
//! Data model for {entity}.
//!
//! Spec: {spec}
//! Generated by ICDEV™ Builder - code_generator.py

use serde::{{Deserialize, Serialize}};
use std::collections::HashMap;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct {class_name} {{
    pub id: String,
    pub name: String,
    #[serde(default)]
    pub description: String,
    #[serde(default = "default_status")]
    pub status: String,
    #[serde(default)]
    pub metadata: HashMap<String, serde_json::Value>,
    pub created_at: String,
    pub updated_at: String,
}}

fn default_status() -> String {{
    "active".to_string()
}}

impl {class_name} {{
    pub fn new(name: &str, description: &str) -> Self {{
        let now = chrono::Utc::now().to_rfc3339();
        {class_name} {{
            id: uuid::Uuid::new_v4().to_string(),
            name: name.to_string(),
            description: description.to_string(),
            status: "active".to_string(),
            metadata: HashMap::new(),
            created_at: now.clone(),
            updated_at: now,
        }}
    }}

    pub fn validate(&self) -> Vec<String> {{
        let mut errors = Vec::new();
        if self.name.is_empty() {{
            errors.push("name is required".to_string());
        }}
        let valid_statuses = ["active", "inactive", "archived"];
        if !valid_statuses.contains(&self.status.as_str()) {{
            errors.push(format!("invalid status: {{}}", self.status));
        }}
        errors
    }}
}}

impl Default for {class_name} {{
    fn default() -> Self {{
        Self::new("", "")
    }}
}}
'''


def _generate_rust_service_code(entity: str, spec: str) -> str:
    """Generate a Rust service with trait."""
    class_name = entity.capitalize()
    return f'''{CUI_HEADER_C_STYLE}
//! Service layer for {entity} business logic.
//!
//! Spec: {spec}
//! Generated by ICDEV™ Builder - code_generator.py

use std::collections::HashMap;
use std::sync::{{Arc, RwLock}};

pub trait {class_name}Repository: Send + Sync {{
    fn create(&self, data: HashMap<String, String>) -> Result<HashMap<String, String>, String>;
    fn get_by_id(&self, id: &str) -> Result<Option<HashMap<String, String>>, String>;
    fn list_all(&self) -> Result<Vec<HashMap<String, String>>, String>;
    fn update(&self, id: &str, data: HashMap<String, String>) -> Result<Option<HashMap<String, String>>, String>;
    fn delete(&self, id: &str) -> Result<bool, String>;
}}

pub struct {class_name}Service {{
    repo: Arc<dyn {class_name}Repository>,
}}

impl {class_name}Service {{
    pub fn new(repo: Arc<dyn {class_name}Repository>) -> Self {{
        {class_name}Service {{ repo }}
    }}

    pub fn create(&self, data: HashMap<String, String>) -> Result<HashMap<String, String>, String> {{
        self.validate(&data)?;
        self.repo.create(data)
    }}

    pub fn get_by_id(&self, id: &str) -> Result<Option<HashMap<String, String>>, String> {{
        self.repo.get_by_id(id)
    }}

    pub fn list_all(&self) -> Result<Vec<HashMap<String, String>>, String> {{
        self.repo.list_all()
    }}

    pub fn update(&self, id: &str, data: HashMap<String, String>) -> Result<Option<HashMap<String, String>>, String> {{
        self.repo.update(id, data)
    }}

    pub fn delete(&self, id: &str) -> Result<bool, String> {{
        self.repo.delete(id)
    }}

    fn validate(&self, data: &HashMap<String, String>) -> Result<(), String> {{
        if !data.contains_key("name") || data["name"].is_empty() {{
            return Err("validation failed: name is required".to_string());
        }}
        Ok(())
    }}
}}
'''


# ---------------------------------------------------------------------------
# C# code generators
# ---------------------------------------------------------------------------

def _generate_csharp_api_code(entity: str, spec: str, secure: bool = True) -> str:
    """Generate an ASP.NET controller (C#)."""
    class_name = entity.capitalize()
    auth_using = ""
    auth_attr = ""
    if secure:
        auth_using = "\nusing Microsoft.AspNetCore.Authorization;"
        auth_attr = "\n    [Authorize]"
    return f'''{CUI_HEADER_C_STYLE}
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;{auth_using}

namespace ICDev.Controllers
{{
    /// <summary>
    /// REST API controller for {entity}.
    ///
    /// Spec: {spec}
    /// Generated by ICDEV™ Builder - code_generator.py
    /// </summary>
    [ApiController]
    [Route("api/{entity}")]{auth_attr}
    public class {class_name}Controller : ControllerBase
    {{
        private readonly {class_name}Service _service;

        public {class_name}Controller({class_name}Service service)
        {{
            _service = service;
        }}

        [HttpGet]
        public ActionResult<IEnumerable<Dictionary<string, object>>> List()
        {{
            var items = _service.ListAll();
            return Ok(new {{ data = items, count = items.Count }});
        }}

        [HttpGet("{{id}}")]
        public ActionResult<Dictionary<string, object>> Get(string id)
        {{
            var item = _service.GetById(id);
            if (item == null)
                return NotFound(new {{ error = "{class_name} not found" }});
            return Ok(item);
        }}

        [HttpPost]
        public ActionResult<Dictionary<string, object>> Create([FromBody] Dictionary<string, object> data)
        {{
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            var created = _service.Create(data);
            return CreatedAtAction(nameof(Get), new {{ id = created["id"] }}, created);
        }}

        [HttpPut("{{id}}")]
        public ActionResult<Dictionary<string, object>> Update(string id, [FromBody] Dictionary<string, object> data)
        {{
            if (!ModelState.IsValid)
                return BadRequest(ModelState);
            var updated = _service.Update(id, data);
            if (updated == null)
                return NotFound(new {{ error = "{class_name} not found" }});
            return Ok(updated);
        }}

        [HttpDelete("{{id}}")]
        public IActionResult Delete(string id)
        {{
            var deleted = _service.Delete(id);
            if (!deleted)
                return NotFound(new {{ error = "{class_name} not found" }});
            return NoContent();
        }}
    }}
}}
'''


def _generate_csharp_model_code(entity: str, spec: str) -> str:
    """Generate a C# record/class model with data annotations."""
    class_name = entity.capitalize()
    return f'''{CUI_HEADER_C_STYLE}
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ICDev.Models
{{
    /// <summary>
    /// Data model for {entity}.
    ///
    /// Spec: {spec}
    /// Generated by ICDEV™ Builder - code_generator.py
    /// </summary>
    public class {class_name}
    {{
        public string Id {{ get; set; }} = Guid.NewGuid().ToString();

        [Required(ErrorMessage = "Name is required")]
        public string Name {{ get; set; }} = string.Empty;

        public string Description {{ get; set; }} = string.Empty;

        public string Status {{ get; set; }} = "active";

        public Dictionary<string, object> Metadata {{ get; set; }} = new();

        public DateTime CreatedAt {{ get; set; }} = DateTime.UtcNow;

        public DateTime UpdatedAt {{ get; set; }} = DateTime.UtcNow;

        public List<string> Validate()
        {{
            var errors = new List<string>();
            if (string.IsNullOrWhiteSpace(Name))
                errors.Add("name is required");
            var validStatuses = new[] {{ "active", "inactive", "archived" }};
            if (Array.IndexOf(validStatuses, Status) < 0)
                errors.Add($"invalid status: {{Status}}");
            return errors;
        }}
    }}
}}
'''


def _generate_csharp_service_code(entity: str, spec: str) -> str:
    """Generate a C# service class with DI interface."""
    class_name = entity.capitalize()
    return f'''{CUI_HEADER_C_STYLE}
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Extensions.Logging;

namespace ICDev.Services
{{
    /// <summary>
    /// Service interface for {entity} operations.
    /// </summary>
    public interface I{class_name}Service
    {{
        Dictionary<string, object> Create(Dictionary<string, object> data);
        Dictionary<string, object> GetById(string id);
        List<Dictionary<string, object>> ListAll();
        Dictionary<string, object> Update(string id, Dictionary<string, object> data);
        bool Delete(string id);
    }}

    /// <summary>
    /// Service layer for {entity} business logic.
    ///
    /// Spec: {spec}
    /// Generated by ICDEV™ Builder - code_generator.py
    /// </summary>
    public class {class_name}Service : I{class_name}Service
    {{
        private readonly ILogger<{class_name}Service> _logger;
        private readonly Dictionary<string, Dictionary<string, object>> _store = new();

        public {class_name}Service(ILogger<{class_name}Service> logger)
        {{
            _logger = logger;
            _logger.LogInformation("{class_name}Service initialized");
        }}

        public Dictionary<string, object> Create(Dictionary<string, object> data)
        {{
            var id = Guid.NewGuid().ToString();
            data["id"] = id;
            data["created_at"] = DateTime.UtcNow.ToString("o");
            data["updated_at"] = DateTime.UtcNow.ToString("o");
            _store[id] = data;
            _logger.LogInformation("{class_name} created: {{Id}}", id);
            return data;
        }}

        public Dictionary<string, object> GetById(string id)
        {{
            return _store.GetValueOrDefault(id);
        }}

        public List<Dictionary<string, object>> ListAll()
        {{
            return _store.Values.ToList();
        }}

        public Dictionary<string, object> Update(string id, Dictionary<string, object> data)
        {{
            if (!_store.ContainsKey(id))
                return null;
            foreach (var kvp in data)
                _store[id][kvp.Key] = kvp.Value;
            _store[id]["updated_at"] = DateTime.UtcNow.ToString("o");
            return _store[id];
        }}

        public bool Delete(string id)
        {{
            return _store.Remove(id);
        }}
    }}
}}
'''


# ---------------------------------------------------------------------------
# Phase 19: Agentic spec type generators (Python — FORGE child apps)
# ---------------------------------------------------------------------------

def _generate_agent_skill_code(entity: str, spec: str) -> str:
    """Generate A2A skill handler with register_skill().

    Creates an agent skill module that:
    - Defines a skill handler class with execute() and validate()
    - Provides register_skill() for A2A agent card registration
    - Includes JSON-RPC 2.0 compliant request/response handling
    - Logs skill invocations to the audit trail
    """
    class_name = entity.capitalize()
    skill_name = _slugify(entity)
    return f'''{CUI_HEADER}
"""A2A Skill Handler: {entity}

Spec: {spec}
Generated by ICDEV™ Builder - code_generator.py (Phase 19: Agentic)

Implements an A2A-compliant skill that can be registered with any
FORGE-framework agent. Follows JSON-RPC 2.0 protocol over mTLS.
"""

import hashlib
import json
import logging
import time
import uuid
from datetime import datetime, timezone
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


class {class_name}Skill:
    """A2A skill handler for {entity}.

    This skill can be registered with an agent and invoked via
    the A2A protocol. It validates input, executes the skill logic,
    and returns structured results.

    Attributes:
        skill_id: Unique identifier for this skill instance.
        name: Human-readable skill name.
        version: Semantic version string.
        description: What this skill does.
        keywords: Discovery keywords for agent card.
        max_retries: Maximum retry attempts on transient failure.
    """

    SKILL_NAME = "{skill_name}"
    SKILL_VERSION = "1.0.0"
    KEYWORDS = ["agent", "skill", "a2a", "dispatch", "{entity}"]

    def __init__(self, config: Optional[Dict[str, Any]] = None) -> None:
        """Initialize the skill handler.

        Args:
            config: Optional configuration overrides.
        """
        self.skill_id = str(uuid.uuid4())
        self.name = self.SKILL_NAME
        self.version = self.SKILL_VERSION
        self.description = "{spec}"
        self.keywords = self.KEYWORDS
        self.config = config or {{}}
        self.max_retries = self.config.get("max_retries", 3)
        self._invocation_count = 0
        self._last_invocation: Optional[str] = None
        logger.info(f"{class_name}Skill initialized (id={{self.skill_id}})")

    def validate(self, params: Dict[str, Any]) -> List[str]:
        """Validate skill invocation parameters.

        Args:
            params: The parameters passed to the skill.

        Returns:
            List of validation error messages (empty if valid).
        """
        errors = []
        if not params:
            errors.append("params cannot be empty")
        if "action" not in params:
            errors.append("'action' is required in params")
        return errors

    def execute(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """Execute the skill with the given parameters.

        Args:
            params: Skill invocation parameters. Must include 'action'.

        Returns:
            Result dict with 'status', 'data', and 'metadata' keys.

        Raises:
            ValueError: If parameter validation fails.
        """
        errors = self.validate(params)
        if errors:
            raise ValueError(f"Validation failed: {{'; '.join(errors)}}")

        self._invocation_count += 1
        self._last_invocation = datetime.now(timezone.utc).isoformat() + "Z"

        action = params.get("action", "default")
        logger.info(
            f"{{self.name}} executing action='{{action}}' "
            f"(invocation #{{self._invocation_count}})"
        )

        result = {{
            "status": "completed",
            "skill_id": self.skill_id,
            "action": action,
            "data": self._process_action(action, params),
            "metadata": {{
                "invocation_count": self._invocation_count,
                "timestamp": self._last_invocation,
                "version": self.version,
            }},
        }}
        return result

    def _process_action(self, action: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """Process a specific action within the skill.

        Override this method to implement custom skill logic.

        Args:
            action: The action to perform.
            params: Full parameter dict.

        Returns:
            Action-specific result data.
        """
        return {{
            "action": action,
            "input_keys": list(params.keys()),
            "processed": True,
        }}

    def get_skill_card(self) -> Dict[str, Any]:
        """Generate the A2A skill card for agent registration.

        Returns:
            Skill card dict compatible with /.well-known/agent.json.
        """
        return {{
            "id": self.skill_id,
            "name": self.name,
            "version": self.version,
            "description": self.description,
            "keywords": self.keywords,
            "input_schema": {{
                "type": "object",
                "required": ["action"],
                "properties": {{
                    "action": {{"type": "string", "description": "Action to perform"}},
                    "data": {{"type": "object", "description": "Action-specific data"}},
                }},
            }},
            "output_schema": {{
                "type": "object",
                "properties": {{
                    "status": {{"type": "string"}},
                    "data": {{"type": "object"}},
                    "metadata": {{"type": "object"}},
                }},
            }},
        }}


def register_skill(
    agent_url: str,
    skill: {class_name}Skill,
    auth_token: Optional[str] = None,
) -> Dict[str, Any]:
    """Register this skill with an A2A agent.

    Sends the skill card to the agent's registration endpoint so it
    appears in the agent's /.well-known/agent.json capabilities list.

    Args:
        agent_url: Base URL of the target agent (e.g. https://agent:8443).
        skill: The skill instance to register.
        auth_token: Optional mTLS/bearer token for authentication.

    Returns:
        Registration confirmation dict.
    """
    skill_card = skill.get_skill_card()
    registration = {{
        "jsonrpc": "2.0",
        "method": "skill.register",
        "params": skill_card,
        "id": str(uuid.uuid4()),
    }}
    logger.info(
        f"Registering skill '{{skill.name}}' with agent at {{agent_url}}"
    )
    # In production, this would POST to agent_url/a2a via mTLS
    # For now, return the registration payload for testing
    return {{
        "status": "registered",
        "agent_url": agent_url,
        "skill_id": skill.skill_id,
        "skill_name": skill.name,
        "registration": registration,
    }}


# Standalone usage
if __name__ == "__main__":
    skill = {class_name}Skill()
    print(json.dumps(skill.get_skill_card(), indent=2))
    result = skill.execute({{"action": "test", "data": {{"key": "value"}}}})
    print(json.dumps(result, indent=2))
'''


def _generate_llm_service_code(entity: str, spec: str) -> str:
    """Generate BedrockClient wrapper with retry and token tracking.

    Creates an LLM service module that:
    - Wraps AWS Bedrock invoke_model with exponential backoff retry
    - Tracks input/output token counts per request and cumulative
    - Supports configurable model ID, temperature, max_tokens
    - Logs all invocations with token usage for cost tracking
    """
    class_name = entity.capitalize()
    return f'''{CUI_HEADER}
"""LLM Service: {entity}

Spec: {spec}
Generated by ICDEV™ Builder - code_generator.py (Phase 19: Agentic)

Provides a BedrockClient wrapper with exponential backoff retry,
per-request and cumulative token tracking, and structured logging
for cost analysis and audit compliance.
"""

import json
import logging
import time
import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


class TokenUsage:
    """Tracks token usage across LLM invocations.

    Attributes:
        total_input_tokens: Cumulative input tokens consumed.
        total_output_tokens: Cumulative output tokens generated.
        request_count: Number of successful invocations.
        history: Per-request token usage records.
    """

    def __init__(self) -> None:
        self.total_input_tokens: int = 0
        self.total_output_tokens: int = 0
        self.request_count: int = 0
        self.history: List[Dict[str, Any]] = []

    def record(self, input_tokens: int, output_tokens: int, model_id: str) -> None:
        """Record token usage from a single invocation.

        Args:
            input_tokens: Tokens in the prompt.
            output_tokens: Tokens in the response.
            model_id: Model that was invoked.
        """
        self.total_input_tokens += input_tokens
        self.total_output_tokens += output_tokens
        self.request_count += 1
        self.history.append({{
            "timestamp": datetime.now(timezone.utc).isoformat() + "Z",
            "model_id": model_id,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
        }})

    def to_dict(self) -> Dict[str, Any]:
        """Serialize usage summary to dict."""
        return {{
            "total_input_tokens": self.total_input_tokens,
            "total_output_tokens": self.total_output_tokens,
            "total_tokens": self.total_input_tokens + self.total_output_tokens,
            "request_count": self.request_count,
        }}


class {class_name}LLMService:
    """Bedrock LLM client wrapper with retry and token tracking.

    Wraps AWS Bedrock invoke_model with:
    - Configurable model ID, temperature, and max_tokens
    - Exponential backoff retry on throttling/transient errors
    - Per-request and cumulative token tracking
    - Structured logging for audit trail

    Attributes:
        model_id: Bedrock model identifier.
        region: AWS region (default: us-gov-west-1 for GovCloud).
        max_retries: Maximum retry attempts.
        base_delay: Initial retry delay in seconds.
        temperature: Sampling temperature (0.0 - 1.0).
        max_tokens: Maximum tokens in response.
        token_usage: Token tracking instance.
    """

    DEFAULT_MODEL_ID = "anthropic.claude-sonnet-4-5-20250929-v1:0"
    DEFAULT_REGION = "us-gov-west-1"

    def __init__(self, config: Optional[Dict[str, Any]] = None) -> None:
        """Initialize the LLM service.

        Args:
            config: Configuration overrides. Supported keys:
                - model_id: Bedrock model ID
                - region: AWS region
                - max_retries: Retry count (default 3)
                - base_delay: Base retry delay in seconds (default 1.0)
                - temperature: Sampling temperature (default 0.7)
                - max_tokens: Max output tokens (default 4096)
        """
        config = config or {{}}
        self.model_id = config.get("model_id", self.DEFAULT_MODEL_ID)
        self.region = config.get("region", self.DEFAULT_REGION)
        self.max_retries = config.get("max_retries", 3)
        self.base_delay = config.get("base_delay", 1.0)
        self.temperature = config.get("temperature", 0.7)
        self.max_tokens = config.get("max_tokens", 4096)
        self.token_usage = TokenUsage()
        self._client = None
        logger.info(
            f"{class_name}LLMService initialized "
            f"(model={{self.model_id}}, region={{self.region}})"
        )

    def _get_client(self) -> Any:
        """Lazily create the Bedrock runtime client.

        Returns:
            boto3 Bedrock runtime client.
        """
        if self._client is None:
            try:
                import boto3
                self._client = boto3.client(
                    "bedrock-runtime",
                    region_name=self.region,
                )
            except ImportError:
                raise RuntimeError(
                    "boto3 is required for Bedrock access. "
                    "Install with: pip install boto3"
                )
        return self._client

    def invoke(
        self,
        prompt: str,
        system_prompt: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
    ) -> Dict[str, Any]:
        """Invoke the LLM with retry and token tracking.

        Args:
            prompt: The user prompt text.
            system_prompt: Optional system instruction.
            temperature: Override default temperature.
            max_tokens: Override default max_tokens.

        Returns:
            Dict with 'content', 'model_id', 'usage', and 'request_id'.

        Raises:
            RuntimeError: If all retries exhausted.
        """
        request_id = str(uuid.uuid4())
        temp = temperature if temperature is not None else self.temperature
        tokens = max_tokens if max_tokens is not None else self.max_tokens

        body = {{
            "anthropic_version": "bedrock-2023-05-31",
            "messages": [{{"role": "user", "content": prompt}}],
            "temperature": temp,
            "max_tokens": tokens,
        }}
        if system_prompt:
            body["system"] = system_prompt

        last_error = None
        for attempt in range(self.max_retries + 1):
            try:
                client = self._get_client()
                response = client.invoke_model(
                    modelId=self.model_id,
                    contentType="application/json",
                    accept="application/json",
                    body=json.dumps(body),
                )
                result = json.loads(response["body"].read())

                # Extract token usage
                usage = result.get("usage", {{}})
                input_tokens = usage.get("input_tokens", 0)
                output_tokens = usage.get("output_tokens", 0)
                self.token_usage.record(input_tokens, output_tokens, self.model_id)

                content = ""
                if "content" in result and result["content"]:
                    content = result["content"][0].get("text", "")

                logger.info(
                    f"LLM invocation complete (request={{request_id}}, "
                    f"in={{input_tokens}}, out={{output_tokens}})"
                )
                return {{
                    "content": content,
                    "model_id": self.model_id,
                    "request_id": request_id,
                    "usage": {{
                        "input_tokens": input_tokens,
                        "output_tokens": output_tokens,
                    }},
                }}

            except Exception as e:
                last_error = e
                if attempt < self.max_retries:
                    delay = self.base_delay * (2 ** attempt)
                    logger.warning(
                        f"LLM invocation failed (attempt {{attempt + 1}}/{{self.max_retries + 1}}), "
                        f"retrying in {{delay:.1f}}s: {{e}}"
                    )
                    time.sleep(delay)

        raise RuntimeError(
            f"LLM invocation failed after {{self.max_retries + 1}} attempts: {{last_error}}"
        )

    def get_usage_summary(self) -> Dict[str, Any]:
        """Return cumulative token usage summary.

        Returns:
            Dict with total input/output tokens and request count.
        """
        return self.token_usage.to_dict()


# Standalone usage
if __name__ == "__main__":
    service = {class_name}LLMService({{
        "model_id": "anthropic.claude-3-sonnet-20240229-v1:0",
    }})
    print(f"Service initialized: model={{service.model_id}}")
    print(f"Usage: {{json.dumps(service.get_usage_summary(), indent=2)}}")
'''


def _generate_prompt_template_code(entity: str, spec: str) -> str:
    """Generate hardprompt manager with {{{{variable}}}} substitution.

    Creates a prompt template module that:
    - Loads templates from hardprompts/ directory
    - Supports {{{{variable}}}} substitution with validation
    - Provides template composition (chain templates together)
    - Includes template caching and versioning
    """
    class_name = entity.capitalize()
    return f'''{CUI_HEADER}
"""Prompt Template Manager: {entity}

Spec: {spec}
Generated by ICDEV™ Builder - code_generator.py (Phase 19: Agentic)

Manages hardprompt templates with variable substitution,
template composition, caching, and version tracking.
Templates use {{{{variable}}}} syntax for substitution.
"""

import hashlib
import json
import logging
import os
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Set

logger = logging.getLogger(__name__)


class PromptTemplate:
    """A single prompt template with variable substitution.

    Attributes:
        name: Template identifier.
        content: Raw template text with {{{{variable}}}} placeholders.
        version: Template version (content hash).
        variables: Set of variable names found in the template.
        metadata: Additional template metadata.
    """

    VARIABLE_PATTERN = re.compile(r"\\{{\\{{(\\w+)\\}}\\}}")

    def __init__(
        self,
        name: str,
        content: str,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Initialize a prompt template.

        Args:
            name: Template identifier.
            content: Raw template text with {{{{var}}}} placeholders.
            metadata: Optional metadata (author, description, etc.).
        """
        self.name = name
        self.content = content
        self.metadata = metadata or {{}}
        self.version = hashlib.sha256(content.encode()).hexdigest()[:12]
        self.variables = self._extract_variables()
        self.created_at = datetime.now(timezone.utc).isoformat() + "Z"

    def _extract_variables(self) -> Set[str]:
        """Extract all variable names from the template.

        Returns:
            Set of variable names found in {{{{var}}}} placeholders.
        """
        return set(self.VARIABLE_PATTERN.findall(self.content))

    def render(self, variables: Dict[str, str]) -> str:
        """Render the template by substituting variables.

        Args:
            variables: Mapping of variable name to value.

        Returns:
            Rendered template string.

        Raises:
            ValueError: If required variables are missing.
        """
        missing = self.variables - set(variables.keys())
        if missing:
            raise ValueError(
                f"Missing required variables: {{', '.join(sorted(missing))}}"
            )

        result = self.content
        for var_name, var_value in variables.items():
            result = result.replace(f"{{{{{{{{{{var_name}}}}}}}}}}", str(var_value))
        return result

    def to_dict(self) -> Dict[str, Any]:
        """Serialize template to dict."""
        return {{
            "name": self.name,
            "version": self.version,
            "variables": sorted(self.variables),
            "metadata": self.metadata,
            "created_at": self.created_at,
            "content_length": len(self.content),
        }}


class {class_name}PromptManager:
    """Manages a collection of hardprompt templates.

    Loads templates from the hardprompts/ directory, supports
    on-demand template creation, composition, and caching.

    Attributes:
        templates_dir: Path to the hardprompts directory.
        templates: Dict of loaded templates keyed by name.
    """

    def __init__(
        self,
        templates_dir: Optional[str] = None,
        project_root: Optional[str] = None,
    ) -> None:
        """Initialize the prompt manager.

        Args:
            templates_dir: Path to templates directory.
            project_root: Project root (templates_dir defaults to
                          {{project_root}}/hardprompts/).
        """
        if templates_dir:
            self.templates_dir = Path(templates_dir)
        elif project_root:
            self.templates_dir = Path(project_root) / "hardprompts"
        else:
            self.templates_dir = Path.cwd() / "hardprompts"

        self.templates: Dict[str, PromptTemplate] = {{}}
        self._load_templates()
        logger.info(
            f"{class_name}PromptManager initialized "
            f"({{len(self.templates)}} templates loaded from {{self.templates_dir}})"
        )

    def _load_templates(self) -> None:
        """Load all .md and .txt templates from the templates directory."""
        if not self.templates_dir.exists():
            logger.warning(f"Templates directory not found: {{self.templates_dir}}")
            return

        for ext in ("*.md", "*.txt"):
            for path in self.templates_dir.glob(ext):
                try:
                    content = path.read_text(encoding="utf-8")
                    name = path.stem
                    self.templates[name] = PromptTemplate(
                        name=name,
                        content=content,
                        metadata={{"source": str(path)}},
                    )
                except Exception as e:
                    logger.error(f"Failed to load template {{path}}: {{e}}")

    def register(self, name: str, content: str, metadata: Optional[Dict[str, Any]] = None) -> PromptTemplate:
        """Register a new template programmatically.

        Args:
            name: Template identifier.
            content: Raw template text.
            metadata: Optional metadata.

        Returns:
            The created PromptTemplate instance.
        """
        template = PromptTemplate(name=name, content=content, metadata=metadata)
        self.templates[name] = template
        logger.info(f"Template registered: {{name}} (v{{template.version}})")
        return template

    def render(self, name: str, variables: Dict[str, str]) -> str:
        """Render a named template with the given variables.

        Args:
            name: Template name.
            variables: Variable substitutions.

        Returns:
            Rendered string.

        Raises:
            KeyError: If template not found.
            ValueError: If required variables are missing.
        """
        if name not in self.templates:
            raise KeyError(f"Template not found: {{name}}")
        return self.templates[name].render(variables)

    def compose(self, template_names: List[str], variables: Dict[str, str], separator: str = "\\n\\n") -> str:
        """Compose multiple templates into a single prompt.

        Args:
            template_names: Ordered list of template names.
            variables: Variable substitutions (applied to all).
            separator: String to join rendered templates.

        Returns:
            Composed rendered string.
        """
        parts = []
        for name in template_names:
            parts.append(self.render(name, variables))
        return separator.join(parts)

    def list_templates(self) -> List[Dict[str, Any]]:
        """List all loaded templates with metadata.

        Returns:
            List of template summary dicts.
        """
        return [t.to_dict() for t in self.templates.values()]


# Standalone usage
if __name__ == "__main__":
    manager = {class_name}PromptManager()
    print(f"Loaded {{len(manager.templates)}} templates")
    for info in manager.list_templates():
        print(f"  {{info['name']}} (v{{info['version']}}): {{info['variables']}}")
'''


def _generate_agent_collaboration_code(entity: str, spec: str) -> str:
    """Generate collaboration coordinator with authority checks.

    Creates a multi-agent collaboration module that:
    - Coordinates task handoffs between agents
    - Enforces authority/permission checks before delegation
    - Tracks collaboration sessions with full audit trail
    - Supports parallel fan-out and sequential pipeline patterns
    """
    class_name = entity.capitalize()
    return f'''{CUI_HEADER}
"""Agent Collaboration Coordinator: {entity}

Spec: {spec}
Generated by ICDEV™ Builder - code_generator.py (Phase 19: Agentic)

Coordinates multi-agent collaboration with authority checks,
task handoff tracking, and structured audit trail. Supports
fan-out (parallel) and pipeline (sequential) collaboration patterns.
"""

import json
import logging
import uuid
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable, Dict, List, Optional

logger = logging.getLogger(__name__)


class CollaborationPattern(Enum):
    """Supported multi-agent collaboration patterns."""
    PIPELINE = "pipeline"       # Sequential A -> B -> C
    FAN_OUT = "fan_out"         # Parallel A -> [B, C, D]
    HANDOFF = "handoff"         # Single transfer A -> B
    ROUND_ROBIN = "round_robin" # Cyclic distribution


class TaskStatus(Enum):
    """Status of a collaboration task."""
    PENDING = "pending"
    DISPATCHED = "dispatched"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"
    REJECTED = "rejected"


class AuthorityLevel(Enum):
    """Agent authority levels for permission checks."""
    CORE = "core"         # Orchestrator, Architect
    DOMAIN = "domain"     # Builder, Compliance, Security, Infra, MBSE, Modernization
    SUPPORT = "support"   # Knowledge, Monitor


# Authority matrix: which levels can delegate to which
AUTHORITY_MATRIX = {{
    AuthorityLevel.CORE: {{AuthorityLevel.CORE, AuthorityLevel.DOMAIN, AuthorityLevel.SUPPORT}},
    AuthorityLevel.DOMAIN: {{AuthorityLevel.DOMAIN, AuthorityLevel.SUPPORT}},
    AuthorityLevel.SUPPORT: {{AuthorityLevel.SUPPORT}},
}}


class CollaborationTask:
    """A single task within a collaboration session.

    Attributes:
        task_id: Unique task identifier.
        source_agent: Agent that created the task.
        target_agent: Agent that should execute the task.
        action: The action to perform.
        params: Task parameters.
        status: Current task status.
        result: Task result (set on completion).
    """

    def __init__(
        self,
        source_agent: str,
        target_agent: str,
        action: str,
        params: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.task_id = str(uuid.uuid4())
        self.source_agent = source_agent
        self.target_agent = target_agent
        self.action = action
        self.params = params or {{}}
        self.status = TaskStatus.PENDING
        self.result: Optional[Dict[str, Any]] = None
        self.created_at = datetime.now(timezone.utc).isoformat() + "Z"
        self.updated_at = self.created_at

    def to_dict(self) -> Dict[str, Any]:
        """Serialize task to dict."""
        return {{
            "task_id": self.task_id,
            "source_agent": self.source_agent,
            "target_agent": self.target_agent,
            "action": self.action,
            "params": self.params,
            "status": self.status.value,
            "result": self.result,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
        }}


class {class_name}Coordinator:
    """Coordinates multi-agent collaboration with authority enforcement.

    Manages collaboration sessions, enforces the authority matrix,
    dispatches tasks to agents, and maintains a full audit trail
    of all handoffs and results.

    Attributes:
        session_id: Current collaboration session ID.
        agents: Registered agents with their authority levels.
        tasks: All tasks in the current session.
        audit_log: Chronological log of all collaboration events.
    """

    def __init__(self, session_id: Optional[str] = None) -> None:
        """Initialize the collaboration coordinator.

        Args:
            session_id: Optional session ID (auto-generated if omitted).
        """
        self.session_id = session_id or str(uuid.uuid4())
        self.agents: Dict[str, AuthorityLevel] = {{}}
        self.tasks: List[CollaborationTask] = []
        self.audit_log: List[Dict[str, Any]] = []
        self._task_handlers: Dict[str, Callable] = {{}}
        logger.info(f"{class_name}Coordinator initialized (session={{self.session_id}})")

    def register_agent(self, agent_name: str, authority: AuthorityLevel) -> None:
        """Register an agent with the coordinator.

        Args:
            agent_name: Unique agent identifier.
            authority: Agent's authority level.
        """
        self.agents[agent_name] = authority
        self._log_event("agent_registered", {{
            "agent": agent_name,
            "authority": authority.value,
        }})

    def check_authority(self, source_agent: str, target_agent: str) -> bool:
        """Check if source agent can delegate to target agent.

        Args:
            source_agent: The delegating agent.
            target_agent: The receiving agent.

        Returns:
            True if delegation is authorized.
        """
        source_level = self.agents.get(source_agent)
        target_level = self.agents.get(target_agent)

        if source_level is None:
            logger.warning(f"Unknown source agent: {{source_agent}}")
            return False
        if target_level is None:
            logger.warning(f"Unknown target agent: {{target_agent}}")
            return False

        allowed = AUTHORITY_MATRIX.get(source_level, set())
        return target_level in allowed

    def handoff(
        self,
        source_agent: str,
        target_agent: str,
        action: str,
        params: Optional[Dict[str, Any]] = None,
    ) -> CollaborationTask:
        """Create and dispatch a handoff task with authority check.

        Args:
            source_agent: The delegating agent.
            target_agent: The receiving agent.
            action: Action to perform.
            params: Task parameters.

        Returns:
            The created CollaborationTask.

        Raises:
            PermissionError: If authority check fails.
            ValueError: If agents are not registered.
        """
        if source_agent not in self.agents:
            raise ValueError(f"Source agent not registered: {{source_agent}}")
        if target_agent not in self.agents:
            raise ValueError(f"Target agent not registered: {{target_agent}}")

        if not self.check_authority(source_agent, target_agent):
            self._log_event("authority_denied", {{
                "source": source_agent,
                "target": target_agent,
                "action": action,
            }})
            raise PermissionError(
                f"{{source_agent}} ({{self.agents[source_agent].value}}) "
                f"cannot delegate to {{target_agent}} ({{self.agents[target_agent].value}})"
            )

        task = CollaborationTask(
            source_agent=source_agent,
            target_agent=target_agent,
            action=action,
            params=params,
        )
        task.status = TaskStatus.DISPATCHED
        task.updated_at = datetime.now(timezone.utc).isoformat() + "Z"
        self.tasks.append(task)

        self._log_event("task_handoff", {{
            "task_id": task.task_id,
            "source": source_agent,
            "target": target_agent,
            "action": action,
        }})

        logger.info(
            f"Handoff: {{source_agent}} -> {{target_agent}} "
            f"action='{{action}}' task_id={{task.task_id}}"
        )
        return task

    def complete_task(self, task_id: str, result: Dict[str, Any]) -> None:
        """Mark a task as completed with its result.

        Args:
            task_id: Task to complete.
            result: Task result data.
        """
        for task in self.tasks:
            if task.task_id == task_id:
                task.status = TaskStatus.COMPLETED
                task.result = result
                task.updated_at = datetime.now(timezone.utc).isoformat() + "Z"
                self._log_event("task_completed", {{
                    "task_id": task_id,
                    "target": task.target_agent,
                }})
                return
        raise ValueError(f"Task not found: {{task_id}}")

    def fail_task(self, task_id: str, error: str) -> None:
        """Mark a task as failed.

        Args:
            task_id: Task to mark as failed.
            error: Error description.
        """
        for task in self.tasks:
            if task.task_id == task_id:
                task.status = TaskStatus.FAILED
                task.result = {{"error": error}}
                task.updated_at = datetime.now(timezone.utc).isoformat() + "Z"
                self._log_event("task_failed", {{
                    "task_id": task_id,
                    "error": error,
                }})
                return
        raise ValueError(f"Task not found: {{task_id}}")

    def get_session_summary(self) -> Dict[str, Any]:
        """Get a summary of the current collaboration session.

        Returns:
            Session summary with task counts and status breakdown.
        """
        status_counts: Dict[str, int] = {{}}
        for task in self.tasks:
            status_counts[task.status.value] = status_counts.get(task.status.value, 0) + 1

        return {{
            "session_id": self.session_id,
            "agent_count": len(self.agents),
            "task_count": len(self.tasks),
            "status_breakdown": status_counts,
            "audit_events": len(self.audit_log),
        }}

    def _log_event(self, event_type: str, details: Dict[str, Any]) -> None:
        """Append an event to the audit log.

        Args:
            event_type: Type of collaboration event.
            details: Event-specific data.
        """
        self.audit_log.append({{
            "timestamp": datetime.now(timezone.utc).isoformat() + "Z",
            "session_id": self.session_id,
            "event_type": event_type,
            "details": details,
        }})


# Standalone usage
if __name__ == "__main__":
    coord = {class_name}Coordinator()
    coord.register_agent("orchestrator", AuthorityLevel.CORE)
    coord.register_agent("builder", AuthorityLevel.DOMAIN)
    coord.register_agent("monitor", AuthorityLevel.SUPPORT)

    task = coord.handoff("orchestrator", "builder", "generate_code", {{"spec": "REST API"}})
    coord.complete_task(task.task_id, {{"files": ["api.py"]}})

    print(json.dumps(coord.get_session_summary(), indent=2))
'''


def _generate_model_config_code(entity: str, spec: str) -> str:
    """Generate agent config + card generation module.

    Creates a model/agent configuration module that:
    - Defines agent configuration dataclass with validation
    - Generates /.well-known/agent.json agent cards
    - Supports loading config from YAML/JSON files
    - Validates agent config against the FORGE framework schema
    """
    class_name = entity.capitalize()
    return f'''{CUI_HEADER}
"""Agent Configuration & Card Generator: {entity}

Spec: {spec}
Generated by ICDEV™ Builder - code_generator.py (Phase 19: Agentic)

Provides agent configuration management and /.well-known/agent.json
card generation for A2A protocol compliance. Supports loading from
YAML/JSON and validation against the FORGE framework schema.
"""

import hashlib
import json
import logging
import os
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)


# Valid agent tiers and their allowed ports
AGENT_TIERS = {{
    "core": {{"ports": range(8443, 8445), "max_agents": 2}},
    "domain": {{"ports": range(8445, 8453), "max_agents": 8}},
    "support": {{"ports": range(8449, 8453), "max_agents": 4}},
}}

# Required fields per agent tier
TIER_REQUIREMENTS = {{
    "core": ["name", "port", "tier", "model_id", "tls_cert"],
    "domain": ["name", "port", "tier", "model_id"],
    "support": ["name", "port", "tier"],
}}


@dataclass
class AgentSkillConfig:
    """Configuration for a single agent skill.

    Attributes:
        name: Skill name.
        version: Skill version.
        description: What the skill does.
        keywords: Discovery keywords.
        input_schema: JSON Schema for skill input.
    """
    name: str = ""
    version: str = "1.0.0"
    description: str = ""
    keywords: List[str] = field(default_factory=list)
    input_schema: Dict[str, Any] = field(default_factory=dict)


@dataclass
class {class_name}AgentConfig:
    """Full agent configuration for a FORGE framework agent.

    Attributes:
        name: Agent name (e.g. 'builder', 'compliance').
        port: Agent listening port.
        tier: Agent tier (core, domain, support).
        model_id: Bedrock model ID for LLM inference.
        tls_cert: Path to TLS certificate.
        tls_key: Path to TLS private key.
        description: Human-readable description.
        skills: List of skill configurations.
        metadata: Additional key-value metadata.
        health_endpoint: Health check path (default /health).
        max_concurrent_tasks: Max parallel task limit.
    """
    name: str = ""
    port: int = 8443
    tier: str = "domain"
    model_id: str = "anthropic.claude-3-sonnet-20240229-v1:0"
    tls_cert: str = ""
    tls_key: str = ""
    description: str = ""
    skills: List[AgentSkillConfig] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    health_endpoint: str = "/health"
    max_concurrent_tasks: int = 10

    def validate(self) -> List[str]:
        """Validate the agent configuration.

        Returns:
            List of validation error messages (empty if valid).
        """
        errors = []
        if not self.name:
            errors.append("name is required")
        if not isinstance(self.port, int) or self.port < 1024 or self.port > 65535:
            errors.append(f"invalid port: {{self.port}} (must be 1024-65535)")
        if self.tier not in AGENT_TIERS:
            errors.append(f"invalid tier: {{self.tier}} (must be one of {{list(AGENT_TIERS.keys())}})")
        else:
            required = TIER_REQUIREMENTS.get(self.tier, [])
            for req_field in required:
                if not getattr(self, req_field, None):
                    errors.append(f"{{req_field}} is required for tier '{{self.tier}}'")
        if self.max_concurrent_tasks < 1:
            errors.append("max_concurrent_tasks must be >= 1")
        return errors

    def to_dict(self) -> Dict[str, Any]:
        """Serialize configuration to dict."""
        return asdict(self)


def generate_agent_card(config: {class_name}AgentConfig) -> Dict[str, Any]:
    """Generate a /.well-known/agent.json card from config.

    Creates an A2A-compliant agent card that other agents use
    to discover capabilities and establish communication.

    Args:
        config: Agent configuration.

    Returns:
        Agent card dict suitable for serving at /.well-known/agent.json.

    Raises:
        ValueError: If config validation fails.
    """
    errors = config.validate()
    if errors:
        raise ValueError(f"Invalid config: {{'; '.join(errors)}}")

    card = {{
        "name": config.name,
        "description": config.description or f"{{config.name}} agent ({{config.tier}} tier)",
        "url": f"https://{{config.name}}:{{config.port}}",
        "version": "1.0.0",
        "protocol": "a2a",
        "protocolVersion": "1.0",
        "tier": config.tier,
        "capabilities": {{
            "streaming": False,
            "pushNotifications": False,
            "maxConcurrentTasks": config.max_concurrent_tasks,
        }},
        "skills": [
            {{
                "id": f"{{config.name}}-{{skill.name}}",
                "name": skill.name,
                "version": skill.version,
                "description": skill.description,
                "keywords": skill.keywords,
                "inputSchema": skill.input_schema or {{
                    "type": "object",
                    "properties": {{
                        "action": {{"type": "string"}},
                    }},
                }},
            }}
            for skill in config.skills
        ],
        "authentication": {{
            "type": "mtls",
            "certificate": config.tls_cert,
        }},
        "health": {{
            "endpoint": config.health_endpoint,
            "interval": "30s",
        }},
        "generated_at": datetime.now(timezone.utc).isoformat() + "Z",
    }}
    return card


def load_config_from_file(config_path: str) -> {class_name}AgentConfig:
    """Load agent configuration from a YAML or JSON file.

    Args:
        config_path: Path to config file (.yaml, .yml, or .json).

    Returns:
        Populated AgentConfig instance.

    Raises:
        FileNotFoundError: If config file doesn't exist.
        ValueError: If file format is unsupported.
    """
    path = Path(config_path)
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {{config_path}}")

    content = path.read_text(encoding="utf-8")

    if path.suffix in (".yaml", ".yml"):
        try:
            import yaml
            data = yaml.safe_load(content)
        except ImportError:
            raise RuntimeError("pyyaml is required for YAML config. Install with: pip install pyyaml")
    elif path.suffix == ".json":
        data = json.loads(content)
    else:
        raise ValueError(f"Unsupported config format: {{path.suffix}} (use .yaml, .yml, or .json)")

    # Build skill configs
    skills = []
    for skill_data in data.get("skills", []):
        skills.append(AgentSkillConfig(**skill_data))

    config = {class_name}AgentConfig(
        name=data.get("name", ""),
        port=data.get("port", 8443),
        tier=data.get("tier", "domain"),
        model_id=data.get("model_id", ""),
        tls_cert=data.get("tls_cert", ""),
        tls_key=data.get("tls_key", ""),
        description=data.get("description", ""),
        skills=skills,
        metadata=data.get("metadata", {{}}),
        health_endpoint=data.get("health_endpoint", "/health"),
        max_concurrent_tasks=data.get("max_concurrent_tasks", 10),
    )

    logger.info(f"Loaded config for agent '{{config.name}}' from {{config_path}}")
    return config


def save_agent_card(config: {class_name}AgentConfig, output_dir: str) -> str:
    """Generate and save agent card to .well-known/agent.json.

    Args:
        config: Agent configuration.
        output_dir: Output directory (agent.json placed in .well-known/).

    Returns:
        Path to the generated agent.json file.
    """
    card = generate_agent_card(config)
    out_path = Path(output_dir) / ".well-known"
    out_path.mkdir(parents=True, exist_ok=True)
    card_file = out_path / "agent.json"
    card_file.write_text(json.dumps(card, indent=2), encoding="utf-8")
    logger.info(f"Agent card saved: {{card_file}}")
    return str(card_file)


# Standalone usage
if __name__ == "__main__":
    config = {class_name}AgentConfig(
        name="example-agent",
        port=8445,
        tier="domain",
        model_id="anthropic.claude-3-sonnet-20240229-v1:0",
        description="Example FORGE agent",
        skills=[
            AgentSkillConfig(
                name="example_skill",
                description="An example skill",
                keywords=["example", "demo"],
            ),
        ],
    )
    card = generate_agent_card(config)
    print(json.dumps(card, indent=2))
'''


# ---------------------------------------------------------------------------
# Phase 19: generate_from_blueprint — batch generation for FORGE child apps
# ---------------------------------------------------------------------------

def generate_from_blueprint(
    project_path: str,
    blueprint: Dict[str, Any],
    language: str = "python",
) -> List[str]:
    """Generate common boilerplate files from a FORGE blueprint.

    Takes a blueprint dict describing a child application and generates:
    - Agent skill handlers for each agent defined in the blueprint
    - An LLM service wrapper
    - A prompt template manager
    - Agent configuration/card modules

    Args:
        project_path: Root path of the project.
        blueprint: Blueprint dict with keys:
            - name (str): Application name
            - agents (list[dict]): Agent definitions with 'name', 'tier', 'port', 'skills'
            - llm_config (dict, optional): LLM configuration overrides
            - templates_dir (str, optional): Path to hardprompt templates
        language: Target language (currently only 'python' for agentic types).

    Returns:
        List of paths to all generated files.
    """
    if language != "python":
        raise ValueError(
            f"Agentic blueprint generation currently supports Python only, got: {language}"
        )

    project = Path(project_path)
    src_dir = project / "src"
    src_dir.mkdir(parents=True, exist_ok=True)

    # Ensure __init__.py
    init_file = src_dir / "__init__.py"
    if not init_file.exists():
        init_file.write_text(f"{CUI_HEADER}\n", encoding="utf-8")

    generated_files: List[str] = []
    app_name = blueprint.get("name", "app")

    # 1. Generate agent skill handlers for each agent
    agents = blueprint.get("agents", [])
    for agent_def in agents:
        agent_name = agent_def.get("name", "agent")
        agent_spec = (
            f"A2A skill handler for {agent_name} agent in {app_name}. "
            f"Tier: {agent_def.get('tier', 'domain')}. "
            f"Skills: {', '.join(s.get('name', '') for s in agent_def.get('skills', []))}"
        )
        code = _generate_agent_skill_code(agent_name, agent_spec)
        filename = f"skill_{_slugify(agent_name)}.py"
        output_file = src_dir / filename
        output_file.write_text(code, encoding="utf-8")
        generated_files.append(str(output_file))
        print(f"Generated [python/agent_skill]: {output_file}")

    # 2. Generate LLM service wrapper
    llm_spec = (
        f"Bedrock LLM service for {app_name}. "
        f"Model: {blueprint.get('llm_config', {}).get('model_id', 'default')}."
    )
    code = _generate_llm_service_code(app_name, llm_spec)
    filename = f"llm_service_{_slugify(app_name)}.py"
    output_file = src_dir / filename
    output_file.write_text(code, encoding="utf-8")
    generated_files.append(str(output_file))
    print(f"Generated [python/llm_service]: {output_file}")

    # 3. Generate prompt template manager
    tmpl_spec = f"Hardprompt template manager for {app_name}."
    code = _generate_prompt_template_code(app_name, tmpl_spec)
    filename = f"prompt_manager_{_slugify(app_name)}.py"
    output_file = src_dir / filename
    output_file.write_text(code, encoding="utf-8")
    generated_files.append(str(output_file))
    print(f"Generated [python/prompt_template]: {output_file}")

    # 4. Generate agent config/card modules for each agent
    for agent_def in agents:
        agent_name = agent_def.get("name", "agent")
        config_spec = (
            f"Agent config and card for {agent_name} in {app_name}. "
            f"Port: {agent_def.get('port', 8443)}. Tier: {agent_def.get('tier', 'domain')}."
        )
        code = _generate_model_config_code(agent_name, config_spec)
        filename = f"config_{_slugify(agent_name)}.py"
        output_file = src_dir / filename
        output_file.write_text(code, encoding="utf-8")
        generated_files.append(str(output_file))
        print(f"Generated [python/model_config]: {output_file}")

    # Log audit trail
    _log_audit(project_path, generated_files, f"Blueprint generation for {app_name}")

    return generated_files


def _generate_mosa_interface_code(entity: str, spec: str) -> str:
    """Generate MOSA interface module: abstract interface + concrete implementation.

    Creates:
    - Abstract interface class (ABC) with method stubs
    - Concrete implementation skeleton
    - Interface test stub
    - OpenAPI stub reference comment
    """
    entity_title = entity.replace("_", " ").title().replace(" ", "")
    return f'''#!/usr/bin/env python3
# CUI // SP-CTI
"""MOSA Interface: {entity_title}

Auto-generated MOSA interface contract.
Specification: {spec}

MOSA Compliance:
    - MOSA-ARCH-1: Module boundary definition (ABC interface)
    - MOSA-INT-1: Interface control document required
    - MOSA-INT-2: Semantic versioning enforced
    - MOSA-STD-2: OpenAPI spec recommended for REST interfaces
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, List, Optional


# --- Interface Contract ---

class I{entity_title}(ABC):
    """Abstract interface for {entity_title}.

    All consumers MUST use this interface, not the concrete implementation.
    This ensures MOSA loose coupling (MOSA-ARCH-2) and replaceability (MOSA-CS-1).
    """

    @abstractmethod
    def get(self, resource_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve a resource by ID."""
        ...

    @abstractmethod
    def list_all(self, filters: Optional[Dict] = None) -> List[Dict[str, Any]]:
        """List resources with optional filters."""
        ...

    @abstractmethod
    def create(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new resource."""
        ...

    @abstractmethod
    def update(self, resource_id: str, data: Dict[str, Any]) -> Dict[str, Any]:
        """Update an existing resource."""
        ...

    @abstractmethod
    def delete(self, resource_id: str) -> bool:
        """Delete a resource by ID."""
        ...


# --- Data Transfer Objects ---

@dataclass
class {entity_title}Request:
    """Request DTO for {entity_title} operations."""
    data: Dict[str, Any]
    request_id: Optional[str] = None


@dataclass
class {entity_title}Response:
    """Response DTO for {entity_title} operations."""
    success: bool
    data: Optional[Dict[str, Any]] = None
    error: Optional[str] = None


# --- Concrete Implementation ---

class {entity_title}Impl(I{entity_title}):
    """Concrete implementation of I{entity_title}.

    This implementation can be swapped out for an alternative (MOSA-CS-1)
    as long as the replacement implements I{entity_title}.
    """

    def __init__(self):
        self._store: Dict[str, Dict] = {{}}

    def get(self, resource_id: str) -> Optional[Dict[str, Any]]:
        return self._store.get(resource_id)

    def list_all(self, filters: Optional[Dict] = None) -> List[Dict[str, Any]]:
        items = list(self._store.values())
        if filters:
            for key, val in filters.items():
                items = [i for i in items if i.get(key) == val]
        return items

    def create(self, data: Dict[str, Any]) -> Dict[str, Any]:
        import uuid
        rid = str(uuid.uuid4())
        record = {{"id": rid, **data}}
        self._store[rid] = record
        return record

    def update(self, resource_id: str, data: Dict[str, Any]) -> Dict[str, Any]:
        if resource_id not in self._store:
            raise KeyError(f"Resource {{resource_id}} not found")
        self._store[resource_id].update(data)
        return self._store[resource_id]

    def delete(self, resource_id: str) -> bool:
        if resource_id in self._store:
            del self._store[resource_id]
            return True
        return False


# --- Interface Version ---
INTERFACE_VERSION = "1.0.0"
# See docs/icd/{entity}_icd.md for full Interface Control Document
# See openapi/{entity}_openapi.yaml for OpenAPI specification
'''


# Template dispatch table (Python — original + Phase 19 agentic + Phase 26 MOSA)
_GENERATORS = {
    "api": _generate_api_code,
    "model": _generate_model_code,
    "service": _generate_service_code,
    "cli": _generate_cli_code,
    "utility": _generate_module_code,
    "middleware": _generate_module_code,
    "config": _generate_module_code,
    "module": _generate_module_code,
    # Phase 19: Agentic spec types
    "agent_skill": _generate_agent_skill_code,
    "llm_service": _generate_llm_service_code,
    "prompt_template": _generate_prompt_template_code,
    "agent_collaboration": _generate_agent_collaboration_code,
    "model_config": _generate_model_config_code,
    # Phase 26: MOSA interface
    "mosa_interface": _generate_mosa_interface_code,
}

# Language-specific generator dispatch tables
LANGUAGE_GENERATORS = {
    "python": _GENERATORS,
    "java": {
        "api": _generate_java_api_code,
        "model": _generate_java_model_code,
        "service": _generate_java_service_code,
    },
    "go": {
        "api": _generate_go_api_code,
        "model": _generate_go_model_code,
        "service": _generate_go_service_code,
    },
    "typescript": {
        "api": _generate_typescript_api_code,
        "model": _generate_typescript_model_code,
        "service": _generate_typescript_service_code,
    },
    "rust": {
        "api": _generate_rust_api_code,
        "model": _generate_rust_model_code,
        "service": _generate_rust_service_code,
    },
    "csharp": {
        "api": _generate_csharp_api_code,
        "model": _generate_csharp_model_code,
        "service": _generate_csharp_service_code,
    },
}


# File extension mapping per language
_LANGUAGE_EXTENSIONS = {
    "python": ".py",
    "java": ".java",
    "go": ".go",
    "typescript": ".ts",
    "rust": ".rs",
    "csharp": ".cs",
}


def generate_from_spec(
    project_path: str,
    spec: str,
    output_dir: Optional[str] = None,
    force_type: Optional[str] = None,
    language: str = "python",
    project_id: Optional[str] = None,
    secure: bool = True,
) -> List[str]:
    """Generate implementation code from a specification.

    Args:
        project_path: Root path of the project.
        spec: Specification text describing what to generate.
        output_dir: Optional output directory (defaults to {project}/src/).
        force_type: Force a specific code type (api, model, service, cli, module).
        language: Target language (python, java, go, typescript, rust, csharp).
        project_id: Optional project ID for dev profile injection (Phase 34, D187).
        secure: Include auth decorators and input validation (D-EPSEC-5).
                Default True. Use --no-auth CLI flag to disable.

    Returns:
        List of paths to generated files.
    """
    # Phase 34: Build profile context for LLM-aware generation
    profile_context = ""
    if project_id:
        profile_context = _build_profile_context(project_id, "code_generation")
    project = Path(project_path)
    src_dir = Path(output_dir) if output_dir else project / "src"
    src_dir.mkdir(parents=True, exist_ok=True)

    # Ensure __init__.py exists for Python projects
    if language == "python":
        init_file = src_dir / "__init__.py"
        if not init_file.exists():
            init_file.write_text(f"{CUI_HEADER}\n", encoding="utf-8")

    # Detect code type and entity
    code_type = force_type or _detect_spec_type(spec)
    entity = _extract_entity_name(spec)

    # Get language-specific generators
    lang_generators = LANGUAGE_GENERATORS.get(language)
    if not lang_generators:
        raise ValueError(
            f"Unsupported language: {language}. "
            f"Supported: {', '.join(LANGUAGE_GENERATORS.keys())}"
        )

    # Find the generator for this code type
    generator = lang_generators.get(code_type)
    if not generator:
        # Fall back to module/generic generator if available, or error
        generator = lang_generators.get("module")
        if not generator:
            available = ", ".join(lang_generators.keys())
            raise ValueError(
                f"No '{code_type}' generator for language '{language}'. "
                f"Available types for {language}: {available}"
            )

    # Pass secure flag to API generators (D-EPSEC-5)
    import inspect
    if "secure" in inspect.signature(generator).parameters:
        code = generator(entity, spec, secure=secure)
    else:
        code = generator(entity, spec)

    # Write the file with appropriate extension
    ext = _LANGUAGE_EXTENSIONS.get(language, ".py")
    filename = f"{_slugify(entity)}{ext}"
    output_file = src_dir / filename
    output_file.write_text(code, encoding="utf-8")

    generated_files = [str(output_file)]
    print(f"Generated [{language}/{code_type}]: {output_file}")

    # Log audit trail
    _log_audit(project_path, generated_files, spec)

    return generated_files


def _log_audit(project_path: str, files: List[str], spec: str) -> None:
    """Log code generation to the audit trail."""
    try:
        conn = sqlite3.connect(str(DB_PATH))
        c = conn.cursor()
        c.execute(
            """INSERT INTO audit_trail (project_id, event_type, actor, action, details, affected_files, classification)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (
                None,
                "code_generated",
                "builder/code_generator",
                f"Generated code from spec: {spec[:100]}",
                json.dumps({"spec": spec}),
                json.dumps(files),
                "CUI",
            ),
        )
        conn.commit()
        conn.close()
    except Exception as e:
        print(f"Warning: audit logging failed: {e}")


def main():
    parser = argparse.ArgumentParser(description="Generate implementation code from specifications")
    parser.add_argument("--project-path", required=True, help="Root path of the project")
    parser.add_argument("--spec", required=True, help="Specification text")
    parser.add_argument("--output-dir", help="Output directory (defaults to {project}/src/)")
    parser.add_argument(
        "--type",
        choices=[
            "api", "model", "service", "cli", "utility", "middleware", "config", "module",
            "agent_skill", "llm_service", "prompt_template", "agent_collaboration", "model_config",
        ],
        help="Force a specific code type",
    )
    parser.add_argument(
        "--language", default="python",
        choices=["python", "java", "go", "typescript", "csharp", "rust"],
        help="Target language for code generation (default: python)",
    )
    parser.add_argument(
        "--project-id", default=None,
        help="Project ID for dev profile injection (Phase 34, D187)",
    )
    parser.add_argument(
        "--no-auth", action="store_true",
        help="Disable auth decorators and validation in generated API code (D-EPSEC-5). "
             "WARNING: Generated code will fail endpoint_security gate.",
    )
    args = parser.parse_args()

    files = generate_from_spec(
        project_path=args.project_path,
        spec=args.spec,
        output_dir=args.output_dir,
        force_type=args.type,
        language=args.language,
        project_id=args.project_id,
        secure=not args.no_auth,
    )
    print(f"\nGenerated {len(files)} file(s) [{args.language}]:")
    for f in files:
        print(f"  {f}")


if __name__ == "__main__":
    main()
