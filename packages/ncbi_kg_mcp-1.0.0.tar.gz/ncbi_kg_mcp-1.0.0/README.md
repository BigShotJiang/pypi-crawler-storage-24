# ncbi-kg-mcp

MCP server for the [NCBI Knowledge Graph](https://github.com/monideep2255/ncbi_ai_agents) - a BioLink-compliant glucose metabolism graph with 82,517 nodes and 263,404 edges. Query genes, diseases, variants, proteins, pathways, and more from any LLM.

## Install

```bash
pip install ncbi-kg-mcp
```

## Configure

Add to your `.mcp.json` (Claude Code, Cursor, Cline, etc.):

```json
{
  "mcpServers": {
    "ncbi-kg": {
      "command": "ncbi-kg-mcp"
    }
  }
}
```

That's it. No API keys, no database credentials, no repo cloning needed.

## Tools (5)

| Tool | Input | Description |
|------|-------|-------------|
| `query` | `question: str` | Ask a natural language question - auto-translated to Cypher |
| `cypher` | `query_text: str` | Run a read-only Cypher query directly |
| `get_stats` | None | Get node and edge counts by type |
| `get_schema` | None | Get graph schema - node types, relationships, patterns |
| `get_neighbors` | `node_id: str` | Get 1-hop neighbors of a node (e.g., "NCBIGene:2645") |

## Example

Ask your LLM: *"What genes are associated with MODY?"*

The LLM calls the `query` tool, which translates to Cypher, executes against Neo4j, and returns a synthesized answer with raw data.

## Graph Data

- **8 node types**: Gene, Disease, SequenceVariant, BiologicalProcess, MolecularActivity, Protein, CellularComponent, Pathway
- **15 relationship types**: GENE_ASSOCIATED_WITH_CONDITION, IS_SEQUENCE_VARIANT_OF, CAUSES, INVOLVED_IN, ENABLES, and more
- **Sources**: NCBI Gene, ClinVar, MedGen, MONDO, GO, UniProt, Reactome

## Configuration

| Env Variable | Default | Description |
|-------------|---------|-------------|
| `NCBI_KG_API_URL` | `https://ncbi-kg-api-production.up.railway.app` | API base URL |

Override the API URL to point to a local backend:

```json
{
  "mcpServers": {
    "ncbi-kg": {
      "command": "ncbi-kg-mcp",
      "env": {"NCBI_KG_API_URL": "http://localhost:8001"}
    }
  }
}
```

## Links

- [Full documentation](https://github.com/monideep2255/ncbi_ai_agents/blob/ncbi-kg/AGENTS_EXTERNAL.md)
- [REST API reference](https://github.com/monideep2255/ncbi_ai_agents/blob/ncbi-kg/KG/PoC/documents/API_REFERENCE.md)
- [Live API docs](https://ncbi-kg-api-production.up.railway.app/docs)
