"""Allow running as: python -m ncbi_kg_mcp"""

from ncbi_kg_mcp.server import run

run()
