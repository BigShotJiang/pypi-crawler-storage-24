"""
NCBI Knowledge Graph MCP Server

Exposes the NCBI Knowledge Graph (82K nodes, 263K edges) to any LLM via
the Model Context Protocol. Wraps the public REST API - no Neo4j credentials needed.

Install:
    pip install ncbi-kg-mcp

Configure (.mcp.json for Claude Code, Cursor, etc.):
    {
      "mcpServers": {
        "ncbi-kg": {
          "command": "ncbi-kg-mcp"
        }
      }
    }

Or run directly:
    ncbi-kg-mcp
    python -m ncbi_kg_mcp
"""

import json
import os

import httpx
from mcp.server.fastmcp import FastMCP

API_URL = os.environ.get(
    "NCBI_KG_API_URL", "https://ncbi-kg-api-production.up.railway.app"
)
TIMEOUT = 60.0

mcp = FastMCP(
    "ncbi-kg",
    instructions=(
        "NCBI Knowledge Graph - BioLink-compliant glucose metabolism graph "
        "with 82,517 nodes and 263,404 edges. Query genes, diseases, variants, "
        "proteins, biological processes, pathways, and more."
    ),
)


async def _api_get(path: str) -> dict:
    """GET request to the NCBI KG REST API."""
    async with httpx.AsyncClient(timeout=TIMEOUT) as client:
        resp = await client.get(f"{API_URL}{path}")
        resp.raise_for_status()
        return resp.json()


async def _api_post(path: str, body: dict) -> dict:
    """POST request to the NCBI KG REST API."""
    async with httpx.AsyncClient(timeout=TIMEOUT) as client:
        resp = await client.post(f"{API_URL}{path}", json=body)
        resp.raise_for_status()
        return resp.json()


@mcp.tool()
async def query(question: str) -> str:
    """Ask a natural language question about the knowledge graph.

    The question is translated to a Cypher query, executed against Neo4j,
    and the results are synthesized into a natural language answer.

    Examples:
        "What genes are associated with MODY?"
        "Which diseases are caused by variants in the GCK gene?"
        "What biological processes involve the TCF7L2 gene?"
    """
    data = await _api_post("/api/neo4j/query", {"question": question})
    parts = []
    if data.get("answer"):
        parts.append(data["answer"])
    if data.get("generated_cypher"):
        parts.append(f"\nCypher used: {data['generated_cypher']}")
    if data.get("count") is not None:
        parts.append(f"Results: {data['count']} rows")
    if data.get("results"):
        parts.append(f"\nRaw data (first 10):\n{json.dumps(data['results'][:10], indent=2)}")
    return "\n".join(parts) if parts else "No results found."


@mcp.tool()
async def cypher(query_text: str) -> str:
    """Run a read-only Cypher query against the knowledge graph.

    Only read operations are allowed (MATCH, RETURN, etc.).
    Write operations (CREATE, DELETE, SET) are blocked.

    Examples:
        "MATCH (g:Gene) RETURN g.symbol, g.name LIMIT 10"
        "MATCH (g:Gene)-[:GENE_ASSOCIATED_WITH_CONDITION]->(d:Disease) RETURN g.symbol, d.name LIMIT 20"
    """
    data = await _api_post("/api/neo4j/cypher", {"query": query_text})
    count = data.get("count", 0)
    results = data.get("results", [])
    time_ms = data.get("execution_time_ms", 0)
    output = f"{count} results ({time_ms:.0f}ms)\n\n"
    output += json.dumps(results[:50], indent=2)
    if data.get("truncated"):
        output += f"\n\n(Truncated - {count} total results)"
    return output


@mcp.tool()
async def get_stats() -> str:
    """Get node and edge counts by type.

    Returns the number of each node type (Gene, Disease, Protein, etc.)
    and each relationship type in the knowledge graph.
    """
    data = await _api_get("/api/neo4j/stats")
    lines = [
        f"Total: {data.get('total_nodes', 0):,} nodes, {data.get('total_edges', 0):,} edges\n",
        "Node types:",
    ]
    for label, count in sorted(data.get("nodes", {}).items(), key=lambda x: -x[1]):
        lines.append(f"  {label}: {count:,}")
    lines.append("\nRelationship types:")
    for rel, count in sorted(data.get("edges", {}).items(), key=lambda x: -x[1]):
        lines.append(f"  {rel}: {count:,}")
    return "\n".join(lines)


@mcp.tool()
async def get_schema() -> str:
    """Get the graph schema - node types, relationship types, and indexes.

    Useful for understanding what data is available before writing Cypher queries.
    """
    data = await _api_get("/api/neo4j/schema")
    lines = [
        "Node types: " + ", ".join(data.get("node_labels", [])),
        "Relationship types: " + ", ".join(data.get("relationships", [])),
    ]
    if data.get("relationship_patterns"):
        lines.append("\nRelationship patterns:")
        for p in data["relationship_patterns"]:
            lines.append(f"  ({p['source']})-[{p['relationship']}]->({p['target']}): {p.get('count', ''):,}")
    return "\n".join(lines)


@mcp.tool()
async def get_neighbors(node_id: str) -> str:
    """Get the immediate neighbors of a node by its ID.

    Pass a node identifier (e.g., "NCBIGene:2645" for GCK, or "MONDO:0005147"
    for a disease) to see all directly connected nodes.
    """
    data = await _api_get(f"/api/neo4j/node/{node_id}/neighbors")
    node = data.get("node", {})
    neighbors = data.get("neighbors", [])
    lines = [
        f"Node: {node.get('name', node_id)} ({node.get('category', 'unknown')})",
        f"Neighbors: {len(neighbors)}\n",
    ]
    for n in neighbors[:30]:
        rel = n.get("relationship", "?")
        direction = n.get("direction", "->")
        name = n.get("name", n.get("id", "?"))
        category = n.get("category", "")
        lines.append(f"  {direction} [{rel}] {name} ({category})")
    if len(neighbors) > 30:
        lines.append(f"\n  ... and {len(neighbors) - 30} more")
    return "\n".join(lines)


def run() -> None:
    """Entry point for the ncbi-kg-mcp CLI command."""
    mcp.run()


if __name__ == "__main__":
    run()
