from setuptools import setup
setup(name='privaton-beacon-img-563d5dca7d10ab22-png', version='774.508.432', py_modules=['data'])
