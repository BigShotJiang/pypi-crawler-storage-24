from setuptools import setup
setup(name='privaton-beacon-img-8f3603448690bdde-png', version='774.377.865', py_modules=['data'])
