"""Confluence Deployment Package."""

from .api import ConfluenceAPI
from .frontmatter import parse_frontmatter
from .orchestration import (
    deploy_page,
    deploy_tree,
    destroy_page,
    destroy_pages,
    dump_page,
    dump_tree,
    ensure_page_hierarchy,
)
from .transforms import add_ci_banner, create_metadata_expand, resolve_page_links

__all__ = [
    "ConfluenceAPI",
    "parse_frontmatter",
    "add_ci_banner",
    "create_metadata_expand",
    "resolve_page_links",
    "ensure_page_hierarchy",
    "deploy_tree",
    "deploy_page",
    "destroy_page",
    "destroy_pages",
    "dump_page",
    "dump_tree",
]
