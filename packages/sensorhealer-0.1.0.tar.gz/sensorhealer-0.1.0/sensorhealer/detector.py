import numpy as np

def detect(series):

    mean = np.nanmean(series)
    std = np.nanstd(series)

    status = []

    for v in series:

        if np.isnan(v):
            status.append("missing")

        elif abs(v - mean) > 3*std:
            status.append("outlier")

        else:
            status.append("normal")

    return status