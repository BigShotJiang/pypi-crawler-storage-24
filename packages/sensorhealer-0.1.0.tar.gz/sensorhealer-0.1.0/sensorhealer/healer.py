import numpy as np
import pandas as pd

def heal(df, columns, window=5):

    result = df.copy()

    for col in columns:

        series = df[col].values.copy()

        healed = series.copy()
        confidence = np.ones(len(series))

        global_std = np.nanstd(series)

        for i in range(len(series)):

            if np.isnan(series[i]):

                start = max(0, i-window)

                prev = healed[start:i]
                valid = prev[~np.isnan(prev)]

                if len(valid) > 0:
                    local_mean = np.mean(valid)
                    local_var = np.var(valid)
                else:
                    local_mean = np.nanmean(series)
                    local_var = global_std

                healed_value = local_mean + (0.2 * global_std)

                healed[i] = healed_value
                confidence[i] = 1 / (1 + local_var)

        result[f"{col}_healed"] = healed
        result[f"{col}_confidence"] = confidence

    return result