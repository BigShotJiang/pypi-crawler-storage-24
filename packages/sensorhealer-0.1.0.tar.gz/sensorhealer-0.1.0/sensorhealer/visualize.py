import matplotlib.pyplot as plt

def plot(df, columns):

    for col in columns:

        healed_col = f"{col}_healed"

        plt.figure(figsize=(10,5))

        plt.plot(df[col], label="original", alpha=0.7)

        if healed_col in df.columns:
            plt.plot(df[healed_col],
                     linestyle="--",
                     label="healed")

        plt.title(f"Sensor Data Healing: {col}")
        plt.xlabel("time")
        plt.ylabel(col)

        plt.legend()
        plt.grid(True)

        plt.show()