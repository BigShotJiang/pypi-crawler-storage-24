// ============================================================================
// CoreArray: Rust-Native Array with 64-byte Aligned Memory
// ============================================================================
//
// This is the primary backing store for corepy.ndarray, replacing NumPy.
// Memory is 64-byte aligned for optimal SIMD (AVX-512 = 64-byte registers).
//
// Ownership model:
// - Rust owns the heap allocation via AlignedBuffer
// - Python holds an Arc<CoreArray> via PyO3
// - to_numpy() creates a zero-copy view (or copy if needed)

use pyo3::prelude::*;
use std::alloc::{self, Layout};
use std::ptr;

use super::dtype::DType;

const ALIGNMENT: usize = 64; // Cache-line + AVX-512 friendly

/// A raw buffer with guaranteed 64-byte alignment.
/// This is the memory backbone of CoreArray.
struct AlignedBuffer {
    ptr: *mut u8,
    layout: Layout,
}

impl AlignedBuffer {
    /// Allocate `size` bytes with 64-byte alignment, zero-initialized.
    fn new(size: usize) -> Self {
        if size == 0 {
            return AlignedBuffer {
                ptr: ptr::null_mut(),
                layout: Layout::from_size_align(0, ALIGNMENT).unwrap(),
            };
        }
        let layout = Layout::from_size_align(size, ALIGNMENT)
            .expect("Invalid layout for aligned allocation");
        // SAFETY: layout has non-zero size and valid alignment
        let ptr = unsafe { alloc::alloc_zeroed(layout) };
        if ptr.is_null() {
            alloc::handle_alloc_error(layout);
        }
        AlignedBuffer { ptr, layout }
    }

    fn clone(&self) -> Self {
        let new_buf = AlignedBuffer::new(self.len());
        if self.len() > 0 {
            unsafe {
                ptr::copy_nonoverlapping(self.ptr, new_buf.ptr, self.len());
            }
        }
        new_buf
    }

    fn as_ptr(&self) -> *const u8 {
        self.ptr as *const u8
    }

    fn as_mut_ptr(&self) -> *mut u8 {
        self.ptr
    }

    fn len(&self) -> usize {
        self.layout.size()
    }
}

impl Drop for AlignedBuffer {
    fn drop(&mut self) {
        if !self.ptr.is_null() && self.layout.size() > 0 {
            // SAFETY: ptr was allocated with this layout
            unsafe { alloc::dealloc(self.ptr, self.layout) };
        }
    }
}

// SAFETY: The buffer is an owned heap allocation, safe to send across threads.
unsafe impl Send for AlignedBuffer {}
unsafe impl Sync for AlignedBuffer {}

// ============================================================================
// CoreArray
// ============================================================================

/// Rust-native array. Primary backing store for corepy arrays.
///
/// Features:
/// - 64-byte aligned memory (SIMD-optimal)
/// - C-contiguous row-major layout
/// - Zero-copy pointer exposure for FFI
/// - PyO3-exposed for direct Python access
#[pyclass(from_py_object)]
pub struct CoreArray {
    buffer: AlignedBuffer,
    shape: Vec<usize>,
    strides: Vec<usize>, // byte strides
    dtype: DType,
}

impl Clone for CoreArray {
    fn clone(&self) -> Self {
        CoreArray {
            buffer: self.buffer.clone(),
            shape: self.shape.clone(),
            strides: self.strides.clone(),
            dtype: self.dtype,
        }
    }
}

impl std::fmt::Debug for CoreArray {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.__repr__())
    }
}

#[allow(clippy::useless_conversion)]
#[pymethods]
impl CoreArray {
    /// Create a new array from a flat list of f32 values and a shape.
    #[new]
    #[pyo3(signature = (data, shape))]
    pub fn new(data: Vec<f32>, shape: Vec<usize>) -> PyResult<Self> {
        let expected_count: usize = shape.iter().product();
        if data.len() != expected_count {
            return Err(pyo3::exceptions::PyValueError::new_err(format!(
                "Data length {} does not match shape {:?} (expected {})",
                data.len(),
                shape,
                expected_count
            )));
        }

        let byte_len = expected_count * std::mem::size_of::<f32>();
        let buffer = AlignedBuffer::new(byte_len);

        // Copy data into aligned buffer
        // SAFETY: buffer is freshly allocated with correct size
        unsafe {
            ptr::copy_nonoverlapping(data.as_ptr() as *const u8, buffer.as_mut_ptr(), byte_len);
        }

        let strides = Self::compute_c_strides(&shape, std::mem::size_of::<f32>());

        Ok(CoreArray {
            buffer,
            shape,
            strides,
            dtype: DType::Float32,
        })
    }

    /// Raw pointer to the data buffer (for FFI).
    #[getter]
    pub fn data_ptr(&self) -> usize {
        self.buffer.as_ptr() as usize
    }

    /// Shape of the array.
    #[getter]
    pub fn shape(&self) -> Vec<usize> {
        self.shape.clone()
    }

    /// Byte strides of the array.
    #[getter]
    pub fn strides(&self) -> Vec<usize> {
        self.strides.clone()
    }

    /// Data type of the array.
    #[getter]
    pub fn dtype(&self) -> DType {
        self.dtype
    }

    /// Number of dimensions.
    #[getter]
    pub fn ndim(&self) -> usize {
        self.shape.len()
    }

    /// Total number of elements.
    #[getter]
    pub fn element_count(&self) -> usize {
        self.shape.iter().product()
    }

    /// Total size in bytes.
    #[getter]
    pub fn nbytes(&self) -> usize {
        self.buffer.len()
    }

    /// Whether the array is C-contiguous.
    pub fn is_contiguous(&self) -> bool {
        let expected = Self::compute_c_strides(&self.shape, self.dtype.itemsize());
        self.strides == expected
    }

    /// Return the data as a flat list of f32 values (for Python interop).
    pub fn to_list(&self) -> PyResult<Vec<f32>> {
        if self.dtype != DType::Float32 {
            return Err(pyo3::exceptions::PyTypeError::new_err(
                "to_list() currently only supports Float32",
            ));
        }
        let count = self.element_count();
        let slice =
            unsafe { std::slice::from_raw_parts(self.buffer.as_ptr() as *const f32, count) };
        Ok(slice.to_vec())
    }

    /// Create a array filled with zeros.
    #[staticmethod]
    #[pyo3(signature = (shape, dtype=None))]
    pub fn zeros(shape: Vec<usize>, dtype: Option<DType>) -> PyResult<Self> {
        let dt = dtype.unwrap_or(DType::Float32);
        let count: usize = shape.iter().product();
        let byte_len = count * dt.itemsize();
        let buffer = AlignedBuffer::new(byte_len); // alloc_zeroed
        let strides = Self::compute_c_strides(&shape, dt.itemsize());

        Ok(CoreArray {
            buffer,
            shape,
            strides,
            dtype: dt,
        })
    }

    /// Create a array filled with ones (f32).
    #[staticmethod]
    #[pyo3(signature = (shape))]
    pub fn ones(shape: Vec<usize>) -> PyResult<Self> {
        let count: usize = shape.iter().product();
        let data = vec![1.0f32; count];
        CoreArray::new(data, shape)
    }

    /// Create a array filled with a constant value.
    #[staticmethod]
    #[pyo3(signature = (shape, value))]
    pub fn full(shape: Vec<usize>, value: f32) -> PyResult<Self> {
        let count: usize = shape.iter().product();
        let data = vec![value; count];
        CoreArray::new(data, shape)
    }

    /// Create a array with evenly spaced values: [start, start+step, ...).
    #[staticmethod]
    #[pyo3(signature = (start, stop, step=None))]
    pub fn arange(start: f32, stop: f32, step: Option<f32>) -> PyResult<Self> {
        let s = step.unwrap_or(1.0);
        if s == 0.0 {
            return Err(pyo3::exceptions::PyValueError::new_err(
                "arange step cannot be zero",
            ));
        }
        let mut data = Vec::new();
        let mut val = start;
        if s > 0.0 {
            while val < stop {
                data.push(val);
                val += s;
            }
        } else {
            while val > stop {
                data.push(val);
                val += s;
            }
        }
        let count = data.len();
        CoreArray::new(data, vec![count])
    }

    /// Concatenate multiple arrays along axis 0.
    #[staticmethod]
    #[pyo3(signature = (arrays))]
    pub fn concatenate(arrays: Vec<pyo3::PyRef<'_, CoreArray>>) -> PyResult<Self> {
        if arrays.is_empty() {
            return Err(pyo3::exceptions::PyValueError::new_err(
                "need at least one array to concatenate",
            ));
        }

        // Validate all have same dtype and compatible shapes
        let dtype = arrays[0].dtype;
        if dtype != DType::Float32 {
            return Err(pyo3::exceptions::PyTypeError::new_err(
                "concatenate() currently only supports Float32",
            ));
        }

        // For 1D: just concatenate data
        if arrays[0].shape.len() == 1 {
            let mut all_data = Vec::new();
            for t in &arrays {
                let slice = unsafe { t.as_f32_slice() };
                all_data.extend_from_slice(slice);
            }
            let count = all_data.len();
            return CoreArray::new(all_data, vec![count]);
        }

        // For ND: validate inner dimensions match, sum first dim
        let inner_shape = &arrays[0].shape[1..];
        let mut total_first_dim = 0usize;
        for t in &arrays {
            if t.shape[1..] != *inner_shape {
                return Err(pyo3::exceptions::PyValueError::new_err(format!(
                    "incompatible shapes for concatenation: {:?} vs {:?}",
                    arrays[0].shape, t.shape
                )));
            }
            total_first_dim += t.shape[0];
        }

        let mut all_data = Vec::new();
        for t in &arrays {
            let slice = unsafe { t.as_f32_slice() };
            all_data.extend_from_slice(slice);
        }

        let mut new_shape = vec![total_first_dim];
        new_shape.extend_from_slice(inner_shape);
        CoreArray::new(all_data, new_shape)
    }

    // =========================================================================
    // Element-wise Operations (Phase 3)
    // =========================================================================

    /// Element-wise addition: self + other → new CoreArray
    pub fn add(&self, other: &CoreArray) -> PyResult<Self> {
        self.elementwise_binop(other, |a, b| a + b, "add")
    }

    /// Element-wise subtraction: self - other → new CoreArray
    pub fn sub(&self, other: &CoreArray) -> PyResult<Self> {
        self.elementwise_binop(other, |a, b| a - b, "sub")
    }

    /// Element-wise multiplication: self * other → new CoreArray
    pub fn mul(&self, other: &CoreArray) -> PyResult<Self> {
        self.elementwise_binop(other, |a, b| a * b, "mul")
    }

    /// Element-wise division: self / other → new CoreArray
    pub fn div(&self, other: &CoreArray) -> PyResult<Self> {
        self.elementwise_binop(other, |a, b| a / b, "div")
    }

    /// Sum all elements.
    pub fn sum(&self) -> PyResult<f32> {
        if self.dtype != DType::Float32 {
            return Err(pyo3::exceptions::PyTypeError::new_err(
                "sum() requires Float32",
            ));
        }
        let slice = unsafe { self.as_f32_slice() };
        Ok(slice.iter().sum())
    }

    /// Mean of all elements.
    pub fn mean(&self) -> PyResult<f32> {
        if self.dtype != DType::Float32 {
            return Err(pyo3::exceptions::PyTypeError::new_err(
                "mean() requires Float32",
            ));
        }
        let slice = unsafe { self.as_f32_slice() };
        let count = slice.len();
        if count == 0 {
            return Err(pyo3::exceptions::PyValueError::new_err(
                "mean of empty array",
            ));
        }
        Ok(slice.iter().sum::<f32>() / count as f32)
    }

    // =========================================================================
    // Comparison Operations (Phase 14) — return Bool arrays
    // =========================================================================

    /// Element-wise equality: self == other → Bool CoreArray
    pub fn eq(&self, other: &CoreArray) -> PyResult<Self> {
        self.elementwise_cmp(other, |a, b| a == b, "eq")
    }

    /// Element-wise not-equal: self != other
    pub fn ne(&self, other: &CoreArray) -> PyResult<Self> {
        self.elementwise_cmp(other, |a, b| a != b, "ne")
    }

    /// Element-wise greater-than: self > other
    pub fn gt(&self, other: &CoreArray) -> PyResult<Self> {
        self.elementwise_cmp(other, |a, b| a > b, "gt")
    }

    /// Element-wise less-than: self < other
    pub fn lt(&self, other: &CoreArray) -> PyResult<Self> {
        self.elementwise_cmp(other, |a, b| a < b, "lt")
    }

    /// Element-wise greater-or-equal: self >= other
    pub fn ge(&self, other: &CoreArray) -> PyResult<Self> {
        self.elementwise_cmp(other, |a, b| a >= b, "ge")
    }

    /// Element-wise less-or-equal: self <= other
    pub fn le(&self, other: &CoreArray) -> PyResult<Self> {
        self.elementwise_cmp(other, |a, b| a <= b, "le")
    }

    // =========================================================================
    // Unary Operations (Phase 15)
    // =========================================================================

    /// Element-wise negation: -self
    pub fn neg(&self) -> PyResult<Self> {
        self.elementwise_unary(|a| -a, "neg")
    }

    /// Element-wise absolute value: |self|
    pub fn abs(&self) -> PyResult<Self> {
        self.elementwise_unary(|a| a.abs(), "abs")
    }

    /// Element-wise square root: sqrt(self)
    pub fn sqrt(&self) -> PyResult<Self> {
        use crate::ops::ufunc::UFunc;
        crate::ops::ufunc::Sqrt.apply(self)
    }

    /// Element-wise exponential: exp(self)
    pub fn exp(&self) -> PyResult<Self> {
        use crate::ops::ufunc::UFunc;
        crate::ops::ufunc::Exp.apply(self)
    }

    /// Element-wise natural logarithm: log(self)
    pub fn log(&self) -> PyResult<Self> {
        use crate::ops::ufunc::UFunc;
        crate::ops::ufunc::Log.apply(self)
    }

    /// Element-wise sine: sin(self)
    pub fn sin(&self) -> PyResult<Self> {
        use crate::ops::ufunc::UFunc;
        crate::ops::ufunc::Sin.apply(self)
    }

    /// Element-wise power: self^exponent (scalar)
    pub fn pow(&self, exponent: f32) -> PyResult<Self> {
        self.elementwise_unary(|a| a.powf(exponent), "pow")
    }

    /// Element-wise power: self^other (array)
    pub fn power(&self, other: &CoreArray) -> PyResult<Self> {
        self.elementwise_binop(other, |a, b| a.powf(b), "power")
    }

    /// Element-wise modulo: self % other
    pub fn mod_op(&self, other: &CoreArray) -> PyResult<Self> {
        self.elementwise_binop(other, |a, b| a % b, "mod")
    }

    /// Element-wise floor division: self // other
    pub fn floor_div(&self, other: &CoreArray) -> PyResult<Self> {
        self.elementwise_binop(other, |a, b| (a / b).floor(), "floor_div")
    }

    // =========================================================================
    // Logical Operations (UFUNC CORE-12)
    // =========================================================================

    /// Element-wise logical AND (0.0 = false, non-zero = true)
    pub fn logical_and(&self, other: &CoreArray) -> PyResult<Self> {
        self.elementwise_binop(
            other,
            |a, b| {
                if a != 0.0 && b != 0.0 {
                    1.0
                } else {
                    0.0
                }
            },
            "logical_and",
        )
    }

    /// Element-wise logical OR
    pub fn logical_or(&self, other: &CoreArray) -> PyResult<Self> {
        self.elementwise_binop(
            other,
            |a, b| {
                if a != 0.0 || b != 0.0 {
                    1.0
                } else {
                    0.0
                }
            },
            "logical_or",
        )
    }

    /// Element-wise logical NOT (unary)
    pub fn logical_not(&self) -> PyResult<Self> {
        self.elementwise_unary(|a| if a == 0.0 { 1.0 } else { 0.0 }, "logical_not")
    }

    /// Element-wise logical XOR
    pub fn logical_xor(&self, other: &CoreArray) -> PyResult<Self> {
        self.elementwise_binop(
            other,
            |a, b| {
                let ab = a != 0.0;
                let bb = b != 0.0;
                if ab ^ bb {
                    1.0
                } else {
                    0.0
                }
            },
            "logical_xor",
        )
    }

    // =========================================================================
    // Sorting Operations (UFUNC CORE-12)
    // =========================================================================

    /// Sort elements in ascending order, returns new sorted array.
    #[pyo3(signature = (descending=false))]
    pub fn sort(&self, descending: bool) -> PyResult<Self> {
        if self.dtype != DType::Float32 {
            return Err(pyo3::exceptions::PyTypeError::new_err(
                "sort() currently only supports Float32",
            ));
        }
        let mut data: Vec<f32> = unsafe { self.as_f32_slice() }.to_vec();
        if data.len() > 100_000 {
            use rayon::prelude::*;
            data.par_sort_unstable_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
        } else {
            data.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
        }
        if descending {
            data.reverse();
        }
        CoreArray::new(data, self.shape.clone())
    }

    /// Return indices that would sort the array.
    #[pyo3(signature = (descending=false))]
    pub fn argsort(&self, descending: bool) -> PyResult<Self> {
        if self.dtype != DType::Float32 {
            return Err(pyo3::exceptions::PyTypeError::new_err(
                "argsort() currently only supports Float32",
            ));
        }
        let slice = unsafe { self.as_f32_slice() };
        let mut indices: Vec<usize> = (0..slice.len()).collect();
        indices.sort_by(|&i, &j| {
            slice[i]
                .partial_cmp(&slice[j])
                .unwrap_or(std::cmp::Ordering::Equal)
        });
        if descending {
            indices.reverse();
        }
        let data: Vec<f32> = indices.iter().map(|&i| i as f32).collect();
        CoreArray::new(data, self.shape.clone())
    }

    // =========================================================================
    // Searching Operations (UFUNC CORE-12)
    // =========================================================================

    /// Return index of maximum element.
    pub fn argmax(&self) -> PyResult<usize> {
        if self.dtype != DType::Float32 {
            return Err(pyo3::exceptions::PyTypeError::new_err(
                "argmax() requires Float32",
            ));
        }
        let slice = unsafe { self.as_f32_slice() };
        if slice.is_empty() {
            return Err(pyo3::exceptions::PyValueError::new_err(
                "argmax of empty array",
            ));
        }
        let mut max_idx = 0;
        let mut max_val = slice[0];
        for (i, &v) in slice.iter().enumerate().skip(1) {
            if v > max_val {
                max_val = v;
                max_idx = i;
            }
        }
        Ok(max_idx)
    }

    /// Return index of minimum element.
    pub fn argmin(&self) -> PyResult<usize> {
        if self.dtype != DType::Float32 {
            return Err(pyo3::exceptions::PyTypeError::new_err(
                "argmin() requires Float32",
            ));
        }
        let slice = unsafe { self.as_f32_slice() };
        if slice.is_empty() {
            return Err(pyo3::exceptions::PyValueError::new_err(
                "argmin of empty array",
            ));
        }
        let mut min_idx = 0;
        let mut min_val = slice[0];
        for (i, &v) in slice.iter().enumerate().skip(1) {
            if v < min_val {
                min_val = v;
                min_idx = i;
            }
        }
        Ok(min_idx)
    }

    // =========================================================================
    // Utility Operations (UFUNC CORE-12)
    // =========================================================================

    /// Element-wise is_even: returns 1.0 where x % 2 == 0, else 0.0
    pub fn is_even(&self) -> PyResult<Self> {
        self.elementwise_unary(|a| if a % 2.0 == 0.0 { 1.0 } else { 0.0 }, "is_even")
    }

    /// Element-wise is_odd: returns 1.0 where x % 2 != 0, else 0.0
    pub fn is_odd(&self) -> PyResult<Self> {
        self.elementwise_unary(|a| if a % 2.0 != 0.0 { 1.0 } else { 0.0 }, "is_odd")
    }

    /// Create evenly spaced values over [start, stop].
    #[staticmethod]
    #[pyo3(signature = (start, stop, num))]
    pub fn linspace(start: f32, stop: f32, num: usize) -> PyResult<Self> {
        if num == 0 {
            return CoreArray::new(vec![], vec![0]);
        }
        if num == 1 {
            return CoreArray::new(vec![start], vec![1]);
        }
        let step = (stop - start) / (num - 1) as f32;
        let data: Vec<f32> = (0..num).map(|i| start + step * i as f32).collect();
        CoreArray::new(data, vec![num])
    }

    // =========================================================================
    // Advanced Indexing (UFUNC CORE-12)
    // =========================================================================

    /// Take elements from array at given indices.
    pub fn take(&self, indices: &CoreArray) -> PyResult<Self> {
        if self.dtype != DType::Float32 || indices.dtype != DType::Float32 {
            return Err(pyo3::exceptions::PyTypeError::new_err(
                "take() currently only supports Float32",
            ));
        }
        let src = unsafe { self.as_f32_slice() };
        let idx_slice = unsafe { indices.as_f32_slice() };
        let mut result = Vec::with_capacity(idx_slice.len());
        for &idx_f in idx_slice {
            let idx = idx_f as usize;
            if idx >= src.len() {
                return Err(pyo3::exceptions::PyIndexError::new_err(format!(
                    "index {} out of bounds for array with {} elements",
                    idx,
                    src.len()
                )));
            }
            result.push(src[idx]);
        }
        CoreArray::new(result, indices.shape.clone())
    }

    /// Select elements where mask is non-zero.
    pub fn boolean_index(&self, mask: &CoreArray) -> PyResult<Self> {
        if self.dtype != DType::Float32 || mask.dtype != DType::Float32 {
            return Err(pyo3::exceptions::PyTypeError::new_err(
                "boolean_index() currently only supports Float32",
            ));
        }
        let src = unsafe { self.as_f32_slice() };
        let mask_slice = unsafe { mask.as_f32_slice() };
        if src.len() != mask_slice.len() {
            return Err(pyo3::exceptions::PyValueError::new_err(format!(
                "boolean_index: array length {} != mask length {}",
                src.len(),
                mask_slice.len()
            )));
        }
        let result: Vec<f32> = src
            .iter()
            .zip(mask_slice.iter())
            .filter(|(_, &m)| m != 0.0)
            .map(|(&v, _)| v)
            .collect();
        let count = result.len();
        CoreArray::new(result, vec![count])
    }

    // =========================================================================
    // Trigonometric Operations (UFUNC CORE-50)
    // =========================================================================

    pub fn cos(&self) -> PyResult<Self> {
        self.elementwise_unary(|a| a.cos(), "cos")
    }
    pub fn tan(&self) -> PyResult<Self> {
        self.elementwise_unary(|a| a.tan(), "tan")
    }
    pub fn arcsin(&self) -> PyResult<Self> {
        self.elementwise_unary(|a| a.asin(), "arcsin")
    }
    pub fn arccos(&self) -> PyResult<Self> {
        self.elementwise_unary(|a| a.acos(), "arccos")
    }
    pub fn arctan(&self) -> PyResult<Self> {
        self.elementwise_unary(|a| a.atan(), "arctan")
    }
    pub fn arctan2(&self, other: &CoreArray) -> PyResult<Self> {
        self.elementwise_binop(other, |a, b| a.atan2(b), "arctan2")
    }

    // =========================================================================
    // Hyperbolic Operations (UFUNC CORE-50)
    // =========================================================================

    pub fn sinh(&self) -> PyResult<Self> {
        self.elementwise_unary(|a| a.sinh(), "sinh")
    }
    pub fn cosh(&self) -> PyResult<Self> {
        self.elementwise_unary(|a| a.cosh(), "cosh")
    }
    pub fn tanh(&self) -> PyResult<Self> {
        self.elementwise_unary(|a| a.tanh(), "tanh")
    }
    pub fn arcsinh(&self) -> PyResult<Self> {
        self.elementwise_unary(|a| a.asinh(), "arcsinh")
    }
    pub fn arccosh(&self) -> PyResult<Self> {
        self.elementwise_unary(|a| a.acosh(), "arccosh")
    }
    pub fn arctanh(&self) -> PyResult<Self> {
        self.elementwise_unary(|a| a.atanh(), "arctanh")
    }

    // =========================================================================
    // Exponential / Logarithmic (UFUNC CORE-50)
    // =========================================================================

    pub fn exp2(&self) -> PyResult<Self> {
        self.elementwise_unary(|a| a.exp2(), "exp2")
    }
    pub fn expm1(&self) -> PyResult<Self> {
        self.elementwise_unary(|a| a.exp() - 1.0, "expm1")
    }
    pub fn log2(&self) -> PyResult<Self> {
        self.elementwise_unary(|a| a.log2(), "log2")
    }
    pub fn log10(&self) -> PyResult<Self> {
        self.elementwise_unary(|a| a.log10(), "log10")
    }
    pub fn log1p(&self) -> PyResult<Self> {
        self.elementwise_unary(|a| (1.0 + a).ln(), "log1p")
    }

    // =========================================================================
    // Rounding Operations (UFUNC CORE-50)
    // =========================================================================

    pub fn floor_op(&self) -> PyResult<Self> {
        self.elementwise_unary(|a| a.floor(), "floor")
    }
    pub fn ceil_op(&self) -> PyResult<Self> {
        self.elementwise_unary(|a| a.ceil(), "ceil")
    }
    pub fn round_op(&self) -> PyResult<Self> {
        self.elementwise_unary(|a| a.round(), "round")
    }
    pub fn trunc_op(&self) -> PyResult<Self> {
        self.elementwise_unary(|a| a.trunc(), "trunc")
    }
    pub fn rint(&self) -> PyResult<Self> {
        // Round to nearest even (banker's rounding)
        self.elementwise_unary(
            |a| {
                let rounded = a.round();
                if (a - rounded).abs() == 0.5 {
                    // Round to even
                    if rounded as i32 % 2 != 0 {
                        rounded - a.signum()
                    } else {
                        rounded
                    }
                } else {
                    rounded
                }
            },
            "rint",
        )
    }

    // =========================================================================
    // Sign / Clip (UFUNC CORE-50)
    // =========================================================================

    pub fn sign_op(&self) -> PyResult<Self> {
        self.elementwise_unary(
            |a| {
                if a > 0.0 {
                    1.0
                } else if a < 0.0 {
                    -1.0
                } else {
                    0.0
                }
            },
            "sign",
        )
    }

    #[pyo3(signature = (min_val, max_val))]
    pub fn clip(&self, min_val: f32, max_val: f32) -> PyResult<Self> {
        self.elementwise_unary(|a| a.max(min_val).min(max_val), "clip")
    }

    pub fn copysign(&self, other: &CoreArray) -> PyResult<Self> {
        self.elementwise_binop(other, |a, b| a.abs() * b.signum(), "copysign")
    }

    // =========================================================================
    // Special Functions (UFUNC CORE-50)
    // =========================================================================

    pub fn square(&self) -> PyResult<Self> {
        self.elementwise_unary(|a| a * a, "square")
    }
    pub fn reciprocal(&self) -> PyResult<Self> {
        self.elementwise_unary(|a| 1.0 / a, "reciprocal")
    }
    pub fn cbrt(&self) -> PyResult<Self> {
        self.elementwise_unary(|a| a.cbrt(), "cbrt")
    }
    pub fn degrees_op(&self) -> PyResult<Self> {
        self.elementwise_unary(|a| a.to_degrees(), "degrees")
    }
    pub fn radians_op(&self) -> PyResult<Self> {
        self.elementwise_unary(|a| a.to_radians(), "radians")
    }
    pub fn hypot(&self, other: &CoreArray) -> PyResult<Self> {
        self.elementwise_binop(other, |a, b| a.hypot(b), "hypot")
    }

    // =========================================================================
    // Bitwise Operations (UFUNC CORE-50) — cast f32→i32 internally
    // =========================================================================

    pub fn bitwise_and(&self, other: &CoreArray) -> PyResult<Self> {
        self.elementwise_binop(
            other,
            |a, b| ((a as i32) & (b as i32)) as f32,
            "bitwise_and",
        )
    }
    pub fn bitwise_or(&self, other: &CoreArray) -> PyResult<Self> {
        self.elementwise_binop(other, |a, b| ((a as i32) | (b as i32)) as f32, "bitwise_or")
    }
    pub fn bitwise_xor(&self, other: &CoreArray) -> PyResult<Self> {
        self.elementwise_binop(
            other,
            |a, b| ((a as i32) ^ (b as i32)) as f32,
            "bitwise_xor",
        )
    }
    pub fn bitwise_not(&self) -> PyResult<Self> {
        self.elementwise_unary(|a| (!(a as i32)) as f32, "bitwise_not")
    }
    pub fn left_shift(&self, other: &CoreArray) -> PyResult<Self> {
        self.elementwise_binop(
            other,
            |a, b| ((a as i32) << (b as i32)) as f32,
            "left_shift",
        )
    }
    pub fn right_shift(&self, other: &CoreArray) -> PyResult<Self> {
        self.elementwise_binop(
            other,
            |a, b| ((a as i32) >> (b as i32)) as f32,
            "right_shift",
        )
    }

    // =========================================================================
    // Reduction Operations (UFUNC CORE-50)
    // =========================================================================

    /// Product of all elements.
    pub fn prod(&self) -> PyResult<f32> {
        let slice = unsafe { self.as_f32_slice() };
        Ok(slice.iter().product())
    }

    /// Population standard deviation.
    pub fn std_dev(&self) -> PyResult<f32> {
        let slice = unsafe { self.as_f32_slice() };
        if slice.is_empty() {
            return Err(pyo3::exceptions::PyValueError::new_err(
                "std of empty array",
            ));
        }
        let n = slice.len() as f32;
        let mean = slice.iter().sum::<f32>() / n;
        let variance = slice.iter().map(|&x| (x - mean) * (x - mean)).sum::<f32>() / n;
        Ok(variance.sqrt())
    }

    /// Population variance.
    pub fn var(&self) -> PyResult<f32> {
        let slice = unsafe { self.as_f32_slice() };
        if slice.is_empty() {
            return Err(pyo3::exceptions::PyValueError::new_err(
                "var of empty array",
            ));
        }
        let n = slice.len() as f32;
        let mean = slice.iter().sum::<f32>() / n;
        Ok(slice.iter().map(|&x| (x - mean) * (x - mean)).sum::<f32>() / n)
    }

    /// Cumulative sum, returns new array.
    pub fn cumsum(&self) -> PyResult<Self> {
        let slice = unsafe { self.as_f32_slice() };
        let mut result = Vec::with_capacity(slice.len());
        let mut acc = 0.0f32;
        for &v in slice {
            acc += v;
            result.push(acc);
        }
        CoreArray::new(result, self.shape.clone())
    }

    /// Cumulative product, returns new array.
    pub fn cumprod(&self) -> PyResult<Self> {
        let slice = unsafe { self.as_f32_slice() };
        let mut result = Vec::with_capacity(slice.len());
        let mut acc = 1.0f32;
        for &v in slice {
            acc *= v;
            result.push(acc);
        }
        CoreArray::new(result, self.shape.clone())
    }

    /// Sum ignoring NaN values.
    pub fn nansum(&self) -> PyResult<f32> {
        let slice = unsafe { self.as_f32_slice() };
        Ok(slice.iter().filter(|x| !x.is_nan()).sum())
    }

    /// Mean ignoring NaN values.
    pub fn nanmean(&self) -> PyResult<f32> {
        let slice = unsafe { self.as_f32_slice() };
        let valid: Vec<f32> = slice.iter().filter(|x| !x.is_nan()).copied().collect();
        if valid.is_empty() {
            return Ok(f32::NAN);
        }
        Ok(valid.iter().sum::<f32>() / valid.len() as f32)
    }

    /// Max ignoring NaN values.
    pub fn nanmax(&self) -> PyResult<f32> {
        let slice = unsafe { self.as_f32_slice() };
        let result = slice
            .iter()
            .filter(|x| !x.is_nan())
            .copied()
            .fold(f32::NEG_INFINITY, f32::max);
        Ok(result)
    }

    /// Min ignoring NaN values.
    pub fn nanmin(&self) -> PyResult<f32> {
        let slice = unsafe { self.as_f32_slice() };
        let result = slice
            .iter()
            .filter(|x| !x.is_nan())
            .copied()
            .fold(f32::INFINITY, f32::min);
        Ok(result)
    }

    // =========================================================================
    // Creation from existing (UFUNC CORE-50)
    // =========================================================================

    /// Create zeros with same shape.
    pub fn zeros_like(&self) -> PyResult<Self> {
        CoreArray::zeros(self.shape.clone(), Some(self.dtype))
    }

    /// Create ones with same shape.
    pub fn ones_like(&self) -> PyResult<Self> {
        let count = self.element_count();
        CoreArray::new(vec![1.0f32; count], self.shape.clone())
    }

    /// Create filled with value, same shape.
    pub fn full_like(&self, value: f32) -> PyResult<Self> {
        let count = self.element_count();
        CoreArray::new(vec![value; count], self.shape.clone())
    }

    // =========================================================================
    // Shape Manipulation (Phase 9)
    // =========================================================================

    /// Reshape the array (zero-copy when element count matches).
    pub fn reshape(&self, new_shape: Vec<usize>) -> PyResult<Self> {
        let new_count: usize = new_shape.iter().product();
        if new_count != self.element_count() {
            return Err(pyo3::exceptions::PyValueError::new_err(format!(
                "Cannot reshape array of {} elements into shape {:?} ({} elements)",
                self.element_count(),
                new_shape,
                new_count
            )));
        }

        // Zero-copy: reuse buffer, just change shape/strides metadata
        let byte_len = self.buffer.len();
        let new_buffer = AlignedBuffer::new(byte_len);
        unsafe {
            ptr::copy_nonoverlapping(self.buffer.as_ptr(), new_buffer.as_mut_ptr(), byte_len);
        }

        let strides = Self::compute_c_strides(&new_shape, self.dtype.itemsize());

        Ok(CoreArray {
            buffer: new_buffer,
            shape: new_shape,
            strides,
            dtype: self.dtype,
        })
    }

    /// Transpose a 2D array (swap rows and columns).
    pub fn transpose(&self) -> PyResult<Self> {
        if self.shape.len() != 2 {
            return Err(pyo3::exceptions::PyValueError::new_err(format!(
                "transpose() requires 2D array, got {}D",
                self.shape.len()
            )));
        }
        if self.dtype != DType::Float32 {
            return Err(pyo3::exceptions::PyTypeError::new_err(
                "transpose() currently only supports Float32",
            ));
        }

        let rows = self.shape[0];
        let cols = self.shape[1];
        let count = rows * cols;
        let mut out_data = vec![0.0f32; count];

        let src = unsafe { self.as_f32_slice() };
        for r in 0..rows {
            for c in 0..cols {
                out_data[c * rows + r] = src[r * cols + c];
            }
        }

        CoreArray::new(out_data, vec![cols, rows])
    }

    // =========================================================================
    // Indexing (Phase 10)
    // =========================================================================

    /// Get a single f32 element by flat index.
    pub fn get_scalar(&self, index: usize) -> PyResult<f32> {
        if self.dtype != DType::Float32 {
            return Err(pyo3::exceptions::PyTypeError::new_err(
                "get_scalar() only supports Float32",
            ));
        }
        let count = self.element_count();
        if index >= count {
            return Err(pyo3::exceptions::PyIndexError::new_err(format!(
                "index {} out of bounds for array with {} elements",
                index, count
            )));
        }
        let slice = unsafe { self.as_f32_slice() };
        Ok(slice[index])
    }

    /// Index along the first axis (like array[i]).
    /// For 1D: returns a scalar wrapper (1-element array).
    /// For ND: returns a sub-array with shape[1:].
    pub fn getitem(&self, index: i64) -> PyResult<Self> {
        if self.dtype != DType::Float32 {
            return Err(pyo3::exceptions::PyTypeError::new_err(
                "getitem() only supports Float32",
            ));
        }
        if self.shape.is_empty() {
            return Err(pyo3::exceptions::PyIndexError::new_err(
                "cannot index a scalar array",
            ));
        }

        let dim0 = self.shape[0] as i64;
        let actual_idx = if index < 0 { dim0 + index } else { index };
        if actual_idx < 0 || actual_idx >= dim0 {
            return Err(pyo3::exceptions::PyIndexError::new_err(format!(
                "index {} out of bounds for axis 0 with size {}",
                index, dim0
            )));
        }
        let idx = actual_idx as usize;

        let src = unsafe { self.as_f32_slice() };

        if self.shape.len() == 1 {
            // 1D: return scalar as 1-element array
            CoreArray::new(vec![src[idx]], vec![1])
        } else {
            // ND: slice along first axis
            let inner_count: usize = self.shape[1..].iter().product();
            let start = idx * inner_count;
            let sub_data = src[start..start + inner_count].to_vec();
            let new_shape = self.shape[1..].to_vec();
            CoreArray::new(sub_data, new_shape)
        }
    }

    // =========================================================================
    // Linear Algebra Extensions
    // =========================================================================

    /// Cholesky decomposition
    pub fn cholesky(&self) -> PyResult<Self> {
        crate::linalg::decompose::solve_cholesky(self)
    }

    /// Matrix multiplication
    pub fn matmul(&self, other: &CoreArray) -> PyResult<Self> {
        if self.dtype != DType::Float32 || other.dtype != DType::Float32 {
            return Err(pyo3::exceptions::PyTypeError::new_err(
                "matmul() currently only supports Float32",
            ));
        }

        if self.shape.len() != 2 || other.shape.len() != 2 {
            return Err(pyo3::exceptions::PyValueError::new_err(
                "matmul() currently only supports 2D arrays",
            ));
        }

        let m = self.shape[0];
        let k1 = self.shape[1];
        let k2 = other.shape[0];
        let n = other.shape[1];

        if k1 != k2 {
            return Err(pyo3::exceptions::PyValueError::new_err(format!(
                "matmul() shape mismatch: inner dimensions {} and {} must match",
                k1, k2
            )));
        }

        let result = CoreArray::zeros(vec![m, n], Some(DType::Float32))?;

        unsafe {
            crate::backend::registry::dispatch_matmul_f32(
                self.buffer.as_ptr() as *const f32,
                other.buffer.as_ptr() as *const f32,
                result.buffer.as_ptr() as *mut f32,
                m,
                k1,
                n,
            )
            .map_err(pyo3::exceptions::PyRuntimeError::new_err)?;
        }

        Ok(result)
    }

    fn __repr__(&self) -> String {
        let count = self.element_count();
        let preview = if self.dtype == DType::Float32 && count <= 8 {
            let slice =
                unsafe { std::slice::from_raw_parts(self.buffer.as_ptr() as *const f32, count) };
            format!("{:?}", slice)
        } else {
            format!("[{} elements]", count)
        };
        format!(
            "CoreArray(shape={:?}, dtype={:?}, data={})",
            self.shape, self.dtype, preview
        )
    }
}

// Non-PyO3 methods (Rust-internal API)
impl CoreArray {
    /// Compute C-contiguous (row-major) byte strides for a given shape.
    pub fn compute_c_strides(shape: &[usize], itemsize: usize) -> Vec<usize> {
        let ndim = shape.len();
        if ndim == 0 {
            return vec![];
        }
        let mut strides = vec![0usize; ndim];
        strides[ndim - 1] = itemsize;
        for i in (0..ndim - 1).rev() {
            strides[i] = strides[i + 1] * shape[i + 1];
        }
        strides
    }

    /// Get a raw f32 slice view of the underlying data.
    /// # Safety
    /// Caller must ensure dtype is Float32 and buffer is valid.
    pub unsafe fn as_f32_slice(&self) -> &[f32] {
        std::slice::from_raw_parts(self.buffer.as_ptr() as *const f32, self.element_count())
    }

    /// Get a mutable raw f32 slice view of the underlying data.
    /// # Safety
    /// Caller must ensure dtype is Float32 and buffer is valid.
    pub unsafe fn as_f32_slice_mut(&mut self) -> &mut [f32] {
        std::slice::from_raw_parts_mut(self.buffer.as_mut_ptr() as *mut f32, self.element_count())
    }

    /// Generic element-wise binary operation.
    fn elementwise_binop<F>(&self, other: &CoreArray, op: F, name: &str) -> PyResult<Self>
    where
        F: Fn(f32, f32) -> f32 + Sync + Send,
    {
        if self.dtype != DType::Float32 || other.dtype != DType::Float32 {
            return Err(pyo3::exceptions::PyTypeError::new_err(format!(
                "{} currently only supports Float32",
                name
            )));
        }
        if self.shape != other.shape {
            return Err(pyo3::exceptions::PyValueError::new_err(format!(
                "Shape mismatch for {}: {:?} vs {:?}",
                name, self.shape, other.shape
            )));
        }

        let a = unsafe { self.as_f32_slice() };
        let b = unsafe { other.as_f32_slice() };

        use rayon::prelude::*;
        let result_data: Vec<f32> = a
            .par_iter()
            .zip(b.par_iter())
            .map(|(&x, &y)| op(x, y))
            .collect();

        CoreArray::new(result_data, self.shape.clone())
    }

    /// Generic element-wise comparison operation (returns Float32 where 1.0=true, 0.0=false).
    fn elementwise_cmp<F>(&self, other: &CoreArray, op: F, name: &str) -> PyResult<Self>
    where
        F: Fn(f32, f32) -> bool + Sync + Send,
    {
        if self.dtype != DType::Float32 || other.dtype != DType::Float32 {
            return Err(pyo3::exceptions::PyTypeError::new_err(format!(
                "{} currently only supports Float32",
                name
            )));
        }
        if self.shape != other.shape {
            return Err(pyo3::exceptions::PyValueError::new_err(format!(
                "Shape mismatch for {}: {:?} vs {:?}",
                name, self.shape, other.shape
            )));
        }

        let a = unsafe { self.as_f32_slice() };
        let b = unsafe { other.as_f32_slice() };

        use rayon::prelude::*;
        let result_data: Vec<f32> = a
            .par_iter()
            .zip(b.par_iter())
            .map(|(&x, &y)| if op(x, y) { 1.0 } else { 0.0 })
            .collect();

        CoreArray::new(result_data, self.shape.clone())
    }

    /// Generic element-wise unary operation.
    fn elementwise_unary<F>(&self, op: F, name: &str) -> PyResult<Self>
    where
        F: Fn(f32) -> f32 + Sync + Send,
    {
        if self.dtype != DType::Float32 {
            return Err(pyo3::exceptions::PyTypeError::new_err(format!(
                "{} currently only supports Float32",
                name
            )));
        }

        let a = unsafe { self.as_f32_slice() };
        use rayon::prelude::*;
        let result_data: Vec<f32> = a.par_iter().map(|&x| op(x)).collect();

        CoreArray::new(result_data, self.shape.clone())
    }
}

// ============================================================================
// Tests
// ============================================================================

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_create_array() {
        let t = CoreArray::new(vec![1.0, 2.0, 3.0, 4.0, 5.0, 6.0], vec![2, 3]).unwrap();
        assert_eq!(t.element_count(), 6);
        assert_eq!(t.ndim(), 2);
        assert_eq!(t.shape(), vec![2, 3]);
        assert!(t.is_contiguous());
        assert_eq!(t.nbytes(), 24); // 6 * 4
    }

    #[test]
    fn test_alignment() {
        let t = CoreArray::new(vec![0.0; 1024], vec![1024]).unwrap();
        assert_eq!(t.data_ptr() % 64, 0, "Buffer must be 64-byte aligned");
    }

    #[test]
    fn test_zeros() {
        let t = CoreArray::zeros(vec![3, 3], None).unwrap();
        let data = t.to_list().unwrap();
        assert!(data.iter().all(|&x| x == 0.0));
    }

    #[test]
    fn test_ones() {
        let t = CoreArray::ones(vec![2, 2]).unwrap();
        let data = t.to_list().unwrap();
        assert!(data.iter().all(|&x| x == 1.0));
    }

    #[test]
    fn test_shape_mismatch() {
        let result = CoreArray::new(vec![1.0, 2.0, 3.0], vec![2, 2]);
        assert!(result.is_err());
    }

    #[test]
    fn test_c_strides() {
        let strides = CoreArray::compute_c_strides(&[2, 3, 4], 4);
        assert_eq!(strides, vec![48, 16, 4]); // 3*4*4, 4*4, 4
    }
}
