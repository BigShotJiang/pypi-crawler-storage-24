// ============================================================================
// DType: Array Element Data Types
// ============================================================================

use pyo3::prelude::*;

/// Supported array element data types.
/// Mirrors Python's DataType enum for seamless FFI.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
#[pyclass(eq, eq_int, from_py_object)]
pub enum DType {
    Float32 = 0,
    Float64 = 1,
    Int32 = 2,
    Int64 = 3,
    Bool = 4,
}

#[pymethods]
impl DType {
    /// Size of a single element in bytes.
    #[getter]
    pub fn itemsize(&self) -> usize {
        match self {
            DType::Float32 => 4,
            DType::Float64 => 8,
            DType::Int32 => 4,
            DType::Int64 => 8,
            DType::Bool => 1,
        }
    }

    fn __repr__(&self) -> String {
        format!("DType.{:?}", self)
    }
}
