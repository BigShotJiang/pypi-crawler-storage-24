use pyo3::prelude::*;
use std::collections::HashMap;

use super::core::DataFrame;
use super::series::Series;
use crate::array::core_array::CoreArray;
use crate::array::DType;

#[pyclass(from_py_object)]
#[derive(Clone)]
pub struct GroupBy {
    df: DataFrame,
    by: String,

    // For f32 keys (using to_bits), or i32 keys
    groups_f32: Option<HashMap<u32, Vec<usize>>>,
    groups_i32: Option<HashMap<i32, Vec<usize>>>,
}

impl GroupBy {
    pub fn new(df: DataFrame, by: String) -> PyResult<Self> {
        let col = df.columns.get(&by).ok_or_else(|| {
            pyo3::exceptions::PyKeyError::new_err(format!("Column {} not found for groupby", by))
        })?;

        let dtype = col.data.dtype();
        let mut groups_f32 = None;
        let mut groups_i32 = None;

        if dtype == DType::Float32 {
            let mut map: HashMap<u32, Vec<usize>> = HashMap::new();
            let slice = unsafe {
                std::slice::from_raw_parts(
                    col.data.data_ptr() as *const f32,
                    col.data.element_count(),
                )
            };
            for (i, &val) in slice.iter().enumerate() {
                map.entry(val.to_bits()).or_default().push(i);
            }
            groups_f32 = Some(map);
        } else if dtype == DType::Int32 {
            let mut map: HashMap<i32, Vec<usize>> = HashMap::new();
            let slice = unsafe {
                std::slice::from_raw_parts(
                    col.data.data_ptr() as *const i32,
                    col.data.element_count(),
                )
            };
            for (i, &val) in slice.iter().enumerate() {
                map.entry(val).or_default().push(i);
            }
            groups_i32 = Some(map);
        } else {
            return Err(pyo3::exceptions::PyTypeError::new_err(
                "Unsupported grouping column dtype",
            ));
        }

        Ok(GroupBy {
            df,
            by,
            groups_f32,
            groups_i32,
        })
    }
}

#[pymethods]
impl GroupBy {
    pub fn sum(&self) -> PyResult<DataFrame> {
        self.aggregate_sum()
    }

    pub fn mean(&self) -> PyResult<DataFrame> {
        self.aggregate_mean()
    }
}

impl GroupBy {
    fn aggregate_sum(&self) -> PyResult<DataFrame> {
        let mut new_df = DataFrame::new();

        // We need to iterate over groups in a consistent order, so we extract and sort keys
        let (keys_f32, keys_i32) = if let Some(ref map) = self.groups_f32 {
            let mut keys: Vec<u32> = map.keys().cloned().collect();
            // Sort by f32 value
            keys.sort_by(|a, b| {
                f32::from_bits(*a)
                    .partial_cmp(&f32::from_bits(*b))
                    .unwrap_or(std::cmp::Ordering::Equal)
            });
            (Some((keys, map)), None)
        } else if let Some(ref map) = self.groups_i32 {
            let mut keys: Vec<i32> = map.keys().cloned().collect();
            keys.sort();
            (None, Some((keys, map)))
        } else {
            return Err(pyo3::exceptions::PyRuntimeError::new_err("No groups found"));
        };

        let num_groups = keys_f32
            .as_ref()
            .map(|(k, _)| k.len())
            .unwrap_or_else(|| keys_i32.as_ref().unwrap().0.len());

        for (name, series) in &self.df.columns {
            if name == &self.by {
                // Grouping key column
                let mut new_data_vec = Vec::with_capacity(num_groups);
                if let Some((ref keys, _)) = keys_f32 {
                    for &k in keys {
                        new_data_vec.push(f32::from_bits(k));
                    }
                } else if let Some((ref keys, _)) = keys_i32 {
                    for &k in keys {
                        new_data_vec.push(k as f32); // Fallback float storage
                    }
                }

                let array = CoreArray::new(new_data_vec, vec![num_groups])?;
                let index: Vec<String> = (0..num_groups).map(|i| i.to_string()).collect();
                new_df.columns.insert(
                    name.clone(),
                    Series {
                        name: name.clone(),
                        data: array,
                        index,
                    },
                );
                continue;
            }

            // Numeric aggregation column
            let mut new_data_vec = Vec::with_capacity(num_groups);
            let dtype = series.data.dtype();

            let aggregate = |indices: &Vec<usize>| -> f32 {
                let mut sum = 0.0;
                if dtype == DType::Float32 {
                    let slice = unsafe {
                        std::slice::from_raw_parts(
                            series.data.data_ptr() as *const f32,
                            series.data.element_count(),
                        )
                    };
                    for &idx in indices {
                        sum += slice[idx];
                    }
                } else if dtype == DType::Int32 {
                    let slice = unsafe {
                        std::slice::from_raw_parts(
                            series.data.data_ptr() as *const i32,
                            series.data.element_count(),
                        )
                    };
                    for &idx in indices {
                        sum += slice[idx] as f32;
                    }
                }
                sum
            };

            if let Some((ref keys, map)) = keys_f32 {
                for &k in keys {
                    let indices = map.get(&k).unwrap();
                    new_data_vec.push(aggregate(indices));
                }
            } else if let Some((ref keys, map)) = keys_i32 {
                for &k in keys {
                    let indices = map.get(&k).unwrap();
                    new_data_vec.push(aggregate(indices));
                }
            }

            let array = CoreArray::new(new_data_vec, vec![num_groups])?;
            let index: Vec<String> = (0..num_groups).map(|i| i.to_string()).collect();
            new_df.columns.insert(
                name.clone(),
                Series {
                    name: name.clone(),
                    data: array,
                    index,
                },
            );
        }

        new_df.row_count = num_groups;
        Ok(new_df)
    }

    fn aggregate_mean(&self) -> PyResult<DataFrame> {
        let mut new_df = DataFrame::new();

        let (keys_f32, keys_i32) = if let Some(ref map) = self.groups_f32 {
            let mut keys: Vec<u32> = map.keys().cloned().collect();
            keys.sort_by(|a, b| {
                f32::from_bits(*a)
                    .partial_cmp(&f32::from_bits(*b))
                    .unwrap_or(std::cmp::Ordering::Equal)
            });
            (Some((keys, map)), None)
        } else if let Some(ref map) = self.groups_i32 {
            let mut keys: Vec<i32> = map.keys().cloned().collect();
            keys.sort();
            (None, Some((keys, map)))
        } else {
            return Err(pyo3::exceptions::PyRuntimeError::new_err("No groups found"));
        };

        let num_groups = keys_f32
            .as_ref()
            .map(|(k, _)| k.len())
            .unwrap_or_else(|| keys_i32.as_ref().unwrap().0.len());

        for (name, series) in &self.df.columns {
            if name == &self.by {
                let mut new_data_vec = Vec::with_capacity(num_groups);
                if let Some((ref keys, _)) = keys_f32 {
                    for &k in keys {
                        new_data_vec.push(f32::from_bits(k));
                    }
                } else if let Some((ref keys, _)) = keys_i32 {
                    for &k in keys {
                        new_data_vec.push(k as f32);
                    }
                }

                let array = CoreArray::new(new_data_vec, vec![num_groups])?;
                let index: Vec<String> = (0..num_groups).map(|i| i.to_string()).collect();
                new_df.columns.insert(
                    name.clone(),
                    Series {
                        name: name.clone(),
                        data: array,
                        index,
                    },
                );
                continue;
            }

            let mut new_data_vec = Vec::with_capacity(num_groups);
            let dtype = series.data.dtype();

            let aggregate = |indices: &Vec<usize>| -> f32 {
                let mut sum = 0.0;
                let count = indices.len() as f32;
                if count == 0.0 {
                    return f32::NAN;
                }

                if dtype == DType::Float32 {
                    let slice = unsafe {
                        std::slice::from_raw_parts(
                            series.data.data_ptr() as *const f32,
                            series.data.element_count(),
                        )
                    };
                    for &idx in indices {
                        sum += slice[idx];
                    }
                } else if dtype == DType::Int32 {
                    let slice = unsafe {
                        std::slice::from_raw_parts(
                            series.data.data_ptr() as *const i32,
                            series.data.element_count(),
                        )
                    };
                    for &idx in indices {
                        sum += slice[idx] as f32;
                    }
                }
                sum / count
            };

            if let Some((ref keys, map)) = keys_f32 {
                for &k in keys {
                    let indices = map.get(&k).unwrap();
                    new_data_vec.push(aggregate(indices));
                }
            } else if let Some((ref keys, map)) = keys_i32 {
                for &k in keys {
                    let indices = map.get(&k).unwrap();
                    new_data_vec.push(aggregate(indices));
                }
            }

            let array = CoreArray::new(new_data_vec, vec![num_groups])?;
            let index: Vec<String> = (0..num_groups).map(|i| i.to_string()).collect();
            new_df.columns.insert(
                name.clone(),
                Series {
                    name: name.clone(),
                    data: array,
                    index,
                },
            );
        }

        new_df.row_count = num_groups;
        Ok(new_df)
    }
}
