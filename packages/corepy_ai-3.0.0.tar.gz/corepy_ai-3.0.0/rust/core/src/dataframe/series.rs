use pyo3::prelude::*;
use pyo3::types::PyDict;
use std::collections::HashMap;

use crate::array::core_array::CoreArray;
use crate::array::DType;

#[pyclass(from_py_object)]
#[derive(Clone, Debug)]
pub struct Series {
    #[pyo3(get, set)]
    pub name: String,
    #[pyo3(get, set)]
    pub data: CoreArray,
    #[pyo3(get, set)]
    pub index: Vec<String>,
}

#[pymethods]
impl Series {
    #[new]
    #[pyo3(signature = (name, data, index=None))]
    pub fn new(
        name: String,
        data: pyo3::PyRef<'_, CoreArray>,
        index: Option<Vec<String>>,
    ) -> PyResult<Self> {
        let count = data.element_count();
        let idx = match index {
            Some(idx) => {
                if idx.len() != count {
                    return Err(pyo3::exceptions::PyValueError::new_err(
                        "Index length must match data length",
                    ));
                }
                idx
            }
            None => (0..count).map(|i| i.to_string()).collect(),
        };

        Ok(Series {
            name,
            data: data.clone(),
            index: idx,
        })
    }

    pub fn head(&self, n: Option<usize>) -> PyResult<Series> {
        let count = self.data.element_count();
        let n = n.unwrap_or(5).min(count);
        let mut new_data_vec = Vec::with_capacity(n);
        let mut new_index = Vec::with_capacity(n);

        // Assuming data is 1D
        let dtype = self.data.dtype();
        if dtype == DType::Float32 {
            let data_slice =
                unsafe { std::slice::from_raw_parts(self.data.data_ptr() as *const f32, n) };
            new_data_vec.extend_from_slice(data_slice);
        } else if dtype == DType::Int32 {
            let data_slice =
                unsafe { std::slice::from_raw_parts(self.data.data_ptr() as *const i32, n) };
            for &val in data_slice {
                new_data_vec.push(val as f32); // Simple cast for internal representation
            }
        } else {
            return Err(pyo3::exceptions::PyTypeError::new_err(
                "Unsupported DType for head",
            ));
        }

        let new_core_array = CoreArray::new(new_data_vec, vec![n])?;
        new_index.extend_from_slice(&self.index[..n]);

        Ok(Series {
            name: self.name.clone(),
            data: new_core_array,
            index: new_index,
        })
    }

    pub fn tail(&self, n: Option<usize>) -> PyResult<Series> {
        let count = self.data.element_count();
        let n = n.unwrap_or(5).min(count);
        let start = count - n;

        let mut new_data_vec = Vec::with_capacity(n);
        let mut new_index = Vec::with_capacity(n);

        let dtype = self.data.dtype();
        if dtype == DType::Float32 {
            let data_slice = unsafe {
                std::slice::from_raw_parts((self.data.data_ptr() as *const f32).add(start), n)
            };
            new_data_vec.extend_from_slice(data_slice);
        } else if dtype == DType::Int32 {
            let data_slice = unsafe {
                std::slice::from_raw_parts((self.data.data_ptr() as *const i32).add(start), n)
            };
            for &val in data_slice {
                new_data_vec.push(val as f32);
            }
        } else {
            return Err(pyo3::exceptions::PyTypeError::new_err(
                "Unsupported DType for tail",
            ));
        }

        let new_core_array = CoreArray::new(new_data_vec, vec![n])?;
        new_index.extend_from_slice(&self.index[start..]);

        Ok(Series {
            name: self.name.clone(),
            data: new_core_array,
            index: new_index,
        })
    }

    #[getter]
    pub fn values(&self) -> PyResult<CoreArray> {
        Ok(self.data.clone())
    }

    #[getter]
    pub fn dtype(&self) -> PyResult<String> {
        Ok(format!("{:?}", self.data.dtype()))
    }

    pub fn unique(&self) -> PyResult<Series> {
        let dtype = self.data.dtype();
        if dtype != DType::Float32 && dtype != DType::Int32 {
            return Err(pyo3::exceptions::PyTypeError::new_err(
                "Unsupported DType for unique",
            ));
        }

        let mut unique_vals = Vec::new();
        let mut seen = std::collections::HashSet::new();

        if dtype == DType::Float32 {
            let slice = unsafe {
                std::slice::from_raw_parts(
                    self.data.data_ptr() as *const f32,
                    self.data.element_count(),
                )
            };
            for &val in slice {
                let key = val.to_bits(); // Handle floats
                if seen.insert(key) {
                    unique_vals.push(val);
                }
            }
        } else if dtype == DType::Int32 {
            let slice = unsafe {
                std::slice::from_raw_parts(
                    self.data.data_ptr() as *const i32,
                    self.data.element_count(),
                )
            };
            for &val in slice {
                if seen.insert(val as u32) {
                    unique_vals.push(val as f32);
                }
            }
        }

        let n = unique_vals.len();
        let new_array = CoreArray::new(unique_vals, vec![n])?;
        let new_index: Vec<String> = (0..n).map(|i| i.to_string()).collect();

        Ok(Series {
            name: self.name.clone(),
            data: new_array,
            index: new_index,
        })
    }

    pub fn value_counts<'py>(&self, py: Python<'py>) -> PyResult<Bound<'py, PyDict>> {
        let dict = PyDict::new(py);

        let dtype = self.data.dtype();
        if dtype == DType::Float32 {
            let mut counts: HashMap<u32, usize> = HashMap::new();
            let slice = unsafe {
                std::slice::from_raw_parts(
                    self.data.data_ptr() as *const f32,
                    self.data.element_count(),
                )
            };
            for &val in slice {
                *counts.entry(val.to_bits()).or_insert(0) += 1;
            }
            for (bits, count) in counts {
                let val = f32::from_bits(bits);
                dict.set_item(val, count)?;
            }
        } else if dtype == DType::Int32 {
            let mut counts: HashMap<i32, usize> = HashMap::new();
            let slice = unsafe {
                std::slice::from_raw_parts(
                    self.data.data_ptr() as *const i32,
                    self.data.element_count(),
                )
            };
            for &val in slice {
                *counts.entry(val).or_insert(0) += 1;
            }
            for (val, count) in counts {
                dict.set_item(val, count)?;
            }
        } else {
            return Err(pyo3::exceptions::PyTypeError::new_err(
                "Unsupported DType for value_counts",
            ));
        }

        Ok(dict)
    }
}
