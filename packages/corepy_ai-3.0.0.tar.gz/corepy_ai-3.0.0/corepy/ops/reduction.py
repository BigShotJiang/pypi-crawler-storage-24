"""
UFUNC CORE-50: Reduction Operations

    cp.prod, cp.std, cp.var, cp.cumsum, cp.cumprod
    cp.nansum, cp.nanmean, cp.nanmax, cp.nanmin
"""

import math
from typing import Any


def _ensure(a):
    from ..array import ndarray

    if not isinstance(a, ndarray):
        a = ndarray(a if isinstance(a, (list, tuple)) else [a])
    return a


def prod(a: Any) -> float:
    """Product of all elements."""
    a = _ensure(a)
    if a._core_array is not None:
        return a._core_array.prod()
    from .math import _flatten

    flat = _flatten(a._backing_data)
    result = 1.0
    for x in flat:
        result *= x
    return result


def std(a: Any) -> float:
    """Population standard deviation."""
    a = _ensure(a)
    if a._core_array is not None:
        return a._core_array.std_dev()
    from .math import _flatten

    flat = _flatten(a._backing_data)
    n = len(flat)
    mean = sum(flat) / n
    var = sum((x - mean) ** 2 for x in flat) / n
    return math.sqrt(var)


def var(a: Any) -> float:
    """Population variance."""
    a = _ensure(a)
    if a._core_array is not None:
        return a._core_array.var()
    from .math import _flatten

    flat = _flatten(a._backing_data)
    n = len(flat)
    mean = sum(flat) / n
    return sum((x - mean) ** 2 for x in flat) / n


def cumsum(a: Any) -> Any:
    """Cumulative sum."""
    from ..array import ndarray

    a = _ensure(a)
    if a._core_array is not None:
        result_ca = a._core_array.cumsum()
        result = ndarray(result_ca.to_list(), dtype=a.dtype, backend=a.backend)
        result._core_array = result_ca
        return result
    from .math import _flatten

    flat = _flatten(a._backing_data)
    out = []
    acc = 0.0
    for x in flat:
        acc += x
        out.append(acc)
    return ndarray(out, dtype=a.dtype, backend=a.backend)


def cumprod(a: Any) -> Any:
    """Cumulative product."""
    from ..array import ndarray

    a = _ensure(a)
    if a._core_array is not None:
        result_ca = a._core_array.cumprod()
        result = ndarray(result_ca.to_list(), dtype=a.dtype, backend=a.backend)
        result._core_array = result_ca
        return result
    from .math import _flatten

    flat = _flatten(a._backing_data)
    out = []
    acc = 1.0
    for x in flat:
        acc *= x
        out.append(acc)
    return ndarray(out, dtype=a.dtype, backend=a.backend)


def nansum(a: Any) -> float:
    """Sum ignoring NaN."""
    a = _ensure(a)
    if a._core_array is not None:
        return a._core_array.nansum()
    from .math import _flatten

    flat = _flatten(a._backing_data)
    return sum(x for x in flat if not math.isnan(x))


def nanmean(a: Any) -> float:
    """Mean ignoring NaN."""
    a = _ensure(a)
    if a._core_array is not None:
        return a._core_array.nanmean()
    from .math import _flatten

    flat = _flatten(a._backing_data)
    valid = [x for x in flat if not math.isnan(x)]
    if not valid:
        return float("nan")
    return sum(valid) / len(valid)


def nanmax(a: Any) -> float:
    """Max ignoring NaN."""
    a = _ensure(a)
    if a._core_array is not None:
        return a._core_array.nanmax()
    from .math import _flatten

    flat = _flatten(a._backing_data)
    valid = [x for x in flat if not math.isnan(x)]
    return max(valid) if valid else float("-inf")


def nanmin(a: Any) -> float:
    """Min ignoring NaN."""
    a = _ensure(a)
    if a._core_array is not None:
        return a._core_array.nanmin()
    from .math import _flatten

    flat = _flatten(a._backing_data)
    valid = [x for x in flat if not math.isnan(x)]
    return min(valid) if valid else float("inf")
