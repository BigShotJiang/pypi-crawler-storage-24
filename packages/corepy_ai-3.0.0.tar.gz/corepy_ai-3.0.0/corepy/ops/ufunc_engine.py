"""
UFUNC CORE-12: Universal Function Engine

Core dispatch layer for elementwise operations with:
- Broadcasting support
- Multi-input chaining
- Backend dispatch (CoreArray → Python fallback)
- Scalar coercion
"""

from typing import Any, Callable, Optional, Union

from ..broadcasting import broadcast_shapes


def _ensure_array(x: Any) -> Any:
    """Convert scalars and lists to ndarray if needed."""
    from ..array import ndarray

    if isinstance(x, ndarray):
        return x
    return ndarray(x if isinstance(x, (list, tuple)) else [x])


def _broadcast_pair(a: Any, b: Any) -> tuple:
    """
    Broadcast two arrays to compatible shapes.
    Returns (a_broadcasted, b_broadcasted).
    """
    from ..array import ndarray

    a = _ensure_array(a)
    b = _ensure_array(b)

    if a.shape == b.shape:
        return a, b

    # Compute target shape
    target_shape = broadcast_shapes(a.shape, b.shape)

    # Expand scalars / single-element arrays
    if a.size == 1 and a.shape != target_shape:
        scalar = a.to_list()[0] if hasattr(a, "to_list") else float(a)
        total = 1
        for d in target_shape:
            total *= d
        a = ndarray([scalar] * total).reshape(target_shape)

    if b.size == 1 and b.shape != target_shape:
        scalar = b.to_list()[0] if hasattr(b, "to_list") else float(b)
        total = 1
        for d in target_shape:
            total *= d
        b = ndarray([scalar] * total).reshape(target_shape)

    return a, b


def ufunc_binary(op_name: str, a: Any, b: Any) -> Any:
    """
    Execute a binary ufunc with broadcasting.

    Args:
        op_name: Operation name ('add', 'sub', 'mul', 'div', 'power', 'mod', 'floor_div',
                 'eq', 'ne', 'gt', 'lt', 'ge', 'le',
                 'logical_and', 'logical_or', 'logical_xor')
        a: First operand (array or scalar)
        b: Second operand (array or scalar)

    Returns:
        ndarray with the result
    """
    from ..array import ndarray

    a, b = _broadcast_pair(a, b)

    # Try CoreArray fast path
    if a._core_array is not None and b._core_array is not None:
        core_ops = {
            "add": a._core_array.add,
            "sub": a._core_array.sub,
            "mul": a._core_array.mul,
            "div": a._core_array.div,
            "power": a._core_array.power,
            "mod": a._core_array.mod_op,
            "floor_div": a._core_array.floor_div,
            "eq": a._core_array.eq,
            "ne": a._core_array.ne,
            "gt": a._core_array.gt,
            "lt": a._core_array.lt,
            "ge": a._core_array.ge,
            "le": a._core_array.le,
            "logical_and": a._core_array.logical_and,
            "logical_or": a._core_array.logical_or,
            "logical_xor": a._core_array.logical_xor,
        }
        core_fn = core_ops.get(op_name)
        if core_fn is not None:
            result_ca = core_fn(b._core_array)
            result = ndarray(result_ca.to_list(), dtype=a.dtype, backend=a.backend)
            result._core_array = result_ca
            return result

    # Python fallback for basic arithmetic
    from .math import _flatten

    flat_a = _flatten(a._backing_data if hasattr(a, "_backing_data") else a)
    flat_b = _flatten(b._backing_data if hasattr(b, "_backing_data") else b)

    py_ops: dict[str, Callable] = {
        "add": lambda x, y: x + y,
        "sub": lambda x, y: x - y,
        "mul": lambda x, y: x * y,
        "div": lambda x, y: x / y,
        "power": lambda x, y: x**y,
        "mod": lambda x, y: x % y,
        "floor_div": lambda x, y: x // y,
        "eq": lambda x, y: 1.0 if x == y else 0.0,
        "ne": lambda x, y: 1.0 if x != y else 0.0,
        "gt": lambda x, y: 1.0 if x > y else 0.0,
        "lt": lambda x, y: 1.0 if x < y else 0.0,
        "ge": lambda x, y: 1.0 if x >= y else 0.0,
        "le": lambda x, y: 1.0 if x <= y else 0.0,
        "logical_and": lambda x, y: 1.0 if (x != 0 and y != 0) else 0.0,
        "logical_or": lambda x, y: 1.0 if (x != 0 or y != 0) else 0.0,
        "logical_xor": lambda x, y: 1.0 if ((x != 0) ^ (y != 0)) else 0.0,
    }

    fn = py_ops.get(op_name)
    if fn is None:
        raise ValueError(f"Unknown ufunc: {op_name}")

    result_data = [fn(x, y) for x, y in zip(flat_a, flat_b)]
    result = ndarray(result_data, dtype=a.dtype, backend=a.backend)
    result._shape = a.shape
    return result


def ufunc_unary(op_name: str, a: Any) -> Any:
    """Execute a unary ufunc."""
    import math

    from ..array import ndarray

    a = _ensure_array(a)

    # CoreArray fast path
    if a._core_array is not None:
        core_ops = {
            "logical_not": a._core_array.logical_not,
            "neg": a._core_array.neg,
            "abs": a._core_array.abs,
            "is_even": a._core_array.is_even,
            "is_odd": a._core_array.is_odd,
        }
        core_fn = core_ops.get(op_name)
        if core_fn is not None:
            result_ca = core_fn()
            result = ndarray(result_ca.to_list(), dtype=a.dtype, backend=a.backend)
            result._core_array = result_ca
            return result

    # Python fallback
    from .math import _flatten

    flat = _flatten(a._backing_data if hasattr(a, "_backing_data") else a)

    py_ops: dict[str, Callable] = {
        "logical_not": lambda x: 1.0 if x == 0 else 0.0,
        "neg": lambda x: -x,
        "abs": lambda x: abs(x),
        "is_even": lambda x: 1.0 if x % 2 == 0 else 0.0,
        "is_odd": lambda x: 1.0 if x % 2 != 0 else 0.0,
    }

    fn = py_ops.get(op_name)
    if fn is None:
        raise ValueError(f"Unknown unary ufunc: {op_name}")

    result_data = [fn(x) for x in flat]
    result = ndarray(result_data, dtype=a.dtype, backend=a.backend)
    result._shape = a.shape
    return result


def ufunc_multi(op_name: str, *arrays: Any) -> Any:
    """
    Execute a binary ufunc across multiple inputs via left-fold.

    Example: ufunc_multi('add', a, b, c, d) → ((a + b) + c) + d
    """
    if len(arrays) < 2:
        raise ValueError(f"ufunc '{op_name}' requires at least 2 inputs")

    result = ufunc_binary(op_name, arrays[0], arrays[1])
    for arr in arrays[2:]:
        result = ufunc_binary(op_name, result, arr)
    return result
