from typing import Optional, Tuple, Union

from .array import ndarray
from .backend.types import DataType

try:
    from . import _corepy_rust
except ImportError:
    _corepy_rust = None


def rand(
    shape: Union[int, Tuple[int, ...]], seed: int = 42, algo: str = "pcg64"
) -> ndarray:
    """
    Generate an array of uniform random float32 values in [0.0, 1.0).

    Args:
        shape: Dimensions of the array
        seed: Random seed for reproducibility
        algo: 'pcg64' or 'xoshiro'
    """
    if _corepy_rust is None:
        raise ImportError("Rust backend is required for random generation")

    if isinstance(shape, int):
        shape = (shape,)

    rng_algo = _corepy_rust.RngAlgorithm.PCG64
    if algo.lower() == "xoshiro":
        rng_algo = _corepy_rust.RngAlgorithm.Xoshiro256PP

    ct = _corepy_rust.random_uniform_f32(list(shape), seed, rng_algo)
    arr = ndarray([], dtype=DataType.FLOAT32)
    arr._backing_data = ct.to_list()
    arr._shape = tuple(ct.shape)
    arr._element_count = ct.element_count
    arr._core_array = ct
    return arr


def randn(
    shape: Union[int, Tuple[int, ...]], seed: int = 42, algo: str = "pcg64"
) -> ndarray:
    """
    Generate an array of standard normal random float32 values.

    Args:
        shape: Dimensions of the array
        seed: Random seed for reproducibility
        algo: 'pcg64' or 'xoshiro'
    """
    if _corepy_rust is None:
        raise ImportError("Rust backend is required for random generation")

    if isinstance(shape, int):
        shape = (shape,)

    rng_algo = _corepy_rust.RngAlgorithm.PCG64
    if algo.lower() == "xoshiro":
        rng_algo = _corepy_rust.RngAlgorithm.Xoshiro256PP

    ct = _corepy_rust.random_normal_f32(list(shape), seed, rng_algo)
    arr = ndarray([], dtype=DataType.FLOAT32)
    arr._backing_data = ct.to_list()
    arr._shape = tuple(ct.shape)
    arr._element_count = ct.element_count
    arr._core_array = ct
    return arr
