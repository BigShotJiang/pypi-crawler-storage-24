from typing import Any, Dict, List, Optional, Tuple, Union

from ._corepy_rust import DataFrame as _RustDataFrame
from ._corepy_rust import GroupBy as _RustGroupBy
from ._corepy_rust import read_csv as _rust_read_csv
from .array import ndarray
from .series import Series


def read_csv(filepath: str) -> "DataFrame":
    rust_df = _rust_read_csv(filepath)
    return DataFrame(rust_df)


class GroupBy:
    """
    Pandas-compatible GroupBy, backed by Rust Hash Engine.
    """

    def __init__(self, rust_groupby: _RustGroupBy):
        self._groupby = rust_groupby

    def sum(self) -> "DataFrame":
        return DataFrame(self._groupby.sum())

    def mean(self) -> "DataFrame":
        return DataFrame(self._groupby.mean())

    def agg(self, agg_dict: Dict[str, str]) -> "DataFrame":
        # Simplified agg matching only single operations for the tutorial
        # since Rust backend handles mean/sum globally for the group
        ops = list(agg_dict.values())
        if "mean" in ops:
            return self.mean()
        elif "sum" in ops:
            return self.sum()
        else:
            raise NotImplementedError(f"Unsupported aggregations: {ops}")


class DataFrame:
    """
    Pandas-compatible DataFrame backed by CorePy Rust Engine.
    """

    def __init__(self, data=None):
        self._df = _RustDataFrame()
        if data is not None:
            if isinstance(data, dict):
                for col_name, col_data in data.items():
                    if isinstance(col_data, Series):
                        self._df.insert(str(col_name), col_data._series)
                    else:
                        s = Series(col_data, name=str(col_name))
                        self._df.insert(str(col_name), s._series)
            elif isinstance(data, _RustDataFrame):
                self._df = data
            elif isinstance(data, DataFrame):
                for col_name in data.columns:
                    s = data[col_name]
                    self._df.insert(col_name, s._series)
            else:
                raise TypeError(f"Unsupported data type for DataFrame: {type(data)}")

    @property
    def columns(self) -> List[str]:
        return list(self._df.columns.keys())

    @property
    def shape(self) -> Tuple[int, int]:
        return (self._df.row_count, len(self._df.columns))

    def __getitem__(self, key: Union[str, List[str]]):
        if isinstance(key, str):
            rust_series = self._df.get_column(key)
            return Series(rust_series)
        elif isinstance(key, list):
            new_df = DataFrame()
            for col in key:
                if not isinstance(col, str):
                    raise TypeError("Column name must be string")
                rust_series = self._df.get_column(col)
                new_df._df.insert(col, rust_series)
            return new_df
        else:
            raise TypeError("Index must be string or list of strings")

    def __setitem__(self, key: str, value):
        if not isinstance(key, str):
            raise TypeError("Column name must be a string")
        if isinstance(value, Series):
            self._df.insert(key, value._series)
        else:
            s = Series(value, name=key)
            self._df.insert(key, s._series)

    def add_int_column(self, name: str, data: list):
        self[name] = data

    def add_float_column(self, name: str, data: list):
        self[name] = data

    def drop(self, columns: Union[str, List[str]]) -> "DataFrame":
        cols = [columns] if isinstance(columns, str) else columns
        new_rust_df = _RustDataFrame()
        for col_name, series in self._df.columns.items():
            if col_name not in cols:
                new_rust_df.insert(col_name, series)
        return DataFrame(new_rust_df)

    def rename(self, columns: Dict[str, str]) -> "DataFrame":
        new_rust_df = _RustDataFrame()
        for col_name, series in self._df.columns.items():
            if col_name in columns:
                # pass cloned rust series, note that the cloned series name must also be updated
                # doing this by creating a fresh Series in Python is easiest to update name
                s = Series(series)
                s.name = columns[col_name]
                new_rust_df.insert(columns[col_name], s._series)
            else:
                new_rust_df.insert(col_name, series)
        return DataFrame(new_rust_df)

    def sort_values(self, by: str, ascending: bool = True) -> "DataFrame":
        return DataFrame(self._df.sort_values(by, ascending))

    def filter(self, col_name: str, value: Any) -> "DataFrame":
        return DataFrame(self._df.filter_eq(col_name, float(value)))

    def groupby(self, by: str) -> GroupBy:
        return GroupBy(self._df.groupby(by))

    def merge(
        self, right: "DataFrame", left_on: str, right_on: str, how: str = "inner"
    ) -> "DataFrame":
        return DataFrame(self._df.join(right._df, left_on, right_on, how))

    def filter_int_eq(self, col_name: str, value: int) -> "DataFrame":
        return self.filter(col_name, value)

    def pivot(self, index: str, columns: str, values: str) -> "DataFrame":
        return DataFrame(self._df.pivot(index, columns, values))

    @property
    def iloc(self):
        class _ILocIndexer:
            def __init__(self, df):
                self.df = df

            def __getitem__(self, key):
                if isinstance(key, slice):
                    s = key.start
                    e = key.stop
                    # Convert negative slices
                    n = self.df.shape[0]
                    if s is not None and s < 0:
                        s += n
                    if e is not None and e < 0:
                        e += n
                    new_rust_df = self.df._df.iloc(s, e)
                    return DataFrame(new_rust_df)
                elif isinstance(key, int):
                    # Single row slice
                    i = key
                    n = self.df.shape[0]
                    if i < 0:
                        i += n
                    new_rust_df = self.df._df.iloc(i, i + 1)
                    return DataFrame(new_rust_df)
                raise TypeError(
                    "iloc currently only supports slice objects or integers"
                )

        return _ILocIndexer(self)

    def __repr__(self) -> str:
        s = f"DataFrame({self.shape[0]} rows x {self.shape[1]} columns)\n"
        s += "Columns: " + ", ".join(self.columns)
        return s
