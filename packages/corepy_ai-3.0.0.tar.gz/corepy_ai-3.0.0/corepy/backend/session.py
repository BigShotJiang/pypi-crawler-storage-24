from typing import Dict

from .backend import Backend, CPUBackend, CUDABackend, MetalBackend
from .device import DeviceInfo, detect_devices
from .types import BackendType


class Session:
    """
    Manages the global state of the Corepy runtime, including detected devices
    and active backends.
    """

    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(Session, cls).__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return
        self._device_info: DeviceInfo = detect_devices()
        self._backends: Dict[BackendType, Backend] = {}

        # Initialize default backends
        self._backends[BackendType.CPU] = CPUBackend()
        if self._device_info.has_cuda:
            self._backends[BackendType.CUDA] = CUDABackend()
        if self._device_info.has_metal:
            self._backends[BackendType.METAL] = MetalBackend()

        self._initialized = True

    @property
    def device_info(self) -> DeviceInfo:
        return self._device_info

    def get_backend(self, backend_type: BackendType) -> Backend:
        if backend_type not in self._backends:
            # Try to lazy load or raise error
            raise ValueError(
                f"Backend {backend_type} not available or not initialized."
            )
        return self._backends[backend_type]


# Global session instance
_session = None


def get_session() -> Session:
    global _session
    if _session is None:
        _session = Session()
    return _session
