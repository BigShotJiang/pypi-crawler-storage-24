from typing import Any, List, Optional, Union

from ._corepy_rust import CoreArray
from ._corepy_rust import Series as _RustSeries
from .array import ndarray
from .backend.types import DataType


class Series:
    """
    Pandas-compatible Series implementation backed by CorePy Rust engine.
    """

    def __init__(
        self,
        data: Union[List[Any], ndarray, "Series", _RustSeries],
        index: Optional[List[str]] = None,
        name: str = "",
    ):
        if isinstance(data, _RustSeries):
            self._series = data
            return

        # Prepare name
        name_str = str(name)

        # Prepare data as CoreArray
        if isinstance(data, ndarray):
            if data._core_array is None:
                # Force flattening and creation of CoreArray
                data = ndarray(data.to_list(), dtype=data.dtype, backend=data.backend)
            core_data = data._core_array
        elif isinstance(data, Series):
            core_data = data._series.values
            if index is None:
                index = data.index
            name_str = data.name if not name else name_str
        elif isinstance(data, list):
            import struct

            # Simple inference for now
            is_float = any(isinstance(x, float) for x in data)
            flat_data = [float(x) for x in data] if is_float else [int(x) for x in data]

            # Use CoreArray from rust backend
            if is_float:
                core_data = CoreArray(flat_data, [len(flat_data)])
            else:
                # Temporary workaround: push to float for now until int support is fully fleshed out in py wrapper for CoreArray
                core_data = CoreArray([float(x) for x in data], [len(data)])
        else:
            raise TypeError(f"Unsupported data type for Series: {type(data)}")

        # Construct Rust Series
        if index is None:
            self._series = _RustSeries(name_str, core_data)
        else:
            self._series = _RustSeries(name_str, core_data, index)

    @property
    def name(self) -> str:
        return self._series.name

    @name.setter
    def name(self, value: str):
        self._series.name = str(value)

    @property
    def index(self) -> List[str]:
        return self._series.index

    @property
    def values(self) -> ndarray:
        """Returns the underlying data as a corepy.ndarray"""
        ct = self._series.data

        # Check dtype string returned by series.dtype
        dt_str = self._series.dtype.lower()
        dt = DataType.FLOAT32 if "float" in dt_str else DataType.INT32

        # Create a new ndarray from CoreArray
        arr = ndarray([], dtype=dt)
        arr._backing_data = ct.to_list()
        arr._shape = tuple(ct.shape)
        arr._element_count = ct.element_count
        arr._core_array = ct
        return arr

    @property
    def dtype(self) -> str:
        # the rust series dtype() returns a string like "Float32" or "Int32"
        return self._series.dtype

    def head(self, n: int = 5) -> "Series":
        return Series(self._series.head(n))

    def tail(self, n: int = 5) -> "Series":
        return Series(self._series.tail(n))

    def unique(self) -> "Series":
        return Series(self._series.unique())

    def value_counts(self) -> dict:
        return self._series.value_counts()

    def __len__(self) -> int:
        return len(self._series.index)

    def __repr__(self) -> str:
        # Simple representation inspired by pandas
        max_rows = 10
        total_rows = len(self)

        if total_rows == 0:
            return f"Series([], Name: {self.name}, dtype: {self.dtype})"

        lines = []
        if total_rows <= max_rows:
            # Show all
            vals = self.values.to_list()
            for idx, val in zip(self.index, vals):
                lines.append(f"{idx}\t{val}")
        else:
            # Show head and tail
            head = self.head(5)
            tail = self.tail(5)

            head_vals = head.values.to_list()
            for idx, val in zip(head.index, head_vals):
                lines.append(f"{idx}\t{val}")

            lines.append("...")

            tail_vals = tail.values.to_list()
            for idx, val in zip(tail.index, tail_vals):
                lines.append(f"{idx}\t{val}")

        res = "\n".join(lines)
        res += f"\nName: {self.name}, dtype: {self.dtype}"
        return res
