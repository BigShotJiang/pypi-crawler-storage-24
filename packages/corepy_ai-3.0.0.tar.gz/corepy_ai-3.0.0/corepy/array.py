import logging
from collections.abc import Sequence
from typing import TYPE_CHECKING, Any, Optional, Tuple, Union

# NumPy is NO LONGER a top-level import.
# It is lazily imported only where needed (to_numpy, fast-path fallback).
# The primary backing store is now Rust's CoreArray.
from .backend.errors import BackendError
from .backend.selector import select_backend
from .backend.session import get_session
from .backend.types import BackendType, DataType, OperationProperties, OperationType

if TYPE_CHECKING:
    from numpy.typing import NDArray

    from .buffer import BufferView

logger = logging.getLogger("corepy.array")

from .broadcasting import get_c_strides

# The primary backing store is now Rust's CoreArray.
# It is strictly required. Pure Python and NumPy fallbacks have been removed.
try:
    from ._corepy_rust import CoreArray as _CoreArray
except ImportError as e:
    raise ImportError(
        f"CorePy now requires the Rust extension for all logic. Error: {e}\n"
        "Please compile it using `maturin develop` or equivalent."
    ) from e


class ndarray:
    """
    A multi-dimensional array object (NumPy-compatible naming).

    This is the primary array type in CorePy, designed to be a drop-in
    replacement for NumPy's ndarray where applicable. It automatically
    selects the best execution backend (CPU/GPU) based on data size
    and operation complexity.

    Attributes:
        shape: Tuple of array dimensions.
        dtype: Data type of array elements.
        ndim: Number of dimensions.
        size: Total number of elements.

    Example:
        >>> import corepy as cp
        >>> arr = cp.array([1.0, 2.0, 3.0])
        >>> arr.shape
        (3,)
        >>> arr.dtype
        DataType.FLOAT32
    """

    def __init__(
        self,
        data: Union[Sequence[Any], "ndarray", Any],
        dtype: DataType = DataType.FLOAT32,
        backend: Optional[Union[str, BackendType]] = None,
        device: Optional[str] = None,
    ):
        """
        Initialize an array.

        Args:
            data: Input data (list, tuple, or another array).
            dtype: Data type (default: float32).
            backend: Explicitly requested backend ('cpu', 'gpu').
            device: Explicit device string (e.g. 'cuda:0', 'cpu').
                    If provided, overrides 'backend'.
        """
        self._dtype = dtype

        if isinstance(data, _CoreArray):
            self._core_array = data
            self._shape = tuple(data.shape)
            self._element_count = data.element_count
            self._backing_data = []  # lazily populated
        elif isinstance(data, (list, tuple)):
            # Recursive shape detection
            if len(data) == 0:
                self._shape = (0,)
                self._element_count = 0
                self._backing_data = data
            else:
                shape = []
                curr = data
                while isinstance(curr, (list, tuple)) and len(curr) > 0:
                    shape.append(len(curr))
                    curr = curr[0]

                self._shape = tuple(shape)
            # Calculate element count
            count = 1
            for dim in self._shape:
                count *= dim
            self._element_count = count
            self._backing_data = data
        elif isinstance(data, (bytes, bytearray)):
            self._shape = (len(data),)
            self._element_count = len(data)
            self._backing_data = data  # type: ignore[assignment]
        elif isinstance(data, memoryview):
            self._shape = data.shape if data.shape else (len(data),)
            # Calculate size for ND memoryview
            size = 1
            for dim in self._shape:
                size *= dim
            self._element_count = size
            self._backing_data = data  # type: ignore[assignment]
        elif (
            type(data).__name__ == "ndarray"
            and hasattr(data, "shape")
            and hasattr(data, "size")
        ):
            # Interop for explicit numpy array inputs without importing numpy
            self._shape = tuple(int(d) for d in data.shape)
            self._element_count = int(data.size)
            self._backing_data = data
        else:
            # scalar or error
            self._shape = (1,)
            self._element_count = 1
            self._backing_data = [data]

        # Resolve requested backend/device
        session = get_session()
        device_info = session.device_info

        requested_backend = None
        if device:
            if "metal" in device:
                requested_backend = BackendType.METAL
            elif "cuda" in device or "gpu" in device:
                requested_backend = (
                    BackendType.METAL
                    if device_info.platform_system == "Darwin"
                    else BackendType.CUDA
                )
            elif "cpu" in device:
                requested_backend = BackendType.CPU
        elif backend:
            if isinstance(backend, str):
                requested_backend = BackendType(backend.lower())
            else:
                requested_backend = backend

        # Determine where the data should live initially
        if device is not None:
            if "cuda" in device or "gpu" in device or "metal" in device:
                self._device = "metal"  # Normalize to metal for now
            else:
                self._device = "cpu"
        elif requested_backend in (BackendType.CUDA, BackendType.METAL):
            self._device = "metal" if requested_backend == BackendType.METAL else "cuda"
        else:
            self._device = "cpu"

        # Phase 2: GPU Persistent Buffer Tracking
        self._cpu_data: Optional[Any] = None
        self._gpu_data = None
        self._data_location = "cpu"

        # ===== CoreArray Integration =====
        # CoreArray is the strict backing store for logic.
        if not hasattr(self, "_core_array") or self._core_array is None:
            self._core_array = None
            if self._device == "cpu" and self._dtype == DataType.FLOAT32:
                flat_data = self._flatten_to_f32_list()
                if flat_data is not None and len(flat_data) == self._element_count:
                    self._core_array = _CoreArray(flat_data, list(self._shape))

        # Initialize CPU data from backing_data
        if self._core_array is not None:
            # Rust owns the data; cpu_data will be lazily created in to_numpy()
            self._cpu_data = None
            self._data_location = "cpu"
        elif self._device == "cpu":
            self._cpu_data = None
            self._data_location = "cpu"
        else:
            # GPU device - prepare for lazy transfer
            self._cpu_data = None
            self._data_location = "cpu"  # Start on CPU, transfer on first use

        # Select backend through policy
        context = OperationProperties(
            element_count=self._element_count,
            shape=self._shape,
            dtype_bytes=4,
        )
        session = get_session()
        self._backend_type = select_backend(
            OperationType.MEMORY_BOUND, context, device_info, requested_backend
        )

        # Store original device intent
        self._device_intent = self._device

        logger.debug(f"Array created on {self._backend_type}. Shape={self._shape}")

    def _flatten_to_f32_list(self) -> Optional[list]:
        """Flatten backing data to a flat list of floats for CoreArray creation."""
        if type(self._backing_data).__name__ == "ndarray" and hasattr(
            self._backing_data, "ravel"
        ):
            # Interop for NumPy arrays without importing NumPy
            return [float(x) for x in self._backing_data.ravel()]
        elif isinstance(self._backing_data, (list, tuple)):

            def flatten(items):
                for x in items:
                    if isinstance(x, (list, tuple)):
                        yield from flatten(x)
                    else:
                        yield float(x)

            return list(flatten(self._backing_data))
        return None

    @property
    def backend(self) -> BackendType:
        return self._backend_type

    @property
    def shape(self) -> Tuple[int, ...]:
        return self._shape

    @property
    def dtype(self) -> DataType:
        """Data type of the array elements (NumPy-compatible)."""
        return self._dtype

    @property
    def ndim(self) -> int:
        """Number of array dimensions (NumPy-compatible)."""
        return len(self._shape)

    @property
    def size(self) -> int:
        """Total number of elements in the array (NumPy-compatible)."""
        return self._element_count

    def _should_use_fast_path(self) -> bool:
        """
        Determine if numpy fast path should be used to avoid FFI overhead.

        Returns True for small CPU arrays where NumPy is faster than FFI call.


        """
        from .config import SMALL_ARRAY_THRESHOLD

        return self.size < SMALL_ARRAY_THRESHOLD and self._device == "cpu"

    @property
    def T(self) -> "ndarray":
        """Transpose of the array (NumPy-compatible). For 2D arrays only."""
        return self.transpose()

    def reshape(self, *shape) -> "ndarray":
        """
        Return array reshaped to given dimensions.

        Args:
            shape: New shape as multiple arguments or single tuple/list.

        Returns:
            Reshaped array with same data.
        """
        if len(shape) == 1 and isinstance(shape[0], (tuple, list)):
            shape = tuple(shape[0])

        if self._core_array is not None:
            try:
                ct = self._core_array.reshape(list(shape))
                arr = ndarray(ct.to_list(), dtype=self._dtype, backend=self.backend)
                arr._core_array = ct
                return arr
            except Exception:
                pass

        # Pure Python fallback
        from .ops.math import _flatten, _reshape

        flat = _flatten(self._backing_data)
        reshaped = _reshape(flat, shape)
        return ndarray(reshaped, dtype=self._dtype, backend=self.backend)

    def transpose(self, *axes) -> "ndarray":
        """Return transposed array."""
        import time

        from .profiler.core import record_op

        start_time = time.perf_counter()

        if self._core_array is not None:
            try:
                if len(self.shape) == 2 and (not axes or tuple(axes) == (1, 0)):
                    ct = self._core_array.transpose()
                    arr = ndarray([], dtype=self._dtype, backend=self.backend)
                    arr._backing_data = ct.to_list()
                    arr._shape = tuple(ct.shape)
                    arr._element_count = ct.element_count
                    arr._core_array = ct
                    elapsed_ms = (time.perf_counter() - start_time) * 1000
                    record_op("transpose", elapsed_ms, "CoreArray")
                    return arr
            except Exception:
                pass

        # Priority 1: Metal GPU
        is_simple_transpose = len(self.shape) == 2 and (
            not axes or tuple(axes) == (1, 0)
        )
        if is_simple_transpose and self.backend in (
            BackendType.CUDA,
            BackendType.METAL,
        ):
            view = self._get_buffer_view()
            if view.device.is_metal() and self._element_count >= 1024:
                try:
                    from . import _corepy_rust as ffi  # type: ignore[import-untyped]

                    m, n = self.shape

                    # Create CoreArray for output instead of numpy
                    ct_out = ffi.CoreArray.zeros([n, m])

                    ffi.metal_transpose_f32(view.data_ptr, ct_out.data_ptr, m, n)
                    elapsed_ms = (time.perf_counter() - start_time) * 1000
                    record_op("transpose", elapsed_ms, "Metal")

                    arr = ndarray([], dtype=self._dtype, backend=self.backend)
                    arr._backing_data = ct_out.to_list()
                    arr._shape = tuple(ct_out.shape)
                    arr._element_count = ct_out.element_count
                    arr._core_array = ct_out
                    return arr
                except ImportError:
                    pass

        # Pure Python fallback (only 2D supported in pure python fallback currently)
        if len(self.shape) == 2 and is_simple_transpose:
            from .ops.math import _flatten

            flat = _flatten(self._backing_data)
            m, n = self.shape
            transposed = [[flat[i * n + j] for i in range(m)] for j in range(n)]

            elapsed_ms = (time.perf_counter() - start_time) * 1000
            record_op("transpose", elapsed_ms, "Python")
            return ndarray(transposed, dtype=self._dtype, backend=self.backend)

        raise NotImplementedError(
            "Advanced transpose not supported in pure Python fallback"
        )

    def to(self, device: str) -> "ndarray":
        """
        Explicitly move array to a device (deprecated - use to_device).

        Arguments:
            device: 'cpu' or 'gpu'
        """
        return self.to_device(device)

    def to_device(self, device: str) -> "ndarray":
        """
        Move array to specified device with persistent buffer tracking.

        Phase 2: Lazy transfer - only moves data when needed, caches on both sides.

        Args:
            device: Target device ('cpu', 'metal', 'gpu')

        Returns:
            Self (modified in-place for efficiency)
        """
        # Normalize device name
        if device in ("gpu", "metal"):
            device = "metal"  # Metal is macOS GPU

        # Already on target device?
        if device == "cpu" and self._data_location in ("cpu", "both"):
            self._device = "cpu"
            return self
        elif device == "metal" and self._data_location in ("gpu", "both"):
            self._device = "metal"
            return self

        # Need to transfer
        if device == "metal":
            # TODO: Implement actual GPU transfer when Metal backend ready
            # For now, mark intention but keep data on CPU
            self._device = "metal"
            # In production: self._gpu_data = transfer_to_metal(self._cpu_data)
            # self._data_location = "both"
        elif device == "cpu":
            # GPU → CPU transfer
            if self._gpu_data is not None:
                # TODO: Transfer from GPU
                # self._cpu_data = transfer_from_metal(self._gpu_data)
                pass
            self._device = "cpu"
            self._data_location = "cpu" if self._cpu_data is not None else "cpu"

        return self

    def _ensure_on_device(self, device: str):
        """
        Internal method: Ensure data is available on specified device.

        Lazy transfer - only transfers if not already present.
        """
        if device == "metal":
            if self._data_location not in ("gpu", "both"):
                # Need to transfer to GPU
                self.to_device("metal")
        elif device == "cpu":
            if self._data_location not in ("cpu", "both"):
                # Need to transfer to CPU
                self.to_device("cpu")

    def __getitem__(self, item) -> Union["ndarray", float, int, bool]:
        """
        Access element or slice of the array.

        Args:
            item: Index or slice.

        Returns:
            ndarray or scalar: Result of indexing.
        """
        # CoreArray fast-path: integer indexing without NumPy
        if self._core_array is not None and isinstance(item, int):
            try:
                sub = self._core_array.getitem(item)
                if sub.element_count == 1:
                    return sub.to_list()[0]
                result_arr = ndarray(
                    sub.to_list(), dtype=self._dtype, backend=self.backend
                )
                result_arr._core_array = sub
                return result_arr
            except Exception:
                pass  # Fall through to existing logic

        # Delegate to backing data
        if isinstance(self._backing_data, list):
            # List slicing returns list, indexing returns element
            try:
                result = self._backing_data[item]
            except TypeError:
                # Handle tuple indexing for lists by falling back to pure python nested list indexing
                if isinstance(item, tuple):
                    curr = self._backing_data
                    for idx in item:
                        if isinstance(idx, int):
                            curr = curr[idx]
                        elif isinstance(idx, slice):
                            curr = curr[idx]
                        else:
                            raise TypeError(
                                f"Unsupported index type: {type(idx)}"
                            ) from None
                    result = curr
                else:
                    raise

            if isinstance(result, list):
                return ndarray(result, dtype=self._dtype, backend=self.backend)
            else:
                return result  # scalar
        else:
            # Fallback for other types
            try:
                result = self._backing_data[item]
                if isinstance(result, list):
                    return ndarray(result, dtype=self._dtype, backend=self.backend)
                else:
                    return result
            except TypeError:
                raise NotImplementedError(
                    "Advanced indexing not supported on pure python generic sequences."
                ) from None

    def __repr__(self):
        return f"ndarray({self.to_list()}, backend='{self._backend_type.value}')"

    def item(self) -> float:
        """Return the scalar value of this array if it has 1 element."""
        return float(self._get_scalar_value())

    def to_list(self) -> list:
        if self._core_array is not None:
            return self._core_array.to_list()
        if isinstance(self._backing_data, list):
            return self._backing_data
        if hasattr(self._backing_data, "tolist"):
            return self._backing_data.tolist()
        return list(self._backing_data)

    def __add__(self, other: Any) -> "ndarray":
        """Element-wise addition."""
        return self._binary_op("add", other)

    def __sub__(self, other: Any) -> "ndarray":
        """Element-wise subtraction."""
        return self._binary_op("sub", other)

    def __mul__(self, other: Any) -> "ndarray":
        """Element-wise multiplication."""
        return self._binary_op("mul", other)

    def __truediv__(self, other: Any) -> "ndarray":
        """Element-wise division."""
        return self._binary_op("div", other)

    def __pow__(self, other: Any) -> "ndarray":
        """Element-wise power."""
        return self._binary_op("power", other)

    def __mod__(self, other: Any) -> "ndarray":
        """Element-wise modulo."""
        return self._binary_op("mod", other)

    def __floordiv__(self, other: Any) -> "ndarray":
        """Element-wise floor division."""
        return self._binary_op("floor_div", other)

    def __neg__(self) -> "ndarray":
        """Element-wise negation."""
        if self._core_array is not None:
            result_ca = self._core_array.neg()
            result = ndarray(
                result_ca.to_list(), dtype=self._dtype, backend=self.backend
            )
            result._core_array = result_ca
            return result
        from .ops.math import _flatten

        flat = _flatten(self._backing_data)
        return ndarray([-x for x in flat], dtype=self._dtype, backend=self.backend)

    def __abs__(self) -> "ndarray":
        """Element-wise absolute value."""
        if self._core_array is not None:
            result_ca = self._core_array.abs()
            result = ndarray(
                result_ca.to_list(), dtype=self._dtype, backend=self.backend
            )
            result._core_array = result_ca
            return result
        from .ops.math import _flatten

        flat = _flatten(self._backing_data)
        return ndarray([abs(x) for x in flat], dtype=self._dtype, backend=self.backend)

    def __radd__(self, other: Any) -> "ndarray":
        """Right-hand addition."""
        return self._binary_op("add", other)

    def __rsub__(self, other: Any) -> "ndarray":
        """Right-hand subtraction: other - self."""
        if isinstance(other, (int, float)):
            other = ndarray([float(other)] * self._element_count, device=self._device)
        return other.__sub__(self)

    def __rmul__(self, other: Any) -> "ndarray":
        """Right-hand multiplication."""
        return self._binary_op("mul", other)

    def __rtruediv__(self, other: Any) -> "ndarray":
        """Right-hand division: other / self."""
        if isinstance(other, (int, float)):
            other = ndarray([float(other)] * self._element_count, device=self._device)
        return other.__truediv__(self)

    def __rpow__(self, other: Any) -> "ndarray":
        """Right-hand power: other ** self."""
        if isinstance(other, (int, float)):
            other = ndarray([float(other)] * self._element_count, device=self._device)
        return other.__pow__(self)

    def matmul(self, other: Any) -> "ndarray":
        """Matrix multiplication (@ operator)."""
        # Ensure other is ndarray
        if not isinstance(other, ndarray):
            other = ndarray(other, backend=self.backend)

        # Phase 1: GPU fallback - if we're on GPU but operation not supported, use CPU
        if self.backend in (BackendType.CUDA, BackendType.METAL):
            from .backend.dispatch import Dispatcher
            from .backend.errors import OperationNotSupportedError

            # Check if GPU kernel exists
            try:
                Dispatcher.get_kernel("matmul", self.backend)
            except OperationNotSupportedError:
                # GPU doesn't support matmul, fall back to CPU
                logger.info("GPU matmul not supported, falling back to CPU")
                cpu_self = ndarray(self.to_list(), backend=BackendType.CPU)
                cpu_other = ndarray(other.to_list(), backend=BackendType.CPU)
                return cpu_self.matmul(cpu_other)

        # Phase 2: Automatic GPU Switching for large operations
        # If operation is large enough, promoting to GPU might be faster
        if self.backend == BackendType.CPU:
            # Basic heuristic: if both dims >= 2048
            if (
                len(self.shape) >= 2
                and self.shape[-1] >= 2048
                and self.shape[-2] >= 2048
            ):
                # Check if Metal is available
                from .backend import get_system_capabilities

                caps = get_system_capabilities()
                if caps.get("gpu", {}).get("metal_available", False):
                    # Promote to GPU for large matmul
                    logger.info("Auto-switching large matmul to GPU based on size")
                    gpu_self = ndarray(self.to_list(), device="metal")
                    gpu_other = ndarray(other.to_list(), device="metal")
                    return gpu_self.matmul(gpu_other)

        # Delegate to backend implementation
        # Start timing
        import time

        from .profiler.core import record_op

        start_time = time.perf_counter()

        # Fast path: CoreArray Rust method (via FFI function)
        if (
            self.backend == BackendType.CPU
            and self._core_array is not None
            and other._core_array is not None
            and len(self.shape) == 2
            and len(other.shape) == 2
        ):
            from ._corepy_rust import CoreArray as _CT
            from ._corepy_rust import array_matmul_2d_f32

            # Create output array
            m, k1 = self.shape
            k2, n = other.shape

            # Use CoreArray's underlying data pointers for zero-copy
            # DType 0 is Float32
            result_ct = _CT.zeros([m, n], None)  # Default to Float32

            array_matmul_2d_f32(
                self._core_array.data_ptr,
                other._core_array.data_ptr,
                result_ct.data_ptr,
                m,
                k1,
                n,
            )

            # Create ndarray wrapper
            result_arr = ndarray(result_ct, dtype=self._dtype, backend=self.backend)

            elapsed_ms = (time.perf_counter() - start_time) * 1000
            record_op("matmul", elapsed_ms, "CoreArray-Rust")
            return result_arr

        from .backend.dispatch import dispatch_kernel

        result = dispatch_kernel(
            "matmul", self.backend, self, other, shape_a=self.shape, shape_b=other.shape
        )

        elapsed_ms = (time.perf_counter() - start_time) * 1000
        record_op("matmul", elapsed_ms, self.backend.name)

        return ndarray(result, dtype=self._dtype, backend=self.backend)

    def __matmul__(self, other: Any) -> "ndarray":
        """Matrix multiplication (@ operator)."""
        return self.matmul(other)

    def _get_scalar_value(self) -> float:
        """Extract scalar value from single-element array."""
        if self._element_count != 1:
            raise ValueError("Cannot compare non-scalar array")
        if isinstance(self._backing_data, list):
            return float(self._backing_data[0])
        return float(self._backing_data)  # type: ignore[arg-type]

    def __lt__(self, other: Any) -> bool:
        """Less than comparison (for scalar arrays)."""
        return self._get_scalar_value() < (
            other._get_scalar_value() if isinstance(other, ndarray) else float(other)
        )

    def __le__(self, other: Any) -> bool:
        """Less than or equal comparison (for scalar arrays)."""
        return self._get_scalar_value() <= (
            other._get_scalar_value() if isinstance(other, ndarray) else float(other)
        )

    def __gt__(self, other: Any) -> bool:
        """Greater than comparison (for scalar arrays)."""
        return self._get_scalar_value() > (
            other._get_scalar_value() if isinstance(other, ndarray) else float(other)
        )

    def __ge__(self, other: Any) -> bool:
        """Greater than or equal comparison (for scalar arrays)."""
        return self._get_scalar_value() >= (
            other._get_scalar_value() if isinstance(other, ndarray) else float(other)
        )

    def _get_buffer_view(self) -> "BufferView":
        """
        Extract BufferView for zero-copy FFI.

        Returns a BufferView abstraction that provides:
        - Stride awareness (is_contiguous check)
        - Device tracking (CPU/GPU)
        - Explicit ownership (keeps data alive)
        - Cleaner dispatch paths

        Returns:
            BufferView wrapping the backing data

        Raises:
            ValueError: If backing data cannot be wrapped
        """
        from .buffer import CPU, METAL, BufferView, from_buffer

        # Determine target device
        target_device = CPU
        if self.backend in (BackendType.CUDA, BackendType.METAL):
            import platform

            if platform.system() == "Darwin":
                target_device = METAL
            # Future: CUDA support

        # Fast path: CoreArray already has proper BufferView data
        if self._core_array is not None:
            from .buffer import BufferView, Device, DeviceType, MemoryType

            return BufferView(
                data_ptr=self._core_array.data_ptr,
                shape=tuple(self._core_array.shape),
                strides=None,  # C-contiguous
                dtype=self._dtype,
                device=Device(DeviceType.CPU),
                memory_type=MemoryType.NORMAL,
                owner=self._core_array,
                writable=False,
            )

        # Case 2: bytes/bytearray/memoryview/numpy (buffer protocol)
        if not isinstance(self._backing_data, list):
            try:
                mv = memoryview(self._backing_data)  # type: ignore
                return from_buffer(
                    mv,
                    dtype=self._dtype,
                    shape=self._shape,
                    device=target_device,
                )
            except TypeError:
                pass

        # Case 3: List (convert to bytearray)
        elif isinstance(self._backing_data, list):
            import struct

            # Flatten nested lists
            def flatten(items):
                for x in items:
                    if isinstance(x, (list, tuple)):
                        yield from flatten(x)
                    else:
                        yield x

            buffer = bytearray()
            if self._dtype == DataType.FLOAT32:
                for x in flatten(self._backing_data):
                    buffer.extend(struct.pack("f", float(x)))
            elif self._dtype == DataType.INT32:
                for x in flatten(self._backing_data):
                    buffer.extend(struct.pack("i", int(x)))
            elif self._dtype == DataType.FLOAT64:
                for x in flatten(self._backing_data):
                    buffer.extend(struct.pack("d", float(x)))
            elif self._dtype == DataType.INT64:
                for x in flatten(self._backing_data):
                    buffer.extend(struct.pack("q", int(x)))
            else:
                for x in flatten(self._backing_data):
                    buffer.extend(struct.pack("f", float(x)))

            return from_buffer(
                buffer, dtype=self._dtype, shape=self._shape, device=target_device
            )

        # Case 4: Unknown type
        else:
            raise ValueError(
                f"Cannot create BufferView from {type(self._backing_data)}. "
                "Object must be NumPy array, list, or support buffer protocol."
            )

    def _get_buffer_pointer(self, dtype_char="u1") -> Tuple[int, int, Any]:
        """
        Extract raw buffer pointer for zero-copy FFI.

        Args:
            dtype_char: NumPy dtype character code ('u1'=uint8, 'f4'=float32, 'i4'=int32)

        Returns:
            tuple: (pointer: int, count: int, buffer_ref: Any)
                   buffer_ref must be kept alive during FFI call

        Raises:
            ValueError: If backing data cannot be converted to buffer
        """
        import ctypes

        # Case 0: CoreArray (zero-copy, 64-byte aligned, no NumPy needed)
        if self._core_array is not None and dtype_char == "f4":
            return (
                self._core_array.data_ptr,
                self._core_array.element_count,
                self._core_array,  # prevent GC
            )

        # Case 2: bytes/bytearray/memoryview (buffer protocol)
        elif isinstance(self._backing_data, (bytes, bytearray, memoryview)):
            mv = memoryview(self._backing_data)

            # Get pointer via ctypes
            c_type: type
            if dtype_char == "u1":
                c_type = ctypes.c_uint8
            elif dtype_char == "f4":
                c_type = ctypes.c_float
            elif dtype_char == "i4":
                c_type = ctypes.c_int32
            else:
                raise ValueError(f"Unsupported dtype: {dtype_char}")

            # Cast memoryview to c_type array
            c_buffer = (c_type * len(mv)).from_buffer(mv)
            ptr = ctypes.addressof(c_buffer)
            count = len(mv)

            return (ptr, count, (mv, c_buffer))

        # Case 3: List (convert to bytearray)
        elif isinstance(self._backing_data, list):
            import struct

            if dtype_char == "u1":
                # Simplified flattening for POC
                def flatten(items):
                    for x in items:
                        if isinstance(x, (list, tuple)):
                            yield from flatten(x)
                        else:
                            yield x

                buffer = bytearray(int(x) for x in flatten(self._backing_data))
                count = len(buffer)
            elif dtype_char == "f4":
                import struct

                def flatten(items):
                    for x in items:
                        if isinstance(x, (list, tuple)):
                            yield from flatten(x)
                        else:
                            yield x

                buffer = bytearray()
                for x in flatten(self._backing_data):
                    buffer.extend(struct.pack("f", float(x)))
                count = self._element_count
            elif dtype_char == "i4":
                import struct

                def flatten(items):
                    for x in items:
                        if isinstance(x, (list, tuple)):
                            yield from flatten(x)
                        else:
                            yield x

                buffer = bytearray()
                for x in flatten(self._backing_data):
                    buffer.extend(struct.pack("i", int(x)))
                count = self._element_count
            else:
                raise ValueError(f"Unsupported dtype: {dtype_char}")

            c_buffer = (ctypes.c_uint8 * len(buffer)).from_buffer(buffer)
            ptr = ctypes.addressof(c_buffer)

            return (ptr, count, (buffer, c_buffer))

        # Case 4: Generic buffer protocol fallback
        else:
            try:
                mv = memoryview(self._backing_data)  # type: ignore[arg-type]
                # Recursive(ish) logic for memoryview path
                # Just fail for now to keep simple, as case 2 handles mv
                ptr = ctypes.addressof((ctypes.c_byte * len(mv)).from_buffer(mv))
                return (ptr, len(mv), mv)
            except TypeError:
                raise ValueError(
                    f"Cannot extract buffer from {type(self._backing_data)}. "
                    "Object must support buffer protocol or be a list."
                ) from None

    def all(self) -> "ndarray":
        """Returns True if all elements evaluate to True."""
        try:
            from ._corepy_rust import array_all  # type: ignore[import-untyped]

            ptr, count, _ref = self._get_buffer_pointer("u1")
            result = array_all(ptr, count)

            return ndarray(result, dtype=DataType.BOOL, backend=self.backend)

        except ImportError:
            logger.warning("Rust extension not available.")
            from .backend.dispatch import dispatch_kernel

            result = dispatch_kernel("all", self.backend, self._backing_data)
            return ndarray(result, dtype=DataType.BOOL, backend=self.backend)

    def any(self) -> "ndarray":
        """Returns True if any element evaluates to True."""
        try:
            from ._corepy_rust import array_any  # type: ignore[import-untyped]

            ptr, count, _ref = self._get_buffer_pointer("u1")
            result = array_any(ptr, count)

            return ndarray(result, dtype=DataType.BOOL, backend=self.backend)
        except ImportError:
            from .backend.dispatch import dispatch_kernel

            result = dispatch_kernel("any", self.backend, self._backing_data)
            return ndarray(result, dtype=DataType.BOOL, backend=self.backend)

    def sum(self) -> "ndarray":
        """Returns sum of all elements."""
        import time

        from .profiler.core import record_op

        start_time = time.perf_counter()

        # CoreArray method call
        if self._core_array is not None:
            result = float(self._core_array.sum())
            elapsed_ms = (time.perf_counter() - start_time) * 1000
            record_op("sum", elapsed_ms, "CoreArray-Rust")
            return ndarray([result], dtype=self._dtype, backend=self.backend)

        from ._corepy_rust import (  # type: ignore[import-untyped]
            array_sum_f32,
            array_sum_f32_strided,
            array_sum_i32,
            metal_sum_f32,
        )

        # Use BufferView for dispatch decision
        view = self._get_buffer_view()

        if self._dtype == DataType.INT32:
            # INT32 path (contiguous only for now)
            ptr, count, _ref = self._get_buffer_pointer("i4")
            result = array_sum_i32(ptr, count)
        elif view.device.is_metal():
            # Metal GPU path
            result = metal_sum_f32(view.data_ptr, view.element_count)
        elif view.is_contiguous():
            # Fast path: contiguous f32
            result = array_sum_f32(view.data_ptr, view.element_count)
        else:
            # Zero-copy path: strided f32
            result = array_sum_f32_strided(
                view.data_ptr,
                list(view.shape),
                list(view.shape),  # type: ignore[arg-type]
                list(view.strides)
                if view.strides is not None
                else [s * view.dtype.itemsize for s in get_c_strides(view.shape)],  # type: ignore[arg-type]
            )

        elapsed_ms = (time.perf_counter() - start_time) * 1000
        record_op("sum", elapsed_ms, "CPU" if not view.device.is_metal() else "Metal")
        return ndarray([result], dtype=self._dtype, backend=self.backend)

    def mean(self) -> "ndarray":
        """Returns arithmetic mean of all elements."""
        import time

        from .profiler.core import record_op

        start_time = time.perf_counter()

        # CoreArray method call
        if self._core_array is not None:
            result = float(self._core_array.mean())
            elapsed_ms = (time.perf_counter() - start_time) * 1000
            record_op("mean", elapsed_ms, "CoreArray-Rust")
            return ndarray([result], dtype=DataType.FLOAT32, backend=self.backend)

        from ._corepy_rust import (  # type: ignore[import-untyped]
            array_mean_f32,
            array_mean_f32_strided,
            metal_mean_f32,
        )

        # Use BufferView for dispatch decision
        view = self._get_buffer_view()

        if view.device.is_metal():
            # Metal GPU path
            result = metal_mean_f32(view.data_ptr, view.element_count)
        elif view.is_contiguous():
            # Fast path: contiguous f32
            result = array_mean_f32(view.data_ptr, view.element_count)
        else:
            # Zero-copy path: strided f32
            result = array_mean_f32_strided(
                view.data_ptr,
                list(view.shape),
                list(view.shape),  # type: ignore[arg-type]
                list(view.strides)
                if view.strides is not None
                else [s * view.dtype.itemsize for s in get_c_strides(view.shape)],  # type: ignore[arg-type]
            )

        elapsed_ms = (time.perf_counter() - start_time) * 1000
        record_op("mean", elapsed_ms, "CPU" if not view.device.is_metal() else "Metal")
        return ndarray([result], dtype=DataType.FLOAT32, backend=self.backend)

    def std(self) -> "ndarray":
        """Returns standard deviation of all elements."""
        from .backend.dispatch import dispatch_kernel

        result = dispatch_kernel("std", self.backend, self._backing_data)
        return ndarray(result, dtype=DataType.FLOAT32, backend=self.backend)

    def max(self) -> "ndarray":
        """Returns maximum value of all elements."""
        import time

        from .profiler.core import record_op

        start_time = time.perf_counter()

        # Priority 1: Metal GPU
        target_view = self._get_buffer_view()
        from . import _corepy_rust as ffi

        if (
            self.backend in (BackendType.CUDA, BackendType.METAL)
            and target_view.device.is_metal()
            and self._element_count >= 1024
        ):
            result = ffi.metal_max_f32(target_view.data_ptr, self._element_count)
            elapsed_ms = (time.perf_counter() - start_time) * 1000
            record_op("max", elapsed_ms, "Metal")
            return ndarray([result], dtype=self._dtype, backend=self.backend)

        # Priority 2: CPU Rust (Strided)
        view = self._get_buffer_view()
        result = ffi.array_max_f32_strided(
            view.data_ptr,
            list(view.shape),
            list(view.strides)
            if view.strides is not None
            else [s * view.dtype.itemsize for s in get_c_strides(view.shape)],  # type: ignore[arg-type]
        )
        elapsed_ms = (time.perf_counter() - start_time) * 1000
        record_op("max", elapsed_ms, "Rust-CPU")
        return ndarray([result], dtype=self._dtype, backend=self.backend)

    def min(self) -> "ndarray":
        """Returns minimum value of all elements."""
        import time

        from .profiler.core import record_op

        start_time = time.perf_counter()

        # Priority 1: Metal GPU
        target_view = self._get_buffer_view()
        from . import _corepy_rust as ffi

        if (
            self.backend in (BackendType.CUDA, BackendType.METAL)
            and target_view.device.is_metal()
            and self._element_count >= 1024
        ):
            result = ffi.metal_min_f32(target_view.data_ptr, self._element_count)
            elapsed_ms = (time.perf_counter() - start_time) * 1000
            record_op("min", elapsed_ms, "Metal")
            return ndarray([result], dtype=self._dtype, backend=self.backend)

        # Priority 2: CPU Rust (Strided)
        view = self._get_buffer_view()
        result = ffi.array_min_f32_strided(
            view.data_ptr,
            list(view.shape),
            list(view.strides)
            if view.strides is not None
            else [s * view.dtype.itemsize for s in get_c_strides(view.shape)],  # type: ignore[arg-type]
        )
        elapsed_ms = (time.perf_counter() - start_time) * 1000
        record_op("min", elapsed_ms, "Rust-CPU")
        return ndarray([result], dtype=self._dtype, backend=self.backend)

    def to_list(self) -> list:
        """Return the array data as a nested Python list."""
        if self._core_array is not None:
            from .ops.math import _reshape

            flat = self._core_array.to_list()
            return _reshape(flat, self._shape)

        # Fallback to backing data (already a list or buffer protocol)
        if isinstance(self._backing_data, list):
            return self._backing_data

        # Buffer protocols
        return self.to_numpy().tolist()

    def copy(self) -> "ndarray":
        """Returns a copy of the array."""
        if isinstance(self._backing_data, list):
            new_data = list(self._backing_data)
        else:
            new_data = self._backing_data  # type: ignore[assignment]
        return ndarray(new_data, dtype=self._dtype, backend=self.backend)

    def to_numpy(self):
        """
        Convert the array to a NumPy array.
        Returns:
            NDArray: NumPy array containing the data.
        """
        try:
            import numpy as np
        except ImportError:
            raise RuntimeError(
                "NumPy is required to output as a NumPy array!"
            ) from None

        # Phase 2: Check if we already have CPU data cached
        if self._cpu_data is not None:
            return self._cpu_data

        # CoreArray path: reconstruct numpy from Rust-owned memory
        if self._core_array is not None:
            flat = self._core_array.to_list()
            arr = np.array(flat, dtype=np.float32).reshape(self._shape)
            return arr

        # Original logic for backward compatibility
        if type(self._backing_data).__name__ == "ndarray":
            return self._backing_data
        elif isinstance(self._backing_data, list):

            def flatten(items):
                for x in items:
                    if isinstance(x, (list, tuple)):
                        yield from flatten(x)
                    else:
                        yield x

            dtype_map = {
                DataType.FLOAT32: np.float32,
                DataType.FLOAT64: np.float64,
                DataType.INT32: np.int32,
                DataType.INT64: np.int64,
                DataType.BOOL: bool,
            }
            np_dtype = dtype_map.get(self._dtype, np.float32)
            return np.array(list(flatten(self._backing_data)), dtype=np_dtype).reshape(
                self.shape
            )
        else:
            # Fallback for buffer protocol objects
            return np.array(self._backing_data).reshape(self.shape)

    def __len__(self) -> int:
        """Returns the number of elements in the array."""
        return self._element_count

    # =========================================================================
    # Convenience Methods (UFUNC CORE-12)
    # =========================================================================

    def sort(self, descending: bool = False) -> "ndarray":
        """Return a sorted copy of the array."""
        from .ops.sorting import sort as _sort

        return _sort(self, descending=descending)

    def argsort(self, descending: bool = False) -> "ndarray":
        """Return indices that would sort the array."""
        from .ops.sorting import argsort as _argsort

        return _argsort(self, descending=descending)

    def argmax(self) -> int:
        """Return index of maximum element."""
        from .ops.searching import argmax as _argmax

        return _argmax(self)

    def argmin(self) -> int:
        """Return index of minimum element."""
        from .ops.searching import argmin as _argmin

        return _argmin(self)

    def is_even(self) -> "ndarray":
        """Element-wise is_even: returns 1.0 where x % 2 == 0."""
        from .ops.ufunc_engine import ufunc_unary

        return ufunc_unary("is_even", self)

    def is_odd(self) -> "ndarray":
        """Element-wise is_odd: returns 1.0 where x % 2 != 0."""
        from .ops.ufunc_engine import ufunc_unary

        return ufunc_unary("is_odd", self)

    # =========================================================================
    # Convenience Methods (UFUNC CORE-50)
    # =========================================================================

    def sin(self) -> "ndarray":
        from .ops.trigonometry import sin as _sin

        return _sin(self)

    def cos(self) -> "ndarray":
        from .ops.trigonometry import cos as _cos

        return _cos(self)

    def tan(self) -> "ndarray":
        from .ops.trigonometry import tan as _tan

        return _tan(self)

    def exp(self) -> "ndarray":
        from .ops.exponential import exp as _exp

        return _exp(self)

    def log(self) -> "ndarray":
        from .ops.exponential import log as _log

        return _log(self)

    def sqrt(self) -> "ndarray":
        from .ops.exponential import sqrt as _sqrt

        return _sqrt(self)

    def floor(self) -> "ndarray":
        from .ops.rounding import floor as _floor

        return _floor(self)

    def ceil(self) -> "ndarray":
        from .ops.rounding import ceil as _ceil

        return _ceil(self)

    def round(self, decimals: int = 0) -> "ndarray":
        from .ops.rounding import round_ as _round

        return _round(self)

    def clip(self, a_min: float, a_max: float) -> "ndarray":
        from .ops.rounding import clip as _clip

        return _clip(self, a_min, a_max)

    def square(self) -> "ndarray":
        from .ops.special import square as _sq

        return _sq(self)

    def reciprocal(self) -> "ndarray":
        from .ops.special import reciprocal as _rcp

        return _rcp(self)

    def cumsum(self) -> "ndarray":
        from .ops.reduction import cumsum as _cs

        return _cs(self)

    def cumprod(self) -> "ndarray":
        from .ops.reduction import cumprod as _cp

        return _cp(self)

    def prod(self) -> float:
        from .ops.reduction import prod as _prod

        return _prod(self)

    def std(self) -> float:
        from .ops.reduction import std as _std

        return _std(self)

    def var(self) -> float:
        from .ops.reduction import var as _var

        return _var(self)

    def _binary_op(self, op: str, other: Any) -> "ndarray":
        """Helper for binary operations via Rust FFI."""
        import time

        from .profiler.core import record_op

        start_time = time.perf_counter()
        if isinstance(other, (int, float)):
            other = ndarray([float(other)] * self._element_count, device=self._device)
        elif isinstance(other, ndarray) and other._element_count == 1:
            # Broadcasting: single-element array to match self's size
            scalar_val = (
                other._backing_data[0]
                if isinstance(other._backing_data, list)
                else float(other._backing_data)  # type: ignore[arg-type]
            )
            other = ndarray(
                [float(scalar_val)] * self._element_count, device=self._device
            )  # type: ignore[arg-type]

        if not isinstance(other, ndarray):
            raise ValueError("Binary ops require array or scalar")

        if other.backend != self.backend:
            raise BackendError(f"Backend mismatch: {self.backend} vs {other.backend}")

        if self._core_array is not None and other._core_array is not None:
            op_map = {
                "add": self._core_array.add,
                "sub": self._core_array.sub,
                "mul": self._core_array.mul,
                "div": self._core_array.div,
                "power": self._core_array.power,
                "mod": self._core_array.mod_op,
                "floor_div": self._core_array.floor_div,
            }
            rust_op = op_map.get(op)
            if rust_op is not None:
                result_array = rust_op(other._core_array)
                result_arr = ndarray(
                    result_array.to_list(),
                    dtype=self._dtype,
                    backend=self.backend,
                )
                result_arr._core_array = result_array
                elapsed_ms = (time.perf_counter() - start_time) * 1000
                record_op(op, elapsed_ms, "CoreArray-Rust")
                return result_arr

        # Priority 1: Metal GPU (if available and large enough OR if broadcasting needed)
        # We generally avoid GPU overhead for very small arrays (< 1024 elements)
        # but allow it for broadcasting since CPU fallback doesn't support it yet
        view = self._get_buffer_view()
        is_metal = view.device.is_metal()
        use_metal = (
            self.backend in (BackendType.CUDA, BackendType.METAL)
            and is_metal
            and (self._element_count >= 1024 or self.shape != other.shape)
        )
        # print(f"DEBUG: use_metal={use_metal} is_metal={is_metal} count={self._element_count}")

        if use_metal:
            # ...
            try:
                # Get input buffers (f32 hardcoded for now)
                # Note: buffer pointers on Metal are actually encoded offsets/handles
                # handled by the Rust/Metal bridge.
                import math

                from . import _corepy_rust as ffi  # type: ignore[import-untyped]

                size = 1
                for d in self.shape:
                    size *= d

                ct_out = ffi.CoreArray.zeros([size])
                # We need to reshape the output after metal op if it's N-dimensional
                ptr_out = ct_out.data_ptr

                # Dispatch
                # Dispatch
                success = False

                # Check for broadcasting scenarios
                if self.shape != other.shape:
                    try:
                        from .broadcasting import (
                            broadcast_shapes,
                            compute_broadcast_strides,
                            get_c_strides,
                        )

                        target_shape = broadcast_shapes(self.shape, other.shape)
                        size = 1
                        for d in target_shape:
                            size *= d

                        # Allocate output using CoreArray
                        ct_out = ffi.CoreArray.zeros([size])
                        ptr_out = ct_out.data_ptr

                        # Compute strides
                        strides_a = compute_broadcast_strides(
                            self.shape, target_shape, get_c_strides(self.shape)
                        )
                        strides_b = compute_broadcast_strides(
                            other.shape, target_shape, get_c_strides(other.shape)
                        )

                        op_map = {"add": 0, "sub": 1, "mul": 2, "div": 3}
                        op_code = op_map.get(op)

                        if op_code is not None:
                            ffi.metal_broadcast_op(
                                op_code,
                                view.data_ptr,
                                other._get_buffer_view().data_ptr,
                                ptr_out,
                                list(target_shape),
                                strides_a,
                                strides_b,
                                size,
                                self._element_count,
                                other._element_count,
                            )
                            success = True
                    except (ValueError, AttributeError, ImportError):
                        # Fallback to Rust/CPU if broadcasting fails or not implemented
                        pass

                if not success and self.shape == other.shape:
                    if op == "add":
                        ffi.metal_add_f32(
                            view.data_ptr,
                            other._get_buffer_view().data_ptr,
                            ptr_out,
                            self._element_count,
                        )
                        success = True
                    elif op == "sub":
                        ffi.metal_sub_f32(
                            view.data_ptr,
                            other._get_buffer_view().data_ptr,
                            ptr_out,
                            self._element_count,
                        )
                        success = True
                    elif op == "mul":
                        ffi.metal_mul_f32(
                            view.data_ptr,
                            other._get_buffer_view().data_ptr,
                            ptr_out,
                            self._element_count,
                        )
                        success = True
                    elif op == "div":
                        ffi.metal_div_f32(
                            view.data_ptr,
                            other._get_buffer_view().data_ptr,
                            ptr_out,
                            self._element_count,
                        )
                        success = True

                if success:
                    elapsed_ms = (time.perf_counter() - start_time) * 1000
                    record_op(op, elapsed_ms, "Metal")
                    # Result is currently on CPU (transferred back by metal_backend implementation logic
                    # which copies to output buffer).
                    # Future optimization: Keep on GPU.
                    # Reshape the 1D corearray to target dimensions
                    target_out_shape = (
                        target_shape if self.shape != other.shape else self.shape
                    )
                    ct_out = ct_out.reshape(list(target_out_shape))
                    out_arr = ndarray(
                        ct_out.to_list(), dtype=self._dtype, backend=self.backend
                    )
                    out_arr._core_array = ct_out
                    return out_arr

            except ImportError:
                pass  # Fallback to Rust/CPU

        # Priority 2: Try Rust CPU kernels (fastest for medium/large arrays)
        if self.backend == BackendType.CPU:  # Priority 2: Rust CPU kernels
            try:
                from . import _corepy_rust as ffi  # type: ignore[import-untyped]

                # Get input buffers (f32 hardcoded for now)
                ptr_a, count_a, _ref_a = self._get_buffer_pointer("f4")
                ptr_b, count_b, _ref_b = other._get_buffer_pointer("f4")

                if count_a != count_b:
                    raise ValueError(f"Shape mismatch: {count_a} vs {count_b}")

                # Allocate output via Rust CoreArray (64-byte aligned, zero-init)
                out_array = _CoreArray.zeros(list(self._shape))
                ptr_out = out_array.data_ptr

                # Dispatch to Rust kernels (writes directly into aligned buffer)
                if op == "add":
                    ffi.array_add_f32(ptr_a, ptr_b, ptr_out, count_a)
                elif op == "sub":
                    ffi.array_sub_f32(ptr_a, ptr_b, ptr_out, count_a)
                elif op == "mul":
                    ffi.array_mul_f32(ptr_a, ptr_b, ptr_out, count_a)
                elif op == "div":
                    ffi.array_div_f32(ptr_a, ptr_b, ptr_out, count_a)

                # Wrap result — CoreArray owns the memory
                result_arr = ndarray(
                    out_array.to_list(),
                    dtype=self._dtype,
                    backend=self.backend,
                )
                result_arr._core_array = out_array
                elapsed_ms = (time.perf_counter() - start_time) * 1000
                record_op(op, elapsed_ms, "Rust-CPU")
                return result_arr

            except ImportError:
                pass  # Fall through to dispatch_kernel

        # Priority 3: Fallback to the dynamic dispatch system for other backends (Mock, CUDA, etc.)
        from .backend.dispatch import dispatch_kernel

        start_time = time.perf_counter()
        result = dispatch_kernel(
            op, self.backend, self._backing_data, other._backing_data
        )
        elapsed_ms = (time.perf_counter() - start_time) * 1000
        from .profiler.core import record_op

        record_op(op, elapsed_ms, self.backend.name)

        out_arr = ndarray([], dtype=self._dtype, backend=self.backend)
        out_arr._backing_data = result
        out_arr._shape = self.shape
        out_arr._element_count = self._element_count
        return out_arr


#     def matmul(self, other: "ndarray") -> "ndarray":
#         """Matrix multiplication (handles 1D dot product and 2D matmul)."""
#         import time
#
#         from .profiler.core import record_op
#
#         start_time = time.perf_counter()
#         if not isinstance(other, ndarray):
#             raise ValueError("matmul requires array")
#
# Fast path: Use NumPy for small arrays to avoid FFI overhead
#         if self._should_use_fast_path() and other._should_use_fast_path():
#             import numpy as np
#
#             np_a = self.to_numpy()
#             np_b = other.to_numpy()
#             result = np.matmul(np_a, np_b)
#             elapsed_ms = (time.perf_counter() - start_time) * 1000
#             record_op("matmul", elapsed_ms, "NumPy-Fast")
#             return ndarray(result, dtype=self._dtype, backend=self.backend)
#
#         if self.backend == BackendType.CPU or (
#             self.backend in (BackendType.CUDA, BackendType.METAL)
#             and "metal" in str(self._get_buffer_view().device)
#         ):
#             try:
#                 from . import _corepy_rust as ffi  # type: ignore[import-untyped]
#
# Check for Metal dispatch
#                 view = self._get_buffer_view()
#                 is_metal = view.device.is_metal()
#
#                 if is_metal and len(self.shape) == 2 and len(other.shape) == 2:
# Metal Matrix Multiplication
#                     m, k1 = self.shape
#                     k2, n = other.shape
#
#                     if k1 != k2:
#                         raise ValueError(
#                             f"Matrix dimension mismatch: ({m}, {k1}) @ ({k2}, {n})"
#                         )
#
#                     view_b = other._get_buffer_view()
#
# Allocate output
#                     import numpy as np
#
#                     final_np = np.empty((m, n), dtype=np.float32)
#                     ptr_out = final_np.__array_interface__["data"][0]
#
#                     ffi.metal_matmul_f32(
#                         view.data_ptr, view_b.data_ptr, ptr_out, m, k1, n
#                     )
#
#                     elapsed_ms = (time.perf_counter() - start_time) * 1000
#                     record_op("matmul", elapsed_ms, "Metal")
#                     return ndarray(final_np, dtype=self._dtype, backend=self.backend)
#
# Case 1: Dot Product (1D @ 1D)
#                 if len(self.shape) == 1 and len(other.shape) == 1 and not is_metal:
#                     ptr_a, count_a, _ref_a = self._get_buffer_pointer("f4")
#                     ptr_b, count_b, _ref_b = other._get_buffer_pointer("f4")
#
#                     if count_a != count_b:
#                         raise ValueError(
#                             f"Dot product size mismatch: {count_a} vs {count_b}"
#                         )
#
#                     result = ffi.array_matmul_f32(ptr_a, ptr_b, count_a)
#                     elapsed_ms = (time.perf_counter() - start_time) * 1000
#                     record_op("matmul", elapsed_ms, "CPU")
#                     return ndarray(result, dtype=self._dtype, backend=self.backend)
#
# Case 2: Matrix Multiplication (2D @ 2D) - CPU
#                 elif len(self.shape) == 2 and len(other.shape) == 2 and not is_metal:
#                     m, k1 = self.shape
#                     k2, n = other.shape
#
#                     if k1 != k2:
#                         raise ValueError(
#                             f"Matrix dimension mismatch: ({m}, {k1}) @ ({k2}, {n})"
#                         )
#
#                     ptr_a, _c_a, _ref_a = self._get_buffer_pointer("f4")
#                     ptr_b, _c_b, _ref_b = other._get_buffer_pointer("f4")
#
# Prepare output buffer (Zero-Copy Optimization)
#                     import numpy as np
#
# Allocate uninitialized memory directly (fastest)
# Note: C++ kernels (AVX2/OpenBLAS) will initialize this (beta=0.0)
#                     final_np = np.empty((m, n), dtype=np.float32)
#
# Get raw pointer to the numpy array's data
#                     ptr_out = final_np.__array_interface__["data"][0]
#
# Dispatch 2D kernel
#                     ffi.array_matmul_2d_f32(ptr_a, ptr_b, ptr_out, m, k1, n)
#
# Return wrapped array
#                     elapsed_ms = (time.perf_counter() - start_time) * 1000
#                     record_op("matmul", elapsed_ms, "CPU")
#                     return ndarray(final_np, dtype=self._dtype, backend=self.backend)
#
#                 else:
# Generic shapes not supported in optimized kernel yet
#                     pass
#
#             except ImportError:
#                 pass  # Fallback
#
#         from .backend.dispatch import dispatch_kernel
#
#         result = dispatch_kernel(
#             "matmul",
#             self.backend,
#             self._backing_data,
#             other._backing_data,
#             shape_a=self.shape,
#             shape_b=other.shape,
#         )
#         elapsed_ms = (time.perf_counter() - start_time) * 1000
#         record_op("matmul", elapsed_ms, self.backend.name)
#         return ndarray(result, dtype=self._dtype, backend=self.backend)
#

# Backward compatibility alias (deprecated) - REMOVED
