# -*- coding: utf-8 -*-
# flake8: noqa: E501
"""CLI init: create working_dir with config and HEARTBEAT.md (security confirmation only)."""
from __future__ import annotations

from pathlib import Path

import click
from rich.console import Console
from rich.panel import Panel

from .utils import prompt_confirm
from ..config import (
    get_config_path,
    get_heartbeat_query_path,
    load_config,
    save_config,
)
from ..config.config import (
    Config,
    HeartbeatConfig,
)
from ..constant import HEARTBEAT_DEFAULT_EVERY
from ..providers import load_providers_json

SECURITY_WARNING = """
安全提示 — 请务必阅读。

Symbio-OpenPaw 是运行在您本机环境的个人助手。它可以连接各种频道（钉钉、飞书、QQ、
Discord、iMessage 等），并执行读取文件、运行命令、调用外部 API 等技能。
默认情况下它是单操作者边界：仅一位受信用户。若启用工具，恶意或混淆的提示
可能导致代理执行不安全操作。

若多人可向同一 Symbio-OpenPaw 实例发送消息并启用工具，他们将共享同一委派权限
（代理可访问的文件、命令、密钥等）。

若您对访问控制与加固不够熟悉，请勿在使用工具或将机器人暴露于不受信任用户
的情况下运行 OpenPaw。在启用强力技能或将机器人暴露于互联网之前，请向有经验
者咨询。

建议基线：
- 限制可触发代理的频道与用户；尽可能使用白名单。
- 多用户或共享收件箱：为不同信任边界使用独立配置、凭据，建议使用独立
  操作系统用户或主机。
- 以最小权限运行技能；在可行处使用沙箱。
- 勿将密钥放在代理工作目录或技能可访问路径中。
- 当代理启用工具或处理不受信任输入时，使用能力足够的模型。

定期检查配置与技能；将工具范围限制在所需范围内。
"""


def _echo_security_warning_box() -> None:
    """Print SECURITY_WARNING in a rich panel with blue border."""
    console = Console()
    console.print(
        Panel(
            SECURITY_WARNING.strip(),
            title="[bold]🐾 安全提示 — 请务必阅读[/bold]",
            border_style="blue",
        ),
    )


DEFAULT_HEARTBEAT_MDS = {
    "zh": """# Heartbeat checklist
- 扫描收件箱紧急邮件
- 查看未来 2h 的日历
- 检查待办是否卡住
- 若安静超过 8h，轻量 check-in
""",
    "en": """# Heartbeat checklist
- Scan inbox for urgent email
- Check calendar for next 2h
- Check tasks for blockers
- Light check-in if quiet for 8h
""",
}

DEFAULT_PORT = 8088


@click.command("init")
@click.option(
    "--force",
    is_flag=True,
    help="Overwrite existing config.json and HEARTBEAT.md if present.",
)
@click.option(
    "--defaults",
    "use_defaults",
    is_flag=True,
    help="Use defaults only, no interactive prompts (for scripts).",
)
@click.option(
    "--accept-security",
    "accept_security",
    is_flag=True,
    help="Skip security confirmation (use with --defaults for scripts/Docker).",
)
@click.option(
    "--no-launch",
    is_flag=True,
    help="Do not run openpaw app after init.",
)
# pylint: disable=too-many-branches,too-many-statements
def init_cmd(
    force: bool,
    use_defaults: bool,
    accept_security: bool,
    no_launch: bool,
) -> None:
    """Create working dir with config.json and HEARTBEAT.md.

    Only prompts for security acceptance; all other settings use defaults.
    On success, runs openpaw app in foreground by default.
    """
    config_path = get_config_path()
    working_dir = config_path.parent
    heartbeat_path = get_heartbeat_query_path()

    click.echo(f"Working dir: {working_dir}")

    # --- Security warning: must accept to continue ---
    _echo_security_warning_box()
    if use_defaults and accept_security:
        click.echo(
            "已假设接受安全协议（--accept-security 配合 --defaults）。",
        )
    else:
        accepted = prompt_confirm(
            "您是否已阅读并接受上述安全提示？（输入 yes 继续，no 退出）",
            default=True,
        )
        if not accepted:
            click.echo(
                "初始化已取消。请阅读安全提示后重新运行。",
            )
            raise click.Abort()

    working_dir.mkdir(parents=True, exist_ok=True)

    # --- Use defaults for everything (no further prompts) ---
    _run_init_with_defaults(config_path, heartbeat_path, force)
    click.echo("\n✓ Initialization complete!")

    # --- Run app in foreground (unless --no-launch) ---
    if not no_launch and not (use_defaults and accept_security):
        _run_app_foreground(DEFAULT_PORT)
    elif no_launch:
        click.echo("Run 'openpaw app' to start the service.")


def _run_init_with_defaults(
    config_path: Path,
    heartbeat_path: Path,
    force: bool,
) -> None:
    """Execute init logic using all defaults, no prompts."""
    from .providers_cmd import configure_providers_interactive

    write_config = True
    if config_path.is_file() and not force:
        write_config = True  # Always overwrite with defaults in simplified mode

    if not write_config:
        click.echo("Skipping configuration.")
    else:
        every = HEARTBEAT_DEFAULT_EVERY
        target = "main"
        active_hours = None
        hb = HeartbeatConfig(
            every=every,
            target=target,
            active_hours=active_hours,
        )
        existing = (
            load_config(config_path) if config_path.is_file() else Config()
        )
        existing.agents.defaults.heartbeat = hb
        existing.show_tool_details = True
        existing.agents.language = "zh"
        save_config(existing, config_path)
        click.echo(f"✓ Configuration saved to {config_path}")

    # --- LLM provider (use defaults) ---
    data = load_providers_json()
    has_llm = bool(data.active_llm.provider_id and data.active_llm.model)
    if not has_llm:
        configure_providers_interactive(use_defaults=True)
    else:
        click.echo(
            f"✓ LLM already configured: "
            f"{data.active_llm.provider_id} / {data.active_llm.model}",
        )

    # --- Skills ---
    from ..agents.skills_manager import sync_skills_to_working_dir

    click.echo("Enabling all skills by default (skip existing)...")
    synced, skipped = sync_skills_to_working_dir(
        skill_names=None,
        force=False,
    )
    if skipped:
        click.echo(
            f"✓ Skills synced: {synced}, skipped (existing): {skipped}",
        )
    else:
        click.echo(f"✓ All {synced} skills enabled.")

    # --- MD files ---
    from ..agents.utils import copy_md_files

    config = load_config(config_path) if config_path.is_file() else Config()
    current_language = config.agents.language
    click.echo(f"\nChecking MD files [language: {current_language}]...")
    copied = copy_md_files(current_language, skip_existing=True)
    if copied:
        config.agents.installed_md_files_language = current_language
        save_config(config, config_path)
        click.echo(f"✓ Copied {len(copied)} md file(s): " + ", ".join(copied))
    else:
        click.echo("✓ MD files already present, skipped.")

    # --- HEARTBEAT.md ---
    write_heartbeat = not heartbeat_path.is_file() or force
    if write_heartbeat:
        DEFAULT_HEARTBEAT_MD = DEFAULT_HEARTBEAT_MDS[current_language]
        heartbeat_path.write_text(
            DEFAULT_HEARTBEAT_MD.strip(),
            encoding="utf-8",
        )
        click.echo(f"✓ Heartbeat query saved to {heartbeat_path}")
    else:
        click.echo("✓ HEARTBEAT.md already present, skipped.")


def _run_app_foreground(port: int) -> None:
    """Run openpaw app in foreground (blocking) — same process as manual 'openpaw app'."""
    from .app_cmd import run_app

    click.echo("Starting OpenPaw...")
    try:
        run_app(
            host="127.0.0.1",
            port=port,
            reload=False,
            workers=1,
            log_level="info",
            hide_access_paths=("/console/push-messages",),
        )
    except Exception as e:
        click.echo(f"Warning: Could not run openpaw app: {e}")
        click.echo("Run 'openpaw app' manually.")
