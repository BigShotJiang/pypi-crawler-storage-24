# -*- coding: utf-8 -*-
"""Allow running OpenPaw via ``python -m openpaw``."""
from .cli.main import cli

if __name__ == "__main__":
    cli()  # pylint: disable=no-value-for-parameter
