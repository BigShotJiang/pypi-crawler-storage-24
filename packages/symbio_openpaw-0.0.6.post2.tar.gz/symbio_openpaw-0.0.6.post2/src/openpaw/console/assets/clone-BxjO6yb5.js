import{at as r}from"./index-5JDDSNVN.js";var a=4;function n(o){return r(o,a)}export{n as c};
