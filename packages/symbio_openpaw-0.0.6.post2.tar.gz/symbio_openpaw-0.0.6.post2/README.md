<div align="center">

# OpenPaw

[![License](https://img.shields.io/badge/license-Apache%202.0-red.svg?logo=apache&label=License)](LICENSE)
[![Python Version](https://img.shields.io/badge/python-3.10%20~%20%3C3.14-blue.svg?logo=python&label=Python)](https://www.python.org/downloads/)
[![Code Style](https://img.shields.io/badge/code%20style-black-black.svg?logo=python&label=CodeStyle)](https://github.com/psf/black)
[[中文 README](README_zh.md)] [[日本語](README_ja.md)]

<p align="center"><b>Works for you, grows with you.</b></p>

<p align="center"><em>Derived from <a href="https://github.com/agentscope-ai/CoPaw">CoPaw</a> (Apache 2.0). Modified for redistribution.</em></p>

</div>

Your Personal AI Assistant; easy to install, deploy on your own machine or on the cloud; supports multiple chat apps with easily extensible capabilities.

> **Core capabilities:**
>
> **Every channel** — DingTalk, Feishu, QQ, Discord, iMessage, and more. One assistant, connect as you need.
>
> **Under your control** — Memory and personalization under your control. Deploy locally or in the cloud; scheduled reminders to any channel.
>
> **Skills** — Built-in cron; custom skills in your workspace, auto-loaded. No lock-in.
>
> <details>
> <summary><b>What you can do</b></summary>
>
> <br>
>
> - **Social**: daily digest of hot posts (Xiaohongshu, Zhihu, Reddit), Bilibili/YouTube summaries.
> - **Productivity**: newsletter digests to DingTalk/Feishu/QQ, contacts from email/calendar.
> - **Creative**: describe your goal, run overnight, get a draft next day.
> - **Research**: track tech/AI news, personal knowledge base.
> - **Desktop**: organize files, read/summarize docs, request files in chat.
> - **Explore**: combine Skills and cron into your own agentic app.
>
> </details>

---

## News

[2026-03-06] We released v0.0.5! See the [v0.0.5 Release Notes](https://agentscope-ai.github.io/OpenPaw/release-notes) for the full changelog.

- **FEAT:** Channel management; Twilio voice channel; DeepSeek Reasoner support; daemon mode; agent interruption API; version update notifications.
- **PERF:** Memory system upgrade (reme-ai 0.3.0.3); console UI improvements (request cancellation, collapsible sidebar); optional channel lazy loading;  Windows installation script.
- **BUGFIX:** Configuration persistence for Docker; Ollama base URL; channel fixes (DingTalk, Feishu, Telegram); Windows compatibility; MCP client stability, shell timeout hang fix.
- **DOCS:** Model configuration guide; Docker + Ollama guide; Japanese README; release notes system, improve channel guide.
- **COMM:** Special thanks to all new contributors: [@qoli](https://github.com/qoli), [@qbc2016](https://github.com/qbc2016), [@yunlzheng](https://github.com/yunlzheng), [@BlueSkyXN](https://github.com/BlueSkyXN), [@sidonsoft](https://github.com/sidonsoft), [@lishengzxc](https://github.com/lishengzxc), [@pikaxinge](https://github.com/pikaxinge), [@linshengli](https://github.com/linshengli), [@eltociear](https://github.com/eltociear), [@liuxiaopai-ai](https://github.com/liuxiaopai-ai), [@Leirunlin](https://github.com/Leirunlin), [@pan-x-c](https://github.com/pan-x-c), [@garyzhang99](https://github.com/garyzhang99), [@celestialhorse51D](https://github.com/celestialhorse51D), [@wwx814](https://github.com/wwx814), [@nszhsl](https://github.com/nszhsl), [@DavdGao](https://github.com/DavdGao), [@zhangckcup](https://github.com/zhangckcup).

[2026-03-02] We released v0.0.4! See the [v0.0.4 Release Notes](https://agentscope-ai.github.io/OpenPaw/release-notes) for the full changelog.

---

## Table of Contents

> **Recommended reading:**
>
> - **I want to run OpenPaw in 3 commands**: [Quick Start](#quick-start) → open Console in browser.
> - **I want to chat in DingTalk / Feishu / QQ**: [Quick Start](#quick-start) → [Channels](https://openpaw.agentscope.io/docs/channels).
> - **I don’t want to install Python**: [One-line install](#one-line-install-beta-continuously-improving) handles Python automatically, or use [ModelScope one-click](https://modelscope.cn/studios/fork?target=AgentScope/OpenPaw) for cloud.

- [News](#news)
- [Quick Start](#quick-start)
- [API Key](#api-key)
- [Local Models](#local-models)
- [Documentation](#documentation)
- [FAQ](#faq)
- [Roadmap](#roadmap)
- [Contributing](#get-involved)
- [Install from source](#install-from-source)
- [Why OpenPaw?](#why-openpaw)
- [Built by](#built-by)
- [License](#license)

---

## Quick Start

### pip install (recommended)

If you prefer managing Python yourself:

```bash
pip install openpaw
openpaw init --defaults
openpaw app
```

Then open **http://127.0.0.1:8088/** in your browser for the Console (chat with OpenPaw, configure the agent). To talk in DingTalk, Feishu, QQ, etc., add a channel in the [docs](https://openpaw.agentscope.io/docs/channels).

![Console](https://img.alicdn.com/imgextra/i4/O1CN01iuGyNc1mNwsUU5NQI_!!6000000004943-2-tps-3822-2070.png)

### One-line install (beta, continuously improving)

No Python required — the installer handles everything:

**macOS / Linux:**

```bash
curl -fsSL https://openpaw.agentscope.io/install.sh | bash
```

To install with Ollama support:

```bash
curl -fsSL https://openpaw.agentscope.io/install.sh | bash -s -- --extras ollama
```

To install with multiple extras (e.g., Ollama + llama.cpp):

```bash
curl -fsSL https://openpaw.agentscope.io/install.sh | bash -s -- --extras ollama,llamacpp
```

**Windows (CMD):**

```CMD
curl -fsSL https://openpaw.agentscope.io/install.bat -o install.bat && install.bat
```

**Windows (PowerShell):**

```powershell
irm https://openpaw.agentscope.io/install.ps1 | iex
```

> **Note**: The installer will automatically check the status of uv. If it is not installed, it will attempt to download and configure it automatically. If the automatic installation fails, please follow the on-screen prompts or execute `python -m pip install -U uv`, then rerun the installer.

> **⚠️ Special Notice for Windows Enterprise LTSC Users**
>
> If you are using Windows LTSC or an enterprise environment governed by strict security policies, PowerShell may run in **Constrained Language Mode**, potentially causing the following issue:
> 1. **If using CMD (.bat): Script executes successfully but fails to write to `Path`**
>
>    The script completes file installation. Due to **Constrained Language Mode**, it cannot automatically update environment variables. Manually configure as follows:
>    - **Locate the installation directory**:
>      - Check if `uv` is available: Enter `uv --version` in CMD. If a version number appears, **only configure the OpenPaw path**. If you receive the prompt `'uv' is not recognized as an internal or external command, operable program or batch file,` configure both paths.
>      - uv path (choose one based on installation location; use if `uv` fails): Typically `%USERPROFILE%\.local\bin`, `%USERPROFILE%\AppData\Local\uv`, or the `Scripts` folder within your Python installation directory
>      - OpenPaw path: Typically located at `%USERPROFILE%\.openpaw\bin`.
>    - **Manually add to the system's Path environment variable**:
>      - Press `Win + R`, type `sysdm.cpl` and press Enter to open System Properties.
>      - Click “Advanced” -> “Environment Variables”.
>      - Under “System variables”, locate and select `Path`, then click “Edit”.
>      - Click “New”, enter both directory paths sequentially, then click OK to save.
> 2. **If using PowerShell (.ps1): Script execution interrupted**
>
>   Due to **Constrained Language Mode**, the script may fail to automatically download `uv`.
>   - **Manually install uv**: Refer to the [GitHub Release](https://github.com/astral-sh/uv/releases) to download `uv.exe` and place it in `%USERPROFILE%\.local\bin` or `%USERPROFILE%\AppData\Local\uv`; or ensure Python is installed and run `python -m pip install -U uv`.
>   - **Configure `uv` environment variables**: Add the `uv` directory and `%USERPROFILE%\.openpaw\bin` to your system's `Path` variable.
>   - **Re-run the installation**: Open a new terminal and execute the installation script again to complete the `OpenPaw` installation.
>   - **Configure the `OpenPaw` environment variable**: Add `%USERPROFILE%\.openpaw\bin` to your system's `Path` variable.

Once installed, open a new terminal and run:

```bash
openpaw init --defaults   # or: openpaw init (interactive)
openpaw app
```

<details>
<summary><b>Install options</b></summary>

**macOS / Linux:**

```bash
# Install a specific version
curl -fsSL ... | bash -s -- --version 0.0.2

# Install from source (dev/testing)
curl -fsSL ... | bash -s -- --from-source

# With local model support
bash install.sh --extras llamacpp    # llama.cpp (cross-platform)
bash install.sh --extras mlx         # MLX (Apple Silicon)
bash install.sh --extras llamacpp,mlx

# Upgrade — just re-run the installer
curl -fsSL ... | bash

# Uninstall
openpaw uninstall          # keeps config and data
openpaw uninstall --purge  # removes everything
```

**Windows (PowerShell):**

```powershell
# Install a specific version
irm ... | iex; .\install.ps1 -Version 0.0.2

# Install from source (dev/testing)
.\install.ps1 -FromSource

# With local model support
.\install.ps1 -Extras llamacpp      # llama.cpp (cross-platform)
.\install.ps1 -Extras mlx           # MLX
.\install.ps1 -Extras llamacpp,mlx

# Upgrade — just re-run the installer
irm ... | iex

# Uninstall
openpaw uninstall          # keeps config and data
openpaw uninstall --purge  # removes everything
```

</details>

### Using Docker

Images are on **Docker Hub** (`agentscope/openpaw`). Image tags: `latest` (stable); `pre` (PyPI pre-release).

```bash
docker pull agentscope/openpaw:latest
docker run -p 127.0.0.1:8088:8088 -v openpaw-data:/app/working agentscope/openpaw:latest
```

Also available on Alibaba Cloud Container Registry (ACR) for users in China: `agentscope-registry.ap-southeast-1.cr.aliyuncs.com/agentscope/openpaw` (same tags).

Then open **http://127.0.0.1:8088/** for the Console. Config, memory, and skills are stored in the `openpaw-data` volume. To pass API keys (e.g. `DASHSCOPE_API_KEY`), add `-e VAR=value` or `--env-file .env` to `docker run`.

> **Connecting to Ollama or other services on the host machine**
>
> Inside a Docker container, `localhost` refers to the container itself, not your host machine. If you run Ollama (or other model services) on the host and want OpenPaw in Docker to reach them, use one of these approaches:
>
> **Option A** — Explicit host binding (all platforms):
> ```bash
> docker run -p 127.0.0.1:8088:8088 \
>   --add-host=host.docker.internal:host-gateway \
>   -v openpaw-data:/app/working agentscope/openpaw:latest
> ```
> Then in OpenPaw **Settings → Models → Ollama**, change the Base URL to `http://host.docker.internal:11434/v1` or your corresponding port.
>
> **Option B** — Host networking (Linux only):
> ```bash
> docker run --network=host -v openpaw-data:/app/working agentscope/openpaw:latest
> ```
> No port mapping (`-p`) is needed; the container shares the host network directly. Note that all container ports are exposed on the host, which may cause conflicts if the port is already in use.

The image is built from scratch. To build the image yourself, please refer to the [Build Docker image](scripts/README.md#build-docker-image) section in `scripts/README.md`, and then push to your registry.

### Using ModelScope

**No local install?** [ModelScope Studio](https://modelscope.cn/studios/fork?target=AgentScope/OpenPaw) one-click cloud setup. Set your Studio to **non-public** so others cannot control your OpenPaw.

### Deploy on Alibaba Cloud ECS

To run OpenPaw on Alibaba Cloud (ECS), use the one-click deployment: open the [OpenPaw on Alibaba Cloud (ECS) deployment link](https://computenest.console.aliyun.com/service/instance/create/cn-hangzhou?type=user&ServiceId=service-1ed84201799f40879884) and follow the prompts. For step-by-step instructions, see [Alibaba Cloud Developer: Deploy your AI assistant in 3 minutes](https://developer.aliyun.com/article/1713682).

---

## API Key

If you use a **cloud LLM** (e.g. DashScope, ModelScope), you must set an API key before chatting. OpenPaw will not work until a valid key is configured.

**Where to set it:**

1. **`openpaw init`** — When you run `openpaw init`, the command has a step to configure the LLM provider and API key. Follow the prompts to choose a provider and enter your key.
2. **Console** — After `openpaw app`, open **http://127.0.0.1:8088/** → **Settings** → **Models**. Select a provider, fill in the **API Key** field, then activate that provider and model.
3. **Environment variable** — For DashScope you can set `DASHSCOPE_API_KEY` in your shell or in a `.env` file in the working directory.

Tools that need extra keys (e.g. `TAVILY_API_KEY` for web search) can be set in Console **Settings → Environment variables**, or see [Config](https://openpaw.agentscope.io/docs/config) for details.

> **Using local models only?** If you use [Local Models](#local-models) (llama.cpp or MLX), you do **not** need any API key.

## Local Models

OpenPaw can run LLMs entirely on your machine — no API keys or cloud services required.

| Backend       | Best for                                 | Install                                                              |
| ------------- | ---------------------------------------- | -------------------------------------------------------------------- |
| **llama.cpp** | Cross-platform (macOS / Linux / Windows) | `pip install 'openpaw[llamacpp]'` or `bash install.sh --extras llamacpp` |
| **MLX**       | Apple Silicon Macs (M1/M2/M3/M4)         | `pip install 'openpaw[mlx]'` or `bash install.sh --extras mlx`         |
| **Ollama**    | Cross-platform (requires Ollama service) | `pip install 'openpaw[ollama]'` or `bash install.sh --extras ollama`   |

After installing, download a model and start chatting:

```bash
openpaw models download Qwen/Qwen3-4B-GGUF
openpaw models # select the downloaded model
openpaw app # start the server
```

You can also download and manage local models from the Console UI.

---

## Documentation

| Topic                                                         | Description                                       |
| ------------------------------------------------------------- | ------------------------------------------------- |
| [Introduction](https://openpaw.agentscope.io/docs/intro)        | What OpenPaw is and how you use it                  |
| [Quick start](https://openpaw.agentscope.io/docs/quickstart)    | Install and run (local or ModelScope Studio)      |
| [Console](https://openpaw.agentscope.io/docs/console)           | Web UI for chat and agent config                  |
| [Channels](https://openpaw.agentscope.io/docs/channels)         | DingTalk, Feishu, QQ, Discord, iMessage, and more |
| [Heartbeat](https://openpaw.agentscope.io/docs/heartbeat)       | Scheduled check-in or digest                      |
| [Local Models](https://openpaw.agentscope.io/docs/local-models) | Run models locally with llama.cpp or MLX          |
| [CLI](https://openpaw.agentscope.io/docs/cli)                   | Init, cron jobs, skills, clean                    |
| [Skills](https://openpaw.agentscope.io/docs/skills)             | Extend and customize capabilities                 |
| [FAQ](https://openpaw.agentscope.io/docs/faq)                   | Common questions and troubleshooting tips         |
| [Memory](https://openpaw.agentscope.io/docs/memory)             | Context management and long-term memory           |
| [Config](https://openpaw.agentscope.io/docs/config)             | Working directory and config file                 |

Full docs in this repo: [website/public/docs/](website/public/docs/).

---

## FAQ

For common questions, troubleshooting tips, and known issues, please visit the **[FAQ page](https://openpaw.agentscope.io/docs/faq)**.

---

## Roadmap

| Area | Item | Status |
| --- | --- | --- |
| Horizontal Expansion | More channels, models, skills, MCPs — **community contributions welcome** | Seeking Contributors |
| Existing Feature Extension | Display optimization, download hints, Windows path compatibility, etc. — **community contributions welcome** | Seeking Contributors |
| Compatibility & Ease of Use | App-level packaging (DMG, EXE) | In Progress |
| | One-click deployment: built-in deps, dev extras, install/upgrade tutorials | In Progress |
| Release & Contributing | Contributing docs and test framework | In Progress |
| | Responsive handling of community contributions | In Progress |
| | Contributing guidance for vibe coding agents | Planned |
| Bugfixes & Enhancements | Message collapse/hide in UI | Planned |
| | Skills and MCP runtime install, hot-reload improvements | Planned |
| | Context management and compression (long tool outputs, lower token usage) | Planned |
| | Multimodal support | In Progress |
| Security | Shell execution confirmation | Planned |
| | Tool/skills security | Planned |
| | Configurable security levels (user-configurable) | Planned |
| Multimodal | Voice/video calls and real-time interaction | Long-term Planning |
| Multi-agent | Built on [AgentScope](https://github.com/agentscope-ai/agentscope), native multi-agent workflows | Long-term Planning |
| Sandbox | Deeper integration with AgentScope Runtime sandboxes | Long-term Planning |
| Self-healing | Daemon agent for automated recovery and health monitoring | Long-term Planning |
| OpenPaw-optimized local models | LLMs tuned for OpenPaw's native skills and common tasks; better local personal-assistant usability | Long-term Planning |
| Small + large model collaboration | Local LLMs for sensitive data; cloud LLMs for planning and coding; balance of privacy, performance, and capability | Long-term Planning |
| Cloud-native | Deeper integration with AgentScope Runtime; leverage cloud compute, storage, and tooling | Long-term Planning |
| Skills Hub | Enrich the [AgentScope Skills](https://github.com/agentscope-ai/agentscope-skills) repository and improve discoverability of high-quality skills | Long-term Planning |

*Status:* *In Progress* — actively being worked on; *Planned* — queued or under design, also **welcome contributions**; *Seeking Contributors* — we **strongly encourage community contributions**; *Long-term Planning* — longer-horizon roadmap.

### Get involved

We are building OpenPaw in the open and welcome contributions of all kinds! Check the [Roadmap](#roadmap) above (especially items marked **Seeking Contributors**) to find areas that interest you, and read [CONTRIBUTING](https://github.com/agentscope-ai/OpenPaw/blob/main/CONTRIBUTING.md) to get started. We particularly welcome:

- **Horizontal expansion** — new channels, model providers, skills, MCPs.
- **Existing feature extension** — display and UX improvements, download hints, Windows path compatibility, and the like.

Join the conversation on [GitHub Discussions](https://github.com/agentscope-ai/OpenPaw/discussions) to suggest or pick up work.

---

## Install from source

```bash
git clone https://github.com/agentscope-ai/OpenPaw.git
cd OpenPaw
pip install -e .
```

- **Dev** (tests, formatting): `pip install -e ".[dev]"`
- **Console** (build frontend): `cd console && npm ci && npm run build`, then `openpaw app` from project root.

---

## Why OpenPaw?

OpenPaw represents both a **Co Personal Agent Workstation** and a "co-paw"—a partner always by your side. More than just a cold tool, OpenPaw is a warm "little paw" always ready to lend a hand (or a paw!). It is the ultimate teammate for your digital life.

---

## Built by

[AgentScope team](https://github.com/agentscope-ai) · [AgentScope](https://github.com/agentscope-ai/agentscope) · [AgentScope Runtime](https://github.com/agentscope-ai/agentscope-runtime) · [ReMe](https://github.com/agentscope-ai/ReMe)

---

## Contact us

| [Discord](https://discord.gg/eYMpfnkG8h)                     | [X (Twitter)](https://x.com/agentscope_ai)                   | [DingTalk](https://qr.dingtalk.com/action/joingroup?code=v1,k1,OmDlBXpjW+I2vWjKDsjvI9dhcXjGZi3bQiojOq3dlDw=&_dt_no_comment=1&origin=11) |
| ------------------------------------------------------------ | ------------------------------------------------------------ | ------------------------------------------------------------ |
| [<img src="https://gw.alicdn.com/imgextra/i1/O1CN01hhD1mu1Dd3BWVUvxN_!!6000000000238-2-tps-400-400.png" width="80" height="80" alt="Discord">](https://discord.gg/eYMpfnkG8h) | [<img src="https://img.shields.io/badge/X-black.svg?logo=x&logoColor=white" width="80" height="80" alt="X">](https://x.com/agentscope_ai) | [<img src="https://img.alicdn.com/imgextra/i2/O1CN01vCWI8a1skHtLGXEMQ_!!6000000005804-2-tps-458-460.png" width="80" height="80" alt="DingTalk">](https://qr.dingtalk.com/action/joingroup?code=v1,k1,OmDlBXpjW+I2vWjKDsjvI9dhcXjGZi3bQiojOq3dlDw=&_dt_no_comment=1&origin=11) |

---

## License

OpenPaw is released under the [Apache License 2.0](LICENSE). This project is derived from [CoPaw](https://github.com/agentscope-ai/CoPaw); see [NOTICE](NOTICE) for attribution.

---

## Contributors

All thanks to our contributors:

<a href="https://github.com/agentscope-ai/OpenPaw/graphs/contributors">
  <img src="https://contrib.rocks/image?repo=agentscope-ai/OpenPaw" alt="Contributors" />
</a>