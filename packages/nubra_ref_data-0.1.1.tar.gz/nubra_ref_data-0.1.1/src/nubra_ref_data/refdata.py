from __future__ import annotations

from dataclasses import dataclass
import re
from typing import Any

import pandas as pd


WEEK_PATTERN = re.compile(r"^week(?P<index>\d+)$")
OPTION_TYPES = {"CE", "PE"}
BASE_COLUMNS = [
    "stock_name",
    "ref_id",
    "exchange",
    "asset",
    "asset_type",
    "derivative_type",
    "expiry",
    "strike_price",
    "option_type",
    "lot_size",
    "tick_size",
    "token",
    "nubra_name",
    "isin",
    "underlying_prev_close",
]
@dataclass(frozen=True)
class ResolvedExpiry:
    bucket: str
    expiry: int


def _normalize_text(value: Any) -> str:
    if value is None:
        return ""
    return str(value).strip().upper()


def _to_numeric(series: pd.Series) -> pd.Series:
    return pd.to_numeric(series, errors="coerce")


def _normalize_option_side(option_side: str | None) -> str:
    side = _normalize_text(option_side or "BOTH")
    aliases = {
        "BOTH": "BOTH",
        "ALL": "BOTH",
        "CE": "CE",
        "CALL": "CE",
        "CALLS": "CE",
        "PE": "PE",
        "PUT": "PE",
        "PUTS": "PE",
    }
    normalized = aliases.get(side)
    if normalized is None:
        raise ValueError("option_side must be one of BOTH, CE, PE, CALL, or PUT.")
    return normalized


def _ensure_dataframe(instruments: Any, exchange: str) -> pd.DataFrame:
    if not hasattr(instruments, "get_instruments_dataframe"):
        raise TypeError("instruments must expose get_instruments_dataframe(exchange=...).")

    df = instruments.get_instruments_dataframe(exchange=exchange)
    if not isinstance(df, pd.DataFrame):
        raise TypeError("get_instruments_dataframe(exchange=...) must return a pandas DataFrame.")

    missing = [column for column in BASE_COLUMNS if column not in df.columns]
    if missing:
        raise ValueError(f"Instrument DataFrame is missing required columns: {missing}")

    df = df.copy()
    df["exchange"] = df["exchange"].astype(str).str.upper()
    df["asset"] = df["asset"].astype(str).str.upper()
    df["derivative_type"] = df["derivative_type"].astype(str).str.upper()
    df["option_type"] = df["option_type"].astype(str).str.upper()
    df["stock_name"] = df["stock_name"].astype(str)
    df["expiry"] = _to_numeric(df["expiry"]).astype("Int64")
    df["strike_price"] = _to_numeric(df["strike_price"])
    df["underlying_prev_close"] = _to_numeric(df["underlying_prev_close"])
    return df


def _asset_dataframe(instruments: Any, underlying: str, exchange: str) -> pd.DataFrame:
    exchange_code = _normalize_text(exchange)
    underlying_name = _normalize_text(underlying)
    df = _ensure_dataframe(instruments, exchange=exchange_code)
    asset_df = df[(df["exchange"] == exchange_code) & (df["asset"] == underlying_name)].copy()
    if asset_df.empty:
        raise ValueError(f"No instruments found for underlying={underlying_name!r} on exchange={exchange_code!r}.")
    return asset_df


def _resolve_expiry_bucket(option_expiries: list[int], expiry_bucket: str) -> ResolvedExpiry:
    if not option_expiries:
        raise ValueError("No option expiries are available for the selected underlying and exchange.")

    bucket = _normalize_text(expiry_bucket)
    if bucket == "MONTH":
        by_month: dict[tuple[int, int], list[int]] = {}
        for expiry in option_expiries:
            expiry_str = str(expiry)
            month_key = (int(expiry_str[:4]), int(expiry_str[4:6]))
            by_month.setdefault(month_key, []).append(expiry)
        first_month_key = sorted(by_month)[0]
        return ResolvedExpiry(bucket="MONTH", expiry=max(by_month[first_month_key]))

    match = WEEK_PATTERN.match(bucket.lower())
    if match is None:
        raise ValueError("expiry_bucket must look like week0, week1, week2, week3, week4, or month.")

    index = int(match.group("index"))
    if index >= len(option_expiries):
        raise ValueError(
            f"expiry_bucket={expiry_bucket!r} is out of range for the available expiries: {option_expiries}"
        )
    return ResolvedExpiry(bucket=f"WEEK{index}", expiry=option_expiries[index])


def underlying_data(instruments: Any, underlying: str, exchange: str = "NSE") -> pd.DataFrame:
    asset_df = _asset_dataframe(instruments=instruments, underlying=underlying, exchange=exchange)
    stock_name = asset_df["stock_name"].astype(str).str.upper()
    derivative_type = asset_df["derivative_type"].astype(str).str.upper()
    underlying_name = _normalize_text(underlying)
    rows = asset_df[(stock_name == underlying_name) & (~derivative_type.isin(["OPT", "FUT"]))].copy()

    if rows.empty:
        underlying_prev_close = asset_df["underlying_prev_close"].dropna()
        placeholder = {
            "stock_name": underlying_name,
            "ref_id": pd.NA,
            "exchange": _normalize_text(exchange),
            "asset": underlying_name,
            "asset_type": pd.NA,
            "derivative_type": "SPOT",
            "expiry": pd.NA,
            "strike_price": pd.NA,
            "option_type": pd.NA,
            "lot_size": pd.NA,
            "tick_size": pd.NA,
            "token": pd.NA,
            "nubra_name": pd.NA,
            "isin": pd.NA,
            "underlying_prev_close": underlying_prev_close.iloc[0] if not underlying_prev_close.empty else pd.NA,
        }
        rows = pd.DataFrame([placeholder], columns=BASE_COLUMNS)

    return rows[BASE_COLUMNS].reset_index(drop=True)


def futures_data(instruments: Any, underlying: str, exchange: str = "NSE") -> pd.DataFrame:
    asset_df = _asset_dataframe(instruments=instruments, underlying=underlying, exchange=exchange)
    rows = asset_df[asset_df["derivative_type"] == "FUT"].copy()
    rows = rows.sort_values(by=["expiry", "stock_name"], kind="stable")
    return rows[BASE_COLUMNS].reset_index(drop=True)


def options_data(
    instruments: Any,
    underlying: str,
    exchange: str = "NSE",
    expiry_bucket: str = "week0",
    levels: int = 10,
    option_side: str = "BOTH",
) -> pd.DataFrame:
    if levels <= 0:
        raise ValueError("levels must be greater than 0.")

    asset_df = _asset_dataframe(instruments=instruments, underlying=underlying, exchange=exchange)
    option_rows = asset_df[asset_df["derivative_type"] == "OPT"].copy()
    if option_rows.empty:
        raise ValueError(f"No option instruments found for underlying={_normalize_text(underlying)!r}.")

    side = _normalize_option_side(option_side)
    option_expiries = sorted(int(value) for value in option_rows["expiry"].dropna().unique().tolist())
    resolved = _resolve_expiry_bucket(option_expiries, expiry_bucket)

    rows = option_rows[option_rows["expiry"] == resolved.expiry].copy()
    if rows.empty:
        raise ValueError(f"No option instruments found for expiry={resolved.expiry}.")

    ce_rows = rows[rows["option_type"] == "CE"].copy()
    pe_rows = rows[rows["option_type"] == "PE"].copy()
    ce_strikes = set(ce_rows["strike_price"].dropna().tolist())
    pe_strikes = set(pe_rows["strike_price"].dropna().tolist())

    if side == "BOTH":
        valid_strikes = sorted(ce_strikes & pe_strikes)
    elif side == "CE":
        valid_strikes = sorted(ce_strikes)
    else:
        valid_strikes = sorted(pe_strikes)

    if not valid_strikes:
        raise ValueError("No matching option rows were found for the selected filters.")

    underlying_prev_close_series = rows["underlying_prev_close"].dropna()
    underlying_prev_close = (
        float(underlying_prev_close_series.iloc[0])
        if not underlying_prev_close_series.empty
        else float(valid_strikes[len(valid_strikes) // 2])
    )

    ranked_strikes = sorted(valid_strikes, key=lambda strike: (abs(strike - underlying_prev_close), strike))
    selected_strikes = ranked_strikes[: min(levels, len(ranked_strikes))]
    rank_map = {strike: index + 1 for index, strike in enumerate(selected_strikes)}

    rows = rows[rows["strike_price"].isin(selected_strikes)].copy()
    if side in OPTION_TYPES:
        rows = rows[rows["option_type"] == side].copy()
    else:
        rows = rows[rows["option_type"].isin(["CE", "PE"])].copy()

    if side == "CE":
        rows = rows.sort_values(by=["strike_price"], ascending=[True], kind="stable")
        return rows[BASE_COLUMNS].reset_index(drop=True)

    if side == "PE":
        rows = rows.sort_values(by=["strike_price"], ascending=[False], kind="stable")
        return rows[BASE_COLUMNS].reset_index(drop=True)

    ce_output = rows[rows["option_type"] == "CE"].sort_values(by=["strike_price"], ascending=[True], kind="stable")
    pe_output = rows[rows["option_type"] == "PE"].sort_values(by=["strike_price"], ascending=[False], kind="stable")
    final_rows = pd.concat([ce_output, pe_output], ignore_index=True, sort=False)
    return final_rows[BASE_COLUMNS].reset_index(drop=True)


def all_data(
    instruments: Any,
    underlying: str,
    exchange: str = "NSE",
    expiry_bucket: str = "week0",
    levels: int = 10,
    option_side: str = "BOTH",
) -> pd.DataFrame:
    frames = [
        underlying_data(instruments=instruments, underlying=underlying, exchange=exchange),
        futures_data(instruments=instruments, underlying=underlying, exchange=exchange),
        options_data(
            instruments=instruments,
            underlying=underlying,
            exchange=exchange,
            expiry_bucket=expiry_bucket,
            levels=levels,
            option_side=option_side,
        ),
    ]
    concat_frames = [frame.dropna(axis=1, how="all") for frame in frames if not frame.empty]
    final_df = pd.concat(concat_frames, ignore_index=True, sort=False)
    return final_df[BASE_COLUMNS].reset_index(drop=True)
