from __future__ import annotations

import unittest

import pandas as pd

from nubra_ref_data import all_data, futures_data, options_data, underlying_data


class FakeInstruments:
    def __init__(self, dataframe: pd.DataFrame) -> None:
        self._dataframe = dataframe

    def get_instruments_dataframe(self, exchange: str | None = None) -> pd.DataFrame:
        df = self._dataframe.copy()
        if exchange is None:
            return df
        return df[df["exchange"].astype(str).str.upper() == str(exchange).upper()].reset_index(drop=True)


def _sample_df() -> pd.DataFrame:
    rows = [
        {
            "stock_name": "RELIANCE",
            "ref_id": 1,
            "exchange": "NSE",
            "asset": "RELIANCE",
            "asset_type": "STOCKS",
            "derivative_type": "",
            "expiry": pd.NA,
            "strike_price": pd.NA,
            "option_type": pd.NA,
            "lot_size": 1,
            "tick_size": 5,
            "token": 101,
            "nubra_name": "STOCK_RELIANCE.NSECM",
            "isin": "INE002A01018",
            "underlying_prev_close": 201000.0,
        },
        {
            "stock_name": "RELIANCE26MARFUT",
            "ref_id": 2,
            "exchange": "NSE",
            "asset": "RELIANCE",
            "asset_type": "STOCK_FO",
            "derivative_type": "FUT",
            "expiry": 20260326,
            "strike_price": -1,
            "option_type": pd.NA,
            "lot_size": 250,
            "tick_size": 5,
            "token": 102,
            "nubra_name": "FUT_RELIANCE_20260326",
            "isin": pd.NA,
            "underlying_prev_close": 201000.0,
        },
        {
            "stock_name": "RELIANCE26APRFUT",
            "ref_id": 3,
            "exchange": "NSE",
            "asset": "RELIANCE",
            "asset_type": "STOCK_FO",
            "derivative_type": "FUT",
            "expiry": 20260430,
            "strike_price": -1,
            "option_type": pd.NA,
            "lot_size": 250,
            "tick_size": 5,
            "token": 103,
            "nubra_name": "FUT_RELIANCE_20260430",
            "isin": pd.NA,
            "underlying_prev_close": 201000.0,
        },
    ]
    expiries = [20260319, 20260326, 20260430]
    strikes = [199000, 200000, 201000, 202000]
    ref_id = 100
    for expiry in expiries:
        for strike in strikes:
            for option_type in ["CE", "PE"]:
                rows.append(
                    {
                        "stock_name": f"RELIANCE{expiry}{strike}{option_type}",
                        "ref_id": ref_id,
                        "exchange": "NSE",
                        "asset": "RELIANCE",
                        "asset_type": "STOCK_FO",
                        "derivative_type": "OPT",
                        "expiry": expiry,
                        "strike_price": strike,
                        "option_type": option_type,
                        "lot_size": 250,
                        "tick_size": 5,
                        "token": 1000 + ref_id,
                        "nubra_name": f"OPT_RELIANCE_{expiry}_{option_type}_{strike}",
                        "isin": pd.NA,
                        "underlying_prev_close": 201000.0,
                    }
                )
                ref_id += 1
    return pd.DataFrame(rows)


class NubraRefDataTests(unittest.TestCase):
    def setUp(self) -> None:
        self.instruments = FakeInstruments(_sample_df())

    def test_underlying_data_returns_stock_row(self) -> None:
        result = underlying_data(self.instruments, underlying="RELIANCE", exchange="NSE")
        self.assertEqual(len(result), 1)
        self.assertEqual(result.iloc[0]["stock_name"], "RELIANCE")
        self.assertEqual(list(result.columns), [
            "stock_name", "ref_id", "exchange", "asset", "asset_type", "derivative_type",
            "expiry", "strike_price", "option_type", "lot_size", "tick_size", "token",
            "nubra_name", "isin", "underlying_prev_close",
        ])

    def test_futures_data_returns_all_futures(self) -> None:
        result = futures_data(self.instruments, underlying="RELIANCE", exchange="NSE")
        self.assertEqual(len(result), 2)
        self.assertEqual(set(result["derivative_type"].tolist()), {"FUT"})

    def test_options_data_resolves_week_bucket_and_levels(self) -> None:
        result = options_data(
            self.instruments,
            underlying="RELIANCE",
            exchange="NSE",
            expiry_bucket="week0",
            levels=2,
            option_side="BOTH",
        )
        self.assertEqual(len(result), 4)
        self.assertEqual(set(result["option_type"].tolist()), {"CE", "PE"})
        self.assertEqual(result["expiry"].dropna().astype(int).unique().tolist(), [20260319])
        self.assertEqual(result["option_type"].tolist(), ["CE", "CE", "PE", "PE"])
        self.assertEqual(result["strike_price"].tolist(), [200000, 201000, 201000, 200000])

    def test_ce_and_pe_are_separated_with_requested_ordering(self) -> None:
        result = options_data(
            self.instruments,
            underlying="RELIANCE",
            exchange="NSE",
            expiry_bucket="week0",
            levels=3,
            option_side="BOTH",
        )
        ce_rows = result[result["option_type"] == "CE"]
        pe_rows = result[result["option_type"] == "PE"]
        self.assertEqual(ce_rows["strike_price"].tolist(), [200000, 201000, 202000])
        self.assertEqual(pe_rows["strike_price"].tolist(), [202000, 201000, 200000])

    def test_all_data_combines_underlying_futures_and_options(self) -> None:
        result = all_data(
            self.instruments,
            underlying="RELIANCE",
            exchange="NSE",
            expiry_bucket="month",
            levels=1,
            option_side="PE",
        )
        self.assertEqual(result.iloc[0]["stock_name"], "RELIANCE")
        option_rows = result[result["derivative_type"] == "OPT"]
        self.assertEqual(len(option_rows), 1)
        self.assertEqual(option_rows["expiry"].dropna().astype(int).unique().tolist(), [20260326])


if __name__ == "__main__":
    unittest.main()
