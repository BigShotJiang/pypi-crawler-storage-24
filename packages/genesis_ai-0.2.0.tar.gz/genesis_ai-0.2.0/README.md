<div align="center">
  <img alt="Genesis" src="https://raw.githubusercontent.com/deadraid/genesis/main/docs/mascot-dark.svg" width="600">
  <h1>Genesis</h1>
  <p><strong>Universal autonomous AI agent built in Zig</strong></p>
</div>

Genesis runs in the terminal, in the browser, and inside messaging platforms — with multi-agent swarm execution when a single agent isn't enough.

## Install

```bash
pip install genesis-ai-cli
```

## Usage

```bash
genesis                                                # interactive TUI
genesis --provider anthropic --model claude-sonnet-4-6  # specific provider
genesis --task "Build a REST API"                      # swarm mode
genesis --server --transport ws --listen 0.0.0.0:7700  # server mode
```

## Highlights

- **Interactive TUI** — streaming chat, markdown rendering, 6 themes (dark/light)
- **Web UI** — React-based browser interface with full feature parity
- **Channel adapters** — Telegram, Discord, Slack, X; custom channels via JSON-RPC stdio
- **Multi-provider** — Anthropic, z.ai, OpenAI, Google, OpenRouter, Chutes, Moonshot, MiniMax
- **Swarm engine** — parallel multi-agent execution with role differentiation
- **Subagents** — lightweight parallel tasks with workspace isolation
- **MCP support** — external tools through Model Context Protocol
- **Built-in tools** — file editing, shell, glob, web search/fetch, scheduler, vault
- **Permission system** — safe/normal/auto/yolo modes

## Documentation

Full documentation: [github.com/deadraid/genesis](https://github.com/deadraid/genesis#readme)

## License

MIT
