from pathlib import Path
from collections import defaultdict
import re

class ImagePaths:
    '''
    Utility object for organizing and accessing PNG images from a central image directory.
    
    Images are grouped by base name, stripping any trailing digits, so files like
    `button1.png`, `button2.png`, `button3.png` are all accessible via `images["button"]`.
    
    Intended for use with `pyautogui.locate()` / `pyautogui.locateAll()` or
    `smallpy.BaseScreen` objects, where multiple variants of the same UI element
    are stored as numbered siblings.

    Args:
        image_dir (Path): Path to the directory containing `.png` image files.

    Attributes:
        directory_path (Path): The resolved path to the image directory.
        all_images (dict[str, Path]): Flat mapping of image stem -> Path for every `.png` found.
        images (dict[str, list[Path]]): Grouped mapping of base name -> list of variant Paths.  

    Raises:
        FileNotFoundError: If `image_dir` does not exist.
        NotADirectoryError: If `image_dir` is not a directory.
        ValueError: If `image_dir` contains no `.png` files.
    
    Example:
        >>> paths = ImagePaths(Path("assets/images"))
        >>> paths["button"]           # -> [Path("assets/images/button1.png"), ...]
        >>> paths.names               # -> ["button", "icon", "checkbox"]
        >>> paths.get("missing")      # -> None (safe access)
        >>> "button" in paths         # -> True
    '''
    def __init__(self,image_dir:Path):
        image_dir = Path(image_dir)  # coerce str -> Path defensively
        if not image_dir.exists():
            raise FileNotFoundError(f"Image directory not found: {image_dir}")
        if not image_dir.is_dir():
            raise NotADirectoryError(f"Path is not a directory: {image_dir}")
        
        self.directory_path = image_dir.resolve()
        self.all_images = {
            img.stem : img for img in image_dir.glob('*.png')
        }
        self.images = self._group_images(self.all_images)
    
    def __getitem__(self, key:str):
        if key not in self.images:
            raise KeyError(f'Unable to locate image(s) named "{key}" in self.images')
        return self.images[key]

    def __len__(self):
        return len(self.images)
    
    def __contains__(self, item):
        return item in self.images
    
    def __repr__(self) -> str:
        return f"ImagePaths(directory={self.directory_path!r}, groups={len(self.images)}, total={len(self.all_images)})"

    def _group_images(self,image_dict:dict[str,Path]) -> dict[str,list[Path]]:
        grouped = defaultdict(list)
        for stem,path in image_dict.items():
            base_name = re.sub(r'\d+$','',stem)
            grouped[base_name].append(path)
        return dict(grouped)
    
    def get(self, key: str, default=None) -> list[Path] | None:
        '''Safe access that returns `default` instead of raising on missing keys.'''
        return self.images.get(key, default)

    def first(self, key: str) -> Path:
        '''
        Returns the first (or only) image path for a given key.
        Useful when only one variant exists and you don't want to unpack a list.
        
        Raises:
            KeyError: If the key does not exist.
        '''
        return self[key][0]

    @property
    def names(self) -> list[str]:
        '''Sorted list of all grouped base names.'''
        return sorted(self.images.keys())

    @property
    def count(self) -> int:
        '''Total number of individual image files (not groups).'''
        return len(self.all_images)

    def reload(self) -> None:
        '''Re-scan the directory in place, updating `all_images` and `images`.
        Useful if the directory contents change at runtime.'''
        self.all_images = {img.stem: img for img in self.directory_path.glob('*.png')}
        self.images = self._group_images(self.all_images)

    def variants(self, key: str) -> int:
        '''Returns the number of variants for a given image group key.'''
        return len(self[key])