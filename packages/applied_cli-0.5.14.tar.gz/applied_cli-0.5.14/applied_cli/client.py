"""Applied Labs API client."""

import asyncio
import json
import uuid
from typing import Any

import httpx


class AppliedAPIError(Exception):
    """API error with details and recovery suggestions."""

    def __init__(
        self,
        message: str,
        status_code: int,
        detail: str | None = None,
        suggestion: str | None = None,
    ):
        self.status_code = status_code
        self.detail = detail
        self.suggestion = suggestion
        full_message = f"[{status_code}] {message}"
        if detail:
            full_message += f"\nDetail: {detail}"
        if suggestion:
            full_message += f"\n\n💡 Suggestion: {suggestion}"
        super().__init__(full_message)


def _get_error_suggestion(
    status_code: int,
    path: str,
    detail: str,
    body: dict | None,
) -> str | None:
    """Return actionable suggestion based on error context."""
    detail_lower = detail.lower() if detail else ""

    # Edge creation errors
    if "/edges" in path and status_code == 400:
        if "source" in detail_lower or "handle" in detail_lower:
            return (
                "Invalid source_handle. For branch nodes, valid handles are '1', '2', '3', etc. "
                "(matching comparison index) or 'default'. "
                "Run flow_get(flow_id) to see the node's output schema."
            )
        if "cycle" in detail_lower:
            return (
                "This edge would create a cycle. Check your flow graph - "
                "you may be connecting back to an ancestor node. "
                "Use flow_get(flow_id) to visualize the current edges."
            )
        if "target" in detail_lower:
            return "Target node not found. Verify the node_id exists with flow_get(flow_id)."

    # Node errors
    if "/nodes" in path:
        if status_code == 400:
            if "executor" in detail_lower or "name" in detail_lower:
                return (
                    "Invalid executor_type. Common types: 'completion', 'structured_completion', "
                    "'branch', 'code', 'http_request'. Run executor_list() to see all options."
                )
            if "metadata" in detail_lower:
                return (
                    "Invalid metadata format. Ensure metadata is a valid JSON object. "
                    "For branch nodes, include 'value' and 'comparisons'. "
                    "For code nodes, include 'language' and 'code'."
                )
        if status_code == 404:
            return "Node not found. Run flow_get(flow_id) to see all nodes in the flow."

    # Flow errors
    if "/flows" in path:
        if status_code == 404:
            return "Flow not found. Run flow_list(agent_id) to see available flows."
        if status_code == 400 and "trigger" in detail_lower:
            return (
                "Invalid trigger type. Common triggers: 'llm.call', 'webhook.receive', "
                "'conversation.escalated'. Check the flow_create documentation."
            )

    # Agent errors
    if "/agents" in path and status_code == 404:
        return "Agent not found. Run agent_list() to see available agents."

    # Conversation errors
    if "/conversations" in path and status_code == 404:
        return (
            "Conversation not found. The conversation_id may be wrong or the "
            "conversation may have been deleted."
        )

    # Generic suggestions
    if status_code == 401:
        return "Authentication failed. Check your API token or reconnect."
    if status_code == 403:
        return "Permission denied. You may not have access to this resource."
    if status_code == 500:
        return (
            "Server error. The flow may be corrupted. Consider creating a new flow "
            "with flow_create() and rebuilding - often faster than debugging."
        )

    return None


class AppliedClient:
    """Async client for Applied Labs API."""

    def __init__(
        self,
        token: str,
        shop_id: str | None = None,
        base_url: str = "https://api.appliedlabs.ai",
        timeout: float = 30.0,
    ):
        self.token = token
        self.shop_id = shop_id
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    async def _request(
        self,
        method: str,
        path: str,
        params: dict[str, Any] | None = None,
        body: dict[str, Any] | None = None,
    ) -> Any:
        """Make an authenticated API request."""
        headers = {
            "Authorization": f"Bearer {self.token}",
            "Content-Type": "application/json",
        }
        if self.shop_id:
            headers["X-Shop-Id"] = self.shop_id
        url = f"{self.base_url}{path}"

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            if method == "GET":
                resp = await client.get(url, headers=headers, params=params)
            elif method == "POST":
                resp = await client.post(url, headers=headers, json=body or {})
            elif method == "PATCH":
                resp = await client.patch(url, headers=headers, json=body or {})
            elif method == "DELETE":
                resp = await client.request(
                    "DELETE", url, headers=headers, json=body if body else None
                )
            else:
                raise ValueError(f"Unsupported method: {method}")

            if resp.status_code >= 400:
                # Parse error detail from response
                detail = ""
                try:
                    err_data = resp.json()
                    if isinstance(err_data, dict):
                        detail = err_data.get("detail") or err_data.get("error") or ""
                        if not detail and "message" in err_data:
                            detail = err_data["message"]
                        # Handle DRF validation errors
                        if not detail:
                            for key, val in err_data.items():
                                if isinstance(val, list):
                                    detail = f"{key}: {val[0]}"
                                    break
                except Exception:
                    detail = resp.text[:200] if resp.text else ""

                suggestion = _get_error_suggestion(resp.status_code, path, detail, body)

                raise AppliedAPIError(
                    message=f"{method} {path} failed",
                    status_code=resp.status_code,
                    detail=detail,
                    suggestion=suggestion,
                )

            if resp.status_code == 204:
                return None
            return resp.json()

    def _normalize_response(self, data: Any) -> list[dict]:
        """Handle both list and paginated responses."""
        if isinstance(data, list):
            return data
        return data.get("results", [])

    # -------------------------------------------------------------------------
    # Agents
    # -------------------------------------------------------------------------

    async def list_agents(self, limit: int = 100) -> list[dict]:
        """List all AI agents in the workspace."""
        data = await self._request(
            "GET",
            "/v1/agents/",
            params={"limit": limit, "ordering": "-created_at"},
        )
        return self._normalize_response(data)

    # -------------------------------------------------------------------------
    # Taxonomy (topics, intents, flags)
    # -------------------------------------------------------------------------

    async def list_taxonomy(
        self,
        taxonomy_type: str = "all",
    ) -> list[dict]:
        """List conversation taxonomy: topics, intents, and flags."""
        params: dict[str, Any] = {}
        if taxonomy_type == "flags":
            params["is_flag"] = "true"
        elif taxonomy_type == "topics":
            params["is_flag"] = "false"
            params["parent_choice_id__isnull"] = "true"
        elif taxonomy_type == "intents":
            params["is_flag"] = "false"
            params["parent_choice_id__isnull"] = "false"

        data = await self._request("GET", "/v1/property-choices/", params=params)
        return self._normalize_response(data)

    # -------------------------------------------------------------------------
    # Conversations
    # -------------------------------------------------------------------------

    async def query_conversations(
        self,
        filters: dict[str, Any] | None = None,
        limit: int = 20,
        offset: int = 0,
        ordering: str = "-last_message_at",
    ) -> list[dict]:
        """Query conversations with filters."""
        params: dict[str, Any] = {
            "limit": min(limit, 100),
            "offset": offset,
            "ordering": ordering,
        }

        if filters:
            for field, cond in filters.items():
                if isinstance(cond, str):
                    params[f"{field}__in"] = cond
                elif isinstance(cond, list):
                    params[f"{field}__in"] = ",".join(str(c) for c in cond)
                elif isinstance(cond, dict) and ("gte" in cond or "lte" in cond):
                    gte = cond.get("gte", "")
                    lte = cond.get("lte", "")
                    params[f"{field}__range"] = f"{gte},{lte}"

        data = await self._request("GET", "/v1/conversations/", params=params)
        return self._normalize_response(data)

    async def get_conversation(self, conversation_id: str) -> dict:
        """Get a single conversation by ID."""
        return await self._request("GET", f"/v1/conversations/{conversation_id}/")

    async def get_messages(
        self,
        conversation_id: str,
        limit: int = 50,
        ordering: str = "created_at",
    ) -> list[dict]:
        """Get messages for a conversation."""
        data = await self._request(
            "GET",
            "/v1/messages/",
            params={
                "conversation_id": conversation_id,
                "limit": limit,
                "ordering": ordering,
            },
        )
        return self._normalize_response(data)

    # -------------------------------------------------------------------------
    # Tickets
    # -------------------------------------------------------------------------

    async def query_tickets(
        self,
        filters: dict[str, Any] | None = None,
        limit: int = 20,
    ) -> list[dict]:
        """Query tickets with filters."""
        params: dict[str, Any] = {"limit": min(limit, 100)}

        if filters:
            for field, cond in filters.items():
                if isinstance(cond, str):
                    params[f"{field}__in"] = cond

        data = await self._request("GET", "/v1/tickets/", params=params)
        return self._normalize_response(data)

    # -------------------------------------------------------------------------
    # Knowledge Base
    # -------------------------------------------------------------------------

    async def list_knowledge(
        self,
        kb_type: str | None = None,
        search: str | None = None,
        limit: int = 50,
    ) -> list[dict]:
        """List knowledge base items."""
        params: dict[str, Any] = {"page_size": limit}
        if kb_type:
            params["type"] = kb_type
        if search:
            params["search"] = search

        data = await self._request("GET", "/v1/responses/", params=params)
        return self._normalize_response(data)

    # -------------------------------------------------------------------------
    # Flows
    # -------------------------------------------------------------------------

    async def list_flows(
        self,
        agent_id: str | None = None,
        status: str | None = None,
        with_graph: bool = False,
        limit: int = 50,
    ) -> list[dict]:
        """List flows, optionally filtered by agent and status."""
        params: dict[str, Any] = {"limit": limit}
        if agent_id:
            params["agent_id"] = agent_id
        if status:
            params["status"] = status
        if with_graph:
            params["with_graph"] = "true"

        data = await self._request("GET", "/v1/flows/", params=params)
        return self._normalize_response(data)

    async def get_flow(self, flow_id: str) -> dict:
        """Get a single flow with its graph (nodes and edges)."""
        return await self._request("GET", f"/v1/flows/{flow_id}/")

    async def create_flow(
        self,
        agent_id: str,
        name: str,
        flow_type: str = "conversational",
        trigger: str = "llm.call",
        description: str = "",
    ) -> dict:
        """Create a new flow."""
        return await self._request(
            "POST",
            "/v1/flows/",
            body={
                "agent_id": agent_id,
                "name": name,
                "type": flow_type,
                "trigger": trigger,
                "description": description,
            },
        )

    async def update_flow(self, flow_id: str, **kwargs: Any) -> dict:
        """Update a flow's properties."""
        return await self._request("PATCH", f"/v1/flows/{flow_id}/", body=kwargs)

    async def delete_flow(self, flow_id: str) -> None:
        """Delete a flow."""
        await self._request("DELETE", f"/v1/flows/{flow_id}/")

    # -------------------------------------------------------------------------
    # Flow Nodes
    # -------------------------------------------------------------------------

    async def get_node(self, flow_id: str, node_id: str) -> dict | None:
        """Get a single node with full configuration.

        Returns None if node not found.
        """
        flow = await self.get_flow(flow_id)
        graph = flow.get("graph", {})
        nodes = graph.get("nodes", [])
        for node in nodes:
            if node.get("id") == node_id:
                return node
        return None

    async def create_node(
        self,
        flow_id: str,
        name: str,
        metadata: dict[str, Any] | None = None,
        description: str = "",
        prompt: str = "",
    ) -> dict:
        """Create a node in a flow."""
        return await self._request(
            "POST",
            f"/v1/flows/{flow_id}/nodes/",
            body={
                "name": name,
                "metadata": metadata or {},
                "description": description,
                "prompt": prompt,
            },
        )

    async def update_node(
        self,
        flow_id: str,
        node_id: str,
        merge_metadata: bool = True,
        **kwargs: Any,
    ) -> dict:
        """Update a node's properties.

        Args:
            flow_id: The flow UUID
            node_id: The node UUID
            merge_metadata: If True (default), merge new metadata with existing.
                           If False, replace metadata entirely.
            **kwargs: Fields to update (description, prompt, metadata)
        """
        # If merge_metadata and metadata is provided, fetch existing and merge
        if merge_metadata and "metadata" in kwargs and kwargs["metadata"]:
            node = await self.get_node(flow_id, node_id)
            if node:
                existing_metadata = node.get("data", {}).get("metadata", {})
                # Deep merge: existing values are overwritten by new values
                merged = {**existing_metadata, **kwargs["metadata"]}
                kwargs["metadata"] = merged

        return await self._request(
            "PATCH",
            f"/v1/flows/{flow_id}/nodes/",
            body={"id": node_id, **kwargs},
        )

    async def delete_node(self, flow_id: str, node_id: str) -> None:
        """Delete a node from a flow."""
        await self._request(
            "DELETE",
            f"/v1/flows/{flow_id}/nodes/",
            body={"id": node_id},
        )

    # -------------------------------------------------------------------------
    # Flow Edges
    # -------------------------------------------------------------------------

    async def create_edge(
        self,
        flow_id: str,
        source_node_id: str,
        target_node_id: str,
        source_handle: str | None = None,
        target_handle: str | None = None,
        label: str | None = None,
    ) -> dict:
        """Create an edge connecting two nodes."""
        body: dict[str, Any] = {
            "source": source_node_id,
            "target": target_node_id,
        }
        if source_handle:
            body["source_handle"] = source_handle
        if target_handle:
            body["target_handle"] = target_handle
        if label:
            body["label"] = label

        return await self._request(
            "POST",
            f"/v1/flows/{flow_id}/edges/",
            body=body,
        )

    async def update_edge(self, flow_id: str, edge_id: str, **kwargs: Any) -> dict:
        """Update an edge's properties."""
        return await self._request(
            "PATCH",
            f"/v1/flows/{flow_id}/edges/",
            body={"id": edge_id, **kwargs},
        )

    async def delete_edge(self, flow_id: str, edge_id: str) -> None:
        """Delete an edge from a flow."""
        await self._request(
            "DELETE",
            f"/v1/flows/{flow_id}/edges/",
            body={"id": edge_id},
        )

    # -------------------------------------------------------------------------
    # Flow Execution
    # -------------------------------------------------------------------------

    async def run_flow(
        self,
        flow_id: str,
        trigger_data: dict[str, Any] | None = None,
        wait: bool = False,
        wait_timeout: float = 60.0,
        poll_interval: float = 1.0,
    ) -> dict:
        """Execute a flow with trigger data.

        Args:
            flow_id: The flow UUID
            trigger_data: Trigger input data
            wait: If True, poll until the run completes and include spans
            wait_timeout: Max seconds to wait for completion (default 60)
            poll_interval: Seconds between polls (default 1)

        Returns:
            Flow run with spans if wait=True
        """
        body = {"trigger": trigger_data or {}}
        run = await self._request("POST", f"/v1/flows/{flow_id}/run/", body=body)

        if not wait:
            return run

        # Poll until completion
        run_id = run.get("id")
        if not run_id:
            return run

        elapsed = 0.0
        while elapsed < wait_timeout:
            run = await self.get_flow_run(run_id)
            status = run.get("status", "")
            if status in ("Success", "Failed", "Cancelled"):
                return run
            await asyncio.sleep(poll_interval)
            elapsed += poll_interval

        # Timeout - return current state
        return run

    async def list_flow_runs(
        self,
        flow_id: str | None = None,
        conversation_id: str | None = None,
        status: str | None = None,
        limit: int = 20,
    ) -> list[dict]:
        """List flow runs, optionally filtered by flow, conversation, and status."""
        params: dict[str, Any] = {"limit": limit, "ordering": "-started_at"}
        if flow_id:
            params["flow_id"] = flow_id
        if conversation_id:
            params["conversation_id"] = conversation_id
        if status:
            params["status"] = status

        data = await self._request("GET", "/v1/flow-runs/", params=params)
        return self._normalize_response(data)

    async def get_flow_run(self, flow_run_id: str) -> dict:
        """Get a flow run with execution spans and actions."""
        return await self._request("GET", f"/v1/flow-runs/{flow_run_id}/")

    # -------------------------------------------------------------------------
    # Spans (OpenTelemetry traces via /v1/monitor/)
    # -------------------------------------------------------------------------

    async def get_spans(
        self,
        object_type: str,
        object_id: str,
    ) -> list[dict]:
        """Get OpenTelemetry spans for a flow-run or conversation.

        Args:
            object_type: 'flow-runs' or 'conversations'
            object_id: The flow_run_id or conversation_id
        """
        data = await self._request(
            "GET",
            "/v1/monitor/",
            params={"type": object_type, "id": object_id},
        )
        return data.get("spans", [])

    # -------------------------------------------------------------------------
    # Conversational Testing (via streaming /complete endpoint)
    # -------------------------------------------------------------------------

    async def create_conversation(
        self,
        agent_id: str,
        is_test: bool = True,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Create a new conversation for an agent.

        Args:
            agent_id: The agent UUID
            is_test: Whether this is a test conversation (default True)
            metadata: Optional metadata for the conversation

        Returns:
            Dict with conversation id
        """
        body: dict[str, Any] = {
            "agent_id": agent_id,
            "is_test": is_test,
        }
        if metadata:
            body["metadata"] = metadata

        return await self._request("POST", "/v1/c/", body=body)

    async def send_message(
        self,
        agent_id: str,
        message: str,
        conversation_id: str | None = None,
        contact_email: str | None = None,
        contact_name: str | None = None,
        contact_phone: str | None = None,
        flow_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Send a message to an agent and wait for the response.

        This calls the /complete endpoint (streaming) and consumes the full
        response. Use this for testing conversational flows.

        If no conversation_id is provided, a new conversation is created first.

        Args:
            agent_id: The agent UUID
            message: The user message to send
            conversation_id: Optional existing conversation to continue
            contact_email: Optional contact email for context
            contact_name: Optional contact name for context
            contact_phone: Optional contact phone for context
            flow_id: Optional flow UUID to force - bypasses routing and runs this flow
            metadata: Optional metadata dict for the conversation

        Returns:
            Dict with conversation_id, response, and status
        """
        # Build metadata with contact info
        meta = metadata.copy() if metadata else {}
        if contact_email:
            meta["email"] = contact_email
        if contact_name:
            meta["name"] = contact_name
        if contact_phone:
            meta["phone"] = contact_phone

        # Force specific flow via dialogue state
        if flow_id:
            meta["state"] = {"flow_id": flow_id}

        # Create conversation if needed
        result_conversation_id = conversation_id
        if not result_conversation_id:
            conv = await self.create_conversation(
                agent_id=agent_id,
                is_test=True,
                metadata=meta if meta else None,
            )
            result_conversation_id = conv["id"]

        # /complete endpoint uses AllowAny - no auth header needed
        headers: dict[str, str] = {
            "Content-Type": "application/json",
        }

        body: dict[str, Any] = {
            "conversation_id": result_conversation_id,
            "transcript": [
                {
                    "id": str(uuid.uuid4()),
                    "role": "user",
                    "content": message,
                    "text": message,
                    "format": "MARKDOWN",
                }
            ],
        }

        if meta:
            body["metadata"] = meta

        url = f"{self.base_url}/v1/agents/{agent_id}/complete/"

        response_text = ""

        async with (
            httpx.AsyncClient(timeout=120.0) as client,
            client.stream("POST", url, headers=headers, json=body) as response,
        ):
            response.raise_for_status()

            # v1 streaming format: JSON objects on each line
            async for line in response.aiter_lines():
                if not line:
                    continue

                # Try to parse as JSON directly (v1 format)
                try:
                    data = json.loads(line)
                    if "content" in data:
                        response_text += data["content"]
                except json.JSONDecodeError:
                    # Skip non-JSON lines
                    pass

        return {
            "conversation_id": result_conversation_id,
            "response": response_text,
            "status": "success" if response_text else "empty",
        }
