"""MCP tool implementations using AppliedClient.

These functions wrap the client methods with formatting logic,
suitable for both MCP tools and CLI commands.
"""

import json

from applied_cli.client import AppliedAPIError, AppliedClient
from applied_cli.formatters import select_fields, to_csv, to_json


def _format_error(e: AppliedAPIError) -> str:
    """Format an API error as a readable string for the AI."""
    return f"❌ Error: {e}"


async def agent_list(
    client: AppliedClient,
    output_format: str = "csv",
) -> str:
    """
    List all AI agents in the workspace.

    Args:
        client: Authenticated AppliedClient
        output_format: 'csv' (default, token-efficient) or 'json'

    Returns:
        List of agents with id, name, modality, description
    """
    agents = await client.list_agents()
    mapped = [
        {
            "id": a.get("id"),
            "name": a.get("name"),
            "modality": a.get("modality"),
            "description": a.get("description", ""),
        }
        for a in agents
    ]

    if output_format == "csv":
        return to_csv(mapped, ["id", "name", "modality", "description"])
    return to_json(mapped)


async def taxonomy_list(
    client: AppliedClient,
    taxonomy_type: str = "all",
    output_format: str = "csv",
) -> str:
    """
    List conversation taxonomy: topics, intents, and flags.

    Args:
        client: Authenticated AppliedClient
        taxonomy_type: 'all' (default), 'topics', 'intents', or 'flags'
        output_format: 'csv' or 'json'

    Returns:
        Topics (categories), intents (sub-categories), flags (markers)
    """
    choices = await client.list_taxonomy(taxonomy_type)
    items = [
        {
            "id": c.get("id"),
            "name": c.get("name"),
            "type": (
                "flag"
                if c.get("is_flag")
                else ("intent" if c.get("parent_choice_id") else "topic")
            ),
        }
        for c in choices
    ]

    if output_format == "csv":
        return to_csv(items, ["id", "name", "type"])
    return to_json(items)


async def conversation_query(
    client: AppliedClient,
    filters: dict | None = None,
    fields: list[str] | None = None,
    limit: int = 20,
    output_format: str = "csv",
) -> str:
    """
    Query conversations with filters and field selection.

    Args:
        client: Authenticated AppliedClient
        filters: Filter conditions, e.g.:
            {"resolution": "escalated"}
            {"resolution": ["escalated", "soft"]}
            {"created_at": {"gte": "2024-01-01", "lte": "2024-01-31"}}
        fields: Fields to return, e.g. ["id", "title", "contact.email"]
        limit: Max results (default 20, max 100)
        output_format: 'csv' or 'json'

    Returns:
        Matching conversations
    """
    results = await client.query_conversations(filters=filters, limit=limit)

    if fields:
        results = select_fields(results, fields)

    if output_format == "csv":
        return f"# {len(results)} results\n" + to_csv(results, fields)
    return to_json({"count": len(results), "results": results})


async def conversation_get(
    client: AppliedClient,
    conversation_id: str,
    include_messages: bool = False,
    message_limit: int = 50,
) -> str:
    """
    Get a single conversation by ID.

    Args:
        client: Authenticated AppliedClient
        conversation_id: The conversation UUID
        include_messages: Include message transcript (default: False)
        message_limit: Max messages to include (default: 50)

    Returns:
        Conversation details and optionally messages
    """
    conv = await client.get_conversation(conversation_id)
    result = f"# Conversation {conversation_id}\n{to_json(conv)}"

    if include_messages:
        messages = await client.get_messages(conversation_id, limit=message_limit)
        result += f"\n\n# Messages ({len(messages)})\n"
        for m in messages:
            role = m.get("role", "unknown")
            content = str(m.get("content", ""))[:500]
            result += f"\n[{role}] {content}"

    return result


async def ticket_query(
    client: AppliedClient,
    filters: dict | None = None,
    limit: int = 20,
    output_format: str = "csv",
) -> str:
    """
    Query tickets with filters.

    Args:
        client: Authenticated AppliedClient
        filters: Filter conditions, e.g. {"status": "open"}
        limit: Max results (default 20)
        output_format: 'csv' or 'json'

    Returns:
        Matching tickets
    """
    results = await client.query_tickets(filters=filters, limit=limit)
    mapped = [
        {
            "id": t.get("id"),
            "name": t.get("name"),
            "status": t.get("status"),
            "priority": t.get("priority"),
        }
        for t in results
    ]

    if output_format == "csv":
        return f"# {len(mapped)} tickets\n" + to_csv(
            mapped, ["id", "name", "status", "priority"]
        )
    return to_json(mapped)


async def knowledge_list(
    client: AppliedClient,
    kb_type: str | None = None,
    search: str | None = None,
    limit: int = 50,
    output_format: str = "csv",
) -> str:
    """
    List knowledge base items (Q&A, escalation rules, context, exact responses).

    Args:
        client: Authenticated AppliedClient
        kb_type: Filter by type - 'qa', 'context', 'escalate', 'exact'
        search: Full-text search query
        limit: Max results (default 50)
        output_format: 'csv' or 'json'

    Returns:
        Knowledge base items
    """
    results = await client.list_knowledge(kb_type=kb_type, search=search, limit=limit)
    mapped = [
        {
            "id": r.get("id"),
            "type": r.get("type"),
            "question": str(r.get("question", ""))[:100],
            "active": r.get("active"),
        }
        for r in results
    ]

    if output_format == "csv":
        return to_csv(mapped, ["id", "type", "question", "active"])
    return to_json(mapped)


# -----------------------------------------------------------------------------
# Flow Management
# -----------------------------------------------------------------------------


async def flow_list(
    client: AppliedClient,
    agent_id: str | None = None,
    status: str | None = None,
    output_format: str = "csv",
) -> str:
    """
    List flows for an agent.

    Args:
        client: Authenticated AppliedClient
        agent_id: Filter by agent ID (recommended)
        status: Filter by status - 'Active', 'Draft', or 'Archived'
        output_format: 'csv' or 'json'

    Returns:
        List of flows with id, name, type, trigger, status, updated_at
    """
    flows = await client.list_flows(agent_id=agent_id, status=status)
    mapped = [
        {
            "id": f.get("id"),
            "name": f.get("name"),
            "type": f.get("type"),
            "trigger": f.get("trigger"),
            "status": f.get("status"),
            "updated_at": f.get("updated_at", "")[:19],
        }
        for f in flows
    ]

    if output_format == "csv":
        return to_csv(mapped, ["id", "name", "type", "trigger", "status", "updated_at"])
    return to_json(mapped)


async def flow_get(
    client: AppliedClient,
    flow_id: str,
    output_format: str = "summary",
) -> str:
    """
    Get a flow with its full graph (nodes and edges).

    Args:
        client: Authenticated AppliedClient
        flow_id: The flow UUID
        output_format: 'summary' (default), 'full' (includes node metadata/prompts),
                       or 'json' (raw JSON)

    Returns:
        Flow metadata, nodes, and edges. Use 'full' to see node configurations.
    """
    flow = await client.get_flow(flow_id)
    graph = flow.get("graph", {})
    nodes = graph.get("nodes", [])
    edges = graph.get("edges", [])

    if output_format == "json":
        return to_json(flow)

    # Format header
    result = f"# Flow: {flow.get('name')}\n"
    result += f"id: {flow.get('id')}\n"
    result += f"type: {flow.get('type')}\n"
    result += f"trigger: {flow.get('trigger')}\n"
    result += f"status: {flow.get('status')}\n"
    if flow.get("description"):
        result += f"description: {flow.get('description')}\n"
    if flow.get("prompt"):
        result += f"purpose: {flow.get('prompt')}\n"

    # Format nodes
    result += f"\n## Nodes ({len(nodes)})\n"

    if output_format == "full":
        # Full output: include metadata, prompt, schemas for each node
        for n in nodes:
            data = n.get("data", {})
            node_name = data.get("name", n.get("id", ""))
            node_type = n.get("type", data.get("executor_type", ""))

            result += f"\n### {node_name}"
            if node_type and node_type != node_name:
                result += f" ({node_type})"
            result += "\n"
            result += f"id: {n.get('id')}\n"

            if data.get("description"):
                result += f"description: {data.get('description')}\n"

            if data.get("prompt"):
                prompt_preview = data.get("prompt", "")
                if len(prompt_preview) > 300:
                    prompt_preview = prompt_preview[:300] + "..."
                result += f"prompt: {prompt_preview}\n"

            metadata = data.get("metadata", {})
            if metadata:
                result += f"metadata: {json.dumps(metadata)}\n"

            outputs = data.get("outputs", {})
            if outputs and outputs.get("properties"):
                props = list(outputs.get("properties", {}).keys())
                result += f"output_fields: {', '.join(props)}\n"
    else:
        # Summary output: table format
        node_rows = [
            {
                "id": n.get("id"),
                "type": n.get("type", n.get("data", {}).get("name", "")),
                "description": n.get("data", {}).get("description", "")[:50],
            }
            for n in nodes
        ]
        result += to_csv(node_rows, ["id", "type", "description"])

    # Format edges
    result += f"\n## Edges ({len(edges)})\n"
    edge_rows = [
        {
            "id": e.get("id"),
            "source": e.get("source"),
            "target": e.get("target"),
            "source_handle": e.get("sourceHandle", ""),
            "target_handle": e.get("targetHandle", ""),
            "label": e.get("data", {}).get("label", ""),
        }
        for e in edges
    ]
    result += to_csv(
        edge_rows, ["id", "source", "target", "source_handle", "target_handle", "label"]
    )

    return result


async def flow_create(
    client: AppliedClient,
    agent_id: str,
    name: str,
    flow_type: str = "conversational",
    trigger: str = "llm.call",
    description: str = "",
) -> str:
    """
    Create a new flow.

    Args:
        client: Authenticated AppliedClient
        agent_id: The agent to attach the flow to
        name: Flow name
        flow_type: 'conversational' (default) or 'operational'
        trigger: 'llm.call' (conversation trigger), 'conversation.end', etc.
        description: Optional flow description

    Returns:
        Created flow with auto-generated trigger and escalation nodes
    """
    flow = await client.create_flow(
        agent_id=agent_id,
        name=name,
        flow_type=flow_type,
        trigger=trigger,
        description=description,
    )

    result = f"# Created Flow: {flow.get('name')}\n"
    result += f"id: {flow.get('id')}\n"
    result += f"type: {flow.get('type')}\n"
    result += f"trigger: {flow.get('trigger')}\n"
    result += f"status: {flow.get('status')}\n"
    result += "\nUse flow_get to see the auto-generated nodes."

    return result


async def flow_update(
    client: AppliedClient,
    flow_id: str,
    name: str | None = None,
    description: str | None = None,
    prompt: str | None = None,
    status: str | None = None,
) -> str:
    """
    Update a flow's properties.

    Args:
        client: Authenticated AppliedClient
        flow_id: The flow UUID
        name: New name
        description: New description
        prompt: Flow purpose (used for routing)
        status: 'Active', 'Draft', or 'Archived'

    Returns:
        Updated flow
    """
    updates = {}
    if name is not None:
        updates["name"] = name
    if description is not None:
        updates["description"] = description
    if prompt is not None:
        updates["prompt"] = prompt
    if status is not None:
        updates["status"] = status

    flow = await client.update_flow(flow_id, **updates)

    return f"# Updated Flow: {flow.get('name')}\nstatus: {flow.get('status')}"


async def flow_delete(
    client: AppliedClient,
    flow_id: str,
) -> str:
    """
    Delete a flow.

    Args:
        client: Authenticated AppliedClient
        flow_id: The flow UUID

    Returns:
        Success message
    """
    await client.delete_flow(flow_id)
    return f"Flow {flow_id} deleted successfully."


async def flow_archive(
    client: AppliedClient,
    flow_id: str,
) -> str:
    """
    Archive a flow (sets status to 'Archived').

    Archived flows are hidden from the active list but not deleted.
    Use this to clean up broken or redundant flows.

    Args:
        client: Authenticated AppliedClient
        flow_id: The flow UUID

    Returns:
        Success message
    """
    flow = await client.update_flow(flow_id, status="Archived")
    return f"# Archived Flow: {flow.get('name')}\nid: {flow_id}\nstatus: Archived"


# -----------------------------------------------------------------------------
# Node Management
# -----------------------------------------------------------------------------


async def flow_node_get(
    client: AppliedClient,
    flow_id: str,
    node_id: str,
) -> str:
    """
    Get a single node's full configuration.

    Args:
        client: Authenticated AppliedClient
        flow_id: The flow UUID
        node_id: The node UUID

    Returns:
        Full node config including metadata, prompt, executor type, and schemas
    """
    node = await client.get_node(flow_id, node_id)

    if not node:
        return f"Node {node_id} not found in flow {flow_id}"

    data = node.get("data", {})

    result = f"# Node: {data.get('name', node_id)}\n"
    result += f"id: {node.get('id')}\n"
    result += f"type: {node.get('type', data.get('executor_type', ''))}\n"

    if data.get("description"):
        result += f"description: {data.get('description')}\n"

    if data.get("prompt"):
        result += f"\n## Prompt\n{data.get('prompt')}\n"

    # Full metadata
    metadata = data.get("metadata", {})
    if metadata:
        result += "\n## Metadata\n"
        result += json.dumps(metadata, indent=2) + "\n"

    # Input schema
    inputs = data.get("inputs", {})
    if inputs:
        result += "\n## Input Schema\n"
        result += json.dumps(inputs, indent=2) + "\n"

    # Output schema
    outputs = data.get("outputs", {})
    if outputs:
        result += "\n## Output Schema\n"
        result += json.dumps(outputs, indent=2) + "\n"

    return result


async def flow_node_create(
    client: AppliedClient,
    flow_id: str,
    executor_type: str,
    description: str = "",
    prompt: str = "",
    metadata: dict | None = None,
) -> str:
    """
    Add a node to a flow.

    Args:
        client: Authenticated AppliedClient
        flow_id: The flow UUID
        executor_type: Node type - 'completion', 'structured_completion',
            'branch', 'loop', 'http_request', 'code', 'memory', etc.
        description: Node description
        prompt: Prompt for LLM nodes
        metadata: Node configuration as dict (position, comparisons, etc.)

    Returns:
        Created node with generated ID
    """
    # Validate common mistakes before API call
    valid_types = {
        "completion",
        "structured_completion",
        "branch",
        "code",
        "http_request",
        "loop",
        "memory",
        "search",
        "run_flow",
        "analyze",
        "return_data",
        "end_flow",
        "global",
        "_escalate_conversation",
        "handoff",
    }
    if executor_type not in valid_types:
        suggestions = [t for t in valid_types if executor_type.lower() in t.lower()]
        if not suggestions:
            suggestions = ["completion", "branch", "code"]
        return (
            f"❌ Error: Unknown executor_type '{executor_type}'.\n\n"
            f"💡 Did you mean one of: {', '.join(suggestions)}?\n"
            f"Run executor_list() to see all available node types with descriptions."
        )

    # Validate branch metadata
    if executor_type == "branch" and metadata:
        if "value" not in metadata:
            return (
                "❌ Error: Branch node requires 'value' in metadata.\n\n"
                '💡 Example: metadata=\'{"value": "{trigger.message}", '
                '"comparisons": [{"comparison_operator": "contains", '
                '"comparison_value": "yes", "comparison_type": "string"}], '
                '"position": {"x": 0, "y": 300}}\'\n\n'
                "Run flow_variables(flow_id) to see available variable references."
            )
        if "comparisons" not in metadata:
            return (
                "❌ Error: Branch node requires 'comparisons' in metadata.\n\n"
                '💡 Example comparison: {"comparison_operator": "contains", '
                '"comparison_value": "yes", "comparison_type": "string"}\n'
                "Operators: equals, not_equals, contains, not_contains, "
                "starts_with, ends_with, greater_than, less_than, is_empty, is_not_empty"
            )

    try:
        node = await client.create_node(
            flow_id=flow_id,
            name=executor_type,
            description=description,
            prompt=prompt,
            metadata=metadata,
        )
    except AppliedAPIError as e:
        return _format_error(e)

    result = "# Created Node\n"
    result += f"id: {node.get('id')}\n"
    result += f"name: {node.get('name')}\n"
    if description:
        result += f"description: {description}\n"

    return result


async def flow_node_update(
    client: AppliedClient,
    flow_id: str,
    node_id: str,
    description: str | None = None,
    prompt: str | None = None,
    metadata: dict | None = None,
) -> str:
    """
    Update a node's configuration.

    Args:
        client: Authenticated AppliedClient
        flow_id: The flow UUID
        node_id: The node UUID
        description: New description
        prompt: New prompt
        metadata: New metadata (merged with existing)

    Returns:
        Updated node
    """
    updates = {}
    if description is not None:
        updates["description"] = description
    if prompt is not None:
        updates["prompt"] = prompt
    if metadata is not None:
        updates["metadata"] = metadata

    node = await client.update_node(flow_id, node_id, **updates)

    return f"# Updated Node: {node.get('name')}\nid: {node.get('id')}"


async def flow_node_delete(
    client: AppliedClient,
    flow_id: str,
    node_id: str,
) -> str:
    """
    Remove a node from a flow.

    Args:
        client: Authenticated AppliedClient
        flow_id: The flow UUID
        node_id: The node UUID

    Returns:
        Success message
    """
    await client.delete_node(flow_id, node_id)
    return f"Node {node_id} deleted successfully."


# -----------------------------------------------------------------------------
# Edge Management
# -----------------------------------------------------------------------------


async def flow_edge_create(
    client: AppliedClient,
    flow_id: str,
    source_node_id: str,
    target_node_id: str,
    source_handle: str | None = None,
    target_handle: str | None = None,
    label: str | None = None,
) -> str:
    """
    Connect two nodes with an edge.

    Args:
        client: Authenticated AppliedClient
        flow_id: The flow UUID
        source_node_id: Source node UUID
        target_node_id: Target node UUID
        source_handle: Output handle name (for branching: "1", "2", "default")
        target_handle: Input handle name (for mapping)
        label: Edge label/condition

    Returns:
        Created edge
    """
    try:
        edge = await client.create_edge(
            flow_id=flow_id,
            source_node_id=source_node_id,
            target_node_id=target_node_id,
            source_handle=source_handle,
            target_handle=target_handle,
            label=label,
        )
    except AppliedAPIError as e:
        # Add extra context for edge errors
        extra = ""
        if source_handle:
            extra = (
                f"\n\nYou passed source_handle='{source_handle}'. "
                "For branch nodes, handles are '1', '2', '3' (matching comparison index) "
                "or 'default'. Run flow_node_get(flow_id, source_node_id) to check the "
                "node type and available outputs."
            )
        return _format_error(e) + extra

    result = "# Created Edge\n"
    result += f"id: {edge.get('id')}\n"
    result += f"source: {edge.get('source')}\n"
    result += f"target: {edge.get('target')}\n"

    return result


async def flow_edge_update(
    client: AppliedClient,
    flow_id: str,
    edge_id: str,
    label: str | None = None,
    metadata: dict | None = None,
) -> str:
    """
    Update an edge's properties.

    Args:
        client: Authenticated AppliedClient
        flow_id: The flow UUID
        edge_id: The edge UUID
        label: New label/condition
        metadata: New metadata

    Returns:
        Updated edge
    """
    updates = {}
    if label is not None:
        updates["label"] = label
    if metadata is not None:
        updates["metadata"] = metadata

    edge = await client.update_edge(flow_id, edge_id, **updates)

    return f"# Updated Edge\nid: {edge.get('id')}"


async def flow_edge_delete(
    client: AppliedClient,
    flow_id: str,
    edge_id: str,
) -> str:
    """
    Remove an edge from a flow.

    Args:
        client: Authenticated AppliedClient
        flow_id: The flow UUID
        edge_id: The edge UUID

    Returns:
        Success message
    """
    await client.delete_edge(flow_id, edge_id)
    return f"Edge {edge_id} deleted successfully."


# -----------------------------------------------------------------------------
# Flow Execution
# -----------------------------------------------------------------------------


async def flow_run(
    client: AppliedClient,
    flow_id: str,
    trigger_data: dict | None = None,
    wait: bool = True,
    wait_timeout: float = 60.0,
) -> str:
    """
    Execute a flow with test input.

    NOTE: Context fields like {trigger.shop.*} and {trigger.current_time} do NOT
    populate in flow_run. Use send_message(flow_id=...) for context-dependent flows.

    Args:
        client: Authenticated AppliedClient
        flow_id: The flow UUID
        trigger_data: Trigger input data, e.g.:
            {"message": "Hello"}
            {"message": "Help me", "contact": {"email": "user@example.com"}}
            {"conversation_id": "uuid-of-existing-conversation"}
        wait: If True (default), wait for completion and return full trace.
              If False, return immediately with just the run ID.
        wait_timeout: Max seconds to wait (default 60)

    Returns:
        Flow run with execution trace (if wait=True) or just run ID
    """
    try:
        run = await client.run_flow(
            flow_id,
            trigger_data,
            wait=wait,
            wait_timeout=wait_timeout,
        )
    except AppliedAPIError as e:
        return _format_error(e)

    result = f"# Flow Run: {run.get('id')}\n"
    result += f"status: {run.get('status')}\n"
    result += f"started_at: {run.get('started_at')}\n"

    if run.get("ended_at"):
        result += f"ended_at: {run.get('ended_at')}\n"
    if run.get("duration"):
        result += f"duration: {run.get('duration')}s\n"

    # Execution trace from spans
    spans = run.get("spans", [])
    if spans:
        result += f"\n## Execution Trace ({len(spans)} spans)\n"
        for i, span in enumerate(spans, 1):
            name = span.get("span_name", "")
            duration = span.get("duration", 0)
            status = span.get("status_code", "")
            status_msg = span.get("status_message", "")
            attrs = span.get("span_attributes", {})

            status_str = "OK" if "OK" in str(status) else "ERROR"
            result += f"{i}. [{name}] {duration:.2f}s - {status_str}"
            if status_msg:
                result += f" - {status_msg}"
            result += "\n"

            # Show output for executor_run spans
            if name == "executor_run" and attrs.get("output"):
                try:
                    output_data = json.loads(attrs["output"])
                    for k, v in output_data.items():
                        if k == "success":
                            continue
                        result += f"   output.{k}: {str(v)[:300]}\n"
                except (json.JSONDecodeError, TypeError):
                    result += f"   output: {str(attrs['output'])[:500]}\n"

            # completion: show the LLM text output
            elif name == "completion" and attrs.get("content"):
                result += f"   completion: {str(attrs['content'])[:500]}\n"

            # structured_completion: show parsed output
            elif name == "structured_completion" and attrs.get("output"):
                try:
                    out = json.loads(attrs["output"])
                    result += f"   output: {json.dumps(out, indent=None)[:400]}\n"
                except (json.JSONDecodeError, TypeError):
                    result += f"   output: {str(attrs['output'])[:400]}\n"

            # branch: show routing decision
            elif name == "branch":
                selected = attrs.get("selected.path", "")
                if selected:
                    result += f"   selected: {selected}\n"

    # Actions summary
    actions = run.get("actions", [])
    if actions:
        result += f"\n## Actions ({len(actions)})\n"
        action_rows = [
            {
                "node": a.get("tool", {}).get("name", ""),
                "status": a.get("status"),
            }
            for a in actions
        ]
        result += to_csv(action_rows, ["node", "status"])

    # Errors
    errors = [s for s in spans if "ERROR" in str(s.get("status_code", ""))]
    if errors:
        result += "\n## Errors\n"
        for err in errors:
            attrs = err.get("span_attributes", {})
            node_name = attrs.get("tool_name") or err.get("span_name") or "unknown"
            error_msg = err.get("status_message", "")
            result += f"**Node:** {node_name}\n"
            if error_msg:
                result += f"**Error:** {error_msg}\n"
            if attrs.get("output"):
                result += f"**Output:** {str(attrs.get('output'))[:500]}\n"
            result += "\n"

    # Add warnings for common issues
    warnings = []

    # Check for branches that took default with empty value
    for span in spans:
        attrs = span.get("span_attributes", {})
        if span.get("span_name") == "branch":
            selected = attrs.get("selected.path", "")
            if selected == "default":
                # Check if comparisons had empty values
                for key, val in attrs.items():
                    if "comparison" in key.lower() and '""' in str(val):
                        warnings.append(
                            "Branch took 'default' because comparison value was empty (\"\"). "
                            "This often happens because {trigger.shop.*} and {trigger.current_time} "
                            "don't populate in flow_run. Use send_message(flow_id=...) instead "
                            "for realistic testing of context-dependent branches."
                        )
                        break

    if warnings:
        result += "\n## ⚠️ Warnings\n"
        for w in set(warnings):  # dedupe
            result += f"- {w}\n"

    return result


async def flow_run_list(
    client: AppliedClient,
    flow_id: str | None = None,
    conversation_id: str | None = None,
    status: str | None = None,
    limit: int = 20,
    output_format: str = "csv",
) -> str:
    """
    List recent flow runs.

    Args:
        client: Authenticated AppliedClient
        flow_id: Filter by flow UUID
        conversation_id: Filter by conversation UUID
        status: Filter by status - 'Running', 'Success', 'Failed'
        limit: Max results (default 20)
        output_format: 'csv' or 'json'

    Returns:
        List of flow runs
    """
    runs = await client.list_flow_runs(
        flow_id=flow_id,
        conversation_id=conversation_id,
        status=status,
        limit=limit,
    )
    mapped = [
        {
            "id": r.get("id"),
            "flow_name": r.get("flow", {}).get("name", ""),
            "conversation_id": r.get("conversation_id", ""),
            "status": r.get("status"),
            "started_at": r.get("started_at", "")[:19],
            "duration": r.get("duration"),
        }
        for r in runs
    ]

    if output_format == "csv":
        return to_csv(
            mapped,
            ["id", "flow_name", "conversation_id", "status", "started_at", "duration"],
        )
    return to_json(mapped)


async def flow_run_get(
    client: AppliedClient,
    flow_run_id: str,
) -> str:
    """
    Get a flow run with execution trace.

    Args:
        client: Authenticated AppliedClient
        flow_run_id: The flow run UUID

    Returns:
        Run details, execution trace (spans), and errors
    """
    run = await client.get_flow_run(flow_run_id)

    # Header
    flow = run.get("flow", {})
    result = f"# Flow Run: {run.get('id')}\n"
    result += f"flow: {flow.get('name')} ({flow.get('id')})\n"
    result += f"status: {run.get('status')}\n"
    result += f"started_at: {run.get('started_at')}\n"
    result += f"ended_at: {run.get('ended_at')}\n"
    if run.get("duration"):
        result += f"duration: {run.get('duration')}s\n"

    # Execution trace from spans (API returns snake_case field names)
    spans = run.get("spans", [])
    if spans:
        result += f"\n## Execution Trace ({len(spans)} spans)\n"
        for i, span in enumerate(spans, 1):
            name = span.get("span_name", "")
            duration = span.get("duration", 0)
            status = span.get("status_code", "")
            status_msg = span.get("status_message", "")
            attrs = span.get("span_attributes", {})

            status_str = "OK" if "OK" in str(status) else "ERROR"
            result += f"{i}. [{name}] {duration:.2f}s - {status_str}"
            if status_msg:
                result += f" - {status_msg}"
            result += "\n"

            # executor_run: parse output JSON and show fields individually
            if name == "executor_run" and attrs.get("output"):
                try:
                    output_data = json.loads(attrs["output"])
                    for k, v in output_data.items():
                        if k == "success":
                            continue
                        result += f"   output.{k}: {str(v)[:300]}\n"
                except (json.JSONDecodeError, TypeError):
                    result += f"   output: {str(attrs['output'])[:500]}\n"

            # completion: show the LLM text output
            elif name == "completion" and attrs.get("content"):
                result += f"   completion: {str(attrs['content'])[:500]}\n"

            # structured_completion: show parsed output
            elif name == "structured_completion" and attrs.get("output"):
                try:
                    out = json.loads(attrs["output"])
                    result += f"   output: {json.dumps(out, indent=None)[:400]}\n"
                except (json.JSONDecodeError, TypeError):
                    result += f"   output: {str(attrs['output'])[:400]}\n"

            # branch: show routing decision and comparison breakdown
            elif name == "branch":
                selected = attrs.get("selected.path", "")
                if selected:
                    path_label = (
                        "default (no match)"
                        if selected == "default"
                        else f"branch {selected}"
                    )
                    result += f"   selected path: {path_label}\n"
                # Show comparison evaluations
                idx = 1
                while True:
                    op = attrs.get(f"comparison.{idx}.operator")
                    if not op:
                        break
                    lhs = attrs.get(f"comparison.{idx}.lhs", "?")
                    rhs = attrs.get(f"comparison.{idx}.rhs", "?")
                    res = attrs.get(f"comparison.{idx}.result", "?")
                    result += f"   comparison {idx}: {lhs} {op} {rhs} => {res}\n"
                    idx += 1

    # Actions
    actions = run.get("actions", [])
    if actions:
        result += f"\n## Actions ({len(actions)})\n"
        action_rows = [
            {
                "node": a.get("tool", {}).get("name", ""),
                "status": a.get("status"),
                "cost": a.get("cost", 0),
            }
            for a in actions
        ]
        result += to_csv(action_rows, ["node", "status", "cost"])

    # Errors section with detailed debugging info
    errors = [s for s in spans if "ERROR" in str(s.get("status_code", ""))]
    if errors:
        result += "\n## Errors\n"
        for err in errors:
            attrs = err.get("span_attributes", {})
            node_name = attrs.get("tool_name") or attrs.get("toolName") or "unknown"
            error_msg = err.get("status_message", "")

            result += f"**Node:** {node_name}\n"
            if error_msg:
                result += f"**Error:** {error_msg}\n"

            # Include relevant span attributes for debugging
            if attrs.get("output"):
                result += f"**Output:** {str(attrs.get('output'))[:500]}\n"
            if attrs.get("input"):
                result += f"**Input:** {str(attrs.get('input'))[:300]}\n"
            result += "\n"

    return result


async def conversation_spans(
    client: AppliedClient,
    conversation_id: str,
) -> str:
    """
    Get OpenTelemetry spans for a conversation.

    Args:
        client: Authenticated AppliedClient
        conversation_id: The conversation UUID

    Returns:
        Execution trace with spans, errors, and debugging info
    """
    spans = await client.get_spans("conversations", conversation_id)

    if not spans:
        return f"No spans found for conversation {conversation_id}"

    result = f"# Conversation Spans: {conversation_id}\n"
    result += f"Total spans: {len(spans)}\n"

    result += "\n## Execution Trace\n"
    for i, span in enumerate(spans, 1):
        name = span.get("span_name", "")
        scope = span.get("scope_name", "")
        duration = span.get("duration", 0)
        status = span.get("status_code", "")
        status_msg = span.get("status_message", "")
        attrs = span.get("span_attributes", {})

        # Build span identifier
        span_label = name or attrs.get("tool_name", "") or scope or "unknown"
        status_str = "OK" if "OK" in str(status) else "ERROR"

        result += f"{i}. [{span_label}] {duration:.2f}s - {status_str}"
        if status_msg:
            result += f"\n   Message: {status_msg}"
        result += "\n"

        # Show key attributes for debugging
        if attrs.get("output"):
            result += f"   Output: {str(attrs.get('output'))[:300]}\n"

    # Errors section
    errors = [s for s in spans if "ERROR" in str(s.get("status_code", ""))]
    if errors:
        result += "\n## Errors\n"
        for err in errors:
            attrs = err.get("span_attributes", {})
            node_name = attrs.get("tool_name") or err.get("span_name") or "unknown"
            error_msg = err.get("status_message", "")

            result += f"**Node:** {node_name}\n"
            if error_msg:
                result += f"**Error:** {error_msg}\n"
            result += "\n"

    return result


async def send_message(
    client: AppliedClient,
    agent_id: str,
    message: str,
    conversation_id: str | None = None,
    contact_email: str | None = None,
    contact_name: str | None = None,
    contact_phone: str | None = None,
    flow_id: str | None = None,
) -> str:
    """
    Send a message to an agent and get the response.

    Use this to test conversational flows. After sending, you can query
    the conversation messages with conversation_get for full details.

    Args:
        client: Authenticated AppliedClient
        agent_id: The agent UUID to send the message to
        message: The user message to send
        conversation_id: Optional - continue an existing conversation
        contact_email: Optional contact email (for flows that need it)
        contact_name: Optional contact name
        contact_phone: Optional contact phone
        flow_id: Optional - force a specific flow to run (bypasses routing)

    Returns:
        Conversation ID, response preview, and status
    """
    try:
        result = await client.send_message(
            agent_id=agent_id,
            message=message,
            flow_id=flow_id,
            conversation_id=conversation_id,
            contact_email=contact_email,
            contact_name=contact_name,
            contact_phone=contact_phone,
        )

        output = "# Message Sent\n"
        output += f"conversation_id: {result.get('conversation_id')}\n"
        output += f"status: {result.get('status')}\n"

        response = result.get("response", "")
        if response:
            # Truncate long responses for preview
            preview = response[:500] + "..." if len(response) > 500 else response
            output += f"\n## Response Preview\n{preview}\n"

        output += "\n## Next Steps\n"
        output += (
            "- Use `conversation_get` with the conversation_id to see full messages\n"
        )
        output += "- Use `flow_run_list` with conversation_id to see flow runs\n"
        output += "- Use `conversation_spans` for detailed execution trace\n"

        return output

    except Exception as e:
        return f"Error sending message: {e}"


async def executor_list(
    client: AppliedClient,
    output_format: str = "full",
) -> str:
    """
    List available node types (executors) with their metadata schemas.

    Args:
        client: Authenticated AppliedClient (not used, list is hardcoded)
        output_format: 'full' (default, includes schemas), 'csv' (names only), 'json'

    Returns:
        Available executor types with descriptions and metadata field schemas
    """
    # Hardcoded list of executors with metadata schemas
    executors = [
        {
            "name": "completion",
            "description": "LLM completion - generates free-form text",
            "use_case": "Responses, summaries, any text output",
            "metadata_fields": {
                "model": "string - LLM model (default: agent's model)",
                "temperature": "float - 0.0-1.0 (default: 0.7)",
                "max_tokens": "int - max output tokens",
            },
            "output_fields": ["completion"],
        },
        {
            "name": "structured_completion",
            "description": "LLM completion with structured JSON output",
            "use_case": "Extract data, classify, typed responses",
            "metadata_fields": {
                "model": "string - LLM model",
                "output_schema": "object - JSON Schema for output structure",
            },
            "output_fields": ["(defined by output_schema)"],
        },
        {
            "name": "branch",
            "description": "Conditional branching based on comparison or LLM",
            "use_case": "Route flow based on conditions",
            "metadata_fields": {
                "branch_type": "'comparison' or 'llm'",
                "branches": "array - branch definitions with conditions",
            },
            "output_fields": ["selected_branch"],
        },
        {
            "name": "code",
            "description": "Execute Python code in sandbox",
            "use_case": "Data transformation, calculations, API calls",
            "metadata_fields": {
                "language": "string - 'python' (required)",
                "code": "string - Python code to execute (required)",
                "packages": "array - pip packages to install, e.g. ['requests']",
            },
            "output_fields": ["result", "stdout", "stderr"],
        },
        {
            "name": "http_request",
            "description": "Make HTTP API calls",
            "use_case": "Integrate with external APIs",
            "metadata_fields": {
                "method": "string - GET, POST, PUT, DELETE",
                "url": "string - endpoint URL (supports {var} interpolation)",
                "headers": "object - request headers",
                "body": "object - request body for POST/PUT",
            },
            "output_fields": ["status_code", "data", "headers"],
        },
        {
            "name": "loop",
            "description": "Loop over a list and execute subflow",
            "use_case": "Process multiple items, batch operations",
            "metadata_fields": {
                "items_path": "string - variable path to iterate, e.g. {trigger.items}",
                "max_iterations": "int - limit iterations",
            },
            "output_fields": ["results", "count"],
        },
        {
            "name": "memory",
            "description": "Store/retrieve data in conversation memory",
            "use_case": "Remember user preferences, context across turns",
            "metadata_fields": {
                "operation": "'get' or 'set'",
                "key": "string - memory key",
                "value": "any - value to store (for set)",
            },
            "output_fields": ["value"],
        },
        {
            "name": "search",
            "description": "Search knowledge base",
            "use_case": "Find relevant documentation or Q&A",
            "metadata_fields": {
                "query": "string - search query (supports {var} interpolation)",
                "limit": "int - max results",
            },
            "output_fields": ["results", "count"],
        },
        {
            "name": "global",
            "description": "Global handler for escalation or failure",
            "use_case": "Catch-all for errors, default handler",
            "metadata_fields": {},
            "output_fields": [],
        },
        {
            "name": "_escalate_conversation",
            "description": "Escalate conversation to human agent",
            "use_case": "Hand off to support team",
            "metadata_fields": {
                "reason": "string - escalation reason",
            },
            "output_fields": [],
        },
        {
            "name": "handoff",
            "description": "Hand off to another flow or agent",
            "use_case": "Transfer to specialized flow",
            "metadata_fields": {
                "target_flow_id": "string - flow to hand off to",
            },
            "output_fields": [],
        },
        {
            "name": "end_flow",
            "description": "Explicitly end the flow",
            "use_case": "Terminate flow execution early",
            "metadata_fields": {},
            "output_fields": [],
        },
    ]

    if output_format == "csv":
        simple = [
            {"name": e["name"], "description": e["description"]} for e in executors
        ]
        return to_csv(simple, ["name", "description"])

    if output_format == "json":
        return to_json(executors)

    # Full output with schemas
    result = "# Available Node Types (Executors)\n\n"
    result += "Use these with flow_node_create(executor_type=...)\n\n"

    for ex in executors:
        result += f"## {ex['name']}\n"
        result += f"{ex['description']}\n"
        result += f"Use case: {ex['use_case']}\n"

        if ex.get("metadata_fields"):
            result += "\n**Metadata fields:**\n"
            for field, desc in ex["metadata_fields"].items():
                result += f"  - `{field}`: {desc}\n"

        if ex.get("output_fields"):
            result += f"\n**Output fields:** {', '.join(ex['output_fields'])}\n"

        result += "\n"

    result += "## Variable Reference Syntax\n"
    result += "Reference previous node outputs in prompts and metadata:\n"
    result += "- `{trigger.message}` - user's input message\n"
    result += "- `{trigger.contact.email}` - contact email\n"
    result += "- `{node_name.field}` - output from previous node\n"
    result += "- `{code-abc123.result}` - code node output\n"
    result += "- `{http_request-xyz.data.items}` - nested API response\n"

    return result


# -----------------------------------------------------------------------------
# Flow Variables
# -----------------------------------------------------------------------------

# Known output fields for each executor type
_EXECUTOR_OUTPUTS: dict[str, list[dict]] = {
    "completion": [
        {"field": "completion", "type": "string", "desc": "LLM generated text"},
    ],
    "structured_completion": [
        # Dynamic - parsed from output_schema in metadata
    ],
    "code": [
        {"field": "result", "type": "any", "desc": "Return value from code"},
        {"field": "stdout", "type": "string", "desc": "Standard output"},
        {"field": "stderr", "type": "string", "desc": "Standard error"},
    ],
    "http_request": [
        {"field": "status_code", "type": "integer", "desc": "HTTP status code"},
        {"field": "data", "type": "object", "desc": "Response body (JSON)"},
        {"field": "headers", "type": "object", "desc": "Response headers"},
    ],
    "branch": [
        {
            "field": "selected_branch",
            "type": "string",
            "desc": "Which branch was taken",
        },
    ],
    "loop": [
        {"field": "results", "type": "array", "desc": "Results from each iteration"},
        {"field": "count", "type": "integer", "desc": "Number of iterations"},
    ],
    "memory": [
        {"field": "value", "type": "any", "desc": "Retrieved memory value"},
    ],
    "search": [
        {"field": "results", "type": "array", "desc": "Search results"},
        {"field": "count", "type": "integer", "desc": "Number of results"},
    ],
    "trigger": [
        # Shown separately in built-in context section
    ],
}


def _parse_output_schema(metadata: dict) -> list[dict]:
    """
    Parse output_schema from structured_completion metadata.

    Returns list of {"field": "name", "type": "string", "desc": "..."}
    """
    output_schema = metadata.get("output_schema", [])
    fields = []

    # Handle array format: [{"name": "field", "type": "string", "description": "..."}]
    if isinstance(output_schema, list):
        for item in output_schema:
            if isinstance(item, dict) and item.get("name"):
                fields.append(
                    {
                        "field": item["name"],
                        "type": item.get("type", "any"),
                        "desc": item.get("description", "")[:40],
                    }
                )
    # Handle object format: {"properties": {"field": {"type": "string"}}}
    elif isinstance(output_schema, dict):
        props = output_schema.get("properties", {})
        for name, prop in props.items():
            fields.append(
                {
                    "field": name,
                    "type": prop.get("type", "any"),
                    "desc": prop.get("description", "")[:40],
                }
            )

    return fields


def _extract_schema_paths(
    schema: dict,
    prefix: str = "",
    defs: dict | None = None,
    max_depth: int = 4,
) -> list[dict]:
    """
    Recursively extract variable paths from a JSON Schema.

    Returns list of {"path": "field.subfield", "type": "string", "description": "..."}
    """
    if max_depth <= 0:
        return []

    defs = defs or schema.get("$defs", {})
    paths = []

    # Handle $ref
    if "$ref" in schema:
        ref_name = schema["$ref"].split("/")[-1]
        if ref_name in defs:
            return _extract_schema_paths(defs[ref_name], prefix, defs, max_depth)
        return []

    # Handle anyOf/oneOf (take first option)
    if "anyOf" in schema:
        for option in schema["anyOf"]:
            if option.get("type") != "null":
                return _extract_schema_paths(option, prefix, defs, max_depth)
        return []

    schema_type = schema.get("type", "")

    if schema_type == "object":
        props = schema.get("properties", {})
        for prop_name, prop_schema in props.items():
            path = f"{prefix}.{prop_name}" if prefix else prop_name
            prop_type = prop_schema.get("type", "any")
            desc = prop_schema.get("description", "")

            # Add this path
            paths.append({"path": path, "type": prop_type, "description": desc[:60]})

            # Recurse for nested objects/arrays
            if prop_type == "object":
                paths.extend(
                    _extract_schema_paths(prop_schema, path, defs, max_depth - 1)
                )
            elif prop_type == "array":
                items = prop_schema.get("items", {})
                if items:
                    # Add [0] and [*] access patterns
                    paths.append(
                        {
                            "path": f"{path}[0]",
                            "type": "item",
                            "description": "First item",
                        }
                    )
                    paths.append(
                        {
                            "path": f"{path}[*]",
                            "type": "list",
                            "description": "Map over all",
                        }
                    )
                    # Recurse into array items
                    paths.extend(
                        _extract_schema_paths(items, f"{path}[0]", defs, max_depth - 1)
                    )

    elif schema_type == "array":
        items = schema.get("items", {})
        if items and prefix:
            paths.append(
                {"path": f"{prefix}[0]", "type": "item", "description": "First item"}
            )
            paths.extend(
                _extract_schema_paths(items, f"{prefix}[0]", defs, max_depth - 1)
            )

    return paths


def _topological_sort(nodes: list[dict], edges: list[dict]) -> list[dict]:
    """Sort nodes in topological order based on edges."""
    # Build adjacency and in-degree
    node_map = {n["id"]: n for n in nodes}
    in_degree = {n["id"]: 0 for n in nodes}
    children = {n["id"]: [] for n in nodes}

    for e in edges:
        src, tgt = e.get("source"), e.get("target")
        if src in node_map and tgt in node_map:
            children[src].append(tgt)
            in_degree[tgt] = in_degree.get(tgt, 0) + 1

    # Kahn's algorithm
    queue = [nid for nid, deg in in_degree.items() if deg == 0]
    result = []

    while queue:
        nid = queue.pop(0)
        result.append(node_map[nid])
        for child in children.get(nid, []):
            in_degree[child] -= 1
            if in_degree[child] == 0:
                queue.append(child)

    return result


def _get_node_output_fields(node: dict) -> list[dict]:
    """
    Get output fields for a node based on its type and configuration.

    Returns list of {"field": "name", "type": "string", "desc": "..."}
    """
    node_data = node.get("data", {})
    node_type = node.get("type", node_data.get("executor_type", ""))
    metadata = node_data.get("metadata", {})

    # For structured_completion, parse output_schema from metadata
    if node_type == "structured_completion":
        fields = _parse_output_schema(metadata)
        if fields:
            return fields

    # For other types, use known outputs
    return _EXECUTOR_OUTPUTS.get(node_type, [])


async def flow_variables(
    client: AppliedClient,
    flow_id: str,
    node_id: str | None = None,
) -> str:
    """
    List available variables for a flow, showing what can be referenced in prompts
    and node configurations using {node_name.field} syntax.

    Dynamically inspects all nodes in the flow and shows their output fields,
    including custom fields from structured_completion output_schema.

    Args:
        client: Authenticated AppliedClient
        flow_id: The flow UUID
        node_id: Optional - show only variables available to this specific node
                 (predecessors in the graph). If omitted, shows all variables.

    Returns:
        Formatted list of available variables grouped by source node,
        with paths, types, and descriptions.

    Example output:
        ## 1. trigger
        {trigger.message}              string   User's message
        {trigger.shop.is_open}         boolean  Business hours check

        ## 2. structured_completion-abc123
        {structured_completion-abc123.order_id}     string   Extracted order ID
        {structured_completion-abc123.refund_reason} string   Refund reason

        ## 3. http_request-xyz789
        {http_request-xyz789.data}          object   Response body
        {http_request-xyz789.status_code}   integer  HTTP status
    """
    flow = await client.get_flow(flow_id)
    graph = flow.get("graph", {})
    nodes = graph.get("nodes", [])
    edges = graph.get("edges", [])

    # Sort nodes topologically
    sorted_nodes = _topological_sort(nodes, edges)

    # If node_id specified, find its predecessors
    if node_id:
        # Build predecessor set via BFS backwards
        parents = {n["id"]: set() for n in nodes}
        for e in edges:
            tgt = e.get("target")
            src = e.get("source")
            if tgt and src:
                parents[tgt].add(src)

        # BFS to find all ancestors
        ancestors = set()
        queue = list(parents.get(node_id, set()))
        while queue:
            p = queue.pop(0)
            if p not in ancestors:
                ancestors.add(p)
                queue.extend(parents.get(p, set()))

        # Filter to only ancestor nodes
        sorted_nodes = [n for n in sorted_nodes if n["id"] in ancestors]

    result = "# Available Variables for Flow\n"
    result += "Use {node_name.field} syntax in prompts and metadata.\n\n"

    node_count = 0

    for node in sorted_nodes:
        node_data = node.get("data", {})
        node_name = node_data.get("name", node.get("id", ""))
        node_type = node.get("type", node_data.get("executor_type", ""))

        # Skip trigger (handled separately) and global nodes
        if node_type in ("trigger", "global", "_escalate_conversation"):
            continue

        # Get output fields for this node type
        output_fields = _get_node_output_fields(node)

        # Also check if node has outputs schema from backend
        outputs_schema = node_data.get("outputs", {})
        if outputs_schema and outputs_schema.get("properties"):
            schema_paths = _extract_schema_paths(outputs_schema)
            # Merge with known fields
            seen_fields = {f["field"] for f in output_fields}
            for p in schema_paths:
                if p["path"] not in seen_fields and "." not in p["path"]:
                    output_fields.append(
                        {
                            "field": p["path"],
                            "type": p["type"],
                            "desc": p["description"][:40] if p["description"] else "",
                        }
                    )

        # Skip nodes with no outputs
        if not output_fields:
            continue

        node_count += 1
        result += f"## {node_count}. {node_name}"
        if node_type and node_type != node_name.split("-")[0]:
            result += f" ({node_type})"
        result += "\n"

        for f in output_fields:
            var_path = f"{{{node_name}.{f['field']}}}"
            type_str = str(f["type"])[:10].ljust(10)
            desc = f.get("desc", "")
            result += f"  {var_path:<50} {type_str} {desc}\n"

        result += "\n"

    if node_count == 0:
        result += "(No nodes with outputs yet - add completion, code, or http_request nodes)\n\n"

    result += "## Built-in Trigger Context (llm.call trigger)\n"
    result += "The trigger node always provides these fields:\n\n"
    result += "**{trigger.shop}** - Workspace/shop object:\n"
    result += (
        "  {trigger.shop.is_open}          boolean    whether shop is currently open\n"
    )
    result += "  {trigger.shop.name}             string     shop name\n"
    result += "  {trigger.shop.timezone}         string     e.g. 'America/New_York'\n"
    result += "  {trigger.shop.address}          string     shop address\n"
    result += "\n"
    result += "**{trigger.contact}** - Customer contact:\n"
    result += "  {trigger.contact.email}         string     contact email\n"
    result += "  {trigger.contact.name}          string     contact name\n"
    result += "  {trigger.contact.phone}         string     contact phone\n"
    result += "\n"
    result += "**{trigger.conversation}** - Current conversation:\n"
    result += "  {trigger.conversation.id}       string     conversation UUID\n"
    result += "  {trigger.conversation.title}    string     conversation title\n"
    result += (
        "  {trigger.conversation.resolution} string   e.g. 'resolved', 'escalated'\n"
    )
    result += "\n"
    result += "**{trigger.messages}** - Message history (array)\n"
    result += "**{trigger.attachments}** - Uploaded files (array)\n"
    result += "**{trigger.current_time}** - ISO timestamp (string)\n"
    result += "\n"
    result += "## Tips\n"
    result += (
        "- Check {trigger.shop.is_open} in a branch instead of writing a code node\n"
    )
    result += (
        "- Reference node outputs: {completion-abc.completion}, {code-xyz.result}\n"
    )
    result += "- Access nested fields with dots: {http_request-api.data.order.status}\n"

    return result
