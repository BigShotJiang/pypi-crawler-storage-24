# Environment setup helpers and dotfile bootstrap

This project packages shell/python helpers and rc file setup utilities.

## Install

```bash
pip install xiaoranli
```

## CLI usage

```bash
xiaoranli info
xiaoranli setup_rc_files --dry_run=False
```

## Release (PyPI)

Releases are published from branch `xiaoranli`.

```bash
git checkout xiaoranli
git fetch origin
git rebase origin/main
./publish_to_pypi.sh
```

Release script safeguards:
- requires current branch `xiaoranli`
- requires clean git status (including untracked files)
- computes next patch version from PyPI `xiaoranli` release history
- aborts if `PKG_VERSION` override is not respected by `setup.py`
