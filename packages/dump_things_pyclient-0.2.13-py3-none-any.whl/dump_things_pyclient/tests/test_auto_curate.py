import json
import posix
import random
import subprocess
from itertools import chain

from click.testing import CliRunner

from dump_things_pyclient.commands.dtc import cli
from dump_things_pyclient.tests.common import read_records_from_store
from pygments.lexers import r


prefix = 'https://www.example.com/ac_e2e_test/'


def _create_unique_records(offset: int, count: int) -> dict[int, dict]:
    while True:
        pids = tuple(set(random.randrange(offset, offset + 10000) for _ in range(count)))
        if len(pids) == count:
            break
    return {
        # NOTE: the order of keys is relevant because there are JSON-string
        #  comparisons in the change-set tests below.
        pid: {
            'schema_type': 'test:Person',
            'pid': prefix + f'person_{pid}',
            'family_name': f'grieg_{pid}',
            'given_name': f'erwin_{pid}',
        }
        for pid in pids
    }


def test_auto_curate_basic_end_to_end(dump_things_service):
    port, store = dump_things_service


    new_records = tuple(_create_unique_records(10000, 5).values())

    # Add records to inbox
    runner = CliRunner()
    result = runner.invoke(
        cli,
        ['--token=basic_access', 'post-records', f'http://127.0.0.1:{port}', 'collection_1', 'Person'],
        input='\n'.join(
            json.dumps(record, ensure_ascii=False) for record in new_records
        ) + '\n'
    )
    assert result.exit_code == 0, 'dtc post-records failed'

    # Ensure that the records do not yet exist in the curated area
    stored_curated_records = tuple(
        map(
            lambda e: e[2],
            read_records_from_store(store, class_name='Person', remove_keys=['annotations'])
        )
    )
    for record in new_records:
        assert record not in stored_curated_records, 'record already exists, possibly a random number collision'

    # Perform auto-curation
    result = runner.invoke(
        cli,
        ['--token=token-curator', 'auto-curate', '-i', 'tester', f'http://127.0.0.1:{port}', 'collection_1'],
    )
    assert result.exit_code == 0, 'dtc auto-curate failed'

    # Check that the inbox is empty
    stored_inbox_records = tuple(
        map(
            lambda e: e[2],
            read_records_from_store(store, incoming='tester')
        )
    )
    assert stored_inbox_records == tuple(), 'Inbox not clean after auto-curation'

    # Check that the records are in the curated area
    stored_curated_records = tuple(
        map(
            lambda e: e[2],
            read_records_from_store(store, class_name='Person', remove_keys=['annotations'])
        )
    )
    for record in new_records:
        assert record in stored_curated_records


def test_auto_curate_create_change_set_end_to_end(dump_things_service, tmp_path_factory):
    port, store = dump_things_service
    change_set_dir = tmp_path_factory.mktemp('create_change_set')

    new_records = _create_unique_records(20000, 5)
    new_curated_records = _create_unique_records(30000, 5)

    # Add new curated records to inbox and auto-curate them to move them to
    # the curated area.
    runner = CliRunner()
    result = runner.invoke(
        cli,
        ['--token=basic_access', 'post-records', f'http://127.0.0.1:{port}', 'collection_1', 'Person'],
        input='\n'.join(
            json.dumps(record, ensure_ascii=False) for record in new_curated_records.values()
        ) + '\n'
    )
    assert result.exit_code == 0, 'dtc post-records failed'

    # Perform auto-curation
    result = runner.invoke(
        cli,
        ['--token=token-curator', 'auto-curate', '-i', 'tester', f'http://127.0.0.1:{port}', 'collection_1'],
    )
    assert result.exit_code == 0, 'dtc auto-curate failed'

    # Modify the record that were auto-curated and upload those together with
    # newly created records to the inbox.
    modified_curated_records = {
        # NOTE: the order of keys is relevant because there are JSON-string
        #  comparisons in the change-set tests below.
        pid: {
            'schema_type': 'test:Person',
            'pid': record['pid'],
            'family_name': record['family_name'],
            'given_name': record['given_name'].replace('erwin', 'edvard'),
        }
        for pid, record in new_curated_records.items()
    }

    # Upload the modified (already curated) records and the new records to the
    # inbox.
    result = runner.invoke(
        cli,
        ['--token=basic_access', 'post-records', f'http://127.0.0.1:{port}', 'collection_1', 'Person'],
        input='\n'.join(
            json.dumps(record, ensure_ascii=False)
            for record in chain(modified_curated_records.values(), new_records.values())
        ) + '\n'
    )
    assert result.exit_code == 0, 'dtc post-records failed'

    # Create a change set
    result = runner.invoke(
        cli,
        [
            '--token=token-curator',
            'auto-curate',
            '--create-change-set', str(change_set_dir),
            '-i', 'tester',
            f'http://127.0.0.1:{port}', 'collection_1',
        ],
    )
    assert result.exit_code == 0, 'dtc auto-curate --create-change-set failed'

    # Check the number of modified records in the change set
    result = subprocess.run(
        ['git', 'status', '-s',],
        cwd=str(change_set_dir),
        check=True,
        capture_output=True,
    )
    lines = [
        line.strip()
        for line in result.stdout.decode().splitlines()
        if 'annotations' not in line
    ]
    assert len(lines) == len(new_records) + len(modified_curated_records), f'unexpected number of modified records: {len(lines)}'
    assert all(l.startswith('M records/tester') for l in lines), f'unexpected status for modified records: {lines}'

    # Check for expected diff content
    result = subprocess.run(
        ['git', 'diff', '-p',],
        cwd=str(change_set_dir),
        check=True,
        capture_output=True,
    )
    lines = [line.strip() for line in result.stdout.decode().splitlines()]
    # Every diff should be seven lines long, the line at index 5 contains the
    # previous content, the line at index 6 contains the new content.
    for patch in range(int(len(lines) / 7)):
        old = json.loads(lines[(7 * patch) + 5][1:])
        new = json.loads(lines[(7 * patch) + 6][1:])
        pid = int(lines[7 * patch][-5:])
        if pid in new_records:
            assert old == None
            assert new == new_records[pid]
        else:
            assert old == new_curated_records[pid]
            assert new == modified_curated_records[pid]

    # Check that annotations are stored in the change set
    annotations = {
        int(p.name[-5:]): json.loads(p.read_text())
        for p in (change_set_dir / 'annotations').glob('tester/*')
    }
    assert len(annotations) == len(modified_curated_records) + len(new_curated_records)


def test_auto_curate_post_change_set_end_to_end(dump_things_service, tmp_path_factory):
        port, store = dump_things_service
        change_set_dir = tmp_path_factory.mktemp('post_change_set')

        new_records = _create_unique_records(40000, 5)

        # Add new records to inbox of 'tester'.
        runner = CliRunner()
        result = runner.invoke(
            cli,
            ['--token=basic_access', 'post-records', f'http://127.0.0.1:{port}', 'collection_1', 'Person'],
            input='\n'.join(
                json.dumps(record, ensure_ascii=False) for record in new_records.values()
            ) + '\n'
        )
        assert result.exit_code == 0, 'dtc post-records failed'

        # Create a change set with the records from 'tester's' inbox
        result = runner.invoke(
            cli,
            [
                '--token=token-curator',
                'auto-curate',
                '--create-change-set', str(change_set_dir),
                '-i', 'tester',
                f'http://127.0.0.1:{port}', 'collection_1',
            ],
        )
        assert result.exit_code == 0, 'dtc auto-curate --create-change-set failed'

        # Post the changeset without annotations
        result = runner.invoke(
            cli,
            [
                '--token=token-curator',
                'auto-curate',
                '--post-change-set', str(change_set_dir),
                f'http://127.0.0.1:{port}', 'collection_1',
            ],
        )
        assert result.exit_code == 0, 'dtc auto-curate --post-change-set failed'

        # Check that new records have been posted without annotations
        curated_records = tuple(
            map(
                lambda e: e[2],
                read_records_from_store(
                    store,
                    class_name='Person',
                )
            )
        )

        for record in new_records.values():
            assert record in curated_records
        for record in curated_records:
            try:
                record_pid = int(record['pid'][-5:])
                if record_pid in new_records:
                    assert 'annotations' not in record, f'unexpected annotations in {record}'
            except ValueError:
                continue

        # Post the changeset with annotations
        result = runner.invoke(
            cli,
            [
                '--token=token-curator',
                'auto-curate',
                '--post-change-set', str(change_set_dir),
                '--add-annotations',
                f'http://127.0.0.1:{port}', 'collection_1',
            ],
        )
        assert result.exit_code == 0, 'dtc auto-curate --post-change-set --add-annotations failed'

        # Check that new records have been posted with annotations
        curated_records = tuple(
            map(
                lambda e: e[2],
                read_records_from_store(
                    store,
                    class_name='Person',
                )
            )
        )

        # Check that all record content has been posted
        cleaned_curated_records = tuple(
            {
                'schema_type': r['schema_type'],
                'pid': r['pid'],
                'family_name': r['family_name'],
                'given_name': r['given_name'],
            }
            for r in curated_records
        )

        for record in new_records.values():
            assert record in cleaned_curated_records

        # Check that annotations were posted.
        annotations = {
            p.name.replace('-_', '/').replace('--', '-'): json.loads(p.read_text())
            for p in change_set_dir.glob('annotations/tester/*')
        }

        for record in curated_records:
            try:
                record_pid = int(record['pid'][-5:])
                if record_pid in new_records:
                    assert 'annotations' in record, f'missing annotations in {record}'
                    assert record['annotations'] == annotations[record['pid']]
            except ValueError:
                continue
