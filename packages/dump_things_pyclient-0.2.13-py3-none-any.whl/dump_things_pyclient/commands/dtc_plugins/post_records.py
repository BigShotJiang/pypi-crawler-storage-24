import json
import logging
import sys
from itertools import count

import rich_click as click
from rich.console import Console
from rich.progress import track

from ...communicate import (
    HTTPError,
    curated_write_record,
    collection_write_record,
    get_session,
)
from .common.prefix import de_prefix


subcommand_name = 'post-records'

logger = logging.getLogger('post-records')

console = Console(file=sys.stderr)


@click.command(short_help='Post records to an inbox or the curated area of a dump-things collection')
@click.pass_obj
@click.argument(
    'service_url',
    metavar='SERVICE_URL',
)
@click.argument(
    'collection',
    metavar='COLLECTION',
)
@click.argument(
    'cls',
    metavar='CLASS',
)
@click.option(
    '--curated',
    default=False,
    is_flag=True,
    help='store record directly in curated area instead of an inbox. (Note: requires a token with curator rights)'
)
@click.option(
    '--ignore-errors',
    default=False,
    is_flag=True,
    help='ignore errors when posting a record and continue with remaining records',
)
@click.option(
    '--dry-run', '-d',
    help='if provided, do not alter any data, instead print what would be done',
    default=False,
    is_flag=True,
)
def cli(
        obj,
        service_url,
        collection,
        cls,
        curated,
        ignore_errors,
        dry_run,
):
    """Read records of class CLASS from standard input and store them in
    the collection COLLECTION on the service SERVICE_URL. Records should be
    provided in JSON-lines format. Note: if CLASS is `*` post-records will try
    to infer the class from a `schema_type` property in the input records.
    Otherwise, all records are
    assumed to be of class CLASS. In this case, to submit records of multiple
    classes, the
    subcommand has to be invoked multiple times, once for each class.

    If the `--curated`-option is provided, the records will be stored directly
    in the curated area of the collection without any alterations, i.e, no
    annotations will be added.

    If no `--curated`-option is provided, the record will be stored in the
    inbox of the user that is associated with the token, and the record will be
    annotated with the submission time and the user that performed
    the submission.

    If any record could not be posted, error information about the failing pids
    will be written to stdout in JSON Lines format (one line per faulty record).

    A token is required and will be used to authenticate the requests.
    If the `--curated`-option is provided, the token must have
    curator-rights."""
    sys.exit(
        post_records(
            obj,
            service_url,
            collection,
            cls,
            curated,
            ignore_errors,
            dry_run,
        )
    )


def post_records(
        obj,
        service_url,
        collection,
        cls,
        curated,
        ignore_errors,
        dry_run,
) -> int:
    token = obj
    if token is None:
        console.print('[red]Error[/red]: No token provided')
        return 1

    if curated:
        write_record = curated_write_record
    else:
        write_record = collection_write_record

    failed = []
    session = get_session()
    for index, line in zip(count(), track(sys.stdin, console=console)):

        try:
            record = json.loads(line)
        except Exception as e:
            _handle_json_load_error(failed, index, line, e)
            if ignore_errors:
                continue
            break

        if cls == '*':
            class_name = get_class_from_record(record)
            if class_name is None:
                _handle_schema_type_error(failed, index, record)
                if ignore_errors:
                    continue
                break
        else:
            class_name = cls

        if dry_run:
            if curated:
                console.print(f'[DRY_RUN]:WRITE record [green]"{record["pid"]}"[/green] of class "{class_name}" to curated area of collection "{collection}" on "{service_url}"')
            else:
                console.print(f'[DRY_RUN]:WRITE record [green]"{record["pid"]}"[/green] of class "{class_name}" to token-associated incoming area of collection "{collection}" on "{service_url}"')
            continue

        try:
            write_record(
                service_url=service_url,
                collection=collection,
                class_name=class_name,
                record=record,
                token=token,
                session=session,
            )
        except HTTPError as e:
            _handle_http_error(failed, index, line, e)
            if ignore_errors:
                continue
            break
        except Exception as e:
            console.print(
                f'[red]Error: writing record #{index} with pid {record["pid"]} failed[/red]: {e}',
            )
            raise

    if failed:
        click.echo('\n'.join(failed))
        return 1
    return 0


def _handle_json_load_error(
        container: list,
        index: int,
        line: str,
        exc: Exception,
):
    console.print(f'[red]Error[/red]: error loading line [red]#{index}[/red]: {line}')
    container.append(
        json.dumps(
            {
                'status': 'json_load_error',
                'index': index,
                'json': line,
                'detail': str(exc),
            }
        )
    )


def _handle_http_error(
        container: list,
        index: int,
        line: str,
        exc: HTTPError,
):
    console.print(f'[red]Error[/red]: error writing line [red]#{index}[/red]: {line}')
    container.append(
        json.dumps(
            {
                'status': 'http_error',
                'index': index,
                'json': line,
                'url': exc.request.url,
                'http_status': exc.response.status_code,
                'http_response': exc.response.text,
            }
        )
    )


def _handle_schema_type_error(
        container: list,
        index: int,
        record: dict,
):
    console.print(f'[red]Error[/red]: no `schema type` in record [red]#{index}[/red], pid: [red]{record["pid"]}[/red]')
    container.append(
        json.dumps(
            {
                'status': 'class_reading_error',
                'pid': record['pid'],
                'record': record,
                'message': f'could not get class from record {record["pid"]}',
            }
        )
    )


def get_class_from_record(record: dict) -> str | None:
    if 'schema_type' in record:
        return de_prefix(record['schema_type'])
    return None
