from rule_engine_core.metadata_dao import MetadataDao, sync_metadata_store_file


class StubCursor:
    def __init__(self, connection):
        self._connection = connection
        self._rows = []
        self._single_row = None

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        return False

    def execute(self, query, params=None):
        if "SELECT column_name, metadata_json FROM metadata" in query:
            self._rows = [(k, v) for k, v in self._connection.store.items()]
        elif "SELECT metadata_json FROM metadata WHERE column_name = %s" in query:
            value = self._connection.store.get(params[0])
            self._single_row = (value,) if value is not None else None
        elif "INSERT INTO metadata" in query:
            self._connection.store[params[0]] = getattr(params[1], "adapted", params[1])
        elif "DELETE FROM metadata WHERE column_name = %s" in query:
            self._connection.store.pop(params[0], None)

    def fetchall(self):
        return self._rows

    def fetchone(self):
        return self._single_row


class StubConnection:
    def __init__(self):
        self.store = {"price": {"type": "float"}}
        self.closed = 0

    def cursor(self):
        return StubCursor(self)

    def commit(self):
        return None

    def rollback(self):
        return None

    def close(self):
        self.closed = 1


def test_metadata_dao_crud_and_dump(monkeypatch, tmp_path):
    stub_connection = StubConnection()
    monkeypatch.setattr("rule_engine_core.metadata_dao.create_connection", lambda _: stub_connection)
    metadata_dao = MetadataDao()

    assert metadata_dao.get_all_metadata() == {"price": {"type": "float"}}
    assert metadata_dao.get_metadata("price") == {"type": "float"}
    assert metadata_dao.get_metadata("missing") is None

    assert metadata_dao.upsert_metadata("country", {"type": "string"})
    assert metadata_dao.get_metadata("country") == {"type": "string"}

    assert metadata_dao.delete_metadata("country")
    assert metadata_dao.get_metadata("country") is None

    metadata_file_path = tmp_path / "metadata.json"
    metadata = metadata_dao.dump_metadata_to_file(str(metadata_file_path))
    assert metadata == {"price": {"type": "float"}}
    assert metadata_file_path.exists()


def test_sync_metadata_store_file_uses_env_path(monkeypatch, tmp_path):
    stub_connection = StubConnection()
    monkeypatch.setattr("rule_engine_core.metadata_dao.create_connection", lambda _: stub_connection)
    metadata_file_path = tmp_path / "metadata-from-env.json"
    monkeypatch.setenv("METADATA_STORE_FILE_PATH", str(metadata_file_path))

    metadata = sync_metadata_store_file()

    assert metadata == {"price": {"type": "float"}}
    assert metadata_file_path.exists()
