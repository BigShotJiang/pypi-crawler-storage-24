"""
DAO and sync helpers for metadata persisted in PostgreSQL.
"""

import json
import os
import logging
import psycopg2
from typing import Optional
from psycopg2.extensions import connection as PgConnection
from psycopg2.extras import Json
from rule_engine_core.entity_dao import create_connection

_logger = logging.getLogger(__name__)


class MetadataDao:
    def __init__(self, config: Optional[dict] = None):
        self._connection: Optional[PgConnection] = create_connection(config)
        if self._connection is None:
            raise RuntimeError("Failed to create a connection to the database")

    def get_all_metadata(self) -> dict[str, dict]:
        with self._connection.cursor() as cursor:
            cursor.execute("SELECT column_name, metadata_json FROM metadata")
            rows = cursor.fetchall()
            return {row[0]: row[1] for row in rows}

    def get_metadata(self, column_name: str) -> Optional[dict]:
        with self._connection.cursor() as cursor:
            cursor.execute(
                "SELECT metadata_json FROM metadata WHERE column_name = %s",
                (column_name,),
            )
            row = cursor.fetchone()
            return row[0] if row is not None else None

    def upsert_metadata(self, column_name: str, metadata_json: dict) -> bool:
        with self._connection.cursor() as cursor:
            try:
                cursor.execute(
                    """
                    INSERT INTO metadata (column_name, metadata_json)
                    VALUES (%s, %s)
                    ON CONFLICT (column_name)
                    DO UPDATE SET metadata_json = EXCLUDED.metadata_json
                    """,
                    (column_name, Json(metadata_json)),
                )
                self._connection.commit()
                return True
            except psycopg2.Error:
                _logger.exception("Failed to upsert metadata for column: %s", column_name)
                self._connection.rollback()
                return False

    def delete_metadata(self, column_name: str) -> bool:
        with self._connection.cursor() as cursor:
            try:
                cursor.execute("DELETE FROM metadata WHERE column_name = %s", (column_name,))
                self._connection.commit()
                return True
            except psycopg2.Error:
                _logger.exception("Failed to delete metadata for column: %s", column_name)
                self._connection.rollback()
                return False

    def dump_metadata_to_file(self, metadata_store_file_path: str) -> dict[str, dict]:
        metadata = self.get_all_metadata()
        parent_dir = os.path.dirname(metadata_store_file_path)
        if parent_dir:
            os.makedirs(parent_dir, exist_ok=True)
        with open(metadata_store_file_path, "w", encoding="utf-8") as metadata_file:
            json.dump(metadata, metadata_file, indent=4)
        return metadata

    def __del__(self):
        self.close()

    def close(self):
        if self._connection is not None:
            self._connection.close()
            self._connection = None


def sync_metadata_store_file(config: Optional[dict] = None, metadata_store_file_path: Optional[str] = None) -> dict[str, dict]:
    resolved_metadata_store_file_path = metadata_store_file_path or os.getenv("METADATA_STORE_FILE_PATH", "metadata.json")
    metadata_dao = MetadataDao(config)
    return metadata_dao.dump_metadata_to_file(resolved_metadata_store_file_path)
