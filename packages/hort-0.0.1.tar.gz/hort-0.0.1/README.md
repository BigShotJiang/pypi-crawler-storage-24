# hort

Keep your little agentlings under control — remote viewer and controller for Windows, macOS, and Linux

> This is a placeholder release. The full package is coming soon.
