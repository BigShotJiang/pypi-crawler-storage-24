from corp_names.data.nicknames import NICKNAME_TO_CANONICAL
from corp_names.data.prefixes import PREFIXES
from corp_names.data.suffixes import SUFFIXES


def test_prefixes_not_empty():
    assert len(PREFIXES) > 100


def test_suffixes_not_empty():
    assert len(SUFFIXES) > 100


def test_nicknames_not_empty():
    assert len(NICKNAME_TO_CANONICAL) > 200


def test_common_nicknames():
    assert NICKNAME_TO_CANONICAL["bob"] == "robert"
    assert NICKNAME_TO_CANONICAL["bill"] == "william"
    assert NICKNAME_TO_CANONICAL["liz"] == "elizabeth"
    assert NICKNAME_TO_CANONICAL["mike"] == "michael"
    assert NICKNAME_TO_CANONICAL["jim"] == "james"
    assert NICKNAME_TO_CANONICAL["ted"] == "theodore"
    assert NICKNAME_TO_CANONICAL["jack"] == "john"
    assert NICKNAME_TO_CANONICAL["peggy"] == "margaret"


def test_formal_names_not_resolved():
    """Formal names should not appear as keys in the mapping."""
    for name in ("john", "james", "william", "robert", "mary", "elizabeth",
                 "michael", "joseph", "thomas", "david", "richard", "daniel"):
        assert name not in NICKNAME_TO_CANONICAL, f"{name} should not be a nickname"


def test_prefixes_lowercase():
    for p in PREFIXES:
        assert p == p.lower(), f"Prefix not lowercase: {p}"


def test_suffixes_lowercase():
    for s in SUFFIXES:
        assert s == s.lower(), f"Suffix not lowercase: {s}"


def test_nicknames_lowercase():
    for nick, canonical in NICKNAME_TO_CANONICAL.items():
        assert nick == nick.lower(), f"Nickname key not lowercase: {nick}"
        assert canonical == canonical.lower(), f"Nickname value not lowercase: {canonical}"
