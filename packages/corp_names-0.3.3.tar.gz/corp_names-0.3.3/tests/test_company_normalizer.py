import pytest

from corp_names.company_normalizer import normalize_company


@pytest.mark.parametrize(
    "input_name, expected_normalized, expected_suffix, expected_type",
    [
        ("Apple Inc.", "apple", "inc", "Corporation"),
        ("Microsoft Corporation", "microsoft", "corporation", "Corporation"),
        ("Siemens AG", "siemens", "ag", "Corporation"),
        ("Toyota Motor Corp.", "toyota motor", "corp", "Corporation"),
        ("Tesco PLC", "tesco", "plc", "Limited Liability Company"),
        ("Bayerische Motoren Werke GmbH", "bayerische motoren werke", "gmbh", "Limited"),
        ("Unilever N.V.", "unilever", "nv", "Corporation"),
        ("Samsung Electronics Co., Ltd.", "samsung electronics", "co ltd", "Limited"),
        ("Amazon.com, Inc.", "amazoncom", "inc", "Corporation"),
    ],
)
def test_suffix_stripping(input_name, expected_normalized, expected_suffix, expected_type):
    result = normalize_company(input_name)
    assert result.normalized == expected_normalized
    assert result.suffix == expected_suffix
    assert result.entity_type == expected_type


def test_the_prefix():
    result = normalize_company("The Walt Disney Company")
    assert result.normalized == "walt disney"
    assert result.the_prefix_stripped is True
    assert result.suffix == "company"


def test_no_the_prefix():
    result = normalize_company("Apple Inc.")
    assert result.the_prefix_stripped is False


def test_ampersand():
    result = normalize_company("Johnson & Johnson")
    assert result.normalized == "johnson and johnson"
    assert result.suffix == ""


def test_unicode():
    result = normalize_company("Société Générale SA")
    assert result.normalized == "societe generale"
    assert result.suffix == "sa"
    assert result.entity_type == "Corporation"


def test_original_preserved():
    result = normalize_company("Apple Inc.")
    assert result.original == "Apple Inc."


def test_empty_string():
    result = normalize_company("")
    assert result.normalized == ""
    assert result.suffix == ""


def test_whitespace_only():
    result = normalize_company("   ")
    assert result.normalized == ""


def test_no_suffix():
    result = normalize_company("Walmart")
    assert result.normalized == "walmart"
    assert result.suffix == ""
    assert result.entity_type == ""


def test_llc():
    result = normalize_company("Acme Holdings LLC")
    assert result.normalized == "acme holdings"
    assert result.suffix == "llc"
    assert result.entity_type == "Limited Liability Company"


def test_pty_ltd():
    result = normalize_company("BHP Group Pty Ltd")
    assert result.normalized == "bhp group"
    assert result.suffix == "pty ltd"
    assert result.entity_type == "Limited"


def test_pvt_ltd():
    result = normalize_company("Tata Motors Pvt Ltd")
    assert result.normalized == "tata motors"
    assert result.suffix == "pvt ltd"
    assert result.entity_type == "Limited"


def test_multiple_spaces():
    result = normalize_company("  Apple   Inc.  ")
    assert result.normalized == "apple"
    assert result.suffix == "inc"


def test_trailing_comma_in_suffix():
    """e.g. 'Co., Ltd.' should match co ltd."""
    result = normalize_company("Mitsubishi Co., Ltd.")
    assert result.normalized == "mitsubishi"
    assert result.suffix == "co ltd"
