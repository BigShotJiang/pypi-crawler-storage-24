from corp_names import normalize_name


def test_basic_normalization():
    result = normalize_name("John Smith")
    assert result.normalized == "john smith"
    assert result.first == "john"
    assert result.last == "smith"
    assert result.prefix == ""
    assert result.suffix == ""
    assert result.nickname_resolved is False


def test_prefix_stripping():
    result = normalize_name("Dr. John Smith")
    assert result.normalized == "john smith"
    assert result.prefix == "dr"
    assert result.first == "john"
    assert result.last == "smith"


def test_suffix_stripping():
    result = normalize_name("John Smith Jr.")
    assert result.normalized == "john smith"
    assert result.suffix == "jr"


def test_prefix_and_suffix():
    result = normalize_name("Dr. Bob Smith Jr.")
    assert result.normalized == "robert smith"
    assert result.prefix == "dr"
    assert result.suffix == "jr"
    assert result.first == "robert"
    assert result.nickname_resolved is True


def test_middle_initial_removed():
    result = normalize_name("William H. Gates III")
    assert result.normalized == "william gates"
    assert result.suffix == "iii"
    assert result.first == "william"
    assert result.last == "gates"


def test_nickname_resolution():
    result = normalize_name("Bob Smith")
    assert result.first == "robert"
    assert result.normalized == "robert smith"
    assert result.nickname_resolved is True


def test_nickname_liz():
    result = normalize_name("Prof. Liz Warren")
    assert result.first == "elizabeth"
    assert result.normalized == "elizabeth warren"
    assert result.prefix == "prof"
    assert result.nickname_resolved is True


def test_sir_title():
    result = normalize_name("Sir William H. Gates III")
    assert result.normalized == "william gates"
    assert result.prefix == "sir"
    assert result.suffix == "iii"


def test_unicode_normalization():
    result = normalize_name("José García")
    assert result.normalized == "jose garcia"
    assert result.nickname_resolved is False

    result = normalize_name("José García", level="international")
    assert result.normalized == "joseph garcia"
    assert result.nickname_resolved is True


def test_multiple_suffixes():
    result = normalize_name("John Smith MD PhD")
    assert result.normalized == "john smith"
    assert "md" in result.suffix
    assert "phd" in result.suffix


def test_single_name():
    result = normalize_name("Madonna")
    assert result.normalized == "madonna"
    assert result.first == "madonna"
    assert result.last == ""


def test_hyphenated_name():
    result = normalize_name("Mary-Jane Watson")
    assert result.normalized == "mary-jane watson"
    assert result.last == "watson"


def test_preserves_original():
    result = normalize_name("Dr. Bob Smith Jr.")
    assert result.original == "Dr. Bob Smith Jr."


def test_multiple_middle_names_with_initials():
    result = normalize_name("John A B Smith")
    assert result.normalized == "john smith"


def test_empty_after_prefix_suffix_strip():
    """Edge case: all tokens are prefixes/suffixes."""
    result = normalize_name("Dr. Jr.")
    # Should handle gracefully
    assert result.original == "Dr. Jr."
