from corp_names.commands import main

if __name__ == "__main__":
    main()
