import json

import click

from corp_names.company_normalizer import normalize_company


@click.command("normalize-company")
@click.argument("name")
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def normalize_company_cmd(name: str, as_json: bool) -> None:
    """Normalize a company name."""
    result = normalize_company(name)

    if as_json:
        click.echo(result.model_dump_json(indent=2))
    else:
        click.echo(f"Original:   {result.original}")
        click.echo(f"Normalized: {result.normalized}")
        if result.suffix:
            click.echo(f"Suffix:     {result.suffix}")
        if result.entity_type:
            click.echo(f"Type:       {result.entity_type}")
        if result.the_prefix_stripped:
            click.echo("The:        stripped")
