"""Tests for HIITL SDK."""
