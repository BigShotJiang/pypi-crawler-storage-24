"""Core modules — temel bileşenler."""

from .registry import Registry, FunctionContract, DomainContract
from .decorators import ai_func, ai_module

__all__ = [
    "Registry",
    "FunctionContract",
    "DomainContract",
    "ai_func",
    "ai_module",
]

# Backward compatibility
__all__ += ["Registry", "FunctionContract", "DomainContract"]
