"""CLI — Komut satırı arayüzü."""

import sys
import os
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

try:
    from aicontract.core import Registry
    from aicontract.rules import Validator
    from aicontract.tools import ConsoleReporter, CallGraphScanner
except ImportError:
    from core.registry import Registry
    from rules.validator import Validator
    from tools.reporter import ConsoleReporter
    from tools.scanner import CallGraphScanner


def cmd_check(args):
    """Projeyi tara ve violation'ları raporla."""
    path = args[0] if args else "."
    registry = Registry(path)
    validator = Validator(registry)
    violations = validator.scan_project(path)
    reporter = ConsoleReporter()
    reporter.summary(violations, scanned_files=len(list(Path(path).rglob("*.py"))))


def cmd_status(args):
    """Registry durumunu göster."""
    path = args[0] if args else "."
    registry = Registry(path)
    print("\n[aicontract] Registry Durumu")
    print(f"  Fonksiyon: {len(registry.functions)}")
    print(f"  Domain: {len(registry.domains)}")
    print(f"  Dosya: {registry.registry_path}\n")


def cmd_scan(args):
    """Call graph taraması yap."""
    path = args[0] if args else "."
    registry = Registry(path)
    scanner = CallGraphScanner(registry)
    result = scanner.scan(path)
    print("\n[aicontract] Call Graph Taraması")
    print(f"  Güncellenen: {result['updated']}")
    print(f"  Bulunan çağrı: {result['calls_found']}\n")


def main():
    """CLI ana fonksiyonu."""
    args = sys.argv[1:]
    if not args or args[0] not in ["check", "status", "scan"]:
        print("Kullanım: aicontract <check|status|scan> [path]")
        sys.exit(1)

    cmd = args[0]
    if cmd == "check":
        cmd_check(args[1:])
    elif cmd == "status":
        cmd_status(args[1:])
    elif cmd == "scan":
        cmd_scan(args[1:])


if __name__ == "__main__":
    main()
