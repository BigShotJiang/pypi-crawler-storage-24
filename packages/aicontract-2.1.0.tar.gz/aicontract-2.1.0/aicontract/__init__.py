"""
aicontract — AI Kod Quality Gate

Yapay zeka koduna mimari kontrol sistemi.
"""

from .core import ai_func, ai_module, Registry, FunctionContract
from .rules import Validator, Violation, calculate_suspicion_score
from .tools import CallGraphScanner, scan_project, ConsoleReporter
from .utils import (
    check,
    check_file,
    ai_check,
    score,
    suggest,
    CheckResult,
    diff,
    learn,
    load_baseline,
    anomaly,
    extract_intent,
    contract,
    watch,
    check_side_effects,
    Intent,
    DiffResult,
    AnomalyResult,
    FunctionMetrics,
    ProjectBaseline,
    ContractError,
    Config,
    load_config,
    get_config,
    set_config,
    create_sample_config,
    DomainConfig,
    hotspot,
    HotspotReport,
    FileHotspot,
    FunctionHotspot,
    ContextGenerator,
    quick_context,
    SessionMemory,
    ArchDecision,
    ImpactAnalyzer,
    quick_impact,
)
from .adapters import (
    SQLAdapter,
    SQLViolation,
    SchemaInfo,
    MigrationGuard,
    MigrationCheckResult,
)
from .plugins import PluginRegistry, PluginRule, load_plugins, get_plugin_violations

__version__ = "2.1.0"

# Alias
intent = extract_intent

__all__ = [
    # Core
    "ai_func",
    "ai_module",
    "Registry",
    "FunctionContract",
    # Rules
    "Validator",
    "Violation",
    "calculate_suspicion_score",
    # Tools
    "CallGraphScanner",
    "scan_project",
    "ConsoleReporter",
    # Utils - Inline
    "check",
    "check_file",
    "ai_check",
    "score",
    "suggest",
    "CheckResult",
    # Utils - Smart
    "diff",
    "learn",
    "load_baseline",
    "anomaly",
    "extract_intent",
    "contract",
    "watch",
    "check_side_effects",
    "Intent",
    "DiffResult",
    "AnomalyResult",
    "FunctionMetrics",
    "ProjectBaseline",
    "ContractError",
    # Alias
    "intent",
    # Utils - Config
    "Config",
    "load_config",
    "get_config",
    "set_config",
    "create_sample_config",
    "DomainConfig",
    # Utils - Hotspot
    "hotspot",
    "HotspotReport",
    "FileHotspot",
    "FunctionHotspot",
    # Utils - Context
    "ContextGenerator",
    "quick_context",
    # Utils - Session
    "SessionMemory",
    "ArchDecision",
    # Utils - Impact
    "ImpactAnalyzer",
    "quick_impact",
    # Adapters
    "SQLAdapter",
    "SQLViolation",
    "SchemaInfo",
    "MigrationGuard",
    "MigrationCheckResult",
    # Plugins
    "PluginRegistry",
    "PluginRule",
    "load_plugins",
    "get_plugin_violations",
]
