"""Adapters — Harici sistemlerle entegrasyon."""

try:
    from .sql_adapter import SQLAdapter, SQLViolation, SchemaInfo
    from .migration_guard import MigrationGuard, MigrationCheckResult
except ImportError:
    pass

__all__ = [
    "SQLAdapter",
    "SQLViolation",
    "SchemaInfo",
    "MigrationGuard",
    "MigrationCheckResult",
]
