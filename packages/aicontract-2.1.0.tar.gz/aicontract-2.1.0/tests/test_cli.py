#!/usr/bin/env python
"""Test script for aicontract."""

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from aicontract.core import Registry
from aicontract.rules import Validator
from aicontract.tools import ConsoleReporter, CallGraphScanner


def main():
    root = "."

    print("[aicontract] Testing...\n")

    # Test 1: Registry + Validator
    registry = Registry(root)
    validator = Validator(registry)
    reporter = ConsoleReporter()

    violations = validator.scan_project(root)
    print(f"Total violations: {len(violations)}")

    # Show some violations
    for v in violations[:5]:
        print(f"  - {v.rule_id}: {v.message}")

    if len(violations) > 5:
        print(f"  ... and {len(violations) - 5} more")

    reporter.summary(violations, scanned_files=1)

    print("\n" + "=" * 50)

    # Test 2: Scanner
    scanner = CallGraphScanner(registry)
    result = scanner.scan(root)
    print(f"\nCall graph scan: {result}")

    indirect = scanner.find_indirect_calls(root)
    print(f"Indirect calls: {indirect}")

    print("\nRegistry functions:")
    for name, fc in registry.functions.items():
        print(f"  - {name}: {len(fc.called_by)} callers")

    print("\nAll tests passed!")


if __name__ == "__main__":
    main()
