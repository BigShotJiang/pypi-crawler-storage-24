"""
Karmaşık test senaryoları - AI kod üretirken karşılaşabileceği durumlar.
Bu dosya rule'ları test etmek için yazıldı.
"""

import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

os.environ["AICONTRACT_ROOT"] = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

try:
    from aicontract import ai_func, ai_module
except ImportError:
    from aicontract.core import ai_func, ai_module


# ── TEST 1: Domain tanımsız ────────────────────────────────
@ai_func(domain="", touches=["users"])
def test_no_domain():
    """Domain boş - DOM002 tetiklemeli"""
    pass


# ── TEST 2: Yanlış domain ─────────────────────────────────
@ai_func(domain="auth", touches=["db"])
def test_wrong_domain():
    """Yanlış domain - DOM001 tetiklemeli"""
    pass


# ── TEST 3: Yabancı domain dokunma ────────────────────────
@ai_func(domain="email", touches=["postgres"])
def test_foreign_domain():
    """Yabancı domain kaynağına dokunuyor - DOM003"""
    pass


# ── TEST 4: Loop içinde DB çağrısı ─────────────────────────
@ai_func(domain="data", touches=["db"])
def test_db_in_loop(items):
    """Loop içinde DB çağrısı - PERF001"""
    results = []
    for item in items:
        results.append(f"INSERT INTO items VALUES ({item})")
    return results


# ── TEST 5: Loop içinde HTTP çağrısı ────────────────────────
@ai_func(domain="data", touches=["http"])
def test_http_in_loop(urls):
    """Loop içinde HTTP çağrısı - PERF002"""
    results = []
    for url in urls:
        results.append(f"fetch({url})")
    return results


# ── TEST 6: Hardcoded secret ───────────────────────────────
@ai_func(domain="auth", touches=["config"])
def test_hardcoded_secret():
    """Hardcoded password - SEC001"""
    password = "test123456"
    return password


# ── TEST 7: Hardcoded secret ( whitelist'den) ──────────────
@ai_func(domain="auth", touches=["config"])
def test_whitelisted_secret():
    """Whitelist'teki değer - SEC001 tetiklememeli"""
    password = "test"
    return password


# ── TEST 8: SQL injection ───────────────────────────────────
@ai_func(domain="data", touches=["db"])
def test_sql_injection(user_id):
    """f-string SQL injection - SEC002"""
    query = f"SELECT * FROM users WHERE id = {user_id}"
    return query


# ── TEST 9: God function (çok büyük) ────────────────────────
@ai_func(domain="data", touches=["db"])
def test_god_function():
    """Çok satırlı fonksiyon - ARCH001"""
    x = 1
    x = 2
    x = 3
    x = 4
    x = 5
    x = 6
    x = 7
    x = 8
    x = 9
    x = 10
    x = 11
    x = 12
    x = 13
    x = 14
    x = 15
    x = 16
    x = 17
    x = 18
    x = 19
    x = 20
    x = 21
    x = 22
    x = 23
    x = 24
    x = 25
    x = 26
    x = 27
    x = 28
    x = 29
    x = 30
    x = 31
    x = 32
    x = 33
    x = 34
    x = 35
    x = 36
    x = 37
    x = 38
    x = 39
    x = 40
    x = 41
    return x


# ── TEST 10: Çok fazla branch ───────────────────────────────
@ai_func(domain="data", touches=[])
def test_many_branches(x):
    """Çok fazla if/elif - ARCH002"""
    if x == 1:
        return "a"
    elif x == 2:
        return "b"
    elif x == 3:
        return "c"
    elif x == 4:
        return "d"
    elif x == 5:
        return "e"
    elif x == 6:
        return "f"
    elif x == 7:
        return "g"
    elif x == 8:
        return "h"
    return "z"


# ── TEST 11: Çok fazla argüman ───────────────────────────────
@ai_func(domain="data", touches=[])
def test_many_args(a, b, c, d, e, f, g):
    """7 parametre - ARCH003"""
    return a + b + c + d + e + f + g


# ── TEST 12: Return type yok ─────────────────────────────────
@ai_func(domain="data", touches=[])
def test_no_return_type(x):
    """Return type annotation yok - ARCH004"""
    return x * 2


# ── TEST 13: Return type var ─────────────────────────────────
@ai_func(domain="data", touches=[])
def test_with_return_type(x) -> int:
    """Return type annotation var - ARCH004 tetiklememeli"""
    return x * 2


# ── TEST 14: Bare exception ─────────────────────────────────
@ai_func(domain="data", touches=[])
def test_bare_exception():
    """Bare except - PERF003"""
    try:
        x = 1 / 0
    except:
        return None


# ── TEST 15: Docstring yok ──────────────────────────────────
@ai_func(domain="data", touches=[])
def test_no_docstring(x):
    return x + 1


# ── TEST 16: Print in production ─────────────────────────────
@ai_func(domain="data", touches=[])
def test_print_in_production():
    """Production'da print - STYLE002"""
    print("debug info")
    return True


# ── TEST 17: Template değişken (secret değil) ─────────────
@ai_func(domain="auth", touches=[])
def test_template_secret():
    """Template variable - SEC001 tetiklememeli"""
    password = "${DB_PASSWORD}"
    return password


# ── TEST 18: Çok kısa secret ( whitelist'ten) ──────────────
@ai_func(domain="auth", touches=[])
def test_short_secret():
    """Çok kısa - SEC001 tetiklememeli"""
    secret = "abc"
    return secret


# ── TEST 19: Enum benzeri fonksiyonlar (DUP002) ───────────
@ai_func(domain="data", touches=[])
def getUserProfile(user_id):
    """Alt tire+ camelCase - DUP002"""
    return {"id": user_id}


@ai_func(domain="data", touches=[])
def get_user_profile(user_id):
    """Alt tire - DUP002"""
    return {"id": user_id}


# ── TEST 20: Async chain'de sync fonksiyon ─────────────────
@ai_func(domain="auth", touches=[])
async def test_async_caller():
    """Async fonksiyon - sync_auth çağırırsa ASY001"""
    return True


@ai_func(domain="auth", touches=[])
def sync_auth():
    """Sync fonksiyon"""
    return True


# ── TEST 21: Değişken isimlendirme ─────────────────────────
@ai_func(domain="data", touches=[])
def testDynamicDispatch():
    """Dynamic dispatch test - string olarak geçiyor"""
    func_name = "sync_auth"
    return func_name


# ── TEST 22: Test fonksiyonu (dead code değil) ────────────
@ai_func(domain="data", touches=[])
def test_something():
    """Test fonksiyonu - DEAD001 tetiklememeli"""
    assert True


# ── TEST 23: Private fonksiyon (dead code değil) ────────────
@ai_func(domain="data", touches=[])
def _internal_helper():
    """Private fonksiyon - DEAD001 tetiklememeli"""
    return True


# ── TEST 24: Main fonksiyonu (dead code değil) ─────────────
@ai_func(domain="data", touches=[])
def main():
    """Main fonksiyon - DEAD001 tetiklememeli"""
    return True


# ── TEST 25: İlk kaydedilen fonksiyon (DEAD001 grace period) ─
@ai_func(domain="data", touches=[])
def fresh_function():
    """Yeni fonksiyon - 48 saat içinde DEAD001 yok"""
    return True


# ── TEST 26: Ortak helper (benzer logic) ───────────────────
@ai_func(domain="data", touches=[])
def helper_a():
    x = 1
    if x > 0:
        return True
    return False


@ai_func(domain="data", touches=[])
def helper_b():
    y = 1
    if y > 0:
        return True
    return False


if __name__ == "__main__":
    print("\n" + "=" * 60)
    print("Tüm test fonksiyonları kaydedildi!")
    print("Şimdi aicontract check ile kontrol et")
    print("=" * 60 + "\n")
