from setuptools import setup, find_packages
import os

# Read README
long_description = ""
if os.path.exists("README.md"):
    with open("README.md", encoding="utf-8") as f:
        long_description = f.read()


# Get all Python modules (excluding test files and private)
def get_modules():
    modules = []
    for f in os.listdir("."):
        if f.endswith(".py") and not f.startswith("_"):
            # Exclude test files
            if not f.startswith("test_"):
                modules.append(os.path.splitext(f)[0])
    return modules


setup(
    name="aicontract",
    version="2.1.0",
    author="aicontract",
    author_email="hello@aicontract.dev",
    description="AI kod quality gate - yapay zeka koduna mimari kontrol",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/aicontract/aicontract",
    project_urls={
        "Bug Tracker": "https://github.com/aicontract/aicontract/issues",
    },
    classifiers=[
        "Development Status :: 3 - Alpha",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Quality Assurance",
    ],
    packages=find_packages(),
    entry_points={
        "console_scripts": [
            "aicontract=aicontract.cli:main",
        ],
    },
    python_requires=">=3.10",
    install_requires=[
        "pyyaml>=6.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0",
            "ruff>=0.1.0",
        ],
    },
    keywords="ai code-quality architecture-contract linting security",
)
