"""
aicontract — Tek import, her şey dahil.

    import aicontract

    aicontract.check(code)          # analiz et
    aicontract.diff(eski, yeni)     # ne kırıldı?
    aicontract.learn(".")           # projeyi öğren
    aicontract.anomaly(fn)          # bu projede normal mi?
    aicontract.intent(fn)           # ne yapmak istiyor?
    aicontract.score(code)          # 0-100 şüphe skoru

    @aicontract.ai_check            # decorator
    @aicontract.contract(pure=True) # composable kurallar

    with aicontract.watch():        # blok izleyici
        def login(): ...
"""

from .inline import (
    check,
    check_file,
    ai_check,
    score,
    Violation,
    ContractViolationError,
)

from .smart import (
    diff,
    learn,
    load_baseline,
    anomaly,
    contract,
    watch,
    extract_intent,
    check_pure_violations,
    Intent,
    DiffResult,
    AnomalyResult,
    FunctionMetrics,
    ProjectBaseline,
    ContractError,
)

# Eski adaptörler
from .sql_adapter import SQLAdapter
from .migration_guard import MigrationGuard
from .session_memory import SessionMemory

from .hotspot import hotspot, HotspotReport, FileHotspot, FunctionHotspot

intent = extract_intent  # alias: aicontract.intent(fn)

__version__ = "2.1.0"

__all__ = [
    # Inline API
    "check", "check_file", "ai_check", "score",
    # Smart API
    "diff", "learn", "load_baseline", "anomaly", "intent", "contract", "watch",
    # Types
    "Violation", "Intent", "DiffResult", "AnomalyResult",
    "FunctionMetrics", "ProjectBaseline",
    "ContractViolationError", "ContractError",
    # Sprint 2
    "hotspot", "HotspotReport", "FileHotspot", "FunctionHotspot",
    "check_pure_violations",
    "SQLAdapter", "MigrationGuard", "SessionMemory",
]

# Sprint 3 — config katmanı
from .config import (
    load_config,
    get_config,
    AicontractConfig,
    check_diff,
    get_changed_files,
    get_exit_code,
    to_json,
    to_sarif,
    check_baseline_age,
    parse_ignore_comments,
    filter_violations,
    safe_read_file,
    load_ignore_patterns,
)

# Sprint 4 — MCP + Init + Incremental + Only-New
from .mcp_server import run as run_mcp_server

from .init_cmd import (
    init,
    learn_incremental,
    ViolationBaseline,
    get_violation_baseline,
)
