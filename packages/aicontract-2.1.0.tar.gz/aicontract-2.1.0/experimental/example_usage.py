"""
aicontract v2 — Tam kullanım örneği

Bu dosya her yeni özelliğin nasıl kullanılacağını gösterir.
Gerçek bir proje senaryosu: e-ticaret backend'i.
"""

# ════════════════════════════════════════════════════════════════
# 1. SESSION MEMORY — Mimari kararları kaydet
# ════════════════════════════════════════════════════════════════

from aicontract.session_memory import SessionMemory

mem = SessionMemory(".aicontract_memory.yaml")

# Projedeki kararları ekle (bir kez yapılır, YAML'a yazılır)
mem.add_decision(
    category="error_handling",
    rule="Tüm servis katmanı hataları CustomException alt sınıfından türemeli",
    reason="Stack trace ve hata kodu standartlaşıyor",
    enforced=True,
)
mem.add_decision(
    category="db",
    rule="Direkt SQL yazma — SQLAlchemy ORM veya Repository pattern kullan",
    reason="SQL injection koruması + test edilebilirlik",
    enforced=True,
)
mem.add_decision(
    category="api",
    rule="Tüm endpoint girdileri Pydantic model ile doğrulanmalı",
    reason="Runtime tip güvenliği",
    enforced=True,
)
mem.add_decision(
    category="testing",
    rule="Her public fonksiyon için en az 1 happy + 1 edge case test",
    reason="Coverage kalitesi > sayısı",
    enforced=False,  # tavsiye
)

# Koddan otomatik karar çıkar
inferred = mem.infer_from_source(open("auth.py").read() if __import__("os").path.exists("auth.py") else "")
print(f"Koddan {len(inferred)} karar çıkarıldı")
print(mem.summary())


# ════════════════════════════════════════════════════════════════
# 2. SQL ADAPTER — Şema-farkında analiz
# ════════════════════════════════════════════════════════════════

from aicontract.sql_adapter import SQLAdapter

# Gerçek DB'den şema çek:
# sql = SQLAdapter(connection_string="postgresql://localhost/shop")

# Veya şema dosyasından:
sql = SQLAdapter(schema_file=".aicontract_schema.json") if __import__("os").path.exists(".aicontract_schema.json") else SQLAdapter()

# Elle şema tanımla (geliştirme ortamı için):
sql.schema.tables = {
    "users": {
        "columns": ["id", "email", "password_hash", "created_at", "is_active"],
        "indexes": ["email_idx", "created_at_idx"]
    },
    "orders": {
        "columns": ["id", "user_id", "total", "status", "created_at"],
        "indexes": ["user_id_idx", "status_idx"]
    },
    "order_items": {
        "columns": ["id", "order_id", "product_id", "quantity", "price"],
        "indexes": ["order_id_idx"]
    }
}

# YZ'nin yazdığı problemli kodu kontrol et:
bad_code = """
def get_user_orders(user_id):
    # YZ bunu yazdı — 3 sorun var
    query = f"SELECT id, email, username FROM users WHERE id = {user_id}"
    
    orders = []
    for user in users:
        order = db.execute("SELECT * FROM user_orders WHERE user_id = ?", user.id)
        orders.append(order)
    
    db.execute("DELETE FROM orders")
    return orders
"""

violations = sql.check(bad_code)
print(f"\n[SQL] {len(violations)} ihlal:")
for v in violations:
    print(f"  [{v.severity.upper()}] satır {v.line}: {v.message}")
    print(f"    → {v.suggestion}")

# Çıktı:
# [SQL] 4 ihlal:
#   [ERROR] satır 3: f-string ile SQL — injection riski
#     → Parametre bağlama kullan: cursor.execute(sql, (value,))
#   [ERROR] satır 3: Kolon bulunamadı: 'username' in 'users'
#     → 'users' kolonları: id, email, password_hash, created_at, is_active
#   [WARNING] satır 5: Loop içinde DB sorgusu — muhtemel N+1 problemi
#     → JOIN veya batch SELECT kullan.
#   [ERROR] satır 9: WHERE'siz DELETE — tüm satırlar silinir
#     → WHERE koşulu ekle veya LIMIT 0 ile test et.


# ════════════════════════════════════════════════════════════════
# 3. MIGRATION GUARD — Geri dönüşsüz işlemleri yakala
# ════════════════════════════════════════════════════════════════

from aicontract.migration_guard import MigrationGuard

guard = MigrationGuard()  # connection_string ile satır sayısı da alabilir

# YZ'nin yazdığı tehlikeli migration:
dangerous_migration = """
from alembic import op
import sqlalchemy as sa

def upgrade():
    # YZ "artık kullanılmıyor" diye direkt sildi
    op.drop_column('users', 'legacy_phone')
    op.drop_column('users', 'old_address')
    
    # "test verilerini temizle" dedi, production'da 2M satır var
    op.execute('TRUNCATE order_logs')
    
    # "daha hızlı olur" dedi
    op.alter_column('orders', 'notes', nullable=False)

def downgrade():
    pass  # YZ bunu boş bıraktı
"""

result = guard.check_source(dangerous_migration, "0024_cleanup.py")
print(result.report())
print("\nRollback şablonu:")
print(guard.generate_rollback(result))

# Çıktı:
# ============================================================
# [aicontract/migration] 0024_cleanup.py
# Tehlike skoru: 92/100
# ============================================================
# [KRİTİK] DROP_COLUMN — users.legacy_phone (satır 6)
#   Kolon kalıcı olarak siliniyor
#   Öneri: Önce kolonu NULL yapıp deprecated işaretle...
# ...


# ════════════════════════════════════════════════════════════════
# 4. CONTEXT GENERATOR — Hepsini birleştir
# ════════════════════════════════════════════════════════════════

from aicontract.context_gen import ContextGenerator

gen = ContextGenerator(
    project_dir=".",
    memory=mem,
    sql_adapter=sql,
    migration_guard=guard,
)

# YZ'ye görev ver — bağlam otomatik eklenir:
enriched_prompt = gen.wrap(
    user_prompt="login fonksiyonunu JWT tabanlı kimlik doğrulamaya geçir",
    target_fn="login",
    target_file="auth.py",
)

print("\n" + "="*60)
print("YZ'YE GÖNDERİLECEK ZENGİNLEŞTİRİLMİŞ PROMPT:")
print("="*60)
print(enriched_prompt)

# Çıktı (örnek):
# ═══════════════════════════════════════════════════════════════
# aicontract — Otomatik bağlam enjeksiyonu
# Aşağıdaki tüm kurallara UYMAK ZORUNDASIN.
# ═══════════════════════════════════════════════════════════════
#
# # aicontract/memory — Mimari kararlar
# Hata yönetimi:
#   ZORUNLU: Tüm servis katmanı hataları CustomException'dan türemeli
# Veritabanı:
#   ZORUNLU: Direkt SQL yazma — SQLAlchemy ORM veya Repository kullan
# API tasarımı:
#   ZORUNLU: Tüm endpoint girdileri Pydantic model ile doğrulanmalı
#
# # Impact analizi — 'login' değişirse:
# dogrudan_etkilenen: ['auth_handler', 'middleware.session']
# risk_skoru: 48/100
# # Bu fonksiyonların imzasını ve dönüş tipini KIRMAMA:
#   - auth_handler
#   - middleware.session
#
# # aicontract/sql — DB şeması
# schema:
#   users:
#     columns: ['id', 'email', 'password_hash', 'created_at', 'is_active']
# ...
#
# # ─── Görev ───
# hedef_fonksiyon: login
# görev: login fonksiyonunu JWT tabanlı kimlik doğrulamaya geçir


# ════════════════════════════════════════════════════════════════
# 5. CLI — Komut satırından kullanım
# ════════════════════════════════════════════════════════════════

# Karar ekle:
# $ aicontract memory add -c error_handling -r "Custom exception kullan" --reason "Stack trace"

# Kararları listele:
# $ aicontract memory list

# Koddan karar çıkar:
# $ aicontract memory scan .

# SQL kontrol:
# $ aicontract sql check views.py --schema .aicontract_schema.json

# Migration kontrol (CI'da):
# $ aicontract migration check migrations/ --fail-on-danger

# YZ görevi wrap et:
# $ aicontract wrap "login'i JWT'ye geçir" --target login --file auth.py
# $ aicontract wrap "login'i JWT'ye geçir" --target login --copy  # panoya kopyala
