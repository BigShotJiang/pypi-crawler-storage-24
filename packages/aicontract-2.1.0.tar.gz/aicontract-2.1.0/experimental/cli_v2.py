"""
aicontract — Yeni CLI komutları (mevcut cli.py'a eklenecek)

Yeni komutlar:
    aicontract wrap "<görev>" [--target fn] [--file path]
    aicontract memory add --category X --rule "Y" --reason "Z"
    aicontract memory list [--category X]
    aicontract memory scan .
    aicontract sql check <file.py>
    aicontract sql schema --export schema.json
    aicontract migration check <migrations/>
    aicontract migration rollback <migration_file.py>

Mevcut cli.py'daki main() fonksiyonuna bu subcommand'ları ekle.
"""

import sys
import argparse
import json
import os


def add_new_commands(subparsers):
    """
    Mevcut cli.py içindeki argparse subparsers'a yeni komutları ekle.
    Çağrı: cli.py'da setup_args() veya main() içinde bu fonksiyonu çağır.
    """

    # ── wrap ────────────────────────────────────────────────────────
    wrap_p = subparsers.add_parser(
        "wrap",
        help="YZ görevini bağlamla zenginleştir"
    )
    wrap_p.add_argument("prompt", help="YZ'ye verilecek görev")
    wrap_p.add_argument("--target", "-t", help="Hedef fonksiyon adı")
    wrap_p.add_argument("--file", "-f", help="Hedef dosya yolu")
    wrap_p.add_argument("--config", default="aicontract.yaml", help="Config dosyası")
    wrap_p.add_argument("--copy", action="store_true", help="Sonucu panoya kopyala")
    wrap_p.add_argument("--out", help="Sonucu dosyaya yaz")

    # ── memory ──────────────────────────────────────────────────────
    mem_p = subparsers.add_parser("memory", help="Mimari karar yönetimi")
    mem_sub = mem_p.add_subparsers(dest="memory_cmd")

    mem_add = mem_sub.add_parser("add", help="Karar ekle")
    mem_add.add_argument("--category", "-c", required=True,
                         choices=["error_handling","naming","db","api","testing","security","architecture","performance"])
    mem_add.add_argument("--rule", "-r", required=True, help="Kural metni")
    mem_add.add_argument("--reason", help="Neden bu kural var?")
    mem_add.add_argument("--advisory", action="store_true", help="Tavsiye (zorunlu değil)")

    mem_sub.add_parser("list", help="Kararları listele").add_argument(
        "--category", "-c", help="Kategoriye göre filtrele"
    )

    mem_scan = mem_sub.add_parser("scan", help="Koddan kararları çıkar")
    mem_scan.add_argument("dir", nargs="?", default=".", help="Proje dizini")

    # ── sql ─────────────────────────────────────────────────────────
    sql_p = subparsers.add_parser("sql", help="SQL analizi")
    sql_sub = sql_p.add_subparsers(dest="sql_cmd")

    sql_check = sql_sub.add_parser("check", help="Python dosyasındaki SQL'leri kontrol et")
    sql_check.add_argument("file", help="Python dosyası")
    sql_check.add_argument("--schema", help="Schema JSON dosyası")
    sql_check.add_argument("--db", help="DB connection string")

    sql_schema = sql_sub.add_parser("schema", help="DB şemasını işle")
    sql_schema.add_argument("--export", help="Şemayı JSON'a kaydet")
    sql_schema.add_argument("--db", required=True, help="DB connection string")

    # ── migration ───────────────────────────────────────────────────
    mig_p = subparsers.add_parser("migration", help="Migration güvenliği")
    mig_sub = mig_p.add_subparsers(dest="migration_cmd")

    mig_check = mig_sub.add_parser("check", help="Migration dosyalarını kontrol et")
    mig_check.add_argument("path", help="Dosya veya dizin")
    mig_check.add_argument("--db", help="DB connection string (satır sayısı için)")
    mig_check.add_argument("--fail-on-danger", action="store_true",
                           help="Tehlikeli migration bulunursa exit(1)")

    mig_rollback = mig_sub.add_parser("rollback", help="Rollback şablonu üret")
    mig_rollback.add_argument("file", help="Migration dosyası")


def handle_wrap(args):
    from .context_gen import ContextGenerator
    gen = ContextGenerator.from_config(args.config)
    result = gen.wrap(
        user_prompt=args.prompt,
        target_fn=getattr(args, "target", None),
        target_file=getattr(args, "file", None),
    )
    if getattr(args, "out", None):
        with open(args.out, "w") as f:
            f.write(result)
        print(f"[aicontract] Bağlam yazıldı: {args.out}")
    elif getattr(args, "copy", False):
        try:
            import subprocess
            subprocess.run(["pbcopy"], input=result.encode(), check=True)
            print("[aicontract] Panoya kopyalandı.")
        except Exception:
            print("[aicontract] Pano erişimi yok, çıktı aşağıda:\n")
            print(result)
    else:
        print(result)


def handle_memory(args):
    from .session_memory import SessionMemory
    mem = SessionMemory()

    if args.memory_cmd == "add":
        mem.add_decision(
            category=args.category,
            rule=args.rule,
            reason=getattr(args, "reason", "") or "",
            enforced=not getattr(args, "advisory", False),
        )
    elif args.memory_cmd == "list":
        decisions = mem.list_decisions(getattr(args, "category", None))
        if not decisions:
            print("[aicontract/memory] Kayıtlı karar yok.")
            return
        print(f"\n{mem.summary()}\n")
        for d in decisions:
            flag = "ZORUNLU" if d.enforced else "tavsiye"
            print(f"  [{d.uid}] [{d.category}] {d.rule}")
            print(f"         {flag}{' — ' + d.reason if d.reason else ''}")
    elif args.memory_cmd == "scan":
        found = mem.scan_project(args.dir)
        print(f"[aicontract/memory] {len(found)} karar çıkarıldı.")
        print(mem.summary())


def handle_sql(args):
    from .sql_adapter import SQLAdapter

    if args.sql_cmd == "check":
        with open(args.file) as f:
            source = f.read()
        adapter = SQLAdapter(
            connection_string=getattr(args, "db", None),
            schema_file=getattr(args, "schema", None),
        )
        violations = adapter.check(source)
        if not violations:
            print(f"[aicontract/sql] Temiz: {args.file}")
            return
        print(f"\n[aicontract/sql] {len(violations)} ihlal bulundu:\n")
        for v in violations:
            icon = "HATA" if v.severity == "error" else "UYARI"
            print(f"  [{icon}] {v.rule_id} satır {v.line}: {v.message}")
            print(f"         Öneri: {v.suggestion}")

    elif args.sql_cmd == "schema":
        adapter = SQLAdapter(connection_string=args.db)
        if args.export:
            adapter.export_schema(args.export)
            print(f"[aicontract/sql] Şema kaydedildi: {args.export}")
        else:
            print(adapter.build_context())


def handle_migration(args):
    from .migration_guard import MigrationGuard

    guard = MigrationGuard(connection_string=getattr(args, "db", None))

    if args.migration_cmd == "check":
        path = args.path
        if os.path.isfile(path):
            results = [guard.check_file(path)]
        else:
            results = guard.check_directory(path)

        if not results:
            print("[aicontract/migration] Tehlikeli migration bulunamadı.")
            return

        for r in results:
            print(r.report())

        if getattr(args, "fail_on_danger", False) and results:
            sys.exit(1)

    elif args.migration_cmd == "rollback":
        result = guard.check_file(args.file)
        if result.is_dangerous:
            print(guard.generate_rollback(result))
        else:
            print("[aicontract/migration] Bu dosyada tehlikeli işlem bulunamadı.")


# ── Mevcut cli.py'a entegrasyon noktası ─────────────────────────────
#
# cli.py içindeki main() fonksiyonuna şunu ekle:
#
#   from aicontract.cli_v2 import add_new_commands, handle_wrap, handle_memory, handle_sql, handle_migration
#
#   # argparse setup'ından sonra:
#   add_new_commands(subparsers)
#
#   # dispatch switch'ine:
#   elif args.command == "wrap":       handle_wrap(args)
#   elif args.command == "memory":     handle_memory(args)
#   elif args.command == "sql":        handle_sql(args)
#   elif args.command == "migration":  handle_migration(args)
