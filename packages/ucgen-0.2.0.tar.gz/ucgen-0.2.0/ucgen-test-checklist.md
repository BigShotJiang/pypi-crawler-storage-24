# ucgen Test Checklist
> Provider: **Ollama (local)** — run `ollama serve` before starting

---

## How to use this file

Work through each section top to bottom.
Mark each item by changing `[ ]` to `[x]` when it passes.
Note failures inline with what went wrong.

---

## 0 — Prerequisites

```bash
ollama serve
ollama pull mistral
ollama pull qwen3:8b    # recommended — better JSON reliability
```

Run tests with qwen3:8b first:
python -m ucgen generate "patient books appointment" 
(uses whatever is set in .ucgenrc.toml)

To switch models mid-test:
Edit .ucgenrc.toml model = "qwen3:8b"

- [ ] `ollama serve` is running in a separate terminal
- [ ] `mistral` model is pulled and available
- [ ] You are in the repository root (directory containing `pyproject.toml` and `ucgen/`)

---

## 1 — Environment

```bash
python -m ucgen --help
python -m ucgen version
```

- [ ] `--help` shows at least these commands: `generate`, `run`, `status`, `batch`, `validate`, `init`, `init-project`, `log`, `version` (plus `gc` if present)
- [ ] `version` prints `ucgen v0.2.0`
- [ ] `version` shows provider status table
- [ ] Ollama shows `✓` in the status table
- [ ] Anthropic / OpenAI / Groq show `✗` (no keys set — expected)

---

## 2 — Config init

```bash
python -m ucgen init
```

- [ ] Creates `.ucgenrc.toml` in current directory
- [ ] File contains `[defaults]`, `[providers]`, `[hooks]` sections
- [ ] Open the file — all options are commented with explanations

Now set Ollama as default so you don't need `--provider` flags for the rest of this checklist.
Edit `.ucgenrc.toml`:

```toml
[defaults]
provider = "ollama"
model = "mistral"
output_dir = "./use-cases"
template = "default"
```

- [ ] `.ucgenrc.toml` saved with above settings

---

## 3 — Single use case generation (core)

```bash
python -m ucgen generate "patient books appointment at dental clinic"
```

- [ ] No errors during generation
- [ ] Progress spinner appears while generating
- [ ] Success panel printed: shows file path, UC ID, title, actor, provider, duration
- [ ] File created in `./use-cases/` with `UC-YYYY-NNNN-` prefix

Open the generated file and check each section:

**Frontmatter**
- [ ] File starts with `---`
- [ ] `uc_id` present — format `UC-YYYY-NNNN`
- [ ] `title` present and descriptive
- [ ] `actor` present — should be a role (e.g. `Patient`), not a person name
- [ ] `domain` present (e.g. `healthcare`)
- [ ] `status: draft`
- [ ] `generator: ucgen/0.2.0`
- [ ] Closes with `---` before document body

**Preconditions**
- [ ] Section present
- [ ] 3–6 bullet points
- [ ] Each is a verifiable state (noun phrase), not an action
- [ ] None say "User clicks..." or mention UI elements

**Normal Course of Events**
- [ ] Table with Step / Actor / Action / System Response columns
- [ ] 5–9 rows
- [ ] No step says "clicks", "presses", "selects from dropdown" — intent only
- [ ] Every actor action has a corresponding system response

**Minimal Guarantee**
- [ ] Present as a single sentence
- [ ] Describes what is preserved even if the use case fails
- [ ] Example of a good one: _"Booking attempt logged with timestamp and patient ID even if slot was taken"_

**Success Guarantee**
- [ ] Present
- [ ] Addresses what is true for all stakeholders after success

**Alternative Courses**
- [ ] At least 2 alternatives present
- [ ] Format: `**2a** condition → response`
- [ ] At least one covers a failure path (no availability, system down, etc.)

**Implied Entities**
- [ ] At least 1 entity with a table of fields
- [ ] Every entity has `id` field with type `UUID`
- [ ] Every entity has `created_at` and `updated_at` fields
- [ ] Entity names are PascalCase

---

## 4 — Second generation (ID increment)

```bash
python -m ucgen generate "receptionist checks in patient at front desk"
```

- [ ] Second file created with `UC-YYYY-0002` (counter incremented)
- [ ] Different actor from first use case
- [ ] `system_boundary` field populated if detectable

---

## 5 — Templates

```bash
python -m ucgen generate "admin resets user password" --template minimal
python -m ucgen generate "system processes payment" --template cockburn-full
python -m ucgen generate "driver updates live location" --template enterprise
python -m ucgen generate "user searches product catalogue" --template api
```

**minimal**
- [ ] File is shorter than default output
- [ ] Contains frontmatter, trigger, normal course, implied entities
- [ ] Missing sections are intentionally absent (not errors)

**cockburn-full**
- [ ] `Stakeholders and Interests` section present
- [ ] `Minimal Guarantee` section present
- [ ] `Success Guarantee` section present
- [ ] `Open Issues` section present

**enterprise**
- [ ] NFRs table present (latency, availability, consistency, etc.)
- [ ] Scale hints populated if detectable
- [ ] State machine section present if entity has lifecycle states
- [ ] Footer line: _Generated by ucgen..._

**api**
- [ ] API Specification section present with endpoint tables
- [ ] Methods: GET, POST, PATCH, DELETE shown per entity

---

## 6 — Domain quality checks

These test whether the knowledge dictionaries in `knowledge/all-knowledge.json` are influencing output correctly.

**Payment use case**
```bash
python -m ucgen generate "customer pays for order at checkout" --template cockburn-full
```
- [ ] NFR section includes a `consistency` entry
- [ ] No mention of storing raw card data
- [ ] Entities do NOT include a `CardNumber` or `CVV` field
- [ ] Notes or open issues mention third-party payment processor

**Real-time location use case**
```bash
python -m ucgen generate "driver updates live location every 4 seconds" --template enterprise
```
- [ ] Scale hints populated with high frequency estimate
- [ ] NFR includes `throughput` or `latency` entry
- [ ] Entities or notes mention a fast-write store (Redis, Cassandra) or flag PostgreSQL as insufficient alone

**Agriculture use case**
```bash
python -m ucgen generate "farmer submits EU subsidy claim for crop rotation" --template default
```
- [ ] Entities are simple — no over-engineered microservice patterns
- [ ] Use case is self-contained — no external API dependencies assumed
- [ ] Open issues section raises compliance or regulatory questions

**No UI language check**
Open any generated file and search for these strings — none should appear:
- [ ] "clicks" not found in Normal Course
- [ ] "button" not found in Normal Course
- [ ] "dropdown" not found in Normal Course
- [ ] "navigates to" not found in Normal Course

---

## 7 — Batch generation

Create a test file:

```bash
echo "user registers new account" > test-ideas.txt
echo "admin deactivates user account" >> test-ideas.txt
echo "# this line should be skipped" >> test-ideas.txt
echo "" >> test-ideas.txt
echo "system sends password reset email" >> test-ideas.txt
```

```bash
python -m ucgen batch test-ideas.txt
```

- [ ] Progress bar shown during generation
- [ ] 3 files created (comment line and blank line skipped)
- [ ] Summary printed: `3 succeeded`
- [ ] UC IDs continue incrementing from previous runs

---

## 8 — Project workflow (ucgen.yaml)

```bash
python -m ucgen init-project TestClinic --domain healthcare
```

- [ ] `ucgen.yaml` created in current directory
- [ ] `use-cases/` directory created
- [ ] File contains `project`, `defaults`, `actors`, `use_cases` sections
- [ ] One example use case with `status: pending`

Edit `ucgen.yaml` to add two use cases:

```yaml
use_cases:
  - id: UC-001
    title: Patient Books Appointment
    actor: Patient
    goal: Reserve an available slot with preferred dentist
    priority: high
    status: pending

  - id: UC-002
    title: Receptionist Confirms Arrival
    actor: Receptionist
    goal: Record patient arrival and notify dentist
    priority: medium
    status: pending
```

```bash
python -m ucgen status
```

- [ ] Status table shows UC-001 and UC-002
- [ ] Both show `pending` status
- [ ] File path column shows `—` (not generated yet)

```bash
python -m ucgen run --id UC-001
```

- [ ] UC-001 generated and written
- [ ] UC-002 still pending

```bash
python -m ucgen status
```

- [ ] UC-001 now shows `generated` with file path
- [ ] UC-002 still shows `pending`

```bash
python -m ucgen run
```

- [ ] Only UC-002 generated (UC-001 skipped — already generated)
- [ ] Batch summary: `1 succeeded`

---

## 9 — Validation

```bash
python -m ucgen validate use-cases/
```

- [ ] Runs against all .md files in use-cases/
- [ ] Each file shows per-section PASS/FAIL table
- [ ] All generated files pass validation
- [ ] Exit code 0 on success

Create a broken file to test failure:

```bash
echo "not a valid use case file" > use-cases/broken-test.md
python -m ucgen validate use-cases/broken-test.md
```

- [ ] Validation FAILS with clear error messages
- [ ] Shows which sections failed (frontmatter, normal course, etc.)
- [ ] Exit code 1 on failure

```bash
del use-cases\broken-test.md
```

---

## 10 — Error handling

**Provider unavailable**
```bash
# Stop ollama serve, then run:
python -m ucgen generate "test idea"
```

- [ ] Clear error message — not a stack trace
- [ ] Hint shown: "Is Ollama running? Try: ollama serve"
- [ ] Exit code 1
- [ ] No partial file written to use-cases/

Restart `ollama serve` before continuing.

**Stage failure debug output**
If any generation produces unexpected output, check:
- [ ] `.ucgen_debug/` directory created on parse failure
- [ ] Raw LLM output file present for diagnosis

---

## 11 — Memory system

```bash
python -m ucgen log --quick "normal course step said 'user clicks button' — UI language not allowed"
```

- [ ] Entry written to `memory/mistakes/M-001.json`
- [ ] Line appended to `memory/mistakes.idx`
- [ ] Confirmation printed: `✓ Logged M-001`
- [ ] Open M-001.json — contains id, date, what_happened, file_affected

---

## 12 — Output file quality audit

Pick the best generated document from your test runs and check:

- [ ] You would share this with a client as a requirements document
- [ ] Entities map correctly to a real database schema
- [ ] Alternative courses cover realistic failure scenarios, not just "system goes down"
- [ ] Open issues raise genuine questions a developer would need answered
- [ ] The document reads like it was written by a senior BA, not generated by AI

If the answer to the last item is no — open `ucgen/prompts/stage2_sections.md` and tighten the rules. That file is the most important thing to iterate on.

---

## Summary

| Section | Status | Notes |
|---------|--------|-------|
| 0 — Prerequisites | | |
| 1 — Environment | | |
| 2 — Config init | | |
| 3 — Single generation | | |
| 4 — ID increment | | |
| 5 — Templates | | |
| 6 — Domain quality | | |
| 7 — Batch generation | | |
| 8 — Project workflow | | |
| 9 — Validation | | |
| 10 — Error handling | | |
| 11 — Memory system | | |
| 12 — Output quality | | |

---

## Known limitations with Ollama/Mistral

- Stage 3 (entities) may fall back to minimal entities on complex use cases — this is expected and handled gracefully
- Table formatting may drift on longer normal course tables — `table_formatter.py` corrects this automatically
- `minimal_guarantee` and `success_guarantee` may be generic on the first run — tighten `ucgen/prompts/stage2_sections.md` if output is too vague
- Mistral 7B occasionally adds preamble text before JSON — `json_extract.py` handles this but check `.ucgen_debug/` if a stage fails

## If something fails

1. Check `.ucgen_debug/` for raw LLM output from the failing stage
2. Run `python -m ucgen version` to confirm Ollama is still available
3. Try `--model qwen2.5:14b` if mistral output quality is poor on complex use cases
4. Open the relevant prompt file in `ucgen/prompts/` and check the rules section

---

*ucgen v0.2.0 — Ollama test run*
