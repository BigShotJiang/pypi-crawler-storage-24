from enum import StrEnum

# API endpoints
API_BASE_URL = "https://intelliclima.fantinicosmi.it"
API_MONO = "/server_v1_mono/api/"

REFRESH_DELAY = 5  # seconds


class FanSpeed(StrEnum):
    """Fan speed options for EcoComfort VMC devices."""

    off = "0"
    sleep = "1"
    low = "2"
    medium = "3"
    high = "4"
    auto_get = "16"  # The value when getting device status that indicates auto mode
    auto_set = "10"  # The value used when sending the command to set the device to auto mode


class FanMode(StrEnum):
    """Fan mode/direction options for EcoComfort VMC devices."""

    off = "0"
    inward = "1"
    outward = "2"
    alternate = "3"
    sensor = "4"
