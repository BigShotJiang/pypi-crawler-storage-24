"""
Konfiguration — Lädt Umgebungsvariablen und stellt Settings bereit.
"""

import os


# NOAA CDO API Token (kostenlos, großzügige Limits)
# Registrierung: https://www.ncdc.noaa.gov/cdo-web/token
NOAA_TOKEN: str = os.environ.get("NOAA_TOKEN", "")

# Climate TRACE API — kein Key nötig
CLIMATE_TRACE_BASE_URL = "https://api.climatetrace.org/v6"

# Open-Meteo Climate API — kein Key nötig
OPEN_METEO_CLIMATE_URL = "https://climate-api.open-meteo.com/v1/climate"

# NOAA CDO API
NOAA_BASE_URL = "https://www.ncei.noaa.gov/cdo-web/api/v2"

# HTTP Timeout in Sekunden
HTTP_TIMEOUT = 30
