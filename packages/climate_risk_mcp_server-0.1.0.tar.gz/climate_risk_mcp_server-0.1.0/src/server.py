"""
Climate Risk MCP Server — Gibt AI-Agents Zugriff auf Klima- und Emissionsdaten.

Nutzt Climate TRACE, Open-Meteo Climate API und NOAA fuer:
- CO2-Emissionen nach Land und Sektor
- Klimaprojektionen (Temperatur, Niederschlag)
- Laendervergleiche und Trends
- Klimarisiko-Bewertungen (Hitze, Ueberflutung, Duerre)
"""

from mcp.server.fastmcp import FastMCP
from src.tools.climate import register_tools


mcp = FastMCP(
    "Climate Risk Server",
    instructions=(
        "Klima- und Emissionsdaten fuer ESG-Analysen und Risikobewertungen. "
        "Nutze get_emissions fuer Laender-CO2-Daten, get_climate_projection fuer "
        "Zukunftsszenarien, und assess_climate_risk fuer Standort-Risikobewertungen. "
        "Laendercodes im ISO alpha-3 Format (DEU, USA, CHN, etc.)."
    ),
)

# Alle Klima-Tools registrieren
register_tools(mcp)


def main():
    """Server starten (stdio-Transport)."""
    mcp.run()


if __name__ == "__main__":
    main()
