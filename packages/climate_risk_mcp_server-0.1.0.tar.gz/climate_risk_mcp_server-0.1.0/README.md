# climate-risk-mcp-server

<!-- mcp-name: climate-risk-mcp-server -->

MCP server for climate risk assessment and emissions data. Gives AI agents access to CO2 emissions by country and sector, climate projections, and risk assessments for heat, flooding, and drought.

Built for ESG analysis, CSRD compliance reporting, and climate due diligence.

## Why Climate Risk Data?

- **EU CSRD** (Corporate Sustainability Reporting Directive) requires 50,000+ companies to report climate risks starting 2025
- **TCFD/ISSB** frameworks demand quantitative climate scenario analysis
- **ESG investors** need emissions data and physical risk assessments for portfolio decisions
- **Supply chain due diligence** requires climate risk screening of locations worldwide

## Tools (6)

| Tool | Description |
|------|-------------|
| `get_emissions` | CO2 emissions by country via Climate TRACE (195+ countries) |
| `get_sector_emissions_tool` | Emissions by sector (power, transport, agriculture, etc.) |
| `get_climate_projection` | Temperature & precipitation projections (RCP/SSP scenarios) |
| `compare_countries` | Compare emissions between multiple countries |
| `get_emission_trends` | Historical emission trends over 10-30 years |
| `assess_climate_risk` | Risk assessment for any location (heat, flooding, drought) |

## Data Sources

- **[Climate TRACE](https://climatetrace.org/)** — Independent greenhouse gas emissions tracking for every country and major sector. Free, no API key needed.
- **[Open-Meteo Climate API](https://open-meteo.com/en/docs/climate-api)** — Climate projections based on CMIP5/CMIP6 models. Free, no API key needed.
- **[NOAA CDO](https://www.ncei.noaa.gov/cdo-web/)** — Historical climate observations. Free token with generous limits.

## Installation

```bash
pip install climate-risk-mcp-server
```

## Configuration

### Claude Desktop

Add to your `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "climate-risk": {
      "command": "climate-risk-server"
    }
  }
}
```

### With uvx (no install needed)

```json
{
  "mcpServers": {
    "climate-risk": {
      "command": "uvx",
      "args": ["climate-risk-mcp-server"]
    }
  }
}
```

### Optional: NOAA Token

For historical climate observations, set a NOAA token (free):

```bash
export NOAA_TOKEN="your-token-here"
```

Register at: https://www.ncdc.noaa.gov/cdo-web/token

## Usage Examples

**Get Germany's CO2 emissions:**
> "What are Germany's CO2 emissions?"

**Compare countries:**
> "Compare emissions between USA, China, and India"

**Climate risk for a location:**
> "Assess climate risk for Munich (48.14, 11.58)"

**Sector analysis:**
> "Show power sector emissions for the UK"

**Future projections:**
> "What are the temperature projections for Berlin under RCP 8.5?"

## Climate Scenarios

| Scenario | Description | Warming by 2100 |
|----------|-------------|-----------------|
| RCP 2.6 / SSP1-2.6 | Strong mitigation | ~1.5°C |
| RCP 4.5 / SSP2-4.5 | Moderate mitigation | ~2.5°C |
| RCP 8.5 / SSP5-8.5 | Business as usual | ~4.5°C |

## License

MIT
