# Minimal-ActivityPub

[![Repo](https://img.shields.io/badge/repo-Codeberg.org-blue)](https://codeberg.org/MarvinsMastodonTools/minimal-activitypub "Repo at Codeberg.org")
[![CI](https://ci.codeberg.org/api/badges/MarvinsMastodonTools/minimal-activitypub/status.svg)](https://ci.codeberg.org/MarvinsMastodonTools/minimal-activitypub "CI / Woodpecker")
[![Downloads](https://pepy.tech/badge/minimal-activitypub)](https://pepy.tech/project/minimal-activitypub "Download count")
[![uv_secure](https://img.shields.io/badge/uv--secure-checked-green)](https://docs.astral.sh/uv/guides/audit/ "Checked with uv-secure")
[![gitleaks](https://img.shields.io/badge/gitleaks-checked-green)](https://github.com/gitleaks/gitleaks "Checked with gitleaks")
[![pysentry](https://img.shields.io/badge/pysentry-checked-green)](https://github.com/astral-sh/pysentry "Checked with pysentry")
[![complexipy](https://img.shields.io/badge/complexipy-checked-green.svg)](https://github.com/rohaquinlop/complexipy "Checked with complexipy")
[![Codestyle](https://img.shields.io/badge/code%20style-ruff-000000.svg)](https://github.com/astral-sh/ruff "Code style: ruff")
[![Version](https://img.shields.io/pypi/pyversions/minimal-activitypub)](https://pypi.org/project/minimal-activitypub "PyPI – Python Version")
[![Wheel](https://img.shields.io/pypi/wheel/minimal-activitypub)](https://pypi.org/project/minimal-activitypub "PyPI – Wheel")
[![License: AGPL-3.0-or-later](https://img.shields.io/badge/License-AGPL--3.0--or--later-blue.svg)](https://spdx.org/licenses/AGPL-3.0-or-later.html "AGPL 3 or later")

Minimal-ActivityPub is a minimal Python implementation of the ActivityPub REST API used by [Mastodon](https://joinmastodon.org/), [Pleroma](https://pleroma.social/), and [Takahe](https://jointakahe.org/). This implementation makes use of asyncio where appropriate. It is intended to be used as a library by other applications. No standalone functionality is provided.

Minimal refers to the fact that only API calls I need for my other projects [Fedinesia](https://codeberg.org/MarvinsMastodonTools/fedinesia), [Lemmy2Fedi](https://codeberg.org/MarvinsMastodonTools/lemmy2fedi) and [Tootbot](https://codeberg.org/MarvinsMastodonTools/tootbot) are implemented.

**DO NOT** expect a full or complete implementation of all [ActivityPub API](https://activitypub.rocks/) functionality.

## Version 2.0.0 Notice

Version 2.0.0 should be backwards compatible with 1.x. The major version bump reflects a significant internal refactor: the single `client_2_server.py` file (~1,100 lines) has been split into focused mixin modules, and constants, exceptions, utilities, and types have been moved to their own modules. No public API changes were made. The major version was chosen out of caution — if you encounter any regressions, please open an issue.

For more details have a look at the [Documentation](https://marvinsmastodontools.codeberg.page/minimal-activitypub/).

## Contributing

Issues and pull requests are welcome.

Minimal-ActivityPub is using [pre-commit](https://pre-commit.com/) for code quality checks and [uv](https://docs.astral.sh/uv/) for dependency management. Please install and use both pre-commit and uv if you'd like to contribute.

## Documentation

The documentation is built using [MkDocs](https://www.mkdocs.org/) with the [Material theme](https://squidfunk.github.io/mkdocs-material/).

### Building Documentation Locally

```bash
# Install documentation dependencies (using the docs group from pyproject.toml)
uv sync --group docs

# Build documentation
mkdocs build

# Serve documentation locally
mkdocs serve
```

### Documentation Structure

- `docs/` - Markdown source files
- `mkdocs.yml` - MkDocs configuration

## Development

This project uses [uv](https://docs.astral.sh/uv/) for dependency management and virtual environments. To set up the development environment:

```bash
# Create and activate virtual environment
uv venv
source .venv/bin/activate

# Install all dependencies including development and documentation groups
uv sync --all-groups

# Run tests
uv run nox
```

For more details on the development workflow, check the `noxfile.py` and `.woodpecker/` configuration files.

## Licensing

Minimal-ActivityPub is licenced with the [GNU Affero General Public License v3.0](http://www.gnu.org/licenses/agpl-3.0.html)

## Supporting Minimal-ActivityPub

There are a number of ways you can support Minimal-ActivityPub:

- Create an issue with problems or ideas you have with/for Minimal-ActivityPub
- You can [buy me a coffee](https://www.buymeacoffee.com/marvin8).
- You can send me small change in Monero to the address below:

### Monero donation address
`8ADQkCya3orL178dADn4bnKuF1JuVGEG97HPRgmXgmZ2cZFSkWU9M2v7BssEGeTRNN2V5p6bSyHa83nrdu1XffDX3cnjKVu`
