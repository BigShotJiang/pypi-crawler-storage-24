import{b as r}from"./graph-DOyqM1V9.js";var e=4;function a(o){return r(o,e)}export{a as c};
