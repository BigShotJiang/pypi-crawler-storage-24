"""Tests for AES-256-GCM encryption, gzip compression, and RSA."""

import os

from logflux.crypto import (
    Encryptor,
    generate_aes_key,
    gzip_compress,
    gzip_decompress,
    rsa_oaep_encrypt,
    rsa_public_key_fingerprint,
)


def test_generate_aes_key():
    key = generate_aes_key()
    assert len(key) == 32
    assert isinstance(key, bytes)
    # Two keys should be different
    key2 = generate_aes_key()
    assert key != key2


def test_encrypt_decrypt_no_compression():
    key = generate_aes_key()
    enc = Encryptor(key)

    plaintext = b"hello world"
    ciphertext, nonce = enc.encrypt_raw(plaintext, compress=False)

    assert len(nonce) == 12
    assert ciphertext != plaintext
    assert len(ciphertext) > len(plaintext)  # includes 16-byte auth tag

    decrypted = enc.decrypt_raw(ciphertext, nonce, decompress=False)
    assert decrypted == plaintext

    enc.close()


def test_encrypt_decrypt_with_compression():
    key = generate_aes_key()
    enc = Encryptor(key)

    plaintext = b"hello " * 1000  # compressible data
    ciphertext, nonce = enc.encrypt_raw(plaintext, compress=True)

    assert ciphertext != plaintext

    decrypted = enc.decrypt_raw(ciphertext, nonce, decompress=True)
    assert decrypted == plaintext

    enc.close()


def test_encrypt_different_nonces():
    key = generate_aes_key()
    enc = Encryptor(key)

    plaintext = b"same message"
    _, nonce1 = enc.encrypt_raw(plaintext, compress=False)
    _, nonce2 = enc.encrypt_raw(plaintext, compress=False)
    assert nonce1 != nonce2

    enc.close()


def test_encrypt_empty_plaintext():
    key = generate_aes_key()
    enc = Encryptor(key)

    ciphertext, nonce = enc.encrypt_raw(b"", compress=False)
    decrypted = enc.decrypt_raw(ciphertext, nonce, decompress=False)
    assert decrypted == b""

    enc.close()


def test_decrypt_wrong_key_fails():
    key1 = generate_aes_key()
    key2 = generate_aes_key()
    enc1 = Encryptor(key1)
    enc2 = Encryptor(key2)

    ciphertext, nonce = enc1.encrypt_raw(b"secret", compress=False)

    import pytest
    with pytest.raises(Exception):
        enc2.decrypt_raw(ciphertext, nonce, decompress=False)

    enc1.close()
    enc2.close()


def test_close_zeroes_key():
    key = generate_aes_key()
    enc = Encryptor(key)
    enc.close()
    assert all(b == 0 for b in enc._key)


def test_gzip_roundtrip():
    data = b"test data for gzip compression"
    compressed = gzip_compress(data)
    assert compressed != data
    decompressed = gzip_decompress(compressed)
    assert decompressed == data


def test_gzip_empty():
    compressed = gzip_compress(b"")
    decompressed = gzip_decompress(compressed)
    assert decompressed == b""


def test_rsa_oaep_encrypt():
    """Test RSA-OAEP encryption with a generated key pair."""
    from cryptography.hazmat.primitives.asymmetric import rsa, padding as asym_padding
    from cryptography.hazmat.primitives import hashes, serialization

    # Generate test key pair
    private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    public_key = private_key.public_key()
    public_key_pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    ).decode("utf-8")

    # Encrypt
    aes_key = generate_aes_key()
    encrypted = rsa_oaep_encrypt(public_key_pem, aes_key)
    assert len(encrypted) > 0
    assert encrypted != aes_key

    # Decrypt with private key to verify
    decrypted = private_key.decrypt(
        encrypted,
        asym_padding.OAEP(
            mgf=asym_padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None,
        ),
    )
    assert decrypted == aes_key


def test_rsa_fingerprint():
    from cryptography.hazmat.primitives.asymmetric import rsa
    from cryptography.hazmat.primitives import serialization

    private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    public_key = private_key.public_key()
    pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    ).decode("utf-8")

    fingerprint = rsa_public_key_fingerprint(pem)
    assert fingerprint.startswith("SHA256:")
    assert len(fingerprint) == 7 + 64  # "SHA256:" + 64 hex chars
