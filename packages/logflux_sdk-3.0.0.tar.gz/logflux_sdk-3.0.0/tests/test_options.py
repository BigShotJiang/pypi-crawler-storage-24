"""Tests for option validation and environment variable loading."""

import os
import pytest

from logflux.options import (
    Options,
    validate_api_key,
    extract_region_from_key,
    load_options_from_env,
)


def test_validate_api_key_valid():
    validate_api_key("eu-lf_abc123")
    validate_api_key("us-lf_x")
    validate_api_key("ca-lf_longkey12345")
    validate_api_key("au-lf_k")
    validate_api_key("ap-lf_k")


def test_validate_api_key_empty():
    with pytest.raises(ValueError, match="required"):
        validate_api_key("")


def test_validate_api_key_no_dash():
    with pytest.raises(ValueError, match="must be"):
        validate_api_key("eulf_abc")


def test_validate_api_key_bad_region():
    with pytest.raises(ValueError, match="region"):
        validate_api_key("xx-lf_abc")


def test_validate_api_key_no_lf_prefix():
    with pytest.raises(ValueError, match="lf_"):
        validate_api_key("eu-abc_123")


def test_validate_api_key_empty_body():
    with pytest.raises(ValueError, match="body is empty"):
        validate_api_key("eu-lf_")


def test_extract_region():
    region, key = extract_region_from_key("eu-lf_abc123")
    assert region == "eu"
    assert key == "lf_abc123"


def test_extract_region_us():
    region, key = extract_region_from_key("us-lf_xyz")
    assert region == "us"
    assert key == "lf_xyz"


def test_extract_region_unknown():
    region, key = extract_region_from_key("lf_abc123")
    assert region == ""
    assert key == "lf_abc123"


def test_options_defaults():
    opts = Options(api_key="eu-lf_test")
    assert opts.queue_size == 1000
    assert opts.flush_interval == 5.0
    assert opts.batch_size == 100
    assert opts.worker_count == 2
    assert opts.max_retries == 3
    assert opts.failsafe is True
    assert opts.enable_compression is True
    assert opts.sample_rate == 1.0
    assert opts.max_breadcrumbs == 100
    assert opts.debug is False
    assert opts.before_send is None


def test_load_options_from_env(monkeypatch):
    monkeypatch.setenv("LOGFLUX_API_KEY", "eu-lf_envtest123")
    monkeypatch.setenv("LOGFLUX_ENVIRONMENT", "staging")
    monkeypatch.setenv("LOGFLUX_NODE", "worker-1")
    monkeypatch.setenv("LOGFLUX_QUEUE_SIZE", "500")
    monkeypatch.setenv("LOGFLUX_BATCH_SIZE", "50")
    monkeypatch.setenv("LOGFLUX_DEBUG", "true")

    opts = load_options_from_env()
    assert opts.api_key == "eu-lf_envtest123"
    assert opts.environment == "staging"
    assert opts.node == "worker-1"
    assert opts.queue_size == 500
    assert opts.batch_size == 50
    assert opts.debug is True


def test_load_options_from_env_with_node(monkeypatch):
    monkeypatch.setenv("LOGFLUX_API_KEY", "eu-lf_test")
    opts = load_options_from_env(node="custom-node")
    assert opts.node == "custom-node"


def test_load_options_from_env_missing_key(monkeypatch):
    monkeypatch.delenv("LOGFLUX_API_KEY", raising=False)
    with pytest.raises(ValueError, match="LOGFLUX_API_KEY"):
        load_options_from_env()


def test_load_options_from_env_invalid_key(monkeypatch):
    monkeypatch.setenv("LOGFLUX_API_KEY", "invalid_key")
    with pytest.raises(ValueError):
        load_options_from_env()


def test_load_options_flush_interval(monkeypatch):
    monkeypatch.setenv("LOGFLUX_API_KEY", "eu-lf_test")
    monkeypatch.setenv("LOGFLUX_FLUSH_INTERVAL", "10")
    opts = load_options_from_env()
    assert opts.flush_interval == 10.0


def test_load_options_http_timeout(monkeypatch):
    monkeypatch.setenv("LOGFLUX_API_KEY", "eu-lf_test")
    monkeypatch.setenv("LOGFLUX_HTTP_TIMEOUT", "60")
    opts = load_options_from_env()
    assert opts.http_timeout == 60.0


def test_load_options_compression(monkeypatch):
    monkeypatch.setenv("LOGFLUX_API_KEY", "eu-lf_test")
    monkeypatch.setenv("LOGFLUX_ENABLE_COMPRESSION", "false")
    opts = load_options_from_env()
    assert opts.enable_compression is False
