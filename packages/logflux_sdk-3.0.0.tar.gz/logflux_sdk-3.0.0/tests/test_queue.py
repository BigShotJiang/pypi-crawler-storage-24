"""Tests for the thread-safe in-memory queue."""

import threading
import time
from datetime import datetime, timezone

from logflux.queue import Queue, QueueEntry


def _make_entry(msg: str = "test") -> QueueEntry:
    return QueueEntry(
        id="abc",
        message=msg,
        timestamp=datetime.now(timezone.utc),
        level=7,
        entry_type=1,
    )


def test_enqueue_dequeue():
    q = Queue(10)
    e = _make_entry("hello")
    assert q.enqueue(e)
    result = q.dequeue_nowait()
    assert result is not None
    assert result.message == "hello"


def test_fifo_order():
    q = Queue(10)
    for i in range(5):
        q.enqueue(_make_entry(f"msg-{i}"))
    for i in range(5):
        e = q.dequeue_nowait()
        assert e is not None
        assert e.message == f"msg-{i}"


def test_enqueue_full():
    q = Queue(3)
    assert q.enqueue(_make_entry("1"))
    assert q.enqueue(_make_entry("2"))
    assert q.enqueue(_make_entry("3"))
    assert not q.enqueue(_make_entry("4"))  # overflow


def test_dequeue_empty():
    q = Queue(10)
    assert q.dequeue_nowait() is None


def test_dequeue_blocking_timeout():
    q = Queue(10)
    result = q.dequeue(timeout=0.05)
    assert result is None


def test_dequeue_blocking_signal():
    q = Queue(10)
    received = []

    def consumer():
        e = q.dequeue(timeout=2.0)
        if e:
            received.append(e.message)

    t = threading.Thread(target=consumer)
    t.start()
    time.sleep(0.05)
    q.enqueue(_make_entry("wakeup"))
    t.join(timeout=2.0)
    assert received == ["wakeup"]


def test_dequeue_batch():
    q = Queue(100)
    for i in range(10):
        q.enqueue(_make_entry(f"m-{i}"))
    batch = q.dequeue_batch(5)
    assert len(batch) == 5
    assert batch[0].message == "m-0"
    assert batch[4].message == "m-4"
    assert q.size == 5


def test_dequeue_batch_more_than_available():
    q = Queue(10)
    q.enqueue(_make_entry("a"))
    q.enqueue(_make_entry("b"))
    batch = q.dequeue_batch(10)
    assert len(batch) == 2


def test_dequeue_batch_empty():
    q = Queue(10)
    batch = q.dequeue_batch(5)
    assert batch == []


def test_size_capacity():
    q = Queue(50)
    assert q.capacity == 50
    assert q.size == 0
    assert q.is_empty
    assert not q.is_full

    q.enqueue(_make_entry())
    assert q.size == 1
    assert not q.is_empty


def test_close():
    q = Queue(10)
    q.enqueue(_make_entry())
    q.close()
    assert q.closed
    assert not q.enqueue(_make_entry())  # closed


def test_close_unblocks_dequeue():
    q = Queue(10)
    received = []

    def consumer():
        result = q.dequeue(timeout=5.0)
        received.append(result)

    t = threading.Thread(target=consumer)
    t.start()
    time.sleep(0.05)
    q.close()
    t.join(timeout=2.0)
    assert received == [None]


def test_clear():
    q = Queue(10)
    q.enqueue(_make_entry())
    q.enqueue(_make_entry())
    assert q.size == 2
    q.clear()
    assert q.size == 0
    assert q.is_empty


def test_concurrent_producers():
    q = Queue(1000)
    count = 100

    def producer(prefix: str):
        for i in range(count):
            q.enqueue(_make_entry(f"{prefix}-{i}"))

    threads = [threading.Thread(target=producer, args=(f"p{j}",)) for j in range(5)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert q.size == 500


def test_min_capacity():
    q = Queue(0)  # should clamp to 1
    assert q.capacity == 1
    assert q.enqueue(_make_entry())
    assert not q.enqueue(_make_entry())
