"""Tests for sampling behavior."""

import json
import os
from unittest.mock import MagicMock, patch
from datetime import datetime, timezone

from logflux.client import Client
from logflux.options import Options
from logflux.types import EntryType


def _make_initialized_client(sample_rate: float = 1.0) -> Client:
    """Creates a Client with a mock encryptor (no real handshake)."""
    opts = Options(
        api_key="eu-lf_test123",
        node="test-node",
        sample_rate=sample_rate,
        failsafe=True,
    )
    client = Client(opts)
    # Skip actual initialization, mock the internals
    client._encryptor = MagicMock()
    client._key_uuid = "test-key-uuid"
    client._endpoints = MagicMock()
    client._endpoints.base_url = "https://test.ingest.eu.logflux.io"
    return client


def test_sample_rate_1_sends_all():
    """With sample_rate=1.0, all entries should be queued."""
    client = _make_initialized_client(sample_rate=1.0)
    for _ in range(100):
        client.enqueue('{"test": true}', 7, EntryType.LOG)
    assert client._queue.size == 100
    client._queue.close()


def test_sample_rate_0_drops_most():
    """With very low sample rate, most entries should be dropped."""
    client = _make_initialized_client(sample_rate=0.01)
    for _ in range(1000):
        client.enqueue('{"test": true}', 7, EntryType.LOG)
    # With 1% rate, expect roughly 10 entries, but allow wide margin
    assert client._queue.size < 100
    client._queue.close()


def test_audit_exempt_from_sampling():
    """Audit entries (type 5) should never be sampled out."""
    client = _make_initialized_client(sample_rate=0.01)
    for _ in range(100):
        client.enqueue('{"test": true}', 6, EntryType.AUDIT)
    assert client._queue.size == 100
    client._queue.close()


def test_different_entry_types_sampled():
    """Non-audit types are subject to sampling."""
    client = _make_initialized_client(sample_rate=0.01)
    types = [
        EntryType.LOG,
        EntryType.METRIC,
        EntryType.TRACE,
        EntryType.EVENT,
        EntryType.TELEMETRY,
    ]
    for entry_type in types:
        for _ in range(200):
            client.enqueue('{"test": true}', 7, entry_type)

    # 1000 entries at 1% -> expect ~10, but allow wide margin
    assert client._queue.size < 200
    client._queue.close()
