"""Tests for all 7 payload types serialization."""

import json

from logflux.payload.context import configure_context
from logflux.payload.log import create_log_payload
from logflux.payload.metric import create_metric_payload
from logflux.payload.trace import create_trace_payload
from logflux.payload.event import create_event_payload
from logflux.payload.audit import create_audit_payload
from logflux.payload.error import create_error_payload, create_error_payload_with_message
from logflux.payload.telemetry import create_telemetry_payload, Reading
from logflux.breadcrumb import Breadcrumb
from logflux.types import LogLevel

from datetime import datetime, timezone


def setup_function():
    configure_context("", "", "")


def test_log_payload_basic():
    p = create_log_payload("hello world", LogLevel.INFO)
    assert p["v"] == "2.0"
    assert p["type"] == "log"
    assert p["level"] == 7
    assert p["message"] == "hello world"
    assert "ts" in p
    assert "attributes" not in p


def test_log_payload_with_attributes():
    p = create_log_payload("test", LogLevel.ERROR, {"key": "val"})
    assert p["attributes"] == {"key": "val"}
    assert p["level"] == 4


def test_log_payload_with_context():
    configure_context("my-app", "production", "v1.2.3")
    p = create_log_payload("test", LogLevel.INFO)
    assert p["source"] == "my-app"
    assert p["meta"]["environment"] == "production"
    assert p["meta"]["release"] == "v1.2.3"
    configure_context("", "", "")


def test_metric_payload():
    p = create_metric_payload("cpu_usage", 85.5, "gauge")
    assert p["v"] == "2.0"
    assert p["type"] == "metric"
    assert p["name"] == "cpu_usage"
    assert p["value"] == 85.5
    assert p["metric_type"] == "gauge"
    assert p["level"] == 7


def test_metric_payload_with_unit():
    p = create_metric_payload("response_time", 120.0, "gauge", unit="ms")
    assert p["unit"] == "ms"


def test_metric_payload_with_attributes():
    p = create_metric_payload("req_count", 42.0, "counter", {"host": "a"})
    assert p["attributes"] == {"host": "a"}


def test_trace_payload():
    start = datetime(2026, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
    end = datetime(2026, 1, 1, 0, 0, 1, tzinfo=timezone.utc)
    p = create_trace_payload(
        "abc123" * 5 + "ab",
        "deadbeef" * 2,
        "",
        "db.query",
        "SELECT * FROM users",
        "ok",
        start,
        end,
        1000.0,
    )
    assert p["v"] == "2.0"
    assert p["type"] == "trace"
    assert p["trace_id"] == "abc123" * 5 + "ab"
    assert p["span_id"] == "deadbeef" * 2
    assert "parent_span_id" not in p
    assert p["operation"] == "db.query"
    assert p["description"] == "SELECT * FROM users"
    assert p["status"] == "ok"
    assert p["duration_ms"] == 1000.0


def test_trace_payload_with_parent():
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    end = datetime(2026, 1, 1, 0, 0, 1, tzinfo=timezone.utc)
    p = create_trace_payload(
        "a" * 32, "b" * 16, "c" * 16, "op", "desc", "ok", start, end, 50.0
    )
    assert p["parent_span_id"] == "c" * 16


def test_event_payload():
    p = create_event_payload("user.signup")
    assert p["v"] == "2.0"
    assert p["type"] == "event"
    assert p["event"] == "user.signup"
    assert p["level"] == 7


def test_event_payload_with_attributes():
    p = create_event_payload("purchase", {"plan": "pro"})
    assert p["attributes"] == {"plan": "pro"}


def test_audit_payload():
    p = create_audit_payload("create", "admin@ex.com", "user", "u-123")
    assert p["v"] == "2.0"
    assert p["type"] == "audit"
    assert p["action"] == "create"
    assert p["actor"] == "admin@ex.com"
    assert p["resource"] == "user"
    assert p["resource_id"] == "u-123"
    assert p["outcome"] == "success"
    assert p["level"] == 6


def test_audit_payload_with_attributes():
    p = create_audit_payload("delete", "a", "r", "1", {"reason": "expired"})
    assert p["attributes"] == {"reason": "expired"}


def test_error_payload():
    try:
        raise ValueError("something went wrong")
    except ValueError as e:
        p = create_error_payload(e)

    assert p["v"] == "2.0"
    assert p["type"] == "log"
    assert p["level"] == 4
    assert p["error_type"] == "ValueError"
    assert p["error_message"] == "something went wrong"
    assert p["message"] == "something went wrong"
    assert "stack_trace" in p
    assert len(p["stack_trace"]) > 0


def test_error_payload_with_breadcrumbs():
    crumbs = [
        Breadcrumb(timestamp="2026-01-01T00:00:00", category="nav", message="page A"),
        Breadcrumb(timestamp="2026-01-01T00:00:01", category="nav", message="page B"),
    ]
    try:
        raise RuntimeError("oops")
    except RuntimeError as e:
        p = create_error_payload(e, breadcrumbs=crumbs)

    assert "breadcrumbs" in p
    assert len(p["breadcrumbs"]) == 2


def test_error_payload_with_message():
    try:
        raise IOError("disk full")
    except IOError as e:
        p = create_error_payload_with_message(e, "Failed to save", {"path": "/tmp"})

    assert p["message"] == "Failed to save"
    assert p["error_message"] == "disk full"
    assert p["attributes"]["error"] == "disk full"
    assert p["attributes"]["path"] == "/tmp"


def test_error_chain():
    try:
        try:
            raise ValueError("inner")
        except ValueError as inner:
            raise RuntimeError("outer") from inner
    except RuntimeError as e:
        p = create_error_payload(e)

    assert "error_chain" in p
    assert len(p["error_chain"]) == 2
    assert p["error_chain"][0]["type"] == "RuntimeError"
    assert p["error_chain"][1]["type"] == "ValueError"


def test_telemetry_payload():
    readings = [
        Reading(name="temperature", value=22.5, unit="C"),
        Reading(name="humidity", value=65.0),
    ]
    p = create_telemetry_payload("sensor-001", readings)
    assert p["v"] == "2.0"
    assert p["type"] == "telemetry"
    assert p["device_id"] == "sensor-001"
    assert len(p["readings"]) == 2
    assert p["readings"][0]["name"] == "temperature"
    assert p["readings"][0]["value"] == 22.5
    assert p["readings"][0]["unit"] == "C"
    assert "unit" not in p["readings"][1]


def test_telemetry_payload_with_attributes():
    readings = [Reading(name="voltage", value=3.3)]
    p = create_telemetry_payload("dev-1", readings, {"location": "room-a"})
    assert p["attributes"] == {"location": "room-a"}


def test_all_payloads_are_json_serializable():
    """All payload types must be JSON-serializable."""
    start = datetime(2026, 1, 1, tzinfo=timezone.utc)
    end = datetime(2026, 1, 1, 0, 0, 1, tzinfo=timezone.utc)

    payloads = [
        create_log_payload("msg", LogLevel.INFO),
        create_metric_payload("m", 1.0, "counter"),
        create_trace_payload("a" * 32, "b" * 16, "", "op", "d", "ok", start, end, 100),
        create_event_payload("e"),
        create_audit_payload("a", "b", "c", "d"),
        create_telemetry_payload("dev", [Reading("t", 1.0)]),
    ]

    for p in payloads:
        result = json.dumps(p)
        assert isinstance(result, str)
        parsed = json.loads(result)
        assert parsed["v"] == "2.0"
