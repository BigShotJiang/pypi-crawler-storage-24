"""Tests for stats tracking and drop reasons."""

from logflux.stats import StatsTracker, ClientStats
from logflux.types import DropReason


def test_initial_stats():
    tracker = StatsTracker()
    snap = tracker.snapshot(0, 100)
    assert snap.entries_sent == 0
    assert snap.entries_dropped == 0
    assert snap.entries_queued == 0
    assert snap.queue_size == 0
    assert snap.queue_capacity == 100
    assert snap.drop_reasons == {}
    assert snap.last_send_error == ""
    assert snap.last_send_time is None
    assert snap.handshake_ok is False


def test_record_sent():
    tracker = StatsTracker()
    tracker.record_sent(5)
    tracker.record_sent(3)
    snap = tracker.snapshot(0, 100)
    assert snap.entries_sent == 8
    assert snap.last_send_time is not None


def test_record_drop():
    tracker = StatsTracker()
    tracker.record_drop(DropReason.QUEUE_OVERFLOW, 2)
    tracker.record_drop(DropReason.NETWORK_ERROR, 1)
    tracker.record_drop(DropReason.QUEUE_OVERFLOW, 3)
    snap = tracker.snapshot(0, 100)
    assert snap.entries_dropped == 6
    assert snap.drop_reasons[DropReason.QUEUE_OVERFLOW] == 5
    assert snap.drop_reasons[DropReason.NETWORK_ERROR] == 1


def test_record_queued():
    tracker = StatsTracker()
    tracker.record_queued(10)
    snap = tracker.snapshot(5, 100)
    assert snap.entries_queued == 10
    assert snap.queue_size == 5


def test_record_error():
    tracker = StatsTracker()
    tracker.record_error("connection refused")
    snap = tracker.snapshot(0, 100)
    assert snap.last_send_error == "connection refused"


def test_handshake_ok():
    tracker = StatsTracker()
    assert tracker.handshake_ok is False
    tracker.handshake_ok = True
    assert tracker.handshake_ok is True
    snap = tracker.snapshot(0, 100)
    assert snap.handshake_ok is True


def test_all_drop_reasons():
    tracker = StatsTracker()
    reasons = [
        DropReason.QUEUE_OVERFLOW,
        DropReason.NETWORK_ERROR,
        DropReason.SEND_ERROR,
        DropReason.RATE_LIMITED,
        DropReason.QUOTA_EXCEEDED,
        DropReason.BEFORE_SEND,
        DropReason.VALIDATION_ERROR,
    ]
    for r in reasons:
        tracker.record_drop(r, 1)

    snap = tracker.snapshot(0, 100)
    assert snap.entries_dropped == 7
    assert len(snap.drop_reasons) == 7
    for r in reasons:
        assert snap.drop_reasons[r] == 1


def test_snapshot_returns_copy():
    tracker = StatsTracker()
    tracker.record_drop(DropReason.QUEUE_OVERFLOW, 1)
    snap1 = tracker.snapshot(0, 100)

    tracker.record_drop(DropReason.QUEUE_OVERFLOW, 1)
    snap2 = tracker.snapshot(0, 100)

    assert snap1.entries_dropped == 1
    assert snap2.entries_dropped == 2
