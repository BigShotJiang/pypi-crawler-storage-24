"""Tests for span creation, child spans, timing, and trace headers."""

import time

from logflux.span import (
    Span,
    SpanData,
    TraceContext,
    TRACE_HEADER,
    generate_trace_id,
    generate_span_id,
    parse_trace_header,
    start_span,
    continue_from_headers,
)


def test_generate_trace_id():
    tid = generate_trace_id()
    assert len(tid) == 32
    assert all(c in "0123456789abcdef" for c in tid)


def test_generate_span_id():
    sid = generate_span_id()
    assert len(sid) == 16
    assert all(c in "0123456789abcdef" for c in sid)


def test_start_span():
    span = start_span("db.query", "SELECT * FROM users")
    assert span.operation == "db.query"
    assert span.description == "SELECT * FROM users"
    assert len(span.trace_id) == 32
    assert len(span.span_id) == 16
    assert span.parent_span_id == ""
    assert span.status == "ok"
    assert not span.ended


def test_span_end():
    span = start_span("test.op", "test")
    time.sleep(0.01)
    data = span.end()
    assert data is not None
    assert isinstance(data, SpanData)
    assert data.operation == "test.op"
    assert data.status == "ok"
    assert data.duration_ms >= 0


def test_span_end_twice():
    span = start_span("op", "desc")
    data1 = span.end()
    data2 = span.end()
    assert data1 is not None
    assert data2 is None


def test_span_child():
    parent = start_span("http.request", "GET /api")
    child = parent.start_child("db.query", "SELECT *")

    assert child.trace_id == parent.trace_id
    assert child.parent_span_id == parent.span_id
    assert child.span_id != parent.span_id
    assert child.operation == "db.query"


def test_span_attributes():
    span = start_span("op", "desc")
    span.set_attribute("db.type", "postgres")
    span.set_attributes({"db.name": "mydb", "db.host": "localhost"})
    assert span.attributes == {
        "db.type": "postgres",
        "db.name": "mydb",
        "db.host": "localhost",
    }


def test_span_set_status():
    span = start_span("op", "desc")
    span.set_status("error")
    assert span.status == "error"


def test_span_set_error():
    span = start_span("op", "desc")
    span.set_error(RuntimeError("boom"))
    assert span.status == "error"
    assert span.attributes["error.message"] == "boom"


def test_to_trace_header():
    span = start_span("op", "desc")
    header = span.to_trace_header()
    parts = header.split("-")
    assert len(parts) == 3
    assert len(parts[0]) == 32
    assert len(parts[1]) == 16
    assert parts[2] == "1"


def test_parse_trace_header_valid():
    tid = "a" * 32
    sid = "b" * 16
    tc = parse_trace_header(f"{tid}-{sid}-1")
    assert tc is not None
    assert tc.trace_id == tid
    assert tc.span_id == sid
    assert tc.sampled is True


def test_parse_trace_header_not_sampled():
    tc = parse_trace_header(f"{'a' * 32}-{'b' * 16}-0")
    assert tc is not None
    assert tc.sampled is False


def test_parse_trace_header_no_sampled():
    tc = parse_trace_header(f"{'a' * 32}-{'b' * 16}")
    assert tc is not None
    assert tc.sampled is True  # default sampled


def test_parse_trace_header_empty():
    assert parse_trace_header("") is None


def test_parse_trace_header_invalid():
    assert parse_trace_header("too-short") is None
    assert parse_trace_header("x" * 31 + "-" + "y" * 16) is None  # bad trace_id length
    assert parse_trace_header("z" * 32 + "-" + "w" * 15) is None  # bad span_id length
    assert parse_trace_header("G" * 32 + "-" + "a" * 16) is None  # non-hex


def test_continue_from_headers_valid():
    tid = "a" * 32
    sid = "b" * 16
    headers = {TRACE_HEADER: f"{tid}-{sid}-1"}
    span = continue_from_headers(headers, "child.op", "desc")
    assert span.trace_id == tid
    assert span.parent_span_id == sid
    assert span.operation == "child.op"


def test_continue_from_headers_missing():
    span = continue_from_headers({}, "root.op", "desc")
    assert span.parent_span_id == ""  # new root span
    assert len(span.trace_id) == 32


def test_continue_from_headers_lowercase():
    tid = "a" * 32
    sid = "b" * 16
    headers = {"x-logflux-trace": f"{tid}-{sid}-1"}
    span = continue_from_headers(headers, "op", "desc")
    assert span.trace_id == tid
