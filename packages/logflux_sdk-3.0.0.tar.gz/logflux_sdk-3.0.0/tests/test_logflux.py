"""Tests for the LogFlux static API, init, log levels, and close."""

import pytest
from unittest.mock import MagicMock, patch

import logflux
from logflux import LogFlux, Options, LogLevel, EntryType, ClientStats
from logflux.payload.context import configure_context


def setup_function():
    """Reset global state before each test."""
    logflux._global_client = None
    configure_context("", "", "")


def teardown_function():
    logflux._global_client = None
    configure_context("", "", "")


def test_logflux_not_instantiable():
    with pytest.raises(TypeError):
        LogFlux()


def test_is_active_before_init():
    assert LogFlux.is_active() is False


def test_stats_before_init():
    stats = LogFlux.stats()
    assert isinstance(stats, ClientStats)
    assert stats.entries_sent == 0


def test_log_before_init_no_crash():
    """Log methods should not crash when SDK is not initialized."""
    LogFlux.info("test")
    LogFlux.debug("test")
    LogFlux.warn("test")
    LogFlux.error("test")
    LogFlux.notice("test")
    LogFlux.critical("test")
    LogFlux.alert("test")
    LogFlux.emergency("test")


def test_metric_before_init_no_crash():
    LogFlux.counter("test", 1.0)
    LogFlux.gauge("test", 1.0)
    LogFlux.metric("test", 1.0, "counter")


def test_event_before_init_no_crash():
    LogFlux.event("test")


def test_audit_before_init_no_crash():
    LogFlux.audit("create", "user", "resource", "id")


def test_capture_error_before_init_no_crash():
    LogFlux.capture_error(RuntimeError("test"))
    LogFlux.capture_error_with_message(RuntimeError("test"), "msg")


def test_breadcrumbs_before_init_no_crash():
    LogFlux.add_breadcrumb("cat", "msg")
    LogFlux.clear_breadcrumbs()


def test_scope():
    """with_scope should call the callback with a Scope."""
    from logflux.scope import Scope

    received = []
    LogFlux.with_scope(lambda s: received.append(isinstance(s, Scope)))
    assert received == [True]


def test_start_span():
    span = LogFlux.start_span("op", "desc")
    assert span.operation == "op"
    assert span.description == "desc"
    assert len(span.trace_id) == 32


def test_module_level_functions():
    """Module-level convenience functions should not crash before init."""
    logflux.info("test")
    logflux.debug("test")
    logflux.warn("test")
    logflux.error("test")
    logflux.counter("test", 1.0)
    logflux.gauge("test", 1.0)
    logflux.event("test")
    logflux.audit("a", "b", "c", "d")


def test_close_before_init():
    """Close before init should not crash."""
    LogFlux.close()
    logflux.close()


def test_flush_before_init():
    """Flush before init should not crash."""
    LogFlux.flush()
    logflux.flush()


def test_send_span_before_init():
    span = logflux.start_span("op", "desc")
    logflux.send_span(span)  # should not crash


def test_version():
    from logflux.version import VERSION
    assert VERSION == "3.0.0"


def test_log_with_mock_client():
    """When client is mocked, log should enqueue."""
    mock_client = MagicMock()
    mock_client._options = Options(api_key="eu-lf_test")
    mock_client.breadcrumbs = MagicMock()
    logflux._global_client = mock_client

    LogFlux.log(LogLevel.INFO, "test message", {"key": "val"})
    mock_client.enqueue.assert_called_once()
    args = mock_client.enqueue.call_args
    assert "test message" in args[0][0]
    assert args[0][1] == LogLevel.INFO
    assert args[0][2] == EntryType.LOG


def test_counter_with_mock_client():
    mock_client = MagicMock()
    mock_client._options = Options(api_key="eu-lf_test")
    logflux._global_client = mock_client

    LogFlux.counter("requests", 42.0, {"host": "a"})
    mock_client.enqueue.assert_called_once()
    args = mock_client.enqueue.call_args
    assert "requests" in args[0][0]
    assert args[0][2] == EntryType.METRIC


def test_event_with_mock_client():
    mock_client = MagicMock()
    mock_client._options = Options(api_key="eu-lf_test")
    mock_client.breadcrumbs = MagicMock()
    logflux._global_client = mock_client

    LogFlux.event("user.signup", {"plan": "pro"})
    mock_client.enqueue.assert_called_once()
    assert "user.signup" in mock_client.enqueue.call_args[0][0]


def test_audit_with_mock_client():
    mock_client = MagicMock()
    mock_client._options = Options(api_key="eu-lf_test")
    logflux._global_client = mock_client

    LogFlux.audit("delete", "admin", "user", "u-123")
    mock_client.enqueue.assert_called_once()
    args = mock_client.enqueue.call_args
    assert args[0][2] == EntryType.AUDIT
