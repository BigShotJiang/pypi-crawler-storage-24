"""Tests for multipart/mixed body construction."""

from datetime import datetime, timezone

from logflux.crypto import Encryptor, generate_aes_key
from logflux.transport.multipart import (
    MultipartEntry,
    build_multipart_body,
)
from logflux.types import EntryType


def test_build_single_entry():
    key = generate_aes_key()
    enc = Encryptor(key)

    entries = [
        MultipartEntry(
            message='{"v":"2.0","type":"log","message":"hello"}',
            timestamp=datetime.now(timezone.utc),
            entry_type=EntryType.LOG,
        )
    ]

    result = build_multipart_body(entries, enc, "key-uuid-123", True)
    assert result.content_type.startswith("multipart/mixed; boundary=")
    assert len(result.body) > 0

    body_str = result.body.decode("utf-8", errors="replace")
    assert "X-LF-Entry-Type: 1" in body_str
    assert "X-LF-Key-ID: key-uuid-123" in body_str
    assert "X-LF-Nonce:" in body_str
    assert "X-LF-Payload-Type: 1" in body_str

    enc.close()


def test_build_multiple_entries():
    key = generate_aes_key()
    enc = Encryptor(key)

    entries = [
        MultipartEntry(
            message='{"type":"log","message":"a"}',
            timestamp=datetime.now(timezone.utc),
            entry_type=EntryType.LOG,
        ),
        MultipartEntry(
            message='{"type":"metric","name":"cpu"}',
            timestamp=datetime.now(timezone.utc),
            entry_type=EntryType.METRIC,
        ),
        MultipartEntry(
            message='{"type":"event","event":"signup"}',
            timestamp=datetime.now(timezone.utc),
            entry_type=EntryType.EVENT,
        ),
    ]

    result = build_multipart_body(entries, enc, "uuid", True)
    body_str = result.body.decode("utf-8", errors="replace")

    assert body_str.count("X-LF-Entry-Type:") == 3
    assert "X-LF-Entry-Type: 1" in body_str
    assert "X-LF-Entry-Type: 2" in body_str
    assert "X-LF-Entry-Type: 4" in body_str

    enc.close()


def test_build_with_search_tokens():
    key = generate_aes_key()
    enc = Encryptor(key)

    entries = [
        MultipartEntry(
            message='{"type":"log"}',
            timestamp=datetime.now(timezone.utc),
            entry_type=EntryType.LOG,
            search_tokens=["error", "timeout"],
        )
    ]

    result = build_multipart_body(entries, enc, "uuid", False)
    body_str = result.body.decode("utf-8", errors="replace")
    assert "X-LF-Search-Tokens: error,timeout" in body_str

    enc.close()


def test_build_telemetry_managed_no_encryption():
    key = generate_aes_key()
    enc = Encryptor(key)

    entries = [
        MultipartEntry(
            message='{"type":"telemetry","device_id":"d1"}',
            timestamp=datetime.now(timezone.utc),
            entry_type=EntryType.TELEMETRY_MANAGED,
        )
    ]

    result = build_multipart_body(entries, enc, "uuid", True)
    body_str = result.body.decode("utf-8", errors="replace")

    # Type 7 should NOT have Key-ID or Nonce (no E2E encryption)
    assert "X-LF-Key-ID:" not in body_str
    assert "X-LF-Nonce:" not in body_str
    assert "X-LF-Payload-Type: 3" in body_str  # GzipJSON

    enc.close()


def test_closing_boundary():
    key = generate_aes_key()
    enc = Encryptor(key)

    entries = [
        MultipartEntry(
            message="test",
            timestamp=datetime.now(timezone.utc),
            entry_type=EntryType.LOG,
        )
    ]

    result = build_multipart_body(entries, enc, "uuid", False)
    boundary = result.content_type.split("boundary=")[1]
    assert result.body.endswith(f"\r\n--{boundary}--\r\n".encode("utf-8"))

    enc.close()


def test_timestamp_in_header():
    key = generate_aes_key()
    enc = Encryptor(key)

    ts = datetime(2026, 3, 15, 12, 0, 0, tzinfo=timezone.utc)
    entries = [
        MultipartEntry(
            message="test",
            timestamp=ts,
            entry_type=EntryType.LOG,
        )
    ]

    result = build_multipart_body(entries, enc, "uuid", False)
    body_str = result.body.decode("utf-8", errors="replace")
    assert "X-LF-Timestamp:" in body_str

    enc.close()
