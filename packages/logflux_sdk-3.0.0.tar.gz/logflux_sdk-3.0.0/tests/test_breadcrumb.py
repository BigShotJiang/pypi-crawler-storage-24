"""Tests for the breadcrumb ring buffer."""

from logflux.breadcrumb import BreadcrumbRing, Breadcrumb


def test_add_and_snapshot():
    ring = BreadcrumbRing(10)
    ring.add(Breadcrumb(category="nav", message="page A"))
    ring.add(Breadcrumb(category="nav", message="page B"))

    snap = ring.snapshot()
    assert len(snap) == 2
    assert snap[0].message == "page A"
    assert snap[1].message == "page B"


def test_auto_timestamp():
    ring = BreadcrumbRing(10)
    ring.add(Breadcrumb(message="test"))
    snap = ring.snapshot()
    assert snap[0].timestamp != ""


def test_explicit_timestamp():
    ring = BreadcrumbRing(10)
    ring.add(Breadcrumb(timestamp="2026-01-01T00:00:00", message="test"))
    snap = ring.snapshot()
    assert snap[0].timestamp == "2026-01-01T00:00:00"


def test_ring_buffer_overflow():
    ring = BreadcrumbRing(3)
    ring.add(Breadcrumb(message="a"))
    ring.add(Breadcrumb(message="b"))
    ring.add(Breadcrumb(message="c"))
    ring.add(Breadcrumb(message="d"))  # overwrites "a"

    snap = ring.snapshot()
    assert len(snap) == 3
    assert snap[0].message == "b"
    assert snap[1].message == "c"
    assert snap[2].message == "d"


def test_ring_buffer_full_cycle():
    ring = BreadcrumbRing(2)
    ring.add(Breadcrumb(message="a"))
    ring.add(Breadcrumb(message="b"))
    ring.add(Breadcrumb(message="c"))
    ring.add(Breadcrumb(message="d"))
    ring.add(Breadcrumb(message="e"))

    snap = ring.snapshot()
    assert len(snap) == 2
    assert snap[0].message == "d"
    assert snap[1].message == "e"


def test_clear():
    ring = BreadcrumbRing(10)
    ring.add(Breadcrumb(message="a"))
    ring.add(Breadcrumb(message="b"))
    assert ring.size == 2

    ring.clear()
    assert ring.size == 0
    assert ring.snapshot() == []


def test_size():
    ring = BreadcrumbRing(5)
    assert ring.size == 0
    ring.add(Breadcrumb(message="a"))
    assert ring.size == 1
    ring.add(Breadcrumb(message="b"))
    assert ring.size == 2


def test_size_after_overflow():
    ring = BreadcrumbRing(2)
    ring.add(Breadcrumb(message="a"))
    ring.add(Breadcrumb(message="b"))
    ring.add(Breadcrumb(message="c"))
    assert ring.size == 2  # capped at max_size


def test_min_size():
    ring = BreadcrumbRing(0)  # clamps to 1
    ring.add(Breadcrumb(message="a"))
    assert ring.size == 1
    ring.add(Breadcrumb(message="b"))
    snap = ring.snapshot()
    assert len(snap) == 1
    assert snap[0].message == "b"


def test_snapshot_with_data():
    ring = BreadcrumbRing(10)
    ring.add(Breadcrumb(category="http", message="GET /api", data={"status": "200"}))
    snap = ring.snapshot()
    assert snap[0].data == {"status": "200"}


def test_snapshot_empty():
    ring = BreadcrumbRing(10)
    assert ring.snapshot() == []
