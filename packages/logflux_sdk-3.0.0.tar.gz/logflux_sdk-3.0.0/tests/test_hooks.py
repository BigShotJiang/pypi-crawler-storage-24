"""Tests for before_send hooks (drop and modify)."""

from unittest.mock import MagicMock

from logflux.client import Client
from logflux.options import Options
from logflux.types import EntryType, DropReason


def _make_client(before_send=None, before_send_log=None) -> Client:
    opts = Options(
        api_key="eu-lf_test123",
        node="test",
        failsafe=True,
        before_send=before_send,
        before_send_log=before_send_log,
    )
    client = Client(opts)
    client._encryptor = MagicMock()
    client._key_uuid = "k"
    client._endpoints = MagicMock()
    client._endpoints.base_url = "https://test.ingest.eu.logflux.io"
    return client


def test_before_send_passes():
    """When before_send returns the entry, it should be queued."""

    def hook(entry):
        return entry

    client = _make_client(before_send=hook)
    client.enqueue('{"test":true}', 7, EntryType.LOG)
    assert client._queue.size == 1
    client._queue.close()


def test_before_send_drops():
    """When before_send returns None, the entry should be dropped."""

    def hook(entry):
        return None

    client = _make_client(before_send=hook)
    client.enqueue('{"test":true}', 7, EntryType.LOG)
    assert client._queue.size == 0
    stats = client.get_stats()
    assert stats.drop_reasons.get(DropReason.BEFORE_SEND, 0) == 1
    client._queue.close()


def test_before_send_modifies():
    """When before_send returns a modified entry, it should be queued."""

    def hook(entry):
        entry["message"] = "modified"
        return entry

    client = _make_client(before_send=hook)
    client.enqueue('{"test":true}', 7, EntryType.LOG)
    assert client._queue.size == 1
    client._queue.close()


def test_before_send_called_with_entry_info():
    """Verify the hook receives entry type info."""
    received = []

    def hook(entry):
        received.append(entry)
        return entry

    client = _make_client(before_send=hook)
    client.enqueue('{"type":"log"}', 7, EntryType.LOG)
    assert len(received) == 1
    assert received[0]["entry_type"] == EntryType.LOG
    assert received[0]["level"] == 7
    client._queue.close()


def test_before_send_multiple_calls():
    """Verify hook is called for every entry."""
    count = [0]

    def hook(entry):
        count[0] += 1
        return entry

    client = _make_client(before_send=hook)
    for _ in range(10):
        client.enqueue('{"test":true}', 7, EntryType.LOG)
    assert count[0] == 10
    client._queue.close()


def test_no_hook_works():
    """Without a hook, entries should be queued normally."""
    client = _make_client()
    client.enqueue('{"test":true}', 7, EntryType.LOG)
    assert client._queue.size == 1
    client._queue.close()
