"""Tests for scope attribute merging."""

from logflux.scope import Scope


def test_set_attribute():
    scope = Scope()
    scope.set_attribute("key", "value")
    assert scope.get_attributes() == {"key": "value"}


def test_set_attributes():
    scope = Scope()
    scope.set_attributes({"a": "1", "b": "2"})
    attrs = scope.get_attributes()
    assert attrs == {"a": "1", "b": "2"}


def test_set_user():
    scope = Scope()
    scope.set_user("user-123")
    assert scope.get_attributes()["user.id"] == "user-123"


def test_set_request():
    scope = Scope()
    scope.set_request("GET", "/api/data", "req-abc")
    attrs = scope.get_attributes()
    assert attrs["http.method"] == "GET"
    assert attrs["http.path"] == "/api/data"
    assert attrs["request_id"] == "req-abc"


def test_set_request_no_id():
    scope = Scope()
    scope.set_request("POST", "/submit")
    attrs = scope.get_attributes()
    assert "request_id" not in attrs


def test_apply_to_empty():
    scope = Scope()
    scope.set_attributes({"env": "prod"})
    result = scope.apply_to(None)
    assert result == {"env": "prod"}


def test_apply_to_merges():
    scope = Scope()
    scope.set_attributes({"env": "prod", "service": "api"})
    result = scope.apply_to({"request_id": "r-1"})
    assert result["env"] == "prod"
    assert result["service"] == "api"
    assert result["request_id"] == "r-1"


def test_apply_to_explicit_takes_priority():
    scope = Scope()
    scope.set_attributes({"env": "prod"})
    result = scope.apply_to({"env": "staging"})
    assert result["env"] == "staging"  # explicit wins


def test_scope_breadcrumbs():
    scope = Scope(max_breadcrumbs=5)
    scope.add_breadcrumb("nav", "page A")
    scope.add_breadcrumb("click", "button B", {"id": "btn-1"})

    crumbs = scope.breadcrumbs.snapshot()
    assert len(crumbs) == 2
    assert crumbs[0].category == "nav"
    assert crumbs[1].data == {"id": "btn-1"}


def test_get_attributes_is_copy():
    scope = Scope()
    scope.set_attribute("x", "1")
    attrs = scope.get_attributes()
    attrs["x"] = "changed"
    assert scope.get_attributes()["x"] == "1"  # unchanged
