"""AES-256-GCM encryption and gzip compression using the cryptography library."""

from __future__ import annotations

import gzip
import os

from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.asymmetric import padding as asym_padding
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric.rsa import RSAPublicKey

KEY_SIZE = 32
NONCE_SIZE = 12


class Encryptor:
    """AES-256-GCM encryptor with optional gzip compression."""

    def __init__(self, aes_key: bytes) -> None:
        self._key = bytearray(aes_key[:KEY_SIZE])
        self._aesgcm = AESGCM(bytes(self._key))

    def encrypt_raw(self, plaintext: bytes, compress: bool) -> tuple[bytes, bytes]:
        """Encrypts plaintext with AES-256-GCM.

        Returns (ciphertext_with_tag, nonce).
        The ciphertext includes the 16-byte GCM auth tag appended (matches Go gcm.Seal).
        """
        data = plaintext
        if compress:
            data = gzip_compress(data)

        nonce = os.urandom(NONCE_SIZE)
        # AESGCM.encrypt returns ciphertext + tag concatenated
        ciphertext = self._aesgcm.encrypt(nonce, data, None)
        return ciphertext, nonce

    def decrypt_raw(self, ciphertext: bytes, nonce: bytes, decompress: bool) -> bytes:
        """Decrypts AES-256-GCM ciphertext (with appended auth tag)."""
        plaintext = self._aesgcm.decrypt(nonce, ciphertext, None)
        if decompress:
            plaintext = gzip_decompress(plaintext)
        return plaintext

    def close(self) -> None:
        """Zeroes out key material. Encryptor must not be used after calling close()."""
        for i in range(len(self._key)):
            self._key[i] = 0
        self._aesgcm = None  # type: ignore[assignment]


def generate_aes_key() -> bytes:
    """Generates a cryptographically random 32-byte AES key."""
    return os.urandom(KEY_SIZE)


def gzip_compress(data: bytes) -> bytes:
    """Compresses data with gzip."""
    return gzip.compress(data)


def gzip_decompress(data: bytes) -> bytes:
    """Decompresses gzip data."""
    return gzip.decompress(data)


def rsa_oaep_encrypt(public_key_pem: str, plaintext: bytes) -> bytes:
    """Encrypts data with RSA-OAEP-SHA256 using a PEM public key."""
    public_key = serialization.load_pem_public_key(public_key_pem.encode("utf-8"))
    if not isinstance(public_key, RSAPublicKey):
        raise ValueError("Expected RSA public key")
    return public_key.encrypt(
        plaintext,
        asym_padding.OAEP(
            mgf=asym_padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None,
        ),
    )


def rsa_public_key_fingerprint(public_key_pem: str) -> str:
    """Returns SHA256:<hex> fingerprint of a PEM public key."""
    import hashlib

    public_key = serialization.load_pem_public_key(public_key_pem.encode("utf-8"))
    der_bytes = public_key.public_bytes(
        encoding=serialization.Encoding.DER,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    )
    digest = hashlib.sha256(der_bytes).hexdigest()
    return f"SHA256:{digest}"
