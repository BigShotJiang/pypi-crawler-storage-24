"""Ring buffer for breadcrumbs."""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from datetime import datetime, timezone


@dataclass
class Breadcrumb:
    """A single breadcrumb entry in the trail."""

    timestamp: str = ""
    category: str = ""
    message: str = ""
    level: str = ""
    data: dict[str, str] | None = None


class BreadcrumbRing:
    """Thread-safe ring buffer for breadcrumbs.

    When full, the oldest entries are overwritten.
    """

    def __init__(self, max_size: int = 100) -> None:
        self._max_size = max(1, max_size)
        self._items: list[Breadcrumb | None] = [None] * self._max_size
        self._position = 0
        self._full = False
        self._lock = threading.Lock()

    def add(self, b: Breadcrumb) -> None:
        """Adds a breadcrumb to the ring buffer."""
        if not b.timestamp:
            b.timestamp = datetime.now(timezone.utc).isoformat()
        with self._lock:
            self._items[self._position] = b
            self._position = (self._position + 1) % self._max_size
            if self._position == 0:
                self._full = True

    def snapshot(self) -> list[Breadcrumb]:
        """Returns a chronological copy of all breadcrumbs."""
        with self._lock:
            count = self._max_size if self._full else self._position
            if count == 0:
                return []

            result: list[Breadcrumb] = []
            if self._full:
                for i in range(self._position, self._max_size):
                    item = self._items[i]
                    if item is not None:
                        result.append(item)
                for i in range(0, self._position):
                    item = self._items[i]
                    if item is not None:
                        result.append(item)
            else:
                for i in range(0, self._position):
                    item = self._items[i]
                    if item is not None:
                        result.append(item)
            return result

    def clear(self) -> None:
        """Removes all breadcrumbs."""
        with self._lock:
            self._position = 0
            self._full = False

    @property
    def size(self) -> int:
        with self._lock:
            return self._max_size if self._full else self._position
