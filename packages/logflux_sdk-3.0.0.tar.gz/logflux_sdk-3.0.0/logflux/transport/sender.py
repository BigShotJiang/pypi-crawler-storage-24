"""HTTP sender for multipart/mixed requests to the ingestor."""

from __future__ import annotations

import math
import random
import ssl
import urllib.request
from dataclasses import dataclass, field

from ..version import VERSION

USER_AGENT = f"logflux-python-sdk/{VERSION}"
MAX_RESPONSE_SIZE = 1024 * 1024  # 1 MB


@dataclass
class SendResult:
    """Result of a send attempt."""

    ok: bool = False
    status_code: int = 0
    retry_after_sec: int = 0
    is_rate_limited: bool = False
    is_quota_exceeded: bool = False
    rate_limit_info: dict[str, int] | None = None
    error: str = ""


def send_multipart(
    url: str,
    api_key: str,
    body: bytes,
    content_type: str,
    timeout: float = 30.0,
) -> SendResult:
    """Sends a multipart/mixed request to the ingest endpoint.

    Handles 429 (rate limited) and 507 (quota exceeded) responses.
    """
    req = urllib.request.Request(url, data=body, method="POST")
    req.add_header("Content-Type", content_type)
    req.add_header("Authorization", f"Bearer {api_key}")
    req.add_header("User-Agent", USER_AGENT)

    ctx = ssl.create_default_context()
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
            result = SendResult(
                ok=200 <= resp.status < 300,
                status_code=resp.status,
            )

            # Parse rate limit headers
            rl_limit = resp.headers.get("X-RateLimit-Limit")
            rl_remaining = resp.headers.get("X-RateLimit-Remaining")
            rl_reset = resp.headers.get("X-RateLimit-Reset")
            if rl_limit or rl_remaining or rl_reset:
                result.rate_limit_info = {
                    "limit": int(rl_limit) if rl_limit else 0,
                    "remaining": int(rl_remaining) if rl_remaining else 0,
                    "reset": int(rl_reset) if rl_reset else 0,
                }

            return result

    except urllib.error.HTTPError as e:
        status = e.code
        result = SendResult(
            ok=False,
            status_code=status,
            is_rate_limited=status == 429,
            is_quota_exceeded=status == 507,
        )

        if status == 429:
            retry_after = e.headers.get("Retry-After") if e.headers else None
            result.retry_after_sec = int(retry_after) if retry_after else 60
            result.error = f"HTTP 429: rate limited (retry after {result.retry_after_sec}s)"
            return result

        if status == 507:
            result.error = "HTTP 507: quota exceeded"
            return result

        err_body = ""
        if e.fp:
            try:
                err_body = e.read(200).decode("utf-8", errors="replace")
            except Exception:
                pass
        result.error = f"HTTP {status}: {err_body[:200]}"
        return result

    except urllib.error.URLError as e:
        return SendResult(
            ok=False,
            status_code=0,
            error=f"Network error: {e.reason}",
        )
    except Exception as e:
        return SendResult(
            ok=False,
            status_code=0,
            error=str(e),
        )


def is_retryable(result: SendResult) -> bool:
    """Determines if a send error is retryable."""
    if result.ok:
        return False
    if result.is_rate_limited:
        return True
    code = result.status_code
    if code in (500, 502, 503, 504):
        return True
    if code == 0:
        return True  # Network error
    return False


def calculate_backoff(
    attempt: int,
    initial_delay_sec: float,
    max_delay_sec: float,
    backoff_factor: float,
) -> float:
    """Calculates exponential backoff delay with 25% jitter. Returns seconds."""
    delay = initial_delay_sec * (backoff_factor ** attempt)
    if delay > max_delay_sec:
        delay = max_delay_sec
    # 25% jitter
    jitter = random.random() * 0.25
    return delay * (1 + jitter)
