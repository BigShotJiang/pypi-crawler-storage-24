"""RSA key exchange handshake with the LogFlux ingestor."""

from __future__ import annotations

import base64
import json
import ssl
import urllib.request
from dataclasses import dataclass

from ..crypto import generate_aes_key, rsa_oaep_encrypt, rsa_public_key_fingerprint
from ..version import VERSION
from .discovery import (
    EndpointInfo,
    get_handshake_init_url,
    get_handshake_complete_url,
)

USER_AGENT = f"logflux-python-sdk/{VERSION}"
MAX_RESPONSE_SIZE = 64 * 1024  # 64 KiB


@dataclass
class HandshakeLimits:
    max_batch_size: int = 0
    max_payload_size: int = 0
    max_request_size: int = 0


@dataclass
class HandshakeResult:
    aes_key: bytes = b""
    key_uuid: str = ""
    server_public_key_pem: str = ""
    server_key_fingerprint: str = ""
    limits: HandshakeLimits | None = None
    supports_multipart: bool = False


def _fetch_json(
    url: str,
    api_key: str,
    body: dict,
    timeout: float,
) -> dict:
    """Posts JSON and returns parsed response. Raises on failure."""
    data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(url, data=data, method="POST")
    req.add_header("Content-Type", "application/json")
    req.add_header("Authorization", f"Bearer {api_key}")
    req.add_header("User-Agent", USER_AGENT)

    ctx = ssl.create_default_context()
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
            if resp.status < 200 or resp.status >= 300:
                err_body = resp.read(200).decode("utf-8", errors="replace")
                raise RuntimeError(
                    f"Handshake failed with status {resp.status}: {err_body}"
                )
            return json.loads(resp.read(MAX_RESPONSE_SIZE))
    except urllib.error.HTTPError as e:
        err_body = e.read(200).decode("utf-8", errors="replace") if e.fp else ""
        raise RuntimeError(
            f"Handshake failed with status {e.code}: {err_body}"
        ) from e
    except urllib.error.URLError as e:
        raise RuntimeError(f"Handshake request failed: {e.reason}") from e


def perform_handshake(
    endpoints: EndpointInfo,
    api_key: str,
    timeout: float = 30.0,
) -> HandshakeResult:
    """Performs the full RSA key exchange handshake.

    1. POST /v1/handshake/init -> get server's RSA public key
    2. Generate AES-256 key
    3. Encrypt AES key with server's RSA public key (OAEP/SHA-256)
    4. POST /v1/handshake/complete -> get key_uuid
    """
    # Step 1: Get server's public key
    init_url = get_handshake_init_url(endpoints)
    init_resp = _fetch_json(init_url, api_key, {"api_key": api_key}, timeout)

    # Parse response (supports both top-level and wrapped format)
    public_key_pem: str = ""
    limits: HandshakeLimits | None = None
    supports_multipart = False

    if init_resp.get("public_key"):
        public_key_pem = init_resp["public_key"]
        supports_multipart = init_resp.get("supports_multipart", False)
        if init_resp.get("limits"):
            lim = init_resp["limits"]
            limits = HandshakeLimits(
                max_batch_size=lim.get("max_batch_size", 0),
                max_payload_size=lim.get("max_payload_size", 0),
                max_request_size=lim.get("max_request_size", 0),
            )
    elif init_resp.get("data", {}).get("public_key"):
        data = init_resp["data"]
        public_key_pem = data["public_key"]
        supports_multipart = data.get("supports_multipart", False)
        if data.get("limits"):
            lim = data["limits"]
            limits = HandshakeLimits(
                max_batch_size=lim.get("max_batch_size", 0),
                max_payload_size=lim.get("max_payload_size", 0),
                max_request_size=lim.get("max_request_size", 0),
            )
    else:
        raise RuntimeError("Handshake init response missing public_key")

    if "-----BEGIN PUBLIC KEY-----" not in public_key_pem:
        raise RuntimeError("Handshake init returned non-PEM public_key")

    # Step 2: Generate AES key
    aes_key = generate_aes_key()

    # Step 3: Encrypt with RSA-OAEP
    encrypted_secret = base64.b64encode(
        rsa_oaep_encrypt(public_key_pem, aes_key)
    ).decode("ascii")

    # Generate fingerprint
    fingerprint = rsa_public_key_fingerprint(public_key_pem)

    # Step 4: Complete handshake
    complete_url = get_handshake_complete_url(endpoints)
    complete_resp = _fetch_json(
        complete_url,
        api_key,
        {"api_key": api_key, "encrypted_secret": encrypted_secret},
        timeout,
    )

    key_uuid: str = ""
    if complete_resp.get("key_uuid"):
        key_uuid = complete_resp["key_uuid"]
    elif complete_resp.get("data", {}).get("key_uuid"):
        key_uuid = complete_resp["data"]["key_uuid"]
    else:
        raise RuntimeError("Handshake complete response missing key_uuid")

    return HandshakeResult(
        aes_key=aes_key,
        key_uuid=key_uuid,
        server_public_key_pem=public_key_pem,
        server_key_fingerprint=fingerprint,
        limits=limits,
        supports_multipart=supports_multipart,
    )
