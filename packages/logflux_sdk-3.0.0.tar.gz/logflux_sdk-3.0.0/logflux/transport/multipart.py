"""Multipart/mixed request body construction."""

from __future__ import annotations

import base64
import os
from dataclasses import dataclass, field
from datetime import datetime

from ..crypto import Encryptor, gzip_compress
from ..types import entry_type_requires_encryption, default_payload_type


@dataclass
class MultipartEntry:
    """A single entry to include in a multipart request."""

    message: str
    timestamp: datetime
    entry_type: int
    payload_type: int = 0
    search_tokens: list[str] | None = None


@dataclass
class MultipartResult:
    """Result of building a multipart body."""

    body: bytes
    content_type: str


def build_multipart_body(
    entries: list[MultipartEntry],
    encryptor: Encryptor,
    key_uuid: str,
    enable_compression: bool,
) -> MultipartResult:
    """Builds a multipart/mixed request body from entries.

    Each part contains encrypted (or compressed) binary payload with metadata headers.
    """
    boundary = _generate_boundary()
    parts: list[bytes] = []

    for entry in entries:
        payload_type = entry.payload_type
        if not payload_type:
            payload_type = default_payload_type(entry.entry_type)

        headers = [
            f"--{boundary}",
            "Content-Type: application/octet-stream",
            f"X-LF-Entry-Type: {entry.entry_type}",
            f"X-LF-Payload-Type: {payload_type}",
        ]

        if entry.timestamp:
            headers.append(f"X-LF-Timestamp: {entry.timestamp.isoformat()}")
        if entry.search_tokens:
            headers.append(f"X-LF-Search-Tokens: {','.join(entry.search_tokens)}")

        if entry_type_requires_encryption(entry.entry_type):
            ciphertext, nonce = encryptor.encrypt_raw(
                entry.message.encode("utf-8"), enable_compression
            )
            headers.append(f"X-LF-Key-ID: {key_uuid}")
            headers.append(f"X-LF-Nonce: {base64.b64encode(nonce).decode('ascii')}")
            part_body = ciphertext
        else:
            # Type 7: compress only
            msg_bytes = entry.message.encode("utf-8")
            if enable_compression:
                part_body = gzip_compress(msg_bytes)
            else:
                part_body = msg_bytes

        header_block = ("\r\n".join(headers) + "\r\n\r\n").encode("utf-8")
        parts.append(header_block + part_body)

    # Closing boundary
    parts.append(f"\r\n--{boundary}--\r\n".encode("utf-8"))

    return MultipartResult(
        body=b"".join(parts),
        content_type=f"multipart/mixed; boundary={boundary}",
    )


def _generate_boundary() -> str:
    return os.urandom(16).hex()
