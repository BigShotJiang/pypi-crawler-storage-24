"""Transport layer: discovery, handshake, multipart, sending."""

from .discovery import (
    discover_endpoints,
    custom_endpoint,
    get_ingest_url,
    get_handshake_init_url,
    get_handshake_complete_url,
    get_health_url,
    extract_region_from_key,
    EndpointInfo,
    API_PATHS,
)
from .handshake import perform_handshake, HandshakeResult, HandshakeLimits
from .multipart import build_multipart_body, MultipartEntry, MultipartResult
from .sender import send_multipart, SendResult, is_retryable, calculate_backoff

__all__ = [
    "discover_endpoints",
    "custom_endpoint",
    "get_ingest_url",
    "get_handshake_init_url",
    "get_handshake_complete_url",
    "get_health_url",
    "extract_region_from_key",
    "EndpointInfo",
    "API_PATHS",
    "perform_handshake",
    "HandshakeResult",
    "HandshakeLimits",
    "build_multipart_body",
    "MultipartEntry",
    "MultipartResult",
    "send_multipart",
    "SendResult",
    "is_retryable",
    "calculate_backoff",
]
