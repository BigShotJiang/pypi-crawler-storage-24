"""Endpoint discovery for the LogFlux ingestor."""

from __future__ import annotations

import json
import ssl
import urllib.request
from dataclasses import dataclass, field
from typing import Any

from ..version import VERSION

MAX_RESPONSE_SIZE = 64 * 1024  # 64 KiB
USER_AGENT = f"logflux-python-sdk/{VERSION}"

VALID_REGION_PREFIXES = ["eu-", "us-", "ca-", "au-", "ap-"]


class API_PATHS:
    ingest = "/v1/ingest"
    batch = "/v1/batch"
    version = "/version"
    health = "/health"
    handshake_base = "/v1/handshake"
    handshake_init = "/init"
    handshake_complete = "/complete"


@dataclass
class EndpointInfo:
    """Discovered endpoint information."""

    base_url: str = ""
    region: str = ""
    capabilities: list[str] | None = None
    metadata: dict[str, str] | None = None


def extract_region_from_key(key: str) -> tuple[str, str]:
    """Extracts the region prefix from an API key. Returns (region, stripped_key)."""
    for prefix in VALID_REGION_PREFIXES:
        if key.startswith(prefix):
            return prefix[:-1], key[len(prefix) :]
    return "", key


def _static_discovery_url(region: str) -> str:
    return f"https://discover.{region}.logflux.io"


def _fetch_json(
    url: str,
    method: str = "GET",
    headers: dict[str, str] | None = None,
    body: bytes | None = None,
    timeout: float = 10.0,
) -> dict[str, Any] | None:
    """Makes an HTTP request and returns parsed JSON, or None on failure."""
    req = urllib.request.Request(url, method=method)
    req.add_header("User-Agent", USER_AGENT)
    req.add_header("Accept", "application/json")
    if headers:
        for k, v in headers.items():
            req.add_header(k, v)
    if body is not None:
        req.data = body

    ctx = ssl.create_default_context()
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=ctx) as resp:
            if resp.status < 200 or resp.status >= 300:
                return None
            data = resp.read(MAX_RESPONSE_SIZE)
            return json.loads(data)
    except Exception:
        return None


def _try_static_discovery(region: str, timeout: float) -> EndpointInfo | None:
    """Tries static discovery for a region."""
    url = _static_discovery_url(region)
    body = _fetch_json(url, timeout=timeout)
    if body is None:
        return None

    endpoints = body.get("endpoints", {})
    ingestor_url = endpoints.get("ingestor_url")
    if not ingestor_url:
        return None

    return EndpointInfo(
        base_url=ingestor_url,
        region=body.get("region", ""),
        metadata={
            "backend_url": endpoints.get("backend_url", ""),
            "dashboard_url": endpoints.get("dashboard_url", ""),
            "discovery": "static",
        },
    )


def _try_authenticated_discovery(
    discovery_url: str, api_key: str, timeout: float
) -> EndpointInfo | None:
    """Tries authenticated discovery with an API key."""
    body = _fetch_json(
        discovery_url,
        headers={"Authorization": f"Bearer {api_key}"},
        timeout=timeout,
    )
    if body is None:
        return None

    # Spec format: { ingestor_url, backend_url, data_residency, ... }
    if body.get("ingestor_url"):
        return EndpointInfo(
            base_url=body["ingestor_url"],
            region=body.get("data_residency", ""),
            capabilities=body.get("features"),
            metadata={
                "backend_url": body.get("backend_url", ""),
                "environment": body.get("environment", ""),
                "discovery_url": discovery_url,
            },
        )

    # Legacy wrapped format: { status, data: { base_url, region, ... } }
    data = body.get("data", {})
    if data.get("base_url"):
        return EndpointInfo(
            base_url=data["base_url"],
            region=data.get("region", ""),
            capabilities=data.get("capabilities"),
        )

    return None


def discover_endpoints(api_key: str, timeout: float = 10.0) -> EndpointInfo:
    """Discovers the ingestor endpoint using the API key's region prefix.

    Tries static discovery first, then authenticated discovery gateways.
    """
    region, _ = extract_region_from_key(api_key)

    # Try static discovery first for region-prefixed keys
    if region:
        try:
            result = _try_static_discovery(region, timeout)
            if result:
                return result
        except Exception:
            pass

    # Authenticated discovery fallback
    urls = [
        "https://api.logflux.io/api/discovery",
        "https://eu.api.logflux.io/api/discovery",
        "https://us.api.logflux.io/api/discovery",
    ]

    last_err: Exception | None = None
    for url in urls:
        try:
            result = _try_authenticated_discovery(url, api_key, timeout)
            if result:
                return result
        except Exception as e:
            last_err = e

    raise RuntimeError(
        f"All discovery URLs failed: {last_err}" if last_err else "All discovery URLs failed"
    )


def custom_endpoint(base_url: str) -> EndpointInfo:
    """Creates an EndpointInfo for a custom (overridden) URL."""
    return EndpointInfo(base_url=base_url)


def get_ingest_url(endpoint: EndpointInfo) -> str:
    """Returns the full ingest URL for an endpoint."""
    return endpoint.base_url + API_PATHS.ingest


def get_handshake_init_url(endpoint: EndpointInfo) -> str:
    """Returns the full handshake init URL."""
    return endpoint.base_url + API_PATHS.handshake_base + API_PATHS.handshake_init


def get_handshake_complete_url(endpoint: EndpointInfo) -> str:
    """Returns the full handshake complete URL."""
    return endpoint.base_url + API_PATHS.handshake_base + API_PATHS.handshake_complete


def get_health_url(endpoint: EndpointInfo) -> str:
    """Returns the full health URL."""
    return endpoint.base_url + API_PATHS.health
