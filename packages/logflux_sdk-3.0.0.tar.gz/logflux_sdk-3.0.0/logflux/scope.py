"""Per-request scope isolation for attributes and breadcrumbs."""

from __future__ import annotations

from .breadcrumb import BreadcrumbRing, Breadcrumb
from datetime import datetime, timezone


class Scope:
    """Provides per-request context isolation.

    Attributes and breadcrumbs set on a scope are merged into every entry
    sent through it, without affecting other scopes or the global state.
    """

    def __init__(self, max_breadcrumbs: int = 100) -> None:
        self._attributes: dict[str, str] = {}
        self.breadcrumbs = BreadcrumbRing(max_breadcrumbs)

    def set_attribute(self, key: str, value: str) -> None:
        """Sets a key-value pair that will be merged into every entry."""
        self._attributes[key] = value

    def set_attributes(self, attrs: dict[str, str]) -> None:
        """Sets multiple attributes at once."""
        self._attributes.update(attrs)

    def set_user(self, user_id: str) -> None:
        """Convenience method for setting user context."""
        self._attributes["user.id"] = user_id

    def set_request(self, method: str, path: str, request_id: str | None = None) -> None:
        """Convenience method for setting request context."""
        self._attributes["http.method"] = method
        self._attributes["http.path"] = path
        if request_id:
            self._attributes["request_id"] = request_id

    def add_breadcrumb(
        self, category: str, message: str, data: dict[str, str] | None = None
    ) -> None:
        """Adds a breadcrumb to this scope's trail."""
        self.breadcrumbs.add(
            Breadcrumb(
                timestamp=datetime.now(timezone.utc).isoformat(),
                category=category,
                message=message,
                data=data,
            )
        )

    def apply_to(self, existing: dict[str, str] | None) -> dict[str, str]:
        """Merges scope attributes into a payload's attributes.

        Scope attributes are defaults -- they don't overwrite explicit ones.
        """
        result = dict(self._attributes)
        if existing:
            result.update(existing)
        return result

    def get_attributes(self) -> dict[str, str]:
        """Returns a copy of current attributes."""
        return dict(self._attributes)
