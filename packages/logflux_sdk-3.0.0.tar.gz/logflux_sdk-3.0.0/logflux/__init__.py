"""LogFlux Python SDK -- end-to-end encrypted log ingestion.

Usage:
    from logflux import LogFlux, Options

    LogFlux.init(Options(api_key="eu-lf_xxx", node="my-app"))
    LogFlux.info("Server started", {"port": "3000"})
    LogFlux.close()

Or via module-level convenience functions:

    import logflux

    logflux.init(Options(api_key="eu-lf_xxx"))
    logflux.info("hello")
    logflux.close()
"""

from __future__ import annotations

import json
import sys
from typing import TYPE_CHECKING

from .breadcrumb import Breadcrumb, BreadcrumbRing
from .client import Client
from .options import Options, load_options_from_env, validate_api_key
from .payload.audit import create_audit_payload
from .payload.context import configure_context
from .payload.error import create_error_payload, create_error_payload_with_message
from .payload.event import create_event_payload
from .payload.log import create_log_payload
from .payload.metric import create_metric_payload
from .payload.telemetry import Reading, create_telemetry_payload
from .payload.trace import create_trace_payload
from .scope import Scope
from .span import (
    TRACE_HEADER,
    Span,
    SpanData,
    TraceContext,
    continue_from_headers as _continue_from_headers,
    generate_span_id,
    generate_trace_id,
    parse_trace_header,
    start_span as _start_span,
)
from .stats import ClientStats
from .types import DropReason, EntryType, LogLevel, PayloadType, level_string
from .version import VERSION

if TYPE_CHECKING:
    pass

_global_client: Client | None = None


class LogFlux:
    """LogFlux SDK -- static API for zero-knowledge encrypted logging."""

    def __init__(self) -> None:
        raise TypeError("LogFlux is a static class and cannot be instantiated")

    # --- Lifecycle ---

    @staticmethod
    def init(options: Options) -> None:
        """Initializes the SDK. Must be called before sending entries."""
        global _global_client
        if _global_client is not None:
            _global_client.close()
        _global_client = Client(options)
        _global_client.initialize()

    @staticmethod
    def init_from_env(node: str = "") -> None:
        """Initializes the SDK from environment variables."""
        options = load_options_from_env(node)
        LogFlux.init(options)

    @staticmethod
    def close() -> None:
        """Closes the SDK, flushing pending entries and zeroing key material."""
        global _global_client
        if _global_client is not None:
            _global_client.close()
            _global_client = None

    @staticmethod
    def flush(timeout: float = 5.0) -> None:
        """Flushes the queue, waiting up to timeout seconds."""
        if _global_client is not None:
            _global_client.flush(timeout)

    # --- Log (Type 1) ---

    @staticmethod
    def debug(message: str, attributes: dict[str, str] | None = None) -> None:
        LogFlux.log(LogLevel.DEBUG, message, attributes)

    @staticmethod
    def info(message: str, attributes: dict[str, str] | None = None) -> None:
        LogFlux.log(LogLevel.INFO, message, attributes)

    @staticmethod
    def notice(message: str, attributes: dict[str, str] | None = None) -> None:
        LogFlux.log(LogLevel.NOTICE, message, attributes)

    @staticmethod
    def warn(message: str, attributes: dict[str, str] | None = None) -> None:
        LogFlux.log(LogLevel.WARNING, message, attributes)

    @staticmethod
    def error(message: str, attributes: dict[str, str] | None = None) -> None:
        LogFlux.log(LogLevel.ERROR, message, attributes)

    @staticmethod
    def critical(message: str, attributes: dict[str, str] | None = None) -> None:
        LogFlux.log(LogLevel.CRITICAL, message, attributes)

    @staticmethod
    def alert(message: str, attributes: dict[str, str] | None = None) -> None:
        LogFlux.log(LogLevel.ALERT, message, attributes)

    @staticmethod
    def emergency(message: str, attributes: dict[str, str] | None = None) -> None:
        LogFlux.log(LogLevel.EMERGENCY, message, attributes)

    @staticmethod
    def fatal(message: str, attributes: dict[str, str] | None = None) -> None:
        """Sends a critical-level log and exits the process."""
        LogFlux.log(LogLevel.CRITICAL, message, attributes)
        LogFlux.close()
        sys.exit(1)

    @staticmethod
    def log(level: int, message: str, attributes: dict[str, str] | None = None) -> None:
        """Sends a log entry (type 1) with the given level and attributes."""
        if _global_client is None:
            return

        # Per-type hook
        payload = create_log_payload(message, level, attributes)
        hook = _global_client._options.before_send_log
        if hook is not None:
            payload = hook(payload)
            if payload is None:
                return

        _global_client.enqueue(json.dumps(payload), level, EntryType.LOG)

        # Auto-breadcrumb for log entries at info level or above
        if level <= LogLevel.INFO:
            _global_client.breadcrumbs.add(
                Breadcrumb(category="log", message=message, level=level_string(level))
            )

    # --- Metric (Type 2) ---

    @staticmethod
    def counter(name: str, value: float, attributes: dict[str, str] | None = None) -> None:
        LogFlux.metric(name, value, "counter", attributes)

    @staticmethod
    def gauge(name: str, value: float, attributes: dict[str, str] | None = None) -> None:
        LogFlux.metric(name, value, "gauge", attributes)

    @staticmethod
    def metric(
        name: str,
        value: float,
        metric_type: str,
        attributes: dict[str, str] | None = None,
    ) -> None:
        """Sends a metric entry (type 2)."""
        if _global_client is None:
            return

        payload = create_metric_payload(name, value, metric_type, attributes)
        hook = _global_client._options.before_send_metric
        if hook is not None:
            payload = hook(payload)
            if payload is None:
                return

        _global_client.enqueue(json.dumps(payload), LogLevel.INFO, EntryType.METRIC)

    # --- Event (Type 4) ---

    @staticmethod
    def event(name: str, attributes: dict[str, str] | None = None) -> None:
        """Sends an event entry (type 4)."""
        if _global_client is None:
            return

        payload = create_event_payload(name, attributes)
        hook = _global_client._options.before_send_event
        if hook is not None:
            payload = hook(payload)
            if payload is None:
                return

        _global_client.enqueue(json.dumps(payload), LogLevel.INFO, EntryType.EVENT)

        # Auto-breadcrumb for events
        _global_client.breadcrumbs.add(
            Breadcrumb(category="event", message=name, data=attributes)
        )

    # --- Audit (Type 5) ---

    @staticmethod
    def audit(
        action: str,
        actor: str,
        resource: str,
        resource_id: str,
        attributes: dict[str, str] | None = None,
    ) -> None:
        """Sends an audit entry (type 5, Object Lock). Never sampled."""
        if _global_client is None:
            return

        payload = create_audit_payload(action, actor, resource, resource_id, attributes)
        hook = _global_client._options.before_send_audit
        if hook is not None:
            payload = hook(payload)
            if payload is None:
                return

        _global_client.enqueue(json.dumps(payload), LogLevel.NOTICE, EntryType.AUDIT)

    # --- Error capture ---

    @staticmethod
    def capture_error(
        error: BaseException, attributes: dict[str, str] | None = None
    ) -> None:
        """Captures an exception with automatic stack trace and breadcrumbs."""
        if _global_client is None:
            return
        crumbs = _global_client.breadcrumbs.snapshot()
        payload = create_error_payload(error, attributes, crumbs)
        hook = _global_client._options.before_send_error
        if hook is not None:
            payload = hook(payload)
            if payload is None:
                return
        _global_client.enqueue(json.dumps(payload), LogLevel.ERROR, EntryType.LOG)

    @staticmethod
    def capture_error_with_message(
        error: BaseException,
        message: str,
        attributes: dict[str, str] | None = None,
    ) -> None:
        """Captures with a custom message (error goes into attributes)."""
        if _global_client is None:
            return
        crumbs = _global_client.breadcrumbs.snapshot()
        payload = create_error_payload_with_message(error, message, attributes, crumbs)
        hook = _global_client._options.before_send_error
        if hook is not None:
            payload = hook(payload)
            if payload is None:
                return
        _global_client.enqueue(json.dumps(payload), LogLevel.ERROR, EntryType.LOG)

    # --- Breadcrumbs ---

    @staticmethod
    def add_breadcrumb(
        category: str, message: str, data: dict[str, str] | None = None
    ) -> None:
        if _global_client is None:
            return
        from datetime import datetime, timezone

        _global_client.breadcrumbs.add(
            Breadcrumb(
                timestamp=datetime.now(timezone.utc).isoformat(),
                category=category,
                message=message,
                data=data,
            )
        )

    @staticmethod
    def clear_breadcrumbs() -> None:
        if _global_client is not None:
            _global_client.breadcrumbs.clear()

    # --- Scopes ---

    @staticmethod
    def with_scope(callback) -> None:
        """Calls callback with a fresh Scope instance."""
        scope = Scope()
        callback(scope)

    # --- Tracing ---

    @staticmethod
    def start_span(operation: str, description: str) -> Span:
        return _start_span(operation, description)

    @staticmethod
    def continue_from_headers(
        headers: dict[str, str], operation: str, description: str
    ) -> Span:
        return _continue_from_headers(headers, operation, description)

    @staticmethod
    def send_span(span: Span) -> None:
        """Ends a span and sends it as a trace entry (type 3)."""
        if _global_client is None:
            return
        data = span.end()
        if data is None:
            return

        payload = create_trace_payload(
            data.trace_id,
            data.span_id,
            data.parent_span_id,
            data.operation,
            data.description,
            data.status,
            data.start_time,
            data.end_time,
            data.duration_ms,
            data.attributes,
        )
        hook = _global_client._options.before_send_trace
        if hook is not None:
            payload = hook(payload)
            if payload is None:
                return
        _global_client.enqueue(json.dumps(payload), LogLevel.INFO, EntryType.TRACE)

    # --- Telemetry ---

    @staticmethod
    def telemetry(
        device_id: str,
        readings: list[Reading],
        attributes: dict[str, str] | None = None,
    ) -> None:
        """Sends a telemetry entry (type 6)."""
        if _global_client is None:
            return

        payload = create_telemetry_payload(device_id, readings, attributes)
        hook = _global_client._options.before_send_telemetry
        if hook is not None:
            payload = hook(payload)
            if payload is None:
                return
        _global_client.enqueue(json.dumps(payload), LogLevel.INFO, EntryType.TELEMETRY)

    # --- Stats ---

    @staticmethod
    def stats() -> ClientStats:
        if _global_client is None:
            return ClientStats()
        return _global_client.get_stats()

    @staticmethod
    def is_active() -> bool:
        return _global_client is not None and _global_client.is_active


# --- Module-level convenience functions ---

def init(options: Options) -> None:
    """Module-level convenience for LogFlux.init()."""
    LogFlux.init(options)


def init_from_env(node: str = "") -> None:
    """Module-level convenience for LogFlux.init_from_env()."""
    LogFlux.init_from_env(node)


def close() -> None:
    """Module-level convenience for LogFlux.close()."""
    LogFlux.close()


def flush(timeout: float = 5.0) -> None:
    """Module-level convenience for LogFlux.flush()."""
    LogFlux.flush(timeout)


def debug(message: str, attributes: dict[str, str] | None = None) -> None:
    LogFlux.debug(message, attributes)


def info(message: str, attributes: dict[str, str] | None = None) -> None:
    LogFlux.info(message, attributes)


def notice(message: str, attributes: dict[str, str] | None = None) -> None:
    LogFlux.notice(message, attributes)


def warn(message: str, attributes: dict[str, str] | None = None) -> None:
    LogFlux.warn(message, attributes)


def error(message: str, attributes: dict[str, str] | None = None) -> None:
    LogFlux.error(message, attributes)


def critical(message: str, attributes: dict[str, str] | None = None) -> None:
    LogFlux.critical(message, attributes)


def alert(message: str, attributes: dict[str, str] | None = None) -> None:
    LogFlux.alert(message, attributes)


def emergency(message: str, attributes: dict[str, str] | None = None) -> None:
    LogFlux.emergency(message, attributes)


def fatal(message: str, attributes: dict[str, str] | None = None) -> None:
    LogFlux.fatal(message, attributes)


def log(level: int, message: str, attributes: dict[str, str] | None = None) -> None:
    LogFlux.log(level, message, attributes)


def counter(name: str, value: float, attributes: dict[str, str] | None = None) -> None:
    LogFlux.counter(name, value, attributes)


def gauge(name: str, value: float, attributes: dict[str, str] | None = None) -> None:
    LogFlux.gauge(name, value, attributes)


def metric(
    name: str,
    value: float,
    metric_type: str,
    attributes: dict[str, str] | None = None,
) -> None:
    LogFlux.metric(name, value, metric_type, attributes)


def event(name: str, attributes: dict[str, str] | None = None) -> None:
    LogFlux.event(name, attributes)


def audit(
    action: str,
    actor: str,
    resource: str,
    resource_id: str,
    attributes: dict[str, str] | None = None,
) -> None:
    LogFlux.audit(action, actor, resource, resource_id, attributes)


def capture_error(
    error: BaseException, attributes: dict[str, str] | None = None
) -> None:
    LogFlux.capture_error(error, attributes)


def capture_error_with_message(
    error: BaseException,
    message: str,
    attributes: dict[str, str] | None = None,
) -> None:
    LogFlux.capture_error_with_message(error, message, attributes)


def add_breadcrumb(
    category: str, message: str, data: dict[str, str] | None = None
) -> None:
    LogFlux.add_breadcrumb(category, message, data)


def clear_breadcrumbs() -> None:
    LogFlux.clear_breadcrumbs()


def with_scope(callback) -> None:
    LogFlux.with_scope(callback)


def start_span(operation: str, description: str) -> Span:
    return LogFlux.start_span(operation, description)


def continue_from_headers(
    headers: dict[str, str], operation: str, description: str
) -> Span:
    return LogFlux.continue_from_headers(headers, operation, description)


def send_span(span: Span) -> None:
    LogFlux.send_span(span)


def telemetry(
    device_id: str,
    readings: list[Reading],
    attributes: dict[str, str] | None = None,
) -> None:
    LogFlux.telemetry(device_id, readings, attributes)


def stats() -> ClientStats:
    return LogFlux.stats()


def is_active() -> bool:
    return LogFlux.is_active()


__all__ = [
    "LogFlux",
    "Options",
    "LogLevel",
    "EntryType",
    "PayloadType",
    "DropReason",
    "ClientStats",
    "Scope",
    "Span",
    "SpanData",
    "TraceContext",
    "Breadcrumb",
    "BreadcrumbRing",
    "Reading",
    "TRACE_HEADER",
    "VERSION",
    "validate_api_key",
    "load_options_from_env",
    "parse_trace_header",
    "generate_trace_id",
    "generate_span_id",
    # Module-level convenience functions
    "init",
    "init_from_env",
    "close",
    "flush",
    "debug",
    "info",
    "notice",
    "warn",
    "error",
    "critical",
    "alert",
    "emergency",
    "fatal",
    "log",
    "counter",
    "gauge",
    "metric",
    "event",
    "audit",
    "capture_error",
    "capture_error_with_message",
    "add_breadcrumb",
    "clear_breadcrumbs",
    "with_scope",
    "start_span",
    "continue_from_headers",
    "send_span",
    "telemetry",
    "stats",
    "is_active",
]
