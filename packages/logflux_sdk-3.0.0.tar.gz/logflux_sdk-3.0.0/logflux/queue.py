"""Thread-safe in-memory FIFO queue with max size eviction."""

from __future__ import annotations

import threading
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime, timezone


@dataclass
class QueueEntry:
    """A single entry waiting to be sent."""

    id: str
    message: str
    timestamp: datetime
    level: int
    entry_type: int
    payload_type: int = 0
    node: str = ""
    labels: dict[str, str] | None = None
    search_tokens: list[str] | None = None
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


class Queue:
    """Thread-safe FIFO queue with bounded capacity.

    Returns False from enqueue() when full or closed (caller counts as overflow).
    """

    def __init__(self, max_size: int = 1000) -> None:
        self._max_size = max(1, max_size)
        self._items: deque[QueueEntry] = deque()
        self._lock = threading.Lock()
        self._not_empty = threading.Condition(self._lock)
        self._closed = False

    def enqueue(self, entry: QueueEntry) -> bool:
        """Adds an entry to the queue. Returns False if full or closed."""
        with self._lock:
            if self._closed or len(self._items) >= self._max_size:
                return False
            self._items.append(entry)
            self._not_empty.notify()
            return True

    def dequeue(self, timeout: float | None = None) -> QueueEntry | None:
        """Removes and returns the oldest entry.

        Blocks up to timeout seconds if the queue is empty.
        Returns None if empty/closed/timed out.
        """
        with self._not_empty:
            while len(self._items) == 0:
                if self._closed:
                    return None
                if not self._not_empty.wait(timeout=timeout):
                    return None
            return self._items.popleft()

    def dequeue_nowait(self) -> QueueEntry | None:
        """Removes and returns the oldest entry without blocking. Returns None if empty."""
        with self._lock:
            if len(self._items) == 0:
                return None
            return self._items.popleft()

    def dequeue_batch(self, n: int) -> list[QueueEntry]:
        """Removes up to n entries at once (non-blocking)."""
        with self._lock:
            count = min(n, len(self._items))
            if count == 0:
                return []
            result = []
            for _ in range(count):
                result.append(self._items.popleft())
            return result

    @property
    def size(self) -> int:
        with self._lock:
            return len(self._items)

    @property
    def capacity(self) -> int:
        return self._max_size

    @property
    def is_full(self) -> bool:
        with self._lock:
            return len(self._items) >= self._max_size

    @property
    def is_empty(self) -> bool:
        with self._lock:
            return len(self._items) == 0

    @property
    def closed(self) -> bool:
        with self._lock:
            return self._closed

    def clear(self) -> None:
        with self._lock:
            self._items.clear()

    def close(self) -> None:
        """Closes the queue. All waiting dequeuers receive None."""
        with self._lock:
            if self._closed:
                return
            self._closed = True
            self._not_empty.notify_all()
