"""Distributed tracing spans."""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone

TRACE_HEADER = "X-LogFlux-Trace"

_HEX_RE = re.compile(r"^[0-9a-f]+$")


@dataclass
class SpanData:
    """Completed span data for sending as a trace entry."""

    trace_id: str
    span_id: str
    parent_span_id: str
    operation: str
    description: str
    status: str
    start_time: datetime
    end_time: datetime
    duration_ms: float
    attributes: dict[str, str]


@dataclass
class TraceContext:
    """Parsed trace context from propagation header."""

    trace_id: str
    span_id: str
    sampled: bool


class Span:
    """Represents an in-flight trace span. Call end() to finish and return the payload."""

    def __init__(
        self,
        trace_id: str,
        span_id: str,
        parent_span_id: str,
        operation: str,
        description: str,
    ) -> None:
        self.trace_id = trace_id
        self.span_id = span_id
        self.parent_span_id = parent_span_id
        self.operation = operation
        self.description = description
        self.start_time = datetime.now(timezone.utc)
        self._status = "ok"
        self._ended = False
        self._end_time: datetime | None = None
        self._attributes: dict[str, str] = {}

    def start_child(self, operation: str, description: str) -> Span:
        """Creates a child span under this span (same trace ID)."""
        return Span(
            self.trace_id,
            generate_span_id(),
            self.span_id,
            operation,
            description,
        )

    def set_attribute(self, key: str, value: str) -> None:
        """Sets a span attribute."""
        self._attributes[key] = value

    def set_attributes(self, attrs: dict[str, str]) -> None:
        """Sets multiple span attributes."""
        self._attributes.update(attrs)

    def set_status(self, status: str) -> None:
        """Sets the span status ('ok' or 'error')."""
        self._status = status

    def set_error(self, err: BaseException) -> None:
        """Marks the span as errored and records the error message."""
        self._status = "error"
        self._attributes["error.message"] = str(err)

    def to_trace_header(self) -> str:
        """Returns the trace header value for propagation."""
        return f"{self.trace_id}-{self.span_id}-1"

    def end(self) -> SpanData | None:
        """Ends the span and returns the span data for sending. Returns None if already ended."""
        if self._ended:
            return None
        self._ended = True
        self._end_time = datetime.now(timezone.utc)
        duration_ms = (self._end_time - self.start_time).total_seconds() * 1000.0

        return SpanData(
            trace_id=self.trace_id,
            span_id=self.span_id,
            parent_span_id=self.parent_span_id,
            operation=self.operation,
            description=self.description,
            status=self._status,
            start_time=self.start_time,
            end_time=self._end_time,
            duration_ms=duration_ms,
            attributes=dict(self._attributes),
        )

    @property
    def status(self) -> str:
        return self._status

    @property
    def ended(self) -> bool:
        return self._ended

    @property
    def attributes(self) -> dict[str, str]:
        return dict(self._attributes)


def generate_trace_id() -> str:
    """Generates a random 32-character hex trace ID."""
    return os.urandom(16).hex()


def generate_span_id() -> str:
    """Generates a random 16-character hex span ID."""
    return os.urandom(8).hex()


def parse_trace_header(header: str) -> TraceContext | None:
    """Parses a trace header value. Returns None if missing or malformed."""
    if not header:
        return None
    parts = header.split("-", 2)
    if len(parts) < 2:
        return None

    trace_id = parts[0]
    span_id = parts[1]

    if len(trace_id) != 32 or len(span_id) != 16:
        return None
    if not _HEX_RE.match(trace_id) or not _HEX_RE.match(span_id):
        return None

    sampled = True
    if len(parts) == 3:
        sampled = parts[2] != "0"

    return TraceContext(trace_id=trace_id, span_id=span_id, sampled=sampled)


def start_span(operation: str, description: str) -> Span:
    """Creates a new root span with a fresh trace ID."""
    return Span(generate_trace_id(), generate_span_id(), "", operation, description)


def continue_from_headers(
    headers: dict[str, str], operation: str, description: str
) -> Span:
    """Creates a child span that continues a trace from incoming headers.

    If no valid trace header is present, starts a new root span.
    """
    header_value = headers.get(TRACE_HEADER, "") or headers.get(
        TRACE_HEADER.lower(), ""
    )
    tc = parse_trace_header(header_value)
    if not tc:
        return start_span(operation, description)
    return Span(tc.trace_id, generate_span_id(), tc.span_id, operation, description)
