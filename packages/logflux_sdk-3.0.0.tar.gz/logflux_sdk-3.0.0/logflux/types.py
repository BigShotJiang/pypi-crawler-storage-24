"""Enums and constants for the LogFlux SDK."""

from __future__ import annotations


class LogLevel:
    """Syslog severity levels (1-8)."""
    EMERGENCY = 1
    ALERT = 2
    CRITICAL = 3
    ERROR = 4
    WARNING = 5
    NOTICE = 6
    INFO = 7
    DEBUG = 8


class EntryType:
    """Entry type constants matching the server protocol."""
    LOG = 1
    METRIC = 2
    TRACE = 3
    EVENT = 4
    AUDIT = 5
    TELEMETRY = 6
    TELEMETRY_MANAGED = 7


class PayloadType:
    """Payload type constants for encryption/compression."""
    AES256_GCM_GZIP_JSON = 1
    GZIP_JSON = 3


class DropReason:
    """Drop reason constants for statistics tracking."""
    QUEUE_OVERFLOW = "queue_overflow"
    NETWORK_ERROR = "network_error"
    SEND_ERROR = "send_error"
    RATE_LIMITED = "ratelimit_backoff"
    QUOTA_EXCEEDED = "quota_exceeded"
    BEFORE_SEND = "before_send"
    VALIDATION_ERROR = "validation_error"


def entry_type_category(entry_type: int) -> str:
    """Returns the pricing category for an entry type."""
    if entry_type in (EntryType.LOG, EntryType.METRIC, EntryType.EVENT):
        return "events"
    if entry_type in (EntryType.TRACE, EntryType.TELEMETRY, EntryType.TELEMETRY_MANAGED):
        return "traces"
    if entry_type == EntryType.AUDIT:
        return "audit"
    return "events"


def entry_type_requires_encryption(entry_type: int) -> bool:
    """Returns True if the entry type requires E2E encryption (types 1-6)."""
    return 1 <= entry_type <= 6


def default_payload_type(entry_type: int) -> int:
    """Returns the default payload type for an entry type."""
    if entry_type == EntryType.TELEMETRY_MANAGED:
        return PayloadType.GZIP_JSON
    return PayloadType.AES256_GCM_GZIP_JSON


def level_string(level: int) -> str:
    """Converts a numeric log level to a human-readable string."""
    if level <= LogLevel.CRITICAL:
        return "error"
    if level == LogLevel.ERROR:
        return "error"
    if level == LogLevel.WARNING:
        return "warning"
    return "info"
