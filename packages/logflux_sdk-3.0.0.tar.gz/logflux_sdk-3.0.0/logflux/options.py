"""SDK configuration options and environment variable loading."""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from typing import Any, Callable


VALID_REGIONS = {"eu", "us", "ca", "au", "ap"}


@dataclass
class Options:
    """Configuration options for the LogFlux SDK."""

    api_key: str = ""
    source: str = ""
    environment: str = ""
    release: str = ""
    node: str = ""
    custom_endpoint_url: str | None = None
    zone: str | None = None
    log_group: str | None = None

    queue_size: int = 1000
    flush_interval: float = 5.0
    batch_size: int = 100
    worker_count: int = 2

    max_retries: int = 3
    initial_delay: float = 1.0
    max_delay: float = 30.0
    backoff_factor: float = 2.0

    http_timeout: float = 30.0
    failsafe: bool = True
    enable_compression: bool = True

    sample_rate: float = 1.0
    max_breadcrumbs: int = 100

    debug: bool = False

    before_send: Callable[..., Any] | None = None
    before_send_log: Callable[..., Any] | None = None
    before_send_error: Callable[..., Any] | None = None
    before_send_metric: Callable[..., Any] | None = None
    before_send_event: Callable[..., Any] | None = None
    before_send_audit: Callable[..., Any] | None = None
    before_send_trace: Callable[..., Any] | None = None
    before_send_telemetry: Callable[..., Any] | None = None


def validate_api_key(key: str) -> None:
    """Validates API key format: <region>-lf_<key>."""
    if not key:
        raise ValueError("API key is required")

    dash_idx = key.find("-")
    if dash_idx == -1:
        raise ValueError("Invalid API key format: must be <region>-lf_<key>")

    region = key[:dash_idx]
    if region not in VALID_REGIONS:
        raise ValueError(
            f'Invalid API key region: "{region}" (expected eu, us, ca, au, or ap)'
        )

    rest = key[dash_idx + 1 :]
    if not rest.startswith("lf_"):
        raise ValueError("Invalid API key format: key must start with lf_")
    if len(rest) <= 3:
        raise ValueError("Invalid API key format: key body is empty")


def extract_region_from_key(key: str) -> tuple[str, str]:
    """Extracts the region prefix from an API key. Returns (region, stripped_key)."""
    valid_prefixes = ["eu-", "us-", "ca-", "au-", "ap-"]
    for prefix in valid_prefixes:
        if key.startswith(prefix):
            return prefix[:-1], key[len(prefix) :]
    return "", key


def load_options_from_env(node: str = "") -> Options:
    """Loads SDK configuration from environment variables."""
    api_key = os.environ.get("LOGFLUX_API_KEY", "")
    if not api_key:
        raise ValueError("LOGFLUX_API_KEY environment variable is required")
    validate_api_key(api_key)

    opts = Options(
        api_key=api_key,
        node=node or os.environ.get("LOGFLUX_NODE", ""),
        environment=os.environ.get("LOGFLUX_ENVIRONMENT", ""),
        log_group=os.environ.get("LOGFLUX_LOG_GROUP"),
        failsafe=True,
        enable_compression=True,
    )

    def int_env(key: str) -> int | None:
        v = os.environ.get(key, "")
        if not v:
            return None
        try:
            return int(v)
        except ValueError:
            return None

    def float_env(key: str) -> float | None:
        v = os.environ.get(key, "")
        if not v:
            return None
        try:
            return float(v)
        except ValueError:
            return None

    def bool_env(key: str) -> bool | None:
        v = os.environ.get(key, "")
        if not v:
            return None
        return v.lower() in ("true", "1")

    v = int_env("LOGFLUX_QUEUE_SIZE")
    if v is not None:
        opts.queue_size = v

    v = int_env("LOGFLUX_BATCH_SIZE")
    if v is not None:
        opts.batch_size = v

    v = int_env("LOGFLUX_MAX_RETRIES")
    if v is not None:
        opts.max_retries = v

    v = int_env("LOGFLUX_WORKER_COUNT")
    if v is not None:
        opts.worker_count = v

    # Flush interval: env is seconds (int)
    vi = int_env("LOGFLUX_FLUSH_INTERVAL")
    if vi is not None:
        opts.flush_interval = float(vi)

    # Initial delay: env is milliseconds (int)
    vi = int_env("LOGFLUX_INITIAL_DELAY")
    if vi is not None:
        opts.initial_delay = vi / 1000.0

    # Max delay: env is seconds (int)
    vi = int_env("LOGFLUX_MAX_DELAY")
    if vi is not None:
        opts.max_delay = float(vi)

    vf = float_env("LOGFLUX_BACKOFF_FACTOR")
    if vf is not None:
        opts.backoff_factor = vf

    # HTTP timeout: env is seconds (int)
    vi = int_env("LOGFLUX_HTTP_TIMEOUT")
    if vi is not None:
        opts.http_timeout = float(vi)

    vb = bool_env("LOGFLUX_FAILSAFE_MODE")
    if vb is not None:
        opts.failsafe = vb

    vb = bool_env("LOGFLUX_ENABLE_COMPRESSION")
    if vb is not None:
        opts.enable_compression = vb

    vb = bool_env("LOGFLUX_DEBUG")
    if vb is not None:
        opts.debug = vb

    return opts
