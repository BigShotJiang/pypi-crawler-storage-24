"""Core orchestrator for the LogFlux SDK."""

from __future__ import annotations

import json
import os
import socket
import threading
import time
from datetime import datetime, timezone

from .breadcrumb import BreadcrumbRing
from .crypto import Encryptor
from .options import Options, validate_api_key
from .payload.context import configure_context
from .queue import Queue, QueueEntry
from .stats import ClientStats, StatsTracker
from .transport.discovery import (
    EndpointInfo,
    custom_endpoint,
    discover_endpoints,
    get_ingest_url,
)
from .transport.handshake import perform_handshake
from .transport.multipart import MultipartEntry, build_multipart_body
from .transport.sender import (
    SendResult,
    calculate_backoff,
    is_retryable,
    send_multipart,
)
from .types import DropReason, EntryType, entry_type_category


class Client:
    """Core orchestrator for the LogFlux SDK.

    Manages queue, workers, handshake, encryption, and multipart sending.
    """

    def __init__(self, options: Options) -> None:
        self._options = options
        self._node = options.node or _get_hostname()
        self._failsafe = options.failsafe
        self._enable_compression = options.enable_compression
        self._debug = options.debug
        self._sample_rate = options.sample_rate if options.sample_rate > 0 else 1.0

        self._queue = Queue(max(1, options.queue_size))
        self._stats = StatsTracker()
        self.breadcrumbs = BreadcrumbRing(max(1, options.max_breadcrumbs))

        self._batch_size = max(1, options.batch_size)
        self._max_retries = max(0, options.max_retries)
        self._initial_delay = max(0.001, options.initial_delay)
        self._max_delay = max(0.001, options.max_delay)
        self._backoff_factor = max(1.0, options.backoff_factor)
        self._http_timeout = max(1.0, options.http_timeout)
        self._flush_interval = max(0.1, options.flush_interval)
        self._worker_count = max(1, options.worker_count)

        self._encryptor: Encryptor | None = None
        self._key_uuid = ""
        self._endpoints: EndpointInfo | None = None

        self._closed = False
        self._workers: list[threading.Thread] = []
        self._flush_event = threading.Event()

        # Rate limit state
        self._rate_limit_until = 0.0
        self._quota_blocked: set[str] = set()
        self._rate_lock = threading.Lock()

        # Configure global payload context
        source = options.source or options.node or self._node
        configure_context(source, options.environment, options.release)

    def initialize(self) -> None:
        """Initializes the client: performs discovery and handshake, then starts workers."""
        validate_api_key(self._options.api_key)

        # Discover endpoints
        if self._options.custom_endpoint_url:
            self._endpoints = custom_endpoint(self._options.custom_endpoint_url)
        else:
            self._endpoints = discover_endpoints(
                self._options.api_key, self._http_timeout
            )

        # Perform handshake
        result = perform_handshake(
            self._endpoints, self._options.api_key, self._http_timeout
        )

        self._encryptor = Encryptor(result.aes_key)
        # Zero source key material
        key_ba = bytearray(result.aes_key)
        for i in range(len(key_ba)):
            key_ba[i] = 0

        self._key_uuid = result.key_uuid
        self._stats.handshake_ok = True

        if self._debug:
            print(
                f"[LogFlux] Connected to {self._endpoints.base_url} "
                f"(key: {result.server_key_fingerprint})"
            )

        # Start background workers
        self._start_workers()

    def enqueue(self, message: str, level: int, entry_type: int) -> None:
        """Enqueues an entry for async sending."""
        if self._closed:
            if self._failsafe:
                return
            raise RuntimeError("Client is closed")

        # Sampling (audit entries are exempt)
        if (
            entry_type != EntryType.AUDIT
            and self._sample_rate < 1.0
            and os.urandom(4)[0] / 255.0 >= self._sample_rate
        ):
            return

        # Quota check
        category = entry_type_category(entry_type)
        with self._rate_lock:
            if category in self._quota_blocked:
                self._stats.record_drop(DropReason.QUOTA_EXCEEDED, 1)
                if self._failsafe:
                    return
                raise RuntimeError(f"Quota exceeded for category: {category}")

        # Global BeforeSend hook
        if self._options.before_send is not None:
            entry = {"message": message, "level": level, "entry_type": entry_type}
            result = self._options.before_send(entry)
            if result is None:
                self._stats.record_drop(DropReason.BEFORE_SEND, 1)
                return

        queue_entry = QueueEntry(
            id=os.urandom(8).hex(),
            message=message,
            timestamp=datetime.now(timezone.utc),
            level=level,
            entry_type=entry_type,
            node=self._node,
        )

        if self._queue.enqueue(queue_entry):
            self._stats.record_queued(1)
        else:
            self._stats.record_drop(DropReason.QUEUE_OVERFLOW, 1)
            if not self._failsafe:
                raise RuntimeError("Queue is full, entry dropped")

    def _start_workers(self) -> None:
        """Starts background daemon threads that drain the queue."""
        for i in range(self._worker_count):
            t = threading.Thread(target=self._run_worker, daemon=True, name=f"logflux-worker-{i}")
            t.start()
            self._workers.append(t)

    def _run_worker(self) -> None:
        """Worker loop: dequeue entries and send in batches."""
        while not self._closed or not self._queue.is_empty:
            # Check rate limit pause
            with self._rate_lock:
                pause_until = self._rate_limit_until
            now = time.monotonic()
            if now < pause_until:
                time.sleep(pause_until - now)
                continue

            # Dequeue with timeout
            entry = self._queue.dequeue(timeout=self._flush_interval)
            if entry is None:
                if self._closed:
                    break
                continue

            # Build batch
            entries = [entry]
            if self._batch_size > 1:
                extra = self._queue.dequeue_batch(self._batch_size - 1)
                entries.extend(extra)

            self._send_batch_with_retry(entries)

            # Signal flush waiters
            if self._queue.is_empty:
                self._flush_event.set()

    def _send_batch_with_retry(self, entries: list[QueueEntry]) -> None:
        """Sends a batch of entries with retry logic."""
        if not self._encryptor or not self._endpoints:
            return

        multipart_entries = [
            MultipartEntry(
                message=e.message,
                timestamp=e.timestamp,
                entry_type=e.entry_type,
                payload_type=e.payload_type,
                search_tokens=e.search_tokens,
            )
            for e in entries
        ]

        try:
            mp_result = build_multipart_body(
                multipart_entries,
                self._encryptor,
                self._key_uuid,
                self._enable_compression,
            )
        except Exception as e:
            self._stats.record_drop(DropReason.SEND_ERROR, len(entries))
            self._stats.record_error(str(e))
            return

        url = get_ingest_url(self._endpoints)
        count = len(entries)

        for attempt in range(self._max_retries + 1):
            result = send_multipart(
                url,
                self._options.api_key,
                mp_result.body,
                mp_result.content_type,
                self._http_timeout,
            )

            if result.ok:
                self._stats.record_sent(count)
                return

            # Handle rate limiting
            if result.is_rate_limited:
                pause_sec = result.retry_after_sec or 60
                with self._rate_lock:
                    self._rate_limit_until = time.monotonic() + pause_sec
                self._stats.record_drop(DropReason.RATE_LIMITED, count)
                self._stats.record_error(result.error)
                return

            # Handle quota exceeded
            if result.is_quota_exceeded:
                category = entry_type_category(entries[0].entry_type)
                with self._rate_lock:
                    self._quota_blocked.add(category)
                self._stats.record_drop(DropReason.QUOTA_EXCEEDED, count)
                self._stats.record_error(result.error)
                return

            if not is_retryable(result) or attempt >= self._max_retries:
                reason = (
                    DropReason.NETWORK_ERROR
                    if result.status_code == 0
                    else DropReason.SEND_ERROR
                )
                self._stats.record_drop(reason, count)
                self._stats.record_error(result.error)
                return

            # Backoff before retry
            delay = calculate_backoff(
                attempt, self._initial_delay, self._max_delay, self._backoff_factor
            )
            time.sleep(delay)

    def flush(self, timeout: float = 10.0) -> None:
        """Flushes the queue, waiting up to timeout seconds for it to drain."""
        if self._queue.is_empty:
            return
        self._flush_event.clear()
        self._flush_event.wait(timeout=timeout)

    def close(self) -> None:
        """Closes the client: flushes queue, stops workers, zeroes key material."""
        if self._closed:
            return
        self._closed = True

        # Try to flush remaining entries
        try:
            self.flush(timeout=10.0)
        except Exception:
            pass

        self._queue.close()

        # Wait for workers to finish
        for t in self._workers:
            t.join(timeout=5.0)
        self._workers.clear()

        # Zero key material
        if self._encryptor:
            self._encryptor.close()
            self._encryptor = None

    def get_stats(self) -> ClientStats:
        """Returns current client statistics."""
        return self._stats.snapshot(self._queue.size, self._queue.capacity)

    @property
    def is_active(self) -> bool:
        """Returns True if the client is initialized and not closed."""
        return not self._closed and self._encryptor is not None


def _get_hostname() -> str:
    try:
        return socket.gethostname()
    except Exception:
        return "unknown"
