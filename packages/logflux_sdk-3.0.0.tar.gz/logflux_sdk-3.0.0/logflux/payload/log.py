"""Log payload (type 1)."""

from __future__ import annotations

from datetime import datetime, timezone

from .context import apply_context


def create_log_payload(
    message: str,
    level: int,
    attributes: dict[str, str] | None = None,
) -> dict:
    """Creates a v2 log payload (type 1)."""
    payload: dict = {
        "v": "2.0",
        "type": "log",
        "source": "",
        "level": level,
        "ts": datetime.now(timezone.utc).isoformat(),
        "message": message,
    }
    if attributes:
        payload["attributes"] = attributes
    apply_context(payload)
    return payload
