"""Global payload context. Auto-applied to all payloads."""

from __future__ import annotations

_global_source = ""
_global_environment = ""
_global_release = ""


def configure_context(source: str, environment: str, release: str) -> None:
    """Sets the global payload context."""
    global _global_source, _global_environment, _global_release
    _global_source = source
    _global_environment = environment
    _global_release = release


def get_source() -> str:
    """Returns the global source."""
    return _global_source


def apply_context(payload: dict) -> None:
    """Applies global context (source, environment, release) to a payload dict."""
    if not payload.get("source") and _global_source:
        payload["source"] = _global_source
    if _global_environment or _global_release:
        meta = payload.get("meta") or {}
        if _global_environment and not meta.get("environment"):
            meta["environment"] = _global_environment
        if _global_release and not meta.get("release"):
            meta["release"] = _global_release
        payload["meta"] = meta
