"""Audit payload (type 5)."""

from __future__ import annotations

from datetime import datetime, timezone

from .context import apply_context


def create_audit_payload(
    action: str,
    actor: str,
    resource: str,
    resource_id: str,
    attributes: dict[str, str] | None = None,
) -> dict:
    """Creates a v2 audit payload (type 5)."""
    payload: dict = {
        "v": "2.0",
        "type": "audit",
        "source": "",
        "level": 6,
        "ts": datetime.now(timezone.utc).isoformat(),
        "action": action,
        "actor": actor,
        "resource": resource,
        "resource_id": resource_id,
        "outcome": "success",
    }
    if attributes:
        payload["attributes"] = attributes
    apply_context(payload)
    return payload
