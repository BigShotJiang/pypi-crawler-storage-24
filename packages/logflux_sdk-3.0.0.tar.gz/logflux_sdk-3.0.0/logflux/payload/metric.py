"""Metric payload (type 2)."""

from __future__ import annotations

from datetime import datetime, timezone

from .context import apply_context


def create_metric_payload(
    name: str,
    value: float,
    metric_type: str,
    attributes: dict[str, str] | None = None,
    unit: str | None = None,
) -> dict:
    """Creates a v2 metric payload (type 2)."""
    payload: dict = {
        "v": "2.0",
        "type": "metric",
        "source": "",
        "level": 7,
        "ts": datetime.now(timezone.utc).isoformat(),
        "name": name,
        "value": value,
        "metric_type": metric_type,
    }
    if unit:
        payload["unit"] = unit
    if attributes:
        payload["attributes"] = attributes
    apply_context(payload)
    return payload
