"""Trace payload (type 3)."""

from __future__ import annotations

from datetime import datetime, timezone

from .context import apply_context


def create_trace_payload(
    trace_id: str,
    span_id: str,
    parent_span_id: str,
    operation: str,
    description: str,
    status: str,
    start_time: datetime,
    end_time: datetime,
    duration_ms: float,
    attributes: dict[str, str] | None = None,
) -> dict:
    """Creates a v2 trace payload (type 3)."""
    payload: dict = {
        "v": "2.0",
        "type": "trace",
        "source": "",
        "level": 7,
        "ts": datetime.now(timezone.utc).isoformat(),
        "trace_id": trace_id,
        "span_id": span_id,
        "operation": operation,
        "description": description,
        "status": status,
        "start_time": start_time.isoformat(),
        "end_time": end_time.isoformat(),
        "duration_ms": duration_ms,
    }
    if parent_span_id:
        payload["parent_span_id"] = parent_span_id
    if attributes:
        payload["attributes"] = attributes
    apply_context(payload)
    return payload
