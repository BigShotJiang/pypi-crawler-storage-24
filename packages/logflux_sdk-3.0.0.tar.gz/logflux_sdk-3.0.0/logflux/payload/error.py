"""Error payload (type 1 with error-specific fields)."""

from __future__ import annotations

import traceback
from datetime import datetime, timezone
from typing import TYPE_CHECKING

from .context import apply_context

if TYPE_CHECKING:
    from ..breadcrumb import Breadcrumb


def create_error_payload(
    error: BaseException,
    attributes: dict[str, str] | None = None,
    breadcrumbs: list[Breadcrumb] | None = None,
) -> dict:
    """Creates a v2 error payload (type 1 with error-specific fields)."""
    payload: dict = {
        "v": "2.0",
        "type": "log",
        "source": "",
        "level": 4,
        "ts": datetime.now(timezone.utc).isoformat(),
        "message": str(error),
        "error_type": type(error).__name__,
        "error_message": str(error),
    }

    stack_frames = _parse_stack_trace(error)
    if stack_frames:
        payload["stack_trace"] = stack_frames

    chain = _unwrap_error_chain(error)
    if len(chain) > 1:
        payload["error_chain"] = chain

    if breadcrumbs:
        payload["breadcrumbs"] = [_breadcrumb_to_dict(b) for b in breadcrumbs]

    if attributes:
        payload["attributes"] = attributes

    apply_context(payload)
    return payload


def create_error_payload_with_message(
    error: BaseException,
    message: str,
    attributes: dict[str, str] | None = None,
    breadcrumbs: list[Breadcrumb] | None = None,
) -> dict:
    """Creates a v2 error payload with a custom message."""
    merged_attrs = dict(attributes) if attributes else {}
    merged_attrs["error"] = str(error)

    payload: dict = {
        "v": "2.0",
        "type": "log",
        "source": "",
        "level": 4,
        "ts": datetime.now(timezone.utc).isoformat(),
        "message": message,
        "error_type": type(error).__name__,
        "error_message": str(error),
    }

    stack_frames = _parse_stack_trace(error)
    if stack_frames:
        payload["stack_trace"] = stack_frames

    chain = _unwrap_error_chain(error)
    if len(chain) > 1:
        payload["error_chain"] = chain

    if breadcrumbs:
        payload["breadcrumbs"] = [_breadcrumb_to_dict(b) for b in breadcrumbs]

    if merged_attrs:
        payload["attributes"] = merged_attrs

    apply_context(payload)
    return payload


def _parse_stack_trace(error: BaseException) -> list[dict]:
    """Parses a Python exception's traceback into structured frames."""
    tb = error.__traceback__
    if tb is None:
        return []

    frames: list[dict] = []
    for frame_summary in traceback.extract_tb(tb):
        frames.append(
            {
                "function": frame_summary.name or "<unknown>",
                "file": frame_summary.filename or "<unknown>",
                "line": frame_summary.lineno or 0,
            }
        )
    return frames[:20]


def _unwrap_error_chain(error: BaseException) -> list[dict]:
    """Unwraps an error chain using __cause__ (up to 10 levels)."""
    chain: list[dict] = []
    current: BaseException | None = error
    for _ in range(10):
        if current is None:
            break
        chain.append(
            {
                "type": type(current).__name__,
                "message": str(current),
            }
        )
        current = current.__cause__
    return chain


def _breadcrumb_to_dict(b: Breadcrumb) -> dict:
    """Converts a Breadcrumb to a JSON-serializable dict."""
    d: dict = {"timestamp": b.timestamp, "message": b.message}
    if b.category:
        d["category"] = b.category
    if b.level:
        d["level"] = b.level
    if b.data:
        d["data"] = b.data
    return d
