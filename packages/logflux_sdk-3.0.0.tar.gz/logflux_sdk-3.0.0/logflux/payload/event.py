"""Event payload (type 4)."""

from __future__ import annotations

from datetime import datetime, timezone

from .context import apply_context


def create_event_payload(
    event_name: str,
    attributes: dict[str, str] | None = None,
) -> dict:
    """Creates a v2 event payload (type 4)."""
    payload: dict = {
        "v": "2.0",
        "type": "event",
        "source": "",
        "level": 7,
        "ts": datetime.now(timezone.utc).isoformat(),
        "event": event_name,
    }
    if attributes:
        payload["attributes"] = attributes
    apply_context(payload)
    return payload
