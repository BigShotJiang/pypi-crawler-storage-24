"""Telemetry payload (type 6 or 7)."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone

from .context import apply_context


@dataclass
class Reading:
    """A single sensor reading."""

    name: str
    value: float
    unit: str = ""


def create_telemetry_payload(
    device_id: str,
    readings: list[Reading],
    attributes: dict[str, str] | None = None,
) -> dict:
    """Creates a v2 telemetry payload (type 6 or 7)."""
    readings_list = []
    for r in readings:
        rd: dict = {"name": r.name, "value": r.value}
        if r.unit:
            rd["unit"] = r.unit
        readings_list.append(rd)

    payload: dict = {
        "v": "2.0",
        "type": "telemetry",
        "source": "",
        "level": 7,
        "ts": datetime.now(timezone.utc).isoformat(),
        "device_id": device_id,
        "readings": readings_list,
    }
    if attributes:
        payload["attributes"] = attributes
    apply_context(payload)
    return payload
