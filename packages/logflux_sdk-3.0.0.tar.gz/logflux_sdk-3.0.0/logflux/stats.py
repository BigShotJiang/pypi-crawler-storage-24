"""Runtime statistics tracking for the SDK."""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from datetime import datetime


@dataclass
class ClientStats:
    """Runtime statistics snapshot."""

    entries_sent: int = 0
    entries_dropped: int = 0
    entries_queued: int = 0
    queue_size: int = 0
    queue_capacity: int = 0
    drop_reasons: dict[str, int] = field(default_factory=dict)
    last_send_error: str = ""
    last_send_time: datetime | None = None
    handshake_ok: bool = False


class StatsTracker:
    """Thread-safe statistics tracker."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._sent = 0
        self._dropped = 0
        self._queued = 0
        self._reasons: dict[str, int] = {}
        self._last_error = ""
        self._last_time: datetime | None = None
        self._handshake_ok = False

    def record_sent(self, count: int) -> None:
        with self._lock:
            self._sent += count
            self._last_time = datetime.now()

    def record_drop(self, reason: str, count: int) -> None:
        with self._lock:
            self._dropped += count
            self._reasons[reason] = self._reasons.get(reason, 0) + count

    def record_queued(self, count: int) -> None:
        with self._lock:
            self._queued += count

    def record_error(self, err: str) -> None:
        with self._lock:
            self._last_error = err

    @property
    def handshake_ok(self) -> bool:
        with self._lock:
            return self._handshake_ok

    @handshake_ok.setter
    def handshake_ok(self, ok: bool) -> None:
        with self._lock:
            self._handshake_ok = ok

    def snapshot(self, queue_size: int, queue_capacity: int) -> ClientStats:
        with self._lock:
            return ClientStats(
                entries_sent=self._sent,
                entries_dropped=self._dropped,
                entries_queued=self._queued,
                queue_size=queue_size,
                queue_capacity=queue_capacity,
                drop_reasons=dict(self._reasons),
                last_send_error=self._last_error,
                last_send_time=self._last_time,
                handshake_ok=self._handshake_ok,
            )
