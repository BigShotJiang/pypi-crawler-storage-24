# purrito

A Python wrapper for CatGt, providing a human-readable interface to generate command-line arguments for the CatGt tool.

## Overview

CatGt is a command-line tool for preprocessing SpikeGLX data from Neuropixels probes. This wrapper simplifies the process of creating CatGt commands by allowing users to specify options in Python.

## Installation

```bash
pip install purrito-catgt-wrapper
```

Import it in Python as:

```python
from purrito import CatGt
```

For development:
```bash
pip install -e .
```

## Usage

### Basic Example

```python
from purrito import CatGt

# Create a CatGt instance with basic parameters
catgt = CatGt(
    basepath="/path/to/data",
    run="g0",
    gate=0,
    trigger=0
)

# Check the command that will be executed
catgt.dry_run()

# Output: CatGt -dir=/path/to/data -run=g0 -g=0 -t=0


# Run catgt
catgt.run()
# Generate the command line string

```

### Advanced Example with Options

```python
from purrito import CatGt

# Create a CatGt instance with preprocessing options
catgt = CatGt(
    basepath="/data/neuropixels",
    run="g0",
    gate=0,
    trigger=0,
    ap=True,           # Process AP band
    lf=True,           # Process LF band
    prb=0,             # Probe index
    prb_fld=True,         # Probe folder
    dest="/data/processed",  # Output destination
)

cmd = catgt.build_command()
print(cmd)
```

### Using with subprocess

```python
import subprocess
from purrito import CatGt

catgt = CatGt(
    basepath="/data/test",
    run="g0",
    gate=0,
    ap=True
)

# Get command as list for subprocess
args = catgt.get_command_args(catgt_path="/usr/local/bin/CatGt")

# Run the command
# subprocess.run(args)
```

## Features

- **Intuitive Python API**: Specify options using Python arguments
- **Flexible Options**: Support for boolean flags, string values, numeric values, and lists
- **Native CatGt Flags**: Uses CatGt's underscore-based option names such as `prb_fld`
- **Path Handling**: Automatically converts relative paths to absolute paths
- **Command Generation**: Generate command strings for direct use or subprocess execution

## API Reference

### CatGt Class

```python
CatGt(basepath, run=None, gate=None, trigger=None, catgt_path="CatGt", **options)
```

**Parameters:**
- `basepath` (str): Base directory path containing the SpikeGLX data
- `run` (str, optional): Run name (e.g., "g0", "g0_t0"). If omitted, it is inferred from `basepath`
- `gate` (int, optional): Gate index
- `trigger` (int, optional): Trigger index
- `catgt_path` (str, optional): Path to the CatGt executable. Defaults to `CatGt`
- `**options`: Additional CatGt options as keyword arguments

**Methods:**
- `build_command(catgt_path="CatGt")`: Build the complete command line string
- `get_command_args(catgt_path="CatGt")`: Get command and arguments as a list for subprocess

## Testing

Run tests using unittest:

```bash
python -m unittest discover tests
```

Or with pytest (if installed):

```bash
pytest tests/
```

## Releasing to PyPI

This package is automatically published to PyPI when a new GitHub release is created. To create a new release:

1. Update the version number in:
   - `purrito/__init__.py`

2. Create a new GitHub release:
   - Go to the repository's [Releases page](https://github.com/eliezyer/purrito/releases)
   - Click "Draft a new release"
   - Create a new tag (e.g., `v0.1.1`)
   - Fill in the release title and description
   - Click "Publish release"

3. The GitHub Actions workflow will automatically:
   - Build the package
   - Run quality checks
   - Publish to PyPI

### PyPI Setup (One-time)

Before the first release, you need to configure PyPI trusted publishing:

1. Go to [PyPI](https://pypi.org/) and create an account if you don't have one
2. Create the `purrito-catgt-wrapper` project on PyPI (or wait for the first upload)
3. Go to your project's settings on PyPI
4. Under "Publishing", add a new "trusted publisher"
5. Configure it with:
   - Owner: `eliezyer`
   - Repository: `purrito`
   - Workflow: `publish-to-pypi.yml`
   - Environment: (leave empty)

This allows GitHub Actions to publish directly to PyPI without needing API tokens.

## License

This project is licensed under the MIT License - see the LICENSE file for details.

Developed in [Rajasethupathy Lab](https://www.rajasethupathylab.com/)
