from __future__ import annotations

import argparse
import time
from pathlib import Path

from slingsync.common import fail
from slingsync.config import (
    load_sync_config,
    resolve_assigned_user_filter,
    resolve_connection_settings,
    resolve_default_config_path,
    resolve_default_state_dir,
)
from slingsync.mapping import (
    build_task_text,
    choose_completed_field,
    deadline_iso_to_epoch_seconds,
    extract_completed_value,
    extract_deadline_date,
    inspect_filter_fields,
    item_matches_filters,
    parse_bool_from_scalar,
)
from slingsync.slack_api import (
    iter_slack_list_items,
    lookup_user_id_by_email,
    mark_slack_item_completed,
    prompt_if_missing_email,
    prompt_if_missing_token,
)
from slingsync.state_store import load_state, save_state
from slingsync.things_api import (
    create_todo_in_things,
    delete_todo_in_things,
    is_todo_completed_in_things,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Pull Slack List items into Things3 and avoid duplicates via a local state file.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )
    slack_group = parser.add_argument_group("Slack")
    mapping_group = parser.add_argument_group("Field Mapping And Filters")
    things_group = parser.add_argument_group("Things Target")
    exec_group = parser.add_argument_group("Execution")

    mapping_group.add_argument(
        "--title-column",
        default="",
        help=(
            "Column key or column_id to use as task title. "
            "If omitted, first text-like field is used."
        ),
    )
    mapping_group.add_argument(
        "--notes-column",
        default="",
        help="Optional column key or column_id to use as task notes.",
    )
    mapping_group.add_argument(
        "--filter-status",
        default="",
        help="Only import items where the status column matches this value (case-insensitive).",
    )
    mapping_group.add_argument(
        "--exclude-status",
        default="",
        help="Exclude items where the status column matches this value (case-insensitive).",
    )
    mapping_group.add_argument(
        "--status-column",
        default="",
        help="Status column key or column_id. If omitted, script tries common keys like status/state.",
    )
    mapping_group.add_argument(
        "--filter-completed",
        default="",
        help=(
            "Only import items where completed is true/false. "
            "Accepted values: true,false,1,0,yes,no,completed,open."
        ),
    )
    mapping_group.add_argument(
        "--completed-column",
        default="",
        help=(
            "Completed column key or column_id. "
            "If omitted, script tries common keys like completed/todo_completed."
        ),
    )
    mapping_group.add_argument(
        "--filter-assigned-user",
        default="",
        help="Only import items assigned to this user name (case-insensitive contains match).",
    )
    mapping_group.add_argument(
        "--filter-assigned-user-id",
        action=argparse.BooleanOptionalAction,
        default=False,
        help=(
            "Enable assignee filtering by Slack user ID loaded from "
            "`assigned_user_id` in the resolved config file. "
            "Fails if enabled but no ID is configured."
        ),
    )
    mapping_group.add_argument(
        "--assigned-column",
        default="",
        help="Assigned-to column key or column_id. If omitted, script tries common assignee keys.",
    )
    mapping_group.add_argument(
        "--deadline-column",
        default="",
        help=(
            "Deadline/due-date column key or column_id. "
            "If omitted, script tries common keys like due_date/deadline."
        ),
    )
    slack_group.add_argument(
        "--lookup-user-id",
        action="store_true",
        help=(
            "Look up a Slack member ID by email (users.lookupByEmail), print it, and exit. "
            "If token/email are missing, the script will prompt for them."
        ),
    )
    slack_group.add_argument(
        "--lookup-email",
        default="",
        help="Email used with --lookup-user-id.",
    )
    slack_group.add_argument(
        "--config",
        default="",
        help=(
            "Path to config JSON. Overrides $SLINGSYNC_CONFIG and default lookup "
            "(./.sync_config.json, then ~/.config/slingsync/config.json)."
        ),
    )
    mapping_group.add_argument(
        "--debug-filter-fields",
        action="store_true",
        help=(
            "Print resolved status/assignee fields for each Slack item. "
            "Useful to inspect how values are encoded."
        ),
    )
    exec_group.add_argument(
        "--state-file",
        default="",
        help=(
            "Path to state JSON. Defaults to ./.sync_state/... when using local config, "
            "or ~/.config/slingsync/state/... when using global config."
        ),
    )
    things_group.add_argument(
        "--target-list",
        default="Inbox",
        help="Things list name, e.g. Inbox/Today/Anytime (ignored if project/area is set).",
    )
    things_group.add_argument(
        "--target-project",
        default="",
        help="Things project name to add tasks to.",
    )
    things_group.add_argument(
        "--target-area",
        default="",
        help="Things area name to add tasks to.",
    )
    slack_group.add_argument(
        "--include-archived",
        action="store_true",
        help="Include archived Slack List items.",
    )
    exec_group.add_argument(
        "--max-items",
        type=int,
        default=0,
        help="Optional cap for number of Slack items to process in one run.",
    )
    exec_group.add_argument(
        "--two-way-sync",
        action=argparse.BooleanOptionalAction,
        default=True,
        help=(
            "When enabled, mark Slack items as completed if their mapped Things to-do "
            "is completed. Requires Slack scope lists:write. "
            "Use --no-two-way-sync to disable."
        ),
    )
    exec_group.add_argument(
        "--delete-missing",
        action=argparse.BooleanOptionalAction,
        default=True,
        help=(
            "Delete previously synced Things to-dos when their Slack item ID no longer "
            "exists in the list response or when the item is marked completed. "
            "Use --no-delete-missing to disable."
        ),
    )
    exec_group.add_argument(
        "--dry-run",
        action="store_true",
        help="Print what would be created without writing to Things3 or state.",
    )
    return parser.parse_args()


def resolve_target(args: argparse.Namespace) -> tuple[str, str]:
    selected = [bool(args.target_project), bool(args.target_area)]
    if sum(selected) > 1:
        fail("Use only one of --target-project or --target-area.")
    if args.target_project:
        return "project", args.target_project
    if args.target_area:
        return "area", args.target_area
    return "list", args.target_list


def resolve_state_path(args: argparse.Namespace, list_id: str) -> Path:
    if args.state_file:
        return Path(args.state_file).expanduser().resolve()

    state_dir = resolve_default_state_dir(args.config_path)
    safe_list_id = list_id.replace("/", "_").replace(" ", "_")
    return (state_dir / f"slack_to_things_{safe_list_id}.json").resolve()


def main() -> None:
    args = parse_args()
    config_path = resolve_default_config_path(args.config)
    args.config_path = config_path
    config = load_sync_config(config_path)
    slack_token, list_id, team_id = resolve_connection_settings(config)
    configured_assigned_user_id = resolve_assigned_user_filter(config)
    args.assigned_user_id_filter = ""
    if args.filter_assigned_user_id:
        if not configured_assigned_user_id:
            fail(
                "Missing assigned user ID for --filter-assigned-user-id. "
                f"Set `assigned_user_id` in {config_path}."
            )
        args.assigned_user_id_filter = configured_assigned_user_id

    if args.lookup_user_id:
        token = prompt_if_missing_token(slack_token)
        email = prompt_if_missing_email(args.lookup_email)
        user_id = lookup_user_id_by_email(token, email)
        print(f"Slack member ID for {email}: {user_id}")
        return

    if not slack_token:
        fail(
            f"Missing Slack token. Set `slack_token` in {config_path}."
        )
    if not list_id:
        fail(
            f"Missing Slack list id. Set `list_id` in {config_path}."
        )
    if args.delete_missing and args.max_items:
        fail("Cannot use --delete-missing with --max-items because partial reads can cause accidental deletes.")
    filter_completed_bool = None
    if args.filter_completed:
        filter_completed_bool = parse_bool_from_scalar(args.filter_completed)
        if filter_completed_bool is None:
            fail(
                "Invalid --filter-completed value. Use one of: true,false,1,0,yes,no,completed,open."
            )

    target_kind, target_name = resolve_target(args)
    state_path = resolve_state_path(args, list_id)
    state = load_state(state_path)
    synced_item_ids = state.setdefault("synced_item_ids", {})
    synced_item_ids_before_run = set(synced_item_ids.keys())

    items = iter_slack_list_items(
        token=slack_token,
        list_id=list_id,
        team_id=team_id,
        include_archived=args.include_archived,
        max_items=args.max_items,
    )
    print(f"Fetched {len(items)} Slack list item(s) from {list_id}.")
    current_item_ids = {str(item.get("id", "")) for item in items if item.get("id")}
    completed_column_id_by_item_id: dict[str, str] = {}
    for item in items:
        item_id = str(item.get("id", "")).strip()
        if not item_id:
            continue
        fields = [f for f in item.get("fields", []) if isinstance(f, dict)]
        completed_field = choose_completed_field(fields, args.completed_column)
        if not completed_field:
            continue
        completed_column_id = str(completed_field.get("column_id") or "").strip()
        if completed_column_id:
            completed_column_id_by_item_id[item_id] = completed_column_id
    completed_item_ids = {
        str(item.get("id", ""))
        for item in items
        if item.get("id") and extract_completed_value(item, args.completed_column) is True
    }

    created = 0
    skipped = 0
    filtered_out = 0
    slack_marked_completed = 0
    things_not_found_for_push = 0
    push_skipped_missing_completed_column = 0
    deleted = 0
    delete_not_found = 0
    for item in items:
        if args.debug_filter_fields:
            print(inspect_filter_fields(item, args))

        if not item_matches_filters(item, args, filter_completed_bool):
            filtered_out += 1
            continue

        item_id = str(item.get("id", ""))
        if not item_id:
            skipped += 1
            continue

        if item_id in synced_item_ids:
            skipped += 1
            continue

        title, notes = build_task_text(item, args.title_column, args.notes_column)
        deadline_iso = extract_deadline_date(item, args.deadline_column) or ""
        deadline_epoch_seconds = deadline_iso_to_epoch_seconds(deadline_iso)
        if args.dry_run:
            if deadline_iso:
                print(f"[dry-run] would create: {title} (deadline={deadline_iso})")
            else:
                print(f"[dry-run] would create: {title} (deadline=<none>)")
            continue

        things_id = create_todo_in_things(
            title,
            notes,
            deadline_epoch_seconds,
            target_kind,
            target_name,
        )
        synced_item_ids[item_id] = {
            "things_id": things_id,
            "title": title,
            "deadline": deadline_iso,
            "synced_at": int(time.time()),
        }
        created += 1
        print(f"Created Things to-do: {title}")

    sync_error: BaseException | None = None
    try:
        if args.two_way_sync:
            candidate_push_item_ids = sorted((synced_item_ids_before_run & current_item_ids) - completed_item_ids)
            for item_id in candidate_push_item_ids:
                existing = synced_item_ids.get(item_id, {})
                things_id = str(existing.get("things_id", "")).strip()
                if not things_id:
                    continue

                things_completed = is_todo_completed_in_things(things_id)
                if things_completed is None:
                    things_not_found_for_push += 1
                    continue
                if not things_completed:
                    continue

                completed_column_id = completed_column_id_by_item_id.get(item_id, "")
                if not completed_column_id:
                    push_skipped_missing_completed_column += 1
                    continue

                if args.dry_run:
                    print(
                        "[dry-run] would mark Slack item completed from Things completion "
                        f"(item_id={item_id}, column_id={completed_column_id})"
                    )
                    completed_item_ids.add(item_id)
                    continue

                mark_slack_item_completed(
                    token=slack_token,
                    list_id=list_id,
                    row_id=item_id,
                    completed_column_id=completed_column_id,
                )
                slack_marked_completed += 1
                completed_item_ids.add(item_id)
                print(f"Marked Slack item completed from Things: {item_id}")

        if args.delete_missing:
            missing_item_ids = synced_item_ids_before_run - current_item_ids
            completed_synced_item_ids = synced_item_ids_before_run & completed_item_ids
            to_delete_item_ids = sorted(missing_item_ids | completed_synced_item_ids)

            for item_id in to_delete_item_ids:
                existing = synced_item_ids.get(item_id, {})
                things_id = str(existing.get("things_id", "")).strip()
                reasons: list[str] = []
                if item_id in missing_item_ids:
                    reasons.append("missing_in_slack")
                if item_id in completed_synced_item_ids:
                    reasons.append("marked_completed")
                reason_text = ",".join(reasons) if reasons else "unspecified"

                if args.dry_run:
                    print(
                        "[dry-run] would delete Things to-do for Slack item "
                        f"{item_id} (reason={reason_text}, things_id={things_id or '<unknown>'})"
                    )
                    continue

                if things_id:
                    delete_result = delete_todo_in_things(things_id)
                    if delete_result == "not_found":
                        delete_not_found += 1
                    else:
                        deleted += 1
                synced_item_ids.pop(item_id, None)
    except BaseException as exc:
        sync_error = exc
    finally:
        if not args.dry_run:
            save_state(state_path, state)

    if sync_error is not None:
        raise sync_error

    print(
        f"Done. created={created}, skipped={skipped}, filtered_out={filtered_out}, "
        f"slack_marked_completed={slack_marked_completed}, "
        f"things_not_found_for_push={things_not_found_for_push}, "
        f"push_skipped_missing_completed_column={push_skipped_missing_completed_column}, "
        f"deleted={deleted}, delete_not_found={delete_not_found}, total_seen={len(items)}, "
        f"state_file={state_path}"
    )
