from __future__ import annotations

import subprocess

from slingsync.common import fail


def create_todo_in_things(
    title: str,
    notes: str,
    deadline_epoch_seconds: str,
    target_kind: str,
    target_name: str,
) -> str:
    applescript = r'''
on run argv
    set todoTitle to item 1 of argv
    set todoNotes to item 2 of argv
    set deadlineEpochSeconds to item 3 of argv
    set targetKind to item 4 of argv
    set targetName to item 5 of argv

    tell application "Things3"
        set todoProps to {name:todoTitle, notes:todoNotes}
        if deadlineEpochSeconds is not "" then
            try
                set deadlineDate to (date "January 1, 1970 00:00:00")
                set deadlineDate to deadlineDate + (deadlineEpochSeconds as integer)
                set todoProps to {name:todoTitle, notes:todoNotes, due date:deadlineDate}
            on error errMsg number errNum
                error "Failed to parse deadline epoch " & deadlineEpochSeconds & ": " & errMsg number errNum
            end try
        end if

        if targetKind is "project" then
            set newToDo to make new to do with properties todoProps at beginning of project targetName
        else if targetKind is "area" then
            set newToDo to make new to do with properties todoProps at beginning of area targetName
        else
            if targetName is "" then
                set newToDo to make new to do with properties todoProps
            else
                set newToDo to make new to do with properties todoProps at beginning of list targetName
            end if
        end if
        return id of newToDo
    end tell
end run
'''
    cmd = [
        "osascript",
        "-e",
        applescript,
        "--",
        title,
        notes,
        deadline_epoch_seconds,
        target_kind,
        target_name,
    ]
    try:
        result = subprocess.run(cmd, check=True, capture_output=True, text=True)
    except subprocess.CalledProcessError as exc:
        stderr = exc.stderr.strip() or exc.stdout.strip()
        fail(f"Things3 AppleScript command failed: {stderr}")

    return result.stdout.strip()


def delete_todo_in_things(things_id: str) -> str:
    applescript = r'''
on run argv
    set todoId to item 1 of argv
    tell application "Things3"
        try
            set targetTodo to to do id todoId
            delete targetTodo
            return "deleted"
        on error errMsg number errNum
            if errNum is -1728 or errNum is -1719 then
                return "not_found"
            else
                error errMsg number errNum
            end if
        end try
    end tell
end run
'''
    cmd = ["osascript", "-e", applescript, "--", things_id]
    try:
        result = subprocess.run(cmd, check=True, capture_output=True, text=True)
    except subprocess.CalledProcessError as exc:
        stderr = exc.stderr.strip() or exc.stdout.strip()
        fail(f"Things3 AppleScript delete failed: {stderr}")
    return result.stdout.strip()


def is_todo_completed_in_things(things_id: str) -> bool | None:
    applescript = r'''
on run argv
    set todoId to item 1 of argv
    tell application "Things3"
        try
            set targetTodo to to do id todoId
            try
                set todoStatus to (status of targetTodo as string)
                return todoStatus
            on error
                return "open"
            end try
        on error errMsg number errNum
            if errNum is -1728 or errNum is -1719 then
                return "not_found"
            else
                error errMsg number errNum
            end if
        end try
    end tell
end run
'''
    cmd = ["osascript", "-e", applescript, "--", things_id]
    try:
        result = subprocess.run(cmd, check=True, capture_output=True, text=True)
    except subprocess.CalledProcessError as exc:
        stderr = exc.stderr.strip() or exc.stdout.strip()
        fail(f"Things3 AppleScript completion check failed: {stderr}")

    status = result.stdout.strip().lower()
    if status == "not_found":
        return None
    return "completed" in status
