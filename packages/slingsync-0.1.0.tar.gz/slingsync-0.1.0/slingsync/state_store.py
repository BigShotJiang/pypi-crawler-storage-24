from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from slingsync.common import fail


def load_state(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {"synced_item_ids": {}}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        fail(f"State file is not valid JSON: {path} ({exc})")


def save_state(path: Path, state: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp_path = path.with_suffix(path.suffix + ".tmp")
    temp_path.write_text(json.dumps(state, indent=2, sort_keys=True), encoding="utf-8")
    temp_path.replace(path)
