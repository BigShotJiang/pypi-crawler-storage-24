from __future__ import annotations

import argparse
import json
import re
import time
from datetime import datetime, timezone
from typing import Any

STATUS_FIELD_KEYS = {"status", "state"}
ASSIGNED_FIELD_KEYS = {
    "assignee",
    "assignees",
    "assigned",
    "assigned to",
    "assigned_to",
    "owner",
    "owners",
    "user",
    "users",
}
COMPLETED_FIELD_KEYS = {
    "completed",
    "complete",
    "todo_completed",
    "is_completed",
    "done",
}
DEADLINE_FIELD_KEYS = {
    "deadline",
    "due",
    "due date",
    "due_date",
    "duedate",
    "todo_due_date",
}
TITLE_PREFERRED_KEYS = {"title", "name", "task", "todo", "to-do", "rich_text_notes"}
BOOL_TRUE_TOKENS = {"true", "1", "yes", "y", "completed", "done", "checked"}
BOOL_FALSE_TOKENS = {"false", "0", "no", "n", "open", "incomplete", "not completed", "unchecked"}


def flatten_rich_text(node: Any) -> str:
    if isinstance(node, list):
        return "".join(flatten_rich_text(part) for part in node)
    if not isinstance(node, dict):
        return ""

    node_type = node.get("type", "")
    if node_type == "text":
        return str(node.get("text", ""))
    if node_type == "emoji":
        name = str(node.get("name", ""))
        return f":{name}:" if name else ""
    if node_type == "link":
        return str(node.get("url") or node.get("text") or "")
    if node_type in {
        "rich_text_quote",
        "rich_text_section",
        "rich_text_preformatted",
        "rich_text_list",
        "rich_text_list_item",
        "rich_text",
    }:
        return flatten_rich_text(node.get("elements", []))

    if "elements" in node:
        return flatten_rich_text(node.get("elements", []))

    return ""


def stringify_field_value(field: dict[str, Any]) -> str:
    if isinstance(field.get("text"), str) and field["text"].strip():
        return field["text"].strip()

    if "rich_text" in field:
        rich = flatten_rich_text(field.get("rich_text"))
        if rich.strip():
            return rich.strip()

    value = field.get("value")
    if isinstance(value, str):
        raw = value.strip()
        if raw:
            try:
                decoded = json.loads(raw)
            except json.JSONDecodeError:
                return raw
            flattened = flatten_rich_text(decoded)
            return flattened.strip() or raw
    if isinstance(value, (int, float, bool)):
        return str(value)

    for key in (
        "number",
        "select",
        "date",
        "user",
        "channel",
        "attachment",
        "email",
        "phone",
        "rating",
        "timestamp",
    ):
        values = field.get(key)
        if isinstance(values, list) and values:
            return ", ".join(str(v) for v in values)

    links = field.get("link")
    if isinstance(links, list) and links:
        url_values = []
        for link in links:
            if isinstance(link, dict):
                if link.get("displayName"):
                    url_values.append(str(link["displayName"]))
                elif link.get("originalUrl"):
                    url_values.append(str(link["originalUrl"]))
        if url_values:
            return ", ".join(url_values)

    return ""


def field_matches(field: dict[str, Any], column_hint: str) -> bool:
    hint = column_hint.strip().lower()
    if not hint:
        return False
    candidates = [field.get("column_id"), field.get("key")]
    return any(str(c).lower() == hint for c in candidates if c)


def find_field(fields: list[dict[str, Any]], column_hint: str) -> dict[str, Any] | None:
    for field in fields:
        if field_matches(field, column_hint):
            return field
    return None


def normalize_text(value: Any) -> str:
    return " ".join(str(value).strip().lower().split())


def choose_field_by_keys(fields: list[dict[str, Any]], keys: set[str]) -> dict[str, Any] | None:
    for field in fields:
        key = normalize_text(field.get("key", ""))
        if key in keys:
            return field
    for field in fields:
        key = normalize_text(field.get("key", ""))
        if any(k in key for k in keys):
            return field
    return None


def collect_string_values(node: Any, out: set[str]) -> None:
    if isinstance(node, str):
        stripped = node.strip()
        if stripped:
            out.add(stripped)
        return
    if isinstance(node, (int, float, bool)):
        out.add(str(node))
        return
    if isinstance(node, list):
        for item in node:
            collect_string_values(item, out)
        return
    if isinstance(node, dict):
        for value in node.values():
            collect_string_values(value, out)


def extract_field_tokens(field: dict[str, Any]) -> set[str]:
    raw_values: set[str] = set()
    text_value = stringify_field_value(field)
    if text_value:
        raw_values.add(text_value)
    collect_string_values(field, raw_values)
    return {normalize_text(v) for v in raw_values if normalize_text(v)}


def collect_scalar_values(node: Any, out: list[Any]) -> None:
    if isinstance(node, (str, int, float, bool)):
        out.append(node)
        return
    if isinstance(node, list):
        for item in node:
            collect_scalar_values(item, out)
        return
    if isinstance(node, dict):
        for value in node.values():
            collect_scalar_values(value, out)


def parse_date_from_scalar(value: Any) -> str | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        ts = int(value)
        if ts > 10_000_000_000:
            ts //= 1000
        if 100_000_000 <= ts <= 4_102_444_800:
            return datetime.fromtimestamp(ts, tz=timezone.utc).date().isoformat()
        return None
    if not isinstance(value, str):
        return None

    raw = value.strip()
    if not raw:
        return None

    match = re.search(r"(\d{4}-\d{2}-\d{2})", raw)
    if match:
        try:
            return datetime.strptime(match.group(1), "%Y-%m-%d").date().isoformat()
        except ValueError:
            pass

    if raw.isdigit():
        return parse_date_from_scalar(int(raw))

    for fmt in (
        "%Y/%m/%d",
        "%m/%d/%Y",
        "%d/%m/%Y",
        "%b %d, %Y",
        "%B %d, %Y",
    ):
        try:
            return datetime.strptime(raw, fmt).date().isoformat()
        except ValueError:
            continue

    return None


def parse_bool_from_scalar(value: Any) -> bool | None:
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        if int(value) == 1:
            return True
        if int(value) == 0:
            return False
        return None
    if isinstance(value, str):
        normalized = normalize_text(value)
        if normalized in BOOL_TRUE_TOKENS:
            return True
        if normalized in BOOL_FALSE_TOKENS:
            return False
        return None
    if isinstance(value, list):
        for item in value:
            parsed = parse_bool_from_scalar(item)
            if parsed is not None:
                return parsed
        return None
    if isinstance(value, dict):
        for key in ("value", "text", "completed", "is_completed", "checked"):
            if key in value:
                parsed = parse_bool_from_scalar(value[key])
                if parsed is not None:
                    return parsed
    return None


def choose_completed_field(fields: list[dict[str, Any]], completed_column: str) -> dict[str, Any] | None:
    if completed_column:
        return find_field(fields, completed_column)
    return choose_field_by_keys(fields, COMPLETED_FIELD_KEYS)


def extract_completed_value(item: dict[str, Any], completed_column: str) -> bool | None:
    fields = [f for f in item.get("fields", []) if isinstance(f, dict)]
    completed_field = choose_completed_field(fields, completed_column)
    if not completed_field:
        return None

    candidates: list[Any] = []
    for key in ("value", "text", "number", "rich_text"):
        if key in completed_field:
            candidates.append(completed_field.get(key))
    if not candidates:
        collect_scalar_values(completed_field, candidates)

    for candidate in candidates:
        parsed = parse_bool_from_scalar(candidate)
        if parsed is not None:
            return parsed

    tokens = extract_field_tokens(completed_field)
    if any(token in {"true", "completed", "done", "checked", "1"} for token in tokens):
        return True
    if any(token in {"false", "open", "incomplete", "unchecked", "0"} for token in tokens):
        return False

    return None


def choose_deadline_field(fields: list[dict[str, Any]], deadline_column: str) -> dict[str, Any] | None:
    if deadline_column:
        return find_field(fields, deadline_column)
    return choose_field_by_keys(fields, DEADLINE_FIELD_KEYS)


def extract_deadline_date(item: dict[str, Any], deadline_column: str) -> str | None:
    fields = [f for f in item.get("fields", []) if isinstance(f, dict)]
    deadline_field = choose_deadline_field(fields, deadline_column)
    if not deadline_field:
        return None

    candidates: list[Any] = []
    for key in ("text", "value", "date", "timestamp", "number", "rich_text"):
        if key in deadline_field:
            candidates.append(deadline_field.get(key))
    text_value = stringify_field_value(deadline_field)
    if text_value:
        candidates.append(text_value)
    if not candidates:
        collect_scalar_values(deadline_field, candidates)

    seen: set[str] = set()
    for candidate in candidates:
        key = repr(candidate)
        if key in seen:
            continue
        seen.add(key)
        parsed = parse_date_from_scalar(candidate)
        if parsed:
            return parsed

    return None


def deadline_iso_to_epoch_seconds(deadline_iso: str) -> str:
    if not deadline_iso:
        return ""
    try:
        parsed = datetime.strptime(deadline_iso, "%Y-%m-%d")
    except ValueError:
        return ""

    # Use local-noon to avoid day shifts around timezone/DST edges.
    local_noon = parsed.replace(hour=12, minute=0, second=0, microsecond=0)
    return str(int(time.mktime(local_noon.timetuple())))


def status_matches(actual: str, expected: str) -> bool:
    actual_norm = normalize_text(actual)
    expected_norm = normalize_text(expected)
    if not expected_norm:
        return True
    if actual_norm == expected_norm:
        return True
    return actual_norm.startswith(expected_norm + " ")


def item_matches_filters(
    item: dict[str, Any],
    args: argparse.Namespace,
    filter_completed_bool: bool | None,
) -> bool:
    fields = [f for f in item.get("fields", []) if isinstance(f, dict)]
    assigned_user_id_filter = str(getattr(args, "assigned_user_id_filter", "")).strip()

    if filter_completed_bool is not None:
        completed_value = extract_completed_value(item, args.completed_column)
        if completed_value is None:
            return False
        if completed_value != filter_completed_bool:
            return False

    if args.filter_status or args.exclude_status:
        status_field = (
            find_field(fields, args.status_column)
            if args.status_column
            else choose_field_by_keys(fields, STATUS_FIELD_KEYS)
        )
        if not status_field:
            return False
        status_value = stringify_field_value(status_field)
        if args.filter_status and not status_matches(status_value, args.filter_status):
            return False
        if args.exclude_status and status_matches(status_value, args.exclude_status):
            return False

    if args.filter_assigned_user or assigned_user_id_filter:
        assigned_field = (
            find_field(fields, args.assigned_column)
            if args.assigned_column
            else choose_field_by_keys(fields, ASSIGNED_FIELD_KEYS)
        )
        if not assigned_field:
            return False

        tokens = extract_field_tokens(assigned_field)
        if args.filter_assigned_user:
            expected_user = normalize_text(args.filter_assigned_user)
            if not any(expected_user in token for token in tokens):
                return False
        if assigned_user_id_filter:
            expected_id = normalize_text(assigned_user_id_filter)
            if expected_id not in tokens:
                return False

    return True


def inspect_filter_fields(item: dict[str, Any], args: argparse.Namespace) -> str:
    fields = [f for f in item.get("fields", []) if isinstance(f, dict)]

    status_field = (
        find_field(fields, args.status_column)
        if args.status_column
        else choose_field_by_keys(fields, STATUS_FIELD_KEYS)
    )
    assigned_field = (
        find_field(fields, args.assigned_column)
        if args.assigned_column
        else choose_field_by_keys(fields, ASSIGNED_FIELD_KEYS)
    )
    completed_field = (
        find_field(fields, args.completed_column)
        if args.completed_column
        else choose_completed_field(fields, "")
    )

    status_key = str(status_field.get("key", "")) if status_field else "<none>"
    status_column_id = str(status_field.get("column_id", "")) if status_field else "<none>"
    status_value = stringify_field_value(status_field) if status_field else ""

    assigned_key = str(assigned_field.get("key", "")) if assigned_field else "<none>"
    assigned_column_id = str(assigned_field.get("column_id", "")) if assigned_field else "<none>"
    assigned_value = stringify_field_value(assigned_field) if assigned_field else ""
    assigned_tokens = sorted(extract_field_tokens(assigned_field)) if assigned_field else []

    completed_key = str(completed_field.get("key", "")) if completed_field else "<none>"
    completed_column_id = str(completed_field.get("column_id", "")) if completed_field else "<none>"
    completed_value = stringify_field_value(completed_field) if completed_field else ""
    completed_bool = extract_completed_value(item, args.completed_column)

    lines = [
        f"item_id={item.get('id', '')}",
        f"  status: key={status_key!r}, column_id={status_column_id!r}, value={status_value!r}",
        f"  assigned: key={assigned_key!r}, column_id={assigned_column_id!r}, value={assigned_value!r}",
        f"  assigned_tokens={assigned_tokens}",
        f"  completed: key={completed_key!r}, column_id={completed_column_id!r}, value={completed_value!r}, parsed={completed_bool!r}",
    ]
    return "\n".join(lines)


def choose_title_field(fields: list[dict[str, Any]], title_column: str) -> dict[str, Any] | None:
    if title_column:
        return find_field(fields, title_column)

    for field in fields:
        key = str(field.get("key", "")).strip().lower()
        if key in TITLE_PREFERRED_KEYS and stringify_field_value(field):
            return field

    for field in fields:
        if stringify_field_value(field):
            return field

    return None


def build_task_text(
    item: dict[str, Any],
    title_column: str,
    notes_column: str,
) -> tuple[str, str]:
    fields = [f for f in item.get("fields", []) if isinstance(f, dict)]
    title_field = choose_title_field(fields, title_column)

    title = stringify_field_value(title_field) if title_field else ""
    if not title:
        title = f"Slack item {item.get('id', 'unknown')}"

    notes_parts: list[str] = []
    if notes_column:
        notes_field = find_field(fields, notes_column)
        if notes_field:
            notes_value = stringify_field_value(notes_field)
            if notes_value:
                notes_parts.append(notes_value)

    source_meta = [
        f"Imported from Slack list {item.get('list_id', '')}",
        f"Slack item id: {item.get('id', '')}",
    ]
    if item.get("updated_timestamp"):
        source_meta.append(f"Slack updated timestamp: {item['updated_timestamp']}")
    notes_parts.append("\n".join(source_meta))

    return title.strip(), "\n\n".join(part for part in notes_parts if part).strip()
