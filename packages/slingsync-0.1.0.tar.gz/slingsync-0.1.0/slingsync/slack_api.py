from __future__ import annotations

import getpass
import json
import time
from typing import Any
from urllib import error, request
from urllib.parse import urlencode

from slingsync.common import fail

SLACK_API_BASE = "https://slack.com/api"


class SlackApiMethodError(Exception):
    def __init__(self, method: str, response: dict[str, Any]):
        self.method = method
        self.response = response
        super().__init__(slack_api_error(method, response))


def slack_api_error(method: str, data: dict[str, Any]) -> str:
    needed = data.get("needed")
    provided = data.get("provided")
    details = f"Slack API error on {method}: {data.get('error', 'unknown_error')}"
    if needed or provided:
        details += f" (needed={needed}, provided={provided})"
    metadata = data.get("response_metadata", {})
    messages = metadata.get("messages")
    warnings = metadata.get("warnings")
    extra = []
    if isinstance(messages, list) and messages:
        extra.append("messages=" + "; ".join(str(m) for m in messages))
    if isinstance(warnings, list) and warnings:
        extra.append("warnings=" + ", ".join(str(w) for w in warnings))
    if extra:
        details += " [" + " | ".join(extra) + "]"
    return details


def slack_api_request(
    token: str,
    method: str,
    http_method: str,
    *,
    payload: dict[str, Any] | None = None,
    params: dict[str, Any] | None = None,
) -> dict[str, Any]:
    url = f"{SLACK_API_BASE}/{method}"
    headers = {"Authorization": f"Bearer {token}"}
    body: bytes | None = None

    if params:
        query = urlencode(params)
        if query:
            url = f"{url}?{query}"
    if payload is not None:
        body = json.dumps(payload).encode("utf-8")
        headers["Content-Type"] = "application/json; charset=utf-8"

    while True:
        req = request.Request(
            url,
            data=body,
            method=http_method,
            headers=headers,
        )
        try:
            with request.urlopen(req, timeout=30) as resp:
                response_body = resp.read().decode("utf-8")
        except error.HTTPError as exc:
            if exc.code == 429:
                retry_after = int(exc.headers.get("Retry-After", "1"))
                time.sleep(retry_after + 1)
                continue
            details = exc.read().decode("utf-8", errors="replace")
            fail(f"Slack HTTP error {exc.code}: {details}")
        except error.URLError as exc:
            fail(f"Slack request failed: {exc}")

        data = json.loads(response_body)
        if data.get("ok"):
            return data

        if data.get("error") == "ratelimited":
            time.sleep(2)
            continue

        raise SlackApiMethodError(method, data)


def slack_api_call(token: str, method: str, payload: dict[str, Any]) -> dict[str, Any]:
    try:
        return slack_api_request(token, method, "POST", payload=payload)
    except SlackApiMethodError as exc:
        fail(str(exc))


def slack_api_get(token: str, method: str, params: dict[str, Any]) -> dict[str, Any]:
    try:
        return slack_api_request(token, method, "GET", params=params)
    except SlackApiMethodError as exc:
        fail(str(exc))


def prompt_if_missing_token(token: str) -> str:
    cleaned = token.strip()
    if cleaned:
        return cleaned
    entered = getpass.getpass("Enter Slack token: ").strip()
    if not entered:
        fail("Missing Slack token.")
    return entered


def prompt_if_missing_email(email: str) -> str:
    cleaned = email.strip()
    if cleaned:
        return cleaned
    entered = input("Enter email to look up Slack member ID: ").strip()
    if not entered:
        fail("Missing email for lookup.")
    return entered


def lookup_user_id_by_email(token: str, email: str) -> str:
    data = slack_api_get(token, "users.lookupByEmail", {"email": email})
    user_id = str(data.get("user", {}).get("id", "")).strip()
    if not user_id:
        fail("Lookup succeeded but no user ID was returned.")
    return user_id


def iter_slack_list_items(
    token: str,
    list_id: str,
    team_id: str,
    include_archived: bool,
    max_items: int,
) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    cursor = ""

    while True:
        payload: dict[str, Any] = {"list_id": list_id, "limit": 200}
        if team_id:
            payload["team_id"] = team_id
        if cursor:
            payload["cursor"] = cursor
        if include_archived:
            payload["archived"] = True

        data = slack_api_call(token, "slackLists.items.list", payload)
        batch = data.get("items", [])

        for item in batch:
            items.append(item)
            if max_items and len(items) >= max_items:
                return items

        cursor = data.get("response_metadata", {}).get("next_cursor", "")
        if not cursor:
            return items


def mark_slack_item_completed(
    token: str,
    list_id: str,
    row_id: str,
    completed_column_id: str,
) -> None:
    # Slack List checkbox columns accept the "checkbox" cell key.
    # Keep a couple of scalar variants for compatibility.
    candidates: list[dict[str, Any]] = [
        {"checkbox": True},
        {"checkbox": "true"},
        {"checkbox": 1},
    ]
    last_error: SlackApiMethodError | None = None

    for cell_value in candidates:
        payload = {
            "list_id": list_id,
            "cells": [
                {
                    "row_id": row_id,
                    "column_id": completed_column_id,
                    **cell_value,
                }
            ],
        }
        try:
            slack_api_request(token, "slackLists.items.update", "POST", payload=payload)
            return
        except SlackApiMethodError as exc:
            last_error = exc
            error_code = str(exc.response.get("error", ""))
            if error_code in {"invalid_arguments", "invalid_input_type"}:
                continue
            fail(str(exc))

    if last_error is not None:
        fail(str(last_error))
    fail("Slack API error on slackLists.items.update: unknown error")
