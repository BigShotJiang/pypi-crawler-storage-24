from __future__ import annotations

import json
import os
from pathlib import Path

from slingsync.common import fail

APP_NAME = "slingsync"
DEFAULT_CONFIG_FILE = ".sync_config.json"
DEFAULT_GLOBAL_CONFIG_ENV_VAR = "SLINGSYNC_CONFIG"


def resolve_global_config_path() -> Path:
    xdg_config_home = os.getenv("XDG_CONFIG_HOME", "").strip()
    if xdg_config_home:
        base_dir = Path(xdg_config_home).expanduser()
    else:
        base_dir = Path.home() / ".config"
    return (base_dir / APP_NAME / "config.json").resolve()


def resolve_default_config_path(config_path_override: str = "") -> Path:
    if config_path_override.strip():
        return Path(config_path_override).expanduser().resolve()

    env_path = os.getenv(DEFAULT_GLOBAL_CONFIG_ENV_VAR, "").strip()
    if env_path:
        return Path(env_path).expanduser().resolve()

    local_path = (Path.cwd() / DEFAULT_CONFIG_FILE).resolve()
    if local_path.exists():
        return local_path

    global_path = resolve_global_config_path()
    if global_path.exists():
        return global_path
    return global_path


def resolve_default_state_dir(config_path: Path) -> Path:
    local_config_path = (Path.cwd() / DEFAULT_CONFIG_FILE).resolve()
    if config_path == local_config_path:
        return (Path.cwd() / ".sync_state").resolve()
    return (config_path.parent / "state").resolve()


def load_sync_config(path: Path) -> dict[str, str]:
    if not path.exists():
        return {}
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        fail(f"Config file is not valid JSON: {path} ({exc})")
    if not isinstance(raw, dict):
        fail(f"Config file must be a JSON object: {path}")

    aliases = {
        "slack_token": ("slack_token", "token"),
        "list_id": ("list_id", "slack_list_id"),
        "team_id": ("team_id", "slack_team_id"),
        "filter_assigned_user_id": (
            "filter_assigned_user_id",
            "assigned_user_id",
            "slack_filter_assigned_user_id",
        ),
    }
    normalized: dict[str, str] = {}
    for key, candidates in aliases.items():
        for candidate in candidates:
            value = raw.get(candidate)
            if isinstance(value, str) and value.strip():
                normalized[key] = value.strip()
                break
    return normalized


def resolve_connection_settings(config: dict[str, str]) -> tuple[str, str, str]:
    slack_token = config.get("slack_token", "")
    list_id = config.get("list_id", "")
    team_id = config.get("team_id", "")
    return slack_token, list_id, team_id


def resolve_assigned_user_filter(config: dict[str, str]) -> str:
    return config.get("filter_assigned_user_id", "")
