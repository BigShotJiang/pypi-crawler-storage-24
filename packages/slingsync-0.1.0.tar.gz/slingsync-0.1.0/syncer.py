#!/usr/bin/env python3
"""CLI entrypoint for syncing Slack List items into Things3."""

from slingsync.cli import main


if __name__ == "__main__":
    main()
