"""
Defines the public API for the CLI application module.
"""

__all__ = (
    "application",
    "error",
    "info",
    "warning",
    "comment",
    "prompt",
    "confirm",
    "AppStyles",
    "Group",
)

from ._app import (
    AppStyles,
    Group,
    application,
    comment,
    confirm,
    error,
    info,
    prompt,
    warning,
)
