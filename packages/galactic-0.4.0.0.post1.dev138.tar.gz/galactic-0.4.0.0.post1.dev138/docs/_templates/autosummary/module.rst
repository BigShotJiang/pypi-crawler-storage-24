.. raw:: html

    <style>
    /* Hide only the first H1 on this page */
    h1:first-of-type {display: none !important;}
    </style>

{{ fullname | escape | underline }}

:mod:`{{ fullname  }}` module

.. automodule:: {{ fullname }}
