Command line
============

..  click:: galactic.apps.cli.main:application
    :prog: galactic
    :nested: full
