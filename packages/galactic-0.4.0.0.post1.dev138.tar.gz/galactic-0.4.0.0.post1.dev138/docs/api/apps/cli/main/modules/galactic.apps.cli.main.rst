﻿.. raw:: html

    <style>
    /* Hide only the first H1 on this page */
    h1:first-of-type {display: none !important;}
    </style>

galactic.apps.cli.main
======================

:mod:`galactic.apps.cli.main` module

.. automodule:: galactic.apps.cli.main