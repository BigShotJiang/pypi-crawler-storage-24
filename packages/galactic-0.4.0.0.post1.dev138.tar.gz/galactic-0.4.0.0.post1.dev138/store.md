Main `galactic` command line application.
