**GALACTIC** `package.market` submodule
=======================================

This submodule can be added to projects that need to build an additional package for
the market. It checks for the existence of a `market.md` file to create the
documentation package.

Icon constructed using:

* the main **GALACTIC** icon
* the [Git, branch icon](https://www.iconfinder.com/icons/9025799/git_branch_icon)
  designed by [Phosphor Icons](https://www.iconfinder.com/phosphor-icons)
* the [Business, market, sale icon](https://www.iconfinder.com/icons/6617672/business_market_sale_shop_supermarket_icon)
  icon designed by [Yogi Aprelliyanto](https://www.iconfinder.com/yogiaprelliyanto)
