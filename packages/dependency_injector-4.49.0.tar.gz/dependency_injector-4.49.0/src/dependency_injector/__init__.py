"""Top-level package."""

__version__ = "4.49.0"
"""Version number.

:type: str
"""
