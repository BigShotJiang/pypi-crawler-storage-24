"""Tests for injection objects."""
