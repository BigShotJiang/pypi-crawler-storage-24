"""Tests for factories."""
