from pydantic import BaseModel

from ..enums import AdminPermission


# ------------------------------ #
# -------- User Inputs --------- #
# ------------------------------ #
class RegisterUserInput(BaseModel):
    phone: str
    password: str
    name: str
    surname: str


class LoginInput(BaseModel):
    phone: str
    password: str


class MessageFeedbackInput(BaseModel):
    thread_id: str
    message_id: str
    sentiment: str  # 'like' or 'dislike'


class ThreadUpdateInput(BaseModel):
    title: str


# ------------------------------ #
# -------- Admin Inputs -------- #
# ------------------------------ #
class AdminRegisterInput(BaseModel):
    username: str
    password: str
    name: str
    permissions: list[AdminPermission]


class AdminUpdateInput(BaseModel):
    name: str | None = None
    password: str | None = None
    permissions: list[AdminPermission] | None = None


class AdminLoginInput(BaseModel):
    username: str
    password: str


class UserCreateInput(BaseModel):
    phone: str
    name: str
    surname: str
    balance: dict | None = None


class UserUpdateInput(BaseModel):
    phone: str | None = None
    name: str | None = None
    surname: str | None = None


class UserBalanceUpdateInput(BaseModel):
    tokens: int
    requests: int
