import hashlib
from datetime import UTC, datetime, timedelta

import jwt

from ..constants import (
    ADMIN_JWT_EXPIRATION_HOURS,
    ADMIN_JWT_SECRET_KEY,
    JWT_ALGORITHM,
    JWT_EXPIRATION_HOURS,
    JWT_SECRET_KEY,
)


# ------------------------------ #
# -------- JWT Utilities -------- #
# ------------------------------ #
def _create_token(data: dict, secret: str, expiration_hours: int) -> str:
    """Helper to create a JWT token with consistent payload structure."""
    expiration = datetime.now(UTC) + timedelta(hours=expiration_hours)
    payload = {
        **data,
        "exp": expiration,
        "iat": datetime.now(UTC),
    }
    return jwt.encode(payload, secret, algorithm=JWT_ALGORITHM)


def create_jwt_token(user_id: str) -> str:
    """Create a JWT token for a user."""
    return _create_token({"user_id": user_id}, JWT_SECRET_KEY, JWT_EXPIRATION_HOURS)


def create_admin_token(admin_id: str) -> str:
    """Create a JWT token for an admin."""
    return _create_token({"admin_id": admin_id}, ADMIN_JWT_SECRET_KEY, ADMIN_JWT_EXPIRATION_HOURS)


# ------------------------------ #
# -------- Security Utils ------- #
# ------------------------------ #
def hash_password(password: str) -> str:
    """Hash a password using SHA-256."""
    return hashlib.sha256(password.encode()).hexdigest()


def verify_password(password: str, password_hash: str) -> bool:
    """Verify a password against its hash."""
    return hash_password(password) == password_hash
