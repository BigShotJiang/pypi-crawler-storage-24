from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import JSONResponse, Response

from ..dependencies import authenticate_with_bearer


router = APIRouter()


@router.get("/users/balance", tags=["User"])
async def get_user_balance(
    request: Request,
    phone: str | None = None,
) -> Response:
    """
    Endpoint to get a user's balance.
    Can be authenticated via JWT token or phone number.
    """
    user = None

    # Try JWT authentication first
    auth_header = request.headers.get("Authorization")
    if auth_header:
        try:
            user = authenticate_with_bearer(request)
        except HTTPException:
            pass

    if not user:
        raise HTTPException(status_code=401, detail="Authentication required (JWT or phone number)")

    balance = user.balance or {"tokens": 0, "requests": 0, "updated_at": None}
    return JSONResponse(balance, status_code=200)
