from fastapi import APIRouter
from pydantic import BaseModel

from ...constants import APP_LANGUAGE, APP_NAME, SHOW_TOOL_DETAILS


router = APIRouter(prefix="/config", tags=["Config"])


class AppConfig(BaseModel):
    name: str
    language: str
    show_tool_details: bool


@router.get("", response_model=AppConfig)
async def get_config() -> AppConfig:
    return AppConfig(name=APP_NAME, language=APP_LANGUAGE, show_tool_details=SHOW_TOOL_DETAILS)
