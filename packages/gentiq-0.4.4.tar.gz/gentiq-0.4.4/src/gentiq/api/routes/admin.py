import uuid
from datetime import UTC, datetime, timedelta
from typing import Annotated

from fastapi import APIRouter, Depends
from fastapi.responses import JSONResponse, Response

from ...database import Database
from ...enums import AdminPermission
from ..dependencies import (
    authenticate,
    check_permission,
    get_database,
    get_storage,
    optional_authenticate,
    require_permission,
)
from ...storage import Storage
import mimetypes
from ..inputs import (
    AdminLoginInput,
    AdminRegisterInput,
    AdminUpdateInput,
    UserBalanceUpdateInput,
    UserCreateInput,
    UserUpdateInput,
)
from ..security import (
    create_admin_token,
    create_jwt_token,
    hash_password,
    verify_password,
)


router = APIRouter(prefix="/admin", tags=["Admin"])
AuthenticatedAdmin = Annotated[dict | None, Depends(authenticate)]
OptionalAdmin = Annotated[dict | None, Depends(optional_authenticate)]


# ------------------------------ #
# -------- Setup Status -------- #
# ------------------------------ #


@router.get("/setup-status")
async def get_setup_status(database: Database = Depends(get_database)) -> Response:
    """Check if the system needs initial admin setup (no admins exist)."""
    admins = database.list_admins()
    return JSONResponse({"needs_setup": len(admins) == 0})


# ------------------------------ #
# ----- Admin Management ------- #
# ------------------------------ #


@router.post("/admins")
async def register_admin(
    request: AdminRegisterInput,
    database: Database = Depends(get_database),
    admin: dict | None = Depends(optional_authenticate),
) -> Response:
    """Endpoint to register a new admin."""
    # Allow registration if no admins exist (initial setup) or if requester has ADMIN_MANAGEMENT permission
    admins = database.list_admins()
    if len(admins) > 0:
        check_permission(admin, AdminPermission.ADMIN_MANAGEMENT)

    # Check if admin with username already exists
    existing_admin = database.get_admin_by_username(request.username)
    if existing_admin:
        return JSONResponse(
            {"error": "Admin with this username already exists"},
            status_code=400,
        )

    # Generate admin ID and hash password
    admin_id = f"admin_{uuid.uuid4().hex}"
    password_hash = hash_password(request.password)

    # Create admin in database
    try:
        admin_doc = database.create_admin(
            admin_id=admin_id,
            username=request.username,
            password_hash=password_hash,
            name=request.name,
            permissions=[p.value for p in request.permissions],
        )

        return JSONResponse(
            {
                "admin_id": admin_doc.id,
                "username": admin_doc.username,
                "name": admin_doc.name,
                "permissions": admin_doc.permissions,
                "created_at": admin_doc.created_at.isoformat() if admin_doc.created_at else None,
            },
            status_code=201,
        )
    except Exception as e:
        return JSONResponse(
            {"error": f"Failed to create admin: {str(e)}"},
            status_code=500,
        )


@router.post("/login")
async def login_admin(request: AdminLoginInput, database: Database = Depends(get_database)) -> Response:
    """Endpoint for admin login. Returns a JWT token on success."""
    admin = database.get_admin_by_username(request.username)
    if not admin:
        return JSONResponse(
            {"error": "Invalid username or password"},
            status_code=401,
        )

    if not verify_password(request.password, admin.password_hash):
        return JSONResponse(
            {"error": "Invalid username or password"},
            status_code=401,
        )

    token = create_admin_token(admin.id)

    permissions = admin.permissions
    if permissions and len(permissions) > 0 and not isinstance(permissions[0], str):
        permissions = [p.value if hasattr(p, "value") else str(p) for p in permissions]

    return JSONResponse(
        {
            "token": token,
            "admin_id": admin.id,
            "username": admin.username,
            "name": admin.name,
            "permissions": permissions,
        },
        status_code=200,
    )


@router.get("/admins")
async def list_admins(
    database: Database = Depends(get_database),
    admin: dict | None = Depends(require_permission(AdminPermission.ADMIN_MANAGEMENT)),
) -> Response:
    """Endpoint to list all admins."""
    try:
        admins = database.list_admins()
        return JSONResponse(
            {
                "admins": [
                    {
                        "id": a.id,
                        "username": a.username,
                        "name": a.name,
                        "permissions": a.permissions,
                    }
                    for a in admins
                ]
            },
            status_code=200,
        )
    except Exception as e:
        return JSONResponse(
            {"error": f"Failed to fetch admins: {str(e)}"},
            status_code=500,
        )


@router.patch("/admins/{admin_id}")
async def update_admin(
    admin_id: str,
    data: AdminUpdateInput,
    database: Database = Depends(get_database),
    admin: dict | None = Depends(require_permission(AdminPermission.ADMIN_MANAGEMENT)),
) -> Response:
    """Endpoint to update an admin's information or permissions."""
    try:
        update_data = {}
        if data.name is not None:
            update_data["name"] = data.name
        if data.password is not None:
            update_data["password_hash"] = hash_password(data.password)
        if data.permissions is not None:
            update_data["permissions"] = [p.value for p in data.permissions]

        if not update_data:
            return JSONResponse(
                {"error": "No update data provided"},
                status_code=400,
            )

        success = database.update_admin(admin_id, update_data)
        if not success:
            return JSONResponse(
                {"error": "Admin not found or no changes made"},
                status_code=404,
            )

        return JSONResponse(
            {"status": "success", "message": "Admin updated successfully"},
            status_code=200,
        )
    except Exception as e:
        return JSONResponse(
            {"error": f"Failed to update admin: {str(e)}"},
            status_code=500,
        )


@router.delete("/admins/{admin_id}")
async def delete_admin(
    admin_id: str,
    database: Database = Depends(get_database),
    admin: dict | None = Depends(require_permission(AdminPermission.ADMIN_MANAGEMENT)),
) -> Response:
    """Endpoint to delete an admin."""
    if admin and admin_id == admin.get("admin_id"):
        return JSONResponse(
            {"error": "Cannot delete your own admin account"},
            status_code=400,
        )

    try:
        success = database.delete_admin(admin_id)
        if not success:
            return JSONResponse(
                {"error": "Admin not found"},
                status_code=404,
            )
        return JSONResponse(
            {"status": "success", "message": "Admin deleted successfully"},
            status_code=200,
        )
    except Exception as e:
        return JSONResponse(
            {"error": f"Failed to delete admin: {str(e)}"},
            status_code=500,
        )


@router.get("/permissions")
async def list_permissions(
    database: Database = Depends(get_database),
    admin: dict | None = Depends(require_permission(AdminPermission.ADMIN_MANAGEMENT)),
) -> Response:
    """Endpoint to list all available permissions."""
    return JSONResponse(
        {"permissions": AdminPermission.list_all()},
        status_code=200,
    )


# ------------------------------ #
# ----- Chat History ----------- #
# ------------------------------ #


@router.get("/chat-history/threads")
async def list_all_threads(
    skip: int = 0,
    limit: int = 50,
    query: str | None = None,
    feedback: str | None = None,
    database: Database = Depends(get_database),
    admin: dict | None = Depends(require_permission(AdminPermission.CHAT_HISTORY)),
) -> Response:
    """Endpoint to list all chat threads or search for threads."""
    try:
        if query:
            threads = database.search_threads(query=query, skip=skip, limit=limit, feedback_filter=feedback)
        else:
            threads = database.list_all_threads(skip=skip, limit=limit, feedback_filter=feedback)

        return JSONResponse(
            {
                "threads": threads,
                "skip": skip,
                "limit": limit,
                "count": len(threads),
            },
            status_code=200,
        )
    except Exception as e:
        return JSONResponse(
            {"error": f"Failed to fetch threads: {str(e)}"},
            status_code=500,
        )


@router.get("/chat-history/threads/{thread_id}/items")
async def get_thread_items(
    thread_id: str,
    database: Database = Depends(get_database),
    admin: dict | None = Depends(require_permission(AdminPermission.CHAT_HISTORY)),
) -> Response:
    """Endpoint to get all items (messages) in a specific thread."""
    try:
        items = database.get_thread_items_for_admin(thread_id)
        thread = database.fetch_thread(thread_id)

        if not thread:
            return JSONResponse(
                {"error": "Thread not found"},
                status_code=404,
            )

        thread.pop("_id", None)
        if "created_at" in thread and hasattr(thread["created_at"], "isoformat"):
            thread["created_at"] = thread["created_at"].isoformat()
        if "updated_at" in thread and hasattr(thread["updated_at"], "isoformat"):
            thread["updated_at"] = thread["updated_at"].isoformat()

        return JSONResponse(
            {
                "thread_id": thread_id,
                "thread": thread,
                "items": items,
                "count": len(items),
            },
            status_code=200,
        )
    except Exception as e:
        return JSONResponse(
            {"error": f"Failed to fetch thread items: {str(e)}"},
            status_code=500,
        )


@router.get("/chat-history/attachments/{object_name:path}")
async def get_attachment_for_admin(
    object_name: str,
    storage: Storage = Depends(get_storage),
    admin: dict | None = Depends(require_permission(AdminPermission.CHAT_HISTORY)),
) -> Response:
    """Securely proxy a Minio attachment to the authenticated admin."""
    try:
        content = storage.download_attachment(object_name)
        media_type, _ = mimetypes.guess_type(object_name)
        if not media_type:
            media_type = "application/octet-stream"
        return Response(content=content, media_type=media_type)
    except Exception:
        return JSONResponse(
            {"error": "Attachment not found"},
            status_code=404,
        )


# ------------------------------ #
# ----- User Management -------- #
# ------------------------------ #


@router.get("/users")
async def list_users(
    skip: int = 0,
    limit: int = 100,
    query: str | None = None,
    database: Database = Depends(get_database),
    admin: dict | None = Depends(require_permission(AdminPermission.USER_MANAGEMENT)),
) -> Response:
    """Endpoint to list all users."""
    try:
        users = database.list_users(skip=skip, limit=limit, query=query)
        count = database.count_users(query=query)
        return JSONResponse(
            {
                "users": [
                    {
                        "id": u.id,
                        "phone": u.phone,
                        "name": u.name,
                        "surname": u.surname,
                        "token": u.token,
                        "balance": u.balance,
                    }
                    for u in users
                ],
                "count": count,
            },
            status_code=200,
        )
    except Exception as e:
        return JSONResponse(
            {"error": f"Failed to fetch users: {str(e)}"},
            status_code=500,
        )


@router.post("/users")
async def create_user(
    data: UserCreateInput,
    database: Database = Depends(get_database),
    admin: dict | None = Depends(require_permission(AdminPermission.USER_MANAGEMENT)),
) -> Response:
    """Endpoint to create a new user."""
    try:
        existing_user = database.get_user_by_phone(data.phone)
        if existing_user:
            return JSONResponse(
                {"error": "Phone number already registered"},
                status_code=400,
            )

        user_id = f"user_{uuid.uuid4().hex}"
        token = create_jwt_token(user_id)

        user = database.create_user(
            user_id=user_id,
            phone=data.phone,
            name=data.name,
            surname=data.surname,
            token=token,
            balance=data.balance,
        )

        return JSONResponse(
            {
                "status": "success",
                "user": {
                    "id": user.id,
                    "phone": user.phone,
                    "name": user.name,
                    "surname": user.surname,
                    "token": user.token,
                    "created_at": user.created_at.isoformat() if user.created_at else None,
                },
            },
            status_code=201,
        )
    except Exception as e:
        return JSONResponse(
            {"error": f"Failed to create user: {str(e)}"},
            status_code=500,
        )


@router.patch("/users/{user_id}")
async def update_user(
    user_id: str,
    data: UserUpdateInput,
    database: Database = Depends(get_database),
    admin: dict | None = Depends(require_permission(AdminPermission.USER_MANAGEMENT)),
) -> Response:
    """Endpoint to update a user's information."""
    try:
        existing_user = database.get_user(user_id)
        if not existing_user:
            return JSONResponse(
                {"error": "User not found"},
                status_code=404,
            )

        if data.phone and data.phone != existing_user.phone:
            phone_user = database.get_user_by_phone(data.phone)
            if phone_user:
                return JSONResponse(
                    {"error": "Phone number already in use"},
                    status_code=400,
                )
            database.users.update_one({"id": user_id}, {"$set": {"phone": data.phone}})

        database.update_user_info(
            user_id=user_id,
            name=data.name,
            surname=data.surname,
        )

        updated_user = database.get_user(user_id)
        if not updated_user:
            raise Exception(f"User `{user_id}` not found!")

        return JSONResponse(
            {
                "status": "success",
                "user": {
                    "id": updated_user.id,
                    "phone": updated_user.phone,
                    "name": updated_user.name,
                    "surname": updated_user.surname,
                    "token": updated_user.token,
                    "balance": updated_user.balance,
                },
            },
            status_code=200,
        )
    except Exception as e:
        return JSONResponse(
            {"error": f"Failed to update user: {str(e)}"},
            status_code=500,
        )


@router.delete("/users/{user_id}")
async def delete_user(
    user_id: str,
    database: Database = Depends(get_database),
    admin: dict | None = Depends(require_permission(AdminPermission.USER_MANAGEMENT)),
) -> Response:
    """Endpoint to delete a user."""
    try:
        success = database.delete_user(user_id)
        if not success:
            return JSONResponse(
                {"error": "User not found"},
                status_code=404,
            )
        return JSONResponse(
            {"status": "success", "message": "User deleted successfully"},
            status_code=200,
        )
    except Exception as e:
        return JSONResponse(
            {"error": f"Failed to delete user: {str(e)}"},
            status_code=500,
        )


@router.post("/users/{user_id}/balance")
async def update_user_balance(
    user_id: str,
    data: UserBalanceUpdateInput,
    database: Database = Depends(get_database),
    admin: dict | None = Depends(require_permission(AdminPermission.USER_MANAGEMENT)),
) -> Response:
    """Endpoint to update a user's balance to specific values."""
    try:
        new_balance = database.update_user_balance(
            user_id=user_id,
            tokens=data.tokens,
            requests=data.requests,
        )

        return JSONResponse(
            {
                "status": "success",
                "message": "User balance updated successfully",
                "balance": new_balance,
            },
            status_code=200,
        )
    except ValueError as e:
        return JSONResponse(
            {"error": str(e)},
            status_code=404,
        )
    except Exception as e:
        return JSONResponse(
            {"error": f"Failed to update user balance: {str(e)}"},
            status_code=500,
        )


@router.post("/users/{user_id}/refresh-token")
async def refresh_user_token(
    user_id: str,
    database: Database = Depends(get_database),
    admin: dict | None = Depends(require_permission(AdminPermission.USER_MANAGEMENT)),
) -> Response:
    """Endpoint to refresh a user's JWT token."""
    try:
        user = database.get_user(user_id)
        if not user:
            return JSONResponse(
                {"error": "User not found"},
                status_code=404,
            )

        new_token = create_jwt_token(user_id)
        await database.update_user_token(user_id, new_token)

        updated_user = database.get_user(user_id)
        if not updated_user:
            raise Exception(f"User `{user_id}` not found after token update!")

        return JSONResponse(
            {
                "status": "success",
                "message": "Token refreshed successfully",
                "user": {
                    "id": updated_user.id,
                    "phone": updated_user.phone,
                    "name": updated_user.name,
                    "surname": updated_user.surname,
                    "token": updated_user.token,
                    "balance": updated_user.balance,
                },
            },
            status_code=200,
        )
    except Exception as e:
        return JSONResponse(
            {"error": f"Failed to refresh token: {str(e)}"},
            status_code=500,
        )


# ------------------------------ #
# ----- Analytics -------------- #
# ------------------------------ #


@router.get("/analytics")
async def get_analytics(
    days: int = 30,
    database: Database = Depends(get_database),
    admin: dict | None = Depends(require_permission(AdminPermission.ANALYTICS)),
) -> Response:
    """Endpoint to get analytics data for the admin panel."""
    try:
        now = datetime.now(UTC)
        end_date = now + timedelta(days=1)
        start_date = now - timedelta(days=days)

        date_match = {"created_at": {"$gte": start_date, "$lte": end_date}}

        # Get user registration trends over time
        user_pipeline = [
            {"$match": date_match},
            {
                "$group": {
                    "_id": {"$dateToString": {"format": "%Y-%m-%d", "date": "$created_at"}},
                    "count": {"$sum": 1},
                }
            },
            {"$sort": {"_id": 1}},
        ]

        # Get thread creation trends
        thread_pipeline = [
            {"$match": date_match},
            {
                "$group": {
                    "_id": {"$dateToString": {"format": "%Y-%m-%d", "date": "$created_at"}},
                    "count": {"$sum": 1},
                }
            },
            {"$sort": {"_id": 1}},
        ]

        # Get message trends
        message_pipeline = [
            {"$match": date_match},
            {
                "$group": {
                    "_id": {"$dateToString": {"format": "%Y-%m-%d", "date": "$created_at"}},
                    "count": {"$sum": 1},
                }
            },
            {"$sort": {"_id": 1}},
        ]

        # Get token usage trends
        transaction_pipeline = [
            {
                "$match": {
                    "created_at": {"$gte": start_date, "$lte": end_date},
                    "type": "usage",
                }
            },
            {
                "$group": {
                    "_id": {"$dateToString": {"format": "%Y-%m-%d", "date": "$created_at"}},
                    "total_tokens": {"$sum": {"$abs": "$change.tokens"}},
                    "total_requests": {"$sum": {"$abs": "$change.requests"}},
                }
            },
            {"$sort": {"_id": 1}},
        ]

        # Get most active users (by thread count)
        active_users_pipeline = [
            {"$match": date_match},
            {"$group": {"_id": "$user_id", "thread_count": {"$sum": 1}}},
            {"$sort": {"thread_count": -1}},
            {"$limit": 10},
        ]

        # Get recent feedbacks sentiment distribution
        feedback_pipeline = [
            {"$match": date_match},
            {"$group": {"_id": "$sentiment", "count": {"$sum": 1}}},
        ]

        # Execute pipelines
        try:
            user_trends = list(database.users.aggregate(user_pipeline))
        except Exception:
            user_trends = []

        try:
            thread_trends = list(database.threads.aggregate(thread_pipeline))
        except Exception:
            thread_trends = []

        try:
            message_trends = list(database.thread_items.aggregate(message_pipeline))
        except Exception:
            message_trends = []

        try:
            token_usage = list(database.transactions.aggregate(transaction_pipeline))
        except Exception:
            token_usage = []

        try:
            active_users_data = list(database.threads.aggregate(active_users_pipeline))
        except Exception:
            active_users_data = []

        try:
            feedback_distribution = list(database.feedbacks.aggregate(feedback_pipeline))
        except Exception:
            feedback_distribution = []

        # Enrich with user info
        active_users = []
        for item in active_users_data:
            user_id = item.get("_id")
            if user_id:
                user = database.get_user(user_id)
                if user:
                    active_users.append(
                        {
                            "user_id": user_id,
                            "name": f"{user.name} {user.surname}",
                            "thread_count": item["thread_count"],
                        }
                    )

        return JSONResponse(
            {
                "overview": {
                    "total_users": sum([t["count"] for t in user_trends]),
                    "total_threads": sum([t["count"] for t in thread_trends]),
                    "total_messages": sum([m["count"] for m in message_trends]),
                    "total_token_usage": sum([t.get("total_tokens", 0) for t in token_usage]),
                },
                "trends": {
                    "users": [{"date": item["_id"], "count": item["count"]} for item in user_trends],
                    "threads": [{"date": item["_id"], "count": item["count"]} for item in thread_trends],
                    "messages": [{"date": item["_id"], "count": item["count"]} for item in message_trends],
                    "token_usage": [
                        {
                            "date": item["_id"],
                            "tokens": item.get("total_tokens", 0),
                            "requests": item.get("total_requests", 0),
                        }
                        for item in token_usage
                    ],
                },
                "distributions": {
                    "feedback_sentiment": [
                        {
                            "sentiment": "positive"
                            if item["_id"] == "like"
                            else ("negative" if item["_id"] == "dislike" else item["_id"]),
                            "count": item["count"],
                        }
                        for item in feedback_distribution
                    ],
                },
                "active_users": active_users,
            },
            status_code=200,
        )
    except Exception as e:
        import traceback

        traceback.print_exc()
        return JSONResponse(
            {"error": f"Failed to fetch analytics: {str(e)}"},
            status_code=500,
        )
