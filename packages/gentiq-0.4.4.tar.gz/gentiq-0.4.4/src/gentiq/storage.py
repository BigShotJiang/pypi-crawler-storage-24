"""
Minio Storage interface for file uploads and downloads.
"""

from .constants import ATTACHMENTS_BUCKET


class Storage:
    """Minio Storage interface for file uploads and downloads, saving and loading attachments, etc."""

    attachments_bucket: str = ATTACHMENTS_BUCKET

    def __init__(self, endpoint: str, access_key: str, secret_key: str, secure: bool = False):
        from minio import Minio

        self.client = Minio(
            endpoint=endpoint,
            access_key=access_key,
            secret_key=secret_key,
            secure=secure,
        )
        if not self.client.bucket_exists(bucket_name=self.attachments_bucket):
            self.client.make_bucket(bucket_name=self.attachments_bucket)

    def insert_attachment(self, content: bytes, object_name: str):
        """Insert attachment content into storage."""
        from io import BytesIO

        self.client.put_object(
            bucket_name=self.attachments_bucket,
            object_name=object_name,
            data=BytesIO(content),
            length=len(content),
        )

    def download_attachment(self, object_name: str) -> bytes:
        """Download attachment content from storage."""
        response = self.client.get_object(bucket_name=self.attachments_bucket, object_name=object_name)
        data = response.read()
        response.close()
        response.release_conn()
        return data

    def delete_attachment(self, object_name: str) -> None:
        """Delete attachment content from storage."""
        self.client.remove_object(bucket_name=self.attachments_bucket, object_name=object_name)

    def create_bucket(self, bucket_name: str) -> None:
        """Create a new bucket."""
        if not self.client.bucket_exists(bucket_name=bucket_name):
            self.client.make_bucket(bucket_name=bucket_name)

    def get_presigned_url(self, object_name: str, expires_hours: int = 1) -> str:
        """Generate a pre-signed URL for downloading an object."""
        from datetime import timedelta

        return self.client.presigned_get_object(
            bucket_name=self.attachments_bucket,
            object_name=object_name,
            expires=timedelta(hours=expires_hours),
        )

    def object_exists(self, object_name: str) -> bool:
        """Check if an object exists in the attachments bucket."""
        try:
            self.client.stat_object(bucket_name=self.attachments_bucket, object_name=object_name)
            return True
        except Exception:
            return False
