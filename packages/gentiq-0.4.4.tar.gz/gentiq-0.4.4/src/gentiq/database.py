"""
A general-purpose database module for the application. It has access to all DB operations.
It can be used by different parts of the application to interact with the database in a consistent manner.
Authentication and authorization should be handled on each call.
"""

from ast import literal_eval
from dataclasses import asdict, dataclass, fields
from datetime import UTC, datetime

from pymongo import MongoClient, ReturnDocument

from .constants import (
    ADMINS_COLLECTION,
    ATTACHMENTS_COLLECTION,
    FEEDBACKS_COLLECTION,
    INITIAL_BALANCE_REQUESTS,
    INITIAL_BALANCE_TOKENS,
    THREAD_ITEMS_COLLECTION,
    THREADS_COLLECTION,
    TRANSACTIONS_COLLECTION,
    USERS_COLLECTION,
)


@dataclass
class UserDocument:
    """Represents a user document in the 'users' collection in the database."""

    id: str
    phone: str
    name: str
    surname: str
    token: str
    balance: dict | None
    created_at: datetime
    password_hash: str | None

    def to_dict(self) -> dict:
        """Convert the User to a dictionary."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> "UserDocument":
        """Create a UserDocument strictly from matching keys."""
        field_names = {f.name for f in fields(cls)}
        filtered = {k: v for k, v in data.items() if k in field_names}
        return cls(**filtered)


@dataclass
class FeedbackDocument:
    """Represents a feedback document in the 'feedback' collection in the database."""

    thread_id: str
    item_ids: list[str]
    sentiment: str
    user_id: str
    created_at: datetime | None = None

    def to_dict(self) -> dict:
        """Convert the FeedbackDocument to a dictionary."""
        return asdict(self)


@dataclass
class AdminDocument:
    """Represents an admin document in the 'admins' collection in the database."""

    id: str
    username: str
    password_hash: str
    name: str
    permissions: list[str]
    created_at: datetime | None = None

    def to_dict(self) -> dict:
        """Convert the AdminDocument to a dictionary."""
        return asdict(self)


@dataclass
class TransactionDocument:
    """Represents a transaction document in the 'transactions' collection."""

    user_id: str
    type: str  # "usage" or "recharge"
    change: dict  # {"tokens": int, "requests": int}
    balance_after: dict  # {"tokens": int, "requests": int}
    created_at: datetime
    thread_id: str | None = None
    details: dict | None = None

    def to_dict(self) -> dict:
        """Convert the TransactionDocument to a dictionary."""
        return asdict(self)


class Database:
    """A general-purpose MongoDB database class for the application."""

    threads_collection: str = THREADS_COLLECTION
    thread_items_collection: str = THREAD_ITEMS_COLLECTION
    attachments_collection: str = ATTACHMENTS_COLLECTION
    users_collection: str = USERS_COLLECTION
    feedbacks_collection: str = FEEDBACKS_COLLECTION
    admins_collection: str = ADMINS_COLLECTION
    transactions_collection: str = TRANSACTIONS_COLLECTION

    def __init__(
        self,
        uri: str,
        db_name: str,
        username: str | None = None,
        password: str | None = None,
    ) -> None:
        self.client = MongoClient(uri, username=username, password=password)
        self.db = self.client[db_name]
        self.threads = self.db[self.threads_collection]
        self.thread_items = self.db[self.thread_items_collection]
        self.attachments = self.db[self.attachments_collection]
        self.users = self.db[self.users_collection]
        self.feedbacks = self.db[self.feedbacks_collection]
        self.admins = self.db[self.admins_collection]
        self.transactions = self.db[self.transactions_collection]

        # Ensure indexes for performance and uniqueness
        self.thread_items.create_index([("thread_id", 1), ("id", 1)], unique=True)
        self.thread_items.create_index([("thread_id", 1), ("created_at", 1)])

    async def search(self, collection: str, filter: str | dict, **kwargs) -> list[dict]:
        """Run a query against the specified collection in the database."""
        if isinstance(filter, str):
            filter = literal_eval(filter)
        return list(self.db[collection].find(filter, **kwargs))

    def fetch_thread(self, thread_id: str) -> dict | None:
        """Get all items in a thread by its ID."""
        thread = self.threads.find_one({"id": thread_id})
        return thread

    def fetch_thread_item(self, thread_id: str, item_id: str):
        thread_item = self.db.thread_items.find_one({"thread_id": thread_id, "id": item_id})
        return thread_item

    def get_user(self, user_id: str) -> UserDocument | None:
        """Fetch a user document by user ID."""
        doc = self.users.find_one({"id": user_id})
        if not doc:
            return None
        doc.pop("_id", None)
        user = UserDocument.from_dict(doc)
        return user

    def get_user_by_phone(self, phone: str) -> UserDocument | None:
        """Fetch a user document by phone number."""
        doc = self.users.find_one({"phone": phone})
        if doc:
            doc.pop("_id", None)
            return UserDocument.from_dict(doc)
        return None

    def create_user(
        self,
        user_id: str,
        phone: str,
        name: str,
        surname: str,
        token: str,
        balance: dict | None = None,
        password_hash: str | None = None,
    ) -> UserDocument:
        """Create a new user document in the database."""
        if balance is None:
            balance = {
                "tokens": INITIAL_BALANCE_TOKENS,
                "requests": INITIAL_BALANCE_REQUESTS,
                "updated_at": datetime.now(UTC).isoformat(),
            }

        user = UserDocument(
            id=user_id,
            phone=phone,
            password_hash=password_hash,
            name=name,
            surname=surname,
            token=token,
            balance=balance,
            created_at=datetime.now(UTC),
        )
        self.users.insert_one(user.to_dict())
        return user

    async def update_user_token(self, user_id: str, token: str) -> None:
        """Update the JWT token for a user."""
        self.db["users"].update_one({"id": user_id}, {"$set": {"token": token}})

    def update_user_info(
        self,
        user_id: str,
        name: str | None = None,
        surname: str | None = None,
    ) -> None:
        """Update user information."""
        update_fields = {}
        if name is not None:
            update_fields["name"] = name
        if surname is not None:
            update_fields["surname"] = surname

        if update_fields:
            self.db["users"].update_one({"id": user_id}, {"$set": update_fields})

    def recharge_user(self, user_id: str, add_tokens: int, add_requests: int) -> dict:
        """Recharge a user's balance atomically and log the transaction."""
        updated_user = self.users.find_one_and_update(
            {"id": user_id},
            {
                "$inc": {
                    "balance.tokens": add_tokens,
                    "balance.requests": add_requests,
                },
                "$set": {"balance.updated_at": datetime.now(UTC).isoformat()},
            },
            return_document=ReturnDocument.AFTER,
        )

        if not updated_user:
            raise ValueError("User not found")

        new_balance = updated_user.get("balance", {"tokens": 0, "requests": 0})

        transaction = TransactionDocument(
            user_id=user_id,
            type="recharge",
            change={"tokens": add_tokens, "requests": add_requests},
            balance_after={"tokens": new_balance.get("tokens", 0), "requests": new_balance.get("requests", 0)},
            created_at=datetime.now(UTC),
        )
        self.transactions.insert_one(transaction.to_dict())
        return new_balance

    def get_user_balance(self, user_id: str) -> dict:
        """Get a user's current balance."""
        user = self.get_user(user_id)
        if not user:
            raise ValueError("User not found")
        return user.balance or {"tokens": 0, "requests": 0}

    def check_user_balance(self, user_id: str) -> bool:
        """Check if a user has enough balance (at least 1 token and 1 request)."""
        balance = self.get_user_balance(user_id)
        return balance.get("tokens", 0) > 0 and balance.get("requests", 0) > 0

    def update_user_balance(self, user_id: str, tokens: int, requests: int) -> dict:
        """Update a user's balance to specific values and log the transaction."""
        user = self.get_user(user_id)
        if not user:
            raise ValueError("User not found")

        current_balance = user.balance or {"tokens": 0, "requests": 0}
        token_change = tokens - current_balance.get("tokens", 0)
        request_change = requests - current_balance.get("requests", 0)

        new_balance = {
            "tokens": tokens,
            "requests": requests,
            "updated_at": datetime.now(UTC).isoformat(),
        }

        # Update balance to absolute values
        self.users.update_one({"id": user_id}, {"$set": {"balance": new_balance}})

        transaction = TransactionDocument(
            user_id=user_id,
            type="balance_update",
            change={"tokens": token_change, "requests": request_change},
            balance_after={"tokens": tokens, "requests": requests},
            created_at=datetime.now(UTC),
        )
        self.transactions.insert_one(transaction.to_dict())
        return new_balance

    async def save_feedback(
        self,
        thread_id: str,
        item_ids: list[str],
        sentiment: str,
        user_id: str,
    ) -> None:
        """Save feedback for specific thread items."""
        existing = self.feedbacks.find_one({"thread_id": thread_id, "item_ids": item_ids})
        if existing:
            self.feedbacks.update_one({"_id": existing["_id"]}, {"$set": {"sentiment": sentiment}})
            return
        feedback_doc = FeedbackDocument(
            thread_id=thread_id,
            item_ids=item_ids,
            sentiment=sentiment,
            user_id=user_id,
            created_at=datetime.now(UTC),
        )
        self.feedbacks.insert_one(feedback_doc.to_dict())

    async def update_usage(self, user_id: str, thread_id: str, usage) -> None:
        """Update usage statistics for a thread, deduct from user balance, and log transaction."""

        # Safely extract metrics whether usage is an object or dictionary
        def get_metric(obj, key, default=0):
            if isinstance(obj, dict):
                return obj.get(key, default)
            val = getattr(obj, key, default)
            return val if val is not None else default

        details = get_metric(usage, "details", {})
        if not isinstance(details, dict):
            details = {}

        input_t = get_metric(usage, "input_tokens", 0) or get_metric(usage, "request_tokens", 0) or 0
        output_t = get_metric(usage, "output_tokens", 0) or get_metric(usage, "response_tokens", 0) or 0
        total_t = get_metric(usage, "total_tokens", 0) or 0

        # Guard against APIs or older implementations where total_tokens is 0 but input/output are set.
        if total_t == 0 and (input_t > 0 or output_t > 0):
            total_t = input_t + output_t

        usage_info = {
            "requests": get_metric(usage, "requests", 1) or 1,
            "request_tokens": input_t,
            "response_tokens": output_t,
            "input_tokens": input_t,
            "output_tokens": output_t,
            "total_tokens": total_t,
            "cache_read_tokens": get_metric(usage, "cache_read_tokens", 0) or 0,
            "cache_write_tokens": get_metric(usage, "cache_write_tokens", 0) or 0,
            "cache_audio_read_tokens": get_metric(usage, "cache_audio_read_tokens", 0) or 0,
            "input_audio_tokens": get_metric(usage, "input_audio_tokens", 0) or 0,
            "output_audio_tokens": get_metric(usage, "output_audio_tokens", 0) or 0,
            "tool_calls": get_metric(usage, "tool_calls", 0) or 0,
            "details": details,
        }

        # Build the dotted-path dict for MongoDB $inc and $set updates
        inc_data = {}
        set_data = {}

        # Fields that represent a snapshot of the current context window
        snapshot_fields = [
            "request_tokens",
            "input_tokens",
            "cache_read_tokens",
            "cache_audio_read_tokens",
            "input_audio_tokens",
        ]

        # Fields that are genuinely additive per turn
        additive_fields = [
            "requests",
            "response_tokens",
            "output_tokens",
            "cache_write_tokens",
            "output_audio_tokens",
            "tool_calls",
        ]

        for k, v in usage_info.items():
            if k == "details" and isinstance(v, dict):
                for dk, dv in v.items():
                    # detail sub-fields are per-turn metrics — accumulate with $inc
                    inc_data[f"metadata.usage.details.{dk}"] = dv or 0
            elif k in snapshot_fields:
                set_data[f"metadata.usage.{k}"] = v or 0
                # CRITICAL: Also accumulate snapshot fields to track the actual cumulative API cost across the thread.
                # If we don't $inc input_tokens over the thread, we lose the fact that we were billed for them heavily.
                inc_data[f"metadata.usage.cumulative_{k}"] = v or 0
            elif k in additive_fields:
                inc_data[f"metadata.usage.{k}"] = v or 0

        # Add cumulative_total_tokens manually to ensure overall actual cost metric
        inc_data["metadata.usage.cumulative_total_tokens"] = usage_info["total_tokens"]

        update_operations = {
            "$set": {"user_id": user_id, "updated_at": datetime.now(UTC)},
            "$setOnInsert": {
                "created_at": datetime.now(UTC),
                "_id": thread_id,
            },
        }
        if inc_data:
            update_operations["$inc"] = inc_data
        if set_data:
            update_operations["$set"].update(set_data)

        self.threads.update_one(
            {"id": thread_id},
            update_operations,
            upsert=True,
        )

        tokens_to_deduct = usage_info["total_tokens"]
        requests_to_deduct = usage_info["requests"]

        # Use find_one_and_update for atomic balance deduction
        updated_user = self.users.find_one_and_update(
            {"id": user_id},
            {
                "$inc": {
                    "balance.tokens": -tokens_to_deduct,
                    "balance.requests": -requests_to_deduct,
                },
                "$set": {"balance.updated_at": datetime.now(UTC).isoformat()},
            },
            return_document=ReturnDocument.AFTER,
        )

        if not updated_user:
            return

        new_balance = updated_user.get("balance", {"tokens": 0, "requests": 0})

        # Log transaction with full usage metadata
        transaction = TransactionDocument(
            user_id=user_id,
            type="usage",
            thread_id=thread_id,
            change={"tokens": -tokens_to_deduct, "requests": -requests_to_deduct},
            balance_after={"tokens": new_balance.get("tokens", 0), "requests": new_balance.get("requests", 0)},
            created_at=datetime.now(UTC),
            details=usage_info,
        )
        self.transactions.insert_one(transaction.to_dict())

    def create_admin(
        self,
        admin_id: str,
        username: str,
        password_hash: str,
        name: str,
        permissions: list[str],
    ) -> AdminDocument:
        """Create a new admin document in the database."""
        admin = AdminDocument(
            id=admin_id,
            username=username,
            password_hash=password_hash,
            name=name,
            permissions=permissions,
            created_at=datetime.now(UTC),
        )
        self.admins.insert_one(admin.to_dict())
        return admin

    def list_admins(self) -> list[AdminDocument]:
        """List all admins."""
        docs = list(self.admins.find({}))
        admins = []
        for doc in docs:
            doc.pop("_id", None)
            admins.append(AdminDocument(**doc))
        return admins

    def list_users(self, skip: int = 0, limit: int = 100, query: str | None = None) -> list[UserDocument]:
        """List all users with pagination and optional search."""
        filter_doc = {}
        if query:
            filter_doc = {
                "$or": [
                    {"name": {"$regex": query, "$options": "i"}},
                    {"surname": {"$regex": query, "$options": "i"}},
                    {"phone": {"$regex": query, "$options": "i"}},
                ]
            }

        docs = list(self.users.find(filter_doc).sort("name", 1).skip(skip).limit(limit))
        users = []
        for doc in docs:
            doc.pop("_id", None)
            users.append(UserDocument.from_dict(doc))
        return users

    def count_users(self, query: str | None = None) -> int:
        """Count total number of users, optionally filtered by search query."""
        filter_doc = {}
        if query:
            filter_doc = {
                "$or": [
                    {"name": {"$regex": query, "$options": "i"}},
                    {"surname": {"$regex": query, "$options": "i"}},
                    {"phone": {"$regex": query, "$options": "i"}},
                ]
            }
        return self.users.count_documents(filter_doc)

    def delete_user(self, user_id: str) -> bool:
        """Delete a user document."""
        result = self.users.delete_one({"id": user_id})
        return result.deleted_count > 0

    def update_admin(self, admin_id: str, update_data: dict) -> bool:
        """Update an admin document."""
        result = self.admins.update_one({"id": admin_id}, {"$set": update_data})
        return result.modified_count > 0

    def delete_admin(self, admin_id: str) -> bool:
        """Delete an admin document."""
        result = self.admins.delete_one({"id": admin_id})
        return result.deleted_count > 0

    def get_admin_by_username(self, username: str) -> AdminDocument | None:
        """Fetch an admin document by username."""
        doc = self.admins.find_one({"username": username})
        if doc:
            doc.pop("_id", None)
            if "permissions" not in doc:
                doc["permissions"] = ["chat_history", "admin_management"]
            return AdminDocument(**doc)
        return None

    def get_admin(self, admin_id: str) -> AdminDocument | None:
        """Fetch an admin document by admin ID."""
        doc = self.admins.find_one({"id": admin_id})
        if not doc:
            return None
        doc.pop("_id", None)
        if "permissions" not in doc:
            doc["permissions"] = ["chat_history", "admin_management"]
        return AdminDocument(**doc) if doc else None

    def list_user_threads(self, user_id: str, skip: int = 0, limit: int = 50) -> list[dict]:
        """List all non-deleted threads for a specific user."""
        threads = list(
            self.threads.find({"user_id": user_id, "is_deleted": {"$ne": True}})
            .sort("created_at", -1)
            .skip(skip)
            .limit(limit)
        )
        for thread in threads:
            thread.pop("_id", None)
            if "created_at" in thread and hasattr(thread["created_at"], "isoformat"):
                thread["created_at"] = thread["created_at"].isoformat()
            if "updated_at" in thread and hasattr(thread["updated_at"], "isoformat"):
                thread["updated_at"] = thread["updated_at"].isoformat()
            user = self.get_user(thread["user_id"])
            if user:
                thread["user_info"] = {
                    "name": user.name,
                    "surname": user.surname,
                    "phone": user.phone,
                }
        return threads

    def delete_user_thread(self, user_id: str, thread_id: str) -> bool:
        """Soft-delete a chat thread for a specific user to preserve usage data."""
        result = self.threads.update_one(
            {"id": thread_id, "user_id": user_id},
            {"$set": {"is_deleted": True, "updated_at": datetime.now(UTC)}},
        )
        return result.modified_count > 0

    def get_thread_items(self, user_id: str, thread_id: str) -> list[dict] | None:
        """Get all thread items for a specific user thread, if not deleted."""
        thread = self.threads.find_one({"id": thread_id, "user_id": user_id, "is_deleted": {"$ne": True}})
        if not thread:
            return None

        items = list(self.thread_items.find({"thread_id": thread_id}).sort("created_at", 1))

        # Fetch feedbacks for this thread to decorate items
        feedbacks = list(self.feedbacks.find({"thread_id": thread_id}))
        feedback_map = {}
        for fb in feedbacks:
            # item_ids is a list, typically contains one message_id in our usage
            item_ids = fb.get("item_ids")
            if isinstance(item_ids, list):
                for item_id in item_ids:
                    feedback_map[item_id] = fb.get("sentiment")

        for item in items:
            item.pop("_id", None)
            m_id = item.get("id")
            if m_id in feedback_map:
                item["feedback"] = feedback_map[m_id]

            if "created_at" in item and hasattr(item["created_at"], "isoformat"):
                item["created_at"] = item["created_at"].isoformat()
            if "updated_at" in item and hasattr(item["updated_at"], "isoformat"):
                item["updated_at"] = item["updated_at"].isoformat()
        return items

    def save_thread_item(self, thread_id: str, item: dict) -> None:
        """Save a chat item (message) to the database using upsert."""
        if "_id" in item:
            item.pop("_id")

        item["thread_id"] = thread_id
        if "created_at" not in item:
            item["created_at"] = datetime.now(UTC)

        m_id = item.get("id")
        if m_id:
            self.thread_items.replace_one(
                {"thread_id": thread_id, "id": m_id},
                item,
                upsert=True
            )
        else:
            self.thread_items.insert_one(item)

    def clear_thread_items_after(self, thread_id: str, timestamp: datetime) -> int:
        """Delete all thread items created after a specific timestamp for a thread."""
        result = self.thread_items.delete_many({
            "thread_id": thread_id,
            "created_at": {"$gt": timestamp}
        })
        return result.deleted_count

    def save_attachment(
        self, attachment_id: str, thread_id: str, user_id: str, media_type: str, filename: str | None = None
    ) -> None:
        """Save attachment metadata to the attachments collection."""
        doc = {
            "id": attachment_id,
            "thread_id": thread_id,
            "user_id": user_id,
            "media_type": media_type,
            "filename": filename,
            "created_at": datetime.now(UTC),
        }
        self.attachments.insert_one(doc)

    def update_thread_info(
        self, thread_id: str, title: str | None = None, user_id: str | None = None, **kwargs
    ) -> None:
        """Update thread metadata like title or user association."""
        update_doc = {}
        if title:
            update_doc["title"] = title
        if user_id:
            update_doc["user_id"] = user_id

        update_doc.update(kwargs)

        if update_doc:
            update_doc["updated_at"] = datetime.now(UTC)
            self.threads.update_one(
                {"id": thread_id}, {"$set": update_doc, "$setOnInsert": {"created_at": datetime.now(UTC)}}, upsert=True
            )

    def search_threads(
        self, query: str, skip: int = 0, limit: int = 50, feedback_filter: str | None = None
    ) -> list[dict]:
        """Search threads by user name, phone, title, IDs, or message content."""
        user_query = {
            "$or": [
                {"name": {"$regex": query, "$options": "i"}},
                {"surname": {"$regex": query, "$options": "i"}},
                {"phone": {"$regex": query, "$options": "i"}},
                {"id": query},
            ]
        }
        matching_users = list(self.users.find(user_query, {"id": 1}))
        user_ids = [u["id"] for u in matching_users]

        item_query = {
            "$or": [
                {"content": {"$regex": query, "$options": "i"}},
                {"content.text": {"$regex": query, "$options": "i"}},
                {"content.parts.text": {"$regex": query, "$options": "i"}},
            ]
        }
        item_thread_ids = self.thread_items.distinct("thread_id", item_query)

        thread_query = {
            "$or": [
                {"user_id": {"$in": user_ids}},
                {"title": {"$regex": query, "$options": "i"}},
                {"id": query},
                {"id": {"$in": item_thread_ids}},
            ]
        }

        if feedback_filter:
            fb_query = {}
            if feedback_filter == "liked":
                fb_query = {"sentiment": "like"}
            elif feedback_filter == "disliked":
                fb_query = {"sentiment": "dislike"}

            fb_thread_ids = self.feedbacks.distinct("thread_id", fb_query)
            thread_query = {"$and": [thread_query, {"id": {"$in": fb_thread_ids}}]}

        threads = list(self.threads.find(thread_query).sort("created_at", -1).skip(skip).limit(limit))

        # Fetch feedbacks to decorate results
        thread_ids = [t["id"] for t in threads]
        feedbacks = list(self.feedbacks.find({"thread_id": {"$in": thread_ids}}))
        feedback_counts = {}
        for fb in feedbacks:
            tid = fb["thread_id"]
            if tid not in feedback_counts:
                feedback_counts[tid] = {"like": 0, "dislike": 0}
            s = fb.get("sentiment")
            if s in feedback_counts[tid]:
                feedback_counts[tid][s] += 1

        for thread in threads:
            thread.pop("_id", None)
            if "created_at" in thread and hasattr(thread["created_at"], "isoformat"):
                thread["created_at"] = thread["created_at"].isoformat()
            if "updated_at" in thread and hasattr(thread["updated_at"], "isoformat"):
                thread["updated_at"] = thread["updated_at"].isoformat()

            thread["feedback_info"] = feedback_counts.get(thread["id"], {"like": 0, "dislike": 0})

            user = self.get_user(thread["user_id"])
            if user:
                thread["user_info"] = {
                    "name": user.name,
                    "surname": user.surname,
                    "phone": user.phone,
                }
        return threads

    def list_all_threads(self, skip: int = 0, limit: int = 50, feedback_filter: str | None = None) -> list[dict]:
        """List all threads across all users."""
        filter_doc = {}
        if feedback_filter:
            fb_query = {}
            if feedback_filter == "liked":
                fb_query = {"sentiment": "like"}
            elif feedback_filter == "disliked":
                fb_query = {"sentiment": "dislike"}

            thread_ids = self.feedbacks.distinct("thread_id", fb_query)
            filter_doc["id"] = {"$in": thread_ids}

        threads = list(self.threads.find(filter_doc).sort("created_at", -1).skip(skip).limit(limit))

        # Fetch feedbacks to decorate results
        thread_ids = [t["id"] for t in threads]
        feedbacks = list(self.feedbacks.find({"thread_id": {"$in": thread_ids}}))
        feedback_counts = {}
        for fb in feedbacks:
            tid = fb["thread_id"]
            if tid not in feedback_counts:
                feedback_counts[tid] = {"like": 0, "dislike": 0}
            s = fb.get("sentiment")
            if s in feedback_counts[tid]:
                feedback_counts[tid][s] += 1

        for thread in threads:
            thread.pop("_id", None)
            if "created_at" in thread and hasattr(thread["created_at"], "isoformat"):
                thread["created_at"] = thread["created_at"].isoformat()
            if "updated_at" in thread and hasattr(thread["updated_at"], "isoformat"):
                thread["updated_at"] = thread["updated_at"].isoformat()

            thread["feedback_info"] = feedback_counts.get(thread["id"], {"like": 0, "dislike": 0})

            user = self.get_user(thread["user_id"])
            if user:
                thread["user_info"] = {
                    "name": user.name,
                    "surname": user.surname,
                    "phone": user.phone,
                }
        return threads

    def get_thread_items_for_admin(self, thread_id: str) -> list[dict]:
        """Get all thread items for admin viewing."""
        items = list(self.thread_items.find({"thread_id": thread_id}).sort("created_at", 1))

        # Fetch feedbacks for this thread to decorate items
        feedbacks = list(self.feedbacks.find({"thread_id": thread_id}))
        feedback_map = {}
        for fb in feedbacks:
            item_ids = fb.get("item_ids")
            if isinstance(item_ids, list):
                for item_id in item_ids:
                    feedback_map[item_id] = fb.get("sentiment")

        for item in items:
            item.pop("_id", None)
            m_id = item.get("id")
            if m_id in feedback_map:
                item["feedback"] = feedback_map[m_id]

            if "created_at" in item and hasattr(item["created_at"], "isoformat"):
                item["created_at"] = item["created_at"].isoformat()
            if "updated_at" in item and hasattr(item["updated_at"], "isoformat"):
                item["updated_at"] = item["updated_at"].isoformat()
        return items
