import os
from collections.abc import Callable
from contextlib import asynccontextmanager
from enum import Enum
from typing import Any, Generic

import logfire
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic_ai import Agent

from .agents.deps import AgentDeps
from .api.router import api_router
from .constants import (
    APP_NAME,
    LOGFIRE_API_KEY,
    LOGFIRE_TOKEN,
    MINIO_ACCESS_KEY,
    MINIO_ENDPOINT,
    MINIO_SECRET_KEY,
    MONGODB_DB_NAME,
    MONGODB_PASSWORD,
    MONGODB_URI,
    MONGODB_USERNAME,
)
from .database import Database, UserDocument
from .storage import Storage


class GentiqApp[T_Context]:
    """
    The core application class for the Gentiq framework.

    GentiqApp serves as the central orchestration point, integrating FastAPI,
    PydanticAI, MongoDB, and MinIO into a cohesive environment for building
    advanced AI-driven applications.
    """

    def __init__(
        self,
        agent: Agent[AgentDeps[T_Context]],
        context: T_Context | None = None,
        context_factory: Callable[[UserDocument], T_Context] | None = None,
        app_name: str = APP_NAME,
        db_uri: str = MONGODB_URI,
        db_name: str = MONGODB_DB_NAME,
        db_username: str | None = MONGODB_USERNAME,
        db_password: str | None = MONGODB_PASSWORD,
        storage_endpoint: str = MINIO_ENDPOINT,
        storage_access_key: str = MINIO_ACCESS_KEY,
        storage_secret_key: str = MINIO_SECRET_KEY,
        storage_secure: bool = False,
    ):
        self.api = FastAPI(title=app_name, lifespan=self.lifespan)
        self.agent = agent
        self.context = context
        self.context_factory = context_factory

        # Initialize core components
        self.database = Database(uri=db_uri, db_name=db_name, username=db_username, password=db_password)
        self.storage = Storage(
            endpoint=storage_endpoint,
            access_key=storage_access_key,
            secret_key=storage_secret_key,
            secure=storage_secure,
        )

        self._setup_default_middleware()
        self._setup_default_routes()
        self._setup_monitoring()

    def add_middleware(self, middleware_class: type, **options: Any):
        """Add a middleware to the FastAPI application."""
        self.api.add_middleware(middleware_class, **options)

    def add_router(self, router: Any, prefix: str = "", tags: list[str | Enum] | None = None):
        """Include an external router into the application."""
        self.api.include_router(router, prefix=prefix, tags=tags)

    def create_agent_deps(self, user: UserDocument) -> AgentDeps[T_Context]:
        """Create a new instance of Agent dependencies for a specific user."""
        ctx = self.context
        if self.context_factory:
            ctx = self.context_factory(user)

        assert ctx is not None, "Context must be provided either via 'context' or 'context_factory'"
        return AgentDeps[T_Context](
            database=self.database,
            storage=self.storage,
            user=user,
            context=ctx,
        )

    @asynccontextmanager
    async def lifespan(self, app: FastAPI):
        """Manage the FastAPI application lifecycle."""
        app.state.database = self.database
        app.state.storage = self.storage
        app.state.agent = self.agent
        app.state.create_agent_deps = self.create_agent_deps
        yield

    def _setup_default_middleware(self):
        """Configure default middleware."""
        self.add_middleware(
            CORSMiddleware,
            allow_origins=["*"],
            allow_methods=["*"],
            allow_headers=["*"],
        )

    def _setup_default_routes(self):
        """Initialize core framework routes."""
        self.add_router(api_router, prefix="/api")

        @self.api.get("/health", tags=["System"])
        async def health_check() -> dict[str, str]:
            return {"status": "healthy"}

    def _setup_monitoring(self):
        """Configure observability and monitoring."""
        logfire.configure(send_to_logfire="if-token-present", api_key=LOGFIRE_API_KEY, token=LOGFIRE_TOKEN)
        logfire.instrument_pydantic_ai()
