"""
A lightweight agent that generates concise chat titles (2-8 words)
using gpt-5-nano. Designed to run as a fire-and-forget background task.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from pydantic_ai import Agent

from ..constants import OPENAI_HTTP_PROXY
from .utils import get_openai_model


if TYPE_CHECKING:
    from ..database import Database

logger = logging.getLogger(__name__)

TITLE_INSTRUCTIONS = (
    "You are a title generator. Given a user question and an assistant response, "
    "produce a short, descriptive title of 2 to 8 words that captures the topic. "
    "Output ONLY the title text — no quotes, no explanation, no punctuation at the end."
)

_title_model = get_openai_model("gpt-5-nano", proxy=OPENAI_HTTP_PROXY)

title_agent = Agent(
    name="TitleAgent",
    instructions=TITLE_INSTRUCTIONS,
    model=_title_model,
)


async def generate_title(
    question: str,
    answer: str,
    database: Database,
    thread_id: str,
) -> str | None:
    """Generate a title for a thread and persist it. Returns the title or None on failure."""
    try:
        # Truncate inputs to keep the prompt small and fast
        q = question[:500]
        a = answer[:500]
        prompt = f"User question:\n{q}\n\nAssistant response:\n{a}"

        result = await title_agent.run(prompt)
        title = result.output.strip()

        if title:
            # Enforce max length safety
            if len(title) > 80:
                title = title[:77] + "..."
            database.update_thread_info(thread_id, title=title, title_finalized=True)
            logger.info("Generated title for thread %s: %s", thread_id, title)
            return title
    except Exception:
        logger.exception("Title generation failed for thread %s — keeping fallback title", thread_id)
    return None
