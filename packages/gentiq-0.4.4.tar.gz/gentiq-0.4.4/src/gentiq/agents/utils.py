__all__ = ["get_openai_model"]


def get_openai_model(model_name: str, proxy: str | None = None):
    """
    Create OpenAI model with optional proxy.
    """
    import httpx
    from pydantic_ai.models.openai import OpenAIChatModel
    from pydantic_ai.providers.openai import OpenAIProvider

    if proxy:
        http_client = httpx.AsyncClient(
            proxy=proxy,
            timeout=30,
            follow_redirects=True,
        )
        provider = OpenAIProvider(http_client=http_client)
    else:
        provider = OpenAIProvider()

    openai_model = OpenAIChatModel(model_name=model_name, provider=provider)

    return openai_model
