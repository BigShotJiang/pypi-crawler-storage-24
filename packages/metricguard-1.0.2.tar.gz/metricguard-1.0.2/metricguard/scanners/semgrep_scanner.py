"""
MetricGuard v1.0.0 — SemgrepScanner: Multi-Language Analysis Engine.

Author: Yossi Cohen <Yossi85291@gmail.com>
GitHub: https://github.com/Yossi-Cohen19/

Provides cardinality explosion detection for Go, TypeScript, and Java by
invoking the Semgrep CLI as a subprocess and mapping its JSON output back
into the standard MetricGuard Finding model.

Design:
    - Inherits BaseScanner → plugs seamlessly into the existing Strategy pattern.
    - Semgrep is opt-in: if the binary is not installed, a warning is logged
      and an empty list is returned — the scan pipeline never crashes.
    - Custom rule YAML files are shipped inside the package (metricguard/rules/)
      so no internet access is required at scan time.
    - Output mapping is isolated in _parse_semgrep_output() for easy upgrades
      when the Semgrep JSON schema changes.
"""

from __future__ import annotations

import json
import logging
import shutil
import subprocess
from pathlib import Path
from typing import Any

from metricguard.core.config import MetricGuardConfig
from metricguard.core.scanner import BaseScanner
from metricguard.models.finding import Finding, FindingCategory, Severity

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────────────────────
# Package-relative rules directory
# ─────────────────────────────────────────────────────────────────────
_RULES_DIR = Path(__file__).parent.parent / "rules"

# Extension → rule file mapping
_EXT_TO_RULE: dict[str, Path] = {
    ".go": _RULES_DIR / "go_metrics.yml",
    ".ts": _RULES_DIR / "typescript_metrics.yml",
    ".tsx": _RULES_DIR / "typescript_metrics.yml",
    ".js": _RULES_DIR / "typescript_metrics.yml",
    ".jsx": _RULES_DIR / "typescript_metrics.yml",
    ".java": _RULES_DIR / "java_metrics.yml",
}

# Semgrep severity string → MetricGuard Severity enum
_SEMGREP_SEVERITY_MAP: dict[str, Severity] = {
    "ERROR": Severity.CRITICAL,
    "WARNING": Severity.HIGH,
    "INFO": Severity.MEDIUM,
    "NOTE": Severity.LOW,
}

# Rule ID prefix → FindingCategory
_RULE_PREFIX_TO_CATEGORY: dict[str, FindingCategory] = {
    "MG-GO-": FindingCategory.DYNAMIC_LABEL_VALUE,
    "MG-TS-": FindingCategory.DYNAMIC_LABEL_VALUE,
    "MG-JAVA-": FindingCategory.DYNAMIC_LABEL_VALUE,
}

# Extension → human-readable language name
_EXT_TO_LANGUAGE: dict[str, str] = {
    ".go": "go",
    ".ts": "typescript",
    ".tsx": "typescript",
    ".js": "javascript",
    ".jsx": "javascript",
    ".java": "java",
}


class SemgrepScanner(BaseScanner):
    """
    Multi-language cardinality scanner powered by custom Semgrep rules.

    Supports: Go (.go), TypeScript (.ts/.tsx), JavaScript (.js/.jsx), Java (.java).

    Invokes `semgrep` CLI as a subprocess — install via:
        pipx install semgrep
    or:
        pip install semgrep

    If semgrep is not available, returns [] gracefully with a logged WARNING.
    """

    # ── BaseScanner interface ────────────────────────────────────────

    @property
    def supported_extensions(self) -> frozenset[str]:
        return frozenset(_EXT_TO_RULE.keys())

    @property
    def scanner_name(self) -> str:
        return "Semgrep"

    def scan_file(self, file_path: Path, source: str) -> list[Finding]:
        """
        Run Semgrep rules for the given file and return zero or more Findings.

        Args:
            file_path: Path to the file on disk.
            source: Pre-read file content (passed by BaseScanner.scan — not used
                    directly here because Semgrep needs the file on disk, but we
                    accept it to conform to the BaseScanner interface).

        Returns:
            List of Finding objects. Empty if semgrep is not installed, if the
            file doesn't match any rule set, or if no issues are found.
        """
        # Check semgrep availability (cached per-process via _semgrep_available)
        if not _semgrep_available():
            logger.warning(
                "semgrep is not installed — skipping multi-language scan for %s. "
                "Install it with: pipx install semgrep",
                file_path,
            )
            return []

        rule_file = _EXT_TO_RULE.get(file_path.suffix.lower())
        if rule_file is None or not rule_file.exists():
            logger.debug("No Semgrep rule file for extension %s", file_path.suffix)
            return []

        raw_output = _invoke_semgrep(rule_file, file_path)
        if raw_output is None:
            return []

        return _parse_semgrep_output(raw_output, file_path, self.config)

    # ── Constructor ──────────────────────────────────────────────────

    def __init__(self, config: MetricGuardConfig) -> None:
        super().__init__(config)


# ─────────────────────────────────────────────────────────────────────
# Internal helpers
# ─────────────────────────────────────────────────────────────────────

_SEMGREP_CACHE: bool | None = None  # None = not yet checked


def _semgrep_available() -> bool:
    """Return True if the `semgrep` binary is on PATH (cached)."""
    global _SEMGREP_CACHE
    if _SEMGREP_CACHE is None:
        _SEMGREP_CACHE = shutil.which("semgrep") is not None
    return _SEMGREP_CACHE


def _invoke_semgrep(rule_file: Path, target: Path) -> dict[str, Any] | None:
    """
    Run Semgrep synchronously and return its parsed JSON output dict.

    Returns None on any subprocess or JSON parse error.
    """
    cmd = [
        "semgrep",
        "--config",
        str(rule_file),
        "--json",
        "--no-rewrite-rule-ids",
        "--quiet",
        str(target),
    ]

    try:
        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=60,  # hard wall for single-file scans
            check=False,  # semgrep exits 1 when findings exist — that's OK
        )
    except (subprocess.TimeoutExpired, OSError) as exc:
        logger.warning("Semgrep invocation failed for %s: %s", target, exc)
        return None

    if not result.stdout:
        return None

    try:
        return json.loads(result.stdout)  # type: ignore[no-any-return]
    except json.JSONDecodeError as exc:
        logger.warning("Failed to parse Semgrep JSON output for %s: %s", target, exc)
        return None


def _parse_semgrep_output(
    raw: dict[str, Any],
    file_path: Path,
    config: MetricGuardConfig,
) -> list[Finding]:
    """
    Map Semgrep JSON result objects to MetricGuard Finding instances.

    Semgrep JSON schema (stable since ≥v1.0):
    {
      "results": [
        {
          "check_id": "MG-GO-001",
          "path": "/abs/path/to/file.go",
          "start": {"line": 12, "col": 5},
          "end":   {"line": 12, "col": 42},
          "extra": {
            "message": "...",
            "severity": "WARNING",
            "lines": "counter.With(prometheus.Labels{\"user_id\": userId}).Inc()",
            "metadata": {}
          }
        }
      ],
      "errors": []
    }
    """
    findings: list[Finding] = []
    results = raw.get("results", [])

    for item in results:
        try:
            finding = _map_result_to_finding(item, file_path)
            if finding is not None:
                findings.append(finding)
        except Exception as exc:  # noqa: BLE001
            logger.debug("Failed to map Semgrep result item: %s — %s", item, exc)

    # Log any Semgrep errors so they're visible at DEBUG level
    for err in raw.get("errors", []):
        logger.debug("Semgrep reported error: %s", err.get("message", err))

    return findings


def _map_result_to_finding(
    item: dict[str, Any],
    file_path: Path,
) -> Finding | None:
    """Convert a single Semgrep result dict to a Finding object."""
    rule_id: str = item.get("check_id", "MG-UNKNOWN")
    # Strip rule file prefix that semgrep sometimes prepends (e.g. "go_metrics.MG-GO-001")
    if "." in rule_id and not rule_id.startswith("MG-"):
        rule_id = rule_id.split(".")[-1]

    extra = item.get("extra", {})
    semgrep_severity = extra.get("severity", "WARNING").upper()
    severity = _SEMGREP_SEVERITY_MAP.get(semgrep_severity, Severity.HIGH)

    # Determine FindingCategory from rule ID prefix
    category = FindingCategory.DYNAMIC_LABEL_VALUE
    for prefix, cat in _RULE_PREFIX_TO_CATEGORY.items():
        if rule_id.startswith(prefix):
            category = cat
            break

    start = item.get("start", {})
    line_number = int(start.get("line", 1))
    column_number = int(start.get("col", 1))

    message: str = extra.get("message", "High-cardinality metric label detected.")
    # Strip leading rule-id prefix that MetricGuard injects in the rule message
    # e.g. "[MetricGuard MG-GO-001] ..." → keep as-is for traceability
    if message.startswith("[MetricGuard "):
        # Extract just the body after the first ']'
        closing = message.find("]")
        if closing != -1:
            message = message[closing + 1 :].strip()

    offending_snippet: str | None = extra.get("lines")
    if offending_snippet:
        offending_snippet = offending_snippet.strip()

    language = _EXT_TO_LANGUAGE.get(file_path.suffix.lower(), "unknown")

    # Extract label/tag name from metavariable bindings if available
    label_or_tag_name: str | None = None
    metavars = extra.get("metavars", {})
    for candidate_key in ("$KEY", "$TAG_KEY", "$ATTR_KEY"):
        mv = metavars.get(candidate_key, {})
        if mv:
            label_or_tag_name = mv.get("abstract_content") or mv.get(
                "unique_id", {}
            ).get("value")
            if label_or_tag_name:
                # Strip surrounding quotes that semgrep may include
                label_or_tag_name = label_or_tag_name.strip("\"'")
                break

    return Finding(
        file_path=str(file_path),
        line_number=line_number,
        column_number=column_number,
        severity=severity,
        category=category,
        rule_id=rule_id,
        message=message,
        offending_code_snippet=offending_snippet,
        language=language,
        label_or_tag_name=label_or_tag_name,
    )
