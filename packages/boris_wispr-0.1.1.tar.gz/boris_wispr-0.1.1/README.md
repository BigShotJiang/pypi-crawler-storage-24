# Boris Wispr

Voice input engine for Boris TUI. Speak naturally, get clean text.

## Features

- **Whisper Detection** — Works with quiet/whispered speech via Silero VAD sensitivity tuning
- **Filler Word Removal** — Strips "um", "uh", "ahh", "like", "you know" automatically
- **File Tags (@)** — Say "at config dot py" and get `@config.py` — references files in your project
- **Hold-to-Talk** — Press and hold `Ctrl+Shift`, speak, release — text appears in Boris
- **Real-time Transcription** — Uses faster-whisper + Silero VAD for low-latency local processing

## Install

```bash
pip install boris-wispr
```

## Quick Start

```bash
# Standalone test
boris-wispr

# With Boris TUI integration
boris-wispr --boris
```

## Architecture

```
Microphone → VAD (Silero) → Audio Buffer → faster-whisper → Post-processor → Output
                                                              ├─ Filler removal
                                                              ├─ @ tag expansion
                                                              └─ Punctuation cleanup
```
