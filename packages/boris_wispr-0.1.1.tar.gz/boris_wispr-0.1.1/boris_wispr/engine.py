"""Core engine — orchestrates recording, VAD, transcription, post-processing, and output."""

import atexit
import json
import logging
import numpy as np
import threading
import time
import sys
import wave
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Callable, Any

from .config import WisprConfig
from .recorder import AudioRecorder
from .vad import VoiceActivityDetector
from .transcriber import Transcriber
from .postprocessor import PostProcessor
from .hotkey import HotkeyListener, HotkeyMode
from .boris_bridge import BorisBridge

logger = logging.getLogger(__name__)


_NOTIFICATION_SOUND = Path(__file__).parent / "assets" / "notification.wav"

# Track whether we've muted audio so atexit can unmute on crash
_audio_muted = False


def _mute_other_audio_sessions(mute: bool) -> None:
    """Mute or unmute all audio sessions except our own process.

    Uses pycaw (Windows Core Audio API) to set mute state on each active
    audio session.  Unlike Media Play/Pause, this is idempotent (not a
    toggle) and keeps media playing silently — so unmuting resumes audio
    seamlessly without any restart gap.
    """
    global _audio_muted
    if sys.platform != "win32":
        return
    try:
        import os
        from pycaw.pycaw import AudioUtilities
        from comtypes import CoInitialize, CoUninitialize

        # COM must be initialised on the calling thread
        CoInitialize()
        try:
            our_pid = os.getpid()
            sessions = AudioUtilities.GetAllSessions()
            for session in sessions:
                if session.Process and session.Process.pid != our_pid:
                    vol = session.SimpleAudioVolume
                    if vol is not None:
                        vol.SetMute(1 if mute else 0, None)
            _audio_muted = mute
        finally:
            CoUninitialize()
    except ImportError:
        # pycaw not installed — fall back to no-op
        logger.debug("pycaw not available, skipping audio mute/unmute")
    except Exception:
        logger.debug("Failed to mute/unmute audio sessions", exc_info=True)


def _atexit_unmute() -> None:
    """Safety net: unmute all audio sessions on process exit.

    Prevents the system from staying muted if boris-wispr crashes
    during recording.
    """
    if _audio_muted:
        _mute_other_audio_sessions(mute=False)


atexit.register(_atexit_unmute)


def _play_notification_async() -> None:
    """Play the notification sound without blocking.

    On Windows, uses winsound.SND_ASYNC so playback starts immediately on the
    calling thread and won't be affected by subsequent pycaw COM operations.
    On other platforms, uses a background thread with subprocess.
    """
    try:
        sound_path = str(_NOTIFICATION_SOUND)
        if sys.platform == "win32":
            import winsound
            winsound.PlaySound(
                sound_path,
                winsound.SND_FILENAME | winsound.SND_ASYNC | winsound.SND_NODEFAULT,
            )
        else:
            def _play():
                try:
                    import subprocess
                    if sys.platform == "darwin":
                        subprocess.run(["afplay", sound_path], check=False)
                    else:
                        subprocess.run(["mpg123", "-q", sound_path], check=False)
                except Exception:
                    logger.debug("Failed to play notification sound", exc_info=True)
            threading.Thread(target=_play, daemon=True).start()
    except Exception:
        logger.debug("Failed to play notification sound", exc_info=True)


class EngineStatus(str, Enum):
    """Status states for the engine lifecycle."""
    IDLE = "idle"
    LOADING = "loading"
    READY = "ready"
    RECORDING = "recording"
    PROCESSING = "processing"
    ERROR = "error"
    STOPPED = "stopped"


@dataclass
class SessionStats:
    """Tracks session-level statistics."""
    total_transcriptions: int = 0
    total_duration_ms: float = 0.0
    total_confidence: float = 0.0

    @property
    def average_confidence(self) -> float:
        if self.total_transcriptions == 0:
            return 0.0
        return self.total_confidence / self.total_transcriptions

    @property
    def average_duration_ms(self) -> float:
        if self.total_transcriptions == 0:
            return 0.0
        return self.total_duration_ms / self.total_transcriptions


class WisprEngine:
    """Main engine that ties all components together.

    Lifecycle: IDLE -> LOADING -> READY -> RECORDING -> PROCESSING -> READY
    """

    def __init__(
        self,
        config: WisprConfig | None = None,
        on_result: Callable[[str], None] | None = None,
        on_status: Callable[[str], None] | None = None,
        on_status_change: Callable[[EngineStatus], None] | None = None,
        on_transcription: Callable[[str, dict[str, Any]], None] | None = None,
        on_partial_transcription: Callable[[str], None] | None = None,
        on_model_progress: Callable[[str, float], None] | None = None,
    ):
        self.config = config or WisprConfig()

        # Callbacks
        self._on_result = on_result or self._default_output
        self._on_status_legacy = on_status  # legacy string-based status
        self._on_status_change = on_status_change
        self._on_transcription = on_transcription
        self._on_partial_transcription = on_partial_transcription
        self._on_model_progress = on_model_progress

        # Load custom vocabulary
        vocabulary = self._load_vocabulary()

        # Components
        self.recorder = AudioRecorder(
            sample_rate=self.config.sample_rate,
            channels=self.config.channels,
            chunk_duration_ms=self.config.chunk_duration_ms,
            device=self.config.audio_device,
        )
        self.vad = VoiceActivityDetector(
            threshold=self.config.vad_threshold,
            sample_rate=self.config.sample_rate,
            min_speech_ms=self.config.min_speech_ms,
            min_silence_ms=self.config.min_silence_ms,
            speech_pad_ms=self.config.speech_pad_ms,
        )
        self.transcriber = Transcriber(
            model_size=self.config.whisper_model,
            device=self.config.device,
            compute_type=self.config.compute_type,
            vocabulary=vocabulary,
        )
        self.postprocessor = PostProcessor(
            filler_words=self.config.filler_words if self.config.remove_fillers else [],
            project_dir=self.config.project_dir,
        )
        self.bridge = BorisBridge(
            mode=self.config.output_mode,
            socket_path=self.config.boris_socket,
        )

        # Toggle sound enabled flag
        self._toggle_sound = self.config.toggle_sound
        # Track whether we paused media so we can resume on release
        self._media_was_paused = False

        # Model loading state — track each model independently
        self._model_progress: dict[str, float] = {"vad": 0.0, "whisper": 0.0}

        # Lock to prevent streaming transcription from contending with final transcription.
        # CTranslate2 serializes concurrent access internally, but that means the final
        # transcription would wait for an in-progress streaming call (~1s delay).
        self._transcribe_lock = threading.Lock()

        # State
        self._status = EngineStatus.IDLE
        self._running = False
        self._cancel_requested = False
        self._hotkey_listener: HotkeyListener | None = None
        self._escape_listener = None
        self._streaming_timer: threading.Timer | None = None
        self._recording_audio_buffer: list[np.ndarray] = []
        self._lock = threading.Lock()
        self.stats = SessionStats()

    # -- Properties --

    @property
    def status(self) -> EngineStatus:
        return self._status

    @property
    def is_running(self) -> bool:
        return self._running

    # -- Status management --

    def _set_status(self, status: EngineStatus, detail: str | None = None) -> None:
        """Update engine status and fire callbacks."""
        old = self._status
        self._status = status
        logger.debug("Engine status: %s -> %s%s", old.value, status.value,
                      f" ({detail})" if detail else "")

        if self._on_status_change:
            try:
                self._on_status_change(status)
            except Exception:
                logger.exception("Error in on_status_change callback")

        if self._on_status_legacy:
            try:
                status_str = f"{status.value}:{detail}" if detail else status.value
                self._on_status_legacy(status_str)
            except Exception:
                logger.exception("Error in on_status callback")

    # -- Lifecycle --

    def start(self) -> None:
        """Start the engine: preload models, start hotkey listener."""
        self._running = True
        self._set_status(EngineStatus.LOADING)

        # Preload models concurrently in background threads
        vad_thread = threading.Thread(target=self._preload_vad, daemon=True)
        whisper_thread = threading.Thread(target=self._preload_whisper, daemon=True)
        vad_thread.start()
        whisper_thread.start()

        # Wait for both models in a separate thread so we don't block
        def _wait_for_models():
            vad_thread.join()
            whisper_thread.join()
            if self._running:
                self._set_status(EngineStatus.READY)

        threading.Thread(target=_wait_for_models, daemon=True).start()

        # Set up hotkey listener
        self._hotkey_listener = HotkeyListener(
            hotkey=self.config.hotkey,
            mode=HotkeyMode.HOLD,
            on_activate=self._on_hotkey_press,
            on_deactivate=self._on_hotkey_release,
        )
        self._hotkey_listener.start()

        # Set up escape listener for cancel
        self._start_escape_listener()

    def stop(self) -> None:
        """Stop the engine and clean up all components."""
        self._running = False
        self._cancel_requested = False

        if self.recorder.is_recording:
            self.recorder.stop()

        if self._hotkey_listener:
            self._hotkey_listener.stop()
            self._hotkey_listener = None

        self._stop_escape_listener()

        # Safety: unmute audio sessions if we muted them
        if self._media_was_paused:
            self._media_was_paused = False
            _mute_other_audio_sessions(mute=False)

        self._set_status(EngineStatus.STOPPED)

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, *exc):
        self.stop()

    # -- Model preloading --

    def _report_model_progress(self, model: str, progress: float) -> None:
        """Update combined model loading progress and fire callback.

        Shows whichever model is still loading (not yet at 100%).
        """
        self._model_progress[model] = progress
        if not self._on_model_progress:
            return
        # Find the model still loading (lowest progress) to display
        vad_p = self._model_progress.get("vad", 0.0)
        whisper_p = self._model_progress.get("whisper", 0.0)
        if vad_p < 1.0 and whisper_p < 1.0:
            # Both still loading — show whichever reported last
            self._on_model_progress(model, progress)
        elif vad_p < 1.0:
            self._on_model_progress("vad", vad_p)
        elif whisper_p < 1.0:
            self._on_model_progress("whisper", whisper_p)
        else:
            # Both done
            self._on_model_progress(model, 1.0)

    def _preload_vad(self) -> None:
        """Load VAD model with progress reporting."""
        try:
            self._report_model_progress("vad", 0.0)
            self.vad._load_model()
            self._report_model_progress("vad", 1.0)
            logger.info("VAD model loaded")
        except Exception as e:
            logger.exception("Failed to load VAD model")
            self._set_status(EngineStatus.ERROR, f"vad_load_failed: {e}")

    def _preload_whisper(self) -> None:
        """Load Whisper model with progress reporting."""
        try:
            self._report_model_progress("whisper", 0.0)
            self.transcriber._load_model()
            self._report_model_progress("whisper", 1.0)
            logger.info("Whisper model loaded")
        except Exception as e:
            logger.exception("Failed to load Whisper model")
            self._set_status(EngineStatus.ERROR, f"whisper_load_failed: {e}")

    # -- Hotkey handlers --

    def _on_hotkey_press(self) -> None:
        """Called when hold-to-talk key is pressed — start recording."""
        if not self._running or self._status not in (EngineStatus.READY,):
            return

        # CRITICAL: Save the foreground window BEFORE anything else.
        # This is the window the user clicked on (their target input field).
        # We must capture it now because recording/processing may shift focus.
        self.bridge.save_foreground_window()

        self._cancel_requested = False
        self._recording_audio_buffer.clear()

        # Play start recording sound BEFORE muting so pycaw doesn't interfere
        if self._toggle_sound:
            _play_notification_async()

        # Mute other audio sessions (YouTube, Spotify, etc.) for clean mic input
        if self.config.pause_media_on_record:
            self._media_was_paused = True
            _mute_other_audio_sessions(mute=True)

        self._set_status(EngineStatus.RECORDING)
        self.vad.reset()

        try:
            self.recorder.start()
            self._start_streaming()
        except RuntimeError as e:
            logger.error("Failed to start recording: %s", e)
            self._set_status(EngineStatus.ERROR, str(e))
            self._set_status(EngineStatus.READY)

    def _on_hotkey_release(self) -> None:
        """Called when hold-to-talk key is released — process audio."""
        if not self._running or self._status != EngineStatus.RECORDING:
            return

        # Unmute other audio sessions BEFORE playing sound so pycaw doesn't interfere
        if getattr(self, '_media_was_paused', False):
            self._media_was_paused = False
            _mute_other_audio_sessions(mute=False)

        # Stop streaming FIRST and grab the lock to ensure no streaming
        # transcription is in-flight when we start the final transcription.
        # This eliminates the lock-wait delay that was adding up to 500ms+.
        self._stop_streaming()

        # Check if cancel was requested
        if self._cancel_requested:
            self._cancel_requested = False
            if self.recorder.is_recording:
                self.recorder.stop()
            self._set_status(EngineStatus.READY)
            logger.info("Recording cancelled by user")
            return

        # Stop recorder and grab audio immediately
        audio = self.recorder.stop()

        # Check minimum duration (300ms)
        min_samples = int(self.config.sample_rate * 0.3)
        if len(audio) < min_samples:
            logger.debug("Recording too short (%d samples), discarding", len(audio))
            self._set_status(EngineStatus.READY)
            return

        self._set_status(EngineStatus.PROCESSING)

        # Process in background thread to keep UI responsive
        threading.Thread(
            target=self._process_audio,
            args=(audio,),
            daemon=True,
        ).start()

    # -- Cancel (Escape) --

    def cancel_recording(self) -> None:
        """Cancel the current recording (e.g., on Escape key)."""
        if self._status == EngineStatus.RECORDING:
            self._cancel_requested = True
            self._stop_streaming()
            if self.recorder.is_recording:
                audio = self.recorder.stop()
            # Unmute other audio sessions if we muted them
            if self._media_was_paused:
                self._media_was_paused = False
                _mute_other_audio_sessions(mute=False)
            self._set_status(EngineStatus.READY)
            logger.info("Recording cancelled")

    def _start_escape_listener(self) -> None:
        """Listen for Escape key to cancel recording."""
        try:
            from pynput import keyboard

            def on_press(key):
                try:
                    if key == keyboard.Key.esc and self._status == EngineStatus.RECORDING:
                        self.cancel_recording()
                except Exception:
                    pass

            self._escape_listener = keyboard.Listener(on_press=on_press)
            self._escape_listener.daemon = True
            self._escape_listener.start()
        except ImportError:
            logger.warning("pynput not available — Escape cancel disabled")

    def _stop_escape_listener(self) -> None:
        """Stop the escape key listener."""
        if self._escape_listener:
            self._escape_listener.stop()
            self._escape_listener = None

    # -- Audio processing pipeline --

    def _process_audio(self, audio: np.ndarray) -> None:
        """Full pipeline: VAD -> Transcribe -> PostProcess -> Bridge."""
        # Save audio in background to avoid blocking the transcription pipeline
        if self.config.save_audio:
            threading.Thread(target=self._save_audio, args=(audio.copy(),), daemon=True).start()
        start_time = time.monotonic()
        try:
            result = self.transcribe_buffer(audio)
            duration_ms = (time.monotonic() - start_time) * 1000
            logger.info("[TIMING] Full pipeline: %.0fms", duration_ms)

            if result:
                # Update stats
                self.stats.total_transcriptions += 1
                self.stats.total_duration_ms += duration_ms
                # Confidence from VAD isn't available here easily,
                # so we use 1.0 as default for stats
                self.stats.total_confidence += 1.0

                metadata = {
                    "duration_ms": duration_ms,
                    "audio_length_ms": len(audio) / self.config.sample_rate * 1000,
                    "confidence": 1.0,
                    "language": self.transcriber.detected_language or "en",
                }

                # Save to history
                self._save_history(result, metadata)

                # Fire transcription callback for TUI
                if self._on_transcription:
                    try:
                        self._on_transcription(result, metadata)
                    except Exception:
                        logger.exception("Error in on_transcription callback")

                # Send to output bridge
                try:
                    t_bridge = time.monotonic()
                    self.bridge.send(result, metadata=metadata)
                    logger.info("[TIMING] Bridge send total: %.0fms",
                                (time.monotonic() - t_bridge) * 1000)
                except Exception as e:
                    logger.error("Bridge output failed: %s", e)

                # Fire legacy result callback (skip in TUI mode to avoid stdout noise)
                if not self._on_transcription:
                    self._on_result(result)
            else:
                logger.debug("No speech detected in audio")
                audio_len_ms = len(audio) / self.config.sample_rate * 1000
                # Fire transcription callback with empty marker so TUI shows feedback
                if self._on_transcription:
                    try:
                        self._on_transcription("", {
                            "duration_ms": duration_ms,
                            "audio_length_ms": audio_len_ms,
                            "confidence": 0.0,
                            "no_speech": True,
                        })
                    except Exception:
                        pass
                # Set no_speech status — don't let finally clobber it immediately
                self._set_status(EngineStatus.READY, "no_speech")
                if self._on_status_legacy:
                    try:
                        self._on_status_legacy("no_speech")
                    except Exception:
                        pass
                return  # skip the finally READY override

            e2e_ms = (time.monotonic() - start_time) * 1000
            logger.info("[TIMING] === E2E total (release-to-paste): %.0fms ===", e2e_ms)

        except Exception as e:
            logger.exception("Transcription pipeline failed: %s", e)
            self._set_status(EngineStatus.ERROR, str(e))
            # Fire transcription callback with error so TUI can show it
            if self._on_transcription:
                try:
                    self._on_transcription("", {
                        "error": str(e),
                        "confidence": 0.0,
                    })
                except Exception:
                    pass
            # Hold error status for 3 seconds so user can see it
            time.sleep(3)
            if self._running:
                self._set_status(EngineStatus.READY)
            return  # skip finally

        if self._running:
            self._set_status(EngineStatus.READY)

    def transcribe_buffer(self, audio: np.ndarray) -> str:
        """Transcribe an audio buffer through the full pipeline.

        Pipeline: VAD trim -> Whisper transcription -> PostProcessor cleanup

        Uses VAD to trim leading/trailing silence from the audio before
        sending to Whisper. This is the biggest speed optimization because
        Whisper inference time scales linearly with audio duration.

        Segments are streamed live via on_partial_transcription as they decode.
        """
        t0 = time.monotonic()

        # Use VAD to trim silence — Whisper inference scales with audio length,
        # so removing silence at start/end is the single biggest speed lever.
        speech_audio = self._vad_trim(audio)
        t_vad = time.monotonic()
        trim_pct = (1.0 - len(speech_audio) / max(len(audio), 1)) * 100
        logger.info("[TIMING] VAD trim: %.0fms (removed %.0f%% silence, %.2fs -> %.2fs)",
                    (t_vad - t0) * 1000, trim_pct,
                    len(audio) / self.config.sample_rate,
                    len(speech_audio) / self.config.sample_rate)

        # If VAD found no speech at all, bail early
        if len(speech_audio) < int(self.config.sample_rate * 0.2):
            logger.debug("VAD trim: no speech segments found")
            return ""

        # Segment-level streaming callback — fires for each decoded segment
        def _on_segment(partial_text: str):
            if self._on_partial_transcription and partial_text.strip():
                try:
                    self._on_partial_transcription(partial_text.strip())
                except Exception:
                    pass

        # Acquire lock to ensure no streaming transcription is running concurrently.
        # Streaming uses non-blocking acquire, so it will skip if we hold this lock.
        t_lock = time.monotonic()
        self._transcribe_lock.acquire()
        lock_wait = (time.monotonic() - t_lock) * 1000
        if lock_wait > 5:
            logger.info("[TIMING] Waited %.0fms for streaming transcription to finish", lock_wait)
        try:
            # Transcribe with live segment callbacks
            t1 = time.monotonic()
            raw_text = self.transcriber.transcribe(
                speech_audio, self.config.sample_rate,
                on_segment=_on_segment,
            )
            t2 = time.monotonic()
            logger.info("[TIMING] Whisper transcribe: %.0fms", (t2 - t1) * 1000)
        finally:
            self._transcribe_lock.release()

        if not raw_text.strip():
            return ""

        # Post-process
        clean_text = self.postprocessor.process(raw_text)
        t3 = time.monotonic()
        logger.info("[TIMING] PostProcess: %.0fms", (t3 - t2) * 1000)
        return clean_text

    # -- VAD trimming --

    def _vad_trim(self, audio: np.ndarray) -> np.ndarray:
        """Fast RMS-based silence trimming from start/end of audio.

        Uses a simple sliding-window energy detector (not Silero VAD, which is
        too slow at ~1s overhead). Trims leading/trailing silence in <5ms,
        which reduces audio duration sent to Whisper — the #1 speed lever.
        """
        sr = self.config.sample_rate
        window_samples = int(sr * 0.03)  # 30ms analysis window
        if len(audio) < window_samples * 2:
            return audio

        # RMS threshold: anything below this is "silence"
        # Use a fraction of the audio's own energy to adapt to recording levels
        rms_full = float(np.sqrt(np.mean(audio ** 2)))
        threshold = max(rms_full * 0.1, 0.005)  # at least 0.005 to avoid trimming everything

        # Find first non-silent window (leading trim)
        start = 0
        for i in range(0, len(audio) - window_samples, window_samples):
            chunk_rms = float(np.sqrt(np.mean(audio[i:i + window_samples] ** 2)))
            if chunk_rms >= threshold:
                start = max(0, i - int(sr * 0.1))  # keep 100ms before speech
                break

        # Find last non-silent window (trailing trim)
        end = len(audio)
        for i in range(len(audio) - window_samples, window_samples, -window_samples):
            chunk_rms = float(np.sqrt(np.mean(audio[i:i + window_samples] ** 2)))
            if chunk_rms >= threshold:
                end = min(len(audio), i + window_samples + int(sr * 0.1))  # keep 100ms after speech
                break

        if start >= end:
            return audio

        return audio[start:end]

    # -- Vocabulary --

    def _load_vocabulary(self) -> list[str]:
        """Load custom vocabulary from file."""
        vocab_path = Path(self.config.vocabulary_file)
        if vocab_path.exists():
            try:
                words = [w.strip() for w in vocab_path.read_text(encoding="utf-8").splitlines()
                         if w.strip() and not w.startswith("#")]
                logger.info("Loaded %d custom vocabulary words", len(words))
                return words
            except Exception:
                logger.warning("Failed to load vocabulary from %s", vocab_path)
        return []

    # -- Streaming partial transcription --

    def _start_streaming(self) -> None:
        """Start periodic partial transcription during recording.

        Uses a shorter interval (0.5s default) for responsive live preview.
        Only transcribes the latest audio chunk to avoid redundant work.
        """
        interval = min(self.config.streaming_interval_s, 1.0)
        self._last_stream_len = 0  # track how much audio we've already seen

        def _stream_tick():
            if self._status != EngineStatus.RECORDING or not self._running:
                return
            audio = None
            with self._lock:
                if self._recording_audio_buffer:
                    audio = np.concatenate(self._recording_audio_buffer)
            if audio is not None and len(audio) > 8000:  # at least 0.5s of audio
                try:
                    # Only re-transcribe if we have meaningful new audio
                    if len(audio) > self._last_stream_len + 4000:
                        # Non-blocking: skip if final transcription is running
                        if self._transcribe_lock.acquire(blocking=False):
                            try:
                                self._last_stream_len = len(audio)
                                partial = self.transcriber.transcribe_streaming(
                                    audio, self.config.sample_rate)
                                if partial.strip() and self._on_partial_transcription:
                                    self._on_partial_transcription(partial.strip())
                            finally:
                                self._transcribe_lock.release()
                        else:
                            logger.debug("Streaming skipped — transcribe lock held")
                except Exception:
                    logger.debug("Streaming transcription failed", exc_info=True)
            # Schedule next tick
            if self._status == EngineStatus.RECORDING and self._running:
                self._streaming_timer = threading.Timer(interval, _stream_tick)
                self._streaming_timer.daemon = True
                self._streaming_timer.start()

        self._streaming_timer = threading.Timer(interval, _stream_tick)
        self._streaming_timer.daemon = True
        self._streaming_timer.start()

    def _stop_streaming(self) -> None:
        """Stop streaming timer and wait for any in-flight transcription.

        Acquires+releases the transcribe lock to ensure no streaming call
        is still running. This prevents the final transcription from
        waiting on a stale streaming call (which added up to 500ms+ delay).
        """
        if self._streaming_timer:
            self._streaming_timer.cancel()
            self._streaming_timer = None
        # Drain any in-flight streaming transcription
        self._transcribe_lock.acquire()
        self._transcribe_lock.release()

    # -- History --

    def _save_history(self, text: str, metadata: dict) -> None:
        """Append transcription to history JSONL file."""
        try:
            from datetime import datetime
            history_path = Path(self.config.history_file)
            history_path.parent.mkdir(parents=True, exist_ok=True)
            entry = {
                "timestamp": datetime.now().isoformat(),
                "text": text,
                "confidence": metadata.get("confidence", 1.0),
                "duration_ms": metadata.get("duration_ms", 0),
                "audio_length_ms": metadata.get("audio_length_ms", 0),
                "model": self.config.whisper_model,
                "language": self.transcriber.detected_language or "en",
            }
            with open(history_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry) + "\n")
        except Exception:
            logger.warning("Failed to save history", exc_info=True)

    # -- Audio export --

    def _save_audio(self, audio: np.ndarray) -> None:
        """Save recorded audio to WAV file for debugging."""
        if not self.config.save_audio:
            return
        try:
            from datetime import datetime
            rec_dir = Path(self.config.recordings_dir)
            rec_dir.mkdir(parents=True, exist_ok=True)
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            wav_path = rec_dir / f"recording_{ts}.wav"
            int16_audio = (audio * 32767).astype(np.int16)
            with wave.open(str(wav_path), "w") as wf:
                wf.setnchannels(1)
                wf.setsampwidth(2)
                wf.setframerate(self.config.sample_rate)
                wf.writeframes(int16_audio.tobytes())
            logger.debug("Saved audio to %s", wav_path)
        except Exception:
            logger.warning("Failed to save audio", exc_info=True)

    # -- Default output --

    def _default_output(self, text: str) -> None:
        """Default output handler — print to stdout."""
        print(f"\n>> {text}")
        sys.stdout.flush()


# -- CLI self-test --

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Boris Wispr Engine self-test")
    parser.add_argument("--test", action="store_true", help="Run component init test")
    args = parser.parse_args()

    if args.test:
        print("=== WisprEngine Component Test ===\n")
        statuses = []

        def track_status(s):
            statuses.append(s)
            print(f"  status -> {s.value}")

        def track_progress(model, progress):
            print(f"  model_progress: {model} = {progress:.0%}")

        def track_transcription(text, meta):
            print(f"  transcription: {text!r}  meta={meta}")

        config = WisprConfig()
        engine = WisprEngine(
            config=config,
            on_status_change=track_status,
            on_model_progress=track_progress,
            on_transcription=track_transcription,
        )

        # Verify all components initialized
        assert engine.recorder is not None, "Recorder not initialized"
        assert engine.vad is not None, "VAD not initialized"
        assert engine.transcriber is not None, "Transcriber not initialized"
        assert engine.postprocessor is not None, "PostProcessor not initialized"
        assert engine.bridge is not None, "BorisBridge not initialized"
        print("  [OK] All components initialized")

        # Verify status
        assert engine.status == EngineStatus.IDLE, f"Expected IDLE, got {engine.status}"
        print(f"  [OK] Initial status: {engine.status.value}")

        # Verify stats
        assert engine.stats.total_transcriptions == 0
        assert engine.stats.average_confidence == 0.0
        assert engine.stats.average_duration_ms == 0.0
        print("  [OK] Session stats initialized")

        # Verify cancel
        engine._status = EngineStatus.RECORDING
        engine.cancel_recording()
        assert engine.status == EngineStatus.READY, f"Expected READY after cancel, got {engine.status}"
        print("  [OK] Cancel returns to READY")

        # Verify status transitions
        engine._set_status(EngineStatus.LOADING)
        engine._set_status(EngineStatus.READY)
        engine._set_status(EngineStatus.RECORDING)
        engine._set_status(EngineStatus.PROCESSING)
        engine._set_status(EngineStatus.READY)
        expected = [EngineStatus.READY, EngineStatus.LOADING, EngineStatus.READY,
                    EngineStatus.RECORDING, EngineStatus.PROCESSING, EngineStatus.READY]
        assert statuses == expected, f"Status transitions wrong: {statuses} != {expected}"
        print("  [OK] Status transitions: LOADING -> READY -> RECORDING -> PROCESSING -> READY")

        # Verify stats tracking
        engine.stats.total_transcriptions = 3
        engine.stats.total_duration_ms = 1500.0
        engine.stats.total_confidence = 2.7
        assert engine.stats.average_confidence == 0.9
        assert engine.stats.average_duration_ms == 500.0
        print("  [OK] Stats tracking (avg confidence=0.9, avg duration=500ms)")

        print("\n=== All Tests Passed ===")
    else:
        parser.print_help()
