"""Boris Wispr — Voice input engine for Boris TUI."""

__version__ = "0.1.1"
