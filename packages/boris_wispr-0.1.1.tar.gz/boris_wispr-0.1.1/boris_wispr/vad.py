"""Voice Activity Detection using Silero VAD."""

import logging
import numpy as np
import collections

logger = logging.getLogger(__name__)


class VoiceActivityDetector:
    """Silero VAD wrapper for detecting speech segments, including whispers."""

    def __init__(self, threshold: float = 0.3, sample_rate: int = 16000,
                 min_speech_ms: int = 250, min_silence_ms: int = 500,
                 speech_pad_ms: int = 100):
        self.threshold = threshold
        self.sample_rate = sample_rate
        self.min_speech_samples = int(min_speech_ms * sample_rate / 1000)
        self.min_silence_samples = int(min_silence_ms * sample_rate / 1000)
        self.speech_pad_samples = int(speech_pad_ms * sample_rate / 1000)

        self._model = None
        self._is_speaking = False
        self._speech_buffer = collections.deque()
        self._silence_count = 0
        self._speech_count = 0

    def _load_model(self):
        """Lazy-load Silero VAD model."""
        if self._model is not None:
            return

        try:
            import torch
        except OSError as e:
            # Handles broken DLL errors (e.g. torchaudio entry point not found)
            logger.error("Failed to import torch (DLL error): %s", e)
            raise ImportError(f"torch import failed due to DLL error: {e}") from e
        # Try loading from local cache dir directly (skips GitHub API call entirely).
        # torch.hub.load with source='local' needs the actual cache path, not the
        # GitHub repo string.
        cache_dir = torch.hub.get_dir()
        local_repo = None
        from pathlib import Path
        for name in ("snakers4_silero-vad_master", "snakers4_silero-vad_main"):
            candidate = Path(cache_dir) / name
            if candidate.exists() and (candidate / "hubconf.py").exists():
                local_repo = str(candidate)
                break

        if local_repo:
            model, utils = torch.hub.load(
                repo_or_dir=local_repo,
                model="silero_vad",
                trust_repo=True,
                source="local",
            )
        else:
            # First run — must download from GitHub
            model, utils = torch.hub.load(
                repo_or_dir="snakers4/silero-vad",
                model="silero_vad",
                trust_repo=True,
            )
        self._model = model
        self._get_speech_timestamps = utils[0]

    def reset(self):
        """Reset detector state for new utterance."""
        self._is_speaking = False
        self._speech_buffer.clear()
        self._silence_count = 0
        self._speech_count = 0
        if self._model is not None:
            self._model.reset_states()

    def process_chunk(self, audio_chunk: np.ndarray) -> dict:
        """Process an audio chunk and return VAD result.

        Returns:
            dict with keys:
                - is_speech: bool
                - confidence: float (0-1)
                - should_finalize: bool (speech ended, ready to transcribe)
        """
        self._load_model()
        import torch  # safe after _load_model succeeded

        # Convert to torch tensor
        if audio_chunk.dtype != np.float32:
            audio_chunk = audio_chunk.astype(np.float32)
        tensor = torch.from_numpy(audio_chunk)

        # Get speech probability
        confidence = self._model(tensor, self.sample_rate).item()
        is_speech = confidence >= self.threshold

        result = {
            "is_speech": is_speech,
            "confidence": confidence,
            "should_finalize": False,
        }

        if is_speech:
            self._speech_count += len(audio_chunk)
            self._silence_count = 0
            if not self._is_speaking and self._speech_count >= self.min_speech_samples:
                self._is_speaking = True
        else:
            if self._is_speaking:
                self._silence_count += len(audio_chunk)
                if self._silence_count >= self.min_silence_samples:
                    result["should_finalize"] = True
                    self._is_speaking = False
                    self._speech_count = 0
                    self._silence_count = 0

        return result

    def get_speech_segments(self, audio: np.ndarray) -> list[dict]:
        """Get speech segments from a complete audio buffer.

        Returns list of dicts with 'start' and 'end' sample indices.
        """
        self._load_model()
        import torch

        if audio.dtype != np.float32:
            audio = audio.astype(np.float32)
        tensor = torch.from_numpy(audio)

        segments = self._get_speech_timestamps(
            tensor,
            self._model,
            threshold=self.threshold,
            sampling_rate=self.sample_rate,
            min_speech_duration_ms=int(self.min_speech_samples * 1000 / self.sample_rate),
            min_silence_duration_ms=int(self.min_silence_samples * 1000 / self.sample_rate),
            speech_pad_ms=int(self.speech_pad_samples * 1000 / self.sample_rate),
        )

        return [{"start": s["start"], "end": s["end"]} for s in segments]
