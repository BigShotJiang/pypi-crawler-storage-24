"""Microphone recording with hold-to-talk support."""

import argparse
import numpy as np
import threading
import queue
import sys
import time


def normalize(audio: np.ndarray) -> np.ndarray:
    """Ensure audio is float32 in [-1, 1] range."""
    audio = np.asarray(audio, dtype=np.float32)
    if audio.size == 0:
        return audio
    peak = np.max(np.abs(audio))
    if peak > 1.0:
        audio = audio / peak
    return np.clip(audio, -1.0, 1.0)


def auto_gain(audio: np.ndarray, target_rms: float = 0.12,
              max_gain_db: float = 40.0, gate_rms: float = 0.0005) -> np.ndarray:
    """Apply automatic gain control to boost quiet audio (whispers) without clipping.

    Args:
        audio: Float32 audio in [-1, 1] range.
        target_rms: Desired RMS level after gain (0.12 is moderate loudness).
        max_gain_db: Maximum gain in dB to prevent amplifying pure noise.
        gate_rms: Below this RMS, treat as silence and don't amplify (noise gate).

    Returns:
        Gain-adjusted float32 audio, soft-clipped to [-1, 1].
    """
    audio = np.asarray(audio, dtype=np.float32)
    if audio.size == 0:
        return audio

    rms = float(np.sqrt(np.mean(audio ** 2)))

    # Noise gate: if the signal is basically silence, don't amplify noise
    if rms < gate_rms:
        return audio

    # Calculate needed gain
    gain = target_rms / max(rms, 1e-10)

    # Cap the gain to prevent amplifying noise floor too much
    max_gain = 10.0 ** (max_gain_db / 20.0)  # dB to linear
    gain = min(gain, max_gain)

    # Apply gain
    audio = audio * gain

    # Soft clip using tanh to avoid harsh digital clipping
    # Only apply soft clipping if signal exceeds [-1, 1]
    peak = np.max(np.abs(audio))
    if peak > 0.95:
        # tanh soft clip: preserves signal shape, compresses peaks
        audio = np.tanh(audio)

    return np.clip(audio, -1.0, 1.0)


def list_devices() -> list[dict]:
    """List available audio input devices."""
    import sounddevice as sd

    devices = sd.query_devices()
    inputs = []
    for i, dev in enumerate(devices):
        if dev["max_input_channels"] > 0:
            inputs.append({
                "index": i,
                "name": dev["name"],
                "channels": dev["max_input_channels"],
                "sample_rate": dev["default_samplerate"],
            })
    return inputs


def find_device(identifier) -> int | None:
    """Find device index by name (substring match) or integer index."""
    import sounddevice as sd

    devices = sd.query_devices()

    # Try as integer index
    if isinstance(identifier, int):
        if 0 <= identifier < len(devices) and devices[identifier]["max_input_channels"] > 0:
            return identifier
        return None

    # Try as string — parse int or substring match
    if isinstance(identifier, str):
        try:
            idx = int(identifier)
            if 0 <= idx < len(devices) and devices[idx]["max_input_channels"] > 0:
                return idx
        except ValueError:
            pass

        # Substring match on name
        identifier_lower = identifier.lower()
        for i, dev in enumerate(devices):
            if dev["max_input_channels"] > 0 and identifier_lower in dev["name"].lower():
                return i

    return None


class AudioRecorder:
    """Records audio from microphone with VAD-aware buffering."""

    def __init__(self, sample_rate: int = 16000, channels: int = 1,
                 chunk_duration_ms: int = 30, device=None):
        self.sample_rate = sample_rate
        self.channels = channels
        self.chunk_size = int(sample_rate * chunk_duration_ms / 1000)
        self.device = device

        self._stream = None
        self._audio_queue: queue.Queue = queue.Queue()
        self._recording = False
        self._buffer: list[np.ndarray] = []
        self._lock = threading.Lock()

    def start(self):
        """Start recording from microphone."""
        import sounddevice as sd

        # Resolve device
        dev_index = None
        if self.device is not None:
            dev_index = find_device(self.device)
            if dev_index is None:
                raise RuntimeError(
                    f"Audio device not found: {self.device!r}. "
                    f"Available input devices:\n"
                    + "\n".join(f"  [{d['index']}] {d['name']}" for d in list_devices())
                )

        self._recording = True
        self._buffer.clear()
        # Drain any leftover chunks from previous session
        while not self._audio_queue.empty():
            try:
                self._audio_queue.get_nowait()
            except queue.Empty:
                break

        try:
            self._stream = sd.InputStream(
                samplerate=self.sample_rate,
                channels=self.channels,
                dtype="float32",
                blocksize=self.chunk_size,
                device=dev_index,
                callback=self._audio_callback,
            )
            self._stream.start()
        except sd.PortAudioError as e:
            self._recording = False
            self._stream = None
            raise RuntimeError(
                f"Failed to open audio device: {e}\n"
                "Make sure a microphone is connected and not in use by another application."
            ) from e

    def stop(self) -> np.ndarray:
        """Stop recording and return the full audio buffer."""
        self._recording = False

        if self._stream is not None:
            self._stream.stop()
            self._stream.close()
            self._stream = None

        # Drain the queue
        while not self._audio_queue.empty():
            try:
                chunk = self._audio_queue.get_nowait()
                self._buffer.append(chunk)
            except queue.Empty:
                break

        if not self._buffer:
            return np.array([], dtype=np.float32)

        raw = normalize(np.concatenate(self._buffer))
        return auto_gain(raw)

    def get_chunks(self, timeout: float = 0.1) -> list[np.ndarray]:
        """Get all available audio chunks from the queue."""
        chunks = []
        try:
            # Block for first chunk up to timeout
            chunks.append(self._audio_queue.get(timeout=timeout))
            # Then drain any remaining without blocking
            while True:
                chunks.append(self._audio_queue.get_nowait())
        except queue.Empty:
            pass
        return chunks

    def get_chunk(self, timeout: float = 0.1) -> np.ndarray | None:
        """Get the next audio chunk from the queue (for streaming mode)."""
        try:
            return self._audio_queue.get(timeout=timeout)
        except queue.Empty:
            return None

    def _audio_callback(self, indata, frames, time_info, status):
        """sounddevice callback — runs in audio thread."""
        if not self._recording:
            return

        chunk = indata[:, 0].copy() if indata.ndim > 1 else indata.copy().flatten()
        self._audio_queue.put(chunk)

        with self._lock:
            self._buffer.append(chunk)

    @property
    def is_recording(self) -> bool:
        return self._recording

    def get_buffer_duration(self) -> float:
        """Get current buffer duration in seconds."""
        with self._lock:
            total_samples = sum(len(c) for c in self._buffer)
        return total_samples / self.sample_rate


def self_test(device=None, duration: float = 2.0):
    """Record for `duration` seconds and report RMS level."""
    print(f"=== AudioRecorder Self-Test ===")
    print(f"Duration: {duration}s | Sample rate: 16000 Hz | Chunk: 480 samples")
    print()

    # List devices
    devs = list_devices()
    if not devs:
        print("ERROR: No input audio devices found.")
        print("Make sure a microphone is connected.")
        sys.exit(1)

    print("Available input devices:")
    for d in devs:
        print(f"  [{d['index']}] {d['name']} (channels={d['channels']}, sr={d['sample_rate']})")
    print()

    recorder = AudioRecorder(device=device)

    try:
        recorder.start()
    except RuntimeError as e:
        print(f"ERROR: {e}")
        sys.exit(1)

    print(f"Recording for {duration} seconds... Speak into your microphone!")

    chunk_count = 0
    start_time = time.time()
    while time.time() - start_time < duration:
        chunks = recorder.get_chunks(timeout=0.05)
        chunk_count += len(chunks)

    audio = recorder.stop()
    elapsed = time.time() - start_time

    print()
    print(f"Recording complete.")
    print(f"  Chunks received: {chunk_count}")
    print(f"  Total samples:   {len(audio)}")
    print(f"  Duration:        {len(audio) / 16000:.2f}s")

    if len(audio) > 0:
        rms = float(np.sqrt(np.mean(audio ** 2)))
        peak = float(np.max(np.abs(audio)))
        print(f"  RMS level:       {rms:.6f}")
        print(f"  Peak level:      {peak:.6f}")
        print(f"  Dtype:           {audio.dtype}")

        # Verify chunk shape
        test_rec = AudioRecorder(device=device)
        test_rec.start()
        time.sleep(0.15)
        chunk = test_rec.get_chunk(timeout=0.5)
        test_rec.stop()
        if chunk is not None:
            print(f"  Chunk shape:     {chunk.shape} (expected (480,))")
            assert chunk.dtype == np.float32, f"Expected float32, got {chunk.dtype}"
            assert chunk.shape == (480,), f"Expected (480,), got {chunk.shape}"
            print("  Chunk dtype:     float32 ✓")
            print("  Chunk size:      480 ✓")

        if rms < 0.0001:
            print("\n  WARNING: RMS is very low — microphone may be muted or not working.")
        else:
            print("\n  Microphone is working!")
    else:
        print("  WARNING: No audio captured. Check microphone connection.")

    print()
    print("=== Self-Test Complete ===")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Boris Wispr Audio Recorder")
    parser.add_argument("--test", action="store_true", help="Run self-test: record 2s and report RMS")
    parser.add_argument("--device", default=None, help="Audio device index or name")
    parser.add_argument("--list-devices", action="store_true", help="List available input devices")
    args = parser.parse_args()

    if args.list_devices:
        for d in list_devices():
            print(f"[{d['index']}] {d['name']} (channels={d['channels']}, sr={d['sample_rate']})")
    elif args.test:
        self_test(device=args.device)
    else:
        parser.print_help()
