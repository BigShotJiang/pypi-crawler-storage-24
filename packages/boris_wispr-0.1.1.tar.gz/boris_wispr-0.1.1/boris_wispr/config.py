"""Configuration for Boris Wispr."""

import json
from dataclasses import asdict, dataclass, field
from enum import Enum
from pathlib import Path


class OutputMode(str, Enum):
    STDOUT = "stdout"
    CLIPBOARD = "clipboard"
    BORIS = "boris"
    KEYBOARD = "keyboard"


CONFIG_DIR = Path.home() / ".boris-wispr"
CONFIG_FILE = CONFIG_DIR / "config.json"


@dataclass
class WisprConfig:
    # Audio settings
    sample_rate: int = 16000
    channels: int = 1
    dtype: str = "float32"
    chunk_duration_ms: int = 30
    audio_device: str | None = None  # Audio input device index or name substring

    # VAD settings
    vad_threshold: float = 0.3
    min_speech_ms: int = 250
    min_silence_ms: int = 300
    speech_pad_ms: int = 100

    # Whisper model settings
    whisper_model: str = "tiny.en"  # fastest usable model; base.en for higher accuracy
    device: str = "auto"
    compute_type: str = "auto"  # auto-selects: float16 on GPU, int8 on CPU

    # Hotkey
    hotkey: str = "ctrl+shift"

    # Post-processing
    remove_fillers: bool = True
    expand_file_tags: bool = True
    filler_words: list[str] = field(default_factory=lambda: [
        "um", "uh", "umm", "uhh", "ah", "ahh",
        "hmm", "hm", "er", "err",
    ])

    # Output
    output_mode: str = "stdout"
    project_dir: str | None = None
    boris_socket: str | None = None

    # History (M11)
    history_file: str = str(Path.home() / ".boris-wispr" / "history.jsonl")
    save_audio: bool = False
    recordings_dir: str = str(Path.home() / ".boris-wispr" / "recordings")
    vocabulary_file: str = str(Path.home() / ".boris-wispr" / "vocabulary.txt")
    streaming_interval_s: float = 0.5  # fast streaming for live preview
    toggle_sound: bool = True
    toggle_sound_volume: float = 0.3
    pause_media_on_record: bool = True  # Pause system audio (YouTube, music) when recording

    def save(self, path: Path | None = None) -> None:
        """Save config to JSON file."""
        p = path or CONFIG_FILE
        p.parent.mkdir(parents=True, exist_ok=True)
        data = asdict(self)
        p.write_text(json.dumps(data, indent=2), encoding="utf-8")

    @classmethod
    def load(cls, path: Path | None = None) -> "WisprConfig":
        """Load config from JSON file, falling back to defaults."""
        p = path or CONFIG_FILE
        if not p.exists():
            return cls()
        data = json.loads(p.read_text(encoding="utf-8"))
        valid_fields = {f.name for f in cls.__dataclass_fields__.values()}
        filtered = {k: v for k, v in data.items() if k in valid_fields}
        return cls(**filtered)
