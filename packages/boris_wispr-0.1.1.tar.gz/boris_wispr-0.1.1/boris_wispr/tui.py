"""Textual TUI for Boris Wispr — polished voice input interface."""

from __future__ import annotations

import random
import time
from datetime import datetime
from pathlib import Path

try:
    from textual.app import App, ComposeResult
    from textual.binding import Binding
    from textual.containers import Vertical, VerticalScroll
    from textual.reactive import reactive
    from textual.screen import ModalScreen
    from textual.widgets import Footer, Header, RichLog, Static
    from rich.text import Text

    HAS_TEXTUAL = True
except ImportError:
    HAS_TEXTUAL = False


if HAS_TEXTUAL:

    class HelpScreen(ModalScreen[None]):
        """Help overlay with all shortcuts and usage."""

        BINDINGS = [
            Binding("escape", "dismiss", "Close"),
            Binding("h", "dismiss", "Close"),
        ]

        def compose(self) -> ComposeResult:
            with Vertical(id="help-container"):
                yield Static("Boris Wispr \u2014 Help", id="help-title")
                yield Static(
                    "[b]Keyboard Shortcuts[/b]\n"
                    "\n"
                    "  [bold cyan]q[/]       Quit application\n"
                    "  [bold cyan]t[/]       Toggle output mode\n"
                    "  [bold cyan]m[/]       Show model info\n"
                    "  [bold cyan]c[/]       Clear transcript log\n"
                    "  [bold cyan]h[/]       Show/hide this help\n"
                    "  [bold cyan]Esc[/]     Cancel recording\n"
                    "\n"
                    "[b]Usage[/b]\n"
                    "\n"
                    "  Hold your hotkey (default: Ctrl+Shift) to record.\n"
                    "  Release to transcribe and output text.\n"
                    "  Press Esc while recording to cancel.\n"
                    "\n"
                    "[b]Output Modes[/b]\n"
                    "\n"
                    "  [bold]keyboard[/]    Type into focused window\n"
                    "  [bold]stdout[/]      Print to terminal\n"
                    "  [bold]clipboard[/]   Copy to clipboard\n"
                    "  [bold]boris[/]       Send via socket\n",
                    id="help-content",
                )
                yield Static("Press [bold]Esc[/] or [bold]h[/] to close", id="help-footer")

    class ModelInfoScreen(ModalScreen[None]):
        """Modal showing model and engine details."""

        BINDINGS = [
            Binding("escape", "dismiss", "Close"),
            Binding("m", "dismiss", "Close"),
        ]

        def __init__(self, info: str) -> None:
            super().__init__()
            self._info = info

        def compose(self) -> ComposeResult:
            with Vertical(id="model-container"):
                yield Static("Model Information", id="model-title")
                yield Static(self._info, id="model-content")
                yield Static("Press [bold]Esc[/] or [bold]m[/] to close", id="model-footer")

    class DeviceSelectScreen(ModalScreen[int | None]):
        """Startup screen to choose an audio input device."""

        BINDINGS = [
            Binding("escape", "dismiss(None)", "Use Default"),
        ]

        def __init__(self) -> None:
            super().__init__()
            self._devices: list[dict] = []
            self._selected: int = 0
            self._default_idx: int | None = None

        def compose(self) -> ComposeResult:
            with Vertical(id="device-select-container"):
                yield Static("Select Audio Input", id="device-select-title")
                yield Static("", id="device-select-hint")
                with VerticalScroll(id="device-list-scroll"):
                    yield Static("", id="device-list")
                yield Static(
                    "  [bold cyan]↑/↓[/]  Navigate    "
                    "[bold cyan]Enter[/]  Select    "
                    "[bold cyan]Esc[/]  Use Default",
                    id="device-select-footer",
                )

        def on_mount(self) -> None:
            try:
                from .recorder import list_devices
                import sounddevice as sd
                self._devices = list_devices()
                try:
                    self._default_idx = sd.default.device[0]
                except Exception:
                    self._default_idx = None
            except Exception:
                self._devices = []

            if not self._devices:
                self.query_one("#device-select-hint", Static).update(
                    "[dim]No input devices found — using system default[/]"
                )
                return

            # Find which entry is the default and pre-select it
            for i, d in enumerate(self._devices):
                if d["index"] == self._default_idx:
                    self._selected = i
                    break

            self._render_device_list()
            self.query_one("#device-select-hint", Static).update(
                f"[dim]{len(self._devices)} input device(s) found[/]"
            )

        def _render_device_list(self) -> None:
            lines = []
            for i, dev in enumerate(self._devices):
                marker = " ▸ " if i == self._selected else "   "
                default_tag = " [bold green](default)[/]" if dev["index"] == self._default_idx else ""
                style = "bold white on #0f3460" if i == self._selected else ""
                idx = dev["index"]
                name = dev["name"]
                ch = dev["channels"]
                sr = int(dev["sample_rate"])
                line = f"{marker}[{idx}] {name}  (ch={ch}, {sr}Hz){default_tag}"
                if style:
                    line = f"[{style}]{line}[/]"
                lines.append(line)
            self.query_one("#device-list", Static).update("\n".join(lines))

        def on_key(self, event) -> None:
            if not self._devices:
                return
            if event.key == "up":
                self._selected = max(0, self._selected - 1)
                self._render_device_list()
                event.prevent_default()
            elif event.key == "down":
                self._selected = min(len(self._devices) - 1, self._selected + 1)
                self._render_device_list()
                event.prevent_default()
            elif event.key == "enter":
                dev = self._devices[self._selected]
                self.dismiss(dev["index"])
                event.prevent_default()

    class TranscriptEntry:
        """One transcription result for display."""

        def __init__(self, text: str, confidence: float = 1.0,
                     duration_ms: float = 0.0, mode: str = "stdout"):
            self.text = text
            self.confidence = confidence
            self.duration_ms = duration_ms
            self.mode = mode
            self.timestamp = datetime.now()

        def render(self) -> Text:
            ts = self.timestamp.strftime("%H:%M:%S")
            if self.confidence >= 0.8:
                badge = Text("\u25cf", style="bold green")
            elif self.confidence >= 0.5:
                badge = Text("\u25cf", style="bold yellow")
            else:
                badge = Text("\u25cf", style="bold red")

            line = Text()
            line.append(f"[{ts}] ", style="dim")
            line.append_text(badge)
            line.append(" ")
            line.append(self.text, style="bold white")
            if self.duration_ms > 0:
                line.append(f"  ({self.duration_ms:.0f}ms)", style="dim cyan")
            line.append(f"  [{self.mode}]", style="dim")
            return line

    class WisprTUI(App):
        """Boris Wispr TUI \u2014 polished voice input interface."""

        TITLE = "Boris Wispr"
        SUB_TITLE = "v0.1.1"
        CSS_PATH = "tui.css"

        BINDINGS = [
            Binding("q", "quit", "Quit", priority=True),
            Binding("t", "toggle_mode", "Toggle Mode"),
            Binding("m", "model_info", "Model Info"),
            Binding("c", "clear_log", "Clear Log"),
            Binding("h", "help", "Help"),
        ]

        engine_status = reactive("idle")
        transcription_count = reactive(0)

        def __init__(self, engine=None, config=None):
            super().__init__()
            self.engine = engine
            self._config = config
            self._start_time = time.monotonic()
            self._entries: list[TranscriptEntry] = []
            self._waveform_timer = None
            self._spinner_frame = 0
            self._spinner_timer = None
            self._output_modes = ["keyboard", "clipboard", "stdout", "boris"]
            self._current_mode_idx = 0
            self._detected_language: str | None = None
            self._partial_text: str = ""
            if config and hasattr(config, "output_mode"):
                mode = config.output_mode
                # In TUI mode, "stdout" is useless (captured by Textual) — default to keyboard
                if mode == "stdout":
                    mode = "keyboard"
                    if config:
                        config.output_mode = "keyboard"
                if mode in self._output_modes:
                    self._current_mode_idx = self._output_modes.index(mode)

        def compose(self) -> ComposeResult:
            yield Header(show_clock=True)
            with Vertical(id="status-panel"):
                yield Static("\u25cb IDLE", id="status-icon")
                yield Static("Initializing...", id="status-text")
            yield Static("", id="waveform-panel")
            with Vertical(id="transcript-container"):
                yield RichLog(highlight=True, markup=True, wrap=True, id="transcript-log")
            yield Static(self._build_info_text(), id="info-bar")
            yield Footer()

        def on_mount(self) -> None:
            self._spinner_timer = self.set_interval(0.3, self._tick_spinner)
            self.set_interval(1.0, self._update_info_bar)
            self._apply_status("idle")
            # Show device selection screen on startup
            self.push_screen(DeviceSelectScreen(), callback=self._on_device_selected)

        def _on_device_selected(self, device_index: int | None) -> None:
            """Called when user picks a device (or presses Esc for default)."""
            if device_index is not None and self.engine:
                # Update the recorder's device before starting
                self.engine.recorder.device = device_index
                if self._config:
                    self._config.audio_device = str(device_index)
            self._start_engine()

        def _start_engine(self) -> None:
            """Wire up callbacks and start the engine."""
            if self.engine:
                self.engine._on_status_change = self._on_engine_status
                self.engine._on_transcription = self._on_engine_transcription
                self.engine._on_partial_transcription = self._on_engine_partial
                self.engine._on_model_progress = self._on_engine_model_progress
                self.engine._on_status_legacy = self._on_engine_status_legacy
                # Sync bridge mode — stdout is useless in TUI (captured by Textual)
                if hasattr(self.engine, "bridge") and self.engine.bridge.mode == "stdout":
                    self.engine.bridge.mode = "keyboard"
                self.engine.start()
            self._apply_status("loading" if self.engine else "idle")

        # -- Engine callbacks (may come from main or background threads) --

        def _safe_call(self, fn, *args) -> None:
            """Call fn on the main thread, whether invoked from main or worker."""
            import threading
            try:
                if threading.current_thread() is threading.main_thread():
                    fn(*args)
                else:
                    self.call_from_thread(fn, *args)
            except RuntimeError:
                fn(*args)

        def _on_engine_status(self, status) -> None:
            s = status.value if hasattr(status, "value") else str(status)
            # Check for detail in "ready:no_speech" format
            detail = None
            if hasattr(status, "value"):
                s = status.value
            else:
                s = str(status)
            self._safe_call(self._apply_status, s)

        def _on_engine_status_legacy(self, status: str) -> None:
            base = status.split(":")[0] if ":" in status else status
            self._safe_call(self._apply_status, base)

        def _on_engine_transcription(self, text: str, metadata: dict) -> None:
            self._safe_call(self._add_transcription, text, metadata)

        def _on_engine_partial(self, text: str) -> None:
            self._safe_call(self._update_partial, text)

        def _on_engine_model_progress(self, model: str, progress: float) -> None:
            if progress >= 1.0:
                msg = f"{model} loaded \u2714"
            else:
                msg = f"Loading {model}..."
            self._safe_call(self._update_status_text, msg)

        # -- Status management --

        def _apply_status(self, status: str) -> None:
            self.engine_status = status
            panel = self.query_one("#status-panel")
            icon_w = self.query_one("#status-icon", Static)
            text_w = self.query_one("#status-text", Static)
            wf = self.query_one("#waveform-panel", Static)

            for cls in ("status-loading", "status-ready", "status-recording",
                        "status-processing", "status-error"):
                panel.remove_class(cls)
            wf.remove_class("waveform-active")

            display = {
                "idle":       ("\u25cb", "IDLE",       "Waiting to start...",       "status-loading"),
                "loading":    ("\u25cc", "LOADING",    "Loading models...",         "status-loading"),
                "ready":      ("\u25cf", "READY",      "Press Ctrl+Shift to record",  "status-ready"),
                "recording":  ("\u25c9", "RECORDING",  "Listening...",              "status-recording"),
                "processing": ("\u25ce", "PROCESSING", "Transcribing...",           "status-processing"),
                "error":      ("\u2716", "ERROR",      "An error occurred",         "status-error"),
                "stopped":    ("\u25cb", "STOPPED",    "Engine stopped",            "status-loading"),
                "no_speech":  ("\u25cf", "READY",      "No speech detected",        "status-ready"),
                "too_short":  ("\u25cf", "READY",      "Too short \u2014 try again", "status-ready"),
            }
            icon_char, label, detail, css_cls = display.get(
                status, ("?", status.upper(), "", "status-loading"))

            icon_w.update(f"{icon_char} {label}")
            text_w.update(detail)
            panel.add_class(css_cls)

            if status == "recording":
                wf.add_class("waveform-active")
                if not self._waveform_timer:
                    self._waveform_timer = self.set_interval(0.1, self._tick_waveform)
            else:
                if self._waveform_timer:
                    self._waveform_timer.stop()
                    self._waveform_timer = None
                wf.update("")

        def _update_status_text(self, text: str) -> None:
            try:
                self.query_one("#status-text", Static).update(text)
            except Exception:
                pass

        def _update_partial(self, text: str) -> None:
            """Show partial/streaming transcription under waveform."""
            self._partial_text = text
            try:
                wf = self.query_one("#waveform-panel", Static)
                wf.update(f" [dim italic]{text}[/]")
            except Exception:
                pass

        # -- Waveform animation --

        def _tick_waveform(self) -> None:
            if self.engine_status != "recording":
                return
            blocks = "\u2581\u2582\u2583\u2584\u2585\u2586\u2587\u2588"
            width = 40
            levels = []
            if self.engine and hasattr(self.engine, "recorder") and self.engine.recorder.is_recording:
                try:
                    import numpy as np
                    chunks = self.engine.recorder.get_chunks()
                    if chunks:
                        for chunk in chunks[-width:]:
                            rms = float(np.sqrt(np.mean(chunk ** 2)))
                            idx = min(int(rms * 5000), len(blocks) - 1)
                            levels.append(blocks[idx])
                except Exception:
                    pass
            while len(levels) < width:
                levels.append(blocks[random.randint(0, 3)])
            bar = "".join(levels[-width:])
            try:
                self.query_one("#waveform-panel", Static).update(f" {bar} ")
            except Exception:
                pass

        def _tick_spinner(self) -> None:
            if self.engine_status in ("loading", "processing"):
                frames = "\u280b\u2819\u2839\u2838\u283c\u2834\u2826\u2827\u2807\u280f"
                self._spinner_frame = (self._spinner_frame + 1) % len(frames)
                icon = frames[self._spinner_frame]
                label = "LOADING" if self.engine_status == "loading" else "PROCESSING"
                try:
                    self.query_one("#status-icon", Static).update(f"{icon} {label}")
                except Exception:
                    pass

        # -- Transcript log --

        def _add_transcription(self, text: str, metadata: dict) -> None:
            self._partial_text = ""
            log = self.query_one("#transcript-log", RichLog)

            # Handle error feedback
            if metadata.get("error"):
                ts = datetime.now().strftime("%H:%M:%S")
                err_line = Text()
                err_line.append(f"[{ts}] ", style="dim")
                err_line.append("\u2716", style="bold red")
                err_line.append(f" Error: {metadata['error']}", style="red")
                log.write(err_line)
                self.notify(f"Transcription error: {metadata['error']}", severity="error", timeout=5)
                return

            # Handle no-speech feedback
            if metadata.get("no_speech") or (not text and metadata.get("confidence", 1.0) == 0.0):
                ts = datetime.now().strftime("%H:%M:%S")
                audio_ms = metadata.get("audio_length_ms", 0)
                ns_line = Text()
                ns_line.append(f"[{ts}] ", style="dim")
                ns_line.append("\u25cb", style="dim yellow")
                ns_line.append(" No speech detected", style="dim yellow")
                if audio_ms > 0:
                    ns_line.append(f"  ({audio_ms:.0f}ms audio)", style="dim")
                log.write(ns_line)
                self.notify("No speech detected — try speaking louder", timeout=3)
                return

            # Normal transcription
            lang = metadata.get("language")
            if lang:
                self._detected_language = lang
            mode = self._output_modes[self._current_mode_idx]
            entry = TranscriptEntry(
                text=text,
                confidence=metadata.get("confidence", 1.0),
                duration_ms=metadata.get("duration_ms", 0.0),
                mode=mode,
            )
            self._entries.append(entry)
            self.transcription_count = len(self._entries)
            log.write(entry.render())
            self._update_info_bar()

            # Show toast so user always sees what was transcribed
            preview = text[:80] + ("..." if len(text) > 80 else "")
            self.notify(f"[{mode}] {preview}", timeout=4)

        # -- Info bar --

        def _build_info_text(self) -> str:
            model = "base"
            hotkey = "ctrl+shift"
            mode = self._output_modes[self._current_mode_idx]
            count = len(self._entries)
            audio_dev = "default"
            if self._config:
                model = getattr(self._config, "whisper_model", "base")
                hotkey = getattr(self._config, "hotkey", "ctrl+shift")
                ad = getattr(self._config, "audio_device", None)
                if ad:
                    audio_dev = str(ad)
            elapsed = int(time.monotonic() - self._start_time)
            m, s = divmod(elapsed, 60)
            vad = "active" if self.engine_status not in ("idle", "stopped", "error") else "off"
            lang = self._detected_language or "\u2014"
            return (f" Mic: {audio_dev} \u2502 Model: {model} \u2502 VAD: {vad} \u2502 "
                    f"Mode: {mode} \u2502 Lang: {lang} \u2502 Transcriptions: {count} \u2502 "
                    f"Uptime: {m}m{s:02d}s \u2502 Hotkey: {hotkey}")

        def _update_info_bar(self) -> None:
            try:
                self.query_one("#info-bar", Static).update(self._build_info_text())
            except Exception:
                pass
            # Safety net: sync TUI status with actual engine status.
            # Catches missed transitions from background thread callbacks.
            if self.engine and hasattr(self.engine, "status"):
                actual = self.engine.status.value
                if actual != self.engine_status and actual in (
                    "ready", "error", "stopped"
                ):
                    self._apply_status(actual)

        # -- Actions --

        def action_toggle_mode(self) -> None:
            self._current_mode_idx = (self._current_mode_idx + 1) % len(self._output_modes)
            new_mode = self._output_modes[self._current_mode_idx]
            if self.engine and hasattr(self.engine, "bridge"):
                self.engine.bridge.mode = new_mode
            if self._config:
                self._config.output_mode = new_mode
            self._update_info_bar()
            self.notify(f"Output mode: {new_mode}", timeout=2)

        def action_model_info(self) -> None:
            model = device = compute = "?"
            audio_dev = "system default"
            if self._config:
                model = getattr(self._config, "whisper_model", "base")
                device = getattr(self._config, "device", "auto")
                compute = getattr(self._config, "compute_type", "int8")
                ad = getattr(self._config, "audio_device", None)
                if ad:
                    audio_dev = str(ad)
            # Try to resolve actual device name
            resolved_name = audio_dev
            try:
                from .recorder import list_devices, find_device
                if ad:
                    idx = find_device(ad)
                    if idx is not None:
                        devs = list_devices()
                        for d in devs:
                            if d["index"] == idx:
                                resolved_name = f"[{idx}] {d['name']}"
                                break
                else:
                    import sounddevice as sd
                    default_idx = sd.default.device[0]
                    if default_idx is not None and default_idx >= 0:
                        all_devs = sd.query_devices()
                        resolved_name = f"[{default_idx}] {all_devs[default_idx]['name']} (system default)"
            except Exception:
                pass
            stats = ""
            if self.engine and hasattr(self.engine, "stats"):
                st = self.engine.stats
                stats = (f"\n[b]Session Stats[/b]\n"
                         f"  Transcriptions:  {st.total_transcriptions}\n"
                         f"  Avg Confidence:  {st.average_confidence:.1%}\n"
                         f"  Avg Duration:    {st.average_duration_ms:.0f}ms")
            info = (f"[b]Whisper Model[/b]\n"
                    f"  Model Size:    {model}\n"
                    f"  Device:        {device}\n"
                    f"  Compute Type:  {compute}\n\n"
                    f"[b]Audio Input[/b]\n"
                    f"  Input Device:  {resolved_name}\n"
                    f"  Sample Rate:   16000 Hz\n"
                    f"  Channels:      1 (mono)\n"
                    f"  Chunk:         30ms{stats}")
            self.push_screen(ModelInfoScreen(info))

        def action_clear_log(self) -> None:
            self.query_one("#transcript-log", RichLog).clear()
            self._entries.clear()
            self.transcription_count = 0
            self._update_info_bar()
            self.notify("Transcript log cleared", timeout=2)

        def action_help(self) -> None:
            self.push_screen(HelpScreen())

        def on_unmount(self) -> None:
            if self._waveform_timer:
                self._waveform_timer.stop()
            if self._spinner_timer:
                self._spinner_timer.stop()
            if self.engine:
                self.engine.stop()


def run_tui(engine=None, config=None):
    """Launch the Boris Wispr TUI."""
    if not HAS_TEXTUAL:
        print("TUI requires textual: pip install boris-wispr[tui]")
        return
    app = WisprTUI(engine=engine, config=config)
    app.run()


if __name__ == "__main__":
    run_tui()
