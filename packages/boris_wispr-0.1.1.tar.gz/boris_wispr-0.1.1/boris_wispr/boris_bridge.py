"""Bridge between Boris Wispr and Boris TUI — sends transcribed text to Boris.

Supports multiple output backends:
  stdout   — JSON lines to stdout
  clipboard — pyperclip with OS fallbacks
  file     — append timestamped text to ~/.boris-wispr/wispr_input.txt
  socket   — Unix socket / Windows named pipe with retry
  keyboard — type into active window via clipboard+paste (Windows) or pynput (other)
"""

import json
import logging
import os
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

DEFAULT_OUTPUT_FILE = Path.home() / ".boris-wispr" / "wispr_input.txt"
SOCKET_RETRY_ATTEMPTS = 3
SOCKET_RETRY_DELAY = 1.0  # seconds, doubles each retry
KEYBOARD_CHAR_DELAY = 0.02  # seconds between keystrokes


# -- Windows foreground window helpers --

def _win_get_foreground_hwnd() -> int | None:
    """Get the handle of the current foreground window (Windows only)."""
    if sys.platform != "win32":
        return None
    try:
        import ctypes
        return ctypes.windll.user32.GetForegroundWindow()
    except Exception:
        return None


def _win_set_foreground_hwnd(hwnd: int) -> bool:
    """Restore a previously saved foreground window (Windows only).

    Uses multiple strategies to reliably bring the window to front,
    even when Windows restricts SetForegroundWindow.
    """
    if sys.platform != "win32" or not hwnd:
        return False
    try:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32

        # Validate window still exists
        if not user32.IsWindow(hwnd):
            logger.warning("Target hwnd=%s is no longer valid", hwnd)
            return False

        current_thread = ctypes.windll.kernel32.GetCurrentThreadId()
        target_thread = user32.GetWindowThreadProcessId(hwnd, None)

        attached = False
        if current_thread != target_thread:
            attached = bool(user32.AttachThreadInput(current_thread, target_thread, True))

        # Strategy 1: If window is minimized, restore it
        if user32.IsIconic(hwnd):
            user32.ShowWindow(hwnd, 9)  # SW_RESTORE

        # Strategy 2: Bring to top + set foreground
        user32.BringWindowToTop(hwnd)
        result = user32.SetForegroundWindow(hwnd)

        # Strategy 3: If SetForegroundWindow failed, use Alt key trick
        # Pressing and releasing Alt satisfies the "user initiated" requirement
        if not result:
            logger.debug("SetForegroundWindow failed, trying Alt key trick")
            user32.keybd_event(0x12, 0, 0, 0)  # VK_MENU (Alt) down
            user32.keybd_event(0x12, 0, 0x0002, 0)  # Alt up
            result = user32.SetForegroundWindow(hwnd)

        if attached:
            user32.AttachThreadInput(current_thread, target_thread, False)

        logger.debug("SetForegroundWindow result=%s for hwnd=%s", result, hwnd)
        return bool(result)
    except Exception as e:
        logger.warning("Failed to restore foreground window: %s", e)
        return False


class BorisBridge:
    """Connects wispr output to Boris TUI input via configurable backends."""

    def __init__(
        self,
        mode: str = "stdout",
        socket_path: str | None = None,
        output_file: str | None = None,
        keyboard_delay: float = KEYBOARD_CHAR_DELAY,
    ):
        self.mode = mode
        self.socket_path = socket_path
        self.output_file = Path(output_file) if output_file else DEFAULT_OUTPUT_FILE
        self.keyboard_delay = keyboard_delay
        # Saved foreground window handle — set by engine on hotkey press
        self._target_hwnd: int | None = None

    def save_foreground_window(self) -> None:
        """Capture the current foreground window so we can refocus it later.

        Called by the engine when the hotkey is pressed, BEFORE the TUI
        or terminal could steal focus.
        """
        self._target_hwnd = _win_get_foreground_hwnd()
        logger.debug("Saved target window hwnd=%s", self._target_hwnd)

    def send(self, text: str, metadata: dict[str, Any] | None = None) -> None:
        """Send transcribed text to the configured backend.

        Args:
            text: The transcription text to send.
            metadata: Optional dict with extra fields (confidence, language, etc.).
        """
        meta = metadata or {}
        dispatch = {
            "stdout": self._send_stdout,
            "clipboard": self._send_clipboard,
            "file": self._send_file,
            "socket": self._send_socket,
            "keyboard": self._send_keyboard,
        }
        handler = dispatch.get(self.mode)
        if handler is None:
            raise ValueError(f"Unknown output mode: {self.mode!r}")
        handler(text, meta)

    # ------------------------------------------------------------------
    # Backends
    # ------------------------------------------------------------------

    def _send_stdout(self, text: str, metadata: dict[str, Any]) -> None:
        """Emit a JSON line to stdout."""
        payload = {
            "type": "transcription",
            "text": text,
            "confidence": metadata.get("confidence", 1.0),
            "timestamp": metadata.get("timestamp", _now_iso()),
        }
        payload.update({k: v for k, v in metadata.items() if k not in payload})
        print(json.dumps(payload), flush=True)

    def _send_clipboard(self, text: str, metadata: dict[str, Any]) -> None:
        """Copy text to the system clipboard."""
        try:
            import pyperclip
            pyperclip.copy(text)
            logger.debug("Copied %d chars to clipboard via pyperclip", len(text))
            return
        except Exception:
            logger.debug("pyperclip unavailable, falling back to OS commands")

        # OS-level fallbacks
        import subprocess

        if sys.platform == "win32":
            subprocess.run(
                ["clip"],
                input=text.encode("utf-16le"),
                check=True,
            )
        elif sys.platform == "darwin":
            subprocess.run(["pbcopy"], input=text.encode(), check=True)
        else:
            # Linux — try xclip, then xsel
            for cmd in (["xclip", "-selection", "clipboard"], ["xsel", "--clipboard", "--input"]):
                try:
                    subprocess.run(cmd, input=text.encode(), check=True)
                    return
                except FileNotFoundError:
                    continue
            raise RuntimeError("No clipboard tool available (install xclip or xsel)")

    def _send_file(self, text: str, metadata: dict[str, Any]) -> None:
        """Append timestamped text to the output file."""
        self.output_file.parent.mkdir(parents=True, exist_ok=True)
        ts = metadata.get("timestamp", _now_iso())
        with open(self.output_file, "a", encoding="utf-8") as f:
            f.write(f"[{ts}] {text}\n")
        logger.debug("Appended to %s", self.output_file)

    def _send_socket(self, text: str, metadata: dict[str, Any]) -> None:
        """Send JSON via Unix socket or Windows named pipe with retry."""
        if not self.socket_path:
            raise ValueError("socket_path required for socket mode")

        payload = json.dumps({
            "type": "transcription",
            "text": text,
            "confidence": metadata.get("confidence", 1.0),
            "timestamp": metadata.get("timestamp", _now_iso()),
        }).encode()

        if sys.platform == "win32":
            self._send_named_pipe(payload)
        else:
            self._send_unix_socket(payload)

    def _send_named_pipe(self, payload: bytes) -> None:
        """Send via Windows named pipe with retry."""
        delay = SOCKET_RETRY_DELAY
        last_err: Exception | None = None
        for attempt in range(1, SOCKET_RETRY_ATTEMPTS + 1):
            try:
                with open(self.socket_path, "wb") as pipe:  # type: ignore[arg-type]
                    pipe.write(payload)
                logger.debug("Sent %d bytes via named pipe (attempt %d)", len(payload), attempt)
                return
            except (FileNotFoundError, OSError) as exc:
                last_err = exc
                logger.warning("Named pipe attempt %d failed: %s", attempt, exc)
                if attempt < SOCKET_RETRY_ATTEMPTS:
                    time.sleep(delay)
                    delay *= 2
        raise ConnectionError(
            f"Failed to send via named pipe after {SOCKET_RETRY_ATTEMPTS} attempts: {last_err}"
        )

    def _send_unix_socket(self, payload: bytes) -> None:
        """Send via Unix socket with retry."""
        import socket as sock

        delay = SOCKET_RETRY_DELAY
        last_err: Exception | None = None
        for attempt in range(1, SOCKET_RETRY_ATTEMPTS + 1):
            s = sock.socket(sock.AF_UNIX, sock.SOCK_STREAM)
            try:
                s.connect(self.socket_path)  # type: ignore[arg-type]
                s.sendall(payload)
                logger.debug("Sent %d bytes via unix socket (attempt %d)", len(payload), attempt)
                return
            except (ConnectionRefusedError, FileNotFoundError, OSError) as exc:
                last_err = exc
                logger.warning("Unix socket attempt %d failed: %s", attempt, exc)
                if attempt < SOCKET_RETRY_ATTEMPTS:
                    time.sleep(delay)
                    delay *= 2
            finally:
                s.close()
        raise ConnectionError(
            f"Failed to send via unix socket after {SOCKET_RETRY_ATTEMPTS} attempts: {last_err}"
        )

    def _send_keyboard(self, text: str, metadata: dict[str, Any]) -> None:
        """Type text into the target window using clipboard+paste.

        On Windows: restores the saved foreground window, copies text to
        clipboard, and sends Ctrl+V. This is universally reliable across
        browsers, Electron apps, native inputs, etc.

        On other platforms: falls back to pynput Controller.type().
        """
        # Brief delay to let the hotkey fully release
        time.sleep(0.02)

        if sys.platform == "win32":
            self._send_keyboard_win32(text)
        else:
            self._send_keyboard_pynput(text)

    def _send_keyboard_win32(self, text: str) -> None:
        """Windows-specific: refocus target window + clipboard paste."""
        import ctypes
        t_start = time.monotonic()

        # Step 1: Refocus the window the user was in when they pressed the hotkey
        if self._target_hwnd:
            current_fg = ctypes.windll.user32.GetForegroundWindow()
            if current_fg != self._target_hwnd:
                # Window lost focus (e.g., TUI stole it) — refocus
                _win_set_foreground_hwnd(self._target_hwnd)
                time.sleep(0.02)  # let Windows settle the focus
                current_fg = ctypes.windll.user32.GetForegroundWindow()
                if current_fg == self._target_hwnd:
                    logger.debug("Refocused target window hwnd=%s", self._target_hwnd)
                else:
                    logger.warning(
                        "Focus mismatch: wanted hwnd=%s, got hwnd=%s — pasting anyway",
                        self._target_hwnd, current_fg,
                    )
            else:
                logger.debug("Target window already focused hwnd=%s", self._target_hwnd)
        else:
            logger.warning("No saved target window — typing into current foreground")

        # Step 2: Save current clipboard, put our text in clipboard
        old_clipboard = None
        try:
            import pyperclip
            try:
                old_clipboard = pyperclip.paste()
            except Exception:
                pass
            pyperclip.copy(text)
            logger.debug("Copied %d chars to clipboard", len(text))
        except ImportError:
            # Fallback: use win32 clipboard API directly
            try:
                self._win32_set_clipboard(text)
                logger.debug("Copied %d chars to clipboard via win32 API", len(text))
            except Exception:
                # Last resort: clip command
                import subprocess
                subprocess.run(["clip"], input=text.encode("utf-16le"), check=True)
                logger.debug("Copied %d chars to clipboard via clip.exe", len(text))

        # Step 3: Send Ctrl+V to paste
        time.sleep(0.01)
        self._win32_send_paste()
        logger.info("[TIMING] Bridge keyboard inject: %.0fms", (time.monotonic() - t_start) * 1000)
        logger.debug("Pasted %d chars via Ctrl+V into target window", len(text))

        # Step 4: Restore old clipboard after a delay (so paste has time to complete)
        if old_clipboard is not None:
            import threading
            def _restore():
                time.sleep(1.0)
                try:
                    import pyperclip
                    pyperclip.copy(old_clipboard)
                except Exception:
                    pass
            threading.Thread(target=_restore, daemon=True).start()

    @staticmethod
    def _win32_set_clipboard(text: str) -> None:
        """Set clipboard text using Win32 API directly (no pyperclip needed)."""
        import ctypes
        from ctypes import wintypes

        CF_UNICODETEXT = 13
        GMEM_MOVEABLE = 0x0002

        kernel32 = ctypes.windll.kernel32
        user32 = ctypes.windll.user32

        encoded = text.encode("utf-16le") + b"\x00\x00"
        h_mem = kernel32.GlobalAlloc(GMEM_MOVEABLE, len(encoded))
        if not h_mem:
            raise RuntimeError("GlobalAlloc failed")

        ptr = kernel32.GlobalLock(h_mem)
        if not ptr:
            kernel32.GlobalFree(h_mem)
            raise RuntimeError("GlobalLock failed")

        ctypes.memmove(ptr, encoded, len(encoded))
        kernel32.GlobalUnlock(h_mem)

        if not user32.OpenClipboard(0):
            kernel32.GlobalFree(h_mem)
            raise RuntimeError("OpenClipboard failed")

        user32.EmptyClipboard()
        user32.SetClipboardData(CF_UNICODETEXT, h_mem)
        user32.CloseClipboard()

    def _win32_send_paste(self) -> None:
        """Send Ctrl+V keystroke using Win32 SendInput with correct struct sizing.

        The INPUT union MUST include MOUSEINPUT to ensure the correct struct
        size (40 bytes on 64-bit Windows). Without it, SendInput silently fails.
        """
        import ctypes
        from ctypes import wintypes

        INPUT_KEYBOARD = 1
        KEYEVENTF_KEYUP = 0x0002
        VK_CONTROL = 0x11
        VK_V = 0x56

        # -- Correct struct definitions with proper union sizing --
        class MOUSEINPUT(ctypes.Structure):
            _fields_ = [
                ("dx", wintypes.LONG),
                ("dy", wintypes.LONG),
                ("mouseData", wintypes.DWORD),
                ("dwFlags", wintypes.DWORD),
                ("time", wintypes.DWORD),
                ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong)),
            ]

        class KEYBDINPUT(ctypes.Structure):
            _fields_ = [
                ("wVk", wintypes.WORD),
                ("wScan", wintypes.WORD),
                ("dwFlags", wintypes.DWORD),
                ("time", wintypes.DWORD),
                ("dwExtraInfo", ctypes.POINTER(ctypes.c_ulong)),
            ]

        class HARDWAREINPUT(ctypes.Structure):
            _fields_ = [
                ("uMsg", wintypes.DWORD),
                ("wParamL", wintypes.WORD),
                ("wParamH", wintypes.WORD),
            ]

        class INPUT(ctypes.Structure):
            class _INPUT(ctypes.Union):
                _fields_ = [
                    ("mi", MOUSEINPUT),
                    ("ki", KEYBDINPUT),
                    ("hi", HARDWAREINPUT),
                ]
            _fields_ = [
                ("type", wintypes.DWORD),
                ("_input", _INPUT),
            ]

        user32 = ctypes.windll.user32

        def _make_key(vk: int, flags: int = 0) -> INPUT:
            inp = INPUT()
            inp.type = INPUT_KEYBOARD
            inp._input.ki.wVk = vk
            inp._input.ki.dwFlags = flags
            return inp

        # Send Ctrl+V via SendInput (correct struct size = 40 bytes)
        inputs = (INPUT * 4)(
            _make_key(VK_CONTROL),                        # Ctrl down
            _make_key(VK_V),                              # V down
            _make_key(VK_V, KEYEVENTF_KEYUP),             # V up
            _make_key(VK_CONTROL, KEYEVENTF_KEYUP),       # Ctrl up
        )
        sent = user32.SendInput(4, ctypes.byref(inputs), ctypes.sizeof(INPUT))
        logger.debug("SendInput returned %d (expected 4), sizeof(INPUT)=%d",
                      sent, ctypes.sizeof(INPUT))

    def _send_keyboard_pynput(self, text: str) -> None:
        """Non-Windows fallback: type via pynput."""
        try:
            from pynput.keyboard import Controller
        except ImportError:
            raise RuntimeError("pynput is required for keyboard mode (pip install pynput)")
        kb = Controller()
        kb.type(text)
        logger.debug("Typed %d chars via pynput into focused window", len(text))


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------

def _now_iso() -> str:
    """Return current UTC time as ISO-8601 string."""
    return datetime.now(timezone.utc).isoformat()


# ------------------------------------------------------------------
# CLI test harness: python -m boris_wispr.boris_bridge --test --mode <mode>
# ------------------------------------------------------------------

def _cli_test() -> None:
    """Quick smoke test for any output mode."""
    import argparse

    parser = argparse.ArgumentParser(description="BorisBridge test harness")
    parser.add_argument("--test", action="store_true", help="Run a smoke test")
    parser.add_argument("--mode", default="stdout", help="Output mode to test")
    parser.add_argument("--socket-path", default=None, help="Socket/pipe path for socket mode")
    parser.add_argument("--keyboard-delay", type=float, default=KEYBOARD_CHAR_DELAY)
    args = parser.parse_args()

    if not args.test:
        parser.print_help()
        return

    bridge = BorisBridge(
        mode=args.mode,
        socket_path=args.socket_path,
        keyboard_delay=args.keyboard_delay,
    )
    test_text = "Hello from BorisBridge test!"
    test_meta = {"confidence": 0.95, "language": "en"}

    print(f"Testing mode: {args.mode}")
    bridge.send(test_text, metadata=test_meta)
    print(f"OK — sent via {args.mode}")


if __name__ == "__main__":
    _cli_test()
