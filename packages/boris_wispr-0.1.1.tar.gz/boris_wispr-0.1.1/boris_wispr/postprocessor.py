"""Post-processing pipeline: filler removal, @ tag expansion, cleanup."""

import re
from pathlib import Path

# Non-word fillers: safe to remove anywhere — these are never real words
_SAFE_FILLERS = {
    "um", "uh", "umm", "uhh", "ah", "ahh",
    "hmm", "hm", "er", "err",
}


class PostProcessor:
    """Cleans up raw transcription into polished text."""

    def __init__(self, filler_words: list[str] | None = None,
                 project_dir: str | None = None):
        if filler_words is None:
            filler_words = list(_SAFE_FILLERS)

        # Sort by length (longest first) so multi-word fillers match before single-word
        self.filler_words = sorted(filler_words, key=len, reverse=True)
        self.project_dir = Path(project_dir) if project_dir else None
        self._file_cache: list[str] | None = None

    def process(self, text: str) -> str:
        """Run the full post-processing pipeline."""
        text = self._remove_fillers(text)
        text = self._expand_file_tags(text)
        text = self._cleanup(text)
        return text

    def _remove_fillers(self, text: str) -> str:
        """Remove non-word filler sounds (um, uh, etc.) from transcription.

        Only removes sounds that are never real words. Does NOT remove
        real English words like 'like', 'actually', 'basically' etc.
        which carry meaning in sentences.
        """
        for filler in self.filler_words:
            # Only remove fillers that are safe non-words
            if filler.lower() not in _SAFE_FILLERS:
                continue
            # Match filler as whole word/phrase, case-insensitive
            pattern = r'\b' + re.escape(filler) + r'\b'
            # Handle comma-separated fillers: "So, um, the thing" -> "So, the thing"
            text = re.sub(r',?\s*' + pattern + r'\s*,?', ' ', text, flags=re.IGNORECASE)
            # Handle standalone fillers
            text = re.sub(pattern, '', text, flags=re.IGNORECASE)

        return text

    def _expand_file_tags(self, text: str) -> str:
        """Convert spoken file references to @ tags.

        Handles patterns like:
          "at config dot py" -> @config.py
          "at src slash utils dot ts" -> @src/utils.ts
          "at package dot json" -> @package.json
        """
        # Pattern: "at <words> dot <extension>"
        pattern = r'\bat\s+([\w\s/\\]+?)\s+dot\s+(\w+)\b'

        def replace_file_tag(match):
            path_part = match.group(1).strip()
            ext = match.group(2).strip()

            # Convert "src slash utils" -> "src/utils"
            path_part = re.sub(r'\s+slash\s+', '/', path_part)
            path_part = re.sub(r'\s+backslash\s+', '\\\\', path_part)
            # Remove remaining spaces in path (e.g., "config" stays "config")
            path_part = path_part.replace(' ', '')

            filename = f"{path_part}.{ext}"

            # Verify file exists if project_dir is set
            if self.project_dir:
                resolved = self._resolve_file(filename)
                if resolved:
                    filename = resolved

            return f"@{filename}"

        text = re.sub(pattern, replace_file_tag, text, flags=re.IGNORECASE)

        # Also handle explicit "at sign" or "at symbol" patterns
        text = re.sub(r'\bat\s+sign\s+', '@', text, flags=re.IGNORECASE)
        text = re.sub(r'\bat\s+symbol\s+', '@', text, flags=re.IGNORECASE)

        return text

    def _resolve_file(self, filename: str) -> str | None:
        """Try to resolve a filename against the project directory."""
        if not self.project_dir or not self.project_dir.exists():
            return None

        # Build file cache on first use
        if self._file_cache is None:
            self._file_cache = []
            try:
                for p in self.project_dir.rglob("*"):
                    if p.is_file() and not any(
                        part.startswith('.') for part in p.relative_to(self.project_dir).parts
                    ):
                        self._file_cache.append(
                            str(p.relative_to(self.project_dir)).replace('\\', '/')
                        )
            except (PermissionError, OSError):
                pass

        # Exact match
        if filename in self._file_cache:
            return filename

        # Basename match
        for cached in self._file_cache:
            if cached.endswith('/' + filename) or cached == filename:
                return cached

        # Fuzzy: match just the filename part
        basename = filename.split('/')[-1]
        matches = [f for f in self._file_cache if f.endswith('/' + basename) or f == basename]
        if len(matches) == 1:
            return matches[0]

        return None

    def _cleanup(self, text: str) -> str:
        """Clean up whitespace, punctuation, capitalization."""
        # Collapse multiple spaces
        text = re.sub(r'\s{2,}', ' ', text)
        # Remove space before punctuation
        text = re.sub(r'\s+([.,!?;:])', r'\1', text)
        # Remove leading/trailing whitespace
        text = text.strip()
        # Capitalize first letter
        if text:
            text = text[0].upper() + text[1:]
        return text
