"""CLI entry point for Boris Wispr — subcommands for run, test, config, devices, history."""

import argparse
import json
import logging
import signal
import sys
import time
from pathlib import Path

from .config import WisprConfig

logger = logging.getLogger("boris_wispr")


STATUS_ICONS = {
    "loading_model": "[...] Loading models",
    "vad_loaded": "[OK] VAD ready",
    "whisper_loaded": "[OK] Whisper ready",
    "ready": "[MIC] Hold Ctrl+Shift to speak",
    "recording": "[REC] Listening...",
    "processing": "[...] Transcribing...",
    "too_short": "[!] Too short, try again",
    "no_speech": "[!] No speech detected",
    "stopped": "[X] Stopped",
}


def print_status(status: str):
    """Print status to stderr so it doesn't mix with transcription output."""
    msg = STATUS_ICONS.get(status, f"[?] {status}")
    print(f"\r{msg:<50}", end="", file=sys.stderr, flush=True)


def _build_config(args, saved: WisprConfig) -> WisprConfig:
    """Merge CLI args with saved config."""
    return WisprConfig(
        whisper_model=args.model or saved.whisper_model,
        device=args.device or saved.device,
        hotkey=args.hotkey or saved.hotkey,
        vad_threshold=args.sensitivity if args.sensitivity is not None else saved.vad_threshold,
        project_dir=args.project_dir or saved.project_dir,
        remove_fillers=not args.no_fillers if args.no_fillers else saved.remove_fillers,
        output_mode=args.output_mode or saved.output_mode,
        boris_socket=args.socket or saved.boris_socket,
        save_audio=getattr(args, "save_audio", False) or saved.save_audio,
        audio_device=getattr(args, "audio_device", None) or saved.audio_device,
        sample_rate=saved.sample_rate,
        channels=saved.channels,
        dtype=saved.dtype,
        chunk_duration_ms=saved.chunk_duration_ms,
        min_speech_ms=saved.min_speech_ms,
        min_silence_ms=saved.min_silence_ms,
        speech_pad_ms=saved.speech_pad_ms,
        filler_words=saved.filler_words,
        history_file=saved.history_file,
        recordings_dir=saved.recordings_dir,
        vocabulary_file=saved.vocabulary_file,
        streaming_interval_s=saved.streaming_interval_s,
        toggle_sound=saved.toggle_sound,
        toggle_sound_volume=saved.toggle_sound_volume,
    )


def _add_common_args(parser: argparse.ArgumentParser, saved: WisprConfig):
    """Add shared arguments to a subparser."""
    parser.add_argument("--model", default=None,
                        help=f"Whisper model size (tiny, base, small, medium, large-v3) [default: {saved.whisper_model}]")
    parser.add_argument("--device", default=None,
                        help=f"Device for inference (auto, cpu, cuda) [default: {saved.device}]")
    parser.add_argument("--hotkey", default=None,
                        help=f"Hold-to-talk hotkey [default: {saved.hotkey}]")
    parser.add_argument("--sensitivity", type=float, default=None,
                        help=f"VAD sensitivity 0-1 [default: {saved.vad_threshold}]")
    parser.add_argument("--output-mode", choices=["stdout", "clipboard", "boris", "keyboard"],
                        default=None,
                        help=f"Output mode [default: {saved.output_mode}]")
    parser.add_argument("--project-dir", "-d", default=None,
                        help="Project directory for @ file tag resolution")
    parser.add_argument("--no-fillers", action="store_true",
                        help="Keep filler words (don't remove them)")
    parser.add_argument("--socket", default=None,
                        help="Socket/pipe path for Boris bridge")
    parser.add_argument("--audio-device", default=None,
                        help="Audio input device index or name substring (e.g. '5' or 'Realtek')")
    parser.add_argument("--save-audio", action="store_true",
                        help="Save recorded audio to WAV files for debugging")
    parser.add_argument("--verbose", "-v", action="store_true",
                        help="Enable debug logging")


def _setup_logging(verbose: bool):
    """Configure logging level."""
    level = logging.DEBUG if verbose else logging.WARNING
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        stream=sys.stderr,
    )


# -- Subcommand handlers --

def cmd_run(args):
    """Run Boris Wispr (default command)."""
    saved = WisprConfig.load()
    _setup_logging(getattr(args, "verbose", False))
    config = _build_config(args, saved)

    from .engine import WisprEngine
    from . import __version__

    type_mode = getattr(args, "type", False)
    no_tui = getattr(args, "no_tui", False) or type_mode

    # --type implies headless + keyboard output
    if type_mode:
        config.output_mode = "keyboard"

    if no_tui:
        # Headless mode — JSON to stdout
        def json_output(text, metadata=None):
            entry = {"text": text}
            if metadata:
                entry.update(metadata)
            print(json.dumps(entry), flush=True)

        engine = WisprEngine(
            config=config,
            on_result=lambda text: json_output(text),
            on_status=print_status,
        )

        def signal_handler(sig, frame):
            engine.stop()
            sys.exit(0)

        signal.signal(signal.SIGINT, signal_handler)

        print(f"Boris Wispr v{__version__} (headless)", file=sys.stderr)
        print(f"Model: {config.whisper_model} | Sensitivity: {config.vad_threshold}", file=sys.stderr)
        print(f"Hotkey: {config.hotkey} (hold to speak)", file=sys.stderr)
        if config.project_dir:
            print(f"Project: {config.project_dir}", file=sys.stderr)
        print("", file=sys.stderr)

        engine.start()

        try:
            while True:
                time.sleep(0.1)
        except KeyboardInterrupt:
            engine.stop()
            print("\n", file=sys.stderr)
    else:
        # TUI mode
        from .tui import run_tui

        engine = WisprEngine(config=config)
        run_tui(engine=engine, config=config)


def cmd_test(args):
    """Run component self-tests."""
    _setup_logging(verbose=True)
    print("=== Boris Wispr Component Tests ===\n")

    # Mic test
    print("[1/4] Microphone...", end=" ", flush=True)
    try:
        from .recorder import AudioRecorder
        rec = AudioRecorder()
        rec.start()
        time.sleep(0.5)
        audio = rec.stop()
        rms = float((audio ** 2).mean() ** 0.5) if len(audio) > 0 else 0
        print(f"OK (RMS={rms:.6f}, samples={len(audio)})")
    except Exception as e:
        print(f"FAIL ({e})")

    # VAD test
    print("[2/4] VAD model...", end=" ", flush=True)
    try:
        from .vad import VoiceActivityDetector
        vad = VoiceActivityDetector()
        vad._load_model()
        print("OK")
    except Exception as e:
        print(f"FAIL ({e})")

    # Whisper test
    print("[3/4] Whisper model...", end=" ", flush=True)
    try:
        from .transcriber import Transcriber
        t = Transcriber()
        t._load_model()
        print(f"OK (device={t._resolve_device()})")
    except Exception as e:
        print(f"FAIL ({e})")

    # Hotkey test
    print("[4/4] Hotkey listener...", end=" ", flush=True)
    try:
        from .hotkey import HotkeyListener, HotkeyMode
        hl = HotkeyListener(hotkey="ctrl+shift", mode=HotkeyMode.HOLD,
                            on_activate=lambda: None, on_deactivate=lambda: None)
        print("OK")
    except Exception as e:
        print(f"FAIL ({e})")

    print("\n=== Tests Complete ===")


def cmd_config(args):
    """Show, set, or reset configuration."""
    saved = WisprConfig.load()
    action = getattr(args, "config_action", "show")

    if action == "show":
        from dataclasses import asdict
        data = asdict(saved)
        print(json.dumps(data, indent=2))
    elif action == "set":
        key = args.key
        value = args.value
        from dataclasses import asdict, fields
        valid_keys = {f.name for f in fields(WisprConfig)}
        if key not in valid_keys:
            print(f"Unknown config key: {key}", file=sys.stderr)
            print(f"Valid keys: {', '.join(sorted(valid_keys))}", file=sys.stderr)
            sys.exit(1)
        data = asdict(saved)
        # Type coercion
        current = data[key]
        if isinstance(current, bool):
            value = value.lower() in ("true", "1", "yes")
        elif isinstance(current, int):
            value = int(value)
        elif isinstance(current, float):
            value = float(value)
        data[key] = value
        valid_fields = {f.name for f in fields(WisprConfig)}
        filtered = {k: v for k, v in data.items() if k in valid_fields}
        new_config = WisprConfig(**filtered)
        new_config.save()
        print(f"Set {key} = {value}")
    elif action == "reset":
        config = WisprConfig()
        config.save()
        print("Config reset to defaults.")


def cmd_devices(args):
    """List available audio input devices."""
    try:
        import sounddevice as sd
        devices = sd.query_devices()
        print("Available audio input devices:\n")
        for i, dev in enumerate(devices):
            if dev["max_input_channels"] > 0:
                default = " [DEFAULT]" if i == sd.default.device[0] else ""
                print(f"  [{i}] {dev['name']} (channels={dev['max_input_channels']}, "
                      f"rate={dev['default_samplerate']:.0f}){default}")
    except Exception as e:
        print(f"Error listing devices: {e}", file=sys.stderr)
        sys.exit(1)


def cmd_history(args):
    """Search and browse transcription history."""
    saved = WisprConfig.load()
    history_path = Path(saved.history_file)

    if not history_path.exists():
        print("No history yet.")
        return

    query = getattr(args, "query", None)
    limit = getattr(args, "limit", 20)

    entries = []
    with open(history_path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                entries.append(json.loads(line))
            except json.JSONDecodeError:
                continue

    if query:
        q = query.lower()
        entries = [e for e in entries if q in e.get("text", "").lower()]

    # Show most recent first
    entries = entries[-limit:][::-1]

    if not entries:
        print("No matching transcriptions found.")
        return

    for entry in entries:
        ts = entry.get("timestamp", "?")[:19]
        text = entry.get("text", "")
        lang = entry.get("language", "?")
        model = entry.get("model", "?")
        dur = entry.get("duration_ms", 0)
        print(f"[{ts}] ({lang}, {model}, {dur:.0f}ms) {text}")


# -- Main entry point --

def main():
    """Main CLI entry point with subcommands."""
    saved = WisprConfig.load()

    parser = argparse.ArgumentParser(
        prog="boris-wispr",
        description="Boris Wispr — Voice input with whisper detection, filler removal, and @ tags",
    )

    subparsers = parser.add_subparsers(dest="command")

    # run (default)
    run_parser = subparsers.add_parser("run", help="Launch Boris Wispr (default)")
    _add_common_args(run_parser, saved)
    run_parser.add_argument("--no-tui", action="store_true",
                            help="Headless mode — JSON output to stdout")
    run_parser.add_argument("--type", action="store_true",
                            help="Type mode — headless with keyboard output (types into focused window)")

    # test
    subparsers.add_parser("test", help="Run component self-tests (mic, vad, whisper, hotkey)")

    # config
    config_parser = subparsers.add_parser("config", help="Show/set/reset configuration")
    config_sub = config_parser.add_subparsers(dest="config_action")
    config_sub.add_parser("show", help="Show current config")
    set_parser = config_sub.add_parser("set", help="Set a config value")
    set_parser.add_argument("key", help="Config key")
    set_parser.add_argument("value", help="Config value")
    config_sub.add_parser("reset", help="Reset config to defaults")

    # devices
    subparsers.add_parser("devices", help="List available audio input devices")

    # history
    hist_parser = subparsers.add_parser("history", help="Browse transcription history")
    hist_parser.add_argument("query", nargs="?", default=None,
                             help="Search query to filter results")
    hist_parser.add_argument("-n", "--limit", type=int, default=20,
                             help="Number of results to show (default: 20)")

    args = parser.parse_args()
    command = args.command

    # Default to 'run' if no subcommand given
    if command is None:
        # Re-parse with 'run' defaults
        args = run_parser.parse_args([])
        command = "run"

    handlers = {
        "run": cmd_run,
        "test": cmd_test,
        "config": cmd_config,
        "devices": cmd_devices,
        "history": cmd_history,
    }

    handler = handlers.get(command)
    if handler:
        handler(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
