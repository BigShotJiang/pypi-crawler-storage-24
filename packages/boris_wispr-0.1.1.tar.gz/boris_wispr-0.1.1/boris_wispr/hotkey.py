"""Hotkey listener for hold-to-talk and toggle modes."""

import platform
import sys
import threading
import time
from enum import Enum
from typing import Callable


class HotkeyMode(str, Enum):
    HOLD = "hold"      # Press to start, release to stop
    TOGGLE = "toggle"  # Press to start, press again to stop


# Map human-readable key names to pynput key representations
_KEY_MAP = {
    "ctrl": ["Key.ctrl_l", "Key.ctrl_r"],
    "shift": ["Key.shift", "Key.shift_l", "Key.shift_r"],
    "alt": ["Key.alt_l", "Key.alt_r", "Key.alt"],
    "cmd": ["Key.cmd", "Key.cmd_l", "Key.cmd_r"],
    "win": ["Key.cmd", "Key.cmd_l", "Key.cmd_r"],
    "super": ["Key.cmd", "Key.cmd_l", "Key.cmd_r"],
    "space": ["Key.space"],
    "enter": ["Key.enter"],
    "tab": ["Key.tab"],
    "esc": ["Key.esc"],
    "escape": ["Key.esc"],
    "backspace": ["Key.backspace"],
    "delete": ["Key.delete"],
    "up": ["Key.up"],
    "down": ["Key.down"],
    "left": ["Key.left"],
    "right": ["Key.right"],
    "home": ["Key.home"],
    "end": ["Key.end"],
    "page_up": ["Key.page_up"],
    "page_down": ["Key.page_down"],
    "caps_lock": ["Key.caps_lock"],
    "insert": ["Key.insert"],
}

# Add function keys f1-f20
for _i in range(1, 21):
    _KEY_MAP[f"f{_i}"] = [f"Key.f{_i}"]


def _normalize_key_str(key) -> str:
    """Normalize a pynput key object to a comparable string."""
    s = str(key)
    # Handle character keys like 'a', '1' — pynput wraps them in quotes
    if s.startswith("'") and s.endswith("'"):
        return s[1:-1].lower()
    return s


class HotkeyListener:
    """Listens for configurable hotkey with hold-to-talk and toggle modes.

    Supports:
    - Hold-to-talk: press hotkey combo to activate, release to deactivate
    - Toggle mode: press hotkey combo to activate, press again to deactivate
    - Configurable key combos: 'ctrl+shift', 'cmd+space', 'f5', etc.
    - Status callbacks for TUI integration
    - Auto-deactivate safety (focus-loss protection)
    """

    def __init__(
        self,
        hotkey: str = "ctrl+shift",
        mode: HotkeyMode = HotkeyMode.HOLD,
        on_press: Callable | None = None,
        on_release: Callable | None = None,
        on_activate: Callable | None = None,
        on_deactivate: Callable | None = None,
        on_status: Callable[[str], None] | None = None,
        auto_deactivate_ms: int = 60000,
    ):
        self.hotkey = hotkey
        self.mode = HotkeyMode(mode) if isinstance(mode, str) else mode
        # on_activate / on_deactivate are the primary API;
        # on_press / on_release kept for backward compat
        self._on_activate = on_activate or on_press
        self._on_deactivate = on_deactivate or on_release
        self._on_status = on_status

        self._listener = None
        self._pressed_keys: set[str] = set()
        self._is_active = False
        self._lock = threading.Lock()
        self._required_groups = self._parse_hotkey(hotkey)
        self._auto_deactivate_ms = auto_deactivate_ms
        self._activate_time: float | None = None
        self._safety_timer: threading.Timer | None = None
        self._stopped = threading.Event()

    # -- public properties --

    @property
    def is_held(self) -> bool:
        """Backward-compat alias for is_active."""
        return self._is_active

    @property
    def is_active(self) -> bool:
        return self._is_active

    # -- public callbacks --

    def on_activate(self, callback: Callable) -> None:
        """Register activation callback."""
        self._on_activate = callback

    def on_deactivate(self, callback: Callable) -> None:
        """Register deactivation callback."""
        self._on_deactivate = callback

    # -- hotkey parsing --

    @staticmethod
    def _parse_hotkey(hotkey: str) -> list[list[str]]:
        """Parse hotkey string into groups of acceptable key representations.

        For 'ctrl+shift', returns [['Key.ctrl_l','Key.ctrl_r'], ['Key.shift','Key.shift_l','Key.shift_r']]
        Each group represents one required key; any variant within the group satisfies it.
        """
        parts = [p.strip().lower() for p in hotkey.lower().split("+")]
        groups: list[list[str]] = []
        for part in parts:
            if part in _KEY_MAP:
                groups.append(_KEY_MAP[part])
            else:
                # Single character key or unknown — use as-is
                groups.append([part])
        return groups

    def _combo_satisfied(self) -> bool:
        """Check if the required key combo is currently fully pressed."""
        for group in self._required_groups:
            if not any(variant in self._pressed_keys for variant in group):
                return False
        return True

    # -- activation / deactivation --

    def _fire_activate(self) -> None:
        self._is_active = True
        self._activate_time = time.monotonic()
        self._emit_status("active")
        self._start_safety_timer()
        if self._on_activate:
            threading.Thread(target=self._on_activate, daemon=True).start()

    def _fire_deactivate(self) -> None:
        self._is_active = False
        self._activate_time = None
        self._cancel_safety_timer()
        self._emit_status("inactive")
        if self._on_deactivate:
            threading.Thread(target=self._on_deactivate, daemon=True).start()

    def _emit_status(self, status: str) -> None:
        if self._on_status:
            try:
                self._on_status(status)
            except Exception:
                pass

    # -- safety timer (auto-deactivate) --

    def _start_safety_timer(self) -> None:
        self._cancel_safety_timer()
        if self._auto_deactivate_ms > 0:
            self._safety_timer = threading.Timer(
                self._auto_deactivate_ms / 1000.0,
                self._safety_deactivate,
            )
            self._safety_timer.daemon = True
            self._safety_timer.start()

    def _cancel_safety_timer(self) -> None:
        if self._safety_timer:
            self._safety_timer.cancel()
            self._safety_timer = None

    def _safety_deactivate(self) -> None:
        """Auto-deactivate after timeout (handles focus-loss edge case)."""
        with self._lock:
            if self._is_active:
                self._fire_deactivate()

    # -- listener core --

    def start(self) -> None:
        """Start listening for hotkey in a background daemon thread."""
        from pynput import keyboard

        self._stopped.clear()
        self._emit_status("listening")

        def on_press(key):
            normalized = _normalize_key_str(key)
            with self._lock:
                self._pressed_keys.add(normalized)
                if not self._combo_satisfied():
                    return

                if self.mode == HotkeyMode.HOLD:
                    if not self._is_active:
                        self._fire_activate()
                else:  # TOGGLE
                    if self._is_active:
                        self._fire_deactivate()
                    else:
                        self._fire_activate()

        def on_release(key):
            normalized = _normalize_key_str(key)
            with self._lock:
                if self.mode == HotkeyMode.HOLD:
                    # Deactivate when ANY required key is released
                    is_required = any(
                        normalized in group for group in self._required_groups
                    )
                    if self._is_active and is_required:
                        self._fire_deactivate()
                # Toggle mode ignores release events for activation logic

                self._pressed_keys.discard(normalized)

        self._listener = keyboard.Listener(
            on_press=on_press,
            on_release=on_release,
        )
        self._listener.daemon = True
        self._listener.start()

    def stop(self) -> None:
        """Stop the hotkey listener and clean up."""
        self._cancel_safety_timer()
        if self._is_active:
            self._is_active = False
            self._emit_status("inactive")
        if self._listener:
            self._listener.stop()
            self._listener = None
        self._pressed_keys.clear()
        self._stopped.set()
        self._emit_status("stopped")

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, *exc):
        self.stop()


# -- CLI test mode --

def _test_mode():
    """Interactive test: prints hotkey press/release events to terminal."""
    import argparse

    parser = argparse.ArgumentParser(description="Test hotkey listener")
    parser.add_argument("--hotkey", default="ctrl+shift", help="Hotkey combo (default: ctrl+shift)")
    parser.add_argument("--mode", choices=["hold", "toggle"], default="hold", help="Hotkey mode")
    args = parser.parse_args()

    print(f"Hotkey listener test — hotkey={args.hotkey!r}  mode={args.mode}")
    print("Press the hotkey combo to test. Ctrl+C to exit.\n")

    def on_activate():
        print(f"[ACTIVATE] hotkey pressed  (mode={args.mode})")

    def on_deactivate():
        print(f"[DEACTIVATE] hotkey released  (mode={args.mode})")

    def on_status(status: str):
        print(f"  status -> {status}")

    listener = HotkeyListener(
        hotkey=args.hotkey,
        mode=HotkeyMode(args.mode),
        on_activate=on_activate,
        on_deactivate=on_deactivate,
        on_status=on_status,
    )
    listener.start()

    try:
        while True:
            time.sleep(0.1)
    except KeyboardInterrupt:
        print("\nStopping listener...")
        listener.stop()
        print("Done.")


if __name__ == "__main__":
    _test_mode()
