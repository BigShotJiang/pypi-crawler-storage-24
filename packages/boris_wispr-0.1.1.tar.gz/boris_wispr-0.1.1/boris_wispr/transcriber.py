"""Speech-to-text transcription using faster-whisper."""

import logging
import time
import numpy as np
from pathlib import Path
from typing import Callable

logger = logging.getLogger(__name__)


class Transcriber:
    """Wraps faster-whisper for local speech-to-text."""

    def __init__(self, model_size: str = "base.en", device: str = "auto",
                 compute_type: str = "auto", vocabulary: list[str] | None = None):
        self.model_size = model_size
        self.device = device
        self.compute_type = compute_type
        self._model = None
        self._vocabulary = vocabulary or []
        self.detected_language: str | None = None
        self._resolved_device: str | None = None

    def _load_model(self):
        """Lazy-load the whisper model."""
        if self._model is not None:
            return

        from faster_whisper import WhisperModel

        resolved_dev = self._resolve_device()
        resolved_compute = self._resolve_compute_type(resolved_dev)
        self._resolved_device = resolved_dev

        logger.info("Loading Whisper model=%s device=%s compute=%s",
                     self.model_size, resolved_dev, resolved_compute)

        self._model = WhisperModel(
            self.model_size,
            device=resolved_dev,
            compute_type=resolved_compute,
            num_workers=1,
            cpu_threads=4,
        )

    def _resolve_device(self) -> str:
        if self.device != "auto":
            return self.device
        try:
            import torch
            if torch.cuda.is_available():
                logger.info("CUDA GPU detected — using GPU acceleration")
                return "cuda"
        except (ImportError, OSError):
            # OSError handles broken DLL errors (e.g. torchaudio entry point not found)
            pass
        return "cpu"

    def _resolve_compute_type(self, device: str) -> str:
        """Pick optimal compute type based on device."""
        if self.compute_type != "auto":
            return self.compute_type
        if device == "cuda":
            return "float16"  # fp16 is fast on GPU
        return "int8"  # int8 is fastest on CPU

    def _build_initial_prompt(self) -> str | None:
        """Build initial prompt from custom vocabulary only.

        A shorter prompt reduces decoder overhead. Only include vocabulary
        hints when custom words are configured; otherwise skip the prompt
        entirely for maximum speed.
        """
        if self._vocabulary:
            return ", ".join(self._vocabulary[:30])
        return None

    def _prepare_audio(self, audio: np.ndarray) -> np.ndarray:
        """Ensure audio is float32 for Whisper.

        The recorder already applies normalize() and auto_gain(), so we
        only need a dtype cast here. Skipping redundant RMS/gain/tanh
        processing saves ~5-10ms per call.
        """
        if audio.dtype != np.float32:
            audio = audio.astype(np.float32)
        return audio

    def transcribe(self, audio: np.ndarray, sample_rate: int = 16000,
                   detect_language: bool = False, fast: bool = True,
                   on_segment: Callable[[str], None] | None = None) -> str:
        """Transcribe audio buffer to text.

        Args:
            audio: Float32 numpy array of audio samples
            sample_rate: Sample rate (must be 16000 for whisper)
            detect_language: Whether to auto-detect language
            fast: Use beam_size=1 for speed (default True for real-time)
            on_segment: Optional callback fired for each segment as it's decoded

        Returns:
            Transcribed text string
        """
        self._load_model()
        audio = self._prepare_audio(audio)

        prompt = self._build_initial_prompt()
        kwargs = dict(
            beam_size=1 if fast else 5,
            best_of=1,
            vad_filter=False,
            without_timestamps=True,
            language="en",
            condition_on_previous_text=False,
            temperature=0.0,
            no_speech_threshold=0.4,
            log_prob_threshold=-1.0,
            compression_ratio_threshold=2.8,
        )
        if prompt:
            kwargs["initial_prompt"] = prompt
        if detect_language:
            kwargs.pop("language", None)

        segments, info = self._model.transcribe(audio, **kwargs)

        if detect_language and hasattr(info, "language"):
            self.detected_language = info.language
            logger.debug("Detected language: %s (prob=%.2f)",
                         info.language, getattr(info, "language_probability", 0))

        text_parts = []
        for segment in segments:
            seg_text = segment.text.strip()
            if seg_text:
                text_parts.append(seg_text)
                if on_segment:
                    try:
                        on_segment(" ".join(text_parts))
                    except Exception:
                        logger.debug("on_segment callback failed", exc_info=True)

        return " ".join(text_parts)

    def transcribe_streaming(self, audio: np.ndarray,
                             sample_rate: int = 16000) -> str:
        """Quick partial transcription for streaming preview.

        Uses beam_size=1 and minimal settings for maximum speed.
        """
        self._load_model()
        audio = self._prepare_audio(audio)

        segments, info = self._model.transcribe(
            audio,
            beam_size=1,
            vad_filter=False,
            without_timestamps=True,
            language="en",
            condition_on_previous_text=False,
            temperature=0.0,
            no_speech_threshold=0.5,
        )

        text_parts = []
        for segment in segments:
            seg_text = segment.text.strip()
            if seg_text:
                text_parts.append(seg_text)

        return " ".join(text_parts)

    def transcribe_file(self, filepath: str | Path, sample_rate: int = 16000) -> str:
        """Transcribe an audio file."""
        self._load_model()

        segments, info = self._model.transcribe(
            str(filepath),
            beam_size=5,
            language="en",
            vad_filter=True,
            without_timestamps=True,
            initial_prompt=self._build_initial_prompt(),
        )

        text_parts = []
        for segment in segments:
            text_parts.append(segment.text.strip())

        return " ".join(text_parts)
