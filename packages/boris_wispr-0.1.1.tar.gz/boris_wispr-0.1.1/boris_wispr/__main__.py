"""Allow running boris-wispr as python -m boris_wispr."""

from boris_wispr.cli import main

if __name__ == "__main__":
    main()
