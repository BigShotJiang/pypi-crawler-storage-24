from setuptools import setup, find_packages
from pathlib import Path

long_description = Path(__file__).parent.joinpath("README.md").read_text(encoding="utf-8")

setup(
    name="boris-wispr",
    version="0.1.1",
    description="Voice input engine — hold-to-talk whisper detection, filler removal, @ file tags",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="David",
    url="https://github.com/david/boris-wispr",
    license="MIT",
    packages=find_packages(exclude=["tests", "tests.*"]),
    package_data={
        "boris_wispr": [
            "assets/*.wav",
            "assets/*.mp3",
            "tui.css",
        ],
    },
    include_package_data=True,
    python_requires=">=3.10",
    install_requires=[
        "faster-whisper>=1.0.0",
        "sounddevice>=0.4.6",
        "numpy>=1.24",
        "pynput>=1.7.6",
        "textual>=0.40",
        "rich>=13.0",
        "torch>=2.0",
        "pyperclip",
    ],
    extras_require={
        "windows": [
            "pycaw>=20230407",
            "comtypes",
        ],
    },
    entry_points={
        "console_scripts": [
            "boris-wispr=boris_wispr.cli:main",
        ],
    },
    classifiers=[
        "Development Status :: 4 - Beta",
        "Environment :: Console",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Operating System :: Microsoft :: Windows",
        "Operating System :: POSIX :: Linux",
        "Operating System :: MacOS",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Topic :: Multimedia :: Sound/Audio :: Speech",
    ],
)
