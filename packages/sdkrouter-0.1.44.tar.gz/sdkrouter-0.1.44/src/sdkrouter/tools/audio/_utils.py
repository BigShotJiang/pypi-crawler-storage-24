"""Audio utilities shared between STT and TTS modules."""

from __future__ import annotations

from pathlib import Path

# MIME types for common audio file extensions
AUDIO_MIME_TYPES = {
    ".mp3": "audio/mpeg",
    ".mp4": "audio/mp4",
    ".m4a": "audio/mp4",
    ".wav": "audio/wav",
    ".webm": "audio/webm",
    ".ogg": "audio/ogg",
    ".flac": "audio/flac",
    ".opus": "audio/opus",
    ".pcm": "audio/pcm",
}


def guess_mime_type(filename: str) -> str:
    """Guess MIME type from filename extension."""
    ext = Path(filename).suffix.lower()
    return AUDIO_MIME_TYPES.get(ext, "application/octet-stream")


def resolve_file(
    file: bytes | str | Path,
    filename: str | None,
) -> tuple[bytes, str]:
    """Resolve file input to (bytes, filename) tuple."""
    if isinstance(file, (str, Path)):
        path = Path(file)
        resolved_filename = filename or path.name
        file_bytes = path.read_bytes()
    else:
        resolved_filename = filename or "audio.mp3"
        file_bytes = file
    return file_bytes, resolved_filename


__all__ = [
    "AUDIO_MIME_TYPES",
    "guess_mime_type",
    "resolve_file",
]
