"""Payments customers domain — sync and async mixins."""

from __future__ import annotations

from typing import Any

from ...exceptions import api_error_handler, async_api_error_handler
from ..._api.generated.payments.payments__api__payments.models import (
    CustomerBalanceResponse,
    PaginatedCustomerTransactionResponseList,
)


class _CustomersMixin:
    """Sync customer methods."""

    _api: Any

    @api_error_handler
    def customer_balance(self, customer_id: str, project_slug: str) -> CustomerBalanceResponse:
        """Get customer balance."""
        return self._api.customer_balance_retrieve(customer_id, project_slug)

    @api_error_handler
    def customer_transactions(
        self,
        customer_id: str,
        project_slug: str,
        *,
        page: int = 1,
        page_size: int = 20,
    ) -> PaginatedCustomerTransactionResponseList:
        """List transactions for a customer."""
        return self._api.customer_transactions_list(
            customer_id,
            project_slug,
            page=page,
            page_size=page_size,
        )


class _AsyncCustomersMixin:
    """Async customer methods."""

    _api: Any

    @async_api_error_handler
    async def customer_balance(self, customer_id: str, project_slug: str) -> CustomerBalanceResponse:
        """Get customer balance."""
        return await self._api.customer_balance_retrieve(customer_id, project_slug)

    @async_api_error_handler
    async def customer_transactions(
        self,
        customer_id: str,
        project_slug: str,
        *,
        page: int = 1,
        page_size: int = 20,
    ) -> PaginatedCustomerTransactionResponseList:
        """List transactions for a customer."""
        return await self._api.customer_transactions_list(
            customer_id,
            project_slug,
            page=page,
            page_size=page_size,
        )
