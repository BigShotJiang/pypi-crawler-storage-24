"""Payments withdrawals domain — sync and async mixins."""

from __future__ import annotations

from decimal import Decimal
from typing import Any

from ...exceptions import api_error_handler, async_api_error_handler
from ..._api.generated.payments.payments__api__payments.models import (
    PaginatedCustomerWithdrawalResponseList,
    Withdrawal,
    WithdrawalCreateRequest,
)


class _WithdrawalsMixin:
    """Sync withdrawals methods."""

    _api: Any

    @api_error_handler
    def create_withdrawal(
        self,
        *,
        amount_usd: float | Decimal | str,
        network: str,
        wallet_address: str,
        customer_id: str,
        project_slug: str,
    ) -> Withdrawal:
        """Create a withdrawal request."""
        request = WithdrawalCreateRequest(
            amount_usd=str(amount_usd),
            network=network,
            wallet_address=wallet_address,
            customer_id=customer_id,
            project_slug=project_slug,
        )
        return self._api.withdrawals_create(request)

    @api_error_handler
    def list_withdrawals(
        self,
        *,
        page: int = 1,
        page_size: int = 20,
    ) -> PaginatedCustomerWithdrawalResponseList:
        """List withdrawal requests."""
        return self._api.customer_withdrawals_list(page=page, page_size=page_size)

    @api_error_handler
    def get_withdrawal(self, withdrawal_id: str) -> Withdrawal:
        """Get withdrawal details."""
        return self._api.withdrawals_retrieve(withdrawal_id)


class _AsyncWithdrawalsMixin:
    """Async withdrawals methods."""

    _api: Any

    @async_api_error_handler
    async def create_withdrawal(
        self,
        *,
        amount_usd: float | Decimal | str,
        network: str,
        wallet_address: str,
        customer_id: str,
        project_slug: str,
    ) -> Withdrawal:
        """Create a withdrawal request."""
        request = WithdrawalCreateRequest(
            amount_usd=str(amount_usd),
            network=network,
            wallet_address=wallet_address,
            customer_id=customer_id,
            project_slug=project_slug,
        )
        return await self._api.withdrawals_create(request)

    @async_api_error_handler
    async def list_withdrawals(
        self,
        *,
        page: int = 1,
        page_size: int = 20,
    ) -> PaginatedCustomerWithdrawalResponseList:
        """List withdrawal requests."""
        return await self._api.customer_withdrawals_list(page=page, page_size=page_size)

    @async_api_error_handler
    async def get_withdrawal(self, withdrawal_id: str) -> Withdrawal:
        """Get withdrawal details."""
        return await self._api.withdrawals_retrieve(withdrawal_id)
