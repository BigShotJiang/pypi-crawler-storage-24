"""Payments currencies domain — sync and async mixins.

NOTE: Currencies API has been removed from the backend.
These mixins are kept as empty stubs for backwards compatibility.
"""

from __future__ import annotations


class _CurrenciesMixin:
    """Sync currencies methods (removed from API)."""


class _AsyncCurrenciesMixin:
    """Async currencies methods (removed from API)."""
