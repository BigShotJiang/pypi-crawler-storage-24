"""Payments tool — cryptocurrency payments, balances, withdrawals.

Example::

    from sdkrouter import SDKRouter

    client = SDKRouter(api_key="sk_live_xxx")

    balance = client.payments.get_balance()
    invoice = client.payments.create(
        amount_usd="100.00",
        network="TRC20",
        customer_id="cust_xxx",
        project_slug="my-project",
    )
"""

from __future__ import annotations

from ._resource import AsyncPaymentsResource, PaymentsResource
from ..._api.generated.payments.payments__api__payments.models import (
    Balance,
    CustomerBalanceResponse,
    CustomerTransactionResponse,
    CustomerWithdrawalResponse,
    InvoiceCreateRequest,
    InvoiceDetail,
    InvoiceResponse,
    PaginatedCustomerTransactionResponseList,
    PaginatedCustomerWithdrawalResponseList,
    PaginatedInvoiceDetailList,
    PaginatedTransactionList,
    Transaction,
    Withdrawal,
    WithdrawalCreateRequest,
)

__all__ = [
    "PaymentsResource",
    "AsyncPaymentsResource",
    "Balance",
    "CustomerBalanceResponse",
    "CustomerTransactionResponse",
    "CustomerWithdrawalResponse",
    "InvoiceCreateRequest",
    "InvoiceDetail",
    "InvoiceResponse",
    "PaginatedCustomerTransactionResponseList",
    "PaginatedCustomerWithdrawalResponseList",
    "PaginatedInvoiceDetailList",
    "PaginatedTransactionList",
    "Transaction",
    "Withdrawal",
    "WithdrawalCreateRequest",
]
