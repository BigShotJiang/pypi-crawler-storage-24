"""Top-level Payments resources — PaymentsResource and AsyncPaymentsResource."""

from __future__ import annotations

from typing import Any

from ..._api.client import AsyncBaseResource, BaseResource
from ..._api.client import PaymentsPaymentsAPI, SyncPaymentsPaymentsAPI
from ..._api.generated.payments.payments__api__payments.models import (
    Balance,
    Transaction,
    PaginatedTransactionList,
)
from ..._config import SDKConfig
from ...exceptions import api_error_handler, async_api_error_handler
from ._credentials import _AsyncCredentialsMixin, _CredentialsMixin
from ._currencies import _AsyncCurrenciesMixin, _CurrenciesMixin
from ._customers import _AsyncCustomersMixin, _CustomersMixin
from ._payments import _AsyncPaymentsMixin, _PaymentsMixin
from ._withdrawals import _AsyncWithdrawalsMixin, _WithdrawalsMixin


class PaymentsResource(
    _PaymentsMixin,
    _CredentialsMixin,
    _CustomersMixin,
    _CurrenciesMixin,
    _WithdrawalsMixin,
    BaseResource,
):
    """Payments tool (sync).

    Provides cryptocurrency payment processing.

    Features:
    - Create and manage payment invoices
    - Check payment status
    - View balance and transactions
    - Request withdrawals
    - Manage provider credentials

    Example::

        client = SDKRouter(api_key="...")

        balance = client.payments.get_balance()
        payment = client.payments.create(
            amount_usd="100.00",
            currency_code="USDTTRC20",
        )
    """

    def __init__(self, config: SDKConfig) -> None:
        super().__init__(config)
        self._api = SyncPaymentsPaymentsAPI(self._http_client)

    @api_error_handler
    def get_balance(self) -> Balance:
        """Get current balance for the API key."""
        return self._api.balance_retrieve()

    @api_error_handler
    def list_transactions(
        self,
        *,
        page: int = 1,
        page_size: int = 20,
        transaction_type: str | None = None,
    ) -> PaginatedTransactionList:
        """List transactions."""
        return self._api.transactions_list(page=page, page_size=page_size)


class AsyncPaymentsResource(
    _AsyncPaymentsMixin,
    _AsyncCredentialsMixin,
    _AsyncCustomersMixin,
    _AsyncCurrenciesMixin,
    _AsyncWithdrawalsMixin,
    AsyncBaseResource,
):
    """Payments tool (async).

    Async version of PaymentsResource for use in async contexts.

    Example::

        client = AsyncSDKRouter(api_key="...")

        balance = await client.payments.get_balance()
        payment = await client.payments.create(
            amount_usd="100.00",
            currency_code="USDTTRC20",
        )
    """

    def __init__(self, config: SDKConfig) -> None:
        super().__init__(config)
        self._api = PaymentsPaymentsAPI(self._http_client)

    @async_api_error_handler
    async def get_balance(self) -> Balance:
        """Get current balance for the API key."""
        return await self._api.balance_retrieve()

    @async_api_error_handler
    async def list_transactions(
        self,
        *,
        page: int = 1,
        page_size: int = 20,
        transaction_type: str | None = None,
    ) -> PaginatedTransactionList:
        """List transactions."""
        return await self._api.transactions_list(page=page, page_size=page_size)


__all__ = [
    "PaymentsResource",
    "AsyncPaymentsResource",
]
