"""Types and result dataclasses for the banner generator."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

from pydantic import BaseModel, Field as PydanticField


# ── Pydantic schema for structured LLM output ────────────────────────────────

class BannerPrompt(BaseModel):
    prompt: str = PydanticField(
        description="Vivid, detailed image generation prompt, 150–250 words"
    )


# ── Result dataclass ──────────────────────────────────────────────────────────

@dataclass
class BannerResult:
    """Result of a banner generation call."""

    image_url: str
    """CDN URL of the generated image."""

    prompt: str
    """Final image generation prompt used."""

    preset: str
    """Size preset used (github, social, og, wide, square)."""

    size: str
    """Actual image dimensions, e.g. '1792x1024'."""

    model: str
    """Image generation model used."""

    llm_model: str | None
    """LLM model used for prompt enhancement (None if prompt was provided directly)."""

    cost_usd: float
    """Estimated total cost in USD (LLM + image gen)."""

    duration_ms: int
    """Total pipeline duration in milliseconds."""

    saved_to: Path | None = field(default=None)
    """Local file path if output= was specified, otherwise None."""

    @property
    def image_cdn_url(self) -> str:
        """Alias for image_url."""
        return self.image_url


__all__ = ["BannerPrompt", "BannerResult"]
