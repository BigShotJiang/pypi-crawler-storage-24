"""Proxies tool — manage proxies, rotations, assignments, and tests.

Modular proxy management capabilities:
- Proxies: CRUD, health monitoring, country filtering
- Rotations: rotation configuration management
- Assignments: proxy-to-parser assignment tracking
- Tests: connectivity and speed testing

Example::

    from sdkrouter import SDKRouter

    client = SDKRouter(api_key="sk_live_xxx")

    # List healthy Korean proxies
    healthy = client.proxies.get_healthy()

    # Create a rotation config
    rotation = client.proxies.create_rotation(
        name="Korean Proxies",
        allowed_countries=["KR"],
        min_success_rate=95.0,
    )

    # Run a test
    test = client.proxies.create_test(
        proxy="proxy-uuid",
        test_type="connectivity",
    )
"""

from __future__ import annotations

from ._resource import AsyncProxiesResource, ProxiesResource
from ..._api.generated.proxies.proxies__api__proxies.models import (
    Proxy,
    ProxyRequest,
    PatchedProxyRequest,
    PaginatedProxyList,
    ProxyAssignment,
    ProxyAssignmentRequest,
    PatchedProxyAssignmentRequest,
    PaginatedProxyAssignmentList,
    ProxyRotation,
    ProxyRotationRequest,
    PatchedProxyRotationRequest,
    PaginatedProxyRotationList,
    ProxyTest,
    ProxyTestRequest,
    PatchedProxyTestRequest,
    PaginatedProxyTestList,
)
from ..._api.generated.proxies.enums import (
    PatchedProxyRequestProxyType as ProxyType,
    PatchedProxyRequestProxyMode as ProxyMode,
    PatchedProxyRequestStatus as ProxyStatus,
    PatchedProxyTestRequestTestType as ProxyTestType,
)

__all__ = [
    # Resources
    "ProxiesResource",
    "AsyncProxiesResource",
    # Proxy models
    "Proxy",
    "ProxyRequest",
    "PatchedProxyRequest",
    "PaginatedProxyList",
    # Assignment models
    "ProxyAssignment",
    "ProxyAssignmentRequest",
    "PatchedProxyAssignmentRequest",
    "PaginatedProxyAssignmentList",
    # Rotation models
    "ProxyRotation",
    "ProxyRotationRequest",
    "PatchedProxyRotationRequest",
    "PaginatedProxyRotationList",
    # Test models
    "ProxyTest",
    "ProxyTestRequest",
    "PatchedProxyTestRequest",
    "PaginatedProxyTestList",
    # Enums
    "ProxyType",
    "ProxyMode",
    "ProxyStatus",
    "ProxyTestType",
]
