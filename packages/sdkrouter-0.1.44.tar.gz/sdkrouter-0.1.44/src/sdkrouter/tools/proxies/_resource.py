"""Top-level Proxies resources — ProxiesResource and AsyncProxiesResource."""

from __future__ import annotations

from ..._api.client import AsyncBaseResource, BaseResource
from ..._api.generated.proxies.proxies__api__proxies.client import ProxiesProxiesAPI
from ..._api.generated.proxies.proxies__api__proxies.sync_client import SyncProxiesProxiesAPI
from ..._config import SDKConfig
from ._assignments import _AssignmentsMixin, _AsyncAssignmentsMixin
from ._proxies import _AsyncProxiesMixin, _ProxiesMixin
from ._rotations import _AsyncRotationsMixin, _RotationsMixin
from ._tests import _AsyncTestsMixin, _TestsMixin


class ProxiesResource(
    _ProxiesMixin,
    _RotationsMixin,
    _AssignmentsMixin,
    _TestsMixin,
    BaseResource,
):
    """Proxies tool (sync).

    Provides proxy management with CRUD operations, health monitoring,
    rotation configurations, and assignment tracking.

    Features:
    - Create, update, and delete proxies
    - Filter proxies by country, health status
    - Manage rotation configurations
    - Track proxy assignments to parsers
    - Run connectivity and speed tests

    Example::

        client = SDKRouter(api_key="...")

        # List all proxies
        proxies = client.proxies.list()

        # Get healthy proxies
        healthy = client.proxies.get_healthy()

        # Create rotation config
        rotation = client.proxies.create_rotation(
            name="Korean Proxies",
            allowed_countries=["KR"],
            min_success_rate=95.0,
        )
    """

    def __init__(self, config: SDKConfig) -> None:
        super().__init__(config)
        self._api = SyncProxiesProxiesAPI(self._http_client)


class AsyncProxiesResource(
    _AsyncProxiesMixin,
    _AsyncRotationsMixin,
    _AsyncAssignmentsMixin,
    _AsyncTestsMixin,
    AsyncBaseResource,
):
    """Proxies tool (async).

    Async version of ProxiesResource for use in async contexts.

    Example::

        client = AsyncSDKRouter(api_key="...")

        proxies = await client.proxies.list()
        healthy = await client.proxies.get_healthy()
    """

    def __init__(self, config: SDKConfig) -> None:
        super().__init__(config)
        self._api = ProxiesProxiesAPI(self._http_client)


__all__ = [
    "ProxiesResource",
    "AsyncProxiesResource",
]
