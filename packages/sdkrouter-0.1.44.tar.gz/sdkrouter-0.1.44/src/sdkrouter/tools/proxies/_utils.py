"""Proxy helper utilities — enum coercion and list/dict normalization."""

from __future__ import annotations

from typing import Any

from ..._api.generated.proxies.enums import (
    PatchedProxyRequestProxyMode as ProxyMode,
    PatchedProxyRequestProxyType as ProxyType,
    PatchedProxyRequestStatus as ProxyStatus,
    PatchedProxyTestRequestTestType as ProxyTestType,
)


def coerce_proxy_type(value: str | ProxyType | None) -> ProxyType | None:
    return ProxyType(value) if isinstance(value, str) and value else None if not value else value  # type: ignore[return-value]


def coerce_proxy_mode(value: str | ProxyMode | None) -> ProxyMode | None:
    return ProxyMode(value) if isinstance(value, str) and value else None if not value else value  # type: ignore[return-value]


def coerce_proxy_status(value: str | ProxyStatus | None) -> ProxyStatus | None:
    return ProxyStatus(value) if isinstance(value, str) and value else None if not value else value  # type: ignore[return-value]


def coerce_test_type(value: str | ProxyTestType | None) -> ProxyTestType | None:
    return ProxyTestType(value) if isinstance(value, str) and value else None if not value else value  # type: ignore[return-value]


def normalize_countries(value: list[str] | dict[str, Any] | None) -> dict[str, Any] | None:
    """Normalize country list to API format: list → {"codes": [...]}."""
    if value is None:
        return None
    return value if isinstance(value, dict) else {"codes": value}


def normalize_providers(value: list[str] | dict[str, Any] | None) -> dict[str, Any] | None:
    """Normalize provider list to API format: list → {"types": [...]}."""
    if value is None:
        return None
    return value if isinstance(value, dict) else {"types": value}
