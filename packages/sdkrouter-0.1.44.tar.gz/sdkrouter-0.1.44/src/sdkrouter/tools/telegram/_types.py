from pydantic import BaseModel
from typing import Any


class BotInfo(BaseModel):
    alias: str
    bot_username: str
    bot_id: int | None
    is_active: bool
    webhook_set: bool
    callback_url: str
    consecutive_errors: int
    last_used_at: str | None
    created_at: str


class TelegramResult(BaseModel):
    """Raw Telegram API response (pass-through from proxy)."""
    ok: bool
    result: Any = None
    description: str = ""
    error_code: int = 0
