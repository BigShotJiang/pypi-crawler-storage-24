"""Top-level Research resources — ResearchResource and AsyncResearchResource.

Backed by the research API (research__api__research).
"""

from __future__ import annotations

from ..._api.client import AsyncBaseResource, BaseResource
from ..._api.client import SyncResearchResearchAPI, ResearchResearchAPI
from ..._config import SDKConfig
from ._mixins import _AsyncSearchMixin, _SearchMixin


class ResearchResource(_SearchMixin, BaseResource):
    """Web Research tool (sync).

    Uses generated SyncResearchResearchAPI client.
    """

    def __init__(self, config: SDKConfig) -> None:
        super().__init__(config)
        self._api = SyncResearchResearchAPI(self._http_client)


class AsyncResearchResource(_AsyncSearchMixin, AsyncBaseResource):
    """Web Research tool (async).

    Uses generated ResearchResearchAPI client.
    """

    def __init__(self, config: SDKConfig) -> None:
        super().__init__(config)
        self._api = ResearchResearchAPI(self._http_client)


# Backwards compat aliases
SearchResource = ResearchResource
AsyncSearchResource = AsyncResearchResource

__all__ = [
    "ResearchResource",
    "AsyncResearchResource",
    "SearchResource",
    "AsyncSearchResource",
]
