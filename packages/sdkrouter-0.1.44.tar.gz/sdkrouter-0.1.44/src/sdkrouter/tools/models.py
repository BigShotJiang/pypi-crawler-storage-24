"""LLM Models tool using generated API client."""

from typing import Optional

from .._config import SDKConfig
from ..exceptions import api_error_handler, async_api_error_handler
from .._api.client import (
    BaseResource,
    AsyncBaseResource,
    SyncModelsLlmModelsAPI,
    ModelsLlmModelsAPI,
)
from .._api.generated.models.models__api__llm_models.models import (
    LLMModelList,
    LLMModelDetail,
    PaginatedLLMModelListList,
    ProvidersResponse,
    StatsResponse,
    CostCalculationRequestRequest,
    CostCalculationResponse,
    CapabilitiesListResponse,
    CategoriesListResponse,
    PresetsListResponse,
    ResolveRequestRequest,
    ResolveResponse,
)


class ModelsResource(BaseResource):
    """LLM Models tool (sync).

    Uses generated SyncModelsLlmModelsAPI client.

    Example:
        ```python
        from sdkrouter import SDKRouter

        client = SDKRouter(api_key="your-api-key")

        # List all models with pagination
        models = client.models.list(page=1, page_size=20)
        for model in models.results:
            print(f"{model.model_id}: {model.name}")

        # Get model details
        model = client.models.get("openai/gpt-4o")
        print(f"Context: {model.context_length} tokens")

        # Calculate cost
        cost = client.models.calculate_cost(
            "openai/gpt-4o",
            input_tokens=1000,
            output_tokens=500
        )
        print(f"Cost: ${cost.total_cost_usd}")

        # Get providers list
        providers = client.models.providers()
        for p in providers.providers:
            print(f"{p.name}: {p.model_count} models")

        # Get statistics
        stats = client.models.stats()
        print(f"Total models: {stats.total_models}")
        ```
    """

    def __init__(self, config: SDKConfig):
        super().__init__(config)
        self._api = SyncModelsLlmModelsAPI(self._http_client)

    @api_error_handler
    def list(
        self,
        *,
        page: int = 1,
        page_size: int = 20,
    ) -> PaginatedLLMModelListList:
        """
        List available LLM models with pagination.

        Args:
            page: Page number (1-based)
            page_size: Number of results per page

        Returns:
            Paginated list of LLM models.
        """
        return self._api.list(page=page, page_size=page_size)  # type: ignore[return-value]

    @api_error_handler
    def get(self, model_id: str) -> LLMModelDetail:
        """
        Get detailed information about a specific model.

        Args:
            model_id: Model identifier (e.g., 'openai/gpt-4o')

        Returns:
            Model details including pricing, capabilities, etc.
        """
        return self._api.retrieve(model_id)

    @api_error_handler
    def calculate_cost(
        self,
        model_id: str,
        *,
        input_tokens: int,
        output_tokens: int,
    ) -> CostCalculationResponse:
        """
        Calculate cost for a request.

        Args:
            model_id: Model identifier
            input_tokens: Number of input tokens
            output_tokens: Number of output tokens

        Returns:
            Cost calculation result.
        """
        request = CostCalculationRequestRequest(
            input_tokens=input_tokens,
            output_tokens=output_tokens,
        )
        return self._api.calculate_cost_create(model_id, request)

    @api_error_handler
    def providers(self) -> ProvidersResponse:
        """
        Get list of available providers.

        Returns:
            List of providers with model counts.
        """
        return self._api.providers_retrieve()

    @api_error_handler
    def stats(self) -> StatsResponse:
        """
        Get model statistics.

        Returns:
            Statistics about available models.
        """
        return self._api.stats_retrieve()

    @api_error_handler
    def capabilities(self) -> CapabilitiesListResponse:
        """
        Get list of valid capability modifiers.

        Returns:
            Capabilities response with list of capability tags (e.g., "vision", "tools").
        """
        return self._api.capabilities_retrieve()

    @api_error_handler
    def categories(self) -> CategoriesListResponse:
        """
        Get list of available model categories.

        Returns:
            Categories response with list of category names (e.g., "chat", "code").
        """
        return self._api.categories_retrieve()

    @api_error_handler
    def presets(self) -> PresetsListResponse:
        """
        Get list of available model presets (tiers).

        Returns:
            Presets response listing aliases like @cheap, @balanced, @smart, @fast.
        """
        return self._api.presets_retrieve()

    @api_error_handler
    def resolve(self, alias: str) -> ResolveResponse:
        """
        Resolve a model alias to a specific provider/model ID.

        Args:
            alias: Model alias (e.g., "@cheap", "@smart+vision")

        Returns:
            ResolveResponse with the resolved model_id and provider.
        """
        request = ResolveRequestRequest(alias=alias)
        return self._api.resolve_create(request)


class AsyncModelsResource(AsyncBaseResource):
    """LLM Models tool (async).

    Uses generated ModelsLlmModelsAPI client.
    """

    def __init__(self, config: SDKConfig):
        super().__init__(config)
        self._api = ModelsLlmModelsAPI(self._http_client)

    @async_api_error_handler
    async def list(
        self,
        *,
        page: int = 1,
        page_size: int = 20,
    ) -> PaginatedLLMModelListList:
        """List available LLM models with pagination."""
        return await self._api.list(page=page, page_size=page_size)  # type: ignore[return-value]

    @async_api_error_handler
    async def get(self, model_id: str) -> LLMModelDetail:
        """Get detailed information about a specific model."""
        return await self._api.retrieve(model_id)

    @async_api_error_handler
    async def calculate_cost(
        self,
        model_id: str,
        *,
        input_tokens: int,
        output_tokens: int,
    ) -> CostCalculationResponse:
        """Calculate cost for a request."""
        request = CostCalculationRequestRequest(
            input_tokens=input_tokens,
            output_tokens=output_tokens,
        )
        return await self._api.calculate_cost_create(model_id, request)

    @async_api_error_handler
    async def providers(self) -> ProvidersResponse:
        """Get list of available providers."""
        return await self._api.providers_retrieve()

    @async_api_error_handler
    async def stats(self) -> StatsResponse:
        """Get model statistics."""
        return await self._api.stats_retrieve()

    @async_api_error_handler
    async def capabilities(self) -> CapabilitiesListResponse:
        """Get list of valid capability modifiers."""
        return await self._api.capabilities_retrieve()

    @async_api_error_handler
    async def categories(self) -> CategoriesListResponse:
        """Get list of available model categories."""
        return await self._api.categories_retrieve()

    @async_api_error_handler
    async def presets(self) -> PresetsListResponse:
        """Get list of available model presets (tiers)."""
        return await self._api.presets_retrieve()

    @async_api_error_handler
    async def resolve(self, alias: str) -> ResolveResponse:
        """Resolve a model alias to a specific provider/model ID."""
        request = ResolveRequestRequest(alias=alias)
        return await self._api.resolve_create(request)


__all__ = [
    "ModelsResource",
    "AsyncModelsResource",
    # Models
    "LLMModelList",
    "LLMModelDetail",
    "PaginatedLLMModelListList",
    "ProvidersResponse",
    "StatsResponse",
    "CostCalculationRequestRequest",
    "CostCalculationResponse",
    "CapabilitiesListResponse",
    "CategoriesListResponse",
    "PresetsListResponse",
    "ResolveRequestRequest",
    "ResolveResponse",
]
