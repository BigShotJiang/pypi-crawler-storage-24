#!/usr/bin/env python
"""Template: Alpha enrichment — merge forward prices to each alpha tick.

Pipeline (stays lazy until merge_forward):
  scan_alpha -> parse_time                              (lazy)
  select event cols (predictions only, no bid/ask)      (lazy)
  merge_forward(event, ref, ref_cols, horizons)         (collect here)
  write wide-format Delta Lake (one table, no melt)

Column-conflict workaround:
  Alpha has bid_px0/ask_px0 on BOTH event and ref sides.
  We select only prediction + id columns for the event side,
  so merge_forward's asof join has no name collisions.

Output: enriched_alpha/ (Delta Lake, wide format)
  Columns: ukey, data_date, x_10s, x_60s, x_3m, x_30m,
           bid_px0_0s, ask_px0_0s, bid_px0_10s, ..., ask_px0_5m
"""
from __future__ import annotations

import argparse
from datetime import timedelta
from pathlib import Path

import polars as pl
import vizflow as vf

try:
    import deltalake  # noqa: F401
except ImportError:
    raise ImportError("deltalake required. Install: pip install deltalake")


# ═══════════════════════════════════════════════════════════════
# CONFIG (inline – modify for your environment)
# ═══════════════════════════════════════════════════════════════
ALPHA_DIR = Path("/gpfs/.../jyao/alpha")
ALPHA_PATTERN = "alpha_{date}.feather"
ALPHA_SCHEMA = "jyao_v20251114"

# TRADE_DIR = Path("/cpfs/user2/ylu/projects/.../data/ordlog13/sc_8")
# TRADE_PATTERN = "{date}_orders.feather"
# TRADE_SCHEMA = "eric_v20260205"

OUTPUT_DIR = Path("./enriched_alpha")
MARKET = "CN"


# ═══════════════════════════════════════════════════════════════
# FORWARD MERGE CONFIG
# ═══════════════════════════════════════════════════════════════
HORIZONS = [timedelta(seconds=h) for h in [0, 10, 30, 60, 120, 180, 300]]
REF_COLS = ["bid_px0", "ask_px0"]
ALPHA_PRED_COLS = ["x_10s", "x_60s", "x_3m", "x_30m"]

# TRADE_TIME_COL = "update_exchange_ts"  # Fill time – controls time basis
ALPHA_TIME_COL = "ticktime"

EVENT_COLS = ["ukey", "data_date", ALPHA_TIME_COL] + ALPHA_PRED_COLS


# ═══════════════════════════════════════════════════════════════
# PROCESS ONE DATE
# ═══════════════════════════════════════════════════════════════
def process_date(date: str) -> pl.DataFrame:
    """Process one date: merge forward prices to each alpha tick.

    Returns:
        Wide-format DataFrame with event cols + forward cols.
    """
    elapsed_alpha_col = f"elapsed_{ALPHA_TIME_COL}"

    lf_alpha = (
        vf.scan_alpha(date)
        .pipe(vf.parse_time, ALPHA_TIME_COL)
    )

    lf_event = lf_alpha.select(EVENT_COLS + [elapsed_alpha_col])

    elapsed_ref_col = elapsed_alpha_col
    lf_ref = lf_alpha

    # Forward merge (includes h=0 for current price)
    df = vf.merge_forward(
        lf_event, lf_ref,
        ref_cols=REF_COLS,
        horizons=HORIZONS,
        trade_time_col=elapsed_alpha_col,
        ref_time_col=elapsed_ref_col,
    )

    return df


# ═══════════════════════════════════════════════════════════════
# CLI + MAIN
# ═══════════════════════════════════════════════════════════════
def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--date", required=True, help="Date in YYYYMMDD format")
    args = parser.parse_args()

    config = vf.Config(
        alpha_dir=ALPHA_DIR,
        alpha_pattern=ALPHA_PATTERN,
        alpha_schema=ALPHA_SCHEMA,
        # trade_dir=TRADE_DIR,
        # trade_pattern=TRADE_PATTERN,
        # trade_schema=TRADE_SCHEMA,
        market=MARKET,
    )
    vf.set_config(config)

    print(f"Processing {args.date}...")
    df = process_date(args.date)
    print(f"  {len(df)} events, {len(df.columns)} columns")

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    df.write_delta(
        str(OUTPUT_DIR),
        mode="append",
        delta_write_options={"partition_by": ["data_date"]},
    )

    print(f"  Saved to {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
