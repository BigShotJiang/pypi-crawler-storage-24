# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from darabonba.model import DaraModel

class DescDomainRequest(DaraModel):
    def __init__(
        self,
        domain_id: int = None,
        owner_id: int = None,
        require_real_time_dns_records: bool = None,
        resource_owner_account: str = None,
        resource_owner_id: int = None,
    ):
        # The domain name ID. Obtain this ID by calling the QueryDomainByParam operation.
        # 
        # This parameter is required.
        self.domain_id = domain_id
        self.owner_id = owner_id
        # Specifies whether to perform real-time DNS parsing.
        self.require_real_time_dns_records = require_real_time_dns_records
        self.resource_owner_account = resource_owner_account
        self.resource_owner_id = resource_owner_id

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.domain_id is not None:
            result['DomainId'] = self.domain_id

        if self.owner_id is not None:
            result['OwnerId'] = self.owner_id

        if self.require_real_time_dns_records is not None:
            result['RequireRealTimeDnsRecords'] = self.require_real_time_dns_records

        if self.resource_owner_account is not None:
            result['ResourceOwnerAccount'] = self.resource_owner_account

        if self.resource_owner_id is not None:
            result['ResourceOwnerId'] = self.resource_owner_id

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('DomainId') is not None:
            self.domain_id = m.get('DomainId')

        if m.get('OwnerId') is not None:
            self.owner_id = m.get('OwnerId')

        if m.get('RequireRealTimeDnsRecords') is not None:
            self.require_real_time_dns_records = m.get('RequireRealTimeDnsRecords')

        if m.get('ResourceOwnerAccount') is not None:
            self.resource_owner_account = m.get('ResourceOwnerAccount')

        if m.get('ResourceOwnerId') is not None:
            self.resource_owner_id = m.get('ResourceOwnerId')

        return self

