# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from darabonba.model import DaraModel

class DedicatedIpChangeWarmupTypeRequest(DaraModel):
    def __init__(
        self,
        id: str = None,
        warmup_type: str = None,
    ):
        # The ID of the dedicated IP address.
        self.id = id
        # The prefetch method.
        self.warmup_type = warmup_type

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.id is not None:
            result['Id'] = self.id

        if self.warmup_type is not None:
            result['WarmupType'] = self.warmup_type

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('Id') is not None:
            self.id = m.get('Id')

        if m.get('WarmupType') is not None:
            self.warmup_type = m.get('WarmupType')

        return self

