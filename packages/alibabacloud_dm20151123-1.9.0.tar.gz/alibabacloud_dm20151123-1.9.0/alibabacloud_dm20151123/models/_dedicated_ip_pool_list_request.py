# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from darabonba.model import DaraModel

class DedicatedIpPoolListRequest(DaraModel):
    def __init__(
        self,
        all: bool = None,
        keyword: str = None,
        page_index: int = None,
        page_size: int = None,
        pool_id: str = None,
    ):
        # Specifies whether to return all entries.
        self.all = all
        # The keyword to search for IP pools by name.
        self.keyword = keyword
        # The page number to return, starting from 1.
        self.page_index = page_index
        # The number of entries per page.
        self.page_size = page_size
        self.pool_id = pool_id

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.all is not None:
            result['All'] = self.all

        if self.keyword is not None:
            result['Keyword'] = self.keyword

        if self.page_index is not None:
            result['PageIndex'] = self.page_index

        if self.page_size is not None:
            result['PageSize'] = self.page_size

        if self.pool_id is not None:
            result['PoolId'] = self.pool_id

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('All') is not None:
            self.all = m.get('All')

        if m.get('Keyword') is not None:
            self.keyword = m.get('Keyword')

        if m.get('PageIndex') is not None:
            self.page_index = m.get('PageIndex')

        if m.get('PageSize') is not None:
            self.page_size = m.get('PageSize')

        if m.get('PoolId') is not None:
            self.pool_id = m.get('PoolId')

        return self

