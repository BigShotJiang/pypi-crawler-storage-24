# -*- coding: utf-8 -*-
# This file is auto-generated, don't edit it. Thanks.
from __future__ import annotations

from darabonba.model import DaraModel

class SendValidateFileRequest(DaraModel):
    def __init__(
        self,
        address_column: int = None,
        file_name: str = None,
        file_url: str = None,
        has_header_row: bool = None,
        remove_duplicate: bool = None,
    ):
        # The column that contains the email addresses in the file. The index starts from 1.
        # 
        # This parameter is required.
        self.address_column = address_column
        # The name of the file that contains the list of email addresses.
        # 
        # This parameter is required.
        self.file_name = file_name
        # The URL of the file that contains the list of email addresses.
        # 
        # This parameter is required.
        self.file_url = file_url
        # Specifies whether the first row is a table header.
        # 
        # This parameter is required.
        self.has_header_row = has_header_row
        # Specifies whether to remove duplicate email addresses in the output file.
        # 
        # This parameter is required.
        self.remove_duplicate = remove_duplicate

    def validate(self):
        pass

    def to_map(self):
        result = dict()
        _map = super().to_map()
        if _map is not None:
            result = _map
        if self.address_column is not None:
            result['AddressColumn'] = self.address_column

        if self.file_name is not None:
            result['FileName'] = self.file_name

        if self.file_url is not None:
            result['FileUrl'] = self.file_url

        if self.has_header_row is not None:
            result['HasHeaderRow'] = self.has_header_row

        if self.remove_duplicate is not None:
            result['RemoveDuplicate'] = self.remove_duplicate

        return result

    def from_map(self, m: dict = None):
        m = m or dict()
        if m.get('AddressColumn') is not None:
            self.address_column = m.get('AddressColumn')

        if m.get('FileName') is not None:
            self.file_name = m.get('FileName')

        if m.get('FileUrl') is not None:
            self.file_url = m.get('FileUrl')

        if m.get('HasHeaderRow') is not None:
            self.has_header_row = m.get('HasHeaderRow')

        if m.get('RemoveDuplicate') is not None:
            self.remove_duplicate = m.get('RemoveDuplicate')

        return self

