"""Scout MCP Server — Browser automation with anti-detection."""

__version__ = "1.3.1"
