import pandas as pd
import matplotlib.pyplot as plt
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV,learning_curve,train_test_split

df=pd.read_csv("diabetes.csv").dropna()

X=df.drop('Outcome',axis=1)
y=df['Outcome']

X_train_full,X_hold,y_train_full,y_hold=train_test_split(X,y,test_size=0.2,random_state=42,stratify=y)

pipe=Pipeline([
('scale',StandardScaler()),
('rf',RandomForestClassifier(random_state=0))
])

param_grid={
'rf__n_estimators':[100,200],
'rf__max_depth':[5,8,None],
'rf__min_samples_leaf':[3,5]
}

gs=GridSearchCV(pipe,param_grid,cv=5,scoring='accuracy',n_jobs=-1)

gs.fit(X_train_full,y_train_full)

best=gs.best_estimator_

print(gs.best_params_)
print(best.score(X_hold,y_hold))

train_sizes,train_scores,val_scores=learning_curve(
best,X_train_full,y_train_full,
cv=5,train_sizes=[0.2,0.4,0.6,0.8,1.0],
scoring='accuracy'
)

plt.plot(train_sizes,train_scores.mean(axis=1))
plt.plot(train_sizes,val_scores.mean(axis=1))
plt.show()