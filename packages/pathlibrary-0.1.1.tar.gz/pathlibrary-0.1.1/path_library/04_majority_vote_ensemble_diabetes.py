import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier,VotingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score,classification_report,confusion_matrix

df=pd.read_csv("diabetes.csv").dropna()

X=df.drop('Outcome',axis=1)
y=df['Outcome']

X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.2,random_state=42)

clf1=LogisticRegression(max_iter=1000)
clf2=RandomForestClassifier(n_estimators=100)
clf3=KNeighborsClassifier(n_neighbors=5)

ensemble=VotingClassifier(
estimators=[('lr',clf1),('rf',clf2),('knn',clf3)],
voting='hard'
)

ensemble.fit(X_train,y_train)

y_pred=ensemble.predict(X_test)

print(accuracy_score(y_test,y_pred))
print(classification_report(y_test,y_pred))

sns.heatmap(confusion_matrix(y_test,y_pred),annot=True)
plt.show()