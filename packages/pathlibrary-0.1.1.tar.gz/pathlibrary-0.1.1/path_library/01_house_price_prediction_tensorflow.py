import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import tensorflow as tf

df=pd.read_csv("housing.csv")
df.dropna(inplace=True)

features=['median_income','housing_median_age','total_rooms','population']
X=df[features].values
y=df['median_house_value'].values

scaler=StandardScaler()
X_scaled=scaler.fit_transform(X)

X_train,X_test,y_train,y_test=train_test_split(X_scaled,y,test_size=0.2,random_state=42)

model=tf.keras.Sequential([
tf.keras.Input(shape=(X_train.shape[1],)),
tf.keras.layers.Dense(64,activation='relu'),
tf.keras.layers.Dense(32,activation='relu'),
tf.keras.layers.Dense(1)
])

model.compile(optimizer='adam',loss='mse')

callback=tf.keras.callbacks.EarlyStopping(patience=5,restore_best_weights=True)

history=model.fit(X_train,y_train,epochs=100,batch_size=32,verbose=0,validation_split=0.2,callbacks=[callback])

y_pred=model.predict(X_test).flatten()

mse=mean_squared_error(y_test,y_pred)
mae=mean_absolute_error(y_test,y_pred)
r2=r2_score(y_test,y_pred)

print(mse,mae,r2)

plt.scatter(y_test,y_pred)
plt.plot([y_test.min(),y_test.max()],[y_test.min(),y_test.max()])
plt.show()