"""
Tavily 

 Tavily API , Agent .

API Key ():
  1. set_tavily_api("tvly-xxx")         - 
  2. WebSearchTool(api_key="tvly-xxx")  - 
  3.  TAVILY_API_KEY
"""

import os
from typing import Optional

#  API Key ( set_tavily_api )
_TAVILY_API_KEY: Optional[str] = None


def set_tavily_api(api_key: str):
    """
     Tavily  API Key()

    Usage:
        from klynx import set_tavily_api
        set_tavily_api("tvly-xxxxxxxxxxxxxxxx")

     Agent  Key.
    """
    global _TAVILY_API_KEY
    _TAVILY_API_KEY = api_key


class WebSearchTool:
    """Tavily """
    
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or _TAVILY_API_KEY
        self._client = None
    
    def _get_client(self):
        """ Tavily """
        if self._client is None:
            if not self.api_key:
                raise RuntimeError(
                    " TAVILY_API_KEY. .env :\n"
                    "TAVILY_API_KEY=tvly-xxxxxxxxxxxxxxxx"
                )
            from tavily import TavilyClient
            self._client = TavilyClient(api_key=self.api_key)
        return self._client
    
    def search(self, query: str, max_results: int = 5, 
               search_depth: str = "basic",
               include_answer: bool = True) -> str:
        """
        
        
        Args:
            query: 
            max_results:  (1-10)
            search_depth:  ("basic"  "advanced")
            include_answer:  AI 
        
        Returns:
            XML 
        """
        try:
            client = self._get_client()
            
            # ( SSL )
            proxy_vars = {}
            for key in ("HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY",
                        "http_proxy", "https_proxy", "all_proxy"):
                if key in os.environ:
                    proxy_vars[key] = os.environ.pop(key)
            #  requests ( Windows )
            old_no_proxy = os.environ.get("NO_PROXY")
            os.environ["NO_PROXY"] = "*"
            
            try:
                result = client.search(
                    query=query,
                    max_results=min(int(max_results), 10),
                    search_depth=search_depth,
                    include_answer=include_answer
                )
            finally:
                # 
                os.environ.update(proxy_vars)
                if old_no_proxy is not None:
                    os.environ["NO_PROXY"] = old_no_proxy
                elif "NO_PROXY" in os.environ:
                    del os.environ["NO_PROXY"]
            
            #  XML 
            xml = [f'<search_results query="{self._escape_xml(query)}">']
            
            # AI 
            if include_answer and result.get("answer"):
                xml.append(f'  <answer>{self._escape_xml(result["answer"])}</answer>')
            
            # 
            for i, item in enumerate(result.get("results", []), 1):
                title = self._escape_xml(item.get("title", ""))
                url = self._escape_xml(item.get("url", ""))
                content = self._escape_xml(item.get("content", ""))
                score = item.get("score", 0)
                
                xml.append(f'  <result rank="{i}" score="{score:.2f}">')
                xml.append(f'    <title>{title}</title>')
                xml.append(f'    <url>{url}</url>')
                xml.append(f'    <content>{content}</content>')
                xml.append(f'  </result>')
            
            xml.append('</search_results>')
            return "\n".join(xml)
            
        except RuntimeError:
            raise
        except Exception as e:
            return f"<error>: {str(e)}</error>"
    
    @staticmethod
    def _escape_xml(text: str) -> str:
        return text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
