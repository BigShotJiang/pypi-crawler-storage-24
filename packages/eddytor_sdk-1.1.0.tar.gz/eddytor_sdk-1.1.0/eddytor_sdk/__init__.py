"""
Eddytor Python SDK - Connect to Eddytor via Apache Arrow Flight SQL and REST APIs.

Understanding table names
-------------------------

Eddytor uses a three-part **Fully Qualified Name (FQN)** for every table::

    eddytor.cfg_<config_id_hex>.<table_id>_<table_name>

- **Catalog** is always ``"eddytor"`` (fixed constant).
- **Schema** is ``cfg_`` followed by the storage configuration UUID with dashes
  removed (e.g. config id ``550e8400-e29b-41d4-a716-446655440000`` becomes
  ``cfg_550e8400e29b41d4a716446655440000``).
- **Table** is a stable table ID (UUID hex from Delta protocol's ``metaData.id``)
  followed by the human-readable name
  (e.g. ``a1b2c3d4e5f67890abcdef1234567890_customers``).

You do **not** need to construct these yourself. Use ``client.tables()`` to
discover all available tables and get ready-to-use ``Table`` handles::

    from eddytor_sdk import EddytorClient

    with EddytorClient(api_key="edd_live_xxx") as client:
        # Step 1 — discover available tables
        for t in client.tables():
            print(t.fqn)  # e.g. `eddytor`.`cfg_550e...`.`a1b2c3d4..._customers`

        # Step 2 — work with a table
        tables = client.tables()
        customers = tables[0]
        df = customers.query_all(limit=10)
        print(df)
"""

from .client import EddytorClient
from .exceptions import EddytorAuthError, EddytorError, EddytorConnectionError, EddytorQueryError, EddytorSchemaError
from .grpc_client import GrpcClient, StreamResult
from .rest import RestClient
from .storage import Storage
from .table import Table, Column
from .models import (
    # Enums
    SchemeType,
    AIProvider,
    AIAction,
    DomainType,
    # Table models
    ColumnInfo,
    TableMetadata,
    TableHistory,
    TableHistoryEntry,
    InferredSchema,
    MagicDustResult,
    CellReference,
    ExplainRowsResult,
    MoveTableResult,
    RenameTableResult,
    MoveObjectsResult,
    # Storage models
    StorageConfig,
    RegisteredTable,
    StorageObject,
    ListObjectsResult,
    # Domain models
    ColumnDomain,
    HierarchyNode,
    AllowedValues,
)

__version__ = "1.0.3"
__all__ = [
    # Main client
    "EddytorClient",
    "RestClient",
    "GrpcClient",
    "StreamResult",
    # Table/Column/Storage wrappers
    "Table",
    "Column",
    "Storage",
    # Exceptions
    "EddytorError",
    "EddytorAuthError",
    "EddytorConnectionError",
    "EddytorQueryError",
    "EddytorSchemaError",
    # Enums
    "SchemeType",
    "AIProvider",
    "AIAction",
    "DomainType",
    # Table models
    "ColumnInfo",
    "TableMetadata",
    "TableHistory",
    "TableHistoryEntry",
    "InferredSchema",
    "MagicDustResult",
    "CellReference",
    "ExplainRowsResult",
    "MoveTableResult",
    "RenameTableResult",
    "MoveObjectsResult",
    # Storage models
    "StorageConfig",
    "RegisteredTable",
    "StorageObject",
    "ListObjectsResult",
    # Domain models
    "ColumnDomain",
    "HierarchyNode",
    "AllowedValues",
]
