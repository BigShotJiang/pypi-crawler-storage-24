# Verification Notes — Tranche J3 (abi-evals)

## Pytest Node IDs

```
tests/test_promotion_gate.py::TestFindCandidate::test_present
tests/test_promotion_gate.py::TestFindCandidate::test_absent
tests/test_promotion_gate.py::TestEvaluatePromotionSkip::test_skips_when_no_candidate
tests/test_promotion_gate.py::TestEvaluatePromotionSkip::test_skip_summary_dict
tests/test_promotion_gate.py::TestEvaluatePromotionWithCandidate::test_produces_receipt_artifact
tests/test_promotion_gate.py::TestEvaluatePromotionWithCandidate::test_summary_dict_structure
tests/test_promotion_gate.py::TestEvaluatePromotionWithCandidate::test_warn_status_propagated
tests/test_promotion_gate.py::TestEvaluatePromotionWithCandidate::test_fail_status_propagated
tests/test_promotion_gate.py::TestEvaluatePromotionErrors::test_missing_abi_promotion
tests/test_promotion_gate.py::TestEvaluatePromotionErrors::test_no_receipt_produced
tests/test_promotion_gate.py::TestPromotionGateResultDict::test_minimal_skip
tests/test_promotion_gate.py::TestPromotionGateResultDict::test_full_result
```

## Invocation

```bash
# Run only promotion-gate tests
uv run python -m pytest tests/test_promotion_gate.py -v

# Run full verification pipeline
uv run python script/verify.py
```

## Report-Only Statement

The promotion-readiness gate is **report-only**. It surfaces
`promotion.status = pass | warn | fail | skipped | error` as informational
metadata. It does **not** block any eval run, does **not** affect the
eval-result summary, and does **not** gate promotion in any way.

A missing `promotion_candidate.json` results in a clean `skipped` status
with zero side effects.

## Dependency Approach

`abi-promotion` is invoked as a **subprocess** (`python -m abi_promotion
verify-candidate`). There is no hard import of the `abi_promotion` package
in `abi-evals` source or test code. This preserves the dependency direction:
abi-evals does not depend on abi-promotion at the Python package level.

## Fixtures

- `tests/fixtures/evidence_with_candidate/promotion_candidate.json` — sample
  candidate JSON used by tests.
- Subprocess calls are mocked in tests; no real invocation of abi-promotion
  is required to run the test suite.
