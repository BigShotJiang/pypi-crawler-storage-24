# Architecture

## High-Level Design
Evaluation harness with golden management for AbilityBI AI pipeline quality assurance.

## Components
- src/abi_evals/ — eval runner and case management
- src/abi_evals/runner.py — eval suite executor
- tests/ — eval harness tests

## Interfaces
Inputs: Structured data, policy definitions, or API requests depending on module.
Outputs: Processed results, evidence packs, or structured reports.
