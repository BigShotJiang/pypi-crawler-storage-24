# Overview

## Purpose
Provides deterministic evaluation suites for validating AI pipeline outputs against golden fixtures and policy thresholds.

## Primary Users
- AbilityBI engineering and AI pipeline operators

## Scope
- What it covers: Evaluation harness with golden management for AbilityBI AI pipeline quality assurance.
- What it does not cover: External distribution or unsanctioned integrations
