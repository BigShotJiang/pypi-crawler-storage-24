# abi-evals Interfaces

## Input: Eval Suite (eval-suite/1.0)

```json
{
  "schema_version": "eval-suite/1.0",
  "suite_id": "string",
  "description": "string",
  "cases": [
    {
      "case_id": "string",
      "description": "string",
      "input": "any",
      "expected": "any",
      "comparison": "exact|golden_exact|golden_structural|numeric_tolerance|regex_assert|presence_assert|schema_validate",
      "tolerance": 0.001,
      "tags": ["string"]
    }
  ]
}
```

## Output: Eval Result (eval-result/1.0)

```json
{
  "schema_version": "eval-result/1.0",
  "suite_id": "string",
  "run_id": "8-hex-chars",
  "evaluated_at": "ISO 8601",
  "results": [{"case_id": "...", "status": "pass|fail|error|skipped", ...}],
  "summary": {"total": N, "passed": N, "failed": N, "errors": N, "skipped": N}
}
```

## CLI Commands

| Command | Input | Output |
|---------|-------|--------|
| `run --eval-suite F [--evidence-pack F] [--out F]` | Suite JSON + optional evidence pack | Results JSON |
| `diff --golden-set V --evidence-pack F` | Golden version + evidence pack | Diff report |
| `bless --version V --evidence-pack F --i-understand-this-changes-baselines` | Evidence pack | New golden version |
| `list-goldens` | (none) | Golden versions |
