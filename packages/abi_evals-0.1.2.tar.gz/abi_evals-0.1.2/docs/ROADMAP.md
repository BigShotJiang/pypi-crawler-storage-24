# Roadmap

## Near Term
- Add LLM-as-judge eval cases
- Golden fixture auto-refresh tooling

## Later
- Distributed eval runner for large suites
