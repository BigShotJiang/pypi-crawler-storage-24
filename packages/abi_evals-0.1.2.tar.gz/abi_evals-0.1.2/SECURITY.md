# Security Policy

## Repository Privacy

This is a private internal repository under AbilityBI.
It must remain private unless the owner explicitly approves public release.

## Reporting

Report security issues directly to the repository owner.

## Guidelines

- Never commit credentials or secrets.
- Use environment variables for sensitive configuration.
