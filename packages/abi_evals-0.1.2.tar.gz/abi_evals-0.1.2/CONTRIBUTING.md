# Contributing (Speed Mode)

This repository is private and maintained by AbilityBI.

## Current Workflow (Speed Phase)

- Work directly on the default branch.
- No feature branches or pull requests unless explicitly required.
- Commit small, commit often, push often.

## Versioning

- Semantic Versioning (MAJOR.MINOR.PATCH).
- Version must be updated in:
  - `pyproject.toml` OR
  - `package.json` OR
  - `VERSION` file (single source of truth).
- Update CHANGELOG.md with each version bump.

## Security

Do not commit secrets, credentials, or client data.
See SECURITY.md.
