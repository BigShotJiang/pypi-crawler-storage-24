import sys

from abi_evals.cli import main

sys.exit(main())
