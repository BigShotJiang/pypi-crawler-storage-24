"""Internal models for eval harness."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class EvalCase:
    """A single eval test case."""
    case_id: str
    description: str = ""
    input: Any = None
    expected: Any = None
    # exact | numeric_tolerance | structural | golden_exact
    # golden_structural | regex_assert | presence_assert | schema_validate
    comparison: str = "exact"
    tolerance: float = 1e-6
    tags: list[str] = field(default_factory=list)
    config: dict[str, Any] = field(default_factory=dict)


@dataclass
class EvalResult:
    """Result of evaluating a single case."""
    case_id: str
    status: str  # pass | fail | error | skipped
    actual: Any = None
    message: str = ""
    diff: str = ""


@dataclass
class EvalSummary:
    """Summary of eval run."""
    total: int = 0
    passed: int = 0
    failed: int = 0
    errors: int = 0
    skipped: int = 0
