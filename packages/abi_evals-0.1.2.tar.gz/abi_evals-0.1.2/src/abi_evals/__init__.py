"""ABI Evals — eval harness with golden management for the ABI ecosystem.

# TODO(telemetry): When live eval providers are added (non-mock), wire
# TelemetryEmitter from abi_control_core.sdk to emit per-invocation records
# with role="evaluator". See abi-core/src/abi_control_core/sdk/telemetry_emitter.py.
"""
from abi_evals.failure_distiller import FailureDistiller, FailureRecord, RegressionEvalCase
from abi_evals.failure_taxonomy import FailureTaxonomy, FailureType
from abi_evals.model_canary import CanaryResult, ModelCanary
from abi_evals.regression_store import RegressionStore

__version__ = "0.1.2"
__all__ = [
    "FailureTaxonomy",
    "FailureType",
    "FailureDistiller",
    "FailureRecord",
    "RegressionEvalCase",
    "RegressionStore",
    "ModelCanary",
    "CanaryResult",
]
