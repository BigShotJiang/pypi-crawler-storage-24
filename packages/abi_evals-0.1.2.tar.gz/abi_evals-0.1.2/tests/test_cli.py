"""Tests for CLI interface."""
import json

from abi_evals.cli import main


class TestCLI:
    def test_run_command(self, sample_suite_path, tmp_path):
        out = tmp_path / "results.json"
        rc = main([
            "run",
            "--eval-suite", str(sample_suite_path),
            "--out", str(out),
            "--run-id", "test0001",
            "--timestamp", "2025-01-01T00:00:00Z",
        ])
        assert rc == 0
        results = json.loads(out.read_text())
        assert results["summary"]["passed"] > 0

    def test_list_goldens(self, goldens_dir, capsys):
        rc = main(["--goldens-dir", str(goldens_dir), "list-goldens"])
        assert rc == 0
        assert "v1" in capsys.readouterr().out
