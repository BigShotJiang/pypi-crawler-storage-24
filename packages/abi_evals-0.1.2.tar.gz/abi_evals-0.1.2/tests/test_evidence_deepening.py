"""Phase 2 — Evidence deepening for abi-evals.

Verifies that eval runs emit:
- Deterministic seed (via fixed timestamp)
- Evaluation hash (via result hash)
- Versioned eval schema reference
- Complete result structure
"""

from __future__ import annotations

import hashlib
import json

from abi_evals.runner import run_suite


def _sha256(data: str) -> str:
    return hashlib.sha256(data.encode()).hexdigest()


class TestEvalResultSchemaCompliance:
    """Eval results include all required schema fields."""

    def test_result_has_schema_version(self, sample_suite):
        result = run_suite(sample_suite, run_id="ev000001", timestamp="2025-01-01T00:00:00Z")
        assert result["schema_version"] == "eval-result/1.0"

    def test_result_has_suite_id(self, sample_suite):
        result = run_suite(sample_suite, run_id="ev000001", timestamp="2025-01-01T00:00:00Z")
        assert "suite_id" in result
        assert result["suite_id"] == sample_suite["suite_id"]

    def test_result_has_run_id(self, sample_suite):
        result = run_suite(sample_suite, run_id="ev000001", timestamp="2025-01-01T00:00:00Z")
        assert result["run_id"] == "ev000001"

    def test_result_has_evaluated_at(self, sample_suite):
        result = run_suite(sample_suite, run_id="ev000001", timestamp="2025-01-01T00:00:00Z")
        assert result["evaluated_at"] == "2025-01-01T00:00:00Z"

    def test_result_has_summary(self, sample_suite):
        result = run_suite(sample_suite, run_id="ev000001", timestamp="2025-01-01T00:00:00Z")
        summary = result["summary"]
        assert "total" in summary
        assert "passed" in summary
        assert "failed" in summary
        assert "errors" in summary
        assert "skipped" in summary
        expected = summary["passed"] + summary["failed"] + summary["errors"] + summary["skipped"]
        assert summary["total"] == expected

    def test_each_result_has_case_id_and_status(self, sample_suite):
        result = run_suite(sample_suite, run_id="ev000001", timestamp="2025-01-01T00:00:00Z")
        for r in result["results"]:
            assert "case_id" in r
            assert "status" in r
            assert r["status"] in ("pass", "fail", "error", "skipped")


class TestEvalResultHash:
    """Eval results can be hashed for integrity verification."""

    def test_result_hash_reproducible(self, sample_suite):
        r1 = run_suite(sample_suite, run_id="ev000002", timestamp="2025-01-01T00:00:00Z")
        r2 = run_suite(sample_suite, run_id="ev000002", timestamp="2025-01-01T00:00:00Z")
        h1 = _sha256(json.dumps(r1, sort_keys=True))
        h2 = _sha256(json.dumps(r2, sort_keys=True))
        assert h1 == h2, "Eval result hash not reproducible"

    def test_different_run_id_different_hash(self, sample_suite):
        r1 = run_suite(sample_suite, run_id="ev000003", timestamp="2025-01-01T00:00:00Z")
        r2 = run_suite(sample_suite, run_id="ev000004", timestamp="2025-01-01T00:00:00Z")
        h1 = _sha256(json.dumps(r1, sort_keys=True))
        h2 = _sha256(json.dumps(r2, sort_keys=True))
        assert h1 != h2, "Different run_ids should produce different hashes"
