"""Shared fixtures for abi-evals tests."""
import json
from pathlib import Path

import pytest

FIXTURES_DIR = Path(__file__).resolve().parent / "fixtures"


@pytest.fixture
def sample_suite_path() -> Path:
    return FIXTURES_DIR / "sample_eval_suite.json"


@pytest.fixture
def sample_suite() -> dict:
    with open(FIXTURES_DIR / "sample_eval_suite.json") as f:
        return json.load(f)


@pytest.fixture
def sample_evidence_pack() -> dict:
    with open(FIXTURES_DIR / "sample_evidence_pack" / "manifest.json") as f:
        return json.load(f)


@pytest.fixture
def goldens_dir(tmp_path: Path) -> Path:
    d = tmp_path / "goldens"
    d.mkdir()
    v1 = d / "v1"
    v1.mkdir()
    manifest = {
        "version": "v1",
        "blessed_from": "initial",
        "artifacts": {
            "greeting": "Hello, World!",
            "sum_result": 42,
        },
    }
    with open(v1 / "manifest.json", "w") as f:
        json.dump(manifest, f)
    return d
