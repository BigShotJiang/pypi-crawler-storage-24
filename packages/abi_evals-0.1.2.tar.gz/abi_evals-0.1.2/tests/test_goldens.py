"""Tests for golden management."""
import pytest

from abi_evals.goldens import bless_golden, diff_golden, list_golden_versions, load_golden_set


class TestGoldens:
    def test_list_versions(self, goldens_dir):
        versions = list_golden_versions(goldens_dir)
        assert "v1" in versions

    def test_load_golden(self, goldens_dir):
        golden = load_golden_set("v1", goldens_dir)
        assert golden["version"] == "v1"
        assert "artifacts" in golden

    def test_load_missing(self, goldens_dir):
        with pytest.raises(FileNotFoundError):
            load_golden_set("v999", goldens_dir)

    def test_diff_exact_match(self, goldens_dir):
        golden = load_golden_set("v1", goldens_dir)
        evidence = {"artifacts": {"greeting": "Hello, World!", "sum_result": 42}}
        diffs = diff_golden(golden, evidence)
        assert all(d["status"] == "match" for d in diffs)

    def test_diff_mismatch(self, goldens_dir):
        golden = load_golden_set("v1", goldens_dir)
        evidence = {"artifacts": {"greeting": "Goodbye!", "sum_result": 42}}
        diffs = diff_golden(golden, evidence)
        mismatches = [d for d in diffs if d["status"] == "mismatch"]
        assert len(mismatches) == 1

    def test_bless_requires_flag(self, goldens_dir):
        with pytest.raises(ValueError, match="confirmation"):
            bless_golden("v2", {"artifacts": {}}, goldens_dir)

    def test_bless_with_flag(self, goldens_dir):
        result_dir = bless_golden(
            "v2",
            {"run_id": "test0001", "artifacts": {"new": "data"}},
            goldens_dir,
            confirm_flag=True,
        )
        assert (result_dir / "manifest.json").exists()
        versions = list_golden_versions(goldens_dir)
        assert "v2" in versions
