#!/usr/bin/env python3
"""Basic demo — run a sample eval suite and print results."""
from __future__ import annotations

import json
from pathlib import Path

from abi_evals.runner import load_eval_suite, run_suite

REPO_ROOT = Path(__file__).resolve().parent.parent.parent


def main() -> None:
    suite_path = REPO_ROOT / "tests" / "fixtures" / "sample_eval_suite.json"
    suite = load_eval_suite(suite_path)

    results = run_suite(suite, run_id="demo0001", timestamp="2025-01-01T00:00:00Z")

    print(json.dumps(results, indent=2, sort_keys=True))
    print(f"\nSummary: {results['summary']['passed']}/{results['summary']['total']} passed")


if __name__ == "__main__":
    main()
