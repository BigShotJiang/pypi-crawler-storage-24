# Quality Gates

## Gate Requirements

All pull requests must pass these gates before merge.

### All Tiers

1. **CI passes** — lint + tests green
2. **PR description complete** — summary, risk tier, AI usage declared
3. **No secrets** — no credentials, tokens, or keys in code or logs
4. **Human approval** — at least one approving review

### Tier 1+ (Features, Bug Fixes)

5. **Verification block** — exact commands, inputs, expected outputs, invariants
6. **Evidence section** — CI link and test results
7. **Critic review** — adversarial review completed

### Tier 2 (Security, Auth, Migrations, Deletes)

8. **Evidence bundle** — design freeze, test results, regression check, rollback plan
9. **Validator confirmation** — independent verification
10. **Two human approvals** preferred

## Risk Tier Classification

| Tier | Scope | Examples |
|------|-------|---------|
| Tier 0 | Docs, comments, formatting | README updates, typo fixes |
| Tier 1 | Features, bug fixes, refactors | New endpoints, config changes |
| Tier 2 | Security, auth, data, migrations | Schema changes, access control |

## Enforcement

Quality gates are enforced via GitHub Actions governance workflows.
PR labels (`critic-reviewed`, `validator-approved`) track gate completion.
