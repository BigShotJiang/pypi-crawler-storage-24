# Context Bundle

Portable session context assembled by `script/context-export`.
This file is deterministic: identical inputs produce identical output.

**Bundle hash:** `e3b0c44298fc1c14...`
**Files:** 0 total (0 memory, 0 context)

## How to Use

Point an AI agent at this directory. The agent should read:
1. `BUNDLE.md` (this file) — orientation and file index.
2. Files listed under **Memory Files** — current session state.
3. Files listed under **Agent-Bootstrap Context Files** — repo governance context.

To regenerate: `script/context-export`
To verify memory files: `script/memory-drift-check`

Bundle hash (full): `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`
