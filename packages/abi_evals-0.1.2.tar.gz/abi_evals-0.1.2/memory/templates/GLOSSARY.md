# GLOSSARY — Domain Terminology

<!-- Memory template: GLOSSARY. Replace <!-- REQUIRED: ... --> markers with actual content. -->

## Terms

<!-- REQUIRED: terms -->
Define domain-specific terms, acronyms, and project-local vocabulary.
Format:
| Term | Definition |
|------|-----------|
| ABI | AbilityBI — the AI governance framework. |
| HIL | Human-in-the-Loop — a checkpoint requiring human approval before proceeding. |

---
<!-- Template version: 1.0 | See docs/governance/MEMORY_GOVERNANCE_SPEC_v1.md -->
