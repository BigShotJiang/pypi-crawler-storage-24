# RESUME_PROMPT — AI Session Resume Scaffold

<!-- Memory template: RESUME_PROMPT. Replace <!-- REQUIRED: ... --> markers with actual content. -->

## Context

<!-- REQUIRED: session_context -->
Paste or summarise the project context an AI assistant needs to resume this session:
- Repository: name and purpose
- Tech stack: language, frameworks, key dependencies
- Governance constraints: tier, autonomy level, required gates
- Important invariants: what must never change

## Last Known State

<!-- REQUIRED: last_known_state -->
Describe the exact state at the end of the previous session:
- What was being built or investigated
- What files were modified
- What tests passed/failed
- What the last successful command was

## Next Steps

<!-- REQUIRED: next_steps -->
List the next concrete actions to take, in priority order:
1. First action
2. Second action
3. Third action

---
<!-- Template version: 1.0 | See docs/governance/MEMORY_GOVERNANCE_SPEC_v1.md -->
