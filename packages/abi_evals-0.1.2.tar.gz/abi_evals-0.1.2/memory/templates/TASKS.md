# TASKS — Task Queue and Backlog

<!-- Memory template: TASKS. Replace <!-- REQUIRED: ... --> markers with actual content. -->

## Active

<!-- REQUIRED: active_tasks -->
List tasks currently in progress. Include owner and expected next action.
Format:
- [ ] Task description (Owner: @name, Next: action)

## Backlog

<!-- REQUIRED: backlog -->
List tasks not yet started, in priority order.
Format:
- [ ] Task description — rationale or dependency

## Completed

<!-- REQUIRED: completed_tasks -->
List recently completed tasks (last session or milestone). Move older items to archive.
Format:
- [x] Task description — completed on YYYY-MM-DD

---
<!-- Template version: 1.0 | See docs/governance/MEMORY_GOVERNANCE_SPEC_v1.md -->
