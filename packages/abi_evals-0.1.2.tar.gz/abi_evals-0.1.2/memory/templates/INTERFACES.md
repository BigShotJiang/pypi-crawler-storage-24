# INTERFACES — Interface and Contract Ledger

<!-- Memory template: INTERFACES. Replace <!-- REQUIRED: ... --> markers with actual content. -->

## Interface Ledger

<!-- REQUIRED: interface_ledger -->
List all significant external interfaces this repository exposes or consumes.
Format:
| Interface | Type | Version | Direction | Owner | Notes |
|-----------|------|---------|-----------|-------|-------|
| Name | REST/gRPC/schema/event | v1.0 | Exposes/Consumes | @team | |

## Contracts

<!-- REQUIRED: contracts -->
List governed contracts (schema files, lock files, vendor pins).
Format:
- `path/to/contract.json` — purpose, schema version, owner

---
<!-- Template version: 1.0 | See docs/governance/MEMORY_GOVERNANCE_SPEC_v1.md -->
