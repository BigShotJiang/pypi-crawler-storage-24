# DECISIONS — Architectural Decision Log

<!-- Memory template: DECISIONS. Replace <!-- REQUIRED: ... --> markers with actual content. -->

## Decision Log

<!-- REQUIRED: decision_log -->
Record decisions that affect architecture, APIs, or governance. Each entry should be a brief ADR.
Format:
| Date | Decision | Rationale | Status |
|------|----------|-----------|--------|
| YYYY-MM-DD | What was decided | Why | Active / Superseded |

## Pending

<!-- REQUIRED: pending_decisions -->
List open architectural questions that need a decision.
Format:
- [ ] Question or decision point — context and options under consideration

---
<!-- Template version: 1.0 | See docs/governance/MEMORY_GOVERNANCE_SPEC_v1.md -->
