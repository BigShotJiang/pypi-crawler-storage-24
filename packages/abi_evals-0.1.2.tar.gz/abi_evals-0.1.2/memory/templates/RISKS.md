# RISKS — Risk Register

<!-- Memory template: RISKS. Replace <!-- REQUIRED: ... --> markers with actual content. -->

## Risk Register

<!-- REQUIRED: risk_register -->
List open risks with impact and likelihood. Review and update at each milestone.
Format:
| ID | Risk | Likelihood | Impact | Status |
|----|------|-----------|--------|--------|
| R-001 | Risk description | High/Med/Low | High/Med/Low | Open / Mitigated / Accepted |

## Mitigations

<!-- REQUIRED: mitigations -->
Describe active mitigation actions for open risks.
Format:
- **R-001**: Mitigation action and owner.

---
<!-- Template version: 1.0 | See docs/governance/MEMORY_GOVERNANCE_SPEC_v1.md -->
