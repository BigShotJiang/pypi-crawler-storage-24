"""AgenticWorkflow — Universal orchestration engine for AI agents.

Pure-Python SDK that wraps the ``awf`` CLI binary via subprocess.
Zero required dependencies; only stdlib: subprocess, json, pathlib, dataclasses.
"""

from __future__ import annotations

import json
import logging
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

__version__ = "0.1.0"

logger = logging.getLogger(__name__)


class WorkflowError(Exception):
    """Raised when an awf CLI command fails."""


@dataclass
class WorkflowEngine:
    """Interface to an ``.awf`` workflow engine file.

    Parameters
    ----------
    path : str | Path
        Path to the ``.awf`` file. Created automatically on first write
        if it does not exist.
    binary : str
        Name or path of the ``awf`` CLI binary.
    """

    path: str | Path
    binary: str = "awf"
    _resolved_binary: Optional[str] = field(default=None, repr=False, init=False)

    def __post_init__(self) -> None:
        self.path = Path(self.path)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _find_binary(self) -> str:
        if self._resolved_binary is not None:
            return self._resolved_binary

        import shutil

        found = shutil.which(self.binary)
        if found is None:
            raise WorkflowError(
                f"Cannot find '{self.binary}' on PATH. "
                "Install AgenticWorkflow: curl -fsSL https://agentralabs.tech/install/workflow | bash"
            )
        self._resolved_binary = found
        return found

    def _run(self, *args: str, check: bool = True) -> str:
        """Execute an awf CLI command and return stdout."""
        cmd = [self._find_binary(), "--file", str(self.path), *args]
        logger.debug("Running: %s", " ".join(cmd))
        result = subprocess.run(cmd, capture_output=True, text=True)
        if check and result.returncode != 0:
            raise WorkflowError(
                f"awf command failed (exit {result.returncode}): {result.stderr.strip()}"
            )
        return result.stdout.strip()

    def _run_json(self, *args: str) -> Any:
        """Execute a command and parse JSON output."""
        raw = self._run(*args, "--format", "json")
        return json.loads(raw) if raw else {}

    # ------------------------------------------------------------------
    # Workflow operations
    # ------------------------------------------------------------------

    def create_workflow(
        self,
        name: str,
        *,
        description: Optional[str] = None,
        kind: Optional[str] = None,
    ) -> str:
        """Create a new workflow. Returns the workflow ID."""
        args = ["workflow", "create", name]
        if description:
            args.extend(["--description", description])
        if kind:
            args.extend(["--kind", kind])
        return self._run(*args)

    def add_step(
        self,
        workflow: str,
        step_name: str,
        *,
        depends_on: Optional[list[str]] = None,
        action: Optional[str] = None,
    ) -> str:
        """Add a step to a workflow. Returns the step ID."""
        args = ["step", "add", workflow, step_name]
        if depends_on:
            for dep in depends_on:
                args.extend(["--depends-on", dep])
        if action:
            args.extend(["--action", action])
        return self._run(*args)

    def execute(
        self,
        workflow: str,
        *,
        dry_run: bool = False,
    ) -> dict[str, Any]:
        """Execute a workflow. Returns execution results."""
        args = ["workflow", "execute", workflow, "--format", "json"]
        if dry_run:
            args.append("--dry-run")
        raw = self._run(*args)
        return json.loads(raw) if raw else {}

    def list_workflows(self, *, status: Optional[str] = None) -> list[dict[str, Any]]:
        """List all workflows, optionally filtered by status."""
        args = ["workflow", "list", "--format", "json"]
        if status:
            args.extend(["--status", status])
        raw = self._run(*args)
        return json.loads(raw) if raw else []

    # ------------------------------------------------------------------
    # Stats
    # ------------------------------------------------------------------

    def stats(self) -> dict[str, Any]:
        """Get workflow engine statistics."""
        raw = self._run("stats", "--format", "json")
        return json.loads(raw) if raw else {}

    # ------------------------------------------------------------------
    # File operations
    # ------------------------------------------------------------------

    def save(self) -> None:
        """Explicit save (most operations auto-save)."""
        pass

    @property
    def exists(self) -> bool:
        """Whether the .awf file exists on disk."""
        return self.path.exists()
