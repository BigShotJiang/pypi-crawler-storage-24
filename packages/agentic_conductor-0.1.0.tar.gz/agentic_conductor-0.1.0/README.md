# AgenticWorkflow Python SDK

Pure-Python SDK that wraps the `awf` CLI binary.

```bash
pip install agentic-workflow
```
