# openshell

Zero version placeholder for openshell
