from crypteria.security.crypto import KeyManager, CryptoMode, derive_key_from_password
import hashlib

# Generate and manage keys
key_manager = KeyManager()

# Generate a new AES-256 key
new_key = key_manager.generate_key(CryptoMode.GCM)
print(f"Generated key length: {len(new_key)} bytes")

# Store in keyring
key_manager.store_key(new_key, "my_app_key")

# Retrieve later
retrieved_key = key_manager.get_key("my_app_key")

# Derive key from password (PBKDF2)
password = "MySecurePassword123"
derived_key, salt = derive_key_from_password(password)
print(f"Key derived from password: {derived_key.hex()}")
print(f"Salt: {salt.hex()}")
