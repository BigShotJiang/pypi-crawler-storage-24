# murmr Python SDK

## Overview

Python SDK for the murmr TTS API. Mirrors the Node.js SDK (`@murmr/sdk`) in snake_case.

## Structure

```
src/murmr/
  __init__.py          # Public exports
  _client.py           # AsyncMurmrClient + MurmrClient
  _types.py            # Pydantic v2 response models (frozen)
  _errors.py           # MurmrError, MurmrChunkError
  _validate.py         # Input/ID validation
  _streaming.py        # SSE parsing, collect as WAV/PCM
  _audio.py            # WAV header, silence, concat
  _chunker.py          # Sentence-boundary text splitting
  resources/
    speech.py          # Batch, streaming, long-form
    voices.py          # Voice design (batch + streaming)
    jobs.py            # Job polling
```

## Commands

```bash
# Install
pip install -e ".[dev]"

# Test
pytest -v

# Type check
mypy src/murmr/

# Lint
ruff check src/ tests/

# Coverage
pytest --cov=murmr --cov-report=term-missing
```

## Conventions

- **Async-first, sync support:** Every resource has Async + Sync variants
- **kwargs, not models:** Methods take keyword arguments (like OpenAI SDK)
- **`input` maps to `text`:** Public API uses `input`, request body uses `text`
- **Pydantic v2 frozen models:** All response types are immutable
- **No httpx-sse:** SSE parsed manually via `iter_lines()`
- **Context managers:** Streaming methods return context managers that yield typed chunks
