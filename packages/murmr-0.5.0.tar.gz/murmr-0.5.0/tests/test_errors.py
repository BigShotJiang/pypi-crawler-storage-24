"""Tests for _errors module."""

from __future__ import annotations

import pytest

from murmr._errors import MurmrChunkError, MurmrError


class TestMurmrError:
    def test_basic_error(self) -> None:
        err = MurmrError("something failed")
        assert str(err) == "something failed"
        assert err.status is None
        assert err.code is None
        assert err.type is None
        assert err.concurrent_limit is None
        assert err.concurrent_active is None

    def test_error_with_all_fields(self) -> None:
        err = MurmrError(
            "rate limited",
            status=429,
            code="rate_limit_exceeded",
            type="rate_limit",
            concurrent_limit=5,
            concurrent_active=5,
        )
        assert str(err) == "rate limited"
        assert err.status == 429
        assert err.code == "rate_limit_exceeded"
        assert err.type == "rate_limit"
        assert err.concurrent_limit == 5
        assert err.concurrent_active == 5

    def test_is_exception(self) -> None:
        err = MurmrError("test")
        assert isinstance(err, Exception)
        with pytest.raises(MurmrError):
            raise err


class TestMurmrChunkError:
    def test_basic_chunk_error(self) -> None:
        err = MurmrChunkError(
            "chunk 3/5 failed",
            chunk_index=2,
            completed_chunks=2,
            total_chunks=5,
        )
        assert str(err) == "chunk 3/5 failed"
        assert err.chunk_index == 2
        assert err.completed_chunks == 2
        assert err.total_chunks == 5
        assert err.status is None

    def test_inherits_from_murmr_error(self) -> None:
        err = MurmrChunkError(
            "failed",
            chunk_index=0,
            completed_chunks=0,
            total_chunks=1,
        )
        assert isinstance(err, MurmrError)
        assert isinstance(err, Exception)

    def test_inherits_api_fields_from_cause(self) -> None:
        cause = MurmrError(
            "rate limited",
            status=429,
            code="rate_limit_exceeded",
            type="rate_limit",
            concurrent_limit=3,
            concurrent_active=3,
        )
        err = MurmrChunkError(
            "chunk failed due to rate limit",
            chunk_index=1,
            completed_chunks=1,
            total_chunks=5,
            cause=cause,
        )
        assert err.status == 429
        assert err.code == "rate_limit_exceeded"
        assert err.type == "rate_limit"
        assert err.concurrent_limit == 3
        assert err.concurrent_active == 3
        assert err.__cause__ is cause

    def test_non_murmr_cause_does_not_inherit_fields(self) -> None:
        cause = ValueError("bad value")
        err = MurmrChunkError(
            "chunk failed",
            chunk_index=0,
            completed_chunks=0,
            total_chunks=3,
            cause=cause,
        )
        assert err.status is None
        assert err.code is None
        assert err.__cause__ is cause
