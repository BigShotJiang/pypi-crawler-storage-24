"""Tests for _validate module."""

from __future__ import annotations

import pytest

from murmr._errors import MurmrError
from murmr._validate import MAX_INPUT_LENGTH, validate_id, validate_input


class TestValidateInput:
    def test_valid_input(self) -> None:
        validate_input("Hello, world!")  # should not raise

    def test_empty_string_raises(self) -> None:
        with pytest.raises(MurmrError, match="required and cannot be empty"):
            validate_input("")

    def test_whitespace_only_raises(self) -> None:
        with pytest.raises(MurmrError, match="required and cannot be empty"):
            validate_input("   ")

    def test_exceeds_max_length(self) -> None:
        long_text = "a" * (MAX_INPUT_LENGTH + 1)
        with pytest.raises(MurmrError, match="exceeds.*character limit"):
            validate_input(long_text)

    def test_at_max_length_is_ok(self) -> None:
        validate_input("a" * MAX_INPUT_LENGTH)  # should not raise


class TestValidateId:
    def test_valid_ids(self) -> None:
        validate_id("voice_abc123", "voiceId")
        validate_id("job-def-456", "jobId")
        validate_id("simple", "id")

    def test_empty_string_raises(self) -> None:
        with pytest.raises(MurmrError, match="Invalid jobId"):
            validate_id("", "jobId")

    def test_special_chars_raise(self) -> None:
        with pytest.raises(MurmrError, match="Invalid voiceId"):
            validate_id("voice/bad", "voiceId")

    def test_spaces_raise(self) -> None:
        with pytest.raises(MurmrError, match="Invalid id"):
            validate_id("has spaces", "id")
