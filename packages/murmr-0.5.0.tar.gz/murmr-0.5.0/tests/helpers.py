"""Shared test helpers for murmr SDK tests."""

from __future__ import annotations

import base64

BASE_URL = "https://api.murmr.dev"


def make_sse_body(*audio_chunks: bytes, include_done: bool = True) -> bytes:
    """Build an SSE response body from PCM audio chunks.

    Each chunk is base64-encoded and wrapped in an SSE data line.
    A final done event is appended unless include_done=False.
    """
    lines: list[str] = []
    for i, pcm in enumerate(audio_chunks):
        b64 = base64.b64encode(pcm).decode()
        lines.append(f'data: {{"audio": "{b64}", "chunk_index": {i}}}')
        lines.append("")
    if include_done:
        lines.append(f'data: {{"done": true, "total_chunks": {len(audio_chunks)}}}')
        lines.append("")
    return "\n".join(lines).encode()
