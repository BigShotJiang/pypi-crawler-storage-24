"""Shared fixtures for murmr SDK tests."""
