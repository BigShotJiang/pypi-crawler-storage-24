"""Error classes for the murmr SDK."""

from __future__ import annotations


class MurmrError(Exception):
    """Base error for all murmr API errors.

    Attributes:
        status: HTTP status code, if the error originated from an API response.
        code: Machine-readable error code (e.g. 'rate_limit_exceeded').
        type: Error type from the API response.
        concurrent_limit: Max concurrent requests allowed (rate limit errors).
        concurrent_active: Current in-flight requests (rate limit errors).
    """

    def __init__(
        self,
        message: str,
        *,
        status: int | None = None,
        code: str | None = None,
        type: str | None = None,
        concurrent_limit: int | None = None,
        concurrent_active: int | None = None,
    ) -> None:
        super().__init__(message)
        self.message = message
        self.status = status
        self.code = code
        self.type = type
        self.concurrent_limit = concurrent_limit
        self.concurrent_active = concurrent_active


class MurmrChunkError(MurmrError):
    """Error during long-form chunk generation.

    Carries context about which chunk failed and how many completed,
    enabling callers to resume from the failure point.

    Attributes:
        chunk_index: Zero-based index of the chunk that failed.
        completed_chunks: Number of chunks successfully generated before failure.
        total_chunks: Total number of chunks in the long-form request.
    """

    def __init__(
        self,
        message: str,
        *,
        chunk_index: int,
        completed_chunks: int,
        total_chunks: int,
        cause: Exception | None = None,
    ) -> None:
        # Inherit API error fields from the cause if it's a MurmrError
        status: int | None = None
        code: str | None = None
        type_: str | None = None
        concurrent_limit: int | None = None
        concurrent_active: int | None = None
        if isinstance(cause, MurmrError):
            status = cause.status
            code = cause.code
            type_ = cause.type
            concurrent_limit = cause.concurrent_limit
            concurrent_active = cause.concurrent_active

        super().__init__(
            message,
            status=status,
            code=code,
            type=type_,
            concurrent_limit=concurrent_limit,
            concurrent_active=concurrent_active,
        )
        self.chunk_index = chunk_index
        self.completed_chunks = completed_chunks
        self.total_chunks = total_chunks
        self.__cause__ = cause
