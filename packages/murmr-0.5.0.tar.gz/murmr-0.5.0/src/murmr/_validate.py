"""Input validation helpers."""

from __future__ import annotations

import re

from murmr._errors import MurmrError

MAX_INPUT_LENGTH = 4096

_ID_PATTERN = re.compile(r"^[\w-]+$")


def validate_input(input_text: str) -> None:
    """Validate that input text is non-empty and within the API character limit."""
    if not input_text or not input_text.strip():
        raise MurmrError("input text is required and cannot be empty")
    if len(input_text) > MAX_INPUT_LENGTH:
        raise MurmrError(
            f"input text exceeds {MAX_INPUT_LENGTH} character limit. "
            "Use create_long_form() for longer text."
        )


def validate_id(value: str, label: str) -> None:
    """Validate that an ID contains only alphanumeric characters, hyphens, or underscores."""
    if not value or not _ID_PATTERN.match(value):
        raise MurmrError(
            f"Invalid {label}: must contain only alphanumeric characters, "
            "hyphens, or underscores"
        )
