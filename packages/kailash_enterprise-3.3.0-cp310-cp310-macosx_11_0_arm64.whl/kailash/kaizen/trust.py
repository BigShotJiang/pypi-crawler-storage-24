"""Kailash Kaizen Trust — EATP posture management.

Re-exports Rust-backed trust types::

    from kailash.kaizen.trust import PostureSystem, EatpPosture, Capability

All classes are backed by the ``eatp`` Rust crate via PyO3.
"""

try:
    from kailash._kailash import (
        PostureSystem,
        EatpPosture,
        Capability,
        TrustLevel,
        TrustPosture,
    )
except ImportError:
    PostureSystem = None  # type: ignore[assignment,misc]
    EatpPosture = None  # type: ignore[assignment,misc]
    Capability = None  # type: ignore[assignment,misc]
    TrustLevel = None  # type: ignore[assignment,misc]
    TrustPosture = None  # type: ignore[assignment,misc]

__all__ = [
    "PostureSystem",
    "EatpPosture",
    "Capability",
    "TrustLevel",
    "TrustPosture",
]
