"""Agent manifest introspection and deployment utilities.

Pure Python utilities for inspecting agent classes at runtime and deploying
agent manifests to Aegis.

Re-exports Rust-backed manifest types::

    from kailash.kaizen.manifest import AgentManifest, AppManifest, GovernanceSection

Pure Python utilities::

    from kailash.kaizen.manifest import introspect_agent, deploy_to_aegis

Example::

    # Introspect an agent class
    info = introspect_agent("my_project.agents", "ResearchAgent")
    print(info["name"], info["tools"])

    # Deploy to Aegis
    result = deploy_to_aegis(manifest_dict, api_key="...", target_url="https://aegis.example.com")
"""

import importlib
import inspect
import json
import urllib.request
import warnings

# Re-export Rust-backed types
try:
    from kailash._kailash import (
        AgentManifest,
        AppManifest,
        GovernanceSection,
    )
except ImportError:
    AgentManifest = None  # type: ignore[assignment,misc]
    AppManifest = None  # type: ignore[assignment,misc]
    GovernanceSection = None  # type: ignore[assignment,misc]


def introspect_agent(module_name: str, class_name: str) -> dict:
    """Introspect a Python agent class and extract manifest-compatible info.

    Loads the given module, finds the class, and extracts metadata including
    the docstring, tools, and capabilities.

    Args:
        module_name: Fully qualified Python module path (e.g., ``"my_project.agents"``).
        class_name: Name of the agent class within the module.

    Returns:
        A dict with keys: ``name``, ``module``, ``class_name``, ``description``,
        ``tools``, ``capabilities``. Compatible with ``AgentManifest`` fields.

    Raises:
        ModuleNotFoundError: If the module cannot be imported.
        AttributeError: If the class does not exist in the module.

    Example::

        info = introspect_agent("my_project.agents", "ResearchAgent")
        print(info["description"])
        print(info["tools"])
    """
    mod = importlib.import_module(module_name)
    cls = getattr(mod, class_name)

    result: dict = {
        "name": class_name,
        "module": module_name,
        "class_name": class_name,
        "description": inspect.getdoc(cls) or "",
        "tools": [],
        "capabilities": [],
    }

    # Extract tools from class attribute or get_tools() method
    if hasattr(cls, "tools"):
        tools_attr = cls.tools
        if callable(tools_attr):
            # tools is a method, not a plain attribute -- skip (use get_tools below)
            pass
        else:
            result["tools"] = [
                t if isinstance(t, str) else getattr(t, "name", str(t))
                for t in tools_attr
            ]

    if hasattr(cls, "get_tools"):
        try:
            tools_result = cls.get_tools()
            result["tools"] = [
                t if isinstance(t, str) else getattr(t, "name", str(t))
                for t in tools_result
            ]
        except TypeError:
            pass  # get_tools() is an unbound method requiring self; fall back to class attribute
        except Exception as exc:
            warnings.warn(
                f"introspect_agent: {class_name}.get_tools() raised {type(exc).__name__}: {exc}",
                stacklevel=2,
            )

    # Extract capabilities from class attribute
    if hasattr(cls, "capabilities"):
        caps_attr = cls.capabilities
        if callable(caps_attr):
            try:
                result["capabilities"] = list(caps_attr())
            except TypeError:
                pass  # capabilities() is an unbound method requiring self
            except Exception as exc:
                warnings.warn(
                    f"introspect_agent: {class_name}.capabilities() raised "
                    f"{type(exc).__name__}: {exc}",
                    stacklevel=2,
                )
        else:
            result["capabilities"] = list(caps_attr)

    return result


def deploy_to_aegis(
    manifest: dict, api_key: str, target_url: str, timeout: int = 30
) -> dict:
    """Deploy an agent manifest to Aegis.

    Sends a POST request to the Aegis agent registration endpoint with the
    manifest data and authentication credentials.

    Args:
        manifest: Agent manifest as a dict (compatible with ``AgentManifest`` fields).
        api_key: Aegis API key for authentication.
        target_url: Base URL of the Aegis instance (e.g., ``"https://aegis.example.com"``).

    Returns:
        The response body parsed as a dict.

    Raises:
        urllib.error.URLError: If the request fails due to network issues.
        urllib.error.HTTPError: If the server returns an error status code.
        json.JSONDecodeError: If the response body is not valid JSON.

    Example::

        result = deploy_to_aegis(
            manifest={"name": "my-agent", "version": "1.0.0", ...},
            api_key="aegis-api-key-here",
            target_url="https://aegis.example.com",
        )
        print(result)
    """
    from urllib.parse import urlparse

    parsed = urlparse(target_url)
    if parsed.scheme not in ("https", "http"):
        raise ValueError(
            f"target_url must use https:// or http:// scheme, got {parsed.scheme!r}"
        )

    data = json.dumps(manifest).encode("utf-8")
    url = f"{target_url.rstrip('/')}/api/v1/agents/register"
    req = urllib.request.Request(
        url,
        data=data,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        },
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


__all__ = [
    "AgentManifest",
    "AppManifest",
    "GovernanceSection",
    "introspect_agent",
    "deploy_to_aegis",
]
