"""Kailash Enterprise — high-performance Rust-powered workflow engine.

Drop-in replacement for the ``kailash`` Python SDK. Install with::

    pip install kailash-enterprise

This package uses the same ``import kailash`` namespace as the open-source
Python SDK, so existing code works without any import changes.

**New API (v2)** -- direct access to Rust-backed types::

    import kailash

    reg = kailash.NodeRegistry()
    builder = kailash.WorkflowBuilder()
    builder.add_node("NoOpNode", "n1")
    wf = builder.build(reg)
    rt = kailash.Runtime(reg)
    result = rt.execute(wf)
    # result is a dict: {"results": ..., "run_id": ..., "metadata": ...}

**Framework bindings** -- DataFlow, Enterprise, Kaizen, Nexus::

    from kailash._kailash import DataFlow, ModelDefinition, FieldType
    from kailash._kailash import RbacEvaluator, Role, User, Permission
    from kailash._kailash import Agent, AgentConfig, LlmClient, CostTracker
    from kailash._kailash import Nexus, NexusConfig, Preset

**Legacy API (v0.12 compatible)** -- drop-in replacement for the Python SDK::

    from kailash.runtime import LocalRuntime
    from kailash.workflow.builder import WorkflowBuilder

    builder = WorkflowBuilder()
    builder.add_node("NoOpNode", "n1")
    wf = builder.build()          # no registry arg needed
    runtime = LocalRuntime()
    results, run_id = runtime.execute(wf)  # returns (dict, str) tuple

Both APIs work simultaneously. The legacy API emits deprecation warnings
to guide migration to the new API.
"""

from kailash._kailash import (  # noqa: F401
    # Core
    NodeRegistry,
    RuntimeConfig,
    Runtime,
    Workflow,
    WorkflowBuilder,
    # DataFlow
    AggregateOp,
    AggregateSpec,
    DataFlow,
    DataFlowConfig,
    DataFlowExpress,
    DataFlowInspector,
    DataFlowTransaction,
    ModelDefinition,
    FieldType,
    FieldDef,
    FilterCondition,
    PoolSize,
    PoolMetrics,
    TenantContext,
    QueryInterceptor,
    # Migration
    Migration,
    MigrationManager,
    # Enterprise
    Permission,
    Role,
    User,
    RbacEvaluator,
    AbacPolicy,
    AbacEvaluator,
    AuditLogger,
    AuditFilter,
    AccessDecision,
    TenantStatus,
    TenantInfo,
    EnterpriseTenantContext,
    TenantRegistry,
    RbacPolicy,
    RbacPolicyBuilder,
    RoleBuilder,
    SecurityClassification,
    EnterpriseContext,
    PolicyEngine,
    ComplianceManager,
    TokenManager,
    SSOProvider,
    # Kaizen
    AgentConfig,
    LlmClient,
    Agent,
    CostTracker,
    OrchestrationRuntime,
    # Kaizen - Tools
    ToolParam,
    ToolDef,
    ToolRegistry,
    # Kaizen - Memory
    SessionMemory,
    SharedMemory,
    PersistentMemory,
    # Kaizen - Checkpoint
    AgentCheckpoint,
    InMemoryCheckpointStorage,
    FileCheckpointStorage,
    # Kaizen - A2A
    AgentCard,
    AgentRegistry,
    InMemoryMessageBus,
    A2AProtocol,
    # Kaizen - Trust
    TrustLevel,
    TrustPosture,
    EatpPosture,
    VerificationConfig,
    VerificationResult,
    ResourceUsageSnapshot,
    HumanCompetency,
    CompetencyRequirement,
    ComplianceStatus,
    ComplianceReport,
    # Kaizen - Trust Gaps (EG-013)
    MultiSigPolicy,
    MultiSigBundle,
    MultiSigResult,
    ShadowEnforcer,
    ShadowReport,
    CircuitBreakerConfig,
    CircuitBreakerRegistry,
    # Kaizen - Structured Output
    OutputSchema,
    RetryConfig,
    StructuredOutput,
    # Nexus
    NexusConfig,
    HandlerParam,
    Preset,
    JwtConfig,
    JwtClaims,
    RbacConfig,
    AuthRateLimitConfig,
    MiddlewareConfig,
    McpServer,
    EventBus,
    WorkflowRegistry,
    PluginManager,
    # Infrastructure (v2.8.0)
    SagaStepDef,
    SagaDefinition,
    SagaStepStatus,
    SagaStepState,
    SagaStatus,
    SagaState,
    InMemorySagaStore,
    IdempotencyKeyStrategy,
    WorkflowTask,
    TaskStatus,
    TaskInfo,
    InProcessTaskQueue,
    InfraLevel,
    ShutdownToken,
    ConfiguredInfra,
    configure_from_env,
    configure_from_env_full,
)
from kailash.nexus._nexus_ext import Nexus  # noqa: F401
from kailash.nexus.health import HealthMonitor, HealthMonitorConfig  # noqa: F401

# Infrastructure — import as kailash.infra
import kailash.infra  # noqa: F401

# Trust Plane — import as kailash.trust_plane
import kailash.trust_plane  # noqa: F401

try:
    from importlib.metadata import version as _pkg_version

    __version__ = _pkg_version("kailash-enterprise")
except Exception:
    __version__ = "2.9.4"

# Guard: kailash-enterprise and kailash (pure Python) cannot coexist.
# Both install a `kailash/` package — whichever is installed last wins,
# causing silent corruption (missing Rust types or missing Python compat).
try:
    from importlib.metadata import version as _pkg_ver

    _py_version = _pkg_ver("kailash")
    import warnings

    warnings.warn(
        f"Both 'kailash-enterprise' ({__version__}) and 'kailash' ({_py_version}) "
        f"are installed. These packages conflict — they both provide the 'kailash' "
        f"namespace. Please uninstall one:\n"
        f"  pip uninstall kailash        # if using kailash-enterprise (Rust-backed)\n"
        f"  pip uninstall kailash-enterprise  # if using kailash (pure Python)",
        stacklevel=2,
    )
except Exception:
    pass  # kailash not installed — no conflict

__all__ = [
    # Core
    "NodeRegistry",
    "RuntimeConfig",
    "Runtime",
    "Workflow",
    "WorkflowBuilder",
    # DataFlow
    "AggregateOp",
    "AggregateSpec",
    "DataFlow",
    "DataFlowConfig",
    "DataFlowExpress",
    "DataFlowInspector",
    "DataFlowTransaction",
    "ModelDefinition",
    "FieldType",
    "FieldDef",
    "FilterCondition",
    "PoolSize",
    "PoolMetrics",
    "TenantContext",
    "QueryInterceptor",
    # Migration
    "Migration",
    "MigrationManager",
    # Enterprise
    "Permission",
    "Role",
    "User",
    "RbacEvaluator",
    "AbacPolicy",
    "AbacEvaluator",
    "AuditLogger",
    "AuditFilter",
    "AccessDecision",
    "TenantStatus",
    "TenantInfo",
    "EnterpriseTenantContext",
    "TenantRegistry",
    "RbacPolicy",
    "RbacPolicyBuilder",
    "RoleBuilder",
    "SecurityClassification",
    "EnterpriseContext",
    "PolicyEngine",
    "ComplianceManager",
    "TokenManager",
    "SSOProvider",
    # Kaizen
    "AgentConfig",
    "LlmClient",
    "Agent",
    "CostTracker",
    "OrchestrationRuntime",
    # Kaizen - Tools
    "ToolParam",
    "ToolDef",
    "ToolRegistry",
    # Kaizen - Memory
    "SessionMemory",
    "SharedMemory",
    "PersistentMemory",
    # Kaizen - Checkpoint
    "AgentCheckpoint",
    "InMemoryCheckpointStorage",
    "FileCheckpointStorage",
    # Kaizen - A2A
    "AgentCard",
    "AgentRegistry",
    "InMemoryMessageBus",
    "A2AProtocol",
    # Kaizen - Trust
    "TrustLevel",
    "TrustPosture",
    "EatpPosture",
    "VerificationConfig",
    "VerificationResult",
    "ResourceUsageSnapshot",
    "HumanCompetency",
    "CompetencyRequirement",
    "ComplianceStatus",
    "ComplianceReport",
    # Kaizen - Trust Gaps (EG-013)
    "MultiSigPolicy",
    "MultiSigBundle",
    "MultiSigResult",
    "ShadowEnforcer",
    "ShadowReport",
    "CircuitBreakerConfig",
    "CircuitBreakerRegistry",
    # Kaizen - Structured Output
    "OutputSchema",
    "RetryConfig",
    "StructuredOutput",
    # Nexus
    "Nexus",
    "NexusConfig",
    "HandlerParam",
    "Preset",
    "JwtConfig",
    "JwtClaims",
    "RbacConfig",
    "AuthRateLimitConfig",
    "MiddlewareConfig",
    "McpServer",
    "EventBus",
    "WorkflowRegistry",
    "PluginManager",
    # Nexus - Health Monitoring
    "HealthMonitor",
    "HealthMonitorConfig",
    # Infrastructure (v2.8.0)
    "SagaStepDef",
    "SagaDefinition",
    "SagaStepStatus",
    "SagaStepState",
    "SagaStatus",
    "SagaState",
    "InMemorySagaStore",
    "IdempotencyKeyStrategy",
    "WorkflowTask",
    "TaskStatus",
    "TaskInfo",
    "InProcessTaskQueue",
    "InfraLevel",
    "ShutdownToken",
    "ConfiguredInfra",
    "configure_from_env",
    "configure_from_env_full",
    # Meta
    "__version__",
]
