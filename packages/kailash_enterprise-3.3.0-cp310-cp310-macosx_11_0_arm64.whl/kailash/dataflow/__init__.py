"""Kailash DataFlow -- zero-config database framework.

Re-exports Rust-backed DataFlow types and Pythonic compat helpers::

    # Rust-backed types
    from kailash.dataflow import DataFlow, DataFlowConfig
    from kailash.dataflow import ModelDefinition, FieldType, FieldDef
    from kailash.dataflow import FilterCondition
    from kailash.dataflow import DataFlowTransaction
    from kailash.dataflow import TenantContext, QueryInterceptor
    from kailash.dataflow import AggregateOp, AggregateSpec

    # Pythonic helpers
    from kailash.dataflow import db, F, with_tenant

All Rust types are backed by the ``kailash-dataflow`` Rust crate
via PyO3 for maximum performance. The Python helpers provide ergonomic
wrappers on top.
"""

from kailash._kailash import (
    AggregateOp,
    AggregateSpec,
    DataFlow,
    DataFlowConfig,
    DataFlowExpress,
    DataFlowInspector,
    DataFlowTransaction,
    DebugAgent,
    ErrorEnhancer,
    FieldDef,
    FieldType,
    FilterCondition,
    LoggingConfig,
    ModelDefinition,
    QueryInterceptor,
    SchemaCache,
    StrictMode,
    TenantContext,
    ValidationLayer,
)

from kailash.dataflow.filter import F
from kailash.dataflow.model import db
from kailash.dataflow.tenancy import with_tenant

__all__ = [
    # Rust-backed types
    "AggregateOp",
    "AggregateSpec",
    "DataFlow",
    "DataFlowConfig",
    "DataFlowExpress",
    "DataFlowInspector",
    "DataFlowTransaction",
    "DebugAgent",
    "ErrorEnhancer",
    "ModelDefinition",
    "FieldType",
    "FieldDef",
    "FilterCondition",
    "LoggingConfig",
    "SchemaCache",
    "StrictMode",
    "TenantContext",
    "QueryInterceptor",
    "ValidationLayer",
    # Python compat helpers
    "db",
    "F",
    "with_tenant",
]
