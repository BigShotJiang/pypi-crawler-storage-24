"""Kailash PACT Governance Framework.

Re-exports Rust-backed PACT governance types::

    from kailash.pact import GovernanceEngine
    from kailash.pact import GovernanceContext, GovernanceVerdict
    from kailash.pact import Address, ClassificationLevel
    from kailash.pact import KnowledgeItem, AccessDecision

All classes are backed by the ``kailash-pact`` Rust crate via PyO3.

Example::

    from kailash.pact import GovernanceEngine

    engine = GovernanceEngine('{"org_id":"test","name":"Test Org","departments":[]}')
    status = engine.get_vacancy_status()
    print(f"Total roles: {status.total_roles}")
"""

from kailash._kailash import (
    # Engine
    PactGovernanceEngine as GovernanceEngine,
    # Context
    PactGovernanceContext as GovernanceContext,
    # Decision types
    PactGovernanceVerdict as GovernanceVerdict,
    PactAccessDecision as AccessDecision,
    # Address
    PactAddress as Address,
    # Org structure
    PactCompiledOrg as CompiledOrg,
    PactOrgNode as OrgNode,
    PactVacancyStatus as VacancyStatus,
    # Classification
    PactClassificationLevel as ClassificationLevel,
    PactRoleClearance as RoleClearance,
    # Envelopes
    PactRoleEnvelope as RoleEnvelope,
    PactTaskEnvelope as TaskEnvelope,
    PactEffectiveEnvelopeSnapshot as EffectiveEnvelopeSnapshot,
    # Bridges and policies
    PactBridge as Bridge,
    PactKnowledgeItem as KnowledgeItem,
    PactKnowledgeSharePolicy as KnowledgeSharePolicy,
)

__all__ = [
    "GovernanceEngine",
    "GovernanceContext",
    "GovernanceVerdict",
    "AccessDecision",
    "Address",
    "CompiledOrg",
    "OrgNode",
    "VacancyStatus",
    "ClassificationLevel",
    "RoleClearance",
    "RoleEnvelope",
    "TaskEnvelope",
    "EffectiveEnvelopeSnapshot",
    "Bridge",
    "KnowledgeItem",
    "KnowledgeSharePolicy",
]
