"""Kailash Infrastructure -- saga management, task queues, and auto-configuration.

Re-exports Rust-backed infrastructure types for enterprise workflow
orchestration::

    # Saga store
    from kailash.infra import InMemorySagaStore, SagaDefinition, SagaStepDef
    from kailash.infra import SagaState, SagaStatus, SagaStepState, SagaStepStatus

    # Task queue
    from kailash.infra import InProcessTaskQueue, WorkflowTask
    from kailash.infra import TaskInfo, TaskStatus

    # Idempotency
    from kailash.infra import IdempotencyKeyStrategy

    # Auto-configuration
    from kailash.infra import InfraLevel, ConfiguredInfra
    from kailash.infra import configure_from_env, configure_from_env_full

All types are backed by the ``kailash-core`` Rust crate via PyO3 for
maximum performance.

Example::

    from kailash.infra import InMemorySagaStore, SagaDefinition, SagaStepDef

    store = InMemorySagaStore()
    saga = SagaDefinition("order-001", "run-001", [
        SagaStepDef("charge_card", "refund_card"),
        SagaStepDef("reserve_inventory", "release_inventory"),
    ])
    store.create(saga)
    state = store.get("order-001")
    assert state.status.kind == "running"
"""

from kailash._kailash import (
    ConfiguredInfra,
    IdempotencyKeyStrategy,
    InfraLevel,
    InMemorySagaStore,
    InProcessTaskQueue,
    SagaDefinition,
    SagaState,
    SagaStatus,
    SagaStepDef,
    SagaStepState,
    SagaStepStatus,
    ShutdownToken,
    TaskInfo,
    TaskStatus,
    WorkflowTask,
    configure_from_env,
    configure_from_env_full,
)

__all__ = [
    # Saga types
    "SagaStepDef",
    "SagaDefinition",
    "SagaStepStatus",
    "SagaStepState",
    "SagaStatus",
    "SagaState",
    "InMemorySagaStore",
    # Idempotency
    "IdempotencyKeyStrategy",
    # Task queue
    "WorkflowTask",
    "TaskStatus",
    "TaskInfo",
    "InProcessTaskQueue",
    # Infrastructure level and auto-configuration
    "InfraLevel",
    "ConfiguredInfra",
    "configure_from_env",
    "configure_from_env_full",
    # Shutdown token
    "ShutdownToken",
]
