# Syntactical

> **_The programing language of the future._**

### What is Syntactical?

Syntactical is a programming language made with Python, that is meant to be like Python, but with better syntax.

### Where do I get it?

You can install Syntactical with pip via the command: `pip install syntactical`.

### Documentation

Documentation is under construction. The current documentation can be found [here](https://syntactical.cool62.net).

### Visual Studio Code Extension

Syntactical has a VSCode extension! See it's GitHub Repository [here](https://github.com/thecoolguy62aws/syntactical-vscode). Download it for Visual Studio Code [here](https://marketplace.visualstudio.com/items?itemName=thecoolguy62aws.syntactical).

### Updates

**Here's a small section with some of the new things with Syntactical**:

> We are (yet again) switching away from GitHub Releases do to some issues with it. All new releases will just be on PyPI and old releases have been removed from GitHub Releases. New releases will be automatically published to PyPI using a GitHub Workflow.
