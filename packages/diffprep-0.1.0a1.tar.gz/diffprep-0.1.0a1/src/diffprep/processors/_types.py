from __future__ import annotations

from collections.abc import Callable

from diffprep.core import Settings

type Processor = Callable[[bytes, Settings], bytes]
# type Processor = Callable[[bytes], bytes]


class ProcessorRegistryError(Exception):
    """Base error for processor registry problems."""


class DuplicateProcessorError(ProcessorRegistryError):
    """Raised when a processor is registered twice for the same input type."""


class UnknownProcessorError(ProcessorRegistryError):
    """Raised when no processor exists for the requested input type."""
