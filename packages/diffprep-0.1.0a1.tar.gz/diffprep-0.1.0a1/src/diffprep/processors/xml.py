import logging

from diffprep.core import Settings
from diffprep.processors import register_processor
from diffprep.types import InputType

logger = logging.getLogger(__name__)


@register_processor(input_type=InputType.XML)
def process_xml(data: bytes, settings: Settings) -> bytes:
    logger.debug(settings)

    out: bytes = data
    return out
