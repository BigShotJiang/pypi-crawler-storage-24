from __future__ import annotations

import logging

from diffprep.core.logger import setup_logging

from .configs import (
    CliOptions,
    JsonSettings,
    NormalizeSettings,
    Settings,
    XmlSettings,
)

_CURRENT_SETTINGS: Settings | None = None


def init_settings(cli_options: CliOptions) -> Settings:
    global _CURRENT_SETTINGS

    settings = Settings(cli_options=cli_options)

    if cli_options is not None:
        settings = cli_options.apply_to(settings)

    setup_logging(settings.logger_settings)
    logging.debug("Settings initialized: \n%s\n", settings.model_dump_json(indent=4))

    _CURRENT_SETTINGS = settings
    return settings


def get_settings() -> Settings:
    if _CURRENT_SETTINGS is None:
        raise RuntimeError("Settings have not been initialized.")
    return _CURRENT_SETTINGS


__all__ = [
    "JsonSettings",
    "NormalizeSettings",
    "Settings",
    "XmlSettings",
    "get_settings",
    "init_settings",
]
