from __future__ import annotations

import typer

from diffprep.cli.commands import init as init_module
from diffprep.cli.commands.json import json_command
from diffprep.cli.commands.xml import xml_command

app = typer.Typer(help="Command-line JSON and XML diff preprocessor.")

app.command("json")(json_command)
app.command("xml")(xml_command)
app.add_typer(init_module.app, name="init")


if __name__ == "__main__":
    app()
