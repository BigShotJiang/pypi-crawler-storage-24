from __future__ import annotations

import logging
from pathlib import Path
from typing import Annotated

import typer

from diffprep.cli.commands._normalize import run_normalizer
from diffprep.cli.models import JsonCliOptions
from diffprep.core import init_settings
from diffprep.types import InputType

logger = logging.getLogger(__name__)


def json_command(
    path: Annotated[Path, typer.Argument(exists=True, readable=True)],
    question: Annotated[str | None, typer.Option("--question", "-q")] = None,
    drop_keys: Annotated[
        list[str] | None,
        typer.Option(
            "--drop-key",
            "-d",
            help="Remove one or more JSON keys before normalization.",
        ),
    ] = None,
) -> None:
    cli_options = JsonCliOptions(
        input_type=InputType.JSON,
        question=question,
        drop_keys=set(drop_keys or ()),
    )
    settings = init_settings(cli_options)
    logging.debug(settings)

    run_normalizer(settings, path)
