from __future__ import annotations

from pathlib import Path

import typer

from diffprep.cli.io import write_stdout_bytes
from diffprep.cli.prompting import build_llm_prompt, build_prompt_context
from diffprep.core import Settings
from diffprep.processors import get_processor


def read_input_bytes(path: Path) -> bytes:
    try:
        return path.read_bytes()
    except OSError as exc:
        raise typer.BadParameter(f"Could not read input file: {path}") from exc


def run_normalizer(settings: Settings, path: Path) -> None:
    if not settings.cli_options:
        return
    data = read_input_bytes(path)

    processor = get_processor(settings)
    out = processor(data, settings)

    if settings.cli_options.question:
        context = build_prompt_context(
            question=settings.cli_options.question,
            input_type=settings.cli_options.input_type,
            original_input=data,
            normalized_output=out,
            settings=settings,
        )
        prompt = build_llm_prompt(context)
        write_stdout_bytes(prompt.encode("utf-8"))
        return

    write_stdout_bytes(out)
