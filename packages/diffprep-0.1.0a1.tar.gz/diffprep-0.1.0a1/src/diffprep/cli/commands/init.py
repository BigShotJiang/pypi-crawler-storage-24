from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Final, Literal

import typer

TOOL_NAME: Final[str] = "diffprep"
BEGIN_MARKER: Final[str] = "# BEGIN diffprep"
END_MARKER: Final[str] = "# END diffprep"

Status = Literal["created", "updated", "unchanged"]

app = typer.Typer()


@dataclass(frozen=True, slots=True)
class DiffDriver:
    pattern: str
    command_name: str


DEFAULT_DRIVERS: Final[tuple[DiffDriver, ...]] = (
    DiffDriver("*.json", "json"),
    DiffDriver("*.xml", "xml"),
)


def render_gitattributes() -> str:
    lines = [BEGIN_MARKER]
    lines.extend(
        f"{driver.pattern} diff={driver.command_name}" for driver in DEFAULT_DRIVERS
    )
    lines.append(END_MARKER)
    return "\n".join(lines) + "\n"


def render_gitconfig_repo() -> str:
    lines = [BEGIN_MARKER]

    for driver in DEFAULT_DRIVERS:
        lines.extend(
            (
                f'[diff "{driver.command_name}"]',
                f"    textconv = {TOOL_NAME} {driver.command_name}",
                "",
            )
        )

    if lines[-1] == "":
        lines.pop()

    lines.append(END_MARKER)
    return "\n".join(lines) + "\n"


def render_unix_wrapper() -> str:
    return """#!/usr/bin/env sh
set -eu

repo_root="$(git rev-parse --show-toplevel)"
git -c include.path="$repo_root/.gitconfig.repo" diff "$@"
"""


def replace_or_append_managed_block(existing: str, managed_block: str) -> str:
    begin_index = existing.find(BEGIN_MARKER)
    end_index = existing.find(END_MARKER)

    if begin_index != -1 and end_index != -1 and end_index > begin_index:
        before = existing[:begin_index].rstrip()
        after = existing[end_index + len(END_MARKER) :].lstrip()

        parts: list[str] = []
        if before:
            parts.append(before)
        parts.append(managed_block.rstrip())
        if after:
            parts.append(after)
        return "\n\n".join(parts) + "\n"

    existing_clean = existing.rstrip()
    if not existing_clean:
        return managed_block

    return f"{existing_clean}\n\n{managed_block}"


def write_text_file(path: Path, content: str) -> Status:
    previous = path.read_text(encoding="utf-8") if path.exists() else None
    if previous == content:
        return "unchanged"

    path.write_text(content, encoding="utf-8")
    return "created" if previous is None else "updated"


def write_managed_block_file(path: Path, managed_block: str) -> Status:
    existing = path.read_text(encoding="utf-8") if path.exists() else ""
    new_content = replace_or_append_managed_block(existing, managed_block)

    if existing == new_content:
        return "unchanged"

    path.write_text(new_content, encoding="utf-8")
    return "created" if not existing else "updated"


def make_executable(path: Path) -> None:
    path.chmod(path.stat().st_mode | 0o111)


def run_init() -> None:
    gitattributes_path = Path(".gitattributes")
    gitconfig_repo_path = Path(".gitconfig.repo")
    wrapper_path = Path(TOOL_NAME)

    gitattributes_status = write_managed_block_file(
        gitattributes_path,
        render_gitattributes(),
    )
    gitconfig_status = write_text_file(gitconfig_repo_path, render_gitconfig_repo())
    wrapper_status = write_text_file(wrapper_path, render_unix_wrapper())
    make_executable(wrapper_path)

    typer.echo(f"{gitattributes_status:9} {gitattributes_path.name}")
    typer.echo(f"{gitconfig_status:9} {gitconfig_repo_path.name}")
    typer.echo(f"{wrapper_status:9} {wrapper_path.name}")
    typer.echo()
    typer.echo("Run:")
    typer.echo(f"  ./{TOOL_NAME}")


@app.callback(invoke_without_command=True)
def main() -> None:
    run_init()


if __name__ == "__main__":
    app()
