from __future__ import annotations

from pathlib import Path
from typing import Annotated

import typer

from diffprep.cli.commands._normalize import run_normalizer
from diffprep.cli.models import XmlCliOptions
from diffprep.core import init_settings
from diffprep.types import InputType


def xml_command(
    path: Annotated[Path, typer.Argument(exists=True, readable=True)],
    question: Annotated[str | None, typer.Option("--question", "-q")] = None,
) -> None:
    cli_options = XmlCliOptions(
        input_type=InputType.XML,
        question=question,
    )
    settings = init_settings(cli_options)

    run_normalizer(settings, path)
