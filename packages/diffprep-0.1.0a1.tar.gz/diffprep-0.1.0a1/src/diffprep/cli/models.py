from typing import Literal, override

from pydantic import Field

from diffprep.core import JsonSettings, Settings, XmlSettings
from diffprep.core.configs import CliOptions
from diffprep.types import InputType


class JsonCliOptions(CliOptions, JsonSettings):
    input_type: Literal[InputType.JSON] = InputType.JSON

    drop_keys: set[str] = Field(
        default_factory=set,
        description="JSON object keys to remove recursively before output.",
    )

    def to_settings(self) -> JsonSettings:
        return JsonSettings(
            drop_keys=self.drop_keys,
            indent=None if self.style == "compact" else self.indent,
            sort_keys=self.sort_keys,
            ensure_ascii=self.ensure_ascii,
            style=self.style,
        )

    @override
    def apply_to(self, settings: Settings) -> Settings:
        json_update = self.to_settings().model_dump(exclude_unset=True)

        return settings.model_copy(
            update={
                "json_settings": settings.json_settings.model_copy(update=json_update),
            }
        )


class XmlCliOptions(CliOptions, XmlSettings):
    input_type: Literal[InputType.XML] = InputType.XML

    drop_attrs: set[str] = Field(
        default_factory=set,
        description="XML attributes to remove recursively before output.",
    )
    drop_tags: set[str] = Field(
        default_factory=set,
        description="XML tags to remove recursively before output.",
    )

    def to_settings(self) -> XmlSettings:
        return XmlSettings()

    @override
    def apply_to(self, settings: Settings) -> Settings:
        update = self.to_settings().model_dump(exclude_unset=True)

        return settings.model_copy(
            update={
                "json_settings": settings.json_settings.model_copy(update=update),
            }
        )
