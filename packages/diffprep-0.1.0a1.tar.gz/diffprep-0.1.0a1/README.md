# CLI

Command-line JSON and XML diff preprocessor.

**Usage**:

```console
$ [OPTIONS] COMMAND [ARGS]...
```

**Options**:

* `--install-completion`: Install completion for the current shell.
* `--show-completion`: Show completion for the current shell, to copy it or customize the installation.
* `--help`: Show this message and exit.

**Commands**:

* `json`
* `xml`
* `init`

## `json`

**Usage**:

```console
$ json [OPTIONS] PATH
```

**Arguments**:

* `PATH`: [required]

**Options**:

* `-q, --question TEXT`
* `-d, --drop-key TEXT`: Remove one or more JSON keys before normalization.
* `--help`: Show this message and exit.

## `xml`

**Usage**:

```console
$ xml [OPTIONS] PATH
```

**Arguments**:

* `PATH`: [required]

**Options**:

* `-q, --question TEXT`
* `--help`: Show this message and exit.

## `init`

**Usage**:

```console
$ init [OPTIONS] COMMAND [ARGS]...
```

**Options**:

* `--help`: Show this message and exit.

