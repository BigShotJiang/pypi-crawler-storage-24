"""Utility helpers for Movak."""
