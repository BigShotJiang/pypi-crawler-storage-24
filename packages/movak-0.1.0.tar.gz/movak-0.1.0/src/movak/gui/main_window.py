"""Main window placeholders."""

from __future__ import annotations


class MainWindow:
    """Top-level Movak application window."""

    def show(self) -> None:
        """Display the window."""
        pass
