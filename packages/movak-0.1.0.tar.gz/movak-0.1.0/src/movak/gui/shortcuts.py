"""Shortcut placeholders."""

from __future__ import annotations


class ShortcutRegistry:
    """Register keyboard shortcuts for the GUI."""

    def bind_defaults(self) -> None:
        """Bind default shortcuts."""
        pass
