"""GUI modules for Movak."""
