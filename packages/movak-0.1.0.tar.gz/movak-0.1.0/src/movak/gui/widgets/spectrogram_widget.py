"""Spectrogram widget placeholders."""

from __future__ import annotations


class SpectrogramWidget:
    """Widget for displaying a spectrogram."""

    def refresh(self) -> None:
        """Refresh widget content."""
        pass
