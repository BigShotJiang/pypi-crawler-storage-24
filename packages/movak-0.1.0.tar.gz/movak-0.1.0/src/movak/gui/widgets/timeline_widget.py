"""Timeline widget placeholders."""

from __future__ import annotations


class TimelineWidget:
    """Widget hosting timeline rendering."""

    def refresh(self) -> None:
        """Refresh widget content."""
        pass
