"""Tier widget placeholders."""

from __future__ import annotations


class TierWidget:
    """Widget for displaying a tier."""

    def refresh(self) -> None:
        """Refresh widget content."""
        pass
