"""Timeline panel placeholders."""

from __future__ import annotations


class TimelinePanel:
    """Central timeline panel."""

    def build(self) -> None:
        """Build panel contents."""
        pass
