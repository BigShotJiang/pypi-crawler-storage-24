"""Bottom panel placeholders."""

from __future__ import annotations


class BottomPanel:
    """Bottom status and analysis panel."""

    def build(self) -> None:
        """Build panel contents."""
        pass
