"""Right panel placeholders."""

from __future__ import annotations


class RightPanel:
    """Right-side inspector panel."""

    def build(self) -> None:
        """Build panel contents."""
        pass
