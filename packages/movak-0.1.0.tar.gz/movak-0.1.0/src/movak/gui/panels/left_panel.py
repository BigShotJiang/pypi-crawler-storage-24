"""Left panel placeholders."""

from __future__ import annotations


class LeftPanel:
    """Left-side control panel."""

    def build(self) -> None:
        """Build panel contents."""
        pass
