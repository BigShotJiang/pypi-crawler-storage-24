"""Query utilities for Movak."""
