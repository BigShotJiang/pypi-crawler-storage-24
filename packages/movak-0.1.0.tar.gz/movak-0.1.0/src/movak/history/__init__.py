"""History management for Movak."""
