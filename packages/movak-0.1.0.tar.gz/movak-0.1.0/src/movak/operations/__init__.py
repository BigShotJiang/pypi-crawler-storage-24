"""Editing operations for Movak."""
