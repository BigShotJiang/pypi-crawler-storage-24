"""Plugin support for Movak."""
