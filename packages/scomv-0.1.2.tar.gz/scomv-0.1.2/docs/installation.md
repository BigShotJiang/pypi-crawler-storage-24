# Installation

## Requirements
SpatialCompassV requires **Python 3.11 or later**.

You can check your Python version with:

```sh
python3 --version
```

## Create and activate a virtual environment (recommended)

```sh
python3 -m venv scomv_env
source scomv_env/bin/activate
```

## Stable release

To install SpatialCompassV, run this command in your terminal:

```sh
pip install scomv
```

## From source

The source files for SpatialCompassV can be downloaded from the [Github repo](https://github.com/RyosukeNomural/SpatialCompassV).

You can either clone the public repository:

```sh
git clone git://github.com/RyosukeNomural/SpatialCompassV
```


Once you have a copy of the source, you can install it with:

```sh
cd SpatialCompassV
pip install .
```
