import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from typing import Tuple, List, Optional, Dict
from typing import Tuple


def extract_roi(
    grid,
    roi: Tuple[int, int, int, int],
    bin_size: int = 10,
    region_col: str = "region_10",
):
    xmin, xmax, ymin, ymax = roi

    cond = (
        (grid.obs["imagecol"] >= xmin) &
        (grid.obs["imagecol"] <= xmax) &
        (grid.obs["imagerow"] >= ymin) &
        (grid.obs["imagerow"] <= ymax)
    )
    subset_grid = grid[cond].copy()
    subset_grid = subset_grid[~subset_grid.obs[region_col].isna()].copy()

    x0 = grid.obs["imagecol"].min()
    y0 = grid.obs["imagerow"].min()

    xy_bins = subset_grid.obs.apply(
        lambda r: (
            int((r["imagecol"] - x0) // bin_size),
            int((r["imagerow"] - y0) // bin_size),
        ),
        axis=1
    ).tolist()

    filtered_shortest = grid.shortest[grid.shortest.index.isin(xy_bins)]
    return subset_grid, filtered_shortest, xy_bins

# -------------------------
# contour / inside utilities
# -------------------------

def _xy_from_shortest_index(
    shortest_df: pd.DataFrame,
    adata,
    min_x: float, max_x: float, min_y: float, max_y: float,
    bin_size: int = 10,
):
    """shortest_df.index =  Convert (xbin, ybin) back to real coordinates and filter by ROI"""
    if shortest_df is None or len(shortest_df) == 0:
        return np.array([]), np.array([]), [], []

    points = list(shortest_df.index)
    xb, yb = zip(*points)

    # bin -> µm
    x = np.array([i * bin_size + adata.obs.imagecol.min() for i in xb])
    y = np.array([j * bin_size + adata.obs.imagerow.min() for j in yb])

    m = (min_x < x) & (x < max_x) & (min_y < y) & (y < max_y)
    x = x[m]
    y = y[m]

    gx = [int(v // bin_size) for v in x]
    gy = [int(v // bin_size) for v in y]
    return x, y, gx, gy


def _plot_points_black_bg(
    x: np.ndarray,
    y: np.ndarray,
    title: str,
    outpath: Optional[str] = None,
    color: str = "yellow",
    marker: str = "s",
    s: int = 80,
    margin: int = 300,
    show: bool = True,
    ax=None,
    label: Optional[str] = None,
):
    """ Scatter plot with a black background; draw on the given ax if provided"""
    created_fig = False
    if ax is None:
        fig, ax = plt.subplots(figsize=(5, 5), facecolor="black")
        ax.set_facecolor("black")
        created_fig = True
    else:
        fig = ax.figure

    if len(x) > 0:
        ax.scatter(x, y, color=color, s=s, marker=marker, label=label)
        ax.set_xlim(x.min() - margin, x.max() + margin)
        ax.set_ylim(y.min() - margin, y.max() + margin)

    ax.set_title(title, fontsize=10, color="white", weight="bold")
    ax.invert_yaxis()
    ax.autoscale(enable=False)
    ax.tick_params(colors="white")
    for spine in ax.spines.values():
        spine.set_edgecolor("white")

    if label is not None:
        ax.legend(
            facecolor="black",
            edgecolor="white",
            fontsize=14,
            labelcolor="white",
            frameon=True,
            loc="upper right",
            borderpad=0.5,
            handlelength=1.5,
        )

    if outpath is not None and created_fig:
        fig.savefig(outpath, dpi=300, facecolor="black", bbox_inches="tight")

    if created_fig and show:
        plt.show()
    elif created_fig and not show:
        plt.close(fig)

    return ax


def contour_regions(
    filter_grid_shortest,
    adata,
    min_x: float,
    max_x: float,
    min_y: float,
    max_y: float,
    out_dir_base: Optional[str] = None,
    bin_size: int = 10,
    outline_band=(-1.0, 0.0),
    inside_threshold: float = 0.0,
    margin: int = 30,
    show: bool = True,
):
    """
    Extract outline/inside points from grid.shortest using corrected real coordinates.

    Parameters
    ----------
    filter_grid_shortest : pd.DataFrame
        DataFrame like grid.shortest. Its index must represent (x_idx, y_idx).
    adata : AnnData-like
        Object containing obs["imagecol"] and obs["imagerow"].
    min_x, max_x, min_y, max_y : float
        ROI in real/image coordinates.
    out_dir_base : str or None
        Output base directory. Not used unless saving is enabled.
    bin_size : int
        Spatial size represented by one grid index step.
    outline_band : tuple[float, float]
        Euclidean range used for outline extraction.
    inside_threshold : float
        Euclidean threshold used for inside extraction.
        Points with euclidean < inside_threshold are treated as inside.
    margin : int
        Plot margin in real coordinates.
    show : bool
        Whether to display the figure.

    Returns
    -------
    g_x_cont, g_y_cont, g_x_inside, g_y_inside : list[int], list[int], list[int], list[int]
        Bin indices for outline and inside points.
    """

    if out_dir_base is None:
        out_dir_base = os.getcwd()
    out_dir = os.path.join(out_dir_base, f"{min_x}_{max_x}_{min_y}_{max_y}")
    # os.makedirs(out_dir, exist_ok=True)

    df = filter_grid_shortest.copy()

    # Extract bin indices from index
    if isinstance(df.index, pd.MultiIndex):
        x_idx = df.index.get_level_values(0).to_numpy(dtype=float)
        y_idx = df.index.get_level_values(1).to_numpy(dtype=float)
    else:
        x_idx = np.array([idx[0] for idx in df.index], dtype=float)
        y_idx = np.array([idx[1] for idx in df.index], dtype=float)

    # Convert bin indices to real coordinates with offset correction
    x0 = float(adata.obs["imagecol"].min())
    y0 = float(adata.obs["imagerow"].min())

    df["x_idx"] = x_idx
    df["y_idx"] = y_idx
    df["x"] = x_idx * bin_size + x0
    df["y"] = y_idx * bin_size + y0

    # Replace index with corrected real coordinates
    df.index = pd.MultiIndex.from_arrays(
        [df["x"], df["y"]],
        names=["x", "y"]
    )

    # Extract outline points in ROI
    lo, hi = outline_band
    outline_df = df[
        (df["euclidean"] >= lo) &
        (df["euclidean"] <= hi) &
        (df["x"].between(min_x, max_x)) &
        (df["y"].between(min_y, max_y))
    ].copy()

    # Extract inside points in ROI
    inside_df = df[
        (df["euclidean"] < inside_threshold) &
        (df["x"].between(min_x, max_x)) &
        (df["y"].between(min_y, max_y))
    ].copy()

    # Real coordinates for plotting
    x_out = outline_df["x"].to_numpy()
    y_out = outline_df["y"].to_numpy()
    x_in = inside_df["x"].to_numpy()
    y_in = inside_df["y"].to_numpy()

    # Original bin indices to return
    g_x_cont = outline_df["x_idx"].astype(int).tolist()
    g_y_cont = outline_df["y_idx"].astype(int).tolist()
    g_x_inside = inside_df["x_idx"].astype(int).tolist()
    g_y_inside = inside_df["y_idx"].astype(int).tolist()

    # Combined plot
    fig, ax = plt.subplots(figsize=(7, 7), facecolor="black")
    ax.set_facecolor("black")

    if len(x_out) > 0:
        ax.scatter(x_out, y_out, color="red", s=40, marker="s", label="Outside")
    if len(x_in) > 0:
        ax.scatter(x_in, y_in, color="yellow", s=40, marker="s", label="Inside")

    if len(x_out) + len(x_in) > 0:
        xs = np.concatenate([x_out, x_in]) if (len(x_out) > 0 and len(x_in) > 0) else (x_out if len(x_out) > 0 else x_in)
        ys = np.concatenate([y_out, y_in]) if (len(y_out) > 0 and len(y_in) > 0) else (y_out if len(y_out) > 0 else y_in)
        ax.set_xlim(xs.min() - margin, xs.max() + margin)
        ax.set_ylim(ys.min() - margin, ys.max() + margin)

    ax.invert_yaxis()
    ax.set_aspect("equal", adjustable="box")
    ax.tick_params(colors="white")

    for spine in ax.spines.values():
        spine.set_edgecolor("white")

    #ax.legend(facecolor="black", edgecolor="white", labelcolor="white")
    ax.set_xlabel("imagecol", color="white")
    ax.set_ylabel("imagerow", color="white")
    ax.set_title("Tumor Contour and Inside", color="white")

    # fig.savefig(
    #     os.path.join(out_dir, "tumor_combined_contour_inside.png"),
    #     dpi=300,
    #     facecolor="black",
    #     bbox_inches="tight"
    # )

    if show:
        plt.show()
    else:
        plt.close(fig)

    return g_x_cont, g_y_cont, g_x_inside, g_y_inside


__all__ = ["extract_roi", "contour_regions"]
