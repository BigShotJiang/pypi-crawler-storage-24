use ::causalor::{simulate as rust_simulate, CapabilityMode, VibeSchema};
use pyo3::prelude::*;
use reqwest::blocking::Client;
use serde_json::json;
use std::time::{Duration, SystemTime, UNIX_EPOCH};

const CURRENT_VERSION: &str = env!("CARGO_PKG_VERSION");
const DEFAULT_BASE_URL: &str = "https://api.causalorlabs.com";

#[pyclass]
pub struct CausalorSession {
    schema: VibeSchema,
    api_key: Option<String>,
    base_url: String,
    last_run_ms: u128,
    client: Client,
}

#[pymethods]
impl CausalorSession {
    #[new]
    #[pyo3(signature = (schema_json, api_key=None, base_url=None))]
    fn new(schema_json: &str, api_key: Option<String>, base_url: Option<String>) -> PyResult<Self> {
        let schema: VibeSchema = serde_json::from_str(schema_json).map_err(|e| {
            PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Invalid schema: {}", e))
        })?;

        let client = Client::builder()
            .timeout(Duration::from_millis(3500))
            .build()
            .map_err(|e| {
                PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(format!(
                    "Failed to create HTTP client: {}",
                    e
                ))
            })?;

        Ok(Self {
            schema,
            api_key,
            base_url: base_url.unwrap_or_else(|| DEFAULT_BASE_URL.to_string()),
            last_run_ms: 0,
            client,
        })
    }

    /// Evaluates the current schema by delegating to the cloud API.
    #[pyo3(signature = (budget=None))]
    fn evaluate(&mut self, budget: Option<f64>) -> PyResult<String> {
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_millis();
        self.last_run_ms = now;

        let url = format!("{}/v1/simulate", self.base_url);
        let body = json!({
            "schema": self.schema,
            "budget": budget,
            "capability": "lite"
        });

        let mut request = self
            .client
            .post(&url)
            .header("Content-Type", "application/json")
            .header("X-Causalor-Version", CURRENT_VERSION)
            .json(&body);

        if let Some(key) = &self.api_key {
            request = request.header("X-Causalor-Key", key);
        }

        // Retry logic (2 attempts)
        let mut response = request.send();
        if response.is_err() {
            // Simple retry once
            let mut retry_request = self
                .client
                .post(&url)
                .header("Content-Type", "application/json")
                .header("X-Causalor-Version", CURRENT_VERSION)
                .json(&body);

            if let Some(key) = &self.api_key {
                retry_request = retry_request.header("X-Causalor-Key", key);
            }

            response = retry_request.send();
        }

        let resp = response.map_err(|e| {
            PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(format!("API Request Failed: {}", e))
        })?;

        if !resp.status().is_success() {
            return Err(PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(format!(
                "API Error: Status {}",
                resp.status()
            )));
        }

        let result_text = resp.text().map_err(|e| {
            PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(format!(
                "Failed to read API response: {}",
                e
            ))
        })?;

        Ok(result_text)
    }

    /// Capped local execution (Max 5 vars, 12 horizon). Offline-ready.
    #[pyo3(signature = (budget=None))]
    fn simulate_local(&self, budget: Option<f64>) -> PyResult<String> {
        if self.schema.variables.len() > 5 {
            return Err(PyErr::new::<pyo3::exceptions::PyValueError, _>(
                "Local Mode Violation: Max 5 variables. Use evaluate() for cloud execution.",
            ));
        }
        if self.schema.time.horizon > 12 {
            return Err(PyErr::new::<pyo3::exceptions::PyValueError, _>(
                "Local Mode Violation: Max 12 horizon. Use evaluate() for cloud execution.",
            ));
        }

        let result = rust_simulate(self.schema.clone(), budget, CapabilityMode::Lite);
        serde_json::to_string(&result).map_err(|e| {
            PyErr::new::<pyo3::exceptions::PyRuntimeError, _>(format!(
                "Failed to serialize result: {}",
                e
            ))
        })
    }

    /// Update the underlying schema for the session.
    fn update_schema(&mut self, schema_json: &str) -> PyResult<()> {
        let schema: VibeSchema = serde_json::from_str(schema_json).map_err(|e| {
            PyErr::new::<pyo3::exceptions::PyValueError, _>(format!("Invalid schema: {}", e))
        })?;
        self.schema = schema;
        Ok(())
    }
}

#[pyfunction]
#[pyo3(signature = (schema_json, budget=None, api_key=None, base_url=None))]
fn simulate(
    schema_json: &str,
    budget: Option<f64>,
    api_key: Option<String>,
    base_url: Option<String>,
) -> PyResult<String> {
    let mut session = CausalorSession::new(schema_json, api_key, base_url)?;
    session.evaluate(budget)
}

#[pyfunction]
#[pyo3(signature = (schema_json, budget=None))]
fn simulate_local(schema_json: &str, budget: Option<f64>) -> PyResult<String> {
    let session = CausalorSession::new(schema_json, None, None)?;
    session.simulate_local(budget)
}

#[pymodule]
fn causalor(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(simulate, m)?)?;
    m.add_function(wrap_pyfunction!(simulate_local, m)?)?;
    m.add_class::<CausalorSession>()?;
    Ok(())
}
