"""xproject-creator: Generate Xcode .xcodeproj bundles from scratch."""

from .builder import ProjectBuilder
from .objects import (
    PBXAggregateTarget,
    PBXBuildFile,
    PBXContainerItemProxy,
    PBXCopyFilesBuildPhase,
    PBXFileReference,
    PBXFileSystemSynchronizedRootGroup,
    PBXFrameworksBuildPhase,
    PBXGroup,
    PBXNativeTarget,
    PBXProject,
    PBXResourcesBuildPhase,
    PBXShellScriptBuildPhase,
    PBXSourcesBuildPhase,
    PBXTargetDependency,
    XCBuildConfiguration,
    XCConfigurationList,
)

__all__ = [
    "ProjectBuilder",
    "PBXAggregateTarget",
    "PBXBuildFile",
    "PBXContainerItemProxy",
    "PBXCopyFilesBuildPhase",
    "PBXFileReference",
    "PBXFileSystemSynchronizedRootGroup",
    "PBXFrameworksBuildPhase",
    "PBXGroup",
    "PBXNativeTarget",
    "PBXProject",
    "PBXResourcesBuildPhase",
    "PBXShellScriptBuildPhase",
    "PBXSourcesBuildPhase",
    "PBXTargetDependency",
    "XCBuildConfiguration",
    "XCConfigurationList",
]
