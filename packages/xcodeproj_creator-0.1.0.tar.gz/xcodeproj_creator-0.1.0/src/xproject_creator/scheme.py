"""Minimal .xcscheme XML generator."""

import xml.etree.ElementTree as ET


def generate_scheme(
    *,
    project_name: str,
    target_name: str,
    target_id: str,
    product_name: str,
) -> str:
    """Generate a minimal .xcscheme XML file content.

    Args:
        project_name: Name of the Xcode project (without .xcodeproj).
        target_name: Name of the build target.
        target_id: The 24-char hex object key of the PBXNativeTarget.
        product_name: The product file name (e.g., "MyApp.app").

    """
    scheme = ET.Element(
        "Scheme",
        {
            "LastUpgradeVersion": "1600",
            "version": "1.7",
        },
    )

    # BuildAction
    build_action = ET.SubElement(
        scheme,
        "BuildAction",
        {
            "parallelizeBuildables": "YES",
            "buildImplicitDependencies": "YES",
            "buildArchitectures": "Automatic",
        },
    )
    build_action_entries = ET.SubElement(build_action, "BuildActionEntries")
    entry = ET.SubElement(
        build_action_entries,
        "BuildActionEntry",
        {
            "buildForTesting": "YES",
            "buildForRunning": "YES",
            "buildForProfiling": "YES",
            "buildForArchiving": "YES",
            "buildForAnalyzing": "YES",
        },
    )
    _add_buildable_ref(entry, project_name, target_name, target_id, product_name)

    # TestAction
    ET.SubElement(
        scheme,
        "TestAction",
        {
            "buildConfiguration": "Debug",
            "selectedDebuggerIdentifier": "Xcode.DebuggerFoundation.Debugger.LLDB",
            "selectedLauncherIdentifier": "Xcode.DebuggerFoundation.Launcher.LLDB",
            "shouldUseLaunchSchemeArgsEnv": "YES",
            "shouldAutocreateTestPlan": "YES",
        },
    )

    # LaunchAction
    launch_action = ET.SubElement(
        scheme,
        "LaunchAction",
        {
            "buildConfiguration": "Debug",
            "selectedDebuggerIdentifier": "Xcode.DebuggerFoundation.Debugger.LLDB",
            "selectedLauncherIdentifier": "Xcode.DebuggerFoundation.Launcher.LLDB",
            "launchStyle": "0",
            "useCustomWorkingDirectory": "NO",
            "ignoresPersistentStateOnLaunch": "NO",
            "debugDocumentVersioning": "YES",
            "debugServiceExtension": "internal",
            "allowLocationSimulation": "YES",
        },
    )
    buildable_product = ET.SubElement(
        launch_action,
        "BuildableProductRunnable",
        {
            "runnableDebuggingMode": "0",
        },
    )
    _add_buildable_ref(buildable_product, project_name, target_name, target_id, product_name)

    # ProfileAction
    profile_action = ET.SubElement(
        scheme,
        "ProfileAction",
        {
            "buildConfiguration": "Release",
            "shouldUseLaunchSchemeArgsEnv": "YES",
            "savedToolIdentifier": "",
            "useCustomWorkingDirectory": "NO",
            "debugDocumentVersioning": "YES",
        },
    )
    profile_buildable = ET.SubElement(
        profile_action,
        "BuildableProductRunnable",
        {
            "runnableDebuggingMode": "0",
        },
    )
    _add_buildable_ref(profile_buildable, project_name, target_name, target_id, product_name)

    # AnalyzeAction
    ET.SubElement(
        scheme,
        "AnalyzeAction",
        {
            "buildConfiguration": "Debug",
        },
    )

    # ArchiveAction
    ET.SubElement(
        scheme,
        "ArchiveAction",
        {
            "buildConfiguration": "Release",
            "revealArchiveInOrganizer": "YES",
        },
    )

    ET.indent(scheme, space="   ")
    xml_str = ET.tostring(scheme, encoding="unicode", xml_declaration=True)
    return xml_str + "\n"


def _add_buildable_ref(
    parent: ET.Element,
    project_name: str,
    target_name: str,
    target_id: str,
    product_name: str,
) -> None:
    """Add a BuildableReference element to a parent."""
    ET.SubElement(
        parent,
        "BuildableReference",
        {
            "BuildableIdentifier": "primary",
            "BlueprintIdentifier": target_id,
            "BuildableName": product_name,
            "BlueprintName": target_name,
            "ReferencedContainer": f"container:{project_name}.xcodeproj",
        },
    )
