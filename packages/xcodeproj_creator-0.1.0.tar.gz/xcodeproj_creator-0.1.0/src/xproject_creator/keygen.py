"""Unique 24-character hex object ID generator for pbxproj files."""

import os


class KeyGenerator:
    """Generates unique 24-char uppercase hex IDs (96-bit) for PBX objects."""

    def __init__(self) -> None:
        """Initialize with an empty set of issued keys."""
        self._issued: set[str] = set()

    def generate(self) -> str:
        """Generate a unique 24-char uppercase hex ID."""
        while True:
            key = os.urandom(12).hex().upper()
            if key not in self._issued:
                self._issued.add(key)
                return key
