"""Command-line interface for xcodeproj-creator."""

import argparse
import sys
from pathlib import Path

from .builder import ProjectBuilder


def main(argv: list[str] | None = None) -> None:
    """Entry point for the xcodeproj-create CLI."""
    parser = argparse.ArgumentParser(
        prog="xcodeproj-create",
        description="Generate Xcode .xcodeproj bundles from scratch — no macOS required.",
    )

    parser.add_argument("name", help="Project/target name (e.g., MyApp)")
    parser.add_argument(
        "--bundle-id",
        required=True,
        help="Bundle identifier (e.g., com.example.myapp)",
    )
    parser.add_argument(
        "--output",
        "-o",
        help="Output path (default: <name>.xcodeproj)",
    )
    parser.add_argument(
        "--deployment-target",
        default="18.0",
        help="iOS deployment target (default: 18.0)",
    )
    parser.add_argument(
        "--swift-version",
        default="5.0",
        help="Swift language version (default: 5.0)",
    )
    parser.add_argument(
        "--team-id",
        help="Development team ID for code signing",
    )
    parser.add_argument(
        "--sources",
        nargs="*",
        help="Directories to scan for Swift sources (glob: **/*.swift)",
    )
    parser.add_argument(
        "--resources",
        nargs="*",
        help="Directories to scan for resource files",
    )
    parser.add_argument(
        "--asset-catalogs",
        nargs="*",
        help="Asset catalog paths (.xcassets)",
    )
    parser.add_argument(
        "--product-type",
        default="com.apple.product-type.application",
        help="Product type (default: com.apple.product-type.application)",
    )
    parser.add_argument(
        "--object-version",
        default="56",
        choices=["56", "77"],
        help="pbxproj objectVersion: 56 (classic) or 77 (modern file-sync, Xcode 16+)",
    )

    args = parser.parse_args(argv)

    output_path = args.output or f"{args.name}.xcodeproj"

    builder = ProjectBuilder(
        args.name,
        bundle_id=args.bundle_id,
        product_type=args.product_type,
        deployment_target=args.deployment_target,
        swift_version=args.swift_version,
        object_version=args.object_version,
    )

    if args.team_id:
        builder.set_development_team(args.team_id)

    if args.sources:
        for src_dir in args.sources:
            if not Path(src_dir).is_dir():
                print(f"Warning: source directory not found: {src_dir}", file=sys.stderr)
                continue
            builder.add_swift_sources(src_dir)

    if args.resources:
        for res_dir in args.resources:
            if not Path(res_dir).is_dir():
                print(f"Warning: resource directory not found: {res_dir}", file=sys.stderr)
                continue
            builder.add_resources(res_dir)

    if args.asset_catalogs:
        for catalog in args.asset_catalogs:
            builder.add_asset_catalog(catalog)

    builder.save(output_path)
    print(f"Created {output_path}")


if __name__ == "__main__":
    main()
