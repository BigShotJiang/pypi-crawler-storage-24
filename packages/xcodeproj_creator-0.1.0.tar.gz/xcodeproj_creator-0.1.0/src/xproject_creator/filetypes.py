"""Maps file extensions to Xcode lastKnownFileType / explicitFileType values."""

# Extension -> lastKnownFileType
KNOWN_FILE_TYPES: dict[str, str] = {
    ".swift": "sourcecode.swift",
    ".m": "sourcecode.c.objc",
    ".mm": "sourcecode.cpp.objcpp",
    ".c": "sourcecode.c.c",
    ".cc": "sourcecode.cpp.cpp",
    ".cpp": "sourcecode.cpp.cpp",
    ".h": "sourcecode.c.h",
    ".hpp": "sourcecode.cpp.h",
    ".metal": "sourcecode.metal",
    ".storyboard": "file.storyboard",
    ".xib": "file.xib",
    ".xcassets": "folder.assetcatalog",
    ".plist": "text.plist.xml",
    ".entitlements": "text.plist.entitlements",
    ".json": "text.json",
    ".xml": "text.xml",
    ".strings": "text.plist.strings",
    ".stringsdict": "text.plist.stringsdict",
    ".xcstrings": "text.json.xcstrings",
    ".png": "image.png",
    ".jpg": "image.jpeg",
    ".jpeg": "image.jpeg",
    ".gif": "image.gif",
    ".svg": "image.svg",
    ".pdf": "image.pdf",
    ".mp3": "audio.mp3",
    ".wav": "audio.wav",
    ".mp4": "video.mp4",
    ".mov": "video.quicktime",
    ".ttf": "file",
    ".otf": "file",
    ".xcdatamodeld": "wrapper.xcdatamodel",
    ".xcframework": "wrapper.xcframework",
    ".framework": "wrapper.framework",
    ".a": "archive.ar",
    ".dylib": "compiled.mach-o.dylib",
    ".tbd": "sourcecode.text-based-dylib-definition",
    ".js": "sourcecode.javascript",
    ".css": "text.css",
    ".html": "text.html",
    ".txt": "text",
    ".md": "net.daringfireball.markdown",
    ".sh": "text.script.sh",
    ".py": "text.script.python",
    ".rb": "text.script.ruby",
    ".yml": "text.yaml",
    ".yaml": "text.yaml",
}

# Product type -> explicitFileType
PRODUCT_FILE_TYPES: dict[str, str] = {
    "com.apple.product-type.application": "wrapper.application",
    "com.apple.product-type.bundle": "wrapper.cfbundle",
    "com.apple.product-type.bundle.unit-test": "wrapper.cfbundle",
    "com.apple.product-type.bundle.ui-testing": "wrapper.cfbundle",
    "com.apple.product-type.framework": "wrapper.framework",
    "com.apple.product-type.framework.static": "wrapper.framework.static",
    "com.apple.product-type.library.static": "archive.ar",
    "com.apple.product-type.app-extension": "wrapper.app-extension",
    "com.apple.product-type.application.watchapp2": "wrapper.application",
    "com.apple.product-type.watchkit2-extension": "wrapper.app-extension",
}

# Product type -> file extension for the built product
PRODUCT_EXTENSIONS: dict[str, str] = {
    "com.apple.product-type.application": ".app",
    "com.apple.product-type.bundle": ".bundle",
    "com.apple.product-type.bundle.unit-test": ".xctest",
    "com.apple.product-type.bundle.ui-testing": ".xctest",
    "com.apple.product-type.framework": ".framework",
    "com.apple.product-type.framework.static": ".framework",
    "com.apple.product-type.library.static": ".a",
    "com.apple.product-type.app-extension": ".appex",
}

# Extensions that are source files (compiled)
SOURCE_EXTENSIONS: set[str] = {".swift", ".m", ".mm", ".c", ".cc", ".cpp", ".metal"}

# Extensions that are resource files (copied to bundle)
RESOURCE_EXTENSIONS: set[str] = {
    ".storyboard",
    ".xib",
    ".xcassets",
    ".plist",
    ".json",
    ".xml",
    ".strings",
    ".stringsdict",
    ".xcstrings",
    ".png",
    ".jpg",
    ".jpeg",
    ".gif",
    ".svg",
    ".pdf",
    ".mp3",
    ".wav",
    ".mp4",
    ".mov",
    ".ttf",
    ".otf",
    ".html",
    ".css",
    ".js",
    ".txt",
    ".md",
    ".yml",
    ".yaml",
}


def file_type_for_extension(ext: str) -> str:
    """Return the lastKnownFileType for a file extension (including the dot)."""
    return KNOWN_FILE_TYPES.get(ext, "file")


def is_source_file(path: str) -> bool:
    """Check if a file path is a compilable source file."""
    from pathlib import Path

    return Path(path).suffix in SOURCE_EXTENSIONS


def is_resource_file(path: str) -> bool:
    """Check if a file path is a resource file."""
    from pathlib import Path

    return Path(path).suffix in RESOURCE_EXTENSIONS
