"""Tests for the CLI interface."""

import os
import tempfile

from xproject_creator.cli import main


def test_cli_minimal():
    """Test CLI with minimal required arguments."""
    with tempfile.TemporaryDirectory() as tmpdir:
        output = os.path.join(tmpdir, "Test.xcodeproj")
        main(["Test", "--bundle-id", "com.test.app", "-o", output])

        assert os.path.exists(os.path.join(output, "project.pbxproj"))
        assert os.path.exists(os.path.join(output, "xcshareddata", "xcschemes", "Test.xcscheme"))


def test_cli_default_output():
    """Test CLI uses <name>.xcodeproj as default output."""
    with tempfile.TemporaryDirectory() as tmpdir:
        orig_dir = os.getcwd()
        try:
            os.chdir(tmpdir)
            main(["MyApp", "--bundle-id", "com.test.myapp"])
            assert os.path.exists(os.path.join(tmpdir, "MyApp.xcodeproj", "project.pbxproj"))
        finally:
            os.chdir(orig_dir)


def test_cli_with_sources():
    """Test CLI with --sources flag."""
    with tempfile.TemporaryDirectory() as tmpdir:
        src_dir = os.path.join(tmpdir, "MyApp")
        os.makedirs(src_dir)
        with open(os.path.join(src_dir, "App.swift"), "w") as f:
            f.write("import SwiftUI\n")

        output = os.path.join(tmpdir, "MyApp.xcodeproj")
        main(["MyApp", "--bundle-id", "com.test.app", "-o", output, "--sources", src_dir])

        with open(os.path.join(output, "project.pbxproj")) as f:
            content = f.read()
        assert "App.swift" in content


def test_cli_with_resources():
    """Test CLI with --resources flag."""
    with tempfile.TemporaryDirectory() as tmpdir:
        res_dir = os.path.join(tmpdir, "Resources")
        os.makedirs(res_dir)
        with open(os.path.join(res_dir, "data.json"), "w") as f:
            f.write("{}")

        output = os.path.join(tmpdir, "MyApp.xcodeproj")
        main(["MyApp", "--bundle-id", "com.test.app", "-o", output, "--resources", res_dir])

        with open(os.path.join(output, "project.pbxproj")) as f:
            content = f.read()
        assert "data.json" in content


def test_cli_with_asset_catalogs():
    """Test CLI with --asset-catalogs flag."""
    with tempfile.TemporaryDirectory() as tmpdir:
        output = os.path.join(tmpdir, "MyApp.xcodeproj")
        main(
            [
                "MyApp",
                "--bundle-id",
                "com.test.app",
                "-o",
                output,
                "--asset-catalogs",
                "MyApp/Assets.xcassets",
            ]
        )

        with open(os.path.join(output, "project.pbxproj")) as f:
            content = f.read()
        assert "Assets.xcassets" in content


def test_cli_all_options():
    """Test CLI with all options set."""
    with tempfile.TemporaryDirectory() as tmpdir:
        output = os.path.join(tmpdir, "MyApp.xcodeproj")
        main(
            [
                "MyApp",
                "--bundle-id",
                "com.example.myapp",
                "-o",
                output,
                "--deployment-target",
                "18.0",
                "--swift-version",
                "6.0",
                "--team-id",
                "ABCDEF1234",
            ]
        )

        with open(os.path.join(output, "project.pbxproj")) as f:
            content = f.read()
        assert "com.example.myapp" in content
        assert "ABCDEF1234" in content
        assert "18.0" in content


def test_cli_missing_source_dir(capsys: object):
    """Test CLI warns about missing source directories."""
    with tempfile.TemporaryDirectory() as tmpdir:
        output = os.path.join(tmpdir, "MyApp.xcodeproj")
        main(
            [
                "MyApp",
                "--bundle-id",
                "com.test.app",
                "-o",
                output,
                "--sources",
                "/nonexistent/path",
            ]
        )
        # Should still create the project
        assert os.path.exists(os.path.join(output, "project.pbxproj"))


def test_cli_missing_resource_dir(capsys: object):
    """Test CLI warns about missing resource directories."""
    with tempfile.TemporaryDirectory() as tmpdir:
        output = os.path.join(tmpdir, "MyApp.xcodeproj")
        main(
            [
                "MyApp",
                "--bundle-id",
                "com.test.app",
                "-o",
                output,
                "--resources",
                "/nonexistent/path",
            ]
        )
        assert os.path.exists(os.path.join(output, "project.pbxproj"))


def test_cli_object_version_77():
    """Test CLI with --object-version 77."""
    with tempfile.TemporaryDirectory() as tmpdir:
        output = os.path.join(tmpdir, "MyApp.xcodeproj")
        main(
            [
                "MyApp",
                "--bundle-id",
                "com.test.app",
                "-o",
                output,
                "--object-version",
                "77",
            ]
        )

        with open(os.path.join(output, "project.pbxproj")) as f:
            content = f.read()
        assert "objectVersion = 77;" in content
        assert "PBXFileSystemSynchronizedRootGroup" in content
