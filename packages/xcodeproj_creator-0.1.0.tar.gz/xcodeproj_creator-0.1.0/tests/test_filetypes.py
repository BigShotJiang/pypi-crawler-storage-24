from xproject_creator.filetypes import file_type_for_extension, is_resource_file, is_source_file


def test_known_extensions():
    assert file_type_for_extension(".swift") == "sourcecode.swift"
    assert file_type_for_extension(".m") == "sourcecode.c.objc"
    assert file_type_for_extension(".xcassets") == "folder.assetcatalog"
    assert file_type_for_extension(".plist") == "text.plist.xml"
    assert file_type_for_extension(".json") == "text.json"
    assert file_type_for_extension(".png") == "image.png"
    assert file_type_for_extension(".storyboard") == "file.storyboard"


def test_unknown_extension():
    assert file_type_for_extension(".xyz") == "file"


def test_is_source_file():
    assert is_source_file("MyApp/main.swift")
    assert is_source_file("foo.m")
    assert is_source_file("bar.c")
    assert is_source_file("baz.metal")
    assert not is_source_file("image.png")
    assert not is_source_file("data.json")


def test_is_resource_file():
    assert is_resource_file("Assets.xcassets")
    assert is_resource_file("image.png")
    assert is_resource_file("data.json")
    assert is_resource_file("Main.storyboard")
    assert not is_resource_file("main.swift")
    assert not is_resource_file("code.c")
