from xproject_creator.keygen import KeyGenerator


def test_generates_24_char_hex():
    gen = KeyGenerator()
    key = gen.generate()
    assert len(key) == 24
    assert all(c in "0123456789ABCDEF" for c in key)


def test_generates_unique_keys():
    gen = KeyGenerator()
    keys = {gen.generate() for _ in range(1000)}
    assert len(keys) == 1000
