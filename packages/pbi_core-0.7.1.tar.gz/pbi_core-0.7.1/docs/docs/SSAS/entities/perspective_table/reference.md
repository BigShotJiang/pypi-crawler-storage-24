# Reference


:::pbi_core.ssas.model_tables.perspective_table.PerspectiveTable