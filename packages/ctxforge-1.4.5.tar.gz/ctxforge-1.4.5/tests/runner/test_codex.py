"""Tests for CodexRunner."""

from unittest.mock import MagicMock, patch

import pytest

from ctxforge.exceptions import RunnerError
from ctxforge.runner.codex import CodexRunner


class TestCodexRunner:
    def test_run_success(self):
        runner = CodexRunner()
        mock_result = MagicMock()
        mock_result.returncode = 0

        with patch("ctxforge.runner.codex.subprocess.run", return_value=mock_result) as mock_run:
            result = runner.run("system context")
            mock_run.assert_called_once_with(
                ["codex", "system context"],
            )
        assert result.ok
        assert result.stdout == ""
        assert result.stderr == ""

    def test_run_with_initial_prompt(self):
        runner = CodexRunner()
        mock_result = MagicMock()
        mock_result.returncode = 0

        with patch("ctxforge.runner.codex.subprocess.run", return_value=mock_result) as mock_run:
            result = runner.run("system context", "hello")
            mock_run.assert_called_once_with(
                ["codex", "system context\n\nhello"],
            )
        assert result.ok

    def test_run_auto_approve(self):
        runner = CodexRunner()
        mock_result = MagicMock()
        mock_result.returncode = 0

        with patch("ctxforge.runner.codex.subprocess.run", return_value=mock_result) as mock_run:
            result = runner.run("system context", auto_approve=True)
            mock_run.assert_called_once_with(
                ["codex", "--dangerously-bypass-approvals-and-sandbox", "system context"],
            )
        assert result.ok

    def test_run_empty_system_prompt(self):
        runner = CodexRunner()
        mock_result = MagicMock()
        mock_result.returncode = 0

        with patch("ctxforge.runner.codex.subprocess.run", return_value=mock_result) as mock_run:
            result = runner.run("")
            mock_run.assert_called_once_with(["codex"])
        assert result.ok

    def test_run_resume_session(self):
        runner = CodexRunner()
        mock_result = MagicMock()
        mock_result.returncode = 0

        with patch("ctxforge.runner.codex.subprocess.run", return_value=mock_result) as mock_run:
            result = runner.run("system context", "hello", resume_id="abc-123")
            mock_run.assert_called_once_with(
                ["codex", "resume", "abc-123", "hello"],
            )
        assert result.ok

    def test_run_discovers_session_id(self):
        runner = CodexRunner()
        mock_result = MagicMock()
        mock_result.returncode = 0

        with (
            patch("ctxforge.runner.codex.subprocess.run", return_value=mock_result),
            patch.object(runner, "_find_latest_session_id", return_value="sid-123") as mock_find,
        ):
            result = runner.run("system context")
        mock_find.assert_called_once()
        assert result.session_id == "sid-123"

    def test_run_resume_does_not_discover_session_id(self):
        runner = CodexRunner()
        mock_result = MagicMock()
        mock_result.returncode = 0

        with (
            patch("ctxforge.runner.codex.subprocess.run", return_value=mock_result),
            patch.object(runner, "_find_latest_session_id") as mock_find,
        ):
            result = runner.run("system context", resume_id="abc-123")
        mock_find.assert_not_called()
        assert result.session_id is None

    def test_run_failure(self):
        runner = CodexRunner()
        mock_result = MagicMock()
        mock_result.returncode = 1

        with patch("ctxforge.runner.codex.subprocess.run", return_value=mock_result):
            result = runner.run("system context")
        assert not result.ok
        assert result.exit_code == 1

    def test_run_not_found(self):
        runner = CodexRunner()
        with patch("ctxforge.runner.codex.subprocess.run", side_effect=FileNotFoundError):
            with pytest.raises(RunnerError, match="not found"):
                runner.run("test")

    def test_run_oneshot_success(self):
        runner = CodexRunner()
        mock_result = MagicMock()
        mock_result.returncode = 0

        with patch("ctxforge.runner.codex.subprocess.run", return_value=mock_result) as mock_run:
            result = runner.run_oneshot("compress key files")
            mock_run.assert_called_once_with(
                ["codex", "compress key files"],
            )
        assert result.ok

    def test_run_oneshot_auto_approve(self):
        runner = CodexRunner()
        mock_result = MagicMock()
        mock_result.returncode = 0

        with patch("ctxforge.runner.codex.subprocess.run", return_value=mock_result) as mock_run:
            result = runner.run_oneshot("compress key files", auto_approve=True)
            mock_run.assert_called_once_with(
                ["codex", "--dangerously-bypass-approvals-and-sandbox", "compress key files"],
            )
        assert result.ok

    def test_run_oneshot_not_found(self):
        runner = CodexRunner()
        with patch("ctxforge.runner.codex.subprocess.run", side_effect=FileNotFoundError):
            with pytest.raises(RunnerError, match="not found"):
                runner.run_oneshot("test")

    def test_name(self):
        assert CodexRunner.name == "codex"
