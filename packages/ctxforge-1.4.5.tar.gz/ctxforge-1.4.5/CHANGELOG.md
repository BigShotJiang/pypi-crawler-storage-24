# Changelog

All notable changes to this project will be documented in this file.

## [1.4.5] - 2026-03-21

### Fixed

- Fixed `ctxforge run` for Codex so choosing continue now resumes the real previous Codex session instead of starting a new one.
- Updated Codex session persistence to store the actual Codex session ID discovered after launch, rather than a synthetic UUID.

## [1.4.4] - 2026-03-19

### Fixed

- Updated `CodexRunner` to use Codex CLI's current auto-approve flag: `--dangerously-bypass-approvals-and-sandbox`.
- Updated Codex runner tests to match the new CLI flag.

## [1.4.3] - 2026-03-19

### Changed

- Bumped package version to `1.4.3` for the Codex runner compatibility release.

## [1.4.2] - 2026-03-19

### Added

- Added `usermemo.md` support with schema v6 migration.
- Added scope-restricted `ctx` commands.
