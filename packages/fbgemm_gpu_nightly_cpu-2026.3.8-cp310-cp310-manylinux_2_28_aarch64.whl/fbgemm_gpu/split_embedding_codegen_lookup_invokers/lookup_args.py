################################################################################
## GENERATED FILE INFO
##
## Template Source: training/python/lookup_args.template
################################################################################

__template_source_file__ = "training/python/lookup_args.template"

#!/usr/bin/env python3
# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.
#
# This source code is licensed under the BSD-style license found in the
# LICENSE file in the root directory of this source tree.

# pyre-strict

from typing import NamedTuple, Optional, Dict, List

import torch


class VBEMetadata(NamedTuple):
    B_offsets: Optional[torch.Tensor]
    output_offsets_feature_rank: Optional[torch.Tensor]
    B_offsets_rank_per_feature: Optional[torch.Tensor]
    max_B_feature_rank: int = -1
    max_B: int = -1
    output_size: int = -1
    vbe_output: Optional[torch.Tensor] = None
    vbe_output_offsets: Optional[torch.Tensor] = None


class CommonArgs(NamedTuple):
    placeholder_autograd_tensor: torch.Tensor
    dev_weights: torch.Tensor
    host_weights: torch.Tensor
    uvm_weights: torch.Tensor
    lxu_cache_weights: torch.Tensor
    weights_placements: torch.Tensor
    weights_offsets: torch.Tensor
    D_offsets: torch.Tensor
    total_D: int
    max_D: int
    hash_size_cumsum: torch.Tensor
    total_hash_size_bits: int
    indices: torch.Tensor
    offsets: torch.Tensor
    pooling_mode: int
    indice_weights: Optional[torch.Tensor]
    feature_requires_grad: Optional[torch.Tensor]
    lxu_cache_locations: torch.Tensor
    uvm_cache_stats: Optional[torch.Tensor]
    output_dtype: int
    vbe_metadata: VBEMetadata
    is_experimental: bool
    use_uniq_cache_locations_bwd: bool
    use_homogeneous_placements: bool
    learning_rate_tensor: torch.Tensor
    info_B_num_bits: int
    info_B_mask: int


# Do not add a parameter of Type tensor here. It will cause JIT script error due to a bug in PyTorch.
# See more detail in D71010630.
class OptimizerArgs(NamedTuple):
    stochastic_rounding: bool
    gradient_clipping: bool
    max_gradient: float
    max_norm: float
    eps: float
    beta1: float
    beta2: float
    weight_decay: float
    weight_decay_mode: int
    eta: float
    momentum: float
    counter_halflife: int
    adjustment_iter: int
    adjustment_ub: float
    learning_rate_mode: int
    grad_sum_decay: int
    tail_id_threshold: float
    is_tail_id_thresh_ratio: int
    total_hash_size: int  # Required for OptimType.NONE
    weight_norm_coefficient: float
    lower_bound: float
    regularization_mode: int
    use_rowwise_bias_correction: bool # Used for OptimType.ADAM


class Momentum(NamedTuple):
    dev: torch.Tensor
    host: torch.Tensor
    uvm: torch.Tensor
    offsets: torch.Tensor
    placements: torch.Tensor