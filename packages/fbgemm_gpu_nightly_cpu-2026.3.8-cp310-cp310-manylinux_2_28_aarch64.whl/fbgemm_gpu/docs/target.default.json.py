
{
    "version": "2026.3.8",
    "target": "default",
    "variant": "cpu"
}
