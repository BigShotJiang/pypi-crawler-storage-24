# dr-eamer-ai-shared is deprecated

This package has been replaced by [geepers-kernel](https://pypi.org/project/geepers-kernel/).

```bash
pip install geepers-kernel
```
