import warnings
warnings.warn(
    "dr-eamer-ai-shared is deprecated. Install geepers-kernel instead: pip install geepers-kernel",
    DeprecationWarning,
    stacklevel=2,
)
