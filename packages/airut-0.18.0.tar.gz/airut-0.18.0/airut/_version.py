"""Auto-generated at build time — do not edit."""

VERSION = 'v0.18.0'
GIT_SHA_SHORT = 'eee7a21'
GIT_SHA_FULL = 'eee7a21d122ea1e69fad8969e963ba993bdaac8d'
