import os
import environ
from datetime import datetime
from pathlib import Path

from pynop.core.db import AutoDao
from pynop.core.staging.staging_sql import StagingQuery

print ("============================== Sync Settings ==============================")

env = environ.Env()

BASE_DIR = Path(__file__).parent.parent.parent
environ.Env.read_env(os.path.join(BASE_DIR, '.env'))

staging_dao = AutoDao("staging")
settings_list = staging_dao.get_hashmap(StagingQuery.GET_SYNC_SETTINGS_SQL)

def get_setting_str(key, is_int=False, is_bool=False):
    if settings_list.get(key):
        value = str(settings_list[key])
    else:
        value = env(key)
    if is_int:
        value = int(value)
    if is_bool:
        value = (value == 'True' or value == 'true' or value == '1')

    print(f"{key} : {value}")
    return value

def get_setting_int(key):
    return get_setting_str(key, is_int=True)

def get_setting_bool(key):
    return get_setting_str(key, is_bool=True)

is_test = get_setting_bool('IS_TEST')


# Option Flag
SKIP_OLD_MATTRESS_IMPORT = get_setting_bool('SKIP_OLD_MATTRESS_IMPORT')
SECOND_DATA_OPTION = get_setting_str('SECOND_DATA_OPTION')

# Log
APP_STARTED_TIME = datetime.now()
LOG_LEVEL_OPTION = get_setting_str('LOG_LEVEL_OPTION')
LOG_MAX_RETENTION_DAYS = get_setting_int('LOG_MAX_RETENTION_DAYS')

# Directory Path
## Nop Webapp Path
APP_PATH = get_setting_str('APP_PATH')
LOG_DIR_PATH = os.path.join(BASE_DIR, get_setting_str('LOG_DIR_PATH'))

## ERP Contents Path \\192.168.253.201\
WWWROOT_PATH = get_setting_str('WWWROOT_PATH')
SERVER_APP_PATH = get_setting_str('SERVER_APP_PATH')
WWWROOT_PROMOTION_FORMS_DIR = os.path.join(os.path.join(SERVER_APP_PATH , WWWROOT_PATH), get_setting_str('WWWROOT_PROMOTION_FORMS_DIR'))
WWWROOT_PRODUCT_IMAGES_DIR = os.path.join(os.path.join(SERVER_APP_PATH, WWWROOT_PATH), get_setting_str('WWWROOT_PRODUCT_IMAGES_DIR'))
WWWROOT_PROMO_PRODUCT_SQUARE_DIR = os.path.join(os.path.join(SERVER_APP_PATH, WWWROOT_PATH), get_setting_str('WWWROOT_PROMO_PRODUCT_SQUARE_DIR'))
WWWROOT_ENERGY_GUIDES_DIR = os.path.join(os.path.join(SERVER_APP_PATH, WWWROOT_PATH), get_setting_str('WWWROOT_ENERGY_GUIDES_DIR'))
WWWROOT_PRODUCT_SPECS_DIR = os.path.join(os.path.join(SERVER_APP_PATH, WWWROOT_PATH), get_setting_str('WWWROOT_PRODUCT_SPECS_DIR'))

## Sync /contents/product_images/ Path
SYNC_CONTENTS_DIR=os.path.join(BASE_DIR, get_setting_str('SYNC_CONTENTS_DIR'))
SYNC_IMAGE_DIR = os.path.join(SYNC_CONTENTS_DIR, get_setting_str('SYNC_IMAGE_DIR'))

ERP_IMAGE_DIR = os.path.join(SYNC_IMAGE_DIR, 'erp')
if not os.path.exists(ERP_IMAGE_DIR):
    # Create the directory
    os.makedirs(ERP_IMAGE_DIR)
DELETED_ERP_IMAGE_DIR = os.path.join(ERP_IMAGE_DIR, 'deleted')
if not os.path.exists(DELETED_ERP_IMAGE_DIR):
    # Create the deleted sub directory in the folder
    os.makedirs(DELETED_ERP_IMAGE_DIR)

PROMO_IMAGE_DIR = os.path.join(SYNC_IMAGE_DIR, 'promo')
if not os.path.exists(PROMO_IMAGE_DIR):
    # Create the directory
    os.makedirs(PROMO_IMAGE_DIR)
DELETED_PROMO_IMAGE_DIR = os.path.join(PROMO_IMAGE_DIR, 'deleted')
if not os.path.exists(DELETED_PROMO_IMAGE_DIR):
    # Create the deleted sub directory in the folder
    os.makedirs(DELETED_PROMO_IMAGE_DIR)

RWS_IMAGE_DIR = os.path.join(SYNC_IMAGE_DIR, 'rws')
if not os.path.exists(RWS_IMAGE_DIR):
    # Create the directory
    os.makedirs(RWS_IMAGE_DIR)
DELETED_RWS_IMAGE_DIR = os.path.join(RWS_IMAGE_DIR, 'deleted')
if not os.path.exists(DELETED_RWS_IMAGE_DIR):
    # Create the deleted sub directory in the folder
    os.makedirs(DELETED_RWS_IMAGE_DIR)

STG_IMAGE_DIR = os.path.join(SYNC_IMAGE_DIR, 'stage')
if not os.path.exists(STG_IMAGE_DIR):
    # Create the directory
    os.makedirs(STG_IMAGE_DIR)

UNSTG_IMAGE_DIR = os.path.join(SYNC_IMAGE_DIR, 'unstage')
if not os.path.exists(UNSTG_IMAGE_DIR):
    # Create the directory
    os.makedirs(UNSTG_IMAGE_DIR)

STANDARD_SECOND_PROMO_IMAGE = 'promo_WeBeatAllDeals_PDP-1'
STANDARD_SECOND_PROMO_IMAGE_DIR = 'images/'


# RWS Content Settings
RWS_XSD = get_setting_str("RWS_XSD")
RWS_FEED_URL = get_setting_str("RWS_FEED_URL")
RWS_PATH = get_setting_str("RWS_PATH")
if is_test:
    RWS_PATH = os.path.join(RWS_PATH, "test")
RWS_ZIP_FILE_NAME = get_setting_str("RWS_ZIP_FILE_NAME")
RWS_XML_FILE_NAME = get_setting_str("RWS_XML_FILE_NAME")
RWS_XML_SAMPE_FILE_NAME = get_setting_str("RWS_XML_SAMPE_FILE_NAME")

RWS_IMG_URL = get_setting_str("RWS_IMG_URL")
RWS_IMG_DIR_NAME = get_setting_str("RWS_IMG_DIR_NAME")
RWS_THUMB_DIR_NAME = get_setting_str("RWS_THUMB_DIR_NAME")
RWS_PICTURE_MAX_IMPORT_NUMBER = get_setting_int("RWS_PICTURE_MAX_IMPORT_NUMBER")

RWS_SYNC_THUMB_FOLDER = os.path.join(RWS_IMAGE_DIR, RWS_THUMB_DIR_NAME)
if not os.path.exists(RWS_SYNC_THUMB_FOLDER):
    # Create the directory
    os.makedirs(RWS_SYNC_THUMB_FOLDER)


# Notificaton Channel URL
TEAMS_WEBHOOK_URL = get_setting_str("TEAMS_WEBHOOK_URL")

SKYPE_USERNAME = get_setting_str("SKYPE_USERNAME")
SKYPE_PASSWORD = get_setting_str("SKYPE_PASSWORD")
SKYPE_CHANNEL_ID = get_setting_str("SKYPE_CHANNEL_ID")

EMAIL_SERVER_ADDR = get_setting_str("EMAIL_SERVER_ADDR")
EMAIL_SERVER_PORT = get_setting_int("EMAIL_SERVER_PORT")
SENDER_EMAIL = get_setting_str("SENDER_EMAIL")
RECEIVER_EMAIL = get_setting_str("RECEIVER_EMAIL")

SLACK_BOT_TOKEN = get_setting_str("SLACK_BOT_TOKEN")
SLACK_CHANNEL_ID = get_setting_str("SLACK_CHANNEL_ID")

print ("============================== Sync Settings ==============================")
