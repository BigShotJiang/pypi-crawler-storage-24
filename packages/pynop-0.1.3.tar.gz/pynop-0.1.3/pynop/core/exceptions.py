class BizError(Exception):
    pass

