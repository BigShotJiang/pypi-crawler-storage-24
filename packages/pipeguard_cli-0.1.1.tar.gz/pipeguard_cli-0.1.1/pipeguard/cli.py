"""Entry point: pipeguard scan"""

from __future__ import annotations

import sys
from pathlib import Path

import click

from pipeguard import __version__
from pipeguard.config import PipeGuardConfig, load_config
from pipeguard.output.formatter import Formatter, OutputFormat
from pipeguard.scanner.base import Finding
from pipeguard.scanner.github_actions.action_inventory import check_action_inventory
from pipeguard.scanner.github_actions.actionlint_runner import run_actionlint
from pipeguard.scanner.github_actions.cve_check import check_cve
from pipeguard.scanner.github_actions.permissions import check_permissions
from pipeguard.scanner.github_actions.pull_request_target import check_pull_request_target
from pipeguard.scanner.github_actions.secrets_flow import check_secrets_flow
from pipeguard.scanner.github_actions.sha_pinning import check_sha_pinning
from pipeguard.scanner.github_actions.supply_chain import check_supply_chain

_WORKFLOW_GLOB = ("*.yml", "*.yaml")


def _collect_workflows(path: str) -> list[Path]:
    """Return workflow files from a file path or directory."""
    p = Path(path)
    if p.is_file():
        return [p]
    files: list[Path] = []
    for pattern in _WORKFLOW_GLOB:
        files.extend(sorted(p.rglob(pattern)))
    return files


def _scan_file(workflow: Path, config: PipeGuardConfig | None = None) -> list[Finding]:
    findings: list[Finding] = []
    findings += run_actionlint(str(workflow))
    findings += check_sha_pinning(str(workflow))
    findings += check_secrets_flow(str(workflow))
    findings += check_supply_chain(str(workflow), config)
    findings += check_permissions(str(workflow))
    findings += check_pull_request_target(str(workflow))
    findings += check_cve(str(workflow))
    findings += check_action_inventory(str(workflow))
    return findings


@click.group()
@click.version_option(__version__, prog_name="pipeguard")
def main() -> None:
    """PipeGuard — catch GitHub Actions security issues before they reach your runners."""


@main.command()
@click.argument("path", default=".github/workflows", type=click.Path(exists=True))
@click.option(
    "--format",
    "output_format",
    type=click.Choice(["terminal", "json", "sarif"]),
    default="terminal",
    show_default=True,
    help="Output format.",
)
@click.option("--fix", is_flag=True, help="Generate auto-fix suggestions.")
@click.option(
    "--config",
    "config_path",
    type=click.Path(exists=True, dir_okay=False),
    default=None,
    help="Path to a pipeguard config file (default: auto-detect .pipeguard.yml).",
)
def scan(path: str, output_format: str, fix: bool, config_path: str | None) -> None:
    """Scan a workflow FILE or DIRECTORY (default: .github/workflows)."""
    config = load_config(Path(config_path).parent if config_path else None)
    workflows = _collect_workflows(path)

    if not workflows:
        click.echo(f"[pipeguard] No workflow files found in '{path}'.", err=True)
        sys.exit(0)

    fmt = Formatter(OutputFormat(output_format))
    all_findings: list[Finding] = []

    for workflow in workflows:
        findings = _scan_file(workflow, config)
        all_findings.extend(findings)
        fmt.render(findings, str(workflow))

    if len(workflows) > 1:
        errors = sum(1 for f in all_findings if f.severity == "error")
        warnings = sum(1 for f in all_findings if f.severity == "warning")
        infos = sum(1 for f in all_findings if f.severity == "info")
        click.echo(
            f"\nScanned {len(workflows)} file(s) — "
            f"{errors} error(s), {warnings} warning(s), {infos} info(s) total."
        )

    if any(f.severity in ("error", "warning") for f in all_findings):
        sys.exit(1)
