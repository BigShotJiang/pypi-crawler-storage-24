"""Secret provider implementations."""
