import os
import glob
import shutil
from ase.io import read
from dcg_sci_tool import (
    get_local_minima_sides_of_peak, 
    traj2iniData, 
    atoms2lmps_resultData, 
    mpirun_lammps, 
    neb_get_traj, 
    plot_neb_graph
)


def auto_neb_refine(max_round_num = 3):
    """
    自动NEB优化：如果初次neb优化结果中出现中间态，则自动以中间态为初末态，重新优化NEB
    直至neb优化出的能量-坐标图为单峰，最多执行max_round_num轮

    Args:
        max_round_num (int): 循环迭代的最大轮数，默认值为3

    """
    
    # 初始化
    original_cwd = os.getcwd()
    last_round_cwd = os.getcwd()
    found_local_minima, left_idx, right_idx = get_local_minima_sides_of_peak(
        mep_data_file="neb_mep.dat", 
        neb_traj_file="result.xyz"
    )
    
    for round_num in range(1, max_round_num + 1):
        if not found_local_minima:
            break
            
        # 1. 创建并进入本轮工作目录
        target_dir = os.path.join(original_cwd, f"mid{round_num}_{left_idx}-{right_idx}")
        os.makedirs(target_dir, exist_ok=True)
        
        # 2. 移动中间体结构文件
        for suffix in ["IS", "FS"]:
            src_file = os.path.join(last_round_cwd, f"mid_{suffix}.xyz")
            if os.path.exists(src_file):
                shutil.move(src_file, target_dir)
            else:
                print(f"警告: 未找到 {src_file}")
        
        # 3. 复制配置文件
        config_files = ['in.lammps_neb', 'nep.txt']
        for file in config_files:
            for src in glob.glob(file):
                if os.path.isfile(src):
                    shutil.copy(src, target_dir)
        
        # 4. 切换目录并执行计算
        os.chdir(target_dir)
        
        # 5. 生成LAMMPS输入数据
        traj2iniData(
            traj_file="mid_IS.xyz",
            specorder=['C', 'O', 'Pd', 'Au'],
            start_frame=0,
            end_frame=0
        )
        os.rename('0.data', 'IS.data')
        
        FS_atoms = read("mid_FS.xyz", index=0)
        atoms2lmps_resultData(atoms=FS_atoms, output_file="FS.data")
        
        # 6. 执行LAMMPS计算
        print(f"第{round_num}轮: 开始LAMMPS NEB计算")
        mpirun_lammps(input_file="in.lammps_neb", partition="40x1")
        
        # 7. 后处理
        neb_get_traj()
        plot_neb_graph(src_file='neb_mep.dat', output_file="neb_graph.png")
        
        # 8. 检查是否继续
        if round_num == max_round_num:
            print(f"达到最大轮数 {max_round_num}，停止")
            break
        
        # 9. 分析结果，准备下一轮
        last_round_cwd = os.getcwd()
        found_local_minima, left_idx, right_idx = get_local_minima_sides_of_peak(
            mep_data_file="neb_mep.dat", 
            neb_traj_file="result.xyz"
        )
        
        # 返回原始目录
        os.chdir(original_cwd)
    
    print("NEB细化完成")
    os.chdir(original_cwd)