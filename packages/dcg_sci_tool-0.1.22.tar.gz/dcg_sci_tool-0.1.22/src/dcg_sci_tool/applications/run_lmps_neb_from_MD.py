
import glob
import shutil
from dcg_sci_tool import *

xyz_files = glob.glob("CO2_formation_frame*.xyz")
if xyz_files:
    shutil.move(xyz_files[0], "reaction.xyz")
    print(f"已移动 {xyz_files[0]} -> reaction.xyz")
else:
    print("未找到 .xyz 文件")
c_idx, o_idx = get_target_atoms_from_MD("reaction.xyz")