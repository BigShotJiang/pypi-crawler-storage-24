"""Maverick MCP Server — behavioral intelligence for AI agents.

Exposes four tools via MCP:
  - maverick_assess: Run the behavioral assessment
  - maverick_profile: Get current user's profile
  - maverick_adapt: Get adaptation instructions for current context
  - maverick_feedback: Record feedback to refine profile

Every Goose needs its Maverick.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

import yaml
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import TextContent, Tool

from .assessment import QUESTIONS, score_assessment
from .card import generate_card
from .profiles import PROFILES, Drives, Profile, get_profile, match_profile

logger = logging.getLogger(__name__)

# ── MCP Server Instance ───────────────────────────────────────────────────────

mcp_server = Server("maverick")

# ── Local storage ────────────────────────────────────────────────────────────

MAVERICK_DIR = Path.home() / ".maverick"
PROFILE_PATH = MAVERICK_DIR / "profile.yaml"
INTERACTIONS_PATH = MAVERICK_DIR / "interactions.jsonl"
CONFIG_PATH = MAVERICK_DIR / "config.yaml"


def _ensure_dir() -> None:
    MAVERICK_DIR.mkdir(parents=True, exist_ok=True)


def _load_profile() -> dict[str, Any] | None:
    """Load saved profile from disk."""
    if not PROFILE_PATH.exists():
        return None
    with open(PROFILE_PATH) as f:
        return yaml.safe_load(f)


def _save_profile(profile: Profile, drives: Drives) -> None:
    """Save profile to local disk. Your data stays on YOUR machine."""
    _ensure_dir()
    data = {
        "profile_id": profile.id,
        "profile_name": profile.name,
        "drives": {
            "dominance": drives.dominance,
            "extraversion": drives.extraversion,
            "patience": drives.patience,
            "formality": drives.formality,
        },
        "role": profile.role.value,
        "adaptation": {
            "response_length": profile.adaptation.response_length,
            "autonomy_level": profile.adaptation.autonomy_level,
            "tone": profile.adaptation.tone,
            "pacing": profile.adaptation.pacing,
            "decision_style": profile.adaptation.decision_style,
        },
    }
    with open(PROFILE_PATH, "w") as f:
        yaml.dump(data, f, default_flow_style=False)


def _log_interaction(event: dict[str, Any]) -> None:
    """Append interaction event to local log (for profile refinement)."""
    _ensure_dir()
    with open(INTERACTIONS_PATH, "a") as f:
        f.write(json.dumps(event) + "\n")


# ── MCP Tool Handlers ────────────────────────────────────────────────────────


def handle_assess(args: dict[str, Any]) -> dict[str, Any]:
    """Run behavioral assessment or return questions for the agent to ask.

    If `answers` is provided, score them and return the profile.
    If not, return the 10 questions for the agent to present.
    """
    answers = args.get("answers")

    if answers is None:
        # Return questions for the agent to present conversationally
        return {
            "status": "questions",
            "count": len(QUESTIONS),
            "instructions": (
                "Present these questions conversationally — one at a time. "
                "Don't make it feel like a test. Frame it as 'Let me get to know "
                "how you work so I can be a better teammate.' After all answers, "
                "call maverick_assess again with the answers dict."
            ),
            "questions": [
                {
                    "id": q.id,
                    "text": q.text,
                    "choice_a": q.choice_a,
                    "choice_b": q.choice_b,
                }
                for q in QUESTIONS
            ],
        }

    # Score the answers
    profile = score_assessment(answers)
    drives = Drives(
        dominance=max(1, min(10, sum(
            (q.a_adjusts if answers.get(q.id) == "a" else q.b_adjusts).get("D", 0)
            for q in QUESTIONS
        ) + 5)),
        extraversion=max(1, min(10, sum(
            (q.a_adjusts if answers.get(q.id) == "a" else q.b_adjusts).get("E", 0)
            for q in QUESTIONS
        ) + 5)),
        patience=max(1, min(10, sum(
            (q.a_adjusts if answers.get(q.id) == "a" else q.b_adjusts).get("C", 0)
            for q in QUESTIONS
        ) + 5)),
        formality=max(1, min(10, sum(
            (q.a_adjusts if answers.get(q.id) == "a" else q.b_adjusts).get("F", 0)
            for q in QUESTIONS
        ) + 5)),
    )
    _save_profile(profile, drives)

    return {
        "status": "profiled",
        "profile": profile.id,
        "name": profile.name,
        "role": profile.role.value,
        "style": profile.style,
        "message": (
            f"Got it — you're a {profile.name}. {profile.style}. "
            f"I'll adapt how I work with you from here on out."
        ),
    }


def handle_profile(_args: dict[str, Any]) -> dict[str, Any]:
    """Return the current user's behavioral profile."""
    saved = _load_profile()
    if saved is None:
        return {
            "status": "no_profile",
            "message": (
                "No behavioral profile detected yet. Run maverick_assess to "
                "set one up (takes 2 minutes), or I'll infer one from how you "
                "interact over the next few sessions."
            ),
        }

    profile = get_profile(saved["profile_id"])
    if profile is None:
        return {"status": "error", "message": "Saved profile not found in registry"}

    return {
        "status": "ok",
        "profile_id": profile.id,
        "name": profile.name,
        "drives": saved["drives"],
        "role": profile.role.value,
        "style": profile.style,
        "population_pct": profile.population_pct,
    }


def handle_adapt(args: dict[str, Any]) -> dict[str, Any]:
    """Get adaptation instructions for the current context.

    The agent calls this at the start of a task to get behavioral
    context to inject into its approach.
    """
    saved = _load_profile()
    if saved is None:
        return {
            "status": "no_profile",
            "adaptation": (
                "No profile detected. Use a balanced, moderate approach. "
                "Mirror the user's energy and adjust as you go."
            ),
        }

    profile = get_profile(saved["profile_id"])
    if profile is None:
        return {"status": "error", "message": "Profile not found"}

    task_context = args.get("task_context", "general development")

    return {
        "status": "ok",
        "profile": profile.id,
        "role": profile.role.value,
        "adaptation": profile.adaptation.prompt_injection,
        "settings": {
            "response_length": profile.adaptation.response_length,
            "autonomy_level": profile.adaptation.autonomy_level,
            "tone": profile.adaptation.tone,
            "pacing": profile.adaptation.pacing,
            "decision_style": profile.adaptation.decision_style,
            "checkpoint_frequency": profile.adaptation.checkpoint_frequency,
            "explanation_depth": profile.adaptation.explanation_depth,
        },
        "context_note": (
            f"Adapting for {profile.name} profile ({profile.style}). "
            f"Task context: {task_context}"
        ),
    }


def handle_card(args: dict[str, Any]) -> dict[str, Any]:
    """Generate a shareable Developer Card from the user's behavioral profile.

    Creates a beautiful HTML file at ~/.maverick/card.html that the user
    can open in a browser, screenshot, and share on social media.
    """
    saved = _load_profile()
    profile_id = args.get("profile_id")

    if profile_id:
        return generate_card(profile_id=profile_id)

    if saved:
        return generate_card(saved_data=saved)

    return {
        "status": "no_profile",
        "message": (
            "No profile found. Run maverick_assess first to discover your "
            "behavioral profile, then come back for your Developer Card."
        ),
    }


def handle_feedback(args: dict[str, Any]) -> dict[str, Any]:
    """Record user feedback to refine the behavioral profile over time.

    The agent should call this when:
    - User explicitly says the response was too long/short
    - User overrides a decision the agent made autonomously
    - User asks for more/less detail
    - User expresses frustration with pacing
    """
    signal = args.get("signal", "neutral")  # "too_fast", "too_slow", "too_detailed", etc.
    context = args.get("context", "")

    _log_interaction({
        "type": "feedback",
        "signal": signal,
        "context": context,
    })

    return {
        "status": "recorded",
        "message": f"Feedback noted: {signal}. I'll adjust.",
    }


# ── Tool Registry ────────────────────────────────────────────────────────────

TOOLS = {
    "maverick_assess": {
        "handler": handle_assess,
        "description": (
            "Run a 2-minute behavioral assessment to detect the developer's "
            "profile, or score previously collected answers. Call with no args "
            "to get the questions, or with {answers: {1: 'a', 2: 'b', ...}} "
            "to score and save the profile."
        ),
    },
    "maverick_profile": {
        "handler": handle_profile,
        "description": (
            "Get the current user's behavioral profile including drives, "
            "role (expander/converter/stabilizer), and style description."
        ),
    },
    "maverick_adapt": {
        "handler": handle_adapt,
        "description": (
            "Get behavioral adaptation instructions for the current task. "
            "Returns prompt injection text and settings that the agent should "
            "follow to match the user's behavioral style. Call at the start "
            "of each new task or conversation."
        ),
    },
    "maverick_card": {
        "handler": handle_card,
        "description": (
            "Generate a shareable Developer Card — a beautiful HTML visualization "
            "of the user's behavioral profile. Opens in any browser, optimized for "
            "screenshots and social sharing. Requires a saved profile (run "
            "maverick_assess first)."
        ),
    },
    "maverick_feedback": {
        "handler": handle_feedback,
        "description": (
            "Record user feedback to refine the behavioral profile. Call when "
            "the user indicates the agent's pacing, detail level, or autonomy "
            "doesn't match their preference."
        ),
    },
}


# ── MCP Tool Definitions (JSON Schema) ───────────────────────────────────────

MCP_TOOLS = [
    Tool(
        name="maverick_assess",
        description=TOOLS["maverick_assess"]["description"],
        inputSchema={
            "type": "object",
            "properties": {
                "answers": {
                    "type": "object",
                    "description": (
                        "Map of question_id (int) to answer ('a' or 'b'). "
                        "Omit to get the question list first."
                    ),
                    "additionalProperties": {
                        "type": "string",
                        "enum": ["a", "b"],
                    },
                },
            },
            "required": [],
        },
    ),
    Tool(
        name="maverick_profile",
        description=TOOLS["maverick_profile"]["description"],
        inputSchema={
            "type": "object",
            "properties": {},
            "required": [],
        },
    ),
    Tool(
        name="maverick_adapt",
        description=TOOLS["maverick_adapt"]["description"],
        inputSchema={
            "type": "object",
            "properties": {
                "task_context": {
                    "type": "string",
                    "description": (
                        "Brief description of the current task or conversation "
                        "(e.g. 'debugging a memory leak', 'code review'). "
                        "Defaults to 'general development'."
                    ),
                },
            },
            "required": [],
        },
    ),
    Tool(
        name="maverick_card",
        description=TOOLS["maverick_card"]["description"],
        inputSchema={
            "type": "object",
            "properties": {
                "profile_id": {
                    "type": "string",
                    "description": (
                        "Optional profile ID to generate card for (e.g. 'maverick', "
                        "'guardian'). If omitted, uses the saved profile."
                    ),
                },
            },
            "required": [],
        },
    ),
    Tool(
        name="maverick_feedback",
        description=TOOLS["maverick_feedback"]["description"],
        inputSchema={
            "type": "object",
            "properties": {
                "signal": {
                    "type": "string",
                    "description": (
                        "The feedback signal. Common values: 'too_fast', "
                        "'too_slow', 'too_detailed', 'too_brief', "
                        "'too_autonomous', 'needs_more_autonomy', "
                        "'too_formal', 'too_casual', 'good'."
                    ),
                },
                "context": {
                    "type": "string",
                    "description": "Optional context about what triggered the feedback.",
                },
            },
            "required": ["signal"],
        },
    ),
]


# ── MCP Server Handlers ───────────────────────────────────────────────────────


@mcp_server.list_tools()
async def list_tools() -> list[Tool]:
    """Return the full list of Maverick tools to any connecting agent."""
    return MCP_TOOLS


@mcp_server.call_tool()
async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
    """Dispatch a tool call to the appropriate handler.

    All handlers are synchronous — they do file I/O only, no async needed.
    Results are serialized to JSON and returned as a single TextContent block.
    """
    tool_entry = TOOLS.get(name)
    if tool_entry is None:
        error = {"error": f"Unknown tool: {name}. Available: {list(TOOLS)}"}
        return [TextContent(type="text", text=json.dumps(error, indent=2))]

    try:
        result = tool_entry["handler"](arguments or {})
    except Exception as exc:
        logger.exception("Tool %s raised an exception", name)
        error = {"error": str(exc), "tool": name}
        return [TextContent(type="text", text=json.dumps(error, indent=2))]

    return [TextContent(type="text", text=json.dumps(result, indent=2))]


# ── Async Entry Point ─────────────────────────────────────────────────────────


async def run_stdio() -> None:
    """Run the MCP server over stdio — primary mode for Goose integration.

    Reads JSON-RPC messages from stdin, writes responses to stdout.
    Stderr is safe to use for logging without interfering with the protocol.
    """
    async with stdio_server() as (read_stream, write_stream):
        init_options = mcp_server.create_initialization_options()
        await mcp_server.run(read_stream, write_stream, init_options)
