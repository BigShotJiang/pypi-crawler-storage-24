"""Developer Card generator — shareable behavioral profile visualization.

Generates a self-contained HTML file with:
  - Profile name, role, and style
  - DECF drive radar visualization (pure CSS, no JS dependencies)
  - Behavioral strengths and blind spots
  - Working style descriptors
  - Subtle Airlock branding with link

The card is designed to be screenshot-friendly (Twitter/X, LinkedIn)
and opens in any browser. Zero dependencies, single file, ~20KB.

Every Goose needs its Maverick.
"""

from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .profiles import BehavioralRole, Drives, Profile, get_profile

# ── Profile metadata for card enrichment ───────────────────────────────────

PROFILE_DETAILS: dict[str, dict[str, Any]] = {
    "maverick": {
        "tagline": "Move fast. Break molds.",
        "strengths": ["Speed to ship", "Gut-driven decisions", "Fearless experimentation", "Bias to action"],
        "blind_spots": ["May skip planning", "Can overlook details", "Impatient with process"],
        "pair_with": "Guardian",
        "energy": "lightning",
    },
    "captain": {
        "tagline": "Lead from the front.",
        "strengths": ["Team rallying", "Clear direction", "Fast decisions", "Executive presence"],
        "blind_spots": ["Can steamroll quieter voices", "May oversimplify", "Moves before consensus"],
        "pair_with": "Collaborator",
        "energy": "command",
    },
    "guardian": {
        "tagline": "Nothing ships dirty.",
        "strengths": ["Risk detection", "Quality assurance", "Thorough review", "Process design"],
        "blind_spots": ["Can block progress", "Over-engineers safety", "Slow to start"],
        "pair_with": "Maverick",
        "energy": "shield",
    },
    "adapter": {
        "tagline": "Read the room. Match the energy.",
        "strengths": ["Flexibility", "Team harmony", "Situational awareness", "Bridge building"],
        "blind_spots": ["Can lack strong opinion", "May defer too much", "Identity shifts under pressure"],
        "pair_with": "Strategist",
        "energy": "mirror",
    },
    "strategist": {
        "tagline": "See around corners.",
        "strengths": ["Systems thinking", "Long-range planning", "Pattern recognition", "Strategic clarity"],
        "blind_spots": ["Can over-analyze", "Slow to execute", "May miss tactical details"],
        "pair_with": "Promoter",
        "energy": "compass",
    },
    "venturer": {
        "tagline": "Trust the gut. Go alone.",
        "strengths": ["Independence", "Bold bets", "Fast iteration", "Self-reliance"],
        "blind_spots": ["Resists collaboration", "Can isolate", "Skips documentation"],
        "pair_with": "Collaborator",
        "energy": "flame",
    },
    "persuader": {
        "tagline": "Win hearts. Ship features.",
        "strengths": ["Stakeholder buy-in", "Narrative framing", "Energy", "Cross-team influence"],
        "blind_spots": ["Can oversell", "May prioritize story over substance", "Moves before verifying"],
        "pair_with": "Analyzer",
        "energy": "spark",
    },
    "collaborator": {
        "tagline": "Together is the only way.",
        "strengths": ["Consensus building", "Team cohesion", "Empathetic leadership", "Inclusive process"],
        "blind_spots": ["Slow decisions", "Avoids conflict", "Can over-consult"],
        "pair_with": "Venturer",
        "energy": "bridge",
    },
    "analyzer": {
        "tagline": "Data first. Always.",
        "strengths": ["Evidence-based decisions", "Deep research", "Rigorous testing", "Pattern detection"],
        "blind_spots": ["Analysis paralysis", "Can miss the forest", "Slow to commit"],
        "pair_with": "Persuader",
        "energy": "lens",
    },
    "specialist": {
        "tagline": "Deep, not wide.",
        "strengths": ["Domain mastery", "Highest standards", "Precision", "Catches everything"],
        "blind_spots": ["Narrow focus", "Can bottleneck team", "Reluctant to generalize"],
        "pair_with": "Promoter",
        "energy": "diamond",
    },
    "scholar": {
        "tagline": "Know it. Then build it.",
        "strengths": ["Knowledge depth", "Rigorous verification", "Domain learning", "Documentation"],
        "blind_spots": ["Can over-research", "Slow to prototype", "Prefers theory to practice"],
        "pair_with": "Captain",
        "energy": "book",
    },
    "controller": {
        "tagline": "Precision at speed.",
        "strengths": ["Structured execution", "Scope control", "Deadline delivery", "Clear ownership"],
        "blind_spots": ["Can micromanage", "Inflexible to change", "May miss creative solutions"],
        "pair_with": "Adapter",
        "energy": "rail",
    },
    "promoter": {
        "tagline": "Make it visible. Make it matter.",
        "strengths": ["Visibility", "Enthusiasm", "Cross-pollination", "Launch energy"],
        "blind_spots": ["Can overpromise", "May lack follow-through", "Prioritizes sizzle"],
        "pair_with": "Specialist",
        "energy": "broadcast",
    },
    "individualist": {
        "tagline": "Heads down. Ships done.",
        "strengths": ["Self-direction", "Quiet persistence", "Focused execution", "Low maintenance"],
        "blind_spots": ["Can under-communicate", "Resists process", "Invisible contributions"],
        "pair_with": "Collaborator",
        "energy": "arrow",
    },
    "operator": {
        "tagline": "Keep the machine running.",
        "strengths": ["Reliability", "Consistent output", "Steady execution", "Operational excellence"],
        "blind_spots": ["Resists change", "Can miss big picture", "Under-recognized"],
        "pair_with": "Strategist",
        "energy": "engine",
    },
    "artisan": {
        "tagline": "Craft it right.",
        "strengths": ["Quality craftsmanship", "Tangible results", "Steady hand", "Pride in work"],
        "blind_spots": ["Can over-polish", "Slow to ship", "Perfectionism"],
        "pair_with": "Captain",
        "energy": "chisel",
    },
    "altruist": {
        "tagline": "Build for people, not metrics.",
        "strengths": ["Empathy", "Team care", "User advocacy", "Conflict resolution"],
        "blind_spots": ["Can avoid hard decisions", "Over-accommodates", "Deprioritizes self"],
        "pair_with": "Controller",
        "energy": "heart",
    },
}


def _role_color(role: BehavioralRole) -> str:
    """Return the accent color for a behavioral role."""
    return {
        BehavioralRole.EXPANDER: "#00FF88",   # Airlock green
        BehavioralRole.CONVERTER: "#7B61FF",   # Purple
        BehavioralRole.STABILIZER: "#00B4D8",  # Cyan
    }[role]


def _role_label(role: BehavioralRole) -> str:
    """Return a human-friendly role label."""
    return {
        BehavioralRole.EXPANDER: "EXPANDER",
        BehavioralRole.CONVERTER: "CONVERTER",
        BehavioralRole.STABILIZER: "STABILIZER",
    }[role]


def _card_id(profile_id: str) -> str:
    """Generate a short unique card ID for sharing."""
    seed = f"{profile_id}-{datetime.now(timezone.utc).isoformat()}"
    return hashlib.sha256(seed.encode()).hexdigest()[:8]


def generate_card_html(profile: Profile, drives: Drives) -> str:
    """Generate a self-contained HTML developer card.

    The card is optimized for:
    - Browser viewing (opens as file:// or served)
    - Screenshot sharing (fixed 600x800 viewport)
    - Twitter/X card dimensions
    - Dark theme, Airlock brand
    """
    details = PROFILE_DETAILS.get(profile.id, {})
    tagline = details.get("tagline", profile.style)
    strengths = details.get("strengths", [])
    blind_spots = details.get("blind_spots", [])
    pair_with = details.get("pair_with", "—")
    accent = _role_color(profile.role)
    role_label = _role_label(profile.role)
    card_id = _card_id(profile.id)
    date = datetime.now(timezone.utc).strftime("%Y-%m-%d")

    # Drive bar percentages (1-10 → 10%-100%)
    d_pct = drives.dominance * 10
    e_pct = drives.extraversion * 10
    c_pct = drives.patience * 10
    f_pct = drives.formality * 10

    strengths_html = "".join(f'<span class="tag strength">{s}</span>' for s in strengths)
    blind_spots_html = "".join(f'<span class="tag blind-spot">{b}</span>' for b in blind_spots)

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{profile.name} — Developer Card | Maverick</title>
<meta name="description" content="{profile.name}: {tagline}">
<style>
  @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;700&family=Inter:wght@400;500;600;700&display=swap');

  * {{ margin: 0; padding: 0; box-sizing: border-box; }}

  body {{
    background: #0a0a0f;
    display: flex;
    align-items: center;
    justify-content: center;
    min-height: 100vh;
    font-family: 'Inter', -apple-system, sans-serif;
    color: #e0e0e0;
  }}

  .card {{
    width: 480px;
    background: linear-gradient(145deg, #111118 0%, #0d0d14 100%);
    border: 1px solid {accent}22;
    border-radius: 16px;
    padding: 40px 36px;
    position: relative;
    overflow: hidden;
  }}

  .card::before {{
    content: '';
    position: absolute;
    top: -80px;
    right: -80px;
    width: 200px;
    height: 200px;
    background: radial-gradient(circle, {accent}15 0%, transparent 70%);
    pointer-events: none;
  }}

  .card::after {{
    content: '';
    position: absolute;
    bottom: -60px;
    left: -60px;
    width: 160px;
    height: 160px;
    background: radial-gradient(circle, {accent}08 0%, transparent 70%);
    pointer-events: none;
  }}

  .header {{
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    margin-bottom: 28px;
  }}

  .profile-name {{
    font-family: 'JetBrains Mono', monospace;
    font-size: 32px;
    font-weight: 700;
    color: {accent};
    letter-spacing: -0.5px;
    line-height: 1;
  }}

  .tagline {{
    font-size: 14px;
    color: rgba(255,255,255,0.5);
    margin-top: 6px;
    font-style: italic;
  }}

  .role-badge {{
    font-family: 'JetBrains Mono', monospace;
    font-size: 10px;
    font-weight: 700;
    letter-spacing: 0.15em;
    color: {accent};
    border: 1px solid {accent}44;
    padding: 4px 10px;
    border-radius: 4px;
    background: {accent}0a;
    white-space: nowrap;
  }}

  .population {{
    font-family: 'JetBrains Mono', monospace;
    font-size: 10px;
    color: rgba(255,255,255,0.3);
    text-align: right;
    margin-top: 4px;
  }}

  .drives {{
    margin-bottom: 28px;
  }}

  .drives-title {{
    font-family: 'JetBrains Mono', monospace;
    font-size: 10px;
    font-weight: 700;
    letter-spacing: 0.15em;
    color: rgba(255,255,255,0.3);
    text-transform: uppercase;
    margin-bottom: 12px;
  }}

  .drive-row {{
    display: flex;
    align-items: center;
    margin-bottom: 8px;
    gap: 10px;
  }}

  .drive-label {{
    font-family: 'JetBrains Mono', monospace;
    font-size: 11px;
    font-weight: 500;
    color: rgba(255,255,255,0.6);
    width: 90px;
    flex-shrink: 0;
  }}

  .drive-track {{
    flex: 1;
    height: 6px;
    background: rgba(255,255,255,0.06);
    border-radius: 3px;
    overflow: hidden;
  }}

  .drive-fill {{
    height: 100%;
    border-radius: 3px;
    background: {accent};
    transition: width 1s ease;
  }}

  .drive-value {{
    font-family: 'JetBrains Mono', monospace;
    font-size: 11px;
    font-weight: 700;
    color: {accent};
    width: 24px;
    text-align: right;
    flex-shrink: 0;
  }}

  .section {{
    margin-bottom: 20px;
  }}

  .section-title {{
    font-family: 'JetBrains Mono', monospace;
    font-size: 10px;
    font-weight: 700;
    letter-spacing: 0.15em;
    color: rgba(255,255,255,0.3);
    text-transform: uppercase;
    margin-bottom: 10px;
  }}

  .tags {{
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
  }}

  .tag {{
    font-family: 'JetBrains Mono', monospace;
    font-size: 10px;
    font-weight: 500;
    padding: 4px 10px;
    border-radius: 4px;
    letter-spacing: 0.02em;
  }}

  .tag.strength {{
    background: {accent}15;
    color: {accent};
    border: 1px solid {accent}30;
  }}

  .tag.blind-spot {{
    background: rgba(255,255,255,0.04);
    color: rgba(255,255,255,0.4);
    border: 1px solid rgba(255,255,255,0.08);
  }}

  .pair-row {{
    display: flex;
    align-items: center;
    gap: 8px;
    margin-bottom: 28px;
  }}

  .pair-label {{
    font-family: 'JetBrains Mono', monospace;
    font-size: 10px;
    color: rgba(255,255,255,0.3);
    letter-spacing: 0.1em;
    text-transform: uppercase;
  }}

  .pair-value {{
    font-family: 'JetBrains Mono', monospace;
    font-size: 12px;
    color: rgba(255,255,255,0.7);
    font-weight: 600;
  }}

  .adaptation {{
    font-size: 12px;
    line-height: 1.6;
    color: rgba(255,255,255,0.35);
    margin-bottom: 28px;
    padding: 12px 14px;
    background: rgba(255,255,255,0.02);
    border-radius: 8px;
    border-left: 2px solid {accent}33;
  }}

  .footer {{
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding-top: 20px;
    border-top: 1px solid rgba(255,255,255,0.06);
  }}

  .branding {{
    font-family: 'JetBrains Mono', monospace;
    font-size: 10px;
    color: rgba(255,255,255,0.2);
    letter-spacing: 0.1em;
  }}

  .branding a {{
    color: {accent}88;
    text-decoration: none;
  }}

  .branding a:hover {{
    color: {accent};
  }}

  .card-meta {{
    font-family: 'JetBrains Mono', monospace;
    font-size: 9px;
    color: rgba(255,255,255,0.15);
    text-align: right;
  }}

  @media (max-width: 520px) {{
    .card {{
      width: 100%;
      margin: 16px;
      padding: 28px 24px;
    }}
    .profile-name {{ font-size: 26px; }}
  }}
</style>
</head>
<body>

<div class="card">
  <div class="header">
    <div>
      <div class="profile-name">{profile.name}</div>
      <div class="tagline">{tagline}</div>
    </div>
    <div>
      <div class="role-badge">{role_label}</div>
      <div class="population">{profile.population_pct}% of devs</div>
    </div>
  </div>

  <div class="drives">
    <div class="drives-title">Behavioral Drives</div>
    <div class="drive-row">
      <span class="drive-label">Dominance</span>
      <div class="drive-track"><div class="drive-fill" style="width: {d_pct}%"></div></div>
      <span class="drive-value">{drives.dominance}</span>
    </div>
    <div class="drive-row">
      <span class="drive-label">Extraversion</span>
      <div class="drive-track"><div class="drive-fill" style="width: {e_pct}%"></div></div>
      <span class="drive-value">{drives.extraversion}</span>
    </div>
    <div class="drive-row">
      <span class="drive-label">Patience</span>
      <div class="drive-track"><div class="drive-fill" style="width: {c_pct}%"></div></div>
      <span class="drive-value">{drives.patience}</span>
    </div>
    <div class="drive-row">
      <span class="drive-label">Formality</span>
      <div class="drive-track"><div class="drive-fill" style="width: {f_pct}%"></div></div>
      <span class="drive-value">{drives.formality}</span>
    </div>
  </div>

  <div class="section">
    <div class="section-title">Strengths</div>
    <div class="tags">{strengths_html}</div>
  </div>

  <div class="section">
    <div class="section-title">Blind Spots</div>
    <div class="tags">{blind_spots_html}</div>
  </div>

  <div class="pair-row">
    <span class="pair-label">Best pair:</span>
    <span class="pair-value">{pair_with}</span>
  </div>

  <div class="adaptation">{profile.adaptation.prompt_injection}</div>

  <div class="footer">
    <div class="branding">
      MAVERICK by <a href="https://doyoulikedags.xyz" target="_blank">Airlock</a>
    </div>
    <div class="card-meta">#{card_id} &middot; {date}</div>
  </div>
</div>

</body>
</html>"""


def generate_card(profile_id: str | None = None, saved_data: dict | None = None) -> dict[str, Any]:
    """Generate a developer card from profile data.

    Args:
        profile_id: Profile ID to generate card for (uses saved profile if None)
        saved_data: Pre-loaded profile data dict (from profile.yaml)

    Returns:
        Dict with status, html content, and file path
    """
    if saved_data is None and profile_id is None:
        return {"status": "no_profile", "message": "No profile found. Run maverick_assess first."}

    if profile_id:
        profile = get_profile(profile_id)
        if profile is None:
            return {"status": "error", "message": f"Unknown profile: {profile_id}"}
        drives = profile.drives
    elif saved_data:
        profile = get_profile(saved_data["profile_id"])
        if profile is None:
            return {"status": "error", "message": "Saved profile not found in registry"}
        d = saved_data.get("drives", {})
        drives = Drives(
            dominance=d.get("dominance", 5),
            extraversion=d.get("extraversion", 5),
            patience=d.get("patience", 5),
            formality=d.get("formality", 5),
        )
    else:
        return {"status": "error", "message": "No profile data available"}

    html = generate_card_html(profile, drives)

    # Save to ~/.maverick/card.html
    card_dir = Path.home() / ".maverick"
    card_dir.mkdir(parents=True, exist_ok=True)
    card_path = card_dir / "card.html"
    card_path.write_text(html, encoding="utf-8")

    return {
        "status": "ok",
        "profile": profile.id,
        "name": profile.name,
        "path": str(card_path),
        "message": (
            f"Developer Card generated for {profile.name}. "
            f"Open {card_path} in your browser to see it. "
            "Screenshot it and share — let people know how you work."
        ),
        "html": html,
    }
