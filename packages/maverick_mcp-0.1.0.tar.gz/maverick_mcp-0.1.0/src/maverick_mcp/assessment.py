"""Behavioral assessment — 10 questions to detect DECF profile.

Quick, non-invasive, no wrong answers. Each question surfaces a behavioral
preference across one or two drives. Responses are scored and mapped to the
closest of 17 profiles.

The assessment is optional. Maverick can also infer profiles from interaction
patterns over time. But the assessment gets you there in 2 minutes.
"""

from __future__ import annotations

from dataclasses import dataclass

from .profiles import Drives, Profile, match_profile

# ── Assessment Questions ─────────────────────────────────────────────────────
# Each question has two poles. Choice A increases certain drives, Choice B
# increases others. No neutral — you pick the one that feels more natural.


@dataclass
class Question:
    """A behavioral assessment question with two choices."""

    id: int
    text: str
    choice_a: str
    choice_b: str
    # Drive adjustments for choosing A vs B
    a_adjusts: dict[str, int]  # e.g., {"D": +2, "C": -1}
    b_adjusts: dict[str, int]


QUESTIONS: list[Question] = [
    Question(
        id=1,
        text="When starting a new project, do you prefer to:",
        choice_a="Jump in and figure it out as you go",
        choice_b="Plan thoroughly before writing any code",
        a_adjusts={"D": 2, "C": -1},
        b_adjusts={"C": 2, "F": 1},
    ),
    Question(
        id=2,
        text="When you disagree with a technical decision, do you:",
        choice_a="Push back directly and advocate for your approach",
        choice_b="Gather evidence first, then present your case carefully",
        a_adjusts={"D": 2, "E": 1},
        b_adjusts={"F": 2, "C": 1},
    ),
    Question(
        id=3,
        text="In code reviews, do you focus more on:",
        choice_a="Whether it ships the feature and moves things forward",
        choice_b="Whether it follows patterns and handles edge cases",
        a_adjusts={"D": 1, "C": -1},
        b_adjusts={"F": 2, "C": 1},
    ),
    Question(
        id=4,
        text="When pair programming, do you prefer to:",
        choice_a="Drive the keyboard and talk through your thinking",
        choice_b="Navigate and observe, offering suggestions",
        a_adjusts={"D": 1, "E": 2},
        b_adjusts={"C": 1, "E": -1},
    ),
    Question(
        id=5,
        text="When a deadline is tight, do you:",
        choice_a="Cut scope aggressively and ship what matters",
        choice_b="Push back on the deadline to maintain quality",
        a_adjusts={"D": 2, "C": -2},
        b_adjusts={"C": 2, "F": 1},
    ),
    Question(
        id=6,
        text="How do you prefer to communicate with your team?",
        choice_a="Quick messages, standups, and face-to-face",
        choice_b="Detailed written docs, async, and structured updates",
        a_adjusts={"E": 2, "C": -1},
        b_adjusts={"E": -1, "F": 2},
    ),
    Question(
        id=7,
        text="When debugging a tricky issue, do you:",
        choice_a="Trust your intuition and jump to the likely cause",
        choice_b="Systematically trace through logs and reproduce step by step",
        a_adjusts={"D": 1, "C": -1},
        b_adjusts={"C": 2, "F": 1},
    ),
    Question(
        id=8,
        text="In meetings, do you tend to:",
        choice_a="Speak up first and shape the direction",
        choice_b="Listen first and contribute when you have something specific",
        a_adjusts={"D": 1, "E": 2},
        b_adjusts={"C": 1, "E": -1},
    ),
    Question(
        id=9,
        text="When learning a new technology, do you:",
        choice_a="Build something with it immediately",
        choice_b="Read the docs and understand the architecture first",
        a_adjusts={"D": 1, "C": -1, "E": 1},
        b_adjusts={"C": 1, "F": 2},
    ),
    Question(
        id=10,
        text="What frustrates you more?",
        choice_a="Being slowed down by process and bureaucracy",
        choice_b="Shipping something that wasn't ready",
        a_adjusts={"D": 2, "C": -2, "F": -1},
        b_adjusts={"C": 2, "F": 2},
    ),
]


def score_assessment(answers: dict[int, str]) -> Profile:
    """Score a completed assessment and return the best-matching profile.

    Args:
        answers: dict mapping question ID to "a" or "b"

    Returns:
        The closest matching Profile
    """
    # Start from neutral midpoint
    scores = {"D": 5, "E": 5, "C": 5, "F": 5}

    for question in QUESTIONS:
        answer = answers.get(question.id)
        if answer is None:
            continue

        adjustments = question.a_adjusts if answer == "a" else question.b_adjusts
        for drive, delta in adjustments.items():
            scores[drive] = max(1, min(10, scores[drive] + delta))

    drives = Drives(
        dominance=scores["D"],
        extraversion=scores["E"],
        patience=scores["C"],
        formality=scores["F"],
    )

    return match_profile(drives)
