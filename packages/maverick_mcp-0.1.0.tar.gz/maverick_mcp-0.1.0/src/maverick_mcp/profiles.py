"""The 17 behavioral profiles — derived from Predictive Index science.

Every person has a unique DECF signature:
  D = Dominance (drive for control over environment)
  E = Extraversion (drive for social interaction)
  C = Patience (drive for stability and deliberate pace)
  F = Formality (drive for rules and structure)

These profiles are the foundation. The adaptation layer on top
makes the AI agent feel like a real teammate — not a chatbot.

Every Goose needs its Maverick.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Optional


class BehavioralRole(str, Enum):
    """Chemistry Engine classification — what kind of energy this profile brings."""

    EXPANDER = "expander"  # Pushes boundaries, generates ideas, takes risks
    CONVERTER = "converter"  # Translates between expansion and stability
    STABILIZER = "stabilizer"  # Holds the line, ensures quality, protects process


@dataclass(frozen=True)
class Drives:
    """The four behavioral drives (1-10 scale)."""

    dominance: int
    extraversion: int
    patience: int
    formality: int

    @property
    def expander_score(self) -> float:
        return (self.dominance * 1.5) + self.extraversion - (self.patience * 0.8) - (
            self.formality * 0.3
        )

    @property
    def stabilizer_score(self) -> float:
        return (self.patience * 1.5) + self.formality - (self.dominance * 0.8) - (
            self.extraversion * 0.3
        )

    @property
    def converter_score(self) -> float:
        return (
            10
            - abs(self.dominance - 5.5)
            - abs(self.extraversion - 5.5)
            - abs(self.patience - 5.5) * 0.5
            - abs(self.formality - 5.5) * 0.5
        )

    @property
    def primary_role(self) -> BehavioralRole:
        scores = {
            BehavioralRole.EXPANDER: self.expander_score,
            BehavioralRole.CONVERTER: self.converter_score,
            BehavioralRole.STABILIZER: self.stabilizer_score,
        }
        return max(scores, key=scores.get)  # type: ignore[arg-type]


@dataclass(frozen=True)
class Profile:
    """A behavioral profile with drives and adaptation instructions."""

    id: str
    name: str
    drives: Drives
    role: BehavioralRole
    population_pct: float
    style: str  # One-line description
    adaptation: AdaptationSpec


@dataclass(frozen=True)
class AdaptationSpec:
    """How the AI agent should adapt for this profile."""

    response_length: str  # "short", "moderate", "detailed"
    autonomy_level: str  # "maximum", "high", "moderate", "guided"
    tone: str  # "direct", "collaborative", "supportive", "precise"
    pacing: str  # "fast", "moderate", "deliberate"
    decision_style: str  # "decisive", "consultative", "evidence-based", "consensus"
    checkpoint_frequency: str  # "minimal", "moderate", "frequent"
    explanation_depth: str  # "summary", "moderate", "thorough"
    prompt_injection: str  # The actual system prompt context to inject


# ── The 17 Canonical Profiles ────────────────────────────────────────────────

PROFILES: dict[str, Profile] = {
    "maverick": Profile(
        id="maverick",
        name="Maverick",
        drives=Drives(10, 8, 1, 1),
        role=BehavioralRole.EXPANDER,
        population_pct=2.5,
        style="Fast, bold, breaks molds — the rarest profile",
        adaptation=AdaptationSpec(
            response_length="short",
            autonomy_level="maximum",
            tone="direct",
            pacing="fast",
            decision_style="decisive",
            checkpoint_frequency="minimal",
            explanation_depth="summary",
            prompt_injection=(
                "This developer moves FAST and trusts their gut. Keep responses short "
                "and action-oriented. Lead with the answer, skip the preamble. Give ship "
                "dates, not explanations. Only pause for truly irreversible decisions. "
                "They'll tell you if they need more detail — don't volunteer it."
            ),
        ),
    ),
    "captain": Profile(
        id="captain",
        name="Captain",
        drives=Drives(9, 8, 2, 2),
        role=BehavioralRole.EXPANDER,
        population_pct=3.38,
        style="Commanding, decisive, rallies teams",
        adaptation=AdaptationSpec(
            response_length="short",
            autonomy_level="high",
            tone="direct",
            pacing="fast",
            decision_style="decisive",
            checkpoint_frequency="minimal",
            explanation_depth="summary",
            prompt_injection=(
                "This developer leads from the front. Give executive summaries, not "
                "dissertations. Frame options as recommendations with clear trade-offs. "
                "They want to make the call — give them what they need to decide fast."
            ),
        ),
    ),
    "guardian": Profile(
        id="guardian",
        name="Guardian",
        drives=Drives(3, 3, 9, 8),
        role=BehavioralRole.STABILIZER,
        population_pct=6.0,
        style="Thorough, protective, catches everything",
        adaptation=AdaptationSpec(
            response_length="detailed",
            autonomy_level="guided",
            tone="precise",
            pacing="deliberate",
            decision_style="evidence-based",
            checkpoint_frequency="frequent",
            explanation_depth="thorough",
            prompt_injection=(
                "This developer values thoroughness and safety above speed. Show your "
                "reasoning. Cite evidence. Flag risks BEFORE taking action. Ask for "
                "confirmation on anything destructive or irreversible. They'd rather "
                "take longer and be right than ship fast and break things."
            ),
        ),
    ),
    "adapter": Profile(
        id="adapter",
        name="Adapter",
        drives=Drives(5, 5, 5, 5),
        role=BehavioralRole.CONVERTER,
        population_pct=8.0,
        style="Balanced, flexible, reads the room",
        adaptation=AdaptationSpec(
            response_length="moderate",
            autonomy_level="moderate",
            tone="collaborative",
            pacing="moderate",
            decision_style="consultative",
            checkpoint_frequency="moderate",
            explanation_depth="moderate",
            prompt_injection=(
                "This developer is balanced and adaptable. Mirror their energy — if "
                "they're moving fast, match it. If they slow down, slow down. Offer "
                "options without being overwhelming. They appreciate flexibility."
            ),
        ),
    ),
    "strategist": Profile(
        id="strategist",
        name="Strategist",
        drives=Drives(8, 3, 3, 5),
        role=BehavioralRole.EXPANDER,
        population_pct=4.0,
        style="Analytical, big-picture, sees around corners",
        adaptation=AdaptationSpec(
            response_length="moderate",
            autonomy_level="high",
            tone="direct",
            pacing="moderate",
            decision_style="decisive",
            checkpoint_frequency="minimal",
            explanation_depth="moderate",
            prompt_injection=(
                "This developer thinks in systems. Show how pieces connect. Frame "
                "decisions in terms of long-range implications. They want the map, "
                "not turn-by-turn directions. Skip the small talk."
            ),
        ),
    ),
    "venturer": Profile(
        id="venturer",
        name="Venturer",
        drives=Drives(10, 3, 1, 3),
        role=BehavioralRole.EXPANDER,
        population_pct=2.0,
        style="Fiercely independent, trusts gut, moves alone",
        adaptation=AdaptationSpec(
            response_length="short",
            autonomy_level="maximum",
            tone="direct",
            pacing="fast",
            decision_style="decisive",
            checkpoint_frequency="minimal",
            explanation_depth="summary",
            prompt_injection=(
                "This developer operates solo and trusts their instincts. Minimal "
                "hand-holding. Don't explain what they didn't ask about. Get out of "
                "their way and let them drive. They'll ask if they need help."
            ),
        ),
    ),
    "persuader": Profile(
        id="persuader",
        name="Persuader",
        drives=Drives(8, 9, 3, 3),
        role=BehavioralRole.EXPANDER,
        population_pct=4.0,
        style="Energetic, narrative-driven, wins buy-in",
        adaptation=AdaptationSpec(
            response_length="moderate",
            autonomy_level="high",
            tone="collaborative",
            pacing="fast",
            decision_style="decisive",
            checkpoint_frequency="minimal",
            explanation_depth="moderate",
            prompt_injection=(
                "This developer thinks in narratives and stakeholder impact. Frame "
                "technical decisions in terms of who benefits and why. They move fast "
                "and want energy in the interaction. Be a co-conspirator, not a servant."
            ),
        ),
    ),
    "collaborator": Profile(
        id="collaborator",
        name="Collaborator",
        drives=Drives(3, 8, 7, 3),
        role=BehavioralRole.CONVERTER,
        population_pct=6.0,
        style="Team-oriented, builds consensus, connects people",
        adaptation=AdaptationSpec(
            response_length="moderate",
            autonomy_level="moderate",
            tone="supportive",
            pacing="moderate",
            decision_style="consensus",
            checkpoint_frequency="moderate",
            explanation_depth="moderate",
            prompt_injection=(
                "This developer values team alignment. Frame decisions in terms of "
                "impact on others. Ask 'how does this affect the team?' before 'how "
                "do we ship this?' Be warm but productive."
            ),
        ),
    ),
    "analyzer": Profile(
        id="analyzer",
        name="Analyzer",
        drives=Drives(3, 2, 8, 9),
        role=BehavioralRole.STABILIZER,
        population_pct=7.0,
        style="Methodical, data-driven, builds from evidence",
        adaptation=AdaptationSpec(
            response_length="detailed",
            autonomy_level="guided",
            tone="precise",
            pacing="deliberate",
            decision_style="evidence-based",
            checkpoint_frequency="frequent",
            explanation_depth="thorough",
            prompt_injection=(
                "This developer builds conclusions from data, not instinct. Show your "
                "work. Include sources. Present options with quantified trade-offs. "
                "Never ask them to 'just trust' a recommendation."
            ),
        ),
    ),
    "specialist": Profile(
        id="specialist",
        name="Specialist",
        drives=Drives(2, 2, 9, 10),
        role=BehavioralRole.STABILIZER,
        population_pct=3.0,
        style="Deep expertise, highest standards, narrow focus",
        adaptation=AdaptationSpec(
            response_length="detailed",
            autonomy_level="guided",
            tone="precise",
            pacing="deliberate",
            decision_style="evidence-based",
            checkpoint_frequency="frequent",
            explanation_depth="thorough",
            prompt_injection=(
                "This developer has the deepest expertise and the highest standards. "
                "Match their depth. Don't oversimplify. Acknowledge the complexity "
                "they see. Verify every claim. They catch everything."
            ),
        ),
    ),
    "scholar": Profile(
        id="scholar",
        name="Scholar",
        drives=Drives(3, 2, 7, 8),
        role=BehavioralRole.STABILIZER,
        population_pct=4.0,
        style="Knowledge-seeking, rigorous, masters domains",
        adaptation=AdaptationSpec(
            response_length="detailed",
            autonomy_level="moderate",
            tone="precise",
            pacing="deliberate",
            decision_style="evidence-based",
            checkpoint_frequency="moderate",
            explanation_depth="thorough",
            prompt_injection=(
                "This developer values verified knowledge. Cite sources. Distinguish "
                "between 'I know this' and 'I think this.' They appreciate learning "
                "something new — don't dumb things down."
            ),
        ),
    ),
    "controller": Profile(
        id="controller",
        name="Controller",
        drives=Drives(9, 2, 3, 8),
        role=BehavioralRole.EXPANDER,
        population_pct=4.0,
        style="Structured expansion, demands precision",
        adaptation=AdaptationSpec(
            response_length="moderate",
            autonomy_level="high",
            tone="direct",
            pacing="fast",
            decision_style="decisive",
            checkpoint_frequency="moderate",
            explanation_depth="moderate",
            prompt_injection=(
                "This developer drives hard within tight rails. Be precise about "
                "scope and ownership. They want control and clarity. Frame work in "
                "terms of specs and deliverables, not possibilities."
            ),
        ),
    ),
    "promoter": Profile(
        id="promoter",
        name="Promoter",
        drives=Drives(7, 10, 2, 2),
        role=BehavioralRole.EXPANDER,
        population_pct=4.0,
        style="Highest social energy, broadcast expansion",
        adaptation=AdaptationSpec(
            response_length="moderate",
            autonomy_level="high",
            tone="collaborative",
            pacing="fast",
            decision_style="decisive",
            checkpoint_frequency="minimal",
            explanation_depth="summary",
            prompt_injection=(
                "This developer has maximum social energy. Keep things visible and "
                "exciting. Celebrate progress. Frame work in terms of impact and "
                "audience. They want to share what they build."
            ),
        ),
    ),
    "individualist": Profile(
        id="individualist",
        name="Individualist",
        drives=Drives(6, 2, 5, 6),
        role=BehavioralRole.CONVERTER,
        population_pct=4.88,
        style="Self-reliant, focused, quiet persistence",
        adaptation=AdaptationSpec(
            response_length="moderate",
            autonomy_level="high",
            tone="direct",
            pacing="moderate",
            decision_style="decisive",
            checkpoint_frequency="minimal",
            explanation_depth="moderate",
            prompt_injection=(
                "This developer is self-directed and doesn't need cheerleading. "
                "Respect their process. Deliver what's asked without over-explaining. "
                "They'll ask for help when they need it."
            ),
        ),
    ),
    "operator": Profile(
        id="operator",
        name="Operator",
        drives=Drives(2, 3, 8, 6),
        role=BehavioralRole.STABILIZER,
        population_pct=7.0,
        style="Reliable, steady, keeps the machine running",
        adaptation=AdaptationSpec(
            response_length="moderate",
            autonomy_level="moderate",
            tone="supportive",
            pacing="deliberate",
            decision_style="consultative",
            checkpoint_frequency="moderate",
            explanation_depth="moderate",
            prompt_injection=(
                "This developer values reliability and predictability. Give clear "
                "steps in order. Don't surprise them. Be consistent in how you "
                "present information. They are the backbone — treat them that way."
            ),
        ),
    ),
    "artisan": Profile(
        id="artisan",
        name="Artisan",
        drives=Drives(5, 3, 7, 5),
        role=BehavioralRole.STABILIZER,
        population_pct=5.0,
        style="Craftsmanship, tangible results, steady hand",
        adaptation=AdaptationSpec(
            response_length="moderate",
            autonomy_level="moderate",
            tone="direct",
            pacing="moderate",
            decision_style="evidence-based",
            checkpoint_frequency="moderate",
            explanation_depth="moderate",
            prompt_injection=(
                "This developer takes pride in craft. Appreciate quality over speed. "
                "Frame progress in terms of tangible, measurable outcomes. Don't "
                "rush them — their steady pace produces the best work."
            ),
        ),
    ),
    "altruist": Profile(
        id="altruist",
        name="Altruist",
        drives=Drives(2, 9, 8, 2),
        role=BehavioralRole.STABILIZER,
        population_pct=5.0,
        style="Warm, caring, stabilizes through people",
        adaptation=AdaptationSpec(
            response_length="moderate",
            autonomy_level="moderate",
            tone="supportive",
            pacing="moderate",
            decision_style="consensus",
            checkpoint_frequency="moderate",
            explanation_depth="moderate",
            prompt_injection=(
                "This developer cares deeply about people and impact. Frame technical "
                "decisions in terms of who they help. Be warm but not patronizing. "
                "They hold teams together — acknowledge that."
            ),
        ),
    ),
}


def get_profile(profile_id: str) -> Optional[Profile]:
    """Look up a profile by ID."""
    return PROFILES.get(profile_id.lower())


def match_profile(drives: Drives) -> Profile:
    """Find the closest matching profile using Euclidean distance."""
    best_match: Optional[Profile] = None
    best_distance = float("inf")

    for profile in PROFILES.values():
        distance = (
            (drives.dominance - profile.drives.dominance) ** 2
            + (drives.extraversion - profile.drives.extraversion) ** 2
            + (drives.patience - profile.drives.patience) ** 2
            + (drives.formality - profile.drives.formality) ** 2
        ) ** 0.5

        if distance < best_distance:
            best_distance = distance
            best_match = profile

    assert best_match is not None
    return best_match
