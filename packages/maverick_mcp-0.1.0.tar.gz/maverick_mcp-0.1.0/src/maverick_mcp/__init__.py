# Every Goose needs its Maverick.
"""Behavioral intelligence MCP server for AI agents."""

__version__ = "0.1.0"
