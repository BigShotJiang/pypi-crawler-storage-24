"""CLI entry point for maverick-mcp.

Usage:
    maverick serve          # Start MCP server (stdio mode, for Goose)
    maverick assess         # Run assessment interactively
    maverick profile        # Show current profile
    maverick reset          # Clear saved profile

Every Goose needs its Maverick.
"""

from __future__ import annotations

import argparse
import asyncio
import logging
import sys

from .assessment import QUESTIONS, score_assessment
from .card import generate_card
from .server import PROFILE_PATH, _load_profile, run_stdio

logger = logging.getLogger(__name__)


def cmd_serve(args: argparse.Namespace) -> None:
    """Start the MCP server.

    Default mode is stdio, which is what Goose and other MCP hosts expect.
    Stderr is used for diagnostic logging so it doesn't corrupt the stdio
    JSON-RPC stream on stdout/stdin.
    """
    if args.port:
        # SSE mode — not yet implemented; stdio is the primary integration path
        print(
            f"SSE mode (port {args.port}) is not yet implemented. "
            "Use stdio mode (omit --port) for Goose integration.",
            file=sys.stderr,
        )
        sys.exit(1)

    # Configure logging to stderr only — stdout is reserved for MCP protocol
    logging.basicConfig(
        level=logging.WARNING,
        format="%(levelname)s [maverick] %(message)s",
        stream=sys.stderr,
    )
    logger.info("Starting Maverick MCP server (stdio mode)")

    asyncio.run(run_stdio())


def cmd_assess(_args: argparse.Namespace) -> None:
    """Run the behavioral assessment interactively in the terminal."""
    print("Let me get to know how you work.\n")
    print("10 quick questions — pick A or B, whichever feels more natural.\n")

    answers: dict[int, str] = {}

    for q in QUESTIONS:
        print(f"Q{q.id}: {q.text}")
        print(f"  A) {q.choice_a}")
        print(f"  B) {q.choice_b}")

        while True:
            choice = input("  > ").strip().lower()
            if choice in ("a", "b"):
                answers[q.id] = choice
                break
            print("  Pick A or B.")
        print()

    profile = score_assessment(answers)
    print(f"You're a {profile.name}.")
    print(f"{profile.style}")
    print(f"Role: {profile.role.value}")
    print(f"Population: {profile.population_pct}%")
    print()
    print(f"Adaptation: {profile.adaptation.prompt_injection}")


def cmd_profile(_args: argparse.Namespace) -> None:
    """Show the current saved profile."""
    saved = _load_profile()
    if saved is None:
        print("No profile saved. Run `maverick assess` first.")
        return

    print(f"Profile: {saved['profile_name']}")
    print(f"Role: {saved['role']}")
    print(f"Drives: D:{saved['drives']['dominance']} E:{saved['drives']['extraversion']} "
          f"C:{saved['drives']['patience']} F:{saved['drives']['formality']}")


def cmd_card(args: argparse.Namespace) -> None:
    """Generate a shareable Developer Card."""
    profile_id = args.profile_id if hasattr(args, "profile_id") else None
    saved = _load_profile()

    if profile_id:
        result = generate_card(profile_id=profile_id)
    elif saved:
        result = generate_card(saved_data=saved)
    else:
        print("No profile saved. Run `maverick assess` first.")
        return

    if result["status"] == "ok":
        print(f"Developer Card: {result['name']}")
        print(f"Saved to: {result['path']}")
        print()
        print("Open it in your browser. Screenshot it. Share it.")
        # Auto-open in browser
        import webbrowser
        webbrowser.open(f"file://{result['path']}")
    else:
        print(result.get("message", "Failed to generate card."))


def cmd_reset(_args: argparse.Namespace) -> None:
    """Clear saved profile."""
    if PROFILE_PATH.exists():
        PROFILE_PATH.unlink()
        print("Profile cleared.")
    else:
        print("No profile to clear.")


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="maverick",
        description="Every Goose needs its Maverick. Behavioral intelligence for AI agents.",
    )
    sub = parser.add_subparsers(dest="command")

    serve_p = sub.add_parser("serve", help="Start MCP server")
    serve_p.add_argument("--port", type=int, default=None, help="SSE port (default: stdio)")

    sub.add_parser("assess", help="Run behavioral assessment")
    sub.add_parser("profile", help="Show current profile")

    card_p = sub.add_parser("card", help="Generate shareable Developer Card")
    card_p.add_argument("profile_id", nargs="?", default=None, help="Profile ID (default: saved profile)")

    sub.add_parser("reset", help="Clear saved profile")

    args = parser.parse_args()

    commands = {
        "serve": cmd_serve,
        "assess": cmd_assess,
        "profile": cmd_profile,
        "card": cmd_card,
        "reset": cmd_reset,
    }

    handler = commands.get(args.command)
    if handler is None:
        parser.print_help()
        sys.exit(1)

    handler(args)


if __name__ == "__main__":
    main()
