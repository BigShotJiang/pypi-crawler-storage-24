# maverick-mcp

**Every Goose needs its Maverick.**

A behavioral intelligence MCP server that makes AI agents adapt to *who* they're working with — not just what they're asked to do.

Built for [Goose](https://github.com/block/goose). Works with any MCP-compatible agent.

---

## What it does

Maverick observes how you interact with your AI agent and adapts the agent's behavior to match your style:

- **Fast movers** get short, decisive responses with maximum autonomy
- **Methodical thinkers** get thorough explanations with verification checkpoints
- **Team players** get collaborative framing with alignment checks
- **Detail-oriented builders** get precise, evidence-backed responses with process gates

Same model underneath. Different teammate on top.

## How it works

```
┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│    You        │────▶│  Maverick    │────▶│    Goose     │
│  (developer)  │     │  (MCP server)│     │  (AI agent)  │
└──────────────┘     └──────────────┘     └──────────────┘
                      │ Detects your  │
                      │ behavioral    │
                      │ profile from  │
                      │ interaction   │
                      │ patterns      │
                      │               │
                      │ Injects       │
                      │ adaptation    │
                      │ context into  │
                      │ agent prompts │
                      └───────────────┘
```

1. **First use:** Quick 2-minute behavioral assessment (10 questions) or skip and let Maverick infer from your interactions
2. **Profile detection:** Maps you to one of 17 behavioral profiles based on four drives: Dominance, Extraversion, Patience, Formality
3. **Adaptation:** Injects behavioral context into the agent's system prompt — adjusting tone, pacing, autonomy level, and decision style
4. **Learning:** Refines your profile over time based on what you accept, reject, and how you interact

## Quick start

```bash
# Install
pip install maverick-mcp

# Run the MCP server
maverick serve

# Or with uvx (no install needed)
uvx maverick-mcp serve
```

### Connect to Goose

Add to your Goose configuration:

```yaml
extensions:
  maverick:
    type: stdio
    cmd: maverick
    args: [serve]
```

Or if running as a standalone server:

```yaml
extensions:
  maverick:
    type: sse
    uri: http://localhost:8300/sse
```

## MCP Tools

Maverick exposes these tools to the agent:

| Tool | Description |
|------|-------------|
| `maverick_assess` | Run the behavioral assessment (10 questions) |
| `maverick_profile` | Get the current user's behavioral profile |
| `maverick_adapt` | Get adaptation instructions for the current context |
| `maverick_feedback` | Record user feedback to refine the profile |

## The 17 Profiles

Based on [Predictive Index](https://www.predictiveindex.com/) behavioral science, used by 10,000+ companies:

| Profile | Style | Agent Adaptation |
|---------|-------|-----------------|
| **Maverick** | Fast, bold, breaks molds | Short responses, max autonomy, ship dates |
| **Captain** | Commanding, decisive | Executive summaries, clear delegation |
| **Persuader** | Energetic, narrative-driven | Compelling framing, stakeholder angles |
| **Venturer** | Independent, gut-driven | Minimal hand-holding, trust their direction |
| **Strategist** | Analytical, big-picture | Systems thinking, long-range implications |
| **Controller** | Structured, demanding | Precise specs, clear ownership |
| **Promoter** | Social, fast-moving | High energy, visible progress |
| **Adapter** | Balanced, flexible | Moderate everything, read the room |
| **Collaborator** | Team-oriented, supportive | Alignment checks, inclusive language |
| **Individualist** | Self-reliant, focused | Respect their process, don't over-explain |
| **Artisan** | Craftsmanship, patient | Quality focus, tangible outcomes |
| **Guardian** | Thorough, protective | Evidence first, risk assessment, checkpoints |
| **Specialist** | Deep, precise | Domain depth, highest standards |
| **Analyzer** | Methodical, data-driven | Show the data, verify claims |
| **Scholar** | Knowledge-seeking, rigorous | Research backing, source verification |
| **Operator** | Reliable, steady | Clear steps, predictable cadence |
| **Altruist** | Warm, caring | Supportive tone, team-aware framing |

## Data sovereignty

Your behavioral profile is stored **locally on your machine** — never sent to any server. Maverick runs entirely local. No accounts, no telemetry, no cloud.

```
~/.maverick/
├── profile.yaml      # Your behavioral profile
├── interactions.jsonl # Interaction history (for refinement)
└── config.yaml       # Server configuration
```

## Built on

- [Predictive Index](https://www.predictiveindex.com/) behavioral science framework
- [Model Context Protocol](https://modelcontextprotocol.io/) (MCP) for agent integration
- [Airlock](https://doyoulikedags.xyz) behavioral intelligence platform

## The science

The four behavioral drives (DECF):

- **Dominance** — Drive for control and influence over environment
- **Extraversion** — Drive for social interaction and influence over people
- **Patience** — Drive for consistency, stability, and deliberate pace
- **Formality** — Drive for conformity, rules, and structure

Every person has a unique DECF signature. Every AI interaction should respect it.

We've validated this across **7,000+ conversations** using [ConstellationBench](https://doyoulikedags.xyz/research) — a novel persona fidelity benchmark that measures whether AI agents maintain consistent behavioral adaptation.

## Why "Maverick"?

The Maverick is the rarest behavioral profile — 2.5% of the population. Independent innovators who break every mold and bet on the future others can't see.

We named this project after them because that's what's missing from AI agents: the ability to recognize that not everyone thinks the same way, and to adapt accordingly.

Every Goose needs its Maverick.

---

## License

Apache 2.0 — same as Goose.

## Contributing

PRs welcome. See [CONTRIBUTING.md](CONTRIBUTING.md).

Built by [Airlock](https://doyoulikedags.xyz) — the AI that knows who it's talking to.
