"""Tests for the Developer Card generator."""

from __future__ import annotations

from pathlib import Path

import pytest

from maverick_mcp.card import (
    PROFILE_DETAILS,
    generate_card,
    generate_card_html,
)
from maverick_mcp.profiles import PROFILES, BehavioralRole, Drives


class TestProfileDetails:
    """Every profile must have card details."""

    def test_all_profiles_have_details(self) -> None:
        for profile_id in PROFILES:
            assert profile_id in PROFILE_DETAILS, f"Missing card details for {profile_id}"

    def test_details_have_required_fields(self) -> None:
        required = {"tagline", "strengths", "blind_spots", "pair_with", "energy"}
        for profile_id, details in PROFILE_DETAILS.items():
            for field in required:
                assert field in details, f"{profile_id} missing '{field}'"

    def test_strengths_are_nonempty(self) -> None:
        for profile_id, details in PROFILE_DETAILS.items():
            assert len(details["strengths"]) >= 3, f"{profile_id} needs at least 3 strengths"

    def test_blind_spots_are_nonempty(self) -> None:
        for profile_id, details in PROFILE_DETAILS.items():
            assert len(details["blind_spots"]) >= 2, f"{profile_id} needs at least 2 blind spots"

    def test_pair_with_is_valid_profile(self) -> None:
        valid_names = {p.name for p in PROFILES.values()}
        for profile_id, details in PROFILE_DETAILS.items():
            assert details["pair_with"] in valid_names, (
                f"{profile_id} pair_with '{details['pair_with']}' is not a valid profile name"
            )


class TestGenerateCardHtml:
    """Test HTML card generation."""

    def test_generates_valid_html(self) -> None:
        profile = PROFILES["maverick"]
        html = generate_card_html(profile, profile.drives)
        assert "<!DOCTYPE html>" in html
        assert "</html>" in html

    def test_contains_profile_name(self) -> None:
        profile = PROFILES["guardian"]
        html = generate_card_html(profile, profile.drives)
        assert "Guardian" in html

    def test_contains_drive_values(self) -> None:
        drives = Drives(8, 6, 3, 7)
        profile = PROFILES["controller"]
        html = generate_card_html(profile, drives)
        assert 'style="width: 80%"' in html  # D=8 → 80%
        assert 'style="width: 60%"' in html  # E=6 → 60%
        assert 'style="width: 30%"' in html  # C=3 → 30%
        assert 'style="width: 70%"' in html  # F=7 → 70%

    def test_contains_role_badge(self) -> None:
        profile = PROFILES["maverick"]
        html = generate_card_html(profile, profile.drives)
        assert "EXPANDER" in html

    def test_contains_strengths(self) -> None:
        profile = PROFILES["maverick"]
        html = generate_card_html(profile, profile.drives)
        assert "Speed to ship" in html
        assert "Bias to action" in html

    def test_contains_blind_spots(self) -> None:
        profile = PROFILES["guardian"]
        html = generate_card_html(profile, profile.drives)
        assert "Can block progress" in html

    def test_contains_pair_recommendation(self) -> None:
        profile = PROFILES["maverick"]
        html = generate_card_html(profile, profile.drives)
        assert "Guardian" in html

    def test_contains_airlock_branding(self) -> None:
        profile = PROFILES["adapter"]
        html = generate_card_html(profile, profile.drives)
        assert "Airlock" in html
        assert "doyoulikedags.xyz" in html

    def test_contains_adaptation_text(self) -> None:
        profile = PROFILES["analyzer"]
        html = generate_card_html(profile, profile.drives)
        assert "data, not instinct" in html

    @pytest.mark.parametrize("role,color", [
        (BehavioralRole.EXPANDER, "#00FF88"),
        (BehavioralRole.CONVERTER, "#7B61FF"),
        (BehavioralRole.STABILIZER, "#00B4D8"),
    ])
    def test_role_colors(self, role: BehavioralRole, color: str) -> None:
        # Find a profile with this role
        profile = next(p for p in PROFILES.values() if p.role == role)
        html = generate_card_html(profile, profile.drives)
        assert color in html

    def test_all_17_profiles_generate(self) -> None:
        """Every profile must generate a valid card without errors."""
        for profile_id, profile in PROFILES.items():
            html = generate_card_html(profile, profile.drives)
            assert profile.name in html
            assert len(html) > 1000, f"{profile_id} card is suspiciously short"


class TestGenerateCard:
    """Test the card generation entry point."""

    def test_no_profile_returns_error(self) -> None:
        result = generate_card()
        assert result["status"] == "no_profile"

    def test_invalid_profile_id(self) -> None:
        result = generate_card(profile_id="nonexistent")
        assert result["status"] == "error"

    def test_generate_by_profile_id(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setattr("maverick_mcp.card.Path.home", lambda: tmp_path)
        result = generate_card(profile_id="maverick")
        assert result["status"] == "ok"
        assert result["name"] == "Maverick"
        assert "html" in result
        assert (tmp_path / ".maverick" / "card.html").exists()

    def test_generate_from_saved_data(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setattr("maverick_mcp.card.Path.home", lambda: tmp_path)
        saved = {
            "profile_id": "guardian",
            "drives": {"dominance": 3, "extraversion": 3, "patience": 9, "formality": 8},
        }
        result = generate_card(saved_data=saved)
        assert result["status"] == "ok"
        assert result["name"] == "Guardian"
        card_html = (tmp_path / ".maverick" / "card.html").read_text()
        assert "Guardian" in card_html
        assert "Nothing ships dirty" in card_html

    def test_card_file_is_valid_html(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setattr("maverick_mcp.card.Path.home", lambda: tmp_path)
        result = generate_card(profile_id="persuader")
        card_html = (tmp_path / ".maverick" / "card.html").read_text()
        assert card_html.startswith("<!DOCTYPE html>")
        assert card_html.endswith("</html>")
