"""Tests for maverick_mcp.profiles — behavioral profile matching and drive scoring.

Pure function tests with no mocking needed.
"""
import pytest

from maverick_mcp.profiles import (
    PROFILES,
    BehavioralRole,
    Drives,
    Profile,
    get_profile,
    match_profile,
)


# ---------------------------------------------------------------------------
# Drives dataclass
# ---------------------------------------------------------------------------

class TestDrives:
    def test_creation(self):
        d = Drives(dominance=8, extraversion=6, patience=3, formality=4)
        assert d.dominance == 8
        assert d.extraversion == 6
        assert d.patience == 3
        assert d.formality == 4

    def test_frozen(self):
        d = Drives(5, 5, 5, 5)
        with pytest.raises(AttributeError):
            d.dominance = 10  # type: ignore[misc]

    def test_expander_score_high_dominance(self):
        """High D, high E, low C, low F should produce a high expander score."""
        d = Drives(10, 8, 1, 1)
        assert d.expander_score > d.stabilizer_score
        assert d.primary_role == BehavioralRole.EXPANDER

    def test_stabilizer_score_high_patience(self):
        """Low D, low E, high C, high F should produce a high stabilizer score."""
        d = Drives(2, 2, 9, 10)
        assert d.stabilizer_score > d.expander_score
        assert d.primary_role == BehavioralRole.STABILIZER

    def test_converter_score_balanced(self):
        """Balanced drives (all ~5) should produce a high converter score."""
        d = Drives(5, 5, 5, 5)
        assert d.converter_score >= d.expander_score
        assert d.converter_score >= d.stabilizer_score
        assert d.primary_role == BehavioralRole.CONVERTER

    def test_expander_score_formula(self):
        """Verify the expander formula: (D*1.5) + E - (C*0.8) - (F*0.3)."""
        d = Drives(10, 8, 1, 1)
        expected = (10 * 1.5) + 8 - (1 * 0.8) - (1 * 0.3)
        assert d.expander_score == pytest.approx(expected)

    def test_stabilizer_score_formula(self):
        """Verify the stabilizer formula: (C*1.5) + F - (D*0.8) - (E*0.3)."""
        d = Drives(2, 2, 9, 10)
        expected = (9 * 1.5) + 10 - (2 * 0.8) - (2 * 0.3)
        assert d.stabilizer_score == pytest.approx(expected)


# ---------------------------------------------------------------------------
# Profile registry
# ---------------------------------------------------------------------------

class TestProfileRegistry:
    def test_all_17_profiles_exist(self):
        assert len(PROFILES) == 17

    def test_known_profile_ids(self):
        expected = {
            "maverick", "captain", "guardian", "adapter", "strategist",
            "venturer", "persuader", "collaborator", "analyzer", "specialist",
            "scholar", "controller", "promoter", "individualist", "operator",
            "artisan", "altruist",
        }
        assert set(PROFILES.keys()) == expected

    def test_all_profiles_have_drives(self):
        for profile_id, profile in PROFILES.items():
            assert isinstance(profile.drives, Drives), f"{profile_id} missing Drives"
            assert 1 <= profile.drives.dominance <= 10
            assert 1 <= profile.drives.extraversion <= 10
            assert 1 <= profile.drives.patience <= 10
            assert 1 <= profile.drives.formality <= 10

    def test_all_profiles_have_adaptation(self):
        for profile_id, profile in PROFILES.items():
            assert profile.adaptation.response_length in ("short", "moderate", "detailed")
            assert profile.adaptation.tone in ("direct", "collaborative", "supportive", "precise")
            assert profile.adaptation.prompt_injection, f"{profile_id} missing prompt_injection"

    def test_population_percentages_sum(self):
        """Population percentages should sum to a reasonable total."""
        total = sum(p.population_pct for p in PROFILES.values())
        # Should be in a reasonable range (they won't sum to exactly 100)
        assert 50 < total < 120

    def test_all_roles_represented(self):
        roles = {p.role for p in PROFILES.values()}
        assert BehavioralRole.EXPANDER in roles
        assert BehavioralRole.CONVERTER in roles
        assert BehavioralRole.STABILIZER in roles


# ---------------------------------------------------------------------------
# get_profile
# ---------------------------------------------------------------------------

class TestGetProfile:
    def test_get_existing_profile(self):
        profile = get_profile("maverick")
        assert profile is not None
        assert profile.name == "Maverick"

    def test_get_profile_case_insensitive(self):
        profile = get_profile("MAVERICK")
        assert profile is not None
        assert profile.id == "maverick"

    def test_get_nonexistent_profile(self):
        assert get_profile("nonexistent") is None

    def test_get_each_profile(self):
        for profile_id in PROFILES:
            profile = get_profile(profile_id)
            assert profile is not None
            assert profile.id == profile_id


# ---------------------------------------------------------------------------
# match_profile
# ---------------------------------------------------------------------------

class TestMatchProfile:
    def test_exact_match_maverick(self):
        """Maverick drives should match Maverick profile."""
        drives = Drives(10, 8, 1, 1)
        profile = match_profile(drives)
        assert profile.id == "maverick"

    def test_exact_match_guardian(self):
        """Guardian drives should match Guardian profile."""
        drives = Drives(3, 3, 9, 8)
        profile = match_profile(drives)
        assert profile.id == "guardian"

    def test_exact_match_adapter(self):
        """Balanced drives should match Adapter profile."""
        drives = Drives(5, 5, 5, 5)
        profile = match_profile(drives)
        assert profile.id == "adapter"

    def test_exact_match_specialist(self):
        drives = Drives(2, 2, 9, 10)
        profile = match_profile(drives)
        assert profile.id == "specialist"

    def test_close_match_still_returns_nearest(self):
        """Slightly off drives should still return the nearest profile."""
        # Close to Maverick (10, 8, 1, 1) but slightly different
        drives = Drives(9, 7, 2, 1)
        profile = match_profile(drives)
        # Should be Maverick or Captain (both are close)
        assert profile.id in ("maverick", "captain")

    def test_returns_profile_instance(self):
        drives = Drives(5, 5, 5, 5)
        profile = match_profile(drives)
        assert isinstance(profile, Profile)
        assert profile.id in PROFILES

    def test_euclidean_distance_prefers_closer(self):
        """The match should prefer the profile with smaller Euclidean distance."""
        # These drives are exactly Captain (9, 8, 2, 2)
        drives = Drives(9, 8, 2, 2)
        profile = match_profile(drives)
        assert profile.id == "captain"
