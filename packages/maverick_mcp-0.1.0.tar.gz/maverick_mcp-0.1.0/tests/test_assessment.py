"""Tests for maverick_mcp.assessment — behavioral assessment scoring.

Pure function tests validating question structure, score calculation,
and profile matching from assessment answers.
"""
import pytest

from maverick_mcp.assessment import QUESTIONS, Question, score_assessment
from maverick_mcp.profiles import Drives, Profile, PROFILES


# ---------------------------------------------------------------------------
# Question structure
# ---------------------------------------------------------------------------

class TestQuestions:
    def test_ten_questions(self):
        assert len(QUESTIONS) == 10

    def test_sequential_ids(self):
        ids = [q.id for q in QUESTIONS]
        assert ids == list(range(1, 11))

    def test_all_questions_have_two_choices(self):
        for q in QUESTIONS:
            assert q.choice_a, f"Question {q.id} missing choice_a"
            assert q.choice_b, f"Question {q.id} missing choice_b"

    def test_all_questions_have_adjustments(self):
        for q in QUESTIONS:
            assert q.a_adjusts, f"Question {q.id} missing a_adjusts"
            assert q.b_adjusts, f"Question {q.id} missing b_adjusts"

    def test_adjustments_use_valid_drive_keys(self):
        valid_keys = {"D", "E", "C", "F"}
        for q in QUESTIONS:
            for key in q.a_adjusts:
                assert key in valid_keys, f"Question {q.id} a_adjusts has invalid key: {key}"
            for key in q.b_adjusts:
                assert key in valid_keys, f"Question {q.id} b_adjusts has invalid key: {key}"

    def test_question_text_is_nonempty(self):
        for q in QUESTIONS:
            assert len(q.text) > 10, f"Question {q.id} text too short"


# ---------------------------------------------------------------------------
# score_assessment
# ---------------------------------------------------------------------------

class TestScoreAssessment:
    def test_all_a_answers_produce_expander(self):
        """Answering all A (action-oriented) should produce an expander profile."""
        answers = {q.id: "a" for q in QUESTIONS}
        profile = score_assessment(answers)
        assert isinstance(profile, Profile)
        # All-A should push toward high D, high E, low C, low F
        # This should be an expander profile
        assert profile.id in PROFILES

    def test_all_b_answers_produce_stabilizer(self):
        """Answering all B (methodical) should produce a stabilizer profile."""
        answers = {q.id: "b" for q in QUESTIONS}
        profile = score_assessment(answers)
        assert isinstance(profile, Profile)
        assert profile.id in PROFILES

    def test_empty_answers_return_balanced(self):
        """No answers should return neutral (5,5,5,5) -> Adapter."""
        profile = score_assessment({})
        assert profile.id == "adapter"

    def test_partial_answers(self):
        """Only answering some questions should still return a valid profile."""
        answers = {1: "a", 2: "b"}
        profile = score_assessment(answers)
        assert isinstance(profile, Profile)
        assert profile.id in PROFILES

    def test_scores_clamped_to_range(self):
        """Drive scores should stay within 1-10 even with extreme answers."""
        # All A answers push D up aggressively
        answers = {q.id: "a" for q in QUESTIONS}
        profile = score_assessment(answers)
        # Profile is valid, meaning the clamping worked
        assert 1 <= profile.drives.dominance <= 10
        assert 1 <= profile.drives.extraversion <= 10
        assert 1 <= profile.drives.patience <= 10
        assert 1 <= profile.drives.formality <= 10

    def test_mixed_answers_produce_valid_profile(self):
        """A realistic mixed answer set should produce a valid profile."""
        answers = {
            1: "a",   # Jump in
            2: "b",   # Gather evidence
            3: "a",   # Ships the feature
            4: "a",   # Drive the keyboard
            5: "a",   # Cut scope
            6: "a",   # Quick messages
            7: "a",   # Trust intuition
            8: "a",   # Speak up first
            9: "a",   # Build something
            10: "a",  # Frustrated by process
        }
        profile = score_assessment(answers)
        # This is a very action-oriented set — should map to a high-D, high-E profile
        assert profile.id in PROFILES

    def test_methodical_answers(self):
        """All methodical answers should map to a stabilizer profile."""
        answers = {
            1: "b",   # Plan thoroughly
            2: "b",   # Gather evidence
            3: "b",   # Patterns and edge cases
            4: "b",   # Navigate and observe
            5: "b",   # Push back on deadline
            6: "b",   # Written docs
            7: "b",   # Systematic trace
            8: "b",   # Listen first
            9: "b",   # Read the docs
            10: "b",  # Frustrated by shipping unready
        }
        profile = score_assessment(answers)
        # Should be a stabilizer-type profile (high C, high F)
        assert profile.role.value == "stabilizer"

    def test_invalid_question_ids_ignored(self):
        """Question IDs not in the set should be harmlessly ignored."""
        answers = {1: "a", 99: "a", 100: "b"}
        profile = score_assessment(answers)
        assert isinstance(profile, Profile)

    def test_deterministic(self):
        """Same answers should always produce the same profile."""
        answers = {1: "a", 2: "b", 3: "a", 4: "b", 5: "a"}
        p1 = score_assessment(answers)
        p2 = score_assessment(answers)
        assert p1.id == p2.id


# ---------------------------------------------------------------------------
# Drive adjustment math
# ---------------------------------------------------------------------------

class TestDriveAdjustments:
    def test_single_question_adjustment(self):
        """Answering one question should shift drives from neutral."""
        # Question 1 A: D+2, C-1
        answers = {1: "a"}
        profile = score_assessment(answers)
        # Starting from 5,5,5,5 => D=7, C=4 (shifted)
        # The matched profile should reflect higher D
        assert isinstance(profile, Profile)

    def test_opposing_adjustments_cancel(self):
        """If two questions adjust the same drive in opposite directions, they partly cancel."""
        # This is implicit in the scoring — just verify it produces valid output
        answers = {1: "a", 5: "b"}  # Q1 pushes D up, Q5b pushes C up
        profile = score_assessment(answers)
        assert isinstance(profile, Profile)
