"""Settings GUI — tkinter tabbed editor launched from tray menu."""

import logging
import tkinter as tk
from tkinter import messagebox, ttk

logger = logging.getLogger(__name__)


class _Tooltip:
    """Hover tooltip for tkinter widgets."""

    def __init__(self, widget: tk.Widget, text: str) -> None:
        self._widget = widget
        self._text = text
        self._tipwindow: tk.Toplevel | None = None
        widget.bind("<Enter>", self._show)
        widget.bind("<Leave>", self._hide)

    def _show(self, _event=None) -> None:
        if self._tipwindow:
            return
        x = self._widget.winfo_rootx() + 20
        y = self._widget.winfo_rooty() + self._widget.winfo_height() + 4
        tw = tk.Toplevel(self._widget)
        tw.wm_overrideredirect(True)
        tw.wm_geometry(f"+{x}+{y}")
        from getinvoke.theme import FONT_FAMILY, SURFACE, TEXT

        tk.Label(
            tw,
            text=self._text,
            justify="left",
            background=SURFACE,
            foreground=TEXT,
            relief="solid",
            borderwidth=1,
            font=(FONT_FAMILY, 9),
            padx=8,
            pady=4,
            wraplength=300,
        ).pack()
        self._tipwindow = tw

    def _hide(self, _event=None) -> None:
        if self._tipwindow:
            self._tipwindow.destroy()
            self._tipwindow = None


def open_settings(on_save: callable = None) -> None:
    """Open the settings window. Non-blocking (runs in own thread)."""
    import platform
    import threading

    def _run() -> None:
        try:
            # On Windows, prevent the console from stealing focus when tkinter starts
            if platform.system() == "Windows":
                try:
                    import ctypes

                    ctypes.windll.user32.SetForegroundWindow(0)
                except Exception:
                    pass
            app = SettingsWindow(on_save=on_save)
            app.mainloop()
        except Exception as e:
            logger.error(f"Settings GUI error: {e}")

    threading.Thread(target=_run, daemon=True).start()


class SettingsWindow(tk.Tk):
    """Tabbed settings editor."""

    def __init__(self, on_save: callable = None) -> None:
        super().__init__()
        self.attributes("-alpha", 0)  # Fully transparent while building
        self.withdraw()  # Also withdraw to prevent white flash
        self._on_save = on_save
        self.title("Invoke Settings")
        self.geometry("540x560")
        self.resizable(False, False)
        # Center
        self.update_idletasks()
        x = (self.winfo_screenwidth() - 540) // 2
        y = (self.winfo_screenheight() - 560) // 2
        self.geometry(f"+{x}+{y}")

        # Apply Patina theme
        from getinvoke.theme import apply_theme

        apply_theme(self)

        # Use the live singleton — already running correctly, no slow re-init
        from getinvoke.config import settings as live_settings

        self._live = live_settings

        # Snapshot values that require restart, so we can warn on save
        self._initial_hotkey = live_settings.HOTKEY
        self._initial_whisper_model = live_settings.WHISPER_MODEL
        self._initial_whisper_device = live_settings._whisper_device_setting
        self._initial_audio_device = live_settings.AUDIO_DEVICE or ""
        self._initial_image_hotkey = live_settings.IMAGE_HOTKEY
        self._initial_image_enabled = live_settings.IMAGE_CAPTURE_ENABLED

        # Notebook (tabs)
        notebook = ttk.Notebook(self)
        notebook.pack(fill="both", expand=True, padx=12, pady=(12, 0))

        self._build_general_tab(notebook)
        self._build_transcription_tab(notebook)
        self._build_reformatter_tab(notebook)
        self._build_history_tab(notebook)
        self._build_advanced_tab(notebook)
        self._build_license_tab(notebook)

        # Bottom buttons
        btn_frame = ttk.Frame(self)
        btn_frame.pack(fill="x", padx=12, pady=12)
        ttk.Button(btn_frame, text="Cancel", command=self.destroy).pack(side="right", padx=(8, 0))
        ttk.Button(btn_frame, text="Save", command=self._save, style="Gold.TButton").pack(side="right")

        self.deiconify()  # Show now that all widgets are styled
        self.attributes("-alpha", 1.0)  # Fade in after styling complete

    @staticmethod
    def _ensure_in_options(value: str, options: list[str]) -> list[str]:
        """Ensure value is in options list so readonly combos don't show blank."""
        if value and value not in options:
            options = [value] + options
        return options

    def _build_general_tab(self, notebook: ttk.Notebook) -> None:
        tab = ttk.Frame(notebook)
        notebook.add(tab, text="General")

        # Pipeline overview
        ttk.Label(
            tab,
            text="Hold hotkey \u2192 Speak \u2192 Whisper transcribes \u2192 AI formats \u2192 Clipboard",
            foreground="#5FC8C8",
            wraplength=480,
        ).grid(row=0, column=0, columnspan=2, sticky="w", padx=12, pady=(12, 2))
        ttk.Label(
            tab,
            text="Auto-paste can type it at your cursor. AI step can be disabled in AI Processing.",
            foreground="#888888",
        ).grid(row=1, column=0, columnspan=2, sticky="w", padx=12, pady=(0, 8))

        # Mode
        ttk.Label(tab, text="Output Mode:").grid(row=2, column=0, sticky="w", padx=12, pady=4)
        from getinvoke.modes import MODES, list_modes

        mode_names = [m.name for m in list_modes()]
        mode_names = self._ensure_in_options(self._live.MODE, mode_names)
        self._mode_var = tk.StringVar(master=self)
        self._mode_var.set(self._live.MODE)
        self._mode_combo = ttk.Combobox(tab, textvariable=self._mode_var, values=mode_names, state="readonly", width=20)
        self._mode_combo.set(self._live.MODE)
        self._mode_combo.grid(row=2, column=1, sticky="w", padx=12, pady=4)
        self._mode_combo.bind("<<ComboboxSelected>>", lambda _e: self._mode_var.set(self._mode_combo.get()))
        _Tooltip(
            self._mode_combo,
            "How your speech is formatted for your coding tool.\n\n"
            "claude-code, cursor, windsurf, copilot \u2014 structured prompts\n"
            "raw \u2014 clean text, no prompt structure\n"
            "commit, pr \u2014 git-specific formats",
        )

        # Mode description (updates on selection)
        self._mode_desc_var = tk.StringVar(master=self)
        mode_desc_label = ttk.Label(tab, textvariable=self._mode_desc_var, foreground="#888888", wraplength=480)
        mode_desc_label.grid(row=3, column=0, columnspan=2, sticky="w", padx=12, pady=(0, 8))

        def _update_mode_desc(*_args) -> None:
            name = self._mode_var.get()
            mode = MODES.get(name)
            if mode:
                self._mode_desc_var.set(mode.description)
            else:
                self._mode_desc_var.set("")

        self._mode_var.trace_add("write", _update_mode_desc)
        _update_mode_desc()  # Set initial description

        # Voice hotkey
        ttk.Label(tab, text="Voice Hotkey:").grid(row=4, column=0, sticky="w", padx=12, pady=4)
        hotkey_options = ["mouse5", "mouse4", "ctrl+shift+d"]
        self._hotkey_var = tk.StringVar(master=self)
        self._hotkey_var.set(self._live.HOTKEY)
        hotkey_frame = ttk.Frame(tab)
        hotkey_frame.grid(row=4, column=1, sticky="w", padx=12, pady=4)
        self._hotkey_combo = ttk.Combobox(hotkey_frame, textvariable=self._hotkey_var, values=hotkey_options, width=16)
        self._hotkey_combo.set(self._live.HOTKEY)
        self._hotkey_combo.pack(side="left")
        self._hotkey_combo.bind("<<ComboboxSelected>>", lambda _e: self._hotkey_var.set(self._hotkey_combo.get()))
        _Tooltip(
            self._hotkey_combo,
            "Hold this key to record, release to process.\n"
            "Select a preset or type a custom combo (e.g., ctrl+shift+r).\n"
            "mouse4/mouse5 = side mouse buttons.",
        )
        self._record_btn = ttk.Button(hotkey_frame, text="Record...", command=self._record_hotkey, width=8)
        self._record_btn.pack(side="left", padx=(6, 0))
        _Tooltip(self._record_btn, "Click, then press your desired key combo to capture it.")

        # Auto-paste
        self._autopaste_var = tk.BooleanVar(master=self)
        self._autopaste_var.set(self._live.AUTO_PASTE)
        ap_cb = ttk.Checkbutton(tab, text="Auto-paste at cursor", variable=self._autopaste_var)
        ap_cb.grid(row=5, column=0, columnspan=2, sticky="w", padx=12, pady=4)
        _Tooltip(
            ap_cb,
            "Simulates Ctrl+V after copying to clipboard, typing the result at your cursor.\nOn Linux, requires xdotool (sudo apt install xdotool).",
        )

        # Beep feedback
        self._beep_var = tk.BooleanVar(master=self)
        self._beep_var.set(self._live.BEEP_ENABLED)
        beep_cb = ttk.Checkbutton(tab, text="Audio feedback (beeps)", variable=self._beep_var)
        beep_cb.grid(row=6, column=0, columnspan=2, sticky="w", padx=12, pady=4)
        _Tooltip(beep_cb, "Play short sounds when recording starts, stops, succeeds, or fails.")

        # Sound theme (shown when beep is enabled)
        self._sound_theme_label = ttk.Label(tab, text="Sound theme:")
        self._sound_theme_label.grid(row=7, column=0, sticky="w", padx=28, pady=4)
        from getinvoke.feedback import SOUND_PRESETS

        preset_names = list(SOUND_PRESETS.keys())
        self._sound_preset_var = tk.StringVar(master=self)
        self._sound_preset_var.set(self._live.SOUND_PRESET)
        sound_frame = ttk.Frame(tab)
        sound_frame.grid(row=7, column=1, sticky="w", padx=12, pady=4)
        self._sound_theme_combo = ttk.Combobox(
            sound_frame, textvariable=self._sound_preset_var, values=preset_names, state="readonly", width=12
        )
        self._sound_theme_combo.set(self._live.SOUND_PRESET)
        self._sound_theme_combo.pack(side="left")
        # Explicit sync — readonly combos can desync from StringVar in threaded tkinter
        self._sound_theme_combo.bind(
            "<<ComboboxSelected>>", lambda _e: self._sound_preset_var.set(self._sound_theme_combo.get())
        )
        _Tooltip(
            self._sound_theme_combo,
            "default \u2014 original Invoke sounds\n"
            "subtle \u2014 softer, lower tones\n"
            "arcade \u2014 retro game-style chirps\n"
            "minimal \u2014 single short ticks\n"
            "icq \u2014 classic ICQ vibes\n"
            "aim \u2014 AIM buddy list chirps\n"
            "dial-up \u2014 modem handshake tones",
        )
        self._preview_btn = ttk.Button(sound_frame, text="Preview", command=self._preview_sound, width=7)
        self._preview_btn.pack(side="left", padx=(6, 0))
        _Tooltip(self._preview_btn, "Play start \u2192 success \u2192 error sounds for this theme.")

        self._sound_theme_widgets = [self._sound_theme_label, sound_frame]

        def _update_beep_widgets(*_args) -> None:
            for w in self._sound_theme_widgets:
                w.grid() if self._beep_var.get() else w.grid_remove()

        self._beep_var.trace_add("write", _update_beep_widgets)
        _update_beep_widgets()

        # --- Image capture section ---
        self._image_var = tk.BooleanVar(master=self)
        self._image_var.set(self._live.IMAGE_CAPTURE_ENABLED)
        image_cb = ttk.Checkbutton(tab, text="Enable image capture", variable=self._image_var)
        image_cb.grid(row=8, column=0, columnspan=2, sticky="w", padx=12, pady=(12, 4))
        _Tooltip(
            image_cb,
            "Capture clipboard images with a hotkey.\n"
            "Copy any image to clipboard (Win+Shift+S, Print Screen, ShareX, browser right-click, etc.)\n"
            "then press the image hotkey — the saved file path lands on your clipboard.",
        )

        # Image hotkey (hidden when disabled)
        self._image_hotkey_label = ttk.Label(tab, text="Image Hotkey:")
        self._image_hotkey_label.grid(row=9, column=0, sticky="w", padx=28, pady=4)
        image_hotkey_options = ["middle", "mouse4", "ctrl+shift+s"]
        self._image_hotkey_var = tk.StringVar(master=self)
        self._image_hotkey_var.set(self._live.IMAGE_HOTKEY)
        image_hotkey_frame = ttk.Frame(tab)
        image_hotkey_frame.grid(row=9, column=1, sticky="w", padx=12, pady=4)
        self._image_hotkey_combo = ttk.Combobox(
            image_hotkey_frame, textvariable=self._image_hotkey_var, values=image_hotkey_options, width=16
        )
        self._image_hotkey_combo.set(self._live.IMAGE_HOTKEY)
        self._image_hotkey_combo.pack(side="left")
        self._image_hotkey_combo.bind(
            "<<ComboboxSelected>>", lambda _e: self._image_hotkey_var.set(self._image_hotkey_combo.get())
        )
        _Tooltip(self._image_hotkey_combo, "Hotkey to capture clipboard image. Must differ from voice hotkey.")
        self._image_record_btn = ttk.Button(
            image_hotkey_frame, text="Record...", command=self._record_image_hotkey, width=8
        )
        self._image_record_btn.pack(side="left", padx=(6, 0))
        _Tooltip(self._image_record_btn, "Click, then press your desired key combo to capture it.")

        # Save directory
        self._image_dir_label = ttk.Label(tab, text="Save to:")
        self._image_dir_label.grid(row=10, column=0, sticky="w", padx=28, pady=4)
        self._image_dir_var = tk.StringVar(master=self)
        self._image_dir_var.set(self._live.IMAGE_SAVE_DIR)
        image_dir_entry = ttk.Entry(tab, textvariable=self._image_dir_var, width=28)
        image_dir_entry.grid(row=10, column=1, sticky="w", padx=12, pady=4)
        _Tooltip(image_dir_entry, "Directory where captured images are saved as PNGs.")

        self._image_detail_widgets = [
            self._image_hotkey_label,
            image_hotkey_frame,
            self._image_dir_label,
            image_dir_entry,
        ]

        def _update_image_widgets(*_args) -> None:
            for w in self._image_detail_widgets:
                w.grid() if self._image_var.get() else w.grid_remove()

        self._image_var.trace_add("write", _update_image_widgets)
        _update_image_widgets()

        # --- Project directory ---
        ttk.Label(tab, text="Project Directory:").grid(row=11, column=0, sticky="w", padx=12, pady=(16, 4))
        self._project_dir_var = tk.StringVar(master=self)
        self._project_dir_var.set(self._live.PROJECT_DIR)
        project_frame = ttk.Frame(tab)
        project_frame.grid(row=11, column=1, sticky="w", padx=12, pady=(16, 4))
        project_entry = ttk.Entry(project_frame, textvariable=self._project_dir_var, width=22)
        project_entry.pack(side="left")

        def _browse_project() -> None:
            from tkinter import filedialog

            path = filedialog.askdirectory()
            if path:
                self._project_dir_var.set(path)

        ttk.Button(project_frame, text="Browse...", command=_browse_project, width=8).pack(side="left", padx=(6, 0))
        _Tooltip(
            project_entry,
            "Your project/repo directory. Auto-detected when blank.\n"
            "Set this if Invoke isn't finding your project context.",
        )
        ttk.Label(
            tab,
            text="Leave blank for auto-detection. Set if context isn't loading.",
            foreground="#888888",
        ).grid(row=12, column=0, columnspan=2, sticky="w", padx=12, pady=(0, 4))

    def _record_hotkey(self) -> None:
        """Capture a key combo or mouse button by listening for the next input."""
        from pynput import keyboard
        from pynput import mouse as pynput_mouse

        from getinvoke.hotkey import MOUSE_BUTTON_MAP, format_key_combo

        self._record_btn.configure(text="Press...")
        held: set = set()
        _done = [False]
        _button_to_name = {v: k for k, v in MOUSE_BUTTON_MAP.items()}
        _listeners: list = []

        def _finish(combo_str: str | None) -> None:
            if _done[0]:
                return
            _done[0] = True
            for lst in _listeners:
                try:
                    lst.stop()
                except Exception:
                    pass
            if combo_str is not None:
                self.after(0, lambda s=combo_str: self._hotkey_var.set(s))
                self.after(0, lambda s=combo_str: self._hotkey_combo.set(s))
            self.after(0, lambda: self._record_btn.configure(text="Record..."))

        def on_press(key: keyboard.Key | keyboard.KeyCode) -> bool | None:
            if _done[0]:
                return False
            if key == keyboard.Key.esc:
                _finish(None)
                return False
            held.add(key)
            return None

        def on_release(key: keyboard.Key | keyboard.KeyCode) -> None:
            if _done[0] or not held:
                return False
            _finish(format_key_combo(held))
            held.clear()
            return False

        def on_click(x: int, y: int, button: pynput_mouse.Button, pressed: bool) -> None:
            if _done[0] or not pressed:
                return
            name = _button_to_name.get(button)
            if name and name not in ("left", "right"):
                _finish(name)
                return False

        kb_listener = keyboard.Listener(on_press=on_press, on_release=on_release)
        ms_listener = pynput_mouse.Listener(on_click=on_click)
        ms_listener.daemon = True
        _listeners.extend([kb_listener, ms_listener])
        kb_listener.start()
        ms_listener.start()

        def _timeout() -> None:
            _finish(None)

        self.after(5000, _timeout)

    def _record_image_hotkey(self) -> None:
        """Capture a key combo or mouse button for the image hotkey."""
        from pynput import keyboard
        from pynput import mouse as pynput_mouse

        from getinvoke.hotkey import MOUSE_BUTTON_MAP, format_key_combo

        self._image_record_btn.configure(text="Press...")
        held: set = set()
        _done = [False]
        _button_to_name = {v: k for k, v in MOUSE_BUTTON_MAP.items()}
        _listeners: list = []

        def _finish(combo_str: str | None) -> None:
            if _done[0]:
                return
            _done[0] = True
            for lst in _listeners:
                try:
                    lst.stop()
                except Exception:
                    pass
            if combo_str is not None:
                self.after(0, lambda s=combo_str: self._image_hotkey_var.set(s))
                self.after(0, lambda s=combo_str: self._image_hotkey_combo.set(s))
            self.after(0, lambda: self._image_record_btn.configure(text="Record..."))

        def on_press(key: keyboard.Key | keyboard.KeyCode) -> bool | None:
            if _done[0]:
                return False
            if key == keyboard.Key.esc:
                _finish(None)
                return False
            held.add(key)
            return None

        def on_release(key: keyboard.Key | keyboard.KeyCode) -> None:
            if _done[0] or not held:
                return False
            _finish(format_key_combo(held))
            held.clear()
            return False

        def on_click(x: int, y: int, button: pynput_mouse.Button, pressed: bool) -> None:
            if _done[0] or not pressed:
                return
            name = _button_to_name.get(button)
            if name and name not in ("left", "right"):
                _finish(name)
                return False

        kb_listener = keyboard.Listener(on_press=on_press, on_release=on_release)
        ms_listener = pynput_mouse.Listener(on_click=on_click)
        ms_listener.daemon = True
        _listeners.extend([kb_listener, ms_listener])
        kb_listener.start()
        ms_listener.start()

        def _timeout() -> None:
            _finish(None)

        self.after(5000, _timeout)

    def _preview_sound(self) -> None:
        """Play the selected sound preset's start → success → error sequence."""
        from getinvoke.feedback import preview_preset

        # Read directly from the combo widget — StringVar can desync in threaded tkinter
        preset_name = self._sound_theme_combo.get()
        logger.debug(f"Previewing sound preset: {preset_name}")
        preview_preset(preset_name)

    def _load_ollama_models(self) -> None:
        """Query Ollama API for installed models and populate the combo."""
        import threading

        # Read URL and current model on UI thread before spawning background work
        url = self._ollama_url_var.get().rstrip("/")
        current_model = self._ollama_model_combo.get() or self._live.OLLAMA_MODEL

        def _fetch() -> None:
            try:
                import httpx

                response = httpx.get(f"{url}/api/tags", timeout=5.0)
                response.raise_for_status()
                data = response.json()
                models = [m["name"] for m in data.get("models", [])]
                models.sort()
            except Exception as e:
                logger.debug(f"Failed to query Ollama models: {e}")
                models = []

            if models:
                # Ensure current model is in the list (use value captured on UI thread)
                if current_model and current_model not in models:
                    models.insert(0, current_model)
                self.after(0, lambda: self._populate_ollama_models(models))

        threading.Thread(target=_fetch, daemon=True).start()

    def _populate_ollama_models(self, models: list[str]) -> None:
        """Populate Ollama model combo on UI thread."""
        try:
            # Preserve whatever the user has typed/selected
            current = self._ollama_model_combo.get() or self._ollama_model_var.get()
            self._ollama_model_combo.configure(values=models)
            # Always restore — configure(values=) can clear text on some tk versions
            self._ollama_model_combo.set(current)
            self._ollama_model_var.set(current)
        except tk.TclError:
            pass  # Window closed

    def _load_lmstudio_models(self) -> None:
        """Query LM Studio API for loaded models and populate the combo."""
        import threading

        url = self._lmstudio_url_var.get().rstrip("/")
        current_model = self._lmstudio_model_combo.get() or self._live.LMSTUDIO_MODEL

        def _fetch() -> None:
            try:
                import httpx

                response = httpx.get(f"{url}/v1/models", timeout=5.0)
                response.raise_for_status()
                data = response.json()
                models = [m["id"] for m in data.get("data", [])]
                models.sort()
            except Exception as e:
                logger.debug(f"Failed to query LM Studio models: {e}")
                models = []

            if models:
                if current_model and current_model not in models:
                    models.insert(0, current_model)
                self.after(0, lambda: self._populate_lmstudio_models(models))

        threading.Thread(target=_fetch, daemon=True).start()

    def _populate_lmstudio_models(self, models: list[str]) -> None:
        """Populate LM Studio model combo on UI thread."""
        try:
            current = self._lmstudio_model_combo.get() or self._lmstudio_model_var.get()
            self._lmstudio_model_combo.configure(values=models)
            self._lmstudio_model_combo.set(current)
            self._lmstudio_model_var.set(current)
        except tk.TclError:
            pass  # Window closed

    def _build_transcription_tab(self, notebook: ttk.Notebook) -> None:
        tab = ttk.Frame(notebook)
        notebook.add(tab, text="Transcription")

        ttk.Label(
            tab,
            text="Whisper runs locally on your machine — no audio leaves your computer.",
            foreground="#888888",
            wraplength=480,
        ).grid(row=0, column=0, columnspan=2, sticky="w", padx=12, pady=(12, 8))

        # Whisper model
        ttk.Label(tab, text="Whisper Model:").grid(row=1, column=0, sticky="w", padx=12, pady=4)
        model_options = ["distil-large-v3", "large-v3", "medium", "small", "base", "tiny"]
        self._model_var = tk.StringVar(master=self)
        self._model_var.set(self._live.WHISPER_MODEL)
        self._model_combo = ttk.Combobox(tab, textvariable=self._model_var, values=model_options, width=20)
        self._model_combo.set(self._live.WHISPER_MODEL)
        self._model_combo.grid(row=1, column=1, sticky="w", padx=12, pady=4)
        self._model_combo.bind("<<ComboboxSelected>>", lambda _e: self._model_var.set(self._model_combo.get()))
        _Tooltip(
            self._model_combo,
            "distil-large-v3 \u2014 best accuracy/speed balance (recommended)\n"
            "large-v3 \u2014 most accurate, slower\n"
            "medium/small \u2014 lighter, less accurate\n"
            "tiny/base \u2014 fastest, lowest accuracy",
        )

        # Compute device — use raw setting so "auto" survives save cycles
        ttk.Label(tab, text="Compute Device:").grid(row=2, column=0, sticky="w", padx=12, pady=4)
        raw_device = self._live._whisper_device_setting
        import platform as _plat

        device_list = ["auto", "cuda", "cpu"]
        if _plat.system() == "Darwin":
            device_list.insert(1, "mlx")
        device_options = self._ensure_in_options(raw_device, device_list)
        self._device_var = tk.StringVar(master=self)
        self._device_var.set(raw_device)
        self._device_combo = ttk.Combobox(
            tab, textvariable=self._device_var, values=device_options, state="readonly", width=20
        )
        self._device_combo.set(raw_device)
        self._device_combo.grid(row=2, column=1, sticky="w", padx=12, pady=4)
        self._device_combo.bind("<<ComboboxSelected>>", lambda _e: self._device_var.set(self._device_combo.get()))
        _Tooltip(
            self._device_combo,
            "auto \u2014 detects GPU automatically (recommended)\n"
            "cuda \u2014 force GPU (NVIDIA + CUDA required)\n"
            "cpu \u2014 force CPU (slower but always works)",
        )

        # Audio device (loaded async to avoid blocking UI)
        ttk.Label(tab, text="Microphone:").grid(row=3, column=0, sticky="w", padx=12, pady=4)
        self._audio_var = tk.StringVar(master=self, value="Loading...")
        self._audio_combo = ttk.Combobox(
            tab, textvariable=self._audio_var, values=["Loading..."], state="readonly", width=35
        )
        self._audio_combo.set("Loading...")
        self._audio_combo.grid(row=3, column=1, sticky="w", padx=12, pady=4)
        self._audio_combo.bind("<<ComboboxSelected>>", lambda _e: self._audio_var.set(self._audio_combo.get()))
        _Tooltip(self._audio_combo, "Select your microphone. 'default' uses your system's default input device.")

        import threading

        def _load_devices():
            try:
                from getinvoke.recorder import list_devices

                devices = list_devices()
            except Exception as e:
                logger.warning(f"Failed to list audio devices: {e}")
                devices = []
            device_names = ["default"] + [f"[{d['index']}] {d['name']}" for d in devices]
            current = f"[{self._live.AUDIO_DEVICE}]" if self._live.AUDIO_DEVICE else "default"
            audio_val = "default"
            for name in device_names:
                if current in name:
                    audio_val = name
                    break
            self.after(0, lambda: self._populate_audio_combo(device_names, audio_val))

        threading.Thread(target=_load_devices, daemon=True).start()

        # Language
        ttk.Label(tab, text="Language:").grid(row=4, column=0, sticky="w", padx=12, pady=4)
        lang_options = ["en", "auto", "es", "fr", "de", "zh", "ja", "ko", "pt", "ru"]
        current_lang = getattr(self._live, "LANGUAGE", "en")
        self._lang_var = tk.StringVar(master=self)
        self._lang_var.set(current_lang)
        self._lang_combo = ttk.Combobox(tab, textvariable=self._lang_var, values=lang_options, width=20)
        self._lang_combo.set(current_lang)
        self._lang_combo.grid(row=4, column=1, sticky="w", padx=12, pady=4)
        self._lang_combo.bind("<<ComboboxSelected>>", lambda _e: self._lang_var.set(self._lang_combo.get()))
        _Tooltip(
            self._lang_combo,
            "Specifying your language improves accuracy.\n"
            "'auto' detects the language but may be less accurate for short phrases.",
        )

    def _build_reformatter_tab(self, notebook: ttk.Notebook) -> None:
        tab = ttk.Frame(notebook)
        notebook.add(tab, text="AI Processing")

        # Explanation
        ttk.Label(
            tab,
            text="After Whisper transcribes your speech locally, an AI cleans it up \u2014\n"
            "removing filler words and formatting it for your chosen output mode.",
            foreground="#888888",
            wraplength=480,
        ).grid(row=0, column=0, columnspan=2, sticky="w", padx=12, pady=(12, 4))

        # --- Skip AI checkbox ---
        is_none = self._live.REFORMATTER_BACKEND == "none"
        self._skip_ai_var = tk.BooleanVar(master=self)
        self._skip_ai_var.set(is_none)
        skip_cb = ttk.Checkbutton(tab, text="Skip AI processing", variable=self._skip_ai_var)
        skip_cb.grid(row=1, column=0, columnspan=2, sticky="w", padx=12, pady=(4, 2))
        _Tooltip(
            skip_cb,
            "When checked, raw Whisper transcription goes directly to clipboard\nwithout any AI cleanup or formatting.",
        )

        self._skip_ai_desc = ttk.Label(
            tab,
            text="Raw Whisper output copied directly \u2014 fully private, no data sent anywhere.",
            foreground="#E67E80",
        )
        self._skip_ai_desc.grid(row=2, column=0, columnspan=2, sticky="w", padx=28, pady=(0, 4))

        # --- Private mode checkbox ---
        self._privacy_var = tk.BooleanVar(master=self)
        self._privacy_var.set(self._live.PRIVACY_MODE)
        privacy_cb = ttk.Checkbutton(tab, text="Private mode", variable=self._privacy_var)
        privacy_cb.grid(row=3, column=0, columnspan=2, sticky="w", padx=12, pady=(4, 2))
        _Tooltip(
            privacy_cb,
            "Forces local-only AI processing (Ollama or LM Studio).\n"
            "Combined with local Whisper, nothing ever leaves your machine.",
        )
        self._privacy_desc = ttk.Label(
            tab,
            text="All processing stays on your machine \u2014 fully offline.",
            foreground="#5FC8C8",
        )
        self._privacy_desc.grid(row=4, column=0, columnspan=2, sticky="w", padx=28, pady=(0, 4))

        # --- Backend selector (hidden when skip is checked) ---
        self._ai_widgets = []

        lbl = ttk.Label(tab, text="AI Backend:")
        lbl.grid(row=5, column=0, sticky="w", padx=12, pady=(8, 4))
        self._ai_widgets.append(lbl)

        backend_options_list = ["openrouter", "claude-cli", "local"]
        current_backend = self._live.REFORMATTER_BACKEND if self._live.REFORMATTER_BACKEND != "none" else "openrouter"
        # Backward compat: "ollama" → "local" in UI
        if current_backend == "ollama":
            current_backend = "local"
        backend_options = self._ensure_in_options(current_backend, backend_options_list)
        self._backend_var = tk.StringVar(master=self)
        self._backend_var.set(current_backend)
        self._backend_combo = ttk.Combobox(
            tab, textvariable=self._backend_var, values=backend_options, state="readonly", width=20
        )
        self._backend_combo.set(current_backend)
        self._backend_combo.grid(row=5, column=1, sticky="w", padx=12, pady=(8, 4))
        self._backend_combo.bind("<<ComboboxSelected>>", lambda _e: self._backend_var.set(self._backend_combo.get()))
        self._ai_widgets.append(self._backend_combo)
        _Tooltip(self._backend_combo, "Which AI service processes your speech after Whisper transcribes it.")

        # Backend description
        _backend_descs = {
            "openrouter": "Cloud API \u2014 uses Claude via OpenRouter (~$0.001/dictation)",
            "claude-cli": "Uses your local Claude Code CLI \u2014 no extra API key needed",
            "local": "Local LLM \u2014 100% private, nothing leaves your machine (Ollama or LM Studio)",
        }
        self._backend_desc_var = tk.StringVar(master=self)
        desc_lbl = ttk.Label(tab, textvariable=self._backend_desc_var, foreground="#5FC8C8", wraplength=480)
        desc_lbl.grid(row=6, column=0, columnspan=2, sticky="w", padx=12, pady=(0, 4))
        self._ai_widgets.append(desc_lbl)

        # Validation warning
        self._backend_warn_var = tk.StringVar(master=self)
        warn_lbl = ttk.Label(tab, textvariable=self._backend_warn_var, foreground="#E67E80", wraplength=480)
        warn_lbl.grid(row=7, column=0, columnspan=2, sticky="w", padx=12, pady=(0, 8))
        self._ai_widgets.append(warn_lbl)

        # --- OpenRouter fields ---
        self._openrouter_widgets = []

        lbl = ttk.Label(tab, text="API Key:")
        lbl.grid(row=8, column=0, sticky="w", padx=12, pady=4)
        self._openrouter_widgets.append(lbl)
        self._apikey_var = tk.StringVar(master=self)
        self._apikey_var.set(self._live.OPENROUTER_API_KEY)
        api_entry = ttk.Entry(tab, textvariable=self._apikey_var, width=38, show="*")
        api_entry.grid(row=8, column=1, sticky="w", padx=12, pady=4)
        self._openrouter_widgets.append(api_entry)
        _Tooltip(api_entry, "Get a free API key at openrouter.ai/keys")

        lbl = ttk.Label(tab, text="AI Model:")
        lbl.grid(row=9, column=0, sticky="w", padx=12, pady=4)
        self._openrouter_widgets.append(lbl)
        self._dictmodel_var = tk.StringVar(master=self)
        self._dictmodel_var.set(self._live.DICTATION_MODEL)
        dictmodel_entry = ttk.Entry(tab, textvariable=self._dictmodel_var, width=38)
        dictmodel_entry.grid(row=9, column=1, sticky="w", padx=12, pady=4)
        self._openrouter_widgets.append(dictmodel_entry)
        _Tooltip(
            dictmodel_entry,
            "OpenRouter model ID (e.g., anthropic/claude-sonnet-4-6).\nThe default works well for most users.",
        )

        # --- Local LLM provider selector ---
        self._local_provider_widgets = []

        lbl = ttk.Label(tab, text="Provider:")
        lbl.grid(row=10, column=0, sticky="w", padx=12, pady=4)
        self._local_provider_widgets.append(lbl)
        provider_options = ["Ollama", "LM Studio"]
        current_provider = "LM Studio" if self._live.LOCAL_LLM_PROVIDER == "lmstudio" else "Ollama"
        self._local_provider_var = tk.StringVar(master=self)
        self._local_provider_var.set(current_provider)
        self._local_provider_combo = ttk.Combobox(
            tab, textvariable=self._local_provider_var, values=provider_options, state="readonly", width=20
        )
        self._local_provider_combo.set(current_provider)
        self._local_provider_combo.grid(row=10, column=1, sticky="w", padx=12, pady=4)
        self._local_provider_combo.bind(
            "<<ComboboxSelected>>", lambda _e: self._local_provider_var.set(self._local_provider_combo.get())
        )
        self._local_provider_widgets.append(self._local_provider_combo)
        _Tooltip(self._local_provider_combo, "Which local LLM server you're running.")

        # --- Ollama fields ---
        self._ollama_widgets = []

        lbl = ttk.Label(tab, text="Ollama URL:")
        lbl.grid(row=11, column=0, sticky="w", padx=12, pady=4)
        self._ollama_widgets.append(lbl)
        self._ollama_url_var = tk.StringVar(master=self)
        self._ollama_url_var.set(self._live.OLLAMA_URL)
        ollama_url_entry = ttk.Entry(tab, textvariable=self._ollama_url_var, width=38)
        ollama_url_entry.grid(row=11, column=1, sticky="w", padx=12, pady=4)
        self._ollama_widgets.append(ollama_url_entry)
        _Tooltip(
            ollama_url_entry, "Default: http://localhost:11434\nChange if Ollama runs on a different host or port."
        )

        lbl = ttk.Label(tab, text="Ollama Model:")
        lbl.grid(row=12, column=0, sticky="w", padx=12, pady=4)
        self._ollama_widgets.append(lbl)
        self._ollama_model_var = tk.StringVar(master=self)
        self._ollama_model_var.set(self._live.OLLAMA_MODEL)
        ollama_model_frame = ttk.Frame(tab)
        ollama_model_frame.grid(row=12, column=1, sticky="w", padx=12, pady=4)
        self._ollama_widgets.append(ollama_model_frame)
        self._ollama_model_combo = ttk.Combobox(ollama_model_frame, textvariable=self._ollama_model_var, width=28)
        self._ollama_model_combo.set(self._live.OLLAMA_MODEL)
        self._ollama_model_combo.pack(side="left")
        self._ollama_model_combo.bind(
            "<<ComboboxSelected>>", lambda _e: self._ollama_model_var.set(self._ollama_model_combo.get())
        )
        _Tooltip(
            self._ollama_model_combo,
            "Select from installed Ollama models, or type a model name.\nClick Refresh to re-query Ollama.",
        )
        self._ollama_refresh_btn = ttk.Button(
            ollama_model_frame, text="Refresh", command=self._load_ollama_models, width=7
        )
        self._ollama_refresh_btn.pack(side="left", padx=(6, 0))
        _Tooltip(self._ollama_refresh_btn, "Query Ollama for installed models.")

        # Auto-load models in background
        self._load_ollama_models()

        # --- LM Studio fields ---
        self._lmstudio_widgets = []

        lbl = ttk.Label(tab, text="LM Studio URL:")
        lbl.grid(row=13, column=0, sticky="w", padx=12, pady=4)
        self._lmstudio_widgets.append(lbl)
        self._lmstudio_url_var = tk.StringVar(master=self)
        self._lmstudio_url_var.set(self._live.LMSTUDIO_URL)
        lmstudio_url_entry = ttk.Entry(tab, textvariable=self._lmstudio_url_var, width=38)
        lmstudio_url_entry.grid(row=13, column=1, sticky="w", padx=12, pady=4)
        self._lmstudio_widgets.append(lmstudio_url_entry)
        _Tooltip(
            lmstudio_url_entry, "Default: http://localhost:1234\nChange if LM Studio runs on a different host or port."
        )

        lbl = ttk.Label(tab, text="LM Studio Model:")
        lbl.grid(row=14, column=0, sticky="w", padx=12, pady=4)
        self._lmstudio_widgets.append(lbl)
        self._lmstudio_model_var = tk.StringVar(master=self)
        self._lmstudio_model_var.set(self._live.LMSTUDIO_MODEL)
        lmstudio_model_frame = ttk.Frame(tab)
        lmstudio_model_frame.grid(row=14, column=1, sticky="w", padx=12, pady=4)
        self._lmstudio_widgets.append(lmstudio_model_frame)
        self._lmstudio_model_combo = ttk.Combobox(lmstudio_model_frame, textvariable=self._lmstudio_model_var, width=28)
        self._lmstudio_model_combo.set(self._live.LMSTUDIO_MODEL)
        self._lmstudio_model_combo.pack(side="left")
        self._lmstudio_model_combo.bind(
            "<<ComboboxSelected>>", lambda _e: self._lmstudio_model_var.set(self._lmstudio_model_combo.get())
        )
        _Tooltip(
            self._lmstudio_model_combo,
            "Select from loaded LM Studio models, or type a model name.\n"
            "If blank, uses whatever model LM Studio has active.",
        )
        self._lmstudio_refresh_btn = ttk.Button(
            lmstudio_model_frame, text="Refresh", command=self._load_lmstudio_models, width=7
        )
        self._lmstudio_refresh_btn.pack(side="left", padx=(6, 0))
        _Tooltip(self._lmstudio_refresh_btn, "Query LM Studio for loaded models.")

        # Auto-load LM Studio models in background
        self._load_lmstudio_models()

        # --- Claude CLI fields ---
        self._claude_widgets = []

        lbl = ttk.Label(tab, text="Claude Path:")
        lbl.grid(row=15, column=0, sticky="w", padx=12, pady=4)
        self._claude_widgets.append(lbl)
        self._claude_path_var = tk.StringVar(master=self)
        self._claude_path_var.set(self._live.CLAUDE_CLI_PATH)
        claude_path_entry = ttk.Entry(tab, textvariable=self._claude_path_var, width=38)
        claude_path_entry.grid(row=15, column=1, sticky="w", padx=12, pady=4)
        self._claude_widgets.append(claude_path_entry)
        _Tooltip(
            claude_path_entry, "Path to the claude executable.\nUsually just 'claude' if installed globally via npm."
        )

        lbl = ttk.Label(tab, text="Claude Model:")
        lbl.grid(row=16, column=0, sticky="w", padx=12, pady=4)
        self._claude_widgets.append(lbl)
        self._claude_model_var = tk.StringVar(master=self)
        self._claude_model_var.set(self._live.CLAUDE_CLI_MODEL)
        claude_model_entry = ttk.Entry(tab, textvariable=self._claude_model_var, width=38)
        claude_model_entry.grid(row=16, column=1, sticky="w", padx=12, pady=4)
        self._claude_widgets.append(claude_model_entry)
        _Tooltip(claude_model_entry, "Claude model to use (e.g., haiku, sonnet, opus).\nhaiku is fastest and cheapest.")

        def _update_backend_fields(*_args) -> None:
            privacy = self._privacy_var.get()
            skip = self._skip_ai_var.get()

            # Show/hide privacy description
            if privacy:
                self._privacy_desc.grid()
            else:
                self._privacy_desc.grid_remove()

            # Privacy mode forces local backend and hides skip-AI
            if privacy:
                self._skip_ai_var.set(False)
                self._backend_combo.set("local")
                self._backend_var.set("local")

            # Show/hide skip description
            if skip and not privacy:
                self._skip_ai_desc.grid()
            else:
                self._skip_ai_desc.grid_remove()

            # Show/hide all AI widgets
            for w in self._ai_widgets:
                w.grid_remove() if skip else w.grid()

            all_provider_widgets = (
                self._openrouter_widgets
                + self._local_provider_widgets
                + self._ollama_widgets
                + self._lmstudio_widgets
                + self._claude_widgets
            )

            if skip:
                for w in all_provider_widgets:
                    w.grid_remove()
                return

            b = self._backend_var.get().lower()
            self._backend_desc_var.set(_backend_descs.get(b, ""))
            self._backend_warn_var.set("")

            for w in self._openrouter_widgets:
                w.grid() if b == "openrouter" else w.grid_remove()
            for w in self._claude_widgets:
                w.grid() if b == "claude-cli" else w.grid_remove()

            # Local LLM: show provider selector + provider-specific fields
            if b == "local":
                for w in self._local_provider_widgets:
                    w.grid()
                provider = self._local_provider_combo.get()
                is_ollama = provider == "Ollama"
                for w in self._ollama_widgets:
                    w.grid() if is_ollama else w.grid_remove()
                for w in self._lmstudio_widgets:
                    w.grid() if not is_ollama else w.grid_remove()
            else:
                for w in self._local_provider_widgets + self._ollama_widgets + self._lmstudio_widgets:
                    w.grid_remove()

            if b == "openrouter" and not self._apikey_var.get().strip():
                self._backend_warn_var.set("API key required \u2014 get one at openrouter.ai/keys")

        self._privacy_var.trace_add("write", _update_backend_fields)
        self._skip_ai_var.trace_add("write", _update_backend_fields)
        self._backend_var.trace_add("write", _update_backend_fields)
        self._local_provider_var.trace_add("write", _update_backend_fields)
        self._apikey_var.trace_add("write", _update_backend_fields)
        _update_backend_fields()  # Set initial visibility

    def _build_history_tab(self, notebook: ttk.Notebook) -> None:
        tab = ttk.Frame(notebook)
        notebook.add(tab, text="History")

        ttk.Label(
            tab,
            text="Dictation history is stored locally and accessible from the tray menu.",
            foreground="#888888",
            wraplength=480,
        ).grid(row=0, column=0, columnspan=2, sticky="w", padx=12, pady=(12, 8))

        # Enabled
        self._hist_enabled_var = tk.BooleanVar(master=self)
        self._hist_enabled_var.set(self._live.HISTORY_ENABLED)
        hist_cb = ttk.Checkbutton(tab, text="Enable dictation history", variable=self._hist_enabled_var)
        hist_cb.grid(row=1, column=0, columnspan=2, sticky="w", padx=12, pady=4)
        _Tooltip(hist_cb, "Saves each dictation locally so you can review or re-copy past results from the tray menu.")

        # Retention (hidden when history disabled)
        retention_label = ttk.Label(tab, text="Retention (days):")
        retention_label.grid(row=2, column=0, sticky="w", padx=12, pady=4)
        self._retention_var = tk.StringVar(master=self)
        self._retention_var.set(str(self._live.HISTORY_RETENTION_DAYS))
        retention_entry = ttk.Entry(tab, textvariable=self._retention_var, width=10)
        retention_entry.grid(row=2, column=1, sticky="w", padx=12, pady=4)
        _Tooltip(
            retention_entry,
            "History entries older than this are automatically deleted.\nSet to 0 to keep history forever.",
        )

        # Clear history button
        def _clear_history() -> None:
            from getinvoke import history

            history.init_db()
            entry_count = history.count()
            if messagebox.askyesno("Clear History", f"Delete all {entry_count} history entries?"):
                history.clear()
                messagebox.showinfo("History Cleared", "All history entries deleted.")

        clear_btn = ttk.Button(tab, text="Clear History", command=_clear_history)
        clear_btn.grid(row=3, column=0, sticky="w", padx=12, pady=(16, 4))

        # Toggle retention/clear visibility based on history enabled
        self._hist_detail_widgets = [retention_label, retention_entry, clear_btn]

        def _update_hist_widgets(*_args) -> None:
            for w in self._hist_detail_widgets:
                w.grid() if self._hist_enabled_var.get() else w.grid_remove()

        self._hist_enabled_var.trace_add("write", _update_hist_widgets)
        _update_hist_widgets()

    def _build_advanced_tab(self, notebook: ttk.Notebook) -> None:
        tab = ttk.Frame(notebook)
        notebook.add(tab, text="Advanced")

        # Log level
        ttk.Label(tab, text="Log Level:").grid(row=0, column=0, sticky="w", padx=12, pady=(12, 4))
        log_options = self._ensure_in_options(self._live.LOG_LEVEL, ["DEBUG", "INFO", "WARNING", "ERROR"])
        self._loglevel_var = tk.StringVar(master=self)
        self._loglevel_var.set(self._live.LOG_LEVEL)
        self._loglevel_combo = ttk.Combobox(
            tab, textvariable=self._loglevel_var, values=log_options, state="readonly", width=20
        )
        self._loglevel_combo.set(self._live.LOG_LEVEL)
        self._loglevel_combo.grid(row=0, column=1, sticky="w", padx=12, pady=(12, 4))
        self._loglevel_combo.bind("<<ComboboxSelected>>", lambda _e: self._loglevel_var.set(self._loglevel_combo.get()))
        _Tooltip(
            self._loglevel_combo,
            "DEBUG \u2014 everything (verbose, for troubleshooting)\n"
            "INFO \u2014 normal operation (recommended)\n"
            "WARNING \u2014 only problems\n"
            "ERROR \u2014 only failures",
        )

        # Custom vocabulary
        ttk.Label(tab, text="Custom Vocabulary:").grid(row=1, column=0, sticky="nw", padx=12, pady=4)
        self._vocab_var = tk.StringVar(master=self)
        self._vocab_var.set(self._live.CUSTOM_VOCAB)
        vocab_entry = ttk.Entry(tab, textvariable=self._vocab_var, width=38)
        vocab_entry.grid(row=1, column=1, sticky="w", padx=12, pady=4)
        _Tooltip(
            vocab_entry,
            "Technical terms Whisper should recognize correctly.\n"
            "Invoke also auto-detects project terms from your active editor window.",
        )
        ttk.Label(tab, text="Comma-separated (e.g. KeyGrip,FastAPI,pynput)", foreground="#888888").grid(
            row=2, column=0, columnspan=2, sticky="w", padx=12, pady=(0, 4)
        )

        # Logs location
        ttk.Label(tab, text="Log files:").grid(row=3, column=0, sticky="w", padx=12, pady=(16, 4))
        ttk.Label(tab, text=str(self._live.log_dir), foreground="#888888").grid(
            row=3, column=1, sticky="w", padx=12, pady=(16, 4)
        )
        ttk.Label(tab, text="Config file:").grid(row=4, column=0, sticky="w", padx=12, pady=4)
        ttk.Label(tab, text=str(self._live.config_file), foreground="#888888").grid(
            row=4, column=1, sticky="w", padx=12, pady=4
        )

    def _populate_audio_combo(self, device_names: list[str], audio_val: str) -> None:
        """Callback to populate audio combo after async device enumeration."""
        try:
            self._audio_combo.configure(values=device_names)
            self._audio_combo.set(audio_val)
            self._audio_var.set(audio_val)
        except tk.TclError:
            pass  # Window was closed before devices loaded

    def _build_license_tab(self, notebook: ttk.Notebook) -> None:
        tab = ttk.Frame(notebook)
        notebook.add(tab, text="License")

        # Placeholder while license loads async
        ttk.Label(tab, text="License Status:").grid(row=0, column=0, sticky="w", padx=12, pady=(12, 4))
        self._license_status_display = ttk.Label(tab, text="Loading...", foreground="#888888")
        self._license_status_display.grid(row=0, column=1, sticky="w", padx=12, pady=(12, 4))

        self._license_email_label_name = ttk.Label(tab, text="")
        self._license_email_label_name.grid(row=1, column=0, sticky="w", padx=12, pady=4)
        self._license_email_label_val = ttk.Label(tab, text="", foreground="#888888")
        self._license_email_label_val.grid(row=1, column=1, sticky="w", padx=12, pady=4)

        ttk.Label(tab, text="License Key:").grid(row=2, column=0, sticky="w", padx=12, pady=(16, 4))
        self._license_key_var = tk.StringVar(master=self)
        license_key_entry = ttk.Entry(tab, textvariable=self._license_key_var, width=38, show="*")
        license_key_entry.grid(row=2, column=1, sticky="w", padx=12, pady=(16, 4))
        _Tooltip(license_key_entry, "Your Invoke license key from Lemon Squeezy.\nPaste it here and click Activate.")

        self._license_btn_frame = ttk.Frame(tab)
        self._license_btn_frame.grid(row=3, column=0, columnspan=2, sticky="w", padx=12, pady=4)

        self._license_status_var = tk.StringVar(master=self)
        ttk.Label(tab, textvariable=self._license_status_var, foreground="#888888").grid(
            row=4, column=0, columnspan=2, sticky="w", padx=12, pady=(8, 0)
        )

        self._license_tab = tab

        # Load license info in background
        import threading

        threading.Thread(target=self._load_license_async, daemon=True).start()

    def _load_license_async(self) -> None:
        """Load license info off the UI thread."""
        from getinvoke.license import LicenseManager

        lm = LicenseManager()
        status = lm.check()
        self.after(0, lambda: self._populate_license_tab(lm, status))

    def _populate_license_tab(self, lm, status) -> None:
        """Populate license tab on UI thread after async load."""
        try:
            from getinvoke.license import LicenseStatus

            status_text = {
                LicenseStatus.TRIAL: f"Trial \u2014 {lm.trial_days_left} days left",
                LicenseStatus.ACTIVE: "Active",
                LicenseStatus.EXPIRED_TRIAL: "Trial Expired",
                LicenseStatus.INVALID: "Invalid \u2014 re-activation required",
                LicenseStatus.GRACE: "Active (offline grace period)",
            }
            status_color = "#22c55e" if status in (LicenseStatus.ACTIVE, LicenseStatus.TRIAL) else "#E67E80"

            self._license_status_display.configure(text=status_text.get(status, "Unknown"), foreground=status_color)

            if lm.customer_email:
                self._license_email_label_name.configure(text="Email:")
                self._license_email_label_val.configure(text=lm.customer_email)

            self._license_key_var.set(lm.license_key)

            def _activate() -> None:
                key = self._license_key_var.get().strip()
                if not key:
                    self._license_status_var.set("Enter a license key first.")
                    return
                self._license_status_var.set("Activating...")

                import threading

                def _do():
                    success, msg = lm.activate(key)
                    self.after(0, lambda: self._on_activate_done(success, msg))

                threading.Thread(target=_do, daemon=True).start()

            def _deactivate() -> None:
                import threading

                def _do():
                    success, msg = lm.deactivate()
                    self.after(0, lambda: self._on_deactivate_done(success, msg))

                threading.Thread(target=_do, daemon=True).start()

            ttk.Button(self._license_btn_frame, text="Activate", command=_activate, style="Gold.TButton").pack(
                side="left"
            )
            if status == LicenseStatus.ACTIVE:
                ttk.Button(self._license_btn_frame, text="Deactivate", command=_deactivate).pack(
                    side="left", padx=(8, 0)
                )
        except tk.TclError:
            pass  # Window closed

    def _on_activate_done(self, success: bool, msg: str) -> None:
        self._license_status_var.set(msg)
        if success:
            self._license_status_display.configure(text="Active", foreground="#22c55e")

    def _on_deactivate_done(self, success: bool, msg: str) -> None:
        self._license_status_var.set(msg)
        if success:
            self._license_status_display.configure(text="Deactivated", foreground="#E67E80")

    def _save(self) -> None:
        """Save all settings to config.json and update the live singleton."""
        try:
            live = self._live

            # General — read from combo widgets directly (StringVars desync in threaded tkinter)
            live.MODE = self._mode_combo.get()
            live.HOTKEY = self._hotkey_combo.get()
            live.AUTO_PASTE = self._autopaste_var.get()
            live.BEEP_ENABLED = self._beep_var.get()
            live.SOUND_PRESET = self._sound_theme_combo.get()

            # Transcription
            live.WHISPER_MODEL = self._model_combo.get()
            raw_device = self._device_combo.get()
            live._whisper_device_setting = raw_device
            if raw_device != "auto":
                live.WHISPER_DEVICE = raw_device
            # If "auto", keep current resolved value for this session
            audio = self._audio_combo.get()
            if audio in ("default", "Loading..."):
                live.AUDIO_DEVICE = None
            else:
                live.AUDIO_DEVICE = audio.split("]")[0].strip("[")
            live.LANGUAGE = self._lang_combo.get()

            # Reformatter
            live.PRIVACY_MODE = self._privacy_var.get()
            if self._skip_ai_var.get():
                live.REFORMATTER_BACKEND = "none"
            elif live.PRIVACY_MODE:
                live.REFORMATTER_BACKEND = "local"
            else:
                live.REFORMATTER_BACKEND = self._backend_combo.get()
            live.OPENROUTER_API_KEY = self._apikey_var.get()
            live.DICTATION_MODEL = self._dictmodel_var.get()
            # Local LLM provider
            provider = self._local_provider_combo.get()
            live.LOCAL_LLM_PROVIDER = "lmstudio" if provider == "LM Studio" else "ollama"
            live.OLLAMA_URL = self._ollama_url_var.get()
            live.OLLAMA_MODEL = self._ollama_model_combo.get()
            live.LMSTUDIO_URL = self._lmstudio_url_var.get()
            live.LMSTUDIO_MODEL = self._lmstudio_model_combo.get()
            live.CLAUDE_CLI_PATH = self._claude_path_var.get()
            live.CLAUDE_CLI_MODEL = self._claude_model_var.get()

            # History
            live.HISTORY_ENABLED = self._hist_enabled_var.get()
            try:
                days = int(self._retention_var.get())
                if days < 0:
                    raise ValueError("negative")
                live.HISTORY_RETENTION_DAYS = days
            except ValueError:
                messagebox.showwarning(
                    "Invalid Value", "Retention days must be a non-negative number. Keeping current value."
                )
                self._retention_var.set(str(live.HISTORY_RETENTION_DAYS))

            # Image capture
            live.IMAGE_CAPTURE_ENABLED = self._image_var.get()
            live.IMAGE_HOTKEY = self._image_hotkey_combo.get()
            live.IMAGE_SAVE_DIR = self._image_dir_var.get()

            # Project directory
            live.PROJECT_DIR = self._project_dir_var.get()

            # Advanced
            live.LOG_LEVEL = self._loglevel_combo.get()
            live.CUSTOM_VOCAB = self._vocab_var.get()

            # Write to disk
            live.save()

            logger.info(f"Settings saved to {live.config_file}")

            # Check if any restart-required settings changed
            restart_fields = []
            if live.HOTKEY != self._initial_hotkey:
                restart_fields.append("Hotkey")
            if live.WHISPER_MODEL != self._initial_whisper_model:
                restart_fields.append("Whisper model")
            if live._whisper_device_setting != self._initial_whisper_device:
                restart_fields.append("Compute device")
            if (live.AUDIO_DEVICE or "") != (self._initial_audio_device or ""):
                restart_fields.append("Microphone")
            if live.IMAGE_HOTKEY != self._initial_image_hotkey:
                restart_fields.append("Image hotkey")
            if live.IMAGE_CAPTURE_ENABLED != self._initial_image_enabled:
                restart_fields.append("Image capture")

            if restart_fields:
                messagebox.showinfo(
                    "Restart Required",
                    f"Changes to {', '.join(restart_fields)} take effect after restarting Invoke.",
                )

            if self._on_save:
                self._on_save()
        except Exception as e:
            logger.error(f"Failed to save settings: {e}")
            messagebox.showerror("Save Error", f"Failed to save settings:\n{e}")
            return

        self.destroy()
