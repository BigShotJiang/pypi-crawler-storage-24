"""Terminal-based setup wizard using Click prompts + Rich panels."""

import logging
import shutil

import click
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

logger = logging.getLogger(__name__)

console = Console()


def run_cli_wizard() -> None:
    """Interactive CLI setup wizard — same flow as the tkinter wizard."""
    logger.info("Launching CLI setup wizard...")

    collected: dict = {}

    # Step 1: Welcome
    header = Text()
    header.append("> dictate\n", style="bold white")
    header.append("Voice-to-prompt for developers\n\n", style="dim")
    header.append("Hold a button, speak, release.\n", style="white")
    header.append("Text appears at your cursor in under a second.\n\n", style="white")
    header.append("This wizard will set up your GPU, microphone,\nand preferences.", style="dim")
    console.print(Panel(header, border_style="cyan", title="Setup"))
    click.echo()

    # Step 2: License
    console.print("  [bold]License[/bold]", highlight=False)
    console.print("  Invoke includes a 7-day free trial.", style="dim", highlight=False)
    click.echo()

    license_choice = click.prompt(
        "  Enter license key, or press Enter to start trial",
        default="",
        show_default=False,
    )

    if license_choice.strip():
        from getinvoke.license import LicenseManager

        lm = LicenseManager()
        success, msg = lm.activate(license_choice.strip())
        if success:
            console.print(f"  [green]{msg}[/green]")
            collected["license_activated"] = True
        else:
            console.print(f"  [red]{msg}[/red]")
            console.print("  Starting trial instead.", style="dim", highlight=False)
            lm.check()
    else:
        from getinvoke.license import LicenseManager

        lm = LicenseManager()
        lm.check()  # Creates trial if no license.json
        console.print("  [green]7-day trial started.[/green]")

    click.echo()

    # Step 3: GPU Detection
    console.print("  [bold]GPU Detection[/bold]", highlight=False)
    console.print("  Checking for GPU acceleration...", style="dim", highlight=False)

    gpu_available = False
    detection_method = ""

    # Check for Apple Silicon + MLX first
    import platform as _plat

    if _plat.system() == "Darwin" and _plat.machine() == "arm64":
        try:
            import mlx_whisper  # noqa: F401

            gpu_available = True
            detection_method = "Apple Silicon (MLX)"
        except ImportError:
            pass

    if not gpu_available:
        try:
            import ctranslate2

            cuda_types = ctranslate2.get_supported_compute_types("cuda")
            if cuda_types:
                gpu_available = True
                detection_method = "ctranslate2 CUDA support"
        except Exception:
            pass

    if not gpu_available:
        import os

        cuda_path = os.environ.get("CUDA_PATH", "")
        if cuda_path and os.path.isdir(cuda_path):
            gpu_available = True
            detection_method = f"CUDA Toolkit at {cuda_path}"

    if not gpu_available and shutil.which("nvidia-smi"):
        gpu_available = True
        detection_method = "nvidia-smi (NVIDIA driver)"

    if gpu_available:
        if "MLX" in detection_method:
            console.print(f"  [green]Apple Silicon GPU detected![/green] ({detection_method})")
            collected["whisper_device"] = "mlx"
        else:
            console.print(f"  [green]CUDA GPU detected![/green] ({detection_method})")
            collected["whisper_device"] = "cuda"
    else:
        console.print("  [yellow]No GPU found[/yellow] — will use CPU (slower but functional)")
        collected["whisper_device"] = "cpu"

    click.echo()

    # Step 4: Audio Device
    console.print("  [bold]Audio Device[/bold]", highlight=False)

    from getinvoke.recorder import list_devices

    devices = list_devices()
    if not devices:
        console.print("  [yellow]No audio input devices found![/yellow]")
        collected["audio_device"] = ""
    else:
        for dev in devices:
            console.print(f"    [{dev['index']}] {dev['name']} ({dev['channels']}ch)", highlight=False)
        click.echo()
        choice = click.prompt(
            "  Select device number",
            default=str(devices[0]["index"]),
            show_default=True,
        )
        collected["audio_device"] = choice

    click.echo()

    # Step 5: AI Backend
    console.print("  [bold]AI Processing[/bold]", highlight=False)
    console.print("  After Whisper transcribes, an AI can clean up your speech.", style="dim", highlight=False)
    click.echo()

    has_claude_cli = shutil.which("claude") is not None

    backends = [
        ("openrouter", "OpenRouter (cloud API, ~$0.001/dictation)"),
        ("claude-cli", f"Claude Code CLI{' (detected)' if has_claude_cli else ''}"),
        ("local", "Local LLM (Ollama, LM Studio) \u2014 fully private"),
        ("none", "No AI — raw transcription only"),
    ]

    for i, (key, desc) in enumerate(backends, 1):
        console.print(f"    [{i}] {desc}", highlight=False)

    default_idx = 2 if has_claude_cli else 4
    choice = click.prompt("  Select backend", default=str(default_idx), show_default=True)

    try:
        backend_key = backends[int(choice) - 1][0]
    except (ValueError, IndexError):
        backend_key = "none"

    collected["reformatter_backend"] = backend_key

    # Conditional API key prompt
    if backend_key == "openrouter":
        api_key = click.prompt("  OpenRouter API key", hide_input=True)
        collected["openrouter_api_key"] = api_key

    click.echo()

    # Step 6: Hotkey
    console.print("  [bold]Hotkey[/bold]", highlight=False)
    hotkeys = [
        ("mouse5", "Mouse 5 (forward side button)"),
        ("mouse4", "Mouse 4 (back side button)"),
        ("ctrl+shift+d", "Ctrl+Shift+D"),
    ]

    for i, (key, desc) in enumerate(hotkeys, 1):
        console.print(f"    [{i}] {desc}", highlight=False)

    choice = click.prompt("  Select hotkey", default="1", show_default=True)
    try:
        collected["hotkey"] = hotkeys[int(choice) - 1][0]
    except (ValueError, IndexError):
        collected["hotkey"] = "mouse5"

    # Auto-paste
    collected["auto_paste"] = click.confirm("  Auto-paste at cursor?", default=True)

    click.echo()

    # Step 7: Save + Summary
    _save_settings(collected)

    device = collected.get("whisper_device", "cpu")
    backend = collected.get("reformatter_backend", "none")
    hotkey = collected.get("hotkey", "mouse5")
    autopaste = collected.get("auto_paste", True)

    summary = Text()
    summary.append("Configuration saved!\n\n", style="bold green")
    gpu_label = "Apple Silicon (MLX)" if device == "mlx" else "CUDA" if device == "cuda" else "CPU"
    summary.append(f"  GPU: {gpu_label}\n", style="white")
    summary.append(f"  AI Backend: {backend}\n", style="white")
    summary.append(f"  Hotkey: {hotkey}\n", style="white")
    summary.append(f"  Auto-paste: {'on' if autopaste else 'off'}\n\n", style="white")
    summary.append("  Run 'dictate run' to start.\n", style="dim")
    summary.append(f"  Hold {hotkey} to speak, release to transcribe.", style="dim")

    console.print(Panel(summary, border_style="green", title="Setup Complete"))

    logger.info("CLI wizard complete")


def _save_settings(collected: dict) -> None:
    """Write collected settings to config.json via the Settings singleton."""
    from getinvoke.config import settings

    if "whisper_device" in collected:
        settings.WHISPER_DEVICE = collected["whisper_device"]
    if "audio_device" in collected:
        settings.AUDIO_DEVICE = collected["audio_device"] or None
    if "reformatter_backend" in collected:
        settings.REFORMATTER_BACKEND = collected["reformatter_backend"]
    if "openrouter_api_key" in collected:
        settings.OPENROUTER_API_KEY = collected["openrouter_api_key"]
    if "hotkey" in collected:
        settings.HOTKEY = collected["hotkey"]
    if "auto_paste" in collected:
        settings.AUTO_PASTE = collected["auto_paste"]

    settings.save()
    safe = {k: ("***" if "key" in k.lower() else v) for k, v in collected.items()}
    logger.info(f"CLI wizard saved config: {safe}")
