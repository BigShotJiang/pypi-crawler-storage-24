"""Cross-platform clipboard access."""

import logging
import os
import platform
import subprocess
import time

import pyperclip

logger = logging.getLogger(__name__)

_ON_WAYLAND = platform.system() == "Linux" and bool(os.environ.get("WAYLAND_DISPLAY"))

# Terminal emulator WM_CLASS names — terminals use Ctrl+Shift+V, not Ctrl+V
_TERMINAL_CLASSES = {
    "alacritty",
    "kitty",
    "wezterm",
    "foot",
    "gnome-terminal",
    "konsole",
    "xterm",
    "urxvt",
    "terminator",
    "tilix",
    "sakura",
    "st",
    "xfce4-terminal",
    "mate-terminal",
    "lxterminal",
    "warp",
    "ghostty",
    "rio",
    "hyper",
}


def _is_terminal_window() -> bool:
    """Check if the active window is a terminal emulator (needs Ctrl+Shift+V)."""
    try:
        result = subprocess.run(
            ["xdotool", "getactivewindow", "getwindowclassname"],
            capture_output=True,
            text=True,
            timeout=2,
        )
        wm_class = result.stdout.strip().lower()
        return any(t in wm_class for t in _TERMINAL_CLASSES)
    except Exception:
        return False


def copy(text: str) -> bool:
    """Copy text to system clipboard. Returns True on success."""
    if _ON_WAYLAND:
        # pyperclip uses xclip/xsel which write to the X11 clipboard only.
        # On Wayland, use wl-copy to write to the native Wayland clipboard.
        try:
            subprocess.run(["wl-copy", "--", text], timeout=2, check=True)
            logger.info(f"Copied {len(text)} chars to clipboard (wl-copy)")
            return True
        except FileNotFoundError:
            logger.warning(
                "wl-copy not found — clipboard will use X11 only (install wl-clipboard: sudo dnf install wl-clipboard)"
            )
        except Exception as e:
            logger.error(f"Clipboard error (wl-copy): {e}")
            return False

    try:
        pyperclip.copy(text)
        logger.info(f"Copied {len(text)} chars to clipboard")
        return True
    except pyperclip.PyperclipException as e:
        logger.error(f"Clipboard error: {e}")
        return False


def paste() -> bool:
    """Simulate Ctrl+V to paste clipboard contents at cursor. Returns True on success."""
    # Small delay to ensure clipboard is ready and hotkey is fully released
    time.sleep(0.05)

    if platform.system() == "Darwin":
        try:
            subprocess.run(
                ["osascript", "-e", 'tell application "System Events" to keystroke "v" using command down'],
                timeout=2,
                check=True,
            )
            logger.info("Auto-pasted via osascript (Cmd+V)")
            return True
        except FileNotFoundError:
            logger.warning("osascript not found — auto-paste unavailable on this macOS install")
            return False
        except Exception as e:
            logger.error(f"Auto-paste error (osascript): {e}")
            return False

    if platform.system() == "Linux":
        if _ON_WAYLAND:
            # Many apps (Electron, etc.) run via XWayland and receive X11 events,
            # so try xdotool first. Terminals need Ctrl+Shift+V instead of Ctrl+V.
            # If the focused window is native Wayland, fall back to wtype.
            try:
                if _is_terminal_window():
                    subprocess.run(["xdotool", "key", "ctrl+shift+v"], timeout=2, check=True)
                    logger.info("Auto-pasted via xdotool (Ctrl+Shift+V, terminal)")
                else:
                    subprocess.run(["xdotool", "key", "ctrl+v"], timeout=2, check=True)
                    logger.info("Auto-pasted via xdotool (Ctrl+V, XWayland window)")
                return True
            except FileNotFoundError:
                pass
            except Exception:
                pass

            try:
                subprocess.run(["wtype", "-M", "ctrl", "v", "-m", "ctrl"], timeout=2, check=True)
                logger.info("Auto-pasted via wtype (Ctrl+V)")
                return True
            except FileNotFoundError:
                logger.warning(
                    "Auto-paste on Wayland: install xdotool (for XWayland/Electron apps) "
                    "or wtype (for native Wayland apps on KDE/sway). "
                    "Text is on clipboard — paste manually with Ctrl+V (GUI) or Ctrl+Shift+V (terminal)."
                )
            except Exception as e:
                logger.warning(f"Auto-paste (wtype) failed: {e} — paste manually with Ctrl+V.")
            return False
        else:
            try:
                if _is_terminal_window():
                    subprocess.run(["xdotool", "key", "ctrl+shift+v"], timeout=2, check=True)
                    logger.info("Auto-pasted via xdotool (Ctrl+Shift+V, terminal)")
                else:
                    subprocess.run(["xdotool", "key", "ctrl+v"], timeout=2, check=True)
                    logger.info("Auto-pasted via xdotool")
                return True
            except FileNotFoundError:
                logger.warning("Auto-paste needs xdotool on Linux: sudo apt install xdotool")
                return False
            except Exception as e:
                logger.error(f"Auto-paste error (xdotool): {e}")
                return False

    try:
        from pynput.keyboard import Controller, Key

        kb = Controller()
        kb.press(Key.ctrl)
        kb.press("v")
        kb.release("v")
        kb.release(Key.ctrl)
        logger.info("Auto-pasted via Ctrl+V")
        return True
    except Exception as e:
        logger.error(f"Auto-paste error: {e}")
        return False
