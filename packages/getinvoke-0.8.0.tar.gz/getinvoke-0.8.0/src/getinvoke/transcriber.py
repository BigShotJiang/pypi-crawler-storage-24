"""Whisper model loading + transcription."""

import ctypes
import io
import logging
import sys
import time
from pathlib import Path

from getinvoke.config import settings

logger = logging.getLogger(__name__)

_model = None
_is_mlx = False

# MLX model name mapping (Invoke model names → HuggingFace repo IDs)
_MLX_MODELS = {
    "tiny": "mlx-community/whisper-tiny-mlx",
    "base": "mlx-community/whisper-base-mlx",
    "small": "mlx-community/whisper-small-mlx",
    "medium": "mlx-community/whisper-medium-mlx",
    "large-v3": "mlx-community/whisper-large-v3-mlx",
    "distil-large-v3": "mlx-community/distil-whisper-large-v3",
}


def _preload_cuda_libs() -> None:
    """Pre-load CUDA .so files from nvidia-* Python packages so ctranslate2 can find them."""
    for search_path in sys.path:
        nvidia_dir = Path(search_path) / "nvidia"
        if not nvidia_dir.is_dir():
            continue
        for pkg_dir in nvidia_dir.iterdir():
            lib_dir = pkg_dir / "lib"
            if not lib_dir.is_dir():
                continue
            for so_file in sorted(lib_dir.glob("*.so.*")):
                try:
                    ctypes.CDLL(str(so_file))
                except OSError:
                    pass


def load_model() -> None:
    """Load the Whisper model. Call once at startup."""
    global _model, _is_mlx

    if settings.WHISPER_DEVICE == "mlx":
        # MLX-Whisper loads the model on first transcribe call
        _is_mlx = True
        _model = True  # Sentinel — mlx_whisper.transcribe() handles model internally
        mlx_repo = _MLX_MODELS.get(settings.WHISPER_MODEL, f"mlx-community/whisper-{settings.WHISPER_MODEL}-mlx")
        logger.info(f"Using MLX-Whisper on Apple Silicon (model: {mlx_repo})")
        return

    _preload_cuda_libs()
    from faster_whisper import WhisperModel

    logger.info(f"Loading Whisper model '{settings.WHISPER_MODEL}' on {settings.WHISPER_DEVICE}...")
    start = time.time()
    _model = WhisperModel(
        settings.WHISPER_MODEL,
        device=settings.WHISPER_DEVICE,
        compute_type=settings.whisper_compute_type,
    )
    elapsed = time.time() - start
    logger.info(f"Whisper model loaded in {elapsed:.1f}s")


def unload_model() -> None:
    """Unload the Whisper model."""
    global _model
    if _model is not None:
        del _model
        _model = None
        logger.info("Whisper model unloaded")


def transcribe(audio_data: bytes | str, hotwords: list[str] | None = None) -> str:
    """Transcribe audio data (WAV bytes or file path) to text.

    Args:
        audio_data: Either WAV file bytes (from recorder) or a file path string.
        hotwords: Optional list of custom vocabulary words to boost recognition.

    Returns:
        Transcribed text string.
    """
    if _model is None:
        raise RuntimeError("Whisper model not loaded. Call load_model() first.")

    if _is_mlx:
        return _transcribe_mlx(audio_data, hotwords)
    return _transcribe_faster_whisper(audio_data, hotwords)


def _transcribe_mlx(audio_data: bytes | str, hotwords: list[str] | None = None) -> str:
    """Transcribe via MLX-Whisper (Apple Silicon GPU)."""
    import os
    import tempfile

    import mlx_whisper

    # MLX-Whisper expects a file path
    temp_path = None
    if isinstance(audio_data, bytes):
        with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
            f.write(audio_data)
            temp_path = f.name
    else:
        temp_path = audio_data

    try:
        model_repo = _MLX_MODELS.get(settings.WHISPER_MODEL, f"mlx-community/whisper-{settings.WHISPER_MODEL}-mlx")
        kwargs: dict = {"path_or_hf_repo": model_repo}
        if settings.LANGUAGE and settings.LANGUAGE != "auto":
            kwargs["language"] = settings.LANGUAGE
        if hotwords:
            kwargs["initial_prompt"] = ", ".join(hotwords)

        start = time.time()
        result = mlx_whisper.transcribe(temp_path, **kwargs)
        text = result.get("text", "").strip()
        elapsed = time.time() - start
        logger.info(f"MLX transcription done in {elapsed:.1f}s: {text[:100]}...")
        return text
    finally:
        if isinstance(audio_data, bytes) and temp_path is not None:
            os.unlink(temp_path)


def _transcribe_faster_whisper(audio_data: bytes | str, hotwords: list[str] | None = None) -> str:
    """Transcribe via faster-whisper (CUDA/CPU)."""
    # Accept both bytes (in-memory) and file paths
    if isinstance(audio_data, bytes):
        source = io.BytesIO(audio_data)
    else:
        source = audio_data

    # Build transcription kwargs
    kwargs: dict = {
        "beam_size": 5,
        "vad_filter": True,
        "vad_parameters": {"min_silence_duration_ms": 500},
    }

    # Language: explicit language or omit for auto-detect
    if settings.LANGUAGE and settings.LANGUAGE != "auto":
        kwargs["language"] = settings.LANGUAGE

    # Add hotwords if provided (boosts recognition of custom vocabulary)
    if hotwords:
        kwargs["hotwords"] = " ".join(hotwords)
        logger.debug(f"Using hotwords: {hotwords}")

    start = time.time()
    try:
        segments, _info = _model.transcribe(source, **kwargs)
        text = " ".join(seg.text.strip() for seg in segments)
    except RuntimeError as e:
        err = str(e).lower()
        if "not found or cannot be loaded" in err or "cublas" in err:
            logger.warning(f"CUDA runtime error: {e}")
            logger.warning("Falling back to CPU — install CUDA Toolkit 12.x for GPU acceleration")
            _reload_model_on_cpu()
            # Re-create source since the generator may have consumed it
            if isinstance(audio_data, bytes):
                source = io.BytesIO(audio_data)
            else:
                source = audio_data
            segments, _info = _model.transcribe(source, **kwargs)
            text = " ".join(seg.text.strip() for seg in segments)
        else:
            raise
    elapsed = time.time() - start
    logger.info(f"Transcription done in {elapsed:.1f}s: {text[:100]}...")
    return text


def _reload_model_on_cpu() -> None:
    """Reload the Whisper model on CPU after a CUDA runtime failure."""
    global _model
    from faster_whisper import WhisperModel

    logger.info("Reloading Whisper model on CPU...")
    start = time.time()
    _model = WhisperModel(settings.WHISPER_MODEL, device="cpu", compute_type="int8")
    settings.WHISPER_DEVICE = "cpu"
    elapsed = time.time() - start
    logger.info(f"Model reloaded on CPU in {elapsed:.1f}s")
