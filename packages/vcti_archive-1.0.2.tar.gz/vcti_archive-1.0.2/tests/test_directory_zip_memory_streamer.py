# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Tests for vcti.archive.directory_zip_memory_streamer module."""

import io
import zipfile

import pytest

from vcti.archive.directory_zip_memory_streamer import DirectoryZipMemoryStreamer


class TestDirectoryZipMemoryStreamerInit:
    def test_raises_on_non_directory(self, tmp_path):
        file_path = tmp_path / "file.txt"
        file_path.write_text("hello")
        with pytest.raises(ValueError):
            DirectoryZipMemoryStreamer(file_path)

    def test_raises_on_nonexistent_path(self, tmp_path):
        with pytest.raises(ValueError):
            DirectoryZipMemoryStreamer(tmp_path / "nonexistent")

    def test_accepts_valid_directory(self, source_dir):
        streamer = DirectoryZipMemoryStreamer(source_dir)
        assert streamer.directory_path == source_dir.resolve()

    def test_default_chunk_size(self, source_dir):
        streamer = DirectoryZipMemoryStreamer(source_dir)
        assert streamer.chunk_size == 65536

    def test_custom_chunk_size(self, source_dir):
        streamer = DirectoryZipMemoryStreamer(source_dir, chunk_size=1024)
        assert streamer.chunk_size == 1024


class TestDirectoryZipMemoryStreamerOutput:
    def test_yields_bytes(self, source_dir):
        streamer = DirectoryZipMemoryStreamer(source_dir)
        chunks = list(streamer)
        assert all(isinstance(chunk, bytes) for chunk in chunks)

    def test_output_is_valid_zip(self, source_dir):
        streamer = DirectoryZipMemoryStreamer(source_dir)
        data = b"".join(streamer)
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            assert zf.testzip() is None

    def test_zip_contains_expected_files(self, source_dir):
        streamer = DirectoryZipMemoryStreamer(source_dir)
        data = b"".join(streamer)
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            names = zf.namelist()
        assert "file1.txt" in names
        assert "sub/file2.txt" in names

    def test_zip_file_content_is_correct(self, source_dir):
        streamer = DirectoryZipMemoryStreamer(source_dir)
        data = b"".join(streamer)
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            assert zf.read("file1.txt") == b"content1"
            assert zf.read("sub/file2.txt") == b"content2"

    def test_empty_directory_produces_valid_zip(self, tmp_path):
        streamer = DirectoryZipMemoryStreamer(tmp_path)
        data = b"".join(streamer)
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            assert zf.namelist() == []

    def test_small_chunk_size_yields_multiple_chunks(self, tmp_path):
        large_content = "x" * 10000
        (tmp_path / "large.txt").write_text(large_content)
        streamer = DirectoryZipMemoryStreamer(tmp_path, chunk_size=64)
        chunks = list(streamer)
        assert len(chunks) > 1
        assert all(isinstance(c, bytes) for c in chunks)

    def test_chunk_yielded_during_iteration(self, tmp_path):
        for i in range(5):
            (tmp_path / f"file{i}.txt").write_text("A" * 500)
        streamer = DirectoryZipMemoryStreamer(tmp_path, chunk_size=100)
        chunks = list(streamer)
        assert len(chunks) >= 2
        data = b"".join(chunks)
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            assert len(zf.namelist()) == 5


class TestBufferIntegrity:
    """Verify no data loss when files exceed chunk_size (buffer bug fix)."""

    def test_large_file_content_preserved_through_chunking(self, tmp_path):
        content = "X" * 200_000  # 200KB, well above 64KB chunk
        (tmp_path / "large.bin").write_text(content)
        streamer = DirectoryZipMemoryStreamer(tmp_path, chunk_size=1024)
        data = b"".join(streamer)
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            assert zf.read("large.bin").decode() == content

    def test_many_files_larger_than_chunk(self, tmp_path):
        for i in range(10):
            (tmp_path / f"file{i}.dat").write_text("Y" * 5000)
        streamer = DirectoryZipMemoryStreamer(tmp_path, chunk_size=256)
        data = b"".join(streamer)
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            assert len(zf.namelist()) == 10
            for i in range(10):
                assert zf.read(f"file{i}.dat") == b"Y" * 5000


class TestReusability:
    def test_can_iterate_twice(self, source_dir):
        streamer = DirectoryZipMemoryStreamer(source_dir)
        data1 = b"".join(streamer)
        data2 = b"".join(streamer)
        # Both iterations should produce valid (and identical) ZIPs
        with zipfile.ZipFile(io.BytesIO(data1)) as zf1:
            assert zf1.testzip() is None
        with zipfile.ZipFile(io.BytesIO(data2)) as zf2:
            assert zf2.testzip() is None
        assert data1 == data2


class TestFileFiltering:
    def test_exclude_hidden_files(self, tmp_path):
        (tmp_path / "visible.txt").write_text("yes")
        (tmp_path / ".hidden").write_text("no")
        streamer = DirectoryZipMemoryStreamer(tmp_path, exclude=lambda p: p.name.startswith("."))
        data = b"".join(streamer)
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            names = zf.namelist()
        assert "visible.txt" in names
        assert ".hidden" not in names

    def test_exclude_by_extension(self, tmp_path):
        (tmp_path / "keep.txt").write_text("yes")
        (tmp_path / "skip.log").write_text("no")
        streamer = DirectoryZipMemoryStreamer(tmp_path, exclude=lambda p: p.suffix == ".log")
        data = b"".join(streamer)
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            names = zf.namelist()
        assert "keep.txt" in names
        assert "skip.log" not in names


class TestLargeFileStreaming:
    """Validate streaming integrity for files that span many chunks."""

    def test_single_large_file_content_correct(self, tmp_path):
        """500 KB file with 1 KB chunks — content must survive."""
        content = "Z" * 500_000
        (tmp_path / "big.txt").write_text(content)
        streamer = DirectoryZipMemoryStreamer(tmp_path, chunk_size=1024)
        data = b"".join(streamer)
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            assert zf.read("big.txt").decode() == content

    def test_multiple_large_files_content_correct(self, tmp_path):
        """Several large files should all survive chunked streaming."""
        for i in range(5):
            (tmp_path / f"file{i}.dat").write_text(f"{'A' * 100_000}{i}")
        streamer = DirectoryZipMemoryStreamer(tmp_path, chunk_size=2048)
        data = b"".join(streamer)
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            for i in range(5):
                text = zf.read(f"file{i}.dat").decode()
                assert text == f"{'A' * 100_000}{i}"

    def test_chunk_count_increases_with_data(self, tmp_path):
        """More data should produce more chunks."""
        (tmp_path / "small.txt").write_text("x" * 100)
        small_chunks = len(list(DirectoryZipMemoryStreamer(tmp_path, chunk_size=64)))

        (tmp_path / "bigger.txt").write_text("y" * 50_000)
        big_chunks = len(list(DirectoryZipMemoryStreamer(tmp_path, chunk_size=64)))

        assert big_chunks > small_chunks


class TestEmptyAndSpecialFiles:
    def test_directory_with_only_empty_files(self, tmp_path):
        for i in range(10):
            (tmp_path / f"empty{i}.txt").write_text("")
        streamer = DirectoryZipMemoryStreamer(tmp_path)
        data = b"".join(streamer)
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            assert len(zf.namelist()) == 10
            for info in zf.infolist():
                assert zf.read(info.filename) == b""

    def test_binary_file_preserved(self, tmp_path):
        binary_data = bytes(range(256)) * 100
        (tmp_path / "binary.bin").write_bytes(binary_data)
        streamer = DirectoryZipMemoryStreamer(tmp_path, chunk_size=512)
        data = b"".join(streamer)
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            assert zf.read("binary.bin") == binary_data

    def test_deeply_nested_directory(self, tmp_path):
        deep = tmp_path
        for i in range(15):
            deep = deep / f"level{i}"
            deep.mkdir()
        (deep / "leaf.txt").write_text("found")
        streamer = DirectoryZipMemoryStreamer(tmp_path)
        data = b"".join(streamer)
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            names = zf.namelist()
            assert any("leaf.txt" in n for n in names)
            leaf_name = [n for n in names if "leaf.txt" in n][0]
            assert zf.read(leaf_name) == b"found"


class TestDirectoryZipMemoryStreamerErrors:
    def test_add_file_to_zip_error(self, tmp_path, monkeypatch):
        (tmp_path / "file.txt").write_text("data")
        streamer = DirectoryZipMemoryStreamer(tmp_path)
        # Monkeypatch zipfile.ZipFile.write to raise on any call
        _ = zipfile.ZipFile.__init__  # noqa: F841

        def patched_write(self, *a, **k):
            raise OSError("disk full")

        monkeypatch.setattr(zipfile.ZipFile, "write", patched_write)
        with pytest.raises(RuntimeError, match="ZIP streaming failed"):
            list(streamer)
