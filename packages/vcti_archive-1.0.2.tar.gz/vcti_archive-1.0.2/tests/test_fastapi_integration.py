# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Tests for vcti.archive.fastapi optional integration module."""

import asyncio
import io
import zipfile

import pytest

fastapi = pytest.importorskip("fastapi")
from fastapi import BackgroundTasks  # noqa: E402
from fastapi.responses import StreamingResponse  # noqa: E402

from vcti.archive.directory_zip_tempfile_streamer import LargeDirectoryZipStreamer  # noqa: E402
from vcti.archive.fastapi import streaming_zip_response  # noqa: E402


def _collect_body(response: StreamingResponse) -> bytes:
    """Consume response body, handling both sync and async iterators."""

    async def _async_collect(iterator):
        chunks = []
        async for chunk in iterator:
            chunks.append(chunk)
        return b"".join(chunks)

    try:
        return b"".join(response.body_iterator)
    except TypeError:
        return asyncio.run(_async_collect(response.body_iterator))


class TestStreamingZipResponseHeaders:
    def test_returns_streaming_response(self, source_dir):
        streamer = LargeDirectoryZipStreamer(source_dir, "archive.zip")
        response = streaming_zip_response(streamer, BackgroundTasks())
        assert isinstance(response, StreamingResponse)

    def test_response_media_type(self, source_dir):
        streamer = LargeDirectoryZipStreamer(source_dir, "archive.zip")
        response = streaming_zip_response(streamer, BackgroundTasks())
        assert response.media_type == "application/zip"

    def test_response_content_disposition(self, source_dir):
        streamer = LargeDirectoryZipStreamer(source_dir, "archive.zip")
        response = streaming_zip_response(streamer, BackgroundTasks())
        assert response.headers["content-disposition"] == "attachment; filename=archive.zip"

    def test_content_disposition_uses_archive_name(self, source_dir):
        streamer = LargeDirectoryZipStreamer(source_dir, "custom-name.zip")
        response = streaming_zip_response(streamer, BackgroundTasks())
        assert "custom-name.zip" in response.headers["content-disposition"]

    def test_response_has_content_length(self, source_dir):
        streamer = LargeDirectoryZipStreamer(source_dir, "archive.zip")
        response = streaming_zip_response(streamer, BackgroundTasks())
        assert "content-length" in response.headers
        assert int(response.headers["content-length"]) > 0

    def test_content_length_matches_actual_body(self, source_dir):
        streamer = LargeDirectoryZipStreamer(source_dir, "archive.zip")
        bt = BackgroundTasks()
        response = streaming_zip_response(streamer, bt)
        declared_length = int(response.headers["content-length"])
        actual_data = _collect_body(response)
        assert len(actual_data) == declared_length


class TestStreamingZipResponseBody:
    def test_body_is_valid_zip(self, source_dir):
        streamer = LargeDirectoryZipStreamer(source_dir, "archive.zip")
        response = streaming_zip_response(streamer, BackgroundTasks())
        data = _collect_body(response)
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            assert zf.testzip() is None

    def test_body_contains_expected_files(self, source_dir):
        streamer = LargeDirectoryZipStreamer(source_dir, "archive.zip")
        response = streaming_zip_response(streamer, BackgroundTasks())
        data = _collect_body(response)
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            names = zf.namelist()
        assert "file1.txt" in names
        assert "sub/file2.txt" in names

    def test_body_file_content_correct(self, source_dir):
        streamer = LargeDirectoryZipStreamer(source_dir, "archive.zip")
        response = streaming_zip_response(streamer, BackgroundTasks())
        data = _collect_body(response)
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            assert zf.read("file1.txt") == b"content1"
            assert zf.read("sub/file2.txt") == b"content2"

    def test_empty_directory_produces_valid_empty_zip(self, tmp_path):
        streamer = LargeDirectoryZipStreamer(tmp_path, "empty.zip")
        response = streaming_zip_response(streamer, BackgroundTasks())
        data = _collect_body(response)
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            assert zf.namelist() == []

    def test_large_directory_content_preserved(self, tmp_path):
        """Validate that larger files survive the streaming pipeline."""
        content = "W" * 200_000
        (tmp_path / "big.txt").write_text(content)
        streamer = LargeDirectoryZipStreamer(tmp_path, "big.zip")
        response = streaming_zip_response(streamer, BackgroundTasks())
        data = _collect_body(response)
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            assert zf.read("big.txt").decode() == content


class TestStreamingZipResponseFiltering:
    def test_exclude_filter_respected(self, tmp_path):
        (tmp_path / "keep.txt").write_text("yes")
        (tmp_path / "skip.log").write_text("no")
        streamer = LargeDirectoryZipStreamer(
            tmp_path, "filtered.zip", exclude=lambda p: p.suffix == ".log"
        )
        response = streaming_zip_response(streamer, BackgroundTasks())
        data = _collect_body(response)
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            names = zf.namelist()
        assert "keep.txt" in names
        assert "skip.log" not in names


class TestStreamingZipResponseCleanup:
    def test_background_task_registered(self, source_dir):
        """Verify that a background task is registered for cleanup."""
        bt = BackgroundTasks()
        streamer = LargeDirectoryZipStreamer(source_dir, "archive.zip")
        response = streaming_zip_response(streamer, bt)
        # Consume the body to trigger the finally block
        _collect_body(response)
        # BackgroundTasks should have at least one task registered
        assert len(bt.tasks) >= 1

    def test_multiple_responses_each_get_own_temp_file(self, source_dir):
        """Each call should create a separate temp file."""
        bt1 = BackgroundTasks()
        bt2 = BackgroundTasks()
        streamer = LargeDirectoryZipStreamer(source_dir, "archive.zip")
        response1 = streaming_zip_response(streamer, bt1)
        response2 = streaming_zip_response(streamer, bt2)
        data1 = _collect_body(response1)
        data2 = _collect_body(response2)
        # Both should produce identical, valid ZIPs
        assert data1 == data2
        with zipfile.ZipFile(io.BytesIO(data1)) as zf:
            assert zf.testzip() is None


class TestStreamingZipResponseChunking:
    def test_custom_chunk_size_respected(self, tmp_path):
        """Verify that the streamer's chunk_size is used for reading."""
        (tmp_path / "data.txt").write_text("A" * 50_000)
        streamer = LargeDirectoryZipStreamer(tmp_path, "out.zip", chunk_size=1024)
        bt = BackgroundTasks()
        response = streaming_zip_response(streamer, bt)
        # Collect individual chunks
        try:
            chunks = list(response.body_iterator)
        except TypeError:

            async def _collect_chunks(it):
                result = []
                async for c in it:
                    result.append(c)
                return result

            chunks = asyncio.run(_collect_chunks(response.body_iterator))
        # All chunks except possibly the last should be <= chunk_size
        for chunk in chunks[:-1]:
            assert len(chunk) <= 1024
        # Total should be a valid ZIP
        data = b"".join(chunks)
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            assert zf.read("data.txt") == b"A" * 50_000
