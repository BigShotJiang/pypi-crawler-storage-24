# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Tests for vcti.archive.extractor_base module."""

import asyncio
import io
import re

import pytest

import vcti.archive
from vcti.archive.extractor_base import ArchiveExtractor, UnsupportedArchiveFormat


class TestVersion:
    def test_version_exists(self):
        assert hasattr(vcti.archive, "__version__")

    def test_version_is_valid_semver(self):
        assert re.match(r"^\d+\.\d+\.\d+", vcti.archive.__version__)


class TestArchiveExtractorABC:
    def test_cannot_instantiate_directly(self, tmp_path):
        with pytest.raises(TypeError, match="abstract method"):
            ArchiveExtractor(io.BytesIO(b""), tmp_path)

    def test_subclass_must_implement_both_methods(self):
        class IncompleteExtractor(ArchiveExtractor):
            def extract_using_bytesio(self) -> None:
                pass

        with pytest.raises(TypeError, match="abstract method"):
            IncompleteExtractor(io.BytesIO(b""), ".")

    def test_concrete_subclass_works(self, tmp_path):
        class ConcreteExtractor(ArchiveExtractor):
            def extract_using_bytesio(self) -> None:
                pass

            def extract_using_tempfile(self) -> None:
                pass

        ext = ConcreteExtractor(io.BytesIO(b""), tmp_path)
        assert ext.target_dir == tmp_path

    def test_target_dir_converted_to_path(self, tmp_path):
        class ConcreteExtractor(ArchiveExtractor):
            def extract_using_bytesio(self) -> None:
                pass

            def extract_using_tempfile(self) -> None:
                pass

        ext = ConcreteExtractor(io.BytesIO(b""), str(tmp_path))
        assert isinstance(ext.target_dir, type(tmp_path))

    def test_max_total_size_stored(self, tmp_path):
        class ConcreteExtractor(ArchiveExtractor):
            def extract_using_bytesio(self) -> None:
                pass

            def extract_using_tempfile(self) -> None:
                pass

        ext = ConcreteExtractor(io.BytesIO(b""), tmp_path, max_total_size=1024)
        assert ext.max_total_size == 1024

    def test_max_file_count_stored(self, tmp_path):
        class ConcreteExtractor(ArchiveExtractor):
            def extract_using_bytesio(self) -> None:
                pass

            def extract_using_tempfile(self) -> None:
                pass

        ext = ConcreteExtractor(io.BytesIO(b""), tmp_path, max_file_count=10)
        assert ext.max_file_count == 10

    def test_defaults_are_none(self, tmp_path):
        class ConcreteExtractor(ArchiveExtractor):
            def extract_using_bytesio(self) -> None:
                pass

            def extract_using_tempfile(self) -> None:
                pass

        ext = ConcreteExtractor(io.BytesIO(b""), tmp_path)
        assert ext.max_total_size is None
        assert ext.max_file_count is None


class TestAsyncExtraction:
    def test_async_extract_using_bytesio(self, tmp_path):
        class ConcreteExtractor(ArchiveExtractor):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)
                self.bytesio_called = False

            def extract_using_bytesio(self) -> None:
                self.bytesio_called = True

            def extract_using_tempfile(self) -> None:
                pass

        ext = ConcreteExtractor(io.BytesIO(b""), tmp_path)
        asyncio.run(ext.async_extract_using_bytesio())
        assert ext.bytesio_called

    def test_async_extract_using_tempfile(self, tmp_path):
        class ConcreteExtractor(ArchiveExtractor):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, **kwargs)
                self.tempfile_called = False

            def extract_using_bytesio(self) -> None:
                pass

            def extract_using_tempfile(self) -> None:
                self.tempfile_called = True

        ext = ConcreteExtractor(io.BytesIO(b""), tmp_path)
        asyncio.run(ext.async_extract_using_tempfile())
        assert ext.tempfile_called


class TestUnsupportedArchiveFormat:
    def test_is_exception_subclass(self):
        assert issubclass(UnsupportedArchiveFormat, Exception)

    def test_can_be_raised_and_caught(self):
        with pytest.raises(UnsupportedArchiveFormat):
            raise UnsupportedArchiveFormat("unsupported format")

    def test_carries_message(self):
        exc = UnsupportedArchiveFormat("tar.bz2 not supported")
        assert "tar.bz2 not supported" in str(exc)
