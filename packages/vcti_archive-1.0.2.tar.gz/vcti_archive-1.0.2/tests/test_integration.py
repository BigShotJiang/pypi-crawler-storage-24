# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Integration tests exercising real filesystem scenarios.

These tests create actual files on disk (binary, read-only, symlinks,
deeply nested, mixed content) and verify end-to-end behavior through
the full extract and stream pipelines.  They complement the unit tests,
which use in-memory archives and mocks.
"""

import io
import stat
import struct
import zipfile
from pathlib import Path

import pytest
from conftest import make_targz_bytes

from vcti.archive import (
    DirectoryZipMemoryStreamer,
    LargeDirectoryZipStreamer,
    TarGzExtractor,
    ZipExtractor,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _create_test_tree(root: Path) -> dict[str, bytes]:
    """Create a realistic directory tree and return {relative_path: content}.

    The tree contains:
    - Plain text files (UTF-8)
    - A binary file with every byte value 0x00-0xFF
    - An empty file
    - A deeply nested file (10 levels)
    - A read-only file
    - Several files in subdirectories
    """
    files: dict[str, bytes] = {}

    # Plain text
    f = root / "readme.txt"
    content = b"Project readme\nLine 2\n"
    f.write_bytes(content)
    files["readme.txt"] = content

    # UTF-8 text with non-ASCII
    f = root / "notes" / "café.txt"
    f.parent.mkdir(parents=True, exist_ok=True)
    content = "Résumé des données — 2026\n".encode()
    f.write_bytes(content)
    files["notes/café.txt"] = content

    # Binary file: every byte value
    f = root / "data" / "binary.bin"
    f.parent.mkdir(parents=True, exist_ok=True)
    content = bytes(range(256)) * 40  # 10 KB
    f.write_bytes(content)
    files["data/binary.bin"] = content

    # Structured binary (simulated little-endian header)
    f = root / "data" / "header.dat"
    content = struct.pack("<4sII", b"VCTI", 1, 42) + b"\x00" * 100
    f.write_bytes(content)
    files["data/header.dat"] = content

    # Empty file
    f = root / "empty.txt"
    f.write_bytes(b"")
    files["empty.txt"] = b""

    # Deeply nested
    deep = root
    for i in range(10):
        deep = deep / f"level{i}"
    deep.mkdir(parents=True, exist_ok=True)
    f = deep / "deep.txt"
    content = b"found at depth 10"
    f.write_bytes(content)
    rel = str(f.relative_to(root)).replace("\\", "/")
    files[rel] = content

    # Multiple files in one directory
    bulk_dir = root / "bulk"
    bulk_dir.mkdir()
    for i in range(20):
        f = bulk_dir / f"item_{i:03d}.txt"
        content = f"item {i}\n".encode()
        f.write_bytes(content)
        files[f"bulk/item_{i:03d}.txt"] = content

    # Read-only file (restore permissions in fixture teardown)
    f = root / "readonly.txt"
    content = b"do not modify"
    f.write_bytes(content)
    f.chmod(stat.S_IRUSR | stat.S_IRGRP | stat.S_IROTH)
    files["readonly.txt"] = content

    return files


@pytest.fixture
def test_tree(tmp_path):
    """Create the test directory tree and clean up read-only files after."""
    root = tmp_path / "source"
    root.mkdir()
    files = _create_test_tree(root)
    yield root, files
    # Restore write permissions so tmp_path cleanup doesn't fail
    for p in root.rglob("*"):
        if p.is_file():
            p.chmod(stat.S_IRUSR | stat.S_IWUSR)


# ---------------------------------------------------------------------------
# Round-trip: directory → ZIP stream → extract → verify
# ---------------------------------------------------------------------------


class TestRoundTripMemoryStreamer:
    """Stream a real directory as ZIP, extract it, verify every file."""

    def test_full_round_trip(self, test_tree, tmp_path):
        source, expected_files = test_tree

        # Stream
        streamer = DirectoryZipMemoryStreamer(source)
        zip_data = b"".join(streamer)

        # Verify ZIP is valid
        with zipfile.ZipFile(io.BytesIO(zip_data)) as zf:
            assert zf.testzip() is None

        # Extract via ZipExtractor
        target = tmp_path / "extracted"
        extractor = ZipExtractor(io.BytesIO(zip_data), target)
        extractor.extract_using_bytesio()

        # Verify every file
        for rel_path, content in expected_files.items():
            extracted = target / rel_path
            assert extracted.exists(), f"Missing: {rel_path}"
            assert extracted.read_bytes() == content, f"Content mismatch: {rel_path}"

    def test_round_trip_with_small_chunks(self, test_tree, tmp_path):
        """Same round trip but with very small chunks to stress chunking."""
        source, expected_files = test_tree

        streamer = DirectoryZipMemoryStreamer(source, chunk_size=512)
        zip_data = b"".join(streamer)

        target = tmp_path / "extracted"
        extractor = ZipExtractor(io.BytesIO(zip_data), target)
        extractor.extract_using_bytesio()

        for rel_path, content in expected_files.items():
            assert (target / rel_path).read_bytes() == content


class TestRoundTripTempfileStreamer:
    """Same round trip using LargeDirectoryZipStreamer."""

    def test_full_round_trip(self, test_tree, tmp_path):
        source, expected_files = test_tree

        streamer = LargeDirectoryZipStreamer(
            folder_path=source,
            archive_name="test.zip",
        )
        zip_data = b"".join(streamer.stream())

        target = tmp_path / "extracted"
        extractor = ZipExtractor(io.BytesIO(zip_data), target)
        extractor.extract_using_bytesio()

        for rel_path, content in expected_files.items():
            extracted = target / rel_path
            assert extracted.exists(), f"Missing: {rel_path}"
            assert extracted.read_bytes() == content, f"Content mismatch: {rel_path}"


# ---------------------------------------------------------------------------
# Round-trip: TAR.GZ create → extract → verify
# ---------------------------------------------------------------------------


class TestRoundTripTarGz:
    """Create a tar.gz from known content, extract, verify."""

    def test_tar_gz_round_trip(self, test_tree, tmp_path):
        _, expected_files = test_tree
        targz_bytes = make_targz_bytes({k: v for k, v in expected_files.items()})

        target = tmp_path / "extracted"
        extractor = TarGzExtractor(io.BytesIO(targz_bytes), target)
        extractor.extract_using_bytesio()

        for rel_path, content in expected_files.items():
            extracted = target / rel_path
            assert extracted.exists(), f"Missing: {rel_path}"
            assert extracted.read_bytes() == content, f"Content mismatch: {rel_path}"


# ---------------------------------------------------------------------------
# Symlink handling
# ---------------------------------------------------------------------------

_symlinks_available = True
try:
    import tempfile as _tf

    with _tf.TemporaryDirectory() as _td:
        _t = Path(_td) / "t"
        _t.write_text("x")
        (Path(_td) / "l").symlink_to(_t)
except OSError:
    _symlinks_available = False


@pytest.mark.skipif(
    not _symlinks_available,
    reason="Symlinks require elevated privileges on this OS",
)
class TestSymlinks:
    """Verify streamers handle symlinks correctly."""

    def test_memory_streamer_follows_symlinks(self, tmp_path):
        real = tmp_path / "real.txt"
        real.write_text("real content")
        link = tmp_path / "link.txt"
        link.symlink_to(real)

        streamer = DirectoryZipMemoryStreamer(tmp_path)
        data = b"".join(streamer)
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            assert zf.read("link.txt") == b"real content"
            assert zf.read("real.txt") == b"real content"

    def test_tempfile_streamer_follows_symlinks(self, tmp_path):
        real = tmp_path / "real.txt"
        real.write_text("real content")
        link = tmp_path / "link.txt"
        link.symlink_to(real)

        s = LargeDirectoryZipStreamer(tmp_path, "out.zip")
        data = b"".join(s.stream())
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            assert zf.read("link.txt") == b"real content"


# ---------------------------------------------------------------------------
# File filtering integration
# ---------------------------------------------------------------------------


class TestFilteringIntegration:
    """Verify exclude filter works across a realistic tree."""

    def test_exclude_removes_matching_files(self, test_tree, tmp_path):
        source, expected_files = test_tree

        # Exclude all .txt files
        streamer = DirectoryZipMemoryStreamer(source, exclude=lambda p: p.suffix == ".txt")
        data = b"".join(streamer)
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            names = set(zf.namelist())

        # Only non-.txt files should remain
        for rel_path in expected_files:
            normalized = rel_path.replace("\\", "/")
            if normalized.endswith(".txt"):
                assert normalized not in names, f"Should be excluded: {normalized}"
            else:
                assert normalized in names, f"Should be included: {normalized}"

    def test_exclude_with_tempfile_streamer(self, test_tree, tmp_path):
        source, _ = test_tree

        s = LargeDirectoryZipStreamer(
            source,
            "out.zip",
            exclude=lambda p: p.name.startswith("item_"),
        )
        data = b"".join(s.stream())
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            names = zf.namelist()
        assert not any("item_" in n for n in names)
        # Other files should still be present
        assert any("readme.txt" in n for n in names)


# ---------------------------------------------------------------------------
# Read-only file handling
# ---------------------------------------------------------------------------


class TestReadOnlyFiles:
    """Verify that read-only files can be archived and extracted."""

    def test_memory_streamer_includes_readonly(self, test_tree):
        source, expected_files = test_tree
        streamer = DirectoryZipMemoryStreamer(source)
        data = b"".join(streamer)
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            assert zf.read("readonly.txt") == b"do not modify"

    def test_extractor_writes_readonly_content(self, test_tree, tmp_path):
        source, _ = test_tree
        streamer = DirectoryZipMemoryStreamer(source)
        zip_data = b"".join(streamer)

        target = tmp_path / "out"
        ZipExtractor(io.BytesIO(zip_data), target).extract_using_bytesio()
        assert (target / "readonly.txt").read_bytes() == b"do not modify"


# ---------------------------------------------------------------------------
# Bomb protection in integration context
# ---------------------------------------------------------------------------


class TestBombProtectionIntegration:
    """Verify limits work on a realistic tree (not just synthetic archives)."""

    def test_rejects_tree_exceeding_file_count(self, test_tree, tmp_path):
        source, expected_files = test_tree
        streamer = DirectoryZipMemoryStreamer(source)
        zip_data = b"".join(streamer)

        # The tree has 20 bulk + ~6 other files ≈ 26+
        extractor = ZipExtractor(
            io.BytesIO(zip_data),
            tmp_path / "out",
            max_file_count=5,
        )
        with pytest.raises(ValueError, match="exceeding limit"):
            extractor.extract_using_bytesio()

    def test_allows_tree_within_limits(self, test_tree, tmp_path):
        source, expected_files = test_tree
        streamer = DirectoryZipMemoryStreamer(source)
        zip_data = b"".join(streamer)

        extractor = ZipExtractor(
            io.BytesIO(zip_data),
            tmp_path / "out",
            max_file_count=1000,
            max_total_size=100_000_000,
        )
        extractor.extract_using_bytesio()
        assert (tmp_path / "out" / "readme.txt").exists()
