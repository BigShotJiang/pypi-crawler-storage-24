# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Tests for vcti.archive.targz_extractor module."""

import io
import tarfile

import pytest
from conftest import make_targz_bytes

from vcti.archive.extractor_base import ArchiveExtractor
from vcti.archive.targz_extractor import TarGzExtractor


@pytest.fixture
def targz_stream():
    content = make_targz_bytes({"hello.txt": "hello", "sub/world.txt": "world"})
    return io.BytesIO(content)


class TestTarGzExtractorInit:
    def test_inherits_from_archive_extractor(self, tmp_path):
        extractor = TarGzExtractor(io.BytesIO(b""), tmp_path)
        assert isinstance(extractor, ArchiveExtractor)

    def test_stores_archive_and_target(self, tmp_path, targz_stream):
        extractor = TarGzExtractor(targz_stream, tmp_path)
        assert extractor.archive is targz_stream
        assert extractor.target_dir == tmp_path


class TestExtractUsingBytesIO:
    def test_extracts_files(self, tmp_path, targz_stream):
        TarGzExtractor(targz_stream, tmp_path).extract_using_bytesio()
        assert (tmp_path / "hello.txt").read_text() == "hello"

    def test_extracts_nested_files(self, tmp_path, targz_stream):
        TarGzExtractor(targz_stream, tmp_path).extract_using_bytesio()
        assert (tmp_path / "sub" / "world.txt").read_text() == "world"

    def test_raises_on_invalid_targz(self, tmp_path):
        with pytest.raises(tarfile.TarError):
            TarGzExtractor(io.BytesIO(b"not a tar"), tmp_path).extract_using_bytesio()

    def test_creates_target_dir_if_missing(self, tmp_path, targz_stream):
        target = tmp_path / "new" / "dir"
        TarGzExtractor(targz_stream, target).extract_using_bytesio()
        assert (target / "hello.txt").read_text() == "hello"


class TestExtractUsingTempfile:
    def test_extracts_files(self, tmp_path, targz_stream):
        TarGzExtractor(targz_stream, tmp_path).extract_using_tempfile()
        assert (tmp_path / "hello.txt").read_text() == "hello"

    def test_extracts_nested_files(self, tmp_path, targz_stream):
        TarGzExtractor(targz_stream, tmp_path).extract_using_tempfile()
        assert (tmp_path / "sub" / "world.txt").read_text() == "world"

    def test_creates_target_dir_if_missing(self, tmp_path, targz_stream):
        target = tmp_path / "new" / "dir"
        TarGzExtractor(targz_stream, target).extract_using_tempfile()
        assert (target / "hello.txt").read_text() == "hello"


class TestPathTraversalProtection:
    """tar filter='data' rejects .. components via OutsideDestinationError.

    The exception hierarchy is:
        OutsideDestinationError -> FilterError -> TarError
    We assert on TarError so the test stays stable across Python versions
    while still being specific enough to distinguish from unrelated errors.
    """

    def _make_traversal_targz(self) -> io.BytesIO:
        buf = io.BytesIO()
        with tarfile.open(fileobj=buf, mode="w:gz") as tf:
            info = tarfile.TarInfo(name="../../etc/evil.txt")
            data = b"pwned"
            info.size = len(data)
            tf.addfile(info, io.BytesIO(data))
        return io.BytesIO(buf.getvalue())

    def test_rejects_path_traversal_bytesio(self, tmp_path):
        stream = self._make_traversal_targz()
        with pytest.raises(tarfile.TarError, match="outside"):
            TarGzExtractor(stream, tmp_path).extract_using_bytesio()

    def test_rejects_path_traversal_tempfile(self, tmp_path):
        stream = self._make_traversal_targz()
        with pytest.raises(tarfile.TarError, match="outside"):
            TarGzExtractor(stream, tmp_path).extract_using_tempfile()


class TestBombProtection:
    def test_rejects_exceeding_file_count(self, tmp_path):
        files = {f"file{i}.txt": "x" for i in range(10)}
        stream = io.BytesIO(make_targz_bytes(files))
        ext = TarGzExtractor(stream, tmp_path, max_file_count=5)
        with pytest.raises(ValueError, match="exceeding limit"):
            ext.extract_using_bytesio()

    def test_rejects_exceeding_total_size(self, tmp_path):
        content = make_targz_bytes({"big.txt": "x" * 10000})
        ext = TarGzExtractor(io.BytesIO(content), tmp_path, max_total_size=100)
        with pytest.raises(ValueError, match="exceeds limit"):
            ext.extract_using_bytesio()

    def test_allows_within_limits(self, tmp_path):
        files = {"a.txt": "hello", "b.txt": "world"}
        stream = io.BytesIO(make_targz_bytes(files))
        ext = TarGzExtractor(stream, tmp_path, max_file_count=10, max_total_size=1_000_000)
        ext.extract_using_bytesio()
        assert (tmp_path / "a.txt").read_text() == "hello"


class TestEdgeCases:
    def test_empty_targz(self, tmp_path):
        content = make_targz_bytes({})
        TarGzExtractor(io.BytesIO(content), tmp_path).extract_using_bytesio()

    def test_empty_file_in_archive(self, tmp_path):
        content = make_targz_bytes({"empty.txt": ""})
        TarGzExtractor(io.BytesIO(content), tmp_path).extract_using_bytesio()
        assert (tmp_path / "empty.txt").read_text() == ""

    def test_multiple_empty_files(self, tmp_path):
        files = {f"empty_{i}.txt": "" for i in range(5)}
        content = make_targz_bytes(files)
        TarGzExtractor(io.BytesIO(content), tmp_path).extract_using_bytesio()
        for i in range(5):
            assert (tmp_path / f"empty_{i}.txt").read_text() == ""

    def test_binary_content_preserved(self, tmp_path):
        binary_data = bytes(range(256))
        content = make_targz_bytes({"binary.bin": binary_data})
        TarGzExtractor(io.BytesIO(content), tmp_path).extract_using_bytesio()
        assert (tmp_path / "binary.bin").read_bytes() == binary_data

    def test_large_file_bytesio(self, tmp_path):
        large_content = "X" * 500_000
        content = make_targz_bytes({"large.txt": large_content})
        TarGzExtractor(io.BytesIO(content), tmp_path).extract_using_bytesio()
        assert (tmp_path / "large.txt").read_text() == large_content

    def test_large_file_tempfile(self, tmp_path):
        large_content = "Y" * 500_000
        content = make_targz_bytes({"large.txt": large_content})
        TarGzExtractor(io.BytesIO(content), tmp_path).extract_using_tempfile()
        assert (tmp_path / "large.txt").read_text() == large_content

    def test_many_files(self, tmp_path):
        files = {f"dir{i // 10}/file{i}.txt": f"c{i}" for i in range(50)}
        content = make_targz_bytes(files)
        TarGzExtractor(io.BytesIO(content), tmp_path).extract_using_bytesio()
        assert (tmp_path / "dir0" / "file0.txt").read_text() == "c0"
        assert (tmp_path / "dir4" / "file49.txt").read_text() == "c49"

    def test_corrupted_targz_tempfile(self, tmp_path):
        with pytest.raises(tarfile.TarError):
            TarGzExtractor(io.BytesIO(b"not a tar"), tmp_path).extract_using_tempfile()

    def test_extract_same_stream_twice_with_seek(self, tmp_path):
        content = make_targz_bytes({"a.txt": "hello"})
        stream = io.BytesIO(content)
        target1 = tmp_path / "first"
        target2 = tmp_path / "second"
        TarGzExtractor(stream, target1).extract_using_bytesio()
        TarGzExtractor(stream, target2).extract_using_bytesio()
        assert (target1 / "a.txt").read_text() == "hello"
        assert (target2 / "a.txt").read_text() == "hello"
