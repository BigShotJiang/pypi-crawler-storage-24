# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Tests for vcti.archive.directory_zip_tempfile_streamer module."""

import io
import zipfile
from pathlib import Path

import pytest

from vcti.archive.directory_zip_tempfile_streamer import LargeDirectoryZipStreamer


@pytest.fixture
def streamer(source_dir):
    return LargeDirectoryZipStreamer(
        folder_path=source_dir,
        archive_name="archive.zip",
    )


class TestLargeDirectoryZipStreamerInit:
    def test_stores_folder_path(self, source_dir):
        s = LargeDirectoryZipStreamer(source_dir, "out.zip")
        assert s.folder_path == source_dir.resolve()

    def test_stores_archive_name(self, source_dir):
        s = LargeDirectoryZipStreamer(source_dir, "out.zip")
        assert s.archive_name == "out.zip"

    def test_default_chunk_size(self, source_dir):
        s = LargeDirectoryZipStreamer(source_dir, "out.zip")
        assert s.chunk_size == 65536

    def test_raises_on_missing_folder(self, tmp_path):
        with pytest.raises(FileNotFoundError):
            LargeDirectoryZipStreamer(tmp_path / "nonexistent", "out.zip")

    def test_raises_on_non_directory(self, tmp_path):
        f = tmp_path / "file.txt"
        f.write_text("hello")
        with pytest.raises(ValueError):
            LargeDirectoryZipStreamer(f, "out.zip")


class TestGenerateZip:
    def test_creates_valid_zip(self, streamer):
        zip_path = streamer._generate_zip()
        assert zip_path.exists()
        with zipfile.ZipFile(zip_path) as zf:
            assert zf.testzip() is None
        zip_path.unlink()

    def test_zip_contains_expected_files(self, streamer):
        zip_path = streamer._generate_zip()
        with zipfile.ZipFile(zip_path) as zf:
            names = zf.namelist()
        zip_path.unlink()
        assert "file1.txt" in names
        assert "sub/file2.txt" in names


class TestStream:
    def test_stream_yields_bytes(self, streamer):
        chunks = list(streamer.stream())
        assert all(isinstance(c, bytes) for c in chunks)

    def test_stream_produces_valid_zip(self, streamer):
        data = b"".join(streamer.stream())
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            assert zf.testzip() is None


class TestOnCleanup:
    def test_cleanup_callback_called(self, source_dir):
        cleaned = []
        s = LargeDirectoryZipStreamer(
            source_dir,
            "out.zip",
            on_cleanup=lambda p: cleaned.append(p),
        )
        list(s.stream())
        assert len(cleaned) == 1
        assert isinstance(cleaned[0], Path)

    def test_default_cleanup_removes_file(self, streamer):
        zip_path = streamer._generate_zip()
        assert zip_path.exists()
        # Consume the stream (which triggers cleanup in finally)
        list(streamer._stream_chunks(zip_path))
        # Default cleanup removes synchronously
        assert not zip_path.exists()


class TestCleanupTempFile:
    def test_cleanup_removes_file(self, streamer, tmp_path):
        temp_file = tmp_path / "temp.zip"
        temp_file.write_text("dummy")
        streamer._cleanup_temp_file(temp_file)
        assert not temp_file.exists()

    def test_cleanup_handles_missing_file(self, streamer, tmp_path):
        temp_file = tmp_path / "nonexistent.zip"
        # Should not raise
        streamer._cleanup_temp_file(temp_file)

    def test_cleanup_handles_permission_error(self, streamer, tmp_path, monkeypatch):
        temp_file = tmp_path / "locked.zip"
        temp_file.write_text("dummy")
        monkeypatch.setattr(
            Path,
            "unlink",
            lambda self: (_ for _ in ()).throw(PermissionError("locked")),
        )
        # Should not raise
        streamer._cleanup_temp_file(temp_file)


class TestFileFiltering:
    def test_exclude_files(self, tmp_path):
        (tmp_path / "keep.txt").write_text("yes")
        (tmp_path / "skip.log").write_text("no")
        s = LargeDirectoryZipStreamer(tmp_path, "out.zip", exclude=lambda p: p.suffix == ".log")
        data = b"".join(s.stream())
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            names = zf.namelist()
        assert "keep.txt" in names
        assert "skip.log" not in names


class TestLargeDirectoryStreaming:
    """Validate integrity for directories with large or many files."""

    def test_large_file_content_preserved(self, tmp_path):
        content = "Z" * 500_000
        (tmp_path / "big.txt").write_text(content)
        s = LargeDirectoryZipStreamer(tmp_path, "out.zip")
        data = b"".join(s.stream())
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            assert zf.read("big.txt").decode() == content

    def test_many_files(self, tmp_path):
        for i in range(50):
            (tmp_path / f"file{i}.txt").write_text(f"content{i}")
        s = LargeDirectoryZipStreamer(tmp_path, "out.zip")
        data = b"".join(s.stream())
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            assert len(zf.namelist()) == 50
            assert zf.read("file0.txt") == b"content0"
            assert zf.read("file49.txt") == b"content49"

    def test_empty_directory(self, tmp_path):
        s = LargeDirectoryZipStreamer(tmp_path, "empty.zip")
        data = b"".join(s.stream())
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            assert zf.namelist() == []

    def test_empty_files_only(self, tmp_path):
        for i in range(5):
            (tmp_path / f"empty{i}.txt").write_text("")
        s = LargeDirectoryZipStreamer(tmp_path, "out.zip")
        data = b"".join(s.stream())
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            assert len(zf.namelist()) == 5
            for info in zf.infolist():
                assert zf.read(info.filename) == b""

    def test_binary_content_preserved(self, tmp_path):
        binary_data = bytes(range(256)) * 100
        (tmp_path / "binary.bin").write_bytes(binary_data)
        s = LargeDirectoryZipStreamer(tmp_path, "out.zip")
        data = b"".join(s.stream())
        with zipfile.ZipFile(io.BytesIO(data)) as zf:
            assert zf.read("binary.bin") == binary_data

    def test_custom_chunk_size(self, tmp_path):
        import os

        # Use random-ish bytes that don't compress well
        (tmp_path / "data.bin").write_bytes(os.urandom(50_000))
        s = LargeDirectoryZipStreamer(tmp_path, "out.zip", chunk_size=1024)
        chunks = list(s.stream())
        assert len(chunks) > 1
        # All chunks except the last should be exactly chunk_size
        for chunk in chunks[:-1]:
            assert len(chunk) <= 1024


class TestGenerateZipError:
    def test_generate_zip_cleans_up_on_error(self, source_dir, monkeypatch):
        s = LargeDirectoryZipStreamer(source_dir, "out.zip")

        def fail_zipfile(*args, **kwargs):
            raise OSError("disk full")

        monkeypatch.setattr(zipfile, "ZipFile", fail_zipfile)
        with pytest.raises(RuntimeError, match="ZIP creation failed"):
            s._generate_zip()
