# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Tests for vcti.archive.zip_extractor module."""

import io
import zipfile

import pytest
from conftest import make_zip_bytes

from vcti.archive.extractor_base import ArchiveExtractor
from vcti.archive.zip_extractor import ZipExtractor


@pytest.fixture
def zip_stream():
    content = make_zip_bytes({"hello.txt": "hello", "sub/world.txt": "world"})
    return io.BytesIO(content)


class TestZipExtractorInit:
    def test_inherits_from_archive_extractor(self, tmp_path):
        extractor = ZipExtractor(io.BytesIO(b""), tmp_path)
        assert isinstance(extractor, ArchiveExtractor)

    def test_stores_archive_and_target(self, tmp_path, zip_stream):
        extractor = ZipExtractor(zip_stream, tmp_path)
        assert extractor.archive is zip_stream
        assert extractor.target_dir == tmp_path


class TestExtractUsingBytesIO:
    def test_extracts_files(self, tmp_path, zip_stream):
        ZipExtractor(zip_stream, tmp_path).extract_using_bytesio()
        assert (tmp_path / "hello.txt").read_text() == "hello"

    def test_extracts_nested_files(self, tmp_path, zip_stream):
        ZipExtractor(zip_stream, tmp_path).extract_using_bytesio()
        assert (tmp_path / "sub" / "world.txt").read_text() == "world"

    def test_raises_on_invalid_zip(self, tmp_path):
        with pytest.raises(zipfile.BadZipFile):
            ZipExtractor(io.BytesIO(b"not a zip"), tmp_path).extract_using_bytesio()

    def test_creates_target_dir_if_missing(self, tmp_path, zip_stream):
        target = tmp_path / "new" / "dir"
        ZipExtractor(zip_stream, target).extract_using_bytesio()
        assert (target / "hello.txt").read_text() == "hello"


class TestExtractUsingTempfile:
    def test_extracts_files(self, tmp_path, zip_stream):
        ZipExtractor(zip_stream, tmp_path).extract_using_tempfile()
        assert (tmp_path / "hello.txt").read_text() == "hello"

    def test_extracts_nested_files(self, tmp_path, zip_stream):
        ZipExtractor(zip_stream, tmp_path).extract_using_tempfile()
        assert (tmp_path / "sub" / "world.txt").read_text() == "world"

    def test_creates_target_dir_if_missing(self, tmp_path, zip_stream):
        target = tmp_path / "new" / "dir"
        ZipExtractor(zip_stream, target).extract_using_tempfile()
        assert (target / "hello.txt").read_text() == "hello"


class TestPathTraversalProtection:
    def _make_traversal_zip(self) -> io.BytesIO:
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as zf:
            zf.writestr("../../etc/evil.txt", "pwned")
        return io.BytesIO(buf.getvalue())

    def test_rejects_path_traversal_bytesio(self, tmp_path):
        stream = self._make_traversal_zip()
        with pytest.raises(ValueError, match="outside target"):
            ZipExtractor(stream, tmp_path).extract_using_bytesio()

    def test_rejects_path_traversal_tempfile(self, tmp_path):
        stream = self._make_traversal_zip()
        with pytest.raises(ValueError, match="outside target"):
            ZipExtractor(stream, tmp_path).extract_using_tempfile()

    def test_safe_entries_are_allowed(self, tmp_path):
        content = make_zip_bytes({"safe/file.txt": "ok"})
        ZipExtractor(io.BytesIO(content), tmp_path).extract_using_bytesio()
        assert (tmp_path / "safe" / "file.txt").read_text() == "ok"


class TestBombProtection:
    def test_rejects_exceeding_file_count_bytesio(self, tmp_path):
        files = {f"file{i}.txt": "x" for i in range(10)}
        stream = io.BytesIO(make_zip_bytes(files))
        ext = ZipExtractor(stream, tmp_path, max_file_count=5)
        with pytest.raises(ValueError, match="exceeding limit"):
            ext.extract_using_bytesio()

    def test_rejects_exceeding_file_count_tempfile(self, tmp_path):
        files = {f"file{i}.txt": "x" for i in range(10)}
        stream = io.BytesIO(make_zip_bytes(files))
        ext = ZipExtractor(stream, tmp_path, max_file_count=5)
        with pytest.raises(ValueError, match="exceeding limit"):
            ext.extract_using_tempfile()

    def test_rejects_exceeding_total_size_bytesio(self, tmp_path):
        content = make_zip_bytes({"big.txt": "x" * 10000})
        ext = ZipExtractor(io.BytesIO(content), tmp_path, max_total_size=100)
        with pytest.raises(ValueError, match="exceeds limit"):
            ext.extract_using_bytesio()

    def test_rejects_exceeding_total_size_tempfile(self, tmp_path):
        content = make_zip_bytes({"big.txt": "x" * 10000})
        ext = ZipExtractor(io.BytesIO(content), tmp_path, max_total_size=100)
        with pytest.raises(ValueError, match="exceeds limit"):
            ext.extract_using_tempfile()

    def test_allows_within_limits(self, tmp_path):
        files = {"a.txt": "hello", "b.txt": "world"}
        stream = io.BytesIO(make_zip_bytes(files))
        ext = ZipExtractor(stream, tmp_path, max_file_count=10, max_total_size=1_000_000)
        ext.extract_using_bytesio()
        assert (tmp_path / "a.txt").read_text() == "hello"


class TestEdgeCases:
    def test_empty_zip(self, tmp_path):
        content = make_zip_bytes({})
        ZipExtractor(io.BytesIO(content), tmp_path).extract_using_bytesio()
        # No files extracted, no error

    def test_unicode_filenames(self, tmp_path):
        content = make_zip_bytes({"café/données.txt": "data"})
        ZipExtractor(io.BytesIO(content), tmp_path).extract_using_bytesio()
        assert (tmp_path / "café" / "données.txt").read_text() == "data"

    def test_empty_file_in_archive(self, tmp_path):
        content = make_zip_bytes({"empty.txt": ""})
        ZipExtractor(io.BytesIO(content), tmp_path).extract_using_bytesio()
        assert (tmp_path / "empty.txt").read_text() == ""

    def test_multiple_empty_files(self, tmp_path):
        files = {f"empty_{i}.txt": "" for i in range(5)}
        content = make_zip_bytes(files)
        ZipExtractor(io.BytesIO(content), tmp_path).extract_using_bytesio()
        for i in range(5):
            assert (tmp_path / f"empty_{i}.txt").read_text() == ""

    def test_binary_content_preserved(self, tmp_path):
        binary_data = bytes(range(256))
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as zf:
            zf.writestr("binary.bin", binary_data)
        ZipExtractor(io.BytesIO(buf.getvalue()), tmp_path).extract_using_bytesio()
        assert (tmp_path / "binary.bin").read_bytes() == binary_data

    def test_deeply_nested_directory_structure(self, tmp_path):
        deep_name = "/".join([f"d{i}" for i in range(20)]) + "/deep.txt"
        content = make_zip_bytes({deep_name: "deep"})
        ZipExtractor(io.BytesIO(content), tmp_path).extract_using_bytesio()
        deep_path = tmp_path
        for i in range(20):
            deep_path = deep_path / f"d{i}"
        assert (deep_path / "deep.txt").read_text() == "deep"

    def test_large_file_bytesio(self, tmp_path):
        """Validates extraction of a file larger than typical chunk sizes."""
        large_content = "X" * 500_000  # 500 KB
        content = make_zip_bytes({"large.txt": large_content})
        ZipExtractor(io.BytesIO(content), tmp_path).extract_using_bytesio()
        assert (tmp_path / "large.txt").read_text() == large_content

    def test_large_file_tempfile(self, tmp_path):
        """Validates extraction of a large file via tempfile strategy."""
        large_content = "Y" * 500_000
        content = make_zip_bytes({"large.txt": large_content})
        ZipExtractor(io.BytesIO(content), tmp_path).extract_using_tempfile()
        assert (tmp_path / "large.txt").read_text() == large_content

    def test_many_files(self, tmp_path):
        files = {f"dir{i // 10}/file{i}.txt": f"content{i}" for i in range(100)}
        content = make_zip_bytes(files)
        ZipExtractor(io.BytesIO(content), tmp_path).extract_using_bytesio()
        assert (tmp_path / "dir0" / "file0.txt").read_text() == "content0"
        assert (tmp_path / "dir9" / "file99.txt").read_text() == "content99"

    def test_corrupted_zip_tempfile(self, tmp_path):
        with pytest.raises(zipfile.BadZipFile):
            ZipExtractor(io.BytesIO(b"not a zip"), tmp_path).extract_using_tempfile()

    def test_truncated_zip(self, tmp_path):
        """A zip that starts valid but is truncated mid-file."""
        good_bytes = make_zip_bytes({"file.txt": "hello"})
        truncated = good_bytes[: len(good_bytes) // 2]
        with pytest.raises(zipfile.BadZipFile):
            ZipExtractor(io.BytesIO(truncated), tmp_path).extract_using_bytesio()

    def test_extract_same_stream_twice_with_seek(self, tmp_path):
        """Stream can be reused across extractors if seeked."""
        content = make_zip_bytes({"a.txt": "hello"})
        stream = io.BytesIO(content)
        target1 = tmp_path / "first"
        target2 = tmp_path / "second"
        ZipExtractor(stream, target1).extract_using_bytesio()
        ZipExtractor(stream, target2).extract_using_bytesio()
        assert (target1 / "a.txt").read_text() == "hello"
        assert (target2 / "a.txt").read_text() == "hello"
