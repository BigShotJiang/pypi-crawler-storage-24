# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""TAR.GZ archive extractor implementation.

This module provides extraction capabilities for TAR.GZ compressed archives,
supporting both in-memory and temporary file extraction strategies.
"""

import logging
import shutil
import tarfile
from io import BytesIO
from pathlib import Path
from tempfile import NamedTemporaryFile

from .extractor_base import ArchiveExtractor

logger = logging.getLogger(__name__)


class TarGzExtractor(ArchiveExtractor):
    """Extractor for TAR.GZ compressed archives.

    Supports both memory-efficient and fast extraction methods for
    .tar.gz and .tgz file formats.

    Examples:
        >>> from pathlib import Path
        >>> extractor = TarGzExtractor(open("archive.tar.gz", "rb"), Path("/target/dir"))
        >>> extractor.extract_using_bytesio()  # For small files
        >>> # or
        >>> extractor.extract_using_tempfile()  # For large files
    """

    def _check_extraction_limits(self, tar_ref: tarfile.TarFile) -> None:
        """Check archive against size and count limits.

        Args:
            tar_ref: Open TarFile to check.

        Raises:
            ValueError: If archive exceeds configured limits.
        """
        members = tar_ref.getmembers()
        if self.max_file_count and len(members) > self.max_file_count:
            raise ValueError(
                f"Archive contains {len(members)} entries, "
                f"exceeding limit of {self.max_file_count}"
            )
        if self.max_total_size:
            total = sum(m.size for m in members if m.isfile())
            if total > self.max_total_size:
                raise ValueError(
                    f"Archive uncompressed size {total} bytes "
                    f"exceeds limit of {self.max_total_size} bytes"
                )

    def extract_using_bytesio(self) -> None:
        """Extract TAR.GZ archive using in-memory BytesIO stream.

        Reads the entire archive into memory before extraction.
        Fast but not suitable for large archives (>100MB).

        Raises:
            tarfile.TarError: If archive is corrupted or invalid.
            ValueError: If archive exceeds configured limits.
            OSError: If extraction fails due to filesystem issues.
        """
        logger.info("Extracting TAR.GZ archive to %s using bytesio strategy", self.target_dir)
        self.archive.seek(0)
        with BytesIO(self.archive.read()) as buffer:
            with tarfile.open(fileobj=buffer, mode="r:gz") as tar_ref:
                self._check_extraction_limits(tar_ref)
                self.target_dir.mkdir(parents=True, exist_ok=True)
                tar_ref.extractall(self.target_dir, filter="data")
        logger.info("TAR.GZ extraction complete")

    def extract_using_tempfile(self) -> None:
        """Extract TAR.GZ archive via temporary file.

        Streams the archive to a temporary file before extraction.
        Slower but memory-efficient for large archives.

        Raises:
            tarfile.TarError: If archive is corrupted or invalid.
            ValueError: If archive exceeds configured limits.
            OSError: If temporary file creation or extraction fails.
        """
        logger.info("Extracting TAR.GZ archive to %s using tempfile strategy", self.target_dir)
        self.archive.seek(0)
        with NamedTemporaryFile(delete=False, suffix=".tar.gz") as tmp:
            shutil.copyfileobj(self.archive, tmp)
            tmp_path = Path(tmp.name)
        try:
            with tarfile.open(tmp_path, mode="r:gz") as tar_ref:
                self._check_extraction_limits(tar_ref)
                self.target_dir.mkdir(parents=True, exist_ok=True)
                tar_ref.extractall(self.target_dir, filter="data")
        finally:
            tmp_path.unlink(missing_ok=True)
        logger.info("TAR.GZ extraction complete")
