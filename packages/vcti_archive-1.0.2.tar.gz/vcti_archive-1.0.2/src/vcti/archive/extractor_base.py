# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Base classes and exceptions for archive extraction.

This module provides the foundation for extracting various archive formats
(ZIP, TAR.GZ, etc.) from uploaded files to target directories.
"""

import asyncio
from abc import ABC, abstractmethod
from pathlib import Path
from typing import BinaryIO


class ArchiveExtractor(ABC):
    """Base class for archive extractors.

    Provides two extraction strategies:
    1. In-memory extraction via BytesIO (fast, for small files)
    2. Temp file extraction (slower, for large files)

    Both strategies include path traversal protection and optional
    limits on extracted size and file count.

    Attributes:
        archive: BinaryIO stream containing the archive data.
        target_dir: Path where archive contents will be extracted.
        max_total_size: Maximum allowed uncompressed size in bytes, or None.
        max_file_count: Maximum allowed number of files, or None.
    """

    def __init__(
        self,
        archive: BinaryIO,
        target_dir_path: Path,
        *,
        max_total_size: int | None = None,
        max_file_count: int | None = None,
    ) -> None:
        """Initialize the archive extractor.

        Args:
            archive: Archive data as a seekable binary stream.
            target_dir_path: Destination directory for extracted files.
            max_total_size: Maximum uncompressed size in bytes. None for
                no limit.
            max_file_count: Maximum number of files to extract. None for
                no limit.
        """
        self.archive = archive
        self.target_dir = Path(target_dir_path)
        self.max_total_size = max_total_size
        self.max_file_count = max_file_count

    @abstractmethod
    def extract_using_bytesio(self) -> None:
        """Extract archive using in-memory BytesIO stream.

        Best for small to medium-sized archives. Faster but uses more memory.
        """

    @abstractmethod
    def extract_using_tempfile(self) -> None:
        """Extract archive by first saving to a temporary file.

        Best for large archives. Slower but more memory-efficient.
        """

    async def async_extract_using_bytesio(self) -> None:
        """Extract archive using BytesIO in a background thread.

        Wraps :meth:`extract_using_bytesio` with ``asyncio.to_thread``
        so it does not block the event loop.
        """
        await asyncio.to_thread(self.extract_using_bytesio)

    async def async_extract_using_tempfile(self) -> None:
        """Extract archive using tempfile in a background thread.

        Wraps :meth:`extract_using_tempfile` with ``asyncio.to_thread``
        so it does not block the event loop.
        """
        await asyncio.to_thread(self.extract_using_tempfile)


class UnsupportedArchiveFormat(Exception):
    """Raised when attempting to extract an unsupported archive format."""
