# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Archive management utilities for creating and extracting archives.

This package provides:
- ZIP streaming from directories (memory-based and tempfile-based)
- ZIP and TAR.GZ extraction from binary streams
- Memory-efficient strategies for large archives
- Path-traversal and archive-bomb protection
- Optional FastAPI integration (``vcti.archive.fastapi``)

Examples:
    >>> from vcti.archive import DirectoryZipMemoryStreamer, ZipExtractor
    >>>
    >>> # Create a ZIP stream
    >>> streamer = DirectoryZipMemoryStreamer(Path("/data/project"))
    >>>
    >>> # Extract an uploaded ZIP
    >>> extractor = ZipExtractor(open("archive.zip", "rb"), Path("/target"))
    >>> extractor.extract_using_bytesio()
"""

from importlib.metadata import version

from .directory_zip_memory_streamer import DirectoryZipMemoryStreamer
from .directory_zip_tempfile_streamer import LargeDirectoryZipStreamer
from .extractor_base import ArchiveExtractor, UnsupportedArchiveFormat
from .targz_extractor import TarGzExtractor
from .zip_extractor import ZipExtractor

__version__ = version("vcti-archive")

__all__ = [
    "__version__",
    "DirectoryZipMemoryStreamer",
    "LargeDirectoryZipStreamer",
    "ArchiveExtractor",
    "UnsupportedArchiveFormat",
    "ZipExtractor",
    "TarGzExtractor",
]

# Optional FastAPI integration — available only when fastapi is installed.
try:
    from .fastapi import streaming_zip_response  # noqa: F401

    __all__ += ["streaming_zip_response"]
except ImportError:
    pass
