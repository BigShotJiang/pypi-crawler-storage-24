# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Memory-based streaming ZIP generator for directory contents.

This module provides an in-memory ZIP streamer that creates archives on-the-fly
without loading the entire contents into memory at once. Chunks are yielded as
they become available during the archiving process.

Ideal for small to medium directories (<500MB). For larger archives, consider
using LargeDirectoryZipStreamer instead.
"""

import logging
import os
import zipfile
from collections.abc import Callable, Iterator
from io import BytesIO
from pathlib import Path

logger = logging.getLogger(__name__)


class DirectoryZipMemoryStreamer:
    """A memory-efficient streaming ZIP generator for directory contents.

    Creates a ZIP archive of a directory structure on-the-fly without loading
    the entire contents into memory. Yields chunks of ZIP data as they become
    available. The streamer is reusable — each call to ``__iter__`` creates
    an independent ZIP stream.

    Attributes:
        directory_path: Resolved path to the source directory.
        chunk_size: Number of bytes to yield per chunk (default: 64KB).
        exclude: Optional callable that receives a ``Path`` and returns
            ``True`` to exclude that file from the archive.

    Examples:
        >>> streamer = DirectoryZipMemoryStreamer(Path("/path/to/directory"))
        >>> StreamingResponse(streamer, media_type="application/zip")

        >>> # Exclude hidden files
        >>> streamer = DirectoryZipMemoryStreamer(
        ...     Path("/data"),
        ...     exclude=lambda p: p.name.startswith("."),
        ... )
    """

    def __init__(
        self,
        directory_path: Path,
        chunk_size: int = 65536,
        *,
        exclude: Callable[[Path], bool] | None = None,
    ) -> None:
        """Initialize the ZIP streamer for a directory.

        Args:
            directory_path: Path to the directory to be zipped.
            chunk_size: Size of data chunks to yield in bytes.
            exclude: Optional filter — return ``True`` to skip a file.

        Raises:
            ValueError: If directory_path doesn't exist or isn't a directory.
        """
        if not directory_path.is_dir():
            raise ValueError(f"Path is not a directory: {directory_path}")

        self.directory_path = directory_path.resolve()
        self.chunk_size = chunk_size
        self.exclude = exclude

    def _generate_file_paths(self) -> Iterator[Path]:
        """Generator yielding all files in the directory tree.

        Yields:
            Path objects for each file in the directory hierarchy.

        Raises:
            RuntimeError: If directory traversal fails.
        """
        try:
            for root, _, files in os.walk(self.directory_path):
                for filename in files:
                    file_path = Path(root) / filename
                    if self.exclude and self.exclude(file_path):
                        continue
                    yield file_path
        except Exception as e:
            raise RuntimeError(f"Directory traversal failed ({type(e).__name__}): {e}") from e

    def __iter__(self) -> Iterator[bytes]:
        """Main generator interface that yields ZIP data chunks.

        Each call creates an independent ZIP stream, so the streamer is
        safe to iterate multiple times.

        **Buffer invariant — read-cursor, never mutate:**

        ``ZipFile`` writes to the ``BytesIO`` buffer and tracks absolute
        offsets internally (for local file headers, data descriptors, and
        the central directory written at close time).  If we were to
        truncate or rewrite the buffer to reclaim already-yielded bytes,
        those internal offsets would point to the wrong locations and the
        resulting ZIP would be corrupt.

        Instead, we keep the buffer intact for the entire lifetime of the
        ``ZipFile`` and maintain a separate ``bytes_yielded`` cursor that
        records how far we have already read.  After each file is added we
        check whether ``buffer_size - bytes_yielded >= chunk_size``, and
        if so we ``seek(bytes_yielded)`` and read one chunk — a pure read
        that leaves the buffer contents unchanged.  The ``ZipFile`` never
        notices, and the caller receives data incrementally.

        Yields:
            Chunks of ZIP file data as bytes.

        Raises:
            RuntimeError: If ZIP creation fails at any point.
        """
        logger.info("Starting ZIP stream for %s", self.directory_path)
        buffer = BytesIO()
        zip_file = zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED)
        bytes_yielded = 0
        file_count = 0
        try:
            for file_path in self._generate_file_paths():
                arcname = file_path.relative_to(self.directory_path)
                zip_file.write(file_path, arcname)
                file_count += 1

                # Yield full chunks of newly written data.  We only
                # *read* from the buffer here — never truncate, seek-to-
                # start-and-rewrite, or otherwise mutate it — so that
                # ZipFile's internal offset bookkeeping stays valid.
                buf_size = buffer.getbuffer().nbytes
                while buf_size - bytes_yielded >= self.chunk_size:
                    buffer.seek(bytes_yielded)
                    chunk = buffer.read(self.chunk_size)
                    bytes_yielded += len(chunk)
                    yield chunk

            # close() writes the central directory at the current end of
            # the buffer.  Because we never moved any bytes, the offsets
            # recorded in the central directory match the actual positions
            # of the local file headers written earlier.
            zip_file.close()

            # Yield whatever remains (tail of last file + central dir).
            buffer.seek(bytes_yielded)
            while remaining := buffer.read(self.chunk_size):
                yield remaining

            logger.info("ZIP stream complete — %d files archived", file_count)
        except Exception as e:
            zip_file.close()
            raise RuntimeError(f"ZIP streaming failed ({type(e).__name__}): {e}") from e
        finally:
            buffer.close()
