# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""ZIP archive extractor implementation.

This module provides extraction capabilities for ZIP archives,
supporting both in-memory and temporary file extraction strategies.
"""

import logging
import shutil
import zipfile
from io import BytesIO
from pathlib import Path
from tempfile import NamedTemporaryFile

from .extractor_base import ArchiveExtractor

logger = logging.getLogger(__name__)


class ZipExtractor(ArchiveExtractor):
    """Extractor for ZIP archives.

    Supports both memory-efficient and fast extraction methods for
    .zip file formats.

    Examples:
        >>> from pathlib import Path
        >>> extractor = ZipExtractor(open("archive.zip", "rb"), Path("/target/dir"))
        >>> extractor.extract_using_bytesio()  # For small files
        >>> # or
        >>> extractor.extract_using_tempfile()  # For large files
    """

    def _validate_zip_members(self, zip_ref: zipfile.ZipFile) -> None:
        """Validate that no archive member extracts outside target_dir.

        Args:
            zip_ref: Open ZipFile to validate.

        Raises:
            ValueError: If any member path resolves outside target_dir.
        """
        target = self.target_dir.resolve()
        for member in zip_ref.namelist():
            member_path = (target / member).resolve()
            if not member_path.is_relative_to(target):
                raise ValueError(f"Archive member would extract outside target: {member}")

    def _check_extraction_limits(self, zip_ref: zipfile.ZipFile) -> None:
        """Check archive against size and count limits.

        Args:
            zip_ref: Open ZipFile to check.

        Raises:
            ValueError: If archive exceeds configured limits.
        """
        members = zip_ref.infolist()
        if self.max_file_count and len(members) > self.max_file_count:
            raise ValueError(
                f"Archive contains {len(members)} files, exceeding limit of {self.max_file_count}"
            )
        if self.max_total_size:
            total = sum(info.file_size for info in members)
            if total > self.max_total_size:
                raise ValueError(
                    f"Archive uncompressed size {total} bytes "
                    f"exceeds limit of {self.max_total_size} bytes"
                )

    def extract_using_bytesio(self) -> None:
        """Extract ZIP archive using in-memory BytesIO stream.

        Reads the entire archive into memory before extraction.
        Fast but not suitable for large archives (>100MB).

        Raises:
            zipfile.BadZipFile: If archive is corrupted or invalid.
            ValueError: If archive contains path traversal or exceeds limits.
            OSError: If extraction fails due to filesystem issues.
        """
        logger.info("Extracting ZIP archive to %s using bytesio strategy", self.target_dir)
        self.archive.seek(0)
        with BytesIO(self.archive.read()) as buffer:
            with zipfile.ZipFile(buffer) as zip_ref:
                self._validate_zip_members(zip_ref)
                self._check_extraction_limits(zip_ref)
                self.target_dir.mkdir(parents=True, exist_ok=True)
                zip_ref.extractall(self.target_dir)
        logger.info("ZIP extraction complete")

    def extract_using_tempfile(self) -> None:
        """Extract ZIP archive via temporary file.

        Streams the archive to a temporary file before extraction.
        Slower but memory-efficient for large archives.

        Raises:
            zipfile.BadZipFile: If archive is corrupted or invalid.
            ValueError: If archive contains path traversal or exceeds limits.
            OSError: If temporary file creation or extraction fails.
        """
        logger.info("Extracting ZIP archive to %s using tempfile strategy", self.target_dir)
        self.archive.seek(0)
        with NamedTemporaryFile(delete=False, suffix=".zip") as tmp:
            shutil.copyfileobj(self.archive, tmp)
            tmp_path = Path(tmp.name)
        try:
            with zipfile.ZipFile(tmp_path) as zip_ref:
                self._validate_zip_members(zip_ref)
                self._check_extraction_limits(zip_ref)
                self.target_dir.mkdir(parents=True, exist_ok=True)
                zip_ref.extractall(self.target_dir)
        finally:
            tmp_path.unlink(missing_ok=True)
        logger.info("ZIP extraction complete")
