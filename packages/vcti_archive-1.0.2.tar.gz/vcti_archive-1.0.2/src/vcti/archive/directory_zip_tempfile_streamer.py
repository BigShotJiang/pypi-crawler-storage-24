# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Temporary file-based ZIP streamer for large directory archives.

This module provides a memory-efficient ZIP streamer that writes the archive
to a temporary file before streaming. Suitable for large directories where
the entire archive cannot fit in memory.
"""

import logging
import os
import zipfile
from collections.abc import Callable, Iterator
from pathlib import Path
from tempfile import NamedTemporaryFile

logger = logging.getLogger(__name__)


class LargeDirectoryZipStreamer:
    """ZIP streamer using temporary files for large directory archives.

    Creates a complete ZIP file in a temporary location, then streams it
    to the client.  After streaming finishes, the temporary file must be
    removed.  How that happens depends on ``on_cleanup``:

    - **``on_cleanup=None`` (default)** -- the temp file is deleted
      synchronously in the ``finally`` block of the streaming generator.
      This is safe for CLI scripts, background workers, and any context
      where deletion can happen immediately.
    - **``on_cleanup=<callable>``** -- the callable receives the temp
      file ``Path`` in the ``finally`` block *instead of* deleting it.
      Use this when deletion must be deferred — for example, in async
      web frameworks where the response body hasn't been fully sent
      when the generator finishes.  FastAPI's ``BackgroundTasks`` is
      the typical choice; see ``vcti.archive.fastapi`` for a ready-made
      helper that wires this up.

    Ideal for large directories (>500MB) where memory usage is a concern.
    For smaller archives, consider using DirectoryZipMemoryStreamer instead.

    Attributes:
        folder_path: Path to the directory to archive.
        archive_name: Name for the output ZIP file.
        chunk_size: Read chunk size in bytes (default: 64KB).
        on_cleanup: Optional callback ``(Path) -> None`` invoked after
            streaming finishes, intended for deferred temp-file removal.
        exclude: Optional callable that receives a ``Path`` and returns
            ``True`` to exclude that file from the archive.

    Examples:
        Synchronous (temp file deleted immediately after streaming)::

            streamer = LargeDirectoryZipStreamer(
                folder_path=Path("/data/project"),
                archive_name="project.zip",
            )
            for chunk in streamer.stream():
                out.write(chunk)
            # temp file already removed

        Deferred cleanup via FastAPI ``BackgroundTasks``::

            from vcti.archive.fastapi import streaming_zip_response

            @app.get("/download")
            def download(background_tasks: BackgroundTasks):
                streamer = LargeDirectoryZipStreamer(
                    folder_path=Path("/data/project"),
                    archive_name="project.zip",
                )
                return streaming_zip_response(streamer, background_tasks)
    """

    def __init__(
        self,
        folder_path: Path,
        archive_name: str,
        on_cleanup: Callable[[Path], None] | None = None,
        chunk_size: int = 65536,
        *,
        exclude: Callable[[Path], bool] | None = None,
    ) -> None:
        """Initialize the temporary file ZIP streamer.

        Args:
            folder_path: Path to the directory to zip.
            archive_name: Name for the output ZIP file.
            on_cleanup: Optional callback invoked with the temp file
                ``Path`` after streaming completes.  If ``None``
                (default), the temp file is deleted synchronously in
                the generator's ``finally`` block.  Set this when
                cleanup must be deferred — e.g., pass a function that
                registers deletion via FastAPI ``BackgroundTasks`` so
                the file survives until the HTTP response is fully
                sent.  See ``vcti.archive.fastapi`` for a ready-made
                helper.
            chunk_size: Read chunk size in bytes (default: 64KB).
            exclude: Optional filter — return ``True`` to skip a file.

        Raises:
            FileNotFoundError: If folder_path does not exist.
            ValueError: If folder_path is not a directory.
        """
        resolved = folder_path.resolve()
        if not resolved.exists():
            raise FileNotFoundError(f"Folder not found: {resolved}")
        if not resolved.is_dir():
            raise ValueError(f"Path is not a directory: {resolved}")

        self.folder_path = resolved
        self.archive_name = archive_name
        self.on_cleanup = on_cleanup
        self.chunk_size = chunk_size
        self.exclude = exclude

    def _generate_zip(self) -> Path:
        """Create the ZIP file in a temporary location.

        Returns:
            Path to the created temporary ZIP file.

        Raises:
            RuntimeError: If ZIP creation fails.
            OSError: If directory traversal or file operations fail.
        """
        temp_path = None
        try:
            with NamedTemporaryFile(delete=False, suffix=".zip") as tmp:
                temp_path = Path(tmp.name)

            file_count = 0
            with zipfile.ZipFile(temp_path, "w", zipfile.ZIP_DEFLATED) as zipf:
                for root, _, files in os.walk(self.folder_path):
                    for file in files:
                        file_path = Path(root) / file
                        if self.exclude and self.exclude(file_path):
                            continue
                        arcname = file_path.relative_to(self.folder_path)
                        zipf.write(file_path, arcname)
                        file_count += 1

            logger.info("Generated ZIP with %d files at %s", file_count, temp_path)
            return temp_path
        except Exception as e:
            if temp_path and temp_path.exists():
                temp_path.unlink(missing_ok=True)
            raise RuntimeError(f"ZIP creation failed ({type(e).__name__}): {e}") from e

    def _stream_chunks(self, zip_path: Path) -> Iterator[bytes]:
        """Generator that yields chunks of the ZIP file.

        Args:
            zip_path: Path to the ZIP file to stream.

        Yields:
            Chunks of ZIP file data as bytes.
        """
        try:
            with open(zip_path, "rb") as f:
                while chunk := f.read(self.chunk_size):
                    yield chunk
        finally:
            if self.on_cleanup:
                self.on_cleanup(zip_path)
            else:
                self._cleanup_temp_file(zip_path)

    @staticmethod
    def _cleanup_temp_file(path: Path) -> None:
        """Safely remove the temporary file.

        Args:
            path: Path to the temporary file to remove.
        """
        try:
            if path.exists():
                path.unlink()
        except Exception:
            logger.warning("Failed to remove temp file: %s", path, exc_info=True)

    def stream(self) -> Iterator[bytes]:
        """Main streaming interface.

        Returns:
            Iterator that yields ZIP file chunks.

        Raises:
            RuntimeError: If ZIP creation fails.
        """
        logger.info("Starting ZIP stream for %s", self.folder_path)
        zip_path = self._generate_zip()
        return self._stream_chunks(zip_path)
