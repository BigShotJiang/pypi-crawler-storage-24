# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Optional FastAPI integration for vcti.archive.

Relationship to core modules
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

The core ``vcti.archive`` package is **framework-independent**: extractors
accept ``BinaryIO``, streamers yield plain ``bytes`` iterators, and nothing
imports a third-party library.  This module is the *only* place that
depends on FastAPI, and it exists to bridge two gaps:

1. **Response construction** -- ``streaming_zip_response()`` turns a
   ``LargeDirectoryZipStreamer`` into a ready-to-return
   ``StreamingResponse`` with correct ``Content-Disposition``,
   ``Content-Length``, and ``application/zip`` media type.

2. **Deferred cleanup** -- After the HTTP response has been fully sent,
   the temporary ZIP file must be deleted.  FastAPI's ``BackgroundTasks``
   provides that hook; this module registers the cleanup callback so
   callers don't have to.

``DirectoryZipMemoryStreamer`` does **not** need a helper here because it
yields chunks from memory (no temp file) and can be passed directly to
``StreamingResponse``::

    StreamingResponse(streamer, media_type="application/zip")

Install with ``pip install vcti-archive[fastapi]`` to make this module
available.  If FastAPI is not installed, ``__init__.py`` silently skips
the export.

Usage::

    from vcti.archive.fastapi import streaming_zip_response
"""

import os

from fastapi import BackgroundTasks
from fastapi.responses import StreamingResponse

from .directory_zip_tempfile_streamer import LargeDirectoryZipStreamer


def streaming_zip_response(
    streamer: LargeDirectoryZipStreamer,
    background_tasks: BackgroundTasks,
) -> StreamingResponse:
    """Wrap a :class:`LargeDirectoryZipStreamer` in a FastAPI StreamingResponse.

    This is a convenience function that combines three operations that
    would otherwise need to be done manually:

    1. Calls ``streamer._generate_zip()`` to create the temp ZIP file.
    2. Creates a ``StreamingResponse`` that reads the temp file in chunks,
       with correct ``Content-Disposition``, ``Content-Length``, and
       ``application/zip`` headers.
    3. Registers temp-file deletion as a ``BackgroundTasks`` callback so
       it runs *after* the response body has been fully sent to the
       client.

    Args:
        streamer: A configured ``LargeDirectoryZipStreamer`` instance.
            The streamer's ``folder_path``, ``archive_name``,
            ``chunk_size``, and ``exclude`` settings are all respected.
        background_tasks: FastAPI ``BackgroundTasks`` for deferred cleanup.
            The temp file will be removed via a background task after
            the response has been fully streamed.

    Returns:
        A ``StreamingResponse`` with:
        - ``media_type="application/zip"``
        - ``Content-Disposition: attachment; filename=<archive_name>``
        - ``Content-Length: <size of temp ZIP>``

    Examples:
        Basic download endpoint::

            from fastapi import BackgroundTasks
            from vcti.archive import LargeDirectoryZipStreamer
            from vcti.archive.fastapi import streaming_zip_response

            @app.get("/download")
            def download(background_tasks: BackgroundTasks):
                streamer = LargeDirectoryZipStreamer(
                    folder_path=Path("/data/project"),
                    archive_name="project.zip",
                )
                return streaming_zip_response(streamer, background_tasks)

        With file filtering::

            streamer = LargeDirectoryZipStreamer(
                folder_path=Path("/data/project"),
                archive_name="project.zip",
                exclude=lambda p: p.suffix == ".log",
            )
            return streaming_zip_response(streamer, background_tasks)

    See Also:
        :class:`~vcti.archive.DirectoryZipMemoryStreamer` -- For smaller
        directories that don't need a temp file.  Pass it directly to
        ``StreamingResponse(streamer, media_type="application/zip")``.
    """
    zip_path = streamer._generate_zip()
    file_size = os.path.getsize(zip_path)

    def _cleanup() -> None:
        LargeDirectoryZipStreamer._cleanup_temp_file(zip_path)

    def _stream_with_cleanup():
        try:
            with open(zip_path, "rb") as f:
                while chunk := f.read(streamer.chunk_size):
                    yield chunk
        finally:
            background_tasks.add_task(_cleanup)

    return StreamingResponse(
        content=_stream_with_cleanup(),
        media_type="application/zip",
        headers={
            "Content-Disposition": f"attachment; filename={streamer.archive_name}",
            "Content-Length": str(file_size),
        },
    )
