# Agent Message Bus — Bootstrap Guide

This document covers the **stage 0** prerequisites that must exist before
`pulumi up` can provision infrastructure (stage 1) and before the application
can be deployed (stage 2).

## Deployment Stages

| Stage | What | How |
|-------|------|-----|
| **0 — Bootstrap** | Manual one-time setup (this doc) | `gcloud` CLI / GCP Console |
| **1 — Infrastructure** | All GCP resources (28 total) | `pulumi up --stack prod` |
| **2 — Application** | Build & push Docker image, populate secrets | `docker build` + `docker push` + `gcloud secrets versions add` |

## Current Deployment Status

| Resource | Value |
|----------|-------|
| **GCP Project** | `internal-airbyte-ai-infra` (project number: 351139268520) |
| **Load Balancer IP** | `34.117.109.145` |
| **Cloud Run Service URL** | `https://agent-message-bus-vuy6wf6uta-uc.a.run.app` |
| **Firestore Database** | `(default)` in `us-central1` |
| **Artifact Registry** | `us-central1-docker.pkg.dev/internal-airbyte-ai-infra/agent-message-bus` |
| **Cloud Armor Policy** | `agent-message-bus-armor` |
| **Pulumi Stack** | `prod` on `gs://internal-airbyte-ai-infra-pulumi-state` |

## Stage 0: Bootstrap Checklist

> **Status: COMPLETE** — All bootstrap items have been executed.

### 1. Create GCP Project

```bash
gcloud projects create internal-airbyte-ai-infra --name="Internal Airbyte AI Infra"
```

Link a billing account:

```bash
gcloud billing projects link internal-airbyte-ai-infra --billing-account=BILLING_ACCOUNT_ID
```

### 2. Create GCS Bucket for Pulumi State

```bash
gcloud storage buckets create gs://internal-airbyte-ai-infra-pulumi-state \
  --project=internal-airbyte-ai-infra \
  --location=us-central1 \
  --uniform-bucket-level-access

gcloud storage buckets update gs://internal-airbyte-ai-infra-pulumi-state \
  --versioning
```

Then configure the Pulumi backend:

```bash
pulumi login gs://internal-airbyte-ai-infra-pulumi-state
```

### 3. Authenticate

The operator running `pulumi up` needs GCP credentials with Owner or
Editor role on `internal-airbyte-ai-infra`:

```bash
gcloud auth application-default login
```

### 4. Build and Push Docker Image (before first `pulumi up`)

Cloud Run requires the container image to exist before the service can be created:

```bash
cd infra/agent-message-bus/app
docker build -t us-central1-docker.pkg.dev/internal-airbyte-ai-infra/agent-message-bus/agent-message-bus:latest .
gcloud auth configure-docker us-central1-docker.pkg.dev --quiet
docker push us-central1-docker.pkg.dev/internal-airbyte-ai-infra/agent-message-bus/agent-message-bus:latest
```

### 5. Create Placeholder Secret Versions (before first `pulumi up`)

Cloud Run also needs at least one version of each secret to exist:

```bash
for secret in github-webhook-secret subscription-api-bearer-token slack-signing-secret devin-ai-api-key; do
  echo -n "PLACEHOLDER_REPLACE_ME" | \
    gcloud secrets versions add "$secret" --project=internal-airbyte-ai-infra --data-file=-
done
```

---

## Stage 1: Infrastructure (`pulumi up`)

> **Status: COMPLETE** — 28 resources deployed.

```bash
cd infra/agent-message-bus
source venv/bin/activate
pulumi up --stack prod --yes
```

---

## Post-Deploy Manual Steps (after stage 1)

These are **not** chicken-and-egg problems — they require stage 1 outputs.

### Populate Real Secret Values

Replace the placeholder secret values with real ones:

```bash
echo -n "YOUR_GITHUB_WEBHOOK_SECRET" | \
  gcloud secrets versions add github-webhook-secret --data-file=- --project=internal-airbyte-ai-infra

echo -n "YOUR_SLACK_SIGNING_SECRET" | \
  gcloud secrets versions add slack-signing-secret --data-file=- --project=internal-airbyte-ai-infra

echo -n "YOUR_BEARER_TOKEN" | \
  gcloud secrets versions add subscription-api-bearer-token --data-file=- --project=internal-airbyte-ai-infra

echo -n "YOUR_DEVIN_API_KEY" | \
  gcloud secrets versions add devin-ai-api-key --data-file=- --project=internal-airbyte-ai-infra
```

After updating secrets, redeploy Cloud Run to pick up new values:

```bash
gcloud run services update agent-message-bus --region=us-central1 \
  --project=internal-airbyte-ai-infra --update-env-vars="DEPLOY_TS=$(date +%s)"
```

### Register GitHub Org Webhook

On `https://github.com/organizations/airbytehq/settings/hooks/new`:

- **Payload URL**: `http://34.117.109.145/github/webhook`
- **Content type**: `application/json`
- **Secret**: Same value used for `github-webhook-secret` above
- **Events**: `issue_comment`, `issues`, `pull_request`

### Configure Slack App Request URL

In the Slack App settings (Interactivity & Shortcuts):

- **Request URL**: `http://34.117.109.145/slack/webhook`
