# Copyright (c) 2025 Airbyte, Inc., all rights reserved.
"""Slack webhook handler for Block Kit interactive components.

Processes incoming Slack interaction payloads (button clicks, etc.),
extracts the target Devin session URL from the button value, and
injects a notification message into the session.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
import time
from datetime import datetime, timezone
from typing import Any

import requests

from agent_message_bus.devin_client import INJECT_OK, inject_message

logger = logging.getLogger(__name__)

# Slack allows up to 5 minutes of clock skew for signature validation
_SLACK_TIMESTAMP_MAX_AGE_SECONDS = 300


def verify_slack_signature(
    payload_body: bytes,
    timestamp: str,
    signature: str,
    signing_secret: str,
) -> bool:
    """Verify a Slack request signature (X-Slack-Signature).

    Slack uses HMAC-SHA256 with a versioned signing scheme:
    ``v0=HMAC_SHA256(signing_secret, "v0:{timestamp}:{body}")``

    Args:
        payload_body: Raw request body bytes.
        timestamp: Value of X-Slack-Request-Timestamp header.
        signature: Value of X-Slack-Signature header.
        signing_secret: The Slack app's signing secret.

    Returns:
        True if the signature is valid and the timestamp is recent.
    """
    if not timestamp or not signature:
        return False

    # Reject requests older than 5 minutes (replay protection)
    try:
        ts = int(timestamp)
    except ValueError:
        return False

    if abs(time.time() - ts) > _SLACK_TIMESTAMP_MAX_AGE_SECONDS:
        logger.warning("Slack request timestamp too old: %s", timestamp)
        return False

    sig_basestring = f"v0:{timestamp}:{payload_body.decode('utf-8')}"
    expected = (
        "v0="
        + hmac.new(
            signing_secret.encode("utf-8"),
            sig_basestring.encode("utf-8"),
            hashlib.sha256,
        ).hexdigest()
    )

    return hmac.compare_digest(expected, signature)


def _extract_session_url_from_action(action: dict[str, Any]) -> str | None:
    """Extract the Devin session URL from a Slack action payload.

    The session URL is expected to be embedded in the button's ``value``
    field as a JSON string or a direct URL.

    Args:
        action: A single action element from the Slack interaction payload.

    Returns:
        The session URL if found, None otherwise.
    """
    value = action.get("value", "")
    if not value:
        return None

    # Try parsing as JSON first (our standard format)
    try:
        data = json.loads(value)
        if isinstance(data, dict):
            return data.get("session_url")
    except (json.JSONDecodeError, TypeError):
        pass

    # Fall back to treating the value as a direct URL
    if "app.devin.ai/sessions/" in value:
        return value

    return None


def _format_slack_notification(
    action: dict[str, Any],
    user: dict[str, Any],
    message_text: str | None = None,
) -> str:
    """Format a notification message for a Devin session from a Slack action.

    Args:
        action: The Slack action element (button click, etc.).
        user: The Slack user who performed the action.
        message_text: Optional original message text for context.

    Returns:
        Formatted notification string.
    """
    user_name = user.get("name", user.get("username", "someone"))
    action_id = action.get("action_id", "unknown_action")
    button_text = action.get("text", {}).get("text", action_id)

    parts = [
        f"Slack action received: @{user_name} clicked '{button_text}'",
    ]

    if message_text:
        # Truncate for context
        if len(message_text) > 300:
            message_text = message_text[:300] + "..."
        parts.append(f"Original message context: {message_text}")

    return "\n\n".join(parts)


def _update_message_with_approved_button(
    response_url: str,
    original_message: dict[str, Any],
    clicked_action_id: str,
    user_name: str,
) -> None:
    """Update the original Slack message to mark a button as approved.

    Replaces the clicked interactive button with a static text element
    showing the approval status. Uses Slack's ``response_url`` which
    does not require a bot token.

    Args:
        response_url: The response_url from the Slack interaction payload.
        original_message: The original message dict from the payload.
        clicked_action_id: The action_id of the button that was clicked.
        user_name: Display name of the user who clicked.
    """
    if not response_url:
        logger.warning("No response_url in payload, cannot update message")
        return

    blocks = original_message.get("blocks", [])
    updated_blocks: list[dict[str, Any]] = []

    for block in blocks:
        if block.get("type") != "actions":
            updated_blocks.append(block)
            continue

        # Rebuild the actions block: replace the clicked interactive button
        new_elements: list[dict[str, Any]] = []
        for element in block.get("elements", []):
            if element.get("action_id") == clicked_action_id:
                # Extract the action_summary from the original button's
                # confirm dialog text so we can re-display it on the
                # post-approval button.
                original_action_summary = element.get("confirm", {}).get("text", {}).get("text", "")

                # Build the post-approval confirm body with approver
                # and timestamp.  Slack mrkdwn confirm text is capped
                # at 300 chars.
                approved_at = datetime.now(tz=timezone.utc).strftime("%b %-d, %Y at %H:%M UTC")
                confirm_lines: list[str] = []
                if original_action_summary:
                    confirm_lines.append(original_action_summary)
                confirm_lines.append(f"Approved by @{user_name} on {approved_at}")
                confirm_body = "\n\n".join(confirm_lines)[:300]

                # Build the replacement button with an informational
                # confirm dialog.  Both "OK" and "Close" are no-ops
                # because the _done action_id has no handler.
                replacement: dict[str, Any] = {
                    "type": "button",
                    "text": {
                        "type": "plain_text",
                        "text": f":white_check_mark: Approved by @{user_name}",
                        "emoji": True,
                    },
                    "action_id": f"{clicked_action_id}_done",
                    "confirm": {
                        "title": {
                            "type": "plain_text",
                            "text": "Action Already Approved",
                        },
                        "text": {
                            "type": "mrkdwn",
                            "text": confirm_body,
                        },
                        "confirm": {
                            "type": "plain_text",
                            "text": "OK",
                        },
                        "deny": {
                            "type": "plain_text",
                            "text": "Close",
                        },
                    },
                }
                new_elements.append(replacement)
            else:
                new_elements.append(element)

        updated_blocks.append({"type": "actions", "elements": new_elements})

    try:
        resp = requests.post(
            response_url,
            json={
                "replace_original": True,
                "blocks": updated_blocks,
            },
            headers={"Content-Type": "application/json"},
            timeout=10,
        )
        if resp.ok:
            logger.info("Updated Slack message to show approved button")
        else:
            logger.warning(
                "Failed to update Slack message via response_url: %s %s",
                resp.status_code,
                resp.text[:200],
            )
    except requests.RequestException as exc:
        logger.warning("Error posting to response_url: %s", exc)


def handle_slack_interaction(payload: dict[str, Any]) -> dict[str, Any]:
    """Process a Slack interactive component payload.

    Extracts the Devin session URL from button values and injects
    a notification message into the target session. After successful
    delivery, updates the original Slack message to mark the button
    as approved.

    Args:
        payload: The parsed Slack interaction payload.

    Returns:
        Summary dict with processing results.
    """
    payload_type = payload.get("type", "")

    if payload_type != "block_actions":
        return {"status": "skipped", "reason": f"unsupported_type: {payload_type}"}

    actions = payload.get("actions", [])
    user = payload.get("user", {})
    message = payload.get("message", {})
    message_text = message.get("text", "")
    response_url = payload.get("response_url", "")
    user_name = user.get("name", user.get("username", "someone"))

    notified = 0
    errors = 0

    for action in actions:
        session_url = _extract_session_url_from_action(action)
        if not session_url:
            logger.warning(
                "No session URL found in Slack action value: %s",
                action.get("value", ""),
            )
            continue

        notification = _format_slack_notification(action, user, message_text)
        result = inject_message(session_url, notification)

        if result == INJECT_OK:
            notified += 1
            # Update the original message to mark the button as approved
            action_id = action.get("action_id", "")
            if action_id and response_url:
                _update_message_with_approved_button(
                    response_url=response_url,
                    original_message=message,
                    clicked_action_id=action_id,
                    user_name=user_name,
                )
        else:
            errors += 1
            logger.warning(
                "Failed to inject Slack action into session %s (result=%s)",
                session_url,
                result,
            )

    return {
        "status": "processed",
        "actions_received": len(actions),
        "notified": notified,
        "errors": errors,
    }
