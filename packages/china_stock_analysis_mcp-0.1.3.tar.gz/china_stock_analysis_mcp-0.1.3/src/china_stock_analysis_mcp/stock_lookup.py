"""
股票基础信息缓存模块
- 首次调用时从 Tushare stock_basic 接口拉取数据并缓存到本地
- 每隔半年自动更新一次
- 缓存路径: ./resource/stock_codes.json

用法:
    from stock_basic import get_stock_info, get_ts_code, get_name

    get_stock_info("平安银行")      # 返回完整信息 dict
    get_ts_code("平安银行")         # 返回 "000001.SZ"
    get_name("000001.SZ")           # 返回 "平安银行"
"""

import json
import re
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

import tushare as ts

# ── 配置 ────────────────────────────────────────────────────────
# 获取项目根目录 (src/china_stock_analysis_mcp/ -> 项目根目录/)
_PROJECT_ROOT = Path(__file__).parent.parent.parent
CACHE_PATH = _PROJECT_ROOT / "resource" / "stock_codes.json"

UPDATE_INTERVAL_DAYS = 180  # 半年

# Tushare 拉取的字段
_FIELDS = "ts_code,symbol,name,fullname,area,industry,market,list_status,list_date"

# 名称后缀正则（-U/-W/-UW/-WD 等科创板特殊后缀）
_SUFFIX_RE = re.compile(r'-[UW]{1,2}D?$', re.IGNORECASE)


# ── 数据获取 ────────────────────────────────────────────────────

def _fetch_from_tushare() -> list[dict]:
    """从 Tushare 拉取所有上市/退市/暂停股票的基础信息"""
    pro = ts.pro_api()
    frames = []
    for status in ('L', 'D', 'P'):
        df = pro.stock_basic(list_status=status, fields=_FIELDS)
        if df is not None and not df.empty:
            df['list_status'] = status
            frames.append(df)

    if not frames:
        raise RuntimeError("Tushare 返回数据为空，请检查 token 或网络")

    import pandas as pd
    combined = pd.concat(frames, ignore_index=True)
    # fullname 可能为空，用 name 补充
    combined['fullname'] = combined['fullname'].fillna(combined['name'])
    return combined.to_dict(orient='records')


# ── 缓存读写 ────────────────────────────────────────────────────

def _load_cache() -> Optional[dict]:
    """读取本地缓存，返回 None 表示不存在或已损坏"""
    if not CACHE_PATH.exists():
        return None
    try:
        with open(CACHE_PATH, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return None


def _save_cache(records: list[dict]) -> None:
    """保存缓存到本地"""
    CACHE_PATH.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "updated_at": datetime.now().isoformat(),
        "records": records
    }
    with open(CACHE_PATH, 'w', encoding='utf-8') as f:
        json.dump(payload, f, ensure_ascii=False, indent=2)


def _is_stale(cache: dict) -> bool:
    """判断缓存是否超过半年"""
    try:
        updated_at = datetime.fromisoformat(cache["updated_at"])
        return datetime.now() - updated_at > timedelta(days=UPDATE_INTERVAL_DAYS)
    except (KeyError, ValueError):
        return True


# ── 数据加载（带缓存逻辑）───────────────────────────────────────

_RECORDS: Optional[list[dict]] = None  # 模块级内存缓存


def _get_records(force_refresh: bool = False) -> list[dict]:
    """
    获取股票记录列表，自动处理缓存逻辑：
    1. 内存中已有 → 直接返回
    2. 本地缓存存在且未过期 → 从文件加载
    3. 缓存不存在或已过期 → 从 Tushare 拉取并保存
    """
    global _RECORDS
    if _RECORDS is not None and not force_refresh:
        return _RECORDS

    cache = _load_cache()

    if cache is not None and not _is_stale(cache) and not force_refresh:
        print(f"[stock_basic] 使用本地缓存（更新于 {cache['updated_at'][:10]}）")
        _RECORDS = cache["records"]
    else:
        reason = "强制刷新" if force_refresh else ("缓存过期" if cache else "首次初始化")
        print(f"[stock_basic] {reason}，正在从 Tushare 拉取数据...")
        _RECORDS = _fetch_from_tushare()
        _save_cache(_RECORDS)
        print(f"[stock_basic] 拉取完成，共 {len(_RECORDS)} 条，已保存至 {CACHE_PATH}")

    return _RECORDS # pyright: ignore[reportReturnType]


# ── 查询接口 ────────────────────────────────────────────────────

def get_stock_info(query: str, force_refresh: bool = False) -> Optional[dict] | list[dict]:
    """
    按股票名称或 TS 代码查询完整信息。

    Args:
        query: 股票名称（如 "平安银行"、"摩尔线程"）或 TS 代码（如 "000001.SZ"）
        force_refresh: 强制从 Tushare 重新拉取

    Returns:
        单个 dict / list[dict]（模糊匹配多个时）/ None（未找到）
    """
    records = _get_records(force_refresh)
    query = query.strip()
    query_stripped = _SUFFIX_RE.sub('', query)

    # 1. ts_code 精确匹配
    for r in records:
        if r.get('ts_code') == query:
            return r

    # 2. name / fullname 精确匹配
    for r in records:
        if r.get('name') == query or r.get('fullname') == query:
            return r

    # 3. 忽略 -U/-W 后缀匹配（如输入"摩尔线程"匹配"摩尔线程-U"）
    suffix_hits = [
        r for r in records
        if _SUFFIX_RE.sub('', r.get('name', '')) == query_stripped
        and r.get('name') != query
    ]
    if len(suffix_hits) == 1:
        return suffix_hits[0]
    if len(suffix_hits) > 1:
        return suffix_hits

    # 4. 模糊匹配：名称包含 query
    if len(query) >= 2:
        fuzzy = [
            r for r in records
            if query in r.get('name', '') or query in r.get('fullname', '')
        ]
        if len(fuzzy) == 1:
            return fuzzy[0]
        if len(fuzzy) > 1:
            return fuzzy

    return None


def get_ts_code(name: str, force_refresh: bool = False) -> Optional[str] | list[str]:
    """
    按股票名称获取 TS 代码。

    Returns:
        单个代码字符串 / list（多个匹配时）/ None（未找到）
    """
    result = get_stock_info(name, force_refresh)
    if result is None:
        return None
    if isinstance(result, list):
        return [r['ts_code'] for r in result]
    return result.get('ts_code')


def get_name(ts_code: str, force_refresh: bool = False) -> Optional[str]:
    """
    按 TS 代码获取股票名称。

    Returns:
        股票名称字符串 / None（未找到）
    """
    result = get_stock_info(ts_code, force_refresh)
    if result is None or isinstance(result, list):
        return None
    return result.get('name')


def refresh() -> None:
    """手动强制更新本地缓存"""
    _get_records(force_refresh=True)