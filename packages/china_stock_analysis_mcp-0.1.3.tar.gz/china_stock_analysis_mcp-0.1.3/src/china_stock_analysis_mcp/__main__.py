import argparse
import logging
import uvicorn
from starlette.middleware.cors import CORSMiddleware

from .mcp_server import mcp

logger = logging.getLogger(__name__)


def create_streamable_http_app():
    """
    创建并配置可流式 HTTP 模式下的 FastAPI 应用。
    此应用将通过 HTTP 接口提供 MCP 服务。
    """
    app = mcp.http_app()
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["GET", "POST", "OPTIONS"],
        allow_headers=["*"],
        expose_headers=["mcp-session-id", "mcp-protocol-version"],
        max_age=86400,
    )
    return app


def main():
    """
    主函数，解析命令行参数并启动 MCP 服务器。
    支持 HTTP 模式和标准输入/输出 (stdio) 模式。
    """
    parser = argparse.ArgumentParser(
        description="China Stock Analysis MCP Server - 基于 Tushare 的股票分析 MCP 服务器"
    )
    parser.add_argument(
        "--streamable-http",
        action="store_true",
        help="使用可流式 HTTP 模式启动服务器，而不是默认的 stdio 模式。",
    )
    parser.add_argument(
        "--host",
        default="0.0.0.0",
        help="服务器绑定的主机地址 (默认: 0.0.0.0，表示监听所有可用网络接口)",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8081,
        help="服务器监听的端口号 (默认: 8081)",
    )

    args = parser.parse_args()

    if args.streamable_http:
        print("MCP 服务器正在以 HTTP 模式启动...")
        app = create_streamable_http_app()
        print(f"服务器监听地址: {args.host}:{args.port}")
        uvicorn.run(app, host=args.host, port=args.port, log_level="debug")
    else:
        print("MCP 服务器正在以 stdio 模式启动...")
        mcp.run()


if __name__ == "__main__":
    main()
