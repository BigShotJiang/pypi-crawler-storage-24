"""JSON-LD scraper — extracts schema.org/JobPosting data from page HTML.

Parses <script type="application/ld+json"> blocks for JobPosting structured data.
No configuration needed — handles all standard schema.org fields automatically.
"""

from __future__ import annotations

import json
import re
from html.parser import HTMLParser

import httpx
import structlog

from src.core.scrapers import JobContent, register

log = structlog.get_logger()

_CTRL_REPLACEMENTS = {"\n": "\\n", "\r": "\\r", "\t": "\\t"}


def _escape_control_chars_in_strings(raw: str) -> str:
    """Escape control characters that appear inside JSON string values only."""
    out: list[str] = []
    in_string = False
    escape = False
    for ch in raw:
        if escape:
            out.append(ch)
            escape = False
            continue
        if ch == "\\":
            escape = True
            out.append(ch)
            continue
        if ch == '"':
            in_string = not in_string
        if in_string and ord(ch) < 0x20:
            out.append(_CTRL_REPLACEMENTS.get(ch, ""))
            continue
        out.append(ch)
    return "".join(out)


class _JsonLdExtractor(HTMLParser):
    """Extracts JSON-LD blocks from HTML."""

    def __init__(self):
        super().__init__()
        self._in_jsonld = False
        self._data: list[str] = []
        self.results: list[dict] = []

    def handle_starttag(self, tag, attrs):
        if tag == "script":
            attr_dict = dict(attrs)
            if attr_dict.get("type") == "application/ld+json":
                self._in_jsonld = True
                self._data = []

    def handle_data(self, data):
        if self._in_jsonld:
            self._data.append(data)

    def handle_endtag(self, tag):
        if tag == "script" and self._in_jsonld:
            self._in_jsonld = False
            raw = "".join(self._data).strip()
            if raw:
                try:
                    parsed = json.loads(raw)
                    self.results.append(parsed)
                except json.JSONDecodeError:
                    # Some sites emit literal control chars (newlines, tabs)
                    # inside JSON string values — escape them and retry.
                    cleaned = _escape_control_chars_in_strings(raw)
                    try:
                        parsed = json.loads(cleaned)
                        self.results.append(parsed)
                    except json.JSONDecodeError:
                        pass


def _find_job_posting(data: dict | list) -> dict | None:
    """Recursively find a JobPosting object in JSON-LD data."""
    if isinstance(data, list):
        for item in data:
            result = _find_job_posting(item)
            if result:
                return result
        return None

    if isinstance(data, dict):
        type_val = data.get("@type", "")
        if isinstance(type_val, str) and "JobPosting" in type_val:
            return data
        if isinstance(type_val, list) and any("JobPosting" in t for t in type_val):
            return data

        # Check @graph
        graph = data.get("@graph")
        if isinstance(graph, list):
            return _find_job_posting(graph)

    return None


def _extract_locations(posting: dict) -> list[str] | None:
    """Extract locations from jobLocation field."""
    locations: list[str] = []
    job_location = posting.get("jobLocation")

    if job_location is None:
        return None

    items = job_location if isinstance(job_location, list) else [job_location]

    for loc in items:
        if not isinstance(loc, dict):
            continue
        # Try name first
        name = loc.get("name")
        if name:
            locations.append(name)
            continue
        # Build from address
        address = loc.get("address")
        if isinstance(address, dict):
            parts = []
            for field in ("addressLocality", "addressRegion", "addressCountry"):
                val = address.get(field)
                if val:
                    if isinstance(val, dict):
                        val = val.get("name", "")
                    parts.append(str(val))
            if parts:
                locations.append(", ".join(parts))

    return locations or None


def _extract_salary(posting: dict) -> dict | None:
    """Extract salary from baseSalary field."""
    base_salary = posting.get("baseSalary")
    if not isinstance(base_salary, dict):
        return None

    currency = base_salary.get("currency")
    value = base_salary.get("value")

    if isinstance(value, dict):
        return {
            "currency": currency,
            "min": value.get("minValue"),
            "max": value.get("maxValue"),
            "unit": value.get("unitText", "").lower() or None,
        }
    elif isinstance(value, (int, float)):
        return {
            "currency": currency,
            "min": value,
            "max": value,
            "unit": None,
        }

    return None


def _text_or_list(val) -> list[str] | None:
    """Convert a string or list of strings to a list."""
    if isinstance(val, str):
        return [val] if val.strip() else None
    if isinstance(val, list):
        result = [str(v).strip() for v in val if v]
        return result or None
    return None


def _strip_html(text: str) -> str:
    """Remove HTML tags from text."""
    return re.sub(r"<[^>]+>", "", text).strip()


def _parse_posting(posting: dict) -> JobContent:
    """Convert a schema.org JobPosting dict to JobContent."""
    description = posting.get("description")
    if isinstance(description, str) and "<" in description:
        # Keep HTML description as-is (same as greenhouse/lever)
        pass

    extras: dict = {}
    skills = _text_or_list(posting.get("skills"))
    if skills:
        extras["skills"] = skills
    responsibilities = _text_or_list(posting.get("responsibilities"))
    if responsibilities:
        extras["responsibilities"] = responsibilities
    qualifications = _text_or_list(
        posting.get("qualifications") or posting.get("educationRequirements")
    )
    if qualifications:
        extras["qualifications"] = qualifications
    valid_through = posting.get("validThrough")
    if valid_through:
        extras["valid_through"] = valid_through

    return JobContent(
        title=posting.get("title") or posting.get("name"),
        description=description,
        locations=_extract_locations(posting),
        employment_type=posting.get("employmentType"),
        job_location_type=posting.get("jobLocationType"),
        date_posted=posting.get("datePosted"),
        base_salary=_extract_salary(posting),
        extras=extras or None,
    )


def parse_html(html: str, config: dict | None = None) -> JobContent:
    """Extract JobPosting data from pre-fetched HTML."""
    extractor = _JsonLdExtractor()
    extractor.feed(html)

    for block in extractor.results:
        posting = _find_job_posting(block)
        if posting:
            return _parse_posting(posting)

    return JobContent()


def can_handle(htmls: list[str]) -> dict | None:
    """Check if pages contain JSON-LD JobPosting. Returns ``{}`` if majority have it."""
    found = 0
    for html in htmls:
        extractor = _JsonLdExtractor()
        extractor.feed(html)
        if any(_find_job_posting(block) for block in extractor.results):
            found += 1
    # Require at least half the pages to have JSON-LD
    if found > 0 and found >= len(htmls) / 2:
        return {}
    return None


async def scrape(url: str, config: dict, http: httpx.AsyncClient, pw=None, **kwargs) -> JobContent:
    """Extract job data from JSON-LD on a page.

    When ``render`` is true, renders the page with Playwright first.
    """
    if config.get("render"):
        from src.shared.browser import BROWSER_KEYS
        from src.shared.browser import render as browser_render

        browser_config = {k: v for k, v in config.items() if k in BROWSER_KEYS}
        html = await browser_render(url, browser_config, pw=pw)
    else:
        response = await http.get(url, follow_redirects=True)
        response.raise_for_status()
        html = response.text

    content = parse_html(html, config)
    if content.title:
        log.debug("jsonld.extracted", url=url, title=content.title)
    else:
        log.warning("jsonld.not_found", url=url)
    return content


async def probe(url: str, http: httpx.AsyncClient) -> bool:
    """Check if a URL has JSON-LD JobPosting data. Used by validate --probe-jsonld."""
    try:
        response = await http.get(url, follow_redirects=True)
        if response.status_code != 200:
            return False
        return can_handle([response.text]) is not None
    except Exception:
        return False


register("json-ld", scrape, can_handle=can_handle, parse_html=parse_html)
