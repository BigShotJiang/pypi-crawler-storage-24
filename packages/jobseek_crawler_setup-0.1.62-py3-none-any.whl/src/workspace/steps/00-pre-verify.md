# Pre-verify: Is this request valid?

## How this works

You will configure a crawler to monitor a company's career page for job postings.
The `ws` CLI guides you through each step: verify the request, set up the company,
add career page boards, select and test a monitor/scraper, verify data quality, and submit.

Run `ws task` at any time to see your current step.
If something goes wrong, run `ws task troubleshoot <query>` to search the knowledge base.
If you get stuck on any step, run `ws task fail --reason "..."` to enter coding mode —
this unlocks source code access so you can propose a fix.

Interpret `ws` output as evidence. Record what was observed, how it was observed,
and what it likely means before deciding.

**Rule:** Do **not** explore the codebase or read source code — use `ws` commands and `ws help` exclusively.

## Issue

**#{issue}**: {issue_title}

{issue_body}

---

## Is this a real company with a public careers page?

Use web research to confirm:
1. The company exists and is currently operating
2. It has a public-facing careers or jobs page

Research tips:
- Do not assume a specific country or geography unless the issue explicitly says so.
- If the company website is down, check LinkedIn or other sources before rejecting — "website unavailable" is different from "company not found".
- **Search in the company's language**, not just English. Many companies host careers pages in their local language (e.g., "carrières", "Karriere", "carreras", "lavora con noi"). Try `<company> carrières` or `<company> Karriere` early — don't exhaust dozens of English-only searches first.
- **Stop after 5 searches.** If you haven't found a careers page by then, reject with `no-job-board` and note what you tried.

Do not use crawler tooling at this stage. If the issue URL is missing or ambiguous,
check the company's own website for a "Careers" or "Jobs" link.

If the company doesn't exist or can't be identified, reject with `not-a-company` or `company-not-found`.
If there's no public careers page and the user cannot provide a URL, reject with `no-job-board`.

```bash
ws reject --issue {issue} --reason <key> --message "..."
```

## If valid — create the workspace hypothesis context

Choose a slug (lowercase, hyphens, e.g. `stripe`, `deep-judge`):

```bash
ws new <slug> --issue {issue}
```

Then run `ws task` for the next step.

**Important:** Process only this one issue. After completing or rejecting it, stop — do not pick another issue.
