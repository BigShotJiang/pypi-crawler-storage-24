# Sector-specific ratio modules
