"""
CLI commands for trial management in Epochly.

Provides commands for requesting and verifying trial licenses.
Business logic is in _trial_impl and _activate_impl (plain functions).
"""

import os
import sys
import stat
import requests
import json
import logging
from pathlib import Path
from typing import Optional, Tuple
import re

from epochly.config.api_endpoints import APIEndpoints
from epochly.licensing.consent_manager import ConsentRequiredError, require_consent

# Module logger for debugging
logger = logging.getLogger(__name__)


_DEFAULT_CREDS_FILENAME = 'node_credentials.json'


def _get_node_creds_path() -> str:
    """Return the default path for node credentials (~/.epochly/node_credentials.json)."""
    return str(Path.home() / '.epochly' / _DEFAULT_CREDS_FILENAME)


def store_node_credentials(node_id: str, node_secret: str, creds_path: str = None) -> None:
    """
    Persist node credentials to disk with owner-only permissions (0o600).

    Args:
        node_id:    Node identifier returned by the activation API.
        node_secret: HMAC secret returned by the activation API.
        creds_path:  Override file path (default: ~/.epochly/node_credentials.json).
    """
    path = creds_path or _get_node_creds_path()
    Path(path).parent.mkdir(parents=True, exist_ok=True)

    data = {'node_id': node_id, 'node_secret': node_secret}
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f)

    # Set owner-read-write only
    os.chmod(path, stat.S_IRUSR | stat.S_IWUSR)


def load_node_credentials(creds_path: str = None) -> Optional[dict]:
    """
    Load node credentials from disk.

    Args:
        creds_path: Override file path (default: ~/.epochly/node_credentials.json).

    Returns:
        Dict with ``node_id`` and ``node_secret``, or ``None`` if not found.
    """
    path = creds_path or _get_node_creds_path()
    try:
        with open(path, encoding='utf-8') as f:
            return json.load(f)
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return None


def get_api_timeout() -> int:
    """Get configurable API timeout from environment (default: 10 seconds)."""
    try:
        return int(os.environ.get('EPOCHLY_API_TIMEOUT', '10'))
    except ValueError:
        return 10


def safe_json_parse(response: requests.Response) -> Optional[dict]:
    """
    Safely parse JSON from response, returning None if parsing fails.

    Handles cases where server returns HTML (proxy, WAF, CDN error pages)
    instead of expected JSON. Also handles cases where JSON is valid but
    not a dict (e.g., list or string).
    """
    try:
        data = response.json()
    except (ValueError, json.JSONDecodeError):
        return None
    # Ensure we return a dict (response.json() can return list, str, etc.)
    return data if isinstance(data, dict) else None



# Canonical API URLs that are trusted for trial activation.
# SECURITY: Only these URLs may be used for license-granting operations.
_CANONICAL_API_URLS = frozenset([
    APIEndpoints.DEFAULT_BASE_URL,   # https://api.epochly.com
    APIEndpoints.FALLBACK_BASE_URL,  # AWS direct endpoint
])


def is_canonical_api_url(url: str) -> bool:
    """Check if a URL is one of the canonical Epochly API endpoints.

    SECURITY: Trial activation must only be accepted from known Epochly
    infrastructure. Env var overrides (EPOCHLY_API_URL) are useful for
    development but MUST NOT be trusted for license-granting operations.

    Args:
        url: The API base URL to check.

    Returns:
        True if the URL is a canonical Epochly API endpoint.
    """
    return url.rstrip('/') in _CANONICAL_API_URLS


def _validate_activation_response(data: object) -> Tuple[bool, str]:
    """Validate the response from /trial/confirm strictly.

    SECURITY: This prevents forged responses from granting trial entitlements.
    A minimal attacker response (e.g. just {"expires_at": "..."}) must be rejected.

    Required fields:
        - status: must be exactly "trial_activated"
        - expires_at: must be a valid ISO 8601 datetime, in the future, and
          no more than 90 days out (trial is 30 days)

    Args:
        data: Parsed JSON response (should be a dict).

    Returns:
        Tuple of (is_valid, error_message).
    """
    from datetime import datetime, timedelta, timezone as _tz

    if not isinstance(data, dict):
        return False, "Response is not a JSON object"

    status = data.get('status')
    if not status or status != 'trial_activated':
        return False, f"Invalid activation status: {status!r} (expected 'trial_activated')"

    expires_at = data.get('expires_at')
    if not expires_at or not isinstance(expires_at, str):
        return False, "Missing or invalid 'expires_at' field"

    # PR #47 R2, Finding 3: Parse expires_at as ISO datetime immediately.
    # Reject non-parseable strings here instead of deferring to downstream.
    try:
        parsed = datetime.fromisoformat(expires_at)
    except (ValueError, TypeError):
        return False, f"expires_at is not a valid ISO datetime: {expires_at!r}"

    # Normalize to UTC-aware for comparison
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=_tz.utc)

    now = datetime.now(_tz.utc)

    # Reject expired dates
    if parsed <= now:
        return False, f"expires_at is in the past: {expires_at!r}"

    # Reject suspiciously far-future dates (trial is 30 days, allow up to 90)
    max_expiry = now + timedelta(days=90)
    if parsed > max_expiry:
        return False, f"expires_at is >90 days in the future: {expires_at!r}"

    return True, ""



def get_api_base_url() -> str:
    """
    Get API base URL with automatic fallback.

    Respects EPOCHLY_API_URL environment variable override.
    Tries the configured URL first, falls back to direct AWS endpoint if needed.
    Uses a short probe timeout (3s) to quickly detect unavailable servers.
    """
    # Use BASE_URL which respects EPOCHLY_API_URL env var override
    primary_url = APIEndpoints.BASE_URL

    # Use shorter timeout for probe (3s) - we want quick fallback
    probe_timeout = min(3, get_api_timeout())

    # Try primary URL
    try:
        response = requests.head(
            f"{primary_url}/trial/activate",
            timeout=probe_timeout
        )
        if response.status_code < 500:
            return primary_url
    except (requests.exceptions.RequestException, OSError) as e:
        logger.debug("Primary API probe failed: %s", e)

    # Use fallback
    logger.debug("Using fallback API URL: %s", APIEndpoints.FALLBACK_BASE_URL)
    return APIEndpoints.FALLBACK_BASE_URL


def validate_email(email: str) -> bool:
    """Validate email format."""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None


def _echo(message: str) -> None:
    """Print a message to stdout."""
    print(message)


def _update_enforcer_with_trial(server_data: dict, *, api_url: str) -> None:
    """Update the LicenseEnforcer cache with trial data from the server.

    Called immediately after a successful /trial/confirm response so the
    user gets trial-tier limits (unlimited cores, GPU, etc.) without waiting
    for the next background sync cycle (up to 1 hour).

    Security: This code path is exclusively for trial activation.
    - Tier is hardcoded to 'trial' regardless of server response (defense-in-depth).
    - expires_at is validated as a parseable ISO datetime; malformed values fail closed.
    - api_url is required and must be canonical -- fail closed otherwise.

    Args:
        server_data: Parsed JSON from the /trial/confirm 200 response.
        api_url: The API base URL used for this activation. REQUIRED.
                 Must be a canonical Epochly URL or the update is rejected.
    """
    import time as _time
    from datetime import datetime, timedelta, timezone

    # SECURITY (PR #47 R2, Finding 4): api_url is now required.
    # Fail closed when None or non-canonical -- never skip the check.
    if not api_url or not is_canonical_api_url(api_url):
        logger.warning(
            "Rejecting trial enforcer update: missing or non-canonical API URL %r",
            api_url,
        )
        return

    try:
        from epochly.licensing.license_enforcer import get_license_enforcer

        enforcer = get_license_enforcer()

        # SECURITY: Hardcode tier -- trial activation can only produce 'trial'.
        # Never trust server_data['tier'] here; a compromised/malicious server
        # could return 'enterprise' and escalate privileges.
        tier = 'trial'

        # Validate expires_at -- must be a parseable ISO datetime.
        # Fail closed: if missing or malformed, do not persist elevated privileges.
        expires_at_raw = server_data.get('expires_at', '')
        if not expires_at_raw:
            logger.warning("Trial activation missing expires_at -- skipping enforcer update")
            return
        try:
            parsed_expiry = datetime.fromisoformat(expires_at_raw)
            # Normalize to UTC-aware for comparison
            if parsed_expiry.tzinfo is None:
                parsed_expiry = parsed_expiry.replace(tzinfo=timezone.utc)
            # Sanity: reject expiry more than 90 days in the future (trial is 30 days)
            max_expiry = datetime.now(timezone.utc) + timedelta(days=90)
            if parsed_expiry > max_expiry:
                logger.warning(
                    "Trial expires_at %s is >90 days out -- rejecting as suspicious",
                    expires_at_raw,
                )
                return
        except (ValueError, TypeError) as exc:
            logger.warning("Trial expires_at %r is not valid ISO datetime: %s", expires_at_raw, exc)
            return

        expires_at = expires_at_raw

        enforcer._license_data = {
            'tier': tier,
            'max_cores': None,          # Unlimited for trial
            'gpu_enabled': True,        # GPU enabled for trial
            'memory_limit_gb': None,    # Unlimited for trial
            'features': ['pro'],        # 'pro' is the wildcard in check_feature()
            'expires_at': expires_at,
            'had_trial': True,
            'cached_at': _time.time(),
            'last_valid_sync': _time.time(),
        }

        # Persist to encrypted cache so the enforcer survives process restarts
        try:
            enforcer._save_cached_license()
        except Exception:
            # Non-fatal: enforcer has in-memory data, just won't persist
            logger.debug("Could not persist trial license cache", exc_info=True)

        logger.info("License enforcer updated with trial tier (EP-22)")

    except Exception as exc:
        # Non-fatal: worst case the user waits for background sync
        logger.warning(
            "Failed to update license enforcer after trial activation: %s", exc
        )


def _trial_impl(email: str, interactive: bool = True) -> int:
    """
    Request a 30-day trial with email verification.

    Core business logic for trial request.

    Args:
        email: Email address for trial activation.
        interactive: If True, show policy info and prompt for confirmation.
                    If False, skip confirmation (for programmatic use).

    Returns: 0 on success, 1 on error
    """

    # Enforce terms consent before trial activation
    try:
        require_consent("trial_activation")
    except ConsentRequiredError as e:
        _echo("Terms acceptance required before trial activation")
        _echo(f"Please accept the following terms: {', '.join(sorted(e.outstanding_terms))}")
        _echo("Visit https://epochly.com/legal to review terms")
        _echo("Run: epochly terms accept")
        return 1

    # Validate email format BEFORE showing policy info or prompting user
    if not validate_email(email):
        _echo("Error: Invalid email format")
        _echo("Please provide a valid email address")
        return 1

    if interactive:
        # Show clear policy information
        _echo("Trial Policy:")
        _echo("  - One trial per email address (lifetime)")
        _echo("  - One trial per machine (lifetime)")
        _echo("  - This email cannot be used on other machines")
        _echo("  - 30 days with ALL CPU cores enabled")
        _echo("")

        # Confirm with user (only in interactive TTY)
        if not sys.stdin.isatty():
            _echo("Error: Interactive confirmation required but stdin is not a TTY.")
            _echo("Use 'epochly trial --email ... --yes' for non-interactive mode.")
            return 1
        try:
            answer = input("Do you want to use this email for your one-time trial? [y/N]: ")
        except (EOFError, KeyboardInterrupt):
            _echo("\nTrial request cancelled")
            return 0
        if answer.strip().lower() not in ("y", "yes"):
            _echo("Trial request cancelled")
            return 0  # User cancelled -- not an error

    # Get machine fingerprint
    try:
        from epochly.compatibility.secure_node_auth import MachineFingerprint
        fingerprint = MachineFingerprint.generate()
    except Exception as e:
        logger.debug("Machine fingerprint generation failed", exc_info=True)
        _echo(f"Error generating machine fingerprint: {e}")
        _echo("Please ensure Epochly is properly installed")
        return 1

    # Show what we're doing
    _echo(f"Requesting trial for: {email}")
    _echo(f"Machine ID generated for: {email}")

    # Request trial via API
    try:
        api_base = get_api_base_url()
        response = requests.post(
            f'{api_base}/trial/activate',
            json={
                'email': email,
                'machine_id': fingerprint
            },
            timeout=get_api_timeout()
        )

        if response.status_code == 200:
            _echo("")
            _echo(f"Verification email sent to {email}")
            _echo("Check your email to activate your one-time trial")
            _echo("")
            _echo("Next steps:")
            _echo("  1. Open the activation email")
            _echo("  2. Use the activation link OR")
            _echo("  3. Run: epochly verify --token <token-from-email>")
            _echo("")
            _echo("Remember: This email cannot be used for trials on other machines")
            return 0  # Success

        elif response.status_code == 403:
            error_data = safe_json_parse(response)
            error_type = error_data.get('error') if error_data else None

            _echo("")
            if error_type == 'trial_already_used_machine':
                _echo("This machine has already used its one-time trial")
                _echo("")
                _echo("To unlock all cores, purchase a license:")
                _echo("  - Pro: $16/month (or $150/year) per machine")
                _echo("")
                _echo("Visit: https://epochly.com/pricing")

            elif error_type == 'trial_email_already_used':
                _echo(f"The email '{email}' has already been used for a trial")
                _echo("")
                _echo("Each email can only be used once, on one machine.")
                _echo("Options:")
                _echo("  - Use a different email address")
                _echo("  - Purchase a license at https://epochly.com/pricing")
            else:
                _echo("Trial request was denied.")

            return 1  # Forbidden error

        elif response.status_code == 400:
            error_data = safe_json_parse(response)
            _echo("")
            if error_data:
                _echo(f"Error: {error_data.get('message', 'Invalid request')}")
            else:
                _echo("Error: Invalid request")
            return 1

        else:
            _echo("")
            _echo("Error requesting trial. Please try again later.")
            _echo(f"Status: {response.status_code}")
            return 1

    except requests.exceptions.Timeout:
        logger.debug("Trial request timed out", exc_info=True)
        _echo("")
        _echo("Request timed out. Please check your internet connection.")
        return 1
    except requests.exceptions.ConnectionError:
        logger.debug("Trial request connection error", exc_info=True)
        _echo("")
        _echo("Cannot connect to Epochly servers.")
        _echo("Please check your internet connection.")
        return 1
    except Exception as e:
        logger.debug("Trial request unexpected error", exc_info=True)
        _echo("")
        _echo(f"Unexpected error: {e}")
        _echo("Please report this issue at https://github.com/epochly/epochly/issues")
        return 1


def _activate_impl(token: str) -> int:
    """
    Activate your 30-day trial using the token from your email.

    Core business logic for trial request.

    Args:
        token: Activation token from email.

    Returns: 0 on success, 1 on error
    """

    # Enforce terms consent before trial activation
    try:
        require_consent("trial_activation")
    except ConsentRequiredError as e:
        _echo("Terms acceptance required before trial activation")
        _echo(f"Please accept the following terms: {', '.join(sorted(e.outstanding_terms))}")
        _echo("Visit https://epochly.com/legal to review terms")
        _echo("Run: epochly terms accept")
        return 1

    _echo("Activating trial with token...")

    try:
        # Use the magic link confirmation endpoint with token
        # Use params= for proper URL encoding of token
        api_base = get_api_base_url()

        # SECURITY (PR #47 R2, Finding 1): Validate canonical URL BEFORE
        # sending the HTTP request. The token must never be transmitted to
        # a non-canonical endpoint -- even if the entitlement would be blocked
        # later, the token itself gets exfiltrated to the attacker.
        if not is_canonical_api_url(api_base):
            logger.warning(
                "SECURITY: Rejecting trial activation -- non-canonical API URL %r. "
                "Token was NOT sent.",
                api_base,
            )
            _echo("")
            _echo("Error: Trial activation rejected -- untrusted API endpoint.")
            _echo("Trial activation is only supported from official Epochly servers.")
            _echo("If you set EPOCHLY_API_URL, unset it and try again.")
            return 1

        # SECURITY (PR #47 R2, Finding 2): Disable redirects to prevent
        # a canonical URL from 302-redirecting to an attacker endpoint,
        # which would bypass the canonical check above.
        response = requests.get(
            f'{api_base}/trial/confirm',
            params={'token': token},
            headers={'Accept': 'application/json'},
            timeout=get_api_timeout(),
            allow_redirects=False,
        )

        if response.status_code == 200:
            # SECURITY (PR #47): Validate response strictly before granting entitlements.
            # A forged endpoint returning HTTP 200 with minimal JSON must not
            # be enough to grant trial entitlements.

            # Step 2: Parse and validate response schema
            data = safe_json_parse(response)
            is_valid, validation_error = _validate_activation_response(data)
            if not is_valid:
                logger.warning(
                    "SECURITY: Rejecting trial activation -- invalid response: %s",
                    validation_error,
                )
                _echo("")
                _echo("Error: Activation failed -- server returned an invalid response.")
                _echo("Please try again later or contact support.")
                return 1

            cpu_count = os.cpu_count() or 8

            # Issue #32: Store node credentials returned by the server
            node_id = data.get('node_id')
            node_secret = data.get('node_secret')
            if node_id and node_secret:
                try:
                    creds_path = _get_node_creds_path()
                    store_node_credentials(node_id, node_secret, creds_path=creds_path)
                    logger.debug("Node credentials stored to %s", creds_path)
                except Exception as exc:
                    logger.warning(
                        "Failed to store node credentials to %s: %s. "
                        "You can manually save your credentials -- "
                        "node_id: %s",
                        _get_node_creds_path(), exc, node_id,
                    )

            # EP-22: Update license enforcer immediately so the user gets
            # trial-tier limits without waiting for the next background sync.
            _update_enforcer_with_trial(data, api_url=api_base)

            _echo("")
            _echo("Trial activated successfully!")
            _echo("")
            _echo(f"Duration: {data.get('days_remaining', 30)} days")
            _echo(f"CPU Cores: ALL {cpu_count} cores enabled")
            _echo("")
            _echo("Your trial benefits:")
            _echo("  - Unlimited CPU cores")
            _echo("  - Advanced JIT compilation")
            _echo("  - Maximum parallel execution")
            _echo("")
            _echo("Trial reminders will be sent at 15, 7, and 1 day remaining")
            _echo("")
            _echo("To check your trial status anytime:")
            _echo("  epochly status")
            return 0  # Success

        elif response.status_code == 400:
            error_data = safe_json_parse(response)
            error = error_data.get('error') if error_data else None

            _echo("")
            if error == 'token_expired':
                _echo("Verification token has expired (24 hour limit)")
                _echo("Please request a new trial: epochly trial --email your@email.com")
            elif error == 'already_activated':
                _echo("Trial already activated")
                days = error_data.get('days_remaining', 0) if error_data else 0
                _echo(f"You have {days} days remaining")
                _echo("Check your trial status: epochly status")
                return 0  # Already activated is not an error for the user
            else:
                msg = error_data.get('message', 'Invalid token') if error_data else 'Invalid token'
                _echo(f"Error: {msg}")
            return 1

        elif response.status_code == 404:
            _echo("")
            _echo("Invalid verification token")
            _echo("Please check the token from your email and try again")
            return 1

        else:
            _echo("")
            _echo("Error verifying trial. Please try again later.")
            return 1

    except requests.exceptions.Timeout:
        logger.debug("Verify request timed out", exc_info=True)
        _echo("")
        _echo("Request timed out. Please check your internet connection.")
        return 1
    except requests.exceptions.ConnectionError:
        logger.debug("Verify request connection error", exc_info=True)
        _echo("")
        _echo("Cannot connect to Epochly servers.")
        _echo("Please check your internet connection.")
        return 1
    except Exception as e:
        logger.debug("Verify request unexpected error", exc_info=True)
        _echo("")
        _echo(f"Unexpected error: {e}")
        return 1


# Plain function wrappers for argparse dispatch

def trial(email: str) -> int:
    """Request a 30-day trial with email verification."""
    return _trial_impl(email, interactive=True)


def activate(token: str) -> int:
    """Activate your 30-day trial using the token from your email."""
    return _activate_impl(token)


def status() -> int:
    """Check your current Epochly license and trial status."""
    try:
        from epochly.licensing.license_enforcer import get_license_enforcer

        enforcer = get_license_enforcer()
        limits = enforcer.get_limits()

        print("License Status")
        print("-" * 50)

        tier = limits['tier'].upper()
        if tier == 'COMMUNITY':
            tier_display = "Community Edition (Free Forever)"
        elif tier == 'TRIAL':
            tier_display = "Trial (30 Days)"
        else:
            tier_display = tier.title()

        print(f"Tier: {tier_display}")

        max_cores = limits.get('max_cores')
        total_cores = os.cpu_count() or 8
        core_display = max_cores if max_cores is not None else total_cores
        if max_cores is not None:
            print(f"CPU Cores: {core_display} of {total_cores} available")
        else:
            print(f"CPU Cores: All {total_cores} cores enabled")

        gpu_enabled = limits.get('gpu_enabled', False)
        print(f"GPU Acceleration: {'Enabled' if gpu_enabled else 'Not Available'}")

        features = limits.get('features', [])
        if features:
            print(f"Features: {', '.join(features[:3])}")

        if limits['tier'] == 'trial':
            try:
                license_data = enforcer._license_data
                if license_data:
                    expires_at = license_data.get('expires_at')
                    if expires_at:
                        from datetime import datetime, timezone
                        expiry = datetime.fromisoformat(expires_at)
                        if expiry.tzinfo is None:
                            expiry = expiry.replace(tzinfo=timezone.utc)
                        now = datetime.now(timezone.utc)
                        days_remaining = max(0, (expiry - now).days)

                        print("")
                        print(f"Trial Days Remaining: {days_remaining}")

                        if days_remaining <= 7:
                            print("")
                            print(f"WARNING: Trial expires in {days_remaining} days!")
                            print("After expiration: Limited to 4 cores (Community Edition)")
                            print("Maintain full access: https://epochly.com/pricing")
            except Exception as e:
                logger.debug("Failed to get trial expiration info", exc_info=True)

        elif limits['tier'] == 'community':
            had_trial = enforcer.had_trial()

            print("")
            if had_trial:
                print("Trial Status: Already used (one-time only)")
                print("")
                print("Unlock all cores with a paid license:")
                print("  - Pro: $16/month (or $150/year) per machine")
                print("  - Visit: https://epochly.com/pricing")
            else:
                print("Trial Status: Available")
                print("")
                print(f"You're using {core_display} of {total_cores} available cores")
                print("Get a 30-day trial with ALL cores enabled:")
                print("  epochly trial --email user@example.com")
                print("")
                print("Note: Each email can only be used once, on one machine")

        return 0

    except Exception as e:
        logger.debug("Status check failed", exc_info=True)
        print(f"Error checking status: {e}")
        print("Please ensure Epochly is properly installed")
        return 1


# Alias for CLI compatibility - CLI imports 'verify' but function is 'activate'
verify = activate

# Export commands for CLI registration
__all__ = [
    'trial', 'activate', 'verify', 'status',
    '_trial_impl', '_activate_impl',
    'store_node_credentials', 'load_node_credentials', '_get_node_creds_path',
    'validate_email',
]
