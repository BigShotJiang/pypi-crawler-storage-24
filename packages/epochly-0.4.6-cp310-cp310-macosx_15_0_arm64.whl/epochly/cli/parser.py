"""
Epochly CLI argument parser.

Defines the argument parser, subcommands, and custom argparse actions
for the Epochly command-line interface.
"""

import argparse
import os


class PositiveIntAction(argparse.Action):
    """Custom action to validate positive integer values."""
    def __call__(self, parser, namespace, values, option_string=None):
        if values <= 0:
            parser.error(f"{option_string} must be a positive integer (got {values})")
        setattr(namespace, self.dest, values)


class NonNegativeIntAction(argparse.Action):
    """Custom action to validate non-negative integer values."""
    def __call__(self, parser, namespace, values, option_string=None):
        if values < 0:
            parser.error(f"{option_string} must be non-negative (got {values})")
        setattr(namespace, self.dest, values)


class PercentageAction(argparse.Action):
    """Custom action to validate percentage values (1-100)."""
    def __call__(self, parser, namespace, values, option_string=None):
        if values < 1 or values > 100:
            parser.error(f"{option_string} must be between 1 and 100 (got {values})")
        setattr(namespace, self.dest, values)


def create_parser(include_script_args=True, include_subcommands=True) -> argparse.ArgumentParser:
    """Create CLI argument parser

    Args:
        include_script_args: Whether to include positional script arguments.
                           Set to False for command-only mode to avoid conflicts.
        include_subcommands: Whether to include management subcommands.
                           Set to False for script-only mode to avoid conflicts.
    """
    if include_script_args:
        usage_str = "epochly [script.py] [script args...] or epochly [command] [options]"
    else:
        usage_str = "epochly [command] [options]"

    try:
        default_level = int(os.environ.get('EPOCHLY_LEVEL', '3'))
    except (ValueError, TypeError):
        default_level = 3

    parser = argparse.ArgumentParser(
        description="Epochly - Accelerate Python Scripts",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        usage=usage_str,
        epilog="""
Examples:
  epochly myscript.py              # Run script with Epochly acceleration
  epochly myscript.py --arg value  # Pass arguments to your script
  epochly -l 3 myscript.py         # Run with specific optimization level
  epochly status                   # Check Epochly status
  epochly health                   # Run health check
  epochly sitecustomize install    # Install transparent activation
        """
    )

    # --version flag: lazy import to avoid triggering full epochly init
    def _get_version_string():
        try:
            from importlib.metadata import version as _get_version
            return f"epochly {_get_version('epochly')}"
        except Exception:
            return (
                "epochly (version unknown - run 'pip show epochly' to check, "
                "or reinstall with 'pip install --upgrade epochly')"
            )

    parser.add_argument(
        "--version",
        action="version",
        version=_get_version_string(),
    )

    # Only add script arguments if requested (to avoid conflicts with subcommands)
    if include_script_args:
        # Script execution arguments (for running Python files)
        parser.add_argument(
            "script",
            nargs="?",
            help="Python script to run with Epochly acceleration"
        )

        parser.add_argument(
            "script_args",
            nargs=argparse.REMAINDER,
            help="Arguments to pass to the script"
        )

    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Enable verbose logging"
    )

    parser.add_argument(
        "-l", "--level",
        type=int,
        choices=[0, 1, 2, 3, 4],
        default=default_level,
        help="Optimization level (0=monitor, 1=conservative, 2=balanced, 3=aggressive, 4=gpu). "
             "Defaults to EPOCHLY_LEVEL env var if set, otherwise 3."
    )

    parser.add_argument(
        "--no-optimize",
        action="store_true",
        help="Disable automatic optimization (monitor only)"
    )

    # Memory pool configuration (per architecture spec)
    parser.add_argument(
        "--pin-pool",
        choices=["fast", "legacy", "sharded"],
        help="Pin to specific memory pool type"
    )

    parser.add_argument(
        "--allowed-pools",
        help="Comma-separated list of allowed memory pools"
    )

    # Core usage limits (per architecture spec)
    parser.add_argument(
        "--max-cores",
        type=int,
        action=PositiveIntAction,
        metavar="N",
        help="Maximum number of CPU cores to use"
    )

    parser.add_argument(
        "--max-cores-percent",
        type=int,
        action=PercentageAction,
        metavar="PERCENT",
        help="Maximum percentage of CPU cores to use (1-100)"
    )

    parser.add_argument(
        "--reserve-cores",
        type=int,
        action=NonNegativeIntAction,
        metavar="N",
        help="Number of cores to reserve for other processes"
    )

    # Advanced analysis commands (per architecture spec)
    parser.add_argument(
        "--profile",
        action="store_true",
        help="Save profiling data for analysis"
    )

    parser.add_argument(
        "--benchmark",
        action="store_true",
        help="Compare performance with and without Epochly"
    )

    parser.add_argument(
        "--check",
        action="store_true",
        help="Check compatibility without running (dry run)"
    )

    parser.add_argument(
        "--explain",
        action="store_true",
        help="Explain optimization decisions made by Epochly"
    )

    # Runtime configuration
    parser.add_argument(
        "--workers",
        type=int,
        help="Override default worker count"
    )

    if not include_subcommands:
        # Only add global --mode and --force for script execution mode.
        # In command mode, start/restart subparsers each define their own --mode,
        # and adding it globally would cause the subparser default to overwrite
        # any global value (argparse applies subparser defaults unconditionally).
        parser.add_argument(
            "--mode",
            choices=["monitor", "conservative", "balanced", "aggressive"],
            help="Optimization mode (overrides --level)"
        )

        parser.add_argument(
            "--force",
            action="store_true",
            help="Bypass optimization level progression gates (immediate level activation)"
        )

    parser.add_argument(
        "--debug",
        action="store_true",
        help="Enable debug mode with detailed logging"
    )

    # Python-compatible execution modes
    parser.add_argument(
        "-m",
        dest="module",
        help="Run library module as a script (like python -m)"
    )

    parser.add_argument(
        "-c",
        dest="exec_string",
        help="Execute program passed in as string (like python -c)"
    )

    # Only add subcommands if requested
    if include_subcommands:
        subparsers = parser.add_subparsers(dest="command", help="Management commands")

        # Status command
        status_parser = subparsers.add_parser("status", help="Show Epochly system status")
        status_parser.add_argument(
            '--json',
            action='store_true',
            dest='json_output',
            help='Output status in JSON format'
        )

        # Start command
        start_parser = subparsers.add_parser("start", help="Start Epochly system")
        start_parser.add_argument(
        "--mode",
        choices=["monitor", "conservative", "balanced", "aggressive"],
        default="balanced",
        help="Deployment mode (default: balanced)"
        )

        # Stop command
        subparsers.add_parser("stop", help="Stop Epochly system")

        # Restart command
        restart_parser = subparsers.add_parser("restart", help="Restart Epochly system")
        restart_parser.add_argument(
        "--mode",
        choices=["monitor", "conservative", "balanced", "aggressive"],
        default="balanced",
        help="Deployment mode (default: balanced)"
        )

        # Health command
        subparsers.add_parser("health", help="Perform health check")

        # Jupyter command
        jupyter_parser = subparsers.add_parser("jupyter", help="Jupyter integration commands")
        jupyter_subparsers = jupyter_parser.add_subparsers(dest="jupyter_command", help="Jupyter subcommands")

        # Jupyter install
        jupyter_install = jupyter_subparsers.add_parser("install", help="Install Epochly Jupyter kernel")
        jupyter_install.add_argument("--name", default="epochly", help="Kernel name")
        jupyter_install.add_argument("--display-name", default="Python (epochly)", help="Display name")
        jupyter_install.add_argument("--python", help="Python executable path (default: current)")
        jupyter_install.add_argument("--system", action="store_true", help="Install system-wide")
        jupyter_install.add_argument("--force", action="store_true", help="Overwrite existing")

        # Jupyter uninstall
        jupyter_uninstall = jupyter_subparsers.add_parser("uninstall", help="Uninstall Epochly Jupyter kernel")
        jupyter_uninstall.add_argument("--name", default="epochly", help="Kernel name")
        jupyter_uninstall.add_argument("--system", action="store_true", help="Remove from system")

        # Jupyter list
        jupyter_list = jupyter_subparsers.add_parser("list", help="List Epochly kernels")
        jupyter_list.add_argument("--system", action="store_true", help="List system kernels")

        # Jupyter setup
        jupyter_setup = jupyter_subparsers.add_parser("setup", help="Complete Jupyter setup")
        jupyter_setup.add_argument("--force", action="store_true", help="Overwrite existing")

        # Jupyter test
        jupyter_subparsers.add_parser("test", help="Test magic commands")

        # Sitecustomize command (install/uninstall transparent activation)
        sitecustomize_parser = subparsers.add_parser(
            "sitecustomize",
            help="Manage transparent Epochly activation via sitecustomize.py"
        )
        sitecustomize_subparsers = sitecustomize_parser.add_subparsers(
            dest="sitecustomize_command",
            help="Sitecustomize subcommands"
        )

        # Sitecustomize install
        sitecustomize_install = sitecustomize_subparsers.add_parser(
            "install",
            help="Install sitecustomize.py for transparent activation"
        )
        sitecustomize_install.add_argument(
            "--force",
            action="store_true",
            help="Force installation even if conflicts exist"
        )
        sitecustomize_install.add_argument(
            "--no-preserve",
            action="store_true",
            help="Don't preserve existing sitecustomize.py content"
        )

        # Sitecustomize uninstall
        sitecustomize_uninstall = sitecustomize_subparsers.add_parser(
            "uninstall",
            help="Uninstall Epochly sitecustomize.py"
        )
        sitecustomize_uninstall.add_argument(
            "--no-restore",
            action="store_true",
            help="Don't restore original sitecustomize.py from backup"
        )

        # Sitecustomize status
        sitecustomize_subparsers.add_parser(
            "status",
            help="Check sitecustomize.py installation status"
        )

        # Sitecustomize validate
        sitecustomize_subparsers.add_parser(
            "validate",
            help="Validate sitecustomize.py installation"
        )

        # Sitecustomize list-backups
        sitecustomize_subparsers.add_parser(
            "list-backups",
            help="List available sitecustomize.py backups"
        )

        # Shell command
        shell_parser = subparsers.add_parser("shell",
                                            help="Launch Epochly-enabled Python REPL",
                                            description="Launch Epochly-enabled Python REPL with enhanced performance monitoring")
        shell_parser.add_argument(
            "--startup",
            help="Path to startup script to execute on REPL start"
        )
        shell_parser.add_argument(
            "--no-banner",
            action="store_true",
            help="Suppress the Epochly banner on startup"
        )
        shell_parser.add_argument(
            "-i", "--interactive",
            action="store_true",
            help="Force interactive mode (default)"
        )
        shell_parser.add_argument(
            "-q", "--quiet",
            action="store_true",
            help="Quiet mode - minimal output"
        )

        # Config command
        config_parser = subparsers.add_parser("config", help="Manage Epochly configuration (set, get, reset, where)")
        config_subparsers = config_parser.add_subparsers(dest="config_command", help="Config subcommands")

        # Config show
        config_show = config_subparsers.add_parser("show", help="Show current configuration")
        config_show.add_argument("--global", dest="global_config", action="store_true", help="Show global configuration")
        config_show.add_argument("--local", dest="local_config", action="store_true", help="Show local configuration")
        config_show.add_argument("--system", dest="system_config", action="store_true", help="Show system configuration")

        # Config set
        config_set = config_subparsers.add_parser("set", help="Set configuration value")
        config_set.add_argument("key", help="Configuration key")
        config_set.add_argument("value", help="Configuration value")
        config_set.add_argument("--global", dest="global_config", action="store_true", help="Set in global configuration")
        config_set.add_argument("--local", dest="local_config", action="store_true", help="Set in local configuration")
        config_set.add_argument("--system", dest="system_config", action="store_true", help="Set in system configuration")

        # Config get
        config_get = config_subparsers.add_parser("get", help="Get configuration value")
        config_get.add_argument("key", help="Configuration key")
        config_get.add_argument("--global", dest="global_config", action="store_true", help="Get from global configuration")
        config_get.add_argument("--local", dest="local_config", action="store_true", help="Get from local configuration")
        config_get.add_argument("--system", dest="system_config", action="store_true", help="Get from system configuration")

        # Config reset
        config_reset = config_subparsers.add_parser("reset", help="Reset configuration to defaults")
        config_reset.add_argument("--force", action="store_true", help="Skip confirmation prompt")

        # Config where
        config_subparsers.add_parser("where", help="Show all loaded config files with precedence order")

        # Config wizard
        config_subparsers.add_parser("wizard", help="Run interactive configuration wizard")

        # Config export
        config_export = config_subparsers.add_parser("export", help="Export configuration")
        config_export.add_argument("--format", choices=["yaml", "json"], default="yaml", help="Export format")

        # Config import
        config_import = config_subparsers.add_parser("import", help="Import configuration")
        config_import.add_argument("file", help="Configuration file to import")

        # Doctor command
        # Note: --verbose/-v is inherited from the parent parser; do not re-add here
        # as it would shadow the parent's -v flag
        doctor_parser = subparsers.add_parser("doctor", help="Diagnose installation and compatibility")
        doctor_parser.add_argument(
            "--fix",
            action="store_true",
            help="Attempt to fix detected issues automatically"
        )
        doctor_parser.add_argument(
            "--json",
            action="store_true",
            help="Output results in JSON format"
        )

        # Trial command

        # Metrics command (IO-8: Monitor back-pressure)
        metrics_parser = subparsers.add_parser("metrics", help="Monitor performance metrics")
        metrics_subparsers = metrics_parser.add_subparsers(dest="metrics_command", help="Metrics subcommands")

        # Metrics drops
        metrics_drops = metrics_subparsers.add_parser("drops", help="Show dropped metrics count")
        metrics_drops.add_argument(
            "--reset",
            action="store_true",
            help="Reset drop counter after showing"
        )

        # Metrics config
        metrics_config = metrics_subparsers.add_parser("config", help="Configure metrics monitoring")
        metrics_config.add_argument(
            "--alert-interval",
            type=int,
            action=NonNegativeIntAction,
            help="Alert every N drops (0 to disable)"
        )


        # Terms command
        terms_parser = subparsers.add_parser(
            "terms",
            help="Manage terms acceptance (ToS, Privacy Policy, ESLA)"
        )
        terms_subparsers = terms_parser.add_subparsers(
            dest="terms_command",
            help="Terms subcommands"
        )

        # Terms accept
        terms_accept = terms_subparsers.add_parser(
            "accept",
            help="Accept outstanding terms"
        )
        terms_accept.add_argument(
            "--non-interactive",
            action="store_true",
            help="Accept all outstanding terms without prompting"
        )

        # Terms show
        terms_show = terms_subparsers.add_parser(
            "show",
            help="Show acceptance status for all terms"
        )
        terms_show.add_argument(
            "--json",
            action="store_true",
            dest="json_output",
            help="Output status in JSON format"
        )

        # Terms list
        terms_subparsers.add_parser(
            "list",
            help="List available terms documents"
        )

        trial_parser = subparsers.add_parser(
            "trial",
            help="Request a 30-day trial with email verification",
            epilog="Example: epochly trial --email user@example.com",
            formatter_class=argparse.RawDescriptionHelpFormatter,
        )
        trial_parser.add_argument(
            "--email",
            required=True,
            help="Email for one-time trial activation (can only be used once)"
        )
        trial_parser.add_argument(
            "--yes", "-y",
            action="store_true",
            help="Skip confirmation prompt (non-interactive mode)"
        )

        # Verify command
        verify_parser = subparsers.add_parser("verify", help="Verify email and activate your 30-day trial")
        verify_parser.add_argument(
            "--token",
            required=True,
            help="Verification token from email"
        )

        # Activate command (cross-reference to epochly-license)
        activate_parser = subparsers.add_parser(
            "activate",
            help="Verify trial token (same as 'epochly verify --token')"
        )
        activate_parser.add_argument(
            "key",
            nargs="?",
            default=None,
            help="License key to activate"
        )

        # Billing command
        billing_parser = subparsers.add_parser(
            "billing",
            help="Manage Epochly Pro subscription"
        )
        billing_subparsers = billing_parser.add_subparsers(
            dest="billing_command",
            help="Billing subcommands"
        )
        billing_portal = billing_subparsers.add_parser(
            "portal",
            help="Send a customer portal link to your email"
        )
        billing_portal.add_argument(
            "--email",
            help="Email address (uses cached email or prompts if not provided)"
        )
        billing_subparsers.add_parser(
            "status",
            help="Show subscription status from local cache"
        )
        billing_subparsers.add_parser(
            "cancel",
            help="Show step-by-step cancellation instructions"
        )

        # Devices command
        devices_parser = subparsers.add_parser(
            "devices",
            help="Manage device slots for multi-device licensing"
        )
        devices_subparsers = devices_parser.add_subparsers(
            dest="devices_command",
            help="Device subcommands"
        )
        devices_subparsers.add_parser(
            "list",
            help="List all devices for the current license"
        )
        devices_rename = devices_subparsers.add_parser(
            "rename",
            help="Rename a device slot"
        )
        devices_rename.add_argument("old_name", help="Current device slot name")
        devices_rename.add_argument("new_name", help="New device slot name")
        devices_remove = devices_subparsers.add_parser(
            "remove",
            help="Remove a device from a slot"
        )
        devices_remove.add_argument("slot_name", help="Device slot name to remove")
        devices_remove.add_argument(
            "--force",
            action="store_true",
            help="Skip confirmation prompt"
        )
        devices_subparsers.add_parser(
            "sync",
            help="Force device sync with the server"
        )

    return parser
