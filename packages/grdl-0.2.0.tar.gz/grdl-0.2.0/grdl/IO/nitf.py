# -*- coding: utf-8 -*-
"""
NITF Reader - Read National Imagery Transmission Format files.

Base data format reader for generic NITF imagery. For SAR-specific NITF
files (SICD, SIDD), use the dedicated SAR readers which extract SAR XML
metadata that this generic reader does not parse.

Dependencies
------------
rasterio

Author
------
Duane Smalley, PhD
duane.d.smalley@gmail.com

License
-------
MIT License
Copyright (c) 2024 geoint.org
See LICENSE file for full text.

Created
-------
2026-02-09

Modified
--------
2026-02-10
"""

# Standard library
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

# Third-party
import numpy as np

try:
    import rasterio
    from rasterio.windows import Window
    _HAS_RASTERIO = True
except ImportError:
    _HAS_RASTERIO = False

# GRDL internal
from grdl.IO.base import ImageReader, ImageWriter
from grdl.IO.models import ImageMetadata


class NITFReader(ImageReader):
    """Read standard NITF imagery via GDAL's NITF driver.

    Reads generic NITF files containing standard imagery segments.
    For SAR-specific NITF files (SICD, SIDD), use ``SICDReader`` or
    ``SIDDReader`` instead — those extract SAR XML metadata that this
    reader does not parse.

    Parameters
    ----------
    filepath : str or Path
        Path to the NITF file.

    Attributes
    ----------
    filepath : Path
        Path to the NITF file.
    metadata : Dict[str, Any]
        Standardized metadata dictionary.
    dataset : rasterio.DatasetReader
        Rasterio dataset object.

    Raises
    ------
    ImportError
        If rasterio is not installed.
    FileNotFoundError
        If the file does not exist.
    ValueError
        If the file cannot be opened as NITF.

    Examples
    --------
    >>> from grdl.IO.nitf import NITFReader
    >>> with NITFReader('image.ntf') as reader:
    ...     chip = reader.read_chip(0, 512, 0, 512)
    ...     print(reader.metadata['format'])
    'NITF'
    """

    def __init__(self, filepath: Union[str, Path]) -> None:
        if not _HAS_RASTERIO:
            raise ImportError(
                "rasterio is required for NITF reading. "
                "Install with: pip install rasterio"
            )
        super().__init__(filepath)

    def _load_metadata(self) -> None:
        """Load NITF metadata using rasterio (GDAL NITF driver)."""
        try:
            self.dataset = rasterio.open(str(self.filepath))

            extras: Dict[str, Any] = {
                'transform': self.dataset.transform,
                'bounds': self.dataset.bounds,
            }

            tags = self.dataset.tags()
            if tags:
                extras['tags'] = dict(tags)

            self.metadata = ImageMetadata(
                format='NITF',
                rows=self.dataset.height,
                cols=self.dataset.width,
                bands=self.dataset.count,
                dtype=str(self.dataset.dtypes[0]),
                crs=str(self.dataset.crs) if self.dataset.crs else None,
                nodata=self.dataset.nodata,
                extras=extras,
            )

        except Exception as e:
            raise ValueError(f"Failed to load NITF metadata: {e}") from e

    def read_chip(
        self,
        row_start: int,
        row_end: int,
        col_start: int,
        col_end: int,
        bands: Optional[List[int]] = None,
    ) -> np.ndarray:
        """Read a spatial chip from the NITF file.

        Parameters
        ----------
        row_start : int
            Starting row index (inclusive).
        row_end : int
            Ending row index (exclusive).
        col_start : int
            Starting column index (inclusive).
        col_end : int
            Ending column index (exclusive).
        bands : Optional[List[int]]
            Band indices to read (0-based). If None, read all bands.

        Returns
        -------
        np.ndarray
            Image chip with shape ``(rows, cols)`` for single band or
            ``(bands, rows, cols)`` for multi-band.

        Raises
        ------
        ValueError
            If indices are out of bounds.
        """
        if row_start < 0 or col_start < 0:
            raise ValueError("Start indices must be non-negative")
        if row_end > self.metadata['rows'] or col_end > self.metadata['cols']:
            raise ValueError("End indices exceed image dimensions")

        window = Window(
            col_start, row_start,
            col_end - col_start, row_end - row_start,
        )

        if bands is None:
            data = self.dataset.read(window=window)
        else:
            data = self.dataset.read([b + 1 for b in bands], window=window)

        if data.shape[0] == 1:
            return data[0]
        return data

    def read_full(self, bands: Optional[List[int]] = None) -> np.ndarray:
        """Read the entire NITF image.

        Parameters
        ----------
        bands : Optional[List[int]]
            Band indices to read (0-based). If None, read all bands.

        Returns
        -------
        np.ndarray
            Full image data.
        """
        if bands is None:
            data = self.dataset.read()
        else:
            data = self.dataset.read([b + 1 for b in bands])

        if data.shape[0] == 1:
            return data[0]
        return data

    def get_shape(self) -> Tuple[int, ...]:
        """Get image dimensions.

        Returns
        -------
        Tuple[int, ...]
            ``(rows, cols)`` for single band or
            ``(rows, cols, bands)`` for multi-band.
        """
        if self.metadata['bands'] == 1:
            return (self.metadata['rows'], self.metadata['cols'])
        return (
            self.metadata['rows'],
            self.metadata['cols'],
            self.metadata['bands'],
        )

    def get_dtype(self) -> np.dtype:
        """Get the data type of the image.

        Returns
        -------
        np.dtype
        """
        return np.dtype(self.metadata['dtype'])

    def close(self) -> None:
        """Close the rasterio dataset."""
        if hasattr(self, 'dataset') and self.dataset is not None:
            self.dataset.close()


class NITFWriter(ImageWriter):
    """Write arrays to NITF format via rasterio's NITF driver.

    Writes single-band and multi-band arrays to NITF format with
    optional geolocation metadata (CRS and affine transform). Uses
    rasterio (GDAL NITF driver) as the backend.

    Parameters
    ----------
    filepath : str or Path
        Output NITF file path (``.nitf`` or ``.ntf``).
    metadata : ImageMetadata, optional
        Typed metadata to embed. Recognized extras keys:

        - ``'ic'``: Image compression (``'NC'`` for no compression,
          default).
        - ``'irep'``: Image representation (``'MONO'``, ``'MULTI'``,
          ``'RGB'``).

    Raises
    ------
    ImportError
        If rasterio is not installed.

    Examples
    --------
    >>> from grdl.IO.nitf import NITFWriter
    >>> import numpy as np
    >>> data = np.random.rand(64, 64).astype(np.float32)
    >>> with NITFWriter('output.nitf') as writer:
    ...     writer.write(data)
    """

    def __init__(
        self,
        filepath: Union[str, Path],
        metadata: Optional[ImageMetadata] = None,
    ) -> None:
        if not _HAS_RASTERIO:
            raise ImportError(
                "rasterio is required for NITF writing. "
                "Install with: pip install rasterio"
            )
        super().__init__(filepath, metadata)

    def write(
        self,
        data: np.ndarray,
        geolocation: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Write image data to a NITF file.

        Parameters
        ----------
        data : np.ndarray
            Image data with shape ``(rows, cols)`` for single-band or
            ``(bands, rows, cols)`` for multi-band.
        geolocation : Dict[str, Any], optional
            Geolocation information. Recognized keys:

            - ``'crs'``: CRS string (e.g., ``'EPSG:4326'``)
            - ``'transform'``: Affine transform (rasterio ``Affine`` or
              6-element tuple)

        Raises
        ------
        ValueError
            If data has unsupported number of dimensions.
        """
        if data.ndim == 2:
            count = 1
            height, width = data.shape
            write_data = data[np.newaxis, :, :]
        elif data.ndim == 3:
            count, height, width = data.shape
            write_data = data
        else:
            raise ValueError(
                f"Expected 2D or 3D array, got {data.ndim}D"
            )

        crs = None
        transform = None
        if geolocation:
            crs = geolocation.get('crs')
            transform = geolocation.get('transform')

        profile = {
            'driver': 'NITF',
            'height': height,
            'width': width,
            'count': count,
            'dtype': str(data.dtype),
        }

        ic = self.metadata.get('ic', 'NC') if self.metadata else 'NC'
        profile['IC'] = ic

        if crs is not None:
            profile['crs'] = crs
            # NITF driver requires ICORDS creation option for CRS
            profile['ICORDS'] = 'G'
        if transform is not None:
            profile['transform'] = transform

        with rasterio.open(str(self.filepath), 'w', **profile) as ds:
            ds.write(write_data)

    def write_chip(
        self,
        data: np.ndarray,
        row_start: int,
        col_start: int,
        geolocation: Optional[Dict[str, Any]] = None,
    ) -> None:
        """Write a spatial subset to an existing NITF file.

        The file must already exist (created by a prior ``write()`` call).

        Parameters
        ----------
        data : np.ndarray
            Image chip with shape ``(rows, cols)`` for single-band or
            ``(bands, rows, cols)`` for multi-band.
        row_start : int
            Starting row index in the output file.
        col_start : int
            Starting column index in the output file.
        geolocation : Dict[str, Any], optional
            Not used for chip writes (geolocation is set at file level).

        Raises
        ------
        IOError
            If the output file does not exist.
        ValueError
            If data has unsupported number of dimensions.
        """
        if not self.filepath.exists():
            raise IOError(
                f"File {self.filepath} does not exist. "
                "Call write() first to create the file."
            )

        if data.ndim == 2:
            write_data = data[np.newaxis, :, :]
        elif data.ndim == 3:
            write_data = data
        else:
            raise ValueError(
                f"Expected 2D or 3D array, got {data.ndim}D"
            )

        height = write_data.shape[1]
        width = write_data.shape[2]
        window = Window(col_start, row_start, width, height)

        with rasterio.open(str(self.filepath), 'r+') as ds:
            ds.write(write_data, window=window)
