v 0.23.0
========
- Added support for `Worklists` plugin
- BREAKING CHANGES: 
  - `HttpError` no longer have a `dimse_error_status` field in case of DICOM related errors (it was actually not functional !).
    It is now replaced by an `error_payload` field.
  - `JobInfo` no longer has a `dimseErrorStatus` field (it was actually not functional !)


v 0.22.2
========

- Added support for `OT` modality in `helpers.generate_test_dicom_file`

v 0.22.1
========

- Added `dicomweb_servers.retrieve_study`, `retrieve_series` and `retrieve_instance`


v 0.21.0
========

- Added `requested_tags` for `find`method on `studies`

v 0.20.1
========

- `HttpError` might now have a `dimse_error_status` field in case of DICOM related errors

v 0.20.0
========

- Added `Modalities.get_async()` & `Modalities.move_async()`

v 0.19.0
========

- Added `Instance.get_metadata()`
- Added `Study.get_instances()` that also retrieves the metadata in a single API call
- fix `Instances.has_metadata`


v 0.18.8
========

- Added `is_stable` property for `study`.
- Still in `study`, modified `last_update` property to reflect current value.


v 0.18.7
========

- fix in `get_preview_file` method.


v 0.18.6
========

- enhanced `Studies.find` to allow sorting and pagination.

v 0.18.5
========

- New `endpoint` argument to `upload_files_dicom_web` method.
- #7: fix wrong exception handling 

v 0.18.4
========

- Added `labels` property in `Patient`, `Study`, `Series` and `Instance`.

v 0.18.3
========

- Fixed the `get_preview_file` method in case of unsupported image.

v 0.18.2
========

- Added the `get_preview_file` method.


v 0.18.1
========

- Fixed a bug in `get_preview_url` method.

v 0.18.0
========

- Added `OrthancApiClient.modalities.get_study`, `get_series`, `get_instance` to retrieve resources with C-GET.

v 0.17.0
========

- Added `OrthancApiClient.instances.anonymize_bulk` and `OrthancApiClient.instances.anonymize_bulk_async`

v 0.16.3
========

- Avoid pydicom warning when generating test files

v 0.16.2
========

- `o.is_orthanc_version_at_least()` and `o.is_plugin_version_at_least()` now support "mainline-commitId" patterns

v 0.16.1
========

- Added `capabilities`:
  - `o.Capabilities.has_extended_find`
  - `o.Capabilities.has_extended_changes`
  - `o.Capabilities.has_label_support`
  - `o.Capabilities.has_revision_support`

v 0.16.0
========

- Fixed an incompatibility with pydicom 3.0.0

v 0.15.3
========
 
- Added an option to `upload_folder_return_details` method to unzip files (if any) before upload


v 0.15.2
========
 
- Fix `to_dicom_time` method in Helpers
- Added `to_dicom_time_from_seconds` method in Helpers


v 0.15.1
========
 
- The `OrthancApiClient` now implements 3 retries in case of:
  - ConnectionError
  - 502 Bad Gateway
  - 503 Service Unavailable
- added `permissive` argument to `OrthancApiClient.resources.modify_bulk` 


v 0.15.0
========

- **BREAKING CHANGE:** `OrthancApiClient.instances.modify_bulk` now returns a tuple with
  `modified_instances_ids, modifies_series_ids, modified_studies_ids, modifies_patients_ids`
- **BREAKING CHANGE:** `modify_instance_by_instance` has been removed since recent Orthanc versions allow
  using `force=True` and `keep_tags` can preserve DICOM identifiers


v 0.14.14
=========

- Fix #4: re-allow `endpoint` argument to start with a `'/'` e.g. in `get_json()`

v 0.14.12
========
- fixed slash bug affecting several methods: `get_changes`, `get_all_labels`, `get_log_level`, `set_log_level`

v 0.14.11
========
- added `upload_folder_return_details` method in `OrthancApiClient`
- added `__repr__` to `OrthancApiClient` for nice display in debugger.

v 0.14.10
========

- added functions to check the Orthanc and plugin versions:
  `helpers.is_version_at_least`, `OrthancApiClient.is_orthanc_version_at_least`
  `OrthancApiClient.is_plugin_version_at_least`, `OrthancApiClient.has_loaded_plugin`.

v 0.14.8
========

- added `helpers.from_dicom_date_and_time` and `helpers.from_dicom_time`

v 0.14.6
========

- added a `RemoteJob` class that can be created when a `PULL_TRANSFER` is created

v 0.14.5
========

- added `get_statistics()` in `OrthancApiClient`

v 0.14.4
========

- `ignore_errors` in `upload` methods now ignoring 409 errors (conflict)

v 0.14.3
========

- added `get_log_level` and `set_log_level` in `OrthancApiClient`

v 0.14.2
========

- added `execute_lua_script` in `OrthancApiClient`


v 0.14.1
========

- introduced `patients`

v 0.14.0
========

- **BREAKING CHANGE:** `DicomModalities.send_async` was actually not asynchronous and 
  now returns a job.

v 0.13.8
========

- added `local_aet` arg for `DicomModalities.send` and `DicomModalities.send_async`

v 0.13.7
========

- added `Study.last_update`


v 0.13.6
========

- added `headers` arg to the `OrthancApiClient` constructor

v 0.13.5
========

- added `Resources.download_media()` and `Resources.download_archive()` 
- added `InstancesSet.download_media()` and `InstancesSet.download_archive()` 

v 0.13.4
========

- added `Modalities.get_all_ids()`
- added `Modalities.get_id_from_aet()`
- added `Study.info.patient_orthanc_id`
- added `Resources.exists()`

v 0.13.3
========

- added `Studies.get_modalities` and `Studies.get_first_instance_tags()`

v 0.13.2
========

- `Modalities.send` and `Modalities.store`:
  - `timeout` is now a float argument (more pythonic) 
- added `keep_tags` argument to `modify()`


v 0.13.1
========

- added `get_labels`, `add_label`, `add_labels`, `delete_label`, `delete_labels`
  at all resources levels
- added `OrthancApiClient.get_all_labels` to return all labels in Orthanc
- added `labels` and `label_constraint` arguments to `studies.find`

v 0.12.2
========

- `Modalities.send` and `Modalities.store`:
  - **BREAKING CHANGE:** removed `synchronous` argument: it is always synchronous
  - added an optional `timeout` argument

v 0.11.8
========

- `InstancesSet` ids are reproducible (based on a hash of their initial content)
- more detailed HttpError

v 0.11.7
========

- fix `Series.statistics` and `Study.statistics`
- uniformized logger names to `__name__`

v 0.11.5
========
- added `Modalities.configure`, `Modalities.delete` and `Modalities.get_configuration`

v 0.11.4
========
- fix `InstancesSet.filter_instances`

v 0.11.3
========
- fix metadata default value

v 0.11.2
========

- added `keep_tags` to `Instances.modify`

v 0.11.1
========

- added `InstancesSet.id`
- `InstancesSet.api_client` is now public

v 0.11.0
========

- **BREAKING CHANGE:** renamed `dicomweb_servers.send_asynchronous` into `dicomweb_servers.send_async`
- for every target (`peers, transfers, modalities, dicomweb_server`) we now have both:
  - `send()` that is synchronous
  - and `send_async()` that is asynchronous and returns the job that has been created

v 0.10.2
========

- added synchronous `dicomweb_servers.send()`

v 0.10.1
========

- InstancesSet.filter_instances() now returns and instance set with the excluded instances

v 0.10.0
========

- **BREAKING CHANGE:** renamed `set_metadata` into `set_string_metadata` & `set_binary_metadata`
- **BREAKING CHANGE:** renamed `get_metadata` into `get_string_metadata` & `get_binary_metadata`
- added `InstancesSet.filter_instances()` & `InstancesSet.process_instances()` 

v 0.9.1
=======

- introduced `InstancesSet` class

v 0.9.0
=======

- **BREAKING CHANGE:** renamed `download_study` and `download_series` into `download_instances`
- introduced `Series`, `SeriesInfo`, `Instance` and `InstanceInfo` classes

v 0.8.3
=======

- added download methods for instances, series, studies

v 0.8.2
=======

- added pdf (and png/jpg) import tools

v 0.8.1
=======

- made HttpClient available for lib users

v 0.8.0
=======

- **BREAKING CHANGE:** removed the `stow_rs` method from the `DicomWebServers` class

v 0.7.1
=======

- fixed absolute url in `upload` methods.

v 0.7.0
=======

- **BREAKING CHANGE:** renamed the `modality` argument of `client.modalities.send()` and 
  `client.modalities.store()` into `target_modality` to be more consistent with `send()` methods.


v 0.6.1
=======

- added `job.wait_completed()'

v 0.6.0
=======

- added `client.peers.send()'

v 0.5.8
=======

- **BREAKING CHANGE:** renamed `client.upload_file_dicom_web` into `client.upload_files_dicom_web`
  and added support for multiple files
- any HTTP status between 200 and 300 is now considered as a success and won't
  raise exceptions anymore

v 0.5.7
=======

- added `client.upload_file_dicom_web`

v 0.5.6
=======

- added `client.transfers.send`

v 0.5.5
=======

- fix relative url of various methods

v 0.5.1
=======

- added `studies.merge`

v 0.5.0
=======

- BREAKING_CHANGE: renamed `relative_url` arg into `endpoint` for `get, put, post, get_json, ...`
- added `retry, cancel, pause, ...` to `jobs`

v 0.4.1
=======

- added `ignore_errors` to `delete` methods

v 0.4.0
=======

- BREAKING_CHANGE: renamed `dicom_servers.send` into `dicom_servers.send_asynchronous`
- added Job, JobType, JobStatus, JobInfo classes
- new resource `jobs` in api_client: `orthanc.jobs.get(orthanc_id=...)`