"""Redpill - AI-powered generic SDK for dynamic chart generation."""

__version__ = "0.2.0"

from redpillx.client import Redpill

__all__ = ["Redpill", "__version__"]
