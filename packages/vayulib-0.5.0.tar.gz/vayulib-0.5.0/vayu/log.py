import logging
import os
import sys
import datetime
from pytz import timezone

LOGGING_TZ = timezone(os.getenv("TZ", "UTC"))


def _format_time(self, record, _=None):
    return (
        datetime.datetime.fromtimestamp(record.created, datetime.timezone.utc)
        .replace(microsecond=0)
        .astimezone(LOGGING_TZ)
        .isoformat(sep="T")
    )


formatter = logging.Formatter("[%(asctime)s] %(levelname)s> %(message)s")
logging.Formatter.formatTime = _format_time

_asyncio_logger = logging.getLogger("asyncio")
L = logging.getLogger()

_asyncio_logger.setLevel(logging.WARNING)
L.setLevel(os.getenv("LOG_LEVEL", "INFO").upper())

_handler = logging.StreamHandler(sys.stdout)
_handler.setLevel(logging.INFO)
_handler.setFormatter(formatter)
L.addHandler(_handler)
_asyncio_logger.addHandler(_handler)

def _rss_gib():
    try:
        with open(f"/proc/{os.getpid()}/statm") as f:
            return int(f.read().split()[1]) * os.sysconf("SC_PAGE_SIZE") / (1 << 30)
    except OSError:
        import psutil
        return psutil.Process().memory_info().rss / (1 << 30)


def mem(msg, *args, level=logging.INFO, **kwargs):
    L.log(level, f"{msg} [mem: {_rss_gib():.1f} GiB]", *args, **kwargs)


L.i = L.info
L.d = L.debug
L.e = L.error
L.w = L.warning
L.c = L.critical
L.mem = mem

__all___ = [L]
