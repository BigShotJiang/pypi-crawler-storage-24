# amads.pitch package initializer
