# amads.io package initializer
