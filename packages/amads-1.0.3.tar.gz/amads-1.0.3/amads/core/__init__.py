# amads.core package initializer
