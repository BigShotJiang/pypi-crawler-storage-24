# amads.music package initializer
