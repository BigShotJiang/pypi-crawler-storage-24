# amads.algorithms package initializer
