# amads package initializer
