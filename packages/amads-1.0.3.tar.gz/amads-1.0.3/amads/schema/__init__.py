# amads.schema package initializer
