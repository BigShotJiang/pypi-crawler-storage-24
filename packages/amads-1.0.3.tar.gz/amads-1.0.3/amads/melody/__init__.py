# amads.melody package initializer
