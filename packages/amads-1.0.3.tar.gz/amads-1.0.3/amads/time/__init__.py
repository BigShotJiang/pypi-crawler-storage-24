# amads.time package initializer
