"""Main JupyterRunner class for executing Python code on remote Jupyter servers.

This module provides the core JupyterRunner class for:
- Executing Python code and .py files on remote Jupyter kernels
- Uploading/downloading files via Contents API or kernel execution
- Managing kernel lifecycle (start, stop, restart, connect)

Typical usage:
    from pyrun_jupyter import JupyterRunner
    
    with JupyterRunner("http://localhost:8888", token="xxx") as runner:
        # Run code
        result = runner.run("print('Hello!')")
        
        # Upload project
        runner.upload_directory_via_kernel("./project", "remote_project")
        
        # Run file and get results
        result = runner.run_file("train.py", params={"epochs": 10})
        
        # Download outputs
        runner.download_kernel_files(["model.pth"], "./results", "remote_project")
"""

from __future__ import annotations

import base64
import json
import os
import posixpath
from pathlib import Path, PurePosixPath
from typing import Optional, Dict, Any, Union, List, Tuple

from .kernel import KernelManager
from .contents import ContentsManager
from .websocket import KernelWebSocket
from .result import ExecutionResult
from .exceptions import ConnectionError, KernelError


class JupyterRunner:
    """Execute Python code and files on a remote Jupyter server.
    
    This class provides a complete interface for remote Python execution including:
    - Code execution: run(), run_file()
    - File transfer via API: upload_file(), download_file(), upload_directory()
    - File transfer via kernel: upload_via_kernel(), download_kernel_files()
    - Kernel management: start_kernel(), stop_kernel(), restart_kernel()
    
    Attributes:
        url: Jupyter server URL
        token: Authentication token
        kernel_name: Name of kernel specification (e.g., "python3")
        kernel_id: ID of currently connected kernel (None if not connected)
        is_connected: Whether currently connected to a kernel
    
    Example:
        Basic usage::
        
            runner = JupyterRunner("http://localhost:8888", token="your_token")
            result = runner.run("print('Hello!')")
            print(result.stdout)  # Hello!
            runner.stop_kernel()
        
        Context manager (recommended)::
        
            with JupyterRunner("http://localhost:8888", token="xxx") as runner:
                result = runner.run_file("script.py")
                print(result.stdout)
            # Kernel automatically stopped
        
        File transfer for Kaggle/remote environments::
        
            with JupyterRunner(kaggle_url) as runner:
                # Upload entire project
                runner.upload_directory_via_kernel("./my_project", "project")
                
                # Run training
                runner.run("import os; os.chdir('project'); exec(open('train.py').read())")
                
                # Download results
                runner.download_kernel_files(
                    ["model.pth", "metrics.json"],
                    local_dir="./results",
                    working_dir="project"
                )
    """
    
    DEFAULT_EXCLUDE_PATTERNS = [
        "__pycache__",
        "*.pyc",
        ".git",
        ".venv",
        "venv",
        "*.egg-info",
        ".mypy_cache",
        ".pytest_cache",
        ".ipynb_checkpoints",
    ]
    DEFAULT_REMOTE_PROJECT_DIR = ".pyrun_jupyter/project"

    # Class-level type hints for better IDE support
    url: str
    token: Optional[str]
    kernel_name: str
    auto_start_kernel: bool
    reuse_kernel: bool
    _kernel_manager: KernelManager
    _contents_manager: ContentsManager
    _kernel_id: Optional[str]
    _websocket: Optional[KernelWebSocket]
    
    def __init__(
        self,
        url: str,
        token: Optional[str] = None,
        kernel_name: str = "python3",
        auto_start_kernel: bool = True,
        reuse_kernel: bool = True,
    ) -> None:
        """Initialize JupyterRunner.
        
        Args:
            url: Jupyter server URL (e.g., "http://localhost:8888" or Kaggle proxy URL)
            token: Authentication token for the server (None for token-less auth)
            kernel_name: Name of kernel to use (default: "python3")
            auto_start_kernel: Whether to start a kernel automatically on first run
            reuse_kernel: Whether to reuse existing kernel on reconnection (default: True)
        
        Raises:
            ConnectionError: If cannot connect to the Jupyter server
        """
        self.url = url.rstrip("/")
        self.token = token
        self.kernel_name = kernel_name
        self.auto_start_kernel = auto_start_kernel
        self.reuse_kernel = reuse_kernel
        
        self._kernel_manager = KernelManager(self.url, token)
        self._contents_manager = ContentsManager(self.url, token)
        self._kernel_id: Optional[str] = None
        self._websocket: Optional[KernelWebSocket] = None
        
        # Validate connection on initialization
        self._validate_connection()
    
    @property
    def kernel_id(self) -> Optional[str]:
        """Get current kernel ID."""
        return self._kernel_id
    
    @property
    def is_connected(self) -> bool:
        """Check if connected to a kernel."""
        return self._kernel_id is not None and self._websocket is not None
    
    def start_kernel(self, name: str = None) -> str:
        """Start a new kernel.
        
        Args:
            name: Kernel name (uses default if not specified)
            
        Returns:
            Kernel ID
        """
        kernel_name = name or self.kernel_name
        kernel_info = self._kernel_manager.start_kernel(kernel_name)
        self._kernel_id = kernel_info["id"]
        
        # Create WebSocket connection
        ws_url = self._kernel_manager.get_websocket_url(self._kernel_id)
        self._websocket = KernelWebSocket(ws_url)
        self._websocket.connect()
        
        return self._kernel_id
    
    def stop_kernel(self) -> None:
        """Stop the current kernel."""
        if self._websocket:
            self._websocket.close()
            self._websocket = None
        
        if self._kernel_id:
            self._kernel_manager.stop_kernel(self._kernel_id)
            self._kernel_id = None
    
    def restart_kernel(self) -> None:
        """Restart the current kernel."""
        if self._kernel_id:
            self._kernel_manager.restart_kernel(self._kernel_id)
    
    def list_kernels(self) -> list:
        """List all running kernels on the server."""
        return self._kernel_manager.list_kernels()
    
    def connect_to_kernel(self, kernel_id: str) -> None:
        """Connect to an existing kernel.
        
        Args:
            kernel_id: ID of the kernel to connect to
        """
        # Verify kernel exists
        self._kernel_manager.get_kernel_info(kernel_id)
        
        self._kernel_id = kernel_id
        ws_url = self._kernel_manager.get_websocket_url(kernel_id)
        self._websocket = KernelWebSocket(ws_url)
        self._websocket.connect()
    
    def _validate_connection(self) -> None:
        """Validate connection to Jupyter server.
        
        Raises:
            ConnectionError: If cannot connect to server or authentication fails
        """
        try:
            # Try to list kernels to validate connection
            self._kernel_manager.list_kernels()
        except Exception as e:
            raise ConnectionError(f"Failed to connect to Jupyter server at {self.url}: {e}")
    
    def _find_reusable_kernel(self) -> Optional[str]:
        """Find an existing kernel that can be reused.
        
        Returns:
            Kernel ID if found, None otherwise
        """
        if not self.reuse_kernel:
            return None
        
        try:
            kernels = self._kernel_manager.list_kernels()
            for kernel in kernels:
                if kernel.get("name") == self.kernel_name:
                    return kernel.get("id")
        except Exception:
            pass
        return None
    
    def _ensure_kernel(self) -> None:
        """Ensure a kernel is running, start one if needed.
        
        If reuse_kernel is True, will try to connect to existing kernel first.
        """
        if self._kernel_id:
            return
        
        if self.auto_start_kernel:
            # Try to reuse existing kernel first
            existing_kernel = self._find_reusable_kernel()
            if existing_kernel:
                self.connect_to_kernel(existing_kernel)
            else:
                self.start_kernel()
        else:
            raise KernelError("No kernel running. Call start_kernel() first.")
    
    def run(self, code: str, timeout: float = 60.0) -> ExecutionResult:
        """Execute Python code on the remote kernel.
        
        Args:
            code: Python code to execute
            timeout: Maximum execution time in seconds
            
        Returns:
            ExecutionResult with stdout, stderr, and any errors
        """
        self._ensure_kernel()
        return self._websocket.execute(code, timeout=timeout)
    
    def run_file(
        self,
        filepath: Union[str, Path],
        params: Dict[str, Any] = None,
        timeout: float = 60.0,
    ) -> ExecutionResult:
        """Execute a Python file on the remote kernel.
        
        Args:
            filepath: Path to the .py file to execute
            params: Optional parameters to inject as variables before execution
            timeout: Maximum execution time in seconds
            
        Returns:
            ExecutionResult with stdout, stderr, and any errors
            
        Example:
            >>> result = runner.run_file("train.py", params={"lr": 0.01, "epochs": 100})
        """
        filepath = Path(filepath)
        
        if not filepath.exists():
            raise FileNotFoundError(f"File not found: {filepath}")
        
        if not filepath.suffix == ".py":
            raise ValueError(f"Expected .py file, got: {filepath.suffix}")
        
        # Read file content
        code = filepath.read_text(encoding="utf-8")
        
        # Inject parameters if provided
        if params:
            param_code = self._generate_params_code(params)
            code = param_code + "\n" + code
        
        return self.run(code, timeout=timeout)
    
    def _generate_params_code(self, params: Dict[str, Any]) -> str:
        """Generate Python code to define parameters as variables.
        
        Args:
            params: Dictionary of parameter names and values
            
        Returns:
            Python code string that defines the parameters
        """
        lines = ["# Parameters injected by pyrun_jupyter"]
        for name, value in params.items():
            lines.append(f"{name} = {repr(value)}")
        return "\n".join(lines)

    def _iter_local_files(
        self,
        local_dir: Union[str, Path],
        pattern: str = "**/*",
        exclude_patterns: List[str] = None
    ) -> List[Tuple[Path, PurePosixPath]]:
        """Collect local files and their relative remote paths."""
        local_dir = Path(local_dir)
        if not local_dir.is_dir():
            raise ValueError(f"Not a directory: {local_dir}")

        exclude_patterns = exclude_patterns or self.DEFAULT_EXCLUDE_PATTERNS
        files: List[Tuple[Path, PurePosixPath]] = []

        for local_path in local_dir.glob(pattern):
            if not local_path.is_file():
                continue

            rel_path = local_path.relative_to(local_dir)
            if self._should_exclude(rel_path, exclude_patterns):
                continue

            files.append((local_path, PurePosixPath(rel_path.as_posix())))

        return files

    def _should_exclude(self, rel_path: Path, exclude_patterns: List[str]) -> bool:
        """Check whether a relative path should be excluded."""
        rel_posix = rel_path.as_posix()
        rel_parts = rel_path.parts

        for pattern in exclude_patterns:
            normalized = pattern.strip()
            if not normalized:
                continue

            if rel_path.match(normalized) or Path(rel_posix).match(normalized):
                return True

            for part in rel_parts:
                if Path(part).match(normalized):
                    return True

        return False

    def _join_remote_path(self, *parts: str) -> str:
        """Join remote path fragments using POSIX separators."""
        cleaned = [part.strip("/") for part in parts if part]
        if not cleaned:
            return ""
        return posixpath.join(*cleaned)

    def _normalize_entrypoint(
        self,
        project_dir: Union[str, Path],
        entrypoint: Union[str, Path]
    ) -> PurePosixPath:
        """Normalize the entrypoint to a path relative to the project root."""
        project_dir = Path(project_dir).resolve()
        entrypoint_path = Path(entrypoint)

        if entrypoint_path.is_absolute():
            resolved_entrypoint = entrypoint_path.resolve()
        else:
            resolved_entrypoint = (project_dir / entrypoint_path).resolve()

        try:
            relative = resolved_entrypoint.relative_to(project_dir)
        except ValueError as exc:
            raise ValueError(
                f"Entrypoint {resolved_entrypoint} must be inside project directory {project_dir}"
            ) from exc

        if not resolved_entrypoint.exists():
            raise FileNotFoundError(f"Entrypoint not found: {resolved_entrypoint}")
        if not resolved_entrypoint.is_file():
            raise ValueError(f"Entrypoint is not a file: {resolved_entrypoint}")
        if resolved_entrypoint.suffix != ".py":
            raise ValueError(f"Expected .py entrypoint, got: {resolved_entrypoint.suffix}")

        return PurePosixPath(relative.as_posix())

    def _prepare_remote_project_dir(self, remote_dir: str) -> None:
        """Remove and recreate the managed remote project directory."""
        result = self.run(f"""
import os
import shutil

project_root = globals().get("_PYRUN_JUPYTER_ROOT")
if project_root is None:
    project_root = os.getcwd()
    globals()["_PYRUN_JUPYTER_ROOT"] = project_root

remote_dir = {remote_dir!r}
if not os.path.isabs(remote_dir):
    remote_dir = os.path.abspath(os.path.join(project_root, remote_dir))

if os.path.exists(remote_dir):
    shutil.rmtree(remote_dir)
os.makedirs(remote_dir, exist_ok=True)
print("__REMOTE_DIR_READY__")
""")
        if "__REMOTE_DIR_READY__" not in result.stdout:
            raise KernelError(f"Failed to prepare remote directory: {remote_dir}")

    def _sync_project_via_kernel(
        self,
        project_dir: Union[str, Path],
        remote_dir: str,
        pattern: str = "**/*",
        exclude_patterns: List[str] = None
    ) -> List[str]:
        """Upload a local project directory into a clean remote directory."""
        project_dir = Path(project_dir)
        files = self._iter_local_files(project_dir, pattern=pattern, exclude_patterns=exclude_patterns)
        uploaded: List[str] = []

        for local_path, rel_remote in files:
            remote_path = self._join_remote_path(remote_dir, rel_remote.as_posix())
            if not self.upload_via_kernel(local_path, remote_path):
                raise KernelError(f"Failed to upload {local_path} to {remote_path}")
            uploaded.append(remote_path)

        return uploaded

    def _build_project_run_code(
        self,
        remote_dir: str,
        entrypoint: PurePosixPath,
        params: Optional[Dict[str, Any]] = None
    ) -> str:
        """Build Python code that runs an uploaded project entrypoint."""
        entrypoint_str = entrypoint.as_posix()
        return f"""
import json
import os
import runpy
import sys

project_dir = {remote_dir!r}
project_root = globals().get("_PYRUN_JUPYTER_ROOT")
if project_root is None:
    project_root = os.getcwd()
    globals()["_PYRUN_JUPYTER_ROOT"] = project_root

if not os.path.isabs(project_dir):
    project_dir = os.path.abspath(os.path.join(project_root, project_dir))

entrypoint = {entrypoint_str!r}
params = json.loads({json.dumps(params or {})!r})
entrypoint_path = os.path.join(project_dir, entrypoint)

if project_dir not in sys.path:
    sys.path.insert(0, project_dir)

os.chdir(project_dir)
globals().update(params)
runpy.run_path(entrypoint_path, run_name="__main__", init_globals=params)
"""

    def _resolve_kernel_artifacts(
        self,
        patterns: List[str],
        working_dir: str = ""
    ) -> List[str]:
        """Resolve explicit remote file paths or globs via kernel execution."""
        if not patterns:
            return []

        result = self.run(f"""
import glob
import json
import os

project_root = globals().get("_PYRUN_JUPYTER_ROOT")
if project_root is None:
    project_root = os.getcwd()
    globals()["_PYRUN_JUPYTER_ROOT"] = project_root

working_dir = {working_dir!r}
if working_dir and not os.path.isabs(working_dir):
    working_dir = os.path.abspath(os.path.join(project_root, working_dir))

patterns = {patterns!r}
matches = []
seen = set()

for pattern in patterns:
    if os.path.isabs(pattern):
        search_pattern = pattern
        base_dir = ""
    else:
        search_pattern = os.path.join(working_dir, pattern) if working_dir else pattern
        base_dir = working_dir

    resolved = sorted(glob.glob(search_pattern, recursive=True))
    if not resolved and os.path.exists(search_pattern):
        resolved = [search_pattern]

    for candidate in resolved:
        if not os.path.isfile(candidate):
            continue
        relative = os.path.relpath(candidate, base_dir) if base_dir else candidate
        relative = relative.replace("\\\\", "/")
        if relative not in seen:
            seen.add(relative)
            matches.append(relative)

print("__PYRUN_ARTIFACTS__")
print(json.dumps(matches))
""")

        marker = "__PYRUN_ARTIFACTS__"
        stdout = result.stdout.strip()
        if marker not in stdout:
            raise KernelError("Failed to resolve artifact paths on remote kernel")

        payload = stdout.split(marker, 1)[1].strip()
        try:
            resolved = json.loads(payload)
        except json.JSONDecodeError as exc:
            raise KernelError("Remote kernel returned invalid artifact metadata") from exc

        if not isinstance(resolved, list):
            raise KernelError("Remote kernel returned an invalid artifact list")

        return [str(path) for path in resolved]

    def run_project(
        self,
        project_dir: Union[str, Path],
        entrypoint: Union[str, Path],
        artifact_paths: Optional[List[str]] = None,
        local_artifact_dir: Union[str, Path] = "artifacts",
        remote_dir: Optional[str] = None,
        exclude_patterns: Optional[List[str]] = None,
        params: Optional[Dict[str, Any]] = None,
        timeout: float = 60.0,
    ) -> ExecutionResult:
        """Sync a project, run an entrypoint remotely, and download artifacts."""
        project_dir = Path(project_dir).resolve()
        if not project_dir.is_dir():
            raise ValueError(f"Not a directory: {project_dir}")

        relative_entrypoint = self._normalize_entrypoint(project_dir, entrypoint)
        remote_project_dir = remote_dir or self.DEFAULT_REMOTE_PROJECT_DIR

        self._prepare_remote_project_dir(remote_project_dir)
        self._sync_project_via_kernel(
            project_dir,
            remote_project_dir,
            exclude_patterns=exclude_patterns,
        )

        result = self.run(
            self._build_project_run_code(
                remote_project_dir,
                relative_entrypoint,
                params=params,
            ),
            timeout=timeout,
        )

        resolved_artifacts: List[str] = []
        if artifact_paths:
            resolved_artifacts = self._resolve_kernel_artifacts(
                artifact_paths,
                working_dir=remote_project_dir,
            )

        local_paths: List[Path] = []
        if resolved_artifacts:
            local_paths = self.download_kernel_files(
                resolved_artifacts,
                local_dir=local_artifact_dir,
                working_dir=remote_project_dir,
                flatten=False,
            )

        result.data.setdefault("artifacts", [str(path) for path in local_paths])
        return result

    # ==================== File Transfer Methods ====================
    
    def upload_file(
        self,
        local_path: Union[str, Path],
        remote_path: str,
        overwrite: bool = True
    ) -> Dict[str, Any]:
        """Upload a local file to the Jupyter server.
        
        Args:
            local_path: Path to local file to upload
            remote_path: Destination path on the server (e.g., "data/input.csv")
            overwrite: Whether to overwrite if file exists (default: True)
            
        Returns:
            Server response with file metadata
            
        Example:
            >>> runner.upload_file("local_data.csv", "input/data.csv")
            >>> runner.upload_file("model.py", "scripts/model.py")
        """
        return self._contents_manager.upload_file(str(local_path), remote_path, overwrite)
    
    def upload_directory(
        self,
        local_dir: Union[str, Path],
        remote_dir: str = "",
        pattern: str = "**/*",
        exclude_patterns: List[str] = None
    ) -> List[str]:
        """Upload a directory of files to the Jupyter server.
        
        Args:
            local_dir: Local directory path to upload
            remote_dir: Destination directory on server (empty for root)
            pattern: Glob pattern for files to include (default: all files)
            exclude_patterns: List of patterns to exclude (e.g., ["__pycache__", "*.pyc"])
            
        Returns:
            List of uploaded remote file paths
            
        Example:
            >>> runner.upload_directory("./my_project", "project")
            >>> runner.upload_directory("./src", "src", pattern="**/*.py")
            >>> runner.upload_directory("./data", "data", exclude_patterns=["*.tmp", "__pycache__"])
        """
        local_dir = Path(local_dir)
        exclude_patterns = exclude_patterns or self.DEFAULT_EXCLUDE_PATTERNS
        uploaded = []

        for local_path, rel_path in self._iter_local_files(
            local_dir,
            pattern=pattern,
            exclude_patterns=exclude_patterns,
        ):
            remote_path = self._join_remote_path(remote_dir, rel_path.as_posix())
            try:
                self.upload_file(local_path, remote_path)
                uploaded.append(remote_path)
            except Exception as e:
                print(f"Warning: Failed to upload {local_path}: {e}")
        
        return uploaded
    
    def download_file(
        self,
        remote_path: str,
        local_path: Union[str, Path]
    ) -> Path:
        """Download a file from the Jupyter server.
        
        Args:
            remote_path: Path on the server (e.g., "output/model.pt")
            local_path: Local destination path
            
        Returns:
            Path to downloaded file
            
        Example:
            >>> runner.download_file("output/trained_model.pt", "local/model.pt")
            >>> runner.download_file("results.csv", "./results.csv")
        """
        return self._contents_manager.download_file(remote_path, str(local_path))
    
    def download_files(
        self,
        remote_paths: List[str],
        local_dir: Union[str, Path],
        flatten: bool = False
    ) -> List[Path]:
        """Download multiple files from the Jupyter server.
        
        Args:
            remote_paths: List of paths on the server to download
            local_dir: Local directory to save files
            flatten: If True, save all files directly in local_dir without subdirs
            
        Returns:
            List of paths to downloaded files
            
        Example:
            >>> runner.download_files(
            ...     ["output/model.pt", "output/metrics.json"],
            ...     "./results"
            ... )
        """
        local_dir = Path(local_dir)
        local_dir.mkdir(parents=True, exist_ok=True)
        
        downloaded = []
        for remote_path in remote_paths:
            try:
                if flatten:
                    filename = Path(remote_path).name
                    local_path = local_dir / filename
                else:
                    local_path = local_dir / remote_path
                
                result = self.download_file(remote_path, local_path)
                downloaded.append(result)
            except Exception as e:
                print(f"Warning: Failed to download {remote_path}: {e}")
        
        return downloaded
    
    def download_kernel_files(
        self,
        remote_paths: List[str],
        local_dir: Union[str, Path],
        working_dir: str = "",
        flatten: bool = True,
    ) -> List[Path]:
        """Download files created by kernel execution (e.g., on Kaggle).
        
        Some Jupyter environments (like Kaggle) store kernel outputs in a different
        location than the Contents API. This method uses kernel execution to read
        and transfer files.
        
        Args:
            remote_paths: List of file paths relative to kernel working directory
            local_dir: Local directory to save files
            working_dir: Working directory on server (kernel's cwd)
            
        Returns:
            List of paths to downloaded files
            
        Example:
            >>> # After running training that created model.pth
            >>> runner.download_kernel_files(
            ...     ["model.pth", "predictions.png"],
            ...     "./results",
            ...     working_dir="my_project"
            ... )
        """
        import base64
        
        local_dir = Path(local_dir)
        local_dir.mkdir(parents=True, exist_ok=True)
        
        downloaded = []
        
        for filename in remote_paths:
            if working_dir:
                full_path = f"{working_dir}/{filename}"
            else:
                full_path = filename
            
            # Use kernel to read file and encode as base64
            result = self.run(f'''
import os
import base64

filepath = {repr(full_path)}
project_root = globals().get("_PYRUN_JUPYTER_ROOT")
if project_root is None:
    project_root = os.getcwd()
    globals()["_PYRUN_JUPYTER_ROOT"] = project_root

if not os.path.isabs(filepath):
    filepath = os.path.abspath(os.path.join(project_root, filepath))

if os.path.exists(filepath):
    with open(filepath, 'rb') as f:
        content = base64.b64encode(f.read()).decode('ascii')
    # Print in chunks to avoid output limits
    chunk_size = 50000
    for i in range(0, len(content), chunk_size):
        print(content[i:i+chunk_size], end='')
    print()  # Final newline
    print("__FILE_OK__")
else:
    print("__FILE_NOT_FOUND__")
''', timeout=120.0)
            
            output = result.stdout.strip()
            
            if "__FILE_NOT_FOUND__" in output:
                print(f"Warning: {filename} not found on server")
                continue
            
            if "__FILE_OK__" in output:
                # Extract base64 content (everything before __FILE_OK__)
                b64_content = output.replace("__FILE_OK__", "").strip()
                try:
                    file_bytes = base64.b64decode(b64_content)
                    local_path = local_dir / Path(filename).name if flatten else local_dir / Path(filename)
                    local_path.parent.mkdir(parents=True, exist_ok=True)
                    local_path.write_bytes(file_bytes)
                    downloaded.append(local_path)
                except Exception as e:
                    print(f"Warning: Failed to decode {filename}: {e}")
            else:
                print(f"Warning: Unexpected output for {filename}")
        
        return downloaded
    
    def upload_via_kernel(
        self,
        local_path: Union[str, Path],
        remote_path: str
    ) -> bool:
        """Upload a file via kernel execution (for environments like Kaggle).
        
        Some Jupyter environments don't allow direct file uploads via Contents API.
        This method transfers files by executing Python code in the kernel.
        
        Args:
            local_path: Path to local file to upload
            remote_path: Destination path on server (relative to kernel working dir)
            
        Returns:
            True if upload succeeded
            
        Example:
            >>> runner.upload_via_kernel("model.py", "project/model.py")
        """
        import base64
        
        local_path = Path(local_path)
        if not local_path.exists():
            raise FileNotFoundError(f"Local file not found: {local_path}")
        
        content_bytes = local_path.read_bytes()
        content_b64 = base64.b64encode(content_bytes).decode('ascii')
        
        # Create directory and write file
        remote_dir = str(Path(remote_path).parent)
        
        result = self.run(f'''
import os
import base64

remote_path = {repr(remote_path)}
project_root = globals().get("_PYRUN_JUPYTER_ROOT")
if project_root is None:
    project_root = os.getcwd()
    globals()["_PYRUN_JUPYTER_ROOT"] = project_root

if not os.path.isabs(remote_path):
    remote_path = os.path.abspath(os.path.join(project_root, remote_path))

remote_dir = os.path.dirname(remote_path)
if remote_dir:
    os.makedirs(remote_dir, exist_ok=True)

content = base64.b64decode({repr(content_b64)})
with open(remote_path, 'wb') as f:
    f.write(content)
print("__UPLOAD_OK__")
''')
        
        return "__UPLOAD_OK__" in result.stdout
    
    def upload_directory_via_kernel(
        self,
        local_dir: Union[str, Path],
        remote_dir: str = "",
        pattern: str = "**/*",
        exclude_patterns: List[str] = None
    ) -> List[str]:
        """Upload a directory via kernel execution (for environments like Kaggle).
        
        Args:
            local_dir: Local directory path to upload
            remote_dir: Destination directory on server
            pattern: Glob pattern for files to include (default: all files)
            exclude_patterns: List of patterns to exclude
            
        Returns:
            List of uploaded remote file paths
            
        Example:
            >>> runner.upload_directory_via_kernel("./my_project", "project")
        """
        local_dir = Path(local_dir)
        exclude_patterns = exclude_patterns or self.DEFAULT_EXCLUDE_PATTERNS
        uploaded = []

        for local_path, rel_path in self._iter_local_files(
            local_dir,
            pattern=pattern,
            exclude_patterns=exclude_patterns,
        ):
            remote_path = self._join_remote_path(remote_dir, rel_path.as_posix())
            try:
                if self.upload_via_kernel(local_path, remote_path):
                    uploaded.append(remote_path)
            except Exception as e:
                print(f"Warning: Failed to upload {local_path}: {e}")
        
        return uploaded
    
    def list_files(self, path: str = "") -> List[Dict[str, Any]]:
        """List files and directories on the server.
        
        Args:
            path: Directory path on server (empty for root)
            
        Returns:
            List of file/directory info dictionaries with name, path, type, size
            
        Example:
            >>> files = runner.list_files("output/")
            >>> for f in files:
            ...     print(f"{f['name']} ({f['type']})")
        """
        return self._contents_manager.list_contents(path)
    
    def delete_file(self, remote_path: str) -> None:
        """Delete a file on the server.
        
        Args:
            remote_path: Path to file on server
        """
        self._contents_manager.delete_file(remote_path)
    
    def file_exists(self, remote_path: str) -> bool:
        """Check if a file exists on the server.
        
        Args:
            remote_path: Path to check
            
        Returns:
            True if file exists, False otherwise
        """
        return self._contents_manager.file_exists(remote_path)
    
    # ==================== Context Manager ====================
    
    def __enter__(self) -> "JupyterRunner":
        """Context manager entry."""
        if self.auto_start_kernel and not self._kernel_id:
            self.start_kernel()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context manager exit - stop the kernel."""
        self.stop_kernel()
    
    def __repr__(self) -> str:
        status = "connected" if self.is_connected else "disconnected"
        return f"JupyterRunner(url='{self.url}', kernel_id={self._kernel_id}, status={status})"
