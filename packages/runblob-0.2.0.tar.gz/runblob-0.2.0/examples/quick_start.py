"""Quick start — минимальный пример генерации изображения."""
import asyncio
from runblob import RunBlob


async def main():
    # API ключ из переменной окружения RUNBLOB_API_KEY или напрямую
    async with RunBlob(api_key="sk-b50a0b80cae764189936a6f30639cb8345e254483b6b74a0fbe996c2f642be08") as client:

        # Генерация + ожидание результата в одном вызове
        result = await client.nanobanana.generate_and_wait(
            prompt="A cute orange cat sitting on a windowsill at sunset",
            model="standard",
        )

        if result.is_completed:
            print(f"Готово! URL: {result.result_image_url}")
        else:
            print(f"Ошибка: {result.message}")


if __name__ == "__main__":
    asyncio.run(main())
