"""Тест вебхука — отправляет генерацию с callback_url на ngrok."""
import asyncio
from runblob import RunBlob


CALLBACK_URL = "https://60b9-192-71-233-125.ngrok-free.app/webhook"


async def main():
    async with RunBlob(api_key="sk-b50a0b80cae764189936a6f30639cb8345e254483b6b74a0fbe996c2f642be08") as client:
        task = await client.nanobanana.generate(
            prompt="A cute orange cat on a windowsill",
            callback_url=CALLBACK_URL,
        )
        print(f"Task created: {task.task_uuid}")
        print(f"Status: {task.status}")
        print(f"Price: {task.price}")
        print(f"Callback URL: {CALLBACK_URL}")
        print(f"\nЖди webhook на сервере...")


if __name__ == "__main__":
    asyncio.run(main())
