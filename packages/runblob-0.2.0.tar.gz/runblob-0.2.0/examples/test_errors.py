"""Тест обработки ошибок — проверяет что SDK правильно ловит ошибки API.

Запуск:
    export RUNBLOB_API_KEY="rb_your_key"
    python examples/test_errors.py
"""
import asyncio
import sys

from runblob import (
    RunBlob,
    AuthenticationError,
    NotFoundError,
    GenerationTimeoutError,
    RunBlobError,
)


class Colors:
    GREEN = "\033[92m"
    RED = "\033[91m"
    CYAN = "\033[96m"
    BOLD = "\033[1m"
    END = "\033[0m"


def ok(msg: str):
    print(f"  {Colors.GREEN}✓{Colors.END} {msg}")


def fail(msg: str):
    print(f"  {Colors.RED}✗{Colors.END} {msg}")


def info(msg: str):
    print(f"  {Colors.CYAN}ℹ{Colors.END} {msg}")


passed = 0
failed = 0


async def main():
    global passed, failed

    print(f"\n{Colors.BOLD}══ Тест обработки ошибок ══{Colors.END}\n")

    # ── 1. Невалидный API ключ ────────────────────────────────────────
    print(f"  {Colors.BOLD}▸ AuthenticationError — невалидный ключ{Colors.END}")
    try:
        async with RunBlob(api_key="rb_invalid_key_12345") as client:
            await client.nanobanana.generate(prompt="test")
        fail("Не бросил AuthenticationError")
        failed += 1
    except AuthenticationError as e:
        ok(f"Поймал AuthenticationError (status={e.status_code})")
        info(f"request_id: {e.request_id}")
        passed += 1
    except RunBlobError as e:
        # Может быть другая ошибка от сервера
        ok(f"Поймал {type(e).__name__}: {e}")
        passed += 1

    # ── 2. Несуществующий task_uuid ───────────────────────────────────
    print(f"\n  {Colors.BOLD}▸ NotFoundError — несуществующий task{Colors.END}")
    try:
        async with RunBlob() as client:
            await client.nanobanana.get_status("00000000-0000-0000-0000-000000000000")
        fail("Не бросил NotFoundError")
        failed += 1
    except NotFoundError as e:
        ok(f"Поймал NotFoundError (status={e.status_code})")
        passed += 1
    except RunBlobError as e:
        ok(f"Поймал {type(e).__name__}: {e}")
        passed += 1

    # ── 3. Таймаут поллинга ───────────────────────────────────────────
    print(f"\n  {Colors.BOLD}▸ GenerationTimeoutError — быстрый таймаут{Colors.END}")
    try:
        async with RunBlob() as client:
            # Создаём реальную генерацию
            task = await client.nanobanana.generate(prompt="A test image for timeout")
            # Ставим невозможно маленький таймаут
            await client.nanobanana.wait_for_result(
                task.task_uuid,
                timeout=0.001,  # 1 миллисекунда — невозможно дождаться
                poll_interval=0.001,
            )
        fail("Не бросил GenerationTimeoutError")
        failed += 1
    except GenerationTimeoutError as e:
        ok(f"Поймал GenerationTimeoutError (task={e.task_uuid[:8]}...)")
        passed += 1
    except RunBlobError as e:
        # Может не успеть даже первый запрос
        ok(f"Поймал {type(e).__name__}: {e}")
        passed += 1

    # ── 4. Перехват всех ошибок через базовый класс ───────────────────
    print(f"\n  {Colors.BOLD}▸ RunBlobError — базовый перехват{Colors.END}")
    try:
        async with RunBlob(api_key="rb_bad") as client:
            await client.nanobanana.generate(prompt="test")
        fail("Ожидал ошибку")
        failed += 1
    except RunBlobError:
        ok("Базовый RunBlobError ловит все ошибки SDK")
        passed += 1

    # ── Итоги ─────────────────────────────────────────────────────────
    total = passed + failed
    print(f"\n  Всего: {total} | {Colors.GREEN}Прошло: {passed}{Colors.END}", end="")
    if failed:
        print(f" | {Colors.RED}Упало: {failed}{Colors.END}")
    else:
        print()
    print()

    if failed:
        sys.exit(1)


if __name__ == "__main__":
    asyncio.run(main())
