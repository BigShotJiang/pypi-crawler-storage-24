"""Shared test fixtures for RunBlob SDK tests."""
from __future__ import annotations

import pytest
import respx

from runblob import RunBlob


TEST_API_KEY = "rb_test_key_1234567890"
TEST_BASE_URL = "https://test.platform.runblob.io"

_PROXY_VARS = (
    "ALL_PROXY", "all_proxy", "HTTP_PROXY", "http_proxy",
    "HTTPS_PROXY", "https_proxy", "FTP_PROXY", "ftp_proxy",
    "GRPC_PROXY", "grpc_proxy",
)


@pytest.fixture(autouse=True)
def _no_proxy(monkeypatch):
    """Strip proxy env vars so httpx doesn't try SOCKS in sandbox."""
    for var in _PROXY_VARS:
        monkeypatch.delenv(var, raising=False)


@pytest.fixture
def api_key() -> str:
    return TEST_API_KEY


@pytest.fixture
async def client(api_key: str):
    async with RunBlob(
        api_key=api_key,
        base_url=TEST_BASE_URL,
        max_retries=0,
        rate_limit_rps=1000.0,
        circuit_breaker_threshold=100,
    ) as c:
        yield c


@pytest.fixture
def mock_api():
    with respx.mock(base_url=TEST_BASE_URL) as mock:
        yield mock
