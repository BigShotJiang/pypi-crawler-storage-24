"""askfind — Natural language file finder for the terminal."""

__version__ = "0.1.21"

__all__ = ["__version__"]
