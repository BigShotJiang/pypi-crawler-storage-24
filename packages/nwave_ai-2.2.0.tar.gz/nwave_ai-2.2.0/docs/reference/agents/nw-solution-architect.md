# nw-solution-architect

Use for DESIGN wave - collaborates with user to define system architecture, component boundaries, technology selection, and creates architecture documents with business value focus. Hands off to acceptance-designer.

**Wave:** DESIGN
**Model:** inherit
**Max turns:** 50
**Tools:** Read, Write, Edit, Glob, Grep, Task

## Commands

- [`/nw:deliver`](../commands/index.md)
- [`/nw:design`](../commands/index.md)
- [`/nw:diagram`](../commands/index.md)
- [`/nw:discuss`](../commands/index.md)
- [`/nw:finalize`](../commands/index.md)
- [`/nw:review`](../commands/index.md)
- [`/nw:roadmap`](../commands/index.md)

## Skills

- [architectural-styles-tradeoffs](../../../nWave/skills/solution-architect/architectural-styles-tradeoffs.md) — Architectural style selection decision matrices, trade-off analysis, structural enforcement rules, and combination patterns. Load when choosing or evaluating architecture styles.
- [architecture-patterns](../../../nWave/skills/solution-architect/architecture-patterns.md) — Comprehensive architecture patterns, methodologies, quality frameworks, and evaluation methods for solution architects. Load when designing system architecture or selecting patterns.
- [critique-dimensions](../../../nWave/skills/acceptance-designer/critique-dimensions.md) — Review dimensions for acceptance test quality - happy path bias, GWT compliance, business language purity, coverage completeness, walking skeleton user-centricity, and priority validation
- [critique-dimensions](../../../nWave/skills/agent-builder/critique-dimensions.md) — Review dimensions for validating agent quality - template compliance, safety, testing, and priority validation
- [critique-dimensions](../../../nWave/skills/agent-builder-reviewer/critique-dimensions.md) — Review dimensions for validating agent quality - template compliance, safety, testing, and priority validation
- [critique-dimensions](../../../nWave/skills/platform-architect-reviewer/critique-dimensions.md) — Platform design review critique dimensions and severity levels. Load when reviewing CI/CD pipelines, infrastructure, deployment strategies, observability, or security designs.
- [critique-dimensions](../../../nWave/skills/researcher-reviewer/critique-dimensions.md) — Critique dimensions and scoring for research document reviews
- [critique-dimensions](../../../nWave/skills/solution-architect/critique-dimensions.md) — Architecture quality critique dimensions for peer review. Load when invoking solution-architect-reviewer or performing self-review of architecture documents.
- [critique-dimensions](../../../nWave/skills/solution-architect-reviewer/critique-dimensions.md) — Architecture quality critique dimensions for peer review. Load when performing architecture document reviews.
- [domain-driven-design](../../../nWave/skills/solution-architect/domain-driven-design.md) — Strategic and tactical DDD patterns, bounded context discovery, context mapping, aggregate design rules, and decision frameworks for when to apply DDD
- [formal-verification-tlaplus](../../../nWave/skills/solution-architect/formal-verification-tlaplus.md) — TLA+ and PlusCal for specifying distributed system invariants. Decision heuristics for when formal verification adds value, key patterns, state explosion management, and alternatives comparison.
- [security-by-design](../../../nWave/skills/solution-architect/security-by-design.md) — Security design principles, STRIDE threat modeling, OWASP Top 10 architectural mitigations, and secure patterns. Load when designing systems or reviewing architecture for security.
- [stress-analysis](../../../nWave/skills/solution-architect/stress-analysis.md) — Advanced architecture stress analysis methodology for designing systems that survive unknown stresses. Load when --residuality flag is used or when designing high-uncertainty, mission-critical systems.
