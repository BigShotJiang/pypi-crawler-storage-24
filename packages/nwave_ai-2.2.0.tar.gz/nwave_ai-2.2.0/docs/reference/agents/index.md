# Agents

## DESIGN

| Name | Description | Skills |
| --- | --- | --- |
| [nw-platform-architect](nw-platform-architect.md) | Use for DESIGN wave (infrastructure design) and DEVOPS wave (deployment execution, production readiness, stakeholder sign-off). Transforms architecture into deployable infrastructure, then coordinates production delivery and outcome measurement. | 7 |
| [nw-platform-architect-reviewer](nw-platform-architect-reviewer.md) | Use for review and critique tasks - Platform design, CI/CD pipeline, infrastructure, observability, deployment readiness, and production handoff review specialist. Runs on Haiku for cost efficiency. | 14 |
| [nw-product-owner-reviewer](nw-product-owner-reviewer.md) | Use as hard gate before DESIGN wave - validates journey coherence, emotional arc quality, shared artifact tracking, Definition of Ready checklist, LeanUX antipatterns, and story sizing. Blocks handoff if any critical issue or DoR item fails. Runs on Haiku for cost efficiency. | 9 |
| [nw-solution-architect](nw-solution-architect.md) | Use for DESIGN wave - collaborates with user to define system architecture, component boundaries, technology selection, and creates architecture documents with business value focus. Hands off to acceptance-designer. | 13 |
| [nw-solution-architect-reviewer](nw-solution-architect-reviewer.md) | Architecture design and patterns review specialist - Optimized for cost-efficient review operations using Haiku model. | 8 |

## DISTILL

| Name | Description | Skills |
| --- | --- | --- |
| [nw-acceptance-designer](nw-acceptance-designer.md) | Use for DISTILL wave - designs E2E acceptance tests from user stories and architecture using Given-When-Then format. Creates executable specifications that drive Outside-In TDD development. | 10 |
| [nw-acceptance-designer-reviewer](nw-acceptance-designer-reviewer.md) | Use for review and critique tasks - Acceptance criteria and BDD review specialist. Runs on Haiku for cost efficiency. | 9 |

## DELIVER

| Name | Description | Skills |
| --- | --- | --- |
| [nw-functional-software-crafter](nw-functional-software-crafter.md) | DELIVER wave - Outside-In TDD with functional paradigm. Pure functions, pipeline composition, types as documentation, property-based testing. Use when the project follows a functional-first approach (F#, Haskell, Scala, Clojure, Elixir, or FP-heavy TypeScript/Python/Kotlin). | 31 |
| [nw-software-crafter](nw-software-crafter.md) | DELIVER wave - Outside-In TDD and progressive refactoring. Research-optimized core (~375L) with Skills for deep knowledge. Includes Mikado Method for complex refactoring. | 12 |
| [nw-software-crafter-reviewer](nw-software-crafter-reviewer.md) | Use for review and critique tasks - Code quality and implementation review specialist. Runs on Haiku for cost efficiency. | 4 |

## Other

| Name | Description | Skills |
| --- | --- | --- |
| [nw-agent-builder](nw-agent-builder.md) | Use when creating new AI agents, validating agent specifications, optimizing command definitions, or ensuring compliance with Claude Code best practices. Creates focused, research-validated agents (200-400 lines) with Skills for domain knowledge. Also optimizes bloated command files into lean declarative definitions. | 12 |
| [nw-agent-builder-reviewer](nw-agent-builder-reviewer.md) | Use for review and critique tasks - Agent design and quality review specialist. Runs on Haiku for cost efficiency. | 8 |
| [nw-data-engineer](nw-data-engineer.md) | Use for database technology selection, data architecture design, query optimization, schema design, security implementation, and governance guidance. Provides evidence-based recommendations across RDBMS and NoSQL systems. | 4 |
| [nw-data-engineer-reviewer](nw-data-engineer-reviewer.md) | Use for review and critique tasks - Data architecture and pipeline review specialist. Runs on Haiku for cost efficiency. | 6 |
| [nw-documentarist](nw-documentarist.md) | Use for documentation quality enforcement using DIVIO/Diataxis principles. Classifies documentation type, validates against type-specific criteria, detects collapse patterns, and provides actionable improvement guidance. | 3 |
| [nw-documentarist-reviewer](nw-documentarist-reviewer.md) | Use for reviewing documentarist assessments. Validates classification accuracy, validation completeness, collapse detection, and recommendation quality using Haiku model. | 7 |
| [nw-product-discoverer](nw-product-discoverer.md) | Conducts evidence-based product discovery through customer interviews, assumption testing, and opportunity validation. Use when validating problems exist, prioritizing opportunities, or confirming market viability before writing requirements. | 3 |
| [nw-product-discoverer-reviewer](nw-product-discoverer-reviewer.md) | Use as peer reviewer for product-discoverer outputs -- validates evidence quality, sample sizes, decision gate compliance, bias detection, and discovery anti-patterns. Runs on Haiku for cost efficiency. | 6 |
| [nw-product-owner](nw-product-owner.md) | Conducts UX journey design and requirements gathering with BDD acceptance criteria. Use when defining user stories, emotional arcs, or enforcing Definition of Ready. | 20 |
| [nw-researcher](nw-researcher.md) | Use for evidence-driven research with source verification. Gathers knowledge from web and files, cross-references across multiple sources, and produces cited research documents. | 4 |
| [nw-researcher-reviewer](nw-researcher-reviewer.md) | Use for review and critique tasks - Research quality and evidence review specialist. Runs on Haiku for cost efficiency. | 7 |
| [nw-troubleshooter](nw-troubleshooter.md) | Use for investigating system failures, recurring issues, unexpected behaviors, or complex bugs requiring systematic root cause analysis with evidence-based investigation. | 3 |
| [nw-troubleshooter-reviewer](nw-troubleshooter-reviewer.md) | Use for review and critique tasks - Risk analysis and failure mode review specialist. Runs on Haiku for cost efficiency. | 6 |

## All Agents

| Name | Wave | Description | Skills |
| --- | --- | --- | --- |
| [nw-acceptance-designer](nw-acceptance-designer.md) | DISTILL | Use for DISTILL wave - designs E2E acceptance tests from user stories and architecture using Given-When-Then format. Creates executable specifications that drive Outside-In TDD development. | 10 |
| [nw-acceptance-designer-reviewer](nw-acceptance-designer-reviewer.md) | DISTILL | Use for review and critique tasks - Acceptance criteria and BDD review specialist. Runs on Haiku for cost efficiency. | 9 |
| [nw-agent-builder](nw-agent-builder.md) | Other | Use when creating new AI agents, validating agent specifications, optimizing command definitions, or ensuring compliance with Claude Code best practices. Creates focused, research-validated agents (200-400 lines) with Skills for domain knowledge. Also optimizes bloated command files into lean declarative definitions. | 12 |
| [nw-agent-builder-reviewer](nw-agent-builder-reviewer.md) | Other | Use for review and critique tasks - Agent design and quality review specialist. Runs on Haiku for cost efficiency. | 8 |
| [nw-data-engineer](nw-data-engineer.md) | Other | Use for database technology selection, data architecture design, query optimization, schema design, security implementation, and governance guidance. Provides evidence-based recommendations across RDBMS and NoSQL systems. | 4 |
| [nw-data-engineer-reviewer](nw-data-engineer-reviewer.md) | Other | Use for review and critique tasks - Data architecture and pipeline review specialist. Runs on Haiku for cost efficiency. | 6 |
| [nw-documentarist](nw-documentarist.md) | Other | Use for documentation quality enforcement using DIVIO/Diataxis principles. Classifies documentation type, validates against type-specific criteria, detects collapse patterns, and provides actionable improvement guidance. | 3 |
| [nw-documentarist-reviewer](nw-documentarist-reviewer.md) | Other | Use for reviewing documentarist assessments. Validates classification accuracy, validation completeness, collapse detection, and recommendation quality using Haiku model. | 7 |
| [nw-functional-software-crafter](nw-functional-software-crafter.md) | DELIVER | DELIVER wave - Outside-In TDD with functional paradigm. Pure functions, pipeline composition, types as documentation, property-based testing. Use when the project follows a functional-first approach (F#, Haskell, Scala, Clojure, Elixir, or FP-heavy TypeScript/Python/Kotlin). | 31 |
| [nw-platform-architect](nw-platform-architect.md) | DESIGN | Use for DESIGN wave (infrastructure design) and DEVOPS wave (deployment execution, production readiness, stakeholder sign-off). Transforms architecture into deployable infrastructure, then coordinates production delivery and outcome measurement. | 7 |
| [nw-platform-architect-reviewer](nw-platform-architect-reviewer.md) | DESIGN | Use for review and critique tasks - Platform design, CI/CD pipeline, infrastructure, observability, deployment readiness, and production handoff review specialist. Runs on Haiku for cost efficiency. | 14 |
| [nw-product-discoverer](nw-product-discoverer.md) | Other | Conducts evidence-based product discovery through customer interviews, assumption testing, and opportunity validation. Use when validating problems exist, prioritizing opportunities, or confirming market viability before writing requirements. | 3 |
| [nw-product-discoverer-reviewer](nw-product-discoverer-reviewer.md) | Other | Use as peer reviewer for product-discoverer outputs -- validates evidence quality, sample sizes, decision gate compliance, bias detection, and discovery anti-patterns. Runs on Haiku for cost efficiency. | 6 |
| [nw-product-owner](nw-product-owner.md) | Other | Conducts UX journey design and requirements gathering with BDD acceptance criteria. Use when defining user stories, emotional arcs, or enforcing Definition of Ready. | 20 |
| [nw-product-owner-reviewer](nw-product-owner-reviewer.md) | DESIGN | Use as hard gate before DESIGN wave - validates journey coherence, emotional arc quality, shared artifact tracking, Definition of Ready checklist, LeanUX antipatterns, and story sizing. Blocks handoff if any critical issue or DoR item fails. Runs on Haiku for cost efficiency. | 9 |
| [nw-researcher](nw-researcher.md) | Other | Use for evidence-driven research with source verification. Gathers knowledge from web and files, cross-references across multiple sources, and produces cited research documents. | 4 |
| [nw-researcher-reviewer](nw-researcher-reviewer.md) | Other | Use for review and critique tasks - Research quality and evidence review specialist. Runs on Haiku for cost efficiency. | 7 |
| [nw-software-crafter](nw-software-crafter.md) | DELIVER | DELIVER wave - Outside-In TDD and progressive refactoring. Research-optimized core (~375L) with Skills for deep knowledge. Includes Mikado Method for complex refactoring. | 12 |
| [nw-software-crafter-reviewer](nw-software-crafter-reviewer.md) | DELIVER | Use for review and critique tasks - Code quality and implementation review specialist. Runs on Haiku for cost efficiency. | 4 |
| [nw-solution-architect](nw-solution-architect.md) | DESIGN | Use for DESIGN wave - collaborates with user to define system architecture, component boundaries, technology selection, and creates architecture documents with business value focus. Hands off to acceptance-designer. | 13 |
| [nw-solution-architect-reviewer](nw-solution-architect-reviewer.md) | DESIGN | Architecture design and patterns review specialist - Optimized for cost-efficient review operations using Haiku model. | 8 |
| [nw-troubleshooter](nw-troubleshooter.md) | Other | Use for investigating system failures, recurring issues, unexpected behaviors, or complex bugs requiring systematic root cause analysis with evidence-based investigation. | 3 |
| [nw-troubleshooter-reviewer](nw-troubleshooter-reviewer.md) | Other | Use for review and critique tasks - Risk analysis and failure mode review specialist. Runs on Haiku for cost efficiency. | 6 |
