# ppapp/R - piecewise polynomial approximation of real functions

Code generator for piecewise Chebyshev approximation of smooth real-valued functions.

## Overview

This package generates C source code containing polynomial coefficients that approximate
a given function f(x) over a specified domain. The approximation uses piecewise Chebyshev
polynomials with octave-based domain subdivision for optimal accuracy.

**Reference:** Joachim Wuttke and Alexander Kleinsorge,
"Algorithm 1XXX: Code generation for piecewise Chebyshev approximation"

**Documentation:** [userManual.pdf](https://jugit.fz-juelich.de/mlz/ppapp/-/blob/main/R/userManual/userManual.pdf)
