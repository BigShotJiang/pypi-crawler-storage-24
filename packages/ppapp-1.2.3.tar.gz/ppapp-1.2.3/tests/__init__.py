"""Tests for ppapp package."""
