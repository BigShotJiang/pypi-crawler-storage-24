#!/usr/bin/env python3

"""
Code generating code for piecewise Chebyshev approximation

Reference: Joachim Wuttke and Alexander Kleinsorge,
           Algorithm 1XXX: Code generation for piecewise Chebyshev approximation

File:      ppapp/ppapp.py

Main program that prints polynomial coefficients in different formats.
These coefficients pertain to a piecewise Chebyshev approximation of a function f.
A high-precision reference implementation of function f must be provided in reference_f.py.

Usage of the generated file is demonstrated in directory src/dem.

License:   GNU General Public License, version 3 or higher (see src/LICENSE)
Copyright: Forschungszentrum Jülich GmbH 2025
Author:    Joachim Wuttke <j.wuttke@fz-juelich.de>
"""

import os
import sys
from dataclasses import dataclass, field
from math import frexp, isfinite, log
from sys import argv, stderr
from time import ctime, localtime, strftime, time

# Import high-precision Chebyshev coefficient computation
try:
    from ppapp.cheb_coeffs import ArbF, cheb_cn, cheb_pm, check_coeffs, ref_f
except ModuleNotFoundError:
    # Determine which module was invoked
    main_script = os.path.basename(sys.argv[0])
    if main_script in ("ppapp.py", "__main__.py", "ppapp"):
        module_hint = "ppapp"
    else:
        module_hint = f"ppapp.{main_script.removesuffix('.py')}"
    print("Error: Cannot import ppapp.cheb_coeffs.", file=sys.stderr)
    print("", file=sys.stderr)
    print("Run from the directory containing the 'ppapp' package:", file=sys.stderr)
    print("  cd /path/to/ppapp/R", file=sys.stderr)
    print(f"  python -m {module_hint} <args>", file=sys.stderr)
    print("", file=sys.stderr)
    print("Or install ppapp via pip.", file=sys.stderr)
    sys.exit(1)


EPS = 2.0 ** -53 # Machine epsilon for IEEE 754 double precision

@dataclass
class Subdomain:
    """
    Represents a subdomain for piecewise approximation.
    """
    j: int = 0          # octave index
    i: int = 0          # subdomain index within octave
    a: float = 0.0      # lower bound
    b: float = 0.0      # upper bound
    coeffs: list[float] = field(default_factory=list)  # polynomial coefficients
    s: float = 0.0      # power law parameter
    r: float = 0.0      # power law parameter

####################################################################################################
# Computational functions
####################################################################################################

def analyse_row(coeffs: list[float]) -> tuple[float, float]:
    """
    Returns parameters s,r of power law h(n)=s*r^n that approximates |coeffs[n]|
    while |coeffs[n]| <= h(n).

    Solution is by brute force, considering all power laws that touch a pair of data points.

    Args:
        coeffs: List of polynomial coefficients

    Returns:
        Tuple (s, r) where s*r^n bounds the coefficient magnitudes
    """
    assert len(coeffs) >= 2

    # Take absolute values
    y = [abs(v) for v in coeffs]
    N = len(y) - 1

    # Power-law model: h(n) = s * r^n
    def make_model(y_vals, i, j):
        """
        Create power law model that passes through y[i] and y[j].
        """
        assert 0 <= i < j < len(y_vals)
        assert y_vals[i] > 0
        r = (y_vals[j] / y_vals[i]) ** (1.0 / (j - i))
        s = y_vals[i] * (r ** -i)
        return s, r

    def model_f(s, r, i):
        """
        Evaluate model at index i.
        """
        return s * (r ** i)

    def least_squares(s, r, y_vals):
        """
        Compute sum of squared log deviations.
        """
        result = 0.0
        for k in range(len(y_vals)):
            assert y_vals[k] > 0
            result += log(y_vals[k] / model_f(s, r, k)) ** 2
        return result

    # Initial solution: endpoints
    solution_s, solution_r = make_model(y, 0, N)
    squares = float('inf')

    for i in range(N - 1):
        for j in range(i + 1, N):
            s, r = make_model(y, i, j)

            # Check that this model bounds all data points
            valid = True
            for k in range(N):
                if y[k] > model_f(s, r, k) * (1 + 1e-13):
                    valid = False
                    break

            if not valid:
                continue

            sq = least_squares(s, r, y)
            if sq < squares:
                squares = sq
                solution_s, solution_r = s, r

    if not isfinite(squares):
        for i in range(N - 1):
            print(f"y[{i}] = {coeffs[i]}")
        raise RuntimeError("fit failed: squares=infty")

    return solution_s, solution_r


def extrapolate_power_law(coeffs: list[float], s: float, r: float, N: int) -> float:
    """
    Returns maximum relative error, computed from coefficients and power-law parameters.
    Implements Eq (46) of Wuttke and Kleinsorge, "Code generation for piecewise Chebyshev approximation".

    Args:
        coeffs: Polynomial coefficients
        s: Power law parameter s
        r: Power law parameter r
        N: Polynomial degree

    Returns:
        Error bound in units of machine epsilon
    """
    assert len(coeffs) > N

    p0 = coeffs[0]
    denom = p0 - s * (r ** (N + 1)) / (1 - r)

    re = 2 * p0
    for n in range(1, N + 1):
        denom -= abs(coeffs[n])
        re += (3 + n) * abs(coeffs[n])

    te = s * (r ** (N + 1)) / (1 - r) / EPS

    assert denom > 0, f"denom={denom} must be positive"
    return (re + te) / denom


def compute_subdomains(a: float, b: float, M: int) -> tuple[int, int, list[Subdomain]]:
    """
    Divide the interval [a, b] into 2^M subdomains per octave.

    Args:
        a: Lower bound of domain
        b: Upper bound of domain
        M: Number of subdivisions per octave (2^M subdomains per octave)

    Returns:
        Tuple (j0, l0, D) where:
        - j0 is the exponent for frexp(a) (first octave starts at 2^(j0-1))
        - l0 is the starting subdomain index in first octave
        - D is the list of Subdomain objects
    """
    assert a < b, "Lower bound must be less than upper bound"
    assert M >= 0, "M must be non-negative"

    ni = 1 << M  # 2^M subdomains per octave

    # Use frexp to get exponents.
    # frexp returns (mantissa, exponent) where a = mantissa * 2^exponent
    # and mantissa is in [0.5, 1.0)
    _, ea = frexp(a)
    _, eb = frexp(b)

    D = []
    result_l0 = -1

    for j in range(ea - 1, eb):
        for i in range(ni):
            asu = (ni + i) * (2.0 ** (j - M))
            bsu = asu + (2.0 ** (j - M))
            if bsu > a and asu < b:
                # Store j relative to ea
                d = Subdomain(j - ea + 1, i, asu, bsu)
                D.append(d)
                if result_l0 == -1:
                    result_l0 = i

    return ea, result_l0, D


def estimate_error_bound(d: Subdomain, coeffs: list[float], N: int) -> float:
    """
    Estimate error bound for given polynomial coefficients.

    Here we assume that the approximated function is not a finite-order polynomial.
    In this case, the power-law fit will ilekly fail.
    """
    # Analyze power law
    s, r = analyse_row(coeffs)

    # Extrapolate power law to compute error bound
    err = extrapolate_power_law(coeffs, s, r, N)

    return err


def compute_coeffs(d: Subdomain, N: int, economized: bool, arb_f: ArbF):
    """
    Compute coefficients for one subdomain.

    Args:
        d: Subdomain object
        N: Polynomial degree
        economized: If True, compute economized coefficients; else Chebyshev coefficients
        arb_f: Arbitrary-precision reference function

    Returns:
        List of coefficients
    """
    # Compute coefficients
    if economized:
        coeffs = cheb_pm(d.a, d.b, N, arb_f)
    else:
        coeffs = cheb_cn(d.a, d.b, N, arb_f)

    assert len(coeffs) == N + 1

    return coeffs


def find_nmin(d: Subdomain, Nmax: int, relerr: float, arb_f: ArbF):
    """
    Find minimal N for one subdomain.

    Args:
        d: Subdomain object
        Nmax: Maximum polynomial degree to try
        relerr: Target relative error
        arb_f: Arbitrary-precision reference function

    Returns:
        Nmin for this subdomain (0 if not found)
    """
    for n in range(2, Nmax + 1):
        try:
            coeffs = cheb_pm(d.a, d.b, n, arb_f)
            assert len(coeffs) == n + 1

            error = estimate_error_bound(d, coeffs, n)

            if error <= relerr:
                return n
        except Exception:
            # Continue trying higher N values
            pass

    return 0  # Not found within Nmax


def compute_histogram_chunk(D: list[Subdomain], a: float, b: float, n_chunk: int,
                           seed: int, bin_width: float, num_bins: int, arb_f: ArbF):
    """
    Compute histogram for a chunk of random points.

    Args:
        D: List of subdomains
        a: Domain lower bound
        b: Domain upper bound
        n_chunk: Number of points to process
        seed: Random seed
        bin_width: Histogram bin width
        num_bins: Number of histogram bins

    Returns:
        List of histogram bin counts
    """
    import random

    from flint import arb, ctx

    prec = 200
    ctx.prec = prec

    # Use deterministic seed for this chunk
    random.seed(seed)

    # Local histogram for this chunk
    histogram = [0] * num_bins

    for _ in range(n_chunk):
        # Uniform random x in [a, b]
        x = random.uniform(a, b)

        # Find which subdomain contains x
        d = None
        for subdomain in D:
            if subdomain.a <= x < subdomain.b:
                d = subdomain
                break

        # Handle edge case where x equals b
        if d is None and abs(x - b) < EPS * b:
            d = D[-1]

        if d is None:
            raise ValueError(f"Point x={x} not in any subdomain")

        # Transform x to [-1, 1] for this subdomain
        mid = (d.a + d.b) / 2
        half = (d.b - d.a) / 2
        t = (x - mid) / half

        # Compute f_ref in high precision
        X = arb(x)
        F_ref = arb_f(X, prec)

        # Compute f_poly in double precision
        f_poly_double = d.coeffs[-1]
        for c in reversed(d.coeffs[:-1]):
            f_poly_double = f_poly_double * t + c

        # Convert to high precision for accurate difference
        F_poly = arb(f_poly_double)

        # Compute absolute relative deviation in units of epsilon
        rel_dev = abs((F_poly - F_ref) / F_ref / arb(EPS))
        deviation = float(rel_dev.mid())

        # Bin the deviation
        bin_index = int(deviation / bin_width)
        if bin_index < num_bins:
            histogram[bin_index] += 1
        else:
            raise RuntimeError(f"Deviation {deviation} exceeds histogram range")

    return histogram

####################################################################################################
# Startup and help functions
####################################################################################################

def load_function_module(module_path):
    """
    Dynamically load a function definition file.

    Args:
        module_path: File path (e.g., 'f_imwofx.py' or 'path/to/f_custom.py')

    Returns:
        The loaded module object
    """
    import importlib.util

    if not module_path.endswith('.py'):
        module_path = module_path + '.py'

    if not os.path.isabs(module_path):
        module_path = os.path.abspath(module_path)

    if not os.path.exists(module_path):
        print(f"Error: Function definition file not found: {module_path}", file=stderr)
        exit(1)

    module_name = os.path.splitext(os.path.basename(module_path))[0]

    # Ensure the module's directory is on sys.path so that multiprocessing
    # workers (forkserver/spawn) can import the module by name when unpickling.
    module_dir = os.path.dirname(module_path)
    if module_dir not in sys.path:
        sys.path.insert(0, module_dir)

    spec = importlib.util.spec_from_file_location(module_name, module_path)
    if spec is None or spec.loader is None:
        print(f"Error: Cannot load module from: {module_path}", file=stderr)
        exit(1)

    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    spec.loader.exec_module(module)

    # Validate that required attributes exist
    if not hasattr(module, 'my_arb_f'):
        print(f"Error: Module {module_name} does not define 'my_arb_f'", file=stderr)
        exit(1)
    if not hasattr(module, 'my_domain'):
        print(f"Error: Module {module_name} does not define 'my_domain'", file=stderr)
        exit(1)
    if not hasattr(module, 'my_testcases'):
        print(f"Error: Module {module_name} does not define 'my_testcases'", file=stderr)
        exit(1)

    return module


def help_and_exit():
    """
    Prints help and terminates program.
    """
    print("Usage:\n")
    print("ppapp i <f_module>                     - run initial tests from my_testcases")
    print("ppapp v <f_module> <x>                 - print function value f(x)")
    print("ppapp n <f_module> <M> <Nmax> <E>      - print N_min(M',E), up to given Nmax")
    print("ppapp e <f_module> <M> <N>             - print maximum relative error, in units of epsilon")
    print("ppapp c <f_module> <M> <N> [<E>]       - print plain table of Chebyshev coefficients c_n")
    print("ppapp p <f_module> <M> <N> [<E>]       - print plain table of economized coefficients p_m")
    print("ppapp s <f_module> <M> <N> [<E>]       - print C source defining economized coefficients p_m")
    print("ppapp t <f_module> <M> <E>             - print C source defining test cases")
    print("ppapp t <f_module> <M> <Nxo> <E> <E> <E> - ditto, with extra octaves below and above")
    print("ppapp r <f_module> <M> <N> <n>         - print deviation in units of epsilon, for <n> points")
    print("ppapp H <f_module> <M> <N> <n>         - print deviation histogram, for <n> random points")
    print("\nwhere\n")
    print("<f_module> - path to function definition file (e.g., 'mydir/f_imwofx.py')")
    print("<M>        - integer M >= 0 specifies 2^M subdomains per octave")
    print("<N>        - integer N >= 1 is the polynomial degree")
    print("<E>        - double E > 0 is the maximum relative error, in units of epsilon=2^-53")
    print("<Nxo>      - number of extra (non-Chebyshev) octaves on each side of the Chebyshev range")
    print("               (if Nxo>0 then provide max rel err below, inside, above Chebyshev range")
    print("<n>        - integer n >= 1 is the total number of test points")

    # Print installation info
    from importlib.metadata import version
    package_dir = os.path.dirname(os.path.abspath(__file__))
    is_installed = "site-packages" in package_dir

    print("\nInstallation info:")
    print(f"- Invoked via:       {sys.argv[0]}")
    if is_installed:
        print(f"- Running from:      installed package, version {version('ppapp')}")
    else:
        print("- Running from:      source")
    print(f"- Package directory: {package_dir}, with subdirectories:")
    print("  - docs/            user manual (PDF)")
    print("  - demo_functions/  example high-precision function definitions")

    exit(1)


####################################################################################################
# Output functions
####################################################################################################

def hexfloat(x: float) -> str:
    """
    Returns hexadecimal floating-point representation of x.
    Result looks like -0x1.8....p-27.
    This is in decimal notation -1.5.... * 2^(-27).
    Note that binary exponent (following 'p') is rendered as a decimal number.
    """
    if x >= 0:
        return x.hex()
    else:
        # Python's hex() already handles negative numbers, but we want consistent format
        return "-" + (-x).hex()


def n_output_coeffs(N: int) -> int:
    """
    Returns number of polynomial coefficients per subdomain that are written to the C tables.
    For given polynomial degree N, this is normally N+1.
    However, for alignment reasons as described in Sect 2.3 of the reference paper,
    for certain N we fill up with zeroes.
    """
    assert N >= 0
    remainder = (N + 1) % 8
    if remainder in (0, 1, 2, 4):
        return N + 1
    elif remainder == 3:
        return N + 2  # fill up to 4
    else:
        return ((N + 1) // 8 + 1) * 8  # fill up to 8


def print_table(start_time: float, economized: bool, a: float, b: float, M: int, N: int,
                j0: int, l0: int, D: list[Subdomain]) -> None:
    """
    Print plain table of coefficients.

    Args:
        start_time: Time when program started
        economized: If True, print economized coefficients p_m, else Chebyshev coefficients c_n
        a: Lower domain bound
        b: Upper domain bound
        M: Subdivision parameter
        N: Polynomial degree
        j0: Starting octave index
        l0: Number of octaves
        D: List of subdomains
    """
    # Print header comment
    coeff_type = "p_m" if economized else "c_n"
    print(f"# Table of {'economized' if economized else 'Chebyshev'} coefficients {coeff_type}")
    print(f"# Generated: {ctime(start_time)}")
    print(f"# Domain: [{a}, {b})")
    print(f"# M={M}, N={N}, j0={j0}, l0={l0}")
    print(f"# Number of subdomains: {len(D)}")
    print("#")
    print("# Format: j i a b coeff[0] coeff[1] ... coeff[N]")
    print("#")

    for d in D:
        print(f"{d.j} {d.i} {d.a:.16e} {d.b:.16e}", end="")
        for coeff in d.coeffs:
            print(f" {coeff:.16e}", end="")
        print()


def print_source(start_time: float, a: float, b: float, M: int, N: int,
                 j0: int, l0: int, D: list[Subdomain]) -> None:
    """
    Print C source code defining economized coefficients.

    Args:
        start_time: Time when program started
        a: Lower domain bound
        b: Upper domain bound
        M: Subdivision parameter
        N: Polynomial degree
        j0: Starting octave index
        l0: Number of octaves
        D: List of subdomains
    """
    # Derived parameters
    Nout = n_output_coeffs(N)
    assert Nout > N
    nTables = (Nout - 1) // 8 + 1
    assert nTables >= 1
    nr = len(D)

    # Write top lines to file
    print("//--- Begin of auto-generated code; do not edit")
    print("//")
    print(f"// Generated on {strftime('%Y-%m-%d, %H:%M:%S', localtime(start_time))}")
    print("// by the piecewise polynomial approximation generator (https://jugit.fz-juelich.de/mlz/ppapp)")
    print("// Reference: Wuttke and Kleinsorge,")
    print('//            "Code generation for piecewise Chebyshev approximation."')
    print("//")
    print("// clang-format off")
    # Format a and b to avoid unnecessary .0 suffix
    a_str = str(int(a)) if a == int(a) else str(a)
    b_str = str(int(b)) if b == int(b) else str(b)
    print(f"static const double ppapp_a = {a_str}; // begin of domain")
    print(f"static const double ppapp_b = {b_str}; // end of domain")
    print(f"static const int ppapp_M = {M}; // 2^M subdomains per octave")
    print(f"static const int ppapp_N = {N}; // polynomial degree")
    print(f"static const int ppapp_nr = {nr}; // total number of subdomains")
    print(f"static const int ppapp_j0 = {j0}; // first octave starts at 2^(j0−1)")
    print(f"static const int ppapp_l0 = {l0}; // index of a in first octave")
    print(f"static const int ppapp_Nout = {Nout}; // stored coeffs per subdomain")
    print(f"static const int ppapp_nTables = {nTables};")

    # Write coefficient tables to file
    for k in range(nTables):
        print()
        print(f"alignas(64) static const double ppapp_Coeffs{k}[{nr} * {min(8, Nout - k*8)}] = {{")
        for d in D:
            print("    ", end="")
            for n in range(k * 8, min(Nout, (k + 1) * 8)):
                if N - n < 0:
                    print("0", end="")
                else:
                    print(hexfloat(d.coeffs[N - n]), end="")
                print(", ", end="")
            print(f"// subdomain {d.j}:{d.i} ({d.a}..{d.b})")
        print("};")

    # Write bottom lines to file
    print("// clang-format on")
    print("//--- End of auto-generated code")


def print_testcases(start_time: float, a: float, b: float, M: int, Nxo: int,
                    D: list[Subdomain], relerr: float,
                    relerr_below: float = 0.0, relerr_above: float = 0.0) -> None:
    """
    Print C source code defining test cases.

    Args:
        start_time: Time when program started
        a: Lower domain bound
        b: Upper domain bound
        M: Subdivision parameter
        Nxo: Number of extra octaves
        D: List of subdomains (extended domain)
        relerr: Maximum relative error inside [a,b)
        relerr_below: Maximum relative error below [a,b) (for extra octaves)
        relerr_above: Maximum relative error above [a,b) (for extra octaves)
    """
    # Count total subdomains
    nr = len(D)

    # Find subdomain indices for domain boundaries
    # Subdomains are ordered from low-x to high-x
    idx_main_start = None  # First subdomain starting at a
    idx_main_end = None    # First subdomain starting at b
    for i, d in enumerate(D):
        if abs(d.a - a) < 1e-10 and idx_main_start is None:
            idx_main_start = i
        if abs(d.a - b) < 1e-10 and idx_main_end is None:
            idx_main_end = i
            break

    # Print header
    print("//--- Begin of auto-generated test cases; do not edit")
    print("//")
    print(f"// Generated on {strftime('%Y-%m-%d, %H:%M:%S', localtime(start_time))}")
    print("// by the piecewise polynomial approximation generator (https://jugit.fz-juelich.de/mlz/ppapp)")
    print("// Reference: Wuttke and Kleinsorge,")
    print('//            "Code generation for piecewise Chebyshev approximation."')
    print("//")
    print("// clang-format off")
    print()
    print(f"// a = {a:g}, begin of domain")
    print(f"// b = {b:g}, end of domain")
    print(f"// M = {M}, 2^M subdomains per octave")
    print(f"// Nxo = {Nxo}, number of extra octaves on each side")
    print(f"// nr = {nr}, total number of subdomains")
    print()
    print(f"static const double ppapp_maxrelerr_inside = {relerr}; // maximum expected relative error inside [a,b)")
    if Nxo > 0:
        print(f"static const double ppapp_maxrelerr_below = {relerr_below};"
              f" // maximum expected relative error below [a,b)")
        print(f"static const double ppapp_maxrelerr_above = {relerr_above};"
              f" // maximum expected relative error above [a,b)")
    print("static double ppapp_maxrelerr; // current maximum expected relative error")
    print()
    print("int test_one(double x, double fref);")
    print()
    print("int run_tests(void)")
    print("{")
    print("    int failed = 0;")
    if Nxo > 0:
        print("    ppapp_maxrelerr = ppapp_maxrelerr_below;")
    else:
        print("    ppapp_maxrelerr = ppapp_maxrelerr_inside;")

    # Generate test points for each subdomain
    import random
    random.seed(42)  # For reproducibility
    import struct

    def nextafter_down(x):
        """Return the next representable float smaller than x."""
        if x == 0:
            return -5e-324  # Smallest negative subnormal
        bits = struct.unpack('>Q', struct.pack('>d', x))[0]
        if x > 0:
            bits -= 1
        else:
            bits += 1
        return struct.unpack('>d', struct.pack('>Q', bits))[0]

    for i, d in enumerate(D):
        # Switch error bound at domain boundaries
        if Nxo > 0 and i == idx_main_start:
            print("    ppapp_maxrelerr = ppapp_maxrelerr_inside;")
        if Nxo > 0 and i == idx_main_end:
            print("    ppapp_maxrelerr = ppapp_maxrelerr_above;")

        print(f"// subdomain {d.j}:{d.i} ({d.a:.6g}..{d.b:.6g})")
        # Generate 6 test points per subdomain:
        # - First at lower bound
        # - Four random points in the middle
        # - Last at upper bound minus epsilon
        test_xs = [d.a]
        for _ in range(4):
            x = d.a + random.random() * (d.b - d.a)
            test_xs.append(x)
        test_xs.append(nextafter_down(d.b))

        for x in test_xs:
            try:
                f_val = ref_f(x)
                x_hex = hexfloat(x)
                f_hex = hexfloat(f_val)
                print(f"    failed += test_one({x_hex}, {f_hex});")
            except Exception:
                pass

    print("    return failed;")
    print("}")
    print()
    print("// clang-format on")
    print("//--- End of auto-generated test cases")

####################################################################################################
# Main mode functions
####################################################################################################

def mode_i(f_module) -> int:
    """
    Mode i: Run initial tests from my_testcases.

    Args:
        f_module: Loaded function module with my_testcases

    Returns:
        Exit code (0 for success, 1 for failure)
    """
    arb_f = f_module.my_arb_f
    failed = 0
    for x, f_expected, tol in f_module.my_testcases:
        f_val = ref_f(x, arb_f)
        rel_err = abs((f_val - f_expected) / f_expected)
        if rel_err > tol:
            print(f"FAIL: x={x}: expected {f_expected}, got {f_val}, rel_err={rel_err}, tol={tol}")
            failed += 1
        else:
            print(f"PASS: x={x}: f={f_val}, rel_err={rel_err:.2e} <= {tol}")

    if failed:
        print(f"\n{failed} test(s) failed")
        return 1
    print(f"\nAll {len(f_module.my_testcases)} tests passed")
    return 0


def mode_v(x: float, arb_f: ArbF) -> int:
    """
    Mode v: Print function value f(x).

    Args:
        x: Point at which to evaluate function
        arb_f: Arbitrary-precision reference function

    Returns:
        Exit code (0 for success)
    """
    print(f"{x:.16e} {ref_f(x, arb_f):.16e}")
    return 0


def mode_n(a: float, b: float, M: int, Nmax: int, relerr: float, arb_f: ArbF) -> int:
    """
    Mode n: Find minimal N for each subdomain.

    Args:
        a: Lower domain bound
        b: Upper domain bound
        M: Subdivision parameter
        Nmax: Maximum N to try
        relerr: Target relative error
        arb_f: Arbitrary-precision reference function

    Returns:
        Exit code (0 for success)
    """
    import multiprocessing as mp

    j0, l0, D = compute_subdomains(a, b, M)

    # Parallel computation of N_min for each subdomain
    num_workers = mp.cpu_count()
    args = [(d, Nmax, relerr, arb_f) for d in D]

    with mp.Pool(num_workers) as pool:
        Nmin = pool.starmap(find_nmin, args)

    print("# Per subdomain: j i a b Nmin:")
    for k, d in enumerate(D):
        print(f"{d.j} {d.i} {d.a} {d.b} {Nmin[k]}")

    print(f"# Total N_min: {max(Nmin)}")
    return 0


def mode_e(a: float, b: float, M: int, N: int, arb_f: ArbF) -> int:
    """
    Mode e: Print maximum error bound.

    Args:
        a: Lower domain bound
        b: Upper domain bound
        M: Subdivision parameter
        N: Polynomial degree
        arb_f: Arbitrary-precision reference function

    Returns:
        Exit code (0 for success)
    """
    import multiprocessing as mp

    j0, l0, D = compute_subdomains(a, b, M)

    # Parallel computation of coefficients and error bounds
    num_workers = mp.cpu_count()

    # Compute coefficients
    coeffs_args = [(d, N, True, arb_f) for d in D]  # True = economized
    with mp.Pool(num_workers) as pool:
        coeffs_list = pool.starmap(compute_coeffs, coeffs_args)

    # Compute error bounds
    error_args = [(D[k], coeffs_list[k], N) for k in range(len(D))]
    with mp.Pool(num_workers) as pool:
        Err = pool.starmap(estimate_error_bound, error_args)

    print(f"Maximum error bound: {max(Err)} epsilon")
    return 0


def mode_c(start_time: float, a: float, b: float, M: int, N: int, relerr: float,
           arb_f: ArbF) -> int:
    """
    Mode c: Print plain table of Chebyshev coefficients.

    Args:
        start_time: Program start time
        a: Lower domain bound
        b: Upper domain bound
        M: Subdivision parameter
        N: Polynomial degree
        relerr: Optional error bound for checking
        arb_f: Arbitrary-precision reference function

    Returns:
        Exit code (0 for success, 1 if error exceeds bound)
    """
    import multiprocessing as mp

    j0, l0, D = compute_subdomains(a, b, M)

    # Parallel computation
    num_workers = mp.cpu_count()

    # Compute coefficients
    coeffs_args = [(d, N, False, arb_f) for d in D]  # False = Chebyshev coefficients
    with mp.Pool(num_workers) as pool:
        coeffs_list = pool.starmap(compute_coeffs, coeffs_args)

    # Store coefficients
    for k, coeffs in enumerate(coeffs_list):
        D[k].coeffs = coeffs

    # Check error bound if provided
    if relerr:
        error_args = [(D[k], coeffs_list[k], N) for k in range(len(D))]
        with mp.Pool(num_workers) as pool:
            errors = pool.starmap(estimate_error_bound, error_args)
        err = max(errors)
        if err > relerr:
            print(f"Maximum error bound: {err} larger than given bound", file=stderr)
            return 1

    print_table(start_time, True, a, b, M, N, j0, l0, D)
    return 0


def mode_p(start_time: float, a: float, b: float, M: int, N: int, relerr: float,
           arb_f: ArbF) -> int:
    """
    Mode p: Print plain table of economized coefficients.

    Args:
        start_time: Program start time
        a: Lower domain bound
        b: Upper domain bound
        M: Subdivision parameter
        N: Polynomial degree
        relerr: Optional error bound for checking
        arb_f: Arbitrary-precision reference function

    Returns:
        Exit code (0 for success, 1 if error exceeds bound)
    """
    import multiprocessing as mp

    j0, l0, D = compute_subdomains(a, b, M)

    # Parallel computation
    num_workers = mp.cpu_count()

    # Compute coefficients
    coeffs_args = [(d, N, True, arb_f) for d in D]  # True = economized coefficients
    with mp.Pool(num_workers) as pool:
        coeffs_list = pool.starmap(compute_coeffs, coeffs_args)

    # Store coefficients
    for k, coeffs in enumerate(coeffs_list):
        D[k].coeffs = coeffs

    # Check error bound if provided
    if relerr:
        error_args = [(D[k], coeffs_list[k], N) for k in range(len(D))]
        with mp.Pool(num_workers) as pool:
            errors = pool.starmap(estimate_error_bound, error_args)
        err = max(errors)
        if err > relerr:
            print(f"Maximum error bound: {err} larger than given bound", file=stderr)
            return 1

    print_table(start_time, True, a, b, M, N, j0, l0, D)
    return 0


def mode_s(start_time: float, a: float, b: float, M: int, N: int, relerr: float,
           arb_f: ArbF) -> int:
    """
    Mode s: Print C source defining economized coefficients.

    Args:
        start_time: Program start time
        a: Lower domain bound
        b: Upper domain bound
        M: Subdivision parameter
        N: Polynomial degree
        relerr: Optional error bound for checking
        arb_f: Arbitrary-precision reference function

    Returns:
        Exit code (0 for success, 1 if error exceeds bound)
    """
    import multiprocessing as mp

    j0, l0, D = compute_subdomains(a, b, M)

    # Parallel computation
    num_workers = mp.cpu_count()

    # Compute coefficients
    coeffs_args = [(d, N, True, arb_f) for d in D]  # True = economized
    with mp.Pool(num_workers) as pool:
        coeffs_list = pool.starmap(compute_coeffs, coeffs_args)

    # Store coefficients
    for k, coeffs in enumerate(coeffs_list):
        D[k].coeffs = coeffs

    # Check error bound if provided
    if relerr:
        error_args = [(D[k], coeffs_list[k], N) for k in range(len(D))]
        with mp.Pool(num_workers) as pool:
            errors = pool.starmap(estimate_error_bound, error_args)
        err = max(errors)
        if err > relerr:
            print(f"Maximum error bound: {err} larger than given bound", file=stderr)
            return 1
        # Additional checks at test points
        for d in D:
            for t in [-1., -.99897969, -.7924, -.5, 0., 1e-8, .25, .9987654321, 1.]:
                check_coeffs(d.a, d.b, d.coeffs, t, relerr, arb_f)

    print_source(start_time, a, b, M, N, j0, l0, D)
    return 0


def mode_t(start_time: float, a: float, b: float, M: int, Nxo: int,
           relerr: float, relerr_below: float = 0.0, relerr_above: float = 0.0) -> int:
    """
    Mode t: Print C source defining test cases.

    Args:
        start_time: Program start time
        a: Lower domain bound
        b: Upper domain bound
        M: Subdivision parameter
        Nxo: Number of extra octaves
        relerr: Maximum relative error inside [a,b)
        relerr_below: Maximum relative error below [a,b) (for extra octaves)
        relerr_above: Maximum relative error above [a,b) (for extra octaves)

    Returns:
        Exit code (0 for success)
    """
    j0, l0, D = compute_subdomains(a / (2 ** Nxo), b * (2 ** Nxo), M)
    print_testcases(start_time, a, b, M, Nxo, D, relerr, relerr_below, relerr_above)
    return 0


def mode_r(D: list[Subdomain], n: int, arb_f: ArbF) -> int:
    """
    Mode r: Print deviations for log-equidistant points.

    Generate n log-equidistant points across the entire domain,
    and for each point print the deviation between polynomial approximation
    and high-precision reference.

    Args:
        D: List of subdomains with computed coefficients
        n: Total number of test points across entire domain
        arb_f: Arbitrary-precision reference function

    Returns:
        Exit code (0 for success)
    """
    if not D:
        raise ValueError("No subdomains provided")

    # Get domain bounds from first and last subdomain
    a = D[0].a
    b = D[-1].b

    if a <= 0:
        raise ValueError(f"Domain lower bound must be positive for log spacing: {a}")

    # Generate n log-equidistant points across [a, b)
    ratio = b / a

    from flint import arb, ctx
    prec = 200
    ctx.prec = prec

    for i in range(n):
        # Log-equidistant point
        frac = i / (n - 1) if n > 1 else 0.5
        x = a * (ratio ** frac)

        # Ensure last point stays within domain
        if x >= b:
            x = b * (1.0 - EPS)

        # Find which subdomain contains x
        d = None
        for subdomain in D:
            if subdomain.a <= x < subdomain.b:
                d = subdomain
                break

        # Handle edge case where x equals b
        if d is None and abs(x - b) < EPS * b:
            d = D[-1]

        if d is None:
            raise ValueError(f"Point x={x} not in any subdomain")

        # Transform x to [-1, 1] for this subdomain
        mid = (d.a + d.b) / 2
        half = (d.b - d.a) / 2
        t = (x - mid) / half

        # Compute f_ref in high precision
        X = arb(x)
        F_ref = arb_f(X, prec)

        # Compute f_poly in DOUBLE precision (as it would be used in practice)
        # This includes rounding errors from polynomial evaluation
        f_poly_double = d.coeffs[-1]
        for c in reversed(d.coeffs[:-1]):
            f_poly_double = f_poly_double * t + c

        # Convert to high precision for accurate difference computation
        F_poly = arb(f_poly_double)

        # Compute relative deviation: (approximation - reference) / reference
        # in units of epsilon
        rel_dev = (F_poly - F_ref) / F_ref / arb(EPS)
        deviation = float(rel_dev.mid())

        # Print x and deviation
        print(f"{x:.16e} {deviation:.16e}")

    return 0


def mode_H(D: list[Subdomain], n: int, arb_f: ArbF) -> int:
    """
    Mode H: Print deviation histogram for random points.

    Generate n random points uniformly distributed in [a, b],
    compute absolute relative deviation for each, and output
    histogram with bin width 0.1 epsilon.

    Uses parallel processing for better performance on large n.

    Args:
        D: List of subdomains with computed coefficients
        n: Total number of random test points
        arb_f: Arbitrary-precision reference function

    Returns:
        Exit code (0 for success)
    """
    import multiprocessing as mp

    if not D:
        raise ValueError("No subdomains provided")

    # Get domain bounds
    a = D[0].a
    b = D[-1].b

    # Histogram setup: 23 bins, width 0.1 epsilon
    bin_width = 0.1
    num_bins = 23

    # Determine number of workers
    num_workers = mp.cpu_count()

    # Split work into chunks
    chunk_size = n // num_workers
    chunks = []
    for i in range(num_workers):
        # Each worker gets a deterministic seed
        seed = 421 + i
        # Last worker gets any remaining points
        n_chunk = chunk_size + (n % num_workers if i == num_workers - 1 else 0)
        chunks.append((D, a, b, n_chunk, seed, bin_width, num_bins, arb_f))

    # Process chunks in parallel
    with mp.Pool(num_workers) as pool:
        results = pool.starmap(compute_histogram_chunk, chunks)

    # Aggregate histograms from all workers
    histogram = [0] * num_bins
    for chunk_histogram in results:
        for i in range(num_bins):
            histogram[i] += chunk_histogram[i]

    # Print histogram: bin_center count
    for ch in range(num_bins):
        bin_center = (ch + 0.5) * bin_width
        print(f"{bin_center:8g} {histogram[ch]:11d}")

    return 0

####################################################################################################
# Main program
####################################################################################################

def main():
    """
    Computes and prints polynomial coefficients that approximate function ref_f.
    """
    start_time = time()

    # Check for mode argument
    if len(argv) < 2:
        print("No mode given\n", file=stderr)
        help_and_exit()

    mode = argv[1][0]

    # Handle help mode
    if mode == 'h':
        help_and_exit()

    # Check for function module argument
    if len(argv) < 3:
        print("No function module given\n", file=stderr)
        help_and_exit()

    # Mode i: initial tests
    if mode == 'i':
        if len(argv) != 3:
            print("Wrong number of arguments\n", file=stderr)
            help_and_exit()
        f_module = load_function_module(argv[2])
        return mode_i(f_module)

    # Mode v: single value
    if mode == 'v':
        if len(argv) != 4:
            print("Wrong number of arguments\n", file=stderr)
            help_and_exit()
        f_module = load_function_module(argv[2])
        try:
            x = float(argv[3])
        except ValueError:
            print(f"Invalid argument x: {argv[3]}\n", file=stderr)
            help_and_exit()
        return mode_v(x, f_module.my_arb_f)

    # Modes r and H: deviation analysis
    if mode in ['r', 'H']:
        if len(argv) != 6:
            print("Wrong number of arguments\n", file=stderr)
            help_and_exit()

        f_module = load_function_module(argv[2])

        try:
            M = int(argv[3])
            N = int(argv[4])
            n = int(argv[5])
            if M < 0 or N < 1 or n < 1:
                raise ValueError
        except (ValueError, IndexError):
            print("Invalid arguments\n", file=stderr)
            help_and_exit()

        a, b = f_module.my_domain
        assert a > 0 and b > a, "Invalid domain"

        # Compute subdomains and coefficients
        import multiprocessing as mp
        arb_f = f_module.my_arb_f
        j0, l0, D = compute_subdomains(a, b, M)
        num_workers = mp.cpu_count()
        args = [(d, N, True, arb_f) for d in D]  # True = economized coefficients

        with mp.Pool(num_workers) as pool:
            results = pool.starmap(compute_coeffs, args)

        for k, coeffs in enumerate(results):
            D[k].coeffs = coeffs

        return mode_r(D, n, arb_f) if mode == 'r' else mode_H(D, n, arb_f)

    # All other modes: n, e, c, p, s, t
    # Parse standard arguments
    f_module = load_function_module(argv[2])

    # Determine expected arguments
    if mode == 'n':
        min_args, max_args = 6, 6  # M, N(=Nmax), E
    elif mode == 'e':
        min_args, max_args = 5, 5  # M, N
    elif mode == 't':
        # Mode t: either 4 args (M, E) or 6 args (M, Nxo, E_below, E_inside, E_above)
        if len(argv) not in [5, 8]:
            print("Mode t requires either 4 or 6 arguments\n", file=stderr)
            help_and_exit()
        min_args = max_args = len(argv)  # Will be validated below
    elif mode in ['c', 'p', 's']:
        min_args, max_args = 5, 6  # M, N, [E]
    else:
        print("Invalid mode\n", file=stderr)
        help_and_exit()

    # Mode t has special argument handling
    if mode == 't':
        # Get and validate domain
        a, b = f_module.my_domain
        assert a > 0, "Lower domain bound must be positive"
        assert b > a, "Upper domain bound must be greater than lower bound"

        if len(argv) == 5:
            # ppapp t <f_module> <M> <E>
            try:
                M = int(argv[3])
                if M < 0:
                    raise ValueError
                relerr = float(argv[4])
                if not isfinite(relerr) or relerr <= 0:
                    raise ValueError
            except ValueError:
                print("Invalid M or E\n", file=stderr)
                help_and_exit()
            return mode_t(start_time, a, b, M, 0, relerr, 0.0, 0.0)

        elif len(argv) == 8:
            # ppapp t <f_module> <M> <Nxo> <E_below> <E_inside> <E_above>
            try:
                M = int(argv[3])
                Nxo = int(argv[4])
                if M < 0 or Nxo < 0:
                    raise ValueError
                relerr_below = float(argv[5])
                relerr_inside = float(argv[6])
                relerr_above = float(argv[7])
                if not all(isfinite(e) and e > 0 for e in [relerr_below, relerr_inside, relerr_above]):
                    raise ValueError
            except ValueError:
                print("Invalid arguments for mode t\n", file=stderr)
                help_and_exit()
            return mode_t(start_time, a, b, M, Nxo, relerr_inside, relerr_below, relerr_above)

    # For other modes
    if len(argv) < min_args or len(argv) > max_args:
        print("Wrong number of arguments\n", file=stderr)
        help_and_exit()

    # Parse M, N/Nmax
    try:
        M = int(argv[3])
        N = int(argv[4])
        if M < 0 or N < 1:
            raise ValueError
    except ValueError:
        print("Invalid M or N\n", file=stderr)
        help_and_exit()

    # Parse optional E/relerr
    relerr = 0.0
    if len(argv) >= 6:
        try:
            relerr = float(argv[5])
            if not isfinite(relerr) or relerr <= 0:
                raise ValueError
        except ValueError:
            print("Invalid error bound\n", file=stderr)
            help_and_exit()

    # Get and validate domain
    a, b = f_module.my_domain
    assert a > 0, "Lower domain bound must be positive"
    assert b > a, "Upper domain bound must be greater than lower bound"

    arb_f = f_module.my_arb_f

    # Dispatch to mode function
    if mode == 'n':
        assert relerr > 0.0, "Mode n requires error bound E"
        return mode_n(a, b, M, N, relerr, arb_f)
    elif mode == 'e':
        return mode_e(a, b, M, N, arb_f)
    elif mode == 'c':
        return mode_c(start_time, a, b, M, N, relerr, arb_f)
    elif mode == 'p':
        return mode_p(start_time, a, b, M, N, relerr, arb_f)
    elif mode == 's':
        return mode_s(start_time, a, b, M, N, relerr, arb_f)
    else:
        print("Invalid mode\n", file=stderr)
        help_and_exit()


if __name__ == "__main__":
    exit(main())
