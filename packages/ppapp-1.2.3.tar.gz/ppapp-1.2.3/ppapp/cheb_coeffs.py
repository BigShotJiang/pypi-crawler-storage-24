"""
Code generating code for piecewise Chebyshev approximation

Reference: Joachim Wuttke and Alexander Kleinsorge,
           Algorithm 1XXX: Code generation for piecewise Chebyshev approximation

File:      ppapp/cheb_coeffs.py

License:   GNU General Public License, version 3 or higher (see LICENSE)
Copyright: Forschungszentrum Jülich GmbH 2025
Author:    Joachim Wuttke <j.wuttke@fz-juelich.de>
"""

from math import isfinite
from typing import Callable

from flint import arb, ctx

ArbF = Callable[[arb, int], arb]


def str_arb(A: arb) -> str:
    """
    Convert arbitrary precision number to string representation.
    """
    a: float = float(A)
    return f"{a:10.5e}"


def arb_to_float(A: arb) -> float:
    """
    Convert arbitrary precision number to float.
    If the interval [A.mid - A.rad, A.mid + A.rad] contains 0,
    return 0.0 as the most plausible floating-point representation.
    """
    mid = float(A.mid())
    rad = float(A.rad())
    # Check if interval contains 0
    if mid - rad <= 0 and mid + rad >= 0:
        return 0.0
    return mid


def sizeT(N: int) -> int:
    """
    Returns total number of coefficients T_nm with n<=N.
    For N = -2,-1,0,1,..., result is 0,0,1,2,4,6,9,12,16,20,... (OEIS A002620).
    """
    assert N >= -2
    return ((N + 2) // 2) * ((N + 1) // 2 + 1)


def precompute_Tnm(N: int) -> list[int]:
    """
    Returns flat list of nonzero coefficients T_nm with n<=N.
    For N = 0,1,..., result is 1,1,-1,2,-3,4,1,-8,8,5,-20,16,-1,18,-48,32,... (OEIS A008310).
    """
    assert N >= 0
    if N == 0:
        return [1]
    if N == 1:
        return [1, 1]
    # The first two coefficients:
    # R.append(1)
    # if N >= 1: R.append(1)
    R = [1, 1]
    # Remaining coefficients by recursion:
    for n in range(2, N + 1):
        if n % 2 == 0:
            R.append(-R[sizeT(n - 3)])
        for j in range((n + 1) & 1, n // 2):
            R.append(2 * R[sizeT(n - 2) + j - ((n + 1) & 1)] - R[sizeT(n - 3) + j])
        R.append(2 * R[sizeT(n - 2) + (n - 1) // 2])
    assert len(R) == sizeT(N)
    assert R[-1] == (1 << (0 if N == 0 else N - 1))  # T_nn is 2^{n-1}; will fail if there is overflow
    return R


def cheb_cn_arb(a: float, b: float, N: int, prec: int,
                arb_f: ArbF) -> list[arb]:
    """
    Returns the Chebyshev coefficients c_n as vector of arbitrary-precision numbers.
    """
    # Set global precision
    ctx.prec = prec

    # Compute the c_n
    M = arb((a + b) * 0.5)  # midpoint
    H = arb((b - a) * 0.5)  # halfrange

    assert N > 0  # otherwise division by 0; no obvious way to salvage the formalism

    CC = []
    for n in range(N + 1):
        sn = 1 if n == 0 else 2
        C = arb(0)
        for k in range(N + 1):  # increment c_n = sum_{k=0}^N sk f(xk) Tn((xk-a)/(b-a))
            sk = 1 if (k == 0 or k == N) else 2
            E = arb(k)
            E = E * arb.pi()
            E = E / N  # E = k*pi/N (division in arbitrary precision)
            E = E.cos()  # E = xk = cos(k*pi/N) = Chebyshev extremal point
            T = E.chebyshev_t(n)  # T = T_n(ek)
            E = E * H
            E = E + M  # E = midpoint + halfrange*xk
            F = arb_f(E, prec)  # F = f(xk), here we evaluate the reference function
            F = F * T  # F = f(xk) * T_n(ek)
            C = C + sk * F  # increment C by sigma_k * f(xk) * T_n(ek)

        E = arb(sn) / arb(2 * N)  # E = sigma_n/(2N) in arbitrary precision
        C = C * E
        CC.append(C)

    return CC


# Module-level cache for precomputed T_nm coefficients
_cached_Tnm: list[int] = []


def cheb_pm_prec(a: float, b: float, N: int, prec: int,
                 arb_f: ArbF) -> list[float]:
    """
    Returns monomial coefficents p_m for m=0,..,N, computed with precision prec.
    """
    global _cached_Tnm

    # Recompute T_nm if needed for larger N
    if len(_cached_Tnm) < sizeT(N):
        _cached_Tnm = precompute_Tnm(N)

    Tnm = _cached_Tnm

    CC = cheb_cn_arb(a, b, N, prec, arb_f)

    # Compute the p_m
    # ctx.prec is already set by cheb_cn_arb
    result: list[float] = []
    for m in range(N + 1):  # compute p_m
        P = arb(0)
        for n in range(m, N + 1, 2):  # increment p_m = sum_{n=0}^m c_n T_{nm}
            t = Tnm[sizeT(n - 1) + (m - n % 2) // 2]
            P = P + t * CC[n]  # increment p_m by t*C

        p: float = arb_to_float(P)
        if not isfinite(p):
            raise RuntimeError("Invalid coefficient p_m, not a number or infinite")
        dp = float(P.rad())
        if p == 0:
            # Zero coefficient is acceptable (e.g., for polynomials)
            result.append(p)
            continue
        if abs(dp / p) > 1e-18:
            result = []
            break
        result.append(p)
        # import sys
        # print(f"p_{m}={p}", file=sys.stderr)

    return result


def ref_f(x: float, arb_f: ArbF) -> float:
    """
    Returns f(x), computed to relative precision 1e-18.
    """
    for prec in range(77, 170, 9):
        ctx.prec = prec
        X = arb(x)
        F = arb_f(X, prec)
        y = float(F.mid())
        dy = float(F.rad())
        if y == 0:
            raise RuntimeError("Unexpected function value 0")
        if abs(dy / y) < 1e-18:
            return y

    raise RuntimeError("Reference function did not achieve accuracy 1e-18")


def check_coeffs(a: float, b: float, P: list[float], tin: float, relerr: float,
                 arb_f: ArbF) -> None:
    """
    Checks whether economized coefficients reproduce reference function within a few epsilon.
    """
    from sys import stderr
    x: float = (b + a) * 0.5 + (b - a) * 0.5 * tin
    t: float = (x - (a + b) * 0.5) / ((b - a) * 0.5)  # convert back to suppress irrelevant conversion error from t->x
    fnew = P[-1]
    for c in reversed(P[:-1]):
        fnew = fnew * t + c

    fref = ref_f(x, arb_f)
    if abs((fnew - fref) / fref) > relerr * (2.0 ** -53):  # epsilon = 2^-53
        print(f"t={t} x={x} => relerr={abs((fnew - fref) / fref)}:", file=stderr)
        f3 = 0.0

        for m in range(len(P)):
            tm = t ** m
            f3 += P[m] * tm
            print(f"m={m:2d} t^m={tm:8.2g} P[m]={P[m]:8.2g} term={tm * P[m]:8.2g} sum={f3:22.16e}", file=stderr)

        print(f"                                              hor={fnew:22.16e}", file=stderr)
        print(f"                                              ref={fref:22.16e}", file=stderr)
        raise RuntimeError("Approximation not accurate enough")


def cheb_cn(a: float, b: float, N: int, arb_f: ArbF) -> list[float]:
    """
    Returns polynomial coefficents c_n for m=0,..,N,
    such that the reference function f is approximated by sum_{n=0}^N c_n T_n((x-a)/(b-a)).
    Full double-precision accuracy is ensured by running the arbitrary-precision computation
    in function cheb_cn_arb with different precisions.
    """
    # Compute with increasing precision until results agree.
    for prec in range(72, 400, 32):
        CC = cheb_cn_arb(a, b, N, prec, arb_f)
        result: list[float] = []
        for C in CC:
            c = arb_to_float(C)
            if not isfinite(c):
                raise RuntimeError("Invalid coefficient c_n, not a number or infinite")
            if c == 0:
                # Zero coefficient is acceptable (e.g., for polynomials)
                result.append(c)
                continue
            if abs(float(C.rad()) / c) > 1e-18: # c has not reached sufficient precision
                result = []
                break # break inner loop, continue outer loop
            result.append(c)
        if result:
            return result

    raise RuntimeError("Loop in precision did not converge")


def cheb_pm(a: float, b: float, N: int, arb_f: ArbF) -> list[float]:
    """
    Returns polynomial coefficents p_m for m=0,..,N,
    such that the reference function f is approximated by sum_{m=0}^N p_m ((x-a)/(b-a))^m.
    Full double-precision accuracy is ensured by running the arbitrary-precision computation
    in function cheb_coeffs_prec with different precisions.
    """
    # Compute with increasing precision until results agree.
    for prec in range(72, 800, 32):
        result = cheb_pm_prec(a, b, N, prec, arb_f)
        if result:
            return result

    raise RuntimeError("Loop in precision did not converge")
