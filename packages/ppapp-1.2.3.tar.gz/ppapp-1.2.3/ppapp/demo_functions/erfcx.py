#!/usr/bin/env python3

"""
Code generating code for piecewise Chebyshev approximation

Reference: Joachim Wuttke and Alexander Kleinsorge,
           Algorithm 1XXX: Code generation for piecewise Chebyshev approximation

File:      ppapp/demo_functions/erfcx.py

Arbitrary-precision implementation of function erfcx(x).

License:   GNU General Public License, version 3 or higher (see src/LICENSE)
Copyright: Forschungszentrum Jülich GmbH 2025
Author:    Joachim Wuttke <j.wuttke@fz-juelich.de>
"""


from flint import arb

# The total intermediate domain [a,b) to be covered by piecewise polynomial approximation:
my_domain: tuple[float, float] = (0.125, 12.0)


def my_arb_f(X: arb, prec: int) -> arb:
    """
    Evaluates the overflow-compensated complementary error function
      f(x) = erfcx(x) = exp(x^2) * erfc(x),
    using 'prec' binary digits.

    Args:
        X: Input value as arbitrary precision number
        prec: Precision in binary digits

    Returns:
        F = f(X) with given precision
    """
    return X.erfc() * (X ** 2).exp()


# A few test cases, just to secure against gross errors.
# Each entry is (x, f_expected(x), tolerance)
my_testcases: list[tuple[float, float, float]] = [
    (0.2, 0.8090195, 1e-5),
    (1.0, 0.4275836, 1e-5),
    (12.0, 0.046854221, 1e-5),
]
