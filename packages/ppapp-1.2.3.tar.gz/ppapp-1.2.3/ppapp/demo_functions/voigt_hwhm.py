#!/usr/bin/env python3

"""
Code generating code for piecewise Chebyshev approximation

Reference: Joachim Wuttke and Alexander Kleinsorge,
           Algorithm 1XXX: Code generation for piecewise Chebyshev approximation

File:      ppapp/demo_functions/voigt_hwhm.py

Arbitrary-precision implementation of the half width at half maximum of the Voigt function.

License:   GNU General Public License, version 3 or higher (see src/LICENSE)
Copyright: Forschungszentrum Jülich GmbH 2025
Authors:   Eva Mukherjee, Joachim Wuttke <j.wuttke@fz-juelich.de>
"""

import sys

from flint import acb, arb, ctx


def acb_faddeeva_w(z: acb, prec: int) -> acb:
    """
    Computes the Faddeeva function w(z).

    Args:
        z: Complex input as arbitrary precision complex number
        prec: Precision in binary digits

    Returns:
        w(z) = exp(-z^2) * erfc(-i*z)
    """
    ctx.prec = prec

    minus_iz = acb(z.imag, -z.real)
    return (-(z * z)).exp() * minus_iz.erfc()


def my_arb_voigt(q: arb, sigma: arb, gamma: arb, prec: int) -> arb:
    """
    Computes the Voigt function V(q; sigma, gamma).

    Args:
        q: Position parameter
        sigma: Gaussian width parameter
        gamma: Lorentzian width parameter
        prec: Precision in binary digits

    Returns:
        V(q; sigma, gamma)
    """
    ctx.prec = prec

    # Calculating the complex argument z = q / (sqrt(2) * sigma) + i * gamma / (sqrt(2) * sigma)
    T2 = arb(0.5).sqrt() / sigma
    z_complex_arg = acb(q * T2, gamma * T2) # (q+i*gamma) / (sqrt(2)*sigma)

    # Faddeeva function
    w_z_result = acb_faddeeva_w(z_complex_arg, prec)
    T1 = w_z_result.real

    # Calculating 1 / (sqrt(2*pi)*sigma)
    T2 = T2 / arb.pi().sqrt()

    # Computing the Voigt Function
    return T2 * T1


def my_arb_f(X: arb, prec: int) -> arb:
    """
    Computes the half width at half maximum (HWHM) of the Voigt function
    as a function of the ratio gamma/sigma.

    Args:
        X: Input value representing gamma/sigma ratio
        prec: Precision in binary digits

    Returns:
        HWHM for the given gamma/sigma ratio
    """
    ctx.prec = prec

    # The input 'X' represents the ratio gamma/sigma.
    sigma = arb(1.0)
    gamma = X * sigma  # gamma = (gamma/sigma) * sigma = X * 1

    # Calculating V(0; sigma, gamma)
    V_zero = my_arb_voigt(arb(0.0), sigma, gamma, prec)

    # Calculating the target value: 0.5 * V(0; sigma, gamma)
    target_V = V_zero / 2

    # Bisection Method
    # Finding the root of the function f(q) = V(q; sigma, gamma) - target value
    a = arb(0.0)
    b = arb(1.0)

    # Finding b such that V(b) < target_V
    for _ in range(10):
        val_c = my_arb_voigt(b, sigma, gamma, prec)
        if val_c < target_V:
            break
        b *= 2

    # Bisection loop
    max_iter = 2 * prec
    tol = arb(2.0) ** (-prec)

    for _ in range(max_iter):
        diff = b - a
        if diff <= tol:
            break
        c = (a + b) / 2
        val_c = my_arb_voigt(c, sigma, gamma, prec)
        if val_c > target_V:
            a = c  # V(c) too high => mid is too small
        else:
            b = c  # V(c) too low => mid is too large

    # Check convergence
    diff = b - a
    if diff > tol:
        print(f"Warning: bisection may not have converged for X={float(X)}", file=sys.stderr)

    # The result is the HWHM which is midpoint of [a, b]
    return (a + b) / 2


# The total domain [a,b) to be covered by piecewise polynomial approximation.
my_domain: tuple[float, float] = (0.25, 16.0)

# Test cases. Expected values from Olivero-Longbothum for σ=1 and the given γ values.
# Each entry is (x, f_expected(x), tolerance)
my_testcases: list[tuple[float, float, float]] = [
    (0.26, 1.3230, 1e-3),
    (0.73, 1.6161, 1e-3),
    (1.0, 1.8010, 1e-3),
    (1.472, 2.1495, 1e-3),
    (3.67, 4.0356, 1e-3),
    (4.001, 4.3404, 1e-3),
    (7.999, 8.1792, 1e-3),
    (12.0, 12.1250, 1e-3),
    (15.999, 16.0957, 1e-3),
]
