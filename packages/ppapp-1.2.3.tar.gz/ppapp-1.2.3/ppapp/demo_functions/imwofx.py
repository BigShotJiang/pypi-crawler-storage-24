#!/usr/bin/env python3

"""
Code generating code for piecewise Chebyshev approximation

Reference: Joachim Wuttke and Alexander Kleinsorge,
           Algorithm 1XXX: Code generation for piecewise Chebyshev approximation

File:      ppapp/demo_functions/imwofx.py

Arbitrary-precision implementation of function Im w(x).

License:   GNU General Public License, version 3 or higher (see src/LICENSE)
Copyright: Forschungszentrum Jülich GmbH 2025
Author:    Joachim Wuttke <j.wuttke@fz-juelich.de>
"""


from flint import arb

# The total intermediate domain [a,b) to be covered by piecewise polynomial approximation:
my_domain: tuple[float, float] = (0.5, 12.0)


def my_arb_f(X: arb, prec: int) -> arb:
    """
    Evaluates the overflow-compensated imaginary error function
      f(x) = exp(-x^2) * erfi(x) = Im w(x),
    using 'prec' binary digits.

    Args:
        X: Input value as arbitrary precision number
        prec: Precision in binary digits

    Returns:
        F = f(X) with given precision
    """
    return X.erfi() * (-(X ** 2)).exp()


# A few test cases, just to secure against gross errors.
# Each entry is (x, f_expected(x), tolerance)
my_testcases: list[tuple[float, float, float]] = [
    (0.5, 0.478925, 1e-5),
    (1.0, 0.607158, 1e-5),
    (12.0, 0.0471808, 1e-5),
]
