#!/usr/bin/env python3

"""
Target algorithm for piecewise polynomial evaluation.

This script demonstrates the algorithm that evaluates a piecewise polynomial
approximation using Horner's method. It shows how to:
- Find the subdomain containing a given x
- Transform x to the local coordinate t in [-1, 1]
- Evaluate the polynomial using Horner's method

IMPORTANT: This plain Python implementation is for illustration only.
Project ppapp is designed to generate C code for optimized high-throughput
computation. For production use from Python, the evaluation code should be
implemented as a C extension module or at least use NumPy for vectorized
operations. Do not use this script as a template for production code.

Run with:
    python -m ppapp.target_algorithm
"""

from ppapp import cheb_pm, compute_subdomains, ref_f
from ppapp.demo_functions.imwofx import my_arb_f, my_domain


def find_subdomain(x: float, subdomains) -> int:
    """
    Find the subdomain index containing x.
    """
    for i, d in enumerate(subdomains):
        if d.a <= x < d.b:
            return i
    # x might equal the last boundary
    if subdomains and x == subdomains[-1].b:
        return len(subdomains) - 1
    raise ValueError(f"x={x} not in any subdomain")


def horner_eval(coeffs: list[float], t: float) -> float:
    """
    Evaluate polynomial using Horner's method.
    """
    result = coeffs[-1]
    for c in reversed(coeffs[:-1]):
        result = result * t + c
    return result


def main():
    # Set up
    a, b = my_domain
    M = 5
    N = 10

    # Compute subdomains and their coefficients
    j0, l0, subdomains = compute_subdomains(a, b, M)
    for d in subdomains:
        d.coeffs = cheb_pm(d.a, d.b, N, my_arb_f)

    # Test points
    test_x = [0.5, 1.0, 2.0, 5.0, 10.0, 11.9]

    print("Comparing approximation vs reference:")
    print("-" * 70)
    print(f"{'x':>10} {'f_approx':>20} {'f_ref':>20} {'rel_error':>15}")
    print("-" * 70)

    eps = 2.0 ** -53  # Machine epsilon

    for x in test_x:
        # Find subdomain
        idx = find_subdomain(x, subdomains)
        d = subdomains[idx]

        # Transform x to [-1, 1]
        mid = (d.a + d.b) / 2
        half = (d.b - d.a) / 2
        t = (x - mid) / half

        # Evaluate approximation
        f_approx = horner_eval(d.coeffs, t)

        # Evaluate reference
        f_ref = ref_f(x, my_arb_f)

        # Relative error in units of epsilon
        rel_err = abs(f_approx - f_ref) / abs(f_ref) / eps

        print(f"{x:10.4f} {f_approx:20.15f} {f_ref:20.15f} {rel_err:12.2f} eps")


if __name__ == "__main__":
    main()
