"""
ppapp - Piecewise Polynomial Approximation

Code generator for piecewise Chebyshev approximation of mathematical functions.

Reference: Joachim Wuttke and Alexander Kleinsorge,
           "Algorithm 1XXX: Code generation for piecewise Chebyshev approximation"

License:   GNU General Public License, version 3 or higher
Copyright: Forschungszentrum Jülich GmbH 2025
"""

from ppapp.cheb_coeffs import (
    ArbF,
    cheb_cn,
    cheb_pm,
    check_coeffs,
    ref_f,
)
from ppapp.ppapp import (
    Subdomain,
    analyse_row,
    compute_subdomains,
    extrapolate_power_law,
    hexfloat,
    n_output_coeffs,
)

__version__ = "1.2.3"


def get_docs_path() -> str:
    """
    Return path to the documentation directory.
    """
    from importlib.resources import files
    return str(files("ppapp") / "docs")


def get_user_manual_path() -> str:
    """
    Return path to the user manual PDF.
    """
    from importlib.resources import files
    return str(files("ppapp") / "docs" / "userManual.pdf")


__all__ = [
    "cheb_cn",
    "cheb_pm",
    "ArbF",
    "ref_f",
    "check_coeffs",
    "Subdomain",
    "analyse_row",
    "extrapolate_power_law",
    "compute_subdomains",
    "hexfloat",
    "n_output_coeffs",
    "get_docs_path",
    "get_user_manual_path",
]
