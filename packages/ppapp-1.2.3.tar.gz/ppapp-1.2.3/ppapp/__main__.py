"""
Entry point for running ppapp as a module: python -m ppapp
"""

from ppapp.ppapp import main

if __name__ == "__main__":
    exit(main())
