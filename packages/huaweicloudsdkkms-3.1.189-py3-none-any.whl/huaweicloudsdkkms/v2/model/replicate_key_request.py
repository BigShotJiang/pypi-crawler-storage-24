# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ReplicateKeyRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'key_id': 'str',
        'body': 'ReplicateKeyRequestBody'
    }

    attribute_map = {
        'key_id': 'key_id',
        'body': 'body'
    }

    def __init__(self, key_id=None, body=None):
        r"""ReplicateKeyRequest

        The model defined in huaweicloud sdk

        :param key_id: 待复制的密钥ID，36字节，满足正则匹配“^[0-9a-z]{8}-[0-9a-z]{4}-[0-9a-z]{4}-[0-9a-z]{4}-[0-9a-z]{12}$”。 例如：0d0466b0-e727-4d9c-b35d-f84bb474a37f。
        :type key_id: str
        :param body: Body of the ReplicateKeyRequest
        :type body: :class:`huaweicloudsdkkms.v2.ReplicateKeyRequestBody`
        """
        
        

        self._key_id = None
        self._body = None
        self.discriminator = None

        self.key_id = key_id
        if body is not None:
            self.body = body

    @property
    def key_id(self):
        r"""Gets the key_id of this ReplicateKeyRequest.

        待复制的密钥ID，36字节，满足正则匹配“^[0-9a-z]{8}-[0-9a-z]{4}-[0-9a-z]{4}-[0-9a-z]{4}-[0-9a-z]{12}$”。 例如：0d0466b0-e727-4d9c-b35d-f84bb474a37f。

        :return: The key_id of this ReplicateKeyRequest.
        :rtype: str
        """
        return self._key_id

    @key_id.setter
    def key_id(self, key_id):
        r"""Sets the key_id of this ReplicateKeyRequest.

        待复制的密钥ID，36字节，满足正则匹配“^[0-9a-z]{8}-[0-9a-z]{4}-[0-9a-z]{4}-[0-9a-z]{4}-[0-9a-z]{12}$”。 例如：0d0466b0-e727-4d9c-b35d-f84bb474a37f。

        :param key_id: The key_id of this ReplicateKeyRequest.
        :type key_id: str
        """
        self._key_id = key_id

    @property
    def body(self):
        r"""Gets the body of this ReplicateKeyRequest.

        :return: The body of this ReplicateKeyRequest.
        :rtype: :class:`huaweicloudsdkkms.v2.ReplicateKeyRequestBody`
        """
        return self._body

    @body.setter
    def body(self, body):
        r"""Sets the body of this ReplicateKeyRequest.

        :param body: The body of this ReplicateKeyRequest.
        :type body: :class:`huaweicloudsdkkms.v2.ReplicateKeyRequestBody`
        """
        self._body = body

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ReplicateKeyRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
