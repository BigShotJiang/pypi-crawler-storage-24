"""CLI entry point for cueapi-worker."""
from __future__ import annotations

import logging
import platform
import sys

import click

from cueapi_worker import __version__


@click.group()
@click.version_option(version=__version__, prog_name="cueapi-worker")
def main():
    """CueAPI Worker — local pull-based daemon for executing scheduled tasks."""
    pass


@main.command()
@click.option(
    "--config",
    "-c",
    required=True,
    type=click.Path(exists=True),
    help="Path to worker config YAML file.",
)
@click.option("--verbose", "-v", is_flag=True, help="Enable verbose (DEBUG) logging.")
def start(config: str, verbose: bool):
    """Start the worker daemon.

    Polls CueAPI for claimable executions, matches them to handlers
    defined in the config file, and executes them locally.
    """
    # Configure logging
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    from cueapi_worker.config import load_config
    from cueapi_worker.daemon import WorkerDaemon

    try:
        cfg = load_config(config)
    except (FileNotFoundError, ValueError) as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)

    click.echo(f"CueAPI Worker v{__version__}")
    click.echo(f"  Worker ID:    {cfg.worker_id}")
    click.echo(f"  API Base:     {cfg.api_base}")
    click.echo(f"  Handlers:     {', '.join(cfg.handler_names())}")
    click.echo(f"  Poll interval: {cfg.poll_interval}s")
    click.echo(f"  Max concurrent: {cfg.max_concurrent}")
    click.echo()

    daemon = WorkerDaemon(cfg)
    daemon.run()


@main.command()
@click.option(
    "--config",
    "-c",
    required=True,
    type=click.Path(exists=True),
    help="Path to worker config YAML file.",
)
def status(config: str):
    """Check worker status by sending a heartbeat.

    Verifies connectivity to the CueAPI server and reports
    whether the worker can authenticate and communicate.
    """
    from cueapi_worker.client import WorkerAPIClient
    from cueapi_worker.config import load_config

    try:
        cfg = load_config(config)
    except (FileNotFoundError, ValueError) as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)

    client = WorkerAPIClient(api_key=cfg.api_key, api_base=cfg.api_base)
    ok = client.heartbeat(cfg.worker_id, cfg.handler_names())

    if ok:
        click.echo(f"Worker '{cfg.worker_id}' is connected and authenticated.")
        click.echo(f"  Handlers: {', '.join(cfg.handler_names())}")
    else:
        click.echo("Failed to connect to CueAPI. Check your API key and network.", err=True)
        sys.exit(1)


@main.command("install-service")
@click.option(
    "--config",
    "-c",
    required=True,
    type=click.Path(exists=True),
    help="Path to worker config YAML file.",
)
def install_service(config: str):
    """Install worker as a system service (launchd on macOS, systemd on Linux)."""
    from cueapi_worker.service import install_launchd, install_systemd

    system = platform.system()
    try:
        if system == "Darwin":
            path = install_launchd(config)
            click.echo(f"Installed launchd service: {path}")
            click.echo("The worker will start automatically on login.")
        elif system == "Linux":
            path = install_systemd(config)
            click.echo(f"Installed systemd service: {path}")
            click.echo("The worker is now running and will start on boot.")
        else:
            click.echo(f"Unsupported platform: {system}. Use 'cueapi-worker start' directly.", err=True)
            sys.exit(1)
    except Exception as e:
        click.echo(f"Error installing service: {e}", err=True)
        sys.exit(1)


@main.command("uninstall-service")
def uninstall_service():
    """Uninstall the worker system service."""
    from cueapi_worker.service import uninstall_launchd, uninstall_systemd

    system = platform.system()
    try:
        if system == "Darwin":
            ok = uninstall_launchd()
        elif system == "Linux":
            ok = uninstall_systemd()
        else:
            click.echo(f"Unsupported platform: {system}", err=True)
            sys.exit(1)

        if ok:
            click.echo("Service uninstalled successfully.")
        else:
            click.echo("Service not found. Nothing to uninstall.")
    except Exception as e:
        click.echo(f"Error uninstalling service: {e}", err=True)
        sys.exit(1)


if __name__ == "__main__":
    main()
