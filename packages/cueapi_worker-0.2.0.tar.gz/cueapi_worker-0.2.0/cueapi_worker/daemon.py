"""Worker daemon — main poll loop that claims and executes tasks."""
from __future__ import annotations

import logging
import signal
import time
from concurrent.futures import ThreadPoolExecutor, Future
from typing import Dict, Set

from cueapi_worker.client import AuthenticationError, WorkerAPIClient
from cueapi_worker.config import WorkerConfig
from cueapi_worker.executor import execute_handler
from cueapi_worker.heartbeat import HeartbeatThread

logger = logging.getLogger(__name__)


class WorkerDaemon:
    """Main worker daemon.

    Poll loop: get_claimable -> match handler -> claim -> execute in
    ThreadPoolExecutor -> report outcome. Respects max_concurrent.
    Handles SIGINT/SIGTERM gracefully.
    """

    def __init__(self, config: WorkerConfig):
        self._config = config
        self._client = WorkerAPIClient(
            api_key=config.api_key,
            api_base=config.api_base,
        )
        self._heartbeat = HeartbeatThread(
            client=self._client,
            worker_id=config.worker_id,
            handlers=config.handler_names(),
            interval=config.heartbeat_interval,
        )
        self._executor = ThreadPoolExecutor(
            max_workers=config.max_concurrent,
            thread_name_prefix="cueapi-handler",
        )
        self._running = False
        self._active_futures: Set[Future] = set()

    def run(self) -> None:
        """Start the daemon and run until interrupted."""
        self._running = True

        # Install signal handlers
        signal.signal(signal.SIGINT, self._handle_signal)
        signal.signal(signal.SIGTERM, self._handle_signal)

        logger.info(
            "Worker daemon starting: worker_id=%s, handlers=%s, poll_interval=%ds, max_concurrent=%d",
            self._config.worker_id,
            self._config.handler_names(),
            self._config.poll_interval,
            self._config.max_concurrent,
        )

        # Start heartbeat thread
        self._heartbeat.start()

        try:
            while self._running:
                try:
                    self._poll_cycle()
                except AuthenticationError as e:
                    logger.critical(str(e))
                    self._running = False
                    self._shutdown()
                    raise SystemExit(1)
                if self._running:
                    time.sleep(self._config.poll_interval)
        finally:
            self._shutdown()

    def _poll_cycle(self) -> None:
        """Run one poll cycle: fetch claimable, match, claim, execute."""
        # Clean up completed futures
        done = {f for f in self._active_futures if f.done()}
        self._active_futures -= done

        # Check available capacity
        available = self._config.max_concurrent - len(self._active_futures)
        if available <= 0:
            logger.debug("At max concurrent (%d), skipping poll", self._config.max_concurrent)
            return

        # Fetch claimable executions
        executions = self._client.get_claimable()
        if not executions:
            return

        claimed = 0
        for exec_data in executions:
            if claimed >= available:
                break

            task = exec_data.get("task")
            execution_id = exec_data.get("execution_id")

            # Match handler
            handler_config = self._config.handlers.get(task) if task else None
            if handler_config is None:
                logger.debug(
                    "No handler for task=%s, skipping execution=%s",
                    task,
                    execution_id,
                )
                continue

            # Claim
            claim_result = self._client.claim(execution_id, self._config.worker_id)
            if claim_result is None:
                logger.debug("Failed to claim execution=%s", execution_id)
                continue

            claimed += 1
            logger.info(
                "Claimed execution=%s task=%s cue=%s",
                execution_id,
                task,
                exec_data.get("cue_name"),
            )

            # Submit to thread pool
            future = self._executor.submit(
                self._execute_and_report,
                handler_config,
                exec_data,
            )
            self._active_futures.add(future)

        if claimed > 0:
            logger.info("Poll cycle: claimed %d executions", claimed)

    def _execute_and_report(self, handler_config, exec_data: Dict) -> None:
        """Execute a handler and report the outcome. Runs in thread pool."""
        execution_id = exec_data.get("execution_id", "")
        cue_id = exec_data.get("cue_id", "")
        cue_name = exec_data.get("cue_name", "")
        payload = exec_data.get("payload", {})

        try:
            success, output = execute_handler(
                handler=handler_config,
                payload=payload,
                execution_id=execution_id,
                cue_id=cue_id,
                cue_name=cue_name,
                worker_id=self._config.worker_id,
            )

            # Report outcome
            if success:
                self._client.report_outcome(
                    execution_id=execution_id,
                    success=True,
                    result=output or "completed",
                )
            else:
                self._client.report_outcome(
                    execution_id=execution_id,
                    success=False,
                    error=output or "handler failed",
                )

        except Exception as e:
            logger.error("Unhandled error executing %s: %s", execution_id, e)
            self._client.report_outcome(
                execution_id=execution_id,
                success=False,
                error=f"Worker error: {e}",
            )

    def _handle_signal(self, signum: int, frame) -> None:
        """Handle SIGINT/SIGTERM gracefully."""
        sig_name = signal.Signals(signum).name
        logger.info("Received %s, shutting down gracefully...", sig_name)
        self._running = False

    def _shutdown(self) -> None:
        """Clean shutdown: stop heartbeat, wait for active tasks."""
        logger.info("Shutting down worker daemon...")

        # Stop heartbeat
        self._heartbeat.stop()

        # Wait for active tasks to complete
        if self._active_futures:
            logger.info("Waiting for %d active tasks to complete...", len(self._active_futures))
            for future in self._active_futures:
                try:
                    future.result(timeout=30)
                except Exception as e:
                    logger.error("Task error during shutdown: %s", e)

        self._executor.shutdown(wait=False)
        logger.info("Worker daemon stopped")
