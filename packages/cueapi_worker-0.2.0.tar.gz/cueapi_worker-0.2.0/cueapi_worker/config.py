"""Configuration loading for cueapi-worker."""
from __future__ import annotations

import json
import os
import platform
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional

import yaml


@dataclass
class HandlerConfig:
    """Configuration for a single task handler."""

    cmd: str
    cwd: Optional[str] = None
    timeout: int = 300
    env: Optional[Dict[str, str]] = None


@dataclass
class WorkerConfig:
    """Top-level worker configuration."""

    api_key: str
    api_base: str = "https://api.cueapi.ai"
    worker_id: str = ""
    poll_interval: int = 5
    heartbeat_interval: int = 30
    max_concurrent: int = 4
    handlers: Dict[str, HandlerConfig] = field(default_factory=dict)

    def handler_names(self) -> List[str]:
        """Return list of handler task names."""
        return list(self.handlers.keys())


def _resolve_api_key(raw: Optional[str]) -> str:
    """Resolve API key: config value > CUEAPI_API_KEY env > credentials file."""
    # 1. Explicit value from config
    if raw:
        return raw

    # 2. Environment variable
    env_key = os.environ.get("CUEAPI_API_KEY")
    if env_key:
        return env_key

    # 3. Credentials file (same as CLI)
    creds_path = Path.home() / ".config" / "cueapi" / "credentials.json"
    if creds_path.exists():
        try:
            data = json.loads(creds_path.read_text())
            default = data.get("default", {})
            key = default.get("api_key")
            if key:
                return key
        except (json.JSONDecodeError, KeyError):
            pass

    raise ValueError(
        "No API key found. Set 'api_key' in config, CUEAPI_API_KEY env var, "
        "or run 'cueapi login' to save credentials."
    )


def _default_worker_id() -> str:
    """Generate default worker_id from hostname."""
    return platform.node() or "worker-unknown"


def load_config(path: str) -> WorkerConfig:
    """Load and validate worker config from a YAML file.

    Args:
        path: Path to the YAML config file.

    Returns:
        Validated WorkerConfig instance.

    Raises:
        FileNotFoundError: If config file doesn't exist.
        ValueError: If config is invalid.
    """
    config_path = Path(path)
    if not config_path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")

    with open(config_path) as f:
        raw = yaml.safe_load(f)

    if not isinstance(raw, dict):
        raise ValueError(f"Invalid config file: expected a YAML mapping, got {type(raw).__name__}")

    # Resolve API key
    api_key = _resolve_api_key(raw.get("api_key"))

    # Parse handlers
    handlers: Dict[str, HandlerConfig] = {}
    raw_handlers = raw.get("handlers", {})
    if not isinstance(raw_handlers, dict):
        raise ValueError("'handlers' must be a mapping of task_name -> handler config")

    for task_name, handler_raw in raw_handlers.items():
        if isinstance(handler_raw, str):
            # Short form: just a command string
            handlers[task_name] = HandlerConfig(cmd=handler_raw)
        elif isinstance(handler_raw, dict):
            cmd = handler_raw.get("cmd")
            if not cmd:
                raise ValueError(f"Handler '{task_name}' must have a 'cmd' field")
            handlers[task_name] = HandlerConfig(
                cmd=cmd,
                cwd=handler_raw.get("cwd"),
                timeout=handler_raw.get("timeout", 300),
                env=handler_raw.get("env"),
            )
        else:
            raise ValueError(f"Handler '{task_name}' must be a string or mapping")

    if not handlers:
        raise ValueError("At least one handler must be defined")

    # Build config
    worker_id = raw.get("worker_id") or _default_worker_id()

    return WorkerConfig(
        api_key=api_key,
        api_base=raw.get("api_base", "https://api.cueapi.ai"),
        worker_id=worker_id,
        poll_interval=raw.get("poll_interval", 5),
        heartbeat_interval=raw.get("heartbeat_interval", 30),
        max_concurrent=raw.get("max_concurrent", 4),
        handlers=handlers,
    )
