"""Heartbeat thread — sends periodic heartbeat to CueAPI server."""
from __future__ import annotations

import logging
import threading
from typing import List, Optional

import os
import signal

from cueapi_worker.client import AuthenticationError, WorkerAPIClient

logger = logging.getLogger(__name__)


class HeartbeatThread:
    """Daemon thread that sends heartbeat at regular intervals.

    Keeps the worker registered with the server so stale-recovery
    logic doesn't reclaim its claimed executions.
    """

    def __init__(
        self,
        client: WorkerAPIClient,
        worker_id: str,
        handlers: Optional[List[str]] = None,
        interval: int = 30,
    ):
        self._client = client
        self._worker_id = worker_id
        self._handlers = handlers
        self._interval = interval
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None

    def start(self) -> None:
        """Start the heartbeat thread."""
        if self._thread and self._thread.is_alive():
            return

        self._stop_event.clear()
        self._thread = threading.Thread(
            target=self._run,
            name="cueapi-heartbeat",
            daemon=True,
        )
        self._thread.start()
        logger.info("Heartbeat thread started (interval=%ds)", self._interval)

    def stop(self) -> None:
        """Signal the heartbeat thread to stop."""
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=5)
            logger.info("Heartbeat thread stopped")

    def _run(self) -> None:
        """Heartbeat loop — send immediately, then every interval seconds."""
        # Send first heartbeat immediately
        self._send()

        while not self._stop_event.wait(timeout=self._interval):
            self._send()

    def _send(self) -> None:
        """Send a single heartbeat."""
        try:
            ok = self._client.heartbeat(self._worker_id, self._handlers)
            if ok:
                logger.debug("Heartbeat sent for worker=%s", self._worker_id)
            else:
                logger.warning("Heartbeat failed for worker=%s", self._worker_id)
        except AuthenticationError as e:
            logger.critical(str(e))
            # Signal the main process to exit — heartbeat runs in a daemon thread
            # so we send SIGTERM to the main process to trigger graceful shutdown
            self._stop_event.set()
            os.kill(os.getpid(), signal.SIGTERM)
