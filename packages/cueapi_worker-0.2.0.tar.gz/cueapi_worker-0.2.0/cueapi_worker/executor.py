"""Task handler executor — runs shell commands for matched tasks."""
from __future__ import annotations

import logging
import os
import re
import subprocess
from typing import Any, Dict, Optional, Tuple

from cueapi_worker.config import HandlerConfig

logger = logging.getLogger(__name__)

# Max bytes to capture from stdout/stderr
MAX_OUTPUT_BYTES = 4096


def resolve_template(template: str, payload: Dict[str, Any]) -> str:
    """Replace {{ payload.field }} placeholders with values from payload.

    Supports nested access via dot notation: {{ payload.context.url }}
    Missing keys resolve to empty string.

    Args:
        template: String with {{ payload.field }} placeholders.
        payload: Payload dict to resolve values from.

    Returns:
        Template with placeholders replaced.
    """

    def _replace(match: re.Match) -> str:
        path = match.group(1).strip()
        # Remove leading "payload." if present
        if path.startswith("payload."):
            path = path[len("payload."):]

        # Walk the nested dict
        value: Any = payload
        for part in path.split("."):
            if isinstance(value, dict):
                value = value.get(part)
            else:
                return ""
            if value is None:
                return ""
        return str(value)

    return re.sub(r"\{\{\s*(.*?)\s*\}\}", _replace, template)


def execute_handler(
    handler: HandlerConfig,
    payload: Dict[str, Any],
    execution_id: str,
    cue_id: str,
    cue_name: str,
    worker_id: str,
) -> Tuple[bool, str]:
    """Execute a handler command as a subprocess.

    Builds environment with:
    - Built-in CUEAPI_* variables (execution_id, cue_id, cue_name, worker_id)
    - Handler-specific env vars with template resolution
    - Inherits current process env

    Args:
        handler: Handler configuration with cmd, cwd, timeout, env.
        payload: Execution payload dict.
        execution_id: ID of the execution being processed.
        cue_id: ID of the parent cue.
        cue_name: Name of the parent cue.
        worker_id: ID of this worker.

    Returns:
        Tuple of (success: bool, output: str).
        Output is truncated to 4KB.
    """
    # Build environment: inherit current + add CUEAPI_* + handler env
    env = os.environ.copy()

    # Built-in variables
    env["CUEAPI_EXECUTION_ID"] = execution_id
    env["CUEAPI_CUE_ID"] = cue_id
    env["CUEAPI_CUE_NAME"] = cue_name
    env["CUEAPI_WORKER_ID"] = worker_id

    # Add payload as JSON string
    import json

    env["CUEAPI_PAYLOAD"] = json.dumps(payload or {})

    # Handler-specific env vars with template resolution
    if handler.env:
        for key, value in handler.env.items():
            env[key] = resolve_template(str(value), payload or {})

    # Resolve command template
    cmd = resolve_template(handler.cmd, payload or {})

    # Working directory
    cwd = handler.cwd
    if cwd:
        cwd = os.path.expanduser(cwd)

    logger.info(
        "Executing handler: cmd=%s, cwd=%s, timeout=%d, execution_id=%s",
        cmd,
        cwd,
        handler.timeout,
        execution_id,
    )

    try:
        result = subprocess.run(
            cmd,
            shell=True,
            cwd=cwd,
            env=env,
            capture_output=True,
            text=True,
            timeout=handler.timeout,
        )

        # Combine stdout + stderr, truncate to 4KB
        output = ""
        if result.stdout:
            output += result.stdout
        if result.stderr:
            if output:
                output += "\n--- stderr ---\n"
            output += result.stderr
        output = output[:MAX_OUTPUT_BYTES]

        success = result.returncode == 0

        if success:
            logger.info("Handler succeeded: execution_id=%s, returncode=0", execution_id)
        else:
            logger.warning(
                "Handler failed: execution_id=%s, returncode=%d",
                execution_id,
                result.returncode,
            )

        return success, output

    except subprocess.TimeoutExpired:
        msg = f"Handler timed out after {handler.timeout}s"
        logger.error("%s: execution_id=%s", msg, execution_id)
        return False, msg

    except Exception as e:
        msg = f"Handler execution error: {e}"
        logger.error("%s: execution_id=%s", msg, execution_id)
        return False, msg
