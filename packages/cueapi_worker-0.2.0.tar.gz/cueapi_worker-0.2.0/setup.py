"""Fallback setup.py for Python 3.9 editable installs."""
from setuptools import setup

setup()
