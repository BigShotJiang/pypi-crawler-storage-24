"""Tests for cueapi_worker.executor — 7 tests."""
from __future__ import annotations

import os

import pytest

from cueapi_worker.config import HandlerConfig
from cueapi_worker.executor import resolve_template, execute_handler


# ── resolve_template tests ───────────────────────────────────────


def test_resolve_template_simple():
    """Test simple {{ payload.field }} replacement."""
    result = resolve_template(
        "Hello {{ payload.name }}, your task is {{ payload.task }}",
        {"name": "Alice", "task": "backup"},
    )
    assert result == "Hello Alice, your task is backup"


def test_resolve_template_nested():
    """Test nested {{ payload.context.url }} replacement."""
    result = resolve_template(
        "Fetch from {{ payload.context.url }}",
        {"context": {"url": "https://example.com"}},
    )
    assert result == "Fetch from https://example.com"


def test_resolve_template_missing_key():
    """Test missing key resolves to empty string."""
    result = resolve_template(
        "Value: {{ payload.missing }}!",
        {"name": "test"},
    )
    assert result == "Value: !"


# ── execute_handler tests ────────────────────────────────────────


def test_handler_success():
    """Test successful handler execution."""
    handler = HandlerConfig(cmd="echo 'hello world'", timeout=10)
    success, output = execute_handler(
        handler=handler,
        payload={"task": "test"},
        execution_id="exec-1",
        cue_id="cue-1",
        cue_name="test-cue",
        worker_id="worker-1",
    )
    assert success is True
    assert "hello world" in output


def test_handler_failure():
    """Test failed handler (non-zero exit code)."""
    handler = HandlerConfig(cmd="exit 1", timeout=10)
    success, output = execute_handler(
        handler=handler,
        payload={},
        execution_id="exec-2",
        cue_id="cue-2",
        cue_name="fail-cue",
        worker_id="worker-1",
    )
    assert success is False


def test_handler_timeout():
    """Test handler timeout."""
    handler = HandlerConfig(cmd="sleep 10", timeout=1)
    success, output = execute_handler(
        handler=handler,
        payload={},
        execution_id="exec-3",
        cue_id="cue-3",
        cue_name="slow-cue",
        worker_id="worker-1",
    )
    assert success is False
    assert "timed out" in output.lower()


def test_handler_env_with_template():
    """Test handler env vars with template resolution."""
    handler = HandlerConfig(
        cmd='echo "$MY_VAR"',
        timeout=10,
        env={"MY_VAR": "{{ payload.value }}"},
    )
    success, output = execute_handler(
        handler=handler,
        payload={"value": "injected_value"},
        execution_id="exec-4",
        cue_id="cue-4",
        cue_name="env-cue",
        worker_id="worker-1",
    )
    assert success is True
    assert "injected_value" in output
