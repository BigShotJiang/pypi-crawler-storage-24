"""Tests for cueapi_worker.cli — 3 tests."""
from __future__ import annotations

from click.testing import CliRunner

from cueapi_worker.cli import main


def test_version():
    """Test --version flag."""
    runner = CliRunner()
    result = runner.invoke(main, ["--version"])
    assert result.exit_code == 0
    assert "0.1.0" in result.output


def test_start_missing_config():
    """Test start command with non-existent config file."""
    runner = CliRunner()
    result = runner.invoke(main, ["start", "--config", "/nonexistent/config.yaml"])
    assert result.exit_code != 0


def test_help():
    """Test help output lists all commands."""
    runner = CliRunner()
    result = runner.invoke(main, ["--help"])
    assert result.exit_code == 0
    assert "start" in result.output
    assert "status" in result.output
    assert "install-service" in result.output
    assert "uninstall-service" in result.output
