"""Tests for cueapi_worker.daemon — 5 tests."""
from __future__ import annotations

from unittest import mock

import pytest

from cueapi_worker.config import HandlerConfig, WorkerConfig
from cueapi_worker.daemon import WorkerDaemon


def _make_config(**overrides) -> WorkerConfig:
    """Create a test WorkerConfig."""
    defaults = {
        "api_key": "cue_sk_test",
        "api_base": "http://localhost:8000",
        "worker_id": "test-worker",
        "poll_interval": 1,
        "heartbeat_interval": 30,
        "max_concurrent": 2,
        "handlers": {
            "backup": HandlerConfig(cmd="echo backup done", timeout=10),
            "report": HandlerConfig(cmd="echo report done", timeout=10),
        },
    }
    defaults.update(overrides)
    return WorkerConfig(**defaults)


def test_poll_cycle_claims_and_executes():
    """Test that poll cycle fetches, claims, and executes matching tasks."""
    config = _make_config()
    daemon = WorkerDaemon(config)

    # Mock the client
    daemon._client = mock.MagicMock()
    daemon._client.get_claimable.return_value = [
        {
            "execution_id": "exec-1",
            "cue_id": "cue-1",
            "cue_name": "my-backup",
            "task": "backup",
            "payload": {"task": "backup"},
        }
    ]
    daemon._client.claim.return_value = {"claimed": True, "execution_id": "exec-1", "lease_seconds": 900}

    # Run one poll cycle
    daemon._poll_cycle()

    # Verify claim was called
    daemon._client.claim.assert_called_once_with("exec-1", "test-worker")

    # Wait for the executor to finish
    for future in daemon._active_futures:
        future.result(timeout=10)

    # Verify outcome was reported
    daemon._client.report_outcome.assert_called_once()
    call_kwargs = daemon._client.report_outcome.call_args
    assert call_kwargs.kwargs.get("execution_id") == "exec-1" or call_kwargs[1].get("execution_id") == "exec-1"


def test_poll_cycle_skips_unknown_task():
    """Test that poll cycle skips executions with no matching handler."""
    config = _make_config()
    daemon = WorkerDaemon(config)

    daemon._client = mock.MagicMock()
    daemon._client.get_claimable.return_value = [
        {
            "execution_id": "exec-1",
            "cue_id": "cue-1",
            "cue_name": "unknown-cue",
            "task": "unknown_task",
            "payload": {"task": "unknown_task"},
        }
    ]

    daemon._poll_cycle()

    # Claim should NOT be called for unknown task
    daemon._client.claim.assert_not_called()


def test_poll_cycle_respects_max_concurrent():
    """Test that poll cycle stops claiming when at max_concurrent."""
    config = _make_config(max_concurrent=1)
    daemon = WorkerDaemon(config)

    # Simulate one active future
    future = mock.MagicMock()
    future.done.return_value = False
    daemon._active_futures.add(future)

    daemon._client = mock.MagicMock()

    daemon._poll_cycle()

    # Should not even call get_claimable
    daemon._client.get_claimable.assert_not_called()


def test_poll_cycle_reports_failure():
    """Test that handler failure gets reported as failed outcome."""
    config = _make_config(
        handlers={"fail_task": HandlerConfig(cmd="exit 1", timeout=10)}
    )
    daemon = WorkerDaemon(config)

    daemon._client = mock.MagicMock()
    daemon._client.get_claimable.return_value = [
        {
            "execution_id": "exec-fail",
            "cue_id": "cue-1",
            "cue_name": "fail-cue",
            "task": "fail_task",
            "payload": {"task": "fail_task"},
        }
    ]
    daemon._client.claim.return_value = {"claimed": True, "execution_id": "exec-fail", "lease_seconds": 900}

    daemon._poll_cycle()

    # Wait for the executor to finish
    for future in daemon._active_futures:
        future.result(timeout=10)

    # Verify failure was reported
    daemon._client.report_outcome.assert_called_once()
    call_args = daemon._client.report_outcome.call_args
    # Check that success=False was passed
    assert call_args.kwargs.get("success") is False or (len(call_args.args) > 1 and call_args.args[1] is False)


def test_poll_cycle_handles_claim_failure():
    """Test that claim failure (409) is handled gracefully."""
    config = _make_config()
    daemon = WorkerDaemon(config)

    daemon._client = mock.MagicMock()
    daemon._client.get_claimable.return_value = [
        {
            "execution_id": "exec-race",
            "cue_id": "cue-1",
            "cue_name": "race-cue",
            "task": "backup",
            "payload": {"task": "backup"},
        }
    ]
    daemon._client.claim.return_value = None  # Claim failed (409)

    daemon._poll_cycle()

    # Claim was attempted but no execution should be submitted
    daemon._client.claim.assert_called_once()
    assert len(daemon._active_futures) == 0
