"""Tests for worker 401 detection and 429 handling (Fix 1)."""
from __future__ import annotations

import time
from unittest.mock import patch, MagicMock

import pytest
import httpx

from cueapi_worker.client import AuthenticationError, WorkerAPIClient


def _mock_response(status_code, json_data=None, headers=None):
    """Create a mock httpx.Response."""
    resp = MagicMock(spec=httpx.Response)
    resp.status_code = status_code
    resp.headers = headers or {}
    resp.text = str(json_data)
    if json_data:
        resp.json.return_value = json_data
    else:
        resp.json.side_effect = Exception("No JSON")
    return resp


class TestWorker401Detection:
    """Worker should raise AuthenticationError on 401 from any API call."""

    def setup_method(self):
        self.client = WorkerAPIClient(api_key="cue_sk_test", api_base="https://api.test.com")

    def test_worker_exits_on_401_during_poll(self):
        """401 during get_claimable should raise AuthenticationError."""
        with patch("httpx.get") as mock_get:
            mock_get.return_value = _mock_response(
                401,
                {"error": {"code": "invalid_api_key", "message": "Invalid API key", "status": 401}},
            )
            with pytest.raises(AuthenticationError) as exc_info:
                self.client.get_claimable()
            assert "AUTH FAILURE" in str(exc_info.value)
            assert exc_info.value.error_code == "invalid_api_key"

    def test_worker_exits_on_401_during_claim(self):
        """401 during claim should raise AuthenticationError."""
        with patch("httpx.post") as mock_post:
            mock_post.return_value = _mock_response(
                401,
                {"error": {"code": "invalid_api_key", "message": "Invalid", "status": 401}},
            )
            with pytest.raises(AuthenticationError):
                self.client.claim("exec_123", "worker_1")

    def test_worker_exits_on_401_during_heartbeat(self):
        """401 during heartbeat should raise AuthenticationError."""
        with patch("httpx.post") as mock_post:
            mock_post.return_value = _mock_response(
                401,
                {"error": {"code": "invalid_api_key", "message": "Invalid", "status": 401}},
            )
            with pytest.raises(AuthenticationError):
                self.client.heartbeat("worker_1")

    def test_worker_exits_on_401_during_outcome(self):
        """401 during report_outcome should raise AuthenticationError."""
        with patch("httpx.post") as mock_post:
            mock_post.return_value = _mock_response(
                401,
                {"error": {"code": "invalid_api_key", "message": "Invalid", "status": 401}},
            )
            with pytest.raises(AuthenticationError):
                self.client.report_outcome("exec_123", success=True, result="done")

    def test_worker_detects_key_rotated_code(self):
        """401 with key_rotated code should be detected."""
        with patch("httpx.get") as mock_get:
            mock_get.return_value = _mock_response(
                401,
                {"error": {"code": "key_rotated", "message": "This API key has been rotated.", "status": 401}},
            )
            with pytest.raises(AuthenticationError) as exc_info:
                self.client.get_claimable()
            assert exc_info.value.error_code == "key_rotated"
            assert "rotated" in str(exc_info.value).lower()


class TestWorker429Handling:
    """Worker should sleep on 429 (rate limited) rather than crashing."""

    def setup_method(self):
        self.client = WorkerAPIClient(api_key="cue_sk_test", api_base="https://api.test.com")

    def test_worker_sleeps_on_429(self):
        """429 should cause sleep then return None/empty."""
        with patch("httpx.get") as mock_get, patch("time.sleep") as mock_sleep:
            mock_get.return_value = _mock_response(
                429,
                {"error": {"code": "rate_limit_exceeded"}},
                headers={"Retry-After": "5"},
            )
            result = self.client.get_claimable()
            assert result == []
            mock_sleep.assert_called_once_with(5)

    def test_429_claim_returns_none(self):
        """429 on claim should return None after sleeping."""
        with patch("httpx.post") as mock_post, patch("time.sleep") as mock_sleep:
            mock_post.return_value = _mock_response(
                429,
                {},
                headers={"Retry-After": "10"},
            )
            result = self.client.claim("exec_123", "worker_1")
            assert result is None
            mock_sleep.assert_called_once_with(10)
