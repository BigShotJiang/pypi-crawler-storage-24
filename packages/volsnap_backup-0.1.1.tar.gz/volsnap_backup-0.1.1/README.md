# volsnap-backup

Back up snapshots of LVM volumes.
