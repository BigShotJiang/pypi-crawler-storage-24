import argparse
import datetime
import json
import logging
import pathlib

from .b2 import B2BackupBucket
from .compress import zstd_compress_stream
from .config import Config, RawLVJob
from .gpg import encrypt_stream
from .lvm import get_lv_stream, lvm_snapshot
from .protocol import BackupBucket

logger = logging.getLogger(__name__)


def back_up_volume(bucket: BackupBucket, job: RawLVJob, file_name: str):
    if type(job) is RawLVJob:
        logger.info(
            "Backing up %s/%s as %s/%s",
            job.vg,
            job.lv,
            bucket.bucket_name,
            file_name,
        )

        with lvm_snapshot(job.vg, job.lv, job.snapshot_size) as snapshot_name:  # noqa: SIM117
            with get_lv_stream(job.vg, snapshot_name) as stream:
                with zstd_compress_stream(stream) as compressed_stream:
                    with encrypt_stream(
                        compressed_stream, job.gpg_key_id
                    ) as encrypted_stream:
                        bucket.upload_stream(file_name, encrypted_stream)
    else:
        raise NotImplementedError("Only raw LV backup jobs are supported")


def run_backup(
    config: Config,
    bucket: BackupBucket,
    now: datetime.datetime,
    back_up_volume=back_up_volume,
) -> None:
    for name, job in config.jobs.items():
        extension = {RawLVJob: "raw"}[type(job)]

        file_names = {
            f: f"{name}-{f}.{extension}.zst.gpg" for f in ("daily", "monthly", "yearly")
        }

        if "daily" in job.frequency:
            threshold = now.replace(hour=0, minute=0, second=0, microsecond=0)
            file_name = file_names["daily"]
            if bucket.get_latest_backup(file_name, threshold) is None:
                back_up_volume(bucket, job, file_name)

        if "monthly" in job.frequency:
            threshold = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
            file_name = file_names["monthly"]

            if bucket.get_latest_backup(file_name, threshold) is None:
                copy_from = bucket.get_latest_backup(file_names["daily"], threshold)

                if copy_from is not None:
                    bucket.copy_file(copy_from["id"], file_name)
                else:
                    back_up_volume(bucket, job, file_name)

        if "yearly" in job.frequency:
            threshold = now.replace(
                month=1, day=1, hour=0, minute=0, second=0, microsecond=0
            )
            file_name = file_names["yearly"]

            if bucket.get_latest_backup(file_name, threshold) is None:
                copy_from = bucket.get_latest_backup(file_names["daily"], threshold)
                if copy_from is None:
                    copy_from = bucket.get_latest_backup(
                        file_names["monthly"], threshold
                    )

                if copy_from is not None:
                    bucket.copy_file(copy_from["id"], file_name)
                else:
                    back_up_volume(bucket, job, file_name)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--log-level",
        type=str.upper,
        choices=("DEBUG", "INFO", "WARNING", "ERROR"),
        default="INFO",
    )
    parser.add_argument(
        "--config-file",
        type=pathlib.Path,
        default=pathlib.Path("lv-backup-config.json"),
    )

    parser.add_argument("command", choices=("run",))

    args = parser.parse_args()

    logging.basicConfig(level=args.log_level)

    with open(args.config_file) as f:
        config = Config(json.load(f))

    bucket = B2BackupBucket(
        config.destination.bucket,
        application_key_id=config.destination.application_key_id,
        application_key=config.destination.application_key,
    )

    now = datetime.datetime.now(datetime.UTC)

    if args.command == "run":
        run_backup(config, bucket, now)
