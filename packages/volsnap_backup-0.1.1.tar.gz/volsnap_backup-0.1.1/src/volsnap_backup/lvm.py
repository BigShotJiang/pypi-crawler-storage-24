import contextlib
import logging
import subprocess

logger = logging.getLogger(__name__)


@contextlib.contextmanager
def lvm_snapshot(vg: str, lv: str, size: str):
    logger.debug("Snapshotting %s/%s", vg, lv)
    snapshot_name = f"{lv}_snapshot"
    subprocess.run(
        ["lvcreate", f"-L{size}", "-n", snapshot_name, "-s", f"{vg}/{lv}"], check=True
    )
    logger.debug("Snapshot %s/%s created successfully", vg, snapshot_name)

    try:
        yield snapshot_name
    finally:
        logger.debug("Releasing snapshot %s/%s", vg, snapshot_name)
        subprocess.run(["lvremove", "-y", f"{vg}/{snapshot_name}"], check=True)


@contextlib.contextmanager
def get_lv_stream(vg: str, lv: str):
    with open(f"/dev/{vg}/{lv}", "rb") as f:
        yield f
