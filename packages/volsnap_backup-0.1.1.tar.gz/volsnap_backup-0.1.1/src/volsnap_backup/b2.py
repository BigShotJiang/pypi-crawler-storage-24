import datetime
import logging
import pathlib
import typing

from b2sdk.v2 import B2Api, InMemoryAccountInfo
from b2sdk.v2.exception import FileNotPresent

logger = logging.getLogger(__name__)


class B2BackupBucket:
    def __init__(
        self,
        bucket_name: str,
        application_key_id: str,
        application_key: str,
        folder: str = "",
    ) -> None:
        logger.debug("Logging into storage provider")

        b2_api = B2Api(InMemoryAccountInfo())
        b2_api.authorize_account("production", application_key_id, application_key)

        self.bucket = b2_api.get_bucket_by_name(bucket_name)
        self.folder = folder
        self.bucket_name = bucket_name

    def get_latest_backup(self, name: str, threshold: datetime.datetime) -> dict | None:
        try:
            o = self.bucket.get_file_info_by_name(name)
        except FileNotPresent:
            return None

        timestamp = datetime.datetime.fromtimestamp(
            o.upload_timestamp / 1000, tz=datetime.UTC
        )
        if timestamp >= threshold:
            return {"timestamp": timestamp, "size": o.size, "id": o.id_}

        return None

    def upload_stream(self, name: str, stream: typing.BinaryIO) -> None:
        file_path = str(pathlib.Path(self.folder).joinpath(name))
        logger.debug("Uploading %s/%s", self.bucket.name, file_path)
        self.bucket.upload_unbound_stream(stream, file_path)

    def copy_file(self, from_id: str, to_name: str) -> None:
        file_path = str(pathlib.Path(self.folder).joinpath(to_name))
        logger.debug(
            "Copying %s/%s to %s/%s",
            self.bucket.name,
            from_id,
            self.bucket.name,
            file_path,
        )
        self.bucket.copy(from_id, file_path)
