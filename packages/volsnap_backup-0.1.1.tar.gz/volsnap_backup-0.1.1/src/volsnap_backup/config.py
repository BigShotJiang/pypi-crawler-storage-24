class B2Destination:
    def __init__(self, config: dict) -> None:
        self.bucket = config["bucket"]
        self.application_key_id = config["application_key_id"]
        if "application_key_file" in config:
            with open(config["application_key_file"]) as f:
                self.application_key = f.read().rstrip()
        elif "application_key" in config:
            self.application_key = config["application_key"]


class RawLVJob:
    def __init__(self, config: dict, defaults: dict) -> None:
        self.vg = config["vg"]
        self.lv = config["lv"]
        self.snapshot_size = config["snapshot_size"]
        self.frequency = set(config["frequency"])
        try:
            self.gpg_key_id = config["gpg_key_id"]
        except KeyError:
            self.gpg_key_id = defaults["gpg_key_id"]


class Config:
    def __init__(self, config: dict):
        if config["destination"]["type"] == "b2":
            self.destination = B2Destination(config["destination"])
        else:
            raise NotImplementedError("B2 is the only supported destination")

        self.jobs = {}

        job_defaults = {
            "gpg_key_id": config["gpg_key_id"],
        }
        for name, job in config.get("jobs", {}).items():
            if job["type"] == "raw-lv":
                self.jobs[name] = RawLVJob(job, job_defaults)
            else:
                raise NotImplementedError("Only raw-lv job type is supported")
