import contextlib
import subprocess
import typing


@contextlib.contextmanager
def zstd_compress_stream(stream: typing.BinaryIO):
    with subprocess.Popen(
        ["zstd", "-c", "-10", "-T0"], stdin=stream, stdout=subprocess.PIPE
    ) as proc:
        yield proc.stdout

    if proc.returncode != 0:
        raise RuntimeError(
            f"Failed to compress stream (zstd exit code: {proc.returncode})"
        )
