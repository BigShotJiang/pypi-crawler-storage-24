import datetime
from typing import BinaryIO, Protocol


class BackupBucket(Protocol):
    bucket_name: str

    def __init__(
        self,
        bucket_name: str,
        application_key_id: str,
        application_key: str,
        folder: str = "",
    ) -> None: ...
    def upload_stream(self, name: str, stream: BinaryIO) -> None: ...
    def copy_file(self, id_: str, name: str) -> None: ...
    def get_latest_backup(
        self, name: str, threshold: datetime.datetime
    ) -> dict | None: ...
