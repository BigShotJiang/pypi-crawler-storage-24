import contextlib
import io
import logging
import subprocess

logger = logging.getLogger(__name__)


@contextlib.contextmanager
def encrypt_stream(stream: io.BytesIO, recipient: str):
    cmd = ["gpg", "--encrypt", "--recipient", recipient, "--output", "-"]
    logger.debug("Executing %s", " ".join(cmd))
    with subprocess.Popen(cmd, stdin=stream, stdout=subprocess.PIPE) as proc:
        yield proc.stdout

    if proc.returncode != 0:
        raise RuntimeError(
            f"Failed to get GPG-encrypted stream (exit code: {proc.returncode})"
        )
