"""IR generation package."""
