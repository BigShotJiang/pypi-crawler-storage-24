"""Index pipeline package."""
