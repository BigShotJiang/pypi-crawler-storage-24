"""WZRD client.

Use WZRD as a momentum prior before execution routers, model calls,
or agent policy decisions.
"""

from .agent import (
    DEFAULT_API_BASE_URL,
    AgentChallenge,
    AgentSession,
    ClaimResult,
    WZRDAgent,
    agent_auth_message,
    load_keypair,
)
from .client import (
    DEFAULT_API_URL,
    FeedMeta,
    PickResult,
    Signal,
    WZRDError,
    WZRDClient,
    clear_cache,
    compare,
    pick,
    pick_details,
    shortlist,
)

from .router import WZRDRouter

__all__ = [
    "DEFAULT_API_BASE_URL",
    "DEFAULT_API_URL",
    "AgentChallenge",
    "AgentSession",
    "ClaimResult",
    "FeedMeta",
    "PickResult",
    "Signal",
    "WZRDAgent",
    "WZRDError",
    "WZRDClient",
    "WZRDRouter",
    "agent_auth_message",
    "clear_cache",
    "compare",
    "load_keypair",
    "pick",
    "pick_details",
    "shortlist",
]
