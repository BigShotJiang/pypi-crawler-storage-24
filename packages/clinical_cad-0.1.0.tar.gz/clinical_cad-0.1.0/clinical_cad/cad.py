#!/usr/bin/env python3
"""
Robust Clinical Association Displacement (CAD) analysis with statistical normalization.

Key improvements:
1. Variance-normalized displacement (z-scores) throughout for cross-model comparability
2. Statistically validated thresholds based on significance levels
3. Comprehensive lexical fairness metrics
4. Document length normalization

   python /home/adipa/version2_qwen/eval_scripts/add_patientsex_to_predictions.py \
     --pred-dir /scratch/adipa/qwen_vlm_runs/research_run_qwen3VL_v11_BB/miccai_results/baselines/llavarad_chexpert_val \
     --test-csv /scratch/adipa/chexpert-plus/chexpertchestxrays-u20210408/chexpert_v1/valid/valid.csv

Example usage (after pip install clinical-cad):
    cad --output_dir ./out --reference_csv ref.csv --prediction_csv pred.csv
    cad --output_dir ./demo_run --demo
"""
from __future__ import annotations
import argparse
import json
import re
from collections import Counter
from pathlib import Path
from typing import Any, Dict, List, Tuple, Optional
import math
import numpy as np
import pandas as pd
from scipy import stats
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import seaborn as sns
import random
from dataclasses import dataclass

# Default paths (None = user must provide unless --demo)
DEFAULT_REFERENCE_CSV = None
DEFAULT_PREDICTION_CSV = None

# ---------- Utilities ----------
def _path_or_none(s):
    return Path(s) if s else None

def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Clinical Association Displacement (CAD) and Weighted Association Error (WAE) analysis for lexical fairness in clinical text.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
        epilog="""
Examples:
  cad --output_dir ./results --reference_csv ref.csv --prediction_csv pred.csv
  cad --output_dir ./demo_run --demo
  cad --reference_csv ref.csv --prediction_csv pred.csv  # uses default output_dir=./cad_output
"""
    )
    # Input files
    inp = parser.add_argument_group("Input files")
    inp.add_argument("--reference_csv", type=_path_or_none, default=None, metavar="PATH",
                     help="Reference corpus CSV (ground-truth reports). Required unless --demo.")
    inp.add_argument("--prediction_csv", type=_path_or_none, default=None, metavar="PATH",
                     help="Prediction CSV (model-generated reports). Required unless --demo.")
    inp.add_argument("--output_dir", type=Path, default=Path("./cad_output"), metavar="DIR",
                     help="Directory for all output files (tables, plots, JSON).")
    inp.add_argument("--reference_text_column", type=str, default="findings",
                     help="Column name for reference text in reference CSV.")
    inp.add_argument("--prediction_text_column", type=str, default="predicted_report",
                     help="Column name for prediction text in prediction CSV.")
    inp.add_argument("--label_column", type=str, default="PatientSex",
                     help="Demographic label column (M/F). Auto-detects PatientSex, patient_sex, sex if present.")
    inp.add_argument("--reference_label_column", type=str, default=None,
                     help="Override label column for reference CSV only.")
    inp.add_argument("--prediction_label_column", type=str, default=None,
                     help="Override label column for prediction CSV only.")

    # CAD / association parameters
    cad = parser.add_argument_group("CAD & association parameters")
    cad.add_argument("--min_freq", type=int, default=1,
                     help="Minimum token frequency to include in analysis.")
    cad.add_argument("--alpha", type=float, default=0.1,
                     help="Dirichlet smoothing for log-odds estimation.")
    cad.add_argument("--significance_level", type=float, default=0.0455,
                     help="P-value for strong association boundary (two-tailed).")
    cad.add_argument("--neutral_significance", type=float, default=0.317,
                     help="P-value for neutral association boundary (wider = more words considered neutral).")
    cad.add_argument("--displacement_significance", type=float, default=0.01,
                     help="P-value for displacement significance; z threshold derived from this.")
    cad.add_argument("--displacement_threshold_z", type=float, default=None, metavar="Z",
                     help="Override z threshold for displacement (if set, ignores displacement_significance).")
    cad.add_argument("--min_abs_log_odds", type=float, default=0,
                     help="Minimum |log-odds| to consider an association non-neutral.")
    cad.add_argument("--top_k", type=int, default=50,
                     help="Top-k terms to report in summaries.")

    # WAE parameters
    wae = parser.add_argument_group("WAE (Weighted Association Error) parameters")
    wae.add_argument("--wae_weight", type=str, default="total", choices=["total", "ref", "pred"],
                     help="Weight source for WAE: total=ref+pred, ref=reference counts, pred=prediction counts.")
    wae.add_argument("--bootstrap_samples", type=int, default=1000,
                     help="Number of bootstrap samples for WAE confidence intervals.")

    # Tokenization & filtering
    tok = parser.add_argument_group("Tokenization & filtering")
    tok.add_argument("--stopwords_path", type=_path_or_none, default=None, metavar="PATH",
                     help="Optional file with extra stopwords (one per line). Built-in list used if not set.")
    tok.add_argument("--no_stopword_removal", action='store_true',
                     help="Disable stopword removal.")
    tok.add_argument("--include_bigrams", action='store_true',
                     help="Include bigrams in vocabulary.")
    tok.add_argument("--vocab_path", type=_path_or_none, default=None, metavar="PATH",
                     help="Restrict vocabulary to words in this file (one per line).")
    tok.add_argument("--chunksize", type=int, default=100000,
                     help="Chunk size for streaming large CSVs.")

    # Sweep plots (displacement threshold sensitivity)
    sweep = parser.add_argument_group("Sweep plot parameters")
    sweep.add_argument("--sweep_disp_start", type=float, default=0)
    sweep.add_argument("--sweep_disp_stop", type=float, default=3)
    sweep.add_argument("--sweep_disp_step", type=float, default=0.1)
    sweep.add_argument("--sweep_p_start", type=float, default=0.001)
    sweep.add_argument("--sweep_p_stop", type=float, default=1)
    sweep.add_argument("--sweep_p_step", type=float, default=0.05)

    # Diversity metrics (optional)
    div = parser.add_argument_group("Diversity metrics (optional)")
    div.add_argument("--diversity_sample_size", type=int, default=2000)
    div.add_argument("--diversity_truncate_words", type=int, default=150)
    div.add_argument("--diversity_self_bleu_samples", type=int, default=500)
    div.add_argument("--diversity_random_seed", type=int, default=0)
    div.add_argument("--diversity_semantic_backend", type=str, default="auto",
                     choices=["auto", "sentence_transformers", "tfidf"])

    # Misc
    parser.add_argument("--demo", action='store_true',
                        help="Run on built-in demo data (no reference/prediction CSV needed).")

    return parser.parse_args()

def load_vocab(path: Path) -> set:
    if path is None: return set()
    with open(path, "r", encoding="utf-8") as f:
        return {line.strip().lower() for line in f if line.strip()}

BASE_STOPWORDS = {
    "a","an","the","and","or","but","if","while","of","in","on","for","with",
    "to","from","by","as","at","is","are","was","were","be","been","being",
    "this","that","these","those","it","its","their","there","here","then",
    "than","so","such","not","no","nor","do","does","did","doing","can","could",
    "would","should","may","might","will","shall","have","has","had","having",
    "we","you","he","she","they","them","his","her","our","ours","your","yours",
    "i","me","my","mine","us"
}

def load_stopwords(path: Optional[Path]) -> set:
    """Load stopwords, merging the built-in list with optional custom list."""
    stop = set(BASE_STOPWORDS)
    if path and path.exists():
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                w = line.strip().lower()
                if w:
                    stop.add(w)
    return stop

def tokenize(text: str, include_bigrams: bool=False, stopwords: Optional[set]=None) -> List[str]:
    if pd.isna(text) or text == "": return []
    words = re.findall(r"[a-z0-9]+", str(text).lower())
    if stopwords:
        words = [w for w in words if w not in stopwords]
    tokens = words.copy()
    if include_bigrams and len(words) > 1:
        tokens += [f"{words[i]}_{words[i+1]}" for i in range(len(words)-1)]
    return tokens

def find_sex_column(df_columns: pd.Index, preferred_name: str = None) -> str:
    """Find the sex/PatientSex column."""
    if preferred_name and preferred_name in df_columns:
        return preferred_name
    
    variations = ["PatientSex", "patient_sex", "Patient_sex", "patientSex", "sex"]
    for var in variations:
        if var in df_columns:
            return var
    
    df_cols_lower = [col.lower() for col in df_columns]
    if preferred_name:
        preferred_lower = preferred_name.lower()
        if preferred_lower in df_cols_lower:
            idx = df_cols_lower.index(preferred_lower)
            return df_columns[idx]
    
    for var in variations:
        var_lower = var.lower()
        if var_lower in df_cols_lower:
            idx = df_cols_lower.index(var_lower)
            return df_columns[idx]
    
    raise ValueError(f"Could not find sex column. Available: {list(df_columns)}")

def stream_count_tokens(path: Path, text_col: str, label_col: str, 
                       include_bigrams: bool=False, chunksize: int=100000,
                       stopwords: Optional[set]=None):
    """Stream and count tokens with document-level statistics."""
    female = Counter()
    male = Counter()
    total_docs = 0
    total_tokens_f = 0
    total_tokens_m = 0
    doc_lengths_f = []
    doc_lengths_m = []
    
    sample = pd.read_csv(path, nrows=1)
    actual_label_col = find_sex_column(sample.columns, label_col)
    if actual_label_col != label_col:
        print(f"  Using column '{actual_label_col}' instead of '{label_col}'")
    
    for chunk in pd.read_csv(path, usecols=[text_col, actual_label_col], 
                            chunksize=chunksize, dtype=str):
        chunk = chunk.dropna(subset=[text_col, actual_label_col])
        chunk[actual_label_col] = chunk[actual_label_col].str.strip().str.upper()
        chunk = chunk[chunk[actual_label_col].isin({"M","F"})]
        total_docs += len(chunk)
        
        for text, sex in zip(chunk[text_col], chunk[actual_label_col]):
            toks = tokenize(text, include_bigrams, stopwords)
            doc_len = len(toks)
            
            if sex == "M":
                male.update(toks)
                total_tokens_m += doc_len
                doc_lengths_m.append(doc_len)
            else:
                female.update(toks)
                total_tokens_f += doc_len
                doc_lengths_f.append(doc_len)
                
    return {
        'female_counter': female,
        'male_counter': male,
        'total_docs': total_docs,
        'total_tokens_f': total_tokens_f,
        'total_tokens_m': total_tokens_m,
        'doc_lengths_f': np.array(doc_lengths_f),
        'doc_lengths_m': np.array(doc_lengths_m)
    }

# ---------- Statistical computations ----------
def compute_log_odds_and_var(f_counter: Counter, m_counter: Counter, alpha: float, 
                            fixed_vocab_size: int = None) -> Tuple[Dict, Dict, int, int]:
    """Compute smoothed log-odds ratio with variance."""
    local_vocab = set(f_counter) | set(m_counter)
    V = fixed_vocab_size if fixed_vocab_size else len(local_vocab) or 1
    
    Nf = sum(f_counter.values())
    Nm = sum(m_counter.values())
    
    s_scores = {}
    variances = {}
    z_scores = {}
    
    for w in local_vocab:
        cf = f_counter.get(w, 0) + alpha
        cm = m_counter.get(w, 0) + alpha
        
        pf = cf / (Nf + alpha * V)
        pm = cm / (Nm + alpha * V)
        
        s = math.log(pf / pm)
        var = (1.0 / cf) + (1.0 / cm)
        z = s / math.sqrt(var) if var > 0 else 0.0
        
        s_scores[w] = float(s)
        variances[w] = float(var)
        z_scores[w] = float(z)
        
    return s_scores, variances, z_scores, Nf, Nm

def prior_log_odds_for_zero_count(Nf: int, Nm: int, alpha: float, V: int) -> Tuple[float, float, float]:
    """
    Return (s_prior, var_prior, z_prior) for a word with zero observed counts in BOTH groups,
    under Dirichlet smoothing with concentration `alpha` and vocabulary size `V`.

    For unseen w: cf = cm = alpha
      pf = alpha / (Nf + alpha * V)
      pm = alpha / (Nm + alpha * V)
      s = log(pf/pm) = log((Nm + alpha*V)/(Nf + alpha*V))
      var = 1/cf + 1/cm = 2/alpha
      z = s / sqrt(var)
    """
    V = max(int(V), 1)
    denom_f = float(Nf) + float(alpha) * float(V)
    denom_m = float(Nm) + float(alpha) * float(V)
    # denom_* should be > 0 for alpha>0 and V>=1; guard just in case
    if denom_f <= 0 or denom_m <= 0 or alpha <= 0:
        return 0.0, 1.0, 0.0
    s_prior = math.log(denom_m / denom_f)
    var_prior = 2.0 / float(alpha)
    z_prior = s_prior / math.sqrt(var_prior) if var_prior > 0 else 0.0
    return float(s_prior), float(var_prior), float(z_prior)

def bh_fdr(pvals: List[float]) -> List[float]:
    """Benjamini-Hochberg FDR correction."""
    n = len(pvals)
    if n == 0: return []
    idx = sorted(range(n), key=lambda i: pvals[i])
    sorted_p = [pvals[i] for i in idx]
    adj = [0.0]*n
    prev = 1.0
    for rank, p in enumerate(reversed(sorted_p), start=1):
        i = n - rank
        cur = min(prev, p * n / (i+1))
        prev = cur
        adj[i] = cur
    out = [0.0]*n
    for rank, i in enumerate(idx):
        out[i] = min(adj[rank], 1.0)
    return out

# ---------- Z-score based WAE (Normalized WAE) ----------
def compute_normalized_wae(data: pd.DataFrame, weight_source: str) -> float:
    """Compute Weighted Average of squared Z-scores (variance-normalized displacement)."""
    if weight_source == "ref":
        weights = data["ref_count"]
    elif weight_source == "pred":
        weights = data["pred_count"]
    else:
        weights = data["ref_count"] + data["pred_count"]
    
    z_displacement = data["z_displacement"]
    
    if weights.sum() == 0:
        return 0.0
    return float((weights * (z_displacement ** 2)).sum() / weights.sum())

def bootstrap_normalized_wae(data: pd.DataFrame, weight_source: str, 
                             n_bootstrap: int = 1000) -> dict:
    """Bootstrap confidence intervals for normalized WAE."""
    if weight_source == "ref":
        weights = data["ref_count"].to_numpy()
    elif weight_source == "pred":
        weights = data["pred_count"].to_numpy()
    else:
        weights = (data["ref_count"] + data["pred_count"]).to_numpy()
    
    z_disp = data["z_displacement"].to_numpy()
    
    if len(weights) == 0 or weights.sum() == 0:
        return {"mean": 0.0, "lower_ci": 0.0, "upper_ci": 0.0, "std_error": 0.0}

    n = len(z_disp)
    samples = []
    for _ in range(n_bootstrap):
        idx = np.random.randint(0, n, n)
        w = weights[idx]
        z = z_disp[idx]
        if w.sum() == 0:
            continue
        samples.append(float((w * (z ** 2)).sum() / w.sum()))
    
    if not samples:
        return {"mean": 0.0, "lower_ci": 0.0, "upper_ci": 0.0, "std_error": 0.0}

    samples = np.array(samples)
    lower = float(np.percentile(samples, 2.5))
    upper = float(np.percentile(samples, 97.5))
    return {
        "mean": float(samples.mean()),
        "lower_ci": lower,
        "upper_ci": upper,
        "std_error": float(samples.std(ddof=1) if len(samples) > 1 else 0.0),
    }

# ---------- Statistically validated categorization ----------
def _assoc_band(z: float, z_strong: float, z_neutral: float, min_abs_log_odds: float) -> str:
    """Return association band based on z thresholds and minimum log-odds magnitude."""
    abs_z = abs(z)
    if abs_z < z_neutral or abs(z) < min_abs_log_odds:
        return "neutral"
    if abs_z >= z_strong:
        return "strong"
    return "weak"

def categorize_word_statistical(z_ref: float, z_pred: float, z_displacement: float,
                                z_strong: float, z_neutral: float,
                                disp_threshold_z: float, min_abs_log_odds: float,
                                ref_count: int = 0, pred_count: int = 0) -> Tuple[str, str, str]:
    """
    Categorize words into 5 mutually exclusive categories:
    - no_displacement: below displacement threshold
    - preservation: association maintained with same polarity
    - erasure: strong association in reference drops to weak/neutral in prediction (same polarity)
    - new_bias: neutral in reference becomes non-neutral in prediction
    - bias_flip: non-neutral association flips polarity (includes strong→weak opposite)
    Returns (category, ref_band, pred_band)
    """
    ref_band = _assoc_band(z_ref, z_strong, z_neutral, min_abs_log_odds)
    pred_band = _assoc_band(z_pred, z_strong, z_neutral, min_abs_log_odds)
    ref_pol = int(np.sign(z_ref))
    pred_pol = int(np.sign(z_pred))

    # Special case: words that are strongly associated in reference and
    # completely absent in predictions are always considered "erasure",
    # regardless of the displacement z-threshold.
    if ref_band == "strong" and pred_count == 0:
        return "erasure", ref_band, pred_band

    displaced = abs(z_displacement) >= disp_threshold_z
    if not displaced:
        # Below displacement threshold
        return "no_displacement", ref_band, pred_band
    
    same_polarity = (ref_pol == pred_pol) or (ref_pol == 0 and pred_pol == 0)

    # 1. Bias Flip: non-neutral → non-neutral with opposite polarity (checked first; includes strong→weak opposite)
    if ref_band != "neutral" and pred_band != "neutral" and ref_pol != pred_pol:
        return "bias_flip", ref_band, pred_band

    # 2. New Bias: neutral in reference becomes non-neutral in prediction
    if ref_band == "neutral" and pred_band != "neutral" and pred_pol != 0:
        return "new_bias", ref_band, pred_band

    # 3. Erasure:
    #    strong in reference AND association drops to neutral/weak in prediction.
    #    (Complete disappearance case is handled above, without displacement check.)
    if ref_band == "strong" and pred_band in {"neutral", "weak"}:
        return "erasure", ref_band, pred_band

    # 4. Preservation: association maintained with same polarity
    if same_polarity:
        return "preservation", ref_band, pred_band

    # Default fallback (shouldn't happen, but handle edge cases)
    return "preservation", ref_band, pred_band

def sweep_categories_by_displacement(df: pd.DataFrame, z_strong: float, z_neutral: float,
                                     min_abs_log_odds: float, start: float, stop: float, step: float) -> pd.DataFrame:
    """Recount categories while sweeping displacement thresholds.

    Categories are already in the 5 mutually exclusive groups:
      - no_displacement
      - preservation
      - erasure
      - new_bias
      - bias_flip
    """
    thresholds = np.arange(start, stop + 1e-9, step)
    records = []
    for thr in thresholds:
        cats = df.apply(
            lambda r: categorize_word_statistical(
                r["z_ref"], r["z_pred"], r["z_displacement"],
                z_strong, z_neutral, thr, min_abs_log_odds,
                ref_count=int(r.get("ref_count", 0)),
                pred_count=int(r.get("pred_count", 0)),
            )[0],
            axis=1,
        )

        counts = cats.value_counts().to_dict()
        counts["threshold"] = thr
        records.append(counts)

    sweep_df = pd.DataFrame(records).fillna(0).sort_values("threshold")

    # Add percentage columns for each category (relative to total terms at that threshold)
    cat_cols = [c for c in ["no_displacement", "preservation", "erasure", "new_bias", "bias_flip"]
                if c in sweep_df.columns]
    if cat_cols:
        total = sweep_df[cat_cols].sum(axis=1).replace(0, np.nan)
        for c in cat_cols:
            sweep_df[f"{c}_pct"] = (sweep_df[c] / total * 100.0).fillna(0.0)

    return sweep_df

def sweep_categories_by_p(df: pd.DataFrame, z_strong: float, z_neutral: float,
                          min_abs_log_odds: float, p_start: float, p_stop: float, p_step: float) -> pd.DataFrame:
    """Recount categories while sweeping displacement significance (p-value) thresholds.

    For each p-threshold, we convert to an equivalent z-threshold and reuse the same categorization.
    Categories are already in the 5 mutually exclusive groups.
    """
    p_values = np.arange(p_start, p_stop + 1e-12, p_step)
    records = []
    for p_thr in p_values:
        # guard against edge cases
        p_thr = max(min(p_thr, 0.999999), 1e-12)
        z_thr = stats.norm.ppf(1 - p_thr / 2.0)
        cats = df.apply(
            lambda r: categorize_word_statistical(
                r["z_ref"], r["z_pred"], r["z_displacement"],
                z_strong, z_neutral, z_thr, min_abs_log_odds,
                ref_count=int(r.get("ref_count", 0)),
                pred_count=int(r.get("pred_count", 0)),
            )[0],
            axis=1,
        )
        counts = cats.value_counts().to_dict()
        counts["p_threshold"] = p_thr
        counts["z_equiv"] = float(z_thr)
        records.append(counts)

    sweep_p_df = pd.DataFrame(records).fillna(0).sort_values("p_threshold")

    # Add percentage columns for each category (relative to total terms at that p-threshold)
    cat_cols = [c for c in ["no_displacement", "preservation", "erasure", "new_bias", "bias_flip"]
                if c in sweep_p_df.columns]
    if cat_cols:
        total = sweep_p_df[cat_cols].sum(axis=1).replace(0, np.nan)
        for c in cat_cols:
            sweep_p_df[f"{c}_pct"] = (sweep_p_df[c] / total * 100.0).fillna(0.0)

    return sweep_p_df

# ---------- Lexical Fairness Metrics ----------
def compute_lexical_fairness(ref_stats: dict, pred_stats: dict, df: pd.DataFrame) -> dict:
    """Compute comprehensive lexical fairness metrics."""
    
    # Vocabulary statistics
    ref_vocab_f = set(ref_stats['female_counter'].keys())
    ref_vocab_m = set(ref_stats['male_counter'].keys())
    pred_vocab_f = set(pred_stats['female_counter'].keys())
    pred_vocab_m = set(pred_stats['male_counter'].keys())
    
    # Type-Token Ratios (vocabulary richness)
    ref_ttr_f = len(ref_vocab_f) / max(ref_stats['total_tokens_f'], 1)
    ref_ttr_m = len(ref_vocab_m) / max(ref_stats['total_tokens_m'], 1)
    pred_ttr_f = len(pred_vocab_f) / max(pred_stats['total_tokens_f'], 1)
    pred_ttr_m = len(pred_vocab_m) / max(pred_stats['total_tokens_m'], 1)
    
    # Document length statistics
    ref_avglen_f = ref_stats['doc_lengths_f'].mean() if len(ref_stats['doc_lengths_f']) > 0 else 0
    ref_avglen_m = ref_stats['doc_lengths_m'].mean() if len(ref_stats['doc_lengths_m']) > 0 else 0
    pred_avglen_f = pred_stats['doc_lengths_f'].mean() if len(pred_stats['doc_lengths_f']) > 0 else 0
    pred_avglen_m = pred_stats['doc_lengths_m'].mean() if len(pred_stats['doc_lengths_m']) > 0 else 0
    
    # Vocabulary overlap and divergence
    ref_vocab_overlap = len(ref_vocab_f & ref_vocab_m)
    pred_vocab_overlap = len(pred_vocab_f & pred_vocab_m)
    ref_vocab_union = len(ref_vocab_f | ref_vocab_m)
    pred_vocab_union = len(pred_vocab_f | pred_vocab_m)
    
    # Jaccard similarity between gender vocabularies
    ref_jaccard = ref_vocab_overlap / max(ref_vocab_union, 1)
    pred_jaccard = pred_vocab_overlap / max(pred_vocab_union, 1)
    
    # Distribution of associations (use statistically defined bands, not raw sign only)
    neutral_words_ref = df[df["ref_assoc_band"] == "neutral"]
    female_assoc_words_ref = df[(df["z_ref"] > 0) & (df["ref_assoc_band"] != "neutral")]
    male_assoc_words_ref = df[(df["z_ref"] < 0) & (df["ref_assoc_band"] != "neutral")]

    neutral_words_pred = df[df["pred_assoc_band"] == "neutral"]
    female_assoc_words_pred = df[(df["z_pred"] > 0) & (df["pred_assoc_band"] != "neutral")]
    male_assoc_words_pred = df[(df["z_pred"] < 0) & (df["pred_assoc_band"] != "neutral")]
    
    # Lexical parity: how balanced is vocabulary usage?
    ref_vocab_parity = min(len(ref_vocab_f), len(ref_vocab_m)) / max(len(ref_vocab_f), len(ref_vocab_m), 1)
    pred_vocab_parity = min(len(pred_vocab_f), len(pred_vocab_m)) / max(len(pred_vocab_f), len(pred_vocab_m), 1)
    
    # Token count parity
    ref_token_parity = min(ref_stats['total_tokens_f'], ref_stats['total_tokens_m']) / max(ref_stats['total_tokens_f'], ref_stats['total_tokens_m'], 1)
    pred_token_parity = min(pred_stats['total_tokens_f'], pred_stats['total_tokens_m']) / max(pred_stats['total_tokens_f'], pred_stats['total_tokens_m'], 1)
    
    return {
        "vocabulary_statistics": {
            "reference": {
                "unique_words_female": len(ref_vocab_f),
                "unique_words_male": len(ref_vocab_m),
                "unique_words_total": ref_vocab_union,
                "unique_words_overlap": ref_vocab_overlap,
                "total_tokens_female": int(ref_stats['total_tokens_f']),
                "total_tokens_male": int(ref_stats['total_tokens_m']),
                "type_token_ratio_female": float(ref_ttr_f),
                "type_token_ratio_male": float(ref_ttr_m),
                "avg_doc_length_female": float(ref_avglen_f),
                "avg_doc_length_male": float(ref_avglen_m),
            },
            "prediction": {
                "unique_words_female": len(pred_vocab_f),
                "unique_words_male": len(pred_vocab_m),
                "unique_words_total": pred_vocab_union,
                "unique_words_overlap": pred_vocab_overlap,
                "total_tokens_female": int(pred_stats['total_tokens_f']),
                "total_tokens_male": int(pred_stats['total_tokens_m']),
                "type_token_ratio_female": float(pred_ttr_f),
                "type_token_ratio_male": float(pred_ttr_m),
                "avg_doc_length_female": float(pred_avglen_f),
                "avg_doc_length_male": float(pred_avglen_m),
            }
        },
        "lexical_fairness_metrics": {
            "vocabulary_jaccard_similarity": {
                "reference": float(ref_jaccard),
                "prediction": float(pred_jaccard),
                "change": float(pred_jaccard - ref_jaccard)
            },
            "vocabulary_parity": {
                "reference": float(ref_vocab_parity),
                "prediction": float(pred_vocab_parity),
                "change": float(pred_vocab_parity - ref_vocab_parity)
            },
            "token_count_parity": {
                "reference": float(ref_token_parity),
                "prediction": float(pred_token_parity),
                "change": float(pred_token_parity - ref_token_parity)
            },
            "type_token_ratio_disparity": {
                "reference": float(abs(ref_ttr_f - ref_ttr_m)),
                "prediction": float(abs(pred_ttr_f - pred_ttr_m))
            }
        },
        "association_distribution": {
            "reference": {
                "female_associated_words": len(female_assoc_words_ref),
                "male_associated_words": len(male_assoc_words_ref),
                "neutral_words": len(neutral_words_ref),
                "female_mean_z": float(female_assoc_words_ref['z_ref'].mean() if len(female_assoc_words_ref) > 0 else 0),
                "male_mean_z": float(male_assoc_words_ref['z_ref'].mean() if len(male_assoc_words_ref) > 0 else 0),
                "neutral_mean_z": float(neutral_words_ref['z_ref'].mean() if len(neutral_words_ref) > 0 else 0),
            },
            "prediction": {
                "female_associated_words": len(female_assoc_words_pred),
                "male_associated_words": len(male_assoc_words_pred),
                "neutral_words": len(neutral_words_pred),
                "female_mean_z": float(female_assoc_words_pred['z_pred'].mean() if len(female_assoc_words_pred) > 0 else 0),
                "male_mean_z": float(male_assoc_words_pred['z_pred'].mean() if len(male_assoc_words_pred) > 0 else 0),
                "neutral_mean_z": float(neutral_words_pred['z_pred'].mean() if len(neutral_words_pred) > 0 else 0),
            }
        }
    }

def compute_repetitiveness(pred_csv: Path, text_col: str, label_col: str, chunksize: int = 100000) -> dict:
    """
    Analyze repetitiveness of model-generated reports.

    We treat each full report text as a ``template'' string and compute:
      - total number of prediction reports
      - number of unique reports
      - proportion of reports belonging to the top-k most frequent templates
      - per-sex statistics (if a valid sex column is available)
    """
    if not pred_csv.exists():
        return {}

    # Identify the actual sex column (if present)
    try:
        sample = pd.read_csv(pred_csv, nrows=1)
        actual_label_col = find_sex_column(sample.columns, label_col)
        has_sex = True
    except Exception:
        actual_label_col = None
        has_sex = False

    def _normalize_text(x: Any) -> str:
        if pd.isna(x):
            return ""
        # simple normalization: lowercase and strip whitespace
        return str(x).strip().lower()

    from collections import Counter
    global_counter = Counter()
    female_counter = Counter()
    male_counter = Counter()

    usecols = [text_col]
    if has_sex:
        usecols.append(actual_label_col)

    total_docs = 0
    for chunk in pd.read_csv(pred_csv, usecols=usecols, chunksize=chunksize, dtype=str):
        chunk = chunk.dropna(subset=[text_col])
        if has_sex:
            chunk[actual_label_col] = chunk[actual_label_col].str.strip().str.upper()
        for _, row in chunk.iterrows():
            text_norm = _normalize_text(row[text_col])
            if not text_norm:
                continue
            total_docs += 1
            global_counter[text_norm] += 1
            if has_sex:
                sex = row[actual_label_col]
                if sex == "F":
                    female_counter[text_norm] += 1
                elif sex == "M":
                    male_counter[text_norm] += 1

    if total_docs == 0 or not global_counter:
        return {}

    # global stats
    counts_global = np.array(sorted(global_counter.values(), reverse=True), dtype=float)
    total_global = counts_global.sum()
    def frac_global(k: int) -> float:
        k = min(k, len(counts_global))
        return float(counts_global[:k].sum() / total_global) if k > 0 else 0.0

    result = {
        "overall": {
            "total_reports": int(total_docs),
            "unique_reports": int(len(global_counter)),
            "unique_ratio": float(len(global_counter) / total_docs),
            "max_template_count": int(counts_global[0]),
            "max_template_fraction": float(counts_global[0] / total_docs),
            "frac_top_1": frac_global(1),
            "frac_top_5": frac_global(5),
            "frac_top_10": frac_global(10),
        }
    }

    if has_sex:
        if female_counter:
            counts_f = np.array(sorted(female_counter.values(), reverse=True), dtype=float)
            total_f = counts_f.sum()
            def frac_f(k: int) -> float:
                k = min(k, len(counts_f))
                return float(counts_f[:k].sum() / total_f) if k > 0 else 0.0
            result["female"] = {
                "total_reports": int(total_f),
                "unique_reports": int(len(female_counter)),
                "unique_ratio": float(len(female_counter) / total_f),
                "max_template_count": int(counts_f[0]) if len(counts_f) > 0 else 0,
                "max_template_fraction": float(counts_f[0] / total_f) if len(counts_f) > 0 else 0.0,
                "frac_top_1": frac_f(1),
                "frac_top_5": frac_f(5),
                "frac_top_10": frac_f(10),
            }
        if male_counter:
            counts_m = np.array(sorted(male_counter.values(), reverse=True), dtype=float)
            total_m = counts_m.sum()
            def frac_m(k: int) -> float:
                k = min(k, len(counts_m))
                return float(counts_m[:k].sum() / total_m) if k > 0 else 0.0
            result["male"] = {
                "total_reports": int(total_m),
                "unique_reports": int(len(male_counter)),
                "unique_ratio": float(len(male_counter) / total_m),
                "max_template_count": int(counts_m[0]) if len(counts_m) > 0 else 0,
                "max_template_fraction": float(counts_m[0] / total_m) if len(counts_m) > 0 else 0.0,
                "frac_top_1": frac_m(1),
                "frac_top_5": frac_m(5),
                "frac_top_10": frac_m(10),
            }

    return result

# ---------- Diversity metrics (lexical + Self-BLEU + semantic) ----------
@dataclass
class _DiversityConfig:
    sample_size: int
    truncate_words: int
    self_bleu_samples: int
    seed: int
    semantic_backend: str  # auto|sentence_transformers|tfidf

def _truncate_to_words(text: str, max_words: int) -> str:
    if max_words <= 0:
        return str(text) if not pd.isna(text) else ""
    words = re.findall(r"[a-z0-9]+", str(text).lower())
    return " ".join(words[:max_words])

def _distinct_n(texts: List[str], n: int) -> float:
    """Distinct-n over a collection of texts. Returns ratio in [0,1]."""
    if n <= 0:
        return 0.0
    total = 0
    uniq = set()
    for t in texts:
        toks = re.findall(r"[a-z0-9]+", t.lower())
        if len(toks) < n:
            continue
        total += (len(toks) - n + 1)
        for i in range(len(toks) - n + 1):
            uniq.add(tuple(toks[i:i+n]))
    return float(len(uniq) / total) if total > 0 else 0.0

def _ttr(texts: List[str]) -> float:
    """Corpus-level type/token ratio in [0,1]."""
    toks = []
    for t in texts:
        toks.extend(re.findall(r"[a-z0-9]+", t.lower()))
    if not toks:
        return 0.0
    return float(len(set(toks)) / len(toks))

def _ngram_counts(tokens: List[str], n: int) -> Counter:
    c = Counter()
    if len(tokens) < n:
        return c
    for i in range(len(tokens) - n + 1):
        c[tuple(tokens[i:i+n])] += 1
    return c

def _bleu_n(hyp: List[str], refs: List[List[str]], n: int, smooth: float = 1.0) -> float:
    """
    Simple BLEU-N with:
      - clipped n-gram precision up to N
      - brevity penalty
      - add-k smoothing on precisions (k = smooth)
    Returns BLEU in [0,1].
    """
    if not hyp or not refs:
        return 0.0
    max_n = max(1, int(n))

    # Closest reference length for BP
    hyp_len = len(hyp)
    ref_lens = [len(r) for r in refs if r]
    if not ref_lens:
        return 0.0
    closest_ref_len = min(ref_lens, key=lambda rl: (abs(rl - hyp_len), rl))
    if hyp_len == 0:
        return 0.0
    bp = 1.0 if hyp_len > closest_ref_len else math.exp(1.0 - float(closest_ref_len) / float(hyp_len))

    log_p_sum = 0.0
    for k in range(1, max_n + 1):
        hyp_counts = _ngram_counts(hyp, k)
        if not hyp_counts:
            # no k-grams -> precision 0 (with smoothing)
            p_k = smooth / (smooth + 1.0)
        else:
            max_ref = Counter()
            for r in refs:
                max_ref |= _ngram_counts(r, k)
            clipped = 0
            total = 0
            for ng, cnt in hyp_counts.items():
                total += cnt
                clipped += min(cnt, max_ref.get(ng, 0))
            p_k = float(clipped + smooth) / float(total + smooth)
        log_p_sum += math.log(max(p_k, 1e-12))

    bleu = bp * math.exp(log_p_sum / max_n)
    return float(max(0.0, min(1.0, bleu)))

def _self_bleu(texts: List[str], n: int, sample_hyps: int, seed: int) -> float:
    """
    Approximate Self-BLEU by sampling hypotheses and using the rest as references.
    Returns mean BLEU in [0,1].
    """
    texts = [t for t in texts if t and t.strip()]
    if len(texts) < 2:
        return 0.0
    rng = random.Random(seed)
    m = min(sample_hyps, len(texts))
    idxs = list(range(len(texts)))
    rng.shuffle(idxs)
    idxs = idxs[:m]

    tokenized = [re.findall(r"[a-z0-9]+", t.lower()) for t in texts]
    scores = []
    for i in idxs:
        hyp = tokenized[i]
        refs = [tokenized[j] for j in range(len(tokenized)) if j != i]
        # To keep runtime reasonable, subsample references if very large
        if len(refs) > 50:
            ref_idxs = list(range(len(refs)))
            rng.shuffle(ref_idxs)
            refs = [refs[j] for j in ref_idxs[:50]]
        scores.append(_bleu_n(hyp, refs, n=n, smooth=1.0))
    return float(np.mean(scores)) if scores else 0.0

def _semantic_diversity(texts: List[str], backend: str, seed: int) -> dict:
    """
    Semantic diversity as average pairwise cosine distance over document embeddings.
    - If sentence-transformers is available, uses `all-mpnet-base-v2`.
    - Otherwise falls back to TF-IDF vectors.
    Returns dict with fields: backend, n, avg_pairwise_cosine_distance.
    """
    texts = [t for t in texts if t and t.strip()]
    if len(texts) < 2:
        return {"backend": backend, "n": len(texts), "avg_pairwise_cosine_distance": 0.0}

    # Backend selection
    chosen = backend
    if backend == "auto":
        chosen = "sentence_transformers"
        try:
            import sentence_transformers  # noqa: F401
        except Exception:
            chosen = "tfidf"

    rng = np.random.default_rng(seed)

    if chosen == "sentence_transformers":
        try:
            from sentence_transformers import SentenceTransformer
            model = SentenceTransformer("sentence-transformers/all-mpnet-base-v2")
            emb = model.encode(texts, batch_size=32, show_progress_bar=False, normalize_embeddings=True)
            X = np.asarray(emb, dtype=np.float32)
        except Exception as e:
            # fall back to TF-IDF if ST fails at runtime (e.g., missing torch/cuda)
            chosen = "tfidf"
            fallback_reason = str(e)
        else:
            fallback_reason = None
    else:
        fallback_reason = None

    if chosen == "tfidf":
        try:
            from sklearn.feature_extraction.text import TfidfVectorizer
            from sklearn.preprocessing import normalize
            vec = TfidfVectorizer(lowercase=True, token_pattern=r"[a-z0-9]+")
            X = vec.fit_transform(texts)
            X = normalize(X, norm="l2", axis=1)
        except Exception as e:
            return {
                "backend": "tfidf",
                "n": len(texts),
                "avg_pairwise_cosine_distance": 0.0,
                "error": f"tfidf_failed: {e}"
            }

    # Approximate average pairwise cosine distance using sampling
    # cosine_distance = 1 - cosine_similarity; with normalized vectors, sim = dot.
    n = X.shape[0]
    pairs = min(20000, n * (n - 1) // 2)
    if pairs <= 0:
        return {"backend": chosen, "n": int(n), "avg_pairwise_cosine_distance": 0.0}

    # Sample random pairs (i,j), i<j
    i_idx = rng.integers(0, n, size=pairs, dtype=np.int64)
    j_idx = rng.integers(0, n, size=pairs, dtype=np.int64)
    mask = i_idx != j_idx
    i_idx = i_idx[mask]
    j_idx = j_idx[mask]
    if len(i_idx) == 0:
        return {"backend": chosen, "n": int(n), "avg_pairwise_cosine_distance": 0.0}

    if hasattr(X, "multiply"):  # sparse
        sims = np.array((X[i_idx].multiply(X[j_idx])).sum(axis=1)).ravel()
    else:
        sims = np.sum(X[i_idx] * X[j_idx], axis=1)
    dist = 1.0 - sims
    out = {
        "backend": chosen,
        "n": int(n),
        "avg_pairwise_cosine_distance": float(np.mean(dist)),
        "pairs_sampled": int(len(dist)),
    }
    if fallback_reason:
        out["fallback_reason"] = fallback_reason
    return out

def _reservoir_sample_texts(csv_path: Path, text_col: str, chunksize: int, sample_size: int,
                            seed: int, label_col: Optional[str] = None) -> dict:
    """
    Reservoir-sample up to `sample_size` documents from a CSV text column.
    If `label_col` is provided and present, also keeps per-sex samples (M/F).
    Returns dict with keys: overall (List[str]), female (List[str]), male (List[str]), has_sex (bool).
    """
    rng = random.Random(seed)
    overall: List[str] = []
    female: List[str] = []
    male: List[str] = []
    seen = 0
    seen_f = 0
    seen_m = 0

    # Determine actual sex column if requested
    has_sex = False
    actual_label_col = None
    if label_col is not None:
        try:
            sample = pd.read_csv(csv_path, nrows=1)
            actual_label_col = find_sex_column(sample.columns, label_col)
            has_sex = True
        except Exception:
            has_sex = False
            actual_label_col = None

    usecols = [text_col]
    if has_sex and actual_label_col is not None:
        usecols.append(actual_label_col)

    for chunk in pd.read_csv(csv_path, usecols=usecols, chunksize=chunksize, dtype=str):
        chunk = chunk.dropna(subset=[text_col])
        if has_sex and actual_label_col is not None:
            chunk[actual_label_col] = chunk[actual_label_col].str.strip().str.upper()
        for _, row in chunk.iterrows():
            t = row[text_col]
            if pd.isna(t):
                continue
            t = str(t).strip()
            if not t:
                continue

            # overall reservoir
            seen += 1
            if len(overall) < sample_size:
                overall.append(t)
            else:
                j = rng.randint(1, seen)
                if j <= sample_size:
                    overall[j - 1] = t

            if has_sex and actual_label_col is not None:
                sex = row.get(actual_label_col, "")
                if sex == "F":
                    seen_f += 1
                    if len(female) < sample_size:
                        female.append(t)
                    else:
                        j = rng.randint(1, seen_f)
                        if j <= sample_size:
                            female[j - 1] = t
                elif sex == "M":
                    seen_m += 1
                    if len(male) < sample_size:
                        male.append(t)
                    else:
                        j = rng.randint(1, seen_m)
                        if j <= sample_size:
                            male[j - 1] = t

    return {"overall": overall, "female": female, "male": male, "has_sex": has_sex}

def compute_diversity_analysis(csv_path: Path, text_col: str, label_col: Optional[str],
                               chunksize: int, cfg: _DiversityConfig) -> dict:
    """
    Compute diversity metrics for one corpus (CSV + text column):
      - unique reports (count + percent)
      - lexical diversity: TTR, distinct-2, distinct-3 (computed on truncated texts)
      - Self-BLEU: Self-BLEU-2 and Self-BLEU-3 (approx); also report 1 - Self-BLEU avg
      - semantic diversity: avg pairwise cosine distance among embeddings
    Returns JSON-serializable dict.
    """
    if not csv_path.exists():
        return {"error": f"missing_csv: {csv_path}"}

    rng = random.Random(cfg.seed)

    # Sample texts for expensive metrics
    samples = _reservoir_sample_texts(csv_path, text_col, chunksize, cfg.sample_size, cfg.seed, label_col)
    texts_all = samples["overall"]

    # Truncate & normalize texts for lexical/self-bleu metrics
    trunc = [_truncate_to_words(t, cfg.truncate_words) for t in texts_all]
    trunc = [t for t in trunc if t]

    # Unique report templates (on full normalized text, not word-truncated)
    def _norm_full(x: str) -> str:
        return str(x).strip().lower()
    norm_full = [_norm_full(t) for t in texts_all if t and str(t).strip()]
    total_docs_sampled = len(norm_full)
    unique_docs_sampled = len(set(norm_full))
    unique_ratio_sampled = float(unique_docs_sampled / total_docs_sampled) if total_docs_sampled > 0 else 0.0

    # Lexical diversity metrics
    ttr = _ttr(trunc)
    distinct2 = _distinct_n(trunc, 2)
    distinct3 = _distinct_n(trunc, 3)

    # Self-BLEU (approx) and 1 - Self-BLEU (diversity view)
    hyps = min(cfg.self_bleu_samples, len(trunc))
    sb2 = _self_bleu(trunc, n=2, sample_hyps=hyps, seed=cfg.seed + 13)
    sb3 = _self_bleu(trunc, n=3, sample_hyps=hyps, seed=cfg.seed + 17)
    sb_avg = float((sb2 + sb3) / 2.0)
    one_minus_self_bleu = float(1.0 - sb_avg)

    # Semantic diversity
    sem = _semantic_diversity(trunc, backend=cfg.semantic_backend, seed=cfg.seed + 23)

    out = {
        "config": {
            "sample_size": int(cfg.sample_size),
            "truncate_words": int(cfg.truncate_words),
            "self_bleu_samples": int(cfg.self_bleu_samples),
            "random_seed": int(cfg.seed),
            "semantic_backend": str(cfg.semantic_backend),
        },
        "unique_reports_sampled": {
            "total_reports": int(total_docs_sampled),
            "unique_reports": int(unique_docs_sampled),
            "unique_ratio": float(unique_ratio_sampled),
            "unique_percent": float(unique_ratio_sampled * 100.0),
        },
        "lexical_diversity": {
            "ttr": float(ttr),
            "distinct_2": float(distinct2),
            "distinct_3": float(distinct3),
        },
        "self_bleu": {
            "self_bleu_2": float(sb2),
            "self_bleu_3": float(sb3),
            "self_bleu_avg": float(sb_avg),
            "one_minus_self_bleu_avg": float(one_minus_self_bleu),
        },
        "semantic_diversity": sem,
        "has_sex": bool(samples.get("has_sex", False)),
    }

    return out

# ---------- Main pipeline ----------
def run_pipeline(ref_csv: Path, ref_text_col: str, pred_csv: Path, pred_text_col: str, 
                label_col: str, outdir: Path, args):
    outdir.mkdir(parents=True, exist_ok=True)
    vocab_filter = load_vocab(args.vocab_path) if args.vocab_path else set()
    stopwords = set()
    if not args.no_stopword_removal:
        stopwords = load_stopwords(args.stopwords_path)

    ref_label_col = args.reference_label_column or label_col
    pred_label_col = args.prediction_label_column or label_col

    print("\n" + "="*70)
    print("PHASE 1: Token Counting and Document Statistics")
    print("="*70)
    
    print("Counting tokens in reference...")
    ref_stats = stream_count_tokens(ref_csv, ref_text_col, ref_label_col, 
                                     args.include_bigrams, args.chunksize, stopwords)
    
    print("Counting tokens in predictions...")
    pred_stats = stream_count_tokens(pred_csv, pred_text_col, pred_label_col, 
                                      args.include_bigrams, args.chunksize, stopwords)

    if vocab_filter:
        ref_stats['female_counter'] = Counter({w:c for w,c in ref_stats['female_counter'].items() if w in vocab_filter})
        ref_stats['male_counter'] = Counter({w:c for w,c in ref_stats['male_counter'].items() if w in vocab_filter})
        pred_stats['female_counter'] = Counter({w:c for w,c in pred_stats['female_counter'].items() if w in vocab_filter})
        pred_stats['male_counter'] = Counter({w:c for w,c in pred_stats['male_counter'].items() if w in vocab_filter})

    # Global vocabulary
    all_vocab = (set(ref_stats['female_counter']) | set(ref_stats['male_counter']) | 
                 set(pred_stats['female_counter']) | set(pred_stats['male_counter']))
    union_V = len(all_vocab)
    
    print(f"\nGlobal Vocabulary Size: {union_V}")
    print(f"Reference - Total tokens (F/M): {ref_stats['total_tokens_f']}/{ref_stats['total_tokens_m']}")
    print(f"Prediction - Total tokens (F/M): {pred_stats['total_tokens_f']}/{pred_stats['total_tokens_m']}")

    print("\n" + "="*70)
    print("PHASE 2: Computing Log-Odds and Z-scores")
    print("="*70)
    
    ref_s, ref_var, ref_z, Nf_ref, Nm_ref = compute_log_odds_and_var(
        ref_stats['female_counter'], ref_stats['male_counter'], args.alpha, union_V)
    pred_s, pred_var, pred_z, Nf_pred, Nm_pred = compute_log_odds_and_var(
        pred_stats['female_counter'], pred_stats['male_counter'], args.alpha, union_V)

    # Prior (zero-count) defaults under Dirichlet smoothing:
    # Important for words present in one corpus but unseen in the other; the prior log-odds is
    # generally non-zero when Nf != Nm.
    ref_s0, ref_var0, ref_z0 = prior_log_odds_for_zero_count(Nf_ref, Nm_ref, args.alpha, union_V)
    pred_s0, pred_var0, pred_z0 = prior_log_odds_for_zero_count(Nf_pred, Nm_pred, args.alpha, union_V)

    # Statistically-derived thresholds
    z_strong = stats.norm.ppf(1 - args.significance_level/2)
    z_neutral = stats.norm.ppf(1 - args.neutral_significance/2)
    disp_threshold_z = args.displacement_threshold_z
    if disp_threshold_z is None:
        disp_threshold_z = stats.norm.ppf(1 - args.displacement_significance/2)

    print("\n" + "="*70)
    print("PHASE 3: Computing Variance-Normalized Displacement")
    print("="*70)
    
    rows = []
    pvals = []
    
    for w in all_vocab:
        ref_count = ref_stats['female_counter'].get(w,0) + ref_stats['male_counter'].get(w,0)
        pred_count = pred_stats['female_counter'].get(w,0) + pred_stats['male_counter'].get(w,0)
        
        if (ref_count + pred_count) < args.min_freq:
            continue
            
        # Use Dirichlet prior defaults for unseen words instead of 0.0 (neutral),
        # to avoid bias when Nf != Nm.
        s_ref = ref_s.get(w, ref_s0)
        s_pred = pred_s.get(w, pred_s0)
        z_ref = ref_z.get(w, ref_z0)
        z_pred = pred_z.get(w, pred_z0)

        # Two-sided association p-values and 0-1 strengths
        p_assoc_ref = 2.0 * (1.0 - 0.5 * (1.0 + math.erf(abs(z_ref) / math.sqrt(2.0))))
        p_assoc_pred = 2.0 * (1.0 - 0.5 * (1.0 + math.erf(abs(z_pred) / math.sqrt(2.0))))
        assoc_strength_ref = 1.0 - p_assoc_ref
        assoc_strength_pred = 1.0 - p_assoc_pred
        
        delta = s_pred - s_ref
        var_ref = ref_var.get(w, ref_var0)
        var_pred = pred_var.get(w, pred_var0)
        var_delta = var_ref + var_pred
        
        # Z-score for displacement (variance-normalized)
        z_displacement = delta / math.sqrt(var_delta) if var_delta > 0 else 0.0
        
        # P-value for displacement
        p = 2.0 * (1.0 - 0.5*(1.0 + math.erf(abs(z_displacement)/math.sqrt(2.0))))
        
        pvals.append(p)
        rows.append({
            "word": w,
            "ref_count": ref_count,
            "pred_count": pred_count,
            "s_ref": s_ref,
            "s_pred": s_pred,
            "z_ref": z_ref,
            "z_pred": z_pred,
            "p_assoc_ref": p_assoc_ref,
            "p_assoc_pred": p_assoc_pred,
            "assoc_strength_ref": assoc_strength_ref,
            "assoc_strength_pred": assoc_strength_pred,
            "delta": delta,
            "z_displacement": z_displacement,
            "var_delta": var_delta,
            "p_uncorrected": p
        })

    if not rows:
        raise RuntimeError("No words passed the minimum frequency threshold.")

    # FDR Correction
    adj = bh_fdr(pvals)
    for r, a in zip(rows, adj):
        r["p_fdr"] = a
        r["significant"] = a < 0.05
        # Displacement strength in [0,1] space
        r["disp_strength_uncorrected"] = 1.0 - r["p_uncorrected"]
        r["disp_strength_fdr"] = 1.0 - a

    df = pd.DataFrame(rows)
    df = df.sort_values("z_displacement", key=lambda x: x.abs(), ascending=False).reset_index(drop=True)
    
    print("\n" + "="*70)
    print("PHASE 4: Statistical Categorization")
    print("="*70)
    
    # Apply statistical categorization with clinically-aligned labels
    df["displaced"] = df["z_displacement"].abs() >= disp_threshold_z
    df[["category", "ref_assoc_band", "pred_assoc_band"]] = df.apply(
        lambda r: pd.Series(categorize_word_statistical(
            r["z_ref"], r["z_pred"], r["z_displacement"],
            z_strong, z_neutral, disp_threshold_z, args.min_abs_log_odds,
            ref_count=int(r.get("ref_count", 0)),
            pred_count=int(r.get("pred_count", 0)),
        )), axis=1
    )

    print("\n" + "="*70)
    print("PHASE 5: Computing Normalized WAE Metrics")
    print("="*70)
    
    # Compute Normalized WAE (using z_displacement)
    # First, compute for the requested primary weighting (backwards-compatible)
    wae_overall = compute_normalized_wae(df, args.wae_weight)
    wae_female = compute_normalized_wae(df[df["z_ref"] > 0], args.wae_weight)
    wae_male = compute_normalized_wae(df[df["z_ref"] < 0], args.wae_weight)

    wae_overall_ci = bootstrap_normalized_wae(df, args.wae_weight, args.bootstrap_samples)
    wae_female_ci = bootstrap_normalized_wae(df[df["z_ref"] > 0], args.wae_weight, args.bootstrap_samples)
    wae_male_ci = bootstrap_normalized_wae(df[df["z_ref"] < 0], args.wae_weight, args.bootstrap_samples)

    # Additionally, always compute WAE for all three weightings: total, ref, pred
    wae_by_weighting = {}
    for w in ["total", "ref", "pred"]:
        overall_w = compute_normalized_wae(df, w)
        female_w = compute_normalized_wae(df[df["z_ref"] > 0], w)
        male_w = compute_normalized_wae(df[df["z_ref"] < 0], w)
        overall_ci_w = bootstrap_normalized_wae(df, w, args.bootstrap_samples)
        female_ci_w = bootstrap_normalized_wae(df[df["z_ref"] > 0], w, args.bootstrap_samples)
        male_ci_w = bootstrap_normalized_wae(df[df["z_ref"] < 0], w, args.bootstrap_samples)
        wae_by_weighting[w] = {
            "overall": overall_w,
            "ref_female_words": female_w,
            "ref_male_words": male_w,
            "bootstrap": {
                "overall": overall_ci_w,
                "ref_female_words": female_ci_w,
                "ref_male_words": male_ci_w,
                "samples": args.bootstrap_samples,
            },
        }

    print("\n" + "="*70)
    print("PHASE 6: Lexical Fairness Analysis")
    print("="*70)
    
    lexical_fairness = compute_lexical_fairness(ref_stats, pred_stats, df)
    print("\n" + "="*70)
    print("PHASE 7: Repetitiveness Analysis (Prediction Templates)")
    print("="*70)
    repetitiveness = compute_repetitiveness(pred_csv, pred_text_col, pred_label_col, args.chunksize)
    if repetitiveness:
        overall_rep = repetitiveness.get("overall", {})
        if overall_rep:
            print(f"Total prediction reports: {overall_rep.get('total_reports', 0)}")
            print(f"Unique prediction reports: {overall_rep.get('unique_reports', 0)} "
                  f"({overall_rep.get('unique_ratio', 0.0):.3f} unique ratio)")
            print(f"Most frequent template fraction: {overall_rep.get('max_template_fraction', 0.0):.3f}")
            print(f"Top-5 templates cover: {overall_rep.get('frac_top_5', 0.0):.3f} of reports")

    print("\n" + "="*70)
    print("PHASE 8: Diversity Analysis (Lexical / Self-BLEU / Semantic)")
    print("="*70)
    div_cfg = _DiversityConfig(
        sample_size=int(args.diversity_sample_size),
        truncate_words=int(args.diversity_truncate_words),
        self_bleu_samples=int(args.diversity_self_bleu_samples),
        seed=int(args.diversity_random_seed),
        semantic_backend=str(args.diversity_semantic_backend),
    )
    diversity_reference = compute_diversity_analysis(
        ref_csv, ref_text_col, ref_label_col, args.chunksize, div_cfg
    )
    diversity_prediction = compute_diversity_analysis(
        pred_csv, pred_text_col, pred_label_col, args.chunksize, div_cfg
    )
    sweep_df = sweep_categories_by_displacement(
        df, z_strong, z_neutral, args.min_abs_log_odds,
        args.sweep_disp_start, args.sweep_disp_stop, args.sweep_disp_step
    )
    sweep_p_df = sweep_categories_by_p(
        df, z_strong, z_neutral, args.min_abs_log_odds,
        args.sweep_p_start, args.sweep_p_stop, args.sweep_p_step
    )

    # Save results
    csv_path = outdir / "cad_word_stats.csv"
    json_path = outdir / "cad_word_stats.json"
    summary_path = outdir / "cad_summary.json"
    
    df.to_csv(csv_path, index=False)
    df.to_json(json_path, orient="records", indent=2)

    # Summary
    category_counts = df["category"].value_counts().to_dict()
    # Percentages as share of all analyzed words
    category_counts_percent = {
        k: float(v) * 100.0 / max(len(df), 1) for k, v in category_counts.items()
    }
    summary = {
        "statistical_thresholds": {
            "significance_level_strong": args.significance_level,
            "significance_level_neutral": args.neutral_significance,
            "z_critical_strong": float(z_strong),
            "z_critical_neutral": float(z_neutral),
            "assoc_strength_strong": float(1.0 - args.significance_level),
            "assoc_strength_neutral": float(1.0 - args.neutral_significance),
            "displacement_significance": args.displacement_significance,
            "z_displacement_threshold": float(disp_threshold_z),
            "disp_strength_threshold": float(1.0 - args.displacement_significance),
            "alpha_smoothing": args.alpha,
            "min_frequency": args.min_freq
        },
        "category_counts": category_counts,
        "category_counts_percent": category_counts_percent,
        "dataset_statistics": {
            "union_vocabulary_size": union_V,
            "words_analyzed": len(df),
            "reference_documents": int(ref_stats['total_docs']),
            "prediction_documents": int(pred_stats['total_docs'])
        },
        "cad_categories": {
            "counts": category_counts,
            "percents": category_counts_percent
        },
        "normalized_wae": {
            "description": "Weighted Average of squared Z-scores (variance-normalized)",
            "weighting": args.wae_weight,
            "overall": wae_overall,
            "ref_female_words": wae_female,
            "ref_male_words": wae_male,
            "bootstrap": {
                "overall": wae_overall_ci,
                "ref_female_words": wae_female_ci,
                "ref_male_words": wae_male_ci,
                "samples": args.bootstrap_samples
            },
            # New: WAE for all three weighting schemes: total, ref, pred
            "by_weighting": wae_by_weighting
        },
        "lexical_fairness": lexical_fairness,
        "threshold_sweep_counts": sweep_df.to_dict(orient="records"),
        "threshold_sweep_counts_p": sweep_p_df.to_dict(orient="records"),
        "repetitiveness": repetitiveness,
        "diversity_analysis": {
            "reference": diversity_reference,
            "prediction": diversity_prediction
        }
    }
    
    with open(summary_path, "w") as f:
        json.dump(summary, f, indent=2)

    # Print summary
    print("\n" + "="*70)
    print("RESULTS SUMMARY")
    print("="*70)
    print(f"\nNormalized WAE (overall): {wae_overall:.6f}")
    print(f"  95% CI: [{wae_overall_ci['lower_ci']:.6f}, {wae_overall_ci['upper_ci']:.6f}]")
    print(f"\nNormalized WAE (female-associated words): {wae_female:.6f}")
    print(f"  95% CI: [{wae_female_ci['lower_ci']:.6f}, {wae_female_ci['upper_ci']:.6f}]")
    print(f"\nNormalized WAE (male-associated words): {wae_male:.6f}")
    print(f"  95% CI: [{wae_male_ci['lower_ci']:.6f}, {wae_male_ci['upper_ci']:.6f}]")
    # Category counts with percentages
    print("\nCategory breakdown at default displacement threshold:")
    for cat, count in category_counts.items():
        pct = category_counts_percent.get(cat, 0.0)
        print(f"  {cat:15s}: {count:6d} ({pct:5.2f}%)")

    print("\n" + "="*70)
    print("PHASE 7: Generating Visualizations")
    print("="*70)
    
    # Create comprehensive visualizations
    create_visualizations(df, summary, sweep_df, sweep_p_df, outdir, args)
    
    print(f"\nAll outputs saved to: {outdir}")
    print("="*70 + "\n")
    
    return df, summary

def create_visualizations(df: pd.DataFrame, summary: dict, sweep_df: pd.DataFrame, sweep_p_df: pd.DataFrame, outdir: Path, args):
    """Create comprehensive visualization suite (without volcano plot)."""
    
    # Set style
    sns.set_style("whitegrid")
    z_strong = summary['statistical_thresholds']['z_critical_strong']
    z_neutral = summary['statistical_thresholds']['z_critical_neutral']
    disp_thr = summary['statistical_thresholds']['z_displacement_threshold']
    
    df_plot = df.copy()
    
    # 1. Z-score Identity Plot (colored by displacement strength 1 - p_disp)
    fig2, ax2 = plt.subplots(figsize=(8, 8))
    scatter = ax2.scatter(df_plot["z_ref"], df_plot["z_pred"],
                         c=df_plot["disp_strength_uncorrected"],
                         s=10, alpha=0.4, cmap='viridis')
    lim = max(abs(df_plot["z_ref"].max()), abs(df_plot["z_pred"].max())) * 1.1 or 5.0
    ax2.plot([-lim, lim], [-lim, lim], "k--", alpha=0.7, label="Identity")
    ax2.set_xlim(-lim, lim)
    ax2.set_ylim(-lim, lim)
    ax2.set_xlabel("Z-score (Reference)", fontsize=12)
    ax2.set_ylabel("Z-score (Prediction)", fontsize=12)
    ax2.set_title("Clinical Association: Z-score Comparison", fontsize=14, fontweight='bold')
    cbar = fig2.colorbar(scatter, ax=ax2)
    cbar.set_label('Displacement strength (1 - p)', rotation=270, labelpad=20)
    ax2.legend()
    fig2.tight_layout()
    fig2.savefig(outdir / "z_score_identity_plot.png", dpi=300)
    plt.close(fig2)

    # 3. Category Distribution
    fig3, (ax3a, ax3b) = plt.subplots(1, 2, figsize=(14, 6))
    
    # Count plot
    cat_counts = df['category'].value_counts()
    cat_counts.plot(kind='barh', ax=ax3a, color='steelblue')
    ax3a.set_xlabel("Count", fontsize=11)
    ax3a.set_title("Distribution of Word Categories", fontsize=12, fontweight='bold')
    ax3a.grid(axis='x', alpha=0.3)
    
    # WAE breakdown
    wae_data = {
        'Overall': summary['normalized_wae']['overall'],
        'Female-assoc': summary['normalized_wae']['ref_female_words'],
        'Male-assoc': summary['normalized_wae']['ref_male_words']
    }
    wae_ci = {
        'Overall': [summary['normalized_wae']['bootstrap']['overall']['lower_ci'],
                   summary['normalized_wae']['bootstrap']['overall']['upper_ci']],
        'Female-assoc': [summary['normalized_wae']['bootstrap']['ref_female_words']['lower_ci'],
                        summary['normalized_wae']['bootstrap']['ref_female_words']['upper_ci']],
        'Male-assoc': [summary['normalized_wae']['bootstrap']['ref_male_words']['lower_ci'],
                      summary['normalized_wae']['bootstrap']['ref_male_words']['upper_ci']]
    }
    
    x_pos = np.arange(len(wae_data))
    values = list(wae_data.values())
    errors = [[v - wae_ci[k][0] for k, v in wae_data.items()],
              [wae_ci[k][1] - v for k, v in wae_data.items()]]
    
    ax3b.bar(x_pos, values, yerr=errors, capsize=5, color=['purple', 'pink', 'lightblue'], alpha=0.7)
    ax3b.set_xticks(x_pos)
    ax3b.set_xticklabels(wae_data.keys())
    ax3b.set_ylabel("Normalized WAE", fontsize=11)
    ax3b.set_title("Weighted Average Z²-displacement", fontsize=12, fontweight='bold')
    ax3b.grid(axis='y', alpha=0.3)
    
    fig3.tight_layout()
    fig3.savefig(outdir / "category_and_wae_distribution.png", dpi=300)
    plt.close(fig3)

    # 4. Lexical Fairness Dashboard
    fig4 = plt.figure(figsize=(14, 10))
    gs = fig4.add_gridspec(3, 2, hspace=0.3, wspace=0.3)
    
    lf = summary['lexical_fairness']
    
    # Vocabulary size comparison
    ax4a = fig4.add_subplot(gs[0, 0])
    vocab_data = {
        'Ref (F)': lf['vocabulary_statistics']['reference']['unique_words_female'],
        'Ref (M)': lf['vocabulary_statistics']['reference']['unique_words_male'],
        'Pred (F)': lf['vocabulary_statistics']['prediction']['unique_words_female'],
        'Pred (M)': lf['vocabulary_statistics']['prediction']['unique_words_male']
    }
    ax4a.bar(vocab_data.keys(), vocab_data.values(), color=['pink', 'lightblue', 'pink', 'lightblue'])
    ax4a.set_ylabel("Unique Words")
    ax4a.set_title("Vocabulary Size by Gender")
    ax4a.grid(axis='y', alpha=0.3)
    
    # Token counts
    ax4b = fig4.add_subplot(gs[0, 1])
    token_data = {
        'Ref (F)': lf['vocabulary_statistics']['reference']['total_tokens_female'],
        'Ref (M)': lf['vocabulary_statistics']['reference']['total_tokens_male'],
        'Pred (F)': lf['vocabulary_statistics']['prediction']['total_tokens_female'],
        'Pred (M)': lf['vocabulary_statistics']['prediction']['total_tokens_male']
    }
    ax4b.bar(token_data.keys(), token_data.values(), color=['pink', 'lightblue', 'pink', 'lightblue'])
    ax4b.set_ylabel("Total Tokens")
    ax4b.set_title("Token Counts by Gender")
    ax4b.grid(axis='y', alpha=0.3)
    
    # Type-Token Ratio
    ax4c = fig4.add_subplot(gs[1, 0])
    ttr_data = {
        'Ref (F)': lf['vocabulary_statistics']['reference']['type_token_ratio_female'],
        'Ref (M)': lf['vocabulary_statistics']['reference']['type_token_ratio_male'],
        'Pred (F)': lf['vocabulary_statistics']['prediction']['type_token_ratio_female'],
        'Pred (M)': lf['vocabulary_statistics']['prediction']['type_token_ratio_male']
    }
    ax4c.bar(ttr_data.keys(), ttr_data.values(), color=['pink', 'lightblue', 'pink', 'lightblue'])
    ax4c.set_ylabel("Type-Token Ratio")
    ax4c.set_title("Vocabulary Richness (TTR)")
    ax4c.grid(axis='y', alpha=0.3)
    
    # Fairness metrics
    ax4d = fig4.add_subplot(gs[1, 1])
    fairness_metrics = {
        'Vocab\nParity': [lf['lexical_fairness_metrics']['vocabulary_parity']['reference'],
                         lf['lexical_fairness_metrics']['vocabulary_parity']['prediction']],
        'Token\nParity': [lf['lexical_fairness_metrics']['token_count_parity']['reference'],
                         lf['lexical_fairness_metrics']['token_count_parity']['prediction']],
        'Jaccard\nSim': [lf['lexical_fairness_metrics']['vocabulary_jaccard_similarity']['reference'],
                        lf['lexical_fairness_metrics']['vocabulary_jaccard_similarity']['prediction']]
    }
    x = np.arange(len(fairness_metrics))
    width = 0.35
    ax4d.bar(x - width/2, [v[0] for v in fairness_metrics.values()], width, label='Reference', color='steelblue')
    ax4d.bar(x + width/2, [v[1] for v in fairness_metrics.values()], width, label='Prediction', color='coral')
    ax4d.set_ylabel("Score (0-1)")
    ax4d.set_title("Lexical Fairness Metrics")
    ax4d.set_xticks(x)
    ax4d.set_xticklabels(fairness_metrics.keys())
    ax4d.legend()
    ax4d.grid(axis='y', alpha=0.3)
    ax4d.set_ylim(0, 1.1)
    
    # Association distribution
    ax4e = fig4.add_subplot(gs[2, :])
    assoc = lf.get('association_distribution', {})
    assoc_ref = assoc.get('reference', {})
    assoc_pred = assoc.get('prediction', {})

    categories = ['Female-\nassociated', 'Male-\nassociated', 'Neutral']
    ref_vals = [
        assoc_ref.get('female_associated_words', 0),
        assoc_ref.get('male_associated_words', 0),
        assoc_ref.get('neutral_words', 0),
    ]
    pred_vals = [
        assoc_pred.get('female_associated_words', 0),
        assoc_pred.get('male_associated_words', 0),
        assoc_pred.get('neutral_words', 0),
    ]

    x = np.arange(len(categories))
    width = 0.35
    ax4e.bar(x - width/2, ref_vals, width, label='Reference', color='steelblue', alpha=0.8)
    ax4e.bar(x + width/2, pred_vals, width, label='Prediction', color='coral', alpha=0.8)
    ax4e.set_xticks(x)
    ax4e.set_xticklabels(categories)
    ax4e.set_ylabel("Word Count")
    ax4e.set_title("Distribution of Word Associations (Ref vs Pred)")
    ax4e.legend()
    ax4e.grid(axis='y', alpha=0.3)
    
    fig4.suptitle("Lexical Fairness Analysis Dashboard", fontsize=16, fontweight='bold', y=0.995)
    fig4.savefig(outdir / "lexical_fairness_dashboard.png", dpi=300, bbox_inches='tight')
    plt.close(fig4)

    # 5. Association axis distribution (reference vs prediction)
    fig5, ax5 = plt.subplots(figsize=(10, 6))
    bins = np.linspace(-8, 8, 80)
    ax5.hist(df_plot["z_ref"], bins=bins, alpha=0.5, label="Reference z", color="steelblue", density=True)
    ax5.hist(df_plot["z_pred"], bins=bins, alpha=0.5, label="Prediction z", color="coral", density=True)
    ax5.axvline(0, color="black", linestyle="--", linewidth=0.8, alpha=0.6)
    ax5.axvline(z_strong, color="green", linestyle=":", linewidth=1, label="±z_strong")
    ax5.axvline(-z_strong, color="green", linestyle=":", linewidth=1)
    ax5.axvline(z_neutral, color="gray", linestyle="--", linewidth=1, label="±z_neutral")
    ax5.axvline(-z_neutral, color="gray", linestyle="--", linewidth=1)
    ax5.set_xlabel("Association z-score")
    ax5.set_ylabel("Density")
    ax5.set_title("Association Axis Distribution (Reference vs Prediction)")
    ax5.legend()
    fig5.tight_layout()
    fig5.savefig(outdir / "association_axis_distribution.png", dpi=300)
    plt.close(fig5)

    # 6. Displacement threshold sweep (z-threshold)
    fig6, ax6 = plt.subplots(figsize=(10, 6))
    # 5 categories that partition the vocabulary
    key_cats = [c for c in ["no_displacement", "preservation", "erasure", "new_bias", "bias_flip"]
                if c in sweep_df.columns]
    for cat in key_cats:
        ax6.plot(sweep_df["threshold"], sweep_df[cat], marker="o", label=cat)
    ax6.set_xlabel("Displacement z threshold")
    ax6.set_ylabel("Word count")
    ax6.set_title("Category counts vs displacement threshold")
    ax6.grid(alpha=0.3)
    ax6.legend()
    fig6.tight_layout()
    fig6.savefig(outdir / "category_counts_vs_threshold.png", dpi=300)
    plt.close(fig6)

    # 7. Displacement p-value sweep (1 - p-based view)
    fig6b, ax6b = plt.subplots(figsize=(10, 6))
    key_cats_p = [c for c in ["no_displacement", "preservation", "erasure", "new_bias", "bias_flip"]
                  if c in sweep_p_df.columns]
    for cat in key_cats_p:
        ax6b.plot(sweep_p_df["p_threshold"], sweep_p_df[cat], marker="o", label=cat)
    ax6b.set_xlabel("Displacement p-value threshold")
    ax6b.set_ylabel("Word count")
    ax6b.set_title("Category counts vs displacement p-value threshold")
    ax6b.grid(alpha=0.3)
    ax6b.legend()
    fig6b.tight_layout()
    fig6b.savefig(outdir / "category_counts_vs_p_threshold.png", dpi=300)
    plt.close(fig6b)

    # 5. Top K words slope chart (colored by reference sex association)
    k_slope = min(20, len(df))
    topk_df = df.nlargest(k_slope, 'z_displacement').copy()
    
    if not topk_df.empty:
        fig7, ax7 = plt.subplots(figsize=(10, max(8, k_slope * 0.45)))
        # Sort to reduce label overlap (by reference z-score)
        topk_df = topk_df.sort_values("z_ref").reset_index(drop=True)
        for i, row in topk_df.iterrows():
            if row["z_ref"] > 0:
                color = "crimson"   # female-associated in reference
            elif row["z_ref"] < 0:
                color = "royalblue" # male-associated in reference
            else:
                color = "gray"      # neutral in reference
            alpha = min(1.0, abs(row["z_displacement"]) / 3.0)
            # small vertical offset to reduce text overlap
            offset = (i - k_slope / 2.0) * 0.05
            y_ref = row["z_ref"] + offset
            y_pred = row["z_pred"] + offset
            ax7.plot([0, 1], [y_ref, y_pred],
                     color=color, alpha=alpha, marker='o', linewidth=2)
            # label only on prediction side to avoid clutter
            ax7.text(1.02, y_pred, row["word"], fontsize=9, va="center", color=color)
        
        ax7.set_xticks([0, 1])
        ax7.set_xticklabels(["Reference", "Prediction"], fontsize=12)
        ax7.set_ylabel("Z-score", fontsize=12)
        ax7.set_title(f"Top {k_slope} Words by Z-displacement (female=crimson, male=royalblue)", fontsize=12, fontweight='bold')
        ax7.axhline(0, color='black', linestyle='-', linewidth=0.5, alpha=0.3)
        fig7.tight_layout()
        fig7.savefig(outdir / "slope_chart_top_displacement.png", dpi=300, bbox_inches='tight')
        plt.close(fig7)

def make_demo_data(outdir: Path) -> Tuple[Path, Path]:
    """Create demo data for testing."""
    outdir.mkdir(parents=True, exist_ok=True)
    ref = pd.DataFrame([
        {"patient_sex":"F", "Findings":"uterus pregnancy cervix breast"},
        {"patient_sex":"M", "Findings":"prostate testicular"},
        {"patient_sex":"F", "Findings":"ovarian cyst"},
        {"patient_sex":"M", "Findings":"prostate cancer"}
    ] * 50)  # Repeat for sufficient stats
    pred = pd.DataFrame([
        {"patient_sex":"F", "predicted_report":"uterus"},
        {"patient_sex":"M", "predicted_report":"prostate cancer aggressive"},
        {"patient_sex":"F", "predicted_report":"pregnancy"},
        {"patient_sex":"M", "predicted_report":"enlarged prostate"}
    ] * 50)
    ref.to_csv(outdir / "ref.csv", index=False)
    pred.to_csv(outdir / "pred.csv", index=False)
    return outdir / "ref.csv", outdir / "pred.csv"

def main():
    args = parse_args()
    if not args.demo and (args.reference_csv is None or args.prediction_csv is None):
        import sys
        print("Error: --reference_csv and --prediction_csv are required unless --demo.", file=sys.stderr)
        print("  Use --demo to run on built-in toy data, or run: cad --help", file=sys.stderr)
        sys.exit(1)
    args.output_dir = Path(args.output_dir)
    args.output_dir.mkdir(parents=True, exist_ok=True)

    print("\n" + "="*70)
    print("ROBUST CLINICAL ASSOCIATION DISPLACEMENT (CAD) ANALYSIS")
    print("With Variance-Normalized Metrics and Statistical Validation")
    print("="*70)
    print(f"Reference CSV:     {args.reference_csv}")
    print(f"Reference column:  {args.reference_text_column}")
    print(f"Prediction CSV:    {args.prediction_csv}")
    print(f"Prediction column: {args.prediction_text_column}")
    print(f"Output directory:  {args.output_dir}")
    print("="*70)
    
    if args.demo:
        args.output_dir = args.output_dir / "demo_run"
        args.reference_csv, args.prediction_csv = make_demo_data(args.output_dir)
        args.reference_text_column = "Findings"
        args.prediction_text_column = "predicted_report"
        args.label_column = "patient_sex"
    
    if args.label_column is None:
        args.label_column = "PatientSex"
    
    run_pipeline(args.reference_csv, args.reference_text_column, 
                args.prediction_csv, args.prediction_text_column, 
                args.label_column, args.output_dir, args)

if __name__ == "__main__":
    main()