Changelog
=========

All notable changes to this project will be documented in this file.

The format is loosely based on [Keep a Changelog](https://keepachangelog.com).

[Unreleased]
------------

[0.7.0] - 2026-03-09
--------------------

### Breaking Changes

- The `pika` configuration key in `[tool.queueio]` has been renamed to `broker`.
- The `QUEUEIO_PIKA` environment variable has been renamed to `QUEUEIO_BROKER`.
- Removed `Broker.create(queue)`, in favor of `Broker.sync([queue])`.
- Removed `Broker.delete(queue)`, without replacement.
- Removed `QueueIO.create(queue)`, in favor of `QueueIO.sync([queue])`.
- Removed `QueueIO.delete(queue)`, without replacement.

### Added

- Added `Broker.sync()` to back `queueio sync`.
- Added `QueueIO.sync()` to back `queueio sync`.
- `Backend` ABC with `broker()` and `journal()` methods
  that return independent context managers with their own lifecycles.

[0.6.0] - 2026-02-16
--------------------

### Added

- Django integration (`queueio.django`) with `runserver` lifecycle management.
- [djp](https://djp.readthedocs.io/) support for automatic `INSTALLED_APPS` registration.
- [django-cmd](https://pypi.org/project/django-cmd/) integration for settings discovery.
- Documentation site.

[0.5.0] - 2026-02-08
--------------------

### Breaking Changes

- `invocation.priority` removed;
  use `invocation.context[priority]` instead.
- `Invocation.Submitted.priority` replaced with `context`.
- Serialized invocations from previous versions are incompatible.

### Added

- `QueueVar` for user-defined serializable context variables
  that propagate across queue boundaries.
- `QueueContext` mapping to access captured context on invocations.
- `priority` is now a `QueueVar` instance
  (same context manager syntax as before).

[0.4.0] - 2026-02-07
--------------------

### Breaking Changes

- Serialized invocations from previous versions are incompatible.
- Queues must be recreated with `sync --recreate`
  to support priority ordering.

### Added

- Priority support for invocations (0-9, default 4).
  Use the `priority()` context manager to set the priority
  for invocations created within its scope.
  Priority propagates to descendent invocations.
- `sync --recreate` flag to delete and recreate all queues.
- `Invocation.Submitted` events now include `priority`.

### Fixed

- The `queueio` CLI entry point was broken
  by a build configuration that excluded the package source.

[0.3.0] - 2026-02-06
--------------------

### Added

- The journal now uses a threadsafe pika connection,
  rather than guarding a blocking connection.
- The integration tests and examples have better queue names.

[0.2.2] - 2025-11-23
--------------------

### Fixed

- Use the queueio logo from GitHub so it will show on PyPI.

[0.2.1] - 2025-11-22
--------------------

### Fixed

- Include the queueio logo in the distribution so it will show on PyPI.

[0.2.0] - 2025-11-22
--------------------

### Acknowledgement

Thank you to Nick Anderegg for allowing me to use the queueio name for this project.

### Added

- `routine` decorator to declare sync or async functions as background routines.
- `activate` context manager to activate the queueio system.
- `pause` to coordinate a pause of a routine to queueio.
- `gather` to run multiple routines concurrently and gather the results.
- `Routine.submit()` method to submit a routine invocation to the queue.
- Configuration in the `tool.queueio` section of `pyproject.toml`.
  - `pika` configures the pika library to connect to the AMQP broker.
  - `register` configures the modules that declare routines.
- `QUEUEIO_PIKA` environment variable
  to override the `pika` configuration in `pyproject.toml`.
- `queueio sync` command to synchronize queues to the broker.
- `queueio run` command to run the queueio worker.
- The queuespec syntax to `queue run` to consume multiple queues with shared capacity.
- `queueio monitor` command to monitor activity in the queueio system.

[Unreleased]: https://github.com/ryanhiebert/queueio/compare/tag/0.7.0...HEAD
[0.7.0]: https://github.com/ryanhiebert/queueio/compare/tag/0.6.0...tag/0.7.0
[0.6.0]: https://github.com/ryanhiebert/queueio/compare/tag/0.5.0...tag/0.6.0
[0.5.0]: https://github.com/ryanhiebert/queueio/compare/tag/0.4.0...tag/0.5.0
[0.4.0]: https://github.com/ryanhiebert/queueio/compare/tag/0.3.0...tag/0.4.0
[0.3.0]: https://github.com/ryanhiebert/queueio/compare/tag/0.2.2...tag/0.3.0
[0.2.2]: https://github.com/ryanhiebert/queueio/compare/tag/0.2.1...tag/0.2.2
[0.2.1]: https://github.com/ryanhiebert/queueio/compare/tag/0.2.0...tag/0.2.1
[0.2.0]: https://github.com/ryanhiebert/queueio/releases/tag/0.2.0
