import importlib
import os
import tomllib
from collections.abc import Generator
from collections.abc import Iterable
from concurrent.futures import Future
from contextlib import AbstractContextManager
from contextlib import contextmanager
from contextvars import ContextVar
from pathlib import Path
from typing import Self

from .backend import Backend
from .broker import Broker
from .consumer import Consumer
from .django import setup as _django_setup
from .invocation import Invocation
from .journal import Journal
from .message import Message
from .queue import Queue
from .queue import ShutDown
from .queuespec import QueueSpec
from .queuevar import QueueVar
from .registry import ROUTINE_REGISTRY
from .result import Err
from .result import Ok
from .routine import Routine
from .stream import Stream
from .thread import Thread

priority: QueueVar[int] = QueueVar("priority", default=4)


class QueueIO:
    __active = ContextVar[Self | None]("active", default=None)

    @classmethod
    def active(cls) -> Self:
        """Find the currently active instance."""
        queueio = cls.__active.get()
        assert queueio is not None, "No active QueueIO instance"
        return queueio

    @classmethod
    @contextmanager
    def default(cls) -> Generator[Self]:
        """Create a QueueIO from configuration with proper lifecycle management."""
        with (
            cls.__connect() as backend,
            backend.broker() as broker,
            backend.journal() as journal,
        ):
            instance = cls(broker=broker, journal=journal)
            try:
                yield instance
            finally:
                instance.shutdown()

    def __init__(
        self,
        *,
        broker: Broker,
        journal: Journal,
    ):
        self.__broker = broker
        self.__stream = Stream(journal)
        self.__invocations = dict[Invocation, Message]()
        self.__register_routines()

    @contextmanager
    def activate(self):
        token = self.__active.set(self)
        try:
            with self.invocation_handler():
                yield
        finally:
            self.__active.reset(token)
            self.shutdown()

    @staticmethod
    def __pyproject() -> Path | None:
        for path in [cwd := Path.cwd(), *cwd.parents]:
            candidate = path / "pyproject.toml"
            if candidate.is_file():
                return candidate
        return None

    @staticmethod
    def __config() -> dict:
        pyproject = QueueIO.__pyproject()
        if pyproject:
            with pyproject.open("rb") as f:
                config = tomllib.load(f)
            return config.get("tool", {}).get("queueio", {})
        return {}

    @staticmethod
    def __resolve_uri() -> str:
        config = QueueIO.__config()
        uri = os.environ.get("QUEUEIO_BROKER") or config.get("broker")
        if not uri:
            raise ValueError(
                "No broker configured. "
                "Set QUEUEIO_BROKER env var or 'broker' in [tool.queueio]."
            )
        return uri

    @staticmethod
    def __connect() -> AbstractContextManager[Backend]:
        uri = QueueIO.__resolve_uri()
        if uri.startswith("amqp://") or uri.startswith("amqps://"):
            from .pika import PikaBackend

            return PikaBackend.connect(uri)
        if uri.startswith("postgresql://") or uri.startswith("postgres://"):
            raise ValueError("Broker 'psycopg' is not yet implemented.")
        raise ValueError(f"Unsupported URI scheme: {uri}")

    def __register_routines(self):
        """Load routine modules from pyproject.toml."""
        for hook in [_django_setup]:
            hook()

        config = QueueIO.__config()
        modules = config.get("register", [])

        for module_name in modules:
            importlib.import_module(module_name)

    def run[R](self, invocation: Invocation[R], /) -> R:
        with self.invocation_handler():
            return invocation.submit().result()

    def sync(self, queues: Iterable[str], *, recreate: bool = False):
        self.__broker.sync(queues, recreate=recreate)

    def purge(self, *, queue: str):
        self.__broker.purge(queue=queue)

    def routine(self, routine_name: str, /) -> Routine:
        return ROUTINE_REGISTRY[routine_name]

    def routines(self) -> list[Routine]:
        """Return all registered routines."""
        return list(ROUTINE_REGISTRY.values())

    def subscribe[T](self, types: Iterable[type[T]]) -> Queue[T]:
        return self.__stream.subscribe(types)

    def unsubscribe(self, queue: Queue):
        return self.__stream.unsubscribe(queue)

    @contextmanager
    def invocation_handler(self) -> Generator[Future]:
        waiting: dict[str, Future] = {}
        events = self.subscribe({Invocation.Completed})

        def resolver():
            while True:
                try:
                    event = events.get()
                except ShutDown:
                    break

                match event:
                    case Invocation.Completed(id=invocation_id, result=Ok(value)):
                        if invocation_id in waiting:
                            future = waiting.pop(invocation_id)
                            future.set_result(value)
                    case Invocation.Completed(id=invocation_id, result=Err(exception)):
                        if invocation_id in waiting:
                            future = waiting.pop(invocation_id)
                            future.set_exception(exception)

        resolver_thread = Thread(target=resolver)
        resolver_thread.start()

        def handler(invocation: Invocation, /) -> Future:
            future = Future()
            waiting[invocation.id] = future
            self.submit(invocation)
            return future

        try:
            with Invocation.handler(handler):
                yield resolver_thread.future
        finally:
            self.unsubscribe(events)
            resolver_thread.join()

    def submit(self, invocation: Invocation, /):
        """Submit an invocation to be run in the background."""
        routine = self.routine(invocation.routine)
        self.__stream.publish(
            Invocation.Submitted(
                id=invocation.id,
                routine=invocation.routine,
                args=invocation.args,
                kwargs=invocation.kwargs,
                context=invocation.context,
            )
        )
        queue = routine.queue
        self.__broker.enqueue(
            invocation.serialize(),
            queue=queue,
            priority=invocation.context.get(priority, priority.get()),
        )

    def consume(self, queuespec: QueueSpec, /) -> Consumer:
        return Consumer(
            stream=self.__stream,
            receiver=self.__broker.receive(queuespec),
            deserialize=Invocation.deserialize,
        )

    def shutdown(self):
        """Shut down all components."""
        self.__broker.shutdown()
        self.__stream.shutdown()
