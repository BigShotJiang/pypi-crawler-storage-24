import subprocess
import sys

import pytest

from queueio.invocation import Invocation
from queueio.queueio import QueueIO
from queueio.result import Ok

from .basic import yielding


@pytest.mark.timeout(10)
def test_integration():
    with QueueIO.default() as queueio, queueio.activate():
        queueio.sync(["basic"])
        queueio.purge(queue="basic")
        events = queueio.subscribe({Invocation.Completed})
        invocation = yielding(7)
        queueio.submit(invocation)

        proc = subprocess.Popen(
            [sys.executable, "-m", "queueio", "run", "basic=1"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        try:
            while event := events.get():
                if event.id == invocation.id:
                    assert isinstance(event.result, Ok)
                    break
        finally:
            if proc.poll() is None:
                proc.terminate()
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait()
