"""
Query Refinement for SharpContext — powered by Ebbiforge
=========================================================

Turns vague developer queries into precise "master prompts" that yield
better context selection and fewer hallucinations.

Architecture:
    User prompt ──► VaguenessDetector ──► if vague:
                                               │
                    EbbiforgeSemanticEngine ◄──┘
                         │
                         ├─ embed(query) using TF vectors
                         ├─ rank fragment_contents by cosine_similarity
                         ├─ extract vocabulary from closest N fragments
                         └─ reconstruct master prompt grounded in real code

Why ebbiforge?
    - Local TF-vector embeddings (no API call, zero latency, truly offline)
    - Sparse cosine similarity over bag-of-words — real math, not heuristic
    - AgentDriftDetector can warn if user's task is drifting from session goal
    - All pure Python, no dependencies beyond stdlib

Fallback:
    If ebbiforge is not importable, the heuristic path is used silently.
    This makes the integration opt-in and non-breaking.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Optional, List, Callable

# ── Ebbiforge integration ───────────────────────────────────────────────
try:
    from ebbiforge.embeddings import text_to_embedding, cosine_similarity
    _EBBIFORGE_AVAILABLE = True
except ImportError:
    _EBBIFORGE_AVAILABLE = False
    text_to_embedding = None
    cosine_similarity = None


# ── Vagueness detection ─────────────────────────────────────────────────

_GENERIC_VERBS = frozenset({
    "fix", "debug", "add", "help", "check", "look", "find", "show",
    "get", "make", "do", "run", "try", "use", "change", "update",
    "improve", "understand", "explain", "review", "refactor", "write",
    "create", "implement", "build", "test", "work", "handle",
})

_GENERIC_NOUNS = frozenset({
    "bug", "error", "issue", "problem", "thing", "stuff", "code",
    "this", "that", "it", "here", "there", "file", "function",
    "feature", "task", "work", "test", "case", "part", "bit",
})

_CODE_INDICATORS = frozenset({
    "class", "function", "method", "variable", "import", "module",
    "async", "await", "return", "type", "interface", "struct", "enum",
    "trait", "impl", "fn", "def", "let", "const", "mut", "pub",
    "token", "query", "engine", "schema", "api", "endpoint", "database",
    "cache", "auth", "payment", "user", "request", "response", "error",
    "exception", "panic", "crash", "performance", "memory", "thread",
    "race", "deadlock", "timeout", "retry", "circuit", "breaker",
    "knapsack", "entropy", "simhash", "embedding", "relevance", "decay",
})


@dataclass
class QueryAnalysis:
    original: str
    is_vague: bool
    vagueness_score: float
    detected_topics: List[str]
    suggested_files: List[str]
    refined_query: str
    refinement_source: str        # "ebbiforge" | "heuristic" | "none"
    top_semantic_matches: List[str] = field(default_factory=list)


def analyze_query(query: str) -> tuple[float, list[str]]:
    """
    Returns (vagueness_score, code_terms_found).
    vagueness_score: 0.0 = precise, 1.0 = completely vague.
    """
    if not query or not query.strip():
        return 1.0, []

    words = re.findall(r'\b\w+\b', query.lower())
    if not words:
        return 1.0, []

    total = len(words)
    code_terms = [w for w in words if w in _CODE_INDICATORS]

    # Hard rule: ≤3 words with no code terms → always vague
    if total <= 3 and not code_terms:
        return 0.9, code_terms

    generic = sum(1 for w in words if w in _GENERIC_VERBS or w in _GENERIC_NOUNS)
    short_penalty = max(0.0, (5 - total) / 5.0)
    generic_ratio = generic / total if total > 0 else 1.0
    code_bonus = min(1.0, len(code_terms) * 0.2)

    vagueness = (short_penalty * 0.3 + generic_ratio * 0.5) - code_bonus * 0.3
    return max(0.0, min(1.0, vagueness)), code_terms


# ── Ebbiforge semantic expansion ───────────────────────────────────────

def _extract_key_terms(text: str, top_n: int = 12) -> List[str]:
    """
    Extract the most informative terms from a code fragment.

    Uses TF directly: terms with moderate frequency that are long enough
    to be meaningful (filtering out noise like 'a', 'in', 'the').
    """
    words = re.findall(r'[a-z_]\w{3,}', text.lower())  # ≥4 chars, code-like
    if not words:
        return []
    from collections import Counter
    counts = Counter(words)
    total = len(words)
    # Score: TF weighted by length (longer identifiers are more specific)
    scored = [
        (word, (count / total) * min(1.0, len(word) / 10.0))
        for word, count in counts.items()
        if word not in _GENERIC_VERBS and word not in _GENERIC_NOUNS
        and not word.isdigit()
    ]
    scored.sort(key=lambda x: -x[1])
    return [w for w, _ in scored[:top_n]]


def refine_with_ebbiforge(
    query: str,
    fragment_sources: List[str],
    fragment_contents: List[str],
) -> tuple[str, List[str], str]:  # (refined, top_sources, source_tag)
    """
    Semantically ground a vague query using ebbiforge TF embeddings.

    Algorithm:
    1. Embed the query as a TF vector
    2. Embed each fragment's content as a TF vector
    3. Rank fragments by cosine_similarity(query_emb, frag_emb)
    4. Take the top-K semantically closest fragments
    5. Extract key technical vocabulary from those fragments
    6. Reconstruct a master prompt using that vocabulary

    This is what separates "fix the bug in [module]" from
    "fix the bug in SharpContextEngine.ingest() related to
    token budget quantization and entropy scoring thresholds"
    """
    if not _EBBIFORGE_AVAILABLE or not fragment_contents:
        return query, fragment_sources[:3], "heuristic"

    # Step 1: embed the query
    q_emb = text_to_embedding(query)
    if not q_emb.vector:
        return query, fragment_sources[:3], "heuristic"

    # Step 2 + 3: embed each fragment and rank by cosine similarity
    ranked = []
    for i, content in enumerate(fragment_contents[:50]):  # cap at 50 for speed
        if not content.strip():
            continue
        f_emb = text_to_embedding(content[:1000])  # First 1000 chars dominant
        sim = cosine_similarity(q_emb.vector, f_emb.vector)
        source = fragment_sources[i] if i < len(fragment_sources) else f"fragment_{i}"
        ranked.append((sim, source, content))

    if not ranked:
        return query, fragment_sources[:3], "heuristic"

    ranked.sort(key=lambda x: -x[0])
    top_k = ranked[:5]  # Top 5 semantically closest

    # Step 4: extract vocabulary from closest fragments
    top_sources = [src for _, src, _ in top_k]
    combined_content = " ".join(c for _, _, c in top_k)
    key_terms = _extract_key_terms(combined_content, top_n=8)

    # Step 5: module names from sources
    module_names = []
    for src in top_sources[:3]:
        base = src.split("/")[-1]
        base = re.sub(r'\.[^.]+$', '', base)
        if base and base not in ('__init__', 'mod', 'main', 'lib', 'index'):
            module_names.append(base)

    # Step 6: reconstruct the master prompt
    parts = [query.strip()]
    if module_names:
        parts.append(f"in the {', '.join(module_names)} module(s)")
    if key_terms:
        # Pick terms that look like code identifiers (camel/snake case, not prose)
        code_like = [t for t in key_terms if '_' in t or any(c.isupper() for c in t[1:])]
        prose_like = [t for t in key_terms if t not in code_like]
        vocab = (code_like[:4] + prose_like[:2])[:5]
        if vocab:
            parts.append(f"involving {', '.join(vocab)}")

    refined = " ".join(parts)
    if len(refined) > 400:
        refined = refined[:400]

    return refined, top_sources, "ebbiforge"


def refine_query_heuristic(
    original_query: str,
    fragment_sources: List[str],
    fragment_contents: List[str],
) -> str:
    """
    Fallback heuristic expansion when ebbiforge is unavailable.
    Uses only file names and detected language — no semantic content analysis.
    """
    lang_map = {".py": "Python", ".rs": "Rust", ".ts": "TypeScript", ".js": "JavaScript"}
    langs = set()
    modules = []
    for src in fragment_sources[:8]:
        for ext, lang in lang_map.items():
            if src.endswith(ext):
                langs.add(lang)
                break
        base = src.split("/")[-1]
        base = re.sub(r'\.[^.]+$', '', base)
        if base and base not in ('__init__', 'mod', 'main', 'lib'):
            modules.append(base)

    parts = [original_query.strip()]
    if modules:
        parts.append(f"in the {', '.join(modules[:4])} module(s)")
    if langs:
        parts.append(f"({' and '.join(langs)} codebase)")
    return " ".join(parts)


class QueryRefiner:
    """
    Vague query → semantically grounded master prompt.

    Uses ebbiforge's local TF-vector embeddings to find which in-memory
    fragments are genuinely closest to the query, extracts their technical
    vocabulary, and reconstructs a precise master prompt.

    Zero API calls. Runs in microseconds. Works offline.

    Usage:
        refiner = QueryRefiner()
        analysis = refiner.refine(
            "fix the bug",
            fragment_sources=["src/knapsack.rs", "sharp_context/dedup.py"],
            fragment_contents=[rust_code, python_code]
        )
        # analysis.refined_query → use for optimize_context()
        # analysis.refinement_source → "ebbiforge" | "heuristic" | "none"
    """

    def __init__(
        self,
        vagueness_threshold: float = 0.35,
        llm_refine_fn: Optional[Callable] = None,
    ):
        self.vagueness_threshold = vagueness_threshold
        self.llm_refine_fn = llm_refine_fn
        self._ebbiforge_available = _EBBIFORGE_AVAILABLE

    def refine(
        self,
        query: str,
        fragment_sources: Optional[List[str]] = None,
        fragment_contents: Optional[List[str]] = None,
    ) -> QueryAnalysis:
        """
        Analyze and refine a query synchronously.

        fragment_contents should be the actual code text of fragments in memory.
        fragment_sources should be their file paths.
        Both lists must be parallel (same indices).
        """
        fragment_sources = fragment_sources or []
        fragment_contents = fragment_contents or []

        vagueness, code_terms = analyze_query(query)
        is_vague = vagueness >= self.vagueness_threshold

        if not is_vague:
            return QueryAnalysis(
                original=query,
                is_vague=False,
                vagueness_score=round(vagueness, 3),
                detected_topics=code_terms,
                suggested_files=fragment_sources[:5],
                refined_query=query,
                refinement_source="none",
            )

        # Try ebbiforge semantic expansion first
        if self._ebbiforge_available and fragment_contents:
            refined, top_sources, source_tag = refine_with_ebbiforge(
                query, fragment_sources, fragment_contents
            )
        else:
            # Heuristic fallback (file names only)
            refined = refine_query_heuristic(query, fragment_sources, fragment_contents)
            top_sources = fragment_sources[:5]
            source_tag = "heuristic"

        return QueryAnalysis(
            original=query,
            is_vague=True,
            vagueness_score=round(vagueness, 3),
            detected_topics=code_terms,
            suggested_files=top_sources[:5],
            refined_query=refined,
            refinement_source=source_tag,
            top_semantic_matches=top_sources[:3],
        )

    async def refine_async(
        self,
        query: str,
        fragment_sources: Optional[List[str]] = None,
        fragment_contents: Optional[List[str]] = None,
    ) -> QueryAnalysis:
        """
        Async variant — uses LLM for extremely high vagueness queries (>0.8)
        if configured. Falls back to ebbiforge/heuristic silently.
        """
        analysis = self.refine(query, fragment_sources, fragment_contents)

        # Only use LLM if ebbiforge couldn't do a good job
        if (analysis.is_vague
                and self.llm_refine_fn
                and analysis.vagueness_score > 0.8
                and analysis.refinement_source == "heuristic"):
            try:
                topics = {
                    "modules": [s.split("/")[-1] for s in fragment_sources[:6]],
                    "patterns": analysis.detected_topics,
                }
                llm_refined = await self.llm_refine_fn(query, topics)
                if llm_refined and len(llm_refined) > len(query):
                    analysis.refined_query = llm_refined
                    analysis.refinement_source = "llm"
            except Exception:
                pass

        return analysis


# ── LLM backend factories (optional, for extreme vagueness) ─────────────

LLM_REFINEMENT_PROMPT = """You are helping a coding assistant select the most relevant context files.

Developer query: "{query}"
Files in memory: {files}
Code patterns: {patterns}

Rewrite as a precise technical master prompt (max 150 chars) preserving intent:"""


def make_openai_refine_fn(api_key: str, model: str = "gpt-4o-mini") -> Callable:
    """OpenAI async LLM backend for QueryRefiner. Used only when vagueness > 0.8."""
    async def refine_fn(query: str, topics: dict) -> str:
        import httpx
        prompt = LLM_REFINEMENT_PROMPT.format(
            query=query,
            files=", ".join(topics.get("modules", [])[:6]),
            patterns=", ".join(topics.get("patterns", [])[:4]),
        )
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                "https://api.openai.com/v1/chat/completions",
                headers={"Authorization": f"Bearer {api_key}"},
                json={"model": model, "messages": [{"role": "user", "content": prompt}],
                      "max_tokens": 80, "temperature": 0.2},
                timeout=4.0,
            )
            resp.raise_for_status()
            return resp.json()["choices"][0]["message"]["content"].strip()
    return refine_fn


def make_anthropic_refine_fn(api_key: str, model: str = "claude-haiku-20240307") -> Callable:
    """Anthropic async LLM backend for QueryRefiner. Cheapest model, fast."""
    async def refine_fn(query: str, topics: dict) -> str:
        import httpx
        prompt = LLM_REFINEMENT_PROMPT.format(
            query=query,
            files=", ".join(topics.get("modules", [])[:6]),
            patterns=", ".join(topics.get("patterns", [])[:4]),
        )
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                "https://api.anthropic.com/v1/messages",
                headers={"x-api-key": api_key, "anthropic-version": "2023-06-01",
                         "content-type": "application/json"},
                json={"model": model, "max_tokens": 80,
                      "messages": [{"role": "user", "content": prompt}]},
                timeout=4.0,
            )
            resp.raise_for_status()
            return resp.json()["content"][0]["text"].strip()
    return refine_fn
