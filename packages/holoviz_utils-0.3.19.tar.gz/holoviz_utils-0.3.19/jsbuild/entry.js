import * as deckCore from "deck.gl";
import * as deckJson from "@deck.gl/json";
import { COGLayer } from "@developmentseed/deck.gl-geotiff";
import chroma from "chroma-js";

globalThis.deck = { ...deckCore, ...deckJson, COGLayer };
globalThis.chroma = chroma;
