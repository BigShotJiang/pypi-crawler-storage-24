import * as esbuild from "esbuild";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

await esbuild.build({
  entryPoints: [path.join(__dirname, "entry.js")],
  bundle: true,
  minify: true,
  format: "iife",
  outfile: path.join(
    __dirname,
    "..",
    "src",
    "holoviz_utils",
    "vendor",
    "deckgl-bundle.min.js"
  ),
  target: ["esnext"],
  logLevel: "info",
});
