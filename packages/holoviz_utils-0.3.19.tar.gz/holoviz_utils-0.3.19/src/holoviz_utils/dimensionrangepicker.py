import holoviews as hv
import holoviews.streams as streams
import param
import numpy as np
import panel as pn
from bokeh.models import BoxAnnotation, ColumnDataSource, CustomJS
from bokeh.models.annotations.geometry import AreaVisuals

hv.extension("bokeh")


class DimensionRangePickerGraph(param.Parameterized):

    graph = param.ClassSelector(class_=hv.DynamicMap, constant=True)
    axis = param.Selector(default="x", objects=["x", "y", "both"], constant=True)
    box_style = param.Dict(default=dict(
        fill_color="blue",
        fill_alpha=0.2,
        line_color="blue",
        line_alpha=0.5,
        use_handles=False,
    ))

    _throttle_ms = param.Integer(default=200, bounds=(0, None))
    throttled = param.Boolean(default=False)

    _box_left = param.Number(default=None, allow_None=True)
    _box_right = param.Number(default=None, allow_None=True)
    _box_bottom = param.Number(default=None, allow_None=True)
    _box_top = param.Number(default=None, allow_None=True)
    _last_bounds = param.Tuple(default=None, length=4, allow_None=True)

    def __init__(self, **params):
        super().__init__(**params)

        self._box_ref = None
        self._source_ref = None
        self._syncing_from_python = False

        # Determine tool and stream based on axis mode.
        tool_map = {"x": "xbox_select", "y": "ybox_select", "both": "box_select"}
        self._select_tool = tool_map[self.axis]

        # Add a redraw stream for forcing re-renders from Python.
        self._redraw_stream = streams.Stream.define("Redraw")()
        self._box_hook_ref = self._box_hook

        def _append_box_opts(element, _box_hook=self._box_hook, _tool=self._select_tool):
            # Extract existing opts so we append rather than replace.
            try:
                plot_opts = hv.Store.lookup_options(
                    hv.Store.current_backend, element, "plot"
                ).kwargs
            except Exception:
                plot_opts = {}
            existing_hooks = plot_opts.get("hooks", [])
            existing_tools = plot_opts.get("tools", [])
            hooks = existing_hooks if _box_hook in existing_hooks else existing_hooks + [_box_hook]
            tools = existing_tools if _tool in existing_tools else existing_tools + [_tool]
            return element.opts(tools=tools, hooks=hooks)

        with param.edit_constant(self):
            self.graph = self.graph.clone(
                streams=self.graph.streams + [self._redraw_stream]
            ).apply(_append_box_opts)

        # Watch bounds and SingleTap on the graph (not as DynamicMap streams,
        # so the user's callback doesn't need to accept extra args).
        self._tap = streams.SingleTap(source=self.graph)

        if self.axis == "x":
            self._bounds_stream = streams.BoundsX(source=self.graph)
            self._bounds_stream.param.watch(self._on_bounds, ["boundsx"])
        elif self.axis == "y":
            self._bounds_stream = streams.BoundsY(source=self.graph)
            self._bounds_stream.param.watch(self._on_bounds, ["boundsy"])
        else:
            self._bounds_stream = streams.BoundsXY(source=self.graph)
            self._bounds_stream.param.watch(self._on_bounds, ["bounds"])

        self._tap.param.watch(self._on_tap, ["x", "y"])

        watched_params = self._active_box_params()
        self.param.watch(self._sync_box, watched_params)
        self.param.watch(self.log_it, watched_params)

    def _active_box_params(self):
        if self.axis == "x":
            return ["_box_left", "_box_right"]
        elif self.axis == "y":
            return ["_box_bottom", "_box_top"]
        else:
            return ["_box_left", "_box_right", "_box_bottom", "_box_top"]

    def _has_box(self):
        if self.axis == "x":
            return self._box_left is not None
        elif self.axis == "y":
            return self._box_bottom is not None
        else:
            return self._box_left is not None

    def _clear_box_params(self):
        updates = {}
        if self.axis in ("x", "both"):
            updates["_box_left"] = None
            updates["_box_right"] = None
        if self.axis in ("y", "both"):
            updates["_box_bottom"] = None
            updates["_box_top"] = None
        return updates

    def _on_bounds(self, event):
        if event.new is None:
            return
        if self.axis == "x":
            l, r = event.new
            new_bounds = (l, None, r, None)
        elif self.axis == "y":
            b, t = event.new
            new_bounds = (None, b, None, t)
        else:
            new_bounds = event.new  # (left, bottom, right, top)

        if new_bounds == self._last_bounds:
            return

        updates = {"_last_bounds": new_bounds}
        if self.axis in ("x", "both"):
            updates["_box_left"] = new_bounds[0]
            updates["_box_right"] = new_bounds[2]
        if self.axis in ("y", "both"):
            updates["_box_bottom"] = new_bounds[1]
            updates["_box_top"] = new_bounds[3]
        self.param.update(**updates)

    def _on_tap(self, *events):
        ev = {e.name: e.new for e in events}
        x, y = ev.get("x"), ev.get("y")
        if not self._has_box():
            return
        inside = True
        if self.axis in ("x", "both") and x is not None:
            if not (self._box_left <= x <= self._box_right):
                inside = False
        if self.axis in ("y", "both") and y is not None:
            if not (self._box_bottom <= y <= self._box_top):
                inside = False
        if not inside:
            self.param.update(**self._clear_box_params())

    def log_it(self, *events):
        parts = []
        if self.axis in ("x", "both"):
            parts.append(f"left={self._box_left}, right={self._box_right}")
        if self.axis in ("y", "both"):
            parts.append(f"bottom={self._box_bottom}, top={self._box_top}")
        print(f"Box: {', '.join(parts)}")

    def _source_keys(self):
        keys = []
        if self.axis in ("x", "both"):
            keys += ["left", "right"]
        if self.axis in ("y", "both"):
            keys += ["bottom", "top"]
        return keys

    def _box_values(self):
        vals = {}
        if self.axis in ("x", "both"):
            vals["left"] = self._box_left
            vals["right"] = self._box_right
        if self.axis in ("y", "both"):
            vals["bottom"] = self._box_bottom
            vals["top"] = self._box_top
        return vals

    def _sync_box(self, *events):
        """Push box param changes directly to the Bokeh models."""
        if self._box_ref is None:
            if self._has_box():
                self._redraw_stream.event()
            return
        if not self._has_box():
            self._box_ref.visible = False
        else:
            self._box_ref.visible = True
            if self._source_ref is not None:
                self._syncing_from_python = True
                self._source_ref.data = {
                    k: [v] for k, v in self._box_values().items()
                }
                self._syncing_from_python = False

    def _box_hook(self, plot, element):
        # Always remove any existing BoxAnnotation
        plot.state.center = [
            r for r in plot.state.center
            if not isinstance(r, BoxAnnotation)
        ]
        if not self._has_box():
            return

        vals = self._box_values()
        box_kwargs = dict(editable=True, **self.box_style)
        if self.axis == "x":
            box_kwargs.update(left=vals["left"], right=vals["right"], movable="x", resizable="x")
        elif self.axis == "y":
            box_kwargs.update(bottom=vals["bottom"], top=vals["top"], movable="y", resizable="y")
        else:
            box_kwargs.update(
                left=vals["left"], right=vals["right"],
                bottom=vals["bottom"], top=vals["top"],
                movable="both", resizable="all",
            )
        box = BoxAnnotation(**box_kwargs)
        box.handles.corners = AreaVisuals(fill_alpha=0, line_alpha=0, hover_fill_alpha=0, hover_line_alpha=0)
        box.handles.sides = AreaVisuals(
            fill_color="gray", fill_alpha=0.3, line_alpha=0,
            hover_fill_color="gray", hover_fill_alpha=0.5, hover_line_alpha=0,
        )

        # Use a ColumnDataSource as a JS→Python bridge since
        # box.on_change doesn't fire for editable interactions.
        keys = self._source_keys()
        source_data = {k: [getattr(box, k)] for k in keys}
        source = ColumnDataSource(data=source_data)

        # JS: build assignment lines for sync_from_python and data emission.
        py_to_box_lines = "\n".join(f"box.{k} = source.data.{k}[0];" for k in keys)
        box_to_source = "{" + ", ".join(f"{k}: [box.{k}]" for k in keys) + "}"

        sync_from_python_js = CustomJS(
            args=dict(box=box, source=source),
            code=f"""
                source._from_python = true;
                {py_to_box_lines}
                source._from_python = false;
            """,
        )
        source.js_on_change("data", sync_from_python_js)

        if self.throttled:
            js_code = f"""
                if (source._from_python) {{ return; }}
                clearTimeout(source._timeout_id);
                source._timeout_id = setTimeout(() => {{
                    source.data = {box_to_source};
                    source.change.emit();
                }}, throttle_ms);
            """
        else:
            js_code = f"""
                if (source._from_python) {{ return; }}
                const now = Date.now();
                clearTimeout(source._timeout_id);
                if (now - (source._last_fired || 0) >= throttle_ms) {{
                    source._last_fired = now;
                    source.data = {box_to_source};
                    source.change.emit();
                }} else {{
                    source._timeout_id = setTimeout(() => {{
                        source._last_fired = Date.now();
                        source.data = {box_to_source};
                        source.change.emit();
                    }}, throttle_ms);
                }}
            """

        js_cb = CustomJS(
            args=dict(source=source, box=box, throttle_ms=self._throttle_ms),
            code=js_code,
        )
        for k in keys:
            box.js_on_change(k, js_cb)

        def on_source_change(attr, old, new):
            if self._syncing_from_python:
                return
            updates = {}
            if "left" in new:
                updates["_box_left"] = new["left"][0]
            if "right" in new:
                updates["_box_right"] = new["right"][0]
            if "bottom" in new:
                updates["_box_bottom"] = new["bottom"][0]
            if "top" in new:
                updates["_box_top"] = new["top"][0]
            self.param.update(**updates)

        source.on_change("data", on_source_change)

        self._box_ref = box
        self._source_ref = source

        plot.state.add_layout(box)


if __name__ == "__main__":

    def make_graph(amplitude, frequency):
        x = np.linspace(0, 4 * np.pi, 1000)
        y = amplitude * np.sin(frequency * x)
        return hv.Curve((x, y), kdims="x", vdims="y").opts(
            responsive=True, height=400, line_width=2, framewise=True,
        )

    amplitude = pn.widgets.FloatSlider(name="Amplitude", value=2, start=1, end=10)
    frequency = pn.widgets.FloatSlider(name="Frequency", value=1, start=1, end=6)
    dmap = hv.DynamicMap(
        make_graph,
        streams=[
            streams.Params(amplitude, ["value"], rename={"value": "amplitude"}),
            streams.Params(frequency, ["value"], rename={"value": "frequency"}),
        ],
    )

    picker = DimensionRangePickerGraph(graph=dmap, axis="x")
    view = pn.Column(amplitude, frequency, picker.graph)

view