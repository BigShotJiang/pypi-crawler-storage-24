"""Constants for the Larnitech client library."""

from __future__ import annotations

# Default ports
DEFAULT_WS_PORT = 8080
DEFAULT_HTTP_PORT = 8888
DEFAULT_ADMIN_PORT = 80

# Device types
DEVICE_TYPE_AC = "AC"
DEVICE_TYPE_BLINDS = "blinds"
DEVICE_TYPE_CLIMATE_CONTROL = "climate-control"
DEVICE_TYPE_COM_PORT = "com-port"
DEVICE_TYPE_CURRENT_SENSOR = "current-sensor"
DEVICE_TYPE_DIMMER_LAMP = "dimmer-lamp"
DEVICE_TYPE_DOOR_SENSOR = "door-sensor"
DEVICE_TYPE_GATE = "gate"
DEVICE_TYPE_HUMIDITY_SENSOR = "humidity-sensor"
DEVICE_TYPE_ILLUMINATION_SENSOR = "illumination-sensor"
DEVICE_TYPE_IR_RECEIVER = "ir-receiver"
DEVICE_TYPE_IR_TRANSMITTER = "ir-transmitter"
DEVICE_TYPE_JALOUSIE = "jalousie"
DEVICE_TYPE_JSON = "json"
DEVICE_TYPE_LAMP = "lamp"
DEVICE_TYPE_LEAK_SENSOR = "leak-sensor"
DEVICE_TYPE_LIGHT_SCHEME = "light-scheme"
DEVICE_TYPE_MOTION_SENSOR = "motion-sensor"
DEVICE_TYPE_REMOTE_CONTROL = "remote-control"
DEVICE_TYPE_SCRIPT = "script"
DEVICE_TYPE_SWITCH = "switch"
DEVICE_TYPE_TEMPERATURE_SENSOR = "temperature-sensor"
DEVICE_TYPE_VALVE = "valve"
DEVICE_TYPE_VALVE_HEATING = "valve-heating"
DEVICE_TYPE_VIRTUAL = "virtual"
DEVICE_TYPE_VOLTAGE_SENSOR = "voltage-sensor"

# Device type groupings for HA platform mapping
LIGHT_TYPES = {DEVICE_TYPE_LAMP, DEVICE_TYPE_DIMMER_LAMP}
CLIMATE_TYPES = {DEVICE_TYPE_AC, DEVICE_TYPE_VALVE_HEATING}
COVER_TYPES = {DEVICE_TYPE_BLINDS, DEVICE_TYPE_JALOUSIE, DEVICE_TYPE_GATE}
SENSOR_TYPES = {
    DEVICE_TYPE_TEMPERATURE_SENSOR,
    DEVICE_TYPE_HUMIDITY_SENSOR,
    DEVICE_TYPE_ILLUMINATION_SENSOR,
    DEVICE_TYPE_CURRENT_SENSOR,
    DEVICE_TYPE_VOLTAGE_SENSOR,
}
BINARY_SENSOR_TYPES = {
    DEVICE_TYPE_MOTION_SENSOR,
    DEVICE_TYPE_DOOR_SENSOR,
    DEVICE_TYPE_LEAK_SENSOR,
}
SWITCH_TYPES = {DEVICE_TYPE_VALVE}
REMOTE_TYPES = {DEVICE_TYPE_REMOTE_CONTROL}
BUTTON_TYPES = {DEVICE_TYPE_SCRIPT}
SCENE_TYPES = {DEVICE_TYPE_LIGHT_SCHEME}

# AC mode codes (bits 4-7 of byte 0) — verified by live testing
AC_MODE_FAN_ONLY = 0
AC_MODE_COOL = 1
AC_MODE_DRY = 2
AC_MODE_HEAT = 3
AC_MODE_AUTO = 4

AC_MODES = {
    AC_MODE_FAN_ONLY: "fan_only",
    AC_MODE_COOL: "cool",
    AC_MODE_DRY: "dry",
    AC_MODE_HEAT: "heat",
    AC_MODE_AUTO: "auto",
}

# AC fan speed codes (low nibble of byte 4)
# AC fan speed codes (low nibble of byte 4) — verified by live testing
AC_FAN_AUTO = 0
AC_FAN_LOW = 1
AC_FAN_MEDIUM = 2
AC_FAN_HIGH = 3
AC_FAN_TURBO = 4
# Note: 5 is skipped/invalid on tested hardware
AC_FAN_NIGHT = 6

AC_FAN_MODES = {
    AC_FAN_AUTO: "auto",
    AC_FAN_LOW: "low",
    AC_FAN_MEDIUM: "medium",
    AC_FAN_HIGH: "high",
    AC_FAN_TURBO: "turbo",
    AC_FAN_NIGHT: "night",
}
