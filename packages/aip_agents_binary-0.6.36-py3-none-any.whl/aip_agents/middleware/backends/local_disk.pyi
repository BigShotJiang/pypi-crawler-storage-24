from _typeshed import Incomplete
from aip_agents.middleware.backends.protocol import BackendProtocol, EditResult, ExecuteResult, FileInfo, GrepMatch, WriteResult
from pathlib import Path
from typing import Any

__all__ = ['LocalDiskBackend']

class LocalDiskBackend(BackendProtocol):
    '''Local disk filesystem backend.

    Implements BackendProtocol using actual filesystem storage via pathlib.
    Files persist across sessions and are stored on disk.

    Security:
        All paths are validated to prevent directory traversal attacks.
        Operations are restricted to the base_directory.

    Attributes:
        base_path: Root directory for all file operations.

    Example:
        >>> backend = LocalDiskBackend(base_directory="/tmp/agent_files")
        >>> backend.write("/test.txt", "Hello World")
        >>> content = backend.read("/test.txt")
    '''
    base_path: Incomplete
    allow_execute: Incomplete
    def __init__(self, base_directory: str | Path | None = None, allow_execute: bool = False) -> None:
        """Initialize local disk backend.

        Args:
            base_directory: Root directory for file storage. Created if
                it doesn't exist. If None, use system temp directory.
            allow_execute: Whether to allow command execution. Disabled by
                default for security. Set True only for trusted environments.
        """
    def ls_info(self, path: str) -> list[FileInfo]:
        """List files in a directory.

        Args:
            path: Directory path to list (absolute, relative to base).

        Returns:
            List of FileInfo objects.

        Raises:
            FileNotFoundError: If path does not exist.
            NotADirectoryError: If path is not a directory.
        """
    def read(self, file_path: str, offset: int = 0, limit: int = 2000) -> str:
        """Read a file's contents with line numbers.

        Args:
            file_path: Path to the file (absolute, relative to base).
            offset: Line number to start from (0-indexed). Defaults to 0.
            limit: Maximum number of lines to read. Defaults to 2000.

        Returns:
            File content formatted with line numbers.

        Raises:
            FileNotFoundError: If file does not exist.
            IsADirectoryError: If path is a directory.
        """
    def write(self, file_path: str, content: str) -> WriteResult:
        """Write content to a file.

        Args:
            file_path: Path where to write (absolute, relative to base).
            content: Content to write.

        Returns:
            WriteResult indicating success.
        """
    def edit(self, file_path: str, old_string: str, new_string: str, replace_all: bool = False) -> EditResult:
        """Edit a file by replacing old_string with new_string.

        Args:
            file_path: Path to the file (absolute, relative to base).
            old_string: String to find and replace.
            new_string: String to replace with.
            replace_all: If True, replace all occurrences. If False,
                old_string must appear exactly once. Defaults to False.

        Returns:
            EditResult with number of replacements.

        Notes:
            Returns errors via EditResult.error to match deepagents-style tool flow.
        """
    def glob_info(self, pattern: str, path: str = '/') -> list[FileInfo]:
        '''Find files matching a glob pattern.

        Args:
            pattern: Glob pattern (e.g., "**/*.py", "*.txt").
            path: Base directory to search from. Defaults to "/".

        Returns:
            List of FileInfo objects for matching files.
        '''
    def grep(self, pattern: str, path: str | None = None) -> list[GrepMatch]:
        """Search for text pattern across files.

        Uses ripgrep (rg) if available for fast searching, falling back to
        Python regex search. Requires ripgrep to be installed in the
        environment (e.g., via Docker).

        Args:
            pattern: Text pattern to search (literal string, not regex).
            path: Directory to search in. Defaults to None (search all).

        Returns:
            List of GrepMatch objects.

        Raises:
            FileNotFoundError: If path is specified but does not exist.
        """
    grep_raw = grep
    def set_files(self, files: dict[str, Any], thread_id: str = 'default') -> None:
        """Load files from state (no-op for disk backend).

        Files are already persisted on disk, so this is a no-op.
        The thread_id parameter is accepted for protocol compatibility
        but ignored since disk storage is not thread-isolated.

        Args:
            files: Dictionary mapping file paths to file data (ignored).
            thread_id: Thread identifier (ignored for disk backend).
        """
    def get_files(self, thread_id: str = 'default') -> dict[str, Any]:
        """Get files for a specific thread (no-op for disk backend).

        Returns empty dict since disk backend doesn't track files in memory.
        The thread_id parameter is accepted for protocol compatibility
        but ignored.

        Args:
            thread_id: Thread identifier (ignored for disk backend).

        Returns:
            Empty dictionary.
        """
    DANGEROUS_PATTERNS: Incomplete
    def execute(self, command: str, timeout: int = 30) -> ExecuteResult:
        """Execute a shell command using subprocess.

        SECURITY: Disabled by default. Even when enabled, dangerous
        commands are blocked. Use only in trusted development environments.
        Production should use SandboxBackend (PR 007).

        Args:
            command: Shell command to execute.
            timeout: Timeout in seconds.

        Returns:
            ExecuteResult with output and exit code.
        """
