"""Marker validation and solution stripping for marimo notebooks."""

import hashlib
import os
import re
import sys
import zipfile
from pathlib import Path


def _rel(p: Path) -> str:
    """Return a short relative path string for display."""
    try:
        return os.path.relpath(p)
    except ValueError:
        return str(p)


SOLUTION_BEGIN = "### BEGIN SOLUTION"
SOLUTION_END = "### END SOLUTION"
HIDDEN_TESTS_BEGIN = "### BEGIN HIDDEN TESTS"
HIDDEN_TESTS_END = "### END HIDDEN TESTS"
SUBMIT_MARKER = "# === MOGRADER: SUBMIT ==="

_SIMPLE_NAME_RE = re.compile(r"^[a-zA-Z_]\w*$")
_ASSIGN_RE = re.compile(r"^\s*([a-zA-Z_]\w*)\s*=")
# Matches simple and tuple unpacking: "x = ...", "a, b = ...", "(a, b) = ..."
_TUPLE_ASSIGN_RE = re.compile(r"^\s*\(?([a-zA-Z_]\w*(?:\s*,\s*[a-zA-Z_]\w*)*)\)?\s*=")


def _extract_assigned_names(line: str) -> list[str]:
    """Extract all variable names from an assignment LHS (simple or tuple)."""
    m = _TUPLE_ASSIGN_RE.match(line)
    if not m:
        return []
    return [n.strip() for n in m.group(1).split(",") if n.strip()]


def _extract_return_names(line: str) -> list[str]:
    """Extract simple variable names from a return statement.

    Returns names only when every component of the return expression is a
    bare identifier (e.g. ``return x`` or ``return x, y``).  Complex
    expressions like ``return x.value + 1`` yield an empty list.
    """
    m = re.match(r"^\s*return\s+(.+)$", line)
    if not m:
        return []
    expr = m.group(1).strip()
    # Single name: return result
    if _SIMPLE_NAME_RE.match(expr):
        return [expr]
    # Tuple with optional parens: return (x, y) or return x, y
    if expr.startswith("(") and expr.endswith(")"):
        expr = expr[1:-1].strip()
    if expr.endswith(","):
        expr = expr[:-1].strip()
    parts = [p.strip() for p in expr.split(",")]
    if all(_SIMPLE_NAME_RE.match(p) for p in parts):
        return parts
    return []


def _find_sentinel_vars(lines: list[str]) -> dict[int, list[str]]:
    """Identify variables needing sentinels for each solution block.

    Returns a mapping from solution-block index (0-based count of BEGIN
    SOLUTION markers) to the list of variable names that should be
    initialised as ``name = ...`` before the ``# YOUR CODE HERE``
    placeholder.

    A variable needs a sentinel when it appears in a ``return`` statement
    after the corresponding END SOLUTION but is **not** already assigned
    between the beginning of the enclosing scope and the BEGIN SOLUTION
    marker.
    """
    # First pass: locate all solution blocks
    blocks: list[tuple[int, int, str]] = []  # (begin_idx, end_idx, indent)
    stack_begin: int | None = None
    stack_indent = ""
    for i, line in enumerate(lines):
        stripped = line.strip()
        if stripped == SOLUTION_BEGIN:
            stack_begin = i
            stack_indent = line[: len(line) - len(line.lstrip())]
        elif stripped == SOLUTION_END and stack_begin is not None:
            blocks.append((stack_begin, i, stack_indent))
            stack_begin = None

    result: dict[int, list[str]] = {}
    for block_idx, (begin, end, indent) in enumerate(blocks):
        # Scan forward from END SOLUTION to find return statements
        # Stop at next BEGIN SOLUTION, end of file, or a line at lower
        # indentation (different scope).
        return_names: list[str] = []
        for j in range(end + 1, len(lines)):
            fwd = lines[j]
            fwd_stripped = fwd.strip()
            if not fwd_stripped:
                continue
            if fwd_stripped == SOLUTION_BEGIN:
                break
            # Stop when we leave the scope (lower indentation)
            fwd_indent = fwd[: len(fwd) - len(fwd.lstrip())]
            if len(fwd_indent) < len(indent):
                break
            names = _extract_return_names(fwd)
            return_names.extend(names)
            if names or fwd_stripped.startswith("return"):
                break  # found the return, stop scanning

        if not return_names:
            continue

        # Collect names already assigned before BEGIN SOLUTION in this scope
        pre_assigned: set[str] = set()
        for j in range(begin - 1, -1, -1):
            prev = lines[j]
            prev_stripped = prev.strip()
            if not prev_stripped:
                continue
            # Stop scanning when we leave the enclosing scope
            prev_indent = prev[: len(prev) - len(prev.lstrip())]
            if prev_stripped and len(prev_indent) < len(indent):
                break
            for _name in _extract_assigned_names(prev):
                pre_assigned.add(_name)

        orphaned = [n for n in return_names if n not in pre_assigned]
        if orphaned:
            result[block_idx] = orphaned

    return result


def validate_markers(lines: list[str], filepath: str) -> list[str]:
    """Check that all solution and hidden-test markers are properly paired.

    Returns a list of error messages (empty if valid).
    """
    errors = []
    in_solution = False
    in_hidden = False
    sol_start_line = 0
    hidden_start_line = 0

    for i, line in enumerate(lines, 1):
        stripped = line.strip()

        if stripped == SOLUTION_BEGIN:
            if in_solution:
                errors.append(
                    f"{filepath}:{i}: nested {SOLUTION_BEGIN} "
                    f"(previous opened at line {sol_start_line})"
                )
            if in_hidden:
                errors.append(
                    f"{filepath}:{i}: {SOLUTION_BEGIN} inside hidden tests block "
                    f"(opened at line {hidden_start_line})"
                )
            in_solution = True
            sol_start_line = i

        elif stripped == SOLUTION_END:
            if not in_solution:
                errors.append(
                    f"{filepath}:{i}: {SOLUTION_END} without matching {SOLUTION_BEGIN}"
                )
            in_solution = False

        elif stripped == HIDDEN_TESTS_BEGIN:
            if in_hidden:
                errors.append(
                    f"{filepath}:{i}: nested {HIDDEN_TESTS_BEGIN} "
                    f"(previous opened at line {hidden_start_line})"
                )
            if in_solution:
                errors.append(
                    f"{filepath}:{i}: {HIDDEN_TESTS_BEGIN} inside solution block "
                    f"(opened at line {sol_start_line})"
                )
            in_hidden = True
            hidden_start_line = i

        elif stripped == HIDDEN_TESTS_END:
            if not in_hidden:
                errors.append(
                    f"{filepath}:{i}: {HIDDEN_TESTS_END} without matching "
                    f"{HIDDEN_TESTS_BEGIN}"
                )
            in_hidden = False

    if in_solution:
        errors.append(f"{filepath}:{sol_start_line}: unclosed {SOLUTION_BEGIN}")
    if in_hidden:
        errors.append(f"{filepath}:{hidden_start_line}: unclosed {HIDDEN_TESTS_BEGIN}")

    return errors


def strip_solutions(lines: list[str]) -> list[str]:
    """Remove solution blocks from source lines.

    Lines between BEGIN SOLUTION / END SOLUTION are replaced with
    ``# YOUR CODE HERE`` and ``pass`` at the correct indentation.
    The ``pass`` ensures empty function bodies remain syntactically valid.

    When a ``return`` statement after END SOLUTION references simple
    variable names that are only defined inside the removed solution block,
    sentinel assignments (``name = ...``) are inserted before the
    placeholder so the return does not raise :class:`NameError`.
    """
    sentinels = _find_sentinel_vars(lines)

    output = []
    in_solution = False
    solution_indent = ""
    block_idx = -1

    for line in lines:
        stripped = line.strip()

        if stripped == SOLUTION_BEGIN:
            in_solution = True
            block_idx += 1
            solution_indent = line[: len(line) - len(line.lstrip())]
            continue

        if stripped == SOLUTION_END:
            in_solution = False
            # Insert sentinels for orphaned return variables
            for name in sentinels.get(block_idx, []):
                output.append(f"{solution_indent}{name} = ...\n")
            output.append(f"{solution_indent}# YOUR CODE HERE\n")
            output.append(f"{solution_indent}pass\n")
            continue

        if not in_solution:
            output.append(line)

    return output


def count_markers(lines: list[str]) -> int:
    """Count solution blocks."""
    return sum(1 for line in lines if line.strip() == SOLUTION_BEGIN)


def count_hidden_markers(lines: list[str]) -> int:
    """Count hidden test blocks."""
    return sum(1 for line in lines if line.strip() == HIDDEN_TESTS_BEGIN)


def strip_hidden_tests(lines: list[str]) -> list[str]:
    """Remove hidden test blocks from source lines.

    Lines between BEGIN HIDDEN TESTS / END HIDDEN TESTS are replaced with
    a single ``# HIDDEN TESTS`` placeholder comment at the correct indentation.
    """
    output = []
    in_hidden = False
    hidden_indent = ""

    for line in lines:
        stripped = line.strip()

        if stripped == HIDDEN_TESTS_BEGIN:
            in_hidden = True
            hidden_indent = line[: len(line) - len(line.lstrip())]
            continue

        if stripped == HIDDEN_TESTS_END:
            in_hidden = False
            output.append(f"{hidden_indent}# HIDDEN TESTS\n")
            continue

        if not in_hidden:
            output.append(line)

    return output


def extract_hidden_tests(lines: list[str]) -> list[tuple[str, list[str]]]:
    """Extract hidden test blocks as ``(indent, lines)`` tuples.

    Each tuple contains the indentation prefix and the list of lines
    (with their original indentation) from one hidden-test block.
    Used during autograde to reinject hidden tests into submitted notebooks.
    """
    blocks: list[tuple[str, list[str]]] = []
    current_lines: list[str] = []
    in_hidden = False
    indent = ""

    for line in lines:
        stripped = line.strip()

        if stripped == HIDDEN_TESTS_BEGIN:
            in_hidden = True
            indent = line[: len(line) - len(line.lstrip())]
            current_lines = []
            continue

        if stripped == HIDDEN_TESTS_END:
            in_hidden = False
            blocks.append((indent, current_lines))
            continue

        if in_hidden:
            current_lines.append(line)

    return blocks


def convert_markdown_cells(lines: list[str]) -> list[str]:
    """Convert stripped markdown answer cells to editable mo.md() blocks.

    After ``strip_solutions()``, markdown answer cells look like::

        response_text = "placeholder text"
        # YOUR CODE HERE
        pass
        mo.md(response_text)

    This function converts them to::

        mo.md(r\"\"\"
        placeholder text
        \"\"\")

    so that students see a clean editable markdown cell instead of ugly
    placeholder code.
    """
    output = []
    i = 0
    while i < len(lines):
        # Try to match the 4-line pattern
        if i + 3 < len(lines):
            line0 = lines[i]
            line1 = lines[i + 1]
            line2 = lines[i + 2]
            line3 = lines[i + 3]
            m = re.match(r'^(\s*)response_text\s*=\s*["\'](.+?)["\']\s*$', line0)
            if (
                m
                and line1.strip() == "# YOUR CODE HERE"
                and line2.strip() == "pass"
                and line3.strip() == "mo.md(response_text)"
            ):
                indent = m.group(1)
                placeholder = m.group(2)
                output.append(f'{indent}mo.md(r"""\n')
                output.append(f"{indent}{placeholder}\n")
                output.append(f'{indent}""")\n')
                i += 4
                continue
        output.append(lines[i])
        i += 1
    return output


def build_submit_cell(server_url: str, assignment_name: str) -> str:
    """Build a submit cell that uses ``mograder.remote.submit()``.

    Returns source text for two marimo cells (username input + submit action).
    """
    return f'''\

@app.cell(hide_code=True)
def _(mo):
    {SUBMIT_MARKER}
    import os as _os
    mo.stop(_os.environ.get("MOGRADER_DASHBOARD") == "1")
    submit_username = mo.ui.text(label="Username", placeholder="Enter your username")
    submit_btn = mo.ui.run_button(label="Submit")
    mo.hstack([submit_username, submit_btn])
    return (submit_btn, submit_username)


@app.cell(hide_code=True)
def _(submit_btn, submit_username, mo):
    mo.stop(not submit_btn.value or not submit_username.value)
    from mograder.remote import submit as submit_fn
    submit_result = submit_fn("{server_url}", "{assignment_name}", __file__, submit_username.value)
    mo.callout(mo.md(f"**Submitted!** Status: {{submit_result}}"), kind="success")
    return


'''


def _inject_before_main(lines: list[str], cell_text: str) -> list[str]:
    """Insert *cell_text* before the ``if __name__`` guard."""
    insert_idx = None
    for i, line in enumerate(lines):
        if line.strip().startswith("if __name__"):
            insert_idx = i
            break
    if insert_idx is None:
        insert_idx = len(lines)
    return lines[:insert_idx] + cell_text.splitlines(keepends=True) + lines[insert_idx:]


def _inject_hidden_tests_metadata(lines: list[str]) -> list[str]:
    """Insert ``mograder-hidden-tests = true`` into a PEP 723 script block.

    If no PEP 723 block is found, the lines are returned unchanged.
    """
    close_idx = None
    in_block = False
    for i, line in enumerate(lines):
        stripped = line.strip()
        if stripped == "# /// script":
            in_block = True
        elif in_block and stripped == "# ///":
            close_idx = i
            break

    if close_idx is None:
        return lines

    new_line = "# mograder-hidden-tests = true\n"
    return lines[:close_idx] + [new_line] + lines[close_idx:]


def _inject_assignment_metadata(lines: list[str], assignment_name: str) -> list[str]:
    """Insert ``mograder-assignment`` into a PEP 723 script block.

    If no PEP 723 block is found, the lines are returned unchanged.
    """
    # Find the closing # /// line
    close_idx = None
    in_block = False
    for i, line in enumerate(lines):
        stripped = line.strip()
        if stripped == "# /// script":
            in_block = True
        elif in_block and stripped == "# ///":
            close_idx = i
            break

    if close_idx is None:
        return lines

    new_line = f'# mograder-assignment = "{assignment_name}"\n'
    return lines[:close_idx] + [new_line] + lines[close_idx:]


def _hash_cell(code: str) -> str:
    """Return first 8 hex chars of SHA-256 of the stripped cell code."""
    return hashlib.sha256(code.strip().encode()).hexdigest()[:8]


def _inject_cell_hashes(text: str) -> str:
    """Compute hashes of non-solution cells and inject into PEP 723 block.

    Non-solution cells are those NOT containing ``# YOUR CODE HERE``.
    """
    from marimo._convert.converters import MarimoConvert

    ir = MarimoConvert.from_py(text).to_ir()
    hashes = []
    for cell in ir.cells:
        if "# YOUR CODE HERE" not in cell.code:
            hashes.append(_hash_cell(cell.code))

    if not hashes:
        return text

    lines = text.splitlines(keepends=True)
    close_idx = None
    in_block = False
    for i, line in enumerate(lines):
        stripped = line.strip()
        if stripped == "# /// script":
            in_block = True
        elif in_block and stripped == "# ///":
            close_idx = i
            break

    if close_idx is None:
        return text

    csv = ",".join(hashes)
    new_line = f'# mograder-cell-hashes = "{csv}"\n'
    lines = lines[:close_idx] + [new_line] + lines[close_idx:]
    return "".join(lines)


def process_file(
    source: Path,
    output_dir: Path | None,
    dry_run: bool = False,
    validate_only: bool = False,
    submit_url: str | None = None,
) -> bool:
    """Process a single notebook file. Returns True on success."""
    lines = source.read_text().splitlines(keepends=True)

    errors = validate_markers(lines, str(source))
    if errors:
        for err in errors:
            print(f"ERROR: {err}", file=sys.stderr)
        return False

    n_solutions = count_markers(lines)
    if n_solutions == 0:
        print(f"SKIP: {source} (no solution markers found)")
        return True

    if validate_only:
        print(f"VALID: {source} ({n_solutions} solution blocks)")
        return True

    n_hidden = count_hidden_markers(lines)
    student_lines = strip_solutions(lines)
    student_lines = strip_hidden_tests(student_lines)
    student_lines = convert_markdown_cells(student_lines)

    if submit_url:
        assignment_name = source.parent.name
        submit_cell = build_submit_cell(submit_url, assignment_name)
        student_lines = _inject_before_main(student_lines, submit_cell)

    if dry_run:
        n_removed = len(lines) - len(student_lines)
        msg = f"DRY-RUN: {_rel(source)} → {n_solutions} solution blocks stripped"
        if n_hidden:
            msg += f", {n_hidden} hidden test blocks stripped"
        msg += f", {n_removed} lines removed"
        print(msg)
        return True

    if output_dir is None:
        output_dir = Path("release")
    output_dir.mkdir(parents=True, exist_ok=True)
    dest = output_dir / source.name

    # Inject assignment metadata into PEP 723 block
    assignment_name = source.parent.name
    student_lines = _inject_assignment_metadata(student_lines, assignment_name)

    # Inject hidden-tests flag if any hidden test blocks were stripped
    if n_hidden > 0:
        student_lines = _inject_hidden_tests_metadata(student_lines)

    dest.write_text("".join(student_lines))

    # Inject cell hashes (needs parsed marimo IR, so operates on written text)
    text = dest.read_text()
    text = _inject_cell_hashes(text)
    dest.write_text(text)

    msg = f"OK: {_rel(source)} → {_rel(dest)} ({n_solutions} solution blocks stripped"
    if n_hidden:
        msg += f", {n_hidden} hidden test blocks stripped"
    msg += ")"
    print(msg)
    return True


def build_release_zip(release_dir: Path) -> Path | None:
    """Create a zip of student-facing release files, excluding artifacts.

    Returns *None* (and removes any stale zip) when the directory contains
    only a single file — a zip that wraps one file adds no value.

    Uses a fixed timestamp so the zip is reproducible across runs.
    """
    zip_path = release_dir / f"{release_dir.name}.zip"
    _EXCLUDE_SUFFIXES = {".html", ".zip"}

    # Collect candidate files
    candidates = sorted(
        f
        for f in release_dir.iterdir()
        if f.is_file()
        and not f.name.startswith(".")
        and f.suffix not in _EXCLUDE_SUFFIXES
    )

    # Skip zip when there's only a single file (e.g. just the .py notebook)
    if len(candidates) <= 1:
        zip_path.unlink(missing_ok=True)
        return None

    # Fixed date_time for reproducible output (2025-01-01 00:00:00)
    _FIXED_TIME = (2025, 1, 1, 0, 0, 0)
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for f in candidates:
            info = zipfile.ZipInfo(f.name, date_time=_FIXED_TIME)
            info.compress_type = zipfile.ZIP_DEFLATED
            zf.writestr(info, f.read_bytes())
    return zip_path
