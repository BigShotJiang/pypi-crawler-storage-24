"""Shared fixtures for MongoDB adapter tests."""

from __future__ import annotations

import os

import pytest
from pymongo import MongoClient


@pytest.fixture
def db():
    port = os.environ.get("MONGO_PORT", "27017")
    client = MongoClient(f"mongodb://localhost:{port}")
    database = client["test_db"]
    yield database
    client.drop_database("test_db")
    client.close()
