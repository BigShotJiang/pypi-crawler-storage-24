"""db-test-helpers-mongo: MongoDB adapter for db-test-helpers."""

from db_test_helpers.mongo._adapter import MongoAdapter

__all__ = ["MongoAdapter"]
