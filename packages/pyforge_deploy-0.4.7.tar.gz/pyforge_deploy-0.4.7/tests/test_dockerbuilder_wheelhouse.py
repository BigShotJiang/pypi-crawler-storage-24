import subprocess
from pathlib import Path
from typing import Any, cast

import pytest

from pyforge_deploy.builders.docker import DockerBuilder


def test_build_wheelhouse_creates_wheels(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    # Arrange: create temp project dir and fake requirements files
    monkeypatch.chdir(tmp_path)
    req: Path = tmp_path / "requirements-docker.txt"
    req.write_text("requests\n")
    wheels_dir: Path = tmp_path / "wheels"

    calls: dict[str, int] = {"count": 0}

    def fake_run(
        cmd: Any, check: bool = True, cwd: str | None = None, **kwargs: Any
    ) -> Any:
        # create a dummy wheel file to simulate pip wheel
        calls["count"] += 1
        wheels_dir.mkdir(exist_ok=True)
        wheel: Path = wheels_dir / f"dummy-{calls['count']}.whl"
        wheel.write_text("binary")

        class R:
            returncode = 0

        return R()

    monkeypatch.setattr(subprocess, "run", fake_run)

    db = DockerBuilder(dry_run=False)
    # run wheelhouse builder
    report: dict[str, Any] = {"final_list": ["requests"], "heavy_hitters": []}
    cast(Any, db)._build_wheelhouse(report)

    assert wheels_dir.exists()
    assert any(wheels_dir.iterdir())
