//! Shared test helpers for the nereids-pipeline crate.
//!
//! TD-5: These builders use single-resonance data by design — they test
//! pipeline/fitting logic (convergence, spatial map)
//! independently of full ENDF evaluations.  Multi-resonance physics
//! accuracy is covered by the SAMMY test harness in nereids-physics.

use nereids_core::types::Isotope;
use nereids_endf::resonance::{
    LGroup, Resonance, ResonanceData, ResonanceFormalism, ResonanceRange,
};

/// Build a synthetic single-resonance `ResonanceData` for any isotope.
///
/// Used for group fitting tests where distinct isotopes with different
/// resonance energies are needed.
pub fn synthetic_single_resonance(z: u32, a: u32, awr: f64, energy: f64) -> ResonanceData {
    ResonanceData {
        isotope: Isotope::new(z, a).unwrap(),
        za: z * 1000 + a,
        awr,
        ranges: vec![ResonanceRange {
            energy_low: 1e-5,
            energy_high: 1e4,
            resolved: true,
            formalism: ResonanceFormalism::ReichMoore,
            target_spin: 0.0,
            scattering_radius: 5.0,
            naps: 1,
            l_groups: vec![LGroup {
                l: 0,
                awr,
                apl: 0.0,
                qx: 0.0,
                lrx: 0,
                resonances: vec![Resonance {
                    energy,
                    j: 0.5,
                    gn: 1e-3,
                    gg: 1e-2,
                    gfa: 0.0,
                    gfb: 0.0,
                }],
            }],
            rml: None,
            urr: None,
            ap_table: None,
            r_external: vec![],
        }],
    }
}

/// Build a minimal U-238 `ResonanceData` with a single resonance at 6.674 eV.
///
/// Used across pipeline, spatial, and fitting tests to avoid duplicating
/// the same constructor.
pub fn u238_single_resonance() -> ResonanceData {
    ResonanceData {
        isotope: Isotope::new(92, 238).unwrap(),
        za: 92238,
        awr: 236.006,
        ranges: vec![ResonanceRange {
            energy_low: 1e-5,
            energy_high: 1e4,
            resolved: true,
            formalism: ResonanceFormalism::ReichMoore,
            target_spin: 0.0,
            scattering_radius: 9.4285,
            naps: 1,
            l_groups: vec![LGroup {
                l: 0,
                awr: 236.006,
                apl: 0.0,
                qx: 0.0,
                lrx: 0,
                resonances: vec![Resonance {
                    energy: 6.674,
                    j: 0.5,
                    gn: 1.493e-3,
                    gg: 23.0e-3,
                    gfa: 0.0,
                    gfb: 0.0,
                }],
            }],
            rml: None,
            urr: None,
            ap_table: None,
            r_external: vec![],
        }],
    }
}
