"""
nextcloud-jupyter: Read and upload files to/from Nextcloud in Jupyter notebooks

This package provides seamless integration between Nextcloud and Jupyter notebooks,
allowing you to read files directly from Nextcloud without downloading them locally,
and upload files/folders to Nextcloud.

Supported file types:
- Data: CSV, Excel, JSON, Parquet, Feather, HDF5
- Arrays: NumPy (.npy), Compressed NumPy (.npz)
- LiDAR/Point Clouds: LAS (.las), LAZ (.laz)
- Geospatial: Shapefile (.shp), GeoJSON, KML, KMZ, NetCDF
- Images: PNG, JPEG, TIFF, etc.
- Archives: ZIP, TAR, TAR.GZ
- Config: YAML, XML
- Python: Pickle files
- And more...

Usage:
    from nextcloud_esamaap import NextcloudReader, NextcloudUploader
    
    # Read files from Nextcloud
    reader = NextcloudReader(
        nextcloud_url="https://cloud.example.com",
        username="your_username",
        app_password="your_app_password"
    )
    
    df = reader.read_csv('/inputs/data.csv')
    
    # Upload files to Nextcloud
    uploader = NextcloudUploader(
        nextcloud_url="https://cloud.example.com",
        username="your_username",
        app_password="your_app_password"
    )
    
    uploader.upload_file("local.csv", "/remote/data.csv")
"""

__version__ = "0.1.0"
__author__ = "Joseph Melizza"
__email__ = "joseph.melizza@serco.com"

from .reader import NextcloudReader
from .uploader import NextcloudUploader

__all__ = [
    "NextcloudReader",
    "NextcloudUploader",
    "__version__",
]
