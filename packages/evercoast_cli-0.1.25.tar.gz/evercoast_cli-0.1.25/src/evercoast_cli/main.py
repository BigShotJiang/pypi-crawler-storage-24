"""Evercoast CLI entry point.

Commands:
    evercoast login [--staging]
    evercoast logout [--staging]
    evercoast upload <path> [options]
    evercoast take-upload <path> [<path>...] [options]
"""

import os
import sys

import click
from rich.console import Console

from . import __version__
from .api import APIError, fetch_s3_credentials, get_s3_client, login, setup_aws_cli_profile
from .config import Config, DEFAULT_PROFILE, PRODUCTION_API_URL, STAGING_API_URL
from .upload import (
    TYPE_LABELS,
    check_network,
    compute_upload_plan,
    console as upload_console,
    format_size,
    get_remote_files,
    print_dry_run_details,
    print_upload_summary,
    resolve_destination,
    upload_files,
    walk_local_files,
)

console = Console()

# Marker comment used to identify our line in shell rc files
_COMPLETION_MARKER = "# Evercoast CLI shell completion"


@click.group()
@click.version_option(__version__, prog_name="evercoast")
def cli():
    """Evercoast CLI — upload files and takes to Cloudbreak.

    \b
    Quick start:
      1. evercoast login               (one-time setup)
      2. evercoast upload <path>        (upload raw files to S3)
      3. evercoast take-upload <path>   (upload a processed take)

    \b
    Features:
      • Resumable uploads — interrupted uploads pick up where they left off
      • Checksum validation — SHA256 integrity checks on every file
      • Automatic retries — recovers from network drops indefinitely
      • Progress tracking — per-file and overall progress bars
      • Batch take uploads — point at a folder to upload all takes inside
      • Cross-platform — works on macOS, Linux, and Windows

    \b
    Upload modes:
      upload       Upload files/directories to client-uploads/ (unstructured)
      take-upload  Create Cloudbreak Takes with metadata, preview, and
                   chunked raw frames. Accepts single takes, multiple paths,
                   or a parent directory for auto-discovery

    \b
    Update to latest version:
      pip install --upgrade evercoast-cli
      pipx upgrade evercoast-cli          (if installed via pipx)
    """
    pass


def _install_shell_completion():
    """Install shell tab-completion for the evercoast command.

    Writes a completion script to ~/.evercoast/ and adds a source line
    to the user's shell rc file (~/.zshrc or ~/.bashrc) if not already present.
    """
    import subprocess
    from pathlib import Path

    config_dir = Path.home() / ".evercoast"
    config_dir.mkdir(parents=True, exist_ok=True)

    # Detect shell
    shell = os.environ.get("SHELL", "")
    if "zsh" in shell:
        shell_type = "zsh"
        rc_file = Path.home() / ".zshrc"
        env_var = "_EVERCOAST_COMPLETE=zsh_source"
        completion_file = config_dir / "_completion.zsh"
    elif "bash" in shell:
        shell_type = "bash"
        rc_file = Path.home() / ".bashrc"
        env_var = "_EVERCOAST_COMPLETE=bash_source"
        completion_file = config_dir / "_completion.bash"
    else:
        return  # Unsupported shell, skip silently

    # Generate completion script
    try:
        result = subprocess.run(
            ["evercoast"],
            env={**os.environ, env_var.split("=")[0]: env_var.split("=")[1]},
            capture_output=True, text=True, timeout=5,
        )
        if result.returncode != 0 or not result.stdout.strip():
            return
    except (subprocess.TimeoutExpired, FileNotFoundError):
        return

    completion_file.write_text(result.stdout)

    # Add source line to rc file if not already present
    source_line = f'{_COMPLETION_MARKER}\n[[ -f "{completion_file}" ]] && source "{completion_file}"\n'

    if rc_file.exists():
        rc_content = rc_file.read_text()
        if _COMPLETION_MARKER in rc_content:
            return  # Already installed
    else:
        rc_content = ""

    with open(rc_file, "a") as f:
        f.write(f"\n{source_line}")


@cli.command()
@click.option("--staging", is_flag=True, hidden=True)
def login(staging):
    """Authenticate with Evercoast and configure upload credentials.

    Run this once to set up your machine for uploads. You'll be prompted
    for your Evercoast email and password. Credentials are saved locally
    and refresh automatically — you only need to re-run this if you
    change your Evercoast password.

    \b
    What happens during login:
      1. Authenticates with your Evercoast account
      2. Retrieves your company's S3 bucket configuration
      3. Saves credentials to ~/.evercoast/config.toml
      4. Optionally configures an AWS CLI profile (if AWS CLI is installed)

    \b
    Requirements:
      • An active Evercoast account
      • S3 direct upload enabled for your company (contact Evercoast support)

    \b
    The AWS CLI profile is a bonus — it lets you use standard AWS tools
    (like 'aws s3 cp') with your Evercoast bucket if you prefer. The
    Evercoast CLI itself does not require the AWS CLI.
    """
    config = Config()
    api_url = STAGING_API_URL if staging else PRODUCTION_API_URL
    profile_name = config.get_profile_name(staging)

    console.print()
    console.print("[bold cyan]Evercoast Upload — Authentication[/]")
    console.print("=" * 50)
    console.print()

    # Prompt for credentials
    email = click.prompt("Evercoast Email")
    if not email.strip():
        console.print("[red]Error: Email cannot be empty[/]")
        sys.exit(1)

    password = click.prompt("Evercoast Password", hide_input=True)
    if not password:
        console.print("[red]Error: Password cannot be empty[/]")
        sys.exit(1)

    console.print()
    console.print("[cyan]Authenticating...[/]")

    # Login
    try:
        from .api import login as api_login
        token = api_login(api_url, email, password)
    except APIError as e:
        console.print(f"[red]Error: {e}[/]")
        sys.exit(1)

    console.print("[green]Authentication successful![/]")
    console.print()
    console.print("[cyan]Fetching S3 upload credentials...[/]")

    # Get S3 credentials (also validates the token and gets bucket info)
    try:
        s3_data = fetch_s3_credentials(api_url, token)
    except APIError as e:
        console.print(f"[red]Error: {e}[/]")
        sys.exit(1)

    bucket = s3_data["bucket"]
    region = s3_data.get("region", "us-east-1")
    upload_path = s3_data.get("upload_path", "client-uploads/")

    # Save config
    config.save_profile(
        profile=profile_name,
        api_url=api_url,
        token=token,
        bucket=bucket,
        region=region,
        upload_path=upload_path,
    )
    # Set this as the active profile so subsequent commands use it
    config.set_active_profile(profile_name)

    console.print("[green]Credentials retrieved successfully![/]")
    console.print()
    console.print("=" * 50)
    console.print(f"  Bucket:      {bucket}")
    console.print(f"  Region:      {region}")
    console.print(f"  Upload Path: {upload_path}")
    console.print("=" * 50)
    console.print()

    # Set up AWS CLI profile as a bonus
    aws_profile = f"evercoast-{profile_name}" if profile_name != "default" else "evercoast"
    profile_ok = setup_aws_cli_profile(api_url, token, region, aws_profile)

    if profile_ok:
        console.print(
            f"[green]AWS CLI profile '{aws_profile}' configured with auto-refreshing credentials.[/]"
        )
        console.print(
            f"  You can also use: aws s3 cp <file> s3://{bucket}/{upload_path} --profile {aws_profile}"
        )
        console.print()

    # Install shell tab-completion
    _install_shell_completion()

    console.print("[bold]You're all set![/]")
    console.print("  Upload files:  evercoast upload <path>")
    console.print("  Upload a take: evercoast take-upload <path>")
    console.print()


@cli.command()
@click.option("--staging", is_flag=True, hidden=True)
def logout(staging):
    """Remove saved credentials from this machine.

    Deletes the stored authentication token and bucket configuration
    for the current environment. You'll need to run 'evercoast login'
    again to use the CLI after logging out.
    """
    config = Config()
    profile_name = config.get_profile_name(staging)

    if config.delete_profile(profile_name):
        # Clear active profile if it matches
        if config.get_active_profile() == profile_name:
            config.set_active_profile(DEFAULT_PROFILE)
        console.print(f"[green]Logged out successfully.[/]")
    else:
        console.print("[yellow]No credentials found — already logged out.[/]")


@cli.command()
@click.argument("path", required=False, default=None, type=click.Path())
@click.option(
    "--type", "data_type",
    type=click.Choice(["takes", "renders", "calibrations", "registrations", "other"], case_sensitive=False),
    help="Data type that determines the upload destination. "
         "'takes' routes to client-uploads/takes/<name>/, "
         "'renders' routes to client-uploads/renders/<name>/, "
         "'calibrations' routes to client-uploads/calibrations/<name>/, "
         "'registrations' routes to client-uploads/registrations/<name>/, "
         "'other' routes to client-uploads/<name>/. "
         "If omitted, you will be prompted to choose interactively.",
)
@click.option(
    "--to", "custom_dest",
    help="Custom destination path within your upload area. "
         "Overrides --type routing. For example, --to my/custom/path "
         "uploads to client-uploads/my/custom/path/.",
)
@click.option("--staging", is_flag=True, hidden=True)
@click.option(
    "--dry-run", is_flag=True,
    help="Preview what would be uploaded without actually uploading. "
         "Shows a file-by-file list with sizes and destinations.",
)
@click.option(
    "--no-checksum", is_flag=True,
    help="Disable SHA256 checksum validation. By default, checksums are "
         "calculated locally and verified server-side to ensure data "
         "integrity. Only disable this if uploads are unusually slow.",
)
@click.option(
    "--exclude", multiple=True,
    help="Exclude files matching a glob pattern. Can be specified multiple "
         "times. Examples: --exclude '*.tmp' --exclude '.DS_Store'",
)
@click.option(
    "--yes", "-y", is_flag=True,
    help="Skip the confirmation prompt for large uploads (>1 GB).",
)
def upload(path, data_type, custom_dest, staging, dry_run, no_checksum, exclude, yes):
    """Upload files or directories to your company's S3 bucket.

    PATH can be a single file or a directory. When uploading a directory,
    all files within it (including subdirectories) are uploaded, preserving
    the folder structure.

    \b
    Resumable uploads:
      Directories are synced by comparing local files against what already
      exists at the destination. If an upload is interrupted (Ctrl+C,
      network drop, laptop sleep), simply re-run the same command — only
      the remaining files will be uploaded. Already-uploaded files are
      skipped automatically based on filename and size matching.

    \b
    Data types and routing:
      --type takes           →  client-uploads/takes/<folder-name>/
      --type renders         →  client-uploads/renders/<folder-name>/
      --type calibrations    →  client-uploads/calibrations/<folder-name>/
      --type registrations   →  client-uploads/registrations/<folder-name>/
      --type other           →  client-uploads/<folder-name>/
      --to custom/path       →  client-uploads/custom/path/

    \b
    Network resilience:
      If the network drops during an upload, the CLI will:
        1. Detect the failure
        2. Wait for connectivity to return
        3. Retry with increasing delays (up to 5 min between attempts)
      Retries continue indefinitely until the upload succeeds or you
      cancel with Ctrl+C. If you cancel, re-run the same command to
      resume — already-uploaded files will be skipped.

    \b
    Examples:
      evercoast upload ./session-42/ --type takes
      evercoast upload ./meshes/ --type renders
      evercoast upload capture.zip --type other
      evercoast upload ./data/ --to custom/path
      evercoast upload ./data/ --dry-run --exclude "*.tmp"
      evercoast upload ./large-dataset/ --type takes --yes
    """
    # Prompt for path if not provided
    if path is None:
        path = click.prompt("Path to file or directory")

    # Expand ~ and resolve path
    path = os.path.expanduser(path)

    # Validate path exists
    if not os.path.exists(path):
        console.print(f"[red]Error: Path '{path}' does not exist.[/]")
        sys.exit(1)

    config = Config()
    profile_name = config.get_profile_name(staging)
    profile = config.get_profile(profile_name)

    # Pre-flight: check config exists
    if not profile:
        console.print(
            "[red]Error: Not configured. Run 'evercoast login' first.[/]"
        )
        sys.exit(1)

    api_url = profile["api_url"]
    is_staging = STAGING_API_URL in api_url
    env_label = "[bold yellow]STAGING[/]" if is_staging else "[bold green]PRODUCTION[/]"
    console.print(f"\n[bold cyan]Evercoast — Upload[/]  ({env_label})")
    token = profile["token"]
    bucket = profile["bucket"]
    region = profile["region"]
    upload_path = profile.get("upload_path", "client-uploads/")

    # Pre-flight: check source path
    source_path = os.path.abspath(path)
    is_dir = os.path.isdir(source_path)

    # Data type selection
    if custom_dest:
        # --to overrides --type, use "other" as placeholder
        data_type = "other"
    elif data_type is None:
        data_type = _prompt_data_type(config, profile_name)

    # Resolve destination
    destination = resolve_destination(
        data_type=data_type,
        source_path=source_path,
        upload_path=upload_path,
        is_dir=is_dir,
        custom_dest=custom_dest,
    )

    # Build upload plan
    use_checksum = not no_checksum
    exclude_list = list(exclude) if exclude else None

    if is_dir:
        console.print("[cyan]Scanning local files...[/]")
        local_files = walk_local_files(source_path, exclude_list)

        if not local_files:
            console.print("[yellow]No files found to upload.[/]")
            sys.exit(0)

        console.print("[cyan]Comparing with remote...[/]")

        try:
            s3_client = get_s3_client(api_url, token, region)
            remote_files = get_remote_files(s3_client, bucket, destination)
        except APIError as e:
            console.print(f"[red]Error: {e}[/]")
            sys.exit(1)

        to_upload, skipped = compute_upload_plan(source_path, remote_files, exclude_list)
    else:
        # Single file upload
        filename = os.path.basename(source_path)
        file_size = os.path.getsize(source_path)

        try:
            s3_client = get_s3_client(api_url, token, region)
            # Check if file already exists remotely
            remote_files = get_remote_files(s3_client, bucket, destination)
        except APIError as e:
            console.print(f"[red]Error: {e}[/]")
            sys.exit(1)

        # For single files, destination is the full key (not a prefix)
        # Check if already uploaded
        if filename in remote_files and remote_files[filename] == file_size:
            to_upload = []
            skipped = 1
        else:
            to_upload = [(source_path, filename, file_size)]
            skipped = 0

        # Adjust destination to be a prefix for display
        if not destination.endswith("/"):
            destination = destination.rsplit("/", 1)[0] + "/" if "/" in destination else ""

    # Nothing to upload
    if not to_upload:
        console.print()
        console.print(
            f"[green]Nothing to upload — all {skipped} files already exist at destination.[/]"
        )
        console.print(f"  Destination: s3://{bucket}/{destination}")
        console.print()
        sys.exit(0)

    # Print summary
    print_upload_summary(
        source=source_path,
        destination=destination,
        bucket=bucket,
        to_upload=to_upload,
        skipped=skipped,
        use_checksum=use_checksum,
        dry_run=dry_run,
    )

    # Dry run — show details and exit
    if dry_run:
        print_dry_run_details(to_upload, destination, skipped)
        sys.exit(0)

    # Confirmation for large uploads
    total_size = sum(size for _, _, size in to_upload)
    if not yes and total_size > 1024 * 1024 * 1024:  # > 1 GB
        if not click.confirm(
            f"This is a large upload ({format_size(total_size)}). Continue?",
            default=True,
        ):
            console.print("[yellow]Upload cancelled.[/]")
            sys.exit(0)

    # Execute upload
    success = upload_files(
        s3_client=s3_client,
        bucket=bucket,
        destination=destination,
        to_upload=to_upload,
        use_checksum=use_checksum,
    )

    # Save last-used data type
    if success and data_type:
        config.set_value(profile_name, "last_type", data_type)

    sys.exit(0 if success else 1)


def _discover_takes(paths: tuple) -> list:
    """Resolve paths into a list of take directories.

    For each path:
      - If it contains .timestamp.json → it's a take directory
      - Otherwise → recursively scan for subdirectories with .timestamp.json

    Returns:
        Sorted list of absolute paths to take directories
    """
    take_dirs = []
    for p in paths:
        p = os.path.abspath(os.path.expanduser(p))

        if not os.path.exists(p):
            console.print(f"[red]Error: Path '{p}' does not exist.[/]")
            sys.exit(1)

        if not os.path.isdir(p):
            console.print(f"[red]Error: '{p}' is not a directory.[/]")
            sys.exit(1)

        if os.path.exists(os.path.join(p, ".timestamp.json")):
            take_dirs.append(p)
        else:
            # Scan subdirectories for takes
            found = []
            for root, dirs, files in os.walk(p):
                if ".timestamp.json" in files:
                    found.append(root)
                    dirs.clear()  # Don't descend into take directories
            if not found:
                console.print(
                    f"[yellow]Warning: No takes found in '{p}' "
                    f"(no .timestamp.json in any subdirectory)[/]"
                )
            take_dirs.extend(sorted(found))

    # Deduplicate while preserving order
    seen = set()
    unique = []
    for d in take_dirs:
        if d not in seen:
            seen.add(d)
            unique.append(d)
    return unique


@cli.command("take-upload")
@click.argument("paths", nargs=-1, required=True, type=click.Path())
@click.option("--staging", is_flag=True, hidden=True)
@click.option(
    "--dry-run", is_flag=True,
    help="Show what would be uploaded without actually uploading.",
)
@click.option(
    "--no-preview", is_flag=True,
    help="Skip thumbnail and preview MP4 generation. "
         "Useful if ffmpeg is not installed or preview is not needed.",
)
@click.option(
    "--yes", "-y", is_flag=True,
    help="Skip confirmation prompts.",
)
@click.option(
    "--continue-on-error", is_flag=True,
    help="Continue uploading remaining takes if one fails (batch mode). "
         "By default, batch upload stops on the first failure.",
)
def take_upload(paths, staging, dry_run, no_preview, yes, continue_on_error):
    """Upload one or more take directories to Cloudbreak.

    \b
    PATH can be:
      - A single take directory (contains .timestamp.json)
      - Multiple take directories
      - A parent directory — all subdirectories containing .timestamp.json
        will be discovered automatically, at any nesting depth

    \b
    Each take is uploaded with:
      - Metadata extracted from .timestamp.json
      - Thumbnail image from the hero camera
      - Preview MP4 video from the hero camera
      - Raw frames chunked into 32-frame tar.gz archives (with overlap)
      - Audio WAV file (if present)

    \b
    The upload is resumable — if interrupted, re-run the same command and
    already-uploaded files will be skipped automatically.

    \b
    Requirements:
      - ffmpeg must be installed (used for image/video processing)
      - zstd recommended for faster compression (falls back to gzip)

    \b
    Examples:
      evercoast take-upload ./my-take/
      evercoast take-upload ./take1/ ./take2/ ./take3/
      evercoast take-upload ./all-captures/
      evercoast take-upload ./all-captures/ --no-preview --yes
      evercoast take-upload ./my-take/ --dry-run
    """
    # Discover all take directories
    take_dirs = _discover_takes(paths)

    if not take_dirs:
        console.print("[red]Error: No valid take directories found.[/]")
        sys.exit(1)

    # Load config
    config = Config()
    profile_name = config.get_profile_name(staging)
    profile = config.get_profile(profile_name)

    if not profile:
        console.print(
            "[red]Error: Not configured. Run 'evercoast login' first.[/]"
        )
        sys.exit(1)

    api_url = profile["api_url"]
    token = profile["token"]

    is_staging = STAGING_API_URL in api_url
    env_label = "[bold yellow]STAGING[/]" if is_staging else "[bold green]PRODUCTION[/]"
    console.print()
    console.print(f"[bold cyan]Evercoast — Take Upload[/]  ({env_label})")
    console.print("=" * 50)

    # Get company AWS credentials for take uploads
    console.print("[cyan]Fetching credentials...[/]")
    try:
        from .api import get_s3_client_for_take
        s3_client, bucket, region = get_s3_client_for_take(api_url, token)
    except APIError as e:
        console.print(f"[red]Error: {e}[/]")
        sys.exit(1)

    from .take_upload import TakeUploader
    from .raw_frames import read_timestamp_json, parse_take_naming

    batch = len(take_dirs) > 1

    # Pre-read metadata for all takes and show summary
    uploaders = []
    for take_dir in take_dirs:
        try:
            metadata = read_timestamp_json(take_dir)
            naming = parse_take_naming(os.path.basename(take_dir))
        except Exception as e:
            console.print(f"[red]Error reading '{os.path.basename(take_dir)}': {e}[/]")
            sys.exit(1)

        uploader = TakeUploader(
            take_dir=take_dir,
            api_url=api_url,
            token=token,
            s3_client=s3_client,
            bucket=bucket,
            region=region,
            no_preview=no_preview,
        )
        uploader.metadata = metadata
        uploader.naming = naming
        uploaders.append(uploader)

    # Show summary and confirm
    if batch:
        from rich.table import Table
        table = Table(title=f"Takes to Upload ({len(uploaders)})", padding=(0, 2))
        table.add_column("#", style="bold", justify="right")
        table.add_column("Directory")
        table.add_column("Production")
        table.add_column("Scene")
        table.add_column("Take")
        table.add_column("Frames", justify="right")
        table.add_column("Cameras", justify="right")
        for i, u in enumerate(uploaders, 1):
            table.add_row(
                str(i),
                u.dir_name,
                u.naming["sequence"],
                u.naming["scene"],
                u.naming["take_number"],
                str(u.metadata.get("total_frames", "?")),
                str(len(u.metadata.get("cameras", []))),
            )
        console.print()
        console.print(table)
        console.print()
    else:
        uploaders[0]._print_summary()

    if not dry_run and not yes:
        label = f"Proceed with {len(uploaders)} take uploads?" if batch else "Proceed with take upload?"
        if not click.confirm(label, default=True):
            console.print("[yellow]Upload cancelled.[/]")
            sys.exit(0)

    # Process takes
    succeeded = []
    failed = []
    skipped = []

    for i, uploader in enumerate(uploaders, 1):
        if batch:
            console.print()
            console.print(f"[bold cyan]{'=' * 50}[/]")
            console.print(f"[bold cyan]Take {i}/{len(uploaders)}: {uploader.dir_name}[/]")
            console.print(f"[bold cyan]{'=' * 50}[/]")

        success = uploader.run(dry_run=dry_run)

        if success:
            succeeded.append(uploader.dir_name)
        else:
            failed.append(uploader.dir_name)
            if batch and not continue_on_error and not dry_run:
                remaining = len(uploaders) - i
                if remaining > 0:
                    console.print(
                        f"\n[red]Stopping batch — {remaining} take(s) remaining.[/]"
                    )
                    console.print(
                        "[dim]Use --continue-on-error to keep going after failures.[/]"
                    )
                    skipped = [u.dir_name for u in uploaders[i:]]
                break

    # Final summary for batch
    if batch and not dry_run:
        console.print()
        console.print(f"[bold cyan]{'=' * 50}[/]")
        console.print("[bold cyan]Batch Upload Summary[/]")
        console.print(f"[bold cyan]{'=' * 50}[/]")
        if succeeded:
            console.print(f"[green]  Succeeded: {len(succeeded)}[/]")
            for name in succeeded:
                console.print(f"[green]    - {name}[/]")
        if failed:
            console.print(f"[red]  Failed: {len(failed)}[/]")
            for name in failed:
                console.print(f"[red]    - {name}[/]")
        if skipped:
            console.print(f"[yellow]  Skipped: {len(skipped)}[/]")
            for name in skipped:
                console.print(f"[yellow]    - {name}[/]")

    sys.exit(0 if not failed else 1)


def _prompt_data_type(config: Config, profile_name: str) -> str:
    """Prompt user to select data type, showing last-used as default."""
    last_type = config.get_value(profile_name, "last_type")

    # Map last_type to default index
    type_order = ["takes", "renders", "calibrations", "registrations", "other"]
    default_idx = 1  # default to "takes"
    if last_type in type_order:
        default_idx = type_order.index(last_type) + 1

    console.print()
    console.print("[bold]What type of data are you uploading?[/]")
    console.print()
    for i, key in enumerate(type_order, 1):
        console.print(f"  {i}) {TYPE_LABELS[key]}")
    console.print()

    num_types = len(type_order)
    while True:
        choice = click.prompt(
            f"Select [1-{num_types}]",
            default=str(default_idx),
            show_default=True,
        )
        try:
            idx = int(choice)
            if 1 <= idx <= num_types:
                return type_order[idx - 1]
        except ValueError:
            pass
        console.print(f"[red]Please enter 1-{num_types}[/]")
