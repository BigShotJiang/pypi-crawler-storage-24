from typing import List
import re
from pydantic import BaseModel, Field
from adaline_api.models.message_type import MessageType
from adaline_api.models.config_type import ConfigType
from adaline_api.models.tool_type import ToolType
from adaline_api.models.text_content_type import TextContentType


# Define a single variable's inner value
class InnerVariableValue(BaseModel):
    """
    Represents a single variable's inner value.
    Example: {"modality": "text", "value": "hello"}
    """

    modality: str = Field(..., description="e.g., 'text', 'image', etc.")
    value: str


class OuterVariableValue(BaseModel):
    """
    Represents a single variable with its name and value.
    Example: {"name": "username", "value": {"modality": "text", "value": "Alice"}}
    """

    name: str
    value: InnerVariableValue


class PromptType(BaseModel):
    """
    Represents the complete prompt definition, including config, messages, tools, and variables.
    """

    config: ConfigType
    messages: List[MessageType]
    tools: List[ToolType]
    variables: List[OuterVariableValue]


def replace_prompt_variables(
    *, prompt: PromptType, variable_values: List[OuterVariableValue]
) -> PromptType:
    # Build a lookup map from variable name -> string value
    var_map = {v.name: v.value.value for v in variable_values}

    # Create a deep copy of the prompt to avoid in-place modification
    prompt_copy = prompt.model_copy(deep=True)

    for msg in prompt_copy.messages:
        for c in msg.content:
            # NOTE: MessageContentInner is a polymorphic "oneOf" wrapper generated from the OpenAPI schema.
            #       It does not expose fields like 'modality' and 'value' directly. Instead, the real
            #       payload (e.g., TextContent, ImageContent, etc.) is wrapped inside its `actual_instance`.
            #       Therefore, to safely access and modify text messages, we must first check
            #       whether the underlying `actual_instance` is of type TextContent.
            if isinstance(c.actual_instance, TextContentType):
                text = c.actual_instance.value
                if "{{" in text:
                    # Replace {{variableName}} placeholders
                    c.actual_instance.value = re.sub(
                        r"{{([a-zA-Z_][a-zA-Z0-9_]*)}}",
                        lambda m: var_map.get(m.group(1), f"{{{{{m.group(1)}}}}}"),
                        text,
                    )
    return prompt_copy
