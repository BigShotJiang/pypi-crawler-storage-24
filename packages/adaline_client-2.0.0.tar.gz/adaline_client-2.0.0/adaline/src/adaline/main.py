import os
import logging
from typing import Optional, Any, Dict
import asyncio
import datetime as _dt
from tenacity import (
    retry,
    stop_after_delay,
    wait_exponential,
    wait_random,
    retry_if_exception,
)
from adaline_api.models.deployment import Deployment
from adaline_api.models.log_span_content import LogSpanContent
from adaline_api.rest import ApiException
from adaline_api import ApiClient, DefaultApi, Configuration
from adaline.logs import Monitor


class Controller:
    """
    Controller manages the lifecycle of a cached deployment for a given
    (adaline, prompt_id, environment_id) combination.

    Responsibilities:
    - Fetch and cache the latest deployment from the Adaline API
    - Provide cached deployments when available
    - Handle cleanup of background tasks and cache entries
    """

    def __init__(
        self,
        adaline: "Adaline",
        key: str,
        prompt_id: str,
        deployment_environment_id: str,
        background_status: Dict[str, Any],
    ):
        self.adaline = adaline
        self.key = key
        self.prompt_id = prompt_id
        self.deployment_environment_id = deployment_environment_id
        self.background_status = background_status

    async def get(self, force_refresh: bool = False) -> Optional[Deployment]:
        """Return the cached deployment, refreshing if needed.

        Args:
            force_refresh: If True, bypass the cache and fetch from the API.

        Returns:
            The cached or freshly fetched Deployment.

        Raises:
            ApiException: If the API call fails.
        """
        if force_refresh or self.key not in self.adaline.latest_cache:
            try:
                deployment = await self.adaline.get_latest_deployment(
                    prompt_id=self.prompt_id,
                    deployment_environment_id=self.deployment_environment_id,
                )
                self.adaline.latest_cache[self.key] = deployment
            except Exception as e:
                self.adaline._logger.warning("Failed to get latest deployment: %s", e)
                raise

        return self.adaline.latest_cache[self.key]

    async def stop(self):
        """Stop the background refresh task and clear the cache entry."""
        task = self.adaline._background_tasks.get(self.key)
        if task:
            try:
                task.cancel()
                self.background_status["stopped"] = True
                await task
            except asyncio.CancelledError:
                pass
            del self.adaline._background_tasks[self.key]

        if self.key in self.adaline.latest_cache:
            del self.adaline.latest_cache[self.key]

    def get_background_status(self):
        """Return a snapshot of the background refresh status dict."""
        return dict(self.background_status)


class Adaline:
    """Client for the Adaline platform API.

    Provides methods to fetch deployments, manage cached latest-deployment
    controllers with background refresh, and initialize monitoring for
    traces and spans.
    """

    MIN_REFRESH_INTERVAL = 1  # minimum allowed refresh interval (seconds)
    MAX_REFRESH_INTERVAL = 600  # maximum allowed refresh interval (seconds)

    def __init__(
        self,
        *,
        api_key: str | None = None,
        host: str | None = None,
        debug: bool = False,
    ):
        """Initialize the Adaline client.

        Args:
            api_key: API key for authentication. Falls back to the
                ``ADALINE_API_KEY`` environment variable.
            host: Base URL for the Adaline API. Falls back to the
                ``ADALINE_BASE_URL`` env var, then
                ``https://api.adaline.ai/v2``.
            debug: If True, enable DEBUG-level logging on the
                ``adaline`` logger.
        """
        resolved_host = host or os.environ.get(
            "ADALINE_BASE_URL", "https://api.adaline.ai/v2"
        )
        self.config = Configuration(host=resolved_host)
        self.config.access_token = api_key or os.environ.get("ADALINE_API_KEY", "")
        self.client = ApiClient(self.config)
        self.api = DefaultApi(self.client)

        self._logger = logging.getLogger("adaline")
        if debug:
            self._logger.setLevel(logging.DEBUG)
            if not self._logger.handlers:
                handler = logging.StreamHandler()
                handler.setFormatter(
                    logging.Formatter("[Adaline] %(levelname)s: %(message)s")
                )
                self._logger.addHandler(handler)

        self.latest_cache: dict[str, Deployment] = {}
        self._background_tasks: dict[str, asyncio.Task] = {}

    @staticmethod
    def is_retryable_api_exception(exception: Exception) -> bool:
        """
        Return True if the exception is an API error that should be retried.

        We retry only if:
        - It's an ApiException (or subclass), AND
        - It has a .status attribute in the 5xx range.
        """
        should_retry = False

        if isinstance(exception, ApiException):
            status = getattr(exception, "status", None)
            should_retry = status is not None and 500 <= status < 600

        return should_retry

    # retry applied to the raw API call
    adaline_api_retry = retry(
        retry=retry_if_exception(
            is_retryable_api_exception
        ),  # retry only on 5xx errors
        wait=wait_exponential(multiplier=1, min=1, max=10)
        + wait_random(
            0, 1
        ),  # Exponential backoff with jitter: 1s → 2s → 4s → … capped at 10s
        stop=stop_after_delay(
            20
        ),  # Stop retrying once 20 seconds total have elapsed (cumulative timeout)
        reraise=True,  # After retries are exhausted, re-raise the last exception instead of swallowing it
    )

    @adaline_api_retry
    async def _deployments_get_with_retry(
        self,
        *,
        prompt_id: str,
        deployment_id: str = None,
        deployment_environment_id: str = None,
        latest: bool = False,
    ):
        deployment = None

        if latest:
            if deployment_environment_id is None:
                raise ValueError(
                    "deployment_environment_id is required when latest=True"
                )
            # Call the OpenAPI SDK endpoint for latest deployment
            deployment = await self.api.get_deployment(
                prompt_id, "latest", deployment_environment_id
            )

        else:
            if deployment_id is None:
                raise ValueError("deployment_id is required when latest=False")
            # Call the OpenAPI SDK endpoint for specific deployment
            deployment = await self.api.get_deployment(prompt_id, deployment_id)

        return deployment

    async def get_deployment(self, *, prompt_id: str, deployment_id: str) -> Deployment:
        """
        Get a deployment by prompt ID and deployment ID.

        :param prompt_id: The unique ID of the prompt.
        :param deployment_id: The specific deployment ID.
        :return: Deployment model instance.
        :raises ApiException: If the API call fails.
        """
        try:
            return await self._deployments_get_with_retry(
                prompt_id=prompt_id, deployment_id=deployment_id
            )
        except ApiException as e:
            self._logger.warning("API call failed: %s", e)
            raise

    async def get_latest_deployment(
        self, *, prompt_id: str, deployment_environment_id: str
    ) -> Deployment:
        """
        Get the latest deployment for a prompt in a specific environment.

        :param prompt_id: The unique ID of the prompt (required)
        :param deployment_environment_id: The deployment environment ID (required)
        :return: Deployment model instance.
        :raises ApiException: If the API call fails.
        """
        try:
            return await self._deployments_get_with_retry(
                prompt_id=prompt_id,
                deployment_environment_id=deployment_environment_id,
                latest=True,
            )
        except ApiException as e:
            self._logger.warning("API call failed: %s", e)
            raise

    async def init_latest_deployment(
        self,
        *,
        prompt_id: str,
        deployment_environment_id: str,
        refresh_interval: int = 60,
        max_continuous_failures: int = 3,
    ):
        """Initialize a cached latest deployment with background refresh.

        Fetches the latest deployment immediately, then starts a background
        loop that refreshes the cache at the given interval.

        Args:
            prompt_id: The unique ID of the prompt.
            deployment_environment_id: Target deployment environment.
            refresh_interval: Seconds between background refreshes (clamped
                to ``[MIN_REFRESH_INTERVAL, MAX_REFRESH_INTERVAL]``).
            max_continuous_failures: Consecutive failures before the
                background loop stops itself.

        Returns:
            A Controller for retrieving and managing the cached deployment.

        Raises:
            ApiException: If the initial fetch fails.
        """

        key = f"{prompt_id}:{deployment_environment_id}"

        # Cancel any existing background task for this key
        if key in self._background_tasks:
            self._background_tasks[key].cancel()

        background_status = {
            "stopped": False,
            "consecutive_failures": 0,
            "last_error": None,
            "last_refreshed": _dt.datetime.now(_dt.timezone.utc),
        }

        async def refresh_loop():
            while True:
                try:
                    deployment = await self.get_latest_deployment(
                        prompt_id=prompt_id,
                        deployment_environment_id=deployment_environment_id,
                    )
                    self.latest_cache[key] = deployment
                    background_status.update(
                        {
                            "consecutive_failures": 0,
                            "last_error": None,
                            "last_refreshed": _dt.datetime.now(_dt.timezone.utc),
                        }
                    )
                except Exception as e:
                    background_status["consecutive_failures"] += 1

                    if (
                        background_status["consecutive_failures"]
                        >= max_continuous_failures
                    ):
                        err_msg = f"Background refresh failed {max_continuous_failures} times consecutively for prompt_id={prompt_id}, deployment_environment_id={deployment_environment_id}."
                        self._logger.error("%s", err_msg)
                        background_status.update(
                            {
                                "stopped": True,
                                "last_error": f"{err_msg} Error: {e}",
                                "last_refreshed": _dt.datetime.now(_dt.timezone.utc),
                            }
                        )
                        return

                    else:
                        err_msg = f"Failed to refresh latest deployment! Attempt {background_status['consecutive_failures']}."
                        self._logger.warning("%s", err_msg)
                        background_status.update(
                            {
                                "last_error": f"{err_msg} Error: {e}",
                                "last_refreshed": _dt.datetime.now(_dt.timezone.utc),
                            }
                        )

                await asyncio.sleep(
                    max(
                        self.MIN_REFRESH_INTERVAL,
                        min(refresh_interval, self.MAX_REFRESH_INTERVAL),
                    )
                )

        # Immediately fetch the latest deployment once
        try:
            deployment = await self.get_latest_deployment(
                prompt_id=prompt_id,
                deployment_environment_id=deployment_environment_id,
            )
            self.latest_cache[key] = deployment
        except Exception as e:
            self._logger.error("Failed to fetch initial latest deployment: %s", e)
            raise

        # Start background task only if initial fetch succeeds
        task = asyncio.create_task(refresh_loop())
        self._background_tasks[key] = task

        return Controller(
            self, key, prompt_id, deployment_environment_id, background_status
        )

    def init_monitor(
        self,
        *,
        project_id: str,
        flush_interval_seconds: int = 1,
        max_buffer_size: int = 1000,
        default_content: Optional[LogSpanContent] = None,
    ) -> "Monitor":
        """
        Initializes and returns a new Monitor instance.

        :param project_id: Unique project identifier for grouping traces and spans.
        :param flush_interval_seconds: Interval (in seconds) at which the buffer
                                        is automatically flushed (default: 5).
        :param max_buffer_size: Maximum number of buffered entries before
                                oldest items are dropped (default: 5).
        :param default_content: Optional default content for spans.
        :return: A new Monitor instance bound to the given project.
        """
        return Monitor(
            api=self.api,
            project_id=project_id,
            flush_interval_seconds=flush_interval_seconds,
            max_buffer_size=max_buffer_size,
            default_content=default_content,
            logger=self._logger,
        )
