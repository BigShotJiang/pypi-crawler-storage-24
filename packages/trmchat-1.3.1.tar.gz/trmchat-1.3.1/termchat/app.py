from __future__ import annotations

from textual.app import App

from termchat.api import ApiClient
from termchat.config import CONFIG_DIR
from termchat.themes import DEFAULT_THEME, THEMES


class TermChatApp(App):
    CSS_PATH = "termchat.tcss"
    TITLE = "termchat"

    def __init__(self) -> None:
        super().__init__()
        self.api = ApiClient()

    def on_ready(self) -> None:
        for t in THEMES:
            self.register_theme(t)

        theme_file = CONFIG_DIR / "theme"
        if theme_file.exists():
            saved = theme_file.read_text().strip()
            theme_names = [t.name for t in THEMES]
            if saved in theme_names:
                self.theme = saved
                return
        self.theme = DEFAULT_THEME

    async def on_mount(self) -> None:
        from termchat.auth import load_tokens

        tokens = load_tokens()
        if tokens:
            try:
                await self.api.get_me()
                from termchat.screens.chat import ChatScreen
                self.push_screen(ChatScreen())
                return
            except Exception:
                pass

        from termchat.screens.login import LoginScreen
        self.push_screen(LoginScreen())

    async def on_unmount(self) -> None:
        try:
            await self.api.close()
        except Exception:
            pass


def main() -> None:
    app = TermChatApp()
    app.run()


if __name__ == "__main__":
    main()
