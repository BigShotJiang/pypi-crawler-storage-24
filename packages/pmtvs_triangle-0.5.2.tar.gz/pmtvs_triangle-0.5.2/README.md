# pmtvs-triangle

Compositional geometry primitives for simplex-valued data.

## Installation

```bash
pip install pmtvs-triangle
```

## Functions

- `make_triangle(value_normalized, unit_angle)` - Convert a normalized reading to a triangle [A, B, C] where A+B+C=180
- `aitchison_distance(x, y)` - Geodesic distance on the simplex via centered log-ratio transform
- `triangle_covariance(triangles)` - 3x3 covariance matrix of a triangle population in CLR space
- `triangle_eigen(covariance)` - Eigendecompose triangle covariance (eigenvalues, condition, freedom score)
- `eigenvector_lag(eigen_a, eigen_b)` - Rotation angle between two eigenframes (causal lead detection)
- `triangle_area(p1, p2, p3)` - Triangle area via Heron's formula, N-dimensional

## Backend

Pure Python implementation.

## License

PolyForm Strict 1.0.0 with Additional Terms.

- **Students & individual researchers:** Free. Cite us.
- **Funded research labs (grants > $100K):** Academic Research License required. [Contact us](mailto:licensing@pmtvs.dev).
- **Commercial use:** Commercial License required. [Contact us](mailto:licensing@pmtvs.dev).

See [LICENSE](LICENSE) for full terms.
