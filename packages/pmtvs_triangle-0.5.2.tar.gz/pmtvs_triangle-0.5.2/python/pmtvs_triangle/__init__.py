"""pmtvs-triangle — Triangle manifold primitives for compositional geometry."""

__version__ = "0.5.1"
BACKEND = "python"

from pmtvs_triangle.triangle import (
    make_triangle,
    aitchison_distance,
    triangle_covariance,
    triangle_eigen,
    eigenvector_lag,
    triangle_area,
)

__all__ = [
    "__version__",
    "BACKEND",
    "make_triangle",
    "aitchison_distance",
    "triangle_covariance",
    "triangle_eigen",
    "eigenvector_lag",
    "triangle_area",
]
