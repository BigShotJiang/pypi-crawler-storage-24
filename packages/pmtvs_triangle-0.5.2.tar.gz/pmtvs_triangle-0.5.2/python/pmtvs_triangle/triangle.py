"""
Triangle Manifold Primitives

Compositional geometry for multivariate signals. Each observation
becomes a triangle (three angles summing to 180°). Triangles live on
a simplex — Aitchison distance is the correct metric, not Euclidean.

Pure math. numpy in, number out.

    make_triangle            — value → [A, B, C] where A+B+C=180
    aitchison_distance       — geodesic distance on the simplex
    triangle_covariance      — population of triangles → 3x3 CLR covariance
    triangle_eigen           — covariance → eigenvalues, freedom, condition
    eigenvector_lag          — rotation between two eigenframes
    triangle_area            — Heron's formula, N-dimensional
"""

import numpy as np


def make_triangle(
    value_normalized: float,
    unit_angle: float,
) -> np.ndarray:
    """
    Convert a normalized reading to a triangle.

    The value determines angle A (how much of the 180° budget this
    reading consumes). The unit_angle is a fixed geometric identity.
    Angle C is the remainder. The constraint A+B+C=180 IS the schema.

    Parameters
    ----------
    value_normalized : float
        Reading scaled to [0, 1] via min-max normalization.
    unit_angle : float
        Fixed identity angle in degrees (typically 20–70).

    Returns
    -------
    np.ndarray
        Triangle [A, B, C] in degrees, where A + B + C = 180.0.
        A ∈ [5, 165], B ∈ [5, 180-A-5], C = 180-A-B.
    """
    value_normalized = float(np.clip(value_normalized, 0.0, 1.0))
    unit_angle = float(unit_angle)

    A = 5.0 + value_normalized * 160.0
    B = float(np.clip(unit_angle, 5.0, 180.0 - A - 5.0))
    C = 180.0 - A - B

    return np.array([A, B, C], dtype=np.float64)


def aitchison_distance(
    x: np.ndarray,
    y: np.ndarray,
) -> float:
    """
    Aitchison distance between two compositional vectors.

    The correct metric for data on a simplex (angles summing to a
    constant). Euclidean distance on a simplex is the wrong ruler.

    Applies the centered log-ratio (CLR) transform, then computes
    Euclidean distance in CLR space. This is equivalent to the
    geodesic distance on the Aitchison simplex.

    Parameters
    ----------
    x : np.ndarray
        First compositional vector (all elements > 0).
    y : np.ndarray
        Second compositional vector (same length as x, all > 0).

    Returns
    -------
    float
        Aitchison distance. Zero if x and y are proportionally identical.
        Returns nan if either vector has non-positive elements after
        epsilon correction.
    """
    x = np.asarray(x, dtype=np.float64).ravel()
    y = np.asarray(y, dtype=np.float64).ravel()

    if x.shape != y.shape or len(x) == 0:
        return np.nan

    # Close to simplex (normalize to sum=1)
    x_sum = x.sum()
    y_sum = y.sum()
    if x_sum <= 0.0 or y_sum <= 0.0:
        return np.nan

    x = x / x_sum
    y = y / y_sum

    # CLR transform: log(xi / geometric_mean(x))
    eps = 1e-10
    log_x = np.log(x + eps)
    log_y = np.log(y + eps)

    clr_x = log_x - np.mean(log_x)
    clr_y = log_y - np.mean(log_y)

    return float(np.sqrt(np.sum((clr_x - clr_y) ** 2)))


def triangle_covariance(triangles: np.ndarray) -> np.ndarray:
    """
    Covariance matrix of a triangle population in CLR space.

    Always 3x3. The compositional structure is preserved by working
    in centered log-ratio space, not raw angle space.

    Parameters
    ----------
    triangles : (n_triangles, 3) array of [A, B, C] angles

    Returns
    -------
    (3, 3) covariance matrix in CLR space.
    Returns zeros if fewer than 2 triangles.
    """
    triangles = np.asarray(triangles, dtype=np.float64)
    if triangles.ndim != 2 or triangles.shape[0] < 2 or triangles.shape[1] != 3:
        return np.zeros((3, 3), dtype=np.float64)

    row_sums = triangles.sum(axis=1, keepdims=True)
    row_sums = np.where(row_sums > 0, row_sums, 1.0)
    normed = triangles / row_sums

    eps = 1e-10
    log_normed = np.log(normed + eps)
    clr = log_normed - np.mean(log_normed, axis=1, keepdims=True)

    return np.cov(clr.T)


def triangle_eigen(covariance: np.ndarray) -> dict:
    """
    Eigendecompose the triangle covariance matrix.

    Parameters
    ----------
    covariance : (3, 3) matrix from triangle_covariance()

    Returns
    -------
    dict with:
        eigenvalues   : (3,) sorted descending
        eigenvectors  : (3, 3) columns are eigenvectors
        condition     : float — largest / smallest eigenvalue
        freedom_score : float in [0, 1] — entropy-based, 1 = max freedom
        leading_vec   : (3,) first eigenvector
    """
    covariance = np.asarray(covariance, dtype=np.float64)
    if covariance.shape != (3, 3):
        return {
            'eigenvalues': np.zeros(3),
            'eigenvectors': np.eye(3),
            'condition': 1.0,
            'freedom_score': 1.0,
            'leading_vec': np.array([1.0, 0.0, 0.0]),
        }

    eigenvalues, eigenvectors = np.linalg.eigh(covariance)

    idx = np.argsort(eigenvalues)[::-1]
    eigenvalues = eigenvalues[idx]
    eigenvectors = eigenvectors[:, idx]

    min_ev = np.abs(eigenvalues[-1])
    max_ev = np.abs(eigenvalues[0])
    condition = max_ev / (min_ev + 1e-10)

    total = np.sum(np.abs(eigenvalues)) + 1e-10
    proportions = np.abs(eigenvalues) / total
    entropy = -np.sum(proportions * np.log(proportions + 1e-10))
    max_entropy = np.log(len(eigenvalues))
    freedom_score = float(entropy / max_entropy) if max_entropy > 0 else 1.0

    return {
        'eigenvalues': eigenvalues,
        'eigenvectors': eigenvectors,
        'condition': float(condition),
        'freedom_score': freedom_score,
        'leading_vec': eigenvectors[:, 0],
    }


def eigenvector_lag(eigen_a: dict, eigen_b: dict) -> dict:
    """
    Detect geometric lag between two sources via eigenvector rotation.

    Parameters
    ----------
    eigen_a : dict from triangle_eigen() for source A
    eigen_b : dict from triangle_eigen() for source B

    Returns
    -------
    dict with:
        rotation_angle : float in degrees
        leads          : 'a' or 'b' — higher condition number leads
    """
    vec_a = np.asarray(eigen_a['leading_vec'], dtype=np.float64)
    vec_b = np.asarray(eigen_b['leading_vec'], dtype=np.float64)

    cos_angle = np.clip(np.dot(vec_a, vec_b), -1.0, 1.0)
    angle_deg = float(np.degrees(np.arccos(np.abs(cos_angle))))

    leads = 'a' if eigen_a['condition'] > eigen_b['condition'] else 'b'

    return {
        'rotation_angle': angle_deg,
        'leads': leads,
    }


def triangle_area(
    p1: np.ndarray,
    p2: np.ndarray,
    p3: np.ndarray,
) -> float:
    """
    Area of a triangle defined by three points via Heron's formula.

    Works in any number of dimensions. The three points define a
    triangle embedded in N-dimensional space; the area is computed
    from the three side lengths.

    Parameters
    ----------
    p1 : np.ndarray
        First vertex, shape (N,).
    p2 : np.ndarray
        Second vertex, shape (N,).
    p3 : np.ndarray
        Third vertex, shape (N,).

    Returns
    -------
    float
        Area of the triangle. Returns 0.0 for degenerate triangles
        (collinear points). Returns nan if inputs have mismatched shapes.
    """
    p1 = np.asarray(p1, dtype=np.float64).ravel()
    p2 = np.asarray(p2, dtype=np.float64).ravel()
    p3 = np.asarray(p3, dtype=np.float64).ravel()

    if p1.shape != p2.shape or p1.shape != p3.shape or len(p1) == 0:
        return np.nan

    a = float(np.linalg.norm(p2 - p3))
    b = float(np.linalg.norm(p1 - p3))
    c = float(np.linalg.norm(p1 - p2))

    s = (a + b + c) / 2.0
    val = s * (s - a) * (s - b) * (s - c)

    if val <= 0.0:
        return 0.0

    return float(np.sqrt(val))
