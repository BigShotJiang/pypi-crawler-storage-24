"""Tests for pmtvs-triangle."""

import numpy as np
import pytest

from pmtvs_triangle import (
    make_triangle,
    aitchison_distance,
    triangle_covariance,
    triangle_eigen,
    eigenvector_lag,
    triangle_area,
)


class TestMakeTriangle:
    def test_angles_sum_to_180(self):
        tri = make_triangle(0.5, 45.0)
        assert abs(tri.sum() - 180.0) < 1e-10

    def test_min_value(self):
        tri = make_triangle(0.0, 45.0)
        assert abs(tri[0] - 5.0) < 1e-10
        assert abs(tri.sum() - 180.0) < 1e-10

    def test_max_value(self):
        tri = make_triangle(1.0, 45.0)
        assert abs(tri[0] - 165.0) < 1e-10
        assert abs(tri.sum() - 180.0) < 1e-10

    def test_all_angles_positive(self):
        for v in [0.0, 0.25, 0.5, 0.75, 1.0]:
            for ua in [20.0, 45.0, 70.0]:
                tri = make_triangle(v, ua)
                assert (tri > 0).all(), f"v={v}, ua={ua}, tri={tri}"

    def test_clipping(self):
        tri = make_triangle(-0.5, 45.0)
        assert abs(tri[0] - 5.0) < 1e-10
        tri = make_triangle(1.5, 45.0)
        assert abs(tri[0] - 165.0) < 1e-10

    def test_returns_float64(self):
        tri = make_triangle(0.5, 45.0)
        assert tri.dtype == np.float64


class TestAitchisonDistance:
    def test_identical_is_zero(self):
        x = np.array([60.0, 60.0, 60.0])
        assert aitchison_distance(x, x) == pytest.approx(0.0, abs=1e-8)

    def test_symmetric(self):
        x = np.array([90.0, 45.0, 45.0])
        y = np.array([60.0, 60.0, 60.0])
        assert aitchison_distance(x, y) == pytest.approx(
            aitchison_distance(y, x), abs=1e-10
        )

    def test_positive(self):
        x = np.array([90.0, 45.0, 45.0])
        y = np.array([60.0, 60.0, 60.0])
        assert aitchison_distance(x, y) > 0.0

    def test_proportional_is_zero(self):
        x = np.array([60.0, 60.0, 60.0])
        y = np.array([120.0, 120.0, 120.0])
        assert aitchison_distance(x, y) == pytest.approx(0.0, abs=1e-6)

    def test_empty_is_nan(self):
        assert np.isnan(aitchison_distance(np.array([]), np.array([])))

    def test_mismatched_is_nan(self):
        assert np.isnan(aitchison_distance(np.array([1, 2]), np.array([1, 2, 3])))

    def test_returns_float(self):
        x = np.array([90.0, 45.0, 45.0])
        y = np.array([60.0, 60.0, 60.0])
        result = aitchison_distance(x, y)
        assert isinstance(result, float)


class TestTriangleCovariance:
    def test_shape(self):
        np.random.seed(42)
        tris = np.random.rand(20, 3) * 60 + 40
        cov = triangle_covariance(tris)
        assert cov.shape == (3, 3)

    def test_symmetric(self):
        np.random.seed(42)
        tris = np.random.rand(20, 3) * 60 + 40
        cov = triangle_covariance(tris)
        assert np.allclose(cov, cov.T)

    def test_too_few_returns_zeros(self):
        cov = triangle_covariance(np.array([[60.0, 60.0, 60.0]]))
        assert np.allclose(cov, np.zeros((3, 3)))

    def test_wrong_shape_returns_zeros(self):
        cov = triangle_covariance(np.array([[1, 2, 3, 4], [5, 6, 7, 8]]))
        assert np.allclose(cov, np.zeros((3, 3)))


class TestTriangleEigen:
    def test_keys(self):
        cov = np.eye(3)
        result = triangle_eigen(cov)
        assert 'eigenvalues' in result
        assert 'eigenvectors' in result
        assert 'condition' in result
        assert 'freedom_score' in result
        assert 'leading_vec' in result

    def test_eigenvalues_sorted_descending(self):
        np.random.seed(42)
        tris = np.random.rand(50, 3) * 60 + 40
        cov = triangle_covariance(tris)
        result = triangle_eigen(cov)
        evs = result['eigenvalues']
        assert evs[0] >= evs[1] >= evs[2]

    def test_freedom_score_range(self):
        np.random.seed(42)
        tris = np.random.rand(50, 3) * 60 + 40
        cov = triangle_covariance(tris)
        result = triangle_eigen(cov)
        assert 0.0 <= result['freedom_score'] <= 1.0

    def test_wrong_shape_returns_defaults(self):
        result = triangle_eigen(np.eye(4))
        assert np.allclose(result['eigenvalues'], np.zeros(3))


class TestEigenvectorLag:
    def test_keys(self):
        eigen_a = triangle_eigen(np.eye(3))
        eigen_b = triangle_eigen(np.eye(3) * 2)
        result = eigenvector_lag(eigen_a, eigen_b)
        assert 'rotation_angle' in result
        assert 'leads' in result

    def test_identical_zero_angle(self):
        eigen = triangle_eigen(np.eye(3))
        result = eigenvector_lag(eigen, eigen)
        assert result['rotation_angle'] == pytest.approx(0.0, abs=1e-8)

    def test_leads_is_a_or_b(self):
        np.random.seed(42)
        tris_a = np.random.rand(50, 3) * 60 + 40
        tris_b = np.random.rand(50, 3) * 60 + 40
        ea = triangle_eigen(triangle_covariance(tris_a))
        eb = triangle_eigen(triangle_covariance(tris_b))
        result = eigenvector_lag(ea, eb)
        assert result['leads'] in ('a', 'b')


class TestTriangleArea:
    def test_known_right_triangle(self):
        p1 = np.array([0.0, 0.0])
        p2 = np.array([3.0, 0.0])
        p3 = np.array([0.0, 4.0])
        assert triangle_area(p1, p2, p3) == pytest.approx(6.0, abs=1e-10)

    def test_equilateral(self):
        p1 = np.array([0.0, 0.0])
        p2 = np.array([1.0, 0.0])
        p3 = np.array([0.5, np.sqrt(3) / 2])
        expected = np.sqrt(3) / 4
        assert triangle_area(p1, p2, p3) == pytest.approx(expected, abs=1e-10)

    def test_3d(self):
        p1 = np.array([0.0, 0.0, 0.0])
        p2 = np.array([3.0, 0.0, 0.0])
        p3 = np.array([0.0, 4.0, 0.0])
        assert triangle_area(p1, p2, p3) == pytest.approx(6.0, abs=1e-10)

    def test_degenerate_collinear(self):
        p1 = np.array([0.0, 0.0])
        p2 = np.array([1.0, 1.0])
        p3 = np.array([2.0, 2.0])
        assert triangle_area(p1, p2, p3) == pytest.approx(0.0, abs=1e-10)

    def test_mismatched_shapes_nan(self):
        assert np.isnan(triangle_area(np.array([1, 2]), np.array([1, 2, 3]), np.array([1, 2])))

    def test_empty_nan(self):
        assert np.isnan(triangle_area(np.array([]), np.array([]), np.array([])))

    def test_returns_float(self):
        result = triangle_area(np.array([0, 0]), np.array([1, 0]), np.array([0, 1]))
        assert isinstance(result, float)

    def test_high_dimensional(self):
        np.random.seed(42)
        p1 = np.zeros(10)
        p2 = np.zeros(10)
        p3 = np.zeros(10)
        p2[0] = 3.0
        p3[1] = 4.0
        assert triangle_area(p1, p2, p3) == pytest.approx(6.0, abs=1e-10)
