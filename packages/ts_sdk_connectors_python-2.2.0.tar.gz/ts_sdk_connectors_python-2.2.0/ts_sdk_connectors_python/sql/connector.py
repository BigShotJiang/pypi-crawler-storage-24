"""
SQL Connector implementation using inheritance pattern.

This module provides the SqlConnector abstract base class that developers extend
to create SQL-based connectors. Developers implement three abstract methods to
provide database-specific logic, while the SDK handles connection pooling,
query execution, watermark persistence, and file upload.
"""

import asyncio
import json
import logging
import os
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional, Union
from uuid import uuid4

from pydantic import BaseModel
from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine
from tenacity import (
    before_sleep_log,
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_fixed,
)

from ts_sdk_connectors_python.connector import (
    Connector,
    ConnectorError,
    ConnectorOptions,
)
from ts_sdk_connectors_python.file_uploader import UploadFileRequest
from ts_sdk_connectors_python.models import OperatingStatus
from ts_sdk_connectors_python.openapi_codegen.connectors_api_client.models.connector_controller_get_files_order_direction import (
    ConnectorControllerGetFilesOrderDirection,
)
from ts_sdk_connectors_python.openapi_codegen.connectors_api_client.models.connector_details_dto import (
    ConnectorDetailsDto,
)
from ts_sdk_connectors_python.openapi_codegen.connectors_api_client.models.connector_details_dto_config import (
    ConnectorDetailsDtoConfig,
)
from ts_sdk_connectors_python.openapi_codegen.connectors_api_client.models.connector_file_dto_status import (
    ConnectorFileDtoStatus,
)
from ts_sdk_connectors_python.openapi_codegen.connectors_api_client.models.save_connector_file_request import (
    SaveConnectorFileRequest,
)
from ts_sdk_connectors_python.openapi_codegen.connectors_api_client.models.save_connector_file_request_metadata import (
    SaveConnectorFileRequestMetadata,
)
from ts_sdk_connectors_python.openapi_codegen.connectors_api_client.models.update_connector_health_request import (
    UpdateConnectorHealthRequest,
)
from ts_sdk_connectors_python.openapi_codegen.connectors_api_client.models.update_connector_health_request_status import (
    UpdateConnectorHealthRequestStatus,
)
from ts_sdk_connectors_python.openapi_codegen.connectors_api_client.types import Unset
from ts_sdk_connectors_python.tdp_api import TdpApi
from ts_sdk_connectors_python.utils import Poll

# Delay in seconds before restarting poll after stopping it
# This allows in-flight requests to complete gracefully
POLL_RESTART_DELAY_SEC = 2

# Exponential backoff configuration for file processing retries
# Backoff delay = min(BASE_BACKOFF_SECONDS * 2^(error_count-1), MAX_BACKOFF_SECONDS)
# Examples: 60s, 120s, 240s, 480s, 960s, 1920s, 3600s (capped)
BASE_BACKOFF_SECONDS = 60  # 1 minute
MAX_BACKOFF_SECONDS = 3600  # 1 hour

# Threshold for transitioning from WARNING to CRITICAL health status
# Below this threshold: WARNING (transient issue, retrying)
# At or above this threshold: CRITICAL (persistent issue, needs attention)
CRITICAL_ERROR_THRESHOLD = 5


class SqlConnector(Connector):
    """
    Abstract base class for SQL-based connectors using inheritance pattern.

    Developers extend this class and implement get_connection_string() plus ONE of two patterns:

    Pattern 1 - Single Query (backward compatible):
    - get_connector_query(watermark: Optional[Dict]) -> str
    - get_watermark(rows: List[Dict]) -> Dict

    Pattern 2 - Multiple Queries:
    - get_multiple_connector_queries(watermark: Optional[List[Dict]]) -> List[str]
    - get_multiple_watermarks(all_query_rows: List[List[Dict]]) -> List[Dict]

    The SDK handles:
    - Connection pooling with SQLAlchemy
    - Query execution (single or multiple queries)
    - Watermark persistence
    - Polling mechanism
    - File upload to TDP

    Configuration Parameters (in connector_details.config):
    - polling_interval_minutes (int, optional): Polling interval in minutes.
      Default: 10
    - source_type (str, optional): Source type for uploaded files.
      Default: "sql_query_results"
    - initial_watermark (dict, optional): Initial watermark to use on first poll
      when no saved watermark exists. Useful for backfilling from a specific point.
      Default: None
      Example: {"created_date": "2024-01-01 00:00:00"}

    Class Attributes:
    - use_multi_query_format (bool, optional): If True, single-query connectors will
      output files in the multi-query format ({"queries": [...]}) for consistency.
      Default: False (single-query connectors use the legacy format)

    Environment Variables:
    - SQL_CONNECTOR_MAX_QUERIES (int, optional): Maximum number of queries allowed
      when using multi-query mode. Default: 10

    Implementation Note - Synchronous SQLAlchemy:
        This implementation uses synchronous SQLAlchemy with sync database drivers.
        While the connector methods are async, database operations (connect, execute)
        are synchronous and will block the event loop during query execution.

        Why sync instead of async?
        - Async drivers are not available for all databases (e.g., SQL Server with
          pyodbc, Oracle with cx_oracle)
        - Simpler developer experience with familiar sync drivers
        - For typical polling intervals (5-10 minutes), blocking impact is minimal
        - BYO (Bring Your Own) approach works with all existing sync drivers

        Trade-offs:
        - Event loop is blocked during query execution (typically 1-30 seconds)
        - Cannot handle concurrent operations during query execution
        - Not ideal async practice, but acceptable for polling use cases

        Future Enhancement:
        - A future version may use asyncio.to_thread() to run sync database
          operations in a thread pool, avoiding event loop blocking while
          maintaining compatibility with all database drivers.

    Example (single query):
        ```python
        class PostgresConnector(SqlConnector):
            def get_connection_string(self) -> str:
                config_dict = self.get_config_as_dict()
                return f"postgresql://{config_dict['user']}:{config_dict['password']}@..."

            def get_connector_query(self, watermark: Optional[Dict]) -> str:
                if watermark:
                    return f"SELECT * FROM table WHERE id > {watermark['id']}"
                return "SELECT * FROM table LIMIT 1000"

            def get_watermark(self, rows: List[Dict]) -> Dict:
                return {"id": rows[-1]["id"]}
        ```
    """

    def __init_subclass__(cls, **kwargs):
        """
        Validate that subclasses implement the required methods.

        Subclasses must implement get_connection_string and ONE of two patterns:
        1. Single-query pattern: get_connector_query + get_watermark
        2. Multi-query pattern: get_multiple_connector_queries + get_multiple_watermarks

        Sets cls._is_single_query flag based on which pattern is detected.
        """
        super().__init_subclass__(**kwargs)

        # Check that get_connection_string is implemented
        if "get_connection_string" not in cls.__dict__:
            raise TypeError(f"{cls.__name__} must implement get_connection_string()")

        # Check which pattern is implemented
        has_single_query = "get_connector_query" in cls.__dict__
        has_single_watermark = "get_watermark" in cls.__dict__
        has_multi_query = "get_multiple_connector_queries" in cls.__dict__
        has_multi_watermark = "get_multiple_watermarks" in cls.__dict__

        # Validate that one complete pattern is implemented
        single_pattern_complete = has_single_query and has_single_watermark
        multi_pattern_complete = has_multi_query and has_multi_watermark

        if single_pattern_complete and multi_pattern_complete:
            raise TypeError(
                f"{cls.__name__} implements both single-query and multi-query patterns. "
                f"Implement only one pattern: either (get_connector_query + get_watermark) "
                f"or (get_multiple_connector_queries + get_multiple_watermarks)"
            )

        if not single_pattern_complete and not multi_pattern_complete:
            # Determine what's missing
            if has_single_query or has_single_watermark:
                missing = []
                if not has_single_query:
                    missing.append("get_connector_query")
                if not has_single_watermark:
                    missing.append("get_watermark")
                raise TypeError(
                    f"{cls.__name__} partially implements single-query pattern. "
                    f"Missing: {', '.join(missing)}"
                )
            elif has_multi_query or has_multi_watermark:
                missing = []
                if not has_multi_query:
                    missing.append("get_multiple_connector_queries")
                if not has_multi_watermark:
                    missing.append("get_multiple_watermarks")
                raise TypeError(
                    f"{cls.__name__} partially implements multi-query pattern. "
                    f"Missing: {', '.join(missing)}"
                )
            else:
                raise TypeError(
                    f"{cls.__name__} must implement one of two patterns:\n"
                    f"  1. Single-query: get_connector_query() + get_watermark()\n"
                    f"  2. Multi-query: get_multiple_connector_queries() + get_multiple_watermarks()"
                )

        # Set the flag for which pattern is being used
        cls._is_single_query = single_pattern_complete

    # Class attribute to control output format for single-query connectors
    # Set to True to use multi-query format ({"queries": [...]}) for consistency
    # Default: False (use legacy single-query format)
    use_multi_query_format: bool = False

    def __init__(
        self,
        tdp_api: TdpApi,
        options: Optional[ConnectorOptions] = None,
    ):
        super().__init__(tdp_api=tdp_api, options=options)
        self.poll: Optional[Poll] = None
        self.engine: Optional[Engine] = None
        self.watermark: Optional[Dict[str, Any]] = None
        self.skip_upload_if_no_data: bool = False

        # Lazy-initialized cache for max queries (populated on first access)
        self._max_queries_cache: Optional[int] = None

    def _convert_config_to_dict(
        self, config: Union[Unset, dict, ConnectorDetailsDtoConfig, BaseModel]
    ) -> dict:
        if isinstance(config, Unset):
            self.logger.warning(
                "_convert_config_to_dict called on unset config, returning empty dict"
            )
            config_dict = {}
        elif isinstance(config, dict):
            config_dict = config
        elif isinstance(config, ConnectorDetailsDtoConfig):
            config_dict = config.to_dict()
        elif hasattr(config, "model_dump"):  # catch Pydantic for future-proofing
            config_dict = config.model_dump()
        else:
            error_message = f"_convert_config_to_dict got unexpected config type {type(config)} and cannot convert to dict"
            self.logger.error(error_message)
            raise ConnectorError(error_message)
        return config_dict

    def get_config_as_dict(self) -> Dict[str, Any]:
        try:
            config = self.connector_details.config
        except ConnectorError:
            self.logger.warning(
                "Connector details are not loaded; returning empty config"
            )
            return {}
        return self._convert_config_to_dict(config)

    def _get_max_queries(self) -> int:
        """
        Get the maximum number of queries allowed from SQL_CONNECTOR_MAX_QUERIES env var.

        Returns:
            int: The maximum number of queries allowed (default: 10)
        """
        # Return cached value if already parsed
        if self._max_queries_cache is not None:
            return self._max_queries_cache

        # Parse and validate the environment variable
        default_max = 10
        env_value = os.getenv("SQL_CONNECTOR_MAX_QUERIES")

        if env_value is None:
            self._max_queries_cache = default_max
            return default_max

        try:
            max_queries = int(env_value)
            if max_queries <= 0:
                self.logger.warning(
                    f"SQL_CONNECTOR_MAX_QUERIES must be positive, got '{env_value}'. "
                    f"Using default value: {default_max}"
                )
                self._max_queries_cache = default_max
                return default_max
            self._max_queries_cache = max_queries
            return max_queries
        except ValueError:
            self.logger.warning(
                f"SQL_CONNECTOR_MAX_QUERIES must be a valid integer, got '{env_value}'. "
                f"Using default value: {default_max}"
            )
            self._max_queries_cache = default_max
            return default_max

    def get_connection_string(self) -> str:
        """
        Return SQLAlchemy connection string for the database.

        This method must be implemented by subclasses to provide the database
        connection string. The connection string format depends on the database
        type and driver. This is a BYO (Bring Your Own) approach - developers
        must ensure the appropriate database driver is installed.

        Common formats:
        - PostgreSQL: "postgresql://user:password@localhost:5432/dbname"
        - PostgreSQL (psycopg2): "postgresql+psycopg2://user:password@localhost:5432/dbname"
        - MySQL: "mysql+pymysql://user:password@localhost:3306/dbname"
        - SQL Server: "mssql+pyodbc://user:password@localhost:1433/dbname?driver=ODBC+Driver+17+for+SQL+Server"
        - Oracle: "oracle+cx_oracle://user:password@localhost:1521/dbname"
        - SQLite: "sqlite:///path/to/database.db"

        You can access connector configuration via `self.get_config_as_dict()`.

        Returns:
            SQLAlchemy connection string

        Raises:
            ValueError: If required configuration is missing

        Example:
            ```python
            def get_connection_string(self) -> str:
                config_dict = self.get_config_as_dict()
                return (
                    f"postgresql+psycopg2://"
                    f"{config_dict['username']}:{config_dict['password']}"
                    f"@{config_dict['server']}:{config_dict['port']}"
                    f"/{config_dict['database']}"
                )
            ```
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} must implement get_connection_string()"
        )

    def get_connector_query(self, watermark: Optional[Dict[str, Any]]) -> str:
        """
        Build SQL query with watermark logic for incremental data retrieval (single-query pattern).

        This method is called during each polling interval to construct the SQL query.
        The query should use the watermark to retrieve only new or updated data since
        the last poll.

        NOTE: This is for the single-query pattern. For multi-query support, implement
        get_multiple_connector_queries() instead.

        Best practices:
        - Consider adding LIMIT/FETCH FIRST to avoid retrieving too much data
        - Handle the case where watermark is None (initial poll)

        Security considerations:
        - Watermark values come from get_watermark() which extracts data from
          query results, so they originate from the database itself
        - Validate watermark values match expected types (datetime, int, etc.)
        - Consider using SQLAlchemy's literal() for values if needed
        - Avoid incorporating untrusted external input into queries

        Args:
            watermark: Watermark from previous poll. Can be:
                      - None on the first poll or if no previous watermark exists
                      - Dict: {"created_date": "2023-10-31 10:00:00", "id": 12345}

        Returns:
            A single SQL query string

        Example:
            ```python
            def get_connector_query(self, watermark: Optional[Dict]) -> str:
                if watermark and "created_date" in watermark:
                    # Watermark values come from database, but validate type
                    created_date = watermark['created_date']
                    if not isinstance(created_date, (str, datetime)):
                        raise ValueError(f"Invalid watermark type: {type(created_date)}")

                    return f'''
                        SELECT * FROM assay_results
                        WHERE created_date >= '{created_date}'
                        ORDER BY created_date ASC
                        LIMIT 1000
                    '''
                else:
                    return '''
                        SELECT * FROM assay_results
                        ORDER BY created_date ASC
                        LIMIT 1000
                    '''
            ```
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} must implement get_connector_query()"
        )

    def get_watermark(self, rows: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Extract watermark from query results (single-query pattern).

        The watermark represents the position in the dataset for the next poll.
        You have full flexibility in implementing your watermark strategy.

        NOTE: This is for the single-query pattern. For multi-query support, implement
        get_multiple_watermarks() instead.

        The SDK provides all rows from the query results, allowing you to:
        - Use the last row: `rows[-1]["id"]`
        - Find max value: `max(row["ts"] for row in rows)`
        - Count rows: `len(rows)`
        - Any other aggregation or logic

        Two constraints:
        1. The watermark must be derivable from the query results alone. You
           cannot make additional database queries to determine the watermark.
           You may use constants, configuration, or computed values from the
           row data.
        2. The watermark must be JSON-serializable (passed through json.dumps).
           Convert datetime objects to strings (e.g., using isoformat()).

        Args:
            rows: Query results as List[Dict], where each dict represents a row

        Returns:
            Watermark as a Dict

        Example:
            ```python
            def get_watermark(self, rows: List[Dict[str, Any]]) -> Dict[str, Any]:
                # ID-based (last row)
                return {"id": rows[-1]["id"]}

                # Timestamp-based (last row, convert datetime to string)
                return {"modified_at": rows[-1]["modified_at"].isoformat()}

                # Max timestamp across all rows
                return {"max_ts": max(row["ts"].isoformat() for row in rows)}

                # Composite (last row)
                return {"ts": rows[-1]["ts"].isoformat(), "id": rows[-1]["id"]}
            ```
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} must implement get_watermark() "
            f"or use the multi-query pattern with get_multiple_watermarks()"
        )

    def get_multiple_connector_queries(
        self, watermark: Optional[List[Dict[str, Any]]]
    ) -> List[str]:
        """
        Build multiple SQL queries with watermark logic (multi-query pattern).

        This method is called during each polling interval to construct multiple SQL
        queries. Each query should use its corresponding watermark to retrieve only new
        or updated data since the last poll.

        NOTE: This is for the multi-query pattern. For single-query support, implement
        get_connector_query() instead.

        Best practices:
        - Consider adding LIMIT/FETCH FIRST to avoid retrieving too much data
        - Handle the case where watermark is None (initial poll)
        - Maximum number of queries is controlled by SQL_CONNECTOR_MAX_QUERIES env var (default: 10)

        Security considerations:
        - Watermark values come from get_multiple_watermarks() which extracts data from
          query results, so they originate from the database itself
        - Validate watermark values match expected types (datetime, int, etc.)
        - Consider using SQLAlchemy's literal() for values if needed
        - Avoid incorporating untrusted external input into queries

        Args:
            watermark: Watermarks from previous poll. Can be:
                      - None on the first poll or if no previous watermark exists
                      - List[Dict]: [{"id": 100}, {"ts": "2024-01-01"}]
                        One watermark dict per query, in the same order as queries

        Returns:
            List of SQL query strings

        Example:
            ```python
            def get_multiple_connector_queries(
                self, watermark: Optional[List[Dict[str, Any]]]
            ) -> List[str]:
                if watermark is None:
                    # First poll - return initial queries
                    return [
                        "SELECT * FROM table1 ORDER BY id LIMIT 1000",
                        "SELECT * FROM table2 ORDER BY timestamp LIMIT 1000"
                    ]

                # Subsequent polls - use watermarks
                wm1, wm2 = watermark[0], watermark[1]
                return [
                    f"SELECT * FROM table1 WHERE id > {wm1.get('id', 0)} ORDER BY id LIMIT 1000",
                    f"SELECT * FROM table2 WHERE timestamp > '{wm2.get('timestamp', '1970-01-01')}' ORDER BY timestamp LIMIT 1000"
                ]
            ```
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} must implement get_multiple_connector_queries() "
            f"or use the single-query pattern with get_connector_query()"
        )

    def get_multiple_watermarks(
        self, all_query_rows: List[List[Dict[str, Any]]]
    ) -> List[Dict[str, Any]]:
        """
        Extract watermarks from multiple query results (multi-query pattern).

        The watermarks represent the position in the dataset for the next poll.
        You have full flexibility in implementing your watermark strategy.

        NOTE: This is for the multi-query pattern. For single-query support, implement
        get_watermark() instead.

        The SDK provides all rows from each query's results, allowing you to:
        - Use the last row: `rows[0][-1]["id"]`
        - Find max value: `max(row["ts"] for row in rows[0])`
        - Count rows: `len(rows[0])`
        - Any other aggregation or logic

        Two constraints:
        1. The watermark must be derivable from the query results alone. You
           cannot make additional database queries to determine the watermark.
           You may use constants, configuration, or computed values from the
           row data.
        2. The watermark must be JSON-serializable (passed through json.dumps).
           Convert datetime objects to strings (e.g., using isoformat()).

        Args:
            rows: Query results as List[List[Dict]], where each inner list contains
                  the rows for one query, in the same order as the queries.
                  e.g., [[query1_rows], [query2_rows], [query3_rows]]

        Returns:
            List of watermark dicts, one per query in the same order

        Example:
            ```python
            def get_multiple_watermarks(
                self, rows: List[List[Dict[str, Any]]]
            ) -> List[Dict[str, Any]]:
                watermarks = []

                # Watermark for query 1 (table1)
                if rows[0]:  # Check if first query returned data
                    watermarks.append({"id": rows[0][-1]["id"]})
                else:
                    watermarks.append({})  # Empty watermark if no data

                # Watermark for query 2 (table2)
                if rows[1]:  # Check if second query returned data
                    ts = rows[1][-1]["timestamp"]
                    if hasattr(ts, "isoformat"):
                        ts = ts.isoformat()
                    watermarks.append({"timestamp": ts})
                else:
                    watermarks.append({})

                return watermarks
            ```
        """
        raise NotImplementedError(
            f"{self.__class__.__name__} must implement get_multiple_watermarks() "
            f"or use the single-query pattern with get_watermark()"
        )

    async def on_initialized(self):
        """
        Connector fully initialized.

        Note: Database engine creation is deferred to on_start() to avoid a race
        condition. The engine is only needed when the connector is RUNNING, and
        creating it in on_start() ensures proper lifecycle management.
        """
        await super().on_initialized()

    def _create_engine(self) -> Engine:
        """
        Create SQLAlchemy engine with connection pooling and timeout configuration.

        The engine is configured to keep connections alive between poll cycles for efficiency.
        For SQLite, uses SingletonThreadPool (one connection per thread, reused across polls).
        For production databases, uses QueuePool with pool_size=1 (sequential execution).

        Connection pooling prevents expensive reconnection overhead on each poll cycle.
        For example, PostgreSQL connection setup can take 50-200ms, so reusing connections
        saves significant time over the connector's lifetime.

        Note: pool_size=1 is sufficient because the Poll class ensures sequential query
        execution. Each poll cycle waits for the query to complete (via await) before
        starting the next cycle, making concurrent queries impossible.

        Timeout Configuration:
        By default, most database drivers have NO timeout, which means queries can hang
        indefinitely. It is STRONGLY RECOMMENDED to configure timeout via 'connect_args'
        in connector config. See README.md for database-specific timeout configuration
        examples.

        Returns:
            Engine: Configured SQLAlchemy engine

        Raises:
            ValueError: If get_connection_string() returns invalid connection string
        """
        # Get connection string from subclass implementation
        connection_string = self.get_connection_string()

        if not connection_string:
            raise ValueError(
                "Connection string cannot be empty. "
                "Ensure get_connection_string() returns a valid SQLAlchemy connection string."
            )

        # Get connection arguments from connector config (timeout, SSL, etc.)
        connect_args = self._get_connect_args()

        # Build engine config - keep connections alive for polling
        engine_config = {
            "pool_pre_ping": True,  # Verify connection before use
            "pool_recycle": 3600,  # Recycle connections after 1 hour
            "connect_args": connect_args,  # Database-specific timeout
        }

        # SQLite uses SingletonThreadPool by default (one connection per thread)
        # Production databases need explicit pool_size configuration
        if not connection_string.startswith("sqlite"):
            engine_config.update(
                {
                    "pool_size": 1,  # Only 1 connection needed (sequential execution)
                    "max_overflow": 0,  # No additional connections needed
                }
            )

        engine = create_engine(connection_string, **engine_config)

        # Test connection immediately to fail fast on bad configuration.
        # Behavior on connection failure:
        # - If database rejects connection (wrong credentials, unreachable, etc.):
        #   SQLAlchemy throws exception, which is caught and logged in on_start()
        # - If connection hangs (network issues, firewall blocking, etc.):
        #   Blocks until timeout expires. User MUST configure timeout via connect_args
        #   to prevent indefinite hanging (see README.md for database-specific examples)
        #   We strongly recommend setting a timeout to prevent hanging.
        with engine.connect() as conn:
            conn.execute(text("SELECT 1"))

        self.logger.info(
            "Database connection established successfully with timeout config keys: %s",
            list(connect_args.keys())
            if isinstance(connect_args, dict)
            else f"ERROR: Expected dict but got {type(connect_args).__name__}",
        )

        return engine

    def _get_connect_args(self) -> Dict[str, Any]:
        """
        Get connection arguments from connector config.

        Returns the 'connect_args' dictionary from connector config, which is passed
        directly to SQLAlchemy's create_engine(). This can include any driver-specific
        connection parameters such as:
        - Timeout settings (connect_timeout, statement_timeout)
        - SSL/TLS configuration
        - Character set and encoding
        - Other driver-specific options

        Note: By default, most database drivers have NO timeout or very long timeouts.
        It is STRONGLY RECOMMENDED to configure timeout via 'connect_args'.
        See README.md for database-specific configuration examples.

        Returns:
            Dictionary of connection arguments from config, or empty dict if not configured
        """
        # Check if connector_details is loaded (may not be in integration tests or direct method calls)
        if not self.connector_details_are_loaded():
            return {}

        config_dict = self.get_config_as_dict()

        # Check if user provided custom connect_args
        # config can be either dict or ConnectorDetailsDtoConfig (both support 'in' and '[]')
        if "connect_args" in config_dict:  # type: ignore
            connect_args = config_dict["connect_args"]  # type: ignore
            self.logger.info(
                "Using custom connect_args from config with keys: %s",
                list(connect_args.keys())
                if isinstance(connect_args, dict)
                else f"ERROR: Expected dict but got {type(connect_args).__name__}",
            )
            return connect_args

        # No timeout configured - warn user
        self.logger.warning(
            "No timeout configured for database connection. "
            "Queries may hang indefinitely. "
            "It is STRONGLY RECOMMENDED to configure timeout via 'connect_args' in connector config. "
            "See README.md for database-specific timeout configuration examples."
        )
        return {}

    async def on_stop(self):
        """Stop polling."""
        await super().on_stop()
        self._stop_polling()

    async def on_shutdown(self):
        """Clean up database connection."""
        if self.engine:
            self.engine.dispose()
            self.logger.info("Database connection closed")

        await super().on_shutdown()

    async def on_connector_updated(self, prev: ConnectorDetailsDto | None):
        """
        Handle connector configuration updates.

        This method is called when the connector's configuration is updated.
        When the connector is RUNNING, we initialize or reinitialize polling to pick up
        configuration changes such as polling interval or connection parameters.

        If connection configuration (host, port, database, credentials) has changed,
        we recreate the database engine to use the new connection parameters.

        This method also handles initial setup on connector start, since super().on_start()
        calls load_connector_details() which triggers this method.

        Args:
            prev: Previous connector details (None on first call)
        """
        await super().on_connector_updated(prev)

        if self.connector_details.operating_status == OperatingStatus.RUNNING:
            # Check if connection configuration changed
            if prev and self._connection_config_changed(prev):
                self.logger.info(
                    "Connection configuration changed, recreating database engine"
                )
                self._close_engine()
                self.engine = None  # Will be recreated in _initialize_poll

            self.logger.info("Connector configuration updated, initializing poll")
            await self._initialize_poll()

    async def _initialize_poll(self):
        """
        Initialize or reinitialize the polling mechanism.

        This method is called when:
        1. Connector configuration is updated (via on_connector_updated)
        2. Connector starts (via on_start → on_connector_updated)

        If a poll already exists, we stop it first and wait briefly to allow
        any in-flight requests to complete before starting a new poll with
        the updated configuration.

        This method handles:
        - Creating the database engine (if not already created)
        - Loading the watermark from connector state
        - Starting the polling loop
        """
        self.logger.info("Initializing SQL connector polling loop")

        if self.poll:
            self.logger.warning("Stopping existing poll before reinitializing")
            self._stop_polling()
            # Wait briefly to allow in-flight requests to complete
            await asyncio.sleep(POLL_RESTART_DELAY_SEC)

        try:
            # Create engine if it was closed due to config change or first initialization
            if not self.engine:
                self.engine = self._create_engine()

            # Load watermark from connector state
            await self._load_watermark()

            # Start polling with current configuration
            self._start_polling()

        except Exception as exc:
            self.logger.error(f"Failed to initialize SQL connector polling: {exc}")
            raise

    def _connection_config_changed(self, prev: ConnectorDetailsDto) -> bool:
        """
        Check if connection configuration has changed.

        This method compares the entire configuration dictionary to detect changes.
        This is a conservative approach - any configuration change will trigger
        database engine recreation, even if the change doesn't affect the connection
        (e.g., changing polling_interval_minutes).

        This ensures we never miss a connection parameter change, at the cost of
        potentially recreating the engine more often than strictly necessary.

        Developers can override this method to implement more granular detection
        logic if needed. For example, to only check specific connection-related
        configuration keys:

        Example override:
            def _connection_config_changed(self, prev):
                config_dict = self.get_config_as_dict()
                prev_config_dict = self._convert_config_to_dict(prev.config)

                # Only check connection-specific parameters
                connection_keys = ['db_host', 'db_port', 'db_name',
                                   'db_user', 'db_password']
                for key in connection_keys:
                    if config_dict.get(key) != prev_config_dict.get(key):
                        return True
                return False

        Args:
            prev: Previous connector details

        Returns:
            True if configuration changed, False otherwise
        """
        # Compare the entire config dictionary (conservative approach)
        current_config = self.get_config_as_dict()
        if prev.config:
            prev_config = self._convert_config_to_dict(prev.config)
        else:
            prev_config = {}

        changed = current_config != prev_config
        if changed:
            self.logger.info(
                "Connector configuration changed, will recreate database engine"
            )

        return changed

    def _close_engine(self):
        """
        Close the SQLAlchemy engine and dispose of the connection pool.

        This should be called when the connection configuration changes
        or when the connector is shutting down.
        """
        if self.engine:
            self.logger.info("Closing database engine and disposing connection pool")
            self.engine.dispose()
            self.logger.debug("Database engine closed successfully")

    def _start_polling(self):
        """
        Start the polling mechanism.

        The Poll class ensures sequential query execution by waiting for each
        query to complete (via await) before starting the next poll cycle.
        This means queries cannot overlap, even if a query takes longer than
        the polling interval. If a query execution time exceeds the interval,
        the next query will start immediately after the previous one completes.

        Example timeline with 10-minute interval:
        T=0m 00s:  Query 1 starts
        T=0m 15s:  Query 1 finishes (took 15 seconds)
        T=10m 00s: Query 2 starts (slept ~9m 45s to maintain 10-minute interval)
        T=10m 20s: Query 2 finishes (took 20 seconds)
        T=20m 00s: Query 3 starts (slept ~9m 40s to maintain 10-minute interval)
        """
        config_dict = self.get_config_as_dict()
        # Get polling interval from config, default to 10 minutes
        polling_interval_minutes = (
            config_dict["polling_interval_minutes"]
            if "polling_interval_minutes" in config_dict
            else 10
        )
        polling_interval_seconds = polling_interval_minutes * 60

        self.poll = Poll(
            target=self._get_file_and_process,
            interval=polling_interval_seconds,
            on_error=lambda exc: self.logger.error(
                f"Error during polling: {exc}", exc_info=True
            ),
            name="SqlConnectorPoll",
        )
        self.poll.start()
        self.logger.info(
            f"Started polling with interval: {polling_interval_minutes} minutes"
        )

    def _stop_polling(self):
        """Stop the polling mechanism."""
        if self.poll:
            self.poll.stop()
            self.poll = None
            self.logger.info("Stopped polling")

    def _execute_query(self, query: str) -> List[Dict[str, Any]]:
        """
        Execute SQL query and return results as list of dictionaries.

        This method executes a SQL query using the connector's engine and returns
        the results as a list of dictionaries, where each dictionary represents a row.

        Args:
            query: SQL query string to execute

        Returns:
            List of dictionaries, where each dict represents a row with column names as keys

        Raises:
            SQLAlchemyError: If query execution fails
        """
        with self.engine.connect() as conn:
            result = conn.execute(text(query))
            # pylint: disable=protected-access
            rows = [dict(row._mapping) for row in result]
        return rows

    async def _get_file_and_process(self):
        """
        Get or create a PENDING file and process it.

        This method is called by the Poll object at regular intervals.
        It follows a single-open-file pattern:
        1. Check for existing open (PENDING, ERROR) file (from previous failed attempt)
        2. If open file exists, process it first (retry scenario)
        3. If no open file, create a new PENDING one and process it

        Single Open File Pattern:
        - At most one open file exists at any time
        - This ensures clean retry semantics and prevents data duplication
        - If a previous upload failed, we retry with the same watermark
        - Only after successful processing do we move to the next query

        TODO (Future Enhancement - Data Duplication Prevention):
        To prevent data duplication, we could check if a file was already uploaded
        before re-uploading. However, this has a known platform limitation:

        **Label/File ID Issue**: When re-saving a file with the same fileId but
        different content, the platform's fileInfo lambda performs an S3 CopyObject
        to a new file with a NEW random fileId. The labels file (stored at
        `labels/{fileId}.labels`) is NOT copied, causing labels to be lost.

        See: https://tetrascience.slack.com/archives/C063W40KT18/p1755877257508699
        """
        # Step 1: Check for existing open file (indicates previous failure)
        try:
            files_response = await self.get_files(
                statuses=[ConnectorFileDtoStatus.PENDING, ConnectorFileDtoStatus.ERROR],
                order_by="createdAt",
                order_direction=ConnectorControllerGetFilesOrderDirection.ASC,
                paginate=False,
            )

            if files_response and files_response.files:
                if len(files_response.files) > 1:
                    self.logger.warning(
                        f"Found {len(files_response.files)} open files, "
                        "processing oldest and marking others as skipped"
                    )
                    await self.save_files(
                        [
                            SaveConnectorFileRequest(
                                id=f.id,
                                unique_external_id=f.unique_external_id,
                                filepath=f.filepath,
                                status=ConnectorFileDtoStatus.SKIPPED,
                            )
                            for f in files_response.files[1:]
                        ]
                    )

                self.logger.info(
                    f"Found existing {files_response.files[0].status} file {files_response.files[0].id}, "
                    "processing it instead of creating new file"
                )
                await self._process_file(files_response.files[0])
                return

        except Exception as exc:
            self.logger.error(
                f"Failed to check for existing open files: {exc}", exc_info=True
            )
            await self._update_health_status(
                UpdateConnectorHealthRequestStatus.CRITICAL,
                error_code="FileRetrievalError",
            )
            return

        # Step 2: No PENDING file exists - create a new one
        file_id = None
        try:
            file_id = str(uuid4())
            timestamp = datetime.now(timezone.utc).isoformat()
            config_dict = self.get_config_as_dict()
            source_type = config_dict.get("source_type", "sql_query_results")
            file_path = f"/{source_type}/{timestamp}.json"

            # Create metadata object with current watermark
            # watermark_before is used for retry if upload fails
            pending_metadata = SaveConnectorFileRequestMetadata()
            pending_metadata.additional_properties.update(
                {
                    "watermark_before": self.watermark,
                    "query_timestamp": timestamp,
                }
            )

            await self.save_files(
                [
                    SaveConnectorFileRequest(
                        id=file_id,
                        unique_external_id=timestamp,
                        filepath=file_path,
                        status=ConnectorFileDtoStatus.PENDING,
                        metadata=pending_metadata,
                    )
                ]
            )
            self.logger.debug(f"Registered file entry {file_id} with PENDING status")

        except Exception as exc:
            self.logger.error(
                f"Failed to register pending file entry: {exc}", exc_info=True
            )
            await self._update_health_status(
                UpdateConnectorHealthRequestStatus.CRITICAL,
                error_code="FileRegistrationError",
            )
            return

        # Step 3: Retrieve the newly created file and process it
        try:
            files_response = await self.get_files(
                statuses=[ConnectorFileDtoStatus.PENDING],
                max_results=1,
                paginate=False,
            )

            if not files_response or not files_response.files:
                self.logger.warning("No PENDING file found after registration")
                return

            await self._process_file(files_response.files[0])

        except Exception as exc:
            self.logger.error(
                f"Failed to retrieve or process file: {exc}", exc_info=True
            )
            await self._update_health_status(
                UpdateConnectorHealthRequestStatus.CRITICAL,
                error_code="FileRetrievalError",
            )
            return

    def handle_partial_watermarks(
        self,
        watermarks_before: List[Optional[Dict[str, Any]]],
        watermarks_after: List[Dict[str, Any]],
    ) -> List[Dict[str, Any]]:
        """
        Any entries in watermarks_after missing data will get value from
        watermarks_before rolled over

        This is only for the multi-query pattern

        Args:
            watermarks_before: Previous watermarks (each can be None on first run)
            watermarks_after: New watermarks from get_multiple_watermarks

        Returns:
            List of watermarks with partial results filled from watermarks_before
        """
        if self._is_single_query:
            raise NotImplementedError(
                "handle_partial_watermarks is only for the multi-query pattern"
            )

        if not isinstance(watermarks_after, list):
            raise ValueError(
                f"handle_partial_watermarks expects watermarks_after to be List[Dict], "
                f"got {type(watermarks_after)}"
            )

        if not isinstance(watermarks_before, list):
            raise ValueError(
                f"handle_partial_watermarks expects watermarks_before to be List[Dict], "
                f"got {type(watermarks_before)}"
            )

        if len(watermarks_after) != len(watermarks_before):
            raise ValueError(
                f"handle_partial_watermarks received {len(watermarks_after)} new watermarks, "
                f"but old watermark has {len(watermarks_before)} entries"
            )

        output_watermarks = []
        for maybe_wm_before, wm_after in zip(watermarks_before, watermarks_after):
            # consider possibility that wm_before is None before data has been
            # found
            if maybe_wm_before:
                wm_before = maybe_wm_before
            else:
                wm_before = {}

            if not wm_after:
                output_watermarks.append(wm_before)
            else:
                output_watermarks.append(wm_after)

        return output_watermarks

    async def _process_file(self, file_dto):
        """
        Process a single PENDING file.

        This method executes the query with the watermark stored in the file's metadata,
        saves the new watermark, uploads the results, and updates the file status.

        Operation Order (to prevent data loss):
        1. Execute query with watermark from file metadata
        2. Save new watermark to connector state FIRST
           - If fails: ABORT, file stays PENDING, retry next poll with same watermark
        3. Upload file to S3
        4. Mark file as SUCCESS
           - If 3 or 4 fails: file stays PENDING, retry using file metadata watermark_before

        Single Open File Pattern:
        - Only one PENDING file exists at a time
        - If processing fails, the file stays PENDING for retry
        - Watermark in file metadata is used for retry (not connector state)

        Args:
            file_dto: ConnectorFileDto object to process
        """
        try:
            self.logger.info(
                f"Processing file {file_dto.id} (status: {file_dto.status})"
            )

            # Extract metadata from the file entry
            # Use file metadata watermark_before for retry scenarios
            # Note: file_dto.metadata is a ConnectorFileDtoMetadataType0 object,
            # not a dict, so we need to access additional_properties
            metadata = (
                file_dto.metadata.additional_properties if file_dto.metadata else {}
            )
            watermark = metadata.get("watermark_before", self.watermark)
            file_path = file_dto.filepath

            # note: source type is included in the file path. But, an old file
            # could have had its configured source_type changed after the fact
            # So we have two choices:
            # 1) try to extract source_type from file path
            # 2) use the current configured source_type, and possibly break the
            # invariant that source_type matches the source_type used originally
            # in the file path
            #
            # I think 2 is less brittle
            config_dict = self.get_config_as_dict()
            source_type = config_dict.get("source_type", "sql_query_results")

            # Determine which pattern this connector uses (set by __init_subclass__)
            is_single_query = self._is_single_query

            # Get query or queries based on the pattern
            if is_single_query:
                # Single-query pattern: watermark is Dict or None
                query = self.get_connector_query(watermark)
                queries = [query]
            else:
                # Multi-query pattern: watermark is List[Dict] or None
                queries = self.get_multiple_connector_queries(watermark)

            # Validate query count
            max_queries = self._get_max_queries()
            if len(queries) > max_queries:
                self.logger.error(
                    f"get_multiple_connector_queries() returned {len(queries)} queries, "
                    f"but maximum allowed is {max_queries} (SQL_CONNECTOR_MAX_QUERIES)"
                )
                await self._update_health_status(
                    UpdateConnectorHealthRequestStatus.CRITICAL,
                    error_code="SqlConnectorTooManyQueries",
                )
                return  # File stays PENDING

            # Prepare watermarks for each query
            # watermark could be None, Dict, or List[Dict]
            if watermark is None:
                watermarks_per_query = [None] * len(queries)
            elif isinstance(watermark, list):
                # TODO: check the length matches
                watermarks_per_query = watermark
            else:
                # Single dict watermark - use for all queries
                watermarks_per_query = [watermark] * len(queries)

            # Execute all queries (ALL queries must succeed before updating watermark)
            query_results = []
            all_query_rows = []

            for idx, (query, wm) in enumerate(zip(queries, watermarks_per_query), 1):
                self.logger.debug(
                    f"Executing query {idx}/{len(queries)} for file {file_dto.id}"
                )
                rows = self._execute_query(query)  # If this fails, exception propagates
                self.logger.info(
                    f"Query {idx}/{len(queries)} returned {len(rows)} rows"
                )

                query_results.append(
                    {"query": query, "watermark_before": wm, "data": rows}
                )
                all_query_rows.append(rows)

            has_data = any(rows for rows in all_query_rows)
            total_rows = sum(len(rows) for rows in all_query_rows)

            # Handle no data case
            if not has_data:
                self.logger.info(f"No data found for file {file_dto.id}")

                # Unless the option to skip is set, upload file with empty data for transparency
                # This allows users to see that a query was executed but returned no rows
                # Note: Since no data was returned, the watermark remains unchanged.
                # The next poll cycle will execute the same query with the same watermark,
                # which is the expected behavior for polling connectors waiting for new data.

                if self.skip_upload_if_no_data:
                    self.logger.info(
                        f"Skipping upload for file {file_dto.id} as no data was found, leaving file PENDING"
                    )
                    new_file_status = ConnectorFileDtoStatus.PENDING
                else:
                    new_file_status = ConnectorFileDtoStatus.SUCCESS
                    # Denormalize output for single-query case (unless use_multi_query_format is True)
                    if is_single_query and not self.use_multi_query_format:
                        file_content = json.dumps(
                            {
                                "query": queries[0],
                                "watermark": watermark,
                                "data": [],  # Empty data array
                            },
                            indent=2,
                            default=str,
                        )
                    else:
                        # Multi-query format (or single-query with use_multi_query_format=True)
                        file_content = json.dumps(
                            {"queries": query_results},
                            indent=2,
                            default=str,
                        )

                    # Upload file even with no data
                    upload_request = UploadFileRequest(
                        filepath=file_path,
                        content=file_content.encode("utf-8"),
                        source_type=source_type,
                        file_id=file_dto.id,
                    )
                    await self.upload_file(upload_request)
                    self.logger.info(f"Uploaded file with no data rows: {file_path}")

                # Update files table
                # Use same metadata format as when there is data for consistency
                no_data_metadata = SaveConnectorFileRequestMetadata()
                no_data_metadata.additional_properties.update(
                    {
                        "row_count": 0,
                        "query_count": len(queries),
                        "watermark_before": watermark,
                        "watermark_after": watermark,  # No new data, so watermark doesn't advance
                    }
                )
                await self.save_files(
                    [
                        SaveConnectorFileRequest(
                            id=file_dto.id,
                            unique_external_id=file_dto.unique_external_id,
                            filepath=file_dto.filepath,
                            status=new_file_status,
                            metadata=no_data_metadata,
                        )
                    ]
                )
                await self._update_health_status(
                    UpdateConnectorHealthRequestStatus.HEALTHY
                )
                return

            # Has data - log and get new watermark
            # For single query: pass List[Dict], expect Dict back
            # For multi query: pass List[List[Dict]], expect List[Dict] back
            if is_single_query:
                self.logger.info(f"Retrieved {total_rows} rows for file {file_dto.id}")
                new_watermark = self.get_watermark(all_query_rows[0])

                # Check if we should use multi-query format
                if self.use_multi_query_format:
                    # Wrap single-query result in multi-query format
                    query_results[0]["watermark_after"] = new_watermark
                    file_content = json.dumps(
                        {"queries": query_results},
                        indent=2,
                        default=str,
                    )
                else:
                    # Use legacy single-query format
                    file_content = json.dumps(
                        {
                            "query": queries[0],
                            "watermark": watermark,  # Watermark used for THIS query
                            "data": all_query_rows[0],
                        },
                        indent=2,
                        default=str,
                    )
            else:
                self.logger.info(
                    f"Retrieved {total_rows} total rows across {len(queries)} queries for file {file_dto.id}"
                )
                raw_new_watermark = self.get_multiple_watermarks(all_query_rows)
                if not isinstance(raw_new_watermark, list):
                    raise ValueError(
                        f"get_multiple_watermarks must return List[Dict], "
                        f"got {type(raw_new_watermark)}"
                    )
                if len(raw_new_watermark) != len(query_results):
                    raise ValueError(
                        f"get_multiple_watermarks must return one watermark per query, "
                        f"got {len(raw_new_watermark)} watermarks for {len(query_results)} queries"
                    )

                # to deal with case where watermark was None on first run,
                # build watermarks_before from what is stored in the query
                # results
                watermarks_before = [qr["watermark_before"] for qr in query_results]

                new_watermark = self.handle_partial_watermarks(
                    watermarks_before, raw_new_watermark
                )

                # Add watermark_after to each query result
                for qr, wm_after in zip(query_results, new_watermark):
                    qr["watermark_after"] = wm_after

                file_content = json.dumps(
                    {"queries": query_results},
                    indent=2,
                    default=str,
                )

            # IMPORTANT: Save watermark to connector state BEFORE upload
            # This ensures we don't lose data if upload fails:
            # - If watermark save fails: ABORT, file stays PENDING, retry with same watermark
            # - If watermark save succeeds but upload fails: file stays PENDING, but we've
            #   already moved the watermark forward. On retry, we use file metadata watermark_before.
            if new_watermark != self.watermark:
                prev_watermark = self.watermark
                self.watermark = new_watermark
                try:
                    await self._save_watermark()
                    self.logger.debug(f"Saved watermark before upload: {new_watermark}")
                except Exception as wm_exc:
                    # Watermark save failed - ABORT processing
                    # Revert in-memory watermark to maintain consistency
                    # This ensures that if the PENDING file is lost, we use the last
                    # successfully persisted watermark instead of the unpersisted one
                    self.watermark = prev_watermark
                    # File stays PENDING, will retry next poll with same watermark
                    # NOTE: Future enhancement - consider adding exponential backoff for
                    # watermark save failures. Currently, the poll interval (default 10 min)
                    # provides natural spacing between retries.
                    self.logger.error(
                        f"Failed to save watermark, aborting file processing: {wm_exc}",
                        exc_info=True,
                    )
                    await self._update_health_status(
                        UpdateConnectorHealthRequestStatus.WARNING,
                        error_code="WatermarkSaveError",
                    )
                    return

            # Upload file to TDP
            upload_request = UploadFileRequest(
                filepath=file_path,
                content=file_content.encode("utf-8"),
                source_type=source_type,
                file_id=file_dto.id,
            )

            await self.upload_file(upload_request)
            self.logger.info(f"Uploaded file: {file_path}")

            # Mark file as SUCCESS
            # Store both watermarks for clarity:
            # - watermark_before: the watermark used for the query
            # - watermark_after: the new watermark calculated from results
            success_metadata = SaveConnectorFileRequestMetadata()
            success_metadata.additional_properties.update(
                {
                    "row_count": total_rows,
                    "query_count": len(queries),
                    "watermark_before": watermark,
                    "watermark_after": new_watermark,
                }
            )
            await self.save_files(
                [
                    SaveConnectorFileRequest(
                        id=file_dto.id,
                        unique_external_id=file_dto.unique_external_id,
                        filepath=file_dto.filepath,
                        status=ConnectorFileDtoStatus.SUCCESS,
                        metadata=success_metadata,
                    )
                ]
            )

            # File processed successfully
            await self._update_health_status(UpdateConnectorHealthRequestStatus.HEALTHY)

        except Exception as exc:
            self.logger.error(
                f"Failed to process file {file_dto.id}: {exc}", exc_info=True
            )

            # Get current error count and increment
            existing_error_count = 0
            if hasattr(file_dto, "error_count") and file_dto.error_count is not None:
                existing_error_count = file_dto.error_count
            new_error_count = existing_error_count + 1

            # Calculate exponential backoff delay
            # Delay = min(BASE_BACKOFF_SECONDS * 2^(error_count-1), MAX_BACKOFF_SECONDS)
            backoff_delay = min(
                BASE_BACKOFF_SECONDS * (2 ** (new_error_count - 1)),
                MAX_BACKOFF_SECONDS,
            )

            # Log with appropriate severity based on error count
            # Note: file_dto.metadata is a ConnectorFileDtoMetadataType0 object,
            # not a dict, so we need to access additional_properties
            file_watermark_before = (
                file_dto.metadata.additional_properties.get("watermark_before")
                if file_dto.metadata
                else None
            )
            if new_error_count >= CRITICAL_ERROR_THRESHOLD:
                self.logger.error(
                    f"File {file_dto.id} failed (attempt {new_error_count}). "
                    f"Persistent failure - will retry in {backoff_delay}s. "
                    f"File metadata watermark_before: {file_watermark_before}, "
                    f"Connector state watermark: {self.watermark}. "
                    f"Error: {str(exc)[:200]}"
                )
            else:
                self.logger.warning(
                    f"File {file_dto.id} failed (attempt {new_error_count}), "
                    f"will retry in {backoff_delay}s"
                )

            # Update file with error info - save as ERROR so error_message is visible
            # Preserve existing metadata (including watermark_before) for retry
            # Note: file_dto.metadata is a ConnectorFileDtoMetadataType0 object,
            # not a dict, so we need to access additional_properties
            existing_metadata = (
                file_dto.metadata.additional_properties if file_dto.metadata else {}
            )
            error_metadata = SaveConnectorFileRequestMetadata()
            error_metadata.additional_properties.update(existing_metadata)

            try:
                await self.save_files(
                    [
                        SaveConnectorFileRequest(
                            id=file_dto.id,
                            unique_external_id=file_dto.unique_external_id,
                            filepath=file_dto.filepath,
                            status=ConnectorFileDtoStatus.ERROR,
                            error_message=str(exc)[:500],
                            error_count=new_error_count,
                            metadata=error_metadata,
                        )
                    ]
                )
            except Exception as save_exc:
                self.logger.error(
                    f"Failed to update file {file_dto.id} error count: {save_exc}",
                    exc_info=True,
                )

            # Set health status based on error count
            if new_error_count >= CRITICAL_ERROR_THRESHOLD:
                await self._update_health_status(
                    UpdateConnectorHealthRequestStatus.CRITICAL,
                    error_code="PersistentFileProcessingError",
                )
            else:
                await self._update_health_status(
                    UpdateConnectorHealthRequestStatus.WARNING,
                    error_code="FileProcessingError",
                )

            # Sleep before returning to Poll loop to implement exponential backoff.
            # After this sleep, the function returns and Poll waits for its interval.
            # The retry happens in the next poll iteration when it finds this PENDING file.
            # Total wait between retries = backoff_delay + poll_interval
            self.logger.info(f"Backing off for {backoff_delay}s before next retry")
            await asyncio.sleep(backoff_delay)

    async def _update_health_status(
        self,
        status: UpdateConnectorHealthRequestStatus,
        error_code: Optional[str] = None,
    ):
        """
        Update the connector health status in TDP.

        Args:
            status: The health status to set (HEALTHY, WARNING, CRITICAL)
            error_code: Optional error code for WARNING or CRITICAL status
        """
        try:
            if not self.connector_id:
                self.logger.warning("Cannot update health status: connector_id is None")
                return

            # Build request - only include error_code if provided
            request = UpdateConnectorHealthRequest(status=status)
            if error_code is not None:
                request.error_code = error_code

            await self.tdp_api.update_health(self.connector_id, request)
            self.logger.debug(f"Updated health status to {status}")
        except Exception as exc:
            self.logger.error(
                f"Failed to update health status to {status}: {exc}", exc_info=True
            )

    @retry(
        retry=retry_if_exception_type(ConnectorError),
        stop=stop_after_attempt(3),
        wait=wait_fixed(2),
        before_sleep=before_sleep_log(logging.getLogger(__name__), logging.WARNING),
        reraise=True,
    )
    async def _load_watermark(self):
        """
        Load watermark from connector state on startup.

        This loads the in-memory watermark from connector state. This watermark is used
        when creating NEW PENDING files (for the query).

        IMPORTANT: The in-memory watermark is NOT used when processing existing PENDING
        files. When a PENDING file exists, _process_file() uses the watermark stored in
        the file's metadata, not this in-memory value. This ensures retry scenarios use
        the correct starting point (the watermark at the time the file was created).

        Watermark Source Summary:
        - For NEW files: connector state watermark (loaded here, stored in file metadata)
        - For PENDING files (retry): file.metadata.watermark_before (checked every poll cycle)

        Implements retry logic for transient TDP API failures (ConnectorError).
        Uses tenacity decorator for automatic retry.

        Strategy:
        - Retry up to 3 times with 2-second delay for ConnectorError (TDP API errors)
        - Fail fast for unexpected exceptions (no retry)

        Raises:
            ConnectorError: If watermark load fails after retries
            Exception: If unexpected error occurs (fails immediately without retry)
        """
        watermark_value = await self.get_value("watermark")
        if watermark_value and watermark_value.value:
            # The value is stored as a dict in ConnectorValueDto
            watermark_dict = watermark_value.value.to_dict()

            # For multi-query connectors, watermark is stored as {"watermarks": [...]}
            # For single-query connectors, watermark is stored directly as a dict
            if not self._is_single_query and "watermarks" in watermark_dict:
                self.watermark = watermark_dict["watermarks"]
            else:
                self.watermark = watermark_dict

            self.logger.info(f"Loaded watermark from connector state: {self.watermark}")
        else:
            # Use initial watermark from config if available
            config_dict = self.get_config_as_dict()
            self.watermark = config_dict.get("initial_watermark", None)
            self.logger.info(f"No saved watermark, using initial: {self.watermark}")

    async def _save_watermark(self):
        """
        Save watermark to connector state.

        This is called BEFORE uploading the file to S3 (see _process_file).
        If save fails, the file stays PENDING and will be retried on next poll.

        For multi-query connectors, the watermark is a List[Dict] which must be wrapped
        in a dict for storage (since save_value expects a dict).

        Raises:
            Exception: If watermark save fails (caught by caller)
        """
        try:
            # For multi-query connectors, wrap list in dict for storage
            # For single-query connectors, use dict directly
            if not self._is_single_query:
                # Multi-query: watermark is List[Dict], wrap it
                watermark_to_save = {"watermarks": self.watermark or []}
            else:
                # Single-query: watermark is Dict or None
                watermark_to_save = self.watermark or {}

            await self.save_value("watermark", watermark_to_save, secure=False)
            self.logger.debug(f"Saved watermark: {self.watermark}")

        except Exception as exc:
            self.logger.error(
                f"Failed to save watermark: {exc}. File will stay PENDING for retry.",
                exc_info=True,
            )
            raise
