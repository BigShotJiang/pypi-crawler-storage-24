"""EncryptedA2AClient — middleware wrapper that adds encryption to any A2A client."""

from __future__ import annotations

from typing import Any, Protocol

from a2a_crypt._core import (
    KeyPair,
    KeyStore,
    Session,
    is_encrypted,
    negotiate_cipher,
    parse_agent_card,
)


class A2AClientProtocol(Protocol):
    """Protocol that any A2A client must satisfy to be wrapped."""

    async def send_message(self, task_id: str, message: dict) -> dict: ...
    async def get_agent_card(self, url: str) -> dict: ...


class EncryptedA2AClient:
    """Wraps an existing A2A client to transparently encrypt/decrypt messages.

    Usage:
        keystore = KeyStore.from_file("~/.a2a-crypt/keys.json")
        client = EncryptedA2AClient(
            base_client=my_a2a_client,
            keystore=keystore,
            cipher="xchacha20-poly1305",
        )
        response = await client.send_message(task_id, message)
    """

    def __init__(
        self,
        base_client: Any,
        keystore: KeyStore,
        cipher: str = "xchacha20-poly1305",
        policy: str = "prefer",
    ) -> None:
        """
        Args:
            base_client: An A2A client instance with send_message and get_agent_card methods.
            keystore: A KeyStore containing the local agent's keys.
            cipher: Preferred cipher suite name.
            policy: Encryption policy — "require", "prefer", "opportunistic", or "disabled".
        """
        self.base_client = base_client
        self.keystore = keystore
        self.preferred_cipher = cipher
        self.policy = policy
        self._sessions: dict[str, Session] = {}
        self._remote_info: dict[str, dict] = {}

    async def _get_or_create_session(
        self, remote_url: str, context_id: str
    ) -> Session | None:
        """Get an existing session or create one by fetching the remote's Agent Card."""
        session_key = f"{remote_url}::{context_id}"
        if session_key in self._sessions:
            return self._sessions[session_key]

        # Fetch remote Agent Card
        try:
            agent_card = await self.base_client.get_agent_card(remote_url)
        except Exception:
            if self.policy == "require":
                raise RuntimeError(
                    f"Cannot fetch Agent Card from {remote_url} and encryption is required"
                )
            return None

        # Check for A2A-Crypt support
        crypt_ext = parse_agent_card(agent_card)
        if crypt_ext is None:
            if self.policy == "require":
                raise RuntimeError(
                    f"Remote {remote_url} does not support A2A-Crypt and encryption is required"
                )
            return None

        # Store remote info
        self._remote_info[remote_url] = crypt_ext

        # Negotiate cipher
        local_ciphers = [self.preferred_cipher]
        if self.preferred_cipher != "aes-256-gcm":
            local_ciphers.append("aes-256-gcm")
        if self.preferred_cipher != "xchacha20-poly1305":
            local_ciphers.append("xchacha20-poly1305")

        try:
            selected_cipher = negotiate_cipher(local_ciphers, crypt_ext["ciphers"])
        except Exception:
            if self.policy == "require":
                raise RuntimeError(
                    f"No mutually supported cipher with {remote_url}"
                )
            return None

        # Create session
        local_kp = self.keystore.active_key()
        if local_kp is None:
            raise RuntimeError("No active key in keystore")

        session = Session(
            local_keypair=local_kp,
            remote_public_key=crypt_ext["public_key"],
            remote_key_id=crypt_ext["key_id"],
            context_id=context_id,
            cipher=selected_cipher,
        )
        self._sessions[session_key] = session
        return session

    async def send_message(
        self,
        task_id: str,
        message: dict,
        *,
        remote_url: str | None = None,
        context_id: str | None = None,
    ) -> dict:
        """Send an encrypted message.

        Args:
            task_id: The A2A task ID.
            message: The A2A JSON-RPC message dict.
            remote_url: The remote agent's URL (for Agent Card fetching).
            context_id: The A2A context ID (defaults to task_id).
        """
        if self.policy == "disabled":
            return await self.base_client.send_message(task_id, message)

        ctx = context_id or task_id

        if remote_url:
            session = await self._get_or_create_session(remote_url, ctx)
        else:
            # Try to find an existing session by context
            session = None
            for key, s in self._sessions.items():
                if key.endswith(f"::{ctx}"):
                    session = s
                    break

        if session is None:
            if self.policy == "require":
                raise RuntimeError(
                    "No session available and encryption is required. "
                    "Provide remote_url to establish a session."
                )
            # Fallback to plaintext
            return await self.base_client.send_message(task_id, message)

        # Determine if this is the first message (include public key)
        include_pk = session.message_count == 0

        # Encrypt
        encrypted = session.encrypt_message(message, include_public_key=include_pk)

        # Send
        response = await self.base_client.send_message(task_id, encrypted)

        # Decrypt response if encrypted
        if is_encrypted(response):
            response = session.decrypt_message(response)

        return response

    def create_session(
        self,
        remote_public_key: str,
        remote_key_id: str,
        context_id: str,
        cipher: str | None = None,
    ) -> Session:
        """Manually create a session without fetching an Agent Card.

        Useful when you already have the remote's public key.
        """
        local_kp = self.keystore.active_key()
        if local_kp is None:
            raise RuntimeError("No active key in keystore")

        session = Session(
            local_keypair=local_kp,
            remote_public_key=remote_public_key,
            remote_key_id=remote_key_id,
            context_id=context_id,
            cipher=cipher or self.preferred_cipher,
        )

        session_key = f"manual::{context_id}"
        self._sessions[session_key] = session
        return session

    @property
    def active_sessions(self) -> list[str]:
        """List active session keys."""
        return list(self._sessions.keys())
