"""A2A-Crypt — End-to-end payload encryption for the A2A protocol."""

from a2a_crypt._core import (
    KeyPair,
    KeyStore,
    Session,
    is_encrypted,
    inspect_metadata,
    parse_agent_card,
    negotiate_cipher,
    build_agent_card_extension,
)
from a2a_crypt.client import EncryptedA2AClient

__all__ = [
    "KeyPair",
    "KeyStore",
    "Session",
    "EncryptedA2AClient",
    "is_encrypted",
    "inspect_metadata",
    "parse_agent_card",
    "negotiate_cipher",
    "build_agent_card_extension",
]

__version__ = "0.1.0"
