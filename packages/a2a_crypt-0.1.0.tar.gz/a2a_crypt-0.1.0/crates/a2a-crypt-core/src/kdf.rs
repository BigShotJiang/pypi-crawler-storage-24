use hkdf::Hkdf;
use sha2::Sha256;
use zeroize::Zeroize;

use crate::error::Result;
use crate::key::SharedSecret;

/// A derived session key (256-bit).
pub struct SessionKey {
    bytes: [u8; 32],
}

impl SessionKey {
    pub fn as_bytes(&self) -> &[u8; 32] {
        &self.bytes
    }
}

impl Drop for SessionKey {
    fn drop(&mut self) {
        self.bytes.zeroize();
    }
}

/// Compute the deterministic salt for HKDF.
///
/// `salt = SHA256(sorted(key_id_a, key_id_b) || context_id)`
fn compute_salt(key_id_a: &str, key_id_b: &str, context_id: &str) -> [u8; 32] {
    use sha2::Digest;

    let mut hasher = Sha256::new();
    // Sort key IDs for determinism — both sides compute the same salt
    if key_id_a <= key_id_b {
        hasher.update(key_id_a.as_bytes());
        hasher.update(key_id_b.as_bytes());
    } else {
        hasher.update(key_id_b.as_bytes());
        hasher.update(key_id_a.as_bytes());
    }
    hasher.update(context_id.as_bytes());
    hasher.finalize().into()
}

/// Derive an initial session key from an ECDH shared secret.
///
/// ```text
/// session_key = HKDF-SHA256(
///   ikm  = shared_secret,
///   salt = SHA256(sorted(key_id_a, key_id_b) || context_id),
///   info = "a2a-crypt-session-v1",
///   len  = 32
/// )
/// ```
pub fn derive_session_key(
    shared_secret: &SharedSecret,
    key_id_a: &str,
    key_id_b: &str,
    context_id: &str,
) -> Result<SessionKey> {
    let salt = compute_salt(key_id_a, key_id_b, context_id);
    let hk = Hkdf::<Sha256>::new(Some(&salt), shared_secret.as_bytes());
    let mut okm = [0u8; 32];
    hk.expand(b"a2a-crypt-session-v1", &mut okm)
        .expect("32 bytes is a valid HKDF-SHA256 output length");
    Ok(SessionKey { bytes: okm })
}

/// Derive a rotated session key.
///
/// ```text
/// new_session_key = HKDF-SHA256(
///   ikm  = shared_secret,
///   salt = SHA256(sorted(key_id_a, key_id_b) || context_id || rotation_counter),
///   info = "a2a-crypt-session-v1-rotation",
///   len  = 32
/// )
/// ```
pub fn derive_rotated_session_key(
    shared_secret: &SharedSecret,
    key_id_a: &str,
    key_id_b: &str,
    context_id: &str,
    rotation_counter: u64,
) -> Result<SessionKey> {
    use sha2::Digest;

    let mut hasher = Sha256::new();
    if key_id_a <= key_id_b {
        hasher.update(key_id_a.as_bytes());
        hasher.update(key_id_b.as_bytes());
    } else {
        hasher.update(key_id_b.as_bytes());
        hasher.update(key_id_a.as_bytes());
    }
    hasher.update(context_id.as_bytes());
    hasher.update(rotation_counter.to_be_bytes());
    let salt: [u8; 32] = hasher.finalize().into();

    let hk = Hkdf::<Sha256>::new(Some(&salt), shared_secret.as_bytes());
    let mut okm = [0u8; 32];
    hk.expand(b"a2a-crypt-session-v1-rotation", &mut okm)
        .expect("32 bytes is a valid HKDF-SHA256 output length");
    Ok(SessionKey { bytes: okm })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::key::KeyPair;

    #[test]
    fn test_session_key_derivation_deterministic() {
        let alice = KeyPair::generate();
        let bob = KeyPair::generate();

        let shared_ab = alice.diffie_hellman(&bob.public_key);
        let shared_ba = bob.diffie_hellman(&alice.public_key);

        let ctx = "ctx-123";
        let sk_a =
            derive_session_key(&shared_ab, &alice.key_id, &bob.key_id, ctx).unwrap();
        let sk_b =
            derive_session_key(&shared_ba, &alice.key_id, &bob.key_id, ctx).unwrap();

        assert_eq!(sk_a.as_bytes(), sk_b.as_bytes());
    }

    #[test]
    fn test_different_contexts_different_keys() {
        let alice = KeyPair::generate();
        let bob = KeyPair::generate();
        let shared = alice.diffie_hellman(&bob.public_key);

        let sk1 =
            derive_session_key(&shared, &alice.key_id, &bob.key_id, "ctx-1").unwrap();
        let sk2 =
            derive_session_key(&shared, &alice.key_id, &bob.key_id, "ctx-2").unwrap();

        assert_ne!(sk1.as_bytes(), sk2.as_bytes());
    }

    #[test]
    fn test_key_rotation_produces_different_keys() {
        let alice = KeyPair::generate();
        let bob = KeyPair::generate();
        let shared = alice.diffie_hellman(&bob.public_key);
        let ctx = "ctx-123";

        let sk0 = derive_session_key(&shared, &alice.key_id, &bob.key_id, ctx).unwrap();
        let sk1 = derive_rotated_session_key(&shared, &alice.key_id, &bob.key_id, ctx, 1).unwrap();
        let sk2 = derive_rotated_session_key(&shared, &alice.key_id, &bob.key_id, ctx, 2).unwrap();

        assert_ne!(sk0.as_bytes(), sk1.as_bytes());
        assert_ne!(sk1.as_bytes(), sk2.as_bytes());
    }

    #[test]
    fn test_rotation_deterministic_both_sides() {
        let alice = KeyPair::generate();
        let bob = KeyPair::generate();

        let shared_ab = alice.diffie_hellman(&bob.public_key);
        let shared_ba = bob.diffie_hellman(&alice.public_key);
        let ctx = "ctx-456";

        let sk_a =
            derive_rotated_session_key(&shared_ab, &alice.key_id, &bob.key_id, ctx, 5).unwrap();
        let sk_b =
            derive_rotated_session_key(&shared_ba, &alice.key_id, &bob.key_id, ctx, 5).unwrap();

        assert_eq!(sk_a.as_bytes(), sk_b.as_bytes());
    }
}
