use base64::{engine::general_purpose::URL_SAFE_NO_PAD, Engine};
use rand::rngs::OsRng;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::path::Path;
use x25519_dalek::{PublicKey, StaticSecret};
use zeroize::Zeroize;

use crate::error::{A2ACryptError, Result};

/// An X25519 key pair for ECDH key exchange.
pub struct KeyPair {
    pub key_id: String,
    secret: StaticSecret,
    pub public_key: PublicKey,
}

impl KeyPair {
    /// Generate a new random X25519 key pair.
    pub fn generate() -> Self {
        let secret = StaticSecret::random_from_rng(OsRng);
        let public_key = PublicKey::from(&secret);
        let key_id = Self::derive_key_id(&public_key);
        Self {
            key_id,
            secret,
            public_key,
        }
    }

    /// Create a key pair from an existing secret key (base64url-encoded).
    pub fn from_secret_bytes(secret_bytes: &[u8]) -> Result<Self> {
        let bytes: [u8; 32] = secret_bytes
            .try_into()
            .map_err(|_| A2ACryptError::InvalidKeyMaterial("secret key must be 32 bytes".into()))?;
        let secret = StaticSecret::from(bytes);
        let public_key = PublicKey::from(&secret);
        let key_id = Self::derive_key_id(&public_key);
        Ok(Self {
            key_id,
            secret,
            public_key,
        })
    }

    /// Perform ECDH key exchange: compute shared secret with a remote public key.
    pub fn diffie_hellman(&self, remote_public: &PublicKey) -> SharedSecret {
        let shared = self.secret.diffie_hellman(remote_public);
        SharedSecret {
            bytes: *shared.as_bytes(),
        }
    }

    /// Get the secret key bytes (for serialization only).
    pub fn secret_bytes(&self) -> [u8; 32] {
        // StaticSecret doesn't expose bytes directly, so we reconstruct
        // by serializing through the diffie_hellman with a known point.
        // Instead, we store the bytes at creation time.
        // Actually, x25519-dalek StaticSecret can be converted to bytes:
        self.secret.to_bytes()
    }

    /// Get the public key as base64url-encoded string.
    pub fn public_key_b64(&self) -> String {
        URL_SAFE_NO_PAD.encode(self.public_key.as_bytes())
    }

    /// Derive a key ID from the public key (first 16 hex chars of the public key).
    fn derive_key_id(public_key: &PublicKey) -> String {
        let bytes = public_key.as_bytes();
        bytes[..8]
            .iter()
            .map(|b| format!("{:02x}", b))
            .collect()
    }
}

/// Parse a base64url-encoded public key string into an X25519 PublicKey.
pub fn parse_public_key(b64: &str) -> Result<PublicKey> {
    let bytes = URL_SAFE_NO_PAD
        .decode(b64)
        .map_err(|e| A2ACryptError::InvalidKeyMaterial(format!("invalid base64url: {e}")))?;
    let arr: [u8; 32] = bytes
        .try_into()
        .map_err(|_| A2ACryptError::InvalidKeyMaterial("public key must be 32 bytes".into()))?;
    Ok(PublicKey::from(arr))
}

/// A shared secret derived from ECDH.
pub struct SharedSecret {
    bytes: [u8; 32],
}

impl SharedSecret {
    pub fn as_bytes(&self) -> &[u8; 32] {
        &self.bytes
    }
}

impl Drop for SharedSecret {
    fn drop(&mut self) {
        self.bytes.zeroize();
    }
}

/// Serializable key entry for the key store.
#[derive(Serialize, Deserialize)]
struct StoredKey {
    key_id: String,
    secret_key: String,
    public_key: String,
}

/// Persistent key store backed by a JSON file.
pub struct KeyStore {
    keys: HashMap<String, KeyPair>,
    /// The active key ID used for new sessions.
    active_key_id: Option<String>,
    path: Option<std::path::PathBuf>,
}

impl KeyStore {
    /// Create an empty in-memory key store.
    pub fn new() -> Self {
        Self {
            keys: HashMap::new(),
            active_key_id: None,
            path: None,
        }
    }

    /// Load a key store from a JSON file, or create a new one if the file doesn't exist.
    pub fn from_file(path: impl AsRef<Path>) -> Result<Self> {
        let path = path.as_ref();
        let mut store = if path.exists() {
            let data = std::fs::read_to_string(path)?;
            let stored: Vec<StoredKey> = serde_json::from_str(&data)?;
            let mut keys = HashMap::new();
            let mut active_key_id = None;
            for entry in stored {
                let secret_bytes = URL_SAFE_NO_PAD.decode(&entry.secret_key)?;
                let kp = KeyPair::from_secret_bytes(&secret_bytes)?;
                if active_key_id.is_none() {
                    active_key_id = Some(kp.key_id.clone());
                }
                keys.insert(kp.key_id.clone(), kp);
            }
            Self {
                keys,
                active_key_id,
                path: Some(path.to_path_buf()),
            }
        } else {
            Self {
                keys: HashMap::new(),
                active_key_id: None,
                path: Some(path.to_path_buf()),
            }
        };

        // If no keys exist, generate one
        if store.keys.is_empty() {
            let kp = KeyPair::generate();
            store.active_key_id = Some(kp.key_id.clone());
            store.keys.insert(kp.key_id.clone(), kp);
            store.save()?;
        }

        Ok(store)
    }

    /// Add a key pair to the store and optionally set it as active.
    pub fn add_key(&mut self, kp: KeyPair, set_active: bool) {
        let id = kp.key_id.clone();
        self.keys.insert(id.clone(), kp);
        if set_active || self.active_key_id.is_none() {
            self.active_key_id = Some(id);
        }
    }

    /// Get the active key pair.
    pub fn active_key(&self) -> Option<&KeyPair> {
        self.active_key_id
            .as_ref()
            .and_then(|id| self.keys.get(id))
    }

    /// Get a key pair by its ID.
    pub fn get_key(&self, key_id: &str) -> Option<&KeyPair> {
        self.keys.get(key_id)
    }

    /// Get the active key ID.
    pub fn active_key_id(&self) -> Option<&str> {
        self.active_key_id.as_deref()
    }

    /// List all key IDs.
    pub fn key_ids(&self) -> Vec<&str> {
        self.keys.keys().map(|s| s.as_str()).collect()
    }

    /// Save the key store to its file (if file-backed).
    pub fn save(&self) -> Result<()> {
        let path = match &self.path {
            Some(p) => p,
            None => return Ok(()),
        };

        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent)?;
        }

        let stored: Vec<StoredKey> = self
            .keys
            .values()
            .map(|kp| StoredKey {
                key_id: kp.key_id.clone(),
                secret_key: URL_SAFE_NO_PAD.encode(kp.secret_bytes()),
                public_key: kp.public_key_b64(),
            })
            .collect();

        let json = serde_json::to_string_pretty(&stored)?;
        std::fs::write(path, json)?;
        Ok(())
    }
}

impl Default for KeyStore {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_keypair_generation() {
        let kp = KeyPair::generate();
        assert_eq!(kp.key_id.len(), 16); // 8 bytes = 16 hex chars
        assert_eq!(kp.public_key.as_bytes().len(), 32);
    }

    #[test]
    fn test_ecdh_shared_secret() {
        let alice = KeyPair::generate();
        let bob = KeyPair::generate();

        let secret_ab = alice.diffie_hellman(&bob.public_key);
        let secret_ba = bob.diffie_hellman(&alice.public_key);

        assert_eq!(secret_ab.as_bytes(), secret_ba.as_bytes());
    }

    #[test]
    fn test_public_key_roundtrip() {
        let kp = KeyPair::generate();
        let b64 = kp.public_key_b64();
        let parsed = parse_public_key(&b64).unwrap();
        assert_eq!(parsed.as_bytes(), kp.public_key.as_bytes());
    }

    #[test]
    fn test_keypair_from_secret_bytes() {
        let kp1 = KeyPair::generate();
        let secret_bytes = kp1.secret_bytes();
        let kp2 = KeyPair::from_secret_bytes(&secret_bytes).unwrap();
        assert_eq!(kp1.public_key.as_bytes(), kp2.public_key.as_bytes());
        assert_eq!(kp1.key_id, kp2.key_id);
    }

    #[test]
    fn test_keystore_in_memory() {
        let mut store = KeyStore::new();
        let kp = KeyPair::generate();
        let kid = kp.key_id.clone();
        store.add_key(kp, true);

        assert_eq!(store.active_key_id(), Some(kid.as_str()));
        assert!(store.get_key(&kid).is_some());
    }

    #[test]
    fn test_keystore_file_roundtrip() {
        let dir = std::env::temp_dir().join("a2a-crypt-test-keystore");
        let _ = std::fs::remove_dir_all(&dir);
        let path = dir.join("keys.json");

        // Create and save
        let store1 = KeyStore::from_file(&path).unwrap();
        let active_id = store1.active_key_id().unwrap().to_string();
        let pub_key = store1.active_key().unwrap().public_key_b64();

        // Reload
        let store2 = KeyStore::from_file(&path).unwrap();
        assert_eq!(store2.active_key_id(), Some(active_id.as_str()));
        assert_eq!(store2.active_key().unwrap().public_key_b64(), pub_key);

        let _ = std::fs::remove_dir_all(&dir);
    }
}
