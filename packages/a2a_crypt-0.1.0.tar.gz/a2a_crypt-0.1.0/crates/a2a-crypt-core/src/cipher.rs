use aes_gcm::{aead::Aead, Aes256Gcm, KeyInit, Nonce as AesNonce};
use chacha20poly1305::{XChaCha20Poly1305, XNonce};
use serde::{Deserialize, Serialize};

use crate::error::{A2ACryptError, Result};
use crate::kdf::SessionKey;

/// Supported cipher suite identifiers, matching the protocol spec.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum CipherSuite {
    #[serde(rename = "xchacha20-poly1305")]
    XChaCha20Poly1305,
    #[serde(rename = "aes-256-gcm")]
    Aes256Gcm,
}

impl CipherSuite {
    /// Nonce size in bytes for this cipher suite.
    pub fn nonce_size(&self) -> usize {
        match self {
            Self::XChaCha20Poly1305 => 24,
            Self::Aes256Gcm => 12,
        }
    }

    /// String identifier as used in the wire format.
    pub fn as_str(&self) -> &'static str {
        match self {
            Self::XChaCha20Poly1305 => "xchacha20-poly1305",
            Self::Aes256Gcm => "aes-256-gcm",
        }
    }

    /// Parse from string identifier.
    pub fn from_str(s: &str) -> Result<Self> {
        match s {
            "xchacha20-poly1305" => Ok(Self::XChaCha20Poly1305),
            "aes-256-gcm" => Ok(Self::Aes256Gcm),
            _ => Err(A2ACryptError::CipherMismatch),
        }
    }
}

impl std::fmt::Display for CipherSuite {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.write_str(self.as_str())
    }
}

/// Negotiate the cipher suite: select the first cipher from the client's preference
/// list that the remote also supports.
pub fn negotiate_cipher(client_prefs: &[CipherSuite], remote_prefs: &[CipherSuite]) -> Result<CipherSuite> {
    for cipher in client_prefs {
        if remote_prefs.contains(cipher) {
            return Ok(*cipher);
        }
    }
    Err(A2ACryptError::CipherMismatch)
}

/// Encrypt plaintext using the specified cipher suite.
pub fn encrypt(
    cipher: CipherSuite,
    key: &SessionKey,
    nonce: &[u8],
    plaintext: &[u8],
) -> Result<Vec<u8>> {
    match cipher {
        CipherSuite::XChaCha20Poly1305 => {
            let cipher_impl = XChaCha20Poly1305::new(key.as_bytes().into());
            let xnonce = XNonce::from_slice(nonce);
            cipher_impl
                .encrypt(xnonce, plaintext)
                .map_err(|e| A2ACryptError::DecryptionFailed(format!("encryption failed: {e}")))
        }
        CipherSuite::Aes256Gcm => {
            let cipher_impl = Aes256Gcm::new(key.as_bytes().into());
            let aes_nonce = AesNonce::from_slice(nonce);
            cipher_impl
                .encrypt(aes_nonce, plaintext)
                .map_err(|e| A2ACryptError::DecryptionFailed(format!("encryption failed: {e}")))
        }
    }
}

/// Decrypt ciphertext using the specified cipher suite.
pub fn decrypt(
    cipher: CipherSuite,
    key: &SessionKey,
    nonce: &[u8],
    ciphertext: &[u8],
) -> Result<Vec<u8>> {
    match cipher {
        CipherSuite::XChaCha20Poly1305 => {
            let cipher_impl = XChaCha20Poly1305::new(key.as_bytes().into());
            let xnonce = XNonce::from_slice(nonce);
            cipher_impl
                .decrypt(xnonce, ciphertext)
                .map_err(|_| A2ACryptError::DecryptionFailed("authentication tag mismatch".into()))
        }
        CipherSuite::Aes256Gcm => {
            let cipher_impl = Aes256Gcm::new(key.as_bytes().into());
            let aes_nonce = AesNonce::from_slice(nonce);
            cipher_impl
                .decrypt(aes_nonce, ciphertext)
                .map_err(|_| A2ACryptError::DecryptionFailed("authentication tag mismatch".into()))
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::kdf::derive_session_key;
    use crate::key::KeyPair;
    use rand::RngCore;

    fn make_session_key() -> SessionKey {
        let alice = KeyPair::generate();
        let bob = KeyPair::generate();
        let shared = alice.diffie_hellman(&bob.public_key);
        derive_session_key(&shared, &alice.key_id, &bob.key_id, "test-ctx").unwrap()
    }

    #[test]
    fn test_xchacha20_roundtrip() {
        let key = make_session_key();
        let mut nonce = [0u8; 24];
        rand::thread_rng().fill_bytes(&mut nonce);

        let plaintext = b"Hello, A2A-Crypt!";
        let ciphertext =
            encrypt(CipherSuite::XChaCha20Poly1305, &key, &nonce, plaintext).unwrap();
        let decrypted =
            decrypt(CipherSuite::XChaCha20Poly1305, &key, &nonce, &ciphertext).unwrap();

        assert_eq!(decrypted, plaintext);
    }

    #[test]
    fn test_aes256gcm_roundtrip() {
        let key = make_session_key();
        let mut nonce = [0u8; 12];
        rand::thread_rng().fill_bytes(&mut nonce);

        let plaintext = b"Hello, A2A-Crypt with AES!";
        let ciphertext = encrypt(CipherSuite::Aes256Gcm, &key, &nonce, plaintext).unwrap();
        let decrypted = decrypt(CipherSuite::Aes256Gcm, &key, &nonce, &ciphertext).unwrap();

        assert_eq!(decrypted, plaintext);
    }

    #[test]
    fn test_wrong_key_fails() {
        let key1 = make_session_key();
        let key2 = make_session_key();
        let mut nonce = [0u8; 24];
        rand::thread_rng().fill_bytes(&mut nonce);

        let ciphertext =
            encrypt(CipherSuite::XChaCha20Poly1305, &key1, &nonce, b"secret").unwrap();
        let result = decrypt(CipherSuite::XChaCha20Poly1305, &key2, &nonce, &ciphertext);

        assert!(result.is_err());
    }

    #[test]
    fn test_tampered_ciphertext_fails() {
        let key = make_session_key();
        let mut nonce = [0u8; 24];
        rand::thread_rng().fill_bytes(&mut nonce);

        let mut ciphertext =
            encrypt(CipherSuite::XChaCha20Poly1305, &key, &nonce, b"secret").unwrap();
        ciphertext[0] ^= 0xFF; // Tamper with first byte
        let result = decrypt(CipherSuite::XChaCha20Poly1305, &key, &nonce, &ciphertext);

        assert!(result.is_err());
    }

    #[test]
    fn test_cipher_negotiation() {
        let client = vec![CipherSuite::XChaCha20Poly1305, CipherSuite::Aes256Gcm];
        let remote = vec![CipherSuite::Aes256Gcm, CipherSuite::XChaCha20Poly1305];

        let result = negotiate_cipher(&client, &remote).unwrap();
        assert_eq!(result, CipherSuite::XChaCha20Poly1305); // Client's first preference wins
    }

    #[test]
    fn test_cipher_negotiation_no_match() {
        let client = vec![CipherSuite::XChaCha20Poly1305];
        let remote = vec![CipherSuite::Aes256Gcm];

        let result = negotiate_cipher(&client, &remote);
        assert!(result.is_err());
    }

    #[test]
    fn test_cipher_suite_str_roundtrip() {
        assert_eq!(
            CipherSuite::from_str(CipherSuite::XChaCha20Poly1305.as_str()).unwrap(),
            CipherSuite::XChaCha20Poly1305
        );
        assert_eq!(
            CipherSuite::from_str(CipherSuite::Aes256Gcm.as_str()).unwrap(),
            CipherSuite::Aes256Gcm
        );
    }
}
