use std::time::{Duration, Instant};

use crate::cipher::CipherSuite;
use crate::error::Result;
use crate::kdf::{derive_rotated_session_key, derive_session_key, SessionKey};
use crate::key::{KeyPair, SharedSecret};
use crate::nonce::{generate_nonce, NonceTracker};
use x25519_dalek::PublicKey;

/// Configuration for automatic key rotation triggers.
#[derive(Debug, Clone)]
pub struct RotationPolicy {
    /// Rotate after this duration (default: 24 hours).
    pub max_age: Duration,
    /// Rotate after this many messages (default: 1000).
    pub max_messages: u64,
}

impl Default for RotationPolicy {
    fn default() -> Self {
        Self {
            max_age: Duration::from_secs(24 * 60 * 60),
            max_messages: 1000,
        }
    }
}

/// An active encryption session between two agents.
pub struct Session {
    /// Our key ID.
    pub local_key_id: String,
    /// Remote agent's key ID.
    pub remote_key_id: String,
    /// A2A context ID binding this session to a conversation.
    pub context_id: String,
    /// Negotiated cipher suite.
    pub cipher: CipherSuite,
    /// Current session key.
    session_key: SessionKey,
    /// ECDH shared secret (retained for key rotation).
    shared_secret: SharedSecret,
    /// Current rotation counter.
    pub rotation_counter: u64,
    /// Message counter (for AES-GCM nonce and rotation trigger).
    message_counter: u64,
    /// When this session key was derived.
    key_created_at: Instant,
    /// Rotation policy.
    rotation_policy: RotationPolicy,
    /// Nonce tracker for replay detection.
    nonce_tracker: NonceTracker,
}

impl Session {
    /// Create a new session from a local key pair and remote public key.
    pub fn new(
        local_keypair: &KeyPair,
        remote_public_key: &PublicKey,
        remote_key_id: String,
        context_id: String,
        cipher: CipherSuite,
    ) -> Result<Self> {
        let shared_secret = local_keypair.diffie_hellman(remote_public_key);
        let session_key = derive_session_key(
            &shared_secret,
            &local_keypair.key_id,
            &remote_key_id,
            &context_id,
        )?;

        Ok(Self {
            local_key_id: local_keypair.key_id.clone(),
            remote_key_id,
            context_id,
            cipher,
            session_key,
            shared_secret,
            rotation_counter: 0,
            message_counter: 0,
            key_created_at: Instant::now(),
            rotation_policy: RotationPolicy::default(),
            nonce_tracker: NonceTracker::default(),
        })
    }

    /// Set a custom rotation policy.
    pub fn with_rotation_policy(mut self, policy: RotationPolicy) -> Self {
        self.rotation_policy = policy;
        self
    }

    /// Encrypt plaintext, returning (ciphertext, nonce).
    /// Automatically rotates the key if the rotation policy triggers.
    pub fn encrypt(&mut self, plaintext: &[u8]) -> Result<EncryptedPayload> {
        if self.should_rotate() {
            self.rotate()?;
        }

        let nonce = generate_nonce(self.cipher, self.message_counter);
        let ciphertext = crate::cipher::encrypt(self.cipher, &self.session_key, &nonce, plaintext)?;
        self.message_counter += 1;

        Ok(EncryptedPayload {
            ciphertext,
            nonce,
            cipher: self.cipher,
            key_id: self.local_key_id.clone(),
            rotation_counter: self.rotation_counter,
        })
    }

    /// Decrypt an incoming encrypted payload.
    pub fn decrypt(&mut self, payload: &EncryptedPayload) -> Result<Vec<u8>> {
        // Check for nonce reuse (replay attack)
        self.nonce_tracker.check_and_record(&payload.nonce)?;

        // Handle key rotation: if the sender's rotation counter is ahead, re-derive
        let key = if payload.rotation_counter != self.rotation_counter {
            derive_rotated_session_key(
                &self.shared_secret,
                &self.local_key_id,
                &self.remote_key_id,
                &self.context_id,
                payload.rotation_counter,
            )?
        } else {
            // Use current session key — we can't move it, so re-derive
            if self.rotation_counter == 0 {
                derive_session_key(
                    &self.shared_secret,
                    &self.local_key_id,
                    &self.remote_key_id,
                    &self.context_id,
                )?
            } else {
                derive_rotated_session_key(
                    &self.shared_secret,
                    &self.local_key_id,
                    &self.remote_key_id,
                    &self.context_id,
                    self.rotation_counter,
                )?
            }
        };

        crate::cipher::decrypt(payload.cipher, &key, &payload.nonce, &payload.ciphertext)
    }

    /// Check if key rotation should be triggered.
    fn should_rotate(&self) -> bool {
        self.message_counter >= self.rotation_policy.max_messages
            || self.key_created_at.elapsed() >= self.rotation_policy.max_age
    }

    /// Perform key rotation.
    pub fn rotate(&mut self) -> Result<()> {
        self.rotation_counter += 1;
        self.session_key = derive_rotated_session_key(
            &self.shared_secret,
            &self.local_key_id,
            &self.remote_key_id,
            &self.context_id,
            self.rotation_counter,
        )?;
        self.message_counter = 0;
        self.key_created_at = Instant::now();
        Ok(())
    }

    /// Get the current message counter.
    pub fn message_count(&self) -> u64 {
        self.message_counter
    }

    /// Get the current rotation counter.
    pub fn rotation_count(&self) -> u64 {
        self.rotation_counter
    }
}

/// An encrypted payload with all metadata needed for decryption.
#[derive(Debug, Clone)]
pub struct EncryptedPayload {
    pub ciphertext: Vec<u8>,
    pub nonce: Vec<u8>,
    pub cipher: CipherSuite,
    pub key_id: String,
    pub rotation_counter: u64,
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::key::KeyPair;

    fn create_session_pair() -> (Session, Session) {
        let alice = KeyPair::generate();
        let bob = KeyPair::generate();

        let session_a = Session::new(
            &alice,
            &bob.public_key,
            bob.key_id.clone(),
            "test-ctx".into(),
            CipherSuite::XChaCha20Poly1305,
        )
        .unwrap();

        let session_b = Session::new(
            &bob,
            &alice.public_key,
            alice.key_id.clone(),
            "test-ctx".into(),
            CipherSuite::XChaCha20Poly1305,
        )
        .unwrap();

        (session_a, session_b)
    }

    #[test]
    fn test_session_encrypt_decrypt() {
        let (mut alice_session, mut bob_session) = create_session_pair();

        let plaintext = b"Hello from Alice to Bob!";
        let payload = alice_session.encrypt(plaintext).unwrap();
        let decrypted = bob_session.decrypt(&payload).unwrap();

        assert_eq!(decrypted, plaintext);
    }

    #[test]
    fn test_session_bidirectional() {
        let (mut alice_session, mut bob_session) = create_session_pair();

        // Alice -> Bob
        let p1 = alice_session.encrypt(b"hello bob").unwrap();
        assert_eq!(bob_session.decrypt(&p1).unwrap(), b"hello bob");

        // Bob -> Alice
        let p2 = bob_session.encrypt(b"hello alice").unwrap();
        assert_eq!(alice_session.decrypt(&p2).unwrap(), b"hello alice");
    }

    #[test]
    fn test_session_replay_detection() {
        let (mut alice_session, mut bob_session) = create_session_pair();

        let payload = alice_session.encrypt(b"message").unwrap();
        assert!(bob_session.decrypt(&payload).is_ok());
        // Same payload replayed should fail
        assert!(bob_session.decrypt(&payload).is_err());
    }

    #[test]
    fn test_session_key_rotation() {
        let (mut alice_session, mut bob_session) = create_session_pair();

        // Force rotation
        alice_session.rotate().unwrap();
        assert_eq!(alice_session.rotation_count(), 1);

        // Message with new key
        let payload = alice_session.encrypt(b"post-rotation").unwrap();
        assert_eq!(payload.rotation_counter, 1);

        // Bob should handle the new rotation counter
        let decrypted = bob_session.decrypt(&payload).unwrap();
        assert_eq!(decrypted, b"post-rotation");
    }

    #[test]
    fn test_session_auto_rotation() {
        let alice = KeyPair::generate();
        let bob = KeyPair::generate();

        let mut session = Session::new(
            &alice,
            &bob.public_key,
            bob.key_id.clone(),
            "test-ctx".into(),
            CipherSuite::XChaCha20Poly1305,
        )
        .unwrap()
        .with_rotation_policy(RotationPolicy {
            max_age: Duration::from_secs(3600),
            max_messages: 3, // Rotate every 3 messages
        });

        for _ in 0..3 {
            session.encrypt(b"msg").unwrap();
        }
        assert_eq!(session.rotation_count(), 0);

        // 4th message should trigger rotation
        session.encrypt(b"msg").unwrap();
        assert_eq!(session.rotation_count(), 1);
    }

    #[test]
    fn test_session_aes_gcm() {
        let alice = KeyPair::generate();
        let bob = KeyPair::generate();

        let mut session_a = Session::new(
            &alice,
            &bob.public_key,
            bob.key_id.clone(),
            "ctx".into(),
            CipherSuite::Aes256Gcm,
        )
        .unwrap();

        let mut session_b = Session::new(
            &bob,
            &alice.public_key,
            alice.key_id.clone(),
            "ctx".into(),
            CipherSuite::Aes256Gcm,
        )
        .unwrap();

        let payload = session_a.encrypt(b"AES test").unwrap();
        assert_eq!(session_b.decrypt(&payload).unwrap(), b"AES test");
    }
}
