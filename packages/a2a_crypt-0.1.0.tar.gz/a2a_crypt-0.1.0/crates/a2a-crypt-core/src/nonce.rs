use rand::RngCore;
use std::collections::HashSet;

use crate::cipher::CipherSuite;
use crate::error::{A2ACryptError, Result};

/// Generate a random nonce for XChaCha20-Poly1305 (24 bytes).
/// The 192-bit nonce space makes collision probability negligible.
pub fn generate_random_nonce_xchacha20() -> [u8; 24] {
    let mut nonce = [0u8; 24];
    rand::thread_rng().fill_bytes(&mut nonce);
    nonce
}

/// Generate a counter-based nonce for AES-256-GCM (12 bytes).
/// Format: `session_counter (8 bytes) || random (4 bytes)`
pub fn generate_counter_nonce_aes_gcm(counter: u64) -> [u8; 12] {
    let mut nonce = [0u8; 12];
    nonce[..8].copy_from_slice(&counter.to_be_bytes());
    rand::thread_rng().fill_bytes(&mut nonce[8..]);
    nonce
}

/// Generate a nonce for the given cipher suite.
pub fn generate_nonce(cipher: CipherSuite, counter: u64) -> Vec<u8> {
    match cipher {
        CipherSuite::XChaCha20Poly1305 => generate_random_nonce_xchacha20().to_vec(),
        CipherSuite::Aes256Gcm => generate_counter_nonce_aes_gcm(counter).to_vec(),
    }
}

/// Generate a streaming chunk nonce from a base nonce and chunk counter.
/// `chunk_nonce = base_nonce (first 20 bytes) || chunk_counter (4 bytes, big-endian)`
pub fn generate_stream_chunk_nonce(base_nonce: &[u8], chunk_counter: u32) -> [u8; 24] {
    let mut nonce = [0u8; 24];
    let copy_len = base_nonce.len().min(20);
    nonce[..copy_len].copy_from_slice(&base_nonce[..copy_len]);
    nonce[20..24].copy_from_slice(&chunk_counter.to_be_bytes());
    nonce
}

/// Tracks seen nonces to detect replay attacks.
pub struct NonceTracker {
    seen: HashSet<Vec<u8>>,
    /// Maximum number of tracked nonces before oldest are discarded.
    max_size: usize,
}

impl NonceTracker {
    pub fn new(max_size: usize) -> Self {
        Self {
            seen: HashSet::new(),
            max_size,
        }
    }

    /// Check if a nonce has been seen before. Returns Ok(()) if fresh, error if reused.
    pub fn check_and_record(&mut self, nonce: &[u8]) -> Result<()> {
        let nonce_vec = nonce.to_vec();
        if self.seen.contains(&nonce_vec) {
            return Err(A2ACryptError::NonceReuseDetected);
        }

        // Simple eviction: if at capacity, clear half the entries.
        // In production, a proper LRU or time-based eviction would be better.
        if self.seen.len() >= self.max_size {
            let to_keep: Vec<Vec<u8>> = self
                .seen
                .iter()
                .skip(self.max_size / 2)
                .cloned()
                .collect();
            self.seen = to_keep.into_iter().collect();
        }

        self.seen.insert(nonce_vec);
        Ok(())
    }

    /// Check if a nonce has been seen (without recording it).
    pub fn was_seen(&self, nonce: &[u8]) -> bool {
        self.seen.contains(nonce)
    }
}

impl Default for NonceTracker {
    fn default() -> Self {
        Self::new(10_000)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_xchacha20_nonce_uniqueness() {
        let n1 = generate_random_nonce_xchacha20();
        let n2 = generate_random_nonce_xchacha20();
        assert_ne!(n1, n2);
    }

    #[test]
    fn test_aes_gcm_counter_nonce() {
        let n1 = generate_counter_nonce_aes_gcm(0);
        let n2 = generate_counter_nonce_aes_gcm(1);
        // Counter portions should differ
        assert_ne!(n1[..8], n2[..8]);
    }

    #[test]
    fn test_stream_chunk_nonce() {
        let base = generate_random_nonce_xchacha20();
        let c0 = generate_stream_chunk_nonce(&base, 0);
        let c1 = generate_stream_chunk_nonce(&base, 1);

        // Same base prefix
        assert_eq!(c0[..20], c1[..20]);
        // Different counter suffix
        assert_ne!(c0[20..], c1[20..]);
    }

    #[test]
    fn test_nonce_tracker_detects_reuse() {
        let mut tracker = NonceTracker::new(100);
        let nonce = generate_random_nonce_xchacha20();

        assert!(tracker.check_and_record(&nonce).is_ok());
        assert!(tracker.check_and_record(&nonce).is_err());
    }

    #[test]
    fn test_nonce_tracker_allows_unique() {
        let mut tracker = NonceTracker::new(100);

        for _ in 0..50 {
            let nonce = generate_random_nonce_xchacha20();
            assert!(tracker.check_and_record(&nonce).is_ok());
        }
    }

    #[test]
    fn test_nonce_tracker_eviction() {
        let mut tracker = NonceTracker::new(10);

        for _ in 0..20 {
            let nonce = generate_random_nonce_xchacha20();
            assert!(tracker.check_and_record(&nonce).is_ok());
        }
        // Should still be under max after eviction
        assert!(tracker.seen.len() <= 10);
    }
}
