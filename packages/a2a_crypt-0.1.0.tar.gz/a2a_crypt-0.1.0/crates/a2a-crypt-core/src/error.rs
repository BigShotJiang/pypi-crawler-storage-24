use thiserror::Error;

/// JSON-RPC error codes defined by the A2A-Crypt extension spec.
pub const ERROR_ENCRYPTION_REQUIRED: i32 = -33001;
pub const ERROR_DECRYPTION_FAILED: i32 = -33002;
pub const ERROR_CIPHER_MISMATCH: i32 = -33003;
pub const ERROR_KEY_EXPIRED: i32 = -33004;
pub const ERROR_KEY_UNKNOWN: i32 = -33005;
pub const ERROR_NONCE_REUSE_DETECTED: i32 = -33006;

#[derive(Debug, Error)]
pub enum A2ACryptError {
    #[error("encryption required: remote requires encryption but message was plaintext")]
    EncryptionRequired,

    #[error("decryption failed: {0}")]
    DecryptionFailed(String),

    #[error("cipher mismatch: no mutually supported cipher suite")]
    CipherMismatch,

    #[error("key expired: sender's key has expired")]
    KeyExpired,

    #[error("key unknown: key ID '{0}' not recognized")]
    KeyUnknown(String),

    #[error("nonce reuse detected: potential replay attack")]
    NonceReuseDetected,

    #[error("key generation error: {0}")]
    KeyGeneration(String),

    #[error("serialization error: {0}")]
    Serialization(String),

    #[error("invalid key material: {0}")]
    InvalidKeyMaterial(String),

    #[error("IO error: {0}")]
    Io(#[from] std::io::Error),

    #[error("JSON error: {0}")]
    Json(#[from] serde_json::Error),

    #[error("base64 decode error: {0}")]
    Base64(#[from] base64::DecodeError),

    #[error("invalid message format: {0}")]
    InvalidMessage(String),
}

impl A2ACryptError {
    /// Returns the JSON-RPC error code for this error.
    pub fn error_code(&self) -> i32 {
        match self {
            Self::EncryptionRequired => ERROR_ENCRYPTION_REQUIRED,
            Self::DecryptionFailed(_) => ERROR_DECRYPTION_FAILED,
            Self::CipherMismatch => ERROR_CIPHER_MISMATCH,
            Self::KeyExpired => ERROR_KEY_EXPIRED,
            Self::KeyUnknown(_) => ERROR_KEY_UNKNOWN,
            Self::NonceReuseDetected => ERROR_NONCE_REUSE_DETECTED,
            _ => -32603, // Internal error for non-spec errors
        }
    }

    /// Formats this error as a JSON-RPC error response.
    pub fn to_jsonrpc_error(&self, id: &serde_json::Value) -> serde_json::Value {
        let mut data = serde_json::json!({
            "extension": "a2a-crypt",
        });

        // Add hints for recoverable errors
        match self {
            Self::KeyExpired | Self::KeyUnknown(_) => {
                data["hint"] = serde_json::json!("Key may have rotated. Fetch updated Agent Card.");
            }
            Self::CipherMismatch => {
                data["hint"] =
                    serde_json::json!("No common cipher suite. Check supported ciphers.");
            }
            _ => {}
        }

        serde_json::json!({
            "jsonrpc": "2.0",
            "id": id,
            "error": {
                "code": self.error_code(),
                "message": self.to_string(),
                "data": data,
            }
        })
    }
}

pub type Result<T> = std::result::Result<T, A2ACryptError>;
