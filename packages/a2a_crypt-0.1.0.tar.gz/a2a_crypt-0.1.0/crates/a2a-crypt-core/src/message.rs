use base64::{engine::general_purpose::URL_SAFE_NO_PAD, Engine};
use serde::{Deserialize, Serialize};
use serde_json::Value;

use crate::cipher::CipherSuite;
use crate::error::{A2ACryptError, Result};
use crate::session::Session;

/// MIME type used to identify encrypted A2A-Crypt parts.
pub const ENCRYPTED_MIME_TYPE: &str = "application/x-a2a-crypt";

/// Extension version.
pub const VERSION: &str = "1";

/// Metadata included in the encrypted part, per the wire format spec.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CryptMetadata {
    pub version: String,
    pub cipher: String,
    #[serde(rename = "keyId")]
    pub key_id: String,
    #[serde(rename = "senderKeyId")]
    pub sender_key_id: String,
    /// Included on first message so recipient can perform ECDH.
    #[serde(rename = "senderPublicKey", skip_serializing_if = "Option::is_none")]
    pub sender_public_key: Option<String>,
    pub nonce: String,
    #[serde(rename = "partCount")]
    pub part_count: usize,
    /// Rotation counter, included when > 0.
    #[serde(
        rename = "rotationCounter",
        skip_serializing_if = "Option::is_none"
    )]
    pub rotation_counter: Option<u64>,
}

/// Encrypt an A2A JSON-RPC message in place.
///
/// Finds `parts` arrays in message params and artifact params, encrypts them,
/// and replaces them with a single encrypted part per the spec.
pub fn encrypt_message(
    message: &mut Value,
    session: &mut Session,
    include_public_key: bool,
    sender_public_key_b64: &str,
) -> Result<()> {
    // Handle message.parts
    if let Some(parts) = extract_parts_mut(message, "message") {
        let encrypted_part = encrypt_parts(
            parts,
            session,
            include_public_key,
            sender_public_key_b64,
        )?;
        *parts = Value::Array(vec![encrypted_part]);
    }

    // Handle artifact.parts (in responses)
    if let Some(parts) = extract_parts_mut(message, "artifact") {
        let encrypted_part = encrypt_parts(
            parts,
            session,
            include_public_key,
            sender_public_key_b64,
        )?;
        *parts = Value::Array(vec![encrypted_part]);
    }

    Ok(())
}

/// Decrypt an A2A JSON-RPC message in place.
///
/// Finds encrypted parts and replaces them with the original plaintext parts.
pub fn decrypt_message(message: &mut Value, session: &mut Session) -> Result<()> {
    // Handle message.parts
    if let Some(parts) = extract_parts_mut(message, "message") {
        if is_encrypted_parts(parts) {
            let decrypted = decrypt_parts(parts, session)?;
            *parts = decrypted;
        }
    }

    // Handle artifact.parts
    if let Some(parts) = extract_parts_mut(message, "artifact") {
        if is_encrypted_parts(parts) {
            let decrypted = decrypt_parts(parts, session)?;
            *parts = decrypted;
        }
    }

    Ok(())
}

/// Check if a message contains encrypted parts.
pub fn is_encrypted(message: &Value) -> bool {
    if let Some(parts) = extract_parts(message, "message") {
        if is_encrypted_parts(parts) {
            return true;
        }
    }
    if let Some(parts) = extract_parts(message, "artifact") {
        if is_encrypted_parts(parts) {
            return true;
        }
    }
    false
}

/// Extract metadata from an encrypted message without decrypting.
pub fn inspect_metadata(message: &Value) -> Result<Option<CryptMetadata>> {
    let parts = extract_parts(message, "message")
        .or_else(|| extract_parts(message, "artifact"));

    let parts = match parts {
        Some(p) => p,
        None => return Ok(None),
    };

    let arr = match parts.as_array() {
        Some(a) => a,
        None => return Ok(None),
    };

    for part in arr {
        if let Some(metadata) = part.get("metadata").and_then(|m| m.get("a2a-crypt")) {
            let meta: CryptMetadata = serde_json::from_value(metadata.clone())?;
            return Ok(Some(meta));
        }
    }

    Ok(None)
}

// --- Internal helpers ---

fn encrypt_parts(
    parts: &Value,
    session: &mut Session,
    include_public_key: bool,
    sender_public_key_b64: &str,
) -> Result<Value> {
    let parts_array = parts
        .as_array()
        .ok_or_else(|| A2ACryptError::InvalidMessage("parts must be an array".into()))?;

    let part_count = parts_array.len();

    // Serialize the original parts into the wrapper object for forward compat
    let wrapper = serde_json::json!({ "parts": parts });
    let plaintext = serde_json::to_vec(&wrapper)?;

    // Encrypt
    let payload = session.encrypt(&plaintext)?;

    // Build the encrypted part per the wire format
    let metadata = CryptMetadata {
        version: VERSION.to_string(),
        cipher: payload.cipher.to_string(),
        key_id: session.remote_key_id.clone(),
        sender_key_id: session.local_key_id.clone(),
        sender_public_key: if include_public_key {
            Some(sender_public_key_b64.to_string())
        } else {
            None
        },
        nonce: URL_SAFE_NO_PAD.encode(&payload.nonce),
        part_count,
        rotation_counter: if payload.rotation_counter > 0 {
            Some(payload.rotation_counter)
        } else {
            None
        },
    };

    let encrypted_part = serde_json::json!({
        "metadata": {
            "mimeType": ENCRYPTED_MIME_TYPE,
            "a2a-crypt": metadata,
        },
        "data": {
            "mimeType": "application/octet-stream",
            "bytes": URL_SAFE_NO_PAD.encode(&payload.ciphertext),
        }
    });

    Ok(encrypted_part)
}

fn decrypt_parts(parts: &Value, session: &mut Session) -> Result<Value> {
    let arr = parts
        .as_array()
        .ok_or_else(|| A2ACryptError::InvalidMessage("parts must be an array".into()))?;

    // Find the encrypted part
    for part in arr {
        let metadata = match part.get("metadata").and_then(|m| m.get("a2a-crypt")) {
            Some(m) => m,
            None => continue,
        };

        let meta: CryptMetadata = serde_json::from_value(metadata.clone())?;

        let cipher = CipherSuite::from_str(&meta.cipher)?;
        let nonce = URL_SAFE_NO_PAD.decode(&meta.nonce)?;
        let ciphertext_b64 = part
            .get("data")
            .and_then(|d| d.get("bytes"))
            .and_then(|b| b.as_str())
            .ok_or_else(|| A2ACryptError::InvalidMessage("missing encrypted data bytes".into()))?;
        let ciphertext = URL_SAFE_NO_PAD.decode(ciphertext_b64)?;

        let payload = crate::session::EncryptedPayload {
            ciphertext,
            nonce,
            cipher,
            key_id: meta.sender_key_id,
            rotation_counter: meta.rotation_counter.unwrap_or(0),
        };

        let plaintext = session.decrypt(&payload)?;
        let wrapper: Value = serde_json::from_slice(&plaintext)?;

        return wrapper
            .get("parts")
            .cloned()
            .ok_or_else(|| A2ACryptError::DecryptionFailed("decrypted payload missing 'parts'".into()));
    }

    Err(A2ACryptError::InvalidMessage(
        "no encrypted part found".into(),
    ))
}

fn extract_parts_mut<'a>(message: &'a mut Value, container: &str) -> Option<&'a mut Value> {
    message
        .get_mut("params")
        .and_then(|p| p.get_mut(container))
        .and_then(|m| m.get_mut("parts"))
}

fn extract_parts<'a>(message: &'a Value, container: &str) -> Option<&'a Value> {
    message
        .get("params")
        .and_then(|p| p.get(container))
        .and_then(|m| m.get("parts"))
}

fn is_encrypted_parts(parts: &Value) -> bool {
    if let Some(arr) = parts.as_array() {
        arr.iter().any(|part| {
            part.get("metadata")
                .and_then(|m| m.get("mimeType"))
                .and_then(|t| t.as_str())
                == Some(ENCRYPTED_MIME_TYPE)
        })
    } else {
        false
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::cipher::CipherSuite;
    use crate::key::KeyPair;
    use crate::session::Session;

    fn sample_message() -> Value {
        serde_json::json!({
            "jsonrpc": "2.0",
            "method": "message/send",
            "id": "req-001",
            "params": {
                "message": {
                    "role": "user",
                    "messageId": "msg-abc-123",
                    "parts": [
                        { "text": "Find candidates matching this job description..." },
                        { "file": { "url": "https://example.com/doc.pdf", "mimeType": "application/pdf" } }
                    ]
                }
            }
        })
    }

    fn create_sessions() -> (Session, Session, KeyPair, KeyPair) {
        let alice = KeyPair::generate();
        let bob = KeyPair::generate();

        let session_a = Session::new(
            &alice,
            &bob.public_key,
            bob.key_id.clone(),
            "ctx-001".into(),
            CipherSuite::XChaCha20Poly1305,
        )
        .unwrap();

        let session_b = Session::new(
            &bob,
            &alice.public_key,
            alice.key_id.clone(),
            "ctx-001".into(),
            CipherSuite::XChaCha20Poly1305,
        )
        .unwrap();

        (session_a, session_b, alice, bob)
    }

    #[test]
    fn test_encrypt_decrypt_message() {
        let (mut session_a, mut session_b, alice, _bob) = create_sessions();
        let mut msg = sample_message();
        let original_parts = msg["params"]["message"]["parts"].clone();

        // Encrypt
        encrypt_message(&mut msg, &mut session_a, true, &alice.public_key_b64()).unwrap();

        // Verify encrypted structure
        let parts = msg["params"]["message"]["parts"].as_array().unwrap();
        assert_eq!(parts.len(), 1);
        assert_eq!(
            parts[0]["metadata"]["mimeType"].as_str().unwrap(),
            ENCRYPTED_MIME_TYPE
        );
        assert!(parts[0]["metadata"]["a2a-crypt"].is_object());
        assert!(parts[0]["data"]["bytes"].is_string());

        // Verify routing metadata is still plaintext
        assert_eq!(msg["method"].as_str().unwrap(), "message/send");
        assert_eq!(msg["params"]["message"]["role"].as_str().unwrap(), "user");

        // Decrypt
        decrypt_message(&mut msg, &mut session_b).unwrap();
        assert_eq!(msg["params"]["message"]["parts"], original_parts);
    }

    #[test]
    fn test_is_encrypted() {
        let (mut session_a, _, alice, _) = create_sessions();
        let mut msg = sample_message();

        assert!(!is_encrypted(&msg));
        encrypt_message(&mut msg, &mut session_a, true, &alice.public_key_b64()).unwrap();
        assert!(is_encrypted(&msg));
    }

    #[test]
    fn test_inspect_metadata() {
        let (mut session_a, _, alice, _) = create_sessions();
        let mut msg = sample_message();

        encrypt_message(&mut msg, &mut session_a, true, &alice.public_key_b64()).unwrap();

        let meta = inspect_metadata(&msg).unwrap().unwrap();
        assert_eq!(meta.version, "1");
        assert_eq!(meta.cipher, "xchacha20-poly1305");
        assert_eq!(meta.part_count, 2);
        assert!(meta.sender_public_key.is_some());
    }

    #[test]
    fn test_encrypt_without_public_key() {
        let (mut session_a, mut session_b, alice, _) = create_sessions();
        let mut msg = sample_message();

        encrypt_message(&mut msg, &mut session_a, false, &alice.public_key_b64()).unwrap();

        let meta = inspect_metadata(&msg).unwrap().unwrap();
        assert!(meta.sender_public_key.is_none());

        // Should still decrypt fine
        decrypt_message(&mut msg, &mut session_b).unwrap();
    }

    #[test]
    fn test_plaintext_message_not_modified_by_decrypt() {
        let (_, mut session_b, _, _) = create_sessions();
        let mut msg = sample_message();
        let original = msg.clone();

        // Decrypting a plaintext message should be a no-op (parts aren't encrypted)
        decrypt_message(&mut msg, &mut session_b).unwrap();
        assert_eq!(msg, original);
    }

    #[test]
    fn test_artifact_encryption() {
        let (mut session_a, mut session_b, alice, _) = create_sessions();

        let mut msg = serde_json::json!({
            "jsonrpc": "2.0",
            "id": "req-002",
            "result": {
                "id": "task-1",
                "status": { "state": "completed" }
            },
            "params": {
                "artifact": {
                    "artifactId": "art-001",
                    "parts": [
                        { "text": "Generated report content..." }
                    ]
                }
            }
        });

        let original_parts = msg["params"]["artifact"]["parts"].clone();
        encrypt_message(&mut msg, &mut session_a, true, &alice.public_key_b64()).unwrap();

        // Artifact metadata stays plaintext
        assert_eq!(
            msg["params"]["artifact"]["artifactId"].as_str().unwrap(),
            "art-001"
        );

        decrypt_message(&mut msg, &mut session_b).unwrap();
        assert_eq!(msg["params"]["artifact"]["parts"], original_parts);
    }
}
