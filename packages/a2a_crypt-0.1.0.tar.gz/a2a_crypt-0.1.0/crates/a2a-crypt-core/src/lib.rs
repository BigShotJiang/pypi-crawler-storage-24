//! A2A-Crypt Core — End-to-end payload encryption for the A2A protocol.
//!
//! This crate provides the cryptographic primitives and message handling for
//! encrypting A2A (Agent-to-Agent) protocol message content beyond TLS.
//!
//! # Architecture
//!
//! - **key**: X25519 key pair generation, ECDH shared secret derivation, key store
//! - **kdf**: HKDF-SHA256 session key derivation and rotation
//! - **cipher**: XChaCha20-Poly1305 and AES-256-GCM AEAD encryption
//! - **nonce**: Nonce generation (random, counter, streaming) and replay detection
//! - **session**: Session lifecycle, automatic key rotation
//! - **message**: A2A JSON-RPC message encryption/decryption
//! - **agent_card**: Agent Card extension parsing and building
//! - **error**: Error types and JSON-RPC error codes

pub mod agent_card;
pub mod cipher;
pub mod error;
pub mod kdf;
pub mod key;
pub mod message;
pub mod nonce;
pub mod session;

// Re-export key types for convenience
pub use cipher::CipherSuite;
pub use error::{A2ACryptError, Result};
pub use key::{KeyPair, KeyStore};
pub use message::{decrypt_message, encrypt_message, inspect_metadata, is_encrypted};
pub use session::{EncryptedPayload, RotationPolicy, Session};
