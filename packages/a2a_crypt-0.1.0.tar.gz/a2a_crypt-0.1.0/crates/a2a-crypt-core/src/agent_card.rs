use serde::{Deserialize, Serialize};

use crate::cipher::CipherSuite;
use crate::error::{A2ACryptError, Result};

/// A2A-Crypt extension configuration as embedded in an Agent Card.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct A2ACryptExtension {
    /// Agent's X25519 public key (base64url-encoded).
    #[serde(rename = "publicKey")]
    pub public_key: String,
    /// Unique identifier for this key.
    #[serde(rename = "keyId")]
    pub key_id: String,
    /// Supported cipher suites in preference order.
    pub ciphers: Vec<String>,
    /// When this key should no longer be used (ISO 8601).
    #[serde(rename = "keyExpiry", skip_serializing_if = "Option::is_none")]
    pub key_expiry: Option<String>,
    /// Endpoint for explicit key exchange.
    #[serde(
        rename = "keyExchangeEndpoint",
        skip_serializing_if = "Option::is_none"
    )]
    pub key_exchange_endpoint: Option<String>,
}

/// An extension entry in the Agent Card.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AgentCardExtension {
    pub uri: String,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub description: Option<String>,
    #[serde(default)]
    pub required: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub config: Option<serde_json::Value>,
}

/// The extension URI for A2A-Crypt v1.
pub const EXTENSION_URI: &str = "urn:a2a-crypt:v1";

/// Extract the A2A-Crypt extension config from an Agent Card JSON.
pub fn extract_crypt_extension(agent_card: &serde_json::Value) -> Result<Option<A2ACryptExtension>> {
    let extensions = match agent_card.get("extensions").and_then(|e| e.as_array()) {
        Some(exts) => exts,
        None => return Ok(None),
    };

    for ext in extensions {
        let uri = ext.get("uri").and_then(|u| u.as_str()).unwrap_or("");
        if uri == EXTENSION_URI {
            let config = ext
                .get("config")
                .ok_or_else(|| {
                    A2ACryptError::InvalidMessage("a2a-crypt extension missing config".into())
                })?;
            let crypt_ext: A2ACryptExtension = serde_json::from_value(config.clone())?;
            return Ok(Some(crypt_ext));
        }
    }

    Ok(None)
}

/// Parse the cipher list from the extension config into CipherSuite values.
pub fn parse_ciphers(ext: &A2ACryptExtension) -> Result<Vec<CipherSuite>> {
    let mut ciphers = Vec::new();
    for name in &ext.ciphers {
        match CipherSuite::from_str(name) {
            Ok(c) => ciphers.push(c),
            Err(_) => {
                // Skip unknown ciphers — the remote might support ciphers we don't
                continue;
            }
        }
    }
    if ciphers.is_empty() {
        return Err(A2ACryptError::CipherMismatch);
    }
    Ok(ciphers)
}

/// Build the A2A-Crypt extension block for inclusion in an Agent Card.
pub fn build_extension(
    public_key_b64: &str,
    key_id: &str,
    ciphers: &[CipherSuite],
    key_expiry: Option<&str>,
) -> serde_json::Value {
    let cipher_names: Vec<&str> = ciphers.iter().map(|c| c.as_str()).collect();

    let mut config = serde_json::json!({
        "publicKey": public_key_b64,
        "keyId": key_id,
        "ciphers": cipher_names,
    });

    if let Some(expiry) = key_expiry {
        config["keyExpiry"] = serde_json::json!(expiry);
    }

    serde_json::json!({
        "uri": EXTENSION_URI,
        "description": "End-to-end payload encryption",
        "required": false,
        "config": config,
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    fn sample_agent_card() -> serde_json::Value {
        serde_json::json!({
            "name": "Test Agent",
            "url": "https://agent.example.com",
            "extensions": [
                {
                    "uri": "urn:a2a-crypt:v1",
                    "description": "End-to-end payload encryption",
                    "required": false,
                    "config": {
                        "publicKey": "dGVzdC1wdWJsaWMta2V5LWJhc2U2NHVybA",
                        "keyId": "agent-key-001",
                        "ciphers": ["xchacha20-poly1305", "aes-256-gcm"],
                        "keyExpiry": "2026-06-08T00:00:00Z"
                    }
                }
            ]
        })
    }

    #[test]
    fn test_extract_extension() {
        let card = sample_agent_card();
        let ext = extract_crypt_extension(&card).unwrap().unwrap();

        assert_eq!(ext.key_id, "agent-key-001");
        assert_eq!(ext.ciphers.len(), 2);
        assert_eq!(ext.key_expiry.as_deref(), Some("2026-06-08T00:00:00Z"));
    }

    #[test]
    fn test_no_extension() {
        let card = serde_json::json!({
            "name": "Plain Agent",
            "extensions": []
        });
        assert!(extract_crypt_extension(&card).unwrap().is_none());
    }

    #[test]
    fn test_no_extensions_field() {
        let card = serde_json::json!({ "name": "Minimal Agent" });
        assert!(extract_crypt_extension(&card).unwrap().is_none());
    }

    #[test]
    fn test_parse_ciphers() {
        let ext = A2ACryptExtension {
            public_key: "key".into(),
            key_id: "id".into(),
            ciphers: vec![
                "xchacha20-poly1305".into(),
                "aes-256-gcm".into(),
                "unknown-cipher".into(),
            ],
            key_expiry: None,
            key_exchange_endpoint: None,
        };

        let ciphers = parse_ciphers(&ext).unwrap();
        assert_eq!(ciphers.len(), 2);
        assert_eq!(ciphers[0], CipherSuite::XChaCha20Poly1305);
        assert_eq!(ciphers[1], CipherSuite::Aes256Gcm);
    }

    #[test]
    fn test_build_extension() {
        let ext = build_extension(
            "base64key",
            "key-001",
            &[CipherSuite::XChaCha20Poly1305, CipherSuite::Aes256Gcm],
            Some("2026-12-31T00:00:00Z"),
        );

        assert_eq!(ext["uri"], "urn:a2a-crypt:v1");
        assert_eq!(ext["config"]["publicKey"], "base64key");
        assert_eq!(ext["config"]["keyExpiry"], "2026-12-31T00:00:00Z");
    }
}
