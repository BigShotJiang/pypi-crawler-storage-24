"""Tests for a2a_crypt Python bindings."""

import json
import os
import tempfile

import a2a_crypt


def test_keypair_generate():
    kp = a2a_crypt.KeyPair.generate()
    assert isinstance(kp.key_id, str)
    assert len(kp.key_id) == 16  # 8 bytes hex
    assert isinstance(kp.public_key, str)
    assert len(kp.public_key_bytes) == 32


def test_keypair_from_secret_bytes():
    kp1 = a2a_crypt.KeyPair.generate()
    kp2 = a2a_crypt.KeyPair.from_secret_bytes(kp1.secret_bytes)
    assert kp1.key_id == kp2.key_id
    assert kp1.public_key == kp2.public_key


def test_keystore_in_memory():
    store = a2a_crypt.KeyStore()
    kp = a2a_crypt.KeyPair.generate()
    store.add_key(kp, True)
    assert store.active_key_id is not None
    assert len(store.key_ids()) == 1


def test_keystore_file():
    with tempfile.TemporaryDirectory() as tmpdir:
        path = os.path.join(tmpdir, "keys.json")
        store = a2a_crypt.KeyStore.from_file(path)
        kid = store.active_key_id
        pub_key = store.active_key().public_key

        # Reload
        store2 = a2a_crypt.KeyStore.from_file(path)
        assert store2.active_key_id == kid
        assert store2.active_key().public_key == pub_key


def test_session_encrypt_decrypt():
    alice = a2a_crypt.KeyPair.generate()
    bob = a2a_crypt.KeyPair.generate()

    session_a = a2a_crypt.Session(
        local_keypair=alice,
        remote_public_key=bob.public_key,
        remote_key_id=bob.key_id,
        context_id="test-ctx",
    )
    session_b = a2a_crypt.Session(
        local_keypair=bob,
        remote_public_key=alice.public_key,
        remote_key_id=alice.key_id,
        context_id="test-ctx",
    )

    message = {
        "jsonrpc": "2.0",
        "method": "message/send",
        "id": "req-001",
        "params": {
            "message": {
                "role": "user",
                "messageId": "msg-001",
                "parts": [
                    {"text": "Hello Bob, this is secret!"},
                    {"file": {"url": "https://example.com/doc.pdf", "mimeType": "application/pdf"}},
                ],
            }
        },
    }

    # Encrypt
    encrypted = session_a.encrypt_message(message, include_public_key=True)

    # Verify structure
    assert encrypted["method"] == "message/send"
    assert encrypted["params"]["message"]["role"] == "user"
    parts = encrypted["params"]["message"]["parts"]
    assert len(parts) == 1
    assert parts[0]["metadata"]["mimeType"] == "application/x-a2a-crypt"

    # Check is_encrypted
    assert a2a_crypt.is_encrypted(encrypted) is True
    assert a2a_crypt.is_encrypted(message) is False

    # Inspect metadata
    meta = a2a_crypt.inspect_metadata(encrypted)
    assert meta is not None
    assert meta["version"] == "1"
    assert meta["cipher"] == "xchacha20-poly1305"
    assert meta["part_count"] == 2
    assert meta["sender_public_key"] is not None

    # Decrypt
    decrypted = session_b.decrypt_message(encrypted)
    assert decrypted["params"]["message"]["parts"] == message["params"]["message"]["parts"]


def test_session_bidirectional():
    alice = a2a_crypt.KeyPair.generate()
    bob = a2a_crypt.KeyPair.generate()

    session_a = a2a_crypt.Session(alice, bob.public_key, bob.key_id, "ctx")
    session_b = a2a_crypt.Session(bob, alice.public_key, alice.key_id, "ctx")

    msg1 = {
        "jsonrpc": "2.0", "method": "message/send", "id": "1",
        "params": {"message": {"role": "user", "messageId": "m1", "parts": [{"text": "hello bob"}]}},
    }
    msg2 = {
        "jsonrpc": "2.0", "method": "message/send", "id": "2",
        "params": {"message": {"role": "assistant", "messageId": "m2", "parts": [{"text": "hello alice"}]}},
    }

    # A -> B
    enc1 = session_a.encrypt_message(msg1)
    dec1 = session_b.decrypt_message(enc1)
    assert dec1["params"]["message"]["parts"][0]["text"] == "hello bob"

    # B -> A
    enc2 = session_b.encrypt_message(msg2)
    dec2 = session_a.decrypt_message(enc2)
    assert dec2["params"]["message"]["parts"][0]["text"] == "hello alice"


def test_session_aes_gcm():
    alice = a2a_crypt.KeyPair.generate()
    bob = a2a_crypt.KeyPair.generate()

    session_a = a2a_crypt.Session(alice, bob.public_key, bob.key_id, "ctx", cipher="aes-256-gcm")
    session_b = a2a_crypt.Session(bob, alice.public_key, alice.key_id, "ctx", cipher="aes-256-gcm")

    msg = {
        "jsonrpc": "2.0", "method": "message/send", "id": "1",
        "params": {"message": {"role": "user", "messageId": "m1", "parts": [{"text": "aes test"}]}},
    }

    enc = session_a.encrypt_message(msg)
    meta = a2a_crypt.inspect_metadata(enc)
    assert meta["cipher"] == "aes-256-gcm"

    dec = session_b.decrypt_message(enc)
    assert dec["params"]["message"]["parts"][0]["text"] == "aes test"


def test_session_key_rotation():
    alice = a2a_crypt.KeyPair.generate()
    bob = a2a_crypt.KeyPair.generate()

    session_a = a2a_crypt.Session(alice, bob.public_key, bob.key_id, "ctx")
    session_b = a2a_crypt.Session(bob, alice.public_key, alice.key_id, "ctx")

    assert session_a.rotation_count == 0
    session_a.rotate()
    assert session_a.rotation_count == 1

    msg = {
        "jsonrpc": "2.0", "method": "message/send", "id": "1",
        "params": {"message": {"role": "user", "messageId": "m1", "parts": [{"text": "post-rotation"}]}},
    }

    enc = session_a.encrypt_message(msg)
    dec = session_b.decrypt_message(enc)
    assert dec["params"]["message"]["parts"][0]["text"] == "post-rotation"


def test_session_replay_detection():
    alice = a2a_crypt.KeyPair.generate()
    bob = a2a_crypt.KeyPair.generate()

    session_a = a2a_crypt.Session(alice, bob.public_key, bob.key_id, "ctx")
    session_b = a2a_crypt.Session(bob, alice.public_key, alice.key_id, "ctx")

    msg = {
        "jsonrpc": "2.0", "method": "message/send", "id": "1",
        "params": {"message": {"role": "user", "messageId": "m1", "parts": [{"text": "once"}]}},
    }

    enc = session_a.encrypt_message(msg)
    session_b.decrypt_message(enc)  # First time OK

    try:
        session_b.decrypt_message(enc)  # Replay should fail
        assert False, "Should have raised an error"
    except RuntimeError as e:
        assert "nonce reuse" in str(e).lower()


def test_session_properties():
    alice = a2a_crypt.KeyPair.generate()
    bob = a2a_crypt.KeyPair.generate()

    session = a2a_crypt.Session(alice, bob.public_key, bob.key_id, "ctx")

    assert session.local_key_id == alice.key_id
    assert session.remote_key_id == bob.key_id
    assert session.cipher == "xchacha20-poly1305"
    assert session.message_count == 0
    assert session.rotation_count == 0


def test_json_string_input():
    """Test that Session accepts JSON strings as input too."""
    alice = a2a_crypt.KeyPair.generate()
    bob = a2a_crypt.KeyPair.generate()

    session_a = a2a_crypt.Session(alice, bob.public_key, bob.key_id, "ctx")
    session_b = a2a_crypt.Session(bob, alice.public_key, alice.key_id, "ctx")

    msg_str = json.dumps({
        "jsonrpc": "2.0", "method": "message/send", "id": "1",
        "params": {"message": {"role": "user", "messageId": "m1", "parts": [{"text": "as string"}]}},
    })

    enc = session_a.encrypt_message(msg_str)
    dec = session_b.decrypt_message(enc)
    assert dec["params"]["message"]["parts"][0]["text"] == "as string"


def test_negotiate_cipher():
    result = a2a_crypt.negotiate_cipher(
        ["xchacha20-poly1305", "aes-256-gcm"],
        ["aes-256-gcm", "xchacha20-poly1305"],
    )
    assert result == "xchacha20-poly1305"  # Client preference wins

    try:
        a2a_crypt.negotiate_cipher(["xchacha20-poly1305"], ["aes-256-gcm"])
        assert False, "Should have raised"
    except RuntimeError:
        pass


def test_parse_agent_card():
    card = {
        "name": "Test Agent",
        "extensions": [
            {
                "uri": "urn:a2a-crypt:v1",
                "required": False,
                "config": {
                    "publicKey": "dGVzdC1wdWJsaWMta2V5LWJhc2U2NHVybA",
                    "keyId": "key-001",
                    "ciphers": ["xchacha20-poly1305", "aes-256-gcm"],
                    "keyExpiry": "2026-06-08T00:00:00Z",
                },
            }
        ],
    }
    ext = a2a_crypt.parse_agent_card(card)
    assert ext is not None
    assert ext["key_id"] == "key-001"
    assert ext["ciphers"] == ["xchacha20-poly1305", "aes-256-gcm"]
    assert ext["key_expiry"] == "2026-06-08T00:00:00Z"


def test_parse_agent_card_no_extension():
    card = {"name": "Plain Agent", "extensions": []}
    assert a2a_crypt.parse_agent_card(card) is None


def test_build_agent_card_extension():
    kp = a2a_crypt.KeyPair.generate()
    ext = a2a_crypt.build_agent_card_extension(
        public_key=kp.public_key,
        key_id=kp.key_id,
        key_expiry="2026-12-31T00:00:00Z",
    )
    assert ext["uri"] == "urn:a2a-crypt:v1"
    assert ext["config"]["publicKey"] == kp.public_key
    assert ext["config"]["keyId"] == kp.key_id
    assert ext["config"]["keyExpiry"] == "2026-12-31T00:00:00Z"


def test_artifact_encryption():
    alice = a2a_crypt.KeyPair.generate()
    bob = a2a_crypt.KeyPair.generate()

    session_a = a2a_crypt.Session(alice, bob.public_key, bob.key_id, "ctx")
    session_b = a2a_crypt.Session(bob, alice.public_key, alice.key_id, "ctx")

    msg = {
        "jsonrpc": "2.0",
        "id": "2",
        "result": {"id": "task-1", "status": {"state": "completed"}},
        "params": {
            "artifact": {
                "artifactId": "art-001",
                "parts": [{"text": "Generated report..."}],
            }
        },
    }

    enc = session_a.encrypt_message(msg)
    assert enc["params"]["artifact"]["artifactId"] == "art-001"

    dec = session_b.decrypt_message(enc)
    assert dec["params"]["artifact"]["parts"][0]["text"] == "Generated report..."
