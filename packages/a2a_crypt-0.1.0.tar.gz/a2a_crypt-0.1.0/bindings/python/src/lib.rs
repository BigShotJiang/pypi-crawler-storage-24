use pyo3::exceptions::{PyRuntimeError, PyValueError};
use pyo3::prelude::*;
use pyo3::types::PyDict;
use std::path::PathBuf;
use std::sync::Mutex;

use a2a_crypt_core::cipher::CipherSuite;
use a2a_crypt_core::key as core_key;
use a2a_crypt_core::session as core_session;

/// Convert A2ACryptError to a Python exception.
fn to_py_err(e: a2a_crypt_core::A2ACryptError) -> PyErr {
    PyRuntimeError::new_err(e.to_string())
}

/// An X25519 key pair for ECDH key exchange.
#[pyclass(name = "KeyPair")]
struct PyKeyPair {
    inner: core_key::KeyPair,
}

#[pymethods]
impl PyKeyPair {
    /// Generate a new random X25519 key pair.
    #[staticmethod]
    fn generate() -> Self {
        Self {
            inner: core_key::KeyPair::generate(),
        }
    }

    /// Create a key pair from raw secret key bytes.
    #[staticmethod]
    fn from_secret_bytes(secret_bytes: &[u8]) -> PyResult<Self> {
        let kp = core_key::KeyPair::from_secret_bytes(secret_bytes).map_err(to_py_err)?;
        Ok(Self { inner: kp })
    }

    /// The key ID (hex string derived from the public key).
    #[getter]
    fn key_id(&self) -> String {
        self.inner.key_id.clone()
    }

    /// The public key as a base64url-encoded string.
    #[getter]
    fn public_key(&self) -> String {
        self.inner.public_key_b64()
    }

    /// The public key as raw bytes.
    #[getter]
    fn public_key_bytes(&self) -> Vec<u8> {
        self.inner.public_key.as_bytes().to_vec()
    }

    /// The secret key as raw bytes. Handle with care.
    #[getter]
    fn secret_bytes(&self) -> Vec<u8> {
        self.inner.secret_bytes().to_vec()
    }
}

/// Persistent key store backed by a JSON file.
#[pyclass(name = "KeyStore")]
struct PyKeyStore {
    inner: Mutex<core_key::KeyStore>,
}

#[pymethods]
impl PyKeyStore {
    /// Create an empty in-memory key store.
    #[new]
    fn new() -> Self {
        Self {
            inner: Mutex::new(core_key::KeyStore::new()),
        }
    }

    /// Load a key store from a JSON file. Creates the file and a key if it doesn't exist.
    #[staticmethod]
    fn from_file(path: &str) -> PyResult<Self> {
        let store = core_key::KeyStore::from_file(PathBuf::from(path)).map_err(to_py_err)?;
        Ok(Self {
            inner: Mutex::new(store),
        })
    }

    /// Add a key pair. If set_active is true, it becomes the active key.
    fn add_key(&self, keypair: &PyKeyPair, set_active: bool) -> PyResult<()> {
        let kp = core_key::KeyPair::from_secret_bytes(&keypair.inner.secret_bytes())
            .map_err(to_py_err)?;
        self.inner
            .lock()
            .map_err(|e| PyRuntimeError::new_err(e.to_string()))?
            .add_key(kp, set_active);
        Ok(())
    }

    /// Get the active key pair, or None.
    fn active_key(&self) -> PyResult<Option<PyKeyPair>> {
        let store = self
            .inner
            .lock()
            .map_err(|e| PyRuntimeError::new_err(e.to_string()))?;
        match store.active_key() {
            Some(kp) => {
                let new_kp =
                    core_key::KeyPair::from_secret_bytes(&kp.secret_bytes()).map_err(to_py_err)?;
                Ok(Some(PyKeyPair { inner: new_kp }))
            }
            None => Ok(None),
        }
    }

    /// Get the active key ID, or None.
    #[getter]
    fn active_key_id(&self) -> PyResult<Option<String>> {
        let store = self
            .inner
            .lock()
            .map_err(|e| PyRuntimeError::new_err(e.to_string()))?;
        Ok(store.active_key_id().map(|s| s.to_string()))
    }

    /// List all key IDs in the store.
    fn key_ids(&self) -> PyResult<Vec<String>> {
        let store = self
            .inner
            .lock()
            .map_err(|e| PyRuntimeError::new_err(e.to_string()))?;
        Ok(store.key_ids().into_iter().map(|s| s.to_string()).collect())
    }

    /// Save the key store to disk (if file-backed).
    fn save(&self) -> PyResult<()> {
        let store = self
            .inner
            .lock()
            .map_err(|e| PyRuntimeError::new_err(e.to_string()))?;
        store.save().map_err(to_py_err)
    }
}

/// An active encryption session between two agents.
#[pyclass(name = "Session")]
struct PySession {
    inner: Mutex<core_session::Session>,
    local_public_key_b64: String,
}

#[pymethods]
impl PySession {
    /// Create a new session.
    ///
    /// Args:
    ///     local_keypair: Your KeyPair
    ///     remote_public_key: Remote agent's public key (base64url string)
    ///     remote_key_id: Remote agent's key ID
    ///     context_id: A2A context ID
    ///     cipher: Cipher suite name (default: "xchacha20-poly1305")
    #[new]
    #[pyo3(signature = (local_keypair, remote_public_key, remote_key_id, context_id, cipher="xchacha20-poly1305"))]
    fn new(
        local_keypair: &PyKeyPair,
        remote_public_key: &str,
        remote_key_id: &str,
        context_id: &str,
        cipher: &str,
    ) -> PyResult<Self> {
        let remote_pub = core_key::parse_public_key(remote_public_key).map_err(to_py_err)?;
        let cipher_suite = CipherSuite::from_str(cipher).map_err(to_py_err)?;

        let session = core_session::Session::new(
            &local_keypair.inner,
            &remote_pub,
            remote_key_id.to_string(),
            context_id.to_string(),
            cipher_suite,
        )
        .map_err(to_py_err)?;

        Ok(Self {
            local_public_key_b64: local_keypair.inner.public_key_b64(),
            inner: Mutex::new(session),
        })
    }

    /// Encrypt an A2A JSON-RPC message dict. Returns the modified message dict.
    ///
    /// Args:
    ///     message: A2A JSON-RPC message as a Python dict or JSON string
    ///     include_public_key: Include sender's public key (default True, for first contact)
    #[pyo3(signature = (message, include_public_key=true))]
    fn encrypt_message(
        &self,
        py: Python<'_>,
        message: &Bound<'_, PyAny>,
        include_public_key: bool,
    ) -> PyResult<PyObject> {
        let mut json_val = py_to_json(py, message)?;
        let mut session = self
            .inner
            .lock()
            .map_err(|e| PyRuntimeError::new_err(e.to_string()))?;

        a2a_crypt_core::encrypt_message(
            &mut json_val,
            &mut session,
            include_public_key,
            &self.local_public_key_b64,
        )
        .map_err(to_py_err)?;

        json_to_py(py, &json_val)
    }

    /// Decrypt an A2A JSON-RPC message. Returns the modified message dict.
    fn decrypt_message(
        &self,
        py: Python<'_>,
        message: &Bound<'_, PyAny>,
    ) -> PyResult<PyObject> {
        let mut json_val = py_to_json(py, message)?;
        let mut session = self
            .inner
            .lock()
            .map_err(|e| PyRuntimeError::new_err(e.to_string()))?;

        a2a_crypt_core::decrypt_message(&mut json_val, &mut session).map_err(to_py_err)?;

        json_to_py(py, &json_val)
    }

    /// Manually trigger key rotation.
    fn rotate(&self) -> PyResult<()> {
        let mut session = self
            .inner
            .lock()
            .map_err(|e| PyRuntimeError::new_err(e.to_string()))?;
        session.rotate().map_err(to_py_err)
    }

    /// Get the current message count.
    #[getter]
    fn message_count(&self) -> PyResult<u64> {
        let session = self
            .inner
            .lock()
            .map_err(|e| PyRuntimeError::new_err(e.to_string()))?;
        Ok(session.message_count())
    }

    /// Get the current rotation counter.
    #[getter]
    fn rotation_count(&self) -> PyResult<u64> {
        let session = self
            .inner
            .lock()
            .map_err(|e| PyRuntimeError::new_err(e.to_string()))?;
        Ok(session.rotation_count())
    }

    /// The local key ID.
    #[getter]
    fn local_key_id(&self) -> PyResult<String> {
        let session = self
            .inner
            .lock()
            .map_err(|e| PyRuntimeError::new_err(e.to_string()))?;
        Ok(session.local_key_id.clone())
    }

    /// The remote key ID.
    #[getter]
    fn remote_key_id(&self) -> PyResult<String> {
        let session = self
            .inner
            .lock()
            .map_err(|e| PyRuntimeError::new_err(e.to_string()))?;
        Ok(session.remote_key_id.clone())
    }

    /// The cipher suite in use.
    #[getter]
    fn cipher(&self) -> PyResult<String> {
        let session = self
            .inner
            .lock()
            .map_err(|e| PyRuntimeError::new_err(e.to_string()))?;
        Ok(session.cipher.to_string())
    }
}

/// Check if an A2A message is encrypted.
#[pyfunction]
fn is_encrypted(py: Python<'_>, message: &Bound<'_, PyAny>) -> PyResult<bool> {
    let json_val = py_to_json(py, message)?;
    Ok(a2a_crypt_core::is_encrypted(&json_val))
}

/// Inspect encrypted message metadata without decrypting.
/// Returns a dict with metadata fields, or None if not encrypted.
#[pyfunction]
fn inspect_metadata(py: Python<'_>, message: &Bound<'_, PyAny>) -> PyResult<Option<PyObject>> {
    let json_val = py_to_json(py, message)?;
    match a2a_crypt_core::inspect_metadata(&json_val).map_err(to_py_err)? {
        Some(meta) => {
            let dict = PyDict::new(py);
            dict.set_item("version", &meta.version)?;
            dict.set_item("cipher", &meta.cipher)?;
            dict.set_item("key_id", &meta.key_id)?;
            dict.set_item("sender_key_id", &meta.sender_key_id)?;
            dict.set_item("sender_public_key", meta.sender_public_key.as_deref())?;
            dict.set_item("nonce", &meta.nonce)?;
            dict.set_item("part_count", meta.part_count)?;
            dict.set_item("rotation_counter", meta.rotation_counter)?;
            Ok(Some(dict.into_any().unbind()))
        }
        None => Ok(None),
    }
}

/// Extract the A2A-Crypt extension config from an Agent Card dict.
/// Returns a dict with fields: public_key, key_id, ciphers, key_expiry, or None.
#[pyfunction]
fn parse_agent_card(py: Python<'_>, agent_card: &Bound<'_, PyAny>) -> PyResult<Option<PyObject>> {
    let json_val = py_to_json(py, agent_card)?;
    match a2a_crypt_core::agent_card::extract_crypt_extension(&json_val).map_err(to_py_err)? {
        Some(ext) => {
            let dict = PyDict::new(py);
            dict.set_item("public_key", &ext.public_key)?;
            dict.set_item("key_id", &ext.key_id)?;
            dict.set_item("ciphers", &ext.ciphers)?;
            dict.set_item("key_expiry", ext.key_expiry.as_deref())?;
            dict.set_item(
                "key_exchange_endpoint",
                ext.key_exchange_endpoint.as_deref(),
            )?;
            Ok(Some(dict.into_any().unbind()))
        }
        None => Ok(None),
    }
}

/// Negotiate a cipher suite between client and remote preferences.
/// Returns the selected cipher name, or raises an error if no match.
#[pyfunction]
fn negotiate_cipher(client_ciphers: Vec<String>, remote_ciphers: Vec<String>) -> PyResult<String> {
    let client: Vec<CipherSuite> = client_ciphers
        .iter()
        .filter_map(|s| CipherSuite::from_str(s).ok())
        .collect();
    let remote: Vec<CipherSuite> = remote_ciphers
        .iter()
        .filter_map(|s| CipherSuite::from_str(s).ok())
        .collect();

    let result = a2a_crypt_core::cipher::negotiate_cipher(&client, &remote).map_err(to_py_err)?;
    Ok(result.to_string())
}

/// Build an Agent Card extension block as a dict.
#[pyfunction]
#[pyo3(signature = (public_key, key_id, ciphers=None, key_expiry=None))]
fn build_agent_card_extension(
    py: Python<'_>,
    public_key: &str,
    key_id: &str,
    ciphers: Option<Vec<String>>,
    key_expiry: Option<&str>,
) -> PyResult<PyObject> {
    let cipher_list = ciphers.unwrap_or_else(|| {
        vec![
            "xchacha20-poly1305".to_string(),
            "aes-256-gcm".to_string(),
        ]
    });
    let suites: Vec<CipherSuite> = cipher_list
        .iter()
        .map(|s| CipherSuite::from_str(s))
        .collect::<Result<_, _>>()
        .map_err(to_py_err)?;

    let ext =
        a2a_crypt_core::agent_card::build_extension(public_key, key_id, &suites, key_expiry);

    json_to_py(py, &ext)
}

// --- Conversion helpers ---

/// Convert a Python object (dict or str) to serde_json::Value.
fn py_to_json(py: Python<'_>, obj: &Bound<'_, PyAny>) -> PyResult<serde_json::Value> {
    // If it's a string, parse as JSON
    if let Ok(s) = obj.extract::<String>() {
        return serde_json::from_str(&s)
            .map_err(|e| PyValueError::new_err(format!("invalid JSON string: {e}")));
    }

    // Otherwise, convert Python dict/list to JSON via json module
    let json_mod = py.import("json")?;
    let json_str: String = json_mod
        .call_method1("dumps", (obj,))?
        .extract()?;
    serde_json::from_str(&json_str)
        .map_err(|e| PyValueError::new_err(format!("failed to convert to JSON: {e}")))
}

/// Convert serde_json::Value to a Python object (dict/list/str/etc).
fn json_to_py(py: Python<'_>, val: &serde_json::Value) -> PyResult<PyObject> {
    let json_str = serde_json::to_string(val)
        .map_err(|e| PyRuntimeError::new_err(format!("JSON serialization failed: {e}")))?;
    let json_mod = py.import("json")?;
    let result = json_mod.call_method1("loads", (json_str,))?;
    Ok(result.unbind())
}

/// The native Rust module. Re-exported via Python wrapper as `a2a_crypt`.
#[pymodule]
fn _core(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<PyKeyPair>()?;
    m.add_class::<PyKeyStore>()?;
    m.add_class::<PySession>()?;
    m.add_function(wrap_pyfunction!(is_encrypted, m)?)?;
    m.add_function(wrap_pyfunction!(inspect_metadata, m)?)?;
    m.add_function(wrap_pyfunction!(parse_agent_card, m)?)?;
    m.add_function(wrap_pyfunction!(negotiate_cipher, m)?)?;
    m.add_function(wrap_pyfunction!(build_agent_card_extension, m)?)?;
    Ok(())
}
