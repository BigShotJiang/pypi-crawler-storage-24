# Topic-Enhanced RAG
# Copyright (C) 2026 Topic-Enhanced RAG Research Team
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.

"""
topic_rag — Topic-Enhanced Retrieval-Augmented Generation Library

A lightweight Python library for topic-aware document processing and retrieval.

Quickstart::

    from topic_rag import DocumentProcessor, TopicEnhancedRAGRetriever

    processor = DocumentProcessor(n_topics=10)
    corpus_data = processor.process_corpus(documents)

    retriever = TopicEnhancedRAGRetriever(corpus_data)
    results = retriever.retrieve("What is machine learning?", k=5)
"""

from topic_rag.core import (
    DocumentProcessor,
    StandardRAGRetriever,
    TopicEnhancedRAGRetriever,
    SimpleTfidfVectorizer,
    SimpleTopicModel,
    run_single_document_rag_comparison,
    train_topic_embedder,
)

__version__ = "1.0.3"
__author__ = "Topic-Enhanced RAG Research Team"
__all__ = [
    "DocumentProcessor",
    "StandardRAGRetriever",
    "TopicEnhancedRAGRetriever",
    "SimpleTfidfVectorizer",
    "SimpleTopicModel",
    "run_single_document_rag_comparison",
    "train_topic_embedder",
]
