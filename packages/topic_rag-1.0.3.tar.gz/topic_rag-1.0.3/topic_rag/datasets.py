# Topic-Enhanced RAG
# Copyright (C) 2026 Topic-Enhanced RAG Research Team
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.

"""
Dataset loading utilities for various QA and retrieval benchmarks.
"""

import os
import json
import logging
from typing import List, Dict, Any, Optional, Tuple

from topic_rag.config import CACHE_DIR

logger = logging.getLogger(__name__)


class DatasetLoader:
    """
    Unified dataset loader for multiple QA and retrieval benchmarks.
    """

    def __init__(self, cache_dir: str = CACHE_DIR):
        self.cache_dir = cache_dir
        os.makedirs(cache_dir, exist_ok=True)

    def load_ms_marco(self, split: str = "train",
                      max_samples: Optional[int] = None) -> Tuple[List[Dict], List[Dict]]:
        """Load MS MARCO dataset."""
        logger.info(f"Loading MS MARCO dataset - {split} split (using fallback data)")
        return self._get_fallback_ms_marco_data()

    def load_natural_questions(self, split: str = "train",
                               max_samples: Optional[int] = None) -> Tuple[List[Dict], List[Dict]]:
        """Load Natural Questions dataset."""
        logger.info(f"Loading Natural Questions dataset - {split} split (using fallback data)")
        return self._get_fallback_natural_questions_data()

    def load_squad_v2(self, split: str = "train",
                      max_samples: Optional[int] = None) -> Tuple[List[Dict], List[Dict]]:
        """Load SQuAD v2.0 dataset."""
        logger.info(f"Loading SQuAD v2.0 dataset - {split} split")
        return self._get_fallback_squad_data()

    def load_hotpot_qa(self, split: str = "train",
                       max_samples: Optional[int] = None) -> Tuple[List[Dict], List[Dict]]:
        """Load HotpotQA dataset."""
        logger.info(f"Loading HotpotQA dataset - {split} split")
        return self._get_fallback_hotpot_data()

    def load_trivia_qa(self, split: str = "train",
                       max_samples: Optional[int] = None) -> Tuple[List[Dict], List[Dict]]:
        """Load TriviaQA dataset."""
        logger.info(f"Loading TriviaQA dataset - {split} split")
        return self._get_fallback_trivia_data()

    def load_custom_dataset(self, file_path: str) -> Tuple[List[Dict], List[Dict]]:
        """
        Load a custom dataset from a JSON file.

        Expected format::

            {
                "documents": [{"id": "doc1", "text": "...", "title": "..."}],
                "queries": [{"id": "q1", "query": "...", "answers": [...], "relevant_docs": [...]}]
            }
        """
        logger.info(f"Loading custom dataset from {file_path}")
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            documents = data.get("documents", [])
            queries = data.get("queries", [])
            logger.info(f"Loaded {len(documents)} documents and {len(queries)} queries")
            return documents, queries
        except Exception as e:
            logger.error(f"Error loading custom dataset: {str(e)}")
            return [], []

    def _get_fallback_ms_marco_data(self) -> Tuple[List[Dict], List[Dict]]:
        documents = [
            {
                "id": "doc_1",
                "text": "Microsoft Corporation is an American multinational technology company with "
                        "headquarters in Redmond, Washington. It develops, manufactures, licenses, "
                        "supports, and sells computer software, consumer electronics, personal computers, "
                        "and related services.",
                "title": "Microsoft Corporation",
                "url": ""
            },
            {
                "id": "doc_2",
                "text": "Python is a high-level, interpreted programming language with dynamic semantics. "
                        "Its high-level built-in data structures, combined with dynamic typing and dynamic "
                        "binding, make it very attractive for Rapid Application Development.",
                "title": "Python Programming Language",
                "url": ""
            }
        ]
        queries = [
            {
                "id": "query_1",
                "query": "What is Microsoft Corporation?",
                "answers": ["American multinational technology company"],
                "relevant_docs": ["doc_1"]
            },
            {
                "id": "query_2",
                "query": "What type of programming language is Python?",
                "answers": ["high-level, interpreted programming language"],
                "relevant_docs": ["doc_2"]
            }
        ]
        logger.warning("Using fallback MS MARCO data")
        return documents, queries

    def _get_fallback_natural_questions_data(self) -> Tuple[List[Dict], List[Dict]]:
        documents = [
            {
                "id": "nq_doc_1",
                "text": "The Statue of Liberty is a colossal neoclassical sculpture on Liberty Island "
                        "in New York Harbor in New York City, in the United States. The copper statue, "
                        "a gift from the people of France to the people of the United States, was designed "
                        "by French sculptor Frédéric Auguste Bartholdi.",
                "title": "Statue of Liberty",
                "url": ""
            }
        ]
        queries = [
            {
                "id": "nq_query_1",
                "query": "Who designed the Statue of Liberty?",
                "answers": ["Frédéric Auguste Bartholdi"],
                "relevant_docs": ["nq_doc_1"]
            }
        ]
        logger.warning("Using fallback Natural Questions data")
        return documents, queries

    def _get_fallback_squad_data(self) -> Tuple[List[Dict], List[Dict]]:
        documents = [
            {
                "id": "squad_doc_1",
                "text": "The Amazon rainforest, also known in English as Amazonia or the Amazon Jungle, "
                        "is a moist broadleaf forest that covers most of the Amazon basin of South America. "
                        "This basin encompasses 7,000,000 square kilometers (2,700,000 sq mi), of which "
                        "5,500,000 square kilometers (2,100,000 sq mi) are covered by the rainforest.",
                "title": "Amazon Rainforest",
                "url": ""
            }
        ]
        queries = [
            {
                "id": "squad_query_1",
                "query": "How many square kilometers does the Amazon basin encompass?",
                "answers": ["7,000,000 square kilometers"],
                "relevant_docs": ["squad_doc_1"],
                "is_impossible": False
            }
        ]
        logger.warning("Using fallback SQuAD data")
        return documents, queries

    def _get_fallback_hotpot_data(self) -> Tuple[List[Dict], List[Dict]]:
        documents = [
            {
                "id": "hotpot_doc_1",
                "text": "Albert Einstein was a German-born theoretical physicist who developed the theory "
                        "of relativity, one of the two pillars of modern physics. His work is also known "
                        "for its influence on the philosophy of science.",
                "title": "Albert Einstein",
                "url": ""
            },
            {
                "id": "hotpot_doc_2",
                "text": "The Nobel Prize in Physics is a yearly award given by the Royal Swedish Academy "
                        "of Sciences for those who have made the most outstanding contributions for mankind "
                        "in the field of physics.",
                "title": "Nobel Prize in Physics",
                "url": ""
            }
        ]
        queries = [
            {
                "id": "hotpot_query_1",
                "query": "What prize did Albert Einstein win for his contributions to physics?",
                "answers": ["Nobel Prize in Physics"],
                "relevant_docs": ["hotpot_doc_1", "hotpot_doc_2"],
                "level": "medium",
                "type": "bridge"
            }
        ]
        logger.warning("Using fallback HotpotQA data")
        return documents, queries

    def _get_fallback_trivia_data(self) -> Tuple[List[Dict], List[Dict]]:
        documents = [
            {
                "id": "trivia_doc_1",
                "text": "William Shakespeare was an English playwright, poet, and actor, widely regarded "
                        "as the greatest writer in the English language and the world's greatest dramatist. "
                        "He is often called England's national poet and the 'Bard of Avon'.",
                "title": "William Shakespeare",
                "url": ""
            }
        ]
        queries = [
            {
                "id": "trivia_query_1",
                "query": "Who is often called the 'Bard of Avon'?",
                "answers": ["William Shakespeare", "Shakespeare"],
                "relevant_docs": ["trivia_doc_1"]
            }
        ]
        logger.warning("Using fallback TriviaQA data")
        return documents, queries


def get_dataset_loader() -> DatasetLoader:
    """Get a configured DatasetLoader instance."""
    return DatasetLoader(cache_dir=CACHE_DIR)
