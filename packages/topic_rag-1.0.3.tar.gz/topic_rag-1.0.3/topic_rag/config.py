# Topic-Enhanced RAG
# Copyright (C) 2026 Topic-Enhanced RAG Research Team
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.

"""
Configuration settings for the Topic-Enhanced RAG library.
"""

import os

HUGGINGFACE_API_KEY = os.getenv("HUGGINGFACE_API_KEY", "")
WANDB_API_KEY = os.getenv("WANDB_API_KEY", "")

DEFAULT_SENTENCE_MODEL = "all-MiniLM-L6-v2"
DEFAULT_LLM_MODEL = "microsoft/DialoGPT-medium"
DEFAULT_N_TOPICS = 10

SUPPORTED_DATASETS = [
    "ms_marco",
    "natural_questions",
    "squad_v2",
    "hotpot_qa",
    "triviaqa"
]

DEFAULT_K_VALUES = [1, 3, 5, 10]
DEFAULT_METRICS = [
    "recall_at_k",
    "precision_at_k",
    "mrr",
    "ndcg",
    "hit_rate",
    "answer_accuracy"
]

RANDOM_SEED = 42
MAX_WORKERS = 4
BATCH_SIZE = 32
MAX_SEQUENCE_LENGTH = 512

RESULTS_DIR = "results"
FIGURES_DIR = "figures"
PAPERS_DIR = "papers"
CACHE_DIR = "cache"

SIGNIFICANCE_LEVEL = 0.05
CONFIDENCE_INTERVAL = 0.95

FIGURE_DPI = 300
FIGURE_FORMAT = "png"
PAPER_FIGURE_FORMAT = "pdf"

LATEX_TEMPLATE_DIR = "templates"
BIBLIOGRAPHY_FILE = "references.bib"

for directory in [RESULTS_DIR, FIGURES_DIR, PAPERS_DIR, CACHE_DIR]:
    os.makedirs(directory, exist_ok=True)
