# Topic-Enhanced RAG
# Copyright (C) 2026 Topic-Enhanced RAG Research Team
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.

"""
Visualization utilities for RAG evaluation results and research paper figures.
"""

import os
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from typing import List, Dict, Any, Optional
import logging

from topic_rag.config import FIGURES_DIR, FIGURE_DPI, FIGURE_FORMAT, PAPER_FIGURE_FORMAT

logger = logging.getLogger(__name__)

plt.style.use('default')
sns.set_palette("husl")

plt.rcParams['figure.dpi'] = FIGURE_DPI
plt.rcParams['savefig.dpi'] = FIGURE_DPI
plt.rcParams['font.size'] = 12
plt.rcParams['axes.labelsize'] = 14
plt.rcParams['axes.titlesize'] = 16
plt.rcParams['xtick.labelsize'] = 12
plt.rcParams['ytick.labelsize'] = 12
plt.rcParams['legend.fontsize'] = 12


class VisualizationManager:
    """
    Comprehensive visualization manager for RAG evaluation results.
    """

    def __init__(self, output_dir: str = FIGURES_DIR):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)

        self.subdirs = {
            'comparisons': os.path.join(output_dir, 'comparisons'),
            'ablations': os.path.join(output_dir, 'ablations'),
            'distributions': os.path.join(output_dir, 'distributions'),
            'paper': os.path.join(output_dir, 'paper')
        }

        for subdir in self.subdirs.values():
            os.makedirs(subdir, exist_ok=True)

    def plot_performance_comparison(self,
                                    results: Dict[str, Any],
                                    title: str = "RAG Performance Comparison",
                                    save_name: str = "performance_comparison") -> str:
        """Create a comprehensive performance comparison plot."""
        std_metrics = results.get('standard_rag', {}).get('avg_metrics', {})
        enh_metrics = results.get('enhanced_rag', {}).get('avg_metrics', {})

        if not std_metrics or not enh_metrics:
            logger.error("No metrics found for comparison plot")
            return ""

        metrics = []
        standard_values = []
        enhanced_values = []
        improvements = []

        for metric in std_metrics:
            if metric in enh_metrics:
                metrics.append(metric)
                std_val = std_metrics[metric]
                enh_val = enh_metrics[metric]
                standard_values.append(std_val)
                enhanced_values.append(enh_val)
                improvement = (enh_val - std_val) / std_val * 100 if std_val > 0 else 0
                improvements.append(improvement)

        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))

        x = np.arange(len(metrics))
        width = 0.35

        bars1 = ax1.bar(x - width / 2, standard_values, width, label='Standard RAG', alpha=0.8)
        bars2 = ax1.bar(x + width / 2, enhanced_values, width, label='Topic-Enhanced RAG', alpha=0.8)

        ax1.set_xlabel('Metrics')
        ax1.set_ylabel('Performance Score')
        ax1.set_title(f'{title} - Absolute Performance')
        ax1.set_xticks(x)
        ax1.set_xticklabels(metrics, rotation=45, ha='right')
        ax1.legend()
        ax1.grid(True, alpha=0.3)

        for bar in bars1:
            height = bar.get_height()
            ax1.annotate(f'{height:.3f}',
                         xy=(bar.get_x() + bar.get_width() / 2, height),
                         xytext=(0, 3), textcoords="offset points",
                         ha='center', va='bottom', fontsize=9)

        for bar in bars2:
            height = bar.get_height()
            ax1.annotate(f'{height:.3f}',
                         xy=(bar.get_x() + bar.get_width() / 2, height),
                         xytext=(0, 3), textcoords="offset points",
                         ha='center', va='bottom', fontsize=9)

        colors = ['green' if imp > 0 else 'red' for imp in improvements]
        bars3 = ax2.bar(x, improvements, color=colors, alpha=0.7)

        ax2.set_xlabel('Metrics')
        ax2.set_ylabel('Improvement (%)')
        ax2.set_title(f'{title} - Relative Improvement')
        ax2.set_xticks(x)
        ax2.set_xticklabels(metrics, rotation=45, ha='right')
        ax2.axhline(y=0, color='black', linestyle='-', alpha=0.3)
        ax2.grid(True, alpha=0.3)

        for bar, imp in zip(bars3, improvements):
            height = bar.get_height()
            ax2.annotate(f'{imp:+.1f}%',
                         xy=(bar.get_x() + bar.get_width() / 2, height),
                         xytext=(0, 3 if height >= 0 else -15),
                         textcoords="offset points",
                         ha='center', va='bottom' if height >= 0 else 'top',
                         fontsize=9)

        plt.tight_layout()

        filepath = os.path.join(self.subdirs['comparisons'], f"{save_name}.{FIGURE_FORMAT}")
        plt.savefig(filepath, dpi=FIGURE_DPI, bbox_inches='tight')
        plt.close()

        logger.info(f"Saved performance comparison plot to {filepath}")
        return filepath

    def plot_cross_dataset_comparison(self,
                                      comparison_results: Dict[str, Any],
                                      title: str = "Cross-Dataset Performance Comparison",
                                      save_name: str = "cross_dataset_comparison") -> str:
        """Create a cross-dataset comparison heatmap."""
        dataset_summaries = comparison_results.get('dataset_summaries', {})

        if not dataset_summaries:
            logger.error("No dataset summaries found")
            return ""

        datasets = list(dataset_summaries.keys())
        metrics = set()
        for dataset_data in dataset_summaries.values():
            metrics.update(dataset_data.get('improvements', {}).keys())
        metrics = sorted(list(metrics))

        improvement_matrix = []
        for dataset in datasets:
            row = [dataset_summaries[dataset].get('improvements', {}).get(m, 0) for m in metrics]
            improvement_matrix.append(row)

        fig, ax = plt.subplots(figsize=(12, 8))
        im = ax.imshow(improvement_matrix, cmap='RdYlGn', aspect='auto')
        ax.set_xticks(np.arange(len(metrics)))
        ax.set_yticks(np.arange(len(datasets)))
        ax.set_xticklabels(metrics, rotation=45, ha='right')
        ax.set_yticklabels(datasets)
        cbar = plt.colorbar(im, ax=ax)
        cbar.set_label('Improvement (%)', rotation=270, labelpad=20)

        for i in range(len(datasets)):
            for j in range(len(metrics)):
                ax.text(j, i, f'{improvement_matrix[i][j]:.1f}%',
                        ha="center", va="center", color="black", fontweight='bold')

        ax.set_title(title)
        plt.tight_layout()

        filepath = os.path.join(self.subdirs['comparisons'], f"{save_name}.{FIGURE_FORMAT}")
        plt.savefig(filepath, dpi=FIGURE_DPI, bbox_inches='tight')
        plt.close()

        logger.info(f"Saved cross-dataset comparison plot to {filepath}")
        return filepath

    def plot_ablation_study(self,
                            ablation_results: Dict[str, Any],
                            title: str = "Ablation Study Results",
                            save_name: str = "ablation_study") -> str:
        """Create ablation study visualization."""
        component_effects = ablation_results.get('component_effects', {})

        if not component_effects:
            logger.error("No component effects found for ablation plot")
            return ""

        components = list(component_effects.keys())
        metrics = set()
        for effects in component_effects.values():
            metrics.update(effects.keys())
        metrics = sorted(list(metrics))

        effect_matrix = []
        for component in components:
            effect_matrix.append([component_effects[component].get(m, 0) for m in metrics])

        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))

        im = ax1.imshow(effect_matrix, cmap='Reds', aspect='auto')
        ax1.set_xticks(np.arange(len(metrics)))
        ax1.set_yticks(np.arange(len(components)))
        ax1.set_xticklabels(metrics, rotation=45, ha='right')
        ax1.set_yticklabels([c.replace('_', ' ').title() for c in components])
        cbar1 = plt.colorbar(im, ax=ax1)
        cbar1.set_label('Performance Drop (%)', rotation=270, labelpad=20)

        for i in range(len(components)):
            for j in range(len(metrics)):
                ax1.text(j, i, f'{effect_matrix[i][j]:.1f}%',
                         ha="center", va="center",
                         color="white" if effect_matrix[i][j] > 10 else "black")

        ax1.set_title('Component Importance Heatmap')

        avg_effects = [np.mean(effects) for effects in effect_matrix]
        component_names = [c.replace('_', ' ').title() for c in components]
        bars = ax2.barh(range(len(components)), avg_effects, color='coral', alpha=0.7)
        ax2.set_yticks(range(len(components)))
        ax2.set_yticklabels(component_names)
        ax2.set_xlabel('Average Performance Drop (%)')
        ax2.set_title('Component Importance Ranking')
        ax2.grid(True, alpha=0.3)

        for i, (bar, effect) in enumerate(zip(bars, avg_effects)):
            ax2.text(effect + 0.1, i, f'{effect:.1f}%', va='center', ha='left', fontweight='bold')

        plt.tight_layout()

        filepath = os.path.join(self.subdirs['ablations'], f"{save_name}.{FIGURE_FORMAT}")
        plt.savefig(filepath, dpi=FIGURE_DPI, bbox_inches='tight')
        plt.close()

        logger.info(f"Saved ablation study plot to {filepath}")
        return filepath

    def plot_statistical_analysis(self,
                                  statistical_results: Dict[str, Any],
                                  title: str = "Statistical Analysis Results",
                                  save_name: str = "statistical_analysis") -> str:
        """Create statistical analysis visualization."""
        significance_tests = statistical_results.get('significance_tests', {})
        effect_sizes = statistical_results.get('effect_sizes', {})

        if not significance_tests or not effect_sizes:
            logger.error("No statistical data found")
            return ""

        metrics = []
        p_values = []
        effect_sizes_values = []
        significance_status = []

        for metric in significance_tests:
            test_results = significance_tests[metric]
            p_value = None
            if 'paired_t_test' in test_results:
                p_value = test_results['paired_t_test'].get('p_value')
            elif test_results:
                p_value = list(test_results.values())[0].get('p_value')

            if p_value is not None:
                metrics.append(metric)
                p_values.append(p_value)
                cohens_d = effect_sizes.get(metric, {}).get('cohens_d', 0)
                effect_sizes_values.append(abs(cohens_d))
                significance_status.append('Significant' if p_value < 0.05 else 'Not Significant')

        if not metrics:
            logger.error("No valid statistical data found")
            return ""

        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))

        colors = ['green' if s == 'Significant' else 'red' for s in significance_status]
        bars1 = ax1.bar(range(len(metrics)), [-np.log10(p) for p in p_values], color=colors, alpha=0.7)
        ax1.set_xlabel('Metrics')
        ax1.set_ylabel('-log10(p-value)')
        ax1.set_title('Statistical Significance')
        ax1.set_xticks(range(len(metrics)))
        ax1.set_xticklabels(metrics, rotation=45, ha='right')
        ax1.axhline(y=-np.log10(0.05), color='black', linestyle='--', alpha=0.5, label='p=0.05 threshold')
        ax1.legend()
        ax1.grid(True, alpha=0.3)

        for bar, p_val in zip(bars1, p_values):
            height = bar.get_height()
            ax1.annotate(f'p={p_val:.4f}',
                         xy=(bar.get_x() + bar.get_width() / 2, height),
                         xytext=(0, 3), textcoords="offset points",
                         ha='center', va='bottom', fontsize=8, rotation=90)

        bars2 = ax2.bar(range(len(metrics)), effect_sizes_values, color='steelblue', alpha=0.7)
        ax2.set_xlabel('Metrics')
        ax2.set_ylabel("Cohen's d (absolute value)")
        ax2.set_title('Effect Sizes')
        ax2.set_xticks(range(len(metrics)))
        ax2.set_xticklabels(metrics, rotation=45, ha='right')
        ax2.grid(True, alpha=0.3)
        ax2.axhline(y=0.2, color='green', linestyle='--', alpha=0.5, label='Small effect')
        ax2.axhline(y=0.5, color='orange', linestyle='--', alpha=0.5, label='Medium effect')
        ax2.axhline(y=0.8, color='red', linestyle='--', alpha=0.5, label='Large effect')
        ax2.legend()

        for bar, effect in zip(bars2, effect_sizes_values):
            height = bar.get_height()
            ax2.annotate(f'{effect:.3f}',
                         xy=(bar.get_x() + bar.get_width() / 2, height),
                         xytext=(0, 3), textcoords="offset points",
                         ha='center', va='bottom', fontsize=9)

        plt.tight_layout()

        filepath = os.path.join(self.subdirs['distributions'], f"{save_name}.{FIGURE_FORMAT}")
        plt.savefig(filepath, dpi=FIGURE_DPI, bbox_inches='tight')
        plt.close()

        logger.info(f"Saved statistical analysis plot to {filepath}")
        return filepath
