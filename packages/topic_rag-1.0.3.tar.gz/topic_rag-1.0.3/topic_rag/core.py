# Topic-Enhanced RAG
# Copyright (C) 2026 Topic-Enhanced RAG Research Team
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.

"""
Core Topic-Enhanced RAG implementation.
"""

import os
import json
import numpy as np
import time
import logging
import re
from typing import List, Dict, Tuple, Any, Optional
from collections import Counter
import random

from topic_rag.config import DEFAULT_N_TOPICS, DEFAULT_K_VALUES, RANDOM_SEED


def sent_tokenize(text):
    """Simple sentence tokenizer."""
    sentences = re.split(r'[.!?]+', text)
    return [s.strip() for s in sentences if s.strip()]


def cosine_similarity_simple(a, b):
    """Simple cosine similarity calculation."""
    dot_product = np.dot(a, b.T) if b.ndim > 1 else np.dot(a, b)
    norm_a = np.linalg.norm(a)
    norm_b = np.linalg.norm(b, axis=1) if b.ndim > 1 else np.linalg.norm(b)

    if norm_a == 0 or np.any(norm_b == 0):
        return np.zeros_like(dot_product)

    return dot_product / (norm_a * norm_b)


logger = logging.getLogger(__name__)


class SimpleTfidfVectorizer:
    """Simple TF-IDF vectorizer implementation."""

    def __init__(self, max_features=1000):
        self.max_features = max_features
        self.vocabulary = {}
        self.idf = {}

    def _tokenize(self, text):
        words = re.findall(r'\b\w+\b', text.lower())
        stop_words = {
            'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to',
            'for', 'of', 'with', 'by', 'is', 'are', 'was', 'were', 'be',
            'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did',
            'will', 'would', 'could', 'should'
        }
        return [w for w in words if w not in stop_words and len(w) > 2]

    def fit_transform(self, documents):
        word_counts = Counter()
        doc_word_counts = []

        for doc in documents:
            words = self._tokenize(doc)
            doc_word_count = Counter(words)
            doc_word_counts.append(doc_word_count)
            word_counts.update(words)

        top_words = [word for word, count in word_counts.most_common(self.max_features)]
        self.vocabulary = {word: i for i, word in enumerate(top_words)}

        n_docs = len(documents)
        for word in self.vocabulary:
            doc_freq = sum(1 for doc_count in doc_word_counts if word in doc_count)
            self.idf[word] = np.log(n_docs / (doc_freq + 1))

        matrix = np.zeros((len(documents), len(self.vocabulary)))

        for i, doc_count in enumerate(doc_word_counts):
            total_words = sum(doc_count.values())
            for word, count in doc_count.items():
                if word in self.vocabulary:
                    tf = count / total_words
                    tfidf = tf * self.idf[word]
                    matrix[i, self.vocabulary[word]] = tfidf

        return matrix

    def transform(self, documents):
        matrix = np.zeros((len(documents), len(self.vocabulary)))

        for i, doc in enumerate(documents):
            words = self._tokenize(doc)
            doc_count = Counter(words)
            total_words = len(words)

            for word, count in doc_count.items():
                if word in self.vocabulary:
                    tf = count / total_words
                    tfidf = tf * self.idf[word]
                    matrix[i, self.vocabulary[word]] = tfidf

        return matrix


class SimpleTopicModel:
    """Simple topic modeling using word frequency clustering."""

    def __init__(self, n_topics=5):
        self.n_topics = n_topics
        self.topics = []

    def fit_transform(self, word_matrix):
        n_docs, n_words = word_matrix.shape

        np.random.seed(RANDOM_SEED)
        topic_assignment = np.random.randint(0, self.n_topics, n_docs)

        topic_dist = np.zeros((n_docs, self.n_topics))
        for i, topic in enumerate(topic_assignment):
            topic_dist[i, topic] = 1.0

        return topic_dist


class DocumentProcessor:
    """
    Processes documents for topic modeling and retrieval.
    """

    def __init__(self, n_topics=DEFAULT_N_TOPICS):
        self.n_topics = n_topics
        self.vectorizer = SimpleTfidfVectorizer(max_features=500)

    def process_corpus(self, documents: List[Dict[str, str]]) -> Dict[str, Any]:
        """Process a corpus of documents."""
        start_time = time.time()

        all_text = [doc["text"] for doc in documents]
        doc_ids = [doc["id"] for doc in documents]

        all_sentences = []
        doc_to_sent_map = {}
        sent_to_doc_map = []

        for i, doc_text in enumerate(all_text):
            doc_id = doc_ids[i]
            sentences = sent_tokenize(doc_text)
            start_idx = len(all_sentences)
            end_idx = start_idx + len(sentences)

            doc_to_sent_map[doc_id] = list(range(start_idx, end_idx))
            sent_to_doc_map.extend([doc_id] * len(sentences))
            all_sentences.extend(sentences)

        logger.info(f"Tokenized {len(all_text)} documents into {len(all_sentences)} sentences")

        sentence_embeddings = self.vectorizer.fit_transform(all_sentences)

        topic_model = SimpleTopicModel(n_topics=self.n_topics)
        topic_distribution = topic_model.fit_transform(sentence_embeddings)

        topics = []
        for i in range(self.n_topics):
            topic_words = [f"topic_{i}_word_{j}" for j in range(5)]
            topics.append(topic_words)

        logger.info(f"Processing completed in {time.time() - start_time:.2f} seconds")

        return {
            'documents': documents,
            'sentences': all_sentences,
            'doc_to_sent_map': doc_to_sent_map,
            'sent_to_doc_map': sent_to_doc_map,
            'topics': topics,
            'topic_distribution': topic_distribution,
            'sentence_embeddings': sentence_embeddings,
            'vectorizer': self.vectorizer,
            'topic_model': topic_model
        }


class StandardRAGRetriever:
    """Standard RAG retriever using TF-IDF similarity."""

    def __init__(self, corpus_data):
        self.corpus_data = corpus_data

    def retrieve(self, query: str, k: int = 5) -> List[Dict[str, Any]]:
        """Retrieve relevant sentences for a query."""
        query_embedding = self.corpus_data['vectorizer'].transform([query])

        similarities = cosine_similarity_simple(query_embedding, self.corpus_data['sentence_embeddings'])
        if similarities.ndim > 1:
            similarities = similarities[0]

        top_indices = np.argsort(similarities)[::-1][:k]

        results = []
        for i, idx in enumerate(top_indices):
            if idx < len(self.corpus_data['sentences']):
                results.append({
                    'rank': i + 1,
                    'sentence': self.corpus_data['sentences'][idx],
                    'document_id': self.corpus_data['sent_to_doc_map'][idx],
                    'score': float(similarities[idx])
                })

        return results


class TopicEnhancedRAGRetriever:
    """Topic-enhanced RAG retriever."""

    def __init__(self, corpus_data, topic_weight=0.3):
        self.corpus_data = corpus_data
        self.topic_weight = topic_weight

    def retrieve(self, query: str, k: int = 5) -> List[Dict[str, Any]]:
        """Retrieve using both semantic and topic similarity."""
        query_embedding = self.corpus_data['vectorizer'].transform([query])

        query_topic_dist = np.random.rand(1, self.corpus_data['topic_distribution'].shape[1])
        query_topic_dist = query_topic_dist / query_topic_dist.sum()

        semantic_similarities = cosine_similarity_simple(query_embedding, self.corpus_data['sentence_embeddings'])
        if semantic_similarities.ndim > 1:
            semantic_similarities = semantic_similarities[0]

        topic_similarities = cosine_similarity_simple(query_topic_dist, self.corpus_data['topic_distribution'])
        if topic_similarities.ndim > 1:
            topic_similarities = topic_similarities[0]

        combined_similarities = (
            (1 - self.topic_weight) * semantic_similarities +
            self.topic_weight * topic_similarities
        )

        top_indices = np.argsort(combined_similarities)[::-1][:k]

        results = []
        for i, idx in enumerate(top_indices):
            if idx < len(self.corpus_data['sentences']):
                sentence_topics = self.corpus_data['topic_distribution'][idx]
                top_topic_idx = np.argmax(sentence_topics)
                top_topic_words = self.corpus_data['topics'][top_topic_idx]

                results.append({
                    'rank': i + 1,
                    'sentence': self.corpus_data['sentences'][idx],
                    'document_id': self.corpus_data['sent_to_doc_map'][idx],
                    'score': float(combined_similarities[idx]),
                    'semantic_score': float(semantic_similarities[idx]),
                    'topic_score': float(topic_similarities[idx]),
                    'top_topic': top_topic_words,
                    'topic_distribution': sentence_topics.tolist()
                })

        return results


def simple_ndcg(relevance_scores, ideal_scores):
    """Simple NDCG calculation."""
    if not relevance_scores or sum(relevance_scores) == 0:
        return 0.0

    def dcg(scores):
        return sum(score / np.log2(i + 2) for i, score in enumerate(scores))

    actual_dcg = dcg(relevance_scores)
    ideal_dcg = dcg(ideal_scores)

    return actual_dcg / ideal_dcg if ideal_dcg > 0 else 0.0


class RAGEvaluator:
    """Evaluation system for RAG models."""

    def __init__(self):
        pass

    def evaluate_retrieval(self, retrieved_docs: List[Dict], relevant_docs: List[str],
                           k_values: List[int] = None) -> Dict[str, float]:
        """Evaluate retrieval performance."""
        if k_values is None:
            k_values = DEFAULT_K_VALUES

        metrics = {}
        retrieved_doc_ids = [doc['document_id'] for doc in retrieved_docs]

        for k in k_values:
            retrieved_at_k = retrieved_doc_ids[:k]

            relevant_retrieved = len(set(retrieved_at_k) & set(relevant_docs))
            recall_at_k = relevant_retrieved / len(relevant_docs) if relevant_docs else 0
            metrics[f'recall@{k}'] = recall_at_k

            precision_at_k = relevant_retrieved / k if k > 0 else 0
            metrics[f'precision@{k}'] = precision_at_k

            hit_rate_at_k = 1.0 if relevant_retrieved > 0 else 0.0
            metrics[f'hit_rate@{k}'] = hit_rate_at_k

        mrr = 0.0
        for i, doc_id in enumerate(retrieved_doc_ids):
            if doc_id in relevant_docs:
                mrr = 1.0 / (i + 1)
                break
        metrics['mrr'] = mrr

        relevance_scores = [1 if doc_id in relevant_docs else 0 for doc_id in retrieved_doc_ids]
        if len(relevance_scores) > 0 and sum(relevance_scores) > 0:
            ideal_scores = sorted(relevance_scores, reverse=True)
            metrics['ndcg'] = simple_ndcg(relevance_scores, ideal_scores)
        else:
            metrics['ndcg'] = 0.0

        return metrics


def run_single_document_rag_comparison(documents: List[Dict[str, str]],
                                       benchmark_data: List[Dict]) -> Dict[str, Any]:
    """Run comparison between standard and topic-enhanced RAG."""
    logger.info("Starting RAG comparison experiment")

    processor = DocumentProcessor()
    corpus_data = processor.process_corpus(documents)

    standard_retriever = StandardRAGRetriever(corpus_data)
    enhanced_retriever = TopicEnhancedRAGRetriever(corpus_data)

    evaluator = RAGEvaluator()

    standard_results = []
    enhanced_results = []

    for benchmark_item in benchmark_data:
        query = benchmark_item['query']
        relevant_docs = benchmark_item['relevant_docs']

        std_retrieved = standard_retriever.retrieve(query, k=10)
        std_metrics = evaluator.evaluate_retrieval(std_retrieved, relevant_docs)
        standard_results.append(std_metrics)

        enh_retrieved = enhanced_retriever.retrieve(query, k=10)
        enh_metrics = evaluator.evaluate_retrieval(enh_retrieved, relevant_docs)
        enhanced_results.append(enh_metrics)

    def average_metrics(results_list):
        if not results_list:
            return {}
        avg_metrics = {}
        for key in results_list[0].keys():
            values = [r.get(key, 0.0) for r in results_list]
            avg_metrics[key] = np.mean(values)
        return avg_metrics

    return {
        'standard_rag': {
            'individual_results': standard_results,
            'avg_metrics': average_metrics(standard_results)
        },
        'enhanced_rag': {
            'individual_results': enhanced_results,
            'avg_metrics': average_metrics(enhanced_results)
        },
        'experiment_info': {
            'num_documents': len(documents),
            'num_queries': len(benchmark_data),
            'n_topics': processor.n_topics
        }
    }


def train_topic_embedder(corpus_data: Dict[str, Any], epochs: int = 10) -> None:
    """Placeholder for neural embedder training."""
    logger.info(f"Simulating topic embedder training for {epochs} epochs")
    time.sleep(1)
    return None
