# Topic-Enhanced RAG
# Copyright (C) 2026 Topic-Enhanced RAG Research Team
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.

"""
Statistical analysis utilities for RAG evaluation results.
"""

import numpy as np
import pandas as pd
from typing import List, Dict, Any, Tuple, Optional
from scipy import stats
from scipy.stats import ttest_rel, wilcoxon, mannwhitneyu
import logging

from topic_rag.config import SIGNIFICANCE_LEVEL, CONFIDENCE_INTERVAL

logger = logging.getLogger(__name__)


class StatisticalAnalyzer:
    """
    Comprehensive statistical analysis for RAG evaluation results.
    """

    def __init__(self, significance_level: float = SIGNIFICANCE_LEVEL):
        self.significance_level = significance_level
        self.confidence_level = 1 - significance_level

    def calculate_comparison_statistics(self,
                                        standard_results: List[Dict[str, float]],
                                        enhanced_results: List[Dict[str, float]]) -> Dict[str, Any]:
        """Calculate comprehensive statistical comparison between two result sets."""
        if len(standard_results) != len(enhanced_results):
            logger.warning("Unequal number of results in comparison")
            min_len = min(len(standard_results), len(enhanced_results))
            standard_results = standard_results[:min_len]
            enhanced_results = enhanced_results[:min_len]

        if len(standard_results) == 0:
            logger.error("No results to analyze")
            return {}

        all_metrics = set()
        for result in standard_results + enhanced_results:
            all_metrics.update(result.keys())

        analysis = {
            'descriptive_statistics': {},
            'significance_tests': {},
            'effect_sizes': {},
            'confidence_intervals': {},
            'summary': {}
        }

        for metric in all_metrics:
            std_values = [r.get(metric, 0.0) for r in standard_results]
            enh_values = [r.get(metric, 0.0) for r in enhanced_results]

            if all(v == 0 for v in std_values + enh_values):
                continue

            analysis['descriptive_statistics'][metric] = self._calculate_descriptive_stats(
                std_values, enh_values)
            analysis['significance_tests'][metric] = self._perform_significance_tests(
                std_values, enh_values)
            analysis['effect_sizes'][metric] = self._calculate_effect_sizes(
                std_values, enh_values)
            analysis['confidence_intervals'][metric] = self._calculate_confidence_intervals(
                std_values, enh_values)

        analysis['summary'] = self._generate_summary(analysis)
        return analysis

    def perform_ablation_analysis(self, ablation_results: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
        """Perform statistical analysis for ablation study results."""
        analysis = {
            'component_effects': {},
            'ranking': {},
            'recommendations': []
        }

        baseline_key = 'full_model'
        if baseline_key not in ablation_results:
            logger.error("No baseline (full_model) results found for ablation analysis")
            return analysis

        baseline_metrics = ablation_results[baseline_key].get('enhanced_rag', {}).get('avg_metrics', {})

        for config_name, results in ablation_results.items():
            if config_name == baseline_key or 'error' in results:
                continue

            config_metrics = results.get('enhanced_rag', {}).get('avg_metrics', {})
            effects = {}
            for metric in baseline_metrics:
                if metric in config_metrics:
                    baseline_val = baseline_metrics[metric]
                    config_val = config_metrics[metric]
                    effect = (baseline_val - config_val) / baseline_val * 100 if baseline_val > 0 else 0.0
                    effects[metric] = effect

            analysis['component_effects'][config_name] = effects

        analysis['ranking'] = self._rank_components_by_importance(analysis['component_effects'])
        analysis['recommendations'] = self._generate_ablation_recommendations(analysis)
        return analysis

    def calculate_power_analysis(self,
                                 standard_results: List[Dict[str, float]],
                                 enhanced_results: List[Dict[str, float]],
                                 desired_power: float = 0.8) -> Dict[str, Any]:
        """Calculate statistical power analysis for the comparison."""
        power_analysis = {}

        all_metrics = set()
        for result in standard_results + enhanced_results:
            all_metrics.update(result.keys())

        for metric in all_metrics:
            std_values = np.array([r.get(metric, 0.0) for r in standard_results])
            enh_values = np.array([r.get(metric, 0.0) for r in enhanced_results])

            if np.all(std_values == 0) and np.all(enh_values == 0):
                continue

            pooled_std = np.sqrt(
                ((len(std_values) - 1) * np.var(std_values, ddof=1) +
                 (len(enh_values) - 1) * np.var(enh_values, ddof=1)) /
                (len(std_values) + len(enh_values) - 2)
            )

            if pooled_std > 0:
                cohens_d = (np.mean(enh_values) - np.mean(std_values)) / pooled_std
            else:
                cohens_d = 0.0

            if abs(cohens_d) > 0:
                z_alpha = stats.norm.ppf(1 - self.significance_level / 2)
                z_beta = stats.norm.ppf(desired_power)
                required_n = ((z_alpha + z_beta) / cohens_d) ** 2 * 2
            else:
                required_n = float('inf')

            power_analysis[metric] = {
                'effect_size': cohens_d,
                'current_sample_size': len(std_values),
                'required_sample_size': int(required_n) if required_n != float('inf') else None,
                'adequate_power': len(std_values) >= required_n if required_n != float('inf') else False
            }

        return power_analysis

    def _calculate_descriptive_stats(self, std_values, enh_values):
        std_array = np.array(std_values)
        enh_array = np.array(enh_values)
        return {
            'standard_rag': {
                'mean': float(np.mean(std_array)),
                'std': float(np.std(std_array, ddof=1)) if len(std_array) > 1 else 0.0,
                'median': float(np.median(std_array)),
                'min': float(np.min(std_array)),
                'max': float(np.max(std_array)),
                'n': len(std_array)
            },
            'enhanced_rag': {
                'mean': float(np.mean(enh_array)),
                'std': float(np.std(enh_array, ddof=1)) if len(enh_array) > 1 else 0.0,
                'median': float(np.median(enh_array)),
                'min': float(np.min(enh_array)),
                'max': float(np.max(enh_array)),
                'n': len(enh_array)
            },
            'difference': {
                'mean_diff': float(np.mean(enh_array) - np.mean(std_array)),
                'median_diff': float(np.median(enh_array) - np.median(std_array))
            }
        }

    def _perform_significance_tests(self, std_values, enh_values):
        std_array = np.array(std_values)
        enh_array = np.array(enh_values)
        results = {}

        try:
            if len(std_array) > 1 and len(enh_array) > 1:
                t_stat, t_p_value = ttest_rel(enh_array, std_array)
                results['paired_t_test'] = {
                    'statistic': float(t_stat),
                    'p_value': float(t_p_value),
                    'significant': t_p_value < self.significance_level
                }
        except Exception as e:
            logger.warning(f"Could not perform paired t-test: {e}")

        try:
            if len(std_array) > 1 and len(enh_array) > 1:
                w_stat, w_p_value = wilcoxon(enh_array, std_array)
                results['wilcoxon_test'] = {
                    'statistic': float(w_stat),
                    'p_value': float(w_p_value),
                    'significant': w_p_value < self.significance_level
                }
        except Exception as e:
            logger.warning(f"Could not perform Wilcoxon test: {e}")

        try:
            if len(std_array) > 1 and len(enh_array) > 1:
                u_stat, u_p_value = mannwhitneyu(enh_array, std_array, alternative='two-sided')
                results['mann_whitney_test'] = {
                    'statistic': float(u_stat),
                    'p_value': float(u_p_value),
                    'significant': u_p_value < self.significance_level
                }
        except Exception as e:
            logger.warning(f"Could not perform Mann-Whitney test: {e}")

        return results

    def _calculate_effect_sizes(self, std_values, enh_values):
        std_array = np.array(std_values)
        enh_array = np.array(enh_values)
        effect_sizes = {}

        try:
            pooled_std = np.sqrt(
                ((len(std_array) - 1) * np.var(std_array, ddof=1) +
                 (len(enh_array) - 1) * np.var(enh_array, ddof=1)) /
                (len(std_array) + len(enh_array) - 2)
            )
            if pooled_std > 0:
                cohens_d = (np.mean(enh_array) - np.mean(std_array)) / pooled_std
                effect_sizes['cohens_d'] = float(cohens_d)
                if abs(cohens_d) < 0.2:
                    interpretation = "negligible"
                elif abs(cohens_d) < 0.5:
                    interpretation = "small"
                elif abs(cohens_d) < 0.8:
                    interpretation = "medium"
                else:
                    interpretation = "large"
                effect_sizes['cohens_d_interpretation'] = interpretation
        except Exception as e:
            logger.warning(f"Could not calculate Cohen's d: {e}")

        try:
            if np.std(std_array, ddof=1) > 0:
                glass_delta = (np.mean(enh_array) - np.mean(std_array)) / np.std(std_array, ddof=1)
                effect_sizes['glass_delta'] = float(glass_delta)
        except Exception as e:
            logger.warning(f"Could not calculate Glass's delta: {e}")

        try:
            if np.mean(std_array) > 0:
                percent_improvement = (np.mean(enh_array) - np.mean(std_array)) / np.mean(std_array) * 100
                effect_sizes['percent_improvement'] = float(percent_improvement)
        except Exception as e:
            logger.warning(f"Could not calculate percentage improvement: {e}")

        return effect_sizes

    def _calculate_confidence_intervals(self, std_values, enh_values):
        std_array = np.array(std_values)
        enh_array = np.array(enh_values)
        confidence_intervals = {}

        try:
            diff = enh_array - std_array
            mean_diff = np.mean(diff)
            sem_diff = stats.sem(diff)
            df = len(diff) - 1
            t_critical = stats.t.ppf((1 + self.confidence_level) / 2, df)
            margin_error = t_critical * sem_diff
            confidence_intervals['mean_difference'] = {
                'lower': float(mean_diff - margin_error),
                'upper': float(mean_diff + margin_error),
                'confidence_level': self.confidence_level
            }
        except Exception as e:
            logger.warning(f"Could not calculate confidence interval: {e}")

        return confidence_intervals

    def _generate_summary(self, analysis):
        summary = {
            'significant_improvements': [],
            'largest_improvements': [],
            'recommendations': []
        }

        for metric, tests in analysis.get('significance_tests', {}).items():
            for test_name, test_result in tests.items():
                if test_result.get('significant', False):
                    effect_size = analysis.get('effect_sizes', {}).get(metric, {})
                    percent_improvement = effect_size.get('percent_improvement', 0)
                    if percent_improvement > 0:
                        summary['significant_improvements'].append({
                            'metric': metric,
                            'test': test_name,
                            'p_value': test_result.get('p_value', 1.0),
                            'improvement': percent_improvement
                        })

        for metric, effect_data in analysis.get('effect_sizes', {}).items():
            percent_improvement = effect_data.get('percent_improvement', 0)
            if percent_improvement > 0:
                summary['largest_improvements'].append({
                    'metric': metric,
                    'improvement': percent_improvement,
                    'effect_size': effect_data.get('cohens_d', 0),
                    'interpretation': effect_data.get('cohens_d_interpretation', 'unknown')
                })

        summary['largest_improvements'].sort(key=lambda x: x['improvement'], reverse=True)
        summary['significant_improvements'].sort(key=lambda x: x['improvement'], reverse=True)

        if summary['significant_improvements']:
            summary['recommendations'].append(
                "Topic-Enhanced RAG shows statistically significant improvements over standard RAG"
            )

        if summary['largest_improvements']:
            best_metric = summary['largest_improvements'][0]
            summary['recommendations'].append(
                f"Largest improvement observed in {best_metric['metric']} "
                f"({best_metric['improvement']:.1f}% improvement)"
            )

        return summary

    def _rank_components_by_importance(self, component_effects):
        rankings = {}
        for component, effects in component_effects.items():
            if effects:
                avg_effect = np.mean(list(effects.values()))
                rankings[component] = {
                    'average_effect': avg_effect,
                    'max_effect': max(effects.values()) if effects.values() else 0,
                    'affected_metrics': len([e for e in effects.values() if e > 1.0])
                }
        sorted_components = sorted(rankings.items(), key=lambda x: x[1]['average_effect'], reverse=True)
        return {
            'by_average_effect': sorted_components,
            'component_scores': rankings
        }

    def _generate_ablation_recommendations(self, analysis):
        recommendations = []
        ranking = analysis.get('ranking', {})
        if 'by_average_effect' in ranking and ranking['by_average_effect']:
            most_important = ranking['by_average_effect'][0]
            component_name = most_important[0]
            avg_effect = most_important[1]['average_effect']
            recommendations.append(
                f"The {component_name.replace('_', ' ')} component is most critical "
                f"(average {avg_effect:.1f}% performance drop when removed)"
            )
        component_effects = analysis.get('component_effects', {})
        if 'no_embedder_training' in component_effects:
            embedder_effect = np.mean(list(component_effects['no_embedder_training'].values()))
            if embedder_effect > 5.0:
                recommendations.append("Embedder training is essential for optimal performance")
        return recommendations


def calculate_statistical_significance(results1: List[float],
                                       results2: List[float]) -> Dict[str, Any]:
    """Convenience function to calculate statistical significance between two result sets."""
    analyzer = StatisticalAnalyzer()
    dict_results1 = [{'metric': val} for val in results1]
    dict_results2 = [{'metric': val} for val in results2]
    analysis = analyzer.calculate_comparison_statistics(dict_results1, dict_results2)
    return analysis.get('significance_tests', {}).get('metric', {})
