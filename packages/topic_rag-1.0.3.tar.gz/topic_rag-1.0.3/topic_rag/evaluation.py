# Topic-Enhanced RAG
# Copyright (C) 2026 Topic-Enhanced RAG Research Team
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as
# published by the Free Software Foundation, either version 3 of the
# License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.

"""
Comprehensive evaluation pipeline for Topic-Enhanced RAG systems.
"""

import os
import json
import time
import numpy as np
from typing import List, Dict, Any, Optional
import logging

from topic_rag.core import (
    DocumentProcessor, StandardRAGRetriever, TopicEnhancedRAGRetriever,
    RAGEvaluator, run_single_document_rag_comparison, train_topic_embedder
)
from topic_rag.datasets import DatasetLoader
from topic_rag.statistics import StatisticalAnalyzer
from topic_rag.visualization import VisualizationManager
from topic_rag.config import (
    RESULTS_DIR, DEFAULT_N_TOPICS, DEFAULT_K_VALUES, SUPPORTED_DATASETS
)

logger = logging.getLogger(__name__)


class ExperimentConfig:
    """Configuration class for experiments."""

    def __init__(self,
                 dataset_name: str,
                 max_documents: Optional[int] = None,
                 max_queries: Optional[int] = None,
                 n_topics: int = DEFAULT_N_TOPICS,
                 k_values: List[int] = None,
                 index_type: str = 'flat',
                 train_embedder: bool = True,
                 embedder_epochs: int = 10):
        self.dataset_name = dataset_name
        self.max_documents = max_documents
        self.max_queries = max_queries
        self.n_topics = n_topics
        self.k_values = k_values or DEFAULT_K_VALUES
        self.index_type = index_type
        self.train_embedder = train_embedder
        self.embedder_epochs = embedder_epochs


class EvaluationPipeline:
    """
    Comprehensive evaluation pipeline for Topic-Enhanced RAG.
    """

    def __init__(self, output_dir: str = RESULTS_DIR):
        self.output_dir = output_dir
        self.dataset_loader = DatasetLoader()
        self.statistical_analyzer = StatisticalAnalyzer()
        self.visualization_manager = VisualizationManager()

        os.makedirs(output_dir, exist_ok=True)
        os.makedirs(os.path.join(output_dir, "experiments"), exist_ok=True)
        os.makedirs(os.path.join(output_dir, "comparisons"), exist_ok=True)

    def run_single_experiment(self, config: ExperimentConfig) -> Dict[str, Any]:
        """Run a single experiment with the given configuration."""
        logger.info(f"Starting experiment for dataset: {config.dataset_name}")
        start_time = time.time()

        documents, queries = self._load_dataset(config.dataset_name, config.max_documents, config.max_queries)

        if not documents or not queries:
            logger.error(f"Failed to load dataset: {config.dataset_name}")
            return {"error": f"Failed to load dataset: {config.dataset_name}"}

        logger.info("Processing documents...")
        processor = DocumentProcessor(n_topics=config.n_topics)
        corpus_data = processor.process_corpus(documents)

        embedder_model = None
        if config.train_embedder:
            logger.info("Training topic embedder...")
            embedder_model = train_topic_embedder(corpus_data, epochs=config.embedder_epochs)

        logger.info("Initializing retrievers...")
        standard_retriever = StandardRAGRetriever(corpus_data)
        enhanced_retriever = TopicEnhancedRAGRetriever(corpus_data)

        evaluator = RAGEvaluator()

        logger.info(f"Evaluating on {len(queries)} queries...")
        results = self._evaluate_retrievers(
            standard_retriever, enhanced_retriever, evaluator, queries, config.k_values
        )

        results['statistics'] = self.statistical_analyzer.calculate_comparison_statistics(
            results['standard_rag']['individual_results'],
            results['enhanced_rag']['individual_results']
        )

        results['experiment_info'] = {
            'dataset_name': config.dataset_name,
            'num_documents': len(documents),
            'num_queries': len(queries),
            'n_topics': config.n_topics,
            'k_values': config.k_values,
            'index_type': config.index_type,
            'train_embedder': config.train_embedder,
            'embedder_epochs': config.embedder_epochs,
            'execution_time': time.time() - start_time,
            'topics': corpus_data['topics'][:5]
        }

        self._save_experiment_results(config.dataset_name, results)

        logger.info(f"Experiment completed in {time.time() - start_time:.2f} seconds")
        return results

    def run_multiple_experiments(self, configs: List[ExperimentConfig]) -> Dict[str, Any]:
        """Run multiple experiments sequentially."""
        logger.info(f"Starting {len(configs)} experiments")

        all_results = {}
        for config in configs:
            experiment_results = self.run_single_experiment(config)
            all_results[config.dataset_name] = experiment_results

        comparison_results = self._generate_cross_dataset_comparison(all_results)
        self._save_comparison_results(all_results, comparison_results)

        return {
            'individual_experiments': all_results,
            'comparison': comparison_results
        }

    def run_ablation_study(self, base_config: ExperimentConfig) -> Dict[str, Any]:
        """Run ablation study to understand the impact of different components."""
        logger.info("Starting ablation study")

        ablation_configs = [
            ExperimentConfig(
                dataset_name=base_config.dataset_name,
                max_documents=base_config.max_documents,
                max_queries=base_config.max_queries,
                n_topics=base_config.n_topics,
                train_embedder=True,
                embedder_epochs=base_config.embedder_epochs
            ),
            ExperimentConfig(
                dataset_name=base_config.dataset_name,
                max_documents=base_config.max_documents,
                max_queries=base_config.max_queries,
                n_topics=base_config.n_topics,
                train_embedder=False
            ),
            ExperimentConfig(
                dataset_name=base_config.dataset_name,
                max_documents=base_config.max_documents,
                max_queries=base_config.max_queries,
                n_topics=5,
                train_embedder=True,
                embedder_epochs=base_config.embedder_epochs
            ),
            ExperimentConfig(
                dataset_name=base_config.dataset_name,
                max_documents=base_config.max_documents,
                max_queries=base_config.max_queries,
                n_topics=20,
                train_embedder=True,
                embedder_epochs=base_config.embedder_epochs
            )
        ]

        config_names = ['full_model', 'no_embedder_training', 'topics_5', 'topics_20']

        ablation_results = {}
        for config_name, config in zip(config_names, ablation_configs):
            logger.info(f"Running ablation: {config_name}")
            ablation_results[config_name] = self.run_single_experiment(config)

        ablation_analysis = self._analyze_ablation_results(ablation_results)
        self._save_ablation_results(ablation_results, ablation_analysis)

        return {
            'ablation_experiments': ablation_results,
            'analysis': ablation_analysis
        }

    def _load_dataset(self, dataset_name, max_documents, max_queries):
        loaders = {
            'ms_marco': self.dataset_loader.load_ms_marco,
            'natural_questions': self.dataset_loader.load_natural_questions,
            'squad_v2': self.dataset_loader.load_squad_v2,
            'hotpot_qa': self.dataset_loader.load_hotpot_qa,
            'triviaqa': self.dataset_loader.load_trivia_qa,
        }
        loader = loaders.get(dataset_name)
        if loader:
            return loader(max_samples=max_documents)
        logger.error(f"Unknown dataset: {dataset_name}")
        return [], []

    def _evaluate_retrievers(self, standard_retriever, enhanced_retriever, evaluator, queries, k_values):
        standard_results = []
        enhanced_results = []

        empty_metrics = {f'{m}@{k}': 0.0 for m in ['recall', 'precision', 'hit_rate'] for k in k_values}
        empty_metrics.update({'mrr': 0.0, 'ndcg': 0.0})

        for query_data in queries:
            query = query_data['query']
            relevant_docs = query_data['relevant_docs']

            try:
                std_retrieved = standard_retriever.retrieve(query, k=max(k_values))
                std_metrics = evaluator.evaluate_retrieval(std_retrieved, relevant_docs, k_values)
                standard_results.append(std_metrics)
            except Exception as e:
                logger.error(f"Error in standard retrieval: {e}")
                standard_results.append(empty_metrics.copy())

            try:
                enh_retrieved = enhanced_retriever.retrieve(query, k=max(k_values))
                enh_metrics = evaluator.evaluate_retrieval(enh_retrieved, relevant_docs, k_values)
                enhanced_results.append(enh_metrics)
            except Exception as e:
                logger.error(f"Error in enhanced retrieval: {e}")
                enhanced_results.append(empty_metrics.copy())

        def average_metrics(results_list):
            if not results_list:
                return {}
            avg = {}
            for key in results_list[0].keys():
                avg[key] = np.mean([r.get(key, 0.0) for r in results_list])
            return avg

        return {
            'standard_rag': {
                'individual_results': standard_results,
                'avg_metrics': average_metrics(standard_results)
            },
            'enhanced_rag': {
                'individual_results': enhanced_results,
                'avg_metrics': average_metrics(enhanced_results)
            }
        }

    def _generate_cross_dataset_comparison(self, all_results):
        comparison = {
            'dataset_summaries': {},
            'overall_improvements': {},
            'statistical_significance': {}
        }

        for dataset_name, results in all_results.items():
            if 'error' in results:
                continue

            std_metrics = results['standard_rag']['avg_metrics']
            enh_metrics = results['enhanced_rag']['avg_metrics']

            improvements = {}
            for metric in std_metrics:
                if std_metrics[metric] > 0:
                    improvements[metric] = (enh_metrics[metric] - std_metrics[metric]) / std_metrics[metric] * 100
                else:
                    improvements[metric] = 0.0

            comparison['dataset_summaries'][dataset_name] = {
                'standard_metrics': std_metrics,
                'enhanced_metrics': enh_metrics,
                'improvements': improvements,
                'statistical_significance': results.get('statistics', {}).get('significance_tests', {})
            }

        if comparison['dataset_summaries']:
            all_improvements = {}
            for dataset_results in comparison['dataset_summaries'].values():
                for metric, improvement in dataset_results['improvements'].items():
                    all_improvements.setdefault(metric, []).append(improvement)

            for metric, improvements in all_improvements.items():
                comparison['overall_improvements'][metric] = {
                    'mean': np.mean(improvements),
                    'std': np.std(improvements),
                    'min': np.min(improvements),
                    'max': np.max(improvements)
                }

        return comparison

    def _analyze_ablation_results(self, ablation_results):
        analysis = {
            'component_importance': {},
            'optimal_configuration': {},
            'recommendations': []
        }

        full_model_metrics = ablation_results.get('full_model', {}).get('enhanced_rag', {}).get('avg_metrics', {})

        for config_name, results in ablation_results.items():
            if config_name == 'full_model' or 'error' in results:
                continue
            config_metrics = results.get('enhanced_rag', {}).get('avg_metrics', {})
            differences = {
                m: full_model_metrics[m] - config_metrics.get(m, 0)
                for m in full_model_metrics if m in config_metrics
            }
            analysis['component_importance'][config_name] = differences

        if analysis['component_importance']:
            analysis['recommendations'] = [
                "Use embedder training for better performance",
                "Optimal number of topics depends on dataset size",
                "HNSW index provides better scalability for large datasets"
            ]

        return analysis

    def _convert_numpy(self, obj):
        if isinstance(obj, np.bool_):
            return bool(obj)
        elif isinstance(obj, np.integer):
            return int(obj)
        elif isinstance(obj, np.floating):
            return float(obj) if not np.isnan(obj) and not np.isinf(obj) else None
        elif isinstance(obj, np.ndarray):
            return obj.tolist()
        elif isinstance(obj, dict):
            return {k: self._convert_numpy(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [self._convert_numpy(i) for i in obj]
        elif isinstance(obj, float) and (obj != obj or obj == float('inf') or obj == float('-inf')):
            return None
        return obj

    def _save_experiment_results(self, dataset_name, results):
        filepath = os.path.join(self.output_dir, "experiments", f"{dataset_name}_experiment_results.json")
        with open(filepath, 'w') as f:
            json.dump(self._convert_numpy(results), f, indent=2)
        logger.info(f"Saved experiment results to {filepath}")

    def _save_comparison_results(self, all_results, comparison):
        filepath = os.path.join(self.output_dir, "comparisons", "cross_dataset_comparison.json")
        combined = {
            'individual_experiments': all_results,
            'cross_dataset_comparison': comparison,
            'timestamp': time.time()
        }
        with open(filepath, 'w') as f:
            json.dump(self._convert_numpy(combined), f, indent=2)
        logger.info(f"Saved comparison results to {filepath}")

    def _save_ablation_results(self, ablation_results, analysis):
        filepath = os.path.join(self.output_dir, "comparisons", "ablation_study_results.json")
        combined = {
            'ablation_experiments': ablation_results,
            'analysis': analysis,
            'timestamp': time.time()
        }
        with open(filepath, 'w') as f:
            json.dump(self._convert_numpy(combined), f, indent=2)
        logger.info(f"Saved ablation results to {filepath}")


def create_default_experiment_configs() -> List[ExperimentConfig]:
    """Create default experiment configurations for all supported datasets."""
    return [
        ExperimentConfig(
            dataset_name=dataset_name,
            max_documents=1000,
            max_queries=100,
            n_topics=DEFAULT_N_TOPICS,
            k_values=DEFAULT_K_VALUES,
            train_embedder=True,
            embedder_epochs=5
        )
        for dataset_name in SUPPORTED_DATASETS
    ]
