"""Cairn.info XML converter."""

__version__ = "0.6.13"
