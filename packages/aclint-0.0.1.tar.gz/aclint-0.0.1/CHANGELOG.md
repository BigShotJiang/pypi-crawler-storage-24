# Changelog

## 0.0.1 (2026-03-19)


### Chores

* add Claude Code hook settings ([ec2ae04](https://github.com/falcon0387/aclint/commit/ec2ae044db104fe89fa4220632ff66ba5c111327))
* add project dependencies ([9ac0c9a](https://github.com/falcon0387/aclint/commit/9ac0c9a3e52f0714a2aa4eb546d85c884972fdc6))
* remove old test_package.py (moved to tests/aclint/) ([55a1547](https://github.com/falcon0387/aclint/commit/55a15472ad701980e3dc6b587080cc497f0ec190))
* set release-as 0.0.1 for initial release ([d50ce4f](https://github.com/falcon0387/aclint/commit/d50ce4f9cae03fc37791b6efc0d209504a14c6bf))
* update default report description to "Fix all issues at once." ([2155235](https://github.com/falcon0387/aclint/commit/2155235007324f59e8d0343e702d197d85f47913))


### Features

* add CLI entrypoint ([4934ee2](https://github.com/falcon0387/aclint/commit/4934ee201d18f678b86b9760315005efa754fa9d))
* add config loading and schema validation ([efc37b1](https://github.com/falcon0387/aclint/commit/efc37b1e4947ac074ea4b032011a2ece7463b514))
* add core domain models and utilities ([74d65f6](https://github.com/falcon0387/aclint/commit/74d65f6978c8b72fa3d251455b928804891b811f))
* add execution planning and command running ([aa0e3b5](https://github.com/falcon0387/aclint/commit/aa0e3b529a007ae54ea79e8a2b00736efb08f8e0))
* add hook payload I/O and target resolution ([1cf0c4e](https://github.com/falcon0387/aclint/commit/1cf0c4eca662e57c114b65956f4e73365884be33))
* add report rendering ([45fca6c](https://github.com/falcon0387/aclint/commit/45fca6c67427462109d1caefdfbde5050d001add))


### Fixes

* revert to name-based jsonpath for uv.lock ([a8b316f](https://github.com/falcon0387/aclint/commit/a8b316f8a67ad06c2f978de78f4749ef97d9a86f))
* sync uv.lock version via release-please extra-files ([267e0e5](https://github.com/falcon0387/aclint/commit/267e0e5779b6218a71cef6830fe9832940bf12ec))
* use short-circuit jsonpath filter for uv.lock ([2975bed](https://github.com/falcon0387/aclint/commit/2975bed3096e40d87f7e8855b8510fbdc283529a))


### Refactoring

* use editable source filter for uv.lock jsonpath ([11ac9dc](https://github.com/falcon0387/aclint/commit/11ac9dcec4a87603ec50270f9e819885afed6d80))
