"""Tests for aclint."""
