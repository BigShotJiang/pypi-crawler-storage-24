"""Tests that mirror the `aclint` package structure."""
