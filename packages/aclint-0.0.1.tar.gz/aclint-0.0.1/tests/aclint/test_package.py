from __future__ import annotations

import aclint


def test_package_exports_public_api() -> None:
    assert aclint.__doc__ is not None
    assert callable(aclint.main)
