"""Tests for `aclint.execution`."""
