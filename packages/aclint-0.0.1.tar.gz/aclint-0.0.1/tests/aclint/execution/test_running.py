from __future__ import annotations

from pathlib import Path

import anyio
from aclint.core.model import ExecResult, ExecStatus, FixPolicy, Outcome, Phase, Status
from aclint.execution.running import (
    classify_exec_result,
    is_missing_binary_hint,
    run,
    run_in_parallel,
    run_once,
    run_until_stable,
)

from tests.aclint.testing import (
    FixedRunner,
    MappingRunner,
    StableRunner,
    UnavailableRunner,
    build_rule,
    build_settings,
    build_target,
    build_task,
)

# ---------------------------------------------------------------------------
# classify_exec_result
# ---------------------------------------------------------------------------


def test_classify_succeeded_returns_passed() -> None:
    result = ExecResult(status=ExecStatus.SUCCEEDED, output="", duration_seconds=0.01, exit_code=0)
    assert classify_exec_result(result) is Status.PASSED


def test_classify_failed_returns_failed() -> None:
    result = ExecResult(
        status=ExecStatus.FAILED, output="error", duration_seconds=0.01, exit_code=1
    )
    assert classify_exec_result(result) is Status.FAILED


def test_classify_timed_out_returns_failed() -> None:
    result = ExecResult(status=ExecStatus.TIMED_OUT, output="timeout", duration_seconds=5.0)
    assert classify_exec_result(result) is Status.FAILED


def test_classify_missing_binary_returns_warning() -> None:
    result = ExecResult(status=ExecStatus.MISSING_BINARY, output="not found", duration_seconds=0.0)
    assert classify_exec_result(result) is Status.WARNING


def test_classify_os_error_returns_failed() -> None:
    result = ExecResult(status=ExecStatus.OS_ERROR, output="OS error", duration_seconds=0.0)
    assert classify_exec_result(result) is Status.FAILED


def test_classify_failed_with_missing_binary_hint_returns_warning() -> None:
    result = ExecResult(
        status=ExecStatus.FAILED,
        output="tool: command not found",
        duration_seconds=0.01,
        exit_code=1,
    )
    assert classify_exec_result(result) is Status.WARNING


# ---------------------------------------------------------------------------
# is_missing_binary_hint
# ---------------------------------------------------------------------------


def test_missing_binary_hint_detects_command_not_found() -> None:
    assert is_missing_binary_hint("tool: command not found") is True


def test_missing_binary_hint_detects_cannot_find_module() -> None:
    assert is_missing_binary_hint("Error: Cannot find module 'foo'") is True


def test_missing_binary_hint_detects_not_recognized() -> None:
    assert is_missing_binary_hint("'tool' is not recognized as an internal command") is True


def test_missing_binary_hint_rejects_normal_error() -> None:
    assert is_missing_binary_hint("SyntaxError: unexpected token") is False


# ---------------------------------------------------------------------------
# run_once
# ---------------------------------------------------------------------------


def test_run_once_passed() -> None:
    command = build_task("lint", argv=("ruff", "check", "demo.py"))
    runner = FixedRunner(
        ExecResult(status=ExecStatus.SUCCEEDED, output="", duration_seconds=0.01, exit_code=0)
    )
    outcome = anyio.run(run_once, command, runner)
    assert outcome.status is Status.PASSED


def test_run_once_failed() -> None:
    command = build_task("lint", argv=("ruff", "check", "demo.py"))
    runner = FixedRunner(
        ExecResult(status=ExecStatus.FAILED, output="error", duration_seconds=0.01, exit_code=1)
    )
    outcome = anyio.run(run_once, command, runner)
    assert outcome.status is Status.FAILED


def test_run_once_warning_when_binary_unavailable() -> None:
    command = build_task("lint", argv=("ruff", "check", "demo.py"))
    runner = UnavailableRunner()
    outcome = anyio.run(run_once, command, runner)
    assert outcome.status is Status.WARNING


# ---------------------------------------------------------------------------
# run_until_stable
# ---------------------------------------------------------------------------


def test_run_until_stable_stops_when_file_unchanged(tmp_path: Path) -> None:
    target_file = tmp_path / "demo.py"
    target_file.write_text("print('x')\n", encoding="utf-8")
    command = build_task(
        "format",
        phase=Phase.FIX,
        argv=("ruff", "format", "demo.py"),
        repeat_until_stable=True,
        max_stable_passes=5,
    )
    runner = FixedRunner(
        ExecResult(status=ExecStatus.SUCCEEDED, output="", duration_seconds=0.01, exit_code=0)
    )
    outcome = anyio.run(run_until_stable, command, runner, target_file)
    assert outcome.status is Status.PASSED


def test_run_until_stable_retries_on_file_change(tmp_path: Path) -> None:
    target_file = tmp_path / "demo.py"
    target_file.write_text("print('x')\n", encoding="utf-8")
    command = build_task(
        "format",
        phase=Phase.FIX,
        argv=("ruff", "format", "demo.py"),
        repeat_until_stable=True,
        max_stable_passes=5,
    )
    runner = StableRunner(target_file)
    outcome = anyio.run(run_until_stable, command, runner, target_file)
    assert outcome.status is Status.PASSED
    assert runner.run_call_count == 2


def test_run_until_stable_stops_on_failure() -> None:
    command = build_task(
        "format",
        phase=Phase.FIX,
        argv=("ruff", "format", "demo.py"),
        repeat_until_stable=True,
        max_stable_passes=5,
    )
    runner = FixedRunner(
        ExecResult(status=ExecStatus.FAILED, output="error", duration_seconds=0.01, exit_code=1)
    )

    async def _run() -> Status:
        outcome = await run_until_stable(command, runner, Path("/fake"), file_hash=lambda _: "aaa")
        return outcome.status

    assert anyio.run(_run) is Status.FAILED


def test_run_until_stable_stops_at_max_passes() -> None:
    command = build_task(
        "format",
        phase=Phase.FIX,
        argv=("ruff", "format", "demo.py"),
        repeat_until_stable=True,
        max_stable_passes=3,
    )
    runner = FixedRunner(
        ExecResult(status=ExecStatus.SUCCEEDED, output="", duration_seconds=0.01, exit_code=0)
    )
    counter = 0

    def always_changing_hash(_path: object) -> str:
        nonlocal counter
        counter += 1
        return str(counter)

    async def _run() -> Status:
        outcome = await run_until_stable(
            command, runner, Path("/fake"), file_hash=always_changing_hash
        )
        return outcome.status

    assert anyio.run(_run) is Status.PASSED


# ---------------------------------------------------------------------------
# run_in_parallel
# ---------------------------------------------------------------------------


def test_run_in_parallel_empty_commands() -> None:
    runner = FixedRunner(
        ExecResult(status=ExecStatus.SUCCEEDED, output="", duration_seconds=0.01, exit_code=0)
    )

    async def _run() -> tuple[Outcome, ...]:
        return await run_in_parallel((), parallel=3, runner=runner)

    assert anyio.run(_run) == ()


def test_run_in_parallel_preserves_order() -> None:
    commands = (
        build_task("a", argv=("cmd-a",)),
        build_task("b", argv=("cmd-b",)),
        build_task("c", argv=("cmd-c",)),
    )
    runner = FixedRunner(
        ExecResult(status=ExecStatus.SUCCEEDED, output="", duration_seconds=0.01, exit_code=0)
    )

    async def _run() -> list[str]:
        outcomes = await run_in_parallel(commands, parallel=2, runner=runner)
        return [o.command.key for o in outcomes]

    assert anyio.run(_run) == ["a", "b", "c"]


# ---------------------------------------------------------------------------
# run (integration with direct construction)
# ---------------------------------------------------------------------------


def test_run_skips_check_when_fix_fails_with_skip_policy(tmp_path: Path) -> None:
    project_root = tmp_path / "project"
    project_root.mkdir()
    target_file = project_root / "demo.py"
    target_file.write_text("print('x')\n", encoding="utf-8")

    target = build_target(project_root=project_root.resolve(), file_path=target_file.resolve())
    settings = build_settings(
        on_error=FixPolicy.SKIP_CHECK,
        rules=(
            build_rule(
                "formatter",
                phase=Phase.FIX,
                glob=("*.py",),
                argv=("uv", "run", "formatter", "{file}"),
            ),
            build_rule(
                "ruff-check",
                phase=Phase.CHECK,
                glob=("*.py",),
                argv=("uv", "run", "ruff", "check", "{file}"),
            ),
        ),
    )
    runner = MappingRunner(
        {
            ("uv", "run", "formatter", "demo.py"): ExecResult(
                status=ExecStatus.FAILED,
                output="Formatter crashed",
                duration_seconds=0.01,
                exit_code=2,
            ),
        }
    )

    summary = anyio.run(run, target, settings, runner)

    assert [outcome.status for outcome in summary.outcomes] == [Status.FAILED]
    assert runner.seen_argv == [("uv", "run", "formatter", "demo.py")]


def test_run_classifies_nested_missing_binary_as_warning(tmp_path: Path) -> None:
    project_root = tmp_path / "project"
    project_root.mkdir()
    target_file = project_root / "demo.py"
    target_file.write_text("print('x')\n", encoding="utf-8")

    target = build_target(project_root=project_root.resolve(), file_path=target_file.resolve())
    settings = build_settings(
        rules=(
            build_rule(
                "wrapper",
                phase=Phase.CHECK,
                glob=("*.py",),
                argv=("uv", "run", "wrapper", "{file}"),
            ),
        ),
    )
    runner = MappingRunner(
        {
            ("uv", "run", "wrapper", "demo.py"): ExecResult(
                status=ExecStatus.FAILED,
                output="tool: command not found",
                duration_seconds=0.01,
                exit_code=1,
            ),
        }
    )

    summary = anyio.run(run, target, settings, runner)

    assert summary.outcomes[0].status is Status.WARNING
