from __future__ import annotations

from pathlib import Path

from aclint.core.model import CwdMode, Phase
from aclint.execution.planning import expand_argv, plan, resolve_cwd, rule_matches_target

from tests.aclint.testing import build_rule, build_settings, build_target

# ---------------------------------------------------------------------------
# resolve_cwd
# ---------------------------------------------------------------------------


def test_resolve_cwd_project_root() -> None:
    result = resolve_cwd(CwdMode.PROJECT_ROOT, Path("/project"), Path("/project/src/app.py"))
    assert result == Path("/project")


def test_resolve_cwd_file_dir() -> None:
    result = resolve_cwd(CwdMode.FILE_DIR, Path("/project"), Path("/project/src/app.py"))
    assert result == Path("/project/src")


# ---------------------------------------------------------------------------
# expand_argv
# ---------------------------------------------------------------------------


def test_expand_argv_file_token() -> None:
    result = expand_argv(
        argv=("ruff", "check", "{file}"),
        project_root=Path("/project"),
        file_path=Path("/project/src/app.py"),
        cwd=Path("/project"),
    )
    assert result == ("ruff", "check", "src/app.py")


def test_expand_argv_absolute_file_token() -> None:
    result = expand_argv(
        argv=("tool", "{absolute_file}"),
        project_root=Path("/project"),
        file_path=Path("/project/src/app.py"),
        cwd=Path("/project"),
    )
    assert result == ("tool", "/project/src/app.py")


def test_expand_argv_project_root_token() -> None:
    result = expand_argv(
        argv=("tool", "--root", "{project_root}"),
        project_root=Path("/project"),
        file_path=Path("/project/src/app.py"),
        cwd=Path("/project"),
    )
    assert result == ("tool", "--root", "/project")


def test_expand_argv_preserves_plain_args() -> None:
    result = expand_argv(
        argv=("ruff", "check", "--fix"),
        project_root=Path("/project"),
        file_path=Path("/project/src/app.py"),
        cwd=Path("/project"),
    )
    assert result == ("ruff", "check", "--fix")


# ---------------------------------------------------------------------------
# rule_matches_target
# ---------------------------------------------------------------------------


def test_rule_matches_basename_glob() -> None:
    rule = build_rule(glob=("*.py",))
    target = build_target(project_root=Path("/project"), file_path=Path("/project/src/pkg/mod.py"))
    assert rule_matches_target(rule, target) is True


def test_rule_matches_globstar_pattern() -> None:
    rule = build_rule(glob=("**/*.py",))
    target = build_target(project_root=Path("/project"), file_path=Path("/project/a/b/c.py"))
    assert rule_matches_target(rule, target) is True


def test_rule_excludes_pattern() -> None:
    rule = build_rule(glob=("*.py",), exclude=("generated/**",))
    target = build_target(
        project_root=Path("/project"), file_path=Path("/project/generated/out.py")
    )
    assert rule_matches_target(rule, target) is False


def test_rule_rejects_non_matching_extension() -> None:
    rule = build_rule(glob=("*.py",))
    target = build_target(project_root=Path("/project"), file_path=Path("/project/readme.md"))
    assert rule_matches_target(rule, target) is False


# ---------------------------------------------------------------------------
# plan
# ---------------------------------------------------------------------------


def test_plan_excludes_disabled_rules() -> None:
    target = build_target()
    settings = build_settings(
        rules=(
            build_rule("enabled-lint", glob=("*.py",), argv=("ruff", "check", "{file}")),
            build_rule("disabled-lint", glob=("*.py",), argv=("mypy", "{file}"), enabled=False),
        ),
    )
    execution_plan = plan(target, settings)
    assert len(execution_plan.check_commands) == 1
    assert execution_plan.check_commands[0].key == "enabled-lint"


def test_plan_separates_fix_and_check_phases() -> None:
    target = build_target()
    settings = build_settings(
        rules=(
            build_rule(
                "formatter", phase=Phase.FIX, glob=("*.py",), argv=("ruff", "format", "{file}")
            ),
            build_rule(
                "linter", phase=Phase.CHECK, glob=("*.py",), argv=("ruff", "check", "{file}")
            ),
        ),
    )
    execution_plan = plan(target, settings)
    assert len(execution_plan.fix_commands) == 1
    assert execution_plan.fix_commands[0].key == "formatter"
    assert len(execution_plan.check_commands) == 1
    assert execution_plan.check_commands[0].key == "linter"


def test_plan_applies_settings_defaults() -> None:
    target = build_target()
    settings = build_settings(
        rules=(build_rule("lint", glob=("*.py",), argv=("ruff", "check", "{file}")),),
    )
    execution_plan = plan(target, settings)
    task = execution_plan.check_commands[0]
    assert task.timeout_seconds == settings.defaults.timeout_seconds
    assert task.output_chars_limit == settings.defaults.output_chars_limit
