from __future__ import annotations

from dataclasses import replace
from pathlib import Path
from textwrap import dedent

from aclint.core.model import Phase, ReportSectionConfig, Status
from aclint.reporting.rendering import render_report

from tests.aclint.testing import build_outcome, build_settings, build_summary


def test_render_report_groups_fix_failures_warnings_and_check_failures() -> None:
    summary = build_summary(
        build_outcome(
            "formatter",
            status=Status.FAILED,
            output="Parse error\n",
            phase=Phase.FIX,
        ),
        build_outcome(
            "wrapper",
            status=Status.WARNING,
            output="tool: command not found\n",
        ),
        build_outcome("ruff-check", output="All good\n"),
        build_outcome("mypy", status=Status.FAILED, output="type error in main.py"),
    )

    result = render_report(summary, build_settings())

    assert result == dedent("""\
        # ACLint Report

        Fix all issues at once.

        ## Fix failures

        - Formatter: Failed

        ## Missing binaries

        - Wrapper: tool: command not found

        ## Check failures

        ### Mypy
        type error in main.py""")


def test_render_report_shows_config_path_before_description() -> None:
    summary = build_summary(
        build_outcome("mypy", status=Status.FAILED, output="type error\n"),
    )

    result = render_report(
        summary, build_settings(), config_path=Path("/home/user/project/aclint.yml")
    )

    assert result == dedent("""\
        # ACLint Report

        Config: `/home/user/project/aclint.yml`

        Fix all issues at once.

        ## Check failures

        ### Mypy
        type error""")


def test_render_report_hides_config_path_when_show_config_path_is_false() -> None:
    settings = build_settings()
    settings = replace(
        settings,
        report=replace(settings.report, show_config_path=False),
    )
    summary = build_summary(
        build_outcome("mypy", status=Status.FAILED, output="type error\n"),
    )

    result = render_report(summary, settings, config_path=Path("/home/user/project/aclint.yml"))

    assert result == dedent("""\
        # ACLint Report

        Fix all issues at once.

        ## Check failures

        ### Mypy
        type error""")


def test_render_report_omits_empty_description() -> None:
    settings = build_settings()
    settings = replace(settings, report=replace(settings.report, description=""))
    summary = build_summary(
        build_outcome("mypy", status=Status.FAILED, output="type error\n"),
    )

    result = render_report(summary, settings)

    assert result == dedent("""\
        # ACLint Report

        ## Check failures

        ### Mypy
        type error""")


def test_render_report_fix_failures_verbose_shows_detail() -> None:
    settings = build_settings()
    settings = replace(
        settings,
        report=replace(
            settings.report,
            fix_failures=ReportSectionConfig(heading="Fix failures", verbose=True),
        ),
    )
    summary = build_summary(
        build_outcome(
            "formatter",
            status=Status.FAILED,
            output="Parse error on line 5\n",
            phase=Phase.FIX,
        ),
    )

    result = render_report(summary, settings)

    assert result == dedent("""\
        # ACLint Report

        Fix all issues at once.

        ## Fix failures

        ### Formatter
        Parse error on line 5""")


def test_render_report_check_failures_non_verbose_shows_bullet() -> None:
    settings = build_settings()
    settings = replace(
        settings,
        report=replace(
            settings.report,
            check_failures=ReportSectionConfig(heading="Check failures", verbose=False),
        ),
    )
    summary = build_summary(
        build_outcome("mypy", status=Status.FAILED, output="type error in main.py"),
        build_outcome("ruff-check", status=Status.FAILED, output="E501 line too long"),
    )

    result = render_report(summary, settings)

    assert result == dedent("""\
        # ACLint Report

        Fix all issues at once.

        ## Check failures

        - Mypy: Failed
        - Ruff Check: Failed""")
