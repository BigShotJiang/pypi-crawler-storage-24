"""Tests for `aclint.hook`."""
