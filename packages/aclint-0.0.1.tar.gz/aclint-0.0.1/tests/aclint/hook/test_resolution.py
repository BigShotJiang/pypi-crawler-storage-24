from __future__ import annotations

from typing import TYPE_CHECKING

from aclint.core.error import AppError, ErrorCode
from aclint.core.model import Target
from aclint.hook.io import validate_payload
from aclint.hook.resolution import resolve_target

if TYPE_CHECKING:
    from pathlib import Path

    import pytest

from tests.aclint.testing import assert_failure, build_hook_payload


def test_resolve_target_resolves_with_explicit_cwd(tmp_path: Path) -> None:
    project_root = tmp_path / "project"
    project_root.mkdir()
    target_file = project_root / "demo.py"
    target_file.write_text("print('x')\n", encoding="utf-8")

    target = resolve_target(build_hook_payload("demo.py", cwd=project_root)).unwrap()

    assert target == Target(project_root.resolve(), target_file.resolve())


def test_resolve_target_uses_current_directory_when_payload_has_no_cwd(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    project_root = tmp_path / "project"
    project_root.mkdir()
    target_file = project_root / "demo.py"
    target_file.write_text("print('x')\n", encoding="utf-8")
    monkeypatch.chdir(project_root)

    target = resolve_target(build_hook_payload("demo.py")).unwrap()

    assert target == Target(project_root.resolve(), target_file.resolve())


def test_resolve_target_rejects_outside_project(tmp_path: Path) -> None:
    project_root = tmp_path / "project"
    project_root.mkdir()
    outside_file = tmp_path / "outside.py"
    outside_file.write_text("print('x')\n", encoding="utf-8")

    result = resolve_target(build_hook_payload("../outside.py", cwd=project_root))

    assert_failure(
        result,
        AppError(ErrorCode.TARGET_FILE, "File path outside project: ../outside.py"),
    )


def test_validate_payload_rejects_missing_file_path() -> None:
    result = validate_payload({"tool_input": {}})

    assert_failure(
        result,
        AppError(ErrorCode.PAYLOAD_VALIDATION, "No file path provided"),
    )
