from __future__ import annotations

from aclint.core.model import JsonObject, ReportMode, Status
from aclint.hook.io import block_response, response, summary_response

from tests.aclint.testing import build_outcome, build_report, build_settings, build_summary

# ---------------------------------------------------------------------------
# block_response
# ---------------------------------------------------------------------------


def test_block_response_sets_decision_block() -> None:
    result = block_response("Something failed")
    assert result["decision"] == "block"
    assert result["reason"] == "Something failed"


# ---------------------------------------------------------------------------
# response
# ---------------------------------------------------------------------------


def test_response_without_decision_uses_additional_context() -> None:
    result = response(None, "info message")
    assert "decision" not in result
    hook_output: JsonObject = result["hookSpecificOutput"]  # type: ignore[assignment]
    assert hook_output["additionalContext"] == "info message"


def test_response_with_decision_uses_reason() -> None:
    result = response("block", "blocked message")
    assert result["decision"] == "block"
    assert result["reason"] == "blocked message"


def test_response_includes_metadata() -> None:
    result = response(None, "msg", errors=2, executed=5)
    hook_output: JsonObject = result["hookSpecificOutput"]  # type: ignore[assignment]
    assert hook_output["errors"] == 2
    assert hook_output["executed"] == 5


# ---------------------------------------------------------------------------
# summary_response
# ---------------------------------------------------------------------------


def test_summary_response_returns_none_when_all_passed() -> None:
    summary = build_summary(
        build_outcome("a", status=Status.PASSED),
        build_outcome("b", status=Status.PASSED),
    )
    settings = build_settings()
    assert summary_response(summary, settings) is None


def test_summary_response_blocks_in_block_mode() -> None:
    summary = build_summary(
        build_outcome("lint", status=Status.FAILED, output="error\n"),
    )
    settings = build_settings(report=build_report(mode=ReportMode.BLOCK))
    result = summary_response(summary, settings)
    assert result is not None
    assert result["decision"] == "block"


def test_summary_response_uses_context_in_context_mode() -> None:
    summary = build_summary(
        build_outcome("lint", status=Status.FAILED, output="error\n"),
    )
    settings = build_settings(report=build_report(mode=ReportMode.CONTEXT))
    result = summary_response(summary, settings)
    assert result is not None
    assert "decision" not in result
    hook_output: JsonObject = result["hookSpecificOutput"]  # type: ignore[assignment]
    assert "additionalContext" in hook_output
