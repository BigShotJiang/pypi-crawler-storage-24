from __future__ import annotations

import json
from pathlib import Path
from typing import TYPE_CHECKING

import yaml
from aclint.core.model import (
    CwdMode,
    Defaults,
    ExecResult,
    ExecStatus,
    FixPolicy,
    Outcome,
    Phase,
    Report,
    ReportMode,
    ReportSectionConfig,
    Rule,
    Settings,
    Status,
    Summary,
    Target,
    Task,
)
from returns.result import Failure, Result

if TYPE_CHECKING:
    from collections.abc import Callable

    from aclint.core.model import JsonObject


# ---------------------------------------------------------------------------
# Config helpers
# ---------------------------------------------------------------------------


def write_config(path: Path, data: object) -> None:
    """Write a YAML config file from a Python object."""
    path.write_text(yaml.dump(data, sort_keys=False), encoding="utf-8")


# ---------------------------------------------------------------------------
# Hook payload helpers
# ---------------------------------------------------------------------------


def build_hook_payload(file_path: str, *, cwd: Path | None = None) -> JsonObject:
    """Build a hook payload."""
    payload: JsonObject = {"tool_input": {"file_path": file_path}}
    if cwd is not None:
        payload["cwd"] = str(cwd)
    return payload


def dump_hook_payload(file_path: str, *, cwd: Path | None = None) -> str:
    """Build a JSON hook payload."""
    return json.dumps(build_hook_payload(file_path, cwd=cwd))


# ---------------------------------------------------------------------------
# Assertion helpers
# ---------------------------------------------------------------------------


def assert_failure[E](
    result: Result[object, E],
    expected: E,
) -> None:
    """Assert that a result is a failure with the expected error."""
    assert result == Failure(expected)


# ---------------------------------------------------------------------------
# Runner stubs
# ---------------------------------------------------------------------------


class FixedRunner:
    """Return the same ExecResult for every command."""

    def __init__(self, result: ExecResult) -> None:
        self._result = result

    @staticmethod
    def is_available(binary: str) -> bool:  # noqa: ARG004
        return True

    async def run(
        self,
        argv: tuple[str, ...],
        cwd: Path,
        timeout_seconds: float,
        output_chars_limit: int,
    ) -> ExecResult:
        return self._result


class MappingRunner:
    """Return ExecResult based on argv lookup, recording seen commands."""

    def __init__(self, outputs: dict[tuple[str, ...], ExecResult]) -> None:
        self._outputs = outputs
        self.seen_argv: list[tuple[str, ...]] = []

    @staticmethod
    def is_available(binary: str) -> bool:  # noqa: ARG004
        return True

    async def run(
        self,
        argv: tuple[str, ...],
        cwd: Path,
        timeout_seconds: float,
        output_chars_limit: int,
    ) -> ExecResult:
        self.seen_argv.append(argv)
        return self._outputs[argv]


class CallbackRunner:
    """Delegate to a callback function for each command."""

    def __init__(self, fn: Callable[[tuple[str, ...]], ExecResult]) -> None:
        self._fn = fn

    @staticmethod
    def is_available(binary: str) -> bool:  # noqa: ARG004
        return True

    async def run(
        self,
        argv: tuple[str, ...],
        cwd: Path,
        timeout_seconds: float,
        output_chars_limit: int,
    ) -> ExecResult:
        return self._fn(argv)


class UnavailableRunner:
    """Runner where is_available() always returns False."""

    @staticmethod
    def is_available(binary: str) -> bool:  # noqa: ARG004
        return False

    async def run(
        self,
        argv: tuple[str, ...],
        cwd: Path,
        timeout_seconds: float,
        output_chars_limit: int,
    ) -> ExecResult:
        msg = "UnavailableRunner.run() should not be called"
        raise AssertionError(msg)


class StableRunner:
    """Mutate the target file on the first pass only, recording call count."""

    def __init__(self, target_file: Path) -> None:
        self._target_file = target_file
        self.run_call_count = 0

    @staticmethod
    def is_available(binary: str) -> bool:  # noqa: ARG004
        return True

    async def run(
        self,
        argv: tuple[str, ...],
        cwd: Path,
        timeout_seconds: float,
        output_chars_limit: int,
    ) -> ExecResult:
        self.run_call_count += 1
        if self.run_call_count == 1:
            self._target_file.write_text("print('formatted')\n", encoding="utf-8")
        return ExecResult(
            status=ExecStatus.SUCCEEDED,
            output="",
            duration_seconds=0.01,
            exit_code=0,
        )


# ---------------------------------------------------------------------------
# Builder helpers
# ---------------------------------------------------------------------------


def build_task(
    key: str = "stub",
    *,
    phase: Phase = Phase.CHECK,
    argv: tuple[str, ...] = ("stub",),
    cwd: Path = Path("/project"),
    timeout_seconds: float = 10.0,
    output_chars_limit: int = 1000,
    repeat_until_stable: bool = False,
    max_stable_passes: int = 5,
) -> Task:
    """Build a Task with sensible defaults."""
    return Task(
        key=key,
        label=key.replace("-", " ").title(),
        argv=argv,
        phase=phase,
        cwd=cwd,
        timeout_seconds=timeout_seconds,
        output_chars_limit=output_chars_limit,
        repeat_until_stable=repeat_until_stable,
        max_stable_passes=max_stable_passes,
    )


def build_rule(
    key: str = "stub",
    *,
    phase: Phase = Phase.CHECK,
    glob: tuple[str, ...] = ("*",),
    exclude: tuple[str, ...] = (),
    argv: tuple[str, ...] = ("stub", "{file}"),
    cwd: CwdMode = CwdMode.PROJECT_ROOT,
    enabled: bool = True,
    repeat_until_stable: bool = False,
    max_stable_passes: int | None = None,
    timeout_seconds: float | None = None,
    output_chars_limit: int | None = None,
) -> Rule:
    """Build a Rule with sensible defaults."""
    return Rule(
        key=key,
        label=key.replace("-", " ").title(),
        argv=argv,
        phase=phase,
        glob=glob,
        exclude=exclude,
        cwd=cwd,
        enabled=enabled,
        repeat_until_stable=repeat_until_stable,
        max_stable_passes=max_stable_passes,
        timeout_seconds=timeout_seconds,
        output_chars_limit=output_chars_limit,
    )


def build_target(
    project_root: Path = Path("/project"),
    file_path: Path = Path("/project/demo.py"),
) -> Target:
    """Build a Target with sensible defaults."""
    return Target(project_root=project_root, file_path=file_path)


def build_defaults(
    timeout_seconds: float = 15.0,
    output_chars_limit: int = 10000,
) -> Defaults:
    """Build Defaults with sensible values."""
    return Defaults(timeout_seconds=timeout_seconds, output_chars_limit=output_chars_limit)


def build_report(
    *,
    mode: ReportMode = ReportMode.CONTEXT,
    title: str = "ACLint Report",
    description: str = "Fix all issues at once.",
    truncation_suffix: str = " ... (truncated)",
    show_config_path: bool = True,
    fix_failures: ReportSectionConfig | None = None,
    missing_binaries: ReportSectionConfig | None = None,
    check_failures: ReportSectionConfig | None = None,
) -> Report:
    """Build a Report with sensible defaults."""
    return Report(
        mode=mode,
        title=title,
        description=description,
        truncation_suffix=truncation_suffix,
        show_config_path=show_config_path,
        fix_failures=fix_failures or ReportSectionConfig(heading="Fix failures", verbose=False),
        missing_binaries=missing_binaries
        or ReportSectionConfig(heading="Missing binaries", verbose=True),
        check_failures=check_failures
        or ReportSectionConfig(heading="Check failures", verbose=True),
    )


def build_settings(
    *,
    rules: tuple[Rule, ...] = (),
    on_error: FixPolicy = FixPolicy.RUN_CHECK,
    parallel: int = 3,
    defaults: Defaults | None = None,
    report: Report | None = None,
) -> Settings:
    """Build Settings with sensible defaults."""
    return Settings(
        on_error=on_error,
        parallel=parallel,
        defaults=defaults or build_defaults(),
        report=report or build_report(),
        rules=rules,
    )


def build_outcome(
    key: str = "stub",
    *,
    status: Status = Status.PASSED,
    output: str = "",
    phase: Phase = Phase.CHECK,
    duration_seconds: float = 0.01,
    exit_code: int | None = None,
) -> Outcome:
    """Build an Outcome with sensible defaults."""
    resolved_exit_code = (
        exit_code if exit_code is not None else (0 if status is Status.PASSED else 1)
    )
    return Outcome(
        status=status,
        command=build_task(key, phase=phase),
        output=output,
        duration_seconds=duration_seconds,
        exit_code=resolved_exit_code,
    )


def build_summary(
    *outcomes: Outcome,
    duration: float = 1.0,
) -> Summary:
    """Build a Summary from outcomes."""
    return Summary(outcomes=outcomes, total_duration_seconds=duration)
