from __future__ import annotations

from aclint.core.model import Phase, Status
from aclint.core.queries import (
    has_failures,
    has_warnings,
    outcomes_for_phase,
    outcomes_with_status,
)

from tests.aclint.testing import build_outcome, build_summary

# ---------------------------------------------------------------------------
# outcomes_with_status
# ---------------------------------------------------------------------------


def test_outcomes_with_status_filters_matching() -> None:
    summary = build_summary(
        build_outcome("a", status=Status.PASSED),
        build_outcome("b", status=Status.FAILED),
        build_outcome("c", status=Status.PASSED),
    )
    result = outcomes_with_status(summary, Status.PASSED)
    assert len(result) == 2
    assert all(o.status is Status.PASSED for o in result)


def test_outcomes_with_status_returns_empty_when_none_match() -> None:
    summary = build_summary(
        build_outcome("a", status=Status.PASSED),
        build_outcome("b", status=Status.PASSED),
    )
    result = outcomes_with_status(summary, Status.FAILED)
    assert result == ()


# ---------------------------------------------------------------------------
# outcomes_for_phase
# ---------------------------------------------------------------------------


def test_outcomes_for_phase_filters_by_phase() -> None:
    summary = build_summary(
        build_outcome("formatter", phase=Phase.FIX),
        build_outcome("linter", phase=Phase.CHECK),
        build_outcome("typechecker", phase=Phase.CHECK),
    )
    result = outcomes_for_phase(summary, Phase.CHECK)
    assert len(result) == 2
    assert all(o.command.phase is Phase.CHECK for o in result)


# ---------------------------------------------------------------------------
# has_failures / has_warnings
# ---------------------------------------------------------------------------


def test_has_failures_true_when_failed_exists() -> None:
    summary = build_summary(
        build_outcome("a", status=Status.PASSED),
        build_outcome("b", status=Status.FAILED),
    )
    assert has_failures(summary) is True


def test_has_failures_false_when_all_passed() -> None:
    summary = build_summary(
        build_outcome("a", status=Status.PASSED),
        build_outcome("b", status=Status.PASSED),
    )
    assert has_failures(summary) is False


def test_has_warnings_true_when_warning_exists() -> None:
    summary = build_summary(
        build_outcome("a", status=Status.PASSED),
        build_outcome("b", status=Status.WARNING),
    )
    assert has_warnings(summary) is True


def test_has_warnings_false_when_no_warnings() -> None:
    summary = build_summary(
        build_outcome("a", status=Status.PASSED),
        build_outcome("b", status=Status.FAILED),
    )
    assert has_warnings(summary) is False
