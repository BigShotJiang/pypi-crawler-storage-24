from __future__ import annotations

from aclint.core.text import truncate_text

SUFFIX = " ... (truncated)"

# ---------------------------------------------------------------------------
# truncate_text
# ---------------------------------------------------------------------------


def test_truncate_returns_original_when_within_limit() -> None:
    assert truncate_text("short", 100, SUFFIX) == "short"


def test_truncate_returns_empty_for_zero_max_chars() -> None:
    result = truncate_text("anything", 0, SUFFIX)
    assert not result


def test_truncate_prefers_newline_boundary() -> None:
    assert truncate_text("first line\nsecond line", 15, SUFFIX) == "first line" + SUFFIX


def test_truncate_prefers_space_boundary() -> None:
    assert truncate_text("alpha beta gamma", 12, SUFFIX) == "alpha beta" + SUFFIX


def test_truncate_hard_cuts_when_no_boundary() -> None:
    assert truncate_text("abcdefghijklmnop", 5, SUFFIX) == "abcde" + SUFFIX


def test_truncate_appends_suffix() -> None:
    result = truncate_text("first line\nsecond line", 15, " [cut]")
    assert result.endswith(" [cut]")
