from __future__ import annotations

import json
from io import StringIO
from typing import TYPE_CHECKING

import pytest
from aclint.cli import main
from aclint.core.model import ExecResult, ExecStatus

if TYPE_CHECKING:
    from pathlib import Path

from tests.aclint.testing import (
    CallbackRunner,
    dump_hook_payload,
    write_config,
)


def _default_result_for_argv(argv: tuple[str, ...]) -> ExecResult:
    if "format" in argv or "--fix" in argv:
        return ExecResult(
            status=ExecStatus.SUCCEEDED,
            output="",
            duration_seconds=0.01,
            exit_code=0,
        )
    return ExecResult(
        status=ExecStatus.FAILED,
        output="Found a type issue",
        duration_seconds=0.01,
        exit_code=1,
    )


def test_main_emits_context_response_for_failed_check(tmp_path: Path) -> None:
    project_root = tmp_path / "project"
    project_root.mkdir()
    (project_root / "demo.py").write_text("print('x')\n", encoding="utf-8")
    config_path = tmp_path / "config.yml"
    write_config(
        config_path,
        {
            "report": {"mode": "context"},
            "check": {
                "commands": {
                    "ruff-check": {"glob": "*.py", "run": "uv run ruff check {file}"},
                },
            },
        },
    )
    stdout_buffer = StringIO()

    exit_code = main(
        ["--config", str(config_path)],
        stdin=StringIO(dump_hook_payload("demo.py", cwd=project_root)),
        stdout=stdout_buffer,
        runner=CallbackRunner(_default_result_for_argv),
    )

    hook_response = json.loads(stdout_buffer.getvalue())

    assert exit_code == 0
    assert "decision" not in hook_response
    assert "Ruff Check" in hook_response["hookSpecificOutput"]["additionalContext"]


@pytest.mark.parametrize(
    "report_mode",
    ["block", None],
    ids=["explicit_block", "omitted_defaults_to_block"],
)
def test_main_blocks_failed_check_in_block_mode(tmp_path: Path, report_mode: str | None) -> None:
    project_root = tmp_path / "project"
    project_root.mkdir()
    (project_root / "demo.py").write_text("print('x')\n", encoding="utf-8")
    config_path = tmp_path / "config.yml"
    config: dict[str, object] = {
        "check": {
            "commands": {
                "ruff-check": {"glob": "*.py", "run": "uv run ruff check {file}"},
            },
        },
    }
    if report_mode is not None:
        config["report"] = {"mode": report_mode}
    write_config(config_path, config)
    stdout_buffer = StringIO()

    exit_code = main(
        ["--config", str(config_path)],
        stdin=StringIO(dump_hook_payload("demo.py", cwd=project_root)),
        stdout=stdout_buffer,
        runner=CallbackRunner(_default_result_for_argv),
    )

    hook_response = json.loads(stdout_buffer.getvalue())

    assert exit_code == 0
    assert hook_response["decision"] == "block"
    assert "Found a type issue" in hook_response["reason"]


def test_main_omits_check_failures_when_policy_skips_after_fix_failure(tmp_path: Path) -> None:
    project_root = tmp_path / "project"
    project_root.mkdir()
    (project_root / "demo.py").write_text("print('x')\n", encoding="utf-8")
    config_path = tmp_path / "config.yml"
    write_config(
        config_path,
        {
            "report": {"mode": "context"},
            "fix": {
                "on_error": "skip_check",
                "commands": {
                    "formatter": {"glob": "*.py", "run": "uv run formatter {file}"},
                },
            },
            "check": {
                "commands": {
                    "ruff-check": {"glob": "*.py", "run": "uv run ruff check {file}"},
                },
            },
        },
    )
    stdout_buffer = StringIO()
    seen_argv: list[tuple[str, ...]] = []

    def result_for_argv(argv: tuple[str, ...]) -> ExecResult:
        seen_argv.append(argv)
        return ExecResult(
            status=ExecStatus.FAILED if argv[2] == "formatter" else ExecStatus.SUCCEEDED,
            output="Formatter crashed" if argv[2] == "formatter" else "",
            duration_seconds=0.01,
            exit_code=2 if argv[2] == "formatter" else 0,
        )

    exit_code = main(
        ["--config", str(config_path)],
        stdin=StringIO(dump_hook_payload("demo.py", cwd=project_root)),
        stdout=stdout_buffer,
        runner=CallbackRunner(result_for_argv),
    )

    hook_response = json.loads(stdout_buffer.getvalue())
    additional_context = hook_response["hookSpecificOutput"]["additionalContext"]

    assert exit_code == 0
    assert seen_argv == [("uv", "run", "formatter", "demo.py")]
    assert "- Formatter: Failed" in additional_context
    assert "Ruff Check" not in additional_context
    assert hook_response["hookSpecificOutput"]["executed"] == 1
