"""Tests for `aclint.config`."""
