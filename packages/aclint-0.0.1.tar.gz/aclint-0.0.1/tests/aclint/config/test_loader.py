from __future__ import annotations

from pathlib import Path

from aclint.config.loader import config_path, load_settings
from aclint.core.error import AppError, ErrorCode
from aclint.core.model import CwdMode, Phase

from tests.aclint.testing import assert_failure, write_config

_EXAMPLE_CONFIG = {
    "defaults": {
        "timeout_seconds": 12,
        "output_chars_limit": 3456,
    },
    "fix": {
        "commands": {
            "ruff-format": {
                "glob": "*.py",
                "run": "uv run ruff format {file}",
                "enabled": False,
            },
        },
    },
    "check": {
        "parallel": 9,
        "commands": {
            "ruff-check": {
                "glob": "*.py",
                "run": "uv run ruff check {file}",
            },
        },
    },
}


def test_load_settings_normalizes_runtime_settings(tmp_path: Path) -> None:
    config_path = tmp_path / "config.yml"
    write_config(config_path, _EXAMPLE_CONFIG)

    settings = load_settings(config_path).unwrap()

    assert settings.parallel == 9
    assert settings.defaults.output_chars_limit == 3456
    assert settings.defaults.timeout_seconds == 12
    assert settings.rules[0].enabled is False
    assert settings.rules[1].key == "ruff-check"
    assert settings.rules[1].argv == ("uv", "run", "ruff", "check", "{file}")
    assert settings.rules[1].phase is Phase.CHECK
    assert settings.rules[1].cwd is CwdMode.PROJECT_ROOT


def test_config_path_discovers_config_upward(tmp_path: Path) -> None:
    project_root = tmp_path / "project"
    nested_dir = project_root / "src" / "feature"
    nested_dir.mkdir(parents=True)
    config_file = project_root / "aclint.yml"
    write_config(config_file, _EXAMPLE_CONFIG)

    result = config_path([], nested_dir)

    assert result.unwrap() == config_file


def test_load_settings_rejects_invalid_command_configuration(tmp_path: Path) -> None:
    config_path = tmp_path / "config.yml"
    write_config(
        config_path,
        {
            "check": {
                "commands": {
                    "lint": {
                        "glob": "*.py",
                        "run": "uv run ruff check {staged_files}",
                    },
                },
            },
        },
    )

    result = load_settings(config_path)

    assert_failure(
        result,
        AppError(
            ErrorCode.CONFIG_VALIDATION,
            "Invalid config at check.commands.lint: uses unsupported placeholder: {staged_files}",
        ),
    )


def test_config_path_rejects_extra_arguments() -> None:
    result = config_path(["--config", "a.yml", "extra"], Path.cwd())

    assert_failure(
        result,
        AppError(
            ErrorCode.CLI_ARGUMENTS,
            "Error: --config requires exactly one path argument",
        ),
    )
