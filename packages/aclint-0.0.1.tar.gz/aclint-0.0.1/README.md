# aclint

Agentic coding lint hook.

## Overview

- Claude Code hook for auto-fix and lint
- Fix commands run sequentially, then check commands run in parallel
- Reports only when issues remain

## Config

See [`aclint.example.yml`](aclint.example.yml) for all settings, defaults, and command examples.

## Development

```bash
just setup-dev
```

### Tooling

- Runtime: [uv](https://docs.astral.sh/uv/)
- JS/TS: [Biome](https://biomejs.dev/)
- Python: [Ruff](https://docs.astral.sh/ruff/), [mypy](https://mypy-lang.org/), [pytest](https://docs.pytest.org/), [Poe](https://github.com/nat-n/poethepoet)
- Project template: [Copier](https://copier.readthedocs.io/)
- Task runner: [just](https://github.com/casey/just)
- Git hooks: [Lefthook](https://github.com/evilmartians/lefthook)

## Dependencies

Automated via [Renovate](https://docs.renovatebot.com/).
Dependency update PRs are created automatically.

## Release

Automated via [release-please](https://github.com/googleapis/release-please).
Merge the auto-generated Release PR to bump version, update [`CHANGELOG.md`](CHANGELOG.md), and create a tag.
