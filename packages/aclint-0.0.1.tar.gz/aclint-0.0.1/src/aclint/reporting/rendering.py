"""Render user-facing output."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

from aclint.core.model import Phase, Status
from aclint.core.queries import outcomes_for_phase, outcomes_with_status

if TYPE_CHECKING:
    from aclint.core.model import Outcome, Report, Settings, Summary

_REPORT_HEADING_LEVEL = 1
_SECTION_HEADING_LEVEL = 2
_DETAIL_HEADING_LEVEL = 3


def _heading(level: int, text: str) -> str:
    """Render a markdown heading."""
    return f"{'#' * level} {text}"


@dataclass(frozen=True, slots=True)
class _DetailItem:
    """A labeled detail block."""

    label: str
    output: str

    def render(self) -> str:
        """Render the detail block as markdown."""
        return _heading(_DETAIL_HEADING_LEVEL, self.label) + "\n" + self.output


@dataclass(frozen=True, slots=True)
class _BulletItem:
    """A labeled bullet line."""

    label: str
    suffix: str

    def render(self) -> str:
        """Render the bullet line as markdown."""
        return f"- {self.label}: {self.suffix}"


type _ReportItem = _DetailItem | _BulletItem


@dataclass(frozen=True, slots=True)
class _ReportSection:
    """A fully prepared report section."""

    heading: str
    items: tuple[_ReportItem, ...]

    def render(self) -> str:
        """Render the section as markdown."""
        return (
            _heading(_SECTION_HEADING_LEVEL, self.heading)
            + "\n\n"
            + _render_section_body(self.items)
        )


def _render_section_body(items: tuple[_ReportItem, ...]) -> str:
    """Render the item list inside one section."""
    rendered_parts: list[str] = []
    for index, item in enumerate(items):
        rendered_parts.append(item.render())
        if isinstance(item, _DetailItem) and index < len(items) - 1:
            rendered_parts.append("")
    return "\n".join(rendered_parts)


def _build_preamble(report: Report, *, config_path: Path | None) -> tuple[str, ...]:
    """Build the report header lines above the sections."""
    config_line: str | None
    match config_path:
        case Path() as path if report.show_config_path:
            config_line = f"Config: `{path}`"
        case _:
            config_line = None
    return tuple(
        line
        for line in (
            _heading(_REPORT_HEADING_LEVEL, report.title),
            config_line,
            report.description or None,
        )
        if line is not None
    )


def _render_report(preamble: tuple[str, ...], sections: tuple[_ReportSection, ...]) -> str:
    """Assemble preamble and sections into a full report."""
    parts = [*preamble, "\n\n".join(section.render() for section in sections)]
    return "\n\n".join(parts)


def _status_label(status: Status) -> str:
    """Return the user-facing status label."""
    match status:
        case Status.PASSED:
            return "Passed"
        case Status.FAILED:
            return "Failed"
        case Status.WARNING:
            return "Warning"


def _build_missing_binary_item(outcome: Outcome) -> _BulletItem:
    """Build a missing-binary item."""
    return _BulletItem(label=outcome.command.label, suffix=outcome.output.strip())


def _build_detail_or_status_item(outcome: Outcome) -> _ReportItem:
    """Build a detail block when output exists, otherwise a status line."""
    output = outcome.output.strip()
    if output:
        return _DetailItem(label=outcome.command.label, output=output)
    return _build_status_item(outcome)


def _build_status_item(outcome: Outcome) -> _BulletItem:
    """Build a status-only bullet item."""
    return _BulletItem(label=outcome.command.label, suffix=_status_label(outcome.status))


def _build_item(outcome: Outcome, *, missing_binary: bool, verbose: bool) -> _ReportItem:
    """Build the appropriate report item for an outcome."""
    if missing_binary:
        return _build_missing_binary_item(outcome)
    if verbose:
        return _build_detail_or_status_item(outcome)
    return _build_status_item(outcome)


def _build_sections(summary: Summary, report: Report) -> tuple[_ReportSection, ...]:
    """Build non-empty report sections in display order."""
    fix_failures = tuple(
        outcome
        for outcome in outcomes_for_phase(summary, Phase.FIX)
        if outcome.status is Status.FAILED
    )
    warnings = outcomes_with_status(summary, Status.WARNING)
    check_failures = tuple(
        outcome
        for outcome in outcomes_for_phase(summary, Phase.CHECK)
        if outcome.status is Status.FAILED
    )
    candidates: tuple[tuple[str, tuple[Outcome, ...], bool, bool], ...] = (
        (report.fix_failures.heading, fix_failures, False, report.fix_failures.verbose),
        (report.missing_binaries.heading, warnings, True, report.missing_binaries.verbose),
        (report.check_failures.heading, check_failures, False, report.check_failures.verbose),
    )
    return tuple(
        _ReportSection(
            heading=heading,
            items=tuple(
                _build_item(outcome, missing_binary=missing_binary, verbose=verbose)
                for outcome in outcomes
            ),
        )
        for heading, outcomes, missing_binary, verbose in candidates
        if outcomes
    )


def render_report(
    summary: Summary,
    settings: Settings,
    *,
    config_path: Path | None = None,
) -> str:
    """Render fix failures, missing binaries, and check failures."""
    sections = _build_sections(summary, settings.report)
    if not sections:
        return ""
    preamble = _build_preamble(settings.report, config_path=config_path)
    return _render_report(preamble, sections)
