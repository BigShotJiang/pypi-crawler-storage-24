"""Python package for aclint."""

from importlib.metadata import version

from aclint.cli import main

__version__ = version(__name__)

__all__ = [
    "__version__",
    "main",
]
