"""Execute planned commands and classify outcomes."""

from __future__ import annotations

import hashlib
import shutil
import time
from functools import lru_cache
from operator import itemgetter
from typing import TYPE_CHECKING

import anyio

from aclint.core.model import (
    ExecResult,
    ExecStatus,
    FixPolicy,
    Outcome,
    Settings,
    Status,
    Summary,
    Target,
    Task,
)
from aclint.core.text import truncate_text
from aclint.execution.planning import plan

if TYPE_CHECKING:
    from collections.abc import Callable
    from pathlib import Path

    from aclint.core.model import Runner

_MISSING_BINARY_HINTS = ("cannot find module", "command not found", "is not recognized")


@lru_cache(maxsize=32)
def is_command_available(binary: str) -> bool:
    """Return whether a binary exists on PATH."""
    return shutil.which(binary) is not None


def _hash_file(path: Path) -> str:
    """Return the SHA-256 digest of a file."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


class SubprocessRunner:
    """Runner backed by AnyIO subprocess support."""

    def __init__(self, *, truncation_suffix: str) -> None:
        self._truncation_suffix = truncation_suffix

    @staticmethod
    def is_available(binary: str) -> bool:
        """Return whether the binary exists on PATH."""
        return is_command_available(binary)

    async def run(
        self,
        argv: tuple[str, ...],
        cwd: Path,
        timeout_seconds: float,
        output_chars_limit: int,
    ) -> ExecResult:
        """Run a command and capture stdout and stderr."""
        started_at = time.monotonic()

        try:
            with anyio.fail_after(timeout_seconds):
                completed = await anyio.run_process(list(argv), cwd=cwd, check=False)
        except TimeoutError:
            return ExecResult(
                status=ExecStatus.TIMED_OUT,
                output=f"Timed out after {timeout_seconds}s",
                duration_seconds=time.monotonic() - started_at,
            )
        except FileNotFoundError:
            return ExecResult(
                status=ExecStatus.MISSING_BINARY,
                output=f"Missing binary: {argv[0]}",
                duration_seconds=time.monotonic() - started_at,
            )
        except OSError as error:
            return ExecResult(
                status=ExecStatus.OS_ERROR,
                output=f"Error: {error}",
                duration_seconds=time.monotonic() - started_at,
            )

        stdout = completed.stdout.decode(errors="replace") if completed.stdout else ""
        stderr = completed.stderr.decode(errors="replace") if completed.stderr else ""
        return ExecResult(
            status=ExecStatus.SUCCEEDED if completed.returncode == 0 else ExecStatus.FAILED,
            output=truncate_text(stdout + stderr, output_chars_limit, self._truncation_suffix),
            duration_seconds=time.monotonic() - started_at,
            exit_code=completed.returncode,
        )


async def run(
    target: Target,
    settings: Settings,
    runner: Runner,
) -> Summary:
    """Run the configured commands for one target file."""
    started_at = time.monotonic()
    execution_plan = plan(target, settings)
    fix_outcomes = await _run_fix_commands(
        execution_plan.fix_commands, runner=runner, file_path=target.file_path
    )
    skip_check = settings.on_error is FixPolicy.SKIP_CHECK and any(
        outcome.status is Status.FAILED for outcome in fix_outcomes
    )
    check_outcomes = (
        ()
        if skip_check
        else await run_in_parallel(
            execution_plan.check_commands,
            parallel=settings.parallel,
            runner=runner,
        )
    )
    return Summary(
        outcomes=(*fix_outcomes, *check_outcomes),
        total_duration_seconds=time.monotonic() - started_at,
    )


async def _run_fix_commands(
    commands: tuple[Task, ...],
    *,
    runner: Runner,
    file_path: Path,
) -> tuple[Outcome, ...]:
    """Run fix commands sequentially."""
    outcomes = [await _run_command(command, runner, file_path) for command in commands]
    return tuple(outcomes)


async def _run_command(command: Task, runner: Runner, file_path: Path) -> Outcome:
    """Run a command using the configured stability policy."""
    if command.repeat_until_stable:
        return await run_until_stable(command, runner, file_path)
    return await run_once(command, runner)


async def run_once(command: Task, runner: Runner) -> Outcome:
    """Run one command once."""
    binary = command.argv[0]
    if not runner.is_available(binary):
        return Outcome(
            status=Status.WARNING,
            command=command,
            output=f"Missing binary: {binary}",
            duration_seconds=0.0,
        )

    exec_result = await runner.run(
        command.argv,
        command.cwd,
        command.timeout_seconds,
        command.output_chars_limit,
    )
    return Outcome(
        status=classify_exec_result(exec_result),
        command=command,
        output=exec_result.output,
        duration_seconds=exec_result.duration_seconds,
        exit_code=exec_result.exit_code,
    )


def classify_exec_result(exec_result: ExecResult) -> Status:
    """Translate one raw process result into a user-facing status."""
    if exec_result.status is ExecStatus.SUCCEEDED:
        return Status.PASSED
    if exec_result.status is ExecStatus.MISSING_BINARY:
        return Status.WARNING
    if is_missing_binary_hint(exec_result.output):
        return Status.WARNING
    return Status.FAILED


def is_missing_binary_hint(output: str) -> bool:
    """Return whether command output looks like a nested missing-binary error."""
    normalized_output = output.lower()
    return any(hint in normalized_output for hint in _MISSING_BINARY_HINTS)


async def run_until_stable(
    command: Task,
    runner: Runner,
    file_path: Path,
    *,
    file_hash: Callable[[Path], str] = _hash_file,
) -> Outcome:
    """Run a command until the target file stops changing."""
    latest_outcome = Outcome(
        status=Status.FAILED,
        command=command,
        output="",
        duration_seconds=0.0,
    )
    current_hash = file_hash(file_path)

    for _ in range(command.max_stable_passes):
        latest_outcome = await run_once(command, runner)
        if latest_outcome.status is not Status.PASSED:
            return latest_outcome

        new_hash = file_hash(file_path)
        if current_hash == new_hash:
            return latest_outcome
        current_hash = new_hash

    return latest_outcome


async def run_in_parallel(
    commands: tuple[Task, ...],
    *,
    parallel: int,
    runner: Runner,
) -> tuple[Outcome, ...]:
    """Run check commands in parallel while preserving input order."""
    if not commands:
        return ()

    limiter = anyio.CapacityLimiter(max(1, min(parallel, len(commands))))
    collected_outcomes: list[tuple[int, Outcome]] = []

    async def run_limited(index: int, command: Task) -> None:
        async with limiter:
            collected_outcomes.append((index, await run_once(command, runner)))

    async with anyio.create_task_group() as task_group:
        for index, command in enumerate(commands):
            task_group.start_soon(run_limited, index, command)

    return tuple(outcome for _, outcome in sorted(collected_outcomes, key=itemgetter(0)))
