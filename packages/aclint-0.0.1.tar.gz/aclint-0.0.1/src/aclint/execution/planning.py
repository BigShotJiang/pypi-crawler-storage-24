"""Plan executable tasks from validated settings."""

from __future__ import annotations

from typing import TYPE_CHECKING

from wcmatch import pathlib as wc_pathlib

from aclint.core.model import (
    CwdMode,
    Phase,
    Plan,
    Rule,
    Settings,
    Target,
    Task,
)

if TYPE_CHECKING:
    from pathlib import Path

_MAX_STABLE_PASSES = 5
_FILE_TOKEN = "{file}"  # noqa: S105
_ABSOLUTE_FILE_TOKEN = "{absolute_file}"  # noqa: S105
_PROJECT_ROOT_TOKEN = "{project_root}"  # noqa: S105


def plan(target: Target, settings: Settings) -> Plan:
    """Build an execution plan for one file."""
    planned_tasks = tuple(
        _plan_task(rule, target, settings, cwd=cwd)
        for rule in settings.rules
        if rule.enabled
        for cwd in (resolve_cwd(rule.cwd, target.project_root, target.file_path),)
        if _glob_matches(rule, target, cwd)
    )
    return Plan(
        fix_commands=_tasks_for_phase(planned_tasks, Phase.FIX),
        check_commands=_tasks_for_phase(planned_tasks, Phase.CHECK),
    )


def _tasks_for_phase(tasks: tuple[Task, ...], phase: Phase) -> tuple[Task, ...]:
    """Select planned tasks for a phase."""
    return tuple(task for task in tasks if task.phase is phase)


def _plan_task(
    rule: Rule,
    target: Target,
    settings: Settings,
    *,
    cwd: Path,
) -> Task:
    """Build a task from a rule."""
    return Task(
        cwd=cwd,
        key=rule.key,
        label=rule.label,
        argv=expand_argv(
            argv=rule.argv,
            project_root=target.project_root,
            file_path=target.file_path,
            cwd=cwd,
        ),
        phase=rule.phase,
        timeout_seconds=rule.timeout_seconds or settings.defaults.timeout_seconds,
        output_chars_limit=rule.output_chars_limit or settings.defaults.output_chars_limit,
        repeat_until_stable=rule.repeat_until_stable,
        max_stable_passes=rule.max_stable_passes or _MAX_STABLE_PASSES,
    )


def rule_matches_target(rule: Rule, target: Target) -> bool:
    """Return whether a rule applies to the target file."""
    cwd = resolve_cwd(rule.cwd, target.project_root, target.file_path)
    return _glob_matches(rule, target, cwd)


def _glob_matches(rule: Rule, target: Target, cwd: Path) -> bool:
    """Return whether the target file matches the rule globs within the given cwd."""
    if not target.file_path.is_relative_to(cwd):
        return False

    relative_path = target.file_path.relative_to(cwd)
    path_match = wc_pathlib.PurePath(relative_path.as_posix())
    return path_match.globmatch(
        rule.glob,
        flags=wc_pathlib.BRACE | wc_pathlib.GLOBSTAR | wc_pathlib.MATCHBASE,
        exclude=rule.exclude or None,
    )


def expand_argv(
    *,
    argv: tuple[str, ...],
    project_root: Path,
    file_path: Path,
    cwd: Path,
) -> tuple[str, ...]:
    """Expand supported placeholders inside command arguments."""
    return tuple(
        _expand_argv_part(part, project_root=project_root, file_path=file_path, cwd=cwd)
        for part in argv
    )


def _expand_argv_part(
    part: str,
    *,
    project_root: Path,
    file_path: Path,
    cwd: Path,
) -> str:
    """Expand supported placeholders in a command part."""
    project_relative_file = file_path.relative_to(project_root).as_posix()
    file_token_value = (
        file_path.relative_to(cwd).as_posix()
        if file_path.is_relative_to(cwd)
        else project_relative_file
    )
    return (
        part.replace(_FILE_TOKEN, file_token_value)
        .replace(_ABSOLUTE_FILE_TOKEN, str(file_path))
        .replace(_PROJECT_ROOT_TOKEN, str(project_root))
    )


def resolve_cwd(cwd: CwdMode, project_root: Path, file_path: Path) -> Path:
    """Resolve the working directory for a command."""
    if cwd is CwdMode.FILE_DIR:
        return file_path.parent
    return project_root
