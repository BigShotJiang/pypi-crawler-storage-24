"""CLI entrypoint for aclint."""

from __future__ import annotations

import sys
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

import anyio
from returns.result import Failure, Result, Success

from aclint.config.loader import (
    config_path as resolve_cli_config_path,
)
from aclint.config.loader import (
    load_settings,
)
from aclint.execution.running import SubprocessRunner, run
from aclint.hook.io import (
    block_response,
    read_payload,
    summary_response,
    write_response,
)
from aclint.hook.resolution import is_ignored, resolve_target

if TYPE_CHECKING:
    from collections.abc import Mapping
    from typing import TextIO

    from aclint.core.model import JsonObject, Runner, Settings, Target
    from aclint.core.result import InternalResult


@dataclass(frozen=True, slots=True)
class _CliOutcome:
    """Explicit CLI outcome."""

    exit_code: int
    stderr_text: str | None = None
    response: JsonObject | None = None


def _block_outcome(message: str) -> _CliOutcome:
    """Build a blocking hook outcome."""
    return _CliOutcome(exit_code=0, response=block_response(message))


def _stderr_outcome(message: str) -> _CliOutcome:
    """Build a stderr-only outcome before hook I/O begins."""
    return _CliOutcome(exit_code=1, stderr_text=message)


def main(
    argv: list[str] | None = None,
    *,
    stdin: TextIO | None = None,
    stdout: TextIO | None = None,
    stderr: TextIO | None = None,
    env: Mapping[str, str] | None = None,
    runner: Runner | None = None,
) -> int:
    """Run the hook command."""
    del env
    args = list(sys.argv[1:] if argv is None else argv)
    input_stream = sys.stdin if stdin is None else stdin
    output_stream = sys.stdout if stdout is None else stdout
    error_stream = sys.stderr if stderr is None else stderr

    outcome = _resolve_and_run(
        args=args,
        stdin=input_stream,
        cwd=Path.cwd(),
        runner=runner,
    )
    if outcome.stderr_text is not None:
        error_stream.write(outcome.stderr_text)
        error_stream.write("\n")
    if outcome.response is not None:
        write_response(output_stream, outcome.response)
    return outcome.exit_code


def _resolve_and_run(
    *,
    args: list[str],
    stdin: TextIO,
    cwd: Path,
    runner: Runner | None,
) -> _CliOutcome:
    """Resolve a CLI invocation into an explicit outcome."""
    match resolve_cli_config_path(args, cwd):
        case Failure(error):
            return _stderr_outcome(error.message)
        case Success(config_file):
            return _run_hook_protocol(config_file, stdin=stdin, runner=runner)
        case _:  # pragma: no cover
            return _stderr_outcome("Unexpected internal error")


def _run_hook_protocol(
    config_file: Path | None,
    *,
    stdin: TextIO,
    runner: Runner | None,
) -> _CliOutcome:
    """Execute the hook protocol; all errors are reported via hook response."""
    match read_payload(stdin):
        case Failure(error):
            return _block_outcome(error.message)
        case Success(payload):
            pass

    match _prepare_run_internal(payload, config_file):
        case Failure(error):
            return _block_outcome(error.message)
        case Success((settings, target)):
            return _execute_prepared_run(settings, target, runner=runner, config_path=config_file)
        case _:  # pragma: no cover
            return _block_outcome("Unexpected internal error")


def _execute_prepared_run(
    settings: Settings,
    target: Target,
    *,
    runner: Runner | None,
    config_path: Path | None,
) -> _CliOutcome:
    """Execute a validated hook request."""
    if is_ignored(target.project_root, target.file_path):
        return _CliOutcome(exit_code=0)

    effective_runner = runner or SubprocessRunner(
        truncation_suffix=settings.report.truncation_suffix,
    )
    summary = anyio.run(run, target, settings, effective_runner)
    response = summary_response(summary, settings, config_path=config_path)
    return _CliOutcome(exit_code=0, response=response)


def _prepare_run_internal(
    payload: object,
    config_path: Path | None,
) -> InternalResult[tuple[Settings, Target]]:
    """Resolve typed inputs for a hook run."""
    return Result.do(
        (settings, target)
        for settings in load_settings(config_path)
        for target in resolve_target(payload)
    )


__all__ = [
    "main",
]
