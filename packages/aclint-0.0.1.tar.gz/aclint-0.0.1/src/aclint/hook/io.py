"""Hook payload I/O and hook response rendering."""

from __future__ import annotations

import json
from typing import TYPE_CHECKING, Literal, TextIO

from pydantic import BaseModel, ConfigDict, ValidationError
from returns.result import safe

from aclint.core.error import AppError, ErrorCode
from aclint.core.model import ReportMode, Settings, Status, Summary
from aclint.core.queries import has_failures, has_warnings, outcomes_with_status
from aclint.core.result import InternalResult, map_error, validate_model, validation_error_details
from aclint.reporting.rendering import render_report

if TYPE_CHECKING:
    from pathlib import Path

    from aclint.core.model import JsonObject, JsonScalar


class Input(BaseModel):
    """Relevant input fields from a hook payload."""

    model_config = ConfigDict(extra="ignore")

    file_path: str


class Payload(BaseModel):
    """Validated hook payload."""

    model_config = ConfigDict(extra="ignore")

    cwd: str | None = None
    tool_input: Input


def _build_payload_validation_error(
    error: ValidationError,
    code: ErrorCode,
    context: str,
) -> AppError:
    """Build an application error from payload validation."""
    location, _message = validation_error_details(error)
    if location == "tool_input.file_path":
        return AppError(code, "No file path provided")
    return AppError(code, context)


@safe(exceptions=(OSError, json.JSONDecodeError))
def _load_payload(stdin: TextIO) -> object:
    return json.load(stdin)


def read_payload(stdin: TextIO) -> InternalResult[object]:
    """Read JSON hook payload data from stdin."""
    return map_error(
        _load_payload(stdin),
        lambda _: AppError(ErrorCode.PAYLOAD_READ, "Invalid JSON input"),
    )


def validate_payload(payload: object) -> InternalResult[Payload]:
    """Validate hook payload data."""
    return validate_model(
        Payload,
        payload,
        code=ErrorCode.PAYLOAD_VALIDATION,
        context="Invalid payload",
        error_builder=_build_payload_validation_error,
    )


def block_response(message: str) -> JsonObject:
    """Build a block response."""
    return response("block", message)


def summary_response(
    summary: Summary,
    settings: Settings,
    *,
    config_path: Path | None = None,
) -> JsonObject | None:
    """Build the response for a completed run."""
    if not has_failures(summary) and not has_warnings(summary):
        return None

    decision: Literal["block"] | None = (
        "block" if settings.report.mode is ReportMode.BLOCK else None
    )
    return response(
        decision,
        render_report(summary, settings, config_path=config_path),
        duration=round(summary.total_duration_seconds, 2),
        errors=len(outcomes_with_status(summary, Status.FAILED)),
        executed=len(summary.outcomes),
        warnings=len(outcomes_with_status(summary, Status.WARNING)),
    )


def response(
    decision: Literal["block"] | None,
    message: str,
    **metadata: JsonScalar,
) -> JsonObject:
    """Build a Claude-compatible response."""
    response: JsonObject = {}
    hook_output: JsonObject = {"hookEventName": "PostToolUse", **metadata}

    if decision is None:
        hook_output["additionalContext"] = message
    else:
        response["decision"] = decision
        response["reason"] = message

    response["hookSpecificOutput"] = hook_output
    return response


def write_response(stdout: TextIO, response: JsonObject) -> None:
    """Write a JSON hook response to stdout."""
    stdout.write(json.dumps(response))
    stdout.write("\n")
    stdout.flush()
