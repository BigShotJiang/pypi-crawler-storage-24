"""Hook target resolution and path filtering."""

from __future__ import annotations

import shutil
import subprocess  # noqa: S404
from pathlib import Path
from typing import TYPE_CHECKING

from returns.result import Failure, Result, Success

from aclint.core.error import AppError, ErrorCode
from aclint.core.model import Target
from aclint.hook.io import Payload, validate_payload

if TYPE_CHECKING:
    from aclint.core.result import InternalResult

_GIT_BINARY = shutil.which("git")


def resolve_target(payload: object) -> InternalResult[Target]:
    """Resolve the target file and project root for hook payload data."""
    return Result.do(
        Target(project_root, file_path)
        for validated_payload in validate_payload(payload)
        for project_root in _resolve_project_root(_project_root_text(validated_payload))
        for file_path in _resolve_file_path(
            project_root,
            validated_payload.tool_input.file_path,
        )
    )


def _project_root_text(payload: Payload) -> str:
    """Return the project root text in precedence order."""
    if payload.cwd is not None:
        return payload.cwd
    return "."


def _resolve_project_root(value: str) -> InternalResult[Path]:
    """Resolve the project root directory."""
    project_root = Path(value).resolve()
    if not project_root.is_dir():
        return Failure(
            AppError(ErrorCode.PROJECT_ROOT, f"Invalid project directory: {project_root}")
        )
    return Success(project_root)


def _resolve_file_path(project_root: Path, file_path: str) -> InternalResult[Path]:
    """Resolve the file path and ensure it stays inside the project."""
    resolved_file_path = (project_root / file_path).resolve()
    try:
        resolved_file_path.relative_to(project_root)
    except ValueError:
        return Failure(AppError(ErrorCode.TARGET_FILE, f"File path outside project: {file_path}"))

    if not resolved_file_path.is_file():
        return Failure(AppError(ErrorCode.TARGET_FILE, f"File not found: {file_path}"))
    return Success(resolved_file_path)


def is_ignored(project_root: Path, file_path: Path) -> bool:
    """Return whether Git ignore rules exclude the file path."""
    if _GIT_BINARY is None:
        return False

    relative_path = file_path.relative_to(project_root).as_posix()
    try:
        completed = subprocess.run(  # noqa: S603
            [_GIT_BINARY, "check-ignore", "--quiet", "--no-index", "--", relative_path],
            capture_output=True,
            check=False,
            cwd=project_root,
            text=False,
        )
    except OSError:
        return False
    return completed.returncode == 0
