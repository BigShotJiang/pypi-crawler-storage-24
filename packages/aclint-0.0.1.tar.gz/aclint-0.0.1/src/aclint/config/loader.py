"""Configuration discovery, parsing, and decoding."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

import yaml
from returns.result import Failure, Result, Success, safe

from aclint.config.schema import CONFIG_FILENAMES, CONFIG_SUFFIXES, ConfigDocument
from aclint.core.error import AppError, ErrorCode
from aclint.core.result import map_error, validate_model

if TYPE_CHECKING:
    from aclint.core.model import Settings
    from aclint.core.result import InternalResult


@safe(exceptions=(OSError, yaml.YAMLError))
def _read_yaml_file(path: Path) -> object:
    with path.open(encoding="utf-8") as stream:
        return yaml.safe_load(stream)


def config_path(
    args: list[str],
    cwd: Path,
) -> InternalResult[Path | None]:
    """Resolve the effective config path."""
    return Result.do(
        explicit_path or discover_config_path(cwd) for explicit_path in parse_config_args(args)
    )


def parse_config_args(args: list[str]) -> InternalResult[Path | None]:
    """Parse CLI config arguments."""
    if not args:
        return Success(None)
    if args[0] != "--config":
        return Failure(AppError(ErrorCode.CLI_ARGUMENTS, f"Unknown arguments: {' '.join(args)}"))
    if len(args) != 2:
        return Failure(
            AppError(ErrorCode.CLI_ARGUMENTS, "Error: --config requires exactly one path argument")
        )
    return validate_config_path(Path(args[1]).expanduser())


def validate_config_path(config_path: Path) -> InternalResult[Path]:
    """Validate an explicit config path."""
    if not config_path.is_file():
        return Failure(
            AppError(ErrorCode.CONFIG_PATH, f"Error: Config file not found: {config_path}")
        )
    if config_path.suffix.lower() not in CONFIG_SUFFIXES:
        return Failure(
            AppError(ErrorCode.CONFIG_PATH, "Error: Config files must use .yaml or .yml")
        )
    return Success(config_path)


def discover_config_path(cwd: Path) -> Path | None:
    """Find the first config file by walking upward from cwd."""
    current_dir = cwd.resolve()

    while True:
        for config_name in CONFIG_FILENAMES:
            config_path = current_dir / config_name
            if config_path.is_file():
                return config_path
        if current_dir.parent == current_dir:
            return None
        current_dir = current_dir.parent


def load_settings(config_path: Path | None) -> InternalResult[Settings]:
    """Load settings from YAML."""
    return Result.do(
        document.to_settings()
        for raw_data in _read_config_data(config_path)
        for document in _validate_config_data(raw_data)
    )


def _read_config_data(config_path: Path | None) -> InternalResult[object]:
    """Read raw YAML config data."""
    if config_path is None:
        return Success({})
    return map_error(
        _read_yaml_file(config_path),
        lambda error: AppError(ErrorCode.CONFIG_READ, f"Failed to read config: {error}"),
    )


def _validate_config_data(value: object) -> InternalResult[ConfigDocument]:
    """Validate and normalize raw YAML config data."""
    root_value = {} if value is None else value
    if not isinstance(root_value, dict):
        return Failure(AppError(ErrorCode.CONFIG_VALIDATION, "Config root must be a mapping"))
    return validate_model(
        ConfigDocument,
        root_value,
        code=ErrorCode.CONFIG_VALIDATION,
        context="Invalid config",
    )
