"""Pydantic models for the YAML configuration file."""

from __future__ import annotations

import shlex

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from aclint.core.model import (
    CwdMode,
    Defaults,
    FixPolicy,
    Phase,
    Report,
    ReportMode,
    ReportSectionConfig,
    Rule,
    Settings,
)

CONFIG_FILENAMES = ("aclint.yml", "aclint.yaml")
CONFIG_SUFFIXES = frozenset({".yaml", ".yml"})
_UNSUPPORTED_PLACEHOLDERS = frozenset({"{all_files}", "{staged_files}"})


def _default_command_label(key: str) -> str:
    """Build the default user-facing label for a command key."""
    return key.replace("-", " ").replace("_", " ").title()


class _ReportSectionEntry(BaseModel):
    """One report section entry."""

    model_config = ConfigDict(extra="ignore")

    heading: str
    verbose: bool = False


class _ReportSectionConfig(BaseModel):
    """Report text settings."""

    model_config = ConfigDict(extra="ignore")

    mode: ReportMode = ReportMode.BLOCK
    title: str = "ACLint Report"
    description: str = "Fix all issues at once."
    truncation_suffix: str = " ... (truncated)"
    show_config_path: bool = True
    fix_failures: _ReportSectionEntry = Field(
        default_factory=lambda: _ReportSectionEntry(heading="Fix failures", verbose=False)
    )
    missing_binaries: _ReportSectionEntry = Field(
        default_factory=lambda: _ReportSectionEntry(heading="Missing binaries", verbose=True)
    )
    check_failures: _ReportSectionEntry = Field(
        default_factory=lambda: _ReportSectionEntry(heading="Check failures", verbose=True)
    )


class _CommandSection(BaseModel):
    """One declarative command entry."""

    model_config = ConfigDict(extra="forbid")

    label: str | None = None
    glob: tuple[str, ...]
    exclude: tuple[str, ...] = ()
    run: str | None = None
    command: tuple[str, ...] | None = None
    cwd: CwdMode = CwdMode.PROJECT_ROOT
    enabled: bool = True
    repeat_until_stable: bool = False
    max_stable_passes: int | None = None
    timeout_seconds: float | None = None
    output_chars_limit: int | None = None

    @field_validator("glob", "exclude", mode="before")
    @classmethod
    def normalize_globs(cls, value: object) -> tuple[str, ...]:
        """Accept a single glob or a list of globs.

        Raises:
            ValueError: The value is not a string or a list of strings.
        """
        if value is None:
            return ()
        if isinstance(value, str):
            return (value,)
        if isinstance(value, list) and all(isinstance(item, str) for item in value):
            return tuple(value)
        raise ValueError("must be a string or a list of strings")

    @field_validator("max_stable_passes", mode="after")
    @classmethod
    def validate_max_stable_passes(cls, value: int | None) -> int | None:
        """Ensure max_stable_passes is at least 1.

        Raises:
            ValueError: The value is less than 1.
        """
        if value is not None and value < 1:
            raise ValueError("must be at least 1")
        return value

    @field_validator("command", mode="before")
    @classmethod
    def normalize_command(cls, value: object) -> tuple[str, ...] | None:
        """Accept only string arrays for command form.

        Raises:
            ValueError: The value is not a list of strings.
        """
        if value is None:
            return None
        if isinstance(value, list) and all(isinstance(item, str) for item in value):
            return tuple(value)
        raise ValueError("must be a list of strings")

    @model_validator(mode="after")
    def validate_command_entry(self) -> _CommandSection:
        """Validate a command entry.

        Raises:
            ValueError: The command entry is ambiguous or unsupported.
        """
        if (self.run is None) == (self.command is None):
            raise ValueError("must define exactly one of 'run' or 'command'")

        if self.run is not None and not shlex.split(self.run):
            raise ValueError("'run' must not be empty")

        for placeholder in _UNSUPPORTED_PLACEHOLDERS:
            if any(placeholder in part for part in self.command_parts):
                raise ValueError(f"uses unsupported placeholder: {placeholder}")
        return self

    @property
    def command_parts(self) -> tuple[str, ...]:
        """Return the effective command as argv parts."""
        if self.command is not None:
            return self.command
        return tuple(shlex.split(self.run or ""))


class _FixSection(BaseModel):
    """Fix phase configuration."""

    model_config = ConfigDict(extra="ignore")

    on_error: FixPolicy = FixPolicy.RUN_CHECK
    commands: dict[str, _CommandSection] = Field(default_factory=dict)


class _CheckSection(BaseModel):
    """Check phase configuration."""

    model_config = ConfigDict(extra="ignore")

    parallel: int = 3
    commands: dict[str, _CommandSection] = Field(default_factory=dict)


class _DefaultsSection(BaseModel):
    """Default command execution settings."""

    model_config = ConfigDict(extra="ignore")

    timeout_seconds: float = 15.0
    output_chars_limit: int = 10_000


class ConfigDocument(BaseModel):
    """Whole YAML document."""

    model_config = ConfigDict(extra="ignore")

    fix: _FixSection = Field(default_factory=_FixSection)
    check: _CheckSection = Field(default_factory=_CheckSection)
    defaults: _DefaultsSection = Field(default_factory=_DefaultsSection)
    report: _ReportSectionConfig = Field(default_factory=_ReportSectionConfig)

    def to_settings(self) -> Settings:
        """Build runtime settings."""
        return Settings(
            on_error=self.fix.on_error,
            parallel=self.check.parallel,
            defaults=Defaults(
                timeout_seconds=self.defaults.timeout_seconds,
                output_chars_limit=self.defaults.output_chars_limit,
            ),
            report=Report(
                mode=self.report.mode,
                title=self.report.title,
                description=self.report.description,
                truncation_suffix=self.report.truncation_suffix,
                show_config_path=self.report.show_config_path,
                fix_failures=ReportSectionConfig(**self.report.fix_failures.model_dump()),
                missing_binaries=ReportSectionConfig(**self.report.missing_binaries.model_dump()),
                check_failures=ReportSectionConfig(**self.report.check_failures.model_dump()),
            ),
            rules=self.configured_rules(),
        )

    def configured_rules(self) -> tuple[Rule, ...]:
        """Flatten fix and check sections into rules."""
        return tuple(
            Rule(
                key=key,
                label=command_section.label or _default_command_label(key),
                argv=command_section.command_parts,
                phase=phase_name,
                glob=command_section.glob,
                exclude=command_section.exclude,
                cwd=command_section.cwd,
                enabled=command_section.enabled,
                repeat_until_stable=command_section.repeat_until_stable,
                max_stable_passes=command_section.max_stable_passes,
                timeout_seconds=command_section.timeout_seconds,
                output_chars_limit=command_section.output_chars_limit,
            )
            for phase_name, commands in self.phase_sections
            for key, command_section in commands.items()
        )

    @property
    def phase_sections(self) -> tuple[tuple[Phase, dict[str, _CommandSection]], ...]:
        """Return phase command dicts in execution order."""
        return (
            (Phase.FIX, self.fix.commands),
            (Phase.CHECK, self.check.commands),
        )
