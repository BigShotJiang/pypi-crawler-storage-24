"""Text utilities shared across layers."""

from __future__ import annotations


def truncate_text(text: str, max_chars: int, suffix: str) -> str:
    """Trim text at the best visible boundary within the character budget."""
    if max_chars <= 0:
        return ""
    if len(text) <= max_chars:
        return text
    return _truncate_at_boundary(text, max_chars).rstrip() + suffix


def _truncate_at_boundary(text: str, max_chars: int) -> str:
    """Trim text at the best visible boundary within the character budget."""
    newline = text.rfind("\n", 0, max_chars)
    if newline > 0:
        return text[:newline]
    space = text.rfind(" ", 0, max_chars)
    if space > 0:
        return text[:space]
    return text[:max_chars]
