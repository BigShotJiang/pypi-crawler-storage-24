"""Query helpers for execution summaries."""

from __future__ import annotations

from aclint.core.model import Outcome, Phase, Status, Summary


def outcomes_with_status(
    summary: Summary,
    status: Status,
) -> tuple[Outcome, ...]:
    """Return outcomes that match one explicit status."""
    return tuple(outcome for outcome in summary.outcomes if outcome.status is status)


def outcomes_for_phase(
    summary: Summary,
    phase: Phase,
) -> tuple[Outcome, ...]:
    """Return outcomes for one phase."""
    return tuple(outcome for outcome in summary.outcomes if outcome.command.phase is phase)


def has_failures(summary: Summary) -> bool:
    """Return whether any command failed."""
    return bool(outcomes_with_status(summary, Status.FAILED))


def has_warnings(summary: Summary) -> bool:
    """Return whether any warning was emitted."""
    return bool(outcomes_with_status(summary, Status.WARNING))
