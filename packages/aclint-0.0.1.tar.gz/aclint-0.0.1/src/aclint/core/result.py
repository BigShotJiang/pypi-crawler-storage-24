"""Shared helpers for explicit Result flows."""

from __future__ import annotations

from collections.abc import Callable
from typing import cast

from pydantic import BaseModel, ValidationError
from returns.result import Result, safe

from aclint.core.error import AppError, ErrorCode

type InternalResult[T] = Result[T, AppError]
type _ValidationErrorBuilder = Callable[[ValidationError, ErrorCode, str], AppError]


def map_error[T, ErrorT, NewErrorT](
    result: Result[T, ErrorT],
    function: Callable[[ErrorT], NewErrorT],
) -> Result[T, NewErrorT]:
    """Map a result error type into another error type."""
    return cast("Result[T, NewErrorT]", result.alt(function))


@safe(exceptions=(ValidationError,))
def _validate_model[ModelT: BaseModel](
    model_type: type[ModelT],
    value: object,
) -> ModelT:
    return model_type.model_validate(value)


def validation_error_details(error: ValidationError) -> tuple[str, str]:
    """Return the first validation issue as location and message."""
    issue = error.errors(include_url=False)[0]
    location = ".".join(str(part) for part in issue["loc"])
    message = str(issue["msg"]).removeprefix("Value error, ")
    return location, message


def _build_validation_error(
    error: ValidationError,
    code: ErrorCode,
    context: str,
) -> AppError:
    """Build an application error from the first validation issue."""
    location, message = validation_error_details(error)
    if location:
        return AppError(code, f"{context} at {location}: {message}")
    return AppError(code, f"{context}: {message}")


def validate_model[ModelT: BaseModel](
    model_type: type[ModelT],
    value: object,
    *,
    code: ErrorCode,
    context: str,
    error_builder: _ValidationErrorBuilder = _build_validation_error,
) -> InternalResult[ModelT]:
    """Validate a Pydantic model and normalize the first error."""
    return map_error(
        _validate_model(model_type, value),
        lambda error: error_builder(error, code, context),
    )
