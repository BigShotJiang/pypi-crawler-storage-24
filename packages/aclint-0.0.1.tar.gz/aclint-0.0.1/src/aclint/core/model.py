"""Core public data types for aclint."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from typing import TYPE_CHECKING, Protocol

if TYPE_CHECKING:
    from pathlib import Path


class Phase(StrEnum):
    """Execution phase for a configured command."""

    FIX = "fix"
    CHECK = "check"


class FixPolicy(StrEnum):
    """Behavior after a fix command fails."""

    RUN_CHECK = "run_check"
    SKIP_CHECK = "skip_check"


class ReportMode(StrEnum):
    """How hook responses should be surfaced to the caller."""

    BLOCK = "block"
    CONTEXT = "context"


class CwdMode(StrEnum):
    """How to resolve a command working directory."""

    PROJECT_ROOT = "project_root"
    FILE_DIR = "file_dir"


class ExecStatus(StrEnum):
    """Raw process exit classification."""

    SUCCEEDED = "succeeded"
    FAILED = "failed"
    TIMED_OUT = "timed_out"
    MISSING_BINARY = "missing_binary"
    OS_ERROR = "os_error"


class Status(StrEnum):
    """User-facing command outcome status."""

    PASSED = "passed"
    FAILED = "failed"
    WARNING = "warning"


JsonScalar = str | int | float | bool | None
type JsonValue = JsonScalar | list[JsonValue] | dict[str, JsonValue]
type JsonObject = dict[str, JsonValue]


@dataclass(frozen=True, slots=True)
class Rule:
    """Validated command configuration."""

    key: str
    label: str
    argv: tuple[str, ...]
    phase: Phase
    glob: tuple[str, ...]
    exclude: tuple[str, ...]
    cwd: CwdMode = CwdMode.PROJECT_ROOT
    enabled: bool = True
    repeat_until_stable: bool = False
    max_stable_passes: int | None = None
    timeout_seconds: float | None = None
    output_chars_limit: int | None = None


@dataclass(frozen=True, slots=True)
class ReportSectionConfig:
    """Configuration for one report section."""

    heading: str
    verbose: bool = False


@dataclass(frozen=True, slots=True)
class Defaults:
    """Default command execution settings."""

    timeout_seconds: float
    output_chars_limit: int


@dataclass(frozen=True, slots=True)
class Report:
    """User-configurable report text."""

    mode: ReportMode
    title: str
    description: str
    truncation_suffix: str
    show_config_path: bool
    fix_failures: ReportSectionConfig
    missing_binaries: ReportSectionConfig
    check_failures: ReportSectionConfig


@dataclass(frozen=True, slots=True)
class Settings:
    """Validated runtime settings."""

    on_error: FixPolicy
    parallel: int
    defaults: Defaults
    report: Report
    rules: tuple[Rule, ...]


@dataclass(frozen=True, slots=True)
class Target:
    """Validated target file inside one project."""

    project_root: Path
    file_path: Path


@dataclass(frozen=True, slots=True)
class Task:
    """Executable command for one target file."""

    key: str
    label: str
    argv: tuple[str, ...]
    phase: Phase
    cwd: Path
    timeout_seconds: float
    output_chars_limit: int
    repeat_until_stable: bool = False
    max_stable_passes: int = 5


@dataclass(frozen=True, slots=True)
class Plan:
    """Commands selected for one target file."""

    fix_commands: tuple[Task, ...]
    check_commands: tuple[Task, ...]


@dataclass(frozen=True, slots=True)
class ExecResult:
    """Raw subprocess output."""

    status: ExecStatus
    output: str
    duration_seconds: float
    exit_code: int | None = None


@dataclass(frozen=True, slots=True)
class Outcome:
    """Observed outcome for one executed command."""

    status: Status
    command: Task
    output: str
    duration_seconds: float
    exit_code: int | None = None


@dataclass(frozen=True, slots=True)
class Summary:
    """Collected outcomes for executed commands on one target file."""

    outcomes: tuple[Outcome, ...]
    total_duration_seconds: float


class Runner(Protocol):
    """Command execution boundary."""

    def is_available(self, binary: str) -> bool:
        """Return whether the binary exists on PATH."""
        ...

    async def run(
        self,
        argv: tuple[str, ...],
        cwd: Path,
        timeout_seconds: float,
        output_chars_limit: int,
    ) -> ExecResult:
        """Run a command."""
        ...
