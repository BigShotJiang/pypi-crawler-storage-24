"""Typed error values for explicit Result-based flows."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum


class ErrorCode(StrEnum):
    """Stable application error codes."""

    CLI_ARGUMENTS = "cli_arguments"
    CONFIG_PATH = "config_path"
    CONFIG_READ = "config_read"
    CONFIG_VALIDATION = "config_validation"
    PAYLOAD_READ = "payload_read"
    PAYLOAD_VALIDATION = "payload_validation"
    PROJECT_ROOT = "project_root"
    TARGET_FILE = "target_file"


@dataclass(frozen=True, slots=True)
class AppError:
    """One explicit application error."""

    code: ErrorCode
    message: str
