"""Allow running as python -m aclint."""

from aclint.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
