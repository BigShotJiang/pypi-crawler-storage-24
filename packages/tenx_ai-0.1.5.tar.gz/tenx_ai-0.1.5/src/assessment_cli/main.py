"""Console entrypoint for the Tenx assessment CLI."""

from __future__ import annotations

import asyncio

from assessment_cli.session import run_session


def main() -> None:
    try:
        asyncio.run(run_session())
    except KeyboardInterrupt:
        print("\nExiting.")

