"""Build Claude Agent SDK client options (API env, model, tools, cwd)."""

from pathlib import Path

from claude_agent_sdk import ClaudeAgentOptions

from assessment_cli.config import settings
from assessment_cli.system_prompt import (
    build_assistant_system_prompt,
    build_technical_interviewer_system_prompt,
)


def require_api_key() -> str:
    api_key = (settings.anthropic_api_key or "").strip()
    if not api_key:
        raise SystemExit("Missing ANTHROPIC_API_KEY. Set it in .env and retry.")
    return api_key


def build_options(*, cwd: Path) -> ClaudeAgentOptions:
    env = {"ANTHROPIC_API_KEY": require_api_key()}
    if settings.anthropic_base_url:
        env["ANTHROPIC_BASE_URL"] = settings.anthropic_base_url

    return ClaudeAgentOptions(
        env=env,
        model=settings.model,
        system_prompt=build_assistant_system_prompt(),
        allowed_tools=["Read", "Write", "Edit", "Bash", "Glob", "Grep", "WebSearch", "WebFetch"],
        permission_mode="acceptEdits",
        include_partial_messages=False,
        cwd=str(cwd),
    )


def build_technical_interviewer_options(*, cwd: Path) -> ClaudeAgentOptions:
    env = {"ANTHROPIC_API_KEY": require_api_key()}
    if settings.anthropic_base_url:
        env["ANTHROPIC_BASE_URL"] = settings.anthropic_base_url

    output_format = {
        "type": "json_schema",
        "schema": {
            "type": "object",
            "required": ["questions"],
            "properties": {
                "questions": {
                    "type": "array",
                    "minItems": 3,
                    "maxItems": 3,
                    "items": {
                        "type": "object",
                        "required": ["prompt"],
                        "properties": {
                            "prompt": {"type": "string", "minLength": 1},
                        },
                        "additionalProperties": False,
                    },
                },
            },
            "additionalProperties": False,
        },
    }

    return ClaudeAgentOptions(
        env=env,
        model=settings.model,
        system_prompt=build_technical_interviewer_system_prompt(),
        allowed_tools=[],
        permission_mode="acceptEdits",
        include_partial_messages=False,
        output_format=output_format,
        cwd=str(cwd),
    )

