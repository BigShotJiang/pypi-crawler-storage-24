"""Persist and retrieve assessment session state shared across CLI commands."""

from __future__ import annotations

from pathlib import Path

from assessment_cli.config import resolved_agent_workspace_directory, settings

SESSION_STATE_RELATIVE_PATH = Path(".tenx") / "assessment_session_id"


def session_state_path() -> Path:
    return resolved_agent_workspace_directory() / SESSION_STATE_RELATIVE_PATH


def read_assessment_session_id() -> str | None:
    configured_id = (settings.assessment_session_id or "").strip()
    if configured_id:
        return configured_id

    path = session_state_path()
    if not path.exists():
        return None

    stored_id = path.read_text(encoding="utf-8").strip()
    return stored_id or None


def write_assessment_session_id(session_id: str) -> None:
    cleaned_session_id = session_id.strip()
    if not cleaned_session_id:
        return

    path = session_state_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(cleaned_session_id + "\n", encoding="utf-8")
