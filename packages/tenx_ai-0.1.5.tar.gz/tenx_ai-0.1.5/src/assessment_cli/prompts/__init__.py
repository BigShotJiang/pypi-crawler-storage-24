"""Bundled static prompt files shipped with the CLI."""

