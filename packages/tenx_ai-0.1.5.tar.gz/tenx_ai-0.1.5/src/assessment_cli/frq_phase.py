"""Run post-submit FRQ generation and persistence for assessment evaluations."""

from __future__ import annotations

import json
import os
import signal
import subprocess
import time
from pathlib import Path
from typing import Any

from claude_agent_sdk import ClaudeSDKClient
from claude_agent_sdk.types import AssistantMessage, ResultMessage
from rich.console import Console
from rich.theme import Theme

from assessment_cli.chat_history_client import ChatHistoryClient
from assessment_cli.client_options import build_technical_interviewer_options
from assessment_cli.config import resolved_agent_workspace_directory, settings
from assessment_cli.session_state import read_assessment_session_id
from assessment_cli.streaming import extract_text_blocks

GIT_PATCH_CHAR_LIMIT = 50_000
GIT_COMMAND_TIMEOUT_SECONDS = 10
FRQ_QUESTION_COUNT = 3
FRQ_ANSWER_CHARACTER_LIMIT = 2_000
FRQ_SECTION_DURATION_SECONDS = 600

FRQ_THEME = Theme(
    {
        "interviewer": "bold magenta",
        "meta": "dim",
        "error": "bold red",
    }
)
FRQ_CONSOLE = Console(theme=FRQ_THEME, highlight=False, soft_wrap=True)


class _FrqInputTimeoutError(Exception):
    """Raised when FRQ terminal input exceeds the allowed timeout."""


def _format_duration_mm_ss(total_seconds: int) -> str:
    safe_seconds = max(0, total_seconds)
    minutes, seconds = divmod(safe_seconds, 60)
    return f"{minutes:02d}:{seconds:02d}"


def _read_line_with_timeout(*, timeout_seconds: int) -> str | None:
    if timeout_seconds <= 0:
        return None

    if os.name == "nt":
        # Windows does not support SIGALRM; timeout is enforced between answers.
        return input().strip()

    def _timeout_handler(signum: int, frame: Any) -> None:
        raise _FrqInputTimeoutError()

    previous_handler = signal.getsignal(signal.SIGALRM)
    signal.signal(signal.SIGALRM, _timeout_handler)
    signal.alarm(timeout_seconds)
    try:
        return input().strip()
    except _FrqInputTimeoutError:
        return None
    finally:
        signal.alarm(0)
        signal.signal(signal.SIGALRM, previous_handler)


def _run_git_command(arguments: list[str], *, cwd: Path) -> str:
    result = subprocess.run(
        ["git", *arguments],
        cwd=str(cwd),
        check=False,
        capture_output=True,
        text=True,
        timeout=GIT_COMMAND_TIMEOUT_SECONDS,
    )
    if result.returncode != 0:
        return ""
    return (result.stdout or "").strip()


def _truncate_text(text: str, *, limit: int) -> str:
    if len(text) <= limit:
        return text
    return text[:limit] + "\n...[truncated]..."


def _build_submission_context(*, cwd: Path) -> str:
    show_stat = _run_git_command(["show", "--stat", "HEAD"], cwd=cwd)
    show_patch = _run_git_command(["show", "HEAD"], cwd=cwd)
    file_list = _run_git_command(["diff-tree", "--no-commit-id", "--name-only", "-r", "HEAD"], cwd=cwd)
    commit_summary = _run_git_command(["log", "-1", "--pretty=format:%h %s"], cwd=cwd)

    return (
        "Commit summary:\n"
        f"{commit_summary or '[unavailable]'}\n\n"
        "Changed files:\n"
        f"{file_list or '[unavailable]'}\n\n"
        "Diff stats:\n"
        f"{show_stat or '[unavailable]'}\n\n"
        "Patch excerpt:\n"
        f"{_truncate_text(show_patch or '[unavailable]', limit=GIT_PATCH_CHAR_LIMIT)}"
    )


def _extract_questions(*, structured_output: Any, assistant_text: str) -> list[str]:
    candidate: Any = structured_output
    if not isinstance(candidate, dict):
        try:
            candidate = json.loads(assistant_text)
        except json.JSONDecodeError:
            return []

    questions: list[str] = []
    for item in candidate.get("questions", []):
        if not isinstance(item, dict):
            continue
        prompt = str(item.get("prompt") or "").strip()
        if prompt:
            questions.append(prompt)
    return questions


def _read_answer_from_terminal(
    *,
    question: str,
    index: int,
    total: int,
    seconds_remaining: int,
) -> tuple[str, bool]:
    FRQ_CONSOLE.print()
    FRQ_CONSOLE.print(f"[meta]FRQ {index}/{total}[/meta]")
    FRQ_CONSOLE.print(f"[interviewer]Technical Interviewer:[/interviewer] {question}")
    FRQ_CONSOLE.print(f"[meta]Time remaining:[/meta] {_format_duration_mm_ss(seconds_remaining)}")
    FRQ_CONSOLE.print(f"[meta]Answer (single line, max {FRQ_ANSWER_CHARACTER_LIMIT} chars):[/meta]")
    while True:
        answer = _read_line_with_timeout(timeout_seconds=seconds_remaining)
        if answer is None:
            return "", True
        if len(answer) <= FRQ_ANSWER_CHARACTER_LIMIT:
            return answer, False
        FRQ_CONSOLE.print(
            "[error]Answer is too long "
            f"({len(answer)} chars). Keep it within {FRQ_ANSWER_CHARACTER_LIMIT} characters.[/error]"
        )


async def _generate_frq_questions(*, cwd: Path) -> tuple[list[str], str | None]:
    context = _build_submission_context(cwd=cwd)
    if "[unavailable]" in context and "Changed files:\n[unavailable]" in context:
        return [], "Unable to read git commit context from HEAD. Commit and push before FRQ."

    prompt = (
        f"Generate exactly {FRQ_QUESTION_COUNT} free-response interview questions based on this submission.\n"
        "Focus on design decisions, bug fixes, tradeoffs, edge cases, and testability.\n\n"
        f"{context}"
    )

    client = ClaudeSDKClient(options=build_technical_interviewer_options(cwd=cwd))
    assistant_text = ""
    structured_output: Any = None

    try:
        await client.connect()
        await client.query(prompt)
        async for message in client.receive_response():
            if isinstance(message, AssistantMessage):
                candidate_text = extract_text_blocks(message.content)
                if len(candidate_text) >= len(assistant_text):
                    assistant_text = candidate_text
            elif isinstance(message, ResultMessage) and message.structured_output is not None:
                structured_output = message.structured_output
    except Exception as error:
        return [], f"Failed to generate FRQ questions: {error}"
    finally:
        await client.disconnect()

    questions = _extract_questions(structured_output=structured_output, assistant_text=assistant_text)
    if len(questions) < FRQ_QUESTION_COUNT:
        return [], "FRQ generation returned invalid output. Try submitting again."
    return questions[:FRQ_QUESTION_COUNT], None


async def run_frq_phase() -> str | None:
    if not settings.assessment_proxy_url or not settings.assessment_proxy_token:
        return "FRQ phase requires ASSESSMENT_PROXY_URL and ASSESSMENT_PROXY_TOKEN."

    session_id = read_assessment_session_id()
    if not session_id:
        return "FRQ phase requires an assessment session id. Run tenx-ai first."

    workspace_directory = resolved_agent_workspace_directory()
    questions, generation_error = await _generate_frq_questions(cwd=workspace_directory)
    if generation_error:
        return generation_error

    answers_payload: list[dict[str, str]] = []
    total_questions = len(questions)
    deadline_monotonic = time.monotonic() + FRQ_SECTION_DURATION_SECONDS
    timed_out = False
    unanswered_start_index: int | None = None
    for index, question in enumerate(questions, start=1):
        remaining_seconds = int(deadline_monotonic - time.monotonic())
        if remaining_seconds <= 0:
            timed_out = True
            unanswered_start_index = index
            break

        answer, timed_out_during_answer = _read_answer_from_terminal(
            question=question,
            index=index,
            total=total_questions,
            seconds_remaining=remaining_seconds,
        )
        answers_payload.append({"question": question, "answer": answer})
        if timed_out_during_answer:
            timed_out = True
            unanswered_start_index = index + 1
            FRQ_CONSOLE.print(
                "\n[error]FRQ timer expired. Unanswered questions will be saved as blank responses.[/error]"
            )
            break

    if timed_out and unanswered_start_index is not None:
        for unanswered_question in questions[unanswered_start_index - 1 :]:
            answers_payload.append({"question": unanswered_question, "answer": ""})

    chat_history = ChatHistoryClient(
        base_url=settings.assessment_proxy_url,
        token=settings.assessment_proxy_token,
    )
    save_error = await chat_history.save_frq_answers(
        {"session_id": session_id, "answers": answers_payload}
    )
    if save_error:
        return save_error

    if timed_out:
        FRQ_CONSOLE.print(
            "\n[meta]Saved FRQ answers (timer expired at 10:00; unanswered responses were blank).[/meta]"
        )
        return None

    FRQ_CONSOLE.print("\n[meta]Saved FRQ answers.[/meta]")
    return None
