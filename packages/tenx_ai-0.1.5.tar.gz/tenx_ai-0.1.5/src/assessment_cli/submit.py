"""Git submit command that stages, commits, and pushes workspace changes."""

from __future__ import annotations

import argparse
import asyncio
import subprocess
import sys

from assessment_cli.config import resolved_agent_workspace_directory
from assessment_cli.frq_phase import run_frq_phase


def _run_git_command(arguments: list[str], *, check: bool = True) -> subprocess.CompletedProcess[str]:
    root_dir = resolved_agent_workspace_directory()
    return subprocess.run(
        ["git", *arguments],
        cwd=str(root_dir),
        check=check,
        capture_output=True,
        text=True,
    )


def _is_git_repository() -> bool:
    result = _run_git_command(["rev-parse", "--is-inside-work-tree"], check=False)
    return result.returncode == 0 and result.stdout.strip() == "true"


def _has_staged_changes() -> bool:
    result = _run_git_command(["diff", "--cached", "--quiet"], check=False)
    if result.returncode == 0:
        return False
    if result.returncode == 1:
        return True
    stderr_text = (result.stderr or "").strip()
    raise SystemExit(stderr_text or "Failed to check staged git diff.")


def parse_arguments() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Stage all changes, create a commit, and push the current branch."
    )
    parser.add_argument(
        "-m",
        "--message",
        default="Assessment submission",
        help="Commit message (default: Assessment submission).",
    )
    return parser.parse_args()


def main() -> None:
    arguments = parse_arguments()
    root_dir = resolved_agent_workspace_directory()
    if not _is_git_repository():
        raise SystemExit(f"Workspace is not a git repository: {root_dir}")

    try:
        _run_git_command(["add", "-A"])
        if _has_staged_changes():
            _run_git_command(["commit", "-m", arguments.message])
            print("Created commit.")
        else:
            print("No staged changes after git add -A; skipping commit.")
        _run_git_command(["push"])
        print("Pushed current branch.")
        print("Starting FRQ phase...")
        frq_error = asyncio.run(run_frq_phase())
        if frq_error:
            print(frq_error, file=sys.stderr)
            raise SystemExit(1)
    except subprocess.CalledProcessError as error:
        stdout_text = (error.stdout or "").strip()
        stderr_text = (error.stderr or "").strip()
        if stdout_text:
            print(stdout_text, file=sys.stderr)
        if stderr_text:
            print(stderr_text, file=sys.stderr)
        raise SystemExit(error.returncode) from error
