"""Parse assistant message text and usage metadata from the Claude Agent SDK."""

from typing import Any


def extract_text_blocks(content: Any) -> str:
    if not isinstance(content, list):
        return ""
    parts: list[str] = []
    for block in content:
        if isinstance(block, dict):
            if block.get("type") == "text" and block.get("text"):
                parts.append(str(block.get("text")))
        else:
            text = getattr(block, "text", None)
            if text:
                parts.append(str(text))
    return "".join(parts)


def extract_usage(message: Any) -> dict[str, Any]:
    usage = getattr(message, "usage", None)
    if isinstance(usage, dict):
        return usage

    result = getattr(message, "result", None)
    if isinstance(result, dict):
        usage_from_result = result.get("usage")
        if isinstance(usage_from_result, dict):
            return usage_from_result
    return {}


def usage_turn_tokens(usage: dict[str, Any]) -> tuple[int, int]:
    input_tokens = usage.get("input_tokens")
    output_tokens = usage.get("output_tokens")
    input_count = input_tokens if isinstance(input_tokens, int) and input_tokens >= 0 else 0
    output_count = output_tokens if isinstance(output_tokens, int) and output_tokens >= 0 else 0
    return input_count, output_count

