"""HTTP client for assessment-proxy sessions, chat messages, and FRQ persistence."""

from __future__ import annotations

import httpx


class ChatHistoryClient:
    def __init__(self, *, base_url: str | None, token: str | None) -> None:
        self.base_url = (base_url or "").rstrip("/")
        self.token = (token or "").strip()
        self._warned_disabled = False

    def _request_headers(self) -> dict[str, str]:
        headers: dict[str, str] = {"Content-Type": "application/json"}
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        return headers

    async def create_session(self) -> tuple[str | None, str | None]:
        """POST /v1/sessions. Returns (session_id, error_message)."""
        if not self.base_url:
            return None, None

        try:
            async with httpx.AsyncClient(timeout=10.0) as http_client:
                response = await http_client.post(
                    f"{self.base_url}/v1/sessions",
                    headers=self._request_headers(),
                )
        except httpx.HTTPError as http_error:
            return None, f"Failed to create assessment session: {http_error}"

        if response.status_code >= 300:
            detail = (response.text or "").strip()
            suffix = f" - {detail}" if detail else ""
            return None, f"Proxy returned HTTP {response.status_code}{suffix}"

        try:
            data = response.json()
        except ValueError:
            return None, "Proxy returned invalid JSON for session creation"

        session_id = data.get("session_id")
        if not session_id:
            return None, "Proxy session response missing session_id"
        return str(session_id), None

    async def save_message(self, payload: dict[str, object]) -> str | None:
        if not self.base_url:
            if self._warned_disabled:
                return None
            self._warned_disabled = True
            return "Assessment proxy URL is not configured; chat history persistence is disabled."

        try:
            async with httpx.AsyncClient(timeout=10.0) as http_client:
                response = await http_client.post(
                    f"{self.base_url}/v1/chat-history/messages",
                    headers=self._request_headers(),
                    json=payload,
                )
        except httpx.HTTPError as http_error:
            return f"Failed to save chat message to assessment proxy: {http_error}"

        if response.status_code >= 300:
            detail = (response.text or "").strip()
            suffix = f" - {detail}" if detail else ""
            return f"Proxy returned HTTP {response.status_code}{suffix}"
        return None

    async def save_frq_answers(self, payload: dict[str, object]) -> str | None:
        if not self.base_url:
            if self._warned_disabled:
                return None
            self._warned_disabled = True
            return "Assessment proxy URL is not configured; FRQ persistence is disabled."

        try:
            async with httpx.AsyncClient(timeout=10.0) as http_client:
                response = await http_client.post(
                    f"{self.base_url}/v1/chat-history/frq",
                    headers=self._request_headers(),
                    json=payload,
                )
        except httpx.HTTPError as http_error:
            return f"Failed to save FRQ answers to assessment proxy: {http_error}"

        if response.status_code >= 300:
            detail = (response.text or "").strip()
            suffix = f" - {detail}" if detail else ""
            return f"Proxy returned HTTP {response.status_code}{suffix}"
        return None
