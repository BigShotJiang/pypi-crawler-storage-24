"""Rich-based terminal UI for prompts, banners, and assistant output."""

from __future__ import annotations

import asyncio
import os
import sys
import time
from typing import Any

from rich.console import Console
from rich.panel import Panel
from rich.rule import Rule
from rich.status import Status
from rich.table import Table
from rich.theme import Theme

try:
    from prompt_toolkit import PromptSession
except Exception:  # optional dependency
    PromptSession = None


CLI_THEME = Theme(
    {
        "title": "bold bright_cyan",
        "label": "bold bright_blue",
        "assistant": "bold cyan",
        "system": "bright_magenta",
        "success": "green",
        "error": "bold red",
        "meta": "dim",
        "prompt": "bold bright_blue",
        "hint": "dim",
    }
)


def _supports_color() -> bool:
    return (
        sys.stdout.isatty()
        and sys.stderr.isatty()
        and os.environ.get("NO_COLOR") is None
    )


def _usage_tokens(usage: dict[str, Any]) -> tuple[int | None, int | None]:
    input_tokens = usage.get("input_tokens")
    output_tokens = usage.get("output_tokens")
    if isinstance(input_tokens, int) and isinstance(output_tokens, int):
        return input_tokens, output_tokens
    return None, None


def _format_duration_mm_ss(total_seconds: int) -> str:
    safe_seconds = max(0, total_seconds)
    minutes, seconds = divmod(safe_seconds, 60)
    return f"{minutes:02d}:{seconds:02d}"


class CLIUI:
    def __init__(self, *, model: str, proxy_url: str | None) -> None:
        self.model = model
        self.proxy_url = (proxy_url or "").strip()
        self.timer_deadline_monotonic: float | None = None
        self.timer_duration_seconds: int | None = None
        self.console = Console(
            theme=CLI_THEME,
            highlight=False,
            no_color=not _supports_color(),
            soft_wrap=False,
        )
        self._session = None
        if PromptSession is not None and sys.stdin.isatty():
            try:
                self._session = PromptSession(bottom_toolbar=self._bottom_toolbar)
            except Exception:
                self._session = None

    def set_timer(self, *, duration_seconds: int, deadline_monotonic: float) -> None:
        self.timer_duration_seconds = duration_seconds
        self.timer_deadline_monotonic = deadline_monotonic

    def _seconds_remaining(self) -> int | None:
        if self.timer_deadline_monotonic is None:
            return None
        return max(0, int(self.timer_deadline_monotonic - time.monotonic()))

    def _bottom_toolbar(self) -> str:
        seconds_remaining = self._seconds_remaining()
        if seconds_remaining is None:
            return ""
        if seconds_remaining == 0:
            return "Assessment timer: 00:00 (time expired)"
        return f"Assessment timer: {_format_duration_mm_ss(seconds_remaining)} remaining"

    def _prompt_pair(self, *, plain_suffix: str, rich_suffix: str) -> tuple[str, str]:
        """Build (plain, rich) prompts; always include live countdown when a timer is active."""
        seconds_remaining = self._seconds_remaining()
        if seconds_remaining is None:
            return plain_suffix, rich_suffix
        label = _format_duration_mm_ss(seconds_remaining)
        plain = f"({label}) {plain_suffix}"
        if seconds_remaining == 0:
            rich = f"[error]({label})[/error] {rich_suffix}"
        else:
            rich = f"[meta]({label})[/meta] {rich_suffix}"
        return plain, rich

    def show_banner(self) -> None:
        timer_line = ""
        if self.timer_duration_seconds is not None:
            timer_line = (
                "\n\n"
                f"[hint]Assessment timer: {_format_duration_mm_ss(self.timer_duration_seconds)}. "
                "Type /time to check remaining time.[/hint]"
            )
        self.console.print(
            Panel(
                "Hi, I'm Tenx AI. I'm here to assist you during this assessment by answering "
                "questions, planning features, and writing code.\n\n"
                f"[hint]Type /help for commands.[/hint]{timer_line}",
                title="[label]Tenx AI[/label]",
                border_style="label",
                expand=True,
                padding=(1, 2),
            )
        )

    def show_help(self) -> None:
        table = Table(title="Commands", title_style="label", show_header=True, header_style="label")
        table.add_column("Command", style="assistant", no_wrap=True)
        table.add_column("Description")
        table.add_row("/help", "Show this command list")
        table.add_row("/status", "Show active model and chat history API status")
        table.add_row("/time", "Show remaining assessment time")
        table.add_row("/meta", "Toggle per-message usage/timing footer")
        table.add_row("/clear", "Start a fresh Claude session")
        table.add_row("/exit or /quit", "Exit the CLI")
        table.add_row("\\ (line ending)", "Continue multiline input on next line")
        self.console.print(table)

    def show_status(self) -> None:
        state = "configured" if self.proxy_url else "not configured"
        self.console.print(
            f"[meta]Model:[/meta] {self.model}  "
            f"[meta]Chat history API:[/meta] {state}"
        )

    def show_session_reset(self) -> None:
        self.console.print("[success]Started a new session.[/success]")

    def show_meta_mode(self, enabled: bool) -> None:
        value = "ON" if enabled else "OFF"
        self.console.print(f"[system]Meta footer {value}.[/system]")

    def show_time_remaining(self) -> None:
        seconds_remaining = self._seconds_remaining()
        if seconds_remaining is None:
            self.console.print("[meta]Assessment timer is not active.[/meta]")
            return
        if seconds_remaining == 0:
            self.console.print("[error]Assessment timer: 00:00 (time expired).[/error]")
            return
        self.console.print(
            f"[meta]Assessment timer remaining:[/meta] {_format_duration_mm_ss(seconds_remaining)}"
        )

    def show_error(self, message: str) -> None:
        self.console.print(Panel(message, title="Error", border_style="error"))

    def rule_you(self) -> None:
        self.console.print(Rule("[label]You[/label]", style="label"))

    def rule_assistant(self) -> None:
        self.console.print(Rule("[assistant]Assistant[/assistant]", style="assistant"))

    def begin_assistant_reply(self) -> None:
        """Add spacing before assistant output."""
        self.print_blank()

    def end_assistant_reply(self) -> None:
        """Mark the end of an assistant reply."""

    def rule_end(self) -> None:
        self.console.print(Rule(style="meta"))

    def start_working(self) -> Status:
        status = self.console.status("[meta]Working...[/meta]", spinner="dots12")
        status.start()
        return status

    def stop_working(self, status: Status | None) -> None:
        if status is None:
            return
        try:
            status.stop()
        except Exception:
            pass

    def print_assistant_reply(self, text: str) -> None:
        """Print a full assistant reply once generation is complete."""
        if not text:
            return
        self.console.print(
            f"[assistant]AI Assistant:[/assistant] {text}",
            highlight=False,
            soft_wrap=True,
        )

    def print_blank(self) -> None:
        self.console.print()

    def print_meta_footer(self, *, duration_ms: int, usage: dict[str, Any]) -> None:
        input_tokens, output_tokens = _usage_tokens(usage)
        if input_tokens is not None and output_tokens is not None:
            self.console.print(
                f"[meta]{duration_ms} ms | input {input_tokens} | output {output_tokens}[/meta]"
            )
            return
        self.console.print(f"[meta]{duration_ms} ms[/meta]")

    async def _input_line_async(self, *, rich_prompt: str, plain_prompt: str) -> str:
        """Read one input line without calling asyncio.run (safe inside run_session's loop)."""
        if self._session is not None:
            return await self._session.prompt_async(plain_prompt)
        return await asyncio.to_thread(self.console.input, rich_prompt)

    async def read_prompt_async(self) -> str:
        plain_p, rich_p = self._prompt_pair(plain_suffix="> ", rich_suffix="[prompt]> [/prompt]")
        line = (await self._input_line_async(rich_prompt=rich_p, plain_prompt=plain_p)).rstrip()
        if not line:
            return ""

        prompt_lines = [line[:-1] if line.endswith("\\") else line]
        while line.endswith("\\"):
            plain_c, rich_c = self._prompt_pair(
                plain_suffix="... ",
                rich_suffix="[prompt]... [/prompt]",
            )
            line = (await self._input_line_async(rich_prompt=rich_c, plain_prompt=plain_c)).rstrip()
            prompt_lines.append(line[:-1] if line.endswith("\\") else line)
        return "\n".join(prompt_lines).strip()

