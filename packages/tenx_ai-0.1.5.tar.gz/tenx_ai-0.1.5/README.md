# assessment-cli

CLI client for Tenx hiring assessments.

## Highlights

- Uses the Claude Agent SDK for local interactive coding sessions.
- Sends cleaned chat messages to `assessment-proxy` over HTTP when configured.

## Setup

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -e ".[dev]"
copy .env.example .env
```

Set `ANTHROPIC_API_KEY` in `.env` before running.

## Run

```bash
tenx-ai
```

The CLI starts a 60-minute assessment timer when the process starts. Use `/time` to display the remaining time.

Set `TENX_ASSESSMENT_DURATION_SECONDS` in `.env` to override the timer length.

Or:

```bash
python -m assessment_cli
```

## Submit changes

Run this from your assessment workspace to stage, commit, and push:

```bash
tenx-submit
```

Optional commit message:

```bash
tenx-submit --message "Assessment submission"
```

After a successful push, `tenx-submit` starts an FRQ phase:

- It generates free-response questions from your most recent commit (`HEAD`).
- It prompts you for answers in the terminal.
- It saves the FRQ question/answer pairs to `assessment-proxy`.

## Chat history persistence

Set these in `.env` to enable persistence:

- `ASSESSMENT_PROXY_URL` (for example `http://localhost:8000`)
- `ASSESSMENT_PROXY_TOKEN` (must match the proxy’s `PROXY_BEARER_SECRET`)

When `ASSESSMENT_PROXY_URL` is unset, the CLI runs without saving chat history to the proxy.

`tenx-ai` writes the active assessment session id to `.tenx/assessment_session_id` in your workspace so `tenx-submit` can reuse the same session for FRQ persistence.

## Breaking change (Phase 0)

The proxy path and JSON shape changed: see [`assessment-proxy/README.md`](../assessment-proxy/README.md).

## Security notes for Codespaces

- Do not store the Supabase secret API key in the CLI.
- Use only proxy URL and bearer token in CLI env.
- Treat `ASSESSMENT_PROXY_TOKEN` as sensitive and rotate if leaked.
