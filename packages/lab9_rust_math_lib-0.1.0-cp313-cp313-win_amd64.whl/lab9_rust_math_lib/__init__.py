from .lab9_rust_math_lib import *

__doc__ = lab9_rust_math_lib.__doc__
if hasattr(lab9_rust_math_lib, "__all__"):
    __all__ = lab9_rust_math_lib.__all__