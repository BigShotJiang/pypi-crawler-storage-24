# excalidraw-mcp

An MCP server that turns **Claude Code** into an Excalidraw diagram generator.

Ask Claude to draw any architecture and it opens instantly in your browser — fully interactive, editable, and exportable.

```
"Draw the architecture of a web3 voting system."
        ↓
Claude calls draw_architecture_diagram
        ↓
Python computes layout + generates Excalidraw scene
        ↓
Browser opens with the diagram
```

## Install

```bash
pip install claude-excalidraw-mcp
```

## Register with Claude Code

```bash
claude mcp add excalidraw excalidraw-mcp
```

> `excalidraw-mcp` here is the **console command** installed by the package — not a separate pip package.

Restart Claude Code. That's it.

## Usage

Just ask Claude naturally:

```
Draw the architecture of a food delivery app.
Draw a CI/CD pipeline diagram.
Draw a microservices architecture for an e-commerce platform.
```

Claude generates the nodes and edges, the server handles layout, shapes, and rendering.

## Shapes (auto-detected from label)

| Shape | Fill | Used for |
|---|---|---|
| Rectangle | Solid | Services, apps, APIs |
| Ellipse | Hachure | Databases, storage, infra |
| Diamond | Cross-hatch | Queues, external APIs |

Override with `"shape": "ellipse"` in the node definition.

## How it works

```
Claude Code (MCP Client)
        │  stdio / JSON-RPC 2.0
        ▼
excalidraw-mcp server
        │
        ├── Sugiyama layout (longest-path layers + barycenter crossing reduction)
        ├── Smart arrow routing (straight → S-curve only when crossing detected)
        └── Excalidraw scene JSON → local HTML → browser
```

## Requirements

- Python 3.11+
- Claude Code CLI
- Internet (first load only — Excalidraw loads via CDN)

## License

MIT
