from pydantic import BaseModel, Field
from typing import List, Optional


class Node(BaseModel):
    id: str
    label: str
    shape: Optional[str] = "rectangle"  # rectangle, ellipse, diamond


class Edge(BaseModel):
    from_node: str = Field(..., alias="from")
    to: str
    label: Optional[str] = None

    model_config = {"populate_by_name": True}


class DiagramInput(BaseModel):
    nodes: List[Node]
    edges: List[Edge]
    title: Optional[str] = None
