"""
Excalidraw HTTP API Server
--------------------------
Run:
    python api_server.py

Endpoints:
    POST /draw-diagram   — generate a diagram, returns { id, url, diagram_url }
    GET  /diagram/{id}   — serve the rendered Excalidraw HTML page
    GET  /               — simple health check
"""

import json
import uuid
import webbrowser
from contextlib import asynccontextmanager

import uvicorn
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel, Field

from excalidraw.scene_builder import build_scene
from excalidraw.url_encoder import build_excalidraw_url, encode_scene

# ── in-memory diagram store ────────────────────────────────────────────────────
_diagrams: dict[str, dict] = {}


# ── request / response models ──────────────────────────────────────────────────

class Node(BaseModel):
    id: str
    label: str
    shape: str | None = None


class Edge(BaseModel):
    from_node: str = Field(..., alias="from")
    to: str
    label: str | None = None

    model_config = {"populate_by_name": True}


class DrawRequest(BaseModel):
    nodes: list[Node]
    edges: list[Edge]
    title: str | None = None
    open_browser: bool = True


class DrawResponse(BaseModel):
    id: str
    title: str
    node_count: int
    edge_count: int
    diagram_url: str          # local server URL  → always works
    excalidraw_url: str       # excalidraw.com URL


# ── app ───────────────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    print("Excalidraw API server running at http://localhost:8000")
    yield

app = FastAPI(
    title="Excalidraw MCP Server",
    description="Generate Excalidraw diagrams via HTTP",
    version="1.0.0",
    lifespan=lifespan,
)


@app.get("/", response_class=JSONResponse)
def health():
    return {"status": "ok", "diagrams_stored": len(_diagrams)}


@app.post("/draw-diagram", response_model=DrawResponse)
def draw_diagram(req: DrawRequest):
    nodes = [n.model_dump() for n in req.nodes]
    edges = [
        {"from": e.from_node, "to": e.to, **({"label": e.label} if e.label else {})}
        for e in req.edges
    ]

    scene = build_scene(nodes, edges)

    diagram_id = str(uuid.uuid4())[:8]
    _diagrams[diagram_id] = {
        "scene": scene,
        "title": req.title or "diagram",
    }

    local_url = f"http://localhost:8000/diagram/{diagram_id}"
    ext_url   = build_excalidraw_url(scene)

    if req.open_browser:
        webbrowser.open(local_url)

    return DrawResponse(
        id=diagram_id,
        title=req.title or "diagram",
        node_count=len(nodes),
        edge_count=len(edges),
        diagram_url=local_url,
        excalidraw_url=ext_url,
    )


@app.get("/diagram/{diagram_id}", response_class=HTMLResponse)
def serve_diagram(diagram_id: str):
    entry = _diagrams.get(diagram_id)
    if not entry:
        raise HTTPException(status_code=404, detail="Diagram not found")

    scene_json = json.dumps(entry["scene"])
    title = entry["title"]

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>{title}</title>
  <style>
    * {{ margin: 0; padding: 0; box-sizing: border-box; }}
    body {{ width: 100vw; height: 100vh; overflow: hidden; }}
    #root {{ width: 100%; height: 100%; }}
  </style>
</head>
<body>
  <div id="root"></div>
  <script>window.EXCALIDRAW_ASSET_PATH = "https://unpkg.com/@excalidraw/excalidraw@0.17.6/dist/";</script>
  <script src="https://unpkg.com/react@18/umd/react.production.min.js" crossorigin></script>
  <script src="https://unpkg.com/react-dom@18/umd/react-dom.production.min.js" crossorigin></script>
  <script src="https://unpkg.com/@excalidraw/excalidraw@0.17.6/dist/excalidraw.production.min.js" crossorigin></script>
  <script>
    const {{ Excalidraw }} = ExcalidrawLib;
    const initialData = {scene_json};

    function App() {{
      return React.createElement(Excalidraw, {{
        initialData: initialData,
        UIOptions: {{ canvasActions: {{ export: {{ saveFileToDisk: true }} }} }},
      }});
    }}

    const container = document.getElementById("root");
    const rootEl = ReactDOM.createRoot(container);
    rootEl.render(React.createElement(App));
  </script>
</body>
</html>"""

    return HTMLResponse(content=html)


@app.get("/diagrams", response_class=JSONResponse)
def list_diagrams():
    return [
        {"id": did, "title": d["title"]}
        for did, d in _diagrams.items()
    ]


if __name__ == "__main__":
    uvicorn.run("api_server:app", host="0.0.0.0", port=8000, reload=True)
