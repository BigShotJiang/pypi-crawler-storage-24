# Excalidraw MCP Server (Python) — Implementation Guide

## Project Goal

Build a **Model Context Protocol (MCP) server in Python** that allows Claude Code to generate diagrams in **Excalidraw Web automatically**.

User flow:

```
Claude Code prompt
      ↓
Claude calls MCP tool
      ↓
Python MCP server generates Excalidraw scene JSON
      ↓
Server encodes scene into Excalidraw URL
      ↓
Browser opens https://excalidraw.com with the diagram already rendered
```

The user should see **Excalidraw open automatically with the generated diagram**.

---

# High-Level Architecture

```
Claude Code
   │
   │ MCP Tool Call
   ▼
Python MCP Server
   │
   │ Generate Excalidraw Scene JSON
   ▼
URL Encoder
   │
   │ https://excalidraw.com/#json=<encoded_scene>
   ▼
Browser Opens Excalidraw
   │
   ▼
Diagram Appears Automatically
```

---

# Tech Stack

Python components:

```
fastapi
uvicorn
pydantic
networkx (optional for auto layout)
```

Standard libraries:

```
json
urllib.parse
webbrowser
uuid
```

---

# Project Structure

```
mcp-excalidraw/
│
├── server.py
│
├── tools/
│   └── draw_diagram.py
│
├── excalidraw/
│   ├── scene_builder.py
│   └── url_encoder.py
│
├── models/
│   └── diagram_models.py
│
└── requirements.txt
```

---

# Core Responsibilities

## 1. MCP Server

Responsibilities:

• expose diagram generation tools
• receive structured requests from Claude
• call diagram generation pipeline

Example endpoint:

```
POST /draw-diagram
```

---

# Data Model (Input from Claude)

Claude should **NOT generate coordinates**.

Claude outputs logical structure only.

Example input schema:

```json
{
  "nodes": [
    { "id": "user", "label": "User" },
    { "id": "wallet", "label": "Wallet" },
    { "id": "contract", "label": "Smart Contract" }
  ],
  "edges": [
    { "from": "user", "to": "wallet" },
    { "from": "wallet", "to": "contract" }
  ]
}
```

The server will compute layout.

---

# Layout Generation

Use a graph layout algorithm so diagrams look clean.

Recommended library:

```
networkx
```

Example idea:

```
1. Build graph
2. Compute layout positions
3. Convert nodes to Excalidraw rectangles
4. Convert edges to arrows
```

Example:

```python
import networkx as nx

G = nx.DiGraph()

for node in nodes:
    G.add_node(node["id"])

for edge in edges:
    G.add_edge(edge["from"], edge["to"])

positions = nx.spring_layout(G)
```

Positions then map to canvas coordinates.

---

# Excalidraw Scene Format

Excalidraw uses a JSON structure.

Basic scene:

```json
{
  "type": "excalidraw",
  "version": 2,
  "elements": [],
  "appState": {},
  "files": {}
}
```

---

# Rectangle Element Example

```json
{
  "id": "node1",
  "type": "rectangle",
  "x": 100,
  "y": 200,
  "width": 200,
  "height": 80,
  "strokeColor": "#000000"
}
```

---

# Arrow Element Example

```json
{
  "id": "edge1",
  "type": "arrow",
  "x": 0,
  "y": 0,
  "points": [[0,0],[200,0]]
}
```

---

# Scene Builder

Responsibilities:

```
nodes → rectangles
edges → arrows
assemble scene JSON
```

Example function:

```python
def build_scene(nodes, edges):
    scene = {
        "type": "excalidraw",
        "version": 2,
        "elements": [],
        "appState": {},
        "files": {}
    }

    # add rectangles and arrows here

    return scene
```

---

# URL Encoding

Excalidraw can load scenes from the URL.

Pattern:

```
https://excalidraw.com/#json=<encoded_scene>
```

Python encoding:

```python
import urllib.parse
import json

encoded = urllib.parse.quote(json.dumps(scene))
url = f"https://excalidraw.com/#json={encoded}"
```

---

# Opening Excalidraw Automatically

Use the Python `webbrowser` module.

```python
import webbrowser

webbrowser.open(url)
```

Result:

• Browser launches
• Excalidraw loads
• Diagram appears automatically

---

# MCP Tool Definition

Tool name:

```
draw_architecture_diagram
```

Description:

```
Generate a system architecture diagram in Excalidraw.
```

Input schema:

```json
{
  "type": "object",
  "properties": {
    "nodes": {
      "type": "array"
    },
    "edges": {
      "type": "array"
    }
  }
}
```

---

# Example Claude Prompt

User writes in Claude Code:

```
Draw the architecture of a web3 voting system.
```

Claude generates tool call:

```json
{
  "nodes": [
    {"id":"user","label":"User"},
    {"id":"frontend","label":"Frontend"},
    {"id":"wallet","label":"Wallet"},
    {"id":"contract","label":"Smart Contract"},
    {"id":"ipfs","label":"IPFS"}
  ],
  "edges":[
    {"from":"user","to":"frontend"},
    {"from":"frontend","to":"wallet"},
    {"from":"wallet","to":"contract"},
    {"from":"contract","to":"ipfs"}
  ]
}
```

Server generates diagram.

Excalidraw opens with full architecture visualization.

---

# Stretch Goals (Optional)

## 1. Diagram Types

Allow Claude to generate:

```
flowcharts
architecture diagrams
sequence diagrams
mind maps
```

---

## 2. Auto Styling

Add themes:

```
dark mode diagrams
color coded services
different shapes for components
```

---

## 3. Better Layout

Replace spring layout with:

```
dagre
graphviz
```

This produces much cleaner architecture diagrams.

---

# Development Steps

Step 1
Create FastAPI server.

Step 2
Implement diagram input schema.

Step 3
Convert nodes → Excalidraw rectangles.

Step 4
Convert edges → arrows.

Step 5
Build scene JSON.

Step 6
Encode scene into Excalidraw URL.

Step 7
Open browser automatically.

---

# Expected Outcome

Working flow:

```
User prompt in Claude Code
      ↓
Claude calls MCP tool
      ↓
Python server generates scene
      ↓
Browser opens Excalidraw
      ↓
Diagram appears instantly
```

This effectively turns Claude into a **diagram generator that draws directly in Excalidraw web**.

---

# Key Design Principle

Claude generates **logical diagrams**.

Python handles **layout, rendering, and integration**.

This keeps diagrams clean and reliable.
