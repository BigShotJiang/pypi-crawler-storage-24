import json
import tempfile
import os
import urllib.parse

try:
    from lzstring import LZString
    _HAS_LZSTRING = True
except ImportError:
    _HAS_LZSTRING = False


def encode_scene(scene: dict) -> str:
    """Encode scene dict to a string suitable for Excalidraw URL hash."""
    scene_json = json.dumps(scene, separators=(",", ":"))

    if _HAS_LZSTRING:
        lz = LZString()
        return lz.compressToEncodedURIComponent(scene_json)
    else:
        # Fallback: plain URL encoding (may not render on excalidraw.com but
        # will still work with the local HTML approach)
        return urllib.parse.quote(scene_json)


def build_excalidraw_url(scene: dict) -> str:
    """Build an excalidraw.com URL that loads the given scene."""
    encoded = encode_scene(scene)
    return f"https://excalidraw.com/#json={encoded}"


def build_local_html(scene: dict) -> str:
    """Write a standalone HTML file that embeds Excalidraw and opens the scene.

    Returns the path to the generated HTML file.
    """
    scene_json = json.dumps(scene)

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>Excalidraw Diagram</title>
  <style>
    * {{ margin: 0; padding: 0; box-sizing: border-box; }}
    body {{ width: 100vw; height: 100vh; overflow: hidden; }}
    #root {{ width: 100%; height: 100%; }}
  </style>
</head>
<body>
  <div id="root"></div>
  <script>window.EXCALIDRAW_ASSET_PATH = "https://unpkg.com/@excalidraw/excalidraw@0.17.6/dist/";</script>
  <script src="https://unpkg.com/react@18/umd/react.production.min.js" crossorigin></script>
  <script src="https://unpkg.com/react-dom@18/umd/react-dom.production.min.js" crossorigin></script>
  <script src="https://unpkg.com/@excalidraw/excalidraw@0.17.6/dist/excalidraw.production.min.js" crossorigin></script>
  <script>
    const {{ Excalidraw }} = ExcalidrawLib;
    const initialData = {scene_json};

    function App() {{
      return React.createElement(Excalidraw, {{
        initialData: initialData,
        UIOptions: {{ canvasActions: {{ export: {{ saveFileToDisk: true }} }} }},
      }});
    }}

    const container = document.getElementById("root");
    const rootEl = ReactDOM.createRoot(container);
    rootEl.render(React.createElement(App));
  </script>
</body>
</html>
"""

    tmp = tempfile.NamedTemporaryFile(
        suffix=".html", prefix="excalidraw_", delete=False, mode="w", encoding="utf-8"
    )
    tmp.write(html)
    tmp.close()
    return tmp.name
