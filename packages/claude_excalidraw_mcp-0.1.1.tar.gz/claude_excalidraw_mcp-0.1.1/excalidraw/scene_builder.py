"""
scene_builder.py
----------------
Arrow routing strategy
----------------------
• Forward, non-crossing  → straight 2-point line   (clean, no curve)
• Forward, crossing pair → ONE of the pair gets a
  small perpendicular arc to lift it above the cross
• Backward / same-col   → arc looping above nodes

Layout: Sugiyama longest-path layers + barycenter crossing reduction (6 passes)
Ports:  spread attachment points on right/left edges, ordered by partner y-pos
"""

import time
import networkx as nx
from collections import defaultdict
from typing import Any

# ── geometry ──────────────────────────────────────────────────────────────────
RECT_W      = 190
RECT_MIN_H  = 68
FONT_SIZE   = 13
LINE_H      = 1.3
H_GAP       = 330
V_GAP       = 150

SHAPE_CFG = {           # type, fillStyle, w-scale, h-scale
    "rectangle": ("rectangle", "solid",       1.00, 1.00),
    "ellipse":   ("ellipse",   "hachure",     1.05, 1.10),
    "diamond":   ("diamond",   "cross-hatch", 1.20, 1.25),
}

SHAPE_RULES: list[tuple[list[str], str]] = [
    (["postgresql","postgres","mongodb","mongo","mysql","redis","sqlite",
      "database"," db","s3 ","s3\n","storage","cache","elasticsearch",
      "dynamo","cassandra","assets","images","files"], "ellipse"),
    (["kafka","rabbitmq","queue","pubsub","event bus","message bus",
      "stream","nats","sqs","sns"], "diamond"),
    (["stripe","paypal","braintree","sendgrid","twilio","mailgun",
      "firebase","auth0","okta","external","third-party","webhook"], "diamond"),
    (["kubernetes","k8s","docker","nginx","load balancer","cdn",
      "cloudfront","prometheus","grafana","ci/cd","pipeline",
      "monitoring","cluster","jenkins","circleci"], "ellipse"),
]

COLORS = [
    "#a5d8ff","#b2f2bb","#ffd8a8","#ffa8a8",
    "#e8d5ff","#fff3bf","#c5f6fa","#f8d7da",
]

# ── helpers ───────────────────────────────────────────────────────────────────

def _seed():  return int(time.time()*1000) % 1_000_000
def _ts():    return int(time.time()*1000)

def _base(eid, x, y, w, h) -> dict[str, Any]:
    return {
        "id": eid,
        "x": round(x), "y": round(y),
        "width": max(1, round(w)), "height": max(1, round(h)),
        "angle": 0,
        "strokeColor": "#1e1e1e", "backgroundColor": "transparent",
        "fillStyle": "solid", "strokeWidth": 2, "strokeStyle": "solid",
        "roughness": 1, "opacity": 100,
        "groupIds": [], "frameId": None, "roundness": None,
        "seed": _seed(), "version": 1, "versionNonce": _seed(),
        "isDeleted": False, "boundElements": [],
        "updated": _ts(), "link": None, "locked": False,
    }

# ── shape detection ───────────────────────────────────────────────────────────

def _detect_shape(label: str, explicit: str | None) -> str:
    if explicit in SHAPE_CFG:
        return explicit
    low = label.lower()
    for keywords, shape in SHAPE_RULES:
        if any(k in low for k in keywords):
            return shape
    return "rectangle"

# ── node ──────────────────────────────────────────────────────────────────────

def _node_h(label: str, hs: float) -> float:
    return max(RECT_MIN_H * hs, (label.count("\n")+1)*FONT_SIZE*LINE_H + 24)

def _make_node(nid, label, x, y, color, shape):
    et, fs, ws, hs = SHAPE_CFG[shape]
    w = round(RECT_W * ws)
    h = round(_node_h(label, hs))
    grp = nid+"_grp"

    elem = _base(nid+"_shape", x, y, w, h)
    elem["type"] = et
    elem["backgroundColor"] = color
    elem["fillStyle"] = fs
    elem["groupIds"] = [grp]
    if et == "rectangle":
        elem["roundness"] = {"type": 3}

    text_h = (label.count("\n")+1)*FONT_SIZE*LINE_H
    text = _base(nid+"_text", x, y+(h-text_h)/2, w, text_h)
    text.update({"type":"text","strokeWidth":1,"text":label,"originalText":label,
                 "fontSize":FONT_SIZE,"fontFamily":1,"textAlign":"center",
                 "verticalAlign":"middle","lineHeight":LINE_H,"groupIds":[grp]})
    return elem, text, w, h

# ── arrow helpers ─────────────────────────────────────────────────────────────

def _seg_cross(ax,ay,bx,by, cx,cy,dx,dy) -> bool:
    """True if segments AB and CD properly intersect."""
    def ccw(px,py,qx,qy,rx,ry):
        return (ry-py)*(qx-px) > (qy-py)*(rx-px)
    return (ccw(ax,ay,cx,cy,dx,dy) != ccw(bx,by,cx,cy,dx,dy) and
            ccw(ax,ay,bx,by,cx,cy) != ccw(ax,ay,bx,by,dx,dy))

def _arrow_elem(aid, pts: list[list[float]], curved: bool) -> dict:
    """Build an Excalidraw arrow element from absolute point list."""
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    ox, oy = min(xs), min(ys)
    a = _base(aid, ox, oy, max(max(xs)-ox,1), max(max(ys)-oy,1))
    a.update({
        "type": "arrow",
        "roundness": {"type": 2} if curved else None,
        "points": [[round(p[0]-ox), round(p[1]-oy)] for p in pts],
        "lastCommittedPoint": None,
        "startBinding": None, "endBinding": None,
        "startArrowhead": None, "endArrowhead": "arrow",
    })
    return a

def _straight_pts(sx,sy,ex,ey):
    return [[sx,sy],[ex,ey]]

def _scurve_pts(sx,sy,ex,ey):
    dx,dy = ex-sx, ey-sy
    cf = max(0.35, min(0.65, abs(dy)/(abs(dx)+1)*0.3+0.4))
    return [[sx,sy],[sx+dx*cf,sy],[sx+dx*(1-cf),ey],[ex,ey]]

def _arc_above_pts(sx,sy,ex,ey):
    """Arc that bends upward (for backward / same-col edges)."""
    mx = (sx+ex)/2
    top = min(sy,ey) - max(abs(ey-sy)*0.5+90, 80)
    return [[sx,sy],[mx,top],[ex,ey]]

# ── layout ────────────────────────────────────────────────────────────────────

def _build_dag(nodes, edges):
    ids = {n["id"] for n in nodes}
    G = nx.DiGraph()
    G.add_nodes_from(ids)
    for e in edges:
        f = e.get("from") or e.get("from_node","")
        t = e.get("to","")
        if f in ids and t in ids:
            G.add_edge(f, t)
    while True:
        try:    cycle = nx.find_cycle(G); G.remove_edge(*cycle[-1])
        except nx.NetworkXNoCycle: break
    return G

def _assign_layers(G):
    lyr = {}
    for n in nx.topological_sort(G):
        preds = list(G.predecessors(n))
        lyr[n] = 0 if not preds else max(lyr[p] for p in preds)+1
    return lyr

def _barycenter(cols, G, passes=6):
    for _ in range(passes):
        for i in range(1, len(cols)):
            prev = {n:j for j,n in enumerate(cols[i-1])}
            cols[i].sort(key=lambda n: (
                sum(prev[p] for p in G.predecessors(n) if p in prev) /
                max(1, sum(1 for p in G.predecessors(n) if p in prev))))
        for i in range(len(cols)-2,-1,-1):
            nxt = {n:j for j,n in enumerate(cols[i+1])}
            cols[i].sort(key=lambda n: (
                sum(nxt[s] for s in G.successors(n) if s in nxt) /
                max(1, sum(1 for s in G.successors(n) if s in nxt))))

def _compute_layout(nodes, edges):
    G    = _build_dag(nodes, edges)
    lmap = _assign_layers(G)
    nc   = max(lmap.values(), default=0)+1
    cols: list[list[str]] = [[] for _ in range(nc)]
    for nid,col in lmap.items(): cols[col].append(nid)
    for nd in nodes:
        if nd["id"] not in {n for c in cols for n in c}: cols[0].append(nd["id"])
    _barycenter(cols, G)
    max_n = max(len(c) for c in cols) if cols else 1
    layout = {}
    for ci,col in enumerate(cols):
        n = len(col)
        off = (max_n-n)*V_GAP/2
        for ri,nid in enumerate(col):
            layout[nid] = (100+ci*H_GAP, 80+off+ri*V_GAP)
    return layout

# ── scene assembly ────────────────────────────────────────────────────────────

def build_scene(nodes: list, edges: list) -> dict:
    layout   = _compute_layout(nodes, edges)
    elements = []
    bounds: dict[str, tuple[float,float,float,float]] = {}   # x,y,w,h

    # ── nodes ──
    for i, node in enumerate(nodes):
        color = COLORS[i % len(COLORS)]
        x,y   = layout.get(node["id"], (i*(RECT_W+40), 100))
        label = node.get("label", node["id"])
        shape = _detect_shape(label, node.get("shape"))
        elem, text, w, h = _make_node(node["id"], label, x, y, color, shape)
        bounds[node["id"]] = (x, y, w, h)
        elements += [elem, text]

    # ── valid edges ──
    valid: list[tuple[str,str]] = []
    for e in edges:
        f = e.get("from") or e.get("from_node","")
        t = e.get("to","")
        if f in bounds and t in bounds:
            valid.append((f,t))

    def cy(nid): _, y, _, h = bounds[nid]; return y+h/2

    # spread ports sorted by partner cy
    out_s: dict[str,list[str]] = defaultdict(list)
    for f,t in valid: out_s[f].append(t)
    for f in out_s: out_s[f] = sorted(set(out_s[f]), key=cy)

    in_s: dict[str,list[str]] = defaultdict(list)
    for f,t in valid: in_s[t].append(f)
    for t in in_s: in_s[t] = sorted(set(in_s[t]), key=cy)

    # ── compute all arrow candidate positions (straight first) ──
    arrow_data: list[tuple[str,float,float,float,float,bool]] = []  # id,sx,sy,ex,ey,backward

    for i,(fid,tid) in enumerate(valid):
        rx,ry,rw,rh = bounds[fid]
        tx,ty,tw,th = bounds[tid]
        backward = (tx+tw/2) < (rx+rw/2)

        if backward:
            sx,sy = rx+rw/2, ry-2
            ex,ey = tx+tw/2, ty-2
        else:
            ol = out_s[fid]; oi = ol.index(tid); on = len(ol)
            sx = rx+rw;  sy = ry+rh*(oi+1)/(on+1)
            il = in_s[tid]; ii = il.index(fid); iin = len(il)
            ex = tx;     ey = ty+th*(ii+1)/(iin+1)

        aid = f"arr_{i}_{fid[:5]}_{tid[:5]}"
        arrow_data.append((aid, sx, sy, ex, ey, backward))

    # ── crossing detection: mark arrows that cross another ──
    # For each crossing pair, mark the one with larger index as "needs curve"
    needs_curve = set()
    fwd = [(i,d) for i,d in enumerate(arrow_data) if not d[5]]
    for i in range(len(fwd)):
        for j in range(i+1, len(fwd)):
            _,  (aid1,sx1,sy1,ex1,ey1,_) = fwd[i]
            _, (aid2,sx2,sy2,ex2,ey2,_) = fwd[j]
            if _seg_cross(sx1,sy1,ex1,ey1, sx2,sy2,ex2,ey2):
                needs_curve.add(aid2)   # curve the second one

    # ── build arrow elements ──
    for (aid, sx, sy, ex, ey, backward) in arrow_data:
        if backward:
            pts = _arc_above_pts(sx, sy, ex, ey)
            curved = True
        elif aid in needs_curve:
            pts = _scurve_pts(sx, sy, ex, ey)
            curved = True
        else:
            pts = _straight_pts(sx, sy, ex, ey)
            curved = False
        elements.append(_arrow_elem(aid, pts, curved))

    return {
        "type":"excalidraw","version":2,
        "source":"https://excalidraw.com",
        "elements": elements,
        "appState":{"viewBackgroundColor":"#ffffff","gridSize":None},
        "files":{},
    }
