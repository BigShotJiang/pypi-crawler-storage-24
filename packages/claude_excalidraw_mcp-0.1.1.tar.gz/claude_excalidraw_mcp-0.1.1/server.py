"""
Excalidraw MCP Server
---------------------
Exposes the `draw_architecture_diagram` tool so Claude Code can generate
Excalidraw diagrams from logical node/edge descriptions.

Run with:
    python server.py

Then add to Claude Code's MCP config:
    {
      "mcpServers": {
        "excalidraw": {
          "command": "python",
          "args": ["/absolute/path/to/server.py"]
        }
      }
    }
"""

import asyncio
import json
import sys
import traceback

import mcp.types as types
from mcp.server import Server
from mcp.server.stdio import stdio_server

from tools.draw_diagram import draw_diagram

app = Server("excalidraw-mcp")

TOOL_NAME = "draw_architecture_diagram"

INPUT_SCHEMA = {
    "type": "object",
    "properties": {
        "nodes": {
            "type": "array",
            "description": "List of nodes in the diagram.",
            "items": {
                "type": "object",
                "properties": {
                    "id": {
                        "type": "string",
                        "description": "Unique identifier for the node (no spaces).",
                    },
                    "label": {
                        "type": "string",
                        "description": "Display label shown inside the shape.",
                    },
                    "shape": {
                        "type": "string",
                        "enum": ["rectangle", "ellipse", "diamond"],
                        "description": "Shape type (default: rectangle).",
                    },
                },
                "required": ["id", "label"],
            },
        },
        "edges": {
            "type": "array",
            "description": "List of directed edges connecting nodes.",
            "items": {
                "type": "object",
                "properties": {
                    "from": {
                        "type": "string",
                        "description": "Source node id.",
                    },
                    "to": {
                        "type": "string",
                        "description": "Target node id.",
                    },
                    "label": {
                        "type": "string",
                        "description": "Optional label on the arrow.",
                    },
                },
                "required": ["from", "to"],
            },
        },
        "title": {
            "type": "string",
            "description": "Optional title for the diagram (used in status messages).",
        },
    },
    "required": ["nodes", "edges"],
}


@app.list_tools()
async def handle_list_tools() -> list[types.Tool]:
    return [
        types.Tool(
            name=TOOL_NAME,
            description=(
                "Generate a system architecture diagram in Excalidraw. "
                "Provide nodes (id + label) and directed edges (from + to). "
                "The server handles layout automatically and opens the diagram "
                "in the browser."
            ),
            inputSchema=INPUT_SCHEMA,
        )
    ]


@app.call_tool()
async def handle_call_tool(
    name: str, arguments: dict | None
) -> list[types.TextContent]:
    if name != TOOL_NAME:
        raise ValueError(f"Unknown tool: {name}")

    if not arguments:
        raise ValueError("No arguments provided.")

    nodes = arguments.get("nodes", [])
    edges = arguments.get("edges", [])
    title = arguments.get("title")

    if not nodes:
        return [types.TextContent(type="text", text="Error: 'nodes' list is empty.")]

    try:
        result = draw_diagram(nodes, edges, title)
        return [types.TextContent(type="text", text=result["message"])]
    except Exception as exc:
        tb = traceback.format_exc()
        error_msg = f"Failed to generate diagram: {exc}\n\n{tb}"
        return [types.TextContent(type="text", text=error_msg)]


async def main() -> None:
    async with stdio_server() as (read_stream, write_stream):
        await app.run(
            read_stream,
            write_stream,
            app.create_initialization_options(),
        )


if __name__ == "__main__":
    asyncio.run(main())
