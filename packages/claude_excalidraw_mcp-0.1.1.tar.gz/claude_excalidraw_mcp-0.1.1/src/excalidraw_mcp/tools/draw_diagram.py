import os
import subprocess
import sys
from typing import Any

from excalidraw_mcp.excalidraw.scene_builder import build_scene
from excalidraw_mcp.excalidraw.url_encoder import build_excalidraw_url, build_local_html


def _normalise_edges(edges: list[dict]) -> list[dict]:
    result = []
    for e in edges:
        normalised = dict(e)
        if "from_node" in normalised and "from" not in normalised:
            normalised["from"] = normalised.pop("from_node")
        result.append(normalised)
    return result


def draw_diagram(nodes: list[dict], edges: list[dict], title: str | None = None) -> dict[str, Any]:
    edges = _normalise_edges(edges)
    scene = build_scene(nodes, edges)

    url            = build_excalidraw_url(scene)
    local_html_path = build_local_html(scene)
    local_file_url  = f"file:///{local_html_path.replace(chr(92), '/')}"

    if sys.platform == "win32":
        os.startfile(local_html_path)
    elif sys.platform == "darwin":
        subprocess.Popen(["open", local_html_path])
    else:
        subprocess.Popen(["xdg-open", local_html_path])

    node_count = len(nodes)
    edge_count = len(edges)
    label = title or "architecture diagram"

    message = (
        f"Generated {label} with {node_count} nodes and {edge_count} edges.\n"
        f"Browser opened with the diagram.\n\n"
        f"Local HTML: {local_html_path}\n"
        f"Excalidraw.com URL: {url}"
    )

    return {"url": url, "local_html": local_html_path, "local_url": local_file_url, "message": message}
