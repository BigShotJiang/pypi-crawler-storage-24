"""excalidraw-mcp — MCP server that generates Excalidraw diagrams from Claude Code."""

__version__ = "0.1.0"
