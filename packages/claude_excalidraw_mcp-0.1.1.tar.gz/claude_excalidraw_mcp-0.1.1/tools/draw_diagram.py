import os
import subprocess
import sys
from typing import Any

from excalidraw.scene_builder import build_scene
from excalidraw.url_encoder import build_excalidraw_url, build_local_html


def _normalise_edges(edges: list[dict]) -> list[dict]:
    """Ensure edges always have a 'from' key regardless of how they arrived."""
    result = []
    for e in edges:
        normalised = dict(e)
        # Pydantic may have serialised the alias as 'from_node'
        if "from_node" in normalised and "from" not in normalised:
            normalised["from"] = normalised.pop("from_node")
        result.append(normalised)
    return result


def draw_diagram(nodes: list[dict], edges: list[dict], title: str | None = None) -> dict[str, Any]:
    """
    Build an Excalidraw diagram from logical nodes/edges.

    Returns a dict with keys:
      - url       : excalidraw.com URL (requires lzstring encoding to render)
      - local_html: path to a standalone HTML file that always works
      - message   : human-readable status
    """
    edges = _normalise_edges(edges)

    scene = build_scene(nodes, edges)

    # Build excalidraw.com URL
    url = build_excalidraw_url(scene)

    # Build a local HTML fallback that is always reliable
    local_html_path = build_local_html(scene)

    # Open the local HTML file in the default browser (reliable on Windows)
    local_file_url = f"file:///{local_html_path.replace(chr(92), '/')}"
    if sys.platform == "win32":
        os.startfile(local_html_path)
    elif sys.platform == "darwin":
        subprocess.Popen(["open", local_html_path])
    else:
        subprocess.Popen(["xdg-open", local_html_path])

    node_count = len(nodes)
    edge_count = len(edges)
    label = title or "architecture diagram"

    message = (
        f"Generated {label} with {node_count} nodes and {edge_count} edges.\n"
        f"Browser opened with the diagram.\n\n"
        f"Local HTML (always works): {local_html_path}\n"
        f"Excalidraw.com URL: {url}"
    )

    return {
        "url": url,
        "local_html": local_html_path,
        "local_url": local_file_url,
        "message": message,
    }
