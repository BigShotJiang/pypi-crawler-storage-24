import os
import re
import json
from tqdm import tqdm
from torch.utils.data import DataLoader
from .mirc_torch_dataset import MIRCTorchDataset


def load_dataset_masks(root_folder):
    json_data = {}

    all_json_files = []

    for current_root, _, files in os.walk(root_folder):
        for file_name in files:
            if file_name.endswith(".json"):
                all_json_files.append(os.path.join(current_root, file_name))

    for file_path in tqdm(all_json_files):
        file_name = os.path.basename(file_path)

        with open(file_path, "r", encoding="utf-8") as f:
            raw_content = json.load(f)

        key = _process_json_key(file_path, file_name)
        content = _build_simplified_json_content(
            folder_path=os.path.dirname(file_path),
            raw_content=raw_content
        )

        json_data[key] = content

        del raw_content
        del content

    return json_data


def _process_json_key(file_path, file_name):
    subject_id, activity_id, routine_id, cam_id = _extract_ids_from_path(file_path)
    frame_id = _extract_frame_id_from_filename(file_name)

    return f"{subject_id}_{activity_id}_{routine_id}_{cam_id}_{frame_id}"


def _extract_ids_from_path(file_path):
    normalized_path = os.path.normpath(file_path)

    pattern = r"subject(\d+)[/\\]+activity(\d+)[/\\]+routine(\d+)_cam(\d+)"
    match = re.search(pattern, normalized_path, re.IGNORECASE)

    if not match:
        raise ValueError(f"Not possible to extract IDs from the folder: {file_path}")

    subject_id, activity_id, routine_id, cam_id = match.groups()

    return int(subject_id), int(activity_id), int(routine_id), int(cam_id)


def _extract_frame_id_from_filename(file_name):
    pattern = r"_(\d+)\.json$"
    match = re.search(pattern, file_name, re.IGNORECASE)

    if not match:
        raise ValueError(f"Not possible to extract info from file: {file_name}")

    return match.group(1)


def _build_simplified_json_content(folder_path, raw_content):
    objects = []

    for shape in raw_content.get("shapes", []):
        objects.append({
            "label": shape.get("label"),
            "points": shape.get("points", [])
        })

    image_path_in_json = raw_content.get("imagePath", "")
    full_image_path = os.path.join(folder_path, image_path_in_json)

    simplified_content = {
        "objects": objects,
        "image_height": raw_content.get("imageHeight"),
        "image_width": raw_content.get("imageWidth"),
        "image_path": full_image_path
    }

    return simplified_content


def split_dataset_by_subject_cross_validation(dataset_dict, k):
    subject_folds = _split_subjects_for_cross_validation(dataset_dict, k)

    subject_to_fold = {}

    for fold_index, fold_subjects in enumerate(subject_folds):
        for subject_index in fold_subjects:
            subject_to_fold[subject_index] = fold_index

    splitted_dicts = [dict() for _ in range(len(subject_folds))]

    keys_to_move = list(dataset_dict.keys())

    for key in keys_to_move:
        parts = key.split("_")

        if len(parts) < 5:
            raise ValueError(f"Invalid key format: {key}")

        subject_index = int(parts[0])

        if subject_index not in subject_to_fold:
            raise ValueError(f"Subject index {subject_index} not found in fold mapping")

        fold_index = subject_to_fold[subject_index]
        splitted_dicts[fold_index][key] = dataset_dict.pop(key)

    return splitted_dicts


def _split_subjects_for_cross_validation(dataset_dict, k):
    if k <= 1:
        raise ValueError("k must be greater than 1")

    subject_indices = _get_unique_subject_indices(dataset_dict)
    total_subjects = len(subject_indices)

    if total_subjects == 0:
        return []

    folds = [[] for _ in range(k)]

    base_size = total_subjects // k
    remainder = total_subjects % k

    current_index = 0

    for fold_index in range(k):
        extra = 1 if fold_index < remainder else 0
        fold_size = base_size + extra

        if fold_size > 0:
            folds[fold_index] = subject_indices[current_index:current_index + fold_size]
            current_index += fold_size

    return folds


def _get_unique_subject_indices(dataset_dict):
    subject_indices = set()

    for key in dataset_dict.keys():
        parts = key.split("_")

        if len(parts) < 5:
            raise ValueError(f"Invalid key format: {key}")

        subject_indices.add(int(parts[0]))

    return sorted(subject_indices)


def create_dataloaders(dataset_folds, batch_size=32, transform=None, mask_mode=None, num_workers=0, pin_memory=False):
    if len(dataset_folds) <= 1:
        raise ValueError("dataset_folds must contain at least 2 folds")

    dataloaders = []
    total_folds = len(dataset_folds)

    for val_fold_index in range(total_folds):
        train_partitions = [dataset_folds[i] for i in range(total_folds) if i != val_fold_index]
        val_partition = [dataset_folds[val_fold_index]]

        train_dataset = MIRCTorchDataset(
            dataset_partitions=train_partitions,
            transform=transform,
            mask_mode=mask_mode,
            target_size=(256, 256)
        )

        val_dataset = MIRCTorchDataset(
            dataset_partitions=val_partition,
            transform=transform,
            mask_mode=mask_mode,
            target_size=(256, 256)
        )

        train_loader = DataLoader(
            train_dataset,
            batch_size=batch_size,
            shuffle=True,
            num_workers=num_workers,
            pin_memory=pin_memory
        )

        val_loader = DataLoader(
            val_dataset,
            batch_size=batch_size,
            shuffle=False,
            num_workers=num_workers,
            pin_memory=pin_memory
        )

        dataloaders.append((train_loader, val_loader))

    return dataloaders