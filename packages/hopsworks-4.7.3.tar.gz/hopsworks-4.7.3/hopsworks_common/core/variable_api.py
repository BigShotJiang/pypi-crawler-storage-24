#
#   Copyright 2022 Hopsworks AB
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#

from __future__ import annotations

import re

from hopsworks_apigen import also_available_as
from hopsworks_common import client
from hopsworks_common.client.exceptions import FeatureStoreException, RestAPIError


LOADBALANCER_SERVICES = {
    "mysqld": "mysqld",
    "online_store_rest_server": "rdrs",
    "opensearch": "opensearch",
    "kafka": "kafka",
    "feature_query": "flyingduck",
    "datanode": "datanode",
    "namenode": "namenode",
}


@also_available_as(
    "hopsworks.core.variable_api.VariableApi", "hsfs.core.variable_api.VariableApi"
)
class VariableApi:
    def get_variable(self, variable: str):
        """Get the configured value of a variable.

        Parameters:
            variable: Name of the variable.

        Returns:
            The variable's value.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request.
        """
        _client = client.get_instance()

        path_params = ["variables", variable]
        domain = _client._send_request("GET", path_params)

        return domain["successMessage"]

    def get_version(self, software: str) -> str | None:
        """Get version of a software component.

        Parameters:
            software: Name of the software.

        Returns:
            The software's version, if the software is available, otherwise `None`.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request.
        """
        _client = client.get_instance()

        path_params = ["variables", "versions"]
        resp = _client._send_request("GET", path_params)

        for entry in resp:
            if entry["software"] == software:
                return entry["version"]
        return None

    def parse_major_and_minor(
        self, backend_version: str
    ) -> tuple[str | None, str | None]:
        """Extract major and minor version from full version.

        Parameters:
            backend_version: The full version.

        Returns:
            major: The major part of the version, or `None` if the version format is incorrect.
            minor: The minor part of the version, or `None` if the version format is incorrect.
        """
        version_pattern = r"(\d+)\.(\d+)"
        matches = re.match(version_pattern, backend_version)

        if matches is None:
            return (None, None)
        return matches.group(1), matches.group(2)

    def get_data_science_profile_enabled(self) -> bool:
        """Check if data science profile is enabled on the backend.

        Returns:
            `True` if data science profile is enabled, `False` otherwise.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request.
        """
        return self.get_variable("enable_data_science_profile") == "true"

    def get_flyingduck_enabled(self) -> bool:
        """Check if Flying Duck is enabled on the backend.

        Returns:
            `True` if flying duck is available, `False` otherwise.

        Raises:
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request.
        """
        return self.get_variable("enable_flyingduck") == "true"

    def get_loadbalancer_external_domain(self, service: str) -> str:
        """Get domain loadbalancer for a service.

        Returns:
            The domain of external loadbalancer for a service, if it is set up.

        Raises:
            hopsworks.client.exceptions.FeatureStoreException: If variable is not set in Hopsworks Cluster Configuration.
            hopsworks.client.exceptions.RestAPIError: If the backend encounters an error when handling the request.
        """
        try:
            return self.get_variable(f"loadbalancer_external_domain_{service}")
        except RestAPIError as err:
            if err.STATUS_CODE_NOT_FOUND:
                raise FeatureStoreException(
                    f"Client could not get {LOADBALANCER_SERVICES[service]} service hostname from "
                    f"loadbalancer_external_domain_{service}. "
                    "The variable is either not set or empty in Hopsworks cluster configuration."
                ) from err
            raise err

    def get_service_discovery_domain(self) -> str:
        """Get domain of service discovery server.

        Returns:
            The domain of service discovery server, if it is set up, otherwise empty string `""`.
        """
        try:
            return self.get_variable("service_discovery_domain")
        except RestAPIError:
            return ""

    def get_featurestore_online_tablespace(self) -> str:
        """Get domain of featurestore online tablespace.

        Returns:
            The name of featurestore online tablespace, if it is set up, otherwise hopsworks default tablespace `ts_1`.
        """
        try:
            tablespace = self.get_variable("featurestore_online_tablespace")
        except RestAPIError:
            tablespace = None
        return tablespace or "ts_1"
