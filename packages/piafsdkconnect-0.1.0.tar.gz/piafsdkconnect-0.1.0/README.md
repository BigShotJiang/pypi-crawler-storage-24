# piafsdkconnect

A professional Python library for PI AF SDK integration (.NET based).

## Installation

```bash
pip install piafsdkconnect
```

## Usage

### Using .env file

Create a `.env` file in your project root with the following variables:

```env
PI_SERVER_NAME=YourPIServerName
PI_SDK_PATH=C:\Program Files (x86)\PIPC\AF\PublicAssemblies\4.0  # Optional, defaults to this path
PI_USERNAME=YourUsername  # Optional, for PI User/Windows Auth
PI_PASSWORD=YourPassword  # Optional
```

```python
from piafsdkconnect import get_service
service = get_service()
```

## Functions Provided

- `get_current_value(tag_name: str)`: Fetch the current value for a given PI tag.
- `get_recorded_values(tag_name: str, start_time: str, end_time: str)`: Fetch historical (recorded) values for a time range.
- `write_value(tag_name: str, value: Any, timestamp: Any = None)`: Write or replace a value for a PI tag.
- `search_tags(query: str)`: Search for PI tags based on a query pattern.
- `get_asset_servers()`: List available PI AF System (Asset Server) names.
- `get_organizations(asset_server: str)`: List AF Databases (Organizations) on a specific Asset Server.
- `test_connection()`: Verify the connection status to the PI Server.
- `disconnect()`: Explicitly close the connection.

### Passing credentials directly

```python
from piafsdkconnect import get_service

service = get_service(
    server_name="192.168.1.115",
    username="Administrator",
    password="YourPassword",
    sdk_path=r"C:\Program Files (x86)\PIPC\AF\PublicAssemblies\4.0"  # Optional
)

def main():
    val = service.get_current_value("YourTagName")
    print(val)

if __name__ == "__main__":
    main()
```
