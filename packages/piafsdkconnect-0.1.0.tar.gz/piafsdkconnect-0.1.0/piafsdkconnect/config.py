import os
from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import Optional
from dotenv import load_dotenv

class AFSDKSettings(BaseSettings):
    """
    Configuration settings for the PI AF SDK Service.
    """
    PI_SERVER_NAME: Optional[str] = None
    PI_SDK_PATH: Optional[str] = r'C:\Program Files (x86)\PIPC\AF\PublicAssemblies\4.0'
    PI_USERNAME: Optional[str] = None
    PI_PASSWORD: Optional[str] = None

    model_config = SettingsConfigDict(
        env_file=".env", 
        extra='ignore'
    )

def get_settings(
    env_path: Optional[str] = None,
    server_name: Optional[str] = None,
    sdk_path: Optional[str] = None,
    username: Optional[str] = None,
    password: Optional[str] = None
) -> AFSDKSettings:
    if env_path:
        load_dotenv(env_path)
    
    settings = AFSDKSettings()
    
    # Override with manual parameters if provided
    if server_name: settings.PI_SERVER_NAME = server_name
    if sdk_path: settings.PI_SDK_PATH = sdk_path
    if username: settings.PI_USERNAME = username
    if password: settings.PI_PASSWORD = password
    
    return settings
