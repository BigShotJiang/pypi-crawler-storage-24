from .service import PIAFSDKService
from .config import get_settings, AFSDKSettings
from typing import Optional

def get_service(
    env_path: Optional[str] = None,
    server_name: Optional[str] = None,
    sdk_path: Optional[str] = None,
    username: Optional[str] = None,
    password: Optional[str] = None
) -> PIAFSDKService:
    """
    Factory function to get the PI AF SDK service.
    Can be configured via .env file or by passing parameters directly.
    """
    settings = get_settings(
        env_path=env_path,
        server_name=server_name,
        sdk_path=sdk_path,
        username=username,
        password=password
    )
    return PIAFSDKService(settings)

__all__ = ["PIAFSDKService", "get_service", "AFSDKSettings"]
