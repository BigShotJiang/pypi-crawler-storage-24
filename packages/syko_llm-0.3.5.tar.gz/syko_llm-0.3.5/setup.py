from setuptools import setup, find_packages
setup(name="syko-llm", version="0.3.5", packages=find_packages(), install_requires=["torch", "transformers"])
