# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CreaseCaseResponseJson:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'test_case_id': 'int'
    }

    attribute_map = {
        'test_case_id': 'test_case_id'
    }

    def __init__(self, test_case_id=None):
        r"""CreaseCaseResponseJson

        The model defined in huaweicloud sdk

        :param test_case_id: 用例id
        :type test_case_id: int
        """
        
        

        self._test_case_id = None
        self.discriminator = None

        if test_case_id is not None:
            self.test_case_id = test_case_id

    @property
    def test_case_id(self):
        r"""Gets the test_case_id of this CreaseCaseResponseJson.

        用例id

        :return: The test_case_id of this CreaseCaseResponseJson.
        :rtype: int
        """
        return self._test_case_id

    @test_case_id.setter
    def test_case_id(self, test_case_id):
        r"""Sets the test_case_id of this CreaseCaseResponseJson.

        用例id

        :param test_case_id: The test_case_id of this CreaseCaseResponseJson.
        :type test_case_id: int
        """
        self._test_case_id = test_case_id

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CreaseCaseResponseJson):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
