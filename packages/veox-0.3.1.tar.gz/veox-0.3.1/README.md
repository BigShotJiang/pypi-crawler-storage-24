# VEOX Evolution Client

Professional-grade client for the VEOX Evolution REST API with stunning UX.

Full documentation available at [docs.veox.ai](https://docs.veox.ai)


## Quick Start

```python
pip install veox
from veox import VeoxEvolver

evolver = VeoxEvolver("binary")
evolver.fit(max_generations=10, population_size=20)

print(evolver.best_fitness_)     # Best score
print(evolver.best_pipeline_)    # Best genome as readable string
print(evolver.champions_)        # All champions
evolver.save("my_results.json")  # Persist results
```

Auto-managed server connection (recommended):

```python
with VeoxEvolver.serve(port=8090) as evolver:
    evolver.category = "binary"
    evolver.fit(max_generations=10)
```

The `fit()` call blocks until the evolution completes (or fails / times out),
while rendering a live `rich` dashboard in the terminal showing real-time
progress, fitness curves, champion table, ETA, and engine statistics.


## Server Setup

```bash
docker run -d \
  --name veox-enclave-server \
  -p 8090:8090 \
  714044927654.dkr.ecr.us-east-2.amazonaws.com/doug/single_enclave/veox-enclave-server:latest
```

For detailed server setup instructions, see the full docs at [https://docs.veox.ai](https://docs/veox.ai)