"""
veox_client — local import bridge for VEOX example scripts.

This allows example scripts to do:
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
    from veox_client import VeoxEvolver

by re-exporting everything from the actual SDK at veox_client/src/veox/.
"""
import os
import sys

# Add the src directory so that 'veox' package is importable
_src_dir = os.path.join(os.path.dirname(__file__), "src")
if _src_dir not in sys.path:
    sys.path.insert(0, _src_dir)

from veox import VeoxEvolver, EvolutionResult, Champion  # noqa: E402, F401

__all__ = ["VeoxEvolver", "EvolutionResult", "Champion"]
