"""CodeScope core — neug graph + zvec vector code intelligence.

This module contains the main ``CodeScope`` class which orchestrates:
  - Graph schema creation in neug
  - Vector collection in zvec
  - Indexing pipeline (tree-sitter -> neug + zvec)
  - Three use-case query methods (impact, similar, cross_locate)
"""

from __future__ import annotations

import base64
import csv
import hashlib
import json
import logging
import os
import re
import shutil
import subprocess
import time
from dataclasses import asdict
from pathlib import Path

os.environ.setdefault("GLOG_minloglevel", "2")

import neug
import numpy as np
import zvec
from sentence_transformers import SentenceTransformer

from codegraph.adapters.base import BaseAdapter
from codegraph.adapters.c_adapter import CAdapter
from codegraph.adapters.js_adapter import JsAdapter
from codegraph.adapters.python_adapter import PythonAdapter
from codegraph.models import (
    BridgeFunction,
    CallInfo,
    ChangeAttributionResult,
    CoChangeResult,
    CommitModularity,
    CouplingResult,
    CrossLocateResult,
    DeadCodeResult,
    HotColdEntry,
    LayerEntry,
    HotspotResult,
    ImpactResult,
    IntentSearchResult,
    ParsedImport,
    ParseResult,
    SemanticCrossPollinationHit,
    SimilarResult,
    StabilityAnalysis,
    StabilityEntry,
    UpdateReport,
)

_log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Helper: escape single quotes in Cypher string literals
# ---------------------------------------------------------------------------


def _cesc(value: str) -> str:
    """Escape a value for embedding in a Cypher single-quoted string."""
    return (
        value
        .replace("\\", "\\\\")
        .replace("'", "\\'")
        .replace("\n", "\\n")
        .replace("\r", "\\r")
        .replace("\t", "\\t")
    )


def _make_id(fqn: str) -> str:
    """Deterministic short ID from a fully-qualified name (40-char hex)."""
    return hashlib.sha1(fqn.encode()).hexdigest()


# ---------------------------------------------------------------------------
# Adapter registry
# ---------------------------------------------------------------------------


def _get_adapters(languages: list[str]) -> list[BaseAdapter]:
    """Return adapter instances for the requested languages."""
    mapping: dict[str, type[BaseAdapter]] = {
        "python": PythonAdapter,
        "javascript": JsAdapter,
        "typescript": JsAdapter,
        "c": CAdapter,
    }
    adapters = []
    for lang in languages:
        cls = mapping.get(lang)
        if cls is not None:
            adapters.append(cls())
    return adapters


def _match_adapter(
    filepath: Path, adapters: list[BaseAdapter]
) -> BaseAdapter | None:
    """Return the first adapter that can handle *filepath*, or ``None``."""
    for adapter in adapters:
        if adapter.can_handle(str(filepath)):
            return adapter
    return None


# ---------------------------------------------------------------------------
# Git helpers
# ---------------------------------------------------------------------------


def _git_head(repo: str) -> str | None:
    """Return the HEAD commit hash, or None if not a git repo."""
    try:
        r = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=repo, capture_output=True, text=True, check=True,
        )
        return r.stdout.strip()
    except (subprocess.CalledProcessError, FileNotFoundError):
        return None


def _git_diff_files(
    repo: str, old_commit: str, new_commit: str = "HEAD"
) -> dict[str, str]:
    """Return ``{rel_path: status}`` where status is ``A``, ``M``, or ``D``.

    Uses ``git diff-tree`` (plumbing) instead of ``git diff`` (porcelain)
    for dramatically better performance on large repos like the Linux kernel
    (~50x faster: 0.5s vs 30-45s per commit).
    """
    try:
        r = subprocess.run(
            ["git", "diff-tree", "-r", "--no-commit-id", "--name-status",
             old_commit, new_commit],
            cwd=repo, capture_output=True, text=True, check=True,
            timeout=60,
        )
    except (subprocess.CalledProcessError, FileNotFoundError,
            subprocess.TimeoutExpired):
        return {}

    changes: dict[str, str] = {}
    for line in r.stdout.strip().splitlines():
        parts = line.split("\t")
        if len(parts) < 2:
            continue
        status = parts[0][0]
        if status == "R" and len(parts) >= 3:
            changes[parts[1]] = "D"
            changes[parts[2]] = "A"
        else:
            changes[parts[-1]] = status
    return changes


# ============================================================================
# CodeScope
# ============================================================================


class CodeScope:
    """End-to-end code intelligence backed by neug (graph) and zvec (vector).

    Parameters
    ----------
    db_dir:
        Directory that will hold the neug and zvec data files.
    embedding_model:
        Name (or path) of a sentence-transformers model.  Defaults to
        ``all-MiniLM-L6-v2`` (384-dim, runs locally, no API key).
    """

    @staticmethod
    def detect_languages(repo_path: str) -> list[str]:
        """Auto-detect primary languages in a repo by file extensions."""
        ext_map = {
            ".py": "python", ".c": "c", ".h": "c",
            ".js": "javascript", ".jsx": "javascript",
            ".ts": "typescript", ".tsx": "typescript",
        }
        exclude = {
            ".git", "node_modules", "__pycache__", ".venv",
            "venv", "build", "dist", ".tox",
        }
        counts: dict[str, int] = {}
        for fp in Path(repo_path).rglob("*"):
            if fp.is_file() and not any(p in exclude for p in fp.parts):
                lang = ext_map.get(fp.suffix)
                if lang:
                    counts[lang] = counts.get(lang, 0) + 1
        if not counts:
            return ["python"]
        return sorted(counts, key=counts.get, reverse=True)[:2]

    @staticmethod
    def clean_locks(db_dir: str) -> None:
        """Remove stale lock files left by crashed processes."""
        neug_lock = os.path.join(db_dir, "graph.db", "neugdb.lock")
        if os.path.exists(neug_lock):
            os.remove(neug_lock)
            _log.info("Removed stale neug lock: %s", neug_lock)

        zvec_dir = os.path.join(db_dir, "vectors")
        zvec_lock = os.path.join(zvec_dir, "LOCK")
        if os.path.isdir(zvec_dir) and not os.path.exists(zvec_lock):
            open(zvec_lock, "w").close()
            _log.info("Recreated missing zvec LOCK file: %s", zvec_lock)

    def __init__(
        self,
        db_dir: str,
        embedding_model: str = "all-MiniLM-L6-v2",
    ) -> None:
        self.db_dir = db_dir
        os.makedirs(db_dir, exist_ok=True)

        # -- neug: graph store ------------------------------------------------
        self.db = neug.Database(os.path.join(db_dir, "graph.db"))
        self.conn = self.db.connect()

        # -- zvec: vector store -----------------------------------------------
        try:
            zvec.init(log_type=zvec.LogType.CONSOLE, log_level=zvec.LogLevel.WARN)
        except RuntimeError:
            pass
        zvec_path = os.path.join(db_dir, "vectors")
        schema = zvec.CollectionSchema(
            name="functions",
            vectors=zvec.VectorSchema(
                "code_emb", zvec.DataType.VECTOR_FP32, 384
            ),
        )
        self.collection = self._open_or_create_zvec(zvec_path, schema)

        # -- embedding model (local, no API key) ------------------------------
        self.model = SentenceTransformer(embedding_model)

        # -- in-memory embedding cache for subgraph search --------------------
        self._emb_cache: dict[str, np.ndarray] = {}

        # -- cache for _get_functions_at_rev to avoid repeated git show --------
        self._rev_func_cache: dict[tuple[str, str], dict[str, str]] = {}

        self._init_schema()

    @staticmethod
    def _open_or_create_zvec(path: str, schema):
        """Open an existing zvec store, or create a new one if absent.

        If the store exists but cannot be opened AND is tiny (< 1 MB,
        i.e. an empty/corrupt store left by a previous crash), it is
        safe to delete and recreate.  Stores with real data are never
        silently destroyed -- the error is raised instead.
        """
        import shutil

        if os.path.exists(path):
            try:
                return zvec.open(path=path)
            except RuntimeError:
                size = sum(
                    os.path.getsize(os.path.join(dp, f))
                    for dp, _, fns in os.walk(path)
                    for f in fns
                )
                if size > 1_000_000:
                    raise
                _log.warning(
                    "zvec at %s is empty/corrupt (%d bytes), recreating",
                    path, size,
                )
                shutil.rmtree(path, ignore_errors=True)
        return zvec.create_and_open(path=path, schema=schema)

    # ========================================================================
    # Schema
    # ========================================================================

    def _init_schema(self) -> None:
        """Create node/rel tables if they don't already exist."""
        for ddl in [
            """CREATE NODE TABLE IF NOT EXISTS File (
                id STRING, fqn STRING, path STRING, language STRING,
                loc INT64, is_external INT64,
                PRIMARY KEY(id))""",
            """CREATE NODE TABLE IF NOT EXISTS Function (
                id STRING, fqn STRING, name STRING, qualified_name STRING,
                signature STRING, file_path STRING,
                start_line INT64, end_line INT64,
                doc_comment STRING,
                class_name STRING, language STRING,
                is_historical INT64,
                PRIMARY KEY(id))""",
            """CREATE NODE TABLE IF NOT EXISTS Class (
                id STRING, fqn STRING, name STRING, qualified_name STRING,
                file_path STRING, start_line INT64, end_line INT64,
                PRIMARY KEY(id))""",
            """CREATE NODE TABLE IF NOT EXISTS Module (
                id STRING, fqn STRING, name STRING, path_prefix STRING,
                PRIMARY KEY(id))""",
            """CREATE NODE TABLE IF NOT EXISTS Metadata (
                id STRING, value STRING,
                PRIMARY KEY(id))""",
            "CREATE REL TABLE IF NOT EXISTS CALLS (FROM Function TO Function)",
            "CREATE REL TABLE IF NOT EXISTS DEFINES_FUNC (FROM File TO Function)",
            "CREATE REL TABLE IF NOT EXISTS DEFINES_CLASS (FROM File TO Class)",
            "CREATE REL TABLE IF NOT EXISTS HAS_METHOD (FROM Class TO Function)",
            "CREATE REL TABLE IF NOT EXISTS IMPORTS (FROM File TO File)",
            "CREATE REL TABLE IF NOT EXISTS BELONGS_TO (FROM File TO Module)",
            "CREATE REL TABLE IF NOT EXISTS INHERITS (FROM Class TO Class)",
            """CREATE NODE TABLE IF NOT EXISTS Commit (
                id STRING, fqn STRING, hash STRING, message STRING,
                author STRING, timestamp INT64, version_tag STRING,
                PRIMARY KEY(id))""",
            "CREATE REL TABLE IF NOT EXISTS MODIFIES (FROM Commit TO Function)",
            "CREATE REL TABLE IF NOT EXISTS TOUCHES (FROM Commit TO File)",
        ]:
            self.conn.execute(ddl)

    # ========================================================================
    # Indexing pipeline
    # ========================================================================

    DEFAULT_EXCLUDE_DIRS: frozenset[str] = frozenset({
        ".git", "__pycache__", "node_modules", "build", ".build",
        "out", "dist", ".tox", ".mypy_cache",
    })

    DEFAULT_C_EXCLUDES: frozenset[str] = frozenset({
        ".git", "build", ".build", "out", "tools/testing",
        "Documentation", "scripts", "samples",
    })

    def index(
        self,
        repo_path: str,
        languages: list[str] | None = None,
        exclude_dirs: list[str] | None = None,
        progress: bool = True,
    ) -> None:
        """Build the code graph (neug) + vector index (zvec) for a repo.

        All intermediate data (node/edge CSVs and vector text JSONL) is
        persisted in ``<db_dir>/dataset/`` so it can be distributed as a
        pre-built dataset, and so indexing can be resumed if interrupted.

        Uses CSV + ``COPY FROM`` for bulk loading into neug, which avoids
        the per-session WAL buffer limit (~4096 nodes via individual CREATEs).
        """
        languages = languages or ["python"]
        adapters = _get_adapters(languages)

        if exclude_dirs is not None:
            excluded = set(exclude_dirs)
        else:
            excluded = set(self.DEFAULT_EXCLUDE_DIRS)
            if "c" in languages:
                excluded |= self.DEFAULT_C_EXCLUDES

        repo = Path(repo_path)
        all_functions: dict[str, dict] = {}
        all_calls: list[tuple[str, CallInfo]] = []
        all_imports: list[ParsedImport] = []
        all_classes: dict[str, dict] = {}

        file_rows: list[dict] = []
        func_rows: list[dict] = []
        class_rows: list[dict] = []

        candidate_files = []
        for filepath in sorted(repo.rglob("*")):
            if not filepath.is_file():
                continue
            rel = filepath.relative_to(repo)
            if any(part in excluded for part in rel.parts):
                continue
            adapter = _match_adapter(filepath, adapters)
            if adapter is None:
                continue
            candidate_files.append((filepath, rel, adapter))

        total = len(candidate_files)
        t0 = time.time()
        if progress:
            print(f"[1/7] Parsing {total} files...", flush=True)

        for idx, (filepath, rel, adapter) in enumerate(candidate_files, 1):
            rel_path = str(rel)
            source = filepath.read_bytes()
            self._collect_file(
                rel_path, source, adapter,
                all_functions, all_calls, all_imports, all_classes,
                file_rows, func_rows, class_rows,
            )
            if progress and (idx % 200 == 0 or idx == total):
                elapsed = time.time() - t0
                rate = idx / elapsed if elapsed > 0 else 0
                eta = (total - idx) / rate if rate > 0 else 0
                print(
                    f"  {idx}/{total} files  "
                    f"{len(all_functions)} funcs  "
                    f"{elapsed:.1f}s elapsed  "
                    f"ETA {eta:.0f}s",
                    flush=True,
                )

        if progress:
            print("[2/7] Bulk-loading graph nodes...", flush=True)
        self._bulk_import_nodes(file_rows, func_rows, class_rows)

        if progress:
            print("[3/7] Resolving imports...", flush=True)
        self._resolve_file_imports(all_imports)

        if progress:
            print("[4/7] Resolving calls...", flush=True)
        self._resolve_inheritance(all_classes)
        self._resolve_calls(all_functions, all_calls, all_imports, all_classes)

        if progress:
            print("[5/7] Creating modules...", flush=True)
        self._create_modules(repo)

        commit = _git_head(str(repo))
        self._save_commit(
            commit or "", os.path.abspath(str(repo)), languages,
        )

        if progress:
            print("[6/7] Saving vector source texts...", flush=True)
        vec_texts: dict[str, str] = {}
        for fid, info in all_functions.items():
            parts = [info["signature"]]
            if info.get("doc_comment"):
                parts.append(info["doc_comment"])
            if info.get("body_summary"):
                parts.append(info["body_summary"])
            vec_texts[fid] = " ".join(parts)
        self.save_vector_texts(vec_texts, "function_texts.jsonl")

        self._write_manifest({
            "repo": os.path.basename(os.path.abspath(str(repo))),
            "repo_path": os.path.abspath(str(repo)),
            "languages": languages,
            "head_commit": commit or "",
            "files": len(file_rows),
            "functions": len(func_rows),
            "classes": len(class_rows),
            "phase": "graph_complete",
        })

        if progress:
            print("[7/7] Computing embeddings...", flush=True)
        self._build_embeddings(all_functions)

        self._write_manifest({"phase": "complete"})

        summary = self.summary()
        print(summary)

    # -- index helpers --------------------------------------------------------

    def _collect_file(
        self,
        rel_path: str,
        source: bytes,
        adapter: BaseAdapter,
        all_functions: dict[str, dict],
        all_calls: list[tuple[str, CallInfo]],
        all_imports: list[ParsedImport],
        all_classes: dict[str, dict],
        file_rows: list[dict],
        func_rows: list[dict],
        class_rows: list[dict],
    ) -> None:
        """Parse one file and collect rows for bulk CSV import (no graph writes)."""
        result: ParseResult = adapter.parse_file(source, rel_path)
        language = adapter.language_name()
        source_lines = source.decode("utf-8", errors="replace").splitlines()
        loc = len(source_lines)

        file_fqn = rel_path
        file_id = _make_id(file_fqn)
        file_rows.append({
            "id": file_id,
            "fqn": file_fqn,
            "path": rel_path,
            "language": language,
            "loc": loc,
            "is_external": 0,
        })

        seen_fqns: set[str] = set()
        for func in result.functions:
            func_fqn = f"{rel_path}:{func.name}:{func.start_line}"
            if func_fqn in seen_fqns:
                continue
            seen_fqns.add(func_fqn)
            fid = _make_id(func_fqn)

            class_name_val = func.class_name or ""

            func_rows.append({
                "id": fid,
                "fqn": func_fqn,
                "name": func.name,
                "qualified_name": func.qualified_name,
                "signature": func.signature,
                "file_path": rel_path,
                "start_line": func.start_line,
                "end_line": func.end_line,
                "doc_comment": func.doc_comment,
                "class_name": class_name_val,
                "language": language,
                "is_historical": 0,
            })

            for call_info in func.calls:
                all_calls.append((fid, call_info))

            _MAX_BODY_LINES = 15
            body_end = min(func.end_line, func.start_line + _MAX_BODY_LINES)
            body_summary = "\n".join(
                source_lines[func.start_line - 1 : body_end]
            )

            all_functions[fid] = {
                "name": func.name,
                "signature": func.signature,
                "doc_comment": func.doc_comment,
                "file_path": rel_path,
                "class_name": func.class_name,
                "body_summary": body_summary,
            }

        for cls in result.classes:
            cls_fqn = f"{rel_path}:{cls.name}"
            cls_id = _make_id(cls_fqn)
            class_rows.append({
                "id": cls_id,
                "fqn": cls_fqn,
                "name": cls.name,
                "qualified_name": cls.qualified_name,
                "file_path": rel_path,
                "start_line": cls.start_line,
                "end_line": cls.end_line,
            })
            all_classes[cls_id] = {
                "name": cls.name,
                "file_path": rel_path,
                "base_classes": cls.base_classes,
            }

        for imp in result.imports:
            all_imports.append(imp)

    def _bulk_import_nodes(
        self,
        file_rows: list[dict],
        func_rows: list[dict],
        class_rows: list[dict],
    ) -> None:
        """Write CSV files to dataset/ and COPY FROM for bulk node import.

        After nodes are loaded, creates DEFINES_FUNC, DEFINES_CLASS and
        HAS_METHOD relationship edges via CSV as well.
        """
        self._save_and_load_node_csv("File", file_rows,
                                     ["id", "fqn", "path", "language",
                                      "loc", "is_external"])
        self._save_and_load_node_csv("Function", func_rows,
                                     ["id", "fqn", "name", "qualified_name",
                                      "signature", "file_path", "start_line",
                                      "end_line", "doc_comment", "class_name",
                                      "language", "is_historical"])
        self._save_and_load_node_csv("Class", class_rows,
                                     ["id", "fqn", "name", "qualified_name",
                                      "file_path", "start_line", "end_line"])

        df_edges = [
            {"from_id": _make_id(fr["file_path"]), "to_id": fr["id"]}
            for fr in func_rows
        ]
        self._save_and_load_rel_csv("DEFINES_FUNC", df_edges,
                                    "File", "Function")

        dc_edges = [
            {"from_id": _make_id(cr["file_path"]), "to_id": cr["id"]}
            for cr in class_rows
        ]
        self._save_and_load_rel_csv("DEFINES_CLASS", dc_edges,
                                    "File", "Class")

        hm_edges = []
        for fr in func_rows:
            cn = fr["class_name"]
            if cn and cn != "__static__":
                cls_fqn = f"{fr['file_path']}:{cn}"
                hm_edges.append({
                    "from_id": _make_id(cls_fqn),
                    "to_id": fr["id"],
                })
        if hm_edges:
            self._save_and_load_rel_csv("HAS_METHOD", hm_edges,
                                        "Class", "Function")

        _log.info("Bulk imported %d files, %d functions, %d classes",
                  len(file_rows), len(func_rows), len(class_rows))

    _COPY_BATCH = 100_000

    # -- Dataset directory layout ---------------------------------------------
    # .db_dir/dataset/nodes/{Table}.csv      — one CSV per node table
    # .db_dir/dataset/edges/{Rel}.csv        — one CSV per relationship table
    # .db_dir/dataset/vectors/function_texts.jsonl  — {id, text} per function
    # .db_dir/dataset/manifest.json          — metadata for the dataset

    @property
    def _dataset_dir(self) -> str:
        return os.path.join(self.db_dir, "dataset")

    def _dataset_nodes_dir(self) -> str:
        d = os.path.join(self._dataset_dir, "nodes")
        os.makedirs(d, exist_ok=True)
        return d

    def _dataset_edges_dir(self) -> str:
        d = os.path.join(self._dataset_dir, "edges")
        os.makedirs(d, exist_ok=True)
        return d

    def _dataset_vectors_dir(self) -> str:
        d = os.path.join(self._dataset_dir, "vectors")
        os.makedirs(d, exist_ok=True)
        return d

    def _write_manifest(self, extra: dict | None = None) -> None:
        import json as _json
        manifest_path = os.path.join(self._dataset_dir, "manifest.json")
        existing: dict = {}
        if os.path.exists(manifest_path):
            with open(manifest_path, "r") as f:
                existing = _json.load(f)
        existing["updated_at"] = time.strftime("%Y-%m-%dT%H:%M:%S")
        if extra:
            existing.update(extra)
        os.makedirs(self._dataset_dir, exist_ok=True)
        with open(manifest_path, "w") as f:
            _json.dump(existing, f, indent=2, ensure_ascii=False)

    # -- CSV writing (persistent) + loading -----------------------------------

    @staticmethod
    def _write_csv(csv_path: str, rows: list[dict], columns: list[str],
                   *, dedup_col: str | None = None) -> int:
        """Write rows to a CSV file.  Returns the number of rows written."""
        if not rows:
            return 0
        if dedup_col:
            seen: set[str] = set()
            unique: list[dict] = []
            for r in rows:
                pk = str(r[dedup_col])
                if pk not in seen:
                    seen.add(pk)
                    unique.append(r)
            rows = unique

        sanitized = []
        for row in rows:
            clean = {}
            for k, v in row.items():
                if isinstance(v, str):
                    clean[k] = v.replace("\n", "\\n").replace("\r", "")
                else:
                    clean[k] = v
            sanitized.append(clean)

        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(
                f, fieldnames=columns, extrasaction="ignore",
                quoting=csv.QUOTE_ALL,
            )
            w.writeheader()
            w.writerows(sanitized)
        return len(sanitized)

    @staticmethod
    def _append_csv(csv_path: str, rows: list[dict],
                    columns: list[str]) -> int:
        """Append rows to an existing CSV file (creates with header if missing).

        Returns the number of rows appended.
        """
        if not rows:
            return 0

        sanitized = []
        for row in rows:
            clean = {}
            for k, v in row.items():
                if isinstance(v, str):
                    clean[k] = v.replace("\n", "\\n").replace("\r", "")
                else:
                    clean[k] = v
            sanitized.append(clean)

        write_header = not os.path.exists(csv_path)
        with open(csv_path, "a", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(
                f, fieldnames=columns, extrasaction="ignore",
                quoting=csv.QUOTE_ALL,
            )
            if write_header:
                w.writeheader()
            w.writerows(sanitized)
        return len(sanitized)

    def _load_node_csv(self, csv_path: str, table: str) -> None:
        """Load a node CSV into neug via COPY FROM (handles batching)."""
        if not os.path.exists(csv_path):
            return
        try:
            self.conn.execute(
                f'COPY {table} FROM "{csv_path}" '
                f'(header=true, delim=",", escaping=false)'
            )
            self.conn.execute("CHECKPOINT")
        except RuntimeError as exc:
            _log.error("COPY %s FROM %s failed: %s", table, csv_path, exc)
            raise

    def _load_rel_csv(self, csv_path: str, rel_name: str,
                      from_table: str, to_table: str) -> None:
        """Load a relationship CSV into neug via COPY FROM."""
        if not os.path.exists(csv_path):
            return
        try:
            self.conn.execute(
                f'COPY {rel_name} FROM "{csv_path}" '
                f'(from="{from_table}", to="{to_table}", '
                f'header=true, delim=",", escaping=false)'
            )
            self.conn.execute("CHECKPOINT")
        except RuntimeError as exc:
            _log.error("COPY %s FROM %s failed: %s", rel_name, csv_path, exc)
            raise

    def _save_node_csv(self, table: str, rows: list[dict],
                       columns: list[str]) -> str:
        """Write node rows to persistent dataset CSV.  Returns the path."""
        csv_path = os.path.join(self._dataset_nodes_dir(), f"{table}.csv")
        n = self._write_csv(csv_path, rows, columns, dedup_col=columns[0])
        print(f"  Saved {table}.csv ({n:,} rows)", flush=True)
        return csv_path

    def _save_rel_csv(self, rel_name: str, rows: list[dict],
                      extra_cols: list[str] | None = None) -> str:
        """Write relationship rows to persistent dataset CSV.  Returns path."""
        columns = ["from_id", "to_id"] + (extra_cols or [])
        csv_path = os.path.join(self._dataset_edges_dir(), f"{rel_name}.csv")
        n = self._write_csv(csv_path, rows, columns)
        print(f"  Saved {rel_name}.csv ({n:,} edges)", flush=True)
        return csv_path

    def _save_and_load_node_csv(self, table: str, rows: list[dict],
                                columns: list[str]) -> None:
        """Save node CSV to dataset/ then COPY FROM into neug."""
        csv_path = self._save_node_csv(table, rows, columns)
        self._load_node_csv(csv_path, table)

    def _save_and_load_rel_csv(self, rel_name: str, rows: list[dict],
                               from_table: str, to_table: str,
                               extra_cols: list[str] | None = None) -> None:
        """Save relationship CSV to dataset/ then COPY FROM into neug."""
        csv_path = self._save_rel_csv(rel_name, rows, extra_cols)
        self._load_rel_csv(csv_path, rel_name, from_table, to_table)

    def save_vector_texts(self, texts: dict[str, str],
                          filename: str = "function_texts.jsonl") -> str:
        """Save {id: text} mapping as JSONL for vector rebuild without re-parse."""
        import json as _json
        out_path = os.path.join(self._dataset_vectors_dir(), filename)
        with open(out_path, "w", encoding="utf-8") as f:
            for fid, text in texts.items():
                _json.dump({"id": fid, "text": text}, f, ensure_ascii=False)
                f.write("\n")
        print(f"  Saved {filename} ({len(texts):,} entries)", flush=True)
        return out_path

    def _load_vector_texts(self, filename: str = "function_texts.jsonl"
                           ) -> dict[str, str]:
        """Load {id: text} from JSONL."""
        import json as _json
        path = os.path.join(self._dataset_vectors_dir(), filename)
        result: dict[str, str] = {}
        if not os.path.exists(path):
            return result
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    obj = _json.loads(line)
                    result[obj["id"]] = obj["text"]
        return result

    def export_dataset(self) -> str:
        """Export the entire current graph + vector texts to dataset/.

        Useful when you have a built graph.db but no dataset CSVs (e.g.
        from a previous run before this feature existed).  Returns the
        dataset directory path.
        """
        print("Exporting graph to dataset CSVs...", flush=True)

        node_specs = [
            ("File", ["id", "fqn", "path", "language", "loc", "is_external"],
             "MATCH (n:File) RETURN n.id, n.fqn, n.path, n.language, "
             "n.loc, n.is_external"),
            ("Function",
             ["id", "fqn", "name", "qualified_name", "signature", "file_path",
              "start_line", "end_line", "doc_comment", "class_name",
              "language", "is_historical"],
             "MATCH (n:Function) RETURN n.id, n.fqn, n.name, "
             "n.qualified_name, n.signature, n.file_path, n.start_line, "
             "n.end_line, n.doc_comment, n.class_name, n.language, "
             "n.is_historical"),
            ("Class",
             ["id", "fqn", "name", "qualified_name", "file_path",
              "start_line", "end_line"],
             "MATCH (n:Class) RETURN n.id, n.fqn, n.name, "
             "n.qualified_name, n.file_path, n.start_line, n.end_line"),
            ("Module", ["id", "fqn", "name", "path_prefix"],
             "MATCH (n:Module) RETURN n.id, n.fqn, n.name, n.path_prefix"),
            ("Commit",
             ["id", "fqn", "hash", "message", "author", "timestamp",
              "version_tag"],
             "MATCH (n:Commit) RETURN n.id, n.fqn, n.hash, n.message, "
             "n.author, n.timestamp, n.version_tag"),
            ("Metadata", ["id", "value"],
             "MATCH (n:Metadata) RETURN n.id, n.value"),
        ]
        for table, columns, query in node_specs:
            rows = [dict(zip(columns, row))
                    for row in self.conn.execute(query)]
            if rows:
                self._save_node_csv(table, rows, columns)

        rel_specs = [
            ("CALLS", "Function", "Function"),
            ("DEFINES_FUNC", "File", "Function"),
            ("DEFINES_CLASS", "File", "Class"),
            ("HAS_METHOD", "Class", "Function"),
            ("IMPORTS", "File", "File"),
            ("BELONGS_TO", "File", "Module"),
            ("INHERITS", "Class", "Class"),
            ("MODIFIES", "Commit", "Function"),
            ("TOUCHES", "Commit", "File"),
        ]
        for rel_name, from_t, to_t in rel_specs:
            rows = []
            try:
                for row in self.conn.execute(
                    f"MATCH (a:{from_t})-[:{rel_name}]->(b:{to_t}) "
                    "RETURN a.id, b.id"
                ):
                    rows.append({"from_id": row[0], "to_id": row[1]})
            except Exception:
                pass
            if rows:
                self._save_rel_csv(rel_name, rows)

        func_texts: dict[str, str] = {}
        for row in self.conn.execute(
            "MATCH (f:Function) WHERE f.is_historical = 0 "
            "RETURN f.id, f.signature, f.doc_comment"
        ):
            parts = [row[1] or ""]
            if row[2]:
                parts.append(row[2])
            func_texts[row[0]] = " ".join(parts)
        if func_texts:
            self.save_vector_texts(func_texts, "function_texts.jsonl")

        self._write_manifest({"phase": "exported"})
        print(f"Dataset exported to {self._dataset_dir}", flush=True)
        return self._dataset_dir

    # -- Legacy compatibility wrappers (used by _resolve_*, _create_modules) --

    def _copy_node_csv(
        self, tmpdir: str, table: str, rows: list[dict], columns: list[str]
    ) -> None:
        """Write rows to CSV and COPY FROM.  Saves to dataset/ as well."""
        self._save_and_load_node_csv(table, rows, columns)

    def _copy_rel_csv(
        self, tmpdir: str, rel_name: str, rows: list[dict],
        from_table: str, to_table: str,
        extra_cols: list[str] | None = None,
    ) -> None:
        """Write relationship rows to CSV and COPY FROM.  Saves to dataset/."""
        self._save_and_load_rel_csv(rel_name, rows, from_table, to_table,
                                    extra_cols)

    # -- Dataset loading (from pre-built CSVs) --------------------------------

    def load_dataset(self, dataset_dir: str | None = None,
                     build_vectors: bool = True) -> None:
        """Load a pre-built dataset from CSV files into neug + zvec.

        This is the fast path for users who download a pre-built dataset
        instead of running the full indexing pipeline.

        *dataset_dir* defaults to ``self.db_dir + "/dataset"``.
        """
        import json as _json

        if dataset_dir is None:
            dataset_dir = self._dataset_dir
        nodes_dir = os.path.join(dataset_dir, "nodes")
        edges_dir = os.path.join(dataset_dir, "edges")
        vectors_dir = os.path.join(dataset_dir, "vectors")

        manifest_path = os.path.join(dataset_dir, "manifest.json")
        if os.path.exists(manifest_path):
            with open(manifest_path) as f:
                manifest = _json.load(f)
            print(f"Loading dataset: {manifest.get('repo', '?')} "
                  f"({manifest.get('updated_at', '?')})", flush=True)

        node_order = ["File", "Function", "Class", "Module", "Commit",
                      "Metadata"]
        for table in node_order:
            csv_path = os.path.join(nodes_dir, f"{table}.csv")
            if os.path.exists(csv_path):
                print(f"  Loading {table}...", end="", flush=True)
                self._load_node_csv(csv_path, table)
                print(" done", flush=True)

        rel_defs = [
            ("DEFINES_FUNC", "File", "Function"),
            ("DEFINES_CLASS", "File", "Class"),
            ("HAS_METHOD", "Class", "Function"),
            ("IMPORTS", "File", "File"),
            ("BELONGS_TO", "File", "Module"),
            ("INHERITS", "Class", "Class"),
            ("CALLS", "Function", "Function"),
            ("MODIFIES", "Commit", "Function"),
            ("TOUCHES", "Commit", "File"),
        ]
        for rel_name, from_t, to_t in rel_defs:
            csv_path = os.path.join(edges_dir, f"{rel_name}.csv")
            if os.path.exists(csv_path):
                print(f"  Loading {rel_name}...", end="", flush=True)
                self._load_rel_csv(csv_path, rel_name, from_t, to_t)
                print(" done", flush=True)

        # Mark commits that already have MODIFIES edges as backfilled
        # so subsequent backfill runs skip them.
        try:
            self.conn.execute(
                f"MATCH (c:Commit)-[:MODIFIES]->() "
                f"SET c.version_tag = '{self._BACKFILL_MARKER}'"
            )
            self.conn.execute("CHECKPOINT")
            bf_count = list(self.conn.execute(
                f"MATCH (c:Commit) WHERE c.version_tag = "
                f"'{self._BACKFILL_MARKER}' RETURN count(c)"
            ))[0][0]
            if bf_count:
                print(f"  Marked {bf_count} commits as backfilled", flush=True)
        except Exception:
            pass

        if build_vectors:
            func_texts = self._load_vector_texts("function_texts.jsonl")
            if func_texts:
                print(f"  Building vectors from {len(func_texts):,} texts...",
                      flush=True)
                self._build_vectors_from_texts(func_texts)

        print("Dataset loaded.", flush=True)

    def _build_vectors_from_texts(
        self, texts: dict[str, str],
    ) -> None:
        """Compute embeddings from text dict and insert into zvec."""
        ids = list(texts.keys())
        text_list = [texts[i] for i in ids]
        embeddings = self.model.encode(
            text_list, show_progress_bar=True, normalize_embeddings=True,
        )
        coll = self.collection
        docs = [
            zvec.Doc(id=fid, vectors={"code_emb": emb.tolist()})
            for fid, emb in zip(ids, embeddings)
        ]
        _BATCH = 1000
        for i in range(0, len(docs), _BATCH):
            coll.insert(docs[i : i + _BATCH])

    def _resolve_file_imports(
        self, all_imports: list[ParsedImport]
    ) -> None:
        """Create IMPORTS edges between File nodes after all files are indexed.

        Unresolved imports (system/external headers) get lightweight external
        File nodes so the IMPORTS relationship is preserved in the graph.
        """
        known: set[str] = set()
        for row in self.conn.execute("MATCH (f:File) RETURN f.path"):
            known.add(row[0])

        edge_rows: list[dict] = []
        created: set[tuple[str, str]] = set()
        external_paths: set[str] = set()

        for imp in all_imports:
            target_file = self._resolve_import_to_file(imp, known)
            if target_file is None:
                target_path = imp.target_module.replace(".", "/") + ".py"
                if target_path in known:
                    target_file = target_path
            if target_file is None:
                source_dir = str(Path(imp.source_path).parent)
                for candidate in (
                    f"{source_dir}/{imp.target_module}" if source_dir != "." else imp.target_module,
                    f"include/{imp.target_module}",
                    imp.target_module,
                ):
                    if candidate in known:
                        target_file = candidate
                        break

            if target_file is not None:
                if target_file == imp.source_path:
                    continue
                edge = (imp.source_path, target_file)
                if edge not in created:
                    created.add(edge)
                    edge_rows.append({
                        "from_id": _make_id(imp.source_path),
                        "to_id": _make_id(target_file),
                    })
            elif imp.target_module:
                ext_path = imp.target_module
                external_paths.add(ext_path)
                edge = (imp.source_path, ext_path)
                if edge not in created:
                    created.add(edge)
                    edge_rows.append({
                        "from_id": _make_id(imp.source_path),
                        "to_id": _make_id(ext_path),
                    })

        if external_paths:
            ext_rows = [
                {
                    "id": _make_id(ep), "fqn": ep, "path": ep,
                    "language": "external", "loc": 0, "is_external": 1,
                }
                for ep in external_paths
            ]
            file_cols = ["id", "fqn", "path", "language", "loc",
                         "is_external"]
            staging = self._staging_dir()
            tmp_csv = os.path.join(staging, "File_ext.csv")
            self._write_csv(tmp_csv, ext_rows, file_cols, dedup_col="id")
            self._load_node_csv(tmp_csv, "File")
            shutil.rmtree(staging, ignore_errors=True)
            ds_csv = os.path.join(self._dataset_nodes_dir(), "File.csv")
            self._append_csv(ds_csv, ext_rows, file_cols)
            print(f"  Saved File.csv ({len(ext_rows):,} rows)", flush=True)

        if edge_rows:
            self._save_and_load_rel_csv("IMPORTS", edge_rows,
                                        "File", "File")

    def _resolve_inheritance(
        self,
        all_classes: dict[str, dict],
    ) -> None:
        """Create INHERITS edges between classes using bulk CSV import."""
        name_to_cls: dict[str, list[str]] = {}
        for cls_id, info in all_classes.items():
            name_to_cls.setdefault(info["name"], []).append(cls_id)

        edge_rows: list[dict] = []
        created: set[tuple[str, str]] = set()
        for cls_id, info in all_classes.items():
            for base_name in info.get("base_classes", []):
                targets = name_to_cls.get(base_name, [])
                same_file = [
                    t for t in targets
                    if all_classes[t]["file_path"] == info["file_path"]
                ]
                chosen = same_file if same_file else targets
                for target_id in chosen:
                    if target_id == cls_id:
                        continue
                    edge = (cls_id, target_id)
                    if edge in created:
                        continue
                    created.add(edge)
                    edge_rows.append({"from_id": cls_id, "to_id": target_id})

        if edge_rows:
            self._save_and_load_rel_csv("INHERITS", edge_rows,
                                        "Class", "Class")

    # -- import resolution ----------------------------------------------------

    @staticmethod
    def _resolve_import_to_file(
        imp: ParsedImport, known_files: set[str]
    ) -> str | None:
        """Resolve a ParsedImport to a concrete file path in the repo."""
        source_dir = str(Path(imp.source_path).parent)

        if imp.is_relative:
            base_dir = source_dir
            level = imp.relative_level if imp.relative_level else 1
            for _ in range(level - 1):
                parent = str(Path(base_dir).parent)
                if parent == base_dir:
                    break
                base_dir = parent

            if imp.target_module:
                parts = imp.target_module.replace(".", "/")
                target_base = (
                    f"{base_dir}/{parts}" if base_dir != "." else parts
                )
            else:
                target_base = base_dir
        else:
            if not imp.target_module:
                return None
            target_base = imp.target_module.replace(".", "/")

        target_base = str(Path(target_base))

        extensions = [
            ".py", "/__init__.py",
            ".ts", ".tsx", ".js", ".jsx",
            "/index.ts", "/index.tsx", "/index.js", "/index.jsx",
            ".c", ".h",
        ]
        for ext in extensions:
            candidate = target_base + ext
            if candidate in known_files:
                return candidate

        if target_base in known_files:
            return target_base

        for prefix in ("include/", ""):
            candidate = f"{prefix}{target_base}" if prefix else target_base
            if candidate in known_files:
                return candidate
            for ext in (".h", ".c"):
                if (candidate + ext) in known_files:
                    return candidate + ext

        return None

    # -- scope-aware call resolution ------------------------------------------

    def _resolve_calls(
        self,
        all_functions: dict[str, dict],
        all_calls: list[tuple[str, CallInfo]],
        all_imports: list[ParsedImport],
        all_classes: dict[str, dict],
    ) -> None:
        """Create CALLS edges using scope-aware resolution.

        Resolution priority:
          1. self/this method -> current class (+ base classes)
          2. receiver.method -> imported module alias
          3. bare call -> imported name > same file > same module > unique global
        """
        name_to_ids: dict[str, list[str]] = {}
        file_to_func_ids: dict[str, list[str]] = {}
        class_methods: dict[str, list[str]] = {}

        for fid, info in all_functions.items():
            name_to_ids.setdefault(info["name"], []).append(fid)
            fp = info["file_path"]
            file_to_func_ids.setdefault(fp, []).append(fid)
            if info.get("class_name"):
                cls_key = f"{fp}:{info['class_name']}"
                class_methods.setdefault(cls_key, []).append(fid)

        known_files = set(file_to_func_ids.keys())

        import_name_map: dict[tuple[str, str], list[str]] = {}
        module_alias_map: dict[tuple[str, str], str] = {}

        for imp in all_imports:
            if imp.is_relative and not imp.target_module:
                source_dir = str(Path(imp.source_path).parent)
                base_dir = source_dir
                level = imp.relative_level if imp.relative_level else 1
                for _ in range(level - 1):
                    parent = str(Path(base_dir).parent)
                    if parent == base_dir:
                        break
                    base_dir = parent
                for iname in imp.imported_names:
                    sub = f"{base_dir}/{iname}"
                    sub_file = None
                    for ext in (".py", "/__init__.py", ".ts", ".js",
                                "/index.ts", "/index.js"):
                        c = sub + ext
                        if c in known_files:
                            sub_file = c
                            break
                    if sub_file:
                        module_alias_map[(imp.source_path, iname)] = sub_file
                continue

            target_file = self._resolve_import_to_file(imp, known_files)
            if target_file is None:
                continue

            target_funcs = file_to_func_ids.get(target_file, [])
            if imp.imported_names:
                for iname in imp.imported_names:
                    if iname == "*":
                        for fid in target_funcs:
                            fn = all_functions[fid]["name"]
                            import_name_map.setdefault(
                                (imp.source_path, fn), []
                            ).append(fid)
                    else:
                        for fid in target_funcs:
                            if all_functions[fid]["name"] == iname:
                                import_name_map.setdefault(
                                    (imp.source_path, iname), []
                                ).append(fid)
            else:
                alias = (
                    imp.target_module.rsplit(".", 1)[-1]
                    if imp.target_module else ""
                )
                if alias:
                    module_alias_map[
                        (imp.source_path, alias)
                    ] = target_file

        created: set[tuple[str, str]] = set()
        edge_rows: list[dict] = []

        for caller_id, call_info in all_calls:
            caller_info = all_functions.get(caller_id)
            if caller_info is None:
                continue

            caller_file = caller_info["file_path"]
            caller_class = caller_info.get("class_name")
            receiver = call_info.receiver
            callee_name = call_info.callee_name
            targets: list[str] = []

            if receiver in ("self", "this") and caller_class:
                cls_key = f"{caller_file}:{caller_class}"
                targets = [
                    m for m in class_methods.get(cls_key, [])
                    if all_functions[m]["name"] == callee_name
                    and m != caller_id
                ]
                if not targets:
                    bases = all_classes.get(cls_key, {}).get(
                        "base_classes", []
                    )
                    for bname in bases:
                        for bcls_id, binfo in all_classes.items():
                            if binfo["name"] == bname:
                                targets.extend(
                                    m
                                    for m in class_methods.get(bcls_id, [])
                                    if all_functions[m]["name"] == callee_name
                                )
                        if targets:
                            break

            elif receiver is not None:
                target_file = module_alias_map.get(
                    (caller_file, receiver)
                )
                if target_file:
                    targets = [
                        fid
                        for fid in file_to_func_ids.get(target_file, [])
                        if all_functions[fid]["name"] == callee_name
                    ]

            if not targets:
                candidates = name_to_ids.get(callee_name, [])

                imported = import_name_map.get(
                    (caller_file, callee_name), []
                )
                if imported:
                    targets = [t for t in imported if t != caller_id]
                else:
                    same_file = [
                        c for c in candidates
                        if all_functions[c]["file_path"] == caller_file
                        and c != caller_id
                    ]
                    if same_file:
                        targets = same_file
                    else:
                        caller_dir = str(Path(caller_file).parent)
                        same_mod = [
                            c for c in candidates
                            if str(
                                Path(all_functions[c]["file_path"]).parent
                            ) == caller_dir
                            and c != caller_id
                        ]
                        if same_mod:
                            targets = same_mod
                        elif len(candidates) == 1 and candidates[0] != caller_id:
                            targets = candidates

            for target_id in targets:
                edge = (caller_id, target_id)
                if edge in created or target_id == caller_id:
                    continue
                target_info = all_functions.get(target_id)
                if target_info and target_info.get("class_name") == "__static__":
                    if target_info["file_path"] != caller_file:
                        continue
                created.add(edge)
                edge_rows.append({"from_id": caller_id, "to_id": target_id})

        if edge_rows:
            self._save_and_load_rel_csv("CALLS", edge_rows,
                                        "Function", "Function")

    def _create_modules(self, repo: Path) -> None:
        """Create Module nodes for each directory that contains indexed files."""
        rows = list(self.conn.execute(
            "MATCH (f:File) WHERE f.is_external = 0 RETURN f.path"
        ))
        seen_dirs: set[str] = set()
        mod_rows: list[dict] = []
        bt_edges: list[dict] = []

        for (path_val,) in rows:
            parts = Path(path_val).parts
            for depth in range(1, len(parts)):
                dir_path = "/".join(parts[:depth])
                if dir_path in seen_dirs:
                    continue
                seen_dirs.add(dir_path)
                mod_name = parts[depth - 1]
                mod_fqn = f"module:{dir_path}"
                mod_rows.append({
                    "id": _make_id(mod_fqn),
                    "fqn": mod_fqn,
                    "name": mod_name,
                    "path_prefix": dir_path,
                })

        for (path_val,) in rows:
            parent_dir = str(Path(path_val).parent)
            if parent_dir == ".":
                continue
            mod_fqn = f"module:{parent_dir}"
            bt_edges.append({
                "from_id": _make_id(path_val),
                "to_id": _make_id(mod_fqn),
            })

        if mod_rows:
            self._save_and_load_node_csv("Module", mod_rows,
                                         ["id", "fqn", "name", "path_prefix"])
            if bt_edges:
                self._save_and_load_rel_csv("BELONGS_TO", bt_edges,
                                            "File", "Module")

    def _build_embeddings(self, all_functions: dict[str, dict]) -> None:
        """Compute embeddings for all functions, store in zvec + memory cache."""
        texts: list[str] = []
        ids: list[str] = []
        for fid, func in all_functions.items():
            parts = [func["signature"]]
            if func.get("doc_comment"):
                parts.append(func["doc_comment"])
            if func.get("body_summary"):
                parts.append(func["body_summary"])
            texts.append(" ".join(parts))
            ids.append(fid)

        if not texts:
            return

        embeddings = self.model.encode(
            texts, show_progress_bar=True, normalize_embeddings=True
        )

        docs = [
            zvec.Doc(id=fid, vectors={"code_emb": emb.tolist()})
            for fid, emb in zip(ids, embeddings)
        ]
        _BATCH = 1000
        for i in range(0, len(docs), _BATCH):
            self.collection.insert(docs[i : i + _BATCH])

        for fid, emb in zip(ids, embeddings):
            self._emb_cache[fid] = emb

    def build_vectors(self, progress: bool = True) -> None:
        """Build vector embeddings from an existing graph (no re-parse needed).

        Reads all non-historical Function nodes from the graph, computes
        embeddings, and stores them in zvec.  Safe to call when the graph is
        already built but vectors are missing or incomplete.
        """
        if progress:
            print("Reading functions from graph...", flush=True)

        all_functions: dict[str, dict] = {}
        for row in self.conn.execute(
            "MATCH (f:Function) WHERE f.is_historical = 0 "
            "RETURN f.id, f.name, f.signature, f.doc_comment, "
            "f.file_path, f.class_name"
        ):
            fid = row[0]
            all_functions[fid] = {
                "signature": row[2] or "",
                "doc_comment": row[3] or "",
            }

        if progress:
            print(f"  {len(all_functions)} functions loaded from graph",
                  flush=True)
            print("Computing embeddings...", flush=True)

        self._build_embeddings(all_functions)

        if progress:
            print(f"  {len(all_functions)} vectors stored", flush=True)

    # ========================================================================
    # State persistence (graph as single source of truth)
    # ========================================================================

    def _save_commit(
        self,
        commit: str,
        repo_path: str,
        languages: list[str],
    ) -> None:
        """Save indexing metadata to Metadata nodes in the graph."""
        self._save_meta("last_commit", commit or "")
        self._save_meta("repo_path", repo_path)
        self._save_meta("languages", json.dumps(languages))

    def _load_commit(self) -> dict | None:
        """Load indexing metadata from Metadata nodes in the graph."""
        try:
            rows = list(self.conn.execute(
                "MATCH (m:Metadata) RETURN m.id, m.value"
            ))
        except Exception:
            return None
        if not rows:
            return None
        result = {}
        for row in rows:
            result[row[0]] = row[1]
        if "last_commit" not in result:
            return None
        return result

    def _restore_from_graph(self) -> tuple[
        dict[str, dict],
        list[tuple[str, CallInfo]],
        list[ParsedImport],
        dict[str, dict],
    ]:
        """Restore indexing state from the graph.

        Since raw JSON fields (call_raw, import_raw, base_classes_raw) have
        been removed, this method restores what it can from the graph and
        returns empty call/import lists.  A full re-index is recommended
        after major schema changes.
        """
        all_functions: dict[str, dict] = {}

        for row in self.conn.execute(
            "MATCH (f:Function) WHERE f.is_historical = 0 "
            "RETURN f.id, f.name, f.signature, "
            "f.doc_comment, f.file_path, f.class_name"
        ):
            fid = row[0]
            all_functions[fid] = {
                "name": row[1],
                "signature": row[2] or "",
                "doc_comment": row[3] or "",
                "file_path": row[4] or "",
                "class_name": row[5] if row[5] else None,
            }

        all_imports: list[ParsedImport] = []
        all_calls: list[tuple[str, CallInfo]] = []

        all_classes: dict[str, dict] = {}
        for row in self.conn.execute(
            "MATCH (c:Class) RETURN c.id, c.name, c.file_path"
        ):
            all_classes[row[0]] = {
                "name": row[1],
                "file_path": row[2] or "",
                "base_classes": [],
            }

        return all_functions, all_calls, all_imports, all_classes

    # ========================================================================
    # Incremental update
    # ========================================================================

    def _remove_file_graph_data(self, rel_path: str) -> int:
        """Remove all graph nodes and edges for a single file.

        Returns the number of Function nodes removed.
        """
        func_count = 0
        try:
            rows = list(self.conn.execute(
                f"MATCH (f:Function) "
                f"WHERE f.file_path = '{_cesc(rel_path)}' "
                f"RETURN count(f)"
            ))
            func_count = rows[0][0] if rows else 0
        except Exception:
            pass

        for label in ("Function", "Class"):
            try:
                self.conn.execute(
                    f"MATCH (n:{label}) "
                    f"WHERE n.file_path = '{_cesc(rel_path)}' "
                    f"DETACH DELETE n"
                )
            except Exception as exc:
                _log.warning("Failed to delete %s for %s: %s", label, rel_path, exc)

        file_id = _make_id(rel_path)
        try:
            self.conn.execute(
                f"MATCH (f:File {{id: '{_cesc(file_id)}'}}) "
                f"DETACH DELETE f"
            )
        except Exception as exc:
            _log.warning("Failed to delete File node %s: %s", rel_path, exc)

        return func_count

    def _delete_all_edges(self, rel_type: str) -> None:
        """Delete all edges of a given relationship type."""
        _EDGE_ENDPOINTS = {
            "CALLS": ("Function", "Function"),
            "IMPORTS": ("File", "File"),
            "INHERITS": ("Class", "Class"),
        }
        src, dst = _EDGE_ENDPOINTS.get(rel_type, ("", ""))
        if not src:
            return
        try:
            self.conn.execute(
                f"MATCH (:{src})-[r:{rel_type}]->(:{dst}) DELETE r"
            )
        except Exception:
            pass

    def incremental_update(
        self,
        repo_path: str,
        languages: list[str] | None = None,
    ) -> UpdateReport:
        """Incrementally update the index based on git diff.

        Only re-parses changed files, reuses cached embeddings for
        unchanged functions, and re-resolves all call/import/inheritance
        edges for correctness.
        """
        t0 = time.time()
        repo_path = os.path.abspath(repo_path)

        meta = self._load_commit()
        if meta is None:
            raise RuntimeError(
                "No previous index state. Call index() first."
            )

        languages = languages or json.loads(
            meta.get("languages", '["python"]')
        )
        old_commit = meta["last_commit"]
        new_commit = _git_head(repo_path) or ""

        if not old_commit or not new_commit:
            raise RuntimeError(
                "incremental_update requires a git repository "
                "with at least one commit."
            )

        if old_commit == new_commit:
            return UpdateReport(
                commit_before=old_commit,
                commit_after=new_commit,
                duration_ms=(time.time() - t0) * 1000,
            )

        # -- detect changed files ---------------------------------------------
        raw_changes = _git_diff_files(repo_path, old_commit, new_commit)

        adapters = _get_adapters(languages)
        supported_exts: set[str] = set()
        for adapter in adapters:
            supported_exts.update(adapter.supported_extensions())

        changes: dict[str, str] = {}
        for path, status in raw_changes.items():
            if any(path.endswith(ext) for ext in supported_exts):
                changes[path] = status

        files_added = sorted(p for p, s in changes.items() if s == "A")
        files_modified = sorted(p for p, s in changes.items() if s == "M")
        files_deleted = sorted(p for p, s in changes.items() if s == "D")

        # -- restore cached state from graph ----------------------------------
        self._emb_cache.clear()
        all_functions, all_calls, all_imports, all_classes = (
            self._restore_from_graph()
        )
        cached_embs = dict(self._emb_cache)

        # -- remove data for deleted / modified files -------------------------
        removed_files = set(files_deleted + files_modified)
        funcs_removed = 0
        removed_func_ids: set[str] = set()

        for rel_path in removed_files:
            fids = [
                fid for fid, info in all_functions.items()
                if info["file_path"] == rel_path
            ]
            removed_func_ids.update(fids)
            for fid in fids:
                del all_functions[fid]
                cached_embs.pop(fid, None)
            funcs_removed += len(fids)

            all_calls = [
                (cid, ci) for cid, ci in all_calls
                if cid not in removed_func_ids
            ]
            all_imports = [
                imp for imp in all_imports
                if imp.source_path != rel_path
            ]
            cls_ids = [
                cid for cid in all_classes
                if all_classes[cid]["file_path"] == rel_path
            ]
            for cid in cls_ids:
                del all_classes[cid]

            self._remove_file_graph_data(rel_path)

        # -- parse and index new / modified files -----------------------------
        repo = Path(repo_path)
        new_func_ids: set[str] = set()

        file_rows: list[dict] = []
        func_rows: list[dict] = []
        class_rows: list[dict] = []

        for rel_path in files_added + files_modified:
            filepath = repo / rel_path
            if not filepath.is_file():
                continue
            adapter = _match_adapter(filepath, adapters)
            if adapter is None:
                continue

            source = filepath.read_bytes()
            prev_ids = set(all_functions.keys())

            self._collect_file(
                rel_path, source, adapter,
                all_functions, all_calls, all_imports, all_classes,
                file_rows, func_rows, class_rows,
            )

            for fid in all_functions:
                if fid not in prev_ids:
                    new_func_ids.add(fid)

        if file_rows:
            self._bulk_import_nodes(file_rows, func_rows, class_rows)

        funcs_added = len(new_func_ids)

        # -- re-resolve all cross-file edges ----------------------------------
        for rel_type in ("CALLS", "IMPORTS", "INHERITS"):
            self._delete_all_edges(rel_type)

        self._resolve_file_imports(all_imports)
        self._resolve_inheritance(all_classes)
        self._resolve_calls(
            all_functions, all_calls, all_imports, all_classes
        )
        self._create_modules(repo)

        edges_recomputed = 0
        try:
            rows = list(self.conn.execute(
                "MATCH ()-[r:CALLS]->() RETURN count(r)"
            ))
            edges_recomputed = rows[0][0] if rows else 0
        except Exception:
            pass

        # -- update embeddings ------------------------------------------------
        new_funcs_to_embed = {
            fid: all_functions[fid]
            for fid in new_func_ids
            if fid in all_functions
        }

        self._emb_cache = dict(cached_embs)

        if new_funcs_to_embed:
            self._build_embeddings(new_funcs_to_embed)

        embeddings_computed = len(new_funcs_to_embed)
        embeddings_reused = len(cached_embs) - len(removed_func_ids)

        # -- save updated commit reference ------------------------------------
        self._save_commit(new_commit, repo_path, languages)

        duration_ms = (time.time() - t0) * 1000

        return UpdateReport(
            commit_before=old_commit,
            commit_after=new_commit,
            files_added=files_added,
            files_modified=files_modified,
            files_deleted=files_deleted,
            functions_added=funcs_added,
            functions_removed=funcs_removed,
            edges_recomputed=edges_recomputed,
            embeddings_computed=embeddings_computed,
            embeddings_reused=max(0, embeddings_reused),
            duration_ms=duration_ms,
        )

    # ========================================================================
    # Use Case 1: Impact Analysis
    # ========================================================================

    def impact(
        self,
        function: str,
        change: str,
        max_hops: int = 3,
    ) -> list[ImpactResult]:
        """Find callers of *function* within *max_hops*, ranked by relevance.

        Graph provides the caller set (zero false positives).
        Vector ranks callers by semantic relevance to the change description.
        """
        # Step 1 [neug]: find all callers via variable-length CALLS path.
        # Use forward direction: caller -[:CALLS*1..N]-> target
        rows = list(
            self.conn.execute(
                f"MATCH (caller:Function)-[:CALLS*1..{max_hops}]->"
                f"(target:Function {{name: '{_cesc(function)}'}}) "
                f"RETURN DISTINCT caller.id, caller.name, "
                f"caller.qualified_name, caller.file_path"
            )
        )

        if not rows:
            print(f"No callers found for '{function}'")
            return []

        candidate_ids = {row[0] for row in rows}
        candidate_info = {row[0]: row for row in rows}

        # Step 2 [sentence-transformers]: embed the change description
        change_vec = self.model.encode(change, normalize_embeddings=True)

        # Step 3 [Python]: rank candidates by cosine similarity
        scored: list[ImpactResult] = []
        for cid in candidate_ids:
            emb = self._emb_cache.get(cid)
            sim = float(np.dot(change_vec, emb)) if emb is not None else 0.0
            info = candidate_info[cid]
            scored.append(
                ImpactResult(
                    name=info[1],
                    qualified_name=info[2],
                    file_path=info[3] or "",
                    hop_distance=self._hop_distance(function, info[1], max_hops),
                    relevance=sim,
                )
            )

        scored.sort(key=lambda x: -x.relevance)
        return scored

    # ========================================================================
    # Use Case 2: Module-Scoped Semantic Search
    # ========================================================================

    def similar(
        self,
        function: str,
        scope: str,
        topk: int = 10,
    ) -> list[SimilarResult]:
        """Find functions similar to *function* within the given scope.

        Graph constrains the search to the module boundary.
        Vector ranks results by semantic similarity.
        """
        # Step 1 [neug]: find all functions in the module (single MATCH)
        rows = list(
            self.conn.execute(
                f"MATCH (m:Module {{path_prefix: '{_cesc(scope)}'}})"
                f"<-[:BELONGS_TO]-(f:File)"
                f"-[:DEFINES_FUNC]->(func:Function) "
                f"RETURN func.id, func.name, func.signature, func.file_path"
            )
        )

        module_ids = {row[0] for row in rows}
        module_info = {row[0]: row for row in rows}

        # Step 2: get target function's embedding
        target_row = list(
            self.conn.execute(
                f"MATCH (f:Function {{name: '{_cesc(function)}'}}) "
                f"RETURN f.id LIMIT 1"
            )
        )

        if not target_row:
            print(f"Function '{function}' not found")
            return []

        target_id = target_row[0][0]
        target_emb = self._emb_cache.get(target_id)
        if target_emb is None:
            return []

        # Step 3 [Python]: rank module functions by similarity
        scored: list[SimilarResult] = []
        for fid in module_ids:
            if fid == target_id:
                continue
            emb = self._emb_cache.get(fid)
            if emb is None:
                continue
            sim = float(np.dot(target_emb, emb))
            info = module_info[fid]
            scored.append(
                SimilarResult(
                    name=info[1],
                    signature=info[2] or "",
                    file_path=info[3] or "",
                    score=sim,
                )
            )

        scored.sort(key=lambda x: -x.score)
        return scored[:topk]

    # ========================================================================
    # Use Case 3: Cross-Locate
    # ========================================================================

    def cross_locate(
        self,
        query: str,
        topk: int = 10,
    ) -> CrossLocateResult:
        """Find semantically related functions, then reveal connections.

        Vector finds seed functions by semantic similarity.
        Graph discovers call-chain connections between seeds.
        """
        # Step 1 [zvec]: global semantic search
        query_vec = self.model.encode(
            query, normalize_embeddings=True
        ).tolist()

        hits = self.collection.query(
            zvec.VectorQuery("code_emb", vector=query_vec),
            topk=topk,
        )

        seed_ids = [h.id for h in hits]
        seed_scores = {h.id: h.score for h in hits}

        # Get function details from neug
        seeds: list[dict] = []
        for sid in seed_ids:
            rows = list(
                self.conn.execute(
                    f"MATCH (f:Function {{id: '{_cesc(sid)}'}}) "
                    f"RETURN f.name, f.file_path"
                )
            )
            if rows:
                seeds.append(
                    {
                        "id": sid,
                        "name": rows[0][0],
                        "file_path": rows[0][1] or "",
                        "score": seed_scores.get(sid, 0),
                    }
                )

        # Step 2 [neug]: find structural connections between seeds.
        # Use SHORTEST repeated path (NeuG syntax) — try both directions.
        connections: list[dict] = []
        for i, a in enumerate(seeds):
            for b in seeds[i + 1 :]:
                conn_info = self._shortest_between(a["id"], b["id"])
                if conn_info is None:
                    conn_info = self._shortest_between(b["id"], a["id"])
                if conn_info is not None:
                    connections.append(
                        {
                            "from": a["name"],
                            "to": b["name"],
                            "distance": conn_info[0],
                            "via": conn_info[1],
                        }
                    )

        # Step 3: cluster connected seeds
        clusters = self._find_clusters(seeds, connections)

        return CrossLocateResult(
            seeds=seeds,
            connections=connections,
            clusters=clusters,
        )

    # ========================================================================
    # Comparison helper: vector-only search
    # ========================================================================

    def vector_only_search(self, query: str, topk: int = 10) -> list[dict]:
        """Pure vector search for A/B comparison."""
        query_vec = self.model.encode(
            query, normalize_embeddings=True
        ).tolist()

        hits = self.collection.query(
            zvec.VectorQuery("code_emb", vector=query_vec),
            topk=topk,
        )
        return [{"id": h.id, "score": h.score} for h in hits]

    # ========================================================================
    # Use Case 4: Dead Code Detection
    # ========================================================================

    _ENTRY_NAMES = frozenset({
        "main", "__main__", "cli", "app", "run", "start", "setup",
        "configure", "init", "__init__", "register",
    })

    def dead_code(self) -> list[DeadCodeResult]:
        """Find functions with no callers that are not entry points.

        Graph-only analysis: unreachable functions are dead code candidates.
        """
        all_ids: dict[str, tuple[str, str, str]] = {}
        for row in self.conn.execute(
            "MATCH (f:Function) WHERE f.is_historical = 0 "
            "RETURN f.id, f.name, f.qualified_name, f.file_path"
        ):
            all_ids[row[0]] = (row[1], row[2] or "", row[3] or "")

        called_ids: set[str] = set()
        for row in self.conn.execute(
            "MATCH (:Function)-[:CALLS]->(f:Function) "
            "RETURN DISTINCT f.id"
        ):
            called_ids.add(row[0])

        results: list[DeadCodeResult] = []
        for fid, (name, qname, fpath) in all_ids.items():
            if fid in called_ids:
                continue
            if name in self._ENTRY_NAMES:
                continue
            if name.startswith("_"):
                continue
            if name.startswith("test_"):
                continue
            if fpath and "test" in fpath.lower():
                continue
            results.append(DeadCodeResult(
                name=name,
                qualified_name=qname,
                file_path=fpath,
                reason="no callers",
            ))

        results.sort(key=lambda x: (x.file_path, x.name))
        return results

    # ========================================================================
    # Use Case 5: Circular Dependency Detection
    # ========================================================================

    def circular_deps(self) -> list[list[str]]:
        """Detect circular import chains at the file level.

        Graph-only analysis using DFS cycle detection on IMPORTS edges.
        """
        graph: dict[str, list[str]] = {}
        for row in self.conn.execute(
            "MATCH (a:File)-[:IMPORTS]->(b:File) "
            "RETURN a.path, b.path"
        ):
            graph.setdefault(row[0], []).append(row[1])

        cycles: list[list[str]] = []
        visited: set[str] = set()

        def dfs(node: str, path: list[str], on_stack: set[str]) -> None:
            if node in on_stack:
                start = path.index(node)
                cycles.append(path[start:] + [node])
                return
            if node in visited:
                return
            visited.add(node)
            on_stack.add(node)
            path.append(node)
            for nbr in graph.get(node, []):
                dfs(nbr, path, on_stack)
            path.pop()
            on_stack.discard(node)

        for node in graph:
            if node not in visited:
                dfs(node, [], set())

        return cycles

    # ========================================================================
    # Use Case 6: Hotspot Analysis
    # ========================================================================

    def hotspots(self, topk: int = 10) -> list[HotspotResult]:
        """Rank functions by structural risk (fan-in x fan-out).

        High fan-in + high fan-out = change is risky and affects many callers.
        """
        fan_in: dict[str, int] = {}
        for row in self.conn.execute(
            "MATCH (caller:Function)-[:CALLS]->(f:Function) "
            "RETURN f.id, count(caller)"
        ):
            fan_in[row[0]] = row[1]

        fan_out: dict[str, int] = {}
        for row in self.conn.execute(
            "MATCH (f:Function)-[:CALLS]->(callee:Function) "
            "RETURN f.id, count(callee)"
        ):
            fan_out[row[0]] = row[1]

        all_funcs: dict[str, tuple[str, str]] = {}
        for row in self.conn.execute(
            "MATCH (f:Function) WHERE f.is_historical = 0 "
            "RETURN f.id, f.name, f.file_path"
        ):
            all_funcs[row[0]] = (row[1], row[2] or "")

        results: list[HotspotResult] = []
        for fid, (name, fpath) in all_funcs.items():
            fi = fan_in.get(fid, 0)
            fo = fan_out.get(fid, 0)
            risk = (fi + 1) * (fo + 1)
            results.append(HotspotResult(
                name=name,
                file_path=fpath,
                fan_in=fi,
                fan_out=fo,
                risk_score=float(risk),
            ))

        results.sort(key=lambda x: -x.risk_score)
        return results[:topk]

    # ========================================================================
    # Use Case 7: Class Hierarchy
    # ========================================================================

    def class_hierarchy(
        self, class_name: str | None = None
    ) -> list[dict]:
        """Return inheritance relationships.

        If *class_name* is given, return the chain for that class.
        Otherwise return all INHERITS pairs.
        """
        if class_name:
            rows = list(self.conn.execute(
                f"MATCH (c:Class {{name: '{_cesc(class_name)}'}})"
                f"-[:INHERITS*1..10]->(base:Class) "
                f"RETURN c.name, c.file_path, base.name, base.file_path"
            ))
        else:
            rows = list(self.conn.execute(
                "MATCH (c:Class)-[:INHERITS]->(base:Class) "
                "RETURN c.name, c.file_path, base.name, base.file_path"
            ))

        return [
            {
                "child": row[0],
                "child_file": row[1] or "",
                "parent": row[2],
                "parent_file": row[3] or "",
            }
            for row in rows
        ]

    # ========================================================================
    # Use Case 8: Module Coupling Analysis
    # ========================================================================

    def module_coupling(self, topk: int = 10) -> list[CouplingResult]:
        """Discover cross-module coupling via CALLS edges.

        Returns module pairs ranked by total cross-boundary calls.
        """
        func_module: dict[str, str] = {}
        for row in self.conn.execute(
            "MATCH (fn:Function)<-[:DEFINES_FUNC]-(f:File)"
            "-[:BELONGS_TO]->(m:Module) "
            "RETURN fn.id, m.name"
        ):
            func_module[row[0]] = row[1]

        pair_data: dict[tuple[str, str], dict] = {}
        for row in self.conn.execute(
            "MATCH (a:Function)-[:CALLS]->(b:Function) "
            "RETURN a.id, a.name, b.id, b.name"
        ):
            a_mod = func_module.get(row[0])
            b_mod = func_module.get(row[2])
            if not a_mod or not b_mod or a_mod == b_mod:
                continue
            key = (min(a_mod, b_mod), max(a_mod, b_mod))
            if key not in pair_data:
                pair_data[key] = {"a_to_b": 0, "b_to_a": 0, "funcs": []}
            if a_mod <= b_mod:
                pair_data[key]["a_to_b"] += 1
            else:
                pair_data[key]["b_to_a"] += 1
            pair_data[key]["funcs"].append(f"{row[1]}->{row[3]}")

        results: list[CouplingResult] = []
        for (m1, m2), info in pair_data.items():
            results.append(CouplingResult(
                module_a=m1,
                module_b=m2,
                calls_a_to_b=info["a_to_b"],
                calls_b_to_a=info["b_to_a"],
                functions_involved=info["funcs"],
            ))

        results.sort(key=lambda x: -(x.calls_a_to_b + x.calls_b_to_a))
        return results[:topk]

    # ========================================================================
    # Internal helpers
    # ========================================================================

    def _hop_distance(
        self, target_name: str, caller_name: str, max_hops: int = 3
    ) -> int:
        """Shortest call-chain distance using NeuG SHORTEST repeated path."""
        try:
            rows = list(
                self.conn.execute(
                    f"MATCH (a:Function {{name: '{_cesc(caller_name)}'}})"
                    f"-[p:CALLS* SHORTEST 1..{max_hops}]->"
                    f"(b:Function {{name: '{_cesc(target_name)}'}}) "
                    f"RETURN LENGTH(p)"
                )
            )
            if rows:
                return rows[0][0]
        except Exception:
            pass
        return -1

    def _shortest_between(
        self, id_a: str, id_b: str, max_hops: int = 4
    ) -> tuple[int, list[str]] | None:
        """Return (distance, [node_names]) for shortest CALLS path, or None."""
        try:
            rows = list(
                self.conn.execute(
                    f"MATCH (f1:Function {{id: '{_cesc(id_a)}'}})"
                    f"-[p:CALLS* SHORTEST 1..{max_hops}]->"
                    f"(f2:Function {{id: '{_cesc(id_b)}'}}) "
                    f"RETURN LENGTH(p), PROPERTIES(nodes(p), 'name')"
                )
            )
            if rows and rows[0][0] is not None:
                return (rows[0][0], rows[0][1] or [])
        except Exception:
            pass
        return None

    def _find_clusters(
        self, seeds: list[dict], connections: list[dict]
    ) -> list[list[str]]:
        """Union-Find clustering of seeds by graph connections."""
        parent = {s["name"]: s["name"] for s in seeds}

        def find(x: str) -> str:
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        for conn in connections:
            a, b = find(conn["from"]), find(conn["to"])
            if a != b:
                parent[a] = b

        groups: dict[str, list[str]] = {}
        for s in seeds:
            root = find(s["name"])
            groups.setdefault(root, []).append(s["name"])

        return list(groups.values())

    def _get_stats(self) -> dict[str, int]:
        files = list(self.conn.execute(
            "MATCH (f:File) WHERE f.is_external = 0 RETURN count(f)"))[0][0]
        ext_files = list(self.conn.execute(
            "MATCH (f:File) WHERE f.is_external = 1 RETURN count(f)"))[0][0]
        functions = list(self.conn.execute(
            "MATCH (f:Function) WHERE f.is_historical = 0 "
            "RETURN count(f)"))[0][0]
        ghost_functions = list(self.conn.execute(
            "MATCH (f:Function) WHERE f.is_historical = 1 "
            "RETURN count(f)"))[0][0]
        edges = list(self.conn.execute(
            "MATCH ()-[e:CALLS]->() RETURN count(e)"))[0][0]
        try:
            vec_count = self.collection.stats.doc_count
        except Exception:
            vec_count = len(self._emb_cache)
        return {
            "files": files,
            "ext_files": ext_files,
            "functions": functions,
            "ghost_functions": ghost_functions,
            "edges": edges,
            "vectors": vec_count,
        }

    # ========================================================================
    # Evolution Knowledge Graph (Module 3)
    # ========================================================================

    def _staging_dir(self) -> str:
        """Return (and create) a staging directory for temp COPY FROM CSVs."""
        d = os.path.join(self.db_dir, ".staging")
        os.makedirs(d, exist_ok=True)
        return d

    def _flush_batch(
        self,
        commits: list[dict],
        touches: list[dict],
        modifies: list[dict],
        ghost_funcs: list[dict],
        *,
        checkpoint: bool = True,
    ) -> None:
        """Bulk-load a batch of commits/edges into neug via COPY FROM.

        Callers must ensure commits are new (not already in the graph).
        Set *checkpoint* to False to defer flushing to disk.
        """
        if not commits:
            return
        staging = self._staging_dir()
        commit_cols = ["id", "fqn", "hash", "message", "author",
                       "timestamp", "version_tag"]
        edge_cols = ["from_id", "to_id"]
        ghost_cols = [
            "id", "fqn", "name", "qualified_name", "signature",
            "file_path", "start_line", "end_line", "doc_comment",
            "class_name", "language", "is_historical",
        ]

        t0 = time.time()
        if ghost_funcs:
            p = os.path.join(staging, "Function.csv")
            self._write_csv(p, ghost_funcs, ghost_cols, dedup_col="id")
            self.conn.execute(
                f'COPY Function FROM "{p}" '
                f'(header=true, delim=",", escaping=false)')

        p = os.path.join(staging, "Commit.csv")
        self._write_csv(p, commits, commit_cols)
        self.conn.execute(
            f'COPY Commit FROM "{p}" '
            f'(header=true, delim=",", escaping=false)')
        print(f"    flush: COPY {len(commits)} commits"
              f" {time.time()-t0:.1f}s", flush=True)

        if touches:
            p = os.path.join(staging, "TOUCHES.csv")
            self._write_csv(p, touches, edge_cols)
            self.conn.execute(
                f'COPY TOUCHES FROM "{p}" '
                f'(from="Commit", to="File", '
                f'header=true, delim=",", escaping=false)')

        if modifies:
            p = os.path.join(staging, "MODIFIES.csv")
            self._write_csv(p, modifies, edge_cols)
            self.conn.execute(
                f'COPY MODIFIES FROM "{p}" '
                f'(from="Commit", to="Function", '
                f'header=true, delim=",", escaping=false)')

        if checkpoint:
            self.conn.execute("CHECKPOINT")
        shutil.rmtree(staging, ignore_errors=True)

    def ingest_commits(
        self,
        repo_path: str,
        from_ref: str,
        to_ref: str = "HEAD",
        languages: list[str] | None = None,
        skip_merges: bool = True,
        batch_size: int = 2000,
        skip_modifies: bool = False,
    ) -> int:
        """Ingest git commits between two refs, creating Commit nodes,
        MODIFIES edges (Commit->Function), and TOUCHES edges (Commit->File).

        Uses batch COPY FROM for bulk loading instead of individual Cypher
        statements, which is significantly faster for large repos.

        Returns the number of **new** commits ingested.
        """
        languages = languages or ["c"]
        adapters = _get_adapters(languages)
        supported_exts: set[str] = set()
        for adapter in adapters:
            supported_exts.update(adapter.supported_extensions())

        repo = Path(repo_path)

        commits = self._parse_git_log(
            str(repo), from_ref, to_ref, skip_merges,
            include_files=True,
        )
        if not commits:
            return 0

        existing_hashes: set[str] = set()
        for row in self.conn.execute(
            "MATCH (c:Commit) RETURN c.hash"
        ):
            existing_hashes.add(row[0])

        new_commits = [c for c in commits if c["hash"] not in existing_hashes]
        if not new_commits:
            print(f"All {len(commits)} commits already ingested, skipping.")
            if commits and not self._load_meta("oldest_ingested"):
                oldest = min(commits, key=lambda c: c["timestamp"])
                self._save_meta("oldest_ingested", oldest["hash"])
            return 0

        print(f"  {len(new_commits)} new commits to ingest "
              f"({len(commits) - len(new_commits)} already exist)",
              flush=True)

        known_funcs: dict[tuple[str, str], str] = {}
        for row in self.conn.execute(
            "MATCH (f:Function) RETURN f.name, f.file_path, f.id"
        ):
            known_funcs[(row[0], row[1])] = row[2]

        known_files: set[str] = set()
        for row in self.conn.execute(
            "MATCH (f:File) WHERE f.is_external = 0 RETURN f.path"
        ):
            known_files.add(row[0])

        self.conn.execute("CHECKPOINT")

        commit_csv_cols = ["id", "fqn", "hash", "message", "author",
                           "timestamp", "version_tag"]
        edge_cols = ["from_id", "to_id"]
        ds_commit_csv = os.path.join(self._dataset_nodes_dir(), "Commit.csv")
        ds_touch_csv = os.path.join(self._dataset_edges_dir(), "TOUCHES.csv")
        ds_mod_csv = os.path.join(self._dataset_edges_dir(), "MODIFIES.csv")

        pending_commits: list[dict] = []
        pending_touches: list[dict] = []
        pending_modifies: list[dict] = []
        pending_ghosts: list[dict] = []

        import json as _json
        count = 0
        t_start = time.time()
        ds_commits: list[dict] = []
        checkpoint_interval = 2000
        since_checkpoint = 0

        for idx, ci in enumerate(new_commits, 1):
            cr, touches, modifies, ghosts = self._ingest_one_commit(
                ci, repo, adapters, supported_exts,
                known_funcs, known_files,
                skip_modifies=skip_modifies,
            )
            pending_commits.append(cr)
            if touches:
                ds_commits.append(cr)
            pending_touches.extend(touches)
            pending_modifies.extend(modifies)
            pending_ghosts.extend(ghosts)
            count += 1

            if count % batch_size == 0 or idx == len(new_commits):
                elapsed = time.time() - t_start
                rate = count / elapsed if elapsed > 0 else 0
                print(f"  [{count}/{len(new_commits)}] "
                      f"{ci['hash'][:8]}  "
                      f"({rate:.1f} commits/s, "
                      f"{elapsed:.0f}s elapsed)",
                      flush=True)

                since_checkpoint += len(pending_commits)
                do_ckpt = (since_checkpoint >= checkpoint_interval
                           or idx == len(new_commits))

                self._flush_batch(pending_commits, pending_touches,
                                  pending_modifies, pending_ghosts,
                                  checkpoint=do_ckpt)
                if do_ckpt:
                    since_checkpoint = 0
                self._rev_func_cache.clear()

                self._append_csv(ds_commit_csv, ds_commits,
                                 commit_csv_cols)
                self._append_csv(ds_touch_csv, pending_touches, edge_cols)
                if pending_modifies:
                    self._append_csv(ds_mod_csv, pending_modifies, edge_cols)
                pending_commits.clear()
                ds_commits.clear()
                pending_touches.clear()
                pending_modifies.clear()
                pending_ghosts.clear()

        oldest_new = min(new_commits, key=lambda c: c["timestamp"])
        prev_oldest_hash = self._load_meta("oldest_ingested")
        should_update = prev_oldest_hash is None
        if not should_update and prev_oldest_hash:
            rows = list(self.conn.execute(
                f"MATCH (c:Commit {{hash: '{_cesc(prev_oldest_hash)}'}}) "
                "RETURN c.timestamp"
            ))
            if not rows:
                should_update = True
            elif oldest_new["timestamp"] < rows[0][0]:
                should_update = True
        if should_update:
            self._save_meta("oldest_ingested", oldest_new["hash"])

        self._write_manifest({
            "commits_ingested": count,
            "commit_range": f"{from_ref}..{to_ref}",
        })

        print(f"Ingested {count} new commits ({from_ref}..{to_ref})")
        return count

    def ingest_more_commits(
        self,
        repo_path: str,
        count: int = 50,
        languages: list[str] | None = None,
        skip_modifies: bool = False,
        skip_merges: bool = False,
    ) -> int:
        """Progressively ingest older commits, walking backwards from the
        oldest previously ingested commit.

        Returns the number of new commits ingested.
        """
        oldest = self._load_meta("oldest_ingested")
        if not oldest:
            _log.warning("No previously ingested commits found; "
                         "use ingest_commits() first.")
            return 0

        languages = languages or ["c"]
        adapters = _get_adapters(languages)
        supported_exts: set[str] = set()
        for adapter in adapters:
            supported_exts.update(adapter.supported_extensions())

        repo = Path(repo_path)
        cmd = [
            "git", "-C", str(repo), "rev-list",
            "--first-parent",
            "--max-count", str(count + 1),
            "--skip", "1",
            oldest,
        ]
        try:
            raw = subprocess.check_output(
                cmd, stderr=subprocess.DEVNULL
            ).decode().strip()
        except subprocess.CalledProcessError:
            return 0

        if not raw:
            print("No more commits to ingest")
            return 0

        older_hashes = raw.splitlines()[:count]
        older_oldest = older_hashes[-1] if older_hashes else oldest
        to_ref = oldest + "^"

        has_parent = subprocess.run(
            ["git", "-C", str(repo), "rev-parse", "--verify", "-q",
             older_oldest + "^"],
            capture_output=True,
        ).returncode == 0

        if has_parent:
            from_ref = older_oldest + "^"
        else:
            from_ref = ""

        n = self.ingest_commits(
            repo_path, from_ref, to_ref,
            languages=languages, skip_merges=skip_merges,
            skip_modifies=skip_modifies,
        )

        self._save_meta("oldest_ingested", older_oldest)
        return n

    _BACKFILL_MARKER = "bf"

    def backfill_modifies(
        self,
        repo_path: str,
        languages: list[str] | None = None,
        limit: int | None = None,
    ) -> int:
        """Compute MODIFIES edges for commits not yet backfilled.

        Uses the ``version_tag`` field on Commit nodes as a marker:
        commits with ``version_tag = 'bf'`` are considered done and
        skipped.  This means backfill is **incremental**: running
        ``backfill(limit=200)`` then ``backfill(limit=300)`` produces
        500 total backfilled commits (not 300).

        Returns the number of commits processed.
        """
        languages = languages or ["c"]
        adapters = _get_adapters(languages)
        supported_exts: set[str] = set()
        for adapter in adapters:
            supported_exts.update(adapter.supported_extensions())

        repo = Path(repo_path)

        try:
            # Avoid DISTINCT in Cypher (neug crashes on DISTINCT +
            # string filter + edge traversal); deduplicate in Python.
            raw = list(self.conn.execute(
                f"MATCH (c:Commit)-[:MODIFIES]->() "
                f"WHERE c.version_tag <> '{self._BACKFILL_MARKER}' "
                f"RETURN c.id"
            ))
            migrate_ids = list(dict.fromkeys(r[0] for r in raw))
            if migrate_ids:
                for cid in migrate_ids:
                    self.conn.execute(
                        f"MATCH (c:Commit {{id: '{_cesc(cid)}'}}) "
                        f"SET c.version_tag = '{self._BACKFILL_MARKER}'"
                    )
                self.conn.execute("CHECKPOINT")
                print(f"  Migrated {len(migrate_ids)} previously-backfilled "
                      f"commits to version_tag='{self._BACKFILL_MARKER}'",
                      flush=True)
        except Exception as exc:
            _log.warning("Migration check failed: %s", exc)

        q = (f"MATCH (c:Commit) WHERE c.version_tag <> '{self._BACKFILL_MARKER}' "
             "RETURN c.hash ORDER BY c.timestamp DESC")
        if limit:
            q += f" LIMIT {limit}"
        commit_hashes = [r[0] for r in self.conn.execute(q)]
        if not commit_hashes:
            print("No commits need MODIFIES backfill.")
            return 0

        print(f"  {len(commit_hashes)} commits to backfill", flush=True)

        known_funcs: dict[tuple[str, str], str] = {}
        for row in self.conn.execute(
            "MATCH (f:Function) RETURN f.name, f.file_path, f.id"
        ):
            known_funcs[(row[0], row[1])] = row[2]

        known_files: set[str] = set()
        for row in self.conn.execute(
            "MATCH (f:File) WHERE f.is_external = 0 RETURN f.path"
        ):
            known_files.add(row[0])

        self.conn.execute("CHECKPOINT")

        ds_mod_csv = os.path.join(self._dataset_edges_dir(), "MODIFIES.csv")
        edge_cols = ["from_id", "to_id"]
        pending_modifies: list[dict] = []
        pending_ghosts: list[dict] = []
        pending_mark: list[str] = []

        batch_size = 100
        count = 0
        t_start = time.time()
        for idx, h in enumerate(commit_hashes, 1):
            commit_fqn = f"commit:{h[:12]}"
            commit_id = _make_id(commit_fqn)

            try:
                self.conn.execute(
                    f"MATCH (c:Commit {{id: '{_cesc(commit_id)}'}})"
                    f"-[r:MODIFIES]->() DELETE r"
                )
            except Exception:
                pass

            modified_pairs = self._extract_modified_funcs_from_diff(
                repo, h, known_files, supported_exts)

            for file_path, fname in modified_pairs:
                func_id, ghost = self._resolve_func_id(
                    fname, file_path, known_funcs)
                if ghost:
                    pending_ghosts.append(ghost)
                pending_modifies.append({
                    "from_id": commit_id, "to_id": func_id})

            pending_mark.append(commit_id)
            count += 1
            if count % batch_size == 0 or idx == len(commit_hashes):
                elapsed = time.time() - t_start
                rate = count / elapsed if elapsed > 0 else 0
                print(f"  backfill [{count}/{len(commit_hashes)}] "
                      f"{h[:8]} ({rate:.1f}/s, {elapsed:.0f}s)",
                      flush=True)

                staging = self._staging_dir()
                if pending_ghosts:
                    ghost_cols = [
                        "id", "fqn", "name", "qualified_name", "signature",
                        "file_path", "start_line", "end_line", "doc_comment",
                        "class_name", "language", "is_historical",
                    ]
                    p = os.path.join(staging, "Function.csv")
                    self._write_csv(p, pending_ghosts, ghost_cols,
                                    dedup_col="id")
                    self.conn.execute(
                        f'COPY Function FROM "{p}" '
                        f'(header=true, delim=",", escaping=false)')
                    pending_ghosts.clear()

                if pending_modifies:
                    p = os.path.join(staging, "MODIFIES.csv")
                    self._write_csv(p, pending_modifies, edge_cols)
                    self.conn.execute(
                        f'COPY MODIFIES FROM "{p}" '
                        f'(from="Commit", to="Function", '
                        f'header=true, delim=",", escaping=false)')
                    self._append_csv(ds_mod_csv, pending_modifies, edge_cols)
                    pending_modifies.clear()

                for cid in pending_mark:
                    self.conn.execute(
                        f"MATCH (c:Commit {{id: '{_cesc(cid)}'}}) "
                        f"SET c.version_tag = '{self._BACKFILL_MARKER}'"
                    )
                pending_mark.clear()

                self.conn.execute("CHECKPOINT")
                shutil.rmtree(staging, ignore_errors=True)

        print(f"Backfilled MODIFIES for {count} commits.")
        return count

    def _meta_path(self) -> str:
        return os.path.join(self.db_dir, "metadata.json")

    def _save_meta(self, key: str, value: str) -> None:
        path = self._meta_path()
        data: dict = {}
        if os.path.exists(path):
            with open(path) as f:
                data = json.load(f)
        data[key] = value
        with open(path, "w") as f:
            json.dump(data, f, indent=2)

    def _load_meta(self, key: str) -> str | None:
        path = self._meta_path()
        if not os.path.exists(path):
            return None
        with open(path) as f:
            data = json.load(f)
        return data.get(key)

    @staticmethod
    def _parse_git_log(
        repo: str, from_ref: str, to_ref: str, skip_merges: bool,
        *, first_parent: bool = True, include_files: bool = False,
    ) -> list[dict]:
        """Parse ``git log`` between two refs into a list of commit dicts.

        *first_parent* (default True) avoids expanding merge branches,
        which is critical for large repos like the Linux kernel where
        ``HEAD~500`` can expand to 10k+ commits without it.

        *include_files* adds ``--name-status`` to get changed files inline,
        avoiding N separate ``git diff-tree`` calls.  Each returned dict
        gains a ``"changed_files"`` key mapping ``{path: status}``.
        On the Linux kernel this is **~100x faster** than per-commit diffs
        (single git invocation vs thousands).
        """
        field_sep = "---CSEP---"
        commit_boundary = "---COMMIT_BOUNDARY---"
        fmt = f"{commit_boundary}%H{field_sep}%an{field_sep}%at{field_sep}%P{field_sep}%B"
        cmd = [
            "git", "-C", repo, "log",
            "--format=" + fmt,
        ]
        if from_ref:
            cmd.append(f"{from_ref}..{to_ref}")
        else:
            cmd.extend(["--root", to_ref])
        if first_parent:
            cmd.insert(4, "--first-parent")
        if include_files:
            cmd.append("--name-status")
        try:
            raw = subprocess.check_output(
                cmd, stderr=subprocess.DEVNULL, timeout=600,
            ).decode("utf-8", errors="replace")
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
            return []

        commits: list[dict] = []
        for block in raw.split(commit_boundary):
            block = block.strip()
            if not block:
                continue
            parts = block.split(field_sep, 4)
            if len(parts) < 5:
                continue
            hash_, author, ts_str, parents = (
                parts[0].strip(), parts[1].strip(),
                parts[2].strip(), parts[3].strip(),
            )
            body = parts[4]
            if not hash_ or len(hash_) < 7:
                continue
            is_merge = " " in parents
            if skip_merges and is_merge:
                continue
            try:
                timestamp = int(ts_str)
            except ValueError:
                timestamp = 0

            changed_files: dict[str, str] = {}
            message = body.strip()
            if include_files:
                lines = body.strip().splitlines()
                msg_lines: list[str] = []
                for line in lines:
                    stripped = line.strip()
                    if stripped and "\t" in stripped and stripped[0] in "AMDRC":
                        tab_parts = stripped.split("\t")
                        status = tab_parts[0][0]
                        if status == "R" and len(tab_parts) >= 3:
                            changed_files[tab_parts[1]] = "D"
                            changed_files[tab_parts[2]] = "A"
                        elif len(tab_parts) >= 2:
                            changed_files[tab_parts[-1]] = status
                    else:
                        msg_lines.append(line)
                message = "\n".join(msg_lines).strip()

            entry: dict = {
                "hash": hash_,
                "author": author,
                "timestamp": timestamp,
                "message": message,
            }
            if include_files:
                entry["changed_files"] = changed_files
            commits.append(entry)
        return commits

    def _ingest_one_commit(
        self,
        ci: dict,
        repo: Path,
        adapters: list[BaseAdapter],
        supported_exts: set[str],
        known_funcs: dict[tuple[str, str], str],
        known_files: set[str],
        *,
        skip_modifies: bool = False,
    ) -> tuple[dict, list[dict], list[dict], list[dict]]:
        """Collect data for one commit without touching the database.

        Returns ``(commit_row, touches, modifies, ghost_funcs)``.
        The caller is responsible for batch-loading these via COPY FROM.
        The commit_row is always returned (even when no known files are
        touched) so the node is created and won't be re-processed.
        """
        h = ci["hash"]
        msg = ci["message"][:200]
        commit_fqn = f"commit:{h[:12]}"
        commit_id = _make_id(commit_fqn)

        commit_row = {
            "id": commit_id, "fqn": commit_fqn, "hash": h,
            "message": msg, "author": ci["author"],
            "timestamp": ci["timestamp"], "version_tag": "",
        }

        changed = ci.get("changed_files") or _git_diff_files(
            str(repo), h + "^", h
        )

        touches: list[dict] = []
        modifies: list[dict] = []
        ghost_funcs: list[dict] = []

        touched_any = False
        for file_path, status in changed.items():
            if not any(file_path.endswith(ext) for ext in supported_exts):
                continue
            if file_path not in known_files:
                continue

            touched_any = True
            file_id = _make_id(file_path)
            touches.append({"from_id": commit_id, "to_id": file_id})

            if skip_modifies:
                continue

            new_funcs = self._get_functions_at_rev(
                repo, h, file_path, adapters
            )
            old_funcs: dict[str, str] = {}
            if status in ("M", "D"):
                old_funcs = self._get_functions_at_rev(
                    repo, h + "^", file_path, adapters
                )

            if status == "A":
                changed_names = set(new_funcs.keys())
            elif status == "D":
                changed_names = set(old_funcs.keys())
            else:
                added = set(new_funcs) - set(old_funcs)
                deleted = set(old_funcs) - set(new_funcs)
                modified = {
                    n for n in set(new_funcs) & set(old_funcs)
                    if new_funcs[n] != old_funcs[n]
                }
                changed_names = added | deleted | modified

            for fname in changed_names:
                func_id, ghost = self._resolve_func_id(
                    fname, file_path, known_funcs)
                if ghost:
                    ghost_funcs.append(ghost)
                modifies.append({"from_id": commit_id, "to_id": func_id})

        return commit_row, touches, modifies, ghost_funcs

    @staticmethod
    def _resolve_func_id(
        func_name: str,
        file_path: str,
        known_funcs: dict[tuple[str, str], str],
    ) -> tuple[str, dict | None]:
        """Resolve a function's node id, creating ghost function data if needed.

        Returns ``(func_id, ghost_row_or_None)``.  Updates *known_funcs*
        in-place so subsequent calls for the same function won't produce
        duplicate ghost rows.
        """
        func_id = known_funcs.get((func_name, file_path))
        if func_id is not None:
            return func_id, None

        ghost_fqn = f"{file_path}:{func_name}:ghost"
        ghost_id = _make_id(ghost_fqn)
        known_funcs[(func_name, file_path)] = ghost_id
        ghost_row = {
            "id": ghost_id, "fqn": ghost_fqn,
            "name": func_name, "qualified_name": "",
            "signature": "", "file_path": file_path,
            "start_line": 0, "end_line": 0,
            "doc_comment": "", "class_name": "",
            "language": "", "is_historical": 1,
        }
        return ghost_id, ghost_row

    _C_KEYWORDS = frozenset({
        "if", "else", "while", "for", "switch", "return", "sizeof",
        "typeof", "defined", "case", "do", "goto", "break", "continue",
        "struct", "enum", "union", "typedef", "static", "extern",
        "inline", "const", "volatile", "register", "unsigned", "signed",
    })

    _HUNK_RE = re.compile(r"^@@.*@@\s*(.*)")
    _FUNC_RE = re.compile(r"(\w+)\s*\(")

    @staticmethod
    def _extract_modified_funcs_from_diff(
        repo: Path, commit_hash: str,
        known_files: set[str],
        supported_exts: set[str],
    ) -> list[tuple[str, str]]:
        """Extract (file_path, func_name) from diff hunk headers.

        Uses ``git diff-tree -p -U0`` which includes the C function
        context in ``@@`` hunk headers.  One subprocess call per commit
        instead of 2*N ``git show`` + tree-sitter calls.
        """
        try:
            raw = subprocess.check_output(
                ["git", "-C", str(repo), "diff-tree",
                 "-r", "-p", "-U0", "--no-commit-id", commit_hash],
                stderr=subprocess.DEVNULL,
                timeout=60,
            ).decode("utf-8", errors="replace")
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
            return []

        results: list[tuple[str, str]] = []
        seen: set[tuple[str, str]] = set()
        current_file: str | None = None
        hunk_re = CodeScope._HUNK_RE
        func_re = CodeScope._FUNC_RE
        c_kw = CodeScope._C_KEYWORDS

        for line in raw.splitlines():
            if line.startswith("diff --git a/"):
                parts = line.split(" b/", 1)
                fpath = parts[1] if len(parts) == 2 else None
                if fpath and fpath in known_files and any(
                    fpath.endswith(ext) for ext in supported_exts
                ):
                    current_file = fpath
                else:
                    current_file = None
            elif current_file and line.startswith("@@"):
                m = hunk_re.match(line)
                if m:
                    context = m.group(1).strip()
                    fm = func_re.search(context)
                    if fm:
                        fname = fm.group(1)
                        if fname not in c_kw:
                            key = (current_file, fname)
                            if key not in seen:
                                seen.add(key)
                                results.append(key)

        return results

    def _get_functions_at_rev(
        self,
        repo: Path,
        rev: str,
        file_path: str,
        adapters: list[BaseAdapter],
    ) -> dict[str, str]:
        """Get function name -> body content hash at a given git revision."""
        cache_key = (rev, file_path)
        if cache_key in self._rev_func_cache:
            return self._rev_func_cache[cache_key]

        try:
            source = subprocess.check_output(
                ["git", "-C", str(repo), "show", f"{rev}:{file_path}"],
                stderr=subprocess.DEVNULL,
                timeout=30,
            )
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired):
            return {}

        adapter = None
        for a in adapters:
            if a.can_handle(file_path):
                adapter = a
                break
        if adapter is None:
            return {}

        try:
            result = adapter.parse_file(source, file_path)
            source_lines = source.decode("utf-8", errors="replace").splitlines()
            funcs: dict[str, str] = {}
            for f in result.functions:
                body = "\n".join(source_lines[f.start_line - 1 : f.end_line])
                funcs[f.name] = hashlib.md5(body.encode()).hexdigest()
            self._rev_func_cache[cache_key] = funcs
            return funcs
        except Exception:
            return {}

    def _export_commit_dataset(self) -> None:
        """Dump all Commit nodes, MODIFIES and TOUCHES edges to dataset CSVs.

        Called after each commit ingestion batch so the dataset stays in sync.
        """
        commit_rows: list[dict] = []
        for row in self.conn.execute(
            "MATCH (c:Commit) RETURN c.id, c.fqn, c.hash, c.message, "
            "c.author, c.timestamp, c.version_tag"
        ):
            commit_rows.append({
                "id": row[0], "fqn": row[1], "hash": row[2],
                "message": row[3], "author": row[4],
                "timestamp": row[5], "version_tag": row[6] or "",
            })
        if commit_rows:
            self._save_node_csv("Commit", commit_rows,
                                ["id", "fqn", "hash", "message", "author",
                                 "timestamp", "version_tag"])

        mod_rows: list[dict] = []
        for row in self.conn.execute(
            "MATCH (c:Commit)-[:MODIFIES]->(f:Function) "
            "RETURN c.id, f.id"
        ):
            mod_rows.append({"from_id": row[0], "to_id": row[1]})
        if mod_rows:
            self._save_rel_csv("MODIFIES", mod_rows)

        touch_rows: list[dict] = []
        for row in self.conn.execute(
            "MATCH (c:Commit)-[:TOUCHES]->(f:File) RETURN c.id, f.id"
        ):
            touch_rows.append({"from_id": row[0], "to_id": row[1]})
        if touch_rows:
            self._save_rel_csv("TOUCHES", touch_rows)

    # -- Evolution query methods ---------------------------------------------

    def change_attribution(
        self,
        function_name: str,
        file_path: str | None = None,
        limit: int = 20,
    ) -> list[ChangeAttributionResult]:
        """Return commits that modified a function, ordered by recency."""
        if file_path:
            query = (
                f"MATCH (c:Commit)-[:MODIFIES]->(f:Function) "
                f"WHERE f.name = '{_cesc(function_name)}' "
                f"AND f.file_path = '{_cesc(file_path)}' "
                f"RETURN c.hash, c.message, c.author, c.timestamp "
                f"ORDER BY c.timestamp DESC LIMIT {limit}"
            )
        else:
            query = (
                f"MATCH (c:Commit)-[:MODIFIES]->(f:Function) "
                f"WHERE f.name = '{_cesc(function_name)}' "
                f"RETURN c.hash, c.message, c.author, c.timestamp "
                f"ORDER BY c.timestamp DESC LIMIT {limit}"
            )

        results = []
        for row in self.conn.execute(query):
            results.append(ChangeAttributionResult(
                commit_hash=row[0],
                message=row[1],
                author=row[2],
                timestamp=row[3],
                change_type="modify",
            ))
        return results

    def co_change(
        self,
        function_name: str,
        file_path: str | None = None,
        min_commits: int = 2,
        topk: int = 10,
    ) -> list[CoChangeResult]:
        """Find functions frequently co-modified with the target."""
        if file_path:
            func_match = (
                f"f.name = '{_cesc(function_name)}' "
                f"AND f.file_path = '{_cesc(file_path)}'"
            )
        else:
            func_match = f"f.name = '{_cesc(function_name)}'"

        commit_rows = list(self.conn.execute(
            f"MATCH (c:Commit)-[:MODIFIES]->(f:Function) "
            f"WHERE {func_match} RETURN c.id, c.hash"
        ))
        if not commit_rows:
            return []

        commit_ids = [r[0] for r in commit_rows]
        commit_hashes = {r[0]: r[1] for r in commit_rows}

        called_ids: set[str] = set()
        for row in self.conn.execute(
            f"MATCH (f:Function)-[:CALLS]->(t:Function) "
            f"WHERE {func_match} RETURN t.id"
        ):
            called_ids.add(row[0])
        for row in self.conn.execute(
            f"MATCH (t:Function)-[:CALLS]->(f:Function) "
            f"WHERE {func_match} RETURN t.id"
        ):
            called_ids.add(row[0])

        co_counts: dict[str, list[str]] = {}
        for cid in commit_ids:
            for row in self.conn.execute(
                f"MATCH (c:Commit {{id: '{_cesc(cid)}'}})"
                f"-[:MODIFIES]->(f2:Function) "
                f"WHERE NOT ({func_match.replace('f.', 'f2.')}) "
                f"RETURN f2.name, f2.file_path"
            ):
                key = f"{row[0]}@{row[1]}"
                co_counts.setdefault(key, []).append(commit_hashes[cid])

        results = []
        for key, commits in co_counts.items():
            if len(commits) < min_commits:
                continue
            fname, fpath = key.split("@", 1)

            func_id_for_check = None
            for row in self.conn.execute(
                f"MATCH (f:Function) WHERE f.name = '{_cesc(fname)}' "
                f"AND f.file_path = '{_cesc(fpath)}' RETURN f.id"
            ):
                func_id_for_check = row[0]
            if func_id_for_check and func_id_for_check in called_ids:
                continue

            results.append(CoChangeResult(
                function_name=fname,
                file_path=fpath,
                co_change_count=len(commits),
                shared_commits=commits,
            ))

        results.sort(key=lambda x: -x.co_change_count)
        return results[:topk]

    def intent_search(
        self,
        query: str,
        topk: int = 10,
    ) -> list[IntentSearchResult]:
        """Find commits relevant to a natural-language intent query.

        Strategy: use function vector search to find semantically related
        functions, then reverse-traverse MODIFIES edges to discover commits
        that changed those functions.  Commit messages are ranked by textual
        relevance to the query using simple keyword overlap scoring.
        """
        query_vec = self.model.encode(
            query, normalize_embeddings=True
        ).tolist()

        hits = self.collection.query(
            zvec.VectorQuery("code_emb", vector=query_vec),
            topk=topk * 3,
        )

        func_ids = [hit.id for hit in hits]
        if not func_ids:
            return []

        seen_hashes: set[str] = set()
        candidates: list[IntentSearchResult] = []

        query_lower = query.lower()
        query_words = set(query_lower.split())

        for fid in func_ids:
            rows = list(self.conn.execute(
                f"MATCH (c:Commit)-[:MODIFIES]->(f:Function {{id: '{_cesc(fid)}'}}) "
                f"RETURN c.hash, c.message, f.name, f.file_path "
                f"ORDER BY c.timestamp DESC LIMIT 20"
            ))
            for chash, cmsg, fname, fpath in rows:
                if chash in seen_hashes:
                    continue
                seen_hashes.add(chash)

                msg_lower = (cmsg or "").lower()
                msg_words = set(msg_lower.split())
                overlap = len(query_words & msg_words)
                score = overlap / max(len(query_words), 1)

                func_rows = list(self.conn.execute(
                    f"MATCH (c:Commit {{hash: '{_cesc(chash)}'}})"
                    f"-[:MODIFIES]->(f:Function) "
                    f"RETURN f.name, f.file_path"
                ))
                funcs = [f"{r[0]} ({r[1]})" for r in func_rows]

                candidates.append(IntentSearchResult(
                    commit_hash=chash,
                    message=cmsg,
                    similarity_score=score,
                    functions_modified=funcs,
                ))

        candidates.sort(key=lambda x: -x.similarity_score)
        return candidates[:topk]

    # ========================================================================
    # Architecture Intelligence Analyses
    # ========================================================================

    def stability_analysis(self, topk: int = 50) -> StabilityAnalysis:
        """Correlate fan-in (callers) with modification frequency.

        In well-designed software the most-depended-upon functions are
        the least frequently modified (Stable Dependencies Principle).
        Returns the top-*topk* most-called functions with their
        modification counts.
        """
        rows = list(self.conn.execute(
            "MATCH (caller:Function)-[:CALLS]->(f:Function) "
            "WHERE f.is_historical = 0 "
            "RETURN f.id, f.name, f.file_path, count(caller) AS fan_in "
            "ORDER BY fan_in DESC LIMIT " + str(topk)
        ))

        entries: list[StabilityEntry] = []
        modified = 0
        for fid, name, fpath, fan_in in rows:
            mod_rows = list(self.conn.execute(
                f"MATCH (c:Commit)-[:MODIFIES]->(f:Function {{id: '{_cesc(fid)}'}}) "
                f"RETURN count(c)"
            ))
            mod_count = mod_rows[0][0] if mod_rows else 0
            if mod_count > 0:
                modified += 1
            entries.append(StabilityEntry(
                name=name, file_path=fpath or "",
                fan_in=fan_in, modify_count=mod_count,
            ))

        return StabilityAnalysis(
            top_functions=entries,
            total_checked=len(entries),
            modified_count=modified,
            unmodified_count=len(entries) - modified,
        )

    def layer_discovery(self, topk: int = 30) -> list[LayerEntry]:
        """Discover the natural architectural layering of modules.

        Computes an infrastructure score for each module:
        ``incoming_cross_module_calls - outgoing_cross_module_calls``.
        High-score modules are foundational infrastructure; low-score
        modules are leaf consumers.
        """
        incoming: dict[str, int] = {}
        for row in self.conn.execute(
            "MATCH (f1:Function)-[:CALLS]->(f2:Function), "
            "      (file1:File)-[:DEFINES_FUNC]->(f1), "
            "      (file2:File)-[:DEFINES_FUNC]->(f2), "
            "      (file1)-[:BELONGS_TO]->(m1:Module), "
            "      (file2)-[:BELONGS_TO]->(m2:Module) "
            "WHERE m1.id <> m2.id "
            "RETURN m2.path_prefix, count(*) AS cnt "
            "ORDER BY cnt DESC LIMIT 200"
        ):
            incoming[row[0]] = row[1]

        outgoing: dict[str, int] = {}
        for row in self.conn.execute(
            "MATCH (f1:Function)-[:CALLS]->(f2:Function), "
            "      (file1:File)-[:DEFINES_FUNC]->(f1), "
            "      (file2:File)-[:DEFINES_FUNC]->(f2), "
            "      (file1)-[:BELONGS_TO]->(m1:Module), "
            "      (file2)-[:BELONGS_TO]->(m2:Module) "
            "WHERE m1.id <> m2.id "
            "RETURN m1.path_prefix, count(*) AS cnt "
            "ORDER BY cnt DESC LIMIT 200"
        ):
            outgoing[row[0]] = row[1]

        all_mods = set(incoming) | set(outgoing)
        entries = [
            LayerEntry(
                module=m,
                incoming=incoming.get(m, 0),
                outgoing=outgoing.get(m, 0),
                layer_score=float(incoming.get(m, 0) - outgoing.get(m, 0)),
            )
            for m in all_mods
        ]
        entries.sort(key=lambda e: -e.layer_score)
        return entries[:topk]

    def bridge_functions(self, topk: int = 30) -> list[BridgeFunction]:
        """Find functions called from the most distinct modules.

        These are the kernel's true cross-subsystem API -- the
        load-bearing walls of the architecture.
        """
        rows = list(self.conn.execute(
            "MATCH (caller:Function)-[:CALLS]->(f:Function), "
            "      (cf:File)-[:DEFINES_FUNC]->(caller), "
            "      (cf)-[:BELONGS_TO]->(m:Module) "
            "WHERE f.is_historical = 0 "
            "RETURN f.name, f.file_path, "
            "       count(DISTINCT m.id) AS module_count, "
            "       count(caller) AS total_callers "
            "ORDER BY module_count DESC LIMIT " + str(topk)
        ))
        return [
            BridgeFunction(
                name=r[0], file_path=r[1] or "",
                module_count=r[2], total_callers=r[3],
            )
            for r in rows
        ]

    def commit_modularity(self, topk: int = 20) -> list[CommitModularity]:
        """Score each commit's modularity: how many modules were affected.

        Focused commits (1 module) signal good encapsulation.
        Scattered commits (many modules) reveal cross-cutting changes.
        """
        rows = list(self.conn.execute(
            "MATCH (c:Commit)-[:MODIFIES]->(f:Function), "
            "      (file:File)-[:DEFINES_FUNC]->(f), "
            "      (file)-[:BELONGS_TO]->(m:Module) "
            "RETURN c.hash, c.message, "
            "       count(DISTINCT f.id) AS funcs, "
            "       count(DISTINCT m.id) AS mods "
            "ORDER BY mods DESC, funcs DESC LIMIT " + str(topk)
        ))
        return [
            CommitModularity(
                commit_hash=r[0], message=r[1] or "",
                funcs_modified=r[2], modules_touched=r[3],
            )
            for r in rows
        ]

    def hot_cold_map(self, topk: int = 30) -> list[HotColdEntry]:
        """Compute modification density per module.

        Low density in core modules = frozen/stable core.
        High density in peripheral modules = active development.
        """
        mod_funcs: dict[str, int] = {}
        for row in self.conn.execute(
            "MATCH (file:File)-[:DEFINES_FUNC]->(f:Function), "
            "      (file)-[:BELONGS_TO]->(m:Module) "
            "WHERE f.is_historical = 0 "
            "RETURN m.path_prefix, count(f) AS cnt"
        ):
            mod_funcs[row[0]] = row[1]

        mod_modified: dict[str, int] = {}
        for row in self.conn.execute(
            "MATCH (c:Commit)-[:MODIFIES]->(f:Function), "
            "      (file:File)-[:DEFINES_FUNC]->(f), "
            "      (file)-[:BELONGS_TO]->(m:Module) "
            "WHERE f.is_historical = 0 "
            "RETURN m.path_prefix, count(DISTINCT f.id) AS cnt"
        ):
            mod_modified[row[0]] = row[1]

        entries = []
        for mod, total in mod_funcs.items():
            if total < 5:
                continue
            modified = mod_modified.get(mod, 0)
            entries.append(HotColdEntry(
                module=mod, total_functions=total,
                modified_functions=modified,
                density=modified / total if total > 0 else 0.0,
            ))

        entries.sort(key=lambda e: -e.density)
        return entries[:topk]

    def semantic_cross_pollination(
        self, query: str, topk: int = 15,
    ) -> list[SemanticCrossPollinationHit]:
        """Find semantically similar functions across distant subsystems.

        Uses vector search for semantic seeds, then graph traversal to
        check structural connectivity.  Functions that are semantically
        close but structurally distant reveal shared design patterns.
        """
        query_vec = self.model.encode(
            query, normalize_embeddings=True
        ).tolist()

        hits = self.collection.query(
            zvec.VectorQuery("code_emb", vector=query_vec),
            topk=topk * 3,
        )

        results: list[SemanticCrossPollinationHit] = []
        seen_modules: dict[str, float] = {}

        for h in hits:
            rows = list(self.conn.execute(
                f"MATCH (f:Function {{id: '{_cesc(h.id)}'}})"
                f"<-[:DEFINES_FUNC]-(file:File)"
                f"-[:BELONGS_TO]->(m:Module) "
                f"RETURN f.name, f.file_path, m.path_prefix"
            ))
            if not rows:
                continue
            name, fpath, mod = rows[0]
            if mod in seen_modules:
                continue
            seen_modules[mod] = h.score
            results.append(SemanticCrossPollinationHit(
                name=name, file_path=fpath or "", module=mod,
                score=h.score, connected=False, connection_distance=-1,
            ))
            if len(results) >= topk:
                break

        if len(results) >= 2:
            anchor = results[0]
            for r in results[1:]:
                info = self._shortest_between(
                    _make_id(f"{anchor.file_path}:{anchor.name}"),
                    _make_id(f"{r.file_path}:{r.name}"),
                    max_hops=4,
                )
                if info is None:
                    info = self._shortest_between(
                        _make_id(f"{r.file_path}:{r.name}"),
                        _make_id(f"{anchor.file_path}:{anchor.name}"),
                        max_hops=4,
                    )
                if info is not None:
                    r.connected = True
                    r.connection_distance = info[0]

        return results

    def summary(self) -> str:
        """Generate a detailed post-index summary report."""
        stats = self._get_stats()
        lines = [
            "=" * 60,
            "CodeScope Index Summary",
            "=" * 60,
            f"  Files:      {stats['files']}  (+ {stats['ext_files']} external)",
            f"  Functions:  {stats['functions']}  (+ {stats['ghost_functions']} historical)",
            f"  Call edges: {stats['edges']}",
            f"  Vectors:    {stats['vectors']}",
        ]

        try:
            import_count = list(self.conn.execute(
                "MATCH ()-[e:IMPORTS]->() RETURN count(e)"))[0][0]
            lines.append(f"  Imports:    {import_count}")
        except Exception:
            pass

        try:
            class_count = list(self.conn.execute(
                "MATCH (c:Class) RETURN count(c)"))[0][0]
            lines.append(f"  Classes:    {class_count}")
        except Exception:
            pass

        try:
            mod_count = list(self.conn.execute(
                "MATCH (m:Module) RETURN count(m)"))[0][0]
            lines.append(f"  Modules:    {mod_count}")
        except Exception:
            pass

        try:
            rows = list(self.conn.execute(
                "MATCH (f:File)-[:BELONGS_TO]->(m:Module) "
                "RETURN m.path_prefix, count(f) AS cnt "
                "ORDER BY cnt DESC LIMIT 5"
            ))
            if rows:
                lines.append("")
                lines.append("  Largest subsystems:")
                for path_prefix, cnt in rows:
                    lines.append(f"    {path_prefix}: {cnt} files")
        except Exception:
            pass

        try:
            rows = list(self.conn.execute(
                "MATCH (caller:Function)-[:CALLS]->(f:Function) "
                "RETURN f.name, f.file_path, count(caller) AS fan_in "
                "ORDER BY fan_in DESC LIMIT 5"
            ))
            if rows:
                lines.append("")
                lines.append("  Most-called functions:")
                for name, fpath, fan_in in rows:
                    lines.append(f"    {name} ({fpath}): {fan_in} callers")
        except Exception:
            pass

        try:
            rows = list(self.conn.execute(
                "MATCH (f:Function)-[:CALLS]->(callee:Function) "
                "RETURN f.name, f.file_path, count(callee) AS fan_out "
                "ORDER BY fan_out DESC LIMIT 5"
            ))
            if rows:
                lines.append("")
                lines.append("  Highest fan-out functions:")
                for name, fpath, fan_out in rows:
                    lines.append(f"    {name} ({fpath}): calls {fan_out} functions")
        except Exception:
            pass

        lines.append("=" * 60)
        return "\n".join(lines)

    # ========================================================================
    # Bug Analysis
    # ========================================================================

    def analyze_issue(
        self,
        owner: str,
        repo: str,
        number: int,
        use_cache: bool = True,
        topk: int = 10,
    ):
        """Analyze a GitHub issue to find potential root cause code locations.

        Args:
            owner: GitHub repo owner
            repo: GitHub repo name
            number: Issue number
            use_cache: Use cached issue data if available
            topk: Number of root cause candidates to return

        Returns:
            BugAnalysisResult with ranked candidates.
        """
        from codegraph.issue_fetcher import fetch_and_parse_issue
        from codegraph.bug_locator import analyze_bug

        issue = fetch_and_parse_issue(owner, repo, number, use_cache=use_cache)
        return analyze_bug(self, issue, topk=topk)

    def analyze_top_bugs(
        self,
        owner: str,
        repo: str,
        k: int = 10,
        label: str = "bug",
        use_cache: bool = True,
        topk_per_issue: int = 5,
    ):
        """Analyze top-k bug issues and return aggregated results.

        Returns a list of BugAnalysisResult, one per issue.
        """
        from codegraph.issue_fetcher import fetch_and_parse_top_bugs
        from codegraph.bug_locator import analyze_bug

        issues = fetch_and_parse_top_bugs(owner, repo, k=k, label=label, use_cache=use_cache)
        results = []
        for issue in issues:
            result = analyze_bug(self, issue, topk=topk_per_issue)
            results.append(result)
        return results

    def close(self) -> None:
        """Release neug and zvec resources."""
        try:
            self.collection.close()
        except Exception:
            pass
        self.collection = None
        self.conn.close()
        self.db.close()
        self.conn = None
        self.db = None
