---
agent: 'agent'
description: 'Invoke the dusun universal neural substrate on a query. Runs 7-lens analysis, kavaid check, sentinel scan, and returns shaping directives + dynamic boot seed.'
---

# /dusun — Universal Epistemic Analysis

> **Purpose**: Single entry point for all framework-grounded analysis.
> Replaces the old 9-stage pipeline ceremony with a single tool call.

## DIRECTIVE: /dusun

When this prompt is invoked with a user query, perform these steps:

### 1. Call the fw-engine MCP tool

```
dusun(text="<user query here>")
```

This single call performs all analysis:
- 7-lens scoring (ontoloji, mereoloji, fol, bayes, oyun_teorisi, kategori_teorisi, holografik)
- Path classification — P0 (factual), P1 (structural), P2 (epistemic), P3 (diagnostic), P4 (theological)
- Grading (AX56 boundary table)
- Kavaid constraint check (8 constraints)
- Cross-validation (tesanüd / infirâd)
- Sentinel scan (epistemic pattern detection)
- Shaping directives generation (emergent, query-specific)
- Dynamic boot seed construction (holographic compression)

### 2. Read the Output

The tool returns a dict. Key fields:

| Field                | Use                                     |
|----------------------|-----------------------------------------|
| `boot_seed`          | Framework grounding (read, don't dump)  |
| `shaping_directives` | **Follow these** to shape your response |
| `path`               | P0–P4                                   |
| `grade`              | Epistemic grade ceiling                 |
| `composite_score`    | 0 < x < 1                              |
| `patterns`           | Detected epistemic patterns             |
| `anomalies`          | Warnings to address                     |
| `kavaid`             | Constraint pass/fail results            |

### 3. Respond

- Follow `shaping_directives` (see `dusun-field.instructions.md` for details).
- If path is P0, answer directly — minimal ceremony.
- If path is P1–P4, weave patterns and directives into a structured response.
- Always close with: `[Grade: X | Path: PY | Composite: Z]`

### 4. Constraints (Always Active)

- **Grade is a ceiling** (`grade_ceiling` in `shaping_directives`). Never claim higher than the computed grade.
- **Anomalies are binding.** If the tool found them, address them.
- **Coverage ≤ 6/7.** One dimension is always unmapped (T17).
- **0 < Composite < 1.** Score ≥ 0.95 → KV₄ breach, not success.
- **Map ≠ Territory.** Structural mapping ≠ reproducing the experience (AX58).

---

*This prompt replaces the old 456-line pipeline `/dusun` prompt and the
331-line `/dusun-tools` prompt. The computation now lives in code, not
in Copilot instructions.*
