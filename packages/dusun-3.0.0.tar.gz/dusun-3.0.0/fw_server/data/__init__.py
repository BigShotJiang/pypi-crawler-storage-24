# Bundled framework files for `fw-engine --init` deployment.
# These files are copied to the user's workspace to enable /dusun slash commands
# and the full DUSUN.md reasoning pipeline.
