"""
fw_doctor — Self-diagnostic and verification module for the dusun framework.

Usage:
    fw-engine doctor [-v|--verbose] [--no-color]
    python -m fw_doctor [-v|--verbose] [--no-color]

Structural rationale:
    AX5  — Integration Prerequisite: verifies all modules come alive as a whole.
    AX34 — The gap between "installed" and "verified working" is a functional
           interface — fw_doctor fills it.
    AX52 — Multiplicative gate: if ANY module is broken, the gate collapses.
    AX57 — Transparency: every check reports exactly what it tested.
"""

from .checks import (
    ALL_CHECKS,
    CheckResult,
    CheckStatus,
    check_bileshke,
    check_framework_summaries,
    check_hcp,
    check_imports,
    check_kaskad,
    check_kavaid,
    check_lenses,
    check_memory_bank,
    check_persistence,
    check_version,
)
from .runner import exit_code, run_all

__all__ = [
    # Runner
    "run_all",
    "exit_code",
    # Types
    "CheckResult",
    "CheckStatus",
    # Check registry
    "ALL_CHECKS",
    # Individual checks
    "check_imports",
    "check_version",
    "check_lenses",
    "check_bileshke",
    "check_kavaid",
    "check_kaskad",
    "check_hcp",
    "check_framework_summaries",
    "check_persistence",
    "check_memory_bank",
]
