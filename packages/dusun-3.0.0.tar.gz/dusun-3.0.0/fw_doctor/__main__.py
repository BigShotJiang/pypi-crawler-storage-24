"""
fw_doctor.__main__ — Entry point for `python -m fw_doctor`.

Parses --verbose / --no-color flags and runs all checks.
"""

from __future__ import annotations

import argparse
import sys

from .runner import exit_code, run_all


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="fw_doctor",
        description="Self-diagnostic for the dusun framework installation.",
    )
    parser.add_argument(
        "-v", "--verbose",
        action="store_true",
        help="Show detailed output for each check.",
    )
    parser.add_argument(
        "--no-color",
        action="store_true",
        help="Disable ANSI color output.",
    )

    args = parser.parse_args()
    results = run_all(verbose=args.verbose, no_color=args.no_color)
    sys.exit(exit_code(results))


if __name__ == "__main__":
    main()
