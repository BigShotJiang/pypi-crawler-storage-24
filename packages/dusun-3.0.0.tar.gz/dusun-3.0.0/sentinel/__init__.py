"""sentinel — Epistemic Sentinel package.

Fills the structural zero in the framework's self-diagnosis dimension (AX52).
Detects, records, and generalises AI failure modes using a 3-arm engine:

  Reactive Arm   — user complaint detection (regex)
  Proactive Arm  — self-diagnosis heuristics (H1-H6)
  Structural Arm — cross-context pattern matching

Public API::

    from sentinel import get_sentinel, SentinelEngine
    sentinel = get_sentinel()
    signal = sentinel.scan(user_msg, ai_response, session_ledger, turn)
"""

from sentinel.engine import SentinelEngine, get_sentinel, reset_sentinel
from sentinel.types import (
    ConfidenceBasis,
    CoSuggestion,
    DetectionArm,
    Incident,
    PatternRule,
    SentinelSignal,
    SentinelState,
    Severity,
)

__all__ = [
    "SentinelEngine",
    "get_sentinel",
    "reset_sentinel",
    "ConfidenceBasis",
    "CoSuggestion",
    "DetectionArm",
    "Incident",
    "PatternRule",
    "SentinelSignal",
    "SentinelState",
    "Severity",
]
