"""
babilong_eval — BABILong Benchmark Evaluation for the Holographic Context Protocol.

Evaluates HCP's core claim: structural seed computation can identify
which parts of a massively long context are relevant to a query,
enabling an LLM to answer correctly even when facts are buried in
hundreds of thousands of tokens of filler text.

BABILong (NeurIPS 2024):
  - Dataset: bAbI QA tasks (short reasoning facts) injected into
    PG-19 book filler at various positions
  - Tasks: QA1 (single fact) through QA5 (three-argument)
  - Lengths: 0k to 10M tokens
  - Metric: label-matching accuracy (not exact match)
  - Leaderboard: PR-based submission to booydar/babilong

Evaluation Strategy (Option 3 — Filtering):
  Three experimental conditions, same LLM, same prompt template:
    1. full_context (baseline): raw BABILong input → LLM
    2. hcp_filtered: HCP ranks chunks → top retain_ratio sent to LLM
    3. random_filtered (control): random chunks at same retain_ratio

  This isolates HCP's information-theoretic contribution:
  if hcp_filtered > random_filtered, HCP genuinely identifies relevant content.
  if hcp_filtered > full_context, HCP beats the LLM's own attention.

Modules:
  prompts    — Exact BABILong prompt templates for QA1–QA5
  metrics    — Exact BABILong scoring (TASK_LABELS, compare_answers)
  preprocessor — HCP-based context filtering + anomaly scoring
  harness    — Evaluation runner with LLM API integration
  report     — Results aggregation, printing, and JSON export
"""

from babilong_eval.prompts import get_prompt_template, format_prompt
from babilong_eval.metrics import compare_answers, preprocess_output, TASK_LABELS
from babilong_eval.preprocessor import full_context, hcp_filtered, random_filtered, bm25_filtered, embedding_filtered
from babilong_eval.harness import BabilongConfig, run_full_eval, run_task_length
from babilong_eval.report import BabilongResult, print_report, save_results

__all__ = [
    "get_prompt_template",
    "format_prompt",
    "compare_answers",
    "preprocess_output",
    "TASK_LABELS",
    "full_context",
    "hcp_filtered",
    "random_filtered",
    "bm25_filtered",
    "embedding_filtered",
    "BabilongConfig",
    "run_full_eval",
    "run_task_length",
    "BabilongResult",
    "print_report",
    "save_results",
]
