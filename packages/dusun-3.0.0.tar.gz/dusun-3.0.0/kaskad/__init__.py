"""
kaskad — Generative Cascade Engine (AX23).

Models the cascade structure where Names form a DAG and each motivates
the next via internal necessity.  Also encodes the framework's own
Inference Graph (§IG) as a computable, self-referential structure.

Key features:
  - CascadeDAG:  typed DAG with 6 edge morphisms (§IG.1)
  - T8 Neighborliness: predict detectable nodes from observed ones
  - AX63 Tesanüd: super-additive convergence across independent chains
  - §IG.3 Hub/bridge analysis: cross-chain connection points
  - Self-diagnostic: the engine validates its OWN structural integrity
  - Verification layer: verify_all on any CascadeDAG

Governing axioms:
  AX23:  kaskad: S_Isim × S_Isim → Bool (transitive DAG)
  T7:    Creation Motor — Beauty desires mirrors
  T8:    Cascade Neighborliness — detection predicts neighbors
  AX63:  Tesanüd–İnfirâd asymmetry
  KV₄:   0 < Composite < 1
  KV₇:   Independence (no shared state between chains)
  AX57:  Transparency — mandatory disclosure
"""

# --- types ---
from kaskad.types import (
    EdgeType,
    NodeKind,
    ChainId,
    CascadeNode,
    CascadeEdge,
    DynamicEdge,
    NeighborhoodPrediction,
    HubAnalysis,
    ChainIntegrity,
    TesanudResult,
    CascadeReport,
)

# --- engine ---
from kaskad.engine import (
    CascadeDAG,
    MAX_STRUCTURAL_COMPLETENESS,
    T8_BASE_CONFIDENCE,
    T8_HOP_DECAY,
    MIN_TESANUD_CHAINS,
    MIN_EDGE_ACTIVATION,
    activate_edges,
    predict_neighbors_dynamic,
)

# --- chain factories ---
from kaskad.chains import (
    build_framework_graph,
    build_beauty_cascade,
)

# --- verification ---
from kaskad.verification import (
    VerificationResult,
    verify_acyclicity,
    verify_transitivity_sample,
    verify_convergence_bound,
    verify_chain_coverage,
    verify_chain_integrity,
    verify_bridge_nodes,
    verify_sources_and_sinks,
    verify_all,
    is_fully_verified,
    framework_summary,
)

__all__ = [
    # types
    "EdgeType",
    "NodeKind",
    "ChainId",
    "CascadeNode",
    "CascadeEdge",
    "DynamicEdge",
    "NeighborhoodPrediction",
    "HubAnalysis",
    "ChainIntegrity",
    "TesanudResult",
    "CascadeReport",
    # engine
    "CascadeDAG",
    "MAX_STRUCTURAL_COMPLETENESS",
    "T8_BASE_CONFIDENCE",
    "T8_HOP_DECAY",
    "MIN_TESANUD_CHAINS",
    "MIN_EDGE_ACTIVATION",
    "activate_edges",
    "predict_neighbors_dynamic",
    # factories
    "build_framework_graph",
    "build_beauty_cascade",
    # verification
    "VerificationResult",
    "verify_acyclicity",
    "verify_transitivity_sample",
    "verify_convergence_bound",
    "verify_chain_coverage",
    "verify_chain_integrity",
    "verify_bridge_nodes",
    "verify_sources_and_sinks",
    "verify_all",
    "is_fully_verified",
    "framework_summary",
]
