"""Phase 5 — Boot seed Hayat Bridge verification.

Ensures the ``_BOOT_SEED`` in ``dusun.py`` references all four Hayat
Bridge enforcement channels so the LLM has channel awareness from the
very first ``dusun()`` call.
"""

from __future__ import annotations

import pytest

# ── Import the boot seed ────────────────────────────────────────────

from fw_server.dusun import _BOOT_SEED


# ── Helper ──────────────────────────────────────────────────────────

def _seed() -> str:
    """Return the boot seed text, lowered for case-insensitive checks."""
    return _BOOT_SEED.lower()


# ════════════════════════════════════════════════════════════════════
# 1. Hayat Bridge section presence
# ════════════════════════════════════════════════════════════════════

class TestHayatBridgePresence:
    """The boot seed MUST contain a Hayat Bridge section."""

    def test_hayat_bridge_heading_exists(self) -> None:
        assert "hayat bridge" in _seed()

    def test_four_channel_mentioned(self) -> None:
        assert "four-channel" in _seed() or "four channel" in _seed()

    def test_ax5_referenced(self) -> None:
        # AX5 is the integration prerequisite that motivates the bridge
        assert "ax5" in _seed()


# ════════════════════════════════════════════════════════════════════
# 2. Channel 1 — Tool Description Enrichment
# ════════════════════════════════════════════════════════════════════

class TestChannel1Seed:
    """Channel 1 references present."""

    def test_channel_1_present(self) -> None:
        assert "channel 1" in _seed()

    def test_tool_description_mentioned(self) -> None:
        assert "tool description" in _seed()

    def test_enforcement_language_referenced(self) -> None:
        assert "enforcement" in _seed()

    def test_must_never_binding(self) -> None:
        # Boot seed should tell LLM that MUST/NEVER are binding
        assert "binding" in _seed()

    def test_ax27_referenced(self) -> None:
        assert "ax27" in _seed()


# ════════════════════════════════════════════════════════════════════
# 3. Channel 2 — Enriched Tool Returns
# ════════════════════════════════════════════════════════════════════

class TestChannel2Seed:
    """Channel 2 references present."""

    def test_channel_2_present(self) -> None:
        assert "channel 2" in _seed()

    def test_framework_context_mentioned(self) -> None:
        assert "_framework_context" in _seed()

    def test_grade_ceiling_in_return(self) -> None:
        assert "grade_ceiling" in _seed()

    def test_gate_enforcement_in_return(self) -> None:
        assert "gate_enforcement" in _seed()

    def test_cascade_forward_in_return(self) -> None:
        assert "cascade" in _seed()

    def test_never_override_upward(self) -> None:
        assert "never override" in _seed()

    def test_ax37_referenced(self) -> None:
        assert "ax37" in _seed()


# ════════════════════════════════════════════════════════════════════
# 4. Channel 3 — Session State Tracking
# ════════════════════════════════════════════════════════════════════

class TestChannel3Seed:
    """Channel 3 references present."""

    def test_channel_3_present(self) -> None:
        assert "channel 3" in _seed()

    def test_session_tracking_mentioned(self) -> None:
        assert "session" in _seed()

    def test_grade_ceiling_enforcement(self) -> None:
        # Session tracks grade ceiling
        assert "grade ceiling" in _seed()

    def test_multiplicative_gate_mentioned(self) -> None:
        assert "multiplicative gate" in _seed()

    def test_grade_inflation_violation(self) -> None:
        assert "grade inflation" in _seed()

    def test_ax52_referenced(self) -> None:
        assert "ax52" in _seed()


# ════════════════════════════════════════════════════════════════════
# 5. Channel 4 — Cascade Feedback
# ════════════════════════════════════════════════════════════════════

class TestChannel4Seed:
    """Channel 4 references present."""

    def test_channel_4_present(self) -> None:
        assert "channel 4" in _seed()

    def test_cascade_feedback_mentioned(self) -> None:
        assert "cascade feedback" in _seed()

    def test_anomaly_forwarding(self) -> None:
        assert "anomalies" in _seed() and "forward" in _seed()

    def test_degraded_threshold(self) -> None:
        # ≥ 3 anomalies → DEGRADED
        assert "degraded" in _seed()

    def test_critical_threshold(self) -> None:
        assert "critical" in _seed()

    def test_ax23_referenced(self) -> None:
        assert "ax23" in _seed()

    def test_enforcement_directives_in_cascade(self) -> None:
        assert "enforcement language" in _seed()


# ════════════════════════════════════════════════════════════════════
# 6. Pre-existing sections still present (non-regression)
# ════════════════════════════════════════════════════════════════════

class TestPreExistingSections:
    """Boot seed still contains all original sections."""

    def test_kavaid_section(self) -> None:
        assert "kavaid" in _seed()

    def test_structural_patterns_section(self) -> None:
        assert "structural patterns" in _seed()

    def test_structural_bounds_section(self) -> None:
        assert "structural bounds" in _seed()

    def test_paths_section(self) -> None:
        assert "paths" in _seed()

    def test_epistemic_grades_section(self) -> None:
        assert "epistemic grades" in _seed()

    def test_output_rules_section(self) -> None:
        assert "output rules" in _seed()

    def test_kv4_present(self) -> None:
        assert "kv₄" in _seed() or "kv4" in _seed()

    def test_t12_reference(self) -> None:
        assert "t12" in _seed()
