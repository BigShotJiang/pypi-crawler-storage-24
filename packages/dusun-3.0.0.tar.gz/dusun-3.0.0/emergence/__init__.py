"""
emergence — Top-Down Emergence Engine.

Encodes emergence as top-down holographic condensation through
constitutive-poverty interfaces, driven by Beauty's self-reflection,
expressed as a 6-level cascade DAG, bounded by 0 < Fidelity < 1.

This is NOT bottom-up emergence (spontaneous order from parts).
It is provision-flow emergence: the whole actively provisions each
level through transparent (harfî) poverty interfaces, so that each
level condenses the whole's structure at a bounded fidelity.

Key features:
  - EmergenceDAG:  fixed 6-level typed DAG
  - Provision flow: top-down through poverty interfaces (AX2–AX4)
  - Holographic fidelity: each level condenses the whole (T12/AX37)
  - Beauty motor: creation driven by Beauty's desire for mirrors (T7)
  - Multiplicative gate: zero in any dimension → collapse (AX52)
  - Verification layer: 9 structural checks + yakinlasma composite
  - Framework summary: AX57 transparency disclosure

Governing axioms:
  AX2–AX4:  Three-phase actualization (İlim → İrade → Kudret)
  AX5:      Integration prerequisite (Hayat)
  AX17:     Hakikat = Name composition
  AX21–22:  Continuous degrees, unreachable supremum
  AX23–25:  Cascade structure, Beauty motor
  AX34:     Structural gaps as functional interfaces
  AX37:     Holographic isomorphism
  AX52:     Multiplicative gate
  T6:       Unreachable supremum
  T7:       Beauty → mirrors (creation motor)
  T12:      Holographic condensation
  KV₁:      Harfî classification
  KV₂:      Privation ontology
  KV₄:      0 < Composite < 1
  KV₆:      Seed omnipresence
  KV₇:      Independence
"""

# --- types ---
from emergence.emergence import (
    EmergenceLevel,
    FlowDirection,
    InterfaceKind,
    VesselMode,
    PovertyInterface,
    EmergenceNode,
    EmergenceEdge,
    BeautyMotor,
    FidelityPair,
    EmergenceReport,
    clamp_score,
)

# --- engine ---
from emergence.emergence import (
    EmergenceDAG,
    MAX_STRUCTURAL_COMPLETENESS,
    MIN_HOLOGRAPHIC_SEED,
    BEAUTY_BASE_PRESSURE,
    FIDELITY_DECAY_PER_LEVEL,
    POVERTY_TRANSPARENCY_THRESHOLD,
)

# --- verification ---
from emergence.emergence import (
    verify_dag_acyclicity,
    verify_fidelity_bounds,
    verify_poverty_interfaces,
    verify_holographic_condensation,
    verify_transparent_vessels,
    verify_multiplicative_gate,
    verify_continuous_degrees,
    verify_beauty_motor,
    verify_top_down_flow,
    verify_all,
    yakinlasma,
    framework_summary,
)

__all__ = [
    # types
    "EmergenceLevel",
    "FlowDirection",
    "InterfaceKind",
    "VesselMode",
    "PovertyInterface",
    "EmergenceNode",
    "EmergenceEdge",
    "BeautyMotor",
    "FidelityPair",
    "EmergenceReport",
    "clamp_score",
    # engine
    "EmergenceDAG",
    "MAX_STRUCTURAL_COMPLETENESS",
    "MIN_HOLOGRAPHIC_SEED",
    "BEAUTY_BASE_PRESSURE",
    "FIDELITY_DECAY_PER_LEVEL",
    "POVERTY_TRANSPARENCY_THRESHOLD",
    # verification
    "verify_dag_acyclicity",
    "verify_fidelity_bounds",
    "verify_poverty_interfaces",
    "verify_holographic_condensation",
    "verify_transparent_vessels",
    "verify_multiplicative_gate",
    "verify_continuous_degrees",
    "verify_beauty_motor",
    "verify_top_down_flow",
    "verify_all",
    "yakinlasma",
    "framework_summary",
]
