"""
Perfect Cuboid Search Module
============================

Computational exploration of the Perfect Cuboid Problem.

A perfect cuboid is a rectangular parallelepiped where:
  - Three edges (a, b, c) are positive integers
  - Three face diagonals d_ab, d_ac, d_bc are positive integers
  - The space diagonal d_space is a positive integer

System of Diophantine equations:
  a² + b² = d²_ab
  a² + c² = d²_ac
  b² + c² = d²_bc
  a² + b² + c² = d²_space

Status: OPEN PROBLEM (no solution found; non-existence not proven)

Framework mapping (AGENTS.md):
  - AX22/T6: The perfect cuboid may be an unreachable supremum
  - AX5: Simultaneous satisfaction = integration prerequisite
  - AX52: Multiplicative gate — zero in any equation = total failure
  - AX34: The constraint gap is a functional interface, not a defect
"""

from .search import (
    is_perfect_square,
    check_cuboid,
    CuboidResult,
    euler_brick_search,
    perfect_cuboid_search,
    parametric_search,
    modular_sieve,
    find_near_misses,
)

from .analysis import (
    CascadeAnalysis,
    analyze_cascade,
    analyze_modular_obstruction,
    compute_fidelity_spectrum,
    check_holographic_property,
)

__all__ = [
    "is_perfect_square",
    "check_cuboid",
    "CuboidResult",
    "euler_brick_search",
    "perfect_cuboid_search",
    "parametric_search",
    "modular_sieve",
    "find_near_misses",
    "CascadeAnalysis",
    "analyze_cascade",
    "analyze_modular_obstruction",
    "compute_fidelity_spectrum",
    "check_holographic_property",
]
