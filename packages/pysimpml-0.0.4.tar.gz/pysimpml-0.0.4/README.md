pysimpml là thư viện dành cho người mới học Machine Learning, tập trung vào việc giúp bạn hiểu bản chất mô hình thay vì chỉ gọi hàm có sẵn.

Thư viện xử lý được hầu hết các trường hợp cơ bản trong Machine Learning, nhưng nhiều bước được giữ lại để người học tự thao tác bằng tay, giúp hiểu rõ cách mô hình hoạt động thay vì phụ thuộc hoàn toàn vào các thư viện lớn.

Thư viện được xây dựng dựa trên:
numpy — tính toán ma trận và vector
pickle — lưu model
torch / torchvision — hỗ trợ mở rộng deep learning
pillow — xử lý ảnh
csv — lưu log quá trình train (NEW)

Một điểm đặc biệt của simpmnct là khả năng in chi tiết quá trình học của mô hình, bao gồm:

Các tham số out_* có thể hiển thị:
Loss theo từng epoch (out_loss)
Gradient của mô hình (out_gradient)
Quá trình cập nhật weight và bias (out_update)
Thông tin từng epoch (out_epoch)
Công thức mô hình (out_formula)
Thống kê dữ liệu (out_stat)
Dữ liệu trước và sau xử lý (out_data)
Quá trình chia train/test (out_split)
Kích thước dữ liệu (out_shape)
Index train/test (out_index)
Giải thích quá trình dự đoán (explain=True)

Ngoài ra hỗ trợ lưu log:
Loss theo từng epoch ra file CSV (loss_csv=True)
Có thể dùng để vẽ biểu đồ hoặc debug quá trình học

Người học có thể bật hoặc tắt từng phần để quan sát cách mô hình học từng bước.

Loss qua từng epoch
Gradient (dw, db)
Cập nhật weight và bias
Công thức mô hình
Quá trình predict từng bước
Log loss ra file CSV để phân tích

pysimpml is a library for beginners in Machine Learning, focusing on helping you understand the fundamentals of the model rather than simply calling built-in functions.

The library handles most basic Machine Learning scenarios, but many steps are left to allow learners to manipulate them manually, helping them understand how the model works instead of relying entirely on large libraries.

The library is built on:
numpy — matrix and vector computation
pickle — model storage
torch / torchvision — support for deep learning extensions
pillow — image processing
csv — training log storage (New)

A unique feature of simpmnct is its ability to print detailed model learning progress, including:

The out_* parameters can display:
Loss per epoch (out_loss)
Model gradient (out_gradient)
Weight and bias update process (out_update)
Information per epoch (out_epoch)
Model formula (out_formula)
Data statistics (out_stat)
Data before and after processing (out_data)
Train/test splitting process (out_split)
Data size (out_shape)
Train/test index (out_index)
Prediction process explanation (explain=True)

Additionally supports logging:
Saving loss per epoch to CSV file (loss_csv=True)
Useful for plotting learning curves and debugging

Learners can turn each part on or off to observe how the model learns step by step.

Loss at each epoch
Gradient (dw, db)
Update weights and biases
Model formulas
Step-by-step prediction process
Export training logs to CSV for analysis

Thư viện hỗ trợ:
Linear Regression
Logistic Regression
Neural Network (Multi-Layer Perceptron) ← NEW 
Train/Test Split
Normalize dữ liệu (data)
Metrics cơ bản
Save/Load model (.best)
Export training logs (.csv) ← NEW 

import numpy as np

# Import models
from pysimpml.models import *

# DATA CLASSIFICATION
X_class = np.array([
    [1, 2],
    [2, 3],
    [3, 3],
    [6, 7],
    [7, 8],
    [8, 8]
])

y_class = np.array([0, 0, 0, 1, 1, 1])


# DATA REGRESSION
X_reg = np.array([
    [1],
    [2],
    [3],
    [4],
    [5],
    [6]
])

y_reg = np.array([2, 4, 6, 8, 10, 12])



#  KNN

print("\n===== KNN =====")

knn_c = KNNClassification(k=3, out_neighbor=True, out_distance=True, out_loss=True)
knn_c.fit(X_class, y_class)
print("KNN Class:", knn_c.predict(X_class, y_class))

knn_r = KNNRegression(k=3, weights='distance', out_neighbor=True, out_distance=True, out_loss=True)
knn_r.fit(X_reg, y_reg)
print("KNN Reg:", knn_r.predict(X_reg, y_reg))



#  DECISION TREE

print("\n===== DECISION TREE =====")

tree_c = DecisionTreeClassification(max_depth=3, loss=True, loss_csv=True)
tree_c.fit(X_class, y_class)
print("Tree Class:", tree_c.predict(X_class))

tree_r = DecisionTreeRegression(max_depth=3, loss=True, loss_csv=True)
tree_r.fit(X_reg, y_reg)
print("Tree Reg:", tree_r.predict(X_reg))



#  RANDOM FOREST

print("\n===== RANDOM FOREST =====")

rf_c = RandomForestClassification(n_trees=5, out_tree_train=True, out_vote=True, vote_csv=True)
rf_c.fit(X_class, y_class)
print("RF Class:", rf_c.predict(X_class))
print("Accuracy:", rf_c.score(X_class, y_class, explain=True))

rf_r = RandomForestRegression(n_trees=5, out_tree_train=True, out_value=True, value_csv=True)
rf_r.fit(X_reg, y_reg)
print("RF Reg:", rf_r.predict(X_reg))
print("MSE:", rf_r.score(X_reg, y_reg, explain=True))


#  TEST NEW DATA

print("\n===== TEST NEW DATA =====")

new_class = np.array([[2, 2], [7, 7]])
print("KNN Class:", knn_c.predict(new_class))
print("Tree Class:", tree_c.predict(new_class))
print("RF Class:", rf_c.predict(new_class))

new_reg = np.array([[7], [8]])
print("KNN Reg:", knn_r.predict(new_reg))
print("Tree Reg:", tree_r.predict(new_reg))
print("RF Reg:", rf_r.predict(new_reg))

lưu ý : model này là do thằng sinh viên năm 2 viết ko dùng cho dự án lớn hay dẫn đường tên lửa , có thể sai số hoặc nhiều bug tiềm ẩn , chỉ sử dụng để học hoặc làm dự án nhỏ 

Please note: this model was written by a second-year student and is not intended for large projects or missile guidance. It may contain errors or potential bugs; it is only for learning or small projects