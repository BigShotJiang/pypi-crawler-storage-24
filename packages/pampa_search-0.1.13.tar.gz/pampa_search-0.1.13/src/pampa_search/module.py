# PAMPA-SEARCH: A minimalist tree navigation library made to be usable to solve path-finding optimization problems
# PAMPA-SEARCH provides basic tree navigation for path-finding optimization problems. It has configurable features that allows the user to adapt it to the problem at hand. Its first use was to solve maze and routing problems (see examples).
# The library works both for  manually created trees or for problems in which the tree is created dinamically through iterations/movements in the problem. For that purpose, the user can create a class to describe its problems.
#
# - Copyright 2026 Tiago Oliveira Weber
# - License: MIT License
# - Repository: https://github.com/tiagoweber/pampa-search
# - Author professional website: www.tiagoweber.com.br
# - Contact: tiago.oliveira.weber@gmail.com

import copy

class node:
    def __init__(self,parent=None, value=0,is_goal=False,children=[],actions=[],name="",level=0, state = {}):
        self.value = value
        self.acc_value = None # this will be filled during the process
        self.total_cost = None # will be filled during A* process
        self.children = children
        self.actions = actions  # the node itself will not use the "action". It will be a placeholder for the problem to inform which action results in which child, so later the plan can be interpreted correctly (not by a list of node names)
        self.name = name
        self.parent = parent
        self.level = level
        self.is_goal = is_goal
        self.state = copy.deepcopy(state)
    
class tree:
    def __init__(self,problem,cross_revisit_allowed = True, strategy="depth-first"):
        self.root_node = node(name="root")
        self.problem = problem
        self.problem.restart()
        self.reset_navigation()
        self.root_node.state = problem.state 
        self.child_counter = 0
        self.node3_debug = None
        self.min_total_cost = 9e99 # min cost so far
        self.cross_revisit_allowed = cross_revisit_allowed
        self.visited_states = []  # list of dictionaries of visited states
        self.visited_states_nodes = [] # list of nodes that were already visited (different from self.visited_nodes, only used for depth so far)
            
        self.strategy = strategy.lower()
        self.solved = False
        

    def navigate_node(self,node):
        """ directs to the function responsible to return the next_node depending on the chosen strategy/algorithm """
        if (self.strategy == "depth-first"):
            return self.navigate_node_depth(node), self.solved
        elif (self.strategy == "breadth-first"):
            return self.navigate_node_breadth(node), self.solved
        elif (self.strategy == "a-star"):
            return self.navigate_node_astar(node), self.solved
        
    def reset_navigation(self):
        self.current_node = self.root_node
        self.current_level = 0 # (used in navigation for print only)
        self.visited_nodes = [] # used for navigation (used for depth-first so far)
        self.nodes_to_visit = [self.root_node] # useful only for depth first
        #self.problem.state = self.root_node.state.copy()
        
    def add_child(self,name="",value=1,is_goal=0, state = {}):
        parent_level = self.current_node.level
        child_state = copy.deepcopy(state)
        child = node(parent=self.current_node,name=name,value=value,children=[],is_goal=is_goal,level=parent_level+1,state = child_state)
        # if name=="3":
        #     self.node3_debug = child
        #     print("NODE3 created, child of %s and with state %s"%(self.current_node.name,child.state))    

        self.current_node.children.append(child)

    def get_action_to_get_to_next_node(self,node):
        list_of_actions = node.parent.actions
        list_of_nodes = node.parent.children

        node_idx = list_of_nodes.index(node)
        
        action = list_of_actions[node_idx]
#        ipdb.set_trace()

        return action
        
    def print_tree_astar(self):
        self.reset_navigation()
        
        next_node = self.root_node
        while (next_node != None):
            node = next_node            
            print("-",end="")
            for i in range(0,node.level):
                print("-",end="")
            print(" %s"%node.name)
            
            next_node = self.navigate_node_astar(node)   # this is the basic function that will be used in other applications
            if next_node.is_goal:
                return self.get_path_to_node(next_node,print_path=True)

    def get_path_to_node(self,next_node,print_path=False):
        if print_path:
            print("Found Goal in node: %s"%next_node.name)
            
        path_to_node = self.get_path_to_node(next_node)

        if print_path:
            print("Path: [",end="")
        for n in path_to_node:
            if (n.parent != None): # if it is not root
                action = self.get_action_to_get_to_next_node(n)
            else:
                action = ""

            if print_path:
                print("node: %s \t state: %s \t from action: %s "%(n.name,n.state,action))
                    
        if print_path:
            print("]")
            
        return path_to_node

        
    def navigate_node_astar(self,node):
        #self.nodes_to_visit.pop(0)
        self.nodes_to_visit.remove(node)
        # should I make node the "current_node" here? changed nothing
        
        for child in node.children:
            self.nodes_to_visit.append(child)

        if self.nodes_to_visit != []:
            #return self.nodes_to_visit[0]

            costs = self.cost_function_all_nodes() # has memory so nodes are not recalculated
            node_idx = costs.index(min(costs))      # argmin(costs)
            selected_node = self.nodes_to_visit[node_idx]
            #ipdb.set_trace()
            return selected_node
        ipdb.set_trace()

    def cost_function_all_nodes(self):
        costs = []
        self.save_state_backup(self.current_node)        
        for node in self.nodes_to_visit:
            # even as for depth-first and breadth first, which are uninformed, this cost calculation is not used,
            # it is called anyway to standardize the procedure
            cost = self.cost_function(node) 
            
            costs.append(cost)
            
        return costs
        
    def save_state_backup(self,node):
        self.node_state_backup = copy.deepcopy(node.state)
        self.current_node = node   # check if it is needed

    def restore_state_backup(self):
        self.problem.state = copy.deepcopy(self.node_state_backup)
        self.current_node.state = copy.deepcopy(self.node_state_backup)        


    def cost_function(self,node):
        #y = self.g(node) + self.h(node)

        # find the path to get to this node (put in a node list)
        path_list_of_nodes_bottom_up = self.get_path_to_node(node,order="direct")  # direct is from current to root
        path_list_of_nodes_top_down = self.get_path_to_node(node,order="reverse") # reverse is from root to current

        # find the cost to get to this node and sum all values
        total_gcost = 0
        total_hcost = 0

        # #################################################
        # Calculating the cost of getting to the node (gcost) 
        # #################################################
        
        total_gcost = 0
        temp_list_of_costs = []
        #ipdb.set_trace()
        index_of_last_acc_value_bottom_up = len(path_list_of_nodes_bottom_up)
        last_acc_value = 0
        for n in path_list_of_nodes_bottom_up:
            if (n.acc_value != None):
                total_gcost += n.acc_value
                last_acc_value = n.acc_value
                
                break
            total_gcost += n.value; # gets the value of the node (the cost to move there from the previous node)
            temp_list_of_costs.append(n.value)
            index_of_last_acc_value_bottom_up -= 1  # should get to zero if no acc value

        # update accumulated cost for all needed
        temp_list_of_costs.reverse()
        #index_of_last_acc_value_top_down = len(path_list_of_nodes_top_down) - index_of_last_acc_value_bottom_up
        index_of_last_acc_value_top_down = index_of_last_acc_value_bottom_up
        temp_list_counter = 0
        for i in range(index_of_last_acc_value_top_down,len(path_list_of_nodes_top_down)):
            last_acc_value += temp_list_of_costs[temp_list_counter]
            temp_list_counter+=1
            path_list_of_nodes_top_down[i].acc_value = last_acc_value


        # #################################################
        # Calculating the estimated cost (hcost)
        # #################################################
        if self.strategy == "a-star":
            total_hcost = self.problem.estimate_hcost(node.state)   # will be an estimate based on a function provided by the user
        else:
            total_hcost = 0

        self.restore_state_backup()
        
        node.total_cost = total_gcost + total_hcost  # this should be replaced by user
        
        if node.total_cost < self.min_total_cost:
            self.min_total_cost = node.total_cost   # min_cost will help keep track on where to prune

        return node.total_cost
        
    def get_path_to_node(self,node,order="reverse"):
        initial_node = node
        path = [node]  #initially it is bottom-up
        while node.name != "root":
            node = node.parent
            path.append(node)

        if order == "reverse":
            path.reverse()  # make it top-bottom
        return path
        
    def print_tree_breadth(self):
        self.reset_navigation()
        
        next_node = self.root_node
        while (next_node != None):
            node = next_node            
            print("-",end="")
            for i in range(0,node.level):
                print("-",end="")
            print(" %s"%node.name)
            
            next_node = self.navigate_node_breadth(node)   # this is the basic function that will be used in other applications
            if next_node.is_goal:
                return self.get_path_to_node(next_node,print_path=True)

    def navigate_node_breadth(self,node):
        self.nodes_to_visit.pop(0)
        
        for child in node.children:
            self.nodes_to_visit.append(child)
            #if child.is_goal:
            #    self.solved = True
            #    break



        if self.nodes_to_visit != []:
            return self.nodes_to_visit[0]
                            
    def print_tree_depth(self):
        self.reset_navigation()
        
        next_node = self.root_node
        while (next_node != None):
            node = next_node
            print("-",end="")
            for i in range(0,node.level):
                print("-",end="")
            print(" %s"%node.name)
            
            next_node = self.navigate_node_depth(node)   # this is the basic function that will be used in other applications
            if next_node.is_goal:
                return self.get_path_to_node(next_node,print_path=True)

            
    def navigate_node_depth(self,node):
        
        # add to visited nodes
        self.visited_nodes.append(node)
        
        has_child = False
        all_simblings_visited = True
        stop_criteria = 0
        
        while not stop_criteria:
            for child in node.children:
                has_child = True

                if child in self.visited_nodes:
                    pass
                else:
                    #if child.is_goal:
                    #    self.solved = True
                    return child

            if (node.parent != None):
                node = node.parent
            
            else:
                stop_criteria = 1
        
            
            
    def down(self):
        self.current_node = self.current_node.children[0]

    def down_last(self):
        self.current_node = self.current_node.children[-1]

    def up(self):
        self.current_node = self.current_node.parent

    def problem_load_state(self):
        self.problem.state = copy.deepcopy(self.current_node.state) # load state

    def update_current_node_to_problem(self,next_node):
        """ update current node and add problem state """
        self.current_node = next_node
        self.current_node.state = copy.deepcopy(self.problem.state)

    def prune(self,node_not_to_removed):
        nodes_removed = 0
        print("Total nodes - before prune: %d \t"%len(self.nodes_to_visit),end="")
        for node in self.nodes_to_visit:
            if ((node.acc_value != None) and (node != node_not_to_removed )):
                if node.total_cost > max(4*self.min_total_cost,1):
                #if node.acc_value > max(1*self.min_total_cost,1):
                    self.nodes_to_visit.remove(node)                    
                    nodes_removed +=1

        #print("Prunning - Nodes removed: %d"%nodes_removed)
        print("after prune: %d "%len(self.nodes_to_visit))
        print("Min total cost = %d "%self.min_total_cost)

    def populate_actions_and_children(self):
        # load current_node state into problem state
        self.problem_load_state()

        # populate actions
        self.current_node.actions = self.problem.get_available_actions() 

        # populate children
        is_goal_reached = False
        actions_to_remove = []
        
        #print("#####")
        #print("In node %s, PREVIOUS to analyzing - possible actions %s"%(self.current_node.name,self.current_node.actions))

        for action in self.current_node.actions:
            self.problem_load_state()
            #move 
            cost_to_move = self.problem.move(action)
            
            # create child
            is_goal_reached = self.problem.check()            

            # check if child state is not an already visited state
            visited = False
            if (self.cross_revisit_allowed): # makes sense to check the node path only if we are not going to check the global history
                path_to_node = self.get_path_to_node(self.current_node)

                for previous_node in path_to_node:            
                    past_position = previous_node.state["board_player_position"]
                    if (self.problem.state["board_player_position"] == past_position):
                        visited = True

            # check if child state is not an already visited state by any other node (not just in its path)
            cross_visited = False
            # check cross revisit
            if not(self.cross_revisit_allowed):
                if self.problem.state in self.visited_states:
                    cross_visited = True

            # ######################
            # check what to do with cross_visited
            # ######################
            # This part is commented because so far it was not necessary and it seems to have a bug
            # (using a-star: going back in its own path on map 20x20 b)
            
            # if (cross_visited):
            #     print("Cross visited")
            # #     # check if current visited is better than the previous
            #     cross_visited_index = self.visited_states.index(self.problem.state)
                
            #     # Calculating the cost for the memory (cross_visited node) and the current
            #     # PS.: self.cost_function is already a cost for all the path
            #     self.save_state_backup(self.current_node)   # NEEDED before using cost_function
            #     memory_total_cost = self.cost_function(self.visited_states_nodes[cross_visited_index]) 
            #     current_total_cost = self.cost_function(self.current_node)
            #     current_total_cost += 1  #self.problem.value   # not yet implemented in problem (cost to move always 1)
            #                                                    # still ignoring the estimated cost
                
            #     if self.strategy == "a-star":
            #         current_total_cost += self.problem.estimate_hcost(self.problem.state)  #  #(self.current_node.state)
                    
            #     if current_total_cost < memory_total_cost:
            #         # accept the current node as being the one the last one should have used
            #         print("Current total cost is less than what memory total cost was!")

            #         self.visited_states_nodes[cross_visited_index] = self.current_node                    
            #         ipdb.set_trace()                  
            #         # continue as if it was not cross_visited
            #         cross_visited = False
            
            if (not(visited) and not(cross_visited)):
                
                self.add_child(name=str(self.child_counter),value=cost_to_move,is_goal=is_goal_reached, state = self.problem.state)
                #print("Addition of child for node %s \t action: %s \t child: %s"%(self.current_node.name,action,self.current_node.children[-1]))
                self.child_counter += 1
                if not(self.cross_revisit_allowed):
                    self.visited_states.append(copy.deepcopy(self.problem.state))
                    self.visited_states_nodes.append(self.current_node.children[-1])  # CHECK

                if is_goal_reached: # avoid checking other children
                    self.solved = True
                    break
            
                                                                                
            else:
                # remove action
                actions_to_remove.append(action) #can't be directly removed because it is being cycled
                
        for action in actions_to_remove:
            self.current_node.actions.remove(action)
            
        #print("Remaining actions: %s \t children: %s"%(self.current_node.actions,self.current_node.children))
                    

        self.problem_load_state()
