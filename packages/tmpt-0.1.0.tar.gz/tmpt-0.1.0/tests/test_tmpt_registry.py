from __future__ import annotations

import pytest

from tmpt import Tmpt, TmptRegistry


def test_tmpt_v2_has_registry_interface():
    """Tmpt delegates registry operations to TmptRegistry."""
    assert hasattr(Tmpt, "registry")
    assert hasattr(Tmpt, "clear")
    assert hasattr(Tmpt, "list")


def test_tmpt_v2_loads_current_directory(monkeypatch, tmp_path, write_file):
    write_file(tmp_path / "my_prompt.md", "Hello {{ name }}")
    monkeypatch.chdir(tmp_path)

    tmpt = Tmpt("./")

    assert "my_prompt.1" in tmpt.list()


def test_tmpt_v2_does_not_scan_hidden_directories(monkeypatch, tmp_path, write_file):
    write_file(tmp_path / ".hidden" / "secret.md", "secret")
    write_file(tmp_path / "visible.md", "visible")
    monkeypatch.chdir(tmp_path)

    tmpt = Tmpt("./")

    assert "visible.1" in tmpt.list()
    assert "secret" not in tmpt.list()


def test_tmpt_v2_registers_path_source(tmp_path, write_file):
    source = tmp_path / "my_prompt.md"
    write_file(source, "My name is {{ name }}")

    tmpt = Tmpt(source)

    assert isinstance(tmpt, Tmpt)
    assert tmpt.id == "my_prompt.1"


def test_tmpt_v2_registers_explicit_variant_filename(tmp_path, write_file):
    source = tmp_path / "my_prompt.2.md"
    write_file(source, "Variant two")

    tmpt = Tmpt(source)

    assert tmpt.id == "my_prompt.2"
    assert tmpt() == "Variant two"


class TestTmptRegistryVariantsId:
    def test_tmpt_file_variants_simple_filename_aliases(
        self, monkeypatch, tmp_path, write_file
    ):
        source = tmp_path / "my_prompt.md"
        write_file(source, "Variant")

        Tmpt.clear()
        Tmpt["my_prompt"] = source
        tmpt = Tmpt["my_prompt"]

        assert tmpt.id == "my_prompt"
        assert tmpt() == "Variant"
        assert Tmpt["my_prompt"] == "Variant"
        # assert Tmpt["my_prompt.latest"] == "Variant"
        assert Tmpt["my_prompt"] == "Variant"

        with pytest.raises(KeyError):
            Tmpt["my_prompt.2"]
