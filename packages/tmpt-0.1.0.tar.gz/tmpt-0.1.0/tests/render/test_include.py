from __future__ import annotations

import pytest

from tmpt.render.context import RenderContext
from tmpt.render.include import RendererInclude
from tmpt.render.pipeline import PipelineRenderer
from tmpt.render.vars import RendererVars
from tmpt.tmpt_data import TmptData
from tmpt.tmpt_registry import TmptRegistry


def _ctx(registry: TmptRegistry) -> RenderContext:
    return {"registry": registry}


def _data(template: str) -> TmptData:
    return TmptData(template=template)


@pytest.fixture()
def registry() -> TmptRegistry:
    r = TmptRegistry()
    r.load("Hello, World!")  # → _local.1
    r.set("footer", "-- end --")  # named id
    return r


# ------------------------------------------------------------------ #
# syntax                                                         #
# ------------------------------------------------------------------ #


@pytest.mark.parametrize(
    "tag",
    [
        "{{#_local.1}}",
        "{{  #_local.1}}",
        "{{#_local.1  }}",
        "{{ #_local.1 }}",
        "{{# _local.1}}",
        "{{#   _local.1 }}",
    ],
)
def test_syntax(registry, tag):
    assert RendererInclude().render(_data(tag), _ctx(registry)) == "Hello, World!"


# ------------------------------------------------------------------ #
# substitution                                                         #
# ------------------------------------------------------------------ #


def test_known_id_replaced(registry):
    result = RendererInclude().render(_data("{{#_local.1}}"), _ctx(registry))
    assert result == "Hello, World!"


def test_tag_left_unchanged_when_id_not_found(registry):
    result = RendererInclude().render(_data("{{#unknown}}"), _ctx(registry))
    assert result == "{{#unknown}}"


def test_multiple_includes(registry):
    result = RendererInclude().render(
        _data("{{#_local.1}}\n{{#footer}}"),
        _ctx(registry),
    )
    assert result == "Hello, World!\n-- end --"


def test_include_alongside_text(registry):
    result = RendererInclude().render(
        _data("START\n{{#_local.1}}\nEND"),
        _ctx(registry),
    )
    assert result == "START\nHello, World!\nEND"


def test_tag_with_extra_whitespace(registry):
    result = RendererInclude().render(_data("{{# _local.1 }}"), _ctx(registry))
    assert result == "Hello, World!"


# ------------------------------------------------------------------ #
# no-op cases                                                          #
# ------------------------------------------------------------------ #


def test_no_tags_returns_template_unchanged(registry):
    result = RendererInclude().render(_data("plain text"), _ctx(registry))
    assert result == "plain text"


def test_no_ctx_leaves_tags_unchanged():
    result = RendererInclude().render(_data("{{#something}}"), None)
    assert result == "{{#something}}"


def test_no_registry_in_ctx_leaves_tags_unchanged():
    result = RendererInclude().render(_data("{{#something}}"), {})
    assert result == "{{#something}}"


def test_regular_var_tags_not_affected(registry):
    result = RendererInclude().render(_data("{{ name }}"), _ctx(registry))
    assert result == "{{ name }}"


# ------------------------------------------------------------------ #
# pipeline integration: include then substitute vars                   #
# ------------------------------------------------------------------ #


def test_include_then_vars_pipeline():
    """Included template containing {{ var }} is resolved by downstream RendererVars."""
    registry = TmptRegistry()
    registry.load("Hi {{ name }}!")  # _local.1

    data = TmptData(template="{{#_local.1}}", vars={"name": "Alice"})
    result = PipelineRenderer([RendererInclude(), RendererVars()]).render(
        data, _ctx(registry)
    )
    assert result == "Hi Alice!"


# ------------------------------------------------------------------ #
# cycle detection                                                       #
# ------------------------------------------------------------------ #


def test_self_include_cycle_leaves_tag_unchanged():
    """A template that includes itself must not recurse infinitely."""
    registry = TmptRegistry()
    # Manually insert so set() can target the exact key used inside the template.
    registry.set("self_ref", "before {{#self_ref}} after")
    result = RendererInclude().render(
        _data("{{#self_ref}}"),
        _ctx(registry),
    )
    # The recursive tag is left unchanged; no infinite recursion.
    assert result == "before {{#self_ref}} after"


def test_mutual_include_cycle_leaves_tag_unchanged():
    """A → B → A cycle must not recurse infinitely."""
    registry = TmptRegistry()
    registry.set("a", "A:{{#b}}")
    registry.set("b", "B:{{#a}}")
    result = RendererInclude().render(_data("{{#a}}"), _ctx(registry))
    # b expands, then when b tries to include a it is already in _visiting → left unchanged.
    assert result == "A:B:{{#a}}"


def test_deep_chain_no_cycle_resolves_fully():
    """A → B → C (no cycle) resolves all the way."""
    registry = TmptRegistry()
    registry.set("c", "C")
    registry.set("b", "B+{{#c}}")
    registry.set("a", "A+{{#b}}")
    result = RendererInclude().render(_data("{{#a}}"), _ctx(registry))
    assert result == "A+B+C"
