from __future__ import annotations

from tmpt.render.context import RenderContext
from tmpt.render.pipeline import PipelineRenderer
from tmpt.render.transform import (
    RendererPassthrough,
    RendererTransformAppend,
    RendererTransformToUpper,
)
from tmpt.tmpt_data import TmptData


def _data(template: str, vars: dict | None = None) -> TmptData:
    return TmptData(template=template, vars=vars or {})


# ------------------------------------------------------------------ #
# render()                                                             #
# ------------------------------------------------------------------ #


def test_empty_pipeline_returns_template():
    assert PipelineRenderer([]).render(_data("hello")) == "hello"


def test_empty_pipeline_returns_empty_string_when_no_template():
    assert PipelineRenderer([]).render(TmptData()) == ""


def test_single_stage():
    result = PipelineRenderer([RendererTransformToUpper()]).render(_data("hello"))
    assert result == "HELLO"


def test_stages_applied_in_order():
    result = PipelineRenderer(
        [RendererTransformToUpper(), RendererTransformAppend("!")]
    ).render(_data("hello"))
    assert result == "HELLO!"


def test_stages_order_matters():
    result = PipelineRenderer(
        [RendererTransformAppend("!"), RendererTransformToUpper()]
    ).render(_data("hello"))
    assert result == "HELLO!"


def test_each_stage_receives_updated_template():
    """Each stage sees the output of the previous one, not the original."""
    seen: list[str] = []

    from tmpt.render.base import RendererBase

    class Spy(RendererBase):
        def render(self, data: TmptData, ctx: RenderContext | None = None) -> str:
            seen.append(data.template or "")
            return (data.template or "") + "x"

    PipelineRenderer([Spy(), Spy()]).render(_data("a"))
    assert seen == ["a", "ax"]


def test_ctx_passed_to_stages():
    received: list[RenderContext | None] = []

    from tmpt.render.base import RendererBase

    class CtxCapture(RendererBase):
        def render(self, data: TmptData, ctx: RenderContext | None = None) -> str:
            received.append(ctx)
            return data.template or ""

    ctx: RenderContext = {}
    PipelineRenderer([CtxCapture()]).render(_data("hi"), ctx)
    assert received == [ctx]


def test_ctx_defaults_to_none():
    received: list[RenderContext | None] = []

    from tmpt.render.base import RendererBase

    class CtxCapture(RendererBase):
        def render(self, data: TmptData, ctx: RenderContext | None = None) -> str:
            received.append(ctx)
            return data.template or ""

    PipelineRenderer([CtxCapture()]).render(_data("hi"))
    assert received == [None]


# ------------------------------------------------------------------ #
# list behaviour (UserList)                                            #
# ------------------------------------------------------------------ #


def test_is_a_sequence():
    from collections.abc import MutableSequence

    p = PipelineRenderer([RendererTransformToUpper()])
    assert isinstance(p, MutableSequence)
    assert len(p) == 1


def test_append():
    p = PipelineRenderer([RendererTransformToUpper()])
    p.append(RendererTransformAppend("!"))
    assert len(p) == 2
    assert p.render(_data("hello")) == "HELLO!"


def test_indexing():
    upper = RendererTransformToUpper()
    p = PipelineRenderer([upper, RendererTransformAppend("!")])
    assert p[0] is upper


def test_slice_returns_pipeline_renderer():
    p = PipelineRenderer(
        [
            RendererTransformToUpper(),
            RendererTransformAppend("!"),
            RendererPassthrough(),
        ]
    )
    sliced = p[:2]
    assert isinstance(sliced, PipelineRenderer)
    assert sliced.render(_data("hi")) == "HI!"


def test_empty_pipeline_is_falsy():
    assert not PipelineRenderer([])


def test_nonempty_pipeline_is_truthy():
    assert PipelineRenderer([RendererTransformToUpper()])
