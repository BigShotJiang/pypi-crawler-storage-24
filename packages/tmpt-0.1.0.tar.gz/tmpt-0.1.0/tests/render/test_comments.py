from __future__ import annotations

import pytest

from tmpt.render.comments import RendererStripComments
from tmpt.tmpt_data import TmptData


def _render(template: str) -> str:
    return RendererStripComments().render(TmptData(template=template))


# ------------------------------------------------------------------ #
# basic removal                                                        #
# ------------------------------------------------------------------ #


@pytest.mark.parametrize(
    "template, expected",
    [
        # sole comment line — result is empty
        ("// this is a comment", ""),
        # comment at start of multi-line template
        ("// comment\nhello", "\nhello"),
        # comment at end
        ("hello\n// comment", "hello\n"),
        # comment in the middle
        ("hello\n// comment\nworld", "hello\n\nworld"),
        # indented comment
        ("  // indented comment\nhello", "\nhello"),
        # tab-indented comment
        ("\t// tab comment\nhello", "\nhello"),
    ],
)
def test_comment_line_removed(template: str, expected: str) -> None:
    assert _render(template) == expected


# ------------------------------------------------------------------ #
# not a comment                                                        #
# ------------------------------------------------------------------ #


@pytest.mark.parametrize(
    "template",
    [
        "hello world",
        "hello // not a comment",  # inline // after content — untouched
        "url = https://example.com",  # // inside a value — untouched
        "{{ var }}",  # template tag — untouched
    ],
)
def test_non_comment_unchanged(template: str) -> None:
    assert _render(template) == template


# ------------------------------------------------------------------ #
# multiple comments                                                    #
# ------------------------------------------------------------------ #


def test_multiple_comment_lines_removed() -> None:
    template = "// one\n// two\nhello\n// three\nworld"
    assert _render(template) == "\n\nhello\n\nworld"


def test_consecutive_comments_no_excess_blanks() -> None:
    template = "before\n// a\n// b\n// c\nafter"
    result = _render(template)
    # Should not produce more than two consecutive newlines
    assert "\n\n\n" not in result
    assert "before" in result
    assert "after" in result


# ------------------------------------------------------------------ #
# empty / no-op inputs                                                 #
# ------------------------------------------------------------------ #


def test_empty_template() -> None:
    assert _render("") == ""


def test_no_comments_returns_unchanged() -> None:
    template = "hello\nworld\n{{ name }}"
    assert _render(template) == template


def test_no_ctx_required() -> None:
    # RendererStripComments does not need a ctx — passing None is fine
    result = RendererStripComments().render(
        TmptData(template="// drop\nkeep"), ctx=None
    )
    assert result == "\nkeep"
