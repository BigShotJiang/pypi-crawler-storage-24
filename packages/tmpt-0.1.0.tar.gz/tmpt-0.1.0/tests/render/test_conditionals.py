from __future__ import annotations

import pytest

from tmpt.render.conditionals import RendererConditionals
from tmpt.tmpt_data import TmptData


def _render(template: str, **vars: object) -> str:
    return RendererConditionals().render(TmptData(template=template, vars=dict(vars)))


# ------------------------------------------------------------------ #
# Paragraph mode — {{ ? var }}                                        #
# ------------------------------------------------------------------ #


class TestParagraphMode:
    def test_body_shown_when_var_set(self) -> None:
        t = "{{ ? name }}\nHello {{ name }}\n\nrest"
        assert _render(t, name="Alice") == "Hello {{ name }}\n\nrest"

    def test_body_hidden_when_var_missing(self) -> None:
        t = "{{ ? name }}\nHello {{ name }}\n\nrest"
        assert _render(t) == "rest"

    def test_body_hidden_when_var_empty_string(self) -> None:
        t = "{{ ? name }}\nHello\n\nrest"
        assert _render(t, name="") == "rest"

    def test_body_hidden_when_var_whitespace_only(self) -> None:
        t = "{{ ? name }}\nHello\n\nrest"
        assert _render(t, name="   ") == "rest"

    def test_question_mark_alias(self) -> None:
        t = "{{ ? show }}\nshown\n\nrest"
        assert _render(t, show="yes") == "shown\n\nrest"

    def test_question_mark_hidden(self) -> None:
        t = "{{ ? show }}\nshown\n\nrest"
        assert _render(t) == "rest"

    def test_content_after_conditional_always_rendered(self) -> None:
        t = "{{ ? x }}\nconditional\n\nalways"
        result = _render(t)
        assert "always" in result
        assert "conditional" not in result


# ------------------------------------------------------------------ #
# Negation — {{ ! var }} and {{ ! var }}                          #
# ------------------------------------------------------------------ #


class TestNegation:
    def test_bang_shown_when_var_missing(self) -> None:
        t = "{{ ! name }}\nfallback\n\nrest"
        assert _render(t) == "fallback\n\nrest"

    def test_bang_hidden_when_var_set(self) -> None:
        t = "{{ ! name }}\nfallback\n\nrest"
        assert _render(t, name="Alice") == "rest"

    def test_if_not_shown_when_var_missing(self) -> None:
        t = "{{ ! name }}\nfallback\n\nrest"
        assert _render(t) == "fallback\n\nrest"

    def test_if_not_hidden_when_var_set(self) -> None:
        t = "{{ ! name }}\nfallback\n\nrest"
        assert _render(t, name="Alice") == "rest"


# ------------------------------------------------------------------ #
# Section mode — body starts with a markdown heading                  #
# ------------------------------------------------------------------ #


class TestSectionMode:
    def test_section_shown_when_var_set(self) -> None:
        t = "{{ ? detail }}\n## Details\nsome detail\n\n#\nafter"
        result = _render(t, detail="yes")
        assert "## Details" in result
        assert "some detail" in result
        assert "after" in result

    def test_section_hidden_when_var_missing(self) -> None:
        t = "{{ ? detail }}\n## Details\nsome detail\n\n#\nafter"
        result = _render(t)
        assert "## Details" not in result
        assert "some detail" not in result
        assert "after" in result

    def test_bare_hash_fence_consumed(self) -> None:
        t = "{{ ? x }}\n## Section\nbody\n#\nafter"
        result = _render(t, x="1")
        assert "#\n" not in result
        assert "after" in result

    def test_section_ends_at_new_top_heading(self) -> None:
        t = "{{ ? x }}\n## Conditional\nbody\n\n# Always\nuncond"
        result = _render(t)
        assert "Conditional" not in result
        assert "Always" in result
        assert "uncond" in result


# ------------------------------------------------------------------ #
# End-of-document body                                                 #
# ------------------------------------------------------------------ #


class TestEndOfDocument:
    def test_body_until_eof_shown(self) -> None:
        t = "intro\n\n{{ ? x }}\nconditional content\nmore here"
        result = _render(t, x="yes")
        assert "intro" in result
        assert "conditional content" in result

    def test_body_until_eof_hidden(self) -> None:
        t = "intro\n\n{{ ? x }}\nconditional content"
        result = _render(t)
        assert "intro" in result
        assert "conditional content" not in result


# ------------------------------------------------------------------ #
# Inline conditionals                                                  #
# ------------------------------------------------------------------ #


class TestInlineConditionals:
    def test_inline_tag_removed_when_true(self) -> None:
        line = "Hello {{ ? name }}, world\n"
        result = _render(line, name="Alice")
        assert result == "Hello Alice, world\n"

    def test_rest_of_line_removed_when_false(self) -> None:
        line = "Hello {{ ? name }}, world\n"
        result = _render(line)
        assert result.strip() == ""

    def test_inline_bang_line_deleted_when_set(self) -> None:
        line = "Hello{{ ! name }}, stranger\n"
        result = _render(line, name="Alice")
        assert result.strip() == ""

    def test_inline_bang_tag_removed_when_missing(self) -> None:
        line = "Hello{{ ! name }}, stranger\n"
        result = _render(line)
        assert "Hello, stranger\n" == result


# ------------------------------------------------------------------ #
# No-op cases                                                          #
# ------------------------------------------------------------------ #


class TestNoOp:
    def test_template_without_directives_unchanged(self) -> None:
        t = "Hello {{ name }}!\nNo conditionals here."
        assert _render(t, name="Alice") == t

    def test_empty_template(self) -> None:
        assert _render("") == ""

    def test_no_vars_no_directives(self) -> None:
        t = "plain text"
        assert _render(t) == t


# ------------------------------------------------------------------ #
# Multiple conditionals                                                #
# ------------------------------------------------------------------ #


class TestMultipleConditionals:
    def test_two_independent_blocks(self) -> None:
        t = "{{ ? a }}\nblock a\n\n{{ ? b }}\nblock b\n\nend"
        result = _render(t, a="1")
        assert "block a" in result
        assert "block b" not in result
        assert "end" in result

    def test_both_blocks_shown(self) -> None:
        t = "{{ ? a }}\nblock a\n\n{{ ? b }}\nblock b\n\nend"
        result = _render(t, a="1", b="1")
        assert "block a" in result
        assert "block b" in result

    def test_neither_block_shown(self) -> None:
        t = "{{ ? a }}\nblock a\n\n{{ ? b }}\nblock b\n\nend"
        result = _render(t)
        assert "block a" not in result
        assert "block b" not in result
        assert "end" in result


# ------------------------------------------------------------------ #
# Pipeline integration — conditionals before vars                     #
# ------------------------------------------------------------------ #


class TestPipelineIntegration:
    def test_conditional_then_vars_pipeline(self) -> None:
        from tmpt.render.pipeline import PipelineRenderer
        from tmpt.render.vars import RendererVars

        pipeline = PipelineRenderer([RendererConditionals(), RendererVars()])
        data = TmptData(
            template="{{ ? greeting }}\nHello, {{ name }}!\n\nbye",
            vars={"greeting": "yes", "name": "Alice"},
        )
        result = pipeline.render(data)
        assert result == "Hello, Alice!\n\nbye"

    def test_conditional_hides_vars_block(self) -> None:
        from tmpt.render.pipeline import PipelineRenderer
        from tmpt.render.vars import RendererVars

        pipeline = PipelineRenderer([RendererConditionals(), RendererVars()])
        data = TmptData(
            template="{{ ? greeting }}\nHello, {{ name }}!\n\nbye",
            vars={"name": "Alice"},
        )
        result = pipeline.render(data)
        assert "Hello" not in result
        assert "bye" in result
