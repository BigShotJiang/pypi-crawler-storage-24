import pytest

from tmpt.render.vars import RendererVars
from tmpt.tmpt_data import TmptData


def r(template: str, **vars) -> str:
    return RendererVars().render(TmptData(template=template, vars=vars))


class TestRendererVarsPassVars:
    def test_renderervars_substitutes_single_var(self):
        assert r("Hello {{ name }}!", name="Alice") == "Hello Alice!"

    def test_renderervars_substitutes_multiple_vars(self):
        assert (
            r("{{ greeting }} {{ name }}!", greeting="Hello", name="Alice")
            == "Hello Alice!"
        )

    def test_renderervars_substitutes_from_call_dict_with_inline_default(self):
        assert r("Hello {{ name:Bob }}!", name="Alice") == "Hello Alice!"

    def test_renderervars_substitutes_from_kwargs_with_inline_default(self):
        assert r("Hello {{ name:Bob }}!", name="Alice") == "Hello Alice!"


##########################


class TestRendererVarsPassVarsWithWhitespaces:
    @pytest.mark.parametrize(
        ("value", "expected"),
        [
            (" Alice ", "Hello  Alice !"),
            ("\tAlice\t", "Hello \tAlice\t!"),
            ("\nAlice\n", "Hello \nAlice\n!"),
            ("Alice  Bob\n\nAnd you!\n", "Hello Alice  Bob\n\nAnd you!\n!"),
        ],
    )
    def test_renderervars_preserves_whitespace_inside_variable_value(
        self, value, expected
    ):
        assert r("Hello {{ name }}!", name=value) == expected

    def test_renderervars_preserves_multiline_variable_value(self):
        assert (
            r("Value:[{{ text }}]", text="line1\n  line2\nline3")
            == "Value:[line1\n  line2\nline3]"
        )

    @pytest.mark.parametrize(
        ("template", "expected"),
        [
            ("Hello {{ name:' Alice ' }}!", "Hello  Alice !"),
            ("Hello {{ name:'\tAlice\t' }}!", "Hello \tAlice\t!"),
            ("Hello {{ name:'Alice  Bob' }}!", "Hello Alice  Bob!"),
        ],
    )
    def test_renderervars_inline_default_preserves_whitespace(self, template, expected):
        assert r(template) == expected

    def test_renderervars_inline_default_with_newlines_is_left_unchanged(self):
        template = "Hello {{ name:'\nAlice\n' }}!"
        assert r(template) == template

    def test_renderervars_inline_default_with_whitespace_is_overridden_by_value(self):
        assert r("Hello {{ name:' Alice ' }}!", name="Bob") == "Hello Bob!"


class TestRendererVarsSyntax:
    @pytest.mark.parametrize(
        "template",
        [
            ("Hello {{ name }}!"),
            ("Hello {{ name}}!"),
            ("Hello {{name}}!"),
            ("Hello {{  name}}!"),
            ("Hello {{  name  }}!"),
            ("Hello {{  name \n }}!"),
            ("Hello {{\t\tname}}!"),
            ("Hello {{ \nname}}!"),
            ("Hello {{ \nname\n}}!"),
        ],
    )
    def test_renderervars_syntax_ok(self, template):
        assert r(template, name="Alice") == "Hello Alice!"

    @pytest.mark.parametrize(
        "template",
        [
            ("Hello { name }!"),
            ("Hello {{ name }!"),
            ("Hello {{ nam      e }}!"),
            ("Hello {{ \nna\nme\n}}!"),
            ("Hello {{ \nna\n     me\n}}!"),
        ],
    )
    def test_renderervars_syntax_wrong(self, template):
        assert r(template, name="Alice") == template

    @pytest.mark.parametrize(
        "template",
        [
            ("Hello {{ name:Alice }}!"),
            ("Hello {{ name : Alice}}!"),
            ("Hello {{ name : Alice    }}!"),
            ("Hello {{ name:    Alice    }}!"),
            ("Hello {{name:Alice  }}!"),
            ("Hello {{  name:Alice}}!"),
            ("Hello {{  name   :Alice }}!"),
            ("Hello {{\t\tname\t:Alice}}!"),
            ("Hello {{ \nname:Alice}}!"),
        ],
    )
    def test_renderervars_default_syntax_ok(self, template):
        assert r(template) == "Hello Alice!"


##########################


class TestRendererVarsInlineDefaults:
    def test_renderervars_with_inline_default(self):
        assert r("Hello {{ name:Bob }}!") == "Hello Bob!"

    def test_renderervars_with_literal_default(self):
        assert r("Value: {{ value:42 }}") == "Value: 42"

    def test_renderervars_with_string_literal_default(self):
        assert r("Hello {{ name:'friend' }}!") == "Hello friend!"

    def test_renderervars_with_space_default(self):
        assert r("Hello {{ name: }}!") == "Hello !"

    def test_renderervars_with_empty_default(self):
        assert r("Hello {{ name:}}!") == "Hello !"

    def test_renderervars_with_none_default(self):
        assert r("Hello {{ name:None }}!") == "Hello None!"

    def test_renderervars_no_var_name(self):
        assert r('Hello {{ : "Alice" }}!') == "Hello Alice!"


##########################


class TestRendererVarsDict:
    def test_renderervars_substitutes_dict_value(self):
        assert (
            r("Data={{ data }}", data={"a": 1, "b": "x"}) == "Data={'a': 1, 'b': 'x'}"
        )

    def test_renderervars_inline_default_dict(self):
        assert (
            r("Payload: {{ payload:{'ok': True, 'n': 2} }}")
            == "Payload: {'ok': True, 'n': 2}"
        )

    def test_renderervars_inline_default_empty_dict(self):
        assert r("Payload: {{ payload:{} }}") == "Payload: {}"

    def test_renderervars_no_default_keeps_missing_dict_expr(self):
        assert r("Payload: {{ payload }}") == "Payload: {{ payload }}"

    def test_renderervars_empty_dict_value_does_not_fallback_to_default(self):
        assert r("Payload: {{ payload:{'k': 1} }}", payload={}) == "Payload: {}"


##########################


class TestRendererVarsJSON:
    def test_renderervars_inline_default_json_object_like(self):
        assert r('JSON: {{ payload:{"a": 1, "b": "x"} }}') == "JSON: {'a': 1, 'b': 'x'}"

    def test_renderervars_inline_default_json_array_like(self):
        assert r('Items: {{ items:[1, 2, "x"] }}') == "Items: [1, 2, 'x']"

    def test_renderervars_json_string_value(self):
        assert (
            r("Raw: {{ payload }}", payload='{"a": 1, "b": "x"}')
            == 'Raw: {"a": 1, "b": "x"}'
        )

    def test_renderervars_quoted_json_default_stays_string(self):
        assert r("Raw: {{ payload:'{\"a\": 1}' }}") == 'Raw: {"a": 1}'

    def test_renderervars_json_true_null_literals_are_left_raw(self):
        assert (
            r('Raw: {{ payload:{"ok": true, "v": null} }}')
            == 'Raw: {"ok": true, "v": null}'
        )

    def test_renderervars_malformed_json_like_default_is_left_raw(self):
        assert r("Raw: {{ payload:{a:1} }}") == "Raw: {a:1}"


##########################
