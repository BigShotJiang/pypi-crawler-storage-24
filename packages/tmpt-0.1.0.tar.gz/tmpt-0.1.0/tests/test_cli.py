from __future__ import annotations

from tmpt.cli import main


def test_cli_defaults_to_validate_folder(monkeypatch, tmp_path, write_file, capsys):
    monkeypatch.setenv("TMPT_NO_RICH", "1")
    write_file(tmp_path / "welcome.md", "Hello {{ name }}")
    monkeypatch.chdir(tmp_path)

    rc = main([])

    out = capsys.readouterr().out
    assert rc == 0
    assert "Prompt Files" in out
    assert "welcome" in out


def test_cli_validate_folder_shows_variable_names(
    monkeypatch, tmp_path, write_file, capsys
):
    monkeypatch.setenv("TMPT_NO_RICH", "1")
    write_file(tmp_path / "greet.md", "Hello {{ name }}, topic is {{ topic }}")
    monkeypatch.chdir(tmp_path)

    rc = main([])

    out = capsys.readouterr().out
    assert rc == 0
    assert "name" in out
    assert "topic" in out


def test_cli_validate_file_reports_variants(monkeypatch, tmp_path, write_file, capsys):
    monkeypatch.setenv("TMPT_NO_RICH", "1")
    write_file(tmp_path / "prompt.md", "One\n---\nTwo")

    rc = main(["validate", str(tmp_path / "prompt.md")])

    out = capsys.readouterr().out
    assert rc == 0
    assert "File: prompt.md" in out
    assert "2 variant(s)" in out
    assert "prompt.1" in out
    assert "prompt.2" in out


def test_cli_validate_explicit_file_shows_only_that_file(
    monkeypatch, tmp_path, write_file, capsys
):
    monkeypatch.setenv("TMPT_NO_RICH", "1")
    write_file(tmp_path / "notes.md", "Primary note")
    write_file(tmp_path / "nested" / "notes.md", "Nested note")

    rc = main(["validate", str(tmp_path / "notes.md")])

    out = capsys.readouterr().out
    assert rc == 0
    assert "File: notes.md" in out
    assert "1 variant(s)" in out
    assert "notes.1" in out


def test_cli_validate_id_resolves_prompt(monkeypatch, tmp_path, write_file, capsys):
    monkeypatch.setenv("TMPT_NO_RICH", "1")
    write_file(tmp_path / "review.md", "V1\n---\nV2")
    monkeypatch.chdir(tmp_path)

    rc = main(["validate", "review.2"])

    out = capsys.readouterr().out
    assert rc == 0
    assert "review.2" in out


def test_cli_validate_unknown_path_defaults_to_current_dir(
    monkeypatch, tmp_path, write_file, capsys
):
    monkeypatch.setenv("TMPT_NO_RICH", "1")
    write_file(tmp_path / "hello.md", "Hi {{ name }}")
    monkeypatch.chdir(tmp_path)

    # passing a bare word that is not an existing path → treated as ID (not found)
    rc = main(["validate", "nonexistent_id_xyz"])

    assert rc == 1


def test_cli_render_shows_raw_and_rendered(monkeypatch, tmp_path, write_file, capsys):
    monkeypatch.setenv("TMPT_NO_RICH", "1")
    write_file(tmp_path / "greet.md", "Hello {{ name }}")
    monkeypatch.chdir(tmp_path)

    rc = main(["render", "greet", "--name=Michal"])

    captured = capsys.readouterr()
    assert rc == 0
    # UI panels go to stderr
    assert "Prompt Details" in captured.err
    assert "Template" in captured.err
    assert "Rendered Prompt" in captured.err
    assert "Hello {{ name }}" in captured.err
    # raw rendered text goes to stdout
    assert captured.out.strip() == "Hello Michal"


def test_cli_render_shows_frontmatter_vars(monkeypatch, tmp_path, write_file, capsys):
    monkeypatch.setenv("TMPT_NO_RICH", "1")
    write_file(
        tmp_path / "greet.md",
        "---\ntopic: from_frontmatter\n---\nTopic: {{ topic }}",
    )
    monkeypatch.chdir(tmp_path)

    rc = main(["render", "greet", "--topic=from_cli"])

    captured = capsys.readouterr()
    assert rc == 0
    # UI details on stderr
    assert "frontmatter" in captured.err
    assert "from_frontmatter" in captured.err
    assert "variables" in captured.err
    assert "topic" in captured.err
    # raw rendered on stdout
    assert "from_cli" in captured.out


def test_cli_render_missing_id_returns_error(monkeypatch, tmp_path, capsys):
    monkeypatch.setenv("TMPT_NO_RICH", "1")
    monkeypatch.chdir(tmp_path)

    rc = main(["render", "no_such_prompt"])

    assert rc == 1


def test_cli_render_suggests_close_match(monkeypatch, tmp_path, write_file, capsys):
    monkeypatch.setenv("TMPT_NO_RICH", "1")
    write_file(tmp_path / "greet.md", "Hello {{ name }}")
    monkeypatch.chdir(tmp_path)

    rc = main(["render", "greets"])

    err = capsys.readouterr().err
    assert rc == 1
    assert "greet" in err


def test_cli_render_long_form_variable(monkeypatch, tmp_path, write_file, capsys):
    monkeypatch.setenv("TMPT_NO_RICH", "1")
    write_file(tmp_path / "say.md", "Say: {{ message }}")
    monkeypatch.chdir(tmp_path)

    rc = main(["render", "say", "--message", "hello world"])

    out = capsys.readouterr().out
    assert rc == 0
    assert "hello world" in out
