from __future__ import annotations

import pytest

from tmpt import Tmpt


class TestTmptMutateDict:
    def test_to_dict_returns_current_state(self, monkeypatch, tmp_path, write_file):
        write_file(tmp_path / "my_prompt.1.md", "v1")
        monkeypatch.chdir(tmp_path)
        Tmpt("./")

        tmpt = Tmpt["my_prompt"]

        state = tmpt.to_dict()

        assert state == {
            "id": "my_prompt.1",
            "template": "v1",
            "vars": {},
        }

    def test_from_dict_updates_state(self, monkeypatch, tmp_path, write_file):
        write_file(tmp_path / "my_prompt.1.md", "v1")
        write_file(tmp_path / "my_prompt.2.md", "v2")
        monkeypatch.chdir(tmp_path)
        Tmpt("./")

        tmpt = Tmpt["my_prompt"]
        returned = tmpt.update({"id": "my_prompt", "template": "v2"})

        assert returned is None
        assert tmpt.id == "my_prompt"
        assert tmpt.template == "v2"

    def test_from_dict_ignores_unknown_keys(self, monkeypatch, tmp_path, write_file):
        write_file(tmp_path / "my_prompt.1.md", "v1")
        monkeypatch.chdir(tmp_path)
        Tmpt("./")

        tmpt = Tmpt["my_prompt"]
        tmpt.update({"id": "my_prompt", "template": "v1", "unknown": "x"})

        assert tmpt.id == "my_prompt"
        assert tmpt.template == "v1"
        assert not hasattr(tmpt, "unknown")

    def test_from_dict_can_update_partial_state(
        self, monkeypatch, tmp_path, write_file
    ):
        write_file(tmp_path / "my_prompt.1.md", "v1")
        monkeypatch.chdir(tmp_path)
        Tmpt("./")

        tmpt = Tmpt["my_prompt"]
        tmpt.update({"template": "override"})

        assert tmpt.id == "my_prompt.1"
        assert tmpt.template == "override"

    def test_to_dict_from_dict_roundtrip(self, monkeypatch, tmp_path, write_file):
        write_file(tmp_path / "my_prompt.1.md", "v1")
        monkeypatch.chdir(tmp_path)
        Tmpt("./")

        source = Tmpt["my_prompt"]
        source.update({"template": "override"})

        clone = Tmpt["my_prompt"]
        clone.update(source.to_dict())

        assert clone.to_dict() == {
            "template": "override",
            "id": "my_prompt.1",
            "vars": {},
        }


def test_tmpt_v2_getitem_returns_tmpt_selected_context(
    monkeypatch, tmp_path, write_file
):
    write_file(tmp_path / "my_prompt.md", "v1")
    write_file(tmp_path / "my_prompt2.md", "v2")
    monkeypatch.chdir(tmp_path)

    Tmpt("./")  # load templates into the class registry
    selected = Tmpt["my_prompt"]

    assert isinstance(selected, Tmpt)
    assert selected == "v1"
    assert selected() == "v1"

    selected = Tmpt["my_prompt2"]

    assert isinstance(selected, Tmpt)
    assert selected == "v2"
    assert selected() == "v2"


def test_tmpt_v2_mutate_selects_variant_in_place(monkeypatch, tmp_path, write_file):
    write_file(tmp_path / "my_prompt.1.md", "v1")
    write_file(tmp_path / "my_prompt.2.md", "v2")
    monkeypatch.chdir(tmp_path)

    Tmpt["my_prompt.1"] = "v1"
    Tmpt["my_prompt.2"] = "v2"

    tmpt = Tmpt["my_prompt.1"]
    assert tmpt.id == "my_prompt.1"
    assert tmpt() == "v1"

    tmpt2 = Tmpt["my_prompt.2"]
    assert tmpt2.id == "my_prompt.2"
    assert tmpt2() == "v2"


def test_tmpt_v2_mutate_raises_for_unknown_selector(monkeypatch, tmp_path, write_file):
    write_file(tmp_path / "my_prompt.1.md", "v1")
    monkeypatch.chdir(tmp_path)

    with pytest.raises(KeyError):
        Tmpt["missing"]
