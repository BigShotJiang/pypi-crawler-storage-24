"""Tests for mtime-based load caching in TmptRegistry."""

from __future__ import annotations

import time
from pathlib import Path

import pytest

from tmpt import Tmpt
from tmpt.tmpt_data import TmptData
from tmpt.tmpt_registry import TmptRegistry

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_file(path: Path, content: str) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")
    return path


def _touch(path: Path, content: str) -> None:
    """Rewrite with new content and bump mtime past filesystem resolution."""
    time.sleep(0.01)
    path.write_text(content, encoding="utf-8")
    # Force a distinct mtime even on fast filesystems.
    stat = path.stat()
    new_mtime = stat.st_mtime + 1
    import os

    os.utime(path, (stat.st_atime, new_mtime))


# ---------------------------------------------------------------------------
# source_path / source_mtime populated by loader
# ---------------------------------------------------------------------------


class TestTmptDataFields:
    def test_source_path_set_after_load(self, tmp_path):
        f = _make_file(tmp_path / "hello.md", "Hello")
        reg = TmptRegistry()
        results = reg.load(f)
        assert results[0].source_path == f.resolve()

    def test_source_mtime_set_after_load(self, tmp_path):
        f = _make_file(tmp_path / "hello.md", "Hello")
        reg = TmptRegistry()
        results = reg.load(f)
        assert results[0].source_mtime == pytest.approx(f.stat().st_mtime)

    def test_inline_template_has_no_source_path(self):
        reg = TmptRegistry()
        reg.add(TmptData(id="inline", template="Hello"))
        entry = reg.get("inline")
        assert entry.source_path is None
        assert entry.source_mtime is None


# ---------------------------------------------------------------------------
# Unchanged file → no re-parse, same objects returned
# ---------------------------------------------------------------------------


class TestUnchangedFile:
    def test_second_load_returns_same_registry_entry(self, tmp_path):
        f = _make_file(tmp_path / "prompt.md", "First load")
        reg = TmptRegistry()
        first = reg.load(f)
        second = reg.load(f)
        assert second[0] is first[0]

    def test_registry_size_unchanged_on_second_load(self, tmp_path):
        f = _make_file(tmp_path / "prompt.md", "Content")
        reg = TmptRegistry()
        reg.load(f)
        reg.load(f)
        assert len(reg._registry) == 1

    def test_multi_variant_file_unchanged_returns_all_variants(self, tmp_path):
        f = _make_file(tmp_path / "multi.md", "One\n---\nTwo")
        reg = TmptRegistry()
        first = reg.load(f)
        assert len(first) == 2
        second = reg.load(f)
        ids = [d.id for d in second]
        assert "multi.1" in ids
        assert "multi.2" in ids
        assert len(second) == 2


# ---------------------------------------------------------------------------
# Modified file → re-parsed, new content registered, no duplicates
# ---------------------------------------------------------------------------


class TestModifiedFile:
    def test_modified_file_reloads_content(self, tmp_path):
        f = _make_file(tmp_path / "prompt.md", "Version 1")
        reg = TmptRegistry()
        reg.load(f)

        _touch(f, "Version 2")
        results = reg.load(f)

        assert results[0].template == "Version 2"

    def test_modified_file_does_not_duplicate_variants(self, tmp_path):
        f = _make_file(tmp_path / "prompt.md", "V1")
        reg = TmptRegistry()
        reg.load(f)

        _touch(f, "V2")
        reg.load(f)

        assert len(reg._registry) == 1

    def test_modified_file_updates_mtime_in_registry(self, tmp_path):
        f = _make_file(tmp_path / "prompt.md", "V1")
        reg = TmptRegistry()
        reg.load(f)
        old_mtime = reg.get("prompt").source_mtime

        _touch(f, "V2")
        reg.load(f)

        assert reg.get("prompt").source_mtime != old_mtime


# ---------------------------------------------------------------------------
# Multiple files — only modified ones are re-parsed
# ---------------------------------------------------------------------------


class TestMultipleFiles:
    def test_unmodified_sibling_not_re_parsed(self, tmp_path):
        a = _make_file(tmp_path / "a.md", "A content")
        b = _make_file(tmp_path / "b.md", "B content")
        reg = TmptRegistry()
        reg.load(a)
        reg.load(b)

        entry_a_before = reg.get("a")

        _touch(b, "B updated")
        reg.load(a)
        reg.load(b)

        # a's registry object is the same (unchanged)
        assert reg.get("a") is entry_a_before
        # b has new content
        assert reg.get("b").template == "B updated"

    def test_inline_entries_survive_file_reload(self, tmp_path):
        _make_file(tmp_path / "prompt.md", "File content")
        reg = TmptRegistry()
        reg.load(tmp_path)
        reg.add(TmptData(id="inline", template="Inline"))

        reg.load(tmp_path)  # file unchanged

        assert reg.get("inline").template == "Inline"


# ---------------------------------------------------------------------------
# clear() resets cache so next load always re-parses
# ---------------------------------------------------------------------------


class TestClearResetsCache:
    def test_after_clear_same_file_reloaded(self, tmp_path):
        f = _make_file(tmp_path / "prompt.md", "Original")
        reg = TmptRegistry()
        first = reg.load(f)

        reg.clear()
        second = reg.load(f)

        # New objects after clear
        assert second[0] is not first[0]
        assert second[0].template == "Original"


# ---------------------------------------------------------------------------
# Tmpt.is_stale()
# ---------------------------------------------------------------------------


class TestTmptIsStale:
    def test_not_stale_after_load(self, tmp_path):
        f = _make_file(tmp_path / "prompt.md", "Hello")
        t = Tmpt(f)
        assert not t.is_stale()

    def test_stale_after_file_modified(self, tmp_path):
        f = _make_file(tmp_path / "prompt.md", "V1")
        t = Tmpt(f)
        _touch(f, "V2")
        assert t.is_stale()

    def test_stale_after_file_deleted(self, tmp_path):
        f = _make_file(tmp_path / "prompt.md", "Hello")
        t = Tmpt(f)
        f.unlink()
        with pytest.raises(FileNotFoundError):
            t.is_stale()

    def test_inline_template_never_stale(self):
        t = Tmpt(template="Hello {{ name }}")
        assert not t.is_stale()

    def test_not_stale_after_reload(self, tmp_path):
        f = _make_file(tmp_path / "prompt.md", "V1")
        t = Tmpt(f)
        _touch(f, "V2")
        t2 = Tmpt(f)
        assert not t2.is_stale()

    def test_source_path_set_on_instance(self, tmp_path):
        f = _make_file(tmp_path / "prompt.md", "Hello")
        t = Tmpt(f)
        assert t.source_path == f.resolve()

    def test_source_mtime_set_on_instance(self, tmp_path):
        f = _make_file(tmp_path / "prompt.md", "Hello")
        t = Tmpt(f)
        import pytest

        assert t.source_mtime == pytest.approx(f.stat().st_mtime)

    def test_get_preserves_source_path(self, tmp_path):
        f = _make_file(tmp_path / "prompt.md", "Hello")
        Tmpt(f)
        t = Tmpt.get("prompt")
        assert t.source_path == f.resolve()
        assert not t.is_stale()
