from __future__ import annotations

import pytest

from tmpt import Tmpt
from tmpt.tmpt_data import TmptData
from tmpt.tmpt_registry import TmptRegistry


class TestTmptDataHistory:
    def test_history_empty_by_default(self):
        data = TmptData(template="hello")
        assert data.history == []

    def test_history_excluded_from_equality(self):
        a = TmptData(template="hello", history=[("frontmatter", {"x": "1"})])
        b = TmptData(template="hello", history=[])
        assert a == b

    def test_history_excluded_from_repr(self):
        data = TmptData(template="hi", history=[("frontmatter", {"k": "v"})])
        assert "history" not in repr(data)


class TestLoaderHistory:
    def test_no_frontmatter_produces_empty_history(self):
        registry = TmptRegistry()
        [data] = registry.load("Hello {{ name }}")
        assert data.history == []

    def test_frontmatter_vars_recorded_in_history(self, tmp_path, write_file):
        write_file(tmp_path / "greet.md", "---\ntopic: hello\n---\nBody {{ name }}")
        registry = TmptRegistry()
        [data] = registry.load(tmp_path / "greet.md")
        assert len(data.history) == 1
        label, vars_dict = data.history[0]
        assert label == "frontmatter"
        assert vars_dict == {"topic": "hello"}

    def test_frontmatter_history_is_a_copy(self, tmp_path, write_file):
        write_file(tmp_path / "greet.md", "---\ntopic: hello\n---\nBody")
        registry = TmptRegistry()
        [data] = registry.load(tmp_path / "greet.md")
        _, recorded = data.history[0]
        recorded["topic"] = "mutated"
        assert data.vars["topic"] == "hello"

    def test_no_frontmatter_file_produces_no_history(self, tmp_path, write_file):
        write_file(tmp_path / "greet.md", "Body with no frontmatter block")
        registry = TmptRegistry()
        [data] = registry.load(tmp_path / "greet.md")
        assert data.history == []


class TestTmptInstanceHistory:
    def test_from_data_copies_history(self, tmp_path, write_file):
        write_file(tmp_path / "greet.md", "---\ntopic: x\n---\nHello")
        registry = TmptRegistry()
        [data] = registry.load(tmp_path / "greet.md")
        t = Tmpt.from_data(data)
        assert t.history == [("frontmatter", {"topic": "x"})]

    def test_init_with_source_copies_history(self, monkeypatch, tmp_path, write_file):
        write_file(tmp_path / "greet.md", "---\ntopic: x\n---\nHello")
        monkeypatch.chdir(tmp_path)
        t = Tmpt("greet.md")
        assert t.history == [("frontmatter", {"topic": "x"})]

    def test_init_without_source_has_empty_history(self):
        t = Tmpt(template="Hello")
        assert t.history == []

    def test_call_appends_call_entry(self, tmp_path, write_file):
        write_file(tmp_path / "greet.md", "---\ntopic: x\n---\nHello {{ name }}")
        registry = TmptRegistry()
        [data] = registry.load(tmp_path / "greet.md")
        t = Tmpt.from_data(data)
        t(name="Michal")
        # history on the instance is not mutated — it remains as loaded
        assert t.history == [("frontmatter", {"topic": "x"})]

    def test_call_history_passed_to_pipeline(self, tmp_path, write_file):
        """The TmptData fed into the pipeline carries both frontmatter + call entries."""
        write_file(tmp_path / "greet.md", "---\ntopic: x\n---\nHello {{ name }}")
        registry = TmptRegistry()
        [data] = registry.load(tmp_path / "greet.md")

        captured: list[TmptData] = []

        class CapturingRenderer(Tmpt):
            pass

        from tmpt.render.base import RendererBase
        from tmpt.render.context import RenderContext
        from tmpt.render.pipeline import PipelineRenderer

        class Capture(RendererBase):
            def render(self, d: TmptData, ctx: RenderContext | None = None) -> str:
                captured.append(d)
                return d.template or ""

        CapturingRenderer.pipeline = PipelineRenderer([Capture()])
        t = CapturingRenderer.from_data(data)
        t(name="Michal", topic="override")

        assert len(captured) == 1
        h = captured[0].history
        assert ("frontmatter", {"topic": "x"}) in h
        assert ("call", {"name": "Michal", "topic": "override"}) in h

    def test_call_without_vars_no_call_entry(self, tmp_path, write_file):
        """If __call__ receives no vars, no 'call' entry is added."""
        write_file(tmp_path / "greet.md", "---\ntopic: x\n---\nHello")
        registry = TmptRegistry()
        [data] = registry.load(tmp_path / "greet.md")

        captured: list[TmptData] = []
        from tmpt.render.base import RendererBase
        from tmpt.render.context import RenderContext
        from tmpt.render.pipeline import PipelineRenderer

        class Capture(RendererBase):
            def render(self, d: TmptData, ctx: RenderContext | None = None) -> str:
                captured.append(d)
                return d.template or ""

        class T(Tmpt):
            pass

        T.pipeline = PipelineRenderer([Capture()])
        t = T.from_data(data)
        t()

        h = captured[0].history
        labels = [label for label, _ in h]
        assert "call" not in labels

    def test_call_history_is_not_mutated_between_calls(self, tmp_path, write_file):
        write_file(tmp_path / "greet.md", "---\ntopic: x\n---\nHello {{ name }}")
        registry = TmptRegistry()
        [data] = registry.load(tmp_path / "greet.md")
        t = Tmpt.from_data(data)
        t(name="first")
        t(name="second")
        # original instance history unchanged
        assert t.history == [("frontmatter", {"topic": "x"})]
