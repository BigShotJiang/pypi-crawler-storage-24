from __future__ import annotations

from pathlib import Path

import pytest

from tmpt import Tmpt
from tmpt.exceptions import (
    TmptNotFoundError,
    TmptSourceParseError,
    TmptValidationError,
)


def test_tmpt_features_init_prompt_in_code():
    t = Tmpt("Exemplary prompt content")
    assert t() == "Exemplary prompt content"

    t = Tmpt("My name is {{name}}")
    assert t(name="Alice") == "My name is Alice"

    Tmpt["my_prompt"] = "Hello {{ name }}"
    assert Tmpt["my_prompt"](name="Bob") == "Hello Bob"

    t = Tmpt["my_prompt"]
    assert t(name="Charlie") == "Hello Charlie"

    t = Tmpt("My name is {{ name: Bob }}")
    assert t() == "My name is Bob"
    assert t(name="Alice") == "My name is Alice"

    t = Tmpt("My name is {{name}}", name="Alice")
    assert t() == "My name is Alice"
    assert t(name="Bob") == "My name is Bob"

    t = Tmpt("My name is {{name: Bob}}", name="Alice")
    assert t() == "My name is Alice"
    assert t(name="Alice") == "My name is Alice"

    print(Tmpt.list())


def test_tmpt_features_init_prompt_in_file(prepare_file):
    prepare_file("test_prompt.md", "My name is {{name}}")
    t = Tmpt("test_prompt.md")
    assert t() == "My name is {{name}}"

    t = Tmpt("test_prompt.md")
    assert t(name="Alice") == "My name is Alice"

    assert Tmpt["test_prompt.md"](name="Bob") == "My name is Bob"

    t = Tmpt["test_prompt.md"]
    assert t(name="Charlie") == "My name is Charlie"

    t = Tmpt("test_prompt.md", name="Alice")
    assert t() == "My name is Alice"
    assert t(name="Bob") == "My name is Bob"

    t = Tmpt("test_prompt.md", name="Alice")
    assert t() == "My name is Alice"
    assert t(name="Alice") == "My name is Alice"
    # # Test that invalid source raises TmptSourceParseError
    # with pytest.raises(TmptSourceParseError):
    #     Tmpt(source="invalid source")

    # # Test that non-string, non-TmptData source raises TmptValidationError
    # with pytest.raises(TmptValidationError):
    #     Tmpt(source=123)

    # # Test that valid source is loaded and registered correctly
    # test_content = "Test prompt content"
    # test_file = prepare_file("test_prompt.md", test_content)
    # tmpt = Tmpt(source=str(test_file))
    # assert tmpt.id == "test_prompt"
    # assert tmpt.content == test_content
    # assert "test_prompt" in Tmpt.list()
