from __future__ import annotations

import pytest

from tmpt.loaders import frontmatter_content_to_dict

# Test cases for frontmatter_content_to_dict
frontmatter_dict_cases = (
    # (input_content, expected_dict)
    ("name: John\nage: 30", {"name": "John", "age": 30}),
    (
        "name:   John Doe   \nage:  30  ",
        {"name": "John Doe", "age": 30},
    ),
    ("", {}),
    ("   \n  \n  ", {}),
    ("invalid line\nanother invalid line", {}),
    (
        "// This is a comment\nname: John\n// Another comment\nage: 30",
        {"name": "John", "age": 30},
    ),
    ("name: John\n\nage: 30\n\n", {"name": "John", "age": 30}),
    (
        "url: https://example.com\ntime: 10:30:45",
        {"url": "https://example.com", "time": "10:30:45"},
    ),
    (
        "email: test@example.com\ntags: python, testing, #code",
        {"email": "test@example.com", "tags": "python, testing, #code"},
    ),
    (
        "version: 1.0\ncount: 42\nactive: True",
        {"version": 1.0, "count": 42, "active": True},
    ),
    ("name: \nempty_key:", {"name": "", "empty_key": ""}),
    ("name: John\r\nage: 30", {"name": "John", "age": 30}),
)


class TestFrontmatterContentToDict:
    """Tests for the frontmatter_content_to_dict function."""

    @pytest.mark.parametrize("input_content, expected_dict", frontmatter_dict_cases)
    def test_frontmatter_content_to_dict(self, input_content, expected_dict):
        """Test frontmatter_content_to_dict with various inputs."""
        result = frontmatter_content_to_dict(input_content)
        assert result == expected_dict

    def test_frontmatter_content_to_dict_preserves_keys_without_stripping(self):
        """Test that keys are not stripped of whitespace."""
        content = "   name: John\nage: 30"

        result = frontmatter_content_to_dict(content)

        assert "   name" in result or "name" in result

    def test_frontmatter_content_to_dict_handles_multiline_with_mixed_content(self):
        """Test parsing with mixed valid and invalid lines."""
        content = """name: John
email: john@example.com
// Comment line
age: 30

type: user"""

        result = frontmatter_content_to_dict(content)

        assert result == {
            "name": "John",
            "email": "john@example.com",
            "age": 30,
            "type": "user",
        }

    def test_frontmatter_content_to_dict_returns_dict_not_none(self):
        """Test that function returns dict (empty or populated), never None."""
        result1 = frontmatter_content_to_dict("")
        result2 = frontmatter_content_to_dict("name: value")
        result3 = frontmatter_content_to_dict("// comment only")

        assert isinstance(result1, dict)
        assert isinstance(result2, dict)
        assert isinstance(result3, dict)

    def test_frontmatter_content_to_dict_overwrites_duplicate_keys(self):
        """Test that duplicate keys use the last value."""
        content = "name: John\nname: Jane"

        result = frontmatter_content_to_dict(content)

        assert result["name"] == "Jane"

    def test_frontmatter_content_to_dict_mixed_line_endings(self):
        """Test parsing with mixed line endings."""
        content = "name: John\r\nage: 30\nemail: john@example.com"

        result = frontmatter_content_to_dict(content)

        assert result == {"name": "John", "age": 30, "email": "john@example.com"}
