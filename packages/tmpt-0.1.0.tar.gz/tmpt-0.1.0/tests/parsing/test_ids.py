from __future__ import annotations

import pytest

from tmpt.exceptions import TmptValidationError
from tmpt.tmpt_ref import TmptRef

id_test_cases = (
    (
        "prompt",
        TmptRef("prompt", None),
        "prompt.1",
        "prompt.2",
    ),
    (
        "prompt.md",
        TmptRef("prompt", None),
        "prompt.1",
        "prompt.2",
    ),
    (
        "prompt.my.md",
        TmptRef("prompt.my", None),
        "prompt.my.1",
        "prompt.my.2",
    ),
    (
        "prompt.my.2.md",
        TmptRef("prompt.my", 2),
        "prompt.my.2",
        "prompt.my.3",
    ),
    (
        "foo.bar.md",
        TmptRef("foo.bar", None),
        "foo.bar.1",
        "foo.bar.2",
    ),
    (
        "foo.bar.3.md",
        TmptRef("foo.bar", 3),
        "foo.bar.3",
        "foo.bar.4",
    ),
    (
        "path/prompt.md",
        TmptRef("prompt"),
        "prompt.1",
        "prompt.2",
    ),
    (
        "prompt.2",
        TmptRef("prompt", 2),
        "prompt.2",
        "prompt.3",
    ),
    (
        "prompt.2.md",
        TmptRef("prompt", 2),
        "prompt.2",
        "prompt.3",
    ),
    (
        "_prompt.2.md",
        TmptRef("_prompt", 2),
        "_prompt.2",
        "_prompt.3",
    ),
    (
        "path/to/prompt.2.md",
        TmptRef("prompt", 2),
        "prompt.2",
        "prompt.3",
    ),
    (
        "prompt.1",
        TmptRef("prompt", 1),
        "prompt.1",
        "prompt.2",
    ),
    (
        "prompt.99999",
        TmptRef("prompt", 99999),
        "prompt.99999",
        "prompt.100000",
    ),
    (
        "my-prompt.md",
        TmptRef("my-prompt", None),
        "my-prompt.1",
        "my-prompt.2",
    ),
    (
        "my_prompt.md",
        TmptRef("my_prompt", None),
        "my_prompt.1",
        "my_prompt.2",
    ),
    (
        "prompt2.md",
        TmptRef("prompt2", None),
        "prompt2.1",
        "prompt2.2",
    ),
    (
        "prompt.MD",
        TmptRef("prompt", None),
        "prompt.1",
        "prompt.2",
    ),
    (
        "path/to/nested/prompt.2.md",
        TmptRef(
            "prompt",
            2,
        ),
        "prompt.2",
        "prompt.3",
    ),
    (
        "prompt.5",
        TmptRef(
            "prompt",
            5,
        ),
        "prompt.5",
        "prompt.6",
    ),
    (
        "prompt.10",
        TmptRef(
            "prompt",
            10,
        ),
        "prompt.10",
        "prompt.11",
    ),
    (
        "prompt.10.md",
        TmptRef(
            "prompt",
            10,
        ),
        "prompt.10",
        "prompt.11",
    ),
    (
        "a.md",
        TmptRef(
            "a",
            None,
        ),
        "a.1",
        "a.2",
    ),
    (
        "path.old/prompt.2.md",
        TmptRef(
            "prompt",
            2,
        ),
        "prompt.2",
        "prompt.3",
    ),
    (
        "_local",
        TmptRef(
            "_local",
            None,
        ),
        "_local.1",
        "_local.2",
    ),
    (
        "_local.1",
        TmptRef("_local", 1),
        "_local.1",
        "_local.2",
    ),
    (
        "_local.3",
        TmptRef(
            "_local",
            3,
        ),
        "_local.3",
        "_local.4",
    ),
)

invalid_id_test_cases = (
    "prompt.01",
    "prompt.01.md",
    "prompt.2.5",
    "5",
    "5.md",
    "2.5",
    ".2.5",
    ".5",
    "",
    "prompt.100000",
    "prompt.0",
    "prompt.-1",
    "prompt.+1",
    "   ",
    "prompt@test",
    "my prompt.md",
)


@pytest.mark.parametrize("source, expected, resolved, resolved_next", id_test_cases)
def test_tmpt_ref_from_string_valid(source, expected, resolved, resolved_next):
    result = TmptRef.from_string(source)
    assert result == expected
    assert str(result) == (
        f"{result.name}.{result.variant}" if result.variant is not None else result.name
    )
    assert str(result.next([resolved])) == resolved_next


@pytest.mark.parametrize("source", invalid_id_test_cases)
def test_tmpt_ref_from_string_invalid(source):
    with pytest.raises(TmptValidationError):
        TmptRef.from_string(source)


class TestGetNextVariant:
    """Tests for TmptRef.next() method."""

    @pytest.mark.parametrize(
        "source, _expected, resolved, resolved_next", id_test_cases
    )
    def test_next_from_cases(self, source, _expected, resolved, resolved_next):
        """Test next() returns correct next variant based on existing IDs."""
        result = TmptRef.from_string(source)
        assert str(result.next([resolved])) == resolved_next

    def test_next_with_empty_existing_ids(self):
        """When no existing IDs, should return 'name.1' or use imposed variant."""
        assert str(TmptRef.from_string("prompt").next([])) == "prompt.1"
        assert str(TmptRef.from_string("prompt.5").next([])) == "prompt.5"

    def test_next_with_multiple_variants(self):
        """When multiple variants exist, should return max+1."""
        existing = ["prompt.1", "prompt.2", "prompt.5"]
        assert str(TmptRef.from_string("prompt").next(existing)) == "prompt.6"
        existing = ["prompt.2", "prompt.5"]
        assert str(TmptRef.from_string("prompt").next(existing)) == "prompt.6"

    def test_next_with_gaps_in_variants(self):
        """When variants have gaps, should use max+1."""
        existing = ["prompt.1", "prompt.10", "prompt.5"]
        assert str(TmptRef.from_string("prompt").next(existing)) == "prompt.11"

    def test_next_with_mixed_ids(self):
        """Should only count variants for matching base name."""
        existing = ["prompt.1", "other.1", "prompt.2", "another.5"]
        assert str(TmptRef.from_string("prompt").next(existing)) == "prompt.3"
        assert str(TmptRef.from_string("other").next(existing)) == "other.2"

    def test_next_with_similar_names(self):
        """Should only match exact base name, not similar prefixes."""
        existing = ["prompt.1", "prompt2.1", "promptx.1"]
        assert str(TmptRef.from_string("prompt").next(existing)) == "prompt.2"
