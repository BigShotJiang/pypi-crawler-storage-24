from __future__ import annotations

import pytest

from tmpt.loaders import load_str

# Test cases for frontmatter parsing
load_str_frontmatter_cases = (
    # (input_str, expected_vars, expected_templates)
    (
        "---\nname: test_template\nversion: 1.0\n---\nTemplate content",
        {"name": "test_template", "version": 1.0},
        ["Template content"],
    ),
    (
        "---\nauthor: John Doe\ncategory: test\n---\nFirst template\n---\nSecond template",
        {"author": "John Doe", "category": "test"},
        ["First template", "Second template"],
    ),
    (
        "---\n// This is a comment\nname: test\n// Another comment\ntype: example\n---\nContent",
        {"name": "test", "type": "example"},
        ["Content"],
    ),
    (
        "---\nname: test\n\ntype: example\n---\nContent",
        {"name": "test", "type": "example"},
        ["Content"],
    ),
    (
        "---\nurl: https://example.com\ntime: 10:30:45\n---\nContent",
        {"url": "https://example.com", "time": "10:30:45"},
        ["Content"],
    ),
    (
        "---\nname:   test with spaces   \nvalue:     123     \n---\nContent",
        {"name": "test with spaces", "value": 123},
        ["Content"],
    ),
    (
        "---\ntitle: Multi-line Test\n---\nLine 1\nLine 2\nLine 3",
        {"title": "Multi-line Test"},
        ["Line 1\nLine 2\nLine 3"],
    ),
)


class TestLoadStrFrontmatter:
    """Tests for frontmatter parsing in load_str."""

    @pytest.mark.parametrize(
        "input_str, expected_vars, expected_templates",
        load_str_frontmatter_cases,
    )
    def test_load_str_frontmatter(self, input_str, expected_vars, expected_templates):
        """Test frontmatter parsing in load_str."""
        loaded = list(load_str(input_str))

        assert len(loaded) == len(expected_templates)
        for item in loaded:
            assert item.vars == expected_vars

        for i, item in enumerate(loaded):
            assert item.template.strip() == expected_templates[i]

    def test_load_str_without_frontmatter_has_empty_vars(self):
        """Test that templates without frontmatter have empty vars dict."""
        loaded = list(load_str("Simple template"))

        assert loaded[0].vars == {} or loaded[0].vars is None

    def test_load_str_invalid_frontmatter_line_is_skipped(self):
        """Test that invalid frontmatter lines (missing colons) are skipped; valid lines are kept."""
        template_str = """---
invalid line without colon
name: test
---
Content"""

        loaded = list(load_str(template_str))

        # Invalid line is skipped; the valid 'name: test' line is still parsed
        assert len(loaded) == 1
        assert loaded[0].vars == {"name": "test"}

    def test_load_str_frontmatter_only_no_template(self):
        """Test handling of frontmatter with no template content."""
        template_str = """---
name: test
---"""

        loaded = list(load_str(template_str))

        # Should not yield anything if there's no content after frontmatter
        assert len(loaded) == 0

    def test_load_str_vars_attribute_exists(self):
        """Test that vars attribute is always present on TmptData."""
        loaded = list(load_str("Test"))

        assert hasattr(loaded[0], "vars")
        assert isinstance(loaded[0].vars, dict) or loaded[0].vars is None
