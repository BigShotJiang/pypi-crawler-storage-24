from __future__ import annotations

import pytest

from tmpt.loaders import load_str

# Test cases for basic load_str functionality
load_str_basic_cases = (
    # (input_str, expected_count)
    ("Hello world", 1),
    ("First\n---\nSecond\n---\nThird", 3),
    ("First\n---\n---\nSecond\n", 2),
    ("", 1),
    ("---", 0),
    ("   \n  \n  ", 1),
    ("Line 1\nLine 2\nLine 3", 1),
    ("First\n  ---  \nSecond", 2),
    ("First\n---\n---\n---\nSecond", 2),
    ("Before\n---\nAfter", 2),
    ("Text with --- in the middle", 1),
)


class TestLoadStr:
    """Tests for load_str function."""

    @pytest.mark.parametrize("input_str, expected_count", load_str_basic_cases)
    def test_load_str_basic(self, input_str, expected_count):
        """Test basic load_str functionality."""
        loaded = list(load_str(input_str))
        assert len(loaded) == expected_count

    def test_load_str_preserves_trailing_newlines_in_sections(self):
        loaded = list(load_str("First\n\n---\nSecond\n\n"))

        assert len(loaded) == 2
        assert loaded[0].template == "First\n"
        assert loaded[1].template == "Second\n\n"

    def test_load_str_handles_template_with_code_blocks(self):
        template = """```python
def hello():
    print("world")
```"""

        loaded = list(load_str(template))

        assert len(loaded) == 1
        assert "def hello():" in loaded[0].template

    def test_load_str_handles_mixed_content_with_special_chars(self):
        loaded = list(load_str("Template with @#$%\n---\nAnother template!"))

        assert len(loaded) == 2
        assert "Template with @#$%\n" == loaded[0].template
        assert "Another template!" == loaded[1].template

    def test_load_str_sets_id_to_none(self):
        loaded = list(load_str("Template"))

        assert loaded[0].id == "_local"

    def test_load_str_no_frontmatter_multiple_templates(self):
        """Test multiple templates without frontmatter."""
        template_str = """First template
---
Second template
---
Third template"""

        loaded = list(load_str(template_str))

        assert len(loaded) == 3
        for item in loaded:
            assert item.vars == {} or item.vars is None
