from __future__ import annotations

from pathlib import Path

import pytest

from tmpt import Tmpt
from tmpt.exceptions import (
    TmptNotFoundError,
    TmptSourceParseError,
    TmptValidationError,
)

# Test cases for simple initialization
simple_init_cases = (
    # (source, kwargs, expected_template_snippet, description)
    (None, {}, None, "default init"),
    ("Hello", {}, "Hello", "string source"),
    (None, {"source": "Hello"}, "Hello", "kw source"),
    (None, {"source": "Hello", "var1": "test"}, "Hello", "kw source with vars"),
    ("Hello", {"var1": "test"}, "Hello", "with vars"),
)

# Test cases for resolve_id normalization
resolve_id_cases = (
    # (input_id, expected_output)
    (None, "_local"),
    ("", "_local"),
    ("   ", "_local"),
    ("my_prompt", "my_prompt.1"),
    ("my_prompt.md", "my_prompt.1"),
    ("something/my_prompt.md", "my_prompt.1"),
    ("something/my_prompt.2.md", "my_prompt.2"),
    ("  my_prompt", "my_prompt.1"),
    ("my_prompt  ", "my_prompt.1"),
    ("  my_prompt  ", "my_prompt.1"),
    ("my_prompt_name", "my_prompt_name.1"),
    ("my-prompt-name", "my-prompt-name.1"),
    ("prompt123", "prompt123.1"),
    ("prompt.1.md", "prompt.1"),
    ("prompt.1", "prompt.1"),
    ("prompt.MD", "prompt.1"),
    ("folder.md/prompt.md", "prompt.1"),
)


class TestTmptSimpleInit:
    @pytest.mark.parametrize(
        "source, kwargs, expected_template, description",
        [
            (None, {}, None, "default init"),
            ("Hello", {}, "Hello", "string source"),
        ],
    )
    def test_tmpt_init_basic(self, source, kwargs, expected_template, description):
        """Test basic Tmpt initialization."""
        if source is None:
            t = Tmpt(**kwargs)
        else:
            t = Tmpt(source, **kwargs)

        if expected_template is not None:
            assert t.template == expected_template

    def test_tmpt_init_with_vars_not_kw(self):
        with pytest.raises(TypeError):
            t = Tmpt("Hello", "test")

    def test_tmpt_init_with_empty_string(self):
        """Test initializing with empty string."""
        t = Tmpt("")
        assert Tmpt["_local.1"].template == ""
        assert Tmpt["_local"].template == ""
        assert t.template == ""

    def test_tmpt_init_with_whitespace_only(self):
        """Test initializing with whitespace-only string."""
        t = Tmpt("   \n\t  ")
        # Whitespace-only strings might be treated as empty
        assert t.template == "   \n\t  "
        assert Tmpt["_local.1"].template == "   \n\t  "

    def test_tmpt_init_with_newlines(self):
        """Test initializing with multiline string."""
        content = "Line 1\nLine 2\nLine 3"
        t = Tmpt(content)
        assert Tmpt["_local"].template == content
        assert t.template == content

    def test_tmpt_init_with_unicode(self):
        """Test initializing with unicode content."""
        content = "Hello 世界 🌍 émoji"
        t = Tmpt(content)
        assert Tmpt["_local"].template == content

    def test_tmpt_init_with_special_chars(self):
        """Test initializing with special characters."""
        content = "Test {{ var }} with $pecial #chars @nd more!"
        t = Tmpt(content)
        assert Tmpt["_local"].template == content

    def test_tmpt_init_with_very_long_string(self):
        """Test initializing with a very long string."""
        content = "x" * 100000
        t = Tmpt(content)
        assert len(t.template) == 100000

    def test_tmpt_init_with_path_object_string_like(self):
        """Test that string ending with .md triggers file loading."""
        # This should try to load a file, not treat as string
        with pytest.raises(TmptSourceParseError, match="Path does not exist"):
            t = Tmpt("nonexistent.md")

    def test_tmpt_init_with_path_object_dir_like(self):
        """Test that string ending with / triggers directory loading."""
        with pytest.raises(TmptSourceParseError, match="Path does not exist"):
            t = Tmpt("nonexistent/")

    def test_tmpt_init_default_loads_cwd(self):
        """Test that default init loads current directory."""
        t = Tmpt()
        # Should scan cwd for .md files
        assert isinstance(Tmpt.registry._registry, dict)

    def test_tmpt_init_with_none_source(self):
        """Test explicit None source (should load cwd)."""
        t = Tmpt(source=None)
        assert isinstance(Tmpt.registry._registry, dict)

    def test_tmpt_init_multiple_instances_independence(self):
        """Test that multiple instances are independent."""
        t1 = Tmpt("Content 1")
        t2 = Tmpt("Content 2")

        assert t1.template == "Content 1"
        assert t2.template == "Content 2"
        assert t1.__class__.registry is t2.__class__.registry


class TestTmptSourceParse:
    def test_load_str(self):
        t = Tmpt("Hello")
        assert Tmpt["_local"].template == "Hello"
        assert Tmpt["_local.1"].template == "Hello"

    def test_load_str_multiple_instances(self):
        """Test that multiple string loads create independent instances."""
        t = Tmpt("Hello")
        assert Tmpt["_local"].template == "Hello"

        t2 = Tmpt("Hello2")
        assert Tmpt["_local"].template == "Hello2"

    def test_source_empty_empty_dir(self):
        t = Tmpt(Path(__file__).parent)
        assert Tmpt.registry._registry == {}
        with pytest.raises(KeyError):
            assert Tmpt["_local"]

    def test_load_str_preserves_whitespace(self):
        """Test that loading string preserves all whitespace."""
        content = "  leading\n  indented\n    more  "
        t = Tmpt(content)
        assert t.template == content

    def test_load_str_with_template_syntax(self):
        """Test loading string with template variables."""
        content = "Hello {{ name }}, welcome to {{ place }}!"
        t = Tmpt(content)
        assert t.template == content

    def test_load_str_multiple_times_overwrites(self):
        """Test that loading same ID multiple times overwrites."""
        t1 = Tmpt("First")
        t2 = Tmpt("Second")
        # Each creates new instance, so both should have their own content
        assert t1.template == "First"
        assert t2.template == "Second"

    def test_load_str_with_json_like_content(self):
        """Test loading string with JSON-like content."""
        content = '{"key": "value", "nested": {"data": 123}}'
        t = Tmpt(content)
        assert t.template == content

    def test_load_str_with_markdown_content(self):
        """Test loading string with markdown content."""
        content = "# Title\n\n## Subtitle\n\n- Item 1\n- Item 2"
        t = Tmpt(content)
        assert t.template == content

    def test_load_str_with_yaml_frontmatter_like(self):
        """Test loading string with YAML frontmatter-like content."""
        content = "---\ntitle: Test\n---\nContent here"
        t = Tmpt(content)
        # Frontmatter is parsed, so template only contains content after ---
        assert t.template == "Content here"
        assert t.vars.get("title") == "Test"

    def test_load_path_object_nonexistent(self):
        """Test loading non-existent path object raises error."""
        with pytest.raises(TmptSourceParseError, match="Path does not exist"):
            t = Tmpt(Path("nonexistent_path.md"))

    # def test_load_invalid_source_type(self):
    #     """Test that invalid source types are handled."""
    #     with pytest.raises(
    #         (ValueError, AttributeError, TypeError, TmptSourceParseError)
    #     ):
    #         t = Tmpt(source=123)

    def test_load_str_empty_registry_for_dir_without_md_files(self):
        """Test that directory without .md files results in empty registry."""
        t = Tmpt(Path(__file__).parent)
        # The test directory might have .md files, so check it loads
        assert isinstance(Tmpt.registry._registry, dict)


class TestTmptSourceParseFile:
    def test_load_file(self, prepare_file):
        prepare_file("prompt.md", "File content")
        t = Tmpt("prompt.md")
        assert Tmpt["prompt"].template == "File content"
        assert t.id == "prompt.1"
        assert t.template == "File content"
        assert t() == "File content"

    def test_load_file_rel_path(self, prepare_file):
        prepare_file("prompt.md", "File content")
        t = Tmpt("./prompt.md")
        assert Tmpt["prompt"].template == "File content"

    def test_load_file_path(self, prepare_file):
        prepare_file("prompts/prompt.md", "File content")
        Tmpt("./")
        assert Tmpt["prompt"].template == "File content"

    def test_load_file_conflict_path_vs_set(self, prepare_file):
        prepare_file("prompt.md", "File content2")
        t = Tmpt("prompt.md")
        Tmpt["prompt"] = Tmpt("File content")

        assert Tmpt["prompt"].template == "File content"

    def test_load_file_empty(self, prepare_file):
        """Test loading empty file."""
        prepare_file("empty.md", "")
        t = Tmpt("empty.md")
        assert t.template == ""

    def test_load_file_whitespace_only(self, prepare_file):
        """Test loading file with only whitespace."""
        prepare_file("whitespace.md", "   \n\t\n   ")
        t = Tmpt("whitespace.md")
        assert t.template == "   \n\t\n   "

    def test_load_file_with_unicode(self, prepare_file):
        """Test loading file with unicode content."""
        content = "Unicode: 你好世界 🌍 émojis ñ"
        prepare_file("unicode.md", content)
        t = Tmpt("unicode.md")
        assert t.template == content

    def test_load_file_with_very_long_content(self, prepare_file):
        """Test loading file with very long content."""
        content = "x" * 50000
        prepare_file("long.md", content)
        t = Tmpt("long.md")
        assert len(t.template) == 50000

    def test_load_file_multiline(self, prepare_file):
        """Test loading multiline file."""
        content = "Line 1\nLine 2\nLine 3\n"
        prepare_file("multiline.md", content)
        t = Tmpt("multiline.md")
        assert t.template == content

    def test_load_file_with_template_syntax(self, prepare_file):
        """Test loading file containing template syntax."""
        content = "Hello {{ name }}\n\nWelcome to {{ place }}!"
        prepare_file("template.md", content)
        t = Tmpt("template.md")
        assert t.template == content

    def test_load_file_nonexistent(self):
        """Test loading non-existent file raises error."""
        with pytest.raises(TmptSourceParseError, match="Path does not exist"):
            t = Tmpt("nonexistent_file.md")

    def test_load_file_path_object(self, prepare_file):
        """Test loading file using Path object."""
        prepare_file("pathobj.md", "Path object content")
        t = Tmpt(Path("pathobj.md"))
        assert t.template == "Path object content"

    def test_load_file_with_special_chars_in_name(self, prepare_file):
        """Test loading file with special characters in name."""
        prepare_file("special-name_123.md", "Special content")
        t = Tmpt("special-name_123.md")
        assert t.id == "special-name_123.1"
        assert t.template == "Special content"

    def test_load_file_nested_path(self, prepare_file):
        """Test loading file from nested directory."""
        prepare_file("deep/nested/path/file.md", "Nested content")
        t = Tmpt("deep/nested/path/file.md")
        assert t.template == "Nested content"

    def test_load_file_with_dots_in_name(self, prepare_file):
        """Test loading file with dots in name (variant-like)."""
        prepare_file("prompt.version.2.md", "Dotted content")
        t = Tmpt("prompt.version.2.md")
        # Explicit numeric suffix is treated as the variant and preserved.
        assert t.id == "prompt.version.2"

    def test_load_file_with_crlf_endings(self, prepare_file):
        """Test loading file with Windows line endings.

        NOTE: Python's text mode normalizes line endings on read.
        On Unix/Mac, \r\n is converted to \n. This is expected behavior.
        """
        content = "Line 1\r\nLine 2\r\nLine 3"
        prepare_file("crlf.md", content)
        t = Tmpt("crlf.md")
        # On Unix/Mac, line endings are normalized to \n
        assert t.template == "Line 1\nLine 2\nLine 3"

    def test_load_file_with_mixed_line_endings(self, prepare_file):
        """Test loading file with mixed line endings.

        NOTE: Python's text mode normalizes all line ending variants
        (\r\n, \r, \n) to \n on Unix/Mac platforms.
        """
        content = "Line 1\nLine 2\r\nLine 3\rLine 4"
        prepare_file("mixed.md", content)
        t = Tmpt("mixed.md")
        # All line endings normalized to \n
        assert t.template == "Line 1\nLine 2\nLine 3\nLine 4"

    def test_load_file_multiple_times_same_file(self, prepare_file):
        """Test loading same file multiple times."""
        prepare_file("repeat.md", "Repeat content")
        t1 = Tmpt("repeat.md")
        t2 = Tmpt("repeat.md")
        assert t1.template == "Repeat content"
        assert t2.template == "Repeat content"
        # Instances should be independent
        assert t1 is not t2

    def test_load_file_then_modify_via_setitem(self, prepare_file):
        """Test loading file then modifying via setitem."""
        prepare_file("modify.md", "Original")
        t = Tmpt("modify.md")
        assert t.template == "Original"
        Tmpt["modify"] = "Modified"
        assert t.template == "Original"

        t = Tmpt["modify"]
        assert t.template == "Modified"


class TestTmptSourceParseDir:
    def test_load_dir(self, prepare_file):
        prepare_file("prompts/prompt1.md", "Content 1")
        prepare_file("prompts/prompt2.md", "Content 2")
        t = Tmpt("prompts/")
        assert Tmpt["prompt1"].template == "Content 1"
        assert Tmpt["prompt2"].template == "Content 2"
        assert Tmpt["prompt1"] == "Content 1"
        assert Tmpt["prompt2"] == "Content 2"

    def test_load_dir_empty(self, tmp_path, monkeypatch):
        """Test loading empty directory."""
        empty_dir = tmp_path / "empty"
        empty_dir.mkdir()
        monkeypatch.chdir(tmp_path)
        t = Tmpt("empty/")
        assert len(t.list()) == 0

    def test_load_dir_no_md_files(self, tmp_path, monkeypatch, prepare_file):
        """Test loading directory with no .md files."""
        prepare_file("nomd/file.txt", "Text content")
        prepare_file("nomd/file.json", "JSON content")
        t = Tmpt("nomd/")
        # After loading nomd/, no new .md files should be registered
        # Check that we can't find these non-.md files
        with pytest.raises(KeyError):
            Tmpt["file"]

    def test_load_dir_mixed_files(self, prepare_file):
        """Test loading directory with .md and other files."""
        prepare_file("mixed/prompt.md", "MD content")
        prepare_file("mixed/readme.txt", "TXT content")
        prepare_file("mixed/data.json", "JSON content")
        t = Tmpt("mixed/")
        assert Tmpt["prompt"].template == "MD content"
        with pytest.raises(KeyError):
            Tmpt["readme"]

    def test_load_dir_nested_structure(self, prepare_file):
        """Test loading directory with nested subdirectories."""
        prepare_file("nested/prompt1.md", "Top level")
        prepare_file("nested/sub/prompt2.md", "Sub level")
        prepare_file("nested/sub/deep/prompt3.md", "Deep level")
        t = Tmpt("nested/")
        # Should recursively load all .md files
        assert Tmpt["prompt1"].template == "Top level"

    def test_load_dir_hidden_files(self, prepare_file):
        """Test that hidden files (starting with .) are skipped."""
        prepare_file("hidden/prompt.md", "Visible")
        prepare_file("hidden/.hidden.md", "Hidden")
        t = Tmpt("hidden/")
        assert Tmpt["prompt"].template == "Visible"
        # Hidden file should not be loaded
        with pytest.raises(TmptValidationError):
            Tmpt[".hidden"]

    def test_load_dir_hidden_directory(self, prepare_file):
        """Test that files in hidden directories are skipped."""
        prepare_file("withhidden/prompt.md", "Visible")
        prepare_file("withhidden/.hidden/secret.md", "Secret")
        t = Tmpt("withhidden/")
        assert Tmpt["prompt"].template == "Visible"
        with pytest.raises(KeyError):
            Tmpt["secret"]

    def test_load_dir_many_files(self, prepare_file):
        """Test loading directory with many files."""
        for i in range(50):
            prepare_file(f"many/prompt{i}.md", f"Content {i}")
        t = Tmpt("many/")
        # Verify a sample of files were loaded
        assert Tmpt["prompt0"].template == "Content 0"
        assert Tmpt["prompt49"].template == "Content 49"

    def test_load_dir_same_name_different_paths(self, prepare_file):
        """Test loading files with same name in different subdirectories."""
        prepare_file("paths/dir1/prompt.md", "From dir1")
        prepare_file("paths/dir2/prompt.md", "From dir2")
        t = Tmpt("paths/")
        # Both should be loaded, second might overwrite first
        content = Tmpt["prompt"].template
        assert content in ["From dir1", "From dir2"]

    def test_load_dir_sorted_order(self, prepare_file):
        """Test that files are loaded in sorted order."""
        prepare_file("ordered/z_last.md", "Last")
        prepare_file("ordered/a_first.md", "First")
        prepare_file("ordered/m_middle.md", "Middle")
        t = Tmpt("ordered/")
        # Check all are present
        assert Tmpt["z_last"].template == "Last"
        assert Tmpt["a_first"].template == "First"
        assert Tmpt["m_middle"].template == "Middle"

    def test_load_dir_with_unicode_filenames(self, prepare_file):
        """Test loading directory with unicode filenames."""
        prepare_file("unicode/你好.md", "Chinese")
        prepare_file("unicode/émoji.md", "French")
        t = Tmpt("unicode/")
        ids = t.list()
        assert len(ids) == 0

    def test_load_dir_with_spaces_in_filenames(self, prepare_file):
        """Test loading directory with spaces in filenames."""
        prepare_file("spaces/my prompt.md", "Space content")
        t = Tmpt("spaces/")
        with pytest.raises(TmptValidationError):
            Tmpt["my prompt"]

    def test_load_dir_nonexistent(self):
        """Test loading non-existent directory."""
        with pytest.raises(TmptSourceParseError, match="Path does not exist"):
            t = Tmpt("nonexistent_dir/")

    def test_load_dir_path_object(self, tmp_path, monkeypatch, prepare_file):
        """Test loading directory using Path object."""
        prepare_file("pathdir/file.md", "Path dir content")
        t = Tmpt(Path("pathdir"))
        assert Tmpt["file"].template == "Path dir content"

    def test_load_dir_with_variant_files(self, prepare_file):
        """Test loading directory with variant-style filenames."""
        prepare_file("variants/prompt.1.md", "Variant 1")
        prepare_file("variants/prompt.2.md", "Variant 2")
        t = Tmpt("variants/")
        # Both map to same base name, second overwrites first
        content = Tmpt["prompt"].template
        assert content in ["Variant 1", "Variant 2"]


class TestTmptSet:
    def test_setitem(self):
        Tmpt["my_prompt"] = "Hello"
        assert Tmpt["my_prompt"].template == "Hello"

    def test_setitem_overwrite(self):
        t = Tmpt()
        Tmpt["my_prompt"] = "Hello"
        assert Tmpt["my_prompt"].template == "Hello"

        Tmpt["my_prompt"] = "Hello2"
        assert Tmpt["my_prompt"].template == "Hello2"

    def test_setitem_list(self):
        t = Tmpt()

        Tmpt["prompt"] = "Content"

        assert t.list() == ["prompt"]

    def test_setitem_list_cls(self):
        Tmpt["prompt"] = "Content"

        assert Tmpt.list() == ["prompt"]

    def test_setitem_multiple_keys(self):
        """Test setting multiple different keys."""
        t = Tmpt()
        initial_count = len(t.list())

        Tmpt["prompt1"] = "Content 1"
        Tmpt["prompt2"] = "Content 2"
        Tmpt["prompt3"] = "Content 3"

        # Check new items were added
        assert len(Tmpt.list()) == initial_count + 3
        assert Tmpt["prompt1"].template == "Content 1"
        assert Tmpt["prompt2"].template == "Content 2"
        assert Tmpt["prompt3"].template == "Content 3"

    def test_setitem_empty_string(self):
        """Test setting item with empty string."""
        t = Tmpt()
        Tmpt["empty"] = ""
        assert Tmpt["empty"].template == ""

    def test_setitem_whitespace_string(self):
        """Test setting item with whitespace string."""
        t = Tmpt()
        Tmpt["whitespace"] = "   \n\t  "
        assert Tmpt["whitespace"].template == "   \n\t  "

    def test_setitem_unicode_content(self):
        """Test setting item with unicode content."""
        content = "Unicode: 你好 🌍 café"
        Tmpt["unicode"] = content
        assert Tmpt["unicode"].template == content

    def test_setitem_long_content(self):
        """Test setting item with very long content."""
        content = "x" * 100000
        Tmpt["long"] = content
        assert len(Tmpt["long"].template) == 100000

    def test_setitem_with_special_key_names(self):
        """Test setting items with special characters in keys."""
        t = Tmpt()
        initial_count = len(t.list())

        Tmpt["key-with-dash"] = "Content 1"
        Tmpt["key_with_underscore"] = "Content 2"
        Tmpt["key.with.dots"] = "Content 3"

        # Check that keys were added
        assert len(t.list()) >= initial_count + 1  # At least one added
        assert Tmpt["key-with-dash"].template == "Content 1"
        assert Tmpt["key_with_underscore"].template == "Content 2"

    def test_setitem_with_path_object_value(self):
        """Test that setting Path object tries to load it as source."""
        # Path object should be treated as source to load
        with pytest.raises(TmptSourceParseError, match="Path does not exist"):
            t = Tmpt(Path("nonexistent.md"))

    def test_setitem_updates_current_if_same_id(self):
        """Test that setting an item with current ID updates current template."""
        t = Tmpt()
        Tmpt["prompt"] = "Initial"
        t = Tmpt["prompt"]
        assert t.template == "Initial"

        # Update via setitem
        Tmpt["prompt"] = "Updated"
        t = Tmpt["prompt"]
        assert t.template == "Updated"

    def test_setitem_after_file_load(self, prepare_file):
        """Test setting item after loading from file."""
        prepare_file("file.md", "File content")
        t = Tmpt("file.md")
        Tmpt["new_prompt"] = "New content"
        assert Tmpt["file"].template == "File content"
        assert Tmpt["new_prompt"].template == "New content"

    def test_getitem_nonexistent_raises(self):
        """Test that getting non-existent item raises KeyError."""
        t = Tmpt()
        with pytest.raises(KeyError):
            _ = Tmpt["nonexistent"]

    def test_setitem_then_getitem_returns_tmpt_instance(self):
        """Test that getitem returns a Tmpt instance."""
        Tmpt["prompt"] = "Content"
        result = Tmpt["prompt"]
        assert isinstance(result, Tmpt)
        assert result.template == "Content"

    def test_setitem_normalizes_id(self):
        """Test that setitem normalizes the ID."""
        t = Tmpt()
        Tmpt["prompt.md"] = "Content"
        # Should be stored with normalized ID
        assert Tmpt["prompt.md"].template == "Content"


class TestTmptIntegration:
    """Integration tests for complex scenarios."""

    def test_load_dir_then_override_with_setitem(self, prepare_file):
        """Test loading directory then overriding specific file."""
        prepare_file("integration/prompt1.md", "Original 1")
        prepare_file("integration/prompt2.md", "Original 2")
        t = Tmpt("integration/")

        # Override one of the loaded prompts
        Tmpt["prompt1"] = "Override 1"

        assert Tmpt["prompt1"].template == "Override 1"
        assert Tmpt["prompt2"].template == "Original 2"

    def test_load_file_modify_load_another(self, prepare_file):
        """Test loading file, modifying, then loading another."""
        prepare_file("file1.md", "File 1")
        prepare_file("file2.md", "File 2")

        t1 = Tmpt("file1.md")
        Tmpt["custom"] = "Custom"

        t2 = Tmpt("file2.md")

        # Registry is shared across instances
        assert Tmpt["file1"].template == "File 1"
        assert Tmpt["custom"].template == "Custom"
        assert Tmpt["file2"].template == "File 2"

    def test_multiple_operations_sequence(self, prepare_file):
        """Test sequence of multiple operations."""
        t = Tmpt()

        # Add via setitem
        Tmpt["prompt1"] = "Content 1"

        # Load from file
        prepare_file("prompt2.md", "Content 2")
        t2 = Tmpt("prompt2.md")

        # Registry is shared across instances.
        assert Tmpt["prompt1"].template == "Content 1"
        assert Tmpt["prompt2"].template == "Content 2"

    def test_init_with_vars_and_file_load(self, prepare_file):
        """Test initialization with vars when loading from file."""
        prepare_file("varfile.md", "Hello {{ name }}")
        t = Tmpt("varfile.md", name="World")

        assert t.vars["name"] == "World"
        assert t.template == "Hello {{ name }}"

    def test_registry_state_after_errors(self):
        """Test that registry state is consistent after errors."""
        t = Tmpt()
        Tmpt["valid"] = "Valid content"

        # Try to load non-existent file (should fail)
        with pytest.raises(TmptSourceParseError):
            t2 = Tmpt("nonexistent.md")

        # Original instance should still be valid
        assert Tmpt["valid"].template == "Valid content"

    def test_empty_init_then_populate(self):
        """Test empty init followed by population."""
        t = Tmpt()
        initial_count = len(t.list())

        Tmpt["p1"] = "Content 1"
        Tmpt["p2"] = "Content 2"

        assert len(t.list()) == initial_count + 2

    def test_complex_directory_structure(self, prepare_file):
        """Test loading from complex directory structure."""
        prepare_file("complex/root.md", "Root")
        prepare_file("complex/sub1/file1.md", "Sub1 File1")
        prepare_file("complex/sub1/file2.md", "Sub1 File2")
        prepare_file("complex/sub2/file3.md", "Sub2 File3")
        prepare_file("complex/.hidden/secret.md", "Hidden")

        t = Tmpt("complex/")

        # Should load visible files, skip hidden directory
        assert Tmpt["root"].template == "Root"
        with pytest.raises(KeyError):
            Tmpt["secret"]

    def test_same_template_different_instances(self):
        """Test that same template in different instances are independent."""
        t1 = Tmpt("Same content")
        t2 = Tmpt("Same content")

        # Modify registry via class-level setitem
        Tmpt["extra"] = "Extra content"

        # Registry is shared across instances, so t2 also sees extra.
        assert Tmpt["extra"].template == "Extra content"


class TestTmptEdgeCasesAndBugs:
    """Tests specifically targeting potential bugs and edge cases."""

    def test_default_init_loads_cwd_md_files(self):
        """IMPORTANT: Test that Tmpt() with no args loads all .md files from cwd.

        This is a critical behavior - default initialization is NOT empty!
        It scans the current working directory for .md files.
        """
        t = Tmpt()
        # Registry will contain all .md files from test directory
        # This is by design, but can be surprising
        # Just verify it returns a list
        assert isinstance(t.list(), list)

    def test_getitem_returns_new_mutated_instance(self):
        """Test that getitem returns a properly mutated instance."""
        t = Tmpt()
        Tmpt["prompt1"] = "Content 1"
        Tmpt["prompt2"] = "Content 2"

        p1 = Tmpt["prompt1"]
        p2 = Tmpt["prompt2"]

        assert p1 is not p2
        assert p1 is not t

        assert p1.template == "Content 1"
        assert p2.template == "Content 2"
        assert p1.id == "prompt1"
        assert p2.id == "prompt2"

    def test_registry_dict_structure(self):
        """Test that registry stores dicts with template key."""
        t = Tmpt("Hello")
        assert Tmpt["_local"].template == "Hello"

    def test_load_source_dispatch_edge_cases(self):
        """Test that load_source correctly dispatches different source types."""
        # String not ending in .md or / should be treated as inline
        t1 = Tmpt("plain text")
        assert t1.template == "plain text"

        # String ending in / should try to load directory
        with pytest.raises(TmptSourceParseError):
            t2 = Tmpt("nonexistent/")

    def test_mutate_to_nonexistent_id_raises(self):
        """Test that accessing non-existent ID raises error."""
        with pytest.raises(KeyError):
            Tmpt["nonexistent"]

    def test_list_method_returns_sorted_ids(self):
        """Test that list() returns sorted prompt IDs.

        NOTE: When Tmpt() is initialized without args, it loads cwd .md files.
        This test verifies the behavior accounts for that.
        """
        t = Tmpt()
        initial_ids = set(t.list())

        Tmpt["zebra"] = "Z"
        Tmpt["alpha"] = "A"
        Tmpt["middle"] = "M"

        ids = t.list()
        # Should be sorted
        assert ids == sorted(ids)

        # Our new items should be in the list
        assert "zebra" in ids
        assert "alpha" in ids
        assert "middle" in ids

        # Should have more items than initially
        assert len(ids) >= len(initial_ids) + 3

    def test_equality_checks_template(self):
        """Test that Tmpt equality compares templates."""
        t = Tmpt("Hello")
        # From TmptData.__eq__, it compares to template
        assert t == "Hello"
        assert t != "Goodbye"

    def test_call_returns_template(self):
        """Test that calling instance returns template."""
        t = Tmpt("Callable content")
        result = t()
        assert result == "Callable content"

    def test_vars_persistence_across_getitem(self):
        """Test that vars persist when getting items from registry."""
        t = Tmpt()
        Tmpt["prompt"] = "Content"

        # Get item creates new instance via from_dict
        p = Tmpt["prompt"]
        # The returned instance may not have the original constructor vars
        assert isinstance(p, Tmpt)

    def test_to_dict_only_includes_template(self):
        """Test that to_dict only includes template field."""
        t = Tmpt("Content", name="value")
        d = t.to_dict()
        assert d == {"id": "_local.1", "template": "Content", "vars": {"name": "value"}}
        # vars are not included in to_dict

    def test_from_dict_updates_instance_attributes(self):
        """Test that from_dict updates instance state."""
        t = Tmpt("Initial")
        t.update({"template": "Updated"})
        assert t.template == "Updated"

    def test_registry_add_and_set_workflow(self):
        """Test internal _add_and_set method workflow."""
        t = Tmpt()
        Tmpt["test"] = "Content"

        # Should be in shared registry; class-level setitem does not mutate existing instances
        assert Tmpt["test"].template == "Content"
        assert t.id is None
        assert t.template is None

    def test_file_load_uses_stem_for_id(self, prepare_file):
        """Test that file loading uses Path.stem for ID generation."""
        prepare_file("my-file-name.md", "Content")
        t = Tmpt("my-file-name.md")
        assert t.id == "my-file-name.1"

    def test_directory_skips_dotfiles_and_subdirs(self, prepare_file):
        """Test that directory loading skips files/dirs starting with dot."""
        prepare_file("prmpt/normal.md", "Normal")
        prepare_file("prmpt/.hidden.md", "Hidden")

        t = Tmpt("prmpt/")
        assert Tmpt["normal"] == "Normal"
        with pytest.raises(TmptValidationError):
            Tmpt[".hidden"]

    def test_path_object_proper_handling(self, prepare_file):
        """Test that Path objects are handled correctly."""
        prepare_file("pathtest.md", "Path content")

        # Both string and Path should work the same
        t1 = Tmpt("pathtest.md")
        t2 = Tmpt(Path("pathtest.md"))

        assert t1.template == t2.template

    def test_multiple_dots_in_filename_edge_case(self, prepare_file):
        """Test filename with multiple dots (variant syntax edge case)."""
        prepare_file("file.v1.2.md", "Content")
        t = Tmpt("file.v1.2.md")
        # Should extract first part before any dot
        assert t.id == "file.v1.2"
