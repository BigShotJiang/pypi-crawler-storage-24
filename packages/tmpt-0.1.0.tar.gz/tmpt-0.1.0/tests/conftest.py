from __future__ import annotations

from pathlib import Path

import pytest

from tmpt import Tmpt


@pytest.fixture(autouse=True)
def clear_shared_registry():
    Tmpt.clear()
    yield
    Tmpt.clear()


@pytest.fixture
def prepare_file():
    base_dir = Path.cwd()
    created_files: list[Path] = []

    def fn(filename: str, content: str):
        """Create a test file from ``filename`` and ``content``."""
        rel_path = Path(filename)
        test_file = (base_dir / rel_path).resolve()
        test_file.parent.mkdir(parents=True, exist_ok=True)
        test_file.write_text(str(content), encoding="utf-8")
        created_files.append(test_file)
        return test_file

    yield fn

    # Cleanup created files and now-empty directories under base_dir.
    for file_path in reversed(created_files):
        if file_path.exists():
            file_path.unlink()
        parent = file_path.parent
        while parent != base_dir and parent.exists():
            try:
                parent.rmdir()
            except OSError:
                break
            parent = parent.parent


def pytest_configure(config: pytest.Config) -> None:
    clickable_format = "%(levelname)s %(pathname)s:%(lineno)d %(name)s - %(message)s"
    config.option.log_format = clickable_format
    config.option.log_cli_format = clickable_format


@pytest.fixture
def write_file():
    def _write(path: Path, content: str) -> Path:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content, encoding="utf-8")
        return path

    return _write
