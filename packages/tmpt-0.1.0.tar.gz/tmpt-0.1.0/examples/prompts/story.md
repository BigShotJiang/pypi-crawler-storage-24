---
animal: dog

---
{{ # role_pirate }}

// Just an example of some prompt
Write a story about {{ animal }}.
Make it max {{? n_sentence}} sentences.


