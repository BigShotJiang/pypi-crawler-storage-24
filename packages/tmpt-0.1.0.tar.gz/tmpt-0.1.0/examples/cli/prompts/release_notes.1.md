Release {{ product }} {{ version }}

Highlights:
- baseline performance improvements
- CLI validate command
