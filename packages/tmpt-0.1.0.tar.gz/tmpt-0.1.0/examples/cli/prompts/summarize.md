---
tone: concise
---
Your job is to make a summary.

{{ ? topic }} Our topic for summary is {{ topic }}

And whatever our topic is {{ topic }}

{{ ? tone }}
Use tone: {{ tone }}
And that's cool
// This is comment


// Comment

# Checklist

{{ include("shared_checklist") }}


{{ ? tone }}
#
Follow tone

{{ ? not topic }}
#
But we dont know topic 

#
Be kind

---
Detailed summary for {{ topic }}.
Steps:
1. understand impact
2. isolate issue
3. communicate status
{{ #shared_checklist }}
