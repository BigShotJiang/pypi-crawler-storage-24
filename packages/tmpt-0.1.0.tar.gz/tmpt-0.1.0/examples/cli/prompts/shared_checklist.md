Checklist:
- confirm scope
- gather logs
- notify stakeholders 
- set {{ tone }} tone

# References

Some references

{{ ? tone }}
And we do have tone

{{ ? not tone }}
And we do have tone