Release {{ product }} {{ version }}

Highlights:
- richer CLI diagnostics
- examples for folder, file, and id validation
