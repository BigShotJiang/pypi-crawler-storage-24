# tmpt CLI Example

This folder contains small prompt files you can use to try the `tmpt` CLI.

## 1) Install `tmpt` in editable mode

From repository root:

```bash
uv pip install -e src/tmpt
```

## 2) Validate the whole folder

```bash
tmpt validate src/tmpt/examples/cli/prompts
```

You should see:
- discovered prompt files
- prompt variants and callable ids
- inferred operations (`include`, `substitution`, `function_call`, etc.)

## 3) Validate a single file

```bash
tmpt validate src/tmpt/examples/cli/prompts/summarize.md
```

This file has inline variants split by `---`, so the output shows multiple variants.

## 4) Validate by id

Run from this folder:

```bash
cd src/tmpt/examples/cli/prompts
tmpt validate summarize.last
```

## 5) Render with variables

Run from this folder:

```bash
tmpt render summarize --variable topic="incident response"
tmpt render release_notes.last --variable product="tmpt" --variable version="0.2.0"
```

The CLI prints both:
- raw template
- rendered output

## Optional colorful output

`tmpt` works with standard library only, but can use `rich` when installed:

```bash
uv pip install "tmpt[rich]"
```

Disable rich output at any time:

```bash
TMPT_NO_RICH=1 tmpt validate .
```
