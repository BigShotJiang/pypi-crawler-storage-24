import marimo

__generated_with = "0.20.4"
app = marimo.App(width="medium", auto_download=["html", "ipynb"])


@app.cell
def _():
    import marimo as mo
    # import tmpt
    from tmpt import Tmpt
    # import importlib
    # importlib.reload(tmpt)
    return Tmpt, mo


@app.cell
def _(Tmpt):
    print(
        Tmpt("./")["story"]()
    )
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    ### What happened here?

    Let's see step by step.


    `Tmpt` discovered existing `.md` files in a current path (`./`). We can see discovered prompts:
    """)
    return


@app.cell
def _(Tmpt):
    Tmpt.list()
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    We've selected `"story"` prompt:
    """)
    return


@app.cell
def _(Tmpt):
    Tmpt("./")["story"]
    return


@app.cell
def _():
    with open("./examples/prompts/story.md") as f:
        print(f.read())
    return


@app.cell
def _(mo):
    mo.md(r"""
    and rendered it using `()`:
    """)
    return


@app.cell
def _(Tmpt):
    Tmpt("./")["story"]()
    return


@app.cell
def _():
    return


@app.cell(hide_code=True)
def _(mo):
    mo.md(r"""
    We can change variables during rendering:
    """)
    return


@app.cell
def _(Tmpt):
    Tmpt("./")["story"](animal="cat")
    return


@app.cell
def _(Tmpt):
    Tmpt("./", animal="cat")["story"]()
    return


@app.cell
def _(Tmpt):
    t = Tmpt("./")["story"]
    t(animal="cat")
    return (t,)


@app.cell
def _(t):
    t(n_sentence=3)
    return


@app.cell
def _(t):
    t(n_sentence=3, language="mandarin")
    return


@app.cell
def _():
    from tmpt.cli.highlighting import highlight_template


    return (highlight_template,)


@app.cell
def _(highlight_template, t):
    highlight_template(t.template)
    return


@app.cell
def _(t):
    from tmpt import print_panel, print_header, print_status, print_columns


    print_panel(title=t.id, content=t.template)
    print_header(f"[bold]{t.id}[/bold]")
    print_status("✓", f"Loaded {t.id}", color="green")
    print_columns([
        ("Before", t.template, "cyan"),
        ("After",  t.template,        "green"),
    ])
    return


@app.cell
def _():
    return


if __name__ == "__main__":
    app.run()
