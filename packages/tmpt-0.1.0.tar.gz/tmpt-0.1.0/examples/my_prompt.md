---
style: formal
---
Write {{ n_sentence:5 }}-sentence report about {{ country }} in {{ style }} style. 

Some {{ ? country }}

// comment

{{#summarize}}