from __future__ import annotations

from dataclasses import replace
from pathlib import Path

from ._logging import get_logger
from .exceptions import (
    TmptNotFoundError,
    TmptValidationError,
)
from .loaders import load_source
from .tmpt_data import TmptData
from .tmpt_ref import TmptRef
from .types import SourceType

logger = get_logger(__name__)


class TmptRegistry:
    """Self-contained prompt registry.

    Stores templates in an instance-level dict.  Compose one instance into
    ``Tmpt.registry`` (a ClassVar) to share it across all ``Tmpt`` instances,
    or swap ``Tmpt.registry`` to isolate namespaces or simplify test setup.
    """

    def __init__(self) -> None:
        self._registry: dict[TmptRef, TmptData] = {}

    def list(self) -> list[str]:
        """Return a sorted list of all registered template IDs (as strings)."""
        return sorted(str(k) for k in self._registry)

    def clear(self) -> None:
        """Remove all entries from the registry."""
        self._registry.clear()

    def get_default_variant(self, tmpt_id: str) -> TmptData:
        """Return the highest-numbered variant for a given base name.

        Any variant suffix in ``tmpt_id`` is ignored — only the base name is used
        to find all registered variants, and the one with the largest variant number
        is returned.  Raises ``TmptNotFoundError`` if no variants exist.
        """
        ref = TmptRef.from_string(tmpt_id)
        latest_key = ref.latest(list(self._registry.keys()))
        if latest_key and latest_key in self._registry:
            return self._registry[latest_key]
        raise TmptNotFoundError(tmpt_id)

    def get(self, tmpt_id: str) -> TmptData:
        """Look up a template by ID.

        If ``tmpt_id`` includes a variant suffix (e.g. ``"prompt.2"``), an exact
        match is required.  If no variant suffix is given, the highest-numbered
        variant is returned via ``get_default_variant``.
        Raises ``TmptNotFoundError`` if no matching entry exists.
        """
        ref = TmptRef.from_string(tmpt_id)

        # Exact match (including variant)
        if ref in self._registry:
            return self._registry[ref]

        # Another chance if variant is not specified, get the default variant
        if ref.variant is None:
            return self.get_default_variant(tmpt_id)
        raise TmptNotFoundError(tmpt_id)

    def load(self, source: SourceType) -> list[TmptData]:
        """Load templates from a source, using mtime-based caching for file-backed sources.

        For each template yielded by ``load_source``:

        - **Inline templates** (no backing file, ``source_mtime is None``) are always
          passed through ``add()``.
        - **File-backed templates** are checked once per unique file path: if every
          cached entry for that path has an ``source_mtime`` matching the one read by
          ``load_source``, the cached entries are returned as-is.  Otherwise all stale
          entries for that path are evicted and the fresh templates are added via
          ``add()``.

        The freshness decision is locked in on the first variant encountered for each
        path to prevent multi-variant files from being partially re-loaded.

        Returns the list of ``TmptData`` instances that were either served from cache
        or newly registered.
        """
        path_fresh: dict[Path, bool] = {}
        loaded = []

        for tmpt in load_source(source):
            path = tmpt.source_path
            mtime = tmpt.source_mtime

            if mtime is None:
                loaded.append(self.add(tmpt))
                continue

            # First encounter of this path — decide freshness once.
            if path not in path_fresh:
                cached = {
                    k: v for k, v in self._registry.items() if v.source_path == path
                }
                path_fresh[path] = bool(cached) and all(
                    v.source_mtime == mtime for v in cached.values()
                )
                if path_fresh[path]:
                    loaded.extend(cached.values())
                else:
                    for key in cached:
                        del self._registry[key]

            if not path_fresh[path]:
                loaded.append(self.add(tmpt))

        return loaded

    def add(self, tmpt: TmptData) -> TmptData:
        """Append a template to the registry and return a copy with the assigned ID.

        The ID is derived from ``tmpt.id`` by calling ``TmptRef.next()`` against the
        current registry keys, so the assigned variant number is always one higher than
        the current maximum for that base name (e.g. the third call for ``"prompt"``
        yields ``"prompt.3"``).  The original ``tmpt`` object is not mutated.

        For inline templates (``source_path is None``), any previously registered inline
        entry with the same base name is evicted first, keeping the registry free of
        stale duplicates.

        Raises ``TmptValidationError`` if ``tmpt.id`` cannot be parsed as a valid ID.
        """
        try:
            parsed = TmptRef.from_string(tmpt.id)
        except TmptValidationError as exc:
            raise TmptValidationError(f"[add] Invalid tmpt ID: {tmpt.id}") from exc

        if tmpt.source_path is None:
            # Inline template — evict by base name to avoid duplicates.
            for key in list(self._registry):
                if key.name == parsed.name and self._registry[key].source_path is None:
                    del self._registry[key]

        next_key = parsed.next(list(self._registry.keys()))
        registered = replace(tmpt, id=str(next_key))
        self._registry[next_key] = registered
        return registered

    def set(self, tmpt_id: str, tmpt_or_source: SourceType | TmptData) -> None:
        """Register a template under an explicit ID, overwriting any existing entry.

        ``tmpt_or_source`` can be:

        - A ``TmptData`` instance — stored under ``tmpt_id``, which always takes
          precedence over any ``id`` already set on the instance.
        - A ``SourceType`` (string, path, or dict) — loaded via ``load_source``.
          The first loaded template is registered under the exact ``tmpt_id``; if the
          source yields multiple templates (e.g. a multi-section file), each subsequent
          one gets a variant suffix (``name.2``, ``name.3``, …).

          When ``tmpt_id`` has no variant suffix (bare base name), all previously
          registered variants for that base name are evicted first, so stale variants
          left over from an earlier version of the source don't accumulate.
          When ``tmpt_id`` includes an explicit variant suffix, only that specific entry
          is replaced — sibling variants are left untouched.
        """
        # Resolve ID used in registry
        key = TmptRef.from_string(tmpt_id)

        # TmptData provided directly: register with given data, replacing ID with resolved key
        if isinstance(tmpt_or_source, TmptData):
            self._registry[key] = replace(tmpt_or_source, id=tmpt_id)

        elif isinstance(tmpt_or_source, (str, Path, dict, type(None))):
            # When setting by base name, evict all existing variants so stale
            # ones don't linger after the source changes. When targeting a
            # specific variant, only overwrite that exact entry.
            if key.variant is None:
                for k in [k for k in self._registry if k.name == key.name]:
                    del self._registry[k]
            # First template gets the exact key; additional variants get suffixed keys.
            next_key = key
            for tmpt in load_source(tmpt_or_source):
                self._registry[next_key] = replace(tmpt, id=str(next_key))
                next_key = key.next(list(self._registry.keys()))
        else:
            raise TypeError(
                f"Cannot register {type(tmpt_or_source).__name__!r} under id {tmpt_id!r}. "
                "Expected a SourceType instance."
            )
