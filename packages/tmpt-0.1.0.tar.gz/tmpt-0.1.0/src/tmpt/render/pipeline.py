from __future__ import annotations

from collections import UserList
from dataclasses import replace

from ..tmpt_data import TmptData
from .base import RendererBase
from .context import RenderContext


class PipelineRenderer(UserList["RendererBase"]):
    """An ordered list of ``RendererBase`` stages that can render a template.

    Behaves exactly like a list (append, slice, iterate) but also exposes
    ``render()``, which passes ``TmptData`` through each stage in order.
    """

    def render(self, data: TmptData, ctx: RenderContext | None = None) -> str:
        """Pass *data* through each stage, updating the template each time."""
        for stage in self:
            data = replace(data, template=stage.render(data, ctx))
        return data.template or ""
