"""Conditional directive renderer.

Syntax
------
Block directives occupy their own line (surrounded by blank lines):

    {{ ? <var> }}  — include the following block if var is set and non-empty
    {{ ! <var> }}  — include the following block if var is NOT set / empty

The body of a block is all lines between the directive and the next blank line
or bare ``#`` fence.  The fence is consumed; the blank line is preserved.

Inline directives are embedded within a content line:

    {{ ? var }}  — var exists: replace tag with value; missing: delete entire line
    {{ ! var }}  — var missing: remove tag; var exists: delete entire line

See docs/conditionals-state-machine.md for the implementation design rationale.
"""

from __future__ import annotations

import re
from collections.abc import Callable, Generator, Iterator
from enum import Enum, auto
from io import StringIO
from typing import Any

from ..tmpt_data import TmptData
from .base import RendererBase
from .context import RenderContext

# Matches a whole-line directive: {{ ?|! condition }}
_DIRECTIVE_RE = re.compile(r"^\s*\{\{\s*(?P<op>\?|!)\s+(?P<cond>[^{}]+?)\s*\}\}\s*$")

# Matches an inline directive anywhere on a line: {{ ?|! cond }}
_INLINE_RE = re.compile(r"\{\{\s*(?P<op>\?|!)\s+(?P<cond>.+?)\s*\}}")


# ------------------------------------------------------------------ #
# Public renderer                                                     #
# ------------------------------------------------------------------ #


class RendererConditionals(RendererBase):
    """Resolves ``{{ if var }}`` / ``{{ ? var }}`` / ``{{ ! var }}`` blocks.

    Must run *before* ``RendererVars`` so that directive lines are processed
    while ``{{ var }}`` expressions are still intact (RendererVars will fill
    them in on the next stage).
    """

    def render(self, data: TmptData, ctx: RenderContext | None = None) -> str:
        template = data.template or ""
        if "{{" not in template:
            return template
        # Quick check: any directive at all?
        if not _DIRECTIVE_RE.search(template) and not _INLINE_RE.search(template):
            return template
        return _apply_conditionals(template, data.vars)


# ------------------------------------------------------------------ #
# State machine                                                       #
# ------------------------------------------------------------------ #


class _State(Enum):
    NORMAL = auto()
    SHOW = auto()
    HIDE = auto()


# Line type classifiers — ordered, first match wins.
# To add a new line type, append an entry here.
_LINE_TYPES: dict[str, Callable[[str], bool]] = {
    "directive": lambda line: bool(_DIRECTIVE_RE.match(line)),
    "fence": lambda line: line.strip() == "#",
    "blank": lambda line: not line.strip(),
}


def _classify(line: str) -> str:
    for name, check in _LINE_TYPES.items():
        if check(line):
            return name
    return "text"


def _apply_conditionals(template: str, context: dict[str, Any]) -> str:
    lines: Iterator[str] = StringIO(template)
    out = _run_state_machine(lines, context)
    return re.sub(r"\n{3,}", "\n\n", "".join(out))


def _run_state_machine(
    lines: Iterator[str], context: dict[str, Any]
) -> Generator[str, None, None]:
    state = _State.NORMAL
    for line in lines:
        state, emit = _TRANSITIONS[state, _classify(line)](line, context)
        if emit is not None:
            yield emit


# ------------------------------------------------------------------ #
# Helpers                                                             #
# ------------------------------------------------------------------ #


def _parse_directive(line: str) -> str | None:
    """Return the normalised condition string or None if not a directive line."""
    m = _DIRECTIVE_RE.match(line)
    if not m:
        return None
    cond = m.group("cond").strip()
    return f"not {cond}" if m.group("op") == "!" else cond


def _apply_inline(line: str, context: dict[str, Any]) -> str:
    """Process inline {{ if|?|! cond }} tokens.

    ``{{ ? var }}`` / ``{{ if var }}``: var exists → replace tag with value; missing → delete line.
    ``{{ ! var }}``: var missing → remove tag; var exists → delete line.
    """
    # First pass: if any match would delete the whole line, bail early.
    for m in _INLINE_RE.finditer(line):
        op, cond = m.group("op"), m.group("cond").strip()
        var_set = not _is_empty(context.get(cond))
        if (op == "!" and var_set) or (op != "!" and not var_set):
            return ""

    # Second pass: no deletion — substitute (? / if) or strip (!) each tag.
    def repl(m: re.Match[str]) -> str:
        op, cond = m.group("op"), m.group("cond").strip()
        return "" if op == "!" else str(context[cond])

    return _INLINE_RE.sub(repl, line)


def _eval(expr: str, context: dict[str, Any]) -> bool:
    """Evaluate a simple ``[not] var`` condition against context."""
    negate = False
    cond = expr.strip()
    if cond.startswith("not "):
        negate = True
        cond = cond[4:].strip()
    value = context.get(cond)
    is_set = not _is_empty(value)
    return (not is_set) if negate else is_set


def _is_empty(value: Any) -> bool:
    if value is None:
        return True
    if isinstance(value, str):
        return value.strip() == ""
    if isinstance(value, (list, dict)):
        return len(value) == 0
    return False


# ------------------------------------------------------------------ #
# Transition table  (state, line_type) -> (next_state, emit | None)  #
# ------------------------------------------------------------------ #
# To add a new directive: add a _State value, add rows here.

_Tx = Callable[[str, dict[str, Any]], tuple[_State, str | None]]

_TRANSITIONS: dict[tuple[_State, str], _Tx] = {
    # --- NORMAL: pass through, or enter a block ---
    (_State.NORMAL, "directive"): lambda l, ctx: (
        _State.SHOW if _eval(_parse_directive(l), ctx) else _State.HIDE,
        None,
    ),
    (_State.NORMAL, "text"): lambda l, ctx: (_State.NORMAL, _apply_inline(l, ctx)),
    (_State.NORMAL, "blank"): lambda l, ctx: (_State.NORMAL, l),
    (_State.NORMAL, "fence"): lambda l, ctx: (_State.NORMAL, None),
    # --- SHOW: emit body lines, stop at boundary ---
    (_State.SHOW, "text"): lambda l, ctx: (_State.SHOW, _apply_inline(l, ctx)),
    (_State.SHOW, "blank"): lambda l, ctx: (_State.NORMAL, l),
    (_State.SHOW, "fence"): lambda l, ctx: (_State.NORMAL, None),
    # --- HIDE: drop body lines, stop at boundary ---
    (_State.HIDE, "directive"): lambda l, ctx: (_State.HIDE, None),
    (_State.HIDE, "text"): lambda l, ctx: (_State.HIDE, None),
    (_State.HIDE, "blank"): lambda l, ctx: (_State.NORMAL, None),
    (_State.HIDE, "fence"): lambda l, ctx: (_State.NORMAL, None),
}
