from __future__ import annotations

from ..tmpt_data import TmptData
from .base import RendererBase
from .context import RenderContext


class RendererTransformToUpper(RendererBase):
    """Example renderer that transforms the template to uppercase."""

    def render(self, data: TmptData, ctx: RenderContext | None = None) -> str:
        return (data.template or "").upper()


class RendererTransformToLower(RendererBase):
    """Example renderer that transforms the template to lowercase."""

    def render(self, data: TmptData, ctx: RenderContext | None = None) -> str:
        return (data.template or "").lower()


class RendererTransformAppend(RendererBase):
    def __init__(self, suffix: str) -> None:
        self.suffix = suffix

    def render(self, data: TmptData, ctx: RenderContext | None = None) -> str:
        return (data.template or "") + self.suffix


class RendererPassthrough(RendererBase):
    def render(self, data: TmptData, ctx: RenderContext | None = None) -> str:
        return data.template or ""
