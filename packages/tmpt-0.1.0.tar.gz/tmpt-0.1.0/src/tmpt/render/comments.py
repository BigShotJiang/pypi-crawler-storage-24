from __future__ import annotations

import re

from ..tmpt_data import TmptData
from .base import RendererBase
from .context import RenderContext

_COMMENT_RE = re.compile(r"^[ \t]*//.*$", re.MULTILINE)


class RendererStripComments(RendererBase):
    """Removes lines whose non-whitespace content starts with ``//``.

    A line is treated as a comment when it begins with optional horizontal
    whitespace followed by ``//``.  The entire line, including its trailing
    newline, is removed from the output.  Inline ``//`` that appears after
    other content is left untouched.
    """

    def render(self, data: TmptData, ctx: RenderContext | None = None) -> str:
        template = data.template or ""
        if "//" not in template:
            return template
        # Remove matching lines; also clean up the newline that preceded them
        # so no empty blank lines are left behind.
        result = _COMMENT_RE.sub("", template)
        # Collapse consecutive blank lines that may result from comment removal
        result = re.sub(r"\n{3,}", "\n\n", result)
        return result
