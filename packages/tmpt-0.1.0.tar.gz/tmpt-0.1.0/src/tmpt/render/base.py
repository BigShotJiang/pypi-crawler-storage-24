from __future__ import annotations

from abc import ABC, abstractmethod

from ..tmpt_data import TmptData
from .context import RenderContext


class RendererBase(ABC):
    """Abstract base class for renderers."""

    @abstractmethod
    def render(self, data: TmptData, ctx: RenderContext | None = None) -> str:
        """Render the template using data fields (template, vars, etc.)."""
        pass
