from __future__ import annotations

import ast
import re
from typing import Any

from ..tmpt_data import TmptData
from .base import RendererBase
from .context import RenderContext

_EXPR_RE = re.compile(r"\{\{\s*(.*?)\s*\}\}")


def _split_expr(expr: str) -> tuple[str, str | None]:
    if ":" not in expr:
        return expr.strip(), None
    name, default = expr.split(":", 1)
    return name.strip(), default.strip()


def _coerce_literal(raw: str) -> Any:
    try:
        return ast.literal_eval(raw)
    except (ValueError, SyntaxError):
        return raw


class RendererVars(RendererBase):
    """Substitutes ``{{ var }}`` / ``{{ var:default }}`` expressions using ``data.vars``."""

    def render(self, data: TmptData, ctx: RenderContext | None = None) -> str:
        template = data.template or ""
        vars = data.vars

        def _replace(match: re.Match[str]) -> str:
            expr = match.group(1).strip()
            name, default = _split_expr(expr)
            if name in vars:
                return str(vars[name])
            if default is not None:
                return str(_coerce_literal(default))
            return match.group(0)

        return _EXPR_RE.sub(_replace, template)
