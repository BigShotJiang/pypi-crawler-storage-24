from __future__ import annotations

from typing import Any, TypedDict

from ..tmpt_registry import TmptRegistry


class RenderContext(TypedDict, total=False):
    """Execution environment passed to every pipeline stage."""

    registry: TmptRegistry
    _visiting: frozenset[str]
