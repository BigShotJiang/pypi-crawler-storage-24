from __future__ import annotations

import re

from ..exceptions import TmptNotFoundError
from ..tmpt_data import TmptData
from .base import RendererBase
from .context import RenderContext

_INCLUDE_RE = re.compile(r"\{\{\s*#\s*([\w.\-]+)\s*\}\}")


class RendererInclude(RendererBase):
    """Substitutes ``{{#prompt_id}}`` tags with the template from the registry.

    Looks up each ``{{#id}}`` in ``ctx["registry"]``.  If found, the included
    template is inserted verbatim and will be processed by subsequent pipeline
    stages (e.g. ``RendererVars``).  If the registry is absent or the id is not
    found, the tag is left unchanged.
    """

    def render(self, data: TmptData, ctx: RenderContext | None = None) -> str:
        template = data.template or ""
        registry = (ctx or {}).get("registry")
        if registry is None or not _INCLUDE_RE.search(template):
            return template

        visiting: frozenset[str] = (ctx or {}).get("_visiting", frozenset())

        def _replace(match: re.Match[str]) -> str:
            tmpt_id = match.group(1)
            if tmpt_id in visiting:
                return match.group(0)  # cycle guard
            try:
                included = registry.get(tmpt_id)
            except TmptNotFoundError:
                return match.group(0)
            nested_ctx = {**(ctx or {}), "_visiting": visiting | {tmpt_id}}
            return self.render(included, nested_ctx)

        return _INCLUDE_RE.sub(_replace, template)
