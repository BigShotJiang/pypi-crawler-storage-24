import ast
import re
from dataclasses import fields
from pathlib import Path
from typing import Any, Iterator

from ._logging import get_logger
from .exceptions import TmptSourceParseError, TmptValidationError
from .tmpt_data import TmptData
from .tmpt_ref import LOCAL_TEMPLATE_ID, TmptRef
from .types import SourceType

logger = get_logger(__name__)

EXCLUDE_FILENAMES = ["readme", "license", "changelog", "contributing"]
EXCLUDE_FOLDERS = ["docs", "tests", "test", "src", "source", "dist", "build"]
LINE_PREFIX_IGNORE = [
    "//"
]  # lines starting with any of these are ignored in frontmatter parsing
SECTION_DELIMITER = r"(?m)^\s*---\s*$\n?"


def _first_hidden_part(path: Path) -> str | None:
    for part in path.parts:
        if part.startswith("."):
            return part
    return None


def _first_excluded_folder_part(path: Path) -> str | None:
    for part in path.parts:
        part_lower = part.lower()
        if any(exclude in part_lower for exclude in EXCLUDE_FOLDERS):
            return part
    return None


def load_source(source: SourceType) -> Iterator[TmptData]:
    """Dispatch template load for source(s). There can be multiple templates for a given source,
    e.g. when loading a directory with multiple files, or a file with multiple templates defined in frontmatter."""

    logger.debug("load_source: source_type=%s", type(source).__name__)

    # str
    if isinstance(source, str):
        # but may be a path to a file or directory
        if source.endswith(".md") or source.endswith("/"):
            logger.debug("load_source: detected path-like string source=%s", source)
            yield from load_path(Path(source))
        # or anonymous template string
        else:
            logger.debug("load_source: detected inline template string")
            yield from load_str(source)
    # Path, so for sure a file or directory
    elif isinstance(source, Path):
        logger.debug("load_source: detected Path source=%s", source)
        yield from load_path(source)
    # dict, so internal source definition
    elif isinstance(source, dict):
        logger.debug("load_source: detected dict source")
        yield from load_dict(source)
    # (), so nothing to load, a placeholder object
    elif source is None:
        tmpt = TmptData()
        logger.debug("load_source: loaded placeholder template id=%s", tmpt.id)
        yield tmpt
    else:
        raise TmptSourceParseError("Source must be None, str, or Path")


def load_path(path: Path) -> Iterator[TmptData]:
    """Dispatch load from path to file or directory loader."""
    logger.debug("load_path: path=%s", path)

    if path.is_dir():
        logger.debug("load_path: treating as directory path=%s", path)
        yield from load_directory(path)
    elif path.is_file() and path.suffix == ".md":
        logger.debug("load_path: treating as markdown file path=%s", path)
        yield from load_file(path)
    else:
        raise TmptSourceParseError(f"Path does not exist: {path}")


def load_directory(root: Path) -> Iterator[TmptData]:
    """Load all templates .md from a directory, recursively."""
    logger.debug("load_directory: root=%s", root)

    for path in root.rglob("*.md"):
        # Skip ".something" in path
        hidden_part = _first_hidden_part(path)
        if hidden_part:
            logger.debug(
                "load_directory: omitted file path=%s reason=hidden_path",
                path,
            )
            continue

        # Skip excluded folders
        excluded_part = _first_excluded_folder_part(path)
        if excluded_part:
            logger.debug(
                "load_directory: omitted file path=%s reason=excluded_folder",
                path,
            )
            continue

        yield from load_file(path)


def load_file(path: Path) -> Iterator[TmptData]:
    if not path.is_file():
        logger.debug("load_file: omitted file path=%s reason=not_a_file", path)
        return

    if path.name.startswith("."):
        logger.debug("load_file: omitted file path=%s reason=hidden_filename", path)
        return

    if path.suffix != ".md":
        logger.debug(
            "load_file: omitted file path=%s reason=unsupported_suffix",
            path,
        )
        return

    if path.stem.lower() in EXCLUDE_FILENAMES:
        logger.debug(
            "load_file: omitted file path=%s reason=excluded_filename",
            path,
        )
        return
    try:
        ref = TmptRef.from_string(path.name)
    except TmptValidationError:
        logger.debug(
            "load_file: omitted file path=%s reason=invalid_id",
            path,
        )
        return

    logger.debug("load_file: reading file path=%s", path)

    try:
        text = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        logger.warning(
            "load_file: skipped file path=%s reason=encoding_error (not valid UTF-8)",
            path,
        )
        return

    mtime = path.stat().st_mtime
    for t in load_str(text):
        t.id = str(ref)
        t.source_path = path.resolve()
        t.source_mtime = mtime
        logger.debug("load_file: loaded template id=%s source=%s", t.id, path)
        yield t


def frontmatter_content_to_dict(s: str) -> dict[str, Any]:
    """Parse frontmatter string into a dict.

    Expects lines of the form ``key: value`` (no YAML delimiters).
    Lines that are blank, start with a comment prefix (``//``), lack a
    colon, or have a key starting with ``"{[`` are silently skipped.
    Values are coerced to Python types via ``ast.literal_eval`` where
    possible, otherwise kept as strings.
    Returns ``{}`` if no valid key/value lines are found.
    """
    d = {}
    valid_lines = 0
    for line in s.splitlines():
        if not line.strip() or line.startswith(tuple(LINE_PREFIX_IGNORE)):
            continue
        if ":" not in line:
            continue
        key, value = line.split(":", maxsplit=1)
        # Validate that key looks like a frontmatter key (not starting with special chars like { or ")
        key_stripped = key.strip()
        if not key_stripped or key_stripped[0] in '"{[':
            continue
        value = value.strip()
        # Try to convert to appropriate Python type
        try:
            d[key] = ast.literal_eval(value)
        except (ValueError, SyntaxError):
            # Keep as string if literal_eval fails
            d[key] = value
        valid_lines += 1

    # Only treat as frontmatter if we found at least one valid line
    return d if valid_lines > 0 else {}


def load_str(s: str) -> Iterator[TmptData]:
    """Load template from a string, including parsing frontmatter.
    Multiple sections get a bare _local id; versioning is assigned by the registry.
    """

    variables = None  # None if frontmatter is not yet evaluated
    has_frontmatter_block = bool(re.match(r"^\s*---\s*$", s, re.MULTILINE))
    logger.debug(
        "load_str: parsing inline template has_frontmatter=%s",
        has_frontmatter_block,
    )

    if not s.strip():
        tmpt = TmptData(id=LOCAL_TEMPLATE_ID, template=s)
        logger.debug("load_str: loaded empty template id=%s", tmpt.id)
        yield tmpt
        return

    for idx, section in enumerate(re.split(SECTION_DELIMITER, s), start=1):
        # frontmatter not yet evaluated:
        if not section.strip():
            continue  # skip empty sections
        if variables is None and has_frontmatter_block:
            variables = frontmatter_content_to_dict(section)
            if variables:
                # We have frontmatter, so we set variables and continue to next section
                logger.debug(
                    "load_str: parsed frontmatter keys=%s",
                    sorted(k.strip() for k in variables.keys()),
                )
                continue
            # No frontmatter, so go on to yield section as template with empty variables

        _vars = variables or {}
        tmpt = TmptData(
            id=LOCAL_TEMPLATE_ID,
            template=section,
            vars=_vars,
            history=[("frontmatter", dict(_vars))] if _vars else [],
        )
        logger.debug(
            "load_str: loaded template id=%s section_index=%s with_vars=%s",
            tmpt.id,
            idx,
            bool(tmpt.vars),
        )
        yield tmpt


def load_dict(d: dict[str, Any]) -> Iterator[TmptData]:
    known_keys = {f.name for f in fields(TmptData)}
    extra = {k: v for k, v in d.items() if k not in known_keys}
    vars = {**extra, **d.get("vars", {})}
    tmpt = TmptData(id=d.get("id"), template=d.get("template"), vars=vars)
    logger.debug("load_dict: loaded template id=%s", tmpt.id)
    yield tmpt
