from __future__ import annotations

import difflib
from pathlib import Path

from tmpt.exceptions import TmptNotFoundError
from tmpt.tmpt_data import TmptData
from tmpt.tmpt_registry import TmptRegistry


def parse_direct_render_variables(raw_args: list[str]) -> dict[str, str]:
    """Parse render variables from direct command-line arguments.

    Args:
        raw_args: Raw command-line arguments (e.g. --name=value or --name value).

    Returns:
        Dictionary of parsed variables.

    Raises:
        ValueError: If argument format is invalid.
    """
    parsed: dict[str, str] = {}
    i = 0
    while i < len(raw_args):
        token = raw_args[i]
        if not token.startswith("--") or token == "--":
            raise ValueError(
                f"Invalid render argument '{token}'. Use --name=value or --name value."
            )
        body = token[2:]
        if not body:
            raise ValueError(
                f"Invalid render argument '{token}'. Use --name=value or --name value."
            )

        if "=" in body:
            key, value = body.split("=", 1)
            parsed[key] = value
            i += 1
            continue

        key = body
        if i + 1 >= len(raw_args):
            raise ValueError(
                f"Invalid render argument '{token}'. Use --name=value or --name value."
            )
        value = raw_args[i + 1]
        if value.startswith("-"):
            raise ValueError(
                f"Invalid render argument '{token}'. Use --name=value or --name value."
            )
        parsed[key] = value
        i += 2
    return parsed


def suggest_ids(ids: list[str], prompt_id: str) -> list[str]:
    """Return close-match suggestions for a prompt ID."""
    return difflib.get_close_matches(prompt_id, ids, n=5)


def get_with_suggestion(registry: TmptRegistry, prompt_id: str) -> TmptData:
    """Get a prompt by ID, re-raising with suggestions if not found."""
    try:
        return registry.get(prompt_id)
    except TmptNotFoundError as exc:
        suggestions = suggest_ids(registry.list(), prompt_id)
        if suggestions:
            raise TmptNotFoundError(
                f"'{prompt_id}' not found. Did you mean: {', '.join(suggestions)}?"
            ) from exc
        raise


def classify_target(target: str) -> tuple[str, str]:
    """Classify a target as folder, file, or prompt ID.

    Returns:
        Tuple of (kind, resolved_target) where kind is 'folder', 'file', or 'id'.
    """
    candidate = Path(target)
    if candidate.exists():
        if candidate.is_dir():
            return "folder", str(candidate)
        if candidate.is_file():
            return "file", str(candidate)
    return "id", target
