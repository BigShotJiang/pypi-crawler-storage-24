"""Debug view helpers: parse stats and inline-default extraction."""

from __future__ import annotations

import re

from tmpt.tmpt_data import TmptData

_INCLUDE_RE = re.compile(r"\{\{\s*#\s*([\w.\-]+)\s*\}\}")
_EXPR_RE = re.compile(r"\{\{\s*(.*?)\s*\}\}")
_COMMENT_RE = re.compile(r"^[ \t]*//")


def extract_inline_defaults(template: str) -> dict[str, str]:
    """Return {name: default} for every {{ name:default }} expression in the template."""
    result: dict[str, str] = {}
    for m in _EXPR_RE.finditer(template or ""):
        raw = m.group(1).strip()
        if ":" not in raw or _INCLUDE_RE.match("{{" + raw + "}}"):
            continue
        name, default = raw.split(":", 1)
        name = name.strip()
        if re.match(r"[A-Za-z_][A-Za-z0-9_-]*$", name):
            result[name] = default.strip()
    return result


def format_parse_stats(data: TmptData) -> str:
    """Return rich-markup lines/expressions/comments/includes stats (no id, no variables)."""
    template = data.template or ""
    raw_lines = template.splitlines()

    includes: list[str] = []
    comment_count = 0

    for line in raw_lines:
        if _COMMENT_RE.match(line):
            comment_count += 1
            continue
        for m in _EXPR_RE.finditer(line):
            raw = m.group(1).strip()
            inc_m = _INCLUDE_RE.match("{{" + raw + "}}")
            if inc_m:
                inc_id = inc_m.group(1)
                if inc_id not in includes:
                    includes.append(inc_id)

    out: list[str] = []
    out.append(f"\n[dim cyan]lines:[/dim cyan]       {len(raw_lines)}")
    out.append(
        f"[dim cyan]expressions:[/dim cyan] {sum(1 for _ in _EXPR_RE.finditer(template))}"
    )
    if comment_count:
        out.append(f"[dim cyan]comments:[/dim cyan]    {comment_count}")
    if includes:
        out.append("\n[dim cyan]includes:[/dim cyan]")
        for inc in includes:
            out.append(f"  [magenta]{inc}[/magenta]")
    return "\n".join(out)
