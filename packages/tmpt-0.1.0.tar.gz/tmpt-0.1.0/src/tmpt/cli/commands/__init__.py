"""CLI commands package."""

from __future__ import annotations

from tmpt.cli.commands.discover import run_discover
from tmpt.cli.commands.render import run_render
from tmpt.cli.commands.validate import run_validate

__all__ = ["run_discover", "run_render", "run_validate"]
