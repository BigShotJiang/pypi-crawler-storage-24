"""Discover command: show all prompts loaded into the registry with their aliases."""

from __future__ import annotations

from pathlib import Path

from tmpt.cli.output import print_header, print_status
from tmpt.loaders import _first_excluded_folder_part, _first_hidden_part
from tmpt.tmpt_data import TmptData
from tmpt.tmpt_ref import TmptRef
from tmpt.tmpt_registry import TmptRegistry


def run_discover(root: str | None) -> int:
    """Show every prompt discovered by registry.load(path) with its aliases.

    Args:
        root: Folder or file to scan (default: current directory).

    Returns:
        Exit code (0 for success).
    """
    path = Path(root or ".")
    try:
        display_path = path.relative_to(Path.cwd())
    except ValueError:
        display_path = path

    # Load per-file to track provenance, applying the same filters as load_directory
    file_entries: list[tuple[Path, list[TmptData]]] = []
    if path.is_file():
        registry = TmptRegistry()
        templates = registry.load(path)
        if templates:
            file_entries.append((path, templates))
    else:
        for md_file in sorted(path.rglob("*.md")):
            if _first_hidden_part(md_file) or _first_excluded_folder_part(md_file):
                continue
            registry = TmptRegistry()
            templates = registry.load(md_file)
            if templates:
                file_entries.append((md_file, templates))

    # Build name → max_variant map for alias resolution
    all_refs = [TmptRef.from_string(t.id) for _, ts in file_entries for t in ts]
    latest_variant: dict[str, int] = {}
    for ref in all_refs:
        if ref.variant is not None:
            latest_variant[ref.name] = max(latest_variant.get(ref.name, 0), ref.variant)

    total = sum(len(ts) for _, ts in file_entries)
    print_header(
        f"\n[bold cyan]🔍 Discover:[/bold cyan] [yellow]{display_path}[/yellow]"
        f"  [dim]•[/dim]  [magenta]{total}[/magenta] [dim]prompt(s) in"
        f" {len(file_entries)} file(s)[/dim]"
    )

    if not file_entries:
        print_status("•", "No prompts found", "dim")
        return 0

    for md_file, templates in file_entries:
        try:
            rel = md_file.relative_to(Path.cwd())
        except ValueError:
            rel = md_file
        print_header(f"\n  [yellow]{rel}[/yellow]")
        for data in templates:
            ref = TmptRef.from_string(data.id)
            aliases = _aliases(ref, latest_variant)
            alias_str = (
                "  [dim]aliases:[/dim] "
                + "  ".join(f"[green]{a}[/green]" for a in aliases)
                if aliases
                else "  [dim]no aliases[/dim]"
            )
            print_status(
                "  [dim]•[/dim]", f"[bold cyan]{data.id}[/bold cyan]{alias_str}"
            )

    return 0


def _aliases(ref: TmptRef, latest_variant: dict[str, int]) -> list[str]:
    """Return all alternative IDs that resolve to this prompt."""
    result: list[str] = []
    if ref.variant is not None and latest_variant.get(ref.name) == ref.variant:
        result.append(ref.name)
    return result
