"""Validate command implementation."""

from __future__ import annotations

import re
from pathlib import Path

from tmpt.cli.debug_view import extract_inline_defaults, format_parse_stats
from tmpt.cli.highlighting import extract_vars, highlight_template
from tmpt.cli.output import print_columns, print_header, print_status
from tmpt.cli.utils import classify_target, get_with_suggestion
from tmpt.exceptions import TmptNotFoundError
from tmpt.tmpt_data import TmptData
from tmpt.tmpt_registry import TmptRegistry

_INCLUDE_RE = re.compile(r"\{\{\s*#\s*([\w.\-]+)\s*\}\}")


def run_validate(target: str | None) -> int:
    """Run the validate command.

    Args:
        target: Folder path, file path, or prompt ID (default: current directory).

    Returns:
        Exit code (0 for success).
    """
    resolved = target or "."
    kind, path_or_id = classify_target(resolved)
    if kind == "folder":
        _validate_folder(Path(path_or_id))
        return 0
    if kind == "file":
        _validate_file(Path(path_or_id))
        return 0
    _validate_id(str(path_or_id))
    return 0


def _validate_folder(root: Path) -> None:
    """Validate all prompts in a folder."""
    try:
        search_root = root.relative_to(Path.cwd())
    except ValueError:
        search_root = root

    # Load everything into one shared registry so cross-file includes can be validated.
    shared_registry = TmptRegistry()
    file_templates: list[tuple[Path, list[TmptData]]] = []
    for md_file in sorted(search_root.rglob("*.md")):
        templates = shared_registry.load(md_file)
        if templates:
            file_templates.append((md_file, templates))

    print_header("\n[bold cyan]📄 Prompt Files[/bold cyan]")
    if not file_templates:
        print_status("•", "No prompt files found", "dim")
        return

    for md_file, templates in file_templates:
        try:
            rel_path = md_file.relative_to(root)
        except ValueError:
            rel_path = md_file
        print_header(f"\n[yellow]{rel_path}[/yellow]")
        _print_template_columns(templates, shared_registry)


def _validate_file(path: Path) -> None:
    """Validate a single prompt file."""
    if not path.exists() or not path.is_file():
        raise FileNotFoundError(f"File not found: {path}")

    registry = TmptRegistry()
    templates = registry.load(path)
    if not templates:
        raise ValueError(f"Not a supported prompt file: {path}")

    count = len(templates)
    print_header(
        f"\n[bold cyan]📄 File:[/bold cyan] [yellow]{path.name}[/yellow]  "
        f"[dim]•[/dim]  [magenta]{count}[/magenta] [dim]variant(s)[/dim]"
    )
    _print_template_columns(templates, registry)


def _validate_id(prompt_id: str) -> None:
    """Validate a specific prompt by ID."""
    registry = TmptRegistry()
    registry.load(Path("."))
    data = get_with_suggestion(registry, prompt_id)

    print_header(f"\n[bold cyan]🎯 ID:[/bold cyan] [yellow]{prompt_id}[/yellow]")
    _print_template_columns([data], registry)


def _build_summary(data: TmptData, registry: TmptRegistry | None = None) -> str:
    """Build the Prompt Summary panel content for one template."""
    lines = [f"[bold white]{data.id}[/bold white]"]

    var_names = extract_vars(data.template or "")
    all_vars = sorted(set(list(data.vars.keys()) + var_names))
    inline_defaults = extract_inline_defaults(data.template or "")

    lines.append("\n[dim cyan]variables:[/dim cyan]")
    if all_vars:
        for name in all_vars:
            if name in data.vars:
                lines.append(
                    f"  [cyan]{name}[/cyan] = [yellow]{data.vars[name]!r}[/yellow]"
                )
            elif name in inline_defaults:
                lines.append(
                    f"  [cyan]{name}[/cyan] [dim]inline=[yellow]{inline_defaults[name]!r}[/yellow][/dim]"
                )
            else:
                lines.append(f"  [cyan]{name}[/cyan]")
    else:
        lines.append("  [dim]none[/dim]")

    lines.append(format_parse_stats(data))

    # Check include targets against registry
    if registry is not None:
        include_ids = _INCLUDE_RE.findall(data.template or "")
        broken = []
        for inc_id in include_ids:
            try:
                registry.get(inc_id)
            except (TmptNotFoundError, Exception):
                broken.append(inc_id)
        if broken:
            lines.append("\n[bold red]⚠ unresolvable includes:[/bold red]")
            for inc_id in broken:
                lines.append(
                    f"  [red]{{{{#{inc_id}}}}}[/red] [dim]— not found in registry[/dim]"
                )

    return "\n".join(lines)


def _print_template_columns(
    templates: list[TmptData], registry: TmptRegistry | None = None
) -> None:
    for data in templates:
        summary = _build_summary(data, registry)
        template_content = highlight_template(data.template or "")
        print_columns(
            [
                ("Template", template_content, "cyan"),
                ("Prompt Summary", summary, "magenta"),
            ]
        )
