from __future__ import annotations

from pathlib import Path
from typing import Any

from tmpt.cli.debug_view import extract_inline_defaults, format_parse_stats
from tmpt.cli.highlighting import (
    extract_vars,
    highlight_rendered,
    highlight_template,
)
from tmpt.cli.output import print_columns_err, print_header_err, print_panel_err
from tmpt.cli.utils import get_with_suggestion
from tmpt.tmpt import Tmpt
from tmpt.tmpt_data import TmptData
from tmpt.tmpt_registry import TmptRegistry


def run_render(
    prompt_id: str,
    variables: dict[str, str],
) -> int:
    """Run the render command.

    Args:
        prompt_id: Prompt ID to render.
        variables: Parsed variable assignments.

    Returns:
        Exit code (0 for success).

    Raises:
        TmptNotFoundError: If prompt ID not found.
    """
    registry = TmptRegistry()
    registry.load(Path("."))
    data = get_with_suggestion(registry, prompt_id)

    # Share the populated registry with Tmpt so {{#include}} tags resolve.
    Tmpt.registry = registry
    tmpt = Tmpt.from_data(data)
    rendered = tmpt(**variables)
    inline_defaults = extract_inline_defaults(data.template or "")
    final_vars = {**inline_defaults, **data.vars, **variables}

    print_header_err(
        f"\n[bold magenta]🎨 Render:[/bold magenta] [yellow]{prompt_id}[/yellow]  "
        f"[dim]→[/dim]  [cyan]{data.id}[/cyan]"
    )

    details = _build_details(data, variables, registry)
    template_content = highlight_template(data.template or "")
    rendered_content = highlight_rendered(rendered, final_vars)

    print_panel_err("Prompt Details", details, style="magenta")
    columns = [
        ("Template", template_content, "cyan"),
        ("Rendered Prompt", rendered_content, "green"),
    ]
    print_columns_err(columns)

    print(rendered)

    return 0


def _build_details(
    data: TmptData, variables: dict[str, Any], registry: TmptRegistry
) -> str:
    """Build the Prompt Details panel content using var history for provenance."""
    lines = [f"[bold white]{data.id}[/bold white]"]

    # Full history: what the loader recorded + what the CLI adds
    history = list(data.history)
    if variables:
        history.append(("call", variables))

    inline_defaults = extract_inline_defaults(data.template or "")

    # All var names from history entries + template {{ }} expressions
    history_names = {k for _, d in history for k in d}
    template_names = set(extract_vars(data.template or ""))
    all_vars = sorted(history_names | template_names)

    if all_vars:
        lines.append("\n[dim cyan]variables:[/dim cyan]")
        for name in all_vars:
            chain = [(label, vals[name]) for label, vals in history if name in vals]
            if not chain:
                if name in inline_defaults:
                    lines.append(
                        f"  [cyan]{name}[/cyan]: [dim]inline=[yellow]{inline_defaults[name]!r}[/yellow][/dim]"
                    )
                else:
                    lines.append(f"  [cyan]{name}[/cyan] [red]missing[/red]")
                continue
            parts = [
                f"[green]{label}[/green]=[yellow]{val!r}[/yellow]"
                for label, val in chain
            ]
            if len(chain) == 1:
                lines.append(f"  [cyan]{name}[/cyan]: {parts[0]}")
            else:
                chain_str = " [dim]→[/dim] ".join(parts)
                final_val = chain[-1][1]
                lines.append(
                    f"  [cyan]{name}[/cyan]: {chain_str}"
                    f" [dim]→[/dim] final=[bold yellow]{final_val!r}[/bold yellow]"
                )

    lines.append(format_parse_stats(data))

    all_ids = registry.list()
    parts = []
    for rid in all_ids:
        if rid == data.id:
            parts.append(f"[bold magenta]▶ {rid}[/bold magenta]")
        else:
            parts.append(f"[dim cyan]{rid}[/dim cyan]")
    lines.append("\n[dim cyan]registry:[/dim cyan] " + "  [dim]|[/dim]  ".join(parts))

    return "\n".join(lines)
