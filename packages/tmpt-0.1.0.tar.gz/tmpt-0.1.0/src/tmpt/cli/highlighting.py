from __future__ import annotations

import re
from typing import Any


def _add_line_numbers(text: str) -> str:
    """Prepend dim right-aligned line numbers to each line."""
    lines = text.split("\n")
    width = len(str(len(lines)))
    return "\n".join(
        f"[dim]{str(i).rjust(width)}[/dim] {line}" for i, line in enumerate(lines, 1)
    )


def extract_vars(template: str) -> list[str]:
    """Extract variable names referenced in a template."""
    pattern = re.compile(r"\{\{\s*([A-Za-z_][A-Za-z0-9_-]*)\s*(?:[:|][^}]*)?\}\}")
    return sorted(set(m.group(1) for m in pattern.finditer(template or "")))


_WHITESPACE_CHARS = str.maketrans({"\t": "[pink1]→[/pink1]", "\r": "[pink1]␍[/pink1]"})


def highlight_template(template: str) -> str:
    """Color-annotate {{ var }} syntax and visible whitespace in the template."""
    result = re.sub(r"(\{\{[^}]+\}\})", r"[cyan]\1[/cyan]", template or "")
    result = result.translate(_WHITESPACE_CHARS)
    # mark trailing spaces on each line
    result = re.sub(
        r"( +)$",
        lambda m: "[pink1]" + "·" * len(m.group(1)) + "[/pink1]",
        result,
        flags=re.MULTILINE,
    )
    # mark newlines
    result = result.replace("\n", "[pink1]↵[/pink1]\n")
    return _add_line_numbers(result)


def highlight_rendered(rendered: str, variables: dict[str, Any]) -> str:
    """Highlight substituted variable values in rendered output (rich markup)."""
    result = rendered
    # Sort by length descending so longer values are matched before shorter substrings
    for value in sorted(variables.values(), key=lambda v: len(str(v)), reverse=True):
        val = str(value)
        if not val:
            continue
        # Only replace occurrences that are NOT already inside a rich markup tag.
        # Use a negative lookbehind/lookahead to avoid matching inside [tag]...[/tag].
        escaped = re.escape(val)
        result = re.sub(
            rf"(?<!\[)(?<!\w){escaped}(?!\w)(?!\])",
            f"[yellow]{val}[/yellow]",
            result,
        )
    return _add_line_numbers(result)
