from __future__ import annotations

import os
import sys

from tmpt.display import (  # re-export for backwards compatibility
    _strip_markup,
    print_columns,
    print_header,
    print_panel,
    print_status,
)

_RICH_ERR = None


def _get_rich_console_err():  # pragma: no cover - import gated
    if os.getenv("TMPT_NO_RICH") == "1":
        return None
    global _RICH_ERR
    if _RICH_ERR is not None:
        return _RICH_ERR
    try:
        from rich.console import Console
    except ImportError:
        return None
    _RICH_ERR = Console(stderr=True, force_terminal=True)
    return _RICH_ERR


def setup_verbose_logging() -> None:  # pragma: no cover - import gated
    import logging

    c = _get_rich_console_err()
    if c is not None:
        try:
            from rich.logging import RichHandler

            handler = RichHandler(
                console=c,
                show_time=False,
                show_path=True,
                rich_tracebacks=True,
                markup=True,
            )
            handler.setLevel(logging.DEBUG)
            root = logging.getLogger("tmpt")
            root.setLevel(logging.DEBUG)
            root.addHandler(handler)
            return
        except Exception:
            pass
    logging.basicConfig(level=logging.DEBUG, stream=sys.stderr)


def print_header_err(text: str) -> None:
    c = _get_rich_console_err()
    if c is not None:
        c.print(text)
        return
    print(_strip_markup(text), file=sys.stderr)


def print_panel_err(
    title: str, content: str, style: str = "cyan"
) -> None:  # pragma: no cover - import gated
    c = _get_rich_console_err()
    if c is not None:
        try:
            from rich import box as _b
            from rich.panel import Panel

            c.print(
                Panel(
                    content, title=title, border_style=style, expand=True, box=_b.SIMPLE
                )
            )
            return
        except Exception:
            pass
    t = _strip_markup(title)
    print(f"\n{t}", file=sys.stderr)
    print("=" * len(t), file=sys.stderr)
    print(_strip_markup(content), file=sys.stderr)
    print(file=sys.stderr)


def print_columns_err(
    columns: list[tuple[str, str, str]],
) -> None:  # pragma: no cover - import gated
    c = _get_rich_console_err()
    if c is not None:
        try:
            from rich.panel import Panel
            from rich.table import Table
            from rich.text import Text

            table = Table(show_header=False, box=None, padding=0, expand=True)
            for _ in columns:
                table.add_column(ratio=1)
            panels = [
                Panel(Text.from_markup(content), title=title, border_style=style)
                for title, content, style in columns
            ]
            table.add_row(*panels)
            c.print(table)
            return
        except Exception:
            pass
    for title, content, _ in columns:
        t = _strip_markup(title)
        print(f"\n{t}", file=sys.stderr)
        print("=" * len(t), file=sys.stderr)
        print(_strip_markup(content), file=sys.stderr)
        print(file=sys.stderr)


def print_error(text: str) -> None:
    c = _get_rich_console_err()
    if c is not None:
        c.print(f"[bold red]Error:[/bold red] {text}")
        return
    print(f"Error: {text}", file=sys.stderr)
