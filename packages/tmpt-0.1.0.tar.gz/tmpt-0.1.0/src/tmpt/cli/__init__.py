from __future__ import annotations

import argparse
import sys

from tmpt.cli.commands import run_discover, run_render, run_validate
from tmpt.cli.output import print_error, setup_verbose_logging
from tmpt.cli.utils import parse_direct_render_variables
from tmpt.exceptions import TmptNotFoundError, TmptRenderError, TmptSourceParseError

__all__ = ["main"]


def main(argv: list[str] | None = None) -> int:
    """Run the tmpt command-line interface.

    Args:
        argv: Command-line arguments (default: sys.argv[1:]).

    Returns:
        Exit code (0 for success, non-zero for errors).
    """
    normalized = _normalize_argv(argv)
    verbose = "-v" in normalized or "--verbose" in normalized
    if verbose:
        normalized = [a for a in normalized if a not in ("-v", "--verbose")]
        setup_verbose_logging()
    parser = _build_parser()
    args, unknown = parser.parse_known_args(normalized)
    cmd = args.command

    try:
        if unknown:
            if cmd == "render":
                args.variable = parse_direct_render_variables(unknown)
            else:
                parser.error(f"unrecognized arguments: {' '.join(unknown)}")
        elif cmd == "render":
            args.variable = {}

        if cmd == "discover":
            return run_discover(getattr(args, "root", None))
        if cmd == "validate":
            return run_validate(args.target)
        if cmd == "render":
            return run_render(args.prompt_id, args.variable)

    except TmptNotFoundError as exc:
        print_error(str(exc))
        return 1
    except TmptRenderError as exc:
        print_error(str(exc))
        return 2
    except (TmptSourceParseError, FileNotFoundError, ValueError) as exc:
        print_error(str(exc))
        return 1


def _normalize_argv(argv: list[str] | None) -> list[str]:
    raw = list(sys.argv[1:] if argv is None else argv)
    if not raw:
        return ["validate"]
    if raw[0] in {"discover", "validate", "render", "-h", "--help"}:
        return raw
    if raw[0].startswith("-"):
        return raw
    return ["validate", *raw]


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="tmpt", description="Prompt tooling for tmpt."
    )
    sub = parser.add_subparsers(dest="command")

    discover_parser = sub.add_parser(
        "discover",
        help="Show all prompts discovered in a folder with their IDs and aliases.",
    )
    discover_parser.add_argument(
        "root",
        nargs="?",
        default=None,
        help="Folder to scan (default: current directory).",
    )

    validate_parser = sub.add_parser(
        "validate",
        help="Inspect prompts in a folder, single file, or prompt id.",
    )
    validate_parser.add_argument(
        "target",
        nargs="?",
        default=".",
        help="Folder path, file path, or prompt id (default: current directory).",
    )

    render_parser = sub.add_parser("render", help="Render a prompt by id.")
    render_parser.add_argument("prompt_id", help="Prompt id to render.")

    return parser
