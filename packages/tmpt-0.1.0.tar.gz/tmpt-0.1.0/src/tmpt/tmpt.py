from __future__ import annotations

from typing import Any, ClassVar

from ._logging import get_logger
from .render.comments import RendererStripComments
from .render.conditionals import RendererConditionals
from .render.context import RenderContext
from .render.include import RendererInclude
from .render.pipeline import PipelineRenderer
from .render.vars import RendererVars
from .tmpt_data import TmptData
from .tmpt_registry import TmptRegistry
from .types import SourceType

logger = get_logger(__name__)


class TmptMeta(type):
    """Metaclass for class-level ``[]`` get/set syntax."""

    def __getitem__(cls, tmpt_id: str) -> Any:
        return cls.get(tmpt_id)

    def __setitem__(cls, tmpt_id: str, tmpt_or_source: Any) -> None:
        cls.registry.set(tmpt_id, tmpt_or_source)


class TmptDataMeta(TmptMeta):
    """Combined metaclass resolving TmptMeta + dataclass metaclass."""


class Tmpt(TmptData, metaclass=TmptDataMeta):
    """Standalone v2 prompt API.

    The render pipeline is a list of ``RendererBase`` stages in
    ``Tmpt.pipeline``.  Each stage receives the template and vars and returns
    the transformed template.  To extend rendering, subclass ``Tmpt`` and
    override ``pipeline`` with your own list of stages.
    """

    registry: ClassVar[TmptRegistry] = TmptRegistry()
    pipeline: ClassVar[PipelineRenderer] = PipelineRenderer(
        [
            RendererInclude(),
            RendererStripComments(),
            RendererConditionals(),
            RendererVars(),
        ]
    )

    # ------------------------------------------------------------------ #
    # Construction                                                         #
    # ------------------------------------------------------------------ #

    def __init__(
        self,
        source: SourceType = None,
        *,
        id: str | None = None,
        template: str | None = None,
        vars: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> None:

        # Initialize data fields for TmptData parent class
        super().__init__(
            id=id,
            template=template,
            vars=dict(vars or {}),
        )

        if source is not None:
            loaded = self.load(source) or [{}]

            # Assign the first loaded template's data to this instance
            self.update(loaded[0])

        # remaining kwargs are treated as template variables
        self.vars.update(kwargs)

    def __getitem__(self, tmpt_id: str) -> "Tmpt":
        return self.__class__.get(tmpt_id)

    def __call__(self, **vars: Any) -> str:
        ctx: RenderContext = {"registry": self.__class__.registry}
        merged = {**self.vars, **vars}
        history = [*self.history]
        if vars:
            history.append(("call", dict(vars)))
        data = TmptData(
            id=self.id, template=self.template, vars=merged, history=history
        )
        return self.__class__.pipeline.render(data, ctx)

    def __repr__(self):
        return f"""Tmpt(id={self.id!r}, \
vars=[{", ".join(list(self.vars.keys()))}], \
template='{self.template:.10}...', \
registry={", ".join(self.__class__.registry.list())} \
)"""

    # ------------------------------------------------------------------ #
    # Registry                                                             #
    # ------------------------------------------------------------------ #

    @classmethod
    def get(cls, tmpt_id: str) -> "Tmpt":
        return cls.from_data(cls.registry.get(tmpt_id))

    @classmethod
    def list(cls) -> list[str]:
        return cls.registry.list()

    @classmethod
    def clear(cls) -> None:
        cls.registry.clear()

    @classmethod
    def load(cls, source: SourceType) -> list[TmptData]:
        loaded = cls.registry.load(source)
        if loaded:
            logger.debug(
                "Tmpt: loaded %d template(s) from source=%r", len(loaded), source
            )
        else:
            logger.warning("Tmpt: no templates loaded from source=%r", source)
        return loaded
