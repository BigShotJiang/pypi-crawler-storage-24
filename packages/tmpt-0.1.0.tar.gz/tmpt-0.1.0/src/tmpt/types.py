from pathlib import Path
from typing import Any, TypeAlias

SourceType: TypeAlias = str | Path | None | dict[str, Any]
