from __future__ import annotations

import re
from typing import NamedTuple

from .exceptions import TmptValidationError

id_ = re.compile(
    r"^(_)?([A-Za-z][A-Za-z0-9_-]*(?:\.[A-Za-z][A-Za-z0-9_-]*)*)(?:\.([1-9][0-9]{0,4}))?$",
    re.IGNORECASE,
)
LOCAL_TEMPLATE_ID = "_local"


class TmptRef(NamedTuple):
    name: str = LOCAL_TEMPLATE_ID
    variant: int | None = None

    @classmethod
    def from_string(cls, s: str | None) -> TmptRef:
        """Parse 'name.variant<.md>' (or a path/None) into a TmptRef."""
        if s is None:
            return cls()
        s = s.rsplit("/", 1)[-1] if "/" in s else s
        if s.lower().endswith(".md"):
            s = s[:-3]
        m = id_.fullmatch(s)
        if not m:
            raise TmptValidationError(f"Invalid tmpt ID: {s}")
        name = (m.group(1) or "") + m.group(2)
        variant = int(m.group(3)) if m.group(3) else None
        return cls(name, variant)

    def _find_variants(self, existing_keys: list[TmptRef | str]) -> list[int]:
        """Find all existing variant numbers for this base name."""
        result = []
        for k in existing_keys:
            if isinstance(k, str):
                try:
                    k = TmptRef.from_string(k)
                except TmptValidationError:
                    continue
            if k.name == self.name and k.variant is not None:
                result.append(k.variant)
        return result

    def latest(self, existing_keys: list[TmptRef] | None = None) -> TmptRef | None:
        """Get the latest (highest) existing variant as a TmptRef.

        Returns None if no variants exist in the registry.
        """
        existing_keys = existing_keys or []
        variants = self._find_variants(existing_keys)

        if variants:
            return TmptRef(self.name, max(variants))
        return None

    def next(self, existing_keys: list[TmptRef] | None = None) -> TmptRef:
        """Calculate the next variant based on existing IDs in the registry.
        If a variant was explicitly specified in the parsed ID, it takes priority."""
        existing_keys = existing_keys or []
        variants = self._find_variants(existing_keys)

        if variants:
            return TmptRef(self.name, max(variants) + 1)
        if self.variant:
            return TmptRef(self.name, self.variant)
        return TmptRef(self.name, 1)

    def __str__(self) -> str:
        return f"{self.name}.{self.variant}" if self.variant is not None else self.name
