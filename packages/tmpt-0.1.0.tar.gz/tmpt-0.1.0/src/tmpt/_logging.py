from __future__ import annotations

import logging

PACKAGE_LOGGER_NAME = "tmpt"


def _ensure_null_handler() -> None:
    package_logger = logging.getLogger(PACKAGE_LOGGER_NAME)
    if not any(
        isinstance(handler, logging.NullHandler) for handler in package_logger.handlers
    ):
        package_logger.addHandler(logging.NullHandler())


def get_logger(name: str) -> logging.Logger:
    _ensure_null_handler()
    return logging.getLogger(name)


_ensure_null_handler()
