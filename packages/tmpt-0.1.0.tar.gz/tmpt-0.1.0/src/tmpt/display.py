from __future__ import annotations

import os
import re
import sys

_RICH_OUT = None


def _get_rich_console():  # pragma: no cover - import gated
    if os.getenv("TMPT_NO_RICH") == "1":
        return None
    global _RICH_OUT
    if _RICH_OUT is not None:
        return _RICH_OUT
    try:
        from rich.console import Console
    except ImportError:
        return None
    _RICH_OUT = Console()
    return _RICH_OUT


def _strip_markup(text: str) -> str:
    return re.sub(r"\[/?[^\]]+\]", "", text)


def _render_header(text: str) -> None:
    c = _get_rich_console()
    if c is not None:
        c.print(text)
        return
    print(_strip_markup(text))


def _render_panel(  # pragma: no cover - import gated
    title: str,
    content: str,
    style: str,
    *,
    expand: bool = True,
    box=None,
) -> None:
    c = _get_rich_console()
    if c is not None:
        try:
            from rich.panel import Panel

            kwargs: dict = {"title": title, "border_style": style, "expand": expand}
            if box is not None:
                kwargs["box"] = box
            c.print(Panel(content, **kwargs))
            return
        except Exception:
            pass
    t = _strip_markup(title)
    print(f"\n{t}")
    print("=" * len(t))
    print(_strip_markup(content))
    print()


def _render_columns(  # pragma: no cover - import gated
    columns: list[tuple[str, str, str]],
) -> None:
    c = _get_rich_console()
    if c is not None:
        try:
            from rich.panel import Panel
            from rich.table import Table
            from rich.text import Text

            table = Table(show_header=False, box=None, padding=0, expand=True)
            for _ in columns:
                table.add_column(ratio=1)
            panels = [
                Panel(Text.from_markup(content), title=title, border_style=style)
                for title, content, style in columns
            ]
            table.add_row(*panels)
            c.print(table)
            return
        except Exception:
            pass
    for title, content, _ in columns:
        t = _strip_markup(title)
        print(f"\n{t}")
        print("=" * len(t))
        print(_strip_markup(content))
        print()


def print_panel(title: str, content: str, style: str = "cyan") -> None:
    _render_panel(title, content, style, expand=False)


def print_columns(columns: list[tuple[str, str, str]]) -> None:
    _render_columns(columns)


def print_status(icon: str, message: str, color: str = "white") -> None:
    c = _get_rich_console()
    if c is not None:
        c.print(f"[{color}]{icon}[/{color}] {message}")
        return
    print(f"{icon} {message}")


def print_header(text: str) -> None:
    _render_header(text)
