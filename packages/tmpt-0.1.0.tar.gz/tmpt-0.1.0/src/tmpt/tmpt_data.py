from __future__ import annotations

from dataclasses import dataclass, field, fields
from pathlib import Path
from typing import Any

from .exceptions import TmptFileNotFoundError, TmptNotFoundError


@dataclass(kw_only=True, eq=False)
class TmptData:
    """Tmpt data with data operations."""

    id: str | None = None
    template: str | None = None
    vars: dict[str, Any] = field(default_factory=dict)
    history: list[tuple[str, dict[str, Any]]] = field(
        default_factory=list, compare=False, repr=False
    )
    source_path: Path | None = field(default=None, compare=False, repr=False)
    source_mtime: float | None = field(default=None, compare=False, repr=False)

    __hash__ = None  # unhashable; eq is defined below

    def __eq__(self, other: object) -> bool:
        if isinstance(other, TmptData):
            return (
                self.id == other.id
                and self.template == other.template
                and self.vars == other.vars
            )
        if isinstance(other, str):
            return self.template == other
        return NotImplemented

    def is_stale(self, mtime: float | None = None) -> bool:
        """Return True if the source file has been modified or deleted since load. Optionally compare against a provided mtime instead of the current file mtime."""
        if self.source_path is None or self.source_mtime is None:
            return False
        mtime = mtime or self.source_path.stat().st_mtime

        # if not self.source_path.exists():
        #     raise TmptFileNotFoundError(f"{self.source_path=} not found {self.id=}")
        return mtime != self.source_mtime

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "template": self.template,
            "vars": self.vars,
        }

    @classmethod
    def from_data(cls, data: TmptData) -> TmptData:
        """Construct an instance from a TmptData object, bypassing __init__."""
        obj = cls.__new__(cls)
        TmptData.__init__(obj)
        obj.update(data)
        return obj

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TmptData:
        return cls(**data)

    def update(self, data: TmptData | dict[str, Any]) -> None:
        if isinstance(data, TmptData):
            for f in fields(TmptData):
                setattr(self, f.name, getattr(data, f.name))
        else:
            for key, value in data.items():
                if hasattr(self, key):
                    setattr(self, key, value)
