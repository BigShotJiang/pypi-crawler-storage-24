from __future__ import annotations


class TmptError(Exception):
    """Base exception for all tmpt.v2 domain errors."""


class TmptFileNotFoundError(FileNotFoundError, TmptError):
    """Raised when a requested file does not exist."""


class TmptValidationError(ValueError, TmptError):
    """Base validation error for invalid inputs/state."""


class TmptSourceParseError(TmptError):
    """Raised for invalid prompt source strings."""


class TmptNotFoundError(KeyError, TmptError):
    """Raised when a requested prompt id/selector does not exist."""


class TmptRenderError(TmptError):
    """Raised for template rendering failures."""
