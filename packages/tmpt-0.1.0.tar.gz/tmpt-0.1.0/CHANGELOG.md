# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/),
and this project adheres to [Semantic Versioning](https://semver.org/).

## [0.1.0] - 2026-03-14

### Added

- Core `Tmpt` class with file-based and inline prompt management
- Template syntax: variable substitution (`{{ var }}`), defaults (`{{ var:default }}`), conditionals (`{{ ? var }}` / `{{ ! var }}`), includes (`{{#id}}`), comments (`// ...`)
- Multi-variant support: multiple sections per file, numbered files (`prompt.1.md`, `prompt.2.md`)
- `TmptRegistry` with mtime-based caching for file-backed templates
- Extensible render pipeline (`PipelineRenderer`, `RendererBase`)
- CLI commands: `validate`, `render`, `discover`
- Optional Rich output (`pip install "tmpt[rich]"`)
- Zero runtime dependencies — standard library only
