# Conditionals renderer — state machine design

## Syntax

Block directives occupy their own line (surrounded by blank lines):

```
{{ ? <var> }}  — include the following block if var is set and non-empty
{{ ! <var> }}  — include the following block if var is NOT set / empty
```

The body of a block is all lines between the directive and the next blank line
or bare `#` fence. The fence is consumed; the blank line is preserved.

Inline directives are embedded within a content line:

```
{{ ? var }}  — var exists: replace tag with value; missing: delete entire line
{{ ! var }}  — var missing: remove tag; var exists: delete entire line
```

---

## Two designs considered

### Design A — pair-based (rejected)

Invented from the `with_next` / sliding-window idea: iterate `(cur, nxt)` pairs,
derive the current state from the pair's line types, and maintain separate dicts
for entry conditions (`states`) and exit conditions (`back_to_pass`).

```python
states = {
    "skip_in_paragraph": ("is_token", "is_text"),
    "skip_in_heading":   ("is_token", "is_heading"),
}
back_to_pass = {
    "skip_in_paragraph": ("is_text",    "is_empty"),
    "skip_in_heading":   ("is_empty",   "is_heading"),
}

state = "pass"
for cur, nxt in with_next(lines):
    cur_state = state_classify(line_type(cur), line_type(nxt))
    if cur_state != "pass":
        state = cur_state
    if check_back_to_pass(state, line_type(cur), line_type(nxt)):
        state = "pass"
    if state == "pass":
        out += cur
```

**Problems:**

- Entry and exit logic live in two separate data structures. Adding a new block
  type requires editing both — easy to get out of sync.
- State is re-derived each iteration from `(cur_type, nxt_type)` *and* stored in
  a variable, producing two sources of truth.
- Context evaluation (`_eval(cond, context)`) has no natural hookup point; the
  pair's line types alone cannot determine whether to show or hide a block.
- `with_next` materialises one extra line ahead at all times, adding conceptual
  overhead that is unnecessary — blocks end at blank lines, so no lookahead is
  needed.

---

### Design B — explicit transition table (chosen)

One carried `state` variable, one `_TRANSITIONS` dict keyed on
`(state, line_type)`. Each entry is a callable:

```
(line, context) -> (next_state, emit | None)
```

```python
state = _State.NORMAL
for line in lines:
    state, emit = _TRANSITIONS[state, _classify(line)](line, context)
    if emit is not None:
        yield emit
```

The full table:

```python
_TRANSITIONS = {
    # NORMAL: pass through, or enter a block
    (NORMAL, "directive"): lambda l, ctx: (SHOW if _eval(...) else HIDE, None),
    (NORMAL, "text"):      lambda l, ctx: (NORMAL, _apply_inline(l, ctx)),
    (NORMAL, "blank"):     lambda l, ctx: (NORMAL, l),
    (NORMAL, "fence"):     lambda l, ctx: (NORMAL, None),
    # SHOW: emit body lines, stop at boundary
    (SHOW,   "text"):      lambda l, ctx: (SHOW,   _apply_inline(l, ctx)),
    (SHOW,   "blank"):     lambda l, ctx: (NORMAL, l),
    (SHOW,   "fence"):     lambda l, ctx: (NORMAL, None),
    # HIDE: drop body lines, stop at boundary
    (HIDE,   "text"):      lambda l, ctx: (HIDE,   None),
    (HIDE,   "blank"):     lambda l, ctx: (NORMAL, None),
    (HIDE,   "fence"):     lambda l, ctx: (NORMAL, None),
}
```

**Why it was chosen:**

- **Single source of truth.** The table is the complete specification. Every
  reachable `(state, line_type)` combination has exactly one row.
- **Context evaluation is natural.** `_eval(cond, context)` lives inside the
  NORMAL→directive lambda — no special wiring needed.
- **Strictly additive extension.** Adding a new directive means: add a `_State`
  value, add a `_LINE_TYPES` entry, add rows to `_TRANSITIONS`. Nothing else
  changes.
- **Entry and exit are co-located.** The full lifecycle of each state is visible
  by reading the rows with that state as the key.
- **One source of state.** The `state` variable is the only place state lives;
  no re-derivation per pair.

---

## Extensibility example

To add a `{{ for x in list }}` directive:

1. Add `_State.FOR_LOOP` to the `_State` enum.
2. Add `"for_directive"` to `_LINE_TYPES`.
3. Add rows to `_TRANSITIONS`:
   ```python
   (NORMAL,   "for_directive"): lambda l, ctx: (FOR_LOOP, None),
   (FOR_LOOP, "text"):          lambda l, ctx: (FOR_LOOP, _render_for_body(l, ctx)),
   (FOR_LOOP, "blank"):         lambda l, ctx: (NORMAL,   l),
   (FOR_LOOP, "fence"):         lambda l, ctx: (NORMAL,   None),
   ```

No existing rows are touched.
