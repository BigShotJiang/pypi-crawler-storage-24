# CLI

`tmpt` ships with a command-line interface. The default command is `validate`.

## Usage

```bash
tmpt [command] [options]
```

Add `-v` / `--verbose` to any command for debug logging.

## Commands

### `validate`

Inspect prompt files. This is the default command when none is specified.

```bash
# Validate all prompts in the current directory
tmpt
tmpt validate

# Validate all prompts in a specific folder
tmpt validate ./prompts

# Validate a single file
tmpt validate ./prompts/summarize.md

# Look up a specific prompt ID
tmpt validate summarize.last
```

For a **folder**, `tmpt` discovers all prompt files recursively and displays each with its ID, variant count, and variables.

For a **file**, it shows detailed info: sections, IDs, variables, and defaults.

For a **prompt ID**, it searches the current directory for the matching template and displays its details.

### `render`

Render a prompt by ID with variables and display both the raw template and the rendered output.

```bash
tmpt render summarize --variable topic="incident response"
tmpt render release_notes.last --variable product="tmpt" --variable version="0.2.0"
```

Variables can also be passed as positional `key=value` pairs:

```bash
tmpt render summarize topic="incident response" tone="formal"
```

### `discover`

List all prompts discovered in a path with their IDs and aliases.

```bash
tmpt discover
tmpt discover ./prompts
```

## Rich output

Install `rich` for syntax-highlighted, colorful output:

```bash
pip install "tmpt[rich]"
```

Set `TMPT_NO_RICH=1` to disable Rich output even when installed.