# Roadmap

Planned features and improvements for tmpt, roughly in priority order.

## v0.2 — Strict & safe rendering

> Conditionals, comments, and `#` stripping shipped in v0.1.

- **Strict mode**
  Opt-in flag where referencing an undefined variable raises `RenderError` 
  instead of leaving the tag in place. Catches typos before they reach an LLM.

- **`max_output_chars` limit**
  Hard cap on rendered output length — prevents runaway large renders from 
  blowing up token budgets.

- **Auto-reload on access**
  The registry already tracks `mtime` and exposes `is_stale()`. Wire it into 
  `Tmpt["id"]` so changed files are transparently reloaded on next access — 
  critical for notebook / REPL workflows.

## v0.3 — Template functions & expressions

- **Template functions** `{{ fn(args) }}`
  Curated, sandboxed built-in functions callable inside `{{ }}` tags:
  - **Text**: `truncate`, `slugify`, `normalize_ws`, `upper`, `lower`
  - **List**: `unique`, `join`, `take`, `sort`
  - **JSON**: `dumps`, `loads`
  - **Stats**: `words`, `chars`, `tokens` (estimated)
  - **Limits**: `limit_words`, `limit_chars`, `limit_lines`

- **Pipe syntax** `{{ var | fn }}`
  Chain transformations: `{{ body | truncate(200) | upper }}`. Reads naturally 
  left-to-right and composes well with multiple functions.

- **Plugin system**
  `TmptPlugin` base class for third-party packages to register custom template 
  functions and hook into initialization.

## v0.4 — Registry intelligence

- **Duplicate ID detection**
  Report when the same `id` appears across different files instead of silently 
  overwriting.

- **Deprecated variant filtering**
  `deprecated: true` in frontmatter excludes a variant from alias resolution 
  and `list()`.

- **Tag filtering**
  `Tmpt.list(tag="summarization")` to filter the registry by frontmatter tags.

- **`exists(id)`**
  Fast boolean check for whether a prompt is registered.

## v0.5 — Developer experience

- **Render trace / debug output**
  Record `(stage, before, after)` tuples for every pipeline step — enables 
  step-by-step inspection in notebooks and CLI.

- **`snapshot()`**
  Return `{id, template, rendered, vars, hash}` — a stable record of one 
  render invocation for logging, auditing, or golden-test comparison.

- **`diff(a, b)`**
  Human-readable diff between two variant renders or two snapshots.

- **Annotated template view** (CLI)
  Show the raw template with each `{{ expr }}` annotated by its resolved 
  value — useful for debugging complex prompts with many variables.

## v0.6 — Performance

- **Template compilation & caching**
  Parse templates once into a compiled representation and cache it, so 
  repeated renders skip regex matching entirely.

- **LRU render-result cache**
  Thread-safe LRU cache keyed by `(id, frozen_vars)` for instant cache hits 
  on identical repeated renders.

## v0.7 — Prompt engineering toolkit

- **A/B test helper**
  `Tmpt.ab("prompt", vars)` renders all variants and returns a list of 
  `(variant_id, rendered)` pairs — makes it trivial to compare wording changes.

- **Token estimation**
  `tmpt.estimate_tokens()` returns an approximate token count for the rendered 
  output (cl100k / o200k-based). Useful for budget checks before API calls.

- **Model hints in frontmatter**
  `model: gpt-4o`, `temperature: 0.2` — metadata that can be read by 
  application code to configure the LLM call, keeping prompt and settings 
  co-located.

- **Cost estimation**
  Combine token estimation with per-model pricing tables to show projected 
  cost per render — surfaces budget impact early during prompt iteration.

## v0.8 — Composability & reuse

- **Section selector** `id."Section heading"`
  Retrieve just one markdown heading section from a prompt instead of the full 
  template — enables large reference documents as prompt sources.

- **Prompt inheritance**
  `class DetailedSummary(Tmpt["summarize"]): ...` — extend a registered 
  prompt with additional context or overrides without copy-pasting.

- **Shared variable packs**
  Define reusable variable sets (`vars/production.yml`, `vars/dev.yml`) and 
  apply them in bulk: `Tmpt["prompt"](pack="production")`.

## Future / exploring

- **Prompt linting**
  Static analysis rules: warn on unused variables, unreachable conditional 
  branches, includes that reference non-existent IDs.
- **Prompt versioning with git**
  `tmpt history prompt` — show the git log of changes to a prompt file, with 
  rendered diffs between commits.
- **Prompt playground** (CLI / web)
  Interactive REPL or browser UI where you edit a prompt and see the rendered 
  output live with variable sliders.
- **Multi-format loading** — `.yaml` and `.txt` prompt file support alongside 
  `.md`.
- **Image embedding** `image_base64(path)` — read and embed images as base64 
  for multimodal prompts.
- **Prompt evaluation hooks**
  Register a scoring function (`score(rendered, response) -> float`) and track 
  quality across variants over time.
- **Export to LangChain / LlamaIndex**
  `tmpt.to_langchain()` → `ChatPromptTemplate` or `PromptTemplate` for 
  seamless integration with popular frameworks.
- **Watch mode**
  `tmpt watch ./prompts` — monitor a folder and re-validate/re-render on 
  every save, with desktop notifications on errors.
