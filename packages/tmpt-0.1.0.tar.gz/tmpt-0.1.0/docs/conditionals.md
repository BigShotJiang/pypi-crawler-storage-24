Idea is to use new operation in template: `{{ if <variable> }}` alias: `{{ ? <variable> }}`

It should work as following:

If <variable> is set and is not None or empty:

1. Paragraph condition:
```

{{ if my_variable }}
This is a paragraph {{ title }} which will be rendered if `my_variable` is set

This will be rendered no matter what.
```

2. Section condition:

```
{{ ? my_variable }}
## Section 1
This is conditional section


something here which depends on my_variable


# Section
This wil be rendered
nomatter what because is out of scope of the condition
```
3. SEction can be just an empty #

```
{{ ? not my_variable }}
This line will be rendered if my_variable is not declared or is empty or none

{{ ? my_variable }}
# Is set
This

section will be rendered when my_variable is set

#
as we have #, it ends condition scope so this will be rendered
```


4. End of document
```
This is some content to be rendered

{{ ? my_var }}


this is gated


everything til the end of doc is rendered conditionally
```