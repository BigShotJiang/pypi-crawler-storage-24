# Variants

Variants let you store multiple versions of a prompt under the same base name. This is useful for A/B testing, iterating on prompt wording, or keeping a history of changes.

## ID resolution

Every prompt has an **ID** made up of a base name and an optional numeric variant suffix:

| Example ID | Base name | Variant |
|---|---|---|
| `summarize` | `summarize` | (none — resolves to latest) |
| `summarize.1` | `summarize` | 1 |
| `summarize.2` | `summarize` | 2 |
| `summarize.last` | `summarize` | highest registered variant |

When you access a prompt without a variant suffix, the **latest** (highest-numbered) variant is returned.

## One file, one prompt

A file named `prompt.md` with a single section (with or without frontmatter) is registered as:

- `prompt` / `prompt.1`

If frontmatter contains `id: my_prompt`, it is also accessible as `my_prompt` / `my_prompt.1`.

## One file, multiple sections

Sections are separated by `---`. Each section becomes its own variant:

```markdown
---
variable: hello
---

This is the first variant {{ variable }}

---

This is the second variant {{ variable }}
```

| Content | Accessible via |
|---|---|
| First section | `prompt`, `prompt.1` |
| Second section | `prompt.2`, `prompt.last` |

## Numbered files

Files named `prompt.1.md`, `prompt.2.md`, etc. are treated as explicit variants:

| File | Accessible via |
|---|---|
| `prompt.1.md` | `prompt`, `prompt.1` |
| `prompt.2.md` | `prompt.2` |
| Highest-numbered file | `prompt.last` |

Numbered files should **not** contain an `id` in frontmatter or multiple sections — the variant number comes from the filename.

## Rules

- If an `id` in frontmatter already contains a variant number (e.g. `id: my_prompt.3`), a validation error is raised.
- If two files resolve to the same ID, the later-loaded one wins.
- Only files matching `name.md` or `name.N.md` (where N is an integer) are recognized as prompt files.
