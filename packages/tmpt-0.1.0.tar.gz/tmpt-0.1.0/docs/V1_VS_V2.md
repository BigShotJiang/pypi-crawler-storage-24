# v1 vs v2 Feature Comparison

## Template Syntax

| Feature | Description | v1 | v2 |
|---|---|---|---|
| Variable substitution `{{ var }}` | Replace `{{ name }}` with a runtime value from the vars dict. | ✅ | ✅ |
| Default values `{{ var:default }}` | Fall back to a literal value when the variable is not provided. `{{ lang:English }}` → `English`. | ✅ | ✅ |
| Include other prompts | Embed the rendered text of another registered prompt by ID. v1: `{{ include("other.id") }}`; v2: `{{#other.id}}`. | ✅ (via expr eval) | ✅ `{{#id}}` |
| Conditional blocks | Whole-line `{{ if cond }}` / `{{ ? cond }}` / `{{ ! cond }}` directives that show or hide sections based on variable truthiness. | ✅ | ✅ |
| Inline conditionals | Same conditional logic but within a line, not requiring the directive to occupy its own line. | ✅ | ✅ |
| Line comments `//` | Lines starting with `//` are stripped from the final output, allowing editorial notes in templates. | ✅ | ✅ |
| Standalone `#` line stripping | Lines that consist only of a `#`-tag expression (e.g. after conditional removal) are cleaned up to avoid blank lines. | ✅ | ✅ |
| Function calls `{{ fn(args) }}` | Call a registered Python function inside a template expression, e.g. `{{ uuid.uuid4() }}` or `{{ text.truncate(body, 200) }}`. | ✅ | ❌ |
| Expression evaluation | General expression parser that supports attribute access, function calls, and basic arithmetic inside `{{ }}` tags. | ✅ | ❌ |

## Built-in Template Functions

Available inside `{{ }}` expressions in v1. None are available in v2 yet.

| Category | Functions | Description |
|---|---|---|
| Text | `truncate(val, n)`, `slugify(val)`, `normalize_ws(val)`, `lines(val, start, end)` | Common string transformations: truncate with ellipsis, convert to ASCII slug, collapse whitespace, slice lines. |
| List | `unique(lst)`, `join(lst, sep)`, `take(lst, n)`, `sort(lst)` | Manipulate list values before rendering: deduplicate, join to string, take first N, sort. |
| Time | `now_utc_iso()`, `now_unix()`, `format(ts, fmt)` | Inject current timestamp or format a Unix timestamp into the template. |
| Encoding | `base64(val)` | Base64-encode a value, useful for embedding binary content. |
| Hashing | `sha256(val)` | SHA-256 hex digest of a value, useful for cache keys or fingerprints. |
| JSON | `dumps(obj)`, `loads(str)` | Serialize/deserialize JSON within a template expression. |
| Stats | `lines(val)`, `chars(val)`, `words(val)`, `tokens(val)` | Count lines, characters, words, or estimated tokens (~4 chars/token) in a value. |
| Limits | `limit_words(val, n)`, `limit_chars(val, n)`, `limit_lines(val, n)` | Hard-trim a value to at most N words/chars/lines. |
| Image | `image_base64(path)` | Read an image file and embed it as a base64 string. |

## Registry & Loading

| Feature | Description | v1 | v2 |
|---|---|---|---|
| Load from folder | Recursively scan a directory for `.md`, `.yaml`, and `.txt` prompt files and register all found prompts. | ✅ | ✅ |
| Load from single file | Load prompts from one specific file path. | ✅ | ✅ |
| Load from string/inline | Register a prompt directly from a Python string without touching the filesystem. | ✅ | ✅ |
| YAML frontmatter parsing | Parse `---` delimited YAML at the top of `.md` files to extract `id`, `vars`, `defaults`, `tags`, and other metadata. | ✅ | ✅ |
| `.md`, `.yaml`, `.txt` formats | Prompt files can be plain text, markdown with frontmatter, or YAML. | ✅ | partial (`.md` only) |
| Variant separator `--- variant ---` | A single file can contain multiple prompt variants separated by `--- variant ---`, each becoming its own registered entry. | ✅ | ✅ |
| Auto-reload on file change | Registry tracks file `mtime` and transparently reloads changed files on next access — useful for interactive development. | ✅ | partial (mtime caching in `load()`, `is_stale()` available but no auto-trigger on access) |
| Variant alias resolution | Bare name `summarize` automatically resolves to the highest-versioned non-deprecated variant (e.g. `summarize.2`). | ✅ | ✅ |
| Deprecated variant filtering | Variants marked `deprecated: true` in frontmatter are excluded from alias resolution and listing. | ✅ | ❌ |
| Duplicate ID detection | Registry scans all files and reports when the same `id` appears more than once across different files. | ✅ | ❌ |
| Section selector `id."Section"` | Retrieve just one markdown heading section from a prompt instead of the full template. e.g. `summarize."Examples"`. | ✅ | ❌ |
| Defaults from frontmatter | Variables declared with values in frontmatter `defaults:` become fallback values at render time. | ✅ | ✅ |
| Tags / rich metadata | Prompts can carry `tags`, `model_hints` (temperature, model name, etc.), `name`, `created_at`, and arbitrary `metadata`. | ✅ | partial (via raw `vars`) |

## Render Engine

| Feature | Description | v1 | v2 |
|---|---|---|---|
| Template compilation & caching | Templates are parsed once into a `CompiledTemplate` (list of `(kind, chunk)` pairs) and cached, so repeated renders skip parsing. | ✅ | ❌ (interpreted each call) |
| LRU render-result cache | Thread-safe LRU cache stores the final rendered string for a given `(id, vars)` pair, returning it immediately on cache hit. | ✅ | ❌ |
| Strict mode | In strict mode, referencing an undefined variable raises `RenderError` instead of leaving the tag in place. | ✅ | ❌ (leaves tag unchanged) |
| `max_output_chars` limit | Hard cap on the length of the rendered output; raises `RenderError` if exceeded, preventing runaway large renders. | ✅ | ❌ |
| Render trace / debug output | The renderer can record a trace list of `(kind, expr, value)` tuples for every token, enabling step-by-step inspection. | ✅ | ❌ |
| Extensible pipeline | Render is driven by an ordered `PipelineRenderer` list; each stage receives the current template and transforms it. New stages can be added without touching core code. | ❌ | ✅ |
| Custom renderer stages | Implement `RendererBase.render()` to create a reusable transformation step (e.g. include resolution, variable injection, post-processing). | ❌ | ✅ |

## API Shape

| Feature | Description | v1 | v2 |
|---|---|---|---|
| Manager / client pattern | `Tmpt("./prompts/")` instantiates a manager bound to a folder; all operations go through that instance. | ✅ | ❌ |
| Class-based usage | Define prompt types as `class MyPrompt(Tmpt): template = "..."` — class IS the prompt, instances hold per-call state. | partial | ✅ |
| `Tmpt["id"]` get/set | Bracket syntax to get a `TmptRef` by id or register a new prompt: `Tmpt["greet"] = "Hello {{ name }}"`. | ✅ | ✅ |
| `tmpt()` render call | Calling a prompt instance renders it: `tmpt(name="Alice")` → `"Hello Alice"`. | ✅ | ✅ |
| `TmptRef` (lazy reference) | A lightweight handle to a registered prompt that defers template resolution until render time. | ✅ (`PromptRef`) | ✅ (`TmptRef`) |
| `from_dict` / `to_dict` | Serialize/deserialize a `Tmpt` instance to/from a plain dict, useful for storage or API payloads. | ✅ | ✅ |
| `from_data` | Construct a `Tmpt` instance directly from a `TmptData` dataclass. Used internally by the registry `[]` accessor. | ✅ | ✅ |
| `new()` | Return a fresh instance of the same class: `tmpt.new(template="...")`. Useful in subclassing workflows. | ❌ | ✅ |
| `update()` | Apply a dict of attribute values to an existing instance in place. | ❌ | ✅ |
| `exists(id)` | Fast boolean check for whether a prompt id is registered. | ✅ | ❌ |
| `reload()` | Force re-scan of the source folder and refresh the registry from disk. | ✅ | ❌ |
| `validate()` | Inspect all loaded prompts for issues (duplicate ids, unresolvable includes, bad frontmatter) and return a list of `Issue` objects. | ✅ | partial |
| `snapshot()` | Return `{prompt, rendered, vars, hash}` — a stable record of one render invocation for logging or golden-test comparison. | ✅ | ❌ |
| `diff(id, a, b)` | Show a human-readable diff between two variant renders. | planned | ❌ |
| `list(tag=None)` | Return all registered prompt ids, optionally filtered by tag. v2 has no tag filter. | ✅ | ✅ (no tag filter) |
| History tracking | Each render call appends `("call", vars)` to the instance's history list, preserving the sequence of invocations. | ❌ | ✅ |
| Plugin system | `TmptPlugin` base class allows third-party packages to register custom template functions and hook into manager init. | ✅ | ❌ |

## CLI

| Feature | Description | v1 | v2 |
|---|---|---|---|
| `tmpt render <id> --var=val` | Render a registered prompt to stdout, passing variables as `--key=value` flags. | ✅ | ✅ |
| `tmpt validate <target>` | Validate a file, folder, or prompt id and print any issues found. | ✅ | ✅ |
| Rich / syntax-highlighted output | Uses the `rich` library (when available) to colorize the rendered output and variable names in the terminal. | ✅ | ✅ |
| Annotated template view | Shows the raw template with each expression annotated by its resolved value and type, useful for debugging. | ✅ | ❌ |
| Parse report | Prints a structural breakdown of a template: variables referenced, includes, conditionals, function calls. | ✅ | ❌ |
| Variable details panel | Side-by-side panel showing each variable name, its source (frontmatter / call-time / default), and its value. | ✅ | partial (variable history chain shown in render output) |
| `argparse`-based CLI | CLI is built on stdlib `argparse`, keeping the dependency footprint minimal. | ✅ | ✅ |

## Architecture

| Aspect | Description | v1 | v2 |
|---|---|---|---|
| Core abstraction | The central object users interact with. v1 is a stateful manager tied to a folder; v2 is a class that IS the prompt. | `PromptManager` + `PromptRef` | `Tmpt` class + `TmptRegistry` |
| Data model | The internal dataclass carrying prompt state. v1 has rich metadata fields; v2 is minimal (id, template, vars, history). | `Prompt` (rich metadata) | `TmptData` (minimal) |
| Render extension point | How the render pipeline can be customized. v1 has no extension point; v2 uses a `UserList` of `RendererBase` stages. | none (monolithic) | `PipelineRenderer` + `RendererBase` |
| Metaclass | `TmptMeta(type)` enables class-level `Tmpt["id"]` bracket access without inheriting from `dict` or `UserDict`. | none | `TmptMeta` (`type`) |
| Loaders | How files are read and parsed. v1 has a dedicated `loaders/` module with separate fs, frontmatter, and literal coercion layers. | `loaders/` module | single `loaders.py` |
| Exceptions | v1 defines a typed hierarchy (`RenderError`, etc.); v2 consolidates into one `exceptions.py`. | typed hierarchy | single `exceptions.py` |
| Tests | Scale of automated test coverage. | 6 suites, 1800+ lines | modular, 409+ tests |
