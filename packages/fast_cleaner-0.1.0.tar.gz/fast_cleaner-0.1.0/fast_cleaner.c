// 1. 引入 Python 底层的头文件（我们之前提到过的）
#include <Python.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>
// 2. 这就是那个传说中的“标准 C 签名”
PyObject *clean_text(PyObject *self, PyObject *args)
{
    static char lookup[256];    // 256个坑位，对应所有ASCII码
    static int initialized = 0; // 就像一个开关，初始是关着的

    if (!initialized)
    {
        for (int i = 0; i < 256; i++)
        {
            if (ispunct(i))
            {
                lookup[i] = 0;
            }
            else
            {
                lookup[i] = 1;
            }
        }
        initialized = 1; // 走完一遍，把开关永久打开
    }
    PyObject * input_obj; // 1. 声明接收器
    int mode = 0;
    // 2. 更换解包暗号为 "U"，只要传一个接收器
    if (!PyArg_ParseTuple(args, "U|i", &input_obj,&mode))
    {
        return NULL;
    }

    // 3. 直接看透它的绝对长度
    Py_ssize_t length = PyUnicode_GET_LENGTH(input_obj);
    Py_UCS4 *buffer = (Py_UCS4 *)malloc(length * sizeof(Py_UCS4));

    // 2. 记录新本子写到了第几个字
    Py_ssize_t out_len = 0;

    // 3. 上帝视角遍历（不要再用 while(*r) 这种盲人摸象的指针了）
    for (Py_ssize_t i = 0; i < length; i++)
    {
        // 直接抓取第 i 个字的绝对编号（码点）
        Py_UCS4 ch = PyUnicode_READ_CHAR(input_obj, i);
        if (ch<=127)
        {
            if(lookup[ch]) {buffer[out_len++] = ch;}
        }
        if (ch > 127)
        {
            int is_punct = 0; // 先假设它是好人（旗子放下）

            // 1. 基础防线（中英文标点、Emoji 等）
            // 注意：这里不再用 ! 取反了，只要命中，就把旗子举起来
            if ((0x3000 <= ch && ch <= 0x303F) ||
                (0xFF00 <= ch && ch <= 0xFF20) ||
                (0x2000 <= ch && ch <= 0x206F) ||
                (0x1F300 <= ch && ch <= 0x1FAD7) ||
                (0x2600 <= ch && ch <= 0x27BF) ||
                (0xFE00 <= ch && ch <= 0xFE0F))
            {
                is_punct = 1; // 发现基础标点！举旗！
            }

            // 2. 强迫症防线（只有当 mode == 1 时才开启扫描）
            if (mode == 1)
            {
                if (ch == 0x00A1 || ch == 0x00BF ||               // 西班牙语 ¡ 和 ¿
                    ch == 0x060C || ch == 0x061B || ch == 0x061F) // 阿拉伯语 、 ； ？
                {
                    is_punct = 1; // 发现小语种标点！举旗！
                }
            }

            // 3. 终极判决：如果旗子依然是放下的（0），说明是干干净净的文字！
            if (is_punct == 0)
            {
                buffer[out_len++] = ch; // 抄录！
            }
        }
    }
    // 把你写好的 buffer 数组（实际有效长度为 out_len），打包成 Python 的字符串对象
    PyObject *result = PyUnicode_FromKindAndData(PyUnicode_4BYTE_KIND, buffer, out_len);
    free(buffer);
    return result;
}

// 1. 方法表：映射 Python 函数名到 C 函数
static PyMethodDef FastCleanerMethods[] = {
    // {"在Python里你想叫什么名字", 对应的C函数指针, 传参规则, "说明文档"},
    {"clean", clean_text, METH_VARARGS, "Clean punctuation from text extremely fast."},
    {NULL, NULL, 0, NULL} // 哨兵：必须以全 NULL 结尾，告诉 Python 列表到此为止
};

// 2. 模块定义：营业执照
static struct PyModuleDef fastcleanermodule = {
    PyModuleDef_HEAD_INIT,
    "fast_cleaner",                          // 模块名 (我们叫它 fast_cleaner)
    "A C-extension for fast text cleaning.", // 模块文档
    -1,                                      // 保持 -1，表示模块不支持多解释器状态
    FastCleanerMethods                       // 指向上面那个方法表数组的名称
};

// 3. 入口函数：Python import 时的第一落脚点！
// 注意：函数名必须严格按照 PyInit_模块名 的格式！
PyMODINIT_FUNC PyInit_fast_cleaner(void)
{
    // 把模块定义传给创建函数
    return PyModule_Create(&fastcleanermodule);
}