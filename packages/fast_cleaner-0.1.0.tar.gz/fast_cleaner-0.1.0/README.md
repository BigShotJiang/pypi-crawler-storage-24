# FastCleaner 🧹

一个极其轻量、极速的 Python 文本清洗库。使用纯 C 语言编写。

它可以帮你瞬间洗掉文本里的标点符号、Emoji 表情和各种特殊字符，非常适合做数据预处理和 NLP（自然语言处理）清洗任务。

## 📦 安装

```bash
pip install fast_cleaner
```

## 🚀 如何使用

### 1. 基础清洗（默认）

自动过滤掉中英文标点符号和 Emoji。

```
import fast_cleaner

dirty_text = "Hello, World! 这是一个测试... 🤣 你好，世界！"
clean_text = fast_cleaner.clean(dirty_text)

print(clean_text)
# 输出: Hello World 这是一个测试 你好世界
```

### 2. 严格模式 (Mode = 1)

如果你在处理含有小语种特殊标点（比如西班牙语的 ¡、¿，或者阿拉伯语的 、）的文本，可以加上参数 1 开启严格模式。

```
import fast_cleaner

spanish_text = "¡Hola, amigo! ¿Cómo estás?"

# 默认模式（普通清洗）
print(fast_cleaner.clean(spanish_text))
# 输出: ¡Hola amigo ¿Cómo estás

# 严格模式
print(fast_cleaner.clean(spanish_text, 1))
# 输出: Hola amigo Cómo estás
```

## ⚡ 为什么用它？

因为快。底层全部由 C 语言实现，直接操作内存，没有 Python 原生字符串处理的性能损耗，清洗上亿字符只需眨眼之间。
