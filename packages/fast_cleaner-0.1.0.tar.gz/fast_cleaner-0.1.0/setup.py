from setuptools import setup, Extension

# 1. 把你的极简说明书读进来
with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

# 2. 定义 C 扩展模块
fast_module = Extension('fast_cleaner', sources=['fast_cleaner.c'])

# 3. 告诉 Python 开始构建
setup(
    name='fast-cleaner',                 # 库的名字（建议用小写，别人 pip install fast-cleaner）
    version='0.1.0',                     # 第一次发布，按照极客规矩，用 0.1.0
    description='A blazing-fast C extension for text cleaning',
    long_description=long_description,   # 把说明书塞进去！
    long_description_content_type="text/markdown", # 告诉 PyPI 网站这是 Markdown 格式
    ext_modules=[fast_module]            # 挂载你的 C 引擎
)