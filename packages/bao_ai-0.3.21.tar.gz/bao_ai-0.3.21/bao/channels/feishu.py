"""Feishu/Lark channel implementation using lark-oapi SDK with WebSocket long connection."""

import asyncio
import json
import os
import re
import threading
from collections import OrderedDict
from typing import Any

from loguru import logger

from bao.bus.events import OutboundMessage
from bao.bus.queue import MessageBus
from bao.channels.base import BaseChannel
from bao.channels.progress_text import EditingProgress
from bao.config.schema import FeishuConfig
from bao.utils.helpers import get_media_path

lark: Any = None
CreateFileRequest: Any = None
CreateFileRequestBody: Any = None
CreateImageRequest: Any = None
CreateImageRequestBody: Any = None
CreateMessageReactionRequest: Any = None
CreateMessageReactionRequestBody: Any = None
CreateMessageRequest: Any = None
CreateMessageRequestBody: Any = None
Emoji: Any = None
GetFileRequest: Any = None
GetMessageResourceRequest: Any = None
PatchMessageRequest: Any = None
PatchMessageRequestBody: Any = None

_feishu_available = False
try:
    import lark_oapi as lark
    from lark_oapi.api.im.v1 import (
        CreateFileRequest,
        CreateFileRequestBody,
        CreateImageRequest,
        CreateImageRequestBody,
        CreateMessageReactionRequest,
        CreateMessageReactionRequestBody,
        CreateMessageRequest,
        CreateMessageRequestBody,
        Emoji,
        GetFileRequest,
        GetMessageResourceRequest,
        PatchMessageRequest,
        PatchMessageRequestBody,
    )

    _feishu_available = True
except ImportError:
    pass

FEISHU_AVAILABLE = _feishu_available

# Message type display mapping
MSG_TYPE_MAP = {
    "image": "[image]",
    "audio": "[audio]",
    "file": "[file]",
    "sticker": "[sticker]",
}


def _extract_share_card_content(content_json: dict[str, Any], msg_type: str) -> str:
    """Extract text representation from share cards and interactive messages."""
    parts = []

    if msg_type == "share_chat":
        parts.append(f"[shared chat: {content_json.get('chat_id', '')}]")
    elif msg_type == "share_user":
        parts.append(f"[shared user: {content_json.get('user_id', '')}]")
    elif msg_type == "interactive":
        parts.extend(_extract_interactive_content(content_json))
    elif msg_type == "share_calendar_event":
        parts.append(f"[shared calendar event: {content_json.get('event_key', '')}]")
    elif msg_type == "system":
        parts.append("[system message]")
    elif msg_type == "merge_forward":
        parts.append("[merged forward messages]")

    return "\n".join(parts) if parts else f"[{msg_type}]"


def _extract_interactive_content(content: dict[str, Any]) -> list[str]:
    """Recursively extract text and links from interactive card content."""
    parts = []

    if isinstance(content, str):
        try:
            content = json.loads(content)
        except (json.JSONDecodeError, TypeError):
            return [content] if content.strip() else []

    if not isinstance(content, dict):
        return parts

    if "title" in content:
        title = content["title"]
        if isinstance(title, dict):
            title_content = title.get("content", "") or title.get("text", "")
            if title_content:
                parts.append(f"title: {title_content}")
        elif isinstance(title, str):
            parts.append(f"title: {title}")

    elements = content.get("elements")
    if isinstance(elements, list):
        for group in elements:
            if isinstance(group, dict):
                parts.extend(_extract_element_content(group))
            elif isinstance(group, list):
                for element in group:
                    parts.extend(_extract_element_content(element))

    card = content.get("card", {})
    if card:
        parts.extend(_extract_interactive_content(card))

    header = content.get("header", {})
    if header:
        header_title = header.get("title", {})
        if isinstance(header_title, dict):
            header_text = header_title.get("content", "") or header_title.get("text", "")
            if header_text:
                parts.append(f"title: {header_text}")

    return parts


def _extract_element_content(element: dict[str, Any]) -> list[str]:
    """Extract content from a single card element."""
    parts = []

    if not isinstance(element, dict):
        return parts

    tag = element.get("tag", "")

    if tag in ("markdown", "lark_md"):
        content = element.get("content", "")
        if content:
            parts.append(content)

    elif tag == "div":
        text = element.get("text", {})
        if isinstance(text, dict):
            text_content = text.get("content", "") or text.get("text", "")
            if text_content:
                parts.append(text_content)
        elif isinstance(text, str):
            parts.append(text)
        for field in element.get("fields", []):
            if isinstance(field, dict):
                field_text = field.get("text", {})
                if isinstance(field_text, dict):
                    c = field_text.get("content", "")
                    if c:
                        parts.append(c)

    elif tag == "a":
        href = element.get("href", "")
        text = element.get("text", "")
        if href:
            parts.append(f"link: {href}")
        if text:
            parts.append(text)

    elif tag == "button":
        text = element.get("text", {})
        if isinstance(text, dict):
            c = text.get("content", "")
            if c:
                parts.append(c)
        url = element.get("url", "") or element.get("multi_url", {}).get("url", "")
        if url:
            parts.append(f"link: {url}")

    elif tag == "img":
        alt = element.get("alt", {})
        parts.append(alt.get("content", "[image]") if isinstance(alt, dict) else "[image]")

    elif tag == "note":
        for ne in element.get("elements", []):
            parts.extend(_extract_element_content(ne))

    elif tag == "column_set":
        for col in element.get("columns", []):
            for ce in col.get("elements", []):
                parts.extend(_extract_element_content(ce))

    elif tag == "plain_text":
        content = element.get("content", "")
        if content:
            parts.append(content)

    else:
        for ne in element.get("elements", []):
            parts.extend(_extract_element_content(ne))

    return parts


def _extract_post_text(content_json: dict[str, Any]) -> str:
    """Extract plain text from Feishu post (rich text) message content.

    Supports two formats:
    1. Direct format: {"title": "...", "content": [...]}
    2. Localized format: {"zh_cn": {"title": "...", "content": [...]}}
    """

    def extract_from_lang(lang_content: Any) -> str | None:
        if not isinstance(lang_content, dict):
            return None
        title = lang_content.get("title", "")
        content_blocks = lang_content.get("content", [])
        if not isinstance(content_blocks, list):
            return None
        text_parts = []
        if title:
            text_parts.append(title)
        for block in content_blocks:
            if not isinstance(block, list):
                continue
            for element in block:
                if isinstance(element, dict):
                    tag = element.get("tag")
                    if tag == "text":
                        text_parts.append(element.get("text", ""))
                    elif tag == "a":
                        text_parts.append(element.get("text", ""))
                    elif tag == "at":
                        text_parts.append(f"@{element.get('user_name', 'user')}")
        return " ".join(text_parts).strip() if text_parts else None

    post_root = content_json.get("post") if isinstance(content_json, dict) else None
    if not isinstance(post_root, dict):
        post_root = content_json if isinstance(content_json, dict) else {}

    # Try direct format first
    if "content" in post_root:
        result = extract_from_lang(post_root)
        if result:
            return result

    # Try localized format
    for lang_key in ("zh_cn", "en_us", "ja_jp"):
        lang_content = post_root.get(lang_key)
        result = extract_from_lang(lang_content)
        if result:
            return result

    for value in post_root.values():
        if isinstance(value, dict):
            result = extract_from_lang(value)
            if result:
                return result

    return ""


class FeishuChannel(BaseChannel):
    """
    Feishu/Lark channel using WebSocket long connection.

    Uses WebSocket to receive events - no public IP or webhook required.

    Requires:
    - App ID and App Secret from Feishu Open Platform
    - Bot capability enabled
    - Event subscription enabled (im.message.receive_v1)
    """

    name = "feishu"

    def __init__(self, config: FeishuConfig, bus: MessageBus):
        super().__init__(config, bus)
        self.config: FeishuConfig = config
        self._client: Any = None
        self._ws_client: Any = None
        self._ws_thread: threading.Thread | None = None
        self._processed_message_ids: OrderedDict[str, None] = OrderedDict()  # Ordered dedup cache
        self._loop: asyncio.AbstractEventLoop | None = None
        self._progress_handler = EditingProgress(
            self._create_progress_text,
            self._update_progress_text,
            self._send_text,
        )

    async def start(self) -> None:
        """Start the Feishu bot with WebSocket long connection."""
        self.mark_not_ready()
        if not FEISHU_AVAILABLE:
            logger.error("❌ 飞书SDK缺失 / sdk missing: pip install lark-oapi")
            self.mark_ready()
            return

        app_secret = self.config.app_secret.get_secret_value()
        encrypt_key = self.config.encrypt_key.get_secret_value()
        verification_token = self.config.verification_token.get_secret_value()

        if not self.config.app_id or not app_secret:
            logger.error("❌ 飞书配置缺失 / config missing: app_id and app_secret")
            self.mark_ready()
            return

        self._running = True
        self._loop = asyncio.get_running_loop()

        # Create Lark client for sending messages
        self._client = (
            lark.Client.builder()
            .app_id(self.config.app_id)
            .app_secret(app_secret)
            .log_level(lark.LogLevel.INFO)
            .build()
        )
        self.mark_ready()

        # Create event handler (only register message receive, ignore other events)
        event_handler = (
            lark.EventDispatcherHandler.builder(
                encrypt_key,
                verification_token,
            )
            .register_p2_im_message_receive_v1(self._on_message_sync)
            .build()
        )

        # Create WebSocket client for long connection
        self._ws_client = lark.ws.Client(
            self.config.app_id,
            app_secret,
            event_handler=event_handler,
            log_level=lark.LogLevel.INFO,
        )

        # Start WebSocket client in a separate thread with reconnect loop
        def run_ws():
            while self._running:
                try:
                    self._ws_client.start()
                except Exception as e:
                    logger.warning("⚠️ 飞书连接异常 / ws error: {}", e)
                if self._running:
                    import time

                    time.sleep(5)

        self._ws_thread = threading.Thread(target=run_ws, daemon=True)
        self._ws_thread.start()

        logger.info("✅ 飞书已连接 / ws connected: long connection started")
        logger.info("📡 飞书事件接收 / event recv: using WebSocket without public IP")

        # Keep running until stopped
        while self._running:
            await asyncio.sleep(1)

    async def stop(self) -> None:
        """Stop the Feishu bot."""
        self._running = False
        self.mark_not_ready()
        self._clear_progress()
        ws_client = self._ws_client
        if ws_client and hasattr(ws_client, "stop"):
            try:
                await asyncio.to_thread(ws_client.stop)
            except Exception as e:
                logger.debug("Feishu ws stop failed: {}", e)
        ws_thread = self._ws_thread
        if ws_thread and ws_thread.is_alive():
            await asyncio.to_thread(ws_thread.join, timeout=3)
        self._ws_thread = None
        self._loop = None
        self._ws_client = None
        logger.info("ℹ️ 飞书已停止 / channel stopped: shutdown complete")

    def _add_reaction_sync(self, message_id: str, emoji_type: str) -> None:
        """Sync helper for adding reaction (runs in thread pool)."""
        try:
            request = (
                CreateMessageReactionRequest.builder()
                .message_id(message_id)
                .request_body(
                    CreateMessageReactionRequestBody.builder()
                    .reaction_type(Emoji.builder().emoji_type(emoji_type).build())
                    .build()
                )
                .build()
            )

            response = self._client.im.v1.message_reaction.create(request)

            if not response.success():
                logger.debug(
                    "ℹ️ 飞书表情失败 / react failed: code={}, msg={}", response.code, response.msg
                )
            else:
                logger.debug("Added {} reaction to message {}", emoji_type, message_id)
        except Exception as e:
            logger.debug("ℹ️ 飞书表情异常 / react error: {}", e)

    async def _add_reaction(self, message_id: str, emoji_type: str = "THUMBSUP") -> None:
        """
        Add a reaction emoji to a message (non-blocking).

        Common emoji types: THUMBSUP, OK, EYES, DONE, OnIt, HEART
        """
        if not self._client or not Emoji:
            return

        loop = asyncio.get_running_loop()
        await loop.run_in_executor(None, self._add_reaction_sync, message_id, emoji_type)

    # Regex to match markdown tables (header + separator + data rows)
    _TABLE_RE = re.compile(
        r"((?:^[ \t]*\|.+\|[ \t]*\n)(?:^[ \t]*\|[-:\s|]+\|[ \t]*\n)(?:^[ \t]*\|.+\|[ \t]*\n?)+)",
        re.MULTILINE,
    )

    _HEADING_RE = re.compile(r"^(#{1,6})\s+(.+)$", re.MULTILINE)

    _CODE_BLOCK_RE = re.compile(r"(```[\s\S]*?```)", re.MULTILINE)

    @staticmethod
    def _parse_md_table(table_text: str) -> dict[str, Any] | None:
        """Parse a markdown table into a Feishu table element."""
        lines = [line.strip() for line in table_text.strip().split("\n") if line.strip()]
        if len(lines) < 3:
            return None

        def split_row(row: str) -> list[str]:
            return [c.strip() for c in row.strip("|").split("|")]

        headers = split_row(lines[0])
        rows = [split_row(row) for row in lines[2:]]
        columns = [
            {"tag": "column", "name": f"c{i}", "display_name": h, "width": "auto"}
            for i, h in enumerate(headers)
        ]
        return {
            "tag": "table",
            "page_size": len(rows) + 1,
            "columns": columns,
            "rows": [
                {f"c{i}": r[i] if i < len(r) else "" for i in range(len(headers))} for r in rows
            ],
        }

    def _build_card_elements(self, content: str) -> list[dict[str, Any]]:
        """Split content into div/markdown + table elements for Feishu card."""
        elements, last_end = [], 0
        for m in self._TABLE_RE.finditer(content):
            before = content[last_end : m.start()]
            if before.strip():
                elements.extend(self._split_headings(before))
            elements.append(
                self._parse_md_table(m.group(1)) or {"tag": "markdown", "content": m.group(1)}
            )
            last_end = m.end()
        remaining = content[last_end:]
        if remaining.strip():
            elements.extend(self._split_headings(remaining))
        return elements or [{"tag": "markdown", "content": content}]

    def _split_headings(self, content: str) -> list[dict[str, Any]]:
        """Split content by headings, converting headings to div elements."""
        protected = content
        code_blocks = []
        for m in self._CODE_BLOCK_RE.finditer(content):
            code_blocks.append(m.group(1))
            protected = protected.replace(m.group(1), f"\x00CODE{len(code_blocks) - 1}\x00", 1)

        elements = []
        last_end = 0
        for m in self._HEADING_RE.finditer(protected):
            before = protected[last_end : m.start()].strip()
            if before:
                elements.append({"tag": "markdown", "content": before})
            text = m.group(2).strip()
            elements.append(
                {
                    "tag": "div",
                    "text": {
                        "tag": "lark_md",
                        "content": f"**{text}**",
                    },
                }
            )
            last_end = m.end()
        remaining = protected[last_end:].strip()
        if remaining:
            elements.append({"tag": "markdown", "content": remaining})

        for i, cb in enumerate(code_blocks):
            for el in elements:
                if el.get("tag") == "markdown":
                    el["content"] = el["content"].replace(f"\x00CODE{i}\x00", cb)

        return elements or [{"tag": "markdown", "content": content}]

    _IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp", ".ico", ".tiff", ".tif"}
    _AUDIO_EXTS = {".opus"}
    _FILE_TYPE_MAP = {
        ".opus": "opus",
        ".mp4": "mp4",
        ".pdf": "pdf",
        ".doc": "doc",
        ".docx": "doc",
        ".xls": "xls",
        ".xlsx": "xls",
        ".ppt": "ppt",
        ".pptx": "ppt",
    }

    def _upload_image_sync(self, file_path: str) -> str | None:
        """Upload an image to Feishu and return the image_key."""
        try:
            with open(file_path, "rb") as f:
                request = (
                    CreateImageRequest.builder()
                    .request_body(
                        CreateImageRequestBody.builder().image_type("message").image(f).build()
                    )
                    .build()
                )
                response = self._client.im.v1.image.create(request)
                if response.success():
                    image_key = response.data.image_key
                    logger.debug("Uploaded image {}: {}", os.path.basename(file_path), image_key)
                    return image_key
                else:
                    logger.error(
                        "❌ 飞书图片上传失败 / upload failed: code={}, msg={}",
                        response.code,
                        response.msg,
                    )
                    return None
        except Exception as e:
            logger.error("❌ 飞书图片上传异常 / upload error: {}: {}", file_path, e)
            return None

    def _upload_file_sync(self, file_path: str) -> str | None:
        """Upload a file to Feishu and return the file_key."""
        ext = os.path.splitext(file_path)[1].lower()
        file_type = self._FILE_TYPE_MAP.get(ext, "stream")
        file_name = os.path.basename(file_path)
        try:
            with open(file_path, "rb") as f:
                request = (
                    CreateFileRequest.builder()
                    .request_body(
                        CreateFileRequestBody.builder()
                        .file_type(file_type)
                        .file_name(file_name)
                        .file(f)
                        .build()
                    )
                    .build()
                )
                response = self._client.im.v1.file.create(request)
                if response.success():
                    file_key = response.data.file_key
                    logger.debug("Uploaded file {}: {}", file_name, file_key)
                    return file_key
                else:
                    logger.error(
                        "❌ 飞书文件上传失败 / upload failed: code={}, msg={}",
                        response.code,
                        response.msg,
                    )
                    return None
        except Exception as e:
            logger.error("❌ 飞书文件上传异常 / upload error: {}: {}", file_path, e)
            return None

    def _download_image_sync(
        self, message_id: str, image_key: str
    ) -> tuple[bytes | None, str | None]:
        """Download an image from Feishu message by message_id and image_key."""
        try:
            request = (
                GetMessageResourceRequest.builder()
                .message_id(message_id)
                .file_key(image_key)
                .type("image")
                .build()
            )
            response = self._client.im.v1.message_resource.get(request)
            if response.success():
                file_data = response.file
                if hasattr(file_data, "read"):
                    file_data = file_data.read()
                return file_data, response.file_name
            else:
                logger.error(
                    "❌ 飞书图片下载失败 / download failed: code={}, msg={}",
                    response.code,
                    response.msg,
                )
                return None, None
        except Exception as e:
            logger.error("❌ 飞书图片下载异常 / download error: {}: {}", image_key, e)
            return None, None

    def _download_file_sync(self, file_key: str) -> tuple[bytes | None, str | None]:
        """Download a file from Feishu by file_key."""
        try:
            request = GetFileRequest.builder().file_key(file_key).build()
            response = self._client.im.v1.file.get(request)
            if response.success():
                return response.file, response.file_name
            else:
                logger.error(
                    "❌ 飞书文件下载失败 / download failed: code={}, msg={}",
                    response.code,
                    response.msg,
                )
                return None, None
        except Exception as e:
            logger.error("❌ 飞书文件下载异常 / download error: {}: {}", file_key, e)
            return None, None

    async def _download_and_save_media(
        self,
        msg_type: str,
        content_json: dict[str, Any],
        message_id: str | None = None,
    ) -> tuple[str | None, str]:
        """Download media from Feishu and save to local disk.

        Returns:
            (file_path, content_text) - file_path is None if download failed
        """
        loop = asyncio.get_running_loop()
        media_dir = get_media_path()

        data, filename = None, None

        if msg_type == "image":
            image_key = content_json.get("image_key")
            if image_key and message_id:
                data, filename = await loop.run_in_executor(
                    None, self._download_image_sync, message_id, image_key
                )
                if not filename:
                    filename = f"{image_key[:16]}.jpg"

        elif msg_type in ("audio", "file"):
            file_key = content_json.get("file_key")
            if file_key:
                data, filename = await loop.run_in_executor(
                    None, self._download_file_sync, file_key
                )
                if not filename:
                    ext = ".opus" if msg_type == "audio" else ""
                    filename = f"{file_key[:16]}{ext}"

        if data and filename:
            file_path = media_dir / filename
            file_path.write_bytes(data)
            logger.debug("Downloaded {} to {}", msg_type, file_path)
            return str(file_path), f"[{msg_type}: {filename}]"

        return None, f"[{msg_type}: download failed]"

    def _send_message_sync(
        self, receive_id_type: str, receive_id: str, msg_type: str, content: str
    ) -> str | None:
        try:
            request = (
                CreateMessageRequest.builder()
                .receive_id_type(receive_id_type)
                .request_body(
                    CreateMessageRequestBody.builder()
                    .receive_id(receive_id)
                    .msg_type(msg_type)
                    .content(content)
                    .build()
                )
                .build()
            )
            response = self._client.im.v1.message.create(request)
            if not response.success():
                logger.error(
                    "❌ 飞书消息发送失败 / send failed: {} code={}, msg={}, log_id={}",
                    msg_type,
                    response.code,
                    response.msg,
                    response.get_log_id(),
                )
                return None
            logger.debug("Feishu {} message sent to {}", msg_type, receive_id)
            data = getattr(response, "data", None)
            message_id = getattr(data, "message_id", None)
            return str(message_id) if message_id else None
        except Exception as e:
            logger.error("❌ 飞书消息发送异常 / send error: {}: {}", msg_type, e)
            return None

    def _patch_message_sync(self, message_id: str, content: str) -> bool:
        if not self._client or not PatchMessageRequest or not PatchMessageRequestBody:
            return False
        try:
            request = (
                PatchMessageRequest.builder()
                .message_id(message_id)
                .request_body(PatchMessageRequestBody.builder().content(content).build())
                .build()
            )
            response = self._client.im.v1.message.patch(request)
            if not response.success():
                logger.error(
                    "❌ 飞书消息更新失败 / patch failed: code={}, msg={}, log_id={}",
                    response.code,
                    response.msg,
                    response.get_log_id(),
                )
                return False
            return True
        except Exception as e:
            logger.error("❌ 飞书消息更新异常 / patch error: {}", e)
            return False

    async def send(self, msg: OutboundMessage) -> None:
        """Send a message through Feishu, including media (images/files) if present."""
        if not self._client:
            logger.warning("⚠️ 飞书客户端未就绪 / client not ready: not initialized")
            return

        try:
            receive_id_type = "chat_id" if msg.chat_id.startswith("oc_") else "open_id"
            loop = asyncio.get_running_loop()

            for file_path in msg.media:
                if not os.path.isfile(file_path):
                    logger.warning("⚠️ 飞书媒体缺失 / media missing: {}", file_path)
                    continue
                ext = os.path.splitext(file_path)[1].lower()
                if ext in self._IMAGE_EXTS:
                    key = await loop.run_in_executor(None, self._upload_image_sync, file_path)
                    if key:
                        await loop.run_in_executor(
                            None,
                            self._send_message_sync,
                            receive_id_type,
                            msg.chat_id,
                            "image",
                            json.dumps({"image_key": key}, ensure_ascii=False),
                        )
                else:
                    key = await loop.run_in_executor(None, self._upload_file_sync, file_path)
                    if key:
                        media_type = "audio" if ext in self._AUDIO_EXTS else "file"
                        await loop.run_in_executor(
                            None,
                            self._send_message_sync,
                            receive_id_type,
                            msg.chat_id,
                            media_type,
                            json.dumps({"file_key": key}, ensure_ascii=False),
                        )

            if msg.content or (msg.metadata or {}).get("_progress_clear"):
                await self._dispatch_progress_text(msg, flush_progress=True)

        except Exception as e:
            logger.error("❌ 飞书发送异常 / send error: {}", e)

    async def _send_text(self, chat_id: str, text: str) -> None:
        if not self._client or not text.strip():
            return
        receive_id_type = "chat_id" if chat_id.startswith("oc_") else "open_id"
        card = {
            "config": {"wide_screen_mode": True},
            "elements": self._build_card_elements(text),
        }
        loop = asyncio.get_running_loop()
        await loop.run_in_executor(
            None,
            self._send_message_sync,
            receive_id_type,
            chat_id,
            "interactive",
            json.dumps(card, ensure_ascii=False),
        )

    async def _create_progress_text(self, chat_id: str, text: str) -> str | None:
        if not self._client or not text.strip():
            return None
        receive_id_type = "chat_id" if chat_id.startswith("oc_") else "open_id"
        card = {
            "config": {"wide_screen_mode": True},
            "elements": self._build_card_elements(text),
        }
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(
            None,
            self._send_message_sync,
            receive_id_type,
            chat_id,
            "interactive",
            json.dumps(card, ensure_ascii=False),
        )

    async def _update_progress_text(
        self, chat_id: str, handle: str | None, text: str
    ) -> str | None:
        del chat_id
        if not handle or not text.strip():
            return handle
        card = {
            "config": {"wide_screen_mode": True},
            "elements": self._build_card_elements(text),
        }
        loop = asyncio.get_running_loop()
        await loop.run_in_executor(
            None,
            self._patch_message_sync,
            handle,
            json.dumps(card, ensure_ascii=False),
        )
        return handle

    def _on_message_sync(self, data: Any) -> None:
        """
        Sync handler for incoming messages (called from WebSocket thread).
        Schedules async handling in the main event loop.
        """
        if self._running and self._loop and self._loop.is_running():
            try:
                asyncio.run_coroutine_threadsafe(self._on_message(data), self._loop)
            except RuntimeError:
                logger.debug("Feishu: event loop closed, dropping message")

    async def _on_message(self, data: Any) -> None:
        """Handle incoming message from Feishu."""
        try:
            if not self._running:
                return

            event = data.event
            message = event.message
            sender = event.sender

            # Deduplication check
            message_id = str(message.message_id or "")
            if not message_id:
                return
            if message_id in self._processed_message_ids:
                return
            self._processed_message_ids[message_id] = None

            # Trim cache
            while len(self._processed_message_ids) > 1000:
                self._processed_message_ids.popitem(last=False)

            # Skip bot messages
            if sender.sender_type == "bot":
                return

            sender_id = str(sender.sender_id.open_id) if sender.sender_id else "unknown"
            chat_id = str(message.chat_id or "")
            chat_type = str(message.chat_type or "")
            msg_type = str(message.message_type or "")

            # Add reaction
            await self._add_reaction(message_id, self.config.react_emoji)

            # Parse content
            content_parts = []
            media_paths = []

            try:
                content_json = json.loads(message.content) if message.content else {}
            except json.JSONDecodeError:
                content_json = {}

            if msg_type == "text":
                text = content_json.get("text", "")
                if text:
                    content_parts.append(text)

            elif msg_type == "post":
                text = _extract_post_text(content_json)
                if text:
                    content_parts.append(text)

            elif msg_type in ("image", "audio", "file"):
                file_path, content_text = await self._download_and_save_media(
                    msg_type, content_json, message_id
                )
                if file_path:
                    media_paths.append(file_path)
                content_parts.append(content_text)

            elif msg_type in (
                "share_chat",
                "share_user",
                "interactive",
                "share_calendar_event",
                "system",
                "merge_forward",
            ):
                text = _extract_share_card_content(content_json, msg_type)
                if text:
                    content_parts.append(text)

            else:
                content_parts.append(MSG_TYPE_MAP.get(msg_type, f"[{msg_type}]"))

            content = "\n".join(content_parts) if content_parts else ""

            if not content and not media_paths:
                return

            if not self._running:
                return

            # Forward to message bus
            reply_to = chat_id if chat_type == "group" else sender_id
            await self._handle_message(
                sender_id=sender_id,
                chat_id=reply_to,
                content=content,
                media=media_paths,
                metadata={
                    "message_id": message_id,
                    "chat_type": chat_type,
                    "msg_type": msg_type,
                },
            )

        except Exception as e:
            logger.error("❌ 飞书消息处理异常 / process error: {}", e)
