# ----------------------------------------------------------------------------------------
#   gitlab_api
#   ----------
#
#   GitLab REST API client for accessing project releases and group structures.
#   Uses only Python stdlib (urllib.request) - no external dependencies.
#
#   Supports:
#   - Auto-detecting whether a path is a group or project
#   - Listing all projects within a group (including subgroups)
#   - Listing releases and their uploaded assets
#   - Downloading release asset files
#   - Uploading files and creating releases with asset links
#
#   License
#   -------
#   MIT License - Copyright 2026 Cyber Assessment Labs
#
#   Authors
#   -------
#   bena (via claude)
#
#   Version History
#   ---------------
#   Feb 2026 - Created (download support)
#   Feb 2026 - Added upload support (create releases, upload files, asset links)
# ----------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------
#   Imports
# ----------------------------------------------------------------------------------------

import json
import logging
import mimetypes
import urllib.error
import urllib.parse
import urllib.request
import uuid
from dataclasses import dataclass
from dataclasses import field
from pathlib import Path
from typing import Any

# ----------------------------------------------------------------------------------------
#   Types
# ----------------------------------------------------------------------------------------


@dataclass
class ProjectInfo:
    """Information about a GitLab project."""

    id: int
    name: str
    path_with_namespace: str


@dataclass
class ReleaseAsset:
    """An uploaded asset (link) attached to a release."""

    id: int
    name: str
    url: str
    direct_asset_url: str


@dataclass
class ReleaseInfo:
    """Information about a project release."""

    tag_name: str
    name: str
    assets: list[ReleaseAsset] = field(default_factory=lambda: list[ReleaseAsset]())
    created_at: str = ""


# ----------------------------------------------------------------------------------------
#   GitLab Client
# ----------------------------------------------------------------------------------------


# ----------------------------------------------------------------------------------------
class GitLabClient:
    """
    Client for interacting with GitLab's Releases and Groups API.

    Supports both public and private projects (via access token).
    """

    # ------------------------------------------------------------------------------------
    def __init__(self, gitlab_url: str, token: str | None = None):
        """
        Initialise the GitLab client.

        Parameters:
            gitlab_url: Base URL of the GitLab instance (e.g., https://gitlab.com)
            token: Optional private access token for authentication
        """
        # Ensure URL has a scheme
        url = gitlab_url.rstrip("/")
        if not url.startswith(("http://", "https://")):
            url = "https://" + url
        self.gitlab_url = url
        self.token = token
        self.logger = logging.getLogger(__name__)

    # ------------------------------------------------------------------------------------
    def _api_url(self, endpoint: str) -> str:
        """Build full API URL for an endpoint."""
        return f"{self.gitlab_url}/api/v4{endpoint}"

    # ------------------------------------------------------------------------------------
    def _request(self, url: str) -> Any:
        """
        Make an HTTP GET request and return parsed JSON response.

        Parameters:
            url: Full URL to request

        Returns:
            Parsed JSON response

        Raises:
            urllib.error.HTTPError: On HTTP errors
            urllib.error.URLError: On connection errors
        """
        self.logger.debug(f"GET {url}")

        request = urllib.request.Request(url)
        request.add_header("Accept", "application/json")
        if self.token:
            request.add_header("PRIVATE-TOKEN", self.token)

        with urllib.request.urlopen(request) as response:
            data = response.read().decode("utf-8")
            return json.loads(data)

    # ------------------------------------------------------------------------------------
    def _paginated_request(self, url: str) -> list[Any]:
        """
        Make paginated API requests and return all results.

        GitLab's API returns paginated results. This method follows pagination
        headers to fetch all pages.

        Parameters:
            url: Base URL (without pagination parameters)

        Returns:
            List of all results across all pages
        """
        results: list[Any] = []
        page = 1
        per_page = 100

        while True:
            separator = "&" if "?" in url else "?"
            paginated_url = f"{url}{separator}page={page}&per_page={per_page}"

            self.logger.debug(f"GET {paginated_url}")

            request = urllib.request.Request(paginated_url)
            request.add_header("Accept", "application/json")
            if self.token:
                request.add_header("PRIVATE-TOKEN", self.token)

            with urllib.request.urlopen(request) as response:
                data = response.read().decode("utf-8")
                page_results = json.loads(data)

                if not page_results:
                    break

                results.extend(page_results)

                # Check if there are more pages
                total_pages_header = response.headers.get("X-Total-Pages")
                if total_pages_header:
                    total_pages = int(total_pages_header)
                    if page >= total_pages:
                        break
                elif len(page_results) < per_page:
                    # No pagination headers, use result count as heuristic
                    break

                page += 1

        return results

    # ------------------------------------------------------------------------------------
    def _post_json(self, url: str, data: dict[str, Any]) -> Any:
        """
        Make an HTTP POST request with a JSON body and return parsed JSON response.

        Parameters:
            url: Full URL to request
            data: Dict to serialise as JSON body

        Returns:
            Parsed JSON response

        Raises:
            urllib.error.HTTPError: On HTTP errors
            urllib.error.URLError: On connection errors
        """
        self.logger.debug(f"POST {url}")

        body = json.dumps(data).encode("utf-8")
        request = urllib.request.Request(url, data=body, method="POST")
        request.add_header("Content-Type", "application/json")
        request.add_header("Accept", "application/json")
        if self.token:
            request.add_header("PRIVATE-TOKEN", self.token)

        with urllib.request.urlopen(request) as response:
            return json.loads(response.read().decode("utf-8"))

    # ------------------------------------------------------------------------------------
    def _post_multipart(self, url: str, file_path: Path) -> Any:
        """
        Upload a file via multipart/form-data POST.

        Parameters:
            url: Full URL to post to
            file_path: Path to the file to upload

        Returns:
            Parsed JSON response

        Raises:
            urllib.error.HTTPError: On HTTP errors
            urllib.error.URLError: On connection errors
        """
        self.logger.debug(f"POST (multipart) {url}")

        boundary = uuid.uuid4().hex
        filename = file_path.name
        content_type = mimetypes.guess_type(filename)[0] or "application/octet-stream"

        file_data = file_path.read_bytes()

        body = b""
        body += f"--{boundary}\r\n".encode()
        body += (
            f'Content-Disposition: form-data; name="file"; filename="{filename}"\r\n'
        ).encode()
        body += f"Content-Type: {content_type}\r\n".encode()
        body += b"\r\n"
        body += file_data
        body += f"\r\n--{boundary}--\r\n".encode()

        request = urllib.request.Request(url, data=body, method="POST")
        request.add_header("Content-Type", f"multipart/form-data; boundary={boundary}")
        request.add_header("Accept", "application/json")
        if self.token:
            request.add_header("PRIVATE-TOKEN", self.token)

        with urllib.request.urlopen(request) as response:
            return json.loads(response.read().decode("utf-8"))

    # ------------------------------------------------------------------------------------
    def resolve_path(self, path: str) -> tuple[str, int]:
        """
        Determine whether a GitLab path refers to a group or a project.

        Tries the project API first, then the group API.

        Parameters:
            path: GitLab path (e.g., "group/subgroup/project" or "group/subgroup")

        Returns:
            Tuple of (path_type, id) where path_type is "project" or "group"

        Raises:
            ValueError: If the path is neither a valid project nor group
            urllib.error.URLError: On connection errors
        """
        encoded_path = urllib.parse.quote(path, safe="")

        # Try as a project first
        try:
            project_data = self._request(self._api_url(f"/projects/{encoded_path}"))
            return ("project", int(project_data["id"]))
        except (urllib.error.HTTPError, TypeError, KeyError) as e:
            if isinstance(e, urllib.error.HTTPError) and e.code != 404:
                raise

        # Try as a group
        try:
            group_data = self._request(self._api_url(f"/groups/{encoded_path}"))
            return ("group", int(group_data["id"]))
        except (urllib.error.HTTPError, TypeError, KeyError) as e:
            if isinstance(e, urllib.error.HTTPError) and e.code != 404:
                raise

        raise ValueError(f"Path not found as project or group: {path}")

    # ------------------------------------------------------------------------------------
    def get_group_projects(
        self,
        group_id: int,
        project_filter: str | None = None,
    ) -> list[ProjectInfo]:
        """
        List all projects within a group, including subgroups.

        Parameters:
            group_id: The numeric group ID
            project_filter: Optional substring filter for project paths

        Returns:
            List of ProjectInfo objects
        """
        url = self._api_url(
            f"/groups/{group_id}/projects"
            "?include_subgroups=true&simple=true&archived=false"
            "&order_by=path&sort=asc"
        )

        try:
            projects_data = self._paginated_request(url)
        except urllib.error.HTTPError as e:
            if e.code == 404:
                self.logger.warning(f"Group not found: {group_id}")
                return []
            raise

        projects: list[ProjectInfo] = []
        for proj in projects_data:
            # Skip projects pending deletion
            if proj.get("marked_for_deletion_at"):
                continue

            info = ProjectInfo(
                id=proj["id"],
                name=proj["name"],
                path_with_namespace=proj["path_with_namespace"],
            )

            # Apply project filter if specified
            if project_filter:
                if project_filter.lower() not in info.path_with_namespace.lower():
                    continue

            projects.append(info)

        projects.sort(key=lambda p: p.path_with_namespace)
        return projects

    # ------------------------------------------------------------------------------------
    def get_project_info(self, project_id: int) -> ProjectInfo | None:
        """
        Get project information by ID.

        Parameters:
            project_id: The numeric project ID

        Returns:
            ProjectInfo if found, None otherwise
        """
        url = self._api_url(f"/projects/{project_id}")

        try:
            data = self._request(url)
            return ProjectInfo(
                id=data["id"],
                name=data["name"],
                path_with_namespace=data["path_with_namespace"],
            )
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return None
            raise

    # ------------------------------------------------------------------------------------
    def list_releases(self, project_id: int) -> list[ReleaseInfo]:
        """
        List all releases for a project, including their uploaded assets.

        Only includes uploaded asset links, not source code archives.

        Parameters:
            project_id: The numeric project ID

        Returns:
            List of ReleaseInfo objects with their assets
        """
        url = self._api_url(
            f"/projects/{project_id}/releases?order_by=released_at&sort=desc"
        )

        try:
            releases_data = self._paginated_request(url)
        except urllib.error.HTTPError as e:
            if e.code == 404:
                self.logger.warning(f"No releases found for project: {project_id}")
                return []
            raise

        releases: list[ReleaseInfo] = []
        for rel in releases_data:
            assets: list[ReleaseAsset] = []

            # Only include uploaded asset links, not source code archives
            asset_links = rel.get("assets", {}).get("links", [])
            for link in asset_links:
                assets.append(
                    ReleaseAsset(
                        id=link["id"],
                        name=link["name"],
                        url=link["url"],
                        direct_asset_url=link.get("direct_asset_url", link["url"]),
                    )
                )

            releases.append(
                ReleaseInfo(
                    tag_name=rel["tag_name"],
                    name=rel.get("name", rel["tag_name"]),
                    assets=assets,
                    created_at=rel.get("created_at", ""),
                )
            )

        return releases

    # ------------------------------------------------------------------------------------
    def get_release(self, project_id: int, tag_name: str) -> ReleaseInfo | None:
        """
        Get a specific release by tag name.

        Parameters:
            project_id: The numeric project ID
            tag_name: The release tag name

        Returns:
            ReleaseInfo if found, None otherwise
        """
        encoded_tag = urllib.parse.quote(tag_name, safe="")
        url = self._api_url(f"/projects/{project_id}/releases/{encoded_tag}")

        try:
            rel = self._request(url)
        except urllib.error.HTTPError as e:
            if e.code == 404:
                return None
            raise

        assets: list[ReleaseAsset] = []
        asset_links = rel.get("assets", {}).get("links", [])
        for link in asset_links:
            assets.append(
                ReleaseAsset(
                    id=link["id"],
                    name=link["name"],
                    url=link["url"],
                    direct_asset_url=link.get("direct_asset_url", link["url"]),
                )
            )

        return ReleaseInfo(
            tag_name=rel["tag_name"],
            name=rel.get("name", rel["tag_name"]),
            assets=assets,
            created_at=rel.get("created_at", ""),
        )

    # ------------------------------------------------------------------------------------
    def create_release(
        self,
        project_id: int,
        tag_name: str,
        *,
        name: str | None = None,
        description: str | None = None,
    ) -> ReleaseInfo:
        """
        Create a release for a project tag.

        The tag must already exist in the repository.

        Parameters:
            project_id: The numeric project ID
            tag_name: The tag to create a release for
            name: Release name (defaults to tag_name)
            description: Release description

        Returns:
            The created ReleaseInfo

        Raises:
            urllib.error.HTTPError: On API errors (e.g., tag not found, release exists)
        """
        url = self._api_url(f"/projects/{project_id}/releases")
        body: dict[str, Any] = {
            "tag_name": tag_name,
            "name": name or tag_name,
        }
        if description is not None:
            body["description"] = description

        rel = self._post_json(url, body)

        return ReleaseInfo(
            tag_name=rel["tag_name"],
            name=rel.get("name", rel["tag_name"]),
            created_at=rel.get("created_at", ""),
        )

    # ------------------------------------------------------------------------------------
    def upload_project_file(self, project_id: int, file_path: Path) -> str:
        """
        Upload a file to a project's uploads area.

        Parameters:
            project_id: The numeric project ID
            file_path: Path to the file to upload

        Returns:
            The full URL path of the uploaded file (e.g., /namespace/project/uploads/hash/file)

        Raises:
            urllib.error.HTTPError: On API errors
        """
        url = self._api_url(f"/projects/{project_id}/uploads")
        result = self._post_multipart(url, file_path)
        return str(result["full_path"])

    # ------------------------------------------------------------------------------------
    def create_release_link(
        self,
        project_id: int,
        tag_name: str,
        name: str,
        url: str,
    ) -> ReleaseAsset:
        """
        Create an asset link on a release.

        Parameters:
            project_id: The numeric project ID
            tag_name: The release tag name
            name: Display name for the asset
            url: URL of the asset

        Returns:
            The created ReleaseAsset

        Raises:
            urllib.error.HTTPError: On API errors
        """
        encoded_tag = urllib.parse.quote(tag_name, safe="")
        api_url = self._api_url(
            f"/projects/{project_id}/releases/{encoded_tag}/assets/links"
        )
        body = {"name": name, "url": url}
        result = self._post_json(api_url, body)

        return ReleaseAsset(
            id=result["id"],
            name=result["name"],
            url=result["url"],
            direct_asset_url=result.get("direct_asset_url", result["url"]),
        )

    # ------------------------------------------------------------------------------------
    def _parse_artifact_url(
        self, url: str
    ) -> tuple[str, str, str | None, str | None, str | None] | None:
        """
        Parse a web job-artifact URL into its components.

        Returns ``(encoded_project, remainder, ref, artifact_path, job_name)``
        or ``None`` if the URL is not a recognised artifact URL.

        *ref*, *artifact_path* and *job_name* are only set for ref-based URLs.
        """
        prefix = self.gitlab_url + "/"
        if not url.startswith(prefix):
            return None

        path = url[len(prefix) :]
        parts = path.split("/-/jobs/", 1)
        if len(parts) != 2:
            return None

        project_path, remainder = parts
        encoded = urllib.parse.quote(project_path, safe="")

        # Job-ID form: {id}/artifacts/raw/{path}
        if remainder[0:1].isdigit():
            return encoded, remainder, None, None, None

        # Ref-based form: artifacts/{ref}/raw/{artifact_path}?job={job_name}
        if remainder.startswith("artifacts/"):
            after = remainder[len("artifacts/") :]
            raw_idx = after.find("/raw/")
            if raw_idx >= 0 and "?job=" in after:
                ref = after[:raw_idx]
                rest = after[raw_idx + len("/raw/") :]
                artifact_path, job_name = rest.rsplit("?job=", 1)
                return encoded, remainder, ref, artifact_path, job_name

        return encoded, remainder, None, None, None

    # ------------------------------------------------------------------------------------
    def _resolve_job_artifact(
        self,
        encoded_project: str,
        ref: str,
        artifact_path: str,
        job_name: str,
    ) -> bytes | None:
        """
        Download an artifact by resolving the actual job ID via the pipeline.

        The ref-based API endpoint requires the *pipeline* to be successful.
        When only the specific job succeeded (but the pipeline failed), we
        look up the pipeline for *ref*, find the successful job, and download
        via the job-ID endpoint instead.

        Returns the file contents, or ``None`` if resolution failed.
        """
        ref_encoded = urllib.parse.quote(ref, safe="")
        pipeline_url = self._api_url(
            f"/projects/{encoded_project}/pipelines"
            f"?ref={ref_encoded}&per_page=1&order_by=id&sort=desc"
        )
        try:
            pipelines = self._request(pipeline_url)
            if not pipelines:
                return None
            pipeline_id = pipelines[0]["id"]
        except (urllib.error.HTTPError, KeyError, IndexError):
            return None

        jobs_url = self._api_url(
            f"/projects/{encoded_project}/pipelines/{pipeline_id}/jobs?per_page=100"
        )
        try:
            jobs = self._request(jobs_url)
        except urllib.error.HTTPError:
            return None

        job_id: int | None = None
        for job in jobs:
            if (
                job.get("name") == job_name
                and job.get("status") == "success"
                and job.get("artifacts_file", {}).get("filename")
            ):
                job_id = job["id"]
                break

        if job_id is None:
            return None

        download_url = self._api_url(
            f"/projects/{encoded_project}/jobs/{job_id}/artifacts/{artifact_path}"
        )
        self.logger.debug(f"Downloading (job {job_id}): {download_url}")
        request = urllib.request.Request(download_url)
        if self.token:
            request.add_header("PRIVATE-TOKEN", self.token)
        with urllib.request.urlopen(request) as response:
            return response.read()

    # ------------------------------------------------------------------------------------
    def download_file(self, url: str) -> bytes:
        """
        Download a file from a URL.

        For web job-artifact URLs on the same GitLab instance the download is
        attempted in three stages:

        1. **API ref-based endpoint** -- fast, but requires the whole pipeline
           to have succeeded.
        2. **Pipeline job resolution** -- looks up the actual job ID via the
           pipeline API, works even when the pipeline failed but the specific
           job succeeded.
        3. **Original web URL fallback** -- handles public projects where the
           web endpoint can resolve artifacts that the API cannot.

        Parameters:
            url: URL to download from

        Returns:
            File contents as bytes
        """
        parsed = self._parse_artifact_url(url)

        if parsed is not None:
            encoded_project, remainder, ref, artifact_path, job_name = parsed

            # Build the direct API URL
            api_remainder = remainder
            if remainder[0:1].isdigit():
                # Job-ID form: strip /raw/ from artifacts path
                api_remainder = remainder.replace("/artifacts/raw/", "/artifacts/", 1)
            api_url = (
                f"{self.gitlab_url}/api/v4/projects/{encoded_project}"
                f"/jobs/{api_remainder}"
            )

            # Stage 1: try the API URL directly
            self.logger.debug(f"Downloading (API): {api_url}")
            request = urllib.request.Request(api_url)
            if self.token:
                request.add_header("PRIVATE-TOKEN", self.token)
            try:
                with urllib.request.urlopen(request) as response:
                    return response.read()
            except urllib.error.HTTPError as e:
                e.read()
                if e.code != 404:
                    raise
                self.logger.debug("API 404, trying pipeline job resolution")

            # Stage 2: resolve via pipeline/jobs API (ref-based URLs only)
            if ref and artifact_path and job_name:
                try:
                    data = self._resolve_job_artifact(
                        encoded_project, ref, artifact_path, job_name
                    )
                    if data is not None:
                        return data
                except urllib.error.HTTPError:
                    pass
                self.logger.debug("Job resolution failed, falling back to web URL")

        # Stage 3: fall back to the original web URL
        self.logger.debug(f"Downloading: {url}")
        request = urllib.request.Request(url)
        if self.token:
            request.add_header("PRIVATE-TOKEN", self.token)

        try:
            with urllib.request.urlopen(request) as response:
                return response.read()
        except urllib.error.HTTPError as e:
            e.read()
            raise
