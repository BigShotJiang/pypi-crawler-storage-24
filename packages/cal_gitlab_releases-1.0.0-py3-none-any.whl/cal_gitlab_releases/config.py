# ----------------------------------------------------------------------------------------
#   config
#   ------
#
#   Configuration file loading. Looks for a JSON config file at:
#
#   1. Path specified via --config CLI arg
#   2. Path from CAL_GITLAB_RELEASES_CONFIG env var
#   3. Default: ~/.config/cal-gitlab-releases/config.json
#
#   Config file format (all fields optional):
#
#       {
#           "gitlab_url": "https://gitlab.example.com",
#           "token": "glpat-xxxxxxxxxxxx",
#           "base_group": "myorg",
#           "output": "./downloads",
#           "version_filter": "release",
#           "project_filter": "backend",
#           "parallel": 32,
#           "manifest": "/path/to/manifest.json",
#           "flat": false,
#           "no_colour": false
#       }
#
#   License
#   -------
#   MIT License - Copyright 2026 Cyber Assessment Labs
#
#   Authors
#   -------
#   bena (via claude)
#
#   Version History
#   ---------------
#   Feb 2026 - Created
# ----------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------
#   Imports
# ----------------------------------------------------------------------------------------

import json
import os
import sys
from pathlib import Path
from typing import Any
from typing import cast
from .colour import yellow

# ----------------------------------------------------------------------------------------
#   Constants
# ----------------------------------------------------------------------------------------

CONFIG_DIR = Path.home() / ".config" / "cal-gitlab-releases"
DEFAULT_CONFIG_PATH = CONFIG_DIR / "config.json"
CONFIG_PATH_ENV = "CAL_GITLAB_RELEASES_CONFIG"
TOKEN_ENV = "CAL_GITLAB_RELEASES_TOKEN"


# ----------------------------------------------------------------------------------------
#   Functions
# ----------------------------------------------------------------------------------------


# ----------------------------------------------------------------------------------------
def resolve_config_path(cli_arg: Path | None) -> tuple[Path, bool]:
    """
    Resolve the configuration file path.

    Priority:
    1. Command-line argument (--config)
    2. Environment variable (CAL_GITLAB_RELEASES_CONFIG)
    3. Default path (~/.config/cal-gitlab-releases/config.json)

    Returns:
        Tuple of (config_path, explicitly_specified). explicitly_specified is True
        if the path came from --config or the env var (i.e. the user asked
        for this specific file and it should be an error if missing).
    """
    if cli_arg is not None:
        return cli_arg, True

    env_path = os.environ.get(CONFIG_PATH_ENV)
    if env_path:
        return Path(env_path), True

    return DEFAULT_CONFIG_PATH, False


# ----------------------------------------------------------------------------------------
def load_config(config_path: Path | None) -> dict[str, Any]:
    """
    Load configuration from a JSON file.

    Parameters:
        config_path: Path to config file, or None to use default.

    Returns:
        Configuration dict, or empty dict if not found.
    """
    path, explicitly_specified = resolve_config_path(config_path)

    if not path.exists():
        if explicitly_specified:
            print(
                f"Error: Config file not found: {path}",
                file=sys.stderr,
            )
            raise SystemExit(1)
        return {}

    try:
        with path.open() as f:
            data = json.load(f)
            if not isinstance(data, dict):
                print(
                    yellow(
                        f"Warning: Config file {path} is not a JSON object, ignoring"
                    ),
                    file=sys.stderr,
                )
                return {}
            return cast("dict[str, Any]", data)
    except json.JSONDecodeError as e:
        print(
            yellow(f"Warning: Invalid JSON in config file {path}: {e}"),
            file=sys.stderr,
        )
        return {}
    except OSError as e:
        print(
            yellow(f"Warning: Could not read config file {path}: {e}"),
            file=sys.stderr,
        )
        return {}
