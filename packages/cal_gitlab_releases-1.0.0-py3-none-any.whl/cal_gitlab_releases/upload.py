# ----------------------------------------------------------------------------------------
#   upload
#   ------
#
#   Core upload orchestration - scans a directory of release assets (in the same
#   structure produced by `download`), creates GitLab releases, and uploads asset
#   files as release links.
#
#   Expected input directory structure:
#
#       input_dir/
#           relative/project/path/
#               tag_name/
#                   asset_file_1
#                   asset_file_2
#
#   The relative project path is prepended with the --path (base group) to form
#   the full GitLab project path for each discovered project.
#
#   License
#   -------
#   MIT License - Copyright 2026 Cyber Assessment Labs
#
#   Authors
#   -------
#   bena (via claude)
#
#   Version History
#   ---------------
#   Feb 2026 - Created
# ----------------------------------------------------------------------------------------

# ----------------------------------------------------------------------------------------
#   Imports
# ----------------------------------------------------------------------------------------

import logging
import urllib.error
from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import as_completed
from dataclasses import dataclass
from pathlib import Path
from .colour import bold
from .colour import cyan
from .colour import green
from .colour import red
from .colour import yellow
from .gitlab_api import GitLabClient
from .version_filter import matches_version_filter

# ----------------------------------------------------------------------------------------
#   Types
# ----------------------------------------------------------------------------------------


@dataclass
class UploadResult:
    """Result of an upload operation."""

    success: bool
    total_projects: int = 0
    total_releases: int = 0
    total_files: int = 0
    uploaded_files: int = 0
    skipped_files: int = 0
    failed_files: int = 0
    error_message: str | None = None


@dataclass
class UploadConfig:
    """Configuration for the upload operation."""

    gitlab_url: str
    path: str
    input_dir: Path
    token: str | None = None
    version_filter: str = "all"
    project_filter: str | None = None
    parallel: int = 32
    dry_run: bool = False


@dataclass
class _UploadTask:
    """A single file upload task."""

    project_id: int
    tag_name: str
    file_path: Path
    asset_name: str
    relative_key: str
    project_path: str


# ----------------------------------------------------------------------------------------
#   Functions
# ----------------------------------------------------------------------------------------


# ----------------------------------------------------------------------------------------
def upload_releases(config: UploadConfig) -> UploadResult:
    """
    Upload release assets to GitLab projects.

    Scans the input directory for release assets, creates releases on GitLab
    if they don't exist, and uploads asset files as release links.

    Parameters:
        config: Upload configuration

    Returns:
        UploadResult with statistics about the upload
    """
    logger = logging.getLogger(__name__)

    # Validate input directory
    if not config.input_dir.exists():
        return UploadResult(
            success=False,
            error_message=f"Input directory not found: {config.input_dir}",
        )

    if not config.input_dir.is_dir():
        return UploadResult(
            success=False,
            error_message=f"Not a directory: {config.input_dir}",
        )

    # Create GitLab client
    client = GitLabClient(config.gitlab_url, token=config.token)

    # Scan input directory
    print(f"Scanning {config.input_dir}...")
    projects_data = _scan_input_directory(config.input_dir)

    if not projects_data:
        print("No release assets found in input directory.")
        return UploadResult(success=True)

    print(f"Found {len(projects_data)} project(s) with release assets")

    result = UploadResult(success=True, total_projects=len(projects_data))

    # Phase 1: Resolve projects, create releases, gather upload tasks
    all_tasks: list[_UploadTask] = []

    print(f"Connecting to {config.gitlab_url}...")

    for relative_path in sorted(projects_data):
        tags = projects_data[relative_path]

        # Build full project path
        if relative_path:
            full_path = f"{config.path}/{relative_path}"
        else:
            full_path = config.path

        # Apply project filter
        if config.project_filter:
            if config.project_filter.lower() not in full_path.lower():
                result.total_projects -= 1
                continue

        print(f"\n{bold(full_path)}")

        # Resolve project on GitLab
        try:
            path_type, project_id = client.resolve_path(full_path)
            if path_type != "project":
                print(f"  {red('Error')} - Path is a group, not a project: {full_path}")
                file_count = sum(len(files) for files in tags.values())
                result.failed_files += file_count
                result.total_files += file_count
                continue
        except ValueError:
            print(f"  {red('Error')} - Project not found: {full_path}")
            file_count = sum(len(files) for files in tags.values())
            result.failed_files += file_count
            result.total_files += file_count
            continue
        except urllib.error.URLError as e:
            print(f"  {red('Error')} - Connection failed: {e}")
            file_count = sum(len(files) for files in tags.values())
            result.failed_files += file_count
            result.total_files += file_count
            continue

        # Process each tag
        for tag_name in sorted(tags):
            files = tags[tag_name]

            # Apply version filter
            if not matches_version_filter(tag_name, config.version_filter):
                logger.debug(f"Skipping tag {tag_name} (version filter)")
                continue

            result.total_releases += 1
            result.total_files += len(files)

            # Ensure release exists
            existing_asset_names: set[str] = set()
            try:
                release = client.get_release(project_id, tag_name)
                if release is None:
                    if config.dry_run:
                        print(f"  {cyan('Would create')} release: {tag_name}")
                    else:
                        client.create_release(project_id, tag_name)
                        print(f"  {green('Created')} release: {tag_name}")
                else:
                    # Gather existing asset names to avoid duplicates
                    for asset in release.assets:
                        existing_asset_names.add(asset.name)
            except urllib.error.HTTPError as e:
                if e.code == 422:
                    # 422 usually means release already exists - try to get it
                    logger.debug(f"Release {tag_name} may already exist: {e}")
                    try:
                        release = client.get_release(project_id, tag_name)
                        if release:
                            for asset in release.assets:
                                existing_asset_names.add(asset.name)
                    except urllib.error.HTTPError:
                        pass
                else:
                    print(
                        f"  {red('Error')} - Failed to create release {tag_name}: {e}"
                    )
                    result.failed_files += len(files)
                    continue

            # Gather upload tasks for this tag
            for file_path in files:
                # Check if already exists on release
                if file_path.name in existing_asset_names:
                    result.skipped_files += 1
                    print(
                        f"  {yellow('Skipped')}    - "
                        f"{tag_name}: {file_path.name} (already on release)"
                    )
                    continue

                all_tasks.append(
                    _UploadTask(
                        project_id=project_id,
                        tag_name=tag_name,
                        file_path=file_path,
                        asset_name=file_path.name,
                        relative_key=str(file_path.relative_to(config.input_dir)),
                        project_path=full_path,
                    )
                )

    if not all_tasks:
        return result

    if config.dry_run:
        print(f"\nDry run: would upload {len(all_tasks)} file(s)")
        for task in all_tasks:
            print(f"  {cyan('Would upload')} - {task.tag_name}: {task.asset_name}")
        result.uploaded_files = len(all_tasks)
        return result

    # Phase 2: Upload files in parallel
    print(f"\nUploading {len(all_tasks)} file(s) with {config.parallel} threads...")

    with ThreadPoolExecutor(max_workers=config.parallel) as executor:
        futures_list = [
            executor.submit(_upload_single_file, client, task) for task in all_tasks
        ]
        future_to_idx = {f: i for i, f in enumerate(futures_list)}
        completed_ul: dict[int, BaseException | None] = {}
        next_to_print = 0
        printed = 0

        for future in as_completed(future_to_idx):
            idx = future_to_idx[future]
            error: BaseException | None = None
            try:
                future.result()
            except (urllib.error.HTTPError, urllib.error.URLError, OSError) as e:
                error = e
            completed_ul[idx] = error

            # Flush consecutive results in submission order
            while next_to_print in completed_ul:
                err = completed_ul.pop(next_to_print)
                task = all_tasks[next_to_print]
                printed += 1
                progress = f"[{printed}/{len(all_tasks)}]"

                if err is None:
                    result.uploaded_files += 1
                    print(
                        f"  {green('Uploaded')}   - "
                        f"{task.tag_name}: {task.asset_name}  {progress}"
                    )
                else:
                    logger.debug(f"Failed to upload {task.asset_name}: {err}")
                    result.failed_files += 1
                    reason = ""
                    if isinstance(err, urllib.error.HTTPError):
                        reason = f" ({err.code})"
                    print(
                        f"  {red('Error')}{reason:6s} - "
                        f"{task.tag_name}: {task.asset_name}  {progress}"
                    )
                next_to_print += 1

    return result


# ----------------------------------------------------------------------------------------
def _upload_single_file(client: GitLabClient, task: _UploadTask) -> None:
    """
    Upload a single file and create a release asset link.

    This function runs in a worker thread.

    Parameters:
        client: GitLab API client
        task: Upload task with file path and project/release info
    """
    # Step 1: Upload the file to the project
    upload_path = client.upload_project_file(task.project_id, task.file_path)

    # Step 2: Create a release asset link
    full_url = f"{client.gitlab_url}{upload_path}"
    client.create_release_link(
        task.project_id,
        task.tag_name,
        task.asset_name,
        full_url,
    )


# ----------------------------------------------------------------------------------------
def _scan_input_directory(
    input_dir: Path,
) -> dict[str, dict[str, list[Path]]]:
    """
    Scan the input directory for release assets.

    Identifies directories containing files as "tag directories". The path
    from input_dir to the parent of a tag directory is the relative project
    path. The tag directory name is the tag/release name.

    Expected structure::

        input_dir/
            project/path/
                tag_name/
                    asset_file

    Parameters:
        input_dir: Root directory to scan

    Returns:
        Dict mapping relative_project_path -> {tag_name -> [file_paths]}
        An empty relative_project_path ("") means files are directly under
        input_dir/tag_name/ (single project mode).
    """
    result: dict[str, dict[str, list[Path]]] = {}

    for item in sorted(input_dir.rglob("*")):
        if not item.is_dir():
            continue

        # A tag directory is one that contains actual files
        files = sorted(f for f in item.iterdir() if f.is_file())
        if not files:
            continue

        tag_name = item.name

        # Relative project path: from input_dir to the parent of this tag dir
        try:
            rel = item.parent.relative_to(input_dir)
        except ValueError:
            continue

        project_path = str(rel) if str(rel) != "." else ""

        if project_path not in result:
            result[project_path] = {}
        result[project_path][tag_name] = files

    return result


# ----------------------------------------------------------------------------------------
def format_result_summary(result: UploadResult) -> str:
    """
    Format a human-readable summary of the upload result.

    Parameters:
        result: The upload result to summarise

    Returns:
        Formatted summary string
    """
    lines: list[str] = []
    lines.append("")
    lines.append("Upload Summary")
    lines.append("==============")
    lines.append(f"Total projects: {result.total_projects}")
    lines.append(f"Total releases: {result.total_releases}")
    lines.append(f"Total files:    {result.total_files}")
    lines.append(f"Uploaded:       {result.uploaded_files}")

    if result.skipped_files > 0:
        lines.append(f"Skipped:        {result.skipped_files} (already exist)")

    if result.failed_files > 0:
        lines.append(f"Failed:         {result.failed_files}")

    return "\n".join(lines)
