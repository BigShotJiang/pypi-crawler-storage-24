"""Integration tests for Converra SDK's Anthropic wrapper.

Verifies:
 1. Wrapped non-streaming call succeeds despite fake Converra backend
 2. Wrapped streaming call yields all chunks
 3. Error isolation — Converra failures never affect the LLM call

Run:
  cd packages/python-sdk && source .venv/bin/activate
  ANTHROPIC_API_KEY=... python tests/test_anthropic.py
"""

import os
import sys

ANTHROPIC_KEY = os.environ.get("ANTHROPIC_API_KEY")
if not ANTHROPIC_KEY:
    print("SKIP: No ANTHROPIC_API_KEY set")
    sys.exit(0)

from anthropic import Anthropic
from converra import Converra

# ── setup ──────────────────────────────────────────────────────────────────

passed = 0
failed = 0


def assert_true(condition: bool, label: str) -> None:
    global passed, failed
    if condition:
        print(f"  PASS: {label}")
        passed += 1
    else:
        print(f"  FAIL: {label}")
        failed += 1


# Converra client pointed at a bogus endpoint — all Converra calls will fail
# silently, which is exactly the fail-safe behavior we want to verify.
converra = Converra(api_key="sk_test_anthropic", base_url="http://localhost:99999/api/v1")

client = Anthropic(api_key=ANTHROPIC_KEY)
wrapped = converra.wrap(client)

# ── Test 1: Non-streaming ─────────────────────────────────────────────────

print("\n--- Test 1: Wrapped non-streaming call ---")
response = wrapped.messages.create(
    model="claude-haiku-4-5-20251001",
    system="You are a test assistant.",
    messages=[{"role": "user", "content": 'Say "anthropic works" and nothing else'}],
    max_tokens=20,
)
content = response.content[0].text
print(f"  Response: \"{content}\"")
assert_true(isinstance(content, str) and len(content) > 0, "Non-streaming returns non-empty string")
assert_true(response.usage is not None, "Non-streaming includes usage data")
assert_true(response.model is not None, "Non-streaming includes model field")

# ── Test 2: Streaming ─────────────────────────────────────────────────────

print("\n--- Test 2: Wrapped streaming call ---")
stream = wrapped.messages.create(
    model="claude-haiku-4-5-20251001",
    system="You are a test assistant.",
    messages=[{"role": "user", "content": "Count from 1 to 3"}],
    max_tokens=30,
    stream=True,
)

chunks = []
for event in stream:
    if hasattr(event, "delta") and hasattr(event.delta, "text"):
        chunks.append(event.delta.text)

streamed_content = "".join(chunks)
print(f"  Chunks received: {len(chunks)}")
print(f"  Accumulated content: \"{streamed_content}\"")
assert_true(len(chunks) > 1, "Streaming yields multiple chunks")
assert_true(len(streamed_content) > 0, "Streaming accumulates non-empty content")

# ── Test 3: Error isolation ───────────────────────────────────────────────

print("\n--- Test 3: Error isolation (broken Converra config) ---")
broken_converra = Converra(api_key="sk_broken_key", base_url="http://0.0.0.0:1/bad")
broken_wrapped = broken_converra.wrap(Anthropic(api_key=ANTHROPIC_KEY))

response = broken_wrapped.messages.create(
    model="claude-haiku-4-5-20251001",
    system="You are a test assistant.",
    messages=[{"role": "user", "content": 'Say "isolated" and nothing else'}],
    max_tokens=20,
)
content = response.content[0].text
print(f"  Response: \"{content}\"")
assert_true(content is not None and len(content) > 0, "LLM call succeeds despite broken Converra")

# ── Summary ───────────────────────────────────────────────────────────────

print(f"\n========================================")
print(f"  Results: {passed} passed, {failed} failed")
print(f"========================================\n")

if failed > 0:
    sys.exit(1)
