"""Cross-language hash parity test - imports _hasher directly to avoid full SDK deps."""
import hashlib
import re
import json

# Inline the same logic from converra/_hasher.py to avoid import chain pulling in httpx
def normalize_prompt_content(content: str) -> str:
    result = content.strip()
    result = re.sub(r"\s+", " ", result)
    result = re.sub(r"\n+$", "", result)
    return result

def hash_prompt_content(content: str) -> str:
    normalized = normalize_prompt_content(content)
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()

inputs = [
    "You are a helpful assistant",
    "  Lots   of   spaces   and\n\nnewlines\n\n",
    "Unicode: こんにちは 🎉 café",
    "",
    "You are a customer support agent for TechCorp. You handle inquiries about products, billing, and technical issues. Always be polite and professional. If you don't know the answer, say so honestly. Never make up information. Always verify the customer's identity before discussing account details. Use the customer's name when addressing them. Keep responses concise but thorough. If the issue requires escalation, explain the process clearly."
]

for inp in inputs:
    h = hash_prompt_content(inp)
    n = normalize_prompt_content(inp)
    print(json.dumps({"input": inp[:30], "normalized": n[:50], "hash": h}))
