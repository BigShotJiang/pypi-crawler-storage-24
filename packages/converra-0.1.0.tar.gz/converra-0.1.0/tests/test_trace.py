import sys
import os

# Add src to path so we can import converra
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from converra._trace import Trace

# Test 1: Trace creation
trace = Trace(trace_id='test-session', session_id='session-123')
print(f'Trace created: {trace.trace_id}, {trace.session_id}')

# Test 2: Steps
step1 = trace.add_step(
    system_prompt_hash='abc123',
    system_prompt_content='You are an orchestrator',
    model='gpt-4o',
    request={'messages': [{'role': 'user', 'content': 'hello'}]},
    response={'content': 'Hi there!'},
    timing={'started_at': 0, 'completed_at': 100, 'latency_ms': 100},
)
print(f'Step 1 sequence: {step1.sequence_index}')

step2 = trace.add_step(
    system_prompt_hash='def456',
    system_prompt_content='You are a support agent',
    model='gpt-4o',
    request={'messages': [{'role': 'user', 'content': 'help'}]},
    response={'content': 'How can I help?'},
    timing={'started_at': 100, 'completed_at': 150, 'latency_ms': 50},
)
print(f'Step 2 sequence: {step2.sequence_index}')

# Test 3: Payload
payload = trace.to_payload()
print(f'Payload steps: {len(payload["steps"])}')

# Test 4: Context manager propagation
with trace:
    current = Trace.current()
    print(f'Trace.current() inside with: {current is trace}')

# Test 5: Outside context
outside = Trace.current()
print(f'Trace.current() outside with: {outside is None}')

print('\nAll trace tests passed!')
