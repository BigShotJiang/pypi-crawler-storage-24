"""Unit tests for SDK cache, transport, and variant resolver."""

import time
from unittest.mock import MagicMock

from converra._cache import TtlCache
from converra._transport import Transport
from converra._variant_resolver import VariantResolver


# ---------------------------------------------------------------------------
# Test 1: TtlCache — TTL expiration
# ---------------------------------------------------------------------------


def test_cache_returns_value_before_ttl():
    """Cache.get() returns the stored value immediately."""
    cache: TtlCache[str] = TtlCache(ttl=0.1)
    cache.set("key1", "hello")
    assert cache.get("key1") == "hello"


def test_cache_expires_after_ttl():
    """Cache.get() returns None after the TTL has elapsed."""
    cache: TtlCache[str] = TtlCache(ttl=0.1)
    cache.set("key1", "hello")
    time.sleep(0.2)
    assert cache.get("key1") is None


def test_cache_delete():
    """Cache.delete() removes an entry and returns True."""
    cache: TtlCache[str] = TtlCache(ttl=10.0)
    cache.set("key1", "value")
    assert cache.delete("key1") is True
    assert cache.get("key1") is None


def test_cache_delete_missing_key():
    """Cache.delete() returns False for a missing key."""
    cache: TtlCache[str] = TtlCache(ttl=10.0)
    assert cache.delete("nonexistent") is False


def test_cache_clear():
    """Cache.clear() removes all entries."""
    cache: TtlCache[str] = TtlCache(ttl=10.0)
    cache.set("a", "1")
    cache.set("b", "2")
    cache.clear()
    assert cache.size == 0
    assert cache.get("a") is None


def test_cache_size():
    """Cache.size returns the number of stored entries."""
    cache: TtlCache[int] = TtlCache(ttl=10.0)
    assert cache.size == 0
    cache.set("a", 1)
    cache.set("b", 2)
    assert cache.size == 2


# ---------------------------------------------------------------------------
# Test 2: Transport — enqueue and shutdown
# ---------------------------------------------------------------------------


def test_transport_enqueue_does_not_throw():
    """Enqueuing items to a transport with a fake URL should not raise."""
    transport = Transport(
        base_url="http://localhost:19999/api/v1",
        api_key="sk_test_fake",
        batch_size=10,
        flush_interval=60.0,
    )
    transport.enqueue({"event": "first"})
    transport.enqueue({"event": "second"})
    transport.shutdown()


def test_transport_shutdown_does_not_throw():
    """Calling shutdown() (even with pending items) should not raise."""
    transport = Transport(
        base_url="http://localhost:19999/api/v1",
        api_key="sk_test_fake",
        batch_size=10,
        flush_interval=60.0,
    )
    transport.enqueue({"event": "a"})
    transport.enqueue({"event": "b"})
    transport.enqueue({"event": "c"})
    transport.shutdown()


def test_transport_double_shutdown():
    """Calling shutdown() twice is safe (idempotent)."""
    transport = Transport(
        base_url="http://localhost:19999/api/v1",
        api_key="sk_test_fake",
    )
    transport.enqueue({"event": "x"})
    transport.shutdown()
    transport.shutdown()  # should not raise


def test_transport_enqueue_after_shutdown():
    """Enqueuing after shutdown is silently ignored."""
    transport = Transport(
        base_url="http://localhost:19999/api/v1",
        api_key="sk_test_fake",
    )
    transport.shutdown()
    transport.enqueue({"event": "late"})  # should not raise


# ---------------------------------------------------------------------------
# Test 3: VariantResolver — graceful None on fake API
# ---------------------------------------------------------------------------


def test_variant_resolver_match_prompt_returns_none():
    """match_prompt() returns None when the API client fails."""
    mock_api = MagicMock()
    mock_api.post.side_effect = Exception("connection refused")

    resolver = VariantResolver(api=mock_api, prompt_cache_ttl=0.1)
    result = resolver.match_prompt("You are a helpful assistant.")
    assert result is None


def test_variant_resolver_get_active_variant_returns_none():
    """get_active_variant() returns None when the API client fails."""
    mock_api = MagicMock()
    mock_api.get.side_effect = Exception("connection refused")

    resolver = VariantResolver(api=mock_api, variant_cache_ttl=0.1)
    result = resolver.get_active_variant("prompt_123")
    assert result is None


def test_variant_resolver_api_returns_none():
    """match_prompt() returns None when API returns None (404/error)."""
    mock_api = MagicMock()
    mock_api.post.return_value = None

    resolver = VariantResolver(api=mock_api)
    result = resolver.match_prompt("test content")
    assert result is None


def test_variant_resolver_caches_successful_result():
    """A successful match is cached and doesn't call the API again."""
    mock_api = MagicMock()
    mock_api.post.return_value = {
        "data": {
            "promptId": "p_1",
            "name": "Test",
            "contentHash": "abc123",
            "matched": True,
        }
    }

    resolver = VariantResolver(api=mock_api, prompt_cache_ttl=10.0)

    # First call hits the API
    result1 = resolver.match_prompt("You are helpful.")
    assert result1 is not None
    assert result1.prompt_id == "p_1"

    # Second call with same content should use cache
    result2 = resolver.match_prompt("You are helpful.")
    assert result2 is not None
    assert result2.prompt_id == "p_1"

    # API was only called once
    assert mock_api.post.call_count == 1


def test_variant_resolver_invalidate():
    """invalidate() clears the variant cache for a prompt."""
    mock_api = MagicMock()
    mock_api.get.return_value = {
        "data": {
            "hasActiveVariant": True,
            "assignment": "variant",
            "optimizationId": "opt_1",
        }
    }

    resolver = VariantResolver(api=mock_api, variant_cache_ttl=10.0)

    # First call
    resolver.get_active_variant("p_1")
    assert mock_api.get.call_count == 1

    # Cached — no new API call
    resolver.get_active_variant("p_1")
    assert mock_api.get.call_count == 1

    # Invalidate and call again — should hit API
    resolver.invalidate("p_1")
    resolver.get_active_variant("p_1")
    assert mock_api.get.call_count == 2
