import json
import sys
import os

# Add src to path so we can import converra
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from converra._trace import Trace

trace = Trace(trace_id='parity-test', session_id='session-1')

trace.add_step(
    agent_name='orchestrator',
    system_prompt_hash='aaa111',
    system_prompt_content='You are an orchestrator',
    model='gpt-4o',
    request={'messages': [{'role': 'system', 'content': 'You are an orchestrator'}, {'role': 'user', 'content': 'hello'}]},
    response={'content': 'Routing to support agent', 'toolCalls': [{'name': 'route', 'args': {'agent': 'support'}}]},
    timing={'startedAt': 1000, 'completedAt': 1100, 'latencyMs': 100},
)

trace.add_step(
    agent_name='support-agent',
    system_prompt_hash='bbb222',
    system_prompt_content='You are a support agent',
    model='gpt-4o',
    request={'messages': [{'role': 'system', 'content': 'You are a support agent'}, {'role': 'user', 'content': 'I need help'}]},
    response={'content': 'How can I help you?', 'usage': {'promptTokens': 50, 'completionTokens': 10}},
    timing={'startedAt': 1100, 'completedAt': 1200, 'latencyMs': 100},
)

payload = trace.to_payload()

# Print structural comparison (exclude auto-generated stepIds)
print(json.dumps({
    'traceId': payload['traceId'],
    'sessionId': payload['sessionId'],
    'stepCount': len(payload['steps']),
    'step0': {
        'sequenceIndex': payload['steps'][0]['sequenceIndex'],
        'agentName': payload['steps'][0]['agentName'],
        'systemPromptHash': payload['steps'][0]['systemPromptHash'],
        'model': payload['steps'][0]['model'],
        'responseContent': payload['steps'][0]['response']['content'],
        'latencyMs': payload['steps'][0]['timing']['latencyMs'],
    },
    'step1': {
        'sequenceIndex': payload['steps'][1]['sequenceIndex'],
        'agentName': payload['steps'][1]['agentName'],
        'systemPromptHash': payload['steps'][1]['systemPromptHash'],
        'model': payload['steps'][1]['model'],
        'responseContent': payload['steps'][1]['response']['content'],
        'latencyMs': payload['steps'][1]['timing']['latencyMs'],
    },
}, indent=2))
