"""Test LangChain callback handler."""
import sys
sys.path.insert(0, 'src')

from converra._interceptor import Interceptor
from converra._variant_resolver import VariantResolver
from converra._transport import Transport
from converra._api import ApiClient
from converra._types import WrapOptions
from converra.instrumentors._langchain import ConverraCallbackHandler


class MockMessage:
    def __init__(self, type, content):
        self.type = type
        self.content = content


class MockGeneration:
    def __init__(self, text):
        self.text = text
        self.message = MockMessage("ai", text)


class MockLLMResult:
    def __init__(self, text, token_usage=None):
        self.generations = [[MockGeneration(text)]]
        self.llm_output = {"token_usage": token_usage} if token_usage else None


def make_handler():
    api = ApiClient(base_url="http://localhost:99999/api/v1", api_key="sk_fake", timeout=1.0)
    resolver = VariantResolver(api=api, prompt_cache_ttl=300, variant_cache_ttl=30)
    transport = Transport(base_url="http://localhost:99999/api/v1", api_key="sk_fake")
    interceptor = Interceptor(resolver=resolver, transport=transport, options=WrapOptions(), testing_mode="simulation")
    return ConverraCallbackHandler(interceptor)


def test_on_llm_start_with_messages():
    handler = make_handler()
    messages = [[
        MockMessage("system", "You are a helpful assistant."),
        MockMessage("human", "Hello"),
    ]]
    handler.on_llm_start(
        serialized={},
        prompts=None,
        run_id="run-1",
        messages=messages,
        invocation_params={"model_name": "gpt-4o"},
    )
    assert "run-1" in handler._active_runs
    print("on_llm_start with messages: passed")


def test_on_llm_end():
    handler = make_handler()
    # Start a run first
    messages = [[MockMessage("human", "Hello")]]
    handler.on_llm_start(serialized={}, prompts=None, run_id="run-2", messages=messages)

    # End it
    result = MockLLMResult("Hi there!", {"prompt_tokens": 10, "completion_tokens": 5})
    handler.on_llm_end(result, run_id="run-2")

    assert "run-2" not in handler._active_runs  # cleaned up
    print("on_llm_end: passed")


def test_on_llm_error_cleanup():
    handler = make_handler()
    messages = [[MockMessage("human", "Hello")]]
    handler.on_llm_start(serialized={}, prompts=None, run_id="run-3", messages=messages)

    handler.on_llm_error(Exception("test error"), run_id="run-3")
    assert "run-3" not in handler._active_runs
    print("on_llm_error cleanup: passed")


def test_on_llm_end_without_start():
    """Should not crash if end is called without a matching start."""
    handler = make_handler()
    result = MockLLMResult("response")
    handler.on_llm_end(result, run_id="nonexistent")  # should not throw
    print("on_llm_end without start: passed")


def test_message_type_mapping():
    handler = make_handler()
    messages = [[
        MockMessage("system", "System prompt"),
        MockMessage("human", "User message"),
        MockMessage("ai", "AI response"),
    ]]
    handler.on_llm_start(serialized={}, prompts=None, run_id="run-4", messages=messages)

    run_data = handler._active_runs["run-4"]
    roles = [m["role"] for m in run_data["messages"]]
    assert roles == ["system", "user", "assistant"], f"Got {roles}"
    print("message type mapping: passed")


if __name__ == "__main__":
    test_on_llm_start_with_messages()
    test_on_llm_end()
    test_on_llm_error_cleanup()
    test_on_llm_end_without_start()
    test_message_type_mapping()
    print("\nAll LangChain tests passed!")
