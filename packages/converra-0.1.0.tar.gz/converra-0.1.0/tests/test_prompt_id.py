"""
Integration test for explicit prompt_id option in Converra Python SDK.

Verifies that when `prompt_id` is provided to `converra.wrap()`:
 1. The SDK does NOT hash the system prompt
 2. The SDK does NOT call the `/sdk/prompts/match` endpoint
 3. The provided prompt_id is used directly for variant lookup and conversation capture
 4. LLM calls work with dynamic system prompts (hash would differ each time)
 5. Both non-streaming and streaming work correctly

Run:
  OPENAI_API_KEY=sk-... python packages/python-sdk/tests/test_prompt_id.py
"""

import os
import time
import random


def test_prompt_id_non_streaming():
    """Wrap with explicit prompt_id, verify non-streaming call works with dynamic prompt."""
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        print("SKIP: No OPENAI_API_KEY set")
        return

    from openai import OpenAI
    from converra import Converra

    client = OpenAI(api_key=api_key)

    # Wrap with fake Converra server + explicit prompt_id
    converra = Converra(api_key="sk_test_promptid", base_url="http://localhost:99999/api/v1")
    wrapped = converra.wrap(client, prompt_id="explicit-123")

    # Dynamic system prompt — hash would be different each call
    response = wrapped.chat.completions.create(
        model="gpt-4.1-mini",
        messages=[
            {"role": "system", "content": f"Dynamic prompt with RAG context: {time.time()}"},
            {"role": "user", "content": 'Say "promptId works" and nothing else'},
        ],
        max_tokens=10,
    )

    content = response.choices[0].message.content
    assert content is not None and len(content) > 0, f"Expected non-empty content, got: {content!r}"
    print(f"  PASS: Non-streaming with prompt_id: {content}")


def test_prompt_id_streaming():
    """Wrap with explicit prompt_id, verify streaming call works with dynamic prompt."""
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        print("SKIP: No OPENAI_API_KEY set")
        return

    from openai import OpenAI
    from converra import Converra

    client = OpenAI(api_key=api_key)

    converra = Converra(api_key="sk_test_promptid", base_url="http://localhost:99999/api/v1")
    wrapped = converra.wrap(client, prompt_id="explicit-123")

    stream = wrapped.chat.completions.create(
        model="gpt-4.1-mini",
        messages=[
            {"role": "system", "content": f"Dynamic: {random.random()}"},
            {"role": "user", "content": "Count 1 to 3"},
        ],
        max_tokens=30,
        stream=True,
    )

    chunks = []
    for chunk in stream:
        delta = chunk.choices[0].delta.content if chunk.choices else None
        if delta:
            chunks.append(delta)

    content = "".join(chunks)
    assert len(content) > 0, f"Expected non-empty streamed content, got: {content!r}"
    print(f"  PASS: Streaming with prompt_id ({len(chunks)} chunks): {content}")


def test_prompt_id_different_dynamic_content():
    """Second call with different dynamic content still works with same prompt_id."""
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        print("SKIP: No OPENAI_API_KEY set")
        return

    from openai import OpenAI
    from converra import Converra

    client = OpenAI(api_key=api_key)

    converra = Converra(api_key="sk_test_promptid", base_url="http://localhost:99999/api/v1")
    wrapped = converra.wrap(client, prompt_id="explicit-123")

    # Completely different dynamic content — proves no hash dependency
    response = wrapped.chat.completions.create(
        model="gpt-4.1-mini",
        messages=[
            {"role": "system", "content": f"Completely different prompt: {os.urandom(8).hex()}"},
            {"role": "user", "content": 'Say "still works" and nothing else'},
        ],
        max_tokens=10,
    )

    content = response.choices[0].message.content
    assert content is not None and len(content) > 0, f"Expected non-empty content, got: {content!r}"
    print(f"  PASS: Different dynamic content with same prompt_id: {content}")


def test_interceptor_uses_explicit_prompt_id():
    """Verify the Interceptor builds a ResolvedPrompt from prompt_id without hashing or API calls."""
    from converra._interceptor import Interceptor
    from converra._types import WrapOptions, ResolvedPrompt

    # Create a mock resolver that would fail if called
    class FailingResolver:
        def match_prompt(self, content):
            raise AssertionError("match_prompt should NOT be called when prompt_id is set")

        def get_active_variant(self, prompt_id):
            return None

        def preload(self, config):
            pass

    # Create a mock transport
    class NoopTransport:
        def __init__(self):
            self.payloads = []

        def enqueue(self, payload):
            self.payloads.append(payload)

    resolver = FailingResolver()
    transport = NoopTransport()
    options = WrapOptions(prompt_id="explicit-unit-test-456")

    interceptor = Interceptor(
        resolver=resolver,
        transport=transport,
        options=options,
        testing_mode="simulation",
    )

    # Call before_call with a system message
    messages = [
        {"role": "system", "content": "Dynamic system prompt " + str(time.time())},
        {"role": "user", "content": "Hello"},
    ]
    result = interceptor.before_call(messages)

    # Verify prompt_id is used directly
    assert result.resolved_prompt is not None, "resolved_prompt should not be None"
    assert result.resolved_prompt.prompt_id == "explicit-unit-test-456", (
        f"Expected prompt_id 'explicit-unit-test-456', got '{result.resolved_prompt.prompt_id}'"
    )
    assert result.resolved_prompt.matched is True, "matched should be True"
    assert result.resolved_prompt.content_hash == "", "content_hash should be empty (no hashing)"
    # No API call was made (FailingResolver.match_prompt was not called)
    print("  PASS: Interceptor uses explicit prompt_id without hashing or API calls")

    # Verify after_call uses the prompt_id for conversation capture
    interceptor.after_call(
        messages=messages,
        response_content="Hi there!",
        model="gpt-4.1-mini",
        intercept_result=result,
    )

    assert len(transport.payloads) == 1, f"Expected 1 payload, got {len(transport.payloads)}"
    payload = transport.payloads[0]
    assert payload["systemPromptId"] == "explicit-unit-test-456", (
        f"Expected systemPromptId 'explicit-unit-test-456', got '{payload['systemPromptId']}'"
    )
    print("  PASS: after_call uses explicit prompt_id for conversation capture")


if __name__ == "__main__":
    print("\n--- Explicit prompt_id tests ---\n")
    test_interceptor_uses_explicit_prompt_id()
    test_prompt_id_non_streaming()
    test_prompt_id_streaming()
    test_prompt_id_different_dynamic_content()
    print("\nAll prompt_id tests passed!")
