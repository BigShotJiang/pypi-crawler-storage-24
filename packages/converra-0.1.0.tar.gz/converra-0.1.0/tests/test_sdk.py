"""Integration tests for the Converra Python SDK."""
import os
import hashlib
import re

# Hash parity test
from converra._hasher import normalize_prompt_content, hash_prompt_content


def test_hash_parity():
    """Verify Python SDK hashes match the server/TS SDK exactly."""
    inputs = [
        "You are a helpful assistant",
        "You are a helpful assistant   ",
        "You are a helpful assistant\n\n",
        "You  are   a    helpful     assistant",
        "  You are a helpful assistant  ",
        "",
        "You are a helpful assistant. You help users.\n\nBe concise.",
    ]

    for text in inputs:
        # Python SDK hash
        sdk_hash = hash_prompt_content(text)

        # Reference hash (matching server's Node.js crypto)
        normalized = text.strip()
        normalized = re.sub(r"\s+", " ", normalized)
        normalized = re.sub(r"\n+$", "", normalized)
        ref_hash = hashlib.sha256(normalized.encode("utf-8")).hexdigest()

        assert sdk_hash == ref_hash, f"Hash mismatch for '{text[:30]}...': {sdk_hash} != {ref_hash}"

    print("Hash parity: 7/7 passed")


def test_normalization_consistency():
    """All whitespace variants of the same prompt produce the same hash."""
    variants = [
        "You are a helpful assistant",
        "You are a helpful assistant   ",
        "You are a helpful assistant\n\n",
        "You  are   a    helpful     assistant",
        "  You are a helpful assistant  ",
    ]
    hashes = {hash_prompt_content(v) for v in variants}
    assert len(hashes) == 1, f"Expected 1 unique hash, got {len(hashes)}"
    print("Normalization consistency: passed")


def test_wrap_openai_non_streaming():
    """Wrap OpenAI client, make a real non-streaming call."""
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        print("SKIP: No OPENAI_API_KEY set")
        return

    from openai import OpenAI
    from converra import Converra

    client = OpenAI(api_key=api_key)

    # Wrap with fake Converra server (will fail silently)
    converra = Converra(api_key="sk_fake", base_url="http://localhost:99999/api/v1")
    wrapped = converra.wrap(client)

    response = wrapped.chat.completions.create(
        model="gpt-4.1-mini",
        messages=[
            {"role": "system", "content": "You are a test assistant."},
            {"role": "user", "content": 'Say "python works" and nothing else'},
        ],
        max_tokens=10,
    )

    content = response.choices[0].message.content
    assert content is not None and len(content) > 0
    print(f"Non-streaming: {content}")


def test_wrap_openai_streaming():
    """Wrap OpenAI client, make a real streaming call."""
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        print("SKIP: No OPENAI_API_KEY set")
        return

    from openai import OpenAI
    from converra import Converra

    client = OpenAI(api_key=api_key)
    converra = Converra(api_key="sk_fake", base_url="http://localhost:99999/api/v1")
    wrapped = converra.wrap(client)

    stream = wrapped.chat.completions.create(
        model="gpt-4.1-mini",
        messages=[
            {"role": "system", "content": "You are a test assistant."},
            {"role": "user", "content": "Count from 1 to 5"},
        ],
        max_tokens=50,
        stream=True,
    )

    chunks = []
    for chunk in stream:
        delta = chunk.choices[0].delta.content if chunk.choices else None
        if delta:
            chunks.append(delta)

    content = "".join(chunks)
    assert len(content) > 0
    print(f"Streaming ({len(chunks)} chunks): {content}")


def test_error_isolation():
    """Converra errors must never affect the customer's LLM call."""
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        print("SKIP: No OPENAI_API_KEY set")
        return

    from openai import OpenAI
    from converra import Converra

    client = OpenAI(api_key=api_key)
    # Completely broken Converra config (valid key format but unreachable server)
    converra = Converra(api_key="sk_broken_key_for_testing", base_url="http://0.0.0.0:1/bad")
    wrapped = converra.wrap(client)

    # Should still work perfectly
    response = wrapped.chat.completions.create(
        model="gpt-4.1-mini",
        messages=[{"role": "user", "content": 'Say "isolated" and nothing else'}],
        max_tokens=10,
    )

    content = response.choices[0].message.content
    assert content is not None
    print(f"Error isolation: {content}")


if __name__ == "__main__":
    test_hash_parity()
    test_normalization_consistency()
    test_wrap_openai_non_streaming()
    test_wrap_openai_streaming()
    test_error_isolation()
    print("\nAll tests passed!")
