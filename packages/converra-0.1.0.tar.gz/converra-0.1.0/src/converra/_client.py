"""
Converra SDK Client

Main entry point. Initializes config, API client, transport, and resolver.
"""

from __future__ import annotations

from typing import Optional

import warnings

from converra._api import ApiClient
from converra._config import Config, resolve_config
from converra._trace import Trace
from converra._transport import Transport
from converra._types import SdkConfig, WrapOptions
from converra._variant_resolver import VariantResolver


class Converra:
    """Converra SDK client — initialize once, use everywhere."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: Optional[float] = None,
        cache_ttl: Optional[float] = None,
        batch_size: Optional[int] = None,
        flush_interval: Optional[float] = None,
    ) -> None:
        self._config: Config = resolve_config(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            cache_ttl=cache_ttl,
            batch_size=batch_size,
            flush_interval=flush_interval,
        )
        self._api = ApiClient(
            base_url=self._config.base_url,
            api_key=self._config.api_key,
            timeout=self._config.timeout,
        )
        self._transport = Transport(
            base_url=self._config.base_url,
            api_key=self._config.api_key,
            batch_size=self._config.batch_size,
            flush_interval=self._config.flush_interval,
        )
        self._resolver = VariantResolver(
            api=self._api,
            prompt_cache_ttl=self._config.cache_ttl,
            variant_cache_ttl=30.0,
        )
        self._sdk_config: Optional[SdkConfig] = None
        self._testing_mode = "simulation"

    def init(self) -> Converra:
        """Fetch SDK config from server and seed caches. Call once on startup."""
        resp = self._api.get("/sdk/config")
        if resp and "data" in resp:
            data = resp["data"]
            self._sdk_config = SdkConfig(
                testing_mode=data.get("testingMode", "simulation"),
                capture_enabled=data.get("captureEnabled", True),
                active_optimizations=data.get("activeOptimizations", []),
                prompt_hashes=data.get("promptHashes", {}),
            )
            self._testing_mode = self._sdk_config.testing_mode
            self._resolver.preload(self._sdk_config)
        return self

    @property
    def resolver(self) -> VariantResolver:
        """Access the variant resolver for prompt matching."""
        return self._resolver

    @property
    def transport(self) -> Transport:
        """Access the transport for manual payload enqueue."""
        return self._transport

    @property
    def testing_mode(self) -> str:
        """Current testing mode from server config."""
        return self._testing_mode

    def create_interceptor(self, options: Optional[WrapOptions] = None) -> "Interceptor":
        """Create an Interceptor bound to this client's resolver and transport."""
        from converra._interceptor import Interceptor

        return Interceptor(
            resolver=self._resolver,
            transport=self._transport,
            options=options or WrapOptions(),
            testing_mode=self._testing_mode,
        )

    def wrap(self, client: object, **kwargs) -> object:
        """Wrap an LLM client for transparent interception.

        Args:
            client: An OpenAI, AsyncOpenAI, Anthropic, or AsyncAnthropic client instance.
            **kwargs: Passed to WrapOptions (prompt_id, capture_enabled, etc.)

        Returns:
            The same client instance, patched in-place.
        """
        options = WrapOptions(**{k: v for k, v in kwargs.items() if v is not None})
        interceptor = self.create_interceptor(options)

        client_type = type(client).__name__
        module_name = type(client).__module__ or ""

        if client_type in ("OpenAI", "AsyncOpenAI") or "openai" in module_name:
            from converra.instrumentors._openai import instrument_openai
            return instrument_openai(client, interceptor)

        if client_type in ("Anthropic", "AsyncAnthropic") or "anthropic" in module_name:
            from converra.instrumentors._anthropic import instrument_anthropic
            return instrument_anthropic(client, interceptor)

        warnings.warn(f"[Converra] Unsupported client type: {client_type}. Returning unwrapped.")
        return client

    def trace(self, name: Optional[str] = None, session_id: Optional[str] = None) -> Trace:
        """Create a new trace context for multi-agent conversation tracking.

        Usage:
            with converra.trace("session-123") as t:
                response1 = client.chat.completions.create(...)
                response2 = client.chat.completions.create(...)
        """
        return Trace(trace_id=name, session_id=session_id)

    def shutdown(self) -> None:
        """Flush pending data and close connections. Call on process exit."""
        self._transport.shutdown()
        self._api.close()
