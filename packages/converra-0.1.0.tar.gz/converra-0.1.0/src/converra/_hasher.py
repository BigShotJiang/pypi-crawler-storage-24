"""
Converra SDK Content Hashing

SHA-256 content hashing that matches the server's normalizePromptContent()
and hashPromptContent() exactly.
"""

import hashlib
import re


def normalize_prompt_content(content: str) -> str:
    """Normalize prompt content for consistent hashing.
    Collapses whitespace and trims — must match server-side normalization exactly.
    """
    result = content.strip()
    result = re.sub(r"\s+", " ", result)
    result = re.sub(r"\n+$", "", result)
    return result


def hash_prompt_content(content: str) -> str:
    """Hash normalized prompt content using SHA-256.
    Returns lowercase hex string matching server-side hashPromptContent().
    """
    normalized = normalize_prompt_content(content)
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()
