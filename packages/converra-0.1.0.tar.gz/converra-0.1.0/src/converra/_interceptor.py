"""
Converra SDK Interceptor

Core interception logic for LLM provider wrappers.
Handles pre-call prompt matching/variant swapping and
post-call conversation capture.
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

from converra._hasher import hash_prompt_content
from converra._trace import Trace
from converra._transport import Transport
from converra._types import InterceptResult, WrapOptions
from converra._variant_resolver import VariantResolver

logger = logging.getLogger("converra")

Message = Dict[str, Any]


class Interceptor:
    """Pre/post call interception for transparent prompt swapping and capture."""

    def __init__(
        self,
        resolver: VariantResolver,
        transport: Transport,
        options: WrapOptions,
        testing_mode: str,
    ) -> None:
        self._resolver = resolver
        self._transport = transport
        self._options = options
        self._testing_mode = testing_mode

    def before_call(self, messages: List[Message]) -> InterceptResult:
        """Pre-call: match system prompt and resolve any active variant."""
        result = InterceptResult()

        try:
            # Extract system prompt
            system_msg = next(
                (m for m in messages if m.get("role") == "system"), None
            )
            if system_msg is None or not isinstance(system_msg.get("content"), str):
                return result
            result.original_system_prompt = system_msg["content"]

            # Match prompt — by explicit ID or content hash
            if self._options.prompt_id:
                from converra._types import ResolvedPrompt

                result.resolved_prompt = ResolvedPrompt(
                    prompt_id=self._options.prompt_id,
                    name="",
                    content_hash="",
                    matched=True,
                )
            else:
                result.resolved_prompt = self._resolver.match_prompt(
                    system_msg["content"]
                )

            if result.resolved_prompt is None:
                return result

            # Check for active variant (only in proxy mode)
            if (
                self._testing_mode == "proxy"
                and self._options.variant_swap_enabled is not False
            ):
                result.active_variant = self._resolver.get_active_variant(
                    result.resolved_prompt.prompt_id
                )

                av = result.active_variant
                if (
                    av is not None
                    and av.has_active_variant
                    and av.assignment == "variant"
                    and av.variant
                    and av.variant.get("content")
                ):
                    if self._options.render_prompt:
                        result.swapped_content = self._options.render_prompt(
                            av.variant["content"], messages
                        )
                    else:
                        result.swapped_content = av.variant["content"]
        except Exception:
            # Fail-safe: return unmodified result so the original call proceeds
            pass

        return result

    def after_call(
        self,
        messages: List[Message],
        response_content: str,
        model: str,
        intercept_result: InterceptResult,
        usage: Optional[Dict[str, int]] = None,
    ) -> None:
        """Post-call: capture the conversation for analysis."""
        if self._options.capture_enabled is False:
            return

        try:
            trace = Trace.current()
            system_prompt = intercept_result.original_system_prompt or ""

            # Add step to active trace if one exists
            if trace is not None:
                content_hash = hash_prompt_content(system_prompt)

                variant_meta: Optional[Dict[str, str]] = None
                av = intercept_result.active_variant
                rp = intercept_result.resolved_prompt
                if (
                    av is not None
                    and av.assignment == "variant"
                    and rp is not None
                    and av.variant
                ):
                    variant_meta = {
                        "promptId": rp.prompt_id,
                        "optimizationId": av.optimization_id or "",
                        "variantId": av.variant.get("id", ""),
                        "assignment": "variant",
                    }

                trace.add_step(
                    system_prompt_hash=content_hash,
                    system_prompt_content=system_prompt,
                    model=model,
                    request={"messages": messages},
                    response={"content": response_content, "usage": usage},
                    timing={
                        "startedAt": 0,
                        "completedAt": 0,
                        "latencyMs": 0,
                    },
                    variant=variant_meta,
                )
                return  # Trace will be flushed when the context manager exits

            # No trace context — send as individual conversation
            transcript_parts: List[str] = []
            for m in messages:
                if m.get("role") == "system":
                    continue
                role_label = "User" if m.get("role") == "user" else "AI"
                content = m.get("content", "")
                if not isinstance(content, str):
                    import json

                    content = json.dumps(content)
                transcript_parts.append(f"{role_label}: {content}")
            transcript_parts.append(f"AI: {response_content}")

            av = intercept_result.active_variant
            self._transport.enqueue(
                {
                    "content": "\n".join(transcript_parts),
                    "userId": "sdk",
                    "systemPromptId": (
                        intercept_result.resolved_prompt.prompt_id
                        if intercept_result.resolved_prompt
                        else None
                    ),
                    "status": "completed",
                    "metadata": {
                        "source": "sdk",
                        "model": model,
                        "variantId": (
                            av.variant.get("id") if av and av.variant else None
                        ),
                        "optimizationId": (
                            av.optimization_id if av else None
                        ),
                        "assignment": av.assignment if av else "baseline",
                    },
                }
            )
        except Exception:
            # Fail-safe: never break the caller's LLM call
            pass
