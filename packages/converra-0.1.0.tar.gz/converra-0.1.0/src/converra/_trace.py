"""
Converra SDK Trace Context

Manages multi-agent trace lifecycle using contextvars for propagation.
Each trace captures an ordered sequence of LLM steps across multiple
agents within a single request or workflow.

Usage:
    from converra import Trace

    trace = Trace()
    with trace:
        trace.step("Router")
        trace.add_step(
            system_prompt_hash="abc123",
            system_prompt_content="You are a router...",
            model="gpt-4o",
            request={"messages": [{"role": "user", "content": "Hello"}]},
            response={"content": "Routing to Sales agent"},
            timing={"startedAt": 0, "completedAt": 120, "latencyMs": 120},
        )
"""

from __future__ import annotations

import contextvars
import copy
import uuid
from typing import Any, Dict, List, Optional, Sequence

from converra._types import TraceStep

_current_trace: contextvars.ContextVar[Optional[Trace]] = contextvars.ContextVar(
    "converra_trace", default=None
)


class Trace:
    """Multi-step trace context with context-manager support."""

    def __init__(
        self, trace_id: Optional[str] = None, session_id: Optional[str] = None
    ) -> None:
        self.trace_id = trace_id or str(uuid.uuid4())
        self.session_id = session_id
        self._steps: List[TraceStep] = []
        self._sequence_counter = 0
        self._started_at = _now_ms()
        self._next_step_label: Optional[str] = None
        self._metadata: Dict[str, Any] = {}
        self._token: Optional[contextvars.Token[Optional[Trace]]] = None

    # -- Context manager --

    def __enter__(self) -> Trace:
        self._token = _current_trace.set(self)
        return self

    def __exit__(self, *_: Any) -> None:
        if self._token is not None:
            _current_trace.reset(self._token)
            self._token = None

    # -- Step management --

    def step(self, label: str) -> None:
        """Label the next step. Consumed by the next add_step() call."""
        self._next_step_label = label

    def add_step(
        self,
        system_prompt_hash: str,
        system_prompt_content: str,
        model: str,
        request: Dict[str, Any],
        response: Dict[str, Any],
        timing: Dict[str, Any],
        agent_name: Optional[str] = None,
        parent_step_id: Optional[str] = None,
        variant: Optional[Dict[str, str]] = None,
    ) -> TraceStep:
        """Add a completed LLM step to the trace."""
        full_step = TraceStep(
            step_id=str(uuid.uuid4()),
            sequence_index=self._sequence_counter,
            agent_name=self._next_step_label or agent_name,
            system_prompt_hash=system_prompt_hash,
            system_prompt_content=system_prompt_content,
            model=model,
            request=request,
            response=response,
            timing=timing,
            parent_step_id=parent_step_id,
            variant=variant,
        )
        self._sequence_counter += 1
        self._next_step_label = None
        self._steps.append(full_step)
        return full_step

    # -- Metadata --

    def set_metadata(self, data: Dict[str, Any]) -> None:
        """Attach arbitrary metadata (shallow-merged)."""
        self._metadata.update(data)

    # -- Export --

    def to_payload(self) -> Dict[str, Any]:
        """Export trace data for transport. Returns a snapshot."""
        return {
            "traceId": self.trace_id,
            "sessionId": self.session_id,
            "steps": [_step_to_dict(s) for s in self._steps],
            "startedAt": self._started_at,
            "metadata": copy.copy(self._metadata),
        }

    def get_steps(self) -> Sequence[TraceStep]:
        """Get all steps recorded so far (read-only view)."""
        return list(self._steps)

    # -- Static accessor --

    @staticmethod
    def current() -> Optional[Trace]:
        """Get the current active trace from contextvars, or None."""
        return _current_trace.get()


def _now_ms() -> int:
    """Current time in milliseconds."""
    import time

    return int(time.time() * 1000)


def _step_to_dict(step: TraceStep) -> Dict[str, Any]:
    """Convert a TraceStep dataclass to a JSON-serializable dict."""
    d: Dict[str, Any] = {
        "stepId": step.step_id,
        "sequenceIndex": step.sequence_index,
        "systemPromptHash": step.system_prompt_hash,
        "systemPromptContent": step.system_prompt_content,
        "model": step.model,
        "request": step.request,
        "response": step.response,
        "timing": step.timing,
    }
    if step.agent_name is not None:
        d["agentName"] = step.agent_name
    if step.parent_step_id is not None:
        d["parentStepId"] = step.parent_step_id
    if step.variant is not None:
        d["variant"] = step.variant
    return d
