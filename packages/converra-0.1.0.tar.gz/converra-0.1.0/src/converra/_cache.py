"""
Converra SDK Cache

Thread-safe TTL cache for prompt lookups and variant assignments.
"""

from __future__ import annotations

import threading
import time
from typing import Dict, Generic, Optional, TypeVar

T = TypeVar("T")


class _Entry(Generic[T]):
    __slots__ = ("data", "cached_at")

    def __init__(self, data: T, cached_at: float) -> None:
        self.data = data
        self.cached_at = cached_at


class TtlCache(Generic[T]):
    """Thread-safe in-memory cache with per-entry TTL expiration."""

    def __init__(self, ttl: float = 300.0) -> None:
        self._ttl = ttl
        self._store: Dict[str, _Entry[T]] = {}
        self._lock = threading.Lock()

    def get(self, key: str) -> Optional[T]:
        """Return cached value if present and not expired, else None."""
        with self._lock:
            entry = self._store.get(key)
            if entry is None:
                return None
            if time.monotonic() - entry.cached_at > self._ttl:
                del self._store[key]
                return None
            return entry.data

    def set(self, key: str, value: T) -> None:
        """Store a value with the current timestamp."""
        with self._lock:
            self._store[key] = _Entry(value, time.monotonic())

    def delete(self, key: str) -> bool:
        """Remove a key. Returns True if it existed."""
        with self._lock:
            return self._store.pop(key, None) is not None

    def clear(self) -> None:
        """Remove all entries."""
        with self._lock:
            self._store.clear()

    @property
    def size(self) -> int:
        """Number of entries (including possibly expired ones)."""
        with self._lock:
            return len(self._store)
