"""
Converra SDK HTTP Client

Thin wrapper around httpx for API communication.
Sync only — never throws on Converra errors (returns None).
"""

from __future__ import annotations

import logging
from typing import Any, Dict, Optional

import httpx

logger = logging.getLogger("converra")


class ApiClient:
    """Low-level HTTP client for Converra API calls."""

    def __init__(self, base_url: str, api_key: str, timeout: float = 10.0) -> None:
        self._base_url = base_url
        self._client = httpx.Client(
            base_url=base_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            timeout=timeout,
        )

    def post(self, path: str, body: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """POST JSON to Converra API. Returns parsed response or None on error."""
        try:
            resp = self._client.post(path, json=body)
            if resp.status_code >= 400:
                logger.debug("Converra API error: %s %s", resp.status_code, path)
                return None
            return resp.json()
        except Exception:
            logger.debug("Converra API request failed: POST %s", path, exc_info=True)
            return None

    def get(
        self, path: str, params: Optional[Dict[str, str]] = None
    ) -> Optional[Dict[str, Any]]:
        """GET from Converra API. Returns parsed response or None on error."""
        try:
            resp = self._client.get(path, params=params)
            if resp.status_code >= 400:
                logger.debug("Converra API error: %s %s", resp.status_code, path)
                return None
            return resp.json()
        except Exception:
            logger.debug("Converra API request failed: GET %s", path, exc_info=True)
            return None

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()
