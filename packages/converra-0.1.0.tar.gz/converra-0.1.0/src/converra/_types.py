"""Converra SDK Types — mirrors the TypeScript SDK type definitions."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Sequence


@dataclass
class TraceStep:
    """A single LLM call within a trace."""

    step_id: str
    sequence_index: int
    system_prompt_hash: str
    system_prompt_content: str
    model: str
    request: Dict[str, Any]
    response: Dict[str, Any]
    timing: Dict[str, Any]
    agent_name: Optional[str] = None
    parent_step_id: Optional[str] = None
    variant: Optional[Dict[str, str]] = None


@dataclass
class ResolvedPrompt:
    """Result of matching a system prompt by content hash."""

    prompt_id: str
    name: str
    content_hash: str
    matched: bool


@dataclass
class ActiveVariant:
    """Active variant assignment for a prompt during optimization."""

    has_active_variant: bool
    assignment: str  # "baseline" | "variant"
    optimization_id: Optional[str] = None
    variant: Optional[Dict[str, str]] = None
    traffic_split: Optional[Dict[str, float]] = None


@dataclass
class SdkConfig:
    """Server-fetched SDK configuration."""

    testing_mode: str = "simulation"  # "proxy" | "simulation" | "off"
    capture_enabled: bool = True
    active_optimizations: List[Dict[str, Any]] = field(default_factory=list)
    prompt_hashes: Dict[str, str] = field(default_factory=dict)


@dataclass
class InterceptResult:
    """Result of pre-call interception."""

    original_system_prompt: Optional[str] = None
    resolved_prompt: Optional[ResolvedPrompt] = None
    active_variant: Optional[ActiveVariant] = None
    swapped_content: Optional[str] = None


@dataclass
class WrapOptions:
    """Options for wrapping an LLM client."""

    prompt_id: Optional[str] = None
    capture_enabled: Optional[bool] = None
    variant_swap_enabled: Optional[bool] = None
    render_prompt: Optional[Callable[[str, Sequence[Any]], str]] = None


Message = Dict[str, Any]
"""A chat message dict with at least 'role' and 'content' keys."""
