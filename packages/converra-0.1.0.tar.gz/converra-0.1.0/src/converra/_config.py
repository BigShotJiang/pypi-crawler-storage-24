"""
Converra SDK Configuration

Resolves config from constructor args > env vars > defaults.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Optional

_DEFAULT_BASE_URL = "https://app.converra.ai/api/v1"
_DEFAULT_TIMEOUT = 10.0
_DEFAULT_CACHE_TTL = 300  # 5 minutes, in seconds
_DEFAULT_BATCH_SIZE = 10
_DEFAULT_FLUSH_INTERVAL = 30.0  # seconds


@dataclass
class Config:
    """Resolved SDK configuration."""

    api_key: str
    base_url: str
    timeout: float
    cache_ttl: float
    batch_size: int
    flush_interval: float


def resolve_config(
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    timeout: Optional[float] = None,
    cache_ttl: Optional[float] = None,
    batch_size: Optional[int] = None,
    flush_interval: Optional[float] = None,
) -> Config:
    """Build a Config by layering: explicit args > env vars > defaults."""
    resolved_key = api_key or os.environ.get("CONVERRA_API_KEY", "")
    if not resolved_key:
        raise ValueError(
            "Converra API key is required. Pass api_key= or set CONVERRA_API_KEY."
        )

    resolved_url = (
        base_url
        or os.environ.get("CONVERRA_BASE_URL")
        or _DEFAULT_BASE_URL
    )
    # Strip trailing slash for consistent path joining
    resolved_url = resolved_url.rstrip("/")

    return Config(
        api_key=resolved_key,
        base_url=resolved_url,
        timeout=timeout if timeout is not None else _DEFAULT_TIMEOUT,
        cache_ttl=cache_ttl if cache_ttl is not None else _DEFAULT_CACHE_TTL,
        batch_size=batch_size if batch_size is not None else _DEFAULT_BATCH_SIZE,
        flush_interval=flush_interval if flush_interval is not None else _DEFAULT_FLUSH_INTERVAL,
    )
