"""
Converra SDK Variant Resolver

Handles prompt matching by content hash and active variant lookup,
with SDK-side caching to minimize API round-trips.
"""

from __future__ import annotations

from typing import Any, Dict, Optional

from converra._api import ApiClient
from converra._cache import TtlCache
from converra._hasher import hash_prompt_content
from converra._types import ActiveVariant, ResolvedPrompt, SdkConfig


class VariantResolver:
    """Resolves prompts by content hash and looks up active variants."""

    def __init__(
        self,
        api: ApiClient,
        prompt_cache_ttl: float = 300.0,
        variant_cache_ttl: float = 30.0,
    ) -> None:
        self._api = api
        self._prompt_cache: TtlCache[ResolvedPrompt] = TtlCache(ttl=prompt_cache_ttl)
        self._variant_cache: TtlCache[ActiveVariant] = TtlCache(ttl=variant_cache_ttl)

    def preload(self, config: SdkConfig) -> None:
        """Seed prompt cache from a bulk SDK config response."""
        for content_hash, prompt_id in config.prompt_hashes.items():
            self._prompt_cache.set(
                content_hash,
                ResolvedPrompt(
                    prompt_id=prompt_id,
                    name="",
                    content_hash=content_hash,
                    matched=True,
                ),
            )

    def match_prompt(self, content: str) -> Optional[ResolvedPrompt]:
        """Match a system prompt by its content hash. Returns None on miss."""
        try:
            content_hash = hash_prompt_content(content)

            cached = self._prompt_cache.get(content_hash)
            if cached is not None:
                return cached

            resp = self._api.post("/sdk/prompts/match", {"content": content})
            if resp is None:
                return None

            data = resp.get("data")
            if data is None:
                return None

            result = ResolvedPrompt(
                prompt_id=data["promptId"],
                name=data.get("name", ""),
                content_hash=data.get("contentHash", content_hash),
                matched=data.get("matched", True),
            )
            self._prompt_cache.set(content_hash, result)
            return result
        except Exception:
            return None

    def get_active_variant(
        self, prompt_id: str, session_id: Optional[str] = None
    ) -> Optional[ActiveVariant]:
        """Get the active variant for a prompt during an optimization."""
        try:
            cached = self._variant_cache.get(prompt_id)
            if cached is not None:
                return cached

            params: Dict[str, str] = {}
            if session_id:
                params["sessionId"] = session_id

            resp = self._api.get(
                f"/sdk/prompts/{prompt_id}/active-variant", params=params or None
            )
            if resp is None:
                return None

            data = resp.get("data")
            if data is None:
                return None

            result = ActiveVariant(
                has_active_variant=data.get("hasActiveVariant", False),
                assignment=data.get("assignment", "baseline"),
                optimization_id=data.get("optimizationId"),
                variant=data.get("variant"),
                traffic_split=data.get("trafficSplit"),
            )
            self._variant_cache.set(prompt_id, result)
            return result
        except Exception:
            return None

    def invalidate(self, prompt_id: str) -> None:
        """Invalidate the variant cache for a specific prompt."""
        self._variant_cache.delete(prompt_id)
