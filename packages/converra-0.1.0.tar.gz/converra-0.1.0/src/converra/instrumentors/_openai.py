"""
Converra SDK — OpenAI Instrumentor

Patches an OpenAI client instance to intercept ``client.chat.completions.create()``
for prompt variant swapping and conversation capture.

Handles four code paths:
  1. Sync non-streaming  — returns ``ChatCompletion``
  2. Sync streaming      — returns ``Stream[ChatCompletionChunk]``  (iterable)
  3. Async non-streaming — returns ``Coroutine[ChatCompletion]``
  4. Async streaming     — returns ``AsyncStream[ChatCompletionChunk]`` (async iterable)

All Converra logic is wrapped in bare ``except Exception`` guards so the
customer's LLM call is NEVER affected by SDK failures.
"""

from __future__ import annotations

import asyncio
import functools
from typing import Any, Dict, List, Optional, Sequence


# ---------------------------------------------------------------------------
# Type alias — avoids hard dependency on openai package
# ---------------------------------------------------------------------------

Message = Dict[str, Any]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _swap_system_message(messages: List[Message], new_content: str) -> List[Message]:
    """Replace the system message content, preserving everything else."""
    return [
        {**msg, "content": new_content} if msg.get("role") == "system" else msg
        for msg in messages
    ]


def _extract_usage(response: Any) -> Optional[Dict[str, int]]:
    """Pull prompt/completion token counts from a ChatCompletion response."""
    try:
        usage = response.usage
        if usage is None:
            return None
        return {
            "promptTokens": usage.prompt_tokens,
            "completionTokens": usage.completion_tokens,
        }
    except Exception:
        return None


def _extract_content(response: Any) -> str:
    """Extract assistant text from a non-streaming ChatCompletion."""
    try:
        return response.choices[0].message.content or ""
    except Exception:
        return ""


# ---------------------------------------------------------------------------
# Sync stream wrapper
# ---------------------------------------------------------------------------

class _SyncStreamWrapper:
    """Wraps an OpenAI sync ``Stream`` — yields chunks, accumulates content,
    captures the conversation on completion.
    """

    def __init__(
        self,
        stream: Any,
        interceptor: Any,
        messages: List[Message],
        intercept_result: Any,
        model: str,
    ) -> None:
        self._stream = stream
        self._interceptor = interceptor
        self._messages = messages
        self._intercept_result = intercept_result
        self._model = model
        self._accumulated: List[str] = []
        self._usage: Optional[Dict[str, int]] = None

    # -- iteration ----------------------------------------------------------

    def __iter__(self) -> "_SyncStreamWrapper":
        return self

    def __next__(self) -> Any:
        try:
            chunk = next(self._stream)
        except StopIteration:
            self._capture()
            raise
        self._accumulate(chunk)
        return chunk

    # -- context manager (``with client.chat.completions.create(...) as s``) -

    def __enter__(self) -> "_SyncStreamWrapper":
        if hasattr(self._stream, "__enter__"):
            self._stream.__enter__()
        return self

    def __exit__(self, *args: Any) -> None:
        self._capture()
        if hasattr(self._stream, "__exit__"):
            self._stream.__exit__(*args)

    # -- internals ----------------------------------------------------------

    def _accumulate(self, chunk: Any) -> None:
        try:
            if chunk.choices:
                delta = chunk.choices[0].delta
                if delta and delta.content:
                    self._accumulated.append(delta.content)
            if hasattr(chunk, "usage") and chunk.usage:
                self._usage = {
                    "promptTokens": chunk.usage.prompt_tokens,
                    "completionTokens": chunk.usage.completion_tokens,
                }
        except Exception:
            pass

    def _capture(self) -> None:
        try:
            content = "".join(self._accumulated)
            self._interceptor.after_call(
                self._messages,
                content,
                self._model,
                self._intercept_result,
                self._usage,
            )
        except Exception:
            pass

    # -- passthrough for Stream helper methods (e.g. .response, .close) -----

    def __getattr__(self, name: str) -> Any:
        return getattr(self._stream, name)


# ---------------------------------------------------------------------------
# Async stream wrapper
# ---------------------------------------------------------------------------

class _AsyncStreamWrapper:
    """Wraps an OpenAI async ``AsyncStream`` — async-yields chunks,
    accumulates content, captures on completion.
    """

    def __init__(
        self,
        stream: Any,
        interceptor: Any,
        messages: List[Message],
        intercept_result: Any,
        model: str,
    ) -> None:
        self._stream = stream
        self._interceptor = interceptor
        self._messages = messages
        self._intercept_result = intercept_result
        self._model = model
        self._accumulated: List[str] = []
        self._usage: Optional[Dict[str, int]] = None
        self._aiter: Any = None

    # -- async iteration ----------------------------------------------------

    def __aiter__(self) -> "_AsyncStreamWrapper":
        self._aiter = self._stream.__aiter__()
        return self

    async def __anext__(self) -> Any:
        try:
            chunk = await self._aiter.__anext__()
        except StopAsyncIteration:
            await self._capture()
            raise
        self._accumulate(chunk)
        return chunk

    # -- async context manager (``async with ... as s``) --------------------

    async def __aenter__(self) -> "_AsyncStreamWrapper":
        if hasattr(self._stream, "__aenter__"):
            await self._stream.__aenter__()
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self._capture()
        if hasattr(self._stream, "__aexit__"):
            await self._stream.__aexit__(*args)

    # -- internals ----------------------------------------------------------

    def _accumulate(self, chunk: Any) -> None:
        try:
            if chunk.choices:
                delta = chunk.choices[0].delta
                if delta and delta.content:
                    self._accumulated.append(delta.content)
            if hasattr(chunk, "usage") and chunk.usage:
                self._usage = {
                    "promptTokens": chunk.usage.prompt_tokens,
                    "completionTokens": chunk.usage.completion_tokens,
                }
        except Exception:
            pass

    async def _capture(self) -> None:
        try:
            content = "".join(self._accumulated)
            result = self._interceptor.after_call(
                self._messages,
                content,
                self._model,
                self._intercept_result,
                self._usage,
            )
            # after_call may be sync or async depending on interceptor impl
            if asyncio.iscoroutine(result):
                await result
        except Exception:
            pass

    # -- passthrough --------------------------------------------------------

    def __getattr__(self, name: str) -> Any:
        return getattr(self._stream, name)


# ---------------------------------------------------------------------------
# Wrapper factories
# ---------------------------------------------------------------------------

def _make_sync_wrapper(original_create: Any, interceptor: Any) -> Any:
    """Build a synchronous wrapper around ``completions.create``."""

    @functools.wraps(original_create)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        messages = kwargs.get("messages", args[0] if args else [])
        stream = kwargs.get("stream", False)
        model = kwargs.get("model", "unknown")

        # -- pre-call -------------------------------------------------------
        intercept_result = None
        try:
            intercept_result = interceptor.before_call(messages)
            if intercept_result and intercept_result.swapped_content:
                messages = _swap_system_message(messages, intercept_result.swapped_content)
                kwargs["messages"] = messages
        except Exception:
            pass

        # -- call original --------------------------------------------------
        result = original_create(*args, **kwargs)

        # -- post-call ------------------------------------------------------
        if stream:
            return _SyncStreamWrapper(result, interceptor, messages, intercept_result, model)

        try:
            content = _extract_content(result)
            usage = _extract_usage(result)
            actual_model = getattr(result, "model", model)
            interceptor.after_call(messages, content, actual_model, intercept_result, usage)
        except Exception:
            pass

        return result

    return wrapper


def _make_async_wrapper(original_create: Any, interceptor: Any) -> Any:
    """Build an async wrapper around ``completions.create``."""

    @functools.wraps(original_create)
    async def wrapper(*args: Any, **kwargs: Any) -> Any:
        messages = kwargs.get("messages", args[0] if args else [])
        stream = kwargs.get("stream", False)
        model = kwargs.get("model", "unknown")

        # -- pre-call -------------------------------------------------------
        intercept_result = None
        try:
            result = interceptor.before_call(messages)
            if asyncio.iscoroutine(result):
                result = await result
            intercept_result = result
            if intercept_result and intercept_result.swapped_content:
                messages = _swap_system_message(messages, intercept_result.swapped_content)
                kwargs["messages"] = messages
        except Exception:
            pass

        # -- call original --------------------------------------------------
        result = await original_create(*args, **kwargs)

        # -- post-call ------------------------------------------------------
        if stream:
            return _AsyncStreamWrapper(result, interceptor, messages, intercept_result, model)

        try:
            content = _extract_content(result)
            usage = _extract_usage(result)
            actual_model = getattr(result, "model", model)
            after = interceptor.after_call(messages, content, actual_model, intercept_result, usage)
            if asyncio.iscoroutine(after):
                await after
        except Exception:
            pass

        return result

    return wrapper


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def instrument_openai(client: Any, interceptor: Any) -> Any:
    """Patch an OpenAI client instance for Converra interception.

    Works with both ``OpenAI`` (sync) and ``AsyncOpenAI`` (async) clients.
    Only ``client.chat.completions.create()`` is intercepted — all other
    methods and properties pass through unchanged.

    The original ``create`` method is stored on the client for cleanup::

        client._converra_original_create  # the un-patched method

    Args:
        client: An OpenAI or AsyncOpenAI client instance.
        interceptor: A Converra interceptor with ``before_call`` / ``after_call``.

    Returns:
        The same client instance (mutated in-place) with the patched ``create``.
    """
    # Guard: bail if the client doesn't look like an OpenAI client
    try:
        original_create = client.chat.completions.create
        if not callable(original_create):
            return client
    except AttributeError:
        return client

    # Detect async vs sync client
    is_async = asyncio.iscoroutinefunction(original_create)

    if is_async:
        client.chat.completions.create = _make_async_wrapper(original_create, interceptor)
    else:
        client.chat.completions.create = _make_sync_wrapper(original_create, interceptor)

    # Store original for cleanup / uninstrument
    client._converra_original_create = original_create
    return client


def uninstrument_openai(client: Any) -> Any:
    """Restore the original ``create`` method on a previously instrumented client.

    No-op if the client was never instrumented.

    Args:
        client: A previously instrumented OpenAI client.

    Returns:
        The client with the original ``create`` method restored.
    """
    original = getattr(client, "_converra_original_create", None)
    if original is not None:
        client.chat.completions.create = original
        del client._converra_original_create
    return client
