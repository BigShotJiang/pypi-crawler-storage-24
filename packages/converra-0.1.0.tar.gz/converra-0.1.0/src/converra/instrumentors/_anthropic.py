"""
Converra SDK -- Anthropic Instrumentor

Patches an Anthropic client's ``client.messages.create()`` to enable
prompt variant swapping and conversation capture.

Key differences from the OpenAI instrumentor:
- System prompt is a top-level ``system`` parameter, not in the messages array.
- ``system`` can be a string or a list of content blocks.
- Streaming emits ``content_block_delta`` events with ``delta.text``.
- Non-streaming response text lives at ``response.content[0].text``.
- Usage: ``response.usage.input_tokens`` / ``response.usage.output_tokens``.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger("converra")


# ---------------------------------------------------------------------------
# System prompt helpers
# ---------------------------------------------------------------------------


def _extract_system(kwargs: Dict[str, Any]) -> Optional[str]:
    """Extract text from Anthropic's system prompt format.

    Handles both plain string and list-of-content-blocks formats.
    """
    system = kwargs.get("system")
    if isinstance(system, str):
        return system
    if isinstance(system, list):
        text = " ".join(
            b.get("text", "") for b in system if isinstance(b, dict) and b.get("type") == "text"
        )
        return text or None
    return None


def _replace_system(kwargs: Dict[str, Any], new_content: str) -> Dict[str, Any]:
    """Replace system prompt content, preserving the original format.

    String in -> string out.  Array in -> single text block array out.
    """
    kwargs = dict(kwargs)
    system = kwargs.get("system")
    if isinstance(system, str):
        kwargs["system"] = new_content
    elif isinstance(system, list):
        kwargs["system"] = [{"type": "text", "text": new_content}]
    else:
        kwargs["system"] = new_content
    return kwargs


def _build_interceptor_messages(
    system_text: Optional[str], messages: List[Dict[str, Any]]
) -> List[Dict[str, str]]:
    """Build a synthetic messages array for the interceptor.

    Prepends a system-role message so ``before_call`` can match the prompt.
    """
    out: List[Dict[str, str]] = []
    if system_text:
        out.append({"role": "system", "content": system_text})
    for m in messages:
        content = m.get("content", "")
        if not isinstance(content, str):
            import json

            content = json.dumps(content)
        out.append({"role": m.get("role", "user"), "content": content})
    return out


def _extract_response_text(content: Any) -> str:
    """Extract plain text from an Anthropic response content array."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "".join(
            b.text if hasattr(b, "text") else b.get("text", "")
            for b in content
            if (hasattr(b, "type") and b.type == "text")
            or (isinstance(b, dict) and b.get("type") == "text")
        )
    return ""


def _extract_usage(response: Any) -> Optional[Dict[str, int]]:
    """Extract token usage from an Anthropic response."""
    usage = getattr(response, "usage", None)
    if usage is None:
        return None
    return {
        "promptTokens": getattr(usage, "input_tokens", 0),
        "completionTokens": getattr(usage, "output_tokens", 0),
    }


# ---------------------------------------------------------------------------
# Sync / async wrappers
# ---------------------------------------------------------------------------


def _make_sync_wrapper(original_create: Any, interceptor: Any) -> Any:
    """Create a synchronous wrapper around ``messages.create``."""

    def wrapper(*args: Any, **kwargs: Any) -> Any:
        system_text = _extract_system(kwargs)
        raw_messages = kwargs.get("messages", [])
        model = kwargs.get("model", "unknown")
        is_streaming = kwargs.get("stream", False)

        interceptor_messages = _build_interceptor_messages(system_text, raw_messages)

        # Pre-call: match prompt and resolve variant
        intercept_result = None
        try:
            intercept_result = interceptor.before_call(interceptor_messages)
            if intercept_result and getattr(intercept_result, "swapped_content", None):
                kwargs = _replace_system(kwargs, intercept_result.swapped_content)
        except Exception:
            logger.debug("Converra before_call failed", exc_info=True)

        # Call original
        result = original_create(*args, **kwargs)

        # Post-call handling
        if is_streaming:
            return _wrap_sync_stream(result, interceptor, interceptor_messages, model, intercept_result)

        try:
            response_text = _extract_response_text(getattr(result, "content", None))
            usage = _extract_usage(result)
            interceptor.after_call(interceptor_messages, response_text, model, intercept_result, usage)
        except Exception:
            logger.debug("Converra after_call failed", exc_info=True)

        return result

    return wrapper


def _make_async_wrapper(original_create: Any, interceptor: Any) -> Any:
    """Create an asynchronous wrapper around ``messages.create``."""

    async def wrapper(*args: Any, **kwargs: Any) -> Any:
        system_text = _extract_system(kwargs)
        raw_messages = kwargs.get("messages", [])
        model = kwargs.get("model", "unknown")
        is_streaming = kwargs.get("stream", False)

        interceptor_messages = _build_interceptor_messages(system_text, raw_messages)

        # Pre-call: match prompt and resolve variant
        intercept_result = None
        try:
            result = interceptor.before_call(interceptor_messages)
            # Handle both sync and async before_call
            if asyncio.iscoroutine(result):
                intercept_result = await result
            else:
                intercept_result = result
            if intercept_result and getattr(intercept_result, "swapped_content", None):
                kwargs = _replace_system(kwargs, intercept_result.swapped_content)
        except Exception:
            logger.debug("Converra before_call failed", exc_info=True)

        # Call original
        result = await original_create(*args, **kwargs)

        # Post-call handling
        if is_streaming:
            return _wrap_async_stream(result, interceptor, interceptor_messages, model, intercept_result)

        try:
            response_text = _extract_response_text(getattr(result, "content", None))
            usage = _extract_usage(result)
            interceptor.after_call(interceptor_messages, response_text, model, intercept_result, usage)
        except Exception:
            logger.debug("Converra after_call failed", exc_info=True)

        return result

    return wrapper


# ---------------------------------------------------------------------------
# Stream wrappers
# ---------------------------------------------------------------------------


def _wrap_sync_stream(stream: Any, interceptor: Any, messages: list, model: str, intercept_result: Any) -> Any:
    """Wrap a synchronous Anthropic stream, accumulating text for after_call."""
    accumulated = []

    class _WrappedStream:
        def __init__(self, inner: Any) -> None:
            self._inner = inner

        def __iter__(self):
            return self

        def __next__(self):
            try:
                event = next(self._inner)
            except StopIteration:
                self._flush()
                raise
            self._accumulate(event)
            return event

        def __enter__(self):
            if hasattr(self._inner, "__enter__"):
                self._inner.__enter__()
            return self

        def __exit__(self, *exc_info):
            self._flush()
            if hasattr(self._inner, "__exit__"):
                return self._inner.__exit__(*exc_info)
            return False

        def __getattr__(self, name: str) -> Any:
            return getattr(self._inner, name)

        def _accumulate(self, event: Any) -> None:
            if (
                getattr(event, "type", None) == "content_block_delta"
                and hasattr(event, "delta")
                and getattr(event.delta, "type", None) == "text_delta"
                and hasattr(event.delta, "text")
            ):
                accumulated.append(event.delta.text)

        def _flush(self) -> None:
            if accumulated:
                try:
                    interceptor.after_call(
                        messages, "".join(accumulated), model, intercept_result
                    )
                except Exception:
                    logger.debug("Converra stream after_call failed", exc_info=True)

    return _WrappedStream(stream)


def _wrap_async_stream(stream: Any, interceptor: Any, messages: list, model: str, intercept_result: Any) -> Any:
    """Wrap an asynchronous Anthropic stream, accumulating text for after_call."""
    accumulated = []

    class _WrappedAsyncStream:
        def __init__(self, inner: Any) -> None:
            self._inner = inner

        def __aiter__(self):
            return self

        async def __anext__(self):
            try:
                event = await self._inner.__anext__()
            except StopAsyncIteration:
                self._flush()
                raise
            self._accumulate(event)
            return event

        async def __aenter__(self):
            if hasattr(self._inner, "__aenter__"):
                await self._inner.__aenter__()
            return self

        async def __aexit__(self, *exc_info):
            self._flush()
            if hasattr(self._inner, "__aexit__"):
                return await self._inner.__aexit__(*exc_info)
            return False

        def __getattr__(self, name: str) -> Any:
            return getattr(self._inner, name)

        def _accumulate(self, event: Any) -> None:
            if (
                getattr(event, "type", None) == "content_block_delta"
                and hasattr(event, "delta")
                and getattr(event.delta, "type", None) == "text_delta"
                and hasattr(event.delta, "text")
            ):
                accumulated.append(event.delta.text)

        def _flush(self) -> None:
            if accumulated:
                try:
                    interceptor.after_call(
                        messages, "".join(accumulated), model, intercept_result
                    )
                except Exception:
                    logger.debug("Converra stream after_call failed", exc_info=True)

    return _WrappedAsyncStream(stream)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def instrument_anthropic(client: Any, interceptor: Any) -> Any:
    """Patch an Anthropic client instance for Converra interception.

    Intercepts ``client.messages.create()`` to:

    1. Match the system prompt against Converra-managed prompts
    2. Swap in an active optimization variant (if any)
    3. Capture the conversation for performance analysis

    All other client methods and properties pass through unchanged.

    Args:
        client: An Anthropic client instance (``anthropic.Anthropic``
                or ``anthropic.AsyncAnthropic``).
        interceptor: A Converra interceptor with ``before_call`` / ``after_call``.

    Returns:
        The same client instance with ``messages.create`` patched in-place.
    """
    original_create = client.messages.create
    is_async = asyncio.iscoroutinefunction(original_create)

    if is_async:
        client.messages.create = _make_async_wrapper(original_create, interceptor)
    else:
        client.messages.create = _make_sync_wrapper(original_create, interceptor)

    # Stash original for potential restoration
    client._converra_original_create = original_create
    return client
