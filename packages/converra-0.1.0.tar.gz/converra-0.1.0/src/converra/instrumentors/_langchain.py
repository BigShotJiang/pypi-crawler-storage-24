"""
Converra SDK -- LangChain Callback Handler

Duck-typed LangChain callback handler that captures LLM calls for
Converra conversation tracking. Does NOT subclass ``BaseCallbackHandler``
to avoid requiring ``langchain-core`` as a dependency.

Usage::

    from converra.instrumentors._langchain import ConverraCallbackHandler

    handler = ConverraCallbackHandler(interceptor)
    llm = ChatOpenAI(callbacks=[handler])
"""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional

logger = logging.getLogger("converra")


class ConverraCallbackHandler:
    """LangChain callback handler for Converra conversation capture.

    Implements the same interface as ``BaseCallbackHandler`` via duck typing,
    so it works with ``callbacks=[handler]`` without pulling in langchain-core.
    """

    def __init__(self, interceptor: Any) -> None:
        self._interceptor = interceptor
        self._active_runs: Dict[str, Dict[str, Any]] = {}

    # ------------------------------------------------------------------
    # LLM lifecycle callbacks
    # ------------------------------------------------------------------

    def on_llm_start(
        self,
        serialized: Dict[str, Any],
        prompts: Optional[List[str]] = None,
        *,
        run_id: Optional[Any] = None,
        parent_run_id: Optional[Any] = None,
        messages: Optional[List[List[Any]]] = None,
        **kwargs: Any,
    ) -> None:
        """Called when an LLM starts generating.

        LangChain passes either ``prompts`` (list of strings for completion
        models) or ``messages`` (list of message lists for chat models).
        """
        try:
            formatted: List[Dict[str, str]] = []

            if messages and len(messages) > 0:
                # Chat model path -- messages is a list of message lists
                msg_list = messages[0] if messages else []
                for msg in msg_list:
                    role = getattr(msg, "type", "user")
                    if role == "human":
                        role = "user"
                    elif role == "ai":
                        role = "assistant"
                    content = getattr(msg, "content", str(msg))
                    if not isinstance(content, str):
                        import json

                        content = json.dumps(content)
                    formatted.append({"role": role, "content": content})
            elif prompts:
                # Completion model path -- plain strings
                for prompt_text in prompts:
                    formatted.append({"role": "user", "content": prompt_text})

            if not formatted:
                return

            intercept_result = self._interceptor.before_call(formatted)

            model = "unknown"
            invocation_params = kwargs.get("invocation_params") or {}
            model = (
                invocation_params.get("model_name")
                or invocation_params.get("model")
                or "unknown"
            )

            self._active_runs[str(run_id)] = {
                "messages": formatted,
                "intercept_result": intercept_result,
                "model": model,
            }
        except Exception:
            logger.debug("Converra on_llm_start failed", exc_info=True)

    def on_llm_end(
        self,
        response: Any,
        *,
        run_id: Optional[Any] = None,
        **kwargs: Any,
    ) -> None:
        """Called when an LLM finishes generating."""
        try:
            run_data = self._active_runs.pop(str(run_id), None)
            if not run_data:
                return

            # Extract response text from LangChain's LLMResult
            text = _extract_generation_text(response)

            # Extract token usage if available
            usage = _extract_token_usage(response)

            self._interceptor.after_call(
                run_data["messages"],
                text,
                run_data["model"],
                run_data["intercept_result"],
                usage,
            )
        except Exception:
            logger.debug("Converra on_llm_end failed", exc_info=True)

    def on_llm_error(
        self,
        error: BaseException,
        *,
        run_id: Optional[Any] = None,
        **kwargs: Any,
    ) -> None:
        """Called when an LLM errors -- clean up tracked state."""
        self._active_runs.pop(str(run_id), None)

    # ------------------------------------------------------------------
    # No-op stubs for other callbacks LangChain may invoke
    # ------------------------------------------------------------------

    def on_chain_start(self, *args: Any, **kwargs: Any) -> None:
        pass

    def on_chain_end(self, *args: Any, **kwargs: Any) -> None:
        pass

    def on_chain_error(self, *args: Any, **kwargs: Any) -> None:
        pass

    def on_tool_start(self, *args: Any, **kwargs: Any) -> None:
        pass

    def on_tool_end(self, *args: Any, **kwargs: Any) -> None:
        pass

    def on_tool_error(self, *args: Any, **kwargs: Any) -> None:
        pass

    def on_text(self, *args: Any, **kwargs: Any) -> None:
        pass

    def on_llm_new_token(self, *args: Any, **kwargs: Any) -> None:
        pass


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _extract_generation_text(response: Any) -> str:
    """Extract the first generation's text from a LangChain ``LLMResult``."""
    if not hasattr(response, "generations") or not response.generations:
        return ""
    first_gen_list = response.generations[0]
    if not first_gen_list:
        return ""
    gen = first_gen_list[0]

    # ChatGeneration has a .message attribute with .content
    if hasattr(gen, "message") and hasattr(gen.message, "content"):
        content = gen.message.content
        if isinstance(content, str) and content:
            return content

    # Regular Generation has .text
    text = getattr(gen, "text", "")
    if isinstance(text, str):
        return text

    return ""


def _extract_token_usage(response: Any) -> Optional[Dict[str, int]]:
    """Extract token usage from a LangChain ``LLMResult.llm_output``."""
    llm_output = getattr(response, "llm_output", None)
    if not llm_output or not isinstance(llm_output, dict):
        return None
    token_usage = llm_output.get("token_usage") or llm_output.get("usage")
    if not token_usage or not isinstance(token_usage, dict):
        return None
    prompt_tokens = token_usage.get("prompt_tokens", 0)
    completion_tokens = token_usage.get("completion_tokens", 0)
    if not prompt_tokens and not completion_tokens:
        return None
    return {
        "promptTokens": prompt_tokens,
        "completionTokens": completion_tokens,
    }
