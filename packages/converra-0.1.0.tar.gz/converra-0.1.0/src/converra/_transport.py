"""
Converra SDK Transport

Non-blocking batched transport for pushing trace data to Converra.
Uses a daemon thread with a queue. Registers an atexit handler to flush
remaining payloads on shutdown. Never throws or blocks the caller.
"""

from __future__ import annotations

import atexit
import logging
import queue
import threading
from typing import Any, Dict, List

import httpx

logger = logging.getLogger("converra")

_SENTINEL = object()  # Signals the worker thread to stop


class Transport:
    """Batched, fire-and-forget HTTP transport for conversation payloads."""

    def __init__(
        self,
        base_url: str,
        api_key: str,
        batch_size: int = 10,
        flush_interval: float = 30.0,
    ) -> None:
        self._base_url = base_url
        self._api_key = api_key
        self._batch_size = batch_size
        self._flush_interval = flush_interval
        self._queue: queue.Queue[Any] = queue.Queue()
        self._stopped = False

        self._thread = threading.Thread(target=self._worker, daemon=True)
        self._thread.start()
        atexit.register(self.shutdown)

    def enqueue(self, payload: Dict[str, Any]) -> None:
        """Add a payload to the send queue. Never blocks or throws."""
        if self._stopped:
            return
        try:
            self._queue.put_nowait(payload)
        except Exception:
            pass

    def shutdown(self) -> None:
        """Flush remaining payloads and stop the worker thread."""
        if self._stopped:
            return
        self._stopped = True
        self._queue.put(_SENTINEL)
        self._thread.join(timeout=5.0)

    def _worker(self) -> None:
        """Background loop: drain queue into batches and send them."""
        batch: List[Dict[str, Any]] = []

        while True:
            try:
                # Wait up to flush_interval for the next item
                item = self._queue.get(timeout=self._flush_interval)
                if item is _SENTINEL:
                    # Drain anything left in the queue before exiting
                    while not self._queue.empty():
                        remaining = self._queue.get_nowait()
                        if remaining is not _SENTINEL:
                            batch.append(remaining)
                    if batch:
                        self._send(batch)
                    return
                batch.append(item)
            except queue.Empty:
                # Timeout — flush whatever we have
                pass

            if len(batch) >= self._batch_size or (
                batch and self._queue.empty()
            ):
                self._send(batch)
                batch = []

    def _send(self, batch: List[Dict[str, Any]]) -> None:
        """Send a batch of payloads. Failures are silently swallowed."""
        for item in batch:
            try:
                httpx.post(
                    f"{self._base_url}/conversations",
                    json=item,
                    headers={
                        "Authorization": f"Bearer {self._api_key}",
                        "Content-Type": "application/json",
                    },
                    timeout=10.0,
                )
            except Exception:
                logger.debug("Transport send failed", exc_info=True)
