"""NeuralFlow SDK — Research-grade EMG+IMU wearable sensor platform."""

from setuptools import setup, find_packages
import os

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="Biokinesis_sdk",
    version="1.0.0",
    description="Research-grade Python SDK for combined EMG+IMU wearable sensors",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Biokinesis",
    python_requires=">=3.9",
    packages=find_packages(),
    install_requires=[
        "numpy>=1.23",
        "h5py>=3.7",
        "scipy>=1.9",
        "pylsl>=1.16",
    ],
    extras_require={
        "dev": ["pytest>=7.0"],
    },
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Science/Research",
        "Topic :: Scientific/Engineering :: Medical Science Apps.",
        "Programming Language :: Python :: 3",
    ],
)
