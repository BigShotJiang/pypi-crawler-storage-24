# NeuralFlow SDK

**Research-grade Python SDK for combined EMG+IMU wearable sensors.**

Competes directly with Delsys Trigno — matches or exceeds: 2000 Hz EMG, 9-axis IMU at 148 Hz, 16-bit resolution, configurable bandwidth, bipolar differential EMG, LSL output, multi-format export, up to 16 sensors with hardware sync.

## Installation

```bash
pip install -e .
```

## Quick Start

```python
from neuralflow.core.types import SensorConfig, FilterConfig, EMGFrame, IMUFrame
from neuralflow.orchestrator import Orchestrator
from neuralflow.export import ExportManager
import numpy as np

# Set up orchestrator with 2 sensors
orch = Orchestrator()
orch.add_sensor(SensorConfig(sensor_id=1, label="Biceps",
                             filter_config=FilterConfig.standard()))
orch.add_sensor(SensorConfig(sensor_id=2, label="Triceps",
                             filter_config=FilterConfig.standard()))

# Ingest EMG data
emg_data = np.random.randn(4000) * 500  # 2 seconds at 2 kHz, µV
timestamps = np.arange(4000) * 500.0     # µs timestamps
frame = EMGFrame(sensor_id=1, timestamps_us=timestamps,
                 data=emg_data, sample_rate=2000.0)
orch.ingest_emg(1, frame)

# Export all formats
data = orch.collect_all_data()
ExportManager.export_all(data, "./output", formats=["csv", "hdf5", "mat"])
```

## Modules

| Module | Description |
|--------|-------------|
| `neuralflow.emg.filters` | Butterworth bandpass (20–450 / 10–850 Hz), 50/60 Hz notch filter |
| `neuralflow.emg.features` | RMS, MAV, ZCR, iEMG, median/mean frequency, waveform length |
| `neuralflow.emg.analysis` | Muscle onset detection, MVC normalization, co-contraction index |
| `neuralflow.imu.preprocessing` | Raw unit conversion, calibration, gyro bias estimation |
| `neuralflow.imu.fusion` | Quaternion algebra, Madgwick AHRS (6-DOF / 9-DOF) |
| `neuralflow.imu.kinematics` | Euler angles, gravity compensation, joint angle estimation |
| `neuralflow.orchestrator` | 16-sensor manager, µs sync, hardware triggers |
| `neuralflow.export` | CSV, HDF5, LSL, MATLAB .mat |
| `neuralflow.pipelines` | Gait analysis, fatigue monitoring, prosthetics control |

## Running Tests

```bash
pip install -e ".[dev]"
python -m pytest tests/ -v
```

## License

MIT
