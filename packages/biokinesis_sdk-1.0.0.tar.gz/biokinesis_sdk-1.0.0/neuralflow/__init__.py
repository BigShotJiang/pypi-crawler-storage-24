"""
NeuralFlow SDK — Research-grade Python SDK for combined EMG+IMU wearable sensors.

Modules:
    emg         EMG signal chain (filters, features, analysis)
    imu         IMU processing chain (fusion, kinematics)
    orchestrator Multi-sensor management and synchronization
    export      CSV / HDF5 / LSL / MATLAB export
    pipelines   Pre-built clinical pipelines
"""

__version__ = "1.0.0"
__all__ = ["core", "emg", "imu", "orchestrator", "export", "pipelines"]
