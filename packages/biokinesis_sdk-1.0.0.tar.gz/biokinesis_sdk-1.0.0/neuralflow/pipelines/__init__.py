"""Pre-built clinical pipelines."""
from .clinical import GaitAnalysisPipeline, FatigueMonitoringPipeline, ProstheticsControlPipeline

__all__ = ["GaitAnalysisPipeline", "FatigueMonitoringPipeline", "ProstheticsControlPipeline"]
