"""
NeuralFlow SDK — Pre-built clinical pipelines.

  1. GaitAnalysisPipeline   — heel-strike / toe-off detection, stride analysis
  2. FatigueMonitoringPipeline — median frequency tracking, fatigue index
  3. ProstheticsControlPipeline — multi-channel feature extraction for control
"""

from __future__ import annotations

import math
from typing import Any, Dict, List, Optional, Tuple

import numpy as np

from ..core.types import PipelineResult, EMGFrame, IMUFrame
from ..emg.features import (
    rms_envelope, mean_absolute_value, zero_crossing_rate,
    integrated_emg, median_frequency, mean_frequency, waveform_length,
)
from ..emg.analysis import detect_muscle_onset, mvc_normalize
from ..imu.fusion import Quaternion, MadgwickAHRS
from ..imu.kinematics import quaternion_to_euler


# ===================================================================
# 1. Gait Analysis Pipeline
# ===================================================================

class GaitAnalysisPipeline:
    """Gait analysis from IMU data mounted on the shank or foot.

    Detects gait events (heel-strike, toe-off) from vertical acceleration
    peaks, then computes temporal gait parameters.

    Parameters
    ----------
    sample_rate : IMU sampling rate (Hz).
    accel_axis : Which accelerometer axis is vertical (0=X, 1=Y, 2=Z).
    heel_strike_threshold : Acceleration peak threshold for heel-strike (m/s²).
    min_stride_time_s : Minimum time between successive heel-strikes (s).
    """

    def __init__(self, sample_rate: float = 148.0, accel_axis: int = 2,
                 heel_strike_threshold: float = 15.0,
                 min_stride_time_s: float = 0.4):
        self.sample_rate = sample_rate
        self.accel_axis = accel_axis
        self.hs_threshold = heel_strike_threshold
        self.min_stride_samples = int(min_stride_time_s * sample_rate)

    def analyze(self, accel: np.ndarray,
                timestamps_us: Optional[np.ndarray] = None) -> PipelineResult:
        """Run gait analysis.

        Parameters
        ----------
        accel : (N, 3) accelerometer data in m/s².
        timestamps_us : (N,) microsecond timestamps.

        Returns
        -------
        PipelineResult with metrics and events.
        """
        accel = np.asarray(accel, dtype=np.float64)
        N = len(accel)
        if timestamps_us is None:
            timestamps_us = np.arange(N) * (1e6 / self.sample_rate)

        vert = accel[:, self.accel_axis]

        # ------- Heel-strike detection (positive peaks in vertical accel) --------
        heel_strikes = self._detect_peaks(vert, self.hs_threshold,
                                          self.min_stride_samples)

        # ------- Toe-off detection (negative peaks between heel-strikes) ---------
        toe_offs = self._detect_toe_offs(vert, heel_strikes)

        # ------- Stride parameters -------
        stride_times = []
        for i in range(1, len(heel_strikes)):
            dt = (timestamps_us[heel_strikes[i]] -
                  timestamps_us[heel_strikes[i - 1]]) / 1e6
            stride_times.append(dt)

        stride_times = np.array(stride_times) if stride_times else np.array([])

        # Cadence (steps/min)
        cadence = 0.0
        if len(stride_times) > 0 and np.mean(stride_times) > 0:
            cadence = 60.0 / np.mean(stride_times)

        # Stance / swing phase fractions
        stance_fracs, swing_fracs = self._compute_phases(
            heel_strikes, toe_offs, timestamps_us)

        # Gait asymmetry index
        asymmetry = 0.0
        if len(stride_times) >= 2:
            even_strides = stride_times[0::2]
            odd_strides = stride_times[1::2]
            min_len = min(len(even_strides), len(odd_strides))
            if min_len > 0:
                mean_e = np.mean(even_strides[:min_len])
                mean_o = np.mean(odd_strides[:min_len])
                asymmetry = abs(mean_e - mean_o) / ((mean_e + mean_o) / 2) * 100

        # ------- Build result -------
        events = []
        for idx in heel_strikes:
            events.append({
                "type": "heel_strike",
                "sample": int(idx),
                "timestamp_us": float(timestamps_us[idx]),
            })
        for idx in toe_offs:
            events.append({
                "type": "toe_off",
                "sample": int(idx),
                "timestamp_us": float(timestamps_us[idx]),
            })
        events.sort(key=lambda e: e["timestamp_us"])

        return PipelineResult(
            name="gait_analysis",
            metrics={
                "n_strides": len(stride_times),
                "mean_stride_time_s": float(np.mean(stride_times)) if len(stride_times) else 0.0,
                "std_stride_time_s": float(np.std(stride_times)) if len(stride_times) else 0.0,
                "cadence_steps_per_min": cadence,
                "asymmetry_index_pct": asymmetry,
                "mean_stance_fraction": float(np.mean(stance_fracs)) if len(stance_fracs) else 0.0,
                "mean_swing_fraction": float(np.mean(swing_fracs)) if len(swing_fracs) else 0.0,
            },
            time_series={
                "stride_times_s": stride_times,
                "vertical_accel": vert,
            },
            events=events,
        )

    # ---------- internal helpers -------------------------------------
    def _detect_peaks(self, signal: np.ndarray, threshold: float,
                      min_distance: int) -> List[int]:
        """Simple peak detection: find local maxima above threshold."""
        peaks = []
        for i in range(1, len(signal) - 1):
            if (signal[i] > signal[i - 1] and signal[i] > signal[i + 1]
                    and signal[i] > threshold):
                if not peaks or (i - peaks[-1]) >= min_distance:
                    peaks.append(i)
        return peaks

    def _detect_toe_offs(self, vert: np.ndarray,
                         heel_strikes: List[int]) -> List[int]:
        """Detect toe-off as the minimum (negative peak) between successive
        heel-strikes."""
        toe_offs = []
        for i in range(len(heel_strikes) - 1):
            start = heel_strikes[i]
            end = heel_strikes[i + 1]
            seg = vert[start:end]
            if len(seg) > 0:
                min_idx = start + int(np.argmin(seg))
                toe_offs.append(min_idx)
        return toe_offs

    def _compute_phases(self, heel_strikes: List[int],
                        toe_offs: List[int],
                        timestamps_us: np.ndarray
                        ) -> Tuple[List[float], List[float]]:
        """Compute stance and swing phase fractions."""
        stance_fracs: List[float] = []
        swing_fracs: List[float] = []

        for i in range(min(len(heel_strikes) - 1, len(toe_offs))):
            hs = heel_strikes[i]
            to = toe_offs[i]
            next_hs = heel_strikes[i + 1]

            stride_dur = timestamps_us[next_hs] - timestamps_us[hs]
            if stride_dur <= 0:
                continue
            stance_dur = timestamps_us[to] - timestamps_us[hs]
            swing_dur = timestamps_us[next_hs] - timestamps_us[to]

            stance_fracs.append(stance_dur / stride_dur)
            swing_fracs.append(swing_dur / stride_dur)

        return stance_fracs, swing_fracs


# ===================================================================
# 2. Fatigue Monitoring Pipeline
# ===================================================================

class FatigueMonitoringPipeline:
    """Real-time fatigue monitoring from surface EMG.

    Tracks the decline in median frequency and the rise in RMS amplitude
    over time as indicators of neuromuscular fatigue.

    Parameters
    ----------
    sample_rate : EMG sampling rate (Hz).
    window_s : Analysis window length (seconds).
    overlap_frac : Window overlap fraction (0–1).
    fatigue_threshold_pct : Percent decline in MDF to flag fatigue.
    """

    def __init__(self, sample_rate: float = 2000.0,
                 window_s: float = 1.0, overlap_frac: float = 0.5,
                 fatigue_threshold_pct: float = 15.0):
        self.sample_rate = sample_rate
        self.window_s = window_s
        self.overlap_frac = overlap_frac
        self.fatigue_threshold_pct = fatigue_threshold_pct

    def analyze(self, signal: np.ndarray) -> PipelineResult:
        """Run fatigue analysis on an EMG signal.

        Parameters
        ----------
        signal : 1-D filtered EMG array.

        Returns
        -------
        PipelineResult with fatigue metrics and time-series.
        """
        signal = np.asarray(signal, dtype=np.float64)
        win_samples = int(self.window_s * self.sample_rate)
        step = max(1, int(win_samples * (1.0 - self.overlap_frac)))
        N = len(signal)

        mdf_series = []
        mnf_series = []
        rms_series = []
        time_s_series = []

        i = 0
        while i + win_samples <= N:
            seg = signal[i:i + win_samples]
            mdf_series.append(median_frequency(seg, self.sample_rate))
            mnf_series.append(mean_frequency(seg, self.sample_rate))
            rms_val = math.sqrt(float(np.mean(seg * seg)))
            rms_series.append(rms_val)
            time_s_series.append((i + win_samples / 2) / self.sample_rate)
            i += step

        mdf_arr = np.array(mdf_series)
        mnf_arr = np.array(mnf_series)
        rms_arr = np.array(rms_series)
        time_arr = np.array(time_s_series)

        # Fatigue index: linear regression slope of MDF over time
        fatigue_index = 0.0
        mdf_initial = mdf_arr[0] if len(mdf_arr) > 0 else 0.0
        mdf_final = mdf_arr[-1] if len(mdf_arr) > 0 else 0.0

        if len(time_arr) >= 2 and mdf_initial > 0:
            # Compute linear regression slope (least-squares)
            t_mean = np.mean(time_arr)
            mdf_mean = np.mean(mdf_arr)
            numerator = np.sum((time_arr - t_mean) * (mdf_arr - mdf_mean))
            denominator = np.sum((time_arr - t_mean) ** 2)
            if abs(denominator) > 1e-12:
                slope = numerator / denominator
                fatigue_index = slope  # Hz/s (negative = fatigue)

        # Detect fatigue onset (when MDF drops below threshold % of initial)
        fatigue_onset_s = None
        if mdf_initial > 0:
            threshold_hz = mdf_initial * (1.0 - self.fatigue_threshold_pct / 100.0)
            for j, mdf in enumerate(mdf_arr):
                if mdf < threshold_hz:
                    fatigue_onset_s = time_arr[j]
                    break

        # RMS trend slope (positive slope = fatigue)
        rms_slope = 0.0
        if len(time_arr) >= 2:
            t_mean = np.mean(time_arr)
            rms_mean = np.mean(rms_arr)
            num = np.sum((time_arr - t_mean) * (rms_arr - rms_mean))
            den = np.sum((time_arr - t_mean) ** 2)
            if abs(den) > 1e-12:
                rms_slope = num / den

        mdf_decline_pct = 0.0
        if mdf_initial > 0:
            mdf_decline_pct = (mdf_initial - mdf_final) / mdf_initial * 100.0

        events = []
        if fatigue_onset_s is not None:
            events.append({
                "type": "fatigue_onset",
                "time_s": fatigue_onset_s,
                "mdf_threshold_hz": mdf_initial * (1.0 - self.fatigue_threshold_pct / 100.0),
            })

        return PipelineResult(
            name="fatigue_monitoring",
            metrics={
                "mdf_initial_hz": float(mdf_initial),
                "mdf_final_hz": float(mdf_final),
                "mdf_decline_pct": float(mdf_decline_pct),
                "fatigue_index_hz_per_s": float(fatigue_index),
                "rms_slope": float(rms_slope),
                "fatigue_onset_time_s": fatigue_onset_s,
                "is_fatigued": mdf_decline_pct >= self.fatigue_threshold_pct,
            },
            time_series={
                "time_s": time_arr,
                "median_frequency_hz": mdf_arr,
                "mean_frequency_hz": mnf_arr,
                "rms_amplitude": rms_arr,
            },
            events=events,
        )


# ===================================================================
# 3. Prosthetics Control Pipeline
# ===================================================================

class ProstheticsControlPipeline:
    """Multi-channel EMG feature extraction for prosthetics control.

    Extracts a feature vector from multiple EMG channels suitable for
    real-time grasp/gesture classification.

    Feature vector per window (per channel):
        [RMS, MAV, ZCR, waveform_length]

    Parameters
    ----------
    sample_rate : EMG sampling rate (Hz).
    window_ms : Feature extraction window (ms).
    overlap_ms : Window overlap (ms).
    n_channels : Number of EMG channels.
    mvc_values : Optional per-channel MVC values for normalisation.
    """

    def __init__(self, sample_rate: float = 2000.0,
                 window_ms: float = 200.0, overlap_ms: float = 100.0,
                 n_channels: int = 4,
                 mvc_values: Optional[List[float]] = None):
        self.sample_rate = sample_rate
        self.window_samples = int(window_ms / 1000.0 * sample_rate)
        self.overlap_samples = int(overlap_ms / 1000.0 * sample_rate)
        self.step = self.window_samples - self.overlap_samples
        self.n_channels = n_channels
        self.mvc_values = mvc_values

    def extract_features(self, channels: List[np.ndarray]
                         ) -> PipelineResult:
        """Extract feature vectors from multi-channel EMG data.

        Parameters
        ----------
        channels : List of 1-D EMG arrays (one per channel). All must
                   have the same length.

        Returns
        -------
        PipelineResult with feature matrix and metadata.
        """
        if len(channels) != self.n_channels:
            raise ValueError(
                f"Expected {self.n_channels} channels, got {len(channels)}")

        n_samples = len(channels[0])
        n_windows = max(1, (n_samples - self.window_samples) // self.step + 1)

        # 4 features per channel
        n_features = self.n_channels * 4
        feature_matrix = np.empty((n_windows, n_features), dtype=np.float64)

        for w in range(n_windows):
            start = w * self.step
            end = start + self.window_samples
            feat_vec = []

            for ch_idx, ch in enumerate(channels):
                seg = np.asarray(ch[start:end], dtype=np.float64)

                # Optionally MVC-normalise
                if self.mvc_values is not None:
                    seg = seg / self.mvc_values[ch_idx] * 100.0

                # RMS
                rms = math.sqrt(float(np.mean(seg * seg)))
                # MAV
                mav = float(np.mean(np.abs(seg)))
                # ZCR
                crossings = 0
                for i in range(1, len(seg)):
                    if (seg[i] > 0 and seg[i - 1] < 0) or \
                       (seg[i] < 0 and seg[i - 1] > 0):
                        crossings += 1
                zcr = crossings / len(seg)
                # Waveform length
                wl = float(np.sum(np.abs(np.diff(seg))))

                feat_vec.extend([rms, mav, zcr, wl])

            feature_matrix[w] = feat_vec

        # Feature names
        feature_names = []
        for ch in range(self.n_channels):
            for fname in ["rms", "mav", "zcr", "wl"]:
                feature_names.append(f"ch{ch}_{fname}")

        return PipelineResult(
            name="prosthetics_control",
            metrics={
                "n_windows": n_windows,
                "n_features": n_features,
                "window_ms": self.window_samples / self.sample_rate * 1000,
                "overlap_ms": self.overlap_samples / self.sample_rate * 1000,
            },
            time_series={
                "feature_matrix": feature_matrix,
            },
            metadata={
                "feature_names": feature_names,
                "n_channels": self.n_channels,
            },
        )

    def extract_single_window(self, segments: List[np.ndarray]
                              ) -> np.ndarray:
        """Extract features from a single window across all channels.

        Parameters
        ----------
        segments : List of 1-D arrays (one per channel, each of length
                   ``window_samples``).

        Returns
        -------
        feature_vector : 1-D array of length ``n_channels * 4``.
        """
        feat_vec = []
        for ch_idx, seg in enumerate(segments):
            seg = np.asarray(seg, dtype=np.float64)
            if self.mvc_values is not None:
                seg = seg / self.mvc_values[ch_idx] * 100.0

            rms = math.sqrt(float(np.mean(seg * seg)))
            mav = float(np.mean(np.abs(seg)))
            crossings = 0
            for i in range(1, len(seg)):
                if (seg[i] > 0 and seg[i - 1] < 0) or \
                   (seg[i] < 0 and seg[i - 1] > 0):
                    crossings += 1
            zcr = crossings / max(len(seg), 1)
            wl = float(np.sum(np.abs(np.diff(seg))))
            feat_vec.extend([rms, mav, zcr, wl])

        return np.array(feat_vec, dtype=np.float64)
