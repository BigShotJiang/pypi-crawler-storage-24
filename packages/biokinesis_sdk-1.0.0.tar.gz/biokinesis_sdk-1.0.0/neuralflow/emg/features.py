"""
NeuralFlow SDK — EMG feature extraction.

All algorithms implemented from scratch with NumPy — no external DSP library
dependencies.  Each function operates on a 1-D NumPy array of filtered EMG
samples.

Feature set:
  - RMS envelope (windowed)
  - Mean Absolute Value (MAV)
  - Zero-Crossing Rate (ZCR)
  - Integrated EMG (iEMG)
  - Median Frequency
  - Mean Frequency
"""

from __future__ import annotations

import math
from typing import Optional

import numpy as np


# ===================================================================
# Time-domain features
# ===================================================================

def rms_envelope(signal: np.ndarray, window_samples: int = 500,
                 overlap_samples: Optional[int] = None) -> np.ndarray:
    """Compute the Root-Mean-Square envelope of an EMG signal.

    Parameters
    ----------
    signal : 1-D EMG array.
    window_samples : Window length in samples (default 500 = 250 ms @ 2 kHz).
    overlap_samples : Overlap between windows. Default = window_samples // 2.

    Returns
    -------
    rms : 1-D array of RMS values, one per window.
    """
    signal = np.asarray(signal, dtype=np.float64)
    N = len(signal)
    if overlap_samples is None:
        overlap_samples = window_samples // 2
    step = window_samples - overlap_samples
    if step <= 0:
        step = 1
    n_windows = max(1, (N - window_samples) // step + 1)
    rms = np.empty(n_windows, dtype=np.float64)
    for i in range(n_windows):
        start = i * step
        end = start + window_samples
        seg = signal[start:end]
        rms[i] = math.sqrt(np.mean(seg * seg))
    return rms


def mean_absolute_value(signal: np.ndarray,
                        window_samples: Optional[int] = None) -> np.ndarray:
    """Mean Absolute Value (MAV).

    If *window_samples* is ``None``, returns a scalar (full-signal MAV).
    Otherwise returns a windowed MAV array.

    Parameters
    ----------
    signal : 1-D EMG array.
    window_samples : Optional window length in samples.

    Returns
    -------
    mav : scalar or 1-D array.
    """
    signal = np.asarray(signal, dtype=np.float64)
    if window_samples is None:
        return np.array([np.mean(np.abs(signal))])

    N = len(signal)
    step = window_samples // 2 if window_samples > 1 else 1
    n_windows = max(1, (N - window_samples) // step + 1)
    mav = np.empty(n_windows, dtype=np.float64)
    for i in range(n_windows):
        start = i * step
        end = start + window_samples
        mav[i] = np.mean(np.abs(signal[start:end]))
    return mav


def zero_crossing_rate(signal: np.ndarray,
                       window_samples: Optional[int] = None,
                       threshold: float = 0.0) -> np.ndarray:
    """Zero-Crossing Rate (ZCR).

    Counts the number of times the signal crosses the *threshold* within
    each window, normalised by window length.

    Parameters
    ----------
    signal : 1-D EMG array.
    window_samples : Optional window length (full signal if None).
    threshold : Dead-zone threshold — crossings of amplitude below this
                are ignored (reduces noise-induced false crossings).

    Returns
    -------
    zcr : scalar or 1-D array of crossing rates.
    """
    signal = np.asarray(signal, dtype=np.float64)

    def _count_crossings(seg: np.ndarray) -> float:
        count = 0
        for i in range(1, len(seg)):
            if abs(seg[i]) >= threshold and abs(seg[i - 1]) >= threshold:
                if (seg[i] > 0 and seg[i - 1] < 0) or \
                   (seg[i] < 0 and seg[i - 1] > 0):
                    count += 1
        return count / len(seg) if len(seg) > 0 else 0.0

    if window_samples is None:
        return np.array([_count_crossings(signal)])

    N = len(signal)
    step = window_samples // 2 if window_samples > 1 else 1
    n_windows = max(1, (N - window_samples) // step + 1)
    zcr = np.empty(n_windows, dtype=np.float64)
    for i in range(n_windows):
        start = i * step
        end = start + window_samples
        zcr[i] = _count_crossings(signal[start:end])
    return zcr


def integrated_emg(signal: np.ndarray,
                   window_samples: Optional[int] = None) -> np.ndarray:
    """Integrated EMG (iEMG) — sum of absolute values.

    Parameters
    ----------
    signal : 1-D EMG array.
    window_samples : Optional window length.

    Returns
    -------
    iemg : scalar or 1-D array.
    """
    signal = np.asarray(signal, dtype=np.float64)
    if window_samples is None:
        return np.array([np.sum(np.abs(signal))])

    N = len(signal)
    step = window_samples // 2 if window_samples > 1 else 1
    n_windows = max(1, (N - window_samples) // step + 1)
    iemg = np.empty(n_windows, dtype=np.float64)
    for i in range(n_windows):
        start = i * step
        end = start + window_samples
        iemg[i] = np.sum(np.abs(signal[start:end]))
    return iemg


# ===================================================================
# Frequency-domain features
# ===================================================================

def _power_spectral_density(signal: np.ndarray,
                            sample_rate: float) -> tuple:
    """Compute one-sided PSD via FFT (periodogram).

    Returns (freqs, psd) both as 1-D arrays.
    """
    N = len(signal)
    # Apply Hanning window to reduce spectral leakage
    window = np.hanning(N)
    windowed = signal * window

    fft_vals = np.fft.rfft(windowed)
    psd = (np.abs(fft_vals) ** 2) / (sample_rate * np.sum(window ** 2))
    # Double non-DC, non-Nyquist bins for one-sided spectrum
    if N % 2 == 0:
        psd[1:-1] *= 2.0
    else:
        psd[1:] *= 2.0
    freqs = np.fft.rfftfreq(N, d=1.0 / sample_rate)
    return freqs, psd


def median_frequency(signal: np.ndarray,
                     sample_rate: float = 2000.0) -> float:
    """Median frequency (MDF) — the frequency that divides the power spectrum
    into two equal halves.

    Parameters
    ----------
    signal : 1-D EMG array.
    sample_rate : Sampling rate in Hz.

    Returns
    -------
    mdf : Median frequency in Hz.
    """
    signal = np.asarray(signal, dtype=np.float64)
    freqs, psd = _power_spectral_density(signal, sample_rate)
    cumulative = np.cumsum(psd)
    total_power = cumulative[-1]
    if total_power < 1e-30:
        return 0.0
    idx = np.searchsorted(cumulative, total_power / 2.0)
    idx = min(idx, len(freqs) - 1)
    return float(freqs[idx])


def mean_frequency(signal: np.ndarray,
                   sample_rate: float = 2000.0) -> float:
    """Mean frequency (MNF) — the power-weighted average frequency.

    MNF = Σ(f_i · P_i) / Σ(P_i)

    Parameters
    ----------
    signal : 1-D EMG array.
    sample_rate : Sampling rate in Hz.

    Returns
    -------
    mnf : Mean frequency in Hz.
    """
    signal = np.asarray(signal, dtype=np.float64)
    freqs, psd = _power_spectral_density(signal, sample_rate)
    total_power = np.sum(psd)
    if total_power < 1e-30:
        return 0.0
    return float(np.sum(freqs * psd) / total_power)


def waveform_length(signal: np.ndarray,
                    window_samples: Optional[int] = None) -> np.ndarray:
    """Waveform Length (WL) — cumulative sum of absolute differences.

    WL = Σ|x[n] - x[n-1]|

    Parameters
    ----------
    signal : 1-D EMG array.
    window_samples : Optional window length.

    Returns
    -------
    wl : scalar or 1-D array.
    """
    signal = np.asarray(signal, dtype=np.float64)

    def _wl(seg: np.ndarray) -> float:
        return float(np.sum(np.abs(np.diff(seg))))

    if window_samples is None:
        return np.array([_wl(signal)])

    N = len(signal)
    step = window_samples // 2 if window_samples > 1 else 1
    n_windows = max(1, (N - window_samples) // step + 1)
    wl = np.empty(n_windows, dtype=np.float64)
    for i in range(n_windows):
        start = i * step
        end = start + window_samples
        wl[i] = _wl(signal[start:end])
    return wl
