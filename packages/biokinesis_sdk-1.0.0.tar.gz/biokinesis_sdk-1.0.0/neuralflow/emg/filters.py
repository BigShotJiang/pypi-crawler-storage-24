"""
NeuralFlow SDK — EMG digital filters.

Implements Butterworth bandpass and IIR notch filters from scratch using the
bilinear transform.  No scipy.signal dependency for the filter math — only
NumPy is used for the core algorithms.

Signal flow:  raw EMG → Butterworth bandpass → notch filter → clean EMG
"""

from __future__ import annotations

import math
from typing import List, Optional, Tuple

import numpy as np


# ===================================================================
# Low-level helpers
# ===================================================================

def _bilinear_transform_analog_pole(s: complex, fs: float) -> complex:
    """Map an analog pole/zero *s* to the z-plane via the bilinear transform.

    z = (1 + s·T/2) / (1 − s·T/2)   where T = 1/fs
    """
    T = 1.0 / fs
    return (1.0 + s * T / 2.0) / (1.0 - s * T / 2.0)


def _analog_butterworth_poles(order: int) -> List[complex]:
    """Return the *order* poles of a normalised (ωc = 1) analog Butterworth
    low-pass prototype on the left half of the s-plane."""
    poles = []
    for k in range(order):
        theta = math.pi * (2 * k + order + 1) / (2 * order)
        poles.append(complex(math.cos(theta), math.sin(theta)))
    return poles


def _prewarped_frequency(f_hz: float, fs: float) -> float:
    """Pre-warp a digital frequency (Hz) to the analog domain for the
    bilinear transform so that the cutoff maps exactly."""
    return 2.0 * fs * math.tan(math.pi * f_hz / fs)


def _sos_from_zpk(zeros: List[complex], poles: List[complex],
                   gain: float) -> np.ndarray:
    """Convert zeros/poles/gain to second-order sections (SOS) matrix.

    Returns shape (n_sections, 6) where each row is [b0, b1, b2, 1, a1, a2].
    The overall gain is distributed into the first section.
    """
    # Pair complex-conjugate poles/zeros into biquads
    z_remaining = list(zeros)
    p_remaining = list(poles)
    sections: List[np.ndarray] = []

    while len(p_remaining) >= 2:
        # Take a conjugate pair of poles
        p1 = p_remaining.pop(0)
        # Find its conjugate
        best_idx = 0
        best_dist = abs(p_remaining[0] - p1.conjugate())
        for i in range(1, len(p_remaining)):
            d = abs(p_remaining[i] - p1.conjugate())
            if d < best_dist:
                best_dist = d
                best_idx = i
        p2 = p_remaining.pop(best_idx)

        # Denominator: (z - p1)(z - p2) = z² - (p1+p2)z + p1·p2
        a1 = -(p1 + p2).real
        a2 = (p1 * p2).real

        # Take two zeros (or add at z = -1 if we run out)
        if len(z_remaining) >= 2:
            z1 = z_remaining.pop(0)
            # Find conjugate partner
            best_idx = 0
            best_dist = abs(z_remaining[0] - z1.conjugate())
            for i in range(1, len(z_remaining)):
                d = abs(z_remaining[i] - z1.conjugate())
                if d < best_dist:
                    best_dist = d
                    best_idx = i
            z2 = z_remaining.pop(best_idx)
        else:
            z1 = complex(-1, 0)
            z2 = complex(-1, 0)

        b0_s = 1.0
        b1_s = -(z1 + z2).real
        b2_s = (z1 * z2).real

        sections.append(np.array([b0_s, b1_s, b2_s, 1.0, a1, a2]))

    # Handle leftover odd pole
    if p_remaining:
        p1 = p_remaining.pop(0)
        a1 = -p1.real
        if z_remaining:
            z1 = z_remaining.pop(0)
            b0_s = 1.0
            b1_s = -z1.real
        else:
            b0_s = 1.0
            b1_s = 1.0
        sections.append(np.array([b0_s, b1_s, 0.0, 1.0, a1, 0.0]))

    sos = np.array(sections if sections else [[1, 0, 0, 1, 0, 0]],
                   dtype=np.float64)

    # Distribute gain into first section
    sos[0, :3] *= gain
    return sos


# ===================================================================
# SOS filtering (direct-form II transposed)
# ===================================================================

def _sosfilt(sos: np.ndarray, x: np.ndarray) -> np.ndarray:
    """Apply second-order sections filter to signal *x*.

    Uses Direct-Form II Transposed for numerical stability.

    Parameters
    ----------
    sos : ndarray, shape (n_sections, 6)
    x : ndarray, shape (N,)

    Returns
    -------
    y : ndarray, shape (N,)
    """
    y = x.astype(np.float64, copy=True)

    for section in sos:
        b0, b1, b2 = section[0], section[1], section[2]
        a0, a1, a2 = section[3], section[4], section[5]
        # Normalise
        b0 /= a0; b1 /= a0; b2 /= a0
        a1 /= a0; a2 /= a0

        d1 = 0.0
        d2 = 0.0
        out = np.empty_like(y)
        for n in range(len(y)):
            xn = y[n]
            yn = b0 * xn + d1
            d1 = b1 * xn - a1 * yn + d2
            d2 = b2 * xn - a2 * yn
            out[n] = yn
        y = out

    return y


def _sosfiltfilt(sos: np.ndarray, x: np.ndarray) -> np.ndarray:
    """Zero-phase (forward-backward) SOS filter."""
    y = _sosfilt(sos, x)
    y = _sosfilt(sos, y[::-1])[::-1]
    return y


# ===================================================================
# Butterworth bandpass filter
# ===================================================================

class ButterworthBandpass:
    """Butterworth bandpass filter designed from scratch via the bilinear
    transform.

    Parameters
    ----------
    low_cutoff : Low cutoff frequency in Hz.
    high_cutoff : High cutoff frequency in Hz.
    sample_rate : Sampling rate in Hz.
    order : Filter order (per pole-pair; total order = 2 × *order* for
            bandpass because low-pass prototype is frequency-transformed).
    zero_phase : If True, apply forward-backward filtering (zero-phase,
                 doubles the effective order).
    """

    def __init__(self, low_cutoff: float = 20.0, high_cutoff: float = 450.0,
                 sample_rate: float = 2000.0, order: int = 4,
                 zero_phase: bool = True):
        if low_cutoff <= 0 or high_cutoff <= low_cutoff:
            raise ValueError("Need 0 < low_cutoff < high_cutoff")
        if high_cutoff >= sample_rate / 2:
            raise ValueError("high_cutoff must be below Nyquist")

        self.low_cutoff = low_cutoff
        self.high_cutoff = high_cutoff
        self.sample_rate = sample_rate
        self.order = order
        self.zero_phase = zero_phase

        self._sos = self._design()

    # ----- design -------------------------------------------------------
    def _design(self) -> np.ndarray:
        fs = self.sample_rate
        N = self.order

        # Pre-warp cutoff frequencies
        omega_low = _prewarped_frequency(self.low_cutoff, fs)
        omega_high = _prewarped_frequency(self.high_cutoff, fs)
        bw = omega_high - omega_low
        omega_0 = math.sqrt(omega_low * omega_high)

        # Analog low-pass prototype poles (unit circle)
        lp_poles = _analog_butterworth_poles(N)

        # Frequency-transform LP → BP:  s → (s² + ω₀²) / (BW · s)
        # Each LP pole p_k maps to two BP poles via the quadratic:
        #   s² − BW·p_k·s + ω₀² = 0
        bp_poles: List[complex] = []
        bp_zeros: List[complex] = []
        for pk in lp_poles:
            sk = bw * pk  # scaled
            discriminant = sk * sk - 4.0 * omega_0 * omega_0
            sqrt_d = discriminant ** 0.5  # complex sqrt
            bp_poles.append((sk + sqrt_d) / 2.0)
            bp_poles.append((sk - sqrt_d) / 2.0)

        # Bandpass has N zeros at z = 0 → in s-domain, N zeros at s = 0
        # After bilinear transform these become N zeros at z = +1 and N at z = −1
        # (we place them explicitly after the bilinear transform below).

        # Bilinear transform all poles
        z_poles = [_bilinear_transform_analog_pole(p, fs) for p in bp_poles]

        # Zeros: N at z = +1 and N at z = -1 (from s = 0 and s = ∞)
        z_zeros: List[complex] = []
        for _ in range(N):
            z_zeros.append(complex(1, 0))
            z_zeros.append(complex(-1, 0))

        # Compute gain: evaluate H(z) at the centre frequency and normalise
        omega_c_digital = 2.0 * math.pi * math.sqrt(self.low_cutoff * self.high_cutoff) / fs
        ejw = complex(math.cos(omega_c_digital), math.sin(omega_c_digital))

        num = 1.0
        for z0 in z_zeros:
            num *= (ejw - z0)
        den = 1.0
        for zp in z_poles:
            den *= (ejw - zp)

        gain = abs(den / num)

        return _sos_from_zpk(z_zeros, z_poles, gain)

    # ----- apply --------------------------------------------------------
    def __call__(self, signal: np.ndarray) -> np.ndarray:
        """Apply the bandpass filter to *signal*."""
        return self.apply(signal)

    def apply(self, signal: np.ndarray) -> np.ndarray:
        """Filter *signal* (1-D array) and return the filtered result."""
        signal = np.asarray(signal, dtype=np.float64)
        if self.zero_phase:
            return _sosfiltfilt(self._sos, signal)
        return _sosfilt(self._sos, signal)


# ===================================================================
# IIR Notch filter
# ===================================================================

class NotchFilter:
    """Second-order IIR notch (band-reject) filter.

    Implements the standard notch transfer function::

        H(z) = (1 − 2·cos(ω₀)·z⁻¹ + z⁻²) / (1 − 2r·cos(ω₀)·z⁻¹ + r²·z⁻²)

    where  r = 1 − π·BW/fs  and  BW = f₀ / Q.

    Parameters
    ----------
    freq : Centre frequency to reject (Hz).
    sample_rate : Sampling rate (Hz).
    q_factor : Quality factor (higher = narrower notch).
    zero_phase : If True, forward-backward filtering.
    """

    def __init__(self, freq: float = 50.0, sample_rate: float = 2000.0,
                 q_factor: float = 30.0, zero_phase: bool = True):
        self.freq = freq
        self.sample_rate = sample_rate
        self.q_factor = q_factor
        self.zero_phase = zero_phase

        self._sos = self._design()

    def _design(self) -> np.ndarray:
        w0 = 2.0 * math.pi * self.freq / self.sample_rate
        bw = self.freq / self.q_factor
        r = 1.0 - math.pi * bw / self.sample_rate
        r = max(r, 0.0)  # clamp

        cos_w0 = math.cos(w0)

        b0 = 1.0
        b1 = -2.0 * cos_w0
        b2 = 1.0
        a0 = 1.0
        a1 = -2.0 * r * cos_w0
        a2 = r * r

        # Normalise gain at DC
        gain_dc = (b0 + b1 + b2) / (a0 + a1 + a2) if (a0 + a1 + a2) != 0 else 1.0
        if abs(gain_dc) > 1e-12:
            b0 /= gain_dc
            b1 /= gain_dc
            b2 /= gain_dc

        return np.array([[b0, b1, b2, a0, a1, a2]], dtype=np.float64)

    def __call__(self, signal: np.ndarray) -> np.ndarray:
        return self.apply(signal)

    def apply(self, signal: np.ndarray) -> np.ndarray:
        signal = np.asarray(signal, dtype=np.float64)
        if self.zero_phase:
            return _sosfiltfilt(self._sos, signal)
        return _sosfilt(self._sos, signal)


# ===================================================================
# Convenience chain
# ===================================================================

class EMGFilterChain:
    """Full EMG filter chain: Butterworth bandpass → notch filter.

    Parameters
    ----------
    config : A :class:`FilterConfig` or ``None`` for defaults.
    """

    def __init__(self, config=None):
        from ..core.types import FilterConfig as FC
        if config is None:
            config = FC()
        self.config = config

        self.bandpass = ButterworthBandpass(
            low_cutoff=config.bandpass_low,
            high_cutoff=config.bandpass_high,
            sample_rate=config.sample_rate,
            order=config.bandpass_order,
        )
        self.notch: Optional[NotchFilter] = None
        if config.notch_freq is not None:
            self.notch = NotchFilter(
                freq=config.notch_freq,
                sample_rate=config.sample_rate,
                q_factor=config.notch_q,
            )

    def __call__(self, signal: np.ndarray) -> np.ndarray:
        return self.apply(signal)

    def apply(self, signal: np.ndarray) -> np.ndarray:
        """Apply bandpass then notch filter."""
        y = self.bandpass.apply(signal)
        if self.notch is not None:
            y = self.notch.apply(y)
        return y
