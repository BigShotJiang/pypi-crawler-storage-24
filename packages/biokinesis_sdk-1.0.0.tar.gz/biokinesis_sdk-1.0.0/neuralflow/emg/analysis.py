"""
NeuralFlow SDK — EMG analysis: muscle onset detection, MVC normalization,
and co-contraction index.

All algorithms implemented from scratch.
"""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple

import numpy as np

from .features import rms_envelope


# ===================================================================
# Muscle onset detection (double-threshold algorithm)
# ===================================================================

def detect_muscle_onset(
    signal: np.ndarray,
    sample_rate: float = 2000.0,
    baseline_duration_s: float = 0.5,
    threshold_factor: float = 3.0,
    min_onset_duration_s: float = 0.05,
    rms_window_ms: float = 50.0,
) -> List[Dict]:
    """Detect muscle activation onsets using the double-threshold method.

    Algorithm
    ---------
    1. Compute RMS envelope of the signal.
    2. Estimate baseline noise (mean + std of the first *baseline_duration_s*).
    3. Detection threshold = baseline_mean + *threshold_factor* × baseline_std.
    4. Mark onset when RMS exceeds threshold for at least *min_onset_duration_s*.
    5. Mark offset when RMS drops below threshold.

    Parameters
    ----------
    signal : 1-D EMG array (should be filtered first).
    sample_rate : Sampling rate in Hz.
    baseline_duration_s : Duration of quiet baseline at the start (seconds).
    threshold_factor : Multiplier on baseline std for detection threshold.
    min_onset_duration_s : Minimum sustained activation duration to count (s).
    rms_window_ms : RMS window length in milliseconds.

    Returns
    -------
    onsets : List of dicts with keys ``'onset_sample'``, ``'offset_sample'``,
             ``'onset_time_s'``, ``'offset_time_s'``, ``'duration_s'``.
    """
    signal = np.asarray(signal, dtype=np.float64)

    # 1. RMS envelope
    win_samples = max(1, int(rms_window_ms / 1000.0 * sample_rate))
    env = rms_envelope(signal, window_samples=win_samples,
                       overlap_samples=win_samples - 1)

    # 2. Baseline statistics
    baseline_n = max(1, int(baseline_duration_s * sample_rate / 1))
    baseline_n = min(baseline_n, len(env))
    baseline_seg = env[:baseline_n]
    bl_mean = float(np.mean(baseline_seg))
    bl_std = float(np.std(baseline_seg))

    # 3. Threshold
    threshold = bl_mean + threshold_factor * bl_std

    # 4−5. Detect onsets/offsets
    min_duration_samples = int(min_onset_duration_s * sample_rate)
    active = False
    onset_idx = 0
    onsets: List[Dict] = []

    for i, val in enumerate(env):
        if not active:
            if val > threshold:
                onset_idx = i
                active = True
        else:
            if val <= threshold:
                duration = i - onset_idx
                if duration >= min_duration_samples:
                    onsets.append({
                        "onset_sample": onset_idx,
                        "offset_sample": i,
                        "onset_time_s": onset_idx / sample_rate,
                        "offset_time_s": i / sample_rate,
                        "duration_s": duration / sample_rate,
                    })
                active = False

    # Handle signal ending during an active burst
    if active:
        duration = len(env) - onset_idx
        if duration >= min_duration_samples:
            onsets.append({
                "onset_sample": onset_idx,
                "offset_sample": len(env) - 1,
                "onset_time_s": onset_idx / sample_rate,
                "offset_time_s": (len(env) - 1) / sample_rate,
                "duration_s": duration / sample_rate,
            })

    return onsets


# ===================================================================
# MVC normalization
# ===================================================================

def mvc_normalize(
    signal: np.ndarray,
    mvc_value: Optional[float] = None,
    mvc_signal: Optional[np.ndarray] = None,
    sample_rate: float = 2000.0,
    mvc_window_ms: float = 500.0,
) -> np.ndarray:
    """Normalize EMG signal to Maximum Voluntary Contraction (MVC).

    Provide *either* a pre-computed ``mvc_value`` *or* a raw ``mvc_signal``
    from which the peak RMS will be extracted.

    Parameters
    ----------
    signal : 1-D EMG array to normalise (filtered + rectified recommended).
    mvc_value : Known peak MVC amplitude (e.g. peak RMS in µV).
    mvc_signal : Raw MVC trial signal (peak RMS will be extracted from it).
    sample_rate : Sampling rate in Hz.
    mvc_window_ms : RMS window for MVC extraction if using *mvc_signal*.

    Returns
    -------
    normalized : Signal expressed as %MVC (0–100+ range).
    """
    signal = np.asarray(signal, dtype=np.float64)

    if mvc_value is None and mvc_signal is None:
        raise ValueError("Provide either mvc_value or mvc_signal.")

    if mvc_value is None:
        mvc_signal = np.asarray(mvc_signal, dtype=np.float64)
        win = max(1, int(mvc_window_ms / 1000.0 * sample_rate))
        env = rms_envelope(mvc_signal, window_samples=win)
        mvc_value = float(np.max(env))

    if mvc_value <= 0:
        raise ValueError("MVC value must be positive.")

    return (signal / mvc_value) * 100.0


# ===================================================================
# Co-contraction index
# ===================================================================

def co_contraction_index(
    agonist: np.ndarray,
    antagonist: np.ndarray,
    sample_rate: float = 2000.0,
    window_ms: float = 250.0,
    method: str = "rudolph",
) -> np.ndarray:
    """Compute the co-contraction index (CCI) between agonist and
    antagonist muscles.

    Methods
    -------
    **rudolph** (Rudolph et al., 2000):
        CCI = 2 × min(agonist, antagonist) / (agonist + antagonist) × 100

    **winter** (Winter, 2009):
        CCI = 2 × overlap_area / total_area × 100

    Both methods use RMS envelopes for smooth comparison.

    Parameters
    ----------
    agonist : 1-D filtered EMG of the agonist muscle.
    antagonist : 1-D filtered EMG of the antagonist muscle.
    sample_rate : Sampling rate (Hz).
    window_ms : RMS envelope window (ms).
    method : ``'rudolph'`` or ``'winter'``.

    Returns
    -------
    cci : 1-D array of co-contraction index values (0–100%).
    """
    win = max(1, int(window_ms / 1000.0 * sample_rate))
    overlap = win - 1

    env_ag = rms_envelope(np.asarray(agonist, dtype=np.float64),
                          window_samples=win, overlap_samples=overlap)
    env_an = rms_envelope(np.asarray(antagonist, dtype=np.float64),
                          window_samples=win, overlap_samples=overlap)

    # Align lengths
    min_len = min(len(env_ag), len(env_an))
    env_ag = env_ag[:min_len]
    env_an = env_an[:min_len]

    if method == "rudolph":
        total = env_ag + env_an
        overlap = 2.0 * np.minimum(env_ag, env_an)
        cci = np.where(total > 1e-12, overlap / total * 100.0, 0.0)
    elif method == "winter":
        overlap_area = np.minimum(env_ag, env_an)
        total_area = env_ag + env_an
        cci = np.where(total_area > 1e-12,
                       2.0 * overlap_area / total_area * 100.0, 0.0)
    else:
        raise ValueError(f"Unknown method '{method}'. Use 'rudolph' or 'winter'.")

    return cci
