"""EMG signal processing chain."""

from .filters import ButterworthBandpass, NotchFilter, EMGFilterChain
from .features import (
    rms_envelope, mean_absolute_value, zero_crossing_rate,
    integrated_emg, median_frequency, mean_frequency,
)
from .analysis import (
    detect_muscle_onset, mvc_normalize, co_contraction_index,
)

__all__ = [
    "ButterworthBandpass", "NotchFilter", "EMGFilterChain",
    "rms_envelope", "mean_absolute_value", "zero_crossing_rate",
    "integrated_emg", "median_frequency", "mean_frequency",
    "detect_muscle_onset", "mvc_normalize", "co_contraction_index",
]
