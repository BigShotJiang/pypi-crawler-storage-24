"""
NeuralFlow SDK — Multi-sensor orchestrator.

Manages up to 16 simultaneous sensor slots with:
  - Microsecond-aligned timestamps
  - Hardware sync trigger support (rising/falling edge)
  - Per-sensor configurable EMG/IMU processing pipelines
  - Unified data collection and export interface
"""

from __future__ import annotations

import time
from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np

from ..core.constants import (
    MAX_SENSORS, EMG_SAMPLE_RATE, IMU_SAMPLE_RATE, TIMESTAMP_RESOLUTION_US,
)
from ..core.types import (
    EMGFrame, IMUFrame, SensorConfig, FilterConfig, TriggerEvent, TriggerEdge,
)
from ..emg.filters import EMGFilterChain
from ..emg.features import rms_envelope, mean_absolute_value
from ..imu.fusion import MadgwickAHRS, Quaternion
from ..imu.kinematics import quaternions_to_euler_batch, gravity_compensate_batch


# ===================================================================
# Sensor slot
# ===================================================================

class SensorSlot:
    """A single sensor slot with its processing pipeline.

    Parameters
    ----------
    config : Sensor configuration.
    """

    def __init__(self, config: SensorConfig):
        self.config = config
        self.sensor_id = config.sensor_id
        self.label = config.label or f"Sensor_{config.sensor_id}"
        self.enabled = config.enabled

        # EMG pipeline components
        self._emg_filter: Optional[EMGFilterChain] = None
        if config.filter_config is not None:
            self._emg_filter = EMGFilterChain(config.filter_config)
        else:
            self._emg_filter = EMGFilterChain()

        # IMU pipeline component
        self._ahrs = MadgwickAHRS(sample_rate=config.imu_sample_rate)

        # Storage
        self.emg_raw: List[EMGFrame] = []
        self.emg_filtered: List[np.ndarray] = []
        self.imu_raw: List[IMUFrame] = []
        self.imu_quaternions: List[np.ndarray] = []
        self.imu_euler: List[np.ndarray] = []

    def process_emg(self, frame: EMGFrame) -> np.ndarray:
        """Run the EMG filter chain on a frame and store the result."""
        self.emg_raw.append(frame)
        filtered = self._emg_filter.apply(frame.data)
        self.emg_filtered.append(filtered)
        return filtered

    def process_imu(self, frame: IMUFrame) -> Tuple[np.ndarray, np.ndarray]:
        """Run Madgwick fusion on an IMU frame, return quaternions and Euler.
        """
        self.imu_raw.append(frame)
        quats = self._ahrs.process(frame.gyro, frame.accel, frame.mag)
        euler = quaternions_to_euler_batch(quats)
        self.imu_quaternions.append(quats)
        self.imu_euler.append(euler)
        return quats, euler

    def get_all_emg_filtered(self) -> np.ndarray:
        """Concatenate all filtered EMG data."""
        if not self.emg_filtered:
            return np.array([], dtype=np.float64)
        return np.concatenate(self.emg_filtered)

    def get_all_emg_timestamps(self) -> np.ndarray:
        """Concatenate all EMG timestamps."""
        if not self.emg_raw:
            return np.array([], dtype=np.float64)
        return np.concatenate([f.timestamps_us for f in self.emg_raw])

    def get_all_imu_quaternions(self) -> np.ndarray:
        """Concatenate all IMU quaternion data."""
        if not self.imu_quaternions:
            return np.empty((0, 4), dtype=np.float64)
        return np.concatenate(self.imu_quaternions)

    def get_all_imu_euler(self) -> np.ndarray:
        """Concatenate all Euler angle data."""
        if not self.imu_euler:
            return np.empty((0, 3), dtype=np.float64)
        return np.concatenate(self.imu_euler)

    def get_all_imu_timestamps(self) -> np.ndarray:
        """Concatenate all IMU timestamps."""
        if not self.imu_raw:
            return np.array([], dtype=np.float64)
        return np.concatenate([f.timestamps_us for f in self.imu_raw])

    def reset(self):
        """Clear all stored data and reset AHRS."""
        self.emg_raw.clear()
        self.emg_filtered.clear()
        self.imu_raw.clear()
        self.imu_quaternions.clear()
        self.imu_euler.clear()
        self._ahrs = MadgwickAHRS(sample_rate=self.config.imu_sample_rate)


# ===================================================================
# Sync manager
# ===================================================================

class SyncManager:
    """Microsecond-precision timestamp alignment across sensors.

    Uses linear interpolation to resample signals onto a common time base.
    """

    @staticmethod
    def align_timestamps(
        timestamps_list: List[np.ndarray],
        signals_list: List[np.ndarray],
        master_rate_hz: Optional[float] = None,
    ) -> Tuple[np.ndarray, List[np.ndarray]]:
        """Align multiple signals to a common time base.

        Parameters
        ----------
        timestamps_list : List of 1-D timestamp arrays (microseconds).
        signals_list : List of 1-D signal arrays (same lengths as timestamps).
        master_rate_hz : If provided, resample to this rate. Otherwise use the
                         densest signal's time base.

        Returns
        -------
        common_timestamps : 1-D common time base.
        aligned_signals : List of interpolated signals on the common base.
        """
        if not timestamps_list:
            return np.array([]), []

        # Find the common time range
        t_start = max(ts[0] for ts in timestamps_list if len(ts) > 0)
        t_end = min(ts[-1] for ts in timestamps_list if len(ts) > 0)

        if t_start >= t_end:
            return np.array([t_start]), [np.array([s[0]]) for s in signals_list]

        # Build master time base
        if master_rate_hz is not None:
            dt_us = 1e6 / master_rate_hz
        else:
            # Use the smallest inter-sample interval
            dt_us = min(
                np.min(np.diff(ts)) for ts in timestamps_list if len(ts) > 1
            )
            dt_us = max(dt_us, TIMESTAMP_RESOLUTION_US)

        common_ts = np.arange(t_start, t_end, dt_us)

        # Interpolate each signal
        aligned = []
        for ts, sig in zip(timestamps_list, signals_list):
            aligned.append(np.interp(common_ts, ts, sig))

        return common_ts, aligned

    @staticmethod
    def align_multichannel(
        timestamps_list: List[np.ndarray],
        signals_list: List[np.ndarray],
        master_rate_hz: Optional[float] = None,
    ) -> Tuple[np.ndarray, List[np.ndarray]]:
        """Align multi-channel (N, C) signals to a common time base.

        Each signal has shape (N_i, C) where C is the channel count.
        """
        if not timestamps_list:
            return np.array([]), []

        t_start = max(ts[0] for ts in timestamps_list if len(ts) > 0)
        t_end = min(ts[-1] for ts in timestamps_list if len(ts) > 0)
        if t_start >= t_end:
            return np.array([t_start]), [s[:1] for s in signals_list]

        if master_rate_hz is not None:
            dt_us = 1e6 / master_rate_hz
        else:
            dt_us = min(
                np.min(np.diff(ts)) for ts in timestamps_list if len(ts) > 1
            )
            dt_us = max(dt_us, TIMESTAMP_RESOLUTION_US)

        common_ts = np.arange(t_start, t_end, dt_us)
        aligned = []
        for ts, sig in zip(timestamps_list, signals_list):
            n_ch = sig.shape[1] if sig.ndim > 1 else 1
            if n_ch == 1:
                aligned.append(np.interp(common_ts, ts, sig.ravel())[:, None])
            else:
                interped = np.empty((len(common_ts), n_ch), dtype=np.float64)
                for c in range(n_ch):
                    interped[:, c] = np.interp(common_ts, ts, sig[:, c])
                aligned.append(interped)

        return common_ts, aligned


# ===================================================================
# Hardware trigger
# ===================================================================

class HardwareTrigger:
    """Hardware synchronization trigger manager.

    Records trigger events with microsecond precision and supports
    rising, falling, and both-edge detection.
    """

    def __init__(self):
        self._events: List[TriggerEvent] = []
        self._callbacks: List[Callable[[TriggerEvent], None]] = []

    def record_event(self, timestamp_us: float,
                     edge: TriggerEdge = TriggerEdge.RISING,
                     channel: int = 0, label: str = ""):
        """Record a trigger event."""
        event = TriggerEvent(
            timestamp_us=timestamp_us, edge=edge,
            channel=channel, label=label,
        )
        self._events.append(event)
        for cb in self._callbacks:
            cb(event)

    def detect_edges(self, signal: np.ndarray, timestamps_us: np.ndarray,
                     threshold: float = 0.5,
                     edge: TriggerEdge = TriggerEdge.RISING,
                     channel: int = 0) -> List[TriggerEvent]:
        """Detect trigger edges in a digital signal.

        Parameters
        ----------
        signal : 1-D digital trigger signal.
        timestamps_us : Corresponding microsecond timestamps.
        threshold : Logic-level threshold.
        edge : Which edges to detect.
        channel : Trigger channel number.

        Returns
        -------
        events : List of detected TriggerEvent objects.
        """
        detected = []
        for i in range(1, len(signal)):
            prev_high = signal[i - 1] >= threshold
            curr_high = signal[i] >= threshold

            is_rising = not prev_high and curr_high
            is_falling = prev_high and not curr_high

            record = False
            if edge == TriggerEdge.RISING and is_rising:
                record = True
                e = TriggerEdge.RISING
            elif edge == TriggerEdge.FALLING and is_falling:
                record = True
                e = TriggerEdge.FALLING
            elif edge == TriggerEdge.BOTH and (is_rising or is_falling):
                record = True
                e = TriggerEdge.RISING if is_rising else TriggerEdge.FALLING

            if record:
                evt = TriggerEvent(
                    timestamp_us=float(timestamps_us[i]),
                    edge=e, channel=channel,
                )
                detected.append(evt)
                self._events.append(evt)

        return detected

    def on_trigger(self, callback: Callable[[TriggerEvent], None]):
        """Register a callback for trigger events."""
        self._callbacks.append(callback)

    @property
    def events(self) -> List[TriggerEvent]:
        return list(self._events)

    def clear(self):
        self._events.clear()


# ===================================================================
# Orchestrator
# ===================================================================

class Orchestrator:
    """Multi-sensor orchestrator — the central manager for up to 16 sensors.

    Example
    -------
    >>> orch = Orchestrator()
    >>> orch.add_sensor(SensorConfig(sensor_id=1, label='Biceps'))
    >>> orch.add_sensor(SensorConfig(sensor_id=2, label='Triceps'))
    >>> orch.ingest_emg(1, emg_frame)
    >>> orch.ingest_imu(1, imu_frame)
    """

    def __init__(self):
        self._slots: Dict[int, SensorSlot] = {}
        self.trigger = HardwareTrigger()
        self.sync = SyncManager()

    # ----- sensor management -----------------------------------------
    def add_sensor(self, config: SensorConfig) -> SensorSlot:
        """Add a sensor slot.

        Raises ValueError if exceeding MAX_SENSORS or duplicate ID.
        """
        if len(self._slots) >= MAX_SENSORS:
            raise ValueError(f"Cannot exceed {MAX_SENSORS} sensors.")
        if config.sensor_id in self._slots:
            raise ValueError(f"Sensor ID {config.sensor_id} already exists.")
        slot = SensorSlot(config)
        self._slots[config.sensor_id] = slot
        return slot

    def remove_sensor(self, sensor_id: int):
        """Remove a sensor slot."""
        if sensor_id not in self._slots:
            raise KeyError(f"Sensor {sensor_id} not found.")
        del self._slots[sensor_id]

    def get_sensor(self, sensor_id: int) -> SensorSlot:
        """Get a sensor slot by ID."""
        if sensor_id not in self._slots:
            raise KeyError(f"Sensor {sensor_id} not found.")
        return self._slots[sensor_id]

    @property
    def sensor_ids(self) -> List[int]:
        return sorted(self._slots.keys())

    @property
    def n_sensors(self) -> int:
        return len(self._slots)

    # ----- data ingestion --------------------------------------------
    def ingest_emg(self, sensor_id: int, frame: EMGFrame) -> np.ndarray:
        """Feed an EMG frame into the sensor's processing pipeline.

        Returns the filtered signal.
        """
        return self.get_sensor(sensor_id).process_emg(frame)

    def ingest_imu(self, sensor_id: int, frame: IMUFrame) -> Tuple[np.ndarray, np.ndarray]:
        """Feed an IMU frame into the sensor's pipeline.

        Returns (quaternions, euler_angles).
        """
        return self.get_sensor(sensor_id).process_imu(frame)

    # ----- sync -------------------------------------------------------
    def align_all_emg(self, master_rate_hz: Optional[float] = None
                      ) -> Tuple[np.ndarray, Dict[int, np.ndarray]]:
        """Timestamp-align all sensors' filtered EMG data.

        Returns (common_timestamps, {sensor_id: aligned_signal}).
        """
        ts_list, sig_list, ids = [], [], []
        for sid in self.sensor_ids:
            slot = self._slots[sid]
            ts = slot.get_all_emg_timestamps()
            sig = slot.get_all_emg_filtered()
            if len(ts) > 1:
                ts_list.append(ts)
                sig_list.append(sig)
                ids.append(sid)

        if not ts_list:
            return np.array([]), {}

        common_ts, aligned = self.sync.align_timestamps(
            ts_list, sig_list, master_rate_hz,
        )
        return common_ts, {sid: sig for sid, sig in zip(ids, aligned)}

    # ----- bulk export helpers ----------------------------------------
    def collect_all_data(self) -> Dict[str, Any]:
        """Collect all processed data from all sensors into a dict for export.

        Returns a nested dict keyed by sensor_id.
        """
        data: Dict[str, Any] = {}
        for sid in self.sensor_ids:
            slot = self._slots[sid]
            sensor_data: Dict[str, Any] = {"label": slot.label}
            # EMG
            emg_filt = slot.get_all_emg_filtered()
            if len(emg_filt) > 0:
                sensor_data["emg_filtered"] = emg_filt
                sensor_data["emg_timestamps_us"] = slot.get_all_emg_timestamps()
            # IMU
            quats = slot.get_all_imu_quaternions()
            if len(quats) > 0:
                sensor_data["imu_quaternions"] = quats
                sensor_data["imu_euler"] = slot.get_all_imu_euler()
                sensor_data["imu_timestamps_us"] = slot.get_all_imu_timestamps()

            data[str(sid)] = sensor_data

        # Trigger events
        if self.trigger.events:
            data["trigger_events"] = [
                {
                    "timestamp_us": e.timestamp_us,
                    "edge": e.edge.value,
                    "channel": e.channel,
                    "label": e.label,
                }
                for e in self.trigger.events
            ]
        return data

    def reset_all(self):
        """Clear all stored data across all sensors."""
        for slot in self._slots.values():
            slot.reset()
        self.trigger.clear()
