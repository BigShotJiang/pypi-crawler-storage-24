"""
NeuralFlow SDK — Kinematics: Euler angles, gravity compensation,
linear acceleration, and joint angle estimation.

All computations use the Quaternion class from the fusion module.
"""

from __future__ import annotations

import math
from typing import Optional, Tuple

import numpy as np

from .fusion import Quaternion

# Earth's gravity in m/s²
_G = 9.80665


# ===================================================================
# Euler angle conversions
# ===================================================================

def quaternion_to_euler(q: Quaternion) -> Tuple[float, float, float]:
    """Convert a unit quaternion to Euler angles (ZYX convention).

    Returns
    -------
    (roll, pitch, yaw) in radians.

    - roll  = rotation about X (φ)
    - pitch = rotation about Y (θ)
    - yaw   = rotation about Z (ψ)
    """
    w, x, y, z = q.w, q.x, q.y, q.z

    # Roll (X-axis rotation)
    sinr_cosp = 2.0 * (w * x + y * z)
    cosr_cosp = 1.0 - 2.0 * (x * x + y * y)
    roll = math.atan2(sinr_cosp, cosr_cosp)

    # Pitch (Y-axis rotation) — clamp to avoid NaN at ±90°
    sinp = 2.0 * (w * y - z * x)
    sinp = max(-1.0, min(1.0, sinp))
    pitch = math.asin(sinp)

    # Yaw (Z-axis rotation)
    siny_cosp = 2.0 * (w * z + x * y)
    cosy_cosp = 1.0 - 2.0 * (y * y + z * z)
    yaw = math.atan2(siny_cosp, cosy_cosp)

    return roll, pitch, yaw


def euler_to_quaternion(roll: float, pitch: float,
                        yaw: float) -> Quaternion:
    """Convert Euler angles (ZYX convention) to a unit quaternion.

    Parameters
    ----------
    roll, pitch, yaw : angles in radians.
    """
    cr = math.cos(roll / 2.0);  sr = math.sin(roll / 2.0)
    cp = math.cos(pitch / 2.0); sp = math.sin(pitch / 2.0)
    cy = math.cos(yaw / 2.0);   sy = math.sin(yaw / 2.0)

    return Quaternion(
        cr * cp * cy + sr * sp * sy,
        sr * cp * cy - cr * sp * sy,
        cr * sp * cy + sr * cp * sy,
        cr * cp * sy - sr * sp * cy,
    )


def quaternions_to_euler_batch(quaternions: np.ndarray) -> np.ndarray:
    """Convert an array of quaternions (N, 4) to Euler angles (N, 3).

    Returns shape (N, 3) in radians: [roll, pitch, yaw] per row.
    """
    N = len(quaternions)
    euler = np.empty((N, 3), dtype=np.float64)
    for i in range(N):
        q = Quaternion(*quaternions[i])
        euler[i] = quaternion_to_euler(q)
    return euler


# ===================================================================
# Gravity compensation
# ===================================================================

def gravity_compensate(accel: np.ndarray, q: Quaternion) -> np.ndarray:
    """Remove the gravity component from an accelerometer reading.

    The orientation quaternion *q* is used to determine the direction of
    gravity in the sensor frame, which is then subtracted.

    Parameters
    ----------
    accel : (3,) accelerometer reading in m/s² (sensor frame).
    q : Current orientation quaternion (Earth→Sensor).

    Returns
    -------
    accel_no_gravity : (3,) linear acceleration in m/s² (sensor frame).
    """
    accel = np.asarray(accel, dtype=np.float64)

    # Gravity vector in Earth frame: [0, 0, g]
    g_earth = np.array([0.0, 0.0, _G])

    # Rotate gravity into sensor frame
    g_sensor = q.conjugate().rotate_vector(g_earth)

    return accel - g_sensor


def gravity_compensate_batch(accel: np.ndarray,
                             quaternions: np.ndarray) -> np.ndarray:
    """Batch gravity compensation.

    Parameters
    ----------
    accel : (N, 3) accelerometer data in m/s².
    quaternions : (N, 4) orientation quaternions [w, x, y, z].

    Returns
    -------
    linear_accel : (N, 3) gravity-free acceleration in m/s².
    """
    N = len(accel)
    result = np.empty((N, 3), dtype=np.float64)
    for i in range(N):
        q = Quaternion(*quaternions[i])
        result[i] = gravity_compensate(accel[i], q)
    return result


# ===================================================================
# Linear acceleration (convenience wrapper)
# ===================================================================

def linear_acceleration(accel: np.ndarray,
                        quaternions: np.ndarray) -> np.ndarray:
    """Extract linear (motion) acceleration by removing gravity.

    Alias for :func:`gravity_compensate_batch`.
    """
    return gravity_compensate_batch(accel, quaternions)


# ===================================================================
# Joint angle estimation
# ===================================================================

def joint_angle(q_proximal: Quaternion,
                q_distal: Quaternion) -> Tuple[float, float, float]:
    """Estimate the joint angle between two body segments.

    Computes the relative orientation:  q_rel = q_proximal⁻¹ * q_distal

    Then extracts Euler angles (flexion/extension, abduction/adduction,
    internal/external rotation).

    Parameters
    ----------
    q_proximal : Orientation quaternion of the proximal segment.
    q_distal : Orientation quaternion of the distal segment.

    Returns
    -------
    (flexion, abduction, rotation) in radians.
    """
    q_rel = q_proximal.inverse() * q_distal
    return quaternion_to_euler(q_rel)


def joint_angles_batch(q_proximal: np.ndarray,
                       q_distal: np.ndarray) -> np.ndarray:
    """Batch joint angle estimation.

    Parameters
    ----------
    q_proximal : (N, 4) quaternions of proximal segment.
    q_distal : (N, 4) quaternions of distal segment.

    Returns
    -------
    angles : (N, 3) joint angles [flexion, abduction, rotation] in radians.
    """
    N = len(q_proximal)
    angles = np.empty((N, 3), dtype=np.float64)
    for i in range(N):
        qp = Quaternion(*q_proximal[i])
        qd = Quaternion(*q_distal[i])
        angles[i] = joint_angle(qp, qd)
    return angles
