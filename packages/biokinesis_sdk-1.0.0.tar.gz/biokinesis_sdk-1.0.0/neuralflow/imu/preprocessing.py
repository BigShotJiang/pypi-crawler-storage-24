"""
NeuralFlow SDK — IMU preprocessing.

Raw 9-axis data ingestion, calibration (offset/scale correction),
and unit conversions.
"""

from __future__ import annotations

from typing import Optional, Tuple

import numpy as np

from ..core.constants import GRAVITY_MS2


def convert_units(
    accel_raw: np.ndarray,
    gyro_raw: np.ndarray,
    mag_raw: Optional[np.ndarray] = None,
    accel_full_scale_g: float = 16.0,
    gyro_full_scale_dps: float = 2000.0,
    mag_full_scale_ut: float = 4800.0,
    adc_max: int = 32767,
) -> Tuple[np.ndarray, np.ndarray, Optional[np.ndarray]]:
    """Convert raw integer sensor readings to physical units.

    Parameters
    ----------
    accel_raw : shape (N, 3), raw accelerometer counts.
    gyro_raw : shape (N, 3), raw gyroscope counts.
    mag_raw : shape (N, 3) or None, raw magnetometer counts.
    accel_full_scale_g : Accelerometer full-scale range in g.
    gyro_full_scale_dps : Gyroscope full-scale range in deg/s.
    mag_full_scale_ut : Magnetometer full-scale range in µT.
    adc_max : Maximum ADC count (positive side).

    Returns
    -------
    accel_ms2 : Accelerometer in m/s², shape (N, 3).
    gyro_rads : Gyroscope in rad/s, shape (N, 3).
    mag_ut : Magnetometer in µT, shape (N, 3) or None.
    """
    accel_raw = np.asarray(accel_raw, dtype=np.float64)
    gyro_raw = np.asarray(gyro_raw, dtype=np.float64)

    # Accelerometer: raw → g → m/s²
    accel_g = accel_raw * (accel_full_scale_g / adc_max)
    accel_ms2 = accel_g * GRAVITY_MS2

    # Gyroscope: raw → deg/s → rad/s
    gyro_dps = gyro_raw * (gyro_full_scale_dps / adc_max)
    gyro_rads = np.deg2rad(gyro_dps)

    # Magnetometer
    mag_ut = None
    if mag_raw is not None:
        mag_raw = np.asarray(mag_raw, dtype=np.float64)
        mag_ut = mag_raw * (mag_full_scale_ut / adc_max)

    return accel_ms2, gyro_rads, mag_ut


def calibrate_imu(
    accel: np.ndarray,
    gyro: np.ndarray,
    mag: Optional[np.ndarray] = None,
    accel_offset: Optional[np.ndarray] = None,
    accel_scale: Optional[np.ndarray] = None,
    gyro_offset: Optional[np.ndarray] = None,
    mag_offset: Optional[np.ndarray] = None,
    mag_scale: Optional[np.ndarray] = None,
) -> Tuple[np.ndarray, np.ndarray, Optional[np.ndarray]]:
    """Apply calibration offsets and scale corrections.

    corrected = (raw − offset) * scale

    Parameters
    ----------
    accel : shape (N, 3) in m/s².
    gyro : shape (N, 3) in rad/s.
    mag : shape (N, 3) in µT, or None.
    *_offset : shape (3,) bias vectors (default zeros).
    *_scale : shape (3,) scale vectors (default ones).

    Returns
    -------
    accel_cal, gyro_cal, mag_cal : Calibrated arrays.
    """
    accel = np.asarray(accel, dtype=np.float64)
    gyro = np.asarray(gyro, dtype=np.float64)

    a_off = np.zeros(3) if accel_offset is None else np.asarray(accel_offset, dtype=np.float64)
    a_sc = np.ones(3) if accel_scale is None else np.asarray(accel_scale, dtype=np.float64)
    g_off = np.zeros(3) if gyro_offset is None else np.asarray(gyro_offset, dtype=np.float64)

    accel_cal = (accel - a_off) * a_sc
    gyro_cal = gyro - g_off

    mag_cal = None
    if mag is not None:
        mag = np.asarray(mag, dtype=np.float64)
        m_off = np.zeros(3) if mag_offset is None else np.asarray(mag_offset, dtype=np.float64)
        m_sc = np.ones(3) if mag_scale is None else np.asarray(mag_scale, dtype=np.float64)
        mag_cal = (mag - m_off) * m_sc

    return accel_cal, gyro_cal, mag_cal


def estimate_gyro_bias(
    gyro: np.ndarray,
    stationary_duration_samples: int = 500,
) -> np.ndarray:
    """Estimate gyroscope bias from a stationary segment at the start of data.

    Parameters
    ----------
    gyro : shape (N, 3) in rad/s.
    stationary_duration_samples : Number of samples to average.

    Returns
    -------
    bias : shape (3,) estimated gyro bias.
    """
    gyro = np.asarray(gyro, dtype=np.float64)
    n = min(stationary_duration_samples, len(gyro))
    return np.mean(gyro[:n], axis=0)
