"""
NeuralFlow SDK — Sensor fusion: Madgwick AHRS and Quaternion math.

The Madgwick filter is implemented from scratch following the original paper:
    S. Madgwick, "An efficient orientation filter for inertial and
    inertial/magnetic sensor arrays," 2010.

Supports both 6-DOF (acc + gyro) and 9-DOF (acc + gyro + mag) modes.
"""

from __future__ import annotations

import math
from typing import Optional, Tuple

import numpy as np


# ===================================================================
# Quaternion class — full algebra
# ===================================================================

class Quaternion:
    """Unit quaternion for 3-D orientation.

    Stored as (w, x, y, z) where  q = w + x·i + y·j + z·k.
    """

    __slots__ = ("w", "x", "y", "z")

    def __init__(self, w: float = 1.0, x: float = 0.0,
                 y: float = 0.0, z: float = 0.0):
        self.w = w
        self.x = x
        self.y = y
        self.z = z

    # ---------- constructors -----------------------------------------
    @classmethod
    def identity(cls) -> "Quaternion":
        return cls(1.0, 0.0, 0.0, 0.0)

    @classmethod
    def from_array(cls, arr) -> "Quaternion":
        a = np.asarray(arr, dtype=np.float64).ravel()
        return cls(a[0], a[1], a[2], a[3])

    @classmethod
    def from_axis_angle(cls, axis, angle_rad: float) -> "Quaternion":
        """Create from an axis (3-vector) and rotation angle in radians."""
        axis = np.asarray(axis, dtype=np.float64)
        n = np.linalg.norm(axis)
        if n < 1e-12:
            return cls.identity()
        axis = axis / n
        ha = angle_rad / 2.0
        s = math.sin(ha)
        return cls(math.cos(ha), axis[0] * s, axis[1] * s, axis[2] * s)

    # ---------- algebra -----------------------------------------------
    def __mul__(self, other: "Quaternion") -> "Quaternion":
        """Hamilton product q1 * q2."""
        return Quaternion(
            self.w * other.w - self.x * other.x - self.y * other.y - self.z * other.z,
            self.w * other.x + self.x * other.w + self.y * other.z - self.z * other.y,
            self.w * other.y - self.x * other.z + self.y * other.w + self.z * other.x,
            self.w * other.z + self.x * other.y - self.y * other.x + self.z * other.w,
        )

    def conjugate(self) -> "Quaternion":
        return Quaternion(self.w, -self.x, -self.y, -self.z)

    def inverse(self) -> "Quaternion":
        n2 = self.norm_sq()
        if n2 < 1e-15:
            return Quaternion.identity()
        c = self.conjugate()
        return Quaternion(c.w / n2, c.x / n2, c.y / n2, c.z / n2)

    def norm(self) -> float:
        return math.sqrt(self.w ** 2 + self.x ** 2 + self.y ** 2 + self.z ** 2)

    def norm_sq(self) -> float:
        return self.w ** 2 + self.x ** 2 + self.y ** 2 + self.z ** 2

    def normalize(self) -> "Quaternion":
        n = self.norm()
        if n < 1e-15:
            return Quaternion.identity()
        return Quaternion(self.w / n, self.x / n, self.y / n, self.z / n)

    def rotate_vector(self, v) -> np.ndarray:
        """Rotate a 3-D vector by this quaternion:  v' = q v q*."""
        v = np.asarray(v, dtype=np.float64)
        qv = Quaternion(0.0, v[0], v[1], v[2])
        r = self * qv * self.conjugate()
        return np.array([r.x, r.y, r.z])

    def to_array(self) -> np.ndarray:
        return np.array([self.w, self.x, self.y, self.z])

    def __repr__(self) -> str:
        return f"Quaternion({self.w:.6f}, {self.x:.6f}, {self.y:.6f}, {self.z:.6f})"


# ===================================================================
# Madgwick AHRS filter
# ===================================================================

class MadgwickAHRS:
    """Madgwick gradient-descent AHRS filter.

    Parameters
    ----------
    sample_rate : IMU sample rate in Hz.
    beta : Filter gain (default 0.1). Higher → more aggressive accelerometer
           correction, less gyro drift but more noise.
    q0 : Initial orientation quaternion.
    """

    def __init__(self, sample_rate: float = 148.0, beta: float = 0.1,
                 q0: Optional[Quaternion] = None):
        self.sample_rate = sample_rate
        self.beta = beta
        self.q = q0 if q0 is not None else Quaternion.identity()

    @property
    def quaternion(self) -> Quaternion:
        return self.q

    # ---------- 6-DOF update (acc + gyro) ----------------------------
    def update_imu(self, gyro: np.ndarray, accel: np.ndarray) -> Quaternion:
        """6-DOF update using accelerometer + gyroscope.

        Parameters
        ----------
        gyro : (3,) array in rad/s.
        accel : (3,) array in m/s² (direction of gravity when stationary).
        """
        q = self.q
        dt = 1.0 / self.sample_rate

        gx, gy, gz = float(gyro[0]), float(gyro[1]), float(gyro[2])
        ax, ay, az = float(accel[0]), float(accel[1]), float(accel[2])

        # Normalise accelerometer
        a_norm = math.sqrt(ax * ax + ay * ay + az * az)
        if a_norm < 1e-10:
            # Free-fall or invalid — skip correction
            q_dot = Quaternion(
                0.5 * (-q.x * gx - q.y * gy - q.z * gz),
                0.5 * (q.w * gx + q.y * gz - q.z * gy),
                0.5 * (q.w * gy - q.x * gz + q.z * gx),
                0.5 * (q.w * gz + q.x * gy - q.y * gx),
            )
            self.q = Quaternion(q.w + q_dot.w * dt, q.x + q_dot.x * dt,
                                q.y + q_dot.y * dt, q.z + q_dot.z * dt).normalize()
            return self.q

        ax /= a_norm; ay /= a_norm; az /= a_norm

        # Auxiliary variables
        _2qw = 2.0 * q.w; _2qx = 2.0 * q.x
        _2qy = 2.0 * q.y; _2qz = 2.0 * q.z
        _4qw = 4.0 * q.w; _4qx = 4.0 * q.x
        _4qy = 4.0 * q.y
        _8qx = 8.0 * q.x; _8qy = 8.0 * q.y
        qwsq = q.w * q.w; qxsq = q.x * q.x
        qysq = q.y * q.y; qzsq = q.z * q.z

        # Gradient (objective function: align measured gravity to expected)
        s0 = _4qw * qysq + _2qy * ax + _4qw * qxsq - _2qx * ay
        s1 = (_4qx * qzsq - _2qz * ax + 4.0 * qwsq * q.x - _2qw * ay
              - _4qx + _8qx * qxsq + _8qx * qysq + _4qx * az)
        s2 = (4.0 * qwsq * q.y + _2qw * ax + _4qy * qzsq - _2qz * ay
              - _4qy + _8qy * qxsq + _8qy * qysq + _4qy * az)
        s3 = 4.0 * qxsq * q.z - _2qx * ax + 4.0 * qysq * q.z - _2qy * ay

        # Normalise gradient
        s_norm = math.sqrt(s0 * s0 + s1 * s1 + s2 * s2 + s3 * s3)
        if s_norm > 1e-12:
            s0 /= s_norm; s1 /= s_norm; s2 /= s_norm; s3 /= s_norm

        # Quaternion rate of change = gyro integration − beta * gradient
        q_dot_w = 0.5 * (-q.x * gx - q.y * gy - q.z * gz) - self.beta * s0
        q_dot_x = 0.5 * (q.w * gx + q.y * gz - q.z * gy) - self.beta * s1
        q_dot_y = 0.5 * (q.w * gy - q.x * gz + q.z * gx) - self.beta * s2
        q_dot_z = 0.5 * (q.w * gz + q.x * gy - q.y * gx) - self.beta * s3

        # Integrate
        self.q = Quaternion(
            q.w + q_dot_w * dt,
            q.x + q_dot_x * dt,
            q.y + q_dot_y * dt,
            q.z + q_dot_z * dt,
        ).normalize()
        return self.q

    # ---------- 9-DOF update (acc + gyro + mag) ----------------------
    def update_marg(self, gyro: np.ndarray, accel: np.ndarray,
                    mag: np.ndarray) -> Quaternion:
        """9-DOF MARG update using accelerometer + gyroscope + magnetometer.

        Parameters
        ----------
        gyro : (3,) in rad/s.
        accel : (3,) in m/s².
        mag : (3,) in µT.
        """
        q = self.q
        dt = 1.0 / self.sample_rate

        gx, gy, gz = float(gyro[0]), float(gyro[1]), float(gyro[2])
        ax, ay, az = float(accel[0]), float(accel[1]), float(accel[2])
        mx, my, mz = float(mag[0]), float(mag[1]), float(mag[2])

        # Normalise accelerometer
        a_norm = math.sqrt(ax * ax + ay * ay + az * az)
        if a_norm < 1e-10:
            return self.update_imu(gyro, accel)
        ax /= a_norm; ay /= a_norm; az /= a_norm

        # Normalise magnetometer
        m_norm = math.sqrt(mx * mx + my * my + mz * mz)
        if m_norm < 1e-10:
            return self.update_imu(gyro, accel)
        mx /= m_norm; my /= m_norm; mz /= m_norm

        # Auxiliary variables
        qw, qx, qy, qz = q.w, q.x, q.y, q.z
        _2qw = 2.0 * qw; _2qx = 2.0 * qx
        _2qy = 2.0 * qy; _2qz = 2.0 * qz
        _2qwmx = _2qw * mx; _2qwmy = _2qw * my; _2qwmz = _2qw * mz
        _2qxmx = _2qx * mx
        qwsq = qw * qw; qxsq = qx * qx; qysq = qy * qy; qzsq = qz * qz

        # Reference direction of Earth's magnetic field
        hx = (mx * qwsq - _2qwmy * qz + _2qwmz * qy + mx * qxsq
              + _2qx * my * qy + _2qx * mz * qz - mx * qysq - mx * qzsq)
        hy = (_2qwmx * qz + my * qwsq - _2qwmz * qx + _2qxmx * qy
              - my * qxsq + my * qysq + _2qy * mz * qz - my * qzsq)
        _2bx = math.sqrt(hx * hx + hy * hy)
        _2bz = (-_2qwmx * qy + _2qwmy * qx + mz * qwsq + _2qxmx * qz
                - mz * qxsq + _2qy * my * qz - mz * qysq + mz * qzsq)

        _4bx = 2.0 * _2bx; _4bz = 2.0 * _2bz

        # Gradient for 9-DOF
        s0 = (-_2qy * (2.0 * qx * qz - _2qw * qy - ax)
              + _2qx * (2.0 * qw * qx + _2qy * qz - ay)
              - _2bz * qy * (_2bx * (0.5 - qysq - qzsq) + _2bz * (qx * qz - qw * qy) - mx)
              + (-_2bx * qz + _2bz * qx) * (_2bx * (qx * qy - qw * qz)
              + _2bz * (qw * qx + qy * qz) - my)
              + _2bx * qy * (_2bx * (qw * qy + qx * qz) + _2bz * (0.5 - qxsq - qysq) - mz))

        s1 = (_2qz * (2.0 * qx * qz - _2qw * qy - ax)
              + _2qw * (2.0 * qw * qx + _2qy * qz - ay)
              - 4.0 * qx * (1.0 - 2.0 * qxsq - 2.0 * qysq - az)
              + _2bz * qz * (_2bx * (0.5 - qysq - qzsq) + _2bz * (qx * qz - qw * qy) - mx)
              + (_2bx * qy + _2bz * qw) * (_2bx * (qx * qy - qw * qz)
              + _2bz * (qw * qx + qy * qz) - my)
              + (_2bx * qz - _4bz * qx) * (_2bx * (qw * qy + qx * qz)
              + _2bz * (0.5 - qxsq - qysq) - mz))

        s2 = (-_2qw * (2.0 * qx * qz - _2qw * qy - ax)
              + _2qz * (2.0 * qw * qx + _2qy * qz - ay)
              - 4.0 * qy * (1.0 - 2.0 * qxsq - 2.0 * qysq - az)
              + (-_4bx * qy - _2bz * qw) * (_2bx * (0.5 - qysq - qzsq)
              + _2bz * (qx * qz - qw * qy) - mx)
              + (_2bx * qx + _2bz * qz) * (_2bx * (qx * qy - qw * qz)
              + _2bz * (qw * qx + qy * qz) - my)
              + (_2bx * qw - _4bz * qy) * (_2bx * (qw * qy + qx * qz)
              + _2bz * (0.5 - qxsq - qysq) - mz))

        s3 = (_2qx * (2.0 * qx * qz - _2qw * qy - ax)
              + _2qy * (2.0 * qw * qx + _2qy * qz - ay)
              + (-_4bx * qz + _2bz * qx) * (_2bx * (0.5 - qysq - qzsq)
              + _2bz * (qx * qz - qw * qy) - mx)
              + (-_2bx * qw + _2bz * qy) * (_2bx * (qx * qy - qw * qz)
              + _2bz * (qw * qx + qy * qz) - my)
              + _2bx * qx * (_2bx * (qw * qy + qx * qz)
              + _2bz * (0.5 - qxsq - qysq) - mz))

        # Normalise gradient
        s_norm = math.sqrt(s0 * s0 + s1 * s1 + s2 * s2 + s3 * s3)
        if s_norm > 1e-12:
            s0 /= s_norm; s1 /= s_norm; s2 /= s_norm; s3 /= s_norm

        # Quaternion rate of change
        q_dot_w = 0.5 * (-qx * gx - qy * gy - qz * gz) - self.beta * s0
        q_dot_x = 0.5 * (qw * gx + qy * gz - qz * gy) - self.beta * s1
        q_dot_y = 0.5 * (qw * gy - qx * gz + qz * gx) - self.beta * s2
        q_dot_z = 0.5 * (qw * gz + qx * gy - qy * gx) - self.beta * s3

        # Integrate
        self.q = Quaternion(
            qw + q_dot_w * dt, qx + q_dot_x * dt,
            qy + q_dot_y * dt, qz + q_dot_z * dt,
        ).normalize()
        return self.q

    # ---------- batch processing -------------------------------------
    def process(self, gyro: np.ndarray, accel: np.ndarray,
                mag: Optional[np.ndarray] = None) -> np.ndarray:
        """Process a batch of IMU samples.

        Parameters
        ----------
        gyro : shape (N, 3) in rad/s.
        accel : shape (N, 3) in m/s².
        mag : shape (N, 3) in µT, or None for 6-DOF.

        Returns
        -------
        quaternions : shape (N, 4) — [w, x, y, z] per sample.
        """
        N = len(gyro)
        quats = np.empty((N, 4), dtype=np.float64)

        for i in range(N):
            if mag is not None:
                self.update_marg(gyro[i], accel[i], mag[i])
            else:
                self.update_imu(gyro[i], accel[i])
            quats[i] = self.q.to_array()

        return quats
