"""IMU processing chain — sensor fusion and kinematics."""

from .preprocessing import calibrate_imu, convert_units
from .fusion import Quaternion, MadgwickAHRS
from .kinematics import (
    quaternion_to_euler, gravity_compensate, linear_acceleration,
    joint_angle,
)

__all__ = [
    "calibrate_imu", "convert_units",
    "Quaternion", "MadgwickAHRS",
    "quaternion_to_euler", "gravity_compensate", "linear_acceleration",
    "joint_angle",
]
