"""
NeuralFlow SDK — Core data types.

All sensor data flows through these structures. They are plain dataclasses
so serialization / export is straightforward.
"""

from __future__ import annotations

import dataclasses as dc
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

import numpy as np


# ---------------------------------------------------------------------------
# Enumerations
# ---------------------------------------------------------------------------
class SensorType(Enum):
    """Sensor modality."""
    EMG = "emg"
    IMU = "imu"
    EMG_IMU = "emg_imu"


class TriggerEdge(Enum):
    """Hardware trigger edge type."""
    RISING = "rising"
    FALLING = "falling"
    BOTH = "both"


class BandwidthPreset(Enum):
    """EMG bandwidth presets."""
    STANDARD = (20.0, 450.0)   # 20–450 Hz
    WIDE = (10.0, 850.0)       # 10–850 Hz
    CUSTOM = None


# ---------------------------------------------------------------------------
# Filter configuration
# ---------------------------------------------------------------------------
@dc.dataclass
class FilterConfig:
    """Configuration for the EMG filter chain.

    Attributes
    ----------
    bandpass_low : Low cutoff frequency in Hz.
    bandpass_high : High cutoff frequency in Hz.
    bandpass_order : Butterworth filter order.
    notch_freq : Power-line notch frequency (50 or 60 Hz). ``None`` to skip.
    notch_q : Quality factor for the notch filter.
    sample_rate : Sampling rate in Hz.
    """
    bandpass_low: float = 20.0
    bandpass_high: float = 450.0
    bandpass_order: int = 4
    notch_freq: Optional[float] = 50.0
    notch_q: float = 30.0
    sample_rate: float = 2000.0

    @classmethod
    def standard(cls, sample_rate: float = 2000.0, notch: float = 50.0) -> "FilterConfig":
        """20–450 Hz bandpass with notch."""
        return cls(bandpass_low=20.0, bandpass_high=450.0, notch_freq=notch, sample_rate=sample_rate)

    @classmethod
    def wide(cls, sample_rate: float = 2000.0, notch: float = 50.0) -> "FilterConfig":
        """10–850 Hz bandpass with notch."""
        return cls(bandpass_low=10.0, bandpass_high=850.0, notch_freq=notch, sample_rate=sample_rate)


# ---------------------------------------------------------------------------
# Sensor configuration
# ---------------------------------------------------------------------------
@dc.dataclass
class SensorConfig:
    """Per-sensor configuration.

    Attributes
    ----------
    sensor_id : Unique sensor identifier (1–16).
    sensor_type : Modality (EMG, IMU, or combined).
    label : Human-readable label (e.g. 'Biceps Brachii').
    emg_sample_rate : EMG sampling rate in Hz.
    imu_sample_rate : IMU sampling rate in Hz.
    filter_config : EMG filter chain configuration.
    enabled : Whether this slot is active.
    """
    sensor_id: int = 1
    sensor_type: SensorType = SensorType.EMG_IMU
    label: str = ""
    emg_sample_rate: float = 2000.0
    imu_sample_rate: float = 148.0
    filter_config: Optional[FilterConfig] = None
    enabled: bool = True


# ---------------------------------------------------------------------------
# Data frames
# ---------------------------------------------------------------------------
@dc.dataclass
class EMGFrame:
    """A block of EMG samples from one sensor.

    Attributes
    ----------
    sensor_id : Source sensor identifier.
    timestamps_us : Microsecond timestamps, shape (N,).
    data : Raw bipolar differential EMG in µV, shape (N,).
    sample_rate : Sampling rate in Hz.
    """
    sensor_id: int
    timestamps_us: np.ndarray  # (N,)
    data: np.ndarray            # (N,)
    sample_rate: float = 2000.0

    @property
    def n_samples(self) -> int:
        return len(self.data)

    @property
    def duration_s(self) -> float:
        return self.n_samples / self.sample_rate


@dc.dataclass
class IMUFrame:
    """A block of 9-axis IMU samples from one sensor.

    Attributes
    ----------
    sensor_id : Source sensor identifier.
    timestamps_us : Microsecond timestamps, shape (N,).
    accel : Accelerometer data in m/s², shape (N, 3).
    gyro : Gyroscope data in rad/s, shape (N, 3).
    mag : Magnetometer data in µT, shape (N, 3). May be ``None``.
    sample_rate : Sampling rate in Hz.
    """
    sensor_id: int
    timestamps_us: np.ndarray   # (N,)
    accel: np.ndarray            # (N, 3)
    gyro: np.ndarray             # (N, 3)
    mag: Optional[np.ndarray]    # (N, 3) or None
    sample_rate: float = 148.0

    @property
    def n_samples(self) -> int:
        return len(self.accel)

    @property
    def has_mag(self) -> bool:
        return self.mag is not None


@dc.dataclass
class SensorSample:
    """Combined EMG + IMU sample from a single sensor at a single time instant."""
    sensor_id: int
    timestamp_us: float
    emg_uv: Optional[float] = None
    accel: Optional[Tuple[float, float, float]] = None
    gyro: Optional[Tuple[float, float, float]] = None
    mag: Optional[Tuple[float, float, float]] = None


# ---------------------------------------------------------------------------
# Trigger events
# ---------------------------------------------------------------------------
@dc.dataclass
class TriggerEvent:
    """A hardware synchronization trigger event.

    Attributes
    ----------
    timestamp_us : Microsecond timestamp of the trigger.
    edge : Rising, falling, or both-edge detection.
    channel : Trigger input channel (for multi-channel trigger boxes).
    label : Optional event label.
    """
    timestamp_us: float
    edge: TriggerEdge = TriggerEdge.RISING
    channel: int = 0
    label: str = ""


# ---------------------------------------------------------------------------
# Calibration
# ---------------------------------------------------------------------------
@dc.dataclass
class CalibrationData:
    """Sensor calibration offsets and scale factors.

    Attributes
    ----------
    accel_offset : Accelerometer bias, shape (3,).
    accel_scale : Accelerometer scale, shape (3,).
    gyro_offset : Gyroscope bias, shape (3,).
    mag_offset : Hard-iron offset, shape (3,).
    mag_scale : Soft-iron scale, shape (3,).
    """
    accel_offset: np.ndarray = dc.field(default_factory=lambda: np.zeros(3))
    accel_scale: np.ndarray = dc.field(default_factory=lambda: np.ones(3))
    gyro_offset: np.ndarray = dc.field(default_factory=lambda: np.zeros(3))
    mag_offset: np.ndarray = dc.field(default_factory=lambda: np.zeros(3))
    mag_scale: np.ndarray = dc.field(default_factory=lambda: np.ones(3))


# ---------------------------------------------------------------------------
# Pipeline result
# ---------------------------------------------------------------------------
@dc.dataclass
class PipelineResult:
    """Generic result container for clinical pipelines.

    Attributes
    ----------
    name : Name of the pipeline that produced this result.
    metrics : Dictionary of computed metric names → values.
    time_series : Dictionary of computed time-series arrays.
    events : List of detected events (onset, heel-strike, etc.).
    metadata : Arbitrary extra metadata.
    """
    name: str
    metrics: Dict[str, Any] = dc.field(default_factory=dict)
    time_series: Dict[str, np.ndarray] = dc.field(default_factory=dict)
    events: List[Dict[str, Any]] = dc.field(default_factory=list)
    metadata: Dict[str, Any] = dc.field(default_factory=dict)
