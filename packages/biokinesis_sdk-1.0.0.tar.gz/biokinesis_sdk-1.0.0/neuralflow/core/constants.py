"""
NeuralFlow SDK — Hardware constants and configuration presets.

Designed to match or exceed Delsys Trigno specifications:
  - EMG: 2000 Hz, 16-bit, bipolar differential
  - IMU: 148 Hz, 9-axis (acc + gyro + mag)
  - Up to 16 sensor slots
"""

# ---------------------------------------------------------------------------
# Sampling rates (Hz)
# ---------------------------------------------------------------------------
EMG_SAMPLE_RATE: int = 2000
"""EMG sampling rate in Hz — matches Delsys Trigno Avanti."""

IMU_SAMPLE_RATE: int = 148
"""IMU sampling rate in Hz — 9-axis (accelerometer + gyroscope + magnetometer)."""

# ---------------------------------------------------------------------------
# Resolution
# ---------------------------------------------------------------------------
RESOLUTION_BITS: int = 16
"""ADC resolution in bits — 16-bit signed gives ±32 767 counts."""

ADC_MAX_VALUE: int = (1 << (RESOLUTION_BITS - 1)) - 1  # 32767
ADC_MIN_VALUE: int = -(1 << (RESOLUTION_BITS - 1))       # -32768

# Reference voltage for ADC conversion (typical for EMG front-end)
REFERENCE_VOLTAGE_MV: float = 3300.0  # 3.3 V rail

# ---------------------------------------------------------------------------
# Bandwidth presets (Hz) — bandpass filter cutoffs
# ---------------------------------------------------------------------------
BANDWIDTH_STANDARD: tuple = (20.0, 450.0)
"""Standard EMG bandwidth: 20–450 Hz (clinical default)."""

BANDWIDTH_WIDE: tuple = (10.0, 850.0)
"""Wide EMG bandwidth: 10–850 Hz (research / high-density EMG)."""

# ---------------------------------------------------------------------------
# Notch filter frequencies
# ---------------------------------------------------------------------------
NOTCH_50HZ: float = 50.0
"""Power-line notch for 50 Hz regions (Europe, Asia, Africa)."""

NOTCH_60HZ: float = 60.0
"""Power-line notch for 60 Hz regions (Americas, parts of Asia)."""

NOTCH_Q_FACTOR: float = 30.0
"""Quality factor for the notch filter (higher = narrower notch)."""

# ---------------------------------------------------------------------------
# Sensor topology
# ---------------------------------------------------------------------------
MAX_SENSORS: int = 16
"""Maximum simultaneous sensor slots supported by the orchestrator."""

MIN_SENSOR_ID: int = 1
MAX_SENSOR_ID: int = MAX_SENSORS

# ---------------------------------------------------------------------------
# IMU full-scale ranges (defaults)
# ---------------------------------------------------------------------------
ACCEL_FULL_SCALE_G: float = 16.0
"""Accelerometer full-scale range in g."""

GYRO_FULL_SCALE_DPS: float = 2000.0
"""Gyroscope full-scale range in degrees/second."""

MAG_FULL_SCALE_UT: float = 4800.0
"""Magnetometer full-scale range in microtesla."""

GRAVITY_MS2: float = 9.80665
"""Standard gravity in m/s²."""

# ---------------------------------------------------------------------------
# Default filter parameters
# ---------------------------------------------------------------------------
DEFAULT_BUTTERWORTH_ORDER: int = 4
"""Default Butterworth filter order (4th order = 24 dB/octave)."""

DEFAULT_NOTCH_FREQUENCY: float = NOTCH_50HZ

# ---------------------------------------------------------------------------
# Feature extraction defaults
# ---------------------------------------------------------------------------
DEFAULT_RMS_WINDOW_MS: float = 250.0
"""Default RMS envelope window length in milliseconds."""

DEFAULT_ONSET_THRESHOLD_FACTOR: float = 3.0
"""Default muscle onset detection threshold (× baseline std)."""

DEFAULT_ONSET_MIN_DURATION_MS: float = 50.0
"""Minimum duration above threshold to count as onset (ms)."""

# ---------------------------------------------------------------------------
# Sync / trigger
# ---------------------------------------------------------------------------
TRIGGER_RISING_EDGE: str = "rising"
TRIGGER_FALLING_EDGE: str = "falling"
TRIGGER_BOTH_EDGES: str = "both"

TIMESTAMP_RESOLUTION_US: float = 1.0
"""Timestamp resolution in microseconds."""
