"""Core data types and constants for NeuralFlow SDK."""

from .types import (
    SensorSample, EMGFrame, IMUFrame, SensorConfig, FilterConfig,
    PipelineResult, TriggerEvent, CalibrationData,
)
from .constants import (
    EMG_SAMPLE_RATE, IMU_SAMPLE_RATE, RESOLUTION_BITS, MAX_SENSORS,
    BANDWIDTH_STANDARD, BANDWIDTH_WIDE, NOTCH_50HZ, NOTCH_60HZ,
)

__all__ = [
    "SensorSample", "EMGFrame", "IMUFrame", "SensorConfig", "FilterConfig",
    "PipelineResult", "TriggerEvent", "CalibrationData",
    "EMG_SAMPLE_RATE", "IMU_SAMPLE_RATE", "RESOLUTION_BITS", "MAX_SENSORS",
    "BANDWIDTH_STANDARD", "BANDWIDTH_WIDE", "NOTCH_50HZ", "NOTCH_60HZ",
]
