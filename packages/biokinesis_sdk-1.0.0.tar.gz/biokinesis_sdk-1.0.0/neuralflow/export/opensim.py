"""
NeuralFlow SDK — OpenSim-compatible export layer.

Generates files directly consumable by OpenSim, OpenSenseRT, and CEINMS-RT:

  - ``.sto``  — OpenSim Storage format (generic time-series)
  - ``.trc``  — Track Row Column format (marker/position data)
  - ``.mot``  — Motion file format (forces, generalized coordinates)
  - OpenSenseRT quaternion ``.sto`` + Settings XML
  - CEINMS-RT EMG ``.sto`` + trial configuration XML

File format references:
  https://simtk-confluence.stanford.edu/display/OpenSim/STO+File+Format
  https://simtk-confluence.stanford.edu/display/OpenSim/TRC+File+Format
"""

from __future__ import annotations

import math
import os
import time as _time
from typing import Any, Dict, List, Optional, Tuple
from xml.etree import ElementTree as ET
from xml.dom import minidom

import numpy as np


# ===================================================================
# OpenSim .sto writer (core building block)
# ===================================================================

class OpenSimSTO:
    """Read/write OpenSim Storage (.sto) files.

    The .sto format is a tab-delimited text file with a structured header::

        <name>
        version=1
        nRows=<N>
        nColumns=<C>
        inDegrees=yes|no
        endheader
        time\tcol1\tcol2\t...
        0.0\t1.23\t4.56\t...
    """

    @staticmethod
    def write(filepath: str,
              time: np.ndarray,
              data: np.ndarray,
              column_labels: List[str],
              name: str = "NeuralFlow",
              in_degrees: bool = False) -> str:
        """Write an OpenSim .sto file.

        Parameters
        ----------
        filepath : Output path (should end in ``.sto``).
        time : 1-D array of time values in seconds, shape (N,).
        data : 2-D array of data, shape (N, C) where C = len(column_labels).
        column_labels : List of column names (excluding 'time').
        name : Name/identifier written on the first header line.
        in_degrees : Whether angular data is in degrees (True) or radians.

        Returns
        -------
        filepath : Written file path.
        """
        time = np.asarray(time, dtype=np.float64)
        data = np.asarray(data, dtype=np.float64)
        n_rows = len(time)
        n_cols = len(column_labels) + 1  # +1 for time column

        if data.ndim == 1:
            data = data[:, np.newaxis]

        if data.shape != (n_rows, len(column_labels)):
            raise ValueError(
                f"Data shape {data.shape} does not match "
                f"({n_rows}, {len(column_labels)})")

        os.makedirs(os.path.dirname(filepath) or ".", exist_ok=True)

        with open(filepath, "w", newline="\n") as f:
            # Header
            f.write(f"{name}\n")
            f.write("version=1\n")
            f.write(f"nRows={n_rows}\n")
            f.write(f"nColumns={n_cols}\n")
            f.write(f"inDegrees={'yes' if in_degrees else 'no'}\n")
            f.write("endheader\n")

            # Column labels
            f.write("time\t" + "\t".join(column_labels) + "\n")

            # Data rows
            for i in range(n_rows):
                row_vals = [f"{time[i]:.8f}"]
                for j in range(len(column_labels)):
                    row_vals.append(f"{data[i, j]:.8f}")
                f.write("\t".join(row_vals) + "\n")

        return filepath

    @staticmethod
    def read(filepath: str) -> Tuple[np.ndarray, np.ndarray, List[str], Dict[str, str]]:
        """Read an OpenSim .sto file.

        Returns
        -------
        time : 1-D time array.
        data : 2-D data array (N, C).
        column_labels : Column names (without 'time').
        header_meta : Dict of header key-value pairs.
        """
        header_meta: Dict[str, str] = {}
        header_done = False
        col_labels: List[str] = []
        rows: List[List[float]] = []

        with open(filepath, "r") as f:
            for line in f:
                line = line.strip()
                if not header_done:
                    if line == "endheader":
                        header_done = True
                        continue
                    if "=" in line:
                        key, val = line.split("=", 1)
                        header_meta[key.strip()] = val.strip()
                    continue

                if not col_labels:
                    col_labels = line.split("\t")
                    continue

                vals = [float(x) for x in line.split("\t")]
                rows.append(vals)

        arr = np.array(rows, dtype=np.float64)
        time_arr = arr[:, 0]
        data_arr = arr[:, 1:]
        labels = col_labels[1:]  # skip 'time'

        return time_arr, data_arr, labels, header_meta


# ===================================================================
# OpenSim .trc writer (marker tracking data)
# ===================================================================

class OpenSimTRC:
    """Write OpenSim Track Row Column (.trc) files for marker data.

    Used when IMU-derived positions or virtual markers need to be passed
    to OpenSim's Inverse Kinematics tool.

    TRC header format::

        PathFileType\t4\t(X/Y/Z)\t<filename>
        DataRate\tCameraRate\tNumFrames\tNumMarkers\tUnits\tOrigDataRate\t...
        <values>
        Frame#\tTime\t<Marker1>\t\t\t<Marker2>\t...
        \t\tX1\tY1\tZ1\tX2\tY2\tZ2\t...
        1\t0.000\t...
    """

    @staticmethod
    def write(filepath: str,
              time: np.ndarray,
              marker_data: Dict[str, np.ndarray],
              data_rate: float = 148.0,
              units: str = "mm") -> str:
        """Write a .trc file.

        Parameters
        ----------
        filepath : Output path.
        time : 1-D time array in seconds, shape (N,).
        marker_data : Dict mapping marker name → position array (N, 3).
        data_rate : Data rate in Hz.
        units : Position units ('mm' or 'm').

        Returns
        -------
        filepath : Written file path.
        """
        time = np.asarray(time, dtype=np.float64)
        n_frames = len(time)
        marker_names = list(marker_data.keys())
        n_markers = len(marker_names)

        os.makedirs(os.path.dirname(filepath) or ".", exist_ok=True)

        with open(filepath, "w", newline="\n") as f:
            # Line 1: file type identifier
            fname = os.path.basename(filepath)
            f.write(f"PathFileType\t4\t(X/Y/Z)\t{fname}\n")

            # Line 2: parameter names
            f.write("DataRate\tCameraRate\tNumFrames\tNumMarkers\t"
                    "Units\tOrigDataRate\tOrigDataStartFrame\tOrigNumFrames\n")

            # Line 3: parameter values
            f.write(f"{data_rate:.2f}\t{data_rate:.2f}\t{n_frames}\t"
                    f"{n_markers}\t{units}\t{data_rate:.2f}\t1\t{n_frames}\n")

            # Line 4: frame/time + marker labels (each occupies 3 columns)
            header_row = ["Frame#", "Time"]
            for mname in marker_names:
                header_row.extend([mname, "", ""])
            f.write("\t".join(header_row) + "\n")

            # Line 5: empty + XYZ sub-labels
            sub_row = ["", ""]
            for _ in marker_names:
                sub_row.extend(["X", "Y", "Z"])
            f.write("\t".join(sub_row) + "\n")

            # Blank line
            f.write("\n")

            # Data rows
            for i in range(n_frames):
                row = [str(i + 1), f"{time[i]:.6f}"]
                for mname in marker_names:
                    pos = marker_data[mname][i]
                    row.extend([f"{pos[0]:.6f}", f"{pos[1]:.6f}",
                                f"{pos[2]:.6f}"])
                f.write("\t".join(row) + "\n")

        return filepath


# ===================================================================
# OpenSim .mot writer (motion/forces file)
# ===================================================================

class OpenSimMOT:
    """Write OpenSim Motion (.mot) files for forces and generalized coords.

    The .mot format is identical to .sto but conventionally used for
    generalized coordinates and ground reaction forces.
    """

    @staticmethod
    def write(filepath: str,
              time: np.ndarray,
              data: np.ndarray,
              column_labels: List[str],
              name: str = "NeuralFlow",
              in_degrees: bool = True) -> str:
        """Write a .mot file (delegates to .sto writer with degree flag)."""
        return OpenSimSTO.write(
            filepath, time, data, column_labels,
            name=name, in_degrees=in_degrees,
        )


# ===================================================================
# OpenSenseRT exporter
# ===================================================================

class OpenSenseRTExporter:
    """Export IMU quaternion data in the exact format expected by OpenSenseRT.

    Generates:
      1. A ``.sto`` file with quaternion columns named
         ``<imu_label>_imu_q0``, ``<imu_label>_imu_q1``, etc.
      2. An OpenSenseRT Settings XML file mapping IMU labels to OpenSim
         body segments for the IMU Placer and IK tools.

    OpenSenseRT expects quaternions in (w, x, y, z) order mapped as
    (q0, q1, q2, q3) where q0 = w (scalar part).
    """

    @staticmethod
    def export_quaternion_sto(
        filepath: str,
        time: np.ndarray,
        imu_quaternions: Dict[str, np.ndarray],
        name: str = "NeuralFlow_IMU_Orientations",
    ) -> str:
        """Write IMU orientation data as an OpenSenseRT-compatible .sto.

        Parameters
        ----------
        filepath : Output .sto path.
        time : 1-D time in seconds, shape (N,).
        imu_quaternions : Dict mapping IMU label → quaternions (N, 4).
            Quaternion order is [w, x, y, z].

        Returns
        -------
        filepath : Written file path.
        """
        time = np.asarray(time, dtype=np.float64)
        n_rows = len(time)
        imu_labels = list(imu_quaternions.keys())

        # Build column labels: <label>_imu_q0, <label>_imu_q1, ...
        col_labels: List[str] = []
        for label in imu_labels:
            for qi in range(4):
                col_labels.append(f"{label}_imu_q{qi}")

        # Build data matrix
        data = np.empty((n_rows, len(col_labels)), dtype=np.float64)
        col_idx = 0
        for label in imu_labels:
            quats = np.asarray(imu_quaternions[label], dtype=np.float64)
            if quats.shape != (n_rows, 4):
                raise ValueError(
                    f"Quaternion array for '{label}' has shape {quats.shape}, "
                    f"expected ({n_rows}, 4)")
            data[:, col_idx:col_idx + 4] = quats
            col_idx += 4

        return OpenSimSTO.write(filepath, time, data, col_labels,
                                name=name, in_degrees=False)

    @staticmethod
    def export_settings_xml(
        filepath: str,
        imu_to_body_map: Dict[str, str],
        model_file: str = "model.osim",
        orientations_file: str = "imu_orientations.sto",
        sensor_to_opensim_rotation: str = "auto",
        base_imu_label: Optional[str] = None,
        base_heading_axis: str = "z",
        accuracy: float = 1e-5,
    ) -> str:
        """Generate an OpenSenseRT Settings XML file.

        Parameters
        ----------
        filepath : Output XML path.
        imu_to_body_map : Dict mapping IMU label → OpenSim body name.
            Example: ``{'pelvis_imu': 'pelvis', 'femur_r_imu': 'femur_r'}``
        model_file : Path to the OpenSim model (.osim) file.
        orientations_file : Path to the quaternion .sto file.
        sensor_to_opensim_rotation : Rotation from sensor frame to OpenSim
            frame. Use 'auto' for automatic detection.
        base_imu_label : Label of the IMU used as the heading reference.
        base_heading_axis : Axis of the base IMU that points in the heading
            direction.
        accuracy : IK solver accuracy.

        Returns
        -------
        filepath : Written file path.
        """
        os.makedirs(os.path.dirname(filepath) or ".", exist_ok=True)

        root = ET.Element("OpenSimDocument", Version="40000")
        tool = ET.SubElement(root, "IMUInverseKinematicsTool",
                             name="imu_ik_settings")

        # Model
        ET.SubElement(tool, "model_file").text = model_file

        # Orientations file
        ET.SubElement(tool, "orientations_file").text = orientations_file

        # Sensor to OpenSim rotation
        ET.SubElement(tool, "sensor_to_opensim_rotations").text = \
            sensor_to_opensim_rotation

        # Base IMU
        if base_imu_label:
            ET.SubElement(tool, "base_imu_label").text = base_imu_label
            ET.SubElement(tool, "base_heading_axis").text = base_heading_axis

        # Accuracy
        ET.SubElement(tool, "accuracy").text = str(accuracy)

        # IMU placer: sensor → body mapping
        placer = ET.SubElement(tool, "IMUPlacer", name="imu_placer")
        imu_map_elem = ET.SubElement(placer, "imu_to_body_map")
        for imu_label, body_name in imu_to_body_map.items():
            mapping = ET.SubElement(imu_map_elem, "IMUBodyAssociation")
            ET.SubElement(mapping, "imu_name").text = imu_label
            ET.SubElement(mapping, "body_name").text = body_name

        # Pretty-print
        xml_str = minidom.parseString(
            ET.tostring(root, encoding="unicode")
        ).toprettyxml(indent="  ")

        # Remove extra XML declaration
        lines = xml_str.split("\n")
        if lines[0].startswith("<?xml"):
            xml_str = "\n".join(lines[1:])

        with open(filepath, "w", newline="\n") as f:
            f.write('<?xml version="1.0" encoding="UTF-8" ?>\n')
            f.write(xml_str)

        return filepath

    @staticmethod
    def export_from_orchestrator(
        data: Dict[str, Any],
        output_dir: str,
        imu_to_body_map: Optional[Dict[str, str]] = None,
        model_file: str = "model.osim",
        prefix: str = "neuralflow",
        imu_sample_rate: float = 148.0,
    ) -> Dict[str, str]:
        """High-level export from Orchestrator data dict.

        Automatically maps sensor labels to IMU names and generates
        both the .sto and settings XML.

        Parameters
        ----------
        data : Dict from ``Orchestrator.collect_all_data()``.
        output_dir : Output directory.
        imu_to_body_map : Optional explicit mapping. If None, uses sensor
            labels as both IMU labels and body names.
        model_file : Path to .osim model file.
        prefix : Filename prefix.
        imu_sample_rate : IMU sample rate (Hz).

        Returns
        -------
        paths : Dict with keys 'sto' and 'xml'.
        """
        os.makedirs(output_dir, exist_ok=True)

        # Collect all IMU quaternion data keyed by label
        imu_quats: Dict[str, np.ndarray] = {}
        first_timestamps: Optional[np.ndarray] = None

        for key, value in data.items():
            if not isinstance(value, dict):
                continue
            if "imu_quaternions" not in value:
                continue

            label = value.get("label", f"sensor_{key}")
            imu_quats[label] = np.asarray(value["imu_quaternions"])

            if first_timestamps is None and "imu_timestamps_us" in value:
                first_timestamps = np.asarray(value["imu_timestamps_us"])

        if not imu_quats:
            raise ValueError("No IMU quaternion data found in the data dict.")

        # Build time axis in seconds
        n_samples = next(iter(imu_quats.values())).shape[0]
        if first_timestamps is not None:
            time_s = (first_timestamps - first_timestamps[0]) / 1e6
        else:
            time_s = np.arange(n_samples) / imu_sample_rate

        # Normalise array lengths across sensors
        min_len = min(q.shape[0] for q in imu_quats.values())
        min_len = min(min_len, len(time_s))
        time_s = time_s[:min_len]
        for label in imu_quats:
            imu_quats[label] = imu_quats[label][:min_len]

        # Export .sto
        sto_path = os.path.join(output_dir, f"{prefix}_opensensert.sto")
        OpenSenseRTExporter.export_quaternion_sto(
            sto_path, time_s, imu_quats)

        # Build imu_to_body map if not provided
        if imu_to_body_map is None:
            imu_to_body_map = {label: label for label in imu_quats}

        # Export settings XML
        xml_path = os.path.join(output_dir, f"{prefix}_opensensert_settings.xml")
        OpenSenseRTExporter.export_settings_xml(
            xml_path,
            imu_to_body_map=imu_to_body_map,
            model_file=model_file,
            orientations_file=os.path.basename(sto_path),
        )

        return {"sto": sto_path, "xml": xml_path}


# ===================================================================
# CEINMS-RT exporter
# ===================================================================

class CEINMSRTExporter:
    """Export EMG data in the exact format expected by CEINMS-RT.

    CEINMS-RT uses the OpenSim .sto format with amplitude-normalised EMG
    linear envelopes.  Each column represents one muscle's excitation
    signal (0.0–1.0 range after MVC normalisation).

    Generates:
      1. An EMG ``.sto`` file with muscle excitation columns.
      2. A CEINMS-RT trial configuration XML mapping EMG columns to muscles.
    """

    @staticmethod
    def export_emg_sto(
        filepath: str,
        time: np.ndarray,
        emg_channels: Dict[str, np.ndarray],
        name: str = "NeuralFlow_EMG_Excitations",
    ) -> str:
        """Write processed EMG as a CEINMS-RT-compatible .sto.

        Parameters
        ----------
        filepath : Output .sto path.
        time : 1-D time in seconds, shape (N,).
        emg_channels : Dict mapping muscle name → normalised EMG (N,).
            Values should be in 0.0–1.0 range (MVC-normalised excitations).

        Returns
        -------
        filepath : Written file path.
        """
        time = np.asarray(time, dtype=np.float64)
        n_rows = len(time)
        muscle_names = list(emg_channels.keys())

        data = np.empty((n_rows, len(muscle_names)), dtype=np.float64)
        for i, name_key in enumerate(muscle_names):
            ch = np.asarray(emg_channels[name_key], dtype=np.float64)
            if len(ch) != n_rows:
                raise ValueError(
                    f"EMG channel '{name_key}' has length {len(ch)}, "
                    f"expected {n_rows}")
            # Clamp to [0, 1] — CEINMS-RT expects normalised excitations
            data[:, i] = np.clip(ch, 0.0, 1.0)

        return OpenSimSTO.write(filepath, time, data, muscle_names,
                                name=name, in_degrees=False)

    @staticmethod
    def export_trial_xml(
        filepath: str,
        emg_file: str,
        emg_to_muscle_map: Dict[str, List[str]],
        trial_name: str = "neuralflow_trial",
    ) -> str:
        """Generate a CEINMS-RT trial configuration XML.

        Parameters
        ----------
        filepath : Output XML path.
        emg_file : Path to the EMG .sto file.
        emg_to_muscle_map : Dict mapping EMG column name → list of
            OpenSim muscle names that this EMG channel drives.
            Example: ``{'biceps': ['biceps_brachii_long', 'biceps_brachii_short']}``
        trial_name : Trial identifier.

        Returns
        -------
        filepath : Written file path.
        """
        os.makedirs(os.path.dirname(filepath) or ".", exist_ok=True)

        root = ET.Element("ceinms-rt-trial")
        root.set("name", trial_name)

        # EMG data file reference
        emg_elem = ET.SubElement(root, "emg_data")
        ET.SubElement(emg_elem, "file").text = emg_file

        # EMG-to-muscle mapping
        mappings = ET.SubElement(root, "emg_to_muscle_mapping")
        for emg_name, muscles in emg_to_muscle_map.items():
            ch_elem = ET.SubElement(mappings, "emg_channel")
            ET.SubElement(ch_elem, "name").text = emg_name
            muscles_elem = ET.SubElement(ch_elem, "muscles")
            for muscle in muscles:
                ET.SubElement(muscles_elem, "muscle").text = muscle

        # Pretty-print
        xml_str = minidom.parseString(
            ET.tostring(root, encoding="unicode")
        ).toprettyxml(indent="  ")
        lines = xml_str.split("\n")
        if lines[0].startswith("<?xml"):
            xml_str = "\n".join(lines[1:])

        with open(filepath, "w", newline="\n") as f:
            f.write('<?xml version="1.0" encoding="UTF-8" ?>\n')
            f.write(xml_str)

        return filepath

    @staticmethod
    def export_from_orchestrator(
        data: Dict[str, Any],
        output_dir: str,
        mvc_values: Optional[Dict[str, float]] = None,
        emg_to_muscle_map: Optional[Dict[str, List[str]]] = None,
        prefix: str = "neuralflow",
        emg_sample_rate: float = 2000.0,
        rectify: bool = True,
        lowpass_cutoff_hz: float = 6.0,
    ) -> Dict[str, str]:
        """High-level export from Orchestrator data dict.

        Automatically processes raw filtered EMG into amplitude-normalised
        linear envelopes suitable for CEINMS-RT.

        Processing pipeline:
          1. Full-wave rectification (abs)
          2. Low-pass filter (moving average at *lowpass_cutoff_hz*)
          3. MVC normalisation (divide by mvc_values, clamp to [0, 1])

        Parameters
        ----------
        data : Dict from ``Orchestrator.collect_all_data()``.
        output_dir : Output directory.
        mvc_values : Dict mapping sensor label → MVC amplitude.
            If None, each channel is normalised by its own peak.
        emg_to_muscle_map : Dict for CEINMS-RT XML. If None, maps each
            label to itself.
        prefix : Filename prefix.
        emg_sample_rate : EMG sample rate (Hz).
        rectify : Whether to full-wave rectify.
        lowpass_cutoff_hz : Cutoff for the linear envelope smoother (Hz).

        Returns
        -------
        paths : Dict with keys 'sto' and 'xml'.
        """
        os.makedirs(output_dir, exist_ok=True)

        # Collect EMG channels
        emg_channels_raw: Dict[str, np.ndarray] = {}
        first_timestamps: Optional[np.ndarray] = None

        for key, value in data.items():
            if not isinstance(value, dict):
                continue
            if "emg_filtered" not in value:
                continue

            label = value.get("label", f"sensor_{key}")
            emg_channels_raw[label] = np.asarray(value["emg_filtered"],
                                                  dtype=np.float64)
            if first_timestamps is None and "emg_timestamps_us" in value:
                first_timestamps = np.asarray(value["emg_timestamps_us"])

        if not emg_channels_raw:
            raise ValueError("No EMG data found in the data dict.")

        # Normalise lengths
        min_len = min(len(v) for v in emg_channels_raw.values())
        if first_timestamps is not None:
            min_len = min(min_len, len(first_timestamps))
            time_s = (first_timestamps[:min_len] -
                      first_timestamps[0]) / 1e6
        else:
            time_s = np.arange(min_len) / emg_sample_rate

        # Process each channel into a linear envelope
        envelope_window = max(1, int(emg_sample_rate / max(lowpass_cutoff_hz, 0.1)))
        emg_envelopes: Dict[str, np.ndarray] = {}

        for label, raw in emg_channels_raw.items():
            sig = raw[:min_len].copy()

            # 1. Full-wave rectification
            if rectify:
                sig = np.abs(sig)

            # 2. Low-pass smoothing (moving average)
            kernel = np.ones(envelope_window) / envelope_window
            sig = np.convolve(sig, kernel, mode="same")

            # 3. MVC normalisation
            if mvc_values is not None and label in mvc_values:
                mvc = mvc_values[label]
            else:
                mvc = np.max(sig) if np.max(sig) > 1e-12 else 1.0

            sig = sig / mvc
            sig = np.clip(sig, 0.0, 1.0)

            emg_envelopes[label] = sig

        # Export .sto
        sto_path = os.path.join(output_dir, f"{prefix}_ceinmsrt_emg.sto")
        CEINMSRTExporter.export_emg_sto(
            sto_path, time_s, emg_envelopes)

        # Build muscle map if not provided
        if emg_to_muscle_map is None:
            emg_to_muscle_map = {label: [label] for label in emg_envelopes}

        # Export trial XML
        xml_path = os.path.join(output_dir, f"{prefix}_ceinmsrt_trial.xml")
        CEINMSRTExporter.export_trial_xml(
            xml_path,
            emg_file=os.path.basename(sto_path),
            emg_to_muscle_map=emg_to_muscle_map,
        )

        return {"sto": sto_path, "xml": xml_path}


# ===================================================================
# Unified OpenSim export manager
# ===================================================================

class OpenSimExportManager:
    """One-call export for all OpenSim-compatible formats.

    Generates OpenSenseRT + CEINMS-RT files from Orchestrator data.
    """

    @staticmethod
    def export_all(
        data: Dict[str, Any],
        output_dir: str,
        prefix: str = "neuralflow",
        model_file: str = "model.osim",
        imu_to_body_map: Optional[Dict[str, str]] = None,
        mvc_values: Optional[Dict[str, float]] = None,
        emg_to_muscle_map: Optional[Dict[str, List[str]]] = None,
        imu_sample_rate: float = 148.0,
        emg_sample_rate: float = 2000.0,
    ) -> Dict[str, Any]:
        """Export data for OpenSenseRT and CEINMS-RT.

        Parameters
        ----------
        data : Dict from ``Orchestrator.collect_all_data()``.
        output_dir : Root output directory.
        prefix : Filename prefix.
        model_file : Path to the OpenSim model.
        imu_to_body_map : IMU label → OpenSim body mapping.
        mvc_values : Sensor label → MVC amplitude for EMG normalisation.
        emg_to_muscle_map : EMG channel → muscle list for CEINMS-RT.
        imu_sample_rate : IMU sample rate (Hz).
        emg_sample_rate : EMG sample rate (Hz).

        Returns
        -------
        result : Dict with keys ``'opensensert'`` and ``'ceinmsrt'``,
                 each containing sub-dicts with ``'sto'`` and ``'xml'`` paths.
        """
        os.makedirs(output_dir, exist_ok=True)
        result: Dict[str, Any] = {}

        # Check if IMU data is present
        has_imu = any(
            isinstance(v, dict) and "imu_quaternions" in v
            for v in data.values()
        )
        if has_imu:
            opensensert_dir = os.path.join(output_dir, "opensensert")
            result["opensensert"] = OpenSenseRTExporter.export_from_orchestrator(
                data, opensensert_dir,
                imu_to_body_map=imu_to_body_map,
                model_file=model_file,
                prefix=prefix,
                imu_sample_rate=imu_sample_rate,
            )

        # Check if EMG data is present
        has_emg = any(
            isinstance(v, dict) and "emg_filtered" in v
            for v in data.values()
        )
        if has_emg:
            ceinmsrt_dir = os.path.join(output_dir, "ceinmsrt")
            result["ceinmsrt"] = CEINMSRTExporter.export_from_orchestrator(
                data, ceinmsrt_dir,
                mvc_values=mvc_values,
                emg_to_muscle_map=emg_to_muscle_map,
                prefix=prefix,
                emg_sample_rate=emg_sample_rate,
            )

        return result
