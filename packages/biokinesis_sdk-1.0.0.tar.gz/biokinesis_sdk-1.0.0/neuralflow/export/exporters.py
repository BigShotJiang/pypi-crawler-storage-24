"""
NeuralFlow SDK — Export layer.

Exporters for CSV, HDF5, MATLAB .mat, and Lab Streaming Layer (LSL).
"""

from __future__ import annotations

import csv
import json
import os
import time
from typing import Any, Dict, List, Optional, Sequence

import numpy as np


# ===================================================================
# CSV Exporter
# ===================================================================

class CSVExporter:
    """Export sensor data to per-sensor CSV files with metadata header.

    Each CSV file contains a comment header (lines starting with ``#``)
    followed by a standard comma-separated table.
    """

    @staticmethod
    def export(data: Dict[str, Any], output_dir: str,
               prefix: str = "neuralflow") -> List[str]:
        """Export collected data to CSV files.

        Parameters
        ----------
        data : Dict from ``Orchestrator.collect_all_data()``.
        output_dir : Directory to write CSV files.
        prefix : Filename prefix.

        Returns
        -------
        paths : List of written file paths.
        """
        os.makedirs(output_dir, exist_ok=True)
        paths = []

        for key, value in data.items():
            if key == "trigger_events":
                path = os.path.join(output_dir, f"{prefix}_triggers.csv")
                CSVExporter._write_trigger_csv(value, path)
                paths.append(path)
                continue

            if not isinstance(value, dict):
                continue

            sensor_id = key
            label = value.get("label", f"sensor_{sensor_id}")

            # EMG CSV
            if "emg_filtered" in value:
                path = os.path.join(output_dir,
                                    f"{prefix}_emg_sensor{sensor_id}.csv")
                emg = value["emg_filtered"]
                ts = value.get("emg_timestamps_us", np.arange(len(emg)))
                CSVExporter._write_signal_csv(
                    path, ts, emg,
                    header_meta={"sensor_id": sensor_id, "label": label,
                                 "signal": "emg_filtered", "unit": "uV"},
                    columns=["timestamp_us", "emg_uV"],
                )
                paths.append(path)

            # IMU CSV
            if "imu_quaternions" in value:
                path = os.path.join(output_dir,
                                    f"{prefix}_imu_sensor{sensor_id}.csv")
                quats = value["imu_quaternions"]
                euler = value.get("imu_euler", np.zeros((len(quats), 3)))
                ts = value.get("imu_timestamps_us", np.arange(len(quats)))
                CSVExporter._write_imu_csv(path, ts, quats, euler,
                                           sensor_id, label)
                paths.append(path)

        return paths

    @staticmethod
    def _write_signal_csv(path: str, timestamps: np.ndarray,
                          signal: np.ndarray, header_meta: dict,
                          columns: list):
        with open(path, "w", newline="") as f:
            # Metadata header
            f.write(f"# NeuralFlow Export\n")
            for k, v in header_meta.items():
                f.write(f"# {k}: {v}\n")
            f.write(f"# exported_at: {time.strftime('%Y-%m-%dT%H:%M:%S')}\n")

            writer = csv.writer(f)
            writer.writerow(columns)
            for i in range(len(signal)):
                writer.writerow([f"{timestamps[i]:.1f}", f"{signal[i]:.6f}"])

    @staticmethod
    def _write_imu_csv(path: str, timestamps: np.ndarray,
                       quats: np.ndarray, euler: np.ndarray,
                       sensor_id: str, label: str):
        with open(path, "w", newline="") as f:
            f.write(f"# NeuralFlow IMU Export\n")
            f.write(f"# sensor_id: {sensor_id}\n")
            f.write(f"# label: {label}\n")
            f.write(f"# exported_at: {time.strftime('%Y-%m-%dT%H:%M:%S')}\n")

            writer = csv.writer(f)
            writer.writerow(["timestamp_us", "qw", "qx", "qy", "qz",
                              "roll_rad", "pitch_rad", "yaw_rad"])
            for i in range(len(quats)):
                row = [f"{timestamps[i]:.1f}"]
                row += [f"{quats[i, j]:.8f}" for j in range(4)]
                row += [f"{euler[i, j]:.8f}" for j in range(3)]
                writer.writerow(row)

    @staticmethod
    def _write_trigger_csv(events: list, path: str):
        with open(path, "w", newline="") as f:
            f.write("# NeuralFlow Trigger Events\n")
            writer = csv.writer(f)
            writer.writerow(["timestamp_us", "edge", "channel", "label"])
            for e in events:
                writer.writerow([e["timestamp_us"], e["edge"],
                                 e["channel"], e["label"]])


# ===================================================================
# HDF5 Exporter
# ===================================================================

class HDF5Exporter:
    """Export sensor data to a single HDF5 file with hierarchical groups.

    Structure::

        /sensor_1/emg_filtered
        /sensor_1/emg_timestamps_us
        /sensor_1/imu_quaternions
        /sensor_1/imu_euler
        /sensor_1/imu_timestamps_us
        /trigger_events/timestamps_us
        /trigger_events/edges
        ...
    """

    @staticmethod
    def export(data: Dict[str, Any], filepath: str,
               compression: str = "gzip",
               compression_opts: int = 4) -> str:
        """Export data to HDF5.

        Parameters
        ----------
        data : Dict from ``Orchestrator.collect_all_data()``.
        filepath : Output .h5 file path.
        compression : HDF5 compression filter.
        compression_opts : Compression level (1–9).

        Returns
        -------
        filepath : Written file path.
        """
        import h5py

        os.makedirs(os.path.dirname(filepath) or ".", exist_ok=True)

        with h5py.File(filepath, "w") as f:
            # Root attributes
            f.attrs["format"] = "NeuralFlow HDF5"
            f.attrs["version"] = "1.0.0"
            f.attrs["exported_at"] = time.strftime("%Y-%m-%dT%H:%M:%S")

            for key, value in data.items():
                if key == "trigger_events":
                    tg = f.create_group("trigger_events")
                    ts = [e["timestamp_us"] for e in value]
                    tg.create_dataset("timestamps_us", data=np.array(ts),
                                      compression=compression,
                                      compression_opts=compression_opts)
                    edges = [e["edge"] for e in value]
                    tg.create_dataset("edges",
                                      data=np.array(edges, dtype="S10"))
                    channels = [e["channel"] for e in value]
                    tg.create_dataset("channels", data=np.array(channels))
                    continue

                if not isinstance(value, dict):
                    continue

                grp = f.create_group(f"sensor_{key}")
                grp.attrs["label"] = value.get("label", "")

                for dset_name in ("emg_filtered", "emg_timestamps_us",
                                  "imu_quaternions", "imu_euler",
                                  "imu_timestamps_us"):
                    if dset_name in value:
                        arr = np.asarray(value[dset_name])
                        grp.create_dataset(
                            dset_name, data=arr,
                            chunks=True,
                            compression=compression,
                            compression_opts=compression_opts,
                        )

        return filepath


# ===================================================================
# LSL Exporter
# ===================================================================

class LSLExporter:
    """Lab Streaming Layer (LSL) outlet for real-time streaming.

    Creates separate outlets for EMG and IMU data so that downstream
    consumers (e.g. BCI2000, OpenViBE, LabRecorder) can subscribe.
    """

    def __init__(self, name: str = "NeuralFlow",
                 emg_channels: int = 1, imu_channels: int = 10,
                 emg_rate: float = 2000.0, imu_rate: float = 148.0):
        """Initialise LSL outlets.

        Parameters
        ----------
        name : Stream name prefix.
        emg_channels : Number of EMG channels (sensor count).
        imu_channels : Number of IMU channels per sensor
                       (default 10 = 4 quat + 3 accel + 3 gyro).
        emg_rate : EMG nominal sample rate.
        imu_rate : IMU nominal sample rate.
        """
        from pylsl import StreamInfo, StreamOutlet

        # EMG outlet
        emg_info = StreamInfo(
            name=f"{name}_EMG", type="EMG",
            channel_count=emg_channels,
            nominal_srate=emg_rate,
            channel_format="float32",
            source_id=f"{name}_emg_src",
        )
        self._emg_outlet = StreamOutlet(emg_info)

        # IMU outlet
        imu_info = StreamInfo(
            name=f"{name}_IMU", type="IMU",
            channel_count=imu_channels,
            nominal_srate=imu_rate,
            channel_format="float32",
            source_id=f"{name}_imu_src",
        )
        self._imu_outlet = StreamOutlet(imu_info)

    def push_emg(self, sample: Sequence[float],
                 timestamp: Optional[float] = None):
        """Push a single EMG sample (one value per sensor)."""
        self._emg_outlet.push_sample(list(sample),
                                     timestamp if timestamp else 0.0)

    def push_imu(self, sample: Sequence[float],
                 timestamp: Optional[float] = None):
        """Push a single IMU sample."""
        self._imu_outlet.push_sample(list(sample),
                                     timestamp if timestamp else 0.0)

    def push_emg_chunk(self, chunk: np.ndarray,
                       timestamps: Optional[np.ndarray] = None):
        """Push a chunk of EMG samples, shape (N, n_channels)."""
        chunk = np.asarray(chunk, dtype=np.float32)
        if chunk.ndim == 1:
            chunk = chunk[:, None]
        ts_list = timestamps.tolist() if timestamps is not None else [0.0] * len(chunk)
        self._emg_outlet.push_chunk(chunk.tolist(), ts_list)

    def push_imu_chunk(self, chunk: np.ndarray,
                       timestamps: Optional[np.ndarray] = None):
        """Push a chunk of IMU samples, shape (N, n_channels)."""
        chunk = np.asarray(chunk, dtype=np.float32)
        ts_list = timestamps.tolist() if timestamps is not None else [0.0] * len(chunk)
        self._imu_outlet.push_chunk(chunk.tolist(), ts_list)


# ===================================================================
# MATLAB .mat Exporter
# ===================================================================

class MATExporter:
    """Export sensor data to MATLAB .mat file via ``scipy.io.savemat``."""

    @staticmethod
    def export(data: Dict[str, Any], filepath: str) -> str:
        """Export to .mat.

        The dict is flattened so that MATLAB struct field names are valid:
        ``sensor_1_emg_filtered``, ``sensor_1_imu_quaternions``, etc.

        Parameters
        ----------
        data : Dict from ``Orchestrator.collect_all_data()``.
        filepath : Output .mat file path.

        Returns
        -------
        filepath : Written file path.
        """
        from scipy.io import savemat

        os.makedirs(os.path.dirname(filepath) or ".", exist_ok=True)

        mat_dict: Dict[str, Any] = {}
        for key, value in data.items():
            if key == "trigger_events":
                ts = np.array([e["timestamp_us"] for e in value])
                mat_dict["trigger_timestamps_us"] = ts
                mat_dict["trigger_channels"] = np.array(
                    [e["channel"] for e in value])
                continue

            if not isinstance(value, dict):
                continue

            prefix = f"sensor_{key}"
            for dset_name in ("emg_filtered", "emg_timestamps_us",
                              "imu_quaternions", "imu_euler",
                              "imu_timestamps_us"):
                if dset_name in value:
                    mat_key = f"{prefix}_{dset_name}"
                    mat_dict[mat_key] = np.asarray(value[dset_name])

            if "label" in value:
                mat_dict[f"{prefix}_label"] = value["label"]

        mat_dict["neuralflow_version"] = "1.0.0"
        savemat(filepath, mat_dict, do_compression=True)
        return filepath


# ===================================================================
# Unified export manager
# ===================================================================

class ExportManager:
    """Unified interface to export to one or more formats simultaneously."""

    @staticmethod
    def export_all(data: Dict[str, Any], output_dir: str,
                   prefix: str = "neuralflow",
                   formats: Optional[List[str]] = None,
                   **opensim_kwargs) -> Dict[str, Any]:
        """Export data to all requested formats.

        Parameters
        ----------
        data : Dict from ``Orchestrator.collect_all_data()``.
        output_dir : Root output directory.
        prefix : Filename prefix.
        formats : List of format strings: ``'csv'``, ``'hdf5'``, ``'mat'``,
                  ``'opensensert'``, ``'ceinmsrt'``, ``'opensim'`` (all OpenSim).
                  Defaults to ``['csv', 'hdf5', 'mat']``.
        **opensim_kwargs : Passed to ``OpenSimExportManager.export_all``
            (e.g. ``model_file``, ``imu_to_body_map``, ``mvc_values``,
            ``emg_to_muscle_map``).

        Returns
        -------
        result : Dict mapping format → list of written paths.
        """
        if formats is None:
            formats = ["csv", "hdf5", "mat"]

        os.makedirs(output_dir, exist_ok=True)
        result: Dict[str, Any] = {}

        if "csv" in formats:
            csv_dir = os.path.join(output_dir, "csv")
            result["csv"] = CSVExporter.export(data, csv_dir, prefix)

        if "hdf5" in formats:
            h5_path = os.path.join(output_dir, f"{prefix}.h5")
            result["hdf5"] = HDF5Exporter.export(data, h5_path)

        if "mat" in formats:
            mat_path = os.path.join(output_dir, f"{prefix}.mat")
            result["mat"] = MATExporter.export(data, mat_path)

        # OpenSim formats
        opensim_requested = (
            "opensim" in formats or
            "opensensert" in formats or
            "ceinmsrt" in formats
        )
        if opensim_requested:
            from .opensim import OpenSimExportManager
            osim_dir = os.path.join(output_dir, "opensim")
            result["opensim"] = OpenSimExportManager.export_all(
                data, osim_dir, prefix=prefix, **opensim_kwargs)

        return result
