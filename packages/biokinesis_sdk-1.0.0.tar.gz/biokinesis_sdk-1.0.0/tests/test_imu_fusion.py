"""Tests for IMU fusion — Quaternion algebra and Madgwick AHRS."""

import math
import numpy as np
import pytest

from neuralflow.imu.fusion import Quaternion, MadgwickAHRS
from neuralflow.imu.kinematics import quaternion_to_euler, euler_to_quaternion


class TestQuaternion:
    def test_identity(self):
        q = Quaternion.identity()
        assert q.w == 1.0 and q.x == 0.0 and q.y == 0.0 and q.z == 0.0

    def test_multiply_identity(self):
        q = Quaternion(0.5, 0.5, 0.5, 0.5)
        result = q * Quaternion.identity()
        assert np.allclose(result.to_array(), q.to_array(), atol=1e-12)

    def test_multiply_inverse_gives_identity(self):
        q = Quaternion(0.5, 0.5, 0.5, 0.5)
        result = q * q.inverse()
        np.testing.assert_allclose(result.to_array(), [1, 0, 0, 0], atol=1e-10)

    def test_conjugate(self):
        q = Quaternion(1, 2, 3, 4)
        c = q.conjugate()
        assert c.w == 1 and c.x == -2 and c.y == -3 and c.z == -4

    def test_normalize(self):
        q = Quaternion(1, 1, 1, 1).normalize()
        assert abs(q.norm() - 1.0) < 1e-12

    def test_rotate_vector_identity(self):
        q = Quaternion.identity()
        v = np.array([1.0, 2.0, 3.0])
        rotated = q.rotate_vector(v)
        np.testing.assert_allclose(rotated, v, atol=1e-12)

    def test_rotate_90_deg_z(self):
        """Rotating [1,0,0] by 90° around Z should give [0,1,0]."""
        q = Quaternion.from_axis_angle([0, 0, 1], math.pi / 2)
        v = q.rotate_vector([1, 0, 0])
        np.testing.assert_allclose(v, [0, 1, 0], atol=1e-10)


class TestEulerConversion:
    def test_identity_euler(self):
        q = Quaternion.identity()
        r, p, y = quaternion_to_euler(q)
        assert abs(r) < 1e-10 and abs(p) < 1e-10 and abs(y) < 1e-10

    def test_roundtrip(self):
        """Euler → Quaternion → Euler should preserve angles."""
        roll, pitch, yaw = 0.3, 0.5, -0.7
        q = euler_to_quaternion(roll, pitch, yaw)
        r2, p2, y2 = quaternion_to_euler(q)
        assert abs(r2 - roll) < 1e-10
        assert abs(p2 - pitch) < 1e-10
        assert abs(y2 - yaw) < 1e-10


class TestMadgwick:
    def test_stationary_converges_to_gravity(self):
        """With stationary data (only gravity on Z), the filter should
        converge so that the estimated gravity direction is ≈ [0, 0, 1]."""
        ahrs = MadgwickAHRS(sample_rate=148.0, beta=0.5)
        gyro = np.zeros(3)
        accel = np.array([0.0, 0.0, 9.81])

        for _ in range(500):
            ahrs.update_imu(gyro, accel)

        # The estimated gravity in the sensor frame should point along Z
        g_est = ahrs.quaternion.rotate_vector([0, 0, 9.81])
        # This should be close to [0, 0, 9.81] (identity orientation)
        np.testing.assert_allclose(g_est, [0, 0, 9.81], atol=0.5)

    def test_batch_output_shape(self):
        N = 100
        gyro = np.zeros((N, 3))
        accel = np.tile([0, 0, 9.81], (N, 1))
        ahrs = MadgwickAHRS(sample_rate=148.0)
        quats = ahrs.process(gyro, accel)
        assert quats.shape == (N, 4)
