"""Tests for EMG feature extraction functions."""

import math
import numpy as np
import pytest

from neuralflow.emg.features import (
    rms_envelope, mean_absolute_value, zero_crossing_rate,
    integrated_emg, median_frequency, mean_frequency, waveform_length,
)


FS = 2000.0


class TestRMS:
    def test_constant_signal(self):
        """RMS of a constant should equal abs(constant)."""
        sig = np.full(1000, 3.0)
        rms = rms_envelope(sig, window_samples=100)
        assert np.allclose(rms, 3.0, atol=1e-10)

    def test_sine_rms(self):
        """RMS of sin = 1/sqrt(2) ≈ 0.7071."""
        t = np.arange(10000) / FS
        sig = np.sin(2 * np.pi * 100 * t)
        rms = rms_envelope(sig, window_samples=2000)
        assert np.allclose(rms, 1.0 / math.sqrt(2), atol=0.05)


class TestMAV:
    def test_positive_signal(self):
        sig = np.full(1000, 5.0)
        mav = mean_absolute_value(sig)
        assert np.isclose(mav[0], 5.0)

    def test_alternating(self):
        sig = np.array([1.0, -1.0] * 500)
        mav = mean_absolute_value(sig)
        assert np.isclose(mav[0], 1.0)


class TestZCR:
    def test_pure_sine(self):
        """A 100 Hz sine at 2000 Hz should cross zero ~100 times/s."""
        t = np.arange(2000) / FS
        sig = np.sin(2 * np.pi * 100 * t)
        zcr = zero_crossing_rate(sig)
        # ZCR = crossings/N, expect ~200 crossings in 2000 samples
        assert 0.05 < zcr[0] < 0.15

    def test_constant_zero_crossings(self):
        sig = np.ones(1000)
        zcr = zero_crossing_rate(sig)
        assert zcr[0] == 0.0


class TestIEMG:
    def test_positive(self):
        sig = np.ones(100) * 2.0
        iemg = integrated_emg(sig)
        assert np.isclose(iemg[0], 200.0)


class TestFrequencyFeatures:
    def test_single_tone_median_freq(self):
        """Median frequency of a pure 200 Hz tone should be ≈ 200 Hz."""
        t = np.arange(4000) / FS
        sig = np.sin(2 * np.pi * 200 * t)
        mdf = median_frequency(sig, FS)
        assert abs(mdf - 200.0) < 20.0, f"MDF={mdf}"

    def test_single_tone_mean_freq(self):
        """Mean frequency of a pure 200 Hz tone should be ≈ 200 Hz."""
        t = np.arange(4000) / FS
        sig = np.sin(2 * np.pi * 200 * t)
        mnf = mean_frequency(sig, FS)
        assert abs(mnf - 200.0) < 20.0, f"MNF={mnf}"


class TestWaveformLength:
    def test_constant(self):
        sig = np.ones(100)
        wl = waveform_length(sig)
        assert np.isclose(wl[0], 0.0)

    def test_alternating(self):
        sig = np.array([1.0, -1.0, 1.0, -1.0])
        wl = waveform_length(sig)
        assert np.isclose(wl[0], 6.0)
