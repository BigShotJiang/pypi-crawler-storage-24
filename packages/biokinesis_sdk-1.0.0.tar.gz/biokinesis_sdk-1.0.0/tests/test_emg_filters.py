"""Tests for EMG filters — Butterworth bandpass and notch filter."""

import math
import numpy as np
import pytest

from neuralflow.emg.filters import ButterworthBandpass, NotchFilter, EMGFilterChain
from neuralflow.core.types import FilterConfig


FS = 2000.0  # sampling rate


def _make_sinusoid(freq_hz: float, duration_s: float = 1.0,
                   amplitude: float = 1.0, fs: float = FS) -> np.ndarray:
    t = np.arange(int(fs * duration_s)) / fs
    return amplitude * np.sin(2 * np.pi * freq_hz * t)


class TestButterworthBandpass:
    """Verify the hand-coded Butterworth bandpass filter."""

    def test_passes_inband_signal(self):
        """A 100 Hz tone (within 20–450 Hz) should pass with high amplitude."""
        sig = _make_sinusoid(100.0, duration_s=2.0)
        bp = ButterworthBandpass(20, 450, FS, order=4)
        filtered = bp(sig)
        # After transient, amplitude should be close to 1.0
        rms_in = np.sqrt(np.mean(filtered[1000:] ** 2))
        assert rms_in > 0.5, f"In-band signal too attenuated: RMS={rms_in:.4f}"

    def test_attenuates_below_band(self):
        """A 5 Hz tone (below 20 Hz) should be heavily attenuated."""
        sig = _make_sinusoid(5.0, duration_s=2.0)
        bp = ButterworthBandpass(20, 450, FS, order=4)
        filtered = bp(sig)
        rms_out = np.sqrt(np.mean(filtered[1000:] ** 2))
        assert rms_out < 0.1, f"Below-band signal not attenuated: RMS={rms_out:.4f}"

    def test_attenuates_above_band(self):
        """A 800 Hz tone (above 450 Hz) should be heavily attenuated."""
        sig = _make_sinusoid(800.0, duration_s=2.0)
        bp = ButterworthBandpass(20, 450, FS, order=4)
        filtered = bp(sig)
        rms_out = np.sqrt(np.mean(filtered[1000:] ** 2))
        assert rms_out < 0.1, f"Above-band signal not attenuated: RMS={rms_out:.4f}"

    def test_wide_bandwidth(self):
        """10–850 Hz mode with fs=2000 should pass 600 Hz."""
        sig = _make_sinusoid(600.0, duration_s=2.0)
        bp = ButterworthBandpass(10, 850, FS, order=4)
        filtered = bp(sig)
        rms_in = np.sqrt(np.mean(filtered[1000:] ** 2))
        assert rms_in > 0.4, f"Wide-band 600 Hz too attenuated: RMS={rms_in:.4f}"

    def test_invalid_cutoffs_raise(self):
        with pytest.raises(ValueError):
            ButterworthBandpass(0, 450, FS)
        with pytest.raises(ValueError):
            ButterworthBandpass(450, 20, FS)
        with pytest.raises(ValueError):
            ButterworthBandpass(20, 1001, FS)


class TestNotchFilter:
    """Verify the IIR notch filter."""

    def test_attenuates_50hz(self):
        """A pure 50 Hz tone should be heavily attenuated."""
        sig = _make_sinusoid(50.0, duration_s=2.0)
        notch = NotchFilter(50.0, FS, q_factor=30.0)
        filtered = notch(sig)
        rms_out = np.sqrt(np.mean(filtered[500:] ** 2))
        assert rms_out < 0.15, f"50 Hz not attenuated: RMS={rms_out:.4f}"

    def test_passes_other_frequencies(self):
        """A 100 Hz signal should pass through a 50 Hz notch."""
        sig = _make_sinusoid(100.0, duration_s=2.0)
        notch = NotchFilter(50.0, FS, q_factor=30.0)
        filtered = notch(sig)
        rms_in = np.sqrt(np.mean(filtered[500:] ** 2))
        assert rms_in > 0.6, f"100 Hz attenuated by 50 Hz notch: RMS={rms_in:.4f}"

    def test_60hz_notch(self):
        sig = _make_sinusoid(60.0, duration_s=2.0)
        notch = NotchFilter(60.0, FS, q_factor=30.0)
        filtered = notch(sig)
        rms_out = np.sqrt(np.mean(filtered[500:] ** 2))
        assert rms_out < 0.15, f"60 Hz not attenuated: RMS={rms_out:.4f}"


class TestEMGFilterChain:
    """Test the combined bandpass → notch chain."""

    def test_chain_passes_clean_emg_band(self):
        """200 Hz signal through default chain should pass."""
        sig = _make_sinusoid(200.0, duration_s=2.0)
        chain = EMGFilterChain(FilterConfig.standard())
        filtered = chain(sig)
        rms_in = np.sqrt(np.mean(filtered[1000:] ** 2))
        assert rms_in > 0.4

    def test_chain_rejects_50hz(self):
        """50 Hz should be rejected by default chain."""
        sig = _make_sinusoid(50.0, duration_s=2.0)
        chain = EMGFilterChain(FilterConfig.standard())
        filtered = chain(sig)
        rms_out = np.sqrt(np.mean(filtered[1000:] ** 2))
        assert rms_out < 0.15
