"""Integration test — full pipeline through orchestrator → export."""

import os
import tempfile
import numpy as np
import pytest

from neuralflow.core.types import SensorConfig, FilterConfig, EMGFrame, IMUFrame
from neuralflow.orchestrator.manager import Orchestrator
from neuralflow.export.exporters import CSVExporter, HDF5Exporter, ExportManager


FS_EMG = 2000.0
FS_IMU = 148.0
DURATION_S = 2.0


def _synth_emg(n_samples: int, fs: float) -> np.ndarray:
    """Generate synthetic bipolar differential EMG (band-limited noise)."""
    t = np.arange(n_samples) / fs
    # Mix of sine waves simulating motor unit action potentials
    sig = (0.3 * np.sin(2 * np.pi * 80 * t) +
           0.2 * np.sin(2 * np.pi * 150 * t) +
           0.1 * np.sin(2 * np.pi * 300 * t) +
           0.05 * np.random.randn(n_samples))
    return sig * 500.0  # µV scale


def _synth_imu(n_samples: int) -> tuple:
    accel = np.tile([0.0, 0.0, 9.81], (n_samples, 1))
    accel += np.random.randn(n_samples, 3) * 0.05
    gyro = np.random.randn(n_samples, 3) * 0.01
    mag = np.tile([20.0, 0.0, 40.0], (n_samples, 1))
    return accel, gyro, mag


class TestFullPipeline:
    """End-to-end: create 4 sensors, ingest data, export."""

    def test_orchestrator_ingest_and_export_csv(self):
        orch = Orchestrator()

        n_sensors = 4
        for i in range(1, n_sensors + 1):
            orch.add_sensor(SensorConfig(
                sensor_id=i,
                label=f"muscle_{i}",
                filter_config=FilterConfig.standard(),
            ))

        # Ingest synthetic data
        n_emg = int(FS_EMG * DURATION_S)
        n_imu = int(FS_IMU * DURATION_S)

        for sid in orch.sensor_ids:
            emg_data = _synth_emg(n_emg, FS_EMG)
            ts_emg = np.arange(n_emg) * (1e6 / FS_EMG)
            orch.ingest_emg(sid, EMGFrame(
                sensor_id=sid, timestamps_us=ts_emg,
                data=emg_data, sample_rate=FS_EMG))

            accel, gyro, mag = _synth_imu(n_imu)
            ts_imu = np.arange(n_imu) * (1e6 / FS_IMU)
            orch.ingest_imu(sid, IMUFrame(
                sensor_id=sid, timestamps_us=ts_imu,
                accel=accel, gyro=gyro, mag=mag, sample_rate=FS_IMU))

        # Collect and export
        data = orch.collect_all_data()

        with tempfile.TemporaryDirectory() as tmpdir:
            paths = CSVExporter.export(data, tmpdir, prefix="test")
            assert len(paths) > 0
            for p in paths:
                assert os.path.isfile(p)
                assert os.path.getsize(p) > 0

    def test_hdf5_export(self):
        orch = Orchestrator()
        orch.add_sensor(SensorConfig(sensor_id=1, label="test"))

        n_emg = 2000
        ts = np.arange(n_emg) * (1e6 / FS_EMG)
        orch.ingest_emg(1, EMGFrame(
            sensor_id=1, timestamps_us=ts,
            data=_synth_emg(n_emg, FS_EMG), sample_rate=FS_EMG))

        data = orch.collect_all_data()

        with tempfile.TemporaryDirectory() as tmpdir:
            h5_path = os.path.join(tmpdir, "test.h5")
            HDF5Exporter.export(data, h5_path)
            assert os.path.isfile(h5_path)

            import h5py
            with h5py.File(h5_path, "r") as f:
                assert "sensor_1" in f
                assert "emg_filtered" in f["sensor_1"]

    def test_max_sensors_limit(self):
        orch = Orchestrator()
        for i in range(1, 17):
            orch.add_sensor(SensorConfig(sensor_id=i))
        assert orch.n_sensors == 16
        with pytest.raises(ValueError):
            orch.add_sensor(SensorConfig(sensor_id=17))

    def test_export_manager(self):
        orch = Orchestrator()
        orch.add_sensor(SensorConfig(sensor_id=1, label="biceps"))

        n_emg = 2000
        ts = np.arange(n_emg) * (1e6 / FS_EMG)
        orch.ingest_emg(1, EMGFrame(
            sensor_id=1, timestamps_us=ts,
            data=_synth_emg(n_emg, FS_EMG), sample_rate=FS_EMG))

        data = orch.collect_all_data()

        with tempfile.TemporaryDirectory() as tmpdir:
            result = ExportManager.export_all(
                data, tmpdir, prefix="full_test",
                formats=["csv", "hdf5", "mat"])

            assert "csv" in result
            assert "hdf5" in result
            assert "mat" in result
