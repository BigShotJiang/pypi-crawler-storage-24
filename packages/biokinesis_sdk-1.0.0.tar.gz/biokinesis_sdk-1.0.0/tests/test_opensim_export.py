"""Tests for OpenSim export — .sto, OpenSenseRT, and CEINMS-RT output."""

import os
import tempfile
import numpy as np
import pytest

from neuralflow.core.types import SensorConfig, FilterConfig, EMGFrame, IMUFrame
from neuralflow.orchestrator.manager import Orchestrator
from neuralflow.export.opensim import (
    OpenSimSTO, OpenSimTRC, OpenSimMOT,
    OpenSenseRTExporter, CEINMSRTExporter, OpenSimExportManager,
)


FS_EMG = 2000.0
FS_IMU = 148.0


def _make_orchestrator_data():
    """Create a full orchestrator data dict with 2 sensors."""
    orch = Orchestrator()
    for sid, label in [(1, "biceps"), (2, "triceps")]:
        orch.add_sensor(SensorConfig(
            sensor_id=sid, label=label,
            filter_config=FilterConfig.standard(),
        ))

    n_emg = 2000
    n_imu = 148

    for sid in [1, 2]:
        emg = np.sin(2 * np.pi * 100 * np.arange(n_emg) / FS_EMG) * 500
        ts_emg = np.arange(n_emg) * (1e6 / FS_EMG)
        orch.ingest_emg(sid, EMGFrame(
            sensor_id=sid, timestamps_us=ts_emg,
            data=emg, sample_rate=FS_EMG))

        accel = np.tile([0.0, 0.0, 9.81], (n_imu, 1))
        gyro = np.zeros((n_imu, 3))
        mag = np.tile([20.0, 0.0, 40.0], (n_imu, 1))
        ts_imu = np.arange(n_imu) * (1e6 / FS_IMU)
        orch.ingest_imu(sid, IMUFrame(
            sensor_id=sid, timestamps_us=ts_imu,
            accel=accel, gyro=gyro, mag=mag, sample_rate=FS_IMU))

    return orch.collect_all_data()


class TestOpenSimSTO:
    def test_write_and_read_roundtrip(self):
        """Write a .sto, read it back, verify contents match."""
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "test.sto")
            time = np.arange(100) * 0.01
            data = np.random.rand(100, 3)
            labels = ["col_a", "col_b", "col_c"]

            OpenSimSTO.write(path, time, data, labels, name="TestSTO")

            # Read back
            t2, d2, labels2, meta = OpenSimSTO.read(path)

            np.testing.assert_allclose(t2, time, atol=1e-6)
            np.testing.assert_allclose(d2, data, atol=1e-6)
            assert labels2 == labels
            assert meta["nRows"] == "100"
            assert meta["nColumns"] == "4"
            assert meta["version"] == "1"

    def test_header_format(self):
        """Verify the header follows OpenSim spec exactly."""
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "header_test.sto")
            time = np.array([0.0, 0.01])
            data = np.array([[1.0], [2.0]])
            OpenSimSTO.write(path, time, data, ["value"], name="HeaderTest")

            with open(path, "r") as f:
                lines = f.readlines()

            assert lines[0].strip() == "HeaderTest"
            assert lines[1].strip() == "version=1"
            assert lines[2].strip() == "nRows=2"
            assert lines[3].strip() == "nColumns=2"
            assert "inDegrees" in lines[4]
            assert lines[5].strip() == "endheader"
            assert lines[6].strip() == "time\tvalue"


class TestOpenSimTRC:
    def test_write_trc(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "markers.trc")
            time = np.arange(50) * (1.0 / 148.0)
            markers = {
                "ASIS_R": np.random.rand(50, 3) * 100,
                "ASIS_L": np.random.rand(50, 3) * 100,
            }
            OpenSimTRC.write(path, time, markers, data_rate=148.0, units="mm")

            assert os.path.isfile(path)
            with open(path, "r") as f:
                content = f.read()
            assert "PathFileType" in content
            assert "ASIS_R" in content
            assert "ASIS_L" in content


class TestOpenSenseRTExporter:
    def test_quaternion_sto_format(self):
        """Verify column naming: <label>_imu_q0, q1, q2, q3."""
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "imu.sto")
            time = np.arange(100) * (1.0 / 148.0)
            quats = {
                "pelvis": np.tile([1.0, 0.0, 0.0, 0.0], (100, 1)),
                "femur_r": np.tile([1.0, 0.0, 0.0, 0.0], (100, 1)),
            }
            OpenSenseRTExporter.export_quaternion_sto(path, time, quats)

            t, d, labels, meta = OpenSimSTO.read(path)
            assert "pelvis_imu_q0" in labels
            assert "pelvis_imu_q1" in labels
            assert "femur_r_imu_q3" in labels
            assert len(labels) == 8  # 2 IMUs × 4 quaternion components
            assert d.shape == (100, 8)

    def test_settings_xml(self):
        """Verify the settings XML is well-formed and contains mappings."""
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "settings.xml")
            OpenSenseRTExporter.export_settings_xml(
                path,
                imu_to_body_map={"pelvis_imu": "pelvis",
                                 "femur_r_imu": "femur_r"},
                model_file="gait_model.osim",
            )
            assert os.path.isfile(path)
            with open(path, "r") as f:
                content = f.read()
            assert "IMUInverseKinematicsTool" in content
            assert "pelvis_imu" in content
            assert "femur_r" in content
            assert "gait_model.osim" in content

    def test_export_from_orchestrator(self):
        data = _make_orchestrator_data()
        with tempfile.TemporaryDirectory() as tmpdir:
            result = OpenSenseRTExporter.export_from_orchestrator(
                data, tmpdir, prefix="test")
            assert os.path.isfile(result["sto"])
            assert os.path.isfile(result["xml"])


class TestCEINMSRTExporter:
    def test_emg_sto_values_clamped(self):
        """EMG values must be in [0.0, 1.0] for CEINMS-RT."""
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "emg.sto")
            time = np.arange(100) * 0.001
            channels = {
                "biceps": np.random.rand(100) * 0.8,
                "triceps": np.random.rand(100) * 0.5,
            }
            CEINMSRTExporter.export_emg_sto(path, time, channels)

            t, d, labels, meta = OpenSimSTO.read(path)
            assert labels == ["biceps", "triceps"]
            assert np.all(d >= 0.0) and np.all(d <= 1.0)

    def test_trial_xml(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "trial.xml")
            CEINMSRTExporter.export_trial_xml(
                path,
                emg_file="emg.sto",
                emg_to_muscle_map={
                    "biceps": ["biceps_brachii_long", "biceps_brachii_short"],
                    "triceps": ["triceps_brachii"],
                },
            )
            assert os.path.isfile(path)
            with open(path, "r") as f:
                content = f.read()
            assert "biceps_brachii_long" in content
            assert "triceps_brachii" in content
            assert "emg.sto" in content

    def test_export_from_orchestrator(self):
        data = _make_orchestrator_data()
        with tempfile.TemporaryDirectory() as tmpdir:
            result = CEINMSRTExporter.export_from_orchestrator(
                data, tmpdir, prefix="test")
            assert os.path.isfile(result["sto"])
            assert os.path.isfile(result["xml"])

            # Verify EMG values are normalised
            t, d, labels, _ = OpenSimSTO.read(result["sto"])
            assert np.all(d >= 0.0) and np.all(d <= 1.0)


class TestOpenSimExportManager:
    def test_full_export(self):
        """Export both OpenSenseRT and CEINMS-RT files."""
        data = _make_orchestrator_data()
        with tempfile.TemporaryDirectory() as tmpdir:
            result = OpenSimExportManager.export_all(data, tmpdir)

            assert "opensensert" in result
            assert "ceinmsrt" in result
            assert os.path.isfile(result["opensensert"]["sto"])
            assert os.path.isfile(result["opensensert"]["xml"])
            assert os.path.isfile(result["ceinmsrt"]["sto"])
            assert os.path.isfile(result["ceinmsrt"]["xml"])
