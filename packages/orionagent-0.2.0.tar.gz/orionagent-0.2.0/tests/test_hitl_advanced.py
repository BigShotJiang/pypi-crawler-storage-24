import unittest
from unittest.mock import patch, MagicMock
from orionagent.agents.manager import Manager
from orionagent.agents.base_agent import Agent
from orionagent.agents.hitl import HitlConfig

class TestAdvancedHITL(unittest.TestCase):
    def setUp(self):
        self.mock_model = MagicMock()
        self.mock_model.generate.return_value = "Mocked Response"
        self.mock_model.verbose = False
        self.mock_model.debug = False
        self.agent = Agent(name="TestAgent", role="Tester", model=self.mock_model)

    @patch('builtins.input', return_value='y')
    def test_hitl_permission_level_high(self, mock_input):
        # High level should never call input
        config = HitlConfig(permission_level="high")
        manager = Manager(agents=[self.agent], model=self.mock_model, hitl=config)
        res = manager.ask("Hello", stream=False)
        self.assertFalse(mock_input.called)

    @patch('builtins.input', return_value='y')
    def test_hitl_permission_level_medium_risky(self, mock_input):
        # Medium level should call input for risky words like 'delete'
        config = HitlConfig(permission_level="medium")
        manager = Manager(agents=[self.agent], model=self.mock_model, hitl=config)
        res = manager.ask("delete all files", stream=False)
        self.assertTrue(mock_input.called)

    @patch('builtins.input', return_value='y')
    def test_hitl_permission_level_medium_safe(self, mock_input):
        # Medium level should NOT call input for safe words
        config = HitlConfig(permission_level="medium")
        manager = Manager(agents=[self.agent], model=self.mock_model, hitl=config)
        res = manager.ask("How are you?", stream=False)
        self.assertFalse(mock_input.called)

    @patch('builtins.input', return_value='y')
    def test_hitl_ask_once(self, mock_input):
        # Ask once should only call input once even for multiple calls
        config = HitlConfig(permission_level="low", ask_once=True)
        manager = Manager(agents=[self.agent], model=self.mock_model, hitl=config)
        
        manager.ask("Task 1", stream=False)
        self.assertEqual(mock_input.call_count, 1)
        
        manager.ask("Task 2", stream=False)
        self.assertEqual(mock_input.call_count, 1) # Still 1 because session allowed

if __name__ == "__main__":
    unittest.main()
