import os
import shutil
import unittest
import uuid
from orionagent.memory.storage.sqlite_storage import SQLiteStorage

class TestChromaStorage(unittest.TestCase):
    def setUp(self):
        self.test_path = f"tests/test_chroma_db_{uuid.uuid4().hex}"
        self.db_path = os.path.join(self.test_path, "test.db")
        # Initialize SQLiteStorage with use_chroma=True to test Level 4
        self.storage = SQLiteStorage(db_path=self.db_path, use_chroma=True)

    def tearDown(self):
        import time
        time.sleep(0.1)
        if os.path.exists(self.test_path):
            try:
                shutil.rmtree(self.test_path)
            except:
                pass

    def test_add_and_search(self):
        if not getattr(self.storage, 'use_chroma', False):
            self.skipTest("ChromaDB not installed or not enabled")
            
        self.storage.add("The capital of France is Paris.", "user1", "agent1", importance=8)
        self.storage.add("The sky is blue.", "user1", "agent1", importance=3)
        
        # Test semantic search (Level 4 behavior)
        results = self.storage.search("What is the capital of France?", "user1", "agent1")
        self.assertTrue(len(results) > 0)
        self.assertIn("Paris", results[0]["content"])
        
        # Test importance threshold
        results = self.storage.search("What is the capital of France?", "user1", "agent1", min_importance=9)
        self.assertEqual(len(results), 0)

    def test_clear(self):
        if not getattr(self.storage, 'use_chroma', False):
            self.skipTest("ChromaDB not installed")
            
        self.storage.add("Fact 1", "user2", "agent2")
        self.storage.clear("user2", "agent2")
        results = self.storage.search("Fact 1", "user2", "agent2")
        self.assertEqual(len(results), 0)

if __name__ == "__main__":
    unittest.main()
