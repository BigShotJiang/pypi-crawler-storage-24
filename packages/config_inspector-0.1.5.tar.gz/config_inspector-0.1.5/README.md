# Config Inspector

![Coverage](https://img.shields.io/badge/coverage-99.68%25-brightgreen)

## Overview

Config Inspector is a Python package for working with text-based config and script files.

It supports:

- file registration + metadata collection
- file content payload generation with size limits
- update strategies for INI, TOML, JSON, and plain text files

Primary public APIs:

- `FileRegistry`
- `FileMetadataService`
- `FileContentService`
- `updater_factory` (plus updater classes)

## Installation

```bash
uv pip install config-inspector
```

## Quick Start

```python
from pathlib import Path
import json

from config_inspector import FileContentService
from config_inspector import FileMetadataService
from config_inspector import FileRegistry
from config_inspector import updater_factory


class SizeFormatter:
    def format(self, size_bytes: int) -> str:
        return f"{size_bytes} bytes"


class DateTimeFormatter:
    def format(self, dt) -> str:
        return dt.strftime("%Y-%m-%d %H:%M:%S")


metadata_service = FileMetadataService(
    size_formatter=SizeFormatter(),
    datetime_formatter=DateTimeFormatter(),
)

registry = FileRegistry(metadata_service)
registry.register(Path("settings.json"), label="app-config")

for meta in registry.get_all_metadata():
    print(meta)

content_service = FileContentService(metadata_service, max_size_bytes=50_000)
payload = content_service.get_payload(Path("settings.json"), key="config")

content = json.loads(payload["config"]["content"])
content["feature_flag"] = True
updater_factory(".json").update(Path("settings.json"), content)
```

## Development

List available commands:

```bash
just --list
```

Environment setup:

```bash
just env
just pip-install-editable
```

## Testing and Quality Gates

Common local checks:

```bash
just check
just ci
```

Targeted commands:

```bash
just pytest
just coverage
just open-coverage
just ruff-check
just api-check
```

## Versioning and Release

Version helpers:

```bash
just version-show
just version-bump-patch
just version-bump-minor
just version-bump-major
just version-verify
```

Tag helpers:

```bash
just version-tag-dryrun
just version-tag
just version-tag-push
```

Build and publish helpers:

```bash
just dist
just wheel-smoke
just twine-check
just twine-upload-test
just twine-upload
```

## CI

Bitbucket Pipelines is the CI source of truth for this repository.

Main CI command path is:

```bash
just ci
```

## Issues

If you experience issues, open one on Bitbucket:

- https://bitbucket.org/xstudios/config-inspector/issues
