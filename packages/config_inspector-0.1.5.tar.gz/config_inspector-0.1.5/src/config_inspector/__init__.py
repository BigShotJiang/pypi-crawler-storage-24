import logging

from .file_content import FileContentService
from .file_content import FileMetadataService
from .registry import FileRegistry
from .updaters import IniConfigUpdater
from .updaters import JsonConfigUpdater
from .updaters import PlainTextUpdater
from .updaters import TomlConfigUpdater
from .updaters import updater_factory

# Basic logger setup; users of this package can configure logging as needed
logger = logging.getLogger(__name__)
logger.setLevel(logging.ERROR)

__version__ = "0.1.5"

__all__ = [
    "FileContentService",
    "FileMetadataService",
    "FileRegistry",
    "IniConfigUpdater",
    "JsonConfigUpdater",
    "PlainTextUpdater",
    "TomlConfigUpdater",
    "updater_factory",
]
