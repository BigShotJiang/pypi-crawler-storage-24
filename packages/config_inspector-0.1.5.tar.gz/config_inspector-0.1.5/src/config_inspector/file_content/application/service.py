"""Application services for file metadata and file content use-cases."""

from datetime import datetime
from pathlib import Path

from config_inspector.file_content.application.dtos import PayloadEnvelope
from config_inspector.file_content.application.ports import DateTimeFormatter
from config_inspector.file_content.application.ports import FileReaderPort
from config_inspector.file_content.application.ports import PayloadMapperPort
from config_inspector.file_content.application.ports import SizeFormatter
from config_inspector.file_content.domain.entities import FileMeta
from config_inspector.file_content.domain.rules import FileSizePolicy


class FileMetadataService:
    """Application service for extracting file metadata."""

    def __init__(
        self,
        size_formatter: SizeFormatter,
        datetime_formatter: DateTimeFormatter,
        lang_mapper: dict[str, str] | None = None,
    ):
        self.size_formatter = size_formatter
        self.datetime_formatter = datetime_formatter
        self.lang_mapper = lang_mapper or self._default_lang_mapper()

    def _default_lang_mapper(self) -> dict[str, str]:
        return {
            ".bat": "batchfile",
            ".cfg": "ini",
            ".cmd": "batchfile",
            ".ini": "ini",
            ".js": "javascript",
            ".json": "json",
            ".ps1": "powershell",
            ".py": "python",
            ".sh": "sh",
            ".toml": "toml",
            ".yaml": "yaml",
            ".yml": "yaml",
        }

    def get_lang(self, filepath: Path) -> str:
        return self.lang_mapper.get(filepath.suffix.lower(), "text")

    def get_metadata(self, filepath: Path, label: str | None = None) -> FileMeta:
        stat = filepath.stat()
        tz = datetime.now().astimezone().tzinfo
        modified_dt = datetime.fromtimestamp(stat.st_mtime, tz=tz)

        return FileMeta(
            label=label or filepath.stem,
            filepath=filepath,
            name=filepath.name,
            ext=filepath.suffix.lower(),
            size=self.size_formatter.format(stat.st_size),
            lang=self.get_lang(filepath),
            modified=self.datetime_formatter.format(modified_dt),
        )


class FileContentService:
    """Application service for reading file contents with size validation."""

    def __init__(
        self,
        metadata_service: FileMetadataService,
        size_policy: FileSizePolicy,
        file_reader: FileReaderPort,
        payload_mapper: PayloadMapperPort,
    ):
        self.metadata_service = metadata_service
        self.size_policy = size_policy
        self.file_reader = file_reader
        self.payload_mapper = payload_mapper

    def is_valid_size(self, filepath: Path) -> bool:
        return self.size_policy.is_valid(filepath)

    def get_payload(self, filepath: Path, key: str | None, label: str | None = None) -> dict:
        if not filepath.is_file():
            return {}

        self.size_policy.ensure_within_limit(filepath)

        meta = self.metadata_service.get_metadata(filepath, label)
        content = self.file_reader.read(filepath)
        payload = self.payload_mapper.assemble(meta, content)

        envelope = PayloadEnvelope(key=key, payload=payload.to_dict())
        return envelope.to_dict()
