"""Application DTOs for shaping return payloads."""

from dataclasses import dataclass


@dataclass(frozen=True)
class PayloadEnvelope:
    key: str | None
    payload: dict

    def to_dict(self) -> dict:
        if self.key is None:
            return self.payload
        return {self.key: self.payload}
