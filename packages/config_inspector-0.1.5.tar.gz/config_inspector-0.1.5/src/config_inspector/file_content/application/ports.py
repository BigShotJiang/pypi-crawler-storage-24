"""Application ports for file content services."""

from datetime import datetime
from pathlib import Path
from typing import Protocol

from config_inspector.file_content.domain.entities import FileMeta
from config_inspector.file_content.domain.entities import FilePayload


class SizeFormatter(Protocol):
    """Port for formatting byte sizes to human-readable strings."""

    def format(self, size_bytes: int) -> str: ...


class DateTimeFormatter(Protocol):
    """Port for formatting datetime objects to strings."""

    def format(self, dt: datetime) -> str: ...


class FileReaderPort(Protocol):
    """Port for reading file text."""

    def read(self, filepath: Path) -> str: ...


class PayloadMapperPort(Protocol):
    """Port for combining metadata and content into a payload object."""

    def assemble(self, meta: FileMeta, content: str) -> FilePayload: ...
