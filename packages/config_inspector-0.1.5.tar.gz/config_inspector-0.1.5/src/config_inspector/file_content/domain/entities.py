"""Domain entities for file metadata and payload content."""

from dataclasses import dataclass
from pathlib import Path


@dataclass
class FileMeta:
    label: str
    filepath: Path
    name: str
    ext: str
    size: str
    lang: str
    modified: str

    def to_dict(self) -> dict:
        return {
            "label": self.label,
            "filepath": str(self.filepath),
            "name": self.name,
            "ext": self.ext,
            "size": self.size,
            "lang": self.lang,
            "modified": self.modified,
        }


@dataclass
class FilePayload:
    meta: FileMeta
    content: str

    def to_dict(self, key: str | None = None) -> dict:
        result = self.meta.to_dict()
        result["content"] = self.content
        if key is None:
            return result
        return {key: result}
