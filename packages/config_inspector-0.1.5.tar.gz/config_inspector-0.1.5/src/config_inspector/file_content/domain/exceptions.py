"""Domain exceptions for file content policies."""


class FileTooLargeError(ValueError):
    """Raised when file size exceeds the allowed domain limit."""
