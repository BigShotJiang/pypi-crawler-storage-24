"""Domain rules for file content constraints."""

from pathlib import Path

from config_inspector.file_content.domain.exceptions import FileTooLargeError


class FileSizePolicy:
    """Domain policy for validating file size limits."""

    def __init__(self, max_size_bytes: int):
        self.max_size_bytes = max_size_bytes

    def is_valid(self, filepath: Path) -> bool:
        return filepath.stat().st_size < self.max_size_bytes

    def ensure_within_limit(self, filepath: Path) -> None:
        if self.is_valid(filepath):
            return
        size = filepath.stat().st_size
        msg = (
            f"File {filepath} is too large ({size} bytes, "
            f"max {self.max_size_bytes} bytes)"
        )
        raise FileTooLargeError(msg)
