"""File content subdomain public exports."""

from pathlib import Path

from config_inspector.file_content.application.service import FileMetadataService
from config_inspector.file_content.domain.entities import FileMeta
from config_inspector.file_content.domain.entities import FilePayload
from config_inspector.file_content.domain.rules import FileSizePolicy
from config_inspector.file_content.infrastructure.factory import (
    build_file_content_service,
)


class FileContentService:
    """Public facade preserving legacy constructor for file content reads."""

    def __init__(
        self,
        metadata_service: FileMetadataService,
        max_size_bytes: int = 268_435_455,
    ):
        self._service = build_file_content_service(
            metadata_service=metadata_service,
            max_size_bytes=max_size_bytes,
        )

    def is_valid_size(self, filepath: Path) -> bool:
        return self._service.is_valid_size(filepath)

    def get_payload(self, filepath: Path, key: str, label: str | None = None) -> dict:
        return self._service.get_payload(filepath, key, label)


__all__ = [
    "FileContentService",
    "FileMeta",
    "FileMetadataService",
    "FilePayload",
    "FileSizePolicy",
]
