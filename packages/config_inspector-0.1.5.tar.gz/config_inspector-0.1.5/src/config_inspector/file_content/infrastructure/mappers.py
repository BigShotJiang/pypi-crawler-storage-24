"""Infrastructure mappers for file content subdomain."""

from config_inspector.file_content.domain.entities import FileMeta
from config_inspector.file_content.domain.entities import FilePayload


class PayloadAssembler:
    """Build payload objects from metadata + content."""

    def assemble(self, meta: FileMeta, content: str) -> FilePayload:
        return FilePayload(meta=meta, content=content)
