"""Factory wiring for file content application services."""

from config_inspector.file_content.application.service import FileContentService
from config_inspector.file_content.application.service import FileMetadataService
from config_inspector.file_content.domain.rules import FileSizePolicy
from config_inspector.file_content.infrastructure.mappers import PayloadAssembler
from config_inspector.file_content.infrastructure.repository import FileReader


def build_file_content_service(
    metadata_service: FileMetadataService,
    max_size_bytes: int,
) -> FileContentService:
    """Construct an application file content service with infrastructure adapters."""
    return FileContentService(
        metadata_service=metadata_service,
        size_policy=FileSizePolicy(max_size_bytes=max_size_bytes),
        file_reader=FileReader(),
        payload_mapper=PayloadAssembler(),
    )
