"""Infrastructure adapters for file content subdomain."""

from pathlib import Path


class FileReader:
    """Infrastructure adapter for reading text files safely."""

    def read(self, filepath: Path) -> str:
        return filepath.read_text(encoding="utf-8", errors="replace")
