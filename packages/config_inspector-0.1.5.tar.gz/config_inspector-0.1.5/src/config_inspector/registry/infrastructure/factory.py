"""Factory wiring for registry subdomain."""

from config_inspector.file_content import FileMetadataService
from config_inspector.registry.application.service import RegistryService


def build_registry_service(metadata_service: FileMetadataService) -> RegistryService:
    """Build registry service with metadata provider dependency."""
    return RegistryService(metadata_provider=metadata_service)
