"""Infrastructure package for registry subdomain."""

from config_inspector.registry.infrastructure.factory import build_registry_service

__all__ = ["build_registry_service"]
