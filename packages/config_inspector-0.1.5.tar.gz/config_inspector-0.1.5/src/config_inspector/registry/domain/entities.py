"""Domain entities for registry subdomain."""

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class RegisteredFile:
    """A tracked file entry with optional display label."""

    filepath: Path
    label: str | None = None

    def as_tuple(self) -> tuple[Path, str | None]:
        return (self.filepath, self.label)
