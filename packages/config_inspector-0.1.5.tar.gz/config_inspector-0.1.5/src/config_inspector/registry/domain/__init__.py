"""Domain package for registry subdomain."""

from config_inspector.registry.domain.entities import RegisteredFile

__all__ = ["RegisteredFile"]
