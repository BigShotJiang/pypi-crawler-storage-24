"""Registry subdomain public exports and compatibility facade."""

from pathlib import Path

from config_inspector.file_content import FileMetadataService
from config_inspector.file_content.domain.entities import FileMeta
from config_inspector.registry.infrastructure.factory import build_registry_service


class FileRegistry:
    """Registry for tracking files with metadata."""

    def __init__(self, metadata_service: FileMetadataService):
        self._service = build_registry_service(metadata_service)

    def register(self, filepath: Path, label: str | None = None) -> None:
        self._service.register(filepath, label)

    def get_all_metadata(self) -> list[FileMeta]:
        return self._service.get_all_metadata()

    def is_registered(self, filepath: Path) -> bool:
        return self._service.is_registered(filepath)

    def clear(self) -> None:
        self._service.clear()

    def list_files(self) -> list[tuple[Path, str | None]]:
        return self._service.list_files()


__all__ = ["FileRegistry"]
