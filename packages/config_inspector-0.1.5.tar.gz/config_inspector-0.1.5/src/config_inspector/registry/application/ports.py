"""Application ports for registry subdomain."""

from pathlib import Path
from typing import Protocol

from config_inspector.file_content.domain.entities import FileMeta


class MetadataProviderPort(Protocol):
    """Port required by registry for metadata retrieval."""

    def get_metadata(self, filepath: Path, label: str | None = None) -> FileMeta:
        """Return metadata for a file path and optional label."""
