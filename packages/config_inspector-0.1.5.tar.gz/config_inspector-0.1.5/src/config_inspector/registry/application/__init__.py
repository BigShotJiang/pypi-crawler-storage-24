"""Application package for registry subdomain."""

from config_inspector.registry.application.service import RegistryService

__all__ = ["RegistryService"]
