"""Application service for file registry use-cases."""

from pathlib import Path

from config_inspector.file_content.domain.entities import FileMeta
from config_inspector.registry.application.ports import MetadataProviderPort
from config_inspector.registry.domain.entities import RegisteredFile


class RegistryService:
    """Orchestrates file registration and metadata retrieval."""

    def __init__(self, metadata_provider: MetadataProviderPort):
        self.metadata_provider = metadata_provider
        self._files: list[RegisteredFile] = []

    def register(self, filepath: Path, label: str | None = None) -> None:
        if filepath.is_file() and not self.is_registered(filepath):
            self._files.append(RegisteredFile(filepath=filepath, label=label))

    def get_all_metadata(self) -> list[FileMeta]:
        return [
            self.metadata_provider.get_metadata(
                entry.filepath,
                entry.label,
            )
            for entry in self._files
            if entry.filepath.is_file()
        ]

    def is_registered(self, filepath: Path) -> bool:
        return any(entry.filepath == filepath for entry in self._files)

    def clear(self) -> None:
        self._files.clear()

    def list_files(self) -> list[tuple[Path, str | None]]:
        return [entry.as_tuple() for entry in self._files]
