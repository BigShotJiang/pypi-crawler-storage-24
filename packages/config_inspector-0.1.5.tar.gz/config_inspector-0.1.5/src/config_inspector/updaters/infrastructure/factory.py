"""Factory wiring for selecting concrete updater implementations."""

from config_inspector.updaters.application.ports import ConfigUpdater
from config_inspector.updaters.domain.rules import FACTORY_UPDATER_POLICY
from config_inspector.updaters.domain.rules import UpdaterKind
from config_inspector.updaters.domain.rules import resolve_updater_kind
from config_inspector.updaters.infrastructure.repository import IniConfigUpdater
from config_inspector.updaters.infrastructure.repository import JsonConfigUpdater
from config_inspector.updaters.infrastructure.repository import PlainTextUpdater
from config_inspector.updaters.infrastructure.repository import TomlConfigUpdater


def updater_factory(file_extension: str) -> ConfigUpdater:
    """Return the updater implementation for the given file extension."""
    kind = resolve_updater_kind(
        file_extension,
        FACTORY_UPDATER_POLICY,
        default=UpdaterKind.PLAIN_TEXT,
    )
    if kind is UpdaterKind.INI:
        return IniConfigUpdater()
    if kind is UpdaterKind.TOML:
        return TomlConfigUpdater()
    if kind is UpdaterKind.JSON:
        return JsonConfigUpdater()
    return PlainTextUpdater()
