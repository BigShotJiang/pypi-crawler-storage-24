"""Application ports for updater behaviors."""

from pathlib import Path
from typing import Protocol


class ConfigUpdater(Protocol):
    """Application port: update a config-like file with new content."""

    def update(self, filepath: Path, content) -> None:
        """Update the configuration file with new content."""
