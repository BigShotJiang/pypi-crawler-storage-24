"""Application package for updaters subdomain."""

from config_inspector.updaters.application.ports import ConfigUpdater

__all__ = ["ConfigUpdater"]
