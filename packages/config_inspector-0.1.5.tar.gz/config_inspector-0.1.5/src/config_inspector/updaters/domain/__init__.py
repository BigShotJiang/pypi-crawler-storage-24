"""Domain package for updater rules."""

from config_inspector.updaters.domain.exceptions import UpdaterResolutionError
from config_inspector.updaters.domain.rules import FACTORY_UPDATER_POLICY
from config_inspector.updaters.domain.rules import UpdaterKind
from config_inspector.updaters.domain.rules import normalize_extension
from config_inspector.updaters.domain.rules import resolve_updater_kind

__all__ = [
    "FACTORY_UPDATER_POLICY",
    "UpdaterKind",
    "UpdaterResolutionError",
    "normalize_extension",
    "resolve_updater_kind",
]
