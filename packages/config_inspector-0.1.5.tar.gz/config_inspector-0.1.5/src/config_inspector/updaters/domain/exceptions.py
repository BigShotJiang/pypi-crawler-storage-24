"""Domain exceptions for updater resolution."""


class UpdaterResolutionError(ValueError):
    """Raised when no updater strategy can be resolved for an extension."""
