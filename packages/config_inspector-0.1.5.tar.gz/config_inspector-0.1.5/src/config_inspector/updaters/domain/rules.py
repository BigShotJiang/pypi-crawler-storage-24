"""Domain rules for selecting config updater strategies by extension."""

from enum import StrEnum

from config_inspector.updaters.domain.exceptions import UpdaterResolutionError


class UpdaterKind(StrEnum):
    INI = "ini"
    JSON = "json"
    TOML = "toml"
    PLAIN_TEXT = "plain_text"


FACTORY_UPDATER_POLICY: dict[str, UpdaterKind] = {
    ".ini": UpdaterKind.INI,
    ".toml": UpdaterKind.TOML,
    ".json": UpdaterKind.JSON,
    ".txt": UpdaterKind.PLAIN_TEXT,
    ".sh": UpdaterKind.PLAIN_TEXT,
    ".bat": UpdaterKind.PLAIN_TEXT,
}


def normalize_extension(file_extension: str) -> str:
    """Normalize and lower-case extensions for lookup."""
    return file_extension.strip().lower()


def resolve_updater_kind(
    file_extension: str,
    policy: dict[str, UpdaterKind],
    default: UpdaterKind | None = None,
) -> UpdaterKind:
    """Resolve updater kind from policy or default."""
    ext = normalize_extension(file_extension)
    kind = policy.get(ext)
    if kind is not None:
        return kind
    if default is not None:
        return default
    msg = f"No updater found for file type: {ext}"
    raise UpdaterResolutionError(msg)
