# History

All notable changes to this project will be documented in this file. This project adheres to [Semantic Versioning](http://semver.org/).

## 0.1.5 (2026-03-13)
- CHANGED: Refactored package internals into DDD-aligned subdomains (`updaters`, `file_content`, `registry`) while preserving top-level public imports and signatures.
- CHANGED: Standardized application ports on `Protocol` for cleaner dependency boundaries.
- CHANGED: Removed legacy flat modules (`domain.py`, `updaters.py`, `services.py`, `models.py`, `registry.py`, `protocols.py`) after test migration.
- CHANGED: Modernized developer workflow around `Justfile` commands (`check`, `ci`, `doctor`, `outdated`) and release helpers.
- ADDED: Domain-focused tests under `tests/domains/*` and stronger architecture/public API contract checks.
- ADDED: Version management and safe git tag recipes in `Justfile` (`version-bump-*`, `version-tag`, `version-tag-push`).
- ADDED: Bitbucket Pipeline CI configuration as the canonical CI path for this repository.
- CHANGED: Release quality gates now include artifact verification, wheel smoke install, and `twine check`.
- CHANGED: README updated to match current public API usage and `just`-based workflows.
- CHANGED: Hardened `.gitignore` coverage for Python packaging, test artifacts, and tooling caches.
- CHANGED: Removed unused direct runtime dependency on `requests`.

## 0.1.4 (2025-12-04)
- ADDED: tox and 100% test coverage
- ADDED: `updater_factory` to get the correspinding file updater by looking at the file extension.

## 0.1.3 (2025-12-01)
- ADDED: When writing a file with `FileContentService.write_text()` we set utf-8 errors to `replace`.

## 0.1.2 (2025-11-11)

- ADDED: When reading a file with `FileContentService.get_payload` we set utf-8 errors to `replace`.

## 0.1.1 (2025-11-05)

- ADDED: Added `.js` and `.ps1` extensions that simply use `PlainTextUpdater` and do not try to validate/format on save.

## 0.1.0 (2025-10-06)

- First release
