import pytest

from config_inspector.updaters.domain.rules import FACTORY_UPDATER_POLICY
from config_inspector.updaters.domain.rules import UpdaterKind
from config_inspector.updaters.domain.rules import normalize_extension
from config_inspector.updaters.domain.rules import resolve_updater_kind


def test_normalize_extension_trims_and_lowercases():
    assert normalize_extension("  .JSON  ") == ".json"


def test_resolve_updater_kind_raises_for_unknown_without_default():
    with pytest.raises(ValueError, match=r"No updater found for file type: \.unknown"):
        resolve_updater_kind(".unknown", FACTORY_UPDATER_POLICY)


def test_resolve_updater_kind_returns_default_when_provided():
    assert (
        resolve_updater_kind(
            ".unknown",
            FACTORY_UPDATER_POLICY,
            default=UpdaterKind.PLAIN_TEXT,
        )
        is UpdaterKind.PLAIN_TEXT
    )
