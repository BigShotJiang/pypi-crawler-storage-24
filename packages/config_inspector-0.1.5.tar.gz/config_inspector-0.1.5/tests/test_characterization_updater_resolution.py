from config_inspector.updaters import IniConfigUpdater
from config_inspector.updaters import JsonConfigUpdater
from config_inspector.updaters import PlainTextUpdater
from config_inspector.updaters import TomlConfigUpdater
from config_inspector.updaters import updater_factory


def test_factory_extension_policy_characterization():
    assert isinstance(updater_factory(".ini"), IniConfigUpdater)
    assert isinstance(updater_factory(".toml"), TomlConfigUpdater)
    assert isinstance(updater_factory(".json"), JsonConfigUpdater)
    assert isinstance(updater_factory(".txt"), PlainTextUpdater)
    assert isinstance(updater_factory(".cfg"), PlainTextUpdater)
    assert isinstance(updater_factory(".unknown"), PlainTextUpdater)
