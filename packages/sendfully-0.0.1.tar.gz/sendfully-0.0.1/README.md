# Sendfully Python SDK

The official Python SDK for [Sendfully](https://sendfully.com).

## License

MIT
