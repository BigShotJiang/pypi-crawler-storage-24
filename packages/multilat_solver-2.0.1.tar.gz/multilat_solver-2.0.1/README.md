# MultiLat Localizer

Universal multilateration localization with pluggable input/output adapters for distance measurements and position output.

## Features

- **Inputs:** Serial (UWB/RTK-DW1000), MQTT, UDP, File; custom adapters via `with_input()`
- **Outputs:** MAVLink, MAVROS (ROS2), UDP, File, Console; multiple outputs at once, custom adapterd via 'with_output()'
- **Calibration:** None, Linear, Quadratic, Cubic;
- **GPS:** ENU → GPS via pymap3d; frequency throttling; message type (GPS / Position / Both)
- **Config:** Python API or YAML config file; CLI: `multilat_solver --config config.yaml`

## Installation

```bash
pip install multilat_solver
```

Optional: `pip install multilat_solver[mqtt]` (MQTT), `multilat_solver[ros2]` (ROS2), `.[dev]` (development).

## Run from YAML config

```bash
multilat_solver --config config.yaml
multilat_solver --config config.yaml --logs /path/to/logs
```

Config specifies anchors, origin, input/output adapters, and optional `logging.dir` / `logging.level`. Default log directory: `~/.multilat_solver/logs`. Example: `config_examples/example_cli.yaml`. See [Quick Start](docs/quick_start.md).

## Documentation

- **[Quick Start](docs/quick_start.md)** — minimal setup, anchor formats, basic example with UDP server and client
- [Configuration](docs/configuration.md) · [Input adapters](docs/input-adapters.md) · [Output adapters](docs/output-adapters.md)
- [Calibration](docs/calibration.md) · [Examples](docs/examples.md) · [Custom adapters](docs/extension.md)

## Adapters

| Input   | Description                    |
|---------|--------------------------------|
| Serial  | Binary protocol (UWB/RTK-DW1000) |
| MQTT    | JSON over MQTT `[mqtt]`        |
| UDP     | JSON over UDP                  |
| File    | JSON file polling              |

| Output  | Description                    |
|---------|--------------------------------|
| MAVLink | ArduPilot/PX4                  |
| MAVROS  | ROS2 topics `[ros2]`           |
| UDP     | JSON over UDP                  |
| File    | JSONL file                     |
| Console | Human or JSON                  |

## Examples

- `examples/send_data.py` + `examples/for_docs.py` — UDP distance simulator + localizer (run send_data first, then for_docs); see [Quick Start](docs/quick_start.md)
- `examples/basic_usage.py` — Serial in, console/file/MAVLink out
- `examples/multi_output.py` — Multiple outputs
- `examples/mavlink_input_with_sim.py` — MAVLink distances in + simulator
- `examples/uavcan_input_mavlink_output.py` — Custom UAVCAN input → MAVLink out

## Development

```bash
git clone https://github.com/Innopolis-UAV-Team/multilat_solver
cd multilat_solver
pip install -e ".[dev]"
pytest
```
