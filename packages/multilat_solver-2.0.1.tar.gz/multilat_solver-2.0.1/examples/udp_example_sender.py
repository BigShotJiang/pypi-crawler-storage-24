#!/usr/bin/env python3
"""
UDP anchor data sender for examples/udp_example
"""

import json
import socket
import time

server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
server_socket.bind(("udpout:127.0.0.1", 9999))


ranges = [
    {"id": "A0", "m": 0.000, "t": 0.000},
    {"id": "A1", "m": 0.001, "t": 0.001},
    {"id": "A2", "m": 0.002, "t": 0.002},
    {"id": "A3", "m": 0.003, "t": 0.003},
]

print("UDP server listening on 0.0.0.0:9999")
reply = "".join(["\n" + json.dumps(range) for range in ranges])

print(reply)
reply = reply.encode()
while True:
    message, address = server_socket.recvfrom(1024)
    print(f"Received data: {message} from {address}")
    server_socket.sendto(reply, address)
    time.sleep(0.1)
