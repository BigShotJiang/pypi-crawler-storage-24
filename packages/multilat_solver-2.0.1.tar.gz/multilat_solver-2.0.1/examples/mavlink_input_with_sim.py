#!/usr/bin/env python3
"""
Example: Using multiple output adapters simultaneously.
"""
import logging
import threading
import time
from pathlib import Path
from typing import Callable, Dict

import numpy as np
import pymap3d as pm
from pymavlink import mavutil

from multilat_solver import ConfigBuilder, MessageType, MultiLatLocalizerApp
from multilat_solver.input_adapters import InputAdapter
from multilat_solver.output_adapters import (
    ConsoleOutputAdapter,
    FileOutputAdapter,
    MavlinkOutputAdapter,
)

MAV_AUTOPILOT_PX4 = 12
MAV_TYPE_GCS = 6
SYSTEM_ID = 1
COMPONENT_ID = 200
CONNECTION_STRING = "udp:127.0.0.1:14551"
INPUT_CONNECTION_STRING = "udp:127.0.0.1:14551"

ANCHOR_COORDINATES = {
    0: {"lon": 48.741957, "lat": 55.748718, "alt": 214.956},
    1: {"lon": 48.742733, "lat": 55.749016, "alt": 214.956},
    2: {"lon": 48.742733, "lat": 55.749417, "alt": 214.956},
    3: {"lon": 48.743234, "lat": 55.749045, "alt": 214.956},
    4: {"lon": 48.743194, "lat": 55.748616, "alt": 214.956},
    5: {"lon": 48.743733, "lat": 55.749208, "alt": 214.956},
    6: {"lon": 48.743562, "lat": 55.749562, "alt": 214.956},
    7: {"lon": 48.743200, "lat": 55.749869, "alt": 214.956},
    8: {"lon": 48.744116, "lat": 55.749931, "alt": 214.956},
    9: {"lon": 48.744116, "lat": 55.750396, "alt": 214.956},
}

INITIAL_POSITION = {"lat": 55.7487863, "lon": 48.7430517, "alt": 214.956}


anchor_positions = {}
for anchor_id, gps in ANCHOR_COORDINATES.items():
    x, y, z = pm.geodetic2enu(
        lat=gps["lat"],
        lon=gps["lon"],
        h=gps["alt"],
        lat0=INITIAL_POSITION["lat"],
        lon0=INITIAL_POSITION["lon"],
        h0=INITIAL_POSITION["alt"],
    )
    anchor_positions[anchor_id] = (x, y, z)

timestamp = time.strftime("%Y%m%d_%H%M%S")
filename = timestamp + "_" + __file__.split("/")[-1].replace(".py", ".log")
path = Path(__file__).parent.parent.absolute() / "logs"

debug_log_name = "debug_" + filename.replace(".py", ".log")
log_name = filename

logging.basicConfig(filename=path / debug_log_name, encoding="utf-8", level=logging.DEBUG)
logging.basicConfig(filename=path / log_name, encoding="utf-8", level=logging.INFO)

logger = logging.getLogger(__name__)
logger.propagate = True


def get_distance(lat, lon, alt, lat1, lon1, alt1):
    """
    Get distance between two points in meters.
    """
    x, y, z = pm.geodetic2enu(
        lat=lat,
        lon=lon,
        h=alt,
        lat0=INITIAL_POSITION["lat"],
        lon0=INITIAL_POSITION["lon"],
        h0=INITIAL_POSITION["alt"],
    )
    x1, y1, z1 = pm.geodetic2enu(
        lat=lat1,
        lon=lon1,
        h=alt1,
        lat0=INITIAL_POSITION["lat"],
        lon0=INITIAL_POSITION["lon"],
        h0=INITIAL_POSITION["alt"],
    )
    return np.sqrt((x - x1) ** 2 + (y - y1) ** 2 + (z - z1) ** 2)


class MavlinkInputAdapter(InputAdapter):
    """MAVLink input adapter. Uses udpout and sends a few packets first so PX4 registers us and sends back."""

    def __init__(
        self,
        connection_string: str = "udpout:127.0.0.1:14550",
        system_id: int = 1,
        component_id: int = 1,
        reconnect_attempts: int = 3,
        heartbeat_wait_s: float = 15.0,
    ):
        """
        Initialize MAVLink input adapter.
        """
        self.connection_string = connection_string
        self.system_id = system_id
        self.component_id = component_id
        self.reconnect_attempts = reconnect_attempts
        self.heartbeat_wait_s = heartbeat_wait_s
        self.connection = self._connect()
        # Register with PX4 so it sends heartbeats (and other msgs) to our port

    def _connect(self):
        return mavutil.mavlink_connection(
            self.connection_string, source_system=self.system_id, source_component=self.component_id
        )

    def _try_reconnect(self):
        attempts = self.reconnect_attempts
        while attempts > 0:
            if self.connection is not None:
                self.connection.close()
            self.connection = self._connect()
            res = self.connection.wait_heartbeat(timeout=self.heartbeat_wait_s)
            if res is not None:
                self.running = True
                return
            attempts -= 1
            logger.warning(f"MavlinkInputAdapter heartbeat timeout. Attempts left: {attempts}")
        self.running = False

    def start(self, callback: Callable[[Dict[int, Dict[str, float]]], None]):
        """Read from MAVLink."""
        self.callback = callback
        self._try_reconnect()
        self.thread = threading.Thread(target=self._read_loop, daemon=True)
        self.thread.start()

    def _read_loop(self):
        last_hb_time = 0.0
        while self.is_running():
            try:
                hb = self.connection.recv_match(type="HEARTBEAT", blocking=False)
                if hb is not None:
                    last_hb_time = time.monotonic()
                if time.monotonic() - last_hb_time > self.heartbeat_wait_s:
                    self.running = False
                    self._try_reconnect()
                    continue

                msg = self.connection.recv_match(type="GPS_RAW_INT", blocking=False, timeout=0.2)
                if msg is None:
                    continue

                if msg.get_type() == "BAD_DATA":
                    continue
                else:
                    distances = {}
                    for anchor, position in ANCHOR_COORDINATES.items():
                        # LOCAL_POSITION_NED: x, y, z in mm (NED)
                        anchor_distance = get_distance(
                            msg.lat / 1e7,
                            msg.lon / 1e7,
                            msg.alt / 1000,
                            position["lat"],
                            position["lon"],
                            position["alt"],
                        )
                        distances[anchor] = {"m": anchor_distance, "t": msg.time_usec}
                    self.callback(distances)
            except OSError as exc:
                self.running = False
                logger.exception("MAVLink read error: %s", exc)
                self._try_reconnect()
                continue

    def is_running(self) -> bool:
        """Check if adapter is running."""
        return self.running

    def close(self):
        """Close MAVLink connection."""
        self.connection.close()

    def stop(self):
        """Stop reading from MAVLink."""
        self.connection.close()


def main():
    """Run MultiLat Localizer with multiple outputs."""
    config = (
        ConfigBuilder()
        .with_localization(
            anchor_positions=anchor_positions,
            origin_coordinates=(INITIAL_POSITION["lat"], INITIAL_POSITION["lon"], INITIAL_POSITION["alt"]),
            max_range=200.0,
        )
        .with_input(
            "custom",
            MavlinkInputAdapter(
                connection_string=INPUT_CONNECTION_STRING, system_id=SYSTEM_ID, component_id=2
            ),
        )
        # Multiple outputs: console for debugging, MAVLink for flight controller
        .with_output(
            "console",
            ConsoleOutputAdapter(format="human", message_type=MessageType.BOTH, frequency=10),
        )
        .with_output(
            "file",
            FileOutputAdapter(
                filepath="positions.json",
                mode="a",
                message_type=MessageType.BOTH,
                frequency=10,
            ),
        )
        .with_output(
            "mavlink",
            MavlinkOutputAdapter(
                connection_string=CONNECTION_STRING,
                system_id=SYSTEM_ID,
                component_id=COMPONENT_ID,
                message_type=MessageType.GPS,
                frequency=10,
            ),
        )
        .build()
    )

    logger.debug("Config: %s", config)
    app = MultiLatLocalizerApp(config)
    app.run()


if __name__ == "__main__":
    logger.info("Starting main")
    main()
