#!/usr/bin/env python3
"""
Example: Using multiple output adapters simultaneously.
"""
import logging
from logging import getLogger

from multilat_solver import ConfigBuilder, MessageType, MultiLatLocalizerApp
from multilat_solver.output_adapters import (
    ConsoleOutputAdapter,
    FileOutputAdapter,
    MavlinkOutputAdapter,
)

logger = getLogger(__name__)

logger.setLevel(logging.DEBUG)


def main():
    """Run MultiLat Localizer with multiple outputs."""
    config = (
        ConfigBuilder()
        .with_localization(
            anchor_positions={
                1: (0.0, 0.0, 0.0),
                2: (3.0, 0.0, 0.0),
                3: (0.0, 3.0, 0.0),
            },
        )
        .with_serial_input(port="/dev/ttyUSB0", baud=115200)
        # Multiple outputs: console for debugging, MAVLink for flight controller
        .with_output(
            "console",
            ConsoleOutputAdapter(format="human", message_type=MessageType.BOTH, frequency=10),
        )
        .with_output(
            "file",
            FileOutputAdapter(
                filepath="positions.json",
                mode="a",
                message_type=MessageType.BOTH,
                frequency=10,
            ),
        )
        .with_output(
            "mavlink",
            MavlinkOutputAdapter(
                connection_string="udpout:127.0.0.1:14550",
                system_id=1,
                component_id=1,
                message_type=MessageType.BOTH,
                frequency=10,
            ),
        )
        .build()
    )
    logger.debug("Config: %s", config)
    app = MultiLatLocalizerApp(config)
    app.run()


if __name__ == "__main__":
    logger.info("Starting main")
    main()
