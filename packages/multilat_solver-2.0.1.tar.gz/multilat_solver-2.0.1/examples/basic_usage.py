#!/usr/bin/env python3

"""
Basic usage example of MultiLat Localizer with Python API.
"""

import logging

from multilat_solver import CalibrationType, ConfigBuilder, MultiLatLocalizerApp
from multilat_solver.common_types import MessageType
from multilat_solver.output_adapters import (
    ConsoleOutputAdapter,
    FileOutputAdapter,
    MavlinkOutputAdapter,
)

logging.basicConfig(filename="example.log", encoding="utf-8", level=logging.DEBUG)
logger = logging.getLogger(__name__)
logger.propagate = True


def main():
    """Run MultiLat Localizer programmatically."""
    # Build configuration using the builder pattern
    config = (
        ConfigBuilder()
        # Configure localization engine
        .with_localization(
            anchor_positions={
                1: (0.0, 0.0, 3.0),
                2: (3.0, 0.0, 0.0),
                3: (0.0, 3.0, 0.0),
                4: (3.0, 3.0, 0.0),  # Optional: 4th anchor for better accuracy
            },
            origin_coordinates=(37.7749, -122.4194, 0.0),  # San Francisco (optional)
            ellipsoid="wgs84",
            calibration_type=CalibrationType.LINEAR,
            calibration_params=[1.0, 0.0],  # k=1.0, b=0.0 for linear calibration
            z_sign=0,  # Auto-detect z sign
            min_range=0.0,
            max_range=100.0,
        )
        # Configure input adapter (choose one)
        .with_serial_input(port="/dev/ttyUSB0", baud=115200, timeout=1.0)
        .with_output(
            "console",
            ConsoleOutputAdapter(
                format="human",
                message_type=MessageType.BOTH,
                frequency=10,
            ),
        )
        .with_output(
            "file",
            FileOutputAdapter(
                filepath="positions.json",
                mode="a",
                message_type=MessageType.BOTH,
                frequency=10,
            ),
        )
        .with_output(
            "mavlink",
            MavlinkOutputAdapter(
                connection_string="udpout:127.0.0.1:14550",
                system_id=1,
                component_id=1,
                message_type=MessageType.BOTH,
                frequency=10,
            ),
        )
        .build()
    )

    # Create and run the application
    app = MultiLatLocalizerApp(config)
    app.run()


if __name__ == "__main__":
    main()
