#!/usr/bin/env python3
"""
Basic usage example of MultiLat Localizer with Python API.
"""

import logging
import socket
import time
from pathlib import Path

import yaml

from multilat_solver import ConfigBuilder, MessageType, MultiLatLocalizerApp
from multilat_solver.input_adapters import UDPInputAdapter
from multilat_solver.output_adapters import ConsoleOutputAdapter, FileOutputAdapter

timestamp = time.strftime("%Y%m%d_%H%M%S")
filename = timestamp + "_" + __file__.split("/")[-1].replace(".py", ".log")
path = Path(__file__).parent.parent.absolute() / "logs"

debug_log_name = "debug_" + filename.replace(".py", ".log")
log_name = filename

logging.basicConfig(filename=path / debug_log_name, encoding="utf-8", level=logging.DEBUG)
logging.basicConfig(filename=path / log_name, encoding="utf-8", level=logging.INFO)

logger = logging.getLogger(__name__)
logger.propagate = True


_config_path = Path(__file__).parent / "udp_example.yaml"
with open(_config_path, "r") as f:
    config = yaml.safe_load(f)

clientSocket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# Set a timeout value of 1 second
clientSocket.settimeout(1)
builder = ConfigBuilder()

builder.with_localization(
    anchor_positions=config["anchors"],
    origin_coordinates=(config["origin"]["lat"], config["origin"]["lon"], config["origin"]["alt"]),
    max_range=config["publish"]["max_range_m"],
)
builder.with_input("udp", UDPInputAdapter(host="127.0.0.1", port=9999, socket_=clientSocket))
builder.with_output(
    "console", ConsoleOutputAdapter(format="human", message_type=MessageType.BOTH, frequency=10)
)

builder.with_output(
    "file",
    FileOutputAdapter(filepath="positions.json", mode="a", message_type=MessageType.BOTH, frequency=10),
)

app = MultiLatLocalizerApp(builder.build())
app.run()
