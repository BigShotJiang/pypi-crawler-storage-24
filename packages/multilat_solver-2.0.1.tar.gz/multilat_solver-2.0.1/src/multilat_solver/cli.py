#!/usr/bin/env python3
"""
CLI entry point for MultiLat Localizer.

Run with a YAML config file:
  multilat_solver --config config.yaml
  multilat_solver --config config.yaml --logs /path/to/logs
"""

import argparse
import logging
import os
import sys
from pathlib import Path

from multilat_solver import MultiLatLocalizerApp
from multilat_solver.config import MultiLatLocalizerConfig

DEFAULT_LOG_DIR = os.path.expanduser("~/.multilat_solver/logs")


def _setup_logging(log_dir: str | Path, level: str = "INFO") -> Path:
    """Create log directory and configure file + console logging. Returns log dir path."""
    log_path = Path(log_dir).expanduser().resolve()
    log_path.mkdir(parents=True, exist_ok=True)

    from datetime import datetime

    timestamp = datetime.now().strftime("%Y%m%d")
    log_file = log_path / f"multilat_solver_{timestamp}.log"

    level_value = getattr(logging, level.upper(), logging.INFO)
    fmt = "%(asctime)s %(levelname)s [%(name)s] %(message)s"
    datefmt = "%Y-%m-%d %H:%M:%S"

    root = logging.getLogger()
    root.setLevel(level_value)
    for h in list(root.handlers):
        root.removeHandler(h)

    fh = logging.FileHandler(log_file, encoding="utf-8")
    fh.setLevel(level_value)
    fh.setFormatter(logging.Formatter(fmt, datefmt=datefmt))
    root.addHandler(fh)

    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(level_value)
    ch.setFormatter(logging.Formatter(fmt, datefmt=datefmt))
    root.addHandler(ch)

    logging.info("Logging to %s", log_file)
    return log_path


def main() -> int:
    """Main entry point for the CLI."""
    parser = argparse.ArgumentParser(
        description="MultiLat Localizer - run with a YAML config file",
        prog="multilat_solver",
    )
    parser.add_argument(
        "--config",
        "-c",
        required=True,
        metavar="FILE",
        help="Path to YAML config file (anchors, origin, input, output, optional logging)",
    )
    parser.add_argument(
        "--logs",
        "-l",
        metavar="DIR",
        default=None,
        help="Log directory (overrides config logging.dir). Default: ~/.multilat_solver/logs",
    )
    parser.add_argument(
        "--log-level",
        choices=("DEBUG", "INFO", "WARNING", "ERROR"),
        default=None,
        help="Log level (overrides config logging.level)",
    )
    args = parser.parse_args()

    config_path = Path(args.config).expanduser().resolve()
    if not config_path.is_file():
        print(f"Error: config file not found: {config_path}", file=sys.stderr)
        return 1

    try:
        import yaml

        with open(config_path, "r", encoding="utf-8") as f:
            config_data = yaml.safe_load(f)
    except Exception as e:
        print(f"Error loading config: {e}", file=sys.stderr)
        return 1

    if not config_data or not isinstance(config_data, dict):
        print("Error: config file is empty or not a YAML object", file=sys.stderr)
        return 1

    # Resolve log dir: CLI --logs > config.logging.dir > default
    logging_config = config_data.get("logging") or {}
    if isinstance(logging_config, dict):
        log_dir = args.logs or logging_config.get("dir") or DEFAULT_LOG_DIR
        log_level = args.log_level or logging_config.get("level", "INFO")
    else:
        log_dir = args.logs or DEFAULT_LOG_DIR
        log_level = args.log_level or "INFO"

    _setup_logging(log_dir, level=log_level)

    try:
        app_config = MultiLatLocalizerConfig.from_yaml(config_data)
    except ValueError as e:
        logging.error("Invalid config: %s", e)
        return 1

    app = MultiLatLocalizerApp(app_config)
    app.run()
    return 0


if __name__ == "__main__":
    sys.exit(main())
