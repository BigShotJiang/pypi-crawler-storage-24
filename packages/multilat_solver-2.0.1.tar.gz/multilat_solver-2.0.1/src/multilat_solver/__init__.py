"""
MultiLat Localization System - Flexible input/output architecture.
"""

from .app import MultiLatLocalizerApp
from .common_types import DistanceRecord, MessageType
from .config import (
    CalibrationType,
    ConfigBuilder,
    InputConfig,
    LocalizationConfig,
    MultiLatLocalizerConfig,
    SumOutputConfig,
)
from .core import multilateration
from .input_adapters import INPUT_ADAPTERS  # noqa: F401
from .input_adapters import register_input_adapter  # noqa: F401
from .input_adapters import (
    FileInputAdapter,
    InputAdapter,
    MQTTInputAdapter,
    SerialInputAdapter,
    UDPInputAdapter,
)
from .localization import LocalizationEngine
from .output_adapters import OUTPUT_ADAPTERS  # noqa: F401
from .output_adapters import register_output_adapter  # noqa: F401
from .output_adapters import (
    ConsoleOutputAdapter,
    FileOutputAdapter,
    MavlinkOutputAdapter,
    MavrosOutputAdapter,
    MultiOutputAdapter,
    OutputAdapter,
    UDPOutputAdapter,
)

__version__ = "0.1.0"

__all__ = [
    # Core
    "LocalizationEngine",
    "multilateration",
    # App
    "MultiLatLocalizerApp",
    # Config
    "MultiLatLocalizerConfig",
    "ConfigBuilder",
    "LocalizationConfig",
    "InputConfig",
    "SumOutputConfig",
    "CalibrationType",
    "DistanceRecord",
    "MessageType",
    # Input Adapters
    "InputAdapter",
    "SerialInputAdapter",
    "MQTTInputAdapter",
    "UDPInputAdapter",
    "FileInputAdapter",
    # Output Adapters
    "OutputAdapter",
    "MavlinkOutputAdapter",
    "MavrosOutputAdapter",
    "UDPOutputAdapter",
    "FileOutputAdapter",
    "ConsoleOutputAdapter",
    "MultiOutputAdapter",
]
