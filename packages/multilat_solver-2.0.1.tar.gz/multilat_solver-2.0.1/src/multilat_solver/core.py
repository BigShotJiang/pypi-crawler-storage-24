"""Core localization module using multilateration algorithm."""

import logging
from typing import Callable, Dict, Tuple

import numpy as np
import pymap3d as pm

from multilat_solver.common_types import CalibrationType

logger = logging.getLogger(__name__)

# Lazy import so numpy_lse path does not require the localization package
_lx = None


def _get_lx():
    global _lx
    if _lx is None:
        import localization as lx

        _lx = lx
    return _lx


def calibrated_linear(k: float, b: float, x: float) -> float:
    """Linear calibration: k * x + b."""
    return k * x + b


def calibrated_quadratic(a: float, b: float, c: float, x: float) -> float:
    """Quadratic calibration: a * x^2 + b * x + c."""
    return a * x**2 + b * x + c


def calibrated_cubic(a: float, b: float, c: float, d: float, x: float) -> float:
    """Cubic calibration: a * x^3 + b * x^2 + c * x + d."""
    return a * x**3 + b * x**2 + c * x + d


CALIBRATIONS: Dict[CalibrationType, Callable[..., float]] = {
    CalibrationType.LINEAR: calibrated_linear,
    CalibrationType.QUADRATIC: calibrated_quadratic,
    CalibrationType.CUBIC: calibrated_cubic,
}


def register_calibration(calibration_type: CalibrationType, calibration: Callable[..., float]) -> None:
    """Register a new calibration function."""
    if calibration_type in CALIBRATIONS:
        raise ValueError(f"Calibration {calibration_type} already registered")
    CALIBRATIONS[calibration_type] = calibration


def _multilateration_numpy_lse(
    positions: np.ndarray,
    distances: np.ndarray,
    z_sign: int,
) -> Tuple[float, float, float]:
    """
    Linearized least-squares 3D multilateration using NumPy only (no scipy/localization).

    Requires positions shape (n, 3), distances shape (n,), n >= 4.
    """
    n = positions.shape[0]
    assert n >= 4, "At least 4 anchors are required for numpy_lse solver"
    p0 = positions[0]
    d0 = distances[0]
    # From |x-p_i|^2 = d_i^2: 2(p_i - p_0)·x = (|p_i|^2 - |p_0|^2) - (d_i^2 - d_0^2)
    diff = positions[1:] - p0
    A = 2.0 * diff
    sq = np.sum(positions**2, axis=1)
    b = (sq[1:] - sq[0]) - (distances[1:] ** 2 - d0**2)
    x, *_ = np.linalg.lstsq(A, b, rcond=None)
    if z_sign != 0:
        x[2] = abs(x[2]) * z_sign
    return float(x[0]), float(x[1]), float(x[2])


def multilateration(
    raw_data: Dict[int, float],
    anchor_positions: Dict[int, Tuple[float, float, float]] = {},
    z_sign: int = 0,
    solver: str = "lx",
) -> Tuple[float, float, float] | None:
    """
    Multilateration algorithm.

    :param raw_data: Dictionary mapping anchor IDs to distances (meters)
    :param anchor_positions: Dictionary mapping anchor IDs to (x, y, z) positions
    :param z_sign: z sign, used if there are two solutions (0 = auto, +1 = positive, -1 = negative)
    :param solver: "lx" (localization library, scipy) or "numpy_lse"
    :return: (x, y, z) position tuple
    """
    non_zero_data = {}
    for anchor_id in raw_data.keys():
        if raw_data[anchor_id] is not None:
            non_zero_data[anchor_id] = raw_data[anchor_id]
    if len(non_zero_data) < 3:
        raise ValueError(f"Not enough data for trilateration. Non-zero: {non_zero_data}, Input: {raw_data}")

    if len(anchor_positions) < 3:
        raise ValueError(f"Not enough anchor positions for trilateration: {anchor_positions}")

    matched_ids = list(set(non_zero_data.keys()) & set(anchor_positions.keys()))
    if len(matched_ids) < 3:
        raise ValueError(
            f"Not enough common anchors for trilateration. Matched: {matched_ids},\
                known: {anchor_positions.keys()}, received: {set(non_zero_data.keys())}"
        )

    use_numpy_lse = solver == "numpy_lse" and len(matched_ids) >= 4
    if use_numpy_lse:
        positions = np.array([anchor_positions[i] for i in matched_ids], dtype=float)
        distances = np.array([non_zero_data[i] for i in matched_ids], dtype=float)
        return _multilateration_numpy_lse(positions, distances, z_sign)

    lx = _get_lx()
    P = lx.Project(mode="3D", solver="LSE")
    for anchor_id in matched_ids:
        P.add_anchor(anchor_id, anchor_positions[anchor_id])

    t, _ = P.add_target()
    for anchor_id in matched_ids:
        t.add_measure(anchor_id, non_zero_data[anchor_id])

    P.solve()

    if z_sign != 0:
        t.loc.z = abs(t.loc.z) * z_sign

    return t.loc.x, t.loc.y, t.loc.z


def geodetic2enu(
    lat: float, lon: float, alt: float, lat0: float, lon0: float, alt0: float
) -> Tuple[float, float, float]:
    """
    Convert geodetic coordinates to ENU coordinates.
    """
    return pm.geodetic2enu(
        lat=lat,
        lon=lon,
        h=alt,
        lat0=lat0,
        lon0=lon0,
        h0=alt0,
    )
