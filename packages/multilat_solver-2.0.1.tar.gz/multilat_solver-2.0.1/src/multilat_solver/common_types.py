"""Common types for the MultiLat Localization System."""

from enum import Enum
from typing import NamedTuple


class CalibrationType(str, Enum):
    """Calibration type enumeration."""

    NONE = "none"
    LINEAR = "linear"
    QUADRATIC = "quadratic"
    CUBIC = "cubic"


class MessageType(str, Enum):
    """Output message type enumeration."""

    GPS = "gps"
    POSITION = "position"
    BOTH = "both"


class DistanceRecord(NamedTuple):
    """Lightweight record for one anchor distance (replaces dict for less CPU/memory)."""

    m: float  # distance in meters
    t: float  # timestamp (seconds or microseconds depending on adapter)
