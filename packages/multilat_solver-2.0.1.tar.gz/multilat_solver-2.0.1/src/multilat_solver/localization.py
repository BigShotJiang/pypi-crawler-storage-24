"""Localization module for MultiLat Localizer."""

import logging
from typing import Dict, List, Optional, Tuple

import pymap3d as pm

from multilat_solver.common_types import CalibrationType
from multilat_solver.config import LocalizationConfig
from multilat_solver.core import CALIBRATIONS, multilateration

logger = logging.getLogger(__name__)


class LocalizationEngine:
    """Main localization engine that processes distance measurements and calculates position."""

    __attributes__ = [
        "anchor_positions",
        "origin_coordinates",
        "ellipsoid",
        "calibration_type",
        "calibration_params",
        "z_sign",
        "min_range",
        "max_range",
        "solver",
    ]

    def __init__(self, config: LocalizationConfig):
        """
        Initialize localization engine from configuration.

        :param config: Localization configuration
        """
        self.ellipsoid: pm.Ellipsoid = pm.Ellipsoid.from_name(config.ellipsoid)
        self.anchor_positions: Dict[int, Tuple[float, float, float]] = config.anchor_positions
        self.origin_coordinates: Optional[Tuple[float, float, float]] = config.origin_coordinates
        self.calibration_type: str = config.calibration_type
        self.calibration_params: List[float] = config.calibration_params
        self.z_sign: int = config.z_sign
        self.min_range: float = config.min_range
        self.max_range: float = config.max_range
        self.solver: str = getattr(config, "solver", "lx")

    def calibrate(self, raw_distance: float) -> float:
        """Apply calibration to raw distance measurement."""
        if self.calibration_type == CalibrationType.NONE:
            return raw_distance
        if self.calibration_type not in CALIBRATIONS:
            raise ValueError(
                f"Unknown calibration type: {type(self.calibration_type)} {self.calibration_type}"
            )
        return CALIBRATIONS[self.calibration_type](*self.calibration_params, raw_distance)

    def validate_range(self, distance: float) -> bool:
        """Check if distance is within valid range."""
        return self.min_range <= distance <= self.max_range

    def calculate_position(self, distances: Dict[int, float]) -> Optional[Tuple[float, float, float]]:
        """
        Calculate position from distance measurements.

        :param distances: Dictionary mapping anchor IDs to calibrated distances (meters)
        :return: (x, y, z) position tuple or None if calculation fails
        """
        # Filter out None values and validate ranges
        valid_distances = {}
        for anchor_id, distance in distances.items():
            if distance is not None and self.validate_range(distance):
                valid_distances[anchor_id] = distance

        if len(valid_distances) < 3:
            logger.warning("Not enough valid distances: %s is given", len(valid_distances))
            return None

        try:
            return multilateration(valid_distances, self.anchor_positions, self.z_sign, solver=self.solver)
        except ValueError as e:
            logger.error("Error in multilateration: %s", e)
            return None

    def _convert_to_gps(self, position: Tuple[float, float, float]) -> Tuple[float, float, float]:
        """Convert position to GPS coordinates."""
        if self.origin_coordinates is None:
            raise ValueError("Origin coordinates are not set")
        lat, lon, alt = pm.enu2geodetic(
            position[0],
            position[1],
            position[2],
            self.origin_coordinates[0],
            self.origin_coordinates[1],
            self.origin_coordinates[2],
            ell=self.ellipsoid,
        )
        return lat, lon, alt
