# Quick Start

Get MultiLat Localizer running in a few steps.

## Install

```bash
pip install multilat_solver
```

Optional: `pip install multilat_solver[mqtt]` (MQTT), `multilat_solver[ros2]` (ROS2/MAVROS).

## Run from YAML config (CLI)

You can run the app with a single YAML config file:

```bash
multilat_solver --config config.yaml
multilat_solver --config config.yaml --logs /path/to/logs
python -m multilat_solver --config config.yaml
```

- **`--config`** (required): path to YAML with anchors, origin, input, output, and optional `logging`.
- **`--logs`**: directory for log files (overrides `logging.dir` in config). Default: `~/.multilat_solver/logs`.
- **`--log-level`**: DEBUG, INFO, WARNING, or ERROR (overrides `logging.level`).

Logs are written to a timestamped file in the log directory (e.g. `multilat_solver_20260225.log`). Example config: `config_examples/example_cli.yaml`.

# Configuration
Configuration splits into 3 parts: configuration for input adapters, output adapters and localization.

See [Configuration API](configuration.md) for all options.

## Ready to use example for UDP

The repo includes a small **UDP simulator** so you can run the localizer without hardware.

### How it works

1. **`examples/udp_example_sender.py`** — UDP **server** that binds to `0.0.0.0:9999`. When it receives a “ping”, it replies with **NDJSON** distance lines (e.g. `{"id": "A0", "m": 0.0, "t": 0.0}\n...`).
2. **`examples/udp_example.py`** — Runs `MultiLatLocalizerApp` with **UDP input**. The adapter sends “ping” to a **host:port** and waits for the reply. That host must be where `udp_example_sender.py` is running.

### Run order

1. **Terminal 1 — start the data source (must be first):**
   ```bash
   python examples/send_data.py
   ```
   You should see: `UDP server listening on 0.0.0.0:9999`.

2. **Terminal 2 — start the localizer:**
   ```bash
   python examples/for_docs.py
   ```
   It will send pings to **127.0.0.1:9999** and print position/GPS from the replied distances.

### Important

- **`host` in UDP input:** For this setup the adapter is a **client** that sends “ping” to the server. Use **`host="127.0.0.1"`** (or the machine’s IP where `udp_example_sender` runs), **not** `"0.0.0.0"`. `0.0.0.0` is for binding a server, not for the destination of the ping.
- **Port:** Both must agree on the same port (e.g. 9999): `send_data.py` binds to it, `for_docs.py` uses it as the destination port.
- **Anchor IDs:** The anchors in `for_docs.yaml` (e.g. `A0`, `A1`, `A2`, `A3`) must match the `"id"` fields in the NDJSON sent by `send_data.py`.

See [Input adapters — UDP](input-adapters.md#udp-input) for message formats and options.

---

## Next steps

- [Configuration API](configuration.md) — all builder options, calibration, ranges
- [Input adapters](input-adapters.md) — Serial, MQTT, UDP, File formats
- [Output adapters](output-adapters.md) — MAVLink, MAVROS, UDP, File, Console
- [Examples](examples.md) — multiple outputs, MQTT, custom (e.g. UAVCAN) input
