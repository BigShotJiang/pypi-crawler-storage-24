# Input Adapters

Input adapters supply distance measurements to the localization engine. Use built-in methods (`with_serial_input`, `with_mqtt_input`, etc.) or a custom adapter with `with_input("name", adapter_instance)`.

## Serial Input

Receives distance measurements from RTK-DW1000 or similar UWB devices via serial port.

```python
.with_serial_input(port="/dev/ttyUSB0", baud=460800, timeout=1.0)
```

### Message Format

Binary protocol with message marker `0xFF 0xFF 0xFF 0x55`:

- Message structure: `[id: uint8, data: uint32]` (little-endian)
- Data is in millimeters, automatically converted to meters

## MQTT Input

Receives distance measurements via MQTT broker.

```python
# Requires: pip install multilat_solver[mqtt]
.from multilat_solver import ConfigBuilder

config = (ConfigBuilder()
    .with_localization(...)
    .with_mqtt_input(broker="localhost", port=1883, topic="multilat/distances")
    .build())
```

### Message Format

JSON format with two supported structures:

**Dict format**:
```json
{"1": 2.5, "2": 3.1}
```
Where keys are anchor IDs (as strings) and values are distances in meters.

**List format**:
```json
[{"id": 1, "m": 2.5}, {"id": 2, "m": 3.1}]
```

## UDP Input

Receives distance measurements via UDP socket.

```python
.with_udp_input(host="0.0.0.0", port=5005)
```

### Message Format

JSON format (same as MQTT):
- Dict format: `{"1": 2.5, "2": 3.1}` (anchor_id: distance_in_meters) or `{"id": 1, "m": 2.5б 5, "t": 0.0}`
- List format: `[{"id": 1, "m": 2.5, "t": 0.0}, {"id": 2, "m": 3.1, "t": 0.0}]`

## File Input

Reads distance measurements from a JSON file (polled periodically).

```python
.with_file_input(filepath="distances.json", poll_interval=1.0)
```

### Message Format

JSON format (same as MQTT/UDP):
- Dict format: `{"1": 2.5, "2": 3.1}` (anchor_id: distance_in_meters) or `{"id": 1, "m": 2.5б 5, "t": 0.0}`
- List format: `[{"id": 1, "m": 2.55, "t": 0.0}, {"id": 2, "m": 3.1б 5, "t": 0.0}]`

The file is polled at the specified interval. If the file doesn't exist or contains invalid JSON, a warning is logged and the adapter continues running.
