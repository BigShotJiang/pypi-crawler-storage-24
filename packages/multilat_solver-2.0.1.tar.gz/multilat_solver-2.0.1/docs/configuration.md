# Configuration API

## YAML config (CLI)

When using the CLI (`multilat_solver --config config.yaml`), the config file can use this structure:

- **`anchors`**: List of anchor dicts with `gps: [lat, lon, alt]` or `relative: [x, y, z]`, optional `id`.
- **`origin`**: `{ lat, lon, alt }` for GPS conversion.
- **`localization`** (optional): Overrides such as `calibration_type`, `max_range`, `ellipsoid`, `solver` (`lx` or `numpy_lse`; `numpy_lse` uses NumPy-only LSE and requires 4+ anchors).
- **`publish`** (optional): `max_range_m`, `rate_hz` (used for max_range if present).
- **`input`**: `type` (serial, udp, file, mqtt) plus type-specific params (`port`, `baud`, `host`, `port`, `filepath`, etc.).
- **`output`**: Dict of adapter name → kwargs, e.g. `console: { format: human, frequency: 10 }`, `file: { filepath: positions.json, mode: a }`, `mavlink: { connection_string: udpout:127.0.0.1:14550 }`.
- **`logging`** (optional): `dir` (log directory, overridden by `--logs`), `level` (INFO, DEBUG, etc.). Default log dir: `~/.multilat_solver/logs`.

See `config_examples/example_cli.yaml` for a full example.

## Builder Pattern

The `ConfigBuilder` provides a fluent API. Output adapters are configured by passing an **adapter instance** (constructor kwargs):

```python
from multilat_solver import ConfigBuilder, CalibrationType
from multilat_solver.common_types import MessageType
from multilat_solver.output_adapters import (
    ConsoleOutputAdapter, FileOutputAdapter, MavlinkOutputAdapter,
)

config = (ConfigBuilder()
    .with_localization(
        anchor_positions={1: (0, 0, 0), 2: (3, 0, 0), 3: (0, 3, 0), 4: (3, 3, 0)},
        origin_coordinates=(37.7749, -122.4194, 0.0),  # Optional: for GPS
        ellipsoid="wgs84",
        calibration_type=CalibrationType.LINEAR,
        calibration_params=[1.0, 0.0],
        z_sign=0,
        min_range=0.0,
        max_range=100.0,
    )
    .with_serial_input(port="/dev/ttyUSB0", baud=460800, timeout=1.0)
    # OR .with_udp_input(host="0.0.0.0", port=5005)
    # OR .with_file_input(filepath="distances.json", poll_interval=1.0)
    # OR .with_input("any_name", MyInputAdapter(...))  # custom InputAdapter child class instance

    .with_output("console", ConsoleOutputAdapter(format="human", message_type=MessageType.BOTH, frequency=10))
    .with_output("file", FileOutputAdapter(filepath="positions.json", mode="a", message_type=MessageType.BOTH, frequency=10))
    .with_output("mavlink", MavlinkOutputAdapter(connection_string="udpout:127.0.0.1:14550", system_id=1, component_id=1, message_type=MessageType.BOTH, frequency=10))
    # OR .with_output("any_name", MyOutputAdapter(...)) # custom OutputAdapter child class instance
    .build())
```

## Localization Parameters

### `with_localization()`

Configure the multilateration engine:

- **`anchor_positions`** (dict, required): Dictionary mapping anchor IDs to (x, y, z) positions in meters
- **`origin_coordinates`** (tuple, optional): (latitude, longitude, altitude) for GPS conversion. If not provided, GPS output will be disabled.
- **`ellipsoid`** (str, optional): Ellipsoid model for GPS conversion (default: "wgs84")
- **`calibration_type`** (CalibrationType, optional): Type of calibration to apply (default: CalibrationType.NONE)
- **`calibration_params`** (list, optional): Parameters for calibration function (see [Calibration Types](calibration.md))
- **`z_sign`** (int, optional): Z-axis sign detection (0=auto, +1=upper, -1=lower)
- **`min_range`** (float, optional): Minimum valid distance in meters (default: 0.0)
- **`max_range`** (float, optional): Maximum valid distance in meters (default: 100.0)

## Input Adapter Methods

### `with_serial_input(port, baud, timeout=1.0)`

Configure serial port input adapter.

- **`port`** (str): Serial port path (e.g., "/dev/ttyUSB0" or "COM3")
- **`baud`** (int): Baud rate (e.g., 460800)
- **`timeout`** (float, optional): Read timeout in seconds (default: 1.0)

### `with_mqtt_input(broker, port=1883, topic, client_id=None)`

Configure MQTT input adapter. Requires `multilat_solver[mqtt]`.

- **`broker`** (str): MQTT broker hostname or IP
- **`port`** (int, optional): MQTT broker port (default: 1883)
- **`topic`** (str): MQTT topic to subscribe to
- **`client_id`** (str, optional): MQTT client ID (auto-generated if not provided)

### `with_udp_input(host, port)`

Configure UDP input adapter.

- **`host`** (str): Host to bind to (e.g., "0.0.0.0" for all interfaces)
- **`port`** (int): UDP port to listen on

### `with_file_input(filepath, poll_interval=1.0)`

Configure file input adapter.

- **`filepath`** (str): Path to JSON file containing distance measurements
- **`poll_interval`** (float, optional): Polling interval in seconds (default: 1.0)

## Output Adapter Methods

### `with_output(name, adapter_instance)`

Add an output adapter. Can be called multiple times for multiple outputs.

- **`name`** (str): Unique name for this output
- **`adapter_instance`**: An instance of an output adapter (e.g. `ConsoleOutputAdapter(format="human", ...)`)

See [Output Adapters](output-adapters.md) for adapter-specific constructor options.
