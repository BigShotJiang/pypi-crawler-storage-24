# MultiLat Localizer Documentation

Universal multilateration localization with flexible input/output adapters (Python API, no config files). **Version 0.1.0.**

## Quick Links

- **[Quick Start](quick_start.md)** — minimal run, anchor formats (dict/list), basic example with UDP server and client
- [Configuration API](configuration.md) — Builder and localization/input/output setup
- [Input Adapters](input-adapters.md) — Serial, MQTT, UDP, File formats and options
- [Output Adapters](output-adapters.md) — MAVLink, MAVROS, UDP, File, Console
- [Calibration](calibration.md) — Calibration types and message types
- [Examples](examples.md) — Working examples including custom (e.g. UAVCAN) input
- [Extension Guide](extension.md) — Custom input/output adapters

## Overview

- **Inputs:** Serial (UWB/RTK-DW1000), MQTT, UDP, File; custom adapters via `with_input()`
- **Outputs:** MAVLink, MAVROS, UDP, File, Console; multiple at once
- **Calibration:** None, Linear, Quadratic, Cubic; GPS conversion (pymap3d); frequency and message type

## Installation

```bash
pip install multilat_solver
# Optional: [mqtt], [ros2]; development: -e ".[dev]"
```

## Quick Start

Minimal run: 3 anchors, one input, one output. See **[Quick Start](quick_start.md)** for:

- Minimal Python example and anchor formats (dict vs list with `gps`/`relative`)
- **UDP testing:** run `udp_example_sender.py` first, then `udp_example.py` (use `host="127.0.0.1"` for UDP input so pings reach the simulator)

```python
from multilat_solver import ConfigBuilder, MultiLatLocalizerApp, CalibrationType
from multilat_solver.common_types import MessageType
from multilat_solver.output_adapters import ConsoleOutputAdapter

config = (ConfigBuilder()
    .with_localization(
        anchor_positions={1: (0, 0, 0), 2: (3, 0, 0), 3: (0, 3, 0)},
        calibration_type=CalibrationType.LINEAR,
        calibration_params=[1.0, 0.0],
    )
    .with_serial_input(port="/dev/ttyUSB0", baud=460800)
    .with_output("console", ConsoleOutputAdapter(format="human", message_type=MessageType.BOTH, frequency=10))
    .build())

app = MultiLatLocalizerApp(config)
app.run()
```

See [Configuration API](configuration.md) and [Examples](examples.md) for details.
