# Calibration Types

Distance measurements can be calibrated using different polynomial functions to account for systematic errors or non-linearities in the measurement system.

## Available Calibration Types

### NONE

No calibration applied (default) - `y = x`

```python
from multilat_solver import CalibrationType

.with_localization(
    calibration_type=CalibrationType.NONE,
    # calibration_params not needed
)
```

### LINEAR

Linear calibration - `y = k * x + b`

```python
.with_localization(
    calibration_type=CalibrationType.LINEAR,
    calibration_params=[k, b]  # y = k*x + b
)
```

**Example**: `calibration_params=[1.0, 0.0]` means no change (k=1.0, b=0.0)

### QUADRATIC

Quadratic calibration - `y = a * x² + b * x + c`

```python
.with_localization(
    calibration_type=CalibrationType.QUADRATIC,
    calibration_params=[a, b, c]  # y = a*x² + b*x + c
)
```

**Example**: `calibration_params=[0.001, 1.0, 0.0]` means `y = 0.001*x² + 1.0*x + 0.0`

### CUBIC

Cubic calibration - `y = a * x³ + b * x² + c * x + d`

```python
.with_localization(
    calibration_type=CalibrationType.CUBIC,
    calibration_params=[a, b, c, d]  # y = a*x³ + b*x² + c*x + d
)
```

## Message Types

Control what type of messages are sent by output adapters:

### GPS

Send GPS coordinates only. Requires `origin_coordinates` to be set in localization configuration.

```python
from multilat_solver.common_types import MessageType

ConsoleOutputConfig(message_type=MessageType.GPS, ...)
```

### POSITION

Send local position (ENU coordinates) only.

```python
ConsoleOutputConfig(message_type=MessageType.POSITION, ...)
```

### BOTH

Send both GPS and position messages (default).

```python
ConsoleOutputConfig(message_type=MessageType.BOTH, ...)
```
