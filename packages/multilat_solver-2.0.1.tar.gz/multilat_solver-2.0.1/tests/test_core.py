"""
Unit tests for core localization module.
"""

import math

import pytest

from multilat_solver.core import (
    calibrated_cubic,
    calibrated_linear,
    calibrated_quadratic,
    multilateration,
)


class TestCalibration:
    """Test calibration functions."""

    def test_linear_calibration(self):
        """Test linear calibration."""
        assert calibrated_linear(2.0, 1.0, 5.0) == 11.0  # 2*5 + 1
        assert calibrated_linear(1.0, 0.0, 10.0) == 10.0  # Identity

    def test_quadratic_calibration(self):
        """Test quadratic calibration."""
        # x^2 + 2x + 1 at x=2 should be 9
        assert calibrated_quadratic(1.0, 2.0, 1.0, 2.0) == 9.0

    def test_cubic_calibration(self):
        """Test cubic calibration."""
        # x^3 at x=2 should be 8
        assert calibrated_cubic(1.0, 0.0, 0.0, 0.0, 2.0) == 8.0


class TestMultilateration:
    """Test multilateration function."""

    def test_multilateration_sufficient_anchors(self):
        """Test multilateration with sufficient anchors."""
        anchor_positions = {1: (0.0, 0.0, 0.0), 2: (3.0, 0.0, 0.0), 3: (0.0, 3.0, 0.0)}

        # Point at (1,1,0)
        distances = {1: math.sqrt(2), 2: math.sqrt(5), 3: math.sqrt(5)}

        x, y, z = multilateration(distances, anchor_positions, z_sign=0)

        assert abs(x - 1.0) < 0.1
        assert abs(y - 1.0) < 0.1
        assert abs(z - 0.0) < 0.1

    def test_multilateration_insufficient_anchors(self):
        """Test multilateration fails with insufficient anchors."""
        anchor_positions = {1: (0.0, 0.0, 0.0), 2: (3.0, 0.0, 0.0)}

        distances = {1: 1.0, 2: 2.0}

        with pytest.raises(ValueError, match="Not enough data for trilateration"):
            multilateration(distances, anchor_positions)

    def test_multilateration_insufficient_data(self):
        """Test multilateration fails with insufficient distance data."""
        anchor_positions = {1: (0.0, 0.0, 0.0), 2: (3.0, 0.0, 0.0), 3: (0.0, 3.0, 0.0)}

        distances = {1: 1.0, 2: 2.0}

        with pytest.raises(ValueError, match="Not enough data"):
            multilateration(distances, anchor_positions)

    def test_multilateration_no_common_anchors(self):
        """Test multilateration fails when no common anchors."""
        anchor_positions = {1: (0.0, 0.0, 0.0), 2: (3.0, 0.0, 0.0), 3: (0.0, 3.0, 0.0)}

        distances = {4: 1.0, 5: 2.0, 6: 3.0}

        with pytest.raises(ValueError, match="Not enough common anchors"):
            multilateration(distances, anchor_positions)

    def test_multilateration_numpy_lse_four_anchors(self):
        """Test numpy_lse solver with 4 anchors (point at (1, 1, 0))."""
        anchor_positions = {
            1: (0.0, 0.0, 0.0),
            2: (3.0, 0.0, 0.0),
            3: (0.0, 3.0, 0.0),
            4: (3.0, 3.0, 0.0),
        }
        # Distances from (1,1,0) to each anchor
        distances = {
            1: math.sqrt(2),
            2: math.sqrt(5),
            3: math.sqrt(5),
            4: math.sqrt(2),
        }
        x, y, z = multilateration(distances, anchor_positions, z_sign=0, solver="numpy_lse")
        # Linearized LSE can have small error vs iterative solver
        assert abs(x - 1.0) < 0.4
        assert abs(y - 1.0) < 0.4
        assert abs(z - 0.0) < 0.4
