from django.apps import AppConfig


class CanonicalizeConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "nomnom.canonicalize"

    def ready(self) -> None:
        self.enable_signals()

        return super().ready()

    def enable_signals(self):
        from . import (
            receivers,  # noqa: F401
        )
