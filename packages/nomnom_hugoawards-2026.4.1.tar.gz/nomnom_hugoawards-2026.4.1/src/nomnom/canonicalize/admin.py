import bisect
import csv
import functools
import io
from collections import Counter
from collections.abc import Iterable
from itertools import groupby
from typing import Any
from urllib.parse import urlencode

import sentry_sdk
from django import forms
from django.contrib import admin, messages
from django.contrib.auth.decorators import permission_required, user_passes_test
from django.db import IntegrityError, transaction
from django.db.models import Count, F, Q, QuerySet
from django.http import HttpRequest, HttpResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.utils.decorators import method_decorator
from django.utils.html import format_html
from django.utils.translation import gettext_lazy as _
from django_admin_action_forms import (
    AdminActionForm,
    AdminActionFormsMixin,
    action_with_form,
)
from waffle.decorators import waffle_switch

from nomnom.canonicalize import models
from nomnom.canonicalize.feature_switches import SWITCH_FINALIST_CSV_TABLE
from nomnom.nominate import models as nominate
from nomnom.reporting import Report, ReportView
from nomnom.wsfs.rules import eph
from nomnom.wsfs.rules.constitution_2023 import CountData


class RemoveCanonicalizationForm(AdminActionForm):
    class Meta:
        help_text = "Remove canonicalization from these nominations?"
        list_objects = True


@action_with_form(RemoveCanonicalizationForm, description="Remove Canonicalization")
def remove_canonicalization(
    modeladmin: admin.ModelAdmin, request: HttpRequest, queryset: QuerySet, data: dict
) -> None:
    with transaction.atomic():
        models.remove_canonicalization(queryset)


class GroupNominationsForm(AdminActionForm):
    work = forms.ModelChoiceField(
        required=False,
        queryset=models.Work.objects.order_by("name"),
        empty_label="Create New Work from Nominations",
        help_text="Select an existing work to group these nominations into. Leave blank to create a new Work",
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.__post_init__(self.modeladmin, self.request, self.queryset)

        self.fields["work"].label_from_instance = lambda obj: (
            f"{obj.name} ({obj.category})"
        )

    def __post_init__(
        self, modeladmin: admin.ModelAdmin, request: HttpRequest, queryset: QuerySet
    ):
        categories = {n.category for n in queryset}
        # only look at works associated with the current selected
        # nominations' categories.
        #
        # It is an error to attempt to group nominations from more than one
        # election together
        elections = {category.election for category in categories}

        if not elections:
            raise forms.ValidationError(
                "You must select at least one nomination to group"
            )

        if len(elections) > 1:
            raise forms.ValidationError(
                "The nominations selected must come from exactly one election"
            )

        first_nomination = queryset.first()

        self.fields["work"].queryset = (
            self.fields["work"]
            .queryset.select_related("category")
            .filter(category__in=categories)
            .order_by("name")
        )

        if first_nomination:
            work = models.Work.find_match_based_on_identical_nomination(
                first_nomination.proposed_work_name(), first_nomination.category
            )

            if work:
                self.fields["work"].initial = work
            else:
                self.fields["work"].initial = self._find_closest_work(queryset)

    def _find_closest_work(self, queryset: QuerySet) -> models.Work | None:
        """Find the Work whose name is alphabetically closest to the most common
        proposed_work_name() among the selected nominations.

        If there's a clear mode (most frequent name), use it as the target.
        Otherwise, use the first nomination's proposed_work_name().
        """
        proposed_names = [n.proposed_work_name() for n in queryset]
        proposed_names = [
            name.strip() for name in proposed_names if name and name.strip()
        ]

        if not proposed_names:
            return None

        counts = Counter(proposed_names)
        most_common = counts.most_common(2)

        if len(most_common) > 1 and most_common[0][1] == most_common[1][1]:
            # No clear mode; all tied. Use the first nomination's name.
            target = proposed_names[0]
        else:
            target = most_common[0][0]

        works = list(self.fields["work"].queryset)
        if not works:
            return None

        work_names_lower = [w.name.lower() for w in works]
        target_lower = target.lower()

        idx = bisect.bisect_left(work_names_lower, target_lower)

        # Pick the nearest neighbor: compare the entry at idx and idx-1
        if idx == 0:
            return works[0]
        if idx >= len(works):
            return works[-1]

        # Compare distance to neighbors; since these are strings,
        # "closest" means the one that sorts nearest
        before = work_names_lower[idx - 1]
        after = work_names_lower[idx]

        if target_lower == before or target_lower == after:
            # Exact match
            return works[idx] if target_lower == after else works[idx - 1]

        # For string proximity, pick whichever would appear adjacent
        # in a sorted list. Since bisect_left gives us the insertion point,
        # both neighbors are valid; prefer the one after (higher) for consistency.
        return works[idx]

    class Meta:
        list_objects = True
        help_text = "Group these nominations?"


@action_with_form(
    GroupNominationsForm, description="Group nominations as a single Work"
)
def group_works(
    modeladmin: admin.ModelAdmin, request: HttpRequest, queryset: QuerySet, data: dict
) -> None:
    work = data.get("work")

    with transaction.atomic():
        work = models.group_nominations(queryset, work)
        work.save()


class AllNominationsTableInline(admin.TabularInline):
    model = models.CanonicalizedNomination
    extra = 0
    fields = []
    readonly_fields = ["proposed_work_name", "nominator", "category"]
    list_select_related = (
        "nomination",
        "nomination__nominator",
        "nomination__category",
    )

    has_change_permission = has_add_permission = lambda *args, **kwargs: False

    def proposed_work_name(self, instance: models.CanonicalizedNomination):
        return instance.nomination.canonicalization_display_name()

    def nominator(self, instance: models.CanonicalizedNomination):
        return instance.nomination.nominator

    def category(self, instance):
        return instance.nomination.category

    def get_fields(self, request: HttpRequest, obj):
        """Only return readonly fields

        This tabular view by default tries to show the referenced objects, even if fields
        is empty; I don't want that here."""
        return self.get_readonly_fields(request, obj)


class ElectionFilter(admin.SimpleListFilter):
    title = _("Election")
    parameter_name = "election"

    def lookups(self, request, model_admin):
        return nominate.Election.objects.values_list("slug", "name")

    def queryset(self, request, queryset):
        if self.value() is not None:
            return queryset.filter(category__election__slug=self.value())


class CategoryFilter(admin.SimpleListFilter):
    title = _("Category")
    parameter_name = "category"

    def lookups(self, request, model_admin):
        qs = nominate.Category.objects
        if "election" in request.GET:
            qs = qs.filter(election__slug=request.GET["election"])
        return qs.values_list("id", "name")

    def queryset(self, request, queryset):
        if self.value() is not None:
            return queryset.filter(category__id=self.value())


class WorksChoiceField(forms.ModelChoiceField):
    def label_from_instance(self, obj):
        return f"{obj.name} ({obj.nominations.count()} nominations)"


class CombineWorksForm(AdminActionForm):
    class Meta:
        help_text = "Combine these works? Select one to be the primary work."

    primary_work = WorksChoiceField(
        required=False, queryset=models.Work.objects.all(), widget=forms.RadioSelect
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.__post_init__(self.modeladmin, self.request, self.queryset)

    def __post_init__(
        self, modeladmin: admin.ModelAdmin, request: HttpRequest, queryset: QuerySet
    ):
        self.fields["primary_work"].queryset = queryset.annotate(
            nominations_count=Count("nominations")
        ).order_by("-nominations_count", "name")
        self.fields["primary_work"].initial = self.fields[
            "primary_work"
        ].queryset.first()


@action_with_form(CombineWorksForm, description="Combine Works")
def combine_works(
    modeladmin: admin.ModelAdmin, request: HttpRequest, queryset: QuerySet, data: dict
) -> None:
    with transaction.atomic():
        primary_work: models.Work = data.get("primary_work") or queryset.first()
        primary_work.combine_works(queryset.exclude(pk=primary_work.pk))


class WorkAdmin(AdminActionFormsMixin, admin.ModelAdmin):
    list_display = ["name", "category", "nominations_count"]
    fields = ["name", "category", "notes"]
    list_filter = list_filter = [
        ElectionFilter,
        CategoryFilter,
    ]
    search_fields = ["name"]

    actions = [combine_works]

    inlines = [AllNominationsTableInline]

    def get_queryset(self, request: HttpRequest) -> QuerySet:
        return (
            super()
            .get_queryset(request)
            .annotate(nominations_count=Count("nominations"))
            .order_by("category", "name")
        )

    @admin.display(description="Nominations", ordering="nominations_count")
    def nominations_count(self, obj):
        return obj.nominations_count


class CanonicalizedFilter(admin.SimpleListFilter):
    title = _("Canonicalized?")
    parameter_name = "canonicalized"

    def lookups(self, request, model_admin):
        return [("yes", _("Yes")), ("no", _("No"))]

    def queryset(self, request, queryset):
        if self.value() == "yes":
            return queryset.filter(~Q(works=None))
        elif self.value() == "no":
            return queryset.filter(works=None)


class NominationGroupingView(AdminActionFormsMixin, admin.ModelAdmin):
    model = models.CanonicalizedNomination

    list_display = [
        "proposed_work_name",
        "matched_work",
        "category",
        "has_matched_work",
        "is_recategorized",
        "matched_work_category",
    ]

    list_filter = [
        CanonicalizedFilter,
        ElectionFilter,
        CategoryFilter,
    ]

    actions = [group_works, remove_canonicalization]

    def get_queryset(self, request: HttpRequest) -> QuerySet[nominate.Nomination]:
        self.request = request
        return nominate.Nomination.objects.select_related(
            "canonicalizednomination",
            "canonicalizednomination__work",
            "canonicalizednomination__work__category",
            "canonicalizednomination__nomination",
            "canonicalizednomination__nomination__category",
        ).order_by("field_1")

    @admin.display(description="Raw Nomination", ordering="field_1")
    def proposed_work_name(self, obj):
        return obj.canonicalization_display_name()

    @admin.display(description="Original Category")
    def category(self, obj):
        return obj.category

    @admin.display(description="Canonicalized?", boolean=True)
    def has_matched_work(self, obj):
        return obj.work is not None

    @admin.display(description="Recategorized?", boolean=True)
    def is_recategorized(self, obj):
        return obj.work is not None and obj.category != obj.work.category

    @admin.display(description="Canonical Work", ordering="works__name")
    def matched_work(self, obj):
        if obj.work is not None:
            link = reverse("admin:canonicalize_work_change", args=[obj.work.id])
            return format_html(
                '<a href="{}">{}</a>',
                link,
                obj.work.name,
            )
        else:
            return self.make_work_button(obj)

    def matched_work_category(self, obj):
        if obj.work:
            return obj.work.category

    def make_work_button(self, obj):
        # Create an HTTP button that triggers the canonicalize:match-work view with the selected row
        if obj.work is None:
            action_url = reverse(
                "canonicalize:make-work", args=[obj.category.id, obj.id]
            )
            query_params = urlencode({"next": self.get_admin_url_with_filters()})
            full_url = f"{action_url}?{query_params}"
            return format_html(
                '<a class="button" href="{}">Create Work</a>',
                full_url,
            )

    def get_action_choices(self, request):
        choices = super().get_action_choices(request)

        # pop the first is the BLANK_CHOICE_DASH
        choices.pop(0)

        # re-order the list so that 'group_works' is first, since it's the most commonly used action
        # and we want to minimize clicks.
        choices.sort(key=lambda choice: 0 if choice[0] == "group_works" else 1)

        return choices

    def changelist_view(self, request, extra_context=None):
        """Override changelist_view to store the request query parameters for reuse."""
        self.request = request
        return super().changelist_view(request, extra_context)

    def get_admin_url_with_filters(self):
        return self.request.get_full_path() if hasattr(self, "request") else ""


# Register your models here.
admin.site.register(models.Work, WorkAdmin)
admin.site.register(models.CanonicalizedNomination, NominationGroupingView)

report_decorators = [
    user_passes_test(lambda u: u.is_staff, login_url="/admin/login/"),
    permission_required("nominate.report"),
]


class BallotReport(Report):
    def __init__(self, category: nominate.Category):
        self.category = category

    @property
    def filename(self) -> str:
        return f"{self.category.election}-{self.category.id}-canonical-ballots.csv"

    def get_field_names(self) -> list[str]:
        return ["nominator", "work 1", "work 2", "work 3", "work 4", "work 5"]

    def query_set(self) -> QuerySet:
        """Return all valid nominations that have been canonicalized.

        For that purpose, we're hinging off the canonicalized ballot join table."""
        return (
            models.CanonicalizedNomination.objects.select_related(
                "nomination",
                "nomination__nominator",
                "nomination__category",
                "nomination__admin",
                "work",
                "work__category",
            )
            .annotate(
                admin_id=F("nomination__admin__id"),
                valid=F("nomination__admin__valid_nomination"),
            )
            .filter(
                work__category=self.category,
            )
            .filter(
                Q(valid=True) | Q(admin_id=None),
            )
            .order_by("nomination__nominator")
        )

    def process(self, query_set: QuerySet) -> Iterable[Any]:
        def _sub_process():
            grouper = groupby(query_set, lambda r: r.nomination.nominator)
            for nominator, rows in grouper:
                yield [nominator] + [r.work for r in rows]

        return _sub_process()

    def get_report_row(self, field_names: list[str], row: Any) -> list[Any]:
        return row


# custom views for EPH and Finalists
@method_decorator(report_decorators, name="get")
class BallotReportView(ReportView):
    report_class = BallotReport
    html_template_name = "canonicalize/ballots.html"

    @functools.lru_cache
    def category(self) -> nominate.Category:
        return get_object_or_404(nominate.Category, pk=self.kwargs.get("category_id"))

    def prepare_report(self):
        return self.get_report_class()(self.category())


@user_passes_test(lambda u: u.is_staff, login_url="/admin/login/")
@permission_required("nominate.report")
def finalists(request: HttpRequest, category_id: int) -> HttpResponse:
    category = get_object_or_404(nominate.Category, pk=category_id)
    ballot_builder = BallotReport(category)
    ballot_objs = [r[1:] for r in ballot_builder.get_report_rows()]
    ballots = [[w.name for w in ballot] for ballot in ballot_objs]

    steps = []

    def recorder(
        ballots: list[str], counts: dict[str, CountData], eliminations: list[str]
    ):
        steps.append((ballots, counts, eliminations))

    finalists = eph(ballots, finalist_count=6, record_steps=recorder)
    return render(
        request,
        "canonicalize/eph.html",
        {
            "category": category,
            "finalists": finalists,
            "steps": steps,
        },
    )


@waffle_switch(SWITCH_FINALIST_CSV_TABLE)
@user_passes_test(lambda u: u.is_staff, login_url="/admin/login/")
@permission_required("nominate.report")
def finalists_csv(request: HttpRequest, category_id: int) -> HttpResponse:
    category = get_object_or_404(nominate.Category, pk=category_id)
    ballot_builder = BallotReport(category)
    ballot_objs = [r[1:] for r in ballot_builder.get_report_rows()]
    ballots = [[w.name for w in ballot] for ballot in ballot_objs]

    steps: list[tuple[list, dict[str, CountData], list[str]]] = []

    def recorder(
        ballots: list[str], counts: dict[str, CountData], eliminations: list[str]
    ):
        steps.append((ballots, counts, eliminations))

    eph(ballots, finalist_count=6, record_steps=recorder)

    # Determine the last round each candidate appears in counts (for sorting).
    # Finalists appear in the final step; eliminated candidates disappear after
    # their elimination round.
    last_seen_round: dict[str, int] = {}
    all_candidates_set: set[str] = set()
    for round_idx, (_ballots, counts, _eliminations) in enumerate(steps):
        for name in counts:
            last_seen_round[name] = round_idx
            all_candidates_set.add(name)

    # Sort: candidates who survived longest first, then alphabetically for ties.
    all_candidates = sorted(
        all_candidates_set, key=lambda name: (-last_seen_round[name], name)
    )

    num_rounds = len(steps)

    # Build the CSV.
    output = io.StringIO()
    writer = csv.writer(output)

    # Header: last round is "Finalists" since it shows only the final redistributed scores.
    header = ["Candidate"] + [f"Round {i + 1}" for i in range(num_rounds - 1)]
    if num_rounds > 0:
        header.append("Finalists")
    writer.writerow(header)

    # Data rows: show the candidate's points in every round where they appear in
    # counts. Blank cells after the candidate is no longer present.
    for name in all_candidates:
        row: list[str | int] = [name]
        for _ballots, counts, _eliminations in steps:
            if name in counts:
                row.append(counts[name].points)
            else:
                break  # candidate eliminated; leave remaining cells blank
        writer.writerow(row)

    filename = f"{category.election}-{category.id}-eph-elimination.csv"
    response = HttpResponse(output.getvalue(), content_type="text/csv")
    response["Content-Disposition"] = f'attachment; filename="{filename}"'
    return response


@user_passes_test(lambda u: u.is_staff, login_url="/admin/login/")
@permission_required("nominate.report")
def make_work(request: HttpRequest, category_id: int, nominee_id: int) -> HttpResponse:
    category = get_object_or_404(nominate.Category, pk=category_id)
    nominee = get_object_or_404(nominate.Nomination, pk=nominee_id)

    reload_nominee = False

    with transaction.atomic():
        work = models.Work.objects.create(
            name=nominee.proposed_work_name(), category=category
        )
        try:
            models.CanonicalizedNomination.objects.create(nomination=nominee, work=work)
        except IntegrityError:
            reload_nominee = True

    if reload_nominee:
        nominee = get_object_or_404(nominate.Nomination, pk=nominee_id)
        if nominee.work is None:
            # set a message
            messages.error(request, "The nomination could not be canonicalized.")
            sentry_sdk.capture_message(
                "Nomination canonicalization failed",
                level="error",
                extra={"nominee_id": nominee_id},
            )

    next_url = request.GET.get("next")

    if next_url:
        # if we have a next, use that:
        return redirect(next_url)
    else:
        # just redirect to the the canonicalize work change page. This does not need
        # to be generic.
        return redirect("admin:canonicalize_work_change", work.id)
