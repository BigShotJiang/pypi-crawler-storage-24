"""Delivery-domain exceptions per tech_spec §13.4 and §16.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from __future__ import annotations


class InvalidDeliveryContractError(ValueError):
    """Raised when returned delivery contract is structurally invalid."""


class InvalidSubscriptionCategoryError(ValueError):
    """Raised when WS subscription category is missing or invalid."""


class ExecutionDeliveryIdentityCollisionError(RuntimeError):
    """Raised when one identity is used in both execution and delivery domains."""
