"""
Job push: event schema, typed subscriber registry, notifier, and hooks.

Single source of truth for job-push event names and payload schema (events.py).
Registry uses SubscriptionCategory to separate queue_job vs ws_delivery domains.
Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

from mcp_proxy_adapter.core.job_push.events import (
    EVENT_DELIVERY_COMPLETED,
    EVENT_DELIVERY_FAILED,
    EVENT_DELIVERY_PROGRESS,
    EVENT_DELIVERY_STOPPED,
    EVENT_JOB_QUEUED,
    EVENT_JOB_PROGRESS,
    EVENT_JOB_COMPLETED,
    EVENT_JOB_FAILED,
    EVENT_JOB_STOPPED,
    build_delivery_push_message,
    build_push_message,
)
from mcp_proxy_adapter.core.job_push.subscriptions import (
    Subscriber,
    SubscriberRegistry,
    SubscriptionCategory,
)
from mcp_proxy_adapter.core.job_push.notifier import (
    NotificationDomain,
    notify_job_state_changed,
)
from mcp_proxy_adapter.core.job_push.hooks import (
    register_job_push_handler,
    get_job_push_handlers,
    run_job_push_handlers,
)

__all__ = [
    "EVENT_DELIVERY_COMPLETED",
    "EVENT_DELIVERY_FAILED",
    "EVENT_DELIVERY_PROGRESS",
    "EVENT_DELIVERY_STOPPED",
    "EVENT_JOB_QUEUED",
    "EVENT_JOB_PROGRESS",
    "EVENT_JOB_COMPLETED",
    "EVENT_JOB_FAILED",
    "EVENT_JOB_STOPPED",
    "build_delivery_push_message",
    "build_push_message",
    "Subscriber",
    "SubscriberRegistry",
    "SubscriptionCategory",
    "NotificationDomain",
    "notify_job_state_changed",
    "register_job_push_handler",
    "get_job_push_handlers",
    "run_job_push_handlers",
]
