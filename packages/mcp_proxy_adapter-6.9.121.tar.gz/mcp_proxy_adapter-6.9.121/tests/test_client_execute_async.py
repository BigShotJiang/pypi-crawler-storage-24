"""
Unit tests for client execute_async (plan step 03).

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from mcp_proxy_adapter.client.jsonrpc_client.client import JsonRpcClient


class TestClientExecuteAsync:
    """Tests for JsonRpcClient.execute_async."""

    @pytest.mark.asyncio
    async def test_execute_async_returns_accepted_and_ws_id(self) -> None:
        """execute_async returns server response with accepted, ws_id, and delivery."""
        client = JsonRpcClient(host="127.0.0.1", port=8080)
        callback = MagicMock()
        ws_id = "ws-server-issued-1"

        async def fake_rpc(method: str, params: dict) -> dict:
            assert "deliver" + "_id" not in params
            return {
                "jsonrpc": "2.0",
                "result": {
                    "accepted": True,
                    "ws_id": ws_id,
                    "delivery": {"mode": "ws", "terminal_only": True},
                    "message": "Command accepted; result will be delivered via WebSocket",
                },
                "id": 1,
            }

        with patch.object(
            client, "jsonrpc_call", new_callable=AsyncMock, side_effect=fake_rpc
        ):
            with patch(
                "mcp_proxy_adapter.client.jsonrpc_client.command_api.wait_for_terminal_delivery_via_websocket",
                new_callable=AsyncMock,
            ) as mock_wait:

                async def delayed_event(*args: object, **kwargs: object) -> dict:
                    await asyncio.sleep(0.7)
                    return {
                        "event": "delivery_completed",
                        "ws_id": ws_id,
                        "result": {},
                    }

                mock_wait.side_effect = delayed_event

                result = await client.execute_async(
                    "echo", {"message": "hi"}, on_result=callback
                )
                assert result["accepted"] is True
                assert result["ws_id"] == ws_id
                assert "deliver" + "_id" not in result
                assert result.get("delivery", {}).get("mode") == "ws"
                await asyncio.sleep(1.5)
                callback.assert_called_once()
                assert callback.call_args[0][0]["event"] == "delivery_completed"

    @pytest.mark.asyncio
    async def test_execute_async_invokes_callback_with_payload(self) -> None:
        """When WS delivers job_completed, on_result is invoked with event payload."""
        client = JsonRpcClient(host="127.0.0.1", port=8080)
        received: list = []
        ws_id = "ws-abc"

        def on_result(payload: dict) -> None:
            received.append(payload)

        with patch.object(client, "jsonrpc_call", new_callable=AsyncMock) as mock_rpc:
            mock_rpc.return_value = {
                "jsonrpc": "2.0",
                "result": {
                    "accepted": True,
                    "ws_id": ws_id,
                    "delivery": {"mode": "ws", "terminal_only": True},
                    "message": "OK",
                },
                "id": 1,
            }
            with patch(
                "mcp_proxy_adapter.client.jsonrpc_client.command_api.wait_for_terminal_delivery_via_websocket",
                new_callable=AsyncMock,
            ) as mock_wait:

                async def delayed_payload(*args: object, **kwargs: object) -> dict:
                    await asyncio.sleep(0.7)
                    return {
                        "event": "delivery_completed",
                        "ws_id": ws_id,
                        "job_id": ws_id,
                        "result": {"success": True, "data": {"message": "hi"}},
                    }

                mock_wait.side_effect = delayed_payload

                await client.execute_async(
                    "echo", {"message": "hi"}, on_result=on_result
                )
                await asyncio.sleep(1.5)
                assert len(received) == 1
                assert received[0]["event"] == "delivery_completed"
                assert received[0]["result"]["data"]["message"] == "hi"

    @pytest.mark.asyncio
    async def test_execute_async_server_error_cancels_wait_and_raises(self) -> None:
        """When RPC returns error, wait task is cancelled and client raises."""
        client = JsonRpcClient(host="127.0.0.1", port=8080)
        callback = MagicMock()

        with patch.object(client, "jsonrpc_call", new_callable=AsyncMock) as mock_rpc:
            mock_rpc.side_effect = RuntimeError(
                "JSON-RPC error: Method not found (code: -32601)"
            )
            with patch(
                "mcp_proxy_adapter.client.jsonrpc_client.command_api.wait_for_terminal_delivery_via_websocket",
                new_callable=AsyncMock,
            ) as mock_wait:
                mock_wait.return_value = {"event": "delivery_completed", "ws_id": "x", "result": {}}

                with pytest.raises(RuntimeError, match="Method not found"):
                    await client.execute_async("nonexistent", {}, on_result=callback)

        await asyncio.sleep(0.1)
        # Callback should not be invoked (wait task was cancelled before any push)
        callback.assert_not_called()

    @pytest.mark.asyncio
    async def test_execute_async_async_callback_awaited(self) -> None:
        """When on_result is async, it is awaited in the background task."""
        client = JsonRpcClient(host="127.0.0.1", port=8080)
        callback = AsyncMock()

        with patch.object(client, "jsonrpc_call", new_callable=AsyncMock) as mock_rpc:
            mock_rpc.return_value = {
                "jsonrpc": "2.0",
                "result": {
                    "accepted": True,
                    "ws_id": "ws-d1",
                    "delivery": {"mode": "ws", "terminal_only": True},
                    "message": "OK",
                },
                "id": 1,
            }
            with patch(
                "mcp_proxy_adapter.client.jsonrpc_client.command_api.wait_for_terminal_delivery_via_websocket",
                new_callable=AsyncMock,
            ) as mock_wait:

                async def delayed_event(*args: object, **kwargs: object) -> dict:
                    await asyncio.sleep(0.7)
                    return {"event": "job_completed", "result": {}}

                mock_wait.side_effect = delayed_event

                result = await client.execute_async("echo", {}, on_result=callback)
                await asyncio.sleep(1.5)
                assert result["ws_id"] == "ws-d1"
                callback.assert_called_once()
                assert callback.await_count == 1
