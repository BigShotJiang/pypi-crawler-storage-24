"""
Test module: command that updates progress_tracker (for progress visibility tests).

When run via CommandExecutionJob, context["progress_tracker"] is injected by the
adapter; updates must be visible to queue_get_job_status.

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import asyncio

from mcp_proxy_adapter.commands.base import Command, CommandResult
from mcp_proxy_adapter.commands.command_registry import registry


class ProgressTestCommand(Command):
    """Command that updates progress_tracker so get_job_status can be tested."""

    name = "progress_test"
    descr = "Updates progress/description via context progress_tracker"
    use_queue = True

    async def execute(self, steps: int = 5, **kwargs) -> CommandResult:
        """Run for a few seconds, updating progress and description."""
        context = kwargs.pop("context", None) or {}
        pt = context.get("progress_tracker")
        steps = max(1, min(steps, 20))
        for i in range(steps):
            if pt:
                progress = int((i + 1) / steps * 100)
                pt.set_progress(progress)
                pt.set_description(f"Step {i + 1}/{steps} ({progress}%)")
            await asyncio.sleep(0.4)
        return CommandResult(
            success=True,
            data={"steps": steps, "message": "progress_test completed"},
        )

    @classmethod
    def get_schema(cls):
        """Get JSON schema for command parameters."""
        return {
            "type": "object",
            "properties": {
                "steps": {
                    "type": "integer",
                    "default": 5,
                    "description": "Number of steps",
                },
            },
        }


def _auto_register():
    """Auto-register when module is imported."""
    try:
        registry.get_command("progress_test")
    except KeyError:
        registry.register(ProgressTestCommand, "custom")


_auto_register()
