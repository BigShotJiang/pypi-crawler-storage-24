"""
Unit tests for async execution handler (execute_command_async, execute_async JSON-RPC).

Author: Vasiliy Zdanovskiy
email: vasilyvz@gmail.com
"""

import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from mcp_proxy_adapter.api.handlers import handle_json_rpc
from mcp_proxy_adapter.api.handlers_async import execute_command_async
from mcp_proxy_adapter.core.errors import InternalError, MethodNotFoundError


def _make_request_with_delivery_manager(
    ws_id: str = "550e8400-e29b-41d4-a716-446655440000",
):
    """Mock Request with app.state.ws_delivery_manager for execute_command_async."""
    app = MagicMock()
    manager = MagicMock()
    manager.issue_ws_id.return_value = ws_id
    manager.notify_terminal_delivery = AsyncMock()
    app.state.ws_delivery_manager = manager
    req = MagicMock()
    req.app = app
    req.state = MagicMock()
    return req


class TestExecuteCommandAsync:
    """Tests for execute_command_async (server async path)."""

    @pytest.mark.asyncio
    async def test_returns_accepted_and_ws_id(self) -> None:
        """execute_command_async returns ExecuteAsyncAcceptance shape with ws_id."""
        mock_command_class = MagicMock()
        mock_result = MagicMock()
        mock_result.to_dict.return_value = {"success": True, "data": {"message": "hi"}}
        mock_command_class.run = AsyncMock(return_value=mock_result)

        with patch("mcp_proxy_adapter.api.handlers_async.registry") as mock_registry:
            mock_registry.get_command.return_value = mock_command_class
            request = _make_request_with_delivery_manager()
            result = await execute_command_async(
                "echo", {"message": "hi"}, None, None, request
            )

        assert result["accepted"] is True
        assert result["job_id"] is None
        assert result["ws_id"]
        assert isinstance(result["ws_id"], str)
        assert len(result["ws_id"]) > 0
        assert result["delivery"] == {"mode": "ws", "terminal_only": True}
        assert "message" in result
        assert "WebSocket" in result["message"]

    @pytest.mark.asyncio
    async def test_notify_called_on_completion(self) -> None:
        """Background task calls manager.notify_terminal_delivery with completed payload."""
        mock_command_class = MagicMock()
        mock_result = MagicMock()
        mock_result.to_dict.return_value = {"success": True, "data": {"message": "hi"}}
        mock_command_class.run = AsyncMock(return_value=mock_result)

        with patch("mcp_proxy_adapter.api.handlers_async.registry") as mock_registry:
            mock_registry.get_command.return_value = mock_command_class
            request = _make_request_with_delivery_manager()
            out = await execute_command_async(
                "echo", {"message": "hi"}, None, None, request
            )
            ws_id = out["ws_id"]
            await asyncio.sleep(0.1)

            manager = request.app.state.ws_delivery_manager
            manager.notify_terminal_delivery.assert_called_once()
            call_args = manager.notify_terminal_delivery.call_args[0]
            assert call_args[0] == ws_id
            payload = call_args[1]
            assert payload.get("event") == "job_completed"
            assert payload.get("result") == {"success": True, "data": {"message": "hi"}}

    @pytest.mark.asyncio
    async def test_notify_called_on_failure(self) -> None:
        """Background task calls manager.notify_terminal_delivery with failed payload."""
        mock_command_class = MagicMock()
        mock_command_class.run = AsyncMock(side_effect=RuntimeError("command failed"))

        with patch("mcp_proxy_adapter.api.handlers_async.registry") as mock_registry:
            mock_registry.get_command.return_value = mock_command_class
            request = _make_request_with_delivery_manager()
            out = await execute_command_async("failing", {}, None, None, request)
            ws_id = out["ws_id"]
            await asyncio.sleep(0.1)

            manager = request.app.state.ws_delivery_manager
            manager.notify_terminal_delivery.assert_called_once()
            call_args = manager.notify_terminal_delivery.call_args[0]
            assert call_args[0] == ws_id
            payload = call_args[1]
            assert payload.get("event") == "job_failed"
            assert "command failed" in str(payload.get("error", ""))

    @pytest.mark.asyncio
    async def test_method_not_found_raises(self) -> None:
        """execute_command_async raises MethodNotFoundError for unknown command."""
        with patch("mcp_proxy_adapter.api.handlers_async.registry") as mock_registry:
            mock_registry.get_command.side_effect = KeyError("not found")
            request = _make_request_with_delivery_manager()
            with pytest.raises(MethodNotFoundError, match="not found"):
                await execute_command_async("nonexistent", {}, None, None, request)

    @pytest.mark.asyncio
    async def test_raises_when_delivery_manager_missing(self) -> None:
        """execute_command_async raises InternalError when ws_delivery_manager not set."""
        mock_command_class = MagicMock()
        mock_command_class.run = AsyncMock(return_value=MagicMock(to_dict=lambda: {}))
        with patch("mcp_proxy_adapter.api.handlers_async.registry") as mock_registry:
            mock_registry.get_command.return_value = mock_command_class
            request = MagicMock()
            request.app = MagicMock()
            request.app.state.ws_delivery_manager = None
            request.state = MagicMock()
            with pytest.raises(InternalError, match="ws_delivery_manager"):
                await execute_command_async("echo", {}, None, None, request)

    @pytest.mark.asyncio
    async def test_ignores_client_supplied_legacy_correlation(self) -> None:
        """Client-supplied legacy correlation id is ignored; result ws_id is server-generated."""
        mock_command_class = MagicMock()
        mock_result = MagicMock()
        mock_result.to_dict.return_value = {}
        mock_command_class.run = AsyncMock(return_value=mock_result)

        with patch("mcp_proxy_adapter.api.handlers_async.registry") as mock_registry:
            mock_registry.get_command.return_value = mock_command_class
            request = _make_request_with_delivery_manager()
            result = await execute_command_async(
                "echo", {}, "my-deliver-id-123", None, request
            )

        assert "deliver_id" not in result
        assert result["ws_id"] != "my-deliver-id-123"
        assert isinstance(result["ws_id"], str)
        assert len(result["ws_id"]) == 36  # UUID string length
        assert result["ws_id"].count("-") == 4  # UUID format

    @pytest.mark.asyncio
    async def test_strips_legacy_deliver_id_from_command_params(self) -> None:
        """Legacy deliver_id and ws_id in params are not passed to command.run (transport-level)."""
        mock_command_class = MagicMock()
        mock_result = MagicMock()
        mock_result.to_dict.return_value = {}
        mock_command_class.run = AsyncMock(return_value=mock_result)

        with patch("mcp_proxy_adapter.api.handlers_async.registry") as mock_registry:
            mock_registry.get_command.return_value = mock_command_class
            request = _make_request_with_delivery_manager()
            await execute_command_async(
                "echo",
                {
                    "message": "x",
                    "deliver_id": "should-be-removed",
                    "ws_id": "also-remove",
                },
                None,
                None,
                request,
            )
            await asyncio.sleep(0.05)

            run_kwargs = mock_command_class.run.call_args[1]
            assert "deliver_id" not in run_kwargs
            assert "ws_id" not in run_kwargs
            assert run_kwargs.get("message") == "x"
            assert "context" in run_kwargs


class TestHandleJsonRpcExecuteAsync:
    """Tests for handle_json_rpc with method execute_async."""

    @pytest.mark.asyncio
    async def test_execute_async_success(self) -> None:
        """POST execute_async returns result with accepted, ws_id, delivery, message."""
        with patch(
            "mcp_proxy_adapter.api.handlers.execute_command_async",
            new_callable=AsyncMock,
        ) as mock_async:
            mock_async.return_value = {
                "accepted": True,
                "job_id": None,
                "ws_id": "test-ws-123",
                "delivery": {"mode": "ws", "terminal_only": True},
                "message": "Command accepted; result will be delivered via WebSocket",
            }

            result = await handle_json_rpc(
                {
                    "jsonrpc": "2.0",
                    "method": "execute_async",
                    "params": {
                        "command": "echo",
                        "params": {"message": "hello"},
                    },
                    "id": 1,
                }
            )

            assert result["jsonrpc"] == "2.0"
            assert result["id"] == 1
            assert "result" in result
            assert result["result"]["accepted"] is True
            assert result["result"]["ws_id"] == "test-ws-123"
            assert result["result"]["delivery"] == {"mode": "ws", "terminal_only": True}
            assert "deliver_id" not in result["result"]
            mock_async.assert_called_once()
            call_args = mock_async.call_args[0]
            call_kw = mock_async.call_args[1]
            assert call_args[0] == "echo"
            assert call_args[1] == {"message": "hello"}
            assert call_kw.get("request_id") is None
            assert call_kw.get("request") is None

    @pytest.mark.asyncio
    async def test_execute_async_missing_command_returns_error(self) -> None:
        """execute_async without command in params returns JSON-RPC Invalid Request error."""
        result = await handle_json_rpc(
            {
                "jsonrpc": "2.0",
                "method": "execute_async",
                "params": {"params": {}},
                "id": 2,
            }
        )

        assert result["jsonrpc"] == "2.0"
        assert result["id"] == 2
        assert "error" in result
        assert result["error"]["code"] == -32600  # Invalid Request

    @pytest.mark.asyncio
    async def test_execute_async_empty_command_returns_error(self) -> None:
        """execute_async with empty string command returns error."""
        result = await handle_json_rpc(
            {
                "jsonrpc": "2.0",
                "method": "execute_async",
                "params": {"command": "  "},
                "id": 3,
            }
        )

        assert "error" in result
        assert result["error"]["code"] == -32600

    @pytest.mark.asyncio
    async def test_execute_async_invalid_command_propagates(self) -> None:
        """execute_async with invalid command name: MethodNotFoundError propagates from handler."""
        with patch(
            "mcp_proxy_adapter.api.handlers.execute_command_async",
            new_callable=AsyncMock,
        ) as mock_async:
            mock_async.side_effect = MethodNotFoundError("Method not found: bad_cmd")

            with pytest.raises(MethodNotFoundError):
                await handle_json_rpc(
                    {
                        "jsonrpc": "2.0",
                        "method": "execute_async",
                        "params": {"command": "bad_cmd", "params": {}},
                        "id": 4,
                    }
                )


class TestPostApiAsyncRoute:
    """Tests for POST /api/async dedicated route (step 02)."""

    @pytest.mark.asyncio
    async def test_post_api_async_success(self) -> None:
        """POST /api/async returns 200 with accepted, ws_id, delivery, message."""
        from fastapi import FastAPI
        from fastapi.testclient import TestClient

        from mcp_proxy_adapter.api.core.app_factory_routes import setup_routes

        app = FastAPI()
        setup_routes(app)

        with patch(
            "mcp_proxy_adapter.api.core.app_factory_routes.execute_command_async",
            new_callable=AsyncMock,
        ) as mock_async:
            mock_async.return_value = {
                "accepted": True,
                "job_id": None,
                "ws_id": "route-test-ws",
                "delivery": {"mode": "ws", "terminal_only": True},
                "message": "Command accepted; result will be delivered via WebSocket",
            }

            client = TestClient(app)
            response = client.post(
                "/api/async",
                json={"command": "echo", "params": {"message": "hi"}},
            )

        assert response.status_code == 200
        data = response.json()
        assert data["accepted"] is True
        assert data["ws_id"] == "route-test-ws"
        assert data["delivery"] == {"mode": "ws", "terminal_only": True}
        assert "deliver_id" not in data
        mock_async.assert_called_once()
        call_args = mock_async.call_args[0]
        assert call_args[0] == "echo"
        assert call_args[1] == {"message": "hi"}

    @pytest.mark.asyncio
    async def test_post_api_async_missing_command_400(self) -> None:
        """POST /api/async without command returns 400."""
        from fastapi import FastAPI
        from fastapi.testclient import TestClient

        from mcp_proxy_adapter.api.core.app_factory_routes import setup_routes

        app = FastAPI()
        setup_routes(app)
        client = TestClient(app)
        # Schema allows optional command; route validates and returns 400
        response = client.post(
            "/api/async",
            json={"params": {}},
        )
        # FastAPI may return 422 if command is required in schema
        assert response.status_code in (400, 422)
        if response.status_code == 400:
            assert "error" in response.json()

    @pytest.mark.asyncio
    async def test_post_api_async_unknown_command_404(self) -> None:
        """POST /api/async with unknown command returns 404."""
        from fastapi import FastAPI
        from fastapi.testclient import TestClient

        from mcp_proxy_adapter.api.core.app_factory_routes import setup_routes

        app = FastAPI()
        setup_routes(app)

        with patch(
            "mcp_proxy_adapter.api.core.app_factory_routes.execute_command_async",
            new_callable=AsyncMock,
        ) as mock_async:
            mock_async.side_effect = MethodNotFoundError(
                "Method not found: no_such_cmd"
            )

            client = TestClient(app)
            response = client.post(
                "/api/async",
                json={"command": "no_such_cmd", "params": {}},
            )

        assert response.status_code == 404
        assert "error" in response.json()
