
EN:
Vertex2D is a 2D game engine built on pygame-ce and SDL2. It provides a simple and clean API for creating games — scenes, sprites, camera, input, text and UI elements out of the box. The engine handles all the boilerplate: window creation, rendering, input processing and scene management. Designed to be lightweight and easy to pick up, so a project can go from zero to a running game in minutes.



Install: pip install vertex2d
Requires: pygame-ce >= 2.3.0



Quick Start:
from Vertex import Build

vertex = Build("My Game", screen_size=(700, 700), size_window_standart=(700, 700),
    resize=True, ot_pos=False, SafeMode=True, logs=False, DeveLoperMode=False, vsync=True)

class MyGame:
    def __init__(self):
        self.api = vertex.GetFell()
        self.api.SetFPSValue(60)
        self.player = self.api.Square("Player", (255, 0, 0), 350, 350, 150, 150, 0, static=False, center=True)

    def render(self):
        self.api.NewCanvas((75, 75, 75, 255))
        self.api.AllDraw()
        self.api.ClockUse(stabilize_fps=True)
        self.api.Draw()

    def update(self):
        dt = self.api.Get_DeltaTime()
        self.api.Event( { "quit": self.api.End } )
        self.api.UpdateButtonPressedHow()

        self.player.MoveMent("w.a.s.d", 500 * dt)
        """ or:
        if self.api.ButtonPressed("left"): self.player.MoveX(-300 * dt)
        if self.api.ButtonPressed("right"): self.player.MoveX(300 * dt)
        if self.api.ButtonPressed("up"): self.player.MoveY(-300 * dt)
        if self.api.ButtonPressed("down"): self.player.MoveY(300 * dt)
        """

        self.api.AllUpdate()
    
    def run(self):
        self.update()
        self.render()

vertex.NewScene("MyGame", MyGame)
vertex.ChangeScene("MyGame")
vertex.run()
vertex.Destroy()



Telegram: @TeDestry



RU:
Vertex2D — это 2D игровой движок на базе pygame-ce и SDL2. Предоставляет простое и понятное API для создания игр — сцены, спрайты, камера, ввод, текст и UI элементы из коробки. Движок берёт на себя всю рутину: создание окна, рендеринг, обработку ввода и управление сценами. Создан лёгким и простым в освоении — от нуля до работающего проекта за считанные минуты.



Установка: pip install vertex2d
Требования: pygame-ce >= 2.3.0



Быстрый старт:
from Vertex import Build

vertex = Build("My Game", screen_size=(700, 700), size_window_standart=(700, 700),
    resize=True, ot_pos=False, SafeMode=True, logs=False, DeveLoperMode=False, vsync=True)

class MyGame:
    def __init__(self):
        self.api = vertex.GetFell()
        self.api.SetFPSValue(60)
        self.player = self.api.Square("Player", (255, 0, 0), 350, 350, 150, 150, 0, static=False, center=True)

    def render(self):
        self.api.NewCanvas((75, 75, 75, 255))
        self.api.AllDraw()
        self.api.ClockUse(stabilize_fps=True)
        self.api.Draw()

    def update(self):
        dt = self.api.Get_DeltaTime()
        self.api.Event( { "quit": self.api.End } )
        self.api.UpdateButtonPressedHow()

        self.player.MoveMent("w.a.s.d", 500 * dt)
        """ или:
        if self.api.ButtonPressed("left"): self.player.MoveX(-300 * dt)
        if self.api.ButtonPressed("right"): self.player.MoveX(300 * dt)
        if self.api.ButtonPressed("up"): self.player.MoveY(-300 * dt)
        if self.api.ButtonPressed("down"): self.player.MoveY(300 * dt)
        """

        self.api.AllUpdate()
    
    def run(self):
        self.update()
        self.render()

vertex.NewScene("MyGame", MyGame)
vertex.ChangeScene("MyGame")
vertex.run()
vertex.Destroy()



Telegram: @TeDestry
