# Free Fire Guest Account Generator

A Python library to generate Free Fire guest accounts programmatically.

## Installation

```bash
pip install freefire-guest-generator