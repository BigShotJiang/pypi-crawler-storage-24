from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from rawctx.formats.osi import assign_measure_datasets, read_osi


@dataclass(frozen=True)
class Measure:
    name: str
    dataset: str | None
    model: str
    path: str
    expression: dict[str, Any] | None
    description: str | None = None
    ai_context: Any = None


@dataclass(frozen=True)
class Dimension:
    name: str
    dataset: str
    model: str
    path: str
    is_time: bool
    label: str | None
    description: str | None
    expression: dict[str, Any] | None
    ai_context: Any = None


@dataclass(frozen=True)
class Relationship:
    name: str
    from_dataset: str
    to_dataset: str
    from_columns: list[str]
    to_columns: list[str]
    model: str
    path: str
    ai_context: Any = None


@dataclass(frozen=True)
class SemanticModel:
    name: str
    path: str
    datasets: list[str] = field(default_factory=list)
    measures: list[Measure] = field(default_factory=list)
    dimensions: list[Dimension] = field(default_factory=list)
    relationships: list[Relationship] = field(default_factory=list)


@dataclass(frozen=True)
class LoadedPackage:
    package: str
    version: str
    model_paths: list[str]
    snapshot_dir: Path
    datasets: list[str] = field(default_factory=list)
    measures: list[Measure] = field(default_factory=list)
    dimensions: list[Dimension] = field(default_factory=list)
    relationships: list[Relationship] = field(default_factory=list)
    models: list[SemanticModel] = field(default_factory=list)


def _clean_str(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    cleaned = value.strip()
    return cleaned or None


def _copy_mapping(value: Any) -> dict[str, Any] | None:
    if not isinstance(value, dict):
        return None
    return deepcopy(value)


def _copy_ai_context(value: Any) -> Any:
    return deepcopy(value)


def _string_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    return [item.strip() for item in value if isinstance(item, str) and item.strip()]


def build_loaded_package(
    *,
    package: str,
    version: str,
    snapshot_dir: Path,
    model_paths: list[str],
) -> LoadedPackage:
    datasets: list[str] = []
    measures: list[Measure] = []
    dimensions: list[Dimension] = []
    relationships: list[Relationship] = []
    models: list[SemanticModel] = []
    seen_datasets: set[str] = set()

    for model_path in model_paths:
        document = read_osi(snapshot_dir / model_path)
        semantic_models = document.get("semantic_model")
        if not isinstance(semantic_models, list):
            continue

        for semantic_model in semantic_models:
            if not isinstance(semantic_model, dict):
                continue

            model_name = _clean_str(semantic_model.get("name")) or ""
            raw_datasets = semantic_model.get("datasets")
            raw_relationships = semantic_model.get("relationships")
            raw_measures = semantic_model.get("metrics")
            if not isinstance(raw_datasets, list):
                raw_datasets = []
            if not isinstance(raw_relationships, list):
                raw_relationships = []
            if not isinstance(raw_measures, list):
                raw_measures = []

            model_dataset_names: list[str] = []
            dataset_field_names: dict[str, set[str]] = {}

            for raw_dataset in raw_datasets:
                if not isinstance(raw_dataset, dict):
                    continue
                dataset_name = _clean_str(raw_dataset.get("name"))
                if dataset_name is None:
                    continue
                model_dataset_names.append(dataset_name)
                if dataset_name not in seen_datasets:
                    seen_datasets.add(dataset_name)
                    datasets.append(dataset_name)

                raw_fields = raw_dataset.get("fields")
                if not isinstance(raw_fields, list):
                    raw_fields = []
                dataset_field_names[dataset_name] = {
                    field_name
                    for raw_field in raw_fields
                    if isinstance(raw_field, dict)
                    for field_name in [_clean_str(raw_field.get("name"))]
                    if field_name is not None
                }

            measure_datasets = assign_measure_datasets(raw_measures, model_dataset_names, dataset_field_names)

            model_dimensions: list[Dimension] = []
            for raw_dataset in raw_datasets:
                if not isinstance(raw_dataset, dict):
                    continue
                dataset_name = _clean_str(raw_dataset.get("name"))
                if dataset_name is None:
                    continue
                raw_fields = raw_dataset.get("fields")
                if not isinstance(raw_fields, list):
                    raw_fields = []
                for raw_field in raw_fields:
                    if not isinstance(raw_field, dict) or not isinstance(raw_field.get("dimension"), dict):
                        continue
                    field_name = _clean_str(raw_field.get("name"))
                    if field_name is None:
                        continue
                    dimension = Dimension(
                        name=field_name,
                        dataset=dataset_name,
                        model=model_name,
                        path=model_path,
                        is_time=bool(raw_field["dimension"].get("is_time", False)),
                        label=_clean_str(raw_field.get("label")),
                        description=_clean_str(raw_field.get("description")),
                        expression=_copy_mapping(raw_field.get("expression")),
                        ai_context=_copy_ai_context(raw_field.get("ai_context")),
                    )
                    model_dimensions.append(dimension)
                    dimensions.append(dimension)

            model_measures: list[Measure] = []
            for raw_measure, dataset_name in zip(raw_measures, measure_datasets, strict=False):
                if not isinstance(raw_measure, dict):
                    continue
                measure_name = _clean_str(raw_measure.get("name"))
                if measure_name is None:
                    continue
                measure = Measure(
                    name=measure_name,
                    dataset=dataset_name,
                    model=model_name,
                    path=model_path,
                    expression=_copy_mapping(raw_measure.get("expression")),
                    description=_clean_str(raw_measure.get("description")),
                    ai_context=_copy_ai_context(raw_measure.get("ai_context")),
                )
                model_measures.append(measure)
                measures.append(measure)

            model_relationships: list[Relationship] = []
            for raw_relationship in raw_relationships:
                if not isinstance(raw_relationship, dict):
                    continue
                name = _clean_str(raw_relationship.get("name"))
                from_dataset = _clean_str(raw_relationship.get("from"))
                to_dataset = _clean_str(raw_relationship.get("to"))
                if name is None or from_dataset is None or to_dataset is None:
                    continue
                relationship = Relationship(
                    name=name,
                    from_dataset=from_dataset,
                    to_dataset=to_dataset,
                    from_columns=_string_list(raw_relationship.get("from_columns")),
                    to_columns=_string_list(raw_relationship.get("to_columns")),
                    model=model_name,
                    path=model_path,
                    ai_context=_copy_ai_context(raw_relationship.get("ai_context")),
                )
                model_relationships.append(relationship)
                relationships.append(relationship)

            models.append(
                SemanticModel(
                    name=model_name,
                    path=model_path,
                    datasets=model_dataset_names,
                    measures=model_measures,
                    dimensions=model_dimensions,
                    relationships=model_relationships,
                )
            )

    return LoadedPackage(
        package=package,
        version=version,
        model_paths=list(model_paths),
        snapshot_dir=snapshot_dir,
        datasets=datasets,
        measures=measures,
        dimensions=dimensions,
        relationships=relationships,
        models=models,
    )
