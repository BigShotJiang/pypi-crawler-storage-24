from __future__ import annotations

from urllib.parse import urlparse

import click

from rawctx.commands.common import echo_json, raise_click_for_error
from rawctx.sdk import client as rawctx_client


@click.command()
@click.option("--registry", "registry_override", default=None, help="Registry base URL")
@click.option("--id-token", default=None, help="JWT id_token from OAuth callback")
@click.option("--token-name", default="rawctx-cli", show_default=True, help="Name for the generated API token")
@click.option("--expires-in-days", type=int, default=None, help="Token expiration in days")
@click.option("--no-browser", is_flag=True, default=False, help="Do not open browser automatically")
@click.option("--json", "json_output", is_flag=True, default=False, help="Print JSON response")
def login(
    registry_override: str | None,
    id_token: str | None,
    token_name: str,
    expires_in_days: int | None,
    no_browser: bool,
    json_output: bool,
) -> None:
    """Log in and store a local API token. [user]"""

    def progress(event: dict[str, str]) -> None:
        event_type = event.get("type")
        if event_type == "authorize_url":
            prompt_label = event.get("prompt_label", "Sign in").lower()
            click.echo(f"Open this URL and {prompt_label}:\n{event.get('authorize_url', '')}")
        elif event_type == "waiting":
            click.echo("Waiting for OAuth login to complete in browser...")
        elif event_type == "manual_token_required":
            click.echo("Automatic token capture is unavailable on this registry.")
            click.echo("After login, copy the id_token and paste it below.")

    def prompt_for_id_token(label: str) -> str:
        return click.prompt(label, type=str)

    try:
        with rawctx_client(registry=registry_override) as sdk_client:
            payload = sdk_client.login(
                id_token=id_token,
                token_name=token_name,
                expires_in_days=expires_in_days,
                no_browser=no_browser,
                progress=None if json_output else progress,
                prompt_for_id_token=prompt_for_id_token,
            )
    except Exception as exc:
        raise_click_for_error(exc)
        return

    if json_output:
        echo_json(payload)
        return

    click.echo(f"Login succeeded. API token saved to {payload['config_path']}")
    registry_host = urlparse(payload["registry"]).netloc or payload["registry"]
    tenant_display_name = payload.get("tenant_display_name")
    if tenant_display_name:
        click.echo(f"Registry: {registry_host}")
        click.echo(f"Workspace: {tenant_display_name}")
    click.echo(f"Token id: {payload['token_id']}")


@click.command()
@click.option("--local-only", is_flag=True, default=False, help="Delete local token only")
@click.option("--json", "json_output", is_flag=True, default=False, help="Print JSON response")
def logout(local_only: bool, json_output: bool) -> None:
    """Log out and remove the local API token. [user]"""

    try:
        with rawctx_client() as sdk_client:
            payload = sdk_client.logout(local_only=local_only)
    except Exception as exc:
        raise_click_for_error(exc)
        return

    if json_output:
        echo_json(payload)
        return

    if not payload["had_token"]:
        click.echo("No local auth token found.")
        return

    if payload["local_only"]:
        click.echo("Logged out locally.")
    elif payload["revoked"]:
        click.echo("Token revoked on server and removed locally.")
    else:
        click.echo("Local token removed. Server token could not be revoked.")
