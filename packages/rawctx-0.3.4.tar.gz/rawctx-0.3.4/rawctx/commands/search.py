from __future__ import annotations

import click

from rawctx.commands.common import echo_json, raise_click_for_error
from rawctx.sdk import HIDE_ACTIVITY_SIGNALS, client as rawctx_client


@click.command()
@click.argument("query", required=False, default=None)
@click.option("--format", "format_filter", default=None)
@click.option("--source-format", "source_format_filter", default=None)
@click.option("--origin", "origin_filter", default="all", type=click.Choice(["all", "native", "indexed"], case_sensitive=False))
@click.option("--domain", default=None)
@click.option("--source", default=None)
@click.option("--tags", default=None, help="Comma-separated tags")
@click.option("--sort", default="recent", show_default=True, help='Sort results by "recent" or "name".')
@click.option("--page", default=1, type=int, show_default=True)
@click.option("--size", default=20, type=int, show_default=True)
@click.option("--json", "json_output", is_flag=True, default=False)
@click.option("--offline", is_flag=True, default=False)
@click.option("--registry", "registry_override", default=None, help="Registry base URL")
def search(
    query: str | None,
    format_filter: str | None,
    source_format_filter: str | None,
    origin_filter: str,
    domain: str | None,
    source: str | None,
    tags: str | None,
    sort: str,
    page: int,
    size: int,
    json_output: bool,
    offline: bool,
    registry_override: str | None,
) -> None:
    """Search packages in rawctx Hub. [user]"""

    try:
        with rawctx_client(registry=registry_override) as sdk_client:
            payload = sdk_client.search(
                query,
                format=format_filter,
                source_format=source_format_filter,
                origin=origin_filter,
                domain=domain,
                source=source,
                tags=tags,
                sort=sort,
                page=page,
                size=size,
                offline=offline,
            )
    except Exception as exc:
        raise_click_for_error(exc)
        return

    if json_output:
        echo_json(payload)
        return

    items = payload["items"]
    meta = payload["meta"]

    query_mode = str(meta.get("query_mode") or "")
    expanded = bool(meta.get("expanded"))
    applied_rewrite = meta.get("applied_rewrite")
    if query_mode == "expanded" or expanded:
        suffix = f" ({applied_rewrite})" if isinstance(applied_rewrite, str) and applied_rewrite.strip() else ""
        click.echo(f"Expanded search applied{suffix}.")

    if not items:
        click.echo("No cached packages matched." if offline else "No packages found.")
        return

    for item in items:
        description = str(item.get("description") or "").strip()
        tag_preview = ", ".join(item.get("tags", [])[:3]) if item.get("tags") else "-"
        format_name = str(item.get("format") or "unknown")
        osi_preview = item.get("latest_osi_version") or ("1.0" if format_name.lower() == "osi" else "-")
        parts = [
            f"@{item['scope']}/{item['name']:<35}",
            f"format={format_name:<8}",
            f"source_format={str(item.get('source_format') or '-'):<10}",
            f"origin={str(item.get('origin') or 'native'):<7}",
            f"osi={str(osi_preview):<4}",
            f"tags={tag_preview:<24}",
        ]
        if not HIDE_ACTIVITY_SIGNALS:
            parts.append(f"stars={int(item.get('star_count') or 0):<4} downloads={int(item.get('download_count') or 0):<6}")
        if description:
            parts.append(description)
        click.echo(" ".join(parts))
    click.echo(f"page={meta.get('page', page)} size={meta.get('size', size)} total={meta.get('total', len(items))}")
