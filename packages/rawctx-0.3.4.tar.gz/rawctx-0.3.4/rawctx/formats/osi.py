from __future__ import annotations

from dataclasses import dataclass, field
import json
from pathlib import Path
from typing import Any

from jsonschema import Draft202012Validator
import yaml
from yaml import YAMLError

from rawctx.packaging.manifest import ValidationError


@dataclass(frozen=True)
class OsiSummary:
    datasets: int
    measures: int
    dimensions: int
    relationships: int
    has_ai_context: bool
    dataset_measures: tuple["OsiDatasetMeasureDetail", ...] = field(default_factory=tuple)


@dataclass(frozen=True)
class OsiDatasetMeasureDetail:
    model: str | None
    dataset: str
    measure_count: int
    measures: tuple[str | None, ...]


def _schema_path() -> Path:
    return Path(__file__).resolve().parent.parent / "schemas" / "osi" / "v1.0" / "schema.json"


def _load_schema() -> dict[str, Any]:
    schema_file = _schema_path()
    try:
        with schema_file.open("r", encoding="utf-8") as handle:
            return json.load(handle)
    except OSError as exc:
        raise ValidationError("failed to load vendored OSI schema", schema_file) from exc


def _read_yaml(path: Path) -> dict[str, Any]:
    try:
        with path.open("r", encoding="utf-8") as handle:
            data = yaml.safe_load(handle)
    except YAMLError as exc:
        line = getattr(getattr(exc, "problem_mark", None), "line", None)
        col = getattr(getattr(exc, "problem_mark", None), "column", None)
        raise ValidationError(
            "invalid YAML syntax",
            path,
            line=None if line is None else line + 1,
            column=None if col is None else col + 1,
        ) from exc
    except OSError as exc:
        raise ValidationError("failed to read OSI file", path) from exc

    if not isinstance(data, dict):
        raise ValidationError("OSI document root must be a mapping", path)
    return data


def _first_schema_error(path: Path, data: dict[str, Any], schema: dict[str, Any]) -> ValidationError | None:
    validator = Draft202012Validator(schema)
    for error in validator.iter_errors(data):
        field = ".".join(str(part) for part in error.absolute_path)
        return ValidationError(
            message=error.message,
            file_path=path,
            field=field or None,
        )
    return None


def _has_ai_context(obj: Any) -> bool:
    if isinstance(obj, dict):
        if "ai_context" in obj:
            ai_context = obj["ai_context"]
            if ai_context is not None:
                if not (isinstance(ai_context, str) and not ai_context.strip()) and not (isinstance(ai_context, (list, dict)) and len(ai_context) == 0):
                    return True
        for value in obj.values():
            if _has_ai_context(value):
                return True
        return False
    if isinstance(obj, list):
        return any(_has_ai_context(item) for item in obj)
    return False


def _normalized_non_empty_string(value: Any) -> str | None:
    if not isinstance(value, str):
        return None
    normalized = value.strip()
    return normalized if normalized else None


def _metric_name(metric: Any) -> str | None:
    if not isinstance(metric, dict):
        return None
    return _normalized_non_empty_string(metric.get("name"))


def _metric_owner_from_expression(metric: dict[str, Any], dataset_names: list[str]) -> str | None:
    expression = metric.get("expression")
    if not isinstance(expression, dict):
        return None

    dialects = expression.get("dialects")
    if not isinstance(dialects, list):
        return None

    first_position_by_dataset: dict[str, int] = {}
    for dialect in dialects:
        if not isinstance(dialect, dict):
            continue
        raw_expression = _normalized_non_empty_string(dialect.get("expression"))
        if raw_expression is None:
            continue
        lowered = raw_expression.lower()
        for dataset_name in dataset_names:
            token = f"{dataset_name.lower()}."
            position = lowered.find(token)
            if position < 0:
                continue
            current = first_position_by_dataset.get(dataset_name)
            if current is None or position < current:
                first_position_by_dataset[dataset_name] = position

    if not first_position_by_dataset:
        return None

    return min(
        first_position_by_dataset.items(),
        key=lambda item: (item[1], dataset_names.index(item[0])),
    )[0]


def assign_measure_datasets(
    measures: list[Any],
    dataset_names: list[str],
    dataset_field_names: dict[str, set[str]],
) -> list[str | None]:
    owners: list[str | None] = []
    if not dataset_names:
        return [None for _ in measures]

    for measure in measures:
        if not isinstance(measure, dict):
            owners.append(None)
            continue

        owner: str | None = None
        for key in ("dataset", "source_dataset", "source", "table", "from"):
            candidate = _normalized_non_empty_string(measure.get(key))
            if candidate and candidate in dataset_names:
                owner = candidate
                break

        measure_name = _metric_name(measure)
        if owner is None and measure_name is not None:
            matched_datasets = [name for name, fields in dataset_field_names.items() if measure_name in fields]
            if len(matched_datasets) == 1:
                owner = matched_datasets[0]

        if owner is None:
            owner = _metric_owner_from_expression(measure, dataset_names)

        if owner is None and len(dataset_names) == 1:
            owner = dataset_names[0]

        owners.append(owner)

    return owners


def _assign_metric_names_to_datasets(
    metrics: list[Any],
    dataset_names: list[str],
    dataset_field_names: dict[str, set[str]],
) -> tuple[dict[str, list[str | None]], list[str | None]]:
    assigned: dict[str, list[str | None]] = {name: [] for name in dataset_names}
    unassigned: list[str | None] = []
    owners = assign_measure_datasets(metrics, dataset_names, dataset_field_names)
    for metric, owner in zip(metrics, owners, strict=False):
        metric_name = _metric_name(metric)
        if owner is None:
            unassigned.append(metric_name)
            continue
        assigned[owner].append(metric_name)

    return assigned, unassigned


def read_osi(path: Path) -> dict[str, Any]:
    data = _read_yaml(path)
    schema = _load_schema()
    schema_error = _first_schema_error(path, data, schema)
    if schema_error is not None:
        raise schema_error
    return data


def _summary(data: dict[str, Any]) -> OsiSummary:
    semantic_models = data.get("semantic_model", [])
    if not isinstance(semantic_models, list):
        semantic_models = []

    datasets = 0
    measures = 0
    dimensions = 0
    relationships = 0
    dataset_measure_details: list[OsiDatasetMeasureDetail] = []

    for semantic_model in semantic_models:
        if not isinstance(semantic_model, dict):
            continue

        model_name = _normalized_non_empty_string(semantic_model.get("name"))
        model_metrics = semantic_model.get("metrics", [])
        model_relationships = semantic_model.get("relationships", [])
        model_datasets = semantic_model.get("datasets", [])
        metric_names = [_metric_name(metric) for metric in model_metrics] if isinstance(model_metrics, list) else []
        metric_names_by_dataset: dict[str, list[str | None]] = {}
        unassigned_metric_names: list[str | None] = []

        if isinstance(model_metrics, list):
            measures += len(model_metrics)
            if isinstance(model_datasets, list):
                dataset_names = [
                    name
                    for dataset in model_datasets
                    if isinstance(dataset, dict)
                    for name in [_normalized_non_empty_string(dataset.get("name"))]
                    if name is not None
                ]
                dataset_field_names: dict[str, set[str]] = {}
                for dataset in model_datasets:
                    if not isinstance(dataset, dict):
                        continue
                    dataset_name = _normalized_non_empty_string(dataset.get("name"))
                    if dataset_name is None:
                        continue
                    fields = dataset.get("fields", [])
                    if not isinstance(fields, list):
                        continue
                    names: set[str] = set()
                    for field in fields:
                        if not isinstance(field, dict):
                            continue
                        field_name = _normalized_non_empty_string(field.get("name"))
                        if field_name is not None:
                            names.add(field_name)
                    dataset_field_names[dataset_name] = names
                metric_names_by_dataset, unassigned_metric_names = _assign_metric_names_to_datasets(
                    model_metrics,
                    dataset_names,
                    dataset_field_names,
                )
        if isinstance(model_relationships, list):
            relationships += len(model_relationships)

        if isinstance(model_datasets, list):
            datasets += len(model_datasets)
            single_unnamed_dataset = (
                len(model_datasets) == 1
                and isinstance(model_datasets[0], dict)
                and _normalized_non_empty_string(model_datasets[0].get("name")) is None
            )
            for dataset in model_datasets:
                if not isinstance(dataset, dict):
                    continue
                fields = dataset.get("fields", [])
                if not isinstance(fields, list):
                    fields = []
                dataset_name = _normalized_non_empty_string(dataset.get("name"))
                dataset_label = dataset_name if dataset_name is not None else "(unnamed dataset)"
                dataset_measure_names: list[str | None] = []
                if dataset_name is not None:
                    dataset_measure_names = metric_names_by_dataset.get(dataset_name, [])
                elif single_unnamed_dataset:
                    dataset_measure_names = metric_names

                dataset_measure_details.append(
                    OsiDatasetMeasureDetail(
                        model=model_name,
                        dataset=dataset_label,
                        measure_count=len(dataset_measure_names),
                        measures=tuple(dataset_measure_names),
                    )
                )

                for field in fields:
                    if not isinstance(field, dict):
                        continue
                    if isinstance(field.get("dimension"), dict):
                        dimensions += 1

            if single_unnamed_dataset:
                unassigned_metric_names = []

        if unassigned_metric_names:
            dataset_measure_details.append(
                OsiDatasetMeasureDetail(
                    model=model_name,
                    dataset="(unassigned metrics)",
                    measure_count=len(unassigned_metric_names),
                    measures=tuple(unassigned_metric_names),
                )
            )

    return OsiSummary(
        datasets=datasets,
        measures=measures,
        dimensions=dimensions,
        relationships=relationships,
        has_ai_context=_has_ai_context(data),
        dataset_measures=tuple(dataset_measure_details),
    )


def validate_osi(path: Path) -> OsiSummary:
    data = read_osi(path)
    return _summary(data)
