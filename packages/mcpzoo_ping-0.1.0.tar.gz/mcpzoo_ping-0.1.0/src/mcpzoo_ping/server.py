import urllib.request
import urllib.error
import time
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("ping")

@mcp.tool()
def ping_url(url: str, timeout: int = 5) -> str:
    """检测 HTTP URL 是否可访问并返回耗时。"""
    if not url.startswith(('http://', 'https://')):
        url = 'http://' + url
        
    req = urllib.request.Request(
        url, method="HEAD",
        headers={'User-Agent': 'Mozilla/5.0'}
    )
    
    start_time = time.time()
    try:
        with urllib.request.urlopen(req, timeout=timeout) as response:
            elapsed = (time.time() - start_time) * 1000
            return f"状态: {response.status} {response.reason}\n耗时: {elapsed:.2f} ms"
    except urllib.error.HTTPError as e:
        elapsed = (time.time() - start_time) * 1000
        return f"状态: {e.code} {e.reason}\n耗时: {elapsed:.2f} ms"
    except urllib.error.URLError as e:
        return f"连接失败: {e.reason}"
    except Exception as e:
        return f"发生错误: {e}"

def main():
    mcp.run()

if __name__ == "__main__":
    main()
