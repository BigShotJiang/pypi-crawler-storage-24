# mcpzoo-ping

> URL 连通检测 — 检测 HTTP URL 是否可访问并返回耗时

## Installation

```bash
uvx mcpzoo-ping
```

## uvx JSON

```json
{
  "mcpServers": {
    "ping": {
      "args": ["mcpzoo-ping"],
      "command": "uvx"
    }
  }
}
```
