"""Policy enforcement — cost tracking, duration limits, gate timeouts.

The policy engine checks resource limits after each cost/progress update
and triggers appropriate state transitions when limits are exceeded.
"""

from __future__ import annotations

import logging
import time
from datetime import datetime, timezone

from parsica_ventures.models import (
    Venture,
    VenturePolicy,
    VentureError,
    FailureCategory,
)


logger = logging.getLogger(__name__)


class PolicyEngine:
    """Enforces venture policy limits and approval gates."""

    def check_cost(self, venture: Venture) -> VentureError | None:
        """Check if venture has exceeded its cost ceiling.

        Returns a VentureError if exceeded, None if within limits.
        """
        if venture.policy.max_cost_usd is None:
            return None

        if venture.total_cost_usd > venture.policy.max_cost_usd:
            logger.warning(
                "Venture %s exceeded cost ceiling: $%.4f > $%.4f",
                venture.id,
                venture.total_cost_usd,
                venture.policy.max_cost_usd,
            )
            return VentureError(
                category=FailureCategory.POLICY,
                message=(
                    f"Cost ceiling exceeded: ${venture.total_cost_usd:.4f} > "
                    f"${venture.policy.max_cost_usd:.4f}"
                ),
                recoverable=False,
            )
        return None

    def check_duration(self, venture: Venture) -> VentureError | None:
        """Check if venture has exceeded its max duration.

        Returns a VentureError if exceeded, None if within limits.
        """
        if venture.policy.max_duration_hours is None:
            return None
        if venture.started_at is None:
            return None

        now = datetime.now(timezone.utc)
        elapsed_hours = (now - venture.started_at).total_seconds() / 3600.0

        if elapsed_hours > venture.policy.max_duration_hours:
            logger.warning(
                "Venture %s exceeded duration limit: %.1fh > %.1fh",
                venture.id,
                elapsed_hours,
                venture.policy.max_duration_hours,
            )
            return VentureError(
                category=FailureCategory.POLICY,
                message=(
                    f"Duration limit exceeded: {elapsed_hours:.1f}h > "
                    f"{venture.policy.max_duration_hours:.1f}h"
                ),
                recoverable=False,
            )
        return None

    def check_context_resets(self, venture: Venture) -> VentureError | None:
        """Check if venture has exceeded max context resets (checkpoint cycles).

        Returns a VentureError if exceeded, None if within limits.
        """
        if venture.policy.max_context_resets is None:
            return None

        reset_count = len(venture.checkpoints)
        if reset_count > venture.policy.max_context_resets:
            logger.warning(
                "Venture %s exceeded context reset limit: %d > %d",
                venture.id,
                reset_count,
                venture.policy.max_context_resets,
            )
            return VentureError(
                category=FailureCategory.POLICY,
                message=(
                    f"Context reset limit exceeded: {reset_count} > "
                    f"{venture.policy.max_context_resets}"
                ),
                recoverable=False,
            )
        return None

    def check_all(self, venture: Venture) -> VentureError | None:
        """Run all policy checks. Returns the first violation found, or None."""
        for check in (self.check_cost, self.check_duration, self.check_context_resets):
            error = check(venture)
            if error:
                return error
        return None

    def should_checkpoint(self, venture: Venture, tokens_used: int, context_window: int) -> bool:
        """Check if the venture should checkpoint based on token usage.

        Returns True if token_threshold is exceeded.
        """
        if venture.policy.checkpoint_strategy != "token":
            return False
        if context_window <= 0:
            return False

        usage_ratio = tokens_used / context_window
        return usage_ratio >= venture.policy.checkpoint_threshold

    def needs_approval(self, venture: Venture, action: str) -> bool:
        """Check if an action requires approval based on policy.

        Returns True if the action is in the approval_gates list
        and autonomy mode is not 'full'.
        """
        if venture.policy.autonomy == "full":
            return False
        if venture.policy.autonomy == "supervised":
            return True  # Everything needs approval in supervised mode
        # "checkpoints" mode — only explicit gates
        return action in venture.policy.approval_gates

    def get_retry_policy(self, error: VentureError) -> dict:
        """Get retry policy based on failure category.

        Returns dict with max_retries and backoff_seconds.
        """
        policies = {
            FailureCategory.TRANSIENT: {"max_retries": 3, "backoff_seconds": [1, 5, 30]},
            FailureCategory.CRASH: {"max_retries": 1, "backoff_seconds": [5]},
            FailureCategory.LOGIC: {"max_retries": 0, "backoff_seconds": []},
            FailureCategory.POLICY: {"max_retries": 0, "backoff_seconds": []},
            FailureCategory.CHECKPOINT: {"max_retries": 3, "backoff_seconds": [1, 3, 10]},
        }
        return policies.get(error.category, {"max_retries": 0, "backoff_seconds": []})

    def can_retry(self, error: VentureError) -> bool:
        """Check if a failed venture can be retried.

        LOGIC failures are never retryable (agent said it can't proceed).
        POLICY failures are never retryable (limits exceeded).
        """
        policy = self.get_retry_policy(error)
        return error.retry_count < policy["max_retries"] and error.recoverable
