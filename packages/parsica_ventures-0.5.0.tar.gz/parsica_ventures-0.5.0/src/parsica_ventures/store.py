"""SQLite persistence for ventures.

Uses WAL mode for concurrent read/write safety. Schema versioned
for forward-compatible migrations.

All datetime fields serialize as ISO 8601 strings in JSON columns.
"""

from __future__ import annotations

import json
import logging
import sqlite3
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from parsica_ventures.models import (
    Venture,
    VentureState,
    Checkpoint,
    ProgressUpdate,
    StateTransition,
    ApprovalRequest,
    VentureNotification,
)

logger = logging.getLogger(__name__)

CURRENT_SCHEMA_VERSION = 2


def _json_serial(obj: Any) -> str:
    """JSON serializer for objects not serializable by default."""
    if isinstance(obj, datetime):
        return obj.isoformat()
    raise TypeError(f"Object of type {type(obj)} is not JSON serializable")


def _to_json(obj: Any) -> str:
    """Serialize a pydantic model or dict to JSON string."""
    if hasattr(obj, "model_dump"):
        return json.dumps(obj.model_dump(), default=_json_serial)
    return json.dumps(obj, default=_json_serial)


def _to_json_list(items: list[Any]) -> str:
    """Serialize a list of pydantic models to JSON string."""
    return json.dumps(
        [item.model_dump() if hasattr(item, "model_dump") else item for item in items],
        default=_json_serial,
    )


class VentureStore:
    """SQLite-backed venture persistence.

    Location: ~/.parsica/ventures/ventures.db (configurable)
    Journal mode: WAL (concurrent readers + one writer)
    """

    def __init__(self, db_path: str | Path | None = None):
        if db_path is None:
            db_path = Path.home() / ".parsica" / "ventures" / "ventures.db"
        self._db_path = Path(db_path)
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn: sqlite3.Connection | None = None
        self._connect()
        self._init_schema()

    def _connect(self) -> None:
        self._conn = sqlite3.connect(
            str(self._db_path),
            check_same_thread=False,
            timeout=10.0,  # Wait up to 10s for locks (concurrent access)
        )
        self._conn.row_factory = sqlite3.Row
        # WAL mode for concurrent safety — retry on lock contention during init
        for pragma in ("PRAGMA journal_mode=WAL;", "PRAGMA synchronous=NORMAL;", "PRAGMA foreign_keys=ON;"):
            for attempt in range(3):
                try:
                    self._conn.execute(pragma)
                    break
                except sqlite3.OperationalError:
                    if attempt == 2:
                        raise
                    time.sleep(0.1 * (attempt + 1))
        logger.info("Venture store opened: %s (WAL mode)", self._db_path)

    def _init_schema(self) -> None:
        """Create tables if they don't exist. Handles schema versioning."""
        if self._conn is None:
            raise RuntimeError("Venture store is closed")
        cur = self._conn.cursor()

        # Schema version table
        cur.execute("""
            CREATE TABLE IF NOT EXISTS schema_version (
                version INTEGER NOT NULL,
                applied_at TEXT NOT NULL
            )
        """)

        # Check current version
        row = cur.execute(
            "SELECT MAX(version) as v FROM schema_version"
        ).fetchone()
        current_version = row["v"] if row and row["v"] else 0

        if current_version < CURRENT_SCHEMA_VERSION:
            self._migrate(cur, current_version)

        self._conn.commit()

    def _migrate(self, cur: sqlite3.Cursor, from_version: int) -> None:
        """Run migrations from from_version to CURRENT_SCHEMA_VERSION."""
        if from_version < 1:
            self._migrate_v1(cur)
            cur.execute(
                "INSERT INTO schema_version (version, applied_at) VALUES (?, ?)",
                (1, datetime.now(timezone.utc).isoformat()),
            )
            logger.info("Migrated venture store to schema v1")

        if from_version < 2:
            self._migrate_v2(cur)
            cur.execute(
                "INSERT INTO schema_version (version, applied_at) VALUES (?, ?)",
                (2, datetime.now(timezone.utc).isoformat()),
            )
            logger.info("Migrated venture store to schema v2")

    def _migrate_v1(self, cur: sqlite3.Cursor) -> None:
        """Initial schema — v1."""
        cur.execute("""
            CREATE TABLE IF NOT EXISTS ventures (
                id TEXT PRIMARY KEY,
                title TEXT NOT NULL,
                goal TEXT NOT NULL,
                exit_condition TEXT NOT NULL,
                executor_type TEXT NOT NULL,
                executor_config TEXT NOT NULL DEFAULT '{}',
                policy TEXT NOT NULL DEFAULT '{}',
                observer_configs TEXT NOT NULL DEFAULT '[]',
                state TEXT NOT NULL DEFAULT 'created',
                result TEXT,
                error TEXT,
                created_at TEXT NOT NULL,
                started_at TEXT,
                completed_at TEXT,
                total_cost_usd REAL NOT NULL DEFAULT 0.0,
                total_tokens INTEGER NOT NULL DEFAULT 0,
                metadata TEXT NOT NULL DEFAULT '{}'
            )
        """)

        cur.execute("""
            CREATE TABLE IF NOT EXISTS checkpoints (
                id TEXT PRIMARY KEY,
                venture_id TEXT NOT NULL,
                timestamp TEXT NOT NULL,
                reason TEXT NOT NULL,
                progress_summary TEXT NOT NULL,
                next_steps TEXT NOT NULL DEFAULT '[]',
                memory_ids TEXT NOT NULL DEFAULT '[]',
                files_modified TEXT NOT NULL DEFAULT '[]',
                decisions_log TEXT NOT NULL DEFAULT '[]',
                executor_state TEXT NOT NULL DEFAULT '{}',
                FOREIGN KEY (venture_id) REFERENCES ventures(id)
            )
        """)

        cur.execute("""
            CREATE TABLE IF NOT EXISTS progress_updates (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                venture_id TEXT NOT NULL,
                timestamp TEXT NOT NULL,
                step INTEGER,
                message TEXT NOT NULL,
                metadata TEXT NOT NULL DEFAULT '{}',
                FOREIGN KEY (venture_id) REFERENCES ventures(id)
            )
        """)

        cur.execute("""
            CREATE TABLE IF NOT EXISTS state_transitions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                venture_id TEXT NOT NULL,
                from_state TEXT NOT NULL,
                to_state TEXT NOT NULL,
                timestamp TEXT NOT NULL,
                reason TEXT NOT NULL,
                triggered_by TEXT NOT NULL,
                FOREIGN KEY (venture_id) REFERENCES ventures(id)
            )
        """)

        cur.execute("""
            CREATE TABLE IF NOT EXISTS deliverables (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                venture_id TEXT NOT NULL,
                type TEXT NOT NULL,
                title TEXT NOT NULL,
                path TEXT,
                url TEXT,
                content TEXT,
                FOREIGN KEY (venture_id) REFERENCES ventures(id)
            )
        """)

        # Indexes
        cur.execute("CREATE INDEX IF NOT EXISTS idx_ventures_state ON ventures(state)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_checkpoints_venture ON checkpoints(venture_id)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_progress_venture ON progress_updates(venture_id)")
        cur.execute("CREATE INDEX IF NOT EXISTS idx_transitions_venture ON state_transitions(venture_id)")

    def _migrate_v2(self, cur: sqlite3.Cursor) -> None:
        """Schema v2 — approval requests table + notification column."""
        cur.execute("""
            CREATE TABLE IF NOT EXISTS approval_requests (
                id TEXT PRIMARY KEY,
                venture_id TEXT NOT NULL,
                gate TEXT NOT NULL,
                context TEXT NOT NULL DEFAULT '{}',
                requested_at TEXT NOT NULL,
                resolved_at TEXT,
                resolution TEXT NOT NULL DEFAULT 'pending',
                resolved_by TEXT,
                FOREIGN KEY (venture_id) REFERENCES ventures(id)
            )
        """)
        cur.execute(
            "CREATE INDEX IF NOT EXISTS idx_approval_venture "
            "ON approval_requests(venture_id)"
        )
        cur.execute(
            "CREATE INDEX IF NOT EXISTS idx_approval_resolution "
            "ON approval_requests(resolution)"
        )

        # Add notification column to ventures table (nullable JSON)
        # Use try/except because ALTER TABLE ADD COLUMN will fail if the
        # column already exists (e.g. re-running migration on an existing v2 db).
        try:
            cur.execute("ALTER TABLE ventures ADD COLUMN notification TEXT")
        except sqlite3.OperationalError:
            pass  # column already exists

    # -------------------------------------------------------------------
    # CRUD operations
    # -------------------------------------------------------------------

    def save_venture(self, venture: Venture) -> None:
        """Insert or replace a venture record."""
        if self._conn is None:
            raise RuntimeError("Venture store is closed")
        self._conn.execute(
            """
            INSERT OR REPLACE INTO ventures
            (id, title, goal, exit_condition, executor_type, executor_config,
             policy, observer_configs, state, result, error, created_at,
             started_at, completed_at, total_cost_usd, total_tokens,
             notification, metadata)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                venture.id,
                venture.title,
                venture.goal,
                venture.exit_condition,
                venture.executor_type,
                _to_json(venture.executor_config),
                _to_json(venture.policy),
                _to_json_list(venture.observer_configs),
                venture.state.value,
                _to_json(venture.result) if venture.result else None,
                _to_json(venture.error) if venture.error else None,
                venture.created_at.isoformat(),
                venture.started_at.isoformat() if venture.started_at else None,
                venture.completed_at.isoformat() if venture.completed_at else None,
                venture.total_cost_usd,
                venture.total_tokens,
                _to_json(venture.notification) if venture.notification else None,
                _to_json(venture.metadata),
            ),
        )
        self._conn.commit()

    def increment_cost(self, venture_id: str, tokens: int, cost_usd: float) -> None:
        """Atomically increment cost counters for a venture.

        Uses SQL arithmetic to avoid read-modify-write race conditions.
        """
        if self._conn is None:
            raise RuntimeError("Venture store is closed")
        self._conn.execute(
            "UPDATE ventures SET total_tokens = total_tokens + ?, "
            "total_cost_usd = total_cost_usd + ? WHERE id = ?",
            (tokens, cost_usd, venture_id),
        )
        self._conn.commit()

    def get_venture(self, venture_id: str) -> Venture | None:
        """Load a venture by ID. Returns None if not found."""
        if self._conn is None:
            raise RuntimeError("Venture store is closed")
        row = self._conn.execute(
            "SELECT * FROM ventures WHERE id = ?", (venture_id,)
        ).fetchone()
        if not row:
            return None
        return self._row_to_venture(row)

    def list_ventures(
        self,
        states: list[VentureState] | None = None,
        limit: int = 100,
    ) -> list[Venture]:
        """List ventures with optional state filter."""
        if self._conn is None:
            raise RuntimeError("Venture store is closed")
        if states:
            placeholders = ",".join("?" for _ in states)
            rows = self._conn.execute(
                f"SELECT * FROM ventures WHERE state IN ({placeholders}) "
                "ORDER BY created_at DESC LIMIT ?",
                [s.value for s in states] + [limit],
            ).fetchall()
        else:
            rows = self._conn.execute(
                "SELECT * FROM ventures ORDER BY created_at DESC LIMIT ?",
                (limit,),
            ).fetchall()
        return [self._row_to_venture(row) for row in rows]

    def count_by_state(self, states: list[VentureState]) -> int:
        """Count ventures in given states."""
        if self._conn is None:
            raise RuntimeError("Venture store is closed")
        placeholders = ",".join("?" for _ in states)
        row = self._conn.execute(
            f"SELECT COUNT(*) as cnt FROM ventures WHERE state IN ({placeholders})",
            [s.value for s in states],
        ).fetchone()
        return row["cnt"] if row else 0

    def delete_venture(self, venture_id: str) -> bool:
        """Delete a venture and all related records."""
        if self._conn is None:
            raise RuntimeError("Venture store is closed")
        # Delete related records first (foreign keys)
        self._conn.execute("DELETE FROM checkpoints WHERE venture_id = ?", (venture_id,))
        self._conn.execute("DELETE FROM progress_updates WHERE venture_id = ?", (venture_id,))
        self._conn.execute("DELETE FROM state_transitions WHERE venture_id = ?", (venture_id,))
        self._conn.execute("DELETE FROM deliverables WHERE venture_id = ?", (venture_id,))
        self._conn.execute("DELETE FROM approval_requests WHERE venture_id = ?", (venture_id,))
        cur = self._conn.execute("DELETE FROM ventures WHERE id = ?", (venture_id,))
        self._conn.commit()
        return cur.rowcount > 0

    # -------------------------------------------------------------------
    # Checkpoint operations
    # -------------------------------------------------------------------

    def save_checkpoint(self, checkpoint: Checkpoint) -> None:
        """Save a checkpoint record to the DB."""
        if self._conn is None:
            raise RuntimeError("Venture store is closed")
        self._conn.execute(
            """
            INSERT OR REPLACE INTO checkpoints
            (id, venture_id, timestamp, reason, progress_summary,
             next_steps, memory_ids, files_modified, decisions_log, executor_state)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                checkpoint.id,
                checkpoint.venture_id,
                checkpoint.timestamp.isoformat(),
                checkpoint.reason.value,
                checkpoint.progress_summary,
                _to_json_list(checkpoint.next_steps),
                json.dumps(checkpoint.memory_ids),
                _to_json_list(checkpoint.files_modified),
                _to_json_list(checkpoint.decisions_log),
                _to_json(checkpoint.executor_state),
            ),
        )
        self._conn.commit()

    def get_checkpoints(self, venture_id: str) -> list[Checkpoint]:
        """Get all checkpoints for a venture, ordered by timestamp."""
        if self._conn is None:
            raise RuntimeError("Venture store is closed")
        rows = self._conn.execute(
            "SELECT * FROM checkpoints WHERE venture_id = ? ORDER BY timestamp",
            (venture_id,),
        ).fetchall()
        return [self._row_to_checkpoint(row) for row in rows]

    def get_latest_checkpoint(self, venture_id: str) -> Checkpoint | None:
        """Get the most recent checkpoint for a venture."""
        if self._conn is None:
            raise RuntimeError("Venture store is closed")
        row = self._conn.execute(
            "SELECT * FROM checkpoints WHERE venture_id = ? ORDER BY timestamp DESC LIMIT 1",
            (venture_id,),
        ).fetchone()
        return self._row_to_checkpoint(row) if row else None

    # -------------------------------------------------------------------
    # State transition operations
    # -------------------------------------------------------------------

    def save_transition(self, venture_id: str, transition: StateTransition) -> None:
        """Persist a state transition to the audit log."""
        if self._conn is None:
            raise RuntimeError("Venture store is closed")
        self._conn.execute(
            """
            INSERT INTO state_transitions
            (venture_id, from_state, to_state, timestamp, reason, triggered_by)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                venture_id,
                transition.from_state.value,
                transition.to_state.value,
                transition.timestamp.isoformat(),
                transition.reason,
                transition.triggered_by,
            ),
        )
        self._conn.commit()

    def get_transitions(self, venture_id: str) -> list[StateTransition]:
        """Get all state transitions for a venture."""
        if self._conn is None:
            raise RuntimeError("Venture store is closed")
        rows = self._conn.execute(
            "SELECT * FROM state_transitions WHERE venture_id = ? ORDER BY timestamp",
            (venture_id,),
        ).fetchall()
        return [
            StateTransition(
                from_state=VentureState(row["from_state"]),
                to_state=VentureState(row["to_state"]),
                timestamp=datetime.fromisoformat(row["timestamp"]),
                reason=row["reason"],
                triggered_by=row["triggered_by"],
            )
            for row in rows
        ]

    # -------------------------------------------------------------------
    # Progress operations
    # -------------------------------------------------------------------

    def save_progress(self, venture_id: str, update: ProgressUpdate) -> None:
        """Save a progress update."""
        if self._conn is None:
            raise RuntimeError("Venture store is closed")
        self._conn.execute(
            """
            INSERT INTO progress_updates
            (venture_id, timestamp, step, message, metadata)
            VALUES (?, ?, ?, ?, ?)
            """,
            (
                venture_id,
                update.timestamp.isoformat(),
                update.step,
                update.message,
                _to_json(update.metadata),
            ),
        )
        self._conn.commit()

    def get_progress(self, venture_id: str, limit: int = 100) -> list[ProgressUpdate]:
        """Get progress updates for a venture."""
        if self._conn is None:
            raise RuntimeError("Venture store is closed")
        rows = self._conn.execute(
            "SELECT * FROM progress_updates WHERE venture_id = ? ORDER BY timestamp LIMIT ?",
            (venture_id, limit),
        ).fetchall()
        return [
            ProgressUpdate(
                timestamp=datetime.fromisoformat(row["timestamp"]),
                step=row["step"],
                message=row["message"],
                metadata=json.loads(row["metadata"]) if row["metadata"] else {},
            )
            for row in rows
        ]

    # -------------------------------------------------------------------
    # Approval request operations
    # -------------------------------------------------------------------

    def save_approval_request(self, request: ApprovalRequest) -> None:
        """Save an approval request to the DB."""
        if self._conn is None:
            raise RuntimeError("Venture store is closed")
        self._conn.execute(
            """
            INSERT OR REPLACE INTO approval_requests
            (id, venture_id, gate, context, requested_at,
             resolved_at, resolution, resolved_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                request.id,
                request.venture_id,
                request.gate,
                _to_json(request.context),
                request.requested_at.isoformat(),
                request.resolved_at.isoformat() if request.resolved_at else None,
                request.resolution,
                request.resolved_by,
            ),
        )
        self._conn.commit()

    def get_pending_approvals(
        self, venture_id: str | None = None
    ) -> list[ApprovalRequest]:
        """Get pending approval requests, optionally filtered by venture."""
        if self._conn is None:
            raise RuntimeError("Venture store is closed")
        if venture_id:
            rows = self._conn.execute(
                "SELECT * FROM approval_requests "
                "WHERE resolution = 'pending' AND venture_id = ? "
                "ORDER BY requested_at",
                (venture_id,),
            ).fetchall()
        else:
            rows = self._conn.execute(
                "SELECT * FROM approval_requests "
                "WHERE resolution = 'pending' ORDER BY requested_at"
            ).fetchall()
        return [self._row_to_approval_request(row) for row in rows]

    def resolve_approval(
        self,
        approval_id: str,
        resolution: str,
        resolved_by: str | None = None,
    ) -> ApprovalRequest | None:
        """Resolve an approval request and return the updated record."""
        if self._conn is None:
            raise RuntimeError("Venture store is closed")
        now = datetime.now(timezone.utc).isoformat()
        cur = self._conn.execute(
            """
            UPDATE approval_requests
            SET resolution = ?, resolved_at = ?, resolved_by = ?
            WHERE id = ? AND resolution = 'pending'
            """,
            (resolution, now, resolved_by, approval_id),
        )
        self._conn.commit()

        if cur.rowcount == 0:
            return None

        row = self._conn.execute(
            "SELECT * FROM approval_requests WHERE id = ?", (approval_id,)
        ).fetchone()
        return self._row_to_approval_request(row) if row else None

    def get_approval_request(self, approval_id: str) -> ApprovalRequest | None:
        """Get a single approval request by ID."""
        if self._conn is None:
            raise RuntimeError("Venture store is closed")
        row = self._conn.execute(
            "SELECT * FROM approval_requests WHERE id = ?", (approval_id,)
        ).fetchone()
        return self._row_to_approval_request(row) if row else None

    def _row_to_approval_request(self, row: sqlite3.Row) -> ApprovalRequest:
        """Deserialize a DB row into an ApprovalRequest model."""
        data = dict(row)
        data["context"] = json.loads(data["context"]) if data["context"] else {}
        data["requested_at"] = datetime.fromisoformat(data["requested_at"])
        data["resolved_at"] = (
            datetime.fromisoformat(data["resolved_at"])
            if data["resolved_at"]
            else None
        )
        return ApprovalRequest(**data)

    # -------------------------------------------------------------------
    # Helpers
    # -------------------------------------------------------------------

    def _row_to_venture(self, row: sqlite3.Row) -> Venture:
        """Deserialize a DB row into a Venture model."""
        data = dict(row)
        data["executor_config"] = json.loads(data["executor_config"])
        data["policy"] = json.loads(data["policy"])
        data["observer_configs"] = json.loads(data["observer_configs"])
        data["state"] = VentureState(data["state"])
        data["result"] = json.loads(data["result"]) if data["result"] else None
        data["error"] = json.loads(data["error"]) if data["error"] else None
        data["metadata"] = json.loads(data["metadata"])
        data["created_at"] = datetime.fromisoformat(data["created_at"])
        data["started_at"] = datetime.fromisoformat(data["started_at"]) if data["started_at"] else None
        data["completed_at"] = datetime.fromisoformat(data["completed_at"]) if data["completed_at"] else None

        # Notification (nullable JSON, may not exist on old v1 rows)
        notification_raw = data.get("notification")
        data["notification"] = json.loads(notification_raw) if notification_raw else None

        # Load related records
        venture_id = data["id"]
        data["checkpoints"] = self.get_checkpoints(venture_id)
        data["progress"] = self.get_progress(venture_id)
        data["state_history"] = self.get_transitions(venture_id)

        return Venture(**data)

    def _row_to_checkpoint(self, row: sqlite3.Row) -> Checkpoint:
        """Deserialize a DB row into a Checkpoint model.

        Handles corrupt JSON data gracefully by falling back to defaults.
        """
        data = dict(row)
        data["timestamp"] = datetime.fromisoformat(data["timestamp"])
        data["memory_ids"] = json.loads(data["memory_ids"])
        data["files_modified"] = json.loads(data["files_modified"])
        data["decisions_log"] = json.loads(data["decisions_log"])
        data["executor_state"] = json.loads(data["executor_state"])

        # next_steps may contain corrupt data — handle gracefully
        try:
            data["next_steps"] = json.loads(data["next_steps"])
        except (json.JSONDecodeError, TypeError):
            logger.warning(
                "Corrupt next_steps data in checkpoint %s — defaulting to empty list",
                data.get("id", "unknown"),
            )
            data["next_steps"] = []

        try:
            return Checkpoint(**data)
        except Exception:
            logger.warning(
                "Failed to deserialize checkpoint %s — returning with defaults",
                data.get("id", "unknown"),
                exc_info=True,
            )
            # Retry with sanitized next_steps
            data["next_steps"] = []
            return Checkpoint(**data)

    def close(self) -> None:
        """Close the database connection."""
        if self._conn:
            self._conn.close()
            self._conn = None
