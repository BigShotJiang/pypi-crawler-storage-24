"""Subprocess executor — runs shell commands/scripts as ventures.

The simplest executor. Monitors stdout for VENTURE_* signals:
  VENTURE_PROGRESS {"step": 3, "message": "..."}
  VENTURE_CHECKPOINT {"reason": "manual", "summary": "..."}
  VENTURE_APPROVAL_NEEDED {"gate": "git_push", "context": {...}}
  VENTURE_COMPLETE {"summary": "...", "deliverables": [...]}
  VENTURE_FAILED {"error": "..."}

Lines without these prefixes are treated as regular log output.
Lines starting with VENTURE_ but not matching a known signal
generate a warning (per Delta R3 — catches typos like VENTURE_PROGRES).
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import signal
import uuid
from datetime import datetime, timezone
from typing import Any

from parsica_ventures.models import (
    Venture,
    Checkpoint,
    CheckpointData,
    ExecutorHandle,
    ExecutorHealth,
    ProgressUpdate,
    VentureResult,
    VentureError,
    VentureMetrics,
    Deliverable,
    DeliverableType,
    FailureCategory,
)
from parsica_ventures.executor import ExecutorCallback, registry
from parsica_ventures.exceptions import ExecutorLaunchError
from parsica_ventures.sanitizer import sanitize

logger = logging.getLogger(__name__)

# Cap propagated goal text to avoid oversized environment payloads.
_MAX_ENV_GOAL_BYTES = 4096


def _sanitize_goal_for_env(goal: str, max_bytes: int = _MAX_ENV_GOAL_BYTES) -> str:
    """Sanitize and truncate venture goal text for environment propagation."""
    sanitized = sanitize(goal).replace("\x00", "")
    encoded = sanitized.encode("utf-8", errors="ignore")
    if len(encoded) <= max_bytes:
        return sanitized
    truncated = encoded[:max_bytes]
    while True:
        try:
            return truncated.decode("utf-8")
        except UnicodeDecodeError:
            truncated = truncated[:-1]

# Known VENTURE_* signal prefixes
KNOWN_SIGNALS = {
    "VENTURE_PROGRESS",
    "VENTURE_CHECKPOINT",
    "VENTURE_APPROVAL_NEEDED",
    "VENTURE_COMPLETE",
    "VENTURE_FAILED",
}


class SubprocessExecutor:
    """Execute ventures by running shell commands/scripts.

    The subprocess communicates via structured stdout lines.
    stderr is captured as log output.
    """

    def __init__(
        self,
        command: str | None = None,
        shell: bool = True,
        cwd: str | None = None,
        env: dict[str, str] | None = None,
        timeout: float | None = None,
        **kwargs: Any,
    ):
        self.command = command
        self.shell = shell
        self.cwd = cwd
        self.env = env
        self.timeout = timeout
        self._process: asyncio.subprocess.Process | None = None
        self._callback: ExecutorCallback | None = None
        self._monitor_task: asyncio.Task[None] | None = None
        self._executor_id = f"sub_{uuid.uuid4().hex[:8]}"
        self._last_activity = datetime.now(timezone.utc)
        self._log_lines: list[str] = []
        self._terminal_fired: bool = False

    async def start(
        self, venture: Venture, callback: ExecutorCallback
    ) -> ExecutorHandle:
        """Launch the subprocess."""
        command = self.command or venture.executor_config.get("command", "")
        if not command:
            raise ExecutorLaunchError("No command specified for subprocess executor")

        self._callback = callback
        cwd = self.cwd or venture.executor_config.get("cwd")
        env_override = self.env or venture.executor_config.get("env", {})

        # Build environment
        proc_env = os.environ.copy()
        proc_env.update(env_override)
        proc_env["VENTURE_ID"] = venture.id
        proc_env["VENTURE_GOAL"] = _sanitize_goal_for_env(venture.goal)

        try:
            if self.shell:
                self._process = await asyncio.create_subprocess_shell(
                    command,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    cwd=cwd,
                    env=proc_env,
                )
            else:
                args = command.split() if isinstance(command, str) else command
                self._process = await asyncio.create_subprocess_exec(
                    *args,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                    cwd=cwd,
                    env=proc_env,
                )
        except Exception as e:
            raise ExecutorLaunchError(f"Failed to launch subprocess: {e}") from e

        # Start monitoring stdout/stderr
        self._monitor_task = asyncio.create_task(self._monitor())

        handle = ExecutorHandle(
            executor_id=self._executor_id,
            pid=self._process.pid,
        )
        logger.info(
            "Subprocess executor started: pid=%s, command=%s",
            self._process.pid,
            command[:100],
        )
        return handle

    async def pause(self, venture: Venture) -> None:
        """Send SIGSTOP to the subprocess (POSIX only)."""
        if self._process and self._process.returncode is None:
            if not hasattr(signal, "SIGSTOP"):
                logger.warning("SIGSTOP not available on this platform — pause is a no-op")
                return
            try:
                os.kill(self._process.pid, signal.SIGSTOP)
                logger.info("Subprocess %s paused (SIGSTOP)", self._process.pid)
            except OSError as e:
                logger.warning("Failed to pause subprocess: %s", e)

    async def checkpoint(self, venture: Venture) -> CheckpointData:
        """Request checkpoint data from subprocess.

        For subprocess, we capture current log state as the checkpoint.
        The subprocess itself doesn't have structured state access.
        """
        return CheckpointData(
            progress_summary=f"Subprocess running. Last {min(len(self._log_lines), 10)} log lines captured.",
            executor_state={
                "log_lines": self._log_lines[-50:],
                "pid": self._process.pid if self._process else None,
            },
        )

    async def resume(
        self, venture: Venture, checkpoint: Checkpoint, callback: ExecutorCallback
    ) -> ExecutorHandle:
        """Resume from checkpoint — re-launches the subprocess.

        For subprocess executor, resume means re-running the command.
        The checkpoint context is passed via environment variables.
        """
        self._callback = callback

        # Inject checkpoint context into env
        if not self.env:
            self.env = {}
        self.env["VENTURE_CHECKPOINT_SUMMARY"] = checkpoint.progress_summary
        self.env["VENTURE_CHECKPOINT_ID"] = checkpoint.id

        # Re-launch
        return await self.start(venture, callback)

    async def abort(self, venture: Venture) -> None:
        """Kill the subprocess."""
        if self._process and self._process.returncode is None:
            try:
                self._process.kill()
                logger.info("Subprocess %s killed", self._process.pid)
            except OSError as e:
                logger.warning("Failed to kill subprocess: %s", e)

        if self._monitor_task:
            self._monitor_task.cancel()
            try:
                await self._monitor_task
            except asyncio.CancelledError:
                pass

    async def health(self, venture: Venture) -> ExecutorHealth:
        """Check subprocess health."""
        alive = self._process is not None and self._process.returncode is None
        return ExecutorHealth(
            alive=alive,
            last_activity=self._last_activity,
            current_task=f"pid={self._process.pid}" if self._process else None,
        )

    # -------------------------------------------------------------------
    # Internal monitoring
    # -------------------------------------------------------------------

    async def _monitor(self) -> None:
        """Monitor subprocess stdout/stderr for signals and output."""
        assert self._process is not None
        assert self._callback is not None

        # Monitor stdout for VENTURE_* signals
        stdout_task = asyncio.create_task(self._read_stdout())
        stderr_task = asyncio.create_task(self._read_stderr())

        try:
            await asyncio.gather(stdout_task, stderr_task)
        except asyncio.CancelledError:
            return

        # Process exited — check return code (guard against double terminal)
        if self._terminal_fired:
            return

        returncode = self._process.returncode
        if returncode == 0:
            # Normal exit — if no VENTURE_COMPLETE was sent, synthesize one
            self._terminal_fired = True
            await self._callback.on_completed(VentureResult(
                summary="Subprocess completed successfully",
                metrics=VentureMetrics(executor_sessions=1),
            ))
        elif returncode is not None and returncode != 0:
            self._terminal_fired = True
            await self._callback.on_failed(VentureError(
                category=FailureCategory.CRASH,
                message=f"Subprocess exited with code {returncode}",
                recoverable=True,
            ))

    async def _read_stdout(self) -> None:
        """Read stdout line by line, parsing VENTURE_* signals."""
        assert self._process is not None
        assert self._process.stdout is not None
        assert self._callback is not None

        while True:
            line_bytes = await self._process.stdout.readline()
            if not line_bytes:
                break

            line = line_bytes.decode("utf-8", errors="replace").rstrip("\n")
            self._last_activity = datetime.now(timezone.utc)
            self._log_lines.append(sanitize(line))

            # Check for VENTURE_* signals
            if line.startswith("VENTURE_"):
                await self._handle_signal(line)
            else:
                logger.debug("[subprocess stdout] %s", sanitize(line))

    async def _read_stderr(self) -> None:
        """Read stderr as log output."""
        assert self._process is not None
        assert self._process.stderr is not None

        while True:
            line_bytes = await self._process.stderr.readline()
            if not line_bytes:
                break

            line = line_bytes.decode("utf-8", errors="replace").rstrip("\n")
            self._last_activity = datetime.now(timezone.utc)
            self._log_lines.append(f"[stderr] {sanitize(line)}")
            logger.debug("[subprocess stderr] %s", sanitize(line))

    async def _handle_signal(self, line: str) -> None:
        """Parse and dispatch a VENTURE_* signal line."""
        assert self._callback is not None

        # Split signal name from JSON payload
        parts = line.split(" ", 1)
        signal_name = parts[0]
        payload_str = parts[1] if len(parts) > 1 else "{}"

        # Warn on unknown signals (Delta R3 — catch typos)
        if signal_name not in KNOWN_SIGNALS:
            logger.warning(
                "Unknown VENTURE_* signal: '%s' — did you mean one of %s?",
                signal_name,
                sorted(KNOWN_SIGNALS),
            )
            return

        try:
            payload = json.loads(payload_str)
        except json.JSONDecodeError:
            logger.warning("Invalid JSON in %s signal: %s", signal_name, payload_str[:200])
            return

        if signal_name == "VENTURE_PROGRESS":
            await self._callback.on_progress(ProgressUpdate(
                step=payload.get("step"),
                message=payload.get("message", ""),
                metadata=payload.get("metadata", {}),
            ))

        elif signal_name == "VENTURE_CHECKPOINT":
            await self._callback.on_checkpoint_needed(
                reason=payload.get("reason", "manual"),
                state=payload,
            )

        elif signal_name == "VENTURE_APPROVAL_NEEDED":
            await self._callback.on_approval_needed(
                gate=payload.get("gate", "unknown"),
                context=payload.get("context", {}),
            )

        elif signal_name == "VENTURE_COMPLETE":
            if self._terminal_fired:
                logger.warning("Ignoring duplicate VENTURE_COMPLETE signal (terminal already fired)")
                return
            self._terminal_fired = True
            deliverables = self._parse_deliverables(payload.get("deliverables", []))
            await self._callback.on_completed(VentureResult(
                summary=self._cap_string(payload.get("summary", "Complete")),
                deliverables=deliverables,
                recommendations=payload.get("recommendations", []),
            ))

        elif signal_name == "VENTURE_FAILED":
            if self._terminal_fired:
                logger.warning("Ignoring duplicate VENTURE_FAILED signal (terminal already fired)")
                return
            self._terminal_fired = True
            # Safely parse failure category — default to LOGIC on unknown values
            try:
                category = FailureCategory(payload.get("category", "logic"))
            except ValueError:
                logger.warning(
                    "Unknown FailureCategory '%s' — defaulting to LOGIC",
                    payload.get("category"),
                )
                category = FailureCategory.LOGIC
            await self._callback.on_failed(VentureError(
                category=category,
                message=self._cap_string(payload.get("error", "Unknown error")),
                recoverable=payload.get("recoverable", False),
            ))


    # -------------------------------------------------------------------
    # Validation helpers (P0-4: sanitize subprocess deliverables)
    # -------------------------------------------------------------------

    @staticmethod
    def _cap_string(value: str, max_bytes: int = 10240) -> str:
        """Cap a string payload to max_bytes (default 10KB)."""
        if isinstance(value, str) and len(value.encode("utf-8", errors="replace")) > max_bytes:
            # Truncate to approximate byte limit
            return value[:max_bytes] + "... [truncated]"
        return value

    @staticmethod
    def _parse_deliverables(raw_list: list) -> list[Deliverable]:
        """Validate and parse deliverable dicts into Deliverable objects.

        Skips invalid entries with a warning instead of crashing.
        """
        deliverables = []
        for i, d in enumerate(raw_list):
            if not isinstance(d, dict):
                logger.warning("Deliverable #%d is not a dict — skipping", i)
                continue
            try:
                # Validate required fields
                if "type" not in d or "title" not in d:
                    logger.warning(
                        "Deliverable #%d missing required fields (type, title) — skipping: %s",
                        i, list(d.keys()),
                    )
                    continue
                # Validate deliverable type
                try:
                    DeliverableType(d["type"])
                except ValueError:
                    logger.warning(
                        "Deliverable #%d has unknown type '%s' — skipping",
                        i, d["type"],
                    )
                    continue
                # Cap string fields
                for field in ("title", "path", "url", "content"):
                    if field in d and isinstance(d[field], str):
                        d[field] = SubprocessExecutor._cap_string(d[field])
                deliverables.append(Deliverable(**d))
            except Exception as exc:
                logger.warning("Deliverable #%d failed validation: %s — skipping", i, exc)
        return deliverables


# Register with global registry
registry.register("subprocess", SubprocessExecutor)
