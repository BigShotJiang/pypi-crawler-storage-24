"""OpenClaw executor — runs ventures via OpenClaw sub-agent sessions.

This executor mirrors the VentureExecutor interface used by the subprocess
executor, but targets OpenClaw sessions instead of local shell commands.

Implementation status:
- Executor structure is complete
- Session monitoring and callback mapping are implemented
- Gateway transport methods are intentionally stub-friendly with clear TODOs
  so the Python bridge can wire the real OpenClaw API later
"""

from __future__ import annotations

import asyncio
import logging
import uuid
from datetime import datetime, timezone
from typing import Any

from parsica_ventures.executor import ExecutorCallback, registry
from parsica_ventures.exceptions import ExecutorLaunchError
from parsica_ventures.models import (
    Checkpoint,
    CheckpointData,
    ExecutorHandle,
    ExecutorHealth,
    FailureCategory,
    ProgressUpdate,
    Venture,
    VentureError,
    VentureMetrics,
    VentureResult,
)

logger = logging.getLogger(__name__)


class OpenClawExecutor:
    """Execute ventures by spawning OpenClaw sub-agent sessions.

    The real OpenClaw integration point will be the venture bridge. This class
    still provides a concrete, testable executor surface:
      - start() spawns a session through a gateway client abstraction
      - _monitor_session() polls session state and fires executor callbacks
      - pause()/abort()/checkpoint()/resume()/health() delegate to the client

    The gateway client may be:
      1. injected directly via ``gateway_client=...`` for tests/bridge wiring
      2. created later from HTTP or stdio transport settings

    TODO(bridge): implement a real OpenClaw gateway client that supports:
      - spawn_session(task, metadata)
      - get_session(session_id)
      - pause_session(session_id)
      - abort_session(session_id)
      - checkpoint_session(session_id)
    """

    def __init__(
        self,
        gateway_client: Any | None = None,
        checkpoint_threshold: float = 0.80,
        poll_interval_seconds: float = 5.0,
        gateway_url: str | None = None,
        gateway_token: str | None = None,
        **kwargs: Any,
    ):
        self.gateway_client = gateway_client
        self.checkpoint_threshold = checkpoint_threshold
        self.poll_interval_seconds = poll_interval_seconds
        self.gateway_url = gateway_url
        self.gateway_token = gateway_token

        self._callback: ExecutorCallback | None = None
        self._session_id: str | None = None
        self._executor_id = f"openclaw_{uuid.uuid4().hex[:8]}"
        self._last_activity = datetime.now(timezone.utc)
        self._monitor_task: asyncio.Task[None] | None = None
        self._running = False
        self._last_event_cursor: Any = None
        self._checkpoint_signatures: set[str] = set()
        self._context_checkpoint_sent = False
        self._last_health: dict[str, Any] = {}

    async def start(self, venture: Venture, callback: ExecutorCallback) -> ExecutorHandle:
        """Launch an OpenClaw session for this venture."""
        client = self._require_client(venture)
        self._callback = callback
        self._running = True
        self._context_checkpoint_sent = False
        self._checkpoint_signatures.clear()
        self._last_event_cursor = None

        prompt = self._build_prompt(venture)

        try:
            # TODO(bridge): replace this generic client call with the concrete
            # OpenClaw gateway session spawn API when available.
            session = await client.spawn_session(
                task=prompt,
                metadata={
                    "venture_id": venture.id,
                    "venture_title": venture.title,
                    "executor": "openclaw",
                    "policy": venture.policy.model_dump(),
                },
            )
        except Exception as exc:
            raise ExecutorLaunchError(f"Failed to launch OpenClaw session: {exc}") from exc

        self._session_id = self._extract_session_id(session)
        self._monitor_task = asyncio.create_task(self._monitor_session(venture))

        logger.info(
            "OpenClaw executor started: session=%s, venture=%s",
            self._session_id,
            venture.id,
        )

        return ExecutorHandle(
            executor_id=self._executor_id,
            session_id=self._session_id,
        )

    async def pause(self, venture: Venture) -> None:
        self._running = False
        if self._session_id and self.gateway_client:
            await self.gateway_client.pause_session(self._session_id)
        logger.info("OpenClaw session %s paused", self._session_id)

    async def checkpoint(self, venture: Venture) -> CheckpointData:
        client = self._require_client(venture)
        if not self._session_id:
            return CheckpointData(
                progress_summary="OpenClaw session has not started yet",
                executor_state={"session_id": None},
            )

        # TODO(bridge): map this onto real OpenClaw session state/checkpoint APIs.
        state = await client.checkpoint_session(self._session_id)
        if state is None:
            state = await client.get_session(self._session_id)

        summary = self._read_summary(state) or "OpenClaw session checkpointed"
        next_steps = self._read_next_steps(state)
        return CheckpointData(
            progress_summary=summary,
            next_steps=next_steps,
            executor_state={
                "session_id": self._session_id,
                "checkpoint": self._coerce_mapping(state),
            },
        )

    async def resume(
        self,
        venture: Venture,
        checkpoint: Checkpoint,
        callback: ExecutorCallback,
    ) -> ExecutorHandle:
        self._callback = callback
        self._running = True
        self._context_checkpoint_sent = False
        self._checkpoint_signatures.clear()
        self._last_event_cursor = None

        client = self._require_client(venture)
        prompt = self._build_resume_prompt(venture, checkpoint)

        try:
            # TODO(bridge): replace this with the concrete resume/new-session API.
            session = await client.spawn_session(
                task=prompt,
                metadata={
                    "venture_id": venture.id,
                    "venture_title": venture.title,
                    "executor": "openclaw",
                    "resume_from_checkpoint": checkpoint.id,
                },
            )
        except Exception as exc:
            raise ExecutorLaunchError(f"Failed to resume OpenClaw session: {exc}") from exc

        self._session_id = self._extract_session_id(session)
        self._monitor_task = asyncio.create_task(self._monitor_session(venture))

        logger.info(
            "OpenClaw executor resumed: session=%s, checkpoint=%s",
            self._session_id,
            checkpoint.id,
        )

        return ExecutorHandle(
            executor_id=self._executor_id,
            session_id=self._session_id,
        )

    async def abort(self, venture: Venture) -> None:
        self._running = False
        if self._session_id and self.gateway_client:
            await self.gateway_client.abort_session(self._session_id)
        if self._monitor_task:
            self._monitor_task.cancel()
            try:
                await self._monitor_task
            except asyncio.CancelledError:
                pass
        logger.info("OpenClaw session %s aborted", self._session_id)

    async def health(self, venture: Venture) -> ExecutorHealth:
        if not self._session_id or not self.gateway_client:
            return ExecutorHealth(
                alive=False,
                last_activity=self._last_activity,
                current_task="session=uninitialized",
            )

        status = await self.gateway_client.get_session(self._session_id)
        self._last_health = self._coerce_mapping(status)
        return ExecutorHealth(
            alive=self._read_alive(status),
            last_activity=self._last_activity,
            current_task=f"session={self._session_id}",
            tokens_used=self._read_tokens_used(status),
            cost_usd=float(self._coerce_mapping(status).get("cost_usd", 0.0) or 0.0),
            error=self._coerce_mapping(status).get("error"),
        )

    def _require_client(self, venture: Venture) -> Any:
        if self.gateway_client is not None:
            return self.gateway_client

        # TODO(bridge): create a real OpenClaw gateway client from gateway_url /
        # gateway_token / venture.executor_config when bridge wiring lands.
        raise ExecutorLaunchError(
            "OpenClaw gateway client not configured. Inject gateway_client or wire the bridge transport."
        )

    def _build_prompt(self, venture: Venture) -> str:
        parts = [
            f"# Venture: {venture.title}\n",
            f"## Goal\n{venture.goal}\n",
            f"## Exit Condition\n{venture.exit_condition}\n",
            "## Execution Runtime\nRun this venture inside an OpenClaw sub-agent session.\n",
        ]
        if venture.policy.scope_boundaries:
            parts.append("## Scope Boundaries\n")
            for boundary in venture.policy.scope_boundaries:
                parts.append(f"- {boundary}\n")
        if venture.metadata:
            parts.append(f"\n## Additional Context\n{venture.metadata}\n")
        return "\n".join(parts)

    def _build_resume_prompt(self, venture: Venture, checkpoint: Checkpoint) -> str:
        parts = [
            self._build_prompt(venture),
            "\n---\n## Resume From Checkpoint\n",
            f"Checkpoint ID: {checkpoint.id}\n",
            f"Progress so far: {checkpoint.progress_summary}\n",
        ]
        if checkpoint.next_steps:
            parts.append("\n### Remaining Steps\n")
            for step in checkpoint.next_steps:
                parts.append(f"- [{step.priority}] {step.description} ({step.type})\n")
        if checkpoint.decisions_log:
            parts.append("\n### Key Decisions\n")
            for decision in checkpoint.decisions_log:
                parts.append(f"- {decision.description}: {decision.outcome}\n")
        return "\n".join(parts)

    async def _monitor_session(self, venture: Venture) -> None:
        assert self._callback is not None
        assert self._session_id is not None
        assert self.gateway_client is not None

        while self._running:
            try:
                await asyncio.sleep(self.poll_interval_seconds)
                status = await self.gateway_client.get_session(self._session_id)
                health = self._coerce_mapping(status)
                self._last_health = health

                if not self._read_alive(status) and not self._read_completed(status):
                    await self._callback.on_failed(VentureError(
                        category=FailureCategory.CRASH,
                        message=health.get("error") or "OpenClaw session died unexpectedly",
                        recoverable=True,
                    ))
                    break

                if self._read_completed(status):
                    await self._callback.on_completed(VentureResult(
                        summary=self._read_summary(status) or "OpenClaw session completed",
                        metrics=VentureMetrics(
                            total_tokens=self._read_tokens_used(status),
                            total_cost_usd=float(health.get("cost_usd", 0.0) or 0.0),
                            executor_sessions=1,
                        ),
                    ))
                    break

                usage_ratio = self._read_usage_ratio(status, venture)
                if usage_ratio is not None and usage_ratio >= self.checkpoint_threshold and not self._context_checkpoint_sent:
                    self._context_checkpoint_sent = True
                    await self._callback.on_checkpoint_needed(
                        reason="context_limit",
                        state={
                            "summary": self._read_summary(status) or "Checkpoint requested before context exhaustion",
                            "tokens_used": self._read_tokens_used(status),
                            "context_window": self._read_context_window(status),
                            "usage_ratio": usage_ratio,
                            "executor_state": {"session_id": self._session_id},
                        },
                    )

                if self._read_checkpoint_requested(status):
                    signature = self._checkpoint_signature(status)
                    if signature not in self._checkpoint_signatures:
                        self._checkpoint_signatures.add(signature)
                        await self._callback.on_checkpoint_needed(
                            reason="agent_requested",
                            state={
                                "summary": self._read_summary(status) or "OpenClaw session requested checkpoint",
                                "next_steps": self._read_next_steps(status),
                                "executor_state": {"session_id": self._session_id},
                            },
                        )

                events = await self._fetch_new_events()
                for event in events:
                    if not self._is_progress_event(event):
                        continue
                    self._last_activity = datetime.now(timezone.utc)
                    payload = self._coerce_mapping(event)
                    await self._callback.on_progress(ProgressUpdate(
                        message=str(payload.get("message") or payload.get("summary") or "OpenClaw progress update"),
                        step=payload.get("step"),
                        metadata=payload,
                    ))
                    tokens_delta = int(payload.get("tokens_delta", 0) or 0)
                    cost_delta = float(payload.get("cost_delta", 0.0) or 0.0)
                    if tokens_delta or cost_delta:
                        await self._callback.on_cost_update(tokens_delta, cost_delta)

            except asyncio.CancelledError:
                break
            except Exception as exc:
                logger.exception("Monitor loop error for OpenClaw session %s", self._session_id)
                await self._callback.on_failed(VentureError(
                    category=FailureCategory.CRASH,
                    message=f"Monitor loop exception: {exc}",
                    recoverable=True,
                ))
                break

    async def _fetch_new_events(self) -> list[dict[str, Any]]:
        if not self.gateway_client or not self._session_id:
            return []
        if not hasattr(self.gateway_client, "list_session_events"):
            return []

        events = await self.gateway_client.list_session_events(
            self._session_id,
            after=self._last_event_cursor,
        )
        normalized = [self._coerce_mapping(event) for event in (events or [])]
        if normalized:
            self._last_event_cursor = normalized[-1].get("cursor", normalized[-1].get("id", self._last_event_cursor))
        return normalized

    @staticmethod
    def _coerce_mapping(value: Any) -> dict[str, Any]:
        if isinstance(value, dict):
            return value
        if hasattr(value, "model_dump"):
            return value.model_dump()
        if hasattr(value, "dict"):
            return value.dict()
        return dict(getattr(value, "__dict__", {}) or {})

    def _extract_session_id(self, session: Any) -> str:
        data = self._coerce_mapping(session)
        session_id = data.get("session_id") or data.get("id")
        if not session_id:
            raise ExecutorLaunchError("OpenClaw gateway did not return a session id")
        return str(session_id)

    def _read_alive(self, status: Any) -> bool:
        data = self._coerce_mapping(status)
        if "alive" in data:
            return bool(data["alive"])
        state = str(data.get("state", "")).lower()
        return state not in {"failed", "crashed", "aborted", "completed", "done"}

    def _read_completed(self, status: Any) -> bool:
        data = self._coerce_mapping(status)
        if "completed" in data:
            return bool(data["completed"])
        state = str(data.get("state", "")).lower()
        return state in {"completed", "done", "succeeded"}

    def _read_summary(self, status: Any) -> str | None:
        data = self._coerce_mapping(status)
        return data.get("summary") or data.get("result_summary") or data.get("message")

    def _read_tokens_used(self, status: Any) -> int:
        data = self._coerce_mapping(status)
        for key in ("tokens_used", "token_usage", "total_tokens"):
            if key in data and data[key] is not None:
                return int(data[key])
        return 0

    def _read_context_window(self, status: Any) -> int | None:
        data = self._coerce_mapping(status)
        for key in ("context_window", "max_context_tokens"):
            if key in data and data[key] is not None:
                return int(data[key])
        return None

    def _read_usage_ratio(self, status: Any, venture: Venture) -> float | None:
        data = self._coerce_mapping(status)
        if data.get("usage_ratio") is not None:
            return float(data["usage_ratio"])
        context_window = self._read_context_window(status)
        tokens_used = self._read_tokens_used(status)
        if context_window:
            return tokens_used / context_window
        return None

    def _read_checkpoint_requested(self, status: Any) -> bool:
        data = self._coerce_mapping(status)
        return bool(data.get("checkpoint_requested") or data.get("checkpoint_needed"))

    def _read_next_steps(self, status: Any) -> list[Any]:
        data = self._coerce_mapping(status)
        raw = data.get("next_steps") or []
        try:
            steps = list(raw)
        except (TypeError, ValueError):
            logger.warning("Invalid next_steps data: %r — defaulting to empty list", raw)
            return []
        # Filter out invalid entries (must be dict or have description)
        filtered = []
        for step in steps:
            try:
                if isinstance(step, dict) or hasattr(step, "description"):
                    filtered.append(step)
                elif isinstance(step, str):
                    filtered.append(step)
                else:
                    logger.warning("Skipping invalid next_step entry: %r", step)
            except Exception:
                logger.warning("Error processing next_step entry: %r", step, exc_info=True)
        return filtered

    def _checkpoint_signature(self, status: Any) -> str:
        data = self._coerce_mapping(status)
        return str(data.get("checkpoint_request_id") or data.get("checkpoint_cursor") or data.get("updated_at") or data.get("summary") or "checkpoint")

    @staticmethod
    def _is_progress_event(event: dict[str, Any]) -> bool:
        event_type = str(event.get("type") or event.get("event_type") or "").lower()
        if event_type == "progress":
            return True
        return bool(event.get("message") and event_type in {"", "update", "step", "tool"})


registry.register("openclaw", OpenClawExecutor)
