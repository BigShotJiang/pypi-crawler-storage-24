"""Built-in venture executors."""

from parsica_ventures.executors.subprocess_executor import SubprocessExecutor
from parsica_ventures.executors.antaris_agent import AntarisAgentExecutor

__all__ = ["SubprocessExecutor", "AntarisAgentExecutor"]

# Note: AntarisAgentExecutor is NOT registered with the global registry
# because it is not yet functional. SubprocessExecutor and OpenClawExecutor
# register themselves on import from their respective modules.
