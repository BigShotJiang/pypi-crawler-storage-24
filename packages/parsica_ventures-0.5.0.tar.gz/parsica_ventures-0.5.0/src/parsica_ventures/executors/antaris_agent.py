"""Antaris-Agent executor — runs ventures via Antaris-Agent sessions.

Session → Callback Mapping (Delta Condition #1 — MUST implement all 5):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  1. Session ends normally (exit_condition met)
     → await callback.on_completed(VentureResult(summary=..., deliverables=[...]))

  2. Session errors / process crashes (exception, OOM, network drop)
     → await callback.on_failed(VentureError(category=FailureCategory.CRASH,
                                             message=str(exc), recoverable=True))

  3. Session requests a checkpoint (emits CHECKPOINT_NEEDED signal)
     → await callback.on_checkpoint_needed(reason="agent_requested",
                                           state={"summary": ..., "next_steps": [...]})

  4. Session emits incremental progress (tool call completed, step done)
     → await callback.on_progress(ProgressUpdate(message=..., step=N, metadata={...}))

  5. Context window approaching limit (token usage > policy.checkpoint_threshold)
     → await callback.on_checkpoint_needed(reason="context_limit",
                                           state={"tokens_used": N,
                                                  "context_window": MAX,
                                                  "summary": agent_summary})

Context limit detection: The executor monitors the session's token usage
via health checks. When usage exceeds the policy's checkpoint_threshold
(default 0.80 = 80% of context window), it fires callback #5 above.

This executor is designed to be bundled inside Antaris-Agent (suite/ventures/)
where it has direct access to the agent's session management. For standalone
usage it connects to the agent's API endpoint.

Bundling path: antaris-agent/suite/ventures/executor.py should subclass or
instantiate this class and override the TODO stubs with real session calls.
"""

from __future__ import annotations

import asyncio
import logging
import uuid
from datetime import datetime, timezone
from typing import Any

from parsica_ventures.models import (
    Venture,
    Checkpoint,
    CheckpointData,
    ExecutorHandle,
    ExecutorHealth,
    ProgressUpdate,
    VentureResult,
    VentureError,
    VentureMetrics,
    FailureCategory,
)
from parsica_ventures.executor import ExecutorCallback, registry


logger = logging.getLogger(__name__)


class AntarisAgentExecutor:
    """Execute ventures via Antaris-Agent sessions.

    In the bundled deployment (antaris-agent/suite/ventures/), this executor
    has direct access to the agent's session management:
      - create_session(goal, model, config_path) → session
      - session.send_message(text) → response
      - session.health() → SessionHealth(alive, token_usage, context_window)
      - session.pause() / session.abort() / session.result()

    For standalone usage, it connects to the agent's API.

    Session → Callback mapping (implement these 5 in _monitor_session):
    ┌─────────────────────────────────────────────────────────────────────┐
    │  Session Event               →  Callback Method                     │
    ├─────────────────────────────────────────────────────────────────────┤
    │  1. Normal completion        →  on_completed(VentureResult)         │
    │  2. Error / crash            →  on_failed(VentureError(CRASH))      │
    │  3. Agent requests CP        →  on_checkpoint_needed("agent_req..") │
    │  4. Step / tool completed    →  on_progress(ProgressUpdate)         │
    │  5. Context limit (>80%)     →  on_checkpoint_needed("context_lim") │
    └─────────────────────────────────────────────────────────────────────┘

    See _monitor_session() for the exact implementation pattern and TODO
    comments with the concrete API calls to wire in.
    """

    def __init__(
        self,
        config_path: str | None = None,
        model: str | None = None,
        **kwargs: Any,
    ):
        self.config_path = config_path
        self.model = model
        self._callback: ExecutorCallback | None = None
        self._session_id: str | None = None
        self._executor_id = f"agent_{uuid.uuid4().hex[:8]}"
        self._last_activity = datetime.now(timezone.utc)
        self._monitor_task: asyncio.Task[None] | None = None
        self._running = False

    async def start(
        self, venture: Venture, callback: ExecutorCallback
    ) -> ExecutorHandle:
        """Launch an Antaris-Agent session for this venture.

        NOT YET IMPLEMENTED — this executor is a structural placeholder.
        Wire the real agent session API before using.

        TODO (bundled integration): Replace with:

            session = await agent.create_session(
                goal=self._build_prompt(venture),
                model=self.model or venture.executor_config.get("model"),
                config_path=self.config_path,
            )
            self._session_id = session.id
        """
        raise NotImplementedError("Antaris-Agent executor is not yet implemented")

    async def pause(self, venture: Venture) -> None:
        """Pause the agent session."""
        self._running = False
        # TODO: await session.pause()
        logger.info("Antaris-Agent session %s paused", self._session_id)

    async def checkpoint(self, venture: Venture) -> CheckpointData:
        """Get checkpoint data from the agent session.

        TODO (bundled integration): Replace with:
            state = await session.get_state()
            return CheckpointData(
                progress_summary=state.summary,
                next_steps=state.next_steps,
                executor_state={"session_id": self._session_id, "model": self.model},
            )
        """
        # TODO: Query session for current state
        return CheckpointData(
            progress_summary="Agent session checkpointed",
            executor_state={
                "session_id": self._session_id,
                "model": self.model,
            },
        )

    async def resume(
        self, venture: Venture, checkpoint: Checkpoint, callback: ExecutorCallback
    ) -> ExecutorHandle:
        """Resume agent session from checkpoint.

        TODO (bundled integration): Replace stub with:
            session = await agent.create_session(
                goal=self._build_resume_prompt(venture, checkpoint),
                model=self.model or venture.executor_config.get("model"),
                config_path=self.config_path,
            )
            self._session_id = session.id
            # Then start monitoring as in start()
        """
        self._callback = callback
        self._running = True

        # Build resume prompt with checkpoint context
        resume_prompt = self._build_resume_prompt(venture, checkpoint)

        # TODO: Create new session with checkpoint context
        self._session_id = f"venture_session_{uuid.uuid4().hex[:8]}"

        handle = ExecutorHandle(
            executor_id=self._executor_id,
            session_id=self._session_id,
        )

        logger.info(
            "Antaris-Agent executor resumed: session=%s, checkpoint=%s",
            self._session_id,
            checkpoint.id,
        )

        return handle

    async def abort(self, venture: Venture) -> None:
        """Kill the agent session."""
        self._running = False
        # TODO: await session.abort()
        if self._monitor_task:
            self._monitor_task.cancel()
        logger.info("Antaris-Agent session %s aborted", self._session_id)

    async def health(self, venture: Venture) -> ExecutorHealth:
        """Check agent session health.

        TODO (bundled integration): Replace with:
            h = await session.health()
            return ExecutorHealth(
                alive=h.alive,
                last_activity=h.last_activity,
                tokens_used=h.token_usage,
            )
        """
        # TODO: Query actual session health
        return ExecutorHealth(
            alive=self._running,
            last_activity=self._last_activity,
            current_task=f"session={self._session_id}",
        )

    # -------------------------------------------------------------------
    # Prompt building
    # -------------------------------------------------------------------

    def _build_prompt(self, venture: Venture) -> str:
        """Build the initial prompt for the agent session."""
        parts = [
            f"# Venture: {venture.title}\n",
            f"## Goal\n{venture.goal}\n",
            f"## Exit Condition\n{venture.exit_condition}\n",
        ]
        if venture.policy.scope_boundaries:
            parts.append("## Scope Boundaries (must respect)\n")
            for boundary in venture.policy.scope_boundaries:
                parts.append(f"- {boundary}\n")
        if venture.metadata:
            parts.append(f"\n## Additional Context\n{venture.metadata}\n")
        return "\n".join(parts)

    def _build_resume_prompt(self, venture: Venture, checkpoint: Checkpoint) -> str:
        """Build resume prompt with checkpoint context."""
        parts = [
            self._build_prompt(venture),
            "\n---\n## Resuming from Checkpoint\n",
            f"**Progress so far:** {checkpoint.progress_summary}\n",
        ]
        if checkpoint.next_steps:
            parts.append("\n### Remaining Steps\n")
            for step in checkpoint.next_steps:
                parts.append(f"- [{step.priority}] {step.description} ({step.type})\n")
        if checkpoint.decisions_log:
            parts.append("\n### Key Decisions Made\n")
            for decision in checkpoint.decisions_log:
                parts.append(f"- {decision.description}: {decision.outcome}\n")
        return "\n".join(parts)

    # -------------------------------------------------------------------
    # Session monitoring — wire here when bundled in agent
    # -------------------------------------------------------------------

    async def _monitor_session(self, venture: Venture, session: Any) -> None:
        """Monitor agent session and fire the 5 ExecutorCallback events.

        This is the heart of the Session → Callback mapping. Each polling
        cycle reads the live session state and calls the appropriate
        callback method. The engine handles all state transitions and
        persistence — the executor only calls these five methods.

        IMPLEMENTATION GUIDE (5 callbacks, in priority order):
        ────────────────────────────────────────────────────────

        Callback 1 — Normal completion (session exit_condition met):
            if health.completed:
                result = await session.result()
                await self._callback.on_completed(VentureResult(
                    summary=result.summary,
                    deliverables=result.deliverables,
                    metrics=VentureMetrics(
                        total_tokens=health.token_usage,
                        total_cost_usd=health.cost_usd,
                    ),
                ))
                break  # stop monitoring

        Callback 2 — Session crash / unexpected death:
            if not health.alive and not health.completed:
                await self._callback.on_failed(VentureError(
                    category=FailureCategory.CRASH,
                    message=health.error or "Session died unexpectedly",
                    recoverable=True,  # engine will resume from last checkpoint
                ))
                break  # stop monitoring

        Callback 3 — Agent explicitly requests a checkpoint:
            # Agent emits a signal when it wants to save state (e.g., before
            # a risky operation, or when it detects it's approaching a boundary)
            if health.checkpoint_requested:
                state = await session.get_state()
                await self._callback.on_checkpoint_needed(
                    reason="agent_requested",
                    state={
                        "summary": state.summary,
                        "next_steps": state.next_steps,
                        "executor_state": {"session_id": self._session_id},
                    },
                )
                # Do NOT break — monitoring continues after checkpoint

        Callback 4 — Incremental progress (tool call, step, sub-task done):
            # Session emits progress events as it works
            for event in health.new_events:
                if event.type == "progress":
                    self._last_activity = datetime.now(timezone.utc)
                    await self._callback.on_progress(ProgressUpdate(
                        message=event.message,
                        step=event.step_number,
                        metadata={"tool": event.tool_name, "cost": event.cost_usd},
                    ))
                await self._callback.on_cost_update(
                    tokens_used=event.tokens_delta,
                    cost_usd=event.cost_delta,
                )

        Callback 5 — Context window approaching limit (> checkpoint_threshold):
            # Detect when the session is burning through context.
            # Default threshold is 80% (policy.checkpoint_threshold = 0.80).
            # Fire BEFORE the window is full so the checkpoint can complete.
            usage_ratio = health.token_usage / health.context_window
            if usage_ratio > venture.policy.checkpoint_threshold:
                state = await session.get_state()
                await self._callback.on_checkpoint_needed(
                    reason="context_limit",
                    state={
                        "tokens_used": health.token_usage,
                        "context_window": health.context_window,
                        "usage_ratio": usage_ratio,
                        "summary": state.summary,
                        "next_steps": state.next_steps,
                        "executor_state": {"session_id": self._session_id},
                    },
                )
                # Do NOT break — engine handles checkpoint + resume
        """
        assert self._callback is not None

        while self._running:
            await asyncio.sleep(5)  # Poll interval — tune per health_poll_interval_seconds config

            try:
                # TODO: Uncomment and wire to real session object:
                # health = await session.health()

                # ----------------------------------------------------------
                # Callback 2: Crash guard — check this FIRST
                # ----------------------------------------------------------
                # if not health.alive and not health.completed:
                #     await self._callback.on_failed(VentureError(
                #         category=FailureCategory.CRASH,
                #         message=health.error or "Session died unexpectedly",
                #         recoverable=True,
                #     ))
                #     break

                # ----------------------------------------------------------
                # Callback 1: Normal completion
                # ----------------------------------------------------------
                # if health.completed:
                #     result = await session.result()
                #     await self._callback.on_completed(VentureResult(
                #         summary=result.summary,
                #         deliverables=result.deliverables,
                #         metrics=VentureMetrics(
                #             total_tokens=health.token_usage,
                #             total_cost_usd=health.cost_usd,
                #         ),
                #     ))
                #     break

                # ----------------------------------------------------------
                # Callback 5: Context limit check (before Callback 3 to
                # prevent losing context before agent can request CP)
                # ----------------------------------------------------------
                # usage_ratio = health.token_usage / health.context_window
                # if usage_ratio > venture.policy.checkpoint_threshold:
                #     state = await session.get_state()
                #     await self._callback.on_checkpoint_needed(
                #         reason="context_limit",
                #         state={
                #             "tokens_used": health.token_usage,
                #             "context_window": health.context_window,
                #             "usage_ratio": usage_ratio,
                #             "summary": state.summary,
                #             "next_steps": state.next_steps,
                #             "executor_state": {"session_id": self._session_id},
                #         },
                #     )
                #     continue  # engine handles checkpoint + resume

                # ----------------------------------------------------------
                # Callback 3: Agent-requested checkpoint
                # ----------------------------------------------------------
                # if health.checkpoint_requested:
                #     state = await session.get_state()
                #     await self._callback.on_checkpoint_needed(
                #         reason="agent_requested",
                #         state={
                #             "summary": state.summary,
                #             "next_steps": state.next_steps,
                #             "executor_state": {"session_id": self._session_id},
                #         },
                #     )

                # ----------------------------------------------------------
                # Callback 4: Progress events + cost updates
                # ----------------------------------------------------------
                # for event in health.new_events:
                #     self._last_activity = datetime.now(timezone.utc)
                #     if event.type == "progress":
                #         await self._callback.on_progress(ProgressUpdate(
                #             message=event.message,
                #             step=event.step_number,
                #             metadata={"tool": event.tool_name},
                #         ))
                #     if event.tokens_delta:
                #         await self._callback.on_cost_update(
                #             tokens_used=event.tokens_delta,
                #             cost_usd=event.cost_delta,
                #         )
                pass

            except Exception as exc:
                logger.exception("Monitor loop error for session %s", self._session_id)
                await self._callback.on_failed(VentureError(
                    category=FailureCategory.CRASH,
                    message=f"Monitor loop exception: {exc}",
                    recoverable=True,
                ))
                break


# NOT registered with global registry — executor is not yet functional.
# Register manually once the real agent session API is wired:
#   registry.register("antaris-agent", AntarisAgentExecutor)
