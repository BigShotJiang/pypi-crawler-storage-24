"""State machine for venture lifecycle transitions.

All transitions go through a serialized event queue. State mutations are
single-threaded even in async contexts to prevent race conditions (e.g.,
simultaneous user pause + executor checkpoint).
"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
from typing import Callable, Awaitable

from parsica_ventures.models import (
    Venture,
    VentureState,
    StateTransition,
)
from parsica_ventures.exceptions import InvalidStateTransitionError

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Transition table — defines all valid state transitions
# ---------------------------------------------------------------------------

VALID_TRANSITIONS: dict[VentureState, set[VentureState]] = {
    VentureState.CREATED: {
        VentureState.QUEUED,
        VentureState.FAILED,  # validation error
    },
    VentureState.QUEUED: {
        VentureState.RUNNING,
        VentureState.ABORTED,
    },
    VentureState.RUNNING: {
        VentureState.CHECKPOINT,
        VentureState.AWAITING_APPROVAL,
        VentureState.PAUSED,
        VentureState.COMPLETED,
        VentureState.FAILED,
        VentureState.ABORTED,
    },
    VentureState.CHECKPOINT: {
        VentureState.QUEUED,           # auto-resume
        VentureState.CHECKPOINT_FAILED,
        VentureState.PAUSED,           # checkpoint + manual hold
    },
    VentureState.CHECKPOINT_FAILED: {
        VentureState.QUEUED,   # retry succeeded
        VentureState.FAILED,   # max retries exceeded
    },
    VentureState.AWAITING_APPROVAL: {
        VentureState.RUNNING,  # approved
        VentureState.PAUSED,   # denied
        VentureState.ABORTED,  # denied + abort
    },
    VentureState.PAUSED: {
        VentureState.QUEUED,   # resume
        VentureState.ABORTED,
    },
    # Terminal states — limited outgoing transitions
    VentureState.COMPLETED: set(),
    VentureState.FAILED: {VentureState.QUEUED},  # retry (recoverable failures only)
    VentureState.ABORTED: set(),
}

# States from which a venture is considered "done" (terminal)
TERMINAL_STATES = {VentureState.COMPLETED, VentureState.FAILED, VentureState.ABORTED}

# States that count toward max_concurrent
ACTIVE_STATES = {VentureState.RUNNING, VentureState.CHECKPOINT, VentureState.AWAITING_APPROVAL}


def is_valid_transition(from_state: VentureState, to_state: VentureState) -> bool:
    """Check whether a state transition is allowed."""
    return to_state in VALID_TRANSITIONS.get(from_state, set())


def validate_transition(from_state: VentureState, to_state: VentureState) -> None:
    """Raise InvalidStateTransitionError if transition is not allowed."""
    if not is_valid_transition(from_state, to_state):
        raise InvalidStateTransitionError(
            from_state.value,
            to_state.value,
            f"Valid targets from {from_state.value}: "
            f"{sorted(s.value for s in VALID_TRANSITIONS.get(from_state, set()))}",
        )


# Type alias for transition listeners
TransitionListener = Callable[[Venture, StateTransition], Awaitable[None]]


class StateMachine:
    """Serialized state machine for venture lifecycle.

    All transition requests go through the internal event queue and are
    processed one at a time. This prevents race conditions when multiple
    sources (user CLI, executor callback, policy engine) try to transition
    the same venture simultaneously.
    """

    def __init__(self) -> None:
        self._queue: asyncio.Queue[tuple[Venture, VentureState, str, str]] = asyncio.Queue()
        self._listeners: list[TransitionListener] = []
        self._running = False
        self._task: asyncio.Task[None] | None = None

    def add_listener(self, listener: TransitionListener) -> None:
        """Register a callback for every successful state transition."""
        self._listeners.append(listener)

    async def start(self) -> None:
        """Start processing the transition queue."""
        if self._running:
            return
        self._running = True
        self._task = asyncio.create_task(self._process_loop())

    async def stop(self) -> None:
        """Stop the transition queue processor."""
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None

    async def transition(
        self,
        venture: Venture,
        to_state: VentureState,
        reason: str,
        triggered_by: str = "engine",
    ) -> StateTransition:
        """Request a state transition (queued, serialized).

        Returns the StateTransition record after it's been applied.
        Raises InvalidStateTransitionError if the transition is invalid.

        NOTE: transition() validates twice — once here (fail-fast, reject
        obviously invalid requests before they enter the queue) and again
        inside _process_loop before applying (guaranteed check, because
        another transition may have changed the venture's state between
        enqueue and dequeue).
        """
        # Validate before queueing — fail fast
        validate_transition(venture.state, to_state)

        # Apply immediately if queue processor isn't running (sync usage)
        if not self._running:
            return self._apply(venture, to_state, reason, triggered_by)

        # Queue for async serialized processing
        future: asyncio.Future[StateTransition] = asyncio.get_running_loop().create_future()
        await self._queue.put((venture, to_state, reason, triggered_by, future))  # type: ignore[arg-type]
        return await future

    def transition_sync(
        self,
        venture: Venture,
        to_state: VentureState,
        reason: str,
        triggered_by: str = "engine",
    ) -> StateTransition:
        """Synchronous transition for non-async contexts (e.g., CLI, tests)."""
        validate_transition(venture.state, to_state)
        return self._apply(venture, to_state, reason, triggered_by)

    def _apply(
        self,
        venture: Venture,
        to_state: VentureState,
        reason: str,
        triggered_by: str,
    ) -> StateTransition:
        """Apply a state transition to the venture (not thread-safe — call from queue only)."""
        record = StateTransition(
            from_state=venture.state,
            to_state=to_state,
            timestamp=datetime.now(timezone.utc),
            reason=reason,
            triggered_by=triggered_by,  # type: ignore[arg-type]
        )
        venture.state = to_state
        venture.state_history.append(record)

        # Update timestamps on key transitions
        if to_state == VentureState.RUNNING and venture.started_at is None:
            venture.started_at = record.timestamp
        if to_state in TERMINAL_STATES:
            venture.completed_at = record.timestamp

        logger.info(
            "Venture %s: %s → %s (%s, by %s)",
            venture.id,
            record.from_state.value,
            record.to_state.value,
            reason,
            triggered_by,
        )
        return record

    async def _process_loop(self) -> None:
        """Process queued transitions one at a time."""
        while self._running:
            try:
                item = await asyncio.wait_for(self._queue.get(), timeout=1.0)
            except asyncio.TimeoutError:
                continue
            except asyncio.CancelledError:
                break

            venture, to_state, reason, triggered_by, future = item  # type: ignore[misc]
            try:
                validate_transition(venture.state, to_state)
                record = self._apply(venture, to_state, reason, triggered_by)

                # Notify listeners
                for listener in self._listeners:
                    try:
                        await listener(venture, record)
                    except Exception:
                        logger.exception(
                            "Transition listener error for venture %s", venture.id
                        )

                future.set_result(record)
            except Exception as exc:
                future.set_exception(exc)
