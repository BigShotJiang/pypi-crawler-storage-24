"""Internal event bus for executor→engine→observer coordination.

Events are the internal communication layer between:
- Executor → Engine: checkpoint needed, approval needed, progress, completion
- Engine → Observer: all lifecycle events forwarded to observers

All events flow through a serialized asyncio queue for thread safety.
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Callable, Awaitable

logger = logging.getLogger(__name__)


class EventType(str, Enum):
    """Internal event types."""
    # Executor → Engine
    CHECKPOINT_NEEDED = "checkpoint_needed"
    APPROVAL_NEEDED = "approval_needed"
    PROGRESS = "progress"
    COMPLETED = "completed"
    FAILED = "failed"
    COST_UPDATE = "cost_update"

    # Engine → internal
    VENTURE_STARTED = "venture_started"
    VENTURE_PAUSED = "venture_paused"
    VENTURE_RESUMED = "venture_resumed"
    VENTURE_ABORTED = "venture_aborted"
    CHECKPOINT_SAVED = "checkpoint_saved"
    CHECKPOINT_FAILED = "checkpoint_failed"
    QUEUE_DRAIN = "queue_drain"  # signal to check queue for promotable ventures


@dataclass
class VentureEvent:
    """An internal event in the venture system."""
    type: EventType
    venture_id: str
    timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    data: dict[str, Any] = field(default_factory=dict)


# Type alias for event handlers
EventHandler = Callable[[VentureEvent], Awaitable[None]]


class EventBus:
    """Async event bus with serialized processing.

    Events are queued and processed one at a time to prevent race conditions.
    Multiple handlers can be registered per event type.
    """

    def __init__(self) -> None:
        self._queue: asyncio.Queue[VentureEvent] = asyncio.Queue()
        self._handlers: dict[EventType, list[EventHandler]] = {}
        self._global_handlers: list[EventHandler] = []
        self._running = False
        self._task: asyncio.Task[None] | None = None

    def on(self, event_type: EventType, handler: EventHandler) -> None:
        """Register a handler for a specific event type."""
        if event_type not in self._handlers:
            self._handlers[event_type] = []
        self._handlers[event_type].append(handler)

    def on_all(self, handler: EventHandler) -> None:
        """Register a handler that receives ALL events."""
        self._global_handlers.append(handler)

    async def emit(self, event: VentureEvent) -> None:
        """Emit an event to the bus (queued for serialized processing)."""
        await self._queue.put(event)

    def emit_sync(self, event: VentureEvent) -> None:
        """Emit an event synchronously (for non-async contexts).

        Note: This only works if an event loop is running.
        """
        try:
            loop = asyncio.get_running_loop()
            loop.call_soon_threadsafe(self._queue.put_nowait, event)
        except RuntimeError:
            # No event loop — just put directly
            self._queue.put_nowait(event)

    async def start(self) -> None:
        """Start processing events."""
        if self._running:
            return
        self._running = True
        self._task = asyncio.create_task(self._process_loop())

    async def stop(self) -> None:
        """Stop processing events."""
        self._running = False
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None

    async def _process_loop(self) -> None:
        """Process events one at a time from the queue."""
        while self._running:
            try:
                event = await asyncio.wait_for(self._queue.get(), timeout=1.0)
            except asyncio.TimeoutError:
                continue
            except asyncio.CancelledError:
                break

            # Dispatch to type-specific handlers
            handlers = self._handlers.get(event.type, [])
            for handler in handlers:
                try:
                    await handler(event)
                except Exception:
                    logger.exception(
                        "Event handler error for %s (venture %s)",
                        event.type.value,
                        event.venture_id,
                    )

            # Dispatch to global handlers
            for handler in self._global_handlers:
                try:
                    await handler(event)
                except Exception:
                    logger.exception(
                        "Global event handler error for %s (venture %s)",
                        event.type.value,
                        event.venture_id,
                    )
