"""Stdout observer — prints venture events to the terminal.

Useful for CLI usage and development/debugging.
"""

from __future__ import annotations

from datetime import datetime, timezone

from parsica_ventures.models import (
    Venture,
    Checkpoint,
    ProgressUpdate,
    VentureResult,
    VentureError,
)


class StdoutObserver:
    """Prints venture lifecycle events to stdout."""

    def __init__(self, verbose: bool = False):
        self.verbose = verbose

    def _ts(self) -> str:
        return datetime.now(timezone.utc).strftime("%H:%M:%S UTC")

    async def on_started(self, venture: Venture) -> None:
        print(f"[{self._ts()}] ▶ Venture started: {venture.title} ({venture.id})")

    async def on_progress(self, venture: Venture, update: ProgressUpdate) -> None:
        step_str = f" [step {update.step}]" if update.step is not None else ""
        print(f"[{self._ts()}]  {step_str} {update.message}")

    async def on_checkpoint(self, venture: Venture, checkpoint: Checkpoint) -> None:
        print(
            f"[{self._ts()}] 💾 Checkpoint: {checkpoint.reason.value if hasattr(checkpoint.reason, 'value') else checkpoint.reason} "
            f"— {checkpoint.progress_summary[:80]}"
        )
        if self.verbose and checkpoint.next_steps:
            for step in checkpoint.next_steps:
                print(f"          → {step.description}")

    async def on_approval_needed(self, venture: Venture, gate: str, context: dict) -> None:
        print(f"[{self._ts()}] ⏸️  Approval needed: {gate}")
        if context:
            print(f"          Context: {context}")

    async def on_completed(self, venture: Venture, result: VentureResult) -> None:
        print(f"[{self._ts()}] ✅ Venture completed: {venture.title}")
        print(f"          {result.summary}")
        if result.deliverables:
            for d in result.deliverables:
                print(f"          📦 [{d.type.value}] {d.title}")
        if result.metrics:
            m = result.metrics
            parts = []
            if m.duration_seconds:
                parts.append(f"{m.duration_seconds:.0f}s")
            if m.total_tokens:
                parts.append(f"{m.total_tokens} tokens")
            if m.total_cost_usd:
                parts.append(f"${m.total_cost_usd:.4f}")
            if m.checkpoint_count:
                parts.append(f"{m.checkpoint_count} checkpoints")
            if parts:
                print(f"          📊 {' · '.join(parts)}")

    async def on_failed(self, venture: Venture, error: VentureError) -> None:
        print(
            f"[{self._ts()}] ❌ Venture failed: {venture.title} "
            f"({error.category.value})"
        )
        print(f"          {error.message}")
        if error.recoverable:
            print(f"          ↩️  Recoverable — use `ventures retry {venture.id}`")

    async def on_paused(self, venture: Venture) -> None:
        print(f"[{self._ts()}] ⏸️  Venture paused: {venture.title} ({venture.id})")

    async def on_aborted(self, venture: Venture) -> None:
        print(f"[{self._ts()}] 🛑 Venture aborted: {venture.title} ({venture.id})")
