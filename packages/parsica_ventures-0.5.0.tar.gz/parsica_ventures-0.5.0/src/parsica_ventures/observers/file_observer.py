"""File observer — appends venture events to JSON Lines log files.

Log files: ~/.parsica/ventures/logs/<venture_id>/events.jsonl
All output is sanitized to strip known secret patterns.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from parsica_ventures.models import (
    Venture,
    Checkpoint,
    ProgressUpdate,
    VentureResult,
    VentureError,
)
from parsica_ventures.sanitizer import sanitize_dict

logger = logging.getLogger(__name__)


class FileObserver:
    """Appends venture lifecycle events as JSON Lines to a log file."""

    def __init__(self, log_dir: str | Path | None = None):
        self._log_dir = Path(log_dir) if log_dir else Path.home() / ".parsica" / "ventures" / "logs"

    def _log_path(self, venture_id: str) -> Path:
        path = self._log_dir / venture_id
        path.mkdir(parents=True, exist_ok=True)
        return path / "events.jsonl"

    def _write_event(self, venture_id: str, event_type: str, data: dict[str, Any]) -> None:
        """Write a single event line to the log file."""
        entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "type": event_type,
            "venture_id": venture_id,
            **sanitize_dict(data),
        }
        try:
            path = self._log_path(venture_id)
            with open(path, "a") as f:
                f.write(json.dumps(entry, default=str) + "\n")
        except Exception:
            logger.warning("Failed to write event to log file", exc_info=True)

    async def on_started(self, venture: Venture) -> None:
        self._write_event(venture.id, "started", {
            "title": venture.title,
            "executor_type": venture.executor_type,
            "goal": venture.goal[:500],
        })

    async def on_progress(self, venture: Venture, update: ProgressUpdate) -> None:
        self._write_event(venture.id, "progress", {
            "step": update.step,
            "message": update.message,
        })

    async def on_checkpoint(self, venture: Venture, checkpoint: Checkpoint) -> None:
        self._write_event(venture.id, "checkpoint", {
            "checkpoint_id": checkpoint.id,
            "reason": checkpoint.reason.value,
            "summary": checkpoint.progress_summary[:500],
            "next_steps_count": len(checkpoint.next_steps),
            "files_modified_count": len(checkpoint.files_modified),
        })

    async def on_approval_needed(self, venture: Venture, gate: str, context: dict) -> None:
        self._write_event(venture.id, "approval_needed", {
            "gate": gate,
            "context": context,
        })

    async def on_completed(self, venture: Venture, result: VentureResult) -> None:
        self._write_event(venture.id, "completed", {
            "summary": result.summary[:500],
            "deliverables_count": len(result.deliverables),
            "metrics": result.metrics.model_dump() if result.metrics else {},
        })

    async def on_failed(self, venture: Venture, error: VentureError) -> None:
        self._write_event(venture.id, "failed", {
            "category": error.category.value,
            "message": error.message[:500],
            "recoverable": error.recoverable,
            "retry_count": error.retry_count,
        })

    async def on_paused(self, venture: Venture) -> None:
        self._write_event(venture.id, "paused", {})

    async def on_aborted(self, venture: Venture) -> None:
        self._write_event(venture.id, "aborted", {})


def read_log(venture_id: str, log_dir: str | Path | None = None, limit: int = 100) -> list[dict]:
    """Read events from a venture's log file.

    Returns the last `limit` events as dicts.
    """
    base = Path(log_dir) if log_dir else Path.home() / ".parsica" / "ventures" / "logs"
    path = base / venture_id / "events.jsonl"
    if not path.exists():
        return []

    events = []
    try:
        with open(path) as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        events.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue
    except OSError:
        logger.warning("Failed to read log file %s", path)
        return []

    return events[-limit:]
