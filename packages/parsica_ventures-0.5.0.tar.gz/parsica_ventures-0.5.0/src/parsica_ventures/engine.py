"""VentureEngine — the core lifecycle orchestrator.

Manages venture creation, state transitions, checkpoint/resume,
executor coordination, observer notification, and policy enforcement.

The engine does NOT run ventures itself — it delegates to executors.
It manages the lifecycle around execution.

Queue drain strategy (per Delta NI-2):
Event-driven — on any venture reaching a terminal or blocked state
(COMPLETED, FAILED, ABORTED, PAUSED, CHECKPOINT), check the queue
and promote the next QUEUED venture to RUNNING if
running_count < max_concurrent.
"""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path
from typing import Any

from parsica_ventures.models import (
    Venture,
    VentureState,
    VenturePolicy,
    VentureResult,
    VentureError,
    VentureMetrics,
    FailureCategory,
    Checkpoint,
    CheckpointData,
    CheckpointReason,
    ProgressUpdate,
    StateTransition,
    ExecutorHandle,
    ApprovalRequest,
    VentureNotification,
)
from parsica_ventures.state import StateMachine, ACTIVE_STATES
from parsica_ventures.store import VentureStore
from parsica_ventures.checkpoint import (
    create_checkpoint,
    save_checkpoint_atomic,
    verify_file_integrity,
)
from parsica_ventures.memory_bridge import (
    MemoryBridge,
    NoopMemoryBridge,
    save_memories_backup,
    load_memories_backup,
    create_memory_bridge,
)
from parsica_ventures.policy import PolicyEngine
from parsica_ventures.executor import ExecutorCallback, ExecutorRegistry, registry as global_registry
from parsica_ventures.observer import MultiObserver
from parsica_ventures.secrets import resolve_secrets_in_dict, check_for_plaintext_secrets
from parsica_ventures.config import VenturesConfig, load_config
from parsica_ventures.events import EventBus, EventType, VentureEvent
from parsica_ventures.exceptions import (
    VentureNotFoundError,
    CheckpointError,
    ExecutorError,
    PolicyViolationError,
    SecretResolutionError,
)

logger = logging.getLogger(__name__)


class VentureEngine:
    """The core venture lifecycle engine.

    Ties together: state machine, store, executors, observers,
    policy, memory bridge, and event bus.
    """

    def __init__(
        self,
        config: VenturesConfig | None = None,
        store: VentureStore | None = None,
        memory_bridge: MemoryBridge | None = None,
        executor_registry: ExecutorRegistry | None = None,
    ):
        self.config = config or load_config()
        self.store = store or VentureStore(
            db_path=f"{self.config.store_path}/ventures.db"
        )
        self.memory = memory_bridge or create_memory_bridge(
            enabled=self.config.memory.enabled,
            store_path=self.config.memory.store_path,
            tag_prefix=self.config.memory.tag_prefix,
        )
        self.registry = executor_registry or global_registry
        self.state_machine = StateMachine()
        self.policy = PolicyEngine()
        self.observer = MultiObserver()
        self.event_bus = EventBus()

        # Active executor handles — venture_id → (executor, handle)
        self._active: dict[str, tuple[Any, ExecutorHandle]] = {}

        # Approval timeout timers — approval_id → asyncio.Task
        self._approval_timers: dict[str, asyncio.Task[None]] = {}

        # Register event handlers
        self._register_event_handlers()

    def _register_event_handlers(self) -> None:
        """Wire internal event handlers."""
        self.event_bus.on(EventType.QUEUE_DRAIN, self._handle_queue_drain)

    # -------------------------------------------------------------------
    # Venture creation
    # -------------------------------------------------------------------

    def create_venture(
        self,
        title: str,
        goal: str,
        exit_condition: str,
        executor_type: str | None = None,
        executor_config: dict[str, Any] | None = None,
        policy: VenturePolicy | None = None,
        observer_configs: list[dict[str, Any]] | None = None,
        notification: VentureNotification | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Venture:
        """Create a new venture and persist it.

        Validates executor type against registry (fail fast).
        Checks executor_config for plaintext secrets. By default these are
        rejected at creation time so secrets are not persisted to SQLite.
        """
        exec_type = executor_type or self.config.default_executor
        if not self.registry.is_registered(exec_type):
            raise ExecutorError(
                f"Unknown executor type: '{exec_type}'. "
                f"Available: {self.registry.list_registered()}"
            )

        exec_config = executor_config or {}
        allow_plaintext = bool((metadata or {}).get("allow_plaintext", False))
        warnings = check_for_plaintext_secrets(exec_config)
        if warnings and not allow_plaintext:
            raise SecretResolutionError(
                "Plaintext secrets detected in executor_config: "
                + "; ".join(warnings)
            )
        for w in warnings:
            logger.warning(w)

        venture = Venture(
            title=title,
            goal=goal,
            exit_condition=exit_condition,
            executor_type=exec_type,
            executor_config=exec_config,
            policy=policy or VenturePolicy(),
            observer_configs=observer_configs or [],
            notification=notification,
            metadata=metadata or {},
        )

        self.store.save_venture(venture)
        logger.info("Created venture %s: %s", venture.id, title)
        return venture

    # -------------------------------------------------------------------
    # Venture lifecycle commands
    # -------------------------------------------------------------------

    async def start_venture(self, venture_id: str) -> ExecutorHandle | None:
        """Start a venture — transition to QUEUED, then RUNNING if slot available.

        Returns ExecutorHandle if started immediately, None if queued waiting for a slot.
        """
        venture = self._get_venture(venture_id)

        # CREATED → QUEUED
        transition = self.state_machine.transition_sync(
            venture, VentureState.QUEUED, "start requested", "user"
        )
        self.store.save_transition(venture_id, transition)
        self.store.save_venture(venture)

        # Try to promote to RUNNING immediately
        return await self._try_start(venture)

    async def pause_venture(self, venture_id: str) -> None:
        """Pause a running venture."""
        venture = self._get_venture(venture_id)

        # Pause the executor if active
        if venture_id in self._active:
            executor, handle = self._active[venture_id]
            try:
                await executor.pause(venture)
            except Exception:
                logger.warning("Failed to pause executor for %s", venture_id, exc_info=True)

        transition = self.state_machine.transition_sync(
            venture, VentureState.PAUSED, "user requested pause", "user"
        )
        self.store.save_transition(venture_id, transition)
        self.store.save_venture(venture)
        await self.observer.on_paused(venture)
        await self._emit_queue_drain()

    async def resume_venture(self, venture_id: str) -> ExecutorHandle | None:
        """Resume a paused venture from its last checkpoint.

        Returns ExecutorHandle if started immediately, None if queued waiting for a slot.
        """
        venture = self._get_venture(venture_id)

        # PAUSED → QUEUED
        transition = self.state_machine.transition_sync(
            venture, VentureState.QUEUED, "resume requested", "user"
        )
        self.store.save_transition(venture_id, transition)
        self.store.save_venture(venture)

        return await self._try_start(venture)

    async def abort_venture(self, venture_id: str) -> None:
        """Abort a venture."""
        venture = self._get_venture(venture_id)

        # Abort the executor if active
        if venture_id in self._active:
            executor, handle = self._active[venture_id]
            try:
                await executor.abort(venture)
            except Exception:
                logger.warning("Failed to abort executor for %s", venture_id, exc_info=True)
            del self._active[venture_id]

        transition = self.state_machine.transition_sync(
            venture, VentureState.ABORTED, "user requested abort", "user"
        )
        self.store.save_transition(venture_id, transition)
        self.store.save_venture(venture)
        await self.observer.on_aborted(venture)
        await self._emit_queue_drain()

    async def checkpoint_venture(self, venture_id: str) -> Checkpoint:
        """Manually trigger a checkpoint on a running venture.

        Per Delta NI-7: `ventures checkpoint <id>` asks the engine to
        request a checkpoint from the executor. The engine calls
        executor.checkpoint() which produces CheckpointData. The state
        transition is the same as any other checkpoint.
        """
        venture = self._get_venture(venture_id)

        if venture_id not in self._active:
            raise ExecutorError(f"No active executor for venture {venture_id}")

        executor, handle = self._active[venture_id]

        # Get checkpoint data from executor
        data = await executor.checkpoint(venture)

        # Process the checkpoint
        return await self._process_checkpoint(
            venture, data, CheckpointReason.MANUAL
        )

    async def retry_venture(self, venture_id: str) -> ExecutorHandle | None:
        """Retry a failed venture from its last checkpoint.

        Per Delta Condition #2:
        - Only available for FAILED ventures with recoverable=True
        - LOGIC failures (recoverable=False) cannot be retried
        - Transitions to QUEUED, then attempts RUNNING
        """
        venture = self._get_venture(venture_id)

        if venture.state != VentureState.FAILED:
            raise ExecutorError(
                f"Can only retry FAILED ventures (current: {venture.state.value})"
            )

        if venture.error and not venture.error.recoverable:
            raise ExecutorError(
                f"Venture failed with non-recoverable error "
                f"(category: {venture.error.category.value}). Cannot retry."
            )

        # Increment retry count
        if venture.error:
            venture.error.retry_count += 1

        # FAILED → QUEUED (via state machine — no raw state manipulation)
        transition = self.state_machine.transition_sync(
            venture, VentureState.QUEUED, "retry requested", "user"
        )
        self.store.save_transition(venture_id, transition)
        self.store.save_venture(venture)

        return await self._try_start(venture)

    # -------------------------------------------------------------------
    # Approval gates
    # -------------------------------------------------------------------

    async def request_approval(
        self,
        venture_id: str,
        gate: str,
        context: dict[str, Any] | None = None,
    ) -> ApprovalRequest:
        """Request approval for a gate — transition RUNNING → AWAITING_APPROVAL.

        Creates an ApprovalRequest, saves to store, notifies observers,
        and starts a timeout timer based on the venture's policy.
        """
        venture = self._get_venture(venture_id)

        # Pause the executor while awaiting approval
        if venture_id in self._active:
            executor, handle = self._active[venture_id]
            try:
                await executor.pause(venture)
            except Exception:
                logger.warning("Failed to pause executor for %s at gate %s", venture_id, gate, exc_info=True)

        # Transition RUNNING → AWAITING_APPROVAL
        transition = self.state_machine.transition_sync(
            venture, VentureState.AWAITING_APPROVAL,
            f"approval requested: gate={gate}", "engine"
        )
        self.store.save_transition(venture_id, transition)

        # Create and persist the approval request
        ar = ApprovalRequest(
            venture_id=venture_id,
            gate=gate,
            context=context or {},
        )
        self.store.save_approval_request(ar)
        self.store.save_venture(venture)

        # Notify observers
        await self.observer.on_approval_needed(venture, gate, ar.context)

        # Start timeout timer
        timeout = venture.policy.gate_timeout_seconds
        if timeout and timeout > 0:
            timer = asyncio.ensure_future(
                self._approval_timeout(ar.id, venture_id, timeout, venture.policy.gate_timeout_action)
            )
            self._approval_timers[ar.id] = timer

        logger.info(
            "Approval requested for venture %s: gate=%s, id=%s, timeout=%ds",
            venture_id, gate, ar.id, timeout,
        )
        return ar

    async def resolve_approval(
        self,
        approval_id: str,
        resolution: str,
        resolved_by: str | None = None,
    ) -> ApprovalRequest | None:
        """Resolve an approval request.

        On "approved": AWAITING_APPROVAL → RUNNING, resume executor.
        On "denied": AWAITING_APPROVAL → PAUSED (or ABORTED per policy).
        On "timeout": handled by the timeout action policy.
        """
        # Cancel timeout timer if still running
        timer = self._approval_timers.pop(approval_id, None)
        if timer and not timer.done():
            timer.cancel()

        # Update the approval record in the store
        ar = self.store.resolve_approval(approval_id, resolution, resolved_by)
        if ar is None:
            logger.warning("Approval request %s not found or already resolved", approval_id)
            return None

        venture = self._get_venture(ar.venture_id)

        if resolution == "approved":
            latest_cp = self.store.get_latest_checkpoint(venture.id)

            if latest_cp is None:
                # No checkpoint — cannot resume. Stay PAUSED honestly.
                transition = self.state_machine.transition_sync(
                    venture, VentureState.PAUSED,
                    f"approval granted but no checkpoint to resume: gate={ar.gate}", "user"
                )
                self.store.save_transition(venture.id, transition)
                self.store.save_venture(venture)
                if venture.id in self._active:
                    executor, handle = self._active[venture.id]
                    try:
                        await executor.abort(venture)
                    except Exception:
                        logger.warning("Failed to stop executor for %s (no checkpoint)", venture.id, exc_info=True)
                    del self._active[venture.id]
                await self.observer.on_paused(venture)
                await self.observer.on_needs_instructions(
                    venture,
                    f"Venture '{venture.title}' was approved at gate '{ar.gate}' but has no checkpoint to resume from. It is now paused and waiting for new instructions.",
                )
                await self._emit_queue_drain()
                logger.info("Approval granted for venture %s but no checkpoint exists; kept in PAUSED state", venture.id)
            else:
                # Checkpoint exists — attempt resume BEFORE persisting RUNNING state
                resumed = False
                if venture.id in self._active:
                    executor, handle = self._active[venture.id]
                    try:
                        await executor.resume(venture, latest_cp, self._make_callback(venture.id))
                        resumed = True
                    except Exception:
                        logger.warning("Failed to resume executor for %s after approval", venture.id, exc_info=True)

                if resumed:
                    transition = self.state_machine.transition_sync(
                        venture, VentureState.RUNNING,
                        f"approval granted: gate={ar.gate}", "user"
                    )
                else:
                    # Resume failed — stay PAUSED
                    transition = self.state_machine.transition_sync(
                        venture, VentureState.PAUSED,
                        f"approval granted but resume failed: gate={ar.gate}", "user"
                    )
                    if venture.id in self._active:
                        try:
                            await self._active[venture.id][0].abort(venture)
                        except Exception:
                            pass
                        del self._active[venture.id]
                    await self.observer.on_paused(venture)
                    await self.observer.on_needs_instructions(
                        venture,
                        f"Venture '{venture.title}' was approved at gate '{ar.gate}' but failed to resume execution. It is now paused and waiting for new instructions.",
                    )
                    await self._emit_queue_drain()

                self.store.save_transition(venture.id, transition)
                self.store.save_venture(venture)

            logger.info("Venture %s approved at gate=%s by %s → %s", venture.id, ar.gate, resolved_by, venture.state.value)

        elif resolution == "denied":
            # Stop the executor — it was paused at approval request
            if venture.id in self._active:
                executor, handle = self._active[venture.id]
                try:
                    await executor.abort(venture)
                except Exception:
                    logger.warning("Failed to stop executor for %s after denial", venture.id, exc_info=True)
                del self._active[venture.id]

            # Check policy for deny action — default to PAUSED
            target_state = VentureState.PAUSED
            transition = self.state_machine.transition_sync(
                venture, target_state,
                f"approval denied: gate={ar.gate}", "user"
            )
            self.store.save_transition(venture.id, transition)
            self.store.save_venture(venture)
            await self.observer.on_paused(venture)
            await self._emit_queue_drain()
            logger.info("Venture %s denied at gate=%s by %s → %s", venture.id, ar.gate, resolved_by, target_state.value)

        elif resolution == "timeout":
            # Handled by _approval_timeout — this path is for explicit timeout resolution
            await self._apply_timeout_action(venture, ar)

        return ar

    async def _approval_timeout(
        self,
        approval_id: str,
        venture_id: str,
        timeout_seconds: int,
        timeout_action: str,
    ) -> None:
        """Fire after gate_timeout_seconds if no resolution arrives."""
        try:
            await asyncio.sleep(timeout_seconds)
        except asyncio.CancelledError:
            return  # Approval was resolved before timeout

        # Check if still pending
        ar = self.store.get_approval_request(approval_id)
        if ar is None or ar.resolution != "pending":
            return

        # Check if the venture has moved on from AWAITING_APPROVAL
        venture = self._get_venture(venture_id)
        if venture.state != VentureState.AWAITING_APPROVAL:
            # Venture has moved on — resolve approval record as timeout
            # without applying a state transition
            self.store.resolve_approval(approval_id, "timeout")
            self._approval_timers.pop(approval_id, None)
            logger.info(
                "Approval timeout for venture %s (gate=%s) — venture already in %s, skipping state transition",
                venture_id, ar.gate, venture.state.value,
            )
            return

        # Resolve as timeout
        self.store.resolve_approval(approval_id, "timeout")
        ar = self.store.get_approval_request(approval_id)
        self._approval_timers.pop(approval_id, None)

        await self._apply_timeout_action(venture, ar)

        logger.warning(
            "Approval timeout for venture %s: gate=%s, action=%s",
            venture_id, ar.gate, timeout_action,
        )

    async def _apply_timeout_action(self, venture: Venture, ar: ApprovalRequest) -> None:
        """Apply the configured timeout action to a venture."""
        action = venture.policy.gate_timeout_action

        if action == "auto_approve":
            latest_cp = self.store.get_latest_checkpoint(venture.id)

            if latest_cp is None:
                # No checkpoint — cannot resume. Stay PAUSED.
                if venture.id in self._active:
                    try:
                        await self._active[venture.id][0].abort(venture)
                    except Exception:
                        pass
                    del self._active[venture.id]
                transition = self.state_machine.transition_sync(
                    venture, VentureState.PAUSED,
                    f"auto-approve timeout but no checkpoint: gate={ar.gate}", "engine"
                )
                self.store.save_transition(venture.id, transition)
                self.store.save_venture(venture)
                await self.observer.on_paused(venture)
                await self.observer.on_needs_instructions(
                    venture,
                    f"Venture '{venture.title}' auto-approved on timeout at gate '{ar.gate}' but has no checkpoint to resume from. It is now paused and waiting for new instructions.",
                )
                await self._emit_queue_drain()
            else:
                # Attempt resume BEFORE persisting RUNNING state
                resumed = False
                if venture.id in self._active:
                    executor, handle = self._active[venture.id]
                    try:
                        await executor.resume(venture, latest_cp, self._make_callback(venture.id))
                        resumed = True
                    except Exception:
                        logger.warning("Failed to resume executor for %s after auto-approve timeout", venture.id, exc_info=True)

                if resumed:
                    transition = self.state_machine.transition_sync(
                        venture, VentureState.RUNNING,
                        f"auto-approved on timeout: gate={ar.gate}", "engine"
                    )
                else:
                    transition = self.state_machine.transition_sync(
                        venture, VentureState.PAUSED,
                        f"auto-approve timeout but resume failed: gate={ar.gate}", "engine"
                    )
                    if venture.id in self._active:
                        try:
                            await self._active[venture.id][0].abort(venture)
                        except Exception:
                            pass
                        del self._active[venture.id]
                    await self.observer.on_paused(venture)
                    await self.observer.on_needs_instructions(
                        venture,
                        f"Venture '{venture.title}' auto-approved on timeout at gate '{ar.gate}' but failed to resume execution. It is now paused and waiting for new instructions.",
                    )
                    await self._emit_queue_drain()

                self.store.save_transition(venture.id, transition)
                self.store.save_venture(venture)

        elif action == "auto_abort":
            if venture.id in self._active:
                executor, handle = self._active[venture.id]
                try:
                    await executor.abort(venture)
                except Exception:
                    logger.warning("Failed to abort executor for %s", venture.id, exc_info=True)
                del self._active[venture.id]
            transition = self.state_machine.transition_sync(
                venture, VentureState.ABORTED,
                f"approval timeout → abort: gate={ar.gate}", "engine"
            )
            self.store.save_transition(venture.id, transition)
            self.store.save_venture(venture)
            await self.observer.on_aborted(venture)
            await self._emit_queue_drain()

        else:  # auto_pause (default)
            if venture.id in self._active:
                executor, handle = self._active[venture.id]
                try:
                    await executor.abort(venture)
                except Exception:
                    logger.warning("Failed to stop executor for %s on auto-pause timeout", venture.id, exc_info=True)
                del self._active[venture.id]
            transition = self.state_machine.transition_sync(
                venture, VentureState.PAUSED,
                f"approval timeout → pause: gate={ar.gate}", "engine"
            )
            self.store.save_transition(venture.id, transition)
            self.store.save_venture(venture)
            await self.observer.on_paused(venture)
            await self._emit_queue_drain()

    # -------------------------------------------------------------------
    # Internal lifecycle helpers
    # -------------------------------------------------------------------

    async def _try_start(self, venture: Venture) -> ExecutorHandle | None:
        """Try to promote a QUEUED venture to RUNNING.

        Checks max_concurrent limit. If at capacity, venture stays QUEUED
        and returns None (being queued is normal, not an error).
        """
        # Guard: only promote ventures that are actually QUEUED.
        # During queue drain, a venture may have been transitioned by
        # another concurrent path (e.g., aborted while queued).
        if venture.state != VentureState.QUEUED:
            return None

        active_count = self.store.count_by_state(list(ACTIVE_STATES))

        if active_count >= self.config.max_concurrent:
            logger.info(
                "Venture %s queued — at max concurrent (%d/%d)",
                venture.id, active_count, self.config.max_concurrent,
            )
            return None

        # QUEUED → RUNNING
        transition = self.state_machine.transition_sync(
            venture, VentureState.RUNNING, "executor slot available", "engine"
        )
        self.store.save_transition(venture.id, transition)

        # Resolve secrets for executor config
        resolved_config = resolve_secrets_in_dict(venture.executor_config)

        # Create executor
        executor = self.registry.create(venture.executor_type, **resolved_config)

        # Create callback
        callback = self._make_callback(venture.id)

        # Check if resuming from checkpoint
        latest_cp = self.store.get_latest_checkpoint(venture.id)
        if latest_cp:
            # Verify file integrity before resuming
            if latest_cp.files_modified:
                integrity_issues = verify_file_integrity(latest_cp.files_modified)
                for snap, issue in integrity_issues:
                    logger.warning(
                        "File integrity issue on resume for venture %s: %s — %s",
                        venture.id, snap.path, issue,
                    )

            # Try loading memories backup from checkpoint dir as fallback context
            checkpoint_dir = Path(f"{self.config.store_path}/checkpoints") / venture.id
            backup_memories = load_memories_backup(checkpoint_dir)
            if backup_memories:
                logger.info(
                    "Loaded %d memories from backup for venture %s",
                    len(backup_memories), venture.id,
                )

            handle = await executor.resume(venture, latest_cp, callback)
        else:
            handle = await executor.start(venture, callback)

        self._active[venture.id] = (executor, handle)
        self.store.save_venture(venture)
        await self.observer.on_started(venture)

        return handle

    async def _process_checkpoint(
        self,
        venture: Venture,
        data: CheckpointData,
        reason: CheckpointReason,
    ) -> Checkpoint:
        """Process a checkpoint: save state, export memories, transition."""
        try:
            # Transition to CHECKPOINT
            transition = self.state_machine.transition_sync(
                venture, VentureState.CHECKPOINT, reason.value, "engine"
            )
            self.store.save_transition(venture.id, transition)

            # Export memories for backup
            memory_ids = []
            memories_export = []
            if self.memory.available():
                memories_export = self.memory.export_venture_memories(venture.id)
                memory_ids = [m.get("id", "") for m in memories_export if isinstance(m, dict)]

            # Create checkpoint record from executor data
            checkpoint = create_checkpoint(
                venture_id=venture.id,
                data=data,
                reason=reason,
                memory_ids=memory_ids,
            )

            # Save atomically to disk
            checkpoint_dir = f"{self.config.store_path}/checkpoints"
            save_checkpoint_atomic(checkpoint, checkpoint_dir)

            # Save memories backup alongside checkpoint
            if memories_export:
                from pathlib import Path
                cp_dir = Path(checkpoint_dir) / venture.id
                save_memories_backup(memories_export, cp_dir)

            # Save to DB
            self.store.save_checkpoint(checkpoint)
            venture.checkpoints.append(checkpoint)

            # Notify observer
            await self.observer.on_checkpoint(venture, checkpoint)

            # Remove active executor
            if venture.id in self._active:
                del self._active[venture.id]

            # Transition to QUEUED for auto-resume.
            # CHECKPOINT → PAUSED is also valid, but is only used when a user
            # or future approval gate explicitly wants a checkpointed manual hold
            # instead of automatic resume. Phase 1 always auto-resumes here.
            transition = self.state_machine.transition_sync(
                venture, VentureState.QUEUED, "checkpoint complete, auto-resume", "engine"
            )
            self.store.save_transition(venture.id, transition)
            self.store.save_venture(venture)

            # Try to resume immediately
            result = await self._try_start(venture)
            if result is None:
                logger.info("Venture %s waiting for executor slot after checkpoint", venture.id)

            return checkpoint

        except CheckpointError:
            # Checkpoint write failed
            transition = self.state_machine.transition_sync(
                venture, VentureState.CHECKPOINT_FAILED,
                "checkpoint write failed", "engine"
            )
            self.store.save_transition(venture.id, transition)
            self.store.save_venture(venture)
            raise

    def _make_callback(self, venture_id: str) -> ExecutorCallback:
        """Create an ExecutorCallback implementation for a specific venture.

        This is the concrete implementation of the callback protocol.
        The executor calls these methods; the engine handles state
        transitions, persistence, and observer notification.
        """

        engine = self

        class EngineCallback(ExecutorCallback):
            """ExecutorCallback implementation backed by VentureEngine."""

            async def on_checkpoint_needed(self, reason: str, state: dict[str, Any]) -> None:
                venture = engine._get_venture(venture_id)
                data = CheckpointData(
                    progress_summary=state.get("summary", "Checkpoint requested"),
                    next_steps=state.get("next_steps", []),
                    files_modified=state.get("files_modified", []),
                    decisions_log=state.get("decisions_log", []),
                    executor_state=state,
                )
                cp_reason = CheckpointReason.CONTEXT_LIMIT if "context" in reason.lower() else CheckpointReason.MANUAL
                await engine._process_checkpoint(venture, data, cp_reason)

            async def on_approval_needed(self, gate: str, context: dict[str, Any]) -> None:
                await engine.request_approval(venture_id, gate, context)

            async def on_progress(self, update: ProgressUpdate) -> None:
                venture = engine._get_venture(venture_id)
                venture.progress.append(update)
                engine.store.save_progress(venture_id, update)
                await engine.observer.on_progress(venture, update)

            async def on_completed(self, result: VentureResult) -> None:
                venture = engine._get_venture(venture_id)
                venture.result = result

                transition = engine.state_machine.transition_sync(
                    venture, VentureState.COMPLETED, "executor reported completion", "executor"
                )
                engine.store.save_transition(venture_id, transition)

                if venture_id in engine._active:
                    del engine._active[venture_id]

                engine.store.save_venture(venture)
                await engine.observer.on_completed(venture, result)
                await engine._emit_queue_drain()

            async def on_failed(self, error: VentureError) -> None:
                venture = engine._get_venture(venture_id)
                venture.error = error

                # Check retry policy
                retry_policy = engine.policy.get_retry_policy(error)
                if error.retry_count < retry_policy["max_retries"]:
                    error.recoverable = True

                transition = engine.state_machine.transition_sync(
                    venture, VentureState.FAILED,
                    f"executor failed: {error.message}", "executor"
                )
                engine.store.save_transition(venture_id, transition)

                if venture_id in engine._active:
                    del engine._active[venture_id]

                engine.store.save_venture(venture)
                await engine.observer.on_failed(venture, error)
                await engine._emit_queue_drain()

            async def on_cost_update(self, tokens_used: int, cost_usd: float) -> None:
                # Atomic SQL increment — avoids read-modify-write race conditions
                # even if callbacks are invoked from threaded executors.
                engine.store.increment_cost(venture_id, tokens_used, cost_usd)

                # Re-read venture to check cost ceiling with updated totals
                venture = engine._get_venture(venture_id)
                policy_error = engine.policy.check_cost(venture)
                if policy_error:
                    await self.on_failed(policy_error)

        return EngineCallback()

    async def _emit_queue_drain(self) -> None:
        """Signal that a slot may be available for queued ventures.

        Event-driven queue drain: on any terminal/blocked state,
        check if queued ventures can be promoted.
        """
        await self.event_bus.emit(VentureEvent(
            type=EventType.QUEUE_DRAIN,
            venture_id="system",
        ))

    async def _handle_queue_drain(self, event: VentureEvent) -> None:
        """Promote queued ventures when executor slots become available."""
        active_count = self.store.count_by_state(list(ACTIVE_STATES))
        if active_count >= self.config.max_concurrent:
            return

        # Get queued ventures ordered by priority then creation time
        queued = self.store.list_ventures(states=[VentureState.QUEUED])
        # Sort by priority (lower number = higher priority)
        queued.sort(key=lambda v: (v.policy.priority, v.created_at))

        for venture in queued:
            if active_count >= self.config.max_concurrent:
                break
            result = await self._try_start(venture)
            if result is not None:
                active_count += 1

    # -------------------------------------------------------------------
    # Query methods
    # -------------------------------------------------------------------

    def get_venture(self, venture_id: str) -> Venture:
        """Get a venture by ID. Raises VentureNotFoundError if not found."""
        return self._get_venture(venture_id)

    def list_ventures(
        self,
        states: list[VentureState] | None = None,
        limit: int = 100,
    ) -> list[Venture]:
        """List ventures with optional state filter."""
        return self.store.list_ventures(states=states, limit=limit)

    def _get_venture(self, venture_id: str) -> Venture:
        """Internal helper — get venture or raise."""
        venture = self.store.get_venture(venture_id)
        if not venture:
            raise VentureNotFoundError(venture_id)
        return venture

    # -------------------------------------------------------------------
    # Lifecycle
    # -------------------------------------------------------------------

    async def start(self) -> None:
        """Start the engine's async components."""
        await self.state_machine.start()
        await self.event_bus.start()
        logger.info("VentureEngine started")

    async def stop(self) -> None:
        """Stop the engine gracefully."""
        # Cancel any pending approval timers
        for timer in self._approval_timers.values():
            if not timer.done():
                timer.cancel()
        self._approval_timers.clear()

        await self.event_bus.stop()
        await self.state_machine.stop()
        self.store.close()
        logger.info("VentureEngine stopped")
