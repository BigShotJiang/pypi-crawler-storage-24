"""Typed exceptions for Parsica Ventures."""


class VenturesError(Exception):
    """Base exception for all Parsica Ventures errors."""


class VentureNotFoundError(VenturesError):
    """Venture ID does not exist in the store."""

    def __init__(self, venture_id: str):
        self.venture_id = venture_id
        super().__init__(f"Venture not found: {venture_id}")


class InvalidStateTransitionError(VenturesError):
    """Attempted state transition is not allowed."""

    def __init__(self, from_state: str, to_state: str, reason: str = ""):
        self.from_state = from_state
        self.to_state = to_state
        msg = f"Invalid transition: {from_state} → {to_state}"
        if reason:
            msg += f" ({reason})"
        super().__init__(msg)


class CheckpointError(VenturesError):
    """Checkpoint write or read failed."""


class CheckpointCorruptedError(CheckpointError):
    """Checkpoint data is corrupted or incomplete."""


class ExecutorError(VenturesError):
    """Executor failed to start, communicate, or complete."""


class ExecutorLaunchError(ExecutorError):
    """Executor failed to start."""


class ExecutorTimeoutError(ExecutorError):
    """Executor did not respond within the expected time."""


class PolicyViolationError(VenturesError):
    """A policy limit was exceeded."""

    def __init__(self, policy_field: str, limit: object, actual: object):
        self.policy_field = policy_field
        self.limit = limit
        self.actual = actual
        super().__init__(
            f"Policy violation: {policy_field} limit={limit}, actual={actual}"
        )


class SecretResolutionError(VenturesError):
    """A $secret reference could not be resolved, or plaintext secrets detected."""

    def __init__(self, message: str, env_var: str | None = None):
        self.env_var = env_var
        super().__init__(message)


class ConfigError(VenturesError):
    """Configuration loading or validation failed."""


class StoreError(VenturesError):
    """Database operation failed."""


class ApprovalTimeoutError(VenturesError):
    """Approval gate timed out without a response."""

    def __init__(self, gate: str, timeout_seconds: int):
        self.gate = gate
        self.timeout_seconds = timeout_seconds
        super().__init__(
            f"Approval gate '{gate}' timed out after {timeout_seconds}s"
        )
