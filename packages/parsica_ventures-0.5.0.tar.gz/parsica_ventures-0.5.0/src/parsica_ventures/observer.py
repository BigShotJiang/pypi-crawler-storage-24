"""Observer protocol and multi-observer fan-out.

Observers receive venture lifecycle events and report them externally
(Discord, webhook, file, stdout). They never block execution.
"""

from __future__ import annotations

import logging
from typing import Protocol, runtime_checkable

from parsica_ventures.models import (
    Venture,
    Checkpoint,
    ProgressUpdate,
    VentureResult,
    VentureError,
)

logger = logging.getLogger(__name__)


@runtime_checkable
class VentureObserver(Protocol):
    """Protocol for venture observers."""

    async def on_started(self, venture: Venture) -> None: ...
    async def on_progress(self, venture: Venture, update: ProgressUpdate) -> None: ...
    async def on_checkpoint(self, venture: Venture, checkpoint: Checkpoint) -> None: ...
    async def on_approval_needed(self, venture: Venture, gate: str, context: dict) -> None: ...
    async def on_completed(self, venture: Venture, result: VentureResult) -> None: ...
    async def on_failed(self, venture: Venture, error: VentureError) -> None: ...
    async def on_paused(self, venture: Venture) -> None: ...
    async def on_aborted(self, venture: Venture) -> None: ...
    async def on_needs_instructions(self, venture: Venture, reason: str) -> None: ...


class MultiObserver:
    """Fan-out observer that dispatches events to multiple observers.

    Catches and logs exceptions from individual observers to prevent
    one broken observer from blocking the others.
    """

    def __init__(self, observers: list[VentureObserver] | None = None) -> None:
        self._observers: list[VentureObserver] = observers or []

    def add(self, observer: VentureObserver) -> None:
        self._observers.append(observer)

    async def _dispatch(self, method: str, *args, **kwargs) -> None:
        for obs in self._observers:
            try:
                fn = getattr(obs, method, None)
                if fn:
                    await fn(*args, **kwargs)
            except Exception:
                logger.exception(
                    "Observer %s.%s failed", type(obs).__name__, method
                )

    async def on_started(self, venture: Venture) -> None:
        await self._dispatch("on_started", venture)

    async def on_progress(self, venture: Venture, update: ProgressUpdate) -> None:
        await self._dispatch("on_progress", venture, update)

    async def on_checkpoint(self, venture: Venture, checkpoint: Checkpoint) -> None:
        await self._dispatch("on_checkpoint", venture, checkpoint)

    async def on_approval_needed(self, venture: Venture, gate: str, context: dict) -> None:
        await self._dispatch("on_approval_needed", venture, gate, context)

    async def on_completed(self, venture: Venture, result: VentureResult) -> None:
        await self._dispatch("on_completed", venture, result)

    async def on_failed(self, venture: Venture, error: VentureError) -> None:
        await self._dispatch("on_failed", venture, error)

    async def on_paused(self, venture: Venture) -> None:
        await self._dispatch("on_paused", venture)

    async def on_aborted(self, venture: Venture) -> None:
        await self._dispatch("on_aborted", venture)

    async def on_needs_instructions(self, venture: Venture, reason: str) -> None:
        await self._dispatch("on_needs_instructions", venture, reason)
