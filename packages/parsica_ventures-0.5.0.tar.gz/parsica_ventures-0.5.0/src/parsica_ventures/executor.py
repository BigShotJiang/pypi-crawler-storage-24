"""Executor protocol, callback protocol, and registry.

Executors are pluggable adapters that run the actual work. The venture
engine doesn't care HOW work gets done — it manages lifecycle, state,
and reporting. Executors implement the VentureExecutor protocol.

The ExecutorCallback is the engine's implementation passed to start().
It's the wire between executor → engine for events like checkpoint
requests, progress updates, and completion signals.

The concrete ExecutorCallback implementation lives in engine.py as
VentureEngine._make_callback(venture_id).
"""

from __future__ import annotations

import logging
from typing import Protocol, runtime_checkable, Any

from parsica_ventures.models import (
    Venture,
    Checkpoint,
    CheckpointData,
    ExecutorHandle,
    ExecutorHealth,
    ProgressUpdate,
    VentureResult,
    VentureError,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# ExecutorCallback — executor → engine communication wire
# ---------------------------------------------------------------------------

@runtime_checkable
class ExecutorCallback(Protocol):
    """Callback interface the engine provides to executors.

    The executor calls these methods to signal events back to the engine.
    The engine handles state transitions, persistence, and observer notification.
    """

    async def on_checkpoint_needed(self, reason: str, state: dict[str, Any]) -> None:
        """Executor requests a checkpoint (e.g., approaching context limit)."""
        ...

    async def on_approval_needed(self, gate: str, context: dict[str, Any]) -> None:
        """Executor needs approval before proceeding past a gate."""
        ...

    async def on_progress(self, update: ProgressUpdate) -> None:
        """Executor reports incremental progress."""
        ...

    async def on_completed(self, result: VentureResult) -> None:
        """Executor reports venture completion with results."""
        ...

    async def on_failed(self, error: VentureError) -> None:
        """Executor reports an unrecoverable failure."""
        ...

    async def on_cost_update(self, tokens_used: int, cost_usd: float) -> None:
        """Executor reports token/cost usage for budget tracking."""
        ...


# ---------------------------------------------------------------------------
# VentureExecutor — the executor protocol
# ---------------------------------------------------------------------------

@runtime_checkable
class VentureExecutor(Protocol):
    """Protocol for venture executors.

    Each executor adapts a specific runtime (subprocess, Antaris-Agent,
    OpenClaw, MCP server) to the venture lifecycle.

    Key distinction (per Delta review):
    - start() / resume() are engine-initiated: "please begin/continue work"
    - checkpoint() is called by engine when it needs the executor to save state
    - The executor signals checkpoint_needed via the callback when IT detects
      the need (e.g., context limit approaching)
    """

    async def start(
        self, venture: Venture, callback: ExecutorCallback
    ) -> ExecutorHandle:
        """Launch the executor for this venture.

        Returns an ExecutorHandle on successful launch.
        Raises ExecutorLaunchError if launch fails.
        """
        ...

    async def pause(self, venture: Venture) -> None:
        """Engine requests the executor to quiesce and save state.

        The executor should finish its current atomic operation, save
        any in-progress state, and stop.
        """
        ...

    async def checkpoint(self, venture: Venture) -> CheckpointData:
        """Engine requests the executor to produce checkpoint data.

        Called when:
        - User runs `ventures checkpoint <id>` (manual)
        - Engine detects token/time threshold
        - Policy triggers a checkpoint

        Returns CheckpointData that the engine persists as a Checkpoint record.
        """
        ...

    async def resume(
        self, venture: Venture, checkpoint: Checkpoint, callback: ExecutorCallback
    ) -> ExecutorHandle:
        """Resume execution from a checkpoint.

        The engine injects recalled memories + checkpoint data into the
        new session. Returns a new ExecutorHandle.
        """
        ...

    async def abort(self, venture: Venture) -> None:
        """Terminate the executor immediately."""
        ...

    async def health(self, venture: Venture) -> ExecutorHealth:
        """Check if the executor is alive and responsive.

        Engine polls this every N seconds. If alive=False for K consecutive
        polls, the engine triggers recovery.
        """
        ...


# ---------------------------------------------------------------------------
# ExecutorRegistry — validates and creates executors
# ---------------------------------------------------------------------------

class ExecutorRegistry:
    """Registry of available executor types.

    Validates executor_type at venture creation time (fail fast).
    Creates executor instances at start time.
    """

    def __init__(self) -> None:
        self._executors: dict[str, type] = {}

    def register(self, name: str, executor_cls: type) -> None:
        """Register an executor class under a name."""
        logger.info("Registered executor: %s → %s", name, executor_cls.__name__)
        self._executors[name] = executor_cls

    def is_registered(self, name: str) -> bool:
        """Check if an executor type is registered."""
        return name in self._executors

    def get(self, name: str) -> type:
        """Get an executor class by name.

        Raises KeyError if not registered.
        """
        if name not in self._executors:
            available = sorted(self._executors.keys())
            raise KeyError(
                f"Unknown executor type: '{name}'. "
                f"Available: {available}"
            )
        return self._executors[name]

    def create(self, name: str, **kwargs: Any) -> VentureExecutor:
        """Create an executor instance by name.

        Raises KeyError if not registered.
        """
        cls = self.get(name)
        return cls(**kwargs)  # type: ignore[return-value]

    def list_registered(self) -> list[str]:
        """List all registered executor names."""
        return sorted(self._executors.keys())


# Global registry — executors register themselves on import
registry = ExecutorRegistry()
