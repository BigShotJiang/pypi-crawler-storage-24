"""Atomic checkpoint save/restore with file integrity verification.

Checkpoints are written atomically: temp file → fsync → rename.
This ensures a process kill mid-write never corrupts checkpoint state.

File snapshots include SHA-256 checksums, verified on resume.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import tempfile
from datetime import datetime
from pathlib import Path


from parsica_ventures.models import (
    Checkpoint,
    CheckpointData,
    CheckpointReason,
    FileSnapshot,
)
from parsica_ventures.exceptions import CheckpointError, CheckpointCorruptedError

logger = logging.getLogger(__name__)

# Files smaller than this threshold get content inlined in the checkpoint
INLINE_SIZE_THRESHOLD = 10 * 1024  # 10KB


def _safe_venture_dirname(venture_id: str) -> str:
    """Return a filesystem-safe single-path-component directory name.

    Rejects path separators, traversal markers, and names that normalize away
    from a single basename. This prevents checkpoint paths from escaping the
    configured base directory.
    """
    candidate = str(venture_id).strip()
    if not candidate or candidate in {'.', '..'}:
        raise CheckpointError(f"Invalid venture_id for checkpoint path: {venture_id!r}")
    if '/' in candidate or '\\' in candidate:
        raise CheckpointError(f"Invalid venture_id for checkpoint path: {venture_id!r}")
    normalized = Path(candidate)
    if normalized.name != candidate or normalized.parent != Path('.'):
        raise CheckpointError(f"Invalid venture_id for checkpoint path: {venture_id!r}")
    return candidate


def compute_file_checksum(path: str | Path) -> str:
    """Compute SHA-256 checksum of a file."""
    sha = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(8192):
            sha.update(chunk)
    return sha.hexdigest()


def snapshot_file(path: str | Path) -> FileSnapshot:
    """Create a FileSnapshot for a file, including checksum and optional inline content."""
    p = Path(path)
    if not p.exists():
        return FileSnapshot(
            path=str(p),
            checksum="",
            size=0,
            git_committed=False,
            inline_content=None,
        )

    stat = p.stat()
    checksum = compute_file_checksum(p)
    inline = None
    if stat.st_size < INLINE_SIZE_THRESHOLD:
        try:
            inline = p.read_text(errors="replace")
        except OSError:
            pass

    # Check git status
    git_committed = _check_git_committed(p)

    return FileSnapshot(
        path=str(p),
        checksum=checksum,
        size=stat.st_size,
        git_committed=git_committed,
        inline_content=inline,
    )


def _check_git_committed(path: Path) -> bool:
    """Check if a file is committed in git (best-effort, no exception on failure)."""
    try:
        import subprocess

        result = subprocess.run(
            ["git", "status", "--porcelain", str(path)],
            capture_output=True,
            text=True,
            cwd=str(path.parent),
            timeout=5,
        )
        # Empty output means file is clean/committed
        return result.returncode == 0 and result.stdout.strip() == ""
    except Exception:
        return False


def create_checkpoint(
    venture_id: str,
    data: CheckpointData,
    reason: CheckpointReason,
    memory_ids: list[str] | None = None,
) -> Checkpoint:
    """Create a Checkpoint record from executor-produced CheckpointData.

    This wraps the raw executor output with engine metadata (IDs, timestamps,
    memory references).
    """
    return Checkpoint(
        venture_id=venture_id,
        reason=reason,
        progress_summary=data.progress_summary,
        next_steps=data.next_steps,
        memory_ids=memory_ids or [],
        files_modified=data.files_modified,
        decisions_log=data.decisions_log,
        executor_state=data.executor_state,
    )


def save_checkpoint_atomic(
    checkpoint: Checkpoint,
    base_dir: str | Path,
) -> Path:
    """Write a checkpoint to disk atomically.

    Pattern: write to temp file → fsync → rename to final path.
    The rename is atomic on POSIX, ensuring no partial writes on crash.

    Returns the path to the checkpoint file.
    """
    safe_venture_id = _safe_venture_dirname(checkpoint.venture_id)
    checkpoint_dir = Path(base_dir) / safe_venture_id
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    final_path = checkpoint_dir / f"checkpoint_{checkpoint.id}.json"

    try:
        # Serialize checkpoint — use mode='json' to produce ISO 8601 datetimes
        # instead of Python repr strings from default=str
        data = checkpoint.model_dump(mode="json")
        content = json.dumps(data, indent=2)

        # Write to temp file in same directory (same filesystem for atomic rename)
        fd, tmp_path = tempfile.mkstemp(
            dir=str(checkpoint_dir),
            prefix=".checkpoint_tmp_",
            suffix=".json",
        )
        try:
            with os.fdopen(fd, "w") as f:
                f.write(content)
                f.flush()
                os.fsync(f.fileno())
            # Atomic rename
            os.replace(tmp_path, str(final_path))
        except Exception:
            # Clean up temp file on failure
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
            raise

        logger.info("Checkpoint %s saved atomically to %s", checkpoint.id, final_path)
        return final_path

    except Exception as e:
        raise CheckpointError(f"Failed to save checkpoint {checkpoint.id}: {e}") from e


def load_checkpoint(path: str | Path) -> Checkpoint:
    """Load a checkpoint from disk.

    Raises CheckpointCorruptedError if the file is invalid.
    """
    try:
        with open(path) as f:
            data = json.load(f)
        return Checkpoint(**data)
    except json.JSONDecodeError as e:
        raise CheckpointCorruptedError(f"Invalid JSON in checkpoint file {path}: {e}") from e
    except Exception as e:
        raise CheckpointCorruptedError(f"Failed to load checkpoint from {path}: {e}") from e


def verify_file_integrity(
    snapshots: list[FileSnapshot],
) -> list[tuple[FileSnapshot, str]]:
    """Verify file checksums against checkpoint snapshots.

    Returns a list of (snapshot, issue) tuples for files that have changed.
    Empty list means all files match.
    """
    issues: list[tuple[FileSnapshot, str]] = []

    for snap in snapshots:
        path = Path(snap.path)
        if not path.exists():
            if snap.checksum:  # File existed at checkpoint time
                issues.append((snap, "file_missing"))
            continue

        current_checksum = compute_file_checksum(path)
        if snap.checksum and current_checksum != snap.checksum:
            issues.append((snap, f"checksum_mismatch (was {snap.checksum[:12]}..., now {current_checksum[:12]}...)"))

    if issues:
        for snap, issue in issues:
            logger.warning(
                "File integrity issue on resume: %s — %s", snap.path, issue
            )

    return issues
