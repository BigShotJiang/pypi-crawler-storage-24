"""Configuration loading and validation for Parsica Ventures.

Supports TOML config at ~/.parsica/ventures.toml with sensible defaults.
"""

from __future__ import annotations

import os
import logging
from pathlib import Path
from typing import Any

from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

DEFAULT_STORE_PATH = os.path.expanduser("~/.parsica/ventures")
DEFAULT_MEMORY_STORE_PATH = os.path.expanduser("~/.parsica/memory")


class MemoryConfig(BaseModel):
    enabled: bool = True
    store_path: str = DEFAULT_MEMORY_STORE_PATH
    tag_prefix: str = "ventures"
    auto_store_findings: bool = True
    cross_venture_recall: bool = True


class StorageConfig(BaseModel):
    checkpoint_retention_days: int = 7
    max_checkpoints_per_venture: int = 50
    log_retention_days: int = 90


class VenturesConfig(BaseModel):
    """Top-level ventures configuration."""
    store_path: str = DEFAULT_STORE_PATH
    max_concurrent: int = 3
    default_executor: str = "subprocess"
    default_policy: str = "checkpoints"
    default_max_duration_hours: float = 8.0
    health_poll_interval_seconds: int = 30
    health_failure_threshold: int = 3

    memory: MemoryConfig = Field(default_factory=MemoryConfig)
    storage: StorageConfig = Field(default_factory=StorageConfig)

    # Executor-specific configs (resolved at runtime)
    executors: dict[str, dict[str, Any]] = Field(default_factory=dict)
    # Observer-specific configs
    observers: dict[str, dict[str, Any]] = Field(default_factory=dict)


def _find_config_file() -> Path | None:
    """Look for ventures config in standard locations."""
    candidates = [
        Path.cwd() / "ventures.toml",
        Path.home() / ".parsica" / "ventures.toml",
        Path.home() / ".config" / "parsica" / "ventures.toml",
    ]
    # Also check PARSICA_VENTURES_CONFIG env var
    env_path = os.environ.get("PARSICA_VENTURES_CONFIG")
    if env_path:
        candidates.insert(0, Path(env_path))

    for path in candidates:
        if path.is_file():
            return path
    return None


def _load_toml(path: Path) -> dict[str, Any]:
    """Load a TOML file. Uses tomllib (3.11+) or tomli fallback."""
    try:
        import tomllib
    except ImportError:
        try:
            import tomli as tomllib  # type: ignore[no-redef]
        except ImportError:
            logger.warning(
                "No TOML parser available (need Python 3.11+ or tomli). "
                "Using defaults."
            )
            return {}

    with open(path, "rb") as f:
        data = tomllib.load(f)

    # The config may be nested under [ventures] or at top level
    return data.get("ventures", data)


def load_config(config_path: str | Path | None = None) -> VenturesConfig:
    """Load ventures configuration.

    Priority:
    1. Explicit config_path argument
    2. PARSICA_VENTURES_CONFIG env var
    3. Standard file locations
    4. Defaults
    """
    if config_path:
        path = Path(config_path)
        if path.is_file():
            data = _load_toml(path)
            logger.info("Loaded config from %s", path)
            return VenturesConfig(**data)
        else:
            logger.warning("Config path %s not found, using defaults", path)
            return VenturesConfig()

    found = _find_config_file()
    if found:
        data = _load_toml(found)
        logger.info("Loaded config from %s", found)
        return VenturesConfig(**data)

    logger.debug("No config file found, using defaults")
    return VenturesConfig()
