"""Log sanitizer — strips known secret patterns before writing to disk.

Used by file_observer and log storage to prevent secrets from leaking
into venture log files.
"""

from __future__ import annotations

import re

# Compiled patterns matching common API key formats
_SANITIZE_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    # Anthropic keys
    (re.compile(r"sk-ant-api\d+-[a-zA-Z0-9_-]{20,}"), "[REDACTED:anthropic-api-key]"),
    (re.compile(r"sk-ant-oat\d+-[a-zA-Z0-9_-]{20,}"), "[REDACTED:anthropic-oauth]"),
    (re.compile(r"sk-ant-ort\d+-[a-zA-Z0-9_-]{20,}"), "[REDACTED:anthropic-refresh]"),
    # OpenAI keys
    (re.compile(r"sk-proj-[a-zA-Z0-9_-]{20,}"), "[REDACTED:openai-project-key]"),
    (re.compile(r"sk-svcacct-[a-zA-Z0-9_-]{20,}"), "[REDACTED:openai-service-key]"),
    (re.compile(r"sk-[a-zA-Z0-9]{48,}"), "[REDACTED:openai-key]"),
    # Google
    (re.compile(r"AIza[a-zA-Z0-9_-]{30,}"), "[REDACTED:google-api-key]"),
    # GitHub
    (re.compile(r"ghp_[a-zA-Z0-9]{30,}"), "[REDACTED:github-pat]"),
    (re.compile(r"gho_[a-zA-Z0-9]{30,}"), "[REDACTED:github-oauth]"),
    (re.compile(r"ghs_[a-zA-Z0-9]{30,}"), "[REDACTED:github-secret]"),
    # PyPI
    (re.compile(r"pypi-[a-zA-Z0-9_-]{30,}"), "[REDACTED:pypi-token]"),
    # Slack
    (re.compile(r"xoxb-[a-zA-Z0-9-]+"), "[REDACTED:slack-bot-token]"),
    (re.compile(r"xoxp-[a-zA-Z0-9-]+"), "[REDACTED:slack-user-token]"),
    # Discord bot tokens (rough pattern: base64.base64.base64)
    (re.compile(r"[MN][A-Za-z0-9]{23,}\.[A-Za-z0-9_-]{5,8}\.[A-Za-z0-9_-]{25,}"), "[REDACTED:discord-token]"),
    # Generic long hex/base64 strings that look like secrets (40+ chars)
    # This is intentionally conservative — only matches after other patterns
    (re.compile(r"(?:Bearer\s+)([a-zA-Z0-9_-]{60,})"), "[REDACTED:bearer-token]"),
]


def sanitize(text: str) -> str:
    """Replace known secret patterns in text with redaction markers.

    Returns the sanitized text. If no patterns match, returns the original
    string unchanged.
    """
    result = text
    for pattern, replacement in _SANITIZE_PATTERNS:
        result = pattern.sub(replacement, result)
    return result


def sanitize_dict(d: dict) -> dict:
    """Recursively sanitize all string values in a dict."""
    result = {}
    for key, value in d.items():
        if isinstance(value, str):
            result[key] = sanitize(value)
        elif isinstance(value, dict):
            result[key] = sanitize_dict(value)
        elif isinstance(value, list):
            result[key] = [
                sanitize_dict(item) if isinstance(item, dict)
                else sanitize(item) if isinstance(item, str)
                else item
                for item in value
            ]
        else:
            result[key] = value
    return result
