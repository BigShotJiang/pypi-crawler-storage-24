"""Parsica Memory integration bridge.

Provides the MemoryBridge protocol for venture↔memory interaction.
Uses lazy imports so parsica-memory is optional — graceful degradation
when not installed.

The bridge:
- Stores findings/decisions during venture execution
- Recalls venture-scoped memories on checkpoint resume
- Exports backup JSON alongside checkpoints (insurance)
- Tags all memories with ventures/<venture_id>/ prefix
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Protocol, runtime_checkable

logger = logging.getLogger(__name__)


def _get_parsica_memory():
    """Lazy import of parsica_memory. Returns module or None."""
    try:
        import parsica_memory
        return parsica_memory
    except ImportError:
        return None


@runtime_checkable
class MemoryBridge(Protocol):
    """Protocol for Parsica Memory integration.

    Implementations must handle the case where parsica-memory is not
    installed (available() returns False).
    """

    def available(self) -> bool:
        """Check if memory backend is available."""
        ...

    def store_finding(
        self,
        venture_id: str,
        content: str,
        memory_type: str,
        metadata: dict[str, Any] | None = None,
    ) -> str | None:
        """Store a finding/decision as a Parsica memory.

        Returns the memory ID, or None if storage failed.
        memory_type: finding, decision, dead_end, artifact, progress
        """
        ...

    def recall_for_venture(
        self,
        venture_id: str,
        query: str | None = None,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        """Recall memories tagged with this venture.

        If query is provided, semantic search within venture-scoped memories.
        Returns list of memory dicts.
        """
        ...

    def export_venture_memories(
        self,
        venture_id: str,
    ) -> list[dict[str, Any]]:
        """Export all memories for this venture as plain dicts.

        Used for checkpoint backup (memories_backup.json).
        """
        ...


class NoopMemoryBridge:
    """Fallback bridge when parsica-memory is not available.

    All operations succeed silently — ventures work without memory,
    just without cross-context recall.
    """

    def available(self) -> bool:
        return False

    def store_finding(
        self,
        venture_id: str,
        content: str,
        memory_type: str,
        metadata: dict[str, Any] | None = None,
    ) -> str | None:
        logger.debug("Memory bridge unavailable — finding not stored")
        return None

    def recall_for_venture(
        self,
        venture_id: str,
        query: str | None = None,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        return []

    def export_venture_memories(
        self,
        venture_id: str,
    ) -> list[dict[str, Any]]:
        return []


class ParsicaMemoryBridge:
    """Concrete bridge that uses parsica-memory for storage and recall.

    This is the real integration — stores memories with venture tags,
    recalls on resume, exports for checkpoint backup.
    """

    def __init__(self, store_path: str | None = None, tag_prefix: str = "ventures"):
        self._store_path = store_path
        self._tag_prefix = tag_prefix
        self._pm = _get_parsica_memory()
        self._store = None

        if self._pm and self._store_path:
            try:
                self._store = self._pm.MemoryStore(self._store_path)
                logger.info("Parsica Memory bridge connected at %s", store_path)
            except Exception:
                logger.warning("Failed to initialize Parsica Memory store", exc_info=True)
                self._store = None

    def available(self) -> bool:
        return self._store is not None

    def _venture_tag(self, venture_id: str) -> str:
        return f"{self._tag_prefix}/{venture_id}"

    def store_finding(
        self,
        venture_id: str,
        content: str,
        memory_type: str,
        metadata: dict[str, Any] | None = None,
    ) -> str | None:
        if not self.available():
            return None
        try:
            meta = metadata or {}
            meta["venture_id"] = venture_id
            meta["venture_memory_type"] = memory_type
            tags = [self._venture_tag(venture_id), f"type:{memory_type}"]

            # Use the store's add method — exact API depends on parsica-memory version
            memory_id = self._store.add(  # type: ignore[union-attr]
                content=content,
                tags=tags,
                metadata=meta,
            )
            return str(memory_id) if memory_id else None
        except Exception:
            logger.warning("Failed to store venture finding", exc_info=True)
            return None

    def recall_for_venture(
        self,
        venture_id: str,
        query: str | None = None,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        if not self.available():
            return []
        try:
            tag = self._venture_tag(venture_id)
            if query:
                results = self._store.search(  # type: ignore[union-attr]
                    query=query,
                    tags=[tag],
                    limit=limit,
                )
            else:
                results = self._store.search(  # type: ignore[union-attr]
                    query=venture_id,
                    tags=[tag],
                    limit=limit,
                )
            # Normalize to list of dicts
            return [
                r if isinstance(r, dict) else r.model_dump() if hasattr(r, "model_dump") else {"content": str(r)}
                for r in results
            ]
        except Exception:
            logger.warning("Failed to recall venture memories", exc_info=True)
            return []

    def export_venture_memories(
        self,
        venture_id: str,
    ) -> list[dict[str, Any]]:
        """Export all venture memories for checkpoint backup."""
        return self.recall_for_venture(venture_id, limit=1000)


def save_memories_backup(
    memories: list[dict[str, Any]],
    checkpoint_dir: Path,
) -> Path:
    """Write memories_backup.json alongside a checkpoint.

    This is insurance — if Parsica Memory is unavailable on resume,
    the backup can be loaded instead.
    """
    backup_path = checkpoint_dir / "memories_backup.json"
    backup_path.parent.mkdir(parents=True, exist_ok=True)
    with open(backup_path, "w") as f:
        json.dump(memories, f, indent=2, default=str)
    return backup_path


def load_memories_backup(checkpoint_dir: Path) -> list[dict[str, Any]]:
    """Load memories_backup.json from a checkpoint directory.

    Returns empty list if file doesn't exist.
    """
    backup_path = checkpoint_dir / "memories_backup.json"
    if not backup_path.exists():
        return []
    try:
        with open(backup_path) as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        logger.warning("Failed to load memories backup from %s", backup_path)
        return []


def create_memory_bridge(
    enabled: bool = True,
    store_path: str | None = None,
    tag_prefix: str = "ventures",
) -> MemoryBridge:
    """Factory — creates the appropriate memory bridge.

    Returns ParsicaMemoryBridge if parsica-memory is available and enabled,
    otherwise returns NoopMemoryBridge.
    """
    if not enabled:
        logger.info("Memory bridge disabled by config")
        return NoopMemoryBridge()

    pm = _get_parsica_memory()
    if pm is None:
        logger.info(
            "parsica-memory not installed — ventures will work without "
            "cross-context recall. Install parsica-memory for full functionality."
        )
        return NoopMemoryBridge()

    return ParsicaMemoryBridge(store_path=store_path, tag_prefix=tag_prefix)
