"""Secret resolver — ensures secrets never touch SQLite or checkpoint files.

All sensitive values in executor_config and observer_configs must use
$secret references: {"$secret": "ENV_VAR_NAME"}. The resolver substitutes
these at runtime from environment variables.
"""

from __future__ import annotations

import os
import re
import logging
from typing import Any

from parsica_ventures.exceptions import SecretResolutionError

logger = logging.getLogger(__name__)

# Patterns that look like API keys / secrets — warn if found in plain config
SECRET_PATTERNS = [
    re.compile(r"sk-[a-zA-Z0-9_-]{20,}"),          # OpenAI / Anthropic style
    re.compile(r"sk-ant-[a-zA-Z0-9_-]{20,}"),       # Anthropic specific
    re.compile(r"sk-proj-[a-zA-Z0-9_-]{20,}"),      # OpenAI project keys
    re.compile(r"sk-ant-api\d+-[a-zA-Z0-9_-]{20,}"),# Anthropic API keys
    re.compile(r"sk-ant-oat\d+-[a-zA-Z0-9_-]{20,}"),# Anthropic OAuth
    re.compile(r"AIza[a-zA-Z0-9_-]{30,}"),           # Google API keys
    re.compile(r"ghp_[a-zA-Z0-9]{30,}"),             # GitHub PAT
    re.compile(r"gho_[a-zA-Z0-9]{30,}"),             # GitHub OAuth
    re.compile(r"pypi-[a-zA-Z0-9_-]{30,}"),          # PyPI tokens
    re.compile(r"xoxb-[a-zA-Z0-9-]+"),               # Slack bot tokens
    re.compile(r"[A-Z][A-Za-z0-9]{20,}\.[A-Za-z0-9_-]{5,}\.[A-Za-z0-9_-]{20,}"),  # Discord bot tokens
]


def is_secret_ref(value: Any) -> bool:
    """Check if a value is a $secret reference."""
    return isinstance(value, dict) and "$secret" in value and len(value) == 1


def resolve_secret(ref: dict[str, str]) -> str:
    """Resolve a single $secret reference from environment.

    Raises SecretResolutionError if the env var is not set.
    """
    env_var = ref["$secret"]
    value = os.environ.get(env_var)
    if value is None:
        raise SecretResolutionError(f"Secret env var not found: {env_var}", env_var=env_var)
    return value


def resolve_secrets_in_dict(d: dict[str, Any]) -> dict[str, Any]:
    """Recursively resolve all $secret references in a dict.

    Returns a NEW dict with secrets resolved. Does not modify the original.
    """
    result = {}
    for key, value in d.items():
        if is_secret_ref(value):
            result[key] = resolve_secret(value)
        elif isinstance(value, dict):
            result[key] = resolve_secrets_in_dict(value)
        elif isinstance(value, list):
            result[key] = [
                resolve_secrets_in_dict(item) if isinstance(item, dict) else item
                for item in value
            ]
        else:
            result[key] = value
    return result


def check_for_plaintext_secrets(config: dict[str, Any], path: str = "") -> list[str]:
    """Scan a config dict for values that look like plaintext secrets.

    Returns a list of warning messages for any suspicious values found.
    Does NOT raise — this is advisory.
    """
    warnings: list[str] = []

    for key, value in config.items():
        current_path = f"{path}.{key}" if path else key

        if isinstance(value, str):
            for pattern in SECRET_PATTERNS:
                if pattern.search(value):
                    warnings.append(
                        f"Possible plaintext secret at '{current_path}' — "
                        f"use {{\"$secret\": \"ENV_VAR_NAME\"}} instead"
                    )
                    break  # one warning per field
        elif isinstance(value, dict):
            if not is_secret_ref(value):
                warnings.extend(check_for_plaintext_secrets(value, current_path))
        elif isinstance(value, list):
            for i, item in enumerate(value):
                if isinstance(item, dict):
                    warnings.extend(
                        check_for_plaintext_secrets(item, f"{current_path}[{i}]")
                    )

    return warnings


def strip_secrets_for_storage(d: dict[str, Any]) -> dict[str, Any]:
    """Return a copy of the dict with $secret refs preserved but no resolved values.

    This is what gets written to SQLite / checkpoint files. $secret refs
    stay as-is (they're just env var names, not the actual secrets).
    Non-secret values pass through unchanged.
    """
    # This is actually a no-op if the dict only contains $secret refs
    # and non-secret values. But it serves as a validation point —
    # we warn if we see anything that looks like a resolved secret.
    warnings = check_for_plaintext_secrets(d)
    for warning in warnings:
        logger.warning(warning)
    return d  # safe to store — $secret refs are env var names
