"""Core data models for Parsica Ventures.

Naming distinction — CheckpointData vs Checkpoint (Delta Condition #3):
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  CheckpointData  ←  produced BY the executor
    • Raw output from executor.checkpoint() or reported via on_checkpoint_needed()
    • Has NO id, NO venture_id, NO timestamp — those are added by the engine
    • Think: "what the agent knows about its own state right now"
    • Lives only in memory until the engine wraps it

  Checkpoint  ←  created BY the engine, stored to disk + DB
    • Wraps CheckpointData and adds engine metadata (id, venture_id, timestamp, reason)
    • Written atomically to disk (temp → fsync → rename) for crash safety
    • The entity that resume() receives — it is the authoritative saved state
    • Think: "the sealed, timestamped, persisted record of a save point"

  Data flow:
    executor.checkpoint()  →  CheckpointData
    engine._process_checkpoint(data)  →  Checkpoint  →  disk + SQLite

  Rule of thumb:
    - If you're IN an executor: produce CheckpointData
    - If you're IN the engine or CLI: work with Checkpoint
    - If you see both in the same function: you're in engine._process_checkpoint()
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Literal

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------

class VentureState(str, Enum):
    """All possible venture lifecycle states."""
    CREATED = "created"
    QUEUED = "queued"
    RUNNING = "running"
    CHECKPOINT = "checkpoint"
    CHECKPOINT_FAILED = "checkpoint_failed"
    AWAITING_APPROVAL = "awaiting_approval"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    ABORTED = "aborted"


class FailureCategory(str, Enum):
    """Categorizes failures for retry policy decisions.

    - TRANSIENT: network timeout, rate limit → auto-retry 3x with backoff
    - CRASH: executor process died → resume from checkpoint once, fail on second
    - LOGIC: agent declared it can't proceed → fail to user immediately (not retryable)
    - POLICY: cost/duration/context limit hit → fail to user with reason (not retryable)
    - CHECKPOINT: checkpoint write failed → retry up to 3x, then fail
    """
    TRANSIENT = "transient"
    CRASH = "crash"
    LOGIC = "logic"
    POLICY = "policy"
    CHECKPOINT = "checkpoint"


class DeliverableType(str, Enum):
    FILE = "file"
    PR = "pr"
    REPORT = "report"
    MESSAGE = "message"
    ARTIFACT = "artifact"


class CheckpointReason(str, Enum):
    CONTEXT_LIMIT = "context_limit"
    SCHEDULED = "scheduled"
    MANUAL = "manual"
    POLICY_LIMIT = "policy_limit"
    COST_LIMIT = "cost_limit"


# ---------------------------------------------------------------------------
# Sub-models
# ---------------------------------------------------------------------------

class ResourceLimits(BaseModel):
    """Resource constraints for a venture."""
    max_memory_mb: int | None = None
    max_disk_mb: int | None = None

    model_config = {"extra": "allow"}


class NextStep(BaseModel):
    """Structured next step for checkpoint resume — not free text."""
    id: str = Field(default_factory=lambda: f"ns_{uuid.uuid4().hex[:8]}")
    description: str
    type: Literal[
        "read_file", "run_command", "call_api",
        "decision", "investigate", "create_artifact",
    ]
    context: dict[str, Any] = Field(default_factory=dict)
    priority: int = 5
    depends_on: list[str] = Field(default_factory=list)


class FileSnapshot(BaseModel):
    """File state at checkpoint time for integrity verification."""
    path: str
    checksum: str  # sha256
    size: int
    git_committed: bool = False
    inline_content: str | None = None  # small files only (< 10KB)


class Decision(BaseModel):
    """A key decision made during venture execution."""
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    description: str
    reasoning: str
    alternatives_considered: list[str] = Field(default_factory=list)
    outcome: str


class Deliverable(BaseModel):
    """A venture output artifact."""
    type: DeliverableType
    title: str
    path: str | None = None
    url: str | None = None
    content: str | None = None


class ProgressUpdate(BaseModel):
    """Incremental progress report from executor."""
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    step: int | None = None
    message: str
    metadata: dict[str, Any] = Field(default_factory=dict)


class StateTransition(BaseModel):
    """Audit log entry for a state change."""
    from_state: VentureState
    to_state: VentureState
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    reason: str
    triggered_by: Literal["engine", "executor", "user", "policy"]


class VentureMetrics(BaseModel):
    """Accumulated metrics for a completed (or in-progress) venture."""
    duration_seconds: float = 0.0
    total_tokens: int = 0
    total_cost_usd: float = 0.0
    checkpoint_count: int = 0
    context_resets: int = 0
    executor_sessions: int = 0


class VentureError(BaseModel):
    """Structured error with failure category for retry decisions."""
    category: FailureCategory
    message: str
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    recoverable: bool = False
    retry_count: int = 0


class VentureResult(BaseModel):
    """Final result of a completed venture."""
    summary: str
    deliverables: list[Deliverable] = Field(default_factory=list)
    metrics: VentureMetrics = Field(default_factory=VentureMetrics)
    memory_ids: list[str] = Field(default_factory=list)
    recommendations: list[str] = Field(default_factory=list)


class VentureNotification(BaseModel):
    """Configuration for venture lifecycle notifications."""
    channel_type: Literal["discord", "dm", "webhook"] = "discord"
    channel_id: str
    notify_on: list[str] = Field(
        default_factory=lambda: ["checkpoint", "approval", "completed", "failed"]
    )


class ApprovalRequest(BaseModel):
    """A pending or resolved approval gate request."""
    id: str = Field(default_factory=lambda: f"ar_{uuid.uuid4().hex[:8]}")
    venture_id: str
    gate: str
    context: dict[str, Any] = Field(default_factory=dict)
    requested_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    resolved_at: datetime | None = None
    resolution: Literal["pending", "approved", "denied", "timeout"] = "pending"
    resolved_by: str | None = None


class ExecutorHandle(BaseModel):
    """Reference returned by executor.start() to confirm launch."""
    executor_id: str
    pid: int | None = None
    session_id: str | None = None
    started_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class ExecutorHealth(BaseModel):
    """Health check result from executor.health()."""
    alive: bool
    last_activity: datetime
    current_task: str | None = None
    estimated_completion: datetime | None = None
    tokens_used: int = 0
    cost_usd: float = 0.0
    error: str | None = None


# ---------------------------------------------------------------------------
# Checkpoint models (Delta Condition #3 — two distinct types, see module docstring)
# ---------------------------------------------------------------------------

class CheckpointData(BaseModel):
    """Raw checkpoint payload produced BY the executor.

    This is the executor's view of "what I know right now." It contains
    only the information the executor can observe: its own progress,
    the next steps it planned, files it touched, and decisions it made.

    IMPORTANT: CheckpointData has NO identity fields (no id, no venture_id,
    no timestamp). Those are added by the engine when it creates the
    authoritative Checkpoint record. Do not add id/venture_id here —
    that would blur the boundary between executor output and engine record.

    Produced by:
      - executor.checkpoint()             (engine-triggered: manual or threshold)
      - callback.on_checkpoint_needed()   (executor-triggered: context limit, agent request)

    Consumed by:
      - engine._process_checkpoint(data, reason) → creates Checkpoint
    """
    progress_summary: str
    next_steps: list[NextStep] = Field(default_factory=list)
    files_modified: list[FileSnapshot] = Field(default_factory=list)
    decisions_log: list[Decision] = Field(default_factory=list)
    executor_state: dict[str, Any] = Field(default_factory=dict)


class Checkpoint(BaseModel):
    """Persisted checkpoint record — created BY the engine from CheckpointData.

    This is the authoritative save point. The engine adds identity (id,
    venture_id), provenance (reason, timestamp), and cross-system refs
    (memory_ids for Parsica Memory backup). Written atomically to disk
    (temp → fsync → rename) for crash safety.

    IMPORTANT: Checkpoint is NEVER created directly by executors. Only the
    engine calls checkpoint.py:create_checkpoint(venture_id, data, reason).
    Executors receive Checkpoint as input to resume() — they read it but
    do not write it.

    Created by:
      - engine._process_checkpoint(data, reason) → checkpoint.create_checkpoint()
      - checkpoint.py:create_checkpoint(venture_id, data, reason)

    Read by:
      - executor.resume(venture, checkpoint, callback)
      - CLI: ventures status, ventures logs
      - Parsica Memory bridge (memory_ids cross-reference)

    Stored in:
      - SQLite: ventures.db via store.save_checkpoint()
      - Disk: {store_path}/checkpoints/{venture_id}/{checkpoint_id}.json (atomic write)

    All datetime fields serialize as ISO 8601 strings in JSON.
    """
    id: str = Field(default_factory=lambda: f"cp_{uuid.uuid4().hex[:12]}")
    venture_id: str
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    reason: CheckpointReason
    progress_summary: str
    next_steps: list[NextStep] = Field(default_factory=list)
    memory_ids: list[str] = Field(default_factory=list)
    files_modified: list[FileSnapshot] = Field(default_factory=list)
    decisions_log: list[Decision] = Field(default_factory=list)
    executor_state: dict[str, Any] = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# Policy
# ---------------------------------------------------------------------------

class VenturePolicy(BaseModel):
    """Controls what the executor can and cannot do.

    scope_boundaries are ADVISORY ONLY in Phase 1 — passed to the executor
    as context but not mechanically enforced. Enforcement via tool
    interception or sandboxing is Phase 4+.
    """
    autonomy: Literal["full", "checkpoints", "supervised"] = "checkpoints"

    approval_gates: list[str] = Field(default_factory=list)
    gate_timeout_seconds: int = 300
    gate_timeout_action: Literal["auto_pause", "auto_abort", "auto_approve"] = "auto_pause"

    scope_boundaries: list[str] = Field(default_factory=list)

    resource_limits: ResourceLimits = Field(default_factory=ResourceLimits)
    max_duration_hours: float | None = None
    max_cost_usd: float | None = None
    max_context_resets: int | None = None

    checkpoint_strategy: Literal["token", "time", "manual"] = "token"
    checkpoint_threshold: float = 0.80
    checkpoint_interval_minutes: float | None = None

    priority: int = 5  # 1=highest, 10=lowest; FIFO within same priority


# ---------------------------------------------------------------------------
# Venture (top-level)
# ---------------------------------------------------------------------------

class Venture(BaseModel):
    """The top-level venture record.

    Stored in SQLite. executor_config must use $secret refs for
    any sensitive values — secrets are NEVER persisted to DB or disk.
    """
    id: str = Field(default_factory=lambda: f"v_{uuid.uuid4().hex[:12]}")
    title: str
    goal: str
    exit_condition: str
    executor_type: str  # validated against ExecutorRegistry at creation
    executor_config: dict[str, Any] = Field(default_factory=dict)
    policy: VenturePolicy = Field(default_factory=VenturePolicy)
    observer_configs: list[dict[str, Any]] = Field(default_factory=list)
    state: VentureState = VentureState.CREATED
    state_history: list[StateTransition] = Field(default_factory=list)
    checkpoints: list[Checkpoint] = Field(default_factory=list)
    progress: list[ProgressUpdate] = Field(default_factory=list)
    result: VentureResult | None = None
    error: VentureError | None = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    started_at: datetime | None = None
    completed_at: datetime | None = None
    total_cost_usd: float = 0.0
    total_tokens: int = 0
    notification: VentureNotification | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)
