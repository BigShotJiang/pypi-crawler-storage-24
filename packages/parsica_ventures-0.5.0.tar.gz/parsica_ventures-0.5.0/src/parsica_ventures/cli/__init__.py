"""Parsica Ventures CLI."""
