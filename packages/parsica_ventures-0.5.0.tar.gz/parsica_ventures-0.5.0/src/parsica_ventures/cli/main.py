"""Parsica Ventures CLI.

Commands:
  ventures create   — create a new venture
  ventures start    — start a queued venture
  ventures status   — detailed status of a venture
  ventures list     — list ventures with optional status filter
  ventures logs     — show execution log
  ventures pause    — pause a running venture
  ventures resume   — resume a paused venture
  ventures abort    — cancel a venture
  ventures result   — show deliverables
  ventures approve  — approve a pending gate
  ventures checkpoint — manually trigger checkpoint
  ventures retry    — retry a failed venture (only recoverable failures)

Aliases: `venture` works as a singular alias for all commands.
"""

from __future__ import annotations

import asyncio
import json
import sys

import click

from parsica_ventures.config import load_config
from parsica_ventures.engine import VentureEngine
from parsica_ventures.models import VenturePolicy, VentureState
from parsica_ventures.observers.stdout_observer import StdoutObserver
from parsica_ventures.observers.file_observer import FileObserver, read_log


def _run(coro):
    """Run an async coroutine from sync CLI context."""
    return asyncio.run(coro)


def _get_engine() -> VentureEngine:
    """Create and return a VentureEngine with default config."""
    config = load_config()
    engine = VentureEngine(config=config)
    engine.observer.add(StdoutObserver())
    engine.observer.add(FileObserver(log_dir=f"{config.store_path}/logs"))
    return engine


def _format_state(state: VentureState) -> str:
    """Color-code venture states for terminal output."""
    colors = {
        VentureState.CREATED: "white",
        VentureState.QUEUED: "yellow",
        VentureState.RUNNING: "cyan",
        VentureState.CHECKPOINT: "blue",
        VentureState.CHECKPOINT_FAILED: "red",
        VentureState.AWAITING_APPROVAL: "yellow",
        VentureState.PAUSED: "yellow",
        VentureState.COMPLETED: "green",
        VentureState.FAILED: "red",
        VentureState.ABORTED: "magenta",
    }
    return click.style(state.value.upper(), fg=colors.get(state, "white"))


@click.group()
@click.version_option(package_name="parsica-ventures")
def cli():
    """Parsica Ventures — long-running autonomous agent tasks."""
    pass


@cli.command()
@click.argument("goal")
@click.option("--title", "-t", default=None, help="Venture title (defaults to goal)")
@click.option("--executor", "-e", default=None, help="Executor type")
@click.option("--exit-condition", "-x", default="Task completed", help="Exit condition")
@click.option("--policy", "-p", default="checkpoints", help="Policy: full, checkpoints, supervised")
@click.option("--max-duration", default=None, type=float, help="Max duration in hours")
@click.option("--max-cost", default=None, type=float, help="Max cost in USD")
@click.option("--priority", default=5, type=int, help="Priority (1=highest, 10=lowest)")
@click.option("--command", "-c", default=None, help="Command for subprocess executor")
@click.option("--start/--no-start", default=True, help="Start immediately after creation")
def create(goal, title, executor, exit_condition, policy, max_duration, max_cost, priority, command, start):
    """Create a new venture."""
    engine = _get_engine()

    venture_policy = VenturePolicy(
        autonomy=policy,
        max_duration_hours=max_duration,
        max_cost_usd=max_cost,
        priority=priority,
    )

    executor_config = {}
    if command:
        executor_config["command"] = command

    venture = engine.create_venture(
        title=title or goal[:80],
        goal=goal,
        exit_condition=exit_condition,
        executor_type=executor,
        executor_config=executor_config,
        policy=venture_policy,
    )

    click.echo(f"Created venture {click.style(venture.id, bold=True)}: {venture.title}")

    if start:
        try:
            handle = _run(engine.start_venture(venture.id))
            if handle:
                click.echo(f"Started — executor: {handle.executor_id}")
            else:
                click.echo("Queued — waiting for an executor slot")
        except Exception as e:
            click.echo(f"Created but not started: {e}", err=True)


@cli.command("start")
@click.argument("venture_id")
def start_cmd(venture_id):
    """Start a queued venture."""
    engine = _get_engine()
    try:
        handle = _run(engine.start_venture(venture_id))
        if handle:
            click.echo(f"Started venture {venture_id} — executor: {handle.executor_id}")
        else:
            click.echo(f"Venture {venture_id} queued — waiting for an executor slot")
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@cli.command()
@click.argument("venture_id")
def status(venture_id):
    """Show detailed status of a venture."""
    engine = _get_engine()
    try:
        v = engine.get_venture(venture_id)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)

    click.echo(f"Venture: {click.style(v.title, bold=True)}")
    click.echo(f"ID:      {v.id}")
    click.echo(f"State:   {_format_state(v.state)}")
    click.echo(f"Goal:    {v.goal[:200]}")
    click.echo(f"Exit:    {v.exit_condition}")
    click.echo(f"Executor: {v.executor_type}")
    click.echo(f"Created: {v.created_at.strftime('%Y-%m-%d %H:%M:%S UTC')}")
    if v.started_at:
        click.echo(f"Started: {v.started_at.strftime('%Y-%m-%d %H:%M:%S UTC')}")
    if v.completed_at:
        click.echo(f"Completed: {v.completed_at.strftime('%Y-%m-%d %H:%M:%S UTC')}")
    click.echo(f"Cost:    ${v.total_cost_usd:.4f} ({v.total_tokens} tokens)")
    click.echo(f"Checkpoints: {len(v.checkpoints)}")
    click.echo(f"Progress updates: {len(v.progress)}")

    if v.error:
        click.echo(f"\nError ({v.error.category.value}): {v.error.message}")
        if v.error.recoverable:
            click.echo(f"  ↩️  Recoverable — use `ventures retry {v.id}`")

    if v.result:
        click.echo(f"\nResult: {v.result.summary}")
        for d in v.result.deliverables:
            click.echo(f"  📦 [{d.type.value}] {d.title}")


@cli.command("list")
@click.option("--status", "-s", default=None, help="Filter by state (comma-separated)")
@click.option("--limit", "-n", default=20, help="Max results")
def list_cmd(status, limit):
    """List ventures with optional status filter."""
    engine = _get_engine()

    states = None
    if status:
        try:
            states = [VentureState(s.strip()) for s in status.split(",")]
        except ValueError as e:
            click.echo(f"Invalid state: {e}", err=True)
            valid = ", ".join(s.value for s in VentureState)
            click.echo(f"Valid states: {valid}", err=True)
            sys.exit(1)

    ventures = engine.list_ventures(states=states, limit=limit)
    if not ventures:
        click.echo("No ventures found.")
        return

    for v in ventures:
        age = ""
        if v.created_at:
            age = v.created_at.strftime("%m/%d %H:%M")
        click.echo(
            f"  {_format_state(v.state):>20s}  {v.id}  {age}  {v.title[:50]}"
        )
    click.echo(f"\n{len(ventures)} venture(s)")


@cli.command()
@click.argument("venture_id")
@click.option("--follow", "-f", is_flag=True, help="Follow log output (not yet implemented)")
@click.option("--limit", "-n", default=50, help="Number of log entries")
def logs(venture_id, follow, limit):
    """Show execution log for a venture."""
    engine = _get_engine()
    config = load_config()

    events = read_log(venture_id, log_dir=f"{config.store_path}/logs", limit=limit)
    if not events:
        click.echo(f"No log entries for venture {venture_id}")
        return

    for event in events:
        ts = event.get("timestamp", "")[:19]
        etype = event.get("type", "unknown")
        msg = ""
        if etype == "progress":
            msg = event.get("message", "")
        elif etype == "checkpoint":
            msg = f"reason={event.get('reason', '')} — {event.get('summary', '')[:60]}"
        elif etype == "completed":
            msg = event.get("summary", "")[:80]
        elif etype == "failed":
            msg = f"[{event.get('category', '')}] {event.get('message', '')[:60]}"
        elif etype == "started":
            msg = f"executor={event.get('executor_type', '')}"
        elif etype == "aborted":
            msg = "aborted"
        else:
            msg = json.dumps(event, default=str)[:80]

        click.echo(f"  {ts}  {etype:>18s}  {msg}")


@cli.command()
@click.argument("venture_id")
def pause(venture_id):
    """Pause a running venture."""
    engine = _get_engine()
    try:
        _run(engine.pause_venture(venture_id))
        click.echo(f"Paused venture {venture_id}")
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@cli.command()
@click.argument("venture_id")
def resume(venture_id):
    """Resume a paused venture."""
    engine = _get_engine()
    try:
        handle = _run(engine.resume_venture(venture_id))
        if handle:
            click.echo(f"Resumed venture {venture_id} — executor: {handle.executor_id}")
        else:
            click.echo(f"Venture {venture_id} queued — waiting for an executor slot")
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@cli.command()
@click.argument("venture_id")
def abort(venture_id):
    """Abort a venture."""
    engine = _get_engine()
    try:
        _run(engine.abort_venture(venture_id))
        click.echo(f"Aborted venture {venture_id}")
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@cli.command()
@click.argument("venture_id")
def result(venture_id):
    """Show venture result and deliverables."""
    engine = _get_engine()
    try:
        v = engine.get_venture(venture_id)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)

    if not v.result:
        click.echo(f"Venture {venture_id} has no result yet (state: {v.state.value})")
        return

    click.echo(f"Result for {click.style(v.title, bold=True)}:")
    click.echo(f"  {v.result.summary}")
    if v.result.deliverables:
        click.echo("\nDeliverables:")
        for d in v.result.deliverables:
            click.echo(f"  📦 [{d.type.value}] {d.title}")
            if d.path:
                click.echo(f"     Path: {d.path}")
            if d.url:
                click.echo(f"     URL: {d.url}")
    if v.result.recommendations:
        click.echo("\nRecommendations:")
        for r in v.result.recommendations:
            click.echo(f"  → {r}")


@cli.command("checkpoint")
@click.argument("venture_id")
def checkpoint_cmd(venture_id):
    """Manually trigger a checkpoint on a running venture."""
    engine = _get_engine()
    try:
        cp = _run(engine.checkpoint_venture(venture_id))
        click.echo(f"Checkpoint saved: {cp.id}")
        click.echo(f"  Summary: {cp.progress_summary[:100]}")
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@cli.command()
@click.argument("venture_id")
def retry(venture_id):
    """Retry a failed venture from its last checkpoint.

    \b
    ELIGIBILITY RULES (enforced by the engine):
      - Venture must be in FAILED state
      - venture.error.recoverable must be True
      - LOGIC failures (FailureCategory.LOGIC) are NOT retryable —
        these mean the agent explicitly declared it cannot proceed
        (e.g., "I cannot complete this task: missing required permissions").
        Retrying would produce the same LOGIC failure again.

    \b
    RETRYABLE FAILURE CATEGORIES:
      - TRANSIENT  → network timeout, rate limit (auto-retried 3x first)
      - CRASH      → executor process died; resumes from last checkpoint
      - CHECKPOINT → checkpoint write failed; retries the checkpoint

    \b
    NON-RETRYABLE FAILURE CATEGORIES:
      - LOGIC  → agent said it can't proceed (user must intervene)
      - POLICY → cost/duration/context-reset limit exceeded (must reconfigure)

    \b
    STATE TRANSITION:
      FAILED (recoverable=True) → QUEUED → RUNNING (when slot available)

    \b
    ENGINE ENFORCEMENT (engine.py retry_venture):
      The engine checks both conditions before transitioning:
        if venture.state != VentureState.FAILED → raises ExecutorError
        if venture.error.recoverable is False   → raises ExecutorError
      So the CLI error message you see is authoritative — there is no
      way to force a retry of a non-recoverable failure via the CLI.

    \b
    EXAMPLES:
      ventures retry v_abc123          # retry after transient failure
      ventures status v_abc123         # check if recoverable=True first
    """
    engine = _get_engine()
    try:
        handle = _run(engine.retry_venture(venture_id))
        if handle:
            click.echo(f"Retrying venture {venture_id} — executor: {handle.executor_id}")
        else:
            click.echo(f"Venture {venture_id} queued for retry — waiting for an executor slot")
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@cli.command()
@click.argument("venture_id")
@click.option("--approval-id", "-a", default=None, help="Specific approval request ID (optional)")
def approve(venture_id, approval_id):
    """Approve a pending approval gate.

    If --approval-id is given, resolves that specific request.
    Otherwise, approves the oldest pending request for the venture.
    """
    engine = _get_engine()
    try:
        if not approval_id:
            pending = engine.store.get_pending_approvals(venture_id)
            if not pending:
                click.echo(f"No pending approvals for venture {venture_id}")
                return
            approval_id = pending[0].id

        ar = _run(engine.resolve_approval(approval_id, "approved", "cli"))

        if ar:
            click.echo(f"Approved: {ar.id} (gate={ar.gate}) for venture {venture_id}")
        else:
            click.echo(f"Approval request not found or already resolved", err=True)
            sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


@cli.command()
@click.argument("venture_id")
@click.option("--approval-id", "-a", default=None, help="Specific approval request ID (optional)")
@click.option("--abort", "do_abort", is_flag=True, help="Abort the venture instead of pausing")
def deny(venture_id, approval_id, do_abort):
    """Deny a pending approval gate.

    By default, denied ventures are paused. Use --abort to abort instead.
    """
    engine = _get_engine()
    try:
        if not approval_id:
            pending = engine.store.get_pending_approvals(venture_id)
            if not pending:
                click.echo(f"No pending approvals for venture {venture_id}")
                return
            approval_id = pending[0].id

        ar = _run(engine.resolve_approval(approval_id, "denied", "cli"))
        if ar:
            if do_abort:
                _run(engine.abort_venture(venture_id))
            action = "aborted" if do_abort else "paused"
            click.echo(f"Denied: {ar.id} (gate={ar.gate}) → venture {action}")
        else:
            click.echo(f"Approval request not found or already resolved", err=True)
            sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)


if __name__ == "__main__":
    cli()
