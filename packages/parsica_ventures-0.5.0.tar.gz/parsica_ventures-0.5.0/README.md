# Parsica Ventures

![Version](https://img.shields.io/badge/version-v0.5.0-4A90D9)

> **Current version: v0.5.0**
>
> Parsica Ventures is a lightweight orchestration engine for long-running agent tasks.
> It gives you checkpointing, retry logic, policy enforcement, and memory-aware recovery.

## What it does

A **venture** is a long-running task with lifecycle management around it.

Instead of treating agent work as a single fragile run, Parsica Ventures wraps that work in a durable orchestration layer:

- start, pause, resume, abort
- checkpoint before context or policy limits become fatal
- recover from crashes without losing all progress
- enforce scope, duration, and cost policies
- route updates and approval requests to human operators
- integrate with memory so resumed work keeps context

In practice, that means you can give an agent a bigger job and still keep it observable, recoverable, and governed.

## Quick Start (OpenClaw)

1. Install Parsica Ventures:

```bash
pip install parsica-ventures
```

2. Enable the OpenClaw plugin by placing `openclaw-plugin/` where your gateway loads plugins.

3. Add a plugin block to `openclaw.json`:

```json
{
  "plugins": {
    "parsica-ventures": {
      "enabled": true,
      "storePath": "./parsica_ventures_store",
      "maxConcurrent": 3,
      "defaultExecutor": "subprocess",
      "memoryEnabled": false,
      "memoryStorePath": "./parsica_memory_store",
      "notifyChannel": "YOUR_CHANNEL_ID",
      "pythonPath": "python3"
    }
  }
}
```

4. Restart the OpenClaw gateway.

Once the gateway is back up, the plugin starts a persistent Python bridge, exposes venture operations to the agent context, and forwards venture notifications to the configured channel.

## Setup Flow

1. **Define Venture**
   - title
   - goal
   - exit condition
   - executor type
   - optional scope boundaries

2. **Choose Approval Mode**
   - full autonomy
   - checkpoints with gates
   - supervised

3. **Choose Notification Channel**
   - Discord channel
   - DM
   - webhook destination
   - any channel your OpenClaw environment routes notifications to

## Approval Modes

### Full autonomy

The venture runs without approval gates.

Use this when the task is low-risk and you want throughput. Notifications still fire for progress, checkpoint, completion, and failure events.

### Checkpoints with gates

The venture runs autonomously until it reaches a configured approval boundary.

Examples:

- deploy
- git push
- publish
- send external message

At a gate, the venture pauses and asks for approval in the notification channel.

### Supervised

The strictest mode. The venture pauses for every major decision or sensitive transition.

Use this when you want a human in the loop the whole time.

### Conversational approval

Approval is designed to work in normal language, but the plugin is intentionally conservative.

**Safest path:** reply directly to the approval message.

When you reply directly, the plugin accepts explicit approvals such as:

- yes
- go ahead
- approved
- do it
- ship it
- proceed
- confirm

And denials such as:

- no
- deny
- hold off
- wait
- stop
- reject
- cancel
- nope
- don't

If you are **not** replying directly to the approval message, the plugin requires stronger wording and may ask for a confirmation step before it resolves anything. Casual replies like `ok` or `go` are intentionally ignored in shared channels.

If the reply is ambiguous, the plugin asks again instead of guessing.

## Notification

All modes send updates.

That matters because **full autonomy is never silent**. Even when no approval gates are enabled, ventures still report:

- checkpoint updates
- progress events
- completion
- failure

Approval adds blocking behavior on top of notification. It does not replace notification.

## Configuration

OpenClaw plugin config:

- `storePath` — path for venture DB and checkpoints. Default: `./parsica_ventures_store`
- `maxConcurrent` — maximum concurrent ventures. Default: `3`
- `defaultExecutor` — default runtime. Default: `subprocess`
- `memoryEnabled` — enable Parsica Memory wiring when available. Default: `false`
- `memoryStorePath` — path to Parsica Memory store
- `notifyChannel` — default channel for venture updates and approval prompts
- `pythonPath` — Python executable for the venture bridge. Default: `process.env.PARSICA_PYTHON || 'python3'`

Standalone Python config uses `ventures.toml`:

```toml
[ventures]
store_path = "~/.parsica/ventures"
max_concurrent = 3
default_executor = "subprocess"
health_poll_interval_seconds = 30

[ventures.memory]
enabled = true
store_path = "~/.parsica/memory"
tag_prefix = "ventures"
```

## Standalone Usage

If you are not using OpenClaw, Parsica Ventures still works as a Python package and CLI.

Install:

```bash
pip install parsica-ventures
```

Python example:

```python
import asyncio
from parsica_ventures import VentureEngine, VenturePolicy

async def main():
    engine = VentureEngine()
    venture = engine.create_venture(
        title="Count Python files",
        goal="Count all .py files in the current directory recursively",
        exit_condition="File count reported",
        executor_type="subprocess",
        executor_config={"command": "find . -name '*.py' | wc -l"},
        policy=VenturePolicy(max_duration_hours=0.1),
    )
    await engine.start_venture(venture.id)

asyncio.run(main())
```

## CLI Reference

- `ventures create <goal>`
- `ventures start <id>`
- `ventures status <id>`
- `ventures list`
- `ventures pause <id>`
- `ventures resume <id>`
- `ventures abort <id>`
- `ventures checkpoint <id>`
- `ventures retry <id>`
- `ventures approve <id>` — approve a pending approval gate (CLI fallback; conversational approval is primary)
- `ventures deny <id> [--abort]` — deny a pending approval gate (optionally abort the venture)
- `ventures logs <id>`

Typical examples:

```bash
ventures create "Audit the repository and summarize release blockers" \
  --executor subprocess \
  --command "python audit.py" \
  --exit-condition "Audit summary written"

ventures status v_abc123
ventures checkpoint v_abc123
ventures resume v_abc123
ventures logs v_abc123
```

## Architecture

Parsica Ventures is built from a few core pieces:

- **engine** — orchestrates venture lifecycle and callback handling
- **executors** — runtime adapters such as subprocess, OpenClaw, and future integrations
- **state machine** — validates legal venture transitions
- **store** — persists ventures and checkpoints
- **memory bridge** — exports and restores memory-aware context when enabled

For OpenClaw specifically:

- the JavaScript plugin owns lifecycle integration with the gateway
- a persistent Python bridge handles engine commands and event flow
- the OpenClaw executor models venture work as sub-agent sessions

## Python Version

Python `>=3.10`

## License

MIT — see `LICENSE`.
