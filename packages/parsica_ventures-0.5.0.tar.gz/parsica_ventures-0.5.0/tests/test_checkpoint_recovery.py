"""Tests for checkpoint recovery — interrupted writes, corrupt state, missing files."""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from parsica_ventures.models import Checkpoint, CheckpointData, CheckpointReason
from parsica_ventures.checkpoint import (
    save_checkpoint_atomic,
    load_checkpoint,
    create_checkpoint,
    verify_file_integrity,
    snapshot_file,
)
from parsica_ventures.exceptions import CheckpointCorruptedError, CheckpointError


# ---------------------------------------------------------------------------
# Interrupted writes
# ---------------------------------------------------------------------------


class TestInterruptedWrites:
    def test_atomic_write_no_partial_file_on_exception(self, tmp_path):
        """If write fails mid-way, no final file is left behind."""
        cp = Checkpoint(
            venture_id="v_interrupt",
            reason=CheckpointReason.MANUAL,
            progress_summary="will fail",
        )

        # Patch os.rename to simulate a failure after temp file is written
        original_rename = os.rename
        rename_calls = []

        def failing_rename(src, dst):
            rename_calls.append((src, dst))
            raise OSError("Simulated rename failure")

        with patch("parsica_ventures.checkpoint.os.replace", side_effect=failing_rename):
            with pytest.raises(CheckpointError):
                save_checkpoint_atomic(cp, tmp_path)

        # The final checkpoint file should NOT exist
        venture_dir = tmp_path / "v_interrupt"
        final_files = list(venture_dir.glob("checkpoint_*.json"))
        assert final_files == [], "Partial checkpoint file left behind after failed write"

    def test_temp_file_cleaned_up_on_failure(self, tmp_path):
        """Temp files are cleaned up when write fails."""
        cp = Checkpoint(
            venture_id="v_cleanup",
            reason=CheckpointReason.MANUAL,
            progress_summary="cleanup test",
        )

        with patch("parsica_ventures.checkpoint.os.replace", side_effect=OSError("fail")):
            with pytest.raises(CheckpointError):
                save_checkpoint_atomic(cp, tmp_path)

        venture_dir = tmp_path / "v_cleanup"
        if venture_dir.exists():
            temp_files = list(venture_dir.glob(".checkpoint_tmp_*"))
            assert temp_files == [], "Temp files not cleaned up"

    def test_successful_write_produces_clean_file(self, tmp_path):
        """After successful write, temp file gone and final file exists."""
        cp = Checkpoint(
            venture_id="v_success",
            reason=CheckpointReason.MANUAL,
            progress_summary="success",
        )
        path = save_checkpoint_atomic(cp, tmp_path)
        assert path.exists()
        venture_dir = tmp_path / "v_success"
        temp_files = list(venture_dir.glob(".checkpoint_tmp_*"))
        assert temp_files == []


# ---------------------------------------------------------------------------
# Corrupt state
# ---------------------------------------------------------------------------


class TestCorruptCheckpointFiles:
    def test_empty_file_raises(self, tmp_path):
        bad = tmp_path / "empty.json"
        bad.write_text("")
        with pytest.raises(CheckpointCorruptedError):
            load_checkpoint(bad)

    def test_truncated_json_raises(self, tmp_path):
        bad = tmp_path / "truncated.json"
        bad.write_text('{"venture_id": "v_x", "reason": "manual"')  # no closing brace
        with pytest.raises(CheckpointCorruptedError):
            load_checkpoint(bad)

    def test_invalid_json_raises(self, tmp_path):
        bad = tmp_path / "invalid.json"
        bad.write_text("not json at all @@##!!")
        with pytest.raises(CheckpointCorruptedError):
            load_checkpoint(bad)

    def test_valid_json_wrong_schema_raises(self, tmp_path):
        bad = tmp_path / "wrong_schema.json"
        bad.write_text(json.dumps({"foo": "bar", "baz": 123}))
        with pytest.raises(CheckpointCorruptedError):
            load_checkpoint(bad)

    def test_valid_checkpoint_loads_fine(self, tmp_path):
        cp = Checkpoint(
            venture_id="v_valid",
            reason=CheckpointReason.MANUAL,
            progress_summary="all good",
        )
        path = save_checkpoint_atomic(cp, tmp_path)
        loaded = load_checkpoint(path)
        assert loaded.venture_id == "v_valid"

    def test_checkpoint_with_null_bytes_raises(self, tmp_path):
        """A file with null bytes in JSON is not valid."""
        bad = tmp_path / "nullbytes.json"
        bad.write_bytes(b'{"venture_id": "v_x"\x00}')
        with pytest.raises(CheckpointCorruptedError):
            load_checkpoint(bad)

    def test_overwritten_checkpoint_loads_new_data(self, tmp_path):
        """Saving a checkpoint twice (same ID) results in new data being read."""
        cp = Checkpoint(
            venture_id="v_overwrite",
            reason=CheckpointReason.MANUAL,
            progress_summary="original",
        )
        path = save_checkpoint_atomic(cp, tmp_path)

        # Manually overwrite with new content (same id)
        cp2 = Checkpoint(
            id=cp.id,  # same ID
            venture_id="v_overwrite",
            reason=CheckpointReason.MANUAL,
            progress_summary="overwritten",
        )
        save_checkpoint_atomic(cp2, tmp_path)

        loaded = load_checkpoint(path)
        assert loaded.progress_summary == "overwritten"


# ---------------------------------------------------------------------------
# Missing files (file integrity)
# ---------------------------------------------------------------------------


class TestMissingFiles:
    def test_missing_file_reported_as_issue(self, tmp_path):
        f = tmp_path / "important.py"
        f.write_text("x = 1")
        snap = snapshot_file(f)
        f.unlink()  # delete after snapshotting
        issues = verify_file_integrity([snap])
        assert len(issues) == 1
        assert issues[0][1] == "file_missing"

    def test_modified_file_reported_as_checksum_mismatch(self, tmp_path):
        f = tmp_path / "important.py"
        f.write_text("original")
        snap = snapshot_file(f)
        f.write_text("modified by attacker")
        issues = verify_file_integrity([snap])
        assert len(issues) == 1
        assert "checksum_mismatch" in issues[0][1]

    def test_file_that_never_existed_not_reported(self, tmp_path):
        """A snapshot of a non-existent file (checksum='') is not flagged."""
        from parsica_ventures.models import FileSnapshot
        snap = FileSnapshot(
            path=str(tmp_path / "never_existed.py"),
            checksum="",  # means it didn't exist at snapshot time
            size=0,
        )
        issues = verify_file_integrity([snap])
        assert issues == []

    def test_multiple_issues_reported(self, tmp_path):
        f1 = tmp_path / "a.py"
        f2 = tmp_path / "b.py"
        f1.write_text("a")
        f2.write_text("b")
        snap1 = snapshot_file(f1)
        snap2 = snapshot_file(f2)
        f1.unlink()
        f2.write_text("changed")
        issues = verify_file_integrity([snap1, snap2])
        assert len(issues) == 2

    def test_no_issues_when_all_files_intact(self, tmp_path):
        files = [tmp_path / f"f{i}.txt" for i in range(3)]
        for f in files:
            f.write_text("content")
        snaps = [snapshot_file(f) for f in files]
        issues = verify_file_integrity(snaps)
        assert issues == []


# ---------------------------------------------------------------------------
# Resume from checkpoint after recovery
# ---------------------------------------------------------------------------


class TestCheckpointRecoveryData:
    def test_checkpoint_preserves_executor_state(self, tmp_path):
        cp = Checkpoint(
            venture_id="v_recover",
            reason=CheckpointReason.CONTEXT_LIMIT,
            progress_summary="recovery test",
            executor_state={"tokens_used": 90000, "last_tool": "file_read"},
        )
        path = save_checkpoint_atomic(cp, tmp_path)
        recovered = load_checkpoint(path)
        assert recovered.executor_state["tokens_used"] == 90000
        assert recovered.executor_state["last_tool"] == "file_read"

    def test_checkpoint_preserves_memory_ids(self, tmp_path):
        cp = Checkpoint(
            venture_id="v_mem",
            reason=CheckpointReason.MANUAL,
            progress_summary="memory test",
            memory_ids=["mem_001", "mem_002", "mem_003"],
        )
        path = save_checkpoint_atomic(cp, tmp_path)
        loaded = load_checkpoint(path)
        assert loaded.memory_ids == ["mem_001", "mem_002", "mem_003"]

    def test_checkpoint_preserves_next_steps(self, tmp_path):
        from parsica_ventures.models import NextStep
        cp = Checkpoint(
            venture_id="v_steps",
            reason=CheckpointReason.MANUAL,
            progress_summary="next steps",
            next_steps=[
                NextStep(description="Continue analysis", type="investigate"),
                NextStep(description="Write report", type="create_artifact"),
            ],
        )
        path = save_checkpoint_atomic(cp, tmp_path)
        loaded = load_checkpoint(path)
        assert len(loaded.next_steps) == 2
        assert loaded.next_steps[0].description == "Continue analysis"
        assert loaded.next_steps[1].type == "create_artifact"
