"""Tests for the v0.5.0 approval system — state transitions, CRUD, engine flow, bridge."""
from __future__ import annotations

import asyncio
import json
import sys
import tempfile
from io import StringIO
from pathlib import Path
from typing import Any

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from parsica_ventures.models import (
    ApprovalRequest,
    Venture,
    VentureNotification,
    VenturePolicy,
    VentureState,
)
from parsica_ventures.state import (
    ACTIVE_STATES,
    VALID_TRANSITIONS,
    StateMachine,
    is_valid_transition,
    validate_transition,
)
from parsica_ventures.store import VentureStore
from parsica_ventures.config import VenturesConfig
from parsica_ventures.engine import VentureEngine
from parsica_ventures.executor import ExecutorRegistry
from parsica_ventures.memory_bridge import NoopMemoryBridge
from parsica_ventures.exceptions import InvalidStateTransitionError


def _make_venture(state=VentureState.CREATED, **kwargs) -> Venture:
    v = Venture(
        title=kwargs.get("title", "Test"),
        goal="Test approval",
        exit_condition="Done",
        executor_type="subprocess",
        policy=kwargs.get("policy", VenturePolicy()),
    )
    v.state = state
    return v


# ---------------------------------------------------------------------------
# 1. Approval state transitions
# ---------------------------------------------------------------------------


class TestApprovalStateTransitions:
    """Test AWAITING_APPROVAL state transitions in the state machine."""

    def test_running_to_awaiting_approval(self):
        assert is_valid_transition(VentureState.RUNNING, VentureState.AWAITING_APPROVAL)

    def test_awaiting_approval_to_running(self):
        assert is_valid_transition(VentureState.AWAITING_APPROVAL, VentureState.RUNNING)

    def test_awaiting_approval_to_paused(self):
        assert is_valid_transition(VentureState.AWAITING_APPROVAL, VentureState.PAUSED)

    def test_awaiting_approval_to_aborted(self):
        assert is_valid_transition(VentureState.AWAITING_APPROVAL, VentureState.ABORTED)

    def test_awaiting_approval_to_completed_invalid(self):
        assert not is_valid_transition(VentureState.AWAITING_APPROVAL, VentureState.COMPLETED)

    def test_awaiting_approval_to_queued_invalid(self):
        assert not is_valid_transition(VentureState.AWAITING_APPROVAL, VentureState.QUEUED)

    def test_awaiting_approval_to_failed_invalid(self):
        assert not is_valid_transition(VentureState.AWAITING_APPROVAL, VentureState.FAILED)

    def test_awaiting_approval_in_active_states(self):
        assert VentureState.AWAITING_APPROVAL in ACTIVE_STATES

    def test_created_to_awaiting_approval_invalid(self):
        assert not is_valid_transition(VentureState.CREATED, VentureState.AWAITING_APPROVAL)

    def test_queued_to_awaiting_approval_invalid(self):
        assert not is_valid_transition(VentureState.QUEUED, VentureState.AWAITING_APPROVAL)

    def test_paused_to_awaiting_approval_invalid(self):
        assert not is_valid_transition(VentureState.PAUSED, VentureState.AWAITING_APPROVAL)


class TestApprovalStateMachineSync:
    """Test state machine sync transitions with AWAITING_APPROVAL."""

    def test_running_to_awaiting_and_back(self):
        sm = StateMachine()
        v = _make_venture()
        sm.transition_sync(v, VentureState.QUEUED, "start", "user")
        sm.transition_sync(v, VentureState.RUNNING, "slot", "engine")
        sm.transition_sync(v, VentureState.AWAITING_APPROVAL, "approval needed", "engine")
        assert v.state == VentureState.AWAITING_APPROVAL

        sm.transition_sync(v, VentureState.RUNNING, "approved", "user")
        assert v.state == VentureState.RUNNING

    def test_running_to_awaiting_to_paused(self):
        sm = StateMachine()
        v = _make_venture()
        sm.transition_sync(v, VentureState.QUEUED, "start", "user")
        sm.transition_sync(v, VentureState.RUNNING, "slot", "engine")
        sm.transition_sync(v, VentureState.AWAITING_APPROVAL, "gate", "engine")
        sm.transition_sync(v, VentureState.PAUSED, "denied", "user")
        assert v.state == VentureState.PAUSED

    def test_running_to_awaiting_to_aborted(self):
        sm = StateMachine()
        v = _make_venture()
        sm.transition_sync(v, VentureState.QUEUED, "start", "user")
        sm.transition_sync(v, VentureState.RUNNING, "slot", "engine")
        sm.transition_sync(v, VentureState.AWAITING_APPROVAL, "gate", "engine")
        sm.transition_sync(v, VentureState.ABORTED, "denied+abort", "user")
        assert v.state == VentureState.ABORTED

    def test_invalid_from_awaiting_to_queued(self):
        sm = StateMachine()
        v = _make_venture()
        sm.transition_sync(v, VentureState.QUEUED, "start", "user")
        sm.transition_sync(v, VentureState.RUNNING, "slot", "engine")
        sm.transition_sync(v, VentureState.AWAITING_APPROVAL, "gate", "engine")
        with pytest.raises(InvalidStateTransitionError):
            sm.transition_sync(v, VentureState.QUEUED, "invalid", "engine")

    def test_awaiting_approval_records_history(self):
        sm = StateMachine()
        v = _make_venture()
        sm.transition_sync(v, VentureState.QUEUED, "start", "user")
        sm.transition_sync(v, VentureState.RUNNING, "slot", "engine")
        sm.transition_sync(v, VentureState.AWAITING_APPROVAL, "gate=deploy", "engine")
        assert len(v.state_history) == 3
        assert v.state_history[-1].from_state == VentureState.RUNNING
        assert v.state_history[-1].to_state == VentureState.AWAITING_APPROVAL


# ---------------------------------------------------------------------------
# 2. ApprovalRequest CRUD (store)
# ---------------------------------------------------------------------------


class TestApprovalRequestCRUD:
    def test_save_and_retrieve(self, tmp_path):
        store = VentureStore(db_path=tmp_path / "test.db")
        v = _make_venture()
        store.save_venture(v)

        ar = ApprovalRequest(venture_id=v.id, gate="deploy", context={"env": "prod"})
        store.save_approval_request(ar)

        retrieved = store.get_approval_request(ar.id)
        assert retrieved is not None
        assert retrieved.venture_id == v.id
        assert retrieved.gate == "deploy"
        assert retrieved.context == {"env": "prod"}
        assert retrieved.resolution == "pending"
        assert retrieved.resolved_at is None
        store.close()

    def test_get_pending_approvals(self, tmp_path):
        store = VentureStore(db_path=tmp_path / "test.db")
        v = _make_venture()
        store.save_venture(v)

        ar1 = ApprovalRequest(venture_id=v.id, gate="deploy")
        ar2 = ApprovalRequest(venture_id=v.id, gate="publish")
        store.save_approval_request(ar1)
        store.save_approval_request(ar2)

        pending = store.get_pending_approvals(v.id)
        assert len(pending) == 2
        assert {p.gate for p in pending} == {"deploy", "publish"}
        store.close()

    def test_get_pending_approvals_filter_by_venture(self, tmp_path):
        store = VentureStore(db_path=tmp_path / "test.db")
        v1 = _make_venture(title="V1")
        v2 = _make_venture(title="V2")
        store.save_venture(v1)
        store.save_venture(v2)

        ar1 = ApprovalRequest(venture_id=v1.id, gate="deploy")
        ar2 = ApprovalRequest(venture_id=v2.id, gate="publish")
        store.save_approval_request(ar1)
        store.save_approval_request(ar2)

        pending_v1 = store.get_pending_approvals(v1.id)
        assert len(pending_v1) == 1
        assert pending_v1[0].gate == "deploy"

        # All pending
        all_pending = store.get_pending_approvals()
        assert len(all_pending) == 2
        store.close()

    def test_resolve_approval(self, tmp_path):
        store = VentureStore(db_path=tmp_path / "test.db")
        v = _make_venture()
        store.save_venture(v)

        ar = ApprovalRequest(venture_id=v.id, gate="deploy")
        store.save_approval_request(ar)

        resolved = store.resolve_approval(ar.id, "approved", "antaris")
        assert resolved is not None
        assert resolved.resolution == "approved"
        assert resolved.resolved_by == "antaris"
        assert resolved.resolved_at is not None

        # No longer pending
        pending = store.get_pending_approvals(v.id)
        assert len(pending) == 0
        store.close()

    def test_resolve_already_resolved(self, tmp_path):
        store = VentureStore(db_path=tmp_path / "test.db")
        v = _make_venture()
        store.save_venture(v)

        ar = ApprovalRequest(venture_id=v.id, gate="deploy")
        store.save_approval_request(ar)

        store.resolve_approval(ar.id, "approved", "user1")
        # Try to resolve again — should return None because it is no longer pending
        result = store.resolve_approval(ar.id, "denied", "user2")
        assert result is None
        store.close()

    def test_get_nonexistent_approval(self, tmp_path):
        store = VentureStore(db_path=tmp_path / "test.db")
        result = store.get_approval_request("ar_nonexistent")
        assert result is None
        store.close()

    def test_delete_venture_cascades_approvals(self, tmp_path):
        store = VentureStore(db_path=tmp_path / "test.db")
        v = _make_venture()
        store.save_venture(v)

        ar = ApprovalRequest(venture_id=v.id, gate="deploy")
        store.save_approval_request(ar)

        store.delete_venture(v.id)
        assert store.get_approval_request(ar.id) is None
        store.close()


# ---------------------------------------------------------------------------
# 3. Notification model
# ---------------------------------------------------------------------------


class TestVentureNotification:
    def test_default_notification(self):
        n = VentureNotification(channel_id="123")
        assert n.channel_type == "discord"
        assert n.channel_id == "123"
        assert "checkpoint" in n.notify_on
        assert "approval" in n.notify_on
        assert "completed" in n.notify_on
        assert "failed" in n.notify_on

    def test_custom_notification(self):
        n = VentureNotification(
            channel_type="webhook",
            channel_id="https://hooks.example.com/123",
            notify_on=["failed"],
        )
        assert n.channel_type == "webhook"
        assert n.notify_on == ["failed"]

    def test_venture_with_notification(self):
        v = Venture(
            title="Test",
            goal="Test",
            exit_condition="Done",
            executor_type="subprocess",
            notification=VentureNotification(channel_id="123456"),
        )
        assert v.notification is not None
        assert v.notification.channel_id == "123456"

    def test_venture_without_notification(self):
        v = Venture(
            title="Test",
            goal="Test",
            exit_condition="Done",
            executor_type="subprocess",
        )
        assert v.notification is None

    def test_notification_persists_to_store(self, tmp_path):
        store = VentureStore(db_path=tmp_path / "test.db")
        v = Venture(
            title="Test",
            goal="Test",
            exit_condition="Done",
            executor_type="subprocess",
            notification=VentureNotification(
                channel_type="dm",
                channel_id="789",
                notify_on=["approval", "failed"],
            ),
        )
        store.save_venture(v)

        loaded = store.get_venture(v.id)
        assert loaded is not None
        assert loaded.notification is not None
        assert loaded.notification.channel_type == "dm"
        assert loaded.notification.channel_id == "789"
        assert loaded.notification.notify_on == ["approval", "failed"]
        store.close()

    def test_notification_none_persists(self, tmp_path):
        store = VentureStore(db_path=tmp_path / "test.db")
        v = Venture(
            title="Test",
            goal="Test",
            exit_condition="Done",
            executor_type="subprocess",
        )
        store.save_venture(v)

        loaded = store.get_venture(v.id)
        assert loaded.notification is None
        store.close()


# ---------------------------------------------------------------------------
# 4. Engine approval flow
# ---------------------------------------------------------------------------


def _make_engine(tmp_path):
    """Create an engine with mock executor for testing."""
    config = VenturesConfig(store_path=str(tmp_path), max_concurrent=3)
    store = VentureStore(db_path=tmp_path / "test.db")

    from conftest import MockExecutor

    reg = ExecutorRegistry()
    reg.register("subprocess", MockExecutor)

    engine = VentureEngine(
        config=config,
        store=store,
        memory_bridge=NoopMemoryBridge(),
        executor_registry=reg,
    )
    return engine, store


class TestEngineApprovalFlow:
    @pytest.mark.asyncio
    async def test_request_approval_transitions_state(self, tmp_path):
        engine, store = _make_engine(tmp_path)
        v = engine.create_venture(
            title="Test", goal="test", exit_condition="done",
            executor_type="subprocess",
        )
        # Start the venture
        handle = await engine.start_venture(v.id)
        assert handle is not None

        # Request approval
        ar = await engine.request_approval(v.id, "deploy", {"env": "prod"})
        assert ar.gate == "deploy"
        assert ar.resolution == "pending"

        reloaded = engine.get_venture(v.id)
        assert reloaded.state == VentureState.AWAITING_APPROVAL
        store.close()

    @pytest.mark.asyncio
    async def test_approve_without_checkpoint_stays_paused(self, tmp_path):
        engine, store = _make_engine(tmp_path)
        v = engine.create_venture(
            title="Test", goal="test", exit_condition="done",
            executor_type="subprocess",
        )
        await engine.start_venture(v.id)
        ar = await engine.request_approval(v.id, "deploy")

        result = await engine.resolve_approval(ar.id, "approved", "antaris")
        assert result is not None
        assert result.resolution == "approved"

        reloaded = engine.get_venture(v.id)
        assert reloaded.state == VentureState.PAUSED
        store.close()

    @pytest.mark.asyncio
    async def test_deny_transitions_to_paused(self, tmp_path):
        engine, store = _make_engine(tmp_path)
        v = engine.create_venture(
            title="Test", goal="test", exit_condition="done",
            executor_type="subprocess",
        )
        await engine.start_venture(v.id)
        ar = await engine.request_approval(v.id, "deploy")

        result = await engine.resolve_approval(ar.id, "denied", "antaris")
        assert result is not None
        assert result.resolution == "denied"

        reloaded = engine.get_venture(v.id)
        assert reloaded.state == VentureState.PAUSED
        store.close()

    @pytest.mark.asyncio
    async def test_approval_timeout_auto_pause(self, tmp_path):
        engine, store = _make_engine(tmp_path)
        v = engine.create_venture(
            title="Test", goal="test", exit_condition="done",
            executor_type="subprocess",
            policy=VenturePolicy(
                gate_timeout_seconds=1,
                gate_timeout_action="auto_pause",
            ),
        )
        await engine.start_venture(v.id)
        ar = await engine.request_approval(v.id, "deploy")

        # Wait for timeout
        await asyncio.sleep(1.5)

        reloaded = engine.get_venture(v.id)
        assert reloaded.state == VentureState.PAUSED

        resolved_ar = store.get_approval_request(ar.id)
        assert resolved_ar.resolution == "timeout"
        store.close()

    @pytest.mark.asyncio
    async def test_approval_timeout_auto_approve_without_checkpoint_stays_paused(self, tmp_path):
        engine, store = _make_engine(tmp_path)
        v = engine.create_venture(
            title="Test", goal="test", exit_condition="done",
            executor_type="subprocess",
            policy=VenturePolicy(
                gate_timeout_seconds=1,
                gate_timeout_action="auto_approve",
            ),
        )
        await engine.start_venture(v.id)
        ar = await engine.request_approval(v.id, "deploy")

        await asyncio.sleep(1.5)

        reloaded = engine.get_venture(v.id)
        assert reloaded.state == VentureState.PAUSED

        resolved_ar = store.get_approval_request(ar.id)
        assert resolved_ar.resolution == "timeout"
        store.close()

    @pytest.mark.asyncio
    async def test_approval_timeout_auto_abort(self, tmp_path):
        engine, store = _make_engine(tmp_path)
        v = engine.create_venture(
            title="Test", goal="test", exit_condition="done",
            executor_type="subprocess",
            policy=VenturePolicy(
                gate_timeout_seconds=1,
                gate_timeout_action="auto_abort",
            ),
        )
        await engine.start_venture(v.id)
        ar = await engine.request_approval(v.id, "deploy")

        await asyncio.sleep(1.5)

        reloaded = engine.get_venture(v.id)
        assert reloaded.state == VentureState.ABORTED
        store.close()

    @pytest.mark.asyncio
    async def test_resolve_before_timeout_cancels_timer(self, tmp_path):
        engine, store = _make_engine(tmp_path)
        v = engine.create_venture(
            title="Test", goal="test", exit_condition="done",
            executor_type="subprocess",
            policy=VenturePolicy(gate_timeout_seconds=5),
        )
        await engine.start_venture(v.id)
        ar = await engine.request_approval(v.id, "deploy")

        # Resolve immediately
        await engine.resolve_approval(ar.id, "approved", "user")

        # Timer should be cancelled
        assert ar.id not in engine._approval_timers
        store.close()

    @pytest.mark.asyncio
    async def test_pending_approvals_from_engine(self, tmp_path):
        engine, store = _make_engine(tmp_path)
        v = engine.create_venture(
            title="Test", goal="test", exit_condition="done",
            executor_type="subprocess",
        )
        await engine.start_venture(v.id)
        ar = await engine.request_approval(v.id, "deploy")

        pending = store.get_pending_approvals(v.id)
        assert len(pending) == 1
        assert pending[0].id == ar.id
        store.close()

    @pytest.mark.asyncio
    async def test_approval_notifies_observer(self, tmp_path):
        engine, store = _make_engine(tmp_path)
        approvals_received = []

        class TestObs:
            async def on_started(self, v): pass
            async def on_progress(self, v, u): pass
            async def on_checkpoint(self, v, c): pass
            async def on_approval_needed(self, v, gate, ctx):
                approvals_received.append({"gate": gate, "venture_id": v.id})
            async def on_completed(self, v, r): pass
            async def on_failed(self, v, e): pass
            async def on_paused(self, v): pass
            async def on_aborted(self, v): pass

        engine.observer.add(TestObs())

        v = engine.create_venture(
            title="Test", goal="test", exit_condition="done",
            executor_type="subprocess",
        )
        await engine.start_venture(v.id)
        await engine.request_approval(v.id, "git_push", {"branch": "main"})

        assert len(approvals_received) == 1
        assert approvals_received[0]["gate"] == "git_push"
        store.close()

    @pytest.mark.asyncio
    async def test_create_venture_with_notification(self, tmp_path):
        engine, store = _make_engine(tmp_path)
        v = engine.create_venture(
            title="Notify Test",
            goal="test",
            exit_condition="done",
            executor_type="subprocess",
            notification=VentureNotification(channel_id="123456789"),
        )
        assert v.notification is not None
        assert v.notification.channel_id == "123456789"

        reloaded = engine.get_venture(v.id)
        assert reloaded.notification is not None
        assert reloaded.notification.channel_id == "123456789"
        store.close()

    @pytest.mark.asyncio
    async def test_awaiting_approval_counts_as_active(self, tmp_path):
        """AWAITING_APPROVAL should count toward max_concurrent."""
        engine, store = _make_engine(tmp_path)
        # Create 3 ventures (max_concurrent=3)
        v1 = engine.create_venture(
            title="V1", goal="test", exit_condition="done",
            executor_type="subprocess",
        )
        v2 = engine.create_venture(
            title="V2", goal="test", exit_condition="done",
            executor_type="subprocess",
        )
        v3 = engine.create_venture(
            title="V3", goal="test", exit_condition="done",
            executor_type="subprocess",
        )

        await engine.start_venture(v1.id)
        await engine.start_venture(v2.id)
        await engine.start_venture(v3.id)

        # Put v1 into AWAITING_APPROVAL
        await engine.request_approval(v1.id, "deploy")

        # v1 is now AWAITING_APPROVAL — still counts as active
        active_count = store.count_by_state(list(ACTIVE_STATES))
        assert active_count == 3  # all three slots occupied

        store.close()


# ---------------------------------------------------------------------------
# 5. Schema v2 migration
# ---------------------------------------------------------------------------


class TestSchemaV2Migration:
    def test_fresh_db_creates_approval_table(self, tmp_path):
        store = VentureStore(db_path=tmp_path / "test.db")
        # approval_requests table should exist
        conn = store._conn
        row = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='approval_requests'"
        ).fetchone()
        assert row is not None
        store.close()

    def test_fresh_db_has_notification_column(self, tmp_path):
        store = VentureStore(db_path=tmp_path / "test.db")
        conn = store._conn
        # Check that notification column exists
        info = conn.execute("PRAGMA table_info(ventures)").fetchall()
        col_names = [row["name"] for row in info]
        assert "notification" in col_names
        store.close()

    def test_schema_version_is_2(self, tmp_path):
        store = VentureStore(db_path=tmp_path / "test.db")
        conn = store._conn
        row = conn.execute("SELECT MAX(version) as v FROM schema_version").fetchone()
        assert row["v"] == 2
        store.close()


# ---------------------------------------------------------------------------
# 6. ApprovalRequest model
# ---------------------------------------------------------------------------


class TestApprovalRequestModel:
    def test_default_fields(self):
        ar = ApprovalRequest(venture_id="v_123", gate="deploy")
        assert ar.id.startswith("ar_")
        assert ar.venture_id == "v_123"
        assert ar.gate == "deploy"
        assert ar.resolution == "pending"
        assert ar.resolved_at is None
        assert ar.resolved_by is None
        assert ar.context == {}
        assert ar.requested_at is not None

    def test_custom_context(self):
        ar = ApprovalRequest(
            venture_id="v_123",
            gate="deploy",
            context={"env": "prod", "branch": "main"},
        )
        assert ar.context["env"] == "prod"
        assert ar.context["branch"] == "main"

    def test_serialization(self):
        ar = ApprovalRequest(venture_id="v_123", gate="deploy")
        d = ar.model_dump()
        assert d["venture_id"] == "v_123"
        assert d["resolution"] == "pending"
