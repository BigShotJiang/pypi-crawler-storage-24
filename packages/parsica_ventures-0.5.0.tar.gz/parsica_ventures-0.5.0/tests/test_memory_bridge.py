"""Tests for parsica_ventures.memory_bridge — NoopBridge, ParsicaMemoryBridge (mocked), backup."""
from __future__ import annotations

import json
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from parsica_ventures.memory_bridge import (
    NoopMemoryBridge,
    ParsicaMemoryBridge,
    create_memory_bridge,
    save_memories_backup,
    load_memories_backup,
)


# ---------------------------------------------------------------------------
# NoopMemoryBridge
# ---------------------------------------------------------------------------


class TestNoopBridge:
    def test_not_available(self):
        bridge = NoopMemoryBridge()
        assert bridge.available() is False

    def test_store_finding_returns_none(self):
        bridge = NoopMemoryBridge()
        result = bridge.store_finding("v_1", "some content", "finding")
        assert result is None

    def test_store_finding_with_metadata_returns_none(self):
        bridge = NoopMemoryBridge()
        result = bridge.store_finding("v_1", "content", "decision", {"key": "val"})
        assert result is None

    def test_recall_returns_empty_list(self):
        bridge = NoopMemoryBridge()
        results = bridge.recall_for_venture("v_1")
        assert results == []

    def test_recall_with_query_returns_empty(self):
        bridge = NoopMemoryBridge()
        results = bridge.recall_for_venture("v_1", query="how to fix the bug")
        assert results == []

    def test_export_returns_empty_list(self):
        bridge = NoopMemoryBridge()
        results = bridge.export_venture_memories("v_1")
        assert results == []

    def test_implements_memory_bridge_protocol(self):
        from parsica_ventures.memory_bridge import MemoryBridge
        bridge = NoopMemoryBridge()
        assert isinstance(bridge, MemoryBridge)


# ---------------------------------------------------------------------------
# ParsicaMemoryBridge (mocked parsica-memory)
# ---------------------------------------------------------------------------


class TestParsicaMemoryBridge:
    def _make_mock_pm(self):
        """Create a mock parsica_memory module."""
        mock_store = MagicMock()
        mock_store.add.return_value = "mem_001"
        mock_store.search.return_value = [
            {"id": "mem_001", "content": "Found something"},
            {"id": "mem_002", "content": "Another finding"},
        ]
        mock_pm = MagicMock()
        mock_pm.MemoryStore.return_value = mock_store
        return mock_pm, mock_store

    def test_available_when_store_connected(self, tmp_path):
        mock_pm, mock_store = self._make_mock_pm()
        with patch("parsica_ventures.memory_bridge._get_parsica_memory", return_value=mock_pm):
            bridge = ParsicaMemoryBridge(store_path=str(tmp_path))
        assert bridge.available() is True

    def test_not_available_when_pm_not_installed(self, tmp_path):
        with patch("parsica_ventures.memory_bridge._get_parsica_memory", return_value=None):
            bridge = ParsicaMemoryBridge(store_path=str(tmp_path))
        assert bridge.available() is False

    def test_not_available_without_store_path(self):
        mock_pm, _ = self._make_mock_pm()
        with patch("parsica_ventures.memory_bridge._get_parsica_memory", return_value=mock_pm):
            bridge = ParsicaMemoryBridge(store_path=None)
        assert bridge.available() is False

    def test_store_finding_calls_add(self, tmp_path):
        mock_pm, mock_store = self._make_mock_pm()
        with patch("parsica_ventures.memory_bridge._get_parsica_memory", return_value=mock_pm):
            bridge = ParsicaMemoryBridge(store_path=str(tmp_path))
        mem_id = bridge.store_finding("v_1", "Test finding content", "finding")
        assert mem_id == "mem_001"
        mock_store.add.assert_called_once()

    def test_store_finding_tags_with_venture_id(self, tmp_path):
        mock_pm, mock_store = self._make_mock_pm()
        with patch("parsica_ventures.memory_bridge._get_parsica_memory", return_value=mock_pm):
            bridge = ParsicaMemoryBridge(store_path=str(tmp_path), tag_prefix="ventures")
        bridge.store_finding("v_abc", "content", "decision")
        call_kwargs = mock_store.add.call_args[1] if mock_store.add.call_args[1] else {}
        call_args = mock_store.add.call_args[0] if mock_store.add.call_args[0] else ()
        # Check tags were passed
        tags = call_kwargs.get("tags", [])
        assert any("v_abc" in t for t in tags), f"venture tag not found in {tags}"

    def test_recall_returns_memories(self, tmp_path):
        mock_pm, mock_store = self._make_mock_pm()
        with patch("parsica_ventures.memory_bridge._get_parsica_memory", return_value=mock_pm):
            bridge = ParsicaMemoryBridge(store_path=str(tmp_path))
        results = bridge.recall_for_venture("v_1")
        assert len(results) == 2
        assert results[0]["content"] == "Found something"

    def test_recall_with_query(self, tmp_path):
        mock_pm, mock_store = self._make_mock_pm()
        with patch("parsica_ventures.memory_bridge._get_parsica_memory", return_value=mock_pm):
            bridge = ParsicaMemoryBridge(store_path=str(tmp_path))
        results = bridge.recall_for_venture("v_1", query="bug analysis")
        mock_store.search.assert_called_once()
        call_kwargs = mock_store.search.call_args[1]
        assert call_kwargs.get("query") == "bug analysis"

    def test_store_finding_when_unavailable_returns_none(self):
        with patch("parsica_ventures.memory_bridge._get_parsica_memory", return_value=None):
            bridge = ParsicaMemoryBridge(store_path=None)
        result = bridge.store_finding("v_1", "content", "finding")
        assert result is None

    def test_recall_when_unavailable_returns_empty(self):
        with patch("parsica_ventures.memory_bridge._get_parsica_memory", return_value=None):
            bridge = ParsicaMemoryBridge(store_path=None)
        result = bridge.recall_for_venture("v_1")
        assert result == []

    def test_store_finding_exception_returns_none(self, tmp_path):
        mock_pm, mock_store = self._make_mock_pm()
        mock_store.add.side_effect = RuntimeError("storage error")
        with patch("parsica_ventures.memory_bridge._get_parsica_memory", return_value=mock_pm):
            bridge = ParsicaMemoryBridge(store_path=str(tmp_path))
        result = bridge.store_finding("v_1", "content", "finding")
        assert result is None

    def test_recall_exception_returns_empty(self, tmp_path):
        mock_pm, mock_store = self._make_mock_pm()
        mock_store.search.side_effect = RuntimeError("search error")
        with patch("parsica_ventures.memory_bridge._get_parsica_memory", return_value=mock_pm):
            bridge = ParsicaMemoryBridge(store_path=str(tmp_path))
        result = bridge.recall_for_venture("v_1")
        assert result == []

    def test_export_memories_delegates_to_recall(self, tmp_path):
        mock_pm, mock_store = self._make_mock_pm()
        mock_store.search.return_value = [{"id": "mem_1", "content": "export test"}]
        with patch("parsica_ventures.memory_bridge._get_parsica_memory", return_value=mock_pm):
            bridge = ParsicaMemoryBridge(store_path=str(tmp_path))
        result = bridge.export_venture_memories("v_1")
        assert isinstance(result, list)


# ---------------------------------------------------------------------------
# save/load memories backup
# ---------------------------------------------------------------------------


class TestMemoriesBackup:
    def test_save_creates_file(self, tmp_path):
        memories = [
            {"id": "mem_1", "content": "Finding A"},
            {"id": "mem_2", "content": "Finding B"},
        ]
        path = save_memories_backup(memories, tmp_path)
        assert path.exists()
        assert path.name == "memories_backup.json"

    def test_save_and_load_roundtrip(self, tmp_path):
        memories = [
            {"id": "mem_001", "content": "Test finding", "tags": ["ventures/v_1"]},
            {"id": "mem_002", "content": "Decision log", "tags": ["ventures/v_1", "type:decision"]},
        ]
        save_memories_backup(memories, tmp_path)
        loaded = load_memories_backup(tmp_path)
        assert len(loaded) == 2
        assert loaded[0]["id"] == "mem_001"
        assert loaded[1]["content"] == "Decision log"

    def test_load_nonexistent_returns_empty(self, tmp_path):
        result = load_memories_backup(tmp_path / "nonexistent_dir")
        assert result == []

    def test_load_empty_dir_returns_empty(self, tmp_path):
        result = load_memories_backup(tmp_path)
        assert result == []

    def test_load_corrupted_backup_returns_empty(self, tmp_path):
        bad_file = tmp_path / "memories_backup.json"
        bad_file.write_text("not valid json {{{{")
        result = load_memories_backup(tmp_path)
        assert result == []

    def test_save_empty_list(self, tmp_path):
        path = save_memories_backup([], tmp_path)
        assert path.exists()
        loaded = load_memories_backup(tmp_path)
        assert loaded == []

    def test_save_creates_parent_dirs(self, tmp_path):
        nested_dir = tmp_path / "nested" / "subdir"
        memories = [{"id": "m1", "content": "test"}]
        path = save_memories_backup(memories, nested_dir)
        assert path.exists()


# ---------------------------------------------------------------------------
# create_memory_bridge factory
# ---------------------------------------------------------------------------


class TestCreateMemoryBridge:
    def test_disabled_returns_noop(self):
        bridge = create_memory_bridge(enabled=False)
        assert isinstance(bridge, NoopMemoryBridge)
        assert bridge.available() is False

    def test_pm_not_installed_returns_noop(self):
        with patch("parsica_ventures.memory_bridge._get_parsica_memory", return_value=None):
            bridge = create_memory_bridge(enabled=True)
        assert isinstance(bridge, NoopMemoryBridge)

    def test_pm_installed_returns_parsica_bridge(self, tmp_path):
        mock_pm = MagicMock()
        mock_store = MagicMock()
        mock_pm.MemoryStore.return_value = mock_store
        with patch("parsica_ventures.memory_bridge._get_parsica_memory", return_value=mock_pm):
            bridge = create_memory_bridge(
                enabled=True,
                store_path=str(tmp_path),
                tag_prefix="test",
            )
        assert isinstance(bridge, ParsicaMemoryBridge)
