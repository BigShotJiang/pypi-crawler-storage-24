"""Tests for approval gates — injectable approval provider, gate timeout behavior."""
from __future__ import annotations

import asyncio
import sys
from pathlib import Path
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from parsica_ventures.models import (
    Venture,
    VenturePolicy,
    VentureState,
)
from parsica_ventures.policy import PolicyEngine
from parsica_ventures.observer import MultiObserver, VentureObserver
from parsica_ventures.exceptions import ApprovalTimeoutError


def _make_venture(policy=None) -> Venture:
    return Venture(
        title="Gate Test",
        goal="Test approval gates",
        exit_condition="approved",
        executor_type="subprocess",
        policy=policy or VenturePolicy(),
    )


# ---------------------------------------------------------------------------
# Policy approval gate logic
# ---------------------------------------------------------------------------


class TestPolicyApprovalGates:
    def test_full_autonomy_no_approval(self):
        engine = PolicyEngine()
        v = _make_venture(VenturePolicy(
            autonomy="full",
            approval_gates=["git_push", "deploy"],
        ))
        assert engine.needs_approval(v, "git_push") is False
        assert engine.needs_approval(v, "deploy") is False
        assert engine.needs_approval(v, "write_file") is False

    def test_supervised_always_approves(self):
        engine = PolicyEngine()
        v = _make_venture(VenturePolicy(autonomy="supervised"))
        assert engine.needs_approval(v, "read_file") is True
        assert engine.needs_approval(v, "write_file") is True
        assert engine.needs_approval(v, "anything_at_all") is True

    def test_checkpoints_only_listed_gates(self):
        engine = PolicyEngine()
        v = _make_venture(VenturePolicy(
            autonomy="checkpoints",
            approval_gates=["git_push", "npm_publish"],
        ))
        assert engine.needs_approval(v, "git_push") is True
        assert engine.needs_approval(v, "npm_publish") is True
        assert engine.needs_approval(v, "read_file") is False
        assert engine.needs_approval(v, "write_file") is False

    def test_empty_approval_gates_no_approval(self):
        engine = PolicyEngine()
        v = _make_venture(VenturePolicy(autonomy="checkpoints", approval_gates=[]))
        assert engine.needs_approval(v, "anything") is False

    def test_gate_timeout_configured(self):
        v = _make_venture(VenturePolicy(
            gate_timeout_seconds=120,
            gate_timeout_action="auto_abort",
        ))
        assert v.policy.gate_timeout_seconds == 120
        assert v.policy.gate_timeout_action == "auto_abort"

    def test_default_gate_timeout(self):
        v = _make_venture()
        assert v.policy.gate_timeout_seconds == 300
        assert v.policy.gate_timeout_action == "auto_pause"


# ---------------------------------------------------------------------------
# MockApprovalProvider (injectable)
# ---------------------------------------------------------------------------


class MockApprovalProvider:
    def __init__(self, approve: bool = True, delay: float = 0.0):
        self.approve = approve
        self.delay = delay
        self.requests = []

    async def request_approval(
        self, venture_id: str, gate: str, context: dict[str, Any]
    ) -> bool:
        self.requests.append({"venture_id": venture_id, "gate": gate, "context": context})
        if self.delay > 0:
            await asyncio.sleep(self.delay)
        return self.approve


class TestMockApprovalProvider:
    @pytest.mark.asyncio
    async def test_auto_approve(self):
        provider = MockApprovalProvider(approve=True)
        result = await provider.request_approval("v_1", "git_push", {})
        assert result is True

    @pytest.mark.asyncio
    async def test_auto_deny(self):
        provider = MockApprovalProvider(approve=False)
        result = await provider.request_approval("v_1", "deploy", {})
        assert result is False

    @pytest.mark.asyncio
    async def test_records_requests(self):
        provider = MockApprovalProvider()
        await provider.request_approval("v_1", "git_push", {"branch": "main"})
        await provider.request_approval("v_2", "deploy", {"env": "prod"})
        assert len(provider.requests) == 2
        assert provider.requests[0]["gate"] == "git_push"
        assert provider.requests[1]["context"]["env"] == "prod"

    @pytest.mark.asyncio
    async def test_respects_delay(self):
        import time
        provider = MockApprovalProvider(approve=True, delay=0.1)
        start = time.time()
        await provider.request_approval("v_1", "gate", {})
        elapsed = time.time() - start
        assert elapsed >= 0.1


# ---------------------------------------------------------------------------
# Gate timeout behavior
# ---------------------------------------------------------------------------


class TestGateTimeoutBehavior:
    @pytest.mark.asyncio
    async def test_approval_times_out(self):
        """Simulates a gate that times out if no approval within threshold."""
        async def slow_approval():
            await asyncio.sleep(10)  # Way longer than timeout
            return True

        with pytest.raises(asyncio.TimeoutError):
            await asyncio.wait_for(slow_approval(), timeout=0.05)

    @pytest.mark.asyncio
    async def test_timeout_action_auto_pause(self):
        """gate_timeout_action=auto_pause means venture should be paused."""
        v = _make_venture(VenturePolicy(
            gate_timeout_seconds=1,
            gate_timeout_action="auto_pause",
        ))
        assert v.policy.gate_timeout_action == "auto_pause"

    @pytest.mark.asyncio
    async def test_timeout_action_auto_abort(self):
        v = _make_venture(VenturePolicy(
            gate_timeout_seconds=1,
            gate_timeout_action="auto_abort",
        ))
        assert v.policy.gate_timeout_action == "auto_abort"

    @pytest.mark.asyncio
    async def test_timeout_action_auto_approve(self):
        v = _make_venture(VenturePolicy(
            gate_timeout_seconds=5,
            gate_timeout_action="auto_approve",
        ))
        assert v.policy.gate_timeout_action == "auto_approve"

    def test_approval_timeout_error(self):
        err = ApprovalTimeoutError(gate="git_push", timeout_seconds=300)
        assert err.gate == "git_push"
        assert err.timeout_seconds == 300
        assert "git_push" in str(err)
        assert "300" in str(err)


# ---------------------------------------------------------------------------
# Observer on_approval_needed
# ---------------------------------------------------------------------------


class TestObserverApprovalNotification:
    @pytest.mark.asyncio
    async def test_multi_observer_dispatches_approval(self):
        observer = MultiObserver()
        received = []

        class TestObs:
            async def on_started(self, v): pass
            async def on_progress(self, v, u): pass
            async def on_checkpoint(self, v, c): pass
            async def on_approval_needed(self, v, gate, ctx):
                received.append({"gate": gate, "ctx": ctx})
            async def on_completed(self, v, r): pass
            async def on_failed(self, v, e): pass
            async def on_paused(self, v): pass
            async def on_aborted(self, v): pass

        observer.add(TestObs())
        v = _make_venture()
        await observer.on_approval_needed(v, "git_push", {"branch": "main"})
        assert len(received) == 1
        assert received[0]["gate"] == "git_push"

    @pytest.mark.asyncio
    async def test_failing_observer_doesnt_block_approval(self):
        """If one observer fails on approval, others still receive it."""
        observer = MultiObserver()
        received = []

        class BadObs:
            async def on_started(self, v): pass
            async def on_progress(self, v, u): pass
            async def on_checkpoint(self, v, c): pass
            async def on_approval_needed(self, v, gate, ctx):
                raise RuntimeError("Observer crash!")
            async def on_completed(self, v, r): pass
            async def on_failed(self, v, e): pass
            async def on_paused(self, v): pass
            async def on_aborted(self, v): pass

        class GoodObs:
            async def on_started(self, v): pass
            async def on_progress(self, v, u): pass
            async def on_checkpoint(self, v, c): pass
            async def on_approval_needed(self, v, gate, ctx):
                received.append(gate)
            async def on_completed(self, v, r): pass
            async def on_failed(self, v, e): pass
            async def on_paused(self, v): pass
            async def on_aborted(self, v): pass

        observer.add(BadObs())
        observer.add(GoodObs())
        v = _make_venture()
        await observer.on_approval_needed(v, "deploy", {})
        assert "deploy" in received


# ---------------------------------------------------------------------------
# Approval gate integration with engine callback
# ---------------------------------------------------------------------------


class TestEngineCallbackApproval:
    @pytest.mark.asyncio
    async def test_callback_approval_notifies_observer(self):
        """The engine callback's on_approval_needed should notify observers."""
        from parsica_ventures.store import VentureStore
        from parsica_ventures.config import VenturesConfig
        from parsica_ventures.engine import VentureEngine
        from parsica_ventures.executor import ExecutorRegistry
        from parsica_ventures.memory_bridge import NoopMemoryBridge
        import tempfile

        with tempfile.TemporaryDirectory() as tmpdir:
            config = VenturesConfig(store_path=tmpdir, max_concurrent=3)
            store = VentureStore(db_path=f"{tmpdir}/test.db")

            reg = ExecutorRegistry()
            from conftest import MockExecutor
            reg.register("subprocess", MockExecutor)

            engine = VentureEngine(
                config=config,
                store=store,
                memory_bridge=NoopMemoryBridge(),
                executor_registry=reg,
            )

            approvals = []

            class ApprovalObs:
                async def on_started(self, v): pass
                async def on_progress(self, v, u): pass
                async def on_checkpoint(self, v, c): pass
                async def on_approval_needed(self, v, gate, ctx):
                    approvals.append({"venture": v.id, "gate": gate})
                async def on_completed(self, v, r): pass
                async def on_failed(self, v, e): pass
                async def on_paused(self, v): pass
                async def on_aborted(self, v): pass

            engine.observer.add(ApprovalObs())

            v = engine.create_venture(
                title="Gate Test",
                goal="test",
                exit_condition="done",
                executor_type="subprocess",
            )
            # Transition to RUNNING so approval can fire
            engine.state_machine.transition_sync(v, VentureState.QUEUED, "start", "user")
            engine.state_machine.transition_sync(v, VentureState.RUNNING, "slot", "engine")
            store.save_venture(v)

            cb = engine._make_callback(v.id)
            await cb.on_approval_needed("git_push", {"branch": "main"})

            assert len(approvals) == 1
            assert approvals[0]["gate"] == "git_push"
            # Verify the venture is now AWAITING_APPROVAL
            reloaded = store.get_venture(v.id)
            assert reloaded.state == VentureState.AWAITING_APPROVAL
            store.close()
