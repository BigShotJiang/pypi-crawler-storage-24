"""Tests for parsica_ventures.config — defaults, TOML loading, env var override."""
from __future__ import annotations

import os
import sys
import tempfile
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from parsica_ventures.config import (
    load_config,
    VenturesConfig,
    MemoryConfig,
    StorageConfig,
    DEFAULT_STORE_PATH,
    DEFAULT_MEMORY_STORE_PATH,
)


# ---------------------------------------------------------------------------
# Default values
# ---------------------------------------------------------------------------


class TestDefaultConfig:
    def test_default_store_path(self):
        cfg = VenturesConfig()
        assert "parsica" in cfg.store_path.lower() or "ventures" in cfg.store_path.lower()

    def test_default_max_concurrent(self):
        cfg = VenturesConfig()
        assert cfg.max_concurrent == 3

    def test_default_executor(self):
        cfg = VenturesConfig()
        assert cfg.default_executor == "subprocess"

    def test_default_policy(self):
        cfg = VenturesConfig()
        assert cfg.default_policy == "checkpoints"

    def test_default_max_duration(self):
        cfg = VenturesConfig()
        assert cfg.default_max_duration_hours == 8.0

    def test_default_health_poll(self):
        cfg = VenturesConfig()
        assert cfg.health_poll_interval_seconds == 30

    def test_default_health_failure_threshold(self):
        cfg = VenturesConfig()
        assert cfg.health_failure_threshold == 3

    def test_default_memory_config(self):
        cfg = VenturesConfig()
        assert cfg.memory.enabled is True
        assert cfg.memory.auto_store_findings is True
        assert cfg.memory.cross_venture_recall is True
        assert cfg.memory.tag_prefix == "ventures"

    def test_default_storage_config(self):
        cfg = VenturesConfig()
        assert cfg.storage.checkpoint_retention_days == 7
        assert cfg.storage.max_checkpoints_per_venture == 50
        assert cfg.storage.log_retention_days == 90

    def test_empty_executors_dict(self):
        cfg = VenturesConfig()
        assert cfg.executors == {}

    def test_empty_observers_dict(self):
        cfg = VenturesConfig()
        assert cfg.observers == {}


class TestMemoryConfig:
    def test_defaults(self):
        mc = MemoryConfig()
        assert mc.enabled is True
        assert "parsica" in mc.store_path.lower() or "memory" in mc.store_path.lower()

    def test_custom_values(self):
        mc = MemoryConfig(enabled=False, tag_prefix="custom")
        assert mc.enabled is False
        assert mc.tag_prefix == "custom"


class TestStorageConfig:
    def test_defaults(self):
        sc = StorageConfig()
        assert sc.checkpoint_retention_days == 7
        assert sc.max_checkpoints_per_venture == 50
        assert sc.log_retention_days == 90


# ---------------------------------------------------------------------------
# load_config — no config file (returns defaults)
# ---------------------------------------------------------------------------


class TestLoadConfigDefaults:
    def test_no_config_returns_defaults(self, tmp_path, monkeypatch):
        """With no config file and PARSICA_VENTURES_CONFIG not set, returns defaults."""
        monkeypatch.delenv("PARSICA_VENTURES_CONFIG", raising=False)
        monkeypatch.chdir(tmp_path)  # ensure no ventures.toml in cwd
        cfg = load_config()
        assert isinstance(cfg, VenturesConfig)
        assert cfg.max_concurrent == 3

    def test_nonexistent_explicit_path_returns_defaults(self, tmp_path):
        cfg = load_config(config_path=tmp_path / "nonexistent.toml")
        assert isinstance(cfg, VenturesConfig)
        assert cfg.max_concurrent == 3


# ---------------------------------------------------------------------------
# load_config — TOML loading
# ---------------------------------------------------------------------------


class TestLoadConfigTOML:
    def test_load_from_explicit_path(self, tmp_path):
        toml_content = """
[ventures]
max_concurrent = 5
default_executor = "subprocess"
"""
        config_file = tmp_path / "ventures.toml"
        config_file.write_text(toml_content)
        cfg = load_config(config_path=config_file)
        assert cfg.max_concurrent == 5
        assert cfg.default_executor == "subprocess"

    def test_load_from_env_var(self, tmp_path, monkeypatch):
        toml_content = """
[ventures]
max_concurrent = 7
"""
        config_file = tmp_path / "custom_ventures.toml"
        config_file.write_text(toml_content)
        monkeypatch.setenv("PARSICA_VENTURES_CONFIG", str(config_file))
        cfg = load_config()
        assert cfg.max_concurrent == 7

    def test_load_toplevel_toml(self, tmp_path):
        """Config at top level (no [ventures] wrapper) also works."""
        toml_content = """
max_concurrent = 9
default_policy = "full"
"""
        config_file = tmp_path / "ventures.toml"
        config_file.write_text(toml_content)
        cfg = load_config(config_path=config_file)
        assert cfg.max_concurrent == 9
        assert cfg.default_policy == "full"

    def test_nested_memory_config(self, tmp_path):
        toml_content = """
[ventures]
max_concurrent = 2

[ventures.memory]
enabled = false
tag_prefix = "myproject"
"""
        config_file = tmp_path / "ventures.toml"
        config_file.write_text(toml_content)
        cfg = load_config(config_path=config_file)
        assert cfg.memory.enabled is False
        assert cfg.memory.tag_prefix == "myproject"

    def test_nested_storage_config(self, tmp_path):
        toml_content = """
[ventures]
[ventures.storage]
checkpoint_retention_days = 14
"""
        config_file = tmp_path / "ventures.toml"
        config_file.write_text(toml_content)
        cfg = load_config(config_path=config_file)
        assert cfg.storage.checkpoint_retention_days == 14

    def test_executor_config(self, tmp_path):
        toml_content = """
[ventures]
[ventures.executors.subprocess]
timeout = 3600
"""
        config_file = tmp_path / "ventures.toml"
        config_file.write_text(toml_content)
        cfg = load_config(config_path=config_file)
        assert "subprocess" in cfg.executors

    def test_custom_store_path(self, tmp_path):
        custom_path = str(tmp_path / "my_store")
        toml_content = f"""
[ventures]
store_path = "{custom_path}"
"""
        config_file = tmp_path / "ventures.toml"
        config_file.write_text(toml_content)
        cfg = load_config(config_path=config_file)
        assert cfg.store_path == custom_path

    def test_find_in_cwd(self, tmp_path, monkeypatch):
        """Config found in current directory."""
        toml_content = """
[ventures]
max_concurrent = 6
"""
        config_file = tmp_path / "ventures.toml"
        config_file.write_text(toml_content)
        monkeypatch.chdir(tmp_path)
        monkeypatch.delenv("PARSICA_VENTURES_CONFIG", raising=False)
        cfg = load_config()
        assert cfg.max_concurrent == 6


# ---------------------------------------------------------------------------
# VenturesConfig validation
# ---------------------------------------------------------------------------


class TestVenturesConfigValidation:
    def test_max_concurrent_set(self):
        cfg = VenturesConfig(max_concurrent=10)
        assert cfg.max_concurrent == 10

    def test_nested_models_are_validated(self):
        cfg = VenturesConfig(
            memory=MemoryConfig(enabled=False),
            storage=StorageConfig(checkpoint_retention_days=30),
        )
        assert cfg.memory.enabled is False
        assert cfg.storage.checkpoint_retention_days == 30
