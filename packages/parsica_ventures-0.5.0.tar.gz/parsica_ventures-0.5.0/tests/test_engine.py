"""Tests for VentureEngine — full lifecycle: create→start→progress→checkpoint→resume→complete."""
from __future__ import annotations

import asyncio
import sys
from pathlib import Path
from datetime import datetime, timezone
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from parsica_ventures.engine import VentureEngine
from parsica_ventures.models import (
    Venture,
    VentureState,
    VenturePolicy,
    VentureResult,
    VentureError,
    FailureCategory,
    ProgressUpdate,
    CheckpointData,
    CheckpointReason,
    Checkpoint,
    ExecutorHandle,
    ExecutorHealth,
)
from parsica_ventures.store import VentureStore
from parsica_ventures.config import VenturesConfig
from parsica_ventures.executor import ExecutorRegistry
from parsica_ventures.memory_bridge import NoopMemoryBridge
from parsica_ventures.exceptions import (
    VentureNotFoundError,
    ExecutorError,
    InvalidStateTransitionError,
)


# ---------------------------------------------------------------------------
# Engine fixtures (also defined in conftest but we keep them local for clarity)
# ---------------------------------------------------------------------------


class RecordingExecutor:
    """Executor that records calls without actually running anything."""

    def __init__(self, **kwargs):
        self.starts = []
        self.resumes = []
        self.aborts = []
        self.pauses = []
        self.checkpoints = []
        self._callback = None

    async def start(self, venture: Venture, callback) -> ExecutorHandle:
        self._callback = callback
        self.starts.append(venture.id)
        return ExecutorHandle(executor_id=f"rec_{venture.id}", pid=99999)

    async def pause(self, venture: Venture) -> None:
        self.pauses.append(venture.id)

    async def checkpoint(self, venture: Venture) -> CheckpointData:
        self.checkpoints.append(venture.id)
        return CheckpointData(
            progress_summary="Recording checkpoint",
            executor_state={"step": 1},
        )

    async def resume(self, venture: Venture, checkpoint, callback) -> ExecutorHandle:
        self._callback = callback
        self.resumes.append(venture.id)
        return ExecutorHandle(executor_id=f"rec_resume_{venture.id}", pid=99998)

    async def abort(self, venture: Venture) -> None:
        self.aborts.append(venture.id)

    async def health(self, venture: Venture) -> ExecutorHealth:
        return ExecutorHealth(alive=True, last_activity=datetime.now(timezone.utc))


def _make_engine(tmp_path) -> tuple[VentureEngine, RecordingExecutor]:
    config = VenturesConfig(store_path=str(tmp_path), max_concurrent=3)
    store = VentureStore(db_path=tmp_path / "test.db")
    reg = ExecutorRegistry()
    executor = RecordingExecutor()
    executor_class = type("FixedExecutor", (), {
        "__init__": lambda self, **kw: setattr(self, "_inner", executor),
        "start": lambda self, v, cb: executor.start(v, cb),
        "pause": lambda self, v: executor.pause(v),
        "checkpoint": lambda self, v: executor.checkpoint(v),
        "resume": lambda self, v, cp, cb: executor.resume(v, cp, cb),
        "abort": lambda self, v: executor.abort(v),
        "health": lambda self, v: executor.health(v),
    })
    reg.register("subprocess", executor_class)
    engine = VentureEngine(
        config=config,
        store=store,
        memory_bridge=NoopMemoryBridge(),
        executor_registry=reg,
    )
    return engine, executor


# ---------------------------------------------------------------------------
# Venture creation
# ---------------------------------------------------------------------------


class TestVentureCreation:
    def test_create_venture_returns_venture(self, tmp_path):
        engine, _ = _make_engine(tmp_path)
        v = engine.create_venture(
            title="Test Venture",
            goal="Do something",
            exit_condition="Done",
            executor_type="subprocess",
        )
        assert isinstance(v, Venture)
        assert v.title == "Test Venture"
        assert v.state == VentureState.CREATED

    def test_create_persists_to_store(self, tmp_path):
        engine, _ = _make_engine(tmp_path)
        v = engine.create_venture(
            title="Persisted",
            goal="persist test",
            exit_condition="done",
        )
        loaded = engine.get_venture(v.id)
        assert loaded.id == v.id
        assert loaded.title == "Persisted"

    def test_create_with_unknown_executor_raises(self, tmp_path):
        engine, _ = _make_engine(tmp_path)
        with pytest.raises(ExecutorError) as exc_info:
            engine.create_venture(
                title="Bad",
                goal="g",
                exit_condition="e",
                executor_type="nonexistent_executor",
            )
        assert "nonexistent_executor" in str(exc_info.value)

    def test_create_with_policy(self, tmp_path):
        engine, _ = _make_engine(tmp_path)
        policy = VenturePolicy(max_cost_usd=5.0, priority=1)
        v = engine.create_venture(
            title="Policy Test",
            goal="g",
            exit_condition="e",
            policy=policy,
        )
        loaded = engine.get_venture(v.id)
        assert loaded.policy.max_cost_usd == 5.0
        assert loaded.policy.priority == 1

    def test_create_with_metadata(self, tmp_path):
        engine, _ = _make_engine(tmp_path)
        v = engine.create_venture(
            title="Meta",
            goal="g",
            exit_condition="e",
            metadata={"project": "alpha"},
        )
        loaded = engine.get_venture(v.id)
        assert loaded.metadata["project"] == "alpha"


# ---------------------------------------------------------------------------
# Start lifecycle
# ---------------------------------------------------------------------------


class TestStartVenture:
    @pytest.mark.asyncio
    async def test_start_transitions_to_running(self, tmp_path):
        engine, _ = _make_engine(tmp_path)
        v = engine.create_venture(title="T", goal="g", exit_condition="e")
        await engine.start_venture(v.id)
        loaded = engine.get_venture(v.id)
        assert loaded.state == VentureState.RUNNING

    @pytest.mark.asyncio
    async def test_start_returns_handle(self, tmp_path):
        engine, _ = _make_engine(tmp_path)
        v = engine.create_venture(title="T", goal="g", exit_condition="e")
        handle = await engine.start_venture(v.id)
        assert handle.executor_id is not None

    @pytest.mark.asyncio
    async def test_start_sets_started_at(self, tmp_path):
        engine, _ = _make_engine(tmp_path)
        v = engine.create_venture(title="T", goal="g", exit_condition="e")
        await engine.start_venture(v.id)
        loaded = engine.get_venture(v.id)
        assert loaded.started_at is not None

    @pytest.mark.asyncio
    async def test_start_nonexistent_raises(self, tmp_path):
        engine, _ = _make_engine(tmp_path)
        with pytest.raises(VentureNotFoundError):
            await engine.start_venture("v_doesnotexist")


# ---------------------------------------------------------------------------
# Progress updates
# ---------------------------------------------------------------------------


class TestProgressUpdates:
    @pytest.mark.asyncio
    async def test_progress_persisted_to_store(self, tmp_path):
        engine, _ = _make_engine(tmp_path)
        v = engine.create_venture(title="T", goal="g", exit_condition="e")
        await engine.start_venture(v.id)

        cb = engine._make_callback(v.id)
        await cb.on_progress(ProgressUpdate(message="Step 1", step=1))
        await cb.on_progress(ProgressUpdate(message="Step 2", step=2))

        loaded = engine.get_venture(v.id)
        assert len(loaded.progress) == 2
        assert loaded.progress[0].message == "Step 1"

    @pytest.mark.asyncio
    async def test_cost_update_accumulates(self, tmp_path):
        engine, _ = _make_engine(tmp_path)
        v = engine.create_venture(title="T", goal="g", exit_condition="e")
        await engine.start_venture(v.id)

        cb = engine._make_callback(v.id)
        await cb.on_cost_update(1000, 0.01)
        await cb.on_cost_update(2000, 0.02)

        loaded = engine.get_venture(v.id)
        assert loaded.total_tokens == 3000
        assert abs(loaded.total_cost_usd - 0.03) < 0.001


# ---------------------------------------------------------------------------
# Completion
# ---------------------------------------------------------------------------


class TestCompletion:
    @pytest.mark.asyncio
    async def test_on_completed_transitions_to_completed(self, tmp_path):
        engine, _ = _make_engine(tmp_path)
        v = engine.create_venture(title="T", goal="g", exit_condition="e")
        await engine.start_venture(v.id)

        cb = engine._make_callback(v.id)
        await cb.on_completed(VentureResult(summary="All done!"))

        loaded = engine.get_venture(v.id)
        assert loaded.state == VentureState.COMPLETED
        assert loaded.result.summary == "All done!"
        assert loaded.completed_at is not None

    @pytest.mark.asyncio
    async def test_on_failed_transitions_to_failed(self, tmp_path):
        engine, _ = _make_engine(tmp_path)
        v = engine.create_venture(title="T", goal="g", exit_condition="e")
        await engine.start_venture(v.id)

        cb = engine._make_callback(v.id)
        await cb.on_failed(VentureError(
            category=FailureCategory.LOGIC,
            message="Can't proceed",
        ))

        loaded = engine.get_venture(v.id)
        assert loaded.state == VentureState.FAILED
        assert "Can't proceed" in loaded.error.message

    @pytest.mark.asyncio
    async def test_on_failed_transient_sets_recoverable(self, tmp_path):
        engine, _ = _make_engine(tmp_path)
        v = engine.create_venture(title="T", goal="g", exit_condition="e")
        await engine.start_venture(v.id)

        cb = engine._make_callback(v.id)
        await cb.on_failed(VentureError(
            category=FailureCategory.TRANSIENT,
            message="Network timeout",
            recoverable=False,  # engine should set this based on retry policy
            retry_count=0,
        ))

        loaded = engine.get_venture(v.id)
        assert loaded.state == VentureState.FAILED


# ---------------------------------------------------------------------------
# Checkpoint
# ---------------------------------------------------------------------------


class TestCheckpointing:
    @pytest.mark.asyncio
    async def test_checkpoint_venture_saves_checkpoint(self, tmp_path):
        engine, executor = _make_engine(tmp_path)
        v = engine.create_venture(title="T", goal="g", exit_condition="e")
        await engine.start_venture(v.id)

        cp = await engine.checkpoint_venture(v.id)
        assert cp is not None
        assert cp.venture_id == v.id
        assert cp.id.startswith("cp_")

    @pytest.mark.asyncio
    async def test_checkpoint_transitions_through_states(self, tmp_path):
        engine, _ = _make_engine(tmp_path)
        v = engine.create_venture(title="T", goal="g", exit_condition="e")
        await engine.start_venture(v.id)

        # Get checkpoint via callback
        cb = engine._make_callback(v.id)
        data = CheckpointData(
            progress_summary="Mid-way",
            executor_state={"step": 5},
        )
        # Process checkpoint through engine internals
        venture = engine.get_venture(v.id)
        cp = await engine._process_checkpoint(
            venture, data, CheckpointReason.MANUAL
        )
        assert cp.progress_summary == "Mid-way"

    @pytest.mark.asyncio
    async def test_checkpoint_without_active_executor_raises(self, tmp_path):
        engine, _ = _make_engine(tmp_path)
        v = engine.create_venture(title="T", goal="g", exit_condition="e")
        # Don't start — no active executor
        with pytest.raises(ExecutorError):
            await engine.checkpoint_venture(v.id)


# ---------------------------------------------------------------------------
# Pause/Resume
# ---------------------------------------------------------------------------


class TestPauseResume:
    @pytest.mark.asyncio
    async def test_pause_transitions_to_paused(self, tmp_path):
        engine, _ = _make_engine(tmp_path)
        v = engine.create_venture(title="T", goal="g", exit_condition="e")
        await engine.start_venture(v.id)
        await engine.pause_venture(v.id)
        loaded = engine.get_venture(v.id)
        assert loaded.state == VentureState.PAUSED

    @pytest.mark.asyncio
    async def test_resume_from_paused(self, tmp_path):
        engine, _ = _make_engine(tmp_path)
        v = engine.create_venture(title="T", goal="g", exit_condition="e")
        await engine.start_venture(v.id)
        await engine.pause_venture(v.id)
        handle = await engine.resume_venture(v.id)
        assert handle is not None
        loaded = engine.get_venture(v.id)
        assert loaded.state == VentureState.RUNNING


# ---------------------------------------------------------------------------
# Abort
# ---------------------------------------------------------------------------


class TestAbort:
    @pytest.mark.asyncio
    async def test_abort_transitions_to_aborted(self, tmp_path):
        engine, _ = _make_engine(tmp_path)
        v = engine.create_venture(title="T", goal="g", exit_condition="e")
        await engine.start_venture(v.id)
        await engine.abort_venture(v.id)
        loaded = engine.get_venture(v.id)
        assert loaded.state == VentureState.ABORTED

    @pytest.mark.asyncio
    async def test_abort_sets_completed_at(self, tmp_path):
        engine, _ = _make_engine(tmp_path)
        v = engine.create_venture(title="T", goal="g", exit_condition="e")
        await engine.start_venture(v.id)
        await engine.abort_venture(v.id)
        loaded = engine.get_venture(v.id)
        assert loaded.completed_at is not None

    @pytest.mark.asyncio
    async def test_abort_queued_venture(self, tmp_path):
        engine, _ = _make_engine(tmp_path)
        v = engine.create_venture(title="T", goal="g", exit_condition="e")
        # Manually set to QUEUED
        from parsica_ventures.state import StateMachine
        sm = StateMachine()
        loaded = engine.get_venture(v.id)
        sm.transition_sync(loaded, VentureState.QUEUED, "test", "user")
        engine.store.save_venture(loaded)
        await engine.abort_venture(v.id)
        result = engine.get_venture(v.id)
        assert result.state == VentureState.ABORTED


# ---------------------------------------------------------------------------
# Full lifecycle
# ---------------------------------------------------------------------------


class TestFullLifecycle:
    @pytest.mark.asyncio
    async def test_create_start_progress_complete(self, tmp_path):
        """Full happy path: create → start → progress → complete."""
        engine, _ = _make_engine(tmp_path)

        # Create
        v = engine.create_venture(
            title="Full Lifecycle Test",
            goal="Test full lifecycle",
            exit_condition="All steps done",
            executor_type="subprocess",
            executor_config={"command": "echo hi"},
        )
        assert v.state == VentureState.CREATED

        # Start
        handle = await engine.start_venture(v.id)
        assert handle is not None
        loaded = engine.get_venture(v.id)
        assert loaded.state == VentureState.RUNNING

        # Progress
        cb = engine._make_callback(v.id)
        await cb.on_progress(ProgressUpdate(message="Step 1", step=1))
        await cb.on_progress(ProgressUpdate(message="Step 2", step=2))
        await cb.on_progress(ProgressUpdate(message="Step 3", step=3))

        loaded = engine.get_venture(v.id)
        assert len(loaded.progress) == 3

        # Cost update
        await cb.on_cost_update(5000, 0.05)
        loaded = engine.get_venture(v.id)
        assert loaded.total_tokens == 5000

        # Complete
        await cb.on_completed(VentureResult(
            summary="All 3 steps completed successfully",
            recommendations=["Cache results for next run"],
        ))

        loaded = engine.get_venture(v.id)
        assert loaded.state == VentureState.COMPLETED
        assert loaded.result.summary == "All 3 steps completed successfully"
        assert loaded.completed_at is not None

    @pytest.mark.asyncio
    async def test_checkpoint_and_resume_cycle(self, tmp_path):
        """Start → checkpoint → verify checkpoint saved → resume runs."""
        engine, _ = _make_engine(tmp_path)

        v = engine.create_venture(
            title="Checkpoint Test",
            goal="test checkpoint resume",
            exit_condition="done",
        )
        await engine.start_venture(v.id)

        cb = engine._make_callback(v.id)

        # Simulate checkpoint needed
        await cb.on_checkpoint_needed(
            reason="context limit approaching",
            state={"summary": "finished step 3", "step": 3},
        )

        # Venture should have gone through checkpoint and back to running (or queued)
        loaded = engine.get_venture(v.id)
        assert loaded.state in (VentureState.RUNNING, VentureState.QUEUED)
        # Should have a checkpoint saved
        cps = engine.store.get_checkpoints(v.id)
        assert len(cps) >= 1

    @pytest.mark.asyncio
    async def test_state_history_recorded(self, tmp_path):
        """State transitions are recorded in the audit log."""
        engine, _ = _make_engine(tmp_path)

        v = engine.create_venture(title="Audit Test", goal="g", exit_condition="e")
        await engine.start_venture(v.id)

        cb = engine._make_callback(v.id)
        await cb.on_completed(VentureResult(summary="done"))

        transitions = engine.store.get_transitions(v.id)
        # Should have: CREATED→QUEUED, QUEUED→RUNNING, RUNNING→COMPLETED
        states = [(t.from_state, t.to_state) for t in transitions]
        assert (VentureState.CREATED, VentureState.QUEUED) in states
        assert (VentureState.QUEUED, VentureState.RUNNING) in states
        assert (VentureState.RUNNING, VentureState.COMPLETED) in states


# ---------------------------------------------------------------------------
# List/Query
# ---------------------------------------------------------------------------


class TestQueryMethods:
    def test_list_all_ventures(self, tmp_path):
        engine, _ = _make_engine(tmp_path)
        for i in range(3):
            engine.create_venture(title=f"V{i}", goal="g", exit_condition="e")
        ventures = engine.list_ventures()
        assert len(ventures) == 3

    def test_list_filter_by_state(self, tmp_path):
        engine, _ = _make_engine(tmp_path)
        engine.create_venture(title="A", goal="g", exit_condition="e")
        engine.create_venture(title="B", goal="g", exit_condition="e")
        created = engine.list_ventures(states=[VentureState.CREATED])
        assert len(created) == 2

    def test_get_nonexistent_raises(self, tmp_path):
        engine, _ = _make_engine(tmp_path)
        with pytest.raises(VentureNotFoundError):
            engine.get_venture("v_doesnotexist")


# ---------------------------------------------------------------------------
# Cost ceiling enforcement via callback
# ---------------------------------------------------------------------------


class TestCostCeilingEnforcement:
    @pytest.mark.asyncio
    async def test_cost_ceiling_triggers_failure(self, tmp_path):
        engine, _ = _make_engine(tmp_path)
        v = engine.create_venture(
            title="Budget Test",
            goal="g",
            exit_condition="e",
            policy=VenturePolicy(max_cost_usd=1.0),
        )
        await engine.start_venture(v.id)

        cb = engine._make_callback(v.id)
        # Exceed the cost ceiling
        await cb.on_cost_update(100000, 5.0)

        loaded = engine.get_venture(v.id)
        assert loaded.state == VentureState.FAILED
        assert loaded.error is not None
        assert loaded.error.category == FailureCategory.POLICY
