"""Tests for parsica_ventures.events — event bus emit/receive, handler errors don't block."""
from __future__ import annotations

import asyncio
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from parsica_ventures.events import EventBus, EventType, VentureEvent


def _make_event(
    event_type: EventType = EventType.PROGRESS,
    venture_id: str = "v_test",
    data: dict | None = None,
) -> VentureEvent:
    return VentureEvent(
        type=event_type,
        venture_id=venture_id,
        data=data or {},
    )


# ---------------------------------------------------------------------------
# EventType enum
# ---------------------------------------------------------------------------


class TestEventType:
    def test_all_event_types_present(self):
        expected_executor = {
            "checkpoint_needed", "approval_needed", "progress",
            "completed", "failed", "cost_update",
        }
        expected_engine = {
            "venture_started", "venture_paused", "venture_resumed",
            "venture_aborted", "checkpoint_saved", "checkpoint_failed",
            "queue_drain",
        }
        actual = {e.value for e in EventType}
        assert expected_executor.issubset(actual)
        assert expected_engine.issubset(actual)

    def test_is_str_enum(self):
        assert isinstance(EventType.PROGRESS, str)
        assert EventType.PROGRESS == "progress"


# ---------------------------------------------------------------------------
# VentureEvent
# ---------------------------------------------------------------------------


class TestVentureEvent:
    def test_creation(self):
        evt = VentureEvent(
            type=EventType.COMPLETED,
            venture_id="v_123",
            data={"result": "done"},
        )
        assert evt.type == EventType.COMPLETED
        assert evt.venture_id == "v_123"
        assert evt.data == {"result": "done"}
        assert evt.timestamp is not None

    def test_default_data_is_empty(self):
        evt = VentureEvent(type=EventType.PROGRESS, venture_id="v_1")
        assert evt.data == {}


# ---------------------------------------------------------------------------
# EventBus basic operations
# ---------------------------------------------------------------------------


class TestEventBusBasic:
    @pytest.mark.asyncio
    async def test_handler_receives_event(self):
        bus = EventBus()
        received = []

        async def handler(event: VentureEvent):
            received.append(event)

        bus.on(EventType.PROGRESS, handler)
        await bus.start()
        await bus.emit(_make_event(EventType.PROGRESS))
        await asyncio.sleep(0.05)
        assert len(received) == 1
        assert received[0].type == EventType.PROGRESS
        await bus.stop()

    @pytest.mark.asyncio
    async def test_handler_only_receives_registered_type(self):
        bus = EventBus()
        received = []

        async def handler(event: VentureEvent):
            received.append(event)

        bus.on(EventType.COMPLETED, handler)
        await bus.start()
        await bus.emit(_make_event(EventType.PROGRESS))    # not subscribed
        await bus.emit(_make_event(EventType.COMPLETED))   # subscribed
        await asyncio.sleep(0.1)
        assert len(received) == 1
        assert received[0].type == EventType.COMPLETED
        await bus.stop()

    @pytest.mark.asyncio
    async def test_multiple_handlers_for_same_type(self):
        bus = EventBus()
        results_a = []
        results_b = []

        async def handler_a(event):
            results_a.append(event.venture_id)

        async def handler_b(event):
            results_b.append(event.venture_id)

        bus.on(EventType.PROGRESS, handler_a)
        bus.on(EventType.PROGRESS, handler_b)
        await bus.start()
        await bus.emit(_make_event(EventType.PROGRESS, "v_abc"))
        await asyncio.sleep(0.05)
        assert results_a == ["v_abc"]
        assert results_b == ["v_abc"]
        await bus.stop()

    @pytest.mark.asyncio
    async def test_global_handler_receives_all_events(self):
        bus = EventBus()
        all_events = []

        async def global_handler(event):
            all_events.append(event.type)

        bus.on_all(global_handler)
        await bus.start()
        await bus.emit(_make_event(EventType.PROGRESS))
        await bus.emit(_make_event(EventType.COMPLETED))
        await bus.emit(_make_event(EventType.FAILED))
        await asyncio.sleep(0.1)
        assert EventType.PROGRESS in all_events
        assert EventType.COMPLETED in all_events
        assert EventType.FAILED in all_events
        await bus.stop()

    @pytest.mark.asyncio
    async def test_emit_multiple_events(self):
        bus = EventBus()
        count = []

        async def handler(event):
            count.append(1)

        bus.on(EventType.PROGRESS, handler)
        await bus.start()
        for i in range(5):
            await bus.emit(_make_event(EventType.PROGRESS, f"v_{i}"))
        await asyncio.sleep(0.1)
        assert len(count) == 5
        await bus.stop()

    @pytest.mark.asyncio
    async def test_event_data_preserved(self):
        bus = EventBus()
        received_data = []

        async def handler(event):
            received_data.append(event.data)

        bus.on(EventType.PROGRESS, handler)
        await bus.start()
        await bus.emit(_make_event(EventType.PROGRESS, data={"step": 3, "msg": "hello"}))
        await asyncio.sleep(0.05)
        assert len(received_data) == 1
        assert received_data[0]["step"] == 3
        await bus.stop()


# ---------------------------------------------------------------------------
# Handler errors don't block
# ---------------------------------------------------------------------------


class TestHandlerErrorIsolation:
    @pytest.mark.asyncio
    async def test_failing_handler_doesnt_block_other_handlers(self):
        bus = EventBus()
        good_received = []

        async def bad_handler(event):
            raise RuntimeError("handler crash!")

        async def good_handler(event):
            good_received.append(event.venture_id)

        bus.on(EventType.PROGRESS, bad_handler)
        bus.on(EventType.PROGRESS, good_handler)
        await bus.start()
        await bus.emit(_make_event(EventType.PROGRESS, "v_good"))
        await asyncio.sleep(0.05)
        # good_handler should have been called despite bad_handler failing
        assert good_received == ["v_good"]
        await bus.stop()

    @pytest.mark.asyncio
    async def test_failing_global_handler_doesnt_block(self):
        bus = EventBus()
        specific_received = []

        async def bad_global(event):
            raise ValueError("global crash")

        async def good_specific(event):
            specific_received.append(event.type)

        bus.on_all(bad_global)
        bus.on(EventType.COMPLETED, good_specific)
        await bus.start()
        await bus.emit(_make_event(EventType.COMPLETED))
        await asyncio.sleep(0.05)
        assert EventType.COMPLETED in specific_received
        await bus.stop()

    @pytest.mark.asyncio
    async def test_multiple_consecutive_events_after_handler_error(self):
        """Bus continues processing events after a handler throws."""
        bus = EventBus()
        received = []
        call_count = [0]

        async def flaky_handler(event):
            call_count[0] += 1
            if call_count[0] == 2:
                raise RuntimeError("flaky error on second call")
            received.append(event.venture_id)

        bus.on(EventType.PROGRESS, flaky_handler)
        await bus.start()
        for v_id in ["v_1", "v_2", "v_3"]:
            await bus.emit(_make_event(EventType.PROGRESS, v_id))
        await asyncio.sleep(0.1)
        # v_1 and v_3 should be received (v_2 caused the error)
        assert "v_1" in received
        assert "v_3" in received
        await bus.stop()


# ---------------------------------------------------------------------------
# Start/stop lifecycle
# ---------------------------------------------------------------------------


class TestEventBusLifecycle:
    @pytest.mark.asyncio
    async def test_start_and_stop(self):
        bus = EventBus()
        await bus.start()
        assert bus._running is True
        await bus.stop()
        assert bus._running is False

    @pytest.mark.asyncio
    async def test_double_start_is_noop(self):
        bus = EventBus()
        await bus.start()
        first_task = bus._task
        await bus.start()  # second start should be noop
        assert bus._task is first_task
        await bus.stop()

    @pytest.mark.asyncio
    async def test_stop_cancels_task(self):
        bus = EventBus()
        await bus.start()
        task = bus._task
        await bus.stop()
        assert task.done() or task.cancelled()

    def test_emit_sync_doesnt_crash_without_loop(self):
        """emit_sync should not crash even when used outside a running loop."""
        bus = EventBus()
        evt = _make_event()
        # Should not raise
        try:
            bus.emit_sync(evt)
        except Exception:
            pass  # Some environments may not have a running loop; that's ok

    @pytest.mark.asyncio
    async def test_emit_sync_with_running_loop(self):
        """emit_sync should enqueue event when loop is running."""
        bus = EventBus()
        received = []

        async def handler(event):
            received.append(event)

        bus.on(EventType.PROGRESS, handler)
        await bus.start()
        bus.emit_sync(_make_event(EventType.PROGRESS))
        await asyncio.sleep(0.05)
        assert len(received) >= 1
        await bus.stop()
