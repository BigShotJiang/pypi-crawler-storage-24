"""Tests for parsica_ventures.secrets — $secret resolution, plaintext detection."""
from __future__ import annotations

import os
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from parsica_ventures.secrets import (
    is_secret_ref,
    resolve_secret,
    resolve_secrets_in_dict,
    check_for_plaintext_secrets,
    strip_secrets_for_storage,
)
from parsica_ventures.exceptions import SecretResolutionError


# ---------------------------------------------------------------------------
# is_secret_ref
# ---------------------------------------------------------------------------


class TestIsSecretRef:
    def test_valid_secret_ref(self):
        assert is_secret_ref({"$secret": "MY_API_KEY"}) is True

    def test_string_is_not_secret_ref(self):
        assert is_secret_ref("sk-abc123") is False

    def test_dict_without_dollar_secret_is_not(self):
        assert is_secret_ref({"key": "value"}) is False

    def test_dict_with_extra_keys_is_not(self):
        assert is_secret_ref({"$secret": "MY_KEY", "extra": "value"}) is False

    def test_none_is_not(self):
        assert is_secret_ref(None) is False

    def test_empty_dict_is_not(self):
        assert is_secret_ref({}) is False

    def test_list_is_not(self):
        assert is_secret_ref(["$secret", "KEY"]) is False


# ---------------------------------------------------------------------------
# resolve_secret
# ---------------------------------------------------------------------------


class TestResolveSecret:
    def test_resolves_from_env(self, monkeypatch):
        monkeypatch.setenv("TEST_API_KEY", "sk-test123")
        result = resolve_secret({"$secret": "TEST_API_KEY"})
        assert result == "sk-test123"

    def test_missing_env_var_raises(self, monkeypatch):
        monkeypatch.delenv("MISSING_SECRET_VARIABLE", raising=False)
        with pytest.raises(SecretResolutionError) as exc_info:
            resolve_secret({"$secret": "MISSING_SECRET_VARIABLE"})
        assert "MISSING_SECRET_VARIABLE" in str(exc_info.value)

    def test_error_contains_var_name(self, monkeypatch):
        monkeypatch.delenv("MY_NONEXISTENT_VAR", raising=False)
        with pytest.raises(SecretResolutionError) as exc_info:
            resolve_secret({"$secret": "MY_NONEXISTENT_VAR"})
        err = exc_info.value
        assert err.env_var == "MY_NONEXISTENT_VAR"

    def test_empty_string_env_var_resolves(self, monkeypatch):
        monkeypatch.setenv("EMPTY_VAR", "")
        result = resolve_secret({"$secret": "EMPTY_VAR"})
        assert result == ""


# ---------------------------------------------------------------------------
# resolve_secrets_in_dict
# ---------------------------------------------------------------------------


class TestResolveSecretsInDict:
    def test_resolves_top_level_secret(self, monkeypatch):
        monkeypatch.setenv("MY_KEY", "secret_value")
        result = resolve_secrets_in_dict({"api_key": {"$secret": "MY_KEY"}})
        assert result["api_key"] == "secret_value"

    def test_preserves_non_secret_values(self, monkeypatch):
        monkeypatch.setenv("MY_KEY", "val")
        d = {"plain": "text", "num": 42, "key": {"$secret": "MY_KEY"}}
        result = resolve_secrets_in_dict(d)
        assert result["plain"] == "text"
        assert result["num"] == 42
        assert result["key"] == "val"

    def test_nested_dict_resolved(self, monkeypatch):
        monkeypatch.setenv("NESTED_KEY", "nested_val")
        d = {
            "executor": {
                "inner": {
                    "api_key": {"$secret": "NESTED_KEY"}
                }
            }
        }
        result = resolve_secrets_in_dict(d)
        assert result["executor"]["inner"]["api_key"] == "nested_val"

    def test_list_values_with_dicts_resolved(self, monkeypatch):
        monkeypatch.setenv("LIST_KEY", "list_val")
        d = {
            "items": [
                {"key": {"$secret": "LIST_KEY"}},
                {"plain": "value"},
            ]
        }
        result = resolve_secrets_in_dict(d)
        assert result["items"][0]["key"] == "list_val"
        assert result["items"][1]["plain"] == "value"

    def test_original_dict_not_modified(self, monkeypatch):
        monkeypatch.setenv("ORIG_KEY", "orig_val")
        original = {"api": {"$secret": "ORIG_KEY"}}
        original_copy = dict(original)
        resolve_secrets_in_dict(original)
        assert original == original_copy

    def test_missing_env_var_raises(self, monkeypatch):
        monkeypatch.delenv("DEFINITELY_MISSING", raising=False)
        with pytest.raises(SecretResolutionError):
            resolve_secrets_in_dict({"key": {"$secret": "DEFINITELY_MISSING"}})

    def test_empty_dict(self):
        assert resolve_secrets_in_dict({}) == {}


# ---------------------------------------------------------------------------
# check_for_plaintext_secrets
# ---------------------------------------------------------------------------


class TestCheckForPlaintextSecrets:
    def test_openai_key_detected(self):
        config = {"api_key": "sk-" + "a" * 48}
        warnings = check_for_plaintext_secrets(config)
        assert len(warnings) >= 1

    def test_anthropic_api_key_detected(self):
        config = {"key": "sk-ant-api03-" + "x" * 30}
        warnings = check_for_plaintext_secrets(config)
        assert len(warnings) >= 1

    def test_anthropic_oauth_detected(self):
        config = {"token": "sk-ant-oat01-" + "y" * 30}
        warnings = check_for_plaintext_secrets(config)
        assert len(warnings) >= 1

    def test_google_api_key_detected(self):
        config = {"key": "AIza" + "B" * 35}
        warnings = check_for_plaintext_secrets(config)
        assert len(warnings) >= 1

    def test_github_pat_detected(self):
        config = {"token": "ghp_" + "z" * 36}
        warnings = check_for_plaintext_secrets(config)
        assert len(warnings) >= 1

    def test_pypi_token_detected(self):
        config = {"token": "pypi-" + "A" * 35}
        warnings = check_for_plaintext_secrets(config)
        assert len(warnings) >= 1

    def test_clean_config_no_warnings(self):
        config = {
            "model": "claude-3-5-sonnet",
            "temperature": 0.7,
            "max_tokens": 4096,
        }
        warnings = check_for_plaintext_secrets(config)
        assert warnings == []

    def test_secret_ref_no_warning(self):
        config = {"api_key": {"$secret": "MY_API_KEY"}}
        warnings = check_for_plaintext_secrets(config)
        assert warnings == []

    def test_nested_secret_detected(self):
        config = {
            "executor": {
                "config": {
                    "api_key": "sk-" + "a" * 48
                }
            }
        }
        warnings = check_for_plaintext_secrets(config)
        assert len(warnings) >= 1

    def test_warning_contains_field_path(self):
        config = {"executor": {"api_key": "sk-" + "a" * 48}}
        warnings = check_for_plaintext_secrets(config)
        assert any("api_key" in w for w in warnings)

    def test_only_one_warning_per_field(self):
        """Even if multiple patterns match, only one warning per field."""
        config = {"key": "sk-ant-api03-" + "x" * 40}  # matches multiple patterns
        warnings = check_for_plaintext_secrets(config)
        # One warning per field max
        assert len([w for w in warnings if "'key'" in w]) <= 1


# ---------------------------------------------------------------------------
# strip_secrets_for_storage
# ---------------------------------------------------------------------------


class TestStripSecretsForStorage:
    def test_secret_refs_pass_through(self):
        d = {"api_key": {"$secret": "MY_KEY"}}
        result = strip_secrets_for_storage(d)
        assert result["api_key"] == {"$secret": "MY_KEY"}

    def test_plain_values_pass_through(self):
        d = {"model": "claude", "max_tokens": 100}
        result = strip_secrets_for_storage(d)
        assert result == d

    def test_returns_same_structure(self):
        d = {
            "command": "echo hello",
            "api_key": {"$secret": "API_KEY"},
        }
        result = strip_secrets_for_storage(d)
        assert "command" in result
        assert "api_key" in result
