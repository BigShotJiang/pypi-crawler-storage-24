"""Tests for graceful degradation when parsica-memory is not installed."""
from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import patch

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from parsica_ventures.memory_bridge import (
    NoopMemoryBridge,
    ParsicaMemoryBridge,
    create_memory_bridge,
    save_memories_backup,
    load_memories_backup,
    _get_parsica_memory,
)


class TestParsicaMemoryUnavailable:
    """All tests simulate parsica-memory not being installed."""

    def test_get_parsica_memory_returns_none_when_missing(self):
        """_get_parsica_memory() returns None when parsica_memory is not importable."""
        import builtins
        original_import = builtins.__import__

        def mock_import(name, *args, **kwargs):
            if name == "parsica_memory":
                raise ImportError("No module named 'parsica_memory'")
            return original_import(name, *args, **kwargs)

        with patch("builtins.__import__", side_effect=mock_import):
            # Need to reload the function to re-execute the import
            result = _get_parsica_memory.__wrapped__() if hasattr(_get_parsica_memory, "__wrapped__") else None

        # Even without patching the internal call, direct unavailability check works
        with patch("parsica_ventures.memory_bridge._get_parsica_memory", return_value=None):
            bridge = create_memory_bridge(enabled=True, store_path="/tmp/test")
        assert isinstance(bridge, NoopMemoryBridge)

    def test_create_bridge_returns_noop_when_pm_none(self):
        with patch("parsica_ventures.memory_bridge._get_parsica_memory", return_value=None):
            bridge = create_memory_bridge(enabled=True)
        assert isinstance(bridge, NoopMemoryBridge)
        assert bridge.available() is False

    def test_noop_bridge_store_finding_graceful(self):
        bridge = NoopMemoryBridge()
        # Should not raise
        result = bridge.store_finding("v_1", "content", "finding")
        assert result is None

    def test_noop_bridge_recall_graceful(self):
        bridge = NoopMemoryBridge()
        result = bridge.recall_for_venture("v_1", query="test query")
        assert result == []

    def test_noop_bridge_export_graceful(self):
        bridge = NoopMemoryBridge()
        result = bridge.export_venture_memories("v_1")
        assert result == []

    def test_parsica_bridge_unavailable_without_pm(self, tmp_path):
        with patch("parsica_ventures.memory_bridge._get_parsica_memory", return_value=None):
            bridge = ParsicaMemoryBridge(store_path=str(tmp_path))
        assert bridge.available() is False

    def test_parsica_bridge_store_finding_returns_none_when_unavailable(self, tmp_path):
        with patch("parsica_ventures.memory_bridge._get_parsica_memory", return_value=None):
            bridge = ParsicaMemoryBridge(store_path=str(tmp_path))
        result = bridge.store_finding("v_1", "test", "finding")
        assert result is None

    def test_parsica_bridge_recall_returns_empty_when_unavailable(self, tmp_path):
        with patch("parsica_ventures.memory_bridge._get_parsica_memory", return_value=None):
            bridge = ParsicaMemoryBridge(store_path=str(tmp_path))
        result = bridge.recall_for_venture("v_1")
        assert result == []

    def test_parsica_bridge_export_returns_empty_when_unavailable(self, tmp_path):
        with patch("parsica_ventures.memory_bridge._get_parsica_memory", return_value=None):
            bridge = ParsicaMemoryBridge(store_path=str(tmp_path))
        result = bridge.export_venture_memories("v_1")
        assert result == []


class TestBackupFallback:
    """Backup JSON is insurance when parsica-memory is unavailable on resume."""

    def test_backup_can_substitute_for_unavailable_pm(self, tmp_path):
        """Load backup returns memories even when parsica-memory is not available."""
        memories = [
            {"id": "m1", "content": "Finding from previous session", "tags": ["ventures/v_1"]},
            {"id": "m2", "content": "Decision: use SQLite", "tags": ["ventures/v_1"]},
        ]
        save_memories_backup(memories, tmp_path)

        # Simulate parsica-memory unavailable
        with patch("parsica_ventures.memory_bridge._get_parsica_memory", return_value=None):
            bridge = NoopMemoryBridge()
            assert bridge.available() is False

        # But backup still loadable
        loaded = load_memories_backup(tmp_path)
        assert len(loaded) == 2
        assert loaded[0]["id"] == "m1"

    def test_backup_survives_pm_crash_gracefully(self, tmp_path):
        """If PM crashes during backup save, existing data isn't corrupted."""
        from unittest.mock import MagicMock
        mock_pm = MagicMock()
        mock_store = MagicMock()
        mock_store.add.return_value = "mem_001"
        mock_pm.MemoryStore.return_value = mock_store

        with patch("parsica_ventures.memory_bridge._get_parsica_memory", return_value=mock_pm):
            bridge = ParsicaMemoryBridge(store_path=str(tmp_path))

        # Write initial backup
        save_memories_backup([{"id": "m1", "content": "initial"}], tmp_path)

        # Simulate PM failure
        mock_store.search.side_effect = RuntimeError("PM crashed")
        results = bridge.recall_for_venture("v_1")
        assert results == []  # graceful empty return

        # Backup still loadable
        loaded = load_memories_backup(tmp_path)
        assert len(loaded) == 1
        assert loaded[0]["id"] == "m1"

    def test_ventures_fully_functional_with_noop_bridge(self, tmp_path):
        """Ventures should work completely without parsica-memory."""
        from parsica_ventures.store import VentureStore
        from parsica_ventures.models import Venture, VentureState

        store = VentureStore(db_path=tmp_path / "test.db")
        venture = Venture(
            title="Test without memory",
            goal="Work without PM",
            exit_condition="done",
            executor_type="subprocess",
        )
        store.save_venture(venture)
        loaded = store.get_venture(venture.id)
        assert loaded is not None
        assert loaded.title == "Test without memory"
        store.close()
