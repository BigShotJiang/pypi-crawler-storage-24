"""Tests for parsica_ventures.store — CRUD, WAL mode, concurrent access."""
from __future__ import annotations

import sys
import sqlite3
import threading
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from parsica_ventures.models import (
    Venture,
    VentureState,
    VenturePolicy,
    Checkpoint,
    CheckpointReason,
    ProgressUpdate,
    StateTransition,
)
from parsica_ventures.store import VentureStore


def _make_venture(
    title="Test",
    state=VentureState.CREATED,
    priority=5,
) -> Venture:
    v = Venture(
        title=title,
        goal="Do a thing",
        exit_condition="Done",
        executor_type="subprocess",
        policy=VenturePolicy(priority=priority),
    )
    v.state = state
    return v


# ---------------------------------------------------------------------------
# Schema / WAL tests
# ---------------------------------------------------------------------------


class TestStoreInit:
    def test_creates_db_file(self, tmp_path):
        db = tmp_path / "v.db"
        store = VentureStore(db_path=db)
        assert db.exists()
        store.close()

    def test_wal_mode_enabled(self, tmp_db):
        store = VentureStore(db_path=tmp_db)
        conn = sqlite3.connect(str(tmp_db))
        row = conn.execute("PRAGMA journal_mode").fetchone()
        conn.close()
        assert row[0].lower() == "wal"
        store.close()

    def test_schema_version_recorded(self, tmp_db):
        store = VentureStore(db_path=tmp_db)
        conn = sqlite3.connect(str(tmp_db))
        row = conn.execute("SELECT MAX(version) FROM schema_version").fetchone()
        conn.close()
        assert row[0] == 2
        store.close()

    def test_all_tables_created(self, tmp_db):
        store = VentureStore(db_path=tmp_db)
        conn = sqlite3.connect(str(tmp_db))
        tables = {
            r[0]
            for r in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            ).fetchall()
        }
        conn.close()
        store.close()
        expected = {"ventures", "checkpoints", "progress_updates", "state_transitions", "deliverables"}
        assert expected.issubset(tables)


# ---------------------------------------------------------------------------
# Venture CRUD
# ---------------------------------------------------------------------------


class TestVentureCRUD:
    def test_save_and_get(self, store):
        v = _make_venture("Alpha")
        store.save_venture(v)
        loaded = store.get_venture(v.id)
        assert loaded is not None
        assert loaded.id == v.id
        assert loaded.title == "Alpha"
        assert loaded.state == VentureState.CREATED

    def test_get_nonexistent_returns_none(self, store):
        assert store.get_venture("v_doesnotexist") is None

    def test_update_existing(self, store):
        v = _make_venture()
        store.save_venture(v)
        v.state = VentureState.QUEUED
        v.title = "Updated"
        store.save_venture(v)
        loaded = store.get_venture(v.id)
        assert loaded.state == VentureState.QUEUED
        assert loaded.title == "Updated"

    def test_delete_venture(self, store):
        v = _make_venture()
        store.save_venture(v)
        assert store.get_venture(v.id) is not None
        result = store.delete_venture(v.id)
        assert result is True
        assert store.get_venture(v.id) is None

    def test_delete_nonexistent_returns_false(self, store):
        result = store.delete_venture("v_nope")
        assert result is False

    def test_list_ventures_empty(self, store):
        assert store.list_ventures() == []

    def test_list_ventures_all(self, store):
        a = _make_venture("A")
        b = _make_venture("B")
        store.save_venture(a)
        store.save_venture(b)
        ventures = store.list_ventures()
        assert len(ventures) == 2

    def test_list_ventures_filter_by_state(self, store):
        a = _make_venture("Running", state=VentureState.RUNNING)
        b = _make_venture("Paused", state=VentureState.PAUSED)
        c = _make_venture("Complete", state=VentureState.COMPLETED)
        store.save_venture(a)
        store.save_venture(b)
        store.save_venture(c)

        running = store.list_ventures(states=[VentureState.RUNNING])
        assert len(running) == 1
        assert running[0].state == VentureState.RUNNING

    def test_list_ventures_multi_state_filter(self, store):
        a = _make_venture("A", state=VentureState.RUNNING)
        b = _make_venture("B", state=VentureState.PAUSED)
        c = _make_venture("C", state=VentureState.COMPLETED)
        store.save_venture(a)
        store.save_venture(b)
        store.save_venture(c)
        active = store.list_ventures(states=[VentureState.RUNNING, VentureState.PAUSED])
        assert len(active) == 2

    def test_list_ventures_limit(self, store):
        for i in range(5):
            store.save_venture(_make_venture(f"Venture {i}"))
        limited = store.list_ventures(limit=3)
        assert len(limited) == 3

    def test_count_by_state(self, store):
        store.save_venture(_make_venture("A", state=VentureState.RUNNING))
        store.save_venture(_make_venture("B", state=VentureState.RUNNING))
        store.save_venture(_make_venture("C", state=VentureState.PAUSED))
        count = store.count_by_state([VentureState.RUNNING])
        assert count == 2

    def test_venture_policy_persists(self, store):
        v = _make_venture(priority=1)
        store.save_venture(v)
        loaded = store.get_venture(v.id)
        assert loaded.policy.priority == 1

    def test_venture_executor_config_persists(self, store):
        v = _make_venture()
        v.executor_config = {"command": "echo hello"}
        store.save_venture(v)
        loaded = store.get_venture(v.id)
        assert loaded.executor_config == {"command": "echo hello"}

    def test_venture_metadata_persists(self, store):
        v = _make_venture()
        v.metadata = {"project": "alpha", "team": "beta"}
        store.save_venture(v)
        loaded = store.get_venture(v.id)
        assert loaded.metadata == {"project": "alpha", "team": "beta"}


# ---------------------------------------------------------------------------
# Checkpoint operations
# ---------------------------------------------------------------------------


class TestCheckpointOperations:
    def test_save_and_get(self, store):
        v = _make_venture()
        store.save_venture(v)
        cp = Checkpoint(
            venture_id=v.id,
            reason=CheckpointReason.MANUAL,
            progress_summary="halfway",
        )
        store.save_checkpoint(cp)
        checkpoints = store.get_checkpoints(v.id)
        assert len(checkpoints) == 1
        assert checkpoints[0].progress_summary == "halfway"

    def test_get_latest_checkpoint(self, store):
        v = _make_venture()
        store.save_venture(v)
        cp1 = Checkpoint(venture_id=v.id, reason=CheckpointReason.MANUAL, progress_summary="first")
        cp2 = Checkpoint(venture_id=v.id, reason=CheckpointReason.CONTEXT_LIMIT, progress_summary="second")
        store.save_checkpoint(cp1)
        store.save_checkpoint(cp2)
        latest = store.get_latest_checkpoint(v.id)
        assert latest is not None
        # Latest should be the one with the most recent timestamp
        # Both are created now, but cp2 is added after cp1
        assert latest.progress_summary in ("first", "second")

    def test_get_latest_no_checkpoints(self, store):
        v = _make_venture()
        store.save_venture(v)
        assert store.get_latest_checkpoint(v.id) is None

    def test_checkpoint_with_next_steps(self, store):
        from parsica_ventures.models import NextStep
        v = _make_venture()
        store.save_venture(v)
        cp = Checkpoint(
            venture_id=v.id,
            reason=CheckpointReason.MANUAL,
            progress_summary="with steps",
            next_steps=[NextStep(description="Do X", type="run_command")],
        )
        store.save_checkpoint(cp)
        loaded = store.get_checkpoints(v.id)
        assert len(loaded) == 1

    def test_delete_venture_cascades_checkpoints(self, store):
        v = _make_venture()
        store.save_venture(v)
        cp = Checkpoint(
            venture_id=v.id,
            reason=CheckpointReason.MANUAL,
            progress_summary="test",
        )
        store.save_checkpoint(cp)
        store.delete_venture(v.id)
        assert store.get_checkpoints(v.id) == []


# ---------------------------------------------------------------------------
# State transition operations
# ---------------------------------------------------------------------------


class TestStateTransitionOperations:
    def test_save_and_get(self, store):
        v = _make_venture()
        store.save_venture(v)
        t = StateTransition(
            from_state=VentureState.CREATED,
            to_state=VentureState.QUEUED,
            reason="start",
            triggered_by="user",
        )
        store.save_transition(v.id, t)
        transitions = store.get_transitions(v.id)
        assert len(transitions) == 1
        assert transitions[0].from_state == VentureState.CREATED
        assert transitions[0].to_state == VentureState.QUEUED
        assert transitions[0].triggered_by == "user"

    def test_multiple_transitions(self, store):
        v = _make_venture()
        store.save_venture(v)
        t1 = StateTransition(from_state=VentureState.CREATED, to_state=VentureState.QUEUED, reason="a", triggered_by="user")
        t2 = StateTransition(from_state=VentureState.QUEUED, to_state=VentureState.RUNNING, reason="b", triggered_by="engine")
        store.save_transition(v.id, t1)
        store.save_transition(v.id, t2)
        transitions = store.get_transitions(v.id)
        assert len(transitions) == 2


# ---------------------------------------------------------------------------
# Progress operations
# ---------------------------------------------------------------------------


class TestProgressOperations:
    def test_save_and_get(self, store):
        v = _make_venture()
        store.save_venture(v)
        pu = ProgressUpdate(message="Step 1 done", step=1)
        store.save_progress(v.id, pu)
        progress = store.get_progress(v.id)
        assert len(progress) == 1
        assert progress[0].message == "Step 1 done"
        assert progress[0].step == 1

    def test_progress_limit(self, store):
        v = _make_venture()
        store.save_venture(v)
        for i in range(10):
            store.save_progress(v.id, ProgressUpdate(message=f"step {i}", step=i))
        limited = store.get_progress(v.id, limit=5)
        assert len(limited) == 5


# ---------------------------------------------------------------------------
# Concurrent access
# ---------------------------------------------------------------------------


class TestConcurrentAccess:
    def test_multiple_threads_can_read(self, tmp_db):
        """Multiple threads can safely read from the store — each with own connection."""
        # First populate
        setup = VentureStore(db_path=tmp_db)
        v = _make_venture()
        setup.save_venture(v)
        setup.close()

        errors = []

        def reader():
            # Each thread opens its own store (SQLite WAL is concurrent-read safe)
            s = VentureStore(db_path=tmp_db)
            try:
                result = s.get_venture(v.id)
                assert result is not None
            except Exception as e:
                errors.append(e)
            finally:
                s.close()

        threads = [threading.Thread(target=reader) for _ in range(8)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert errors == [], f"Concurrent read errors: {errors}"

    def test_sequential_writes_dont_corrupt(self, tmp_db):
        """Sequential writes produce a consistent database."""
        store = VentureStore(db_path=tmp_db)
        ventures = [_make_venture(f"V{i}") for i in range(10)]
        for v in ventures:
            store.save_venture(v)

        all_ventures = store.list_ventures()
        assert len(all_ventures) == 10
        store.close()
