"""Tests for parsica_ventures.models — dataclasses, enums, serialization."""
from __future__ import annotations

import sys
from pathlib import Path
from datetime import datetime, timezone

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from parsica_ventures.models import (
    VentureState,
    FailureCategory,
    DeliverableType,
    CheckpointReason,
    ResourceLimits,
    NextStep,
    FileSnapshot,
    Decision,
    Deliverable,
    ProgressUpdate,
    StateTransition,
    VentureMetrics,
    VentureError,
    VentureResult,
    ExecutorHandle,
    ExecutorHealth,
    CheckpointData,
    Checkpoint,
    VenturePolicy,
    Venture,
)


# ---------------------------------------------------------------------------
# Enum tests
# ---------------------------------------------------------------------------


class TestVentureState:
    def test_all_states_present(self):
        expected = {
            "created", "queued", "running", "checkpoint",
            "checkpoint_failed", "awaiting_approval", "paused",
            "completed", "failed", "aborted",
        }
        actual = {s.value for s in VentureState}
        assert actual == expected

    def test_is_str_enum(self):
        assert isinstance(VentureState.RUNNING, str)
        assert VentureState.RUNNING == "running"

    def test_from_string(self):
        assert VentureState("running") == VentureState.RUNNING
        assert VentureState("completed") == VentureState.COMPLETED

    def test_invalid_string_raises(self):
        with pytest.raises(ValueError):
            VentureState("nonexistent")


class TestFailureCategory:
    def test_all_categories(self):
        expected = {"transient", "crash", "logic", "policy", "checkpoint"}
        actual = {c.value for c in FailureCategory}
        assert actual == expected

    def test_is_str_enum(self):
        assert isinstance(FailureCategory.LOGIC, str)
        assert FailureCategory.LOGIC == "logic"


class TestDeliverableType:
    def test_all_types(self):
        expected = {"file", "pr", "report", "message", "artifact"}
        actual = {t.value for t in DeliverableType}
        assert actual == expected


class TestCheckpointReason:
    def test_all_reasons(self):
        expected = {
            "context_limit", "scheduled", "manual",
            "policy_limit", "cost_limit",
        }
        actual = {r.value for r in CheckpointReason}
        assert actual == expected


# ---------------------------------------------------------------------------
# Sub-model tests
# ---------------------------------------------------------------------------


class TestResourceLimits:
    def test_defaults_are_none(self):
        rl = ResourceLimits()
        assert rl.max_memory_mb is None
        assert rl.max_disk_mb is None

    def test_set_values(self):
        rl = ResourceLimits(max_memory_mb=512, max_disk_mb=1024)
        assert rl.max_memory_mb == 512
        assert rl.max_disk_mb == 1024

    def test_extra_fields_allowed(self):
        rl = ResourceLimits(max_memory_mb=100, custom_field="hello")
        assert rl.custom_field == "hello"  # type: ignore[attr-defined]


class TestNextStep:
    def test_creation_with_defaults(self):
        ns = NextStep(description="Do something", type="run_command")
        assert ns.description == "Do something"
        assert ns.type == "run_command"
        assert ns.priority == 5
        assert ns.depends_on == []
        assert ns.context == {}
        assert ns.id.startswith("ns_")

    def test_id_is_unique(self):
        a = NextStep(description="step a", type="decision")
        b = NextStep(description="step b", type="decision")
        assert a.id != b.id

    def test_all_types_valid(self):
        for t in ["read_file", "run_command", "call_api", "decision", "investigate", "create_artifact"]:
            ns = NextStep(description="x", type=t)
            assert ns.type == t


class TestFileSnapshot:
    def test_basic_creation(self):
        fs = FileSnapshot(path="/some/file.py", checksum="abc123", size=1024)
        assert fs.path == "/some/file.py"
        assert fs.checksum == "abc123"
        assert fs.size == 1024
        assert fs.git_committed is False
        assert fs.inline_content is None

    def test_with_inline_content(self):
        fs = FileSnapshot(
            path="/file.py",
            checksum="sha",
            size=100,
            inline_content="print('hello')",
            git_committed=True,
        )
        assert fs.inline_content == "print('hello')"
        assert fs.git_committed is True


class TestDecision:
    def test_creation(self):
        d = Decision(
            description="Use SQLite",
            reasoning="Simple, no deps",
            alternatives_considered=["Postgres", "DynamoDB"],
            outcome="Implemented with WAL",
        )
        assert d.description == "Use SQLite"
        assert len(d.alternatives_considered) == 2
        assert isinstance(d.timestamp, datetime)


class TestProgressUpdate:
    def test_creation(self):
        pu = ProgressUpdate(message="Step 3 done", step=3)
        assert pu.message == "Step 3 done"
        assert pu.step == 3
        assert pu.metadata == {}

    def test_timestamp_is_utc(self):
        pu = ProgressUpdate(message="test")
        assert pu.timestamp.tzinfo is not None


class TestStateTransition:
    def test_creation(self):
        st = StateTransition(
            from_state=VentureState.CREATED,
            to_state=VentureState.QUEUED,
            reason="test",
            triggered_by="engine",
        )
        assert st.from_state == VentureState.CREATED
        assert st.to_state == VentureState.QUEUED
        assert st.reason == "test"
        assert isinstance(st.timestamp, datetime)


class TestVentureMetrics:
    def test_defaults_are_zero(self):
        m = VentureMetrics()
        assert m.duration_seconds == 0.0
        assert m.total_tokens == 0
        assert m.total_cost_usd == 0.0
        assert m.checkpoint_count == 0
        assert m.context_resets == 0
        assert m.executor_sessions == 0


class TestVentureError:
    def test_creation(self):
        err = VentureError(
            category=FailureCategory.TRANSIENT,
            message="Network timeout",
            recoverable=True,
        )
        assert err.category == FailureCategory.TRANSIENT
        assert err.message == "Network timeout"
        assert err.recoverable is True
        assert err.retry_count == 0

    def test_not_recoverable_by_default(self):
        err = VentureError(category=FailureCategory.LOGIC, message="can't proceed")
        assert err.recoverable is False


class TestVentureResult:
    def test_creation(self):
        res = VentureResult(summary="All done")
        assert res.summary == "All done"
        assert res.deliverables == []
        assert res.memory_ids == []
        assert res.recommendations == []

    def test_with_deliverables(self):
        d = Deliverable(type=DeliverableType.FILE, title="output.py", path="/out.py")
        res = VentureResult(summary="done", deliverables=[d])
        assert len(res.deliverables) == 1
        assert res.deliverables[0].type == DeliverableType.FILE


class TestExecutorHandle:
    def test_creation(self):
        h = ExecutorHandle(executor_id="sub_abc")
        assert h.executor_id == "sub_abc"
        assert h.pid is None
        assert isinstance(h.started_at, datetime)


class TestExecutorHealth:
    def test_alive(self):
        now = datetime.now(timezone.utc)
        h = ExecutorHealth(alive=True, last_activity=now)
        assert h.alive is True
        assert h.tokens_used == 0

    def test_dead_with_error(self):
        now = datetime.now(timezone.utc)
        h = ExecutorHealth(alive=False, last_activity=now, error="process killed")
        assert h.alive is False
        assert h.error == "process killed"


# ---------------------------------------------------------------------------
# CheckpointData / Checkpoint tests
# ---------------------------------------------------------------------------


class TestCheckpointData:
    def test_creation(self):
        cd = CheckpointData(progress_summary="halfway there")
        assert cd.progress_summary == "halfway there"
        assert cd.next_steps == []
        assert cd.files_modified == []
        assert cd.decisions_log == []
        assert cd.executor_state == {}


class TestCheckpoint:
    def test_creation(self):
        cp = Checkpoint(
            venture_id="v_test",
            reason=CheckpointReason.MANUAL,
            progress_summary="saved",
        )
        assert cp.venture_id == "v_test"
        assert cp.reason == CheckpointReason.MANUAL
        assert cp.id.startswith("cp_")

    def test_id_is_unique(self):
        a = Checkpoint(venture_id="v1", reason=CheckpointReason.MANUAL, progress_summary="a")
        b = Checkpoint(venture_id="v1", reason=CheckpointReason.MANUAL, progress_summary="b")
        assert a.id != b.id

    def test_serialization_roundtrip(self):
        cp = Checkpoint(
            venture_id="v_abc",
            reason=CheckpointReason.CONTEXT_LIMIT,
            progress_summary="at 80% context",
            executor_state={"tokens": 8000},
        )
        data = cp.model_dump()
        restored = Checkpoint(**data)
        assert restored.id == cp.id
        assert restored.reason == cp.reason
        assert restored.executor_state == {"tokens": 8000}


# ---------------------------------------------------------------------------
# VenturePolicy tests
# ---------------------------------------------------------------------------


class TestVenturePolicy:
    def test_defaults(self):
        p = VenturePolicy()
        assert p.autonomy == "checkpoints"
        assert p.approval_gates == []
        assert p.gate_timeout_seconds == 300
        assert p.gate_timeout_action == "auto_pause"
        assert p.max_duration_hours is None
        assert p.max_cost_usd is None
        assert p.max_context_resets is None
        assert p.checkpoint_strategy == "token"
        assert p.checkpoint_threshold == 0.80
        assert p.priority == 5

    def test_custom_values(self):
        p = VenturePolicy(
            autonomy="supervised",
            max_cost_usd=10.0,
            max_duration_hours=2.0,
            priority=1,
        )
        assert p.autonomy == "supervised"
        assert p.max_cost_usd == 10.0
        assert p.max_duration_hours == 2.0
        assert p.priority == 1


# ---------------------------------------------------------------------------
# Venture top-level model tests
# ---------------------------------------------------------------------------


class TestVenture:
    def test_creation(self):
        v = Venture(
            title="Test Venture",
            goal="Do something",
            exit_condition="Done",
            executor_type="subprocess",
        )
        assert v.title == "Test Venture"
        assert v.state == VentureState.CREATED
        assert v.id.startswith("v_")
        assert v.checkpoints == []
        assert v.progress == []
        assert v.result is None
        assert v.error is None
        assert v.total_cost_usd == 0.0
        assert v.total_tokens == 0

    def test_id_uniqueness(self):
        a = Venture(title="a", goal="g", exit_condition="e", executor_type="subprocess")
        b = Venture(title="b", goal="g", exit_condition="e", executor_type="subprocess")
        assert a.id != b.id

    def test_created_at_is_utc(self):
        v = Venture(title="t", goal="g", exit_condition="e", executor_type="subprocess")
        assert v.created_at.tzinfo is not None

    def test_serialization_roundtrip(self):
        v = Venture(
            title="Test",
            goal="Goal",
            exit_condition="Done",
            executor_type="subprocess",
            executor_config={"command": "echo hi"},
        )
        data = v.model_dump()
        restored = Venture(**data)
        assert restored.id == v.id
        assert restored.title == v.title
        assert restored.executor_config == {"command": "echo hi"}

    def test_model_dump_includes_policy(self):
        v = Venture(
            title="t",
            goal="g",
            exit_condition="e",
            executor_type="subprocess",
            policy=VenturePolicy(priority=1),
        )
        data = v.model_dump()
        assert data["policy"]["priority"] == 1
