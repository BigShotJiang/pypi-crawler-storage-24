"""Tests for concurrent ventures — 3 ventures running, no DB corruption."""
from __future__ import annotations

import asyncio
import sys
import threading
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from parsica_ventures.models import (
    Venture,
    VentureState,
    VenturePolicy,
    ProgressUpdate,
    StateTransition,
    Checkpoint,
    CheckpointReason,
)
from parsica_ventures.store import VentureStore


def _make_venture(title: str, state: VentureState = VentureState.CREATED) -> Venture:
    v = Venture(
        title=title,
        goal=f"Goal for {title}",
        exit_condition="Done",
        executor_type="subprocess",
    )
    v.state = state
    return v


# ---------------------------------------------------------------------------
# Concurrent DB access (thread safety)
# ---------------------------------------------------------------------------


class TestConcurrentStoreAccess:
    def test_concurrent_saves_no_corruption(self, tmp_db):
        """Multiple threads saving ventures simultaneously — each with own connection."""
        errors = []
        saved_ids = []
        lock = threading.Lock()

        def save_venture(i):
            # Each thread uses its own store (connection) — WAL allows concurrent writers
            s = VentureStore(db_path=tmp_db)
            try:
                v = _make_venture(f"Venture {i}")
                s.save_venture(v)
                with lock:
                    saved_ids.append(v.id)
            except Exception as e:
                with lock:
                    errors.append(e)
            finally:
                s.close()

        threads = [threading.Thread(target=save_venture, args=(i,)) for i in range(5)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert errors == [], f"Errors during concurrent save: {errors}"
        # Verify count with a fresh connection
        verify_store = VentureStore(db_path=tmp_db)
        all_ventures = verify_store.list_ventures()
        verify_store.close()
        assert len(all_ventures) == 5

    def test_concurrent_reads_no_errors(self, tmp_db):
        """Multiple threads reading with own connections should succeed."""
        # First, populate the DB
        setup_store = VentureStore(db_path=tmp_db)
        ventures = [_make_venture(f"V{i}") for i in range(5)]
        for v in ventures:
            setup_store.save_venture(v)
        setup_store.close()

        errors = []

        def read_venture(vid):
            # Each thread opens its own connection
            s = VentureStore(db_path=tmp_db)
            try:
                result = s.get_venture(vid)
                assert result is not None
            except Exception as e:
                errors.append(e)
            finally:
                s.close()

        threads = [threading.Thread(target=read_venture, args=(v.id,)) for v in ventures * 2]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert errors == []

    def test_concurrent_progress_updates(self, tmp_db):
        """Multiple threads writing progress to different ventures with own connections."""
        setup_store = VentureStore(db_path=tmp_db)
        ventures = [_make_venture(f"V{i}", state=VentureState.RUNNING) for i in range(3)]
        for v in ventures:
            setup_store.save_venture(v)
        setup_store.close()

        errors = []

        def write_progress(venture_id, count):
            s = VentureStore(db_path=tmp_db)
            try:
                for i in range(count):
                    s.save_progress(venture_id, ProgressUpdate(
                        message=f"Progress {i} for {venture_id}",
                        step=i,
                    ))
            except Exception as e:
                errors.append(e)
            finally:
                s.close()

        threads = []
        for v in ventures:
            t = threading.Thread(target=write_progress, args=(v.id, 5))
            threads.append(t)

        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert errors == [], f"Progress write errors: {errors}"

        # Verify all progress was saved
        verify_store = VentureStore(db_path=tmp_db)
        for v in ventures:
            progress = verify_store.get_progress(v.id)
            assert len(progress) == 5
        verify_store.close()

    def test_concurrent_state_transitions(self, tmp_db):
        """Multiple threads writing state transitions with own connections."""
        setup_store = VentureStore(db_path=tmp_db)
        ventures = [_make_venture(f"V{i}") for i in range(3)]
        for v in ventures:
            setup_store.save_venture(v)
        setup_store.close()

        errors = []

        def write_transitions(venture_id):
            s = VentureStore(db_path=tmp_db)
            try:
                for _ in range(3):
                    t = StateTransition(
                        from_state=VentureState.CREATED,
                        to_state=VentureState.QUEUED,
                        reason="test",
                        triggered_by="engine",
                    )
                    s.save_transition(venture_id, t)
            except Exception as e:
                errors.append(e)
            finally:
                s.close()

        threads = [threading.Thread(target=write_transitions, args=(v.id,)) for v in ventures]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert errors == [], f"Transition write errors: {errors}"


# ---------------------------------------------------------------------------
# Engine concurrent ventures
# ---------------------------------------------------------------------------


class TestEngineConcurrentVentures:
    @pytest.mark.asyncio
    async def test_three_ventures_run_concurrently(self, engine, store):
        """Create 3 ventures and start them — engine manages slots."""
        v1 = engine.create_venture(
            title="Venture Alpha",
            goal="alpha goal",
            exit_condition="done",
            executor_type="subprocess",
        )
        v2 = engine.create_venture(
            title="Venture Beta",
            goal="beta goal",
            exit_condition="done",
            executor_type="subprocess",
        )
        v3 = engine.create_venture(
            title="Venture Gamma",
            goal="gamma goal",
            exit_condition="done",
            executor_type="subprocess",
        )

        # Start all three
        h1 = await engine.start_venture(v1.id)
        h2 = await engine.start_venture(v2.id)
        h3 = await engine.start_venture(v3.id)

        assert h1.executor_id != h2.executor_id
        assert h2.executor_id != h3.executor_id

        # Verify all are RUNNING
        all_running = engine.list_ventures(states=[VentureState.RUNNING])
        assert len(all_running) == 3

    @pytest.mark.asyncio
    async def test_fourth_venture_stays_queued(self, engine, store):
        """When max_concurrent=3, 4th venture stays QUEUED."""
        engine.config.max_concurrent = 3

        ventures = []
        for i in range(3):
            v = engine.create_venture(
                title=f"Venture {i}",
                goal="goal",
                exit_condition="done",
                executor_type="subprocess",
            )
            ventures.append(v)
            await engine.start_venture(v.id)

        # Fourth venture — should be queued (at capacity)
        v4 = engine.create_venture(
            title="Venture 4",
            goal="goal",
            exit_condition="done",
            executor_type="subprocess",
        )
        try:
            await engine.start_venture(v4.id)
        except Exception:
            pass  # expected — at capacity

        running = engine.list_ventures(states=[VentureState.RUNNING])
        queued = engine.list_ventures(states=[VentureState.QUEUED])
        # At least 3 running or queued+running = 4
        total = len(running) + len(queued)
        assert total >= 4 or len(running) == 3

    @pytest.mark.asyncio
    async def test_ventures_have_distinct_ids(self, engine, store):
        """Every created venture has a unique ID."""
        ids = set()
        for i in range(5):
            v = engine.create_venture(
                title=f"V{i}",
                goal="goal",
                exit_condition="done",
                executor_type="subprocess",
            )
            ids.add(v.id)
        assert len(ids) == 5

    @pytest.mark.asyncio
    async def test_no_db_corruption_after_multiple_ops(self, engine, store):
        """Multiple start/abort/create operations don't corrupt the DB."""
        created = []
        for i in range(5):
            v = engine.create_venture(
                title=f"Venture {i}",
                goal="goal",
                exit_condition="done",
                executor_type="subprocess",
            )
            created.append(v)

        # Start some
        for v in created[:3]:
            try:
                await engine.start_venture(v.id)
            except Exception:
                pass

        # Abort two
        for v in created[:2]:
            try:
                await engine.abort_venture(v.id)
            except Exception:
                pass

        # DB should still return all ventures
        all_ventures = engine.list_ventures()
        assert len(all_ventures) == 5

    @pytest.mark.asyncio
    async def test_progress_updates_dont_interfere(self, engine, store):
        """Progress from one venture doesn't affect another."""
        v1 = engine.create_venture(
            title="V1", goal="g", exit_condition="e", executor_type="subprocess"
        )
        v2 = engine.create_venture(
            title="V2", goal="g", exit_condition="e", executor_type="subprocess"
        )
        await engine.start_venture(v1.id)
        await engine.start_venture(v2.id)

        # Trigger progress on v1 via callback
        cb1 = engine._make_callback(v1.id)
        cb2 = engine._make_callback(v2.id)

        await cb1.on_progress(ProgressUpdate(message="V1 step", step=1))
        await cb2.on_progress(ProgressUpdate(message="V2 step", step=1))

        # Each should only have their own progress
        v1_loaded = engine.get_venture(v1.id)
        v2_loaded = engine.get_venture(v2.id)

        v1_progress = [p.message for p in v1_loaded.progress]
        v2_progress = [p.message for p in v2_loaded.progress]

        assert "V1 step" in v1_progress
        assert "V2 step" in v2_progress
        assert "V2 step" not in v1_progress
        assert "V1 step" not in v2_progress
