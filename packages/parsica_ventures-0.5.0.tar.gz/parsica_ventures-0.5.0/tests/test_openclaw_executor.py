"""Tests for OpenClaw executor — session launch, monitoring, checkpoints, and registry."""
from __future__ import annotations

import asyncio
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from parsica_ventures.executors.openclaw_executor import OpenClawExecutor
from parsica_ventures.models import Checkpoint, NextStep, Venture


class MockCallback:
    def __init__(self):
        self.checkpoints = []
        self.progress = []
        self.completions = []
        self.failures = []
        self.approvals = []
        self.costs = []

    async def on_checkpoint_needed(self, reason, state):
        self.checkpoints.append({"reason": reason, "state": state})

    async def on_progress(self, update):
        self.progress.append(update)

    async def on_completed(self, result):
        self.completions.append(result)

    async def on_failed(self, error):
        self.failures.append(error)

    async def on_approval_needed(self, gate, context):
        self.approvals.append({"gate": gate, "context": context})

    async def on_cost_update(self, tokens, cost):
        self.costs.append({"tokens": tokens, "cost": cost})


class FakeGatewayClient:
    def __init__(self, session_id: str = "sess_123"):
        self.session_id = session_id
        self.spawn_calls = []
        self.pause_calls = []
        self.abort_calls = []
        self.checkpoint_calls = []
        self.list_events_calls = []
        self.status_queue = []
        self.event_queue = []
        self.default_status = {
            "id": session_id,
            "alive": True,
            "completed": False,
            "tokens_used": 0,
            "context_window": 1000,
        }

    async def spawn_session(self, task, metadata):
        self.spawn_calls.append({"task": task, "metadata": metadata})
        return {"id": self.session_id}

    async def get_session(self, session_id):
        assert session_id == self.session_id
        if self.status_queue:
            return self.status_queue.pop(0)
        return dict(self.default_status)

    async def pause_session(self, session_id):
        self.pause_calls.append(session_id)

    async def abort_session(self, session_id):
        self.abort_calls.append(session_id)

    async def checkpoint_session(self, session_id):
        self.checkpoint_calls.append(session_id)
        return {
            "summary": "checkpoint summary",
            "next_steps": [
                {"description": "do the next thing", "type": "investigate", "priority": 3}
            ],
        }

    async def list_session_events(self, session_id, after=None):
        self.list_events_calls.append({"session_id": session_id, "after": after})
        if self.event_queue:
            return self.event_queue.pop(0)
        return []


def _make_venture() -> Venture:
    return Venture(
        title="OpenClaw Test",
        goal="Run an OpenClaw sub-agent session",
        exit_condition="done",
        executor_type="openclaw",
    )


class TestOpenClawExecutor:
    @pytest.mark.asyncio
    async def test_start_spawns_session(self):
        client = FakeGatewayClient()
        executor = OpenClawExecutor(gateway_client=client, poll_interval_seconds=0.01)
        callback = MockCallback()
        venture = _make_venture()

        handle = await executor.start(venture, callback)

        assert handle.session_id == client.session_id
        assert handle.executor_id.startswith("openclaw_")
        assert len(client.spawn_calls) == 1
        await executor.abort(venture)

    @pytest.mark.asyncio
    async def test_start_without_client_raises(self):
        executor = OpenClawExecutor()
        callback = MockCallback()
        venture = _make_venture()

        with pytest.raises(Exception):
            await executor.start(venture, callback)

    @pytest.mark.asyncio
    async def test_monitor_emits_progress_and_cost_updates(self):
        client = FakeGatewayClient()
        client.status_queue = [
            {"id": client.session_id, "alive": True, "completed": False, "tokens_used": 100, "context_window": 1000},
            {"id": client.session_id, "alive": True, "completed": True, "summary": "done", "tokens_used": 150, "cost_usd": 0.25},
        ]
        client.event_queue = [[
            {"id": "e1", "type": "progress", "message": "step complete", "step": 1, "tokens_delta": 50, "cost_delta": 0.1}
        ]]
        executor = OpenClawExecutor(gateway_client=client, poll_interval_seconds=0.01)
        callback = MockCallback()
        venture = _make_venture()

        await executor.start(venture, callback)
        await asyncio.wait_for(executor._monitor_task, timeout=1.0)

        assert len(callback.progress) == 1
        assert callback.progress[0].message == "step complete"
        assert callback.costs[0]["tokens"] == 50
        assert len(callback.completions) == 1
        assert callback.completions[0].summary == "done"

    @pytest.mark.asyncio
    async def test_monitor_emits_context_checkpoint(self):
        client = FakeGatewayClient()
        client.status_queue = [
            {"id": client.session_id, "alive": True, "completed": False, "tokens_used": 850, "context_window": 1000, "summary": "near limit"},
            {"id": client.session_id, "alive": True, "completed": True, "summary": "done"},
        ]
        executor = OpenClawExecutor(gateway_client=client, poll_interval_seconds=0.01, checkpoint_threshold=0.8)
        callback = MockCallback()
        venture = _make_venture()

        await executor.start(venture, callback)
        await asyncio.wait_for(executor._monitor_task, timeout=1.0)

        assert any(c["reason"] == "context_limit" for c in callback.checkpoints)

    @pytest.mark.asyncio
    async def test_monitor_emits_agent_requested_checkpoint(self):
        client = FakeGatewayClient()
        client.status_queue = [
            {
                "id": client.session_id,
                "alive": True,
                "completed": False,
                "checkpoint_requested": True,
                "checkpoint_request_id": "cp-1",
                "summary": "save now",
                "next_steps": [{"description": "continue", "type": "investigate", "priority": 4}],
            },
            {"id": client.session_id, "alive": True, "completed": True, "summary": "done"},
        ]
        executor = OpenClawExecutor(gateway_client=client, poll_interval_seconds=0.01)
        callback = MockCallback()
        venture = _make_venture()

        await executor.start(venture, callback)
        await asyncio.wait_for(executor._monitor_task, timeout=1.0)

        assert any(c["reason"] == "agent_requested" for c in callback.checkpoints)

    @pytest.mark.asyncio
    async def test_monitor_emits_failure_on_crash(self):
        client = FakeGatewayClient()
        client.status_queue = [
            {"id": client.session_id, "alive": False, "completed": False, "error": "session crashed"}
        ]
        executor = OpenClawExecutor(gateway_client=client, poll_interval_seconds=0.01)
        callback = MockCallback()
        venture = _make_venture()

        await executor.start(venture, callback)
        await asyncio.wait_for(executor._monitor_task, timeout=1.0)

        assert len(callback.failures) == 1
        assert callback.failures[0].message == "session crashed"

    @pytest.mark.asyncio
    async def test_checkpoint_returns_checkpoint_data(self):
        client = FakeGatewayClient()
        executor = OpenClawExecutor(gateway_client=client, poll_interval_seconds=0.01)
        callback = MockCallback()
        venture = _make_venture()

        await executor.start(venture, callback)
        data = await executor.checkpoint(venture)

        assert data.progress_summary == "checkpoint summary"
        assert data.next_steps[0].description == "do the next thing"
        await executor.abort(venture)

    @pytest.mark.asyncio
    async def test_resume_spawns_new_session_with_checkpoint_context(self):
        client = FakeGatewayClient(session_id="sess_resume")
        executor = OpenClawExecutor(gateway_client=client, poll_interval_seconds=0.01)
        callback = MockCallback()
        venture = _make_venture()
        checkpoint = Checkpoint(
            venture_id=venture.id,
            reason="manual",
            progress_summary="resume from here",
            next_steps=[NextStep(description="finish it", type="investigate", priority=2)],
        )

        handle = await executor.resume(venture, checkpoint, callback)

        assert handle.session_id == "sess_resume"
        assert len(client.spawn_calls) == 1
        assert "resume" in client.spawn_calls[0]["task"].lower()
        await executor.abort(venture)

    @pytest.mark.asyncio
    async def test_pause_and_abort_delegate_to_client(self):
        client = FakeGatewayClient()
        executor = OpenClawExecutor(gateway_client=client, poll_interval_seconds=0.01)
        callback = MockCallback()
        venture = _make_venture()

        await executor.start(venture, callback)
        await executor.pause(venture)
        await executor.abort(venture)

        assert client.pause_calls == [client.session_id]
        assert client.abort_calls == [client.session_id]

    @pytest.mark.asyncio
    async def test_health_reflects_gateway_status(self):
        client = FakeGatewayClient()
        client.status_queue = [
            {"id": client.session_id, "alive": True, "completed": False, "tokens_used": 321, "cost_usd": 0.42}
        ]
        executor = OpenClawExecutor(gateway_client=client, poll_interval_seconds=0.01)
        callback = MockCallback()
        venture = _make_venture()

        await executor.start(venture, callback)
        health = await executor.health(venture)

        assert health.alive is True
        assert health.tokens_used == 321
        assert health.cost_usd == 0.42
        await executor.abort(venture)


class TestRegistryRegistration:
    def test_openclaw_registered(self):
        from parsica_ventures.executor import registry
        assert registry.is_registered("openclaw")

    def test_openclaw_creates_instance(self):
        from parsica_ventures.executor import registry
        executor = registry.create("openclaw", gateway_client=FakeGatewayClient())
        assert isinstance(executor, OpenClawExecutor)
