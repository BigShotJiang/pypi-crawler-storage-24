"""Tests for parsica_ventures.policy — cost, duration, context resets, retry policy."""
from __future__ import annotations

import sys
from datetime import datetime, timezone, timedelta
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from parsica_ventures.models import (
    Venture,
    VenturePolicy,
    VentureError,
    VentureState,
    FailureCategory,
    Checkpoint,
    CheckpointReason,
)
from parsica_ventures.policy import PolicyEngine


def _make_venture(policy: VenturePolicy | None = None) -> Venture:
    v = Venture(
        title="Test",
        goal="Do something",
        exit_condition="Done",
        executor_type="subprocess",
        policy=policy or VenturePolicy(),
    )
    return v


# ---------------------------------------------------------------------------
# Cost ceiling checks
# ---------------------------------------------------------------------------


class TestCheckCost:
    def test_no_limit_returns_none(self):
        engine = PolicyEngine()
        v = _make_venture(VenturePolicy(max_cost_usd=None))
        v.total_cost_usd = 999.0
        assert engine.check_cost(v) is None

    def test_under_limit_returns_none(self):
        engine = PolicyEngine()
        v = _make_venture(VenturePolicy(max_cost_usd=10.0))
        v.total_cost_usd = 9.99
        assert engine.check_cost(v) is None

    def test_at_limit_returns_none(self):
        engine = PolicyEngine()
        v = _make_venture(VenturePolicy(max_cost_usd=10.0))
        v.total_cost_usd = 10.0
        assert engine.check_cost(v) is None

    def test_over_limit_returns_error(self):
        engine = PolicyEngine()
        v = _make_venture(VenturePolicy(max_cost_usd=10.0))
        v.total_cost_usd = 10.01
        err = engine.check_cost(v)
        assert err is not None
        assert err.category == FailureCategory.POLICY
        assert "cost" in err.message.lower()
        assert err.recoverable is False

    def test_far_over_limit_returns_error(self):
        engine = PolicyEngine()
        v = _make_venture(VenturePolicy(max_cost_usd=5.0))
        v.total_cost_usd = 100.0
        err = engine.check_cost(v)
        assert err is not None
        assert "100" in err.message or "5" in err.message


# ---------------------------------------------------------------------------
# Duration limit checks
# ---------------------------------------------------------------------------


class TestCheckDuration:
    def test_no_limit_returns_none(self):
        engine = PolicyEngine()
        v = _make_venture(VenturePolicy(max_duration_hours=None))
        v.started_at = datetime.now(timezone.utc) - timedelta(hours=100)
        assert engine.check_duration(v) is None

    def test_no_started_at_returns_none(self):
        engine = PolicyEngine()
        v = _make_venture(VenturePolicy(max_duration_hours=1.0))
        v.started_at = None
        assert engine.check_duration(v) is None

    def test_under_limit_returns_none(self):
        engine = PolicyEngine()
        v = _make_venture(VenturePolicy(max_duration_hours=2.0))
        v.started_at = datetime.now(timezone.utc) - timedelta(hours=1)
        assert engine.check_duration(v) is None

    def test_over_limit_returns_error(self):
        engine = PolicyEngine()
        v = _make_venture(VenturePolicy(max_duration_hours=1.0))
        v.started_at = datetime.now(timezone.utc) - timedelta(hours=2)
        err = engine.check_duration(v)
        assert err is not None
        assert err.category == FailureCategory.POLICY
        assert "duration" in err.message.lower()
        assert err.recoverable is False

    def test_just_over_limit(self):
        engine = PolicyEngine()
        v = _make_venture(VenturePolicy(max_duration_hours=0.5))
        v.started_at = datetime.now(timezone.utc) - timedelta(minutes=31)
        err = engine.check_duration(v)
        assert err is not None


# ---------------------------------------------------------------------------
# Context reset checks
# ---------------------------------------------------------------------------


class TestCheckContextResets:
    def test_no_limit_returns_none(self):
        engine = PolicyEngine()
        v = _make_venture(VenturePolicy(max_context_resets=None))
        for i in range(100):
            v.checkpoints.append(
                Checkpoint(venture_id=v.id, reason=CheckpointReason.MANUAL, progress_summary=f"cp{i}")
            )
        assert engine.check_context_resets(v) is None

    def test_under_limit_returns_none(self):
        engine = PolicyEngine()
        v = _make_venture(VenturePolicy(max_context_resets=5))
        for i in range(4):
            v.checkpoints.append(
                Checkpoint(venture_id=v.id, reason=CheckpointReason.MANUAL, progress_summary=f"cp{i}")
            )
        assert engine.check_context_resets(v) is None

    def test_at_limit_returns_none(self):
        engine = PolicyEngine()
        v = _make_venture(VenturePolicy(max_context_resets=3))
        for i in range(3):
            v.checkpoints.append(
                Checkpoint(venture_id=v.id, reason=CheckpointReason.MANUAL, progress_summary=f"cp{i}")
            )
        assert engine.check_context_resets(v) is None

    def test_over_limit_returns_error(self):
        engine = PolicyEngine()
        v = _make_venture(VenturePolicy(max_context_resets=2))
        for i in range(3):  # 3 > 2
            v.checkpoints.append(
                Checkpoint(venture_id=v.id, reason=CheckpointReason.MANUAL, progress_summary=f"cp{i}")
            )
        err = engine.check_context_resets(v)
        assert err is not None
        assert err.category == FailureCategory.POLICY
        assert "context" in err.message.lower() or "reset" in err.message.lower()
        assert err.recoverable is False


# ---------------------------------------------------------------------------
# check_all
# ---------------------------------------------------------------------------


class TestCheckAll:
    def test_all_ok_returns_none(self):
        engine = PolicyEngine()
        v = _make_venture(VenturePolicy(max_cost_usd=100.0, max_duration_hours=10.0))
        v.total_cost_usd = 1.0
        v.started_at = datetime.now(timezone.utc) - timedelta(minutes=5)
        assert engine.check_all(v) is None

    def test_first_violation_returned(self):
        engine = PolicyEngine()
        v = _make_venture(VenturePolicy(max_cost_usd=1.0, max_duration_hours=100.0))
        v.total_cost_usd = 999.0  # cost violation
        v.started_at = datetime.now(timezone.utc) - timedelta(minutes=1)
        err = engine.check_all(v)
        assert err is not None
        assert err.category == FailureCategory.POLICY


# ---------------------------------------------------------------------------
# should_checkpoint
# ---------------------------------------------------------------------------


class TestShouldCheckpoint:
    def test_token_strategy_at_threshold(self):
        engine = PolicyEngine()
        v = _make_venture(VenturePolicy(
            checkpoint_strategy="token",
            checkpoint_threshold=0.80,
        ))
        # 80% of 100000 = 80000
        assert engine.should_checkpoint(v, tokens_used=80000, context_window=100000) is True

    def test_token_strategy_below_threshold(self):
        engine = PolicyEngine()
        v = _make_venture(VenturePolicy(
            checkpoint_strategy="token",
            checkpoint_threshold=0.80,
        ))
        assert engine.should_checkpoint(v, tokens_used=79000, context_window=100000) is False

    def test_non_token_strategy_returns_false(self):
        engine = PolicyEngine()
        v = _make_venture(VenturePolicy(checkpoint_strategy="time"))
        assert engine.should_checkpoint(v, tokens_used=90000, context_window=100000) is False

    def test_zero_context_window_returns_false(self):
        engine = PolicyEngine()
        v = _make_venture(VenturePolicy(checkpoint_strategy="token"))
        assert engine.should_checkpoint(v, tokens_used=100, context_window=0) is False


# ---------------------------------------------------------------------------
# needs_approval
# ---------------------------------------------------------------------------


class TestNeedsApproval:
    def test_full_autonomy_never_needs_approval(self):
        engine = PolicyEngine()
        v = _make_venture(VenturePolicy(
            autonomy="full",
            approval_gates=["git_push", "deploy"],
        ))
        assert engine.needs_approval(v, "git_push") is False
        assert engine.needs_approval(v, "deploy") is False
        assert engine.needs_approval(v, "anything") is False

    def test_supervised_always_needs_approval(self):
        engine = PolicyEngine()
        v = _make_venture(VenturePolicy(autonomy="supervised"))
        assert engine.needs_approval(v, "random_action") is True

    def test_checkpoints_mode_only_gate_actions(self):
        engine = PolicyEngine()
        v = _make_venture(VenturePolicy(
            autonomy="checkpoints",
            approval_gates=["git_push"],
        ))
        assert engine.needs_approval(v, "git_push") is True
        assert engine.needs_approval(v, "read_file") is False

    def test_checkpoints_mode_unlisted_action_no_approval(self):
        engine = PolicyEngine()
        v = _make_venture(VenturePolicy(
            autonomy="checkpoints",
            approval_gates=["deploy"],
        ))
        assert engine.needs_approval(v, "write_file") is False


# ---------------------------------------------------------------------------
# Retry policy
# ---------------------------------------------------------------------------


class TestRetryPolicy:
    def test_transient_retries_3_times(self):
        engine = PolicyEngine()
        err = VentureError(category=FailureCategory.TRANSIENT, message="timeout")
        policy = engine.get_retry_policy(err)
        assert policy["max_retries"] == 3
        assert len(policy["backoff_seconds"]) == 3

    def test_crash_retries_once(self):
        engine = PolicyEngine()
        err = VentureError(category=FailureCategory.CRASH, message="died")
        policy = engine.get_retry_policy(err)
        assert policy["max_retries"] == 1

    def test_logic_not_retryable(self):
        engine = PolicyEngine()
        err = VentureError(category=FailureCategory.LOGIC, message="can't proceed")
        policy = engine.get_retry_policy(err)
        assert policy["max_retries"] == 0
        assert policy["backoff_seconds"] == []

    def test_policy_not_retryable(self):
        engine = PolicyEngine()
        err = VentureError(category=FailureCategory.POLICY, message="limit exceeded")
        policy = engine.get_retry_policy(err)
        assert policy["max_retries"] == 0

    def test_checkpoint_retries_3_times(self):
        engine = PolicyEngine()
        err = VentureError(category=FailureCategory.CHECKPOINT, message="disk full")
        policy = engine.get_retry_policy(err)
        assert policy["max_retries"] == 3

    def test_can_retry_recoverable_transient(self):
        engine = PolicyEngine()
        err = VentureError(
            category=FailureCategory.TRANSIENT,
            message="timeout",
            recoverable=True,
            retry_count=0,
        )
        assert engine.can_retry(err) is True

    def test_cannot_retry_logic_failure(self):
        engine = PolicyEngine()
        err = VentureError(
            category=FailureCategory.LOGIC,
            message="can't proceed",
            recoverable=False,
        )
        assert engine.can_retry(err) is False

    def test_cannot_retry_when_max_retries_exceeded(self):
        engine = PolicyEngine()
        err = VentureError(
            category=FailureCategory.TRANSIENT,
            message="timeout",
            recoverable=True,
            retry_count=3,  # max_retries is also 3
        )
        assert engine.can_retry(err) is False

    def test_cannot_retry_non_recoverable(self):
        engine = PolicyEngine()
        err = VentureError(
            category=FailureCategory.TRANSIENT,
            message="timeout",
            recoverable=False,
            retry_count=0,
        )
        assert engine.can_retry(err) is False
