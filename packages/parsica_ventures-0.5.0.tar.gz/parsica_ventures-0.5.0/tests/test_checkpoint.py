"""Tests for parsica_ventures.checkpoint — atomic writes, load, file snapshots."""
from __future__ import annotations

import hashlib
import json
import os
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from parsica_ventures.models import (
    Checkpoint,
    CheckpointData,
    CheckpointReason,
    NextStep,
    FileSnapshot,
    Decision,
)
from parsica_ventures.checkpoint import (
    compute_file_checksum,
    snapshot_file,
    create_checkpoint,
    save_checkpoint_atomic,
    load_checkpoint,
    verify_file_integrity,
    INLINE_SIZE_THRESHOLD,
)
from parsica_ventures.exceptions import CheckpointError
from parsica_ventures.exceptions import CheckpointCorruptedError, CheckpointError


# ---------------------------------------------------------------------------
# compute_file_checksum
# ---------------------------------------------------------------------------


class TestComputeFileChecksum:
    def test_known_content(self, tmp_path):
        f = tmp_path / "test.txt"
        f.write_bytes(b"hello world")
        expected = hashlib.sha256(b"hello world").hexdigest()
        assert compute_file_checksum(f) == expected

    def test_empty_file(self, tmp_path):
        f = tmp_path / "empty.txt"
        f.write_bytes(b"")
        expected = hashlib.sha256(b"").hexdigest()
        assert compute_file_checksum(f) == expected

    def test_same_content_same_checksum(self, tmp_path):
        a = tmp_path / "a.txt"
        b = tmp_path / "b.txt"
        a.write_bytes(b"same content")
        b.write_bytes(b"same content")
        assert compute_file_checksum(a) == compute_file_checksum(b)

    def test_different_content_different_checksum(self, tmp_path):
        a = tmp_path / "a.txt"
        b = tmp_path / "b.txt"
        a.write_bytes(b"content A")
        b.write_bytes(b"content B")
        assert compute_file_checksum(a) != compute_file_checksum(b)


# ---------------------------------------------------------------------------
# snapshot_file
# ---------------------------------------------------------------------------


class TestSnapshotFile:
    def test_small_file_includes_inline(self, tmp_path):
        f = tmp_path / "small.py"
        f.write_text("x = 1\n")
        snap = snapshot_file(f)
        assert snap.path == str(f)
        assert len(snap.checksum) == 64  # sha256 hex
        assert snap.size > 0
        assert snap.inline_content == "x = 1\n"

    def test_large_file_no_inline(self, tmp_path):
        f = tmp_path / "large.bin"
        content = b"x" * (INLINE_SIZE_THRESHOLD + 100)
        f.write_bytes(content)
        snap = snapshot_file(f)
        assert snap.inline_content is None
        assert snap.size == len(content)

    def test_nonexistent_file(self, tmp_path):
        f = tmp_path / "missing.py"
        snap = snapshot_file(f)
        assert snap.checksum == ""
        assert snap.size == 0
        assert snap.inline_content is None

    def test_returns_file_snapshot_type(self, tmp_path):
        f = tmp_path / "test.txt"
        f.write_text("hello")
        snap = snapshot_file(f)
        assert isinstance(snap, FileSnapshot)


# ---------------------------------------------------------------------------
# create_checkpoint
# ---------------------------------------------------------------------------


class TestCreateCheckpoint:
    def test_wraps_checkpoint_data(self):
        data = CheckpointData(
            progress_summary="Halfway through",
            next_steps=[NextStep(description="Run tests", type="run_command")],
            executor_state={"step": 5},
        )
        cp = create_checkpoint(
            venture_id="v_abc",
            data=data,
            reason=CheckpointReason.MANUAL,
            memory_ids=["mem_1", "mem_2"],
        )
        assert cp.venture_id == "v_abc"
        assert cp.reason == CheckpointReason.MANUAL
        assert cp.progress_summary == "Halfway through"
        assert len(cp.next_steps) == 1
        assert cp.memory_ids == ["mem_1", "mem_2"]
        assert cp.executor_state == {"step": 5}

    def test_no_memory_ids_defaults_empty(self):
        data = CheckpointData(progress_summary="test")
        cp = create_checkpoint("v_x", data, CheckpointReason.CONTEXT_LIMIT)
        assert cp.memory_ids == []

    def test_auto_generates_id(self):
        data = CheckpointData(progress_summary="test")
        cp = create_checkpoint("v_1", data, CheckpointReason.MANUAL)
        assert cp.id.startswith("cp_")

    def test_id_is_unique(self):
        data = CheckpointData(progress_summary="test")
        cp1 = create_checkpoint("v_1", data, CheckpointReason.MANUAL)
        cp2 = create_checkpoint("v_1", data, CheckpointReason.MANUAL)
        assert cp1.id != cp2.id


# ---------------------------------------------------------------------------
# save_checkpoint_atomic + load_checkpoint
# ---------------------------------------------------------------------------


class TestAtomicSave:
    def test_creates_file(self, tmp_path):
        cp = Checkpoint(
            venture_id="v_test",
            reason=CheckpointReason.MANUAL,
            progress_summary="Test checkpoint",
        )
        path = save_checkpoint_atomic(cp, tmp_path)
        assert path.exists()

    def test_file_path_structure(self, tmp_path):
        cp = Checkpoint(
            venture_id="v_test",
            reason=CheckpointReason.MANUAL,
            progress_summary="Test",
        )
        path = save_checkpoint_atomic(cp, tmp_path)
        # Should be: base_dir / venture_id / checkpoint_<id>.json
        assert path.parent.name == "v_test"
        assert path.name.startswith("checkpoint_cp_")
        assert path.suffix == ".json"

    def test_file_is_valid_json(self, tmp_path):
        cp = Checkpoint(
            venture_id="v_abc",
            reason=CheckpointReason.CONTEXT_LIMIT,
            progress_summary="At context limit",
            executor_state={"tokens": 8000},
        )
        path = save_checkpoint_atomic(cp, tmp_path)
        with open(path) as f:
            data = json.load(f)
        assert data["venture_id"] == "v_abc"
        assert data["progress_summary"] == "At context limit"

    def test_no_temp_files_left(self, tmp_path):
        cp = Checkpoint(
            venture_id="v_clean",
            reason=CheckpointReason.MANUAL,
            progress_summary="Clean",
        )
        save_checkpoint_atomic(cp, tmp_path)
        venture_dir = tmp_path / "v_clean"
        temp_files = list(venture_dir.glob(".checkpoint_tmp_*"))
        assert temp_files == []

    def test_creates_parent_dirs(self, tmp_path):
        nested = tmp_path / "deep" / "nested"
        cp = Checkpoint(
            venture_id="v_deep",
            reason=CheckpointReason.MANUAL,
            progress_summary="deep",
        )
        path = save_checkpoint_atomic(cp, nested)
        assert path.exists()

    def test_rejects_path_traversal_in_venture_id(self, tmp_path):
        cp = Checkpoint(
            venture_id="../../escaped_dir",
            reason=CheckpointReason.MANUAL,
            progress_summary="bad path",
        )
        with pytest.raises(CheckpointError):
            save_checkpoint_atomic(cp, tmp_path)


class TestLoadCheckpoint:
    def test_roundtrip(self, tmp_path):
        cp = Checkpoint(
            venture_id="v_round",
            reason=CheckpointReason.MANUAL,
            progress_summary="roundtrip test",
            executor_state={"x": 42, "y": "hello"},
        )
        path = save_checkpoint_atomic(cp, tmp_path)
        loaded = load_checkpoint(path)
        assert loaded.id == cp.id
        assert loaded.venture_id == "v_round"
        assert loaded.progress_summary == "roundtrip test"
        assert loaded.executor_state["x"] == 42

    def test_load_nonexistent_raises(self, tmp_path):
        with pytest.raises((CheckpointCorruptedError, FileNotFoundError, Exception)):
            load_checkpoint(tmp_path / "nope.json")

    def test_load_corrupted_raises(self, tmp_path):
        bad_file = tmp_path / "bad.json"
        bad_file.write_text("not valid json {{{")
        with pytest.raises(CheckpointCorruptedError):
            load_checkpoint(bad_file)

    def test_load_invalid_model_raises(self, tmp_path):
        """A valid JSON but missing required fields should raise."""
        bad_file = tmp_path / "bad_model.json"
        bad_file.write_text('{"some": "data", "not": "a checkpoint"}')
        with pytest.raises(CheckpointCorruptedError):
            load_checkpoint(bad_file)

    def test_checkpoint_with_next_steps(self, tmp_path):
        cp = Checkpoint(
            venture_id="v_steps",
            reason=CheckpointReason.MANUAL,
            progress_summary="with steps",
            next_steps=[
                NextStep(description="Step A", type="run_command"),
                NextStep(description="Step B", type="decision"),
            ],
        )
        path = save_checkpoint_atomic(cp, tmp_path)
        loaded = load_checkpoint(path)
        assert len(loaded.next_steps) == 2
        assert loaded.next_steps[0].description == "Step A"


# ---------------------------------------------------------------------------
# verify_file_integrity
# ---------------------------------------------------------------------------


class TestVerifyFileIntegrity:
    def test_no_issues_when_files_match(self, tmp_path):
        f = tmp_path / "check.py"
        f.write_text("x = 1")
        snap = snapshot_file(f)
        issues = verify_file_integrity([snap])
        assert issues == []

    def test_detects_modified_file(self, tmp_path):
        f = tmp_path / "check.py"
        f.write_text("original content")
        snap = snapshot_file(f)  # checkpoint time
        f.write_text("modified content")  # file changed
        issues = verify_file_integrity([snap])
        assert len(issues) == 1
        assert "checksum_mismatch" in issues[0][1]

    def test_detects_missing_file(self, tmp_path):
        f = tmp_path / "missing.py"
        f.write_text("will be deleted")
        snap = snapshot_file(f)
        f.unlink()
        issues = verify_file_integrity([snap])
        assert len(issues) == 1
        assert "file_missing" in issues[0][1]

    def test_empty_snapshot_list(self):
        assert verify_file_integrity([]) == []

    def test_multiple_files_all_ok(self, tmp_path):
        files = []
        snaps = []
        for i in range(3):
            f = tmp_path / f"file{i}.txt"
            f.write_text(f"content {i}")
            files.append(f)
            snaps.append(snapshot_file(f))
        issues = verify_file_integrity(snaps)
        assert issues == []
