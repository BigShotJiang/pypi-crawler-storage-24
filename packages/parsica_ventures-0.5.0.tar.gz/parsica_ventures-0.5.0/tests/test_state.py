"""Tests for parsica_ventures.state — state machine transitions."""
from __future__ import annotations

import asyncio
import sys
from pathlib import Path

import pytest
import pytest_asyncio

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from parsica_ventures.models import Venture, VentureState, VenturePolicy
from parsica_ventures.state import (
    StateMachine,
    VALID_TRANSITIONS,
    TERMINAL_STATES,
    ACTIVE_STATES,
    is_valid_transition,
    validate_transition,
)
from parsica_ventures.exceptions import InvalidStateTransitionError


# ---------------------------------------------------------------------------
# Pure function tests
# ---------------------------------------------------------------------------


class TestIsValidTransition:
    def test_created_to_queued(self):
        assert is_valid_transition(VentureState.CREATED, VentureState.QUEUED) is True

    def test_created_to_failed(self):
        assert is_valid_transition(VentureState.CREATED, VentureState.FAILED) is True

    def test_queued_to_running(self):
        assert is_valid_transition(VentureState.QUEUED, VentureState.RUNNING) is True

    def test_queued_to_aborted(self):
        assert is_valid_transition(VentureState.QUEUED, VentureState.ABORTED) is True

    def test_running_to_checkpoint(self):
        assert is_valid_transition(VentureState.RUNNING, VentureState.CHECKPOINT) is True

    def test_running_to_paused(self):
        assert is_valid_transition(VentureState.RUNNING, VentureState.PAUSED) is True

    def test_running_to_completed(self):
        assert is_valid_transition(VentureState.RUNNING, VentureState.COMPLETED) is True

    def test_running_to_failed(self):
        assert is_valid_transition(VentureState.RUNNING, VentureState.FAILED) is True

    def test_running_to_aborted(self):
        assert is_valid_transition(VentureState.RUNNING, VentureState.ABORTED) is True

    def test_checkpoint_to_queued(self):
        assert is_valid_transition(VentureState.CHECKPOINT, VentureState.QUEUED) is True

    def test_checkpoint_to_checkpoint_failed(self):
        assert is_valid_transition(VentureState.CHECKPOINT, VentureState.CHECKPOINT_FAILED) is True

    def test_checkpoint_to_paused(self):
        assert is_valid_transition(VentureState.CHECKPOINT, VentureState.PAUSED) is True

    def test_checkpoint_failed_to_queued(self):
        assert is_valid_transition(VentureState.CHECKPOINT_FAILED, VentureState.QUEUED) is True

    def test_checkpoint_failed_to_failed(self):
        assert is_valid_transition(VentureState.CHECKPOINT_FAILED, VentureState.FAILED) is True

    def test_paused_to_queued(self):
        assert is_valid_transition(VentureState.PAUSED, VentureState.QUEUED) is True

    def test_paused_to_aborted(self):
        assert is_valid_transition(VentureState.PAUSED, VentureState.ABORTED) is True

    # Terminal states have no valid outgoing transitions
    def test_completed_has_no_transitions(self):
        for target in VentureState:
            assert is_valid_transition(VentureState.COMPLETED, target) is False

    def test_failed_only_allows_queued(self):
        """FAILED allows transition to QUEUED (retry) but nothing else."""
        assert is_valid_transition(VentureState.FAILED, VentureState.QUEUED) is True
        for target in VentureState:
            if target != VentureState.QUEUED:
                assert is_valid_transition(VentureState.FAILED, target) is False

    def test_aborted_has_no_transitions(self):
        for target in VentureState:
            assert is_valid_transition(VentureState.ABORTED, target) is False

    # Invalid transitions
    def test_created_to_running_invalid(self):
        assert is_valid_transition(VentureState.CREATED, VentureState.RUNNING) is False

    def test_queued_to_completed_invalid(self):
        assert is_valid_transition(VentureState.QUEUED, VentureState.COMPLETED) is False

    def test_paused_to_completed_invalid(self):
        assert is_valid_transition(VentureState.PAUSED, VentureState.COMPLETED) is False

    def test_running_to_created_invalid(self):
        assert is_valid_transition(VentureState.RUNNING, VentureState.CREATED) is False


class TestValidateTransition:
    def test_valid_raises_nothing(self):
        validate_transition(VentureState.CREATED, VentureState.QUEUED)  # no exception

    def test_invalid_raises_error(self):
        with pytest.raises(InvalidStateTransitionError) as exc_info:
            validate_transition(VentureState.COMPLETED, VentureState.RUNNING)
        assert "completed" in str(exc_info.value)
        assert "running" in str(exc_info.value)

    def test_error_includes_from_and_to(self):
        with pytest.raises(InvalidStateTransitionError) as exc_info:
            validate_transition(VentureState.PAUSED, VentureState.FAILED)
        err = exc_info.value
        assert err.from_state == "paused"
        assert err.to_state == "failed"

    def test_all_valid_transitions_from_table_succeed(self):
        for from_state, valid_targets in VALID_TRANSITIONS.items():
            for to_state in valid_targets:
                validate_transition(from_state, to_state)  # no exception


class TestTerminalAndActiveStates:
    def test_terminal_states(self):
        assert VentureState.COMPLETED in TERMINAL_STATES
        assert VentureState.FAILED in TERMINAL_STATES
        assert VentureState.ABORTED in TERMINAL_STATES
        assert VentureState.RUNNING not in TERMINAL_STATES

    def test_active_states(self):
        assert VentureState.RUNNING in ACTIVE_STATES
        assert VentureState.CHECKPOINT in ACTIVE_STATES
        assert VentureState.PAUSED not in ACTIVE_STATES
        assert VentureState.COMPLETED not in ACTIVE_STATES


# ---------------------------------------------------------------------------
# StateMachine tests
# ---------------------------------------------------------------------------


def _make_venture(state=VentureState.CREATED) -> Venture:
    v = Venture(
        title="Test",
        goal="Do a thing",
        exit_condition="Done",
        executor_type="subprocess",
    )
    v.state = state
    return v


class TestStateMachineSync:
    def test_transition_sync_applies_state(self):
        sm = StateMachine()
        v = _make_venture(VentureState.CREATED)
        rec = sm.transition_sync(v, VentureState.QUEUED, "test", "engine")
        assert v.state == VentureState.QUEUED
        assert rec.from_state == VentureState.CREATED
        assert rec.to_state == VentureState.QUEUED
        assert rec.reason == "test"
        assert rec.triggered_by == "engine"

    def test_transition_sync_appends_history(self):
        sm = StateMachine()
        v = _make_venture()
        sm.transition_sync(v, VentureState.QUEUED, "q", "engine")
        sm.transition_sync(v, VentureState.RUNNING, "r", "engine")
        assert len(v.state_history) == 2

    def test_transition_sync_invalid_raises(self):
        sm = StateMachine()
        v = _make_venture(VentureState.CREATED)
        with pytest.raises(InvalidStateTransitionError):
            sm.transition_sync(v, VentureState.RUNNING, "skip", "engine")

    def test_started_at_set_on_running(self):
        sm = StateMachine()
        v = _make_venture()
        assert v.started_at is None
        sm.transition_sync(v, VentureState.QUEUED, "q", "engine")
        sm.transition_sync(v, VentureState.RUNNING, "run", "engine")
        assert v.started_at is not None

    def test_completed_at_set_on_terminal(self):
        sm = StateMachine()
        v = _make_venture()
        sm.transition_sync(v, VentureState.QUEUED, "q", "engine")
        sm.transition_sync(v, VentureState.RUNNING, "run", "engine")
        assert v.completed_at is None
        sm.transition_sync(v, VentureState.COMPLETED, "done", "executor")
        assert v.completed_at is not None

    def test_completed_at_set_on_failed(self):
        sm = StateMachine()
        v = _make_venture()
        sm.transition_sync(v, VentureState.QUEUED, "q", "engine")
        sm.transition_sync(v, VentureState.RUNNING, "run", "engine")
        sm.transition_sync(v, VentureState.FAILED, "error", "executor")
        assert v.completed_at is not None

    def test_started_at_not_overwritten(self):
        """started_at is set only once — on first RUNNING transition."""
        sm = StateMachine()
        v = _make_venture()
        sm.transition_sync(v, VentureState.QUEUED, "q", "engine")
        sm.transition_sync(v, VentureState.RUNNING, "run", "engine")
        first_started = v.started_at

        # Checkpoint → Queued → Running again (resume)
        sm.transition_sync(v, VentureState.CHECKPOINT, "cp", "engine")
        sm.transition_sync(v, VentureState.QUEUED, "resume", "engine")
        sm.transition_sync(v, VentureState.RUNNING, "run2", "engine")
        assert v.started_at == first_started  # unchanged


class TestStateMachineAsync:
    @pytest.mark.asyncio
    async def test_async_transition_applies_state(self):
        sm = StateMachine()
        await sm.start()
        v = _make_venture()
        rec = await sm.transition(v, VentureState.QUEUED, "test", "engine")
        assert v.state == VentureState.QUEUED
        assert rec.to_state == VentureState.QUEUED
        await sm.stop()

    @pytest.mark.asyncio
    async def test_async_invalid_transition_raises(self):
        sm = StateMachine()
        await sm.start()
        v = _make_venture()
        with pytest.raises(InvalidStateTransitionError):
            await sm.transition(v, VentureState.RUNNING, "skip", "engine")
        await sm.stop()

    @pytest.mark.asyncio
    async def test_listener_called_on_transition(self):
        sm = StateMachine()
        fired = []

        async def listener(venture, record):
            fired.append((venture.id, record.to_state))

        sm.add_listener(listener)
        await sm.start()
        v = _make_venture()
        await sm.transition(v, VentureState.QUEUED, "test", "engine")
        await asyncio.sleep(0.05)  # let queue process
        assert len(fired) == 1
        assert fired[0][1] == VentureState.QUEUED
        await sm.stop()

    @pytest.mark.asyncio
    async def test_listener_exception_doesnt_block(self):
        """A failing listener should not prevent other listeners from running."""
        sm = StateMachine()
        results = []

        async def bad_listener(v, r):
            raise RuntimeError("listener crash")

        async def good_listener(v, r):
            results.append(r.to_state)

        sm.add_listener(bad_listener)
        sm.add_listener(good_listener)
        await sm.start()
        v = _make_venture()
        await sm.transition(v, VentureState.QUEUED, "test", "engine")
        await asyncio.sleep(0.05)
        assert VentureState.QUEUED in results
        await sm.stop()

    @pytest.mark.asyncio
    async def test_stop_and_restart(self):
        sm = StateMachine()
        await sm.start()
        await sm.stop()
        assert sm._running is False
        assert sm._task is None

    @pytest.mark.asyncio
    async def test_transition_without_start_uses_direct_apply(self):
        """If queue not running, transition falls back to direct apply."""
        sm = StateMachine()
        # Do NOT call start()
        v = _make_venture()
        rec = await sm.transition(v, VentureState.QUEUED, "test", "engine")
        assert v.state == VentureState.QUEUED
        assert rec.to_state == VentureState.QUEUED


class TestFullTransitionPath:
    """Walk a venture through a full lifecycle using only sync transitions."""

    def test_happy_path(self):
        sm = StateMachine()
        v = _make_venture()

        sm.transition_sync(v, VentureState.QUEUED, "start", "user")
        assert v.state == VentureState.QUEUED

        sm.transition_sync(v, VentureState.RUNNING, "slot available", "engine")
        assert v.state == VentureState.RUNNING

        sm.transition_sync(v, VentureState.CHECKPOINT, "context limit", "engine")
        sm.transition_sync(v, VentureState.QUEUED, "auto-resume", "engine")
        sm.transition_sync(v, VentureState.RUNNING, "slot available", "engine")

        sm.transition_sync(v, VentureState.COMPLETED, "executor done", "executor")
        assert v.state == VentureState.COMPLETED
        assert len(v.state_history) == 6

    def test_abort_from_queued(self):
        sm = StateMachine()
        v = _make_venture()
        sm.transition_sync(v, VentureState.QUEUED, "start", "user")
        sm.transition_sync(v, VentureState.ABORTED, "user cancelled", "user")
        assert v.state == VentureState.ABORTED

    def test_checkpoint_fail_then_recover(self):
        sm = StateMachine()
        v = _make_venture()
        sm.transition_sync(v, VentureState.QUEUED, "q", "engine")
        sm.transition_sync(v, VentureState.RUNNING, "r", "engine")
        sm.transition_sync(v, VentureState.CHECKPOINT, "cp", "engine")
        sm.transition_sync(v, VentureState.CHECKPOINT_FAILED, "disk full", "engine")
        sm.transition_sync(v, VentureState.QUEUED, "retry succeeded", "engine")
        assert v.state == VentureState.QUEUED

    def test_checkpoint_fail_then_terminal(self):
        sm = StateMachine()
        v = _make_venture()
        sm.transition_sync(v, VentureState.QUEUED, "q", "engine")
        sm.transition_sync(v, VentureState.RUNNING, "r", "engine")
        sm.transition_sync(v, VentureState.CHECKPOINT, "cp", "engine")
        sm.transition_sync(v, VentureState.CHECKPOINT_FAILED, "disk full", "engine")
        sm.transition_sync(v, VentureState.FAILED, "max retries exceeded", "engine")
        assert v.state == VentureState.FAILED
