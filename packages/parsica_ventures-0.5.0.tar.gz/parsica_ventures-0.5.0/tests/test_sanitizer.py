"""Tests for parsica_ventures.sanitizer — secret patterns are redacted correctly."""
from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from parsica_ventures.sanitizer import sanitize, sanitize_dict


# ---------------------------------------------------------------------------
# Individual pattern tests
# ---------------------------------------------------------------------------


class TestSanitize:
    # Anthropic keys
    def test_anthropic_api_key_redacted(self):
        text = "Using key sk-ant-api03-" + "A" * 30
        result = sanitize(text)
        assert "sk-ant-api03" not in result
        assert "[REDACTED:anthropic-api-key]" in result

    def test_anthropic_oauth_redacted(self):
        text = "token=sk-ant-oat01-" + "X" * 30
        result = sanitize(text)
        assert "sk-ant-oat01" not in result
        assert "[REDACTED:anthropic-oauth]" in result

    def test_anthropic_refresh_redacted(self):
        text = "refresh=sk-ant-ort01-" + "Y" * 30
        result = sanitize(text)
        assert "sk-ant-ort01" not in result
        assert "[REDACTED:anthropic-refresh]" in result

    # OpenAI keys
    def test_openai_project_key_redacted(self):
        text = "api_key: sk-proj-" + "b" * 30
        result = sanitize(text)
        assert "sk-proj-" not in result
        assert "[REDACTED:openai-project-key]" in result

    def test_openai_service_key_redacted(self):
        text = "token: sk-svcacct-" + "c" * 30
        result = sanitize(text)
        assert "sk-svcacct-" not in result
        assert "[REDACTED:openai-service-key]" in result

    def test_openai_key_redacted(self):
        # Generic sk- with 48+ chars
        text = "key: sk-" + "d" * 48
        result = sanitize(text)
        assert "[REDACTED:openai-key]" in result

    # Google
    def test_google_api_key_redacted(self):
        text = "gkey: AIza" + "E" * 35
        result = sanitize(text)
        assert "AIza" not in result
        assert "[REDACTED:google-api-key]" in result

    # GitHub
    def test_github_pat_redacted(self):
        text = "github token: ghp_" + "F" * 36
        result = sanitize(text)
        assert "ghp_" not in result
        assert "[REDACTED:github-pat]" in result

    def test_github_oauth_redacted(self):
        text = "gho_" + "G" * 36
        result = sanitize(text)
        assert "gho_" not in result
        assert "[REDACTED:github-oauth]" in result

    def test_github_secret_redacted(self):
        text = "ghs_" + "H" * 36
        result = sanitize(text)
        assert "ghs_" not in result
        assert "[REDACTED:github-secret]" in result

    # PyPI
    def test_pypi_token_redacted(self):
        token = "pypi-" + "I" * 36
        text = f"token value: {token}"
        result = sanitize(text)
        # The original token should not appear after redaction
        assert token not in result
        assert "[REDACTED:pypi-token]" in result

    # Slack
    def test_slack_bot_token_redacted(self):
        text = "slack: xoxb-1234-5678-abc"
        result = sanitize(text)
        assert "xoxb-" not in result
        assert "[REDACTED:slack-bot-token]" in result

    def test_slack_user_token_redacted(self):
        text = "xoxp-12345-67890-abcdef"
        result = sanitize(text)
        assert "xoxp-" not in result
        assert "[REDACTED:slack-user-token]" in result

    # Discord
    def test_discord_token_redacted(self):
        # Discord bot token pattern: base64.base64.base64
        text = "MTQ4MTc5MDYwNjYxMDI2ODMwNA.GZh9yg.ik7p4VzFdruPzWkwO_T5JPlaraNddIbb49bck4"
        result = sanitize(text)
        assert "[REDACTED:discord-token]" in result

    # Bearer token
    def test_bearer_token_redacted(self):
        long_token = "A" * 65
        text = f"Authorization: Bearer {long_token}"
        result = sanitize(text)
        assert "[REDACTED:bearer-token]" in result

    # No-op cases
    def test_clean_text_unchanged(self):
        text = "Running subprocess: echo hello world"
        assert sanitize(text) == text

    def test_empty_string(self):
        assert sanitize("") == ""

    def test_short_sk_not_redacted(self):
        # Short "sk-" strings that don't look like API keys
        text = "sk-short"
        result = sanitize(text)
        assert result == text or "sk-short" not in result  # may or may not match

    def test_multiline_text(self):
        text = "Line 1: normal\nLine 2: sk-ant-api03-" + "Z" * 30 + "\nLine 3: ok"
        result = sanitize(text)
        assert "sk-ant-api03" not in result
        assert "Line 1: normal" in result
        assert "Line 3: ok" in result

    def test_multiple_secrets_in_one_line(self):
        key1 = "sk-ant-api03-" + "A" * 30
        key2 = "sk-proj-" + "B" * 30
        text = f"key1={key1} key2={key2}"
        result = sanitize(text)
        assert "sk-ant-api03" not in result
        assert "sk-proj-" not in result

    def test_non_secret_content_preserved(self):
        text = "Completed step 3: wrote 150 lines to output.py"
        result = sanitize(text)
        assert result == text


# ---------------------------------------------------------------------------
# sanitize_dict
# ---------------------------------------------------------------------------


class TestSanitizeDict:
    def test_string_values_sanitized(self):
        d = {"log": "sk-ant-api03-" + "A" * 30}
        result = sanitize_dict(d)
        assert "sk-ant-api03" not in result["log"]
        assert "[REDACTED" in result["log"]

    def test_non_string_values_preserved(self):
        d = {"count": 42, "flag": True, "ratio": 3.14}
        result = sanitize_dict(d)
        assert result == d

    def test_nested_dict_sanitized(self):
        d = {
            "outer": {
                "token": "sk-proj-" + "X" * 30,
                "plain": "value",
            }
        }
        result = sanitize_dict(d)
        assert "[REDACTED" in result["outer"]["token"]
        assert result["outer"]["plain"] == "value"

    def test_list_of_strings_sanitized(self):
        d = {
            "logs": [
                "normal line",
                "ghp_" + "A" * 36,
                "another normal line",
            ]
        }
        result = sanitize_dict(d)
        assert result["logs"][0] == "normal line"
        assert "[REDACTED:github-pat]" in result["logs"][1]
        assert result["logs"][2] == "another normal line"

    def test_list_of_dicts_sanitized(self):
        d = {
            "items": [
                {"key": "sk-ant-api03-" + "B" * 30}
            ]
        }
        result = sanitize_dict(d)
        assert "[REDACTED" in result["items"][0]["key"]

    def test_empty_dict(self):
        assert sanitize_dict({}) == {}

    def test_clean_dict_unchanged(self):
        d = {"model": "claude", "step": 3, "done": False}
        result = sanitize_dict(d)
        assert result == d
