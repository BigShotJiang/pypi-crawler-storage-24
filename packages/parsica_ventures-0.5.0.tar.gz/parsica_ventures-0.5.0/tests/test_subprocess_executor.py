"""Tests for subprocess executor — VENTURE_* signal parsing, lifecycle, unknown signals."""
from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path
from unittest.mock import patch, AsyncMock, MagicMock

import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from parsica_ventures.executors.subprocess_executor import SubprocessExecutor, KNOWN_SIGNALS
from parsica_ventures.models import (
    Venture,
    VenturePolicy,
    VentureState,
)
from parsica_ventures.exceptions import ExecutorLaunchError


def _make_venture() -> Venture:
    return Venture(
        title="Test",
        goal="do a thing",
        exit_condition="done",
        executor_type="subprocess",
        executor_config={"command": "echo done"},
    )


class MockCallback:
    def __init__(self):
        self.checkpoints = []
        self.progress = []
        self.completions = []
        self.failures = []
        self.approvals = []
        self.costs = []

    async def on_checkpoint_needed(self, reason, state):
        self.checkpoints.append({"reason": reason, "state": state})

    async def on_progress(self, update):
        self.progress.append(update)

    async def on_completed(self, result):
        self.completions.append(result)

    async def on_failed(self, error):
        self.failures.append(error)

    async def on_approval_needed(self, gate, context):
        self.approvals.append({"gate": gate, "context": context})

    async def on_cost_update(self, tokens, cost):
        self.costs.append({"tokens": tokens, "cost": cost})


# ---------------------------------------------------------------------------
# KNOWN_SIGNALS
# ---------------------------------------------------------------------------


class TestKnownSignals:
    def test_known_signals_set(self):
        expected = {
            "VENTURE_PROGRESS",
            "VENTURE_CHECKPOINT",
            "VENTURE_APPROVAL_NEEDED",
            "VENTURE_COMPLETE",
            "VENTURE_FAILED",
        }
        assert KNOWN_SIGNALS == expected


# ---------------------------------------------------------------------------
# Signal parsing via _handle_signal
# ---------------------------------------------------------------------------


class TestSignalParsing:
    @pytest.mark.asyncio
    async def test_venture_progress_parsed(self):
        executor = SubprocessExecutor()
        cb = MockCallback()
        executor._callback = cb
        line = 'VENTURE_PROGRESS {"step": 3, "message": "Done with analysis"}'
        await executor._handle_signal(line)
        assert len(cb.progress) == 1
        assert cb.progress[0].step == 3
        assert cb.progress[0].message == "Done with analysis"

    @pytest.mark.asyncio
    async def test_venture_complete_parsed(self):
        executor = SubprocessExecutor()
        cb = MockCallback()
        executor._callback = cb
        line = 'VENTURE_COMPLETE {"summary": "All done", "recommendations": ["Use caching"]}'
        await executor._handle_signal(line)
        assert len(cb.completions) == 1
        assert cb.completions[0].summary == "All done"
        assert "Use caching" in cb.completions[0].recommendations

    @pytest.mark.asyncio
    async def test_venture_failed_parsed(self):
        executor = SubprocessExecutor()
        cb = MockCallback()
        executor._callback = cb
        line = 'VENTURE_FAILED {"error": "Out of memory", "category": "crash", "recoverable": true}'
        await executor._handle_signal(line)
        assert len(cb.failures) == 1
        assert cb.failures[0].message == "Out of memory"
        assert cb.failures[0].recoverable is True

    @pytest.mark.asyncio
    async def test_venture_checkpoint_parsed(self):
        executor = SubprocessExecutor()
        cb = MockCallback()
        executor._callback = cb
        line = 'VENTURE_CHECKPOINT {"reason": "manual", "summary": "Saved state"}'
        await executor._handle_signal(line)
        assert len(cb.checkpoints) == 1
        assert cb.checkpoints[0]["reason"] == "manual"

    @pytest.mark.asyncio
    async def test_venture_approval_needed_parsed(self):
        executor = SubprocessExecutor()
        cb = MockCallback()
        executor._callback = cb
        line = 'VENTURE_APPROVAL_NEEDED {"gate": "git_push", "context": {"branch": "main"}}'
        await executor._handle_signal(line)
        assert len(cb.approvals) == 1
        assert cb.approvals[0]["gate"] == "git_push"
        assert cb.approvals[0]["context"]["branch"] == "main"

    @pytest.mark.asyncio
    async def test_unknown_signal_warns_and_returns(self, caplog):
        """Unknown VENTURE_* signals generate a warning and don't crash."""
        import logging
        executor = SubprocessExecutor()
        cb = MockCallback()
        executor._callback = cb
        with caplog.at_level(logging.WARNING, logger="parsica_ventures.executors.subprocess_executor"):
            await executor._handle_signal("VENTURE_PROGRES {}")  # typo
        # No progress recorded
        assert len(cb.progress) == 0
        # Warning logged
        assert any("VENTURE_PROGRES" in r.message for r in caplog.records)

    @pytest.mark.asyncio
    async def test_unknown_signal_typo_warns(self, caplog):
        """Test several common typo variants."""
        import logging
        executor = SubprocessExecutor()
        cb = MockCallback()
        executor._callback = cb
        typos = [
            "VENTURE_COMPLET {}",
            "VENTURE_FAIL {}",
            "VENTURE_CHECKPOITN {}",
        ]
        with caplog.at_level(logging.WARNING, logger="parsica_ventures.executors.subprocess_executor"):
            for typo in typos:
                await executor._handle_signal(typo)
        # No callbacks fired
        assert len(cb.completions) == 0
        assert len(cb.failures) == 0
        assert len(cb.checkpoints) == 0

    @pytest.mark.asyncio
    async def test_invalid_json_in_signal_warns(self, caplog):
        import logging
        executor = SubprocessExecutor()
        cb = MockCallback()
        executor._callback = cb
        with caplog.at_level(logging.WARNING, logger="parsica_ventures.executors.subprocess_executor"):
            await executor._handle_signal("VENTURE_PROGRESS not json at all")
        assert len(cb.progress) == 0

    @pytest.mark.asyncio
    async def test_venture_complete_with_deliverables(self):
        executor = SubprocessExecutor()
        cb = MockCallback()
        executor._callback = cb
        payload = json.dumps({
            "summary": "Done",
            "deliverables": [
                {"type": "file", "title": "output.py", "path": "/out/output.py"}
            ]
        })
        await executor._handle_signal(f"VENTURE_COMPLETE {payload}")
        assert len(cb.completions) == 1
        assert len(cb.completions[0].deliverables) == 1
        assert cb.completions[0].deliverables[0].title == "output.py"

    @pytest.mark.asyncio
    async def test_venture_progress_no_step(self):
        executor = SubprocessExecutor()
        cb = MockCallback()
        executor._callback = cb
        await executor._handle_signal('VENTURE_PROGRESS {"message": "Working..."}')
        assert len(cb.progress) == 1
        assert cb.progress[0].step is None
        assert cb.progress[0].message == "Working..."


# ---------------------------------------------------------------------------
# Lifecycle tests (using actual subprocesses)
# ---------------------------------------------------------------------------


class TestSubprocessLifecycle:
    @pytest.mark.asyncio
    async def test_start_simple_command(self):
        executor = SubprocessExecutor(command="echo hello", shell=True)
        cb = MockCallback()
        venture = _make_venture()
        handle = await executor.start(venture, cb)
        assert handle.pid is not None
        assert handle.executor_id.startswith("sub_")
        # Wait for monitor to finish
        if executor._monitor_task:
            await asyncio.wait_for(executor._monitor_task, timeout=5.0)
        # Should have triggered on_completed
        assert len(cb.completions) == 1

    @pytest.mark.asyncio
    async def test_start_failing_command(self):
        executor = SubprocessExecutor(command="exit 1", shell=True)
        cb = MockCallback()
        venture = _make_venture()
        handle = await executor.start(venture, cb)
        if executor._monitor_task:
            await asyncio.wait_for(executor._monitor_task, timeout=5.0)
        assert len(cb.failures) == 1
        assert cb.failures[0].message.startswith("Subprocess exited with code")

    @pytest.mark.asyncio
    async def test_start_no_command_raises(self):
        executor = SubprocessExecutor(command=None)
        cb = MockCallback()
        venture = _make_venture()
        venture.executor_config = {}  # no command in config either
        with pytest.raises(ExecutorLaunchError):
            await executor.start(venture, cb)

    @pytest.mark.asyncio
    async def test_health_alive_when_running(self):
        executor = SubprocessExecutor(command="sleep 10", shell=True)
        cb = MockCallback()
        venture = _make_venture()
        await executor.start(venture, cb)
        health = await executor.health(venture)
        assert health.alive is True
        await executor.abort(venture)

    @pytest.mark.asyncio
    async def test_health_dead_before_start(self):
        executor = SubprocessExecutor()
        venture = _make_venture()
        health = await executor.health(venture)
        assert health.alive is False

    @pytest.mark.asyncio
    async def test_abort_kills_process(self):
        executor = SubprocessExecutor(command="sleep 10", shell=True)
        cb = MockCallback()
        venture = _make_venture()
        await executor.start(venture, cb)
        assert executor._process is not None
        await executor.abort(venture)
        # Wait for the process to actually die after kill
        if executor._process is not None:
            try:
                await asyncio.wait_for(executor._process.wait(), timeout=3.0)
            except asyncio.TimeoutError:
                pass
        health = await executor.health(venture)
        assert health.alive is False

    @pytest.mark.asyncio
    async def test_checkpoint_returns_data(self):
        executor = SubprocessExecutor(command="sleep 10", shell=True)
        cb = MockCallback()
        venture = _make_venture()
        await executor.start(venture, cb)
        data = await executor.checkpoint(venture)
        assert data.progress_summary != ""
        await executor.abort(venture)

    @pytest.mark.asyncio
    async def test_venture_signal_from_subprocess(self):
        """Subprocess that emits VENTURE_PROGRESS should trigger callback."""
        cmd = 'echo \'VENTURE_PROGRESS {"step": 1, "message": "test step"}\''
        executor = SubprocessExecutor(command=cmd, shell=True)
        cb = MockCallback()
        venture = _make_venture()
        await executor.start(venture, cb)
        if executor._monitor_task:
            await asyncio.wait_for(executor._monitor_task, timeout=5.0)
        assert len(cb.progress) >= 1
        assert any(p.step == 1 for p in cb.progress)

    @pytest.mark.asyncio
    async def test_venture_complete_from_subprocess(self):
        """Subprocess that emits VENTURE_COMPLETE should trigger on_completed."""
        cmd = 'echo \'VENTURE_COMPLETE {"summary": "subprocess done"}\''
        executor = SubprocessExecutor(command=cmd, shell=True)
        cb = MockCallback()
        venture = _make_venture()
        await executor.start(venture, cb)
        if executor._monitor_task:
            await asyncio.wait_for(executor._monitor_task, timeout=5.0)
        # Should have either a VENTURE_COMPLETE or the natural exit completion
        assert len(cb.completions) >= 1

    @pytest.mark.asyncio
    async def test_venture_id_injected_into_env(self):
        """VENTURE_ID env var is set when subprocess launches."""
        import tempfile
        import os
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
            outfile = f.name
        try:
            cmd = f'echo $VENTURE_ID > {outfile}'
            executor = SubprocessExecutor(command=cmd, shell=True)
            cb = MockCallback()
            venture = _make_venture()
            await executor.start(venture, cb)
            if executor._monitor_task:
                await asyncio.wait_for(executor._monitor_task, timeout=5.0)
            content = Path(outfile).read_text().strip()
            assert content == venture.id
        finally:
            os.unlink(outfile)


# ---------------------------------------------------------------------------
# Registry registration
# ---------------------------------------------------------------------------


class TestRegistryRegistration:
    def test_subprocess_registered(self):
        from parsica_ventures.executor import registry
        assert registry.is_registered("subprocess")

    def test_subprocess_creates_instance(self):
        from parsica_ventures.executor import registry
        executor = registry.create("subprocess", command="echo hi")
        assert isinstance(executor, SubprocessExecutor)
