"""Tests for notification models and routing logic."""
from __future__ import annotations

import sys
from pathlib import Path

import pytest
from pydantic import BaseModel, Field, ValidationError

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from parsica_ventures.models import Venture, VenturePolicy


class NotificationTarget(BaseModel):
    channel_id: str
    notify_on: list[str] = Field(default_factory=lambda: ["checkpoint", "completed", "failed"])


class NotificationRouter:
    def __init__(self, default_channel: str | None = None):
        self.default_channel = default_channel

    def route(self, venture: Venture, event_kind: str) -> str | None:
        cfg = venture.metadata.get("notification") or {}
        targets = cfg.get("targets") or []
        for target in targets:
            parsed = NotificationTarget(**target)
            if event_kind in parsed.notify_on:
                return parsed.channel_id
        return cfg.get("channel_id") or self.default_channel


def _make_venture(metadata=None) -> Venture:
    return Venture(
        title="Notify Test",
        goal="Check notification routing",
        exit_condition="done",
        executor_type="subprocess",
        policy=VenturePolicy(),
        metadata=metadata or {},
    )


class TestNotificationModelValidation:
    def test_valid_target(self):
        target = NotificationTarget(channel_id="chan-123", notify_on=["completed"])
        assert target.channel_id == "chan-123"
        assert target.notify_on == ["completed"]

    def test_default_notify_events(self):
        target = NotificationTarget(channel_id="chan-123")
        assert "checkpoint" in target.notify_on
        assert "completed" in target.notify_on
        assert "failed" in target.notify_on

    def test_channel_id_required(self):
        with pytest.raises(ValidationError):
            NotificationTarget()


class TestNotificationRouting:
    def test_routes_specific_event_target(self):
        venture = _make_venture({
            "notification": {
                "targets": [
                    {"channel_id": "checkpoints", "notify_on": ["checkpoint"]},
                    {"channel_id": "failures", "notify_on": ["failed"]},
                ]
            }
        })
        router = NotificationRouter(default_channel="default")

        assert router.route(venture, "checkpoint") == "checkpoints"
        assert router.route(venture, "failed") == "failures"

    def test_falls_back_to_venture_channel(self):
        venture = _make_venture({
            "notification": {
                "channel_id": "venture-home",
                "targets": [{"channel_id": "checkpoints", "notify_on": ["checkpoint"]}],
            }
        })
        router = NotificationRouter(default_channel="default")

        assert router.route(venture, "completed") == "venture-home"

    def test_falls_back_to_default_channel(self):
        venture = _make_venture()
        router = NotificationRouter(default_channel="default-room")

        assert router.route(venture, "completed") == "default-room"

    def test_returns_none_when_no_route_exists(self):
        venture = _make_venture()
        router = NotificationRouter(default_channel=None)

        assert router.route(venture, "failed") is None
