"""Pydantic models for the Ionworks API client.

These models use extra="allow" to accept any fields from the API response,
letting the API handle validation. Required fields are kept minimal.
"""

from collections.abc import Iterator
from typing import Any, Generic, TypeVar
from urllib.parse import urlencode

from pydantic import BaseModel, ConfigDict, field_validator

from .validators import DataFrame, dict_to_df_validator

_T = TypeVar("_T")


class PaginatedList(Generic[_T]):  # noqa: UP046 - needs Python 3.11 compat
    """A list-like container that also carries pagination metadata.

    Returned by ``list()`` methods when ``limit`` or ``offset`` is provided.
    Behaves like a regular ``list`` for iteration, indexing, truthiness, and
    ``len()`` so callers can treat it interchangeably with ``list[T]``.

    Parameters
    ----------
    items : list[_T]
        The page of results.
    total : int
        Total number of matching records across all pages.
    """

    __slots__ = ("items", "total")

    def __init__(self, items: list[_T], total: int) -> None:
        self.items = items
        self.total = total

    @property
    def count(self) -> int:
        """Number of items in this page (same as ``len(self)``)."""
        return len(self.items)

    def __iter__(self) -> Iterator[_T]:
        return iter(self.items)

    def __len__(self) -> int:
        return len(self.items)

    def __getitem__(self, index: int | slice) -> Any:
        return self.items[index]

    def __bool__(self) -> bool:
        return bool(self.items)

    def __repr__(self) -> str:
        return (
            f"PaginatedList(items={self.items!r}, count={self.count}, "
            f"total={self.total})"
        )


def _build_endpoint(base: str, params: dict[str, str | int | bool | None]) -> str:
    """Append non-None query parameters to a base endpoint path."""
    filtered = {k: str(v) for k, v in params.items() if v is not None}
    if not filtered:
        return base
    return f"{base}?{urlencode(filtered)}"


def _parse_list_response(  # noqa: UP047
    response_data: Any,
    model_class: type[_T],
) -> PaginatedList[_T]:
    """Parse a list endpoint response into model instances.

    Always returns a :class:`PaginatedList` which behaves like a regular
    ``list`` (iteration, indexing, ``len``, truthiness) so existing callers
    are unaffected. Also exposes ``.count`` and ``.total`` for pagination.

    Handles both the paginated dict format ``{"items": [...], "count": N,
    "total": N}`` and legacy plain-array responses for backward
    compatibility.

    Parameters
    ----------
    response_data : Any
        Raw response from the API (list or paginated dict).
    model_class : type[_T]
        The Pydantic model class to instantiate per item.

    Returns
    -------
    PaginatedList[_T]
        A list-like result with ``.items``, ``.count``, and ``.total``.
    """
    if isinstance(response_data, dict) and "items" in response_data:
        items = [model_class(**item) for item in response_data["items"]]
        return PaginatedList(
            items=items,
            total=response_data["total"],
        )
    # Legacy plain-array response (backward compat)
    items = [model_class(**item) for item in response_data]
    return PaginatedList(items=items, total=len(items))


# --- Cell Specification Models --- #


class CellSpecification(BaseModel):
    """Cell specification model - accepts any fields from the API.

    The API returns nested component/material data and ratings objects.
    This model is permissive to allow the API to define the schema.
    """

    model_config = ConfigDict(extra="allow")

    id: str
    name: str


# --- Cell Instance Models --- #


class CellInstance(BaseModel):
    """Cell instance model - accepts any fields from the API."""

    model_config = ConfigDict(extra="allow")

    id: str
    name: str
    cell_specification_id: str


# --- Cell Measurement Models --- #


class CellMeasurement(BaseModel):
    """Cell measurement model - accepts any fields from the API."""

    model_config = ConfigDict(extra="allow")

    id: str
    name: str
    cell_instance_id: str


# --- Bundle Models --- #


class CellMeasurementBundleResponse(BaseModel):
    """Response from creating a measurement bundle."""

    measurement: CellMeasurement
    steps_created: int
    file_path: str


class InitiateUploadResponse(BaseModel):
    """Response from the initiate-upload endpoint for signed URL uploads."""

    measurement_id: str
    signed_url: str
    token: str
    path: str


class ConfirmUploadResponse(BaseModel):
    """Response from the confirm-upload endpoint after successful upload."""

    instance: CellInstance
    measurement: CellMeasurement
    steps_created: int
    file_path: str


# --- Detail Models --- #


class CellMeasurementDetail(BaseModel):
    """Detail model for a measurement with steps and time series.

    Returns minimal data by default: foreign keys for parent objects
    rather than nested objects. Use the spec/instance clients to
    fetch parent objects if needed.
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    measurement: CellMeasurement
    specification_id: str | None = None
    instance_id: str | None = None
    steps: DataFrame | None = None
    time_series: DataFrame | None = None
    cycles: DataFrame | None = None

    @field_validator("steps", "time_series", "cycles", mode="before")
    @classmethod
    def convert_dict_to_df(cls, v: Any) -> Any:
        """Convert dictionary to DataFrame (polars or pandas based on config)."""
        return dict_to_df_validator(v)


class CellInstanceDetail(BaseModel):
    """Detail model for a cell instance with all measurements.

    Returns a foreign key for the parent specification rather
    than a nested object. Use ``client.cell_spec.get(detail
    .specification_id)`` to fetch the full specification.
    """

    instance: CellInstance
    specification_id: str
    measurements: list[CellMeasurementDetail]


class StepsAndCycles(BaseModel):
    """Steps and cycle metrics for a measurement.

    Returned by the ``/steps_and_cycles`` endpoint which
    fetches both in one call (cycles are derived from steps).
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    steps: DataFrame
    cycles: DataFrame

    @field_validator("steps", "cycles", mode="before")
    @classmethod
    def convert_dict_to_df(cls, v: Any) -> Any:
        """Convert dictionary to DataFrame."""
        return dict_to_df_validator(v)
