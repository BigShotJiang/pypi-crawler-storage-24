# API Reference

::: binaryornot
