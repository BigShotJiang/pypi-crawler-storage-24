"""CLI entrypoints for abi-control-core."""

from __future__ import annotations

import json
import sys
from datetime import UTC, datetime
from pathlib import Path

from abi_control_core.sdk.lock import generate_lock, serialize_lock


def lock_contracts_cli() -> None:
    """CLI entrypoint: regenerate contracts.lock.json.

    The lock file itself is deterministic (no timestamps).
    A separate contracts.lock.meta.json is emitted with run metadata.
    """
    repo_root = Path(__file__).resolve().parent.parent.parent
    lock_path = repo_root / "contracts.lock.json"

    lock_data = generate_lock()
    lock_path.write_text(serialize_lock(lock_data))

    # Emit timestamp metadata separately — not part of the verified lock
    meta_path = repo_root / "contracts.lock.meta.json"
    meta = {
        "generated_at": datetime.now(UTC).isoformat(),
        "contract_count": len(lock_data["contracts"]),
    }
    meta_path.write_text(json.dumps(meta, indent=2) + "\n")

    print(f"Wrote {lock_path} with {len(lock_data['contracts'])} contracts")
    sys.exit(0)
