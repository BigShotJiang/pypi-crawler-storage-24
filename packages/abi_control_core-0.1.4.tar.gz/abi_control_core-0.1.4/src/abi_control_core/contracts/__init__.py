"""ABI canonical contract schemas."""

from pathlib import Path

CONTRACTS_DIR = Path(__file__).parent


def schema_path(name: str) -> Path:
    """Return the absolute path to a schema file by name.

    Args:
        name: Schema filename (e.g. 'run_manifest.schema.json')

    Returns:
        Absolute path to the schema file.

    Raises:
        FileNotFoundError: If the schema does not exist.
    """
    p = CONTRACTS_DIR / name
    if not p.exists():
        raise FileNotFoundError(f"Schema not found: {name} (looked in {CONTRACTS_DIR})")
    return p
