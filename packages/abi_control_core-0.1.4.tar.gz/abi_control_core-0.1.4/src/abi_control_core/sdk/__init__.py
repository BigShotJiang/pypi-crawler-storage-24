"""ABI Control Core SDK — validation, hashing, artifacts, evidence packs, evals."""

from abi_control_core.sdk.canonical_hash import (
    canonical_hash_excluding_metadata,
    canonical_hash_jcs_sha256,
    jcs_serialize,
)
from abi_control_core.sdk.evidence_pack import (
    EvidencePackBuilder,
    EvidenceValidationError,
    ValidationResult,
    validate_before_promote,
    validate_evidence_pack,
)
from abi_control_core.sdk.failure_taxonomy import (
    FailureClass,
    FailureSeverity,
    create_failure_record,
    validate_failure_record,
)
from abi_control_core.sdk.config_loader import (
    ABIConfig,
    load_config,
)
from abi_control_core.sdk.telemetry_emitter import (
    VALID_PROVIDERS,
    VALID_ROLES,
    VALID_STATUSES,
    TelemetryEmitter,
)

__all__ = [
    "canonical_hash_excluding_metadata",
    "canonical_hash_jcs_sha256",
    "jcs_serialize",
    "EvidencePackBuilder",
    "EvidenceValidationError",
    "ValidationResult",
    "validate_before_promote",
    "validate_evidence_pack",
    "FailureClass",
    "FailureSeverity",
    "create_failure_record",
    "validate_failure_record",
    "ABIConfig",
    "load_config",
    "TelemetryEmitter",
    "VALID_PROVIDERS",
    "VALID_ROLES",
    "VALID_STATUSES",
]
