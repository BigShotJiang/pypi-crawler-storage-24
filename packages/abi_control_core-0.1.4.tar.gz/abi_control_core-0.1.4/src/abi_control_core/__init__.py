"""abi-control-core: Canonical nucleus for ABI contracts, evidence packs, and validation."""

__version__ = "0.1.4"
