# Schema Discovery Report

Generated from: `C:\Dev\AbilityBI\PortfolioProjects\abi-template`

## Discovered Schemas (15 files matching `*.schema.json`)

| Original Path | Canonical Contract Name | Category | Notes |
|---|---|---|---|
| `.abi/evidence.schema.json` | `evidence.schema.json` | governance | Change evidence for Tier 1/2 changes |
| `agents/schemas/role_assignments.schema.json` | `role_assignments.schema.json` | agents | Maps governance roles to AI providers/models |
| `docs/ai/contracts/a2a-handoff.schema.json` | `a2a_handoff.schema.json` | agents | Agent-to-agent handoff envelope (A2A-Lite) |
| `docs/ai/contracts/dlif-envelope.schema.json` | `dlif_envelope.schema.json` | invocation | Deterministic LLM Invocation Framework envelope |
| `docs/ai/contracts/genai-telemetry.schema.json` | `genai_telemetry.schema.json` | telemetry | GenAI observability events (OTel-aligned) |
| `intent/schemas/aics.manifest.schema.json` | `aics_manifest.schema.json` | intent | AbilityBI Intent Contract Standard manifest |
| `intent/schemas/aics.receipt.schema.json` | `aics_receipt.schema.json` | intent | Intent gate run receipt |
| `policies/schema/policy_registry.schema.json` | `policy_registry.schema.json` | governance | Canonical policy inventory |
| `schemas/budget_receipt.schema.json` | `budget_receipt.schema.json` | budget | Token budget accounting receipt |
| `schemas/context_manifest.schema.json` | `context_manifest.schema.json` | context | Context pack governance manifest |
| `schemas/crp.schema.json` | `crp.schema.json` | planning | Completion Report Package |
| `schemas/mrp.schema.json` | `mrp.schema.json` | planning | Machine Readable Plan |
| `schemas/run_manifest.schema.json` | `run_manifest.schema.json` | core | **Anchor contract** — gate run metadata |
| `schemas/span.schema.json` | `span.schema.json` | tracing | OpenTelemetry-inspired trace span |
| `schemas/trace_event.schema.json` | `trace_event.schema.json` | tracing | Append-only trace event stream |

## Naming Convention

- Filenames normalized to `snake_case` with `.schema.json` suffix.
- Dots in original names (e.g., `aics.manifest`) replaced with underscores.
- Hyphens in original names (e.g., `a2a-handoff`) replaced with underscores.
- No filename conflicts detected across all source locations.

## Additional Schema Files (non `.schema.json` extension)

| Original Path | Status | Notes |
|---|---|---|
| `promptware/schema.json` | Not mirrored | Promptware-specific, not a contract |
| `ui/tokens/schema.json` | Not mirrored | UI design tokens, not a contract |

These two files use `$schema` references but define domain-specific structures that are not ABI governance contracts. They are excluded from the canonical set.

## Categories

| Category | Count | Description |
|---|---|---|
| core | 1 | Anchor contracts (run_manifest) |
| budget | 1 | Token budget tracking |
| tracing | 2 | Spans and events |
| intent | 2 | AICS manifest and receipts |
| governance | 2 | Evidence and policy registry |
| agents | 2 | Role assignments and A2A handoffs |
| planning | 2 | MRP and CRP |
| invocation | 1 | DLIF envelope |
| telemetry | 1 | GenAI observability |
| context | 1 | Context pack governance |
