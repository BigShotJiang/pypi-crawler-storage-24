"""Shared test fixtures."""

from pathlib import Path

import pytest

FIXTURES_DIR = Path(__file__).parent / "fixtures"


@pytest.fixture
def fixtures_dir() -> Path:
    return FIXTURES_DIR


@pytest.fixture
def tmp_evidence_dir(tmp_path: Path) -> Path:
    d = tmp_path / "evidence_packs"
    d.mkdir()
    return d
