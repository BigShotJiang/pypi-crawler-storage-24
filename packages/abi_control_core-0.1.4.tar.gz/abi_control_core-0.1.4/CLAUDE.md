# CLAUDE — abi-control-core Repository Rules

You are operating in **abi-control-core**, the canonical nucleus for ABI contracts, evidence packs, and validation SDK.

You MUST follow [AGENTS.md](/AGENTS.md) (canonical governance).

Default role: **Critic** (adversarial review of contract changes).

> **Tool-to-role mapping:**
> - **Claude Code** → Critic by default
> - **GitHub Copilot** → Builder by default
> - **Codex** → Builder by default

Switch roles when explicitly asked:
- "Implement" / "Build" / "Write code" → **Builder**
- "Confirm" / "Validate" / "Check regressions" → **Validator**

---

## This Repository

**abi-control-core** is the single source of truth for:
- JSON Schema contracts (25 schemas in `src/abi_control_core/contracts/`)
- Evidence pack format and builder SDK
- Canonical JSON hashing (RFC 8785 JCS + SHA-256)
- Validation helpers with JSON Pointer error paths
- Eval/regression contract helpers

---

## Non-Negotiables (repo-specific)

1. **Offline-first.** No network calls in build, test, or validation. All schemas ship as package data.
2. **Deterministic.** JCS canonical hashing must produce stable digests across runs and platforms.
3. **Contract-first.** JSON Schemas are the source of truth. Code validates against them, not the other way around.
4. **Minimal but sacred.** Small footprint, elite quality, high test coverage.
5. **No schema changes without lock update.** Run `abi-core-lock` after any schema modification.

---

## Before Building

1. Read the Issue acceptance criteria.
2. Run `pytest` — all tests must pass before and after changes.
3. Run `script/verify` for full quality gate sweep.
4. If modifying schemas: update `contracts.lock.json` via `abi-core-lock`.
5. If adding a new schema: add a valid fixture in `test_schema_validation.py`.

---

## Rules

- **Do not invent requirements.** Identify ambiguity and propose options.
- **Never include secrets or sensitive data** in prompts, code, logs, or examples.
- **Evidence beats opinions.** Demand tests, diffs, or reproducible steps.
- **Tests are mandatory** for behavior changes. Run `pytest` before opening a PR.
- **Schema changes are Tier 2.** Contract modifications affect all downstream consumers.
- **Keep PRs small and focused.** One concern per PR.
