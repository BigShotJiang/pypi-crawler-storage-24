#!/usr/bin/env python3
"""Quality Gate: Eval Contracts.

Verifies that eval_suite and eval_result schemas work correctly:
- A valid eval suite can be loaded and validated
- An eval result can be written and validated
- Golden comparison modes function correctly

Exits 0 on success, 1 on failure.
"""

from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

from abi_control_core.sdk.evals import (
    compare_exact,
    compare_numeric_tolerance,
    compare_structural,
    load_eval_suite,
    write_eval_result,
)
from abi_control_core.sdk.validate import SchemaValidationError

VALID_SUITE = {
    "schema_version": "eval-suite/1.0",
    "suite_id": "gate-eval-suite",
    "cases": [
        {"case_id": "tc-1", "input": {"x": 1}, "expected": {"y": 2}},
        {"case_id": "tc-2", "input": {"x": 2}, "expected": {"y": 4}, "comparison": "exact"},
    ],
}


def main() -> int:
    errors: list[str] = []

    with tempfile.TemporaryDirectory() as tmp:
        tmp_path = Path(tmp)

        # Test: load valid eval suite
        suite_path = tmp_path / "suite.json"
        suite_path.write_text(json.dumps(VALID_SUITE), encoding="utf-8")
        try:
            suite = load_eval_suite(suite_path)
            if suite["suite_id"] != "gate-eval-suite":
                errors.append("Loaded suite has wrong suite_id")
        except Exception as e:
            errors.append(f"Failed to load valid suite: {e}")

        # Test: write eval result
        result_path = tmp_path / "result.json"
        try:
            result = write_eval_result(
                result_path,
                "gate-eval-suite",
                "aabb0011",
                [
                    {"case_id": "tc-1", "status": "pass"},
                    {"case_id": "tc-2", "status": "fail", "message": "mismatch"},
                ],
            )
            if result["summary"]["total"] != 2:
                errors.append("Eval result summary total incorrect")
            if result["summary"]["passed"] != 1:
                errors.append("Eval result summary passed incorrect")
        except Exception as e:
            errors.append(f"Failed to write eval result: {e}")

        # Test: comparison modes
        if not compare_exact({"a": 1}, {"a": 1}):
            errors.append("Exact comparison failed for equal values")
        if compare_exact({"a": 1}, {"a": 2}):
            errors.append("Exact comparison passed for unequal values")

        if not compare_numeric_tolerance(1.0000001, 1.0, tolerance=1e-6):
            errors.append("Numeric tolerance comparison failed within tolerance")

        if not compare_structural({"a": 1, "b": 2}, {"a": 1}):
            errors.append("Structural comparison failed for superset")

    if errors:
        print(f"FAIL: {len(errors)} eval contract error(s):")
        for err in errors:
            print(f"  - {err}")
        return 1

    print("PASS: Eval contracts and golden comparison verified")
    return 0


if __name__ == "__main__":
    sys.exit(main())
