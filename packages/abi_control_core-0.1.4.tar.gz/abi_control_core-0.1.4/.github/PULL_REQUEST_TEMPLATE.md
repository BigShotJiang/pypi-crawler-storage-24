## Summary
<!-- What changed and why? Link to the motivating Issue. -->

## Intent
<!-- WHY is this change being made? What problem does it solve? -->

## Approach
<!-- HOW did you solve it? What alternatives were considered? -->

## Spec
- Issue: #
- Acceptance criteria: <!-- paste checklist from Issue -->

## Risk Tier
- [ ] Tier 0 (Trivial) — docs, comments, formatting
- [ ] Tier 1 (Standard) — SDK improvements, new tests, tooling
- [ ] Tier 2 (Critical) — schema changes, hashing changes, evidence pack format changes

## AI Usage
- [ ] None
- [ ] Yes — Tools:
- What AI did:
- What human verified:

## Verification
<!-- Required for Tier 1+. Tier 0 may omit. -->
1) Run:
   <!-- exact commands to execute -->
2) Inputs:
   <!-- fixtures, sample data -->
3) Expected:
   <!-- observable outputs -->
4) Confirm:
   - <!-- key invariants -->
   - <!-- error paths covered -->

## Contract Impact
<!-- Required if any schema files were modified. -->
- [ ] No schema changes
- [ ] Schema changed — details:
  - [ ] `contracts.lock.json` updated via `abi-core-lock`
  - [ ] Valid fixture added in `test_schema_validation.py`
  - [ ] `MIGRATION.md` updated (if consumer impact)

## Evidence
<!-- Tier 1+: required. Tier 0: write N/A. -->
- CI run:
- Test results:
- `script/verify` output:
