#!/usr/bin/env python3
"""Standalone script to regenerate contracts.lock.json.

Usage:
    python scripts/lock_contracts.py
    # or via CLI entrypoint:
    abi-core-lock
"""

from __future__ import annotations

import json
import sys
from datetime import UTC, datetime
from pathlib import Path

# Add src to path for standalone execution
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))

from abi_control_core.sdk.lock import generate_lock, serialize_lock


def main() -> None:
    repo_root = Path(__file__).resolve().parent.parent
    lock_path = repo_root / "contracts.lock.json"

    lock_data = generate_lock()
    lock_path.write_text(serialize_lock(lock_data))

    # Emit timestamp metadata separately — not part of the verified lock
    meta_path = repo_root / "contracts.lock.meta.json"
    meta = {
        "generated_at": datetime.now(UTC).isoformat(),
        "contract_count": len(lock_data["contracts"]),
    }
    meta_path.write_text(json.dumps(meta, indent=2) + "\n")

    print(f"Wrote {lock_path} with {len(lock_data['contracts'])} contracts")


if __name__ == "__main__":
    main()
