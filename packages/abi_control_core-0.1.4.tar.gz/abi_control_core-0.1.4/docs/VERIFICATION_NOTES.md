# Verification Notes — abi-core

## Traceability Markers

### Full node ID: determinism

```
tests/test_canonical_hash.py::TestCanonicalHash::test_simple_manifest_hash_stable
```

Verifies that the JCS canonical hash of a simple manifest is identical across
10 repeated computations using `canonical_hash_jcs_sha256`.

### Full node ID: timestamp exclusion

```
tests/test_lock.py::TestContractLock::test_lock_no_timestamp
```

Asserts that the generated `contracts.lock.json` contains no timestamp field,
ensuring deterministic lock file regeneration.

---

## Tranche History

- **Definition Plane Tranche** (base HEAD `124a1c7`) — contract rigor hardening, schema strictness

### Definition Plane Tranche — Capability Advancement

**Schema strictness** — 43 tests in `tests/test_schema_strictness.py`

Full node ID:
```
tests/test_schema_strictness.py::TestSchemaSelfValidity::test_schema_is_valid_draft_2020_12[run_manifest]
```

43 new tests total. All pass. Draft 2020-12 self-validation for all 31 schemas,
additionalProperties enforcement, required field removal rejection, enum strictness.

### Model Governance & Routing Spec v1.0 — Schema Tranche

**Base HEAD**: `124a1c7`

5 new JSON schemas created in `src/abi_control_core/contracts/`:
- `model_registry.schema.json` (model-registry/1.0)
- `routing_policy.schema.json` (routing-policy/1.0)
- `project_profile.schema.json` (project-profile/1.0)
- `routing_decision_record.schema.json` (routing-decision-record/1.0)
- `budget_state.schema.json` (budget-state/1.0)

25 new tests in `tests/test_model_governance_schemas.py`. contracts.lock.json regenerated (36 schemas).

Full node ID:
```
tests/test_model_governance_schemas.py::TestModelRegistrySchema::test_valid_model_registry
```

verify.log: EXIT_CODE=0, Results: 8 passed, 0 failed
