# Roadmap

## Near Term
- Expand evidence pack schema coverage
- Add contract versioning support

## Later
- GraphQL schema generation from Pydantic models
