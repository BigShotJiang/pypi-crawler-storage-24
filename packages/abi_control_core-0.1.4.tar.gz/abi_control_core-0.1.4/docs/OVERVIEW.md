# Overview

## Purpose
The shared contract layer consumed by all AbilityBI repositories. Defines RunState, EvidencePack, PolicyDecision, and related domain models.

## Primary Users
- AbilityBI engineering and AI pipeline operators

## Scope
- What it covers: Canonical contracts, evidence packs, and validation SDK for the AbilityBI control plane.
- What it does not cover: External distribution or unsanctioned integrations
