# Governance

This directory contains the Memory Governance Protocol adopted from abi-template.

## Canonical Reference

The Memory Governance Protocol is authored and maintained in
**[abi-template](https://github.com/AbilityBI/abi-template)**:

- Specification: `docs/governance/MEMORY_GOVERNANCE_SPEC_v1.md`
- Verifier algorithm: `docs/governance/MEMORY_VERIFIER_ALGORITHM.md`
- Quick-start guide: `docs/guides/MEMORY_PROTOCOL_QUICKSTART.md`

The copies in this repo are adopted verbatim from abi-template v0.21.2+.
To upgrade, re-copy from the canonical source after a abi-template template version bump.

## abi-core Scope Note

abi-core is the **contract schema source-of-truth** repo. Memory governance does not
govern `contracts/`, `contracts.lock.json`, or `src/abi_control_core/`. Those surfaces
are governed by `scripts/lock_contracts.py` and the gate scripts in `script/`.
