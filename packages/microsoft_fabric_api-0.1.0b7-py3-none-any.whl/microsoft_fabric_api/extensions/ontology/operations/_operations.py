from ....generated.ontology.operations import *
from ....generated.ontology import operations as _operations
from ....generated.ontology import models as _models
from azure.core.polling.base_polling import LROBasePolling, OperationResourcePolling, StatusCheckPolling
from azure.core.polling import LROPoller
from ....fabric_api_utils import _LROResultExtractor
from typing import *
import time



class ItemsOperations(_operations.ItemsOperations):
    """ItemsOperations for Ontology."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    

    
    def create_ontology(self, workspace_id: str, create_ontology_request: _models.CreateOntologyRequest, *, content_type: str = 'application/json', **kwargs: Any) -> _models.Ontology:
        """Creates an Ontology in the specified workspace.

        ..

           [!NOTE]
           Ontology item is currently in Preview (\ `learn more </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create ontology with definition, refer to `Ontology definition
        </rest/api/fabric/articles/item-management/definitions/ontology-definition>`_.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------


        * To create an ontology the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_ontology_request: Create item request payload. Required.
        :type create_ontology_request: ~microsoft.fabric.api.ontology.models.CreateOntologyRequest
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns Ontology
        :rtype: ~azure.core.polling.LROPoller[~microsoft.fabric.api.ontology.models.Ontology]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        extractor = self.begin_create_ontology(workspace_id=workspace_id, create_ontology_request=create_ontology_request, content_type=content_type, **kwargs, )

        while extractor.result is None:
            time.sleep(5)

        return extractor.result
        
    
    
    def begin_create_ontology(self, workspace_id: str, create_ontology_request: _models.CreateOntologyRequest, *, content_type: str = 'application/json', **kwargs: Any) -> _LROResultExtractor[_models.Ontology]:
        """Creates an Ontology in the specified workspace.

        ..

           [!NOTE]
           Ontology item is currently in Preview (\ `learn more </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create ontology with definition, refer to `Ontology definition
        </rest/api/fabric/articles/item-management/definitions/ontology-definition>`_.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------


        * To create an ontology the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_ontology_request: Create item request payload. Required.
        :type create_ontology_request: ~microsoft.fabric.api.ontology.models.CreateOntologyRequest
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns Ontology
        :rtype: ~azure.core.polling.LROPoller[~microsoft.fabric.api.ontology.models.Ontology]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        extractor = _LROResultExtractor[_models.Ontology]()

        poller = super().begin_create_ontology(
            workspace_id=workspace_id,
            create_ontology_request=create_ontology_request,
            content_type=content_type,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )

        poller.add_done_callback(extractor)

        return extractor
        
    

    
    def create_ontology(self, workspace_id: str, create_ontology_request: IO[bytes], *, content_type: str = 'application/json', **kwargs: Any) -> _models.Ontology:
        """Creates an Ontology in the specified workspace.

        ..

           [!NOTE]
           Ontology item is currently in Preview (\ `learn more </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create ontology with definition, refer to `Ontology definition
        </rest/api/fabric/articles/item-management/definitions/ontology-definition>`_.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------


        * To create an ontology the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_ontology_request: Create item request payload. Required.
        :type create_ontology_request: IO[bytes]
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns Ontology
        :rtype: ~azure.core.polling.LROPoller[~microsoft.fabric.api.ontology.models.Ontology]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        extractor = self.begin_create_ontology(workspace_id=workspace_id, create_ontology_request=create_ontology_request, content_type=content_type, **kwargs, )

        while extractor.result is None:
            time.sleep(5)

        return extractor.result
        
    
    
    def begin_create_ontology(self, workspace_id: str, create_ontology_request: IO[bytes], *, content_type: str = 'application/json', **kwargs: Any) -> _LROResultExtractor[_models.Ontology]:
        """Creates an Ontology in the specified workspace.

        ..

           [!NOTE]
           Ontology item is currently in Preview (\ `learn more </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create ontology with definition, refer to `Ontology definition
        </rest/api/fabric/articles/item-management/definitions/ontology-definition>`_.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------


        * To create an ontology the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_ontology_request: Create item request payload. Required.
        :type create_ontology_request: IO[bytes]
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns Ontology
        :rtype: ~azure.core.polling.LROPoller[~microsoft.fabric.api.ontology.models.Ontology]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        extractor = _LROResultExtractor[_models.Ontology]()

        poller = super().begin_create_ontology(
            workspace_id=workspace_id,
            create_ontology_request=create_ontology_request,
            content_type=content_type,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )

        poller.add_done_callback(extractor)

        return extractor
        
    

    
    def create_ontology(self, workspace_id: str, create_ontology_request: Union[_models.CreateOntologyRequest, IO[bytes]], **kwargs: Any) -> _models.Ontology:
        """Creates an Ontology in the specified workspace.

        ..

           [!NOTE]
           Ontology item is currently in Preview (\ `learn more </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create ontology with definition, refer to `Ontology definition
        </rest/api/fabric/articles/item-management/definitions/ontology-definition>`_.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------


        * To create an ontology the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_ontology_request: Create item request payload. Is either a CreateOntologyRequest
         type or a IO[bytes] type. Required.
        :type create_ontology_request: ~microsoft.fabric.api.ontology.models.CreateOntologyRequest or
         IO[bytes]
        :return: An instance of LROPoller that returns Ontology
        :rtype: ~azure.core.polling.LROPoller[~microsoft.fabric.api.ontology.models.Ontology]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        extractor = self.begin_create_ontology(workspace_id=workspace_id, create_ontology_request=create_ontology_request, **kwargs, )

        while extractor.result is None:
            time.sleep(5)

        return extractor.result
        
    
    
    def begin_create_ontology(self, workspace_id: str, create_ontology_request: Union[_models.CreateOntologyRequest, IO[bytes]], **kwargs: Any) -> _LROResultExtractor[_models.Ontology]:
        """Creates an Ontology in the specified workspace.

        ..

           [!NOTE]
           Ontology item is currently in Preview (\ `learn more </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create ontology with definition, refer to `Ontology definition
        </rest/api/fabric/articles/item-management/definitions/ontology-definition>`_.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------


        * To create an ontology the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_ontology_request: Create item request payload. Is either a CreateOntologyRequest
         type or a IO[bytes] type. Required.
        :type create_ontology_request: ~microsoft.fabric.api.ontology.models.CreateOntologyRequest or
         IO[bytes]
        :return: An instance of LROPoller that returns Ontology
        :rtype: ~azure.core.polling.LROPoller[~microsoft.fabric.api.ontology.models.Ontology]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        extractor = _LROResultExtractor[_models.Ontology]()

        poller = super().begin_create_ontology(
            workspace_id=workspace_id,
            create_ontology_request=create_ontology_request,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )

        poller.add_done_callback(extractor)

        return extractor
        
    

    
    def get_ontology_definition(self, workspace_id: str, ontology_id: str, *, format: Optional[str] = None, **kwargs: Any) -> _models.OntologyDefinitionResponse:
        """Returns the specified Ontology public definition.

        ..

           [!NOTE]
           Ontology item is currently in Preview (\ `learn more </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        When you get an ontology public definition, the sensitivity label is not a part of the
        definition.

        Permissions
        -----------

         The caller must have *read and write* permissions for the ontology.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------

         This API is blocked for an ontology with an encrypted sensitivity label.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param ontology_id: The ontology ID. Required.
        :type ontology_id: str
        :keyword format: The format of the Ontology public definition. Default value is None.
        :paramtype format: str
        :return: An instance of LROPoller that returns OntologyDefinitionResponse
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.ontology.models.OntologyDefinitionResponse]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        extractor = self.begin_get_ontology_definition(workspace_id=workspace_id, ontology_id=ontology_id, format=format, **kwargs, )

        while extractor.result is None:
            time.sleep(5)

        return extractor.result
        
    
    
    def begin_get_ontology_definition(self, workspace_id: str, ontology_id: str, *, format: Optional[str] = None, **kwargs: Any) -> _LROResultExtractor[_models.OntologyDefinitionResponse]:
        """Returns the specified Ontology public definition.

        ..

           [!NOTE]
           Ontology item is currently in Preview (\ `learn more </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        When you get an ontology public definition, the sensitivity label is not a part of the
        definition.

        Permissions
        -----------

         The caller must have *read and write* permissions for the ontology.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------

         This API is blocked for an ontology with an encrypted sensitivity label.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param ontology_id: The ontology ID. Required.
        :type ontology_id: str
        :keyword format: The format of the Ontology public definition. Default value is None.
        :paramtype format: str
        :return: An instance of LROPoller that returns OntologyDefinitionResponse
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.ontology.models.OntologyDefinitionResponse]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        extractor = _LROResultExtractor[_models.OntologyDefinitionResponse]()

        poller = super().begin_get_ontology_definition(
            workspace_id=workspace_id,
            ontology_id=ontology_id,
            format=format,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )

        poller.add_done_callback(extractor)

        return extractor
        
    

    
    def update_ontology_definition(self, workspace_id: str, ontology_id: str, update_ontology_definition_request: _models.UpdateOntologyDefinitionRequest, *, update_metadata: Optional[bool] = None, content_type: str = 'application/json', **kwargs: Any) -> None:
        """Updates the definition of a specified Ontology. The update overrides the current definition.

        ..

           [!NOTE]
           Ontology item is currently in Preview (\ `learn more </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the ontology definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the ontology.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param ontology_id: The ontology ID. Required.
        :type ontology_id: str
        :param update_ontology_definition_request: Update ontology definition request payload.
         Required.
        :type update_ontology_definition_request:
         ~microsoft.fabric.api.ontology.models.UpdateOntologyDefinitionRequest
        :keyword update_metadata: Whether to update the item's metadata if it is provided in the
         ``.platform`` file. True - Update the metadata if it is provided in the ``.platform`` file as
         part of the definition, False - Do not update the metadata. Default value is None.
        :paramtype update_metadata: bool
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        poller = self.begin_update_ontology_definition(
            workspace_id=workspace_id,
            ontology_id=ontology_id,
            update_ontology_definition_request=update_ontology_definition_request,
            update_metadata=update_metadata,
            content_type=content_type,
            **kwargs,
            )
        
        while not poller.done():
            time.sleep(5)

        
    
    
    def begin_update_ontology_definition(self, workspace_id: str, ontology_id: str, update_ontology_definition_request: _models.UpdateOntologyDefinitionRequest, *, update_metadata: Optional[bool] = None, content_type: str = 'application/json', **kwargs: Any) -> LROPoller[None]:
        """Updates the definition of a specified Ontology. The update overrides the current definition.

        ..

           [!NOTE]
           Ontology item is currently in Preview (\ `learn more </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the ontology definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the ontology.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param ontology_id: The ontology ID. Required.
        :type ontology_id: str
        :param update_ontology_definition_request: Update ontology definition request payload.
         Required.
        :type update_ontology_definition_request:
         ~microsoft.fabric.api.ontology.models.UpdateOntologyDefinitionRequest
        :keyword update_metadata: Whether to update the item's metadata if it is provided in the
         ``.platform`` file. True - Update the metadata if it is provided in the ``.platform`` file as
         part of the definition, False - Do not update the metadata. Default value is None.
        :paramtype update_metadata: bool
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        return super().begin_update_ontology_definition(
            workspace_id=workspace_id,
            ontology_id=ontology_id,
            update_ontology_definition_request=update_ontology_definition_request,
            update_metadata=update_metadata,
            content_type=content_type,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )
        
    

    
    def update_ontology_definition(self, workspace_id: str, ontology_id: str, update_ontology_definition_request: IO[bytes], *, update_metadata: Optional[bool] = None, content_type: str = 'application/json', **kwargs: Any) -> None:
        """Updates the definition of a specified Ontology. The update overrides the current definition.

        ..

           [!NOTE]
           Ontology item is currently in Preview (\ `learn more </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the ontology definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the ontology.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param ontology_id: The ontology ID. Required.
        :type ontology_id: str
        :param update_ontology_definition_request: Update ontology definition request payload.
         Required.
        :type update_ontology_definition_request: IO[bytes]
        :keyword update_metadata: Whether to update the item's metadata if it is provided in the
         ``.platform`` file. True - Update the metadata if it is provided in the ``.platform`` file as
         part of the definition, False - Do not update the metadata. Default value is None.
        :paramtype update_metadata: bool
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        poller = self.begin_update_ontology_definition(
            workspace_id=workspace_id,
            ontology_id=ontology_id,
            update_ontology_definition_request=update_ontology_definition_request,
            update_metadata=update_metadata,
            content_type=content_type,
            **kwargs,
            )
        
        while not poller.done():
            time.sleep(5)

        
    
    
    def begin_update_ontology_definition(self, workspace_id: str, ontology_id: str, update_ontology_definition_request: IO[bytes], *, update_metadata: Optional[bool] = None, content_type: str = 'application/json', **kwargs: Any) -> LROPoller[None]:
        """Updates the definition of a specified Ontology. The update overrides the current definition.

        ..

           [!NOTE]
           Ontology item is currently in Preview (\ `learn more </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the ontology definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the ontology.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param ontology_id: The ontology ID. Required.
        :type ontology_id: str
        :param update_ontology_definition_request: Update ontology definition request payload.
         Required.
        :type update_ontology_definition_request: IO[bytes]
        :keyword update_metadata: Whether to update the item's metadata if it is provided in the
         ``.platform`` file. True - Update the metadata if it is provided in the ``.platform`` file as
         part of the definition, False - Do not update the metadata. Default value is None.
        :paramtype update_metadata: bool
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        return super().begin_update_ontology_definition(
            workspace_id=workspace_id,
            ontology_id=ontology_id,
            update_ontology_definition_request=update_ontology_definition_request,
            update_metadata=update_metadata,
            content_type=content_type,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )
        
    

    
    def update_ontology_definition(self, workspace_id: str, ontology_id: str, update_ontology_definition_request: Union[_models.UpdateOntologyDefinitionRequest, IO[bytes]], *, update_metadata: Optional[bool] = None, **kwargs: Any) -> None:
        """Updates the definition of a specified Ontology. The update overrides the current definition.

        ..

           [!NOTE]
           Ontology item is currently in Preview (\ `learn more </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the ontology definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the ontology.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param ontology_id: The ontology ID. Required.
        :type ontology_id: str
        :param update_ontology_definition_request: Update ontology definition request payload. Is
         either a UpdateOntologyDefinitionRequest type or a IO[bytes] type. Required.
        :type update_ontology_definition_request:
         ~microsoft.fabric.api.ontology.models.UpdateOntologyDefinitionRequest or IO[bytes]
        :keyword update_metadata: Whether to update the item's metadata if it is provided in the
         ``.platform`` file. True - Update the metadata if it is provided in the ``.platform`` file as
         part of the definition, False - Do not update the metadata. Default value is None.
        :paramtype update_metadata: bool
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        poller = self.begin_update_ontology_definition(
            workspace_id=workspace_id,
            ontology_id=ontology_id,
            update_ontology_definition_request=update_ontology_definition_request,
            update_metadata=update_metadata,
            **kwargs,
            )
        
        while not poller.done():
            time.sleep(5)

        
    
    
    def begin_update_ontology_definition(self, workspace_id: str, ontology_id: str, update_ontology_definition_request: Union[_models.UpdateOntologyDefinitionRequest, IO[bytes]], *, update_metadata: Optional[bool] = None, **kwargs: Any) -> LROPoller[None]:
        """Updates the definition of a specified Ontology. The update overrides the current definition.

        ..

           [!NOTE]
           Ontology item is currently in Preview (\ `learn more </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the ontology definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the ontology.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param ontology_id: The ontology ID. Required.
        :type ontology_id: str
        :param update_ontology_definition_request: Update ontology definition request payload. Is
         either a UpdateOntologyDefinitionRequest type or a IO[bytes] type. Required.
        :type update_ontology_definition_request:
         ~microsoft.fabric.api.ontology.models.UpdateOntologyDefinitionRequest or IO[bytes]
        :keyword update_metadata: Whether to update the item's metadata if it is provided in the
         ``.platform`` file. True - Update the metadata if it is provided in the ``.platform`` file as
         part of the definition, False - Do not update the metadata. Default value is None.
        :paramtype update_metadata: bool
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        return super().begin_update_ontology_definition(
            workspace_id=workspace_id,
            ontology_id=ontology_id,
            update_ontology_definition_request=update_ontology_definition_request,
            update_metadata=update_metadata,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )
        
    
