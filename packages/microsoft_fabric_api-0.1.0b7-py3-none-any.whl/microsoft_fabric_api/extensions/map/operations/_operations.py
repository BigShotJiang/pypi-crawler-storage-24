from ....generated.map.operations import *
from ....generated.map import operations as _operations
from ....generated.map import models as _models
from azure.core.polling.base_polling import LROBasePolling, OperationResourcePolling, StatusCheckPolling
from azure.core.polling import LROPoller
from ....fabric_api_utils import _LROResultExtractor
from typing import *
import time



class ItemsOperations(_operations.ItemsOperations):
    """ItemsOperations for Map."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    

    
    def create_map(self, workspace_id: str, create_map_request: _models.CreateMapRequest, *, content_type: str = 'application/json', **kwargs: Any) -> _models.Map:
        """Creates a Map in the specified workspace.

        ..

           [!NOTE]
           Map item is currently in Preview (\ `learn more </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create Map with a public definition, refer to `Map
        </rest/api/fabric/articles/item-management/definitions/map-definition>`_ article.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------


        * To create a Map the workspace must be on a supported Fabric capacity. For more information
        see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_map_request: Create item request payload. Required.
        :type create_map_request: ~microsoft.fabric.api.map.models.CreateMapRequest
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns Map
        :rtype: ~azure.core.polling.LROPoller[~microsoft.fabric.api.map.models.Map]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        extractor = self.begin_create_map(workspace_id=workspace_id, create_map_request=create_map_request, content_type=content_type, **kwargs, )

        while extractor.result is None:
            time.sleep(5)

        return extractor.result
        
    
    
    def begin_create_map(self, workspace_id: str, create_map_request: _models.CreateMapRequest, *, content_type: str = 'application/json', **kwargs: Any) -> _LROResultExtractor[_models.Map]:
        """Creates a Map in the specified workspace.

        ..

           [!NOTE]
           Map item is currently in Preview (\ `learn more </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create Map with a public definition, refer to `Map
        </rest/api/fabric/articles/item-management/definitions/map-definition>`_ article.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------


        * To create a Map the workspace must be on a supported Fabric capacity. For more information
        see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_map_request: Create item request payload. Required.
        :type create_map_request: ~microsoft.fabric.api.map.models.CreateMapRequest
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns Map
        :rtype: ~azure.core.polling.LROPoller[~microsoft.fabric.api.map.models.Map]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        extractor = _LROResultExtractor[_models.Map]()

        poller = super().begin_create_map(
            workspace_id=workspace_id,
            create_map_request=create_map_request,
            content_type=content_type,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )

        poller.add_done_callback(extractor)

        return extractor
        
    

    
    def create_map(self, workspace_id: str, create_map_request: IO[bytes], *, content_type: str = 'application/json', **kwargs: Any) -> _models.Map:
        """Creates a Map in the specified workspace.

        ..

           [!NOTE]
           Map item is currently in Preview (\ `learn more </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create Map with a public definition, refer to `Map
        </rest/api/fabric/articles/item-management/definitions/map-definition>`_ article.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------


        * To create a Map the workspace must be on a supported Fabric capacity. For more information
        see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_map_request: Create item request payload. Required.
        :type create_map_request: IO[bytes]
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns Map
        :rtype: ~azure.core.polling.LROPoller[~microsoft.fabric.api.map.models.Map]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        extractor = self.begin_create_map(workspace_id=workspace_id, create_map_request=create_map_request, content_type=content_type, **kwargs, )

        while extractor.result is None:
            time.sleep(5)

        return extractor.result
        
    
    
    def begin_create_map(self, workspace_id: str, create_map_request: IO[bytes], *, content_type: str = 'application/json', **kwargs: Any) -> _LROResultExtractor[_models.Map]:
        """Creates a Map in the specified workspace.

        ..

           [!NOTE]
           Map item is currently in Preview (\ `learn more </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create Map with a public definition, refer to `Map
        </rest/api/fabric/articles/item-management/definitions/map-definition>`_ article.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------


        * To create a Map the workspace must be on a supported Fabric capacity. For more information
        see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_map_request: Create item request payload. Required.
        :type create_map_request: IO[bytes]
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns Map
        :rtype: ~azure.core.polling.LROPoller[~microsoft.fabric.api.map.models.Map]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        extractor = _LROResultExtractor[_models.Map]()

        poller = super().begin_create_map(
            workspace_id=workspace_id,
            create_map_request=create_map_request,
            content_type=content_type,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )

        poller.add_done_callback(extractor)

        return extractor
        
    

    
    def create_map(self, workspace_id: str, create_map_request: Union[_models.CreateMapRequest, IO[bytes]], **kwargs: Any) -> _models.Map:
        """Creates a Map in the specified workspace.

        ..

           [!NOTE]
           Map item is currently in Preview (\ `learn more </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create Map with a public definition, refer to `Map
        </rest/api/fabric/articles/item-management/definitions/map-definition>`_ article.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------


        * To create a Map the workspace must be on a supported Fabric capacity. For more information
        see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_map_request: Create item request payload. Is either a CreateMapRequest type or a
         IO[bytes] type. Required.
        :type create_map_request: ~microsoft.fabric.api.map.models.CreateMapRequest or IO[bytes]
        :return: An instance of LROPoller that returns Map
        :rtype: ~azure.core.polling.LROPoller[~microsoft.fabric.api.map.models.Map]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        extractor = self.begin_create_map(workspace_id=workspace_id, create_map_request=create_map_request, **kwargs, )

        while extractor.result is None:
            time.sleep(5)

        return extractor.result
        
    
    
    def begin_create_map(self, workspace_id: str, create_map_request: Union[_models.CreateMapRequest, IO[bytes]], **kwargs: Any) -> _LROResultExtractor[_models.Map]:
        """Creates a Map in the specified workspace.

        ..

           [!NOTE]
           Map item is currently in Preview (\ `learn more </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create Map with a public definition, refer to `Map
        </rest/api/fabric/articles/item-management/definitions/map-definition>`_ article.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------


        * To create a Map the workspace must be on a supported Fabric capacity. For more information
        see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_map_request: Create item request payload. Is either a CreateMapRequest type or a
         IO[bytes] type. Required.
        :type create_map_request: ~microsoft.fabric.api.map.models.CreateMapRequest or IO[bytes]
        :return: An instance of LROPoller that returns Map
        :rtype: ~azure.core.polling.LROPoller[~microsoft.fabric.api.map.models.Map]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        extractor = _LROResultExtractor[_models.Map]()

        poller = super().begin_create_map(
            workspace_id=workspace_id,
            create_map_request=create_map_request,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )

        poller.add_done_callback(extractor)

        return extractor
        
    

    
    def get_map_definition(self, workspace_id: str, map_id: str, *, format: Optional[str] = None, **kwargs: Any) -> _models.MapDefinitionResponse:
        """Returns the specified Map public definition.

        ..

           [!NOTE]
           Map item is currently in Preview (\ `learn more </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        When you get a Map's public definition, the sensitivity label is not a part of the definition.

        Permissions
        -----------

         The caller must have *read and write* permissions for the Map.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param map_id: The Map ID. Required.
        :type map_id: str
        :keyword format: The format of the Map public definition. Additional ``format`` types may be
         added over time. Default value is None.
        :paramtype format: str
        :return: An instance of LROPoller that returns MapDefinitionResponse
        :rtype: ~azure.core.polling.LROPoller[~microsoft.fabric.api.map.models.MapDefinitionResponse]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        extractor = self.begin_get_map_definition(workspace_id=workspace_id, map_id=map_id, format=format, **kwargs, )

        while extractor.result is None:
            time.sleep(5)

        return extractor.result
        
    
    
    def begin_get_map_definition(self, workspace_id: str, map_id: str, *, format: Optional[str] = None, **kwargs: Any) -> _LROResultExtractor[_models.MapDefinitionResponse]:
        """Returns the specified Map public definition.

        ..

           [!NOTE]
           Map item is currently in Preview (\ `learn more </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        When you get a Map's public definition, the sensitivity label is not a part of the definition.

        Permissions
        -----------

         The caller must have *read and write* permissions for the Map.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param map_id: The Map ID. Required.
        :type map_id: str
        :keyword format: The format of the Map public definition. Additional ``format`` types may be
         added over time. Default value is None.
        :paramtype format: str
        :return: An instance of LROPoller that returns MapDefinitionResponse
        :rtype: ~azure.core.polling.LROPoller[~microsoft.fabric.api.map.models.MapDefinitionResponse]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        extractor = _LROResultExtractor[_models.MapDefinitionResponse]()

        poller = super().begin_get_map_definition(
            workspace_id=workspace_id,
            map_id=map_id,
            format=format,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )

        poller.add_done_callback(extractor)

        return extractor
        
    

    
    def update_map_definition(self, workspace_id: str, map_id: str, update_map_definition_request: _models.UpdateMapDefinitionRequest, *, update_metadata: Optional[bool] = None, content_type: str = 'application/json', **kwargs: Any) -> None:
        """Overrides the definition for the specified Map.

        ..

           [!NOTE]
           Map item is currently in Preview (\ `learn more </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the Map's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the Map.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param map_id: The Map ID. Required.
        :type map_id: str
        :param update_map_definition_request: Update Map definition request payload. Required.
        :type update_map_definition_request:
         ~microsoft.fabric.api.map.models.UpdateMapDefinitionRequest
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        poller = self.begin_update_map_definition(
            workspace_id=workspace_id,
            map_id=map_id,
            update_map_definition_request=update_map_definition_request,
            update_metadata=update_metadata,
            content_type=content_type,
            **kwargs,
            )
        
        while not poller.done():
            time.sleep(5)

        
    
    
    def begin_update_map_definition(self, workspace_id: str, map_id: str, update_map_definition_request: _models.UpdateMapDefinitionRequest, *, update_metadata: Optional[bool] = None, content_type: str = 'application/json', **kwargs: Any) -> LROPoller[None]:
        """Overrides the definition for the specified Map.

        ..

           [!NOTE]
           Map item is currently in Preview (\ `learn more </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the Map's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the Map.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param map_id: The Map ID. Required.
        :type map_id: str
        :param update_map_definition_request: Update Map definition request payload. Required.
        :type update_map_definition_request:
         ~microsoft.fabric.api.map.models.UpdateMapDefinitionRequest
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        return super().begin_update_map_definition(
            workspace_id=workspace_id,
            map_id=map_id,
            update_map_definition_request=update_map_definition_request,
            update_metadata=update_metadata,
            content_type=content_type,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )
        
    

    
    def update_map_definition(self, workspace_id: str, map_id: str, update_map_definition_request: IO[bytes], *, update_metadata: Optional[bool] = None, content_type: str = 'application/json', **kwargs: Any) -> None:
        """Overrides the definition for the specified Map.

        ..

           [!NOTE]
           Map item is currently in Preview (\ `learn more </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the Map's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the Map.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param map_id: The Map ID. Required.
        :type map_id: str
        :param update_map_definition_request: Update Map definition request payload. Required.
        :type update_map_definition_request: IO[bytes]
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        poller = self.begin_update_map_definition(
            workspace_id=workspace_id,
            map_id=map_id,
            update_map_definition_request=update_map_definition_request,
            update_metadata=update_metadata,
            content_type=content_type,
            **kwargs,
            )
        
        while not poller.done():
            time.sleep(5)

        
    
    
    def begin_update_map_definition(self, workspace_id: str, map_id: str, update_map_definition_request: IO[bytes], *, update_metadata: Optional[bool] = None, content_type: str = 'application/json', **kwargs: Any) -> LROPoller[None]:
        """Overrides the definition for the specified Map.

        ..

           [!NOTE]
           Map item is currently in Preview (\ `learn more </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the Map's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the Map.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param map_id: The Map ID. Required.
        :type map_id: str
        :param update_map_definition_request: Update Map definition request payload. Required.
        :type update_map_definition_request: IO[bytes]
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        return super().begin_update_map_definition(
            workspace_id=workspace_id,
            map_id=map_id,
            update_map_definition_request=update_map_definition_request,
            update_metadata=update_metadata,
            content_type=content_type,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )
        
    

    
    def update_map_definition(self, workspace_id: str, map_id: str, update_map_definition_request: Union[_models.UpdateMapDefinitionRequest, IO[bytes]], *, update_metadata: Optional[bool] = None, **kwargs: Any) -> None:
        """Overrides the definition for the specified Map.

        ..

           [!NOTE]
           Map item is currently in Preview (\ `learn more </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the Map's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the Map.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param map_id: The Map ID. Required.
        :type map_id: str
        :param update_map_definition_request: Update Map definition request payload. Is either a
         UpdateMapDefinitionRequest type or a IO[bytes] type. Required.
        :type update_map_definition_request:
         ~microsoft.fabric.api.map.models.UpdateMapDefinitionRequest or IO[bytes]
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        poller = self.begin_update_map_definition(
            workspace_id=workspace_id,
            map_id=map_id,
            update_map_definition_request=update_map_definition_request,
            update_metadata=update_metadata,
            **kwargs,
            )
        
        while not poller.done():
            time.sleep(5)

        
    
    
    def begin_update_map_definition(self, workspace_id: str, map_id: str, update_map_definition_request: Union[_models.UpdateMapDefinitionRequest, IO[bytes]], *, update_metadata: Optional[bool] = None, **kwargs: Any) -> LROPoller[None]:
        """Overrides the definition for the specified Map.

        ..

           [!NOTE]
           Map item is currently in Preview (\ `learn more </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the Map's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the Map.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param map_id: The Map ID. Required.
        :type map_id: str
        :param update_map_definition_request: Update Map definition request payload. Is either a
         UpdateMapDefinitionRequest type or a IO[bytes] type. Required.
        :type update_map_definition_request:
         ~microsoft.fabric.api.map.models.UpdateMapDefinitionRequest or IO[bytes]
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        return super().begin_update_map_definition(
            workspace_id=workspace_id,
            map_id=map_id,
            update_map_definition_request=update_map_definition_request,
            update_metadata=update_metadata,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )
        
    
