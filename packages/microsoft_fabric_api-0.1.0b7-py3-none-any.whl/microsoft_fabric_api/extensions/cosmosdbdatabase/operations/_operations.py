from ....generated.cosmosdbdatabase.operations import *
from ....generated.cosmosdbdatabase import operations as _operations
from ....generated.cosmosdbdatabase import models as _models
from azure.core.polling.base_polling import LROBasePolling, OperationResourcePolling, StatusCheckPolling
from azure.core.polling import LROPoller
from ....fabric_api_utils import _LROResultExtractor
from typing import *
import time



class ItemsOperations(_operations.ItemsOperations):
    """ItemsOperations for Cosmosdbdatabase."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    

    
    def create_cosmos_db_database(self, workspace_id: str, create_cosmos_db_database_request: _models.CreateCosmosDBDatabaseRequest, *, content_type: str = 'application/json', **kwargs: Any) -> _models.CosmosDBDatabase:
        """Creates a Cosmos DB database in the specified workspace.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------


        * To create a Cosmos DB database the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_cosmos_db_database_request: Create item request payload. Required.
        :type create_cosmos_db_database_request:
         ~microsoft.fabric.api.CosmosDBDatabase.models.CreateCosmosDBDatabaseRequest
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns CosmosDBDatabase
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.CosmosDBDatabase.models.CosmosDBDatabase]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        extractor = self.begin_create_cosmos_db_database(workspace_id=workspace_id, create_cosmos_db_database_request=create_cosmos_db_database_request, content_type=content_type, **kwargs, )

        while extractor.result is None:
            time.sleep(5)

        return extractor.result
        
    
    
    def begin_create_cosmos_db_database(self, workspace_id: str, create_cosmos_db_database_request: _models.CreateCosmosDBDatabaseRequest, *, content_type: str = 'application/json', **kwargs: Any) -> _LROResultExtractor[_models.CosmosDBDatabase]:
        """Creates a Cosmos DB database in the specified workspace.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------


        * To create a Cosmos DB database the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_cosmos_db_database_request: Create item request payload. Required.
        :type create_cosmos_db_database_request:
         ~microsoft.fabric.api.CosmosDBDatabase.models.CreateCosmosDBDatabaseRequest
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns CosmosDBDatabase
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.CosmosDBDatabase.models.CosmosDBDatabase]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        extractor = _LROResultExtractor[_models.CosmosDBDatabase]()

        poller = super().begin_create_cosmos_db_database(
            workspace_id=workspace_id,
            create_cosmos_db_database_request=create_cosmos_db_database_request,
            content_type=content_type,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )

        poller.add_done_callback(extractor)

        return extractor
        
    

    
    def create_cosmos_db_database(self, workspace_id: str, create_cosmos_db_database_request: IO[bytes], *, content_type: str = 'application/json', **kwargs: Any) -> _models.CosmosDBDatabase:
        """Creates a Cosmos DB database in the specified workspace.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------


        * To create a Cosmos DB database the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_cosmos_db_database_request: Create item request payload. Required.
        :type create_cosmos_db_database_request: IO[bytes]
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns CosmosDBDatabase
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.CosmosDBDatabase.models.CosmosDBDatabase]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        extractor = self.begin_create_cosmos_db_database(workspace_id=workspace_id, create_cosmos_db_database_request=create_cosmos_db_database_request, content_type=content_type, **kwargs, )

        while extractor.result is None:
            time.sleep(5)

        return extractor.result
        
    
    
    def begin_create_cosmos_db_database(self, workspace_id: str, create_cosmos_db_database_request: IO[bytes], *, content_type: str = 'application/json', **kwargs: Any) -> _LROResultExtractor[_models.CosmosDBDatabase]:
        """Creates a Cosmos DB database in the specified workspace.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------


        * To create a Cosmos DB database the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_cosmos_db_database_request: Create item request payload. Required.
        :type create_cosmos_db_database_request: IO[bytes]
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns CosmosDBDatabase
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.CosmosDBDatabase.models.CosmosDBDatabase]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        extractor = _LROResultExtractor[_models.CosmosDBDatabase]()

        poller = super().begin_create_cosmos_db_database(
            workspace_id=workspace_id,
            create_cosmos_db_database_request=create_cosmos_db_database_request,
            content_type=content_type,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )

        poller.add_done_callback(extractor)

        return extractor
        
    

    
    def create_cosmos_db_database(self, workspace_id: str, create_cosmos_db_database_request: Union[_models.CreateCosmosDBDatabaseRequest, IO[bytes]], **kwargs: Any) -> _models.CosmosDBDatabase:
        """Creates a Cosmos DB database in the specified workspace.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------


        * To create a Cosmos DB database the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_cosmos_db_database_request: Create item request payload. Is either a
         CreateCosmosDBDatabaseRequest type or a IO[bytes] type. Required.
        :type create_cosmos_db_database_request:
         ~microsoft.fabric.api.CosmosDBDatabase.models.CreateCosmosDBDatabaseRequest or IO[bytes]
        :return: An instance of LROPoller that returns CosmosDBDatabase
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.CosmosDBDatabase.models.CosmosDBDatabase]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        extractor = self.begin_create_cosmos_db_database(workspace_id=workspace_id, create_cosmos_db_database_request=create_cosmos_db_database_request, **kwargs, )

        while extractor.result is None:
            time.sleep(5)

        return extractor.result
        
    
    
    def begin_create_cosmos_db_database(self, workspace_id: str, create_cosmos_db_database_request: Union[_models.CreateCosmosDBDatabaseRequest, IO[bytes]], **kwargs: Any) -> _LROResultExtractor[_models.CosmosDBDatabase]:
        """Creates a Cosmos DB database in the specified workspace.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------


        * To create a Cosmos DB database the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_cosmos_db_database_request: Create item request payload. Is either a
         CreateCosmosDBDatabaseRequest type or a IO[bytes] type. Required.
        :type create_cosmos_db_database_request:
         ~microsoft.fabric.api.CosmosDBDatabase.models.CreateCosmosDBDatabaseRequest or IO[bytes]
        :return: An instance of LROPoller that returns CosmosDBDatabase
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.CosmosDBDatabase.models.CosmosDBDatabase]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        extractor = _LROResultExtractor[_models.CosmosDBDatabase]()

        poller = super().begin_create_cosmos_db_database(
            workspace_id=workspace_id,
            create_cosmos_db_database_request=create_cosmos_db_database_request,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )

        poller.add_done_callback(extractor)

        return extractor
        
    

    
    def get_cosmos_db_database_definition(self, workspace_id: str, cosmos_db_database_id: str, **kwargs: Any) -> _models.CosmosDBDatabaseDefinitionResponse:
        """Returns the specified Cosmos DB database public definition.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        When you get a Cosmos DB database's public definition, the sensitivity label is not a part of
        the definition.

        Permissions
        -----------

         The caller must have *read and write* permissions for the CosmosDBDatabase.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------

         This API is blocked for a notebook with an encrypted sensitivity label.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param cosmos_db_database_id: The Cosmos DB database ID. Required.
        :type cosmos_db_database_id: str
        :return: An instance of LROPoller that returns CosmosDBDatabaseDefinitionResponse
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.CosmosDBDatabase.models.CosmosDBDatabaseDefinitionResponse]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        extractor = self.begin_get_cosmos_db_database_definition(workspace_id=workspace_id, cosmos_db_database_id=cosmos_db_database_id, **kwargs, )

        while extractor.result is None:
            time.sleep(5)

        return extractor.result
        
    
    
    def begin_get_cosmos_db_database_definition(self, workspace_id: str, cosmos_db_database_id: str, **kwargs: Any) -> _LROResultExtractor[_models.CosmosDBDatabaseDefinitionResponse]:
        """Returns the specified Cosmos DB database public definition.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        When you get a Cosmos DB database's public definition, the sensitivity label is not a part of
        the definition.

        Permissions
        -----------

         The caller must have *read and write* permissions for the CosmosDBDatabase.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------

         This API is blocked for a notebook with an encrypted sensitivity label.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param cosmos_db_database_id: The Cosmos DB database ID. Required.
        :type cosmos_db_database_id: str
        :return: An instance of LROPoller that returns CosmosDBDatabaseDefinitionResponse
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.CosmosDBDatabase.models.CosmosDBDatabaseDefinitionResponse]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        extractor = _LROResultExtractor[_models.CosmosDBDatabaseDefinitionResponse]()

        poller = super().begin_get_cosmos_db_database_definition(
            workspace_id=workspace_id,
            cosmos_db_database_id=cosmos_db_database_id,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )

        poller.add_done_callback(extractor)

        return extractor
        
    

    
    def update_cosmos_db_database_definition(self, workspace_id: str, cosmos_db_database_id: str, update_cosmos_db_database_definition_request: _models.UpdateCosmosDBDatabaseDefinitionRequest, *, update_metadata: Optional[bool] = None, content_type: str = 'application/json', **kwargs: Any) -> None:
        """Overrides the definition for the specified Cosmos DB database.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the Cosmos DB database's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the CosmosDBDatabase.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param cosmos_db_database_id: The Cosmos DB database ID. Required.
        :type cosmos_db_database_id: str
        :param update_cosmos_db_database_definition_request: Update Cosmos DB database request payload.
         Required.
        :type update_cosmos_db_database_definition_request:
         ~microsoft.fabric.api.CosmosDBDatabase.models.UpdateCosmosDBDatabaseDefinitionRequest
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file.

         ..

            NOTE:
            The CosmosDBDatabase item type does not support renaming via the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        poller = self.begin_update_cosmos_db_database_definition(
            workspace_id=workspace_id,
            cosmos_db_database_id=cosmos_db_database_id,
            update_cosmos_db_database_definition_request=update_cosmos_db_database_definition_request,
            update_metadata=update_metadata,
            content_type=content_type,
            **kwargs,
            )
        
        while not poller.done():
            time.sleep(5)

        
    
    
    def begin_update_cosmos_db_database_definition(self, workspace_id: str, cosmos_db_database_id: str, update_cosmos_db_database_definition_request: _models.UpdateCosmosDBDatabaseDefinitionRequest, *, update_metadata: Optional[bool] = None, content_type: str = 'application/json', **kwargs: Any) -> LROPoller[None]:
        """Overrides the definition for the specified Cosmos DB database.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the Cosmos DB database's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the CosmosDBDatabase.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param cosmos_db_database_id: The Cosmos DB database ID. Required.
        :type cosmos_db_database_id: str
        :param update_cosmos_db_database_definition_request: Update Cosmos DB database request payload.
         Required.
        :type update_cosmos_db_database_definition_request:
         ~microsoft.fabric.api.CosmosDBDatabase.models.UpdateCosmosDBDatabaseDefinitionRequest
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file.

         ..

            NOTE:
            The CosmosDBDatabase item type does not support renaming via the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        return super().begin_update_cosmos_db_database_definition(
            workspace_id=workspace_id,
            cosmos_db_database_id=cosmos_db_database_id,
            update_cosmos_db_database_definition_request=update_cosmos_db_database_definition_request,
            update_metadata=update_metadata,
            content_type=content_type,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )
        
    

    
    def update_cosmos_db_database_definition(self, workspace_id: str, cosmos_db_database_id: str, update_cosmos_db_database_definition_request: IO[bytes], *, update_metadata: Optional[bool] = None, content_type: str = 'application/json', **kwargs: Any) -> None:
        """Overrides the definition for the specified Cosmos DB database.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the Cosmos DB database's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the CosmosDBDatabase.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param cosmos_db_database_id: The Cosmos DB database ID. Required.
        :type cosmos_db_database_id: str
        :param update_cosmos_db_database_definition_request: Update Cosmos DB database request payload.
         Required.
        :type update_cosmos_db_database_definition_request: IO[bytes]
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file.

         ..

            NOTE:
            The CosmosDBDatabase item type does not support renaming via the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        poller = self.begin_update_cosmos_db_database_definition(
            workspace_id=workspace_id,
            cosmos_db_database_id=cosmos_db_database_id,
            update_cosmos_db_database_definition_request=update_cosmos_db_database_definition_request,
            update_metadata=update_metadata,
            content_type=content_type,
            **kwargs,
            )
        
        while not poller.done():
            time.sleep(5)

        
    
    
    def begin_update_cosmos_db_database_definition(self, workspace_id: str, cosmos_db_database_id: str, update_cosmos_db_database_definition_request: IO[bytes], *, update_metadata: Optional[bool] = None, content_type: str = 'application/json', **kwargs: Any) -> LROPoller[None]:
        """Overrides the definition for the specified Cosmos DB database.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the Cosmos DB database's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the CosmosDBDatabase.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param cosmos_db_database_id: The Cosmos DB database ID. Required.
        :type cosmos_db_database_id: str
        :param update_cosmos_db_database_definition_request: Update Cosmos DB database request payload.
         Required.
        :type update_cosmos_db_database_definition_request: IO[bytes]
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file.

         ..

            NOTE:
            The CosmosDBDatabase item type does not support renaming via the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        return super().begin_update_cosmos_db_database_definition(
            workspace_id=workspace_id,
            cosmos_db_database_id=cosmos_db_database_id,
            update_cosmos_db_database_definition_request=update_cosmos_db_database_definition_request,
            update_metadata=update_metadata,
            content_type=content_type,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )
        
    

    
    def update_cosmos_db_database_definition(self, workspace_id: str, cosmos_db_database_id: str, update_cosmos_db_database_definition_request: Union[_models.UpdateCosmosDBDatabaseDefinitionRequest, IO[bytes]], *, update_metadata: Optional[bool] = None, **kwargs: Any) -> None:
        """Overrides the definition for the specified Cosmos DB database.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the Cosmos DB database's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the CosmosDBDatabase.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param cosmos_db_database_id: The Cosmos DB database ID. Required.
        :type cosmos_db_database_id: str
        :param update_cosmos_db_database_definition_request: Update Cosmos DB database request payload.
         Is either a UpdateCosmosDBDatabaseDefinitionRequest type or a IO[bytes] type. Required.
        :type update_cosmos_db_database_definition_request:
         ~microsoft.fabric.api.CosmosDBDatabase.models.UpdateCosmosDBDatabaseDefinitionRequest or
         IO[bytes]
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file.

         ..

            NOTE:
            The CosmosDBDatabase item type does not support renaming via the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        poller = self.begin_update_cosmos_db_database_definition(
            workspace_id=workspace_id,
            cosmos_db_database_id=cosmos_db_database_id,
            update_cosmos_db_database_definition_request=update_cosmos_db_database_definition_request,
            update_metadata=update_metadata,
            **kwargs,
            )
        
        while not poller.done():
            time.sleep(5)

        
    
    
    def begin_update_cosmos_db_database_definition(self, workspace_id: str, cosmos_db_database_id: str, update_cosmos_db_database_definition_request: Union[_models.UpdateCosmosDBDatabaseDefinitionRequest, IO[bytes]], *, update_metadata: Optional[bool] = None, **kwargs: Any) -> LROPoller[None]:
        """Overrides the definition for the specified Cosmos DB database.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the Cosmos DB database's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the CosmosDBDatabase.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param cosmos_db_database_id: The Cosmos DB database ID. Required.
        :type cosmos_db_database_id: str
        :param update_cosmos_db_database_definition_request: Update Cosmos DB database request payload.
         Is either a UpdateCosmosDBDatabaseDefinitionRequest type or a IO[bytes] type. Required.
        :type update_cosmos_db_database_definition_request:
         ~microsoft.fabric.api.CosmosDBDatabase.models.UpdateCosmosDBDatabaseDefinitionRequest or
         IO[bytes]
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file.

         ..

            NOTE:
            The CosmosDBDatabase item type does not support renaming via the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        return super().begin_update_cosmos_db_database_definition(
            workspace_id=workspace_id,
            cosmos_db_database_id=cosmos_db_database_id,
            update_cosmos_db_database_definition_request=update_cosmos_db_database_definition_request,
            update_metadata=update_metadata,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )
        
    
