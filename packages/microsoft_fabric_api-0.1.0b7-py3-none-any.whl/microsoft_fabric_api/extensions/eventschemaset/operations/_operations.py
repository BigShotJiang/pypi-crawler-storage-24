from ....generated.eventschemaset.operations import *
from ....generated.eventschemaset import operations as _operations
from ....generated.eventschemaset import models as _models
from azure.core.polling.base_polling import LROBasePolling, OperationResourcePolling, StatusCheckPolling
from azure.core.polling import LROPoller
from ....fabric_api_utils import _LROResultExtractor
from typing import *
import time



class ItemsOperations(_operations.ItemsOperations):
    """ItemsOperations for Eventschemaset."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    

    
    def create_event_schema_set(self, workspace_id: str, create_event_schema_set_request: _models.CreateEventSchemaSetRequest, *, content_type: str = 'application/json', **kwargs: Any) -> _models.EventSchemaSet:
        """Creates an EventSchemaSet in the specified workspace.

        ..

           [!NOTE]
           EventSchemaSets item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create an EventSchemaSet with a public definition, refer to `EventSchemaSet
        </rest/api/fabric/articles/item-management/definitions/eventschemaset-definition>`_ article.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------


        * To create an EventSchemaSet the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_event_schema_set_request: Create item request payload. Required.
        :type create_event_schema_set_request:
         ~microsoft.fabric.api.EventSchemaSet.models.CreateEventSchemaSetRequest
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns EventSchemaSet
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.EventSchemaSet.models.EventSchemaSet]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        extractor = self.begin_create_event_schema_set(workspace_id=workspace_id, create_event_schema_set_request=create_event_schema_set_request, content_type=content_type, **kwargs, )

        while extractor.result is None:
            time.sleep(5)

        return extractor.result
        
    
    
    def begin_create_event_schema_set(self, workspace_id: str, create_event_schema_set_request: _models.CreateEventSchemaSetRequest, *, content_type: str = 'application/json', **kwargs: Any) -> _LROResultExtractor[_models.EventSchemaSet]:
        """Creates an EventSchemaSet in the specified workspace.

        ..

           [!NOTE]
           EventSchemaSets item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create an EventSchemaSet with a public definition, refer to `EventSchemaSet
        </rest/api/fabric/articles/item-management/definitions/eventschemaset-definition>`_ article.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------


        * To create an EventSchemaSet the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_event_schema_set_request: Create item request payload. Required.
        :type create_event_schema_set_request:
         ~microsoft.fabric.api.EventSchemaSet.models.CreateEventSchemaSetRequest
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns EventSchemaSet
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.EventSchemaSet.models.EventSchemaSet]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        extractor = _LROResultExtractor[_models.EventSchemaSet]()

        poller = super().begin_create_event_schema_set(
            workspace_id=workspace_id,
            create_event_schema_set_request=create_event_schema_set_request,
            content_type=content_type,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )

        poller.add_done_callback(extractor)

        return extractor
        
    

    
    def create_event_schema_set(self, workspace_id: str, create_event_schema_set_request: IO[bytes], *, content_type: str = 'application/json', **kwargs: Any) -> _models.EventSchemaSet:
        """Creates an EventSchemaSet in the specified workspace.

        ..

           [!NOTE]
           EventSchemaSets item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create an EventSchemaSet with a public definition, refer to `EventSchemaSet
        </rest/api/fabric/articles/item-management/definitions/eventschemaset-definition>`_ article.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------


        * To create an EventSchemaSet the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_event_schema_set_request: Create item request payload. Required.
        :type create_event_schema_set_request: IO[bytes]
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns EventSchemaSet
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.EventSchemaSet.models.EventSchemaSet]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        extractor = self.begin_create_event_schema_set(workspace_id=workspace_id, create_event_schema_set_request=create_event_schema_set_request, content_type=content_type, **kwargs, )

        while extractor.result is None:
            time.sleep(5)

        return extractor.result
        
    
    
    def begin_create_event_schema_set(self, workspace_id: str, create_event_schema_set_request: IO[bytes], *, content_type: str = 'application/json', **kwargs: Any) -> _LROResultExtractor[_models.EventSchemaSet]:
        """Creates an EventSchemaSet in the specified workspace.

        ..

           [!NOTE]
           EventSchemaSets item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create an EventSchemaSet with a public definition, refer to `EventSchemaSet
        </rest/api/fabric/articles/item-management/definitions/eventschemaset-definition>`_ article.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------


        * To create an EventSchemaSet the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_event_schema_set_request: Create item request payload. Required.
        :type create_event_schema_set_request: IO[bytes]
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns EventSchemaSet
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.EventSchemaSet.models.EventSchemaSet]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        extractor = _LROResultExtractor[_models.EventSchemaSet]()

        poller = super().begin_create_event_schema_set(
            workspace_id=workspace_id,
            create_event_schema_set_request=create_event_schema_set_request,
            content_type=content_type,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )

        poller.add_done_callback(extractor)

        return extractor
        
    

    
    def create_event_schema_set(self, workspace_id: str, create_event_schema_set_request: Union[_models.CreateEventSchemaSetRequest, IO[bytes]], **kwargs: Any) -> _models.EventSchemaSet:
        """Creates an EventSchemaSet in the specified workspace.

        ..

           [!NOTE]
           EventSchemaSets item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create an EventSchemaSet with a public definition, refer to `EventSchemaSet
        </rest/api/fabric/articles/item-management/definitions/eventschemaset-definition>`_ article.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------


        * To create an EventSchemaSet the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_event_schema_set_request: Create item request payload. Is either a
         CreateEventSchemaSetRequest type or a IO[bytes] type. Required.
        :type create_event_schema_set_request:
         ~microsoft.fabric.api.EventSchemaSet.models.CreateEventSchemaSetRequest or IO[bytes]
        :return: An instance of LROPoller that returns EventSchemaSet
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.EventSchemaSet.models.EventSchemaSet]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        extractor = self.begin_create_event_schema_set(workspace_id=workspace_id, create_event_schema_set_request=create_event_schema_set_request, **kwargs, )

        while extractor.result is None:
            time.sleep(5)

        return extractor.result
        
    
    
    def begin_create_event_schema_set(self, workspace_id: str, create_event_schema_set_request: Union[_models.CreateEventSchemaSetRequest, IO[bytes]], **kwargs: Any) -> _LROResultExtractor[_models.EventSchemaSet]:
        """Creates an EventSchemaSet in the specified workspace.

        ..

           [!NOTE]
           EventSchemaSets item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create an EventSchemaSet with a public definition, refer to `EventSchemaSet
        </rest/api/fabric/articles/item-management/definitions/eventschemaset-definition>`_ article.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Limitations
        -----------


        * To create an EventSchemaSet the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_event_schema_set_request: Create item request payload. Is either a
         CreateEventSchemaSetRequest type or a IO[bytes] type. Required.
        :type create_event_schema_set_request:
         ~microsoft.fabric.api.EventSchemaSet.models.CreateEventSchemaSetRequest or IO[bytes]
        :return: An instance of LROPoller that returns EventSchemaSet
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.EventSchemaSet.models.EventSchemaSet]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        extractor = _LROResultExtractor[_models.EventSchemaSet]()

        poller = super().begin_create_event_schema_set(
            workspace_id=workspace_id,
            create_event_schema_set_request=create_event_schema_set_request,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )

        poller.add_done_callback(extractor)

        return extractor
        
    

    
    def get_event_schema_set_definition(self, workspace_id: str, event_schema_set_id: str, *, format: Optional[str] = None, **kwargs: Any) -> _models.EventSchemaSetDefinitionResponse:
        """Returns the specified EventSchemaSet definition.

        ..

           [!NOTE]
           EventSchemaSets item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        When you get a EventSchemaSet's public definition, the sensitivity label is not a part of the
        definition.

        Permissions
        -----------

         The caller must have *read and write* permissions for the workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param event_schema_set_id: The EventSchemaSet ID. Required.
        :type event_schema_set_id: str
        :keyword format: The format of the EventSchemaSet public definition. Default value is None.
        :paramtype format: str
        :return: An instance of LROPoller that returns EventSchemaSetDefinitionResponse
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.EventSchemaSet.models.EventSchemaSetDefinitionResponse]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        extractor = self.begin_get_event_schema_set_definition(workspace_id=workspace_id, event_schema_set_id=event_schema_set_id, format=format, **kwargs, )

        while extractor.result is None:
            time.sleep(5)

        return extractor.result
        
    
    
    def begin_get_event_schema_set_definition(self, workspace_id: str, event_schema_set_id: str, *, format: Optional[str] = None, **kwargs: Any) -> _LROResultExtractor[_models.EventSchemaSetDefinitionResponse]:
        """Returns the specified EventSchemaSet definition.

        ..

           [!NOTE]
           EventSchemaSets item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        When you get a EventSchemaSet's public definition, the sensitivity label is not a part of the
        definition.

        Permissions
        -----------

         The caller must have *read and write* permissions for the workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param event_schema_set_id: The EventSchemaSet ID. Required.
        :type event_schema_set_id: str
        :keyword format: The format of the EventSchemaSet public definition. Default value is None.
        :paramtype format: str
        :return: An instance of LROPoller that returns EventSchemaSetDefinitionResponse
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.EventSchemaSet.models.EventSchemaSetDefinitionResponse]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        extractor = _LROResultExtractor[_models.EventSchemaSetDefinitionResponse]()

        poller = super().begin_get_event_schema_set_definition(
            workspace_id=workspace_id,
            event_schema_set_id=event_schema_set_id,
            format=format,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )

        poller.add_done_callback(extractor)

        return extractor
        
    

    
    def update_event_schema_set_definition(self, workspace_id: str, event_schema_set_id: str, update_event_schema_set_definition_request: _models.UpdateEventSchemaSetDefinitionRequest, *, update_metadata: Optional[bool] = None, content_type: str = 'application/json', **kwargs: Any) -> None:
        """Overrides the definition for the specified EventSchemaSet.

        ..

           [!NOTE]
           EventSchemaSets item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the EventSchemaSet's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param event_schema_set_id: The EventSchemaSet ID. Required.
        :type event_schema_set_id: str
        :param update_event_schema_set_definition_request: Update EventSchemaSet definition request
         payload. Required.
        :type update_event_schema_set_definition_request:
         ~microsoft.fabric.api.EventSchemaSet.models.UpdateEventSchemaSetDefinitionRequest
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        poller = self.begin_update_event_schema_set_definition(
            workspace_id=workspace_id,
            event_schema_set_id=event_schema_set_id,
            update_event_schema_set_definition_request=update_event_schema_set_definition_request,
            update_metadata=update_metadata,
            content_type=content_type,
            **kwargs,
            )
        
        while not poller.done():
            time.sleep(5)

        
    
    
    def begin_update_event_schema_set_definition(self, workspace_id: str, event_schema_set_id: str, update_event_schema_set_definition_request: _models.UpdateEventSchemaSetDefinitionRequest, *, update_metadata: Optional[bool] = None, content_type: str = 'application/json', **kwargs: Any) -> LROPoller[None]:
        """Overrides the definition for the specified EventSchemaSet.

        ..

           [!NOTE]
           EventSchemaSets item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the EventSchemaSet's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param event_schema_set_id: The EventSchemaSet ID. Required.
        :type event_schema_set_id: str
        :param update_event_schema_set_definition_request: Update EventSchemaSet definition request
         payload. Required.
        :type update_event_schema_set_definition_request:
         ~microsoft.fabric.api.EventSchemaSet.models.UpdateEventSchemaSetDefinitionRequest
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        return super().begin_update_event_schema_set_definition(
            workspace_id=workspace_id,
            event_schema_set_id=event_schema_set_id,
            update_event_schema_set_definition_request=update_event_schema_set_definition_request,
            update_metadata=update_metadata,
            content_type=content_type,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )
        
    

    
    def update_event_schema_set_definition(self, workspace_id: str, event_schema_set_id: str, update_event_schema_set_definition_request: IO[bytes], *, update_metadata: Optional[bool] = None, content_type: str = 'application/json', **kwargs: Any) -> None:
        """Overrides the definition for the specified EventSchemaSet.

        ..

           [!NOTE]
           EventSchemaSets item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the EventSchemaSet's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param event_schema_set_id: The EventSchemaSet ID. Required.
        :type event_schema_set_id: str
        :param update_event_schema_set_definition_request: Update EventSchemaSet definition request
         payload. Required.
        :type update_event_schema_set_definition_request: IO[bytes]
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        poller = self.begin_update_event_schema_set_definition(
            workspace_id=workspace_id,
            event_schema_set_id=event_schema_set_id,
            update_event_schema_set_definition_request=update_event_schema_set_definition_request,
            update_metadata=update_metadata,
            content_type=content_type,
            **kwargs,
            )
        
        while not poller.done():
            time.sleep(5)

        
    
    
    def begin_update_event_schema_set_definition(self, workspace_id: str, event_schema_set_id: str, update_event_schema_set_definition_request: IO[bytes], *, update_metadata: Optional[bool] = None, content_type: str = 'application/json', **kwargs: Any) -> LROPoller[None]:
        """Overrides the definition for the specified EventSchemaSet.

        ..

           [!NOTE]
           EventSchemaSets item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the EventSchemaSet's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param event_schema_set_id: The EventSchemaSet ID. Required.
        :type event_schema_set_id: str
        :param update_event_schema_set_definition_request: Update EventSchemaSet definition request
         payload. Required.
        :type update_event_schema_set_definition_request: IO[bytes]
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        return super().begin_update_event_schema_set_definition(
            workspace_id=workspace_id,
            event_schema_set_id=event_schema_set_id,
            update_event_schema_set_definition_request=update_event_schema_set_definition_request,
            update_metadata=update_metadata,
            content_type=content_type,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )
        
    

    
    def update_event_schema_set_definition(self, workspace_id: str, event_schema_set_id: str, update_event_schema_set_definition_request: Union[_models.UpdateEventSchemaSetDefinitionRequest, IO[bytes]], *, update_metadata: Optional[bool] = None, **kwargs: Any) -> None:
        """Overrides the definition for the specified EventSchemaSet.

        ..

           [!NOTE]
           EventSchemaSets item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the EventSchemaSet's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param event_schema_set_id: The EventSchemaSet ID. Required.
        :type event_schema_set_id: str
        :param update_event_schema_set_definition_request: Update EventSchemaSet definition request
         payload. Is either a UpdateEventSchemaSetDefinitionRequest type or a IO[bytes] type. Required.
        :type update_event_schema_set_definition_request:
         ~microsoft.fabric.api.EventSchemaSet.models.UpdateEventSchemaSetDefinitionRequest or IO[bytes]
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        poller = self.begin_update_event_schema_set_definition(
            workspace_id=workspace_id,
            event_schema_set_id=event_schema_set_id,
            update_event_schema_set_definition_request=update_event_schema_set_definition_request,
            update_metadata=update_metadata,
            **kwargs,
            )
        
        while not poller.done():
            time.sleep(5)

        
    
    
    def begin_update_event_schema_set_definition(self, workspace_id: str, event_schema_set_id: str, update_event_schema_set_definition_request: Union[_models.UpdateEventSchemaSetDefinitionRequest, IO[bytes]], *, update_metadata: Optional[bool] = None, **kwargs: Any) -> LROPoller[None]:
        """Overrides the definition for the specified EventSchemaSet.

        ..

           [!NOTE]
           EventSchemaSets item is currently in Preview (\ `learn more
        </fabric/fundamentals/preview>`_\ ).


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the EventSchemaSet's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the workspace role.

        Required Delegated Scopes
        -------------------------

         Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - No


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param event_schema_set_id: The EventSchemaSet ID. Required.
        :type event_schema_set_id: str
        :param update_event_schema_set_definition_request: Update EventSchemaSet definition request
         payload. Is either a UpdateEventSchemaSetDefinitionRequest type or a IO[bytes] type. Required.
        :type update_event_schema_set_definition_request:
         ~microsoft.fabric.api.EventSchemaSet.models.UpdateEventSchemaSetDefinitionRequest or IO[bytes]
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        return super().begin_update_event_schema_set_definition(
            workspace_id=workspace_id,
            event_schema_set_id=event_schema_set_id,
            update_event_schema_set_definition_request=update_event_schema_set_definition_request,
            update_metadata=update_metadata,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )
        
    
