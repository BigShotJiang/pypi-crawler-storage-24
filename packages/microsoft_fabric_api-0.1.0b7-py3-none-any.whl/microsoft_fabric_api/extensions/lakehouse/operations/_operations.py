from ....generated.lakehouse.operations import *
from ....generated.lakehouse import operations as _operations
from ....generated.lakehouse import models as _models
from azure.core.polling.base_polling import LROBasePolling, OperationResourcePolling, StatusCheckPolling
from azure.core.polling import LROPoller
from ....fabric_api_utils import _LROResultExtractor
from typing import *
import time



class ItemsOperations(_operations.ItemsOperations):
    """ItemsOperations for Lakehouse."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    

    
    def create_lakehouse(self, workspace_id: str, create_lakehouse_request: _models.CreateLakehouseRequest, *, content_type: str = 'application/json', **kwargs: Any) -> _models.Lakehouse:
        """Creates a lakehouse in the specified workspace.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create lakehouse with a public definition, refer to `Lakehouse definition
        </rest/api/fabric/articles/item-management/definitions/lakehouse-definition>`_ article.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Lakehouse.ReadWrite.All or Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_lakehouse_request: Create item request payload. Required.
        :type create_lakehouse_request: ~microsoft.fabric.api.lakehouse.models.CreateLakehouseRequest
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns Lakehouse
        :rtype: ~azure.core.polling.LROPoller[~microsoft.fabric.api.lakehouse.models.Lakehouse]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        extractor = self.begin_create_lakehouse(workspace_id=workspace_id, create_lakehouse_request=create_lakehouse_request, content_type=content_type, **kwargs, )

        while extractor.result is None:
            time.sleep(5)

        return extractor.result
        
    
    
    def begin_create_lakehouse(self, workspace_id: str, create_lakehouse_request: _models.CreateLakehouseRequest, *, content_type: str = 'application/json', **kwargs: Any) -> _LROResultExtractor[_models.Lakehouse]:
        """Creates a lakehouse in the specified workspace.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create lakehouse with a public definition, refer to `Lakehouse definition
        </rest/api/fabric/articles/item-management/definitions/lakehouse-definition>`_ article.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Lakehouse.ReadWrite.All or Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_lakehouse_request: Create item request payload. Required.
        :type create_lakehouse_request: ~microsoft.fabric.api.lakehouse.models.CreateLakehouseRequest
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns Lakehouse
        :rtype: ~azure.core.polling.LROPoller[~microsoft.fabric.api.lakehouse.models.Lakehouse]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        extractor = _LROResultExtractor[_models.Lakehouse]()

        poller = super().begin_create_lakehouse(
            workspace_id=workspace_id,
            create_lakehouse_request=create_lakehouse_request,
            content_type=content_type,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )

        poller.add_done_callback(extractor)

        return extractor
        
    

    
    def create_lakehouse(self, workspace_id: str, create_lakehouse_request: IO[bytes], *, content_type: str = 'application/json', **kwargs: Any) -> _models.Lakehouse:
        """Creates a lakehouse in the specified workspace.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create lakehouse with a public definition, refer to `Lakehouse definition
        </rest/api/fabric/articles/item-management/definitions/lakehouse-definition>`_ article.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Lakehouse.ReadWrite.All or Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_lakehouse_request: Create item request payload. Required.
        :type create_lakehouse_request: IO[bytes]
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns Lakehouse
        :rtype: ~azure.core.polling.LROPoller[~microsoft.fabric.api.lakehouse.models.Lakehouse]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        extractor = self.begin_create_lakehouse(workspace_id=workspace_id, create_lakehouse_request=create_lakehouse_request, content_type=content_type, **kwargs, )

        while extractor.result is None:
            time.sleep(5)

        return extractor.result
        
    
    
    def begin_create_lakehouse(self, workspace_id: str, create_lakehouse_request: IO[bytes], *, content_type: str = 'application/json', **kwargs: Any) -> _LROResultExtractor[_models.Lakehouse]:
        """Creates a lakehouse in the specified workspace.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create lakehouse with a public definition, refer to `Lakehouse definition
        </rest/api/fabric/articles/item-management/definitions/lakehouse-definition>`_ article.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Lakehouse.ReadWrite.All or Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_lakehouse_request: Create item request payload. Required.
        :type create_lakehouse_request: IO[bytes]
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns Lakehouse
        :rtype: ~azure.core.polling.LROPoller[~microsoft.fabric.api.lakehouse.models.Lakehouse]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        extractor = _LROResultExtractor[_models.Lakehouse]()

        poller = super().begin_create_lakehouse(
            workspace_id=workspace_id,
            create_lakehouse_request=create_lakehouse_request,
            content_type=content_type,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )

        poller.add_done_callback(extractor)

        return extractor
        
    

    
    def create_lakehouse(self, workspace_id: str, create_lakehouse_request: Union[_models.CreateLakehouseRequest, IO[bytes]], **kwargs: Any) -> _models.Lakehouse:
        """Creates a lakehouse in the specified workspace.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create lakehouse with a public definition, refer to `Lakehouse definition
        </rest/api/fabric/articles/item-management/definitions/lakehouse-definition>`_ article.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Lakehouse.ReadWrite.All or Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_lakehouse_request: Create item request payload. Is either a
         CreateLakehouseRequest type or a IO[bytes] type. Required.
        :type create_lakehouse_request: ~microsoft.fabric.api.lakehouse.models.CreateLakehouseRequest
         or IO[bytes]
        :return: An instance of LROPoller that returns Lakehouse
        :rtype: ~azure.core.polling.LROPoller[~microsoft.fabric.api.lakehouse.models.Lakehouse]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        extractor = self.begin_create_lakehouse(workspace_id=workspace_id, create_lakehouse_request=create_lakehouse_request, **kwargs, )

        while extractor.result is None:
            time.sleep(5)

        return extractor.result
        
    
    
    def begin_create_lakehouse(self, workspace_id: str, create_lakehouse_request: Union[_models.CreateLakehouseRequest, IO[bytes]], **kwargs: Any) -> _LROResultExtractor[_models.Lakehouse]:
        """Creates a lakehouse in the specified workspace.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create lakehouse with a public definition, refer to `Lakehouse definition
        </rest/api/fabric/articles/item-management/definitions/lakehouse-definition>`_ article.

        Permissions
        -----------

         The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         Lakehouse.ReadWrite.All or Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_lakehouse_request: Create item request payload. Is either a
         CreateLakehouseRequest type or a IO[bytes] type. Required.
        :type create_lakehouse_request: ~microsoft.fabric.api.lakehouse.models.CreateLakehouseRequest
         or IO[bytes]
        :return: An instance of LROPoller that returns Lakehouse
        :rtype: ~azure.core.polling.LROPoller[~microsoft.fabric.api.lakehouse.models.Lakehouse]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        extractor = _LROResultExtractor[_models.Lakehouse]()

        poller = super().begin_create_lakehouse(
            workspace_id=workspace_id,
            create_lakehouse_request=create_lakehouse_request,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )

        poller.add_done_callback(extractor)

        return extractor
        
    

    
    def get_lakehouse_definition(self, workspace_id: str, lakehouse_id: str, *, format: Optional[str] = None, **kwargs: Any) -> _models.LakehouseDefinitionResponse:
        """Returns the specified lakehouse public definition.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        When you get a lakehouse's public definition, the sensitivity label is not a part of the
        definition.

        Permissions
        -----------

        The caller must have *read and write* permissions for the lakehouse.

        Required Delegated Scopes
        -------------------------

         Lakehouse.ReadWrite.All or Item.ReadWrite.All

        Limitations
        -----------

         This API is blocked for a lakehouse with an encrypted sensitivity label.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param lakehouse_id: The lakehouse ID. Required.
        :type lakehouse_id: str
        :keyword format: The format of the lakehouse public definition. Default value is None.
        :paramtype format: str
        :return: An instance of LROPoller that returns LakehouseDefinitionResponse
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.lakehouse.models.LakehouseDefinitionResponse]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        extractor = self.begin_get_lakehouse_definition(workspace_id=workspace_id, lakehouse_id=lakehouse_id, format=format, **kwargs, )

        while extractor.result is None:
            time.sleep(5)

        return extractor.result
        
    
    
    def begin_get_lakehouse_definition(self, workspace_id: str, lakehouse_id: str, *, format: Optional[str] = None, **kwargs: Any) -> _LROResultExtractor[_models.LakehouseDefinitionResponse]:
        """Returns the specified lakehouse public definition.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        When you get a lakehouse's public definition, the sensitivity label is not a part of the
        definition.

        Permissions
        -----------

        The caller must have *read and write* permissions for the lakehouse.

        Required Delegated Scopes
        -------------------------

         Lakehouse.ReadWrite.All or Item.ReadWrite.All

        Limitations
        -----------

         This API is blocked for a lakehouse with an encrypted sensitivity label.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param lakehouse_id: The lakehouse ID. Required.
        :type lakehouse_id: str
        :keyword format: The format of the lakehouse public definition. Default value is None.
        :paramtype format: str
        :return: An instance of LROPoller that returns LakehouseDefinitionResponse
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.lakehouse.models.LakehouseDefinitionResponse]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        extractor = _LROResultExtractor[_models.LakehouseDefinitionResponse]()

        poller = super().begin_get_lakehouse_definition(
            workspace_id=workspace_id,
            lakehouse_id=lakehouse_id,
            format=format,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )

        poller.add_done_callback(extractor)

        return extractor
        
    

    
    def update_lakehouse_definition(self, workspace_id: str, lakehouse_id: str, update_lakehouse_definition_request: _models.UpdateLakehouseDefinitionRequest, *, update_metadata: Optional[bool] = None, content_type: str = 'application/json', **kwargs: Any) -> _models.Lakehouse:
        """Overrides the definition for the specified lakehouse.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the lakehouse's definition does not affect its sensitivity label.

        Permissions
        -----------

        The caller must have *read and write* permissions for the lakehouse.

        Required Delegated Scopes
        -------------------------

         Lakehouse.ReadWrite.All or Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param lakehouse_id: The lakehouse ID. Required.
        :type lakehouse_id: str
        :param update_lakehouse_definition_request: Update lakehouse definition request payload.
         Required.
        :type update_lakehouse_definition_request:
         ~microsoft.fabric.api.lakehouse.models.UpdateLakehouseDefinitionRequest
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns Lakehouse
        :rtype: ~azure.core.polling.LROPoller[~microsoft.fabric.api.lakehouse.models.Lakehouse]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        extractor = self.begin_update_lakehouse_definition(workspace_id=workspace_id, lakehouse_id=lakehouse_id, update_lakehouse_definition_request=update_lakehouse_definition_request, update_metadata=update_metadata, content_type=content_type, **kwargs, )

        while extractor.result is None:
            time.sleep(5)

        return extractor.result
        
    
    
    def begin_update_lakehouse_definition(self, workspace_id: str, lakehouse_id: str, update_lakehouse_definition_request: _models.UpdateLakehouseDefinitionRequest, *, update_metadata: Optional[bool] = None, content_type: str = 'application/json', **kwargs: Any) -> _LROResultExtractor[_models.Lakehouse]:
        """Overrides the definition for the specified lakehouse.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the lakehouse's definition does not affect its sensitivity label.

        Permissions
        -----------

        The caller must have *read and write* permissions for the lakehouse.

        Required Delegated Scopes
        -------------------------

         Lakehouse.ReadWrite.All or Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param lakehouse_id: The lakehouse ID. Required.
        :type lakehouse_id: str
        :param update_lakehouse_definition_request: Update lakehouse definition request payload.
         Required.
        :type update_lakehouse_definition_request:
         ~microsoft.fabric.api.lakehouse.models.UpdateLakehouseDefinitionRequest
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns Lakehouse
        :rtype: ~azure.core.polling.LROPoller[~microsoft.fabric.api.lakehouse.models.Lakehouse]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        extractor = _LROResultExtractor[_models.Lakehouse]()

        poller = super().begin_update_lakehouse_definition(
            workspace_id=workspace_id,
            lakehouse_id=lakehouse_id,
            update_lakehouse_definition_request=update_lakehouse_definition_request,
            update_metadata=update_metadata,
            content_type=content_type,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )

        poller.add_done_callback(extractor)

        return extractor
        
    

    
    def update_lakehouse_definition(self, workspace_id: str, lakehouse_id: str, update_lakehouse_definition_request: IO[bytes], *, update_metadata: Optional[bool] = None, content_type: str = 'application/json', **kwargs: Any) -> _models.Lakehouse:
        """Overrides the definition for the specified lakehouse.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the lakehouse's definition does not affect its sensitivity label.

        Permissions
        -----------

        The caller must have *read and write* permissions for the lakehouse.

        Required Delegated Scopes
        -------------------------

         Lakehouse.ReadWrite.All or Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param lakehouse_id: The lakehouse ID. Required.
        :type lakehouse_id: str
        :param update_lakehouse_definition_request: Update lakehouse definition request payload.
         Required.
        :type update_lakehouse_definition_request: IO[bytes]
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns Lakehouse
        :rtype: ~azure.core.polling.LROPoller[~microsoft.fabric.api.lakehouse.models.Lakehouse]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        extractor = self.begin_update_lakehouse_definition(workspace_id=workspace_id, lakehouse_id=lakehouse_id, update_lakehouse_definition_request=update_lakehouse_definition_request, update_metadata=update_metadata, content_type=content_type, **kwargs, )

        while extractor.result is None:
            time.sleep(5)

        return extractor.result
        
    
    
    def begin_update_lakehouse_definition(self, workspace_id: str, lakehouse_id: str, update_lakehouse_definition_request: IO[bytes], *, update_metadata: Optional[bool] = None, content_type: str = 'application/json', **kwargs: Any) -> _LROResultExtractor[_models.Lakehouse]:
        """Overrides the definition for the specified lakehouse.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the lakehouse's definition does not affect its sensitivity label.

        Permissions
        -----------

        The caller must have *read and write* permissions for the lakehouse.

        Required Delegated Scopes
        -------------------------

         Lakehouse.ReadWrite.All or Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param lakehouse_id: The lakehouse ID. Required.
        :type lakehouse_id: str
        :param update_lakehouse_definition_request: Update lakehouse definition request payload.
         Required.
        :type update_lakehouse_definition_request: IO[bytes]
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns Lakehouse
        :rtype: ~azure.core.polling.LROPoller[~microsoft.fabric.api.lakehouse.models.Lakehouse]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        extractor = _LROResultExtractor[_models.Lakehouse]()

        poller = super().begin_update_lakehouse_definition(
            workspace_id=workspace_id,
            lakehouse_id=lakehouse_id,
            update_lakehouse_definition_request=update_lakehouse_definition_request,
            update_metadata=update_metadata,
            content_type=content_type,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )

        poller.add_done_callback(extractor)

        return extractor
        
    

    
    def update_lakehouse_definition(self, workspace_id: str, lakehouse_id: str, update_lakehouse_definition_request: Union[_models.UpdateLakehouseDefinitionRequest, IO[bytes]], *, update_metadata: Optional[bool] = None, **kwargs: Any) -> _models.Lakehouse:
        """Overrides the definition for the specified lakehouse.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the lakehouse's definition does not affect its sensitivity label.

        Permissions
        -----------

        The caller must have *read and write* permissions for the lakehouse.

        Required Delegated Scopes
        -------------------------

         Lakehouse.ReadWrite.All or Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param lakehouse_id: The lakehouse ID. Required.
        :type lakehouse_id: str
        :param update_lakehouse_definition_request: Update lakehouse definition request payload. Is
         either a UpdateLakehouseDefinitionRequest type or a IO[bytes] type. Required.
        :type update_lakehouse_definition_request:
         ~microsoft.fabric.api.lakehouse.models.UpdateLakehouseDefinitionRequest or IO[bytes]
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :return: An instance of LROPoller that returns Lakehouse
        :rtype: ~azure.core.polling.LROPoller[~microsoft.fabric.api.lakehouse.models.Lakehouse]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        extractor = self.begin_update_lakehouse_definition(workspace_id=workspace_id, lakehouse_id=lakehouse_id, update_lakehouse_definition_request=update_lakehouse_definition_request, update_metadata=update_metadata, **kwargs, )

        while extractor.result is None:
            time.sleep(5)

        return extractor.result
        
    
    
    def begin_update_lakehouse_definition(self, workspace_id: str, lakehouse_id: str, update_lakehouse_definition_request: Union[_models.UpdateLakehouseDefinitionRequest, IO[bytes]], *, update_metadata: Optional[bool] = None, **kwargs: Any) -> _LROResultExtractor[_models.Lakehouse]:
        """Overrides the definition for the specified lakehouse.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Updating the lakehouse's definition does not affect its sensitivity label.

        Permissions
        -----------

        The caller must have *read and write* permissions for the lakehouse.

        Required Delegated Scopes
        -------------------------

         Lakehouse.ReadWrite.All or Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param lakehouse_id: The lakehouse ID. Required.
        :type lakehouse_id: str
        :param update_lakehouse_definition_request: Update lakehouse definition request payload. Is
         either a UpdateLakehouseDefinitionRequest type or a IO[bytes] type. Required.
        :type update_lakehouse_definition_request:
         ~microsoft.fabric.api.lakehouse.models.UpdateLakehouseDefinitionRequest or IO[bytes]
        :keyword update_metadata: When set to true and the .platform file is provided as part of the
         definition, the item's metadata is updated using the metadata in the .platform file. Default
         value is None.
        :paramtype update_metadata: bool
        :return: An instance of LROPoller that returns Lakehouse
        :rtype: ~azure.core.polling.LROPoller[~microsoft.fabric.api.lakehouse.models.Lakehouse]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        extractor = _LROResultExtractor[_models.Lakehouse]()

        poller = super().begin_update_lakehouse_definition(
            workspace_id=workspace_id,
            lakehouse_id=lakehouse_id,
            update_lakehouse_definition_request=update_lakehouse_definition_request,
            update_metadata=update_metadata,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )

        poller.add_done_callback(extractor)

        return extractor
        
    


class TablesOperations(_operations.TablesOperations):
    """TablesOperations for Lakehouse."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    

    
    def load_table(self, workspace_id: str, lakehouse_id: str, table_name: str, load_table_request: _models.LoadTableRequest, *, content_type: str = 'application/json', **kwargs: Any) -> None:
        """Starts a load table operation and returns the operation status URL in the response location
        header.

        ..

           [!NOTE]
           This API is part of a Preview release and is provided for evaluation and development
        purposes only. It may change based on feedback and is not recommended for production use.


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Permissions
        -----------

        Write permission to the lakehouse item.

        Required Delegated Scopes
        -------------------------

        Lakehouse.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param lakehouse_id: The lakehouse item ID. Required.
        :type lakehouse_id: str
        :param table_name: The table name. Required.
        :type table_name: str
        :param load_table_request: The load table request payload. Required.
        :type load_table_request: ~microsoft.fabric.api.lakehouse.models.LoadTableRequest
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        poller = self.begin_load_table(
            workspace_id=workspace_id,
            lakehouse_id=lakehouse_id,
            table_name=table_name,
            load_table_request=load_table_request,
            content_type=content_type,
            **kwargs,
            )
        
        while not poller.done():
            time.sleep(5)

        
    
    
    def begin_load_table(self, workspace_id: str, lakehouse_id: str, table_name: str, load_table_request: _models.LoadTableRequest, *, content_type: str = 'application/json', **kwargs: Any) -> LROPoller[None]:
        """Starts a load table operation and returns the operation status URL in the response location
        header.

        ..

           [!NOTE]
           This API is part of a Preview release and is provided for evaluation and development
        purposes only. It may change based on feedback and is not recommended for production use.


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Permissions
        -----------

        Write permission to the lakehouse item.

        Required Delegated Scopes
        -------------------------

        Lakehouse.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param lakehouse_id: The lakehouse item ID. Required.
        :type lakehouse_id: str
        :param table_name: The table name. Required.
        :type table_name: str
        :param load_table_request: The load table request payload. Required.
        :type load_table_request: ~microsoft.fabric.api.lakehouse.models.LoadTableRequest
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        return super().begin_load_table(
            workspace_id=workspace_id,
            lakehouse_id=lakehouse_id,
            table_name=table_name,
            load_table_request=load_table_request,
            content_type=content_type,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )
        
    

    
    def load_table(self, workspace_id: str, lakehouse_id: str, table_name: str, load_table_request: IO[bytes], *, content_type: str = 'application/json', **kwargs: Any) -> None:
        """Starts a load table operation and returns the operation status URL in the response location
        header.

        ..

           [!NOTE]
           This API is part of a Preview release and is provided for evaluation and development
        purposes only. It may change based on feedback and is not recommended for production use.


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Permissions
        -----------

        Write permission to the lakehouse item.

        Required Delegated Scopes
        -------------------------

        Lakehouse.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param lakehouse_id: The lakehouse item ID. Required.
        :type lakehouse_id: str
        :param table_name: The table name. Required.
        :type table_name: str
        :param load_table_request: The load table request payload. Required.
        :type load_table_request: IO[bytes]
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        poller = self.begin_load_table(
            workspace_id=workspace_id,
            lakehouse_id=lakehouse_id,
            table_name=table_name,
            load_table_request=load_table_request,
            content_type=content_type,
            **kwargs,
            )
        
        while not poller.done():
            time.sleep(5)

        
    
    
    def begin_load_table(self, workspace_id: str, lakehouse_id: str, table_name: str, load_table_request: IO[bytes], *, content_type: str = 'application/json', **kwargs: Any) -> LROPoller[None]:
        """Starts a load table operation and returns the operation status URL in the response location
        header.

        ..

           [!NOTE]
           This API is part of a Preview release and is provided for evaluation and development
        purposes only. It may change based on feedback and is not recommended for production use.


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Permissions
        -----------

        Write permission to the lakehouse item.

        Required Delegated Scopes
        -------------------------

        Lakehouse.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param lakehouse_id: The lakehouse item ID. Required.
        :type lakehouse_id: str
        :param table_name: The table name. Required.
        :type table_name: str
        :param load_table_request: The load table request payload. Required.
        :type load_table_request: IO[bytes]
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        return super().begin_load_table(
            workspace_id=workspace_id,
            lakehouse_id=lakehouse_id,
            table_name=table_name,
            load_table_request=load_table_request,
            content_type=content_type,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )
        
    

    
    def load_table(self, workspace_id: str, lakehouse_id: str, table_name: str, load_table_request: Union[_models.LoadTableRequest, IO[bytes]], **kwargs: Any) -> None:
        """Starts a load table operation and returns the operation status URL in the response location
        header.

        ..

           [!NOTE]
           This API is part of a Preview release and is provided for evaluation and development
        purposes only. It may change based on feedback and is not recommended for production use.


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Permissions
        -----------

        Write permission to the lakehouse item.

        Required Delegated Scopes
        -------------------------

        Lakehouse.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param lakehouse_id: The lakehouse item ID. Required.
        :type lakehouse_id: str
        :param table_name: The table name. Required.
        :type table_name: str
        :param load_table_request: The load table request payload. Is either a LoadTableRequest type or
         a IO[bytes] type. Required.
        :type load_table_request: ~microsoft.fabric.api.lakehouse.models.LoadTableRequest or IO[bytes]
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        poller = self.begin_load_table(
            workspace_id=workspace_id,
            lakehouse_id=lakehouse_id,
            table_name=table_name,
            load_table_request=load_table_request,
            **kwargs,
            )
        
        while not poller.done():
            time.sleep(5)

        
    
    
    def begin_load_table(self, workspace_id: str, lakehouse_id: str, table_name: str, load_table_request: Union[_models.LoadTableRequest, IO[bytes]], **kwargs: Any) -> LROPoller[None]:
        """Starts a load table operation and returns the operation status URL in the response location
        header.

        ..

           [!NOTE]
           This API is part of a Preview release and is provided for evaluation and development
        purposes only. It may change based on feedback and is not recommended for production use.


        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        Permissions
        -----------

        Write permission to the lakehouse item.

        Required Delegated Scopes
        -------------------------

        Lakehouse.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param lakehouse_id: The lakehouse item ID. Required.
        :type lakehouse_id: str
        :param table_name: The table name. Required.
        :type table_name: str
        :param load_table_request: The load table request payload. Is either a LoadTableRequest type or
         a IO[bytes] type. Required.
        :type load_table_request: ~microsoft.fabric.api.lakehouse.models.LoadTableRequest or IO[bytes]
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        return super().begin_load_table(
            workspace_id=workspace_id,
            lakehouse_id=lakehouse_id,
            table_name=table_name,
            load_table_request=load_table_request,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )
        
    
