from ....generated.sqldatabase.operations import *
from ....generated.sqldatabase import operations as _operations
from ....generated.sqldatabase import models as _models
from azure.core.polling.base_polling import LROBasePolling, OperationResourcePolling, StatusCheckPolling
from azure.core.polling import LROPoller
from ....fabric_api_utils import _LROResultExtractor
from typing import *
import time



class ItemsOperations(_operations.ItemsOperations):
    """ItemsOperations for Sqldatabase."""

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

    

    
    def create_sql_database(self, workspace_id: str, create_sql_database_request: _models.CreateSQLDatabaseRequest, *, content_type: str = 'application/json', **kwargs: Any) -> _models.SQLDatabase:
        """Creates a SQL database in the specified workspace.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create a SQL database with a public definition, refer to `SQLDatabase definition
        </rest/api/fabric/articles/item-management/definitions/sql-database-definition>`_ article.

        Permissions
        -----------

        The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         SQLDatabase.ReadWrite.All or Item.ReadWrite.All

        Limitations
        -----------


        * To create a SQL database the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_sql_database_request: Create item request payload. Required.
        :type create_sql_database_request:
         ~microsoft.fabric.api.sqldatabase.models.CreateSQLDatabaseRequest
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns SQLDatabase
        :rtype: ~azure.core.polling.LROPoller[~microsoft.fabric.api.sqldatabase.models.SQLDatabase]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        extractor = self.begin_create_sql_database(workspace_id=workspace_id, create_sql_database_request=create_sql_database_request, content_type=content_type, **kwargs, )

        while extractor.result is None:
            time.sleep(5)

        return extractor.result
        
    
    
    def begin_create_sql_database(self, workspace_id: str, create_sql_database_request: _models.CreateSQLDatabaseRequest, *, content_type: str = 'application/json', **kwargs: Any) -> _LROResultExtractor[_models.SQLDatabase]:
        """Creates a SQL database in the specified workspace.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create a SQL database with a public definition, refer to `SQLDatabase definition
        </rest/api/fabric/articles/item-management/definitions/sql-database-definition>`_ article.

        Permissions
        -----------

        The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         SQLDatabase.ReadWrite.All or Item.ReadWrite.All

        Limitations
        -----------


        * To create a SQL database the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_sql_database_request: Create item request payload. Required.
        :type create_sql_database_request:
         ~microsoft.fabric.api.sqldatabase.models.CreateSQLDatabaseRequest
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns SQLDatabase
        :rtype: ~azure.core.polling.LROPoller[~microsoft.fabric.api.sqldatabase.models.SQLDatabase]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        extractor = _LROResultExtractor[_models.SQLDatabase]()

        poller = super().begin_create_sql_database(
            workspace_id=workspace_id,
            create_sql_database_request=create_sql_database_request,
            content_type=content_type,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )

        poller.add_done_callback(extractor)

        return extractor
        
    

    
    def create_sql_database(self, workspace_id: str, create_sql_database_request: IO[bytes], *, content_type: str = 'application/json', **kwargs: Any) -> _models.SQLDatabase:
        """Creates a SQL database in the specified workspace.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create a SQL database with a public definition, refer to `SQLDatabase definition
        </rest/api/fabric/articles/item-management/definitions/sql-database-definition>`_ article.

        Permissions
        -----------

        The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         SQLDatabase.ReadWrite.All or Item.ReadWrite.All

        Limitations
        -----------


        * To create a SQL database the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_sql_database_request: Create item request payload. Required.
        :type create_sql_database_request: IO[bytes]
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns SQLDatabase
        :rtype: ~azure.core.polling.LROPoller[~microsoft.fabric.api.sqldatabase.models.SQLDatabase]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        extractor = self.begin_create_sql_database(workspace_id=workspace_id, create_sql_database_request=create_sql_database_request, content_type=content_type, **kwargs, )

        while extractor.result is None:
            time.sleep(5)

        return extractor.result
        
    
    
    def begin_create_sql_database(self, workspace_id: str, create_sql_database_request: IO[bytes], *, content_type: str = 'application/json', **kwargs: Any) -> _LROResultExtractor[_models.SQLDatabase]:
        """Creates a SQL database in the specified workspace.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create a SQL database with a public definition, refer to `SQLDatabase definition
        </rest/api/fabric/articles/item-management/definitions/sql-database-definition>`_ article.

        Permissions
        -----------

        The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         SQLDatabase.ReadWrite.All or Item.ReadWrite.All

        Limitations
        -----------


        * To create a SQL database the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_sql_database_request: Create item request payload. Required.
        :type create_sql_database_request: IO[bytes]
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns SQLDatabase
        :rtype: ~azure.core.polling.LROPoller[~microsoft.fabric.api.sqldatabase.models.SQLDatabase]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        extractor = _LROResultExtractor[_models.SQLDatabase]()

        poller = super().begin_create_sql_database(
            workspace_id=workspace_id,
            create_sql_database_request=create_sql_database_request,
            content_type=content_type,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )

        poller.add_done_callback(extractor)

        return extractor
        
    

    
    def create_sql_database(self, workspace_id: str, create_sql_database_request: Union[_models.CreateSQLDatabaseRequest, IO[bytes]], **kwargs: Any) -> _models.SQLDatabase:
        """Creates a SQL database in the specified workspace.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create a SQL database with a public definition, refer to `SQLDatabase definition
        </rest/api/fabric/articles/item-management/definitions/sql-database-definition>`_ article.

        Permissions
        -----------

        The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         SQLDatabase.ReadWrite.All or Item.ReadWrite.All

        Limitations
        -----------


        * To create a SQL database the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_sql_database_request: Create item request payload. Is either a
         CreateSQLDatabaseRequest type or a IO[bytes] type. Required.
        :type create_sql_database_request:
         ~microsoft.fabric.api.sqldatabase.models.CreateSQLDatabaseRequest or IO[bytes]
        :return: An instance of LROPoller that returns SQLDatabase
        :rtype: ~azure.core.polling.LROPoller[~microsoft.fabric.api.sqldatabase.models.SQLDatabase]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        extractor = self.begin_create_sql_database(workspace_id=workspace_id, create_sql_database_request=create_sql_database_request, **kwargs, )

        while extractor.result is None:
            time.sleep(5)

        return extractor.result
        
    
    
    def begin_create_sql_database(self, workspace_id: str, create_sql_database_request: Union[_models.CreateSQLDatabaseRequest, IO[bytes]], **kwargs: Any) -> _LROResultExtractor[_models.SQLDatabase]:
        """Creates a SQL database in the specified workspace.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         To create a SQL database with a public definition, refer to `SQLDatabase definition
        </rest/api/fabric/articles/item-management/definitions/sql-database-definition>`_ article.

        Permissions
        -----------

        The caller must have a *contributor* workspace role.

        Required Delegated Scopes
        -------------------------

         SQLDatabase.ReadWrite.All or Item.ReadWrite.All

        Limitations
        -----------


        * To create a SQL database the workspace must be on a supported Fabric capacity. For more
        information see: `Microsoft Fabric license types
        </fabric/enterprise/licenses#microsoft-fabric-license-types>`_.

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param create_sql_database_request: Create item request payload. Is either a
         CreateSQLDatabaseRequest type or a IO[bytes] type. Required.
        :type create_sql_database_request:
         ~microsoft.fabric.api.sqldatabase.models.CreateSQLDatabaseRequest or IO[bytes]
        :return: An instance of LROPoller that returns SQLDatabase
        :rtype: ~azure.core.polling.LROPoller[~microsoft.fabric.api.sqldatabase.models.SQLDatabase]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        extractor = _LROResultExtractor[_models.SQLDatabase]()

        poller = super().begin_create_sql_database(
            workspace_id=workspace_id,
            create_sql_database_request=create_sql_database_request,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )

        poller.add_done_callback(extractor)

        return extractor
        
    

    
    def get_sql_database_definition(self, workspace_id: str, sql_database_id: str, **kwargs: Any) -> _models.SQLDatabaseDefinitionResponse:
        """Returns the specified SQL database public definition.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        When you get a SQL database's public definition, the sensitivity label is not a part of the
        definition.

        Permissions
        -----------

         The caller must have *read and write* permissions for the SQL database.

        Required Delegated Scopes
        -------------------------

         SQLDatabase.ReadWrite.All or Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param sql_database_id: The SQL database ID. Required.
        :type sql_database_id: str
        :return: An instance of LROPoller that returns SQLDatabaseDefinitionResponse
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.sqldatabase.models.SQLDatabaseDefinitionResponse]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        extractor = self.begin_get_sql_database_definition(workspace_id=workspace_id, sql_database_id=sql_database_id, **kwargs, )

        while extractor.result is None:
            time.sleep(5)

        return extractor.result
        
    
    
    def begin_get_sql_database_definition(self, workspace_id: str, sql_database_id: str, **kwargs: Any) -> _LROResultExtractor[_models.SQLDatabaseDefinitionResponse]:
        """Returns the specified SQL database public definition.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

        When you get a SQL database's public definition, the sensitivity label is not a part of the
        definition.

        Permissions
        -----------

         The caller must have *read and write* permissions for the SQL database.

        Required Delegated Scopes
        -------------------------

         SQLDatabase.ReadWrite.All or Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param sql_database_id: The SQL database ID. Required.
        :type sql_database_id: str
        :return: An instance of LROPoller that returns SQLDatabaseDefinitionResponse
        :rtype:
         ~azure.core.polling.LROPoller[~microsoft.fabric.api.sqldatabase.models.SQLDatabaseDefinitionResponse]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        extractor = _LROResultExtractor[_models.SQLDatabaseDefinitionResponse]()

        poller = super().begin_get_sql_database_definition(
            workspace_id=workspace_id,
            sql_database_id=sql_database_id,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )

        poller.add_done_callback(extractor)

        return extractor
        
    

    
    def update_sql_databases_definition(self, workspace_id: str, sql_database_id: str, update_sql_database_definition_request: _models.UpdateSQLDatabaseDefinitionRequest, *, update_metadata: Optional[bool] = None, content_type: str = 'application/json', **kwargs: Any) -> None:
        """Overrides the definition for the specified SQL database.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         Updating the SQL database's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the SQL database.

        Required Delegated Scopes
        -------------------------

         SQLDatabase.ReadWrite.All or Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param sql_database_id: The SQL database ID. Required.
        :type sql_database_id: str
        :param update_sql_database_definition_request: Update SQL database definition request payload.
         Required.
        :type update_sql_database_definition_request:
         ~microsoft.fabric.api.sqldatabase.models.UpdateSQLDatabaseDefinitionRequest
        :keyword update_metadata: When set to true and the SQL database.platform file is provided as
         part of the definition, the item's metadata is updated using the metadata in the SQL
         database.platform file. Default value is None.
        :paramtype update_metadata: bool
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        poller = self.begin_update_sql_databases_definition(
            workspace_id=workspace_id,
            sql_database_id=sql_database_id,
            update_sql_database_definition_request=update_sql_database_definition_request,
            update_metadata=update_metadata,
            content_type=content_type,
            **kwargs,
            )
        
        while not poller.done():
            time.sleep(5)

        
    
    
    def begin_update_sql_databases_definition(self, workspace_id: str, sql_database_id: str, update_sql_database_definition_request: _models.UpdateSQLDatabaseDefinitionRequest, *, update_metadata: Optional[bool] = None, content_type: str = 'application/json', **kwargs: Any) -> LROPoller[None]:
        """Overrides the definition for the specified SQL database.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         Updating the SQL database's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the SQL database.

        Required Delegated Scopes
        -------------------------

         SQLDatabase.ReadWrite.All or Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param sql_database_id: The SQL database ID. Required.
        :type sql_database_id: str
        :param update_sql_database_definition_request: Update SQL database definition request payload.
         Required.
        :type update_sql_database_definition_request:
         ~microsoft.fabric.api.sqldatabase.models.UpdateSQLDatabaseDefinitionRequest
        :keyword update_metadata: When set to true and the SQL database.platform file is provided as
         part of the definition, the item's metadata is updated using the metadata in the SQL
         database.platform file. Default value is None.
        :paramtype update_metadata: bool
        :keyword content_type: Body Parameter content-type. Content type parameter for JSON body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        return super().begin_update_sql_databases_definition(
            workspace_id=workspace_id,
            sql_database_id=sql_database_id,
            update_sql_database_definition_request=update_sql_database_definition_request,
            update_metadata=update_metadata,
            content_type=content_type,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )
        
    

    
    def update_sql_databases_definition(self, workspace_id: str, sql_database_id: str, update_sql_database_definition_request: IO[bytes], *, update_metadata: Optional[bool] = None, content_type: str = 'application/json', **kwargs: Any) -> None:
        """Overrides the definition for the specified SQL database.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         Updating the SQL database's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the SQL database.

        Required Delegated Scopes
        -------------------------

         SQLDatabase.ReadWrite.All or Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param sql_database_id: The SQL database ID. Required.
        :type sql_database_id: str
        :param update_sql_database_definition_request: Update SQL database definition request payload.
         Required.
        :type update_sql_database_definition_request: IO[bytes]
        :keyword update_metadata: When set to true and the SQL database.platform file is provided as
         part of the definition, the item's metadata is updated using the metadata in the SQL
         database.platform file. Default value is None.
        :paramtype update_metadata: bool
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        poller = self.begin_update_sql_databases_definition(
            workspace_id=workspace_id,
            sql_database_id=sql_database_id,
            update_sql_database_definition_request=update_sql_database_definition_request,
            update_metadata=update_metadata,
            content_type=content_type,
            **kwargs,
            )
        
        while not poller.done():
            time.sleep(5)

        
    
    
    def begin_update_sql_databases_definition(self, workspace_id: str, sql_database_id: str, update_sql_database_definition_request: IO[bytes], *, update_metadata: Optional[bool] = None, content_type: str = 'application/json', **kwargs: Any) -> LROPoller[None]:
        """Overrides the definition for the specified SQL database.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         Updating the SQL database's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the SQL database.

        Required Delegated Scopes
        -------------------------

         SQLDatabase.ReadWrite.All or Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param sql_database_id: The SQL database ID. Required.
        :type sql_database_id: str
        :param update_sql_database_definition_request: Update SQL database definition request payload.
         Required.
        :type update_sql_database_definition_request: IO[bytes]
        :keyword update_metadata: When set to true and the SQL database.platform file is provided as
         part of the definition, the item's metadata is updated using the metadata in the SQL
         database.platform file. Default value is None.
        :paramtype update_metadata: bool
        :keyword content_type: Body Parameter content-type. Content type parameter for binary body.
         Default value is "application/json".
        :paramtype content_type: str
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        return super().begin_update_sql_databases_definition(
            workspace_id=workspace_id,
            sql_database_id=sql_database_id,
            update_sql_database_definition_request=update_sql_database_definition_request,
            update_metadata=update_metadata,
            content_type=content_type,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )
        
    

    
    def update_sql_databases_definition(self, workspace_id: str, sql_database_id: str, update_sql_database_definition_request: Union[_models.UpdateSQLDatabaseDefinitionRequest, IO[bytes]], *, update_metadata: Optional[bool] = None, **kwargs: Any) -> None:
        """Overrides the definition for the specified SQL database.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         Updating the SQL database's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the SQL database.

        Required Delegated Scopes
        -------------------------

         SQLDatabase.ReadWrite.All or Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param sql_database_id: The SQL database ID. Required.
        :type sql_database_id: str
        :param update_sql_database_definition_request: Update SQL database definition request payload.
         Is either a UpdateSQLDatabaseDefinitionRequest type or a IO[bytes] type. Required.
        :type update_sql_database_definition_request:
         ~microsoft.fabric.api.sqldatabase.models.UpdateSQLDatabaseDefinitionRequest or IO[bytes]
        :keyword update_metadata: When set to true and the SQL database.platform file is provided as
         part of the definition, the item's metadata is updated using the metadata in the SQL
         database.platform file. Default value is None.
        :paramtype update_metadata: bool
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        poller = self.begin_update_sql_databases_definition(
            workspace_id=workspace_id,
            sql_database_id=sql_database_id,
            update_sql_database_definition_request=update_sql_database_definition_request,
            update_metadata=update_metadata,
            **kwargs,
            )
        
        while not poller.done():
            time.sleep(5)

        
    
    
    def begin_update_sql_databases_definition(self, workspace_id: str, sql_database_id: str, update_sql_database_definition_request: Union[_models.UpdateSQLDatabaseDefinitionRequest, IO[bytes]], *, update_metadata: Optional[bool] = None, **kwargs: Any) -> LROPoller[None]:
        """Overrides the definition for the specified SQL database.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         Updating the SQL database's definition, does not affect its sensitivity label.

        Permissions
        -----------

         The caller must have *read and write* permissions for the SQL database.

        Required Delegated Scopes
        -------------------------

         SQLDatabase.ReadWrite.All or Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace ID. Required.
        :type workspace_id: str
        :param sql_database_id: The SQL database ID. Required.
        :type sql_database_id: str
        :param update_sql_database_definition_request: Update SQL database definition request payload.
         Is either a UpdateSQLDatabaseDefinitionRequest type or a IO[bytes] type. Required.
        :type update_sql_database_definition_request:
         ~microsoft.fabric.api.sqldatabase.models.UpdateSQLDatabaseDefinitionRequest or IO[bytes]
        :keyword update_metadata: When set to true and the SQL database.platform file is provided as
         part of the definition, the item's metadata is updated using the metadata in the SQL
         database.platform file. Default value is None.
        :paramtype update_metadata: bool
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        return super().begin_update_sql_databases_definition(
            workspace_id=workspace_id,
            sql_database_id=sql_database_id,
            update_sql_database_definition_request=update_sql_database_definition_request,
            update_metadata=update_metadata,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )
        
    

    
    def revalidate_cmk(self, workspace_id: str, sql_database_id: str, **kwargs: Any) -> None:
        """Revalidate Customer‑Managed Key (CMK) of the specified SQL database.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         Revalidating Customer‑Managed Key (CMK) of the specified SQL database, which checks that the
        currently configured Azure Key Vault (AKV) key is still accessible, valid, and authorized for
        encryption operations.

        Permissions
        -----------

         The caller must have *read and write* permissions for the SQL database.

        Required Delegated Scopes
        -------------------------

         SQLDatabase.ReadWrite.All or Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace identifier. Required.
        :type workspace_id: str
        :param sql_database_id: The SQL database ID. Required.
        :type sql_database_id: str
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
        """

        
        poller = self.begin_revalidate_cmk(
            workspace_id=workspace_id,
            sql_database_id=sql_database_id,
            **kwargs,
            )
        
        while not poller.done():
            time.sleep(5)

        
    
    
    def begin_revalidate_cmk(self, workspace_id: str, sql_database_id: str, **kwargs: Any) -> LROPoller[None]:
        """Revalidate Customer‑Managed Key (CMK) of the specified SQL database.

        This API supports `long running operations (LRO)
        </rest/api/fabric/articles/long-running-operation>`_.

         Revalidating Customer‑Managed Key (CMK) of the specified SQL database, which checks that the
        currently configured Azure Key Vault (AKV) key is still accessible, valid, and authorized for
        encryption operations.

        Permissions
        -----------

         The caller must have *read and write* permissions for the SQL database.

        Required Delegated Scopes
        -------------------------

         SQLDatabase.ReadWrite.All or Item.ReadWrite.All

        Microsoft Entra supported identities
        ------------------------------------

        This API supports the Microsoft `identities </rest/api/fabric/articles/identity-support>`_
        listed in this section.

        .. list-table::
           :header-rows: 1

           * - Identity
             - Support
           * - User
             - Yes
           * - `Service principal
        </entra/identity-platform/app-objects-and-service-principals#service-principal-object>`_ and
        `Managed identities </entra/identity/managed-identities-azure-resources/overview>`_
             - Yes


        Interface
        ---------.

        :param workspace_id: The workspace identifier. Required.
        :type workspace_id: str
        :param sql_database_id: The SQL database ID. Required.
        :type sql_database_id: str
        :return: An instance of LROPoller that returns None
        :rtype: ~azure.core.polling.LROPoller[None]
        :raises ~azure.core.exceptions.HttpResponseError:
         asynchronously."""

        

        return super().begin_revalidate_cmk(
            workspace_id=workspace_id,
            sql_database_id=sql_database_id,
            **kwargs,
            polling=LROBasePolling(lro_algorithms=[OperationResourcePolling(operation_location_header="location"), StatusCheckPolling()]),
        )
        
    
