from poolclaw_mcp.setup import main
main()
