from __future__ import annotations

from typing import Any, Dict, List, Optional
from urllib.parse import quote

from ._http import HttpClient
from .types import PosthawkResponse, WebhookEndpoint


class Webhooks:
    """Webhook endpoint management."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def list(self) -> PosthawkResponse[List[WebhookEndpoint]]:
        """List all webhook endpoints for the current workspace."""
        resp = self._http.request("GET", "/v1/webhooks")
        if resp.error:
            return PosthawkResponse(data=None, error=resp.error)

        return PosthawkResponse(
            data=[WebhookEndpoint(**item) for item in resp.data],
            error=None,
        )

    def create(
        self,
        *,
        url: str,
        events: List[str],
        description: Optional[str] = None,
    ) -> PosthawkResponse[WebhookEndpoint]:
        """Create a new webhook endpoint."""
        body: Dict[str, Any] = {"url": url, "events": events}
        if description:
            body["description"] = description

        resp = self._http.request("POST", "/v1/webhooks", json=body)
        if resp.error:
            return PosthawkResponse(data=None, error=resp.error)

        return PosthawkResponse(
            data=WebhookEndpoint(**resp.data),
            error=None,
        )

    def update(
        self,
        id: str,
        *,
        url: Optional[str] = None,
        events: Optional[List[str]] = None,
        enabled: Optional[bool] = None,
        description: Optional[str] = None,
    ) -> PosthawkResponse[WebhookEndpoint]:
        """Update an existing webhook endpoint."""
        body: Dict[str, Any] = {}
        if url is not None:
            body["url"] = url
        if events is not None:
            body["events"] = events
        if enabled is not None:
            body["enabled"] = enabled
        if description is not None:
            body["description"] = description

        resp = self._http.request(
            "PATCH", f"/v1/webhooks/{quote(id, safe='')}", json=body,
        )
        if resp.error:
            return PosthawkResponse(data=None, error=resp.error)

        return PosthawkResponse(
            data=WebhookEndpoint(**resp.data),
            error=None,
        )

    def delete(self, id: str) -> PosthawkResponse[Dict[str, bool]]:
        """Delete a webhook endpoint."""
        resp = self._http.request("DELETE", f"/v1/webhooks/{quote(id, safe='')}")
        if resp.error:
            return PosthawkResponse(data=None, error=resp.error)

        return PosthawkResponse(data=resp.data, error=None)
