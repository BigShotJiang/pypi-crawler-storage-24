from __future__ import annotations

from typing import Any, Dict, List, Optional
from urllib.parse import quote

from ._http import HttpClient
from .types import (
    PosthawkResponse,
    Domain,
    DomainResponse,
    DomainListResponse,
    DomainDeleteResponse,
    DnsRecord,
    WebhookTestResponse,
)


class Domains:
    """Domain management (Cloud only)."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def create(self, *, domain: str, region: Optional[str] = None) -> PosthawkResponse[DomainResponse]:
        body: Dict[str, Any] = {"domain": domain}
        if region:
            body["region"] = region
        resp = self._http.request("POST", "/v1/domains", json=body)
        if resp.error:
            return PosthawkResponse(data=None, error=resp.error)
        return PosthawkResponse(data=self._parse_domain_response(resp.data), error=None)

    def list(self) -> PosthawkResponse[DomainListResponse]:
        resp = self._http.request("GET", "/v1/domains")
        if resp.error:
            return PosthawkResponse(data=None, error=resp.error)
        return PosthawkResponse(data=self._parse_list_response(resp.data), error=None)

    def get(self, id: str) -> PosthawkResponse[DomainResponse]:
        resp = self._http.request("GET", f"/v1/domains/{quote(id, safe='')}")
        if resp.error:
            return PosthawkResponse(data=None, error=resp.error)
        return PosthawkResponse(data=self._parse_domain_response(resp.data), error=None)

    def delete(self, id: str) -> PosthawkResponse[DomainDeleteResponse]:
        resp = self._http.request("DELETE", f"/v1/domains/{quote(id, safe='')}")
        if resp.error:
            return PosthawkResponse(data=None, error=resp.error)
        return PosthawkResponse(data=DomainDeleteResponse(**resp.data), error=None)

    def verify(self, id: str) -> PosthawkResponse[DomainResponse]:
        resp = self._http.request("POST", f"/v1/domains/{quote(id, safe='')}/verify")
        if resp.error:
            return PosthawkResponse(data=None, error=resp.error)
        return PosthawkResponse(data=self._parse_domain_response(resp.data), error=None)

    def enable_receiving(self, id: str) -> PosthawkResponse[DomainResponse]:
        resp = self._http.request("POST", f"/v1/domains/{quote(id, safe='')}/receiving/enable")
        if resp.error:
            return PosthawkResponse(data=None, error=resp.error)
        return PosthawkResponse(data=self._parse_domain_response(resp.data), error=None)

    def disable_receiving(self, id: str) -> PosthawkResponse[DomainResponse]:
        resp = self._http.request("POST", f"/v1/domains/{quote(id, safe='')}/receiving/disable")
        if resp.error:
            return PosthawkResponse(data=None, error=resp.error)
        return PosthawkResponse(data=self._parse_domain_response(resp.data), error=None)

    def update_webhook(self, id: str, *, webhook_url: Optional[str]) -> PosthawkResponse[DomainResponse]:
        resp = self._http.request(
            "PATCH",
            f"/v1/domains/{quote(id, safe='')}/webhook",
            json={"webhookUrl": webhook_url},
        )
        if resp.error:
            return PosthawkResponse(data=None, error=resp.error)
        return PosthawkResponse(data=self._parse_domain_response(resp.data), error=None)

    def test_webhook(self, id: str) -> PosthawkResponse[WebhookTestResponse]:
        resp = self._http.request("POST", f"/v1/domains/{quote(id, safe='')}/webhook/test")
        if resp.error:
            return PosthawkResponse(data=None, error=resp.error)
        d = resp.data
        return PosthawkResponse(
            data=WebhookTestResponse(
                success=d.get("success", False),
                status=d.get("status", 0),
                status_text=d.get("statusText", d.get("status_text", "")),
                error=d.get("error"),
            ),
            error=None,
        )

    @staticmethod
    def _parse_domain(d: dict) -> Domain:
        dns_raw = d.pop("dns_records", None) or d.pop("dnsRecords", None)
        dns_records = None
        if dns_raw:
            dns_records = [DnsRecord(**r) for r in dns_raw]
        return Domain(
            id=d.get("id", ""),
            domain=d.get("domain", ""),
            ses_region=d.get("ses_region", d.get("sesRegion", "")),
            ses_identity_status=d.get("ses_identity_status", d.get("sesIdentityStatus", "")),
            dkim_verified=d.get("dkim_verified", d.get("dkimVerified", False)),
            spf_verified=d.get("spf_verified", d.get("spfVerified", False)),
            sending_enabled=d.get("sending_enabled", d.get("sendingEnabled", False)),
            receiving_enabled=d.get("receiving_enabled", d.get("receivingEnabled", False)),
            webhook_url=d.get("webhook_url", d.get("webhookUrl")),
            webhook_secret=d.get("webhook_secret", d.get("webhookSecret")),
            verification_attempts=d.get("verification_attempts", d.get("verificationAttempts", 0)),
            last_checked_at=d.get("last_checked_at", d.get("lastCheckedAt")),
            created_at=d.get("created_at", d.get("createdAt", "")),
            updated_at=d.get("updated_at", d.get("updatedAt", "")),
            dns_records=dns_records,
        )

    def _parse_domain_response(self, d: dict) -> DomainResponse:
        data = d.get("data", {})
        return DomainResponse(
            success=d.get("success", True),
            data=self._parse_domain(data),
            message=d.get("message"),
        )

    def _parse_list_response(self, d: dict) -> DomainListResponse:
        return DomainListResponse(
            success=d.get("success", True),
            data=[self._parse_domain(item) for item in d.get("data", [])],
        )
