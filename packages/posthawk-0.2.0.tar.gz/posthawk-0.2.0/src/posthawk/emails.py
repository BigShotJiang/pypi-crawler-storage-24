from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional, Union
from urllib.parse import quote

from ._http import HttpClient
from .types import (
    EmailJobResult,
    EmailJobStatus,
    PosthawkResponse,
    SendEmailResponse,
)


def _to_list(value: Optional[Union[str, List[str]]]) -> Optional[List[str]]:
    if value is None:
        return None
    return value if isinstance(value, list) else [value]


def _to_iso(value: Optional[Union[str, datetime]]) -> Optional[str]:
    if value is None:
        return None
    return value.isoformat() if isinstance(value, datetime) else value


class Emails:
    """Email sending and status checking."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def send(
        self,
        *,
        from_email: str,
        to: Union[str, List[str]],
        subject: str,
        cc: Optional[Union[str, List[str]]] = None,
        bcc: Optional[Union[str, List[str]]] = None,
        html: Optional[str] = None,
        text: Optional[str] = None,
        template_id: Optional[str] = None,
        variables: Optional[Dict[str, str]] = None,
        headers: Optional[Dict[str, str]] = None,
        scheduled_for: Optional[Union[str, datetime]] = None,
        timezone: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        tags: Optional[Dict[str, Any]] = None,
        reply_to: Optional[str] = None,
        idempotency_key: Optional[str] = None,
    ) -> PosthawkResponse[SendEmailResponse]:
        """Send an email immediately or schedule it for later."""
        body: Dict[str, Any] = {
            "from": from_email,
            "to": _to_list(to),
            "subject": subject,
        }

        optionals: Dict[str, Any] = {
            "cc": _to_list(cc),
            "bcc": _to_list(bcc),
            "html": html,
            "text": text,
            "templateId": template_id,
            "variables": variables,
            "headers": headers,
            "scheduledFor": _to_iso(scheduled_for),
            "timezone": timezone,
            "metadata": metadata,
            "tags": tags,
            "replyTo": reply_to,
        }
        body.update({k: v for k, v in optionals.items() if v is not None})

        extra_headers: Optional[Dict[str, str]] = None
        if idempotency_key:
            extra_headers = {"Idempotency-Key": idempotency_key}

        resp = self._http.request("POST", "/v1/send", json=body, headers=extra_headers)
        if resp.error:
            return PosthawkResponse(data=None, error=resp.error)

        return PosthawkResponse(
            data=SendEmailResponse(**resp.data),
            error=None,
        )

    def get(self, job_id: str) -> PosthawkResponse[EmailJobStatus]:
        """Check the status of a previously queued email job."""
        resp = self._http.request("GET", f"/v1/send/{quote(job_id, safe='')}")
        if resp.error:
            return PosthawkResponse(data=None, error=resp.error)

        raw = dict(resp.data)
        result_data = raw.pop("result", None)
        result = EmailJobResult(**result_data) if result_data else None

        return PosthawkResponse(
            data=EmailJobStatus(**raw, result=result),
            error=None,
        )
