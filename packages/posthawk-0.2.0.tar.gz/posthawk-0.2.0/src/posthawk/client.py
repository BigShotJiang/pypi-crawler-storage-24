from __future__ import annotations

from typing import Optional

from ._http import HttpClient
from .domains import Domains
from .emails import Emails
from .error import PosthawkError
from .scheduled import Scheduled
from .templates import Templates
from .webhooks import Webhooks

_DEFAULT_BASE_URL = "https://api.posthawk.dev"


class Posthawk:
    """Posthawk SDK client.

    Usage::

        client = Posthawk("ck_live_...")

        result = client.emails.send(
            from_email="hi@example.com",
            to="user@example.com",
            subject="Hello",
            html="<h1>Hi!</h1>",
        )
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        *,
        base_url: Optional[str] = None,
    ) -> None:
        if not api_key:
            raise PosthawkError(
                'Missing API key. Pass your key as the first argument: '
                'Posthawk("ck_live_...")',
                401,
            )

        resolved_url = (base_url or _DEFAULT_BASE_URL).rstrip("/")

        self._http = HttpClient(resolved_url, api_key)
        self.emails = Emails(self._http)
        self.scheduled = Scheduled(self._http)
        self.templates = Templates(self._http)
        self.webhooks = Webhooks(self._http)
        self.domains = Domains(self._http)

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._http.close()

    def __enter__(self) -> Posthawk:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()
