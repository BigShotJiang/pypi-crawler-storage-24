from __future__ import annotations

from dataclasses import dataclass, field
from typing import Generic, List, Optional, TypeVar

from .error import PosthawkError

T = TypeVar("T")


@dataclass
class PosthawkResponse(Generic[T]):
    """Every SDK method returns this. Check .error first."""

    data: Optional[T]
    error: Optional[PosthawkError]


# -- Email responses --


@dataclass
class SendEmailResponse:
    success: bool
    scheduled: bool
    message: str
    status_url: str
    job_id: Optional[str] = None
    id: Optional[str] = None
    scheduled_for: Optional[str] = None


@dataclass
class EmailJobResult:
    success: Optional[bool] = None
    message_id: Optional[str] = None
    email_log_id: Optional[str] = None


@dataclass
class EmailJobStatus:
    job_id: str
    status: str  # pending | processing | completed | failed
    created_at: str
    progress: Optional[float] = None
    result: Optional[EmailJobResult] = None
    error: Optional[str] = None
    processed_at: Optional[str] = None


# -- Scheduled responses --


@dataclass
class ScheduledEmail:
    id: str
    from_email: str
    to_emails: List[str]
    subject: str
    scheduled_for: str
    status: str  # scheduled | sent | cancelled | failed
    created_at: str
    cc_emails: Optional[List[str]] = None
    bcc_emails: Optional[List[str]] = None
    timezone: Optional[str] = None


@dataclass
class ScheduledListResponse:
    success: bool
    data: List[ScheduledEmail]
    total: int


@dataclass
class ScheduledGetResponse:
    success: bool
    data: ScheduledEmail


@dataclass
class CancelResponse:
    success: bool
    message: str


@dataclass
class RescheduleResponse:
    success: bool
    data: ScheduledEmail


# -- Template responses --


@dataclass
class RenderTemplateResponse:
    success: bool
    subject: str
    html: Optional[str] = None
    text: Optional[str] = None


# -- Webhook responses --


@dataclass
class WebhookEndpoint:
    id: str
    url: str
    secret: str
    events: List[str]
    enabled: bool
    created_at: str
    updated_at: str
    description: Optional[str] = None


# -- Domain responses (Cloud only) --


@dataclass
class DnsRecord:
    type: str
    name: str
    value: str
    purpose: str


@dataclass
class Domain:
    id: str
    domain: str
    ses_region: str
    ses_identity_status: str
    dkim_verified: bool
    spf_verified: bool
    sending_enabled: bool
    receiving_enabled: bool
    created_at: str
    updated_at: str
    verification_attempts: int = 0
    webhook_url: Optional[str] = None
    webhook_secret: Optional[str] = None
    last_checked_at: Optional[str] = None
    dns_records: Optional[List["DnsRecord"]] = None


@dataclass
class DomainResponse:
    success: bool
    data: Domain
    message: Optional[str] = None


@dataclass
class DomainListResponse:
    success: bool
    data: List[Domain]


@dataclass
class DomainDeleteResponse:
    success: bool
    message: str


@dataclass
class WebhookTestResponse:
    success: bool
    status: int
    status_text: str
    error: Optional[str] = None
