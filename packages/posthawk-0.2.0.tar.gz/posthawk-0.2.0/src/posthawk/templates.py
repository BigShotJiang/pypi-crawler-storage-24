from __future__ import annotations

from typing import Any, Dict, Optional

from ._http import HttpClient
from .types import PosthawkResponse, RenderTemplateResponse


class Templates:
    """Server-side template rendering."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def render(
        self,
        *,
        template_id: str,
        variables: Optional[Dict[str, str]] = None,
    ) -> PosthawkResponse[RenderTemplateResponse]:
        """Render a stored template with the given variables."""
        body: Dict[str, Any] = {"templateId": template_id}
        if variables:
            body["variables"] = variables

        resp = self._http.request("POST", "/v1/render", json=body)
        if resp.error:
            return PosthawkResponse(data=None, error=resp.error)

        return PosthawkResponse(
            data=RenderTemplateResponse(**resp.data),
            error=None,
        )
