from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, Optional, Union
from urllib.parse import quote

from ._http import HttpClient
from .types import (
    CancelResponse,
    PosthawkResponse,
    RescheduleResponse,
    ScheduledEmail,
    ScheduledGetResponse,
    ScheduledListResponse,
)


class Scheduled:
    """Manage scheduled emails."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    def list(
        self,
        *,
        status: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
    ) -> PosthawkResponse[ScheduledListResponse]:
        """List scheduled emails with optional filtering."""
        params: Dict[str, Any] = {}
        if status is not None:
            params["status"] = status
        if limit is not None:
            params["limit"] = str(limit)
        if offset is not None:
            params["offset"] = str(offset)

        resp = self._http.request("GET", "/scheduled", params=params or None)
        if resp.error:
            return PosthawkResponse(data=None, error=resp.error)

        raw = resp.data
        emails = [ScheduledEmail(**e) for e in raw.get("data", [])]

        return PosthawkResponse(
            data=ScheduledListResponse(
                success=raw.get("success", True),
                data=emails,
                total=raw.get("total", 0),
            ),
            error=None,
        )

    def get(self, id: str) -> PosthawkResponse[ScheduledGetResponse]:
        """Get a specific scheduled email by ID."""
        resp = self._http.request("GET", f"/scheduled/{quote(id, safe='')}")
        if resp.error:
            return PosthawkResponse(data=None, error=resp.error)

        raw = resp.data
        return PosthawkResponse(
            data=ScheduledGetResponse(
                success=raw.get("success", True),
                data=ScheduledEmail(**raw["data"]),
            ),
            error=None,
        )

    def cancel(self, id: str) -> PosthawkResponse[CancelResponse]:
        """Cancel a scheduled email before it sends."""
        resp = self._http.request("DELETE", f"/scheduled/{quote(id, safe='')}")
        if resp.error:
            return PosthawkResponse(data=None, error=resp.error)

        raw = resp.data
        return PosthawkResponse(
            data=CancelResponse(
                success=raw.get("success", True),
                message=raw.get("message", ""),
            ),
            error=None,
        )

    def reschedule(
        self,
        id: str,
        *,
        scheduled_for: Union[str, datetime],
    ) -> PosthawkResponse[RescheduleResponse]:
        """Reschedule an email to a new send time."""
        iso = (
            scheduled_for.isoformat()
            if isinstance(scheduled_for, datetime)
            else scheduled_for
        )

        resp = self._http.request(
            "PATCH",
            f"/scheduled/{quote(id, safe='')}/reschedule",
            json={"scheduledFor": iso},
        )
        if resp.error:
            return PosthawkResponse(data=None, error=resp.error)

        raw = resp.data
        return PosthawkResponse(
            data=RescheduleResponse(
                success=raw.get("success", True),
                data=ScheduledEmail(**raw["data"]),
            ),
            error=None,
        )
