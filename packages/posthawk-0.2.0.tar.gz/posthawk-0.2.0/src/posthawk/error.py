class PosthawkError(Exception):
    """Error returned by the Posthawk API.

    SDK methods never raise this for API errors — they return
    PosthawkResponse(data=None, error=PosthawkError(...)) instead.

    Only the Posthawk constructor raises this directly (e.g. missing API key).
    """

    def __init__(self, message: str, status_code: int = 500):
        super().__init__(message)
        self.message = message
        self.status_code = status_code

    def __repr__(self) -> str:
        return f"PosthawkError(message={self.message!r}, status_code={self.status_code})"
