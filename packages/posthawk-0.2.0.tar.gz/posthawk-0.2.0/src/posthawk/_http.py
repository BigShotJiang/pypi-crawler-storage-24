from __future__ import annotations

import re
from typing import Any, Dict, Optional

import httpx

from ._version import __version__
from .error import PosthawkError
from .types import PosthawkResponse


def _camel_to_snake(name: str) -> str:
    s1 = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1_\2", name)
    return re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", s1).lower()


def _convert_keys(obj: Any) -> Any:
    """Recursively convert dict keys from camelCase to snake_case."""
    if isinstance(obj, dict):
        return {_camel_to_snake(k): _convert_keys(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_convert_keys(item) for item in obj]
    return obj


class HttpClient:
    def __init__(self, base_url: str, api_key: str) -> None:
        self._client = httpx.Client(
            base_url=base_url,
            headers={
                "x-api-key": api_key,
                "Content-Type": "application/json",
                "User-Agent": f"posthawk-python/{__version__}",
            },
            timeout=30.0,
        )

    def request(
        self,
        method: str,
        path: str,
        json: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
        headers: Optional[Dict[str, str]] = None,
    ) -> PosthawkResponse[Any]:
        try:
            response = self._client.request(
                method, path, json=json, params=params, headers=headers or {},
            )

            data = response.json() if response.content else None

            if not response.is_success:
                message = f"Request failed with status {response.status_code}"
                if isinstance(data, dict):
                    message = data.get("message") or data.get("error") or message
                return PosthawkResponse(
                    data=None,
                    error=PosthawkError(message, response.status_code),
                )

            converted = _convert_keys(data) if data is not None else data
            return PosthawkResponse(data=converted, error=None)

        except httpx.HTTPError as exc:
            return PosthawkResponse(
                data=None,
                error=PosthawkError(str(exc), 0),
            )

    def close(self) -> None:
        self._client.close()
