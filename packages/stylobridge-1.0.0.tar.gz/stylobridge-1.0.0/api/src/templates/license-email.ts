/**
 * HTML email templates for license delivery.
 */

interface LicenseEmailParams {
  planName: string;
  token: string;
  expires: string;
}

export function licenseEmail(params: LicenseEmailParams): string {
  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body style="margin:0;padding:0;background:#f4f4f5;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f4f4f5;padding:40px 20px;">
    <tr>
      <td align="center">
        <table width="600" cellpadding="0" cellspacing="0" style="background:#ffffff;border-radius:8px;overflow:hidden;">
          <!-- Header -->
          <tr>
            <td style="background:#1a1a2e;padding:32px 40px;">
              <h1 style="margin:0;color:#ffffff;font-size:24px;font-weight:700;">StyloBridge</h1>
            </td>
          </tr>
          <!-- Body -->
          <tr>
            <td style="padding:40px;">
              <h2 style="margin:0 0 16px;color:#1a1a2e;font-size:20px;">Your ${params.planName} License Key</h2>
              <p style="margin:0 0 24px;color:#52525b;font-size:15px;line-height:1.6;">
                Your license key is ready. Copy it and add it to your Claude Desktop configuration to get started.
              </p>

              <!-- Token block -->
              <div style="background:#f4f4f5;border:1px solid #e4e4e7;border-radius:6px;padding:16px;margin:0 0 32px;word-break:break-all;font-family:'SF Mono',Monaco,Consolas,monospace;font-size:12px;line-height:1.5;color:#18181b;">
                ${params.token}
              </div>

              <!-- Quick start -->
              <h3 style="margin:0 0 12px;color:#1a1a2e;font-size:16px;">Quick Start</h3>
              <ol style="margin:0 0 32px;padding-left:20px;color:#52525b;font-size:14px;line-height:1.8;">
                <li>Install StyloBridge: <code style="background:#f4f4f5;padding:2px 6px;border-radius:3px;font-size:13px;">uv tool install stylobridge</code></li>
                <li>Open your Claude Desktop config and add your license key to the <code style="background:#f4f4f5;padding:2px 6px;border-radius:3px;font-size:13px;">STYLOBRIDGE_LICENSE</code> env var</li>
                <li>Ask Claude: <em>"Convert my report to a Word doc"</em></li>
              </ol>

              <!-- Expiration -->
              <p style="margin:0 0 8px;color:#a1a1aa;font-size:13px;">
                This license expires on <strong>${params.expires}</strong>.
              </p>
            </td>
          </tr>
          <!-- Footer -->
          <tr>
            <td style="background:#f9fafb;padding:24px 40px;border-top:1px solid #e4e4e7;">
              <p style="margin:0;color:#a1a1aa;font-size:12px;">
                Need help? Reply to this email or visit
                <a href="https://stylobridge.ai" style="color:#3b82f6;">stylobridge.ai</a>
              </p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>`;
}

interface DemoEmailParams {
  prospectName: string;
  token: string;
  expires: string;
}

export function demoEmail(params: DemoEmailParams): string {
  return licenseEmail({
    planName: `Enterprise Trial`,
    token: params.token,
    expires: params.expires,
  }).replace(
    "Your license key is ready.",
    `Hi ${params.prospectName}, welcome to StyloBridge! Here's your 60-day enterprise trial — full access, no restrictions.`
  );
}
