/**
 * Cloudflare Worker environment bindings.
 */
export interface Env {
  // Secrets (set via `wrangler secret put`)
  SIGNING_PRIVATE_KEY: string;
  STRIPE_SECRET_KEY: string;
  STRIPE_WEBHOOK_SECRET: string;
  STRIPE_PRICE_INDIVIDUAL: string;
  STRIPE_PRICE_TEAM: string;
  STRIPE_PRICE_ENTERPRISE: string;
  RESEND_API_KEY: string;
  DEMO_PASSWORD: string;

  // Vars (set in wrangler.toml)
  ALLOWED_ORIGIN: string;
}
