"""Pydantic model for StyloBridge JWT license claims.

Single source of truth used by both license.py (validation) and
gen_license.py (token generation).
"""

from datetime import datetime

from pydantic import BaseModel, Field, field_validator


class LicenseClaims(BaseModel):
    """JWT payload schema for StyloBridge enterprise licenses."""

    sub: str = Field(..., description="Organization identifier (e.g. 'acme-corp')")
    iss: str = Field("stylobridge", description="Token issuer")
    aud: str = Field("stylobridge", description="Token audience (prevents cross-app replay)")
    tier: str = Field(..., description="License tier: 'standard' or 'enterprise'")
    seats: int = Field(1, ge=1, description="Licensed seat count (metadata only, not enforced)")
    iat: datetime = Field(..., description="Issued-at timestamp")
    exp: datetime = Field(..., description="Expiration timestamp")

    @field_validator("tier")
    @classmethod
    def tier_must_be_valid(cls, v: str) -> str:
        allowed = {"standard", "enterprise"}
        if v not in allowed:
            raise ValueError(f"Tier must be one of {allowed}, got '{v}'")
        return v

    @field_validator("iss")
    @classmethod
    def issuer_must_be_stylobridge(cls, v: str) -> str:
        if v != "stylobridge":
            raise ValueError("Issuer must be 'stylobridge'")
        return v

    @field_validator("aud")
    @classmethod
    def audience_must_be_stylobridge(cls, v: str) -> str:
        if v != "stylobridge":
            raise ValueError("Audience must be 'stylobridge'")
        return v
