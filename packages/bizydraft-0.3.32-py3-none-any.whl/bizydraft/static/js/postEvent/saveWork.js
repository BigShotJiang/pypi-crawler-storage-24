import { createMD5, createCRC64, createSHA256 } from "../lib/hash-wasm.js";

/**
 * 计算文件的复合哈希值 (SHA256 based on MD5 + CRC64)
 * 算法: sha256(base64(md5) + crc64_decimal)
 * @param {Blob|File|string} content - 文件、Blob 或字符串
 * @returns {Promise<string>} SHA256 哈希值
 */
export async function calculateWorkflowHash(content) {
  let blob = content;
  if (typeof content === "string") {
    blob = new Blob([content], { type: "application/json" });
  }

  const chunkSize = 1024 * 1024; // 1MB chunks

  const md5Hasher = await createMD5();
  const crc64Hasher = await createCRC64();
  const sha256Hasher = await createSHA256();

  md5Hasher.init();
  crc64Hasher.init();
  sha256Hasher.init();

  const fileSize = blob.size;
  let offset = 0;

  // 分块读取并计算 MD5 和 CRC64
  while (offset < fileSize) {
    const chunk = blob.slice(offset, offset + chunkSize);
    const buffer = await new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = (e) => resolve(e.target.result);
      reader.onerror = () => reject(new Error("FileReader error"));
      reader.readAsArrayBuffer(chunk);
    });

    const uint8Array = new Uint8Array(buffer);
    md5Hasher.update(uint8Array);
    crc64Hasher.update(uint8Array);

    offset += buffer.byteLength;
  }

  // 处理 MD5: Hex -> Base64
  const md5HashHex = md5Hasher.digest();
  const md5Bytes = new Uint8Array(
    md5HashHex.match(/.{2}/g).map((byte) => parseInt(byte, 16))
  );
  const base64Md5 = btoa(String.fromCharCode(...md5Bytes));

  // 处理 CRC64: Hex -> Decimal String
  const crc64HashHex = crc64Hasher.digest();
  const flippedCrc64 = BigInt("0x" + crc64HashHex).toString(10);

  // 计算最终 SHA256
  const combinedString = `${base64Md5}${flippedCrc64}`;
  sha256Hasher.update(combinedString);
  const sha256sum = sha256Hasher.digest();

  return sha256sum;
}

/**
 * 保存工作流并计算哈希值
 * @param {object} workflow - ComfyUI 工作流对象
 * @returns {Promise<{checksum: string, workflowStr: string}>}
 */
export async function saveWork(workflow) {
  try {
    // 兼容处理：如果传入的是 { workflow: {...} } 格式，提取内层
    let actualWorkflow = workflow;
    if (workflow.workflow && typeof workflow.workflow === "object") {
      actualWorkflow = workflow.workflow;
    }

    // 清理 extra 字段
    if (actualWorkflow.extra) {
      delete actualWorkflow.extra;
    }

    // 序列化并计算哈希
    const workflowStr = JSON.stringify(actualWorkflow);
    const checksum = await calculateWorkflowHash(workflowStr);

    return {
      checksum,
      workflowStr,
    };
  } catch (error) {
    console.error("Hash calculation failed:", error);
    throw error;
  }
}
