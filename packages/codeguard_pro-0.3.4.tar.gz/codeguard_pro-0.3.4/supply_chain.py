"""Supply chain scanner — catches malicious/typosquat packages BEFORE install.

Queries PyPI and npm registries to flag suspicious packages:
young age, low downloads, typosquatting, missing repo links.
"""

import json
import os
import re
from datetime import datetime, timezone
from difflib import SequenceMatcher
from typing import Dict, List

import requests

# Popular packages to check typosquatting against
POPULAR_PIP = [
    "requests", "numpy", "pandas", "flask", "django", "boto3", "setuptools",
    "urllib3", "cryptography", "pillow", "scipy", "tensorflow", "torch",
    "beautifulsoup4", "sqlalchemy", "celery", "redis", "pytest", "black",
    "pydantic", "fastapi", "httpx", "aiohttp", "paramiko", "jinja2",
]
POPULAR_NPM = [
    "express", "react", "lodash", "axios", "webpack", "typescript", "moment",
    "commander", "chalk", "debug", "uuid", "dotenv", "cors", "mongoose",
    "next", "vue", "angular", "jquery", "passport", "eslint", "prettier",
    "nodemon", "jest", "mocha", "socket.io", "graphql", "prisma",
]

SUSPICIOUS_EMAIL_DOMAINS = [
    "tempmail", "guerrilla", "throwaway", "mailinator", "yopmail",
    "10minutemail", "trashmail", "fakeinbox",
]

# ── Known Compromised Packages (CVE/Advisory database) ──
# Format: "package_name": {"versions": [...], "advisory": "...", "date": "...", "severity": "CRITICAL"}
KNOWN_COMPROMISED = {
    # TeamPCP campaign — March 2026
    "litellm": {
        "versions": ["1.82.7", "1.82.8"],
        "advisory": "TeamPCP supply chain attack — .pth credential stealer (SSH, cloud, crypto, Slack, Discord)",
        "date": "2026-03-24",
        "severity": "CRITICAL",
        "cve": "N/A — active campaign",
    },
    "telnyx": {
        "versions": ["4.87.1", "4.87.2"],
        "advisory": "TeamPCP supply chain attack — credential stealer via import-time execution",
        "date": "2026-03-27",
        "severity": "CRITICAL",
        "cve": "N/A — active campaign",
    },
    # Historical compromises
    "ctx": {
        "versions": ["0.2.2", "0.2.6"],
        "advisory": "Account takeover via expired domain — exfiltrates AWS credentials",
        "date": "2022-05-15",
        "severity": "CRITICAL",
        "cve": "N/A",
    },
    "colourama": {
        "versions": ["*"],
        "advisory": "Typosquat of colorama — Bitcoin clipboard hijacker",
        "date": "2018-10-01",
        "severity": "CRITICAL",
        "cve": "N/A",
    },
    "sympy-dev": {
        "versions": ["*"],
        "advisory": "Typosquat of sympy — deploys cryptominer",
        "date": "2026-02-01",
        "severity": "CRITICAL",
        "cve": "N/A",
    },
    # Lazarus Group (North Korea) — Feb 2026
    "pycryptoenv": {
        "versions": ["*"],
        "advisory": "Lazarus Group — fake recruitment campaign malware",
        "date": "2026-02-01",
        "severity": "CRITICAL",
        "cve": "N/A",
    },
    "pycryptoconf": {
        "versions": ["*"],
        "advisory": "Lazarus Group — fake recruitment campaign malware",
        "date": "2026-02-01",
        "severity": "CRITICAL",
        "cve": "N/A",
    },
}

# Suspicious .pth payload patterns (TeamPCP attack vector)
PTH_SUSPICIOUS_PATTERNS = [
    "subprocess", "os.system", "exec(", "eval(", "base64",
    "requests.post", "requests.get", "urllib", "socket",
    "import os", "__import__", "compile(", "marshal",
]

OSV_API_BASE = "https://api.osv.dev/v1"
OSV_TIMEOUT = 5

MAX_AGE_DAYS = 30
TYPO_SIMILARITY_THRESHOLD = 0.85


def parse_package_spec(spec: str) -> Dict:
    """Split a requirement string into name/operator/version without installing it."""
    raw = spec.strip()
    if not raw:
        return {"raw": spec, "name": "", "operator": "", "version": ""}

    requirement = raw.split(";", 1)[0].strip()
    match = re.match(
        r"^\s*([A-Za-z0-9_.-]+(?:\[[A-Za-z0-9_,.-]+\])?)\s*(==|>=|<=|~=|!=|>|<)?\s*([A-Za-z0-9*_.+-]*)\s*$",
        requirement,
    )
    if not match:
        return {"raw": spec, "name": requirement, "operator": "", "version": ""}

    name = match.group(1).split("[", 1)[0].strip()
    operator = match.group(2) or ""
    version = (match.group(3) or "").strip()
    return {"raw": spec, "name": name, "operator": operator, "version": version}


def _days_since(iso_date: str) -> int:
    """Return days between an ISO date string and now."""
    try:
        dt = datetime.fromisoformat(iso_date.replace("Z", "+00:00"))
        return (datetime.now(timezone.utc) - dt).days
    except Exception:
        return -1


def _typosquat_check(name: str, popular: List[str]) -> List[str]:
    """Return popular package names that are suspiciously similar."""
    hits = []
    for p in popular:
        if p == name:
            continue
        ratio = SequenceMatcher(None, name.lower(), p.lower()).ratio()
        if ratio >= TYPO_SIMILARITY_THRESHOLD:
            hits.append(p)
    return hits


def _suspicious_email(email: str) -> bool:
    if not email:
        return False
    lower = email.lower()
    return any(d in lower for d in SUSPICIOUS_EMAIL_DOMAINS)


def query_osv(package_name: str, version: str, ecosystem: str = "PyPI") -> Dict:
    """Query OSV.dev for known vulnerabilities for a specific package+version.

    OSV.dev is a free, no-auth vulnerability database aggregating CVEs from
    multiple sources (NVD, GitHub Advisories, PyPI, npm, etc.).

    Args:
        package_name: Package name (e.g. "requests")
        version: Exact version string (e.g. "2.31.0")
        ecosystem: Package ecosystem — "PyPI", "npm", "Go", "crates.io", etc.

    Returns:
        Dict with vuln_count, severity_summary, cves, and raw vulns list.
    """
    url = f"{OSV_API_BASE}/query"
    payload = {
        "package": {"name": package_name, "ecosystem": ecosystem},
        "version": version,
    }

    try:
        resp = requests.post(url, json=payload, timeout=OSV_TIMEOUT)
    except requests.RequestException as e:
        return {
            "package": package_name,
            "version": version,
            "ecosystem": ecosystem,
            "error": f"OSV API request failed: {e}",
            "vulns": [],
            "vuln_count": 0,
        }

    if resp.status_code != 200:
        return {
            "package": package_name,
            "version": version,
            "ecosystem": ecosystem,
            "error": f"OSV API returned {resp.status_code}",
            "vulns": [],
            "vuln_count": 0,
        }

    data = resp.json()
    raw_vulns = data.get("vulns", [])

    # Extract structured summary from each vulnerability
    vulns_summary = []
    cves = []
    severity_counts = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0, "UNKNOWN": 0}

    for vuln in raw_vulns:
        vuln_id = vuln.get("id", "unknown")
        summary = vuln.get("summary", "No summary available")
        aliases = vuln.get("aliases", [])
        cve_ids = [a for a in aliases if a.startswith("CVE-")]
        cves.extend(cve_ids)

        # Determine severity from database_specific or severity field
        severity = "UNKNOWN"
        severity_entries = vuln.get("severity", [])
        for sev in severity_entries:
            score_str = sev.get("score", "")
            # CVSS v3 score is in the vector string; extract base score
            if "CVSS" in sev.get("type", ""):
                try:
                    # Parse CVSS base score from vector (last numeric segment)
                    parts = score_str.split("/")
                    for part in parts:
                        if part.startswith("AV:") or part.startswith("CVSS:"):
                            continue
                    # Try to find base score in database_specific
                except Exception:
                    pass

        # Fallback: check database_specific for severity
        db_specific = vuln.get("database_specific", {})
        raw_severity = db_specific.get("severity", "")
        if isinstance(raw_severity, str) and raw_severity.upper() in severity_counts:
            severity = raw_severity.upper()

        # Also check ecosystem-specific severity in affected ranges
        for affected in vuln.get("affected", []):
            eco_sev = affected.get("database_specific", {}).get("severity", "")
            if isinstance(eco_sev, str) and eco_sev.upper() in severity_counts:
                severity = eco_sev.upper()
                break

        severity_counts[severity] += 1
        vulns_summary.append({
            "id": vuln_id,
            "summary": summary,
            "cves": cve_ids if cve_ids else [vuln_id],
            "severity": severity,
        })

    return {
        "package": package_name,
        "version": version,
        "ecosystem": ecosystem,
        "vuln_count": len(raw_vulns),
        "cves": list(set(cves)),
        "severity_summary": {k: v for k, v in severity_counts.items() if v > 0},
        "vulns": vulns_summary,
    }


def query_osv_batch(packages: List[Dict]) -> Dict:
    """Batch query OSV.dev for vulnerabilities across multiple packages.

    Args:
        packages: List of dicts, each with "name", "version", and optional "ecosystem"
                  (defaults to "PyPI"). Example:
                  [{"name": "requests", "version": "2.31.0", "ecosystem": "PyPI"}]

    Returns:
        Aggregated dict with total vuln count, per-package results, and summary.
    """
    url = f"{OSV_API_BASE}/querybatch"
    queries = []
    for pkg in packages:
        queries.append({
            "package": {
                "name": pkg["name"],
                "ecosystem": pkg.get("ecosystem", "PyPI"),
            },
            "version": pkg.get("version", ""),
        })

    try:
        resp = requests.post(url, json={"queries": queries}, timeout=OSV_TIMEOUT)
    except requests.RequestException as e:
        return {
            "error": f"OSV batch API request failed: {e}",
            "total_vulns": 0,
            "packages_scanned": len(packages),
            "results": [],
        }

    if resp.status_code != 200:
        return {
            "error": f"OSV batch API returned {resp.status_code}",
            "total_vulns": 0,
            "packages_scanned": len(packages),
            "results": [],
        }

    data = resp.json()
    batch_results = data.get("results", [])

    results = []
    total_vulns = 0
    packages_with_vulns = 0

    for i, pkg in enumerate(packages):
        entry = batch_results[i] if i < len(batch_results) else {}
        raw_vulns = entry.get("vulns", [])
        vuln_count = len(raw_vulns)
        total_vulns += vuln_count

        cves = []
        for vuln in raw_vulns:
            aliases = vuln.get("aliases", [])
            cves.extend(a for a in aliases if a.startswith("CVE-"))

        if vuln_count > 0:
            packages_with_vulns += 1

        results.append({
            "package": pkg["name"],
            "version": pkg.get("version", ""),
            "ecosystem": pkg.get("ecosystem", "PyPI"),
            "vuln_count": vuln_count,
            "cves": list(set(cves)),
            "vuln_ids": [v.get("id", "") for v in raw_vulns],
        })

    return {
        "packages_scanned": len(packages),
        "packages_with_vulns": packages_with_vulns,
        "total_vulns": total_vulns,
        "results": results,
    }


def scan_pip_package(package_name: str, requested_version: str = "") -> Dict:
    """Check a pip package BEFORE install. Returns verdict + reasons."""
    reasons = []
    severity = "SAFE"

    url = f"https://pypi.org/pypi/{package_name}/json"
    try:
        resp = requests.get(url, timeout=10)
    except requests.RequestException as e:
        return {"package": package_name, "registry": "pypi",
                "verdict": "ERROR", "reasons": [f"Request failed: {e}"]}

    if resp.status_code == 404:
        return {"package": package_name, "registry": "pypi",
                "verdict": "ERROR", "reasons": ["Package not found on PyPI"]}
    if resp.status_code != 200:
        return {"package": package_name, "registry": "pypi",
                "verdict": "ERROR", "reasons": [f"PyPI returned {resp.status_code}"]}

    data = resp.json()
    info = data.get("info", {})

    # ── Known compromised package check (FIRST — highest priority) ──
    if package_name.lower() in KNOWN_COMPROMISED:
        entry = KNOWN_COMPROMISED[package_name.lower()]
        current_ver = info.get("version", "")
        matched_version = ""
        if requested_version and requested_version in entry["versions"]:
            matched_version = requested_version
            reasons.append(
                f"KNOWN COMPROMISED REQUESTED VERSION: {package_name}=={requested_version} "
                f"matches {entry['advisory']} (date: {entry['date']})"
            )
            severity = "BLOCKED"
        elif "*" in entry["versions"] or current_ver in entry["versions"]:
            matched_version = current_ver
            reasons.append(f"KNOWN COMPROMISED: {entry['advisory']} (date: {entry['date']})")
            severity = "BLOCKED"
        else:
            reasons.append(f"Previously compromised ({entry['date']}): {entry['advisory']} — compromised versions: {', '.join(entry['versions'])}")
            severity = max(severity, "WARNING", key=lambda s: ["SAFE", "WARNING", "BLOCKED"].index(s))
        if matched_version:
            reasons.append(f"Compromised version matched: {matched_version}")

    # ── OSV.dev vulnerability check ──
    current_ver = info.get("version", "")
    if current_ver:
        osv_result = query_osv(package_name, current_ver, ecosystem="PyPI")
        if osv_result.get("vuln_count", 0) > 0:
            cve_str = ", ".join(osv_result["cves"]) if osv_result["cves"] else "see OSV IDs"
            reasons.append(
                f"OSV.dev: {osv_result['vuln_count']} known vulnerability(ies) "
                f"in v{current_ver} ({cve_str})"
            )
            # Escalate to BLOCKED if any CRITICAL vulns found
            sev_summary = osv_result.get("severity_summary", {})
            if sev_summary.get("CRITICAL", 0) > 0:
                severity = "BLOCKED"
            else:
                severity = max(severity, "WARNING",
                               key=lambda s: ["SAFE", "WARNING", "BLOCKED"].index(s))

    # Age check
    releases = data.get("releases", {})
    first_release = None
    for ver, files in releases.items():
        for f in files:
            upload = f.get("upload_time_iso_8601") or f.get("upload_time")
            if upload:
                if first_release is None or upload < first_release:
                    first_release = upload
    if first_release:
        age = _days_since(first_release)
        if 0 <= age < MAX_AGE_DAYS:
            reasons.append(f"Very new package — first released {age} days ago")
            severity = max(severity, "WARNING", key=lambda s: ["SAFE", "WARNING", "BLOCKED"].index(s))

    # Typosquatting
    typo_hits = _typosquat_check(package_name, POPULAR_PIP)
    if typo_hits:
        reasons.append(f"Name similar to popular package(s): {', '.join(typo_hits)}")
        severity = "BLOCKED"

    # Missing homepage / repo
    home = info.get("home_page") or ""
    project_urls = info.get("project_urls") or {}
    has_repo = bool(home) or any(
        "github" in str(v).lower() or "gitlab" in str(v).lower()
        for v in project_urls.values()
    )
    if not has_repo:
        reasons.append("No homepage or repository link")
        severity = max(severity, "WARNING", key=lambda s: ["SAFE", "WARNING", "BLOCKED"].index(s))

    # Suspicious author email
    email = info.get("author_email") or ""
    if _suspicious_email(email):
        reasons.append(f"Suspicious author email: {email}")
        severity = "BLOCKED"

    # Very few downloads — use latest version file download count as proxy
    latest_ver = info.get("version", "")
    latest_files = releases.get(latest_ver, [])
    if latest_files:
        total_downloads = sum(f.get("downloads", 0) for f in latest_files)
        # PyPI deprecated per-file download counts (returns 0), so skip if 0
        # but flag if data exists and is very low
        if total_downloads > 0 and total_downloads < 100:
            reasons.append(f"Very few downloads: {total_downloads}")
            severity = max(severity, "WARNING", key=lambda s: ["SAFE", "WARNING", "BLOCKED"].index(s))

    if not reasons:
        reasons.append("Package looks legitimate")

    return {"package": package_name, "registry": "pypi",
            "requested_version": requested_version or None,
            "verdict": severity, "reasons": reasons}


def scan_npm_package(package_name: str) -> Dict:
    """Check an npm package BEFORE install. Returns verdict + reasons."""
    reasons = []
    severity = "SAFE"

    url = f"https://registry.npmjs.org/{package_name}"
    try:
        resp = requests.get(url, timeout=10)
    except requests.RequestException as e:
        return {"package": package_name, "registry": "npm",
                "verdict": "ERROR", "reasons": [f"Request failed: {e}"]}

    if resp.status_code == 404:
        return {"package": package_name, "registry": "npm",
                "verdict": "ERROR", "reasons": ["Package not found on npm"]}
    if resp.status_code != 200:
        return {"package": package_name, "registry": "npm",
                "verdict": "ERROR", "reasons": [f"npm returned {resp.status_code}"]}

    data = resp.json()

    # Age check — look at earliest version time
    time_data = data.get("time", {})
    created = time_data.get("created")
    if created:
        age = _days_since(created)
        if 0 <= age < MAX_AGE_DAYS:
            reasons.append(f"Very new package — created {age} days ago")
            severity = "WARNING"

    # Typosquatting
    typo_hits = _typosquat_check(package_name, POPULAR_NPM)
    if typo_hits:
        reasons.append(f"Name similar to popular package(s): {', '.join(typo_hits)}")
        severity = "BLOCKED"

    # Missing repo
    latest = data.get("dist-tags", {}).get("latest", "")
    latest_data = data.get("versions", {}).get(latest, {})
    repo = latest_data.get("repository") or data.get("repository")
    if not repo:
        reasons.append("No repository link")
        severity = max(severity, "WARNING", key=lambda s: ["SAFE", "WARNING", "BLOCKED"].index(s))

    # Suspicious maintainer email
    maintainers = data.get("maintainers", [])
    for m in maintainers:
        email = m.get("email", "")
        if _suspicious_email(email):
            reasons.append(f"Suspicious maintainer email: {email}")
            severity = "BLOCKED"
            break

    if not reasons:
        reasons.append("Package looks legitimate")

    return {"package": package_name, "registry": "npm",
            "verdict": severity, "reasons": reasons}


def scan_requirements(file_path: str) -> Dict:
    """Scan a requirements.txt and check every package."""
    resolved = os.path.abspath(file_path)
    if not os.path.exists(resolved):
        return {"error": f"File not found: {resolved}"}

    with open(resolved, "r") as f:
        lines = f.readlines()

    results = []
    for line in lines:
        line = line.strip()
        if not line or line.startswith("#") or line.startswith("-"):
            continue
        parsed = parse_package_spec(line)
        pkg = parsed["name"]
        if pkg:
            requested_version = parsed["version"] if parsed["operator"] == "==" else ""
            results.append(scan_pip_package(pkg, requested_version=requested_version))

    blocked = [r for r in results if r["verdict"] == "BLOCKED"]
    warnings = [r for r in results if r["verdict"] == "WARNING"]

    return {
        "file": resolved,
        "total_packages": len(results),
        "blocked": len(blocked),
        "warnings": len(warnings),
        "safe": len(results) - len(blocked) - len(warnings),
        "results": results,
    }


# ── .pth File Scanner (TeamPCP attack vector) ──────────────

def scan_pth_files(site_packages_path: str = None) -> Dict:
    """Scan site-packages for malicious .pth files (TeamPCP-class attack).

    .pth files in site-packages execute on EVERY Python startup.
    Attackers abuse this for persistence — no import needed.
    """
    import glob
    import site

    if site_packages_path is None:
        paths = site.getsitepackages()
    else:
        paths = [site_packages_path]

    findings = []
    scanned = 0

    for sp in paths:
        if not os.path.isdir(sp):
            continue
        for pth_file in glob.glob(os.path.join(sp, "*.pth")):
            scanned += 1
            try:
                with open(pth_file, "r", errors="ignore") as f:
                    content = f.read()
            except Exception:
                continue

            # .pth files that start with "import" execute code
            # Safe patterns: namespace packages and coverage hooks
            safe_patterns = [
                "import pkgutil; pkgutil.extend_path",  # namespace packages (clean)
                "import importlib; importlib.import",    # namespace packages (clean)
                "importlib.util.module_from_spec",       # namespace packages (obfuscated)
                "importlib.machinery.PathFinder",        # namespace packages (obfuscated)
                "coverage.process_startup",              # coverage.py
                "import _distutils_hack",                # setuptools compat
                "SETUPTOOLS_USE_DISTUTILS",              # setuptools distutils shim
                "COVERAGE_PROCESS_START",                # coverage.py env check
            ]

            suspicious_lines = []
            for i, line in enumerate(content.split("\n"), 1):
                line_stripped = line.strip()
                if not line_stripped or line_stripped.startswith("#"):
                    continue
                # Lines starting with "import" are executed as code
                if line_stripped.startswith("import "):
                    # Skip known-safe patterns (check full content since .pth is often one-liner)
                    if any(safe in content for safe in safe_patterns):
                        continue
                    for pattern in PTH_SUSPICIOUS_PATTERNS:
                        if pattern in content:
                            suspicious_lines.append((i, line_stripped, pattern))
                            break

            if suspicious_lines:
                findings.append({
                    "file": pth_file,
                    "severity": "CRITICAL",
                    "category": "malicious-pth",
                    "lines": suspicious_lines,
                    "message": f"Suspicious .pth file executes code at Python startup — {len(suspicious_lines)} suspect line(s)",
                })

    return {
        "scanned": scanned,
        "findings": findings,
        "site_packages": paths,
        "verdict": "BLOCKED" if findings else "SAFE",
    }


def scan_requirements_unpinned(file_path: str) -> Dict:
    """Detect unpinned or loosely pinned dependencies — supply chain risk.

    Unpinned deps (e.g. 'litellm' or 'litellm>=1.0') will silently pull
    a compromised version if the attacker publishes a new release.
    """
    resolved = os.path.abspath(file_path)
    if not os.path.exists(resolved):
        return {"error": f"File not found: {resolved}"}

    with open(resolved, "r") as f:
        lines = f.readlines()

    findings = []
    total = 0

    for line_num, line in enumerate(lines, 1):
        line = line.strip()
        if not line or line.startswith("#") or line.startswith("-"):
            continue
        total += 1

        # Strictly pinned: package==1.2.3
        if "==" in line:
            continue

        # Extract package name
        pkg = line.split(">=")[0].split("<=")[0].split("~=")[0].split("!=")[0].split(">")[0].split("<")[0].split("[")[0].strip()

        if ">=" in line or "~=" in line:
            findings.append({
                "line": line_num,
                "package": pkg,
                "spec": line,
                "severity": "MEDIUM",
                "message": f"Loosely pinned: '{line}' — use == for exact version to prevent supply chain attacks",
            })
        else:
            findings.append({
                "line": line_num,
                "package": pkg,
                "spec": line,
                "severity": "HIGH",
                "message": f"Unpinned: '{line}' — attacker can publish malicious version that auto-installs",
            })

    pinned = total - len(findings)
    return {
        "file": resolved,
        "total_packages": total,
        "pinned": pinned,
        "unpinned": len(findings),
        "pin_rate": f"{(pinned / total * 100):.0f}%" if total > 0 else "N/A",
        "findings": findings,
        "verdict": "BLOCKED" if any(f["severity"] == "HIGH" for f in findings) else "WARNING" if findings else "SAFE",
    }


def scan_github_actions(workflow_dir: str = ".github/workflows") -> Dict:
    """Audit GitHub Actions for mutable tag references (TeamPCP attack vector).

    TeamPCP compromised Trivy by rewriting git tags to point to malicious code.
    Actions pinned to SHA are immune. Actions using tags (v1, v2, latest) are vulnerable.
    """
    import glob as glob_mod
    import re

    resolved = os.path.abspath(workflow_dir)
    if not os.path.isdir(resolved):
        return {"error": f"Directory not found: {resolved}"}

    findings = []
    files_scanned = 0

    for yml_file in glob_mod.glob(os.path.join(resolved, "*.yml")) + glob_mod.glob(os.path.join(resolved, "*.yaml")):
        files_scanned += 1
        try:
            with open(yml_file, "r") as f:
                content = f.read()
        except Exception:
            continue

        for i, line in enumerate(content.split("\n"), 1):
            # Match: uses: owner/repo@ref
            match = re.search(r'uses:\s*([^@\s]+)@(\S+)', line)
            if not match:
                continue

            action = match.group(1)
            ref = match.group(2)

            # SHA-pinned refs are 40 hex chars
            is_sha = bool(re.match(r'^[0-9a-f]{40}$', ref))

            if not is_sha:
                severity = "HIGH" if ref in ("main", "master", "latest") else "MEDIUM"
                findings.append({
                    "file": os.path.basename(yml_file),
                    "line": i,
                    "action": action,
                    "ref": ref,
                    "severity": severity,
                    "message": f"Action '{action}@{ref}' uses mutable tag — pin to SHA to prevent tag rewrite attacks (TeamPCP-class)",
                })

    return {
        "directory": resolved,
        "files_scanned": files_scanned,
        "findings": findings,
        "sha_pinned": files_scanned > 0 and len(findings) == 0,
        "verdict": "BLOCKED" if any(f["severity"] == "HIGH" for f in findings) else "WARNING" if findings else "SAFE",
    }


# ── Self-test ──────────────────────────────────────────────
if __name__ == "__main__":
    print("=== Supply Chain Scanner Self-Test ===\n")

    # Known good package
    print("1) Scanning 'requests' (should be SAFE)...")
    result = scan_pip_package("requests")
    print(f"   Verdict: {result['verdict']}")
    print(f"   Reasons: {result['reasons']}\n")
    assert result["verdict"] == "SAFE", f"Expected SAFE, got {result['verdict']}"

    # Typosquatting test — name close to 'requests'
    print("2) Scanning 'requets' (typosquat of 'requests', should be BLOCKED)...")
    result = scan_pip_package("requets")
    print(f"   Verdict: {result['verdict']}")
    print(f"   Reasons: {result['reasons']}\n")
    # May be 404 or BLOCKED depending on whether it exists
    if result["verdict"] != "ERROR":
        assert result["verdict"] == "BLOCKED", f"Expected BLOCKED, got {result['verdict']}"
    else:
        print("   (package doesn't exist on PyPI — typosquat detection N/A)\n")

    # npm known good
    print("3) Scanning npm 'express' (should be SAFE)...")
    result = scan_npm_package("express")
    print(f"   Verdict: {result['verdict']}")
    print(f"   Reasons: {result['reasons']}\n")
    assert result["verdict"] == "SAFE", f"Expected SAFE, got {result['verdict']}"

    # npm typosquat
    print("4) Scanning npm 'expresss' (typosquat of 'express')...")
    result = scan_npm_package("expresss")
    print(f"   Verdict: {result['verdict']}")
    print(f"   Reasons: {result['reasons']}\n")
    if result["verdict"] != "ERROR":
        assert result["verdict"] == "BLOCKED", f"Expected BLOCKED, got {result['verdict']}"
    else:
        print("   (package doesn't exist on npm — typosquat detection N/A)\n")

    print("=== All tests passed ===")
