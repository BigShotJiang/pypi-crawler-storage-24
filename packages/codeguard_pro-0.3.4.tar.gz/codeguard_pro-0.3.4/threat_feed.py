"""Signed threat-feed prototype for CodeGuard.

This is a practical Phase 2 building block:
- local signed feed creation
- local feed verification
- feed snapshot fetch/download
- advisory generation

Prototype note:
- uses HMAC-SHA256 with a shared secret for signing
- good enough for a small-team prototype and hackathon demo
- can later be replaced with asymmetric signing without changing the feed shape
"""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import time
from typing import Dict, List

import requests


MANIFEST_NAME = "feed_manifest.json"
DEFAULT_FEED_FILES = [
    "compromised_packages.json",
    "compromised_versions.json",
    "bad_action_refs.json",
    "pth_indicators.json",
    "ioc_domains.json",
]


def _canonical_json(data: Dict) -> bytes:
    return json.dumps(data, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _load_secret(key_file: str = "", env_var: str = "CODEGUARD_FEED_SECRET") -> str:
    if key_file:
        with open(key_file, "r", encoding="utf-8") as f:
            return f.read().strip()
    return os.environ.get(env_var, "").strip()


def _sign_payload(payload: Dict, secret: str) -> str:
    return hmac.new(secret.encode("utf-8"), _canonical_json(payload), hashlib.sha256).hexdigest()


def _read_json(path: str) -> Dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _write_json(path: str, data: Dict) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
        f.write("\n")


def init_feed(feed_dir: str) -> Dict:
    """Create a starter feed directory if missing."""
    resolved = os.path.abspath(feed_dir)
    os.makedirs(resolved, exist_ok=True)

    defaults = {
        "compromised_packages.json": {"packages": {}},
        "compromised_versions.json": {"packages": {}},
        "bad_action_refs.json": {"refs": []},
        "pth_indicators.json": {"patterns": []},
        "ioc_domains.json": {"domains": []},
    }

    created = []
    for name, payload in defaults.items():
        path = os.path.join(resolved, name)
        if not os.path.exists(path):
            _write_json(path, payload)
            created.append(name)

    return {"feed_dir": resolved, "created": created, "status": "READY"}


def build_feed(feed_dir: str, key_file: str = "", expires_in_hours: int = 24) -> Dict:
    """Create/update the signed manifest for a feed directory."""
    resolved = os.path.abspath(feed_dir)
    secret = _load_secret(key_file)
    if not secret:
        return {"status": "ERROR", "error": "Missing signing secret. Use --key-file or CODEGUARD_FEED_SECRET."}

    init_feed(resolved)

    files = {}
    for name in DEFAULT_FEED_FILES:
        path = os.path.join(resolved, name)
        if not os.path.exists(path):
            continue
        with open(path, "rb") as f:
            raw = f.read()
        files[name] = {
            "sha256": _sha256_bytes(raw),
            "bytes": len(raw),
        }

    payload = {
        "version": str(int(time.time())),
        "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "expires_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(time.time() + expires_in_hours * 3600)),
        "files": files,
        "signing": {
            "scheme": "hmac-sha256",
            "key_hint": os.path.basename(key_file) if key_file else "env:CODEGUARD_FEED_SECRET",
        },
    }
    signature = _sign_payload(payload, secret)
    manifest = {"payload": payload, "signature": signature}
    manifest_path = os.path.join(resolved, MANIFEST_NAME)
    _write_json(manifest_path, manifest)
    return {"status": "SIGNED", "manifest": manifest_path, "files": len(files), "version": payload["version"]}


def verify_feed(feed_dir: str, key_file: str = "") -> Dict:
    """Verify feed manifest signature and file hashes."""
    resolved = os.path.abspath(feed_dir)
    secret = _load_secret(key_file)
    if not secret:
        return {"status": "ERROR", "error": "Missing signing secret. Use --key-file or CODEGUARD_FEED_SECRET."}

    manifest_path = os.path.join(resolved, MANIFEST_NAME)
    if not os.path.exists(manifest_path):
        return {"status": "ERROR", "error": f"Missing manifest: {manifest_path}"}

    manifest = _read_json(manifest_path)
    payload = manifest.get("payload", {})
    signature = manifest.get("signature", "")
    expected = _sign_payload(payload, secret)
    if not hmac.compare_digest(signature, expected):
        return {"status": "ERROR", "error": "Invalid feed signature"}

    mismatches = []
    for name, meta in payload.get("files", {}).items():
        path = os.path.join(resolved, name)
        if not os.path.exists(path):
            mismatches.append({"file": name, "reason": "missing"})
            continue
        with open(path, "rb") as f:
            actual = _sha256_bytes(f.read())
        if actual != meta.get("sha256"):
            mismatches.append({"file": name, "reason": "hash-mismatch"})

    return {
        "status": "VERIFIED" if not mismatches else "ERROR",
        "version": payload.get("version"),
        "files": len(payload.get("files", {})),
        "mismatches": mismatches,
    }


def fetch_feed(base_url: str, out_dir: str, key_file: str = "", timeout: int = 10) -> Dict:
    """Download a feed snapshot and verify it locally."""
    resolved = os.path.abspath(out_dir)
    os.makedirs(resolved, exist_ok=True)

    manifest_url = f"{base_url.rstrip('/')}/{MANIFEST_NAME}"
    resp = requests.get(manifest_url, timeout=timeout)
    resp.raise_for_status()
    manifest = resp.json()
    _write_json(os.path.join(resolved, MANIFEST_NAME), manifest)

    files = []
    for name in manifest.get("payload", {}).get("files", {}).keys():
        data = requests.get(f"{base_url.rstrip('/')}/{name}", timeout=timeout)
        data.raise_for_status()
        with open(os.path.join(resolved, name), "wb") as f:
            f.write(data.content)
        files.append(name)

    verified = verify_feed(resolved, key_file=key_file)
    verified["downloaded"] = files
    return verified


def maybe_refresh_feed(
    base_url: str = "",
    out_dir: str = "",
    key_file: str = "",
    timeout: int = 10,
) -> Dict:
    """Refresh the threat feed if configured; otherwise return SKIPPED."""
    base = base_url or os.environ.get("CODEGUARD_FEED_URL", "").strip()
    target = out_dir or os.environ.get("CODEGUARD_FEED_DIR", "").strip()
    key = key_file or os.environ.get("CODEGUARD_FEED_KEY_FILE", "").strip()

    if not base or not target:
        return {"status": "SKIPPED", "reason": "Feed URL or directory not configured"}

    try:
        result = fetch_feed(base, target, key_file=key, timeout=timeout)
        result["source"] = base
        result["feed_dir"] = os.path.abspath(target)
        return result
    except Exception as e:
        return {"status": "ERROR", "error": str(e), "source": base, "feed_dir": os.path.abspath(target)}


def generate_advisory(
    title: str,
    summary: str,
    severity: str = "HIGH",
    packages: List[str] | None = None,
    iocs: List[str] | None = None,
    actions: List[str] | None = None,
) -> Dict:
    """Generate an incident/advisory document structure."""
    packages = packages or []
    iocs = iocs or []
    actions = actions or []
    advisory = {
        "title": title,
        "severity": severity,
        "summary": summary,
        "packages": packages,
        "iocs": iocs,
        "recommended_actions": actions,
        "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }
    markdown = "\n".join([
        f"# {title}",
        "",
        f"Severity: **{severity}**",
        "",
        "## Summary",
        summary,
        "",
        "## Affected Packages",
        *([f"- `{p}`" for p in packages] or ["- None listed"]),
        "",
        "## Indicators",
        *([f"- `{ioc}`" for ioc in iocs] or ["- None listed"]),
        "",
        "## Recommended Actions",
        *([f"- {a}" for a in actions] or ["- Investigate and rotate credentials if exposure is suspected"]),
    ])
    return {"advisory": advisory, "markdown": markdown}
