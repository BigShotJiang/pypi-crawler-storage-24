"""Opt-in telemetry prototype for CodeGuard threat-intel network."""

from __future__ import annotations

import hashlib
import json
import os
import platform
import re
import socket
import time
from typing import Dict, List

import requests


def _sha256(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _redact(text: str) -> str:
    text = re.sub(r"sk-[A-Za-z0-9_-]{10,}", "[REDACTED-API-KEY]", text)
    text = re.sub(r"AKIA[0-9A-Z]{16}", "[REDACTED-AWS-KEY]", text)
    text = re.sub(r"gh[pousr]_[A-Za-z0-9]{20,}", "[REDACTED-GITHUB-TOKEN]", text)
    return text


def build_telemetry_event(
    event_type: str,
    findings: List[Dict] | None = None,
    package: str = "",
    version: str = "",
    sample: str = "",
    source: str = "manual",
    include_sample: bool = False,
) -> Dict:
    """Build a minimal telemetry event with safe defaults."""
    findings = findings or []
    redacted_sample = _redact(sample) if include_sample and sample else ""
    event = {
        "event_type": event_type,
        "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "source": source,
        "package": package,
        "version": version,
        "finding_categories": sorted(set(f.get("category", "") for f in findings if f.get("category"))),
        "severity_counts": {
            sev: sum(1 for f in findings if f.get("severity") == sev)
            for sev in ["CRITICAL", "HIGH", "MEDIUM", "LOW"]
        },
        "sample_hash": _sha256(sample) if sample else "",
        "sample_preview": redacted_sample[:500] if redacted_sample else "",
        "host": {
            "hostname_hash": _sha256(socket.gethostname()),
            "platform": platform.system(),
            "python": platform.python_version(),
        },
    }
    return event


def send_telemetry(
    event: Dict,
    endpoint: str = "",
    api_key: str = "",
    timeout: int = 10,
) -> Dict:
    """Send a telemetry event to the configured endpoint if enabled."""
    url = endpoint or os.environ.get("CODEGUARD_TELEMETRY_URL", "").strip()
    token = api_key or os.environ.get("CODEGUARD_TELEMETRY_KEY", "").strip()
    enabled = os.environ.get("CODEGUARD_TELEMETRY_ENABLED", "").strip().lower() in {"1", "true", "yes"}

    if not enabled:
        return {"status": "SKIPPED", "reason": "Telemetry disabled"}
    if not url:
        return {"status": "ERROR", "error": "Missing telemetry endpoint"}

    headers = {"Content-Type": "application/json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"

    resp = requests.post(url, headers=headers, json=event, timeout=timeout)
    return {
        "status": "SENT" if resp.status_code < 300 else "ERROR",
        "status_code": resp.status_code,
        "endpoint": url,
        "body": resp.text[:300],
    }
