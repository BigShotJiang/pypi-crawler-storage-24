"""CodeGuard Pro MCP Server — AI agent security firewall.

The inline security gate that AI agents call BEFORE committing code.
Catches secrets, OWASP vulns, and blocks bad commits with fix suggestions.
"""

import os
import sys
import json
import argparse
from mcp.server.fastmcp import FastMCP


def _validate_path(path: str) -> str:
    """Validate and resolve file path. Prevents path traversal."""
    resolved = os.path.abspath(path)
    if not os.path.exists(resolved):
        raise ValueError(f"Path not found: {resolved}")
    return resolved


def create_server():
    mcp = FastMCP("codeguard-pro")

    # ═══════════════════════════════════════════════════
    # NEW: Inline Agent Security Gate
    # ═══════════════════════════════════════════════════

    @mcp.tool()
    def security_gate(diff: str) -> str:
        """INLINE SECURITY GATE — Call this BEFORE committing code.

        Returns APPROVED or BLOCKED with fix suggestions.
        AI agents should call this tool before any git commit.

        Args:
            diff: Git diff text (from git diff --cached) or raw code to review
        """
        try:
            from secret_scanner import scan_diff, scan_secrets, format_findings, generate_fix_patch

            # Try as diff first, fall back to raw code scan
            findings = scan_diff(diff)
            if not findings and not diff.startswith("diff --git"):
                findings = scan_secrets(diff)

            critical = [f for f in findings if f.severity == "CRITICAL"]

            if critical:
                report = format_findings(findings, block_mode=True)
                patch = generate_fix_patch(diff, findings)
                return json.dumps({
                    "status": "BLOCKED",
                    "critical": len(critical),
                    "total": len(findings),
                    "report": report,
                    "fix_patch": patch,
                    "action": "Apply the fix patch, then re-run security_gate."
                }, indent=2)

            high = [f for f in findings if f.severity == "HIGH"]
            if high:
                report = format_findings(findings, block_mode=False)
                return json.dumps({
                    "status": "WARNING",
                    "warnings": len(high),
                    "report": report,
                    "action": "Review warnings. Commit is allowed but consider fixing."
                }, indent=2)

            return json.dumps({
                "status": "APPROVED",
                "message": "No secrets detected. Safe to commit."
            }, indent=2)
        except Exception as e:
            return json.dumps({"status": "ERROR", "error": str(e)}, indent=2)

    @mcp.tool()
    def scan_secrets_in_file(file_path: str) -> str:
        """Scan a file for hardcoded secrets (API keys, tokens, passwords).

        Args:
            file_path: Absolute path to file to scan
        """
        try:
            resolved = _validate_path(file_path)
            with open(resolved, "r", errors="ignore") as f:
                code = f.read()

            from secret_scanner import scan_secrets, format_findings
            findings = scan_secrets(code, resolved)
            result = format_findings(findings, block_mode=False)
            return f"File: {resolved}\n\n{result}"
        except Exception as e:
            return f"Error: {e}"

    @mcp.tool()
    def scan_secrets_in_directory(dir_path: str) -> str:
        """Scan an entire directory tree for hardcoded secrets.

        Args:
            dir_path: Directory path to scan
        """
        try:
            resolved = _validate_path(dir_path)
            if not os.path.isdir(resolved):
                return f"Error: Not a directory: {resolved}"

            from secret_scanner import scan_secrets

            skip_dirs = {'.git', 'node_modules', '__pycache__', '.venv', 'venv', 'dist', 'build'}
            skip_ext = {'.pyc', '.whl', '.so', '.dll', '.png', '.jpg', '.gif', '.lock', '.zip'}

            all_findings = []
            files_scanned = 0

            for root, dirs, files in os.walk(resolved):
                dirs[:] = [d for d in dirs if d not in skip_dirs]
                for fname in files:
                    ext = os.path.splitext(fname)[1].lower()
                    if ext in skip_ext:
                        continue
                    fpath = os.path.join(root, fname)
                    try:
                        with open(fpath, "r", errors="ignore") as f:
                            code = f.read()
                        findings = scan_secrets(code, fpath)
                        files_scanned += 1
                        for finding in findings:
                            all_findings.append({
                                "file": os.path.relpath(fpath, resolved),
                                "line": finding.line,
                                "type": finding.secret_type,
                                "severity": finding.severity,
                                "match": finding.matched,
                                "fix": finding.fix,
                            })
                    except Exception:
                        continue

            critical = sum(1 for f in all_findings if f["severity"] == "CRITICAL")
            return json.dumps({
                "files_scanned": files_scanned,
                "total_findings": len(all_findings),
                "critical": critical,
                "high": len(all_findings) - critical,
                "findings": all_findings[:20],  # Cap output
            }, indent=2)
        except Exception as e:
            return json.dumps({"error": str(e)}, indent=2)

    # ═══════════════════════════════════════════════════
    # Existing tools (with input validation added)
    # ═══════════════════════════════════════════════════

    @mcp.tool()
    def smart_review(code: str, language: str = "python") -> str:
        """Code review — catches duplicates, long functions, deep nesting, naming issues, unused imports, debug statements.
        Args:
            code: Source code to review
            language: Programming language (python, javascript, typescript, go)
        """
        try:
            if not code or not code.strip():
                return "Error: No code provided."
            if language not in ("python", "javascript", "typescript", "go", "rust", "java", "ruby", "unknown"):
                language = "python"
            from tools_review import review_code
            return review_code(code, language)
        except Exception as e:
            return f"Review error: {e}"

    @mcp.tool()
    def review_file(file_path: str) -> str:
        """Review a file from disk — auto-detects language.
        Args:
            file_path: Absolute path to file
        """
        try:
            resolved = _validate_path(file_path)
            from tools_review import review_file as _rf
            return _rf(resolved)
        except Exception as e:
            return f"Error: {e}"

    @mcp.tool()
    def security_scan(code: str, language: str = "python") -> str:
        """OWASP Top 10 security scanner — SQL injection, XSS, command injection, SSRF, path traversal, weak crypto.
        Args:
            code: Source code to scan
            language: Programming language
        """
        try:
            if not code or not code.strip():
                return "Error: No code provided."
            from tools_security import scan_security
            return scan_security(code, language)
        except Exception as e:
            return f"Scan error: {e}"

    @mcp.tool()
    def deep_analyze(code: str, language: str = "python") -> str:
        """[BETA] AI-powered deep security analysis (BETA) — uses MiniMax 2.7 for taint tracing and behavioral analysis beyond regex.
        Args:
            code: Source code to analyze
            language: Programming language
        """
        try:
            if not code or not code.strip():
                return json.dumps({"status": "ERROR", "error": "No code provided."}, indent=2)
            from agent_analyzer import deep_analyze as _deep_analyze
            return json.dumps(_deep_analyze(code, language), indent=2)
        except Exception as e:
            return json.dumps({"status": "ERROR", "error": str(e)}, indent=2)

    @mcp.tool()
    def smart_analyze(code: str, language: str = "python", explain_requested: bool = False, record_learning: bool = False, title: str = "", source: str = "manual", expected_behavior: str = "") -> str:
        """Layered analysis: deterministic fast path first, MiniMax escalation only when justified.

        Args:
            code: Source code to analyze
            language: Programming language
            explain_requested: Force escalation when a human-readable deep explanation is needed
            record_learning: Save suspicious misses into the learning corpus
            title: Optional learning-corpus title when record_learning is enabled
            source: Optional learning-corpus source label
            expected_behavior: Optional note about what the detector should catch
        """
        try:
            if not code or not code.strip():
                return json.dumps({"status": "ERROR", "error": "No code provided."}, indent=2)
            from agent_analyzer import smart_analyze as _smart_analyze
            return json.dumps(
                _smart_analyze(code, language, explain_requested, record_learning, title, source, expected_behavior),
                indent=2,
            )
        except Exception as e:
            return json.dumps({"status": "ERROR", "error": str(e)}, indent=2)

    @mcp.tool()
    def analyze_setup_py(code: str) -> str:
        """[BETA] AI-powered setup.py malware analysis (BETA) — detects obfuscated payloads, credential theft, suspicious install hooks.
        Args:
            code: setup.py or pyproject.toml content
        """
        try:
            if not code or not code.strip():
                return json.dumps({"status": "ERROR", "error": "No code provided."}, indent=2)
            from agent_analyzer import analyze_setup_py as _analyze_setup_py
            return json.dumps(_analyze_setup_py(code), indent=2)
        except Exception as e:
            return json.dumps({"status": "ERROR", "error": str(e)}, indent=2)

    @mcp.tool()
    def explain_vulnerability(finding: str, code_context: str) -> str:
        """[BETA] AI-generated vulnerability explanation (BETA) — human-readable exploit scenarios for any finding.
        Args:
            finding: Finding text to explain
            code_context: Relevant code snippet around the finding
        """
        try:
            if not finding or not finding.strip():
                return "Error: No finding provided."
            if not code_context or not code_context.strip():
                return "Error: No code context provided."
            from agent_analyzer import explain_vulnerability as _explain_vulnerability
            return _explain_vulnerability(finding, code_context)
        except Exception as e:
            return f"Error: {e}"

    @mcp.tool()
    def security_scan_file(file_path: str) -> str:
        """Security scan a file from disk.
        Args:
            file_path: Absolute path to file
        """
        try:
            resolved = _validate_path(file_path)
            from tools_security import scan_file
            return scan_file(resolved)
        except Exception as e:
            return f"Error: {e}"

    @mcp.tool()
    def security_scan_directory(dir_path: str, extensions: str = ".py,.js,.ts") -> str:
        """Scan all files in a directory for security vulnerabilities.
        Args:
            dir_path: Directory path to scan
            extensions: Comma-separated file extensions
        """
        try:
            resolved = _validate_path(dir_path)
            from tools_security import scan_directory
            return scan_directory(resolved, extensions)
        except Exception as e:
            return f"Error: {e}"

    @mcp.tool()
    def audit_mcp_server(file_path: str) -> str:
        """Security audit an MCP server — checks input validation, error handling, path traversal, shell execution.
        Args:
            file_path: Path to MCP server file
        """
        try:
            resolved = _validate_path(file_path)
            from tools_security import audit_mcp_server as _audit
            return _audit(resolved)
        except Exception as e:
            return f"Error: {e}"

    # ═══════════════════════════════════════════════════
    # Supply Chain Scanner
    # ═══════════════════════════════════════════════════

    @mcp.tool()
    def scan_package(package_name: str, registry: str = "pypi") -> str:
        """Scan a package BEFORE install — checks age, typosquatting, missing repo, suspicious author, and known compromised packages database.

        Returns SAFE / WARNING / BLOCKED with reasons.

        Args:
            package_name: Name of the package to check
            registry: "pypi" or "npm"
        """
        try:
            from supply_chain import scan_pip_package, scan_npm_package
            if registry == "npm":
                result = scan_npm_package(package_name)
            else:
                result = scan_pip_package(package_name)
            return json.dumps(result, indent=2)
        except Exception as e:
            return json.dumps({"status": "ERROR", "error": str(e)}, indent=2)

    @mcp.tool()
    def scan_requirements_file(file_path: str) -> str:
        """Scan a requirements.txt for supply chain risks — checks every package against PyPI.

        Args:
            file_path: Absolute path to requirements.txt
        """
        try:
            resolved = _validate_path(file_path)
            from supply_chain import scan_requirements
            result = scan_requirements(resolved)
            return json.dumps(result, indent=2)
        except Exception as e:
            return json.dumps({"status": "ERROR", "error": str(e)}, indent=2)

    @mcp.tool()
    def scan_pth_files(site_packages_path: str) -> str:
        """Scan for malicious .pth files in site-packages (TeamPCP attack vector).

        .pth files execute arbitrary Python at interpreter startup. This tool
        detects suspicious .pth files that may have been injected by compromised
        packages.

        Args:
            site_packages_path: Absolute path to a site-packages directory
        """
        try:
            resolved = _validate_path(site_packages_path)
            if not os.path.isdir(resolved):
                return json.dumps({"status": "ERROR", "error": f"Not a directory: {resolved}"}, indent=2)
            from supply_chain import scan_pth_files as _scan_pth
            result = _scan_pth(resolved)
            return json.dumps(result, indent=2)
        except Exception as e:
            return json.dumps({"status": "ERROR", "error": str(e)}, indent=2)

    @mcp.tool()
    def scan_requirements_unpinned(file_path: str) -> str:
        """Detect unpinned or loosely pinned dependencies in a requirements file.

        Flags packages using >=, ~=, or no version pin at all, which can lead
        to supply chain attacks via malicious new releases.

        Args:
            file_path: Absolute path to requirements.txt or similar file
        """
        try:
            resolved = _validate_path(file_path)
            from supply_chain import scan_requirements_unpinned as _scan_unpinned
            result = _scan_unpinned(resolved)
            return json.dumps(result, indent=2)
        except Exception as e:
            return json.dumps({"status": "ERROR", "error": str(e)}, indent=2)

    @mcp.tool()
    def scan_github_actions(workflow_dir: str) -> str:
        """Audit GitHub Actions workflows for mutable tag references.

        Detects uses of unpinned actions (e.g. actions/checkout@v3 instead of
        a full SHA), which can be hijacked via tag mutation attacks.

        Args:
            workflow_dir: Absolute path to .github/workflows directory
        """
        try:
            resolved = _validate_path(workflow_dir)
            if not os.path.isdir(resolved):
                return json.dumps({"status": "ERROR", "error": f"Not a directory: {resolved}"}, indent=2)
            from supply_chain import scan_github_actions as _scan_actions
            result = _scan_actions(resolved)
            return json.dumps(result, indent=2)
        except Exception as e:
            return json.dumps({"status": "ERROR", "error": str(e)}, indent=2)

    @mcp.tool()
    def query_osv(package_name: str, version: str, ecosystem: str = "PyPI") -> str:
        """Query OSV.dev for known vulnerabilities in a specific package version.

        OSV.dev is a free, no-auth vulnerability database aggregating CVEs from
        NVD, GitHub Advisories, PyPI, npm, and more. Returns vuln count, CVE IDs,
        severity breakdown, and details for each vulnerability found.

        Args:
            package_name: Package name (e.g. "requests", "lodash")
            version: Exact version to check (e.g. "2.31.0")
            ecosystem: Package ecosystem — "PyPI", "npm", "Go", "crates.io", etc.
        """
        try:
            from supply_chain import query_osv as _query_osv
            result = _query_osv(package_name, version, ecosystem)
            return json.dumps(result, indent=2)
        except Exception as e:
            return json.dumps({"status": "ERROR", "error": str(e)}, indent=2)

    @mcp.tool()
    def query_osv_batch(packages: str) -> str:
        """Batch query OSV.dev for vulnerabilities across multiple packages.

        Accepts a JSON array of package objects, each with "name", "version",
        and optional "ecosystem" (defaults to "PyPI"). Returns aggregated results.

        Args:
            packages: JSON array string, e.g. '[{"name":"requests","version":"2.31.0","ecosystem":"PyPI"}]'
        """
        try:
            from supply_chain import query_osv_batch as _query_osv_batch
            pkg_list = json.loads(packages)
            if not isinstance(pkg_list, list):
                return json.dumps({"status": "ERROR", "error": "packages must be a JSON array"}, indent=2)
            result = _query_osv_batch(pkg_list)
            return json.dumps(result, indent=2)
        except json.JSONDecodeError as e:
            return json.dumps({"status": "ERROR", "error": f"Invalid JSON: {e}"}, indent=2)
        except Exception as e:
            return json.dumps({"status": "ERROR", "error": str(e)}, indent=2)

    @mcp.tool()
    def full_audit(file_path: str) -> str:
        """Combined secrets scan + code review + security scan.
        Args:
            file_path: Path to file to audit
        """
        try:
            resolved = _validate_path(file_path)

            results = []

            # Secrets scan (NEW)
            with open(resolved, "r", errors="ignore") as f:
                code = f.read()
            from secret_scanner import scan_secrets, format_findings
            secret_findings = scan_secrets(code, resolved)
            results.append("=== SECRETS SCAN ===")
            results.append(format_findings(secret_findings, block_mode=False))

            # Code review
            from tools_review import review_file as _rf
            results.append("\n=== CODE REVIEW ===")
            results.append(_rf(resolved))

            # Security scan
            from tools_security import scan_file as _sf
            results.append("\n=== SECURITY SCAN ===")
            results.append(_sf(resolved))

            return "\n".join(results)
        except Exception as e:
            return f"Error: {e}"

    @mcp.tool()
    def record_learning_candidate(title: str, code: str, language: str = "python", source: str = "manual", expected_behavior: str = "") -> str:
        """Store a new suspicious sample for review without changing rules automatically.

        Args:
            title: Short label for the sample
            code: Suspicious code sample
            language: Source language
            source: Where the sample came from (manual, production, redteam, customer)
            expected_behavior: What CodeGuard should eventually detect or explain
        """
        try:
            from agent_analyzer import deep_analyze as _deep
            from learning_loop import record_candidate
            ai_result = _deep(code, language)
            result = record_candidate(
                title=title,
                code=code,
                language=language,
                source=source,
                expected_behavior=expected_behavior,
                regex_findings=[f for f in ai_result.get("findings", []) if f.get("source") == "[REGEX]"],
                ai_findings=[f for f in ai_result.get("findings", []) if f.get("source") == "[AI-BETA]"],
            )
            return json.dumps(result, indent=2)
        except Exception as e:
            return json.dumps({"status": "ERROR", "error": str(e)}, indent=2)

    @mcp.tool()
    def generate_learning_issue(candidate_path: str) -> str:
        """Generate a GitHub-issue-ready markdown report from a stored learning sample.

        Args:
            candidate_path: Absolute path to a learning candidate JSON file
        """
        try:
            resolved = _validate_path(candidate_path)
            from learning_loop import generate_issue_markdown
            result = generate_issue_markdown(resolved)
            return json.dumps(result, indent=2)
        except Exception as e:
            return json.dumps({"status": "ERROR", "error": str(e)}, indent=2)

    @mcp.tool()
    def learning_summary(corpus_dir: str) -> str:
        """Summarize the local learning corpus and issue queue.

        Args:
            corpus_dir: Absolute or relative path to the learning directory
        """
        try:
            from learning_loop import corpus_summary
            result = corpus_summary(corpus_dir)
            return json.dumps(result, indent=2)
        except Exception as e:
            return json.dumps({"status": "ERROR", "error": str(e)}, indent=2)

    @mcp.tool()
    def threat_feed_verify(feed_dir: str, key_file: str = "") -> str:
        """Verify a local signed threat feed."""
        try:
            from threat_feed import verify_feed
            result = verify_feed(feed_dir, key_file=key_file)
            return json.dumps(result, indent=2)
        except Exception as e:
            return json.dumps({"status": "ERROR", "error": str(e)}, indent=2)

    @mcp.tool()
    def threat_feed_refresh(base_url: str = "", out_dir: str = "", key_file: str = "") -> str:
        """Refresh a configured remote threat feed and verify it."""
        try:
            from threat_feed import maybe_refresh_feed
            result = maybe_refresh_feed(base_url=base_url, out_dir=out_dir, key_file=key_file)
            return json.dumps(result, indent=2)
        except Exception as e:
            return json.dumps({"status": "ERROR", "error": str(e)}, indent=2)

    @mcp.tool()
    def generate_advisory(title: str, summary: str, severity: str = "HIGH", packages: str = "[]", iocs: str = "[]", actions: str = "[]") -> str:
        """Generate issue/customer-ready advisory markdown."""
        try:
            from threat_feed import generate_advisory as _generate
            result = _generate(
                title=title,
                summary=summary,
                severity=severity,
                packages=json.loads(packages),
                iocs=json.loads(iocs),
                actions=json.loads(actions),
            )
            return result["markdown"]
        except Exception as e:
            return f"Error: {e}"

    @mcp.tool()
    def build_telemetry_event(event_type: str, package: str = "", version: str = "", sample: str = "", source: str = "manual", include_sample: bool = False) -> str:
        """Build an opt-in telemetry event payload."""
        try:
            from telemetry import build_telemetry_event as _build
            result = _build(event_type, package=package, version=version, sample=sample, source=source, include_sample=include_sample)
            return json.dumps(result, indent=2)
        except Exception as e:
            return json.dumps({"status": "ERROR", "error": str(e)}, indent=2)

    return mcp


def main():
    """Run the packaged MCP server entrypoint."""
    parser = argparse.ArgumentParser(
        prog="codeguard-mcp",
        description="CodeGuard Pro MCP server. Run this from an MCP client such as Claude Code, Codex, Cursor, or a VS Code MCP extension.",
    )
    parser.add_argument(
        "--stdio",
        action="store_true",
        help="Run the MCP server over stdio. This is the default mode used by MCP clients.",
    )
    args = parser.parse_args()

    if sys.stdin.isatty() and not args.stdio:
        print(
            "CodeGuard Pro MCP server\n\n"
            "This command is meant to be launched by an MCP client over stdio.\n"
            "Use `codeguard mcp-config` to print a client config snippet.\n"
            "Use `codeguard-mcp --stdio` to run the server explicitly.\n",
            file=sys.stderr,
        )
        return

    refresh_result = None
    if os.environ.get("CODEGUARD_FEED_URL") and os.environ.get("CODEGUARD_FEED_DIR"):
        try:
            from threat_feed import maybe_refresh_feed
            refresh_result = maybe_refresh_feed()
        except Exception as e:
            refresh_result = {"status": "ERROR", "error": str(e)}
        if refresh_result and sys.stdin.isatty():
            print(f"Feed refresh: {json.dumps(refresh_result)}", file=sys.stderr)

    mcp = create_server()
    mcp.run()


if __name__ == "__main__":
    main()
