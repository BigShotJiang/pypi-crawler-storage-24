#!/usr/bin/env python3
"""CodeGuard Pro CLI — Install, scan, and protect your code.

Usage:
    codeguard init [--policy]  Initialize CodeGuard in current repo
    codeguard install          Install pre-commit hook in current repo
    codeguard scan <path>      Scan a file or directory for secrets
    codeguard scan-diff        Scan staged git diff for secrets
    codeguard demo             Run a local product demo
    codeguard redteam-demo     Run mocked install-time attack benchmark
    codeguard feed-init        Create a starter threat feed directory
    codeguard feed-build       Sign a local threat feed
    codeguard feed-verify      Verify a local threat feed
    codeguard feed-fetch       Download and verify a remote threat feed
    codeguard feed-refresh     Refresh a configured remote threat feed
    codeguard advisory         Generate incident advisory markdown
    codeguard telemetry-event  Build a telemetry event JSON
    codeguard telemetry-send   Send a telemetry event JSON file
    codeguard mcp-config       Print MCP config snippet for CodeGuard
    codeguard learn-add        Save a suspicious sample for later review
    codeguard learn-report     Generate an issue-ready markdown report
    codeguard learn-summary    Summarize the local learning corpus
    codeguard uninstall        Remove pre-commit hook
"""

import os
import sys
import stat
import json
import shutil
import subprocess
import argparse

CODEGUARD_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, CODEGUARD_DIR)

HOOK_SCRIPT = f'''#!/usr/bin/env python3
"""CodeGuard Pro pre-commit hook — auto-installed."""
import sys
sys.path.insert(0, "{CODEGUARD_DIR}")
from hook import main
main()
'''

RED = "\033[91m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
BOLD = "\033[1m"
RESET = "\033[0m"


def find_git_root() -> str:
    """Find the .git directory from current working directory."""
    cwd = os.getcwd()
    while cwd != "/":
        if os.path.isdir(os.path.join(cwd, ".git")):
            return cwd
        cwd = os.path.dirname(cwd)
    return ""


def _auto_refresh_feed_if_configured(command_name: str) -> None:
    """Refresh the threat feed automatically when configured."""
    if command_name in {"feed-init", "feed-build", "feed-verify", "feed-fetch", "feed-refresh"}:
        return
    if not (os.environ.get("CODEGUARD_FEED_URL") and os.environ.get("CODEGUARD_FEED_DIR")):
        return
    try:
        from threat_feed import maybe_refresh_feed
        result = maybe_refresh_feed()
        if os.environ.get("CODEGUARD_FEED_VERBOSE", "").lower() in {"1", "true", "yes"}:
            print(f"{YELLOW}Feed refresh: {json.dumps(result)}{RESET}", file=sys.stderr)
    except Exception as e:
        if os.environ.get("CODEGUARD_FEED_VERBOSE", "").lower() in {"1", "true", "yes"}:
            print(f"{YELLOW}Feed refresh error: {e}{RESET}", file=sys.stderr)


def cmd_install():
    """Install the pre-commit hook."""
    git_root = find_git_root()
    if not git_root:
        print(f"{RED}Error: Not a git repository.{RESET}")
        sys.exit(1)

    hooks_dir = os.path.join(git_root, ".git", "hooks")
    os.makedirs(hooks_dir, exist_ok=True)

    hook_path = os.path.join(hooks_dir, "pre-commit")

    # Back up existing hook
    if os.path.exists(hook_path):
        backup = hook_path + ".backup"
        shutil.copy2(hook_path, backup)
        print(f"{YELLOW}Existing hook backed up to {backup}{RESET}")

    with open(hook_path, "w") as f:
        f.write(HOOK_SCRIPT)

    os.chmod(hook_path, os.stat(hook_path).st_mode | stat.S_IEXEC)

    print(f"{GREEN}{BOLD}CodeGuard Pro installed.{RESET}")
    print(f"Hook: {hook_path}")
    print(f"Every commit will be scanned for secrets automatically.")


def cmd_uninstall():
    """Remove the pre-commit hook."""
    git_root = find_git_root()
    if not git_root:
        print(f"{RED}Error: Not a git repository.{RESET}")
        sys.exit(1)

    hook_path = os.path.join(git_root, ".git", "hooks", "pre-commit")
    backup = hook_path + ".backup"

    if os.path.exists(hook_path):
        os.remove(hook_path)
        print(f"{GREEN}CodeGuard Pro hook removed.{RESET}")

        if os.path.exists(backup):
            shutil.move(backup, hook_path)
            print(f"Restored previous hook from backup.")
    else:
        print("No hook found.")


def cmd_scan(path: str):
    """Scan a file or directory for secrets."""
    from secret_scanner import scan_secrets, format_findings

    if os.path.isfile(path):
        with open(path, "r", errors="ignore") as f:
            code = f.read()
        findings = scan_secrets(code, path)
        print(f"{BOLD}Scan: {path}{RESET}\n")
        print(format_findings(findings, block_mode=False))
        if findings:
            sys.exit(1)
    elif os.path.isdir(path):
        total_findings = []
        files_scanned = 0
        skip_dirs = {'.git', 'node_modules', '__pycache__', '.venv', 'venv', 'dist', 'build', '.next'}
        skip_ext = {'.pyc', '.whl', '.so', '.dll', '.png', '.jpg', '.gif', '.ico', '.svg',
                    '.woff', '.ttf', '.mp3', '.mp4', '.zip', '.tar', '.gz', '.lock'}

        for root, dirs, files in os.walk(path):
            dirs[:] = [d for d in dirs if d not in skip_dirs]
            for fname in files:
                ext = os.path.splitext(fname)[1].lower()
                if ext in skip_ext:
                    continue
                fpath = os.path.join(root, fname)
                try:
                    with open(fpath, "r", errors="ignore") as f:
                        code = f.read()
                    findings = scan_secrets(code, fpath)
                    files_scanned += 1
                    for finding in findings:
                        total_findings.append((fpath, finding))
                except Exception:
                    continue

        print(f"{BOLD}Directory Scan: {path}{RESET}")
        print(f"Files scanned: {files_scanned}\n")

        if not total_findings:
            print(f"{GREEN}PASS — No secrets detected.{RESET}")
        else:
            critical = sum(1 for _, f in total_findings if f.severity == "CRITICAL")
            high = sum(1 for _, f in total_findings if f.severity == "HIGH")
            print(f"{RED}FOUND {len(total_findings)} secret(s){RESET}")
            print(f"  CRITICAL: {critical}")
            print(f"  HIGH:     {high}\n")

            for fpath, f in total_findings:
                rel = os.path.relpath(fpath, path)
                print(f"  [{f.severity}] {f.secret_type} in {rel}:{f.line}")
                print(f"    {f.matched}")
                print(f"    Fix: {f.fix}\n")

            sys.exit(1)
    else:
        print(f"{RED}Error: {path} not found.{RESET}")
        sys.exit(1)


POLICIES = {
    "minimal": {
        "block_on_critical": True,
        "block_on_high": False,
        "scan_secrets": True,
        "scan_owasp": False,
        "scan_packages": False,
        "autofix": False,
        "autofix_model": None,
    },
    "standard": {
        "block_on_critical": True,
        "block_on_high": False,
        "scan_secrets": True,
        "scan_owasp": True,
        "scan_packages": False,
        "autofix": False,
        "autofix_model": None,
    },
    "full": {
        "block_on_critical": True,
        "block_on_high": False,
        "scan_secrets": True,
        "scan_owasp": True,
        "scan_packages": True,
        "autofix": True,
        "autofix_model": "MiniMax-M2.7",
    },
}

SECRET_FILE_PATTERNS = [
    ".env",
    ".env.local",
    ".env.production",
    ".env.staging",
    "*.pem",
    "*.key",
    "*.p12",
    "*.pfx",
    "*.jks",
]


def _ensure_gitignore_patterns(git_root: str) -> list:
    """Add common secret file patterns to .gitignore if missing. Returns list of added patterns."""
    gitignore_path = os.path.join(git_root, ".gitignore")
    existing_lines = set()

    if os.path.exists(gitignore_path):
        with open(gitignore_path, "r") as f:
            existing_lines = {line.strip() for line in f.readlines()}

    added = []
    lines_to_add = []
    for pattern in SECRET_FILE_PATTERNS:
        if pattern not in existing_lines:
            lines_to_add.append(pattern)
            added.append(pattern)

    if lines_to_add:
        with open(gitignore_path, "a") as f:
            if existing_lines and "" not in existing_lines:
                f.write("\n")
            f.write("# CodeGuard Pro — secret file patterns\n")
            for line in lines_to_add:
                f.write(f"{line}\n")

    return added


def cmd_init(policy: str = "standard"):
    """Initialize CodeGuard Pro in current repo: hook + config + gitignore."""
    git_root = find_git_root()
    if not git_root:
        print(f"{RED}Error: Not a git repository. Run 'git init' first.{RESET}")
        sys.exit(1)

    print(f"{BOLD}CodeGuard Pro — Initializing ({policy} policy){RESET}\n")

    steps_done = []

    # 1. Install pre-commit hook (reuse existing logic)
    cmd_install()
    steps_done.append("Pre-commit hook installed")

    # 2. Create .codeguard.json config
    config = dict(POLICIES[policy])
    config_path = os.path.join(git_root, ".codeguard.json")

    if os.path.exists(config_path):
        print(f"{YELLOW}  .codeguard.json already exists — overwriting with {policy} policy{RESET}")

    with open(config_path, "w") as f:
        json.dump(config, f, indent=2)
        f.write("\n")
    steps_done.append(f".codeguard.json created ({policy} policy)")

    # 3. Git-track .codeguard.json
    try:
        subprocess.run(
            ["git", "add", ".codeguard.json"],
            capture_output=True, text=True, timeout=10, cwd=git_root,
        )
        steps_done.append(".codeguard.json added to git tracking")
    except Exception:
        print(f"{YELLOW}  Warning: Could not git add .codeguard.json{RESET}")

    # 4. Add secret file patterns to .gitignore
    added_patterns = _ensure_gitignore_patterns(git_root)
    if added_patterns:
        steps_done.append(f".gitignore updated (+{len(added_patterns)} patterns)")
        # Also stage .gitignore
        try:
            subprocess.run(
                ["git", "add", ".gitignore"],
                capture_output=True, text=True, timeout=10, cwd=git_root,
            )
        except Exception:
            pass
    else:
        steps_done.append(".gitignore already has secret patterns")

    # 5. Print summary
    print(f"\n{GREEN}{BOLD}Setup complete!{RESET}\n")
    for step in steps_done:
        print(f"  {GREEN}+{RESET} {step}")

    print(f"\n{BOLD}Policy: {policy}{RESET}")
    print(f"  Secrets scanning:  {'ON' if config.get('scan_secrets') else 'OFF'}")
    print(f"  OWASP scanning:    {'ON' if config.get('scan_owasp') else 'OFF'}")
    print(f"  Package scanning:  {'ON' if config.get('scan_packages') else 'OFF'}")
    print(f"  Auto-fix:          {'ON' if config.get('autofix') else 'OFF'}")
    if config.get('autofix_model'):
        print(f"  Auto-fix model:    {config['autofix_model']}")
    print(f"  Block on CRITICAL: {'YES' if config.get('block_on_critical') else 'NO'}")
    print(f"  Block on HIGH:     {'YES' if config.get('block_on_high') else 'NO'}")
    print(f"\n{BOLD}Next steps{RESET}")
    print(f"  1. Run {BOLD}codeguard scan .{RESET} to scan your project now.")
    print(f"  2. Run {BOLD}codeguard check <package>{RESET} before installing new dependencies.")
    print(f"  3. Run {BOLD}codeguard mcp-config{RESET} to connect Claude/Codex/Cursor/VS Code MCP clients.")
    print(f"  4. Run {BOLD}codeguard demo{RESET} to see the layered scanner output.")


def cmd_check(packages: list, registry: str = "pypi"):
    """Scan packages BEFORE installing — catches typosquats + suspicious packages."""
    from supply_chain import parse_package_spec, scan_pip_package, scan_npm_package

    scanner = scan_pip_package if registry == "pypi" else scan_npm_package
    blocked = []
    warnings = []

    print(f"{BOLD}CodeGuard Pre-Install Check ({registry}){RESET}\n")

    for pkg in packages:
        parsed = parse_package_spec(pkg)
        pkg_name = parsed["name"]
        if not pkg_name:
            continue
        requested_version = parsed["version"] if parsed["operator"] == "==" and registry == "pypi" else ""
        result = scanner(pkg_name, requested_version=requested_version) if registry == "pypi" else scanner(pkg_name)
        verdict = result.get("verdict", "ERROR")
        reasons = result.get("reasons", [])
        display_name = parsed["raw"].strip() or pkg_name

        if verdict == "BLOCKED":
            print(f"  {RED}BLOCKED{RESET}  {display_name}")
            for r in reasons:
                print(f"           {r}")
            blocked.append(display_name)
        elif verdict == "WARNING":
            print(f"  {YELLOW}WARNING{RESET}  {display_name}")
            for r in reasons:
                print(f"           {r}")
            warnings.append(display_name)
        elif verdict == "SAFE":
            print(f"  {GREEN}SAFE{RESET}     {display_name}")
        else:
            print(f"  {YELLOW}?{RESET}        {display_name} ({verdict})")

    print()
    if blocked:
        print(f"{RED}{BOLD}BLOCKED: {len(blocked)} package(s) look dangerous.{RESET}")
        print(f"  {', '.join(blocked)}")
        print(f"\n  DO NOT install these. They may be typosquats or malicious.")
        sys.exit(1)
    elif warnings:
        print(f"{YELLOW}WARNING: {len(warnings)} package(s) flagged.{RESET}")
        print(f"  Proceed with caution.")
    else:
        print(f"{GREEN}All {len(packages)} package(s) look safe to install.{RESET}")


def cmd_scan_diff():
    """Scan staged diff for secrets."""
    from hook import get_staged_diff
    from secret_scanner import scan_diff, format_findings

    diff = get_staged_diff()
    if not diff:
        print("No staged changes found.")
        return

    findings = scan_diff(diff)
    print(f"{BOLD}Staged Diff Scan{RESET}\n")
    print(format_findings(findings, block_mode=False))


def cmd_learn_add(sample_path: str, title: str, language: str = "python", source: str = "manual", expected_behavior: str = ""):
    """Store a suspicious sample in the review corpus."""
    from agent_analyzer import deep_analyze
    from learning_loop import record_candidate

    if not os.path.isfile(sample_path):
        print(f"{RED}Error: {sample_path} not found.{RESET}")
        sys.exit(1)

    with open(sample_path, "r", errors="ignore") as f:
        code = f.read()

    ai_result = deep_analyze(code, language)
    result = record_candidate(
        title=title,
        code=code,
        language=language,
        source=source,
        expected_behavior=expected_behavior,
        regex_findings=[f for f in ai_result.get("findings", []) if f.get("source") == "[REGEX]"],
        ai_findings=[f for f in ai_result.get("findings", []) if f.get("source") == "[AI-BETA]"],
    )
    print(json.dumps(result, indent=2))


def cmd_learn_report(candidate_path: str):
    """Generate issue-ready markdown for a stored learning sample."""
    from learning_loop import generate_issue_markdown

    if not os.path.isfile(candidate_path):
        print(f"{RED}Error: {candidate_path} not found.{RESET}")
        sys.exit(1)
    print(json.dumps(generate_issue_markdown(candidate_path), indent=2))


def cmd_learn_summary(corpus_dir: str = "learning"):
    """Summarize the local learning corpus."""
    from learning_loop import corpus_summary
    print(json.dumps(corpus_summary(corpus_dir), indent=2))


def cmd_demo():
    """Run a concise local demo of CodeGuard's core flows."""
    from demo import main as run_demo
    run_demo()


def cmd_redteam_demo():
    """Run the mocked red-team install-time corpus."""
    from demo import redteam_demo as run_redteam_demo
    run_redteam_demo()


def cmd_feed_init(feed_dir: str):
    from threat_feed import init_feed
    print(json.dumps(init_feed(feed_dir), indent=2))


def cmd_feed_build(feed_dir: str, key_file: str, expires_in_hours: int):
    from threat_feed import build_feed
    print(json.dumps(build_feed(feed_dir, key_file=key_file, expires_in_hours=expires_in_hours), indent=2))


def cmd_feed_verify(feed_dir: str, key_file: str):
    from threat_feed import verify_feed
    print(json.dumps(verify_feed(feed_dir, key_file=key_file), indent=2))


def cmd_feed_fetch(base_url: str, out_dir: str, key_file: str):
    from threat_feed import fetch_feed
    print(json.dumps(fetch_feed(base_url, out_dir, key_file=key_file), indent=2))


def cmd_feed_refresh(base_url: str, out_dir: str, key_file: str):
    from threat_feed import maybe_refresh_feed
    print(json.dumps(maybe_refresh_feed(base_url=base_url, out_dir=out_dir, key_file=key_file), indent=2))


def cmd_advisory(title: str, summary: str, severity: str, packages: list, iocs: list, actions: list):
    from threat_feed import generate_advisory
    result = generate_advisory(title, summary, severity=severity, packages=packages, iocs=iocs, actions=actions)
    print(result["markdown"])


def cmd_telemetry_event(event_type: str, package: str, version: str, sample_path: str, source: str, include_sample: bool):
    from telemetry import build_telemetry_event
    sample = ""
    if sample_path:
        with open(sample_path, "r", errors="ignore") as f:
            sample = f.read()
    event = build_telemetry_event(
        event_type=event_type,
        package=package,
        version=version,
        sample=sample,
        source=source,
        include_sample=include_sample,
    )
    print(json.dumps(event, indent=2))


def cmd_telemetry_send(event_path: str, endpoint: str, api_key: str):
    from telemetry import send_telemetry
    with open(event_path, "r", encoding="utf-8") as f:
        event = json.load(f)
    print(json.dumps(send_telemetry(event, endpoint=endpoint, api_key=api_key), indent=2))


def cmd_mcp_config(server_command: str = "codeguard-mcp", client: str = "generic"):
    """Print a minimal MCP config snippet for popular clients."""
    config = {
        "mcpServers": {
            "codeguard": {
                "command": server_command,
                "args": [],
            }
        }
    }

    notes = {
        "generic": "Use this JSON in any MCP client that accepts a command-based server definition.",
        "claude": "Add this server entry to your Claude Code MCP configuration.",
        "cursor": "Add this server entry in Cursor's MCP settings or config file.",
        "vscode": "Use this command in any VS Code MCP extension or MCP client configuration.",
        "codex": "Use this command in any Codex-compatible MCP client configuration.",
    }

    print(json.dumps({
        "client": client,
        "note": notes.get(client, notes["generic"]),
        "config": config,
    }, indent=2))


def main():
    parser = argparse.ArgumentParser(
        prog="codeguard",
        description="CodeGuard Pro — Stop secrets from reaching git."
    )
    sub = parser.add_subparsers(dest="command")

    init_p = sub.add_parser("init", help="Initialize CodeGuard in repo")
    init_p.add_argument(
        "--policy", choices=["minimal", "standard", "full"],
        default="standard",
        help="Security policy level (default: standard)"
    )

    sub.add_parser("install", help="Install pre-commit hook")
    sub.add_parser("uninstall", help="Remove pre-commit hook")

    scan_p = sub.add_parser("scan", help="Scan file or directory")
    scan_p.add_argument("path", help="File or directory to scan")

    sub.add_parser("scan-diff", help="Scan staged git diff")
    sub.add_parser("demo", help="Run a local demo")
    sub.add_parser("redteam-demo", help="Run mocked install-time attack benchmark")

    feed_init_p = sub.add_parser("feed-init", help="Create a starter threat feed directory")
    feed_init_p.add_argument("feed_dir", help="Directory to initialize")

    feed_build_p = sub.add_parser("feed-build", help="Sign a local threat feed")
    feed_build_p.add_argument("feed_dir", help="Feed directory")
    feed_build_p.add_argument("--key-file", default="", help="Path to signing secret file")
    feed_build_p.add_argument("--expires-hours", type=int, default=24, help="Manifest expiry window")

    feed_verify_p = sub.add_parser("feed-verify", help="Verify a local threat feed")
    feed_verify_p.add_argument("feed_dir", help="Feed directory")
    feed_verify_p.add_argument("--key-file", default="", help="Path to signing secret file")

    feed_fetch_p = sub.add_parser("feed-fetch", help="Download and verify a remote threat feed")
    feed_fetch_p.add_argument("base_url", help="Base URL hosting feed files")
    feed_fetch_p.add_argument("out_dir", help="Local directory to store the feed")
    feed_fetch_p.add_argument("--key-file", default="", help="Path to signing secret file")

    feed_refresh_p = sub.add_parser("feed-refresh", help="Refresh feed from env or explicit args")
    feed_refresh_p.add_argument("--base-url", default="", help="Feed base URL")
    feed_refresh_p.add_argument("--out-dir", default="", help="Feed directory")
    feed_refresh_p.add_argument("--key-file", default="", help="Path to signing secret file")

    advisory_p = sub.add_parser("advisory", help="Generate incident advisory markdown")
    advisory_p.add_argument("--title", required=True, help="Advisory title")
    advisory_p.add_argument("--summary", required=True, help="Short summary")
    advisory_p.add_argument("--severity", default="HIGH", help="Severity label")
    advisory_p.add_argument("--package", action="append", dest="packages", default=[], help="Affected package")
    advisory_p.add_argument("--ioc", action="append", dest="iocs", default=[], help="Indicator of compromise")
    advisory_p.add_argument("--action", action="append", dest="actions", default=[], help="Recommended action")

    telemetry_event_p = sub.add_parser("telemetry-event", help="Build telemetry event JSON")
    telemetry_event_p.add_argument("--event-type", required=True, help="Event type label")
    telemetry_event_p.add_argument("--package", default="", help="Affected package")
    telemetry_event_p.add_argument("--version", default="", help="Affected version")
    telemetry_event_p.add_argument("--sample-path", default="", help="Optional sample file path")
    telemetry_event_p.add_argument("--source", default="manual", help="Event source label")
    telemetry_event_p.add_argument("--include-sample", action="store_true", help="Include redacted sample preview")

    telemetry_send_p = sub.add_parser("telemetry-send", help="Send a telemetry event JSON file")
    telemetry_send_p.add_argument("event_path", help="Path to telemetry JSON")
    telemetry_send_p.add_argument("--endpoint", default="", help="Telemetry endpoint")
    telemetry_send_p.add_argument("--api-key", default="", help="Telemetry API key")

    mcp_p = sub.add_parser("mcp-config", help="Print MCP config snippet")
    mcp_p.add_argument("--client", choices=["generic", "claude", "cursor", "vscode", "codex"], default="generic")
    mcp_p.add_argument("--server-command", default="codeguard-mcp", help="Server command to run in the MCP client")

    check_p = sub.add_parser("check", help="Scan packages BEFORE installing")
    check_p.add_argument("packages", nargs="+", help="Package names to check")
    check_p.add_argument("--npm", action="store_true", help="Check npm instead of pip")

    learn_add_p = sub.add_parser("learn-add", help="Add suspicious sample to learning corpus")
    learn_add_p.add_argument("sample_path", help="Path to the suspicious sample file")
    learn_add_p.add_argument("--title", required=True, help="Short title for the sample")
    learn_add_p.add_argument("--language", default="python", help="Source language")
    learn_add_p.add_argument("--source", default="manual", help="Where the sample came from")
    learn_add_p.add_argument("--expected", default="", help="Expected detector behavior")

    learn_report_p = sub.add_parser("learn-report", help="Generate issue-ready markdown from a candidate")
    learn_report_p.add_argument("candidate_path", help="Path to learning candidate JSON")

    learn_summary_p = sub.add_parser("learn-summary", help="Summarize the learning corpus")
    learn_summary_p.add_argument("--corpus-dir", default="learning", help="Learning corpus directory")

    args = parser.parse_args()
    _auto_refresh_feed_if_configured(args.command or "")

    if args.command == "init":
        cmd_init(args.policy)
    elif args.command == "install":
        cmd_install()
    elif args.command == "uninstall":
        cmd_uninstall()
    elif args.command == "scan":
        cmd_scan(args.path)
    elif args.command == "scan-diff":
        cmd_scan_diff()
    elif args.command == "demo":
        cmd_demo()
    elif args.command == "redteam-demo":
        cmd_redteam_demo()
    elif args.command == "feed-init":
        cmd_feed_init(args.feed_dir)
    elif args.command == "feed-build":
        cmd_feed_build(args.feed_dir, args.key_file, args.expires_hours)
    elif args.command == "feed-verify":
        cmd_feed_verify(args.feed_dir, args.key_file)
    elif args.command == "feed-fetch":
        cmd_feed_fetch(args.base_url, args.out_dir, args.key_file)
    elif args.command == "feed-refresh":
        cmd_feed_refresh(args.base_url, args.out_dir, args.key_file)
    elif args.command == "advisory":
        cmd_advisory(args.title, args.summary, args.severity, args.packages, args.iocs, args.actions)
    elif args.command == "telemetry-event":
        cmd_telemetry_event(args.event_type, args.package, args.version, args.sample_path, args.source, args.include_sample)
    elif args.command == "telemetry-send":
        cmd_telemetry_send(args.event_path, args.endpoint, args.api_key)
    elif args.command == "mcp-config":
        cmd_mcp_config(args.server_command, args.client)
    elif args.command == "check":
        cmd_check(args.packages, registry="npm" if args.npm else "pypi")
    elif args.command == "learn-add":
        cmd_learn_add(args.sample_path, args.title, args.language, args.source, args.expected)
    elif args.command == "learn-report":
        cmd_learn_report(args.candidate_path)
    elif args.command == "learn-summary":
        cmd_learn_summary(args.corpus_dir)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
