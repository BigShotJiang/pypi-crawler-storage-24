"""
Date: create on 09/11/2025
Checkpoint: edit on 15/02/2026
Author: Yang Zhou, zyaztec@gmail.com
Reference:
- [1] Hosmer D W, Lemeshow S, Sturdivant R X. Applied Logistic Regression.

Logistic Regression (LR) is a classic linear baseline for CTR/ranking tasks.
It maps each feature (dense, sparse, or sequence) into a numeric vector and
learns a single linear logit. Despite its simplicity, LR is strong for
high-dimensional sparse data and is commonly used as a baseline or a "wide"
component in hybrid models.

Workflow:
- Embed sparse/sequence fields; project dense fields if configured
- Concatenate all feature vectors into a single linear input
- Apply a linear layer to produce logits
- Use the prediction layer to output task-specific probabilities

LR 是 CTR/排序任务中最经典的线性基线模型。它将稠密、稀疏以及序列特征
映射为数值向量后做线性组合，输出 logit。虽然结构简单，但在稀疏高维场景
依然具有很强的基线效果，并常作为 Wide 端与深模型组合。

流程：
- 稀疏/序列特征做 embedding，稠密特征按需投影
- 拼接所有特征向量形成线性输入
- 线性层输出 logit
- 通过预测层输出任务概率

"""

from nextrec.basic.features import DenseFeature, SequenceFeature, SparseFeature
from nextrec.basic.layers import EmbeddingLayer, LR as LinearLayer
from nextrec.basic.heads import TaskHead
from nextrec.basic.model import BaseModel
from nextrec.utils.types import TaskTypeInput


class LR(BaseModel):
    @property
    def model_name(self):
        return "LR"

    @property
    def default_task(self):
        return "binary"

    def __init__(
        self,
        dense_features: list[DenseFeature] | None = None,
        sparse_features: list[SparseFeature] | None = None,
        sequence_features: list[SequenceFeature] | None = None,
        target: str | list[str] | None = None,
        task: TaskTypeInput | list[TaskTypeInput] | None = None,
        **kwargs,
    ):

        dense_features = dense_features or []
        sparse_features = sparse_features or []
        sequence_features = sequence_features or []

        super(LR, self).__init__(
            dense_features=dense_features,
            sparse_features=sparse_features,
            sequence_features=sequence_features,
            target=target,
            task=task,
            **kwargs,
        )

        self.embedding = EmbeddingLayer(features=self.all_features)
        linear_input_dim = self.embedding.input_dim
        self.linear = LinearLayer(linear_input_dim)
        self.prediction_layer = TaskHead(task_type=self.task)

        self.register_regularization_weights(embedding_attr="embedding", include_modules=["linear"])

    def forward(self, x):
        input_linear = self.embedding(x=x, features=self.all_features, squeeze_dim=True)
        y = self.linear(input_linear)
        return self.prediction_layer(y)
