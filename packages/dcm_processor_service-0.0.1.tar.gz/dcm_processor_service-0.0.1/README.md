# dcm-processor-service

`dcm-processor-service` is the runtime helper and service SDK for processing code that runs inside the dcm-processor platform.

It provides the functions that service modules use while a worker is executing a job.

## Role In The Bigger Picture

This package is what processing code talks to at runtime.

If a service module contains the actual domain logic for a medical imaging task, this package provides the surrounding execution tools:

- session data helpers
- session file helpers
- peer lookup helpers
- DICOM conversion helpers
- DICOM sending helpers
- access to runtime job/session context via environment variables

It is effectively the service-side standard library for the platform.

## Main Responsibilities

### 1. Runtime Context Access

The module reads execution context from environment variables injected by the worker runtime.

This includes values such as:

- database provider
- database URL and name
- session id
- job id
- job name
- job event
- service name
- peer id

### 2. Session Data And File Access

The module exposes helpers to store and retrieve:

- session-scoped key/value data
- session-scoped files

That allows different processing stages to exchange intermediate artifacts through the shared DB-backed session model.

### 3. DICOM And Imaging Utilities

The package contains helpers for:

- DICOM dataset access
- DICOM series export
- NIfTI conversion
- DICOM sending
- document and series creation helpers

These are the domain-facing tools a service callback typically needs.

### 4. Pre/Post Service Hooks

The worker runtime can call standard pre-service and post-service functions that live in this package.

Those hooks support common runtime behavior outside of service-specific processing modules.

## Key Internal Areas

- `dcm_processor_service/db_manager.py`
  - session, peer, and DB-backed runtime helpers
- `dcm_processor_service/env_vars.py`
  - access to injected runtime environment values
- `dcm_processor_service/converters.py`
  - DICOM and NIfTI conversion helpers
- `dcm_processor_service/dicom_network/`
  - DICOM networking helpers such as sending
- `dcm_processor_service/pre_services.py`
- `dcm_processor_service/post_services.py`

## Dependencies On Other Modules

This module depends mainly on:

- `dcm-processor-db-provider`
  - for session data and file persistence
- `dcm-processor-utils`
  - for shared helpers

It is used by:

- `dcm-processor-worker`
  - which injects the runtime context and executes code that imports this package

## What This Module Is Not

This package is not:

- the job scheduler
- the worker implementation
- the DICOM ingest server
- the CLI

It is the service execution support layer.

## Summary

Use this module from inside processing callbacks and service runtime code.

It provides the runtime-facing API that service authors use to interact with sessions, files, peers, and imaging data while their job is running.
