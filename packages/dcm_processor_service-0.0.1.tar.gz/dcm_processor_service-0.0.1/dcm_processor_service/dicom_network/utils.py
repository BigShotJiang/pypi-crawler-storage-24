import base64, datetime, zipfile, re, time
from io import BytesIO
from pydicom import FileDataset, Dataset, dcmread, uid
from pydicom.dataset import FileMetaDataset
from pydicom.uid import generate_uid, SecondaryCaptureImageStorage, CTImageStorage
from pydicom.valuerep import DSfloat
from pydicom.multival import MultiValue
from copy import deepcopy
import numpy as np
import nibabel as nib

COPY_TAGS = {
    "1.2.840.10008.5.1.4.1.1.104.1": [
        "PatientName", "PatientID", "PatientSex", "PatientBirthDate",
        "IssuerOfPatientID", "TypeOfPatientID", "LocalNamespaceEntityID", "OtherPatientNames",
        "PatientSize", "PatientWeight", "PatientBodyMassIndex",
        "PatientState","PregnancyStatus", "StudyInstanceUID","StudyID",
        "StudyDate", "StudyTime", "AccessionNumber", "StudyDescription", "ReferringPhysicianName",
        "ReferringPhysicianIdentificationSequence", "ConsultingPhysicianName",
        "ConsultingPhysicianIdentificationSequence", "ProcedureCodeSequence",
        "PhysiciansOfRecord", "PhysiciansOfRecordIdentificationSequence",
        "NameOfPhysiciansReadingStudy", "PhysiciansReadingStudyIdentificationSequence",
        "ReferencedStudySequence", "RequestingService", "RequestingServiceCodeSequence",
        "ReasonForPerformedProcedureCodeSequence", "Laterality", "Manufacturer",
        "ManufacturerModelName", "DeviceSerialNumber", "ContentQualification"
    ],
    "1.2.840.10008.5.1.4.1.1.7": [
        "PatientName", "PatientID", "PatientSex", "PatientBirthDate",
        "ReferencedPatientSequence", "IssuerOfPatientID", "LocalNamespaceEntityID", "TypeOfPatientID",
        "PatientBirthTime", "OtherPatientNames", "PatientSize",
        "PatientWeight", "PatientBodyMassIndex", "PatientState",
        "PatientPosition", "PregnancyStatus", "AdmissionID",
        "StudyInstanceUID", "StudyID", "StudyDate", "StudyTime",
        "AccessionNumber", "AcquisitionDate", "AcquisitionTime", "AcquisitionNumber",
        "IssuerOfAccessionNumberSequence", "StudyDescription",
        "ReferringPhysicianName", "ReferringPhysicianIdentificationSequence",
        "ConsultingPhysicianName", "ConsultingPhysicianIdentificationSequence",
        "ProcedureCodeSequence", "PhysiciansOfRecord",
        "PhysiciansOfRecordIdentificationSequence", "NameOfPhysiciansReadingStudy",
        "PhysiciansReadingStudyIdentificationSequence", "ReferencedStudySequence",
        "RequestingService", "RequestingServiceCodeSequence",
        "ReasonForPerformedProcedureCodeSequence", "Laterality",
        "Manufacturer", "ManufacturerModelName", "PatientOrientation",
        "DeviceSerialNumber", "PixelPresentation", "ContentQualification",
    ],
    "others": [
        "PatientName", "PatientID", "PatientSex", "PatientBirthDate",
        "ReferencedPatientSequence", "IssuerOfPatientID", "LocalNamespaceEntityID", "TypeOfPatientID",
        "PatientBirthTime", "OtherPatientNames", "PatientSize",
        "PatientWeight", "PatientBodyMassIndex", "PatientState", "PatientPosition",
        "PregnancyStatus", "AdmissionID",
        "StudyInstanceUID", "StudyID", "StudyDate", "StudyTime", "AccessionNumber",
        "AcquisitionDate", "AcquisitionTime", "AcquisitionNumber",
        "IssuerOfAccessionNumberSequence", "StudyDescription",
        "ReferringPhysicianName", "ReferringPhysicianIdentificationSequence",
        "ConsultingPhysicianName", "ConsultingPhysicianIdentificationSequence",
        "ProcedureCodeSequence", "PhysiciansOfRecord",
        "PhysiciansOfRecordIdentificationSequence", "NameOfPhysiciansReadingStudy",
        "PhysiciansReadingStudyIdentificationSequence", "ReferencedStudySequence",
        "RequestingService", "RequestingServiceCodeSequence",
        "ReasonForPerformedProcedureCodeSequence", "Laterality",
        "Manufacturer", "ManufacturerModelName", "DeviceSerialNumber",
        "PositionReferenceIndicator", "GantryDetectorTilt",
        "DistanceSourceToPatient", "DistanceSourceToDetector",
        "SharedFunctionalGroupsSequence", "PerFrameFunctionalGroupsSequence",
        "DimensionOrganizationSequence", "DimensionIndexSequence",
        "AcquisitionContextSequence", "PixelPresentation", "VolumetricProperties",
        "VolumeBasedCalculationTechnique", "PatientOrientation", "KVP",
        "FrameOfReferenceUID"
    ]
}

def generate_dicom_from_pdf(pdf_data):
    """
    generates dicom dataset from a pdf

    Parameters
    ----------
    pdf_data: base64 str representation of the pdf file
    Returns
    -------
    dataset: pydicom dataset representation of the pdf data
    """

    filename = None

    file_meta = FileMetaDataset()
    file_meta.FileMetaInformationVersion = b'\x00\x01'
    file_meta.MediaStorageSOPClassUID = uid.EncapsulatedPDFStorage
    file_meta.MediaStorageSOPInstanceUID = uid.generate_uid()
    file_meta.ImplementationClassUID = "1.3.46.670589.50.1.8.0"
    file_meta.TransferSyntaxUID = uid.ExplicitVRLittleEndian

    ds_data = FileDataset(filename, {}, file_meta=file_meta, preamble=b"\0" * 128)

    ds_data.is_little_endian = True
    ds_data.is_implicit_VR = False

    cur_dt = datetime.datetime.now()
    ds_data.ContentDate = cur_dt.strftime("%Y%m%d")
    time_str = cur_dt.strftime("%H%M%S.%f")
    ds_data.ContentTime = time_str
    ds_data.AcquisitionDateTime = cur_dt.strftime("%Y%m%d%H%M%S")
    ds_data.SeriesDate = cur_dt.strftime("%Y%m%d")
    ds_data.SeriesTime = cur_dt.strftime("%H%M%S.%f")

    ds_data.SOPClassUID = uid.EncapsulatedPDFStorage

    f_read = base64.b64decode(pdf_data)
    value_length = len(f_read)
    ## All Dicom Element must have an even ValueLength
    if value_length % 2 != 0:
        f_read += b"\0"

    ds_data.EncapsulatedDocument = f_read
    ds_data.MIMETypeOfEncapsulatedDocument = "application/pdf"

    ds_data.Modality = "OT"  # document
    ds_data.ConversionType = "WSD"  # workstation
    ds_data.SpecificCharacterSet = "ISO_IR 100"
    ds_data.InstanceNumber = '1'
    ds_data.BurnedInAnnotation = "NO"

    concept = Dataset()
    concept.CodeValue = "18748-4"  # LOINC code for imaging report
    concept.CodingSchemeDesignator = "LN"  # LOINC
    concept.CodeMeaning = "Diagnostic imaging report"
    ds_data.ConceptNameCodeSequence = [concept]

    return ds_data

def format_patient_age(age):
    if age is None:
        return age
    
    if len(age) >= 4:
        return age
    
    try:
        number = int("".join(re.findall(r"\d", age)))
        return f"{str(int(number)).zfill(3)}Y"
    except:
        print("Unable to reformat PatientAge {age}", flush=True)
    
    return age

def post_process_all_ds(ds: Dataset):
    for elem in ds:
        try:
            if elem.VR == "DS":
                if isinstance(elem.value, (list, MultiValue)):
                    elem.value = [DSfloat(str(v)[:16]) for v in elem.value]
                else:
                    elem.value = DSfloat(str(elem.value)[:16])
        except Exception as ex:
            pass

def get_orientation(ds, tol=0.1):
    """
    Determine the orientation of a DICOM image from ImageOrientationPatient.

    Parameters:
        ds : pydicom.dataset.Dataset
            DICOM dataset containing ImageOrientationPatient (0020,0037)
        tol : float
            Tolerance for detecting primary planes. Values < tol are considered zero.

    Returns:
        str: 'AXIAL', 'SAGITTAL', 'CORONAL', or 'OBLIQUE'
    """
    if not hasattr(ds, 'ImageOrientationPatient'):
        return None

    iop = ds.ImageOrientationPatient
    if len(iop) != 6:
        return None

    # Convert to numpy arrays
    row_cosines = np.array(iop[:3], dtype=float)
    col_cosines = np.array(iop[3:], dtype=float)

    # Compute normal vector
    normal = np.cross(row_cosines, col_cosines)
    abs_normal = np.abs(normal)

    # Determine dominant axis
    max_idx = np.argmax(abs_normal)
    max_val = abs_normal[max_idx]

    # Check if dominant component is significantly larger than others
    if max_val < (1 - tol):
        return "OBLIQUE"

    plane = {0: "SAGITTAL", 1: "CORONAL", 2: "AXIAL"}[max_idx]
    return plane

def get_patient_orientation(ds: Dataset):
    """
    Compute PatientOrientation (0020,0020) from a pydicom Dataset.

    Parameters:
        ds (pydicom.dataset.Dataset): The DICOM dataset containing ImageOrientationPatient.

    Returns:
        str: 2-letter patient orientation (row + column), e.g., 'RA', 'LP', 'HF'.
    """
    if not hasattr(ds, 'ImageOrientationPatient'):
        return None

    iop = ds.ImageOrientationPatient
    if len(iop) != 6:
        return None

    row_cos = np.array(iop[:3], dtype=float)
    col_cos = np.array(iop[3:], dtype=float)

    def axis_label(cos):
        """
        Determine which patient axis the vector points to most strongly.
        Returns 'R', 'L', 'A', 'P', 'H', or 'F'.
        """
        # x-axis (L-R), y-axis (P-A), z-axis (I-S/H-F)
        axes = ['R','L','A','P','H','F']
        values = [cos[0], -cos[0], cos[1], -cos[1], cos[2], -cos[2]]
        # Pick the axis with the largest magnitude
        idx = np.argmax(np.abs(values))
        return axes[idx]

    row_orientation = axis_label(row_cos)
    col_orientation = axis_label(col_cos)

    return [row_orientation, col_orientation]

def make_pdf_dicom(ref_dicom, pdf_data, series_description=None, series_number=None):
    """
    create dicom series from a base64 pdf data

    Parameters
    ----------
    ref_dicom: reference pydicom dataset to copy dicom tags from
    pdf_data: str, base64 string representation of pdf

    Returns
    -------
    dataset: pydicom dataset representation of pdf data
    """

    pdf_ds = generate_dicom_from_pdf(pdf_data=pdf_data)
    ref_dicom_copy = deepcopy(ref_dicom)

    for tag in COPY_TAGS.get(pdf_ds.SOPClassUID, COPY_TAGS.get("others")):
        if tag in ref_dicom_copy:
            pdf_ds[tag] = ref_dicom_copy[tag]

    sop_instance_uid = generate_uid()
    pdf_ds.SeriesInstanceUID = generate_uid()
    pdf_ds.file_meta.MediaStorageSOPInstanceUID = sop_instance_uid
    pdf_ds.SOPInstanceUID = sop_instance_uid

    # copy and patch series number
    ref_series_number = str(ref_dicom_copy.SeriesNumber or '00')
    new_series_number = f"{ref_series_number}{series_number or '2000'}"

    if len(new_series_number) > 9:
        new_series_number = new_series_number[-9:]

    pdf_ds.SeriesNumber = new_series_number
    pdf_ds.SeriesDescription = series_description or "SpineQ PDF Report"
    pdf_ds.DocumentTitle = series_description or "SpineQ PDF Report"

    if ('PatientAge' in ref_dicom_copy) and (not ref_dicom_copy.get("PatientAge") is None) and (str(ref_dicom_copy.get("PatientAge")).strip() != ""):
        pdf_ds.PatientAge = format_patient_age(ref_dicom_copy.PatientAge)
    else:
        if ('PatientBirthDate' in ref_dicom_copy and 'StudyDate' in ref_dicom_copy):
            try:
                birth_year = int(str(ref_dicom_copy.get('PatientBirthDate')).strip()[:4])
                study_year = int(str(ref_dicom_copy.get('StudyDate')).strip()[:4])
                pdf_ds.PatientAge = format_patient_age(study_year - birth_year)
            except Exception:
                pass

    # Set Laterality if not present
    if ("Laterality" in pdf_ds) and ((pdf_ds.Laterality is None) or (pdf_ds.Laterality == "")):
        delattr(pdf_ds, "Laterality")

    # Set Refering Physician Name if not present
    if not hasattr(pdf_ds, "ReferringPhysicianName") or pdf_ds.ReferringPhysicianName is None:
        pdf_ds.ReferringPhysicianName = ""

    return pdf_ds

def make_series_dicom(ref_dicom, datasets, series_description=""):
    """
    create dicom series from a list of pydicom datasets

    Parameters
    ----------
    ref_dicom: reference pydicom dataset to copy dicom tags from
    datasets: list[dataset], list of pydicom dataset
    series_description: str, series description attached to each instance

    Returns
    -------
    datasets: list[dataset], list of modified datasets
    """
    
    series_uid = generate_uid()
    ref_dicom_copy = deepcopy(ref_dicom)
    ref_series_number = str(ref_dicom_copy.SeriesNumber or '00')

    # Compute orientation for image type
    im_type = ["DERIVED", "SECONDARY", "AXIAL"]
    im_orientation = get_orientation(ref_dicom_copy)

    # If computation fails then check if its present in image type
    if im_orientation is None:
        ref_im_type = ref_dicom_copy.ImageType or []
        if len(ref_im_type) >= 3:
            im_type[2] = ref_im_type[2]
    else:
        im_type[2] = im_orientation

    frame_of_ref_uid = generate_uid()

    if 'PatientAge' in ref_dicom_copy and (not ref_dicom_copy.get("PatientAge") is None) and (str(ref_dicom_copy.get("PatientAge")).strip() != ""):
        patient_age = format_patient_age(ref_dicom_copy.PatientAge)
    else:
        if ('PatientBirthDate' in ref_dicom_copy and 'StudyDate' in ref_dicom_copy):
            try:
                birth_year = int(str(ref_dicom_copy.get('PatientBirthDate')).strip()[:4])
                study_year = int(str(ref_dicom_copy.get('StudyDate')).strip()[:4])
                patient_age = format_patient_age(study_year - birth_year)
            except Exception:
                patient_age = None

    for dataset in datasets:
        dataset.SpecificCharacterSet = "ISO_IR 100"
        for tag in COPY_TAGS.get(dataset.SOPClassUID, COPY_TAGS.get("others")):
            if tag in ref_dicom_copy:
                dataset[tag] = ref_dicom_copy[tag]
            else:
                # Set Frame of reference UID if not in ref dicom
                if tag == "FrameOfReferenceUID":
                    dataset.FrameOfReferenceUID = frame_of_ref_uid

        sop_instance_uid = generate_uid()
        dataset.SeriesInstanceUID = series_uid
        dataset.file_meta.MediaStorageSOPInstanceUID = sop_instance_uid
        dataset.SOPInstanceUID = sop_instance_uid
        dataset.ImageType = im_type

        # copy and patch series number
        existing_series_number = str(dataset.SeriesNumber or '00')
        new_series_number = f"{ref_series_number}{existing_series_number}"

        if len(new_series_number) > 9:
            new_series_number = new_series_number[-9:]

        dataset.SeriesNumber = new_series_number

        cur_date = datetime.datetime.now()
        dataset.SeriesDate = cur_date.strftime("%Y%m%d")
        dataset.SeriesTime = cur_date.strftime("%H%M%S.%f")
        dataset.SeriesDescription = series_description
        dataset.PatientAge = patient_age

        # Set Laterality if not present
        if ("Laterality" in dataset) and ((dataset.Laterality is None) or (dataset.Laterality == "")):
            delattr(dataset, "Laterality")

        # Set Laterality to empty string for CT if missing
        if (dataset.SOPClassUID == CTImageStorage or dataset.SOPClassUID == SecondaryCaptureImageStorage) and (not hasattr(dataset, "Laterality")):
            dataset.Laterality = ""

        if not hasattr(dataset, "ReferringPhysicianName") or dataset.ReferringPhysicianName is None:
            dataset.ReferringPhysicianName = ""

        # Check Patient Orientation for SC
        if dataset.SOPClassUID == SecondaryCaptureImageStorage:
            if ((not hasattr(dataset, "PatientOrientation")) or getattr(dataset, "PatientOrientation") == ""):
                dataset.PatientOrientation = get_patient_orientation(dataset) or ""
        
        post_process_all_ds(dataset)
                
    return datasets

def get_slope_and_intercept_pydicom(image: nib.nifti1.Nifti1Image) -> tuple:
    """
    Calculate slope and intercept for scaling NIfTI data to DICOM range.

    Parameters:
    -----------
    image : nib.nifti1.Nifti1Image
        The NIfTI image to be converted.

    Returns:
    --------
    tuple[float, float, str, bool]: A tuple of the slope, intercept, data type,
    and a boolean indicating if the data type was changed.
    """
    arr = image.get_fdata()
    dtype = arr.dtype
    intercept = 0
    slope = 1
    changed = False

    # Determine rescale parameters
    min_val = -(2**15) + 1
    max_val = 2**15 - 1  # int16 range
    img_min = np.min(arr)
    img_max = np.max(arr)

    if img_min < min_val:
        intercept = (img_min - min_val)  # Shift minimum to zero
        img_max = img_max - intercept
        changed = True

    if img_max > max_val:
        slope = max_val / img_max  # Scale maximum to fit into uint16
        changed = True

    return slope, intercept, dtype, changed

def write_dicom_slice(
    file_meta: Dataset,
    series_tag_values: list,
    new_img: nib.nifti1.Nifti1Image,
    arr: np.ndarray,
    modality: str,
    i: int,
) -> Dataset:
    """
    creates a DICOM file from a slice of a Nifti1Image.

    Parameters:
    -----------
    ds : pydicom.Dataset
        The DICOM dataset to be used.
    series_tag_values : list
        A list of tag values to be used in the DICOM file.
    new_img : nib.nifti1.Nifti1Image
        The image to be converted to DICOM.
    i : int
        The slice index.

    Returns:
    --------
        pydicom.Dataset: The DICOM dataset.
    """
    
    i2 = arr.shape[2] - i - 1
    slice_arr = arr[:, :, i].T

    # Create a new DICOM file
    sop_instance_uid = uid.generate_uid()
    file_meta_copy = deepcopy(file_meta)
    file_meta_copy.MediaStorageSOPInstanceUID = sop_instance_uid
    new_ds = FileDataset(
        None, dataset={}, file_meta=file_meta_copy, preamble=b"\0" * 128
    )

    new_ds.is_little_endian = True
    new_ds.is_implicit_VR = False

    # Copy shared tags
    for tag, value in series_tag_values:
        setattr(new_ds, tag, value)

    # Slice specific tags
    new_ds.SOPInstanceUID = sop_instance_uid
    new_ds.InstanceCreationDate = time.strftime("%Y%m%d")
    new_ds.InstanceCreationTime = time.strftime("%H%M%S")
    new_ds.Modality = modality
    position = np.dot(new_img.affine, [0, 0, i, 1])[:3]
    position[0] = -position[0]  # Flip the x-axis
    position[1] = -position[1]  # Flip the y-axis
    new_ds.ImagePositionPatient = list(position)
    new_ds.InstanceNumber = i2 + 1

    # Add the pixel data
    if slice_arr.dtype != np.uint16:
        slice_arr = slice_arr.astype(np.uint16)

    new_ds.PixelData = slice_arr.tobytes()
    new_ds.Rows, new_ds.Columns = slice_arr.shape
    new_ds.SamplesPerPixel = 1
    new_ds.PhotometricInterpretation = "MONOCHROME2"
    new_ds.BitsAllocated = 16
    new_ds.BitsStored = 16
    new_ds.HighBit = 15
    new_ds.PixelRepresentation = 1

    return new_ds

def nifti_to_dicom(
    img_nib: nib.nifti1.Nifti1Image,
    modality: str,
    series_description="",
    study_instance_uid=None,
    sop_class_uid=None,
    ref_dcm: Dataset|None=None,
) -> list[Dataset]:
    """
    converts a Nifti1Image to a DICOM file. Speifically, it converts a nifti file of orientation PIR and 
    Spacing of (1, 1, 2) to a DICOM file.

    Parameters:
    -----------
    img_nib : nib.nifti1.Nifti1Image
        The image to be converted.
    modality : str
        The modality of the image.
    study_instance_uid : str
        The study instance UID.

    Returns:
    --------
        dict: A dictionary of DICOM datasets.
    """

    slope, intercept, _, dtype_changed = get_slope_and_intercept_pydicom(
        img_nib
    )

    if not ref_dcm is None:
        study_instance_uid = getattr(ref_dcm, "StudyInstanceUID", study_instance_uid)

    file_meta = FileMetaDataset()
    file_meta.TransferSyntaxUID = uid.ExplicitVRLittleEndian
    file_meta.MediaStorageSOPClassUID = sop_class_uid or uid.CTImageStorage
    file_meta.MediaStorageSOPInstanceUID = uid.generate_uid()

    modification_time = time.strftime("%H%M")
    modification_date = time.strftime("%Y%m%d")
    

    # Manually set the direction cosines for sagittal orientation (PIR)
    direction_cosines = [0, 1, 0, 0, 0, -1]
    series_instance_uid = generate_uid()
    series_tag_values = [
        ("SeriesTime", modification_time),  # Series Time
        ("SeriesDate", modification_date),  # Series Date
        ("SeriesNumber", 2001),  # Series Number
        ("ImageType", "DERIVED\\SECONDARY"),  # Image Type
        ("SeriesInstanceUID", series_instance_uid),  # Series Instance UID
        ("ImageOrientationPatient", direction_cosines),  # Image Orientation
        ("PixelSpacing", [1.0, 1.0]),  # Pixel Spacing
        ("SliceThickness", "2.0"),  # Slice Thickness
        ("SpacingBetweenSlices", "2.0"),  # Spacing Between Slices
        ("StudyInstanceUID", study_instance_uid),
        ("Modality", modality),
        ("SOPClassUID", sop_class_uid or uid.CTImageStorage),
        ("WindowCenter", "300"),
        ("WindowWidth", "1500"),  # Window Width
    ]

    #if dtype_changed:

    series_tag_values += [
        ("RescaleSlope", str(slope)),  # rescale slope
        ("RescaleIntercept", str(intercept)),  # rescale intercept
        ("BitsAllocated", 16),  # bits allocated
        ("BitsStored", 16),  # bits stored
        ("HighBit", 15),  # high bit
        ("PixelRepresentation", 1),  # pixel representation
    ]

    # Write slices to output directory
    dcm_list = []
    
    arr = img_nib.get_fdata()

    if slope != 1 or intercept != 0:
        arr = (arr - intercept) / slope

    for i in range(img_nib.shape[2]):
        dcm_list.append(write_dicom_slice(file_meta, series_tag_values, img_nib, arr, modality, i))

    if ref_dcm is None:
        return dcm_list
    
    return make_series_dicom(ref_dicom=ref_dcm, datasets=dcm_list, series_description=series_description)