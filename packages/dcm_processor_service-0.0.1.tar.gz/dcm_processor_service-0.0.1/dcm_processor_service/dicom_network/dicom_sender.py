"""
Loads and sends dicom file to server
"""

from glob import glob
import os, ssl, socket
from pydicom import dcmread, Dataset
from pydicom.errors import InvalidDicomError
from pydicom.uid import ImplicitVRLittleEndian, ExplicitVRLittleEndian
from pynetdicom import AE
from pydicom.uid import (
    CTImageStorage,
    EncapsulatedPDFStorage,
    EnhancedCTImageStorage,
    SecondaryCaptureImageStorage,
    SegmentationStorage,
    RTStructureSetStorage,
    ParametricMapStorage,
    BasicTextSRStorage, 
    EnhancedSRStorage, 
    ComprehensiveSRStorage,
    Comprehensive3DSRStorage,
)

REQUESTED_SOP_CLASSES = [
    CTImageStorage,
    EncapsulatedPDFStorage,
    EnhancedCTImageStorage,
    SecondaryCaptureImageStorage,
    SegmentationStorage,
    RTStructureSetStorage,
    ParametricMapStorage,
    BasicTextSRStorage, 
    EnhancedSRStorage, 
    ComprehensiveSRStorage,
    Comprehensive3DSRStorage,
]
REQUESTED_TRANSFER_SYNTAXES = [ExplicitVRLittleEndian, ImplicitVRLittleEndian]
STATUS_CONTEXT_NOT_ACCEPTED = 0xC001


class DicomSender:
    """
    A class to handle the creation of dicom application entity and sending of dicom
    data using the dicom send protocol
    """

    def __init__(
        self,
        ae_title,
        server_host,
        server_port,
        server_ae_title=None,
        enable_tls=False,
        tls_cert_file=None,
        tls_key_file=None,
        tls_ca_file=None,
        tls_trusted_ca=False,
        additional_sops=None,
        additional_syntaxes=None,
    ) -> None:
        # Initialise the Application Entity
        self.app_entity = AE(ae_title=ae_title)
        self.ae_title = server_ae_title
        self.host = server_host
        self.port = server_port

        # TLS information
        self.enable_tls = enable_tls
        self.cert_file = tls_cert_file
        self.key_file = tls_key_file
        self.ca_file = tls_ca_file
        self.trusted_ca = tls_trusted_ca

        self.ssl_cx = None

        # Add a requested presentation context
        sop_classes = list(set(REQUESTED_SOP_CLASSES + (additional_sops or [])))
        syntaxes = list(set(REQUESTED_TRANSFER_SYNTAXES + (additional_syntaxes or [])))

        for context in sop_classes:
            self.app_entity.add_requested_context(context, syntaxes)

        self.app_entity.add_requested_context("1.2.840.10008.1.1")

    def __convert_to_syntax(self, ds: Dataset, syntax):
        if (
            ds.file_meta.TransferSyntaxUID in REQUESTED_TRANSFER_SYNTAXES
            and syntax in REQUESTED_TRANSFER_SYNTAXES
            and ds.file_meta.TransferSyntaxUID != syntax
        ):
            ds.file_meta.TransferSyntaxUID = syntax
            ds.is_little_endian = True
            ds.is_implicit_VR = syntax == ImplicitVRLittleEndian

        return ds

    def __get_accepted_syntax(self, accepted_contexts, sop_class, preferred_syntax):
        for context in accepted_contexts:
            if context.abstract_syntax == sop_class:
                if len(context.transfer_syntax) > 0:
                    if preferred_syntax in context.transfer_syntax:
                        return preferred_syntax
                    
                    return context.transfer_syntax[0]
                
        return None

    def __iter_dicom_datasets_from_path(self, path):
        for entry in sorted(os.scandir(path), key=lambda item: item.name):
            if not entry.is_file():
                continue

            try:
                yield entry.path, dcmread(entry.path)
            except (InvalidDicomError, OSError):
                continue
    
    def __create_assoc(self, **kwargs):

        c_enable_tls = self.enable_tls
        c_host = self.host
        c_port = self.port
        c_aet = self.ae_title
        c_cert_file = self.cert_file
        c_key_file = self.key_file
        c_ca_file = self.ca_file
        c_trusted_ca = self.trusted_ca

        host=kwargs.get("host")
        port=kwargs.get("port")
        aet=kwargs.get("aet", kwargs.get("ae_title"))
        tls=kwargs.get("tls", kwargs.get("enable_tls"))
        cert_file=kwargs.get("cert_file", kwargs.get("tls_cert_file"))
        key_file=kwargs.get("key_file", kwargs.get("tls_key_file"))
        ca_file=kwargs.get("ca_file", kwargs.get("tls_ca_file"))
        trusted_ca=kwargs.get("trusted_ca", kwargs.get("tls_trusted_ca"))

        if not host is None:
            c_host = host

        if not port is None:
            c_port = port
        
        if not aet is None:
            c_aet = aet

        if not tls is None:
            c_enable_tls = tls
            if c_enable_tls:
                if not cert_file is None:
                    c_cert_file = cert_file
                if not key_file is None:
                    c_key_file = key_file
                if not ca_file is None:
                    c_ca_file = ca_file
                if not trusted_ca is None:
                    c_trusted_ca = trusted_ca

        if c_enable_tls:
            # Create the SSLContext
            self.ssl_cx = ssl.create_default_context(
                ssl.Purpose.SERVER_AUTH,
                cafile=None if c_trusted_ca else c_ca_file,
            )
            self.ssl_cx.verify_mode = ssl.CERT_REQUIRED
            self.ssl_cx.load_cert_chain(
                certfile=c_cert_file, keyfile=c_key_file
            )

            ssl_hostname = socket.gethostname()
            assoc = (
                self.app_entity.associate(
                    c_host, c_port, tls_args=(self.ssl_cx, ssl_hostname)
                )
                if c_aet is None
                else self.app_entity.associate(
                    c_host,
                    c_port,
                    ae_title=c_aet,
                    tls_args=(self.ssl_cx, ssl_hostname),
                )
            )
        else:
            assoc = (
                self.app_entity.associate(c_host, c_port)
                if c_aet is None
                else self.app_entity.associate(
                    c_host, c_port, ae_title=c_aet
                )
            )

        return assoc

    def send_dicom_from_path(self, path, filter_callback=None, **kwargs):
        """
        Send dicom data from a directory containing dicom files

        Parameters
        ----------
        path: path to a dicom directory
        filter_callback: function, callback funtion executed to filter out the dicom files.

        Returns
        -------
        statuses: list of status returned from the dicom send operation
        """
        # Associate with peer AE
        assoc = self.__create_assoc(**kwargs)
        statuses = []

        if assoc.is_established:
            # Use the C-STORE service to send the dataset
            # returns the response status as a pydicom Dataset
            for pname, ds_data in self.__iter_dicom_datasets_from_path(path):

                res = True

                if not filter_callback is None:
                    res = filter_callback(ds_data)

                if not res:
                    continue

                # Check and convert transfer-syntax if needed
                sop_class_uid = ds_data.SOPClassUID
                syntax = self.__get_accepted_syntax(assoc.accepted_contexts, sop_class_uid, ds_data.file_meta.TransferSyntaxUID)
                # Check if SOP was accepted
                if syntax is None:
                    print(
                        f"Error: SCP did not accept any presentation context for {sop_class_uid}",
                        flush=True
                    )
                    status = Dataset()
                    status.Status = STATUS_CONTEXT_NOT_ACCEPTED
                    statuses.append(status)
                    continue

                ds_data = self.__convert_to_syntax(ds_data, syntax)

                status = assoc.send_c_store(ds_data)

                # Check the status of the storage request
                statuses.append(status)
                if status:
                    # If the storage request succeeded this will be 0x0000
                    if not status.Status == 0x0000:
                        print(f"C-STORE request status: {status.Status}", flush=True)
                else:
                    print(
                        "Connection timed out, was aborted or received invalid response",
                        flush=True
                    )

            # Release the association
            assoc.release()
        else:
            print("Association rejected, aborted or never connected", flush=True)

        return statuses

    def send_dicom_from_filelist(self, filelist, filter_callback=None, **kwargs):
        """
        Send dicom data from a a list of dicom files

        Parameters
        ----------
        filelist: list of filenames of dicom files
        filter_callback: function, callback funtion executed to filter out the dicom files.

        Returns
        -------
        statuses: list of status returned from the dicom send operation
        """
        # Associate with peer AE
        assoc = self.__create_assoc(**kwargs)
        statuses = []

        if assoc.is_established:
            # Use the C-STORE service to send the dataset
            # returns the response status as a pydicom Dataset
            for pname in filelist:
                ds_data = dcmread(pname)

                res = True

                if not filter_callback is None:
                    res = filter_callback(ds_data)

                if not res:
                    continue

                # Check and convert transfer-syntax if needed
                sop_class_uid = ds_data.SOPClassUID
                syntax = self.__get_accepted_syntax(assoc.accepted_contexts, sop_class_uid, ds_data.file_meta.TransferSyntaxUID)
                # Check if SOP was accepted
                if syntax is None:
                    print(
                        f"Error: SCP did not accept any presentation context for {sop_class_uid}",
                        flush=True
                    )
                    status = Dataset()
                    status.Status = STATUS_CONTEXT_NOT_ACCEPTED
                    statuses.append(status)
                    continue

                ds_data = self.__convert_to_syntax(ds_data, syntax)

                status = assoc.send_c_store(ds_data)
                statuses.append(status)
                # Check the status of the storage request
                if status:
                    # If the storage request succeeded this will be 0x0000
                    if not status.Status == 0x0000:
                        print(f"C-STORE request status: {status.Status}", flush=True)
                else:
                    print(
                        "Connection timed out, was aborted or received invalid response",
                        flush=True
                    )

            # Release the association
            assoc.release()
        else:
            print("Association rejected, aborted or never connected", flush=True)

        return statuses

    def send_dicom_from_dataset(self, datasets, filter_callback=None, **kwargs):
        """
        Send dicom data from a pydicom list of datasets

        Parameters
        ----------
        datasets: list of pydicom dataset
        filter_callback: function, callback funtion executed to filter out the dicom files.

        Returns
        -------
        statuses: list of status returned from the dicom send operation
        """
        # Associate with peer AE
        assoc = self.__create_assoc(**kwargs)
        statuses = []

        if assoc.is_established:
            # Use the C-STORE service to send the dataset
            # returns the response status as a pydicom Dataset
            for ds_data in datasets:
                res = True

                if not filter_callback is None:
                    res = filter_callback(ds_data)

                if not res:
                    continue

                # Check and convert transfer-syntax if needed
                sop_class_uid = ds_data.SOPClassUID
                syntax = self.__get_accepted_syntax(assoc.accepted_contexts, sop_class_uid, ds_data.file_meta.TransferSyntaxUID)
                # Check if SOP was accepted
                if syntax is None:
                    print(
                        f"Error: SCP did not accept any presentation context for {sop_class_uid}",
                        flush=True
                    )
                    status = Dataset()
                    status.Status = STATUS_CONTEXT_NOT_ACCEPTED
                    statuses.append(status)
                    continue

                ds_data = self.__convert_to_syntax(ds_data, syntax)

                status = assoc.send_c_store(ds_data)
                statuses.append(status)
                # Check the status of the storage request
                if status:
                    # If the storage request succeeded this will be 0x0000
                    if not status.Status == 0x0000:
                        print(f"C-STORE request status: {status.Status}", flush=True)
                else:
                    print(
                        "Connection timed out, was aborted or received invalid response",
                        flush=True
                    )

            # Release the association
            assoc.release()
        else:
            print("Association rejected, aborted or never connected", flush=True)

        return statuses

    def send_dicom_from_dicomdir(self, filename, filter_callback=None, **kwargs):
        """
        Send dicom data from a dicomdir file

        Parameters
        ----------
        filename: filepath, path to the dicomdir file
        filter_callback: function, callback funtion executed to filter out the dicom files.

        Returns
        -------
        statuses: list of status returned from the dicom send operation
        """
        # Associate with peer AE
        assoc = self.__create_assoc(**kwargs)

        statuses = []

        dicom_dir = dcmread(filename)
        base_dir = os.path.dirname(filename)

        if not assoc.is_established:
            print("Association rejected, aborted or never connected", flush=True)
            return statuses

        # Use the C-STORE service to send the dataset
        # returns the response status as a pydicom Dataset
        for patient_record in dicom_dir.patient_records:
            studies = patient_record.children
            for study in studies:
                all_series = study.children
                for series in all_series:
                    image_records = series.children
                    image_filenames = [
                        os.path.join(base_dir, *image_rec.ReferencedFileID)
                        for image_rec in image_records
                    ]

                    for image_filename in image_filenames:

                        ds_data = dcmread(image_filename)
                        res = True

                        if not filter_callback is None:
                            res = filter_callback(ds_data)

                        if not res:
                            continue

                        # Check and convert transfer-syntax if needed
                        sop_class_uid = ds_data.SOPClassUID
                        syntax = self.__get_accepted_syntax(assoc.accepted_contexts, sop_class_uid, ds_data.file_meta.TransferSyntaxUID)
                        # Check if SOP was accepted
                        if syntax is None:
                            print(
                                f"Error: SCP did not accept any presentation context for {sop_class_uid}",
                                flush=True
                            )
                            status = Dataset()
                            status.Status = STATUS_CONTEXT_NOT_ACCEPTED
                            statuses.append(status)
                            continue

                        ds_data = self.__convert_to_syntax(ds_data, syntax)

                        status = assoc.send_c_store(ds_data)
                        statuses.append(status)

                        # Check the status of the storage request
                        if (not status is None) and (not status.Status == 0x0000):
                            # If the storage request succeeded this will be 0x0000
                            print(f"C-STORE request status: {status.Status}", flush=True)
                        elif status is None:
                            print(
                                "Connection timed out, was aborted or received invalid response",
                                flush=True
                            )

        # Release the association
        assoc.release()

        return statuses

    def send_echo(self, **kwargs):
        """
        Send echo to connected dicom server to check if connection is successful

        Returns
        -------
        status: status object from the echo request
        """
        assoc = self.__create_assoc(**kwargs)

        if assoc.is_established:
            status = assoc.send_c_echo()
            assoc.release()
            return status

        return None
