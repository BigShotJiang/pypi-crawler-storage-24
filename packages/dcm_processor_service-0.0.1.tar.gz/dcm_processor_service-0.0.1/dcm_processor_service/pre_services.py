
def callback(*args, **kwargs):
    print("PRE SERVICES CALLED!", flush=True)