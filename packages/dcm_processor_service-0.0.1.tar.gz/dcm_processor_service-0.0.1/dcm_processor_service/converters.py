import tempfile, os, shutil, json
from pydicom import dcmread
import nibabel as nib
import numpy as np
from .db_manager import get_mgr
from .dicom_conversion import (
    dicom_series_to_nifti,
    get_simplified_json,
)

def get_series_dicom(series_id, dir_path=None):
    mgr = get_mgr()
    series = mgr.get_series_by_id(series_id)
    
    if series is None:
        return None
    
    instances = series.get("Instances", [])

    if  not dir_path is None:
        os.makedirs(dir_path, exist_ok=True)

    datasets = []

    for inst in instances:
        filename = None if dir_path is None else os.path.join(dir_path, f"{inst}.dcm")
        data = mgr.download_dicom_file(file_id=inst, filename=filename)
        if filename is None:
            dcm_data = dcmread(data)
            datasets.append(dcm_data)
        else:
            datasets.append(filename)

    return datasets
        
def get_series_nifti(series_id, filename=None):

    with tempfile.TemporaryDirectory() as temp_dir:
        dicom_dir = os.path.join(temp_dir, "dicom")
        filenames = get_series_dicom(series_id, dicom_dir)
        series_filename = os.path.join(temp_dir, f"{series_id}.nii.gz")

        if not filenames:
            raise ValueError(f"No DICOM instances found for series '{series_id}'.")

        n_slices = dicom_series_to_nifti(
            series_path=dicom_dir,
            output_file=series_filename
        )

        if not os.path.exists(series_filename):
            raise RuntimeError(f"Unable to convert series '{series_id}' to NIfTI.")

        sample = dcmread(filenames[0])
        json_data = get_simplified_json(sample, n_slices=n_slices)

        if not filename is None:
            # move nifti
            shutil.move(series_filename, filename)

            # Save json
            json_file_name = f"{str(filename).split('.nii')[0]}.json"
            with open(json_file_name, 'w') as jsfile:
                json.dump(json_data, jsfile)

            return filename, json_file_name, None
        else:
            nifti_img = nib.load(series_filename)
            nifti_data = nifti_img.get_fdata(dtype=np.float32)
            return nifti_img, json_data, nifti_data
