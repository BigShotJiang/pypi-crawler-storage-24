from .db_manager import get_mgr

def callback(*args, **kwargs):
    print("POST SERVICES CALLED!", flush=True)
    run_clean_up_service(*args, **kwargs)

def run_clean_up_service(*args, **kwargs):
    session_id = kwargs.get('session_id')
    dbMgr = get_mgr()
    dbMgr.clean_up_sesssion(
        session_id=session_id
    )
    
