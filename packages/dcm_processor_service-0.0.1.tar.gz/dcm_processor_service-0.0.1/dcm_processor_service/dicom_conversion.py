"""
Handles DICOM to nifti conversion
"""
import tempfile, os, shutil, glob, re
from copy import deepcopy
import nibabel as nib
import numpy as np
from dcm2niix import main as dcm2niix
import pydicom


def __get_json(data):
    """
    takes a dictionary returned from pydicom.dataset.to_json_dict and rearranges it to be
    compatible with json encoding
    """
    data1 = {}
    for key, value in data.items():
        try:
            k = pydicom.datadict.dictionary_keyword(key)
        except Exception:
            continue
        if "Value" in value:
            if isinstance(value["Value"], list) and len(value["Value"]) > 0:
                if isinstance(value["Value"][0], dict):
                    data1[k] = [
                        __get_json(value["Value"][i]) for i in range(len(value["Value"]))
                    ]
                else:
                    if len(data[key]["Value"]) == 1:
                        data1[k] = data[key]["Value"][0]
                    else:
                        data1[k] = data[key]["Value"]
            else:
                data1[k] = data[key]["Value"]
    return data1

def __dataset_to_json(ds: pydicom.Dataset):
    result = {}

    for elem in ds.iterall():
        try:
            tmp_ds = pydicom.Dataset()
            tmp_ds.add(elem)
            result.update(tmp_ds.to_json_dict())
        except Exception:
            # Fallback: force string
            result[elem.tag] = {
                "vr": elem.VR,
                "Value": [str(elem.value)]
            }

    return result

def get_simplified_json(ds: pydicom.Dataset, n_slices=None):
    """
    creates and save a json file given a pydicom dicom header and a filename path
    """
    try:
        py_dataset = deepcopy(ds)
        py_dataset.PixelData = None
        py_dict = __dataset_to_json(py_dataset)
        simp_json = __get_json(py_dict)

        if "PatientName" in py_dataset:
            simp_json["PatientName"] = str(py_dataset.PatientName)

        if "PatientAge" in py_dataset:
            age = re.findall(r"\d+", str(py_dataset.PatientAge))
            if len(age) > 0:
                simp_json["PatientAge"] = int("".join(age))
        
        if not n_slices is None:
            simp_json["Slices"] = n_slices
        
        return simp_json
    except Exception as e:
        print(e, "pydict error", flush=True)

    return {}

def dicom_series_to_nifti(series_path, output_file):
    """
    Convert dicom series to nifti file

    Parameters
    ----------
    series_path: path to the directory containing the dicom files
    output_file: filename to store the nifti data

    Returns
    -------
    n_slices: int, number of slices in the nifti data
    """
    with tempfile.TemporaryDirectory() as base_dir:
        args = ["-o", base_dir, "-z", "y", "-f", "data", series_path]

        dcm2niix(args)

        min_size = 0
        n_slices = 0
        is_roi = False
        filename = None
        d_type = None
        zoom = None

        for fname in glob.glob(os.path.join(base_dir, "*.nii.gz")):
            d: nib.nifti1.Nifti1Image = nib.load(fname)
            c_d_shape = d.header.get_data_shape()
            c_d_type = d.header.get_data_dtype()
            c_zoom = np.max(d.header.get_zooms())

            m = np.min(c_d_shape)
            c_is_roi = "ROI" in fname.upper()

            if (
                (m > min_size)
                or (m == min_size and is_roi and not c_is_roi)
                or (m == min_size and zoom > c_zoom)
                or (m == min_size and __is_higher_resolution(d_type, c_d_type))
            ):
                filename = fname
                min_size = m
                n_slices = c_d_shape[-1]
                d_type = c_d_type
                is_roi = c_is_roi
                zoom = c_zoom

        if not filename is None:
            print(f"Selected filename: {filename}", flush=True)
            shutil.move(filename, output_file)

        return n_slices

def __is_higher_resolution(pre_d_type, cur_d_type):
    """
    Check if given current resolution is higher than previous resolution

    Parameters
    ----------
    pre_d_type: prev data type
    cur_d_type: current data type

    """
    if pre_d_type is None:
        return True
    return cur_d_type.itemsize > pre_d_type.itemsize
