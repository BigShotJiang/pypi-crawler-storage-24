import os

def get_db_info():
    dbprovider = os.getenv("DCM-PROCESSOR-SERVICE-DB-PROVIDER")
    dburl = os.getenv("DCM-PROCESSOR-SERVICE-DB-URL")
    dbname = os.getenv("DCM-PROCESSOR-SERVICE-DB-NAME")
    return dbprovider, dburl, dbname

def get_session_id():
    sess = os.getenv("DCM-PROCESSOR-SERVICE-SESSION-ID")
    return sess

def get_job_id():
    job = os.getenv("DCM-PROCESSOR-SERVICE-JOB-ID")
    return job

def get_job_event():
    event = os.getenv("DCM-PROCESSOR-SERVICE-JOB-EVENT")
    return event

def get_job_name():
    name = os.getenv("DCM-PROCESSOR-SERVICE-JOB-NAME")
    return name

def get_job_service_name():
    service = os.getenv("DCM-PROCESSOR-SERVICE-JOB-SERVICE-NAME")
    return service

def get_peer_id():
    peer = os.getenv("DCM-PROCESSOR-SERVICE-PEER-ID")
    return peer