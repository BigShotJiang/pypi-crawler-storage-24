from dcm_processor_db_provider import DBManager
from .dicom_network.dicom_sender import DicomSender
from .env_vars import (
    get_db_info, get_job_id, get_session_id,
    get_job_event
)

DBMGR: DBManager|None = None

def get_mgr():
    global DBMGR
    if DBMGR is None:
        dbprovider, dburl, dbname = get_db_info()
        DBMGR = DBManager(dburl=dburl, dbname=dbname, dbprovider=dbprovider)

    return DBMGR

def get_session_data(name, default=None, job_name=None):
    mgr = get_mgr()

    job_id = get_job_id()
    if not job_name is None:
        job_id = mgr.get_session_job_id(get_job_event(), job_name=job_name, session_id=get_session_id())

    res = mgr.get_session_data(
        job_id=job_id,
        name=name,
        select=["value"]
    )

    if not res is None:
        return res.get("value")
    
    return default

def set_session_data(name, value):
    mgr = get_mgr()
    job_id = get_job_id()

    res = mgr.set_session_data(
        job_id=job_id,
        name=name,
        value=value
    )
    return res

def has_session_data(name, job_name=None):
    mgr = get_mgr()

    job_id = get_job_id()
    if not job_name is None:
        job_id = mgr.get_session_job_id(get_job_event(), job_name=job_name, session_id=get_session_id())

    return mgr.has_session_data(
        job_id=job_id,
        name=name
    )

def remove_session_data(name):
    mgr = get_mgr()
    job_id = get_job_id()

    res = mgr.remove_session_data(
        job_id=job_id,
        name=name,
    )
    return res

def upload_session_file(file, name, meta=None, content_type=None, ext=None):
    job_id = get_job_id()
    return get_mgr().upload_session_file(
        job_id=job_id,
        file=file,
        name=name,
        meta=meta,
        content_type=content_type,
        ext=ext
    )

def download_session_file(name, filename=None, job_name=None):
    mgr = get_mgr()

    job_id = get_job_id()
    if not job_name is None:
        job_id = mgr.get_session_job_id(get_job_event(), job_name=job_name, session_id=get_session_id())

    return mgr.download_session_file(
        job_id=job_id,
        name=name,
        filename=filename
    )

def get_session_file(name, select=None, job_name=None):
    mgr = get_mgr()

    job_id = get_job_id()
    if not job_name is None:
        job_id = mgr.get_session_job_id(get_job_event(), job_name=job_name, session_id=get_session_id())

    return mgr.get_session_file(
        job_id=job_id,
        name=name,
        select=select,
    )

def has_session_file(name, job_name=None) -> bool:
    mgr = get_mgr()

    job_id = get_job_id()
    if not job_name is None:
        job_id = mgr.get_session_job_id(get_job_event(), job_name=job_name, session_id=get_session_id())

    return mgr.has_session_file(
        job_id=job_id,
        name=name
    )

def remove_session_file(name) -> bool:
    job_id = get_job_id()
    return get_mgr().remove_session_file(
        job_id=job_id,
        name=name
    )

def get_peer(name=None):
    mgr = get_mgr()

    if not name is None:
        return mgr.get_dicom_peer(name=name)
    
    session_id = get_session_id()
    session = mgr.get_session(session_id=session_id)
    peer_id = session.get("peer_id")
    if not peer_id is None:
        return mgr.get_peer(peer_id=peer_id)
    else:
        return None
    
def get_dicom_sender(peer_name=None, additional_sops=None, additional_syntaxes=None) -> DicomSender|None:
    peer = get_peer(name=peer_name)
    if peer is None:
        return None
    
    kwargs = {
        "ae_title": peer.get("aet"),
        "server_host": peer.get("host"),
        "server_port": peer.get("port"),
        "additional_sops": additional_sops,
        "additional_syntaxes": additional_syntaxes,
        "enable_tls": peer.get("tls", False),
    }

    if peer.get("tls", False):
        kwargs["tls_cert_file"] = peer.get("cert_file")
        kwargs["tls_key_file"] = peer.get("key_file")
        kwargs["tls_ca_file"] = peer.get("ca_file")
        kwargs["tls_trusted_ca"] = peer.get("ca_file") is None
    
    sender = DicomSender(**kwargs)
    return sender

