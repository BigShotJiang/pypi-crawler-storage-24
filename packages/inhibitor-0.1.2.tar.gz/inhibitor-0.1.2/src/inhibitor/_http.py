"""
HTTP response helpers for the Inhibitor client.

Extracts error details from API responses for clearer exceptions.
"""

import httpx


def detail_from_response(response: httpx.Response) -> str | None:
    """
    Try to get a human-readable detail message from the response body.

    :param response: The HTTP response from the API.
    :return: The detail string if present, otherwise None.
    """
    try:
        body = response.json()
        if isinstance(body, dict) and "detail" in body:
            d = body["detail"]
            return d if isinstance(d, str) else str(d)
    except Exception:
        pass
    return None
