"""
Request and response models for the Inhibitor inference API.

All user-facing payloads use only: query, metadata, and additional_metadata.
Metadata follows the shape: {"key": {"value": "<val>", "description": "<des>"}}.
"""

from typing import Any

from pydantic import BaseModel, Field


class MetadataItem(BaseModel):
    """
    Single metadata entry. Shape: {"value": "<val>", "description": "<des>"}.

    Use when building metadata or additional_metadata programmatically.
    """

    value: str = Field(..., description="The metadata value")
    description: str = Field(default="", description="Optional description of this field")


# Metadata shape: {"key": {"value": "val", "description": "des"}}
MetadataDict = dict[str, dict[str, Any]]


class InferenceRequest(BaseModel):
    """
    Request payload for POST /v1/inference.

    Only these three fields are sent. No query parameters.
    """

    query: str = Field(
        ...,
        min_length=1,
        description="Natural language query to evaluate against your policies",
    )
    metadata: MetadataDict | None = Field(
        default=None,
        description=(
            "Optional metadata in the form "
            '{"key": {"value": "val", "description": "des"}}. '
            "Used as authoritative context for compliance evaluation."
        ),
    )
    additional_metadata: MetadataDict | None = Field(
        default=None,
        description=(
            "Extra metadata stored with the inference log only. "
            'Same shape: {"key": {"value": "val", "description": "des"}}.'
        ),
    )


class RuleResult(BaseModel):
    """Result from a single rule's model inference."""

    rule_name: str
    rule_id: str
    predicted_label: str
    decision: str  # ALLOW | MODIFY | BLOCK
    confidence: float
    all_probabilities: dict[str, float]
    rule_explanation: str | None = None


class InferenceResponse(BaseModel):
    """Response from POST /v1/inference."""

    query: str
    final_decision: str  # ALLOW | MODIFY | BLOCK
    final_score: float
    matched_policies: list[str]
    model_results: list[RuleResult]
    explanation: str | None = None
    suggestion: str | None = None
    redacted_query: str | None = None
    processing_time_seconds: float | None = None
    mode: str | None = None
