"""
Inhibitor — Python client for the Inhibitor policy compliance inference API.

You send only: **query**, **metadata**, and **additional_metadata**.
Default base URL is the production API; override with base_url if needed.

Install::

    pip install inhibitor

Usage::

    from inhibitor import InhibitorClient

    client = InhibitorClient(api_key="your-api-key")
    response = client.inference.query(
        "Can I share this document with external partners?",
        metadata={"consent": {"value": "yes", "description": "User consent obtained"}},
    )
    print(response.final_decision)  # ALLOW | MODIFY | BLOCK
    print(response.explanation)
"""

from inhibitor.client import InhibitorClient, AsyncInhibitorClient
from inhibitor.models import (
    InferenceRequest,
    InferenceResponse,
    RuleResult,
    MetadataItem,
    MetadataDict,
)
from inhibitor.exceptions import (
    InhibitorError,
    InhibitorAPIError,
    InhibitorAuthError,
    InhibitorValidationError,
)
from inhibitor.constants import DEFAULT_BASE_URL

__version__ = "0.1.0"
__all__ = [
    "InhibitorClient",
    "AsyncInhibitorClient",
    "InferenceRequest",
    "InferenceResponse",
    "RuleResult",
    "MetadataItem",
    "MetadataDict",
    "DEFAULT_BASE_URL",
    "InhibitorError",
    "InhibitorAPIError",
    "InhibitorAuthError",
    "InhibitorValidationError",
]
