"""
Default configuration for the Inhibitor API client.

Use these when you do not override base_url; pass base_url to the client
to use a different backend.
"""

# Permanent production URL. Override via InhibitorClient(base_url="...") when needed.
DEFAULT_BASE_URL = "https://inhibitor-be.envistudios.com"

# API path for inference (appended to base_url)
INFERENCE_PATH = "/v1/inference"
