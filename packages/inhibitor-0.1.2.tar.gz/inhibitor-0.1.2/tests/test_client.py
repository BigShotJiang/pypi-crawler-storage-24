"""Tests for InhibitorClient (require network/backend for integration tests)."""

import pytest

from inhibitor import (
    InhibitorClient,
    AsyncInhibitorClient,
    InferenceRequest,
    InferenceResponse,
    DEFAULT_BASE_URL,
)
from inhibitor.exceptions import InhibitorAuthError, InhibitorValidationError, InhibitorAPIError


def test_client_creation():
    client = InhibitorClient(api_key="test-key", base_url="https://api.example.com")
    assert client.api_key == "test-key"
    assert client.base_url == "https://api.example.com"
    assert "X-API-Key" in client._headers
    assert client._headers["X-API-Key"] == "test-key"


def test_client_uses_default_base_url():
    client = InhibitorClient(api_key="test-key")
    assert client.base_url == DEFAULT_BASE_URL


def test_inference_request_model():
    req = InferenceRequest(query="Can I share this?")
    assert req.query == "Can I share this?"
    assert req.metadata is None
    req2 = InferenceRequest(
        query="x",
        metadata={"consent": {"value": "yes", "description": "User consent"}},
    )
    assert req2.metadata == {"consent": {"value": "yes", "description": "User consent"}}


def test_inference_response_model():
    data = {
        "query": "test",
        "final_decision": "ALLOW",
        "final_score": 0.95,
        "matched_policies": ["P1"],
        "model_results": [],
        "explanation": "Ok",
    }
    resp = InferenceResponse.model_validate(data)
    assert resp.query == "test"
    assert resp.final_decision == "ALLOW"
    assert resp.matched_policies == ["P1"]
    assert resp.model_results == []


@pytest.mark.asyncio
async def test_async_client_creation():
    async with AsyncInhibitorClient(api_key="test", base_url="https://api.example.com") as client:
        assert client.api_key == "test"
        assert client.inference is not None
