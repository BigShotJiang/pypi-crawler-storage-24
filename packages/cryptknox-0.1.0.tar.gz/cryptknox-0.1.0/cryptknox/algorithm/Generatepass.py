class Generatepass:
    pass