"""
oh-my-linear (OhMyLinear) - unified Linear MCP via local cache + official fallback.
"""

from .cli import main

__version__ = "0.6.5"
__all__ = ["main"]
