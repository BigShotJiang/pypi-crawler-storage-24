from nicegui import ui

from ..render_context import UIRenderContext


def render_global(ctx: UIRenderContext) -> None:
    runtime = ctx.runtime
    global_config = runtime.global_config
    local_config = runtime.local_config
    merged_config = runtime.merged_config
    form_state = runtime.form_state
    state = runtime.state
    has_changes = runtime.has_changes
    active = runtime.active
    nav_buttons = runtime.nav_buttons
    controller = ctx.controller
    content_container = ctx.content_container
    transform_tab_state = ctx.transform_tab_state
    convenience_hooks = ctx.convenience_hooks
    migmanprojects = ctx.migmanprojects
    get_tip = ctx.get_tip
    mark_changed = ctx.mark_changed
    mark_saved = ctx.mark_saved
    set_active = ctx.set_active
    save_config = ctx.save_config
    reset_config = ctx.reset_config
    renderers = ctx.renderers
    self = ctx.ui_app

    def render_global():
        if not content_container:
            return

        content_container.clear()
        with content_container:
            ui.label("Global Settings").classes("text-2xl font-semibold")
            ui.separator()
            ui.label("Configure global settings for the MigMan ETL process.")

            current_etl_directory = form_state["data"].get(
                "etl_directory", "./etl/migman"
            )

            # --- ETL Directory (editable) ---
            with ui.card().classes(""):
                ui.label("ETL directory").classes("text-lg font-semibold mb-2")

                def on_etl_dir_change(e):
                    form_state["data"]["etl_directory"] = e.value
                    mark_changed()

                etl_dir_input = (
                    ui.input(
                        label="Path to ETL folder",
                        value=current_etl_directory,
                        placeholder="e.g. /Users/me/projects/migman/etl",
                        on_change=on_etl_dir_change,
                        validation={
                            "Required": lambda v: bool(v and v.strip())
                        },
                    )
                    .props("dense")
                    .classes("w-[36rem]")
                )
                etl_dir_input.tooltip(get_tip("global.etl_directory"))
                ui.label(
                    "Enter an absolute or relative path to a local folder."
                ).classes("text-sm")

    render_global()
