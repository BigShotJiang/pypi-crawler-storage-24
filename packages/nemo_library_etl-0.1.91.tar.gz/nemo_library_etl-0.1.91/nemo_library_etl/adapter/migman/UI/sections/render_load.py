from nicegui import ui

from ..render_context import UIRenderContext


def render_load(ctx: UIRenderContext) -> None:
    runtime = ctx.runtime
    global_config = runtime.global_config
    local_config = runtime.local_config
    merged_config = runtime.merged_config
    form_state = runtime.form_state
    state = runtime.state
    has_changes = runtime.has_changes
    active = runtime.active
    nav_buttons = runtime.nav_buttons
    controller = ctx.controller
    content_container = ctx.content_container
    transform_tab_state = ctx.transform_tab_state
    convenience_hooks = ctx.convenience_hooks
    migmanprojects = ctx.migmanprojects
    get_tip = ctx.get_tip
    mark_changed = ctx.mark_changed
    mark_saved = ctx.mark_saved
    set_active = ctx.set_active
    save_config = ctx.save_config
    reset_config = ctx.reset_config
    renderers = ctx.renderers
    self = ctx.ui_app

    def render_load():
        if not content_container:
            return

        content_container.clear()
        with content_container:
            ui.label("Load").classes("text-2xl font-semibold")
            ui.separator()
            ui.label("Load data into target system.")

            # Load active toggle
            load_config = form_state["data"].setdefault("load", {})

            with ui.card().classes("mt-4"):
                ui.label("Load Settings").classes("text-lg font-semibold mb-2")

                def on_load_active_change(e):
                    load_config["active"] = e.value
                    mark_changed()

                load_active = load_config.get("active", True)

                ui.switch(
                    "Load active",
                    value=load_active,
                    on_change=on_load_active_change,
                ).tooltip(get_tip("load.active"))
                def on_delete_temp_files_change(e):
                    load_config["delete_temp_files"] = e.value
                    mark_changed()

                delete_temp_files_switch = ui.switch(
                    "Delete temp files",
                    value=load_config.get("delete_temp_files", True),
                    on_change=on_delete_temp_files_change,
                )
                delete_temp_files_switch.tooltip(get_tip("load.delete_temp_files"))


                def on_delete_projects_before_load_change(e):
                    load_config["delete_projects_before_load"] = e.value
                    mark_changed()

                delete_projects_before_load_switch = ui.switch(
                    "Delete projects before load",
                    value=load_config.get("delete_projects_before_load", True),
                    on_change=on_delete_projects_before_load_change,
                )
                delete_projects_before_load_switch.tooltip(get_tip("load.delete_projects_before_load"))


                def on_development_deficiency_mining_only_change(e):
                    load_config["development_deficiency_mining_only"] = e.value
                    mark_changed()

                development_deficiency_mining_only_switch = ui.switch(
                    "DEVELOPMENT: deficiency mining only",
                    value=load_config.get(
                        "development_deficiency_mining_only", False
                    ),
                    on_change=on_development_deficiency_mining_only_change,
                )
                development_deficiency_mining_only_switch.tooltip(get_tip("load.development_deficiency_mining_only"))

                def on_development_load_reports_only_change(e):
                    load_config["development_load_reports_only"] = e.value
                    mark_changed()

                development_load_reports_only_switch = ui.switch(
                    "DEVELOPMENT: load reports only",
                    value=load_config.get(
                        "development_load_reports_only", False
                    ),
                    on_change=on_development_load_reports_only_change,
                )
                development_load_reports_only_switch.tooltip(get_tip("load.development_load_reports_only"))

                def on_nemo_project_prefix_change(e):
                    load_config["nemo_project_prefix"] = e.value
                    mark_changed()

                nemo_project_prefix_input = (
                    ui.input(
                        label="NEMO project prefix",
                        value=load_config.get("nemo_project_prefix", "mml"),
                        placeholder="",
                        on_change=on_nemo_project_prefix_change,
                    )
                    .props("dense")
                    .classes("w-[36rem] mt-3")
                    .tooltip(get_tip("load.nemo_project_prefix"))
                )
                # NEMO project prefix field is always enabled (sensitive field)
    render_load()
