"""Miscellaneous helper functions for the elliptec package."""
from __future__ import annotations

import logging

from .errcodes import error_codes

logger = logging.getLogger(__name__)

# A parsed status is either a dict (for info responses) or a tuple of (address, code, value).
Status = dict[str, object] | tuple[str, str, int | str]


def is_null_or_empty(msg: bytes) -> bool:
    """Checks if message is empty or null."""
    return not msg.endswith(b"\r\n") or len(msg) == 0


def parse(msg: bytes, debug: bool = True) -> Status | None:
    """Parses the message from the controller."""
    if is_null_or_empty(msg):
        if debug:
            logger.warning("Parse: Status/Response may be incomplete!")
            logger.warning("Parse: Message: %s", msg)
        return None
    msg = msg.decode().strip()
    code = msg[1:3]
    try:
        _ = int(msg[0], 16)
    except ValueError as exc:
        raise ValueError(f"Invalid Address: {msg[0]}.") from exc
    addr = msg[0]

    if code.upper() == "IN":
        info = {
            "Address": addr,
            "Motor Type": int(msg[3:5], 16),
            "Serial No.": msg[5:13],
            "Year": msg[13:17],
            "Firmware": msg[17:19],
            "Thread": is_metric(msg[19]),
            "Hardware": msg[20],
            "Range": (int(msg[21:25], 16)),
            "Pulse/Rev": (int(msg[25:], 16)),
        }
        return info

    elif code.upper() in ["PO", "BO", "HO", "GJ"]:
        pos = msg[3:]
        return (addr, code, (s32(int(pos, 16))))

    elif code.upper() == "GS":
        errcode = msg[3:]
        return (addr, code, str(int(errcode, 16)))

    elif code.upper() in ["I1", "I2"]:
        # Info about motor

        # Period=14740000/frequency for backward and forward motor movements
        # And 1 Amp of current is equal to 1866 points (1 point is 0.54 mA circa)

        info = {
            "Address": addr,
            "Loop": msg[3],  # The state of the loop setting (1 = ON, 0 = OFF)
            "Motor": msg[4],  # The state of the motor (1 = ON, 0 = OFF)
            "Current": int(msg[5:9], 16) / 1866,  # 1866 points is 1 amp
            "Ramp up": int(msg[9:13], 16),  # PWM increase every ms
            "Ramp down": int(msg[13:17], 16),  # PWM decrease every ms
            "Forward period": int(msg[17:21], 16),  # Forward period value
            "Backward period": int(msg[21:25], 16),  # Backward period value
            "Forward frequency": 14740000 / int(msg[17:21], 16),  # Calculated forward frequency
            "Backward frequency": 14740000 / int(msg[21:25], 16),  # Calculated forward frequency
        }
        return info

    else:
        return (addr, code, msg[3:])


def is_metric(num: str) -> str | None:
    """Checks if thread is metric or imperial."""
    return {"0": "Metric", "1": "Imperial"}.get(num)


def s32(value: int) -> int:
    """Convert 32bit signed hex to int."""
    return -(value & 0x80000000) | (value & 0x7FFFFFFF)


def error_check(status: Status | None) -> None:
    """Checks if there is an error."""
    if not status:
        logger.warning("Status is None")
    elif isinstance(status, dict):
        logger.warning("Status is a dictionary.")
    elif status[1] == "GS":
        if status[2] != "0":  # is there an error?
            err = error_codes[status[2]]
            logger.error("ERROR: %s", err)
        else:
            logger.debug("Status OK")
    elif status[1] == "PO":
        logger.debug("Status OK (position)")
    else:
        logger.warning("Other status: %s", status)


def move_check(status: Status | None) -> None:
    """Checks if the move was successful."""
    if not status:
        logger.warning("Status is None")
    elif status[1] == "GS":
        error_check(status)
    elif (status[1] == "PO") or (status[1] == "BO"):
        logger.debug("Move Successful.")
    else:
        logger.warning("Unknown response code %s", status[1])
