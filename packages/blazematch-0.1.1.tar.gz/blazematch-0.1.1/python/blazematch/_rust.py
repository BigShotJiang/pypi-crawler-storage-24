try:
    from blazematch._blazematch_rs import (
        compute_feature_matrix,
        cosine_batch,
        damerau_levenshtein_batch,
        exact_match_batch,
        jaccard_batch,
        jaro_winkler_batch,
        levenshtein_batch,
        numeric_distance_batch,
        numeric_similarity_batch,
        predict_batch,
        predict_forest_batch,
        predict_gbdt_batch,
        predict_svm_batch,
        soundex_batch,
        token_sort_ratio_batch,
    )
except ImportError as e:
    raise ImportError(
        "blazematch native extension not found. "
        "Install with: pip install blazematch (or maturin develop for dev)"
    ) from e

__all__ = [
    "jaro_winkler_batch",
    "levenshtein_batch",
    "damerau_levenshtein_batch",
    "exact_match_batch",
    "numeric_distance_batch",
    "numeric_similarity_batch",
    "soundex_batch",
    "jaccard_batch",
    "cosine_batch",
    "token_sort_ratio_batch",
    "compute_feature_matrix",
    "predict_batch",
    "predict_forest_batch",
    "predict_gbdt_batch",
    "predict_svm_batch",
]
