from blazematch.blocking import EmbeddingBlocker, RuleBlocker
from blazematch.clustering import DBSCANModel, GMMModel, KMeansModel
from blazematch.config import (
    BlockingRule,
    ComparisonLevel,
    EmbeddingBlockingConfig,
    FieldComparison,
    LinkConfig,
    Metric,
)
from blazematch.dedup import Deduplicator
from blazematch.estimate_ram import RAMEstimate, estimate_ram
from blazematch.fellegi_sunter import ComparisonLevels, FellegiSunterModel
from blazematch.linker import Linker
from blazematch.model import (
    GradientBoostingModel,
    LightGBMModel,
    MatchModel,
    RandomForestModel,
    SVMModel,
    XGBoostModel,
)
from blazematch.preprocess import (
    apply_preprocess,
    lowercase,
    normalize_unicode,
    remove_punctuation,
    strip_whitespace,
)
from blazematch.visualize import (
    plot_comparison_heatmap,
    plot_comparison_viewer,
    plot_match_weights,
    plot_precision_recall,
    plot_roc,
    plot_score_distribution,
    plot_threshold_analysis,
    plot_waterfall,
)

__version__ = "0.1.0"

__all__ = [
    # Core
    "Linker",
    "Deduplicator",
    "LinkConfig",
    "FieldComparison",
    "BlockingRule",
    "Metric",
    # Blocking
    "EmbeddingBlocker",
    "RuleBlocker",
    "EmbeddingBlockingConfig",
    # Supervised models
    "MatchModel",
    "RandomForestModel",
    "GradientBoostingModel",
    "SVMModel",
    "XGBoostModel",
    "LightGBMModel",
    # Unsupervised models
    "FellegiSunterModel",
    "ComparisonLevels",
    "ComparisonLevel",
    "KMeansModel",
    "GMMModel",
    "DBSCANModel",
    # Utilities
    "estimate_ram",
    "RAMEstimate",
    # Preprocessing
    "apply_preprocess",
    "lowercase",
    "strip_whitespace",
    "remove_punctuation",
    "normalize_unicode",
    # Visualization
    "plot_score_distribution",
    "plot_waterfall",
    "plot_comparison_heatmap",
    "plot_precision_recall",
    "plot_roc",
    "plot_threshold_analysis",
    "plot_match_weights",
    "plot_comparison_viewer",
]
