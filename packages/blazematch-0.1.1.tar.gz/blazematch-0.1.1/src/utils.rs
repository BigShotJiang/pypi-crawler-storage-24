/// Sigmoid function: 1 / (1 + exp(-x))
#[inline]
pub fn sigmoid(x: f64) -> f64 {
    1.0 / (1.0 + (-x).exp())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_sigmoid_zero() {
        assert!((sigmoid(0.0) - 0.5).abs() < 1e-10);
    }

    #[test]
    fn test_sigmoid_large_positive() {
        assert!((sigmoid(100.0) - 1.0).abs() < 1e-10);
    }

    #[test]
    fn test_sigmoid_large_negative() {
        assert!(sigmoid(-100.0) < 1e-10);
    }
}
