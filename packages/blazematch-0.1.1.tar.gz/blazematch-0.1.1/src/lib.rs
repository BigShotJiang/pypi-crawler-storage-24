use pyo3::prelude::*;

mod features;
mod inference;
pub mod similarity;
mod svm_inference;
mod tree_inference;
mod utils;

#[pymodule]
fn _blazematch_rs(m: &Bound<'_, PyModule>) -> PyResult<()> {
    // Similarity functions
    m.add_function(wrap_pyfunction!(similarity::jaro_winkler_batch, m)?)?;
    m.add_function(wrap_pyfunction!(similarity::levenshtein_batch, m)?)?;
    m.add_function(wrap_pyfunction!(similarity::damerau_levenshtein_batch, m)?)?;
    m.add_function(wrap_pyfunction!(similarity::exact_match_batch, m)?)?;
    m.add_function(wrap_pyfunction!(similarity::numeric_distance_batch, m)?)?;
    m.add_function(wrap_pyfunction!(similarity::numeric_similarity_batch, m)?)?;
    m.add_function(wrap_pyfunction!(similarity::soundex_batch, m)?)?;
    m.add_function(wrap_pyfunction!(similarity::jaccard_batch, m)?)?;
    m.add_function(wrap_pyfunction!(similarity::cosine_batch, m)?)?;
    m.add_function(wrap_pyfunction!(similarity::token_sort_ratio_batch, m)?)?;

    // Feature matrix computation
    m.add_function(wrap_pyfunction!(features::compute_feature_matrix, m)?)?;

    // Logistic regression inference
    m.add_function(wrap_pyfunction!(inference::predict_batch, m)?)?;

    // Tree-based model inference
    m.add_function(wrap_pyfunction!(tree_inference::predict_forest_batch, m)?)?;
    m.add_function(wrap_pyfunction!(tree_inference::predict_gbdt_batch, m)?)?;

    // SVM inference
    m.add_function(wrap_pyfunction!(svm_inference::predict_svm_batch, m)?)?;

    Ok(())
}
