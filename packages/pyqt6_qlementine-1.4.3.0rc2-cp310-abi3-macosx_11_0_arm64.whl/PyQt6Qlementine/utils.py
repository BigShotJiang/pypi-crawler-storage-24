"""Qlementine utility functions."""


def _init():
    from . import _qlementine as _ql

    ns = globals()
    for name in dir(_ql):
        if name.startswith('_'):
            continue
        obj = getattr(_ql, name)
        if isinstance(obj, type):
            continue
        ns[name] = obj


_init()
del _init
