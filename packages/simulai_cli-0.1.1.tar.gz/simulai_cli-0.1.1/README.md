# Simul AI CLI

The official command-line interface for [Simul AI](https://trysimulai.com) — Nigeria's AI gateway with Naira billing.

## Installation

```bash
pip install simulai-cli
```

## Quick Start

```bash
# Configure with your API key
simulai setup

# List available models
simulai models

# Chat with any model
simulai chat "What is the capital of Nigeria?"

# Chat with a specific model
simulai chat "Explain quantum computing" --model openai/gpt-4o

# Analyze a file
simulai analyze mycode.py --instruction "Find all bugs"

# Check wallet balance
simulai wallet
```

## Features

- Chat with 20+ AI models including GPT-4o, Claude, Gemini, DeepSeek
- Naira billing — pay in ₦, no dollar card needed
- File analysis — code, CSV, PDF, DOCX
- Real-time streaming responses
- Wallet management

## Links

- Website: [trysimulai.com](https://trysimulai.com)
- Dashboard: [app.trysimulai.com](https://trysimulai.com)