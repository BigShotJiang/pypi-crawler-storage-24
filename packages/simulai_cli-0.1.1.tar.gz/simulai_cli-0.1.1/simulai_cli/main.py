"""
Simul AI CLI — Chat with 20+ AI models from your terminal.
Nigerian AI gateway with Naira billing.

Usage:
    simulai setup                                    # configure API key
    simulai chat "your message"                      # chat with default model
    simulai chat "your message" --model openai/gpt-4o
    simulai analyze myfile.py                        # analyze a file
    simulai analyze myfile.py --output result.md     # save output to file
    simulai analyze myfile.py --edit                 # edit file in place
    simulai models                                   # list available models
    simulai wallet                                   # check balance
"""

import json
import os
import sys
import httpx
import typer
from pathlib import Path
from typing import Optional
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.prompt import Prompt, Confirm
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.syntax import Syntax
from rich.markdown import Markdown
from rich import print as rprint

app = typer.Typer(
    name="simulai",
    help="[bold green]Simul AI[/bold green] — Nigerian AI gateway. Chat with 20+ models, Naira billing.",
    rich_markup_mode="rich",
    no_args_is_help=True,
)
console = Console()

# ── Config ────────────────────────────────────────────────────────────────────

CONFIG_DIR = Path.home() / ".simulai"
CONFIG_FILE = CONFIG_DIR / "config.json"

DEFAULT_CONFIG = {
    "api_url": "https://api.trysimulai.com",
    "api_key": "",
    "default_model": "openai/gpt-4o-mini",
}


def load_config() -> dict:
    if CONFIG_FILE.exists():
        try:
            return json.loads(CONFIG_FILE.read_text())
        except Exception:
            pass
    return DEFAULT_CONFIG.copy()


def save_config(config: dict):
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(config, indent=2))


def get_config() -> dict:
    config = load_config()
    if not config.get("api_key"):
        console.print("\n[red]❌ API key not configured.[/red]")
        console.print("Run [bold cyan]simulai setup[/bold cyan] first.\n")
        raise typer.Exit(1)
    return config


# ── Helper: API call ──────────────────────────────────────────────────────────


def api_get(url: str, api_key: str) -> dict:
    try:
        r = httpx.get(url, headers={"Authorization": f"Bearer {api_key}"}, timeout=30)
        r.raise_for_status()
        return r.json()
    except httpx.HTTPStatusError as e:
        err = e.response.json() if e.response.content else {}
        msg = err.get("detail", {})
        if isinstance(msg, dict):
            msg = msg.get("message", str(e))
        console.print(f"\n[red]❌ Error: {msg}[/red]\n")
        raise typer.Exit(1)
    except httpx.ConnectError:
        console.print(
            "\n[red]❌ Cannot connect to Simul AI API. Check your internet connection.[/red]\n"
        )
        raise typer.Exit(1)


def stream_chat(
    api_url: str,
    api_key: str,
    model: str,
    messages: list,
    max_tokens: Optional[int] = None,
) -> str:
    """Stream a chat completion and return the full response text."""
    payload = {
        "model": model,
        "messages": messages,
        "stream": True,
        "temperature": 0.7,
    }
    if max_tokens:
        payload["max_tokens"] = max_tokens

    full_response = ""
    try:
        with httpx.Client(timeout=300) as client:
            with client.stream(
                "POST",
                f"{api_url}/v1/chat/completions",
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json",
                },
                json=payload,
            ) as response:
                if response.status_code == 402:
                    console.print(
                        "\n[red]❌ Insufficient credits. Top up at https://trysimulai.com/billing[/red]\n"
                    )
                    raise typer.Exit(1)
                if response.status_code != 200:
                    console.print(
                        f"\n[red]❌ API error: {response.status_code}[/red]\n"
                    )
                    raise typer.Exit(1)

                for line in response.iter_lines():
                    if not line or not line.startswith("data: "):
                        continue
                    data = line[6:]
                    if data == "[DONE]":
                        break
                    try:
                        chunk = json.loads(data)
                        delta = chunk.get("choices", [{}])[0].get("delta", {})
                        text = delta.get("content", "")
                        if text:
                            console.print(text, end="", highlight=False)
                            full_response += text
                    except (json.JSONDecodeError, IndexError, KeyError):
                        continue

    except httpx.ConnectError:
        console.print("\n[red]❌ Cannot connect to Simul AI API.[/red]\n")
        raise typer.Exit(1)

    return full_response


def pick_model(config: dict) -> str:
    """Interactively pick a model from the list."""
    api_url = config["api_url"]
    api_key = config["api_key"]

    with console.status("[cyan]Fetching models...[/cyan]"):
        try:
            r = httpx.get(f"{api_url}/v1/models", timeout=15)
            models = r.json()
        except Exception:
            console.print("[red]Could not fetch models.[/red]")
            raise typer.Exit(1)

    # Group by category
    categories = {}
    for m in models:
        cat = m.get("category", "other")
        categories.setdefault(cat, []).append(m)

    console.print("\n[bold]Available models:[/bold]\n")
    all_models = []
    idx = 1
    for cat, cat_models in categories.items():
        console.print(f"[bold yellow]  {cat.upper()}[/bold yellow]")
        for m in cat_models:
            cost = f"₦{m['input_cost_per_1k']}/₦{m['output_cost_per_1k']} per 1k tokens"
            console.print(
                f"  [cyan]{idx}[/cyan]. {m['name']} [dim]({m['model_id']}) — {cost}[/dim]"
            )
            all_models.append(m)
            idx += 1

    console.print()
    choice = Prompt.ask(
        "Select model number",
        default="1",
    )
    try:
        selected = all_models[int(choice) - 1]
        return selected["model_id"]
    except (ValueError, IndexError):
        console.print("[red]Invalid selection.[/red]")
        raise typer.Exit(1)


def detect_output_format(output_path: str) -> str:
    ext = Path(output_path).suffix.lower()
    formats = {
        ".md": "markdown",
        ".txt": "text",
        ".json": "json",
        ".html": "html",
        ".py": "python",
        ".js": "javascript",
        ".ts": "typescript",
        ".csv": "csv",
        ".xlsx": "excel",
    }
    return formats.get(ext, "text")


def save_output(content: str, output_path: str, fmt: str):
    """Save AI response to file in the requested format."""
    path = Path(output_path)

    if fmt == "excel":
        try:
            import openpyxl

            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = "Simul AI Output"
            for i, line in enumerate(content.split("\n"), 1):
                ws.cell(row=i, column=1, value=line)
            wb.save(str(path))
        except ImportError:
            console.print(
                "[yellow]⚠ openpyxl not installed. Saving as text instead.[/yellow]"
            )
            path = path.with_suffix(".txt")
            path.write_text(content, encoding="utf-8")
    elif fmt == "json":
        try:
            # Try to parse as JSON first
            parsed = json.loads(content)
            path.write_text(json.dumps(parsed, indent=2), encoding="utf-8")
        except json.JSONDecodeError:
            # Wrap in JSON if not valid JSON
            path.write_text(
                json.dumps({"response": content}, indent=2), encoding="utf-8"
            )
    elif fmt == "html":
        html = f"""<!DOCTYPE html>
<html>
<head><meta charset="utf-8"><title>Simul AI Output</title>
<style>body{{font-family:sans-serif;max-width:800px;margin:40px auto;padding:0 20px;line-height:1.6}}
pre{{background:#f4f4f4;padding:16px;border-radius:8px;overflow-x:auto}}</style>
</head>
<body><pre>{content}</pre></body>
</html>"""
        path.write_text(html, encoding="utf-8")
    else:
        path.write_text(content, encoding="utf-8")


# ── Commands ──────────────────────────────────────────────────────────────────


@app.command()
def setup():
    """Configure your Simul AI API key and settings."""
    config = load_config()

    console.print(
        Panel.fit(
            "[bold green]Simul AI CLI Setup[/bold green]\n"
            "Get your API key from [cyan]https://trysimulai.com/dashboard/api-keys[/cyan]",
            border_style="green",
        )
    )

    api_url = Prompt.ask(
        "\nAPI URL", default=config.get("api_url", DEFAULT_CONFIG["api_url"])
    )

    api_key = Prompt.ask(
        "API Key (sk-ng-...)", password=True, default=config.get("api_key", "")
    )

    # Verify key works
    with console.status("[cyan]Verifying API key...[/cyan]"):
        try:
            r = httpx.get(
                f"{api_url}/v1/models",
                headers={"Authorization": f"Bearer {api_key}"},
                timeout=15,
            )
            if r.status_code == 200:
                models = r.json()
                console.print(
                    f"[green]✓ Connected! {len(models)} models available.[/green]"
                )
            else:
                console.print(
                    f"[yellow]⚠ Could not verify key (status {r.status_code}). Saving anyway.[/yellow]"
                )
        except Exception:
            console.print(
                "[yellow]⚠ Could not reach API. Saving config anyway.[/yellow]"
            )

    # Pick default model
    console.print("\n[bold]Set your default model:[/bold]")
    console.print("[dim]Press Enter to keep current default, or type a model ID[/dim]")
    default_model = Prompt.ask(
        "Default model",
        default=config.get("default_model", DEFAULT_CONFIG["default_model"]),
    )

    config.update(
        {
            "api_url": api_url.rstrip("/"),
            "api_key": api_key,
            "default_model": default_model,
        }
    )
    save_config(config)

    console.print(f"\n[green]✓ Config saved to {CONFIG_FILE}[/green]")
    console.print("\nYou're ready! Try:")
    console.print('  [cyan]simulai chat "Hello, what can you do?"[/cyan]')
    console.print("  [cyan]simulai models[/cyan]")
    console.print("  [cyan]simulai wallet[/cyan]\n")


@app.command()
def chat(
    message: str = typer.Argument(..., help="Your message to the AI"),
    model: Optional[str] = typer.Option(None, "--model", "-m", help="Model ID to use"),
    system: Optional[str] = typer.Option(None, "--system", "-s", help="System prompt"),
    select: bool = typer.Option(False, "--select", help="Interactively select a model"),
    max_tokens: Optional[int] = typer.Option(
        None, "--max-tokens", help="Max tokens in response"
    ),
):
    """Chat with any AI model. Streams response in real time."""
    config = get_config()

    # Model selection
    if select:
        model_id = pick_model(config)
    elif model:
        model_id = model
    else:
        model_id = config.get("default_model", DEFAULT_CONFIG["default_model"])

    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": message})

    console.print(f"\n[dim]Model: {model_id}[/dim]\n")
    console.print("[bold green]●[/bold green] ", end="")

    response = stream_chat(
        api_url=config["api_url"],
        api_key=config["api_key"],
        model=model_id,
        messages=messages,
        max_tokens=max_tokens,
    )

    console.print("\n")


@app.command()
def analyze(
    file: str = typer.Argument(..., help="Path to file to analyze"),
    instruction: Optional[str] = typer.Option(
        None, "--instruction", "-i", help="What to do with the file"
    ),
    model: Optional[str] = typer.Option(None, "--model", "-m", help="Model to use"),
    output: Optional[str] = typer.Option(
        None, "--output", "-o", help="Save result to file (e.g. result.md, result.xlsx)"
    ),
    edit: bool = typer.Option(
        False, "--edit", "-e", help="Apply AI changes back to the original file"
    ),
    select: bool = typer.Option(False, "--select", help="Interactively select a model"),
    max_tokens: Optional[int] = typer.Option(
        None, "--max-tokens", help="Max tokens in response"
    ),
):
    """
    Analyze any file with AI. Supports code, CSV, Excel, PDF, TXT, DOCX.

    Examples:

        simulai analyze mycode.py --instruction "Find all bugs"

        simulai analyze data.csv --output report.xlsx --instruction "Summarize this data"

        simulai analyze script.py --edit --instruction "Fix all bugs and add docstrings"

        simulai analyze report.pdf --output summary.md
    """
    config = get_config()
    file_path = Path(file)

    if not file_path.exists():
        console.print(f"\n[red]❌ File not found: {file}[/red]\n")
        raise typer.Exit(1)

    # Default instruction based on file type
    if not instruction:
        ext = file_path.suffix.lower()
        defaults = {
            ".py": "Review this Python code. Find bugs, suggest improvements, and explain what it does.",
            ".js": "Review this JavaScript code. Find bugs and suggest improvements.",
            ".ts": "Review this TypeScript code. Find bugs and suggest improvements.",
            ".csv": "Analyze this data. Identify patterns, anomalies, and provide a summary.",
            ".xlsx": "Analyze this spreadsheet data. Identify patterns and provide insights.",
            ".pdf": "Summarize this document. Extract key points and important information.",
            ".txt": "Summarize this text and extract the key points.",
            ".md": "Review and improve this markdown document.",
            ".sql": "Review this SQL. Identify issues, optimize queries, and explain what it does.",
            ".json": "Analyze this JSON data and explain its structure and contents.",
        }
        instruction = defaults.get(
            ext, "Analyze this file and provide a detailed summary."
        )
        console.print(f"[dim]Using default instruction: {instruction}[/dim]")

    # Model selection
    if select:
        model_id = pick_model(config)
    elif model:
        model_id = model
    else:
        model_id = config.get("default_model", DEFAULT_CONFIG["default_model"])

    # Read file content
    with console.status(f"[cyan]Reading {file_path.name}...[/cyan]"):
        try:
            ext = file_path.suffix.lower()
            if ext in {".xlsx", ".xls"}:
                import openpyxl

                wb = openpyxl.load_workbook(str(file_path), read_only=True)
                lines = []
                for sheet in wb.worksheets:
                    lines.append(f"=== Sheet: {sheet.title} ===")
                    for row in sheet.iter_rows(values_only=True):
                        lines.append(
                            "\t".join(str(c) if c is not None else "" for c in row)
                        )
                file_content = "\n".join(lines)
            elif ext == ".pdf":
                import pypdf

                reader = pypdf.PdfReader(str(file_path))
                file_content = "\n".join(
                    page.extract_text() or "" for page in reader.pages
                )
            elif ext == ".docx":
                import docx

                doc = docx.Document(str(file_path))
                file_content = "\n".join(p.text for p in doc.paragraphs)
            else:
                file_content = file_path.read_text(encoding="utf-8", errors="replace")
        except Exception as e:
            console.print(f"\n[red]❌ Could not read file: {e}[/red]\n")
            raise typer.Exit(1)

    file_size_kb = file_path.stat().st_size / 1024
    console.print(
        f"\n[dim]File: {file_path.name} ({file_size_kb:.1f} KB) | Model: {model_id}[/dim]\n"
    )
    console.print(f"[bold cyan]📋 Instruction:[/bold cyan] {instruction}\n")
    console.print("[bold green]●[/bold green] ", end="")

    # Build prompt
    messages = [
        {
            "role": "system",
            "content": (
                "You are an expert AI assistant analyzing files. "
                "Be thorough, specific, and actionable. "
                "When editing code, return the complete updated file content."
            ),
        },
        {
            "role": "user",
            "content": f"File: {file_path.name}\n\n```\n{file_content}\n```\n\n{instruction}",
        },
    ]

    # Stream response
    ai_response = stream_chat(
        api_url=config["api_url"],
        api_key=config["api_key"],
        model=model_id,
        messages=messages,
        max_tokens=max_tokens,
    )

    console.print()

    # Handle output options
    if output:
        output_path = Path(output)
        fmt = detect_output_format(output)
        save_output(ai_response, str(output_path), fmt)
        console.print(f"\n[green]✓ Output saved to: {output_path.resolve()}[/green]\n")

    elif edit:
        console.print(
            f"\n[yellow]⚠ This will overwrite: {file_path.resolve()}[/yellow]"
        )
        confirmed = Confirm.ask("Apply AI changes to the original file?")
        if confirmed:
            # Extract code block if present
            content_to_write = ai_response
            if "```" in ai_response:
                lines = ai_response.split("\n")
                code_lines = []
                in_code = False
                for line in lines:
                    if line.startswith("```") and not in_code:
                        in_code = True
                        continue
                    elif line.startswith("```") and in_code:
                        in_code = False
                        continue
                    if in_code:
                        code_lines.append(line)
                if code_lines:
                    content_to_write = "\n".join(code_lines)

            # Backup original
            backup_path = file_path.with_suffix(file_path.suffix + ".bak")
            file_path.rename(backup_path)
            console.print(f"[dim]Backup saved to: {backup_path}[/dim]")

            file_path.write_text(content_to_write, encoding="utf-8")
            console.print(f"[green]✓ File updated: {file_path.resolve()}[/green]\n")
        else:
            console.print("[dim]Edit cancelled.[/dim]\n")


@app.command()
def models():
    """List all available AI models with pricing."""
    config = get_config()

    with console.status("[cyan]Fetching models...[/cyan]"):
        data = api_get(f"{config['api_url']}/v1/models", config["api_key"])

    if not data:
        console.print("[yellow]No models available.[/yellow]")
        return

    # Group by category
    categories = {}
    for m in data:
        cat = m.get("category", "other")
        categories.setdefault(cat, []).append(m)

    console.print()
    for cat, cat_models in categories.items():
        table = Table(
            title=f"[bold]{cat.upper()}[/bold]",
            show_header=True,
            header_style="bold cyan",
            border_style="dim",
            expand=True,
        )
        table.add_column("Model", style="white", min_width=20)
        table.add_column("ID", style="dim", min_width=25)
        table.add_column("Provider", style="cyan", min_width=10)
        table.add_column("Input/1k", style="green", justify="right")
        table.add_column("Output/1k", style="green", justify="right")
        table.add_column("Context", style="dim", justify="right")
        table.add_column("Vision", justify="center")
        table.add_column("Files", justify="center")

        for m in cat_models:
            ctx = m.get("context_window")
            ctx_str = f"{ctx // 1000}K" if ctx else "—"
            table.add_row(
                m["name"],
                m["model_id"],
                m["provider"],
                f"₦{m['input_cost_per_1k']}",
                f"₦{m['output_cost_per_1k']}",
                ctx_str,
                "✓" if m.get("supports_vision") else "—",
                "✓" if m.get("supports_files") else "—",
            )

        console.print(table)
        console.print()

    current_default = config.get("default_model", DEFAULT_CONFIG["default_model"])
    console.print(f"[dim]Current default: {current_default}[/dim]")
    console.print(f"[dim]Change with: simulai setup[/dim]\n")


@app.command()
def wallet():
    """Check your credit balance and recent transactions."""
    config = get_config()

    with console.status("[cyan]Fetching wallet...[/cyan]"):
        balance = api_get(f"{config['api_url']}/billing/wallet", config["api_key"])
        transactions = api_get(
            f"{config['api_url']}/billing/transactions", config["api_key"]
        )

    # Balance panel
    total = balance.get("total_credits", 0)
    sub = balance.get("subscription_credits", 0)
    topup = balance.get("topup_credits", 0)
    spent = balance.get("total_spent", 0)

    color = "green" if total > 100 else "yellow" if total > 10 else "red"
    console.print(
        Panel(
            f"[bold {color}]{total:,} credits[/bold {color}]\n\n"
            f"  Subscription:  [cyan]{sub:,}[/cyan]\n"
            f"  Top-up:        [cyan]{topup:,}[/cyan]\n"
            f"  Total spent:   [dim]{spent:,}[/dim]",
            title="[bold]💳 Wallet Balance[/bold]",
            border_style=color,
            expand=False,
        )
    )

    if total < 50:
        console.print(
            f"[yellow]⚠ Low balance. Top up at: {config['api_url'].replace('api.', '')}[/yellow]"
        )

    # Transactions table
    if transactions:
        console.print()
        table = Table(
            title="Recent Transactions",
            show_header=True,
            header_style="bold cyan",
            border_style="dim",
        )
        table.add_column("Type", min_width=8)
        table.add_column("Amount", justify="right", min_width=10)
        table.add_column("Balance After", justify="right", min_width=12)
        table.add_column("Description", min_width=30)
        table.add_column("Date", min_width=12)

        for t in transactions[:10]:
            tx_type = t.get("type", "")
            amount = t.get("amount", 0)
            color = (
                "green"
                if tx_type == "credit"
                else "red" if tx_type == "debit" else "yellow"
            )
            sign = "+" if tx_type in ("credit", "refund") else "-"
            date_str = t.get("created_at", "")[:10]

            table.add_row(
                f"[{color}]{tx_type}[/{color}]",
                f"[{color}]{sign}{amount:,}[/{color}]",
                f"{t.get('balance_after', 0):,}",
                t.get("description", "")[:45],
                date_str,
            )

        console.print(table)
    console.print()


@app.command()
def version():
    """Show Simul AI CLI version."""
    console.print("[bold green]Simul AI CLI[/bold green] v0.1.0")
    console.print("Nigerian AI gateway — [cyan]https://trysimulai.com[/cyan]")


if __name__ == "__main__":
    app()
