# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class StacksConfig:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'attributes': 'StacksAttribute',
        'recipe': 'Recipe'
    }

    attribute_map = {
        'attributes': 'attributes',
        'recipe': 'recipe'
    }

    def __init__(self, attributes=None, recipe=None):
        r"""StacksConfig

        The model defined in huaweicloud sdk

        :param attributes: 
        :type attributes: :class:`huaweicloudsdkcloudide.v2.StacksAttribute`
        :param recipe: 
        :type recipe: :class:`huaweicloudsdkcloudide.v2.Recipe`
        """
        
        

        self._attributes = None
        self._recipe = None
        self.discriminator = None

        if attributes is not None:
            self.attributes = attributes
        if recipe is not None:
            self.recipe = recipe

    @property
    def attributes(self):
        r"""Gets the attributes of this StacksConfig.

        :return: The attributes of this StacksConfig.
        :rtype: :class:`huaweicloudsdkcloudide.v2.StacksAttribute`
        """
        return self._attributes

    @attributes.setter
    def attributes(self, attributes):
        r"""Sets the attributes of this StacksConfig.

        :param attributes: The attributes of this StacksConfig.
        :type attributes: :class:`huaweicloudsdkcloudide.v2.StacksAttribute`
        """
        self._attributes = attributes

    @property
    def recipe(self):
        r"""Gets the recipe of this StacksConfig.

        :return: The recipe of this StacksConfig.
        :rtype: :class:`huaweicloudsdkcloudide.v2.Recipe`
        """
        return self._recipe

    @recipe.setter
    def recipe(self, recipe):
        r"""Sets the recipe of this StacksConfig.

        :param recipe: The recipe of this StacksConfig.
        :type recipe: :class:`huaweicloudsdkcloudide.v2.Recipe`
        """
        self._recipe = recipe

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, StacksConfig):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
