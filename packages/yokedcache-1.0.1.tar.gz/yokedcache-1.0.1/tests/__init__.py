# Tests for YokedCache
