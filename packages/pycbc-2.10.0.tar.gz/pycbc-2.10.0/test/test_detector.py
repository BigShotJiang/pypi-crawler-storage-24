# Copyright (C) 2018 Alex Nitz
#
# This program is free software; you can redistribute it and/or modify it
# under the terms of the GNU General Public License as published by the
# Free Software Foundation; either version 3 of the License, or (at your
# option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
# Public License for more details.
#
# You should have received a copy of the GNU General Public License along
# with this program; if not, write to the Free Software Foundation, Inc.,
# 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

#
# =============================================================================
#
#                                   Preamble
#
# =============================================================================
#
"""
These are the unittests for the pycbc.detector module
"""

import pycbc.detector as det
import unittest, numpy
from numpy.random import uniform, seed
seed(0)

# We require lal as a reference comparison
import lal

from utils import simple_exit

class TestDetector(unittest.TestCase):
    def setUp(self):
        self.d = [det.Detector(ifo)
                  for ifo in det.get_available_detectors()]

        # not distributed sanely, but should provide some good coverage
        N = 1000
        self.ra = uniform(0, numpy.pi * 2, size=N)
        self.dec = uniform(-numpy.pi, numpy.pi, size=N)
        self.pol = uniform(0, numpy.pi * 2, size=N)
        self.time = uniform(1126000000.0, 1336096017.0, size=N)

    def test_light_time(self):
        for d1 in self.d:
            for d2 in self.d:
                t1 = lal.LightTravelTime(d1.lal(), d2.lal()) * 1e-9
                t2 = d1.light_travel_time_to_detector(d2)
                self.assertAlmostEqual(t1, t2, 7)

    def test_custom_detector(self):
        det.add_detector_on_earth("TEST", 1.3, 0.5, yangle=0, xaltitude=0.01)
        d = det.Detector("TEST")

        # Check that we can call the new detector response
        fp, fc = d.antenna_pattern(1.5, 1.0, 0, 1000000000)

        # Check it interacts with existing detectors
        d2 = det.Detector("H1")
        t1 = d2.light_travel_time_to_detector(d)

    def test_response_matrix(self):
        import lal
        for ifo in ['H1', 'L1', 'V1', 'K1', 'I1']:
            ref_resp = lal.cached_detector_by_prefix[ifo].response
            resp = det.Detector(ifo).response
            self.assertAlmostEqual((ref_resp - resp).max(), 0, places=6)

    def test_antenna_pattern(self):
        vals = list(zip(self.ra, self.dec, self.pol, self.time))
        for ifo in self.d:
            fp = []
            fc = []
            for ra1, dec1, pol1, time1 in vals:
                gmst = lal.GreenwichMeanSiderealTime(time1)
                fp1, fc1 = tuple(lal.ComputeDetAMResponse(ifo.response, ra1, dec1, pol1, gmst))
                fp.append(fp1)
                fc.append(fc1)

            fp2, fc2 = ifo.antenna_pattern(self.ra, self.dec, self.pol, self.time)

            fp = numpy.array(fp)
            fc = numpy.array(fc)

            diff1 = fp - fp2
            diff2 = fc - fc2
            diff = abs(numpy.concatenate([diff1, diff2]))
            tolerance = 2e-4
            print("Max antenna diff:", ifo.name, diff.max())

            self.assertLess(diff.max(), tolerance)

    def test_delay_from_detector(self):
        ra, dec, time = self.ra[0:10], self.dec[0:10], self.time[0:10]
        for d1 in self.d:
            for d2 in self.d:
                time1 = []
                for ra1, dec1, tim1 in zip(ra, dec, time):
                    t1 = lal.ArrivalTimeDiff(d1.location, d2.location,
                                             ra1, dec1, tim1)
                    time1.append(t1)
                time1 = numpy.array(time1)
                time2 = d1.time_delay_from_detector(d2, ra, dec, time)
                self.assertLess(abs(time1 - time2).max(), 1e-3)

    def test_optimal_orientation(self):
        for d1 in self.d:
            ra, dec = d1.optimal_orientation(self.time[0])
            ra1 = d1.longitude + lal.GreenwichMeanSiderealTime(self.time[0]) % (numpy.pi *2)
            dec1 = d1.latitude

            self.assertAlmostEqual(ra, ra1, 3)
            self.assertAlmostEqual(dec, dec1, 7)
            
    def test_det_tc_conversion(self):
        """Test that the convert_tc method functions properly. The same times
        should be returned in all frames regardless of the reference.
        """
        vals = list(zip(self.ra, self.dec, self.time))
        ref_frames = ['geocentric', 'H1', 'L1', 'V1']
        target_frames = ['H1', 'L1', 'V1']
        # convert the times from geocentric using time_delay_from_earth_center
        test_times = {'geocentric': self.time}
        for ifo in target_frames:
            d = det.Detector(ifo)
            det_times = []
            for ra1, dec1, time1 in vals:
                tc = time1 + d.time_delay_from_earth_center(ra1, dec1, time1)
                det_times.append(tc)
            test_times[ifo] = det_times
        # convert the nominal times to each of the other detectors
        for target_ifo in target_frames:
            # set up the target detector
            d = det.Detector(target_ifo)
            target_times = test_times[target_ifo]
            for ref_ifo in ref_frames:
                ref_times = test_times[ref_ifo]
                converted_times = []
                for i in range(len(vals)):
                    ra1, dec1, _ = vals[i]
                    ref_tc = ref_times[i]
                    # convert the reference time to the target detector
                    tc = d.arrival_time(ref_tc, ra1, dec1, ref_frame = ref_ifo)
                    converted_times.append(tc)
                # check that the times converted to target match nominal
                print(f"Testing conversion from {ref_ifo} to {target_ifo}")
                for i in range(len(converted_times)):
                    self.assertAlmostEqual(converted_times[i], target_times[i], 
                                           places=6)

suite = unittest.TestSuite()
suite.addTest(unittest.TestLoader().loadTestsFromTestCase(TestDetector))

if __name__ == '__main__':
    from astropy.utils import iers
    iers.conf.auto_download = False
    results = unittest.TextTestRunner(verbosity=2).run(suite)
    simple_exit(results)
