"""Backward-compatible exports for the QMSum benchmark contracts."""

from card_framework.benchmark.summarizer_critic.qmsum.config import *  # noqa: F403
