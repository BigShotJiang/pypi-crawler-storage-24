"""SPoRC-specific summarizer-critic benchmark entrypoints."""

from card_framework.benchmark.summarizer_critic.sporc.cli import main

__all__ = ["main"]
