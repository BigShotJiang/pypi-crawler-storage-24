"""Run the SPoRC summarizer-critic benchmark CLI."""

from card_framework.benchmark.summarizer_critic.sporc.cli import main


if __name__ == "__main__":
    raise SystemExit(main())
