"""Public entrypoints for real-dataset summarizer-critic benchmarks."""

from card_framework.benchmark.summarizer_critic.cli import main

__all__ = ["main"]
