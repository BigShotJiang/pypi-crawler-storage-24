"""QMSum-specific summarizer-critic benchmark package."""

from .cli import main

__all__ = ["main"]
