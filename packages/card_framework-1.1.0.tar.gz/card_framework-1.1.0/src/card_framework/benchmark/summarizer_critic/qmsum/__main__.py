"""Run the QMSum summarizer-critic benchmark CLI."""

from .cli import main


if __name__ == "__main__":
    raise SystemExit(main())
