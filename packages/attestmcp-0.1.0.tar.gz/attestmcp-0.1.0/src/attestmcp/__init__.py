"""AttestMCP: Continuous compliance evidence for AI agent memory."""

__version__ = "0.1.0"
