"""Prometheus metrics for AttestMCP proxy observability.

Four core metrics that must be monitored from Day 1:
- requests_proxied: total MCP requests forwarded
- audit_records_written: total records appended to the chain
- chain_verification_failures: any chain integrity check failures
- upstream_latency: round-trip time to the memory server
"""

from __future__ import annotations

from prometheus_client import Counter, Histogram

requests_proxied = Counter(
    "attestmcp_requests_proxied_total",
    "Total MCP requests proxied to upstream",
    ["method"],
)

audit_records_written = Counter(
    "attestmcp_audit_records_written_total",
    "Total audit records appended to the chain",
    ["policy_decision"],
)

chain_verification_failures = Counter(
    "attestmcp_chain_verification_failures_total",
    "Number of chain integrity verification failures detected",
)

upstream_latency = Histogram(
    "attestmcp_upstream_latency_seconds",
    "Round-trip latency to upstream memory server",
    buckets=[0.001, 0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 0.5, 1.0],
)
