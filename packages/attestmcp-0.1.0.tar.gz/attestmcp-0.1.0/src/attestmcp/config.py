"""Configuration for AttestMCP proxy.

All configuration is via environment variables, following 12-factor principles.
"""

from __future__ import annotations

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """AttestMCP configuration, loaded from environment variables."""

    model_config = {"env_prefix": "ATTESTMCP_"}

    # Upstream memory server
    upstream_url: str = "http://localhost:8000/mcp"

    # Proxy server
    host: str = "0.0.0.0"  # noqa: S104 — proxy must bind to all interfaces
    port: int = 9090

    # Audit store
    db_path: str = "attestmcp_audit.db"

    # Identity / JWT
    jwks_url: str | None = None
    jwt_audience: str | None = None
    jwt_issuer: str | None = None

    # Metrics (served at GET /metrics on the proxy port)
    metrics_enabled: bool = True
