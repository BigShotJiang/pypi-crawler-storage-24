# Release Process (Local)

This project uses [Commitizen](https://commitizen-tools.github.io/commitizen/) for automated versioning and [twine](https://twine.readthedocs.io/) for publishing to PyPI.

## 1. Prerequisites

Ensure you have the necessary tools installed:
```bash
pip install commitizen build twine
```

You will also need a **PyPI API Token**. Create one at [pypi.org/manage/account/token/](https://pypi.org/manage/account/token/).

## 2. Release Steps

1.  **Switch to main and pull latest changes:**
    ```bash
    git checkout main
    git pull origin main
    ```

2.  **Generate the version bump and changelog:**
    ```bash
    # Review what will happen
    cz bump --dry-run

    # Perform the bump (updates pyproject.toml and CHANGELOG.md, creates a local tag)
    cz bump
    ```

3.  **Build the package:**
    ```bash
    # Clean previous builds
    rm -rf dist/ build/ *.egg-info

    # Build sdist and wheel
    python -m build
    ```

4.  **Publish to PyPI:**
    ```bash
    # Use your PyPI API token for password (username should be __token__)
    twine upload dist/*
    ```

5.  **Push changes and tags to GitLab:**
    ```bash
    git push origin main --tags
    ```

## 3. Alternative: Using `.pypirc`

To avoid entering your token every time, you can create a `~/.pypirc` file:

```ini
[distutils]
index-servers =
    pypi

[pypi]
username = __token__
password = pypi-your-api-token-here
```

Then you can simply run:
```bash
twine upload dist/*
```
