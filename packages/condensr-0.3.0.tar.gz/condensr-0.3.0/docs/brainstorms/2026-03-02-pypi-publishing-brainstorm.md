---
date: 2026-03-02
topic: pypi-publishing-and-versioning
---

# PyPi Publishing and Automated Versioning

## What We're Building
A fully automated CI/CD pipeline in GitLab to build and publish the `condensr` package to PyPi. The system will use Git tags (e.g., `v0.1.1`) as the single source of truth for versioning, eliminating the need to manually update version strings in the source code.

## Why This Approach
We chose **Approach A (setuptools-scm)** because it aligns with the "Don't Repeat Yourself" (DRY) principle. By deriving the package version directly from Git tags, we ensure that the published artifact always matches the repository state without requiring "version bump" commits. This modern approach is highly recommended for Python projects using `pyproject.toml`.

## Key Decisions
- **Versioning Strategy**: Use `setuptools-scm` to dynamically generate version numbers from Git tags.
- **Build System**: Stick with the existing `pyproject.toml` (setuptools backend); no `setup.py` will be added.
- **CI/CD Platform**: GitLab CI (using the existing `.gitlab-ci.yml`).
- **Trigger**: Automated publishing will occur only when a new Git tag (matching a pattern like `v*`) is pushed to the repository.
- **Credentials**: Set up GitLab as a "Trusted Publisher" (OIDC) on PyPi (no long-lived secrets to manage).
- **Testing**: No TestPyPi stage; publish directly to the live PyPi index.
- **Changelog**: Use `changelogfromtags` to automatically generate release notes from Git tags and commit messages.

## Resolved Questions
- **Credentials**: Should we use a PyPi API Token or set up GitLab as a "Trusted Publisher" (OIDC) on PyPi? **(Resolved: OIDC / Trusted Publisher)**
- **Testing**: Do we want to include a "dry-run" or "TestPyPi" stage in the CI to verify the package before it hits the live PyPi index? **(Resolved: No)**
- **Changelog**: Should we automate changelog generation from commit messages or keep it manual? **(Resolved: Automated with changelogfromtags)**

## Open Questions
- (None)

## Next Steps
→ `/ce:plan` for implementation details once open questions are resolved.
