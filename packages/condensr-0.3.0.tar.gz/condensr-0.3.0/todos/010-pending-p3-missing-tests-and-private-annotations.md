---
status: pending
priority: p3
issue_id: "010"
tags: [code-review, testing, type-safety, python]
---

# Missing test for `on_chapter` callback + private helper type annotations

## Problem Statement

1. **No test for `on_chapter` callback** — The callback is part of the public API and fires with `(str, str)`. Without a test, there is no verification that it is called at all, or with the right arguments.
2. **Private helpers missing type annotations** — `_validate_pdf`, `_detect_from_toc`, `_detect_from_headings` all accept `pymupdf.Document` but are typed as bare `doc` (no annotation).

## Findings

**Missing test — `condensr/__init__.py:66-68`:**
```python
if on_chapter:
    on_chapter(chapter.title, summary)  # called but never tested
```

**Missing annotations — `condensr/parser.py:124,149,186`:**
```python
def _validate_pdf(doc):               # should be doc: pymupdf.Document
def _detect_from_toc(doc):            # should be doc: pymupdf.Document
def _detect_from_headings(doc):       # should be doc: pymupdf.Document
```

## Proposed Solutions

### Test for `on_chapter`:

Add to a new `TestSummarize` class in `tests/test_summarizer.py` (or a new `tests/test_api.py`):

```python
@patch("condensr.summarizer.Mistral")
def test_on_chapter_callback_is_called(mock_mistral_class, pdf_with_toc):
    mock_client = MagicMock()
    mock_mistral_class.return_value = mock_client
    mock_response = MagicMock()
    mock_response.choices[0].message.content = "Summary."
    mock_client.chat.complete.return_value = mock_response

    received = []
    def on_chapter(title, summary):
        received.append((title, summary))

    list(condensr.summarize(pdf_with_toc, on_chapter=on_chapter))

    assert len(received) == 3
    assert all(isinstance(t, str) for t, s in received)
    assert all(isinstance(s, str) for t, s in received)
```

### Type annotations on private helpers:

```python
def _validate_pdf(doc: pymupdf.Document) -> None: ...
def _detect_from_toc(doc: pymupdf.Document) -> list[Chapter]: ...
def _detect_from_headings(doc: pymupdf.Document) -> list[Chapter]: ...
```

## Technical Details

- **Files:** `condensr/parser.py` (annotations), `tests/test_summarizer.py` or new `tests/test_api.py` (callback test)

## Acceptance Criteria

- [ ] `_validate_pdf`, `_detect_from_toc`, `_detect_from_headings` all annotated with `doc: pymupdf.Document`
- [ ] Test added verifying `on_chapter` is called once per chapter with `(str, str)` arguments
- [ ] All tests pass
