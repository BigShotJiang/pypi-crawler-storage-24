# Todo List - Automate PyPi publishing with OIDC

## Phase 1: Build & Versioning Configuration
- [x] Modify `pyproject.toml` to add `setuptools-scm[simple]` and `commitizen` configuration.
- [x] Update `condensr/__init__.py` to use `importlib.metadata.version`.

## Phase 2: GitLab CI Configuration
- [x] Update `.gitlab-ci.yml` for PyPi OIDC publishing and the `release` environment.

## Phase 3: External Configuration (Manual)
- [ ] Configure PyPi Trusted Publisher for the GitLab repository.
- [ ] Create and protect the \`release\` environment in GitLab.

## Quality & Finalization
- [x] Run tests and linting.
- [x] Finalize the PR.

