---
status: pending
priority: p2
issue_id: "005"
tags: [code-review, python, library-conventions]
---

# Library code uses `print()` to stderr — replace with `warnings.warn()`

## Problem Statement

`condensr/summarizer.py` writes directly to `sys.stderr` using `print()`. Library code must not write to stderr. That is the application's responsibility. Using `print()` means callers cannot filter, suppress, or redirect the warning using the standard `warnings` module.

## Findings

**`condensr/summarizer.py:48-52`:**
```python
print(
    f"Warning: Chapter '{chapter_title}' text exceeds {MAX_TEXT_LENGTH} "
    f"characters ({len(text)}). Truncating.",
    file=sys.stderr,
)
```

## Proposed Solution

```python
import warnings

if len(text) > MAX_TEXT_LENGTH:
    warnings.warn(
        f"Chapter '{chapter_title}' text truncated from {len(text)} to "
        f"{MAX_TEXT_LENGTH} characters.",
        UserWarning,
        stacklevel=2,
    )
    text = text[:MAX_TEXT_LENGTH]
```

**Test change:** Replace `capsys.readouterr()` assertion with `pytest.warns(UserWarning)`:

```python
with pytest.warns(UserWarning, match="truncated"):
    summarize_text(long_text, "Long Chapter")
```

## Technical Details

- **File:** `condensr/summarizer.py`
- **Line:** 48–52
- Remove `import sys` if no other usage remains

## Acceptance Criteria

- [ ] `print(..., file=sys.stderr)` replaced with `warnings.warn(..., UserWarning, stacklevel=2)`
- [ ] `import sys` removed if no longer needed
- [ ] `test_summarizer.py` updated to use `pytest.warns(UserWarning)` instead of `capsys`
- [ ] Tests pass
