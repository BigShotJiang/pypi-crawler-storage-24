---
status: pending
priority: p3
issue_id: "007"
tags: [code-review, python, style, cleanup]
---

# PEP 8 violations + dead assignment in `detect_chapters()`

## Problem Statement

Three minor code style/cleanup issues in `condensr/parser.py`:

1. **Comma-separated imports on one line** — PEP 8 requires one import per line.
2. **Compound `if: return` on one line** — PEP 8 prohibits compound conditional statements on single lines.
3. **Dead assignment** — `last_page = len(doc) - 1` in `detect_chapters()` is computed but never used in that function (the private helpers compute their own `last_page`).

## Findings

**`condensr/parser.py:5`:**
```python
import os, re, statistics  # three imports on one line
```

**`condensr/parser.py:47-51`:**
```python
chapters = _detect_from_toc(doc)
if chapters: return chapters       # compound statement

chapters = _detect_from_headings(doc)
if chapters: return chapters       # compound statement
```

**`condensr/parser.py:44`:**
```python
last_page = len(doc) - 1  # dead — never read in this function
```

## Proposed Solution

```python
# parser.py imports
import os
import re
import statistics

# detect_chapters body
def detect_chapters(pdf_path: str) -> list[Chapter]:
    doc = pymupdf.open(pdf_path)
    try:
        _validate_pdf(doc)
        # removed: last_page = len(doc) - 1

        chapters = _detect_from_toc(doc)
        if chapters:
            return chapters

        chapters = _detect_from_headings(doc)
        if chapters:
            return chapters

        return []
    finally:
        doc.close()
```

Also fix `get_book_title`:
```python
title = doc.metadata.get("title", "").strip()
if title:
    return title
```

## Technical Details

- **File:** `condensr/parser.py`
- **Lines:** 5 (imports), 44 (dead assignment), 47–51 (compound ifs)

## Acceptance Criteria

- [ ] `import os, re, statistics` split onto three lines
- [ ] `last_page = len(doc) - 1` in `detect_chapters()` removed
- [ ] `if chapters: return chapters` expanded to two lines throughout
- [ ] All tests pass
