---
status: complete
priority: p1
issue_id: "002"
tags: [code-review, security, python, cli]
---

# CLI output file: missing UTF-8 encoding + writes next to source PDF

## Problem Statement

Two related bugs in `cli.py` that both manifest at the `open(output, "w")` call:

1. **No `encoding="utf-8"`** — On Windows with a non-UTF-8 locale (cp1252), any non-ASCII character in the summary (em-dash, accented name, CJK text) raises `UnicodeEncodeError` and corrupts the output file mid-write.
2. **Default output path is next to the source PDF** — `book.pdf → book-summary.md` in the same directory as the input. Users expect CLI tools to write to the current working directory, not to wherever the input file lives.

## Findings

**File:** `condensr/cli.py:24-32`

```python
if output is None:
    base = pdf_path.rsplit(".", 1)[0]       # includes full path
    output = f"{base}-summary.md"           # written next to source PDF

...
with open(output, "w") as f:               # no encoding
```

Running `condensr /home/user/books/ai.pdf` writes to `/home/user/books/ai-summary.md`, not `./ai-summary.md`.

## Proposed Solutions

### Option A: Fix both in one pass (Recommended)

```python
from pathlib import Path

if output is None:
    output = Path.cwd() / f"{Path(pdf_path).stem}-summary.md"

...
with open(output, "w", encoding="utf-8") as f:
```

Also add `writable=True` to the Click option for clean error messages:

```python
@click.option("--output", "-o", type=click.Path(writable=True), ...)
```

**Pros:** Two bugs fixed together, no extra diff, clean pathlib usage.
**Effort:** Small. **Risk:** Minor behavior change (output location moves to CWD for default case — a fix, not a regression).

### Option B: Fix only the encoding

```python
with open(output, "w", encoding="utf-8") as f:
```

**Pros:** Minimal change.
**Cons:** Leaves the surprising output location bug in place.
**Effort:** Trivial. **Risk:** None.

## Recommended Action

Option A — fix both together.

## Technical Details

- **File:** `condensr/cli.py`
- **Lines:** 24–26 (path derivation), 32 (file open)

## Acceptance Criteria

- [ ] Default output is `CWD/<stem>-summary.md`, not `<source_dir>/<stem>-summary.md`
- [ ] `open()` called with `encoding="utf-8"`
- [ ] `--output` Click option has `writable=True` for clean error messages
- [ ] Existing CLI tests (if any) updated for new default path behavior
