## 0.2.1 (2026-03-02)

## 0.2.1 (2026-03-02)

## 0.2.0 (2026-03-02)

### Feat

- **ci**: automate PyPi publishing with OIDC and tag-driven versioning
- initial implementation of Condensr book summarizer
