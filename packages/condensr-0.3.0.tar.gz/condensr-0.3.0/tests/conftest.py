"""Shared test fixtures for Condensr tests."""

import pymupdf
import pytest


@pytest.fixture
def pdf_with_toc(tmp_path):
    """Create a small PDF with a table of contents (3 chapters)."""
    doc = pymupdf.open()

    # Chapter 1: pages 0-1
    page = doc.new_page()
    page.insert_text((72, 72), "Chapter 1: Introduction", fontsize=16)
    page.insert_text((72, 120), "This is the introduction content. " * 20)
    page = doc.new_page()
    page.insert_text((72, 72), "More introduction content. " * 30)

    # Chapter 2: pages 2-3
    page = doc.new_page()
    page.insert_text((72, 72), "Chapter 2: Methods", fontsize=16)
    page.insert_text((72, 120), "This chapter covers the methods used. " * 20)
    page = doc.new_page()
    page.insert_text((72, 72), "Additional methods details. " * 30)

    # Chapter 3: page 4
    page = doc.new_page()
    page.insert_text((72, 72), "Chapter 3: Conclusion", fontsize=16)
    page.insert_text((72, 120), "In conclusion, we found that... " * 20)

    # Set the TOC (1-based page numbers)
    toc = [
        [1, "Introduction", 1],
        [1, "Methods", 3],
        [1, "Conclusion", 5],
    ]
    doc.set_toc(toc)

    path = tmp_path / "book_with_toc.pdf"
    doc.save(str(path))
    doc.close()
    return str(path)


@pytest.fixture
def pdf_with_headings(tmp_path):
    """Create a PDF with bold/large headings but no TOC."""
    doc = pymupdf.open()

    # Page 0: Chapter heading in large bold font
    page = doc.new_page()
    page.insert_text((72, 72), "Chapter 1 The Beginning", fontsize=24, fontname="helv")
    page.insert_text((72, 140), "Some normal body text here. " * 30, fontsize=11)

    # Page 1: Another chapter heading
    page = doc.new_page()
    page.insert_text((72, 72), "Chapter 2 The Middle", fontsize=24, fontname="helv")
    page.insert_text((72, 140), "More body text for the middle chapter. " * 30, fontsize=11)

    # No TOC set

    path = tmp_path / "book_with_headings.pdf"
    doc.save(str(path))
    doc.close()
    return str(path)


@pytest.fixture
def pdf_no_chapters(tmp_path):
    """Create a plain PDF with no chapters (just body text)."""
    doc = pymupdf.open()

    page = doc.new_page()
    page.insert_text((72, 72), "Just some regular text. " * 50, fontsize=11)

    page = doc.new_page()
    page.insert_text((72, 72), "More regular text on page two. " * 50, fontsize=11)

    path = tmp_path / "plain_book.pdf"
    doc.save(str(path))
    doc.close()
    return str(path)


@pytest.fixture
def pdf_encrypted(tmp_path):
    """Create an encrypted PDF."""
    doc = pymupdf.open()
    page = doc.new_page()
    page.insert_text((72, 72), "Secret content. " * 30)

    path = tmp_path / "encrypted_book.pdf"
    doc.save(
        str(path),
        encryption=pymupdf.PDF_ENCRYPT_AES_256,
        user_pw="password",
        owner_pw="owner",
    )
    doc.close()
    return str(path)


@pytest.fixture
def pdf_no_text(tmp_path):
    """Create a PDF with no extractable text (empty pages)."""
    doc = pymupdf.open()
    doc.new_page()
    doc.new_page()

    path = tmp_path / "empty_book.pdf"
    doc.save(str(path))
    doc.close()
    return str(path)


@pytest.fixture
def pdf_with_metadata_title(tmp_path):
    """Create a PDF with title in metadata."""
    doc = pymupdf.open()
    page = doc.new_page()
    page.insert_text((72, 72), "Some content here. " * 30)

    doc.set_metadata({"title": "The Great Book"})

    path = tmp_path / "titled_book.pdf"
    doc.save(str(path))
    doc.close()
    return str(path)


@pytest.fixture
def pdf_with_toc_and_subchapters(tmp_path):
    """PDF with level-1 chapters and level-2 sub-sections."""
    doc = pymupdf.open()
    for i in range(5):
        page = doc.new_page()
        page.insert_text((72, 72), f"Page {i + 1} content. " * 20)
    toc = [
        [1, "Chapter One", 1],
        [2, "Section 1.1", 1],
        [2, "Section 1.2", 2],
        [1, "Chapter Two", 3],
        [2, "Section 2.1", 4],
        [1, "Chapter Three", 5],
    ]
    doc.set_toc(toc)
    path = tmp_path / "toc_subchapters.pdf"
    doc.save(str(path))
    doc.close()
    return str(path)


@pytest.fixture
def pdf_with_meta_chapters(tmp_path):
    """PDF with meta entries (Copyright, etc.) mixed with real chapters."""
    doc = pymupdf.open()
    for i in range(7):
        page = doc.new_page()
        page.insert_text((72, 72), f"Page {i + 1} content. " * 20)
    toc = [
        [1, "TITLE PAGE", 1],
        [1, "COPYRIGHT", 2],
        [1, "DEDICATION", 3],
        [1, "CONTENTS", 4],
        [1, "Chapter One", 5],
        [1, "Chapter Two", 6],
        [1, "ABOUT THE AUTHORS", 7],
    ]
    doc.set_toc(toc)
    path = tmp_path / "meta_chapters.pdf"
    doc.save(str(path))
    doc.close()
    return str(path)


@pytest.fixture
def pdf_with_meta_chapters_fr(tmp_path):
    """PDF with French meta entries."""
    doc = pymupdf.open()
    for i in range(5):
        page = doc.new_page()
        page.insert_text((72, 72), f"Page {i + 1} contenu. " * 20)
    toc = [
        [1, "Dédicace", 1],
        [1, "Remerciements", 2],
        [1, "Chapitre Premier", 3],
        [1, "Chapitre Deux", 4],
        [1, "Bibliographie", 5],
    ]
    doc.set_toc(toc)
    path = tmp_path / "meta_chapters_fr.pdf"
    doc.save(str(path))
    doc.close()
    return str(path)


@pytest.fixture
def pdf_with_superstring_titles(tmp_path):
    """PDF with titles that contain blocklist words but are real chapters."""
    doc = pymupdf.open()
    for i in range(3):
        page = doc.new_page()
        page.insert_text((72, 72), f"Page {i + 1} content. " * 20)
    toc = [
        [1, "Notes on the Revolution", 1],
        [1, "A Dedication to Craft", 2],
        [1, "The Copyright Wars", 3],
    ]
    doc.set_toc(toc)
    path = tmp_path / "superstring_titles.pdf"
    doc.save(str(path))
    doc.close()
    return str(path)
