"""Tests for condensr.summarizer module."""

from unittest.mock import MagicMock, patch

import pytest

from condensr.summarizer import MAX_TEXT_LENGTH, SYSTEM_PROMPT, USER_PROMPT, summarize_text


class TestSummarizeText:
    @patch("condensr.summarizer.Mistral")
    def test_calls_mistral_with_correct_params(self, mock_mistral_class):
        mock_client = MagicMock()
        mock_mistral_class.return_value = mock_client
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = "Summary here."
        mock_client.chat.complete.return_value = mock_response

        result = summarize_text("Some chapter text", "Chapter 1")

        mock_mistral_class.assert_called_once_with(api_key=None)
        call_kwargs = mock_client.chat.complete.call_args[1]
        assert call_kwargs["model"] == "mistral-small-latest"
        assert call_kwargs["temperature"] == 0.3
        messages = call_kwargs["messages"]
        assert messages[0]["role"] == "system"
        assert messages[0]["content"] == SYSTEM_PROMPT
        assert messages[1]["role"] == "user"
        assert "Chapter 1" in messages[1]["content"]
        assert "Some chapter text" in messages[1]["content"]
        assert result == "Summary here."

    @patch("condensr.summarizer.Mistral")
    def test_passes_api_key(self, mock_mistral_class):
        mock_client = MagicMock()
        mock_mistral_class.return_value = mock_client
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = "Summary."
        mock_client.chat.complete.return_value = mock_response

        summarize_text("Text", "Title", api_key="my-key")

        mock_mistral_class.assert_called_once_with(api_key="my-key")

    @patch("condensr.summarizer.Mistral")
    def test_passes_custom_model(self, mock_mistral_class):
        mock_client = MagicMock()
        mock_mistral_class.return_value = mock_client
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = "Summary."
        mock_client.chat.complete.return_value = mock_response

        summarize_text("Text", "Title", model="mistral-large-latest")

        call_kwargs = mock_client.chat.complete.call_args[1]
        assert call_kwargs["model"] == "mistral-large-latest"

    @patch("condensr.summarizer.Mistral")
    def test_raises_on_none_content(self, mock_mistral_class):
        mock_client = MagicMock()
        mock_mistral_class.return_value = mock_client
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = None
        mock_client.chat.complete.return_value = mock_response

        with pytest.raises(ValueError, match="empty content"):
            summarize_text("Text", "Chapter 1")

    @patch("condensr.summarizer.Mistral")
    def test_truncates_long_text(self, mock_mistral_class, capsys):
        mock_client = MagicMock()
        mock_mistral_class.return_value = mock_client
        mock_response = MagicMock()
        mock_response.choices = [MagicMock()]
        mock_response.choices[0].message.content = "Summary."
        mock_client.chat.complete.return_value = mock_response

        long_text = "a" * (MAX_TEXT_LENGTH + 1000)
        summarize_text(long_text, "Long Chapter")

        # Check warning was printed to stderr
        captured = capsys.readouterr()
        assert "Truncating" in captured.err

        # Check the text sent to Mistral was truncated
        call_kwargs = mock_client.chat.complete.call_args[1]
        user_content = call_kwargs["messages"][1]["content"]
        # The user prompt contains the text, which should be truncated
        assert len(user_content) < len(long_text) + 200  # prompt overhead
