import json
from datetime import datetime, timezone, timedelta

from croniter import croniter
from fastapi import APIRouter, Depends, Request, HTTPException, Form
from fastapi.responses import RedirectResponse
from sqlalchemy import func
from sqlalchemy.orm import Session

from fastpluggy.core.auth import require_authentication
from fastpluggy.core.database import get_db
from fastpluggy.core.dependency import get_view_builder
from fastpluggy.core.menu.decorator import menu_entry
from fastpluggy.core.widgets import CustomTemplateWidget
from ..models import ScheduledQuery, ScheduledQueryResultHistory

crud_router = APIRouter(
    dependencies=[Depends(require_authentication)]
)


@crud_router.get("/")
def read_scheduled_queries(
        request: Request,
        db: Session = Depends(get_db),
        view_builder=Depends(get_view_builder)
):
    """
    Retrieve scheduled queries and render as a Grafana-style card grid.
    """
    now = datetime.now(tz=timezone.utc)
    queries = db.query(ScheduledQuery).all()

    # Compute next_run for each query
    for q in queries:
        if q.cron_schedule and q.enabled:
            try:
                ref = q.last_executed.replace(tzinfo=timezone.utc) if q.last_executed and q.last_executed.tzinfo is None else (q.last_executed or now)
                cron = croniter(q.cron_schedule, ref)
                q._next_run = cron.get_next(datetime)
            except Exception:
                q._next_run = None
        else:
            q._next_run = None

    # Summary stats
    total_queries = len(queries)
    enabled_count = sum(1 for q in queries if q.enabled)

    cutoff = now - timedelta(hours=24)
    failed_24h = db.query(func.count(ScheduledQueryResultHistory.id)).filter(
        ScheduledQueryResultHistory.status == 'failed',
        ScheduledQueryResultHistory.executed_at >= cutoff,
    ).scalar() or 0

    avg_duration_row = db.query(func.avg(ScheduledQueryResultHistory.duration_ms)).filter(
        ScheduledQueryResultHistory.status == 'success',
        ScheduledQueryResultHistory.executed_at >= cutoff,
    ).scalar()
    avg_duration = round(avg_duration_row) if avg_duration_row else 0

    # Parse last_result and fetch last status for each query
    for q in queries:
        q._last_status = None
        q._last_value = None
        if q.last_result:
            try:
                data = json.loads(q.last_result)
                if isinstance(data, dict) and data.get("type") == "rows" and data.get("rows"):
                    if q.render_type in ("counter", "metric"):
                        first_col = data["columns"][0]["name"]
                        q._last_value = data["rows"][0].get(first_col)
                    else:
                        q._last_value = f"{len(data['rows'])} rows"
                elif isinstance(data, dict) and data.get("type") == "rows_affected":
                    q._last_value = f"{data['count']} affected"
            except Exception:
                pass
        # Get last execution status from history
        last_history = db.query(ScheduledQueryResultHistory).filter(
            ScheduledQueryResultHistory.scheduled_query_id == q.id
        ).order_by(ScheduledQueryResultHistory.executed_at.desc()).first()
        q._last_status = last_history.status if last_history else None

    items = [
        CustomTemplateWidget(
            template_name="scheduled_query/query_cards.html.j2",
            context={
                "request": request,
                "queries": queries,
                "total_queries": total_queries,
                "enabled_count": enabled_count,
                "failed_24h": failed_24h,
                "avg_duration": avg_duration,
                "sparklines_url": str(request.url_for("get_queries_sparklines")),
                "apexcharts_url": "/app_static/scheduled_query/vendor/apexcharts.min.js",
                "url_edit": str(request.url_for("edit_scheduled_query_form", query_id="__ID__")),
                "url_run_now": str(request.url_for("run_scheduled_query_now", query_id="__ID__")),
                "url_detail": str(request.url_for("query_detail", query_id="__ID__")),
                "url_create": str(request.url_for("read_scheduled_queries")) + "create",
            }
        )
    ]
    return view_builder.generate(
        request,
        widgets=items,
        title='Scheduled Queries',
    )
@crud_router.get("/create")
def create_scheduled_query_form(
        request: Request,
        view_builder=Depends(get_view_builder)
):
    """Show the create form for a new scheduled query."""
    # Create a dummy object with defaults for the template
    class _Empty:
        name = ""
        cron_schedule = ""
        render_type = "auto"
        enabled = False
        query = ""

    items = [
        CustomTemplateWidget(
            template_name="scheduled_query/edit_form.html.j2",
            context={
                "request": request,
                "query": _Empty(),
                "form_action": str(request.url_for("create_scheduled_query")),
                "is_create": True,
                "preview_url": str(request.url_for("preview_query")),
            }
        )
    ]
    return view_builder.generate(
        request,
        widgets=items,
        title='New Scheduled Query',
    )


@crud_router.get("/edit/{query_id}")
def edit_scheduled_query_form(
        query_id: int,
        request: Request,
        db: Session = Depends(get_db),
        view_builder=Depends(get_view_builder)
):
    """
    Show the edit form for a scheduled query.
    """
    # Get the query to edit
    query = db.query(ScheduledQuery).filter(ScheduledQuery.id == query_id).first()
    if not query:
        raise HTTPException(status_code=404, detail=f"Scheduled query with ID {query_id} not found")

    items = [
        CustomTemplateWidget(
            template_name="scheduled_query/edit_form.html.j2",
            context={
                "request": request,
                "query": query,
                "form_action": str(request.url_for("update_scheduled_query", query_id=query_id)),
                "is_create": False,
                "preview_url": str(request.url_for("preview_query")),
            }
        )
    ]

    return view_builder.generate(
        request,
        widgets=items,
        title=f'Edit Query: {query.name}',
    )


@crud_router.get("/query/{query_id}")
def query_detail(
        query_id: int,
        request: Request,
        db: Session = Depends(get_db),
        view_builder=Depends(get_view_builder)
):
    """Query detail page with Grafana-style charts."""
    query = db.query(ScheduledQuery).filter(ScheduledQuery.id == query_id).first()
    if not query:
        raise HTTPException(status_code=404, detail=f"Scheduled query with ID {query_id} not found")

    # Compute next_run
    next_run = None
    if query.cron_schedule and query.enabled:
        try:
            now = datetime.now(tz=timezone.utc)
            ref = query.last_executed.replace(tzinfo=timezone.utc) if query.last_executed and query.last_executed.tzinfo is None else (query.last_executed or now)
            cron = croniter(query.cron_schedule, ref)
            next_run = cron.get_next(datetime)
        except Exception:
            pass

    # Get last execution status
    last_history = db.query(ScheduledQueryResultHistory).filter(
        ScheduledQueryResultHistory.scheduled_query_id == query.id
    ).order_by(ScheduledQueryResultHistory.executed_at.desc()).first()
    last_status = last_history.status if last_history else None

    items = [
        CustomTemplateWidget(
            template_name="scheduled_query/query_detail.html.j2",
            context={
                "request": request,
                "query": query,
                "next_run": next_run,
                "last_status": last_status,
                "chart_data_url": str(request.url_for("get_chart_data", query_id=query_id)),
                "edit_url": str(request.url_for("edit_scheduled_query_form", query_id=query_id)),
                "run_now_url": str(request.url_for("run_scheduled_query_now", query_id=query_id)),
                "toggle_url": str(request.url_for("toggle_query_enabled", query_id=query_id)),
                "apexcharts_url": "/app_static/scheduled_query/vendor/apexcharts.min.js",
                "list_url": str(request.url_for("read_scheduled_queries")),
            }
        )
    ]
    return view_builder.generate(
        request,
        widgets=items,
        title=f'Query: {query.name}',
    )


@crud_router.post("/create")
def create_scheduled_query(
        request: Request,
        db: Session = Depends(get_db),
        name: str = Form(...),
        query: str = Form(...),
        cron_schedule: str = Form(...),
        enabled: bool = Form(False),
        render_type: str = Form("auto")
):
    """Create a new scheduled query with validation."""
    from ..tasks import is_query_safe

    # Validate query safety
    if not is_query_safe(query):
        raise HTTPException(status_code=400, detail="Query contains forbidden keywords")

    # Validate cron expression
    if not croniter.is_valid(cron_schedule):
        raise HTTPException(status_code=400, detail=f"Invalid cron expression: {cron_schedule}")

    scheduled_query = ScheduledQuery(
        name=name,
        query=query,
        cron_schedule=cron_schedule,
        enabled=enabled,
        render_type=render_type,
    )
    db.add(scheduled_query)
    db.commit()

    return RedirectResponse(url=str(request.url_for("read_scheduled_queries")), status_code=303)


@crud_router.post("/edit/{query_id}")
def update_scheduled_query(
        query_id: int,
        request: Request,
        db: Session = Depends(get_db),
        name: str = Form(...),
        query: str = Form(...),
        cron_schedule: str = Form(...),
        enabled: bool = Form(False),
        render_type: str = Form("auto")
):
    """
    Update a scheduled query with form data.
    """
    from ..tasks import is_query_safe

    # Validate query safety
    if not is_query_safe(query):
        raise HTTPException(status_code=400, detail="Query contains forbidden keywords")

    # Validate cron expression
    if not croniter.is_valid(cron_schedule):
        raise HTTPException(status_code=400, detail=f"Invalid cron expression: {cron_schedule}")

    # Get the query to update
    scheduled_query = db.query(ScheduledQuery).filter(ScheduledQuery.id == query_id).first()
    if not scheduled_query:
        raise HTTPException(status_code=404, detail=f"Scheduled query with ID {query_id} not found")

    # Update the query fields
    scheduled_query.name = name
    scheduled_query.query = query
    scheduled_query.cron_schedule = cron_schedule
    scheduled_query.enabled = enabled
    scheduled_query.render_type = render_type

    # Save changes
    db.commit()

    # Redirect back to the scheduled queries list
    return RedirectResponse(url=str(request.url_for("read_scheduled_queries")), status_code=303)
