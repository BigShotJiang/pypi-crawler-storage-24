from fastapi import APIRouter, Depends, Request
from fastapi.responses import RedirectResponse

from fastpluggy.core.auth import require_authentication

web_router = APIRouter(
    dependencies=[Depends(require_authentication)]
)


@web_router.get("/dashboard")
def dashboard(request: Request):
    """Redirect old dashboard URL to main list page."""
    return RedirectResponse(url=str(request.url_for("read_scheduled_queries")), status_code=301)
