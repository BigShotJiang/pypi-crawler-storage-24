import json
import re

from loguru import logger
from prometheus_client import Gauge, REGISTRY

prometheus_gauges = {}
prometheus_registry = REGISTRY

# Execution counters (in-memory, not prometheus_client objects — exposed via get_metrics())
execution_counters = {
    "executions_total": 0,
    "successes_total": 0,
    "failures_total": 0,
    "timeouts_total": 0,
}

# Per-query last duration: {slugified_name: duration_ms}
per_query_last_duration: dict[str, float] = {}

# Per-query rolling average: {slugified_name: (total_ms, count)}
per_query_avg_duration: dict[str, tuple[float, int]] = {}


def _slugify(name: str) -> str:
    """Convert a query name to a Prometheus-safe label value.

    Lowercase, replace non-alphanumeric chars with underscore,
    collapse runs, strip leading/trailing underscores.
    """
    s = name.lower()
    s = re.sub(r"[^a-z0-9]+", "_", s)
    s = re.sub(r"_+", "_", s)
    return s.strip("_")


def record_execution(query_name: str, status: str, duration_ms: int | None = None):
    """Record an execution outcome in the in-memory counters."""
    execution_counters["executions_total"] += 1
    if status == "success":
        execution_counters["successes_total"] += 1
    elif status == "timeout":
        execution_counters["timeouts_total"] += 1
    else:
        execution_counters["failures_total"] += 1

    if duration_ms is not None and query_name:
        slug = _slugify(query_name)
        per_query_last_duration[slug] = float(duration_ms)
        total, count = per_query_avg_duration.get(slug, (0.0, 0))
        per_query_avg_duration[slug] = (total + duration_ms, count + 1)


def _extract_metric_value(last_result: str) -> float | None:
    try:
        payload = json.loads(last_result)
        rows = payload.get("rows", [])
        if not rows:
            return None
        first_value = list(rows[0].values())[0]
        return float(first_value)
    except (TypeError, ValueError, KeyError, json.JSONDecodeError):
        return None


def update_prometheus_metric(scheduled_query):
    try:
        config = scheduled_query.grafana_metric_config
        if not config:
            return

        metric_name = config.get("metric_name")
        value = _extract_metric_value(scheduled_query.last_result or "")
        if value is None:
            logger.warning(f"Could not extract metric value for query {scheduled_query.id}")
            return

        if metric_name not in prometheus_gauges:
            prometheus_gauges[metric_name] = Gauge(
                name=metric_name,
                documentation=f"Scheduled query metric: {metric_name}",
                registry=prometheus_registry,
            )

        prometheus_gauges[metric_name].set(value)  # always update
        logger.info(f"Prometheus metric {metric_name} updated with value: {value}")

    except Exception as e:
        logger.exception(f"Failed to update Prometheus metric for query {scheduled_query.id}: {e}")
