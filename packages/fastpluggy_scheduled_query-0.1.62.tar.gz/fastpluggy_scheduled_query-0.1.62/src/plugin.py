# plugin.py

from typing import Annotated, Any

from loguru import logger

from fastpluggy.core.database import create_table_if_not_exist
from fastpluggy.core.metrics import MetricEntry, MetricsResult
from fastpluggy.core.module_base import FastPluggyBaseModule
from fastpluggy.core.tools.inspect_tools import InjectDependency
from .config import ScheduledQuerySettings


def get_scheduler_query_router():
    from .routers.web_router import web_router
    from .routers.api_router import api_router
    from .routers.crud_router import crud_router
    return [web_router, api_router, crud_router]

class ScheduledQueryPlugin(FastPluggyBaseModule):

    module_name: str = "scheduled_query"

    module_menu_name: str = "Scheduled Queries"
    module_menu_icon: str = "ti ti-clock-play"

    module_settings: Any = ScheduledQuerySettings
    module_router: Any = get_scheduler_query_router

    capabilities: list[str] = ["metrics"]

    depends_on: dict = {
        "tasks_worker": ">=0.2.0",
    }

    def on_load_complete(self, fast_pluggy: Annotated["FastPluggy", InjectDependency]) -> None:
        logger.info("Add query runner to executor")
        settings = ScheduledQuerySettings()
        from .models import ScheduledQuery
        create_table_if_not_exist(ScheduledQuery)

        if settings.enable_history:
            from .models import ScheduledQueryResultHistory
            create_table_if_not_exist(ScheduledQueryResultHistory)

        from fastpluggy_plugin.tasks_worker import TaskWorker
        from .tasks import collect_execute_scheduled_query
        TaskWorker.add_scheduled_task(
            function=collect_execute_scheduled_query,
            task_name='scheduled query',
            allow_concurrent=False,
            interval=60,
            origin="code",
            enabled=True,
        )

        try:
            from fastpluggy_plugin.db_purge.hooks import register_purge_target
            register_purge_target("fp_scheduled_query_results", "executed_at", default_retention_days=90)
        except ImportError:
            pass

    def get_metrics(self) -> MetricsResult:
        """Return execution counters, per-query duration gauges, and user-defined gauges."""
        from .metrics import (
            prometheus_gauges,
            execution_counters,
            per_query_last_duration,
            per_query_avg_duration,
        )
        from fastpluggy.core.database import session_scope
        from .models import ScheduledQuery as SQModel

        gauges: list[MetricEntry] = []
        counters: list[MetricEntry] = []

        # Execution counters
        for name, value in execution_counters.items():
            counters.append(MetricEntry(name=name, value=float(value), type="counter", help=f"Scheduled query {name}"))

        # Summary gauges (queries_configured, queries_enabled) — live from DB
        try:
            with session_scope() as db:
                configured = db.query(SQModel).count()
                enabled = db.query(SQModel).filter(SQModel.enabled == True).count()
            gauges.append(MetricEntry(name="queries_configured", value=float(configured), type="gauge", help="Total configured queries"))
            gauges.append(MetricEntry(name="queries_enabled", value=float(enabled), type="gauge", help="Currently enabled queries"))
        except Exception:
            pass

        # Per-query last duration gauges
        for slug, duration in per_query_last_duration.items():
            gauges.append(MetricEntry(
                name="last_duration_ms", value=duration, type="gauge",
                help="Last execution duration in ms",
                labels={"query_name": slug},
            ))

        # Per-query average duration gauges
        for slug, (total, count) in per_query_avg_duration.items():
            avg = total / count if count > 0 else 0.0
            gauges.append(MetricEntry(
                name="avg_duration_ms", value=round(avg, 1), type="gauge",
                help="Average execution duration in ms",
                labels={"query_name": slug},
            ))

        # User-defined Prometheus gauges (from grafana_metric_config)
        for name, gauge in prometheus_gauges.items():
            gauges.append(MetricEntry(
                name=name, value=gauge._value.get(), type="gauge", help=gauge._documentation,
            ))

        return MetricsResult(gauges=gauges, counters=counters)
