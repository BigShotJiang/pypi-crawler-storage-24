import asyncio
import datetime
import json
import re
import time
from decimal import Decimal
from typing import Annotated

from croniter import croniter

from fastpluggy.core.database import session_scope
from fastpluggy.core.tools.inspect_tools import InjectDependency
from fastpluggy.fastpluggy import FastPluggy
from loguru import logger
from sqlalchemy import text

from .config import ScheduledQuerySettings
from .metrics import update_prometheus_metric, record_execution
from .models import ScheduledQuery
from .models import ScheduledQueryResultHistory
from fastpluggy_plugin.tasks_worker.core.context import TaskContext
from fastpluggy_plugin.tasks_worker import TaskWorker

_CTE_SELECT_RE = re.compile(r'\b(with|select)\b', re.IGNORECASE)


def is_due(query: ScheduledQuery) -> bool:
    """Return True if the query's cron schedule says it should run now."""
    if not query.last_executed:
        return True
    ref = (
        query.last_executed.replace(tzinfo=datetime.timezone.utc)
        if query.last_executed.tzinfo is None
        else query.last_executed
    )
    cron = croniter(query.cron_schedule, ref)
    return cron.get_next(datetime.datetime) <= datetime.datetime.now(tz=datetime.timezone.utc)


# todo: use serialise_value function from fastpluggy core to avoid duplicate
def _row_to_dict(row, keys: list) -> dict:
    """Convert a SQLAlchemy Row to a JSON-safe dict."""
    out = {}
    for k, v in zip(keys, row):
        if isinstance(v, (datetime.datetime, datetime.date)):
            out[k] = v.isoformat()
        elif isinstance(v, Decimal):
            out[k] = float(v)
        else:
            out[k] = v
    return out


def _infer_value_type(v) -> str:
    if v is None:
        return "null"
    if isinstance(v, bool):
        return "boolean"
    if isinstance(v, int):
        return "integer"
    if isinstance(v, float):
        return "float"
    if isinstance(v, (datetime.datetime, datetime.date)):
        return "datetime"
    return "text"


def _build_column_meta(keys: list, first_row) -> list:
    return [
        {"name": k, "type": _infer_value_type(first_row[i] if first_row is not None else None)}
        for i, k in enumerate(keys)
    ]


def is_query_safe(query: str) -> bool:
    settings = ScheduledQuerySettings()
    forbidden = {kw.strip() for kw in settings.forbidden_keywords.split(',')}
    return not any(
        re.search(rf'\b{re.escape(kw)}\b', query, re.IGNORECASE)
        for kw in forbidden
    )

async def execute_scheduled_query(scheduled_query_id):

    with session_scope() as db:
        settings = ScheduledQuerySettings()

        try:
            scheduled_query = db.query(ScheduledQuery).filter(ScheduledQuery.id == scheduled_query_id).first()
            if not scheduled_query:
                logger.warning(f"Query with ID {scheduled_query_id} not found.")
                return

            if not is_query_safe(scheduled_query.query):
                scheduled_query.last_result = "Query rejected: contains forbidden keywords."
                scheduled_query.last_executed = datetime.datetime.now(tz=datetime.timezone.utc)
                db.commit()
                return

            start_time = time.perf_counter()
            try:
                result = await asyncio.wait_for(
                    asyncio.to_thread(db.execute, text(scheduled_query.query)),
                    timeout=settings.query_timeout,
                )
                db.commit()
            except asyncio.TimeoutError:
                duration_ms = int((time.perf_counter() - start_time) * 1000)
                db.rollback()
                scheduled_query.last_result = f"Error: query exceeded {settings.query_timeout}s timeout"
                scheduled_query.last_executed = datetime.datetime.now(tz=datetime.timezone.utc)

                if settings.enable_history:
                    history = ScheduledQueryResultHistory(
                        scheduled_query_id=scheduled_query.id,
                        executed_at=scheduled_query.last_executed,
                        duration_ms=duration_ms,
                        result=None,
                        status="timeout",
                        error_message=f"Query exceeded {settings.query_timeout}s timeout",
                    )
                    db.add(history)
                db.commit()
                record_execution(scheduled_query.name, "timeout", duration_ms)
                logger.warning(f"Query {scheduled_query.id} timed out after {settings.query_timeout}s")
                return

            duration_ms = int((time.perf_counter() - start_time) * 1000)

            # Keys must be read BEFORE fetchall — cursor may close after
            # returns_rows covers most cases; regex catches CTEs and commented queries
            is_select = result.returns_rows or bool(_CTE_SELECT_RE.search(scheduled_query.query))
            if is_select:
                keys = list(result.keys())
                rows = result.fetchall()
                payload = {
                    "type": "rows",
                    "columns": _build_column_meta(keys, rows[0] if rows else None),
                    "rows": [_row_to_dict(row, keys) for row in rows],
                }
            else:
                keys = []
                payload = {"type": "rows_affected", "count": result.rowcount}

            result_str = json.dumps(payload)

            scheduled_query.last_result = result_str
            scheduled_query.last_executed = datetime.datetime.now(tz=datetime.timezone.utc)
            db.add(scheduled_query)
            db.commit()

            # Store execution history
            if settings.enable_history:
                history = ScheduledQueryResultHistory(
                    scheduled_query_id=scheduled_query.id,
                    executed_at=scheduled_query.last_executed,
                    duration_ms=duration_ms,
                    result=result_str,
                    status="success"
                )
                db.add(history)
                db.commit()
            db.refresh(scheduled_query)
            record_execution(scheduled_query.name, "success", duration_ms)

            logger.info(f"Query {scheduled_query.id} executed successfully with result: {result_str}")

        except Exception as e:
            logger.exception(f"Error executing query {scheduled_query_id}: {e}")
            db.rollback()

            error_msg = str(e)
            now = datetime.datetime.now(tz=datetime.timezone.utc)

            # Update last result
            if scheduled_query:
                scheduled_query.last_result = f"Error: {error_msg}"
                scheduled_query.last_executed = now

            # Store failed execution history
            history = ScheduledQueryResultHistory(
                scheduled_query_id=scheduled_query_id,
                executed_at=now,
                duration_ms=None,
                result=None,
                status="failed",
                error_message=error_msg,
            )
            db.add(history)
            db.commit()
            record_execution(
                scheduled_query.name if scheduled_query else "",
                "failed",
            )



async def _run_due_queries(due_queries, settings):
    """Execute all due queries sequentially on a single event loop."""
    for item in due_queries:
        logger.debug(f"Collecting execute scheduled query : {item}")
        await execute_scheduled_query(item.id)

        # Update Prometheus metrics
        if settings.prometheus_enabled and item.grafana_metric_config:
            update_prometheus_metric(item)


@TaskWorker.register(name="scheduled_query.collect_execute", allow_concurrent=False, task_type="fp-daemon")
def collect_execute_scheduled_query(task_logger: Annotated[TaskContext, InjectDependency],fast_pluggy: Annotated[FastPluggy, InjectDependency], ):
    from .config import ScheduledQuerySettings

    with session_scope() as db:
            try:
                settings = ScheduledQuerySettings()
                list_query = db.query(ScheduledQuery).filter(ScheduledQuery.enabled == True).all()
                due = []
                for item in list_query:
                    if not is_due(item):
                        logger.debug(f"Skipping query {item.id} — not due yet")
                        continue

                    due.append(item)

                if due:
                    loop = asyncio.new_event_loop()
                    try:
                        loop.run_until_complete(_run_due_queries(due, settings))
                    finally:
                        loop.close()
            except Exception as e:
                logger.exception(f"Error in scheduled query execution: {e}")
