"""Tests for the scheduler loop — _run_due_queries and collect_execute_scheduled_query."""

import asyncio
from unittest.mock import MagicMock, patch, AsyncMock


from fastpluggy_plugin.scheduled_query.tasks import _run_due_queries


# ---------------------------------------------------------------------------
# _run_due_queries
# ---------------------------------------------------------------------------

class TestRunDueQueries:
    @patch("fastpluggy_plugin.scheduled_query.tasks.execute_scheduled_query", new_callable=AsyncMock)
    @patch("fastpluggy_plugin.scheduled_query.tasks.update_prometheus_metric")
    def test_executes_all_due(self, mock_prom, mock_exec):
        q1 = MagicMock(id=1, grafana_metric_config=None)
        q2 = MagicMock(id=2, grafana_metric_config=None)
        settings = MagicMock(prometheus_enabled=False)

        asyncio.run(_run_due_queries([q1, q2], settings))

        assert mock_exec.await_count == 2
        mock_exec.assert_any_await(1)
        mock_exec.assert_any_await(2)

    @patch("fastpluggy_plugin.scheduled_query.tasks.execute_scheduled_query", new_callable=AsyncMock)
    @patch("fastpluggy_plugin.scheduled_query.tasks.update_prometheus_metric")
    def test_updates_prometheus_when_enabled(self, mock_prom, mock_exec):
        config = {"metric_name": "my_metric"}
        q1 = MagicMock(id=1, grafana_metric_config=config)
        settings = MagicMock(prometheus_enabled=True)

        asyncio.run(_run_due_queries([q1], settings))

        mock_prom.assert_called_once_with(q1)

    @patch("fastpluggy_plugin.scheduled_query.tasks.execute_scheduled_query", new_callable=AsyncMock)
    @patch("fastpluggy_plugin.scheduled_query.tasks.update_prometheus_metric")
    def test_skips_prometheus_when_disabled(self, mock_prom, mock_exec):
        config = {"metric_name": "my_metric"}
        q1 = MagicMock(id=1, grafana_metric_config=config)
        settings = MagicMock(prometheus_enabled=False)

        asyncio.run(_run_due_queries([q1], settings))

        mock_prom.assert_not_called()

    @patch("fastpluggy_plugin.scheduled_query.tasks.execute_scheduled_query", new_callable=AsyncMock)
    @patch("fastpluggy_plugin.scheduled_query.tasks.update_prometheus_metric")
    def test_skips_prometheus_when_no_config(self, mock_prom, mock_exec):
        q1 = MagicMock(id=1, grafana_metric_config=None)
        settings = MagicMock(prometheus_enabled=True)

        asyncio.run(_run_due_queries([q1], settings))

        mock_prom.assert_not_called()

    @patch("fastpluggy_plugin.scheduled_query.tasks.execute_scheduled_query", new_callable=AsyncMock)
    @patch("fastpluggy_plugin.scheduled_query.tasks.update_prometheus_metric")
    def test_empty_list(self, mock_prom, mock_exec):
        settings = MagicMock(prometheus_enabled=True)

        asyncio.run(_run_due_queries([], settings))

        mock_exec.assert_not_awaited()
        mock_prom.assert_not_called()
