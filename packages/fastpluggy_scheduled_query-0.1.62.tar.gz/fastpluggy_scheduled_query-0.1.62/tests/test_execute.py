"""Tests for execute_scheduled_query — success, error, forbidden, not-found paths."""

import asyncio
import json
from unittest.mock import MagicMock, patch


from fastpluggy_plugin.scheduled_query.tasks import execute_scheduled_query


def _make_sq(id_=1, query="SELECT 1", enabled=True):
    sq = MagicMock()
    sq.id = id_
    sq.query = query
    sq.enabled = enabled
    sq.last_result = None
    sq.last_executed = None
    return sq


def _make_db(sq=None):
    db = MagicMock()
    db.query.return_value.filter.return_value.first.return_value = sq
    return db


def _make_ctx(db):
    ctx = MagicMock()
    ctx.__enter__ = MagicMock(return_value=db)
    ctx.__exit__ = MagicMock(return_value=False)
    return ctx


def _make_settings(**overrides):
    s = MagicMock()
    s.query_timeout = 30
    s.forbidden_keywords = "drop,delete,truncate,alter"
    s.enable_history = True
    s.prometheus_enabled = False
    for k, v in overrides.items():
        setattr(s, k, v)
    return s


# ---------------------------------------------------------------------------
# Query not found
# ---------------------------------------------------------------------------

class TestQueryNotFound:
    @patch("fastpluggy_plugin.scheduled_query.tasks.ScheduledQuerySettings")
    @patch("fastpluggy_plugin.scheduled_query.tasks.session_scope")
    def test_returns_early(self, mock_scope, mock_settings_cls):
        mock_settings_cls.return_value = _make_settings()
        db = _make_db(sq=None)
        mock_scope.return_value = _make_ctx(db)

        asyncio.run(execute_scheduled_query(999))

        db.commit.assert_not_called()


# ---------------------------------------------------------------------------
# Forbidden query rejected
# ---------------------------------------------------------------------------

class TestForbiddenQuery:
    @patch("fastpluggy_plugin.scheduled_query.tasks.ScheduledQuerySettings")
    @patch("fastpluggy_plugin.scheduled_query.tasks.session_scope")
    def test_forbidden_sets_last_result(self, mock_scope, mock_settings_cls):
        mock_settings_cls.return_value = _make_settings()
        sq = _make_sq(query="DROP TABLE users")
        db = _make_db(sq)
        mock_scope.return_value = _make_ctx(db)

        asyncio.run(execute_scheduled_query(1))

        assert "forbidden" in sq.last_result.lower()
        assert sq.last_executed is not None
        db.commit.assert_called()
        # Should NOT call db.execute
        db.execute.assert_not_called()


# ---------------------------------------------------------------------------
# Successful SELECT execution
# ---------------------------------------------------------------------------

class TestSuccessSelect:
    @patch("fastpluggy_plugin.scheduled_query.tasks.ScheduledQuerySettings")
    @patch("fastpluggy_plugin.scheduled_query.tasks.session_scope")
    def test_select_stores_result_and_history(self, mock_scope, mock_settings_cls):
        mock_settings_cls.return_value = _make_settings()
        sq = _make_sq(query="SELECT id, name FROM users")
        db = _make_db(sq)
        mock_scope.return_value = _make_ctx(db)

        # Simulate a result set
        result = MagicMock()
        result.returns_rows = True
        result.keys.return_value = ["id", "name"]
        result.fetchall.return_value = [(1, "alice"), (2, "bob")]
        db.execute.return_value = result

        asyncio.run(execute_scheduled_query(1))

        # last_result should be JSON with rows
        assert sq.last_result is not None
        payload = json.loads(sq.last_result)
        assert payload["type"] == "rows"
        assert len(payload["rows"]) == 2
        assert payload["rows"][0] == {"id": 1, "name": "alice"}
        assert payload["columns"][0]["name"] == "id"

        # last_executed should be set
        assert sq.last_executed is not None

        # History record should be added
        add_calls = db.add.call_args_list
        history_objs = [
            c[0][0] for c in add_calls
            if hasattr(c[0][0], 'status') and c[0][0].status == "success"
        ]
        assert len(history_objs) == 1
        assert history_objs[0].scheduled_query_id == 1
        assert history_objs[0].duration_ms is not None

    @patch("fastpluggy_plugin.scheduled_query.tasks.ScheduledQuerySettings")
    @patch("fastpluggy_plugin.scheduled_query.tasks.session_scope")
    def test_select_no_history_when_disabled(self, mock_scope, mock_settings_cls):
        mock_settings_cls.return_value = _make_settings(enable_history=False)
        sq = _make_sq(query="SELECT 1")
        db = _make_db(sq)
        mock_scope.return_value = _make_ctx(db)

        result = MagicMock()
        result.returns_rows = True
        result.keys.return_value = ["col"]
        result.fetchall.return_value = [(1,)]
        db.execute.return_value = result

        asyncio.run(execute_scheduled_query(1))

        assert sq.last_result is not None
        # No history object should be added
        add_calls = db.add.call_args_list
        history_objs = [
            c[0][0] for c in add_calls
            if hasattr(c[0][0], 'status') and c[0][0].status == "success"
        ]
        assert len(history_objs) == 0


# ---------------------------------------------------------------------------
# Successful non-SELECT (DML) execution
# ---------------------------------------------------------------------------

class TestSuccessDML:
    @patch("fastpluggy_plugin.scheduled_query.tasks.ScheduledQuerySettings")
    @patch("fastpluggy_plugin.scheduled_query.tasks.session_scope")
    def test_dml_stores_rows_affected(self, mock_scope, mock_settings_cls):
        mock_settings_cls.return_value = _make_settings()
        sq = _make_sq(query="UPDATE users SET active=true")
        db = _make_db(sq)
        mock_scope.return_value = _make_ctx(db)

        result = MagicMock()
        result.returns_rows = False
        result.rowcount = 5
        db.execute.return_value = result

        asyncio.run(execute_scheduled_query(1))

        payload = json.loads(sq.last_result)
        assert payload["type"] == "rows_affected"
        assert payload["count"] == 5


# ---------------------------------------------------------------------------
# Exception during execution
# ---------------------------------------------------------------------------

class TestExecutionError:
    @patch("fastpluggy_plugin.scheduled_query.tasks.ScheduledQuerySettings")
    @patch("fastpluggy_plugin.scheduled_query.tasks.session_scope")
    def test_error_stores_result_and_history(self, mock_scope, mock_settings_cls):
        mock_settings_cls.return_value = _make_settings()
        sq = _make_sq(query="SELECT * FROM nonexistent")
        db = _make_db(sq)
        mock_scope.return_value = _make_ctx(db)

        db.execute.side_effect = RuntimeError("relation does not exist")

        asyncio.run(execute_scheduled_query(1))

        # Rollback should be called
        db.rollback.assert_called()

        # last_result should contain error
        assert "Error:" in sq.last_result
        assert "relation does not exist" in sq.last_result
        assert sq.last_executed is not None

        # History record with status="failed"
        add_calls = db.add.call_args_list
        history_objs = [
            c[0][0] for c in add_calls
            if hasattr(c[0][0], 'status') and c[0][0].status == "failed"
        ]
        assert len(history_objs) == 1
        assert "relation does not exist" in history_objs[0].error_message
