"""Unit tests for pure functions in tasks.py."""

import asyncio
import datetime
import time
from decimal import Decimal
from unittest.mock import patch, MagicMock

import pytest

from fastpluggy_plugin.scheduled_query.tasks import (
    _build_column_meta,
    _infer_value_type,
    _row_to_dict,
    execute_scheduled_query,
    is_due,
    is_query_safe,
)


# ---------------------------------------------------------------------------
# _infer_value_type
# ---------------------------------------------------------------------------

class TestInferValueType:
    def test_none(self):
        assert _infer_value_type(None) == "null"

    def test_bool(self):
        assert _infer_value_type(True) == "boolean"
        assert _infer_value_type(False) == "boolean"

    def test_int(self):
        assert _infer_value_type(42) == "integer"

    def test_float(self):
        assert _infer_value_type(3.14) == "float"

    def test_datetime(self):
        assert _infer_value_type(datetime.datetime.now()) == "datetime"
        assert _infer_value_type(datetime.date.today()) == "datetime"

    def test_text_fallback(self):
        assert _infer_value_type("hello") == "text"
        assert _infer_value_type([1, 2]) == "text"


# ---------------------------------------------------------------------------
# _row_to_dict
# ---------------------------------------------------------------------------

class TestRowToDict:
    def test_basic(self):
        row = (1, "alice", 99.5)
        keys = ["id", "name", "score"]
        assert _row_to_dict(row, keys) == {"id": 1, "name": "alice", "score": 99.5}

    def test_datetime_iso(self):
        dt = datetime.datetime(2025, 1, 15, 10, 30)
        row = (dt,)
        result = _row_to_dict(row, ["ts"])
        assert result["ts"] == "2025-01-15T10:30:00"

    def test_date_iso(self):
        d = datetime.date(2025, 6, 1)
        row = (d,)
        result = _row_to_dict(row, ["day"])
        assert result["day"] == "2025-06-01"

    def test_decimal_to_float(self):
        row = (Decimal("3.14"),)
        result = _row_to_dict(row, ["val"])
        assert result["val"] == pytest.approx(3.14)
        assert isinstance(result["val"], float)

    def test_none_value(self):
        row = (None,)
        assert _row_to_dict(row, ["x"]) == {"x": None}


# ---------------------------------------------------------------------------
# _build_column_meta
# ---------------------------------------------------------------------------

class TestBuildColumnMeta:
    def test_with_row(self):
        keys = ["id", "name", "active"]
        first_row = (1, "alice", True)
        meta = _build_column_meta(keys, first_row)
        assert meta == [
            {"name": "id", "type": "integer"},
            {"name": "name", "type": "text"},
            {"name": "active", "type": "boolean"},
        ]

    def test_no_row(self):
        keys = ["id", "name"]
        meta = _build_column_meta(keys, None)
        assert meta == [
            {"name": "id", "type": "null"},
            {"name": "name", "type": "null"},
        ]


# ---------------------------------------------------------------------------
# is_query_safe
# ---------------------------------------------------------------------------

class TestIsQuerySafe:
    @patch("fastpluggy_plugin.scheduled_query.tasks.ScheduledQuerySettings")
    def test_safe_select(self, mock_settings_cls):
        mock_settings_cls.return_value.forbidden_keywords = "drop,delete,truncate,alter"
        assert is_query_safe("SELECT * FROM users") is True

    @patch("fastpluggy_plugin.scheduled_query.tasks.ScheduledQuerySettings")
    def test_forbidden_drop(self, mock_settings_cls):
        mock_settings_cls.return_value.forbidden_keywords = "drop,delete,truncate,alter"
        assert is_query_safe("DROP TABLE users") is False

    @patch("fastpluggy_plugin.scheduled_query.tasks.ScheduledQuerySettings")
    def test_forbidden_delete(self, mock_settings_cls):
        mock_settings_cls.return_value.forbidden_keywords = "drop,delete,truncate,alter"
        assert is_query_safe("DELETE FROM users WHERE id=1") is False

    @patch("fastpluggy_plugin.scheduled_query.tasks.ScheduledQuerySettings")
    def test_forbidden_truncate(self, mock_settings_cls):
        mock_settings_cls.return_value.forbidden_keywords = "drop,delete,truncate,alter"
        assert is_query_safe("TRUNCATE TABLE logs") is False

    @patch("fastpluggy_plugin.scheduled_query.tasks.ScheduledQuerySettings")
    def test_forbidden_alter(self, mock_settings_cls):
        mock_settings_cls.return_value.forbidden_keywords = "drop,delete,truncate,alter"
        assert is_query_safe("ALTER TABLE users ADD COLUMN age INT") is False

    @patch("fastpluggy_plugin.scheduled_query.tasks.ScheduledQuerySettings")
    def test_word_boundary_fixed(self, mock_settings_cls):
        """Word-boundary matching: 'deleted_at' no longer triggers 'delete'."""
        mock_settings_cls.return_value.forbidden_keywords = "drop,delete,truncate,alter"
        assert is_query_safe("SELECT deleted_at FROM users") is True

    @patch("fastpluggy_plugin.scheduled_query.tasks.ScheduledQuerySettings")
    def test_exact_keyword_still_blocked(self, mock_settings_cls):
        """Exact keyword 'delete' as a standalone word is still blocked."""
        mock_settings_cls.return_value.forbidden_keywords = "drop,delete,truncate,alter"
        assert is_query_safe("DELETE FROM users WHERE id=1") is False


# ---------------------------------------------------------------------------
# is_due
# ---------------------------------------------------------------------------

class TestIsDue:
    def _make_query(self, cron="* * * * *", last_executed=None):
        q = MagicMock()
        q.cron_schedule = cron
        q.last_executed = last_executed
        return q

    def test_never_executed(self):
        q = self._make_query(last_executed=None)
        assert is_due(q) is True

    def test_due_now(self):
        past = datetime.datetime(2020, 1, 1, tzinfo=datetime.timezone.utc)
        q = self._make_query(cron="* * * * *", last_executed=past)
        assert is_due(q) is True

    def test_not_due_yet(self):
        # Last executed just now, yearly cron — not due
        now = datetime.datetime.now(tz=datetime.timezone.utc)
        q = self._make_query(cron="0 0 1 1 *", last_executed=now)
        assert is_due(q) is False

    def test_naive_datetime_handled(self):
        """Naive last_executed gets UTC tzinfo added."""
        past = datetime.datetime(2020, 1, 1)  # naive
        q = self._make_query(cron="* * * * *", last_executed=past)
        assert is_due(q) is True


# ---------------------------------------------------------------------------
# execute_scheduled_query — timeout
# ---------------------------------------------------------------------------

class TestQueryTimeout:
    """Verify that a slow query triggers the timeout path."""

    @patch("fastpluggy_plugin.scheduled_query.tasks.ScheduledQuerySettings")
    @patch("fastpluggy_plugin.scheduled_query.tasks.session_scope")
    def test_timeout_creates_history_and_sets_last_result(
        self, mock_session_scope, mock_settings_cls
    ):
        # Configure settings with a very short timeout
        settings = MagicMock()
        settings.query_timeout = 0.1
        settings.forbidden_keywords = "drop,delete,truncate,alter"
        settings.enable_history = True
        mock_settings_cls.return_value = settings

        # Build a fake scheduled_query row
        sq = MagicMock()
        sq.id = 42
        sq.query = "SELECT pg_sleep(60)"
        sq.last_result = None
        sq.last_executed = None

        # Set up the DB session mock
        db = MagicMock()
        db.query.return_value.filter.return_value.first.return_value = sq

        # Make db.execute block longer than the timeout
        def slow_execute(*args, **kwargs):
            time.sleep(5)

        db.execute.side_effect = slow_execute

        ctx = MagicMock()
        ctx.__enter__ = MagicMock(return_value=db)
        ctx.__exit__ = MagicMock(return_value=False)
        mock_session_scope.return_value = ctx

        # Run the coroutine
        asyncio.run(execute_scheduled_query(42))

        # Verify rollback was called (not commit for the query)
        db.rollback.assert_called_once()

        # Verify last_result was set to timeout message
        assert "timeout" in sq.last_result.lower()
        assert sq.last_executed is not None

        # Verify history record was added with status="timeout"
        add_calls = db.add.call_args_list
        history_added = [
            c for c in add_calls
            if hasattr(c[0][0], 'status') and c[0][0].status == "timeout"
        ]
        assert len(history_added) == 1
        history_obj = history_added[0][0][0]
        assert history_obj.scheduled_query_id == 42
        assert history_obj.status == "timeout"
        assert history_obj.duration_ms is not None
        assert "timeout" in history_obj.error_message.lower()

    @patch("fastpluggy_plugin.scheduled_query.tasks.ScheduledQuerySettings")
    @patch("fastpluggy_plugin.scheduled_query.tasks.session_scope")
    def test_timeout_without_history(self, mock_session_scope, mock_settings_cls):
        """When enable_history is False, no history record is created."""
        settings = MagicMock()
        settings.query_timeout = 0.1
        settings.forbidden_keywords = "drop,delete,truncate,alter"
        settings.enable_history = False
        mock_settings_cls.return_value = settings

        sq = MagicMock()
        sq.id = 7
        sq.query = "SELECT 1"
        sq.last_result = None
        sq.last_executed = None

        db = MagicMock()
        db.query.return_value.filter.return_value.first.return_value = sq

        def slow_execute(*args, **kwargs):
            time.sleep(5)

        db.execute.side_effect = slow_execute

        ctx = MagicMock()
        ctx.__enter__ = MagicMock(return_value=db)
        ctx.__exit__ = MagicMock(return_value=False)
        mock_session_scope.return_value = ctx

        asyncio.run(execute_scheduled_query(7))

        # last_result still set
        assert "timeout" in sq.last_result.lower()
        # No history object was added (only the scheduled_query itself via commit)
        add_calls = db.add.call_args_list
        history_added = [
            c for c in add_calls
            if hasattr(c[0][0], 'status') and c[0][0].status == "timeout"
        ]
        assert len(history_added) == 0
