"""Tests for ScheduledQueryPlugin.get_metrics() — MetricsProvider capability."""

from contextlib import contextmanager
from unittest.mock import MagicMock, patch

from fastpluggy.core.metrics import MetricEntry, MetricsProvider, MetricsResult

from fastpluggy_plugin.scheduled_query.plugin import ScheduledQueryPlugin


def _make_gauge(value: float, doc: str = "") -> MagicMock:
    gauge = MagicMock()
    gauge._value.get.return_value = value
    gauge._documentation = doc
    return gauge


@contextmanager
def _clean_metrics(**overrides):
    """Patch all module-level metric state so tests are isolated."""
    defaults = {
        "fastpluggy_plugin.scheduled_query.metrics.prometheus_gauges": overrides.get("prometheus_gauges", {}),
        "fastpluggy_plugin.scheduled_query.metrics.execution_counters": overrides.get("execution_counters", {
            "executions_total": 0, "successes_total": 0,
            "failures_total": 0, "timeouts_total": 0,
        }),
        "fastpluggy_plugin.scheduled_query.metrics.per_query_last_duration": overrides.get("per_query_last_duration", {}),
        "fastpluggy_plugin.scheduled_query.metrics.per_query_avg_duration": overrides.get("per_query_avg_duration", {}),
    }
    patches = [patch.dict(k, v, clear=True) for k, v in defaults.items()]
    # Also mock session_scope to avoid DB access for summary gauges
    mock_session = MagicMock()
    mock_session.__enter__ = MagicMock(return_value=MagicMock(**{"query.return_value.count.return_value": 0, "query.return_value.filter.return_value.count.return_value": 0}))
    mock_session.__exit__ = MagicMock(return_value=False)
    patches.append(patch("fastpluggy.core.database.session_scope", return_value=mock_session))
    for p in patches:
        p.start()
    try:
        yield
    finally:
        for p in patches:
            p.stop()


class TestCapabilitiesDeclaration:
    def test_metrics_in_capabilities(self):
        plugin = ScheduledQueryPlugin()
        assert "metrics" in plugin.capabilities

    def test_satisfies_metrics_provider_protocol(self):
        plugin = ScheduledQueryPlugin()
        assert isinstance(plugin, MetricsProvider)


class TestGetMetricsEmpty:
    def test_returns_empty_result(self):
        with _clean_metrics():
            plugin = ScheduledQueryPlugin()
            result = plugin.get_metrics()

        assert isinstance(result, MetricsResult)
        # Only summary gauges (queries_configured, queries_enabled) + counters
        user_gauges = [g for g in result.gauges if g.name not in ("queries_configured", "queries_enabled")]
        assert user_gauges == []

    def test_counters_present_even_when_zero(self):
        with _clean_metrics():
            plugin = ScheduledQueryPlugin()
            result = plugin.get_metrics()

        assert len(result.counters) == 4
        assert all(c.value == 0.0 for c in result.counters)


class TestGetMetricsSingleGauge:
    def test_single_gauge_returned(self):
        with _clean_metrics(prometheus_gauges={"active_users": _make_gauge(42.0, "Active user count")}):
            plugin = ScheduledQueryPlugin()
            result = plugin.get_metrics()

        user_gauges = [g for g in result.gauges if g.name == "active_users"]
        assert len(user_gauges) == 1
        entry = user_gauges[0]
        assert isinstance(entry, MetricEntry)
        assert entry.value == 42.0
        assert entry.type == "gauge"
        assert entry.help == "Active user count"
        assert entry.labels == {}

    def test_counters_always_present(self):
        with _clean_metrics(prometheus_gauges={"some_gauge": _make_gauge(1.0)}):
            plugin = ScheduledQueryPlugin()
            result = plugin.get_metrics()

        assert len(result.counters) == 4
        assert result.histograms == []


class TestGetMetricsMultipleGauges:
    def test_multiple_gauges(self):
        gauges = {
            "order_count": _make_gauge(150.0, "Total orders"),
            "error_rate": _make_gauge(0.03, "Error rate"),
            "queue_depth": _make_gauge(7.0, "Queue depth"),
        }
        with _clean_metrics(prometheus_gauges=gauges):
            plugin = ScheduledQueryPlugin()
            result = plugin.get_metrics()

        user_gauges = [g for g in result.gauges if g.name in ("order_count", "error_rate", "queue_depth")]
        assert len(user_gauges) == 3
        names = {e.name for e in user_gauges}
        assert names == {"order_count", "error_rate", "queue_depth"}

        by_name = {e.name: e for e in user_gauges}
        assert by_name["order_count"].value == 150.0

    def test_all_entries_includes_counters_and_gauges(self):
        gauges = {"metric_a": _make_gauge(1.0), "metric_b": _make_gauge(2.0)}
        with _clean_metrics(prometheus_gauges=gauges):
            plugin = ScheduledQueryPlugin()
            result = plugin.get_metrics()

        # all_entries = gauges + counters
        assert len(result.all_entries) > 2  # at least 2 user gauges + 4 counters + 2 summary


class TestGetMetricsZeroAndNegativeValues:
    def test_zero_value(self):
        with _clean_metrics(prometheus_gauges={"zero_metric": _make_gauge(0.0)}):
            plugin = ScheduledQueryPlugin()
            result = plugin.get_metrics()

        entry = next(g for g in result.gauges if g.name == "zero_metric")
        assert entry.value == 0.0

    def test_negative_value(self):
        with _clean_metrics(prometheus_gauges={"neg_metric": _make_gauge(-5.5)}):
            plugin = ScheduledQueryPlugin()
            result = plugin.get_metrics()

        entry = next(g for g in result.gauges if g.name == "neg_metric")
        assert entry.value == -5.5


class TestGetMetricsExecutionCounters:
    def test_counters_returned(self):
        with _clean_metrics(execution_counters={
            "executions_total": 10, "successes_total": 8,
            "failures_total": 1, "timeouts_total": 1,
        }):
            plugin = ScheduledQueryPlugin()
            result = plugin.get_metrics()

        counter_names = {c.name for c in result.counters}
        assert "executions_total" in counter_names
        by_name = {c.name: c for c in result.counters}
        assert by_name["executions_total"].value == 10.0

    def test_per_query_duration_labels(self):
        with _clean_metrics(
            per_query_last_duration={"daily_report": 250.0},
            per_query_avg_duration={"daily_report": (500.0, 2)},
        ):
            plugin = ScheduledQueryPlugin()
            result = plugin.get_metrics()

        duration_entries = [g for g in result.gauges if g.name == "last_duration_ms"]
        assert len(duration_entries) == 1
        assert duration_entries[0].labels == {"query_name": "daily_report"}
        assert duration_entries[0].value == 250.0

        avg_entries = [g for g in result.gauges if g.name == "avg_duration_ms"]
        assert len(avg_entries) == 1
        assert avg_entries[0].value == 250.0  # 500/2
