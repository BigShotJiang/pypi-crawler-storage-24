# Copyright 2026 Invoke Labs, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Event related payloads and responses."""

from typing import NotRequired, Required, TypedDict


class ClientCreateEventPayload(TypedDict):
    """Create an event.

    See [Creating an Event](https://app.voker.ai/docs/concepts/events#creating-an-event-via-sdk) for more information.
    """

    event_name: Required[str]
    properties: Required[EventProperties]

    agent: NotRequired[str]
    """The name of the [agent](https://app.voker.ai/docs/concepts/agents#agents) associated with the event.

    If this agent does not exist, it will be created. If an agent is not supplied, a default agent will be used.
    """

    agent_version: NotRequired[str]
    """The name of the [agent version](https://app.voker.ai/docs/concepts/agents#agent-versions) associated with the event.

    If this agent version does not exist, it will be created. If an agent version is not supplied, a default version will be used.
    """

    person: NotRequired[str]
    """The unique identifier of the [person](https://app.voker.ai/docs/concepts/people) associated with the event.

    If the person does not exist, it will be created.
    """

    session: NotRequired[str]
    """The unique identifier of the [session](https://app.voker.ai/docs/concepts/events#event-sessions) associated with the event.

    If the session does not exist, it will be created.
    """


class CreateEventPayload(ClientCreateEventPayload):
    """Create an event.

    See [Creating an Event](https://app.voker.ai/docs/concepts/events#creating-an-event-via-sdk) for more information.
    """

    fingerprint_id: Required[str]
    """The [fingerprint](https://app.voker.ai/docs/concepts/events#fingerprints) of the client that generated the event.
"""


EventProperties = dict
