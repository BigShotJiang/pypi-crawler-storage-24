# Copyright 2026 Invoke Labs, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Person related models."""

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Literal, Self, TypedDict


@dataclass
class Person:
    """Represents a person.

    See [People](https://app.voker.ai/docs/concepts/people) for more information.
    """

    person_id: str
    properties: dict[str, Any] | None
    created_at: datetime

    @classmethod
    def deserialize(cls, data: dict[str, Any]) -> Self:
        """TODO."""
        return cls(
            person_id=data["person_id"],
            properties=data["properties"],
            created_at=datetime.fromisoformat(data["created_at"]),
        )


class PersonNotFoundResponse(TypedDict):
    """TODO."""

    type: Literal["person-not-found"] = "person-not-found"


class PersonNotFoundError(Exception):
    """TODO."""
