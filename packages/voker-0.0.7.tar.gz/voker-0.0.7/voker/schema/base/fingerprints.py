# Copyright 2026 Invoke Labs, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Fingerprint related models."""

from dataclasses import dataclass
from typing import Any, Literal, Self, TypedDict


class FingerprintNotFoundResponse(TypedDict):
    """TODO."""

    type: Literal["fingerprint-not-found"] = "fingerprint-not-found"


class FingerprintNotFoundError(Exception):
    """TODO."""


@dataclass
class Fingerprint:
    """Represents a fingerprint.

    See [Fingerprints](https://app.voker.ai/docs/concepts/events#fingerprints) for more information.
    """

    fingerprint_id: str

    @classmethod
    def deserialize(cls, data: dict[str, Any]) -> Self:
        """TODO."""
        return cls(fingerprint_id=data["fingerprint_id"])
