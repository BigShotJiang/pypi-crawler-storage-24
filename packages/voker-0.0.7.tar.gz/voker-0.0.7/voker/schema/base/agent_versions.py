# Copyright 2026 Invoke Labs, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Agent version related models."""

from dataclasses import dataclass
from datetime import datetime
from typing import Any, Literal, Self, TypedDict


@dataclass
class AgentVersion:
    """Represents an agent version.

    See [Agent Versions](https://app.voker.ai/docs/concepts/agents#agent-versions) for more information.
    """

    agent_version_name: str
    """Unique identifier for the agent version within its agent."""

    description: str | None

    agent_version_number: int
    """Unique number assigned to the agent version within its agent."""

    created_at: datetime
    deprecated_at: datetime | None

    @classmethod
    def deserialize(cls, data: dict[str, Any]) -> Self:
        """TODO."""
        return cls(
            agent_version_name=data["agent_version_name"],
            description=data["description"],
            agent_version_number=data["agent_version_number"],
            created_at=datetime.fromisoformat(data["created_at"]),
            deprecated_at=(
                datetime.fromisoformat(data["deprecated_at"])
                if data["deprecated_at"] is not None
                else None
            ),
        )


class AgentVersionNotFoundResponse(TypedDict):
    """TODO."""

    type: Literal["agent-version-not-found"] = "agent-version-not-found"


class AgentVersionNotFoundError(Exception):
    """TODO."""
