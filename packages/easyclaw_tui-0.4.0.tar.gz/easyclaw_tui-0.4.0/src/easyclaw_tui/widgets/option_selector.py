"""Selectable option list widget for config choices (model, channel, etc.)."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.widget import Widget
from textual.widgets import Static, OptionList
from textual.widgets.option_list import Option
from textual.message import Message


class OptionSelector(Widget):
    """Vertical list of selectable options."""

    class OptionSelected(Message):
        """An option was selected."""

        def __init__(self, key: str, value: str, label: str) -> None:
            super().__init__()
            self.key = key
            self.value = value
            self.label = label

    def __init__(
        self,
        title: str,
        options: list[tuple[str, str, str]],  # (value, label, description)
        key: str = "",
        default: str = "",
    ) -> None:
        super().__init__()
        self.title = title
        self.options = options
        self.key = key
        self.default = default

    def compose(self) -> ComposeResult:
        yield Static(f"[bold #f59e0b]{self.title}[/bold #f59e0b]")
        items = []
        for value, label, desc in self.options:
            marker = " (default)" if value == self.default else ""
            text = f"{label}{marker}"
            if desc:
                text += f" — {desc}"
            items.append(Option(text, id=value))
        yield OptionList(*items, id="option-list")

    def on_option_list_option_selected(self, event: OptionList.OptionSelected) -> None:
        value = event.option.id
        label = str(event.option.prompt)
        self.post_message(self.OptionSelected(self.key, value, label))
