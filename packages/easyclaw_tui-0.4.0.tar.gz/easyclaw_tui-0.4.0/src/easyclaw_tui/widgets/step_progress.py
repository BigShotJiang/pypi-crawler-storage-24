"""Sidebar widget showing step progress."""

from __future__ import annotations

from textual.app import ComposeResult
from textual.widget import Widget
from textual.widgets import Static
from textual.reactive import reactive

from easyclaw_tui.state import InstallState, StepStatus


ICONS = {
    StepStatus.PENDING: "○",
    StepStatus.ACTIVE: "●",
    StepStatus.RUNNING: "◉",
    StepStatus.SUCCESS: "✓",
    StepStatus.FAILED: "✗",
    StepStatus.SKIPPED: "–",
}


class StepProgress(Widget):
    """Left sidebar showing all 15 steps and their status."""

    DEFAULT_CSS = ""

    def __init__(self, state: InstallState) -> None:
        super().__init__()
        self.state = state

    def compose(self) -> ComposeResult:
        yield Static("EasyClaw", id="progress-header")
        for step in self.state.steps:
            icon = ICONS[step.status]
            label = f" {icon} {step.number:2d}. {step.name}"
            item = Static(label, classes="step-item")
            item.id = f"step-{step.number}"
            yield item

    def refresh_steps(self) -> None:
        """Update step display to reflect current state."""
        for step in self.state.steps:
            widget = self.query_one(f"#step-{step.number}", Static)
            icon = ICONS[step.status]
            widget.update(f" {icon} {step.number:2d}. {step.name}")
            # Update CSS classes
            widget.remove_class("--active", "--success", "--failed", "--running", "--pending")
            widget.add_class(f"--{step.status.value}")
