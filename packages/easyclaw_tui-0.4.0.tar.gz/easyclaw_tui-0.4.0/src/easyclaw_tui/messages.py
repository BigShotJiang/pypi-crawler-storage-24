"""Custom Textual messages for agent-install communication."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from typing import Any

from textual.message import Message

from easyclaw_tui.steps.base import StepResult


class InstallStepStarted(Message):
    """A step has begun."""

    def __init__(self, step_num: int, name: str) -> None:
        super().__init__()
        self.step_num = step_num
        self.name = name


class InstallStepCompleted(Message):
    """A step finished (success/fail/skip)."""

    def __init__(self, step_num: int, name: str, result: StepResult) -> None:
        super().__init__()
        self.step_num = step_num
        self.name = name
        self.result = result


class InstallFinished(Message):
    """All 15 steps complete."""

    def __init__(self, all_passed: bool) -> None:
        super().__init__()
        self.all_passed = all_passed


class AgentResponse(Message):
    """Agent produced a text response to display."""

    def __init__(self, text: str) -> None:
        super().__init__()
        self.text = text


class AgentToolCall(Message):
    """Agent is calling a tool (for inline visibility)."""

    def __init__(self, name: str, args: dict[str, Any]) -> None:
        super().__init__()
        self.name = name
        self.args = args


class AgentThinking(Message):
    """Agent is processing (show indicator)."""

    def __init__(self) -> None:
        super().__init__()


class AgentReady(Message):
    """Agent finished processing (hide indicator)."""

    def __init__(self) -> None:
        super().__init__()


class UserConfirmRequest(Message):
    """Agent's ask_user tool needs user input in TUI."""

    def __init__(
        self,
        question: str,
        response_event: asyncio.Event,
        response_holder: list[str],
    ) -> None:
        super().__init__()
        self.question = question
        self.response_event = response_event
        self.response_holder = response_holder


class ChatSubmitted(Message):
    """User submitted a chat message."""

    def __init__(self, text: str) -> None:
        super().__init__()
        self.text = text
