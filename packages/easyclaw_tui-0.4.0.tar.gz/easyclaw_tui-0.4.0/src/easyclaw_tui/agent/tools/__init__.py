"""Agent tools — register all tools at import time."""

from __future__ import annotations

from easyclaw_tui.agent.tools.registry import register
from easyclaw_tui.agent.tools import shell, files, mcp, confirm

# Register local tools
register("run_command", shell.run_command)
register("read_file", files.read_file)
register("write_file", files.write_file)
register("edit_file", files.edit_file)
register("list_directory", files.list_directory)
register("ask_user", confirm.ask_user)

# Register MCP tools
register("mcp_search_knowledge", mcp.mcp_search_knowledge)
register("mcp_get_full_guide", mcp.mcp_get_full_guide)
register("mcp_get_model_recommendation", mcp.mcp_get_model_recommendation)
register("mcp_validate_config", mcp.mcp_validate_config)
register("mcp_recommend_skills", mcp.mcp_recommend_skills)
register("mcp_security_audit", mcp.mcp_security_audit)
register("mcp_estimate_cost", mcp.mcp_estimate_cost)
register("mcp_generate_config", mcp.mcp_generate_config)
register("mcp_search_web", mcp.mcp_search_web)
register("mcp_diagnose_issue", mcp.mcp_diagnose_issue)
register("mcp_validate_deployment", mcp.mcp_validate_deployment)
register("mcp_get_foreman_config", mcp.mcp_get_foreman_config)
register("mcp_troubleshoot_gateway", mcp.mcp_troubleshoot_gateway)


# Register install logs tool (wrapper for install_runner.get_logs_for_step)
async def _get_install_logs(step_num: int = 0) -> str:
    from easyclaw_tui.install_runner import get_logs_for_step
    return get_logs_for_step(step_num)


register("get_install_logs", _get_install_logs)
