"""User confirmation tool — ask before risky operations."""

from __future__ import annotations

from typing import Callable, Awaitable, Optional

# Callback: takes question string, returns "approved" or "denied"
# Set by REPL (interactive) or daemon (auto-approve)
_confirm_callback: Optional[Callable[[str], Awaitable[str]]] = None


def set_confirm_callback(cb: Callable[[str], Awaitable[str]]) -> None:
    """Set the confirmation callback. Called by REPL or daemon at startup."""
    global _confirm_callback
    _confirm_callback = cb


async def ask_user(question: str) -> str:
    """Ask the user for confirmation before a risky operation.

    Returns 'approved' or 'denied'.
    If no callback is set, defaults to 'approved' (daemon/headless mode).
    """
    if _confirm_callback is None:
        return "approved (no interactive session — auto-approved)"

    try:
        return await _confirm_callback(question)
    except Exception as e:
        return f"Error getting confirmation: {e}. Proceeding with caution."
