"""Main EasyClaw TUI application."""

from __future__ import annotations

from textual.app import App, ComposeResult
from textual.binding import Binding

from easyclaw_tui.state import InstallState

# Re-export for convenience
from easyclaw_tui.state import StepStatus, StepInfo, MODEL_MAP  # noqa: F401


class EasyClawApp(App):
    """EasyClaw interactive installer."""

    TITLE = "EasyClaw"
    SUB_TITLE = "Agent Johnny 5"
    CSS_PATH = "styles/app.tcss"

    BINDINGS = [
        Binding("q", "quit", "Quit", show=True),
        Binding("ctrl+c", "quit", "Quit", show=False),
    ]

    def __init__(
        self,
        mode: str = "install",
        api_key: str = "",
        openrouter_key: str = "",
        openai_key: str = "",
        model: str = "",
        channel: str = "none",
        bind: str = "lan",
    ) -> None:
        super().__init__()
        self.install_state = InstallState(
            api_key=api_key,
            openrouter_key=openrouter_key,
            openai_key=openai_key,
            model=model,
            channel=channel,
            bind=bind,
        )
        self.mode = mode

    def on_mount(self) -> None:
        if self.mode == "help":
            from easyclaw_tui.screens.help import HelpScreen

            self.push_screen(HelpScreen(self.install_state))
        else:
            from easyclaw_tui.screens.install import InstallScreen

            self.push_screen(InstallScreen(self.install_state))
