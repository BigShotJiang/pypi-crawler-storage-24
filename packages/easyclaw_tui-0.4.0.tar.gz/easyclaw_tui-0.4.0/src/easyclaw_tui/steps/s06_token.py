"""Step 6: Generate gateway auth token."""

from __future__ import annotations

import secrets

from easyclaw_tui.steps.base import BaseStep, StepResult


class TokenStep(BaseStep):
    STEP_NUM = 6
    STEP_NAME = "Token"

    async def run(self) -> StepResult:
        token = f"oc_{secrets.token_hex(16)}"
        self.state.gateway_token = token
        self.ok("Gateway token generated")
        return StepResult(True)
