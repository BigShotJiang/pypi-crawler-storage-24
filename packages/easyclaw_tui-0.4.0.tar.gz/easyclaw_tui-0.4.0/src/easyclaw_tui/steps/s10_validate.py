"""Step 10: Validate configuration."""

from __future__ import annotations

from easyclaw_tui.steps.base import BaseStep, StepResult


class ValidateStep(BaseStep):
    STEP_NUM = 10
    STEP_NAME = "Validate"

    async def run(self) -> StepResult:
        # Clean JSON (fix trailing commas from empty blocks)
        await self.run_cmd(
            'python3 -c "'
            "import json; "
            "f=open('$HOME/.openclaw/openclaw.json'); "
            "d=json.load(f); f.close(); "
            "f=open('$HOME/.openclaw/openclaw.json','w'); "
            "json.dump(d,f,indent=2); f.close(); "
            "print('JSON validated')"
            '" 2>&1 || true'
        )

        # Run openclaw config validate
        rc, out, _ = await self.run_cmd("openclaw config validate 2>&1")
        if "error" in out.lower():
            self.warn("Config validation found issues — check: openclaw config validate")
        else:
            self.ok("Config validates successfully")

        return StepResult(True)
