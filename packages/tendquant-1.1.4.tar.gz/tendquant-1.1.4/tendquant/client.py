import os
import ssl
import json
import time
import random
import string
import logging
from datetime import datetime
import paho.mqtt.client as mqtt
from typing import Callable, Optional, Any

from .log import setup_logger

VERSION = "1.1.4"

class Client:
    """
    tendQuant MQTT 客户端
    """
    
    # 定义不可重连的错误码
    NO_RECONNECT_CODES = [4, 5, 135]
    
    def __init__(
        self, 
        username: str, 
        password: str, 
        log_level: int = logging.INFO,
        use_colors: bool = True,
        output_dir: Optional[str] = None
    ):
        """
        初始化MQTT客户端

        使用前请通过官网注册账号并获取用户名和密码
        官网地址：https://tendquant.cn

        Args:
            username: MQTT用户名
            password: MQTT密码
            log_level: 日志级别
            use_colors: 是否使用彩色日志
            output_dir: 数据保存目录
        """
        # 配置日志 - 使用简化格式
        self.logger = setup_logger(
            name=f"MQTT",
            level=log_level,
            use_colors=use_colors,
            log_format='%(asctime)s - %(levelname)s - %(message)s'
        )
        
        self.username = username
        self.password = password
        self.port = 443
        self.path = "/mqtt"
        self.save_data = False
        self.subscribe_info = {}
        
        # 设置输出目录
        if output_dir is not None:
            self.save_data  = True
            self.output_dir = os.path.join(output_dir, datetime.now().strftime("%Y%m%d"))
            os.makedirs(self.output_dir, exist_ok=True)
            self.logger.debug(f"数据保存目录: {self.output_dir}")
        
        # 生成唯一的客户端ID
        random_suffix = ''.join(random.choices(string.ascii_letters + string.digits, k=12))
        self.client_id = f"pyclient_{random_suffix}_v{VERSION}"
        
        self.clean_start = True
        
        # 创建MQTT v5客户端
        self.client = mqtt.Client(
            client_id=self.client_id,
            protocol=mqtt.MQTTv5,
            transport="websockets" if self.port == 443 else "tcp"
        )
        
        # 设置回调函数
        self.client.on_connect = self._on_connect
        self.client.on_disconnect = self._on_disconnect
        self.client.on_message = self._on_message
        self.client.on_publish = self._on_publish
        self.client.on_subscribe = self._on_subscribe
        
        # 设置认证信息
        self.client.username_pw_set(username, password)
        
        # WebSocket路径设置
        if self.port == 443:
            self.client.ws_set_options(path=self.path)
        
        # 存储消息回调函数
        self.message_callback: Optional[Callable] = None
        self.connected = False
        self.auth_failed = False
        self.connect_error_code = None
        
        # 用于存储每个主题的文件句柄，实现按主题分文件保存
        self.topic_files = {}
        
    def _get_topic_filename(self, topic: str) -> str:
        """
        根据主题生成文件名
        
        Args:
            topic: 主题名称
            
        Returns:
            str: 文件名
        """
        # 替换主题中的特殊字符为下划线
        safe_topic = topic.replace('/', '_').replace('#', 'all').replace('+', 'plus')
        # 限制文件名长度
        if len(safe_topic) > 200:
            safe_topic = safe_topic[:200]
        return f"{safe_topic}.jsonl"
    
    def _save_message(self, topic: str, payload: Any, timestamp: float):
        """
        保存消息到文件
        
        Args:
            topic: 主题名称
            payload: 消息内容
            timestamp: 时间戳
        """
        if not self.save_data:
            return
        
        try:
            # 准备数据
            data = {
                "topic": topic,
                "timestamp": timestamp,
                "datetime": datetime.fromtimestamp(timestamp).strftime('%Y-%m-%d %H:%M:%S.%f'),
                "payload": payload
            }
            
            # 如果payload是字符串，尝试解析为JSON
            if isinstance(payload, str):
                try:
                    data["payload"] = json.loads(payload)
                except:
                    data["payload"] = payload
            
            # 生成文件名
            filename = self._get_topic_filename(topic)
            filepath = os.path.join(self.output_dir, filename)
            
            # 写入文件
            with open(filepath, 'a', encoding='utf-8') as f:
                f.write(json.dumps(data, ensure_ascii=False) + '\n')
                
        except Exception as e:
            self.logger.error(f"保存消息失败: {e}")
    
    def _on_connect(self, client, userdata, flags, rc, properties=None):
        """
        连接回调函数
        """
        rc_value = rc.value if hasattr(rc, 'value') else rc
        
        if rc_value == 0:
            self.connected = True
            self.auth_failed = False
            self.connect_error_code = None
        else:
            self.connected = False
            self.connect_error_code = rc_value
            
            rc_messages = {
                0: "连接成功",
                1: "协议版本不支持",
                2: "客户端标识符无效",
                3: "服务器不可用",
                4: "用户名或密码错误",
                5: "未授权",
                128: "连接失败",
                135: "应用认证失败"
            }
            error_msg = rc_messages.get(rc_value, f'未知错误码: {rc_value}')
            self.logger.error(error_msg)
            
            if rc_value in self.NO_RECONNECT_CODES:
                self.auth_failed = True
                self.logger.warning("请检查:")
                self.logger.warning("  1. 用户名是否正确")
                self.logger.warning("  2. 密码是否正确")
                self.logger.warning("  3. 账号是否已过期")
                self.logger.warning("  4. 是否超过最大连接数，创建的应用默认连接数为 1，可以进入应用管理界面修改")
            
    def _on_disconnect(self, client, userdata, rc, properties=None):
        """
        断开连接回调函数
        """
        self.connected = False
        rc_value = rc.value if hasattr(rc, 'value') else rc
        
        if rc_value == 0:
            self.logger.info("已正常断开连接")
        else:
            if not self.auth_failed:
                if rc_value:
                    self.logger.warning(f"异常断开连接，返回码: {rc_value}")
                    if hasattr(rc, 'getName'):
                        self.logger.warning(f"详细信息: {rc.getName()}")
                else:
                    self.logger.error("服务端已主动断开连接")


    def _on_message(self, client, userdata, msg):
        """
        消息接收回调函数
        """
        try:
            # 获取当前时间戳
            timestamp = time.time()
            
            # 尝试解码消息
            payload = msg.payload.decode('utf-8')
            self.logger.debug(f"收到消息 - 主题: {msg.topic}, QoS: {msg.qos}")
            
            # 保存消息到文件
            if self.save_data:
                self._save_message(msg.topic, payload, timestamp)
                self.logger.debug(f"消息已保存 - 主题: {msg.topic}")
            
            # 调用用户自定义回调函数
            if self.message_callback:
                self.message_callback(self, userdata, msg)
            else:
                # 如果没有自定义回调，输出到控制台
                if len(payload) > 200:
                    short_payload = payload[:200] + "..."
                    self.logger.info(f"收到主题数据 {msg.topic}: {short_payload}")
                else:
                    self.logger.info(f"收到主题数据 {msg.topic}: {payload}")
                
        except UnicodeDecodeError:
            self.logger.error(f"消息解码失败 - 主题: {msg.topic}")
            # 保存原始二进制数据
            if self.save_data:
                timestamp = time.time()
                try:
                    filename = self._get_topic_filename(msg.topic)
                    filepath = os.path.join(self.output_dir, filename)
                    data = {
                        "topic": msg.topic,
                        "timestamp": timestamp,
                        "datetime": datetime.fromtimestamp(timestamp).strftime('%Y-%m-%d %H:%M:%S.%f'),
                        "payload_binary": msg.payload.hex()
                    }
                    with open(filepath, 'a', encoding='utf-8') as f:
                        f.write(json.dumps(data, ensure_ascii=False) + '\n')
                except Exception as e:
                    self.logger.error(f"保存二进制消息失败: {e}")
        except Exception as e:
            self.logger.error(f"处理消息时出错: {e}")
    
    def _on_publish(self, userdata, mid, reason_code, properties=None):
        """
        发布消息回调函数
        """
        rc_value = reason_code.value if hasattr(reason_code, 'value') else reason_code
        self.logger.debug(f"消息发布成功, 返回码: {rc_value}")
    
    def _on_subscribe(self, client, userdata, mid, reason_codes, properties=None):
        """
        订阅主题回调函数
        MQTT v5中reason_codes是ReasonCode列表
        返回码0表示成功，非0表示失败
        """
        # MQTT v5 订阅返回码含义
        subscribe_codes = {
            0: "QoS 0",
            1: "QoS 1", 
            2: "QoS 2",
            128: "未授权",
            129: "主题过滤器无效",
            130: "报文标识符无效",
            131: "不支持QoS等级",
            132: "无权限",
            135: "无订阅权限"
        }
        
        # 获取订阅的主题列表
        topics = []
        if mid in self.subscribe_info:
            topics = self.subscribe_info[mid]["topics"]
            # 清理已使用的订阅信息
            del self.subscribe_info[mid]
        
        if isinstance(reason_codes, list):
            success_count = 0
            fail_count = 0
            success_topics = []
            fail_topics = []
            results = []
            
            for i, rc in enumerate(reason_codes):
                rc_value = rc.value if hasattr(rc, 'value') else rc
                
                # 获取对应的主题名称
                topic_name = topics[i] if i < len(topics) else f"未知主题{i}"
                
                if rc_value in [0, 1, 2]:
                    success_count += 1
                    status = "成功"
                    message = subscribe_codes.get(rc_value, f"成功 (返回码: {rc_value})")
                    success_topics.append(topic_name)
                else:
                    fail_count += 1
                    status = "失败"
                    message = subscribe_codes.get(rc_value, f"失败 (返回码: {rc_value})")
                    fail_topics.append(f"{topic_name} ({message})")
                
                results.append(f"{topic_name}: {status} - {message}")
                self.logger.debug(f"订阅结果 - 主题: {topic_name}, 返回码: {rc_value}, {message}")
            
            if fail_count == 0:
                self.logger.info(f"订阅成功, 共{success_count}个主题全部订阅成功")
                self.logger.info(f"成功主题: {', '.join(success_topics)}")
            elif success_count == 0:
                self.logger.error(f"订阅失败, 共{fail_count}个主题全部订阅失败")
                self.logger.error(f"失败主题:")
                for fail_topic in fail_topics:
                    self.logger.error(f"{fail_topic}")
            else:
                self.logger.warning(f"订阅部分成功, 成功: {success_count}, 失败: {fail_count}")
                if success_topics:
                    self.logger.info(f"成功主题: {', '.join(success_topics)}")
                if fail_topics:
                    self.logger.error(f"失败主题:")
                    for fail_topic in fail_topics:
                        self.logger.error(f"{fail_topic}")
        else:
            # 单个订阅的情况
            rc_value = reason_codes.value if hasattr(reason_codes, 'value') else reason_codes
            topic_name = topics[0] if topics else "未知主题"
            
            if rc_value in [0, 1, 2]:
                message = subscribe_codes.get(rc_value, f"成功 (返回码: {rc_value})")
                self.logger.info(f"订阅成功, 主题: {topic_name}, 结果: {message}")
            else:
                message = subscribe_codes.get(rc_value, f"失败 (返回码: {rc_value})")
                self.logger.error(f"订阅失败, 主题: {topic_name}, 结果: {message}")
    
    def connect(self, on_message: Optional[Callable] = None, timeout: int = 60) -> bool:
        """
        连接到MQTT broker
        
        Args:
            on_message: 消息处理回调函数
            timeout: 连接超时时间（秒）
            
        Returns:
            bool: 连接是否成功
        """
        try:
            if self.auth_failed:
                self.logger.error("由于认证失败，拒绝重新连接。请检查用户名和密码后重新创建客户端实例。")
                return False
            
            self.message_callback = on_message
            
            if self.port == 443:
                self.client.tls_set(
                    cert_reqs=ssl.CERT_REQUIRED,
                    tls_version=ssl.PROTOCOL_TLSv1_2
                )
                self.client.tls_insecure_set(False)
            
            connect_properties = mqtt.Properties(mqtt.PacketTypes.CONNECT)
            
            self.logger.debug(f"官网地址：tendquant.cn")

            self.logger.info(f"正在连接行情服务器")
            self.logger.debug(f"用户名: {self.username}")
            self.logger.debug(f"客户端: {self.client_id}")
            
            self.client.connect(
                "quant.top2189.cn", 
                self.port, 
                keepalive=60,
                clean_start=self.clean_start,
                properties=connect_properties
            )
            
            self.client.loop_start()
            
            start_time = time.time()
            while not self.connected and (time.time() - start_time) < timeout:
                if self.auth_failed:
                    self.logger.error("认证失败，停止连接尝试")
                    self.client.loop_stop()
                    return False
                time.sleep(0.1)
            
            if self.connected:
                self.logger.info("行情服务器连接成功")
                return True
            else:
                if not self.auth_failed:
                    self.logger.error(f"连接超时（{timeout}秒）")
                return False
                
        except Exception as e:
            self.logger.error(f"连接异常: {e}")
            import traceback
            self.logger.debug(traceback.format_exc())
            return False
    
    def subscribe(self, topic: str, qos: int = 2) -> bool:
        """
        订阅主题
        
        Args:
            topic: 主题名称，支持通配符 + 和 #
            qos: QoS等级（0,1,2）
            
        Returns:
            bool: 订阅是否成功
        """
        try:
            if not self.connected:
                self.logger.error("未连接到服务器，无法订阅")
                return False
            
            # 检查是否已经订阅过该主题
            for mid, info in self.subscribe_info.items():
                if topic in info["topics"]:
                    self.logger.warning(f"已经订阅过主题 {topic}")
                    return True
            
            result, mid = self.client.subscribe(topic, qos)
            if result == mqtt.MQTT_ERR_SUCCESS:
                # 保存订阅信息
                self.subscribe_info[mid] = {
                    "topics": [topic],
                    "qos": qos
                }
                self.logger.debug(f"订阅请求已发送 - 主题: {topic} (QoS: {qos}), 消息ID: {mid}")
                return True
            else:
                self.logger.error(f"订阅请求发送失败: {result}")
                return False
                
        except Exception as e:
            self.logger.error(f"订阅异常: {e}")
            return False
    
    def unsubscribe(self, topic: str) -> bool:
        """
        取消订阅主题
        
        Args:
            topic: 主题名称
            
        Returns:
            bool: 取消订阅是否成功
        """
        try:
            if not self.connected:
                self.logger.warning("未连接到服务器，无法取消订阅")
                return False
            
            result, mid = self.client.unsubscribe(topic)
            if result == mqtt.MQTT_ERR_SUCCESS:
                self.logger.info(f"已取消订阅主题: {topic}")
                return True
            else:
                self.logger.error(f"取消订阅失败: {result}")
                return False
                
        except Exception as e:
            self.logger.error(f"取消订阅异常: {e}")
            return False
    
    def publish(
        self, 
        topic: str, 
        payload: Any, 
        qos: int = 2, 
        retain: bool = False
    ) -> bool:
        """
        发布消息
        
        Args:
            topic: 主题名称
            payload: 消息内容（支持字符串、字典、字节）
            qos: QoS等级（0,1,2）
            retain: 是否保留消息
            
        Returns:
            bool: 发布是否成功
        """
        try:
            if not self.connected:
                self.logger.warning("未连接到服务器，无法发布消息")
                return False
            
            if isinstance(payload, dict):
                payload = json.dumps(payload, ensure_ascii=False)
            elif not isinstance(payload, (str, bytes)):
                payload = str(payload)
            
            result, mid = self.client.publish(topic, payload, qos, retain)
            if result == mqtt.MQTT_ERR_SUCCESS:
                self.logger.debug(f"消息已发布 - 主题: {topic}, QoS: {qos}")
                return True
            else:
                self.logger.error(f"发布失败: {result}")
                return False
                
        except Exception as e:
            self.logger.error(f"发布异常: {e}")
            return False
    
    def disconnect(self) -> bool:
        """
        断开连接
        """
        try:
            self.logger.info("正在断开连接")
            self.client.loop_stop()
            self.client.disconnect()
            self.connected = False
            
            # 关闭所有打开的文件句柄
            self.topic_files.clear()
            
            self.logger.info("已断开连接")
            return True
        except Exception as e:
            self.logger.error(f"断开连接异常: {e}")
            return False
    
    def is_connected(self) -> bool:
        """检查连接状态"""
        return self.connected
    
    def is_auth_failed(self) -> bool:
        """检查认证是否失败"""
        return self.auth_failed
    
    def get_connect_error(self) -> Optional[int]:
        """获取连接错误码"""
        return self.connect_error_code
    
    def set_log_level(self, level: int):
        """设置日志级别"""
        self.logger.setLevel(level)
        level_names = {
            logging.DEBUG: "DEBUG",
            logging.INFO: "INFO",
            logging.WARNING: "WARNING",
            logging.ERROR: "ERROR"
        }
        self.logger.info(f"日志级别已设置为: {level_names.get(level, 'UNKNOWN')}")