# Namespace package for jazzmine
__path__ = __import__("pkgutil").extend_path(__path__, __name__)
