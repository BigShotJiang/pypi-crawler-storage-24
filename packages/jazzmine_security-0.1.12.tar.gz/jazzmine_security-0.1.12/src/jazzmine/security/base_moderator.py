from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple, Union
import asyncio
from pathlib import Path
import uuid
import time
from datetime import datetime

from jazzmine.security.errors import ModeratorError
from jazzmine.logging import BaseLogger
import torch
from torch.utils.data import Dataset, DataLoader
import torch.nn.functional as F


class BaseModerator(ABC):
    def __init__(self, logger: Optional[BaseLogger] = None):
        """Initialize BaseModerator with optional logging.
        
        Args:
            logger: Optional pre-configured BaseLogger instance to use instead of creating a new one
        """
        self.logger: Optional[BaseLogger] = logger
        self._log_context: Dict[str, Any] = {
            "moderator_class": self.__class__.__name__,
        }
        
    
    @abstractmethod
    def classify(self, text: str) -> Tuple[str, float]:
        pass

    @abstractmethod
    def classify_batch(self, texts: List[str], batch_size: int = 32) -> List[Tuple[str, float]]:
        pass

    @dataclass
    class _BatchRequest:
        payload: Any
        future: asyncio.Future

    async def classify_async(self, text: str, timeout: Optional[float] = None) -> Tuple[str, float]:
        if getattr(self, "_batch_queue", None) is not None:
            loop = asyncio.get_running_loop()
            fut = loop.create_future()
            req = BaseModerator._BatchRequest(payload=text, future=fut)
            try:
                self._batch_queue.put_nowait(req)
            except asyncio.QueueFull:
                if self.logger:
                    self.logger.error(
                        "Batch queue full",
                        action="classify_async",
                        suggested_fix="backpressure or increase queue size"
                    )
                raise ModeratorError("Batch queue full - backpressure or increase queue size")
            try:
                return await asyncio.wait_for(fut, timeout=timeout)
            except asyncio.TimeoutError:
                fut.cancel()
                if self.logger:
                    self.logger.error(
                        "Request timed out",    
                        action="classify_async"
                    )
                raise ModeratorError("Request timed out")

        try:
            return await asyncio.wait_for(asyncio.to_thread(self.classify, text), timeout=timeout)
        except asyncio.TimeoutError:
            if self.logger:
                self.logger.error(
                    "Request timed out",
                    action="classify_async"
                )
            raise ModeratorError("Request timed out")

    async def classify_batch_async(self, texts: List[str], batch_size: int = 32, timeout: Optional[float] = None) -> List[Tuple[str, float]]:
        if getattr(self, "_batch_queue", None) is not None:
            loop = asyncio.get_running_loop()
            fut = loop.create_future()
            req = BaseModerator._BatchRequest(payload=(texts, batch_size), future=fut)
            try:
                self._batch_queue.put_nowait(req)
            except asyncio.QueueFull:
                if self.logger:
                    self.logger.error(
                        "Batch queue full",
                        action="classify_batch_async",
                        suggested_fix="backpressure or increase queue size"
                    )
                raise ModeratorError("Batch queue full - backpressure or increase queue size")
            try:
                return await asyncio.wait_for(fut, timeout=timeout)
            except asyncio.TimeoutError:
                fut.cancel()
                if self.logger:
                    self.logger.error(
                        "Request timed out",
                        action="classify_batch_async"
                    )
                raise ModeratorError("Request timed out")

        return await asyncio.to_thread(self.classify_batch, texts, batch_size)

    async def start_batch_worker(self, *, max_batch_size: int = 32, max_wait_ms: int = 50, queue_maxsize: int = 1000) -> None:
        if getattr(self, "_batch_queue", None) is not None:
            return
        
        if self.logger:
            self.logger.info(
                "Batch worker started",
                max_batch_size=max_batch_size,
                max_wait_ms=max_wait_ms,
                queue_maxsize=queue_maxsize
            )
        
        self._batch_queue: asyncio.Queue = asyncio.Queue(maxsize=queue_maxsize)
        self._batch_stop: asyncio.Event = asyncio.Event()
        self._batch_worker_task: asyncio.Task = asyncio.create_task(
            self._batch_worker_loop(max_batch_size=max_batch_size, max_wait_ms=max_wait_ms)
        )

    async def stop_batch_worker(self, *, drain: bool = True) -> None:
        q = getattr(self, "_batch_queue", None)
        task = getattr(self, "_batch_worker_task", None)
        stop_ev = getattr(self, "_batch_stop", None)
        if q is None or task is None or stop_ev is None:
            return
        
        if self.logger:
            self.logger.info(
                "Stopping batch worker",
                drain=drain,
                queue_depth=q.qsize()
            )
        if not drain:
            while not q.empty():
                try:
                    req = q.get_nowait()
                except asyncio.QueueEmpty:
                    break
                if not req.future.done():
                    req.future.set_exception(ModeratorError("Batch worker stopped before processing request"))
                    if self.logger:
                        self.logger.warning(
                            "Batch request dropped due to immediate shutdown",
        
                        )

        stop_ev.set()
        try:
            await task
        except asyncio.CancelledError:
            if self.logger:
                self.logger.warning(
                    "Batch worker task cancelled during shutdown",
                    
                )
            pass

        del self._batch_queue
        del self._batch_worker_task
        del self._batch_stop
        
        if self.logger:
            self.logger.info("Batch worker stopped", )

    async def _batch_worker_loop(self, max_batch_size: int, max_wait_ms: int) -> None:
        q: asyncio.Queue = self._batch_queue
        stop_ev: asyncio.Event = self._batch_stop
        loop = asyncio.get_running_loop()
        try:
            while True:
                if stop_ev.is_set() and q.empty():
                    if self.logger:
                        self.logger.info(
                            "Batch worker stopping - stop event set and queue empty",
                            
                        )
                    break

                get_task = asyncio.create_task(q.get())
                stop_task = asyncio.create_task(stop_ev.wait())
                done, pending = await asyncio.wait({get_task, stop_task}, return_when=asyncio.FIRST_COMPLETED)

                if stop_task in done:
                    get_task.cancel()
                    break

                stop_task.cancel()
                try:
                    first_req: BaseModerator._BatchRequest = get_task.result()
                except asyncio.CancelledError:
                    continue

                if first_req.future.cancelled():
                    if self.logger:
                        self.logger.warning(
                            "Batch request future was cancelled before processing",
                        )
                    continue

                batch = [first_req]
                batch_start = loop.time()
                deadline = batch_start + (max_wait_ms / 1000.0)

                while len(batch) < max_batch_size:
                    timeout = max(0.0, deadline - loop.time())
                    if timeout <= 0:
                        if self.logger:
                            self.logger.debug(
                                "Max wait time reached for batch",
            
                                batch_size=len(batch),
                                queue_depth=q.qsize()
                            )
                        break
                    get_task = asyncio.create_task(q.get())
                    stop_task = asyncio.create_task(stop_ev.wait())
                    done, pending = await asyncio.wait({get_task, stop_task}, return_when=asyncio.FIRST_COMPLETED, timeout=timeout)
                    if not done:
                        get_task.cancel()
                        stop_task.cancel()
                        break
                    if stop_task in done:
                        get_task.cancel()
                        stop_task.cancel()
                        break
                    stop_task.cancel()
                    try:
                        req = get_task.result()
                    except asyncio.CancelledError:
                        continue
                    if req.future.cancelled():
                        if self.logger:
                            self.logger.warning(
                                "Batch request future was cancelled before processing",
                            )
                        continue
                    batch.append(req)

                payloads = [r.payload for r in batch]
                grouped = any(isinstance(p, tuple) for p in payloads)
                if grouped:
                    all_texts = []
                    mapping: List[Tuple[int, int]] = []
                    for req_idx, p in enumerate(payloads):
                        if isinstance(p, tuple):
                            inner_texts, _ = p
                            for inner_idx, txt in enumerate(inner_texts):
                                mapping.append((req_idx, inner_idx))
                                all_texts.append(txt)
                        else:
                            mapping.append((req_idx, 0))
                            all_texts.append(p)
                    
                    if self.logger:
                        self.logger.debug(
                            "Processing grouped batch",
                            batch_size=len(batch),
                            total_requests=len(all_texts),
                            queue_depth=q.qsize()
                        )

                    try:
                        results = await asyncio.to_thread(self.classify_batch, all_texts, len(all_texts))
                        per_req_results: Dict[int, List[Any]] = {}
                        for (req_idx, inner_idx), res in zip(mapping, results):
                            per_req_results.setdefault(req_idx, []).append(res)

                        for idx, req in enumerate(batch):
                            if req.future.cancelled():
                                if self.logger:
                                    self.logger.warning(
                                        "Batch request future was cancelled before setting result",
                                    )
                                continue
                            res_list = per_req_results.get(idx, [])
                            if isinstance(req.payload, tuple):
                                if not req.future.done():
                                    req.future.set_result(res_list)
                            else:
                                if res_list:
                                    if not req.future.done():
                                        req.future.set_result(res_list[0])
                                else:
                                    if not req.future.done():
                                        req.future.set_result(None)
                    except Exception as e:
                        for req in batch:
                            if not req.future.done():
                                req.future.set_exception(e)
                else:
                    batch_texts = [str(p) for p in payloads]
                    
                    if self.logger:
                        self.logger.debug(
                            "Processing simple batch",
                            batch_size=len(batch),
                            queue_depth=q.qsize()
                        )
                    
                    try:
                        results = await asyncio.to_thread(self.classify_batch, batch_texts, len(batch_texts))
                        for req, res in zip(batch, results):
                            if req.future.cancelled():
                                if self.logger:
                                    self.logger.warning(
                                        "Batch request future was cancelled before setting result",
                                    )
                                continue
                            if not req.future.done():
                                req.future.set_result(res)
                    except Exception as e:
                        if self.logger:
                            self.logger.error(
                                "Batch processing failed",
            
                                error_type=type(e).__name__,
                                error_message=str(e),
                                error_stage="batch_inference"
                            )
                        for req in batch:
                            if not req.future.done():
                                req.future.set_exception(e)
        finally:
            while not q.empty():
                try:
                    req = q.get_nowait()
                except asyncio.QueueEmpty:
                    break
                if not req.future.done():
                    req.future.set_exception(ModeratorError("Batch worker stopped before processing request"))
                    if self.logger:
                        self.logger.warning(
                            "Batch request dropped due to worker shutdown",
                        )

    def _run_model_batch(
        self,
        texts: List[str],
        tokenizer,
        model,
        device: Optional[int] = None,
        batch_size: int = 32,
        max_retries: int = 3,
        backoff_base: float = 0.5,
    ) -> List[Tuple[str, float]]:
        """Run model inference over `texts` using vectorized tokenization and batching.

        Retries on transient GPU OOM/runtime errors with exponential backoff.
        Returns a list of (label, score) tuples aligned with `texts`.
        """
        if not texts:
            return []

        if device is None:
            device = 0 if torch.cuda.is_available() else -1

        results: List[Tuple[str, float]] = []

        # helper to map logits -> (label, score)
        def logits_to_label_score(logits_tensor):
            probs = F.softmax(logits_tensor, dim=-1)
            top_probs, top_idxs = probs.max(dim=-1)
            idx = int(top_idxs.item())
            score = float(top_probs.item())
            label = None
            try:
                label = model.config.id2label[idx]
            except Exception:
                label = f"LABEL_{idx}"
            return label, score

        # Dataset + collate_fn to produce tokenized batches via DataLoader
        class _TextDataset(Dataset):
            def __init__(self, texts_list: List[str]):
                self._texts = texts_list

            def __len__(self) -> int:
                return len(self._texts)

            def __getitem__(self, index: int) -> str:
                return self._texts[index]

        def _collate(batch_texts: List[str]):
            return tokenizer(batch_texts, padding=True, truncation=True, return_tensors="pt")

        dataset = _TextDataset(texts)
        # Use num_workers=0 to avoid pickling/tokenizer issues; keep order
        dataloader = DataLoader(dataset, batch_size=batch_size, collate_fn=_collate, num_workers=0)
        
        start_time = time.perf_counter()
        
        # Measure memory before batch processing
        memory_before_mb = 0.0
        if device != -1 and torch.cuda.is_available():
            torch.cuda.synchronize(device)
            memory_before_mb = torch.cuda.memory_allocated(device) / (1024 * 1024)
        
        if self.logger:
            self.logger.debug(
                "Starting model batch inference",
                total_texts=len(texts),
                batch_size=batch_size,
                device="cuda" if device != -1 else "cpu",
                memory_before_mb=round(memory_before_mb, 2)
            )

        for batch_enc in dataloader:
            attempt = 0
            while True:
                try:
                    enc = batch_enc
                    if device != -1 and torch.cuda.is_available():
                        enc = {k: v.to(torch.device(f"cuda:{device}")) for k, v in enc.items()}

                    with torch.no_grad():
                        out = model(**enc)

                    logits = out.logits if hasattr(out, "logits") else out[0]
                    if logits is None:
                        raise ModeratorError("Model returned no logits")

                    for j in range(logits.shape[0]):
                        lbl, sc = logits_to_label_score(logits[j])
                        results.append((lbl, sc))

                    try:
                        del enc
                        del out
                    except Exception:
                        pass

                    break
                except (torch.cuda.OutOfMemoryError, RuntimeError) as e:
                    msg = str(e).lower()
                    if "out of memory" in msg or isinstance(e, torch.cuda.OutOfMemoryError):
                        attempt += 1
                        if attempt > max_retries:
                            if self.logger:
                                self.logger.error(
                                    "Runtime error during inference",
                
                                    error_type=type(e).__name__,
                                    error_message=str(e),
                                    error_stage="batch_inference"
                                )
                            raise ModeratorError("OOM during inference after retries") from e
                        torch.cuda.empty_cache()
                        sleep_s = backoff_base * (2 ** (attempt - 1))
                        if self.logger:
                            self.logger.warning(
                                "OOM during model inference - retrying",
            
                                attempt=attempt,
                                max_retries=max_retries,
                                sleep_seconds=sleep_s,
                                error_type=type(e).__name__,
                                error_message=str(e),
                                error_stage="batch_inference"
                            )
                        time.sleep(sleep_s)
                        continue
                    else:
                        attempt += 1
                        if attempt > max_retries:
                            if self.logger:
                                self.logger.error(
                                    "Runtime error during inference",
                
                                    error_type=type(e).__name__,
                                    error_message=str(e),
                                    error_stage="batch_inference"
                                )
                            raise ModeratorError("Runtime error during inference") from e
                        time.sleep(backoff_base * (2 ** (attempt - 1)))
                        if self.logger:
                            self.logger.warning(
                                "Runtime error during model inference - retrying",
            
                                attempt=attempt,
                                max_retries=max_retries,
                                error_type=type(e).__name__,
                                error_message=str(e),
                                error_stage="batch_inference"
                            )
                        continue
        
        # Measure memory after batch processing
        memory_after_mb = 0.0
        memory_delta_mb = 0.0
        memory_peak_mb = 0.0
        if device != -1 and torch.cuda.is_available():
            torch.cuda.synchronize(device)
            memory_after_mb = torch.cuda.memory_allocated(device) / (1024 * 1024)
            memory_peak_mb = torch.cuda.max_memory_allocated(device) / (1024 * 1024)
            memory_delta_mb = memory_after_mb - memory_before_mb
            # Reset peak memory stats for next batch
            torch.cuda.reset_peak_memory_stats(device)
        
        if self.logger:
            duration_ms = (time.perf_counter() - start_time) * 1000
            throughput = len(results) / (duration_ms / 1000) if duration_ms > 0 else 0
            
            self.logger.info(
                "Model batch inference complete",
                total_results=len(results),
                duration_ms=round(duration_ms, 2),
                throughput=round(throughput, 2),
                memory_before_mb=round(memory_before_mb, 2),
                memory_after_mb=round(memory_after_mb, 2),
                memory_delta_mb=round(memory_delta_mb, 2),
                memory_peak_mb=round(memory_peak_mb, 2)
            )

        return results
