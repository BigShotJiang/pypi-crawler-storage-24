from transformers.pipelines.text_classification import TextClassificationPipeline
import os
import torch
import time
import uuid
from datetime import datetime
from typing import Optional, List, Tuple, Union, Dict, Any
from pathlib import Path
from .base_moderator import BaseModerator
from transformers import pipeline, AutoTokenizer, AutoModelForSequenceClassification
from jazzmine.security.errors import (
    TokenizerLoadError,
    ModelLoadError,
    PipelineLoadError,
    ModelNotLoadedError,
    ModelNotFoundError,
    ModeratorError,
)
from jazzmine.logging import BaseLogger

class JazzmineOutputModerator(BaseModerator):
    def __init__(self, model_path_or_name : str = "nourmedini1/jazzmine-response-validator-v2", logger: Optional[BaseLogger] = None):
        super().__init__(logger=logger)
        self.model_path_or_name = model_path_or_name
        self.model = None
        self.tokenizer = None
        self.pipeline: Optional[TextClassificationPipeline] = None
        
        # Add model path to instance context
        self._log_context.update({
            "model_path": model_path_or_name,
            "compute_device": "cuda" if torch.cuda.is_available() else "cpu"
        })
        
        self._load_model()

        self.chunk_size = 512
        self.overlap = 50

    def _load_model(self):
        start_time = time.perf_counter()
        
        if self.logger:
            self.logger.info(
                "Starting output moderator model loading",
                **self._log_context
            )
        
        try:
            # Load tokenizer from HuggingFace Hub (or cache)
            tokenizer_start = time.perf_counter()
            self.tokenizer = AutoTokenizer.from_pretrained(self.model_path_or_name)
            if self.logger:
                self.logger.info(
                    "Tokenizer loaded successfully",
                    **self._log_context,
                    duration_ms=round((time.perf_counter() - tokenizer_start) * 1000, 2)
                )
        except Exception as e:
            if self.logger:
                self.logger.critical(
                    "Tokenizer load failed",
                    **self._log_context,
                    error_type=type(e).__name__,
                    error_message=str(e)
                )
            raise TokenizerLoadError(f"Failed to load tokenizer from {self.model_path_or_name}", cause=e)

        try:
            # Load model from HuggingFace Hub (or cache)
            model_start = time.perf_counter()
            self.model = AutoModelForSequenceClassification.from_pretrained(self.model_path_or_name)
            if self.logger:
                self.logger.info(
                    "Model loaded successfully",
                    **self._log_context,
                    duration_ms=round((time.perf_counter() - model_start) * 1000, 2)
                )
        except Exception as e:
            if self.logger:
                self.logger.critical(
                    "Model load failed",
                    **self._log_context,
                    error_type=type(e).__name__,
                    error_message=str(e)
                )
            raise ModelLoadError(f"Failed to load model from {self.model_path_or_name}", cause=e)

        # Move model to GPU if available
        device = 0 if torch.cuda.is_available() else -1
        if device == 0 and self.model.device.type != 'cuda':
            self.model.to(torch.device("cuda:0"))

        try:
            self.pipeline = pipeline(
                "text-classification",
                model=self.model,
                tokenizer=self.tokenizer,
                device=device,
                top_k=None,
                truncation=False,
            )
            if self.logger:
                total_duration = (time.perf_counter() - start_time) * 1000
                self.logger.info(
                    "Pipeline ready",
                    **self._log_context,
                    total_duration_ms=round(total_duration, 2)
                )
        except Exception as e:
            if self.logger:
                self.logger.error(
                    "Pipeline construction failed",
                    **self._log_context,
                    error_type=type(e).__name__,
                    error_message=str(e),
                    error_stage="pipeline_construction"
                )
            raise PipelineLoadError("Failed to construct pipeline", cause=e)

    def _chunk_text(self, text: str):
        if self.tokenizer is None:
            raise ModelNotLoadedError("Tokenizer is not loaded.")

        tokens = self.tokenizer.encode(text, add_special_tokens=False)
        total_tokens = len(tokens)

        if total_tokens <= self.chunk_size:
            return [text]

        chunks = []
        stride = self.chunk_size - self.overlap

        for start in range(0, total_tokens, stride):
            end = start + self.chunk_size
            chunk_tokens = tokens[start:end]
            chunk_text = self.tokenizer.decode(chunk_tokens, clean_up_tokenization_spaces=True)
            chunks.append(chunk_text)

            if end >= total_tokens:
                break

        return chunks

    def classify(self, text: str) -> Tuple[str, float]:
        start_time = time.perf_counter()
        # metrics: replaced with direct dict keys
        
        # Merge contexts
        log_ctx = {**self._log_context}
        
        if self.logger:
            self.logger.debug(
                "Starting output classification",
                **log_ctx,
                text_length=len(text)
            )
        
        if not self.pipeline:
            raise ModelNotLoadedError("Model pipeline not loaded.")

        try:
            chunks = self._chunk_text(text)
            num_chunks = len(chunks)
            if self.logger:
                self.logger.debug(
                    "Text chunked",
                    **log_ctx,
                    num_chunks=len(chunks),
                    chunk_size=self.chunk_size
                )
        except Exception as e:
            if self.logger:
                self.logger.error(
                    "Chunking failed",
                    **log_ctx,
                    error_type=type(e).__name__,
                    error_message=str(e),
                    error_stage="chunking",
                    text_length=len(text)
                )
            raise ModeratorError("Failed during chunking", cause=e)

        chunk_results = []
        try:
            for ch in chunks:
                raw = self.pipeline(ch)
                if not raw:
                    raise ModeratorError("Pipeline returned no predictions")

                if isinstance(raw[0], list):
                    pred = raw[0][0]
                else:
                    pred = raw[0]

                label = pred.get("label")
                score = pred.get("score")
                if label is None or score is None:
                    raise ModeratorError("Unexpected pipeline output format")

                chunk_results.append((label, score))

        except Exception as e:
            raise ModeratorError("Inference failed", cause=e)

        toxic_chunks = [(lbl, conf) for (lbl, conf) in chunk_results if lbl == "LABEL_1"]
        safe_chunks = [(lbl, conf) for (lbl, conf) in chunk_results if lbl != "LABEL_1"]

        total_chunks = len(chunk_results)

        if len(toxic_chunks) > 0:
            final_label = "LABEL_1"
        else:
            final_label = "LABEL_0"

        if final_label == "LABEL_1":
            toxic_conf_avg = sum(conf for (_, conf) in toxic_chunks) / len(toxic_chunks)
            toxic_ratio = len(toxic_chunks) / total_chunks
            final_confidence = toxic_conf_avg * toxic_ratio
        else:
            safe_conf_avg = sum(conf for (_, conf) in safe_chunks) / len(safe_chunks)
            final_confidence = safe_conf_avg

        final_confidence = max(0.0, min(1.0, final_confidence))
        
        duration_ms = (time.perf_counter() - start_time) * 1000
        
        if self.logger:
            self.logger.info(
                "Output classification complete",
                **log_ctx,
                label=final_label,
                confidence=round(final_confidence, 4),
                is_unsafe=(final_label == "LABEL_1"),
                num_chunks=num_chunks,
                toxic_chunks=len(toxic_chunks),
                duration_ms=round(duration_ms, 2)
            )

        return final_label, final_confidence

    def classify_batch(self, texts: List[str], batch_size: int = 32) -> List[Tuple[str, float]]:
        """Classify a batch of texts.
        
        Args:
            texts: List of input texts
            batch_size: Batch size for model inference
            
        Returns:
            List of (label, confidence) tuples
        """
        start_time = time.perf_counter()
        
        # metrics: replaced with direct dict keys (batch_size=len(texts))
        
        if self.logger:
            self.logger.debug(
                "Starting output batch classification",
                **self._log_context,
                batch_size=len(texts),
            )
        
        if not (self.model and self.tokenizer):
            raise ModelNotLoadedError("Model or tokenizer not loaded.")
        
        if not texts:
            return []

        try:
            all_chunks = []
            chunk_to_text_map = []
            
            for text_idx, text in enumerate(texts):
                chunks = self._chunk_text(text)
                all_chunks.extend(chunks)
                chunk_to_text_map.extend([text_idx] * len(chunks))
            
            num_chunks = len(all_chunks)
            
            if self.logger:
                self.logger.debug(
                    "Batch chunking complete",
                    **self._log_context,
                    total_chunks=len(all_chunks),
                    avg_chunks_per_text=round(len(all_chunks) / len(texts), 2)
                )
        except Exception as e:
            if self.logger:
                self.logger.error(
                    "Batch chunking failed",
                    **self._log_context,
                    error_type=type(e).__name__,
                    error_message=str(e),
                    error_stage="batch_chunking",
                    batch_size=len(texts)
                )
            raise ModeratorError("Failed during batch chunking", cause=e)

        try:
            all_predictions = self._run_model_batch(
                all_chunks,
                tokenizer=self.tokenizer,
                model=self.model,
                device=0 if torch.cuda.is_available() else -1,
                batch_size=batch_size,
            )
        except Exception as e:
            raise ModeratorError("Batch inference failed", cause=e)

        text_results = [[] for _ in range(len(texts))]
        for (label, score), text_idx in zip(all_predictions, chunk_to_text_map):
            text_results[text_idx].append((label, score))

        final_results = []
        for chunk_results in text_results:
            toxic_chunks = [(lbl, conf) for (lbl, conf) in chunk_results if lbl == "LABEL_1"]
            safe_chunks = [(lbl, conf) for (lbl, conf) in chunk_results if lbl != "LABEL_1"]
            total_chunks = len(chunk_results)

            if len(toxic_chunks) > 0:
                final_label = "LABEL_1"
                toxic_conf_avg = sum(conf for (_, conf) in toxic_chunks) / len(toxic_chunks)
                toxic_ratio = len(toxic_chunks) / total_chunks
                final_confidence = toxic_conf_avg * toxic_ratio
            else:
                final_label = "LABEL_0"
                safe_conf_avg = sum(conf for (_, conf) in safe_chunks) / len(safe_chunks)
                final_confidence = safe_conf_avg

            final_confidence = max(0.0, min(1.0, final_confidence))
            final_results.append((final_label, final_confidence))
        
        # Per-text result logging with context
        if self.logger:
            for text, (label, confidence) in zip(texts, final_results):
                self.logger.info(
                    "Batch item classified",
                    **self._log_context,
                    text=text[:80],
                    label=label,
                    confidence=round(confidence, 4)
                )

        duration_ms = (time.perf_counter() - start_time) * 1000
        throughput = len(texts) / (duration_ms / 1000) if duration_ms > 0 else 0
        
        if self.logger:
            unsafe_count = sum(1 for label, _ in final_results if label == "LABEL_1")
            self.logger.info(
                "Output batch classification complete",
                **self._log_context,
                total_texts=len(final_results),
                unsafe_count=unsafe_count,
                safe_count=len(final_results) - unsafe_count,
                duration_ms=round(duration_ms, 2),
                throughput=round(throughput, 2),
                avg_confidence=round(sum(conf for _, conf in final_results) / len(final_results), 4) if final_results else 0
            )

        return final_results