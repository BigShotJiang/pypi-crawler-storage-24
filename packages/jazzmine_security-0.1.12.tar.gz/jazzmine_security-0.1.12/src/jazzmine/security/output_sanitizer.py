from datetime import datetime
import io
import os
import csv
import asyncio
from typing import Dict, Union, Optional, List, Any, Iterable, Tuple, Callable
from abc import ABC, abstractmethod
from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor, as_completed
from multiprocessing import cpu_count
from pypdf import PdfReader, PdfWriter
from pypdf.generic import DictionaryObject, ArrayObject
import bleach
from jazzmine.security.errors import (
    PDFSanitizationError,
    CSVSanitizationError,
    HTMLSanitizationError,
)
from jazzmine.logging import BaseLogger, RequestContext

def _sanitize_wrapper(args: Tuple[str, Any, Dict[str, Any]]):
    cls_name, item, kwargs = args
    cls = globals().get(cls_name)
    if cls is None:
        raise ValueError("Sanitizer class not found")
    if hasattr(cls, "_call_sanitize_with_primary"):
        return cls._call_sanitize_with_primary(item, kwargs)
    return cls.sanitize(item, **kwargs)

import uuid

class BaseSanitizer(ABC):
    PRIMARY_ARG: Optional[str] = None

    def __init__(self, logger: Optional[BaseLogger] = None):
        self.logger = logger
        self.instance_id = uuid.uuid4().hex[:8]

    @abstractmethod
    def sanitize(self, *args: Any, **kwargs: Any) -> Union[bytes, str, Any]:
        pass

    def _call_sanitize_with_primary(self, item: Any, kwargs: Dict[str, Any]):
        if self.PRIMARY_ARG:
            call_kwargs = {**kwargs}
            if self.PRIMARY_ARG not in call_kwargs:
                call_kwargs[self.PRIMARY_ARG] = item
            return self.sanitize(**call_kwargs)
        return self.sanitize(item, **kwargs)

    def sanitize_batch(self, items: List[Any], max_workers: Optional[int] = None, chunk_size: int = 64, **kwargs: Any) -> List[Optional[Any]]:
        if not isinstance(items, list):
            raise ValueError("sanitize_batch expects a list of inputs")
        total = len(items)
        if total == 0:
            return []
        if max_workers is None:
            try:
                cores = os.cpu_count() or 1
            except Exception:
                cores = 1
            max_workers = min(32, max(4, cores * 2))
        results: List[Optional[Any]] = [None for _ in range(total)]
        def worker(idx_item: Tuple[int, Any]) -> Tuple[int, Any]:
            idx, item = idx_item
            try:
                return idx, self._call_sanitize_with_primary(item, kwargs)
            except Exception as e:
                return idx, e
        with ThreadPoolExecutor(max_workers=max_workers) as exe:
            for idx, res in exe.map(worker, enumerate(items)):
                results[idx] = res
        return results

    async def sanitize_batch_async(self, items: List[Any], max_workers: Optional[int] = None, chunk_size: int = 64, **kwargs: Any) -> List[Optional[Any]]:
        if not isinstance(items, list):
            raise ValueError("sanitize_batch_async expects a list of inputs")
        loop = asyncio.get_running_loop()
        if max_workers is None:
            try:
                cores = os.cpu_count() or 1
            except Exception:
                cores = 1
            max_workers = min(32, max(4, cores * 2))
        results: List[Optional[Any]] = [None] * len(items)
        def _sync_worker(idx_item: Tuple[int, Any]) -> Tuple[int, Any]:
            idx, item = idx_item
            try:
                return idx, self._call_sanitize_with_primary(item, kwargs)
            except Exception as e:
                return idx, e
        with ThreadPoolExecutor(max_workers=max_workers) as exe:
            tasks = [loop.run_in_executor(exe, _sync_worker, (i, items[i])) for i in range(len(items))]
            for fut in asyncio.as_completed(tasks):
                idx, res = await fut
                results[idx] = res
        return results

    def sanitize_batch_process(self, items: List[Any], max_workers: Optional[int] = None, chunk_size: int = 64, **kwargs: Any) -> List[Optional[Any]]:
        if not isinstance(items, list):
            raise ValueError("sanitize_batch_process expects a list of inputs")
        total = len(items)
        if total == 0:
            return []
        if max_workers is None:
            try:
                cores = cpu_count() or 1
            except Exception:
                cores = 1
            max_workers = min(cores, 16)
        results: List[Optional[Any]] = [None] * total
        with ProcessPoolExecutor(max_workers=max_workers) as exe:
            futures = {exe.submit(_sanitize_wrapper, (self.__class__.__name__, items[i], kwargs)): i for i in range(total)}
            for fut in as_completed(futures):
                idx = futures[fut]
                try:
                    results[idx] = fut.result()
                except Exception as e:
                    results[idx] = e
        return results

    def sanitize_stream(self, source: Iterable[Any], mode: str = "thread", max_workers: Optional[int] = None, chunk_size: int = 64, **kwargs: Any):
        if mode not in ("thread", "process", "sync", "async"):
            raise ValueError("mode must be one of thread, process, sync, async")
        if mode == "sync":
            for item in source:
                try:
                    yield self._call_sanitize_with_primary(item, kwargs)
                except Exception as e:
                    yield e
            return
        if mode == "async":
            if max_workers is None:
                try:
                    cores = os.cpu_count() or 1
                except Exception:
                    cores = 1
                max_workers = min(32, max(4, cores * 2))
            async def _agen():
                tasks = []
                loop = asyncio.get_running_loop()
                with ThreadPoolExecutor(max_workers=max_workers) as exe:
                    for item in source:
                        tasks.append(loop.run_in_executor(exe, lambda it=item: self._call_sanitize_with_primary(it, kwargs)))
                    for coro in asyncio.as_completed(tasks):
                        try:
                            res = await coro
                        except Exception as e:
                            res = e
                        yield res
            loop = None
            try:
                loop = asyncio.get_running_loop()
            except RuntimeError:
                pass
            if loop and loop.is_running():
                async def _bridge():
                    async for r in _agen():
                        yield r
                return _bridge()
            else:
                return _agen()
        if mode == "thread":
            if max_workers is None:
                try:
                    cores = os.cpu_count() or 1
                except Exception:
                    cores = 1
                max_workers = min(32, max(4, cores * 2))
            with ThreadPoolExecutor(max_workers=max_workers) as exe:
                futures = []
                for i, item in enumerate(source):
                    futures.append(exe.submit(self._call_sanitize_with_primary, item, kwargs))
                    if len(futures) >= chunk_size:
                        for fut in as_completed(futures):
                            try:
                                yield fut.result()
                            except Exception as e:
                                yield e
                        futures = []
                for fut in as_completed(futures):
                    try:
                        yield fut.result()
                    except Exception as e:
                        yield e
            return
        if mode == "process":
            if max_workers is None:
                try:
                    cores = cpu_count() or 1
                except Exception:
                    cores = 1
                max_workers = min(cores, 16)
            with ProcessPoolExecutor(max_workers=max_workers) as exe:
                futures = []
                items = list(source)
                total = len(items)
                for i in range(total):
                    futures.append(exe.submit(_sanitize_wrapper, (self.__class__.__name__, items[i], kwargs)))
                    if len(futures) >= chunk_size:
                        for fut in as_completed(futures):
                            try:
                                yield fut.result()
                            except Exception as e:
                                yield e
                        futures = []
                for fut in as_completed(futures):
                    try:
                        yield fut.result()
                    except Exception as e:
                        yield e
            return

class JazzminePDFSanitizer(BaseSanitizer):
    PRIMARY_ARG = "file_input"
    DANGEROUS_KEYS = ["/JS", "/JavaScript", "/AA", "/OpenAction", "/Launch", "/RichMedia", "/EmbeddedFiles"]
    def sanitize(self, *args: Any, file_input: Union[bytes, io.BytesIO, None] = None, chunked_pages: Optional[int] = None, **kwargs: Any) -> bytes:
        if file_input is None and args:
            try:
                file_input = args[0]
            except Exception:
                file_input = None
        if file_input is None:
            if self.logger:
                self.logger.error("PDFSanitizationError: file_input is required")
            raise PDFSanitizationError("file_input is required for PDF sanitization.")
        if isinstance(file_input, bytes):
            file_input = io.BytesIO(file_input)
        try:
            if self.logger:
                self.logger.debug("Starting PDF sanitization",)
            reader = PdfReader(file_input)
            writer = PdfWriter()
            total_pages = len(reader.pages)
            if chunked_pages is None or chunked_pages >= total_pages:
                for page in reader.pages:
                    self._clean_page(page)
                    writer.add_page(page)
            else:
                for start in range(0, total_pages, chunked_pages):
                    end = min(start + chunked_pages, total_pages)
                    for page in reader.pages[start:end]:
                        self._clean_page(page)
                        writer.add_page(page)
            self._clean_root(writer)
            output_stream = io.BytesIO()
            writer.write(output_stream)
            if self.logger:
                self.logger.info("PDF sanitization complete", total_pages=total_pages)
            return output_stream.getvalue()
        except Exception as e:
            length = None
            try:
                length = len(file_input.getvalue())
            except Exception:
                length = None
            if self.logger:
                self.logger.error("PDF sanitization failed", error_type=type(e).__name__, error_message=str(e), input_len=length)
            raise PDFSanitizationError("Failed to sanitize PDF", cause=e, context={"input_len": length})

    @classmethod
    def _clean_page(cls, page):
        for key in cls.DANGEROUS_KEYS:
            if key in page:
                del page[key]
        if "/Annots" in page:
            annotations = page["/Annots"]
            if isinstance(annotations, ArrayObject):
                for i in range(len(annotations) - 1, -1, -1):
                    annot = annotations[i].get_object()
                    if cls._is_dangerous_object(annot):
                        del annotations[i]

    @classmethod
    def _is_dangerous_object(cls, obj: DictionaryObject) -> bool:
        for key in cls.DANGEROUS_KEYS:
            if key in obj:
                return True
        if "/A" in obj:
            action = obj["/A"].get_object()
            if action and isinstance(action, DictionaryObject):
                type_entry = action.get("/S")
                if type_entry in ["/JavaScript", "/Launch", "/Import", "/GoToR"]:
                    return True
        return False

    @classmethod
    def _clean_root(cls, writer: PdfWriter):
        root = writer.root_object
        for key in cls.DANGEROUS_KEYS:
            if key in root:
                del root[key]
        if "/Names" in root:
            try:
                names = root["/Names"].get_object()
                if isinstance(names, DictionaryObject) and "/JavaScript" in names:
                    del names["/JavaScript"]
            except Exception:
                pass

class JazzmineCSVSanitizer(BaseSanitizer):
    PRIMARY_ARG = "input_data"
    DANGEROUS_PREFIXES = ('=', '+', '-', '@', '%')
    def sanitize(self, *args: Any, input_data: Union[str, List[List[Any]], None] = None, force_quote: bool = False, **kwargs: Any) -> str:
        if input_data is None and args:
            try:
                input_data = args[0]
            except Exception:
                input_data = None
        if input_data is None:
            if self.logger:
                self.logger.error("CSVSanitizationError: input_data is required")
            raise CSVSanitizationError("Input data is required for CSV sanitization.")
        try:
            if self.logger:
                self.logger.debug("Starting CSV sanitization", input_type=type(input_data).__name__)
            if isinstance(input_data, str):
                result = self._sanitize_string(input_data, force_quote=force_quote)
            elif isinstance(input_data, list):
                result = self._sanitize_list(input_data, force_quote=force_quote)
            else:
                raise CSVSanitizationError("Input must be a CSV string or a list of lists.")
            if self.logger:
                self.logger.info("CSV sanitization complete", output_length=len(result))
            return result
        except CSVSanitizationError:
            raise
        except Exception as e:
            if self.logger:
                self.logger.error("CSV sanitization failed", error_type=type(e).__name__, error_message=str(e))
            raise CSVSanitizationError("CSV sanitization failed", cause=e)

    @classmethod
    def _sanitize_string(cls, csv_string: str, force_quote: bool = False) -> str:
        try:
            output = io.StringIO()
            reader = csv.reader(io.StringIO(csv_string.strip()))
            quoting = csv.QUOTE_ALL if force_quote else csv.QUOTE_MINIMAL
            writer = csv.writer(output, quoting=quoting)
            for row in reader:
                safe_row = [cls._escape_cell(cell) for cell in row]
                writer.writerow(safe_row)
            return output.getvalue()
        except Exception as e:
            raise CSVSanitizationError("Failed to sanitize CSV string", cause=e)

    @classmethod
    def _sanitize_list(cls, data: List[List[Any]], force_quote: bool = False) -> str:
        try:
            output = io.StringIO()
            quoting = csv.QUOTE_ALL if force_quote else csv.QUOTE_MINIMAL
            writer = csv.writer(output, quoting=quoting)
            for row in data:
                safe_row = [cls._escape_cell(str(cell)) for cell in row]
                writer.writerow(safe_row)
            return output.getvalue()
        except Exception as e:
            raise CSVSanitizationError("Failed to sanitize CSV list", cause=e)

    @classmethod
    def _escape_cell(cls, cell_content: str) -> str:
        if not cell_content:
            return ""
        if cell_content.startswith(cls.DANGEROUS_PREFIXES):
            return f"'{cell_content}"
        if cell_content.startswith(('\t', '\r')):
            return f"'{cell_content}"
        return cell_content

class JazzmineHTMLSanitizer(BaseSanitizer):
    PRIMARY_ARG = "html_content"
    DEFAULT_ALLOWED_TAGS = ['p', 'br', 'b', 'i', 'u', 'em', 'strong', 'a', 'ul', 'ol', 'li', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'code', 'pre', 'blockquote', 'span', 'div']
    DEFAULT_ALLOWED_ATTRIBUTES = {'a': ['href', 'title', 'target'], 'img': ['src', 'alt', 'title'], '*': ['class']}
    DEFAULT_ALLOWED_STYLES = []
    def sanitize(self, *args: Any, html_content: str = "", allowed_tags: Optional[List[str]] = None, allowed_attributes: Optional[Dict] = None, strip_comments: bool = True, **kwargs: Any) -> str:
        if not html_content and args:
            try:
                html_content = args[0]
            except Exception:
                html_content = html_content
        if not html_content:
            if self.logger:
                self.logger.debug("No HTML content to sanitize")
            return ""
        tags = allowed_tags if allowed_tags else self.DEFAULT_ALLOWED_TAGS
        attrs = allowed_attributes if allowed_attributes else self.DEFAULT_ALLOWED_ATTRIBUTES
        try:
            if self.logger:
                self.logger.debug("Starting HTML sanitization", input_length=len(html_content))
            cleaned_html = bleach.clean(html_content, tags=tags, attributes=attrs, strip=True, strip_comments=strip_comments)
            cleaned_html = bleach.linkifier.Linker(callbacks=[]).linkify(cleaned_html)
            if self.logger:
                self.logger.info("HTML sanitization complete", output_length=len(cleaned_html))
            return cleaned_html
        except Exception as e:
            if self.logger:
                self.logger.error("HTML sanitization failed", error_type=type(e).__name__, error_message=str(e))
            raise HTMLSanitizationError("Failed to sanitize HTML", cause=e)

    @classmethod
    def sanitize_strict(cls, text: str) -> str:
        return bleach.clean(text, tags=[], attributes={}, strip=True)

