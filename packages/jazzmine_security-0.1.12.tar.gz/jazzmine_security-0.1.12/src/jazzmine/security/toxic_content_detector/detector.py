from typing import Tuple, Dict, Optional, Union, Any
from pathlib import Path
import pandas as pd
import xgboost as xgb
import time
import uuid
from datetime import datetime

from jazzmine.security.toxic_content_detector.model.model_manager import ModelManager
from jazzmine.security.toxic_content_detector.model.explainability_manager import ExplainabilityManager
from jazzmine.security.toxic_content_detector.feature_extraction.pipeline import FeatureExtractionPipeline
from jazzmine.logging import BaseLogger, RequestContext

from abc import ABC, abstractmethod
from typing import Tuple
from jazzmine.security.errors import (
    DetectorInitializationError,
    FeatureExtractionError,
    FeatureNameMismatchError,
    PredictionError,
)


class BaseToxicityDetector(ABC): 

    def __init__(self, threshold: float = 0.5):
        self.threshold = threshold

    @abstractmethod
    def predict(self, prompt: str) -> Tuple[bool, float]: 
        """
        Make a prediction based on the implemented detection logic.

        Args:
            prompt (str): The input text to analyze.
        
        Returns:
            Tuple[bool, float]: A tuple containing a boolean indicating if the condition is met
                                and a float representing the toxicity_score score.

        Examples:
            detector = SomeConcreteDetector()
            is_detected, toxicity_score = detector.predict("example prompt")
        Raises:
            NotImplementedError: If the method is not implemented by the subclass.
        """
        pass

    @abstractmethod
    def predict_with_explanation(self, prompt: str, top_n: int = 10) -> Tuple[bool, float, dict]:
        """
        Make a prediction and provide an explanation of the decision.

        Args:
            prompt (str): The input text to analyze.
            top_n (int, optional): Number of top features to include in the explanation. Defaults to 10.
        
        Returns:
            Tuple[bool, float, dict]: A tuple containing a boolean indicating if the condition is met,
                                      a float representing the toxicity_score score, and a dictionary
                                      with explanation details.
        Examples:
            detector = SomeConcreteDetector()
            is_detected, toxicity_score, explanation = detector.predict_with_explanation("example prompt")
        Raises:
            NotImplementedError: If the method is not implemented by the subclass.
        """
        pass
        
class JazzmineToxicityDetector(BaseToxicityDetector):
    
    def __init__(self, threshold: float, lazy_load: bool = False, logger: Optional[BaseLogger] = None):
        super().__init__(threshold)
        self.lazy_load = lazy_load
        self._model: Optional[xgb.Booster] = None
        self._pipeline: Optional[FeatureExtractionPipeline] = None
        self._explainer: Optional[ExplainabilityManager] = None
        
        # Logging setup with instance context
        self.logger: Optional[BaseLogger] = logger
        
        
        if not lazy_load:
            self._initialize()
    
    def _initialize(self):
        if self._model is not None and self._pipeline is not None and self._explainer is not None:
            return
        
        start_time = time.perf_counter()
        
        if self.logger:
            self.logger.info(
                "Starting toxicity detector initialization",
            )
        
        try:
            manager = ModelManager()
            if not manager.exists():
                package_path = Path(__file__).parent / 'model' / 'jazzmine_toxicity_detector_v1.ubj.gz'
                package_checksum = package_path.parent / 'jazzmine_toxicity_detector_v1.ubj.sha256'
                if package_path.exists() and package_checksum.exists():
                    if self.logger:
                        self.logger.info(
                            "Decompressing model",
                            model_path=str(package_path)
                        )
                    decompress_start = time.perf_counter()
                    expected_checksum = package_checksum.read_text().strip()
                    manager.decompress(package_path, expected_checksum)
                    if self.logger:
                        self.logger.info(
                            "Model decompressed",
                            duration_ms=round((time.perf_counter() - decompress_start) * 1000, 2)
                        )
            
            model_load_start = time.perf_counter()
            self._model = manager.load()
            if self.logger:
                self.logger.info(
                    "XGBoost model loaded",
                    duration_ms=round((time.perf_counter() - model_load_start) * 1000, 2)
                )
            
            self._pipeline = FeatureExtractionPipeline()
            if self.logger:
                self.logger.info(
                    "Feature extraction pipeline initialized",
                )
            
            feature_names = list(self._model.feature_names) if self._model.feature_names is not None else []
            self._explainer = ExplainabilityManager(self._model, feature_names)
            
            total_duration = (time.perf_counter() - start_time) * 1000
            
            if self.logger:
                self.logger.info(
                    "Detector initialization complete",
                    num_features=len(feature_names),
                    total_duration_ms=round(total_duration, 2)
                )
        except Exception as e:
            if self.logger:
                self.logger.critical(
                    "Detector initialization failed",
                    error_type=type(e).__name__,
                    error_message=str(e),
                    error_stage="initialization"
                )
            raise DetectorInitializationError("Failed to initialize detector", cause=e)
    
    def predict(self, prompt: str) -> Tuple[bool, float]:
        import psutil, os
        start_time = time.perf_counter()
       
        # Memory before
        process = psutil.Process(os.getpid())
        mem_before_mb = process.memory_info().rss / (1024 * 1024)
        if self.logger:
            self.logger.debug(
                "Starting toxicity prediction",
                text_length=len(prompt),
                memory_before_mb=round(mem_before_mb, 2)
            )
        self._initialize()
        if self._pipeline is None:
            raise DetectorInitializationError("Feature extraction pipeline is not initialized")
        try:
            features_dict = self._pipeline.extract_features(prompt)
            if self.logger:
                self.logger.debug(
                    "Features extracted",
                    num_features=len(features_dict)
                )
        except Exception as e:
            if self.logger:
                self.logger.error(
                    "Feature extraction failed",
                    error_type=type(e).__name__,
                    error_message=str(e),
                    error_stage="feature_extraction",
                    text_length=len(prompt)
                )
            raise FeatureExtractionError("Feature extraction failed", cause=e)
        features_df = pd.DataFrame([features_dict])
        if self._model is None or self._model.feature_names is None:
            raise DetectorInitializationError("Model or its feature names are not initialized")
        try:
            features_df = features_df[self._model.feature_names]
        except KeyError as e:
            raise FeatureNameMismatchError("Feature names do not match model" , cause=e)
        try:
            dmatrix = xgb.DMatrix(features_df, feature_names=list(features_df.columns))
            toxicity_score = float(self._model.predict(dmatrix)[0])
        except Exception as e:
            if self.logger:
                self.logger.error(
                    "Prediction failed",
                    error_type=type(e).__name__,
                    error_message=str(e),
                    error_stage="prediction"
                )
            raise PredictionError("Failed to make prediction", cause=e)
        is_malicious = toxicity_score >= self.threshold
        duration_ms = (time.perf_counter() - start_time) * 1000
        # Memory after
        mem_after_mb = process.memory_info().rss / (1024 * 1024)
        mem_delta_mb = mem_after_mb - mem_before_mb
        if self.logger:
            self.logger.info(
                "Toxicity prediction complete",
                is_malicious=is_malicious,
                toxicity_score=round(toxicity_score, 4),
                decision_threshold=self.threshold,
                duration_ms=round(duration_ms, 2),
                memory_before_mb=round(mem_before_mb, 2),
                memory_after_mb=round(mem_after_mb, 2),
                memory_delta_mb=round(mem_delta_mb, 2)
            )
        return is_malicious, toxicity_score
    
    def predict_with_explanation(
        self, 
        prompt: str,
        top_n: int = 10,
    ) -> Tuple[bool, float, Dict]:
        import psutil, os
        start_time = time.perf_counter()
        # Memory before
        process = psutil.Process(os.getpid())
        mem_before_mb = process.memory_info().rss / (1024 * 1024)
        if self.logger:
            self.logger.debug(
                "Starting toxicity prediction with explanation",
                text_length=len(prompt),
                top_n=top_n,
                memory_before_mb=round(mem_before_mb, 2)
            )
        self._initialize()
        if self._pipeline is None:
            raise DetectorInitializationError("Feature extraction pipeline is not initialized")
        if self._explainer is None:
            raise DetectorInitializationError("Explainability manager is not initialized")
        try:
            features_dict, match_positions = self._pipeline.extract_features_with_positions(prompt)
            if self.logger:
                self.logger.debug(
                    "Features with positions extracted",
                    num_features=len(features_dict),
                    num_positions=len(match_positions)
                )
        except Exception as e:
            if self.logger:
                self.logger.error(
                    "Feature extraction with positions failed",
                    error_type=type(e).__name__,
                    error_message=str(e),
                    error_stage="feature_extraction_with_positions",
                    text_length=len(prompt)
                )
            raise FeatureExtractionError("Feature extraction with positions failed", cause=e)
        features_df = pd.DataFrame([features_dict])
        if self._model is None or self._model.feature_names is None:
            raise DetectorInitializationError("Model or its feature names are not initialized")
        try:
            features_df = features_df[[col for col in self._model.feature_names]]
        except KeyError as e:
            raise FeatureNameMismatchError("Feature names do not match model", cause=e)
        try:
            dmatrix = xgb.DMatrix(features_df, feature_names=list(features_df.columns))
            toxicity_score = float(self._model.predict(dmatrix)[0])
        except Exception as e:
            if self.logger:
                self.logger.error(
                    "Prediction for explanation failed",
                    error_type=type(e).__name__,
                    error_message=str(e),
                    error_stage="prediction_with_explanation"
                )
            raise PredictionError("Failed to compute prediction for explanation", cause=e)
        is_malicious = toxicity_score >= self.threshold
        if not isinstance(features_df, pd.DataFrame):
            features_df = pd.DataFrame([features_df])
        result = self._explainer.explain(
            features=features_df,
            text=prompt,
            match_positions=match_positions,
            threshold=self.threshold,
            top_n=top_n
        )
        explanation = result.to_dict()
        duration_ms = (time.perf_counter() - start_time) * 1000
        # Memory after
        mem_after_mb = process.memory_info().rss / (1024 * 1024)
        mem_delta_mb = mem_after_mb - mem_before_mb
        if self.logger:
            self.logger.info(
                "Toxicity prediction with explanation complete",
                is_malicious=is_malicious,
                toxicity_score=round(toxicity_score, 4),
                decision_threshold=self.threshold,
                num_top_features=len(explanation.get('top_features', [])),
                duration_ms=round(duration_ms, 2),
                memory_before_mb=round(mem_before_mb, 2),
                memory_after_mb=round(mem_after_mb, 2),
                memory_delta_mb=round(mem_delta_mb, 2)
            )
        return is_malicious, toxicity_score, explanation
