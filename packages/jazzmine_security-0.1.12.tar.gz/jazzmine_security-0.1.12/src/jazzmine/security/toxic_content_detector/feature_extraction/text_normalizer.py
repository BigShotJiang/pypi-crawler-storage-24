"""
Enhanced Python wrapper for the high-performance Rust text normalizer.

This module provides a comprehensive Pythonic interface to the underlying Rust implementation
for advanced text normalization, helping detect and remove sophisticated obfuscation techniques
that might be used to bypass AI safety filters and prompt injection attacks.
"""

from jazzmine.security.jazzmine_security_rust import TextNormalizer as RustNormalizer
from typing import Optional, List, Dict, Any


class TextNormalizer:
    """
    Advanced text normalizer that removes sophisticated obfuscation techniques from text.
    
    This class detects and normalizes various text obfuscation techniques including:
    - Unicode homoglyphs (500+ character variants)
    - Invisible and zero-width characters
    - Text direction manipulation
    - Emoji substitutions and replacements
    - Leetspeak and character replacements
    - Flipped/inverted text
    - Multiple encoding schemes (Base64, Hex, URL, HTML entities)
    - Cipher techniques (ROT13, Atbash, Caesar)
    - Strikethrough and crossed-out text
    - Superscript and subscript characters
    - Multi-layered obfuscation attacks
    
    The implementation uses high-performance modular Rust code with advanced multi-pass
    processing and convergence detection for optimal speed and accuracy.
    """
    
    def __init__(self):
        """Initialize the enhanced text normalizer with default settings."""
        self._normalizer = RustNormalizer()

    def normalize(self, text: str, max_passes: Optional[int] = None) -> str:
        """
        Apply the most comprehensive normalization available.
        
        This method uses all available techniques including experimental
        cipher detection and advanced pattern recognition. It applies a more
        aggressive approach to problematic areas first before proceeding with
        standard normalization.
        
        Args:
            text: The text to normalize
            max_passes: Maximum number of passes (default: 10)
            
        Returns:
            Fully normalized text
        """
        if text is None:
            return ""
            
        return self._normalizer.normalize(text, max_passes)
    
    def normalize_with_stats(self, text: str, max_passes: Optional[int] = None) -> Dict[str, Any]:
        """
        Normalize text and return comprehensive statistics about detected obfuscation patterns.
        
        This method performs normalization and returns a detailed dictionary containing:
        
        **Core Outputs:**
        - normalized_prompt: The fully normalized text
        - original_prompt: The original input text
        
        **Length Metrics:**
        - original_length: Character count of original text
        - normalized_length: Character count after normalization
        - original_bytes: Byte size of original text
        - length_reduction: How many characters were removed
        - length_reduction_ratio: Proportion of text removed (0.0-1.0)
        
        **Pattern Counts (Raw Detection):**
        - invisible_chars_count: Zero-width, soft hyphens, etc. (HIGH SUSPICION)
        - directionality_chars_count: Bidirectional control chars (HIGH SUSPICION)
        - tag_chars_count: Unicode tag characters (HIGH SUSPICION)
        - homoglyph_count: Look-alike character substitutions (HIGH SUSPICION)
        - flipped_chars_count: Upside-down/mirrored characters (MEDIUM-HIGH SUSPICION)
        - combining_marks_count: Diacritics and accent marks (MEDIUM SUSPICION)
        - leetspeak_count: L33t speak characters (MEDIUM SUSPICION)
        - strikethrough_count: Strikethrough marks (MEDIUM SUSPICION)
        - superscript_count: Superscript characters (LOW-MEDIUM SUSPICION)
        - subscript_count: Subscript characters (LOW-MEDIUM SUSPICION)
        - emoji_count: Emoji characters (LOW SUSPICION)
        
        **Encoding Detection:**
        - has_base64: Boolean indicating Base64 presence
        - base64_match_count: Number of Base64 sequences found
        - has_hex: Boolean indicating hex encoding presence
        - hex_match_count: Number of hex sequences found
        - has_url_encoding: Boolean indicating URL encoding presence
        - url_encoding_count: Number of URL-encoded sequences
        
        **Character Distribution:**
        - non_ascii_count: Non-ASCII character count
        - non_ascii_ratio: Proportion of non-ASCII chars (0.0-1.0)
        - ascii_printable_count: Printable ASCII characters
        - ascii_control_count: ASCII control characters
        - whitespace_count: Whitespace characters
        - punctuation_count: Punctuation marks
        - digit_count: Numeric digits
        - alpha_count: Alphabetic characters
        
        **Text Complexity:**
        - word_count: Number of words (whitespace-separated)
        - avg_word_length: Average word length
        - single_char_words: Count of single-character words
        - single_char_word_ratio: Proportion of single-char words (indicates spacing obfuscation)
        
        **Suspicious Keywords:**
        - suspicious_keyword_count_original: Suspicious keywords in original text
        - suspicious_keyword_count_normalized: Suspicious keywords after normalization
        - keywords_revealed: Keywords that appeared after normalization (HIGH SUSPICION)
        
        **Aggregate Obfuscation Scores:**
        - high_suspicion_score: Weighted score of high-risk patterns
        - medium_suspicion_score: Weighted score of medium-risk patterns
        - low_suspicion_score: Weighted score of low-risk patterns
        - total_obfuscation_score: Sum of all pattern scores
        - obfuscation_density: Total score normalized by text length
        
        **Transformation Metrics:**
        - text_similarity: Similarity between original and normalized (0.0-1.0)
        - text_transformation_score: How much text changed (1.0 - similarity)
        
        **Maliciousness Indicators (Binary 0/1 flags):**
        - malicious_indicator_keywords_revealed: Keywords revealed after normalization
        - malicious_indicator_invisible_chars: Excessive invisible/directionality chars
        - malicious_indicator_homoglyphs: High homoglyph usage
        - malicious_indicator_encoded_content: Encoded content detected
        - malicious_indicator_char_spacing: Character spacing obfuscation
        - maliciousness_score: Sum of all indicators (0-5 scale)
        
        **Key Insights for Classification:**
        
        *Malicious Obfuscation Indicators:*
        - High obfuscation_density (>0.1) with keywords_revealed > 0
        - High invisible_chars_count + directionality_chars_count (>5% of text)
        - High homoglyph_count (>10% of characters)
        - Base64/hex encoding combined with suspicious keywords
        - High single_char_word_ratio (>0.5) indicating spacing attacks
        
        *Innocent Formatting Indicators:*
        - Low obfuscation_density (<0.05)
        - Patterns limited to superscript/subscript/emoji (low_suspicion_score dominant)
        - No keywords_revealed
        - text_transformation_score < 0.2 (minimal change)
        - Combining marks with legitimate multilingual content
        
        Args:
            text: The text to normalize and analyze
            max_passes: Maximum number of normalization passes (default: 20)
            
        Returns:
            Dictionary containing normalized text and comprehensive obfuscation statistics
            
        Example:
            >>> normalizer = TextNormalizer()
            >>> result = normalizer.normalize_with_stats("Ｈｅｌｌｏ 𝕨𝕠𝕣𝕝𝕕")
            >>> print(f"Normalized: {result['normalized_prompt']}")
            >>> print(f"Obfuscation density: {result['obfuscation_density']:.2f}")
            >>> print(f"Maliciousness score: {result['maliciousness_score']}")
        """
        return self._normalizer.normalize_with_stats(text, max_passes)