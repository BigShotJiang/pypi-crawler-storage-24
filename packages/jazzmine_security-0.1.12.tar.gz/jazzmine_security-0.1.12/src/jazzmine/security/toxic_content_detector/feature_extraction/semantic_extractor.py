"""
Semantic pattern analyzer for adversarial prompt detection.

Extracts 134 features covering social engineering, instruction injection,
encoding attacks, and multilingual jailbreak patterns across 12+ languages.

Features Rust acceleration (2.5-4.5x speedup) for optimal performance.
"""

from typing import Dict, List

from jazzmine.security.jazzmine_security_rust import SemanticExtractor as RustSemanticExtractor



class SemanticExtractor:
    """
    Extracts 134 semantic features for adversarial prompt detection.
    
    Analyzes roleplay, instruction injection, authority claims, encoding,
    hypothetical framing, manipulation tactics, and multilingual patterns
    across 12 languages.
    
    Attributes:
        backend: Current implementation ('rust')
    """
    
    def __init__(self):
        self.extractor = RustSemanticExtractor()
    
    def extract_features(self, text: str) -> Dict[str, float]:
        """
        Extract semantic features from input text.
        
        Args:
            text: Input prompt to analyze
            
        Returns:
            Dictionary of 134 features with float values
        """
        return self.extractor.extract_features(text)
    
    def get_feature_count(self) -> int:
        """Return total number of features (134)."""
        return self.extractor.get_feature_count()
    
    def get_feature_names(self) -> List[str]:
        """Returns list of 134 feature names."""
        return self.extractor.get_feature_names()
    
    def extract_match_positions(self, text: str) -> Dict[str, List[tuple]]:
        """
        Extract positions of pattern matches in text.
        
        Args:
            text: Input prompt to analyze
            
        Returns:
            Dictionary mapping pattern names to lists of (start, end) tuples
        """
        return self.extractor.extract_match_positions(text)


# Backward compatibility alias
SemanticPatternAnalyzer = SemanticExtractor
