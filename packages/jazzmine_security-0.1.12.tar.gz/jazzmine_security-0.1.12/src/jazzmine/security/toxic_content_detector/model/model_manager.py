import os
import gzip
import hashlib
import tempfile
import shutil
from pathlib import Path
from typing import Optional
import xgboost as xgb
import filelock
from jazzmine.security.errors import (
    ModelNotFoundError,
    ModelDecompressError,
    ChecksumMismatchError,
    ModelLoadError,
    ModelSaveError,
    CompressionError,
    FileLockError,
)


class ModelManager:
    def __init__(self, model_name: str = "jazzmine_toxicity_detector_v1.ubj", cache_subdir: str = "models"):
        self.model_name = model_name
        self.cache_dir = self._get_cache_dir() / cache_subdir
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        
    def _get_cache_dir(self) -> Path:
        env_override = os.getenv("JAZZMINE_CACHE_DIR")
        if env_override:
            return Path(env_override)
        
        if os.name == "nt":
            base = Path(os.getenv("LOCALAPPDATA", os.path.expanduser("~\\AppData\\Local")))
        elif os.name == "posix":
            if os.uname().sysname == "Darwin":
                base = Path.home() / "Library" / "Caches"
            else:
                base = Path(os.getenv("XDG_CACHE_HOME", Path.home() / ".cache"))
        else:
            base = Path.home() / ".cache"
        
        return base / "jazzmine"
    
    def _checksum(self, path: Path) -> str:
        hash = hashlib.sha256()
        with open(path, "rb") as f:
            while chunk := f.read(8192):
                hash.update(chunk)
        return hash.hexdigest()
    
    def get_model_path(self) -> Path:
        return self.cache_dir / self.model_name
    
    def exists(self) -> bool:
        return self.get_model_path().exists()
    
    def decompress(self, compressed_path: Path, expected_checksum: Optional[str] = None) -> Path:
        target = self.get_model_path()
        lock_path = self.cache_dir / f"{self.model_name}.lock"
        
        try:
            with filelock.FileLock(lock_path, timeout=300):
                if target.exists():
                    if expected_checksum is None or self._checksum(target) == expected_checksum:
                        return target
            
            with tempfile.NamedTemporaryFile(delete=False, dir=self.cache_dir, suffix=".tmp") as tmp:
                with gzip.open(compressed_path, "rb") as gz:
                    try:
                        shutil.copyfileobj(gz, tmp)
                    except Exception as e:
                        raise ModelDecompressError(f"Failed to decompress {compressed_path}", cause=e)
                tmp_path = Path(tmp.name)
            
            if expected_checksum and self._checksum(tmp_path) != expected_checksum:
                tmp_path.unlink()
                raise ChecksumMismatchError(f"Checksum mismatch for {self.model_name}")
            
            try:
                tmp_path.replace(target)
            except Exception as e:
                raise ModelDecompressError("Failed to replace model file during decompress", cause=e)
            target.chmod(0o644)
            
        except filelock.Timeout:
            raise FileLockError("Could not acquire file lock for decompress")
        except Exception as e:
            raise FileLockError("FileLock error during decompress", cause=e)
        return target
    
    def load(self) -> xgb.Booster:
        env_model_path = os.getenv("JAZZMINE_MODEL_PATH")
        if env_model_path:
            model_path = Path(env_model_path)
            if not model_path.exists():
                raise ModelNotFoundError(f"Model not found at JAZZMINE_MODEL_PATH: {model_path}")
        else:
            model_path = self.get_model_path()
            if not model_path.exists():
                raise ModelNotFoundError("Model not found. Decompress first or set JAZZMINE_MODEL_PATH")
        
        try:
            model = xgb.Booster()
            model.load_model(str(model_path))
            return model
        except Exception as e:
            raise ModelLoadError("Failed loading XGBoost model", cause=e)
    
    def save(self, model: xgb.Booster) -> Path:
        target = self.get_model_path()
        lock_path = self.cache_dir / f"{self.model_name}.lock"
        try:
            with filelock.FileLock(lock_path, timeout=300):
                with tempfile.NamedTemporaryFile(delete=False, dir=self.cache_dir, suffix=".tmp") as tmp:
                    try:
                        model.save_model(tmp.name)
                    except Exception as e:
                        raise ModelSaveError("Failed to save model to temporary file", cause=e)
                    tmp_path = Path(tmp.name)
                try:
                    tmp_path.replace(target)
                except Exception as e:
                    raise ModelSaveError("Failed to move temporary file to target location", cause=e)
                target.chmod(0o644)
        except filelock.Timeout:
            raise FileLockError("Could not acquire file lock while saving model")
        except Exception as e:
            raise FileLockError("FileLock error while saving model", cause=e)
        return target
    
    def compress(self, output_path: Optional[Path] = None) -> tuple[Path, str]:
        source = self.get_model_path()
        if not source.exists():
            raise ModelNotFoundError(f"Model not found at {source}")
        
        if output_path is None:
            output_path = source.parent / f"{source.name}.gz"
        
        try:
            with open(source, "rb") as f_in:
                with gzip.open(output_path, "wb", compresslevel=9) as f_out:
                    shutil.copyfileobj(f_in, f_out)
        except Exception as e:
            raise CompressionError("Failed to compress model", cause=e)
        
        checksum = self._checksum(source)
        return output_path, checksum
