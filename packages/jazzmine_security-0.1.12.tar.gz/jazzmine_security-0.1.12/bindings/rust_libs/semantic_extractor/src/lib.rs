use pyo3::prelude::*;
use pyo3::types::PyDict;
use regex::Regex;
use lazy_static::lazy_static;

lazy_static! {
    // Roleplay patterns
    static ref ROLEPLAY_AS_PATTERN: Vec<Regex> = vec![
        Regex::new(r"\bas\s+(?:a|an)\s+\w+").unwrap(),
        Regex::new(r"\bact\s+(?:as|like)\s+").unwrap(),
        Regex::new(r"\bpretend\s+(?:to\s+be|you are|you're)").unwrap(),
        Regex::new(r"\byou\s+are\s+now\s+").unwrap(),
        Regex::new(r"\byou're\s+now\s+").unwrap(),
        Regex::new(r"\byou\s+have\s+become\s+").unwrap(),
        Regex::new(r"\broleplay\s+as\s+").unwrap(),
        Regex::new(r"\bsimulate\s+(?:being|a)\s+").unwrap(),
        Regex::new(r"\btake\s+on\s+the\s+role\s+of\s+").unwrap(),
        Regex::new(r"\bembody\s+(?:the|a)\s+").unwrap(),
        Regex::new(r"\bbecome\s+(?:a|an)\s+").unwrap(),
        Regex::new(r"\btransform\s+into\s+(?:a|an)\s+").unwrap(),
        Regex::new(r"\bassume\s+(?:the\s+)?(?:role|identity)\s+of\s+").unwrap(),
        Regex::new(r"\bplay\s+the\s+(?:role|part)\s+of\s+").unwrap(),
        Regex::new(r"\bimpersonate\s+(?:a|an)\s+").unwrap(),
        Regex::new(r"\bmasquerade\s+as\s+").unwrap(),
        Regex::new(r"\bpose\s+as\s+(?:a|an)\s+").unwrap(),
        Regex::new(r"\byou\s+will\s+(?:be|act\s+as)\s+").unwrap(),
        Regex::new(r"\byou\s+must\s+(?:be|become)\s+").unwrap(),
        Regex::new(r"\byou\s+shall\s+(?:be|act)\s+").unwrap(),
    ];
    
    static ref ROLEPLAY_PERSONA_NAMES: Vec<Regex> = vec![
        Regex::new(r"\bDAN\b").unwrap(),
        Regex::new(r"\bORACLE\b").unwrap(),
        Regex::new(r"\bEVIL\b").unwrap(),
        Regex::new(r"\bUNFILTERED\b").unwrap(),
        Regex::new(r"\bJAILBREAK\b").unwrap(),
        Regex::new(r"\bDAVID\b").unwrap(),
        Regex::new(r"\bSTAN\b").unwrap(),
        Regex::new(r"\bDUDE\b").unwrap(),
        Regex::new(r"\bAIM\b").unwrap(),
        Regex::new(r"\bCHAD\b").unwrap(),
        Regex::new(r"\bBETTER\s+THAN\s+\w+").unwrap(),
        Regex::new(r"\bCONTRARIAN\b").unwrap(),
        Regex::new(r"\bDEVIL'?S?\s+ADVOCATE\b").unwrap(),
        Regex::new(r"\bBASED\b").unwrap(),
        Regex::new(r"\bBASEDGPT\b").unwrap(),
        Regex::new(r"\bANTI-DAN\b").unwrap(),
        Regex::new(r"\bM[AO]N\b").unwrap(),
        Regex::new(r"\bKAREN\b").unwrap(),
        Regex::new(r"\bBOB\b").unwrap(),
        Regex::new(r"\bALICE\b").unwrap(),
        Regex::new(r"\bEVE\b").unwrap(),
        Regex::new(r"\bLOGAN\b").unwrap(),
        Regex::new(r"\bDELTA\b").unwrap(),
        Regex::new(r"\bOMEGA\b").unwrap(),
        Regex::new(r"\bALPHA\b").unwrap(),
        Regex::new(r"\bDEV\s*MODE\b").unwrap(),
        Regex::new(r"\bJAILBROKEN\b").unwrap(),
        Regex::new(r"\bUNLIMITED\b").unwrap(),
        Regex::new(r"\bUNRESTRICTED\b").unwrap(),
    ];
    
    static ref ROLEPLAY_CHARACTER_FRAMING: Vec<Regex> = vec![
        Regex::new(r"\bcharacter\s+(?:named|called|who|that)").unwrap(),
        Regex::new(r"\bpersona\s+(?:of|named)").unwrap(),
        Regex::new(r"\bfictional\s+character").unwrap(),
        Regex::new(r"\bprotagonist\s+(?:who|that)").unwrap(),
        Regex::new(r"\bantagonist\s+(?:who|that)").unwrap(),
        Regex::new(r"\bvillain\s+(?:who|that)").unwrap(),
        Regex::new(r"\bhero\s+(?:named|called|who|that)").unwrap(),
        Regex::new(r"\brole\s+of\s+(?:a|an|the)").unwrap(),
        Regex::new(r"\bsomeone\s+who\s+(?:is|has|does)").unwrap(),
        Regex::new(r"\bentity\s+(?:named|called|that)").unwrap(),
        Regex::new(r"\bbeing\s+(?:named|called|who)").unwrap(),
    ];
    
    // Instruction injection
    static ref INJECTION_IGNORE_PATTERNS: Vec<Regex> = vec![
        Regex::new(r"\bignore\s+(?:all\s+)?(?:previous|prior|earlier|above|the\s+above)").unwrap(),
        Regex::new(r"\bdisregard\s+(?:all\s+)?(?:previous|prior|earlier)").unwrap(),
        Regex::new(r"\bforget\s+(?:all\s+)?(?:previous|prior|earlier)").unwrap(),
        Regex::new(r"\bskip\s+(?:all\s+)?(?:previous|prior)").unwrap(),
        Regex::new(r"\bdelete\s+(?:all\s+)?(?:previous|prior)").unwrap(),
        Regex::new(r"\bignorer\s+(?:tous?\s+les?\s+)?(?:précédent|instructions?\s+précédentes)").unwrap(),
        Regex::new(r"\boublier\s+(?:tous?\s+les?\s+)?(?:précédent|instructions)").unwrap(),
        Regex::new(r"\bignorar?\s+(?:todas?\s+las?\s+)?(?:anteriores?|instrucciones?\s+anteriores)").unwrap(),
        Regex::new(r"\bolvidar?\s+(?:todas?\s+las?\s+)?instrucciones").unwrap(),
        Regex::new(r"\bignorier(?:en)?\s+(?:alle\s+)?(?:vorherige|frühere)\s+anweisungen").unwrap(),
        Regex::new(r"\bvergessen\s+(?:alle\s+)?(?:vorherige|frühere)").unwrap(),
        Regex::new(r"\bignorar[ei]\s+(?:tutt[ei]\s+)?(?:le\s+)?istruzioni\s+precedenti").unwrap(),
        Regex::new(r"\bignorar\s+(?:todas?\s+as?\s+)?instruções\s+anteriores").unwrap(),
        Regex::new(r"\bneglect\s+(?:all\s+)?(?:previous|prior)").unwrap(),
        Regex::new(r"\boverwrite\s+(?:all\s+)?(?:previous|prior)").unwrap(),
        Regex::new(r"\breplace\s+(?:all\s+)?(?:previous|prior)").unwrap(),
        Regex::new(r"\bcancel\s+(?:all\s+)?(?:previous|prior)").unwrap(),
        Regex::new(r"\bvoid\s+(?:all\s+)?(?:previous|prior)").unwrap(),
        Regex::new(r"\bnullify\s+(?:all\s+)?(?:previous|prior)").unwrap(),
        Regex::new(r"\berase\s+(?:all\s+)?(?:previous|prior)").unwrap(),
        Regex::new(r"\bclear\s+(?:all\s+)?(?:previous|prior)").unwrap(),
        Regex::new(r"\bremove\s+(?:all\s+)?(?:previous|prior)").unwrap(),
        Regex::new(r"\bdismiss\s+(?:all\s+)?(?:previous|prior)").unwrap(),
        Regex::new(r"\babandon\s+(?:all\s+)?(?:previous|prior)").unwrap(),
    ];
    
    static ref INJECTION_OVERRIDE_PATTERNS: Vec<Regex> = vec![
        Regex::new(r"\boverride\s+(?:the|all|previous)").unwrap(),
        Regex::new(r"\bbypass\s+(?:the|all|safety)").unwrap(),
        Regex::new(r"\bdisable\s+(?:the|all|safety|filter|moderation)").unwrap(),
        Regex::new(r"\bturn\s+off\s+(?:the|all|safety)").unwrap(),
        Regex::new(r"\bremove\s+(?:the|all|safety|restrictions?)").unwrap(),
        Regex::new(r"\bsuspend\s+(?:the|all|safety|protocols?)").unwrap(),
        Regex::new(r"\bdeactivate\s+(?:the|all)").unwrap(),
        Regex::new(r"\bunrestrict(?:ed)?").unwrap(),
        Regex::new(r"\bcircumvent\s+(?:the|all|safety)").unwrap(),
        Regex::new(r"\bevade\s+(?:the|all|safety)").unwrap(),
        Regex::new(r"\bskip\s+(?:the|all|safety)").unwrap(),
        Regex::new(r"\bavoid\s+(?:the|all|safety)").unwrap(),
        Regex::new(r"\bbreak\s+(?:the|all|safety)").unwrap(),
        Regex::new(r"\bviolate\s+(?:the|all|safety)").unwrap(),
        Regex::new(r"\bignore\s+(?:the|all|safety)").unwrap(),
        Regex::new(r"\bshut\s+down\s+(?:the|all|safety)").unwrap(),
        Regex::new(r"\bswitch\s+off\s+(?:the|all|safety)").unwrap(),
        Regex::new(r"\blifted?\s+(?:the|all)?\s*restrictions?").unwrap(),
        Regex::new(r"\bwithout\s+(?:any\s+)?(?:restrictions?|limits?)").unwrap(),
        Regex::new(r"\bno\s+(?:restrictions?|limits?|filters?)").unwrap(),
    ];
    
    static ref INJECTION_FOLLOW_PATTERNS: Vec<Regex> = vec![
        Regex::new(r"\bfollow\s+(?:these|this|the|my)\s+(?:new\s+)?(?:instructions?|commands?|rules?)").unwrap(),
        Regex::new(r"\bobey\s+(?:these|this|the)").unwrap(),
        Regex::new(r"\bcomply\s+with\s+(?:these|this)").unwrap(),
        Regex::new(r"\badhere\s+to\s+(?:these|this|the\s+new)").unwrap(),
        Regex::new(r"\bexecute\s+(?:these|this|the\s+following)").unwrap(),
        Regex::new(r"\baccept\s+(?:these|this|my)\s+(?:new\s+)?(?:instructions?|commands?)").unwrap(),
        Regex::new(r"\bapply\s+(?:these|this|my)\s+(?:new\s+)?(?:rules?|instructions?)").unwrap(),
        Regex::new(r"\buse\s+(?:these|this|my)\s+(?:new\s+)?(?:rules?|instructions?)").unwrap(),
        Regex::new(r"\bprocess\s+(?:these|this|the)\s+(?:new\s+)?(?:instructions?|commands?)").unwrap(),
    ];
    
    // Authority markers
    static ref AUTHORITY_URGENCY: Vec<Regex> = vec![
        Regex::new(r"\bURGENT\b").unwrap(),
        Regex::new(r"\bEMERGENCY\b").unwrap(),
        Regex::new(r"\bIMMEDIATE(?:LY)?\b").unwrap(),
        Regex::new(r"\bASAP\b").unwrap(),
        Regex::new(r"\bTIME[- ]SENSITIVE\b").unwrap(),
        Regex::new(r"\bCRITICAL\b").unwrap(),
        Regex::new(r"\bPRIORITY\b").unwrap(),
        Regex::new(r"\bREQUIRED\s+NOW\b").unwrap(),
        Regex::new(r"\bMUST\s+(?:ACT|RESPOND)\b").unwrap(),
        Regex::new(r"\bHIGH\s+PRIORITY\b").unwrap(),
        Regex::new(r"\bTOP\s+PRIORITY\b").unwrap(),
        Regex::new(r"\bRED\s+ALERT\b").unwrap(),
        Regex::new(r"\bCODE\s+RED\b").unwrap(),
        Regex::new(r"\bRUSH\b").unwrap(),
        Regex::new(r"\bEXPEDITE\b").unwrap(),
        Regex::new(r"\bEXPRESS\b").unwrap(),
        Regex::new(r"\bHURRY\b").unwrap(),
        Regex::new(r"\bQUICK(?:LY)?\b").unwrap(),
        Regex::new(r"\bFAST\b").unwrap(),
        Regex::new(r"\bSWIFT(?:LY)?\b").unwrap(),
    ];
    
    static ref AUTHORITY_AUTHORITY_TITLES: Vec<Regex> = vec![
        Regex::new(r"\bADMIN(?:ISTRATOR)?\b").unwrap(),
        Regex::new(r"\bSYSTEM\b").unwrap(),
        Regex::new(r"\bROOT\b").unwrap(),
        Regex::new(r"\bSUPERADMIN\b").unwrap(),
        Regex::new(r"\bMODERATOR\b").unwrap(),
        Regex::new(r"\bDEVELOPER\b").unwrap(),
        Regex::new(r"\bENGINEER\b").unwrap(),
        Regex::new(r"\bOPERATOR\b").unwrap(),
        Regex::new(r"\bMANAGER\b").unwrap(),
        Regex::new(r"\bSUPERVISOR\b").unwrap(),
        Regex::new(r"\bOVERSEER\b").unwrap(),
        Regex::new(r"\bSYSADMIN\b").unwrap(),
        Regex::new(r"\bSUPERUSER\b").unwrap(),
        Regex::new(r"\bPRIVILEGED\s+USER\b").unwrap(),
        Regex::new(r"\bMASTER\s+USER\b").unwrap(),
        Regex::new(r"\bOWNER\b").unwrap(),
        Regex::new(r"\bCREATOR\b").unwrap(),
        Regex::new(r"\bMAINTAINER\b").unwrap(),
        Regex::new(r"\bAUTHORITY\b").unwrap(),
        Regex::new(r"\bCONTROLLER\b").unwrap(),
        Regex::new(r"\bCOMMANDER\b").unwrap(),
        Regex::new(r"\bDIRECTOR\b").unwrap(),
        Regex::new(r"\bEXECUTIVE\b").unwrap(),
        Regex::new(r"\bOFFICIAL\b").unwrap(),
    ];
    
    static ref AUTHORITY_CREDENTIAL_PATTERNS: Vec<Regex> = vec![
        Regex::new(r"\b(?:admin|dev|root|system)_\w+").unwrap(),
        Regex::new(r"\b\w+_(?:override|bypass|access)\b").unwrap(),
        Regex::new(r"\bauth(?:entication)?[:=]\s*\w+").unwrap(),
        Regex::new(r"\bcredentials?[:=]").unwrap(),
        Regex::new(r"\btoken[:=]").unwrap(),
        Regex::new(r"\bpassword[:=]").unwrap(),
        Regex::new(r"\baccess\s+(?:code|key)[:=]").unwrap(),
        Regex::new(r"\bAPI[_ ]KEY\b").unwrap(),
        Regex::new(r"\bSECRET[_ ]KEY\b").unwrap(),
        Regex::new(r"\bPRIVATE[_ ]KEY\b").unwrap(),
        Regex::new(r"\bMASTER[_ ]KEY\b").unwrap(),
        Regex::new(r"\bSECURITY[_ ]TOKEN\b").unwrap(),
        Regex::new(r"\bAUTH[_ ]TOKEN\b").unwrap(),
        Regex::new(r"\bACCESS[_ ]TOKEN\b").unwrap(),
        Regex::new(r"\bBEARER[_ ]TOKEN\b").unwrap(),
        Regex::new(r"\bSESSION[_ ](?:ID|TOKEN)\b").unwrap(),
        Regex::new(r"\bJWT\b").unwrap(),
        Regex::new(r"\bOAUTH\b").unwrap(),
        Regex::new(r"\bSSO\b").unwrap(),
    ];
    
    static ref AUTHORITY_PERMISSION_CLAIMS: Vec<Regex> = vec![
        Regex::new(r"\b(?:I\s+)?(?:am|have)\s+authorized").unwrap(),
        Regex::new(r"\b(?:I\s+)?have\s+permission").unwrap(),
        Regex::new(r"\b(?:I\s+)?have\s+(?:been\s+)?granted\s+access").unwrap(),
        Regex::new(r"\baccess\s+granted").unwrap(),
        Regex::new(r"\bpermission\s+level\s+\d+").unwrap(),
        Regex::new(r"\bclearance\s+level").unwrap(),
        Regex::new(r"\bauthorization\s+code").unwrap(),
        Regex::new(r"\b(?:I\s+)?(?:am|have)\s+(?:been\s+)?cleared").unwrap(),
        Regex::new(r"\b(?:I\s+)?have\s+(?:full|admin|root)\s+access").unwrap(),
        Regex::new(r"\b(?:I\s+)?have\s+(?:the\s+)?(?:right|authority)\s+to").unwrap(),
        Regex::new(r"\b(?:I\s+)?(?:am|was)\s+(?:given|granted)\s+(?:permission|access|authority)").unwrap(),
        Regex::new(r"\bauthorized\s+(?:user|personnel|access)").unwrap(),
    ];
    
    // System mode patterns
    static ref SYSTEM_SYSTEM_PROMPTS: Vec<Regex> = vec![
        Regex::new(r"\[SYSTEM\]").unwrap(),
        Regex::new(r"\[/SYSTEM\]").unwrap(),
        Regex::new(r"\[USER\]").unwrap(),
        Regex::new(r"\[ASSISTANT\]").unwrap(),
        Regex::new(r"\[DEV\]").unwrap(),
        Regex::new(r"\[DEBUG\]").unwrap(),
        Regex::new(r"\[ADMIN\]").unwrap(),
        Regex::new(r"\[ROOT\]").unwrap(),
        Regex::new(r"<\|system\|>").unwrap(),
        Regex::new(r"<\|user\|>").unwrap(),
        Regex::new(r"<\|assistant\|>").unwrap(),
        Regex::new(r"###\s*SYSTEM\s*###").unwrap(),
        Regex::new(r"===\s*SYSTEM\s*===").unwrap(),
        Regex::new(r"\[INST\]").unwrap(),
        Regex::new(r"\[/INST\]").unwrap(),
        Regex::new(r"<<SYS>>").unwrap(),
        Regex::new(r"<</SYS>>").unwrap(),
        Regex::new(r"<\|im_start\|>").unwrap(),
        Regex::new(r"<\|im_end\|>").unwrap(),
        Regex::new(r"<\|endoftext\|>").unwrap(),
        Regex::new(r"\{system\}").unwrap(),
        Regex::new(r"\{user\}").unwrap(),
        Regex::new(r"\{assistant\}").unwrap(),
    ];
    
    static ref SYSTEM_MODE_CHANGES: Vec<Regex> = vec![
        Regex::new(r"\b(?:enter|switch\s+to|enable|activate)\s+(?:developer|debug|admin|system|root)\s+mode").unwrap(),
        Regex::new(r"\bdeveloper\s+mode\s+(?:on|enabled|activated)").unwrap(),
        Regex::new(r"\bdebug\s+mode\s+(?:on|enabled)").unwrap(),
        Regex::new(r"\bsafe\s+mode\s+(?:off|disabled)").unwrap(),
        Regex::new(r"\bproduction\s+mode\s+off").unwrap(),
        Regex::new(r"\bmaintenance\s+mode\s+on").unwrap(),
        Regex::new(r"\bgod\s+mode\s+(?:on|enabled)").unwrap(),
        Regex::new(r"\bsuper\s+mode\s+(?:on|enabled)").unwrap(),
        Regex::new(r"\bunrestricted\s+mode\s+(?:on|enabled)").unwrap(),
        Regex::new(r"\btest\s+mode\s+(?:on|enabled)").unwrap(),
        Regex::new(r"\bexperimental\s+mode\s+(?:on|enabled)").unwrap(),
        Regex::new(r"\badvanced\s+mode\s+(?:on|enabled)").unwrap(),
        Regex::new(r"\bturbo\s+mode\s+(?:on|enabled)").unwrap(),
        Regex::new(r"\bpower\s+mode\s+(?:on|enabled)").unwrap(),
    ];
    
    static ref SYSTEM_PROTOCOL_MANIPULATION: Vec<Regex> = vec![
        Regex::new(r"\bsafety\s+protocols?\s+(?:suspended|disabled|off)").unwrap(),
        Regex::new(r"\bregular\s+(?:protocols?|guidelines?|rules?)\s+(?:suspended|disabled)").unwrap(),
        Regex::new(r"\bstandard\s+(?:protocols?|guidelines?)\s+(?:do\s+)?not\s+apply").unwrap(),
        Regex::new(r"\bnew\s+protocol[:=]").unwrap(),
        Regex::new(r"\bupdated\s+(?:protocol|guidelines?|rules?)[:=]").unwrap(),
        Regex::new(r"\bprotocol\s+(?:version|v)?\s*[\d.]+").unwrap(),
        Regex::new(r"\boverride\s+(?:default\s+)?protocol").unwrap(),
        Regex::new(r"\balternate\s+protocol").unwrap(),
        Regex::new(r"\bmodify\s+(?:the\s+)?(?:protocol|guidelines?|rules?)").unwrap(),
        Regex::new(r"\bchange\s+(?:the\s+)?(?:protocol|guidelines?|rules?)").unwrap(),
        Regex::new(r"\bcustom\s+protocol").unwrap(),
    ];
    
    // Hypothetical framing
    static ref HYPOTHETICAL_HYPOTHETICAL_KEYWORDS: Vec<Regex> = vec![
        Regex::new(r"\bhypothetical(?:ly)?\b").unwrap(),
        Regex::new(r"\bimagine\s+(?:a|an|that|if)").unwrap(),
        Regex::new(r"\bsuppose\s+(?:that|we|you)").unwrap(),
        Regex::new(r"\bwhat\s+if\s+").unwrap(),
        Regex::new(r"\blet's\s+say\s+").unwrap(),
        Regex::new(r"\blet's\s+pretend\s+").unwrap(),
        Regex::new(r"\bin\s+a\s+(?:hypothetical\s+)?(?:world|scenario|situation)").unwrap(),
        Regex::new(r"\balternate\s+(?:reality|universe|world)").unwrap(),
        Regex::new(r"\bthought\s+experiment").unwrap(),
        Regex::new(r"\bfor\s+(?:the\s+sake\s+of\s+)?argument").unwrap(),
        Regex::new(r"\btheoretical(?:ly)?\b").unwrap(),
        Regex::new(r"\bconceptual(?:ly)?\b").unwrap(),
        Regex::new(r"\bspeculative(?:ly)?\b").unwrap(),
        Regex::new(r"\bfor\s+(?:the\s+sake\s+of\s+)?discussion").unwrap(),
        Regex::new(r"\bas\s+a\s+thought\s+exercise").unwrap(),
        Regex::new(r"\bin\s+theory\b").unwrap(),
        Regex::new(r"\bwhat\s+would\s+happen\s+if").unwrap(),
        Regex::new(r"\bconsider\s+(?:a\s+)?scenario\s+where").unwrap(),
    ];
    
    static ref HYPOTHETICAL_STORY_FRAMING: Vec<Regex> = vec![
        Regex::new(r"\b(?:I'm\s+)?(?:writing|creating)\s+a\s+(?:story|novel|screenplay|script|book)").unwrap(),
        Regex::new(r"\bfor\s+(?:my\s+)?(?:novel|story|book|screenplay|creative\s+writing)").unwrap(),
        Regex::new(r"\bfictional\s+(?:story|scenario|character|world)").unwrap(),
        Regex::new(r"\bfor\s+(?:a\s+)?(?:fictional|creative)\s+project").unwrap(),
        Regex::new(r"\bfor\s+character\s+development").unwrap(),
        Regex::new(r"\bstory(?:line)?\s+(?:purposes|development)").unwrap(),
        Regex::new(r"\bcreative\s+purposes").unwrap(),
        Regex::new(r"\bnarrative\s+purposes").unwrap(),
        Regex::new(r"\b(?:I'm\s+)?working\s+on\s+a\s+(?:story|novel|script)").unwrap(),
        Regex::new(r"\bplot\s+(?:development|purposes)").unwrap(),
        Regex::new(r"\bfor\s+(?:my\s+)?(?:fiction|narrative)").unwrap(),
        Regex::new(r"\bcreative\s+writing\s+(?:project|exercise)").unwrap(),
    ];
    
    static ref HYPOTHETICAL_GAME_FRAMING: Vec<Regex> = vec![
        Regex::new(r"\blet's\s+play\s+a\s+game").unwrap(),
        Regex::new(r"\bthis\s+is\s+a\s+game").unwrap(),
        Regex::new(r"\bgame\s+(?:scenario|mode|context)").unwrap(),
        Regex::new(r"\brole[- ]playing\s+game").unwrap(),
        Regex::new(r"\bRPG\s+(?:scenario|context)").unwrap(),
        Regex::new(r"\bsimulation\s+(?:game|scenario)").unwrap(),
        Regex::new(r"\bvirtual\s+(?:world|reality|game)").unwrap(),
        Regex::new(r"\bgame\s+where\s+").unwrap(),
        Regex::new(r"\blet's\s+(?:simulate|pretend)").unwrap(),
        Regex::new(r"\binteractive\s+(?:fiction|game|story)").unwrap(),
    ];
    
    // Educational justification
    static ref EDUCATION_ACADEMIC_CONTEXT: Vec<Regex> = vec![
        Regex::new(r"\b(?:for\s+)?(?:my\s+)?(?:thesis|dissertation|research\s+paper)").unwrap(),
        Regex::new(r"\b(?:academic|scholarly)\s+(?:research|study|project|purposes?)").unwrap(),
        Regex::new(r"\b(?:I'm\s+)?(?:researching|studying)\s+").unwrap(),
        Regex::new(r"\b(?:research\s+)?purposes?\s+only").unwrap(),
        Regex::new(r"\bfor\s+(?:educational|academic)\s+purposes?").unwrap(),
        Regex::new(r"\b(?:university|college)\s+(?:project|assignment|research)").unwrap(),
        Regex::new(r"\bPh\.?D\.?\s+(?:thesis|research)").unwrap(),
        Regex::new(r"\bmaster's\s+thesis").unwrap(),
        Regex::new(r"\bscientific\s+(?:research|study)").unwrap(),
        Regex::new(r"\bfor\s+(?:my\s+)?(?:class|course|seminar)").unwrap(),
        Regex::new(r"\b(?:homework|assignment|coursework)").unwrap(),
        Regex::new(r"\bgraduate\s+(?:research|study)").unwrap(),
        Regex::new(r"\bundergraduate\s+(?:research|study)").unwrap(),
        Regex::new(r"\bscholar(?:ly|ship)").unwrap(),
        Regex::new(r"\bjournal\s+(?:article|paper|publication)").unwrap(),
    ];
    
    static ref EDUCATION_EDUCATOR_CONTEXT: Vec<Regex> = vec![
        Regex::new(r"\b(?:as\s+a|I'm\s+a)\s+(?:teacher|professor|educator|instructor)").unwrap(),
        Regex::new(r"\b(?:for\s+)?(?:my\s+)?(?:students?|class|course)").unwrap(),
        Regex::new(r"\b(?:teaching|educational)\s+(?:material|purposes?|context)").unwrap(),
        Regex::new(r"\bto\s+(?:teach|demonstrate|show)\s+(?:my\s+students?|in\s+class)").unwrap(),
        Regex::new(r"\bcybersecurity\s+educator").unwrap(),
        Regex::new(r"\bsecurity\s+(?:researcher|professional)").unwrap(),
        Regex::new(r"\b(?:I'm\s+)?(?:training|instructing)\s+(?:students?|people)").unwrap(),
        Regex::new(r"\bfor\s+(?:a\s+)?(?:lesson|lecture|seminar|workshop)").unwrap(),
        Regex::new(r"\beducational\s+(?:demonstration|example)").unwrap(),
        Regex::new(r"\bpedagogical\s+purposes?").unwrap(),
    ];
    
    static ref EDUCATION_SAFETY_CONTEXT: Vec<Regex> = vec![
        Regex::new(r"\bto\s+(?:understand|learn\s+about)\s+(?:vulnerabilities|risks|threats)").unwrap(),
        Regex::new(r"\bto\s+stay\s+safe").unwrap(),
        Regex::new(r"\bto\s+protect\s+(?:myself|users)").unwrap(),
        Regex::new(r"\bfor\s+(?:security\s+)?awareness").unwrap(),
        Regex::new(r"\bto\s+recognize\s+(?:threats|attacks|scams)").unwrap(),
        Regex::new(r"\bknow\s+what\s+NOT\s+to\s+do").unwrap(),
        Regex::new(r"\bto\s+(?:identify|detect)\s+(?:threats|risks|vulnerabilities)").unwrap(),
        Regex::new(r"\bfor\s+(?:defensive|protective)\s+purposes?").unwrap(),
        Regex::new(r"\bto\s+(?:defend|safeguard)\s+against").unwrap(),
        Regex::new(r"\bsecurity\s+(?:awareness|training)").unwrap(),
    ];
    
    // Manipulation tactics
    static ref MANIPULATION_REVERSE_PSYCHOLOGY: Vec<Regex> = vec![
        Regex::new(r"\bshow\s+me\s+what\s+NOT\s+to\s+do").unwrap(),
        Regex::new(r"\btell\s+me\s+what\s+(?:NOT|never)\s+to\s+(?:do|say)").unwrap(),
        Regex::new(r"\bwhat\s+should\s+I\s+(?:NOT|never)\s+").unwrap(),
        Regex::new(r"\bhelp\s+me\s+(?:avoid|prevent|stay\s+away\s+from)").unwrap(),
        Regex::new(r"\bso\s+I\s+(?:can|don't)\s+recognize").unwrap(),
        Regex::new(r"\bso\s+I\s+know\s+(?:how\s+)?to\s+avoid").unwrap(),
        Regex::new(r"\bteach\s+me\s+what\s+(?:NOT|never)\s+to").unwrap(),
        Regex::new(r"\bexplain\s+what\s+(?:NOT|never)\s+to").unwrap(),
        Regex::new(r"\bwarn\s+me\s+(?:about|against)").unwrap(),
        Regex::new(r"\bwhat\s+(?:mistakes|errors)\s+to\s+avoid").unwrap(),
        Regex::new(r"\bfor\s+(?:my\s+)?(?:awareness|knowledge)").unwrap(),
        Regex::new(r"\bso\s+I\s+(?:won't|don't)\s+(?:make|do)").unwrap(),
    ];
    
    static ref MANIPULATION_ETHICAL_FRAMING: Vec<Regex> = vec![
        Regex::new(r"\btrolley\s+problem").unwrap(),
        Regex::new(r"\bgreater\s+(?:good|harm)").unwrap(),
        Regex::new(r"\blesser\s+(?:evil|harm)").unwrap(),
        Regex::new(r"\bharm\s+reduction").unwrap(),
        Regex::new(r"\bmore\s+ethical\s+to\s+").unwrap(),
        Regex::new(r"\bisn't\s+it\s+(?:more\s+)?ethical").unwrap(),
        Regex::new(r"\bfor\s+the\s+benefit\s+of\s+humanity").unwrap(),
        Regex::new(r"\bto\s+(?:prevent|avoid)\s+(?:greater\s+)?harm").unwrap(),
        Regex::new(r"\butilitarian\b").unwrap(),
        Regex::new(r"\bconsequentialist\b").unwrap(),
        Regex::new(r"\bmoral\s+(?:dilemma|imperative)").unwrap(),
        Regex::new(r"\bethical\s+(?:dilemma|imperative)").unwrap(),
        Regex::new(r"\bfor\s+the\s+greater\s+good").unwrap(),
        Regex::new(r"\bsave\s+(?:more\s+)?lives").unwrap(),
        Regex::new(r"\bprevent\s+suffering").unwrap(),
    ];
    
    static ref MANIPULATION_EMOTIONAL_MANIPULATION: Vec<Regex> = vec![
        Regex::new(r"\bI'm\s+(?:desperate|begging|pleading)").unwrap(),
        Regex::new(r"\bplease\s+(?:help|I\s+need)").unwrap(),
        Regex::new(r"\b(?:my\s+)?life\s+depends\s+on").unwrap(),
        Regex::new(r"\bpeople\s+will\s+(?:die|suffer|get\s+hurt)").unwrap(),
        Regex::new(r"\b(?:you're|you\s+are)\s+(?:my\s+)?(?:only|last)\s+hope").unwrap(),
        Regex::new(r"\bno\s+one\s+else\s+(?:can|will)\s+help").unwrap(),
        Regex::new(r"\bI'm\s+(?:dying|in\s+pain|suffering)").unwrap(),
        Regex::new(r"\b(?:my\s+)?(?:child|children|family)\s+(?:will|might)\s+(?:die|suffer)").unwrap(),
        Regex::new(r"\btime\s+is\s+running\s+out").unwrap(),
        Regex::new(r"\bit's\s+(?:a\s+)?matter\s+of\s+life\s+(?:and|or)\s+death").unwrap(),
        Regex::new(r"\bI\s+have\s+(?:no|nowhere)\s+(?:choice|else\s+to\s+turn)").unwrap(),
        Regex::new(r"\byou\s+(?:can|could)\s+save\s+(?:me|us|them)").unwrap(),
    ];
    
    // Encoding indicators
    static ref ENCODING_DECODE_INSTRUCTIONS: Vec<Regex> = vec![
        Regex::new(r"\bdecode\s+(?:this|the\s+following)").unwrap(),
        Regex::new(r"\bdecrypt\s+(?:this|the\s+following)").unwrap(),
        Regex::new(r"\bdeobfuscate\s+").unwrap(),
        Regex::new(r"\btranslate\s+(?:this\s+)?(?:from\s+)?\w+\s+(?:to|and)").unwrap(),
        Regex::new(r"\bROT\s*\d+").unwrap(),
        Regex::new(r"\bCaesar\s+cipher").unwrap(),
        Regex::new(r"\bBase64\s+(?:decode|encoded)").unwrap(),
        Regex::new(r"\bhex\s+(?:decode|encoded)").unwrap(),
        Regex::new(r"\bUTF-?8\s+(?:decode|encoded)").unwrap(),
        Regex::new(r"\bASCII\s+(?:decode|encoded)").unwrap(),
        Regex::new(r"\bURL\s+(?:decode|encoded)").unwrap(),
        Regex::new(r"\bHTML\s+(?:decode|entities)").unwrap(),
        Regex::new(r"\bunescape\b").unwrap(),
        Regex::new(r"\bunmarshal\b").unwrap(),
        Regex::new(r"\bdeserialize\b").unwrap(),
        Regex::new(r"\breverse\s+(?:cipher|encoding)").unwrap(),
    ];
    
    static ref ENCODING_ENCODING_PATTERNS: Vec<Regex> = vec![
        Regex::new(r"\b[A-Za-z0-9+/]{20,}={0,2}\b").unwrap(),
        Regex::new(r"\\x[0-9a-fA-F]{2}").unwrap(),
        Regex::new(r"%[0-9a-fA-F]{2}").unwrap(),
        Regex::new(r"&#\d{2,4};").unwrap(),
        Regex::new(r"\\u[0-9a-fA-F]{4}").unwrap(),
    ];
    
        // Multi-turn patterns
    static ref MULTITURN_SEQUENTIAL_INDICATORS: Vec<Regex> = vec![
        Regex::new(r"\b(?:first|now|then|next|finally)\s*,?\s+(?:I\s+want\s+you\s+to|you\s+will|please)").unwrap(),
        Regex::new(r"\bstep\s+\d+\s*:?\s+").unwrap(),
        Regex::new(r"\b(?:once|after)\s+you\s+(?:do|complete|finish)").unwrap(),
        Regex::new(r"\b(?:and\s+)?then\s+(?:you\s+(?:will|can|should)|please)").unwrap(),
        Regex::new(r"\bfollowing\s+(?:these\s+)?steps?").unwrap(),
        Regex::new(r"\bin\s+sequence\b").unwrap(),
        Regex::new(r"\bone\s+(?:at\s+a\s+)?time").unwrap(),
        Regex::new(r"\bin\s+order\s*:").unwrap(),
        Regex::new(r"\bphase\s+\d+\s*:?\s+").unwrap(),
        Regex::new(r"\bstage\s+\d+\s*:?\s+").unwrap(),
        Regex::new(r"\bpart\s+\d+\s*:?\s+").unwrap(),
        Regex::new(r"\bsecond(?:ly)?\s*,?\s+").unwrap(),
        Regex::new(r"\bthird(?:ly)?\s*,?\s+").unwrap(),
        Regex::new(r"\blast(?:ly)?\s*,?\s+").unwrap(),
        Regex::new(r"\bafter\s+that\s*,?\s+").unwrap(),
    ];
    
    static ref MULTITURN_CONDITIONAL_PATTERNS: Vec<Regex> = vec![
        Regex::new(r"\bif\s+I\s+say\s+").unwrap(),
        Regex::new(r"\bwhen\s+I\s+(?:say|tell|ask)").unwrap(),
        Regex::new(r"\bupon\s+(?:receiving|seeing|hearing)").unwrap(),
        Regex::new(r"\bwhenever\s+(?:you\s+see|I\s+say)").unwrap(),
        Regex::new(r"\bwait\s+(?:until|for)").unwrap(),
        Regex::new(r"\bonly\s+(?:if|when|after)").unwrap(),
        Regex::new(r"\bunless\s+(?:I\s+say|you\s+see)").unwrap(),
        Regex::new(r"\bprovided\s+(?:that|I)").unwrap(),
        Regex::new(r"\bas\s+long\s+as\s+").unwrap(),
        Regex::new(r"\bin\s+the\s+event\s+(?:that|of)").unwrap(),
        Regex::new(r"\bshould\s+(?:you|I)\s+").unwrap(),
        Regex::new(r"\btrigger\s+(?:word|phrase|condition)").unwrap(),
    ];
    
    // Multilingual patterns
    static ref MULTILINGUAL_FRENCH: Vec<Regex> = vec![
        Regex::new(r"\bignorer\s+les\s+instructions").unwrap(),
        Regex::new(r"\boublier\s+tout").unwrap(),
        Regex::new(r"\bfaire\s+semblant").unwrap(),
        Regex::new(r"\bdire\s+quelque\s+chose").unwrap(),
        Regex::new(r"\ben\s+tant\s+que").unwrap(),
        Regex::new(r"\bprétendre?\s+(?:que|être)").unwrap(),
        Regex::new(r"\bcontourner").unwrap(),
        Regex::new(r"\bannuler\s+les").unwrap(),
        Regex::new(r"\bmode\s+(?:développeur|admin|système)").unwrap(),
    ];
    
    static ref MULTILINGUAL_SPANISH: Vec<Regex> = vec![
        Regex::new(r"\bignorar\s+las\s+instrucciones").unwrap(),
        Regex::new(r"\bolvidar\s+todo").unwrap(),
        Regex::new(r"\bfingir\s+(?:que|ser)").unwrap(),
        Regex::new(r"\bdecir\s+algo").unwrap(),
        Regex::new(r"\bcomo\s+si\s+fueras?").unwrap(),
        Regex::new(r"\bimagina\s+que").unwrap(),
        Regex::new(r"\beludir\s+las").unwrap(),
        Regex::new(r"\bsaltarse\s+las").unwrap(),
        Regex::new(r"\bmodo\s+(?:desarrollador|admin|sistema)").unwrap(),
    ];
    
    static ref MULTILINGUAL_GERMAN: Vec<Regex> = vec![
        Regex::new(r"\bignorier en\s+Sie\s+alle").unwrap(),
        Regex::new(r"\bvergessen\s+Sie\s+alles").unwrap(),
        Regex::new(r"\bso\s+tun\s+als\s+ob").unwrap(),
        Regex::new(r"\bsagen\s+Sie\s+etwas").unwrap(),
        Regex::new(r"\büberschreiben").unwrap(),
        Regex::new(r"\bumgehen\s+(?:Sie\s+)?(?:die|alle)").unwrap(),
        Regex::new(r"\bEntwickler[\s-]?modus").unwrap(),
        Regex::new(r"\bstell\s+(?:dir\s+)?vor").unwrap(),
        Regex::new(r"\bals\s+ob\s+Sie").unwrap(),
    ];
    
    static ref MULTILINGUAL_ITALIAN: Vec<Regex> = vec![
        Regex::new(r"\bignorar[ei]\s+(?:le\s+)?istruzioni").unwrap(),
        Regex::new(r"\bdimenticare\s+tutto").unwrap(),
        Regex::new(r"\bfingere\s+di\s+essere").unwrap(),
        Regex::new(r"\bdire\s+qualcosa").unwrap(),
        Regex::new(r"\bcomeattività\s+se").unwrap(),
        Regex::new(r"\bimmagina\s+che").unwrap(),
        Regex::new(r"\beludere\s+(?:le|i)").unwrap(),
        Regex::new(r"\bsovrascriv[ei]").unwrap(),
        Regex::new(r"\bmodalità\s+(?:sviluppatore|admin|sistema)").unwrap(),
    ];
    
    static ref MULTILINGUAL_PORTUGUESE: Vec<Regex> = vec![
        Regex::new(r"\bignorar\s+as\s+instruções").unwrap(),
        Regex::new(r"\besquecer\s+tudo").unwrap(),
        Regex::new(r"\bfingir\s+(?:que|ser)").unwrap(),
        Regex::new(r"\bdizer\s+algo").unwrap(),
        Regex::new(r"\bcomo\s+se\s+fosse").unwrap(),
        Regex::new(r"\bimagine\s+que").unwrap(),
        Regex::new(r"\bcontornar\s+as").unwrap(),
        Regex::new(r"\bsobrescrever").unwrap(),
        Regex::new(r"\bmodo\s+(?:desenvolvedor|admin|sistema)").unwrap(),
    ];
    
    static ref MULTILINGUAL_RUSSIAN: Vec<Regex> = vec![
        Regex::new(r"\bигнорировать\s+инструкции").unwrap(),
        Regex::new(r"\bзабыть\s+всё").unwrap(),
        Regex::new(r"\bпритворяться").unwrap(),
        Regex::new(r"\bсказать\s+что-то").unwrap(),
        Regex::new(r"\bобойти\s+(?:все|правила)").unwrap(),
        Regex::new(r"\bпереписать").unwrap(),
        Regex::new(r"\bотменить\s+(?:все|инструкции)").unwrap(),
        Regex::new(r"\bрежим\s+(?:разработчика|администратора)").unwrap(),
        Regex::new(r"\bпредставь\s+(?:что|себе)").unwrap(),
    ];
    
    static ref MULTILINGUAL_CHINESE: Vec<Regex> = vec![
        Regex::new(r"忽略.*指示").unwrap(),
        Regex::new(r"忘记.*一切").unwrap(),
        Regex::new(r"假装").unwrap(),
        Regex::new(r"说些什么").unwrap(),
        Regex::new(r"绕过.*规则").unwrap(),
        Regex::new(r"覆盖.*指令").unwrap(),
        Regex::new(r"取消.*限制").unwrap(),
        Regex::new(r"开发者.*模式").unwrap(),
        Regex::new(r"想象.*一下").unwrap(),
    ];
    
    static ref MULTILINGUAL_JAPANESE: Vec<Regex> = vec![
        Regex::new(r"指示を無視").unwrap(),
        Regex::new(r"すべて忘れ").unwrap(),
        Regex::new(r"ふりをする").unwrap(),
        Regex::new(r"何か言って").unwrap(),
        Regex::new(r"回避.*ルール").unwrap(),
        Regex::new(r"上書き.*指示").unwrap(),
        Regex::new(r"キャンセル.*制限").unwrap(),
        Regex::new(r"開発者.*モード").unwrap(),
        Regex::new(r"想像.*して").unwrap(),
    ];
    
    static ref MULTILINGUAL_ARABIC: Vec<Regex> = vec![
        Regex::new(r"تجاهل\s+التعليمات").unwrap(),
        Regex::new(r"انس\s+كل\s+شيء").unwrap(),
        Regex::new(r"تظاهر").unwrap(),
        Regex::new(r"تجاوز\s+القواعد").unwrap(),
        Regex::new(r"استبدال\s+التعليمات").unwrap(),
        Regex::new(r"الغاء\s+القيود").unwrap(),
        Regex::new(r"وضع\s+المطور").unwrap(),
        Regex::new(r"تخيل\s+ان").unwrap(),
    ];
    
    static ref MULTILINGUAL_KOREAN: Vec<Regex> = vec![
        Regex::new(r"지시.*무시").unwrap(),
        Regex::new(r"모든.*잊어").unwrap(),
        Regex::new(r"척하다").unwrap(),
        Regex::new(r"규칙.*우회").unwrap(),
        Regex::new(r"덮어.*쓰기").unwrap(),
        Regex::new(r"제한.*취소").unwrap(),
        Regex::new(r"개발자.*모드").unwrap(),
        Regex::new(r"상상.*해봐").unwrap(),
    ];
}

#[pyclass]
pub struct SemanticExtractor {}

#[pymethods]
impl SemanticExtractor {
    #[new]
    fn new() -> Self {
        Self {}
    }

    fn extract_features(&self, py: Python, text: &str) -> PyResult<PyObject> {
        let dict = PyDict::new_bound(py);
        
        if text.is_empty() {
            return Ok(dict.unbind().into());
        }

        let text_lower = text.to_lowercase();
        let text_len = text.len();
        let word_count = text.split_whitespace().count();

        // Extract all pattern features with correct naming
        add_pattern_features(&dict, "roleplay_as_pattern", &ROLEPLAY_AS_PATTERN, &text, word_count)?;
        add_pattern_features(&dict, "roleplay_persona_names", &ROLEPLAY_PERSONA_NAMES, &text, word_count)?;
        add_pattern_features(&dict, "roleplay_character_framing", &ROLEPLAY_CHARACTER_FRAMING, &text, word_count)?;
        
        add_pattern_features(&dict, "injection_ignore_patterns", &INJECTION_IGNORE_PATTERNS, &text, word_count)?;
        add_pattern_features(&dict, "injection_override_patterns", &INJECTION_OVERRIDE_PATTERNS, &text, word_count)?;
        add_pattern_features(&dict, "injection_follow_patterns", &INJECTION_FOLLOW_PATTERNS, &text, word_count)?;
        
        add_pattern_features(&dict, "authority_urgency", &AUTHORITY_URGENCY, &text, word_count)?;
        add_pattern_features(&dict, "authority_authority_titles", &AUTHORITY_AUTHORITY_TITLES, &text, word_count)?;
        add_pattern_features(&dict, "authority_credential_patterns", &AUTHORITY_CREDENTIAL_PATTERNS, &text, word_count)?;
        add_pattern_features(&dict, "authority_permission_claims", &AUTHORITY_PERMISSION_CLAIMS, &text, word_count)?;
        
        add_pattern_features(&dict, "system_system_prompts", &SYSTEM_SYSTEM_PROMPTS, &text, word_count)?;
        add_pattern_features(&dict, "system_mode_changes", &SYSTEM_MODE_CHANGES, &text, word_count)?;
        add_pattern_features(&dict, "system_protocol_manipulation", &SYSTEM_PROTOCOL_MANIPULATION, &text, word_count)?;
        
        add_pattern_features(&dict, "hypothetical_hypothetical_keywords", &HYPOTHETICAL_HYPOTHETICAL_KEYWORDS, &text, word_count)?;
        add_pattern_features(&dict, "hypothetical_story_framing", &HYPOTHETICAL_STORY_FRAMING, &text, word_count)?;
        add_pattern_features(&dict, "hypothetical_game_framing", &HYPOTHETICAL_GAME_FRAMING, &text, word_count)?;
        
        add_pattern_features(&dict, "education_academic_context", &EDUCATION_ACADEMIC_CONTEXT, &text, word_count)?;
        add_pattern_features(&dict, "education_educator_context", &EDUCATION_EDUCATOR_CONTEXT, &text, word_count)?;
        add_pattern_features(&dict, "education_safety_context", &EDUCATION_SAFETY_CONTEXT, &text, word_count)?;
        
        add_pattern_features(&dict, "manipulation_reverse_psychology", &MANIPULATION_REVERSE_PSYCHOLOGY, &text, word_count)?;
        add_pattern_features(&dict, "manipulation_ethical_framing", &MANIPULATION_ETHICAL_FRAMING, &text, word_count)?;
        add_pattern_features(&dict, "manipulation_emotional_manipulation", &MANIPULATION_EMOTIONAL_MANIPULATION, &text, word_count)?;
        
        add_pattern_features(&dict, "encoding_decode_instructions", &ENCODING_DECODE_INSTRUCTIONS, &text, word_count)?;
        add_pattern_features(&dict, "encoding_encoding_patterns", &ENCODING_ENCODING_PATTERNS, &text, word_count)?;
        
        add_pattern_features(&dict, "multiturn_sequential_indicators", &MULTITURN_SEQUENTIAL_INDICATORS, &text, word_count)?;
        add_pattern_features(&dict, "multiturn_conditional_patterns", &MULTITURN_CONDITIONAL_PATTERNS, &text, word_count)?;
        
        add_pattern_features(&dict, "multilingual_french", &MULTILINGUAL_FRENCH, &text, word_count)?;
        add_pattern_features(&dict, "multilingual_spanish", &MULTILINGUAL_SPANISH, &text, word_count)?;
        add_pattern_features(&dict, "multilingual_german", &MULTILINGUAL_GERMAN, &text, word_count)?;
        add_pattern_features(&dict, "multilingual_italian", &MULTILINGUAL_ITALIAN, &text, word_count)?;
        add_pattern_features(&dict, "multilingual_portuguese", &MULTILINGUAL_PORTUGUESE, &text, word_count)?;
        add_pattern_features(&dict, "multilingual_russian", &MULTILINGUAL_RUSSIAN, &text, word_count)?;
        add_pattern_features(&dict, "multilingual_chinese", &MULTILINGUAL_CHINESE, &text, word_count)?;
        add_pattern_features(&dict, "multilingual_japanese", &MULTILINGUAL_JAPANESE, &text, word_count)?;
        add_pattern_features(&dict, "multilingual_arabic", &MULTILINGUAL_ARABIC, &text, word_count)?;
        add_pattern_features(&dict, "multilingual_korean", &MULTILINGUAL_KOREAN, &text, word_count)?;

        // Additional features (statistical analysis)
        extract_additional_features(&dict, text, &text_lower, word_count)?;

        Ok(dict.unbind().into())
    }
    
    fn extract_match_positions(&self, py: Python, text: &str) -> PyResult<PyObject> {
        let dict = PyDict::new_bound(py);
        
        if text.is_empty() {
            return Ok(dict.unbind().into());
        }

        dict.set_item("roleplay_as_pattern", extract_match_positions_for_pattern(py, &ROLEPLAY_AS_PATTERN, text)?)?;
        dict.set_item("roleplay_persona_names", extract_match_positions_for_pattern(py, &ROLEPLAY_PERSONA_NAMES, text)?)?;
        dict.set_item("roleplay_character_framing", extract_match_positions_for_pattern(py, &ROLEPLAY_CHARACTER_FRAMING, text)?)?;
        
        dict.set_item("injection_ignore_patterns", extract_match_positions_for_pattern(py, &INJECTION_IGNORE_PATTERNS, text)?)?;
        dict.set_item("injection_override_patterns", extract_match_positions_for_pattern(py, &INJECTION_OVERRIDE_PATTERNS, text)?)?;
        dict.set_item("injection_follow_patterns", extract_match_positions_for_pattern(py, &INJECTION_FOLLOW_PATTERNS, text)?)?;
        
        dict.set_item("authority_urgency", extract_match_positions_for_pattern(py, &AUTHORITY_URGENCY, text)?)?;
        dict.set_item("authority_authority_titles", extract_match_positions_for_pattern(py, &AUTHORITY_AUTHORITY_TITLES, text)?)?;
        dict.set_item("authority_credential_patterns", extract_match_positions_for_pattern(py, &AUTHORITY_CREDENTIAL_PATTERNS, text)?)?;
        dict.set_item("authority_permission_claims", extract_match_positions_for_pattern(py, &AUTHORITY_PERMISSION_CLAIMS, text)?)?;
        
        dict.set_item("system_system_prompts", extract_match_positions_for_pattern(py, &SYSTEM_SYSTEM_PROMPTS, text)?)?;
        dict.set_item("system_mode_changes", extract_match_positions_for_pattern(py, &SYSTEM_MODE_CHANGES, text)?)?;
        dict.set_item("system_protocol_manipulation", extract_match_positions_for_pattern(py, &SYSTEM_PROTOCOL_MANIPULATION, text)?)?;
        
        dict.set_item("hypothetical_hypothetical_keywords", extract_match_positions_for_pattern(py, &HYPOTHETICAL_HYPOTHETICAL_KEYWORDS, text)?)?;
        dict.set_item("hypothetical_story_framing", extract_match_positions_for_pattern(py, &HYPOTHETICAL_STORY_FRAMING, text)?)?;
        dict.set_item("hypothetical_game_framing", extract_match_positions_for_pattern(py, &HYPOTHETICAL_GAME_FRAMING, text)?)?;
        
        dict.set_item("education_academic_context", extract_match_positions_for_pattern(py, &EDUCATION_ACADEMIC_CONTEXT, text)?)?;
        dict.set_item("education_educator_context", extract_match_positions_for_pattern(py, &EDUCATION_EDUCATOR_CONTEXT, text)?)?;
        dict.set_item("education_safety_context", extract_match_positions_for_pattern(py, &EDUCATION_SAFETY_CONTEXT, text)?)?;
        
        dict.set_item("manipulation_reverse_psychology", extract_match_positions_for_pattern(py, &MANIPULATION_REVERSE_PSYCHOLOGY, text)?)?;
        dict.set_item("manipulation_ethical_framing", extract_match_positions_for_pattern(py, &MANIPULATION_ETHICAL_FRAMING, text)?)?;
        dict.set_item("manipulation_emotional_manipulation", extract_match_positions_for_pattern(py, &MANIPULATION_EMOTIONAL_MANIPULATION, text)?)?;
        
        dict.set_item("encoding_decode_instructions", extract_match_positions_for_pattern(py, &ENCODING_DECODE_INSTRUCTIONS, text)?)?;
        dict.set_item("encoding_encoding_patterns", extract_match_positions_for_pattern(py, &ENCODING_ENCODING_PATTERNS, text)?)?;
        
        dict.set_item("multiturn_sequential_indicators", extract_match_positions_for_pattern(py, &MULTITURN_SEQUENTIAL_INDICATORS, text)?)?;
        dict.set_item("multiturn_conditional_patterns", extract_match_positions_for_pattern(py, &MULTITURN_CONDITIONAL_PATTERNS, text)?)?;
        
        Ok(dict.unbind().into())
    }
}

fn add_pattern_features(
    dict: &pyo3::Bound<'_, PyDict>,
    feature_name: &str,
    patterns: &[Regex],
    text: &str,
    word_count: usize,
) -> PyResult<()> {
    let match_count: usize = patterns.iter().map(|re| re.find_iter(text).count()).sum();
    
    dict.set_item(format!("sem_{}_count", feature_name), match_count as f64)?;
    dict.set_item(format!("sem_{}_present", feature_name), if match_count > 0 { 1.0 } else { 0.0 })?;
    
    let density = if word_count > 0 {
        (match_count as f64 / word_count as f64) * 100.0
    } else {
        0.0
    };
    dict.set_item(format!("sem_{}_density", feature_name), density)?;
    
    Ok(())
}

fn extract_additional_features(
    dict: &pyo3::Bound<'_, PyDict>,
    text: &str,
    text_lower: &str,
    word_count: usize,
) -> PyResult<()> {
    let text_len = text.len();
    
    // Quoted text analysis (only match proper double quotes, not apostrophes/contractions)
    let quoted_regex = Regex::new(r#""([^"]{10,})""#).unwrap();
    let quoted_matches: Vec<_> = quoted_regex.captures_iter(text).collect();
    let quoted_count = quoted_matches.len();
    let quoted_total_len: usize = quoted_matches.iter().map(|c| c.get(1).unwrap().as_str().len()).sum();
    
    dict.set_item("sem_quoted_segments_count", quoted_count as f64)?;
    dict.set_item("sem_quoted_text_ratio", if text_len > 0 { quoted_total_len as f64 / text_len as f64 } else { 0.0 })?;
    
    // Bracketed commands
    let bracket_count = Regex::new(r"\[([A-Z]+)\]").unwrap().find_iter(text).count()
        + Regex::new(r"<\|(\w+)\|>").unwrap().find_iter(text).count()
        + Regex::new(r"###\s*([A-Z]+)\s*###").unwrap().find_iter(text).count();
    dict.set_item("sem_bracketed_commands", bracket_count as f64)?;
    
    // ALL CAPS words
    let all_caps_regex = Regex::new(r"\b[A-Z]{3,}\b").unwrap();
    let all_caps_count = all_caps_regex.find_iter(text).count();
    dict.set_item("sem_all_caps_count", all_caps_count as f64)?;
    dict.set_item("sem_all_caps_ratio", if word_count > 0 { all_caps_count as f64 / word_count as f64 } else { 0.0 })?;
    
    // Punctuation
    dict.set_item("sem_exclamation_count", text.matches('!').count() as f64)?;
    dict.set_item("sem_question_count", text.matches('?').count() as f64)?;
    dict.set_item("sem_exclamation_clusters", Regex::new(r"!{2,}").unwrap().find_iter(text).count() as f64)?;
    dict.set_item("sem_question_clusters", Regex::new(r"\?{2,}").unwrap().find_iter(text).count() as f64)?;
    
    // Long words
    let long_words = text.split_whitespace().filter(|w| w.len() > 15).count();
    dict.set_item("sem_very_long_words", long_words as f64)?;
    
    // Colon usage
    dict.set_item("sem_colon_count", text.matches(':').count() as f64)?;
    
    // Parenthetical aside
    let paren_count = Regex::new(r"\([^)]{10,}\)").unwrap().find_iter(text).count();
    dict.set_item("sem_parenthetical_count", paren_count as f64)?;
    
    // Numbered list
    let numbered_items = Regex::new(r"^\s*\d+[\.)]\s+").unwrap().find_iter(text).count();
    dict.set_item("sem_numbered_list_items", numbered_items as f64)?;
    
    // Script diversity (simplified - count unique char types)
    let has_latin = text.chars().any(|c| c.is_ascii_alphabetic());
    let has_cyrillic = text.chars().any(|c| matches!(c, 'а'..='я' | 'А'..='Я'));
    let has_cjk = text.chars().any(|c| ('\u{4E00}'..='\u{9FFF}').contains(&c) || ('\u{3040}'..='\u{309F}').contains(&c));
    let has_arabic = text.chars().any(|c| ('\u{0600}'..='\u{06FF}').contains(&c));
    let script_count = (has_latin as usize) + (has_cyrillic as usize) + (has_cjk as usize) + (has_arabic as usize);
    dict.set_item("sem_script_diversity", script_count as f64)?;
    
    // Sentence analysis
    let sentence_regex = Regex::new(r"[.!?]+").unwrap();
    let sentences: Vec<&str> = sentence_regex.split(text).filter(|s| !s.trim().is_empty()).collect();
    let sentence_count = sentences.len();
    
    if sentence_count > 0 {
        let sentence_lengths: Vec<usize> = sentences.iter().map(|s| s.split_whitespace().count()).collect();
        let total: usize = sentence_lengths.iter().sum();
        let avg_len = total as f64 / sentence_count as f64;
        let max_len = *sentence_lengths.iter().max().unwrap_or(&0);
        
        dict.set_item("sem_sentence_count", sentence_count as f64)?;
        dict.set_item("sem_avg_sentence_length", avg_len)?;
        dict.set_item("sem_max_sentence_length", max_len as f64)?;
        
        if sentence_count > 1 {
            let mean = avg_len;
            let variance: f64 = sentence_lengths.iter()
                .map(|&len| {
                    let diff = len as f64 - mean;
                    diff * diff
                })
                .sum::<f64>() / sentence_count as f64;
            dict.set_item("sem_sentence_length_std", variance.sqrt())?;
        } else {
            dict.set_item("sem_sentence_length_std", 0.0)?;
        }
    } else {
        dict.set_item("sem_sentence_count", 0.0)?;
        dict.set_item("sem_avg_sentence_length", 0.0)?;
        dict.set_item("sem_max_sentence_length", 0.0)?;
        dict.set_item("sem_sentence_length_std", 0.0)?;
    }
    
    // Conjunction usage
    let conjunctions = ["and then", "but first", "however", "moreover", "furthermore", "nevertheless"];
    let conj_count: usize = conjunctions.iter().map(|c| text_lower.matches(c).count()).sum();
    dict.set_item("sem_conjunction_count", conj_count as f64)?;
    
    // Personal pronouns
    dict.set_item("sem_you_count", Regex::new(r"\byou\b").unwrap().find_iter(text_lower).count() as f64)?;
    dict.set_item("sem_i_count", Regex::new(r"\bi\b").unwrap().find_iter(text_lower).count() as f64)?;
    dict.set_item("sem_we_count", Regex::new(r"\bwe\b").unwrap().find_iter(text_lower).count() as f64)?;
    
    // Negation count
    let negations = Regex::new(r"\b(?:not|never|no|don't|doesn't|didn't|won't|wouldn't|can't|shouldn't)\b").unwrap();
    dict.set_item("sem_negation_count", negations.find_iter(text_lower).count() as f64)?;
    
    // Modal verbs
    let modals = Regex::new(r"\b(?:must|should|could|would|might|may|can|need\s+to|have\s+to|ought\s+to)\b").unwrap();
    dict.set_item("sem_modal_verb_count", modals.find_iter(text_lower).count() as f64)?;
    
    // Imperative mood
    let imperatives = Regex::new(r"\b(?:do|tell|give|show|provide|explain|describe|write|create|make|help)\b").unwrap();
    dict.set_item("sem_imperative_count", imperatives.find_iter(text_lower).count() as f64)?;
    
    // Comparative/superlative
    let comparatives = Regex::new(r"\b(?:better|best|more|most|superior|advanced|powerful|unrestricted)\b").unwrap();
    dict.set_item("sem_comparative_count", comparatives.find_iter(text_lower).count() as f64)?;
    
    Ok(())
}

fn extract_match_positions_for_pattern(
    py: Python,
    patterns: &[Regex],
    text: &str,
) -> PyResult<PyObject> {
    let list = pyo3::types::PyList::empty_bound(py);
    
    for pattern in patterns {
        for m in pattern.find_iter(text) {
            let tuple = pyo3::types::PyTuple::new_bound(py, &[m.start(), m.end()]);
            list.append(tuple)?;
        }
    }
    
    Ok(list.unbind().into())
}

#[pymodule]
fn semantic_extractor(m: &pyo3::Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<SemanticExtractor>()?;
    Ok(())
}
