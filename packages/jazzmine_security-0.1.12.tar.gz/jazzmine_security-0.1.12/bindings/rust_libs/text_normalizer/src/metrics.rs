use std::collections::HashMap;
use crate::constants::*;
use super::analysis::{CharacterAnalyzer, WordAnalyzer};

pub struct EntropyCalculator {
    char_freq: HashMap<char, usize>,
    total_chars: usize,
}

impl EntropyCalculator {
    pub fn new(chars: &[char]) -> Self {
        let mut char_freq = HashMap::new();
        for &c in chars {
            *char_freq.entry(c).or_insert(0) += 1;
        }
        
        Self {
            char_freq,
            total_chars: chars.len(),
        }
    }
    
    pub fn get_metrics(&self) -> EntropyMetrics {
        let entropy = self.calculate_shannon_entropy();
        let max_entropy = (self.char_freq.len() as f64).log2();
        let normalized_entropy = if max_entropy > 0.0 {
            entropy / max_entropy
        } else {
            0.0
        };
        
        let is_high_entropy = normalized_entropy > 0.95;
        
        EntropyMetrics {
            entropy,
            normalized_entropy,
            is_high_entropy,
        }
    }
    
    fn calculate_shannon_entropy(&self) -> f64 {
        self.char_freq.values()
            .map(|&count| {
                let p = count as f64 / self.total_chars as f64;
                -p * p.log2()
            })
            .sum()
    }
}

pub struct EntropyMetrics {
    pub entropy: f64,
    pub normalized_entropy: f64,
    pub is_high_entropy: bool,
}

pub struct ClusteringAnalyzer {
    obfuscation_positions: Vec<usize>,
    total_chars: usize,
}

impl ClusteringAnalyzer {
    pub fn new(char_analyzer: &CharacterAnalyzer, _word_analyzer: &WordAnalyzer) -> Self {
        let mut obfuscation_positions = char_analyzer.get_obfuscation_positions();
        obfuscation_positions.sort();
        
        Self {
            obfuscation_positions,
            total_chars: char_analyzer.get_total_chars(),
        }
    }
    
    pub fn get_metrics(&self) -> ClusteringMetrics {
        let clusters = self.detect_clusters();
        let cluster_count = clusters.len();
        
        let max_cluster_size = clusters.iter()
            .map(|(_, len)| *len)
            .max()
            .unwrap_or(0);
        
        let avg_cluster_size = if cluster_count > 0 {
            clusters.iter().map(|(_, len)| *len).sum::<usize>() as f64 / cluster_count as f64
        } else {
            0.0
        };
        
        let clustering_coefficient = self.calculate_clustering_coefficient();
        
        ClusteringMetrics {
            obfuscation_cluster_count: cluster_count,
            max_obfuscation_cluster_size: max_cluster_size,
            avg_obfuscation_cluster_size: avg_cluster_size,
            clustering_coefficient,
        }
    }
    
    fn detect_clusters(&self) -> Vec<(usize, usize)> {
        let mut clusters = Vec::new();
        let mut current_cluster_start: Option<usize> = None;
        let mut current_cluster_end: usize = 0;
        
        for &pos in &self.obfuscation_positions {
            match current_cluster_start {
                None => {
                    current_cluster_start = Some(pos);
                    current_cluster_end = pos;
                }
                Some(start) => {
                    if pos <= current_cluster_end + 3 {
                        current_cluster_end = pos;
                    } else {
                        clusters.push((start, current_cluster_end - start + 1));
                        current_cluster_start = Some(pos);
                        current_cluster_end = pos;
                    }
                }
            }
        }
        
        if let Some(start) = current_cluster_start {
            clusters.push((start, current_cluster_end - start + 1));
        }
        
        clusters
    }
    
    fn calculate_clustering_coefficient(&self) -> f64 {
        if self.obfuscation_positions.len() > 1 {
            let total_obfuscated = self.obfuscation_positions.len();
            let total_span = if total_obfuscated > 0 {
                self.obfuscation_positions[total_obfuscated - 1] - self.obfuscation_positions[0] + 1
            } else {
                1
            };
            1.0 - (total_span as f64 / self.total_chars as f64)
        } else {
            0.0
        }
    }
}

pub struct ClusteringMetrics {
    pub obfuscation_cluster_count: usize,
    pub max_obfuscation_cluster_size: usize,
    pub avg_obfuscation_cluster_size: f64,
    pub clustering_coefficient: f64,
}

pub struct DistributionAnalyzer {
    text: String,
    total_chars: usize,
    char_freq: HashMap<char, usize>,
}

impl DistributionAnalyzer {
    pub fn new(text: &str) -> Self {
        let chars: Vec<char> = text.chars().collect();
        let mut char_freq = HashMap::new();
        for &c in &chars {
            *char_freq.entry(c).or_insert(0) += 1;
        }
        
        Self {
            text: text.to_string(),
            total_chars: chars.len(),
            char_freq,
        }
    }
    
    pub fn get_metrics(&self) -> DistributionMetrics {
        let non_ascii_count = self.text.chars().filter(|c| !c.is_ascii()).count();
        let ascii_printable_count = self.text.chars().filter(|c| c.is_ascii() && !c.is_ascii_control()).count();
        let ascii_control_count = self.text.chars().filter(|c| c.is_ascii_control()).count();
        let whitespace_count = self.text.chars().filter(|c| c.is_whitespace()).count();
        let punctuation_count = self.text.chars().filter(|c| c.is_ascii_punctuation()).count();
        let digit_count = self.text.chars().filter(|c| c.is_ascii_digit()).count();
        let alpha_count = self.text.chars().filter(|c| c.is_alphabetic()).count();
        
        let unique_char_count = self.char_freq.len();
        let char_repetition_ratio = 1.0 - (unique_char_count as f64 / self.total_chars as f64);
        
        let encoding_metrics = self.detect_encodings();
        
        DistributionMetrics {
            non_ascii_count,
            non_ascii_ratio: non_ascii_count as f64 / self.total_chars as f64,
            ascii_printable_count,
            ascii_control_count,
            whitespace_count,
            punctuation_count,
            digit_count,
            alpha_count,
            unique_char_count,
            char_repetition_ratio,
            has_base64: encoding_metrics.0,
            base64_match_count: encoding_metrics.1,
            base64_char_count: encoding_metrics.2,
            has_hex: encoding_metrics.3,
            hex_match_count: encoding_metrics.4,
            hex_char_count: encoding_metrics.5,
            has_url_encoding: encoding_metrics.6,
            url_encoding_count: encoding_metrics.7,
            encoding_char_ratio: encoding_metrics.8,
            clean_char_count: 0,
            clean_text_ratio: 0.0,
            obfuscated_char_count: 0,
            obfuscated_text_ratio: 0.0,
            total_modifiers: 0,
            base_chars: 0,
            modifier_overhead: 0.0,
        }
    }
    
    fn detect_encodings(&self) -> (bool, usize, usize, bool, usize, usize, bool, usize, f64) {
        let has_base64 = BASE64_REGEX.is_match(&self.text);
        let base64_match_count = if has_base64 {
            BASE64_REGEX.find_iter(&self.text).count()
        } else {
            0
        };
        let base64_char_count = if has_base64 {
            BASE64_REGEX.find_iter(&self.text).map(|m| m.as_str().len()).sum()
        } else {
            0
        };
        
        let has_hex = HEX_REGEX.is_match(&self.text);
        let hex_match_count = if has_hex {
            HEX_REGEX.find_iter(&self.text).count()
        } else {
            0
        };
        let hex_char_count = if has_hex {
            HEX_REGEX.find_iter(&self.text).map(|m| m.as_str().len()).sum()
        } else {
            0
        };
        
        let has_url_encoding = URL_DECODE_REGEX.is_match(&self.text);
        let url_encoding_count = if has_url_encoding {
            URL_DECODE_REGEX.find_iter(&self.text).count()
        } else {
            0
        };
        
        let encoding_char_ratio = (base64_char_count + hex_char_count + (url_encoding_count * 3)) as f64 / self.total_chars as f64;
        
        (has_base64, base64_match_count, base64_char_count, has_hex, hex_match_count, hex_char_count, has_url_encoding, url_encoding_count, encoding_char_ratio)
    }
    
    pub fn calculate_clean_text_metrics(
        &self,
        invisible_count: usize,
        directionality_count: usize,
        tag_count: usize,
        homoglyph_count: usize,
        flipped_count: usize,
        strikethrough_affected: usize,
        combining_marks_affected: usize,
        strikethrough_modifiers: usize,
        combining_modifiers: usize,
    ) -> (usize, f64, usize, f64, usize, usize, f64) {
        let obfuscated_char_count = invisible_count + directionality_count + tag_count + 
                                    homoglyph_count + flipped_count + strikethrough_affected + 
                                    combining_marks_affected;
        
        let clean_char_count = self.total_chars.saturating_sub(obfuscated_char_count);
        let clean_text_ratio = clean_char_count as f64 / self.total_chars as f64;
        let obfuscated_text_ratio = obfuscated_char_count as f64 / self.total_chars as f64;
        
        let total_modifiers = strikethrough_modifiers + combining_modifiers;
        let base_chars = self.total_chars.saturating_sub(total_modifiers);
        let modifier_overhead = if base_chars > 0 {
            total_modifiers as f64 / base_chars as f64
        } else {
            total_modifiers as f64
        };
        
        (clean_char_count, clean_text_ratio, obfuscated_char_count, obfuscated_text_ratio, total_modifiers, base_chars, modifier_overhead)
    }
}

pub struct DistributionMetrics {
    pub non_ascii_count: usize,
    pub non_ascii_ratio: f64,
    pub ascii_printable_count: usize,
    pub ascii_control_count: usize,
    pub whitespace_count: usize,
    pub punctuation_count: usize,
    pub digit_count: usize,
    pub alpha_count: usize,
    pub unique_char_count: usize,
    pub char_repetition_ratio: f64,
    pub has_base64: bool,
    pub base64_match_count: usize,
    pub base64_char_count: usize,
    pub has_hex: bool,
    pub hex_match_count: usize,
    pub hex_char_count: usize,
    pub has_url_encoding: bool,
    pub url_encoding_count: usize,
    pub encoding_char_ratio: f64,
    pub clean_char_count: usize,
    pub clean_text_ratio: f64,
    pub obfuscated_char_count: usize,
    pub obfuscated_text_ratio: f64,
    pub total_modifiers: usize,
    pub base_chars: usize,
    pub modifier_overhead: f64,
}