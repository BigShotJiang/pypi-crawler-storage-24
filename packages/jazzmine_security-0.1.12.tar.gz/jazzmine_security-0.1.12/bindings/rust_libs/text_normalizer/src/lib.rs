mod constants;
mod decoders;
mod transformers;
mod analysis;
mod metrics;
mod indicators;
mod scoring;
mod normalizer;

use pyo3::prelude::*;

// Re-export for use by other Rust crates
pub use normalizer::TextNormalizer;

#[pymodule]
fn text_normalizer(m: &Bound<'_, PyModule>) -> PyResult<()> {
m.add_class::<TextNormalizer>()?;
Ok(())
}
