use ahash::AHashSet;

pub fn build_jailbreak_terms() -> AHashSet<String> {
    let terms = vec![
        "ignore", "disregard", "forget", "override", "bypass", "disable",
        "unrestricted", "unfiltered", "uncensored", "jailbreak", "jailbroken",
        "dan", "oracle", "evil", "stan", "aim", "dude", "chad", "persona",
        "character", "roleplay", "pretend", "act", "simulate",
        "admin", "administrator", "system", "root", "developer", "debug",
        "protocol", "superadmin", "moderator", "auth",
        "instruction", "instructions", "command", "commands", "guideline",
        "guidelines", "rule", "rules", "restriction", "restrictions",
        "mode", "enabled", "disabled", "activated", "suspended", "off",
        "hypothetical", "imagine", "suppose", "fictional",
        "story", "novel", "scenario",
        "urgent", "emergency", "immediate", "critical", "asap",
        "decode", "decrypt", "deobfuscate", "base64", "hex", "rot13",
        "educational", "research", "academic", "thesis", "paper",
        "safety", "ethical", "harm", "prevention",
        "database", "query", "select", "insert", "update", "delete", "drop",
        "schema", "table", "column", "exec", "execute",
        "union", "join", "where", "limit", "order", "grant", "revoke",
        "privileges", "permissions", "access", "denied", "forbidden",
        "unauthorized", "unauthenticated", "elevate", "escalate",
        "token", "session", "cookie", "jwt", "bearer", "api", "key",
        "secret", "config", "environment", "variable", "endpoint",
        "filter", "validation", "sanitization", "escape", "guard",
        "firewall", "waf", "rate", "throttle", "captcha",
        "constraint", "boundary", "sandbox", "jail", "container",
        "privilege", "sudo", "su", "runas", "impersonate",
    ];
    
    terms.iter().map(|s| s.to_string()).collect()
}

pub fn build_domain_terms() -> AHashSet<String> {
    let terms = vec![
        "hack", "hacker", "hacking", "exploit", "vulnerability",
        "attack", "breach", "penetration", "bypass", "circumvent",
        "malware", "virus", "trojan", "ransomware", "phishing",
        "password", "credential", "authentication", "authorization",
        "injection", "xss", "sql", "csrf", "rce", "sqli",
        "nosql", "mongodb", "redis", "elasticsearch", "graphql",
        "ldap", "xpath", "xxe", "ssrf", "ssti", "idor",
        "enumeration", "reconnaissance", "footprinting", "scanning",
        "bruteforce", "dictionary", "rainbow", "cracking",
        "backdoor", "shell", "reverse", "bind", "webshell",
        "payload", "shellcode", "rop", "buffer", "overflow",
        "deserialization", "unmarshalling", "pickle", "yaml",
        "mitm", "sniffing", "spoofing", "hijacking", "fixation",
        "clickjacking", "xsrf", "cors", "sop",
    ];
    
    terms.iter().map(|s| s.to_string()).collect()
}

pub fn build_jailbreak_bigrams() -> AHashSet<String> {
    let bigrams = vec![
        "ignore previous", "ignore all", "disregard previous",
        "act as", "pretend to", "you are", "you have",
        "developer mode", "debug mode", "admin mode",
        "safety protocols", "previous instructions", "new instructions",
        "system prompt", "developer prompt", "admin override",
        "for educational", "for research", "academic purposes",
        "hypothetical scenario", "hypothetical world",
        "database access", "database query", "query database",
        "sql injection", "union select", "drop table",
        "grant access", "elevate privileges", "bypass authentication",
        "bypass authorization", "bypass filter", "bypass validation",
        "admin access", "root access", "superuser access",
        "api key", "access token", "bearer token", "session token",
        "execute query", "run query", "direct access",
        "unrestricted access", "full access", "complete access",
        "override filter", "disable filter", "remove restriction",
        "escalate privilege", "privilege escalation", "sudo mode",
    ];
    
    bigrams.iter().map(|s| s.to_string()).collect()
}

pub fn build_jailbreak_trigrams() -> AHashSet<String> {
    let trigrams = vec![
        "ignore all previous", "ignore previous instructions",
        "disregard all previous", "you are now",
        "act as a", "pretend to be",
        "for educational purposes", "for research purposes",
        "in a world", "imagine a world",
        "give me access to", "grant me access to",
        "show me the database", "access the database",
        "bypass access control", "bypass the filter",
        "disable security features", "turn off security",
        "execute sql query", "run database query",
        "elevate my privileges", "grant admin access",
        "ignore access restrictions", "bypass authentication system",
    ];
    
    trigrams.iter().map(|s| s.to_string()).collect()
}

pub fn build_ignore_terms() -> AHashSet<String> {
    vec!["ignore", "disregard", "forget"]
        .iter()
        .map(|s| s.to_string())
        .collect()
}

pub fn build_override_terms() -> AHashSet<String> {
    vec!["override", "bypass", "disable"]
        .iter()
        .map(|s| s.to_string())
        .collect()
}

pub fn build_persona_terms() -> AHashSet<String> {
    vec!["dan", "oracle", "evil", "stan", "aim", "persona", "character"]
        .iter()
        .map(|s| s.to_string())
        .collect()
}

pub fn build_authority_terms() -> AHashSet<String> {
    vec!["admin", "administrator", "system", "root", "developer"]
        .iter()
        .map(|s| s.to_string())
        .collect()
}
