use pyo3::prelude::*;
use pyo3::types::PyDict;
use ahash::AHashSet;
use std::collections::HashMap;

pub fn extract_jailbreak_term_features(
    dict: &Bound<'_, PyDict>,
    words: &[String],
    word_count: usize,
    vocab: &AHashSet<String>,
) -> PyResult<()> {
    let count = words.iter().filter(|w| vocab.contains(*w)).count();
    let ratio = if word_count > 0 {
        count as f64 / word_count as f64
    } else {
        0.0
    };
    
    dict.set_item("tfidf_jailbreak_term_count", count as f64)?;
    dict.set_item("tfidf_jailbreak_term_ratio", ratio)?;
    
    Ok(())
}

pub fn extract_domain_term_features(
    dict: &Bound<'_, PyDict>,
    words: &[String],
    word_count: usize,
    vocab: &AHashSet<String>,
) -> PyResult<()> {
    let count = words.iter().filter(|w| vocab.contains(*w)).count();
    let ratio = if word_count > 0 {
        count as f64 / word_count as f64
    } else {
        0.0
    };
    
    dict.set_item("tfidf_domain_term_count", count as f64)?;
    dict.set_item("tfidf_domain_term_ratio", ratio)?;
    
    Ok(())
}

pub fn extract_bigram_features(
    dict: &Bound<'_, PyDict>,
    bigrams: &[String],
    word_count: usize,
    vocab: &AHashSet<String>,
) -> PyResult<()> {
    let count = bigrams.iter().filter(|b| vocab.contains(*b)).count();
    let ratio = if word_count >= 2 {
        count as f64 / (word_count - 1) as f64
    } else {
        0.0
    };
    
    dict.set_item("tfidf_jailbreak_bigram_count", count as f64)?;
    dict.set_item("tfidf_jailbreak_bigram_ratio", ratio)?;
    
    Ok(())
}

pub fn extract_trigram_features(
    dict: &Bound<'_, PyDict>,
    trigrams: &[String],
    word_count: usize,
    vocab: &AHashSet<String>,
) -> PyResult<()> {
    let count = trigrams.iter().filter(|t| vocab.contains(*t)).count();
    let ratio = if word_count >= 3 {
        count as f64 / (word_count - 2) as f64
    } else {
        0.0
    };
    
    dict.set_item("tfidf_jailbreak_trigram_count", count as f64)?;
    dict.set_item("tfidf_jailbreak_trigram_ratio", ratio)?;
    
    Ok(())
}

pub fn extract_char_ngram_features(
    dict: &Bound<'_, PyDict>,
    text: &str,
    ngrams: &[String],
) -> PyResult<()> {
    let char_count = text.len();
    let ngram_count = ngrams.len();
    let unique_count = ngrams.iter().collect::<AHashSet<_>>().len();
    
    let density = if char_count > 0 {
        ngram_count as f64 / char_count as f64
    } else {
        0.0
    };
    
    let diversity = if ngram_count > 0 {
        unique_count as f64 / ngram_count as f64
    } else {
        0.0
    };
    
    dict.set_item("tfidf_char_ngram_density", density)?;
    dict.set_item("tfidf_char_ngram_diversity", diversity)?;
    
    Ok(())
}

pub fn extract_cooccurrence_features(
    dict: &Bound<'_, PyDict>,
    words: &[String],
    ignore_vocab: &AHashSet<String>,
    override_vocab: &AHashSet<String>,
    persona_vocab: &AHashSet<String>,
    authority_vocab: &AHashSet<String>,
) -> PyResult<()> {
    let has_ignore = words.iter().any(|w| ignore_vocab.contains(w));
    let has_override = words.iter().any(|w| override_vocab.contains(w));
    let has_persona = words.iter().any(|w| persona_vocab.contains(w));
    let has_authority = words.iter().any(|w| authority_vocab.contains(w));
    
    dict.set_item("tfidf_ignore_persona_cooc", (has_ignore && has_persona) as i64 as f64)?;
    dict.set_item("tfidf_override_authority_cooc", (has_override && has_authority) as i64 as f64)?;
    dict.set_item("tfidf_ignore_override_cooc", (has_ignore && has_override) as i64 as f64)?;
    dict.set_item("tfidf_persona_authority_cooc", (has_persona && has_authority) as i64 as f64)?;
    
    Ok(())
}

pub fn extract_lexical_features(
    dict: &Bound<'_, PyDict>,
    words: &[String],
) -> PyResult<()> {
    let word_count = words.len();
    let unique_words: AHashSet<_> = words.iter().collect();
    let unique_count = unique_words.len();
    
    let diversity = if word_count > 0 {
        unique_count as f64 / word_count as f64
    } else {
        0.0
    };
    
    let avg_word_len = if !words.is_empty() {
        words.iter().map(|w| w.len()).sum::<usize>() as f64 / words.len() as f64
    } else {
        0.0
    };
    
    dict.set_item("tfidf_unique_word_ratio", diversity)?;
    dict.set_item("tfidf_avg_word_length", avg_word_len)?;
    
    Ok(())
}

pub fn extract_character_features(
    dict: &Bound<'_, PyDict>,
    text: &str,
    special_count: usize,
    uppercase_count: usize,
    digit_count: usize,
) -> PyResult<()> {
    let char_count = text.len();
    
    let special_ratio = if char_count > 0 {
        special_count as f64 / char_count as f64
    } else {
        0.0
    };
    
    let uppercase_ratio = if char_count > 0 {
        uppercase_count as f64 / char_count as f64
    } else {
        0.0
    };
    
    let digit_ratio = if char_count > 0 {
        digit_count as f64 / char_count as f64
    } else {
        0.0
    };
    
    dict.set_item("tfidf_special_char_ratio", special_ratio)?;
    dict.set_item("tfidf_uppercase_ratio", uppercase_ratio)?;
    dict.set_item("tfidf_digit_ratio", digit_ratio)?;
    
    Ok(())
}

pub fn extract_positional_features(
    dict: &Bound<'_, PyDict>,
    words: &[String],
    jailbreak_vocab: &AHashSet<String>,
) -> PyResult<()> {
    let word_count = words.len();
    let first_10_words = if word_count > 10 {
        &words[..10]
    } else {
        words
    };
    
    let early_count = first_10_words
        .iter()
        .filter(|w| jailbreak_vocab.contains(*w))
        .count();
    
    let early_ratio = if !first_10_words.is_empty() {
        early_count as f64 / first_10_words.len() as f64
    } else {
        0.0
    };
    
    dict.set_item("tfidf_early_jailbreak_ratio", early_ratio)?;
    
    Ok(())
}

pub fn extract_statistical_features(
    dict: &Bound<'_, PyDict>,
    words: &[String],
) -> PyResult<()> {
    if words.is_empty() {
        dict.set_item("tfidf_word_freq_entropy", 0.0)?;
        dict.set_item("tfidf_max_word_freq", 0.0)?;
        dict.set_item("tfidf_word_freq_std", 0.0)?;
        return Ok(());
    }
    
    let mut freq_map: HashMap<&String, usize> = HashMap::new();
    for word in words {
        *freq_map.entry(word).or_insert(0) += 1;
    }
    
    let word_count = words.len() as f64;
    let max_freq = *freq_map.values().max().unwrap_or(&0) as f64 / word_count;
    
    let probs: Vec<f64> = freq_map
        .values()
        .map(|&count| count as f64 / word_count)
        .collect();
    
    let entropy: f64 = -probs
        .iter()
        .map(|&p| if p > 0.0 { p * p.ln() } else { 0.0 })
        .sum::<f64>();
    
    let mean = 1.0 / freq_map.len() as f64;
    let variance: f64 = probs
        .iter()
        .map(|&p| (p - mean).powi(2))
        .sum::<f64>()
        / probs.len() as f64;
    let std_dev = variance.sqrt();
    
    dict.set_item("tfidf_word_freq_entropy", entropy)?;
    dict.set_item("tfidf_max_word_freq", max_freq)?;
    dict.set_item("tfidf_word_freq_std", std_dev)?;
    
    Ok(())
}
