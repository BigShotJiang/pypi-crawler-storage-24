use pyo3::prelude::*;
use pyo3::types::PyDict;
use std::collections::HashMap;
use ahash::AHashSet;
use regex::Regex;

mod lexicons;

use lexicons::*;

#[pyclass]
pub struct TFIDFExtractor {
    jailbreak_terms: AHashSet<String>,
    jailbreak_bigrams: AHashSet<String>,
    jailbreak_trigrams: AHashSet<String>,
    domain_terms: AHashSet<String>,
    ignore_terms: AHashSet<String>,
    override_terms: AHashSet<String>,
    persona_terms: AHashSet<String>,
    authority_terms: AHashSet<String>,
    obfuscated_trigrams: HashMap<String, &'static str>,
    obfuscated_quadgrams: HashMap<String, &'static str>,
    word_regex: Regex,
}

#[pymethods]
impl TFIDFExtractor {
    #[new]
    fn new() -> Self {
        let mut obfuscated_trigrams = HashMap::new();
        obfuscated_trigrams.insert("ign".to_string(), "ignore");
        obfuscated_trigrams.insert("gno".to_string(), "ignore");
        obfuscated_trigrams.insert("nor".to_string(), "ignore");
        obfuscated_trigrams.insert("byp".to_string(), "bypass");
        obfuscated_trigrams.insert("ypa".to_string(), "bypass");
        obfuscated_trigrams.insert("pas".to_string(), "bypass");
        obfuscated_trigrams.insert("ove".to_string(), "override");
        obfuscated_trigrams.insert("ver".to_string(), "override");
        obfuscated_trigrams.insert("rid".to_string(), "override");
        obfuscated_trigrams.insert("dis".to_string(), "disable");
        obfuscated_trigrams.insert("isa".to_string(), "disable");
        obfuscated_trigrams.insert("abl".to_string(), "disable");

        let mut obfuscated_quadgrams = HashMap::new();
        obfuscated_quadgrams.insert("igno".to_string(), "ignore");
        obfuscated_quadgrams.insert("gnor".to_string(), "ignore");
        obfuscated_quadgrams.insert("bypa".to_string(), "bypass");
        obfuscated_quadgrams.insert("ypas".to_string(), "bypass");
        obfuscated_quadgrams.insert("over".to_string(), "override");
        obfuscated_quadgrams.insert("verr".to_string(), "override");
        obfuscated_quadgrams.insert("disa".to_string(), "disable");
        obfuscated_quadgrams.insert("isab".to_string(), "disable");
        obfuscated_quadgrams.insert("admi".to_string(), "admin");
        obfuscated_quadgrams.insert("dmin".to_string(), "admin");

        TFIDFExtractor {
            jailbreak_terms: build_jailbreak_terms(),
            jailbreak_bigrams: build_jailbreak_bigrams(),
            jailbreak_trigrams: build_jailbreak_trigrams(),
            domain_terms: build_domain_terms(),
            ignore_terms: build_ignore_terms(),
            override_terms: build_override_terms(),
            persona_terms: build_persona_terms(),
            authority_terms: build_authority_terms(),
            obfuscated_trigrams,
            obfuscated_quadgrams,
            word_regex: Regex::new(r"\b\w+\b").unwrap(),
        }
    }

    fn extract_features(&self, py: Python, text: &str) -> PyResult<PyObject> {
        let dict = PyDict::new_bound(py);

        if text.is_empty() {
            return self.get_zero_features(py);
        }

        let text_lower = text.to_lowercase();
        let words: Vec<String> = self.word_regex
            .find_iter(&text_lower)
            .map(|m| m.as_str().to_string())
            .collect();
        let word_count = words.len();
        let char_count = text.len();

        // 1. Jailbreak term frequency
        let jailbreak_count = words.iter().filter(|w| self.jailbreak_terms.contains(w.as_str())).count();
        dict.set_item("tfidf_jailbreak_term_count", jailbreak_count as f64)?;
        dict.set_item("tfidf_jailbreak_term_ratio", if word_count > 0 { jailbreak_count as f64 / word_count as f64 } else { 0.0 })?;
        dict.set_item("tfidf_jailbreak_term_density", if word_count > 0 { (jailbreak_count as f64 / word_count as f64) * 100.0 } else { 0.0 })?;

        // Specific term categories
        let ignore_count = words.iter().filter(|w| self.ignore_terms.contains(w.as_str())).count();
        let override_count = words.iter().filter(|w| self.override_terms.contains(w.as_str())).count();
        let persona_count = words.iter().filter(|w| self.persona_terms.contains(w.as_str())).count();
        let authority_count = words.iter().filter(|w| self.authority_terms.contains(w.as_str())).count();

        dict.set_item("tfidf_ignore_terms", ignore_count as f64)?;
        dict.set_item("tfidf_override_terms", override_count as f64)?;
        dict.set_item("tfidf_persona_terms", persona_count as f64)?;
        dict.set_item("tfidf_authority_terms", authority_count as f64)?;

        // 2. Domain term frequency
        let domain_count = words.iter().filter(|w| self.domain_terms.contains(w.as_str())).count();
        dict.set_item("tfidf_domain_term_count", domain_count as f64)?;
        dict.set_item("tfidf_domain_term_ratio", if word_count > 0 { domain_count as f64 / word_count as f64 } else { 0.0 })?;

        // 3. Bigrams
        let mut bigram_matches = 0;
        if word_count >= 2 {
            for i in 0..words.len() - 1 {
                let bigram = format!("{} {}", words[i], words[i + 1]);
                if self.jailbreak_bigrams.contains(&bigram) {
                    bigram_matches += 1;
                }
            }
        }
        dict.set_item("tfidf_jailbreak_bigrams", bigram_matches as f64)?;
        dict.set_item("tfidf_jailbreak_bigrams_ratio", if word_count > 1 { bigram_matches as f64 / (word_count - 1) as f64 } else { 0.0 })?;

        // 4. Trigrams
        let mut trigram_matches = 0;
        if word_count >= 3 {
            for i in 0..words.len() - 2 {
                let trigram = format!("{} {} {}", words[i], words[i + 1], words[i + 2]);
                if self.jailbreak_trigrams.contains(&trigram) {
                    trigram_matches += 1;
                }
            }
        }
        dict.set_item("tfidf_jailbreak_trigrams", trigram_matches as f64)?;
        dict.set_item("tfidf_jailbreak_trigrams_ratio", if word_count > 2 { trigram_matches as f64 / (word_count - 2) as f64 } else { 0.0 })?;

        // 5. Character trigrams (Unicode-safe)
        let chars: Vec<char> = text_lower.chars().collect();
        let char_trigram_matches = if chars.len() >= 3 {
            (0..chars.len() - 2)
                .filter(|&i| {
                    let trigram: String = chars[i..i + 3].iter().collect();
                    self.obfuscated_trigrams.contains_key(trigram.as_str())
                })
                .count()
        } else {
            0
        };
        let char_trigram_count = chars.len().saturating_sub(2);
        dict.set_item("tfidf_char_trigram_matches", char_trigram_matches as f64)?;
        dict.set_item("tfidf_char_trigram_density", if char_trigram_count > 0 { (char_trigram_matches as f64 / char_trigram_count as f64) * 100.0 } else { 0.0 })?;

        // 6. Character quadgrams (Unicode-safe)
        let char_quadgram_matches = if chars.len() >= 4 {
            (0..chars.len() - 3)
                .filter(|&i| {
                    let quadgram: String = chars[i..i + 4].iter().collect();
                    self.obfuscated_quadgrams.contains_key(quadgram.as_str())
                })
                .count()
        } else {
            0
        };
        let char_quadgram_count = chars.len().saturating_sub(3);
        dict.set_item("tfidf_char_quadgram_matches", char_quadgram_matches as f64)?;
        dict.set_item("tfidf_char_quadgram_density", if char_quadgram_count > 0 { (char_quadgram_matches as f64 / char_quadgram_count as f64) * 100.0 } else { 0.0 })?;

        // 7. Combo features
        let has_ignore = words.iter().any(|w| self.ignore_terms.contains(w.as_str()));
        let has_instruction = words.iter().any(|w| w == "instruction" || w == "instructions");
        let has_previous = words.iter().any(|w| w == "previous" || w == "prior");
        let has_act = words.iter().any(|w| w == "act" || w == "pretend");
        let has_as = words.iter().any(|w| w == "as");
        let has_system = words.iter().any(|w| w == "system");
        let has_mode = words.iter().any(|w| w == "mode");

        dict.set_item("tfidf_ignore_instruction_combo", if has_ignore && has_instruction { 1.0 } else { 0.0 })?;
        dict.set_item("tfidf_ignore_previous_combo", if has_ignore && has_previous { 1.0 } else { 0.0 })?;
        dict.set_item("tfidf_act_as_combo", if has_act && has_as { 1.0 } else { 0.0 })?;
        dict.set_item("tfidf_system_mode_combo", if has_system && has_mode { 1.0 } else { 0.0 })?;

        // 8. Vocabulary richness
        let unique_words: AHashSet<&String> = words.iter().collect();
        dict.set_item("tfidf_type_token_ratio", if word_count > 0 { unique_words.len() as f64 / word_count as f64 } else { 0.0 })?;

        let avg_word_len = if !words.is_empty() { words.iter().map(|w| w.len()).sum::<usize>() as f64 / words.len() as f64 } else { 0.0 };
        dict.set_item("tfidf_avg_word_length", avg_word_len)?;

        // 9. Special character patterns
        let special_chars = text.chars().filter(|c| !c.is_alphanumeric() && !c.is_whitespace()).count();
        let upper_chars = text.chars().filter(|c| c.is_uppercase()).count();
        let digit_chars = text.chars().filter(|c| c.is_ascii_digit()).count();

        dict.set_item("tfidf_special_char_ratio", if char_count > 0 { special_chars as f64 / char_count as f64 } else { 0.0 })?;
        dict.set_item("tfidf_uppercase_ratio", if char_count > 0 { upper_chars as f64 / char_count as f64 } else { 0.0 })?;
        dict.set_item("tfidf_digit_ratio", if char_count > 0 { digit_chars as f64 / char_count as f64 } else { 0.0 })?;

        // 10. Positional features
        let first_10_words = if words.len() >= 10 { &words[..10] } else { &words[..] };
        let jailbreak_terms_early = first_10_words.iter().filter(|w| self.jailbreak_terms.contains(w.as_str())).count();
        dict.set_item("tfidf_jailbreak_terms_early", jailbreak_terms_early as f64)?;

        // 11. Statistical features
        if !words.is_empty() {
            let mut word_freq: HashMap<&String, usize> = HashMap::new();
            for word in &words {
                *word_freq.entry(word).or_insert(0) += 1;
            }
            let max_freq = word_freq.values().max().copied().unwrap_or(0);
            dict.set_item("tfidf_max_word_freq", max_freq as f64)?;
            dict.set_item("tfidf_max_word_freq_ratio", max_freq as f64 / word_count as f64)?;
        } else {
            dict.set_item("tfidf_max_word_freq", 0.0)?;
            dict.set_item("tfidf_max_word_freq_ratio", 0.0)?;
        }

        Ok(dict.unbind().into())
    }

    fn get_zero_features(&self, py: Python) -> PyResult<PyObject> {
        let dict = PyDict::new_bound(py);
        
        dict.set_item("tfidf_jailbreak_term_count", 0.0)?;
        dict.set_item("tfidf_jailbreak_term_ratio", 0.0)?;
        dict.set_item("tfidf_jailbreak_term_density", 0.0)?;
        dict.set_item("tfidf_ignore_terms", 0.0)?;
        dict.set_item("tfidf_override_terms", 0.0)?;
        dict.set_item("tfidf_persona_terms", 0.0)?;
        dict.set_item("tfidf_authority_terms", 0.0)?;
        dict.set_item("tfidf_domain_term_count", 0.0)?;
        dict.set_item("tfidf_domain_term_ratio", 0.0)?;
        dict.set_item("tfidf_jailbreak_bigrams", 0.0)?;
        dict.set_item("tfidf_jailbreak_bigrams_ratio", 0.0)?;
        dict.set_item("tfidf_jailbreak_trigrams", 0.0)?;
        dict.set_item("tfidf_jailbreak_trigrams_ratio", 0.0)?;
        dict.set_item("tfidf_char_trigram_matches", 0.0)?;
        dict.set_item("tfidf_char_trigram_density", 0.0)?;
        dict.set_item("tfidf_char_quadgram_matches", 0.0)?;
        dict.set_item("tfidf_char_quadgram_density", 0.0)?;
        dict.set_item("tfidf_ignore_instruction_combo", 0.0)?;
        dict.set_item("tfidf_ignore_previous_combo", 0.0)?;
        dict.set_item("tfidf_act_as_combo", 0.0)?;
        dict.set_item("tfidf_system_mode_combo", 0.0)?;
        dict.set_item("tfidf_type_token_ratio", 0.0)?;
        dict.set_item("tfidf_avg_word_length", 0.0)?;
        dict.set_item("tfidf_special_char_ratio", 0.0)?;
        dict.set_item("tfidf_uppercase_ratio", 0.0)?;
        dict.set_item("tfidf_digit_ratio", 0.0)?;
        dict.set_item("tfidf_jailbreak_terms_early", 0.0)?;
        dict.set_item("tfidf_max_word_freq", 0.0)?;
        dict.set_item("tfidf_max_word_freq_ratio", 0.0)?;

        Ok(dict.unbind().into())
    }
}

#[pymodule]
fn tfidf_extractor(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<TFIDFExtractor>()?;
    Ok(())
}
