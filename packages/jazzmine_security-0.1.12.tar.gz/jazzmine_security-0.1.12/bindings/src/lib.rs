use pyo3::prelude::*;

// Re-export the classes from each Rust library
use semantic_extractor::SemanticExtractor;
use text_normalizer::TextNormalizer;
use tfidf_extractor::TFIDFExtractor;

#[pymodule]
fn jazzmine_security_rust(m: &Bound<'_, PyModule>) -> PyResult<()> {
    // Add all classes from the three libraries
    m.add_class::<SemanticExtractor>()?;
    m.add_class::<TextNormalizer>()?;
    m.add_class::<TFIDFExtractor>()?;
    Ok(())
}