"""Constants and environment configuration for MansionGym."""

import os

# Objathor assets directory (where ai2thor loads 3D assets from)
# Can be overridden via environment variable OBJATHOR_ASSETS_BASE_DIR
ASSETS_VERSION = os.environ.get("ASSETS_VERSION", "2023_09_23")

OBJATHOR_ASSETS_BASE_DIR = os.environ.get(
    "OBJATHOR_ASSETS_BASE_DIR", os.path.expanduser("~/.objathor-assets")
)

OBJATHOR_VERSIONED_DIR = os.path.join(OBJATHOR_ASSETS_BASE_DIR, ASSETS_VERSION)
OBJATHOR_ASSETS_DIR = os.path.join(OBJATHOR_VERSIONED_DIR, "assets")

# AI2-THOR local executable path
# Can be overridden via environment variable LOCAL_AI2THOR_PATH
LOCAL_AI2THOR_PATH = os.environ.get(
    "LOCAL_AI2THOR_PATH",
    os.path.expanduser("~/.ai2thor/releases/thor-Linux64-local/thor-Linux64-local/thor-Linux64-local"),
)
