"""Interactive REPL session: Claude queries, Rich UI, and optional chat history persistence."""

from __future__ import annotations

import asyncio
import time
from pathlib import Path
from typing import Any

from claude_agent_sdk import ClaudeSDKClient

from assessment_cli.clean_logs import clean_logs
from assessment_cli.client_options import build_options
from assessment_cli.config import resolved_agent_workspace_directory, settings
from assessment_cli.chat_history_client import ChatHistoryClient
from assessment_cli.session_state import read_assessment_session_id, write_assessment_session_id
from assessment_cli.streaming import extract_stream_text, extract_text_blocks, extract_usage, usage_turn_tokens
from assessment_cli.ui import CLIUI
from assessment_cli.utils import utc_now_iso


async def _create_client(*, cwd: Path) -> ClaudeSDKClient:
    client = ClaudeSDKClient(options=build_options(cwd=cwd))
    await client.connect()
    return client


async def run_session() -> None:
    root_dir = resolved_agent_workspace_directory()
    client = await _create_client(cwd=root_dir)
    ui = CLIUI(model=settings.model, proxy_url=settings.assessment_proxy_url)
    assessment_duration_seconds = settings.tenx_assessment_duration_seconds
    timer_deadline_monotonic = time.monotonic() + assessment_duration_seconds
    ui.set_timer(
        duration_seconds=assessment_duration_seconds,
        deadline_monotonic=timer_deadline_monotonic,
    )
    chat_history = ChatHistoryClient(
        base_url=settings.assessment_proxy_url,
        token=settings.assessment_proxy_token,
    )
    chat_session_id: str | None = read_assessment_session_id()
    if chat_session_id:
        try:
            write_assessment_session_id(chat_session_id)
        except OSError as error:
            ui.show_error(f"Failed to persist assessment session id: {error}")
    elif chat_history.base_url:
        created_id, session_error = await chat_history.create_session()
        if session_error:
            ui.show_error(session_error)
        else:
            chat_session_id = created_id
            try:
                write_assessment_session_id(chat_session_id)
            except OSError as error:
                ui.show_error(f"Failed to persist assessment session id: {error}")

    ui.show_banner()
    meta_enabled = False
    session_cumulative_input_tokens = 0
    session_cumulative_output_tokens = 0

    try:
        while True:
            try:
                prompt = await ui.read_prompt_async()
            except EOFError:
                ui.print_blank()
                break
            except KeyboardInterrupt:
                ui.print_blank()
                break

            if not prompt:
                continue

            if prompt in {"/exit", "/quit"}:
                break
            if prompt == "/help":
                ui.show_help()
                continue
            if prompt == "/status":
                ui.show_status()
                continue
            if prompt == "/time":
                ui.show_time_remaining()
                continue
            if prompt == "/meta":
                meta_enabled = not meta_enabled
                ui.show_meta_mode(meta_enabled)
                continue
            if prompt == "/clear":
                await client.disconnect()
                client = await _create_client(cwd=root_dir)
                ui.show_session_reset()
                continue

            started = time.perf_counter()
            assistant_parts: list[str] = []
            usage: dict[str, Any] = {}
            status_code = 200
            stream_seen = False
            assistant_message_printed = False
            assistant_started = False
            working = ui.start_working()

            try:
                await client.query(prompt)
                async for message in client.receive_response():
                    stream_piece = extract_stream_text(message)
                    if stream_piece:
                        if not stream_seen:
                            assistant_parts.clear()
                            stream_seen = True
                        if not assistant_started:
                            ui.stop_working(working)
                            working = None
                            ui.rule_assistant()
                            ui.begin_assistant_reply()
                            assistant_started = True
                        assistant_parts.append(stream_piece)
                        ui.print_stream_text(stream_piece)
                    elif not stream_seen and not assistant_message_printed:
                        content = getattr(message, "content", None)
                        text = extract_text_blocks(content)
                        if text:
                            if not assistant_started:
                                ui.stop_working(working)
                                working = None
                                ui.rule_assistant()
                                ui.begin_assistant_reply()
                                assistant_started = True
                            assistant_parts.append(text)
                            ui.print_stream_text(text)
                            assistant_message_printed = True

                    new_usage = extract_usage(message)
                    if new_usage:
                        usage.update(new_usage)
            except Exception as error:
                status_code = 500
                error_message = f"[error] {error}"
                assistant_parts.append(error_message)
                ui.stop_working(working)
                working = None
                ui.show_error(error_message)
            finally:
                ui.stop_working(working)
                if assistant_started:
                    ui.print_blank()
                ui.end_assistant_reply()
                ui.rule_end()

            duration_ms = int((time.perf_counter() - started) * 1000)
            if meta_enabled:
                ui.print_meta_footer(duration_ms=duration_ms, usage=usage)

            assistant_raw = "".join(assistant_parts).strip()
            user_clean = clean_logs(prompt)
            assistant_clean = clean_logs(assistant_raw)
            turn_input_tokens, turn_output_tokens = usage_turn_tokens(usage)
            session_cumulative_input_tokens += turn_input_tokens
            session_cumulative_output_tokens += turn_output_tokens

            if status_code == 200 and not user_clean and not assistant_clean:
                continue

            if chat_session_id:
                message_payload = {
                    "session_id": chat_session_id,
                    "user_message": user_clean,
                    "assistant_message": assistant_clean,
                    "token_usage": {
                        "input": session_cumulative_input_tokens,
                        "output": session_cumulative_output_tokens,
                    },
                    "created_at": utc_now_iso(),
                }
                save_error = await chat_history.save_message(message_payload)
                if save_error:
                    ui.show_error(save_error)
    finally:
        await client.disconnect()

