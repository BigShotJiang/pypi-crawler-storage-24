"""Environment-backed settings for the CLI (anchored to the assessment-cli project root)."""

from pathlib import Path

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

PROJECT_ROOT = Path(__file__).resolve().parents[2]


class Settings(BaseSettings):
    anthropic_api_key: str | None = Field(default=None, validation_alias="ANTHROPIC_API_KEY")
    anthropic_base_url: str | None = Field(default=None, validation_alias="ANTHROPIC_BASE_URL")
    model: str = Field(
        default="claude-sonnet-4-5-20250929",
        validation_alias="MODEL",
    )
    assessment_proxy_url: str | None = Field(default=None, validation_alias="ASSESSMENT_PROXY_URL")
    assessment_proxy_token: str | None = Field(default=None, validation_alias="ASSESSMENT_PROXY_TOKEN")
    assessment_session_id: str | None = Field(default=None, validation_alias="ASSESSMENT_SESSION_ID")
    assessment_agent_cwd: str | None = Field(default=None, validation_alias="ASSESSMENT_AGENT_CWD")
    tenx_assessment_duration_seconds: int = Field(
        default=3600,
        ge=1,
        validation_alias="TENX_ASSESSMENT_DURATION_SECONDS",
    )
    # Deprecated: retained for backward compatibility with existing .env files.
    tenx_skip_frq: bool | None = Field(default=None, validation_alias="TENX_SKIP_FRQ")

    model_config = SettingsConfigDict(
        env_file=str(PROJECT_ROOT / ".env"),
        env_file_encoding="utf-8",
        case_sensitive=False,
    )


settings = Settings()


def resolved_agent_workspace_directory() -> Path:
    """Directory the agent uses for tools (Read, Bash, …); optional override via ASSESSMENT_AGENT_CWD."""
    raw = (settings.assessment_agent_cwd or "").strip()
    if not raw:
        return PROJECT_ROOT
    path = Path(raw).expanduser().resolve()
    if not path.is_dir():
        raise SystemExit(f"ASSESSMENT_AGENT_CWD must be an existing directory: {path}")
    return path

