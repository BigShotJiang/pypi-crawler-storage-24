"""模块注册表 — 动态管理面板模块类型"""

from __future__ import annotations

from typing import Any

# 注册表：name → {'label': str, 'class': WidgetClass}
_REGISTRY: dict[str, dict[str, Any]] = {}

# 旧名称 → 新名称映射（兼容已保存的布局）
_COMPAT: dict[str, str] = {
    'info_table': 'board',
    'game': 'status',
}


def register_module(name: str, label: str, widget_class: type) -> None:
    """注册一个面板模块类型"""
    _REGISTRY[name] = {
        'label': label,
        'class': widget_class,
    }


def get_module_names() -> list[str]:
    """返回所有已注册模块名称列表"""
    return list(_REGISTRY.keys())


def get_module_labels() -> dict[str, str]:
    """返回 {模块名: 显示标签} 字典"""
    return {k: v['label'] for k, v in _REGISTRY.items()}


def get_module_info(name: str) -> dict | None:
    """返回模块注册信息，未找到返回 None"""
    return _REGISTRY.get(name)


def resolve_compat_name(name: str) -> str:
    """旧名称映射到新名称"""
    return _COMPAT.get(name, name)


def is_known_module(name: str) -> bool:
    """检查模块是否已注册"""
    return name in _REGISTRY
