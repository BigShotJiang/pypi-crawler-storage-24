"""
网络通信模块
"""

import socket
import json


class NetworkManager:
    """网络管理"""
    
    def __init__(self, port):
        self.socket = None
        self.port = port
        self.connected = False

    def connect(self, host):
        """连接服务器"""
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.socket.settimeout(5)
        self.socket.connect((host, self.port))
        self.socket.settimeout(None)
        self.connected = True
        return True
    
    def disconnect(self):
        """断开连接"""
        self.connected = False
        if self.socket:
            try:
                self.socket.close()
            except:
                pass
    
    def send(self, data):
        """发送数据"""
        if not self.connected:
            return False
        try:
            msg = json.dumps(data) + '\n'
            self.socket.send(msg.encode('utf-8'))
            return True
        except:
            return False
