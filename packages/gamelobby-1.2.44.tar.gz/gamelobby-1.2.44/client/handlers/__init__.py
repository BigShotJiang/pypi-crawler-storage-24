"""
游戏客户端处理器自动注册

import client.handlers 即可触发所有处理器注册。
新增游戏处理器只需在此包中添加 import。
"""

# 添加新游戏处理器时在此 import，例如：
# from . import xxx_handler  # noqa: F401
