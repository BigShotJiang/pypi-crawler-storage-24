"""指令注册表 — 服务端下发，客户端纯缓存"""

from __future__ import annotations

from .game_handler import CommandInfo


# ── 服务端下发的当前位置指令集 ──

_current_commands: list[CommandInfo] = []


def set_commands(commands: list[dict]) -> None:
    """接收服务端下发的指令列表，替换当前缓存"""
    global _current_commands
    _current_commands = [
        CommandInfo(
            command=c.get('name', ''),
            label=c.get('label', ''),
            description=c.get('desc', ''),
        )
        for c in commands
    ]


def get_available_commands() -> list[CommandInfo]:
    """获取当前可用指令"""
    return list(_current_commands)


def filter_commands(prefix: str) -> list[CommandInfo]:
    """根据输入前缀过滤可用指令"""
    if not prefix:
        return list(_current_commands)
    return [c for c in _current_commands if c.command.startswith(prefix)]


def format_completion_bar(commands: list[CommandInfo], max_show: int = 6) -> str:
    """格式化指令列表为 action_bar 显示文本"""
    if not commands:
        return ""
    parts = [f"{c.command}({c.label})" for c in commands[:max_show]]
    text = "  ".join(parts)
    if len(commands) > max_show:
        text += f"  …(+{len(commands) - max_show})"
    return text
