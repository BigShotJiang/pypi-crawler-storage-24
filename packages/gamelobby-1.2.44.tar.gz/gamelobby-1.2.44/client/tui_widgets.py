"""
TUI 面板组件 — ChatPanel / CommandPanel / BoardPanel / StatusPanel
纯终端风格：所有面板只有 RichLog，无独立输入框
"""

from __future__ import annotations

from textual.app import ComposeResult
from textual.widgets import Static, RichLog
from textual.containers import Vertical
from textual.widget import Widget
from textual.scrollbar import ScrollBar, ScrollBarRender
from rich.segment import Segment, Segments
from rich.style import Style
from rich.color import Color

from .config import COLOR_BG_PRIMARY, COLOR_BORDER
from .game_registry import get_renderer
from .module_state import ModuleStateManager, MSG, SYS, HISTORY


# ═══════════════════════════════════════════════════════
#  圆角滚动条渲染器
# ═══════════════════════════════════════════════════════

class RoundedScrollBarRender(ScrollBarRender):
    """药丸形滚动条 — 用半块字符 ▄█▀ 组成圆头圆尾的拇指"""

    @classmethod
    def render_bar(
        cls,
        size: int = 25,
        virtual_size: float = 50,
        window_size: float = 20,
        position: float = 0,
        thickness: int = 1,
        vertical: bool = True,
        back_color: Color = Color.parse(COLOR_BG_PRIMARY),
        bar_color: Color = Color.parse(COLOR_BORDER),
    ) -> Segments:
        result = ScrollBarRender.render_bar(
            size=size, virtual_size=virtual_size, window_size=window_size,
            position=position, thickness=thickness, vertical=vertical,
            back_color=back_color, bar_color=bar_color,
        )
        if not vertical or not result.segments:
            return result

        segs = list(result.segments)
        # 找到拇指范围（有前景色的段即为拇指/部分块）
        thumb_indices = [
            i for i, seg in enumerate(segs)
            if seg.style and seg.style.color is not None
        ]
        if not thumb_indices:
            return result

        first, last = thumb_indices[0], thumb_indices[-1]
        meta = {"@mouse.down": "grab"}
        w = thickness
        cap_style = Style(color=bar_color, bgcolor=back_color, meta=meta)
        body_style = Style(color=bar_color, bgcolor=bar_color, meta=meta)

        if first == last:
            # 只有1格：用实心块
            segs[first] = Segment("█" * w, cap_style)
        elif last - first == 1:
            # 只有2格：上半圆 + 下半圆
            segs[first] = Segment("▄" * w, cap_style)
            segs[last] = Segment("▀" * w, cap_style)
        else:
            # 3格以上：上半圆 + 实心体 + 下半圆
            segs[first] = Segment("▄" * w, cap_style)
            for i in range(first + 1, last):
                segs[i] = Segment("█" * w, body_style)
            segs[last] = Segment("▀" * w, cap_style)

        return Segments(segs, new_lines=True)


# 全局替换滚动条渲染器
ScrollBar.renderer = RoundedScrollBarRender


# ═══════════════════════════════════════════════════════
#  PromptMixin — 输入提示（ChatPanel / CommandPanel 共用）
# ═══════════════════════════════════════════════════════

class PromptMixin:
    """面板输入提示的通用实现"""

    _prompt_id: str  # 子类必须定义

    def show_prompt(self, text: str = ""):
        prompt = self.query_one(f"#{self._prompt_id}", Static)
        prompt.update(f"> {text}█")
        prompt.add_class("visible")

    def update_prompt(self, text: str):
        prompt = self.query_one(f"#{self._prompt_id}", Static)
        prompt.update(f"> {text}█")

    def hide_prompt(self):
        prompt = self.query_one(f"#{self._prompt_id}", Static)
        prompt.update("")
        prompt.remove_class("visible")


# ═══════════════════════════════════════════════════════
#  ChatPanel — 聊天面板（左栏）
# ═══════════════════════════════════════════════════════

class ChatPanel(PromptMixin, Widget):
    """聊天面板：频道标签 + 消息日志"""

    CHANNEL_NAMES = {1: "世界", 2: "房间"}
    _prompt_id = "chat-prompt"

    def __init__(self, **kw):
        super().__init__(**kw)
        self.current_channel = 1

    def compose(self) -> ComposeResult:
        yield RichLog(id="chat-log", wrap=True, highlight=True, markup=True, max_lines=500)
        yield Static("", id="chat-prompt", classes="panel-prompt")

    def add_message(self, name: str, text: str, channel: int = 1, time_str: str = ""):
        if channel != self.current_channel:
            return
        log: RichLog = self.query_one("#chat-log", RichLog)
        log.write(f"{name}> {text}")

    def add_system_message(self, text: str):
        log: RichLog = self.query_one("#chat-log", RichLog)
        log.write(f"[dim]>>> {text}[/]")

    def show_history(self, messages: list, channel: int):
        if channel != self.current_channel:
            return
        log: RichLog = self.query_one("#chat-log", RichLog)
        log.clear()
        for m in messages:
            name = m.get("name", "???")
            text = m.get("text", "")
            log.write(f"{name}> {text}")

    def switch_channel(self, channel_id: int):
        self.current_channel = channel_id
        labels = []
        for cid, cname in self.CHANNEL_NAMES.items():
            if cid == channel_id:
                labels.append(f"[b]{cname}[/b]")
            else:
                labels.append(f"[dim]{cname}[/]")
        self.border_title = " │ ".join(labels)

    def update_online_users(self, users: list):
        if not users:
            self.border_subtitle = ""
            return
        self.border_subtitle = f"在线({len(users)})"

    def restore(self, state: ModuleStateManager):
        st = state.chat
        self.switch_channel(st.current_channel)
        log: RichLog = self.query_one("#chat-log", RichLog)
        for entry in st.entries:
            if entry[0] == MSG:
                _, name, text, channel, time_str = entry
                if channel == st.current_channel:
                    log.write(f"{name}> {text}")
            elif entry[0] == SYS:
                log.write(f"[dim]>>> {entry[1]}[/]")
            elif entry[0] == HISTORY:
                _, messages, channel = entry
                if channel == st.current_channel:
                    log.clear()
                    for m in messages:
                        log.write(f"{m.get('name', '???')}> {m.get('text', '')}")
        if st.online_count:
            self.border_subtitle = f"在线({st.online_count})"


# ═══════════════════════════════════════════════════════
#  CommandPanel — 指令面板（中栏）
# ═══════════════════════════════════════════════════════

class CommandPanel(PromptMixin, Widget):
    """指令面板：纯终端输出"""

    _prompt_id = "cmd-prompt"

    def compose(self) -> ComposeResult:
        yield RichLog(id="cmd-log", wrap=True, highlight=True, markup=True, max_lines=1000)
        yield Static("", id="cmd-prompt", classes="panel-prompt")

    def add_message(self, text: str, update_last: bool = False):
        log: RichLog = self.query_one("#cmd-log", RichLog)
        log.write(text)

    def clear(self):
        log: RichLog = self.query_one("#cmd-log", RichLog)
        log.clear()

    def set_action_bar(self, text: str):
        self.border_subtitle = text

    def clear_action_bar(self):
        self.border_subtitle = ""

    def restore(self, state: ModuleStateManager):
        st = state.cmd
        log: RichLog = self.query_one("#cmd-log", RichLog)
        for line in st.lines:
            log.write(line)
        if st.action_bar:
            self.border_subtitle = st.action_bar


# ═══════════════════════════════════════════════════════
#  BoardPanel — 棋盘/牌桌/地图（可视化游戏场景）
# ═══════════════════════════════════════════════════════

class BoardPanel(Widget):
    """棋盘面板：通过 RENDERER_REGISTRY 渲染任意游戏的棋盘/牌桌/地图"""

    def __init__(self, **kw):
        super().__init__(**kw)
        self.current_location = "lobby"

    def compose(self) -> ComposeResult:
        yield RichLog(id="board-content", wrap=True, highlight=True, markup=True, max_lines=500)

    def set_location(self, location: str):
        self.current_location = location

    def update_map(self, map_data):
        content: RichLog = self.query_one("#board-content", RichLog)
        content.clear()
        lines = map_data if isinstance(map_data, list) else map_data.split("\n")
        for line in lines:
            content.write(line)

    def update_status(self, player_data: dict):
        name = player_data.get("name", "?")
        level = player_data.get("level", 1)
        gold = player_data.get("gold", 0)
        self.border_subtitle = f"{name} Lv.{level} {gold}G"

    def update_table(self, room_data: dict | None):
        """通过渲染注册表渲染棋盘 — 这就是"切口" """
        content: RichLog = self.query_one("#board-content", RichLog)
        if room_data is None:
            content.clear()
            return
        game_type = room_data.get("game_type", "")
        renderer = get_renderer(game_type)
        if renderer:
            renderer.render_board(content, room_data)
        else:
            content.clear()
            content.write(f"[dim]未知游戏类型: {game_type}[/]")

    def restore(self, state: ModuleStateManager):
        st = state.board
        if st.player_data:
            self.update_status(st.player_data)
        if st.map_data:
            self.update_map(st.map_data)
        if st.room_data:
            self.update_table(st.room_data)
        self.set_location(st.location)


# ═══════════════════════════════════════════════════════
#  StatusPanel — 状态面板（手牌/走棋历史/属性等文字数据）
# ═══════════════════════════════════════════════════════

class StatusPanel(Widget):
    """状态面板：通过 RENDERER_REGISTRY 渲染手牌/走棋历史等游戏状态"""

    def compose(self) -> ComposeResult:
        yield RichLog(id="status-content", wrap=True, highlight=True, markup=True, max_lines=500)

    def update_game_status(self, game_type: str, game_data: dict):
        """通过渲染注册表渲染游戏状态 — 这就是"切口" """
        content: RichLog = self.query_one("#status-content", RichLog)
        renderer = get_renderer(game_type)
        if renderer:
            renderer.render_status(content, game_data)

    def add_message(self, text: str):
        content: RichLog = self.query_one("#status-content", RichLog)
        content.write(text)

    def clear(self):
        content: RichLog = self.query_one("#status-content", RichLog)
        content.clear()

    def restore(self, state: ModuleStateManager):
        st = state.status
        if st.game_type and st.game_data:
            self.update_game_status(st.game_type, st.game_data)
        else:
            log: RichLog = self.query_one("#status-content", RichLog)
            for line in st.lines:
                log.write(line)


# ═══════════════════════════════════════════════════════
#  OnlineUsersPanel — 在线用户列表
# ═══════════════════════════════════════════════════════

class OnlineUsersPanel(Widget):
    """在线用户列表面板"""

    def compose(self) -> ComposeResult:
        yield RichLog(id="online-log", wrap=True, highlight=True, markup=True, max_lines=200)

    def update_users(self, users: list):
        content: RichLog = self.query_one("#online-log", RichLog)
        content.clear()
        content.write(f"[b]在线 ({len(users)})[/b]")
        content.write("─" * 16)
        for u in users:
            if isinstance(u, dict):
                content.write(u.get("name", str(u)))
            else:
                content.write(str(u))

    def restore(self, state: ModuleStateManager):
        if state.online.users:
            self.update_users(state.online.users)


# ── 注册内置模块 ──

from .module_registry import register_module  # noqa: E402

register_module('chat',   '聊天',     ChatPanel)
register_module('cmd',    '指令',     CommandPanel)
register_module('board',  '棋盘',     BoardPanel)
register_module('status', '状态',     StatusPanel)
register_module('online', '在线用户', OnlineUsersPanel)
