"""
游戏渲染器包 — 导入即自动注册

添加新游戏渲染器：
  1. 在此目录下新建 xxx_renderer.py
  2. 实现 GameRenderer 协议并调用 register_renderer()
  3. 在此文件中 import 该模块
"""

# 添加新游戏渲染器时在此 import，例如：
# from . import xxx_renderer  # noqa: F401
