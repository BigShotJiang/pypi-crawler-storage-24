from typing import Optional

import numpy as np
from scipy.sparse.linalg import LinearOperator, eigsh

from vicentin.kernels import Kernel, LinearKernel


def PCA(X: np.ndarray | Kernel, n_components: Optional[int] = None):
    if isinstance(X, Kernel):
        kernel = X
        X = kernel.X
    else:
        kernel = LinearKernel(X).center()

    if n_components is None:
        n_components = kernel.N - 1
    n_components = min(n_components, kernel.N - 1)

    matvec = lambda v: (kernel @ v).reshape(-1)
    K_op = LinearOperator(shape=kernel.shape, matvec=matvec, dtype=np.float64)

    eigenvalues, eigenvectors = eigsh(K_op, k=n_components, which="LM")

    idx = np.argsort(eigenvalues)[::-1]
    eigenvalues = eigenvalues[idx]
    eigenvectors = eigenvectors[:, idx]

    eigenvectors = eigenvectors / np.sqrt(np.maximum(eigenvalues, 1e-12))

    return eigenvalues, eigenvectors
