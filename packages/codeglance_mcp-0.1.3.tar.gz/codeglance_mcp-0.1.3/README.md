# CodeGlance MCP Server

An MCP (Model Context Protocol) server that analyzes GitHub repositories using Gemini AI and generates comprehensive documentation — project overviews, architecture guides, file insights, and more.

Works with any MCP-compatible client: Claude Code, Claude Desktop, Cursor, Windsurf, etc.

## Quick Start

### 1. Get a Gemini API Key

Get a free API key from [Google AI Studio](https://aistudio.google.com/app/apikey).

### 2. Install & Configure

#### Claude Code

```bash
claude mcp add codeglance -e GEMINI_API_KEY=your_key_here -- uvx codeglance-mcp
```

That's it. Verify with:

```bash
claude mcp list
```

#### Claude Desktop / Cursor / Other MCP Clients

Add to your MCP config file (`claude_desktop_config.json`, `.cursor/mcp.json`, etc.):

```json
{
  "mcpServers": {
    "codeglance": {
      "command": "uvx",
      "args": ["codeglance-mcp"],
      "env": {
        "GEMINI_API_KEY": "your_gemini_api_key_here"
      }
    }
  }
}
```

#### Alternative: Install via pip

```bash
pip install codeglance-mcp
```

Then configure your MCP client to run `codeglance-mcp` as the command instead of `uvx codeglance-mcp`.

## What It Does

When you ask your AI assistant to analyze a repository, CodeGlance:

1. **Clones** the repository (shallow clone for speed)
2. **Reads** key files (README, package.json, config files, entry points)
3. **Sends** the context to Gemini AI with specialized analysis prompts
4. **Generates** 6 documentation files in `codeglance-analysis/guide/`

### Generated Documentation

| File | Description |
|------|-------------|
| `01-overview.md` | 5-minute project overview |
| `02-tree.md` | Annotated directory structure |
| `03-file-insights.md` | Key files and their purposes |
| `04-architecture.md` | System architecture deep-dive |
| `05-quick-start.md` | Getting started guide |
| `06-master-analysis.md` | Comprehensive technical analysis |

## MCP Tools

| Tool | Description |
|------|-------------|
| `analyze_repository` | Run full analysis on a GitHub repo |
| `get_repository_info` | Check if a repo is already cloned |
| `list_generated_guides` | List generated documentation files |

## MCP Prompts

| Prompt | Description |
|--------|-------------|
| `comprehensive_analysis` | Full analysis workflow |
| `quick_overview` | Fast overview only |
| `architecture_review` | Architecture-focused analysis |
| `security_audit` | Security-focused review |

## Configuration

All settings can be customized via environment variables in your MCP config:

| Variable | Default | Description |
|----------|---------|-------------|
| `GEMINI_API_KEY` | *(required)* | Your Google Gemini API key |
| `MAX_FILE_SIZE` | `5000` | Max characters per file to analyze |
| `MAX_FILES_PER_ANALYSIS` | `50` | Max files to include in analysis |
| `TIMEOUT_SECONDS` | `120` | API request timeout |
| `MAX_CONCURRENT_REQUESTS` | `3` | Concurrent Gemini API calls |
| `CACHE_TTL_SECONDS` | `3600` | In-memory cache TTL |

Example with custom settings:

```json
{
  "mcpServers": {
    "codeglance": {
      "command": "uvx",
      "args": ["codeglance-mcp"],
      "env": {
        "GEMINI_API_KEY": "your_key",
        "TIMEOUT_SECONDS": "180",
        "MAX_CONCURRENT_REQUESTS": "5"
      }
    }
  }
}
```

## Requirements

- Python 3.11+
- Git (for cloning repositories)
- A [Gemini API key](https://aistudio.google.com/app/apikey) (free tier works)

## Development

```bash
git clone https://github.com/lucidopus/codeglance-mcp.git
cd codeglance-mcp
uv sync

# Run locally
GEMINI_API_KEY=your_key uv run codeglance-mcp
```

## License

MIT
