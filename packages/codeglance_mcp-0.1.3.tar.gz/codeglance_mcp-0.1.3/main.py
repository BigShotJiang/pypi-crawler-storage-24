#!/usr/bin/env python3
"""CodeGlance MCP Server - Entry Point."""

from codeglance_mcp import main

if __name__ == "__main__":
    main()
