"""CodeGlance MCP Server - Comprehensive GitHub repository analysis using Gemini AI."""

from codeglance_mcp.server import main

__all__ = ["main"]
