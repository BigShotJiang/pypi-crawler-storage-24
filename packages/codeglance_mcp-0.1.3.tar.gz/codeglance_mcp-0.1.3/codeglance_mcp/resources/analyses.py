"""MCP Resources for accessing generated analyses."""

from pathlib import Path
from typing import List
import logging
from mcp.types import Resource, TextContent

from codeglance_mcp.utils.async_helpers import read_file_async

logger = logging.getLogger(__name__)


class AnalysisResource:
    """Resource handler for generated analyses."""

    @staticmethod
    async def list_analyses(working_directory: str = ".") -> List[Resource]:
        """List all generated analysis files as resources."""
        resources = []
        try:
            guide_dir = Path(working_directory) / "codeglance-analysis" / "guide"
            if not guide_dir.exists():
                return resources

            analysis_files = {
                "README.md": "Analysis Index",
                "01-overview.md": "Project Overview",
                "02-tree.md": "Directory Structure",
                "03-file-insights.md": "File Insights",
                "04-architecture.md": "System Architecture",
                "05-quick-start.md": "Quick Start Guide",
                "06-master-analysis.md": "Master Analysis",
            }

            for filename, description in analysis_files.items():
                file_path = guide_dir / filename
                if file_path.exists():
                    repo_name = "unknown"
                    try:
                        analysis_dir = Path(working_directory) / "codeglance-analysis"
                        repo_dirs = [d for d in analysis_dir.iterdir() if d.is_dir() and d.name != "guide"]
                        if repo_dirs:
                            repo_name = repo_dirs[0].name
                    except Exception:
                        pass

                    resource = Resource(
                        uri=f"analysis://guides/{repo_name}/{filename}",
                        name=f"Analysis: {filename}",
                        description=description,
                        mimeType="text/markdown"
                    )
                    resources.append(resource)

        except Exception as e:
            logger.error(f"Error listing analyses: {e}")

        return resources

    @staticmethod
    async def read_analysis(repo_name: str, filename: str, working_directory: str = ".") -> TextContent:
        """Read a specific analysis file."""
        try:
            guide_dir = Path(working_directory) / "codeglance-analysis" / "guide"
            analysis_file = guide_dir / filename

            if not analysis_file.exists():
                return TextContent(
                    type="text",
                    text=f"Analysis file '{filename}' not found for repository '{repo_name}'"
                )

            content = await read_file_async(analysis_file, max_size=100000)
            if content:
                return TextContent(type="text", text=content)
            else:
                return TextContent(type="text", text=f"Could not read analysis file '{filename}'")

        except Exception as e:
            logger.error(f"Error reading analysis {repo_name}/{filename}: {e}")
            return TextContent(type="text", text=f"Error reading analysis: {str(e)}")


analysis_resource = AnalysisResource()
