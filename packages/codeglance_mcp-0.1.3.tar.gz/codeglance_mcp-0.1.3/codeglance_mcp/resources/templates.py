"""MCP Resources for accessing prompt templates."""

from pathlib import Path
from typing import List
import logging
from mcp.types import Resource, TextContent

from codeglance_mcp.config import config
from codeglance_mcp.utils.async_helpers import read_file_async

logger = logging.getLogger(__name__)


class TemplateResource:
    """Resource handler for prompt templates."""

    @staticmethod
    async def list_templates() -> List[Resource]:
        """List all available prompt templates as resources."""
        resources = []
        try:
            if not config.prompts_dir.exists():
                logger.warning(f"Prompts directory not found: {config.prompts_dir}")
                return resources

            for template_file in config.prompts_dir.glob("*.md"):
                template_name = template_file.stem
                resource = Resource(
                    uri=f"prompt://templates/{template_name}",
                    name=f"Prompt Template: {template_name}",
                    description=f"Analysis prompt template for {template_name.replace('-', ' ').title()}",
                    mimeType="text/markdown"
                )
                resources.append(resource)

        except Exception as e:
            logger.error(f"Error listing templates: {e}")

        return resources

    @staticmethod
    async def read_template(template_name: str) -> TextContent:
        """Read a specific prompt template."""
        try:
            template_file = config.prompts_dir / f"{template_name}.md"

            if not template_file.exists():
                return TextContent(
                    type="text",
                    text=f"Template '{template_name}' not found. Available templates: {[f.stem for f in config.prompts_dir.glob('*.md')]}"
                )

            content = await read_file_async(template_file, max_size=50000)
            if content:
                return TextContent(type="text", text=content)
            else:
                return TextContent(type="text", text=f"Could not read template '{template_name}'")

        except Exception as e:
            logger.error(f"Error reading template {template_name}: {e}")
            return TextContent(type="text", text=f"Error reading template: {str(e)}")


template_resource = TemplateResource()
