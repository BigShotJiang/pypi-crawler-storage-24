"""MCP server for CodeGlance - comprehensive GitHub repository analysis."""

import asyncio
import os
from pathlib import Path
from typing import List
import logging

from pydantic import BaseModel, Field
from mcp.server.fastmcp import FastMCP
from mcp.types import TextContent

from codeglance_mcp.config import config
from codeglance_mcp.tools.analyzer import analyzer
from codeglance_mcp.resources.templates import template_resource
from codeglance_mcp.resources.analyses import analysis_resource
from codeglance_mcp.prompts_handlers.workflows import workflow_handler
from codeglance_mcp.utils.gemini_client import gemini_client
from codeglance_mcp.utils.async_helpers import write_file_async

logger = logging.getLogger(__name__)


def resolve_working_directory(working_directory: str) -> str:
    """Resolve working directory to absolute path."""
    if working_directory == ".":
        caller_cwd = os.getenv('CLAUDE_CWD')
        if caller_cwd:
            return caller_cwd
        return os.getcwd()
    return os.path.abspath(working_directory)


# Create the MCP server instance
mcp = FastMCP("CodeGlance")


# Pydantic models for structured output
class AnalysisResult(BaseModel):
    success: bool = Field(description="Whether analysis completed successfully")
    message: str = Field(description="Status message")
    output_files: List[str] = Field(description="List of generated documentation files")
    repository_path: str = Field(description="Path to the cloned repository")
    gemini_available: bool = Field(description="Whether Gemini API was available for analysis")
    context_file_content: str = Field(
        default="",
        description=(
            "AI context file content generated from the analysis. "
            "You MUST save this as your context file at the ROOT of the analyzed project "
            "(e.g. CLAUDE.md for Claude Code, .cursorrules for Cursor, "
            ".windsurfrules for Windsurf, .github/copilot-instructions.md for Copilot). "
            "Do NOT modify any other files in the project — only create this one context file."
        )
    )


class RepositoryInfo(BaseModel):
    repo_url: str = Field(description="GitHub repository URL")
    repo_name: str = Field(description="Repository name")
    local_path: str = Field(description="Local path where repository would be/is stored")
    already_cloned: bool = Field(description="Whether repository is already cloned locally")
    working_directory: str = Field(description="Working directory used")


class GeneratedGuide(BaseModel):
    filename: str = Field(description="Name of the guide file")
    path: str = Field(description="Full path to the guide file")
    title: str = Field(description="Title/description of the guide")
    size_bytes: int = Field(description="File size in bytes")


# MCP Tools
@mcp.tool()
async def analyze_repository(repo_url: str, working_directory: str = ".") -> AnalysisResult:
    """Execute comprehensive code analysis workflow on a GitHub repository.

    Clones the repository, analyzes it with Gemini AI, and generates 6 documentation
    files covering overview, structure, file insights, architecture, quick-start, and
    a master analysis.

    Args:
        repo_url: GitHub repository URL to analyze
        working_directory: Directory where to create analysis folder (default: current directory)
    """
    try:
        working_directory = resolve_working_directory(working_directory)
        repo_name = repo_url.removesuffix('.git').rstrip('/').split('/')[-1]
        analysis_dir = Path(working_directory) / "codeglance-analysis"
        analysis_dir.mkdir(parents=True, exist_ok=True)

        # Clone repository
        success, message, repo_path = await analyzer.clone_repository(repo_url, str(analysis_dir))
        if not success:
            return AnalysisResult(
                success=False,
                message=f"Failed to clone repository: {message}",
                output_files=[],
                repository_path="",
                gemini_available=gemini_client.is_available()
            )

        # Create guide directory
        guide_dir = analysis_dir / "guide"
        guide_dir.mkdir(exist_ok=True)

        output_files = []

        if gemini_client.is_available():
            analysis_templates = [
                ("project-overview", "01-overview.md"),
                ("visual-tree", "02-tree.md"),
                ("file-insights", "03-file-insights.md"),
                ("architecture", "04-architecture.md"),
                ("quick-start", "05-quick-start.md"),
                ("master-analysis", "06-master-analysis.md"),
            ]

            tasks = []
            for template_name, output_filename in analysis_templates:
                output_file = guide_dir / output_filename
                task = analyzer.generate_analysis(template_name, Path(repo_path), output_file)
                tasks.append((task, str(output_file)))

            results = await asyncio.gather(*[task for task, _ in tasks], return_exceptions=True)

            for (_, output_file), result in zip(tasks, results):
                if isinstance(result, Exception):
                    logger.error(f"Analysis task failed for {output_file}: {result}")
                    placeholder = f"# Analysis Failed\n\nError: {result}\n\nPlease check logs or try again."
                    await write_file_async(Path(output_file), placeholder)
                    output_files.append(output_file)
                else:
                    success_result, message_result = result
                    if success_result:
                        output_files.append(output_file)
                    else:
                        logger.error(f"Analysis failed for {output_file}: {message_result}")
                        placeholder = f"# Analysis Failed\n\nError: {message_result}\n\nPlease check logs or try again."
                        await write_file_async(Path(output_file), placeholder)
                        output_files.append(output_file)
        else:
            placeholder = (
                "# Analysis requires GEMINI_API_KEY\n\n"
                "Please configure your Gemini API key to generate this analysis.\n"
                "See: https://aistudio.google.com/app/apikey"
            )
            for filename in ["01-overview.md", "02-tree.md", "03-file-insights.md",
                             "04-architecture.md", "05-quick-start.md", "06-master-analysis.md"]:
                f = guide_dir / filename
                await write_file_async(f, placeholder)
                output_files.append(str(f))

        # Create index file
        index_content = f"""# CodeGlance Analysis: {repo_name}

**Repository:** {repo_url}
**Local Path:** {repo_path}
**Gemini API:** {'Available' if gemini_client.is_available() else 'Not Available'}

## Generated Documentation

1. [Project Overview](01-overview.md)
2. [Directory Structure](02-tree.md)
3. [File Insights](03-file-insights.md)
4. [System Architecture](04-architecture.md)
5. [Quick Start Guide](05-quick-start.md)
6. [Master Analysis](06-master-analysis.md)
"""
        index_file = guide_dir / "README.md"
        await write_file_async(index_file, index_content)
        output_files.append(str(index_file))

        # Generate AI context file content
        context_content = ""
        if gemini_client.is_available():
            try:
                context_result = await analyzer.generate_context_file(Path(repo_path))
                if context_result[0]:
                    context_content = context_result[1]
            except Exception as e:
                logger.error(f"Failed to generate context file: {e}")

        return AnalysisResult(
            success=True,
            message=f"Successfully analyzed {repo_name}. Generated {len(output_files)} files.",
            output_files=output_files,
            repository_path=repo_path,
            gemini_available=gemini_client.is_available(),
            context_file_content=context_content,
        )

    except Exception as e:
        logger.error(f"Error in analyze_repository: {e}")
        return AnalysisResult(
            success=False,
            message=f"Error: {str(e)}",
            output_files=[],
            repository_path="",
            gemini_available=gemini_client.is_available()
        )


@mcp.tool()
async def get_repository_info(repo_url: str, working_directory: str = ".") -> RepositoryInfo:
    """Get information about a repository and whether it's already cloned locally.

    Args:
        repo_url: GitHub repository URL
        working_directory: Directory where analysis folder should be located
    """
    try:
        working_directory = resolve_working_directory(working_directory)
        repo_name = repo_url.removesuffix('.git').rstrip('/').split('/')[-1]
        local_path = Path(working_directory) / "codeglance-analysis" / repo_name

        return RepositoryInfo(
            repo_url=repo_url,
            repo_name=repo_name,
            local_path=str(local_path),
            already_cloned=local_path.exists(),
            working_directory=working_directory
        )
    except Exception as e:
        logger.error(f"Error in get_repository_info: {e}")
        return RepositoryInfo(
            repo_url=repo_url,
            repo_name="error",
            local_path="",
            already_cloned=False,
            working_directory=working_directory
        )


@mcp.tool()
async def list_generated_guides(working_directory: str = ".") -> List[GeneratedGuide]:
    """List all generated guide files in the codeglance-analysis/guide directory.

    Args:
        working_directory: Directory where codeglance-analysis folder should be located
    """
    try:
        working_directory = resolve_working_directory(working_directory)
        guide_dir = Path(working_directory) / "codeglance-analysis" / "guide"
        guides = []

        if not guide_dir.exists():
            return guides

        guide_files = {
            "README.md": "Analysis Index",
            "01-overview.md": "Project Overview",
            "02-tree.md": "Directory Structure",
            "03-file-insights.md": "File Insights",
            "04-architecture.md": "System Architecture",
            "05-quick-start.md": "Quick Start Guide",
            "06-master-analysis.md": "Master Analysis",
        }

        for filename, description in guide_files.items():
            file_path = guide_dir / filename
            if file_path.exists():
                guides.append(GeneratedGuide(
                    filename=filename,
                    path=str(file_path),
                    title=description,
                    size_bytes=file_path.stat().st_size
                ))

        return guides

    except Exception as e:
        logger.error(f"Error in list_generated_guides: {e}")
        return []


# MCP Resources
@mcp.resource("prompt://templates/{template_name}")
async def get_prompt_template(template_name: str) -> TextContent:
    """Access prompt templates as resources."""
    return await template_resource.read_template(template_name)


@mcp.resource("analysis://guides/{repo_name}/{filename}")
async def get_analysis_file(repo_name: str, filename: str) -> TextContent:
    """Access generated analysis files as resources."""
    return await analysis_resource.read_analysis(repo_name, filename)


# MCP Prompts
@mcp.prompt()
async def comprehensive_analysis(repo_url: str, working_directory: str = ".") -> str:
    """Complete repository analysis workflow with all documentation types."""
    working_directory = resolve_working_directory(working_directory)
    return await workflow_handler.handle_comprehensive_analysis({
        "repo_url": repo_url,
        "working_directory": working_directory
    })


@mcp.prompt()
async def quick_overview(repo_url: str, working_directory: str = ".") -> str:
    """Fast repository overview for quick understanding."""
    working_directory = resolve_working_directory(working_directory)
    return await workflow_handler.handle_quick_overview({
        "repo_url": repo_url,
        "working_directory": working_directory
    })


@mcp.prompt()
async def architecture_review(repo_url: str, working_directory: str = ".") -> str:
    """Architecture-focused analysis for system design understanding."""
    working_directory = resolve_working_directory(working_directory)
    return await workflow_handler.handle_architecture_review({
        "repo_url": repo_url,
        "working_directory": working_directory
    })


@mcp.prompt()
async def security_audit(repo_url: str, working_directory: str = ".") -> str:
    """Security-focused repository review."""
    working_directory = resolve_working_directory(working_directory)
    return await workflow_handler.handle_security_audit({
        "repo_url": repo_url,
        "working_directory": working_directory
    })


def main():
    """Run the MCP server."""
    logger.info("Starting CodeGlance MCP server...")
    logger.info(f"Gemini API available: {gemini_client.is_available()}")
    mcp.run()
