"""Async Gemini client following MCP best practices."""

import asyncio
import google.generativeai as genai
import logging
from codeglance_mcp.config import config

logger = logging.getLogger(__name__)


class GeminiClient:
    """Async Gemini client with proper error handling."""

    def __init__(self):
        self.model = None
        self._semaphore = asyncio.Semaphore(config.max_concurrent_requests)

        if config.has_gemini_key:
            try:
                genai.configure(api_key=config.gemini_api_key)
                self.model = genai.GenerativeModel(config.content_generation_model)
                logger.info("Gemini client initialized successfully")
            except Exception as e:
                logger.error(f"Failed to initialize Gemini client: {e}")
                self.model = None
        else:
            logger.warning("No Gemini API key found - AI features disabled")

    async def generate_content_async(self, prompt: str) -> tuple[bool, str]:
        """Generate content asynchronously with proper error handling."""
        if not self.model:
            return False, "Gemini client not initialized - please set GEMINI_API_KEY"

        async with self._semaphore:
            try:
                response = await asyncio.wait_for(
                    self.model.generate_content_async(prompt),
                    timeout=config.timeout_seconds
                )

                if response and response.text:
                    return True, response.text
                else:
                    return False, "No content generated"

            except asyncio.TimeoutError:
                logger.error(f"Gemini request timeout after {config.timeout_seconds}s")
                return False, f"Request timeout after {config.timeout_seconds}s"
            except Exception as e:
                logger.error(f"Gemini API error: {e}")
                return False, f"API error: {str(e)}"

    def is_available(self) -> bool:
        """Check if Gemini client is available."""
        return self.model is not None


# Global client instance
gemini_client = GeminiClient()
