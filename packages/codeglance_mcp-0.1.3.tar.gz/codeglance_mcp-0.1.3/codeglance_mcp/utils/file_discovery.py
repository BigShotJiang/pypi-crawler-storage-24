"""Intelligent file discovery and prioritization for repository analysis."""

import os
import re
import asyncio
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple
import logging

from codeglance_mcp.utils.async_helpers import read_file_async

logger = logging.getLogger(__name__)

# Directories to always skip
IGNORED_DIRS: Set[str] = {
    ".git", "node_modules", "__pycache__", ".venv", "venv", "env",
    ".tox", "dist", "build", ".next", ".nuxt", "target", "out",
    "vendor", ".gradle", ".mvn", "Pods", ".dart_tool",
    ".eggs", "coverage", ".nyc_output", ".cache", ".parcel-cache",
    ".terraform", ".serverless", ".angular", ".svelte-kit",
    "bower_components", "jspm_packages", ".webpack", ".turbo",
}

# Extensions to skip entirely (binary/non-source)
BINARY_EXTENSIONS: Set[str] = {
    ".png", ".jpg", ".jpeg", ".gif", ".bmp", ".ico", ".svg", ".webp",
    ".mp3", ".mp4", ".wav", ".avi", ".mov", ".mkv",
    ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
    ".zip", ".tar", ".gz", ".bz2", ".rar", ".7z",
    ".woff", ".woff2", ".ttf", ".eot", ".otf",
    ".so", ".dylib", ".dll", ".exe", ".bin", ".dat",
    ".pyc", ".pyo", ".class", ".o", ".obj",
    ".sqlite", ".db", ".sqlite3",
    ".DS_Store",
}

# Lock files to skip
LOCK_FILES: Set[str] = {
    "package-lock.json", "yarn.lock", "pnpm-lock.yaml",
    "Pipfile.lock", "poetry.lock", "Gemfile.lock",
    "composer.lock", "Cargo.lock", "go.sum",
}

LANGUAGE_EXTENSIONS: Dict[str, str] = {
    ".py": "python", ".js": "javascript", ".ts": "typescript",
    ".tsx": "typescript", ".jsx": "javascript", ".go": "go",
    ".rs": "rust", ".java": "java", ".kt": "kotlin",
    ".rb": "ruby", ".php": "php", ".cs": "csharp",
    ".cpp": "cpp", ".c": "c", ".h": "c", ".hpp": "cpp",
    ".swift": "swift", ".scala": "scala",
    ".ex": "elixir", ".exs": "elixir",
    ".dart": "dart", ".lua": "lua", ".r": "r", ".R": "r",
    ".vue": "vue", ".svelte": "svelte",
}

# Import patterns per language (compiled regexes)
IMPORT_PATTERNS: Dict[str, List[re.Pattern]] = {
    "python": [
        re.compile(r"^from\s+(\S+)\s+import", re.MULTILINE),
        re.compile(r"^import\s+(\S+)", re.MULTILINE),
    ],
    "javascript": [
        re.compile(r"""import\s+.*?from\s+['"](\..*?)['"]""", re.MULTILINE),
        re.compile(r"""require\(\s*['"](\..*?)['"]\s*\)""", re.MULTILINE),
    ],
    "typescript": [
        re.compile(r"""import\s+.*?from\s+['"](\..*?)['"]""", re.MULTILINE),
        re.compile(r"""require\(\s*['"](\..*?)['"]\s*\)""", re.MULTILINE),
    ],
    "go": [
        re.compile(r'"([^"]+)"', re.MULTILINE),
    ],
    "rust": [
        re.compile(r"use\s+(\S+)::", re.MULTILINE),
        re.compile(r"mod\s+(\w+);", re.MULTILINE),
    ],
    "java": [
        re.compile(r"^import\s+(\S+);", re.MULTILINE),
    ],
    "kotlin": [
        re.compile(r"^import\s+(\S+)", re.MULTILINE),
    ],
}


@dataclass
class FileInfo:
    """Metadata about a discovered file."""
    rel_path: str
    abs_path: Path
    size_bytes: int
    extension: str
    depth: int
    category: str = "source"
    priority_score: float = 0.0
    language: str = ""
    imported_by_count: int = 0


# Category weights for scoring
CATEGORY_WEIGHTS: Dict[str, int] = {
    "entry_point": 10,
    "config_root": 9,
    "readme": 8,
    "schema_model": 8,
    "api_route": 7,
    "config_build": 7,
    "config_env": 7,
    "core_logic": 6,
    "type_def": 5,
    "source": 4,
    "docs": 3,
    "test": 2,
    "generated": 1,
    "asset": 0,
}

# Filename patterns for classification
ENTRY_POINT_PATTERNS = [
    re.compile(r"^main\.(py|go|rs|js|ts|java|kt|rb|swift)$"),
    re.compile(r"^index\.(js|ts|tsx|jsx)$"),
    re.compile(r"^app\.(py|js|ts|tsx|jsx)$"),
    re.compile(r"^server\.(py|js|ts|go)$"),
    re.compile(r"^cli\.(py|js|ts|go)$"),
    re.compile(r"^__main__\.py$"),
    re.compile(r"^manage\.py$"),
    re.compile(r"^wsgi\.py$"),
    re.compile(r"^asgi\.py$"),
]

CONFIG_ROOT_PATTERNS = [
    re.compile(r"^package\.json$"),
    re.compile(r"^pyproject\.toml$"),
    re.compile(r"^Cargo\.toml$"),
    re.compile(r"^go\.mod$"),
    re.compile(r"^pom\.xml$"),
    re.compile(r"^build\.gradle(\.kts)?$"),
    re.compile(r"^Gemfile$"),
    re.compile(r"^composer\.json$"),
    re.compile(r"^setup\.(py|cfg)$"),
    re.compile(r"^requirements.*\.txt$"),
]

CONFIG_BUILD_PATTERNS = [
    re.compile(r"^Dockerfile.*$"),
    re.compile(r"^docker-compose.*\.ya?ml$"),
    re.compile(r"^Makefile$"),
    re.compile(r"^tsconfig.*\.json$"),
    re.compile(r"^webpack\.config\.(js|ts)$"),
    re.compile(r"^vite\.config\.(js|ts)$"),
    re.compile(r"^next\.config\.(js|ts|mjs)$"),
    re.compile(r"^\.github/workflows/.*\.ya?ml$"),
    re.compile(r"^Procfile$"),
    re.compile(r"^vercel\.json$"),
    re.compile(r"^netlify\.toml$"),
]

CONFIG_ENV_PATTERNS = [
    re.compile(r"^\.env\.example$"),
    re.compile(r"^\.env\.sample$"),
    re.compile(r"^config\.(py|js|ts|go|yaml|yml|toml)$"),
    re.compile(r"^settings\.(py|js|ts|yaml|yml)$"),
]

SCHEMA_MODEL_PATTERNS = [
    re.compile(r"models?\.(py|js|ts|go|rs|java|rb)$"),
    re.compile(r"schema\.(py|js|ts|graphql|gql|prisma)$"),
    re.compile(r"types?\.(py|ts|go)$"),
    re.compile(r"\.graphql$"),
    re.compile(r"\.prisma$"),
    re.compile(r"\.proto$"),
]

API_ROUTE_PATTERNS = [
    re.compile(r"routes?\.(py|js|ts|go|rb)$"),
    re.compile(r"router\.(py|js|ts|go)$"),
    re.compile(r"controllers?/.*\.(py|js|ts|go|java|rb)$"),
    re.compile(r"handlers?\.(py|js|ts|go)$"),
    re.compile(r"endpoints?\.(py|js|ts)$"),
    re.compile(r"views?\.(py|rb)$"),
    re.compile(r"api/.*\.(py|js|ts|go)$"),
]

TEST_PATTERNS = [
    re.compile(r"test_.*\.(py|js|ts|go|java|rb)$"),
    re.compile(r".*_test\.(py|go|rs)$"),
    re.compile(r".*\.test\.(js|ts|tsx|jsx)$"),
    re.compile(r".*\.spec\.(js|ts|tsx|jsx)$"),
    re.compile(r"^tests?/"),
    re.compile(r"^__tests__/"),
    re.compile(r"^spec/"),
]

GENERATED_PATTERNS = [
    re.compile(r"^generated/"),
    re.compile(r"^gen/"),
    re.compile(r"\.gen\.(go|ts|js)$"),
    re.compile(r"\.pb\.(go|py|js)$"),
    re.compile(r"\.generated\.(ts|js)$"),
    re.compile(r"\.min\.(js|css)$"),
    re.compile(r"^migrations?/"),
]


def _matches_any(path: str, patterns: list) -> bool:
    """Check if path matches any of the given patterns."""
    return any(p.search(path) for p in patterns)


# ── Phase 1: Enumerate ──────────────────────────────────────────────

def enumerate_source_files(repo_path: Path, max_files: int = 10_000) -> List[FileInfo]:
    """Walk the repo and collect all source file metadata."""
    files: List[FileInfo] = []
    repo_str = str(repo_path)

    for dirpath, dirnames, filenames in os.walk(repo_path, followlinks=False):
        # Prune ignored directories in-place
        dirnames[:] = [
            d for d in dirnames
            if d not in IGNORED_DIRS and not d.endswith(".egg-info")
        ]

        for filename in filenames:
            if len(files) >= max_files:
                logger.warning(f"Reached max file limit ({max_files}), stopping enumeration")
                return files

            abs_path = Path(dirpath) / filename
            rel_path = str(abs_path.relative_to(repo_path))
            ext = abs_path.suffix.lower()

            # Skip binary and lock files
            if ext in BINARY_EXTENSIONS or filename in LOCK_FILES:
                continue

            try:
                size = abs_path.stat().st_size
            except OSError:
                continue

            # Skip empty files and very large files (>500KB likely not source)
            if size == 0 or size > 500_000:
                continue

            depth = rel_path.count(os.sep)
            language = LANGUAGE_EXTENSIONS.get(ext, "")

            files.append(FileInfo(
                rel_path=rel_path,
                abs_path=abs_path,
                size_bytes=size,
                extension=ext,
                depth=depth,
                language=language,
            ))

    return files


# ── Phase 2: Classify ───────────────────────────────────────────────

def classify_files(files: List[FileInfo]) -> None:
    """Assign a category to each file based on its path and name."""
    for f in files:
        path = f.rel_path
        filename = os.path.basename(path)

        if filename.lower() in ("readme.md", "readme.rst", "readme.txt", "readme"):
            f.category = "readme"
        elif _matches_any(filename, ENTRY_POINT_PATTERNS):
            f.category = "entry_point"
        elif _matches_any(filename, CONFIG_ROOT_PATTERNS):
            f.category = "config_root"
        elif _matches_any(path, GENERATED_PATTERNS):
            f.category = "generated"
        elif _matches_any(path, TEST_PATTERNS):
            f.category = "test"
        elif _matches_any(path, CONFIG_BUILD_PATTERNS):
            f.category = "config_build"
        elif _matches_any(path, CONFIG_ENV_PATTERNS):
            f.category = "config_env"
        elif _matches_any(path, SCHEMA_MODEL_PATTERNS):
            f.category = "schema_model"
        elif _matches_any(path, API_ROUTE_PATTERNS):
            f.category = "api_route"
        elif f.extension in (".d.ts",) or filename.startswith("types"):
            f.category = "type_def"
        elif f.extension in (".md", ".rst", ".txt") and f.depth > 0:
            f.category = "docs"
        elif f.extension in (".css", ".scss", ".less", ".sass"):
            f.category = "asset"
        elif any(d in f.rel_path.split(os.sep) for d in
                 ("services", "service", "lib", "core", "internal", "pkg", "src")):
            f.category = "core_logic"
        elif f.language:
            f.category = "source"
        else:
            f.category = "asset"


# ── Phase 3: Score ──────────────────────────────────────────────────

async def _read_file_head(file_path: Path, num_lines: int = 50) -> str:
    """Read the first N lines of a file for import scanning."""
    try:
        content = await read_file_async(file_path, max_size=3000)
        if content:
            lines = content.split('\n')[:num_lines]
            return '\n'.join(lines)
    except Exception:
        pass
    return ""


def _extract_imports(content: str, language: str) -> List[str]:
    """Extract import paths from file content."""
    patterns = IMPORT_PATTERNS.get(language, [])
    imports = []
    for pattern in patterns:
        for match in pattern.finditer(content):
            # Get the first non-None group
            for g in match.groups():
                if g:
                    imports.append(g)
                    break
    return imports


async def build_import_graph(files: List[FileInfo], scan_limit: int = 200) -> Dict[str, int]:
    """Build lightweight import graph — count how many files import each file."""
    # Only scan top-scored files (by category weight)
    source_files = [f for f in files if f.language and f.category != "test"]
    source_files.sort(key=lambda f: CATEGORY_WEIGHTS.get(f.category, 0), reverse=True)
    to_scan = source_files[:scan_limit]

    # Build path lookup for resolving imports
    path_lookup: Dict[str, str] = {}
    for f in files:
        # Map module-style paths: "src/utils/helper.py" -> "src.utils.helper", "src/utils/helper"
        stem = f.rel_path.rsplit('.', 1)[0] if '.' in f.rel_path else f.rel_path
        path_lookup[stem] = f.rel_path
        path_lookup[stem.replace(os.sep, '.')] = f.rel_path
        path_lookup[stem.replace(os.sep, '/')] = f.rel_path
        # Also just the filename stem
        basename = os.path.basename(stem)
        if basename not in path_lookup:
            path_lookup[basename] = f.rel_path

    imported_by: Dict[str, int] = {}

    # Read heads concurrently
    tasks = [(f, _read_file_head(f.abs_path)) for f in to_scan]
    results = await asyncio.gather(*[t[1] for t in tasks], return_exceptions=True)

    for (f, _), result in zip(tasks, results):
        if isinstance(result, Exception) or not result:
            continue

        imports = _extract_imports(result, f.language)
        for imp in imports:
            # Try to resolve import to a file in the repo
            resolved = path_lookup.get(imp) or path_lookup.get(imp.replace('.', os.sep))
            if resolved and resolved != f.rel_path:
                imported_by[resolved] = imported_by.get(resolved, 0) + 1

    return imported_by


def _size_score(size_bytes: int) -> float:
    """Score based on file size — moderate files score highest."""
    est_lines = size_bytes / 40
    if est_lines < 20:
        return 1.0
    elif est_lines < 50:
        return 3.0
    elif est_lines < 150:
        return 6.0
    elif est_lines < 500:
        return 8.0
    elif est_lines < 1000:
        return 5.0
    else:
        return 3.0


async def score_files(files: List[FileInfo], scan_limit: int = 200) -> None:
    """Assign priority scores to all files."""
    # Build import graph
    imported_by = await build_import_graph(files, scan_limit)

    # Find max import count for normalization
    max_imports = max(imported_by.values()) if imported_by else 1

    for f in files:
        cat_weight = CATEGORY_WEIGHTS.get(f.category, 0)
        centrality = (imported_by.get(f.rel_path, 0) / max_imports) * 10
        size_sig = _size_score(f.size_bytes)
        depth_bonus = max(0.0, 10.0 - f.depth * 2.0)

        f.imported_by_count = imported_by.get(f.rel_path, 0)
        f.priority_score = (cat_weight * 4) + (centrality * 3) + (size_sig * 2) + (depth_bonus * 1)


# ── Phase 4: Budget & Select ────────────────────────────────────────

def detect_repo_size(files: List[FileInfo]) -> str:
    """Detect repo size from actual file count."""
    source_count = sum(1 for f in files if f.language)
    if source_count < 50:
        return "small"
    elif source_count < 500:
        return "medium"
    elif source_count < 2000:
        return "large"
    else:
        return "massive"


def select_files_within_budget(
    files: List[FileInfo],
    repo_size: str,
    char_budget: int = 90_000,
) -> List[FileInfo]:
    """Select the most important files within the character budget."""

    limits = {
        "small":   (40, 4000),
        "medium":  (25, 3500),
        "large":   (15, 3000),
        "massive": (10, 2500),
    }
    max_files, max_chars_per_file = limits.get(repo_size, (25, 3500))

    # Sort by priority score
    ranked = sorted(files, key=lambda f: f.priority_score, reverse=True)

    selected: List[FileInfo] = []
    selected_paths: Set[str] = set()
    total_chars = 0

    # Phase 1: Ensure mandatory coverage (entry_point, config_root, readme)
    for mandatory_cat in ("readme", "config_root", "entry_point"):
        for f in ranked:
            if f.category == mandatory_cat and f.rel_path not in selected_paths:
                est_chars = min(f.size_bytes, max_chars_per_file)
                if total_chars + est_chars <= char_budget:
                    selected.append(f)
                    selected_paths.add(f.rel_path)
                    total_chars += est_chars
                break

    # Phase 2: For large repos, ensure breadth (1 file per top-level dir)
    if repo_size in ("large", "massive"):
        top_dirs: Dict[str, FileInfo] = {}
        for f in ranked:
            top_dir = f.rel_path.split(os.sep)[0] if os.sep in f.rel_path else "__root__"
            if top_dir not in top_dirs and f.rel_path not in selected_paths:
                if f.category not in ("test", "generated", "asset"):
                    top_dirs[top_dir] = f

        for f in top_dirs.values():
            if len(selected) >= max_files:
                break
            est_chars = min(f.size_bytes, max_chars_per_file)
            if total_chars + est_chars <= char_budget:
                selected.append(f)
                selected_paths.add(f.rel_path)
                total_chars += est_chars

    # Phase 3: Fill remaining slots from ranked list
    for f in ranked:
        if len(selected) >= max_files:
            break
        if f.rel_path in selected_paths:
            continue
        est_chars = min(f.size_bytes, max_chars_per_file)
        if total_chars + est_chars > char_budget:
            continue
        selected.append(f)
        selected_paths.add(f.rel_path)
        total_chars += est_chars

    # Sort final selection by path for readable output
    selected.sort(key=lambda f: f.rel_path)
    return selected


# ── Phase 5: Read & Truncate ────────────────────────────────────────

async def read_selected_files(
    files: List[FileInfo],
    max_chars_per_file: int = 4000,
) -> Dict[str, str]:
    """Read selected files with smart head+tail truncation."""
    tasks = []
    for f in files:
        # Read full file (up to a generous limit), we'll truncate after
        tasks.append((f, read_file_async(f.abs_path, max_size=max_chars_per_file + 1000)))

    results = await asyncio.gather(*[t[1] for t in tasks], return_exceptions=True)

    contents: Dict[str, str] = {}
    for (f, _), result in zip(tasks, results):
        if isinstance(result, Exception) or not result:
            continue

        if len(result) <= max_chars_per_file:
            contents[f.rel_path] = result
        else:
            # Smart truncation: 70% head + 15% tail
            head_size = int(max_chars_per_file * 0.70)
            tail_size = int(max_chars_per_file * 0.15)
            head = result[:head_size]
            tail = result[-tail_size:] if tail_size > 0 else ""

            total_lines = result.count('\n') + 1
            contents[f.rel_path] = (
                f"{head}\n\n"
                f"... [truncated: {total_lines} total lines] ...\n\n"
                f"{tail}"
            )

    return contents


# ── Orchestrator ────────────────────────────────────────────────────

async def discover_repository_files(
    repo_path: Path,
    char_budget: int = 90_000,
    scan_limit: int = 200,
) -> Tuple[Dict[str, str], Dict]:
    """Run the full 5-phase discovery pipeline.

    Returns:
        (file_contents, metadata) where metadata includes repo stats.
    """
    # Phase 1: Enumerate
    all_files = await asyncio.to_thread(enumerate_source_files, repo_path)
    logger.info(f"Phase 1: Enumerated {len(all_files)} files")

    if not all_files:
        return {}, {"total_files": 0, "repo_size": "small", "languages": {}}

    # Phase 2: Classify
    classify_files(all_files)
    logger.info("Phase 2: Classified all files")

    # Detect languages
    lang_counts: Dict[str, int] = {}
    for f in all_files:
        if f.language:
            lang_counts[f.language] = lang_counts.get(f.language, 0) + 1
    primary_languages = sorted(lang_counts.items(), key=lambda x: x[1], reverse=True)

    # Detect repo size
    repo_size = detect_repo_size(all_files)
    logger.info(f"Repo size: {repo_size} ({len(all_files)} files)")

    # Phase 3: Score
    await score_files(all_files, scan_limit)
    logger.info("Phase 3: Scored all files")

    # Phase 4: Select
    limits = {"small": 4000, "medium": 3500, "large": 3000, "massive": 2500}
    max_chars = limits.get(repo_size, 3500)
    selected = select_files_within_budget(all_files, repo_size, char_budget)
    logger.info(f"Phase 4: Selected {len(selected)} files (budget: {char_budget} chars)")

    # Phase 5: Read
    contents = await read_selected_files(selected, max_chars)
    logger.info(f"Phase 5: Read {len(contents)} files")

    # Build metadata
    category_counts: Dict[str, int] = {}
    for f in all_files:
        category_counts[f.category] = category_counts.get(f.category, 0) + 1

    metadata = {
        "total_files": len(all_files),
        "files_analyzed": len(contents),
        "repo_size": repo_size,
        "languages": dict(primary_languages[:5]),
        "category_breakdown": category_counts,
        "selected_files": [
            {"path": f.rel_path, "category": f.category, "score": round(f.priority_score, 1)}
            for f in selected
        ],
    }

    return contents, metadata
