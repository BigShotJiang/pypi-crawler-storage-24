"""Async utility functions following MCP best practices."""

import asyncio
import aiofiles
from pathlib import Path
from typing import List, Optional
import logging

logger = logging.getLogger(__name__)


async def run_subprocess_async(cmd: List[str], timeout: float = 30.0) -> tuple[str, str, int]:
    """Run subprocess asynchronously without blocking event loop."""
    try:
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )

        stdout, stderr = await asyncio.wait_for(
            process.communicate(),
            timeout=timeout
        )

        return stdout.decode(), stderr.decode(), process.returncode
    except asyncio.TimeoutError:
        logger.error(f"Subprocess timeout after {timeout}s: {' '.join(cmd)}")
        return "", f"Timeout after {timeout}s", -1
    except Exception as e:
        logger.error(f"Subprocess error: {e}")
        return "", str(e), -1


async def read_file_async(file_path: Path, max_size: int = 5000) -> Optional[str]:
    """Read file asynchronously with size limit."""
    try:
        if not file_path.exists() or not file_path.is_file():
            return None

        async with aiofiles.open(file_path, 'r', encoding='utf-8') as f:
            content = await f.read()

        if len(content) > max_size:
            content = content[:max_size] + "... (truncated)"

        return content
    except Exception as e:
        logger.error(f"Error reading file {file_path}: {e}")
        return f"Error reading file: {str(e)}"


async def write_file_async(file_path: Path, content: str) -> bool:
    """Write file asynchronously."""
    try:
        file_path.parent.mkdir(parents=True, exist_ok=True)

        async with aiofiles.open(file_path, 'w', encoding='utf-8') as f:
            await f.write(content)

        return True
    except Exception as e:
        logger.error(f"Error writing file {file_path}: {e}")
        return False


async def get_directory_structure_async(repo_path: Path, max_lines: int = 500, timeout: float = 10.0) -> str:
    """Get directory structure asynchronously, truncated for large repos."""
    try:
        stdout, stderr, returncode = await run_subprocess_async(
            ["tree", "-a", "-I", ".git|node_modules|__pycache__|.venv|venv|.tox|dist|build",
             "--filelimit", "50", "-L", "4", str(repo_path)],
            timeout=timeout
        )

        if returncode == 0 and stdout:
            lines = stdout.split('\n')
            if len(lines) > max_lines:
                return '\n'.join(lines[:max_lines]) + f"\n\n... (truncated, {len(lines)} total lines)"
            return stdout

    except Exception:
        pass

    # Fallback to find
    try:
        stdout, stderr, returncode = await run_subprocess_async(
            ["find", str(repo_path), "-type", "f", "-not", "-path", "*/.*",
             "-not", "-path", "*/node_modules/*", "-not", "-path", "*/__pycache__/*"],
            timeout=timeout
        )

        if returncode == 0:
            lines = stdout.split('\n')
            if len(lines) > max_lines:
                return '\n'.join(lines[:max_lines]) + f"\n\n... (truncated, {len(lines)} total files)"
            return stdout

    except Exception:
        pass

    return f"Could not generate directory structure for {repo_path}"


async def clone_repository_async(repo_url: str, target_path: Path, timeout: float = 60.0) -> tuple[bool, str]:
    """Clone repository asynchronously. Reuses existing clone if present."""
    try:
        if target_path.exists():
            git_dir = target_path / ".git"
            if git_dir.exists():
                logger.info(f"Repository already exists at {target_path}, pulling latest changes")
                stdout, stderr, returncode = await run_subprocess_async(
                    ["git", "-C", str(target_path), "pull", "--ff-only"],
                    timeout=timeout
                )
                if returncode == 0:
                    return True, "Repository already existed, pulled latest changes"
                else:
                    logger.warning(f"Pull failed ({stderr}), continuing with existing clone")
                    return True, "Repository already existed (pull failed, using existing)"
            else:
                return False, (
                    f"Target path {target_path} already exists and is not a git repository. "
                    "Remove it manually to re-clone."
                )

        # Shallow clone for faster analysis
        stdout, stderr, returncode = await run_subprocess_async(
            ["git", "clone", "--depth", "1", repo_url, str(target_path)],
            timeout=timeout
        )

        if returncode == 0:
            return True, "Repository cloned successfully"
        else:
            return False, f"Git clone failed: {stderr}"

    except Exception as e:
        logger.error(f"Error cloning repository: {e}")
        return False, str(e)
