# Repository Size Intelligence Guide

This is a shared reference for all CodeGlance prompts on how to intelligently handle repositories of different sizes.

## Automatic Repository Size Detection

Before beginning any analysis, use these methods to assess repository scale:

### File Count Detection
```bash
# Count source code files (excluding common non-source files)
find . -type f \( \
  -name "*.js" -o -name "*.ts" -o -name "*.jsx" -o -name "*.tsx" \
  -o -name "*.py" -o -name "*.java" -o -name "*.go" -o -name "*.rs" \
  -o -name "*.php" -o -name "*.rb" -o -name "*.cpp" -o -name "*.c" \
  -o -name "*.cs" -o -name "*.kt" -o -name "*.scala" -o -name "*.swift" \
\) -not -path "*/node_modules/*" -not -path "*/vendor/*" \
  -not -path "*/build/*" -not -path "*/dist/*" | wc -l
```

### Directory Count Detection  
```bash
# Count directories (excluding common build/dependency dirs)
find . -type d -not -path "*/node_modules/*" -not -path "*/vendor/*" \
  -not -path "*/build/*" -not -path "*/dist/*" -not -path "*/.git/*" | wc -l
```

### Monorepo Detection
Look for these indicators:
- Multiple `package.json` files
- Workspace configuration (`workspaces` field in root package.json)
- Multiple top-level directories with their own build configs
- `lerna.json`, `nx.json`, or similar monorepo tools
- Multiple `Cargo.toml`, `pom.xml`, or other project files

## Repository Size Categories

### Small Repository
- **File Count**: < 50 source files
- **Directory Count**: < 10 directories  
- **Characteristics**: Single application, simple structure
- **Analysis Approach**: Comprehensive analysis of all important files

### Medium Repository  
- **File Count**: 50-500 source files
- **Directory Count**: 10-50 directories
- **Characteristics**: Well-structured single application or small multi-module project
- **Analysis Approach**: Strategic sampling with focus on key components

### Large Repository
- **File Count**: 500-2000 source files  
- **Directory Count**: 50-200 directories
- **Characteristics**: Complex application, multiple modules, or small monorepo
- **Analysis Approach**: Architectural focus with representative file sampling

### Massive Repository
- **File Count**: 2000+ source files
- **Directory Count**: 200+ directories
- **Characteristics**: Large monorepo, microservices architecture, or enterprise codebase
- **Analysis Approach**: High-level architectural analysis with workspace-level understanding

## Analysis Strategy Matrix

| Component | Small | Medium | Large | Massive |
|-----------|-------|---------|-------|---------|
| **Overview** | Comprehensive | Comprehensive | Comprehensive | Comprehensive |
| **Visual Tree** | Full Detail | Full with Collapsing | Full with Heavy Collapsing | Full with Extensive Sectioning |
| **File Insights** | 15-20 files | 10-15 files | 6-10 files | 4-6 files |
| **Architecture** | Detailed | Pattern Focus | High-level | Component Boundaries |
| **Quick Start** | Complete | Complete | Simplified | Workspace-aware |

## Intelligent File Selection Algorithm

### Priority Scoring System

**Priority Score = (Importance × 4) + (Centrality × 3) + (Complexity × 2) + (Activity × 1)**

#### Importance Score (0-10)
- **10**: Main entry points (main.js, app.py, index.ts)
- **9**: Root configuration (package.json, Cargo.toml, pom.xml)
- **8**: Primary business logic (core services, main controllers)
- **7**: Database schemas/models
- **6**: API endpoints/route definitions
- **5**: Key components/modules
- **4**: Configuration files
- **3**: Utility functions
- **2**: Test files
- **1**: Documentation, assets

#### Centrality Score (0-10)
Based on import/dependency relationships:
- **10**: Imported by 20+ files
- **8**: Imported by 10-19 files
- **6**: Imported by 5-9 files
- **4**: Imported by 2-4 files
- **2**: Imported by 1 file
- **0**: Not imported by other files

#### Complexity Score (0-10)
Based on file size and structure:
- **10**: 500+ lines with complex logic
- **8**: 300-499 lines
- **6**: 150-299 lines
- **4**: 50-149 lines
- **2**: 20-49 lines
- **0**: <20 lines

#### Activity Score (0-10)
Based on recent modification frequency:
- **10**: Modified in last week
- **8**: Modified in last month
- **6**: Modified in last 3 months
- **4**: Modified in last 6 months
- **2**: Modified in last year
- **0**: Older than 1 year

### File Selection by Repository Size

**Small Repositories**: Select top 20 files by priority score

**Medium Repositories**: Select top 15 files, ensuring representation across major directories

**Large Repositories**: Select top 10 files, with at least one from each major component/workspace

**Massive Repositories**: Select top 6 files, focusing on entry points and architectural boundary files

## Adaptive Detail Levels

### Documentation Depth Guidelines

**Small Repositories**:
- **File Analysis**: Detailed function-by-function analysis
- **Examples**: Multiple usage examples per file
- **Connections**: Complete dependency mapping
- **Visual Elements**: Detailed diagrams and flows

**Medium Repositories**:
- **File Analysis**: Focus on key functions and patterns
- **Examples**: Primary usage patterns
- **Connections**: Major dependency relationships
- **Visual Elements**: High-level architectural diagrams

**Large Repositories**:
- **File Analysis**: Architectural role and key interfaces
- **Examples**: Representative usage only
- **Connections**: Component-level relationships
- **Visual Elements**: System-level architecture diagrams

**Massive Repositories**:
- **File Analysis**: Purpose and position in larger system
- **Examples**: Minimal, pattern-focused examples
- **Connections**: Workspace/service boundaries
- **Visual Elements**: High-level system architecture

## Quality Assurance by Size

### Small Repository Quality Checks
- ✅ Every important file analyzed in detail
- ✅ Complete usage examples provided
- ✅ Full directory tree visible
- ✅ All major features documented

### Medium Repository Quality Checks  
- ✅ Representative files from each major component
- ✅ Key architectural patterns explained
- ✅ Important directories expanded in tree
- ✅ Main workflows documented

### Large Repository Quality Checks
- ✅ Architectural overview clearly explains system structure
- ✅ Component boundaries well-defined
- ✅ Navigation guidance provided for further exploration
- ✅ Complete tree available through collapsible sections

### Massive Repository Quality Checks
- ✅ System scope and boundaries clearly explained
- ✅ Workspace/package organization documented
- ✅ High-level data flows mapped
- ✅ "Exploration roadmap" provided for deep diving

## Implementation Notes

### For All Prompts
- Always detect repository size first before beginning analysis
- Explicitly state the detected size and chosen strategy
- Adapt analysis depth while maintaining quality standards
- Provide clear navigation paths regardless of size

### Error Conditions
- If file counting fails, default to "Large" repository assumptions
- If structure is unclear, default to more comprehensive analysis
- Always err on the side of providing more information rather than less

### User Communication
- Be transparent about analysis choices made due to repository size
- Provide clear guidance on where to find more detailed information
- Explain the trade-offs made in analysis depth
- Offer pathways for deeper exploration