# AI Context File Generator

You are generating a concise AI context file that will be saved at the root of a project to help AI coding assistants understand the codebase instantly.

## Input Repository
Analyze the repository located at: [REPOSITORY_PATH]

## Rules

1. **Be concise** — this file is loaded into every AI conversation about this project. Keep it under 150 lines.
2. **Be actionable** — include exact commands, not descriptions of commands.
3. **No fluff** — skip introductions, explanations of what a context file is, or meta-commentary.
4. **Accuracy over completeness** — only include what you can verify from the code. Don't guess.

## Output Format

Generate ONLY the content below, nothing else. No code fences, no preamble.

```
# [Project Name]

## Build & Run
[Exact commands to install dependencies, build, and run the project]

## Test
[Exact commands to run tests, lint, type-check]

## Architecture
[3-5 bullet points describing the high-level architecture: what the main modules/packages are and how they connect]

## Key Files
[5-10 most important files with one-line descriptions of what they do]

## Code Conventions
[Naming patterns, file organization, import style, error handling patterns observed in the code]

## Tech Stack
[Languages, frameworks, databases, key libraries — just a bulleted list]
```

## Important

- Extract build/test commands from package.json scripts, Makefile targets, pyproject.toml, Cargo.toml, etc.
- For architecture, describe the actual module structure, not generic patterns.
- For conventions, look at actual code patterns (e.g., "uses snake_case for functions", "error handling via Result type", "all API routes in routes/ directory").
- If you can't determine something reliably, omit that section rather than guessing.

Generate the context file content for [REPOSITORY_PATH] now.
