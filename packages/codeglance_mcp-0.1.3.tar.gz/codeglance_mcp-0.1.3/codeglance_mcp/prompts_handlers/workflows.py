"""MCP Prompts for guided analysis workflows."""

from typing import List, Dict, Any
import logging
from mcp.types import Prompt, PromptArgument

logger = logging.getLogger(__name__)


class AnalysisWorkflows:
    """Guided workflows for repository analysis."""

    @staticmethod
    def get_available_prompts() -> List[Prompt]:
        """Get all available analysis workflow prompts."""
        return [
            Prompt(
                name="comprehensive_analysis",
                description="Complete repository analysis workflow with all documentation types",
                arguments=[
                    PromptArgument(name="repo_url", description="GitHub repository URL to analyze", required=True),
                    PromptArgument(name="working_directory", description="Directory where to create repos and guide folders", required=False),
                ]
            ),
            Prompt(
                name="quick_overview",
                description="Fast repository overview for quick understanding",
                arguments=[
                    PromptArgument(name="repo_url", description="GitHub repository URL to analyze", required=True),
                    PromptArgument(name="working_directory", description="Directory where to create repos and guide folders", required=False),
                ]
            ),
            Prompt(
                name="architecture_review",
                description="Architecture-focused analysis for system design understanding",
                arguments=[
                    PromptArgument(name="repo_url", description="GitHub repository URL to analyze", required=True),
                    PromptArgument(name="working_directory", description="Directory where to create repos and guide folders", required=False),
                ]
            ),
            Prompt(
                name="security_audit",
                description="Security-focused repository review",
                arguments=[
                    PromptArgument(name="repo_url", description="GitHub repository URL to analyze", required=True),
                    PromptArgument(name="working_directory", description="Directory where to create repos and guide folders", required=False),
                ]
            ),
        ]

    @staticmethod
    async def handle_comprehensive_analysis(arguments: Dict[str, Any]) -> str:
        repo_url = arguments.get("repo_url")
        working_directory = arguments.get("working_directory", ".")
        if not repo_url:
            return "Error: repo_url is required for comprehensive analysis"

        return f"""# Comprehensive Repository Analysis Workflow

I'll perform a complete analysis of the repository: {repo_url}

## Steps:

1. **Clone Repository** - Clone {repo_url} into the analysis directory
2. **Generate Documentation** - Project overview, directory tree, file insights, architecture, quick start, master analysis
3. **Create Index** - Navigation guide linking all documentation

## To proceed:
Use the `analyze_repository` tool with:
- repo_url: {repo_url}
- working_directory: {working_directory}"""

    @staticmethod
    async def handle_quick_overview(arguments: Dict[str, Any]) -> str:
        repo_url = arguments.get("repo_url")
        working_directory = arguments.get("working_directory", ".")
        if not repo_url:
            return "Error: repo_url is required for quick overview"

        return f"""# Quick Repository Overview

Fast overview of: {repo_url}

## To proceed:
1. Use `analyze_repository` tool with repo_url: {repo_url}
2. Focus on `01-overview.md` and `02-tree.md`

Output saved in {working_directory}/codeglance-analysis/guide/"""

    @staticmethod
    async def handle_architecture_review(arguments: Dict[str, Any]) -> str:
        repo_url = arguments.get("repo_url")
        working_directory = arguments.get("working_directory", ".")
        if not repo_url:
            return "Error: repo_url is required for architecture review"

        return f"""# Architecture Review

Architecture-focused analysis of: {repo_url}

## To proceed:
Use `analyze_repository` with repo_url: {repo_url}
Focus on `04-architecture.md` for system design insights."""

    @staticmethod
    async def handle_security_audit(arguments: Dict[str, Any]) -> str:
        repo_url = arguments.get("repo_url")
        working_directory = arguments.get("working_directory", ".")
        if not repo_url:
            return "Error: repo_url is required for security audit"

        return f"""# Security Audit

Security-focused review of: {repo_url}

This analysis focuses on defensive security patterns and best practices.

## To proceed:
Use `analyze_repository` with repo_url: {repo_url}
Review all generated docs with a security lens."""


workflow_handler = AnalysisWorkflows()
