# PhaseDB v2

**PhaseDB v2** is a **standalone, pure-Python database system** with tables, auto-increment IDs, CRUD operations, and JSON persistence.  
It allows you to work with databases **without SQLite or any external dependency**. Optional ORM-style models let you define tables as Python classes.

---

## 📦 Installation

### 1. Local installation

If you have the PhaseDB folder locally:

```bash
pip install .
```

### 2. PyPI (after uploading)

```bash
pip install phasedb
```

---

## ⚡ Usage

### Import and connect

```python
import phasedb

# Create or load a database file
db = phasedb.PhaseDB("mydb.pdb")
```

---

### Create a table

```python
db.create_table("users")
```

---

### Insert data

```python
db.insert("users", {"name":"Alice","coins":100})
db.insert("users", {"name":"Bob","coins":200})
```

---

### Select data

```python
all_users = db.select("users")
rich_users = db.select("users", condition=lambda r: r["coins"] > 150)

print(all_users)
print(rich_users)
```

---

### Update data

```python
db.update("users", {"coins":999}, condition=lambda r: r["name"]=="Alice")
```

---

### Delete data

```python
db.delete("users", condition=lambda r: r["name"]=="Bob")
```

---

## 🧱 Using Models (ORM-style)

```python
from phasedb.models import BaseModel

class User(BaseModel):
    table_name = "users"
    columns = ["name", "coins", "level"]

user_model = User(db)

# Insert using model
user_model.insert(name="Charlie", coins=500, level=1)

# Select using model
print(user_model.select())

# Update
user_model.update({"coins":600}, condition=lambda r: r["name"]=="Charlie")

# Delete
user_model.delete(condition=lambda r: r["name"]=="Charlie")
```

---

## 🔹 Features

* Fully **standalone** (no SQLite)
* **Tables with auto-increment IDs**
* Pythonic CRUD: `insert`, `select`, `update`, `delete`
* **JSON persistence** for saving/loading data
* Optional ORM-style models for cleaner table management
* Simple, readable Python API

---

## 🔧 Requirements

* Python 3.8+
* No external dependencies

---

## 📌 License

MIT License
