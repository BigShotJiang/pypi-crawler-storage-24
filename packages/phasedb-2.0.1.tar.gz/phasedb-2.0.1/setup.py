from setuptools import setup, find_packages

setup(
    name="phasedb",                     
    version="2.0.1",                     
    author="PhaseDev",                   
    author_email="PhaseDB@protonmail.com",
    description="Standalone Python database with tables, CRUD, and JSON persistence",
    long_description=open("README.md", "r", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/phasedb",  # Optional, replace if you have a repo
    packages=find_packages(),            
    python_requires=">=3.8",
    install_requires=[],                 
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Intended Audience :: Developers",
    ],
)