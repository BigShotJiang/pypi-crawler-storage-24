# phasedb/__init__.py

"""
PhaseDB v2
A standalone, pure-Python database system with tables, auto-increment IDs, CRUD, and JSON persistence.
"""

import json
import os

class PhaseDB:
    def __init__(self, filename="phasedb.pdb"):
        self.filename = filename
        self.tables = {}
        if os.path.exists(self.filename):
            self.load()

    # ---------- CRUD ----------
    def create_table(self, table_name):
        """Create a new table if it doesn't exist"""
        if table_name not in self.tables:
            self.tables[table_name] = {"last_id": 0, "rows": {}}
            self.save()

    def insert(self, table_name, row):
        """Insert a row into a table"""
        table = self.tables.get(table_name)
        if table is None:
            raise Exception(f"Table '{table_name}' does not exist")
        table["last_id"] += 1
        row_id = table["last_id"]
        table["rows"][row_id] = row
        self.save()
        return row_id

    def select(self, table_name, condition=lambda row: True):
        """Select rows from a table that match a condition"""
        table = self.tables.get(table_name)
        if table is None:
            raise Exception(f"Table '{table_name}' does not exist")
        return {k: v for k, v in table["rows"].items() if condition(v)}

    def update(self, table_name, updates, condition=lambda row: True):
        """Update rows in a table that match a condition"""
        table = self.tables.get(table_name)
        if table is None:
            raise Exception(f"Table '{table_name}' does not exist")
        count = 0
        for row in table["rows"].values():
            if condition(row):
                row.update(updates)
                count += 1
        self.save()
        return count

    def delete(self, table_name, condition=lambda row: True):
        """Delete rows from a table that match a condition"""
        table = self.tables.get(table_name)
        if table is None:
            raise Exception(f"Table '{table_name}' does not exist")
        keys_to_delete = [k for k, v in table["rows"].items() if condition(v)]
        for k in keys_to_delete:
            del table["rows"][k]
        self.save()
        return len(keys_to_delete)

    # ---------- Persistence ----------
    def save(self):
        """Save the database to a JSON file"""
        with open(self.filename, "w") as f:
            json.dump(self.tables, f, indent=4)

    def load(self):
        """Load the database from a JSON file"""
        with open(self.filename, "r") as f:
            self.tables = json.load(f)


# Optional: Simple ORM-style base class
class BaseModel:
    """
    Base class for defining table models.
    Usage:
        class User(BaseModel):
            table_name = "users"
            columns = ["name", "coins"]
    """
    table_name = ""
    columns = []

    def __init__(self, db: PhaseDB):
        self.db = db
        if self.table_name and self.columns:
            self.db.create_table(self.table_name)

    def insert(self, **kwargs):
        return self.db.insert(self.table_name, kwargs)

    def select(self, condition=lambda row: True):
        return self.db.select(self.table_name, condition)

    def update(self, updates, condition=lambda row: True):
        return self.db.update(self.table_name, updates, condition)

    def delete(self, condition=lambda row: True):
        return self.db.delete(self.table_name, condition)


# Expose the main API
__all__ = ["PhaseDB", "BaseModel"]