# phasedb/models.py

"""
PhaseDB v2 - ORM-style Models
Allows you to define tables as Python classes with simple CRUD operations.
"""

from .database import PhaseDB

class BaseModel:
    """
    Base class for defining table models.
    Usage:

        class User(BaseModel):
            table_name = "users"
            columns = ["name", "coins"]

        user_model = User(db)
    """

    table_name = ""
    columns = []

    def __init__(self, db: PhaseDB):
        self.db = db
        if self.table_name and self.columns:
            self.db.create_table(self.table_name)

    def insert(self, **kwargs):
        """
        Insert a row.
        kwargs = column_name=value
        """
        # Ensure only defined columns are inserted
        row = {k: v for k, v in kwargs.items() if k in self.columns}
        return self.db.insert(self.table_name, row)

    def select(self, condition=lambda row: True):
        """
        Select rows from the table.
        condition = lambda(row) -> bool
        """
        return self.db.select(self.table_name, condition)

    def update(self, updates, condition=lambda row: True):
        """
        Update rows in the table.
        updates = dict of column:value
        condition = lambda(row) -> bool
        """
        row_updates = {k: v for k, v in updates.items() if k in self.columns}
        return self.db.update(self.table_name, row_updates, condition)

    def delete(self, condition=lambda row: True):
        """
        Delete rows from the table.
        condition = lambda(row) -> bool
        """
        return self.db.delete(self.table_name, condition)