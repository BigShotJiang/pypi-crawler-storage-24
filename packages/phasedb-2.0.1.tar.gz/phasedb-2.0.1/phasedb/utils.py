from phasedb.utils import validate_row, pretty_print_table

columns = ["name", "coins", "level"]
row = {"name":"Alice", "coins":100, "level":5, "extra":"ignored"}

validated = validate_row(columns, row)
print(validated)
# Output: {'name': 'Alice', 'coins': 100, 'level': 5}

table = {
    1: {"name":"Alice","coins":100,"level":5},
    2: {"name":"Bob","coins":200,"level":10}
}

pretty_print_table(table)