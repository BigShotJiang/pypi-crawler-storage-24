"""Simple way to talk to the websocket api of minecraft"""
from .main import *

__author__ = "Spacetrale"
__version__ = "1.0.0"