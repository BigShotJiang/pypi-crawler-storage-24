import asyncio
import inspect

class Commands_manager:
    def __init__(self, server):
        self.server = server
    
    def command(self, name=None, description=None):
        """Decorator for create a command mcws from a coro function.
        
        .. codeblock:: python3
            
            @server.command()
            async def hello_world(ws):
                ws.send("Hello Minecraft World!")
            
        .. note:
            
            Parameters:
                
                name: :class:`str`
                Name for call the command in Minecraft.
                
                description: :class:`str`
                Description to put in the help command.
                
            Raises:
                
                TypeError
                    If the function is not a coroutine function.
        """
        def wrapper(func):
            if asyncio.iscoroutinefunction(func):
                self.server.commands[name or func.__name__] = {
                    "call": func, 
                    "description": description,
                    "params": []
                }
                for param in inspect.signature(func).parameters.values():
                    self.server.commands[name or func.__name__]["params"].append({
                        "name": param.name,
                        "type": param.annotation
                    })
                return func
            else:
                raise TypeError(f"'{func.__name__}' is not a coroutine function")
        return wrapper
    
    def transformer(self, cmd):
        i = 0
        for param in self.server.commands[cmd[0]]["params"][1:]:
            i += 1
            if param["type"] != inspect._empty and param["name"] != "ws":
                cmd[i] = param["type"](cmd[i])
        return cmd
    
    async def classing(self, ws):
        if ws.data["header"].get("eventName") == "PlayerMessage":
            if ws.data["body"]["message"].startswith(self.server.PREFIX):
                cmd = ws.data["body"]["message"].replace(self.server.PREFIX, "").split(" ")
                if not cmd[0] in self.server.commands.keys():
                    print(f"[ERROR] No command named {cmd[0]}")
                    return
                
                # if command dont exist is execute this too ;-;
                cmd = self.transformer(cmd)
                if len(cmd) > 1:
                    await self.server.commands[cmd[0]]["call"](ws, *cmd[1:])
                else:
                    await self.server.commands[cmd[0]]["call"](ws)