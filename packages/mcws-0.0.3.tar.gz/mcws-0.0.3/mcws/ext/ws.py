from typing import Literal
from uuid import uuid4
import asyncio
import json

class Websocket:
    def __init__(self, server, client, data):
        self.server = server
        self.client = client
        self.data = data
    
    @property
    def message(self):
        return self.data["body"].get("message")
    
    @property
    def player(self):
        if "player" in self.data["body"]:
            return self.data["body"]["player"]["name"]
        elif "sender" in self.data["body"]:
            return self.data["body"]["sender"]
    
    @property
    def player_position(self):
        if "player" in self.data["body"]:
            return self.data["body"]["player"]["position"]
    
    @property
    def speed(self):
        return self.data["body"].get("metersTravelled")
    
    @property
    def item(self):
        if "item" in self.data["body"]:
            return self.data["body"]["item"]["id"]
    
    @property
    def block(self):
        if "block" in self.data["body"]:
            return self.data["body"]["block"]["id"]
    
    @property
    def count(self):
        if "item" in self.data["body"]:
            return self.data["body"]["item"]["count"]
    
    @property
    def entity_index(self):
        if "mob" in self.data["body"]:
            return self.data["body"]["mob"]["type"]
    
    def send_command(self, command: str) -> None:
        """Function to send a command to the world.
        
        .. codeblock:: python3
            
            @server.command()
            async def give_dirt(ws):
                ws.send_command(f"/give {ws.player} dirt")
            
        Parameters:
            
            command: :class:`str`
            Command to send.
        """
        self.server.send_queue.append({
            "header": {
                "version": 1,
                "requestId": str(uuid4()),
                "messagePurpose": "commandRequest",
                "messageType": "commandRequest"
            },
            "body": {
                "version": 1,
                "commandLine": command,
                "origin": {
                    "type": "player"
                }
            }
        })
    
    def send(self, text: str) -> None:
        """Function for send message in the chat.
        
        .. codeblock:: python3
            
            @server.command()
            async def talk(ws):
                ws.send(f"Hello {ws.player}")
            
        Parameters:
            
            text: :class:`str`
            Text to send to everyone.
        """
        self.send_command(f"/say {text}")
    
    async def __send(self, command):
        await self.client.send(json.dumps({
            "header": {
                "version": 1,
                "requestId": str(uuid4()),
                "messagePurpose": "commandRequest",
                "messageType": "commandRequest"
            },
            "body": {
                "version": 1,
                "commandLine": command,
                "origin": {
                    "type": "player"
                }
            }
        }))
    
    async def __receive(self):
        async for msg in self.client:
            return Websocket(self.server, self.client, json.loads(msg))
    
    async def get_response_command(self, command: str):
        """Function for send command and receive the response.
        
        .. codeblock:: python3
            
            @server.command()
            async def list_player(ws):
                response = await ws.get_response_command("/list")
                ws.send(f"You are actualy {ws.data['player_count']}")
                ws.send(f"And there is the list of people: {','.join(ws.data['players'])}")
            
        Parameters:
            
            command: :class:`str`
            Command to send to minecraft.
        """
        r = await asyncio.gather(self.__receive(), self.__send(command))
        return r[0]