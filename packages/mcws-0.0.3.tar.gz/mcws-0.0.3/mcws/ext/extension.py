from .commands import Commands_manager
from .events import Events_manager
import importlib

class Extension:
    """Class for create mcws Extension for mcws Server.
    
    .. codeblock:: python3
        
        from mcws.ext import Extension
        
        ext = Extension()
        
        @ext.command()
        async def my_command(ws):
            ws.send("Hello World!")
        
    """
    def __init__(self):
        # extension append
        self.commands_manager = Commands_manager(self)
        self.events_manager = Events_manager(self)
        # extension function append
        self.command = getattr(self.commands_manager, "command")
        self.event = getattr(self.events_manager, "event")
        # variable
        self.commands = {}
        self.events = {}

class Add_Extension_manager:
    def __init__(self, server):
        self.server = server
    
    def add_extension(self, ext):
        for name, func in ext.commands.items():                
            self.server.commands[name] = func
        for event_name, funcs in ext.events.items():
            if event_name not in self.server.events.keys():
                self.server.events[event_name] = []
            for func in funcs:
                self.server.events[event_name].append(func)
    
    def load(self, path):
        """Function for load ext from another file or directories.
        
        .. codeblock:: python3
            
            server.load("my_directory.my_file")
            
        Raises:
            
            TypeError
                When the file don't have setup function.
        """
        spec = importlib.util.find_spec(path)
        lib = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(lib)
        if getattr(lib, "setup", None):
            getattr(lib, "setup")(self.server)
        else:
            raise TypeError(f"'{path}' have no setup function")