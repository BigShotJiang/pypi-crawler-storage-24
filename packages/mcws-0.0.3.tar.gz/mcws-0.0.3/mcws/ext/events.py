from uuid import uuid4
import asyncio
import json

class Events_manager:
    def __init__(self, server):
        self.server = server
    
    async def subscribe(self, client, event_name):
        await client.send(json.dumps({
            "body": {
                "eventName": event_name
            },
            "header": {
                "requestId": str(uuid4()),
                "messagePurpose": "subscribe",
                "version": 1,
                "messageType": "commandRequest"
            }
        }))
    
    def event(self, event_name: str):
        """Decorator for create a mcws event listener from a coro function.
        
        .. codeblock::
            
            @server.event("OnReady")
            async def on_ready():
                print("Hello World!")
            
        .. note:
            
            Parameters:
                
                event_name: :class:`str`
                Event minecraft/mcws to subscribe, watch the documentation of mcws for see the list of events.
                
            Raises:
                
                TypeError
                    The function is not a coroutine function 
        """
        def wrapper(func):
            if asyncio.iscoroutinefunction(func):
                if event_name in self.server.events:
                    self.server.events[event_name].append(func)
                else:
                    self.server.events[event_name] = [func]
                return func
            else:
                raise TypeError(f"'{func.__name__}' is not a coroutine function")
        return wrapper
    
    async def call_events(self, event_name, *args):
        if event_name in self.server.events.keys():
            for event in self.server.events[event_name]:
                if len(args) > 0:
                    await event(*args)
                else:
                    await event()