from .ext import *
import websockets
import asyncio
import json

class Server:
    """Class for create a websocket server for minecraft.
    
    .. codeblock:: python3
        
        import mcws
        
        server = mcws.Server("+")
        
        @server.command()
        async def my_command(ws):
            ws.send("Hello world!")
        
        server.run()
        
    .. note:
        
        Parameters:
            
            prefix: :class:`str`
            Prefix for commands
            
            ip: :class:`str` = "localhost"
            Ip address of the server
            
            port: :class:`int` = 5000
            Port of the server
    """
    def __init__(self, prefix: str, ip: str = "localhost", port: int = 5000):
        # ext class append
        self.__commands_manager = Commands_manager(self)
        self.__events_manager = Events_manager(self)
        self.__add_extension_manager = Add_Extension_manager(self)
        # variable
        self.PREFIX = prefix
        self.ip = ip
        self.port = port
        self.commands = {}
        self.events = {}
        # ext function append
        self.command = getattr(self.__commands_manager, "command")
        self.event = getattr(self.__events_manager, "event")
        self.classing = getattr(self.__commands_manager, "classing")
        self.call_events = getattr(self.__events_manager, "call_events")
        self.subscribe = getattr(self.__events_manager, "subscribe")
        self.add_extension = getattr(self.__add_extension_manager, "add_extension")
        self.load = getattr(self.__add_extension_manager, "load")
        # command protect
        self.send_queue = []
        self.awaited_queue = {}
      
    # Server websockets
    async def __main(self, client):
        # OnConnected events
        await self.call_events("OnConnected")
        
        # subscribe events
        for event in self.events.keys():
            if event != "PlayerMessage":
                await self.subscribe(client, event)
        await self.subscribe(client, "PlayerMessage")
        
        # Websockets server
        async for msg in client:
            msg = json.loads(msg)
            
            # events / commands
            ws = Websocket(self, client, msg)
            await self.call_events("OnResponse", ws)
            await self.call_events(msg["header"].get("eventName"), ws)
            await self.classing(ws)
            
            # command protect
            
            count = 100 - len(self.awaited_queue)
            for command in self.send_queue[:count]:
                await client.send(json.dumps(command))
                self.awaited_queue[command["header"]["requestId"]] = command
            self.send_queue = self.send_queue[count:]
        
        await self.call_events("OnDisconnected")
    
    async def __server(self):
        async with websockets.serve(self.__main, self.ip, self.port):
            await self.call_events("OnReady")
            await asyncio.Future()
    
    def run(self) -> None:
        asyncio.run(self.__server())