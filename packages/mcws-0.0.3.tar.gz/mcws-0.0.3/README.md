# Mcws
## Simple way to talk to the minecraft websocket api

---

# Features

- Simple command system
- Event system
- Extension system
- Converter

---

## Installation

```bash
pip install mcws
```

---

## Quickstart

### Create hello world command

```python
import mcws

server = mcws.Server("+")

@server.command()
async def hello_world(ws):
    ws.send("Hello Minecraft World!")

server.run()
```

### Create diamond giver

```python
import mcws

server = mcws.Server("+")

@server.command()
async def diamond(ws):
    ws.send_command("/give @a diamond")

server.run()
```

---

## Mcws events

### Mcws events

```python
import mcws

server = mcws.Server("+")

@server.event("OnReady")
async def on_ready():
    print(f"Listen ws//{server.ip}:{server.port}")

@server.event("OnConnected")
async def on_connected():
    print("Connected")

@server.event("OnDisconnected")
async def on_disconnected():
    print("Disconnected")

server.run()
```

### Minecraft websocket api events

#### Players message
```python
import mcws

server = mcws.Server("+")

@server.event("PlayerMessage")
async def on_message(ws):
    ws.send(f"Hello {ws.player}")

server.run()
```

#### Block destroyed
```python
import mcws

server = mcws.Server("+")

@server.event("BlockBroken")
async def on_block_destroyed(ws):
    print(f"Nooooooooo poor block of {ws.block}")

server.run()
```

---

## Mcws Extension

### Quickstart

```python
from mcws import Extension
import mcws

server = mcws.Server("+")
ext = Extension()

# extension

@ext.command()
async def my_command(ws):
    ws.send("Hello World!")

# server

server.add_extension(ext)

server.run()
```

### Better separation

#### main.py
```python
import mcws

server = mcws.Server("+")

server.load("extension") # file path not name file

server.run()
```

#### extension.py
```python
from mcws import Extension

ext = Extension()

@ext.command()
async def diamond(ws):
    ws.send_command("/give @a diamond")

def setup(server):
    server.add_extension(ext)
```