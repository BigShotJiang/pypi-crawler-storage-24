"""Tests for StigmergyScheduler — batteries-included pressure-driven scheduling."""

import asyncio

import pytest

from stigmergy import (
    DispatchResult,
    InMemoryFieldBackend,
    ExponentialDecay,
    PheromoneField,
    SchedulerMetrics,
    StigmergyScheduler,
    TaskSpec,
)


@pytest.fixture
def scheduler():
    return StigmergyScheduler(tick_interval=0.05, wake_threshold=0.3)


@pytest.fixture
def field():
    return PheromoneField(
        backend=InMemoryFieldBackend(),
        decay_strategy=ExponentialDecay(half_life_seconds=300.0),
        evaporation_threshold=0.01,
    )


# ── Dataclass basics ────────────────────────────────────────────────


def test_task_spec_defaults():
    t = TaskSpec(id="a", description="do thing", agent_id="bot")
    assert t.priority == 0.5
    assert t.dependencies == []
    assert t.metadata == {}


def test_dispatch_result_defaults():
    r = DispatchResult(success=True)
    assert r.output is None
    assert r.error is None


def test_scheduler_metrics_defaults():
    m = SchedulerMetrics()
    assert m.total_ticks == 0
    assert m.completed_tasks == []


# ── Registration ─────────────────────────────────────────────────────


def test_register_agent(scheduler):
    scheduler.register_agent("writer")
    assert "writer" in scheduler._agents


@pytest.mark.asyncio
async def test_add_task_registers_agent(scheduler):
    task = TaskSpec(id="t1", description="write", agent_id="writer")
    await scheduler.add_task(task)
    assert "writer" in scheduler._agents
    assert "t1" in scheduler._tasks


# ── Single task dispatch ─────────────────────────────────────────────


@pytest.mark.asyncio
async def test_single_task_completes(scheduler):
    results = []

    async def dispatch(agent_id, task):
        results.append((agent_id, task.id))
        return DispatchResult(success=True, output="done")

    scheduler.set_dispatcher(dispatch)
    await scheduler.add_task(
        TaskSpec(id="t1", description="write draft", agent_id="writer", priority=0.8)
    )
    await scheduler.run()

    assert "t1" in results[0]
    assert scheduler.is_complete()
    metrics = scheduler.get_metrics()
    assert metrics.total_completions == 1
    assert metrics.total_failures == 0
    assert "t1" in metrics.completed_tasks


# ── Dependency ordering ──────────────────────────────────────────────


@pytest.mark.asyncio
async def test_dependency_ordering():
    scheduler = StigmergyScheduler(tick_interval=0.05, wake_threshold=0.1)
    order = []

    async def dispatch(agent_id, task):
        order.append(task.id)
        return DispatchResult(success=True)

    scheduler.set_dispatcher(dispatch)
    await scheduler.add_task(
        TaskSpec(id="draft", description="write", agent_id="writer", priority=0.8)
    )
    await scheduler.add_task(
        TaskSpec(
            id="review",
            description="review",
            agent_id="reviewer",
            dependencies=["draft"],
            priority=0.6,
        )
    )
    await scheduler.run()

    assert order.index("draft") < order.index("review")
    assert scheduler.is_complete()


# ── Failure handling ─────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_failure_increments_metrics():
    scheduler = StigmergyScheduler(tick_interval=0.05, wake_threshold=0.1)
    call_count = 0

    async def dispatch(agent_id, task):
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            return DispatchResult(success=False, error="oops")
        return DispatchResult(success=True)

    scheduler.set_dispatcher(dispatch)
    await scheduler.add_task(
        TaskSpec(id="flaky", description="might fail", agent_id="bot", priority=0.9)
    )
    await scheduler.run()

    metrics = scheduler.get_metrics()
    assert metrics.total_failures >= 1
    assert metrics.total_completions >= 1


@pytest.mark.asyncio
async def test_exception_in_dispatcher():
    scheduler = StigmergyScheduler(tick_interval=0.05, wake_threshold=0.1)
    call_count = 0

    async def dispatch(agent_id, task):
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            raise RuntimeError("boom")
        return DispatchResult(success=True)

    scheduler.set_dispatcher(dispatch)
    await scheduler.add_task(
        TaskSpec(id="crashy", description="will crash", agent_id="bot", priority=0.9)
    )
    await scheduler.run()

    metrics = scheduler.get_metrics()
    assert metrics.total_failures >= 1
    assert metrics.total_completions >= 1


# ── inject_urgent ────────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_inject_urgent():
    scheduler = StigmergyScheduler(tick_interval=0.05, wake_threshold=0.1)
    dispatched = []

    async def dispatch(agent_id, task):
        dispatched.append(task.id)
        return DispatchResult(success=True)

    scheduler.set_dispatcher(dispatch)
    await scheduler.inject_urgent(
        TaskSpec(id="hotfix", description="urgent fix", agent_id="oncall", priority=0.3)
    )
    await scheduler.run()

    assert "hotfix" in dispatched
    assert scheduler._tasks["hotfix"].priority >= 0.9


# ── Lifecycle: start / stop ──────────────────────────────────────────


@pytest.mark.asyncio
async def test_start_and_stop():
    scheduler = StigmergyScheduler(tick_interval=0.05, wake_threshold=0.1)
    dispatched = []

    async def dispatch(agent_id, task):
        dispatched.append(task.id)
        return DispatchResult(success=True)

    scheduler.set_dispatcher(dispatch)
    await scheduler.add_task(
        TaskSpec(id="bg", description="background work", agent_id="bot", priority=0.8)
    )
    task = scheduler.start()
    await task  # should finish once all tasks complete
    assert "bg" in dispatched


@pytest.mark.asyncio
async def test_stop_mid_run():
    scheduler = StigmergyScheduler(tick_interval=0.05, wake_threshold=0.99)
    # threshold so high nothing dispatches — scheduler loops forever unless stopped

    async def dispatch(agent_id, task):
        return DispatchResult(success=True)

    scheduler.set_dispatcher(dispatch)
    scheduler.register_agent("bot")

    bg = scheduler.start()
    await asyncio.sleep(0.15)
    scheduler.stop()
    await bg  # should return promptly


# ── Metrics snapshot is a copy ───────────────────────────────────────


@pytest.mark.asyncio
async def test_metrics_snapshot_is_copy(scheduler):
    async def dispatch(agent_id, task):
        return DispatchResult(success=True)

    scheduler.set_dispatcher(dispatch)
    await scheduler.add_task(
        TaskSpec(id="m1", description="metrics test", agent_id="bot", priority=0.8)
    )
    await scheduler.run()

    m1 = scheduler.get_metrics()
    m2 = scheduler.get_metrics()
    assert m1 is not m2
    assert m1.completed_tasks == m2.completed_tasks
    m1.completed_tasks.append("fake")
    assert "fake" not in m2.completed_tasks


# ── Custom field injection ───────────────────────────────────────────


@pytest.mark.asyncio
async def test_custom_field(field):
    scheduler = StigmergyScheduler(
        tick_interval=0.05, wake_threshold=0.1, field=field
    )
    assert scheduler.field is field

    async def dispatch(agent_id, task):
        return DispatchResult(success=True)

    scheduler.set_dispatcher(dispatch)
    await scheduler.add_task(
        TaskSpec(id="cf", description="custom field", agent_id="bot", priority=0.8)
    )
    await scheduler.run()
    assert scheduler.is_complete()


# ── is_complete edge cases ───────────────────────────────────────────


def test_is_complete_no_tasks(scheduler):
    assert not scheduler.is_complete()


@pytest.mark.asyncio
async def test_no_dispatcher_does_not_crash(scheduler):
    await scheduler.add_task(
        TaskSpec(id="orphan", description="no dispatcher", agent_id="bot")
    )
    await scheduler.tick()
    assert not scheduler.is_complete()
