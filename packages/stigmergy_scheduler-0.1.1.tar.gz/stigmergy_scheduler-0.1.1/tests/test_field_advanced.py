"""Advanced field tests — concurrency, multi-agent scenarios, pressure edge cases."""

import asyncio

import pytest

from stigmergy import InMemoryFieldBackend, PheromoneField, Signal


@pytest.fixture
def field():
    return PheromoneField(InMemoryFieldBackend())


class TestConcurrency:
    @pytest.mark.asyncio
    async def test_concurrent_deposits(self, field):
        """Many agents depositing simultaneously should not lose signals."""
        async def deposit(i: int):
            await field.deposit(f"agent-{i}", "work", 0.5)

        await asyncio.gather(*[deposit(i) for i in range(50)])
        assert await field.signal_count() == 50

    @pytest.mark.asyncio
    async def test_concurrent_reads_during_writes(self, field):
        """Reads during writes should not crash."""
        async def write_loop():
            for i in range(20):
                await field.deposit(f"w-{i}", "work", 0.5)

        async def read_loop():
            for _ in range(20):
                await field.read()
                await field.read_pressure("reader")

        await asyncio.gather(write_loop(), read_loop())
        assert await field.signal_count() == 20


class TestMultiAgentScenarios:
    @pytest.mark.asyncio
    async def test_pressure_asymmetry(self, field):
        """Agent A deposits heavily, agent B should feel high pressure."""
        for i in range(10):
            await field.deposit("agent-a", f"signal-{i}", 0.8)

        pressure = await field.read_pressure("agent-b")
        assert pressure > 5.0  # 10 signals * 0.8 = 8.0

        # Agent A feels no pressure from own signals
        pressure_a = await field.read_pressure("agent-a")
        assert pressure_a == 0.0

    @pytest.mark.asyncio
    async def test_targeted_pressure_isolation(self, field):
        """Targeted signals only pressure the target agent."""
        await field.deposit("a1", "help", 0.9, target_agent_id="a2")
        await field.deposit("a1", "help", 0.9, target_agent_id="a3")

        # a2 only sees the signal targeted to them (+ any untargeted)
        pressure_a2 = await field.read_pressure("a2")
        pressure_a4 = await field.read_pressure("a4")

        assert pressure_a2 > 0
        assert pressure_a4 == 0  # No signals visible to a4

    @pytest.mark.asyncio
    async def test_broadcast_vs_targeted(self, field):
        """Broadcast signals visible to all, targeted only to recipient."""
        await field.deposit("a1", "broadcast", 0.5)
        await field.deposit("a1", "targeted", 0.5, target_agent_id="a2")

        # a2 sees both
        signals_a2 = await field.read(agent_id="a2", exclude_own=True)
        assert len(signals_a2) == 2

        # a3 sees only broadcast
        signals_a3 = await field.read(agent_id="a3", exclude_own=True)
        assert len(signals_a3) == 1
        assert signals_a3[0].signal_type == "broadcast"

    @pytest.mark.asyncio
    async def test_clear_one_agent_preserves_others(self, field):
        """Clearing one agent's signals doesn't affect others."""
        await field.deposit("a1", "sig", 0.5)
        await field.deposit("a1", "sig", 0.3)
        await field.deposit("a2", "sig", 0.8)
        await field.deposit("a3", "sig", 0.4)

        removed = await field.clear_agent("a1")
        assert removed == 2
        assert await field.signal_count() == 2

        signals = await field.read()
        agents = {s.agent_id for s in signals}
        assert "a1" not in agents
        assert "a2" in agents
        assert "a3" in agents


class TestPressureWeights:
    @pytest.mark.asyncio
    async def test_zero_weight_ignored(self, field):
        """Signal types with zero weight contribute nothing to pressure."""
        await field.deposit("a1", "important", 0.8)
        await field.deposit("a2", "noise", 0.5)

        pressure = await field.read_pressure(
            "a3", weights={"important": 1.0, "noise": 0.0}
        )
        assert abs(pressure - 0.8) < 0.001

    @pytest.mark.asyncio
    async def test_negative_weights_for_avoidance(self, field):
        """Negative weights can be used for avoidance signals."""
        await field.deposit("a1", "attract", 0.5)
        await field.deposit("a2", "repel", 0.5)

        pressure = await field.read_pressure(
            "a3", weights={"attract": 1.0, "repel": -1.0}
        )
        assert abs(pressure - 0.0) < 0.001

    @pytest.mark.asyncio
    async def test_unweighted_types_use_default(self, field):
        """Signal types not in weights dict use default weight of 1.0."""
        await field.deposit("a1", "known", 0.5)
        await field.deposit("a2", "unknown_type", 0.3)

        # Only weight "known", "unknown_type" gets default 1.0
        pressure = await field.read_pressure("a3", weights={"known": 2.0})
        expected = 0.5 * 2.0 + 0.3 * 1.0  # 1.0 + 0.3 = 1.3
        assert abs(pressure - expected) < 0.001


class TestReadFiltering:
    @pytest.mark.asyncio
    async def test_min_intensity_filter(self, field):
        """Signals below min_intensity should be filtered out."""
        await field.deposit("a1", "strong", 0.8)
        await field.deposit("a2", "weak", 0.1)
        await field.deposit("a3", "medium", 0.4)

        signals = await field.read(min_intensity=0.3)
        assert len(signals) == 2
        intensities = [s.intensity for s in signals]
        assert all(i >= 0.3 for i in intensities)

    @pytest.mark.asyncio
    async def test_read_sorted_by_intensity(self, field):
        """Signals should be returned sorted by intensity (strongest first)."""
        await field.deposit("a1", "t", 0.3)
        await field.deposit("a2", "t", 0.9)
        await field.deposit("a3", "t", 0.6)

        signals = await field.read()
        intensities = [s.intensity for s in signals]
        assert intensities == sorted(intensities, reverse=True)

    @pytest.mark.asyncio
    async def test_empty_field_read(self, field):
        """Reading an empty field returns empty list."""
        assert await field.read() == []
        assert await field.read_pressure("a1") == 0.0


class TestAmplificationAdvanced:
    @pytest.mark.asyncio
    async def test_amplify_preserves_metadata(self, field):
        """Amplification should preserve signal metadata."""
        sig = await field.deposit("a1", "insight", 0.5, {"topic": "AI"})
        updated = await field.amplify(sig.id, 1.5)

        assert updated is not None
        assert updated.metadata == {"topic": "AI"}
        assert updated.agent_id == "a1"
        assert updated.signal_type == "insight"

    @pytest.mark.asyncio
    async def test_amplify_below_zero_floors(self, field):
        """Dampening a positive signal can't make it negative."""
        sig = await field.deposit("a1", "test", 0.3)
        updated = await field.amplify(sig.id, 0.01)  # 0.3 * 0.01 = 0.003

        assert updated is not None
        assert updated.intensity >= 0.0

    @pytest.mark.asyncio
    async def test_sequential_amplifications(self, field):
        """Multiple amplifications should compound."""
        sig = await field.deposit("a1", "test", 0.5)
        await field.amplify(sig.id, 1.5)  # -> 0.75
        updated = await field.amplify(sig.id, 1.5)  # -> 1.0 (capped)

        assert updated is not None
        # After two 1.5x amplifications: 0.5 * 1.5 * 1.5 = 1.125 -> capped at 1.0
        assert updated.intensity == 1.0
