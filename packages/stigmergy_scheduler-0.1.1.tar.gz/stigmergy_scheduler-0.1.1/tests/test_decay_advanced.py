"""Advanced decay tests — stochastic decay, edge cases, interaction with field."""

import asyncio
import time

import pytest

from stigmergy import (
    ExponentialDecay,
    InMemoryFieldBackend,
    LinearDecay,
    PheromoneField,
    Signal,
    StepDecay,
)
from stigmergy.decay import StochasticDecay


class TestStochasticDecay:
    def test_stochastic_has_randomness(self):
        decay = StochasticDecay(half_life_seconds=3600, noise_factor=0.3)
        signal = Signal(agent_id="a1", signal_type="t", intensity=1.0)

        # Run many times — results should vary
        results = set()
        for _ in range(100):
            val = decay.compute(signal, 1800)  # half a half-life
            results.add(round(val, 3))

        # With noise_factor=0.3, we should see variation
        assert len(results) > 1, "Stochastic decay should produce varied results"

    def test_stochastic_stays_bounded(self):
        decay = StochasticDecay(half_life_seconds=100, noise_factor=0.5)
        signal = Signal(agent_id="a1", signal_type="t", intensity=1.0)

        for _ in range(1000):
            val = decay.compute(signal, 50)
            assert 0.0 <= val <= 1.0, f"Value {val} out of bounds"

    def test_stochastic_negative_signal(self):
        decay = StochasticDecay(half_life_seconds=3600, noise_factor=0.2)
        signal = Signal(agent_id="a1", signal_type="t", intensity=-0.8)

        for _ in range(100):
            val = decay.compute(signal, 1800)
            assert -1.0 <= val <= 0.0


class TestDecayEdgeCases:
    def test_zero_age(self):
        """Decay with zero elapsed time should return original intensity."""
        for decay in [
            ExponentialDecay(3600),
            LinearDecay(0.1),
            StepDecay(60),
        ]:
            signal = Signal(agent_id="a1", signal_type="t", intensity=0.7)
            result = decay.compute(signal, 0)
            assert abs(result - 0.7) < 0.001

    def test_very_large_age(self):
        """Decay with very large age should approach zero."""
        for decay in [
            ExponentialDecay(3600),
            LinearDecay(0.001),
        ]:
            signal = Signal(agent_id="a1", signal_type="t", intensity=1.0)
            result = decay.compute(signal, 1_000_000)
            assert result < 0.01

    def test_zero_intensity_signal(self):
        """A zero-intensity signal stays at zero after decay."""
        signal = Signal(agent_id="a1", signal_type="t", intensity=0.0)
        for decay in [
            ExponentialDecay(3600),
            LinearDecay(0.1),
        ]:
            assert decay.compute(signal, 100) == 0.0

    def test_linear_decay_exact_boundary(self):
        """Linear decay hitting exactly zero."""
        decay = LinearDecay(rate_per_second=0.1)
        signal = Signal(agent_id="a1", signal_type="t", intensity=1.0)
        result = decay.compute(signal, 10)  # 1.0 - 0.1*10 = 0.0
        assert result == 0.0

    def test_step_decay_exact_boundary(self):
        """Step decay at exact TTL boundary — >= TTL means dead."""
        decay = StepDecay(ttl_seconds=60)
        signal = Signal(agent_id="a1", signal_type="t", intensity=0.5)
        # Just before TTL — alive
        assert decay.compute(signal, 59) == 0.5
        # Exactly at TTL — dead (implementation uses >=)
        assert decay.compute(signal, 60) == 0.0
        # Past TTL — dead
        assert decay.compute(signal, 61) == 0.0


class TestFieldDecayIntegration:
    @pytest.mark.asyncio
    async def test_multiple_decay_passes(self):
        """Multiple decay passes progressively weaken signals."""
        field = PheromoneField(
            InMemoryFieldBackend(),
            decay_strategy=LinearDecay(rate_per_second=100.0),
            evaporation_threshold=0.01,
        )
        await field.deposit("a1", "test", 0.5)

        # Let a tiny bit of time pass
        await asyncio.sleep(0.01)
        evaporated = await field.decay()
        assert evaporated == 1  # Signal should be evaporated

    @pytest.mark.asyncio
    async def test_mixed_signal_strengths_decay(self):
        """Strong signals survive longer than weak ones."""
        field = PheromoneField(
            InMemoryFieldBackend(),
            decay_strategy=LinearDecay(rate_per_second=50.0),
            evaporation_threshold=0.1,
        )
        await field.deposit("a1", "strong", 1.0)
        await field.deposit("a2", "weak", 0.05)

        await asyncio.sleep(0.01)
        evaporated = await field.decay()
        # Weak signal should evaporate, strong survives
        assert evaporated >= 1
        remaining = await field.signal_count()
        assert remaining <= 1

    @pytest.mark.asyncio
    async def test_decay_updates_intensity_in_place(self):
        """After decay, reading signals should show reduced intensity."""
        field = PheromoneField(
            InMemoryFieldBackend(),
            decay_strategy=ExponentialDecay(half_life_seconds=0.01),
            evaporation_threshold=0.01,
        )
        sig = await field.deposit("a1", "test", 1.0)

        # Wait for one half-life
        await asyncio.sleep(0.02)
        await field.decay()

        signals = await field.read()
        if signals:
            assert signals[0].intensity < 1.0
