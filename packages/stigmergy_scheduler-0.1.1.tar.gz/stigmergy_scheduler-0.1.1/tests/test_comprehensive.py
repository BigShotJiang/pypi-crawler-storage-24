"""Comprehensive tests — covering untested paths, edge cases, and integration."""

import asyncio

import pytest

from stigmergy import InMemoryFieldBackend, PheromoneField, Signal
from stigmergy.backends import RedisFieldBackend
from stigmergy.decay import ExponentialDecay, LinearDecay, StepDecay, StochasticDecay


# --- Signal edge cases ---


class TestSignalEdgeCases:
    def test_zero_intensity_properties(self):
        """Zero-intensity signal is neither attraction nor repulsion."""
        sig = Signal(agent_id="a1", signal_type="t", intensity=0.0)
        assert not sig.is_attraction
        assert not sig.is_repulsion

    def test_intensity_boundary_values(self):
        """Exact boundary intensities should be valid."""
        s1 = Signal(agent_id="a1", signal_type="t", intensity=1.0)
        s2 = Signal(agent_id="a1", signal_type="t", intensity=-1.0)
        assert s1.is_attraction
        assert s2.is_repulsion

    def test_intensity_out_of_bounds_raises(self):
        """Values outside [-1, 1] should raise ValueError."""
        with pytest.raises(ValueError):
            Signal(agent_id="a1", signal_type="t", intensity=1.01)
        with pytest.raises(ValueError):
            Signal(agent_id="a1", signal_type="t", intensity=-1.01)

    def test_with_intensity_clamps_out_of_range(self):
        """with_intensity() should clamp to [-1, 1]."""
        sig = Signal(agent_id="a1", signal_type="t", intensity=0.5)
        clamped_high = sig.with_intensity(5.0)
        clamped_low = sig.with_intensity(-5.0)
        assert clamped_high.intensity == 1.0
        assert clamped_low.intensity == -1.0

    def test_with_intensity_preserves_target(self):
        """with_intensity() should preserve target_agent_id."""
        sig = Signal(agent_id="a1", signal_type="t", intensity=0.5, target_agent_id="a2")
        updated = sig.with_intensity(0.9)
        assert updated.target_agent_id == "a2"
        assert updated.id == sig.id

    def test_age_seconds_positive(self):
        """age_seconds should be non-negative."""
        sig = Signal(agent_id="a1", signal_type="t", intensity=0.5)
        assert sig.age_seconds >= 0.0

    def test_complex_metadata(self):
        """Signals should handle complex nested metadata."""
        meta = {"nested": {"list": [1, 2, 3], "deep": {"val": True}}, "n": None}
        sig = Signal(agent_id="a1", signal_type="t", intensity=0.5, metadata=meta)
        assert sig.metadata["nested"]["deep"]["val"] is True
        assert sig.metadata["n"] is None

    def test_unique_ids(self):
        """Each signal should get a unique ID."""
        ids = {Signal(agent_id="a1", signal_type="t", intensity=0.5).id for _ in range(50)}
        assert len(ids) == 50


# --- PheromoneField: Negative signals and amplification ---


class TestFieldNegativeSignals:
    @pytest.mark.asyncio
    async def test_deposit_negative_intensity(self):
        """Negative intensity signals should be depositable and readable."""
        field = PheromoneField(InMemoryFieldBackend())
        sig = await field.deposit("a1", "repel", -0.7)
        assert sig.intensity == -0.7
        assert sig.is_repulsion

        signals = await field.read()
        assert len(signals) == 1
        assert signals[0].intensity == -0.7

    @pytest.mark.asyncio
    async def test_pressure_with_all_negative_signals(self):
        """Pressure from only negative signals should be negative."""
        field = PheromoneField(InMemoryFieldBackend())
        await field.deposit("a1", "repel", -0.5)
        await field.deposit("a2", "repel", -0.3)

        pressure = await field.read_pressure("a3")
        assert pressure == pytest.approx(-0.8, abs=0.01)

    @pytest.mark.asyncio
    async def test_pressure_mixed_positive_negative(self):
        """Mixed signals should partially cancel out."""
        field = PheromoneField(InMemoryFieldBackend())
        await field.deposit("a1", "attract", 0.8)
        await field.deposit("a2", "repel", -0.3)

        pressure = await field.read_pressure("a3")
        assert pressure == pytest.approx(0.5, abs=0.01)

    @pytest.mark.asyncio
    async def test_amplify_negative_signal(self):
        """Amplifying a negative signal should make it more negative."""
        field = PheromoneField(InMemoryFieldBackend())
        sig = await field.deposit("a1", "repel", -0.3)
        result = await field.amplify(sig.id, 2.0)
        assert result is not None
        assert result.intensity == pytest.approx(-0.6, abs=0.01)

    @pytest.mark.asyncio
    async def test_dampen_negative_signal(self):
        """Dampening a negative signal should move it towards zero."""
        field = PheromoneField(InMemoryFieldBackend())
        sig = await field.deposit("a1", "repel", -0.8)
        result = await field.amplify(sig.id, 0.5)
        assert result is not None
        assert result.intensity == pytest.approx(-0.4, abs=0.01)

    @pytest.mark.asyncio
    async def test_amplify_with_zero_factor(self):
        """Factor of 0 should set intensity to 0."""
        field = PheromoneField(InMemoryFieldBackend())
        sig = await field.deposit("a1", "work", 0.8)
        result = await field.amplify(sig.id, 0.0)
        assert result is not None
        assert result.intensity == 0.0

    @pytest.mark.asyncio
    async def test_amplify_capped_for_negative(self):
        """Amplification cap should work for negative signals too."""
        field = PheromoneField(InMemoryFieldBackend(), max_amplification=2.0)
        sig = await field.deposit("a1", "repel", -0.3)
        # factor=10 would make -3.0, cap at -0.3 * 2.0 = -0.6
        result = await field.amplify(sig.id, 10.0)
        assert result is not None
        assert result.intensity == pytest.approx(-0.6, abs=0.01)


# --- PheromoneField: Filter combinations ---


class TestFieldFilterCombinations:
    @pytest.mark.asyncio
    async def test_read_with_empty_signal_types_list(self):
        """Empty signal_types list should return nothing (strict filter)."""
        field = PheromoneField(InMemoryFieldBackend())
        await field.deposit("a1", "work", 0.5)
        signals = await field.read(signal_types=[])
        assert len(signals) == 0

    @pytest.mark.asyncio
    async def test_read_sorted_by_absolute_intensity(self):
        """Signals should sort by abs(intensity), mixing positive and negative."""
        field = PheromoneField(InMemoryFieldBackend())
        await field.deposit("a1", "t", 0.3)
        await field.deposit("a2", "t", -0.9)
        await field.deposit("a3", "t", 0.6)

        signals = await field.read()
        assert len(signals) == 3
        # abs: 0.9, 0.6, 0.3
        assert abs(signals[0].intensity) >= abs(signals[1].intensity)
        assert abs(signals[1].intensity) >= abs(signals[2].intensity)

    @pytest.mark.asyncio
    async def test_read_min_intensity_with_negative(self):
        """min_intensity should filter by absolute value via backend."""
        field = PheromoneField(InMemoryFieldBackend())
        await field.deposit("a1", "t", 0.8)
        await field.deposit("a2", "t", -0.9)
        await field.deposit("a3", "t", 0.2)

        signals = await field.read(min_intensity=0.5)
        # Only signals with abs(intensity) >= 0.5 — depends on backend implementation
        assert all(abs(s.intensity) >= 0.5 for s in signals)

    @pytest.mark.asyncio
    async def test_pressure_with_empty_weights_dict(self):
        """Empty weights dict should use default weight of 1.0."""
        field = PheromoneField(InMemoryFieldBackend())
        await field.deposit("a1", "work", 0.5)

        pressure = await field.read_pressure("a2", weights={})
        assert pressure == pytest.approx(0.5, abs=0.01)

    @pytest.mark.asyncio
    async def test_pressure_with_type_filter_and_weights(self):
        """Signal types filter and weights should work together."""
        field = PheromoneField(InMemoryFieldBackend())
        await field.deposit("a1", "work", 0.5)
        await field.deposit("a2", "help", 0.3)

        pressure = await field.read_pressure(
            "a3",
            signal_types=["work"],
            weights={"work": 2.0}
        )
        assert pressure == pytest.approx(1.0, abs=0.01)

    @pytest.mark.asyncio
    async def test_clear_nonexistent_agent(self):
        """Clearing signals for an agent that has none should return 0."""
        field = PheromoneField(InMemoryFieldBackend())
        await field.deposit("a1", "work", 0.5)
        result = await field.clear_agent("nonexistent")
        assert result == 0
        # Original signal still there
        assert await field.signal_count() == 1


# --- PheromoneField: Decay integration ---


class TestFieldDecayIntegrationComprehensive:
    @pytest.mark.asyncio
    async def test_decay_empty_field(self):
        """Decay on empty field should return 0."""
        field = PheromoneField(InMemoryFieldBackend())
        removed = await field.decay()
        assert removed == 0

    @pytest.mark.asyncio
    async def test_signal_count_direct(self):
        """signal_count() should match number of stored signals."""
        field = PheromoneField(InMemoryFieldBackend())
        assert await field.signal_count() == 0
        await field.deposit("a1", "t", 0.5)
        assert await field.signal_count() == 1
        await field.deposit("a2", "t", 0.3)
        assert await field.signal_count() == 2


# --- Decay strategy validation ---


class TestDecayValidation:
    def test_exponential_decay_zero_half_life_raises(self):
        """ExponentialDecay with zero half_life should raise ValueError."""
        with pytest.raises(ValueError, match="positive"):
            ExponentialDecay(half_life_seconds=0)

    def test_exponential_decay_negative_half_life_raises(self):
        """ExponentialDecay with negative half_life should raise ValueError."""
        with pytest.raises(ValueError, match="positive"):
            ExponentialDecay(half_life_seconds=-100)

    def test_linear_decay_negative_intensity(self):
        """LinearDecay should move negative intensity towards zero."""
        decay = LinearDecay(rate_per_second=0.1)
        sig = Signal(agent_id="a1", signal_type="t", intensity=-0.5)
        result = decay.compute(sig, 3.0)
        # -0.5 + 0.3 = -0.2
        assert result == pytest.approx(-0.2, abs=0.01)

    def test_linear_decay_negative_exactly_at_zero(self):
        """Linear decay should stop at 0 for negative signals."""
        decay = LinearDecay(rate_per_second=0.1)
        sig = Signal(agent_id="a1", signal_type="t", intensity=-0.3)
        result = decay.compute(sig, 5.0)  # would be -0.3 + 0.5 = 0.2, clamped to 0
        assert result == 0.0

    def test_stochastic_decay_zero_base_gives_zero_noise(self):
        """When base value is 0, noise factor should produce no variation."""
        decay = StochasticDecay(half_life_seconds=1.0, noise_factor=0.1)
        sig = Signal(agent_id="a1", signal_type="t", intensity=0.0)
        # Zero intensity * any decay = 0, noise on 0 = 0
        result = decay.compute(sig, 100)
        assert result == 0.0

    def test_stochastic_decay_preserves_sign_for_negative(self):
        """Stochastic decay should keep negative signals negative."""
        decay = StochasticDecay(half_life_seconds=3600, noise_factor=0.1)
        sig = Signal(agent_id="a1", signal_type="t", intensity=-0.8)
        # Run multiple times — should always be <= 0
        for _ in range(50):
            result = decay.compute(sig, 60)
            assert result <= 0.0


# --- Redis backend serialization edge cases ---


class MockRedis:
    def __init__(self):
        self._store: dict[str, dict[str, str]] = {}

    async def hset(self, key: str, field: str, value: str):
        self._store.setdefault(key, {})[field] = value

    async def hget(self, key: str, field: str):
        return self._store.get(key, {}).get(field)

    async def hdel(self, key: str, *fields: str):
        bucket = self._store.get(key, {})
        count = 0
        for f in fields:
            if f in bucket:
                del bucket[f]
                count += 1
        return count

    async def hvals(self, key: str):
        return list(self._store.get(key, {}).values())

    async def hlen(self, key: str):
        return len(self._store.get(key, {}))

    async def delete(self, key: str):
        self._store.pop(key, None)


class TestRedisSerializationEdgeCases:
    @pytest.fixture
    def backend(self):
        return RedisFieldBackend(MockRedis(), key_prefix="test:")

    @pytest.mark.asyncio
    async def test_roundtrip_targeted_signal(self, backend):
        """Signal with target_agent_id should survive serialization."""
        sig = Signal(agent_id="a1", signal_type="t", intensity=0.5, target_agent_id="a2")
        await backend.store(sig)
        found = await backend.get(sig.id)
        assert found is not None
        assert found.target_agent_id == "a2"

    @pytest.mark.asyncio
    async def test_roundtrip_complex_metadata(self, backend):
        """Signals with nested metadata should survive serialization."""
        sig = Signal(
            agent_id="a1", signal_type="t", intensity=0.5,
            metadata={"nested": {"key": [1, 2, 3]}, "flag": True}
        )
        await backend.store(sig)
        found = await backend.get(sig.id)
        assert found is not None
        assert found.metadata["nested"]["key"] == [1, 2, 3]
        assert found.metadata["flag"] is True

    @pytest.mark.asyncio
    async def test_roundtrip_negative_intensity(self, backend):
        """Negative intensity should survive serialization."""
        sig = Signal(agent_id="a1", signal_type="t", intensity=-0.7)
        await backend.store(sig)
        found = await backend.get(sig.id)
        assert found is not None
        assert found.intensity == pytest.approx(-0.7, abs=0.001)

    @pytest.mark.asyncio
    async def test_update_nonexistent_signal(self, backend):
        """Updating intensity for nonexistent signal should not raise."""
        await backend.update_intensity("nonexistent", 0.9)
        # Should not raise

    @pytest.mark.asyncio
    async def test_remove_batch_empty_list(self, backend):
        """Removing empty batch should return 0."""
        removed = await backend.remove_batch([])
        assert removed == 0

    @pytest.mark.asyncio
    async def test_list_with_all_filters(self, backend):
        """List with all filter params at once."""
        s1 = Signal(agent_id="a1", signal_type="work", intensity=0.8)
        s2 = Signal(agent_id="a2", signal_type="help", intensity=0.3)
        s3 = Signal(agent_id="a1", signal_type="work", intensity=0.2)
        for s in [s1, s2, s3]:
            await backend.store(s)

        signals = await backend.list_signals(
            signal_types=["work"],
            agent_id="a1",
            min_intensity=0.5,
        )
        assert len(signals) == 1
        assert signals[0].intensity == 0.8


# --- End-to-end integration ---


class TestEndToEndIntegration:
    @pytest.mark.asyncio
    async def test_deposit_amplify_decay_cycle(self):
        """Full cycle: deposit → amplify → decay → read."""
        backend = InMemoryFieldBackend()
        field = PheromoneField(
            backend,
            decay_strategy=StepDecay(ttl_seconds=10),
            evaporation_threshold=0.01,
        )

        # Deposit
        sig = await field.deposit("a1", "insight", 0.5, metadata={"topic": "AI"})
        assert await field.signal_count() == 1

        # Amplify
        result = await field.amplify(sig.id, 1.5)
        assert result is not None
        assert result.intensity == pytest.approx(0.75, abs=0.01)

        # Read pressure as another agent
        pressure = await field.read_pressure("a2")
        assert pressure == pytest.approx(0.75, abs=0.01)

        # Signal is alive (within TTL)
        removed = await field.decay()
        assert removed == 0

    @pytest.mark.asyncio
    async def test_multi_agent_deposit_read_clear(self):
        """Multiple agents deposit, read, then one clears."""
        field = PheromoneField(InMemoryFieldBackend())

        await field.deposit("a1", "work", 0.5)
        await field.deposit("a1", "help", 0.3)
        await field.deposit("a2", "work", 0.7)

        assert await field.signal_count() == 3

        # Clear a1's signals
        cleared = await field.clear_agent("a1")
        assert cleared == 2
        assert await field.signal_count() == 1

        # Only a2's signal remains
        signals = await field.read()
        assert len(signals) == 1
        assert signals[0].agent_id == "a2"
