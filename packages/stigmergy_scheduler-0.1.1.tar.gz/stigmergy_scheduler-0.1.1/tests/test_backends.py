"""Tests for stigmergy backends — InMemory and Redis (mocked)."""

import asyncio

import pytest

from stigmergy import InMemoryFieldBackend, Signal
from stigmergy.backends import RedisFieldBackend


# --- InMemoryFieldBackend ---


class TestInMemoryBackend:
    @pytest.mark.asyncio
    async def test_store_and_list(self):
        backend = InMemoryFieldBackend()
        sig = Signal(agent_id="a1", signal_type="test", intensity=0.5)
        await backend.store(sig)

        signals = await backend.list_signals()
        assert len(signals) == 1
        assert signals[0].id == sig.id

    @pytest.mark.asyncio
    async def test_get_by_id(self):
        backend = InMemoryFieldBackend()
        sig = Signal(agent_id="a1", signal_type="test", intensity=0.5)
        await backend.store(sig)

        found = await backend.get(sig.id)
        assert found is not None
        assert found.id == sig.id
        assert found.intensity == 0.5

    @pytest.mark.asyncio
    async def test_get_missing(self):
        backend = InMemoryFieldBackend()
        found = await backend.get("nonexistent")
        assert found is None

    @pytest.mark.asyncio
    async def test_update_intensity(self):
        backend = InMemoryFieldBackend()
        sig = Signal(agent_id="a1", signal_type="test", intensity=0.5)
        await backend.store(sig)

        await backend.update_intensity(sig.id, 0.9)

        found = await backend.get(sig.id)
        assert found is not None
        assert found.intensity == 0.9

    @pytest.mark.asyncio
    async def test_remove(self):
        backend = InMemoryFieldBackend()
        sig = Signal(agent_id="a1", signal_type="test", intensity=0.5)
        await backend.store(sig)
        await backend.remove(sig.id)

        assert await backend.get(sig.id) is None
        assert len(await backend.list_signals()) == 0

    @pytest.mark.asyncio
    async def test_remove_nonexistent_is_noop(self):
        backend = InMemoryFieldBackend()
        await backend.remove("nonexistent")  # Should not raise

    @pytest.mark.asyncio
    async def test_remove_batch(self):
        backend = InMemoryFieldBackend()
        s1 = Signal(agent_id="a1", signal_type="t", intensity=0.5)
        s2 = Signal(agent_id="a2", signal_type="t", intensity=0.3)
        s3 = Signal(agent_id="a3", signal_type="t", intensity=0.7)
        await backend.store(s1)
        await backend.store(s2)
        await backend.store(s3)

        removed = await backend.remove_batch([s1.id, s2.id])
        assert removed == 2
        assert await backend.count() == 1

    @pytest.mark.asyncio
    async def test_count(self):
        backend = InMemoryFieldBackend()
        assert await backend.count() == 0

        await backend.store(Signal(agent_id="a1", signal_type="t", intensity=0.5))
        await backend.store(Signal(agent_id="a2", signal_type="t", intensity=0.3))
        assert await backend.count() == 2

    @pytest.mark.asyncio
    async def test_list_filter_by_type(self):
        backend = InMemoryFieldBackend()
        await backend.store(Signal(agent_id="a1", signal_type="work", intensity=0.5))
        await backend.store(Signal(agent_id="a2", signal_type="help", intensity=0.3))

        results = await backend.list_signals(signal_types=["work"])
        assert len(results) == 1
        assert results[0].signal_type == "work"

    @pytest.mark.asyncio
    async def test_list_filter_by_agent(self):
        backend = InMemoryFieldBackend()
        await backend.store(Signal(agent_id="a1", signal_type="t", intensity=0.5))
        await backend.store(Signal(agent_id="a2", signal_type="t", intensity=0.3))

        results = await backend.list_signals(agent_id="a1")
        assert len(results) == 1
        assert results[0].agent_id == "a1"

    @pytest.mark.asyncio
    async def test_list_filter_by_min_intensity(self):
        backend = InMemoryFieldBackend()
        await backend.store(Signal(agent_id="a1", signal_type="t", intensity=0.8))
        await backend.store(Signal(agent_id="a2", signal_type="t", intensity=0.2))

        results = await backend.list_signals(min_intensity=0.5)
        assert len(results) == 1
        assert results[0].intensity == 0.8

    @pytest.mark.asyncio
    async def test_concurrent_writes(self):
        """Multiple concurrent deposits should not lose data."""
        backend = InMemoryFieldBackend()

        async def deposit(i: int):
            sig = Signal(agent_id=f"a{i}", signal_type="t", intensity=0.5)
            await backend.store(sig)

        await asyncio.gather(*[deposit(i) for i in range(20)])
        assert await backend.count() == 20


# --- RedisFieldBackend (unit tests with mock) ---


class MockRedis:
    """Minimal mock Redis client for testing the backend adapter."""

    def __init__(self):
        self._store: dict[str, dict[str, str]] = {}

    async def hset(self, key: str, field: str, value: str):
        self._store.setdefault(key, {})[field] = value

    async def hget(self, key: str, field: str):
        return self._store.get(key, {}).get(field)

    async def hdel(self, key: str, *fields: str):
        bucket = self._store.get(key, {})
        count = 0
        for f in fields:
            if f in bucket:
                del bucket[f]
                count += 1
        return count

    async def hvals(self, key: str):
        return list(self._store.get(key, {}).values())

    async def hlen(self, key: str):
        return len(self._store.get(key, {}))

    async def delete(self, key: str):
        self._store.pop(key, None)


class TestRedisBackend:
    @pytest.fixture
    def backend(self):
        return RedisFieldBackend(MockRedis(), key_prefix="test:")

    @pytest.mark.asyncio
    async def test_store_and_get(self, backend):
        sig = Signal(agent_id="a1", signal_type="test", intensity=0.5)
        await backend.store(sig)

        found = await backend.get(sig.id)
        assert found is not None
        assert found.agent_id == "a1"
        assert found.intensity == 0.5

    @pytest.mark.asyncio
    async def test_list_signals(self, backend):
        await backend.store(Signal(agent_id="a1", signal_type="t", intensity=0.5))
        await backend.store(Signal(agent_id="a2", signal_type="t", intensity=0.3))

        signals = await backend.list_signals()
        assert len(signals) == 2

    @pytest.mark.asyncio
    async def test_remove(self, backend):
        sig = Signal(agent_id="a1", signal_type="test", intensity=0.5)
        await backend.store(sig)
        await backend.remove(sig.id)

        assert await backend.get(sig.id) is None

    @pytest.mark.asyncio
    async def test_count(self, backend):
        assert await backend.count() == 0
        await backend.store(Signal(agent_id="a1", signal_type="t", intensity=0.5))
        assert await backend.count() == 1

    @pytest.mark.asyncio
    async def test_update_intensity(self, backend):
        sig = Signal(agent_id="a1", signal_type="test", intensity=0.5)
        await backend.store(sig)
        await backend.update_intensity(sig.id, 0.9)

        found = await backend.get(sig.id)
        assert found is not None
        assert found.intensity == 0.9

    @pytest.mark.asyncio
    async def test_remove_batch(self, backend):
        s1 = Signal(agent_id="a1", signal_type="t", intensity=0.5)
        s2 = Signal(agent_id="a2", signal_type="t", intensity=0.3)
        await backend.store(s1)
        await backend.store(s2)

        removed = await backend.remove_batch([s1.id, s2.id])
        assert removed == 2
        assert await backend.count() == 0
