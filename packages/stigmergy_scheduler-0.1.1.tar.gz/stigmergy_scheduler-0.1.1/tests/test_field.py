"""Tests for PheromoneField — core stigmergy coordination."""

import asyncio
from datetime import datetime, timedelta, timezone

import pytest

from stigmergy import (
    ExponentialDecay,
    InMemoryFieldBackend,
    LinearDecay,
    PheromoneField,
    Signal,
    StepDecay,
)


@pytest.fixture
def field():
    return PheromoneField(InMemoryFieldBackend())


@pytest.fixture
def fast_decay_field():
    """Field with very fast decay for testing evaporation."""
    return PheromoneField(
        InMemoryFieldBackend(),
        decay_strategy=LinearDecay(rate_per_second=10.0),
        evaporation_threshold=0.05,
    )


# --- Signal creation ---


class TestSignal:
    def test_signal_defaults(self):
        s = Signal(agent_id="a1", signal_type="test", intensity=0.5)
        assert s.agent_id == "a1"
        assert s.signal_type == "test"
        assert s.intensity == 0.5
        assert s.is_attraction
        assert not s.is_repulsion
        assert s.id  # auto-generated

    def test_signal_repulsion(self):
        s = Signal(agent_id="a1", signal_type="test", intensity=-0.5)
        assert s.is_repulsion
        assert not s.is_attraction

    def test_signal_intensity_bounds(self):
        with pytest.raises(ValueError, match="intensity must be in"):
            Signal(agent_id="a1", signal_type="test", intensity=1.5)
        with pytest.raises(ValueError, match="intensity must be in"):
            Signal(agent_id="a1", signal_type="test", intensity=-1.5)

    def test_signal_immutable(self):
        s = Signal(agent_id="a1", signal_type="test", intensity=0.5)
        with pytest.raises(AttributeError):
            s.intensity = 0.9  # type: ignore

    def test_with_intensity(self):
        s = Signal(agent_id="a1", signal_type="test", intensity=0.5)
        s2 = s.with_intensity(0.8)
        assert s.intensity == 0.5  # original unchanged
        assert s2.intensity == 0.8
        assert s2.id == s.id  # same ID

    def test_with_intensity_clamps(self):
        s = Signal(agent_id="a1", signal_type="test", intensity=0.5)
        s2 = s.with_intensity(5.0)
        assert s2.intensity == 1.0


# --- Deposit & Read ---


class TestDeposit:
    @pytest.mark.asyncio
    async def test_deposit_and_read(self, field):
        sig = await field.deposit("agent-1", "work_claim", 0.8, {"task": "research"})
        assert sig.agent_id == "agent-1"
        assert sig.signal_type == "work_claim"
        assert sig.intensity == 0.8

        signals = await field.read()
        assert len(signals) == 1
        assert signals[0].id == sig.id

    @pytest.mark.asyncio
    async def test_deposit_multiple(self, field):
        await field.deposit("a1", "work_claim", 0.8)
        await field.deposit("a2", "need_help", 0.5)
        await field.deposit("a3", "insight_deposit", 0.3)

        signals = await field.read()
        assert len(signals) == 3
        # Sorted by intensity (strongest first)
        assert signals[0].intensity == 0.8
        assert signals[1].intensity == 0.5
        assert signals[2].intensity == 0.3

    @pytest.mark.asyncio
    async def test_read_filter_by_type(self, field):
        await field.deposit("a1", "work_claim", 0.8)
        await field.deposit("a2", "need_help", 0.5)

        signals = await field.read(signal_types=["work_claim"])
        assert len(signals) == 1
        assert signals[0].signal_type == "work_claim"

    @pytest.mark.asyncio
    async def test_read_exclude_own(self, field):
        await field.deposit("a1", "work_claim", 0.8)
        await field.deposit("a2", "need_help", 0.5)

        signals = await field.read(agent_id="a1", exclude_own=True)
        assert len(signals) == 1
        assert signals[0].agent_id == "a2"

    @pytest.mark.asyncio
    async def test_targeted_signals(self, field):
        await field.deposit("a1", "need_help", 0.8, target_agent_id="a2")
        await field.deposit("a1", "broadcast", 0.5)

        # a2 sees both (targeted to them + untargeted)
        signals = await field.read(agent_id="a2", exclude_own=True)
        assert len(signals) == 2

        # a3 sees only the untargeted one
        signals = await field.read(agent_id="a3", exclude_own=True)
        assert len(signals) == 1
        assert signals[0].signal_type == "broadcast"


# --- Pressure ---


class TestPressure:
    @pytest.mark.asyncio
    async def test_basic_pressure(self, field):
        await field.deposit("a1", "event", 0.5)
        await field.deposit("a2", "goal", 0.3)

        # a3 sees pressure from both (not their own)
        pressure = await field.read_pressure("a3")
        assert abs(pressure - 0.8) < 0.001

    @pytest.mark.asyncio
    async def test_pressure_excludes_own(self, field):
        await field.deposit("a1", "event", 0.5)
        await field.deposit("a1", "goal", 0.3)

        # a1 should not feel pressure from own signals
        pressure = await field.read_pressure("a1")
        assert pressure == 0.0

    @pytest.mark.asyncio
    async def test_pressure_with_weights(self, field):
        await field.deposit("a1", "event", 0.5)
        await field.deposit("a2", "goal", 0.3)

        weights = {"event": 2.0, "goal": 0.5}
        pressure = await field.read_pressure("a3", weights=weights)
        expected = 0.5 * 2.0 + 0.3 * 0.5  # 1.0 + 0.15 = 1.15
        assert abs(pressure - expected) < 0.001

    @pytest.mark.asyncio
    async def test_pressure_with_repulsion(self, field):
        await field.deposit("a1", "attraction", 0.8)
        await field.deposit("a2", "repulsion", -0.5)

        pressure = await field.read_pressure("a3")
        assert abs(pressure - 0.3) < 0.001

    @pytest.mark.asyncio
    async def test_pressure_filter_by_type(self, field):
        await field.deposit("a1", "event", 0.5)
        await field.deposit("a2", "goal", 0.3)

        pressure = await field.read_pressure("a3", signal_types=["event"])
        assert abs(pressure - 0.5) < 0.001


# --- Amplification ---


class TestAmplification:
    @pytest.mark.asyncio
    async def test_amplify(self, field):
        sig = await field.deposit("a1", "insight", 0.5)
        updated = await field.amplify(sig.id, 1.5)

        assert updated is not None
        assert abs(updated.intensity - 0.75) < 0.001

    @pytest.mark.asyncio
    async def test_amplify_capped(self, field):
        sig = await field.deposit("a1", "insight", 0.5)
        # Try to amplify by 10x — should be capped at max_amplification (3x)
        updated = await field.amplify(sig.id, 10.0)

        assert updated is not None
        # Max = 0.5 * 3.0 = 1.0 (also capped at 1.0)
        assert updated.intensity == 1.0

    @pytest.mark.asyncio
    async def test_amplify_dampen(self, field):
        sig = await field.deposit("a1", "insight", 0.8)
        updated = await field.amplify(sig.id, 0.5)

        assert updated is not None
        assert abs(updated.intensity - 0.4) < 0.001

    @pytest.mark.asyncio
    async def test_amplify_nonexistent(self, field):
        result = await field.amplify("nonexistent", 1.5)
        assert result is None


# --- Decay ---


class TestDecay:
    @pytest.mark.asyncio
    async def test_decay_removes_weak_signals(self, fast_decay_field):
        field = fast_decay_field
        # With LinearDecay(rate=10.0) and threshold=0.05,
        # a signal with intensity 0.1 should evaporate almost instantly
        await field.deposit("a1", "weak", 0.05)
        # Small delay to ensure age > 0
        await asyncio.sleep(0.01)

        evaporated = await field.decay()
        assert evaporated == 1
        assert await field.signal_count() == 0

    @pytest.mark.asyncio
    async def test_decay_preserves_strong_signals(self, field):
        await field.deposit("a1", "strong", 1.0)
        # Default ExponentialDecay with 1hr half-life — signal barely decays
        evaporated = await field.decay()
        assert evaporated == 0
        assert await field.signal_count() == 1

    @pytest.mark.asyncio
    async def test_signal_count(self, field):
        assert await field.signal_count() == 0
        await field.deposit("a1", "x", 0.5)
        await field.deposit("a2", "y", 0.5)
        assert await field.signal_count() == 2


# --- Clear agent ---


class TestClearAgent:
    @pytest.mark.asyncio
    async def test_clear_agent(self, field):
        await field.deposit("a1", "claim1", 0.8)
        await field.deposit("a1", "claim2", 0.5)
        await field.deposit("a2", "other", 0.3)

        removed = await field.clear_agent("a1")
        assert removed == 2
        assert await field.signal_count() == 1

        signals = await field.read()
        assert signals[0].agent_id == "a2"


# --- Decay strategies ---


class TestDecayStrategies:
    def test_exponential_decay(self):
        decay = ExponentialDecay(half_life_seconds=3600)
        signal = Signal(agent_id="a1", signal_type="t", intensity=1.0)

        # After one half-life, intensity should be ~0.5
        result = decay.compute(signal, 3600)
        assert abs(result - 0.5) < 0.01

        # After two half-lives, ~0.25
        result = decay.compute(signal, 7200)
        assert abs(result - 0.25) < 0.01

    def test_linear_decay(self):
        decay = LinearDecay(rate_per_second=0.1)
        signal = Signal(agent_id="a1", signal_type="t", intensity=1.0)

        result = decay.compute(signal, 5)
        assert abs(result - 0.5) < 0.01

        # Floors at 0.0
        result = decay.compute(signal, 20)
        assert result == 0.0

    def test_linear_decay_negative(self):
        decay = LinearDecay(rate_per_second=0.1)
        signal = Signal(agent_id="a1", signal_type="t", intensity=-0.5)

        result = decay.compute(signal, 3)
        assert abs(result - (-0.2)) < 0.01

    def test_step_decay(self):
        decay = StepDecay(ttl_seconds=60)
        signal = Signal(agent_id="a1", signal_type="t", intensity=0.8)

        # Before TTL: full intensity
        assert decay.compute(signal, 30) == 0.8
        # After TTL: evaporated
        assert decay.compute(signal, 61) == 0.0
