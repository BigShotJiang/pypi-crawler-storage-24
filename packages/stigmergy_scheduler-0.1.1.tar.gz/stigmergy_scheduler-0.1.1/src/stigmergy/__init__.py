"""stigmergy — Pheromone-field coordination for LLM multi-agent systems.

Implements implicit coordination through shared state, inspired by
ant colony pheromone trails. Agents deposit signals with intensity
that decays over time (evaporation), creating emergent coordination
without explicit messaging or hierarchical control.

Based on: arXiv:2601.08129 — Pressure-field coordination outperforms
hierarchical control by 30x on solve rates.

Quick start:
    from stigmergy import PheromoneField, InMemoryFieldBackend

    field = PheromoneField(InMemoryFieldBackend())
    await field.deposit("agent-1", "work_claim", 0.8, {"task": "research"})
    pressure = await field.read_pressure("agent-2")
    evaporated = await field.decay()
"""

from stigmergy.backends import FieldBackend, InMemoryFieldBackend, RedisFieldBackend
from stigmergy.decay import (
    DecayStrategy,
    ExponentialDecay,
    LinearDecay,
    StepDecay,
    StochasticDecay,
)
from stigmergy.field import PheromoneField
from stigmergy.scheduler import (
    AgentDispatcher,
    DispatchResult,
    SchedulerMetrics,
    StigmergyScheduler,
    TaskSpec,
)
from stigmergy.signal import Signal

__all__ = [
    "PheromoneField",
    "Signal",
    "FieldBackend",
    "InMemoryFieldBackend",
    "RedisFieldBackend",
    "DecayStrategy",
    "ExponentialDecay",
    "LinearDecay",
    "StepDecay",
    "StochasticDecay",
    "StigmergyScheduler",
    "TaskSpec",
    "DispatchResult",
    "SchedulerMetrics",
    "AgentDispatcher",
]

__version__ = "0.1.0"
