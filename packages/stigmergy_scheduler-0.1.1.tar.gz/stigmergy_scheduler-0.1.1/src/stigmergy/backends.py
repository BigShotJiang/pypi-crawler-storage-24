"""Storage backends for pheromone fields.

Backends are pluggable: InMemoryFieldBackend for testing and single-process
deployments, RedisFieldBackend for production multi-process setups.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any, Protocol

from stigmergy.signal import Signal


class FieldBackend(Protocol):
    """Abstract storage backend for pheromone signals."""

    async def store(self, signal: Signal) -> None:
        """Persist a signal."""
        ...

    async def get(self, signal_id: str) -> Signal | None:
        """Retrieve a single signal by ID."""
        ...

    async def list_signals(
        self,
        signal_types: list[str] | None = None,
        agent_id: str | None = None,
        target_agent_id: str | None = None,
        min_intensity: float | None = None,
    ) -> list[Signal]:
        """List signals matching the given filters."""
        ...

    async def update_intensity(self, signal_id: str, new_intensity: float) -> None:
        """Update a signal's intensity (for decay or amplification)."""
        ...

    async def remove(self, signal_id: str) -> None:
        """Remove a signal (evaporated)."""
        ...

    async def remove_batch(self, signal_ids: list[str]) -> int:
        """Remove multiple signals. Returns count removed."""
        ...

    async def count(self) -> int:
        """Total number of active signals."""
        ...


class InMemoryFieldBackend:
    """In-memory backend for testing and single-process deployments."""

    def __init__(self) -> None:
        self._signals: dict[str, Signal] = {}

    async def store(self, signal: Signal) -> None:
        self._signals[signal.id] = signal

    async def get(self, signal_id: str) -> Signal | None:
        return self._signals.get(signal_id)

    async def list_signals(
        self,
        signal_types: list[str] | None = None,
        agent_id: str | None = None,
        target_agent_id: str | None = None,
        min_intensity: float | None = None,
    ) -> list[Signal]:
        results = list(self._signals.values())

        if signal_types is not None:
            results = [s for s in results if s.signal_type in signal_types]
        if agent_id is not None:
            results = [s for s in results if s.agent_id == agent_id]
        if target_agent_id is not None:
            results = [
                s for s in results
                if s.target_agent_id is None or s.target_agent_id == target_agent_id
            ]
        if min_intensity is not None:
            results = [s for s in results if abs(s.intensity) >= min_intensity]

        return results

    async def update_intensity(self, signal_id: str, new_intensity: float) -> None:
        existing = self._signals.get(signal_id)
        if existing is not None:
            self._signals[signal_id] = existing.with_intensity(new_intensity)

    async def remove(self, signal_id: str) -> None:
        self._signals.pop(signal_id, None)

    async def remove_batch(self, signal_ids: list[str]) -> int:
        removed = 0
        for sid in signal_ids:
            if sid in self._signals:
                del self._signals[sid]
                removed += 1
        return removed

    async def count(self) -> int:
        return len(self._signals)


def _signal_to_dict(signal: Signal) -> dict[str, Any]:
    """Serialize a Signal to a JSON-safe dict."""
    return {
        "id": signal.id,
        "agent_id": signal.agent_id,
        "signal_type": signal.signal_type,
        "intensity": signal.intensity,
        "metadata": signal.metadata,
        "created_at": signal.created_at.isoformat(),
        "target_agent_id": signal.target_agent_id,
    }


def _dict_to_signal(d: dict[str, Any]) -> Signal:
    """Deserialize a dict to a Signal."""
    return Signal(
        id=d["id"],
        agent_id=d["agent_id"],
        signal_type=d["signal_type"],
        intensity=d["intensity"],
        metadata=d.get("metadata", {}),
        created_at=datetime.fromisoformat(d["created_at"]),
        target_agent_id=d.get("target_agent_id"),
    )


class RedisFieldBackend:
    """Redis-backed storage using a hash map for signals.

    Each signal is stored as a JSON value in a Redis hash keyed by signal ID.
    This provides O(1) reads/writes and atomic batch operations.

    Requires: `pip install stigmergy-scheduler[redis]`
    """

    def __init__(self, redis_client: Any, key_prefix: str = "stigmergy:field") -> None:
        self._redis = redis_client
        self._key = f"{key_prefix}:signals"

    async def store(self, signal: Signal) -> None:
        data = json.dumps(_signal_to_dict(signal))
        await self._redis.hset(self._key, signal.id, data)

    async def get(self, signal_id: str) -> Signal | None:
        raw = await self._redis.hget(self._key, signal_id)
        if raw is None:
            return None
        return _dict_to_signal(json.loads(raw))

    async def list_signals(
        self,
        signal_types: list[str] | None = None,
        agent_id: str | None = None,
        target_agent_id: str | None = None,
        min_intensity: float | None = None,
    ) -> list[Signal]:
        all_raw = await self._redis.hvals(self._key)
        results: list[Signal] = []
        for raw in all_raw:
            s = _dict_to_signal(json.loads(raw))
            if signal_types is not None and s.signal_type not in signal_types:
                continue
            if agent_id is not None and s.agent_id != agent_id:
                continue
            if target_agent_id is not None and s.target_agent_id is not None and s.target_agent_id != target_agent_id:
                continue
            if min_intensity is not None and abs(s.intensity) < min_intensity:
                continue
            results.append(s)
        return results

    async def update_intensity(self, signal_id: str, new_intensity: float) -> None:
        raw = await self._redis.hget(self._key, signal_id)
        if raw is None:
            return
        d = json.loads(raw)
        d["intensity"] = max(-1.0, min(1.0, new_intensity))
        await self._redis.hset(self._key, signal_id, json.dumps(d))

    async def remove(self, signal_id: str) -> None:
        await self._redis.hdel(self._key, signal_id)

    async def remove_batch(self, signal_ids: list[str]) -> int:
        if not signal_ids:
            return 0
        return await self._redis.hdel(self._key, *signal_ids)

    async def count(self) -> int:
        return await self._redis.hlen(self._key)
