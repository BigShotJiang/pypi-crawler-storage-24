"""StigmergyScheduler — batteries-included pressure-driven agent scheduling.

Runs a tick loop that decays signals, computes pressure per agent, and
dispatches tasks when pressure exceeds the wake threshold. Handles
dependency resolution, error recovery, and metrics out of the box.

Usage:
    from stigmergy import StigmergyScheduler, TaskSpec, DispatchResult

    scheduler = StigmergyScheduler(wake_threshold=0.4)
    scheduler.register_agent("writer")
    scheduler.register_agent("reviewer")

    async def dispatch(agent_id, task):
        result = await my_llm_call(task.description)
        return DispatchResult(success=True, output=result)

    scheduler.set_dispatcher(dispatch)
    scheduler.add_task(TaskSpec(id="draft", description="Write draft",
                                agent_id="writer", priority=0.8))
    scheduler.add_task(TaskSpec(id="review", description="Review draft",
                                agent_id="reviewer", dependencies=["draft"],
                                priority=0.6))
    await scheduler.run()
"""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field
from typing import Any, Protocol

from stigmergy.backends import InMemoryFieldBackend
from stigmergy.decay import ExponentialDecay
from stigmergy.field import PheromoneField

logger = logging.getLogger(__name__)


@dataclass
class TaskSpec:
    """A task to be dispatched to an agent."""

    id: str
    description: str
    agent_id: str
    priority: float = 0.5
    dependencies: list[str] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class DispatchResult:
    """Result returned by the dispatcher after executing a task."""

    success: bool
    output: Any = None
    error: str | None = None


@dataclass
class SchedulerMetrics:
    """Snapshot of scheduler state."""

    total_ticks: int = 0
    total_dispatches: int = 0
    total_completions: int = 0
    total_failures: int = 0
    pending_tasks: int = 0
    completed_tasks: list[str] = field(default_factory=list)
    running_agents: list[str] = field(default_factory=list)
    agent_pressures: dict[str, float] = field(default_factory=dict)


class AgentDispatcher(Protocol):
    """Protocol for the user-provided dispatch function."""

    async def __call__(self, agent_id: str, task: TaskSpec) -> DispatchResult: ...


class StigmergyScheduler:
    """Pressure-driven task scheduler for multi-agent systems.

    Creates a PheromoneField internally and runs a tick loop that:
    1. Decays all signals (evaporation)
    2. Finds tasks with met dependencies and idle agents
    3. Computes pressure per agent
    4. Dispatches tasks when pressure exceeds the wake threshold
    5. Deposits completion/failure signals to drive dependent tasks
    """

    def __init__(
        self,
        tick_interval: float = 1.0,
        wake_threshold: float = 0.4,
        decay_half_life: float = 300.0,
        evaporation_threshold: float = 0.01,
        field: PheromoneField | None = None,
    ) -> None:
        self._tick_interval = tick_interval
        self._wake_threshold = wake_threshold
        self._field = field or PheromoneField(
            backend=InMemoryFieldBackend(),
            decay_strategy=ExponentialDecay(half_life_seconds=decay_half_life),
            evaporation_threshold=evaporation_threshold,
        )
        self._tasks: dict[str, TaskSpec] = {}
        self._completed: set[str] = set()
        self._running: set[str] = set()
        self._agents: set[str] = set()
        self._dispatcher: AgentDispatcher | None = None
        self._running_task: asyncio.Task[None] | None = None
        self._stop_event = asyncio.Event()
        self._metrics = SchedulerMetrics()

    @property
    def field(self) -> PheromoneField:
        """Access the underlying PheromoneField."""
        return self._field

    def register_agent(self, agent_id: str) -> None:
        """Register an agent that can be woken by pressure."""
        self._agents.add(agent_id)

    def set_dispatcher(self, dispatcher: AgentDispatcher) -> None:
        """Set the function called when an agent is woken to execute a task."""
        self._dispatcher = dispatcher

    async def add_task(self, task: TaskSpec) -> None:
        """Add a task to the queue. Deposits initial pressure for the target agent."""
        self._tasks[task.id] = task
        self._agents.add(task.agent_id)
        await self._field.deposit(
            agent_id="system",
            signal_type="event_pressure",
            intensity=task.priority,
            metadata={"task_id": task.id},
            target_agent_id=task.agent_id,
        )

    async def inject_urgent(self, task: TaskSpec) -> None:
        """Inject a high-priority task for immediate processing."""
        task.priority = max(task.priority, 0.9)
        await self.add_task(task)
        await self._field.deposit(
            agent_id="system",
            signal_type="urgent_event",
            intensity=1.0,
            metadata={"task_id": task.id, "urgent": True},
            target_agent_id=task.agent_id,
        )

    async def run(self) -> None:
        """Run the scheduler until all tasks complete or stop() is called."""
        self._stop_event.clear()
        while not self._stop_event.is_set():
            await self.tick()
            if self.is_complete():
                break
            try:
                await asyncio.wait_for(
                    self._stop_event.wait(), timeout=self._tick_interval
                )
            except asyncio.TimeoutError:
                pass

    def start(self) -> asyncio.Task[None]:
        """Start the scheduler in the background. Returns the asyncio Task."""
        self._stop_event.clear()
        self._running_task = asyncio.create_task(self.run())
        return self._running_task

    def stop(self) -> None:
        """Signal the scheduler to stop after the current tick."""
        self._stop_event.set()

    async def tick(self) -> None:
        """Single tick: decay, evaluate pressure, dispatch tasks."""
        self._metrics.total_ticks += 1
        await self._field.decay()

        if not self._dispatcher:
            return

        available = self._available_tasks()
        available.sort(key=lambda t: t.priority, reverse=True)

        for task in available:
            if task.agent_id in self._running:
                continue

            pressure = await self._field.read_pressure(task.agent_id)
            pressure += 0.3  # time pressure for idle agents

            if pressure >= self._wake_threshold:
                self._running.add(task.agent_id)
                self._metrics.total_dispatches += 1
                self._metrics.running_agents = list(self._running)
                asyncio.create_task(self._dispatch(task))

        self._metrics.pending_tasks = sum(
            1 for t in self._tasks.values() if t.id not in self._completed
        )
        self._metrics.agent_pressures = {
            agent: await self._field.read_pressure(agent)
            for agent in self._agents
        }

    def _available_tasks(self) -> list[TaskSpec]:
        """Tasks with met dependencies, not completed, agent not busy."""
        result = []
        for task in self._tasks.values():
            if task.id in self._completed:
                continue
            if task.agent_id in self._running:
                continue
            if not all(d in self._completed for d in task.dependencies):
                continue
            result.append(task)
        return result

    async def _dispatch(self, task: TaskSpec) -> None:
        """Execute a task via the dispatcher and handle the result."""
        try:
            result = await self._dispatcher(task.agent_id, task)

            if result.success:
                self._completed.add(task.id)
                self._metrics.total_completions += 1
                self._metrics.completed_tasks.append(task.id)
                await self._field.deposit(
                    agent_id=task.agent_id,
                    signal_type="task_complete",
                    intensity=0.6,
                    metadata={"task_id": task.id},
                )
                logger.info("Task %s completed by %s", task.id, task.agent_id)
            else:
                self._metrics.total_failures += 1
                await self._field.deposit(
                    agent_id="system",
                    signal_type="failure_pressure",
                    intensity=0.9,
                    metadata={"task_id": task.id, "error": result.error},
                    target_agent_id=task.agent_id,
                )
                logger.warning(
                    "Task %s failed on %s: %s", task.id, task.agent_id, result.error
                )
        except Exception as exc:
            self._metrics.total_failures += 1
            await self._field.deposit(
                agent_id="system",
                signal_type="failure_pressure",
                intensity=0.9,
                metadata={"task_id": task.id, "error": str(exc)},
                target_agent_id=task.agent_id,
            )
            logger.exception("Task %s raised exception on %s", task.id, task.agent_id)
        finally:
            self._running.discard(task.agent_id)
            self._metrics.running_agents = list(self._running)

    def is_complete(self) -> bool:
        """True when all tasks have completed."""
        return bool(self._tasks) and all(
            t.id in self._completed for t in self._tasks.values()
        )

    def get_metrics(self) -> SchedulerMetrics:
        """Return a snapshot of current metrics."""
        return SchedulerMetrics(
            total_ticks=self._metrics.total_ticks,
            total_dispatches=self._metrics.total_dispatches,
            total_completions=self._metrics.total_completions,
            total_failures=self._metrics.total_failures,
            pending_tasks=self._metrics.pending_tasks,
            completed_tasks=list(self._metrics.completed_tasks),
            running_agents=list(self._metrics.running_agents),
            agent_pressures=dict(self._metrics.agent_pressures),
        )
