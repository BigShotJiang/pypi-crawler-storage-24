"""Decay strategies for pheromone evaporation.

In biological stigmergy, pheromones evaporate over time. This creates
essential dynamics: recently-reinforced paths (popular, successful) stay
strong while abandoned paths fade. The four classical self-organisation
mechanisms from arXiv:2601.08129 map directly:

- Positive feedback: amplify() increases intensity
- Negative feedback: decay reduces intensity over time
- Randomness: stochastic decay adds exploration pressure
- Multiple interactions: many agents reading/writing the same field
"""

from __future__ import annotations

import math
import random
from typing import Protocol

from stigmergy.signal import Signal


class DecayStrategy(Protocol):
    """Protocol for signal decay computation."""

    def compute(self, signal: Signal, elapsed_seconds: float) -> float:
        """Return the new intensity after decay. Return 0.0 to evaporate."""
        ...


class ExponentialDecay:
    """Exponential decay: intensity *= half_life_factor^(elapsed / half_life).

    The default and most natural model. Signals lose half their intensity
    every `half_life_seconds`.
    """

    def __init__(self, half_life_seconds: float = 3600.0) -> None:
        if half_life_seconds <= 0:
            raise ValueError("half_life_seconds must be positive")
        self.half_life_seconds = half_life_seconds

    def compute(self, signal: Signal, elapsed_seconds: float) -> float:
        factor = math.pow(0.5, elapsed_seconds / self.half_life_seconds)
        return signal.intensity * factor


class LinearDecay:
    """Linear decay: intensity decreases by a fixed rate per second.

    Useful for signals that should have a hard expiration time.
    """

    def __init__(self, rate_per_second: float = 0.001) -> None:
        self.rate_per_second = rate_per_second

    def compute(self, signal: Signal, elapsed_seconds: float) -> float:
        reduction = self.rate_per_second * elapsed_seconds
        if signal.intensity > 0:
            return max(0.0, signal.intensity - reduction)
        else:
            return min(0.0, signal.intensity + reduction)


class StepDecay:
    """Step decay: full intensity until TTL expires, then instant evaporation.

    Useful for time-boxed signals like work claims that should
    either be active or gone.
    """

    def __init__(self, ttl_seconds: float = 3600.0) -> None:
        self.ttl_seconds = ttl_seconds

    def compute(self, signal: Signal, elapsed_seconds: float) -> float:
        if elapsed_seconds >= self.ttl_seconds:
            return 0.0
        return signal.intensity


class StochasticDecay:
    """Stochastic decay: exponential decay with random noise.

    Implements the "randomness" mechanism from classical self-organisation.
    The noise prevents the system from getting stuck in local optima
    by occasionally letting weaker signals persist or stronger ones fade.
    """

    def __init__(
        self,
        half_life_seconds: float = 3600.0,
        noise_factor: float = 0.1,
    ) -> None:
        self._base = ExponentialDecay(half_life_seconds)
        self.noise_factor = noise_factor

    def compute(self, signal: Signal, elapsed_seconds: float) -> float:
        base_value = self._base.compute(signal, elapsed_seconds)
        noise = random.gauss(0, self.noise_factor * abs(base_value))
        result = base_value + noise
        # Clamp to original sign direction
        if signal.intensity > 0:
            return max(0.0, min(1.0, result))
        else:
            return max(-1.0, min(0.0, result))
