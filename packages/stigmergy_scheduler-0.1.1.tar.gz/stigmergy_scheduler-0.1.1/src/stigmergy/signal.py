"""Signal — the atomic unit of stigmergic communication.

A Signal is a pheromone trace deposited by an agent into a shared field.
Signals have intensity that decays over time (evaporation), creating
temporal dynamics where recent, reinforced signals dominate while
stale ones fade — mirroring ant colony pheromone trails.

Reference: arXiv:2601.08129 — Pressure-field coordination for multi-agent systems.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any


@dataclass(frozen=True)
class Signal:
    """An immutable pheromone signal in the field."""

    id: str = field(default_factory=lambda: uuid.uuid4().hex[:12])
    agent_id: str = ""
    signal_type: str = ""
    intensity: float = 1.0  # -1.0 (repulsion) to 1.0 (attraction)
    metadata: dict[str, Any] = field(default_factory=dict)
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    target_agent_id: str | None = None  # If set, only this agent sees pressure from it

    def __post_init__(self) -> None:
        if not -1.0 <= self.intensity <= 1.0:
            raise ValueError(f"intensity must be in [-1.0, 1.0], got {self.intensity}")

    def with_intensity(self, new_intensity: float) -> Signal:
        """Return a copy with updated intensity."""
        return Signal(
            id=self.id,
            agent_id=self.agent_id,
            signal_type=self.signal_type,
            intensity=max(-1.0, min(1.0, new_intensity)),
            metadata=self.metadata,
            created_at=self.created_at,
            target_agent_id=self.target_agent_id,
        )

    @property
    def age_seconds(self) -> float:
        """Seconds since this signal was created."""
        return (datetime.now(timezone.utc) - self.created_at).total_seconds()

    @property
    def is_attraction(self) -> bool:
        return self.intensity > 0

    @property
    def is_repulsion(self) -> bool:
        return self.intensity < 0
