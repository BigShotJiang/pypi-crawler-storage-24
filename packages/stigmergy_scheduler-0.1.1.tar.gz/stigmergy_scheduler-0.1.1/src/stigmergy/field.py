"""PheromoneField — the core coordination primitive.

A shared state space where agents deposit and read signals. The field
implements the four classical self-organisation mechanisms from
arXiv:2601.08129:

1. **Positive feedback** — `amplify()` increases signal intensity when
   the signal proves valuable (reinforcement).
2. **Negative feedback** — `decay()` reduces intensity over time
   (evaporation), preventing stale signals from dominating.
3. **Randomness** — StochasticDecay adds noise to prevent local optima.
4. **Multiple interactions** — many agents reading/writing the same field
   creates emergent coordination without explicit messaging.

Usage:
    field = PheromoneField(InMemoryFieldBackend())
    await field.deposit("agent-1", "work_claim", 0.8, {"task": "research"})
    pressure = await field.read_pressure("agent-2")
    evaporated = await field.decay()
"""

from __future__ import annotations

import logging
from typing import Any

from stigmergy.backends import FieldBackend
from stigmergy.decay import DecayStrategy, ExponentialDecay
from stigmergy.signal import Signal

logger = logging.getLogger(__name__)

# Intensity below this threshold is considered evaporated
EVAPORATION_THRESHOLD = 0.01

# Maximum amplification factor to prevent runaway positive feedback
MAX_AMPLIFICATION = 3.0


class PheromoneField:
    """A shared pheromone field for stigmergic agent coordination."""

    def __init__(
        self,
        backend: FieldBackend,
        decay_strategy: DecayStrategy | None = None,
        evaporation_threshold: float = EVAPORATION_THRESHOLD,
        max_amplification: float = MAX_AMPLIFICATION,
    ) -> None:
        self._backend = backend
        self._decay_strategy = decay_strategy or ExponentialDecay()
        self._evaporation_threshold = evaporation_threshold
        self._max_amplification = max_amplification

    async def deposit(
        self,
        agent_id: str,
        signal_type: str,
        intensity: float = 1.0,
        metadata: dict[str, Any] | None = None,
        target_agent_id: str | None = None,
    ) -> Signal:
        """Deposit a pheromone signal into the field.

        Args:
            agent_id: Who is depositing the signal.
            signal_type: Category (e.g. "work_claim", "need_help", "insight_deposit").
            intensity: Strength from -1.0 (repulsion) to 1.0 (attraction).
            metadata: Arbitrary data attached to the signal.
            target_agent_id: If set, only this agent receives pressure from it.

        Returns:
            The created Signal.
        """
        signal = Signal(
            agent_id=agent_id,
            signal_type=signal_type,
            intensity=intensity,
            metadata=metadata or {},
            target_agent_id=target_agent_id,
        )
        await self._backend.store(signal)
        logger.debug(
            "Deposited signal %s: type=%s intensity=%.2f by %s",
            signal.id, signal_type, intensity, agent_id,
        )
        return signal

    async def read(
        self,
        agent_id: str | None = None,
        signal_types: list[str] | None = None,
        exclude_own: bool = False,
        min_intensity: float | None = None,
    ) -> list[Signal]:
        """Read signals from the field.

        Args:
            agent_id: If provided with exclude_own=True, excludes this agent's signals.
                      If provided, also filters targeted signals to show only those
                      targeting this agent (or untargeted ones).
            signal_types: Filter by signal type(s).
            exclude_own: If True, exclude signals deposited by agent_id.
            min_intensity: Minimum absolute intensity to include.

        Returns:
            List of matching signals, sorted by intensity (strongest first).
        """
        signals = await self._backend.list_signals(
            signal_types=signal_types,
            target_agent_id=agent_id,
            min_intensity=min_intensity,
        )

        if exclude_own and agent_id:
            signals = [s for s in signals if s.agent_id != agent_id]

        return sorted(signals, key=lambda s: abs(s.intensity), reverse=True)

    async def read_pressure(
        self,
        agent_id: str,
        signal_types: list[str] | None = None,
        weights: dict[str, float] | None = None,
    ) -> float:
        """Compute aggregate wake pressure for an agent.

        Reads all signals visible to this agent and sums their intensities,
        optionally weighted by signal type. This is the core mechanism for
        self-scheduling: when pressure exceeds a threshold, the agent wakes.

        Args:
            agent_id: The agent to compute pressure for.
            signal_types: Only consider these signal types. None = all.
            weights: Optional {signal_type: weight} multipliers. Default 1.0.

        Returns:
            Aggregate pressure value (can be negative if repulsion dominates).
        """
        signals = await self._backend.list_signals(
            signal_types=signal_types,
            target_agent_id=agent_id,
        )

        # Exclude agent's own signals from pressure calculation
        signals = [s for s in signals if s.agent_id != agent_id]

        weights = weights or {}
        total = 0.0
        for s in signals:
            w = weights.get(s.signal_type, 1.0)
            total += s.intensity * w

        return total

    async def amplify(self, signal_id: str, factor: float) -> Signal | None:
        """Positive feedback: amplify a signal that proved valuable.

        The amplification is capped at `max_amplification` times the original
        intensity to prevent runaway positive feedback loops (AMAGF safety).

        Args:
            signal_id: Signal to amplify.
            factor: Multiplier (>1.0 to amplify, <1.0 to dampen).

        Returns:
            The updated Signal, or None if not found.
        """
        signal = await self._backend.get(signal_id)
        if signal is None:
            return None

        new_intensity = signal.intensity * factor
        # Cap amplification
        max_abs = abs(signal.intensity) * self._max_amplification
        if abs(new_intensity) > max_abs:
            new_intensity = max_abs if new_intensity > 0 else -max_abs
        new_intensity = max(-1.0, min(1.0, new_intensity))

        await self._backend.update_intensity(signal_id, new_intensity)
        updated = signal.with_intensity(new_intensity)
        logger.debug(
            "Amplified signal %s: %.2f -> %.2f (factor=%.2f)",
            signal_id, signal.intensity, new_intensity, factor,
        )
        return updated

    async def decay(self) -> int:
        """Apply decay to all signals. Evaporate those below threshold.

        This should be called periodically (e.g., every tick of the
        swarm scheduler) to maintain temporal dynamics.

        Returns:
            Number of signals evaporated (removed).
        """
        all_signals = await self._backend.list_signals()
        to_remove: list[str] = []

        for signal in all_signals:
            elapsed = signal.age_seconds
            new_intensity = self._decay_strategy.compute(signal, elapsed)

            if abs(new_intensity) < self._evaporation_threshold:
                to_remove.append(signal.id)
            elif new_intensity != signal.intensity:
                await self._backend.update_intensity(signal.id, new_intensity)

        removed = 0
        if to_remove:
            removed = await self._backend.remove_batch(to_remove)
            logger.debug("Evaporated %d signals", removed)

        return removed

    async def clear_agent(self, agent_id: str) -> int:
        """Remove all signals deposited by a specific agent.

        Useful when an agent completes work and wants to clear its claims.
        """
        signals = await self._backend.list_signals(agent_id=agent_id)
        ids = [s.id for s in signals]
        return await self._backend.remove_batch(ids) if ids else 0

    async def signal_count(self) -> int:
        """Total number of active signals in the field."""
        return await self._backend.count()
