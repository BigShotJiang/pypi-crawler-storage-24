from .schema import RedisInfo
from fastpluggy.core.widgets import CardWidget


def make_memory_usage_card(info: RedisInfo) -> CardWidget:
    """
    Returns a CardWidget showing:
      • used_memory_human / total_system_memory_human
      • a Bootstrap progress bar indicating percent used.
      Tooltip (via title="…") combines descriptions of used_memory_human & total_system_memory_human.
    """
    # 1) Compute percentage
    used_bytes = info.used_memory or 0
    total_bytes = info.total_system_memory or 1
    pct_used = (used_bytes / total_bytes) * 100

    # 2) Pull descriptions directly from RedisInfo.model_fields
    desc_used = RedisInfo.model_fields['used_memory_human'].description or ""
    desc_total = RedisInfo.model_fields['total_system_memory_human'].description or ""

    return CardWidget(
        subheader="Memory Usage",
        value=f"{info.used_memory_human} / {info.total_system_memory_human}",
        content= f"{desc_used} | {desc_total}",
        progress=round(pct_used, 1),
        progress_color="blue",
    )


