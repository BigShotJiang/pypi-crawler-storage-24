import numpy as np
from phantom_operator.array import AbsentArray


def _ensure_array(x):
    if isinstance(x, AbsentArray):
        return x
    from absence_calculator import Void
    if isinstance(x, Void):
        return AbsentArray(np.array([0.0]), np.array([-1], dtype=np.int8))
    if isinstance(x, (int, float)):
        return AbsentArray(np.array([x]), np.array([0], dtype=np.int8))
    if isinstance(x, list):
        return AbsentArray(x)
    raise TypeError(f"Cannot convert {type(x).__name__} to AbsentArray")


def _broadcast(a, b):
    a = _ensure_array(a)
    b = _ensure_array(b)
    if a.shape != b.shape:
        try:
            v = np.broadcast_shapes(a.shape, b.shape)
            av = np.broadcast_to(a._values, v).copy()
            as_ = np.broadcast_to(a._states, v).copy()
            bv = np.broadcast_to(b._values, v).copy()
            bs = np.broadcast_to(b._states, v).copy()
            a = AbsentArray(av, as_)
            b = AbsentArray(bv, bs)
        except ValueError:
            raise ValueError(f"Cannot broadcast shapes {a.shape} and {b.shape}")
    return a, b


def arr_add(x, y):
    x, y = _broadcast(x, y)
    x_void = x._states == -1
    y_void = y._states == -1
    both_void = x_void & y_void
    result_values = np.zeros_like(x._values)
    result_states = np.zeros(x._values.shape, dtype=np.int8)
    result_values[both_void] = 0
    result_states[both_void] = -1
    only_x_void = x_void & ~y_void
    result_values[only_x_void] = y._values[only_x_void]
    result_states[only_x_void] = y._states[only_x_void]
    only_y_void = y_void & ~x_void
    result_values[only_y_void] = x._values[only_y_void]
    result_states[only_y_void] = x._states[only_y_void]
    neither_void = ~x_void & ~y_void
    same = (x._states == y._states) & neither_void
    diff = (x._states != y._states) & neither_void
    result_values[same] = x._values[same] + y._values[same]
    result_states[same] = x._states[same]
    if np.any(diff):
        from absence_calculator import add as pt_add, AbsentNumber
        for idx in zip(*np.where(diff)):
            xn = AbsentNumber(x._values[idx], int(x._states[idx])) if x._values[idx] != 0 else AbsentNumber(1, 1)
            yn = AbsentNumber(y._values[idx], int(y._states[idx])) if y._values[idx] != 0 else AbsentNumber(1, 1)
            r = pt_add(xn, yn)
            result_values[idx] = r.left.value if hasattr(r, 'left') else (r.value if hasattr(r, 'value') else 0)
            result_states[idx] = 0
    return AbsentArray(result_values, result_states.astype(np.int8))


def arr_subtract(x, y):
    x, y = _broadcast(x, y)
    x_void = x._states == -1
    y_void = y._states == -1
    both_void = x_void & y_void
    result_values = np.zeros_like(x._values)
    result_states = np.zeros(x._values.shape, dtype=np.int8)
    result_values[both_void] = 0
    result_states[both_void] = -1
    only_y_void = y_void & ~x_void
    result_values[only_y_void] = x._values[only_y_void]
    result_states[only_y_void] = x._states[only_y_void]
    only_x_void = x_void & ~y_void
    result_values[only_x_void] = 0
    result_states[only_x_void] = -1
    neither_void = ~x_void & ~y_void
    same = (x._states == y._states) & neither_void
    equal_vals = (x._values == y._values) & same
    normal = same & ~equal_vals
    result_values[equal_vals] = 0
    result_states[equal_vals] = -1
    result_values[normal] = x._values[normal] - y._values[normal]
    result_states[normal] = x._states[normal]
    diff = (x._states != y._states) & neither_void
    if np.any(diff):
        for idx in zip(*np.where(diff)):
            result_values[idx] = x._values[idx]
            result_states[idx] = x._states[idx]
    return AbsentArray(result_values, result_states.astype(np.int8))


def arr_multiply(x, y):
    x, y = _broadcast(x, y)
    x_void = x._states == -1
    y_void = y._states == -1
    any_void = x_void | y_void
    result_values = x._values * y._values
    result_states = ((x._states.astype(np.int16) + y._states.astype(np.int16)) % 2).astype(np.int8)
    result_values[any_void] = 0
    result_states[any_void] = -1
    return AbsentArray(result_values, result_states)


def arr_divide(x, y):
    x, y = _broadcast(x, y)
    x_void = x._states == -1
    y_void = y._states == -1
    any_void = x_void | y_void
    with np.errstate(divide='ignore', invalid='ignore'):
        result_values = np.where((y._values != 0) & ~any_void, x._values / y._values, 0)
    result_values = np.round(result_values, 10)
    int_mask = result_values == np.floor(result_values)
    result_values = np.where(int_mask, np.floor(result_values), result_values)
    result_states = ((x._states.astype(np.int16) + y._states.astype(np.int16)) % 2).astype(np.int8)
    result_values[any_void] = 0
    result_states[any_void] = -1
    return AbsentArray(result_values, result_states)


def arr_erase(x, y):
    x, y = _broadcast(x, y)
    x_void = x._states == -1
    y_void = y._states == -1
    neither_void = ~x_void & ~y_void
    same = (x._states == y._states) & neither_void
    remainder_vals = np.zeros_like(x._values)
    remainder_states = np.full(x._values.shape, -1, dtype=np.int8)
    erased_vals = np.zeros_like(x._values)
    erased_states = np.full(x._values.shape, -1, dtype=np.int8)
    excess_vals = np.zeros_like(x._values)
    excess_states = np.full(x._values.shape, -1, dtype=np.int8)
    has_remainder = same & (x._values > y._values)
    remainder_vals[has_remainder] = x._values[has_remainder] - y._values[has_remainder]
    remainder_states[has_remainder] = x._states[has_remainder]
    erased_vals[same] = np.minimum(x._values[same], y._values[same])
    erased_states[same] = ((y._states[same].astype(np.int16) + 1) % 2).astype(np.int8)
    has_excess = same & (y._values > x._values)
    excess_vals[has_excess] = y._values[has_excess] - x._values[has_excess]
    excess_states[has_excess] = ((y._states[has_excess].astype(np.int16) + 1) % 2).astype(np.int8)
    x_only = x_void & ~y_void
    remainder_vals[x_only] = 0
    remainder_states[x_only] = -1
    y_only = y_void & ~x_void
    remainder_vals[y_only] = x._values[y_only]
    remainder_states[y_only] = x._states[y_only]
    return {
        'remainder': AbsentArray(remainder_vals, remainder_states),
        'erased': AbsentArray(erased_vals, erased_states),
        'excess': AbsentArray(excess_vals, excess_states),
    }


def arr_toggle(arr):
    arr = _ensure_array(arr)
    void_mask = arr._states == -1
    new_states = ((arr._states.astype(np.int16) + 1) % 2).astype(np.int8)
    new_states[void_mask] = -1
    return AbsentArray(arr._values.copy(), new_states)


def arr_combine(x, y):
    x, y = _broadcast(x, y)
    x_void = x._states == -1
    y_void = y._states == -1
    both_void = x_void & y_void
    result_values = np.zeros_like(x._values)
    result_states = np.zeros(x._values.shape, dtype=np.int8)
    result_values[both_void] = 0
    result_states[both_void] = -1
    only_x_void = x_void & ~y_void
    result_values[only_x_void] = 1
    result_states[only_x_void] = y._states[only_x_void]
    only_y_void = y_void & ~x_void
    result_values[only_y_void] = 1
    result_states[only_y_void] = x._states[only_y_void]
    neither_void = ~x_void & ~y_void
    same = (x._states == y._states) & neither_void
    diff = (x._states != y._states) & neither_void
    result_values[same] = 2
    result_states[same] = x._states[same]
    result_values[diff] = 1
    result_states[diff] = 0
    return AbsentArray(result_values, result_states.astype(np.int8))


def arr_compare(x, y):
    x, y = _broadcast(x, y)
    x_void = x._states == -1
    y_void = y._states == -1
    x_present = (x._states == 0) & ~x_void
    y_present = (y._states == 0) & ~y_void
    x_pcount = np.where(x_present, x._values, 0)
    y_pcount = np.where(y_present, y._values, 0)
    diff = y_pcount - x_pcount
    result_values = np.abs(diff)
    result_states = np.where(diff > 0, 0, np.where(diff < 0, 1, -1)).astype(np.int8)
    return AbsentArray(result_values, result_states)


def arr_where(arr, condition_fn=None):
    arr = _ensure_array(arr)
    if condition_fn is None:
        return np.where(arr._states == 0)
    mask = condition_fn(arr._values, arr._states)
    return np.where(mask)


def arr_count_present(arr):
    arr = _ensure_array(arr)
    return int(np.sum(arr._states == 0))


def arr_present_mask(arr):
    arr = _ensure_array(arr)
    return arr._states == 0


def arr_absent_mask(arr):
    arr = _ensure_array(arr)
    return arr._states == 1


def arr_void_mask(arr):
    arr = _ensure_array(arr)
    return arr._states == -1


def arr_trace(fn, start, end, order=None):
    from absence_calculator import trace as pt_trace, AbsentNumber, Void, Unresolved
    results = pt_trace(fn, start, end, order=order)
    vals = []
    sts = []
    for r in results:
        if isinstance(r, Void):
            vals.append(0)
            sts.append(-1)
        elif isinstance(r, Unresolved):
            if hasattr(r, 'left') and isinstance(r.left, AbsentNumber):
                vals.append(r.left.value)
                sts.append(r.left.absence_level)
            else:
                vals.append(0)
                sts.append(0)
        elif isinstance(r, AbsentNumber):
            if r.value == 1 and r.absence_level == 1:
                vals.append(0)
                sts.append(0)
            else:
                vals.append(r.value)
                sts.append(r.absence_level)
        elif hasattr(r, 'remainder'):
            rem = r.remainder
            if isinstance(rem, Void):
                vals.append(0)
                sts.append(-1)
            elif isinstance(rem, AbsentNumber):
                vals.append(rem.value)
                sts.append(rem.absence_level)
            else:
                vals.append(0)
                sts.append(0)
        elif hasattr(r, 'value'):
            vals.append(r.value)
            sts.append(getattr(r, 'absence_level', 0))
        else:
            try:
                vals.append(float(r))
                sts.append(0)
            except (TypeError, ValueError):
                vals.append(0)
                sts.append(-1)
    return AbsentArray(np.array(vals, dtype=np.float64), np.array(sts, dtype=np.int8))
