import numpy as np
from absence_calculator import AbsentNumber, Void, VOID


VOID_STATE = np.int8(-1)


class AbsentArray:
    def __init__(self, values, states=None):
        if isinstance(values, AbsentArray):
            self._values = values._values.copy()
            self._states = values._states.copy()
            return

        if isinstance(values, list):
            vals = []
            sts = []
            for item in values:
                if isinstance(item, Void):
                    vals.append(0)
                    sts.append(-1)
                elif isinstance(item, AbsentNumber):
                    v = item.value
                    if v == 1 and item.absence_level == 1:
                        v = 0
                        sts.append(0)
                    else:
                        sts.append(item.absence_level)
                    vals.append(v if not (item.value == 1 and item.absence_level == 1) else 0)
                elif isinstance(item, (int, float)):
                    vals.append(item)
                    sts.append(0)
                elif isinstance(item, list):
                    sub = AbsentArray(item)
                    vals.append(sub._values)
                    sts.append(sub._states)
                else:
                    raise TypeError(f"Cannot convert {type(item).__name__} to AbsentArray element")
            self._values = np.array(vals, dtype=np.float64)
            if states is not None:
                self._states = np.array(states, dtype=np.int8)
            else:
                self._states = np.array(sts, dtype=np.int8)
            return

        if isinstance(values, np.ndarray):
            self._values = values.astype(np.float64)
            if states is not None:
                if isinstance(states, np.ndarray):
                    self._states = states.astype(np.int8)
                else:
                    self._states = np.full(values.shape, states, dtype=np.int8)
            else:
                self._states = np.zeros(values.shape, dtype=np.int8)
            return

        raise TypeError(f"Cannot create AbsentArray from {type(values).__name__}")

    @property
    def values(self):
        return self._values

    @property
    def states(self):
        return self._states

    @property
    def shape(self):
        return self._values.shape

    @property
    def size(self):
        return self._values.size

    @property
    def ndim(self):
        return self._values.ndim

    @property
    def dtype(self):
        return self._values.dtype

    def __len__(self):
        return len(self._values)

    def __getitem__(self, key):
        v = self._values[key]
        s = self._states[key]
        if isinstance(v, np.ndarray):
            return AbsentArray(v, s)
        if int(s) == -1:
            return VOID
        return AbsentNumber(v if v != 0 else 1, int(s) if v != 0 else 1)

    def __setitem__(self, key, value):
        if isinstance(value, Void):
            self._values[key] = 0
            self._states[key] = -1
        elif isinstance(value, AbsentNumber):
            if value.value == 1 and value.absence_level == 1:
                self._values[key] = 0
                self._states[key] = 0
            else:
                self._values[key] = value.value
                self._states[key] = value.absence_level
        elif isinstance(value, AbsentArray):
            self._values[key] = value._values
            self._states[key] = value._states
        elif isinstance(value, (int, float)):
            self._values[key] = value
            self._states[key] = 0
        else:
            raise TypeError(f"Cannot assign {type(value).__name__} to AbsentArray")

    def to_list(self):
        flat_vals = self._values.ravel()
        flat_states = self._states.ravel()
        result = []
        for v, s in zip(flat_vals, flat_states):
            if int(s) == -1:
                result.append(VOID)
            elif v == 0:
                result.append(AbsentNumber(1, 1))
            else:
                result.append(AbsentNumber(v, int(s)))
        if self.ndim == 1:
            return result
        shape = self.shape
        def reshape(flat, dims):
            if len(dims) == 1:
                return flat[:dims[0]]
            chunk = 1
            for d in dims[1:]:
                chunk *= d
            return [reshape(flat[i*chunk:(i+1)*chunk], dims[1:]) for i in range(dims[0])]
        return reshape(result, list(shape))

    def copy(self):
        return AbsentArray(self._values.copy(), self._states.copy())

    def reshape(self, *shape):
        if len(shape) == 1 and isinstance(shape[0], tuple):
            shape = shape[0]
        return AbsentArray(self._values.reshape(shape), self._states.reshape(shape))

    def flatten(self):
        return AbsentArray(self._values.ravel().copy(), self._states.ravel().copy())

    def _format_element(self, v, s):
        if s == -1:
            return "void"
        if v == 0:
            return "0"
        if isinstance(v, float) and v == int(v):
            v = int(v)
        if s == 0:
            return str(v)
        return f"{v}(0)"

    def __repr__(self):
        if self.ndim == 1:
            items = [self._format_element(self._values[i], self._states[i]) for i in range(len(self._values))]
            return f"AbsentArray([{', '.join(items)}])"
        return f"AbsentArray(shape={self.shape})"

    def __eq__(self, other):
        if isinstance(other, AbsentArray):
            return np.array_equal(self._values, other._values) and np.array_equal(self._states, other._states)
        return False

    @property
    def void_mask(self):
        return self._states == -1


def absent_array(data, states=None):
    return AbsentArray(data, states)


def zeros(shape, state=0):
    if isinstance(shape, int):
        shape = (shape,)
    vals = np.zeros(shape, dtype=np.float64)
    sts = np.full(shape, state, dtype=np.int8)
    return AbsentArray(vals, sts)


def ones(shape, state=0):
    if isinstance(shape, int):
        shape = (shape,)
    vals = np.ones(shape, dtype=np.float64)
    sts = np.full(shape, state, dtype=np.int8)
    return AbsentArray(vals, sts)


def full(shape, value, state=0):
    if isinstance(shape, int):
        shape = (shape,)
    vals = np.full(shape, value, dtype=np.float64)
    sts = np.full(shape, state, dtype=np.int8)
    return AbsentArray(vals, sts)


def empty(shape, state=0):
    if isinstance(shape, int):
        shape = (shape,)
    vals = np.empty(shape, dtype=np.float64)
    sts = np.full(shape, state, dtype=np.int8)
    return AbsentArray(vals, sts)


def voids(shape):
    if isinstance(shape, int):
        shape = (shape,)
    vals = np.zeros(shape, dtype=np.float64)
    sts = np.full(shape, -1, dtype=np.int8)
    return AbsentArray(vals, sts)


def arange(start, stop=None, step=1, state=0):
    if stop is None:
        stop = start
        start = 1
    vals = np.arange(start, stop + 1, step, dtype=np.float64)
    sts = np.full(vals.shape, state, dtype=np.int8)
    return AbsentArray(vals, sts)
