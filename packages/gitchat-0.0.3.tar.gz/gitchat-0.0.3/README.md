# GitChat
> Proof-of-work realtime chat, using only `git` as a transport

This is just a joy project, be careful!

## Requirements
- Git
- Python >= 3.12
- Github/Gitlab/Gitverse account

## Usage
1. Install package
```bash
# From PyPI
pip install gitchat

# From source
git clone <this repo>
cd gitchat
pip install .
```
2. Create empty git repo using any git hosting and clone it
3. Configure peers once (on both sides) and enter chat:
```bash
# Configuring repo
gitchat config -r <repo path> -u <username>

# Starting chat
gitchat chat -r <repo path> -u <username> -d <check interval in secs>
```
4. Add handler (to process messages)
```bash
# handler.py (example)
import os

def handler(message):
    if message["data"].startswith("%sh"):
        cmd = message["data"][4:]
        print(f"[*] Executing '{cmd}' ...")
        os.system(cmd)

# In shell
gitchat chat -u <username> -r <repo path> --handler handler.py
```
> your py file must have function `handler` that accepts message
