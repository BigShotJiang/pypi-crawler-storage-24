"""
Real path test: ModelScope download + load checkpoint + one forward.
Requires network; run with: uv run python -m pytest tests/test_real_model_forward.py -v
"""
import pytest
import torch
from pathlib import Path

from speakerlab.process.processor import FBank
from speakerlab.utils.builder import dynamic_import


@pytest.mark.real
def test_modelscope_download_load_forward():
    pytest.importorskip("modelscope")
    from modelscope.hub.snapshot_download import snapshot_download
    model_id = "iic/speech_eres2net_large_sv_zh-cn_3dspeaker_16k"
    revision = "v1.0.0"
    model_file = "eres2net_large_model.ckpt"
    model_obj = "speakerlab.models.eres2net.ERes2Net.ERes2Net"
    model_args = {"feat_dim": 80, "embedding_size": 512, "m_channels": 64}

    cache_dir = snapshot_download(model_id, revision=revision)
    model_path = Path(cache_dir) / model_file
    assert model_path.is_file(), f"Missing {model_path}"

    state = torch.load(model_path, map_location="cpu")
    ModelCls = dynamic_import(model_obj)
    model = ModelCls(**model_args)
    model.load_state_dict(state, strict=True)
    model.eval()

    fbank = FBank(n_mels=80, sample_rate=16000, mean_nor=True)
    dummy_wav = torch.randn(1, 16000 * 2)
    feat = fbank(dummy_wav)
    x = feat.unsqueeze(0)
    with torch.no_grad():
        emb = model(x)
    assert emb.dim() == 2 and emb.shape[1] == model_args["embedding_size"]
