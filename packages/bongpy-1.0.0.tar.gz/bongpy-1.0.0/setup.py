from setuptools import setup

setup(
    name='bongpy', 
    version='1.0.0',
    description='The Official Benglish Programming Language Engine, developed by Ronit.',
    author='Ronit',
    py_modules=['bongpy_engine'],
    entry_points={
        'console_scripts': [
            'bongpy=bongpy_engine:main',
        ],
    },
)