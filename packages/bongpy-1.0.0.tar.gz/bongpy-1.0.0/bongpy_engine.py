import re
import sys

# The Official Bongpy Dictionary
BENGLISH_DICT = {
    r'\btol\b': 'import',
    r'\bhisebe\b': 'as',
    r'\btheke\b': 'from',
    r'\bbol\b': 'print',
    r'\bjodi\b': 'if',
    r'\bta_na_hole\b': 'elif',
    r'\bsesh_mesh\b': 'else',
    r'\bar\b': 'and',
    r'\bba\b': 'or',
    r'\bthik\b': 'True',
    r'\bbhul\b': 'False',
    r'\bghora\b': 'for',
    r'\bjotokhon\b': 'while',
    r'\bdara\b': 'break',
    r'\bchaliye_ja\b': 'continue',
    r'\bbana\b': 'def',
    r'\bjinish\b': 'class',
    r'\bde\b': 'return',
    r'\bchere_de\b': 'pass',
    r'\bchesta_kor\b': 'try',
    r'\bna_hole\b': 'except'
}

def run_bongpy_code(file_name):
    try:
        with open(file_name, 'r') as file:
            code = file.read()
    except FileNotFoundError:
        print("Bhai, tui je namer file khunjchis, sheta toh ekhane nei! Nam thik kore dekh.")
        return

    # Translate bongpy to Python
    for benglish_word, python_word in BENGLISH_DICT.items():
        code = re.sub(benglish_word, python_word, code)

    # Execute the code with Pure Benglish Error Handling
    try:
        exec(code)
    except IndentationError:
        print("Bhai, space ba tab thik kore de! Tero-beka kore likhle computer bujhbe ki kore?")
    except SyntaxError:
        print("Abe, ki likhechis eishob? Banan ba lekhar dhoron thik nei, chokh khule dekh!")
    except NameError:
        print("Bhai, ei nam-ta aage kothaw bolish ni, achanak kotheke elo?")
    except TypeError:
        print("Bhai, jol ar tel meshate chas na! Duto onno rokom jinish meshano jabe na.")
    except ZeroDivisionError:
        print("Abe, shunno diye bhag kora jay naki? Paglami korish na!")
    except IndexError:
        print("Bhai, joto gulo jayga ache tor kache, tar theke baire haat baracchis!")
    except ValueError:
        print("Bhai, thik jinish de! Jeta chawa hoyeche sheta na diye onno kichu dili keno?")
    except KeyError:
        print("Bhai, ei key-ta toh dictionary-te nei! Khuje dekh bhalo kore.")
    except AttributeError:
        print("Abe, ei jinish-tar toh ei khomota nei! Ki korchis egulo?")
    except Exception:
        print("Bhai, boro kono jhamela pakiyechis! Abar bhalo kore tor lekha-ta por.")

def main():
    if len(sys.argv) > 1:
        run_bongpy_code(sys.argv[1])
    else:
        print("""
    ____                   _____       
   |  _ \\                 |  __ \\      
   | |_) | ___  _ __   __ | |__) |   _ 
   |  _ < / _ \\| '_ \\ / _`|  ___/ | | |
   | |_) | (_) | | | | (_|| |   | |_| |
   |____/ \\___/|_| |_|\\__,|_|    \\__, |
                                  __/ |
                                 |___/ 
    =========================================
      The Official BongPy Programming Engine
      Developed exclusively by Ronit
    =========================================
        """)
        print("Bhai, ki chalate hobe shetai toh bolli na! File er naam ta de. (e.g., bongpy hello.by)")
        
if __name__ == "__main__":
    main()