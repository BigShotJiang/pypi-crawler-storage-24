import os
import sqlite3
import json
import logging
import hashlib
from datetime import datetime
from typing import List, Optional

logger = logging.getLogger(__name__)

def init_db(db_path: str):
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Quotes table with timestamps and unique hash_id
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS quotes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            hash_id TEXT UNIQUE,
            text TEXT NOT NULL,
            author TEXT NOT NULL,
            book_title TEXT,
            tags TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Crawl state table with updated_at timestamp
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS crawl_state (
            tag_url TEXT PRIMARY KEY,
            last_page_processed INTEGER DEFAULT 0,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    conn.commit()
    conn.close()

def get_random_quote(conn: sqlite3.Connection):
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    row = cursor.execute('''
        SELECT text, author, book_title, tags 
        FROM quotes 
        WHERE id >= (ABS(RANDOM()) % (SELECT MAX(id) FROM quotes)) 
        LIMIT 1
    ''').fetchone()
    if not row:
        return None
        
    return {
        "text": row["text"],
        "author": row["author"],
        "book_title": row["book_title"],
        "tags": json.loads(row["tags"]) if row["tags"] else []
    }

def search_quotes(conn: sqlite3.Connection, query: str, limit: int = 5):
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    # Use FTS5 for searching
    rows = cursor.execute(
        """
        SELECT q.text, q.author, q.book_title, q.tags 
        FROM quotes q
        JOIN quotes_fts f ON q.id = f.rowid
        WHERE quotes_fts MATCH ?
        ORDER BY rank
        LIMIT ?
        """,
        (query, limit),
    ).fetchall()

    quotes = []
    for row in rows:
        quotes.append({
            "text": row["text"],
            "author": row["author"],
            "book_title": row["book_title"],
            "tags": json.loads(row["tags"]) if row["tags"] else []
        })
    return quotes

def save_quote(conn: sqlite3.Connection, quote):
    cursor = conn.cursor()
    hash_id = quote.hash_id
    tags_json = json.dumps(quote.tags)
    
    try:
        cursor.execute('''
            INSERT INTO quotes (hash_id, text, author, book_title, tags)
            VALUES (?, ?, ?, ?, ?)
        ''', (hash_id, quote.text, quote.author, quote.book_title, tags_json))
        conn.commit()
    except sqlite3.IntegrityError:
        # Duplicate quote, ignore
        pass
    except sqlite3.Error as e:
        # Log other DB errors
        logger.error(f"Database error: {e}")

def get_crawl_state(conn: sqlite3.Connection, tag_url: str) -> int:
    cursor = conn.cursor()
    cursor.execute('SELECT last_page_processed FROM crawl_state WHERE tag_url = ?', (tag_url,))
    result = cursor.fetchone()
    return result[0] if result else 0

def update_crawl_state(conn: sqlite3.Connection, tag_url: str, page: int):
    cursor = conn.cursor()
    now = datetime.now().isoformat()
    cursor.execute('''
        INSERT INTO crawl_state (tag_url, last_page_processed, updated_at)
        VALUES (?, ?, ?)
        ON CONFLICT(tag_url) DO UPDATE SET
            last_page_processed = excluded.last_page_processed,
            updated_at = excluded.updated_at
    ''', (tag_url, page, now))
    conn.commit()

def get_all_quotes(conn: sqlite3.Connection):
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.execute("SELECT text, author, book_title, tags FROM quotes")
    rows = cursor.fetchall()
    
    quotes = []
    for row in rows:
        quotes.append({
            "text": row["text"],
            "author": row["author"],
            "book_title": row["book_title"],
            "tags": json.loads(row["tags"]) if row["tags"] else []
        })
    return quotes

def get_unique_tags(conn: sqlite3.Connection) -> List[str]:
    cursor = conn.cursor()
    cursor.execute("SELECT tags FROM quotes")
    rows = cursor.fetchall()
    
    unique_tags = set()
    for row in rows:
        tags = json.loads(row["tags"]) if row["tags"] else []
        unique_tags.update(tags)
    return sorted(list(unique_tags))

def optimize_db(db_path: str):
    """
    Apply SQLite optimizations: indexes, FTS5 virtual table, and VACUUM.
    """
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    # Create standard indexes
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_author ON quotes(author)")
    
    # Create FTS5 virtual table for searching
    cursor.execute("DROP TABLE IF EXISTS quotes_fts")
    cursor.execute('''
        CREATE VIRTUAL TABLE quotes_fts USING fts5(
            text, 
            author, 
            book_title,
            content='quotes',
            content_rowid='id'
        )
    ''')
    
    # Populate FTS5 table
    cursor.execute('''
        INSERT INTO quotes_fts(rowid, text, author, book_title)
        SELECT id, text, author, book_title FROM quotes
    ''')
    
    conn.commit()
    
    # Vacuum to minimize file size
    cursor.execute("VACUUM")
    conn.close()

def create_subset_db(source_db: str, target_db: str, limit: int = 500, tag: Optional[str] = None):
    """
    Create a smaller subset of the database for the 'starter' API.
    Can be filtered by a specific tag.
    """
    if os.path.exists(target_db):
        os.remove(target_db)
        
    init_db(target_db)
    
    src_conn = sqlite3.connect(source_db)
    dst_conn = sqlite3.connect(target_db)
    
    # Build query with optional tag filter
    query = "SELECT hash_id, text, author, book_title, tags FROM quotes"
    params = []
    
    if tag:
        query += " WHERE tags LIKE ?"
        params.append(f'%"{tag.lower()}"%')
    
    query += " ORDER BY RANDOM() LIMIT ?"
    params.append(limit)
    
    # Copy subset of quotes
    quotes = src_conn.execute(query, params).fetchall()
    
    dst_conn.executemany(
        "INSERT INTO quotes (hash_id, text, author, book_title, tags) VALUES (?, ?, ?, ?, ?)",
        quotes
    )
    
    dst_conn.commit()
    src_conn.close()
    dst_conn.close()
    
    # Optimize the subset
    optimize_db(target_db)
