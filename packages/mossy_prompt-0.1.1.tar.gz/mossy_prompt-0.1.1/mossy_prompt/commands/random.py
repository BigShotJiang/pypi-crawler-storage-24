import sqlite3
import typer
from mossy_prompt.commands.utils import get_cached_db
from mossy_prompt.db import get_random_quote

def random(
    verbose: bool = typer.Option(
        False, "--verbose", "-v", help="Display tags for the quote"
    ),
    working_dir: str = typer.Option(
        "docs/data/sqlite", "--working-dir", "-w", help="Working directory for local cache"
    ),
):
    """
    Get a random quote from the local cached database.
    """
    db_path = get_cached_db(working_dir)
    if not db_path:
        typer.echo("Error: No cached database found. Run 'sync' first or 'crawl' to create one.", err=True)
        raise typer.Exit(code=1)

    conn = sqlite3.connect(db_path)
    try:
        quote = get_random_quote(conn)
        if quote:
            typer.secho(f'\n"{quote["text"]}"', fg=typer.colors.CYAN, bold=True)
            typer.echo(
                f"  -- {quote['author']}"
                + (f" (from '{quote['book_title']}')" if quote["book_title"] else "")
            )
            
            if verbose:
                typer.echo(f"  Tags: {', '.join(quote['tags'])}")
            
            typer.echo("") # Newline

            if "quotes-small.db" in db_path:
                typer.echo(
                    "(Using small database. Full database might not be available.)"
                )
        else:
            typer.echo("No quotes found in database.")
    finally:
        conn.close()
