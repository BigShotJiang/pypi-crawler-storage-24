import os
import json
from datetime import datetime
from typing import Optional, Dict, Any

def get_cached_db(working_dir: str) -> Optional[str]:
    """
    Helper to find the best available local database (quotes.db > quotes-small.db).
    """
    cache_dir = os.path.join(working_dir, "cache")
    main_path = os.path.join(cache_dir, "quotes.db")
    small_path = os.path.join(cache_dir, "quotes-small.db")

    if os.path.exists(main_path):
        return main_path
    if os.path.exists(small_path):
        return small_path
    
    # Also check the working_dir itself
    direct_path = os.path.join(working_dir, "quotes.db")
    if os.path.exists(direct_path):
        return direct_path
        
    return None

def get_manifest(manifest_path: str) -> Dict[str, Any]:
    """
    Read the manifest from the specified path. Return an empty manifest if not found.
    """
    if os.path.exists(manifest_path):
        try:
            with open(manifest_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass
    return {"version": "0.0.0", "total_quotes": 0}

def save_manifest(manifest_path: str, manifest: Dict[str, Any]):
    """
    Save the manifest to the specified path.
    """
    os.makedirs(os.path.dirname(manifest_path), exist_ok=True)
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)

def generate_calver(current_version: str) -> str:
    """
    Generate a CalVer version string (YYYY.MM.DD). 
    If the current version is from today, increment a revision suffix (.N).
    """
    today = datetime.now().strftime("%Y.%m.%d")
    if not current_version.startswith(today):
        return today
    
    # Same day, handle revision
    parts = current_version.split(".")
    if len(parts) == 4:
        # e.g., 2024.03.01.1 -> 2024.03.01.2
        try:
            rev = int(parts[3])
            return f"{today}.{rev + 1}"
        except ValueError:
            pass
    
    return f"{today}.1"
