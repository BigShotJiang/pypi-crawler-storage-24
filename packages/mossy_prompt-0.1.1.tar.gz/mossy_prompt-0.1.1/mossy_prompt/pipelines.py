import sqlite3
from scrapy.exceptions import DropItem
from pydantic import ValidationError
from .models import Quote
from .db import init_db, save_quote, update_crawl_state

class SQLitePipeline:
    @classmethod
    def from_crawler(cls, crawler):
        pipeline = cls()
        pipeline.crawler = crawler
        return pipeline

    def open_spider(self, spider):
        # Use settings from crawler if available, fallback to spider settings
        settings = getattr(self, 'crawler', spider).settings
        db_path = settings.get('DB_PATH', 'quotes.db')
        init_db(db_path)
        self.conn = sqlite3.connect(db_path)
        self.item_count = 0

    def close_spider(self, spider):
        if hasattr(self, 'conn'):
            self.conn.close()

    def process_item(self, item, spider):
        # Handle crawl state items
        if item.get('type') == 'crawl_state':
            tag_url = item['tag_url']
            page = item['page']
            update_crawl_state(self.conn, tag_url, page)
            print(f"\rCrawl Progress: {self.item_count} items | Completed page {page} for {tag_url}", end="", flush=True)
            return item
        
        # Handle quote items
        try:
            # Drop the Scrapy internal metadata before Pydantic validation
            quote_data = {k: v for k, v in item.items() if k in Quote.model_fields}
            quote = Quote(**quote_data)
            save_quote(self.conn, quote)
            self.item_count += 1
            if self.item_count % 10 == 0:
                print(f"\rCrawl Progress: {self.item_count} items collected...", end="", flush=True)
            return item
        except ValidationError as e:
            raise DropItem(f"Invalid quote item: {e}")
        except Exception as e:
            spider.logger.error(f"Error processing item: {e}")
            raise DropItem(f"Error processing item: {e}")
