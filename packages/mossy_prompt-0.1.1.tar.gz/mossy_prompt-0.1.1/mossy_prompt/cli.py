import typer
from mossy_prompt.commands import crawl as crawl_mod
from mossy_prompt.commands import export as export_mod
from mossy_prompt.commands import sync as sync_mod
from mossy_prompt.commands import random as random_mod
from mossy_prompt.commands import search as search_mod

app = typer.Typer(help="Goodreads Quotes Crawler CLI")

# Register commands
app.command()(crawl_mod.crawl)
app.command()(export_mod.export)
app.command()(sync_mod.sync)
app.command()(random_mod.random)
app.command()(search_mod.search)

if __name__ == "__main__":
    app()
