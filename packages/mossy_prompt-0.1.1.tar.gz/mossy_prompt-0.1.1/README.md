# Mossy Prompt

A robust, resumable, and polite quote crawler for Goodreads. Built with Python 3.13+, Scrapy, Typer, and SQLite.

## Features

- **Resumable Crawling**: Tracks `last_page_processed` per tag in SQLite, allowing you to stop and resume crawls at any time.
- **Smart Deduplication**: Quotes are uniquely identified by a SHA-256 hash of their text and author, preventing duplicates across different tags.
- **Polite & Ethical**:
  - Respects `robots.txt`.
  - Uses Scrapy's `AUTOTHROTTLE` to adjust speed based on server load.
  - Supports configurable download delays via CLI.
  - Employs realistic browser User-Agents to avoid blocks.
- **Data Modeling**: Uses Pydantic for strict data validation and type safety.
- **Clean CLI**: A powerful `typer`-based interface with progress reporting.
- **Flexible Export**: Export your collection to JSON or CSV.

## Tech Stack

- **Python 3.13+**
- **[uv](https://github.com/astral-sh/uv)**: Dependency management and project isolation.
- **Scrapy**: High-level crawling and scraping.
- **SQLite**: Local persistence and state management.
- **Typer**: CLI command parsing.
- **Pydantic**: Data validation.

## Setup

### Using pip (Recommended)

You can install the project directly from the source:

```bash
pip install .
```

This will install the `mossy-prompt` command-line tool globally (or in your virtual environment).

### Using uv

If you prefer using `uv`:

```bash
uv sync
```

## Usage

After installation, you can use the `mossy-prompt` command directly.

### Crawling

Start crawling quotes for specific tags. The default tags are `inspirational,motivational,buddhism`.

```bash
# Basic crawl
mossy-prompt crawl --tags inspirational,life

# Crawl from a specific Goodreads URL (author, book, etc.)
mossy-prompt crawl --url https://www.goodreads.com/author/mossy-prompt/123.Author_Name

# Configurable download delay (default 1s)
mossy-prompt crawl --delay 2.0
```

The crawler will save quotes to `docs/data/sqlite/quotes.db` by default and display real-time progress.

### Exporting

Export your collection as optimized web and CLI assets.

```bash
# Export optimized SQLite and JSON files to ./docs
mossy-prompt export --output ./docs --limit 500
```

This command creates:
- `docs/data/sqlite/quotes.db`: Complete optimized database with FTS5 search.
- `docs/data/sqlite/quotes-small.db`: Small subset (tag: buddhism) for instant availability.
- `docs/data/json/quotes.json` & `docs/data/json/quotes-small.json`: JSON versions of the databases.
- `docs/data/csv/quotes.csv` & `docs/data/csv/quotes-small.csv`: CSV versions of the databases.

### CLI Client

Interact with the cached quote collection using the CLI client.

```bash
# Sync data files (SQLite, CSV, JSON) from the remote static website
mossy-prompt sync https://anhldbk.github.io/mossy-prompt/data/

# Get a random quote from the local cache
mossy-prompt random

# Lightning-fast keyword search using FTS5
mossy-prompt search "success and happiness" --limit 3
```

## Testing

Run the full suite of unit and integration tests:

```bash
export PYTHONPATH=$PYTHONPATH:. 
uv run pytest
```

## Project Structure

- `mossy-prompt/`: Core package containing models, spider, database logic, and pipelines.
- `scripts/`: Entry point bash scripts.
- `docs/`: Design documents, implementation plans, and exported web assets (`docs/data/`).
- `tests/`: Comprehensive test suite.

---

Vibe coded via **Gemini**.
