import sqlite3
import pytest
from mossy_prompt.db import init_db, save_quote, get_crawl_state, update_crawl_state
from mossy_prompt.models import Quote


@pytest.fixture
def db_conn(tmp_path):
    db_path = str(tmp_path / "test_mossy_prompt.db")
    init_db(db_path)
    conn = sqlite3.connect(db_path)
    yield conn
    conn.close()


def test_init_db(tmp_path):
    db_path = str(tmp_path / "init_test.db")
    init_db(db_path)
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
    tables = [t[0] for t in cursor.fetchall()]
    assert "quotes" in tables
    assert "crawl_state" in tables
    conn.close()


def test_save_quote(db_conn):
    quote = Quote(
        text="Test quote", author="Author", book_title="Book", tags=["tag1", "tag2"]
    )
    save_quote(db_conn, quote)

    cursor = db_conn.cursor()
    cursor.execute("SELECT text, author, tags FROM quotes")
    row = cursor.fetchone()
    assert row[0] == "Test quote"
    assert row[1] == "Author"
    assert "tag1" in row[2]
    assert "tag2" in row[2]


def test_deduplication(db_conn):
    quote = Quote(text="Unique quote", author="Author", tags=[])
    save_quote(db_conn, quote)
    save_quote(db_conn, quote)  # Should be ignored

    cursor = db_conn.cursor()
    cursor.execute("SELECT COUNT(*) FROM quotes")
    assert cursor.fetchone()[0] == 1


def test_create_subset_db_with_tag(tmp_path):
    from mossy_prompt.db import create_subset_db, get_all_quotes
    src_db = str(tmp_path / "source.db")
    dst_db = str(tmp_path / "subset.db")
    
    init_db(src_db)
    conn = sqlite3.connect(src_db)
    
    # Save mixed quotes
    q1 = Quote(text="Buddhism quote", author="Author1", tags=["buddhism", "life"])
    q2 = Quote(text="Inspirational quote", author="Author2", tags=["inspirational"])
    save_quote(conn, q1)
    save_quote(conn, q2)
    conn.close()
    
    # Create subset for 'buddhism'
    create_subset_db(src_db, dst_db, limit=10, tag="buddhism")
    
    # Verify
    subset_conn = sqlite3.connect(dst_db)
    quotes_data = get_all_quotes(subset_conn)
    subset_conn.close()
    
    assert len(quotes_data) == 1
    assert quotes_data[0]["text"] == "Buddhism quote"
    assert "buddhism" in quotes_data[0]["tags"]


def test_crawl_state(db_conn):
    tag_url = "https://example.com/tag"
    update_crawl_state(db_conn, tag_url, 5)
    assert get_crawl_state(db_conn, tag_url) == 5

    update_crawl_state(db_conn, tag_url, 10)
    assert get_crawl_state(db_conn, tag_url) == 10
