import os
import pytest
from typer.testing import CliRunner
from mossy_prompt.cli import app
from unittest.mock import patch, MagicMock

runner = CliRunner()


def test_crawl_command_creates_dir(tmp_path):
    working_dir = tmp_path / "test_data"
    # Mocking CrawlerProcess to avoid live crawl
    with patch("mossy_prompt.commands.crawl.CrawlerProcess") as mock_process:
        result = runner.invoke(
            app, ["crawl", "--working-dir", str(working_dir), "--tags", "test"]
        )
        assert result.exit_code == 0
        assert os.path.exists(working_dir)


def test_export_command_missing_db(tmp_path):
    working_dir = tmp_path / "empty_dir"
    os.makedirs(working_dir)
    # Check stderr for the error message
    result = runner.invoke(
        app, ["export", "--working-dir", str(working_dir)]
    )
    assert result.exit_code == 1
    assert "Source database not found" in result.stderr


def test_export_with_mock_db(tmp_path):
    working_dir = tmp_path / "data/sqlite"
    os.makedirs(working_dir)
    db_path = working_dir / "quotes.db"
    # Create an empty db file to pass the existence check
    open(db_path, "a").close()

    output_dir = tmp_path / "output"

    with patch("mossy_prompt.commands.export.sqlite3.connect") as mock_connect, \
         patch("mossy_prompt.commands.export.optimize_db") as mock_optimize, \
         patch("mossy_prompt.commands.export.create_subset_db") as mock_subset, \
         patch("mossy_prompt.commands.export.get_all_quotes") as mock_get_quotes:
        
        mock_conn = MagicMock()
        mock_connect.return_value = mock_conn
        mock_get_quotes.return_value = []

        result = runner.invoke(app, ["export", "--working-dir", str(working_dir), "--output", str(output_dir)])
        assert result.exit_code == 0
        assert "Successfully exported" in result.stdout


def test_random_command(tmp_path):
    working_dir = tmp_path / "data/sqlite"
    os.makedirs(working_dir)
    db_path = working_dir / "quotes.db"
    
    with patch("mossy_prompt.commands.random.get_cached_db") as mock_get_db, \
         patch("mossy_prompt.commands.random.sqlite3.connect") as mock_connect, \
         patch("mossy_prompt.commands.random.get_random_quote") as mock_get_random:
        
        mock_get_db.return_value = str(db_path)
        mock_get_random.return_value = {
            "text": "Random quote",
            "author": "Author",
            "book_title": "Book",
            "tags": ["tag1"]
        }
        
        # Test without verbose
        result = runner.invoke(app, ["random", "--working-dir", str(working_dir)])
        assert result.exit_code == 0
        assert "Random quote" in result.stdout
        assert "Author" in result.stdout
        assert "Tags:" not in result.stdout

        # Test with verbose
        result = runner.invoke(app, ["random", "--verbose", "--working-dir", str(working_dir)])
        assert result.exit_code == 0
        assert "Random quote" in result.stdout
        assert "Tags: tag1" in result.stdout


def test_search_command(tmp_path):
    working_dir = tmp_path / "data/sqlite"
    os.makedirs(working_dir)
    db_path = working_dir / "quotes.db"
    
    with patch("mossy_prompt.commands.search.get_cached_db") as mock_get_db, \
         patch("mossy_prompt.commands.search.sqlite3.connect") as mock_connect, \
         patch("mossy_prompt.commands.search.search_quotes") as mock_search:
        
        mock_get_db.return_value = str(db_path)
        mock_search.return_value = [{
            "text": "Found quote",
            "author": "Author",
            "book_title": "Book",
            "tags": ["tag1"]
        }]
        
        result = runner.invoke(app, ["search", "query", "--working-dir", str(working_dir)])
        assert result.exit_code == 0
        assert "Found quote" in result.stdout
        assert "Author" in result.stdout
        assert "tag1" in result.stdout


def test_sync_command_default_only_sqlite(tmp_path):
    working_dir = tmp_path / "data"
    
    with patch("urllib.request.urlopen") as mock_urlopen:
        mock_response = MagicMock()
        mock_response.__enter__.return_value = mock_response
        # Return a valid JSON for manifest.json, then dummy data for others
        mock_response.read.side_effect = [
            b'{"version": "2026.03.26", "total_quotes": 100}', # remote manifest.json
            b"fake data", # sqlite/quotes.db
            b"fake data", # sqlite/quotes-small.db
        ]
        mock_urlopen.return_value = mock_response

        # Test default (only sqlite)
        result = runner.invoke(app, ["sync", "--working-dir", str(working_dir)])
        assert result.exit_code == 0
        assert "SQLite database" in result.stdout
        assert "Small SQLite database" in result.stdout
        assert "CSV quotes" not in result.stdout
        assert "JSON quotes" not in result.stdout
        assert os.path.exists(working_dir / "sqlite" / "quotes.db")
        assert not os.path.exists(working_dir / "csv" / "quotes.csv")
        assert not os.path.exists(working_dir / "csv" / "quotes-small.csv")
        assert not os.path.exists(working_dir / "json" / "quotes.json")
        assert not os.path.exists(working_dir / "json" / "quotes-small.json")


def test_sync_command_all_formats(tmp_path):
    working_dir = tmp_path / "data_all"
    
    with patch("urllib.request.urlopen") as mock_urlopen:
        mock_response = MagicMock()
        mock_response.__enter__.return_value = mock_response
        mock_response.read.side_effect = [
            b'{"version": "2026.03.26", "total_quotes": 100}', # remote manifest.json
            b"fake data", # sqlite/quotes.db
            b"fake data", # sqlite/quotes-small.db
            b"fake data", # csv/quotes.csv
            b"fake data", # csv/quotes-small.csv
            b"fake data", # json/quotes.json
            b"fake data", # json/quotes-small.json
        ]
        mock_urlopen.return_value = mock_response

        # Test with --all
        result = runner.invoke(app, ["sync", "--working-dir", str(working_dir), "--all"])
        assert result.exit_code == 0
        assert "SQLite database" in result.stdout
        assert "CSV quotes" in result.stdout
        assert "JSON quotes" in result.stdout
        assert os.path.exists(working_dir / "sqlite" / "quotes.db")
        assert os.path.exists(working_dir / "csv" / "quotes.csv")
        assert os.path.exists(working_dir / "json" / "quotes.json")
