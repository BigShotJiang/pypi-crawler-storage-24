import scrapy
import pytest
from scrapy.http import HtmlResponse, Request
from mossy_prompt.spider import GoodreadsQuotesSpider


def test_spider_init_with_tags():
    spider = GoodreadsQuotesSpider(tags="inspirational,life")
    assert spider.tags == ["inspirational", "life"]


def test_spider_init_default():
    spider = GoodreadsQuotesSpider()
    assert spider.tags == []


def test_parse_mossy_prompt():
    spider = GoodreadsQuotesSpider()
    html = """
    <div class="quote">
        <div class="quoteDetails">
            <div class="quoteText">
                “Quote 1 text”
                <br>  ―
                <span class="authorOrTitle">
                    Author 1
                </span>
            </div>
            <div class="quoteFooter">
                <div class="greyText smallText left">
                                        tags:
                                        <a href="/mossy_prompt/tag/tag1">tag1</a>,
                                        <a href="/mossy_prompt/tag/tag2">tag2</a>
                                    </div>            </div>
        </div>
    </div>
    <div class="quote">
        <div class="quoteDetails">
            <div class="quoteText">
                “Quote 2 text”
                <br>  ―
                <span class="authorOrTitle">
                    Author 2
                </span>
                <a class="authorOrTitle" href="/book/show/123">Book Title 2</a>
            </div>
            <div class="quoteFooter">
                <div class="greyText smallText left">
                                        tags:
                                        <a href="/mossy_prompt/tag/tag3">tag3</a>
                                    </div>            </div>
        </div>
    </div>
    <div class="pagination">
        <a class="next_page" href="/mossy_prompt/tag/inspirational?page=2">Next</a>
    </div>
    """
    request = Request(
        url="https://www.goodreads.com/mossy_prompt/tag/inspirational",
        meta={
            "tag_url": "https://www.goodreads.com/mossy_prompt/tag/inspirational",
            "page": 1,
        },
    )
    response = HtmlResponse(
        url="https://www.goodreads.com/mossy_prompt/tag/inspirational",
        body=html,
        encoding="utf-8",
        request=request,
    )

    results = list(spider.parse(response))

    # Extract only quote items (ignore state updates)
    mossy_prompt = [
        r for r in results if isinstance(r, dict) and r.get("type") != "crawl_state"
    ]

    assert len(mossy_prompt) == 2
    assert mossy_prompt[0]["text"] == "Quote 1 text"
    assert mossy_prompt[0]["author"] == "Author 1"
    assert mossy_prompt[0]["book_title"] is None
    assert mossy_prompt[0]["tags"] == ["tag1", "tag2"]

    assert mossy_prompt[1]["text"] == "Quote 2 text"
    assert mossy_prompt[1]["author"] == "Author 2"
    assert mossy_prompt[1]["book_title"] == "Book Title 2"
    assert mossy_prompt[1]["tags"] == ["tag3"]


def test_pagination_logic():
    spider = GoodreadsQuotesSpider()
    html = """
    <div class="pagination">
        <a class="next_page" href="/mossy_prompt/tag/inspirational?page=2">Next</a>
    </div>
    """
    request = Request(
        url="https://www.goodreads.com/mossy_prompt/tag/inspirational",
        meta={
            "tag_url": "https://www.goodreads.com/mossy_prompt/tag/inspirational",
            "page": 1,
        },
    )
    response = HtmlResponse(
        url="https://www.goodreads.com/mossy_prompt/tag/inspirational",
        body=html,
        encoding="utf-8",
        request=request,
    )

    results = list(spider.parse(response))
    requests = [r for r in results if isinstance(r, scrapy.Request)]

    assert len(requests) == 1
    assert "page=2" in requests[0].url
    assert requests[0].meta["page"] == 2
    assert (
        requests[0].meta["tag_url"]
        == "https://www.goodreads.com/mossy_prompt/tag/inspirational"
    )


def test_spider_init_with_url():
    spider = GoodreadsQuotesSpider(url="https://www.goodreads.com/author/mossy_prompt/123")
    assert spider.url == "https://www.goodreads.com/author/mossy_prompt/123"
