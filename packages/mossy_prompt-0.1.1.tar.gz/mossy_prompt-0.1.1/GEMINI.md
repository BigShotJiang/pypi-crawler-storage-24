# Mossy Prompt

A robust, resumable, and polite quote crawler for Goodreads. Built as a unified Python package using modern tools like Scrapy, Typer, Pydantic, and SQLite.

## Project Overview

The **Mossy Prompt** is designed to scrape quotes from specific tags (e.g., *inspirational*, *motivational*) on Goodreads. It focuses on data integrity, deduplication, and the ability to resume long-running crawls.

### Key Technologies
- **Python 3.13+**: Core language.
- **UV**: Fast dependency management and project isolation.
- **Scrapy**: High-level web crawling and scraping framework.
- **SQLite**: Local database for quote storage and session state management.
- **Typer**: User-friendly CLI for execution and data export.
- **Pydantic**: Data validation and type safety.

### Architecture
- **`mossy_prompt/cli.py`**: The CLI entry point. Coordinates database initialization and launches Scrapy's `CrawlerProcess`.
- **`mossy_prompt/spider.py`**: Defines the extraction logic, follows pagination, and handles resumption by reading the previous crawl state.
- **`mossy_prompt/db.py`**: Manages the SQLite schema and provides functions for atomic quote storage and state updates.
- **`mossy_prompt/pipelines.py`**: A Scrapy pipeline that validates items using Pydantic before persisting them to the database.
- **`mossy_prompt/models.py`**: Contains Pydantic models defining the `Quote` schema (including a computed `hash_id` for deduplication) and `CrawlState`.

---

## Building and Running

This project uses `uv` for easy environment management.

### Setup
```bash
# Install uv (if not already installed)
curl -LsSf https://astral.sh/uv/install.sh | sh

# Sync dependencies
uv sync
```

### Running the Crawler
Use the provided bash script or run the package directly:
```bash
# Run using the script
./scripts/mossy-prompt crawl --tags inspirational,motivational

# Crawl from a specific Goodreads URL (author, book, etc.)
./scripts/mossy-prompt crawl --url https://www.goodreads.com/author/mossy_prompt/123.Author_Name

# Configure download delay for politeness
./scripts/mossy-prompt crawl --delay 2.0
```

### Exporting Data
```bash
# Export the database into optimized assets for web and CLI use
mossy-prompt export --output ./docs --limit 500
```


### Web Assets Structure
The `export` command generates:
- `docs/data/manifest.json`: Data version (CalVer) and metadata.
- `docs/data/sqlite/quotes.db`: Complete optimized database with FTS5.
- `docs/data/sqlite/quotes-small.db`: Small subset (filtered by 'buddhism' tag).
- `docs/data/json/quotes.json`: JSON version of all quotes.
- `docs/data/json/quotes-small.json`: JSON version of the small collection.
- `docs/data/csv/quotes.csv`: CSV version of all quotes.
- `docs/data/csv/quotes-small.csv`: CSV version of the small collection.



### CLI Client Usage
```bash
# Sync data from the remote static website (GitHub Pages)
./scripts/mossy-prompt sync

# Get a random quote from local cache
./scripts/mossy-prompt random

# Search for quotes using lightning-fast FTS5
./scripts/mossy-prompt search "success and happiness" --limit 5
```

### Testing
```bash
# Run all tests using pytest
export PYTHONPATH=$PYTHONPATH:. 
uv run pytest
```

---

## Development Conventions

### Resumption Logic
The crawler is designed to be interrupted. Before starting a crawl for a tag, it checks the `crawl_state` table in SQLite. It resumes from `last_page_processed + 1`.

### Data Integrity & Deduplication
- Quotes are deduplicated based on a unique `hash_id` (SHA-256 hash of `text` and `author`).
- The database uses `ON CONFLICT` logic to update crawl states atomically.
- All extracted data is validated against the `Quote` Pydantic model before being saved.

### Politeness & Scraping Ethics
- **Autothrottle**: Enabled by default to adjust crawling speed based on server response.
- **User-Agent**: Uses a realistic browser agent to avoid simple bot blocks.
- **Robots.txt**: Adheres to `ROBOTSTXT_OBEY = True`.
- **Download Delay**: Configurable via CLI to respect server resources.

### Logging & Progress
- Standard Scrapy logs are reduced to `WARNING` level in the CLI.
- Custom progress reporting is implemented in the `SQLitePipeline` to show real-time item collection and page status.
