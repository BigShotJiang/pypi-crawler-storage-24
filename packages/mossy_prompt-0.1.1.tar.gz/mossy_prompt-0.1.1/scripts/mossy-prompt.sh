#!/bin/bash
set -e
uv run -m mossy_prompt.cli "$@"
