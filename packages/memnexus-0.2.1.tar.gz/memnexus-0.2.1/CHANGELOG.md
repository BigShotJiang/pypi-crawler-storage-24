# Changelog

All notable changes to MemNexus will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.2.0] - 2026-03-25

### 🎉 First Public Release - Code Memory for AI Programming Tools

This is the first public release of MemNexus as a **Code Memory** tool for AI programming assistants.

### ✨ New Features

#### Core Memory System
- **CodeMemory** - Main entry point for library usage
- **Vector Storage** - LanceDB-based semantic search
- **MemoryStore** - Add, search, and manage memory entries

#### Git Integration
- **GitMemoryExtractor** - Extract commit history from Git repositories
- **Commit Indexing** - Index commit messages, authors, and file changes
- **Semantic Search** - Search Git history with natural language
- **File History** - Get complete history for specific files

#### Code Parsing
- **CodeParser** - Parse Python code using AST
- **Symbol Extraction** - Extract functions, classes, and methods
- **Import Analysis** - Extract and analyze import statements
- **CodeChunker** - Create embeddable code chunks with context
- **Signature Extraction** - Capture function signatures with type annotations

#### CLI Interface
- **memnexus init** - Initialize project for memory tracking
- **memnexus index** - Index Git history and/or code
- **memnexus search** - Search project memory
- **memnexus status** - Check project indexing status
- **memnexus server** - Start HTTP API server

#### HTTP API
- `GET /health` - Health check
- `GET /stats` - Project statistics
- `GET /api/v1/search` - Search all memories
- `POST /api/v1/memory` - Add memory entry
- `POST /api/v1/git/index` - Index Git history
- `GET /api/v1/git/search` - Search Git history
- `POST /api/v1/code/index` - Index codebase
- `GET /api/v1/code/search` - Search code symbols
- `GET /api/v1/code/symbol/{name}` - Find specific symbol

#### Kimi CLI Plugin
- **Plugin Support** - Native integration with Kimi CLI 1.25.0+
- **6 Tools** - memory_search, memory_store, memory_status, memory_index, find_symbol, get_file_history
- **Slash Commands** - `/memory search`, `/memory store`, `/memory status`, etc.

### 🐛 Known Issues

- Code parsing currently only supports Python
- TypeScript/JavaScript support coming in next release
- Large repositories may require tuning batch sizes

### 📁 New Files

```
src/memnexus/
├── __init__.py              # Main exports
├── code_memory.py           # Core CodeMemory class
├── cli.py                   # CLI interface
├── server.py                # FastAPI server
├── memory/
│   ├── git.py              # Git integration
│   ├── code.py             # Code parsing
│   └── store.py            # Vector storage
└── scripts/
    └── kimi_plugin.py      # Kimi CLI plugin

~/.kimi/plugins/memnexus/
├── plugin.json             # Plugin manifest
└── SKILL.md                # Plugin documentation
```

### 📊 Statistics

- Total Lines of Code: ~5,000
- Python Files: 15
- Test Coverage: Core functionality tested
- Documentation: Complete user guides

## [0.1.0] - 2026-02-20 (Internal)

### Initial Prototype

> **Note:** This was an internal prototype with a different focus (Multi-Agent Orchestration). 
> The project was significantly refactored for the 0.2.0 release.

Original features:
- Multi-Agent Collaboration Orchestration
- ACP Protocol implementation
- LlamaIndex RAG Pipeline
- React Frontend
- Task Scheduler and Intervention System

[0.2.0]: https://github.com/Leeelics/MemNexus/releases/tag/v0.2.0
[0.1.0]: https://github.com/Leeelics/MemNexus/releases/tag/v0.1.0
