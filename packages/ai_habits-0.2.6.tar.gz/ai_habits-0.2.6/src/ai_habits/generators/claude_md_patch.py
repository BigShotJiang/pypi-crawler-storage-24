"""Generate additions to an existing CLAUDE.md.

We NEVER replace the file. We only produce new sections that the user
can append/merge. Every section has a comment explaining the evidence.
"""

from __future__ import annotations

from pathlib import Path

from ai_habits.patterns.clustering import Pattern

# Maps anti-pattern name → section generator function name
_ANTI_PATTERN_SECTION_MAP: dict[str, str] = {
    "auth-setup-repeat":    "_auth_section",
    "no-context-preamble":  "_context_preamble_section",
    "version-specification": "_versions_section",
    "tool-repetition":      "_tools_section",
}


def generate_patch(
    project_path: Path,
    patterns: list[Pattern],
    anti_patterns: list[dict] | None = None,
    output_path: Path | None = None,
) -> Path:
    """Generate a CLAUDE.md.patch file with suggested additions.

    Args:
        project_path: Root of the project (CLAUDE.md must exist here).
        patterns: Classified patterns from the scan.
        anti_patterns: Anti-pattern match dicts from the scan.
        output_path: Where to write the patch (default: CLAUDE.md.patch).

    Returns:
        Path of the written patch file.
    """
    claude_md = project_path / "CLAUDE.md"
    if not claude_md.exists():
        raise FileNotFoundError(
            f"No CLAUDE.md found at {claude_md}. "
            "Run `claude /init` to create one first."
        )

    if output_path is None:
        output_path = project_path / "CLAUDE.md.patch"

    anti_patterns = anti_patterns or []
    sections: list[str] = [_header()]

    # Sections from anti-patterns (highest signal — clearly recurring)
    for ap in anti_patterns:
        fn_name = _ANTI_PATTERN_SECTION_MAP.get(ap["name"])
        if fn_name:
            fn = globals()[fn_name]
            sections.append(fn(ap))

    # Sections from context-re-explanation patterns
    context_pats = [p for p in patterns if p.category == "context-re-explanation"]
    if context_pats:
        sections.append(_context_from_patterns(context_pats))

    # Troubleshooting section from recurring one-off debugging patterns
    debug_pats = _debug_patterns(patterns)
    if debug_pats:
        sections.append(_troubleshooting_section(debug_pats))

    if len(sections) == 1:  # Only the header was added
        sections.append(
            "<!-- No patterns found. Run `ai-habits scan` first, "
            "then re-run `ai-habits generate patch`. -->"
        )

    output_path.write_text("\n\n".join(sections) + "\n", encoding="utf-8")
    return output_path


# ---------------------------------------------------------------------------
# Section generators (LLM-first, template fallback)
# ---------------------------------------------------------------------------

def _header() -> str:
    return """\
<!-- ai-habits CLAUDE.md patch — REVIEW BEFORE APPLYING -->
<!-- Append these sections to your CLAUDE.md or merge them manually. -->
<!-- Evidence for each suggestion is noted inline. -->
"""


def _try_llm(section_type: str, samples: list[str]) -> str | None:
    """Attempt LLM-generated section. Prefers Groq (free) → Anthropic → None."""
    if not samples:
        return None
    # Groq first — free tier, fast
    try:
        from ai_habits.utils.groq_llm import generate_claude_md_section as groq_gen
        result = groq_gen(section_type, samples)
        if result:
            return result
    except Exception:
        pass
    # Anthropic fallback
    try:
        from ai_habits.utils.llm import generate_claude_md_section as anthropic_gen
        return anthropic_gen(section_type, samples)
    except Exception:
        return None


def _auth_section(ap: dict) -> str:
    count = ap["count"]
    samples = ap.get("sample_texts", [])
    evidence = f"<!-- Evidence: {count} conversations re-explaining auth ({ap['name']}) -->"

    llm = _try_llm("authentication setup (auth provider, OAuth flow, token storage, protected routes)", samples)
    if llm:
        return f"{evidence}\n\n{llm}"

    return f"""\
## Authentication
{evidence}

- **Auth provider**: [e.g. Firebase, Supabase, Auth0, custom JWT, Google OAuth]
- **Flow**: [e.g. Authorization Code with PKCE, email+password, magic link]
- **Token storage**: [e.g. httpOnly cookie, localStorage, AsyncStorage]
- **Protected routes**: [which routes/screens require authentication]
- **Key config**: [where credentials/config live]
- **Common issues**: [recurring auth bugs Claude should know]"""


def _context_preamble_section(ap: dict) -> str:
    count = ap["count"]
    samples = ap.get("sample_texts", [])
    evidence = f"<!-- Evidence: {count} conversations re-explaining project context ({ap['name']}) -->"

    llm = _try_llm("project context (stack, architecture, key directories, conventions)", samples)
    if llm:
        return f"{evidence}\n\n{llm}"

    return f"""\
## Project Context
{evidence}

[Project name] is a [one-line description].

**Tech stack**: [e.g. React Native + FastAPI + PostgreSQL]
**Key directories**:
- `[dir]/` — [what it contains]

**Conventions**:
- [e.g. All API calls go through `src/api/`]"""


def _versions_section(ap: dict) -> str:
    count = ap["count"]
    samples = ap.get("sample_texts", [])
    evidence = f"<!-- Evidence: {count} conversations specifying version numbers ({ap['name']}) -->"

    llm = _try_llm("pinned tool/framework versions", samples)
    if llm:
        return f"{evidence}\n\n{llm}"

    return f"""\
## Pinned Versions
{evidence}

| Tool / Framework | Version |
|------------------|---------|
| [e.g. Python]    | [e.g. 3.11] |
| [e.g. React]     | [e.g. 18.2] |"""


def _tools_section(ap: dict) -> str:
    count = ap["count"]
    samples = ap.get("sample_texts", [])
    evidence = f"<!-- Evidence: {count} conversations repeating tool details ({ap['name']}) -->"

    llm = _try_llm("development tools and workflow commands", samples)
    if llm:
        return f"{evidence}\n\n{llm}"

    return f"""\
## Tools & Workflow
{evidence}

- **Package manager**: [e.g. pip, npm, bun]
- **Test runner**: [e.g. pytest, jest]
- **Run commands**: [e.g. `make dev`]"""


def _context_from_patterns(patterns: list[Pattern]) -> str:
    samples = []
    for pat in patterns:
        samples.extend(pat.sample_texts[:3])
    evidence = f"<!-- Evidence: {len(patterns)} context re-explanation cluster(s) -->"

    llm = _try_llm("project context the developer keeps re-explaining", samples)
    if llm:
        return f"{evidence}\n\n{llm}"

    lines = ["## Project Context", evidence, ""]
    for pat in patterns:
        if pat.sample_texts:
            lines.append(f"<!-- Pattern '{pat.id}': {pat.sample_texts[0][:120]} -->")
    lines += ["", "[Fill in the context Claude needs to know about your project]"]
    return "\n".join(lines)


def _debug_patterns(patterns: list[Pattern]) -> list[Pattern]:
    """Return one-off-task patterns that look like recurring debugging issues."""
    debug_keywords = ("stuck", "error", "fail", "not work", "broken", "crash", "wrong", "issue", "bug")
    result = []
    for pat in patterns:
        if pat.category != "one-off-task":
            continue
        text = (pat.label or (pat.sample_texts[0] if pat.sample_texts else "")).lower()
        if any(kw in text for kw in debug_keywords) and pat.size >= 3:
            result.append(pat)
    return result


def _troubleshooting_section(patterns: list[Pattern]) -> str:
    evidence = f"<!-- Evidence: {', '.join(p.id for p in patterns)} — recurring debugging questions -->"
    sections = ["## Troubleshooting", evidence]

    for pat in patterns:
        label = (pat.label or (pat.sample_texts[0] if pat.sample_texts else pat.id))[:80]
        samples = pat.sample_texts[:5]

        llm = _try_llm(
            f"recurring issue: '{label}' (cause, diagnosis steps, fix)",
            samples,
        )
        if llm:
            sections.append(f"\n{llm}")
        else:
            sections.append(
                f"\n### {label}\n"
                f"<!-- Occurred {pat.size} times -->\n"
                "- **Cause**: [what triggers this]\n"
                "- **Diagnose**: [how to tell what's wrong]\n"
                "- **Fix**: [what resolves it]"
            )

    return "\n".join(sections)
