// Copyright (c) 2025 Charlie Vanaret
// Licensed under the MIT license. See LICENSE file in the project directory for details.

#ifndef UNO_INEQUALITYCONSTRAINEDSOLVER_H
#define UNO_INEQUALITYCONSTRAINEDSOLVER_H

namespace uno {
   // forward declarations
   class Direction;
   class Evaluations;
   class SolverWorkspace;
   class Statistics;
   class Subproblem;
   template <typename ElementType>
   class Vector;
   class WarmstartInformation;

   class InequalityConstrainedSolver {
   public:
      InequalityConstrainedSolver() = default;
      virtual ~InequalityConstrainedSolver() = default;

      virtual void initialize_memory(const Subproblem& subproblem) = 0;

      virtual void solve(Statistics& statistics, Subproblem& subproblem, double trust_region_radius,
         const Vector<double>& initial_point, Direction& direction, Evaluations& current_evaluations,
         const WarmstartInformation& warmstart_information) = 0;

      [[nodiscard]] virtual SolverWorkspace& get_workspace() = 0;
   };
} // namespace

#endif // UNO_INEQUALITYCONSTRAINEDSOLVER_H