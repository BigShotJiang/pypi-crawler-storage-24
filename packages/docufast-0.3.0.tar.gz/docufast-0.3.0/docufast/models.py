from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

@dataclass
class Workspace:
    id: str
    name: str
    description: Optional[str] = None
    workspace_type: Optional[str] = None

@dataclass
class Collection:
    id: str
    name: str
    description: Optional[str] = None
    collection_type: Optional[str] = None

@dataclass
class Document:
    id: str
    name: str
    type: Optional[str] = None
    file_path: Optional[str] = None
    download_url: Optional[str] = None
    external_metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: Optional[str] = None
    last_updated: Optional[str] = None

@dataclass
class MediaItem:
    id: str
    name: str
    file_path: Optional[str] = None
    download_url: Optional[str] = None
    description: Optional[str] = None
    mime_type: Optional[str] = None
    file_size: Optional[int] = None
    external_metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: Optional[str] = None
    last_updated: Optional[str] = None

@dataclass
class Note:
    id: str
    name: str
    data: Optional[str] = None
    external_metadata: Dict[str, Any] = field(default_factory=dict)
    created_at: Optional[str] = None
    last_updated: Optional[str] = None
