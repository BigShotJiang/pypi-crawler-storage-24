class DocufastError(Exception):
    def __init__(self, message: str, status_code: int = None, response: dict = None):
        super().__init__(message)
        self.status_code = status_code
        self.response = response

class AuthenticationError(DocufastError):
    pass

class NotFoundError(DocufastError):
    pass

class PermissionError(DocufastError):
    pass

class ValidationError(DocufastError):
    pass
