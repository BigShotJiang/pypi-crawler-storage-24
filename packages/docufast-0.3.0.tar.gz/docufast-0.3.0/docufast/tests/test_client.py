"""Tests for the Docufast client."""
from docufast import Docufast


def test_client_init(api_key, base_url):
    client = Docufast(api_key=api_key, base_url=base_url)
    assert client.workspaces is not None
    assert client.collections is not None
    assert client.documents is not None
    assert client.images is not None
    assert client.audio is not None
    assert client.videos is not None
    assert client.notes is not None
    assert client.entities is not None
    assert client.locations is not None
    client.close()


def test_client_context_manager(api_key, base_url):
    with Docufast(api_key=api_key, base_url=base_url) as client:
        assert client.workspaces is not None


def test_client_default_base_url(api_key):
    client = Docufast(api_key=api_key)
    assert "docufa.st" in client._client.base_url.host
    client.close()
