"""Test that all public modules import correctly."""


def test_import_client():
    from docufast import Docufast
    assert Docufast is not None


def test_import_exceptions():
    from docufast.exceptions import (
        AuthenticationError,
        DocufastError,
        NotFoundError,
        PermissionError,
        ValidationError,
    )
    assert DocufastError is not None
    assert AuthenticationError is not None
    assert NotFoundError is not None
    assert PermissionError is not None
    assert ValidationError is not None


def test_import_models():
    from docufast.models import Collection, Document, MediaItem, Note, Workspace
    assert Workspace is not None
    assert Collection is not None
    assert Document is not None
    assert MediaItem is not None
    assert Note is not None


def test_import_resources():
    from docufast.resources import (
        AudioResource,
        CollectionsResource,
        DocumentsResource,
        EntitiesResource,
        ImagesResource,
        LocationsResource,
        NotesResource,
        VideosResource,
        WorkspacesResource,
    )
    assert WorkspacesResource is not None
    assert EntitiesResource is not None
    assert LocationsResource is not None
