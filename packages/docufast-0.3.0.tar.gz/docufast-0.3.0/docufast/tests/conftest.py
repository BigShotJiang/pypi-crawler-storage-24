import pytest


@pytest.fixture
def api_key():
    return "df_sdk_test_key_12345"


@pytest.fixture
def base_url():
    return "http://localhost:5001"
