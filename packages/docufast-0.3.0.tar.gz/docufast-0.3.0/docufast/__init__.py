from .client import Docufast

__all__ = ["Docufast"]
__version__ = "0.1.0"
