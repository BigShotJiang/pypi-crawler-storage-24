import httpx
from .resources import (
    AudioResource,
    CollectionsResource,
    DocumentsResource,
    EntitiesResource,
    ImagesResource,
    LocationsResource,
    NotesResource,
    VideosResource,
    WorkspacesResource,
)

class Docufast:
    def __init__(
        self,
        api_key: str,
        base_url: str = "https://api.docufa.st",
        timeout: float = 30.0,
    ):
        self._client = httpx.Client(
            base_url=base_url.rstrip("/"),
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=timeout,
        )
        self.workspaces = WorkspacesResource(self._client)
        self.collections = CollectionsResource(self._client)
        self.documents = DocumentsResource(self._client)
        self.images = ImagesResource(self._client)
        self.audio = AudioResource(self._client)
        self.videos = VideosResource(self._client)
        self.notes = NotesResource(self._client)
        self.entities = EntitiesResource(self._client)
        self.locations = LocationsResource(self._client)

    def close(self):
        self._client.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
