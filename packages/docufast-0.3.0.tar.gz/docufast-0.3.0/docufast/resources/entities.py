from typing import Any, Dict, List, Optional
from .base import BaseResource


class EntitiesResource(BaseResource):
    def list(self) -> List[dict]:
        return self._request("GET", "/api/v1/sdk/entities")

    def create(
        self, name: str, entity_type: Optional[str] = None, description: Optional[str] = None
    ) -> dict:
        return self._request(
            "POST", "/api/v1/sdk/entities",
            json={"name": name, "entity_type": entity_type, "description": description},
        )

    def get(self, entity_id: str) -> dict:
        return self._request("GET", f"/api/v1/sdk/entities/{entity_id}")

    def delete(self, entity_id: str) -> dict:
        return self._request("DELETE", f"/api/v1/sdk/entities/{entity_id}")

    def link_to_document(
        self, document_id: str, sender_entity_id: Optional[str] = None,
        receiver_entity_id: Optional[str] = None,
    ) -> dict:
        return self._request(
            "POST", f"/api/v1/sdk/documents/{document_id}/entities",
            json={"sender_entity_id": sender_entity_id, "receiver_entity_id": receiver_entity_id},
        )
