from typing import List, Optional
from .base import BaseResource


class LocationsResource(BaseResource):
    def list(self) -> List[dict]:
        return self._request("GET", "/api/v1/sdk/locations")

    def create(
        self, name: str, is_physical: bool = True, location: Optional[str] = None
    ) -> dict:
        return self._request(
            "POST", "/api/v1/sdk/locations",
            json={"name": name, "is_physical": is_physical, "location": location},
        )

    def get(self, location_id: str) -> dict:
        return self._request("GET", f"/api/v1/sdk/locations/{location_id}")

    def delete(self, location_id: str) -> dict:
        return self._request("DELETE", f"/api/v1/sdk/locations/{location_id}")

    def link_to_document(self, document_id: str, location_id: str) -> dict:
        return self._request(
            "POST", f"/api/v1/sdk/documents/{document_id}/locations",
            json={"location_id": location_id},
        )
