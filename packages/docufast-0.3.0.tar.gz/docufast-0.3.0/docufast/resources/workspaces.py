from typing import List
from ..models import Workspace
from .base import BaseResource

class WorkspacesResource(BaseResource):
    def list(self) -> List[Workspace]:
        data = self._request("GET", "/api/v1/sdk/workspaces")
        return [Workspace(**ws) for ws in data]
