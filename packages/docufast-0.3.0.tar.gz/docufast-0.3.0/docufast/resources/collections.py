from typing import Any, Dict, List, Optional
from ..models import Collection
from .base import BaseResource

class CollectionsResource(BaseResource):
    def list(self, workspace_id: str) -> List[Collection]:
        data = self._request("GET", f"/api/v1/sdk/workspaces/{workspace_id}/collections")
        return [Collection(**c) for c in data]

    def create(
        self,
        workspace_id: str,
        name: str,
        description: Optional[str] = None,
        collection_type: Optional[str] = None,
    ) -> Collection:
        data = self._request(
            "POST",
            f"/api/v1/sdk/workspaces/{workspace_id}/collections",
            json={"name": name, "description": description, "collection_type": collection_type},
        )
        return Collection(**data)

    def delete(self, collection_id: str) -> dict:
        return self._request("DELETE", f"/api/v1/sdk/collections/{collection_id}")
