from typing import Any, Dict, Optional
from ..models import Note
from .base import BaseResource

class NotesResource(BaseResource):
    def create(
        self,
        collection_id: str,
        name: str,
        data: str = "",
        external_metadata: Optional[Dict[str, Any]] = None,
    ) -> Note:
        result = self._request(
            "POST",
            f"/api/v1/sdk/collections/{collection_id}/notes",
            json={
                "name": name,
                "data": data,
                "external_metadata": external_metadata or {},
            },
        )
        return Note(**result)

    def get(self, note_id: str) -> Note:
        result = self._request("GET", f"/api/v1/sdk/notes/{note_id}")
        return Note(**result)

    def update_metadata(self, note_id: str, external_metadata: Dict[str, Any]) -> Note:
        result = self._request(
            "PUT", f"/api/v1/sdk/notes/{note_id}/metadata",
            json={"external_metadata": external_metadata},
        )
        return Note(**result)

    def delete(self, note_id: str) -> dict:
        return self._request("DELETE", f"/api/v1/sdk/notes/{note_id}")
