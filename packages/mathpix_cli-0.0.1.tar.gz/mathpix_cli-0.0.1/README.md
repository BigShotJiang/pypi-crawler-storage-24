# mathpix-cli

Mathpix CLI for PDF conversion and image snips.

## Usage

```bash
# Convert a local PDF
uvx mathpix-cli convert pdf path ./path/to/file.pdf

# Convert a PDF from a URL
uvx mathpix-cli convert pdf url https://example.com/file.pdf

# Snip an image
uvx mathpix-cli snip image ./path/to/equation.png

# Show all commands
uvx mathpix-cli --help
```

## Output Layout

Outputs are saved under `~/.mathpix-cli/`.

```text
~/.mathpix-cli/
├── history.json
├── converts/
│   └── {format}/
│       └── {sha256_16}/
│           ├── main.{ext}
│           ├── original.{ext}
│           └── images/
└── snips/
    └── {format}/
        └── {sha256_16}/
            ├── main.{ext}
            └── {fingerprint}/
                └── main.{ext}
```

## Configuration

Config path follows the XDG Base Directory Specification:

```text
~/.config/mathpix-cli/config.toml
```

See [`config.example.toml`](config.example.toml) for all available options.

## Development

```bash
just setup-dev
```

### Tooling

- Runtime: [uv](https://docs.astral.sh/uv/)
- JS/TS: [Biome](https://biomejs.dev/)
- Python: [Ruff](https://docs.astral.sh/ruff/), [mypy](https://mypy-lang.org/), [pytest](https://docs.pytest.org/), [Poe](https://github.com/nat-n/poethepoet)
- Project template: [Copier](https://copier.readthedocs.io/)
- Task runner: [just](https://github.com/casey/just)
- Git hooks: [Lefthook](https://github.com/evilmartians/lefthook)

## Dependencies

Automated via [Renovate](https://docs.renovatebot.com/).
Dependency update PRs are created automatically.

## Release

Automated via [release-please](https://github.com/googleapis/release-please).
Merge the auto-generated Release PR to bump version, update [`CHANGELOG.md`](CHANGELOG.md), and create a tag.
