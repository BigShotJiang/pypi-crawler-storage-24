# Changelog

## 0.0.1 (2026-03-24)


### Chores

* add runtime dependencies ([01ab44d](https://github.com/falcon0387/mathpix-cli/commit/01ab44d797b2cb0f39ea45ec8359243d40a7654b))
* remove template test ([bb8c7f1](https://github.com/falcon0387/mathpix-cli/commit/bb8c7f13de0e5b85da79ac9e10e870900ae9c8f2))


### Features

* implement convert and snip CLI ([1af3411](https://github.com/falcon0387/mathpix-cli/commit/1af3411c596266ef4225a057e07654c0fcf65021))
* initial release ([33d5458](https://github.com/falcon0387/mathpix-cli/commit/33d5458146dff10a0aff074c79215283ae0c6a7b))
