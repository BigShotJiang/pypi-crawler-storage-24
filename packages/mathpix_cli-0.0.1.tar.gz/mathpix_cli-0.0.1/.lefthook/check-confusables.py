#!/usr/bin/env python3
"""Detect Unicode characters that are visually confusable with ASCII."""

from __future__ import annotations

import sys
from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class CodepointRange:
    """An inclusive Unicode codepoint range."""

    start: int
    end: int


@dataclass(frozen=True)
class Category:
    """A group of related confusable characters."""

    name: str
    hint: str
    ranges: tuple[CodepointRange, ...]


@dataclass(frozen=True)
class LineMatch:
    """A source line containing at least one confusable character."""

    line_number: int
    line: str


@dataclass(frozen=True)
class CategoryReport:
    """Matches for one confusable-character category within a file."""

    category: Category
    matches: tuple[LineMatch, ...]


def _parse_codepoint_spec(spec: str) -> CodepointRange:
    if "-" not in spec:
        value = int(spec, 16)
        return CodepointRange(start=value, end=value)

    start_text, end_text = spec.split("-", maxsplit=1)
    return CodepointRange(start=int(start_text, 16), end=int(end_text, 16))


def _parse_ranges(*specs: str) -> tuple[CodepointRange, ...]:
    return tuple(_parse_codepoint_spec(spec) for spec in specs)


CATEGORIES: tuple[Category, ...] = (
    Category(
        name="Spaces / invisible characters",
        hint="Remove invisible or non-standard space characters.",
        ranges=_parse_ranges(
            "00A0",
            "00AD",
            "2000-200A",
            "200B-200D",
            "202F",
            "205F",
            "2060",
            "3000",
            "FEFF",
        ),
    ),
    Category(
        name="Dashes",
        hint="Rephrase the sentence without dashes.",
        ranges=_parse_ranges("2010-2015", "2212"),
    ),
    Category(
        name="Quotes / accents",
        hint="Use straight quotes (' and \") instead of smart quotes.",
        ranges=_parse_ranges("00B4", "2018-2019", "201C-201D", "2032-2033"),
    ),
    Category(
        name="Ellipsis",
        hint="Use three dots (...) instead of the ellipsis character.",
        ranges=_parse_ranges("2026"),
    ),
    Category(
        name="Bidi control characters",
        hint="Remove bidirectional control characters (potential Trojan Source attack).",
        ranges=_parse_ranges("202A-202E", "2066-2069"),
    ),
)


def is_confusable(character: str, ranges: tuple[CodepointRange, ...]) -> bool:
    """Return whether a character falls within any configured range.

    Returns:
        `True` when the character is within at least one configured range.
    """
    codepoint = ord(character)
    return any(
        codepoint_range.start <= codepoint <= codepoint_range.end for codepoint_range in ranges
    )


def find_line_matches(text: str, ranges: tuple[CodepointRange, ...]) -> tuple[LineMatch, ...]:
    """Return lines containing characters from the configured ranges.

    Returns:
        A tuple of matching lines with their 1-based line numbers.
    """
    return tuple(
        LineMatch(line_number=line_number, line=line)
        for line_number, line in enumerate(text.splitlines(), start=1)
        if any(is_confusable(character, ranges) for character in line)
    )


def read_text_file(path: Path) -> str | None:
    """Read a UTF-8 text file, skipping binary files.

    Returns:
        The decoded text, or `None` when the file appears to be binary.
    """
    data = path.read_bytes()
    if b"\0" in data:
        return None
    return data.decode("utf-8", errors="replace")


def scan_file(path: Path, categories: tuple[Category, ...]) -> tuple[CategoryReport, ...]:
    """Scan one file and collect matches grouped by category.

    Returns:
        A tuple of reports for categories that matched the file contents.
    """
    text = read_text_file(path)
    if text is None:
        return ()

    reports: list[CategoryReport] = []
    for category in categories:
        matches = find_line_matches(text, category.ranges)
        if matches:
            reports.append(CategoryReport(category=category, matches=matches))
    return tuple(reports)


def format_report(path: Path, report: CategoryReport) -> str:
    """Format one category report for terminal output.

    Returns:
        A multi-line string ready to print to stderr.
    """
    lines = [f"  [{report.category.name}]"]
    lines.extend(f"    {path}:{match.line_number}:{match.line}" for match in report.matches)
    lines.append(f"    -> {report.category.hint}")
    return "\n".join(lines)


def collect_reports(paths: tuple[Path, ...], categories: tuple[Category, ...]) -> tuple[str, ...]:
    """Collect formatted reports for all matching files.

    Returns:
        A tuple of formatted report blocks.
    """
    reports: list[str] = []

    for path in paths:
        if not path.is_file():
            continue
        reports.extend(format_report(path, report) for report in scan_file(path, categories))

    return tuple(reports)


def main(argv: list[str]) -> int:
    """Run the confusable-character check for the provided paths.

    Returns:
        Zero when no issues are found, otherwise one.
    """
    paths = tuple(Path(argument) for argument in argv)

    try:
        reports = collect_reports(paths, CATEGORIES)
    except OSError as error:
        print(error, file=sys.stderr)
        return 1

    if not reports:
        return 0

    print("Error: Unicode confusable characters detected:\n", file=sys.stderr)
    print("\n\n".join(reports), file=sys.stderr)
    print("If intentional, bypass with: git commit --no-verify", file=sys.stderr)
    return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
