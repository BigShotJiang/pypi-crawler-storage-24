#!/bin/bash
# Ensure files with a shebang (#!) are executable.

# Return the git index mode (e.g. 100644, 100755, 120000) for a file.
git_mode() {
  git ls-files -s -- "$1" | cut -d' ' -f1
}

# Check whether a file starts with a shebang (#!).
has_shebang() {
  local magic
  read -rN2 magic < "$1" 2>/dev/null
  [[ "$magic" == "#!" ]]
}

main() {
  local status=0
  for file in "$@"; do
    if [[ "$(git_mode "$file")" == "100644" ]] && has_shebang "$file"; then
      printf '%s: has shebang (#!) but not marked executable\n' "$file"
      status=1
    fi
  done
  return "$status"
}

main "$@"
