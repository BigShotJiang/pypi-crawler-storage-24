from __future__ import annotations

from dataclasses import replace

import httpx
from mathpix_cli.shared.config import (
    AppConfig,
    BackendMode,
    MathpixV1Credentials,
    MathpixV3Credentials,
)
from mathpix_cli.shared.resolver import ResolvedBackend
from mathpix_cli.snip.providers.mathpix_v1 import MathpixV1SnipConverter
from mathpix_cli.snip.providers.mathpix_v3 import MathpixV3SnipConverter
from mathpix_cli.snip.resolver import build_plan, build_use_case


def auth_value() -> str:
    return "test-token"


def test_build_plan_uses_v1_in_auto_mode_when_v1_available() -> None:
    plan = build_plan(
        AppConfig(
            v3=MathpixV3Credentials(app_id="id", app_key="key"),
            v1=MathpixV1Credentials(token=auth_value()),
        )
    )

    assert plan.backend is ResolvedBackend.MATHPIX_V1
    assert plan.summary_label == "mathpix-v1 -> latex"


def test_build_plan_uses_v3_when_only_v3_is_available() -> None:
    plan = build_plan(
        AppConfig(
            v3=MathpixV3Credentials(app_id="id", app_key="key"),
            v1=None,
        )
    )

    assert plan.backend is ResolvedBackend.MATHPIX_V3
    assert plan.summary_label == "mathpix-v3 -> latex"


def test_build_use_case_requires_explicit_v1_credentials() -> None:
    client = httpx.AsyncClient()
    result = build_use_case(
        AppConfig(
            v3=None,
            v1=None,
        ),
        client,
    )

    assert result.ok is False
    assert result.error is not None
    assert "no backend is configured" in result.error.message


def test_build_use_case_selects_v1_converter_in_auto_mode() -> None:
    client = httpx.AsyncClient()
    result = build_use_case(
        AppConfig(
            v3=MathpixV3Credentials(app_id="id", app_key="key"),
            v1=MathpixV1Credentials(token=auth_value()),
        ),
        client,
    )

    assert result.ok is True
    assert result.value is not None
    assert isinstance(result.value.converter, MathpixV1SnipConverter)
    assert result.value.converter.client is client


def test_build_use_case_selects_api_converter_when_requested() -> None:
    config = AppConfig(
        v3=MathpixV3Credentials(app_id="id", app_key="key"),
        v1=MathpixV1Credentials(token=auth_value()),
    )
    config = replace(
        config,
        snip=config.snip.__class__(
            format=config.snip.format,
            mode=BackendMode.V3,
            options=config.snip.options,
            show_result=config.snip.show_result,
        ),
    )

    client = httpx.AsyncClient()
    result = build_use_case(config, client)

    assert result.ok is True
    assert result.value is not None
    assert isinstance(result.value.converter, MathpixV3SnipConverter)
    assert result.value.converter.client is client


def test_build_use_case_requires_explicit_v1_credentials_when_requested() -> None:
    config = AppConfig(
        v3=MathpixV3Credentials(app_id="id", app_key="key"),
        v1=None,
    )
    config = replace(
        config,
        snip=config.snip.__class__(
            format=config.snip.format,
            mode=BackendMode.V1,
            options=config.snip.options,
            show_result=config.snip.show_result,
        ),
    )

    result = build_use_case(config, httpx.AsyncClient())

    assert result.ok is False
    assert result.error is not None
    assert "mathpix-v1 backend" in result.error.message


def test_build_use_case_selects_v3_converter_when_only_v3_is_available() -> None:
    client = httpx.AsyncClient()
    result = build_use_case(
        AppConfig(
            v3=MathpixV3Credentials(app_id="id", app_key="key"),
            v1=None,
        ),
        client,
    )

    assert result.ok is True
    assert result.value is not None
    assert isinstance(result.value.converter, MathpixV3SnipConverter)
    assert result.value.converter.client is client
