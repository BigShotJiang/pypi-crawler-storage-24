from __future__ import annotations

import json
from typing import TYPE_CHECKING

import pytest
from mathpix_cli.shared.errors import ErrorCode
from mathpix_cli.snip.model import SnipFormat, SnipOptions
from mathpix_cli.snip.store import FileSystemSnipStore

if TYPE_CHECKING:
    from pathlib import Path


@pytest.mark.anyio
async def test_save_writes_snip_output_and_history(tmp_path: Path) -> None:
    store = FileSystemSnipStore(output_dir=str(tmp_path))

    result = await store.save(
        text="x^2",
        sha256="a" * 64,
        source=str(tmp_path / "image.png"),
        fmt=SnipFormat.LATEX,
        confidence=0.9,
    )

    assert result.ok is True
    assert result.value is not None
    main_path = tmp_path / "snips" / "latex" / ("a" * 16) / "main.tex"
    assert main_path.read_text(encoding="utf-8") == "x^2"
    history = json.loads((tmp_path / "history.json").read_text(encoding="utf-8"))
    assert history["snips"][f"{'a' * 64}:latex"]["source"] == "image.png"


@pytest.mark.anyio
async def test_find_cached_returns_existing_snip_path(tmp_path: Path) -> None:
    sha256 = "b" * 64
    main_path = tmp_path / "snips" / "latex" / ("b" * 16) / "main.tex"
    main_path.parent.mkdir(parents=True)
    main_path.write_text("cached", encoding="utf-8")
    history = {"snips": {f"{sha256}:latex": {"source": "image.png"}}}
    (tmp_path / "history.json").write_text(json.dumps(history), encoding="utf-8")
    store = FileSystemSnipStore(output_dir=str(tmp_path))

    result = await store.find_cached(sha256, SnipFormat.LATEX)

    assert result.ok is True
    assert result.value == str(main_path.resolve())


@pytest.mark.anyio
async def test_find_cached_returns_none_when_history_has_no_snips(tmp_path: Path) -> None:
    (tmp_path / "history.json").write_text(json.dumps({"converts": {}}), encoding="utf-8")
    store = FileSystemSnipStore(output_dir=str(tmp_path))

    result = await store.find_cached("c" * 64, SnipFormat.LATEX)

    assert result.ok is True
    assert result.value is None


@pytest.mark.anyio
async def test_find_cached_returns_error_when_history_json_is_invalid(tmp_path: Path) -> None:
    (tmp_path / "history.json").write_text("{", encoding="utf-8")
    store = FileSystemSnipStore(output_dir=str(tmp_path))

    result = await store.find_cached("d" * 64, SnipFormat.LATEX)

    assert result.ok is False
    assert result.error is not None
    assert result.error.code is ErrorCode.IO
    assert "Failed to read history" in result.error.message


@pytest.mark.anyio
async def test_different_options_produce_separate_cache_entries(tmp_path: Path) -> None:
    store = FileSystemSnipStore(output_dir=str(tmp_path))
    opts_a = SnipOptions(rm_fonts=True)
    opts_b = SnipOptions(rm_fonts=False)
    sha256 = "e" * 64

    await store.save(
        text="with rm_fonts",
        sha256=sha256,
        source="img.png",
        fmt=SnipFormat.LATEX,
        confidence=0.9,
        options=opts_a,
    )
    await store.save(
        text="without rm_fonts",
        sha256=sha256,
        source="img.png",
        fmt=SnipFormat.LATEX,
        confidence=0.8,
        options=opts_b,
    )

    result_a = await store.find_cached(sha256, SnipFormat.LATEX, options=opts_a)
    result_b = await store.find_cached(sha256, SnipFormat.LATEX, options=opts_b)

    assert result_a.ok is True
    assert result_b.ok is True
    assert result_a.value is not None
    assert result_b.value is not None
    assert result_a.value != result_b.value
