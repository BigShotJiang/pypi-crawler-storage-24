"""Snip module tests."""
