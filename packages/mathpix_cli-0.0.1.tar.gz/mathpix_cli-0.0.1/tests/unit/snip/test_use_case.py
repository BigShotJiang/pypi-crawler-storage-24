from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import pytest
from mathpix_cli.shared.errors import ErrorCode
from mathpix_cli.shared.result import Result
from mathpix_cli.snip.model import SnipFormat, SnipOptions, SnipOutcome, SnipRequest
from mathpix_cli.snip.use_case import SnipUseCase

if TYPE_CHECKING:
    from pathlib import Path


@dataclass
class FakeSnipConverter:
    outcome: SnipOutcome
    error: str | None = None
    calls: list[tuple[bytes, SnipFormat, SnipOptions | None]] = field(default_factory=list)

    async def snip(
        self,
        image: bytes,
        fmt: SnipFormat,
        *,
        options: SnipOptions | None = None,
    ) -> Result[SnipOutcome]:
        self.calls.append((image, fmt, options))
        if self.error is not None:
            return Result.failure(ErrorCode.NETWORK, self.error)
        return Result.success(self.outcome)


@dataclass
class FakeSnipStore:
    output_path: str
    cached_path: str | None = None
    cache_error: str | None = None
    save_error: str | None = None
    saves: list[tuple[str, str, str, SnipFormat, float]] = field(default_factory=list)

    async def find_cached(
        self, sha256: str, fmt: SnipFormat, *, options: SnipOptions | None = None
    ) -> Result[str | None]:
        _ = (sha256, fmt, options)
        if self.cache_error is not None:
            return Result.failure(ErrorCode.IO, self.cache_error)
        return Result.success(self.cached_path)

    async def save(
        self,
        *,
        text: str,
        sha256: str,
        source: str,
        fmt: SnipFormat,
        confidence: float,
        options: SnipOptions | None = None,
    ) -> Result[str]:
        self.saves.append((text, sha256, source, fmt, confidence))
        if self.save_error is not None:
            return Result.failure(ErrorCode.IO, self.save_error)
        return Result.success(self.output_path)


DEFAULT_OUTCOME = SnipOutcome(
    confidence=0.95,
    format=SnipFormat.LATEX,
    snip_id="snip-001",
    text="x^2 + y^2 = z^2",
)


def write_png(tmp_path: Path, name: str = "input.png") -> str:
    image_path = tmp_path / name
    image_path.write_bytes(b"\x89PNG\r\n\x1a\n" + b"\x00" * 16)
    return str(image_path)


@pytest.mark.anyio
async def test_execute_snips_image_and_saves_result(tmp_path: Path) -> None:
    image_path = write_png(tmp_path)
    options = SnipOptions(rm_fonts=True)
    converter = FakeSnipConverter(outcome=DEFAULT_OUTCOME)
    store = FakeSnipStore(output_path=str(tmp_path / "main.tex"))
    use_case = SnipUseCase(converter=converter, store=store)

    result = await use_case.execute(
        SnipRequest(format=SnipFormat.LATEX, image_path=image_path, options=options)
    )

    assert result.ok is True
    assert result.value is not None
    assert result.value.cache_hit is False
    assert result.value.outcome == DEFAULT_OUTCOME
    assert result.value.path == str(tmp_path / "main.tex")
    assert converter.calls[0][1] is SnipFormat.LATEX
    assert converter.calls[0][2] == options
    assert len(store.saves) == 1


@pytest.mark.anyio
async def test_execute_returns_cached_snip_without_conversion(tmp_path: Path) -> None:
    image_path = write_png(tmp_path)
    converter = FakeSnipConverter(outcome=DEFAULT_OUTCOME)
    store = FakeSnipStore(
        output_path=str(tmp_path / "unused.tex"),
        cached_path=str(tmp_path / "cached.tex"),
    )
    use_case = SnipUseCase(converter=converter, store=store)

    result = await use_case.execute(SnipRequest(format=SnipFormat.LATEX, image_path=image_path))

    assert result.ok is True
    assert result.value is not None
    assert result.value.cache_hit is True
    assert result.value.path == str(tmp_path / "cached.tex")
    assert result.value.outcome is None
    assert converter.calls == []
    assert store.saves == []


@pytest.mark.anyio
async def test_execute_rejects_unsupported_image_format(tmp_path: Path) -> None:
    image_path = tmp_path / "input.xyz"
    image_path.write_bytes(b"fake data")
    use_case = SnipUseCase(
        converter=FakeSnipConverter(outcome=DEFAULT_OUTCOME),
        store=FakeSnipStore(output_path=str(tmp_path / "main.tex")),
    )

    result = await use_case.execute(
        SnipRequest(format=SnipFormat.LATEX, image_path=str(image_path))
    )

    assert result.ok is False
    assert result.error is not None
    assert "Unsupported image format" in result.error.message


@pytest.mark.anyio
async def test_execute_rejects_missing_image(tmp_path: Path) -> None:
    use_case = SnipUseCase(
        converter=FakeSnipConverter(outcome=DEFAULT_OUTCOME),
        store=FakeSnipStore(output_path=str(tmp_path / "main.tex")),
    )

    result = await use_case.execute(
        SnipRequest(format=SnipFormat.LATEX, image_path=str(tmp_path / "missing.png"))
    )

    assert result.ok is False
    assert result.error is not None
    assert "File not found" in result.error.message


@pytest.mark.anyio
async def test_execute_wraps_cache_lookup_failure(tmp_path: Path) -> None:
    image_path = write_png(tmp_path)
    use_case = SnipUseCase(
        converter=FakeSnipConverter(outcome=DEFAULT_OUTCOME),
        store=FakeSnipStore(output_path=str(tmp_path / "main.tex"), cache_error="cache failed"),
    )

    result = await use_case.execute(SnipRequest(format=SnipFormat.LATEX, image_path=image_path))

    assert result.ok is False
    assert result.error is not None
    assert "Cache lookup failed" in result.error.message


@pytest.mark.anyio
async def test_execute_forwards_converter_failure(tmp_path: Path) -> None:
    image_path = write_png(tmp_path)
    use_case = SnipUseCase(
        converter=FakeSnipConverter(outcome=DEFAULT_OUTCOME, error="snip failed"),
        store=FakeSnipStore(output_path=str(tmp_path / "main.tex")),
    )

    result = await use_case.execute(SnipRequest(format=SnipFormat.LATEX, image_path=image_path))

    assert result.ok is False
    assert result.error is not None
    assert result.error.message == "snip failed"


@pytest.mark.anyio
async def test_execute_forwards_save_failure(tmp_path: Path) -> None:
    image_path = write_png(tmp_path)
    use_case = SnipUseCase(
        converter=FakeSnipConverter(outcome=DEFAULT_OUTCOME),
        store=FakeSnipStore(output_path=str(tmp_path / "main.tex"), save_error="save failed"),
    )

    result = await use_case.execute(SnipRequest(format=SnipFormat.LATEX, image_path=image_path))

    assert result.ok is False
    assert result.error is not None
    assert result.error.message == "save failed"
