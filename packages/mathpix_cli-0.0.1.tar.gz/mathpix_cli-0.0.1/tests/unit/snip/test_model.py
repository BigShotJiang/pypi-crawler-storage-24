from __future__ import annotations

import pytest
from mathpix_cli.snip.model import SnipOptions, detect_image_mime, mime_extension


@pytest.mark.parametrize(
    ("header", "expected"),
    [
        (b"\x89PNG\r\n\x1a\n" + b"\x00" * 8, "image/png"),
        (b"RIFF\x00\x00\x00\x00WEBP", "image/webp"),
        (b"GIF89a", "image/gif"),
        (b"BM\x00\x00", "image/bmp"),
        (b"II\x2a\x00", "image/tiff"),
        (b"MM\x00\x2a", "image/tiff"),
        (b"\xff\xd8\xff\xe0", "image/jpeg"),
    ],
    ids=["png", "webp", "gif", "bmp", "tiff-le", "tiff-be", "jpeg"],
)
def test_detect_image_mime(header: bytes, expected: str) -> None:
    assert detect_image_mime(header) == expected


def test_detect_image_mime_returns_none_for_unknown() -> None:
    assert detect_image_mime(b"\x00\x00\x00\x00") is None


@pytest.mark.parametrize(
    ("mime", "expected"),
    [
        ("image/png", ".png"),
        ("image/jpeg", ".jpg"),
        ("image/webp", ".webp"),
        ("image/gif", ".gif"),
        ("image/bmp", ".bmp"),
        ("image/tiff", ".tiff"),
        ("application/octet-stream", ".jpg"),
    ],
    ids=["png", "jpeg", "webp", "gif", "bmp", "tiff", "unknown"],
)
def test_mime_extension(mime: str, expected: str) -> None:
    assert mime_extension(mime) == expected


def test_snip_options_fingerprint_is_stable() -> None:
    opts = SnipOptions(rm_fonts=True, include_chemistry=True)
    assert opts.fingerprint() == opts.fingerprint()
    assert len(opts.fingerprint()) == 12


def test_snip_options_fingerprint_differs_for_different_options() -> None:
    a = SnipOptions(rm_fonts=True)
    b = SnipOptions(rm_fonts=False)
    assert a.fingerprint() != b.fingerprint()
