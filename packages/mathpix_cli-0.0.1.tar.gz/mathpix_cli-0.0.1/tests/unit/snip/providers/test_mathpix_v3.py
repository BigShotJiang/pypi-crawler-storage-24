from __future__ import annotations

import json
from typing import TYPE_CHECKING

import httpx
import pytest
from anyio import lowlevel
from mathpix_cli.shared.config import MathpixV3Credentials
from mathpix_cli.snip.model import SnipFormat, SnipOptions
from mathpix_cli.snip.providers.mathpix_v3 import MathpixV3SnipConverter

if TYPE_CHECKING:
    from _pytest.monkeypatch import MonkeyPatch

BASE_URL = "https://api.mathpix.com/v3"


def make_converter() -> MathpixV3SnipConverter:
    return MathpixV3SnipConverter(
        config=MathpixV3Credentials(app_id="id", app_key="key", base_url=BASE_URL),
        client=httpx.AsyncClient(),
    )


@pytest.mark.anyio
async def test_snip_latex_uses_latex_styled_and_returns_outcome(monkeypatch: MonkeyPatch) -> None:
    converter = make_converter()
    seen_options: dict[str, object] = {}

    async def mock_request(
        self: httpx.AsyncClient,
        method: str,
        url: str,
        **kwargs: object,
    ) -> httpx.Response:
        _ = self
        await lowlevel.checkpoint()
        request = httpx.Request(method, url)
        seen_options.update(json.loads(str((kwargs["data"])["options_json"])))  # type: ignore[index]
        return httpx.Response(
            200,
            request=request,
            json={
                "latex_styled": "x^2",
                "confidence": 0.9,
                "request_id": "req-1",
            },
        )

    monkeypatch.setattr(httpx.AsyncClient, "request", mock_request)

    result = await converter.snip(
        b"\xff\xd8\xff\xe0", SnipFormat.LATEX, options=SnipOptions(rm_fonts=True)
    )

    assert result.ok is True
    assert result.value is not None
    assert result.value.text == "x^2"
    assert result.value.confidence == pytest.approx(0.9)
    assert result.value.snip_id == "req-1"
    assert seen_options["formats"] == ["latex_styled"]
    assert seen_options["rm_fonts"] is True


@pytest.mark.anyio
async def test_snip_asciimath_reads_value_from_data_entries(monkeypatch: MonkeyPatch) -> None:
    converter = make_converter()

    async def mock_request(
        self: httpx.AsyncClient,
        method: str,
        url: str,
        **kwargs: object,
    ) -> httpx.Response:
        _ = (self, method, url, kwargs)
        await lowlevel.checkpoint()
        request = httpx.Request("POST", f"{BASE_URL}/text")
        return httpx.Response(
            200,
            request=request,
            json={
                "data": [{"type": "asciimath", "value": "sqrt(x)"}],
                "confidence_rate": 0.8,
                "request_id": "req-2",
            },
        )

    monkeypatch.setattr(httpx.AsyncClient, "request", mock_request)

    result = await converter.snip(b"\xff\xd8\xff\xe0", SnipFormat.ASCIIMATH)

    assert result.ok is True
    assert result.value is not None
    assert result.value.text == "sqrt(x)"
    assert result.value.confidence == pytest.approx(0.8)


@pytest.mark.anyio
async def test_snip_sends_correct_mime_for_png(monkeypatch: MonkeyPatch) -> None:
    converter = make_converter()
    captured_files: dict[str, tuple[str, bytes, str]] = {}

    async def mock_request(
        self: httpx.AsyncClient,
        method: str,
        url: str,
        **kwargs: object,
    ) -> httpx.Response:
        _ = self
        await lowlevel.checkpoint()
        files = kwargs.get("files")
        if isinstance(files, dict):
            captured_files.update(files)
        request = httpx.Request(method, url)
        return httpx.Response(
            200,
            request=request,
            json={"latex_styled": "x", "confidence": 0.9, "request_id": "r"},
        )

    monkeypatch.setattr(httpx.AsyncClient, "request", mock_request)
    png_bytes = b"\x89PNG\r\n\x1a\n" + b"\x00" * 16

    result = await converter.snip(png_bytes, SnipFormat.LATEX)

    assert result.ok is True
    file_tuple = captured_files["file"]
    assert file_tuple[0] == "image.png"
    assert file_tuple[2] == "image/png"


@pytest.mark.anyio
async def test_snip_rejects_unrecognized_image_format() -> None:
    converter = make_converter()

    result = await converter.snip(b"\x00\x00\x00\x00", SnipFormat.LATEX)

    assert result.ok is False
    assert result.error is not None
    assert "Unrecognized image format" in result.error.message


@pytest.mark.anyio
async def test_snip_returns_api_error(monkeypatch: MonkeyPatch) -> None:
    converter = make_converter()

    async def mock_request(
        self: httpx.AsyncClient,
        method: str,
        url: str,
        **kwargs: object,
    ) -> httpx.Response:
        _ = (self, method, url, kwargs)
        await lowlevel.checkpoint()
        request = httpx.Request("POST", f"{BASE_URL}/text")
        return httpx.Response(200, request=request, json={"error": "bad image"})

    monkeypatch.setattr(httpx.AsyncClient, "request", mock_request)

    result = await converter.snip(b"\xff\xd8\xff\xe0", SnipFormat.TEXT)

    assert result.ok is False
    assert result.error is not None
    assert "Snip API error" in result.error.message


@pytest.mark.anyio
async def test_snip_returns_missing_field_error(monkeypatch: MonkeyPatch) -> None:
    converter = make_converter()

    async def mock_request(
        self: httpx.AsyncClient,
        method: str,
        url: str,
        **kwargs: object,
    ) -> httpx.Response:
        _ = (self, method, url, kwargs)
        await lowlevel.checkpoint()
        request = httpx.Request("POST", f"{BASE_URL}/text")
        return httpx.Response(200, request=request, json={"confidence": 0.5})

    monkeypatch.setattr(httpx.AsyncClient, "request", mock_request)

    result = await converter.snip(b"\xff\xd8\xff\xe0", SnipFormat.HTML)

    assert result.ok is False
    assert result.error is not None
    assert "missing 'html' field" in result.error.message
