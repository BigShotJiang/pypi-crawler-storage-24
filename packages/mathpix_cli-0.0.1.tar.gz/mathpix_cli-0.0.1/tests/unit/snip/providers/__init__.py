"""Snip provider tests."""
