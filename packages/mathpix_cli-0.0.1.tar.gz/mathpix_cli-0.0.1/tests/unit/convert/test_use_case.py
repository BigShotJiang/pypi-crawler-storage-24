from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import pytest
from mathpix_cli.convert.model import (
    ConvertRequest,
    OutputFormat,
    SavedConvert,
)
from mathpix_cli.convert.use_case import ConvertUseCase
from mathpix_cli.shared.config import (
    AppConfig,
    BackendMode,
    ConvertSettings,
    MathpixV1Credentials,
)
from mathpix_cli.shared.errors import ErrorCode
from mathpix_cli.shared.result import Result

if TYPE_CHECKING:
    from pathlib import Path


@dataclass
class FakeConverter:
    text: str
    error: str | None = None
    calls: list[tuple[bytes, OutputFormat, str]] = field(default_factory=list)

    async def convert(
        self,
        content: bytes,
        fmt: OutputFormat,
        *,
        filename: str,
        max_polling_time: int,
        max_retries: int,
        polling_interval: int,
    ) -> Result[str]:
        _ = (max_polling_time, max_retries, polling_interval)
        self.calls.append((content, fmt, filename))
        if self.error is not None:
            return Result.failure(ErrorCode.NETWORK, self.error)
        return Result.success(self.text)


@dataclass
class FakeLocalReader:
    payload: bytes = b"%PDF local"
    error: str | None = None
    calls: list[str] = field(default_factory=list)

    async def read(self, absolute_path: Path) -> Result[bytes]:
        self.calls.append(str(absolute_path))
        if self.error is not None:
            return Result.failure(ErrorCode.IO, self.error)
        return Result.success(self.payload)


@dataclass
class FakeRemoteReader:
    payload: bytes = b"%PDF remote"
    error: str | None = None
    calls: list[str] = field(default_factory=list)

    async def read(self, url: str) -> Result[bytes]:
        self.calls.append(url)
        if self.error is not None:
            return Result.failure(ErrorCode.NETWORK, self.error)
        return Result.success(self.payload)


@dataclass
class FakeStore:
    output_path: str
    cached: str | None = None
    cache_error: str | None = None
    save_error: str | None = None
    saved_inputs: list[tuple[str, str, str, OutputFormat]] = field(default_factory=list)

    async def find_cached(self, sha256: str, fmt: OutputFormat) -> Result[str | None]:
        _ = (sha256, fmt)
        if self.cache_error is not None:
            return Result.failure(ErrorCode.IO, self.cache_error)
        return Result.success(self.cached)

    async def save(
        self,
        *,
        text: str,
        sha256: str,
        source: str,
        fmt: OutputFormat,
    ) -> Result[SavedConvert]:
        self.saved_inputs.append((text, sha256, source, fmt))
        if self.save_error is not None:
            return Result.failure(ErrorCode.IO, self.save_error)
        return Result.success(
            SavedConvert(
                format=fmt,
                images_downloaded=0,
                path=self.output_path,
                warnings=(),
            )
        )


def auth_value() -> str:
    return "test-token"


def build_config(
    *,
    output_format: OutputFormat,
    mode: BackendMode = BackendMode.V1,
    max_retries: int = 2,
) -> AppConfig:
    return AppConfig(
        v3=None,
        convert=ConvertSettings(format=output_format, mode=mode, max_retries=max_retries),
        v1=MathpixV1Credentials(token=auth_value()),
    )


def make_use_case(
    *,
    converter: FakeConverter,
    local_reader: FakeLocalReader | None = None,
    remote_reader: FakeRemoteReader | None = None,
    store: FakeStore,
) -> ConvertUseCase:
    return ConvertUseCase(
        converter=converter,
        local_reader=local_reader or FakeLocalReader(),
        remote_reader=remote_reader or FakeRemoteReader(),
        store=store,
    )


@pytest.mark.anyio
async def test_execute_converts_local_pdf(tmp_path: Path) -> None:
    pdf_path = tmp_path / "input.pdf"
    pdf_path.write_bytes(b"%PDF local")
    converter = FakeConverter(text="md-text")
    local_reader = FakeLocalReader(payload=b"%PDF local")
    remote_reader = FakeRemoteReader()
    store = FakeStore(output_path=str(tmp_path / "main.md"))
    use_case = make_use_case(
        converter=converter,
        local_reader=local_reader,
        remote_reader=remote_reader,
        store=store,
    )

    result = await use_case.execute(
        ConvertRequest(is_url=False, source=str(pdf_path)),
        build_config(output_format=OutputFormat.MD),
    )

    assert result.ok is True
    assert result.value is not None
    assert result.value.path == str(tmp_path / "main.md")
    assert result.value.cache_hit is False
    assert local_reader.calls == [str(pdf_path)]
    assert remote_reader.calls == []
    assert len(converter.calls) == 1
    assert len(store.saved_inputs) == 1


@pytest.mark.anyio
async def test_execute_converts_remote_pdf(tmp_path: Path) -> None:
    converter = FakeConverter(text="mmd-text")
    local_reader = FakeLocalReader()
    remote_reader = FakeRemoteReader(payload=b"%PDF remote")
    store = FakeStore(output_path=str(tmp_path / "main.mmd"))
    use_case = make_use_case(
        converter=converter,
        local_reader=local_reader,
        remote_reader=remote_reader,
        store=store,
    )

    result = await use_case.execute(
        ConvertRequest(is_url=True, source="https://example.com/input.pdf"),
        build_config(output_format=OutputFormat.MMD),
    )

    assert result.ok is True
    assert result.value is not None
    assert result.value.format is OutputFormat.MMD
    assert remote_reader.calls == ["https://example.com/input.pdf"]
    assert local_reader.calls == []


@pytest.mark.anyio
async def test_execute_returns_cached_output_without_conversion(tmp_path: Path) -> None:
    cached = str(tmp_path / "cached.md")
    converter = FakeConverter(text="unused")
    store = FakeStore(output_path=str(tmp_path / "unused.md"), cached=cached)
    use_case = make_use_case(converter=converter, store=store)

    result = await use_case.execute(
        ConvertRequest(is_url=False, source=str(tmp_path / "input.pdf")),
        build_config(output_format=OutputFormat.MD),
    )

    assert result.ok is True
    assert result.value is not None
    assert result.value.cache_hit is True
    assert result.value.path == cached
    assert result.value.format is OutputFormat.MD
    assert converter.calls == []
    assert store.saved_inputs == []


@pytest.mark.anyio
async def test_execute_rejects_non_positive_retries(tmp_path: Path) -> None:
    pdf_path = tmp_path / "input.pdf"
    pdf_path.write_bytes(b"%PDF local")
    use_case = make_use_case(
        converter=FakeConverter(text="md-text"),
        store=FakeStore(output_path=str(tmp_path / "main.md")),
    )

    result = await use_case.execute(
        ConvertRequest(is_url=False, source=str(pdf_path)),
        build_config(output_format=OutputFormat.MD, max_retries=0),
    )

    assert result.ok is False
    assert result.error is not None
    assert "max_retries" in result.error.message


@pytest.mark.anyio
async def test_execute_wraps_local_read_failure(tmp_path: Path) -> None:
    pdf_path = tmp_path / "input.pdf"
    pdf_path.write_bytes(b"%PDF local")
    use_case = make_use_case(
        converter=FakeConverter(text="unused"),
        local_reader=FakeLocalReader(error="read failed"),
        store=FakeStore(output_path=str(tmp_path / "main.md")),
    )

    result = await use_case.execute(
        ConvertRequest(is_url=False, source=str(pdf_path)),
        build_config(output_format=OutputFormat.MD),
    )

    assert result.ok is False
    assert result.error is not None
    assert "Failed to read PDF" in result.error.message


@pytest.mark.anyio
async def test_execute_wraps_cache_lookup_failure(tmp_path: Path) -> None:
    pdf_path = tmp_path / "input.pdf"
    pdf_path.write_bytes(b"%PDF local")
    use_case = make_use_case(
        converter=FakeConverter(text="unused"),
        store=FakeStore(output_path=str(tmp_path / "main.md"), cache_error="cache failed"),
    )

    result = await use_case.execute(
        ConvertRequest(is_url=False, source=str(pdf_path)),
        build_config(output_format=OutputFormat.MD),
    )

    assert result.ok is False
    assert result.error is not None
    assert "Failed to load cache" in result.error.message


@pytest.mark.anyio
async def test_execute_wraps_converter_failure(tmp_path: Path) -> None:
    pdf_path = tmp_path / "input.pdf"
    pdf_path.write_bytes(b"%PDF local")
    use_case = make_use_case(
        converter=FakeConverter(text="unused", error="convert failed"),
        store=FakeStore(output_path=str(tmp_path / "main.md")),
    )

    result = await use_case.execute(
        ConvertRequest(is_url=False, source=str(pdf_path)),
        build_config(output_format=OutputFormat.MD),
    )

    assert result.ok is False
    assert result.error is not None
    assert "Failed to convert PDF" in result.error.message


@pytest.mark.anyio
async def test_execute_wraps_save_failure(tmp_path: Path) -> None:
    pdf_path = tmp_path / "input.pdf"
    pdf_path.write_bytes(b"%PDF local")
    use_case = make_use_case(
        converter=FakeConverter(text="md-text"),
        store=FakeStore(output_path=str(tmp_path / "main.md"), save_error="save failed"),
    )

    result = await use_case.execute(
        ConvertRequest(is_url=False, source=str(pdf_path)),
        build_config(output_format=OutputFormat.MD),
    )

    assert result.ok is False
    assert result.error is not None
    assert "Failed to save output" in result.error.message
