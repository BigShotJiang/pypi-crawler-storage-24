from __future__ import annotations

import httpx
from mathpix_cli.convert.model import OutputFormat
from mathpix_cli.convert.providers.mathpix_v1 import MathpixV1PdfConverter
from mathpix_cli.convert.providers.mathpix_v3 import MathpixV3PdfConverter
from mathpix_cli.convert.reader import HttpPdfReader
from mathpix_cli.convert.resolver import build_plan, build_use_case
from mathpix_cli.shared.config import (
    AppConfig,
    BackendMode,
    ConvertSettings,
    MathpixV1Credentials,
    MathpixV3Credentials,
)
from mathpix_cli.shared.resolver import ResolvedBackend


def auth_value() -> str:
    return "test-token"


def test_build_plan_uses_v3_summary_for_v3_mode() -> None:
    plan = build_plan(
        AppConfig(
            v3=MathpixV3Credentials(app_id="id", app_key="key"),
            convert=ConvertSettings(format=OutputFormat.MD, mode=BackendMode.V3),
            v1=None,
        )
    )

    assert plan.backend is ResolvedBackend.MATHPIX_V3
    assert plan.summary_label == "mathpix-v3 -> md"


def test_build_plan_uses_v3_mmd_summary_for_v3_mode() -> None:
    plan = build_plan(
        AppConfig(
            v3=MathpixV3Credentials(app_id="id", app_key="key"),
            convert=ConvertSettings(format=OutputFormat.MMD, mode=BackendMode.V3),
            v1=None,
        )
    )

    assert plan.backend is ResolvedBackend.MATHPIX_V3
    assert plan.summary_label == "mathpix-v3 -> mmd"


def test_build_plan_prefers_v1_in_auto_mode() -> None:
    plan = build_plan(
        AppConfig(
            v3=MathpixV3Credentials(app_id="id", app_key="key"),
            convert=ConvertSettings(format=OutputFormat.MD, mode=BackendMode.AUTO),
            v1=MathpixV1Credentials(token=auth_value()),
        )
    )

    assert plan.backend is ResolvedBackend.MATHPIX_V1
    assert plan.summary_label == "mathpix-v1 -> md"


def test_build_use_case_requires_explicit_v1_credentials() -> None:
    client = httpx.AsyncClient()
    result = build_use_case(
        AppConfig(
            v3=None,
            convert=ConvertSettings(format=OutputFormat.MD, mode=BackendMode.V1),
            v1=None,
        ),
        client,
    )

    assert result.ok is False
    assert result.error is not None
    assert "mathpix-v1 backend" in result.error.message


def test_build_use_case_selects_v1_converter_in_auto_mode() -> None:
    client = httpx.AsyncClient()
    result = build_use_case(
        AppConfig(
            v3=MathpixV3Credentials(app_id="id", app_key="key"),
            convert=ConvertSettings(format=OutputFormat.MD, mode=BackendMode.AUTO),
            v1=MathpixV1Credentials(token=auth_value()),
        ),
        client,
    )

    assert result.ok is True
    assert result.value is not None
    assert isinstance(result.value.converter, MathpixV1PdfConverter)
    assert result.value.converter.client is client
    assert isinstance(result.value.remote_reader, HttpPdfReader)


def test_build_use_case_selects_v3_converter_when_only_v3_is_configured() -> None:
    client = httpx.AsyncClient()
    result = build_use_case(
        AppConfig(
            v3=MathpixV3Credentials(app_id="id", app_key="key"),
            convert=ConvertSettings(format=OutputFormat.MMD, mode=BackendMode.AUTO),
            v1=None,
        ),
        client,
    )

    assert result.ok is True
    assert result.value is not None
    assert isinstance(result.value.converter, MathpixV3PdfConverter)
    assert result.value.converter.client is client


def test_build_use_case_requires_explicit_v3_credentials() -> None:
    client = httpx.AsyncClient()
    result = build_use_case(
        AppConfig(
            v3=None,
            convert=ConvertSettings(format=OutputFormat.MD, mode=BackendMode.V3),
            v1=MathpixV1Credentials(token=auth_value()),
        ),
        client,
    )

    assert result.ok is False
    assert result.error is not None
    assert "mathpix-v3 backend" in result.error.message


def test_build_use_case_requires_any_credentials_in_auto_mode() -> None:
    client = httpx.AsyncClient()
    result = build_use_case(
        AppConfig(
            v3=None,
            convert=ConvertSettings(format=OutputFormat.MD, mode=BackendMode.AUTO),
            v1=None,
        ),
        client,
    )

    assert result.ok is False
    assert result.error is not None
    assert "no backend is configured" in result.error.message
