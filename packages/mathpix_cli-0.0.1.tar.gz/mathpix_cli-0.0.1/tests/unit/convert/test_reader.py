from __future__ import annotations

from typing import TYPE_CHECKING

import httpx
import pytest
from anyio import lowlevel
from mathpix_cli.convert.reader import FileSystemPdfReader, HttpPdfReader

if TYPE_CHECKING:
    from pathlib import Path

    from _pytest.monkeypatch import MonkeyPatch


@pytest.mark.anyio
async def test_file_system_pdf_reader_returns_error_for_missing_file(tmp_path: Path) -> None:
    result = await FileSystemPdfReader().read(tmp_path / "missing.pdf")

    assert result.ok is False
    assert result.error is not None
    assert "not found" in result.error.message


@pytest.mark.anyio
async def test_file_system_pdf_reader_reads_existing_file(tmp_path: Path) -> None:
    pdf_path = tmp_path / "test.pdf"
    pdf_path.write_bytes(b"%PDF-1.4 fake")

    result = await FileSystemPdfReader().read(pdf_path)

    assert result.ok is True
    assert result.value == b"%PDF-1.4 fake"


@pytest.mark.anyio
async def test_file_system_pdf_reader_returns_os_error_from_candidate_read(
    monkeypatch: MonkeyPatch,
    tmp_path: Path,
) -> None:
    pdf_path = tmp_path / "test.pdf"

    async def fake_read_if_exists(path: Path) -> tuple[bytes | None, str | None]:
        _ = path
        await lowlevel.checkpoint()
        return (None, "read failed")

    monkeypatch.setattr(FileSystemPdfReader, "_read_if_exists", staticmethod(fake_read_if_exists))

    result = await FileSystemPdfReader().read(pdf_path)

    assert result.ok is False
    assert result.error is not None
    assert result.error.message == "read failed"


@pytest.mark.anyio
async def test_http_pdf_reader_reads_remote_pdf(monkeypatch: MonkeyPatch) -> None:
    async def fake_request(
        self: httpx.AsyncClient, method: str, url: str, **kwargs: object
    ) -> httpx.Response:
        _ = (self, method, kwargs)
        await lowlevel.checkpoint()
        request = httpx.Request("GET", url)
        return httpx.Response(200, request=request, content=b"%PDF remote")

    monkeypatch.setattr(httpx.AsyncClient, "request", fake_request)

    result = await HttpPdfReader(client=httpx.AsyncClient()).read("https://example.com/input.pdf")

    assert result.ok is True
    assert result.value == b"%PDF remote"


@pytest.mark.anyio
async def test_http_pdf_reader_returns_network_error(monkeypatch: MonkeyPatch) -> None:
    async def fake_request(
        self: httpx.AsyncClient, method: str, url: str, **kwargs: object
    ) -> httpx.Response:
        _ = (self, method, kwargs)
        await lowlevel.checkpoint()
        request = httpx.Request("GET", url)
        raise httpx.ConnectError("offline", request=request)

    monkeypatch.setattr(httpx.AsyncClient, "request", fake_request)

    result = await HttpPdfReader(client=httpx.AsyncClient()).read("https://example.com/input.pdf")

    assert result.ok is False
    assert result.error is not None
    assert "Failed to download PDF" in result.error.message
