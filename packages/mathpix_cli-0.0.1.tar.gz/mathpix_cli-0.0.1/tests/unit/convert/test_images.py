from __future__ import annotations

from typing import TYPE_CHECKING

import anyio
import httpx
import pytest
from anyio import lowlevel
from mathpix_cli.convert.images import (
    CDN_PATTERN,
    MMD_CDN_PATTERN,
    CdnUrlInfo,
    MarkdownImageMatch,
    MultiMarkdownImageMatch,
    download_cdn_images,
    find_cdn_images,
    has_cdn_images,
    parse_cdn_url,
)

if TYPE_CHECKING:
    from pathlib import Path

    from _pytest.monkeypatch import MonkeyPatch


def test_cdn_pattern_matches_mathpix_markdown_url() -> None:
    markdown = "![alt](https://cdn.mathpix.com/cropped/2024_01_01_abc123.jpg?height=100)"

    assert CDN_PATTERN.search(markdown) is not None


def test_mmd_pattern_matches_mathpix_includegraphics_url() -> None:
    mmd = (
        r"\includegraphics[width=0.5\textwidth]"
        r"{https://cdn.mathpix.com/cropped/2024_01_01_abc.jpg?height=100}"
    )

    assert MMD_CDN_PATTERN.search(mmd) is not None


def test_image_matches_render_local_references() -> None:
    markdown_match = MarkdownImageMatch(
        alt_text="alt",
        original_match="orig",
        span=(0, 4),
        url="https://cdn.mathpix.com/cropped/a.jpg",
    )
    multimarkdown_match = MultiMarkdownImageMatch(
        alt_text="width=200",
        original_match="orig",
        span=(0, 4),
        url="https://cdn.mathpix.com/cropped/a.jpg",
    )

    assert markdown_match.local_ref("images/img.jpg") == "![alt](images/img.jpg)"
    assert (
        multimarkdown_match.local_ref("images/img.jpg")
        == r"\includegraphics[width=200]{images/img.jpg}"
    )


def test_has_cdn_images_detects_markdown_and_mmd() -> None:
    assert has_cdn_images("![](https://cdn.mathpix.com/cropped/img.jpg?h=1)") is True
    assert (
        has_cdn_images(r"\includegraphics[w=1]{https://cdn.mathpix.com/cropped/img.jpg?h=1}")
        is True
    )
    assert has_cdn_images("plain text") is False


def test_find_cdn_images_returns_both_match_types() -> None:
    text = (
        "![alt](https://cdn.mathpix.com/cropped/a.jpg?h=1)\n"
        r"\includegraphics[w=1]{https://cdn.mathpix.com/cropped/b.jpg?h=2}"
    )

    results = find_cdn_images(text)

    assert len(results) == 2
    assert isinstance(results[0], MarkdownImageMatch)
    assert isinstance(results[1], MultiMarkdownImageMatch)
    assert results[0].url == "https://cdn.mathpix.com/cropped/a.jpg?h=1"
    assert results[0].span == (0, 49)
    assert results[1].url == "https://cdn.mathpix.com/cropped/b.jpg?h=2"


def test_find_cdn_images_returns_matches_sorted_by_position() -> None:
    text = (
        r"\includegraphics[w=1]{https://cdn.mathpix.com/cropped/first.jpg?h=1}"
        "\n"
        "![alt](https://cdn.mathpix.com/cropped/second.jpg?h=2)"
    )

    results = find_cdn_images(text)

    assert len(results) == 2
    assert isinstance(results[0], MultiMarkdownImageMatch)
    assert isinstance(results[1], MarkdownImageMatch)
    assert results[0].span[0] < results[1].span[0]


def test_parse_cdn_url_extracts_name_extension_and_dimensions() -> None:
    parsed = parse_cdn_url("https://cdn.mathpix.com/cropped/img.png?height=50&width=200")

    assert parsed == CdnUrlInfo(base_name="img", extension="png", height="50", width="200")


def test_parse_cdn_url_defaults_extension_to_jpg() -> None:
    parsed = parse_cdn_url("https://cdn.mathpix.com/cropped/img_without_ext")

    assert parsed == CdnUrlInfo(
        base_name="img_without_ext",
        extension="jpg",
        height=None,
        width=None,
    )


@pytest.mark.anyio
async def test_download_cdn_images_returns_original_when_no_matches(tmp_path: Path) -> None:
    result = await download_cdn_images("plain text", tmp_path / "images")

    assert result.ok is True
    assert result.value is not None
    assert result.value.images_downloaded == 0
    assert result.value.markdown == "plain text"
    assert result.value.warnings == ()


@pytest.mark.anyio
async def test_download_cdn_images_downloads_and_rewrites_links(
    monkeypatch: MonkeyPatch,
    tmp_path: Path,
) -> None:
    markdown = "![alt](https://cdn.mathpix.com/cropped/sample.png?height=10)"

    async def fake_get(self: httpx.AsyncClient, url: str, **kwargs: object) -> httpx.Response:
        _ = (self, kwargs)
        await lowlevel.checkpoint()
        request = httpx.Request("GET", url)
        return httpx.Response(200, request=request, content=b"image-bytes")

    monkeypatch.setattr(httpx.AsyncClient, "get", fake_get)

    result = await download_cdn_images(markdown, tmp_path / "images")

    assert result.ok is True
    assert result.value is not None
    assert result.value.images_downloaded == 1
    assert result.value.markdown == "![alt](images/sample-01.png)"
    assert (tmp_path / "images" / "sample-01.png").read_bytes() == b"image-bytes"


@pytest.mark.anyio
async def test_download_cdn_images_collects_download_warning(
    monkeypatch: MonkeyPatch,
    tmp_path: Path,
) -> None:
    markdown = "![alt](https://cdn.mathpix.com/cropped/sample.jpg)"

    async def fake_get(self: httpx.AsyncClient, url: str, **kwargs: object) -> httpx.Response:
        _ = (self, kwargs)
        await lowlevel.checkpoint()
        request = httpx.Request("GET", url)
        raise httpx.ConnectError("offline", request=request)

    monkeypatch.setattr(httpx.AsyncClient, "get", fake_get)

    result = await download_cdn_images(markdown, tmp_path / "images")

    assert result.ok is True
    assert result.value is not None
    assert result.value.images_downloaded == 0
    assert result.value.markdown == markdown
    assert "Failed to download" in result.value.warnings[0]


@pytest.mark.anyio
async def test_download_cdn_images_collects_write_warning(
    monkeypatch: MonkeyPatch,
    tmp_path: Path,
) -> None:
    markdown = "![alt](https://cdn.mathpix.com/cropped/sample.jpg)"

    async def fake_get(self: httpx.AsyncClient, url: str, **kwargs: object) -> httpx.Response:
        _ = (self, kwargs)
        await lowlevel.checkpoint()
        request = httpx.Request("GET", url)
        return httpx.Response(200, request=request, content=b"image-bytes")

    async def fake_write_bytes(path: object, data: bytes) -> None:
        _ = (path, data)
        await lowlevel.checkpoint()
        raise OSError("disk full")

    monkeypatch.setattr(httpx.AsyncClient, "get", fake_get)
    monkeypatch.setattr("anyio.Path.write_bytes", fake_write_bytes)

    result = await download_cdn_images(markdown, tmp_path / "images")

    assert result.ok is True
    assert result.value is not None
    assert result.value.images_downloaded == 0
    assert "Failed to write image" in result.value.warnings[0]


@pytest.mark.anyio
async def test_download_cdn_images_returns_error_when_directory_creation_fails(
    monkeypatch: MonkeyPatch,
    tmp_path: Path,
) -> None:
    async def fake_mkdir(self: object, *, parents: bool, exist_ok: bool) -> None:
        _ = (self, parents, exist_ok)
        await lowlevel.checkpoint()
        raise OSError("mkdir failed")

    monkeypatch.setattr("anyio.Path.mkdir", fake_mkdir)

    result = await download_cdn_images(
        "![alt](https://cdn.mathpix.com/cropped/sample.jpg)",
        tmp_path / "images",
    )

    assert result.ok is False
    assert result.error is not None
    assert "Failed to create images directory" in result.error.message


@pytest.mark.anyio
async def test_download_cdn_images_handles_duplicate_urls(
    monkeypatch: MonkeyPatch,
    tmp_path: Path,
) -> None:
    url = "https://cdn.mathpix.com/cropped/sample.png?h=10"
    markdown = f"![a]({url})\n![b]({url})"

    async def fake_get(self: httpx.AsyncClient, url: str, **kwargs: object) -> httpx.Response:
        _ = (self, kwargs)
        await lowlevel.checkpoint()
        request = httpx.Request("GET", url)
        return httpx.Response(200, request=request, content=b"img")

    monkeypatch.setattr(httpx.AsyncClient, "get", fake_get)

    result = await download_cdn_images(markdown, tmp_path / "images")

    assert result.ok is True
    assert result.value is not None
    assert result.value.images_downloaded == 2
    assert result.value.markdown == "![a](images/sample-01.png)\n![b](images/sample-02.png)"


@pytest.mark.anyio
async def test_download_cdn_images_limits_concurrency_to_eight(
    monkeypatch: MonkeyPatch,
    tmp_path: Path,
) -> None:
    markdown = "\n".join(
        f"![alt{i}](https://cdn.mathpix.com/cropped/sample{i}.png)" for i in range(10)
    )
    active = 0
    max_active = 0
    lock = anyio.Lock()

    async def fake_get(self: httpx.AsyncClient, url: str, **kwargs: object) -> httpx.Response:
        nonlocal active, max_active
        _ = (self, kwargs)
        request = httpx.Request("GET", url)
        async with lock:
            active += 1
            max_active = max(max_active, active)
        await anyio.sleep(0.01)
        async with lock:
            active -= 1
        return httpx.Response(200, request=request, content=b"image-bytes")

    monkeypatch.setattr(httpx.AsyncClient, "get", fake_get)

    result = await download_cdn_images(markdown, tmp_path / "images")

    assert result.ok is True
    assert result.value is not None
    assert result.value.images_downloaded == 10
    assert max_active == 8
