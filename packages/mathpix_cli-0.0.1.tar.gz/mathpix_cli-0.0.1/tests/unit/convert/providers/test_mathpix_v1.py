from __future__ import annotations

from typing import TYPE_CHECKING

import httpx
import pytest
from anyio import lowlevel
from mathpix_cli.convert.model import OutputFormat
from mathpix_cli.convert.providers.mathpix_v1 import MathpixV1PdfConverter
from mathpix_cli.shared.config import MathpixV1Credentials

if TYPE_CHECKING:
    from _pytest.monkeypatch import MonkeyPatch

BASE_URL = "https://api.mathpix.com/v1"


def make_converter() -> MathpixV1PdfConverter:
    return MathpixV1PdfConverter(
        config=MathpixV1Credentials(token=auth_value(), base_url=BASE_URL),
        client=httpx.AsyncClient(),
    )


def auth_value() -> str:
    return "test-token"


def pdf_status(status: str) -> dict[str, object]:
    return {"pdf": {"id": "pdf-1", "status": status}}


def conversion_status(status: str) -> dict[str, object]:
    return {"conversion": {"id": "conv-1", "conversion_status": {"md": {"status": status}}}}


@pytest.mark.anyio
async def test_convert_md_uses_conversions_endpoint(monkeypatch: MonkeyPatch) -> None:
    converter = make_converter()
    call_log: list[tuple[str, str]] = []

    async def mock_request(
        self: httpx.AsyncClient,
        method: str,
        url: str,
        **kwargs: object,
    ) -> httpx.Response:
        _ = (self, kwargs)
        await lowlevel.checkpoint()
        call_log.append((method, url))
        request = httpx.Request(method, url)
        if method == "POST" and url == f"{BASE_URL}/pdfs":
            return httpx.Response(200, request=request, json={"pdf": {"id": "pdf-1"}})
        if method == "GET" and url == f"{BASE_URL}/pdfs/pdf-1":
            return httpx.Response(200, request=request, json=pdf_status("completed"))
        if method == "POST" and url == f"{BASE_URL}/conversions":
            return httpx.Response(200, request=request, json={"conversion": {"id": "conv-1"}})
        if method == "GET" and url == f"{BASE_URL}/conversions/conv-1":
            return httpx.Response(200, request=request, json=conversion_status("completed"))
        if method == "GET" and url == f"{BASE_URL}/conversions/conv-1/md":
            return httpx.Response(200, request=request, text="# via conversions")
        return httpx.Response(404, request=request)

    monkeypatch.setattr(httpx.AsyncClient, "request", mock_request)

    result = await converter.convert(
        b"%PDF",
        OutputFormat.MD,
        filename="input.pdf",
        max_polling_time=10,
        max_retries=1,
        polling_interval=1,
    )

    assert result.ok is True
    assert result.value == "# via conversions"
    assert ("POST", f"{BASE_URL}/pdfs") in call_log
    assert ("GET", f"{BASE_URL}/pdfs/pdf-1") in call_log
    assert ("POST", f"{BASE_URL}/conversions") in call_log
    assert ("GET", f"{BASE_URL}/conversions/conv-1") in call_log
    assert ("GET", f"{BASE_URL}/conversions/conv-1/md") in call_log
    assert not any(url.endswith("/pdfs/pdf-1/md") for _, url in call_log)


@pytest.mark.anyio
async def test_convert_mmd_uses_direct_pdf_endpoint(monkeypatch: MonkeyPatch) -> None:
    converter = make_converter()
    call_log: list[tuple[str, str]] = []

    async def mock_request(
        self: httpx.AsyncClient,
        method: str,
        url: str,
        **kwargs: object,
    ) -> httpx.Response:
        _ = (self, kwargs)
        await lowlevel.checkpoint()
        call_log.append((method, url))
        request = httpx.Request(method, url)
        if method == "POST" and url == f"{BASE_URL}/pdfs":
            return httpx.Response(200, request=request, json={"pdf": {"id": "pdf-1"}})
        if method == "GET" and url == f"{BASE_URL}/pdfs/pdf-1":
            return httpx.Response(200, request=request, json=pdf_status("completed"))
        if method == "GET" and url == f"{BASE_URL}/pdfs/pdf-1/mmd":
            return httpx.Response(200, request=request, text="\\section{Raw MMD}")
        return httpx.Response(404, request=request)

    monkeypatch.setattr(httpx.AsyncClient, "request", mock_request)

    result = await converter.convert(
        b"%PDF",
        OutputFormat.MMD,
        filename="input.pdf",
        max_polling_time=10,
        max_retries=1,
        polling_interval=1,
    )

    assert result.ok is True
    assert result.value == "\\section{Raw MMD}"
    assert ("GET", f"{BASE_URL}/pdfs/pdf-1/mmd") in call_log
    assert not any(url.endswith("/conversions") for _, url in call_log)


@pytest.mark.anyio
async def test_convert_fails_when_upload_payload_is_invalid(monkeypatch: MonkeyPatch) -> None:
    converter = make_converter()

    async def mock_request(
        self: httpx.AsyncClient,
        method: str,
        url: str,
        **kwargs: object,
    ) -> httpx.Response:
        _ = (self, kwargs)
        await lowlevel.checkpoint()
        request = httpx.Request(method, url)
        if method == "POST" and url == f"{BASE_URL}/pdfs":
            return httpx.Response(200, request=request, json={"pdf": {}})
        return httpx.Response(404, request=request)

    monkeypatch.setattr(httpx.AsyncClient, "request", mock_request)

    result = await converter.convert(
        b"%PDF",
        OutputFormat.MD,
        filename="input.pdf",
        max_polling_time=10,
        max_retries=1,
        polling_interval=1,
    )

    assert result.ok is False
    assert result.error is not None
    assert "no pdf id" in result.error.message.lower()


@pytest.mark.anyio
async def test_convert_fails_on_invalid_status_payload(monkeypatch: MonkeyPatch) -> None:
    converter = make_converter()

    async def mock_request(
        self: httpx.AsyncClient,
        method: str,
        url: str,
        **kwargs: object,
    ) -> httpx.Response:
        _ = (self, kwargs)
        await lowlevel.checkpoint()
        request = httpx.Request(method, url)
        if method == "POST" and url == f"{BASE_URL}/pdfs":
            return httpx.Response(200, request=request, json={"pdf": {"id": "pdf-1"}})
        if method == "GET" and url == f"{BASE_URL}/pdfs/pdf-1":
            return httpx.Response(200, request=request, text="not-json")
        return httpx.Response(404, request=request)

    monkeypatch.setattr(httpx.AsyncClient, "request", mock_request)

    result = await converter.convert(
        b"%PDF",
        OutputFormat.MD,
        filename="input.pdf",
        max_polling_time=10,
        max_retries=1,
        polling_interval=1,
    )

    assert result.ok is False
    assert result.error is not None
    assert "invalid json" in result.error.message.lower()
