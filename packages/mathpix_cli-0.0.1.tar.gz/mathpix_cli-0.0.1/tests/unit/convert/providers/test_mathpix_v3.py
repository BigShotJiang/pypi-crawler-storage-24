from __future__ import annotations

from typing import TYPE_CHECKING

import httpx
import pytest
from anyio import lowlevel
from mathpix_cli.convert.model import OutputFormat
from mathpix_cli.convert.providers.mathpix_v3 import MathpixV3PdfConverter
from mathpix_cli.shared.config import MathpixV3Credentials

if TYPE_CHECKING:
    from _pytest.monkeypatch import MonkeyPatch

BASE_URL = "https://api.mathpix.com/v3"


def make_converter() -> MathpixV3PdfConverter:
    return MathpixV3PdfConverter(
        config=MathpixV3Credentials(
            app_id="test-id",
            app_key="test-key",
            base_url=BASE_URL,
        ),
        client=httpx.AsyncClient(),
    )


@pytest.mark.anyio
async def test_convert_md_runs_full_flow(monkeypatch: MonkeyPatch) -> None:
    converter = make_converter()
    call_log: list[tuple[str, str]] = []
    upload_data: dict[str, object] = {}

    async def mock_request(
        self: httpx.AsyncClient,
        method: str,
        url: str,
        **kwargs: object,
    ) -> httpx.Response:
        _ = self
        await lowlevel.checkpoint()
        call_log.append((method, url))
        request = httpx.Request(method, url)
        if method == "POST" and url == f"{BASE_URL}/pdf":
            data = kwargs.get("data")
            if isinstance(data, dict):
                upload_data.update(data)
            return httpx.Response(200, request=request, json={"pdf_id": "job-1"})
        if method == "GET" and url == f"{BASE_URL}/pdf/job-1":
            return httpx.Response(200, request=request, json={"status": {"md": "completed"}})
        if method == "GET" and url == f"{BASE_URL}/pdf/job-1.md":
            return httpx.Response(200, request=request, text="# Hello MD")
        return httpx.Response(404, request=request)

    monkeypatch.setattr(httpx.AsyncClient, "request", mock_request)

    result = await converter.convert(
        b"%PDF",
        OutputFormat.MD,
        filename="input.pdf",
        max_polling_time=10,
        max_retries=1,
        polling_interval=1,
    )

    assert result.ok is True
    assert result.value == "# Hello MD"
    assert "options_json" in upload_data
    assert ("POST", f"{BASE_URL}/pdf") in call_log
    assert ("GET", f"{BASE_URL}/pdf/job-1") in call_log
    assert ("GET", f"{BASE_URL}/pdf/job-1.md") in call_log


@pytest.mark.anyio
async def test_convert_mmd_omits_conversion_options(monkeypatch: MonkeyPatch) -> None:
    converter = make_converter()
    upload_data: dict[str, object] = {}

    async def mock_request(
        self: httpx.AsyncClient,
        method: str,
        url: str,
        **kwargs: object,
    ) -> httpx.Response:
        _ = self
        await lowlevel.checkpoint()
        request = httpx.Request(method, url)
        if method == "POST" and url == f"{BASE_URL}/pdf":
            data = kwargs.get("data")
            if isinstance(data, dict):
                upload_data.update(data)
            return httpx.Response(200, request=request, json={"pdf_id": "job-1"})
        if method == "GET" and url == f"{BASE_URL}/pdf/job-1":
            return httpx.Response(200, request=request, json={"status": {"mmd": "completed"}})
        if method == "GET" and url == f"{BASE_URL}/pdf/job-1.mmd":
            return httpx.Response(200, request=request, text="\\section{Hello MMD}")
        return httpx.Response(404, request=request)

    monkeypatch.setattr(httpx.AsyncClient, "request", mock_request)

    result = await converter.convert(
        b"%PDF",
        OutputFormat.MMD,
        filename="input.pdf",
        max_polling_time=10,
        max_retries=1,
        polling_interval=1,
    )

    assert result.ok is True
    assert result.value == "\\section{Hello MMD}"
    assert "options_json" not in upload_data


@pytest.mark.anyio
async def test_convert_fails_when_upload_payload_is_invalid(monkeypatch: MonkeyPatch) -> None:
    converter = make_converter()

    async def mock_request(
        self: httpx.AsyncClient,
        method: str,
        url: str,
        **kwargs: object,
    ) -> httpx.Response:
        _ = (self, kwargs)
        await lowlevel.checkpoint()
        request = httpx.Request(method, url)
        if method == "POST" and url == f"{BASE_URL}/pdf":
            return httpx.Response(200, request=request, json={})
        return httpx.Response(404, request=request)

    monkeypatch.setattr(httpx.AsyncClient, "request", mock_request)

    result = await converter.convert(
        b"%PDF",
        OutputFormat.MD,
        filename="input.pdf",
        max_polling_time=10,
        max_retries=1,
        polling_interval=1,
    )

    assert result.ok is False
    assert result.error is not None
    assert "pdf_id" in result.error.message


@pytest.mark.anyio
async def test_convert_fails_on_invalid_status_payload(monkeypatch: MonkeyPatch) -> None:
    converter = make_converter()

    async def mock_request(
        self: httpx.AsyncClient,
        method: str,
        url: str,
        **kwargs: object,
    ) -> httpx.Response:
        _ = (self, kwargs)
        await lowlevel.checkpoint()
        request = httpx.Request(method, url)
        if method == "POST" and url == f"{BASE_URL}/pdf":
            return httpx.Response(200, request=request, json={"pdf_id": "job-1"})
        if method == "GET" and url == f"{BASE_URL}/pdf/job-1":
            return httpx.Response(200, request=request, text="not-json")
        return httpx.Response(404, request=request)

    monkeypatch.setattr(httpx.AsyncClient, "request", mock_request)

    result = await converter.convert(
        b"%PDF",
        OutputFormat.MD,
        filename="input.pdf",
        max_polling_time=10,
        max_retries=1,
        polling_interval=1,
    )

    assert result.ok is False
    assert result.error is not None
    assert "invalid json" in result.error.message.lower()
