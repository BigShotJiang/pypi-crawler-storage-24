from __future__ import annotations

import json
import os
from pathlib import Path
from typing import TYPE_CHECKING

import anyio
import pytest
from mathpix_cli.convert.images import ImageLocalization
from mathpix_cli.convert.model import OutputFormat
from mathpix_cli.convert.store import FileSystemConvertStore
from mathpix_cli.shared.errors import ErrorCode
from mathpix_cli.shared.result import Result

if TYPE_CHECKING:
    from _pytest.monkeypatch import MonkeyPatch


@pytest.mark.anyio
async def test_save_writes_convert_output_and_history(tmp_path: Path) -> None:
    store = FileSystemConvertStore(output_dir=str(tmp_path))

    result = await store.save(
        text="# Hello",
        sha256="a" * 64,
        source="input.pdf",
        fmt=OutputFormat.MD,
    )

    assert result.ok is True
    assert result.value is not None
    folder = tmp_path / "converts" / "md" / ("a" * 16)
    main_path = folder / "main.md"
    assert main_path.read_text(encoding="utf-8") == "# Hello"

    history = json.loads((tmp_path / "history.json").read_text(encoding="utf-8"))
    entry = history["converts"][f"{'a' * 64}:md"]
    assert entry["format"] == "md"
    assert entry["source"] == "input.pdf"


@pytest.mark.anyio
async def test_save_replaces_history_atomically(monkeypatch: MonkeyPatch, tmp_path: Path) -> None:
    store = FileSystemConvertStore(output_dir=str(tmp_path))
    replace_calls: list[tuple[Path, Path]] = []
    original_replace = os.replace

    def fake_replace(src: os.PathLike[str] | str, dst: os.PathLike[str] | str) -> None:
        src_path = Path(src)
        dst_path = Path(dst)
        replace_calls.append((src_path, dst_path))
        original_replace(src, dst)

    monkeypatch.setattr("mathpix_cli.shared.store.os.replace", fake_replace)

    result = await store.save(
        text="# Hello",
        sha256="z" * 64,
        source="input.pdf",
        fmt=OutputFormat.MD,
    )

    assert result.ok is True
    assert len(replace_calls) == 1
    temp_path, history_path = replace_calls[0]
    assert history_path == tmp_path / "history.json"
    assert temp_path.parent == tmp_path
    assert temp_path.name.startswith(".history.json.")
    assert temp_path.exists() is False


@pytest.mark.anyio
async def test_find_cached_returns_existing_output(tmp_path: Path) -> None:
    sha256 = "b" * 64
    folder = "b" * 16
    main_path = tmp_path / "converts" / "md" / folder / "main.md"
    main_path.parent.mkdir(parents=True)
    main_path.write_text("# cached", encoding="utf-8")
    history = {
        "converts": {
            f"{sha256}:md": {
                "format": "md",
                "images_downloaded": 0,
                "source": "input.pdf",
                "timestamp": "2026-03-20T00:00:00+00:00",
            }
        }
    }
    (tmp_path / "history.json").write_text(json.dumps(history), encoding="utf-8")
    store = FileSystemConvertStore(output_dir=str(tmp_path))

    result = await store.find_cached(sha256, OutputFormat.MD)

    assert result.ok is True
    assert result.value is not None
    assert result.value == str(main_path.resolve())


@pytest.mark.anyio
async def test_save_records_localization_warning_when_image_download_fails(
    monkeypatch: MonkeyPatch,
    tmp_path: Path,
) -> None:
    store = FileSystemConvertStore(output_dir=str(tmp_path))

    async def fake_download(markdown: str, images_dir: Path) -> Result[object]:
        _ = (markdown, images_dir)
        await anyio.lowlevel.checkpoint()
        return Result.failure(ErrorCode.NETWORK, "cdn failed")

    monkeypatch.setattr("mathpix_cli.convert.store.download_cdn_images", fake_download)

    result = await store.save(
        text="![](https://cdn.mathpix.com/cropped/img.jpg)",
        sha256="c" * 64,
        source="https://example.com/input.pdf",
        fmt=OutputFormat.MD,
    )

    assert result.ok is True
    assert result.value is not None
    assert result.value.warnings == ("Image localization failed: cdn failed",)


@pytest.mark.anyio
async def test_find_cached_returns_none_when_history_has_no_converts(tmp_path: Path) -> None:
    (tmp_path / "history.json").write_text(json.dumps({"snips": {}}), encoding="utf-8")
    store = FileSystemConvertStore(output_dir=str(tmp_path))

    result = await store.find_cached("a" * 64, OutputFormat.MD)

    assert result.ok is True
    assert result.value is None


@pytest.mark.anyio
async def test_find_cached_returns_none_when_cached_file_is_missing(tmp_path: Path) -> None:
    sha256 = "d" * 64
    history = {"converts": {f"{sha256}:md": {"source": "input.pdf"}}}
    (tmp_path / "history.json").write_text(json.dumps(history), encoding="utf-8")
    store = FileSystemConvertStore(output_dir=str(tmp_path))

    result = await store.find_cached(sha256, OutputFormat.MD)

    assert result.ok is True
    assert result.value is None


@pytest.mark.anyio
async def test_find_cached_returns_error_when_history_is_invalid_json(tmp_path: Path) -> None:
    (tmp_path / "history.json").write_text("{", encoding="utf-8")
    store = FileSystemConvertStore(output_dir=str(tmp_path))

    result = await store.find_cached("e" * 64, OutputFormat.MD)

    assert result.ok is False
    assert result.error is not None
    assert "Failed to read history" in result.error.message


@pytest.mark.anyio
async def test_save_writes_original_markdown_when_images_are_localized(
    monkeypatch: MonkeyPatch,
    tmp_path: Path,
) -> None:
    store = FileSystemConvertStore(output_dir=str(tmp_path))

    async def fake_download(markdown: str, images_dir: Path) -> Result[object]:
        _ = (markdown, images_dir)
        await anyio.lowlevel.checkpoint()

        return Result.success(
            ImageLocalization(
                images_downloaded=1,
                markdown="# localized",
                warnings=("warn",),
            )
        )

    monkeypatch.setattr("mathpix_cli.convert.store.download_cdn_images", fake_download)

    result = await store.save(
        text="# original",
        sha256="f" * 64,
        source="input.pdf",
        fmt=OutputFormat.MD,
    )

    assert result.ok is True
    assert result.value is not None
    folder = tmp_path / "converts" / "md" / ("f" * 16)
    assert (folder / "main.md").read_text(encoding="utf-8") == "# localized"
    assert (folder / "original.md").read_text(encoding="utf-8") == "# original"
    assert result.value.warnings == ("warn",)
