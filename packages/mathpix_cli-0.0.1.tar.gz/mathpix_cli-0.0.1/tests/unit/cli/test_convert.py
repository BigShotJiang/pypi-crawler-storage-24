from __future__ import annotations

import importlib
from typing import TYPE_CHECKING

import pytest
import typer
from mathpix_cli.convert.model import ConvertOutcome, OutputFormat
from mathpix_cli.shared.config import (
    AppConfig,
    BackendMode,
    ConvertSettings,
    MathpixV1Credentials,
    MathpixV3Credentials,
)
from mathpix_cli.shared.errors import ErrorCode
from mathpix_cli.shared.result import Result
from typer.testing import CliRunner

from .conftest import FakeReporter, async_success, config_loader

if TYPE_CHECKING:
    from pathlib import Path

    from _pytest.monkeypatch import MonkeyPatch

cli_app_module = importlib.import_module("mathpix_cli.cli.app")
cli_convert_module = importlib.import_module("mathpix_cli.cli.convert")
runner = CliRunner()


def auth_value() -> str:
    return "test-token"


def saved_outcome(
    *,
    path: str,
    output_format: OutputFormat,
    cache_hit: bool,
    images: int,
    warnings: tuple[str, ...] = (),
) -> ConvertOutcome:
    return ConvertOutcome(
        cache_hit=cache_hit,
        format=output_format,
        images_downloaded=images,
        path=path,
        warnings=warnings,
    )


def v1_config() -> AppConfig:
    return AppConfig(
        v3=MathpixV3Credentials(app_id="id", app_key="key", base_url="https://api.mathpix.com/v3"),
        convert=ConvertSettings(format=OutputFormat.MD, mode=BackendMode.V1),
        v1=MathpixV1Credentials(token=auth_value(), base_url="https://api.mathpix.com/v1"),
    )


def v3_config(*, output_format: OutputFormat) -> AppConfig:
    return AppConfig(
        v3=MathpixV3Credentials(app_id="id", app_key="key", base_url="https://api.mathpix.com/v3"),
        convert=ConvertSettings(format=output_format, mode=BackendMode.V3),
        v1=None,
    )


def test_path_command_rejects_tilde_path() -> None:
    result = runner.invoke(cli_app_module.app, ["convert", "pdf", "path", "~/file.pdf"])

    assert result.exit_code != 0


def test_path_command_prints_v1_plan(monkeypatch: MonkeyPatch, tmp_path: Path) -> None:
    pdf_path = tmp_path / "input.pdf"
    pdf_path.write_bytes(b"%PDF")
    saved_path = tmp_path / "main.md"

    monkeypatch.setattr(
        cli_convert_module,
        "load_config_or_exit",
        config_loader(v1_config()),
    )
    monkeypatch.setattr(
        cli_convert_module,
        "_run",
        async_success(
            saved_outcome(
                path=str(saved_path),
                output_format=OutputFormat.MD,
                cache_hit=False,
                images=0,
            )
        ),
    )

    result = runner.invoke(cli_app_module.app, ["convert", "pdf", "path", str(pdf_path)])

    assert result.exit_code == 0
    assert f"mathpix-v1 -> md | {pdf_path}" in result.output
    assert "Saved" in result.output
    assert str(saved_path) in result.output


def test_path_command_verbose_prints_provider_details(
    monkeypatch: MonkeyPatch,
    tmp_path: Path,
) -> None:
    pdf_path = tmp_path / "input.pdf"
    pdf_path.write_bytes(b"%PDF")
    saved_path = tmp_path / "main.md"

    monkeypatch.setattr(
        cli_convert_module,
        "load_config_or_exit",
        config_loader(v1_config()),
    )
    monkeypatch.setattr(
        cli_convert_module,
        "_run",
        async_success(
            saved_outcome(
                path=str(saved_path),
                output_format=OutputFormat.MD,
                cache_hit=False,
                images=3,
            )
        ),
    )

    result = runner.invoke(
        cli_app_module.app,
        ["convert", "pdf", "path", "--verbose", str(pdf_path)],
    )

    assert result.exit_code == 0
    assert "backend: mathpix-v1" in result.output
    assert "endpoint: POST /v1/pdfs -> GET /v1/conversions/{id}/md" in result.output
    assert "3 images" in result.output


def test_path_command_cache_hit_prints_cached(monkeypatch: MonkeyPatch, tmp_path: Path) -> None:
    pdf_path = tmp_path / "input.pdf"
    pdf_path.write_bytes(b"%PDF")
    cached_path = tmp_path / "main.md"

    monkeypatch.setattr(
        cli_convert_module,
        "load_config_or_exit",
        config_loader(v1_config()),
    )
    monkeypatch.setattr(
        cli_convert_module,
        "_run",
        async_success(
            saved_outcome(
                path=str(cached_path),
                output_format=OutputFormat.MD,
                cache_hit=True,
                images=0,
            )
        ),
    )

    result = runner.invoke(cli_app_module.app, ["convert", "pdf", "path", str(pdf_path)])

    assert result.exit_code == 0
    assert "Cached" in result.output
    assert str(cached_path) in result.output
    assert "Saved" not in result.output


def test_path_command_verbose_prints_v3_mmd_details(
    monkeypatch: MonkeyPatch,
    tmp_path: Path,
) -> None:
    pdf_path = tmp_path / "input.pdf"
    pdf_path.write_bytes(b"%PDF")
    saved_path = tmp_path / "main.mmd"

    monkeypatch.setattr(
        cli_convert_module,
        "load_config_or_exit",
        config_loader(v3_config(output_format=OutputFormat.MMD)),
    )
    monkeypatch.setattr(
        cli_convert_module,
        "_run",
        async_success(
            saved_outcome(
                path=str(saved_path),
                output_format=OutputFormat.MMD,
                cache_hit=False,
                images=0,
            )
        ),
    )

    result = runner.invoke(
        cli_app_module.app,
        ["convert", "pdf", "path", "--verbose", str(pdf_path)],
    )

    assert result.exit_code == 0
    assert "backend: mathpix-v3" in result.output
    assert "endpoint: POST /v3/pdf -> GET /v3/pdf/{id}.mmd" in result.output


def test_url_command_rejects_non_http_url() -> None:
    result = runner.invoke(cli_app_module.app, ["convert", "pdf", "url", "not-a-url"])

    assert result.exit_code != 0


def test_run_path_verbose_prints_v1_mmd_plan(tmp_path: Path, monkeypatch: MonkeyPatch) -> None:
    reporter = FakeReporter()
    pdf_path = tmp_path / "input.pdf"
    pdf_path.write_bytes(b"%PDF")
    config = AppConfig(
        v3=MathpixV3Credentials(app_id="id", app_key="key"),
        convert=ConvertSettings(format=OutputFormat.MMD, mode=BackendMode.V1),
        v1=MathpixV1Credentials(token=auth_value(), base_url="https://api.mathpix.com/v1"),
    )

    monkeypatch.setattr(
        cli_convert_module,
        "_run",
        async_success(
            saved_outcome(
                path=str(tmp_path / "main.mmd"),
                output_format=OutputFormat.MMD,
                cache_hit=False,
                images=0,
            )
        ),
    )

    cli_convert_module.run_path(reporter, str(pdf_path), config, verbose=True)

    assert reporter.statuses[-1] == ("Saved", str(tmp_path / "main.mmd"), "")
    assert "endpoint: POST /v1/pdfs -> GET /v1/pdfs/{id}/mmd" in reporter.details


def test_run_path_emits_warning_and_saved_message(tmp_path: Path, monkeypatch: MonkeyPatch) -> None:
    reporter = FakeReporter()
    pdf_path = tmp_path / "input.pdf"
    pdf_path.write_bytes(b"%PDF")
    config = v1_config()

    monkeypatch.setattr(
        cli_convert_module,
        "_run",
        async_success(
            saved_outcome(
                path=str(tmp_path / "main.md"),
                output_format=OutputFormat.MD,
                cache_hit=False,
                images=0,
                warnings=("warn-1",),
            )
        ),
    )

    cli_convert_module.run_path(reporter, str(pdf_path), config, verbose=False)

    assert reporter.warnings == ["warn-1"]
    assert reporter.statuses[-1] == ("Saved", str(tmp_path / "main.md"), "")


def test_run_path_exits_when_build_use_case_fails(tmp_path: Path, monkeypatch: MonkeyPatch) -> None:
    reporter = FakeReporter()
    pdf_path = tmp_path / "input.pdf"
    pdf_path.write_bytes(b"%PDF")

    monkeypatch.setattr(
        cli_convert_module,
        "build_use_case",
        lambda _config, _client: Result.failure(ErrorCode.CONFIG, "bad config"),
    )

    with pytest.raises(typer.Exit):
        cli_convert_module.run_path(reporter, str(pdf_path), v1_config(), verbose=False)

    assert reporter.errors == ["bad config"]
