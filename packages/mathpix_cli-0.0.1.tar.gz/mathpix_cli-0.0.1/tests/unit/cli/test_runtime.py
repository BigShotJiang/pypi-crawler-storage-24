from __future__ import annotations

from typing import TYPE_CHECKING

import pytest
import typer
from mathpix_cli.cli import runtime
from mathpix_cli.shared.config import AppConfig
from mathpix_cli.shared.errors import ErrorCode
from mathpix_cli.shared.reporter import ConsoleReporter
from mathpix_cli.shared.result import Result

from .conftest import FakeReporter

if TYPE_CHECKING:
    from _pytest.monkeypatch import MonkeyPatch


def test_make_reporter_returns_console_reporter() -> None:
    assert isinstance(runtime.make_reporter(), ConsoleReporter)


def test_load_config_or_exit_returns_loaded_config(monkeypatch: MonkeyPatch) -> None:
    config = AppConfig()
    monkeypatch.setattr(runtime, "load_config", lambda: Result.success(config))

    result = runtime.load_config_or_exit(runtime.make_reporter())

    assert result == config


def test_load_config_or_exit_reports_error_and_exits(monkeypatch: MonkeyPatch) -> None:
    reporter = FakeReporter()
    monkeypatch.setattr(
        runtime,
        "load_config",
        lambda: Result.failure(ErrorCode.CONFIG, "bad config"),
    )

    with pytest.raises(typer.Exit):
        runtime.load_config_or_exit(reporter)  # type: ignore[arg-type]

    assert reporter.errors == ["bad config"]
