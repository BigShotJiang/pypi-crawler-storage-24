from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import anyio
import pytest
from mathpix_cli.shared.result import Result

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from mathpix_cli.shared.config import AppConfig


@dataclass
class FakeReporter:
    """Fake reporter for CLI tests."""

    errors: list[str] = field(default_factory=list)
    summaries: list[str] = field(default_factory=list)
    contents: list[str] = field(default_factory=list)
    statuses: list[tuple[str, str, str]] = field(default_factory=list)
    details: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    def detail(self, message: str) -> None:
        self.details.append(message)

    def error(self, message: str) -> None:
        self.errors.append(message)

    def content(self, message: str) -> None:
        self.contents.append(message)

    def status(self, label: str, path: str, *, detail: str = "") -> None:
        self.statuses.append((label, path, detail))

    def summary(self, message: str) -> None:
        self.summaries.append(message)

    def warn(self, message: str) -> None:
        self.warnings.append(message)


@pytest.fixture
def fake_reporter() -> FakeReporter:
    """Return a fresh fake reporter."""
    return FakeReporter()


def async_success[T](value: T) -> Callable[[object, object], Awaitable[Result[T]]]:
    """Return an async runner that succeeds with *value*."""

    async def run_result(first: object, second: object) -> Result[T]:
        _ = (first, second)
        await anyio.lowlevel.checkpoint()
        return Result.success(value)

    return run_result


def config_loader(config: AppConfig) -> Callable[[object], AppConfig]:
    """Return a config loader stub."""

    def load_config_for_test(reporter: object) -> AppConfig:
        _ = reporter
        return config

    return load_config_for_test
