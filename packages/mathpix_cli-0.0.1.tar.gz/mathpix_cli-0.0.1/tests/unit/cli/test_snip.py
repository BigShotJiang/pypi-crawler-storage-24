from __future__ import annotations

import importlib
from dataclasses import dataclass, replace
from typing import TYPE_CHECKING

import pytest
import typer
from mathpix_cli.shared.config import AppConfig, MathpixV1Credentials, MathpixV3Credentials
from mathpix_cli.shared.errors import ErrorCode
from mathpix_cli.shared.result import Result
from mathpix_cli.snip.model import SavedSnip, SnipFormat, SnipOutcome
from typer.testing import CliRunner

from .conftest import FakeReporter, async_success, config_loader

if TYPE_CHECKING:
    from pathlib import Path

    from _pytest.monkeypatch import MonkeyPatch

cli_app_module = importlib.import_module("mathpix_cli.cli.app")
cli_snip_module = importlib.import_module("mathpix_cli.cli.snip")
runner = CliRunner()


@dataclass
class FailingSnipUseCase:
    message: str

    async def execute(self, request: object) -> Result[SavedSnip]:
        _ = request
        return Result.failure(ErrorCode.NETWORK, self.message)


def v3_config() -> AppConfig:
    return AppConfig(v3=MathpixV3Credentials(app_id="id", app_key="key"))


def auth_value() -> str:
    return "test-token"


def v1_config() -> AppConfig:
    return AppConfig(
        v3=MathpixV3Credentials(app_id="id", app_key="key"),
        v1=MathpixV1Credentials(token=auth_value()),
    )


def test_image_command_rejects_tilde_path() -> None:
    result = runner.invoke(cli_app_module.app, ["snip", "image", "~/equation.png"])

    assert result.exit_code != 0


def test_image_command_prints_saved_snip(monkeypatch: MonkeyPatch, tmp_path: Path) -> None:
    image_path = tmp_path / "equation.png"
    image_path.write_bytes(b"\x89PNG\r\n\x1a\n" + b"\x00" * 16)
    saved_path = tmp_path / "main.tex"
    saved = SavedSnip(
        cache_hit=False,
        outcome=SnipOutcome(
            confidence=0.95,
            format=SnipFormat.LATEX,
            snip_id="snip-1",
            text="x^2 + y^2 = z^2",
        ),
        path=str(saved_path),
    )

    monkeypatch.setattr(
        cli_snip_module,
        "load_config_or_exit",
        config_loader(v3_config()),
    )
    monkeypatch.setattr(cli_snip_module, "_run", async_success(saved))

    result = runner.invoke(
        cli_app_module.app,
        ["snip", "image", "--verbose", str(image_path)],
    )

    assert result.exit_code == 0
    assert "x^2 + y^2 = z^2" in result.output
    assert "Saved" in result.output
    assert str(saved_path) in result.output
    assert "confidence: 0.95" in result.output
    assert "snip_id: snip-1" in result.output


def test_image_command_prints_summary_line(monkeypatch: MonkeyPatch, tmp_path: Path) -> None:
    image_path = tmp_path / "equation.png"
    image_path.write_bytes(b"\x89PNG\r\n\x1a\n" + b"\x00" * 16)
    saved = SavedSnip(
        cache_hit=False,
        outcome=SnipOutcome(
            confidence=0.9,
            format=SnipFormat.LATEX,
            snip_id="",
            text="x",
        ),
        path=str(tmp_path / "main.tex"),
    )

    monkeypatch.setattr(
        cli_snip_module,
        "load_config_or_exit",
        config_loader(v3_config()),
    )
    monkeypatch.setattr(cli_snip_module, "_run", async_success(saved))

    result = runner.invoke(cli_app_module.app, ["snip", "image", str(image_path)])

    assert result.exit_code == 0
    assert f"mathpix-v3 -> latex | {image_path}" in result.output


def test_image_command_prints_cached_result_from_file(
    monkeypatch: MonkeyPatch,
    tmp_path: Path,
) -> None:
    image_path = tmp_path / "equation.png"
    image_path.write_bytes(b"\x89PNG\r\n\x1a\n" + b"\x00" * 16)
    cached_path = tmp_path / "cached.tex"
    cached_path.write_text("cached output\n", encoding="utf-8")
    saved = SavedSnip(
        cache_hit=True,
        path=str(cached_path),
    )

    monkeypatch.setattr(
        cli_snip_module,
        "load_config_or_exit",
        config_loader(v3_config()),
    )
    monkeypatch.setattr(cli_snip_module, "_run", async_success(saved))

    result = runner.invoke(cli_app_module.app, ["snip", "image", str(image_path)])

    assert result.exit_code == 0
    assert "cached output" in result.output
    assert "Cached" in result.output


def test_image_command_warns_on_cached_result_read_failure(
    monkeypatch: MonkeyPatch,
    tmp_path: Path,
) -> None:
    reporter = FakeReporter()
    image_path = tmp_path / "equation.png"
    image_path.write_bytes(b"\x89PNG\r\n\x1a\n" + b"\x00" * 16)
    cached_path = tmp_path / "cached.tex"
    saved = SavedSnip(cache_hit=True, path=str(cached_path))

    def fake_read_text(self: object, *, encoding: str) -> str:
        _ = (self, encoding)
        raise OSError("disk full")

    monkeypatch.setattr(cli_snip_module.Path, "read_text", fake_read_text)
    monkeypatch.setattr(cli_snip_module, "_run", async_success(saved))

    cli_snip_module.run_image(reporter, str(image_path), v3_config(), fmt=None, verbose=False)

    assert reporter.contents == []
    assert reporter.warnings == [f"Failed to read cached result from {cached_path}: disk full"]


def test_run_image_can_hide_inline_result(monkeypatch: MonkeyPatch, tmp_path: Path) -> None:
    reporter = FakeReporter()
    image_path = tmp_path / "equation.png"
    image_path.write_bytes(b"\x89PNG\r\n\x1a\n" + b"\x00" * 16)
    saved = SavedSnip(
        cache_hit=False,
        outcome=SnipOutcome(
            confidence=0.8,
            format=SnipFormat.TEXT,
            snip_id="",
            text="hidden",
        ),
        path=str(tmp_path / "main.txt"),
    )
    config = v3_config()
    config = replace(
        config,
        snip=config.snip.__class__(
            format=config.snip.format,
            mode=config.snip.mode,
            options=config.snip.options,
            show_result=False,
        ),
    )
    monkeypatch.setattr(cli_snip_module, "_run", async_success(saved))

    cli_snip_module.run_image(reporter, str(image_path), config, fmt=None, verbose=False)

    assert reporter.contents == []
    assert reporter.statuses == [("Saved", str(tmp_path / "main.txt"), "confidence: 0.8")]


def test_run_image_ignores_missing_cached_file(monkeypatch: MonkeyPatch, tmp_path: Path) -> None:
    reporter = FakeReporter()
    image_path = tmp_path / "equation.png"
    image_path.write_bytes(b"\x89PNG\r\n\x1a\n" + b"\x00" * 16)
    saved = SavedSnip(
        cache_hit=True,
        path=str(tmp_path / "missing.txt"),
    )
    monkeypatch.setattr(cli_snip_module, "_run", async_success(saved))

    cli_snip_module.run_image(reporter, str(image_path), v3_config(), fmt=None, verbose=False)

    assert reporter.statuses == [("Cached", str(tmp_path / "missing.txt"), "")]


def test_run_image_summary_preserves_relative_input(
    monkeypatch: MonkeyPatch, tmp_path: Path
) -> None:
    reporter = FakeReporter()
    image_path = tmp_path / "equation.png"
    image_path.write_bytes(b"\x89PNG\r\n\x1a\n" + b"\x00" * 16)
    saved = SavedSnip(
        cache_hit=False,
        outcome=SnipOutcome(
            confidence=0.9,
            format=SnipFormat.LATEX,
            snip_id="",
            text="x",
        ),
        path=str(tmp_path / "main.tex"),
    )
    monkeypatch.setattr(cli_snip_module, "_run", async_success(saved))
    monkeypatch.chdir(tmp_path)

    cli_snip_module.run_image(reporter, "equation.png", v3_config(), fmt=None, verbose=False)

    assert reporter.summaries == ["mathpix-v3 -> latex | equation.png"]


def test_image_command_exits_when_use_case_build_fails(
    monkeypatch: MonkeyPatch,
    tmp_path: Path,
) -> None:
    reporter = FakeReporter()
    image_path = tmp_path / "equation.png"
    image_path.write_bytes(b"\x89PNG\r\n\x1a\n" + b"\x00" * 16)
    monkeypatch.setattr(
        cli_snip_module,
        "build_use_case",
        lambda _config, _client: Result.failure(ErrorCode.CONFIG, "bad config"),
    )

    with pytest.raises(typer.Exit):
        cli_snip_module.run_image(reporter, str(image_path), v3_config(), fmt=None, verbose=False)

    assert reporter.errors == ["bad config"]


def test_image_command_exits_when_use_case_execution_fails(
    monkeypatch: MonkeyPatch,
    tmp_path: Path,
) -> None:
    reporter = FakeReporter()
    image_path = tmp_path / "equation.png"
    image_path.write_bytes(b"\x89PNG\r\n\x1a\n" + b"\x00" * 16)
    monkeypatch.setattr(
        cli_snip_module,
        "build_use_case",
        lambda _config, _client: Result.success(FailingSnipUseCase(message="snip failed")),
    )

    with pytest.raises(typer.Exit):
        cli_snip_module.run_image(reporter, str(image_path), v3_config(), fmt=None, verbose=False)

    assert reporter.errors == ["snip failed"]
