"""CLI module tests."""
