from __future__ import annotations

import importlib
from typing import TYPE_CHECKING

from mathpix_cli.cli.app import app
from typer.testing import CliRunner

if TYPE_CHECKING:
    from _pytest.monkeypatch import MonkeyPatch

runner = CliRunner()


def test_help_lists_top_level_commands() -> None:
    result = runner.invoke(app, ["--help"])

    assert result.exit_code == 0
    assert "convert" in result.output
    assert "snip" in result.output


def test_version_option_prints_package_version() -> None:
    result = runner.invoke(app, ["--version"])

    assert result.exit_code == 0
    assert "mathpix-cli" in result.output


def test_main_invokes_typer_application(monkeypatch: MonkeyPatch) -> None:
    app_module = importlib.import_module("mathpix_cli.cli.app")
    called: list[bool] = []

    def fake_app() -> None:
        called.append(True)

    monkeypatch.setattr(app_module, "app", fake_app)

    app_module.main()

    assert called == [True]
