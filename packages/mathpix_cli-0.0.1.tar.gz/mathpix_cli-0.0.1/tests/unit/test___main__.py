from __future__ import annotations

import runpy
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from _pytest.monkeypatch import MonkeyPatch


def test_module_entrypoint_calls_cli_main(monkeypatch: MonkeyPatch) -> None:
    called: list[bool] = []

    def fake_main() -> None:
        called.append(True)

    monkeypatch.setattr("mathpix_cli.cli.main", fake_main)

    runpy.run_module("mathpix_cli.__main__", run_name="__main__")

    assert called == [True]
