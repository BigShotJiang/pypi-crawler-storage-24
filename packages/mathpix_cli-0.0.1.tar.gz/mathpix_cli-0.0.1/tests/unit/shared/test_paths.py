from __future__ import annotations

import unicodedata
from pathlib import Path

from mathpix_cli.shared.paths import normalize_path, resolve_source_path


def test_normalize_path_uses_nfc() -> None:
    raw_path = unicodedata.normalize("NFD", "/var/data/\u30c6\u30b9\u30c8.pdf")

    assert unicodedata.is_normalized("NFC", normalize_path(raw_path))


def test_normalize_path_keeps_ascii_path() -> None:
    assert normalize_path("/var/data/test.pdf") == "/var/data/test.pdf"


def test_resolve_source_path_returns_absolute_path() -> None:
    result = resolve_source_path("file.pdf")

    assert result.ok is True
    assert result.value is not None
    assert result.value.is_absolute()


def test_resolve_source_path_keeps_absolute_input() -> None:
    result = resolve_source_path("/home/user/file.pdf")

    assert result.ok is True
    assert result.value == Path("/home/user/file.pdf")


def test_resolve_source_path_rejects_tilde() -> None:
    result = resolve_source_path("~/file.pdf")

    assert result.ok is False
    assert result.error is not None
    assert "Home directory expansion" in result.error.message
