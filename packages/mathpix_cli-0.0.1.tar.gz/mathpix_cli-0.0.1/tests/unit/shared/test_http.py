from __future__ import annotations

import httpx
import pytest
from anyio import lowlevel
from mathpix_cli.shared.http import (
    normalize_http_base_url,
    parse_response_model,
    request_and_parse,
    request_text,
)
from pydantic import BaseModel


class ExamplePayload(BaseModel):
    """Example payload used to validate HTTP parsing."""

    name: str


def test_normalize_http_base_url_trims_and_removes_trailing_slash() -> None:
    result = normalize_http_base_url(" https://api.mathpix.com/v3/ ", field="api_base")

    assert result.ok is True
    assert result.value == "https://api.mathpix.com/v3"


def test_normalize_http_base_url_rejects_non_http_url() -> None:
    result = normalize_http_base_url("ftp://api.mathpix.com/v3", field="api_base")

    assert result.ok is False
    assert result.error is not None
    assert "absolute HTTP(S) URL" in result.error.message


def test_parse_response_model_returns_validated_payload() -> None:
    response = httpx.Response(
        200,
        request=httpx.Request("GET", "https://example.com"),
        text='{"name":"mathpix"}',
    )

    result = parse_response_model(response, context="parse failed", model=ExamplePayload)

    assert result.ok is True
    assert result.value == ExamplePayload(name="mathpix")


def test_parse_response_model_reports_invalid_json() -> None:
    response = httpx.Response(
        200,
        request=httpx.Request("GET", "https://example.com"),
        text="not-json",
    )

    result = parse_response_model(response, context="parse failed", model=ExamplePayload)

    assert result.ok is False
    assert result.error is not None
    assert "invalid json response" in result.error.message


@pytest.mark.anyio
async def test_request_and_parse_returns_validated_payload(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    async with httpx.AsyncClient() as client:
        response = httpx.Response(
            200,
            request=httpx.Request("GET", "https://example.com"),
            text='{"name":"mathpix"}',
        )

        async def fake_request(
            method: str,
            url: str,
            **kwargs: object,
        ) -> httpx.Response:
            _ = (method, url, kwargs)
            await lowlevel.checkpoint()
            return response

        monkeypatch.setattr(client, "request", fake_request)
        result = await request_and_parse(
            client,
            "GET",
            "https://example.com",
            headers={"Authorization": "Bearer token"},
            model=ExamplePayload,
            context="request failed",
            timeout=10.0,
        )

    assert result.ok is True
    assert result.value == ExamplePayload(name="mathpix")


@pytest.mark.anyio
async def test_request_text_returns_response_text(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    async with httpx.AsyncClient() as client:
        response = httpx.Response(
            200,
            request=httpx.Request("GET", "https://example.com"),
            text="hello",
        )

        async def fake_request(
            method: str,
            url: str,
            **kwargs: object,
        ) -> httpx.Response:
            _ = (method, url, kwargs)
            await lowlevel.checkpoint()
            return response

        monkeypatch.setattr(client, "request", fake_request)
        result = await request_text(
            client,
            "GET",
            "https://example.com",
            headers={"Authorization": "Bearer token"},
            context="request failed",
            timeout=10.0,
        )

    assert result.ok is True
    assert result.value == "hello"


@pytest.mark.anyio
async def test_request_and_parse_maps_http_error(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    async with httpx.AsyncClient() as client:

        async def fake_request(
            method: str,
            url: str,
            **kwargs: object,
        ) -> httpx.Response:
            _ = (method, url, kwargs)
            await lowlevel.checkpoint()
            request = httpx.Request("GET", url)
            raise httpx.ConnectError("offline", request=request)

        monkeypatch.setattr(client, "request", fake_request)
        result = await request_and_parse(
            client,
            "GET",
            "https://example.com",
            headers={},
            model=ExamplePayload,
            context="request failed",
            timeout=10.0,
        )

    assert result.ok is False
    assert result.error is not None
    assert "request failed" in result.error.message


@pytest.mark.anyio
async def test_request_text_maps_http_error_without_duplication(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    async with httpx.AsyncClient() as client:

        async def fake_request(
            method: str,
            url: str,
            **kwargs: object,
        ) -> httpx.Response:
            _ = (method, url, kwargs)
            await lowlevel.checkpoint()
            request = httpx.Request("GET", url)
            raise httpx.ConnectError("offline", request=request)

        monkeypatch.setattr(client, "request", fake_request)
        result = await request_text(
            client,
            "GET",
            "https://example.com",
            headers={},
            context="download failed",
            timeout=10.0,
        )

    assert result.ok is False
    assert result.error is not None
    assert "download failed" in result.error.message
    # Ensure context is NOT duplicated (was "download failed: download failed: ...")
    assert result.error.message.count("download failed") == 1
