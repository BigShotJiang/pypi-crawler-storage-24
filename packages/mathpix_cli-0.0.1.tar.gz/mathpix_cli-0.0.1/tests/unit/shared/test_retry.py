from __future__ import annotations

from dataclasses import dataclass

import anyio
import pytest
from mathpix_cli.shared.errors import ErrorCode
from mathpix_cli.shared.result import Result
from mathpix_cli.shared.retry import (
    is_completed,
    is_failed,
    poll_with_retry,
    retry_result,
    validate_polling,
    validate_retries,
)


@dataclass
class Counter:
    calls: int = 0


def test_validate_polling_rejects_non_positive_values() -> None:
    result = validate_polling(max_polling_time=0, polling_interval=1)

    assert result.ok is False
    assert result.error is not None
    assert "max_polling_time" in result.error.message


def test_validate_polling_rejects_non_positive_interval() -> None:
    result = validate_polling(max_polling_time=1, polling_interval=0)

    assert result.ok is False
    assert result.error is not None
    assert "polling_interval" in result.error.message


def test_validate_retries_rejects_non_positive_values() -> None:
    result = validate_retries(0)

    assert result.ok is False
    assert result.error is not None
    assert "max_retries" in result.error.message


def test_status_helpers_match_provider_convention() -> None:
    assert is_completed("completed") is True
    assert is_failed("failed") is True
    assert is_failed("error") is True
    assert is_failed("pending") is False


@pytest.mark.anyio
async def test_retry_result_retries_until_success() -> None:
    counter = Counter()

    async def action() -> Result[str]:
        await anyio.lowlevel.checkpoint()
        counter.calls += 1
        if counter.calls == 1:
            return Result.failure(ErrorCode.NETWORK, "temporary")
        return Result.success("done")

    result = await retry_result(action=action, delay_seconds=0.0, retries=2)

    assert result.ok is True
    assert result.value == "done"
    assert counter.calls == 2


@pytest.mark.anyio
async def test_poll_with_retry_returns_success_for_completed_status() -> None:
    async def check() -> Result[str]:
        await anyio.lowlevel.checkpoint()
        return Result.success("completed")

    result = await poll_with_retry(
        check=check,
        delay_seconds=0.0,
        failure_label="Conversion",
        max_polling_time=2,
        max_retries=1,
        polling_interval=1,
        timeout_label="Conversion",
    )

    assert result.ok is True


@pytest.mark.anyio
async def test_poll_with_retry_returns_failure_for_failed_status() -> None:
    async def check() -> Result[str]:
        await anyio.lowlevel.checkpoint()
        return Result.success("failed")

    result = await poll_with_retry(
        check=check,
        delay_seconds=0.0,
        failure_label="Conversion",
        max_polling_time=2,
        max_retries=1,
        polling_interval=1,
        timeout_label="Conversion",
    )

    assert result.ok is False
    assert result.error is not None
    assert "failed with status: failed" in result.error.message


@pytest.mark.anyio
async def test_retry_result_returns_last_failure() -> None:
    async def action() -> Result[str]:
        await anyio.lowlevel.checkpoint()
        return Result.failure(ErrorCode.NETWORK, "temporary")

    result = await retry_result(action=action, delay_seconds=0.0, retries=1)

    assert result.ok is False
    assert result.error is not None
    assert result.error.message == "temporary"


@pytest.mark.anyio
async def test_retry_result_rejects_invalid_retry_count() -> None:
    async def action() -> Result[str]:
        await anyio.lowlevel.checkpoint()
        return Result.success("done")

    result = await retry_result(action=action, delay_seconds=0.0, retries=0)

    assert result.ok is False
    assert result.error is not None
    assert "max_retries" in result.error.message


@pytest.mark.anyio
async def test_poll_with_retry_times_out_when_status_stays_pending() -> None:
    async def check() -> Result[str]:
        await anyio.lowlevel.checkpoint()
        return Result.success("pending")

    result = await poll_with_retry(
        check=check,
        delay_seconds=0.0,
        failure_label="Conversion",
        max_polling_time=1,
        max_retries=1,
        polling_interval=1,
        timeout_label="Conversion",
    )

    assert result.ok is False
    assert result.error is not None
    assert result.error.code is ErrorCode.TIMEOUT
