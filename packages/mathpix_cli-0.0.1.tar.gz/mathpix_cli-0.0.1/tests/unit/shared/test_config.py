from __future__ import annotations

from typing import TYPE_CHECKING

import pytest
from mathpix_cli.convert.model import OutputFormat
from mathpix_cli.shared.config import DEFAULT_OUTPUT_DIR, BackendMode, load_config
from mathpix_cli.snip.model import SnipFormat

if TYPE_CHECKING:
    from pathlib import Path


@pytest.fixture(autouse=True)
def clear_mathpix_env(monkeypatch: pytest.MonkeyPatch) -> None:
    for key in [
        "MATHPIX_V3_APP_ID",
        "MATHPIX_V3_APP_KEY",
        "MATHPIX_CONVERT_MODE",
        "MATHPIX_FORMAT",
        "MATHPIX_V1_AUTH_TOKEN",
        "MATHPIX_SNIP_MODE",
        "MATHPIX_SNIP_FORMAT",
    ]:
        monkeypatch.delenv(key, raising=False)


def auth_value() -> str:
    return "test-token"


def test_load_config_auto_mode_with_v1_and_v3(tmp_path: Path) -> None:
    toml = tmp_path / "config.toml"
    toml.write_text('[auth]\nv3_app_id = "id"\nv3_app_key = "key"\n')
    v1_config = tmp_path / "v1_config"
    v1_config.write_text(f"MATHPIX_V1_AUTH_TOKEN={auth_value()}\n")

    result = load_config(toml, v1_token_path=str(v1_config))

    assert result.ok is True
    assert result.value is not None
    assert result.value.convert.mode is BackendMode.AUTO
    assert result.value.v3 is not None
    assert result.value.v1 is not None


def test_load_config_reads_v1_mode_from_toml(tmp_path: Path) -> None:
    toml = tmp_path / "config.toml"
    toml.write_text(f'[convert]\nmode = "v1"\n\n[auth]\nv1_auth_token = "{auth_value()}"\n')

    result = load_config(toml, v1_token_path=str(tmp_path / "missing"))

    assert result.ok is True
    assert result.value is not None
    assert result.value.convert.mode is BackendMode.V1
    assert result.value.v1 is not None
    assert result.value.v1.token == auth_value()


def test_load_config_reads_v3_mode_from_env(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    monkeypatch.setenv("MATHPIX_CONVERT_MODE", "v3")
    monkeypatch.setenv("MATHPIX_V3_APP_ID", "id")
    monkeypatch.setenv("MATHPIX_V3_APP_KEY", "key")

    result = load_config(tmp_path / "config.toml", v1_token_path=str(tmp_path / "missing"))

    assert result.ok is True
    assert result.value is not None
    assert result.value.convert.mode is BackendMode.V3


def test_load_config_reads_convert_format_from_toml(tmp_path: Path) -> None:
    toml = tmp_path / "config.toml"
    toml.write_text(
        '[convert]\nmode = "v3"\nformat = "mmd"\n\n[auth]\nv3_app_id = "id"\nv3_app_key = "key"\n'
    )

    result = load_config(toml, v1_token_path=str(tmp_path / "missing"))

    assert result.ok is True
    assert result.value is not None
    assert result.value.convert.format is OutputFormat.MMD


def test_load_config_reads_snip_settings(tmp_path: Path) -> None:
    toml = tmp_path / "config.toml"
    toml.write_text(
        '[convert]\nmode = "v3"\n'
        '\n[auth]\nv3_app_id = "id"\nv3_app_key = "key"\n'
        '\n[snip]\nmode = "v3"\nformat = "text"\ninclude_chemistry = true\nrm_fonts = true\n'
    )

    result = load_config(toml, v1_token_path=str(tmp_path / "missing"))

    assert result.ok is True
    assert result.value is not None
    assert result.value.snip.mode is BackendMode.V3
    assert result.value.snip.format is SnipFormat.TEXT
    assert result.value.snip.options.include_chemistry is True
    assert result.value.snip.options.rm_fonts is True


def test_load_config_reads_convert_format_from_env(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    monkeypatch.setenv("MATHPIX_FORMAT", "mmd")
    monkeypatch.setenv("MATHPIX_V3_APP_ID", "id")
    monkeypatch.setenv("MATHPIX_V3_APP_KEY", "key")

    toml = tmp_path / "config.toml"
    toml.write_text('[convert]\nmode = "v3"\n')

    result = load_config(toml, v1_token_path=str(tmp_path / "missing"))

    assert result.ok is True
    assert result.value is not None
    assert result.value.convert.format is OutputFormat.MMD


def test_load_config_uses_default_output_dir_for_blank_value(tmp_path: Path) -> None:
    toml = tmp_path / "config.toml"
    toml.write_text(
        '[output]\ndir = "   "\n\n[auth]\nv3_app_id = "id"\nv3_app_key = "key"\n',
        encoding="utf-8",
    )

    result = load_config(toml, v1_token_path=str(tmp_path / "missing"))

    assert result.ok is True
    assert result.value is not None
    assert result.value.output.dir == DEFAULT_OUTPUT_DIR


def test_load_config_reads_delimiter_pairs(tmp_path: Path) -> None:
    toml = tmp_path / "config.toml"
    toml.write_text(
        '[auth]\nv3_app_id = "id"\nv3_app_key = "key"\n'
        '\n[snip]\nmath_display_delimiters = ["$$", "$$"]\n'
        'math_inline_delimiters = ["\\\\(", "\\\\)"]\n',
        encoding="utf-8",
    )

    result = load_config(toml, v1_token_path=str(tmp_path / "missing"))

    assert result.ok is True
    assert result.value is not None
    assert result.value.snip.options.math_display_delimiters == ("$$", "$$")
    assert result.value.snip.options.math_inline_delimiters == ("\\(", "\\)")


def test_load_config_rejects_invalid_delimiter_pair(tmp_path: Path) -> None:
    toml = tmp_path / "config.toml"
    toml.write_text(
        '[auth]\nv3_app_id = "id"\nv3_app_key = "key"\n'
        '\n[snip]\nmath_inline_delimiters = ["\\\\("]\n',
        encoding="utf-8",
    )

    result = load_config(toml, v1_token_path=str(tmp_path / "missing"))

    assert result.ok is False
    assert result.error is not None
    assert "math_inline_delimiters" in result.error.message


def test_load_config_rejects_invalid_port_in_base_url(tmp_path: Path) -> None:
    toml = tmp_path / "config.toml"
    toml.write_text(
        '[auth]\nv3_app_id = "id"\nv3_app_key = "key"\nv3_api_base = "https://api.mathpix.com:abc/v3"\n',
        encoding="utf-8",
    )

    result = load_config(toml, v1_token_path=str(tmp_path / "missing"))

    assert result.ok is False
    assert result.error is not None
    assert "invalid port" in result.error.message


def test_load_config_returns_defaults_when_config_file_is_missing(tmp_path: Path) -> None:
    v1_config = tmp_path / "v1_config"
    v1_config.write_text(f"MATHPIX_V1_AUTH_TOKEN={auth_value()}\n", encoding="utf-8")

    result = load_config(tmp_path / "missing.toml", v1_token_path=str(v1_config))

    assert result.ok is True
    assert result.value is not None
    assert result.value.convert.mode is BackendMode.AUTO


def test_load_config_rejects_invalid_toml(tmp_path: Path) -> None:
    toml = tmp_path / "config.toml"
    toml.write_text("[auth\nv3_app_id = 'id'\n", encoding="utf-8")

    result = load_config(toml, v1_token_path=str(tmp_path / "missing"))

    assert result.ok is False
    assert result.error is not None
    assert "Invalid config TOML" in result.error.message


def test_load_config_rejects_invalid_mode(tmp_path: Path) -> None:
    toml = tmp_path / "config.toml"
    toml.write_text('[convert]\nmode = "invalid"\n')

    result = load_config(toml, v1_token_path=str(tmp_path / "missing"))

    assert result.ok is False
    assert result.error is not None
    assert "invalid" in result.error.message


def test_load_config_rejects_invalid_format(tmp_path: Path) -> None:
    toml = tmp_path / "config.toml"
    toml.write_text(
        '[convert]\nmode = "v3"\nformat = "docx"\n\n[auth]\nv3_app_id = "id"\nv3_app_key = "key"\n'
    )

    result = load_config(toml, v1_token_path=str(tmp_path / "missing"))

    assert result.ok is False
    assert result.error is not None
    assert "docx" in result.error.message


def test_load_config_shows_at_most_five_validation_errors(tmp_path: Path) -> None:
    toml = tmp_path / "config.toml"
    toml.write_text(
        "[convert]\n"
        'format = "docx"\n'
        "max_polling_time = 0\n"
        "max_retries = 0\n"
        'mode = "invalid"\n'
        "polling_interval = 0\n"
        '\n[snip]\nformat = "docx"\n',
        encoding="utf-8",
    )

    result = load_config(toml, v1_token_path=str(tmp_path / "missing"))

    assert result.ok is False
    assert result.error is not None
    assert result.error.message.count("\n- ") == 6
    assert "convert_format" in result.error.message
    assert "snip_format" not in result.error.message
    assert "1 more error" in result.error.message


def test_load_config_rejects_invalid_v3_base_url(tmp_path: Path) -> None:
    toml = tmp_path / "config.toml"
    toml.write_text(
        '[convert]\nmode = "v3"\n\n[auth]\nv3_app_id = "id"\nv3_app_key = "key"\n'
        'v3_api_base = "api.mathpix.com/v3"\n'
    )

    result = load_config(toml, v1_token_path=str(tmp_path / "missing"))

    assert result.ok is False
    assert result.error is not None
    assert "v3_api_base" in result.error.message.lower()


def test_load_config_rejects_invalid_v1_base_url(tmp_path: Path) -> None:
    toml = tmp_path / "config.toml"
    toml.write_text(
        '[convert]\nmode = "v1"\n\n[auth]\n'
        f'v1_auth_token = "{auth_value()}"\n'
        'v1_api_base = "ftp://api.mathpix.com/v1"\n'
    )

    result = load_config(toml, v1_token_path=str(tmp_path / "missing"))

    assert result.ok is False
    assert result.error is not None
    assert "v1_api_base" in result.error.message.lower()


def test_load_config_rejects_non_positive_polling(tmp_path: Path) -> None:
    toml = tmp_path / "config.toml"
    toml.write_text(
        '[convert]\nmode = "v3"\nmax_polling_time = 0\n'
        '\n[auth]\nv3_app_id = "id"\nv3_app_key = "key"\n'
    )

    result = load_config(toml, v1_token_path=str(tmp_path / "missing"))

    assert result.ok is False
    assert result.error is not None
    assert "max_polling_time" in result.error.message


def test_load_config_rejects_bool_retries(tmp_path: Path) -> None:
    toml = tmp_path / "config.toml"
    toml.write_text(
        '[convert]\nmode = "v3"\nmax_retries = true\n'
        '\n[auth]\nv3_app_id = "id"\nv3_app_key = "key"\n'
    )

    result = load_config(toml, v1_token_path=str(tmp_path / "missing"))

    assert result.ok is False
    assert result.error is not None
    assert "max_retries" in result.error.message


@pytest.mark.parametrize(
    ("toml_text", "error_word"),
    [
        ('[convert]\nmode = "v1"\n', "v1_auth_token"),
        ('[convert]\nmode = "v3"\n', "v3_app_id"),
        ("", 'mode="auto"'),
    ],
)
def test_load_config_requires_convert_credentials(
    tmp_path: Path,
    toml_text: str,
    error_word: str,
) -> None:
    toml = tmp_path / "config.toml"
    toml.write_text(toml_text)

    result = load_config(toml, v1_token_path=str(tmp_path / "missing"))

    assert result.ok is False
    assert result.error is not None
    assert error_word in result.error.message.lower()


def test_load_config_requires_snip_api_credentials(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    monkeypatch.delenv("MATHPIX_V1_AUTH_TOKEN", raising=False)
    toml = tmp_path / "config.toml"
    toml.write_text(
        '[convert]\nmode = "v1"\n\n[auth]\nv1_auth_token = "token"\n\n[snip]\nmode = "v3"\n',
        encoding="utf-8",
    )

    result = load_config(toml, v1_token_path=str(tmp_path / "missing"))

    assert result.ok is False
    assert result.error is not None
    assert '[snip] mode="v3"' in result.error.message


def test_load_config_reads_xdg_default_path(
    monkeypatch: pytest.MonkeyPatch,
    tmp_path: Path,
) -> None:
    xdg_home = tmp_path / "xdg"
    config_dir = xdg_home / "mathpix-cli"
    config_dir.mkdir(parents=True)
    (config_dir / "config.toml").write_text(
        '[auth]\nv3_app_id = "id"\nv3_app_key = "key"\n',
        encoding="utf-8",
    )
    monkeypatch.setenv("XDG_CONFIG_HOME", str(xdg_home))

    result = load_config(None, v1_token_path=str(tmp_path / "missing"))

    assert result.ok is True
    assert result.value is not None
    assert result.value.v3 is not None
