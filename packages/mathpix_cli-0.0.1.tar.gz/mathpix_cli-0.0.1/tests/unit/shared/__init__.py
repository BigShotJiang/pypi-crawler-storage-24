"""Shared module tests."""
