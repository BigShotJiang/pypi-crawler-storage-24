from __future__ import annotations

import pytest
from mathpix_cli.shared.errors import ErrorCode
from mathpix_cli.shared.result import Result, error_message


def test_failure_result_exposes_error() -> None:
    result: Result[str] = Result.failure(ErrorCode.IO, "bad")

    assert result.ok is False
    assert result.value is None
    assert result.error is not None
    assert result.error.message == "bad"


def test_success_result_exposes_value() -> None:
    result = Result.success(42)

    assert result.ok is True
    assert result.value == 42
    assert result.error is None


def test_unwrap_raises_on_failure() -> None:
    result: Result[str] = Result.failure(ErrorCode.IO, "bad")

    with pytest.raises(RuntimeError, match="bad"):
        _ = result.unwrap


def test_alt_maps_error() -> None:
    result: Result[str] = Result.failure(ErrorCode.IO, "bad").alt(
        lambda error: error.__class__(code=ErrorCode.CONFIG, message=f"wrapped: {error.message}")
    )

    assert result.ok is False
    assert result.error is not None
    assert result.error.code is ErrorCode.CONFIG
    assert result.error.message == "wrapped: bad"


def test_bind_maps_success_to_next_result() -> None:
    result = Result.success(2).bind(lambda value: Result.success(value * 3))

    assert result.ok is True
    assert result.value == 6


def test_bind_preserves_failure() -> None:
    result: Result[int] = Result.failure(ErrorCode.IO, "bad")

    mapped = result.bind(lambda value: Result.success(value * 3))

    assert mapped.ok is False
    assert mapped.error is not None
    assert mapped.error.message == "bad"


def test_forward_returns_failure_when_called_on_failure() -> None:
    result: Result[str] = Result.failure(ErrorCode.IO, "bad")

    forwarded: Result[int] = result.forward()

    assert forwarded.ok is False
    assert forwarded.error is not None
    assert forwarded.error.message == "bad"


def test_map_preserves_failure() -> None:
    result: Result[int] = Result.failure(ErrorCode.IO, "bad")

    mapped = result.map(lambda value: value * 2)

    assert mapped.ok is False
    assert mapped.error is not None
    assert mapped.error.message == "bad"


def test_or_else_replaces_failure_message() -> None:
    result: Result[str] = Result.failure(ErrorCode.IO, "bad")

    replaced = result.or_else(ErrorCode.CONFIG, "wrapped")

    assert replaced.ok is False
    assert replaced.error is not None
    assert replaced.error.code is ErrorCode.CONFIG
    assert replaced.error.message == "wrapped: bad"


def test_or_else_keeps_success_unchanged() -> None:
    result = Result.success("ok")

    replaced = result.or_else(ErrorCode.CONFIG, "wrapped")

    assert replaced.ok is True
    assert replaced.value == "ok"


def test_error_message_uses_default_for_success() -> None:
    result = Result.success("ok")

    assert error_message(result, default="fallback") == "fallback"


def test_error_message_uses_unknown_without_default() -> None:
    result = Result.success("ok")

    assert error_message(result) == "unknown"
