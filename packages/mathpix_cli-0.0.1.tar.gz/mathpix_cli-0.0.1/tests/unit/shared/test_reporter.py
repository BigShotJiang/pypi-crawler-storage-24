from __future__ import annotations

from io import StringIO

from mathpix_cli.shared.reporter import ConsoleReporter
from rich.console import Console


def _make_reporter() -> tuple[ConsoleReporter, StringIO, StringIO]:
    stdout = StringIO()
    stderr = StringIO()
    reporter = ConsoleReporter(
        out_console=Console(file=stdout, highlight=False, soft_wrap=True),
        err_console=Console(file=stderr, highlight=False, soft_wrap=True),
    )
    return reporter, stdout, stderr


def test_warn_and_error_write_to_stderr() -> None:
    reporter, _stdout, stderr = _make_reporter()

    reporter.warn("careful")
    reporter.error("broken")

    err_value = stderr.getvalue()
    assert "WARN  careful" in err_value
    assert "ERROR  broken" in err_value


def test_summary_writes_to_stdout_without_label() -> None:
    reporter, stdout, _stderr = _make_reporter()

    reporter.summary("mathpix-v1 -> md | file.pdf")

    output = stdout.getvalue()
    assert "mathpix-v1 -> md | file.pdf" in output
    assert "INFO" not in output


def test_content_writes_to_stdout_without_label() -> None:
    reporter, stdout, _stderr = _make_reporter()

    reporter.content("x^2 + y^2")

    output = stdout.getvalue()
    assert "x^2 + y^2" in output
    assert "INFO" not in output


def test_status_writes_label_and_path() -> None:
    reporter, stdout, _stderr = _make_reporter()

    reporter.status("Saved", "/path/to/main.md")

    output = stdout.getvalue()
    assert "Saved" in output
    assert "/path/to/main.md" in output


def test_status_writes_detail_in_parentheses() -> None:
    reporter, stdout, _stderr = _make_reporter()

    reporter.status("Saved", "/path/to/main.md", detail="5 images")

    output = stdout.getvalue()
    assert "(5 images)" in output


def test_detail_writes_indented_to_stdout() -> None:
    reporter, stdout, _stderr = _make_reporter()

    reporter.detail("backend: mathpix-v1")

    output = stdout.getvalue()
    assert "  backend: mathpix-v1" in output
