"""Tests for mathpix-cli."""
