module.exports = {
  platform: "github",
  onboarding: false,
  requireConfig: "optional",
  allowScripts: true,
};
