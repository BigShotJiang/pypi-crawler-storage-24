"""Shared filesystem path helpers."""

from __future__ import annotations

import unicodedata
from pathlib import Path

from mathpix_cli.shared.errors import ErrorCode
from mathpix_cli.shared.result import Result


def normalize_path(path: str) -> str:
    """Normalize a filesystem path to NFC."""
    return unicodedata.normalize("NFC", path)


def resolve_source_path(path: str) -> Result[Path]:
    """Resolve a user-provided filesystem path."""
    if path.startswith("~"):
        return Result.failure(
            ErrorCode.VALIDATION,
            (
                "Home directory expansion is not allowed.\n"
                f"Input: '{path}'\n"
                "Please use an absolute or relative path instead.\n"
                "Example: /home/username/Documents/file.pdf"
            ),
        )

    normalized_path = normalize_path(path)
    return Result.success(Path(normalized_path).resolve())
