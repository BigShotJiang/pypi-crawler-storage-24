from __future__ import annotations

from typing import TYPE_CHECKING, TypeVar, cast

from tenacity import (
    AsyncRetrying,
    retry_if_exception_type,
    stop_after_attempt,
    stop_after_delay,
    wait_fixed,
)

from mathpix_cli.shared.errors import AppError, ErrorCode
from mathpix_cli.shared.result import Result

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

R = TypeVar("R")

CONFIG_MAX_POLLING_TIME_POSITIVE = "max_polling_time must be greater than zero"
CONFIG_MAX_RETRIES_POSITIVE = "max_retries must be greater than zero"
CONFIG_POLLING_INTERVAL_POSITIVE = "polling_interval must be greater than zero"
COMPLETED_STATUS = "completed"
FAILED_STATUSES = frozenset({"error", "failed"})


class _PendingPollError(Exception):
    """Internal retry signal used while polling asynchronous operations."""


class _RetryableFailureError(Exception):
    """Internal retry signal for transient operation failures."""

    def __init__(self, error: AppError) -> None:
        super().__init__(error.message)
        self.error = error


class _TerminalPollFailureError(Exception):
    """Internal signal for unrecoverable polling failures."""

    def __init__(self, error: AppError) -> None:
        super().__init__(error.message)
        self.error = error


def validate_polling(*, max_polling_time: int, polling_interval: int) -> Result[None]:
    """Validate polling configuration."""
    if max_polling_time <= 0:
        return Result.failure(ErrorCode.CONFIG, CONFIG_MAX_POLLING_TIME_POSITIVE)
    if polling_interval <= 0:
        return Result.failure(ErrorCode.CONFIG, CONFIG_POLLING_INTERVAL_POSITIVE)
    return Result.success(None)


def validate_retries(max_retries: int) -> Result[None]:
    """Validate retry configuration."""
    if max_retries <= 0:
        return Result.failure(ErrorCode.CONFIG, CONFIG_MAX_RETRIES_POSITIVE)
    return Result.success(None)


def is_completed(status: str) -> bool:
    """Return whether a provider status marks completion."""
    return status == COMPLETED_STATUS


def is_failed(status: str) -> bool:
    """Return whether a provider status marks failure."""
    return status in FAILED_STATUSES


async def _poll_result[R](
    *,
    action: Callable[[], Awaitable[Result[R]]],
    interval_seconds: int,
    is_done: Callable[[R], bool],
    timeout_message: str,
    timeout_seconds: int,
    to_terminal_error: Callable[[R], AppError | None],
) -> Result[R]:
    validation = validate_polling(
        max_polling_time=timeout_seconds,
        polling_interval=interval_seconds,
    )
    if not validation.ok:
        return validation.forward()

    try:
        async for attempt in AsyncRetrying(
            stop=stop_after_delay(timeout_seconds),
            wait=wait_fixed(interval_seconds),
            retry=retry_if_exception_type(_PendingPollError),
            reraise=True,
        ):
            with attempt:
                value = _unwrap_poll_step(await action())
                terminal_error = to_terminal_error(value)
                if terminal_error is not None:
                    _raise_terminal(terminal_error)
                if is_done(value):
                    return Result.success(value)
                _raise_pending()
    except _TerminalPollFailureError as exc:
        return Result.failure_error(exc.error)
    except _PendingPollError:
        return Result.failure(ErrorCode.TIMEOUT, timeout_message)

    return Result.failure(ErrorCode.INTERNAL, "polling did not execute")


async def _retry_result[R](
    *,
    action: Callable[[], Awaitable[Result[R]]],
    delay_seconds: float,
    retries: int,
) -> Result[R]:
    validation = validate_retries(retries)
    if not validation.ok:
        return validation.forward()

    try:
        async for attempt in AsyncRetrying(
            stop=stop_after_attempt(retries),
            wait=wait_fixed(delay_seconds),
            retry=retry_if_exception_type(_RetryableFailureError),
            reraise=True,
        ):
            with attempt:
                current = await action()
                if current.ok:
                    return current
                if current.error is not None:
                    _raise_retryable(current.error)
                _raise_retryable(
                    AppError(code=ErrorCode.INTERNAL, message="operation failed without an error")
                )
    except _RetryableFailureError as exc:
        return Result.failure_error(exc.error)

    return Result.failure(ErrorCode.INTERNAL, "retry did not execute")


async def _poll_with_retry(
    *,
    check: Callable[[], Awaitable[Result[str]]],
    delay_seconds: float,
    failure_label: str,
    max_polling_time: int,
    max_retries: int,
    polling_interval: int,
    timeout_label: str,
) -> Result[None]:
    def _terminal_error(status: str) -> AppError | None:
        if is_failed(status):
            return AppError(
                code=ErrorCode.NETWORK,
                message=f"{failure_label} failed with status: {status}",
            )
        return None

    poll_status = await _poll_result(
        action=lambda: _retry_result(
            action=check,
            delay_seconds=delay_seconds,
            retries=max_retries,
        ),
        interval_seconds=polling_interval,
        is_done=is_completed,
        timeout_message=f"{timeout_label} timeout after {max_polling_time}s",
        timeout_seconds=max_polling_time,
        to_terminal_error=_terminal_error,
    )
    if not poll_status.ok:
        return poll_status.forward()
    return Result.success(None)


def _unwrap_poll_step[R](step_result: Result[R]) -> R:
    if not step_result.ok:
        if step_result.error is not None:
            _raise_terminal(step_result.error)
        _raise_terminal(
            AppError(code=ErrorCode.INTERNAL, message="polling step failed without an error")
        )

    value = step_result.value
    if value is None:
        _raise_terminal(
            AppError(code=ErrorCode.INTERNAL, message="polling step succeeded without a value")
        )
    return cast("R", value)


def _raise_pending() -> None:
    raise _PendingPollError


def _raise_retryable(error: AppError) -> None:
    raise _RetryableFailureError(error)


def _raise_terminal(error: AppError) -> None:
    raise _TerminalPollFailureError(error)


poll_with_retry = _poll_with_retry
retry_result = _retry_result
