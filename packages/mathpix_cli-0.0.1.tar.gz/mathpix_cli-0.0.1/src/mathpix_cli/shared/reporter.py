"""Console reporter implementation."""

from __future__ import annotations

import sys
from dataclasses import dataclass, field

from rich.console import Console
from rich.text import Text


@dataclass(frozen=True, slots=True)
class ConsoleReporter:
    """Report user-facing messages to stdout and stderr."""

    err_console: Console = field(
        default_factory=lambda: Console(
            file=sys.stderr,
            highlight=False,
            soft_wrap=True,
        )
    )
    out_console: Console = field(
        default_factory=lambda: Console(
            file=sys.stdout,
            highlight=False,
            soft_wrap=True,
        )
    )

    def detail(self, message: str) -> None:
        """Print an indented verbose detail line."""
        self.out_console.print(f"  {message}")

    def error(self, message: str) -> None:
        """Print an error message."""
        self._emit(self.err_console, "ERROR", "bold red", message)

    def content(self, message: str) -> None:
        """Print command output without any label."""
        self.out_console.print(message)

    def status(self, label: str, path: str, *, detail: str = "") -> None:
        """Print a status line (Saved/Cached) with path and optional metadata."""
        suffix = f"  ({detail})" if detail else ""
        text = Text.assemble((label, "bold green"), ("  ", ""), (f"{path}{suffix}", ""))
        self.out_console.print(text)

    def summary(self, message: str) -> None:
        """Print a summary line without any label."""
        self.out_console.print(message)

    def warn(self, message: str) -> None:
        """Print a warning message."""
        self._emit(self.err_console, "WARN", "bold yellow", message)

    @staticmethod
    def _emit(console: Console, label: str, style: str, message: str) -> None:
        text = Text.assemble((label, style), ("  ", ""), (message, ""))
        console.print(text)
