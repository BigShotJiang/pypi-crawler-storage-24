"""Shared filesystem history store helpers."""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path

import anyio

from mathpix_cli.shared.errors import ErrorCode
from mathpix_cli.shared.result import Result


async def read_history(history_path: Path, *, default_key: str) -> Result[dict[str, object]]:
    """Read and parse `history.json`."""
    try:
        content = await anyio.Path(history_path).read_text(encoding="utf-8")
    except FileNotFoundError:
        return Result.success({default_key: {}})
    except OSError as exc:
        return Result.failure(ErrorCode.IO, f"Failed to read history file: {exc}")

    try:
        loaded = json.loads(content)
    except json.JSONDecodeError as exc:
        return Result.failure(ErrorCode.IO, f"Invalid history.json: {exc}")

    if isinstance(loaded, dict):
        return Result.success(loaded)
    return Result.failure(
        ErrorCode.IO,
        "Invalid history.json: root object must be a JSON object",
    )


def read_history_section(history: dict[str, object], section_key: str) -> dict[str, object] | None:
    """Return one named history section when present and valid."""
    section = history.get(section_key)
    if isinstance(section, dict):
        return section
    return None


def upsert_history_section(history: dict[str, object], section_key: str) -> dict[str, object]:
    """Return one named history section, creating it when needed."""
    section = read_history_section(history, section_key)
    if section is not None:
        return section

    section = {}
    history[section_key] = section
    return section


async def write_history(history_path: Path, history: dict[str, object]) -> Result[None]:
    """Write `history.json`."""
    temp_path: Path | None = None
    try:
        history_path = Path(history_path)
        await anyio.Path(history_path).parent.mkdir(parents=True, exist_ok=True)
        serialized = json.dumps(history, indent=2, ensure_ascii=False)
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=str(history_path.parent),
            prefix=f".{history_path.name}.",
            suffix=".tmp",
            delete=False,
        ) as handle:
            temp_path = Path(handle.name)
            handle.write(serialized)
            handle.flush()
            os.fsync(handle.fileno())
        _replace_file(temp_path, history_path)
        return Result.success(None)
    except OSError as exc:
        try:
            if temp_path is not None and await anyio.Path(temp_path).exists():
                _unlink_file(temp_path)
        except OSError:
            pass
        return Result.failure(ErrorCode.IO, f"Failed to write history file: {exc}")


async def find_cached_path(
    history_path: Path,
    *,
    default_key: str,
    section_key: str,
    cache_entry_key: str,
    main_file: Path,
) -> Result[str | None]:
    """Return a cached path when history and the target file both exist."""
    history_result = await read_history(history_path, default_key=default_key)
    if not history_result.ok:
        return history_result.or_else(ErrorCode.IO, "Failed to read history").forward()

    history = history_result.unwrap
    section = read_history_section(history, section_key)
    if section is None:
        return Result.success(None)

    entry = section.get(cache_entry_key)
    if not isinstance(entry, dict):
        return Result.success(None)

    if await anyio.Path(main_file).exists():
        return Result.success(str(await anyio.Path(main_file).resolve()))
    return Result.success(None)


def cache_key(sha256: str, format_value: str) -> str:
    """Build a cache key from a content hash and format identifier."""
    return f"{sha256}:{format_value}"


def _replace_file(source: Path, target: Path) -> None:
    """Atomically replace one file with another."""
    os.replace(source, target)  # noqa: PTH105


def _unlink_file(path: Path) -> None:
    """Remove one file if it still exists."""
    path.unlink()
