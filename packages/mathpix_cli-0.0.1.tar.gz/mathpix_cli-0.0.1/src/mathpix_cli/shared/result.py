from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING, TypeVar, cast

from returns.pipeline import is_successful
from returns.result import Failure, Success
from returns.result import Result as ReturnsResult

from mathpix_cli.shared.errors import AppError, ErrorCode

if TYPE_CHECKING:
    from collections.abc import Callable

T = TypeVar("T")

UNKNOWN_ERROR_MESSAGE = "unknown"


@dataclass(frozen=True, slots=True)
class Result[R]:
    """Application result wrapper."""

    _inner: ReturnsResult[R, AppError]

    @property
    def error(self) -> AppError | None:
        """Return the error for failures."""
        if isinstance(self._inner, Failure):
            return cast("AppError", self._inner.failure())
        return None

    @property
    def ok(self) -> bool:
        """Return whether the result succeeded."""
        return is_successful(self._inner)

    @property
    def unwrap(self) -> R:
        """Return the success value.

        Raises:
            RuntimeError: The result is a failure.
        """
        if isinstance(self._inner, Success):
            return cast("R", self._inner.unwrap())
        message = self.error.message if self.error else UNKNOWN_ERROR_MESSAGE
        raise RuntimeError(f"unwrap called on failure Result: {message}")

    @property
    def value(self) -> R | None:
        """Return the success value or ``None``."""
        if isinstance(self._inner, Success):
            return cast("R", self._inner.unwrap())
        return None

    def alt(self, function: Callable[[AppError], AppError]) -> Result[R]:
        """Map the error value."""
        return Result(self._inner.alt(function))

    def bind(self, function: Callable[[R], Result[T]]) -> Result[T]:
        """Bind another ``Result`` function."""
        if isinstance(self._inner, Success):
            return function(cast("R", self._inner.unwrap()))
        return Result(cast("ReturnsResult[T, AppError]", self._inner))

    def forward(self) -> Result[T]:
        """Forward the current failure."""
        if self.error is not None:
            return Result.failure_error(self.error)
        return Result.failure(ErrorCode.INTERNAL, "forwarded failure without error")

    def map(self, function: Callable[[R], T]) -> Result[T]:
        """Map the success value."""
        return Result(self._inner.map(function))

    def or_else(self, code: ErrorCode, message: str) -> Result[R]:
        """Rewrite the failure message."""
        if self.ok:
            return self
        original = self.error.message if self.error else UNKNOWN_ERROR_MESSAGE
        return Result.failure(code, f"{message}: {original}")

    @staticmethod
    def failure(code: ErrorCode, message: str) -> Result[R]:
        """Build a failure."""
        return Result(Failure(AppError(code=code, message=message)))

    @staticmethod
    def failure_error(error: AppError) -> Result[R]:
        """Build a failure from an error."""
        return Result(Failure(error))

    @staticmethod
    def success(value: R) -> Result[R]:
        """Build a success."""
        return Result(Success(value))


def error_message[T](result: Result[T], *, default: str | None = None) -> str:
    """Return the error message."""
    if result.error is not None:
        return result.error.message
    if default is not None:
        return default
    return UNKNOWN_ERROR_MESSAGE
