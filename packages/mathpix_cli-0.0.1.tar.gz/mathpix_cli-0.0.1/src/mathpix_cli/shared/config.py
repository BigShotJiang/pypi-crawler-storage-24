from __future__ import annotations

import os
import tomllib
from dataclasses import dataclass, field
from enum import StrEnum
from pathlib import Path
from typing import Annotated, Any, cast
from urllib.parse import urlparse

from pydantic import AliasChoices, Field, ValidationError, ValidationInfo, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

from mathpix_cli.convert.model import OutputFormat
from mathpix_cli.shared.errors import ErrorCode
from mathpix_cli.shared.http import normalize_http_base_url
from mathpix_cli.shared.result import Result
from mathpix_cli.snip.model import SnipFormat, SnipOptions

APP_NAME = "mathpix-cli"
CONFIG_FILENAME = "config.toml"
DEFAULT_MATHPIX_V3_API_BASE = "https://api.mathpix.com/v3"
DEFAULT_MAX_POLLING_TIME = 600
DEFAULT_MAX_RETRIES = 2
DEFAULT_MATHPIX_V1_API_BASE = "https://api.mathpix.com/v1"
DEFAULT_MATHPIX_V1_SNIP_API_BASE = "https://snip-api.mathpix.com"
DEFAULT_V1_TOKEN_PATH = "~/.config/mathpix-cli/v1.env"  # noqa: S105
DEFAULT_OUTPUT_DIR = "~/.mathpix-cli"
DEFAULT_POLLING_INTERVAL = 3
DEFAULT_SNIP_FORMAT = SnipFormat.LATEX

PositiveStrictInt = Annotated[int, Field(ge=1, strict=True)]


class BackendMode(StrEnum):
    """Backend mode."""

    AUTO = "auto"
    V1 = "v1"
    V3 = "v3"


@dataclass(frozen=True, slots=True)
class MathpixV3Credentials:
    """Mathpix v3 credentials."""

    app_id: str
    app_key: str
    base_url: str = DEFAULT_MATHPIX_V3_API_BASE


@dataclass(frozen=True, slots=True)
class ConvertSettings:
    """Convert settings."""

    format: OutputFormat = OutputFormat.MD
    max_polling_time: int = DEFAULT_MAX_POLLING_TIME
    max_retries: int = DEFAULT_MAX_RETRIES
    mode: BackendMode = BackendMode.AUTO
    polling_interval: int = DEFAULT_POLLING_INTERVAL


@dataclass(frozen=True, slots=True)
class MathpixV1Credentials:
    """Mathpix v1 credentials."""

    token: str
    base_url: str = DEFAULT_MATHPIX_V1_API_BASE
    snip_api_base: str = DEFAULT_MATHPIX_V1_SNIP_API_BASE


@dataclass(frozen=True, slots=True)
class OutputSettings:
    """Output settings."""

    dir: str = DEFAULT_OUTPUT_DIR


@dataclass(frozen=True, slots=True)
class SnipSettings:
    """Snip settings."""

    format: SnipFormat = DEFAULT_SNIP_FORMAT
    mode: BackendMode = BackendMode.AUTO
    options: SnipOptions = field(default_factory=SnipOptions)
    show_result: bool = True


@dataclass(frozen=True, slots=True)
class AppConfig:
    """Runtime configuration."""

    v3: MathpixV3Credentials | None = None
    convert: ConvertSettings = field(default_factory=ConvertSettings)
    v1: MathpixV1Credentials | None = None
    output: OutputSettings = field(default_factory=OutputSettings)
    snip: SnipSettings = field(default_factory=SnipSettings)


class RuntimeSettings(BaseSettings):
    """Validated settings from config and env."""

    model_config = SettingsConfigDict(env_prefix="", extra="ignore", populate_by_name=True)

    v3_api_base: str = Field(
        default=DEFAULT_MATHPIX_V3_API_BASE,
        validation_alias=AliasChoices("v3_api_base", "MATHPIX_V3_API_BASE"),
    )
    v3_app_id: str | None = Field(
        default=None,
        validation_alias=AliasChoices("v3_app_id", "MATHPIX_V3_APP_ID"),
    )
    v3_app_key: str | None = Field(
        default=None,
        validation_alias=AliasChoices("v3_app_key", "MATHPIX_V3_APP_KEY"),
    )
    convert_format: OutputFormat = Field(
        default=OutputFormat.MD,
        validation_alias=AliasChoices("convert_format", "MATHPIX_FORMAT"),
    )
    convert_max_polling_time: PositiveStrictInt = Field(
        default=DEFAULT_MAX_POLLING_TIME,
        validation_alias=AliasChoices("convert_max_polling_time", "MATHPIX_MAX_POLLING_TIME"),
    )
    convert_max_retries: PositiveStrictInt = Field(
        default=DEFAULT_MAX_RETRIES,
        validation_alias=AliasChoices("convert_max_retries", "MATHPIX_MAX_RETRIES"),
    )
    convert_mode: BackendMode = Field(
        default=BackendMode.AUTO,
        validation_alias=AliasChoices("convert_mode", "MATHPIX_CONVERT_MODE"),
    )
    convert_polling_interval: PositiveStrictInt = Field(
        default=DEFAULT_POLLING_INTERVAL,
        validation_alias=AliasChoices("convert_polling_interval", "MATHPIX_POLLING_INTERVAL"),
    )
    v1_api_base: str = Field(
        default=DEFAULT_MATHPIX_V1_API_BASE,
        validation_alias=AliasChoices(
            "v1_api_base",
            "MATHPIX_V1_API_BASE",
        ),
    )
    v1_auth_token: str | None = Field(
        default=None,
        validation_alias=AliasChoices(
            "v1_auth_token",
            "MATHPIX_V1_AUTH_TOKEN",
        ),
    )
    v1_snip_api_base: str = Field(
        default=DEFAULT_MATHPIX_V1_SNIP_API_BASE,
        validation_alias=AliasChoices(
            "v1_snip_api_base",
            "MATHPIX_V1_SNIP_API_BASE",
        ),
    )
    output_dir: str = Field(
        default=DEFAULT_OUTPUT_DIR,
        validation_alias=AliasChoices("output_dir", "MATHPIX_OUTPUT_DIR"),
    )
    snip_format: SnipFormat = Field(
        default=DEFAULT_SNIP_FORMAT,
        validation_alias=AliasChoices("snip_format", "MATHPIX_SNIP_FORMAT"),
    )
    snip_include_chemistry: bool = Field(
        default=False,
        validation_alias=AliasChoices("snip_include_chemistry", "MATHPIX_SNIP_INCLUDE_CHEMISTRY"),
    )
    snip_include_diagrams: bool = Field(
        default=False,
        validation_alias=AliasChoices("snip_include_diagrams", "MATHPIX_SNIP_INCLUDE_DIAGRAMS"),
    )
    snip_math_display_delimiters: tuple[str, str] | None = Field(
        default=None,
        validation_alias=AliasChoices("snip_math_display_delimiters"),
    )
    snip_math_inline_delimiters: tuple[str, str] | None = Field(
        default=None,
        validation_alias=AliasChoices("snip_math_inline_delimiters"),
    )
    snip_mode: BackendMode = Field(
        default=BackendMode.AUTO,
        validation_alias=AliasChoices("snip_mode", "MATHPIX_SNIP_MODE"),
    )
    snip_rm_fonts: bool = Field(
        default=False,
        validation_alias=AliasChoices("snip_rm_fonts", "MATHPIX_SNIP_RM_FONTS"),
    )
    snip_show_result: bool = Field(
        default=True,
        validation_alias=AliasChoices("snip_show_result", "MATHPIX_SNIP_SHOW_RESULT"),
    )

    @field_validator("v3_app_id", "v3_app_key", "v1_auth_token", mode="before")
    @classmethod
    def _blank_to_none(cls, value: object) -> object:
        if isinstance(value, str) and not value.strip():
            return None
        return value

    @field_validator("v3_api_base", "v1_api_base", "v1_snip_api_base", mode="before")
    @classmethod
    def _normalize_base_url(cls, value: object, info: ValidationInfo) -> object:
        if not isinstance(value, str):
            return value

        normalized = normalize_http_base_url(value.strip(), field=info.field_name or "url")
        if not normalized.ok:
            if normalized.error is not None:
                raise ValueError(normalized.error.message)
            raise ValueError("must be an absolute HTTP(S) URL")

        parsed = urlparse(normalized.unwrap)
        try:
            _ = parsed.port
        except ValueError as exc:
            raise ValueError("contains an invalid port") from exc

        return normalized.unwrap

    @field_validator("snip_math_display_delimiters", "snip_math_inline_delimiters", mode="before")
    @classmethod
    def _normalize_delimiter_pair(cls, value: object) -> object:
        if value is None:
            return None
        if isinstance(value, (list, tuple)) and len(value) == 2:
            return (str(value[0]), str(value[1]))
        raise ValueError("must be a pair of two strings, e.g. ['\\\\(', '\\\\)']")

    @field_validator("output_dir", mode="before")
    @classmethod
    def _normalize_output_dir(cls, value: object) -> object:
        if isinstance(value, str) and not value.strip():
            return DEFAULT_OUTPUT_DIR
        return value


def load_config(
    config_path: Path | None = None,
    *,
    v1_token_path: str = DEFAULT_V1_TOKEN_PATH,
) -> Result[AppConfig]:
    """Load runtime configuration."""
    path = config_path or _xdg_config_path()

    toml_result = _read_toml(path)
    if not toml_result.ok:
        return toml_result.forward()

    try:
        flattened = cast("dict[str, Any]", _flatten_toml(toml_result.unwrap))
        settings = RuntimeSettings(**flattened)
    except ValidationError as exc:
        return Result.failure(ErrorCode.CONFIG, _format_validation_error(exc))

    v3, v1 = _build_credentials(settings, v1_token_path=v1_token_path)
    convert = _build_convert_settings(settings)

    credential_result = _validate_credentials(
        v3=v3,
        convert=convert,
        v1=v1,
        snip_mode=settings.snip_mode,
    )
    if not credential_result.ok:
        return credential_result.forward()

    return Result.success(_build_app_config(v3=v3, v1=v1, settings=settings, convert=convert))


def _build_app_config(
    *,
    v3: MathpixV3Credentials | None,
    v1: MathpixV1Credentials | None,
    settings: RuntimeSettings,
    convert: ConvertSettings,
) -> AppConfig:
    snip = SnipSettings(
        format=settings.snip_format,
        mode=settings.snip_mode,
        options=SnipOptions(
            include_chemistry=settings.snip_include_chemistry,
            include_diagrams=settings.snip_include_diagrams,
            math_display_delimiters=settings.snip_math_display_delimiters,
            math_inline_delimiters=settings.snip_math_inline_delimiters,
            rm_fonts=settings.snip_rm_fonts,
        ),
        show_result=settings.snip_show_result,
    )
    return AppConfig(
        v3=v3,
        convert=convert,
        v1=v1,
        output=OutputSettings(dir=settings.output_dir),
        snip=snip,
    )


def _build_convert_settings(settings: RuntimeSettings) -> ConvertSettings:
    return ConvertSettings(
        format=settings.convert_format,
        max_polling_time=settings.convert_max_polling_time,
        max_retries=settings.convert_max_retries,
        mode=settings.convert_mode,
        polling_interval=settings.convert_polling_interval,
    )


def _build_credentials(
    settings: RuntimeSettings,
    *,
    v1_token_path: str,
) -> tuple[MathpixV3Credentials | None, MathpixV1Credentials | None]:
    v3 = None
    if settings.v3_app_id and settings.v3_app_key:
        v3 = MathpixV3Credentials(
            app_id=settings.v3_app_id,
            app_key=settings.v3_app_key,
            base_url=settings.v3_api_base,
        )

    token = settings.v1_auth_token or _read_v1_token(v1_token_path)
    v1 = None
    if token:
        v1 = MathpixV1Credentials(
            token=token,
            base_url=settings.v1_api_base,
            snip_api_base=settings.v1_snip_api_base,
        )
    return (v3, v1)


def _copy_mapped_values(
    *,
    source: dict[str, object],
    mapping: dict[str, str],
    target: dict[str, object],
) -> None:
    for source_key, target_key in mapping.items():
        if source_key in source:
            target[target_key] = source[source_key]


def _flatten_toml(raw: dict[str, object]) -> dict[str, object]:
    auth_raw = _section(raw, "auth")
    convert_raw = _section(raw, "convert")
    output_raw = _section(raw, "output")
    snip_raw = _section(raw, "snip")

    data: dict[str, object] = {}
    _copy_mapped_values(
        source=convert_raw,
        mapping={
            "format": "convert_format",
            "max_polling_time": "convert_max_polling_time",
            "max_retries": "convert_max_retries",
            "mode": "convert_mode",
            "polling_interval": "convert_polling_interval",
        },
        target=data,
    )
    _copy_mapped_values(
        source=auth_raw,
        mapping={
            "v3_api_base": "v3_api_base",
            "v3_app_id": "v3_app_id",
            "v3_app_key": "v3_app_key",
            "v1_api_base": "v1_api_base",
            "v1_auth_token": "v1_auth_token",
            "v1_snip_api_base": "v1_snip_api_base",
        },
        target=data,
    )
    if "dir" in output_raw:
        data["output_dir"] = output_raw["dir"]
    _copy_mapped_values(
        source=snip_raw,
        mapping={
            "format": "snip_format",
            "include_chemistry": "snip_include_chemistry",
            "include_diagrams": "snip_include_diagrams",
            "math_display_delimiters": "snip_math_display_delimiters",
            "math_inline_delimiters": "snip_math_inline_delimiters",
            "mode": "snip_mode",
            "rm_fonts": "snip_rm_fonts",
            "show_result": "snip_show_result",
        },
        target=data,
    )
    return data


def _format_validation_error(exc: ValidationError) -> str:
    details = exc.errors(include_url=False)
    formatted = [_format_validation_error_detail(detail) for detail in details[:5]]
    if not formatted:
        return "invalid configuration: invalid value"
    if len(formatted) == 1:
        return f"invalid configuration for {formatted[0]}"

    lines = ["invalid configuration:"]
    lines.extend(f"- {message}" for message in formatted)
    if len(details) > 5:
        remaining = len(details) - 5
        suffix = "error" if remaining == 1 else "errors"
        lines.append(f"- ... and {remaining} more {suffix}")
    return "\n".join(lines)


def _format_validation_error_detail(detail: object) -> str:
    detail_dict = cast("dict[str, object]", detail)
    location_parts = [
        str(part)
        for part in cast(
            "tuple[object, ...] | list[object]",
            detail_dict.get("loc", ()),
        )
    ]
    location = ".".join(location_parts)
    message = str(detail_dict.get("msg", "invalid value"))
    received = detail_dict.get("input")
    if location:
        if received is not None:
            return f"{location}: {message}. Received: {received!r}"
        return f"{location}: {message}"
    if received is not None:
        return f"{message}. Received: {received!r}"
    return message


def _read_v1_token(v1_token_path: str = DEFAULT_V1_TOKEN_PATH) -> str | None:
    token_path = Path(v1_token_path).expanduser()
    if not token_path.exists():
        return None

    try:
        text = token_path.read_text(encoding="utf-8")
    except OSError:
        return None

    for line in text.splitlines():
        stripped = line.strip()
        if stripped.startswith("#") or "=" not in stripped:
            continue
        key, _, value = stripped.partition("=")
        token = value.strip().strip("\"'")
        if key.strip() == "MATHPIX_V1_AUTH_TOKEN" and token:
            return token
    return None


def _read_toml(path: Path) -> Result[dict[str, object]]:
    if not path.exists():
        return Result.success({})

    try:
        with path.open("rb") as handle:
            loaded = tomllib.load(handle)
    except OSError as exc:
        return Result.failure(ErrorCode.IO, f"Failed to read config file: {exc}")
    except tomllib.TOMLDecodeError as exc:
        return Result.failure(ErrorCode.CONFIG, f"Invalid config TOML: {exc}")

    return Result.success(loaded)


def _section(raw: dict[str, object], name: str) -> dict[str, object]:
    value = raw.get(name)
    if isinstance(value, dict):
        return value
    return {}


def _validate_credentials(
    *,
    v3: MathpixV3Credentials | None,
    convert: ConvertSettings,
    v1: MathpixV1Credentials | None,
    snip_mode: BackendMode,
) -> Result[None]:
    convert_result = _validate_mode_credentials(
        scope="convert",
        mode=convert.mode,
        v3=v3,
        v1=v1,
        require_auto_credentials=True,
    )
    if not convert_result.ok:
        return convert_result

    return _validate_mode_credentials(
        scope="snip",
        mode=snip_mode,
        v3=v3,
        v1=v1,
        require_auto_credentials=False,
    )


def _validate_mode_credentials(
    *,
    scope: str,
    mode: BackendMode,
    v3: MathpixV3Credentials | None,
    v1: MathpixV1Credentials | None,
    require_auto_credentials: bool,
) -> Result[None]:
    if mode is BackendMode.V1 and v1 is None:
        return Result.failure(ErrorCode.CONFIG, _missing_v1_credentials(scope))
    if mode is BackendMode.V3 and v3 is None:
        return Result.failure(ErrorCode.CONFIG, _missing_v3_credentials(scope))
    if require_auto_credentials and mode is BackendMode.AUTO and v1 is None and v3 is None:
        return Result.failure(ErrorCode.CONFIG, _missing_auto_credentials(scope))
    return Result.success(None)


def _missing_v1_credentials(scope: str) -> str:
    return (
        f'[{scope}] mode="v1" requires [auth].v1_auth_token, MATHPIX_V1_AUTH_TOKEN, '
        f"or {DEFAULT_V1_TOKEN_PATH}."
    )


def _missing_v3_credentials(scope: str) -> str:
    return (
        f'[{scope}] mode="v3" requires [auth].v3_app_id and [auth].v3_app_key, '
        "or MATHPIX_V3_APP_ID and MATHPIX_V3_APP_KEY."
    )


def _missing_auto_credentials(scope: str) -> str:
    return f'[{scope}] mode="auto" requires v1_auth_token or v3_app_id/v3_app_key.'


def _xdg_config_path() -> Path:
    xdg_config_home = os.environ.get("XDG_CONFIG_HOME")
    if xdg_config_home:
        base = Path(xdg_config_home).expanduser()
    else:
        base = Path.home() / ".config"
    return base / APP_NAME / CONFIG_FILENAME
