from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum


@dataclass(frozen=True, slots=True)
class AppError:
    """Application error value."""

    code: ErrorCode
    message: str

    def __str__(self) -> str:
        """Return the human-readable error message."""
        return self.message


class ErrorCode(StrEnum):
    """Supported application error codes."""

    CONFIG = "config"
    INTERNAL = "internal"
    IO = "io"
    NETWORK = "network"
    TIMEOUT = "timeout"
    VALIDATION = "validation"
