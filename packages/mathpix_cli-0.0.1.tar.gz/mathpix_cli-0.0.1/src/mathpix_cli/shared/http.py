from __future__ import annotations

from typing import Any, cast
from urllib.parse import urlparse

import httpx
from pydantic import BaseModel, ValidationError

from mathpix_cli.shared.errors import ErrorCode
from mathpix_cli.shared.result import Result


def normalize_http_base_url(raw_url: str, *, field: str) -> Result[str]:
    """Validate and normalize a configured HTTP(S) base URL."""
    value = raw_url.strip()
    if not value:
        return Result.failure(ErrorCode.CONFIG, f"{field} must not be empty")

    parsed = urlparse(value)
    scheme = parsed.scheme.lower()
    if scheme not in {"http", "https"} or not parsed.netloc:
        return Result.failure(
            ErrorCode.CONFIG,
            f"{field} must be an absolute HTTP(S) URL. Received: {raw_url!r}",
        )

    path = parsed.path.rstrip("/")
    return Result.success(f"{scheme}://{parsed.netloc}{path}")


def parse_response_model[M: BaseModel](
    response: httpx.Response,
    *,
    context: str,
    model: type[M],
) -> Result[M]:
    """Parse a JSON HTTP response into a validated Pydantic model."""
    try:
        payload = model.model_validate_json(response.text)
    except ValidationError as exc:
        return Result.failure(ErrorCode.NETWORK, f"{context}: {_validation_error_message(exc)}")
    return Result.success(payload)


def _validation_error_message(exc: ValidationError) -> str:
    detail = exc.errors(include_url=False)[0]
    error_type = str(detail.get("type", ""))
    if error_type == "json_invalid":
        return "invalid json response"

    location_parts = [str(part) for part in detail.get("loc", ())]
    location = ".".join(location_parts)
    message = str(detail.get("msg", "invalid response payload"))
    if location:
        return f"invalid response field '{location}': {message}"
    return f"invalid response payload: {message}"


async def request_and_parse[M: BaseModel](
    client: httpx.AsyncClient,
    method: str,
    url: str,
    *,
    headers: dict[str, str],
    model: type[M],
    context: str,
    timeout: float,  # noqa: ASYNC109
    **kwargs: object,
) -> Result[M]:
    """Send one HTTP request and parse the JSON body into a model."""
    response_result = await _request_response(
        client,
        method,
        url,
        headers=headers,
        context=context,
        timeout=timeout,
        **kwargs,
    )
    if not response_result.ok:
        return response_result.forward()

    return parse_response_model(
        response_result.unwrap,
        context=context,
        model=model,
    ).or_else(ErrorCode.NETWORK, context)


async def request_text(
    client: httpx.AsyncClient,
    method: str,
    url: str,
    *,
    headers: dict[str, str],
    context: str,
    timeout: float,  # noqa: ASYNC109
    **kwargs: object,
) -> Result[str]:
    """Send one HTTP request and return the response text."""
    response_result = await _request_response(
        client,
        method,
        url,
        headers=headers,
        context=context,
        timeout=timeout,
        **kwargs,
    )
    if not response_result.ok:
        return response_result.forward()
    return Result.success(response_result.unwrap.text)


async def _request_response(
    client: httpx.AsyncClient,
    method: str,
    url: str,
    *,
    headers: dict[str, str],
    context: str,
    timeout: float,  # noqa: ASYNC109
    **kwargs: object,
) -> Result[httpx.Response]:
    try:
        request_kwargs = cast("dict[str, Any]", kwargs)
        response = await client.request(
            method,
            url,
            headers=headers,
            timeout=timeout,
            **request_kwargs,
        )
        response.raise_for_status()
    except httpx.HTTPError as exc:
        return Result.failure(ErrorCode.NETWORK, f"{context}: {exc}")
    return Result.success(response)
