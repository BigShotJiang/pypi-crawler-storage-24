"""Shared backend selection logic for resolvers."""

from __future__ import annotations

from enum import StrEnum

from mathpix_cli.shared.config import BackendMode
from mathpix_cli.shared.errors import ErrorCode
from mathpix_cli.shared.result import Result


class ResolvedBackend(StrEnum):
    """Resolved backend."""

    MATHPIX_V1 = "mathpix-v1"
    MATHPIX_V3 = "mathpix-v3"


def resolve_backend(mode: BackendMode, *, v1_available: bool) -> ResolvedBackend:
    """Resolve the active backend."""
    if mode is BackendMode.V1:
        return ResolvedBackend.MATHPIX_V1
    if mode is BackendMode.V3:
        return ResolvedBackend.MATHPIX_V3
    if v1_available:
        return ResolvedBackend.MATHPIX_V1
    return ResolvedBackend.MATHPIX_V3


def select_backend[T](
    *,
    mode: BackendMode,
    build_v1: T | None,
    build_v3: T | None,
) -> Result[T]:
    """Select a backend instance."""
    if mode is BackendMode.V1:
        return _require(build_v1, message="mathpix-v1 backend is not configured")
    if mode is BackendMode.V3:
        return _require(build_v3, message="mathpix-v3 backend is not configured")

    selected = build_v1 if build_v1 is not None else build_v3
    return _require(selected, message="no backend is configured")


def _require[T](value: T | None, *, message: str) -> Result[T]:
    if value is None:
        return Result.failure(ErrorCode.CONFIG, message)
    return Result.success(value)
