"""Module entrypoint for ``python -m mathpix_cli``."""

from mathpix_cli.cli import main

if __name__ == "__main__":
    main()
