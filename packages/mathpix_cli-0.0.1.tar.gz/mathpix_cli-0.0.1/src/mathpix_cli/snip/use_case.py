from __future__ import annotations

import hashlib
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

import anyio

from mathpix_cli.shared.errors import ErrorCode
from mathpix_cli.shared.result import Result
from mathpix_cli.snip.model import SavedSnip, SnipFormat, SnipOptions, SnipOutcome, SnipRequest

SUPPORTED_IMAGE_EXTENSIONS: frozenset[str] = frozenset(
    {".bmp", ".gif", ".jpeg", ".jpg", ".png", ".tiff", ".webp"}
)


class SnipConverter(Protocol):
    """Convert image bytes into a snip result."""

    async def snip(
        self,
        image: bytes,
        fmt: SnipFormat,
        *,
        options: SnipOptions | None = None,
    ) -> Result[SnipOutcome]:
        """Convert one image."""


class SnipStore(Protocol):
    """Store snip outputs."""

    async def find_cached(
        self, sha256: str, fmt: SnipFormat, *, options: SnipOptions | None = None
    ) -> Result[str | None]:
        """Return a cached snip path."""

    async def save(
        self,
        *,
        text: str,
        sha256: str,
        source: str,
        fmt: SnipFormat,
        confidence: float,
        options: SnipOptions | None = None,
    ) -> Result[str]:
        """Save one snip output."""


@dataclass(frozen=True, slots=True)
class SnipUseCase:
    """Run one snip request with caching."""

    converter: SnipConverter
    store: SnipStore

    async def execute(self, request: SnipRequest) -> Result[SavedSnip]:
        """Run the snip flow."""
        read_result = await self._read_image(request.image_path)
        if not read_result.ok:
            return read_result.forward()
        image_bytes = read_result.unwrap

        sha256 = hashlib.sha256(image_bytes).hexdigest()
        cache_result = await self.store.find_cached(sha256, request.format, options=request.options)
        if not cache_result.ok:
            return cache_result.or_else(ErrorCode.IO, "Cache lookup failed").forward()

        cached_path = cache_result.value
        if cached_path is not None:
            return Result.success(SavedSnip(cache_hit=True, path=cached_path))

        return await self._run_uncached(
            request=request,
            image_bytes=image_bytes,
            sha256=sha256,
            source=request.image_path,
        )

    async def _run_uncached(
        self,
        *,
        request: SnipRequest,
        image_bytes: bytes,
        sha256: str,
        source: str,
    ) -> Result[SavedSnip]:
        snip_result = await self.converter.snip(
            image_bytes,
            request.format,
            options=request.options,
        )
        if not snip_result.ok:
            return snip_result.forward()

        outcome = snip_result.unwrap
        save_result = await self.store.save(
            text=outcome.text,
            sha256=sha256,
            source=source,
            fmt=request.format,
            confidence=outcome.confidence,
            options=request.options,
        )
        if not save_result.ok:
            return save_result.forward()

        return Result.success(SavedSnip(cache_hit=False, path=save_result.unwrap, outcome=outcome))

    @staticmethod
    async def _read_image(raw_path: str) -> Result[bytes]:
        """Validate and read an image file."""
        path = Path(raw_path)
        if path.suffix.lower() not in SUPPORTED_IMAGE_EXTENSIONS:
            return Result.failure(ErrorCode.VALIDATION, f"Unsupported image format: {path.suffix}")
        try:
            return Result.success(await anyio.Path(path).read_bytes())
        except FileNotFoundError:
            return Result.failure(ErrorCode.VALIDATION, f"File not found: {path}")
        except OSError as exc:
            return Result.failure(ErrorCode.IO, f"Failed to read image: {exc}")
