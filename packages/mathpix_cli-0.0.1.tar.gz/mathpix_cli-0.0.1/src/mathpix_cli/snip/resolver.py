"""Resolver for image snips."""

from __future__ import annotations

from typing import TYPE_CHECKING

from mathpix_cli.shared.resolver import resolve_backend, select_backend
from mathpix_cli.shared.result import Result
from mathpix_cli.snip.model import SnipFormat, SnipPlan
from mathpix_cli.snip.providers import MathpixV1SnipConverter, MathpixV3SnipConverter
from mathpix_cli.snip.store import FileSystemSnipStore
from mathpix_cli.snip.use_case import SnipUseCase

if TYPE_CHECKING:
    import httpx

    from mathpix_cli.shared.config import AppConfig
    from mathpix_cli.snip.use_case import SnipConverter


def build_plan(config: AppConfig, *, fmt: SnipFormat | None = None) -> SnipPlan:
    """Build the snip plan."""
    backend = resolve_backend(config.snip.mode, v1_available=config.v1 is not None)
    effective_fmt = fmt if fmt is not None else config.snip.format
    return SnipPlan(
        format=effective_fmt,
        summary_label=f"{backend} -> {effective_fmt.value}",
        backend=backend,
    )


def build_use_case(config: AppConfig, client: httpx.AsyncClient) -> Result[SnipUseCase]:
    """Build the snip use case from runtime configuration."""
    converter_result = _select_converter(config, client=client)
    if not converter_result.ok:
        return converter_result.forward()

    return Result.success(
        SnipUseCase(
            converter=converter_result.unwrap,
            store=FileSystemSnipStore(output_dir=config.output.dir),
        )
    )


def _select_converter(config: AppConfig, *, client: httpx.AsyncClient) -> Result[SnipConverter]:
    return select_backend(
        mode=config.snip.mode,
        build_v1=(
            MathpixV1SnipConverter(config=config.v1, client=client)
            if config.v1 is not None
            else None
        ),
        build_v3=(
            MathpixV3SnipConverter(config=config.v3, client=client)
            if config.v3 is not None
            else None
        ),
    )
