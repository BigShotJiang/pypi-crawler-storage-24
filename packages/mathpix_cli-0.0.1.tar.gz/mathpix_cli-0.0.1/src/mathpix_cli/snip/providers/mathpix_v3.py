from __future__ import annotations

import json
from dataclasses import dataclass
from typing import TYPE_CHECKING

from pydantic import BaseModel

from mathpix_cli.shared.errors import ErrorCode
from mathpix_cli.shared.http import request_and_parse
from mathpix_cli.shared.result import Result
from mathpix_cli.snip.model import (
    SnipFormat,
    SnipOptions,
    SnipOutcome,
    detect_image_mime,
    mime_extension,
)

if TYPE_CHECKING:
    import httpx

    from mathpix_cli.shared.config import MathpixV3Credentials


class MathpixDataEntry(BaseModel):
    """One `data` entry in a v3 response."""

    type: str
    value: str


class MathpixTextResponsePayload(BaseModel):
    """Mathpix v3 snip response payload."""

    confidence: float | None = None
    confidence_rate: float | None = None
    data: list[MathpixDataEntry] | None = None
    error: str | None = None
    html: str | None = None
    latex_styled: str | None = None
    request_id: str | None = None
    text: str | None = None


@dataclass(frozen=True, slots=True)
class _V3FormatSpec:
    """Static v3 snip format mapping."""

    data_options: dict[str, bool] | None = None
    formats: tuple[str, ...] = ()


_V3_FORMAT_SPECS: dict[SnipFormat, _V3FormatSpec] = {
    SnipFormat.ASCIIMATH: _V3FormatSpec(
        data_options={"include_asciimath": True},
        formats=("data",),
    ),
    SnipFormat.HTML: _V3FormatSpec(formats=("html",)),
    SnipFormat.LATEX: _V3FormatSpec(formats=("latex_styled",)),
    SnipFormat.MATHML: _V3FormatSpec(data_options={"include_mathml": True}, formats=("data",)),
    SnipFormat.TEXT: _V3FormatSpec(formats=("text",)),
}

SNIP_PARSE_ERROR_LABEL = "Snip response parse error"
SNIP_REQUEST_TIMEOUT_SECONDS = 30.0


@dataclass(frozen=True, slots=True)
class MathpixV3SnipConverter:
    """Mathpix v3 snip converter."""

    config: MathpixV3Credentials
    client: httpx.AsyncClient

    @staticmethod
    def _build_options_json(fmt: SnipFormat, options: SnipOptions | None) -> str:
        spec = _V3_FORMAT_SPECS[fmt]
        payload: dict[str, object] = {"formats": list(spec.formats)}
        if spec.data_options is not None:
            payload["data_options"] = spec.data_options
        if options is not None:
            payload["rm_fonts"] = options.rm_fonts
            if options.math_display_delimiters is not None:
                payload["math_display_delimiters"] = list(options.math_display_delimiters)
            if options.math_inline_delimiters is not None:
                payload["math_inline_delimiters"] = list(options.math_inline_delimiters)
        return json.dumps(payload)

    def _endpoint(self) -> str:
        return f"{self.config.base_url}/text"

    @staticmethod
    def _extract_result(fmt: SnipFormat, payload: MathpixTextResponsePayload) -> str | None:
        if fmt is SnipFormat.LATEX:
            return payload.latex_styled
        if fmt is SnipFormat.TEXT:
            return payload.text
        if fmt is SnipFormat.HTML:
            return payload.html
        if fmt in {SnipFormat.ASCIIMATH, SnipFormat.MATHML}:
            if payload.data is None:
                return None
            for entry in payload.data:
                if entry.type == fmt.value:
                    return entry.value
        return None

    def _headers(self) -> dict[str, str]:
        return {"app_id": self.config.app_id, "app_key": self.config.app_key}

    async def snip(
        self,
        image: bytes,
        fmt: SnipFormat,
        *,
        options: SnipOptions | None = None,
    ) -> Result[SnipOutcome]:
        """Convert one image into the requested snip format."""
        options_json = self._build_options_json(fmt, options)
        mime = detect_image_mime(image)
        if mime is None:
            return Result.failure(ErrorCode.VALIDATION, "Unrecognized image format")

        payload_result = await request_and_parse(
            self.client,
            "POST",
            self._endpoint(),
            headers=self._headers(),
            context=SNIP_PARSE_ERROR_LABEL,
            model=MathpixTextResponsePayload,
            timeout=SNIP_REQUEST_TIMEOUT_SECONDS,
            files={"file": (f"image{mime_extension(mime)}", image, mime)},
            data={"options_json": options_json},
        )
        if not payload_result.ok:
            return payload_result.forward()

        payload = payload_result.unwrap
        if payload.error:
            return Result.failure(ErrorCode.NETWORK, f"Snip API error: {payload.error}")

        result_text = self._extract_result(fmt, payload)
        if result_text is None:
            return Result.failure(ErrorCode.NETWORK, f"Snip response missing '{fmt.value}' field")

        return Result.success(
            SnipOutcome(
                confidence=payload.confidence or payload.confidence_rate or 0.0,
                format=fmt,
                snip_id=payload.request_id or "",
                text=result_text,
            )
        )
