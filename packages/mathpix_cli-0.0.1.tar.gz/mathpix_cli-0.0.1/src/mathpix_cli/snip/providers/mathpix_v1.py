from __future__ import annotations

import json
from dataclasses import dataclass
from typing import TYPE_CHECKING

from pydantic import BaseModel

from mathpix_cli.shared.errors import ErrorCode
from mathpix_cli.shared.http import request_and_parse
from mathpix_cli.shared.result import Result
from mathpix_cli.snip.model import (
    SnipFormat,
    SnipOptions,
    SnipOutcome,
    detect_image_mime,
    mime_extension,
)

if TYPE_CHECKING:
    import httpx

    from mathpix_cli.shared.config import MathpixV1Credentials

SNIP_PARSE_ERROR_LABEL = "Snip response parse error"
SNIP_REQUEST_TIMEOUT_SECONDS = 30.0

# The v1 endpoint only returns latex and text.
# Other formats are not available from this API.
_SUPPORTED_FORMATS: frozenset[SnipFormat] = frozenset({SnipFormat.LATEX, SnipFormat.TEXT})


def _check_format_supported(fmt: SnipFormat) -> Result[None]:
    """Reject unsupported v1 formats."""
    if fmt in _SUPPORTED_FORMATS:
        return Result.success(None)
    supported = ", ".join(sorted(f.value for f in _SUPPORTED_FORMATS))
    return Result.failure(
        ErrorCode.VALIDATION,
        f"mathpix-v1 does not support '{fmt.value}' format (supported: {supported})",
    )


class MathpixV1SnipResponsePayload(BaseModel):
    """Mathpix v1 snip response payload."""

    confidence: float | None = None
    confidence_rate: float | None = None
    created_at: str | None = None
    error: str | None = None
    latex: str | None = None
    snip_id: str | None = None
    text: str | None = None


@dataclass(frozen=True, slots=True)
class MathpixV1SnipConverter:
    """Mathpix v1 snip converter."""

    config: MathpixV1Credentials
    client: httpx.AsyncClient

    @staticmethod
    def _build_options_json(fmt: SnipFormat, options: SnipOptions | None) -> str:
        payload: dict[str, object] = {"formats": [fmt.value]}
        if options is not None:
            payload["include_chemistry"] = options.include_chemistry
            payload["include_diagrams"] = options.include_diagrams
            payload["rm_fonts"] = options.rm_fonts
            if options.math_display_delimiters is not None:
                payload["math_display_delimiters"] = list(options.math_display_delimiters)
            if options.math_inline_delimiters is not None:
                payload["math_inline_delimiters"] = list(options.math_inline_delimiters)
        else:
            payload["include_chemistry"] = False
            payload["include_diagrams"] = False
        return json.dumps(payload)

    def _endpoint(self) -> str:
        return f"{self.config.snip_api_base}/v1/snips-multipart"

    def _headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self.config.token}"}

    @staticmethod
    def _extract_outcome(
        payload: MathpixV1SnipResponsePayload,
        fmt: SnipFormat,
    ) -> Result[SnipOutcome]:
        """Parse the snip response."""
        if payload.error:
            return Result.failure(ErrorCode.NETWORK, f"Snip API error: {payload.error}")

        result_text = getattr(payload, fmt.value, None)
        if result_text is None:
            return Result.failure(ErrorCode.NETWORK, f"Snip response missing '{fmt.value}' field")

        return Result.success(
            SnipOutcome(
                confidence=payload.confidence or payload.confidence_rate or 0.0,
                format=fmt,
                snip_id=payload.snip_id or "",
                text=result_text,
            )
        )

    async def snip(
        self,
        image: bytes,
        fmt: SnipFormat,
        *,
        options: SnipOptions | None = None,
    ) -> Result[SnipOutcome]:
        """Convert one image into the requested snip format."""
        fmt_check = _check_format_supported(fmt)
        if not fmt_check.ok:
            return fmt_check.forward()

        options_json = self._build_options_json(fmt, options)
        mime = detect_image_mime(image)
        if mime is None:
            return Result.failure(ErrorCode.VALIDATION, "Unrecognized image format")

        payload_result = await request_and_parse(
            self.client,
            "POST",
            self._endpoint(),
            headers=self._headers(),
            model=MathpixV1SnipResponsePayload,
            context=SNIP_PARSE_ERROR_LABEL,
            timeout=SNIP_REQUEST_TIMEOUT_SECONDS,
            files={"file": (f"image{mime_extension(mime)}", image, mime)},
            data={"options_json": options_json},
        )
        if not payload_result.ok:
            return payload_result.forward()

        return self._extract_outcome(payload_result.unwrap, fmt)
