"""Models for image snips."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from enum import StrEnum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from mathpix_cli.shared.resolver import ResolvedBackend


class SnipFormat(StrEnum):
    """Supported snip formats."""

    ASCIIMATH = "asciimath"
    HTML = "html"
    LATEX = "latex"
    MATHML = "mathml"
    TEXT = "text"


SNIP_FORMAT_EXTENSIONS: dict[SnipFormat, str] = {
    SnipFormat.ASCIIMATH: ".txt",
    SnipFormat.HTML: ".html",
    SnipFormat.LATEX: ".tex",
    SnipFormat.MATHML: ".xml",
    SnipFormat.TEXT: ".txt",
}


@dataclass(frozen=True, slots=True)
class SnipOptions:
    """Snip options."""

    include_chemistry: bool = False
    include_diagrams: bool = False
    math_display_delimiters: tuple[str, str] | None = None
    math_inline_delimiters: tuple[str, str] | None = None
    rm_fonts: bool = False

    def fingerprint(self) -> str:
        """Return a short stable cache hash."""
        parts = (
            f"chem={self.include_chemistry}",
            f"diag={self.include_diagrams}",
            f"dd={self.math_display_delimiters}",
            f"di={self.math_inline_delimiters}",
            f"rm={self.rm_fonts}",
        )
        return hashlib.sha256("|".join(parts).encode()).hexdigest()[:12]


@dataclass(frozen=True, slots=True)
class SnipRequest:
    """Snip request."""

    format: SnipFormat
    image_path: str
    options: SnipOptions | None = None


@dataclass(frozen=True, slots=True)
class SnipOutcome:
    """Snip result."""

    confidence: float
    format: SnipFormat
    snip_id: str
    text: str


@dataclass(frozen=True, slots=True)
class SavedSnip:
    """Saved snip output."""

    cache_hit: bool
    path: str
    outcome: SnipOutcome | None = None


@dataclass(frozen=True, slots=True)
class SnipPlan:
    """Snip plan."""

    format: SnipFormat
    summary_label: str
    backend: ResolvedBackend


_MIME_EXTENSIONS: dict[str, str] = {
    "image/bmp": ".bmp",
    "image/gif": ".gif",
    "image/jpeg": ".jpg",
    "image/png": ".png",
    "image/tiff": ".tiff",
    "image/webp": ".webp",
}


_MAGIC_TABLE: tuple[tuple[int, tuple[bytes, ...], str], ...] = (
    (8, (b"\x89PNG\r\n\x1a\n",), "image/png"),
    (3, (b"GIF",), "image/gif"),
    (3, (b"\xff\xd8\xff",), "image/jpeg"),
    (2, (b"BM",), "image/bmp"),
    (4, (b"II\x2a\x00", b"MM\x00\x2a"), "image/tiff"),
)


def detect_image_mime(data: bytes) -> str | None:
    """Detect an image MIME type from magic bytes."""
    for length, signatures, mime in _MAGIC_TABLE:
        if data[:length] in signatures:
            return mime
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":
        return "image/webp"
    return None


def mime_extension(mime: str) -> str:
    """Return the canonical file extension for a MIME type."""
    return _MIME_EXTENSIONS.get(mime, ".jpg")
