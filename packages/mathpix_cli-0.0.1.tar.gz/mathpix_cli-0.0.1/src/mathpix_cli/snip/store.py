from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from functools import cached_property
from pathlib import Path

import anyio

from mathpix_cli.shared.errors import ErrorCode
from mathpix_cli.shared.paths import normalize_path
from mathpix_cli.shared.result import Result
from mathpix_cli.shared.store import (
    cache_key,
    find_cached_path,
    read_history,
    upsert_history_section,
    write_history,
)
from mathpix_cli.snip.model import SNIP_FORMAT_EXTENSIONS, SnipFormat, SnipOptions

_HISTORY_KEY = "snips"


@dataclass(frozen=True)
class FileSystemSnipStore:
    """Filesystem-backed store for snip outputs."""

    output_dir: str

    @cached_property
    def _base(self) -> Path:
        return Path(normalize_path(self.output_dir)).expanduser().resolve()

    def _history_path(self) -> Path:
        return self._base / "history.json"

    def _base_dir(self, fmt: SnipFormat, sha256: str) -> Path:
        return self._base / "snips" / fmt.value / sha256[:16]

    async def find_cached(
        self, sha256: str, fmt: SnipFormat, *, options: SnipOptions | None = None
    ) -> Result[str | None]:
        """Return a cached snip path."""
        opts_fp = options.fingerprint() if options is not None else None
        key_segment = _format_segment(fmt, opts_fp)
        ext = SNIP_FORMAT_EXTENSIONS[fmt]
        output_dir = self._base_dir(fmt, sha256)
        if opts_fp is not None:
            output_dir /= opts_fp
        main_file = output_dir / f"main{ext}"
        return await find_cached_path(
            self._history_path(),
            default_key=_HISTORY_KEY,
            section_key=_HISTORY_KEY,
            cache_entry_key=cache_key(sha256, key_segment),
            main_file=main_file,
        )

    async def save(
        self,
        *,
        text: str,
        sha256: str,
        source: str,
        fmt: SnipFormat,
        confidence: float,
        options: SnipOptions | None = None,
    ) -> Result[str]:
        """Persist a snip output and update history."""
        opts_fp = options.fingerprint() if options is not None else None
        key_segment = _format_segment(fmt, opts_fp)
        output_dir = self._base_dir(fmt, sha256)
        if opts_fp is not None:
            output_dir /= opts_fp
        try:
            await anyio.Path(output_dir).mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            return Result.failure(ErrorCode.IO, f"Failed to create output directory: {exc}")

        ext = SNIP_FORMAT_EXTENSIONS[fmt]
        main_file = output_dir / f"main{ext}"
        try:
            await anyio.Path(main_file).write_text(text, encoding="utf-8")
        except OSError as exc:
            return Result.failure(ErrorCode.IO, f"Failed to write snip result file: {exc}")

        history_result = await read_history(self._history_path(), default_key=_HISTORY_KEY)
        if not history_result.ok:
            return history_result.or_else(
                ErrorCode.IO,
                "Failed to load history for update",
            ).forward()

        history = history_result.unwrap
        snips = upsert_history_section(history, _HISTORY_KEY)

        snips[cache_key(sha256, key_segment)] = {
            "confidence": confidence,
            "timestamp": datetime.now(tz=UTC).isoformat(),
            "format": fmt.value,
            "source": Path(source).name,
        }

        write_result = await write_history(self._history_path(), history)
        if not write_result.ok:
            return write_result.or_else(ErrorCode.IO, "Failed to write history").forward()

        return Result.success(str(main_file.resolve()))


def _format_segment(fmt: SnipFormat, fingerprint: str | None) -> str:
    """Build the cache key segment from format and options fingerprint."""
    if fingerprint is not None:
        return f"{fmt.value}:{fingerprint}"
    return fmt.value
