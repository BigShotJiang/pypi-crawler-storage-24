"""Resolver for PDF conversion."""

from __future__ import annotations

from typing import TYPE_CHECKING

from mathpix_cli.convert.model import ConvertPlan
from mathpix_cli.convert.providers import MathpixV1PdfConverter, MathpixV3PdfConverter
from mathpix_cli.convert.reader import FileSystemPdfReader, HttpPdfReader
from mathpix_cli.convert.store import FileSystemConvertStore
from mathpix_cli.convert.use_case import ConvertUseCase
from mathpix_cli.shared.resolver import resolve_backend, select_backend
from mathpix_cli.shared.result import Result

if TYPE_CHECKING:
    import httpx

    from mathpix_cli.convert.use_case import PdfConverter
    from mathpix_cli.shared.config import AppConfig


def build_plan(config: AppConfig) -> ConvertPlan:
    """Build the runtime conversion plan from configuration."""
    backend = resolve_backend(config.convert.mode, v1_available=config.v1 is not None)
    output_format = config.convert.format
    return ConvertPlan(
        format=output_format,
        summary_label=f"{backend} -> {output_format.value}",
        backend=backend,
    )


def build_use_case(config: AppConfig, client: httpx.AsyncClient) -> Result[ConvertUseCase]:
    """Build the conversion use case from runtime configuration."""
    converter_result = _select_converter(config, client=client)
    if not converter_result.ok:
        return converter_result.forward()

    return Result.success(
        ConvertUseCase(
            converter=converter_result.unwrap,
            local_reader=FileSystemPdfReader(),
            remote_reader=HttpPdfReader(client=client),
            store=FileSystemConvertStore(output_dir=config.output.dir),
        )
    )


def _select_converter(config: AppConfig, *, client: httpx.AsyncClient) -> Result[PdfConverter]:
    return select_backend(
        mode=config.convert.mode,
        build_v1=(
            MathpixV1PdfConverter(config=config.v1, client=client)
            if config.v1 is not None
            else None
        ),
        build_v3=(
            MathpixV3PdfConverter(config=config.v3, client=client)
            if config.v3 is not None
            else None
        ),
    )
