from __future__ import annotations

import re
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import TYPE_CHECKING
from urllib.parse import parse_qs, urlparse

import anyio
import httpx

from mathpix_cli.shared.errors import ErrorCode
from mathpix_cli.shared.result import Result

if TYPE_CHECKING:
    from pathlib import Path

CDN_IMAGE_DOWNLOAD_TIMEOUT_SECONDS = 30.0
MAX_CONCURRENT_IMAGE_DOWNLOADS = 8

CDN_PATTERN = re.compile(r"!\[([^\]]*)\]\((https://cdn\.mathpix\.com/cropped/[^)]+)\)")
MMD_CDN_PATTERN = re.compile(
    r"\\includegraphics\[([^\]]*)\]\{(https://cdn\.mathpix\.com/cropped/[^}]+)\}"
)


@dataclass(frozen=True)
class CdnImageMatch(ABC):
    """Abstract match for a CDN-hosted image reference embedded in output."""

    alt_text: str
    original_match: str
    span: tuple[int, int]
    url: str

    @abstractmethod
    def local_ref(self, local_path: str) -> str:
        """Render the localized image reference for the specific syntax."""


@dataclass(frozen=True)
class CdnUrlInfo:
    """Parsed metadata extracted from a Mathpix CDN image URL."""

    base_name: str
    extension: str
    height: str | None = None
    width: str | None = None


@dataclass(frozen=True)
class ImageLocalization:
    """Result of downloading and relinking embedded CDN images."""

    images_downloaded: int
    markdown: str
    warnings: tuple[str, ...]


@dataclass(frozen=True)
class MarkdownImageMatch(CdnImageMatch):
    """Markdown image reference found in generated output."""

    def local_ref(self, local_path: str) -> str:
        """Return the localized Markdown image reference."""
        return f"![{self.alt_text}]({local_path})"


@dataclass(frozen=True)
class MultiMarkdownImageMatch(CdnImageMatch):
    """MultiMarkdown image reference found in generated output."""

    def local_ref(self, local_path: str) -> str:
        """Return the localized MultiMarkdown image reference."""
        return f"\\includegraphics[{self.alt_text}]{{{local_path}}}"


async def download_cdn_images(markdown: str, images_dir: Path) -> Result[ImageLocalization]:
    """Download CDN-hosted images and rewrite the markdown to local paths."""
    matches = find_cdn_images(markdown)
    if not matches:
        return Result.success(
            ImageLocalization(images_downloaded=0, markdown=markdown, warnings=())
        )

    try:
        await anyio.Path(images_dir).mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        return Result.failure(ErrorCode.IO, f"Failed to create images directory: {exc}")

    counters: dict[str, int] = {}
    plan: list[tuple[CdnImageMatch, str, Path]] = []
    limiter = anyio.CapacityLimiter(MAX_CONCURRENT_IMAGE_DOWNLOADS)
    for found in matches:
        url_info = parse_cdn_url(found.url)
        base_name = url_info.base_name or "image"
        extension = url_info.extension or "jpg"
        sequence = counters.get(base_name, 0) + 1
        counters[base_name] = sequence
        filename = f"{base_name}-{sequence:02d}.{extension}"
        plan.append((found, filename, images_dir / filename))

    successes: dict[int, str] = {}  # match index -> replacement text
    warnings: list[str] = []

    async def _download_one(idx: int, found: CdnImageMatch, filename: str, file_path: Path) -> None:
        async with limiter:
            try:
                response = await client.get(found.url, timeout=CDN_IMAGE_DOWNLOAD_TIMEOUT_SECONDS)
                response.raise_for_status()
                await anyio.Path(file_path).write_bytes(response.content)
            except httpx.HTTPError as exc:
                warnings.append(f"Failed to download {found.url}: {exc}")
                return
            except OSError as exc:
                warnings.append(f"Failed to write image {file_path}: {exc}")
                return
            successes[idx] = found.local_ref(f"images/{filename}")

    async with httpx.AsyncClient() as client, anyio.create_task_group() as tg:
        for idx, (found, filename, file_path) in enumerate(plan):
            tg.start_soon(_download_one, idx, found, filename, file_path)

    # Rebuild the text from match positions for deterministic replacements.
    parts: list[str] = []
    cursor = 0
    for idx, (found, _filename, _file_path) in enumerate(plan):
        start, end = found.span
        parts.extend((markdown[cursor:start], successes.get(idx, found.original_match)))
        cursor = end
    parts.append(markdown[cursor:])
    transformed = "".join(parts)

    return Result.success(
        ImageLocalization(
            images_downloaded=len(successes),
            markdown=transformed,
            warnings=tuple(warnings),
        )
    )


def find_cdn_images(text: str) -> list[CdnImageMatch]:
    """Return markdown and MMD CDN image references found in the text."""
    matches: list[CdnImageMatch] = [
        MarkdownImageMatch(
            alt_text=match.group(1),
            original_match=match.group(0),
            span=match.span(),
            url=match.group(2),
        )
        for match in CDN_PATTERN.finditer(text)
    ]
    matches.extend(
        MultiMarkdownImageMatch(
            alt_text=match.group(1),
            original_match=match.group(0),
            span=match.span(),
            url=match.group(2),
        )
        for match in MMD_CDN_PATTERN.finditer(text)
    )
    matches.sort(key=lambda m: m.span[0])
    return matches


def has_cdn_images(text: str) -> bool:
    """Report whether the rendered text contains Mathpix CDN image links."""
    return CDN_PATTERN.search(text) is not None or MMD_CDN_PATTERN.search(text) is not None


def parse_cdn_url(url: str) -> CdnUrlInfo:
    """Parse a CDN URL into a local filename stem and optional dimensions."""
    parsed = urlparse(url)
    filename = parsed.path.split("/")[-1]
    if "." in filename:
        base_name, extension = filename.rsplit(".", 1)
    else:
        base_name, extension = filename, "jpg"

    params = parse_qs(parsed.query)
    return CdnUrlInfo(
        base_name=base_name,
        extension=extension,
        height=params.get("height", [None])[0],
        width=params.get("width", [None])[0],
    )
