from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime
from functools import cached_property
from pathlib import Path

import anyio

from mathpix_cli.convert.images import download_cdn_images
from mathpix_cli.convert.model import (
    OUTPUT_FORMAT_EXTENSIONS,
    OutputFormat,
    SavedConvert,
)
from mathpix_cli.shared.errors import ErrorCode
from mathpix_cli.shared.paths import normalize_path
from mathpix_cli.shared.result import Result, error_message
from mathpix_cli.shared.store import (
    cache_key,
    find_cached_path,
    read_history,
    upsert_history_section,
    write_history,
)

_HISTORY_KEY = "converts"


@dataclass(frozen=True)
class FileSystemConvertStore:
    """Filesystem-backed store for convert outputs."""

    output_dir: str

    @cached_property
    def _base(self) -> Path:
        return Path(normalize_path(self.output_dir)).expanduser().resolve()

    def _history_path(self) -> Path:
        return self._base / "history.json"

    def _output_path(self, fmt: OutputFormat, folder: str) -> Path:
        return self._base / "converts" / fmt.value / folder

    async def find_cached(self, sha256: str, fmt: OutputFormat) -> Result[str | None]:
        """Return a cached converted file path when present."""
        key_segment = fmt.value
        folder = sha256[:16]
        ext = OUTPUT_FORMAT_EXTENSIONS[fmt]
        main_file = self._output_path(fmt, folder) / f"main{ext}"
        return await find_cached_path(
            self._history_path(),
            default_key=_HISTORY_KEY,
            section_key=_HISTORY_KEY,
            cache_entry_key=cache_key(sha256, key_segment),
            main_file=main_file,
        )

    async def save(
        self,
        *,
        text: str,
        sha256: str,
        source: str,
        fmt: OutputFormat,
    ) -> Result[SavedConvert]:
        """Persist a converted output and update history."""
        key_segment = fmt.value
        folder = sha256[:16]
        output_path = self._output_path(fmt, folder)
        try:
            await anyio.Path(output_path).mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            return Result.failure(ErrorCode.IO, f"Failed to create output directory: {exc}")

        ext = OUTPUT_FORMAT_EXTENSIONS[fmt]
        transformed = text
        images_downloaded = 0
        warnings: list[str] = []

        localize_result = await download_cdn_images(text, output_path / "images")
        if not localize_result.ok:
            warnings.append(f"Image localization failed: {error_message(localize_result)}")
        else:
            localized = localize_result.unwrap
            transformed = localized.markdown
            images_downloaded = localized.images_downloaded
            warnings.extend(localized.warnings)
            if images_downloaded > 0:
                original_path = output_path / f"original{ext}"
                try:
                    await anyio.Path(original_path).write_text(text, encoding="utf-8")
                except OSError as exc:
                    warnings.append(f"Failed to write original markdown: {exc}")

        main_path = output_path / f"main{ext}"
        try:
            await anyio.Path(main_path).write_text(transformed, encoding="utf-8")
        except OSError as exc:
            return Result.failure(ErrorCode.IO, f"Failed to write output file: {exc}")

        history_result = await read_history(self._history_path(), default_key=_HISTORY_KEY)
        if not history_result.ok:
            return history_result.or_else(
                ErrorCode.IO,
                "Failed to load history for update",
            ).forward()

        history = history_result.unwrap
        converts = upsert_history_section(history, _HISTORY_KEY)

        converts[cache_key(sha256, key_segment)] = {
            "timestamp": datetime.now(tz=UTC).isoformat(),
            "format": fmt.value,
            "images_downloaded": images_downloaded,
            "source": source if source.startswith(("http://", "https://")) else Path(source).name,
        }

        write_result = await write_history(self._history_path(), history)
        if not write_result.ok:
            return write_result.or_else(ErrorCode.IO, "Failed to write history").forward()

        return Result.success(
            SavedConvert(
                format=fmt,
                images_downloaded=images_downloaded,
                path=str(main_path.resolve()),
                warnings=tuple(warnings),
            )
        )
