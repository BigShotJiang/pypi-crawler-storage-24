from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from pydantic import BaseModel

from mathpix_cli.convert.model import OutputFormat
from mathpix_cli.shared.errors import ErrorCode
from mathpix_cli.shared.http import request_and_parse, request_text
from mathpix_cli.shared.result import Result
from mathpix_cli.shared.retry import poll_with_retry, retry_result

if TYPE_CHECKING:
    import httpx

    from mathpix_cli.shared.config import MathpixV1Credentials

CHECK_CONVERSION_STATUS_LABEL = "Failed to check conversion status"
CHECK_STATUS_LABEL = "Failed to check status"
CHECK_STATUS_TIMEOUT_SECONDS = 10.0
CONVERSION_DOWNLOAD_LABEL = "Failed to download conversion output"
DOWNLOAD_TEXT_LABEL = "Failed to download text"
PDF_UPLOAD_LABEL = "Failed to upload PDF file"
PDF_UPLOAD_TIMEOUT_SECONDS = 60.0
REQUEST_TIMEOUT_SECONDS = 30.0
RETRY_DELAY_SECONDS = 2.0
PENDING_STATUS = "pending"
UNKNOWN_STATUS = "unknown"


class MathpixV1ConversionStatusEntry(BaseModel):
    """Single format status entry within a Mathpix v1 conversion response."""

    status: str | None = None


class MathpixV1ConversionPayload(BaseModel):
    """Mathpix v1 conversion resource payload."""

    conversion_status: dict[str, MathpixV1ConversionStatusEntry] | None = None
    id: str | None = None


class MathpixV1ConversionEnvelope(BaseModel):
    """Envelope returned by the Mathpix v1 conversion API."""

    conversion: MathpixV1ConversionPayload


class MathpixV1PdfPayload(BaseModel):
    """Mathpix v1 PDF resource payload."""

    id: str | None = None
    status: str | None = None


class MathpixV1PdfEnvelope(BaseModel):
    """Envelope returned by the Mathpix v1 PDF API."""

    pdf: MathpixV1PdfPayload


@dataclass(frozen=True, slots=True)
class MathpixV1PdfConverter:
    """Mathpix v1 PDF converter."""

    config: MathpixV1Credentials
    client: httpx.AsyncClient

    async def _check_conversion_status(self, conversion_id: str) -> Result[str]:
        envelope_result = await request_and_parse(
            self.client,
            "GET",
            self._conversion_endpoint(conversion_id),
            headers=self._headers(),
            context=CHECK_CONVERSION_STATUS_LABEL,
            model=MathpixV1ConversionEnvelope,
            timeout=CHECK_STATUS_TIMEOUT_SECONDS,
        )
        if not envelope_result.ok:
            return envelope_result.forward()

        conversion_status = envelope_result.unwrap.conversion.conversion_status
        if conversion_status is None:
            return Result.success(PENDING_STATUS)
        md_entry = conversion_status.get("md")
        if md_entry is None or md_entry.status is None:
            return Result.success(PENDING_STATUS)
        return Result.success(md_entry.status)

    async def _check_status(self, pdf_id: str) -> Result[str]:
        envelope_result = await request_and_parse(
            self.client,
            "GET",
            self._pdf_endpoint(pdf_id),
            headers=self._headers(),
            context=CHECK_STATUS_LABEL,
            model=MathpixV1PdfEnvelope,
            timeout=CHECK_STATUS_TIMEOUT_SECONDS,
        )
        if not envelope_result.ok:
            return envelope_result.forward()

        status = envelope_result.unwrap.pdf.status or UNKNOWN_STATUS
        return Result.success(status)

    def _conversion_endpoint(self, conversion_id: str) -> str:
        return f"{self.config.base_url}/conversions/{conversion_id}"

    def _conversion_md_endpoint(self, conversion_id: str) -> str:
        return f"{self._conversion_endpoint(conversion_id)}/md"

    def _conversions_endpoint(self) -> str:
        return f"{self.config.base_url}/conversions"

    async def _convert_via_conversions(
        self,
        pdf_id: str,
        *,
        filename: str,
        max_polling_time: int,
        max_retries: int,
        polling_interval: int,
    ) -> Result[str]:
        create_result = await retry_result(
            action=lambda: self._create_conversion(pdf_id, filename=filename),
            delay_seconds=RETRY_DELAY_SECONDS,
            retries=max_retries,
        )
        if not create_result.ok:
            return create_result.or_else(ErrorCode.NETWORK, "Failed to create conversion")
        conversion_id = create_result.unwrap

        wait_result = await poll_with_retry(
            check=lambda: self._check_conversion_status(conversion_id),
            delay_seconds=RETRY_DELAY_SECONDS,
            failure_label="Conversion",
            max_polling_time=max_polling_time,
            max_retries=max_retries,
            polling_interval=polling_interval,
            timeout_label="Conversion",
        )
        if not wait_result.ok:
            return wait_result.forward()

        download_result = await retry_result(
            action=lambda: self._download_conversion_output(conversion_id),
            delay_seconds=RETRY_DELAY_SECONDS,
            retries=max_retries,
        )
        if not download_result.ok:
            return download_result.or_else(
                ErrorCode.NETWORK,
                "Failed to download conversion output",
            )
        return Result.success(download_result.unwrap)

    async def _create_conversion(self, pdf_uuid: str, *, filename: str) -> Result[str]:
        body = {"pdf_uuid": pdf_uuid, "filename": filename, "formats": {"md": True}}
        envelope_result = await request_and_parse(
            self.client,
            "POST",
            self._conversions_endpoint(),
            headers={**self._headers(), "Content-Type": "application/json"},
            context="Failed to create conversion",
            model=MathpixV1ConversionEnvelope,
            timeout=REQUEST_TIMEOUT_SECONDS,
            json=body,
        )
        if not envelope_result.ok:
            return envelope_result.forward()

        conversion_id = envelope_result.unwrap.conversion.id
        if not conversion_id:
            return Result.failure(
                ErrorCode.NETWORK,
                "Failed to create conversion: no conversion id in response",
            )
        return Result.success(conversion_id)

    async def _download_conversion_output(self, conversion_id: str) -> Result[str]:
        return await request_text(
            self.client,
            "GET",
            self._conversion_md_endpoint(conversion_id),
            headers=self._headers(),
            context=CONVERSION_DOWNLOAD_LABEL,
            timeout=REQUEST_TIMEOUT_SECONDS,
        )

    async def _download_text(self, pdf_id: str, fmt: OutputFormat) -> Result[str]:
        return await request_text(
            self.client,
            "GET",
            self._pdf_output_endpoint(pdf_id, fmt),
            headers=self._headers(),
            context=DOWNLOAD_TEXT_LABEL,
            timeout=REQUEST_TIMEOUT_SECONDS,
        )

    def _headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self.config.token}"}

    def _pdf_endpoint(self, pdf_id: str) -> str:
        return f"{self.config.base_url}/pdfs/{pdf_id}"

    def _pdf_output_endpoint(self, pdf_id: str, fmt: OutputFormat) -> str:
        return f"{self._pdf_endpoint(pdf_id)}/{fmt.value}"

    def _pdfs_endpoint(self) -> str:
        return f"{self.config.base_url}/pdfs"

    async def _upload_pdf(self, content: bytes, *, filename: str) -> Result[str]:
        files = {"file": (filename, content, "application/pdf")}
        envelope_result = await request_and_parse(
            self.client,
            "POST",
            self._pdfs_endpoint(),
            headers=self._headers(),
            context=PDF_UPLOAD_LABEL,
            model=MathpixV1PdfEnvelope,
            timeout=PDF_UPLOAD_TIMEOUT_SECONDS,
            files=files,
        )
        if not envelope_result.ok:
            return envelope_result.forward()

        pdf_id = envelope_result.unwrap.pdf.id
        if not pdf_id:
            return Result.failure(ErrorCode.NETWORK, f"{PDF_UPLOAD_LABEL}: no pdf id in response")
        return Result.success(pdf_id)

    async def convert(
        self,
        content: bytes,
        fmt: OutputFormat,
        *,
        filename: str,
        max_polling_time: int,
        max_retries: int,
        polling_interval: int,
    ) -> Result[str]:
        """Convert one PDF into the requested output format."""
        upload_result = await retry_result(
            action=lambda: self._upload_pdf(content, filename=filename),
            delay_seconds=RETRY_DELAY_SECONDS,
            retries=max_retries,
        )
        if not upload_result.ok:
            return upload_result.or_else(ErrorCode.NETWORK, "Failed to upload PDF")
        pdf_id = upload_result.unwrap

        wait_result = await poll_with_retry(
            check=lambda: self._check_status(pdf_id),
            delay_seconds=RETRY_DELAY_SECONDS,
            failure_label="PDF",
            max_polling_time=max_polling_time,
            max_retries=max_retries,
            polling_interval=polling_interval,
            timeout_label="PDF processing",
        )
        if not wait_result.ok:
            return wait_result.forward()

        if fmt is OutputFormat.MD:
            return await self._convert_via_conversions(
                pdf_id,
                filename=filename,
                max_polling_time=max_polling_time,
                max_retries=max_retries,
                polling_interval=polling_interval,
            )

        download_result = await retry_result(
            action=lambda: self._download_text(pdf_id, fmt),
            delay_seconds=RETRY_DELAY_SECONDS,
            retries=max_retries,
        )
        if not download_result.ok:
            return download_result.or_else(ErrorCode.NETWORK, "Failed to download text")
        return Result.success(download_result.unwrap)
