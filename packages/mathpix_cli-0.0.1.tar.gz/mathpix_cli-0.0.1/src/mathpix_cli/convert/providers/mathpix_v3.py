from __future__ import annotations

import json
from dataclasses import dataclass
from typing import TYPE_CHECKING

from pydantic import BaseModel, Field

from mathpix_cli.convert.model import OutputFormat
from mathpix_cli.shared.errors import ErrorCode
from mathpix_cli.shared.http import request_and_parse, request_text
from mathpix_cli.shared.result import Result
from mathpix_cli.shared.retry import poll_with_retry, retry_result

if TYPE_CHECKING:
    import httpx

    from mathpix_cli.shared.config import MathpixV3Credentials

CHECK_STATUS_LABEL = "Failed to check status"
CHECK_STATUS_TIMEOUT_SECONDS = 10.0
DOWNLOAD_LABEL = "Failed to download text"
DOWNLOAD_TIMEOUT_SECONDS = 30.0
PDF_UPLOAD_LABEL = "Failed to upload PDF file"
PDF_UPLOAD_TIMEOUT_SECONDS = 60.0
RETRY_DELAY_SECONDS = 2.0


class MathpixStatusPayload(BaseModel):
    """Mathpix PDF status payload."""

    status: str | dict[str, str]

    def status_for(self, fmt: OutputFormat) -> str:
        """Return the status string for the requested output format."""
        if isinstance(self.status, dict):
            format_status = self.status.get(fmt.value)
            if isinstance(format_status, str):
                return format_status
        return str(self.status)


class MathpixUploadPayload(BaseModel):
    """Mathpix PDF upload response payload."""

    pdf_id: str = Field(min_length=1)


@dataclass(frozen=True, slots=True)
class MathpixV3PdfConverter:
    """Mathpix v3 PDF converter."""

    config: MathpixV3Credentials
    client: httpx.AsyncClient

    async def _check_status(self, job_id: str, fmt: OutputFormat) -> Result[str]:
        payload_result = await request_and_parse(
            self.client,
            "GET",
            self._job_endpoint(job_id),
            headers=self._headers(),
            context=CHECK_STATUS_LABEL,
            model=MathpixStatusPayload,
            timeout=CHECK_STATUS_TIMEOUT_SECONDS,
        )
        if not payload_result.ok:
            return payload_result.forward()

        return Result.success(payload_result.unwrap.status_for(fmt))

    async def _download_text(self, job_id: str, fmt: OutputFormat) -> Result[str]:
        return await request_text(
            self.client,
            "GET",
            self._job_output_endpoint(job_id, fmt),
            headers=self._headers(),
            context=DOWNLOAD_LABEL,
            timeout=DOWNLOAD_TIMEOUT_SECONDS,
        )

    def _headers(self) -> dict[str, str]:
        return {"app_id": self.config.app_id, "app_key": self.config.app_key}

    def _job_endpoint(self, job_id: str) -> str:
        return f"{self.config.base_url}/pdf/{job_id}"

    def _job_output_endpoint(self, job_id: str, fmt: OutputFormat) -> str:
        return f"{self._job_endpoint(job_id)}.{fmt.value}"

    async def _upload_pdf(self, content: bytes, fmt: OutputFormat, *, filename: str) -> Result[str]:
        files = {"file": (filename, content, "application/pdf")}
        data: dict[str, str] = {}
        if fmt is OutputFormat.MD:
            data["options_json"] = json.dumps({"conversion_formats": {fmt.value: True}})
        payload_result = await request_and_parse(
            self.client,
            "POST",
            f"{self.config.base_url}/pdf",
            headers=self._headers(),
            context=PDF_UPLOAD_LABEL,
            model=MathpixUploadPayload,
            timeout=PDF_UPLOAD_TIMEOUT_SECONDS,
            files=files,
            data=data,
        )
        if not payload_result.ok:
            return payload_result.forward()

        return Result.success(payload_result.unwrap.pdf_id)

    async def convert(
        self,
        content: bytes,
        fmt: OutputFormat,
        *,
        filename: str,
        max_polling_time: int,
        max_retries: int,
        polling_interval: int,
    ) -> Result[str]:
        """Convert one PDF into the requested output format."""
        upload_result = await retry_result(
            action=lambda: self._upload_pdf(content, fmt, filename=filename),
            delay_seconds=RETRY_DELAY_SECONDS,
            retries=max_retries,
        )
        if not upload_result.ok:
            return upload_result.or_else(ErrorCode.NETWORK, "Failed to upload PDF")
        job_id = upload_result.unwrap

        wait_result = await poll_with_retry(
            check=lambda: self._check_status(job_id, fmt),
            delay_seconds=RETRY_DELAY_SECONDS,
            failure_label="Conversion",
            max_polling_time=max_polling_time,
            max_retries=max_retries,
            polling_interval=polling_interval,
            timeout_label="Conversion",
        )
        if not wait_result.ok:
            return wait_result.forward()

        download_result = await retry_result(
            action=lambda: self._download_text(job_id, fmt),
            delay_seconds=RETRY_DELAY_SECONDS,
            retries=max_retries,
        )
        if not download_result.ok:
            return download_result.or_else(ErrorCode.NETWORK, "Failed to download text")

        return Result.success(download_result.unwrap)
