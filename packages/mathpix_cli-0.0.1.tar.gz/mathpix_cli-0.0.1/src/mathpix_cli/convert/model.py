"""Models for PDF conversion."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from mathpix_cli.shared.resolver import ResolvedBackend


class OutputFormat(StrEnum):
    """Supported convert formats."""

    MD = "md"
    MMD = "mmd"


OUTPUT_FORMAT_EXTENSIONS: dict[OutputFormat, str] = {
    OutputFormat.MD: ".md",
    OutputFormat.MMD: ".mmd",
}


@dataclass(frozen=True, slots=True)
class ConvertRequest:
    """Convert request."""

    is_url: bool
    source: str


@dataclass(frozen=True, slots=True)
class ConvertOutcome:
    """Convert result."""

    cache_hit: bool
    format: OutputFormat
    images_downloaded: int
    path: str
    warnings: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class ConvertPlan:
    """Convert plan."""

    format: OutputFormat
    summary_label: str
    backend: ResolvedBackend


@dataclass(frozen=True, slots=True)
class SavedConvert:
    """Saved convert output."""

    format: OutputFormat
    images_downloaded: int
    path: str
    warnings: tuple[str, ...] = ()
