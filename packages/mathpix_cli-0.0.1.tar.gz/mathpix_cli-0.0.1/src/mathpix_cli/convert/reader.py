"""Input readers for PDF conversion."""

from __future__ import annotations

import unicodedata
from pathlib import Path

import anyio
import httpx
from pydantic import ConfigDict
from pydantic.dataclasses import dataclass

from mathpix_cli.shared.errors import ErrorCode
from mathpix_cli.shared.result import Result


@dataclass(frozen=True, slots=True)
class FileSystemPdfReader:
    """Read PDF files from the local filesystem."""

    @staticmethod
    def _candidate_paths(path: Path) -> tuple[Path, Path]:
        nfc_path = Path(unicodedata.normalize("NFC", str(path)))
        nfd_path = Path(unicodedata.normalize("NFD", str(path)))
        return (nfc_path, nfd_path)

    @staticmethod
    async def _read_if_exists(path: Path) -> tuple[bytes | None, str | None]:
        try:
            return (await anyio.Path(path).read_bytes(), None)
        except FileNotFoundError:
            return (None, None)
        except OSError as error:
            return (None, str(error))

    async def read(self, absolute_path: Path) -> Result[bytes]:
        """Read one PDF from the local filesystem."""
        last_error: str | None = None
        try:
            for candidate_path in self._candidate_paths(absolute_path):
                content, error = await self._read_if_exists(candidate_path)
                if error is not None:
                    last_error = error
                if content is not None:
                    return Result.success(content)
        except OSError as error:
            return Result.failure(ErrorCode.IO, f"Failed to read PDF: {error}")

        if last_error is not None:
            return Result.failure(ErrorCode.IO, last_error)
        return Result.failure(ErrorCode.IO, f"PDF file not found: {absolute_path}")


@dataclass(frozen=True, slots=True)
class HttpPdfReader:
    """Download PDF files over HTTP(S)."""

    __pydantic_config__ = ConfigDict(arbitrary_types_allowed=True)

    client: httpx.AsyncClient
    timeout_seconds: float = 60.0

    async def read(self, url: str) -> Result[bytes]:
        """Download one remote PDF."""
        try:
            response = await self.client.request(
                "GET",
                url,
                follow_redirects=True,
                timeout=self.timeout_seconds,
            )
            response.raise_for_status()
        except httpx.HTTPError as error:
            return Result.failure(ErrorCode.NETWORK, f"Failed to download PDF: {error}")
        return Result.success(response.content)
