from __future__ import annotations

import hashlib
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Protocol

from mathpix_cli.convert.model import (
    ConvertOutcome,
    ConvertRequest,
    OutputFormat,
    SavedConvert,
)
from mathpix_cli.shared.errors import ErrorCode
from mathpix_cli.shared.result import Result
from mathpix_cli.shared.retry import retry_result, validate_polling, validate_retries

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from mathpix_cli.shared.config import AppConfig

LOCAL_READ_RETRY_DELAY_SECONDS = 0.0
REMOTE_READ_RETRY_DELAY_SECONDS = 2.0


class PdfConverter(Protocol):
    """Convert PDF bytes into text output."""

    async def convert(
        self,
        content: bytes,
        fmt: OutputFormat,
        *,
        filename: str,
        max_polling_time: int,
        max_retries: int,
        polling_interval: int,
    ) -> Result[str]:
        """Convert PDF bytes into text output."""


class LocalPdfReader(Protocol):
    """Read a local PDF file."""

    async def read(self, absolute_path: Path) -> Result[bytes]:
        """Read one PDF from the local filesystem."""


class RemotePdfReader(Protocol):
    """Read a remote PDF file."""

    async def read(self, url: str) -> Result[bytes]:
        """Download one remote PDF."""


class ConvertStore(Protocol):
    """Store converted outputs."""

    async def find_cached(self, sha256: str, fmt: OutputFormat) -> Result[str | None]:
        """Return a cached file path if one exists."""

    async def save(
        self,
        *,
        text: str,
        sha256: str,
        source: str,
        fmt: OutputFormat,
    ) -> Result[SavedConvert]:
        """Save one converted output."""


@dataclass(frozen=True, slots=True)
class ConvertUseCase:
    """Run one PDF conversion with caching."""

    converter: PdfConverter
    local_reader: LocalPdfReader
    remote_reader: RemotePdfReader
    store: ConvertStore

    async def execute(self, request: ConvertRequest, config: AppConfig) -> Result[ConvertOutcome]:
        """Execute the conversion flow for one PDF source."""
        validate_result = self._validate_config(config)
        if not validate_result.ok:
            return validate_result.forward()

        output_format = config.convert.format
        read_result = await self._read_pdf(request, retries=config.convert.max_retries)
        if not read_result.ok:
            return read_result.or_else(ErrorCode.IO, "Failed to read PDF").forward()
        content = read_result.unwrap

        sha256 = hashlib.sha256(content).hexdigest()
        cache_result = await self.store.find_cached(sha256, output_format)
        if not cache_result.ok:
            return cache_result.or_else(ErrorCode.IO, "Failed to load cache").forward()

        cached = cache_result.value
        if cached is not None:
            return Result.success(
                ConvertOutcome(
                    cache_hit=True,
                    format=output_format,
                    images_downloaded=0,
                    path=cached,
                    warnings=(),
                )
            )

        return await self._convert_uncached(
            content=content,
            output_format=output_format,
            sha256=sha256,
            source=request.source,
            config=config,
        )

    async def _convert_uncached(
        self,
        *,
        content: bytes,
        output_format: OutputFormat,
        sha256: str,
        source: str,
        config: AppConfig,
    ) -> Result[ConvertOutcome]:
        convert_result = await self.converter.convert(
            content,
            output_format,
            filename=f"{sha256[:16]}.pdf",
            max_polling_time=config.convert.max_polling_time,
            max_retries=config.convert.max_retries,
            polling_interval=config.convert.polling_interval,
        )
        if not convert_result.ok:
            return convert_result.or_else(ErrorCode.NETWORK, "Failed to convert PDF").forward()

        save_result = await self.store.save(
            text=convert_result.unwrap,
            fmt=output_format,
            sha256=sha256,
            source=source,
        )
        if not save_result.ok:
            return save_result.or_else(ErrorCode.IO, "Failed to save output").forward()

        saved = save_result.unwrap
        return Result.success(
            ConvertOutcome(
                cache_hit=False,
                format=saved.format,
                images_downloaded=saved.images_downloaded,
                path=saved.path,
                warnings=saved.warnings,
            )
        )

    async def _read_pdf(self, request: ConvertRequest, retries: int) -> Result[bytes]:
        action: Callable[[], Awaitable[Result[bytes]]]
        delay_seconds = LOCAL_READ_RETRY_DELAY_SECONDS
        if request.is_url:

            async def read_remote() -> Result[bytes]:
                return await self.remote_reader.read(request.source)

            action = read_remote
            delay_seconds = REMOTE_READ_RETRY_DELAY_SECONDS
        else:

            async def read_local() -> Result[bytes]:
                return await self.local_reader.read(Path(request.source))

            action = read_local

        return await retry_result(
            action=action,
            delay_seconds=delay_seconds,
            retries=retries,
        )

    @staticmethod
    def _validate_config(config: AppConfig) -> Result[None]:
        polling = validate_polling(
            max_polling_time=config.convert.max_polling_time,
            polling_interval=config.convert.polling_interval,
        )
        if not polling.ok:
            return polling.forward()

        retries = validate_retries(config.convert.max_retries)
        if not retries.ok:
            return retries.forward()
        return Result.success(None)
