"""Shared runtime helpers for CLI commands."""

from __future__ import annotations

import typer

from mathpix_cli.shared.config import AppConfig, load_config
from mathpix_cli.shared.reporter import ConsoleReporter
from mathpix_cli.shared.result import Result, error_message


def make_reporter() -> ConsoleReporter:
    """Create the CLI reporter."""
    return ConsoleReporter()


def load_config_or_exit(reporter: ConsoleReporter) -> AppConfig:
    """Load config or exit.

    Raises:
        typer.Exit: Config loading failed.
    """
    result: Result[AppConfig] = load_config()
    if result.ok and result.value is not None:
        return result.unwrap
    reporter.error(error_message(result, default="Failed to load config"))
    raise typer.Exit(code=1)
