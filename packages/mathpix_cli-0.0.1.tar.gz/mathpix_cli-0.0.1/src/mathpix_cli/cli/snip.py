"""CLI commands for image snips."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Annotated

import anyio
import httpx
import typer

from mathpix_cli.cli.runtime import load_config_or_exit, make_reporter
from mathpix_cli.shared.paths import resolve_source_path
from mathpix_cli.shared.resolver import ResolvedBackend
from mathpix_cli.shared.result import Result, error_message
from mathpix_cli.snip.model import SavedSnip, SnipFormat, SnipPlan, SnipRequest
from mathpix_cli.snip.resolver import build_plan, build_use_case

if TYPE_CHECKING:
    from mathpix_cli.shared.config import AppConfig
    from mathpix_cli.shared.reporter import ConsoleReporter

app = typer.Typer(add_completion=False, help="Snip images.")

ENDPOINT_DETAILS = {
    ResolvedBackend.MATHPIX_V1: "POST /v1/snips-multipart",
    ResolvedBackend.MATHPIX_V3: "POST /v3/text",
}


def run_image(
    reporter: ConsoleReporter,
    image_path: str,
    config: AppConfig,
    *,
    fmt: SnipFormat | None,
    verbose: bool,
) -> None:
    """Snip one image.

    Raises:
        typer.Exit: The path is invalid.
    """
    path_result = resolve_source_path(image_path)
    if not path_result.ok:
        reporter.error(error_message(path_result, default="Invalid path"))
        raise typer.Exit(code=1)

    effective_fmt = fmt if fmt is not None else config.snip.format
    request = SnipRequest(
        format=effective_fmt,
        image_path=str(path_result.value),
        options=config.snip.options,
    )

    plan = build_plan(config, fmt=effective_fmt)
    reporter.summary(f"{plan.summary_label} | {image_path}")

    if verbose:
        _print_plan(reporter, config, plan)

    run_result = anyio.run(_run, request, config)
    if not run_result.ok:
        reporter.error(error_message(run_result, default="Image snip failed"))
        raise typer.Exit(code=1)

    _print_outcome(
        reporter,
        run_result.unwrap,
        show_result=config.snip.show_result,
        verbose=verbose,
    )


def _print_outcome(
    reporter: ConsoleReporter,
    saved: SavedSnip,
    *,
    show_result: bool,
    verbose: bool,
) -> None:
    if show_result:
        if saved.cache_hit:
            _print_result_from_file(reporter, saved.path)
        elif saved.outcome is not None:
            reporter.content(saved.outcome.text)
    path = saved.path
    if saved.cache_hit:
        reporter.status("Cached", path)
    elif saved.outcome is not None:
        reporter.status("Saved", path, detail=f"confidence: {saved.outcome.confidence}")
    else:
        reporter.status("Saved", path)
    if verbose and saved.outcome is not None and saved.outcome.snip_id:
        reporter.detail(f"snip_id: {saved.outcome.snip_id}")


async def _run(request: SnipRequest, config: AppConfig) -> Result[SavedSnip]:
    async with httpx.AsyncClient() as client:
        use_case_result = build_use_case(config, client)
        if not use_case_result.ok:
            return use_case_result.forward()
        return await use_case_result.unwrap.execute(request)


def _print_plan(reporter: ConsoleReporter, config: AppConfig, plan: SnipPlan) -> None:
    base_url = _backend_base_url(config, plan.backend)
    reporter.detail(f"backend: {plan.backend} ({base_url})")
    reporter.detail(f"endpoint: {ENDPOINT_DETAILS[plan.backend]}")


def _backend_base_url(config: AppConfig, backend: ResolvedBackend) -> str:
    if backend is ResolvedBackend.MATHPIX_V1:
        return config.v1.snip_api_base if config.v1 else "n/a"
    return config.v3.base_url if config.v3 else "n/a"


def _print_result_from_file(reporter: ConsoleReporter, path: str) -> None:
    try:
        text = Path(path).read_text(encoding="utf-8").rstrip("\n")
        if text:
            reporter.content(text)
    except OSError as exc:
        reporter.warn(f"Failed to read cached result from {path}: {exc}")


@app.command("image")
def image_cmd(
    image_path: Annotated[str, typer.Argument(help="Path to an image.")],
    fmt: Annotated[
        SnipFormat | None,
        typer.Option("--format", "-f", help="Output format."),
    ] = None,
    verbose: Annotated[
        bool | None,
        typer.Option("--verbose", "-v", help="Show backend details."),
    ] = None,
) -> None:
    """Snip an image."""
    reporter = make_reporter()
    config = load_config_or_exit(reporter)
    run_image(reporter, image_path, config, fmt=fmt, verbose=verbose is True)
