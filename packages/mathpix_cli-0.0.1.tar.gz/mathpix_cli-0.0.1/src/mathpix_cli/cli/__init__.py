"""CLI entrypoints for mathpix-cli."""

from .app import app, main

__all__ = ["app", "main"]
