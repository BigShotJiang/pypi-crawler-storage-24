"""CLI commands for PDF conversion."""

from __future__ import annotations

from typing import TYPE_CHECKING, Annotated

import anyio
import httpx
import typer

from mathpix_cli.cli.runtime import load_config_or_exit, make_reporter
from mathpix_cli.convert.model import (
    ConvertOutcome,
    ConvertPlan,
    ConvertRequest,
    OutputFormat,
)
from mathpix_cli.convert.resolver import build_plan, build_use_case
from mathpix_cli.shared.paths import resolve_source_path
from mathpix_cli.shared.resolver import ResolvedBackend
from mathpix_cli.shared.result import Result, error_message

if TYPE_CHECKING:
    from mathpix_cli.shared.config import AppConfig
    from mathpix_cli.shared.reporter import ConsoleReporter

app = typer.Typer(add_completion=False, help="Convert PDFs.")

ENDPOINT_DETAILS = {
    ResolvedBackend.MATHPIX_V1: {
        OutputFormat.MD: "POST /v1/pdfs -> GET /v1/conversions/{id}/md",
        OutputFormat.MMD: "POST /v1/pdfs -> GET /v1/pdfs/{id}/mmd",
    },
    ResolvedBackend.MATHPIX_V3: {
        OutputFormat.MD: "POST /v3/pdf -> GET /v3/pdf/{id}.md",
        OutputFormat.MMD: "POST /v3/pdf -> GET /v3/pdf/{id}.mmd",
    },
}


def run_path(
    reporter: ConsoleReporter,
    file_path: str,
    config: AppConfig,
    *,
    verbose: bool,
) -> None:
    """Convert one local PDF.

    Raises:
        typer.Exit: The path is invalid.
    """
    path_result = resolve_source_path(file_path)
    if not path_result.ok:
        reporter.error(error_message(path_result, default="Invalid path"))
        raise typer.Exit(code=1)

    _execute(
        reporter=reporter,
        source_label=file_path,
        request=ConvertRequest(is_url=False, source=str(path_result.value)),
        config=config,
        verbose=verbose,
    )


def run_url(
    reporter: ConsoleReporter,
    pdf_url: str,
    config: AppConfig,
    *,
    verbose: bool,
) -> None:
    """Convert one remote PDF.

    Raises:
        typer.Exit: The URL is invalid.
    """
    if not pdf_url.startswith(("http://", "https://")):
        reporter.error(f"Invalid URL: {pdf_url}")
        raise typer.Exit(code=1)

    _execute(
        reporter=reporter,
        source_label=pdf_url,
        request=ConvertRequest(is_url=True, source=pdf_url),
        config=config,
        verbose=verbose,
    )


def _execute(
    reporter: ConsoleReporter,
    source_label: str,
    request: ConvertRequest,
    config: AppConfig,
    *,
    verbose: bool,
) -> None:
    plan = build_plan(config)
    reporter.summary(f"{plan.summary_label} | {source_label}")

    if verbose:
        _print_plan(reporter, config, plan)

    run_result = anyio.run(_run, request, config)
    if not run_result.ok:
        reporter.error(error_message(run_result, default="PDF conversion failed"))
        raise typer.Exit(code=1)

    _print_outcome(reporter, run_result.unwrap)


def _print_outcome(reporter: ConsoleReporter, outcome: ConvertOutcome) -> None:
    for warning in outcome.warnings:
        reporter.warn(warning)
    path = outcome.path
    if outcome.cache_hit:
        reporter.status("Cached", path)
    elif outcome.images_downloaded > 0:
        reporter.status("Saved", path, detail=f"{outcome.images_downloaded} images")
    else:
        reporter.status("Saved", path)


def _print_plan(reporter: ConsoleReporter, config: AppConfig, plan: ConvertPlan) -> None:
    base_url = _backend_base_url(config, plan.backend)
    reporter.detail(f"backend: {plan.backend} ({base_url})")
    reporter.detail(f"endpoint: {ENDPOINT_DETAILS[plan.backend][plan.format]}")


def _backend_base_url(config: AppConfig, backend: ResolvedBackend) -> str:
    if backend is ResolvedBackend.MATHPIX_V1:
        return config.v1.base_url if config.v1 else "n/a"
    return config.v3.base_url if config.v3 else "n/a"


async def _run(request: ConvertRequest, config: AppConfig) -> Result[ConvertOutcome]:
    async with httpx.AsyncClient() as client:
        use_case_result = build_use_case(config, client)
        if not use_case_result.ok:
            return use_case_result.forward()
        return await use_case_result.unwrap.execute(request, config)


@app.command("path")
def path_cmd(
    file_path: Annotated[str, typer.Argument(help="Path to a local PDF.")],
    verbose: Annotated[
        bool | None,
        typer.Option("--verbose", "-v", help="Show backend details."),
    ] = None,
) -> None:
    """Convert a local PDF."""
    reporter = make_reporter()
    config = load_config_or_exit(reporter)
    run_path(reporter, file_path, config, verbose=verbose is True)


@app.command("url")
def url_cmd(
    pdf_url: Annotated[str, typer.Argument(help="URL of a PDF.")],
    verbose: Annotated[
        bool | None,
        typer.Option("--verbose", "-v", help="Show backend details."),
    ] = None,
) -> None:
    """Convert a PDF from a URL."""
    reporter = make_reporter()
    config = load_config_or_exit(reporter)
    run_url(reporter, pdf_url, config, verbose=verbose is True)
