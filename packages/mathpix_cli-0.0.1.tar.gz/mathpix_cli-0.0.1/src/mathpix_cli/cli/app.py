"""Typer application for mathpix-cli."""

from __future__ import annotations

from typing import Annotated

import typer

from mathpix_cli import __version__
from mathpix_cli.cli.convert import app as convert_pdf_app
from mathpix_cli.cli.snip import app as snip_app

app = typer.Typer(add_completion=False, help="Mathpix CLI.")
convert_app = typer.Typer(add_completion=False, help="Convert PDFs.")
convert_app.add_typer(convert_pdf_app, name="pdf")
app.add_typer(convert_app, name="convert")
app.add_typer(snip_app, name="snip")


def _version_callback(value: object) -> None:
    if value is not True:
        return
    typer.echo(f"mathpix-cli {__version__}")
    raise typer.Exit


@app.callback()
def callback(
    version: Annotated[
        bool | None,
        typer.Option(
            "--version",
            callback=_version_callback,
            help="Show the version and exit.",
            is_eager=True,
        ),
    ] = None,
) -> None:
    """Run mathpix-cli."""
    _ = version


def main() -> None:
    """Run the CLI application."""
    app()
