export default {
  extends: ["@commitlint/config-conventional"],
  rules: {
    "body-leading-blank": [2, "always"],
    "footer-leading-blank": [2, "always"],
    "scope-case": [2, "always", "kebab-case"],
    "header-max-length": [2, "always", 72],
    "header-min-length": [2, "always", 20],
  },
  ignores: [(message) => message.trim() === "first commit"],
};
