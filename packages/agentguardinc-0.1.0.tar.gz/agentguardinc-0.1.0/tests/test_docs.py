"""Tests for documentation generator."""

from agentguard.docs.generator import generate_annex_iv


class TestAnnexIVGenerator:
    def test_basic_generation(self):
        doc = generate_annex_iv(system_name="TestBot")
        assert "TestBot" in doc
        assert "Annex IV" in doc
        assert "Risk Level" in doc

    def test_with_risk_level(self):
        doc = generate_annex_iv(risk_level="high")
        assert "high" in doc

    def test_with_audit_events(self):
        events = [
            {"timestamp": "2024-01-01T00:00:00", "function_name": "run", "risk_level": "low"},
            {"timestamp": "2024-01-02T00:00:00", "function_name": "check", "risk_level": "high"},
        ]
        doc = generate_annex_iv(audit_events=events, event_count=2)
        assert "run" in doc
        assert "check" in doc

    def test_with_guardrails(self):
        doc = generate_annex_iv(guardrails=["pii", "scope"])
        assert "pii" in doc
        assert "scope" in doc

    def test_with_compliance_result(self):
        cr = {
            "findings": ["Matches Annex III: employment"],
            "recommendations": ["Add human oversight"],
        }
        doc = generate_annex_iv(compliance_result=cr)
        assert "employment" in doc
        assert "human oversight" in doc

    def test_version_in_footer(self):
        doc = generate_annex_iv()
        assert "0.1.0" in doc

    def test_no_audit_events(self):
        doc = generate_annex_iv()
        assert "No audit events recorded" in doc

    def test_with_frameworks(self):
        doc = generate_annex_iv(frameworks=["LangChain", "CrewAI"])
        assert "LangChain" in doc
        assert "CrewAI" in doc
