"""Shared fixtures for AgentGuard tests."""

from __future__ import annotations

import pytest

from agentguard.context import _current_context
from agentguard.event import DecisionEvent


@pytest.fixture(autouse=True)
def reset_context():
    """Ensure context is clean before and after each test."""
    token = _current_context.set(None)
    yield
    _current_context.reset(token)


@pytest.fixture
def sample_event() -> DecisionEvent:
    """Create a sample DecisionEvent for testing."""
    return DecisionEvent(
        agent_name="test-agent",
        function_name="do_task",
        module="tests",
        input_data={"task": "test"},
        risk_level="low",
    )


@pytest.fixture
def tmp_audit_dir(tmp_path):
    """Provide a temporary directory for audit files."""
    return tmp_path
