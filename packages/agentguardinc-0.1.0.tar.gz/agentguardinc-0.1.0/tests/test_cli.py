"""Tests for CLI commands."""

import json

from agentguard.cli import main


class TestCLI:
    def test_version(self, capsys):
        ret = main(["--version"])
        assert ret == 0
        captured = capsys.readouterr()
        assert "agentguard" in captured.out
        assert "0.1.0" in captured.out

    def test_no_command(self, capsys):
        ret = main([])
        assert ret == 0

    def test_classify(self, tmp_path, capsys):
        f = tmp_path / "test_agent.py"
        f.write_text("from langchain import LLMChain\ndef agent(): pass\n")
        ret = main(["classify", str(f)])
        assert ret == 0
        out = capsys.readouterr().out
        assert "Risk Level" in out

    def test_classify_json(self, tmp_path, capsys):
        f = tmp_path / "test_agent.py"
        f.write_text("def hello(): pass\n")
        ret = main(["classify", str(f), "--json"])
        assert ret == 0
        data = json.loads(capsys.readouterr().out)
        assert "risk_level" in data

    def test_check(self, tmp_path, capsys):
        f = tmp_path / "test_agent.py"
        f.write_text("from langchain import LLMChain\ndef hiring_agent(): pass\n")
        ret = main(["check", str(f)])
        assert ret == 0
        out = capsys.readouterr().out
        assert "Regulation" in out

    def test_trail_empty(self, tmp_path, capsys):
        ret = main(["trail", "--backend", "jsonfile", "--path", str(tmp_path / "missing.jsonl")])
        assert ret == 0
        assert "No audit events" in capsys.readouterr().out

    def test_trail_with_events(self, tmp_path, capsys):
        path = tmp_path / "audit.jsonl"
        path.write_text(
            json.dumps({
                "event_id": "e1",
                "timestamp": "2024-01-01T00:00:00",
                "agent_name": "bot",
                "function_name": "run",
                "duration_ms": 1.5,
                "risk_level": "low",
                "error": "",
            }) + "\n"
        )
        ret = main(["trail", "--backend", "jsonfile", "--path", str(path)])
        assert ret == 0
        out = capsys.readouterr().out
        assert "bot" in out
        assert "Total: 1" in out

    def test_docs(self, capsys):
        ret = main(["docs", "--name", "TestSystem"])
        assert ret == 0
        out = capsys.readouterr().out
        assert "TestSystem" in out
        assert "Annex IV" in out

    def test_docs_to_file(self, tmp_path, capsys):
        output = tmp_path / "doc.md"
        ret = main(["docs", "--name", "TestSystem", "--output", str(output)])
        assert ret == 0
        assert output.exists()
        content = output.read_text()
        assert "TestSystem" in content
