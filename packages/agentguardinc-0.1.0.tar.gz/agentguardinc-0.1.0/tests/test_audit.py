"""Tests for audit backends and trail."""

import json
import time

from agentguard.audit.backends import StdoutBackend, JSONFileBackend, SQLiteBackend, create_backend
from agentguard.audit.trail import AuditTrail
from agentguard.event import DecisionEvent


class TestStdoutBackend:
    def test_write(self, capsys):
        backend = StdoutBackend()
        backend.write({"event_id": "123", "agent_name": "test"})
        captured = capsys.readouterr()
        assert "123" in captured.err

    def test_query_returns_empty(self):
        backend = StdoutBackend()
        assert backend.query() == []


class TestJSONFileBackend:
    def test_write_and_query(self, tmp_path):
        path = tmp_path / "audit.jsonl"
        backend = JSONFileBackend(path=path)
        backend.write({"event_id": "e1", "agent_name": "bot"})
        backend.write({"event_id": "e2", "agent_name": "bot"})

        results = backend.query()
        assert len(results) == 2
        assert results[0]["event_id"] == "e1"

    def test_query_with_filter(self, tmp_path):
        path = tmp_path / "audit.jsonl"
        backend = JSONFileBackend(path=path)
        backend.write({"event_id": "e1", "agent_name": "bot1"})
        backend.write({"event_id": "e2", "agent_name": "bot2"})

        results = backend.query(agent_name="bot1")
        assert len(results) == 1
        assert results[0]["agent_name"] == "bot1"

    def test_query_nonexistent_file(self, tmp_path):
        backend = JSONFileBackend(path=tmp_path / "missing.jsonl")
        assert backend.query() == []


class TestSQLiteBackend:
    def test_write_and_query(self, tmp_path):
        path = tmp_path / "audit.db"
        backend = SQLiteBackend(path=path)
        backend.write({"event_id": "e1", "agent_name": "bot", "timestamp": "2024-01-01"})
        backend.write({"event_id": "e2", "agent_name": "bot", "timestamp": "2024-01-02"})

        results = backend.query()
        assert len(results) == 2

    def test_query_with_filter(self, tmp_path):
        path = tmp_path / "audit.db"
        backend = SQLiteBackend(path=path)
        backend.write({"event_id": "e1", "agent_name": "bot1", "timestamp": "t1"})
        backend.write({"event_id": "e2", "agent_name": "bot2", "timestamp": "t2"})

        results = backend.query(agent_name="bot1")
        assert len(results) == 1

    def test_idempotent_insert(self, tmp_path):
        path = tmp_path / "audit.db"
        backend = SQLiteBackend(path=path)
        backend.write({"event_id": "e1", "agent_name": "bot", "timestamp": "t1"})
        backend.write({"event_id": "e1", "agent_name": "updated", "timestamp": "t1"})
        results = backend.query()
        assert len(results) == 1


class TestCreateBackend:
    def test_stdout(self):
        b = create_backend("stdout")
        assert isinstance(b, StdoutBackend)

    def test_jsonfile(self):
        b = create_backend("jsonfile", "/tmp/test.jsonl")
        assert isinstance(b, JSONFileBackend)

    def test_sqlite(self):
        b = create_backend("sqlite", "/tmp/test.db")
        assert isinstance(b, SQLiteBackend)

    def test_unknown_raises(self):
        import pytest
        with pytest.raises(ValueError):
            create_backend("redis")


class TestAuditTrail:
    def test_emit_and_flush(self, tmp_path):
        path = tmp_path / "trail.jsonl"
        backend = JSONFileBackend(path=path)
        trail = AuditTrail(backend)

        event = DecisionEvent(agent_name="test")
        trail.emit(event)
        trail.flush(timeout=2.0)

        # Give a moment for file write
        time.sleep(0.1)
        results = backend.query()
        assert len(results) >= 1
        assert results[0]["agent_name"] == "test"

    def test_never_blocks(self, tmp_path):
        """Emitting should be non-blocking even with errors."""
        path = tmp_path / "trail.jsonl"
        backend = JSONFileBackend(path=path)
        trail = AuditTrail(backend)

        # Emit many events quickly
        for i in range(100):
            trail.emit(DecisionEvent(agent_name=f"agent-{i}"))
        trail.flush(timeout=3.0)
