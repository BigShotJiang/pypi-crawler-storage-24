"""End-to-end tests — full pipeline smoke tests."""

import json
import time

import pytest

from agentguard import monitor, ctx, GuardConfig, GuardrailViolation
from agentguard.audit.backends import JSONFileBackend
from agentguard.classify import RiskClassifier
from agentguard.docs.generator import generate_annex_iv
from agentguard.regulations.eu_ai_act import EUAIActRegulation


class TestFullPipeline:
    def test_monitor_to_audit(self, tmp_path):
        """Config → monitor → guardrails → audit → query."""
        audit_path = tmp_path / "audit.jsonl"

        @monitor(
            audit="jsonfile",
            audit_path=str(audit_path),
            guardrails=["pii"],
            pii_action="warn",
        )
        def my_agent(task):
            ctx.log_tool("search", query=task)
            ctx.log_reasoning("Using search to find answer")
            ctx.log_model("gpt-4", tokens=100)
            return f"Done: {task}"

        result = my_agent("find something")
        assert result == "Done: find something"

        # Wait for audit to flush
        time.sleep(0.3)

        backend = JSONFileBackend(path=audit_path)
        events = backend.query()
        assert len(events) >= 1
        event = events[0]
        assert event["agent_name"].endswith("my_agent")
        assert event["function_name"] == "my_agent"
        assert len(event["tools_used"]) == 1
        assert event["tools_used"][0]["name"] == "search"

    def test_guardrail_blocks_pii(self):
        """PII guardrail blocks execution when action=block."""

        @monitor(
            audit="stdout",
            guardrails=["pii"],
            pii_action="block",
        )
        def my_agent(data):
            return data

        with pytest.raises(GuardrailViolation) as exc_info:
            my_agent("Send to john@example.com")
        assert "pii" in str(exc_info.value).lower()

    def test_classify_and_check(self, tmp_path):
        """Classify file → check compliance → generate docs."""
        agent_file = tmp_path / "agent.py"
        agent_file.write_text("""
from langchain import LLMChain
from agentguard import monitor

@monitor
def hiring_agent(candidate):
    return f"Evaluating {candidate}"
""")

        # Classify
        classifier = RiskClassifier()
        cr = classifier.classify_file(agent_file)
        assert "langchain" in cr.agent_frameworks

        # Check compliance
        reg = EUAIActRegulation()
        result = reg.check_compliance({
            "purpose": "hiring tool",
            "domain": "recruitment",
            "frameworks": cr.agent_frameworks,
        })
        assert result.risk_level == "high"

        # Generate docs
        doc = generate_annex_iv(
            system_name="HiringBot",
            risk_level=result.risk_level,
            frameworks=cr.agent_frameworks,
            compliance_result={
                "findings": result.findings,
                "recommendations": result.recommendations,
            },
        )
        assert "HiringBot" in doc
        assert "high" in doc

    @pytest.mark.asyncio
    async def test_async_pipeline(self, tmp_path):
        """Async monitor with context and audit."""
        audit_path = tmp_path / "async_audit.jsonl"

        @monitor(
            audit="jsonfile",
            audit_path=str(audit_path),
        )
        async def async_agent(task):
            ctx.log_tool("api_call", endpoint="/data")
            return f"Async: {task}"

        result = await async_agent("test")
        assert result == "Async: test"

    def test_nested_agents(self, tmp_path):
        """Nested monitors with parent-child linkage."""
        audit_path = tmp_path / "nested.jsonl"

        @monitor(audit="jsonfile", audit_path=str(audit_path), agent_name="orchestrator")
        def orchestrator(task):
            ctx.log_reasoning("Delegating to worker")
            return worker(task)

        @monitor(audit="jsonfile", audit_path=str(audit_path), agent_name="worker")
        def worker(task):
            ctx.log_tool("process", task=task)
            return f"Processed: {task}"

        result = orchestrator("test")
        assert result == "Processed: test"

        time.sleep(0.3)
        backend = JSONFileBackend(path=audit_path)
        events = backend.query()
        assert len(events) >= 2
