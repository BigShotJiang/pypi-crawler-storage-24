"""Tests for regulation compliance checks."""

from agentguard.regulations.eu_ai_act import EUAIActRegulation


class TestEUAIActClassification:
    def setup_method(self):
        self.reg = EUAIActRegulation()

    def test_minimal_risk(self):
        assert self.reg.classify_risk({"purpose": "calculator"}) == "minimal"

    def test_low_risk_llm(self):
        assert self.reg.classify_risk({"purpose": "LLM chatbot"}) == "low"

    def test_high_risk_employment(self):
        assert self.reg.classify_risk({"purpose": "hiring tool", "domain": "recruitment"}) == "high"

    def test_high_risk_biometric(self):
        assert self.reg.classify_risk({"purpose": "facial recognition system"}) == "high"

    def test_high_risk_autonomy(self):
        assert self.reg.classify_risk({"mode": "autonomous", "purpose": "general"}) == "high"

    def test_unacceptable_social_scoring(self):
        assert self.reg.classify_risk({"purpose": "social scoring system"}) == "unacceptable"

    def test_high_risk_law_enforcement(self):
        assert self.reg.classify_risk({"domain": "law_enforcement", "purpose": "crime prediction"}) == "high"

    def test_high_risk_education(self):
        assert self.reg.classify_risk({"purpose": "student admission scoring"}) == "high"


class TestEUAIActCompliance:
    def setup_method(self):
        self.reg = EUAIActRegulation()

    def test_minimal_is_compliant(self):
        result = self.reg.check_compliance({"purpose": "calculator"})
        assert result.compliant is True
        assert result.risk_level == "minimal"

    def test_unacceptable_not_compliant(self):
        result = self.reg.check_compliance({"purpose": "social scoring"})
        assert result.compliant is False
        assert result.risk_level == "unacceptable"

    def test_high_risk_missing_docs(self):
        result = self.reg.check_compliance({"purpose": "hiring tool", "domain": "recruitment"})
        assert result.risk_level == "high"
        assert result.compliant is False
        assert any("documentation" in r.lower() for r in result.recommendations)

    def test_high_risk_with_docs(self):
        result = self.reg.check_compliance({
            "purpose": "hiring tool",
            "domain": "recruitment",
            "documentation": True,
            "risk_management": True,
            "human_oversight": True,
            "audit_trail": True,
        })
        assert result.risk_level == "high"
        assert result.compliant is True

    def test_annex_references(self):
        result = self.reg.check_compliance({"purpose": "hiring tool", "domain": "recruitment"})
        assert any("Annex III" in ref for ref in result.annex_references)
