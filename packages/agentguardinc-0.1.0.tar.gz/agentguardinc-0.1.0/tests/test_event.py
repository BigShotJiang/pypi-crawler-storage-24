"""Tests for DecisionEvent and GuardrailResult."""

import json

from agentguard.event import DecisionEvent, GuardrailResult


class TestGuardrailResult:
    def test_create(self):
        r = GuardrailResult(name="pii", passed=True)
        assert r.name == "pii"
        assert r.passed is True
        assert r.action == "none"

    def test_create_failed(self):
        r = GuardrailResult(name="pii", passed=False, action="block", detail="found email")
        assert not r.passed
        assert r.action == "block"


class TestDecisionEvent:
    def test_defaults(self):
        e = DecisionEvent()
        assert e.event_id  # non-empty
        assert e.timestamp  # non-empty
        assert e.agent_name == ""
        assert e.input_data == {}
        assert e.tools_used == []
        assert e.guardrail_results == []

    def test_custom_fields(self):
        e = DecisionEvent(agent_name="bot", function_name="run", risk_level="high")
        assert e.agent_name == "bot"
        assert e.function_name == "run"
        assert e.risk_level == "high"

    def test_to_dict(self):
        e = DecisionEvent(agent_name="bot")
        d = e.to_dict()
        assert isinstance(d, dict)
        assert d["agent_name"] == "bot"
        assert "event_id" in d

    def test_to_json(self):
        e = DecisionEvent(agent_name="bot", input_data={"key": "value"})
        s = e.to_json()
        parsed = json.loads(s)
        assert parsed["agent_name"] == "bot"
        assert parsed["input_data"] == {"key": "value"}

    def test_slots(self):
        e = DecisionEvent()
        assert hasattr(e, "__slots__")

    def test_unique_event_ids(self):
        e1 = DecisionEvent()
        e2 = DecisionEvent()
        assert e1.event_id != e2.event_id

    def test_guardrail_results_in_dict(self):
        e = DecisionEvent()
        e.guardrail_results.append(
            GuardrailResult(name="pii", passed=False, action="warn", detail="email found")
        )
        d = e.to_dict()
        assert len(d["guardrail_results"]) == 1
        assert d["guardrail_results"][0]["name"] == "pii"
