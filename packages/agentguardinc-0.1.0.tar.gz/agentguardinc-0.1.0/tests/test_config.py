"""Tests for GuardConfig and resolve_config."""

import json
import os

import pytest

from agentguard.config import GuardConfig, resolve_config, _find_config_file


class TestGuardConfig:
    def test_defaults(self):
        cfg = GuardConfig()
        assert cfg.audit_backend == "stdout"
        assert cfg.guardrails == ["pii", "scope"]
        assert cfg.pii_action == "warn"

    def test_from_dict(self):
        cfg = GuardConfig.from_dict({"audit_backend": "sqlite", "unknown_key": "ignored"})
        assert cfg.audit_backend == "sqlite"

    def test_from_dict_empty(self):
        cfg = GuardConfig.from_dict({})
        assert cfg.audit_backend == "stdout"


class TestResolveConfig:
    def test_defaults(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        cfg = resolve_config()
        assert cfg.audit_backend == "stdout"

    def test_env_override(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("AGENTGUARD_AUDIT_BACKEND", "sqlite")
        monkeypatch.setenv("AGENTGUARD_PII_ACTION", "block")
        cfg = resolve_config()
        assert cfg.audit_backend == "sqlite"
        assert cfg.pii_action == "block"

    def test_env_list(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("AGENTGUARD_ALLOWED_SCOPES", "read,write,delete")
        cfg = resolve_config()
        assert cfg.allowed_scopes == ["read", "write", "delete"]

    def test_config_file_json(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        config_file = tmp_path / "agentguard.json"
        config_file.write_text(json.dumps({"audit_backend": "jsonfile", "pii_action": "redact"}))
        cfg = resolve_config(start=tmp_path)
        assert cfg.audit_backend == "jsonfile"
        assert cfg.pii_action == "redact"

    def test_kwargs_override_env(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        monkeypatch.setenv("AGENTGUARD_AUDIT_BACKEND", "sqlite")
        cfg = resolve_config(audit_backend="jsonfile")
        assert cfg.audit_backend == "jsonfile"

    def test_config_file_walk_up(self, tmp_path, monkeypatch):
        # Place config in parent, start from child
        config_file = tmp_path / "agentguard.json"
        config_file.write_text(json.dumps({"regulation": "eu-ai-act"}))
        child = tmp_path / "sub" / "deep"
        child.mkdir(parents=True)
        found = _find_config_file(child)
        assert found == config_file
