"""Tests for @monitor decorator — the core of AgentGuard."""

import asyncio
import time
import threading
from unittest.mock import patch, MagicMock

import pytest

from agentguard import monitor, ctx, GuardrailViolation
from agentguard.config import GuardConfig
from agentguard.context import _current_context


class TestDecoratorForms:
    """Test all three decorator forms."""

    def test_bare_decorator(self):
        @monitor
        def greet(name):
            return f"Hello {name}"

        assert greet("World") == "Hello World"

    def test_empty_parens(self):
        @monitor()
        def greet(name):
            return f"Hello {name}"

        assert greet("World") == "Hello World"

    def test_with_kwargs(self):
        @monitor(audit="stdout", regulation="eu-ai-act")
        def greet(name):
            return f"Hello {name}"

        assert greet("World") == "Hello World"


class TestSyncMonitor:
    def test_basic_function(self):
        @monitor(audit="stdout")
        def add(a, b):
            return a + b

        assert add(2, 3) == 5

    def test_preserves_return_value(self):
        @monitor(audit="stdout")
        def get_dict():
            return {"key": "value"}

        result = get_dict()
        assert result == {"key": "value"}

    def test_none_return(self):
        @monitor(audit="stdout")
        def noop():
            pass

        assert noop() is None

    def test_exception_propagation(self):
        @monitor(audit="stdout")
        def bad():
            raise ValueError("test error")

        with pytest.raises(ValueError, match="test error"):
            bad()

    def test_functools_wraps(self):
        @monitor(audit="stdout")
        def documented_fn():
            """My docstring."""
            pass

        assert documented_fn.__name__ == "documented_fn"
        assert documented_fn.__doc__ == "My docstring."


class TestAsyncMonitor:
    @pytest.mark.asyncio
    async def test_async_function(self):
        @monitor(audit="stdout")
        async def async_add(a, b):
            return a + b

        result = await async_add(2, 3)
        assert result == 5

    @pytest.mark.asyncio
    async def test_async_preserves_return(self):
        @monitor(audit="stdout")
        async def async_dict():
            return {"key": "value"}

        assert await async_dict() == {"key": "value"}

    @pytest.mark.asyncio
    async def test_async_exception(self):
        @monitor(audit="stdout")
        async def async_bad():
            raise ValueError("async error")

        with pytest.raises(ValueError, match="async error"):
            await async_bad()

    @pytest.mark.asyncio
    async def test_async_wraps(self):
        @monitor(audit="stdout")
        async def my_async():
            """Async doc."""
            pass

        assert my_async.__name__ == "my_async"
        assert my_async.__doc__ == "Async doc."


class TestContextCapture:
    def test_tools_captured(self):
        captured = {}

        @monitor(audit="stdout")
        def agent(task):
            ctx.log_tool("search", query=task)
            ctx.log_tool("write", content="result")
            return "done"

        agent("test")
        # Context is cleaned up after, but the function ran fine
        assert not ctx.active

    def test_reasoning_captured(self):
        @monitor(audit="stdout")
        def agent(task):
            ctx.log_reasoning("Because X leads to Y")
            return "done"

        assert agent("test") == "done"

    def test_model_captured(self):
        @monitor(audit="stdout")
        def agent(task):
            ctx.log_model("gpt-4", tokens=150)
            return "done"

        assert agent("test") == "done"

    def test_context_active_during_execution(self):
        was_active = []

        @monitor(audit="stdout")
        def agent():
            was_active.append(ctx.active)
            return "done"

        agent()
        assert was_active == [True]

    def test_context_inactive_after(self):
        @monitor(audit="stdout")
        def agent():
            return "done"

        agent()
        assert not ctx.active


class TestNestedMonitors:
    def test_parent_id_linkage(self):
        parent_ids = []

        @monitor(audit="stdout", agent_name="outer")
        def outer():
            inner()
            return "outer done"

        @monitor(audit="stdout", agent_name="inner")
        def inner():
            # Inside inner, the context should have parent_id from outer
            dc = _current_context.get(None)
            if dc:
                parent_ids.append(dc.parent_id)
            return "inner done"

        outer()
        assert len(parent_ids) == 1
        assert parent_ids[0] != ""  # should have outer's event_id


class TestGuardrails:
    def test_pii_block_input(self):
        @monitor(
            guardrails=["pii"],
            pii_action="block",
            audit="stdout",
        )
        def agent(data):
            return data

        with pytest.raises(GuardrailViolation):
            agent("Contact john@example.com")

    def test_pii_warn_passes(self):
        @monitor(
            guardrails=["pii"],
            pii_action="warn",
            audit="stdout",
        )
        def agent(data):
            return data

        # Should not raise
        assert agent("Contact john@example.com") == "Contact john@example.com"

    def test_scope_block(self):
        @monitor(
            guardrails=["scope"],
            allowed_scopes=["safe_fn"],
            audit="stdout",
        )
        def dangerous_fn():
            return "should not run"

        with pytest.raises(GuardrailViolation):
            dangerous_fn()


class TestFailOpen:
    def test_internal_error_doesnt_crash(self):
        """If monitoring infrastructure fails, the function still runs."""

        @monitor(audit="stdout")
        def my_fn():
            return 42

        # Patch guardrail engine to raise
        with patch(
            "agentguard.monitor.GuardrailEngine.check_input",
            side_effect=RuntimeError("internal boom"),
        ):
            result = my_fn()
            assert result == 42

    def test_audit_error_doesnt_crash(self):
        """If audit emission fails, function result is still returned."""

        @monitor(audit="stdout")
        def my_fn():
            return "ok"

        with patch("agentguard.monitor.get_trail", side_effect=RuntimeError("audit boom")):
            assert my_fn() == "ok"


class TestPerformance:
    def test_overhead_under_5ms(self):
        @monitor(audit="stdout")
        def noop():
            pass

        # Warmup
        for _ in range(10):
            noop()

        # Measure
        start = time.perf_counter()
        iterations = 1000
        for _ in range(iterations):
            noop()
        elapsed = (time.perf_counter() - start) * 1000  # ms

        avg_ms = elapsed / iterations
        assert avg_ms < 5, f"Average overhead {avg_ms:.2f}ms exceeds 5ms limit"


class TestThreadSafety:
    def test_concurrent_monitors(self):
        results = {}

        @monitor(audit="stdout")
        def worker(name):
            ctx.log_tool(name)
            return name

        def run(name):
            results[name] = worker(name)

        threads = [threading.Thread(target=run, args=(f"t{i}",)) for i in range(10)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        for i in range(10):
            assert results[f"t{i}"] == f"t{i}"


class TestAsyncGatherIsolation:
    @pytest.mark.asyncio
    async def test_concurrent_async_monitors(self):
        @monitor(audit="stdout")
        async def async_worker(name):
            ctx.log_tool(name)
            await asyncio.sleep(0.01)
            return name

        results = await asyncio.gather(
            *[async_worker(f"a{i}") for i in range(10)]
        )
        assert results == [f"a{i}" for i in range(10)]
