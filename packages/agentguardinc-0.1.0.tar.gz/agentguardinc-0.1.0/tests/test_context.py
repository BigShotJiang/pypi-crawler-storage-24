"""Tests for DecisionContext and ctx proxy."""

import asyncio
import threading

from agentguard.context import DecisionContext, _current_context, ctx


class TestDecisionContext:
    def test_context_manager(self):
        dc = DecisionContext(event_id="e1")
        assert _current_context.get(None) is None
        with dc:
            assert _current_context.get(None) is dc
        assert _current_context.get(None) is None

    def test_nesting(self):
        outer = DecisionContext(event_id="outer")
        inner = DecisionContext(event_id="inner")
        with outer:
            with inner:
                assert inner.parent_id == "outer"
                assert _current_context.get(None) is inner
            assert _current_context.get(None) is outer
        assert _current_context.get(None) is None

    def test_log_tool(self):
        dc = DecisionContext(event_id="e1")
        dc.log_tool("search", query="test")
        assert len(dc.tools) == 1
        assert dc.tools[0]["name"] == "search"
        assert dc.tools[0]["query"] == "test"

    def test_log_reasoning(self):
        dc = DecisionContext(event_id="e1")
        dc.log_reasoning("Because X")
        assert dc.reasoning == "Because X"

    def test_log_model(self):
        dc = DecisionContext(event_id="e1")
        dc.log_model("gpt-4", tokens=100)
        dc.log_model("gpt-4", tokens=50)
        assert dc.model == "gpt-4"
        assert dc.tokens_used == 150

    def test_metadata(self):
        dc = DecisionContext(event_id="e1")
        dc.set("key", "value")
        assert dc.get("key") == "value"
        assert dc.get("missing", "default") == "default"


class TestCtxProxy:
    def test_noop_outside_context(self):
        # Should not raise
        ctx.log_tool("test")
        ctx.log_reasoning("test")
        ctx.log_model("test")
        ctx.set("key", "val")
        assert ctx.get("key") is None
        assert ctx.active is False

    def test_works_inside_context(self):
        dc = DecisionContext(event_id="e1")
        with dc:
            assert ctx.active is True
            ctx.log_tool("search", query="q")
            ctx.log_reasoning("reason")
            ctx.log_model("gpt-4", tokens=10)
            ctx.set("custom", "value")
            assert ctx.get("custom") == "value"
        assert dc.tools[0]["name"] == "search"
        assert dc.reasoning == "reason"
        assert dc.model == "gpt-4"

    def test_thread_isolation(self):
        results = {}

        def worker(name):
            dc = DecisionContext(event_id=name)
            with dc:
                ctx.log_tool(name)
                results[name] = dc.tools[:]

        t1 = threading.Thread(target=worker, args=("t1",))
        t2 = threading.Thread(target=worker, args=("t2",))
        t1.start()
        t2.start()
        t1.join()
        t2.join()

        assert results["t1"][0]["name"] == "t1"
        assert results["t2"][0]["name"] == "t2"

    def test_async_isolation(self):
        async def task(name):
            dc = DecisionContext(event_id=name)
            with dc:
                ctx.log_tool(name)
                await asyncio.sleep(0.01)
                return dc.tools[0]["name"]

        async def main():
            r1, r2 = await asyncio.gather(task("a1"), task("a2"))
            return r1, r2

        r1, r2 = asyncio.run(main())
        assert r1 == "a1"
        assert r2 == "a2"
