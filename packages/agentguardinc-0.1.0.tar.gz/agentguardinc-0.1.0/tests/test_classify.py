"""Tests for AST-based risk classifier."""

from agentguard.classify import RiskClassifier


class TestRiskClassifier:
    def setup_method(self):
        self.classifier = RiskClassifier()

    def test_minimal_risk(self):
        source = """
def hello():
    return "world"
"""
        result = self.classifier.classify_source(source)
        assert result.risk_level == "minimal"
        assert result.function_count == 1

    def test_agent_framework_detected(self):
        source = """
from langchain import LLMChain
def my_agent():
    pass
"""
        result = self.classifier.classify_source(source)
        assert "langchain" in result.agent_frameworks
        assert result.score >= 20

    def test_dangerous_calls(self):
        source = """
import subprocess
def run_cmd():
    subprocess.run(["ls"])
"""
        result = self.classifier.classify_source(source)
        assert "subprocess.run" in result.dangerous_calls

    def test_autonomy_markers(self):
        source = '''
def auto_execute():
    """This function runs autonomously."""
    pass
'''
        result = self.classifier.classify_source(source)
        assert len(result.autonomy_markers) > 0

    def test_monitor_detected(self):
        source = """
from agentguard import monitor

@monitor
def my_agent():
    pass
"""
        result = self.classifier.classify_source(source)
        assert result.has_monitor_decorator is True

    def test_high_risk_combination(self):
        source = """
from langchain import LLMChain
import subprocess

def auto_execute(task):
    subprocess.run(["bash", "-c", task])
"""
        result = self.classifier.classify_source(source)
        assert result.risk_level == "high"

    def test_syntax_error(self):
        result = self.classifier.classify_source("def broken(")
        assert "Syntax error" in result.findings[0]

    def test_classify_file(self, tmp_path):
        f = tmp_path / "agent.py"
        f.write_text("def hello(): return 42\n")
        result = self.classifier.classify_file(f)
        assert result.function_count == 1

    def test_classify_missing_file(self):
        result = self.classifier.classify_file("/nonexistent/file.py")
        assert "not found" in result.findings[0].lower()

    def test_class_count(self):
        source = """
class Agent:
    def run(self):
        pass

class Tool:
    pass
"""
        result = self.classifier.classify_source(source)
        assert result.class_count == 2
        assert result.function_count == 1
