"""Tests for guardrails: PII, Scope, Engine."""

import pytest

from agentguard.event import GuardrailResult
from agentguard.exceptions import GuardrailViolation
from agentguard.guardrails.pii import PIIGuardrail
from agentguard.guardrails.scope import ScopeGuardrail
from agentguard.guardrails.engine import GuardrailEngine


class TestPIIGuardrail:
    def test_no_pii(self):
        g = PIIGuardrail(action="warn")
        result = g.check("Hello world, no secrets here")
        assert result.passed is True

    def test_detect_email(self):
        g = PIIGuardrail(action="warn")
        result = g.check("Contact john@example.com for details")
        assert result.passed is False
        assert "email" in result.detail

    def test_detect_phone(self):
        g = PIIGuardrail(action="warn")
        result = g.check("Call me at 555-123-4567")
        assert result.passed is False
        assert "phone" in result.detail

    def test_detect_ssn(self):
        g = PIIGuardrail(action="warn")
        result = g.check("SSN: 123-45-6789")
        assert result.passed is False
        assert "ssn" in result.detail

    def test_detect_ip(self):
        g = PIIGuardrail(action="warn")
        result = g.check("Server at 192.168.1.1")
        assert result.passed is False
        assert "ip_address" in result.detail

    def test_redact(self):
        g = PIIGuardrail(action="redact")
        text = "Email: john@example.com, Phone: 555-123-4567"
        redacted = g.redact(text)
        assert "john@example.com" not in redacted
        assert "555-123-4567" not in redacted
        assert "[REDACTED]" in redacted

    def test_extract_text_dict(self):
        text = PIIGuardrail._extract_text({"name": "John", "email": "john@test.com"})
        assert "john@test.com" in text

    def test_invalid_action(self):
        with pytest.raises(ValueError):
            PIIGuardrail(action="invalid")


class TestScopeGuardrail:
    def test_open_policy(self):
        g = ScopeGuardrail()
        result = g.check("anything")
        assert result.passed is True

    def test_allowed(self):
        g = ScopeGuardrail(allowed=["read", "write"])
        assert g.check("read").passed is True
        assert g.check("write").passed is True

    def test_blocked(self):
        g = ScopeGuardrail(allowed=["read"])
        result = g.check("delete")
        assert result.passed is False
        assert result.action == "block"
        assert "delete" in result.detail


class TestGuardrailEngine:
    def test_no_guardrails(self):
        engine = GuardrailEngine(guardrail_names=[])
        results = engine.check_input({"task": "hello"})
        assert results == []

    def test_pii_warn(self):
        engine = GuardrailEngine(guardrail_names=["pii"], pii_action="warn")
        results = engine.check_input({"email": "john@test.com"})
        assert len(results) == 1
        assert results[0].passed is False
        assert results[0].action == "warn"

    def test_pii_block_raises(self):
        engine = GuardrailEngine(guardrail_names=["pii"], pii_action="block")
        with pytest.raises(GuardrailViolation) as exc_info:
            engine.check_input({"email": "john@test.com"})
        assert exc_info.value.guardrail == "pii"

    def test_scope_block_raises(self):
        engine = GuardrailEngine(
            guardrail_names=["scope"],
            allowed_scopes=["read"],
        )
        with pytest.raises(GuardrailViolation) as exc_info:
            engine.check_input({}, function_name="delete_all")
        assert exc_info.value.guardrail == "scope"

    def test_post_execution_never_blocks(self):
        engine = GuardrailEngine(guardrail_names=["pii"], pii_action="block")
        # Post-execution should downgrade block to warn
        results = engine.check_output("john@test.com")
        assert len(results) == 1
        assert results[0].action == "warn"  # downgraded from block

    def test_redact_output(self):
        engine = GuardrailEngine(guardrail_names=["pii"], pii_action="redact")
        output = engine.redact_output("Email: john@test.com")
        assert "john@test.com" not in output
        assert "[REDACTED]" in output
