"""AgentGuard — compliance infrastructure for AI agents.

Usage:
    from agentguard import monitor, ctx, GuardConfig

    @monitor(audit="stdout")
    def my_agent(task):
        ctx.log_tool("search", query=task)
        return f"Done: {task}"
"""

from ._version import __version__
from .config import GuardConfig, resolve_config
from .context import ctx
from .exceptions import AgentGuardError, ConfigError, GuardrailViolation
from .monitor import monitor

__all__ = [
    "__version__",
    "monitor",
    "ctx",
    "GuardConfig",
    "resolve_config",
    "AgentGuardError",
    "ConfigError",
    "GuardrailViolation",
]
