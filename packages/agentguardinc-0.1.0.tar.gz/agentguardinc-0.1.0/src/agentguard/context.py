"""Decision context — thread-safe, async-safe context for agent monitoring."""

from __future__ import annotations

from contextvars import ContextVar
from dataclasses import dataclass, field
from typing import Any


_current_context: ContextVar[DecisionContext | None] = ContextVar(
    "agentguard_context", default=None
)


@dataclass
class DecisionContext:
    """Holds mutable state during a monitored function's execution.

    Used as a context manager — push on enter, pop on exit.
    Supports nesting: inner context gets parent_id from outer.
    """

    event_id: str = ""
    parent_id: str = ""
    tools: list[dict[str, Any]] = field(default_factory=list)
    reasoning: str = ""
    model: str = ""
    tokens_used: int = 0
    metadata: dict[str, Any] = field(default_factory=dict)

    _token: Any = field(default=None, repr=False)

    def __enter__(self) -> DecisionContext:
        outer = _current_context.get(None)
        if outer is not None:
            self.parent_id = outer.event_id
        self._token = _current_context.set(self)
        return self

    def __exit__(self, *exc: object) -> None:
        if self._token is not None:
            _current_context.reset(self._token)
            self._token = None

    # ── Public API (called by user code inside @monitor) ──

    def log_tool(self, name: str, **kwargs: Any) -> None:
        self.tools.append({"name": name, **kwargs})

    def log_reasoning(self, text: str) -> None:
        self.reasoning = text

    def log_model(self, model: str, tokens: int = 0) -> None:
        self.model = model
        self.tokens_used += tokens

    def set(self, key: str, value: Any) -> None:
        self.metadata[key] = value

    def get(self, key: str, default: Any = None) -> Any:
        return self.metadata.get(key, default)


class _CtxProxy:
    """Module-level proxy to the current DecisionContext.

    All methods no-op (silently) if called outside a @monitor block.
    This ensures user code never crashes due to missing context.
    """

    @staticmethod
    def _current() -> DecisionContext | None:
        return _current_context.get(None)

    def log_tool(self, name: str, **kwargs: Any) -> None:
        c = self._current()
        if c is not None:
            c.log_tool(name, **kwargs)

    def log_reasoning(self, text: str) -> None:
        c = self._current()
        if c is not None:
            c.log_reasoning(text)

    def log_model(self, model: str, tokens: int = 0) -> None:
        c = self._current()
        if c is not None:
            c.log_model(model, tokens)

    def set(self, key: str, value: Any) -> None:
        c = self._current()
        if c is not None:
            c.set(key, value)

    def get(self, key: str, default: Any = None) -> Any:
        c = self._current()
        if c is not None:
            return c.get(key, default)
        return default

    @property
    def active(self) -> bool:
        return self._current() is not None


ctx = _CtxProxy()
