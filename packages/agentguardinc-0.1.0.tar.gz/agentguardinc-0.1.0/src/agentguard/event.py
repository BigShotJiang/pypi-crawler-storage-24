"""Decision event — the core data record for every monitored call."""

from __future__ import annotations

import json
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Any


@dataclass(slots=True)
class GuardrailResult:
    """Result of a single guardrail check."""

    name: str
    passed: bool
    action: str = "none"  # block | warn | redact | none
    detail: str = ""


@dataclass(slots=True)
class DecisionEvent:
    """Immutable record of a single agent decision/action."""

    event_id: str = field(default_factory=lambda: uuid.uuid4().hex)
    timestamp: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    agent_name: str = ""
    function_name: str = ""
    module: str = ""
    parent_id: str = ""

    # Input/output
    input_data: dict[str, Any] = field(default_factory=dict)
    output_summary: str = ""

    # Context captured via ctx API
    tools_used: list[dict[str, Any]] = field(default_factory=list)
    reasoning: str = ""
    model: str = ""
    tokens_used: int = 0

    # Compliance
    risk_level: str = ""  # low | medium | high | critical
    regulation: str = ""
    guardrail_results: list[GuardrailResult] = field(default_factory=list)

    # Timing
    duration_ms: float = 0.0
    error: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Convert to plain dict, serializing nested dataclasses."""
        d = asdict(self)
        return d

    def to_json(self) -> str:
        """Serialize to JSON string."""
        return json.dumps(self.to_dict(), default=str, ensure_ascii=False)
