"""AST-based static risk classifier for Python agent code."""

from __future__ import annotations

import ast
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


# Keywords/patterns that indicate autonomous behavior
_AUTONOMY_INDICATORS = {
    "auto_approve", "auto_execute", "autonomous", "self_driving",
    "no_human_oversight", "unsupervised", "automated_decision",
    "execute_action", "take_action", "run_autonomously",
}

# High-risk domain imports
_HIGH_RISK_IMPORTS = {
    "facial_recognition", "biometric", "deepface",
    "credit_scoring", "recidivism",
}

# Tool/action frameworks
_AGENT_FRAMEWORKS = {
    "langchain", "crewai", "autogen", "semantic_kernel",
    "openai", "anthropic", "transformers",
}

# Dangerous operations
_DANGEROUS_CALLS = {
    "subprocess.run", "subprocess.call", "subprocess.Popen",
    "os.system", "os.exec", "os.popen",
    "eval", "exec", "compile",
    "shutil.rmtree", "os.remove", "os.unlink",
}


@dataclass
class ClassificationResult:
    """Result of static risk classification."""

    file_path: str = ""
    risk_level: str = "minimal"  # minimal | low | high | critical
    score: int = 0
    findings: list[str] = field(default_factory=list)
    imports: list[str] = field(default_factory=list)
    agent_frameworks: list[str] = field(default_factory=list)
    autonomy_markers: list[str] = field(default_factory=list)
    dangerous_calls: list[str] = field(default_factory=list)
    has_monitor_decorator: bool = False
    function_count: int = 0
    class_count: int = 0


class RiskClassifier:
    """AST-based static analysis for AI agent risk classification."""

    def classify_file(self, path: str | Path) -> ClassificationResult:
        """Classify a single Python file."""
        path = Path(path)
        result = ClassificationResult(file_path=str(path))

        if not path.exists():
            result.findings.append(f"File not found: {path}")
            return result

        source = path.read_text(encoding="utf-8")
        return self.classify_source(source, file_path=str(path))

    def classify_source(
        self, source: str, file_path: str = "<string>"
    ) -> ClassificationResult:
        """Classify Python source code."""
        result = ClassificationResult(file_path=file_path)

        try:
            tree = ast.parse(source)
        except SyntaxError as e:
            result.findings.append(f"Syntax error: {e}")
            return result

        visitor = _RiskVisitor()
        visitor.visit(tree)

        result.imports = visitor.imports
        result.agent_frameworks = visitor.agent_frameworks
        result.autonomy_markers = visitor.autonomy_markers
        result.dangerous_calls = visitor.dangerous_calls
        result.has_monitor_decorator = visitor.has_monitor
        result.function_count = visitor.function_count
        result.class_count = visitor.class_count

        # Score calculation
        score = 0

        if visitor.agent_frameworks:
            score += 20
            result.findings.append(
                f"Uses agent framework(s): {', '.join(visitor.agent_frameworks)}"
            )

        if visitor.autonomy_markers:
            score += 30
            result.findings.append(
                f"Autonomy indicators found: {', '.join(visitor.autonomy_markers)}"
            )

        if visitor.dangerous_calls:
            score += 25
            result.findings.append(
                f"Dangerous calls: {', '.join(visitor.dangerous_calls)}"
            )

        for imp in visitor.imports:
            if imp in _HIGH_RISK_IMPORTS:
                score += 20
                result.findings.append(f"High-risk domain import: {imp}")

        if not visitor.has_monitor:
            score += 5
            result.findings.append("No @monitor decorator found — not instrumented")

        result.score = score

        if score >= 50:
            result.risk_level = "high"
        elif score >= 30:
            result.risk_level = "low"
        else:
            result.risk_level = "minimal"

        return result


class _RiskVisitor(ast.NodeVisitor):
    """AST visitor that extracts risk-relevant information."""

    def __init__(self) -> None:
        self.imports: list[str] = []
        self.agent_frameworks: list[str] = []
        self.autonomy_markers: list[str] = []
        self.dangerous_calls: list[str] = []
        self.has_monitor: bool = False
        self.function_count: int = 0
        self.class_count: int = 0

    def visit_Import(self, node: ast.Import) -> None:
        for alias in node.names:
            name = alias.name.split(".")[0]
            self.imports.append(name)
            if name in _AGENT_FRAMEWORKS:
                self.agent_frameworks.append(name)
        self.generic_visit(node)

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        if node.module:
            root = node.module.split(".")[0]
            self.imports.append(root)
            if root in _AGENT_FRAMEWORKS:
                self.agent_frameworks.append(root)
        self.generic_visit(node)

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self.function_count += 1
        self._check_decorators(node)
        self._check_name(node.name)
        self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self.function_count += 1
        self._check_decorators(node)
        self._check_name(node.name)
        self.generic_visit(node)

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        self.class_count += 1
        self._check_name(node.name)
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call) -> None:
        call_name = _get_call_name(node)
        if call_name and call_name in _DANGEROUS_CALLS:
            self.dangerous_calls.append(call_name)
        self.generic_visit(node)

    def visit_Constant(self, node: ast.Constant) -> None:
        if isinstance(node.value, str):
            low = node.value.lower()
            for marker in _AUTONOMY_INDICATORS:
                if marker.replace("_", " ") in low or marker in low:
                    self.autonomy_markers.append(marker)
                    break
        self.generic_visit(node)

    def _check_decorators(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        for dec in node.decorator_list:
            name = _get_decorator_name(dec)
            if name and "monitor" in name:
                self.has_monitor = True

    def _check_name(self, name: str) -> None:
        low = name.lower()
        for marker in _AUTONOMY_INDICATORS:
            if marker in low:
                if marker not in self.autonomy_markers:
                    self.autonomy_markers.append(marker)


def _get_call_name(node: ast.Call) -> str | None:
    """Extract dotted name from a Call node."""
    if isinstance(node.func, ast.Name):
        return node.func.id
    if isinstance(node.func, ast.Attribute):
        parts = []
        current: ast.expr = node.func
        while isinstance(current, ast.Attribute):
            parts.append(current.attr)
            current = current.value
        if isinstance(current, ast.Name):
            parts.append(current.id)
        return ".".join(reversed(parts))
    return None


def _get_decorator_name(node: ast.expr) -> str | None:
    """Extract name from a decorator node."""
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return node.attr
    if isinstance(node, ast.Call):
        return _get_decorator_name(node.func)
    return None
