"""AgentGuard exceptions."""

from __future__ import annotations


class AgentGuardError(Exception):
    """Base exception for all AgentGuard errors."""


class GuardrailViolation(AgentGuardError):
    """Raised when a guardrail blocks execution.

    Attributes:
        guardrail: Name of the guardrail that triggered.
        action: The action taken (block, warn, redact).
        detail: Human-readable description.
    """

    def __init__(
        self,
        guardrail: str,
        action: str = "block",
        detail: str = "",
    ) -> None:
        self.guardrail = guardrail
        self.action = action
        self.detail = detail
        msg = f"[{guardrail}] {action}: {detail}" if detail else f"[{guardrail}] {action}"
        super().__init__(msg)


class ConfigError(AgentGuardError):
    """Raised on invalid configuration."""
