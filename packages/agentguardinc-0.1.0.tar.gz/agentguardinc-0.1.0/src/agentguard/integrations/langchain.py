"""LangChain integration — callback handler that feeds data into AgentGuard context."""

from __future__ import annotations

from typing import Any

from ..context import _current_context


try:
    from langchain_core.callbacks import BaseCallbackHandler

    class AgentGuardCallbackHandler(BaseCallbackHandler):
        """LangChain callback handler that logs to the current AgentGuard context.

        Usage:
            from agentguard.integrations.langchain import AgentGuardCallbackHandler
            chain.invoke(input, config={"callbacks": [AgentGuardCallbackHandler()]})
        """

        def on_llm_start(
            self,
            serialized: dict[str, Any],
            prompts: list[str],
            **kwargs: Any,
        ) -> None:
            ctx = _current_context.get(None)
            if ctx is not None:
                model_name = serialized.get("name", "") or serialized.get("id", [""])[-1]
                ctx.model = model_name

        def on_llm_end(self, response: Any, **kwargs: Any) -> None:
            ctx = _current_context.get(None)
            if ctx is not None:
                try:
                    usage = response.llm_output or {}
                    tokens = usage.get("token_usage", {}).get("total_tokens", 0)
                    if tokens:
                        ctx.tokens_used += tokens
                except Exception:
                    pass

        def on_tool_start(
            self,
            serialized: dict[str, Any],
            input_str: str,
            **kwargs: Any,
        ) -> None:
            ctx = _current_context.get(None)
            if ctx is not None:
                tool_name = serialized.get("name", "unknown_tool")
                ctx.log_tool(tool_name, input=input_str[:500])

        def on_tool_end(self, output: str, **kwargs: Any) -> None:
            ctx = _current_context.get(None)
            if ctx is not None and ctx.tools:
                ctx.tools[-1]["output"] = output[:500]

        def on_chain_error(self, error: BaseException, **kwargs: Any) -> None:
            pass  # Errors handled by @monitor

except ImportError:
    # LangChain not installed — provide a helpful error on import
    class AgentGuardCallbackHandler:  # type: ignore[no-redef]
        def __init__(self, *args: Any, **kwargs: Any) -> None:
            raise ImportError(
                "LangChain is not installed. Install it with: "
                "pip install agentguard[langchain]"
            )
