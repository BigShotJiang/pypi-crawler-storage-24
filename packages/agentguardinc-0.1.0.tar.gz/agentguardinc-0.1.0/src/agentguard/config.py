"""Configuration discovery and resolution."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


_CONFIG_FILENAMES = ("agentguard.json", "agentguard.yaml", "agentguard.yml")


@dataclass
class GuardConfig:
    """Resolved configuration for AgentGuard.

    Resolution order: kwargs > env vars > config file > defaults.
    """

    audit_backend: str = "stdout"
    audit_path: str = ""
    guardrails: list[str] = field(default_factory=lambda: ["pii", "scope"])
    allowed_scopes: list[str] = field(default_factory=list)
    pii_action: str = "warn"  # block | warn | redact
    regulation: str = ""
    risk_level: str = ""
    log_level: str = "WARNING"

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> GuardConfig:
        """Create config from a dict, ignoring unknown keys."""
        known = {f.name for f in cls.__dataclass_fields__.values()}
        filtered = {k: v for k, v in data.items() if k in known}
        return cls(**filtered)


def _find_config_file(start: Path | None = None) -> Path | None:
    """Walk up from *start* (default: cwd) looking for a config file."""
    current = start or Path.cwd()
    current = current.resolve()
    while True:
        for name in _CONFIG_FILENAMES:
            candidate = current / name
            if candidate.is_file():
                return candidate
        parent = current.parent
        if parent == current:
            break
        current = parent
    return None


def _load_config_file(path: Path) -> dict[str, Any]:
    """Load a JSON or YAML config file."""
    text = path.read_text(encoding="utf-8")
    if path.suffix == ".json":
        return json.loads(text)  # type: ignore[no-any-return]
    # YAML
    try:
        import yaml  # type: ignore[import-untyped]
    except ImportError:
        from .exceptions import ConfigError

        raise ConfigError(
            f"Found config file {path} but PyYAML is not installed. "
            "Install it with: pip install agentguard[yaml]"
        )
    return yaml.safe_load(text) or {}  # type: ignore[no-any-return]


def _env_overrides() -> dict[str, Any]:
    """Read AGENTGUARD_* env vars and return as dict."""
    mapping: dict[str, str] = {
        "AGENTGUARD_AUDIT_BACKEND": "audit_backend",
        "AGENTGUARD_AUDIT_PATH": "audit_path",
        "AGENTGUARD_PII_ACTION": "pii_action",
        "AGENTGUARD_REGULATION": "regulation",
        "AGENTGUARD_RISK_LEVEL": "risk_level",
        "AGENTGUARD_LOG_LEVEL": "log_level",
    }
    result: dict[str, Any] = {}
    for env_key, config_key in mapping.items():
        val = os.environ.get(env_key)
        if val is not None:
            result[config_key] = val
    # List-type env vars
    scopes = os.environ.get("AGENTGUARD_ALLOWED_SCOPES")
    if scopes is not None:
        result["allowed_scopes"] = [s.strip() for s in scopes.split(",") if s.strip()]
    guardrails = os.environ.get("AGENTGUARD_GUARDRAILS")
    if guardrails is not None:
        result["guardrails"] = [g.strip() for g in guardrails.split(",") if g.strip()]
    return result


def resolve_config(
    start: Path | None = None, **overrides: Any
) -> GuardConfig:
    """Build a GuardConfig with full resolution chain.

    Priority: overrides > env vars > config file > defaults.
    """
    # Start with defaults
    merged: dict[str, Any] = {}

    # Config file
    config_file = _find_config_file(start)
    if config_file is not None:
        merged.update(_load_config_file(config_file))

    # Env vars
    merged.update(_env_overrides())

    # Explicit overrides
    merged.update({k: v for k, v in overrides.items() if v is not None})

    return GuardConfig.from_dict(merged)
