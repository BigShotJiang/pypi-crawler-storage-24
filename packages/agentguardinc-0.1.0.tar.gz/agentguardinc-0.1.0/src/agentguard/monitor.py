"""@monitor decorator — the heart of AgentGuard."""

from __future__ import annotations

import asyncio
import functools
import inspect
import json
import time
from typing import Any, Callable, TypeVar, overload

from .audit.trail import get_or_create as get_trail
from .config import GuardConfig, resolve_config
from .context import DecisionContext, _current_context
from .event import DecisionEvent
from .exceptions import GuardrailViolation
from .guardrails.engine import GuardrailEngine

F = TypeVar("F", bound=Callable[..., Any])

_SENTINEL = object()

# ── Serialization helpers ──

_MAX_DEPTH = 5
_MAX_SIZE = 10_240  # 10 KB


def _safe_serialize(obj: Any, depth: int = 0) -> Any:
    """Best-effort serialization with depth and size limits."""
    if depth > _MAX_DEPTH:
        return "<max depth>"
    if obj is None or isinstance(obj, (bool, int, float)):
        return obj
    if isinstance(obj, str):
        return obj[:_MAX_SIZE] if len(obj) > _MAX_SIZE else obj
    if isinstance(obj, bytes):
        return f"<bytes len={len(obj)}>"
    if isinstance(obj, (list, tuple)):
        return [_safe_serialize(item, depth + 1) for item in obj[:50]]
    if isinstance(obj, dict):
        return {
            str(k): _safe_serialize(v, depth + 1) for k, v in list(obj.items())[:50]
        }
    # Fallback: try str(), else repr type
    try:
        s = str(obj)
        return s[:_MAX_SIZE] if len(s) > _MAX_SIZE else s
    except Exception:
        return f"<{type(obj).__name__}>"


def _serialize_args(fn: Callable[..., Any], args: tuple[Any, ...], kwargs: dict[str, Any]) -> dict[str, Any]:
    """Serialize function arguments using inspect.signature."""
    try:
        sig = inspect.signature(fn)
        bound = sig.bind(*args, **kwargs)
        bound.apply_defaults()
        return {k: _safe_serialize(v) for k, v in bound.arguments.items()}
    except Exception:
        # Fallback: positional + keyword
        result: dict[str, Any] = {}
        if args:
            result["args"] = [_safe_serialize(a) for a in args]
        if kwargs:
            result["kwargs"] = {k: _safe_serialize(v) for k, v in kwargs.items()}
        return result


def _summarize_output(result: Any) -> str:
    """Create a short string summary of the output."""
    if result is None:
        return "None"
    try:
        s = str(result)
        return s[:500] if len(s) > 500 else s
    except Exception:
        return f"<{type(result).__name__}>"


# ── Decorator ──


@overload
def monitor(_fn: F) -> F: ...
@overload
def monitor(_fn: None = None, **kwargs: Any) -> Callable[[F], F]: ...


def monitor(
    _fn: F | None = None,
    *,
    regulation: str | None = None,
    guardrails: list[str] | None = None,
    audit: str | None = None,
    audit_path: str | None = None,
    agent_name: str | None = None,
    pii_action: str | None = None,
    allowed_scopes: list[str] | None = None,
    config: GuardConfig | None = None,
    **extra: Any,
) -> F | Callable[[F], F]:
    """Decorator for monitoring agent functions.

    Three forms:
        @monitor
        @monitor()
        @monitor(regulation="eu-ai-act", audit="sqlite")
    """

    def decorator(fn: F) -> F:
        # Resolve config once at decoration time
        cfg = config or resolve_config(
            audit_backend=audit,
            audit_path=audit_path,
            regulation=regulation,
            guardrails=guardrails,
            pii_action=pii_action,
            allowed_scopes=allowed_scopes,
        )

        engine = GuardrailEngine(
            guardrail_names=cfg.guardrails,
            pii_action=cfg.pii_action,
            allowed_scopes=cfg.allowed_scopes,
        )

        _agent_name = agent_name or fn.__qualname__

        if inspect.iscoroutinefunction(fn):
            @functools.wraps(fn)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                return await _execute_async(
                    fn, args, kwargs, cfg, engine, _agent_name
                )

            return async_wrapper  # type: ignore[return-value]
        else:
            @functools.wraps(fn)
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                return _execute_sync(
                    fn, args, kwargs, cfg, engine, _agent_name
                )

            return sync_wrapper  # type: ignore[return-value]

    if _fn is not None:
        return decorator(_fn)
    return decorator


def _execute_sync(
    fn: Callable[..., Any],
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
    cfg: GuardConfig,
    engine: GuardrailEngine,
    agent_name: str,
) -> Any:
    """Synchronous execution path with fail-open semantics."""
    event = DecisionEvent(
        agent_name=agent_name,
        function_name=fn.__name__,
        module=fn.__module__,
        regulation=cfg.regulation,
    )
    ctx = DecisionContext(event_id=event.event_id)
    result = _SENTINEL
    start = time.perf_counter()

    try:
        # Serialize input
        event.input_data = _serialize_args(fn, args, kwargs)

        # Pre-guardrails (may raise GuardrailViolation)
        pre_results = engine.check_input(event.input_data, fn.__qualname__)
        event.guardrail_results.extend(pre_results)

        # Execute with context active
        with ctx:
            result = fn(*args, **kwargs)

        # Post-guardrails (warn/redact only)
        post_results = engine.check_output(result)
        event.guardrail_results.extend(post_results)

        event.output_summary = _summarize_output(result)

        # Collect context data
        event.tools_used = ctx.tools
        event.reasoning = ctx.reasoning
        event.model = ctx.model
        event.tokens_used = ctx.tokens_used
        event.parent_id = ctx.parent_id

        return result

    except GuardrailViolation:
        event.error = "guardrail_violation"
        raise

    except Exception:
        # fail-open: if fn already ran, return its result
        if result is not _SENTINEL:
            return result
        # fn never ran — call unmonitored
        return fn(*args, **kwargs)

    finally:
        event.duration_ms = (time.perf_counter() - start) * 1000
        try:
            trail = get_trail(cfg.audit_backend, cfg.audit_path)
            trail.emit(event)
        except Exception:
            pass  # audit never crashes


async def _execute_async(
    fn: Callable[..., Any],
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
    cfg: GuardConfig,
    engine: GuardrailEngine,
    agent_name: str,
) -> Any:
    """Async execution path with fail-open semantics."""
    event = DecisionEvent(
        agent_name=agent_name,
        function_name=fn.__name__,
        module=fn.__module__,
        regulation=cfg.regulation,
    )
    ctx = DecisionContext(event_id=event.event_id)
    result = _SENTINEL
    start = time.perf_counter()

    try:
        event.input_data = _serialize_args(fn, args, kwargs)

        pre_results = engine.check_input(event.input_data, fn.__qualname__)
        event.guardrail_results.extend(pre_results)

        with ctx:
            result = await fn(*args, **kwargs)

        post_results = engine.check_output(result)
        event.guardrail_results.extend(post_results)

        event.output_summary = _summarize_output(result)
        event.tools_used = ctx.tools
        event.reasoning = ctx.reasoning
        event.model = ctx.model
        event.tokens_used = ctx.tokens_used
        event.parent_id = ctx.parent_id

        return result

    except GuardrailViolation:
        event.error = "guardrail_violation"
        raise

    except Exception:
        if result is not _SENTINEL:
            return result
        return await fn(*args, **kwargs)

    finally:
        event.duration_ms = (time.perf_counter() - start) * 1000
        try:
            trail = get_trail(cfg.audit_backend, cfg.audit_path)
            trail.emit(event)
        except Exception:
            pass
