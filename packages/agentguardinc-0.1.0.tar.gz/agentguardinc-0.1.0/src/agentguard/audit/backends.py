"""Audit backends — write DecisionEvents to various sinks."""

from __future__ import annotations

import json
import sqlite3
import sys
import threading
from pathlib import Path
from typing import Any, Protocol


class AuditBackend(Protocol):
    """Protocol for audit backends."""

    def write(self, event_dict: dict[str, Any]) -> None: ...
    def query(self, limit: int = 100, **filters: Any) -> list[dict[str, Any]]: ...


class StdoutBackend:
    """Write events as JSON to stdout."""

    def write(self, event_dict: dict[str, Any]) -> None:
        line = json.dumps(event_dict, default=str, ensure_ascii=False)
        sys.stderr.write(f"[agentguard] {line}\n")

    def query(self, limit: int = 100, **filters: Any) -> list[dict[str, Any]]:
        return []  # stdout is write-only


class JSONFileBackend:
    """Append events as JSON lines to a file."""

    def __init__(self, path: str | Path = "agentguard_audit.jsonl") -> None:
        self.path = Path(path)
        self._lock = threading.Lock()

    def write(self, event_dict: dict[str, Any]) -> None:
        line = json.dumps(event_dict, default=str, ensure_ascii=False)
        with self._lock:
            with open(self.path, "a", encoding="utf-8") as f:
                f.write(line + "\n")

    def query(self, limit: int = 100, **filters: Any) -> list[dict[str, Any]]:
        if not self.path.exists():
            return []
        results: list[dict[str, Any]] = []
        with open(self.path, encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                record = json.loads(line)
                if _matches(record, filters):
                    results.append(record)
                    if len(results) >= limit:
                        break
        return results


class SQLiteBackend:
    """Write events to a SQLite database (WAL mode, per-thread connections)."""

    def __init__(self, path: str | Path = "agentguard_audit.db") -> None:
        self.path = str(path)
        self._local = threading.local()
        # Initialize schema on first construction
        conn = self._get_conn()
        conn.execute(
            """CREATE TABLE IF NOT EXISTS events (
                event_id TEXT PRIMARY KEY,
                timestamp TEXT,
                agent_name TEXT,
                function_name TEXT,
                risk_level TEXT,
                regulation TEXT,
                data TEXT
            )"""
        )
        conn.execute("CREATE INDEX IF NOT EXISTS idx_ts ON events(timestamp)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_agent ON events(agent_name)")
        conn.commit()

    def _get_conn(self) -> sqlite3.Connection:
        conn = getattr(self._local, "conn", None)
        if conn is None:
            conn = sqlite3.connect(self.path)
            conn.execute("PRAGMA journal_mode=WAL")
            conn.row_factory = sqlite3.Row
            self._local.conn = conn
        return conn

    def write(self, event_dict: dict[str, Any]) -> None:
        conn = self._get_conn()
        conn.execute(
            "INSERT OR REPLACE INTO events (event_id, timestamp, agent_name, function_name, risk_level, regulation, data) "
            "VALUES (?, ?, ?, ?, ?, ?, ?)",
            (
                event_dict.get("event_id", ""),
                event_dict.get("timestamp", ""),
                event_dict.get("agent_name", ""),
                event_dict.get("function_name", ""),
                event_dict.get("risk_level", ""),
                event_dict.get("regulation", ""),
                json.dumps(event_dict, default=str, ensure_ascii=False),
            ),
        )
        conn.commit()

    def query(self, limit: int = 100, **filters: Any) -> list[dict[str, Any]]:
        conn = self._get_conn()
        conditions: list[str] = []
        params: list[str] = []
        for key, value in filters.items():
            if key in ("agent_name", "function_name", "risk_level", "regulation"):
                conditions.append(f"{key} = ?")
                params.append(str(value))
        where = " AND ".join(conditions) if conditions else "1=1"
        rows = conn.execute(
            f"SELECT data FROM events WHERE {where} ORDER BY timestamp DESC LIMIT ?",
            (*params, limit),
        ).fetchall()
        return [json.loads(row[0]) for row in rows]


def create_backend(name: str, path: str = "") -> AuditBackend:
    """Factory function for audit backends."""
    if name == "stdout":
        return StdoutBackend()
    elif name == "jsonfile":
        return JSONFileBackend(path=path or "agentguard_audit.jsonl")
    elif name == "sqlite":
        return SQLiteBackend(path=path or "agentguard_audit.db")
    else:
        raise ValueError(f"Unknown audit backend: {name!r}")


def _matches(record: dict[str, Any], filters: dict[str, Any]) -> bool:
    """Check if record matches all filters."""
    for key, value in filters.items():
        if record.get(key) != value:
            return False
    return True
