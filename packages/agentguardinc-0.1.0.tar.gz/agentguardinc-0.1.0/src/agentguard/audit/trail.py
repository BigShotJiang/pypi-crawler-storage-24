"""Audit trail — async event emission via background thread."""

from __future__ import annotations

import atexit
import logging
import queue
import threading
from typing import Any

from ..event import DecisionEvent
from .backends import AuditBackend, create_backend

logger = logging.getLogger("agentguard.audit")

_QUEUE_SIZE = 10_000
_SENTINEL = object()

# Global registry: one trail per backend config hash
_trails: dict[str, AuditTrail] = {}
_trails_lock = threading.Lock()


class AuditTrail:
    """Non-blocking audit event emitter.

    Uses a daemon thread and bounded queue. Never blocks the caller.
    Events that can't be enqueued (full queue) are dropped with a warning.
    """

    def __init__(self, backend: AuditBackend) -> None:
        self._backend = backend
        self._queue: queue.Queue[DecisionEvent | object] = queue.Queue(
            maxsize=_QUEUE_SIZE
        )
        self._thread = threading.Thread(
            target=self._worker, daemon=True, name="agentguard-audit"
        )
        self._thread.start()
        atexit.register(self.flush)

    def emit(self, event: DecisionEvent) -> None:
        """Enqueue an event for async writing. Never blocks or raises."""
        try:
            self._queue.put_nowait(event)
        except queue.Full:
            logger.warning("Audit queue full, dropping event %s", event.event_id)

    def flush(self, timeout: float = 5.0) -> None:
        """Drain the queue and stop the worker. Called at process exit."""
        try:
            self._queue.put(_SENTINEL, timeout=timeout)
        except queue.Full:
            return
        self._thread.join(timeout=timeout)

    def _worker(self) -> None:
        """Background worker — drain queue and write to backend."""
        while True:
            item = self._queue.get()
            if item is _SENTINEL:
                break
            if isinstance(item, DecisionEvent):
                self._safe_write(item)

    def _safe_write(self, event: DecisionEvent) -> None:
        """Write event to backend, swallowing any exception."""
        try:
            self._backend.write(event.to_dict())
        except Exception:
            logger.exception("Audit write failed for event %s", event.event_id)

    @property
    def backend(self) -> AuditBackend:
        return self._backend


def get_or_create(
    backend_name: str = "stdout", backend_path: str = ""
) -> AuditTrail:
    """Get or create a singleton AuditTrail for the given backend config."""
    key = f"{backend_name}:{backend_path}"
    with _trails_lock:
        if key not in _trails:
            backend = create_backend(backend_name, backend_path)
            _trails[key] = AuditTrail(backend)
        return _trails[key]
