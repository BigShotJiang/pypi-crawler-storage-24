"""AgentGuard CLI — classify, check, trail, docs."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path


def main(argv: list[str] | None = None) -> int:
    """Entry point for `agentguard` CLI."""
    parser = argparse.ArgumentParser(
        prog="agentguard",
        description="AgentGuard — compliance infrastructure for AI agents",
    )
    parser.add_argument(
        "--version", action="store_true", help="Show version and exit"
    )
    sub = parser.add_subparsers(dest="command")

    # classify
    p_classify = sub.add_parser("classify", help="Classify risk level of a Python file")
    p_classify.add_argument("file", help="Python file to classify")
    p_classify.add_argument("--json", dest="as_json", action="store_true", help="Output as JSON")

    # check
    p_check = sub.add_parser("check", help="Check compliance of a Python file")
    p_check.add_argument("file", help="Python file to check")
    p_check.add_argument("--regulation", default="eu-ai-act", help="Regulation to check against")

    # trail
    p_trail = sub.add_parser("trail", help="Query the audit trail")
    p_trail.add_argument("--backend", default="jsonfile", help="Audit backend (jsonfile|sqlite)")
    p_trail.add_argument("--path", default="", help="Path to audit file/database")
    p_trail.add_argument("--limit", type=int, default=20, help="Max events to show")
    p_trail.add_argument("--agent", default="", help="Filter by agent name")

    # docs
    p_docs = sub.add_parser("docs", help="Generate Annex IV documentation")
    p_docs.add_argument("--name", default="AI Agent System", help="System name")
    p_docs.add_argument("--output", default="", help="Output file (default: stdout)")
    p_docs.add_argument("--trail-path", default="", help="Path to audit trail for inclusion")

    args = parser.parse_args(argv)

    if args.version:
        from ._version import __version__
        print(f"agentguard {__version__}")
        return 0

    if args.command == "classify":
        return _cmd_classify(args)
    elif args.command == "check":
        return _cmd_check(args)
    elif args.command == "trail":
        return _cmd_trail(args)
    elif args.command == "docs":
        return _cmd_docs(args)
    else:
        parser.print_help()
        return 0


def _cmd_classify(args: argparse.Namespace) -> int:
    from .classify import RiskClassifier

    classifier = RiskClassifier()
    result = classifier.classify_file(args.file)

    if args.as_json:
        from dataclasses import asdict
        print(json.dumps(asdict(result), indent=2))
    else:
        print(f"File: {result.file_path}")
        print(f"Risk Level: {result.risk_level.upper()}")
        print(f"Score: {result.score}")
        if result.findings:
            print("\nFindings:")
            for f in result.findings:
                print(f"  - {f}")
        if result.agent_frameworks:
            print(f"\nAgent frameworks: {', '.join(result.agent_frameworks)}")
        if result.dangerous_calls:
            print(f"Dangerous calls: {', '.join(result.dangerous_calls)}")
        print(f"\nFunctions: {result.function_count}, Classes: {result.class_count}")
        print(f"Monitored: {'Yes' if result.has_monitor_decorator else 'No'}")
    return 0


def _cmd_check(args: argparse.Namespace) -> int:
    from .classify import RiskClassifier
    from .regulations.eu_ai_act import EUAIActRegulation

    classifier = RiskClassifier()
    cr = classifier.classify_file(args.file)

    metadata = {
        "purpose": cr.file_path,
        "frameworks": cr.agent_frameworks,
        "autonomy_markers": cr.autonomy_markers,
        "dangerous_calls": cr.dangerous_calls,
    }

    reg = EUAIActRegulation()
    result = reg.check_compliance(metadata)

    print(f"Regulation: {result.regulation}")
    print(f"Risk Level: {result.risk_level.upper()}")
    print(f"Compliant: {'Yes' if result.compliant else 'No'}")
    if result.findings:
        print("\nFindings:")
        for f in result.findings:
            print(f"  - {f}")
    if result.recommendations:
        print("\nRecommendations:")
        for r in result.recommendations:
            print(f"  - {r}")
    return 0


def _cmd_trail(args: argparse.Namespace) -> int:
    from .audit.backends import create_backend

    filters = {}
    if args.agent:
        filters["agent_name"] = args.agent

    try:
        backend = create_backend(args.backend, args.path)
    except ValueError as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1

    events = backend.query(limit=args.limit, **filters)
    if not events:
        print("No audit events found.")
        return 0

    for evt in events:
        ts = evt.get("timestamp", "")[:19]
        fn = evt.get("function_name", "unknown")
        agent = evt.get("agent_name", "")
        dur = evt.get("duration_ms", 0)
        risk = evt.get("risk_level", "")
        err = evt.get("error", "")
        status = "ERR" if err else "OK"
        print(f"  {ts}  {agent:20s}  {fn:20s}  {dur:6.1f}ms  {risk:8s}  {status}")

    print(f"\nTotal: {len(events)} events")
    return 0


def _cmd_docs(args: argparse.Namespace) -> int:
    from .docs.generator import generate_annex_iv

    # Try to load audit trail if path provided
    audit_events: list[dict] = []
    if args.trail_path:
        from .audit.backends import create_backend
        try:
            if args.trail_path.endswith(".db"):
                backend = create_backend("sqlite", args.trail_path)
            else:
                backend = create_backend("jsonfile", args.trail_path)
            audit_events = backend.query(limit=50)
        except Exception:
            pass

    doc = generate_annex_iv(
        system_name=args.name,
        audit_events=audit_events,
        event_count=len(audit_events),
    )

    if args.output:
        Path(args.output).write_text(doc, encoding="utf-8")
        print(f"Documentation written to {args.output}")
    else:
        print(doc)
    return 0


if __name__ == "__main__":
    sys.exit(main())
