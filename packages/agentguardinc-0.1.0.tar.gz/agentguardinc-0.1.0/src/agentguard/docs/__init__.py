"""Documentation generation subsystem."""
