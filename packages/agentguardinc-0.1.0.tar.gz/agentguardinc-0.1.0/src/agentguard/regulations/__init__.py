"""Regulations subsystem."""

from .base import BaseRegulation, ComplianceResult
from .eu_ai_act import EUAIActRegulation

__all__ = ["BaseRegulation", "ComplianceResult", "EUAIActRegulation"]
