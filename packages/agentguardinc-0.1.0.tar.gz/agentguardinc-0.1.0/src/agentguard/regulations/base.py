"""Base regulation ABC and compliance result."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any


@dataclass(slots=True)
class ComplianceResult:
    """Result of a compliance check against a regulation."""

    regulation: str
    compliant: bool
    risk_level: str = ""  # low | medium | high | critical
    findings: list[str] = field(default_factory=list)
    recommendations: list[str] = field(default_factory=list)
    annex_references: list[str] = field(default_factory=list)


class BaseRegulation(ABC):
    """Abstract base for regulation implementations."""

    name: str = ""

    @abstractmethod
    def classify_risk(self, metadata: dict[str, Any]) -> str:
        """Classify risk level based on agent metadata."""
        ...

    @abstractmethod
    def check_compliance(self, metadata: dict[str, Any]) -> ComplianceResult:
        """Check compliance against this regulation."""
        ...
