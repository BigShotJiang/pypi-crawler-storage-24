"""EU AI Act compliance — Annex III high-risk categories and Annex IV documentation."""

from __future__ import annotations

from typing import Any

from .base import BaseRegulation, ComplianceResult

# Annex III high-risk AI system categories mapped to keywords
_ANNEX_III_CATEGORIES: dict[str, list[str]] = {
    "biometric": [
        "face", "facial", "fingerprint", "biometric", "recognition",
        "identification", "emotion", "gait",
    ],
    "critical_infrastructure": [
        "infrastructure", "energy", "water", "traffic", "transport",
        "power", "grid", "pipeline", "scada",
    ],
    "education": [
        "education", "student", "grade", "admission", "exam",
        "learning", "school", "university",
    ],
    "employment": [
        "hiring", "recruitment", "hr", "employee", "candidate",
        "resume", "interview", "termination", "promotion", "performance_review",
    ],
    "essential_services": [
        "credit", "insurance", "loan", "mortgage", "benefit",
        "social_security", "healthcare", "emergency",
    ],
    "law_enforcement": [
        "police", "law_enforcement", "crime", "criminal", "surveillance",
        "parole", "recidivism", "profiling",
    ],
    "migration": [
        "migration", "asylum", "border", "visa", "immigration",
        "refugee", "passport",
    ],
    "justice": [
        "court", "judge", "legal", "sentencing", "judicial",
        "litigation", "verdict",
    ],
}

# Autonomy indicators that increase risk level
_AUTONOMY_MARKERS: list[str] = [
    "autonomous", "self-driving", "auto-approve", "auto-execute",
    "no-human-oversight", "unsupervised", "automated-decision",
]


class EUAIActRegulation(BaseRegulation):
    """EU AI Act (Regulation 2024/1689) compliance checker."""

    name = "eu-ai-act"

    def classify_risk(self, metadata: dict[str, Any]) -> str:
        """Classify AI system risk level per EU AI Act.

        Returns: minimal | low | high | unacceptable
        """
        text = _metadata_to_text(metadata)

        # Check for unacceptable practices (Article 5)
        if _has_unacceptable_practice(text):
            return "unacceptable"

        # Check Annex III high-risk categories
        matched_categories = self._match_categories(text)
        has_autonomy = any(marker in text for marker in _AUTONOMY_MARKERS)

        if matched_categories:
            return "high"
        if has_autonomy:
            return "high"

        # General-purpose AI → limited risk at minimum
        if any(kw in text for kw in ("llm", "gpt", "claude", "gemini", "general-purpose", "foundation")):
            return "low"

        return "minimal"

    def check_compliance(self, metadata: dict[str, Any]) -> ComplianceResult:
        """Check compliance with EU AI Act requirements."""
        risk = self.classify_risk(metadata)
        findings: list[str] = []
        recommendations: list[str] = []
        annex_refs: list[str] = []

        if risk == "unacceptable":
            findings.append("System matches prohibited AI practices (Article 5)")
            recommendations.append("This AI system may be prohibited under EU AI Act Article 5")
            annex_refs.append("Article 5")
            return ComplianceResult(
                regulation=self.name,
                compliant=False,
                risk_level=risk,
                findings=findings,
                recommendations=recommendations,
                annex_references=annex_refs,
            )

        if risk == "high":
            matched = self._match_categories(_metadata_to_text(metadata))
            for cat in matched:
                findings.append(f"Matches Annex III category: {cat}")
                annex_refs.append(f"Annex III - {cat}")

            # Check for required documentation (Annex IV)
            if not metadata.get("documentation"):
                recommendations.append(
                    "High-risk AI system requires technical documentation per Annex IV"
                )
                annex_refs.append("Annex IV")
            if not metadata.get("risk_management"):
                recommendations.append(
                    "High-risk AI system requires risk management system per Article 9"
                )
            if not metadata.get("human_oversight"):
                recommendations.append(
                    "High-risk AI system requires human oversight measures per Article 14"
                )
            if not metadata.get("audit_trail"):
                recommendations.append(
                    "High-risk AI system requires automatic logging per Article 12"
                )

            compliant = len(recommendations) == 0
        else:
            compliant = True
            if risk == "low":
                findings.append("System classified as limited risk")
                recommendations.append(
                    "Ensure transparency obligations are met (Article 50)"
                )
            else:
                findings.append("System classified as minimal risk")

        return ComplianceResult(
            regulation=self.name,
            compliant=compliant,
            risk_level=risk,
            findings=findings,
            recommendations=recommendations,
            annex_references=annex_refs,
        )

    def _match_categories(self, text: str) -> list[str]:
        """Match text against Annex III categories."""
        matched = []
        for category, keywords in _ANNEX_III_CATEGORIES.items():
            if any(kw in text for kw in keywords):
                matched.append(category)
        return matched


def _metadata_to_text(metadata: dict[str, Any]) -> str:
    """Flatten metadata dict to lowercase text for keyword matching."""
    parts: list[str] = []
    for key, value in metadata.items():
        parts.append(str(key).lower())
        if isinstance(value, (list, tuple)):
            parts.extend(str(v).lower() for v in value)
        else:
            parts.append(str(value).lower())
    return " ".join(parts)


def _has_unacceptable_practice(text: str) -> bool:
    """Check for prohibited AI practices per Article 5."""
    prohibited = [
        "social_scoring",
        "social scoring",
        "subliminal manipulation",
        "exploitation of vulnerabilities",
        "real-time biometric mass surveillance",
    ]
    return any(p in text for p in prohibited)
