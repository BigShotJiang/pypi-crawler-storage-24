"""PII detection guardrail — regex-based, zero dependencies."""

from __future__ import annotations

import re
from typing import Any

from ..event import GuardrailResult


# Compiled at import time for performance (~0.5ms per check).
_PII_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    ("email", re.compile(r"[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z]{2,}")),
    ("phone", re.compile(r"\b(?:\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b")),
    ("ssn", re.compile(r"\b\d{3}-\d{2}-\d{4}\b")),
    (
        "credit_card",
        re.compile(r"\b(?:\d[ -]*?){13,19}\b"),
    ),
    ("ip_address", re.compile(r"\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b")),
]

_REDACT_PLACEHOLDER = "[REDACTED]"


class PIIGuardrail:
    """Detect PII in text using compiled regex patterns.

    Actions:
        block  — raise GuardrailViolation (pre-execution only)
        warn   — return result with passed=False, don't block
        redact — replace matched PII with [REDACTED]
    """

    name = "pii"

    def __init__(self, action: str = "warn") -> None:
        if action not in ("block", "warn", "redact"):
            raise ValueError(f"Invalid PII action: {action!r}")
        self.action = action

    def check(self, text: str) -> GuardrailResult:
        """Check *text* for PII. Returns a GuardrailResult."""
        found: list[str] = []
        for label, pattern in _PII_PATTERNS:
            if pattern.search(text):
                found.append(label)
        if found:
            return GuardrailResult(
                name=self.name,
                passed=False,
                action=self.action,
                detail=f"PII detected: {', '.join(found)}",
            )
        return GuardrailResult(name=self.name, passed=True)

    def redact(self, text: str) -> str:
        """Replace PII matches with [REDACTED]."""
        result = text
        for _, pattern in _PII_PATTERNS:
            result = pattern.sub(_REDACT_PLACEHOLDER, result)
        return result

    @staticmethod
    def _extract_text(data: Any) -> str:
        """Best-effort extraction of text from input data."""
        if isinstance(data, str):
            return data
        if isinstance(data, dict):
            return " ".join(str(v) for v in data.values())
        return str(data)
