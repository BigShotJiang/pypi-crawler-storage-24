"""Guardrail engine — orchestrates all guardrail checks."""

from __future__ import annotations

from typing import Any

from ..event import GuardrailResult
from ..exceptions import GuardrailViolation
from .pii import PIIGuardrail
from .scope import ScopeGuardrail


class GuardrailEngine:
    """Runs configured guardrails in order.

    Pre-execution: may raise GuardrailViolation (action=block).
    Post-execution: warn/redact only — never block (side effects already happened).
    """

    def __init__(
        self,
        guardrail_names: list[str] | None = None,
        pii_action: str = "warn",
        allowed_scopes: list[str] | None = None,
    ) -> None:
        self._guardrails: dict[str, PIIGuardrail | ScopeGuardrail] = {}
        names = guardrail_names or []
        if "pii" in names:
            self._guardrails["pii"] = PIIGuardrail(action=pii_action)
        if "scope" in names:
            self._guardrails["scope"] = ScopeGuardrail(allowed=allowed_scopes)

    def check_input(
        self, input_data: dict[str, Any], function_name: str = ""
    ) -> list[GuardrailResult]:
        """Run pre-execution guardrail checks.

        Raises GuardrailViolation if any guardrail has action=block.
        """
        results: list[GuardrailResult] = []

        # PII check on input
        pii = self._guardrails.get("pii")
        if pii is not None:
            assert isinstance(pii, PIIGuardrail)
            text = pii._extract_text(input_data)
            result = pii.check(text)
            results.append(result)
            if not result.passed and result.action == "block":
                raise GuardrailViolation(
                    guardrail="pii",
                    action="block",
                    detail=result.detail,
                )

        # Scope check
        scope_guard = self._guardrails.get("scope")
        if scope_guard is not None and function_name:
            assert isinstance(scope_guard, ScopeGuardrail)
            result = scope_guard.check(function_name)
            results.append(result)
            if not result.passed and result.action == "block":
                raise GuardrailViolation(
                    guardrail="scope",
                    action="block",
                    detail=result.detail,
                )

        return results

    def check_output(self, output: Any) -> list[GuardrailResult]:
        """Run post-execution guardrail checks.

        Never raises — post-execution can only warn or redact.
        """
        results: list[GuardrailResult] = []
        pii = self._guardrails.get("pii")
        if pii is not None:
            assert isinstance(pii, PIIGuardrail)
            text = pii._extract_text(output)
            result = pii.check(text)
            if not result.passed:
                # Downgrade any block to warn for post-execution
                result = GuardrailResult(
                    name=result.name,
                    passed=result.passed,
                    action="warn" if result.action == "block" else result.action,
                    detail=result.detail,
                )
            results.append(result)
        return results

    def redact_output(self, output: str) -> str:
        """Apply redaction to output text if PII guardrail is in redact mode."""
        pii = self._guardrails.get("pii")
        if pii is not None and isinstance(pii, PIIGuardrail) and pii.action == "redact":
            return pii.redact(output)
        return output
