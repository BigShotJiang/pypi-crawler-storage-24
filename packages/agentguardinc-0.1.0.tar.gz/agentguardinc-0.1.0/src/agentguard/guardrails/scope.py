"""Scope guardrail — restricts agent to allowed operations."""

from __future__ import annotations

from ..event import GuardrailResult


class ScopeGuardrail:
    """Check whether a function/tool is within allowed scopes.

    Uses fast set membership (~0.01ms per check).
    """

    name = "scope"

    def __init__(self, allowed: list[str] | set[str] | None = None) -> None:
        self.allowed: set[str] = set(allowed) if allowed else set()

    def check(self, scope: str) -> GuardrailResult:
        """Check if *scope* is in the allowed set.

        If no allowed scopes configured, passes everything (open policy).
        """
        if not self.allowed:
            return GuardrailResult(name=self.name, passed=True)
        if scope in self.allowed:
            return GuardrailResult(name=self.name, passed=True)
        return GuardrailResult(
            name=self.name,
            passed=False,
            action="block",
            detail=f"Scope {scope!r} not in allowed set",
        )
