"""Example: AI hiring agent — high-risk under EU AI Act."""

from agentguard import monitor, ctx


@monitor(
    regulation="eu-ai-act",
    audit="jsonfile",
    audit_path="examples/audit_trail.jsonl",
    guardrails=["pii"],
    pii_action="warn",
    agent_name="hiring-agent",
)
def screen_candidate(name: str, resume: str) -> dict:
    """Screen a job candidate based on their resume."""
    ctx.log_model("gpt-4", tokens=500)
    ctx.log_reasoning(
        f"Evaluating candidate {name} based on keyword matching and experience extraction"
    )
    ctx.log_tool("resume_parser", input=resume[:100])
    ctx.log_tool("skill_matcher", skills=["python", "ml", "data"])

    return {
        "candidate": name,
        "score": 85,
        "recommendation": "proceed_to_interview",
    }


@monitor(
    audit="jsonfile",
    audit_path="examples/audit_trail.jsonl",
    agent_name="summarizer",
)
def summarize_results(candidates: list[dict]) -> str:
    """Summarize screening results."""
    ctx.log_reasoning("Aggregating candidate scores")
    top = sorted(candidates, key=lambda c: c["score"], reverse=True)
    return f"Top candidate: {top[0]['candidate']} (score: {top[0]['score']})"


if __name__ == "__main__":
    results = []
    for name, resume in [
        ("Alice Chen", "10 years Python, ML at Google, PhD in CS"),
        ("Bob Smith", "5 years Java, backend at Stripe, MS in SE"),
        ("Carol Wu", "8 years Python, data science at Meta, PhD in Stats"),
    ]:
        results.append(screen_candidate(name, resume))

    summary = summarize_results(results)
    print(f"\n{summary}")
