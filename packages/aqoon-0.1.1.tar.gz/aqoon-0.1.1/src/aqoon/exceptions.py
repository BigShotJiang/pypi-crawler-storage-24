"""Typed exceptions for the aqoon SDK."""

from __future__ import annotations


class AqoonError(Exception):
    """Base exception for all aqoon API errors."""

    def __init__(
        self,
        message: str,
        status_code: int | None = None,
        response: object = None,
    ):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.response = response


class AuthenticationError(AqoonError):
    """401 — Invalid or missing API key."""


class ForbiddenError(AqoonError):
    """403 — Insufficient permissions."""


class NotFoundError(AqoonError):
    """404 — Resource not found."""


class ValidationError(AqoonError):
    """400 — Invalid request data."""

    def __init__(self, message: str, errors: dict | None = None, **kwargs):
        super().__init__(message, **kwargs)
        self.errors = errors or {}


class RateLimitError(AqoonError):
    """429 — Rate limit exceeded."""

    def __init__(self, message: str, retry_after: float | None = None, **kwargs):
        super().__init__(message, **kwargs)
        self.retry_after = retry_after


class ServerError(AqoonError):
    """5xx — Server-side error."""
