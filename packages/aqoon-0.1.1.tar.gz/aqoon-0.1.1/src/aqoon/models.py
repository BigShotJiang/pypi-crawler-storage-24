"""Response types for the aqoon SDK."""

from __future__ import annotations

from typing import TypedDict  # noqa: TYP001


class Collection(TypedDict):
    uuid: str
    name: str
    slug: str
    description: str
    document_count: int
    total_chunks: int
    is_public: bool
    is_subscribed: bool
    created_at: str


class Document(TypedDict):
    uuid: str
    title: str
    source_type: str
    status: str
    tags: list[str]
    chunks_count: int
    original_filename: str
    file_size: int
    collection_name: str
    collection_slug: str
    created_at: str


class Chunk(TypedDict):
    chunk_id: int  # noqa: A003
    content: str
    chunk_index: int
    embedding_model: str


class DocumentDetail(Document):
    content_text: str
    error_message: str
    chunks: list[Chunk]


class SearchResult(TypedDict):
    content: str
    title: str
    document_id: str
    collection_name: str
    tags: list[str]
    score: float


class SearchResponse(TypedDict):
    query: str
    count: int
    results: list[SearchResult]


class RateTier(TypedDict):
    name: str
    requests_per_minute: int
    requests_per_day: int
    requests_per_month: int


class APIKeyInfo(TypedDict):
    uuid: str
    name: str
    prefix: str
    is_active: bool
    is_full_access: bool
    rate_tier: RateTier | None
    last_used_at: str | None
    expires_at: str | None
    created_at: str
    collections: list[str]


class APIKeyCreated(TypedDict):
    uuid: str
    name: str
    prefix: str
    key: str
    is_full_access: bool
    created_at: str


class UsageStats(TypedDict):
    total_requests: int
    total_errors: int
    avg_response_time_ms: float
    daily: list[dict]
