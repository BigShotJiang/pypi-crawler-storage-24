"""Framework integrations for aqoon.

Install optional extras to use:
    pip install aqoon[langchain]
    pip install aqoon[llamaindex]
    pip install aqoon[haystack]
    pip install aqoon[all]
"""
