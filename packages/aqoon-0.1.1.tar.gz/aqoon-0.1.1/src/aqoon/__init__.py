"""aqoon — Python SDK for the aqoon knowledge-as-a-service API."""

from aqoon.client import Aqoon
from aqoon.exceptions import (
    AqoonError,
    AuthenticationError,
    ForbiddenError,
    NotFoundError,
    RateLimitError,
    ServerError,
    ValidationError,
)

__all__ = [
    "Aqoon",
    "AqoonError",
    "AuthenticationError",
    "ForbiddenError",
    "NotFoundError",
    "RateLimitError",
    "ServerError",
    "ValidationError",
]

__version__ = "0.1.1"
