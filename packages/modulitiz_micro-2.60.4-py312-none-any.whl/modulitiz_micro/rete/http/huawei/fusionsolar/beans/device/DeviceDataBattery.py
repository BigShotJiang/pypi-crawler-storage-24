from modulitiz_micro.rete.http.huawei.fusionsolar.beans.device.batteryunitinfo.BatteryUnitInfo import BatteryUnitInfo
from modulitiz_micro.rete.http.huawei.fusionsolar.enums.BatteryStatusEnum import BatteryStatusEnum
from modulitiz_nano.EnumUtil import EnumUtil


class DeviceDataBattery(object):
	def __init__(self,diz:dict):
		self.battery_status:BatteryStatusEnum=EnumUtil.checkValueIn(int(diz["battery_status"]),BatteryStatusEnum)
		self.max_charge_power: float = diz["max_charge_power"]
		self.max_discharge_power: float = diz["max_discharge_power"]
		
		self.ch_discharge_power: float = diz["ch_discharge_power"]
		"""Instant Kwh given to (+) or taken from (-) battery"""
		
		self.busbar_u: int = diz["busbar_u"]
		
		self.battery_soc: float = diz["battery_soc"]
		"""Percentage of battery charge remaining"""
		
		self.battery_soh: float = diz["battery_soh"]
		self.ch_discharge_model: float = diz["ch_discharge_model"]
		self.charge_cap: float = diz["charge_cap"]
		self.discharge_cap: float = diz["discharge_cap"]
		self.rated_capacity: float = diz["rated_capacity"]
		
		self.run_state=diz["run_state"]==1
		"""State (0/False: Disconnected, 1/True: Connected)"""
		
		self.battery_unit_info=BatteryUnitInfo(diz.get("battery_unit_info",{}))
