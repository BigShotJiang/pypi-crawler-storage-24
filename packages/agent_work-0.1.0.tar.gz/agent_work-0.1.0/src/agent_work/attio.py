from __future__ import annotations

import httpx

from agent_work.config import ATTIO_KEY


class AttioClient:
    """Sync REST client for the Attio CRM API (v2)."""

    def __init__(self, api_key: str = ATTIO_KEY) -> None:
        self._client = httpx.Client(
            base_url="https://api.attio.com/v2",
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=30,
        )

    def __enter__(self) -> AttioClient:
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    def close(self) -> None:
        self._client.close()

    def request(self, method: str, path: str, **kwargs) -> dict:
        resp = self._client.request(method, path, **kwargs)
        resp.raise_for_status()
        return resp.json()

    # --- People ---

    def list_people(self, **filters) -> dict:
        body = {}
        if filters:
            body["filter"] = filters
        return self.request("POST", "/objects/people/records/query", json=body)

    def get_person(self, person_id: str) -> dict:
        return self.request("GET", f"/objects/people/records/{person_id}")

    # --- Companies ---

    def list_companies(self, **filters) -> dict:
        body = {}
        if filters:
            body["filter"] = filters
        return self.request("POST", "/objects/companies/records/query", json=body)

    def get_company(self, company_id: str) -> dict:
        return self.request("GET", f"/objects/companies/records/{company_id}")

    # --- Lists ---

    def list_lists(self) -> dict:
        return self.request("GET", "/lists")

    # --- Notes ---

    def list_notes(self) -> dict:
        return self.request("GET", "/notes")

    def create_note(self, parent_object: str, parent_record_id: str, title: str, content: str) -> dict:
        return self.request(
            "POST",
            "/notes",
            json={
                "parent_object": parent_object,
                "parent_record_id": parent_record_id,
                "title": title,
                "format": "plaintext",
                "content": content,
            },
        )

    # --- Tasks ---

    def list_tasks(self) -> dict:
        return self.request("GET", "/tasks")

    def create_task(self, content: str, **kwargs) -> dict:
        body = {"content": content, **kwargs}
        return self.request("POST", "/tasks", json=body)
