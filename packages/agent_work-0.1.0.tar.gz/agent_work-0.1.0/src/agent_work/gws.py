import json
import subprocess


class GWS:
    """Wrapper around the `gws` CLI for Google Workspace.

    CLI syntax: gws <service> <resource> <method> [flags]
    """

    def __init__(self, binary: str = "gws") -> None:
        self._bin = binary

    def _run(self, *args: str) -> dict | list:
        result = subprocess.run(
            [self._bin, *args, "--format", "json"],
            capture_output=True,
            text=True,
            check=True,
        )
        return json.loads(result.stdout)

    def drive_list(self, params: dict | None = None) -> dict | list:
        args = ["drive", "files", "list"]
        if params:
            args.extend(["--params", json.dumps(params)])
        return self._run(*args)

    def gmail_list(self, params: dict | None = None) -> dict | list:
        args = ["gmail", "users", "messages", "list", "--params", json.dumps({"userId": "me", **(params or {})})]
        return self._run(*args)

    def calendar_list(self, params: dict | None = None) -> dict | list:
        args = ["calendar", "calendarList", "list"]
        if params:
            args.extend(["--params", json.dumps(params)])
        return self._run(*args)

    def sheets_get(self, spreadsheet_id: str, params: dict | None = None) -> dict | list:
        p = {"spreadsheetId": spreadsheet_id, **(params or {})}
        args = ["sheets", "spreadsheets", "get", "--params", json.dumps(p)]
        return self._run(*args)

    def raw(self, *args: str) -> dict | list:
        return self._run(*args)
