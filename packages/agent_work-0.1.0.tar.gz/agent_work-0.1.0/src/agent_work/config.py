from pathlib import Path

from dotenv import load_dotenv
import os

load_dotenv(Path(__file__).resolve().parents[2] / ".env")

# Required
ATTIO_KEY: str = os.environ["ATTIO_KEY"]
CLEARFEED_API_KEY: str = os.environ["CLEARFEED_API_KEY"]
UNIPILE_DSN: str = os.environ["UNIPILE_DSN"]
UNIPILE_ACCESS_TOKEN: str = os.environ["UNIPILE_ACCESS_TOKEN"]

# Optional
SUPABASE_URL: str | None = os.environ.get("SUPABASE_URL")
SUPABASE_PASSWORD: str | None = os.environ.get("SUPABASE_PASSWORD")
SUPABASE_KEY: str | None = os.environ.get("SUPABASE_KEY")
