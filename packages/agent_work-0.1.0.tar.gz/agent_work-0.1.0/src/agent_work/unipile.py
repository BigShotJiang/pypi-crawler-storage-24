from __future__ import annotations

import httpx

from agent_work.config import UNIPILE_DSN, UNIPILE_ACCESS_TOKEN


class UnipileClient:
    """Sync REST client for the Unipile API."""

    def __init__(
        self,
        dsn: str = UNIPILE_DSN,
        access_token: str = UNIPILE_ACCESS_TOKEN,
    ) -> None:
        self._base = f"https://{dsn}/api/v1"
        self._client = httpx.Client(
            base_url=self._base,
            headers={"X-API-KEY": access_token},
            timeout=30,
        )

    def __enter__(self) -> UnipileClient:
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    def close(self) -> None:
        self._client.close()

    def request(self, method: str, path: str, **kwargs) -> dict:
        resp = self._client.request(method, path, **kwargs)
        resp.raise_for_status()
        return resp.json()

    def list_accounts(self) -> dict:
        return self.request("GET", "/accounts")

    def list_chats(self, account_id: str | None = None) -> dict:
        params = {}
        if account_id:
            params["account_id"] = account_id
        return self.request("GET", "/chats", params=params)

    def send_message(self, chat_id: str, text: str) -> dict:
        return self.request("POST", f"/chats/{chat_id}/messages", json={"text": text})

    def get_user_profile(self, account_id: str) -> dict:
        return self.request("GET", f"/users/me", params={"account_id": account_id})

    def search_people(self, query: str, account_id: str) -> dict:
        return self.request(
            "POST",
            "/users/search",
            json={"query": query, "account_id": account_id},
        )

    def list_posts(self, account_id: str | None = None) -> dict:
        params = {}
        if account_id:
            params["account_id"] = account_id
        return self.request("GET", "/posts", params=params)

    def create_post(self, account_id: str, text: str) -> dict:
        return self.request(
            "POST",
            "/posts",
            json={"account_id": account_id, "text": text},
        )
