from __future__ import annotations

import httpx

from agent_work.config import CLEARFEED_API_KEY


class ClearFeedClient:
    """Sync REST client for the ClearFeed API."""

    def __init__(self, api_key: str = CLEARFEED_API_KEY) -> None:
        self._client = httpx.Client(
            base_url="https://api.clearfeed.app/v1/rest",
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=30,
        )

    def __enter__(self) -> ClearFeedClient:
        return self

    def __exit__(self, *exc) -> None:
        self.close()

    def close(self) -> None:
        self._client.close()

    def request(self, method: str, path: str, **kwargs) -> dict:
        resp = self._client.request(method, path, **kwargs)
        resp.raise_for_status()
        return resp.json()

    # --- Requests (tickets) ---

    def list_requests(self, **params) -> dict:
        return self.request("GET", "/requests", params=params)

    def get_request(self, request_id: str, include: str | None = None) -> dict:
        params = {}
        if include:
            params["include"] = include
        return self.request("GET", f"/requests/{request_id}", params=params)

    def create_request(self, description: str, **kwargs) -> dict:
        body = {"description": description, **kwargs}
        return self.request("POST", "/requests", json=body)

    def update_request(self, request_id: str, **kwargs) -> dict:
        return self.request("PATCH", f"/requests/{request_id}", json=kwargs)

    def add_message(self, request_id: str, html_body: str, **kwargs) -> dict:
        body = {"html_body": html_body, **kwargs}
        return self.request("POST", f"/requests/{request_id}/message", json=body)

    # --- Collections ---

    def list_collections(self, include: str | None = None) -> dict:
        params = {}
        if include:
            params["include"] = include
        return self.request("GET", "/collections", params=params)

    # --- Customers ---

    def list_customers(self, **params) -> dict:
        return self.request("GET", "/customers", params=params)

    def get_customer(self, customer_id: str) -> dict:
        return self.request("GET", f"/customers/{customer_id}")

    def search_customers(self, filters: dict, **kwargs) -> dict:
        body = {"filters": filters, **kwargs}
        return self.request("POST", "/customers/search", json=body)
