"""Store non python files."""
