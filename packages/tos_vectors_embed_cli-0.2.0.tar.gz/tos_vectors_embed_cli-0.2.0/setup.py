#!/usr/bin/env python3

# Copyright (c) 2024 Amazon.com, Inc. or its affiliates. All Rights Reserved.
# Copyright (c) 2026 Beijing Volcano Engine Technology Co., Ltd.
# SPDX-License-Identifier: Apache-2.0
#
# This file has been modified by Beijing Volcano Engine Technology Co., Ltd. on 2026-02-12
#
# Original file was released under Apache License 2.0, with the full license text
# available at http://www.apache.org/licenses/LICENSE-2.0.
#
# This modified file is released under the same license.
"""Setup script for TOS Vectors CLI."""

from setuptools import setup, find_packages

# Import version from the package
exec(open("tos_vectors/__version__.py").read())

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="tos-vectors-embed-cli",
    version=__version__,
    author="tos",
    author_email="",
    maintainer="tos",
    maintainer_email="",
    description=(
        "Standalone CLI for TOS Vector operations with Volcengine Ark embeddings"
    ),
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/volcengine/tos-vectors-embed-cli",
    project_urls={
        "Bug Reports": (
            "https://github.com/volcengine/tos-vectors-embed-cli/issues"
        ),
        "Source": "https://github.com/volcengine/tos-vectors-embed-cli",
        "Documentation": (
            "https://github.com/volcengine/tos-vectors-embed-cli#readme"
        ),
        "Homepage": "https://github.com/volcengine/tos-vectors-embed-cli",
    },
    packages=find_packages(),
    keywords="tos, vectors, embeddings, ark, cli, machine-learning, ai",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: System Administrators",
        "License :: OSI Approved :: Apache Software License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: System :: Systems Administration",
        "Topic :: Utilities",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Environment :: Console",
    ],
    python_requires=">=3.9",
    install_requires=[
        "tos==2.8.8b2",
        "volcengine-python-sdk[ark]",
        "httpx",
        "click>=8.0.0",
        "rich>=12.0.0",
        "pydantic>=1.10.0",
        "scikit-learn",
        "numpy",
    ],
    entry_points={
        "console_scripts": [
            "tos-vectors-embed=tos_vectors.cli:main",
        ],
    },
)
