# Copyright (c) 2024 Amazon.com, Inc. or its affiliates. All Rights Reserved.
# Copyright (c) 2026 Beijing Volcano Engine Technology Co., Ltd.
# SPDX-License-Identifier: Apache-2.0
#
# This file has been modified by Beijing Volcano Engine Technology Co., Ltd. on 2026-02-12
#
# Original file was released under Apache License 2.0, with the full license text
# available at http://www.apache.org/licenses/LICENSE-2.0.
#
# This modified file is released under the same license.
"""Unified processing logic for both PUT and QUERY operations."""

import base64
from typing import Dict, Any, List, Optional
from dataclasses import dataclass

import tos
from tos_vectors.utils.models import (
    SupportedModel,
    ProcessingInput,
    generate_vector_key
)
from tos_vectors.core.constants import (
    TOS_ACCESS_KEY,
    TOS_SECRET_KEY
)


@dataclass
class ProcessingResult:
    """Unified result structure."""
    vectors: List[Dict[str, Any]]  # List of vectors to store
    result_type: str  # "single" or "multiclip"
    job_id: Optional[str] = None
    # Raw results for timing extraction
    raw_results: Optional[List[Dict[str, Any]]] = None


class UnifiedProcessor:
    """Unified processor that handles both sync and async models."""

    def __init__(self, ark_service, tos_vector_service, region: str = "cn-beijing"):
        self.ark_service = ark_service
        self.tos_vector_service = tos_vector_service
        self.region = region

    def process(self, model: SupportedModel, processing_input: ProcessingInput, user_ark_params: Dict[str, Any] = None, vector_bucket_name: str = None, index_name: str = None, precomputed_dimensions: int = None) -> ProcessingResult:
        """Unified processing method for all input types and models."""

        # Step 1: Get index dimensions if available
        # Use pre-computed dimensions (required parameter)
        if precomputed_dimensions is None:
            raise ValueError(
                "Unexpected error occurred. Index dimensions are not fetched."
            )

        index_dimensions = precomputed_dimensions

        # Step 2: Build content for schema application
        content = self._prepare_content(
            processing_input,
            index_dimensions,
            user_ark_params
        )

        # Step 3: Build payload using schema-based system
        user_ark_params = user_ark_params or {}

        # Build final payload
        final_payload = model.build_payload(
            processing_input.content_type,
            content
        )

        # Step 4: Get embeddings
        raw_results = self._embed_sync(
            model.model_id,
            final_payload,
            user_ark_params,
            dimensions=index_dimensions
        )
        job_id = None

        # Step 6: Process results into vectors (unified)
        vectors = self._prepare_vectors(raw_results, processing_input, model)

        # Step 7: Determine result type
        result_type = "multiclip" if len(vectors) > 1 else "single"

        return ProcessingResult(
            vectors=vectors,
            result_type=result_type,
            job_id=job_id,
            raw_results=raw_results
        )
    
    def _get_mime_type(self, file_path: str) -> str:
        """Get MIME type based on file extension."""
        ext = file_path.lower().split('.')[-1]
        mime_map = {
            'jpg': 'image/jpeg',
            'jpeg': 'image/jpeg',
            'png': 'image/png',
            'apng': 'image/png',
            'gif': 'image/gif',
            'webp': 'image/webp',
            'bmp': 'image/bmp',
            'dib': 'image/bmp',
            'tiff': 'image/tiff',
            'tif': 'image/tiff',
            'ico': 'image/x-icon',
            'icns': 'image/icns',
            'sgi': 'image/sgi',
            'j2c': 'image/jp2',
            'j2k': 'image/jp2',
            'jp2': 'image/jp2',
            'jpc': 'image/jp2',
            'jpf': 'image/jp2',
            'jpx': 'image/jp2',
            'mp4': 'video/mp4',
            'avi': 'video/avi',
            'mov': 'video/quicktime',
        }
        if ext in ['mp4', 'avi', 'mov']:
            return mime_map.get(ext, 'video/mp4')
        return mime_map.get(ext, 'image/jpeg')  # Default to jpeg

    def _prepare_content(self, processing_input: ProcessingInput, index_dimensions: int, user_ark_params: Dict[str, Any] = None) -> Dict[str, Any]:
        """Prepare content dictionary for schema application."""
        content = {"index": {"dimensions": index_dimensions}}
        
        if processing_input.content_type == "text":
            if "file_path" in processing_input.data and "text" not in processing_input.data:
                # Read file content for sync models
                file_content = self._read_file_content(processing_input.data["file_path"])
                content["text"] = file_content
                # Update processing_input.data so metadata logic can access the text content
                processing_input.data["text"] = file_content
            else:
                content["text"] = processing_input.data.get("text", "")
        elif processing_input.content_type == "image":
            if "file_path" in processing_input.data:
                file_path = processing_input.data["file_path"]
                # For sync models, read and encode image
                base64_image = self._read_image_as_base64(file_path)
                mime_type = self._get_mime_type(file_path)

                content["image_base64"] = base64_image
                content["image"] = f"data:{mime_type};base64,{base64_image}"
            else:
                content["image_base64"] = processing_input.data.get("image_base64", "")
                content["image"] = processing_input.data.get("image", "")
                
        elif processing_input.content_type == "multimodal":
            # Handle multimodal input (text + image)
            multimodal_data = processing_input.data.get("multimodal", {})
            content["text"] = multimodal_data.get("text", "")
            content["video"] = multimodal_data.get("video", "")
            image_path = multimodal_data.get("image", "")
            if image_path:
                base64_image = self._read_image_as_base64(image_path)
                mime_type = self._get_mime_type(image_path)

                content["image_base64"] = base64_image
                content["image"] = f"data:{mime_type};base64,{base64_image}"

        elif processing_input.content_type == "video":
            file_path = processing_input.data.get("file_path", "")
            if file_path:
                # For sync models, read and encode video
                base64_video = self._read_video_as_base64(file_path)
                mime_type = self._get_mime_type(file_path)
                content["video_base64"] = base64_video
                content["video"] = f"data:{mime_type};base64,{base64_video}"
            else:
                content["video_base64"] = (
                    processing_input.data.get("video_base64", "")
                )
                content["video"] = processing_input.data.get("video", "")
        return content
    
    def _read_from_tos(self, tos_path: str) -> bytes:
        """Read content from TOS path."""
        # tos_path: tos://bucket/key
        try:
            path = tos_path[6:]
            bucket, key = path.split('/', 1)
            endpoint = f"tos-{self.region}.volces.com"
            
            # Get credentials from environment
            ak = TOS_ACCESS_KEY
            sk = TOS_SECRET_KEY
            
            if not ak or not sk:
                # Try to use service credentials if available (fallback)
                if self.tos_vector_service and self.tos_vector_service.ak and self.tos_vector_service.sk:
                    ak = self.tos_vector_service.ak
                    sk = self.tos_vector_service.sk
                else:
                    raise ValueError("TOS credentials not found (TOS_ACCESS_KEY, TOS_SECRET_KEY)")
            
            client = tos.TosClientV2(ak, sk, endpoint, self.region)
            out = client.get_object(bucket, key)
            return out.read()
        except Exception as e:
            raise ValueError(f"Failed to read from TOS {tos_path}: {str(e)}")

    def _read_file_content(self, file_path: str) -> str:
        """Read text file content from local or TOS."""
        if file_path.startswith('tos://'):
             content_bytes = self._read_from_tos(file_path)
             return content_bytes.decode('utf-8')
        else:
            with open(file_path, 'r', encoding='utf-8') as f:
                return f.read()
    
    def _read_image_as_base64(self, file_path: str) -> str:
        """Read image file and convert to base64."""
        if file_path.startswith('tos://'):
             image_bytes = self._read_from_tos(file_path)
        else:
            with open(file_path, 'rb') as f:
                image_bytes = f.read()
        
        return base64.b64encode(image_bytes).decode('utf-8')

    def _read_video_as_base64(self, file_path: str) -> str:
        """Read video file and convert to base64."""
        if file_path.startswith('tos://'):
             video_bytes = self._read_from_tos(file_path)
        else:
            with open(file_path, 'rb') as f:
                video_bytes = f.read()
        
        return base64.b64encode(video_bytes).decode('utf-8')
    
    def _apply_schema(self, schema: Any, context: dict) -> Any:
        """Recursively apply context to schema template."""
        if isinstance(schema, dict):
            result = {}
            for key, value in schema.items():
                applied_value = self._apply_schema(value, context)
                if applied_value is not None:  # Skip None values
                    result[key] = applied_value
            return result
        elif isinstance(schema, list):
            return [self._apply_schema(item, context) for item in schema]
        elif isinstance(schema, str) and schema.startswith("{") and schema.endswith("}"):
            # Template substitution
            path = schema[1:-1]  # Remove { }
            return self._get_by_path(context, path)
        else:
            return schema
    
    def _get_by_path(self, obj: dict, path: str) -> Any:
        """Get value from nested dict by dot notation path."""
        parts = path.split(".")
        current = obj
        for part in parts:
            if isinstance(current, dict) and part in current:
                current = current[part]
            else:
                return None  # Skip optional parameters
        return current
    
    def _embed_sync(self, model_id: str, embedding_input: Dict[str, Any], user_ark_params: Dict[str, Any], dimensions: int = None) -> List[Dict[str, Any]]:
        """Handle sync embedding using model's schema."""
        from tos_vectors.utils.models import get_model_info
        
        # Get model object for schema-based embedding extraction
        model = get_model_info(model_id)
        if not model:
            raise ValueError(f"Unsupported model: {model_id}")
        
        # The embedding_input is already the correct payload from _prepare_embedding_input
        embedding = self.ark_service.embed_with_payload(model, embedding_input, user_ark_params, dimensions=dimensions)
        
        return [{"embedding": embedding}]
    
    def _prepare_vectors(self, raw_results: List[Dict[str, Any]], processing_input: ProcessingInput, model: SupportedModel) -> List[Dict[str, Any]]:
        """Convert raw embedding results to vector storage format."""
        vectors = []

        # Handle regular embedding processing (non-batch text)
        for i, result in enumerate(raw_results):
            embedding = result.get('embedding', [])
            if not embedding:
                raise ValueError(
                    f"Missing required embedding in result "
                    f"{i + 1}/{len(raw_results)}. Result: {result}"
                )

            # Generate vector key based on processing input preferences
            if processing_input.custom_key and len(raw_results) == 1:
                # Use custom key only for single vector results
                vector_key = generate_vector_key(
                    processing_input.custom_key,
                    False,
                    processing_input.source_location,
                    processing_input.key_prefix
                )
            elif processing_input.filename_as_key and len(raw_results) == 1:
                # Use object key/filename only for single vector results
                vector_key = generate_vector_key(
                    None,
                    True,
                    processing_input.source_location,
                    processing_input.key_prefix
                )
            else:
                # Generate UUID for multi-vector results
                vector_key = generate_vector_key(
                    None,
                    False,
                    processing_input.source_location,
                    processing_input.key_prefix
                )

            # Prepare metadata
            vector_metadata = processing_input.metadata.copy()

            # Add standard metadata fields based on input type
            content_type = processing_input.content_type
            if "file_path" in processing_input.data:
                # File input (--text, --image, --video)
                ct_fmt = content_type.upper().replace('_', '-')
                vector_metadata["TOS-VECTORS-EMBED-SRC-LOCATION"] = (
                    processing_input.source_location
                )
                vector_metadata["TOS-VECTORS-EMBED-SRC-CONTENT-TYPE"] = ct_fmt

                # For text files, also add the raw text content
                if content_type == "text" and "text" in processing_input.data:
                    vector_metadata["TOS-VECTORS-EMBED-SRC-CONTENT"] = (
                        processing_input.data["text"]
                    )
            elif content_type == "multimodal":
                # Multimodal input - add both content and location
                m_data = processing_input.data.get("multimodal", {})
                ct_fmt = content_type.upper()
                vector_metadata["TOS-VECTORS-EMBED-SRC-CONTENT-TYPE"] = ct_fmt
                if m_data.get("text", ""):
                    vector_metadata["TOS-VECTORS-EMBED-SRC-CONTENT"] = (
                        m_data.get("text", "")
                    )
                if m_data.get("image", ""):
                    vector_metadata["TOS-VECTORS-EMBED-SRC-LOCATION"] = (
                        m_data.get("image", "")
                    )
                if m_data.get("video", ""):
                    vector_metadata["TOS-VECTORS-EMBED-SRC-LOCATION"] = (
                        m_data.get("video", "")
                    )
            else:
                # Direct text input (--text-value)
                if content_type == "text" and "text" in processing_input.data:
                    vector_metadata["TOS-VECTORS-EMBED-SRC-CONTENT"] = (
                        processing_input.data["text"]
                    )
                ct_fmt = content_type.upper()
                vector_metadata["TOS-VECTORS-EMBED-SRC-CONTENT-TYPE"] = ct_fmt
                vector_metadata["TOS-VECTORS-EMBED-SRC-LOCATION"] = (
                    processing_input.source_location
                )

            # Create vector in TOS Vectors API format
            vector = {
                "key": vector_key,
                "data": {
                    "float32": embedding
                },
                "metadata": vector_metadata
            }

            vectors.append(vector)

        return vectors
    
    def store_vectors(self, vectors: List[Dict[str, Any]], vector_bucket_name: str, index_name: str) -> List[str]:
        """Store vectors using batch operation."""
        if not vectors:
            return []
        
        self.tos_vector_service.put_vectors_batch(vector_bucket_name, index_name, vectors)
        return [v["key"] for v in vectors]
