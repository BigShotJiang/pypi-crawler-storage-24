# Copyright (c) 2024 Amazon.com, Inc. or its affiliates. All Rights Reserved.
# Copyright (c) 2026 Beijing Volcano Engine Technology Co., Ltd.
# SPDX-License-Identifier: Apache-2.0
#
# This file has been modified by Beijing Volcano Engine Technology Co., Ltd. on 2026-02-12
#
# Original file was released under Apache License 2.0, with the full license text
# available at http://www.apache.org/licenses/LICENSE-2.0.
#
# This modified file is released under the same license.
"""Core services for Ark and TOS Vectors operations."""

import json
import time
from typing import Dict, Any, List, Optional
import numpy as np
from volcenginesdkarkruntime import Ark
from tos import VectorClient
from tos.models2 import Vector, VectorData

from tos_vectors.core.constants import (
    ARK_API_KEY,
    TOS_ACCESS_KEY,
    TOS_SECRET_KEY,
    TOS_VECTOR_ENDPOINT
)


class ArkService:
    """Service for Ark embedding operations."""
    
    def __init__(self, region: str = None, debug: bool = False, console=None):
        self.api_key = ARK_API_KEY
        self.client = Ark(api_key=self.api_key)
        self.debug = debug
        self.console = console

        if self.debug and self.console:
            self.console.print("[dim] ArkService initialized[/dim]")
    
    def _debug_log(self, *args, **kwargs):
        """Log debug message if debug mode is enabled."""
        if self.debug and self.console:
            self.console.log(*args, **kwargs)

    def embed_with_payload(self, model, payload: Dict[str, Any], user_ark_params: Dict[str, Any] = None, dimensions: int = None) -> List[float]:
        """Embed using direct Ark API payload for sync models."""
        start_time = time.time()
        model_id = model.model_id
        self._debug_log(
            f"Starting embedding with model: {model_id}, dimensions: {dimensions}"
        )

        try:
            # Construct Ark input items
            input_items = []
            
            # If payload has 'type', it's a single item (e.g. text only)
            if "type" in payload:
                input_items = [payload]
            else:
                # Otherwise, it's a multimodal dict (text/image/video)
                input_items = list(payload.values())

            # Filter out empty items (those that only have a 'type' field but no data)
            input_items = [
                item for item in input_items 
                if isinstance(item, dict) and any(v for k, v in item.items() if k != "type")
            ]

            if not input_items:
                self._debug_log(f"Empty input items from payload: {payload.keys()}")
                raise ValueError(
                    f"Could not determine input data from payload: {list(payload.keys())}"
                )

            self._debug_log(f"Calling Ark API with {len(input_items)} input items")

            # Prepare request parameters
            params = {
                "model": model_id,
                "encoding_format": "float",
                "input": input_items,
            }

            # Pass dimensions if provided
            if dimensions:
                params["dimensions"] = dimensions

            # Merge user parameters into Ark request parameters
            if user_ark_params:
                params.update(user_ark_params)

            self._debug_log("[bold cyan]Ark API Request Parameters:[/bold cyan]", params)

            resp = self.client.multimodal_embeddings.create(**params)

            # Parse response
            if hasattr(resp, "data") and hasattr(resp.data, "embedding"):
                embedding = resp.data.embedding
                # Ensure it's a flat list of floats
                embedding = np.array(embedding).flatten().tolist()

                elapsed_time = time.time() - start_time
                self._debug_log(f"Ark API call completed in {elapsed_time:.2f} seconds")
                return embedding
            else:
                raise ValueError(f"Unexpected response format from Ark API: {resp}")

        except Exception as e:
            self._debug_log(f"Ark embedding failed: {str(e)}")
            raise


class TOSVectorService:
    """Service for TOS Vector operations."""
    
    def __init__(self, region: str = None, account_id: str = None, 
                 debug: bool = False, console=None):
        self.region = region or "cn-beijing"
        self.endpoint = TOS_VECTOR_ENDPOINT
        self.account_id = account_id
        
        self.ak = TOS_ACCESS_KEY
        self.sk = TOS_SECRET_KEY
        
        if not self.account_id:
            raise ValueError("TOS Account ID is required. Pass it via --account-id CLI option.")
            
        if not self.ak or not self.sk:
            raise ValueError("TOS Access Key and Secret Key are required. Set TOS_ACCESS_KEY and TOS_SECRET_KEY env vars.")
        
        self.client = VectorClient(
            region=self.region,
            endpoint=self.endpoint,
            ak=self.ak,
            sk=self.sk,
        )
        self.debug = debug
        self.console = console
        
        if self.debug and self.console:
            self.console.print(f"[dim] TOSVectorService initialized for region: {self.region}, account: {self.account_id}[/dim]")

    def _debug_log(self, *args, **kwargs):
        """Log debug message if debug mode is enabled."""
        if self.debug and self.console:
            self.console.log(*args, **kwargs)
    
    def put_vectors_batch(self, bucket_name: str, index_name: str, 
                         vectors: List[Dict[str, Any]]) -> List[str]:
        """Put multiple vectors into TOS vector index."""
        start_time = time.time()
        self._debug_log("Starting put_vectors_batch operation")
        self._debug_log(f"Bucket: {bucket_name}, Index: {index_name}")
        self._debug_log(f"Batch size: {len(vectors)} vectors")
        
        try:
            tos_vectors = []
            for v in vectors:
                # v["data"]["float32"] contains the embedding
                embedding = v["data"]["float32"]
                
                tos_vectors.append(Vector(
                    key=v["key"],
                    data=VectorData(embedding),
                    metadata=v["metadata"]
                ))
            
            self.client.put_vectors(
                vector_bucket_name=bucket_name,
                account_id=self.account_id,
                index_name=index_name,
                vectors=tos_vectors
            )
            
            elapsed_time = time.time() - start_time
            self._debug_log(f"TOS Vectors put_vectors batch completed in {elapsed_time:.2f} seconds")
            
            return [v["key"] for v in vectors]

        except Exception as e:
            self._debug_log(f"Unexpected error in put_vectors_batch: {str(e)}")
            raise
    
    def query_vectors(self, bucket_name: str, index_name: str,
                      query_embedding: List[float], top_k: int = 5,
                      filter_expr: Optional[Dict[str, Any]] = None,
                      return_metadata: bool = True,
                      return_distance: bool = True) -> List[Dict[str, Any]]:
        """Query vectors from TOS vector index."""
        try:
            # TOS SDK expects filter as dict, UnifiedProcessor might pass dict or string
            # If string, try to parse?
            filter_dict = filter_expr
            if isinstance(filter_expr, str):
                try:
                    filter_dict = json.loads(filter_expr)
                except json.JSONDecodeError as e:
                    raise ValueError(
                        f"Invalid JSON in filter expression: {str(e)}"
                    )

            resp = self.client.query_vectors(
                vector_bucket_name=bucket_name,
                index_name=index_name,
                account_id=self.account_id,
                query_vector=VectorData(query_embedding),
                top_k=top_k,
                return_distance=return_distance,
                return_metadata=return_metadata,
                filter=filter_dict
            )
            
            results = []
            if hasattr(resp, 'vectors'):
                for v in resp.vectors:
                    result = {
                        'vectorId': v.key,
                        'similarity': v.distance if hasattr(v, 'distance') else 0.0,
                        'metadata': v.metadata if hasattr(v, 'metadata') else {}
                    }
                    results.append(result)
            
            return results
            
        except Exception as e:
            raise Exception(f"TOS Vectors query_vectors failed: {e}")
    
    def get_index(self, bucket_name: str, index_name: str) -> Dict[str, Any]:
        """Get index information."""
        try:
            resp = self.client.get_index(
                vector_bucket_name=bucket_name,
                account_id=self.account_id,
                index_name=index_name
            )
            
            # Extract dimension from response
            if (
                hasattr(resp, 'index') 
                and resp.index 
                and hasattr(resp.index, 'dimension')
            ):
                return {"dimension": resp.index.dimension}
            
            raise ValueError(
                f"Index '{index_name}' not found or dimension missing"
            )
        except Exception as e:
            raise Exception(f"TOS Vectors get_index failed: {e}")
