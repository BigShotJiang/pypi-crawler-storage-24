# Copyright (c) 2024 Amazon.com, Inc. or its affiliates. All Rights Reserved.
# Copyright (c) 2026 Beijing Volcano Engine Technology Co., Ltd.
# SPDX-License-Identifier: Apache-2.0
#
# This file has been modified by Beijing Volcano Engine Technology Co., Ltd. on 2026-02-12
#
# Original file was released under Apache License 2.0, with the full license text
# available at http://www.apache.org/licenses/LICENSE-2.0.
#
# This modified file is released under the same license.
"""Batch processing orchestrator for TOS Vectors."""

import os
import glob
import threading
from typing import List, Dict, Any, Generator, Tuple
from pathlib import Path
from dataclasses import dataclass
import tos
from tos_vectors.core.unified_processor import (
    UnifiedProcessor,
    ProcessingInput
)
from tos_vectors.utils.models import SupportedModel


# Supported file extensions by content type
TEXT_EXTENSIONS = {'txt', 'md', 'json', 'csv', 'log'}
IMAGE_EXTENSIONS = {
    'jpg', 'jpeg', 'apng', 'png', 'gif', 'webp', 'bmp', 'tiff', 'tif',
    'ico', 'dib', 'icns', 'sgi', 'j2c', 'j2k', 'jp2', 'jpc', 'jpf', 'jpx'
}
VIDEO_EXTENSIONS = {'mp4', 'avi', 'mov'}
ALL_EXTENSIONS = TEXT_EXTENSIONS | IMAGE_EXTENSIONS | VIDEO_EXTENSIONS


@dataclass
class BatchResult:
    """Result of batch processing operation."""
    processed_count: int
    failed_count: int
    processed_keys: List[str]
    errors: List[str] = None


class StreamingBatchOrchestrator:
    """
    Efficient streaming batch processor that handles files in chunks
    without loading all paths into memory.
    """

    def __init__(
        self,
        unified_processor: UnifiedProcessor,
        max_workers: int = 4,
        batch_size: int = 500
    ):
        self.unified_processor = unified_processor
        self.max_workers = max_workers
        self.batch_size = batch_size
        self.batch_lock = threading.Lock()

    def process_streaming_batch(
        self,
        file_pattern: str,
        content_type: str,
        vector_bucket_name: str,
        index_name: str,
        model: SupportedModel,
        metadata: Dict[str, Any],
        user_ark_params: Dict[str, Any] = None,
        index_dimensions: int = None,
        filename_as_key: bool = False,
        key_prefix: str = None
    ) -> BatchResult:
        """Process files using streaming approach."""

        # Detect processing strategy
        strategy = self._detect_processing_strategy(file_pattern)

        # Use pre-fetched index dimensions (no API call needed)
        if index_dimensions is None:
            raise ValueError(
                "Failed to fetch index dimensions from TOS Vector index. "
                "Cannot proceed without actual index dimensions."
            )

        batch_context = {
            'model': model,
            'index_dimensions': index_dimensions,
            'user_ark_params': user_ark_params or {},
            'batch_size': self.batch_size,
            'filename_as_key': filename_as_key,
            'key_prefix': key_prefix,
            'content_type': content_type
        }

        # Process using appropriate streaming method
        if strategy == "tos_streaming":
            return self._process_tos_streaming(
                file_pattern, content_type, vector_bucket_name,
                index_name, metadata, batch_context
            )
        else:  # local_streaming
            return self._process_local_streaming(
                file_pattern, content_type, vector_bucket_name,
                index_name, metadata, batch_context
            )

    def _detect_processing_strategy(self, file_pattern: str) -> str:
        """Check whether it is for TOS or Local files."""
        if 'tos://' in file_pattern and '*' in file_pattern:
            return "tos_streaming"
        elif '*' in file_pattern or '?' in file_pattern:
            return "local_streaming"
        else:
            raise ValueError(
                f"Invalid pattern for batch processing: {file_pattern}. "
                "Pattern must contain wildcards (* or ?) for batch processing."
            )

    def _process_tos_streaming(
        self,
        tos_pattern: str,
        content_type: str,
        vector_bucket_name: str,
        index_name: str,
        metadata: Dict[str, Any],
        batch_context: Dict[str, Any]
    ) -> BatchResult:
        """Stream TOS objects directly without pre-loading all paths."""

        # Parse TOS pattern
        tos_path = tos_pattern[6:]  # Remove 'tos://'
        if tos_path.endswith('/*'):
            tos_path = tos_path[:-1]  # Remove only '*', keep '/'
        elif tos_path.endswith('*'):
            tos_path = tos_path[:-1]  # Remove '*'
            # Add trailing slash if not present to ensure directory-level
            if not tos_path.endswith('/'):
                tos_path += '/'

        parts = tos_path.split('/', 1)
        bucket, prefix = parts if len(parts) == 2 else (tos_path, '')

        # Initialize TOS client
        region = self.unified_processor.region
        endpoint = f"tos-{region}.volces.com"

        # Get credentials from environment
        ak = os.environ.get("TOS_ACCESS_KEY")
        sk = os.environ.get("TOS_SECRET_KEY")

        if not ak or not sk:
            raise ValueError(
                "TOS credentials not found (TOS_ACCESS_KEY, TOS_SECRET_KEY)"
            )

        client = tos.TosClientV2(ak, sk, endpoint, region)

        total_processed = 0
        total_failed = 0
        all_processed_keys = []
        all_errors = []

        chunk_number = 0
        for chunk_files in self._stream_tos_chunks(client, bucket, prefix):
            if not chunk_files:
                continue

            chunk_number += 1
            print(f"Processing chunk {chunk_number}...")

            # Process chunk
            processed, failed, keys, errors = self._process_chunk(
                chunk_files, content_type, vector_bucket_name,
                index_name, metadata, batch_context
            )

            total_processed += processed
            total_failed += failed
            all_processed_keys.extend(keys)
            if errors:
                all_errors.extend(errors)

            print(
                f"Completed chunk {chunk_number}: "
                f"{processed} processed, {failed} failed"
            )

        return BatchResult(
            processed_count=total_processed,
            failed_count=total_failed,
            processed_keys=all_processed_keys,
            errors=all_errors if all_errors else None
        )

    def _stream_tos_chunks(
        self,
        client,
        bucket: str,
        prefix: str
    ) -> Generator[List[str], None, None]:
        """Generator that yields chunks of TOS file paths."""
        chunk = []

        marker = ''
        is_truncated = True

        while is_truncated:
            out = client.list_objects(bucket, prefix=prefix, marker=marker)
            is_truncated = out.is_truncated
            marker = out.next_marker

            for obj in out.contents:
                key = obj.key
                # Skip directories
                if key.endswith('/'):
                    continue

                # Check file extension
                ext = key.lower().split('.')[-1] if '.' in key else ''
                if ext in ALL_EXTENSIONS:
                    chunk.append(f"tos://{bucket}/{key}")

                    # Yield chunk when it reaches target size
                    if len(chunk) >= self.batch_size:
                        yield chunk
                        chunk = []

        # Yield remaining files
        if chunk:
            yield chunk

    def _process_local_streaming(
        self,
        local_pattern: str,
        content_type: str,
        vector_bucket_name: str,
        index_name: str,
        metadata: Dict[str, Any],
        batch_context: Dict[str, Any]
    ) -> BatchResult:
        """Stream local files directly without pre-loading all paths."""

        total_processed = 0
        total_failed = 0
        all_processed_keys = []
        all_errors = []

        print(f"Starting streaming processing of {local_pattern}")

        chunk_number = 0
        for chunk_files in self._stream_local_chunks(local_pattern):
            if not chunk_files:
                continue

            chunk_number += 1
            print(f"Processing chunk {chunk_number}...")

            # Process chunk
            processed, failed, keys, errors = self._process_chunk(
                chunk_files, content_type, vector_bucket_name,
                index_name, metadata, batch_context
            )

            total_processed += processed
            total_failed += failed
            all_processed_keys.extend(keys)
            if errors:
                all_errors.extend(errors)

            print(
                f"Completed chunk {chunk_number}: "
                f"{processed} processed, {failed} failed"
            )

        return BatchResult(
            processed_count=total_processed,
            failed_count=total_failed,
            processed_keys=all_processed_keys,
            errors=all_errors if all_errors else None
        )

    def _stream_local_chunks(
        self,
        pattern: str
    ) -> Generator[List[str], None, None]:
        """Generator that yields chunks of local file paths."""
        chunk = []

        # Use iglob for memory-efficient iteration
        for file_path in glob.iglob(pattern, recursive=True):
            if os.path.isfile(file_path):
                path_obj = Path(file_path)
                ext = path_obj.suffix.lower()[1:]  # Remove the dot

                if ext in ALL_EXTENSIONS:
                    chunk.append(file_path)

                    # Yield chunk when it reaches target size
                    if len(chunk) >= self.batch_size:
                        yield chunk
                        chunk = []

        # Yield remaining files
        if chunk:
            yield chunk

    def _process_chunk(
        self,
        chunk_files: List[str],
        content_type: str,
        vector_bucket_name: str,
        index_name: str,
        metadata: Dict[str, Any],
        batch_context: Dict[str, Any]
    ) -> Tuple[int, int, List[str], List[str]]:
        """Process a chunk of files using UnifiedProcessor."""

        # For video, process sequentially due to async nature
        # For text/image, use parallel processing
        if content_type in ["video"]:
            return self._process_chunk_async(
                chunk_files, content_type, vector_bucket_name,
                index_name, metadata, batch_context
            )
        else:
            return self._process_chunk_sync(
                chunk_files, content_type, vector_bucket_name,
                index_name, metadata, batch_context
            )

    def _process_chunk_sync(
        self,
        chunk_files: List[str],
        content_type: str,
        vector_bucket_name: str,
        index_name: str,
        metadata: Dict[str, Any],
        batch_context: Dict[str, Any]
    ) -> Tuple[int, int, List[str], List[str]]:
        """Process text/image files in parallel."""
        from concurrent.futures import ThreadPoolExecutor, as_completed

        processed_count = 0
        failed_count = 0
        processed_keys = []
        errors = []
        vectors_to_store = []

        # Process files in parallel
        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            # Submit all files for processing
            future_to_file = {}
            for file_path in chunk_files:
                # Create appropriate ProcessingInput
                processing_input = ProcessingInput(
                    content_type,
                    {"file_path": file_path},
                    file_path,
                    metadata,
                    filename_as_key=batch_context['filename_as_key'],
                    key_prefix=batch_context['key_prefix']
                )

                future = executor.submit(
                    self.unified_processor.process,
                    batch_context['model'],
                    processing_input,
                    batch_context.get('user_ark_params', {}),
                    vector_bucket_name,
                    index_name,
                    batch_context['index_dimensions']
                )
                future_to_file[future] = file_path

            # Collect results
            completed_files = 0
            for future in as_completed(future_to_file):
                file_path = future_to_file[future]
                try:
                    result = future.result()
                    if result and result.vectors:
                        vectors_to_store.extend(result.vectors)
                        processed_keys.extend(
                            [v.get("key", "") for v in result.vectors]
                        )
                        processed_count += len(result.vectors)
                    else:
                        failed_count += 1
                        errors.append(f"No vectors generated for {file_path}")
                except Exception as e:
                    failed_count += 1
                    errors.append(f"Error processing {file_path}: {str(e)}")

                completed_files += 1
                # Print interim status every 100 files
                if completed_files % 100 == 0:
                    print(
                        f"Progress: {completed_files}/{len(chunk_files)} "
                        f"files processed ({processed_count} successful, "
                        f"{failed_count} failed)"
                    )

        # Store vectors in batch
        if vectors_to_store:
            try:
                self.unified_processor.tos_vector_service.put_vectors_batch(
                    vector_bucket_name, index_name, vectors_to_store
                )
                print(f"STORED BATCH: {len(vectors_to_store)} vectors")
            except Exception as e:
                errors.append(f"Batch storage failed: {str(e)}")
                # Mark all as failed if storage fails
                failed_count += processed_count
                processed_count = 0
                processed_keys = []

        return processed_count, failed_count, processed_keys, errors

    def _process_chunk_async(
        self,
        chunk_files: List[str],
        content_type: str,
        vector_bucket_name: str,
        index_name: str,
        metadata: Dict[str, Any],
        batch_context: Dict[str, Any]
    ) -> Tuple[int, int, List[str], List[str]]:
        """Process video files with parallel async."""
        from concurrent.futures import ThreadPoolExecutor, as_completed

        processed_files_count = 0  # Count files, not vectors
        failed_files_count = 0     # Count files, not vectors
        processed_keys = []
        errors = []

        total_files = len(chunk_files)
        print(
            f"Processing {total_files} {content_type} files "
            f"with {self.max_workers} concurrent workers..."
        )

        with ThreadPoolExecutor(max_workers=self.max_workers) as executor:
            future_to_file = {}

            # Submit all files for async processing
            for file_path in chunk_files:
                processing_input = ProcessingInput(
                    content_type,
                    {"file_path": file_path},
                    file_path,
                    metadata,
                    filename_as_key=batch_context['filename_as_key'],
                    key_prefix=batch_context['key_prefix']
                )

                future = executor.submit(
                    self.unified_processor.process,
                    batch_context['model'],
                    processing_input,
                    batch_context['user_ark_params'],
                    vector_bucket_name,
                    index_name,
                    batch_context['index_dimensions']
                )
                future_to_file[future] = file_path

            # Collect results as they complete
            completed_files = 0
            for future in as_completed(future_to_file):
                file_path = future_to_file[future]
                completed_files += 1

                try:
                    result = future.result()

                    if result and result.vectors:
                        # Store vectors from this file
                        try:
                            file_vector_count = len(result.vectors)
                            batch_sz = batch_context['batch_size']

                            if file_vector_count <= batch_sz:
                                # Small file - single API call
                                self.unified_processor.tos_vector_service \
                                    .put_vectors_batch(
                                        vector_bucket_name,
                                        index_name,
                                        result.vectors
                                    )
                            else:
                                # Large file - chunk into batch_size pieces
                                for i in range(0, file_vector_count, batch_sz):
                                    chunk = result.vectors[i:i + batch_sz]
                                    self.unified_processor.tos_vector_service \
                                        .put_vectors_batch(
                                            vector_bucket_name,
                                            index_name,
                                            chunk
                                        )

                            processed_files_count += 1
                            processed_keys.extend(
                                [v.get("key", "") for v in result.vectors]
                            )

                            print(
                                f"[{completed_files}/{total_files}] "
                                f"Stored {file_vector_count} vectors "
                                f"from {file_path}"
                            )

                        except Exception as e:
                            failed_files_count += 1
                            errors.append(
                                f"Storage failed for {file_path}: {str(e)}"
                            )

                    else:
                        failed_files_count += 1
                        errors.append(f"No vectors generated for {file_path}")

                except Exception as e:
                    failed_files_count += 1
                    errors.append(f"Error processing {file_path}: {str(e)}")

        return (
            processed_files_count,
            failed_files_count,
            processed_keys,
            errors
        )
