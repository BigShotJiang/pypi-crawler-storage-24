# Copyright (c) 2024 Amazon.com, Inc. or its affiliates. All Rights Reserved.
# Copyright (c) 2026 Beijing Volcano Engine Technology Co., Ltd.
# SPDX-License-Identifier: Apache-2.0
#
# This file has been modified by Beijing Volcano Engine Technology Co., Ltd. on 2026-02-12
#
# Original file was released under Apache License 2.0, with the full license text
# available at http://www.apache.org/licenses/LICENSE-2.0.
#
# This modified file is released under the same license.
"""Constants and environment configuration for TOS Vectors."""

import os

# --- Ark Configuration ---
ARK_API_KEY = os.environ.get("ARK_API_KEY")

# --- TOS Configuration ---
TOS_ACCESS_KEY = os.environ.get("TOS_ACCESS_KEY")
TOS_SECRET_KEY = os.environ.get("TOS_SECRET_KEY")
TOS_VECTOR_ENDPOINT = os.environ.get("TOS_VECTOR_ENDPOINT", "tosvectors-cn-beijing.volces.com")
