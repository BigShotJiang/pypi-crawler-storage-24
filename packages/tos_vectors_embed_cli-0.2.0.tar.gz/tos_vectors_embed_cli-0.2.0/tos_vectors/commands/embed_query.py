# Copyright (c) 2024 Amazon.com, Inc. or its affiliates. All Rights Reserved.
# Copyright (c) 2026 Beijing Volcano Engine Technology Co., Ltd.
# SPDX-License-Identifier: Apache-2.0
#
# This file has been modified by Beijing Volcano Engine Technology Co., Ltd. on 2026-02-12
#
# Original file was released under Apache License 2.0, with the full license text
# available at http://www.apache.org/licenses/LICENSE-2.0.
#
# This modified file is released under the same license.
"""Command implementation for embedding and querying vectors."""

import json
from typing import Dict, Any

import click
from rich.console import Console
from rich.table import Table
from tos_vectors.core.unified_processor import UnifiedProcessor
from tos_vectors.core.services import ArkService, TOSVectorService
from tos_vectors.utils.config import get_region
from tos_vectors.utils.models import (
    get_model_info,
    validate_model_modality,
    prepare_processing_input,
    determine_content_type
)


def _validate_query_inputs(text_value, text, image, video, model):
    """Validate query input parameters."""
    inputs = [text_value, text, image, video]
    provided_inputs = [
        inp for inp in inputs
        if inp is not None and (not hasattr(inp, "__len__") or len(inp) > 0)
    ]

    if len(provided_inputs) == 0:
        raise click.ClickException(
            "No query input provided. Use one of: --text-value, --text, "
            "--image, or --video"
        )

    # Special case: Allow multimodal input for supported models
    is_multimodal_input = model.supports_multimodal_input() and sum(
        1 for inp in [text_value, text, image, video]
        if inp is not None
    ) >= 2

    if len(provided_inputs) > 1 and not is_multimodal_input:
        raise click.ClickException(
            "Multiple query inputs provided. Use only one input type, except "
            "for multimodal queries with supported models (--text-value + "
            "--image)"
        )

    return is_multimodal_input


def _format_query_results(results: Dict[str, Any], output_format: str,
                          console: Console):
    """Format and display query results."""
    if output_format == "table":
        _display_results_table(results, console)
    else:
        console.print_json(data=results)


def _display_results_table(results: Dict[str, Any], console: Console):
    """Display query results in table format."""
    table = Table(title="Query Results")
    table.add_column("Rank", style="cyan")
    table.add_column("Vector Key", style="green")
    table.add_column("Distance", style="yellow")
    table.add_column("Metadata", style="blue")

    query_results = results.get("results", [])
    for i, result in enumerate(query_results, 1):
        key = result.get("Key", "N/A")
        dist_val = result.get('distance')
        distance = f"{dist_val:.4f}" if dist_val is not None else "N/A"
        metadata = json.dumps(result.get("metadata", {}), indent=2) \
            if result.get("metadata") else "None"

        table.add_row(str(i), key, distance, metadata)

    console.print(table)

    # Display summary
    summary = results.get("summary", {})
    console.print("\nQuery Summary:")
    console.print(f"  Model: {summary.get('model', 'N/A')}")
    console.print(f"  Results Found: {summary.get('resultsFound', 0)}")
    console.print(
        f"  Query Dimensions: {summary.get('queryDimensions', 'N/A')}"
    )


@click.command()
@click.option('--vector-bucket-name', required=True, help='TOS bucket name for vector storage')
@click.option('--index-name', required=True, help='Vector index name')
@click.option('--model-id', required=True, help='Ark embedding model ID (e.g., doubao-embedding-vision-250615)')
@click.option('--text-value', help='Direct text query string')
@click.option('--text', help='Text file path (local file or TOS URI)')
@click.option('--image', help='Image file path (local file or TOS URI)')
@click.option('--video', help='Video file path (local file)')
@click.option('--k', default=5, type=int, help='Number of results to return (default: 5)')
@click.option('--filter', 'filter_expr', help='Filter expression for results (JSON format with operators)')
@click.option('--return-distance', is_flag=True, help='Return similarity distances in results')
@click.option('--return-metadata/--no-return-metadata', default=True, help='Return metadata in results (default: true)')
@click.option('--ark-inference-params', help='JSON string with model-specific parameters matching Ark API format')
@click.option('--output', type=click.Choice(['table', 'json']), default='json', help='Output format (default: json)')
@click.option('--region', help='TOS region name (effective in TOS path mode)')
@click.pass_context
def embed_query(ctx, vector_bucket_name, index_name, model_id, text_value, text, image, video, k, filter_expr, return_distance, return_metadata, ark_inference_params, output, region):
    """Embed query input and search for similar vectors using UnifiedProcessor.

    \b
    SUPPORTED QUERY INPUT TYPES:
    • Direct text: --text-value "search for this text"
    • Local text file: --text /path/to/query.txt
    • Local image file: --image /path/to/image.jpg
    • TOS text file: --text tos://bucket/query.txt
    • TOS image file: --image tos://bucket/image.jpg
    • Video files: --video /path/to/video.mp4

    \b
    SUPPORTED MODELS:
    • doubao-embedding-vision-250615 (text, image, video queries)
    • doubao-embedding-vision-251215 (text, image, video queries)

    \b
    FILTERING:
    • Use JSON format with Volcengine TOS Vectors API operators
    • Single condition: --filter '{"category": {"$eq": "documentation"}}'
    """
    console = ctx.obj.get('console', Console())
    account_id = ctx.obj.get('account_id')

    try:
        # Get model information first for validation
        model = get_model_info(model_id)
        if not model:
            raise click.ClickException(f"Unsupported model: {model_id}")

        # Validate inputs
        is_multimodal = _validate_query_inputs(
            text_value, text, image, video, model
        )

        # Determine content type for model validation
        content_type = determine_content_type(
            text_value, text, image, video, is_multimodal
        )

        # Validate model capabilities
        if is_multimodal:
            if not model.supports_multimodal_input():
                raise click.ClickException(
                    f"Model {model_id} does not support multimodal "
                    "input (text + image)"
                )
        else:
            validate_model_modality(model_id, content_type)

        # Parse user parameters
        user_ark_params = {}
        if ark_inference_params:
            try:
                user_ark_params = json.loads(ark_inference_params)
            except json.JSONDecodeError as e:
                raise click.ClickException(
                    f"Invalid JSON in --ark-inference-params: {e}"
                )

        # Parse filter expression
        metadata_filter = None
        if filter_expr:
            try:
                metadata_filter = json.loads(filter_expr)
            except json.JSONDecodeError as e:
                raise click.ClickException(f"Invalid JSON in --filter: {e}")

        region = get_region(region or ctx.obj.get('region'))

        ark_service = ArkService(
            region=region,
            debug=ctx.obj.get('debug', False),
            console=console
        )
        tos_vector_service = TOSVectorService(
            region=region,
            account_id=account_id,
            debug=ctx.obj.get('debug', False),
            console=console
        )

        # Create UnifiedProcessor
        processor = UnifiedProcessor(ark_service, tos_vector_service, region=region)

        # Fetch index dimensions once at the top level (same pattern as PUT)
        try:
            index_info = tos_vector_service.get_index(
                vector_bucket_name,
                index_name
            )
            index_dimensions = index_info.get("dimension")
            if not index_dimensions:
                raise click.ClickException(
                    f"Could not determine dimensions for index {index_name}"
                )
        except Exception as e:
            raise click.ClickException(
                f"Failed to get index information: {str(e)}"
            )

        # Create ProcessingInput
        processing_input = prepare_processing_input(
            text_value, text, image, video, is_multimodal,
            None, None, False, None
        )

        # Process query input to generate embedding (same as PUT)
        with console.status("[bold green]Generating query embedding..."):
            result = processor.process(
                model=model,
                processing_input=processing_input,
                user_ark_params=user_ark_params,
                precomputed_dimensions=index_dimensions
            )

        # Extract query embedding
        query_timing = {}  # Store timing info for summary

        if hasattr(result, 'vectors') and result.vectors:
            # Get the embedding from the first vector
            first_vector = result.vectors[0]
            if "embedding" in first_vector:
                query_embedding = first_vector["embedding"]
            elif "data" in first_vector and "float32" in first_vector["data"]:
                query_embedding = first_vector["data"]["float32"]
            else:
                raise click.ClickException(
                    "No embedding found in result."
                )
        else:
            raise click.ClickException(
                "Failed to generate query embedding - no vectors returned"
            )

        # Perform vector similarity search
        with console.status("[bold green]Searching for similar vectors..."):
            search_results = tos_vector_service.query_vectors(
                bucket_name=vector_bucket_name,
                index_name=index_name,
                query_embedding=query_embedding,
                top_k=k,
                filter_expr=(
                    json.dumps(metadata_filter) if metadata_filter else None
                ),
                return_metadata=return_metadata,
                return_distance=return_distance
            )

        # Format results
        formatted_results = {
            "results": [
                {
                    "Key": result.get("vectorId", ""),
                    "distance": result.get("similarity", 0.0),
                    "metadata": result.get("metadata", {})
                }
                for result in search_results
            ],
            "summary": {
                "queryType": content_type,
                "model": model_id,
                "index": index_name,
                "resultsFound": len(search_results),
                "queryDimensions": len(query_embedding),
                **query_timing  # Add timing info
            }
        }

        # Add distances if requested (already included in results)
        if not return_distance:
            for result in formatted_results["results"]:
                result.pop("distance", None)

        # Display results
        _format_query_results(formatted_results, output, console)

    except Exception as e:
        raise click.ClickException(str(e))
