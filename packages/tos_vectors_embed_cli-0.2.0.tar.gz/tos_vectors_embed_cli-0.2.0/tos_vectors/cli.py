#!/usr/bin/env python3
# Copyright (c) 2024 Amazon.com, Inc. or its affiliates. All Rights Reserved.
# Copyright (c) 2026 Beijing Volcano Engine Technology Co., Ltd.
# SPDX-License-Identifier: Apache-2.0
#
# This file has been modified by Beijing Volcano Engine Technology Co., Ltd. on 2026-02-12
#
# Original file was released under Apache License 2.0, with the full license text
# available at http://www.apache.org/licenses/LICENSE-2.0.
#
# This modified file is released under the same license.
"""Main CLI entry point for TOS Vectors."""

import click
from rich.console import Console
from rich.traceback import install
from tos_vectors.commands.embed_put import embed_put
from tos_vectors.commands.embed_query import embed_query

# Install rich traceback handler
install(show_locals=True)
console = Console()


@click.group()
@click.version_option(version="0.1.0")
@click.option('--account-id', help='Volcengine account id to use')
@click.option('--region', default='cn-beijing', help='TOS region name')
@click.option('--debug', is_flag=True, help='Enable debug mode with detailed logging')
@click.pass_context
def cli(ctx, account_id, region, debug):
    """TOS Vectors Embed CLI - Standalone tool for vector embedding operations with TOS and Ark."""
    ctx.ensure_object(dict)
    ctx.obj['account_id'] = account_id
    ctx.obj['region'] = region
    ctx.obj['console'] = console
    ctx.obj['debug'] = debug

    if debug:
        console.print("[dim] Debug mode enabled[/dim]")
        console.print(f"[dim] Volcengine Account ID: {account_id}[/dim]")
        console.print(f"[dim] TOS Region: {region}[/dim]")


# Register commands as subcommands
cli.add_command(embed_put, name='put')
cli.add_command(embed_query, name='query')


def main():
    """Main entry point."""
    try:
        cli()
    except KeyboardInterrupt:
        console.print("\n[yellow]Operation cancelled by user[/yellow]")
    except Exception as e:
        console.print(f"[red]Error: {str(e)}[/red]")
        raise


if __name__ == '__main__':
    main()
