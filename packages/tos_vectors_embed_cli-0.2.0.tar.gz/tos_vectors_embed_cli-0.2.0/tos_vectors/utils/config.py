# Copyright (c) 2024 Amazon.com, Inc. or its affiliates. All Rights Reserved.
# Copyright (c) 2026 Beijing Volcano Engine Technology Co., Ltd.
# SPDX-License-Identifier: Apache-2.0
#
# This file has been modified by Beijing Volcano Engine Technology Co., Ltd. on 2026-02-12
#
# Original file was released under Apache License 2.0, with the full license text
# available at http://www.apache.org/licenses/LICENSE-2.0.
#
# This modified file is released under the same license.
"""TOS configuration utilities."""

from tos_vectors.__version__ import __version__


class TOSConfig:
    def __init__(self, account_id=None, region=None, endpoint=None):
        self.account_id = account_id
        self.region = region
        self.endpoint = endpoint


def setup_tos_cfg(account_id=None, region=None):
    if not region:
        region = get_region()
    
    return TOSConfig(account_id=account_id, region=region)


def get_region(region=None):
    if region:
        return region

    # Default to cn-beijing for TOS
    return 'cn-beijing'


def get_user_agent():
    """
    Get the CLI user agent string for logging/debugging.

    Returns:
        User agent string for display
    """
    return f"tos-vectors-embed-cli/{__version__}"
