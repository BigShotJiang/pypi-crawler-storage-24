"""Plugin system for the host agent.

Plugins are Python modules placed in the configured plugin directory.
Each module should contain a class that inherits from PluginBase.
The agent discovers and loads plugins automatically on startup.
"""

from __future__ import annotations

import importlib.util
import inspect
import logging
import pkgutil
import sys
from abc import ABC, abstractmethod
from pathlib import Path

logger = logging.getLogger(__name__)


class PluginBase(ABC):
    """Abstract base class for host agent plugins.

    Subclass this and define namespace, actions, description, and handle().
    """

    namespace: str = ""
    actions: list[str] = []
    description: str = ""

    @abstractmethod
    async def handle(self, action: str, params: dict) -> dict:
        """Handle an incoming action request.

        Args:
            action: The action name (must be in self.actions).
            params: Action parameters from the server.

        Returns:
            A dict with the result. Include an "error" key on failure.
        """
        ...


class PluginRegistry:
    """Discovers and manages plugins from a directory."""

    def __init__(self) -> None:
        self._plugins: dict[str, PluginBase] = {}

    @property
    def plugins(self) -> dict[str, PluginBase]:
        """Return loaded plugins keyed by namespace."""
        return dict(self._plugins)

    def discover(self, plugin_dir: str) -> dict[str, PluginBase]:
        """Discover and load plugins from a directory.

        Scans the directory for .py files, imports each module, and finds
        classes that inherit from PluginBase. Each valid plugin is instantiated
        and registered by its namespace.

        Args:
            plugin_dir: Path to the directory containing plugin .py files.

        Returns:
            Dict of namespace -> PluginBase instance for all loaded plugins.
        """
        path = Path(plugin_dir).expanduser().resolve()
        if not path.is_dir():
            logger.warning("Plugin directory does not exist: %s", path)
            return {}

        logger.info("Scanning for plugins in: %s", path)

        # Add plugin dir to sys.path so imports work
        path_str = str(path)
        if path_str not in sys.path:
            sys.path.insert(0, path_str)

        loaded: dict[str, PluginBase] = {}

        for finder, module_name, is_pkg in pkgutil.iter_modules([path_str]):
            if is_pkg or module_name.startswith("_"):
                continue

            try:
                spec = importlib.util.find_spec(module_name)
                if spec is None or spec.origin is None:
                    logger.warning("Cannot find spec for module: %s", module_name)
                    continue

                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)

                # Find PluginBase subclasses in the module
                for _name, obj in inspect.getmembers(module, inspect.isclass):
                    if (
                        issubclass(obj, PluginBase)
                        and obj is not PluginBase
                        and obj.namespace
                    ):
                        instance = obj()
                        self._plugins[instance.namespace] = instance
                        loaded[instance.namespace] = instance
                        logger.info(
                            "Loaded plugin: %s (actions: %s)",
                            instance.namespace,
                            instance.actions,
                        )

            except Exception as e:
                logger.error("Failed to load plugin module '%s': %s", module_name, e)

        return loaded

    def get(self, namespace: str) -> PluginBase | None:
        """Get a plugin by namespace."""
        return self._plugins.get(namespace)

    def namespaces(self) -> list[str]:
        """Return list of loaded plugin namespaces."""
        return list(self._plugins.keys())
