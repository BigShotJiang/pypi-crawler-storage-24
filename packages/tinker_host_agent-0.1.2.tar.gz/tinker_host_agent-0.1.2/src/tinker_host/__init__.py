"""Tinker Host Agent — Device Agent Protocol client for host machines."""

__version__ = "0.1.2"
