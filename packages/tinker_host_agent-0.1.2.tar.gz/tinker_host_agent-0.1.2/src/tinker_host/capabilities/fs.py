"""File system capability."""

from __future__ import annotations

import logging
import os
from pathlib import Path

logger = logging.getLogger(__name__)


class FSCapability:
    namespace = "fs"
    actions = ["read", "write", "list", "search"]
    description = "File system access (read, write, list, search)"

    def __init__(
        self,
        allowed_paths: list[Path] | None = None,
        blocked_paths: list[Path] | None = None,
    ) -> None:
        self._allowed = allowed_paths or [Path.home(), Path("/tmp")]
        self._blocked = blocked_paths or []

    def _check_path(self, path_str: str) -> str | None:
        """Return error if path is not allowed, None if OK."""
        path = Path(path_str).expanduser().resolve()

        # Check blocked paths first
        for blocked in self._blocked:
            resolved_blocked = blocked.expanduser().resolve()
            if path == resolved_blocked or resolved_blocked in path.parents:
                return f"Access denied: {path} is in blocked path {blocked}"

        # Check allowed paths
        for allowed in self._allowed:
            resolved_allowed = allowed.expanduser().resolve()
            if path == resolved_allowed or resolved_allowed in path.parents:
                return None

        return f"Access denied: {path} is not in any allowed path"

    async def handle(self, action: str, params: dict) -> dict:
        match action:
            case "read":
                return await self._read(params)
            case "write":
                return await self._write(params)
            case "list":
                return await self._list(params)
            case "search":
                return await self._search(params)
            case _:
                return {"error": f"Unknown fs action: {action}"}

    async def _read(self, params: dict) -> dict:
        path_str = params.get("path", "")
        if not path_str:
            return {"error": "No path provided"}

        error = self._check_path(path_str)
        if error:
            return {"error": error}

        path = Path(path_str).expanduser()
        if not path.exists():
            return {"error": f"File not found: {path}"}
        if not path.is_file():
            return {"error": f"Not a file: {path}"}

        try:
            # Check file size (max 10MB)
            size = path.stat().st_size
            if size > 10 * 1024 * 1024:
                return {"error": f"File too large: {size} bytes (max 10MB)"}
            content = path.read_text(errors="replace")
            return {"content": content, "size": size, "path": str(path)}
        except Exception as e:
            return {"error": f"Read failed: {e}"}

    async def _write(self, params: dict) -> dict:
        path_str = params.get("path", "")
        content = params.get("content", "")
        if not path_str:
            return {"error": "No path provided"}

        error = self._check_path(path_str)
        if error:
            return {"error": error}

        path = Path(path_str).expanduser()
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(content)
            return {"message": f"Written {len(content)} bytes to {path}", "path": str(path)}
        except Exception as e:
            return {"error": f"Write failed: {e}"}

    async def _list(self, params: dict) -> dict:
        path_str = params.get("path", "")
        if not path_str:
            return {"error": "No path provided"}

        error = self._check_path(path_str)
        if error:
            return {"error": error}

        path = Path(path_str).expanduser()
        if not path.exists():
            return {"error": f"Directory not found: {path}"}
        if not path.is_dir():
            return {"error": f"Not a directory: {path}"}

        try:
            entries = []
            for entry in sorted(path.iterdir()):
                stat = entry.stat(follow_symlinks=False)
                entries.append({
                    "name": entry.name,
                    "type": "dir" if entry.is_dir() else "file",
                    "size": stat.st_size if entry.is_file() else 0,
                })
            return {"entries": entries, "count": len(entries), "path": str(path)}
        except PermissionError:
            return {"error": f"Permission denied: {path}"}

    async def _search(self, params: dict) -> dict:
        path_str = params.get("path", str(Path.home()))
        pattern = params.get("pattern", "*")
        max_results = params.get("max_results", 50)

        error = self._check_path(path_str)
        if error:
            return {"error": error}

        path = Path(path_str).expanduser()
        if not path.exists():
            return {"error": f"Path not found: {path}"}

        try:
            results = []
            for match in path.rglob(pattern):
                if len(results) >= max_results:
                    break
                results.append(str(match))
            return {"matches": results, "count": len(results), "truncated": len(results) >= max_results}
        except Exception as e:
            return {"error": f"Search failed: {e}"}
