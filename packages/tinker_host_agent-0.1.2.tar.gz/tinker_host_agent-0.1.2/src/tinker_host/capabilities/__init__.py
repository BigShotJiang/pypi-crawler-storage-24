"""Capability modules for the host agent."""

from __future__ import annotations

from typing import Protocol


class CapabilityHandler(Protocol):
    """Protocol for capability handlers."""

    namespace: str
    actions: list[str]
    description: str

    async def handle(self, action: str, params: dict) -> dict: ...
