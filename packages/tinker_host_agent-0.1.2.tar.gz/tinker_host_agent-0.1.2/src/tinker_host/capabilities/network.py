"""Network utilities capability."""

from __future__ import annotations

import asyncio
import logging
import platform
import re
from urllib.request import Request, urlopen
from urllib.error import URLError

logger = logging.getLogger(__name__)

_SYSTEM = platform.system()


class NetworkCapability:
    namespace = "network"
    actions = ["http", "ports", "ping"]
    description = "Network utilities (HTTP requests, port listing, ping)"

    async def handle(self, action: str, params: dict) -> dict:
        match action:
            case "http":
                return await self._http(params)
            case "ports":
                return await self._ports(params)
            case "ping":
                return await self._ping(params)
            case _:
                return {"error": f"Unknown network action: {action}"}

    async def _http(self, params: dict) -> dict:
        """Perform a simple HTTP GET request using urllib."""
        url = params.get("url", "")
        if not url:
            return {"error": "No url provided"}

        timeout = params.get("timeout_ms", 10000) / 1000
        headers = params.get("headers", {})

        def _do_request() -> dict:
            try:
                req = Request(url, method="GET")
                req.add_header("User-Agent", "tinker-host-agent/0.1.0")
                for key, value in headers.items():
                    req.add_header(key, value)

                with urlopen(req, timeout=timeout) as resp:
                    body = resp.read()
                    # Cap response body at 1MB
                    if len(body) > 1024 * 1024:
                        body = body[: 1024 * 1024]

                    return {
                        "status": resp.status,
                        "headers": dict(resp.headers),
                        "body": body.decode(errors="replace"),
                        "url": resp.url,
                    }
            except URLError as e:
                return {"error": f"Request failed: {e.reason}"}
            except TimeoutError:
                return {"error": f"Request timed out after {timeout}s"}
            except Exception as e:
                return {"error": f"Request failed: {e}"}

        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, _do_request)

    async def _ports(self, params: dict) -> dict:
        """List listening TCP/UDP ports."""
        try:
            if _SYSTEM == "Darwin":
                # macOS: use lsof
                proc = await asyncio.create_subprocess_exec(
                    "lsof",
                    "-iTCP",
                    "-sTCP:LISTEN",
                    "-nP",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=15)
                lines = stdout.decode(errors="replace").strip().split("\n")

                ports = []
                for line in lines[1:]:  # skip header
                    parts = line.split()
                    if len(parts) >= 9:
                        # Extract port from NAME column (e.g., *:8000 or 127.0.0.1:3000)
                        name_col = parts[8]
                        match = re.search(r":(\d+)$", name_col)
                        port_num = int(match.group(1)) if match else 0
                        ports.append({
                            "command": parts[0],
                            "pid": parts[1],
                            "address": name_col,
                            "port": port_num,
                        })

                return {"ports": ports, "count": len(ports)}

            elif _SYSTEM == "Linux":
                # Linux: use ss
                proc = await asyncio.create_subprocess_exec(
                    "ss",
                    "-tlnp",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=15)
                lines = stdout.decode(errors="replace").strip().split("\n")

                ports = []
                for line in lines[1:]:  # skip header
                    parts = line.split()
                    if len(parts) >= 4:
                        local_addr = parts[3]
                        match = re.search(r":(\d+)$", local_addr)
                        port_num = int(match.group(1)) if match else 0
                        # Extract process info if available
                        process_info = parts[5] if len(parts) > 5 else ""
                        proc_match = re.search(r'"([^"]+)"', process_info)
                        command = proc_match.group(1) if proc_match else ""
                        ports.append({
                            "command": command,
                            "address": local_addr,
                            "port": port_num,
                        })

                return {"ports": ports, "count": len(ports)}

            else:
                return {"error": f"Port listing not supported on {_SYSTEM}"}

        except Exception as e:
            return {"error": f"Port listing failed: {e}"}

    async def _ping(self, params: dict) -> dict:
        """Ping a host using the system ping command."""
        host = params.get("host", "")
        if not host:
            return {"error": "No host provided"}

        count = min(params.get("count", 4), 20)  # cap at 20

        # Sanitize host to prevent command injection
        if not re.match(r"^[a-zA-Z0-9._:-]+$", host):
            return {"error": "Invalid host format"}

        try:
            # -c on both macOS and Linux
            count_flag = "-c"
            proc = await asyncio.create_subprocess_exec(
                "ping",
                count_flag,
                str(count),
                "-W",
                "5" if _SYSTEM == "Linux" else "5000",
                host,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(
                proc.communicate(), timeout=count * 5 + 10
            )

            output = stdout.decode(errors="replace")

            # Parse summary line for packet loss and rtt
            packet_loss = None
            rtt_avg = None

            loss_match = re.search(r"([\d.]+)% packet loss", output)
            if loss_match:
                packet_loss = float(loss_match.group(1))

            # macOS/Linux: round-trip min/avg/max/stddev = 1.234/5.678/9.012/1.234 ms
            rtt_match = re.search(
                r"(?:rtt|round-trip)\s+\S+\s*=\s*([\d.]+)/([\d.]+)/([\d.]+)", output
            )
            if rtt_match:
                rtt_avg = float(rtt_match.group(2))

            return {
                "host": host,
                "output": output,
                "packet_loss_pct": packet_loss,
                "rtt_avg_ms": rtt_avg,
                "reachable": packet_loss is not None and packet_loss < 100,
            }

        except asyncio.TimeoutError:
            return {"error": f"Ping timed out for {host}"}
        except Exception as e:
            return {"error": f"Ping failed: {e}"}
