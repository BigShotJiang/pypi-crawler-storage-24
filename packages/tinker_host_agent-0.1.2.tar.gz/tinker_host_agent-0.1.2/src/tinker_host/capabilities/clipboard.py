"""Clipboard capability."""

from __future__ import annotations

import asyncio
import logging
import platform

logger = logging.getLogger(__name__)

_SYSTEM = platform.system()


class ClipboardCapability:
    namespace = "clipboard"
    actions = ["get", "set"]
    description = "Clipboard access (get/set)"

    async def handle(self, action: str, params: dict) -> dict:
        match action:
            case "get":
                return await self._get()
            case "set":
                return await self._set(params)
            case _:
                return {"error": f"Unknown clipboard action: {action}"}

    async def _get(self) -> dict:
        try:
            if _SYSTEM == "Darwin":
                proc = await asyncio.create_subprocess_exec(
                    "pbpaste",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                stdout, _ = await proc.communicate()
                return {"content": stdout.decode(errors="replace")}
            elif _SYSTEM == "Linux":
                proc = await asyncio.create_subprocess_exec(
                    "xclip", "-selection", "clipboard", "-o",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                stdout, _ = await proc.communicate()
                return {"content": stdout.decode(errors="replace")}
            return {"error": f"Clipboard not supported on {_SYSTEM}"}
        except Exception as e:
            return {"error": f"Clipboard get failed: {e}"}

    async def _set(self, params: dict) -> dict:
        content = params.get("content", "")
        try:
            if _SYSTEM == "Darwin":
                proc = await asyncio.create_subprocess_exec(
                    "pbcopy",
                    stdin=asyncio.subprocess.PIPE,
                )
                await proc.communicate(input=content.encode())
                return {"message": f"Clipboard set ({len(content)} chars)"}
            elif _SYSTEM == "Linux":
                proc = await asyncio.create_subprocess_exec(
                    "xclip", "-selection", "clipboard",
                    stdin=asyncio.subprocess.PIPE,
                )
                await proc.communicate(input=content.encode())
                return {"message": f"Clipboard set ({len(content)} chars)"}
            return {"error": f"Clipboard not supported on {_SYSTEM}"}
        except Exception as e:
            return {"error": f"Clipboard set failed: {e}"}
