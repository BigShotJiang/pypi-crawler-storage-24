"""Application management capability."""

from __future__ import annotations

import asyncio
import logging
import platform

logger = logging.getLogger(__name__)

_SYSTEM = platform.system()


class AppCapability:
    namespace = "app"
    actions = ["launch", "list", "info", "quit"]
    description = "Application management (launch, list, quit)"

    async def handle(self, action: str, params: dict) -> dict:
        match action:
            case "launch":
                return await self._launch(params)
            case "list":
                return await self._list()
            case "quit":
                return await self._quit(params)
            case _:
                return {"error": f"Unknown app action: {action}"}

    async def _launch(self, params: dict) -> dict:
        app_name = params.get("app_name", "")
        if not app_name:
            return {"error": "No app_name provided"}

        try:
            if _SYSTEM == "Darwin":
                proc = await asyncio.create_subprocess_exec(
                    "open", "-a", app_name,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                _, stderr = await asyncio.wait_for(proc.communicate(), timeout=10)
                if proc.returncode != 0:
                    return {"error": f"Failed to launch: {stderr.decode().strip()}"}
                return {"message": f"Launched: {app_name}"}
            elif _SYSTEM == "Linux":
                proc = await asyncio.create_subprocess_exec(
                    "xdg-open" if "/" not in app_name else app_name,
                    *([] if "/" in app_name else [app_name]),
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                await asyncio.wait_for(proc.communicate(), timeout=10)
                return {"message": f"Launched: {app_name}"}
            return {"error": f"App launch not supported on {_SYSTEM}"}
        except Exception as e:
            return {"error": f"Launch failed: {e}"}

    async def _list(self) -> dict:
        try:
            if _SYSTEM == "Darwin":
                script = (
                    'tell application "System Events" to '
                    "get {name, unix id} of every process whose visible is true"
                )
                proc = await asyncio.create_subprocess_exec(
                    "osascript", "-e", script,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                stdout, _ = await proc.communicate()
                output = stdout.decode().strip()
                return {"apps": output, "platform": "darwin"}
            elif _SYSTEM == "Linux":
                proc = await asyncio.create_subprocess_exec(
                    "ps", "-eo", "pid,comm", "--sort=-pid",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                stdout, _ = await proc.communicate()
                lines = stdout.decode().strip().split("\n")[:50]
                return {"apps": lines, "count": len(lines)}
            return {"error": f"App list not supported on {_SYSTEM}"}
        except Exception as e:
            return {"error": f"List failed: {e}"}

    async def _quit(self, params: dict) -> dict:
        app_name = params.get("app_name", "")
        if not app_name:
            return {"error": "No app_name provided"}

        try:
            if _SYSTEM == "Darwin":
                script = f'tell application "{app_name}" to quit'
                proc = await asyncio.create_subprocess_exec(
                    "osascript", "-e", script,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                await asyncio.wait_for(proc.communicate(), timeout=10)
                return {"message": f"Quit: {app_name}"}
            elif _SYSTEM == "Linux":
                proc = await asyncio.create_subprocess_exec(
                    "pkill", "-f", app_name,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                await proc.communicate()
                return {"message": f"Killed: {app_name}"}
            return {"error": f"App quit not supported on {_SYSTEM}"}
        except Exception as e:
            return {"error": f"Quit failed: {e}"}
