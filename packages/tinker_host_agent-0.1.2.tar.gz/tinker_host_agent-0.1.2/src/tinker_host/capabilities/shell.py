"""Shell execution capability."""

from __future__ import annotations

import asyncio
import logging

logger = logging.getLogger(__name__)


class ShellCapability:
    namespace = "shell"
    actions = ["exec", "stream", "kill"]
    description = "Execute shell commands on the host machine"

    def __init__(self, blocked_commands: list[str] | None = None) -> None:
        self._blocked = blocked_commands or []
        self._processes: dict[str, asyncio.subprocess.Process] = {}

    def _check_command(self, command: str) -> str | None:
        """Return error message if command is blocked, None if OK."""
        for blocked in self._blocked:
            if blocked and blocked in command:
                return f"Command blocked by security policy: contains '{blocked}'"
        return None

    async def handle(self, action: str, params: dict) -> dict:
        match action:
            case "exec":
                return await self._exec(params)
            case "kill":
                return await self._kill(params)
            case _:
                return {"error": f"Unknown shell action: {action}"}

    async def _exec(self, params: dict) -> dict:
        command = params.get("command", "")
        if not command:
            return {"error": "No command provided"}

        blocked = self._check_command(command)
        if blocked:
            return {"error": blocked}

        timeout = params.get("timeout_ms", 30000) / 1000

        try:
            proc = await asyncio.create_subprocess_shell(
                command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, stderr = await asyncio.wait_for(proc.communicate(), timeout=timeout)

            return {
                "stdout": stdout.decode(errors="replace"),
                "stderr": stderr.decode(errors="replace"),
                "exit_code": proc.returncode or 0,
            }
        except asyncio.TimeoutError:
            if proc:
                proc.kill()
            return {"error": "Command timed out", "exit_code": -1}
        except Exception as e:
            return {"error": str(e), "exit_code": -1}

    async def _kill(self, params: dict) -> dict:
        pid = params.get("pid")
        if not pid:
            return {"error": "No pid provided"}
        try:
            import signal

            import os

            os.kill(int(pid), signal.SIGTERM)
            return {"message": f"Sent SIGTERM to pid {pid}"}
        except ProcessLookupError:
            return {"error": f"Process {pid} not found"}
        except Exception as e:
            return {"error": str(e)}
