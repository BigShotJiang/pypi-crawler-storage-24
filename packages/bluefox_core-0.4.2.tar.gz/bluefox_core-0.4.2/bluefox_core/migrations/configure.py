"""Alembic integration for bluefox-core.

Provides configure_alembic() — a single function that wires BluefoxSettings,
model auto-discovery, and async engine support into Alembic's migration context.
"""

from __future__ import annotations

import asyncio
from logging.config import fileConfig
from typing import TYPE_CHECKING

from sqlalchemy import pool
from sqlalchemy.ext.asyncio import async_engine_from_config

from bluefox_core.database import BluefoxBase, normalize_database_url
from bluefox_core.discovery import discover_models
from bluefox_core.settings import BluefoxSettings

if TYPE_CHECKING:
    from alembic.operations import MigrationContext


def _run_migrations(connection, context) -> None:  # noqa: ANN001
    """Run migrations synchronously within an async connection."""
    context.configure(connection=connection, target_metadata=BluefoxBase.metadata)
    with context.begin_transaction():
        context.run_migrations()


def configure_alembic(context: MigrationContext) -> None:
    """Configure Alembic with BluefoxSettings, model discovery, and async engine.

    Call this from your migrations/env.py:

        from alembic import context
        from bluefox_core.migrations import configure_alembic

        configure_alembic(context)
    """
    config = context.config

    # Set up logging from alembic.ini so migration output is visible
    if config.config_file_name is not None:
        fileConfig(config.config_file_name)

    settings = BluefoxSettings()
    discover_models(settings)

    db_url = normalize_database_url(settings.DATABASE_URL)

    if context.is_offline_mode():
        context.configure(
            url=db_url,
            target_metadata=BluefoxBase.metadata,
            literal_binds=True,
            dialect_opts={"paramstyle": "named"},
        )
        with context.begin_transaction():
            context.run_migrations()
    else:
        config.set_main_option("sqlalchemy.url", db_url)

        connectable = async_engine_from_config(
            config.get_section(config.config_ini_section, {}),
            prefix="sqlalchemy.",
            poolclass=pool.NullPool,
        )

        async def run_async() -> None:
            async with connectable.connect() as connection:
                await connection.run_sync(lambda conn: _run_migrations(conn, context))
            await connectable.dispose()

        asyncio.run(run_async())
