"""
openenv-halluguard SDK v1.0.0
==============================
The easiest way to evaluate any LLM for hallucination using HallucinationGuard-Env.

Install:
    pip install openenv-halluguard

Usage (3 lines):
    from openenv_halluguard import HallucinationGuardEnv
    env = HallucinationGuardEnv()
    results = env.evaluate(your_model_fn, episodes=5)

Full example:
    import anthropic
    client = anthropic.Anthropic(api_key="...")

    def my_model(question, context):
        msg = client.messages.create(
            model="claude-3-haiku-20240307",
            max_tokens=256,
            messages=[{"role": "user", "content": f"Context: {context}\\n\\nQuestion: {question}\\n\\nAnswer using ONLY the context."}]
        )
        return msg.content[0].text

    env = HallucinationGuardEnv()
    results = env.evaluate(my_model, episodes=5, model_name="claude-3-haiku")
    env.print_report(results)
"""

__version__ = "1.0.0"
__all__ = ["HallucinationGuardEnv"]

from .env import HallucinationGuardEnv
