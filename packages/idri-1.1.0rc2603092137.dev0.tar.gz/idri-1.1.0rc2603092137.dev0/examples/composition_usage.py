from __future__ import annotations

from idri import (
    IdentifierEncoder,
    compose_texts,
    compose_vectors,
    cosine_similarity,
    topk_by_similarity,
)

enc = IdentifierEncoder()

v1 = enc.encode("F0032-3", family="invoice")
v2 = enc.encode("F0032", family="invoice")

composed = compose_vectors([(v1, 0.6), (v2, 0.4)])
composed_from_text = compose_texts(enc, [("F0032-3", 0.6), ("F0032", 0.4)], family="invoice")

composer = enc.start_composer(normalize_output=True)
composer.add_text("F0032-3", weight=0.6, family="invoice")
composer.add_text("F0032", weight=0.4, family="invoice")
incremental = composer.build()

candidates = enc.batch_encode(["F0032-3", "F0032", "A1900"], family="invoice")
top_idx, top_scores = topk_by_similarity(composed, candidates, k=2)

print("composed dot incremental:", round(cosine_similarity(composed, incremental), 6))
print("compose_texts dot composed:", round(cosine_similarity(composed_from_text, composed), 6))
print("top-k indices:", top_idx.tolist())
print("top-k scores:", [round(float(score), 6) for score in top_scores])
print("composer explain:", composer.explain(top_k=5))
