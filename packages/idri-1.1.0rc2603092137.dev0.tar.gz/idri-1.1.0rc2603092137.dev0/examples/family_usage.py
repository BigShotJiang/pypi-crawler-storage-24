from __future__ import annotations

from idri import IdentifierEncoder

enc = IdentifierEncoder()

vec = enc.encode("INV-2024-001-03", family="invoice")
score = enc.similarity("INV-2024-001", "INV-2024-001-03", family="invoice")

print("invoice vector shape:", vec.shape)
print("invoice similarity:", round(score, 4))
