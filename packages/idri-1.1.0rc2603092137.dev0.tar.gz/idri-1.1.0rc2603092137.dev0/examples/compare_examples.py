from __future__ import annotations

from idri import IdentifierEncoder

pairs = [
    ("ACME INDUSTRIAL SA DE CV", "ACME INDUSTRIAL"),
    ("INV-2024-001-03", "INV-2024-001"),
    ("TRUPER PULIDORA 4 1/2", "TRUPER PULIDORA 4 1 2"),
    ("OMNISPHERE WM", "OMNISPHERE"),
]

enc = IdentifierEncoder(profile="word_ngram")

for a, b in pairs:
    print(f"{a!r} vs {b!r} -> {enc.similarity(a, b):.4f}")
