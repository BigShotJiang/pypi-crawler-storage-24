from __future__ import annotations

from idri import IdentifierEncoder, normalize_text

enc = IdentifierEncoder()

vec = enc.encode("ACME Industrial SA de CV")
score = enc.similarity("ACME Industrial", "ACME Industrial SA de CV")
explanation = enc.explain("ACME Industrial", "ACME Industrial SA de CV")

print("normalized:", normalize_text("  ACME   Industrial SA de CV  "))
print("vector shape:", vec.shape)
print("score:", round(score, 4))
print("top words:", explanation["top_word_overlaps"])
