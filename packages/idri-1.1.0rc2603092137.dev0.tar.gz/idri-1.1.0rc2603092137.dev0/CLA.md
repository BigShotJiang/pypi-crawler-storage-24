# Contributor License Agreement (CLA)

By submitting a contribution (code, docs, tests, assets, or any other material) to this repository, you agree to the following:

1. You represent that you have the legal right to submit the contribution.
2. You grant the project maintainer a perpetual, worldwide, non-exclusive, irrevocable, royalty-free license to use, reproduce, modify, display, perform, distribute, sublicense, and relicense your contribution.
3. This grant includes the right to distribute your contribution under:
   - the repository's open source license (MPL-2.0), and
   - separate commercial or proprietary licenses.
4. You agree that your contribution is provided "as is" without warranties or conditions of any kind.

If your employer or another agreement may affect these terms, only contribute with proper authorization.
