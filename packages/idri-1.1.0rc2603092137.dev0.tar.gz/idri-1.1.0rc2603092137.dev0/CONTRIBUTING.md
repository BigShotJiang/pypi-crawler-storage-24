# Contributing

Thanks for your interest in contributing to `idri`.

## Requirements

1. Open an issue or draft PR for non-trivial changes.
2. Keep the scope aligned with the project's goal: deterministic vectorization primitives for short identifiers/labels.
3. Add or update tests for behavior changes.
4. Run local checks before opening a PR:

```bash
uv sync
uv run pytest
uv run pytest --cov=idri --cov-report=term-missing
```

## CLA and Dual Licensing

This project uses an open-source + consulting/commercial model.

By opening a pull request, you agree to the terms in [CLA.md](CLA.md), including permission for the maintainer to relicense contributions under commercial/proprietary terms.

If you do not agree with that, please do not submit a contribution.
