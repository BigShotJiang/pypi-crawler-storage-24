from __future__ import annotations

import numpy as np
import pytest

from idri import (
    IdentifierEncoder,
    cosine_similarity,
    cosine_similarity_matrix,
    l2_distance,
    topk_by_similarity,
)


def test_cosine_similarity_for_normalized_vectors() -> None:
    enc = IdentifierEncoder()
    v = enc.encode("acme")
    assert cosine_similarity(v, v, assume_normalized=True) == pytest.approx(1.0, rel=1e-6)


def test_cosine_similarity_can_normalize_inputs() -> None:
    enc = IdentifierEncoder()
    v = enc.encode("invoice")
    scaled_a = v * 3.0
    scaled_b = v * 0.5
    score = cosine_similarity(scaled_a, scaled_b, assume_normalized=False)
    assert score == pytest.approx(1.0, rel=1e-6)


def test_cosine_similarity_shape_mismatch_raises() -> None:
    with pytest.raises(ValueError):
        cosine_similarity(np.zeros(32, dtype=np.float32), np.zeros(16, dtype=np.float32))


def test_l2_distance_for_identical_vectors_is_zero() -> None:
    enc = IdentifierEncoder()
    v = enc.encode("invoice")
    assert l2_distance(v, v) == pytest.approx(0.0, abs=1e-7)


def test_cosine_similarity_matrix_supports_one_to_many() -> None:
    enc = IdentifierEncoder(dim=128)
    query = enc.encode("invoice 001")
    candidates = enc.batch_encode(["invoice 001", "invoice 002", "hammer drill"])

    scores = cosine_similarity_matrix(query, candidates)

    assert scores.shape == (3,)
    assert scores[0] == pytest.approx(1.0, rel=1e-6)
    assert scores[0] > scores[2]


def test_cosine_similarity_matrix_can_normalize_scaled_inputs() -> None:
    enc = IdentifierEncoder(dim=128)
    query = enc.encode("invoice 001") * 4.0
    candidates = enc.batch_encode(["invoice 001", "invoice 002"]) * 0.5

    scores = cosine_similarity_matrix(query, candidates, assume_normalized=False)

    assert scores.shape == (2,)
    assert scores[0] == pytest.approx(1.0, rel=1e-6)


def test_topk_by_similarity_returns_ranked_indices_and_scores() -> None:
    enc = IdentifierEncoder(dim=128)
    query = enc.encode("invoice 001")
    candidates = enc.batch_encode(["hammer", "invoice 002", "invoice 001"])

    indices, scores = topk_by_similarity(query, candidates, k=2)

    assert indices.shape == (2,)
    assert scores.shape == (2,)
    assert int(indices[0]) == 2
    assert scores[0] >= scores[1]
