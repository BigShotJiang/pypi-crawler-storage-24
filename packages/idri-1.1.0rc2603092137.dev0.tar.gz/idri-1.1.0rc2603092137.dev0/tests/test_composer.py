from __future__ import annotations

import numpy as np

from idri import IdentifierEncoder, compose_vectors


def test_incremental_composer_matches_direct_composition() -> None:
    enc = IdentifierEncoder(dim=512)

    v1 = enc.encode("F0032-3", family="invoice")
    v2 = enc.encode("F0032", family="invoice")
    expected = compose_vectors([(v1, 0.6), (v2, 0.4)])

    composer = enc.start_composer(normalize_output=True)
    composer.add_text("F0032-3", weight=0.6, family="invoice")
    composer.add_text("F0032", weight=0.4, family="invoice")
    built = composer.build()

    assert np.allclose(expected, built, atol=1e-6)


def test_composer_add_vector_and_reset() -> None:
    enc = IdentifierEncoder(dim=128)
    composer = enc.start_composer()

    composer.add_vector(enc.encode("alpha"), weight=1.0)
    vec = composer.build()
    assert vec.shape == (128,)

    composer.reset()
    reset_vec = composer.build(normalize=False)
    assert np.allclose(reset_vec, np.zeros(128, dtype=np.float32))


def test_composer_explain_shape() -> None:
    enc = IdentifierEncoder()
    composer = enc.start_composer()
    composer.add_text("ACME Industrial", weight=0.8)
    composer.add_text("ACME", weight=0.2)

    info = composer.explain(top_k=5)
    assert "top_text_features" in info
    assert info["num_text_items"] == 2
