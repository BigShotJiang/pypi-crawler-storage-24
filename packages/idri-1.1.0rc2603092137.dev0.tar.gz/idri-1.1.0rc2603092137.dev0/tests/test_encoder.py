from __future__ import annotations

import numpy as np

from idri import IdentifierEncoder, cosine_similarity


def test_deterministic_encoding() -> None:
    enc = IdentifierEncoder()
    v1 = enc.encode("ACME Industrial SA de CV")
    v2 = enc.encode("ACME Industrial SA de CV")
    assert np.array_equal(v1, v2)


def test_identical_strings_high_similarity() -> None:
    enc = IdentifierEncoder()
    score = enc.similarity("INV-2024-001-03", "INV-2024-001-03")
    assert score > 0.999


def test_truncated_name_scores_higher_than_unrelated() -> None:
    enc = IdentifierEncoder()
    trunc = enc.similarity("ACME INDUSTRIAL SA DE CV", "ACME INDUSTRIAL")
    unrelated = enc.similarity("ACME INDUSTRIAL SA DE CV", "GALAXY BANANA MIXER")
    assert trunc > unrelated


def test_family_changes_vector_space() -> None:
    enc = IdentifierEncoder()
    base = enc.encode("INV-2024-001")
    invoice = enc.encode("INV-2024-001", family="invoice")
    assert cosine_similarity(base, invoice) < 0.999


def test_batch_encode_shape_and_dtype() -> None:
    enc = IdentifierEncoder(dim=256)
    mat = enc.batch_encode(["a", "b", "c"])
    assert mat.shape == (3, 256)
    assert mat.dtype == np.float32


def test_empty_similarity_returns_zero() -> None:
    enc = IdentifierEncoder()
    assert enc.similarity("", "") == 0.0
