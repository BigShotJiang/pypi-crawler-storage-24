from __future__ import annotations

from idri import IdentifierEncoder


def test_explain_output_shape_and_fields() -> None:
    enc = IdentifierEncoder()
    out = enc.explain("ACME Industrial", "ACME Industrial SA de CV", family="vendor", top_k=3)

    assert set(out.keys()) == {"score", "top_word_overlaps", "top_ngram_overlaps", "profile", "family"}
    assert out["profile"] == "word_ngram"
    assert out["family"] == "vendor"
    assert len(out["top_word_overlaps"]) <= 3
    assert len(out["top_ngram_overlaps"]) <= 3


def test_explain_is_stable_for_same_inputs() -> None:
    enc = IdentifierEncoder()
    a = enc.explain("hammer drill set", "drill set", top_k=5)
    b = enc.explain("hammer drill set", "drill set", top_k=5)
    assert a == b


def test_explain_contains_expected_word_overlap_tokens() -> None:
    enc = IdentifierEncoder()
    out = enc.explain("acme industrial", "acme industrial sa", top_k=10)
    tokens = {token for token, _ in out["top_word_overlaps"]}
    assert "acme" in tokens
    assert "industrial" in tokens
