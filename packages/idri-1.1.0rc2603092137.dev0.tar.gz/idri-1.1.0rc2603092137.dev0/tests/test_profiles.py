from __future__ import annotations

import pytest

from idri import IdentifierEncoder, available_profiles, normalize_text


def test_word_profile_has_no_ngram_overlaps() -> None:
    enc = IdentifierEncoder(profile="word")
    result = enc.explain("hammer drill", "drill", top_k=5)
    assert result["top_ngram_overlaps"] == []


def test_word_ngram_is_more_robust_than_word_for_ocrish_text() -> None:
    a = "TRUPER PULIDORA 4 1/2"
    b = "TRUPER PULIDORA 4 1 2"

    sim_word = IdentifierEncoder(profile="word").similarity(a, b)
    sim_ngram = IdentifierEncoder(profile="word_ngram").similarity(a, b)
    assert sim_ngram >= sim_word


def test_position_profile_prefers_same_order() -> None:
    enc = IdentifierEncoder(profile="word_ngram_position")
    same = enc.similarity("alpha beta gamma", "alpha beta gamma")
    shuffled = enc.similarity("alpha beta gamma", "gamma beta alpha")
    assert same > shuffled


def test_invalid_profile_raises() -> None:
    with pytest.raises(ValueError):
        IdentifierEncoder(profile="does_not_exist")


def test_available_profiles_are_sorted() -> None:
    assert available_profiles() == ("word", "word_ngram", "word_ngram_position")


def test_normalize_text_collapses_whitespace() -> None:
    assert normalize_text("  ACME   Industrial  ") == "acme industrial"
