## Summary

Describe what changed and why.

## Checklist

- [ ] I ran `uv run pytest` locally.
- [ ] I added/updated tests for behavior changes.
- [ ] I read and agree to the terms in `CLA.md`.
