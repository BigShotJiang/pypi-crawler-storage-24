# Changelog

## v1.1.0rc2603092136

### API cleanup

- added `compose_texts(...)` for encode-and-compose workflows that do not need `VectorComposer`
- added `cosine_similarity_matrix(...)` and `topk_by_similarity(...)` for one-to-many retrieval workflows
- tightened public array typing around `numpy.typing.ArrayLike` inputs and `NDArray[np.float32]` outputs where behavior is fixed to float32

### Docs and examples

- documented the new retrieval helpers and the `compose_texts(...)` shortcut

## v1.0.0rc2603092115

### API cleanup

- moved vector-level operations to top-level exports: `compose_vectors(...)`, `cosine_similarity(...)`, `l2_distance(...)`, and `l2_normalize(...)`
- removed `IdentifierEncoder.compose_vectors(...)` and `IdentifierEncoder.cosine_similarity(...)` so `IdentifierEncoder` stays focused on text encoding and explanation
- made `compose_vectors(...)` infer vector dimension from the first input vector and require `dim=` only when composing an empty list
- added public utility exports `available_profiles()` and `normalize_text(...)`

### Docs and examples

- updated examples, tests, and README snippets to use the new free-function API
- aligned the design docs with the new public surface and the new `l2_distance(...)` helper
