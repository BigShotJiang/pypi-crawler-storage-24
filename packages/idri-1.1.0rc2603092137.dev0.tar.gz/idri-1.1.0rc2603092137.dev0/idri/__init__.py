"""Public package exports for idri."""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version

from .composer import VectorComposer, compose_texts, compose_vectors
from .encoder import IdentifierEncoder
from .profiles import available_profiles
from .similarity import cosine_similarity, cosine_similarity_matrix, l2_distance, l2_normalize, topk_by_similarity
from .utils import normalize_text

try:
    __version__ = version("idri")
except PackageNotFoundError:
    __version__ = "0.0.0"

__all__ = [
    "IdentifierEncoder",
    "VectorComposer",
    "available_profiles",
    "compose_texts",
    "compose_vectors",
    "cosine_similarity",
    "cosine_similarity_matrix",
    "l2_distance",
    "l2_normalize",
    "normalize_text",
    "topk_by_similarity",
    "__version__",
]
