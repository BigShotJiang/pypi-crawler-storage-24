"""Named encoder profile presets."""

from __future__ import annotations

from .ri import RIContextParams


PROFILE_PRESETS: dict[str, RIContextParams] = {
    "word": RIContextParams(
        use_words=True,
        use_chargrams=False,
        gram_min=3,
        gram_max=5,
        max_grams_per_word=40,
        w_family=2.0,
        w_word=1.0,
        w_chargram=0.0,
        position_decay=0.0,
    ),
    "word_ngram": RIContextParams(
        use_words=True,
        use_chargrams=True,
        gram_min=3,
        gram_max=5,
        max_grams_per_word=40,
        w_family=2.0,
        w_word=1.0,
        w_chargram=0.3,
        position_decay=0.0,
    ),
    "word_ngram_position": RIContextParams(
        use_words=True,
        use_chargrams=True,
        gram_min=3,
        gram_max=5,
        max_grams_per_word=40,
        w_family=2.0,
        w_word=1.0,
        w_chargram=0.3,
        position_decay=0.08,
    ),
}


def get_profile_params(profile: str) -> RIContextParams:
    """Return the parameter preset for a named encoder profile."""
    try:
        return PROFILE_PRESETS[profile]
    except KeyError as exc:
        names = ", ".join(sorted(PROFILE_PRESETS))
        raise ValueError(f"Unknown profile '{profile}'. Available profiles: {names}") from exc


def profile_names() -> tuple[str, ...]:
    """Return the sorted list of supported profile names."""
    return tuple(sorted(PROFILE_PRESETS))


available_profiles = profile_names
