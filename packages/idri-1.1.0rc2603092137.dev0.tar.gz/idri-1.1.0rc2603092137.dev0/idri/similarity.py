"""Vector-level similarity and distance helpers."""

from __future__ import annotations

import numpy as np

from .ri import dense_l2_normalize
from .types import ArrayLike, FloatArray, SimilarityTopK


def _as_float32_array(value: ArrayLike, name: str) -> FloatArray:
    """Coerce array-like input to a float32 NumPy array."""
    arr = np.asarray(value, dtype=np.float32)
    if arr.ndim not in (1, 2):
        raise ValueError(f"{name} must be a 1D or 2D array, got shape {arr.shape}")
    return arr


def _l2_normalize_rows(arr: FloatArray) -> FloatArray:
    """L2-normalize a 1D vector or each row of a 2D matrix."""
    if arr.ndim == 1:
        return dense_l2_normalize(arr)

    norms = np.linalg.norm(arr, axis=1, keepdims=True).astype(np.float32, copy=False)
    safe_norms = np.where(norms > 0, norms, np.float32(1.0))
    return (arr / safe_norms).astype(np.float32, copy=False)


def cosine_similarity(vec_a: ArrayLike, vec_b: ArrayLike, assume_normalized: bool = True) -> float:
    """Compute cosine similarity for two dense vectors.

    When ``assume_normalized`` is true, the function uses a direct dot product.
    Otherwise both inputs are L2-normalized first, which is safer for vectors
    that may come from external composition steps.
    """
    a = _as_float32_array(vec_a, "vec_a")
    b = _as_float32_array(vec_b, "vec_b")

    if a.ndim != 1 or b.ndim != 1:
        raise ValueError("cosine_similarity expects 1D vectors")

    if a.shape != b.shape:
        raise ValueError(f"Vector shapes must match: {a.shape} != {b.shape}")

    if not assume_normalized:
        a = dense_l2_normalize(a)
        b = dense_l2_normalize(b)

    return float(np.dot(a, b))


def l2_distance(vec_a: ArrayLike, vec_b: ArrayLike) -> float:
    """Compute Euclidean distance for two dense vectors."""
    a = _as_float32_array(vec_a, "vec_a")
    b = _as_float32_array(vec_b, "vec_b")

    if a.ndim != 1 or b.ndim != 1:
        raise ValueError("l2_distance expects 1D vectors")

    if a.shape != b.shape:
        raise ValueError(f"Vector shapes must match: {a.shape} != {b.shape}")

    return float(np.linalg.norm(a - b))


def cosine_similarity_matrix(
    query: ArrayLike,
    candidates: ArrayLike,
    assume_normalized: bool = True,
) -> FloatArray:
    """Compute one-to-many or many-to-many cosine similarity scores."""
    q = _as_float32_array(query, "query")
    c = _as_float32_array(candidates, "candidates")
    squeeze_query = q.ndim == 1

    if q.ndim == 1:
        q = q.reshape(1, -1)
    if c.ndim == 1:
        c = c.reshape(1, -1)

    if q.shape[1] != c.shape[1]:
        raise ValueError(f"Vector dimensions must match: {q.shape[1]} != {c.shape[1]}")

    if not assume_normalized:
        q = _l2_normalize_rows(q)
        c = _l2_normalize_rows(c)

    scores = (q @ c.T).astype(np.float32, copy=False)
    return scores[0] if squeeze_query else scores


def topk_by_similarity(
    query: ArrayLike,
    candidates: ArrayLike,
    k: int = 10,
    assume_normalized: bool = True,
) -> SimilarityTopK:
    """Return the top-k candidate indices and cosine scores for one query."""
    scores = cosine_similarity_matrix(query, candidates, assume_normalized=assume_normalized)
    if scores.ndim != 1:
        raise ValueError("topk_by_similarity expects a single 1D query vector")

    count = scores.shape[0]
    k = max(0, int(k))
    if k == 0 or count == 0:
        return np.zeros(0, dtype=np.int64), np.zeros(0, dtype=np.float32)

    k = min(k, count)
    part = np.argpartition(scores, -k)[-k:]
    order = np.argsort(scores[part])[::-1]
    indices = part[order].astype(np.int64, copy=False)
    return indices, scores[indices].astype(np.float32, copy=False)


def l2_normalize(vec: ArrayLike) -> FloatArray:
    """Return an L2-normalized dense vector, preserving zero vectors."""
    arr = _as_float32_array(vec, "vec")
    if arr.ndim != 1:
        raise ValueError("l2_normalize expects a 1D vector")
    return dense_l2_normalize(arr)
