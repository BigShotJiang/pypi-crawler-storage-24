"""Small normalization helpers shared by the encoder."""

from __future__ import annotations


def simple_normalize(text: str) -> str:
    """Minimal normalizer: lowercase, trim, collapse internal whitespace."""
    return " ".join((text or "").lower().strip().split())


normalize_text = simple_normalize


def resolve_family(family: str | None) -> str:
    """Return a normalized family label, defaulting empty values to ``generic``."""
    fam = simple_normalize(family or "generic")
    return fam or "generic"
