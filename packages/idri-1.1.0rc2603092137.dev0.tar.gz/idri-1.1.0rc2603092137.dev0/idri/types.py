"""Shared type aliases used across the package."""

from __future__ import annotations

from typing import Any, Sequence, TypeAlias

import numpy as np
import numpy.typing as npt

ArrayLike: TypeAlias = npt.ArrayLike
FloatArray: TypeAlias = npt.NDArray[np.float32]
FloatingArray: TypeAlias = npt.NDArray[np.floating[Any]]
IndexArray: TypeAlias = npt.NDArray[np.int64]

# Sparse random-indexing vector represented as index -> weight.
SparseVector: TypeAlias = dict[int, float]
# Ordered feature log used for explainability and debugging.
FeatureLog: TypeAlias = list[tuple[str, float]]
# Aggregated feature contribution map keyed by feature token.
FeatureMap: TypeAlias = dict[str, float]
# Dense vectors paired with scalar composition weights.
WeightedDenseVectors: TypeAlias = Sequence[tuple[ArrayLike, float]]
# Raw texts paired with scalar composition weights.
WeightedTexts: TypeAlias = Sequence[tuple[str, float]]
# Ranked retrieval result represented as candidate indices and scores.
SimilarityTopK: TypeAlias = tuple[IndexArray, FloatArray]
