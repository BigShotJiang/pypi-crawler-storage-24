"""
LlamaIndex Integration for Sensoit Guardrails
Node postprocessor for RAG pipeline guardrails
"""

from typing import Any, Dict, List, Optional, Sequence
from llama_index.core.postprocessor.types import BaseNodePostprocessor
from llama_index.core.schema import NodeWithScore, QueryBundle

from .client import SensoitClient
from .types import GuardrailCheckRequest, GuardrailResult


class SensoitQueryFilter(BaseNodePostprocessor):
    """
    LlamaIndex node postprocessor for Sensoit guardrails.
    Filters retrieved nodes based on guardrail checks.

    Usage:
        from sensoit.llamaindex import SensoitQueryFilter

        guardrail_filter = SensoitQueryFilter(
            api_key="sk-...",
            prompt_id="prompt_xxx"
        )

        query_engine = index.as_query_engine(
            node_postprocessors=[guardrail_filter]
        )
    """

    def __init__(
        self,
        api_key: str,
        prompt_id: str,
        *,
        base_url: str = "https://api.sensoit.io",
        filter_violations: bool = True,
        check_query: bool = True,
        check_nodes: bool = True,
        guardrail_types: Optional[List[str]] = None,
        min_confidence: float = 0.8,
    ):
        """
        Initialize Sensoit query filter.

        Args:
            api_key: Sensoit API key
            prompt_id: ID of the prompt to check against
            base_url: Sensoit API base URL
            filter_violations: If True, removes nodes that violate guardrails
            check_query: If True, checks the user query
            check_nodes: If True, checks retrieved node content
            guardrail_types: Specific guardrails to run (default: all)
            min_confidence: Minimum confidence to consider a violation
        """
        super().__init__()
        self.client = SensoitClient(api_key=api_key, base_url=base_url)
        self.prompt_id = prompt_id
        self.filter_violations = filter_violations
        self.check_query = check_query
        self.check_nodes = check_nodes
        self.guardrail_types = guardrail_types
        self.min_confidence = min_confidence
        self._query_result: Optional[GuardrailResult] = None
        self._node_results: Dict[str, GuardrailResult] = {}

    @property
    def query_result(self) -> Optional[GuardrailResult]:
        """Get the result of the query guardrail check."""
        return self._query_result

    @property
    def node_results(self) -> Dict[str, GuardrailResult]:
        """Get results of node guardrail checks."""
        return self._node_results

    def _check_guardrails(self, text: str, check_type: str = "input") -> GuardrailResult:
        """Run guardrail check on text."""
        request = GuardrailCheckRequest(
            prompt_id=self.prompt_id,
            text=text,
            check_type=check_type,
            guardrail_types=self.guardrail_types,
        )
        return self.client.guardrails.check(request)

    def _postprocess_nodes(
        self,
        nodes: List[NodeWithScore],
        query_bundle: Optional[QueryBundle] = None,
    ) -> List[NodeWithScore]:
        """
        Filter nodes based on guardrail checks.

        Args:
            nodes: List of retrieved nodes with scores
            query_bundle: The query bundle containing the user query

        Returns:
            Filtered list of nodes
        """
        # Check query if enabled
        if self.check_query and query_bundle is not None:
            query_text = query_bundle.query_str
            self._query_result = self._check_guardrails(query_text, "input")

            if not self._query_result.passed:
                violations = [v for v in self._query_result.violations
                             if v.confidence >= self.min_confidence]
                if violations:
                    raise QueryViolationError(
                        f"Query violates guardrails: {[v.guardrail_type for v in violations]}",
                        result=self._query_result
                    )

        # Check nodes if enabled
        if not self.check_nodes:
            return nodes

        filtered_nodes = []
        self._node_results = {}

        for node_with_score in nodes:
            node_id = node_with_score.node.node_id or str(id(node_with_score))
            node_text = node_with_score.node.get_content()

            result = self._check_guardrails(node_text, "context")
            self._node_results[node_id] = result

            if result.passed:
                filtered_nodes.append(node_with_score)
            elif not self.filter_violations:
                # Add metadata about violations but keep the node
                node_with_score.node.metadata["guardrail_violations"] = [
                    {
                        "type": v.guardrail_type,
                        "confidence": v.confidence,
                        "reason": v.reason,
                    }
                    for v in result.violations
                ]
                filtered_nodes.append(node_with_score)
            # If filter_violations is True and node failed, it's excluded

        return filtered_nodes

    @classmethod
    def class_name(cls) -> str:
        return "SensoitQueryFilter"


class SensoitResponseGuardrail:
    """
    Response synthesizer wrapper for checking generated responses.

    Usage:
        from sensoit.llamaindex import SensoitResponseGuardrail

        response_guardrail = SensoitResponseGuardrail(
            api_key="sk-...",
            prompt_id="prompt_xxx"
        )

        # Wrap your response synthesizer
        response = response_guardrail.check(synthesizer.synthesize(query, nodes))
    """

    def __init__(
        self,
        api_key: str,
        prompt_id: str,
        *,
        base_url: str = "https://api.sensoit.io",
        block_on_violation: bool = True,
        guardrail_types: Optional[List[str]] = None,
    ):
        self.client = SensoitClient(api_key=api_key, base_url=base_url)
        self.prompt_id = prompt_id
        self.block_on_violation = block_on_violation
        self.guardrail_types = guardrail_types
        self._last_result: Optional[GuardrailResult] = None

    @property
    def last_result(self) -> Optional[GuardrailResult]:
        return self._last_result

    def check(self, response: Any) -> Any:
        """
        Check a response against guardrails.

        Args:
            response: LlamaIndex response object

        Returns:
            The original response if passed

        Raises:
            ResponseViolationError: If response violates guardrails
        """
        response_text = str(response)

        request = GuardrailCheckRequest(
            prompt_id=self.prompt_id,
            text=response_text,
            check_type="output",
            guardrail_types=self.guardrail_types,
        )

        self._last_result = self.client.guardrails.check(request)

        if not self._last_result.passed and self.block_on_violation:
            violations = [v.guardrail_type for v in self._last_result.violations]
            raise ResponseViolationError(
                f"Response violates guardrails: {violations}",
                result=self._last_result
            )

        return response


class QueryViolationError(Exception):
    """Exception raised when query violates guardrails."""

    def __init__(self, message: str, result: GuardrailResult):
        super().__init__(message)
        self.result = result
        self.violations = result.violations


class ResponseViolationError(Exception):
    """Exception raised when response violates guardrails."""

    def __init__(self, message: str, result: GuardrailResult):
        super().__init__(message)
        self.result = result
        self.violations = result.violations


# Convenience functions
def create_query_filter(
    api_key: str,
    prompt_id: str,
    **kwargs: Any,
) -> SensoitQueryFilter:
    """Create a Sensoit query filter for LlamaIndex."""
    return SensoitQueryFilter(api_key=api_key, prompt_id=prompt_id, **kwargs)


def create_response_guardrail(
    api_key: str,
    prompt_id: str,
    **kwargs: Any,
) -> SensoitResponseGuardrail:
    """Create a Sensoit response guardrail for LlamaIndex."""
    return SensoitResponseGuardrail(api_key=api_key, prompt_id=prompt_id, **kwargs)
