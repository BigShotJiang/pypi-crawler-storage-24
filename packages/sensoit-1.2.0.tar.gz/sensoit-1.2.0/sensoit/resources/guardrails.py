"""Sensoit Guardrails Resource - Manage guardrail policies and run checks."""

from typing import Any, Callable, Coroutine, Dict, List, Optional

from ..types import (
    GuardrailPolicy,
    CreateGuardrailOptions,
    UpdateGuardrailOptions,
    GuardrailCheckOptions,
    GuardrailCheckResult,
    GuardrailDryRunOptions,
    GuardrailDryRunResult,
    GuardrailExplainOptions,
    GuardrailExplainResult,
    GuardrailBatchOptions,
    GuardrailBatchResult,
    AIServiceMetrics,
    ViolationLog,
    ListOptions,
    PaginatedResponse,
)


class GuardrailsResource:
    """Guardrails resource for managing policies and running checks."""

    def __init__(
        self,
        request_async: Callable[..., Coroutine[Any, Any, Dict[str, Any]]],
        request_sync: Callable[..., Dict[str, Any]],
    ):
        self._request_async = request_async
        self._request_sync = request_sync

    async def check(self, options: GuardrailCheckOptions) -> GuardrailCheckResult:
        """Check text against guardrail policies."""
        data = await self._request_async(
            "POST",
            "/api/guardrails/check",
            json=options.model_dump(by_alias=True, exclude_none=True),
        )
        return GuardrailCheckResult(**data)

    def check_sync(self, options: GuardrailCheckOptions) -> GuardrailCheckResult:
        """Check text against guardrail policies (sync)."""
        data = self._request_sync(
            "POST",
            "/api/guardrails/check",
            json=options.model_dump(by_alias=True, exclude_none=True),
        )
        return GuardrailCheckResult(**data)

    async def list(self, options: Optional[ListOptions] = None) -> PaginatedResponse:
        """List all guardrail policies."""
        params = {}
        if options:
            if options.page:
                params["page"] = options.page
            if options.limit:
                params["limit"] = options.limit
            if options.search:
                params["search"] = options.search

        query = "&".join(f"{k}={v}" for k, v in params.items())
        path = f"/api/guardrails/policies?{query}" if query else "/api/guardrails/policies"
        data = await self._request_async("GET", path)
        return PaginatedResponse(**data)

    def list_sync(self, options: Optional[ListOptions] = None) -> PaginatedResponse:
        """List all guardrail policies (sync)."""
        params = {}
        if options:
            if options.page:
                params["page"] = options.page
            if options.limit:
                params["limit"] = options.limit

        query = "&".join(f"{k}={v}" for k, v in params.items())
        path = f"/api/guardrails/policies?{query}" if query else "/api/guardrails/policies"
        data = self._request_sync("GET", path)
        return PaginatedResponse(**data)

    async def get(self, policy_id: str) -> GuardrailPolicy:
        """Get a guardrail policy by ID."""
        data = await self._request_async("GET", f"/api/guardrails/policies/{policy_id}")
        return GuardrailPolicy(**data)

    def get_sync(self, policy_id: str) -> GuardrailPolicy:
        """Get a guardrail policy by ID (sync)."""
        data = self._request_sync("GET", f"/api/guardrails/policies/{policy_id}")
        return GuardrailPolicy(**data)

    async def create(self, options: CreateGuardrailOptions) -> GuardrailPolicy:
        """Create a new guardrail policy."""
        data = await self._request_async(
            "POST",
            "/api/guardrails/policies",
            json=options.model_dump(by_alias=True, exclude_none=True),
        )
        return GuardrailPolicy(**data)

    def create_sync(self, options: CreateGuardrailOptions) -> GuardrailPolicy:
        """Create a new guardrail policy (sync)."""
        data = self._request_sync(
            "POST",
            "/api/guardrails/policies",
            json=options.model_dump(by_alias=True, exclude_none=True),
        )
        return GuardrailPolicy(**data)

    async def update(
        self, policy_id: str, options: UpdateGuardrailOptions
    ) -> GuardrailPolicy:
        """Update a guardrail policy."""
        data = await self._request_async(
            "PUT",
            f"/api/guardrails/policies/{policy_id}",
            json=options.model_dump(by_alias=True, exclude_none=True),
        )
        return GuardrailPolicy(**data)

    def update_sync(
        self, policy_id: str, options: UpdateGuardrailOptions
    ) -> GuardrailPolicy:
        """Update a guardrail policy (sync)."""
        data = self._request_sync(
            "PUT",
            f"/api/guardrails/policies/{policy_id}",
            json=options.model_dump(by_alias=True, exclude_none=True),
        )
        return GuardrailPolicy(**data)

    async def delete(self, policy_id: str) -> None:
        """Delete a guardrail policy."""
        await self._request_async("DELETE", f"/api/guardrails/policies/{policy_id}")

    def delete_sync(self, policy_id: str) -> None:
        """Delete a guardrail policy (sync)."""
        self._request_sync("DELETE", f"/api/guardrails/policies/{policy_id}")

    async def violations(
        self, options: Optional[ListOptions] = None
    ) -> PaginatedResponse:
        """List violation events."""
        params = {}
        if options:
            if options.page:
                params["page"] = options.page
            if options.limit:
                params["limit"] = options.limit

        query = "&".join(f"{k}={v}" for k, v in params.items())
        path = f"/api/guardrails/violations?{query}" if query else "/api/guardrails/violations"
        data = await self._request_async("GET", path)
        return PaginatedResponse(**data)

    def violations_sync(
        self, options: Optional[ListOptions] = None
    ) -> PaginatedResponse:
        """List violation events (sync)."""
        params = {}
        if options:
            if options.page:
                params["page"] = options.page
            if options.limit:
                params["limit"] = options.limit

        query = "&".join(f"{k}={v}" for k, v in params.items())
        path = f"/api/guardrails/violations?{query}" if query else "/api/guardrails/violations"
        data = self._request_sync("GET", path)
        return PaginatedResponse(**data)

    # =========================================================================
    # Advanced Guardrail Features
    # =========================================================================

    async def dry_run(self, options: GuardrailDryRunOptions) -> GuardrailDryRunResult:
        """
        Dry-run check: Test text against guardrails without blocking.

        Use this to preview what WOULD happen if you sent this text, without
        actually blocking or logging. Great for testing and validation.

        Example:
            result = await gf.guardrails.dry_run(GuardrailDryRunOptions(
                text="My SSN is 123-45-6789",
                industry="fintech",
            ))

            if not result.would_allow:
                print("Would be blocked:", result.violations)
                print("Recommendation:", result.recommendation)
        """
        data = await self._request_async(
            "POST",
            "/api/guardrails/dry-run",
            json=options.model_dump(by_alias=True, exclude_none=True),
        )
        return GuardrailDryRunResult(**data)

    def dry_run_sync(self, options: GuardrailDryRunOptions) -> GuardrailDryRunResult:
        """Dry-run check (sync). See dry_run() for details."""
        data = self._request_sync(
            "POST",
            "/api/guardrails/dry-run",
            json=options.model_dump(by_alias=True, exclude_none=True),
        )
        return GuardrailDryRunResult(**data)

    async def explain(self, options: GuardrailExplainOptions) -> GuardrailExplainResult:
        """
        Explain check: Get detailed explanations for each policy check.

        Returns human-readable explanations, confidence scores, detection methods,
        and suggestions for how to fix violations. Useful for debugging and
        building trust in guardrail decisions.

        Example:
            result = await gf.guardrails.explain(GuardrailExplainOptions(
                text="Contact me at john@example.com",
                industry="healthcare",
            ))

            print("Summary:", result.summary)
            print("Confidence:", result.overall_confidence)

            for policy in result.policy_results:
                print(f"{policy.policy_name}: {policy.explanation}")
                if policy.how_to_fix:
                    print(f"  Fix: {policy.how_to_fix}")
        """
        data = await self._request_async(
            "POST",
            "/api/guardrails/explain",
            json=options.model_dump(by_alias=True, exclude_none=True),
        )
        return GuardrailExplainResult(**data)

    def explain_sync(self, options: GuardrailExplainOptions) -> GuardrailExplainResult:
        """Explain check (sync). See explain() for details."""
        data = self._request_sync(
            "POST",
            "/api/guardrails/explain",
            json=options.model_dump(by_alias=True, exclude_none=True),
        )
        return GuardrailExplainResult(**data)

    async def batch(self, options: GuardrailBatchOptions) -> GuardrailBatchResult:
        """
        Batch check: Process multiple texts in parallel.

        Efficiently validate up to 100 items at once. Uses parallel processing
        for optimal performance. Results include per-item violations and
        aggregate statistics.

        Example:
            result = await gf.guardrails.batch(GuardrailBatchOptions(
                items=[
                    GuardrailBatchItem(id="1", text="First message"),
                    GuardrailBatchItem(id="2", text="Second message"),
                    GuardrailBatchItem(id="3", text="Third message with PII: 555-12-3456"),
                ],
                industry="fintech",
            ))

            print(f"Passed: {result.passed_count}/{result.total_items}")

            for item in result.results:
                if not item.passed:
                    print(f"Item {item.id} failed:", item.violations)
        """
        data = await self._request_async(
            "POST",
            "/api/guardrails/batch",
            json=options.model_dump(by_alias=True, exclude_none=True),
        )
        return GuardrailBatchResult(**data)

    def batch_sync(self, options: GuardrailBatchOptions) -> GuardrailBatchResult:
        """Batch check (sync). See batch() for details."""
        data = self._request_sync(
            "POST",
            "/api/guardrails/batch",
            json=options.model_dump(by_alias=True, exclude_none=True),
        )
        return GuardrailBatchResult(**data)

    async def get_metrics(self) -> AIServiceMetrics:
        """
        Get AI service metrics.

        Returns performance metrics including latency percentiles, cache hit rates,
        error rates, and per-endpoint statistics. Useful for monitoring and debugging.

        Example:
            metrics = await gf.guardrails.get_metrics()

            print("Uptime:", metrics.uptime_seconds, "seconds")
            print("Total checks:", metrics.guardrails.total_checks)
            print("Block rate:", f"{metrics.guardrails.block_rate * 100:.1f}%")
            print("Avg check time:", metrics.guardrails.avg_check_time_ms, "ms")
        """
        data = await self._request_async("GET", "/api/guardrails/metrics")
        return AIServiceMetrics(**data)

    def get_metrics_sync(self) -> AIServiceMetrics:
        """Get AI service metrics (sync). See get_metrics() for details."""
        data = self._request_sync("GET", "/api/guardrails/metrics")
        return AIServiceMetrics(**data)
