"""
LangChain Integration for Sensoit Guardrails
3-line integration for LangChain applications
"""

from typing import Any, Dict, List, Optional, Union
from langchain.callbacks.base import BaseCallbackHandler
from langchain.schema import AgentAction, AgentFinish, LLMResult
from langchain.schema.messages import BaseMessage

from .client import SensoitClient
from .types import GuardrailCheckRequest, GuardrailResult


class SensoitGuardrails(BaseCallbackHandler):
    """
    LangChain callback handler for Sensoit guardrails.

    Usage:
        from sensoit.langchain import SensoitGuardrails

        guardrails = SensoitGuardrails(api_key="sk-...", prompt_id="prompt_xxx")
        llm = ChatOpenAI(callbacks=[guardrails])
    """

    def __init__(
        self,
        api_key: str,
        prompt_id: str,
        *,
        base_url: str = "https://api.sensoit.io",
        block_on_violation: bool = True,
        guardrail_types: Optional[List[str]] = None,
        org_id: Optional[str] = None,
    ):
        """
        Initialize Sensoit guardrails callback.

        Args:
            api_key: Sensoit API key
            prompt_id: ID of the prompt to check against
            base_url: Sensoit API base URL
            block_on_violation: If True, raises exception on violation
            guardrail_types: Specific guardrails to run (default: all)
            org_id: Organization ID (optional, derived from API key)
        """
        super().__init__()
        self.client = SensoitClient(api_key=api_key, base_url=base_url)
        self.prompt_id = prompt_id
        self.block_on_violation = block_on_violation
        self.guardrail_types = guardrail_types
        self.org_id = org_id
        self._last_result: Optional[GuardrailResult] = None

    @property
    def last_result(self) -> Optional[GuardrailResult]:
        """Get the result of the last guardrail check."""
        return self._last_result

    def _check_guardrails(self, text: str, check_type: str = "input") -> GuardrailResult:
        """Run guardrail check on text."""
        request = GuardrailCheckRequest(
            prompt_id=self.prompt_id,
            text=text,
            check_type=check_type,
            guardrail_types=self.guardrail_types,
        )

        result = self.client.guardrails.check(request)
        self._last_result = result

        if not result.passed and self.block_on_violation:
            violations = [v.guardrail_type for v in result.violations]
            raise GuardrailViolationError(
                f"Guardrail violation: {', '.join(violations)}",
                result=result
            )

        return result

    def on_llm_start(
        self,
        serialized: Dict[str, Any],
        prompts: List[str],
        **kwargs: Any,
    ) -> None:
        """Check input prompts before LLM call."""
        for prompt in prompts:
            self._check_guardrails(prompt, "input")

    def on_chat_model_start(
        self,
        serialized: Dict[str, Any],
        messages: List[List[BaseMessage]],
        **kwargs: Any,
    ) -> None:
        """Check chat messages before model call."""
        for message_list in messages:
            for message in message_list:
                if hasattr(message, 'content') and isinstance(message.content, str):
                    self._check_guardrails(message.content, "input")

    def on_llm_end(self, response: LLMResult, **kwargs: Any) -> None:
        """Check LLM output after generation."""
        for generation_list in response.generations:
            for generation in generation_list:
                if hasattr(generation, 'text'):
                    self._check_guardrails(generation.text, "output")

    def on_llm_error(self, error: BaseException, **kwargs: Any) -> None:
        """Handle LLM errors."""
        pass

    def on_chain_start(
        self,
        serialized: Dict[str, Any],
        inputs: Dict[str, Any],
        **kwargs: Any,
    ) -> None:
        """Check chain inputs."""
        for key, value in inputs.items():
            if isinstance(value, str):
                self._check_guardrails(value, "input")

    def on_chain_end(self, outputs: Dict[str, Any], **kwargs: Any) -> None:
        """Check chain outputs."""
        for key, value in outputs.items():
            if isinstance(value, str):
                self._check_guardrails(value, "output")

    def on_tool_start(
        self,
        serialized: Dict[str, Any],
        input_str: str,
        **kwargs: Any,
    ) -> None:
        """Check tool inputs."""
        self._check_guardrails(input_str, "input")

    def on_tool_end(self, output: str, **kwargs: Any) -> None:
        """Check tool outputs."""
        self._check_guardrails(output, "output")

    def on_agent_action(self, action: AgentAction, **kwargs: Any) -> None:
        """Check agent actions."""
        if isinstance(action.tool_input, str):
            self._check_guardrails(action.tool_input, "input")

    def on_agent_finish(self, finish: AgentFinish, **kwargs: Any) -> None:
        """Check agent final output."""
        if isinstance(finish.return_values.get("output"), str):
            self._check_guardrails(finish.return_values["output"], "output")


class GuardrailViolationError(Exception):
    """Exception raised when guardrails detect a violation."""

    def __init__(self, message: str, result: GuardrailResult):
        super().__init__(message)
        self.result = result
        self.violations = result.violations


# Convenience function for quick setup
def create_guardrails(
    api_key: str,
    prompt_id: str,
    **kwargs: Any,
) -> SensoitGuardrails:
    """
    Create a Sensoit guardrails callback handler.

    Usage:
        from sensoit.langchain import create_guardrails

        guardrails = create_guardrails("sk-...", "prompt_xxx")
        llm = ChatOpenAI(callbacks=[guardrails])
    """
    return SensoitGuardrails(api_key=api_key, prompt_id=prompt_id, **kwargs)
