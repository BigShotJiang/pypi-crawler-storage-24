"""
Sensoit Middleware for FastAPI, Flask, and Django.
"""

import json
import logging
from functools import wraps
from typing import Any, Callable, Dict, List, Optional, TypeVar, Union

from .client import Sensoit
from .exceptions import BlockedError, EscalatedError, SensoitError
from .types import RunResult

logger = logging.getLogger("sensoit.middleware")

F = TypeVar("F", bound=Callable[..., Any])


# ============================================================================
# FastAPI / Starlette Middleware
# ============================================================================


class SensoitMiddleware:
    """
    FastAPI/Starlette ASGI middleware for Sensoit.

    Example:
        >>> from fastapi import FastAPI
        >>> from sensoit import Sensoit
        >>> from sensoit.middleware import SensoitMiddleware
        >>>
        >>> app = FastAPI()
        >>> gf = Sensoit(api_key="gf_live_xxx")
        >>>
        >>> app.add_middleware(
        ...     SensoitMiddleware,
        ...     client=gf,
        ...     prompt="default-prompt",
        ...     protected_paths=["/api/chat", "/api/ask"],
        ... )
    """

    def __init__(
        self,
        app: Any,
        client: Union[Sensoit, Callable[[], Sensoit]],
        prompt: str,
        protected_paths: Optional[List[str]] = None,
        extract_input: Optional[Callable[[Dict], str]] = None,
        extract_variables: Optional[Callable[[Dict], Dict[str, str]]] = None,
        blocked_response: Optional[Dict[str, Any]] = None,
        blocked_status_code: int = 200,
        escalated_response: Optional[Dict[str, Any]] = None,
        escalated_status_code: int = 202,
        pass_through: bool = False,
    ):
        self.app = app
        self._client_or_factory = client
        self.prompt = prompt
        self.protected_paths = protected_paths or []
        self.extract_input = extract_input
        self.extract_variables = extract_variables
        self.blocked_response = blocked_response or {
            "error": "Request blocked by security policy"
        }
        self.blocked_status_code = blocked_status_code
        self.escalated_response = escalated_response or {
            "message": "Your request has been escalated for human review"
        }
        self.escalated_status_code = escalated_status_code
        self.pass_through = pass_through

    @property
    def client(self) -> Sensoit:
        """Get Sensoit client (supports lazy loading)."""
        if callable(self._client_or_factory):
            return self._client_or_factory()
        return self._client_or_factory

    async def __call__(
        self,
        scope: Dict[str, Any],
        receive: Callable,
        send: Callable,
    ) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        path = scope.get("path", "")
        method = scope.get("method", "")

        # Check if path should be protected
        should_protect = not self.protected_paths or any(
            path.startswith(p) for p in self.protected_paths
        )

        if not should_protect or method not in ("POST", "PUT", "PATCH"):
            await self.app(scope, receive, send)
            return

        # Read request body
        body = b""
        body_consumed = False

        async def receive_wrapper() -> Dict[str, Any]:
            nonlocal body, body_consumed
            if not body_consumed:
                message = await receive()
                if message["type"] == "http.request":
                    body = message.get("body", b"")
                    body_consumed = True
                return message
            return {"type": "http.request", "body": body}

        # Get first message to capture body
        await receive_wrapper()

        try:
            # Parse body and extract input
            try:
                data = json.loads(body) if body else {}
            except json.JSONDecodeError:
                data = {}

            input_text = None
            if self.extract_input:
                input_text = self.extract_input(data)
            else:
                # Try common field names
                for field in ["input", "message", "text", "query", "content"]:
                    if field in data:
                        input_text = str(data[field])
                        break

            if not input_text:
                # No input found, pass through
                await self._continue_request(scope, send, body)
                return

            # Extract variables
            variables = None
            if self.extract_variables:
                variables = self.extract_variables(data)

            # Run Sensoit
            try:
                result = await self.client.run(
                    self.prompt,
                    input=input_text,
                    variables=variables,
                )

                # Store result in scope
                scope["sensoit"] = result

            except BlockedError as e:
                if self.pass_through:
                    scope["sensoit_blocked"] = True
                    scope["sensoit_violations"] = e.violations
                else:
                    await self._send_json_response(
                        send,
                        self.blocked_status_code,
                        self.blocked_response,
                    )
                    return

            except EscalatedError:
                if self.pass_through:
                    scope["sensoit_escalated"] = True
                else:
                    await self._send_json_response(
                        send,
                        self.escalated_status_code,
                        self.escalated_response,
                    )
                    return

        except Exception as e:
            logger.error(f"Sensoit middleware error: {e}")

        # Continue with request
        await self._continue_request(scope, send, body)

    async def _send_json_response(
        self,
        send: Callable,
        status: int,
        body: Dict[str, Any],
    ) -> None:
        """Send JSON response."""
        response_body = json.dumps(body).encode()
        await send({
            "type": "http.response.start",
            "status": status,
            "headers": [[b"content-type", b"application/json"]],
        })
        await send({
            "type": "http.response.body",
            "body": response_body,
        })

    async def _continue_request(
        self,
        scope: Dict[str, Any],
        send: Callable,
        body: bytes,
    ) -> None:
        """Continue request with captured body."""
        async def receive_with_body() -> Dict[str, Any]:
            return {"type": "http.request", "body": body}

        await self.app(scope, receive_with_body, send)


# Alias for FastAPI
FastAPISensoitMiddleware = SensoitMiddleware


# ============================================================================
# Flask Decorator
# ============================================================================


def flask_protect(
    client: Sensoit,
    prompt: str,
    extract_input: Optional[Callable[[], str]] = None,
    extract_variables: Optional[Callable[[], Dict[str, str]]] = None,
    blocked_response: Optional[Dict[str, Any]] = None,
    blocked_status_code: int = 200,
    escalated_response: Optional[Dict[str, Any]] = None,
    escalated_status_code: int = 202,
) -> Callable[[F], F]:
    """
    Flask decorator to protect routes with Sensoit.

    Example:
        >>> from flask import Flask, request
        >>> from sensoit import Sensoit
        >>> from sensoit.middleware import flask_protect
        >>>
        >>> app = Flask(__name__)
        >>> gf = Sensoit(api_key="gf_live_xxx")
        >>>
        >>> @app.route("/chat", methods=["POST"])
        >>> @flask_protect(gf, prompt="chat-bot")
        >>> def chat():
        ...     result = request.sensoit
        ...     return {"reply": result.output}
    """

    def decorator(func: F) -> F:
        @wraps(func)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            from flask import request, jsonify

            # Extract input
            if extract_input:
                input_text = extract_input()
            else:
                data = request.get_json(silent=True) or {}
                input_text = None
                for field in ["input", "message", "text", "query", "content"]:
                    if field in data:
                        input_text = str(data[field])
                        break

            if not input_text:
                return func(*args, **kwargs)

            # Extract variables
            variables = None
            if extract_variables:
                variables = extract_variables()

            try:
                # Run Sensoit (sync)
                result = client.run_sync(prompt, input=input_text, variables=variables)

                # Store result for access in route
                request.sensoit = result  # type: ignore

            except BlockedError:
                response = blocked_response or {"error": "Request blocked"}
                return jsonify(response), blocked_status_code

            except EscalatedError:
                response = escalated_response or {
                    "message": "Request escalated for review"
                }
                return jsonify(response), escalated_status_code

            except Exception as e:
                logger.error(f"Sensoit error: {e}")

            return func(*args, **kwargs)

        return wrapper  # type: ignore

    return decorator


# Alias
protect = flask_protect


# ============================================================================
# Django Middleware
# ============================================================================


class DjangoSensoitMiddleware:
    """
    Django middleware for Sensoit.

    Add to settings.py:
        MIDDLEWARE = [
            ...
            'sensoit.middleware.DjangoSensoitMiddleware',
        ]

        SENSOIT = {
            'API_KEY': 'gf_live_xxx',
            'PROMPT': 'default-prompt',
            'PROTECTED_PATHS': ['/api/chat/', '/api/ask/'],
            'BASE_URL': 'https://api.sensoit.io',  # Optional
        }
    """

    def __init__(self, get_response: Callable) -> None:
        self.get_response = get_response
        self._client: Optional[Sensoit] = None

    def _get_client(self) -> Sensoit:
        """Get or create Sensoit client."""
        if self._client is None:
            from django.conf import settings

            sensoit_settings = getattr(settings, "SENSOIT", {})
            api_key = sensoit_settings.get("API_KEY")

            if not api_key:
                raise ValueError("SENSOIT['API_KEY'] not set in Django settings")

            base_url = sensoit_settings.get(
                "BASE_URL", "https://api.sensoit.io"
            )

            self._client = Sensoit(api_key=api_key, base_url=base_url)

        return self._client

    def __call__(self, request: Any) -> Any:
        from django.conf import settings
        from django.http import JsonResponse

        sensoit_settings = getattr(settings, "SENSOIT", {})
        prompt = sensoit_settings.get("PROMPT")
        protected_paths = sensoit_settings.get("PROTECTED_PATHS", [])
        blocked_response = sensoit_settings.get("BLOCKED_RESPONSE", {
            "error": "Request blocked by security policy"
        })
        blocked_status_code = sensoit_settings.get("BLOCKED_STATUS_CODE", 200)

        if not prompt:
            return self.get_response(request)

        # Check if path should be protected
        path = request.path
        should_protect = not protected_paths or any(
            path.startswith(p) for p in protected_paths
        )

        if not should_protect or request.method not in ("POST", "PUT", "PATCH"):
            return self.get_response(request)

        try:
            # Parse body
            try:
                data = json.loads(request.body) if request.body else {}
            except json.JSONDecodeError:
                data = {}

            # Extract input
            input_text = None
            for field in ["input", "message", "text", "query", "content"]:
                if field in data:
                    input_text = str(data[field])
                    break

            if not input_text:
                return self.get_response(request)

            # Run Sensoit
            client = self._get_client()
            result = client.run_sync(prompt, input=input_text)

            # Store result for access in view
            request.sensoit = result

        except BlockedError:
            return JsonResponse(blocked_response, status=blocked_status_code)

        except EscalatedError:
            return JsonResponse(
                {"message": "Request escalated for review"},
                status=202,
            )

        except Exception as e:
            logger.error(f"Sensoit middleware error: {e}")

        return self.get_response(request)


# ============================================================================
# Generic ASGI Middleware
# ============================================================================


class SensoitASGI:
    """
    Generic ASGI middleware for Sensoit.

    Example:
        >>> from sensoit import Sensoit
        >>> from sensoit.middleware import SensoitASGI
        >>>
        >>> gf = Sensoit(api_key="gf_live_xxx")
        >>> app = SensoitASGI(your_app, gf, prompt="default")
    """

    def __init__(
        self,
        app: Any,
        client: Sensoit,
        prompt: str,
        protected_paths: Optional[List[str]] = None,
        extract_input: Optional[Callable[[Dict], str]] = None,
        extract_variables: Optional[Callable[[Dict], Dict[str, str]]] = None,
    ):
        self.app = app
        self.client = client
        self.prompt = prompt
        self.protected_paths = protected_paths or []
        self.extract_input = extract_input
        self.extract_variables = extract_variables

    async def __call__(
        self,
        scope: Dict[str, Any],
        receive: Callable,
        send: Callable,
    ) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        path = scope.get("path", "")
        method = scope.get("method", "")

        # Check if should protect
        should_protect = not self.protected_paths or any(
            path.startswith(p) for p in self.protected_paths
        )

        if not should_protect or method not in ("POST", "PUT", "PATCH"):
            await self.app(scope, receive, send)
            return

        # Similar logic to SensoitMiddleware
        body = b""

        async def receive_wrapper() -> Dict[str, Any]:
            nonlocal body
            message = await receive()
            if message["type"] == "http.request":
                body = message.get("body", b"")
            return message

        await receive_wrapper()

        try:
            data = json.loads(body) if body else {}
        except json.JSONDecodeError:
            data = {}

        input_text = None
        if self.extract_input:
            input_text = self.extract_input(data)
        else:
            for field in ["input", "message", "text", "query", "content"]:
                if field in data:
                    input_text = str(data[field])
                    break

        if input_text:
            try:
                variables = None
                if self.extract_variables:
                    variables = self.extract_variables(data)

                result = await self.client.run(
                    self.prompt,
                    input=input_text,
                    variables=variables,
                )
                scope["sensoit"] = result
            except (BlockedError, EscalatedError):
                pass
            except Exception as e:
                logger.error(f"SensoitASGI error: {e}")

        async def receive_with_body() -> Dict[str, Any]:
            return {"type": "http.request", "body": body}

        await self.app(scope, receive_with_body, send)
