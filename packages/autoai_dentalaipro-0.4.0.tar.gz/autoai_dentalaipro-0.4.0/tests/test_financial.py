"""Tests for the DentalAI Pro financial management module."""

from __future__ import annotations

import json
import tempfile
from datetime import date, timedelta
from pathlib import Path

import pytest

from dentalaipro.financial import (
    NHS_BAND_CHARGES,
    NHS_BAND_UDA,
    NHS_EXEMPTIONS,
    VAT_STANDARD_RATE,
    calculate_vat,
    determine_vat_rate,
    create_nhs_invoice,
    create_private_invoice,
    create_insurance_invoice,
    generate_pnl,
    generate_vat_summary,
    calculate_daily_takings,
    calculate_debt_aging,
    get_expense_categories,
    get_income_categories,
    get_nhs_band_info,
)


class TestNHSBandCharges:
    """Verify NHS dental charges 2024/25 are accurate."""

    def test_band_1_charge(self) -> None:
        assert NHS_BAND_CHARGES["1"] == 26.80

    def test_band_2_charge(self) -> None:
        assert NHS_BAND_CHARGES["2"] == 73.50

    def test_band_3_charge(self) -> None:
        assert NHS_BAND_CHARGES["3"] == 319.10

    def test_urgent_charge(self) -> None:
        assert NHS_BAND_CHARGES["urgent"] == 26.80

    def test_band_uda_values(self) -> None:
        assert NHS_BAND_UDA["1"] == 1
        assert NHS_BAND_UDA["2"] == 3
        assert NHS_BAND_UDA["3"] == 12
        assert NHS_BAND_UDA["urgent"] == 1.2


class TestVATCalculation:
    """Test VAT calculation accuracy."""

    def test_vat_standard_rate(self) -> None:
        assert VAT_STANDARD_RATE == 0.20

    def test_calculate_vat_20_percent(self) -> None:
        assert calculate_vat(100.0, 0.20) == 20.0

    def test_calculate_vat_zero(self) -> None:
        assert calculate_vat(100.0, 0.0) == 0.0

    def test_calculate_vat_rounding(self) -> None:
        # 73.50 * 0.20 = 14.70 exactly
        assert calculate_vat(73.50, 0.20) == 14.70

    def test_calculate_vat_penny_rounding(self) -> None:
        # 33.33 * 0.20 = 6.666 -> should round to 6.67
        assert calculate_vat(33.33, 0.20) == 6.67

    def test_healthcare_is_exempt(self) -> None:
        assert determine_vat_rate("filling") == 0.0
        assert determine_vat_rate("crown") == 0.0
        assert determine_vat_rate("extraction") == 0.0

    def test_cosmetic_is_standard_rate(self) -> None:
        assert determine_vat_rate("whitening") == 0.20
        assert determine_vat_rate("dental_jewellery") == 0.20

    def test_cosmetic_flag_overrides(self) -> None:
        assert determine_vat_rate("veneer", is_cosmetic=True) == 0.20

    def test_product_sale_is_standard(self) -> None:
        assert determine_vat_rate("product_sale") == 0.20
        assert determine_vat_rate("whitening_kit") == 0.20


class TestNHSInvoice:
    """Test NHS invoice generation."""

    def test_band_1_invoice(self) -> None:
        inv = create_nhs_invoice(1, "John Smith", "1")
        assert inv["total"] == 26.80
        assert inv["type"] == "nhs"
        assert inv["nhs_band"] == "1"
        assert inv["vat"] == 0.0
        assert inv["status"] == "pending"
        assert inv["id"].startswith("INV-")

    def test_band_2_invoice(self) -> None:
        inv = create_nhs_invoice(1, "Jane Doe", "2")
        assert inv["total"] == 73.50

    def test_band_3_invoice(self) -> None:
        inv = create_nhs_invoice(1, "Bob Wilson", "3")
        assert inv["total"] == 319.10

    def test_exempt_patient_zero_charge(self) -> None:
        inv = create_nhs_invoice(1, "Child Patient", "1", exemption="under18")
        assert inv["total"] == 0.0

    def test_hc2_exempt(self) -> None:
        inv = create_nhs_invoice(1, "Low Income", "3", exemption="hc2")
        assert inv["total"] == 0.0

    def test_hc3_partial_uses_full_charge(self) -> None:
        inv = create_nhs_invoice(1, "Partial Help", "2", exemption="hc3")
        assert inv["total"] == 73.50

    def test_no_exemption_full_charge(self) -> None:
        inv = create_nhs_invoice(1, "Full Price", "3", exemption="none")
        assert inv["total"] == 319.10

    def test_invalid_band_raises(self) -> None:
        with pytest.raises(ValueError, match="Invalid NHS band"):
            create_nhs_invoice(1, "Test", "4")

    def test_items_contain_uda_info(self) -> None:
        inv = create_nhs_invoice(1, "Test", "2")
        items = json.loads(inv["items"])
        assert len(items) == 1
        assert items[0]["udas"] == 3
        assert items[0]["fee"] == 73.50


class TestPrivateInvoice:
    """Test private invoice generation."""

    def test_basic_invoice(self) -> None:
        items = [
            {"procedure": "Crown", "fee": 600},
            {"procedure": "Filling", "fee": 150},
        ]
        inv = create_private_invoice(1, "Test Patient", items)
        assert inv["subtotal"] == 750.0
        assert inv["vat"] == 0.0  # Healthcare exempt
        assert inv["total"] == 750.0
        assert inv["type"] == "private"

    def test_cosmetic_adds_vat(self) -> None:
        items = [
            {"procedure": "Whitening", "fee": 300, "is_cosmetic": True},
        ]
        inv = create_private_invoice(1, "Test", items)
        assert inv["subtotal"] == 300.0
        assert inv["vat"] == 60.0  # 300 * 0.20
        assert inv["total"] == 360.0

    def test_mixed_vat(self) -> None:
        items = [
            {"procedure": "Crown", "fee": 600},  # exempt
            {"procedure": "Whitening", "fee": 300, "is_cosmetic": True},  # 20%
        ]
        inv = create_private_invoice(1, "Test", items)
        assert inv["subtotal"] == 900.0
        assert inv["vat"] == 60.0
        assert inv["total"] == 960.0

    def test_empty_items(self) -> None:
        inv = create_private_invoice(1, "Test", [])
        assert inv["total"] == 0.0


class TestInsuranceInvoice:
    """Test insurance invoice generation."""

    def test_basic_insurance_invoice(self) -> None:
        items = [
            {"procedure": "Root Canal", "fee": 450, "cdt_code": "D3310"},
        ]
        inv = create_insurance_invoice(1, "Test", items, insurance_provider="Denplan")
        assert inv["total"] == 450.0
        assert inv["type"] == "insurance"
        assert "Denplan" in inv["notes"]


class TestPnLReport:
    """Test P&L report generation."""

    def test_basic_pnl(self) -> None:
        income = [
            {"category": "private_fees", "amount": 1000},
            {"category": "nhs_payments", "amount": 500},
        ]
        expenses = [
            {"category": "lab_fees", "amount": 200},
            {"category": "staff_costs", "amount": 300},
        ]
        pnl = generate_pnl(income, expenses, "March 2026")
        assert pnl["total_income"] == 1500.0
        assert pnl["total_expenses"] == 500.0
        assert pnl["net_profit"] == 1000.0
        assert pnl["profit_margin_pct"] == pytest.approx(66.7, abs=0.1)

    def test_empty_pnl(self) -> None:
        pnl = generate_pnl([], [], "Empty")
        assert pnl["total_income"] == 0.0
        assert pnl["total_expenses"] == 0.0
        assert pnl["net_profit"] == 0.0
        assert pnl["profit_margin_pct"] == 0.0

    def test_loss_scenario(self) -> None:
        income = [{"category": "fees", "amount": 100}]
        expenses = [{"category": "rent", "amount": 500}]
        pnl = generate_pnl(income, expenses)
        assert pnl["net_profit"] == -400.0


class TestVATSummary:
    """Test VAT summary generation."""

    def test_basic_vat_summary(self) -> None:
        income = [
            {"amount": 300, "vat_amount": 60},  # Cosmetic with VAT
            {"amount": 500, "vat_amount": 0},    # Healthcare exempt
        ]
        expenses = [
            {"amount": 100, "vat_amount": 20},   # Supplies with VAT
        ]
        vat = generate_vat_summary(income, expenses)
        assert vat["vat_collected"] == 60.0
        assert vat["vat_paid"] == 20.0
        assert vat["net_vat"] == 40.0
        assert vat["vat_owed"] == 40.0
        assert vat["vat_reclaimable"] == 0.0

    def test_reclaimable_vat(self) -> None:
        income = [{"amount": 100, "vat_amount": 0}]
        expenses = [{"amount": 200, "vat_amount": 40}]
        vat = generate_vat_summary(income, expenses)
        assert vat["net_vat"] == -40.0
        assert vat["vat_reclaimable"] == 40.0
        assert vat["vat_owed"] == 0.0


class TestDailyTakings:
    """Test daily takings calculation."""

    def test_basic_takings(self) -> None:
        records = [
            {"amount": 100, "payment_method": "card", "category": "private_fees"},
            {"amount": 26.80, "payment_method": "cash", "category": "nhs_payments"},
        ]
        result = calculate_daily_takings(records, "2026-03-19")
        assert result["total"] == 126.80
        assert result["transaction_count"] == 2
        assert result["by_payment_method"]["card"] == 100.0
        assert result["by_payment_method"]["cash"] == 26.80

    def test_empty_day(self) -> None:
        result = calculate_daily_takings([])
        assert result["total"] == 0.0
        assert result["transaction_count"] == 0


class TestDebtAging:
    """Test debt aging calculation."""

    def test_no_outstanding(self) -> None:
        invoices = [{"status": "paid", "total": 100}]
        result = calculate_debt_aging(invoices)
        assert result["total_outstanding"] == 0.0

    def test_current_debt(self) -> None:
        invoices = [
            {"status": "pending", "total": 200, "date": date.today().isoformat()},
        ]
        result = calculate_debt_aging(invoices)
        assert result["total_outstanding"] == 200.0
        assert result["buckets"]["current"]["total"] == 200.0

    def test_old_debt(self) -> None:
        old_date = (date.today() - timedelta(days=100)).isoformat()
        invoices = [
            {"status": "overdue", "total": 500, "date": old_date},
        ]
        result = calculate_debt_aging(invoices)
        assert result["buckets"]["90_plus"]["total"] == 500.0


class TestCategories:
    """Test expense/income category definitions."""

    def test_expense_categories_exist(self) -> None:
        cats = get_expense_categories()
        assert "clinical_supplies" in cats
        assert "lab_fees" in cats
        assert "staff_costs" in cats
        assert len(cats) >= 10

    def test_income_categories_exist(self) -> None:
        cats = get_income_categories()
        assert "nhs_payments" in cats
        assert "private_fees" in cats
        assert len(cats) >= 5

    def test_nhs_band_info(self) -> None:
        info = get_nhs_band_info()
        assert info["1"]["charge"] == 26.80
        assert info["2"]["charge"] == 73.50
        assert info["3"]["charge"] == 319.10
        assert info["urgent"]["udas"] == 1.2
