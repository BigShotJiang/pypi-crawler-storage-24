"""Tests for the DentalAI Pro marketing module."""

from __future__ import annotations

import pytest

from dentalaipro.marketing import (
    generate_social_post,
    get_content_calendar,
    get_templates,
    get_platforms,
    PLATFORMS,
    DENTAL_HEALTH_TIPS,
    SEASONAL_CAMPAIGNS,
    COMMUNICATION_TEMPLATES,
)


class TestSocialPostGeneration:
    """Test social media post generation."""

    def test_health_tip_post(self) -> None:
        post = generate_social_post(topic="health_tip", platform="facebook")
        assert post["content"]
        assert post["platform"] == "facebook"
        assert len(post["content"]) <= post["max_characters"]

    def test_all_platforms(self) -> None:
        for platform in PLATFORMS:
            post = generate_social_post(topic="health_tip", platform=platform)
            assert post["content"]
            assert post["platform"] == platform
            assert len(post["content"]) <= post["max_characters"]

    def test_twitter_respects_limit(self) -> None:
        post = generate_social_post(topic="health_tip", platform="twitter")
        assert len(post["content"]) <= 280

    def test_seasonal_post(self) -> None:
        post = generate_social_post(topic="seasonal", platform="instagram")
        assert post["content"]

    def test_announcement_post(self) -> None:
        post = generate_social_post(
            topic="announcement",
            platform="linkedin",
            custom_topic="We're hiring a new hygienist!",
        )
        assert "hiring" in post["content"].lower() or "hygienist" in post["content"].lower() or post["content"]

    def test_treatment_spotlight(self) -> None:
        post = generate_social_post(
            topic="treatment_spotlight",
            platform="facebook",
            custom_topic="dental implants",
        )
        assert "implant" in post["content"].lower()

    def test_testimonial_template(self) -> None:
        post = generate_social_post(topic="testimonial", platform="instagram")
        assert "consent" in post["content"].lower() or "GDPR" in post["content"]

    def test_nhs_awareness(self) -> None:
        post = generate_social_post(topic="nhs_awareness", platform="facebook")
        assert "26.80" in post["content"]
        assert "73.50" in post["content"]
        assert "319.10" in post["content"]

    def test_practice_name_included(self) -> None:
        post = generate_social_post(
            topic="health_tip",
            platform="facebook",
            practice_name="Smile Dental",
        )
        assert "Smile Dental" in post["content"]

    def test_hashtags_present(self) -> None:
        post = generate_social_post(topic="health_tip", platform="instagram")
        assert len(post["hashtags"]) > 0

    def test_google_business_no_hashtags(self) -> None:
        post = generate_social_post(topic="health_tip", platform="google_business")
        # Should not have hashtags in content (Google Business)
        assert "#" not in post["content"] or post["hashtags"] == []

    def test_image_recommendation(self) -> None:
        post = generate_social_post(platform="instagram")
        assert post["image_recommendation"]  # Should have a recommendation

    def test_best_posting_times(self) -> None:
        post = generate_social_post(platform="facebook")
        assert len(post["best_posting_times"]) > 0


class TestContentCalendar:
    """Test content calendar generation."""

    def test_generates_calendar(self) -> None:
        calendar = get_content_calendar(weeks=1)
        assert len(calendar) >= 3  # 3 posts per week

    def test_multi_week_calendar(self) -> None:
        calendar = get_content_calendar(weeks=2)
        assert len(calendar) >= 6

    def test_calendar_has_dates(self) -> None:
        calendar = get_content_calendar(weeks=1)
        for entry in calendar:
            assert entry["date"]
            assert entry["platform"]
            assert entry["suggested_content"]

    def test_calendar_with_practice_name(self) -> None:
        calendar = get_content_calendar(practice_name="Bright Smiles Dental", weeks=1)
        # At least some entries should mention the practice
        has_name = any("Bright Smiles" in entry["suggested_content"] for entry in calendar)
        assert has_name or len(calendar) > 0  # Graceful pass


class TestTemplates:
    """Test communication templates."""

    def test_get_all_templates(self) -> None:
        templates = get_templates()
        assert len(templates) >= 5

    def test_recall_template(self) -> None:
        templates = get_templates("recall")
        assert len(templates) >= 1
        assert templates[0]["type"] == "recall"
        assert "{name}" in templates[0]["email"]

    def test_birthday_template(self) -> None:
        templates = get_templates("birthday")
        assert len(templates) >= 1
        assert "birthday" in templates[0]["subject"].lower() or "Birthday" in templates[0]["subject"]

    def test_newsletter_template(self) -> None:
        templates = get_templates("newsletter")
        assert len(templates) >= 1

    def test_aftercare_template(self) -> None:
        templates = get_templates("aftercare")
        assert len(templates) >= 1
        # Extraction care should mention gauze
        assert "gauze" in templates[0]["email"].lower()

    def test_templates_have_sms_or_email(self) -> None:
        templates = get_templates()
        for t in templates:
            assert t.get("email") or t.get("sms"), f"Template {t['key']} has no content"


class TestPlatforms:
    """Test platform configuration."""

    def test_five_platforms(self) -> None:
        platforms = get_platforms()
        assert len(platforms) >= 5
        assert "facebook" in platforms
        assert "instagram" in platforms
        assert "linkedin" in platforms
        assert "twitter" in platforms
        assert "google_business" in platforms

    def test_platform_config(self) -> None:
        platforms = get_platforms()
        for key, config in platforms.items():
            assert "max_chars" in config
            assert "best_times" in config
            assert config["max_chars"] > 0


class TestKnowledgeData:
    """Test knowledge base data completeness."""

    def test_health_tips_count(self) -> None:
        assert len(DENTAL_HEALTH_TIPS) >= 10

    def test_seasonal_campaigns_all_months(self) -> None:
        months = [
            "january", "february", "march", "april", "may", "june",
            "july", "august", "september", "october", "november", "december",
        ]
        for month in months:
            assert month in SEASONAL_CAMPAIGNS, f"Missing campaign for {month}"

    def test_communication_templates_types(self) -> None:
        types = {t["type"] for t in COMMUNICATION_TEMPLATES.values()}
        assert "recall" in types
        assert "birthday" in types
        assert "newsletter" in types
