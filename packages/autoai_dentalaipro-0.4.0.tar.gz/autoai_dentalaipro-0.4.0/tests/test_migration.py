"""Tests for the DentalAI Pro migration module."""

from __future__ import annotations

import pytest

from dentalaipro.migration import (
    get_migration_guide,
    get_all_systems,
    parse_patient_csv,
    verify_migration,
    SOURCE_SYSTEMS,
)


class TestMigrationGuide:
    """Test migration guide retrieval."""

    def test_all_systems_have_guides(self) -> None:
        for system_key in SOURCE_SYSTEMS:
            guide = get_migration_guide(system_key)
            assert "error" not in guide
            assert guide["name"]
            assert guide["export_steps"]
            assert guide["exportable"]
            assert guide["not_exportable"]

    def test_soe_guide(self) -> None:
        guide = get_migration_guide("soe")
        assert "SOE" in guide["name"]
        assert guide["market"] == "UK"
        assert len(guide["export_steps"]) >= 4

    def test_dentrix_guide(self) -> None:
        guide = get_migration_guide("dentrix")
        assert "Dentrix" in guide["name"]
        assert guide["market"] == "US"

    def test_opendental_guide(self) -> None:
        guide = get_migration_guide("opendental")
        assert "Open Dental" in guide["name"]
        assert "MySQL" in str(guide["export_steps"])

    def test_unknown_system_returns_error(self) -> None:
        guide = get_migration_guide("nonexistent")
        assert "error" in guide
        assert "available_systems" in guide

    def test_all_systems_summary(self) -> None:
        systems = get_all_systems()
        assert len(systems) >= 6
        keys = [s["key"] for s in systems]
        assert "soe" in keys
        assert "dentrix" in keys
        assert "opendental" in keys


class TestCSVParsing:
    """Test patient CSV import parsing."""

    def test_basic_csv(self) -> None:
        csv = "name,age,sex\nJohn Smith,45,M\nJane Doe,32,F"
        result = parse_patient_csv(csv)
        assert result["valid"]
        assert result["total_parsed"] == 2
        assert result["patients"][0]["name"] == "John Smith"
        assert result["patients"][0]["age"] == 45
        assert result["patients"][0]["sex"] == "M"

    def test_dob_instead_of_age(self) -> None:
        csv = "name,dob,sex\nJohn Smith,01/01/1980,M"
        result = parse_patient_csv(csv)
        assert result["valid"]
        assert result["patients"][0]["age"] > 40

    def test_medical_conditions(self) -> None:
        csv = 'name,age,medical_conditions\nJohn Smith,50,"diabetes, hypertension"'
        result = parse_patient_csv(csv)
        assert result["valid"]
        assert "diabetes" in result["patients"][0]["medical_conditions"]
        assert "hypertension" in result["patients"][0]["medical_conditions"]

    def test_missing_name_skipped(self) -> None:
        csv = "name,age\n,45\nJane Doe,32"
        result = parse_patient_csv(csv)
        assert result["total_parsed"] == 1
        assert len(result["issues"]) >= 1

    def test_alternative_column_names(self) -> None:
        csv = "patient_name,gender,telephone\nJohn Smith,Male,01234567890"
        result = parse_patient_csv(csv)
        assert result["valid"]
        assert result["patients"][0]["name"] == "John Smith"
        assert result["patients"][0]["sex"] == "M"

    def test_empty_csv(self) -> None:
        csv = ""
        result = parse_patient_csv(csv)
        assert not result["valid"]

    def test_headers_only(self) -> None:
        csv = "name,age,sex"
        result = parse_patient_csv(csv)
        assert result["total_parsed"] == 0

    def test_large_dataset(self) -> None:
        lines = ["name,age,sex"]
        for i in range(100):
            lines.append(f"Patient {i},{30 + i % 50},{'M' if i % 2 == 0 else 'F'}")
        csv = "\n".join(lines)
        result = parse_patient_csv(csv)
        assert result["total_parsed"] == 100

    def test_us_date_format(self) -> None:
        csv = "name,date_of_birth\nJohn Smith,03/15/1990"
        result = parse_patient_csv(csv)
        assert result["valid"]
        assert result["patients"][0]["age"] > 30


class TestVerification:
    """Test migration verification."""

    def test_perfect_match(self) -> None:
        result = verify_migration(100, 100)
        assert result["overall_status"] == "pass"

    def test_within_tolerance(self) -> None:
        # 96% is within 5% tolerance
        result = verify_migration(100, 96)
        assert result["overall_status"] == "pass"

    def test_below_tolerance(self) -> None:
        # 90% is below 95% tolerance
        result = verify_migration(100, 90)
        assert result["overall_status"] == "needs_review"

    def test_zero_source(self) -> None:
        result = verify_migration(0, 0)
        assert "checks" in result

    def test_sample_verification(self) -> None:
        samples = [
            {"name": "John Smith", "age": 45},
            {"name": "Jane Doe", "age": 32},
            {"name": "", "age": 0},  # Invalid
        ]
        result = verify_migration(100, 98, sample_patients=samples)
        assert any(c["check"] == "Sample Verification" for c in result["checks"])

    def test_recommendations_present(self) -> None:
        result = verify_migration(100, 100)
        assert len(result["recommendations"]) >= 3
