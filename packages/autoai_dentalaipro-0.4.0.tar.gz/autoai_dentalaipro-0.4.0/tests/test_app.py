"""Tests for DentalAI Pro — covers all API endpoints and clinical engines."""

from __future__ import annotations

import json
import tempfile
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from dentalaipro.app import app, get_store
from dentalaipro.clinical.oral_pathology import analyze_lesion, calculate_cancer_risk
from dentalaipro.clinical.radiology import generate_report, check_findings
from dentalaipro.clinical.treatment import validate_plan, check_contraindications, estimate_prognosis
from dentalaipro.clinical.compliance import scan_compliance, get_inspection_checklist
from dentalaipro.clinical.billing import validate_claim, analyze_denial, cdt_lookup, cdt_search
from dentalaipro.knowledge.lesions import ORAL_LESIONS, get_lesion_by_name, get_lesions_by_location
from dentalaipro.knowledge.radiographic import RADIOGRAPHIC_FINDINGS, get_commonly_missed
from dentalaipro.knowledge.protocols import TREATMENT_PROTOCOLS
from dentalaipro.knowledge.contraindications import CONTRAINDICATIONS
from dentalaipro.knowledge.cdt_codes import CDT_CODES, lookup_cdt, search_cdt
from dentalaipro.knowledge.compliance_checks import COMPLIANCE_CHECKS
from dentalaipro.store import Store


client = TestClient(app)


# ══════════════════════════════════════════════════════════════
# KNOWLEDGE BASE TESTS
# ══════════════════════════════════════════════════════════════

class TestKnowledgeBases:
    """Verify knowledge base completeness and structure."""

    def test_lesions_count(self) -> None:
        assert len(ORAL_LESIONS) == 50

    def test_lesion_structure(self) -> None:
        for lesion in ORAL_LESIONS:
            assert "name" in lesion
            assert "category" in lesion
            assert "appearance" in lesion
            assert "locations" in lesion
            assert "malignant_potential" in lesion
            assert "key_features" in lesion

    def test_lesion_categories(self) -> None:
        categories = {l["category"] for l in ORAL_LESIONS}
        expected = {"malignant", "potentially_malignant", "benign_neoplasm", "reactive", "infectious", "autoimmune", "developmental"}
        assert categories == expected

    def test_lesion_lookup_by_name(self) -> None:
        result = get_lesion_by_name("Squamous Cell Carcinoma")
        assert result is not None
        assert result["category"] == "malignant"

    def test_lesion_lookup_by_location(self) -> None:
        results = get_lesions_by_location("tongue lateral")
        assert len(results) > 5  # Many lesions can occur here

    def test_radiographic_findings_count(self) -> None:
        assert len(RADIOGRAPHIC_FINDINGS) == 80

    def test_radiographic_structure(self) -> None:
        for f in RADIOGRAPHIC_FINDINGS:
            assert "name" in f
            assert "appearance" in f
            assert "significance" in f
            assert "next_steps" in f

    def test_commonly_missed_findings(self) -> None:
        missed = get_commonly_missed()
        assert len(missed) > 20  # Most findings are commonly missed

    def test_protocols_count(self) -> None:
        assert len(TREATMENT_PROTOCOLS) == 30

    def test_protocol_structure(self) -> None:
        for p in TREATMENT_PROTOCOLS:
            assert "scenario" in p
            assert "decision_tree" in p
            assert "guideline_source" in p
            assert "success_rates" in p

    def test_contraindications_count(self) -> None:
        assert len(CONTRAINDICATIONS) == 40

    def test_contraindication_structure(self) -> None:
        for c in CONTRAINDICATIONS:
            assert "condition_or_drug" in c
            assert "dental_concern" in c
            assert "what_to_do" in c
            assert "severity" in c

    def test_cdt_codes_count(self) -> None:
        assert len(CDT_CODES) == 100

    def test_cdt_code_structure(self) -> None:
        for c in CDT_CODES:
            assert "code" in c
            assert "description" in c
            assert "fee_range" in c
            assert "documentation_needed" in c

    def test_cdt_lookup(self) -> None:
        result = lookup_cdt("D0120")
        assert result is not None
        assert "periodic" in result["description"].lower()

    def test_cdt_search(self) -> None:
        results = search_cdt("crown")
        assert len(results) > 0

    def test_compliance_checks_count(self) -> None:
        assert len(COMPLIANCE_CHECKS) == 50

    def test_compliance_structure(self) -> None:
        for c in COMPLIANCE_CHECKS:
            assert "id" in c
            assert "framework" in c
            assert "title" in c
            assert "requirement" in c
            assert "how_to_comply" in c


# ══════════════════════════════════════════════════════════════
# CLINICAL ENGINE TESTS
# ══════════════════════════════════════════════════════════════

class TestOralPathology:
    """Test oral pathology screening engine."""

    def test_high_risk_lesion(self) -> None:
        """Lateral tongue, red, ulcerated, >2 weeks in 55M smoker should be high risk."""
        data = {
            "location": "tongue lateral",
            "colors": ["red", "mixed red/white"],
            "textures": ["ulcerated"],
            "borders": "irregular",
            "size_mm": 20,
            "duration": "1-3 months",
            "symptoms": ["painless"],
            "patient_age": 55,
            "patient_sex": "M",
            "risk_factors": ["tobacco", "alcohol"],
        }
        result = analyze_lesion(data)
        assert result["cancer_risk_score"] >= 50
        assert len(result["differentials"]) > 0
        assert result["biopsy_recommendation"]["urgency"] in ("IMMEDIATE", "SOON")
        assert "disclaimer" in result

    def test_low_risk_lesion(self) -> None:
        """Young patient, short duration, smooth, painless should be low risk."""
        data = {
            "location": "buccal mucosa",
            "colors": ["normal colored"],
            "textures": ["smooth"],
            "borders": "well-defined",
            "size_mm": 5,
            "duration": "<1 week",
            "symptoms": ["painless"],
            "patient_age": 25,
            "patient_sex": "F",
            "risk_factors": [],
        }
        result = analyze_lesion(data)
        assert result["cancer_risk_score"] < 30

    def test_cancer_risk_score_range(self) -> None:
        score = calculate_cancer_risk({"location": "floor of mouth", "duration": ">6 months",
                                       "colors": ["red"], "textures": ["ulcerated"],
                                       "borders": "irregular", "risk_factors": ["tobacco", "alcohol"],
                                       "patient_age": 65, "symptoms": ["numb"]})
        assert 0 <= score <= 100

    def test_empty_input(self) -> None:
        result = analyze_lesion({})
        assert "cancer_risk_score" in result
        assert result["cancer_risk_score"] >= 0


class TestRadiology:
    """Test radiology engine."""

    def test_generate_report_with_caries(self) -> None:
        data = {"study_type": "bitewing", "tooth_region": "#14", "findings": "caries on mesial", "quick_findings": ["caries"]}
        result = generate_report(data)
        assert "report" in result
        assert result["report"]["findings"]

    def test_missed_findings_panoramic(self) -> None:
        data = {"study_type": "panoramic", "findings": "", "quick_findings": []}
        result = check_findings(data)
        assert result["total_alerts"] > 0  # Should suggest checking condyles, carotids, etc.

    def test_empty_report(self) -> None:
        result = generate_report({"study_type": "periapical", "findings": ""})
        assert "report" in result
        assert "disclaimer" in result


class TestTreatment:
    """Test treatment planning engine."""

    def test_validate_plan_with_contraindication(self) -> None:
        data = {
            "diagnosis": "Irreversible pulpitis",
            "diagnosis_category": "endo",
            "planned_procedures": [{"description": "Root canal treatment", "code": "D3330"}],
            "tooth_number": "19",
            "medical_conditions": ["warfarin"],
            "medications": ["warfarin"],
        }
        result = validate_plan(data)
        assert result["overall_status"] in ("critical", "warning", "pass")
        assert "flags" in result

    def test_check_bisphosphonate_contraindication(self) -> None:
        data = {"medical_conditions": ["IV bisphosphonates"], "medications": ["zoledronic acid"]}
        result = check_contraindications(data)
        assert result["total"] > 0
        assert any(c["severity"] == "critical" for c in result["contraindications_found"])

    def test_prognosis_basic(self) -> None:
        data = {
            "diagnosis_category": "endo",
            "planned_procedures": [{"description": "Root canal treatment"}],
            "medical_conditions": [],
            "medications": [],
        }
        result = estimate_prognosis(data)
        assert result["estimated_success_rate"] > 80

    def test_prognosis_with_diabetes(self) -> None:
        data = {
            "planned_procedures": [{"description": "implant placement"}],
            "medical_conditions": ["uncontrolled diabetes"],
            "medications": [],
        }
        result = estimate_prognosis(data)
        # Should be reduced due to diabetes
        assert result["estimated_success_rate"] < 90

    def test_empty_validation(self) -> None:
        result = validate_plan({})
        assert "overall_status" in result


class TestCompliance:
    """Test compliance engine."""

    def test_scan_all_frameworks(self) -> None:
        result = scan_compliance({"frameworks": ["OSHA", "HIPAA"]})
        assert result["total_checks"] > 0
        assert "OSHA" in result["results"]
        assert "HIPAA" in result["results"]

    def test_inspection_checklist(self) -> None:
        result = get_inspection_checklist("CA")
        assert result["total_items"] > 0
        assert "checklist" in result


class TestBilling:
    """Test billing engine."""

    def test_cdt_lookup_valid(self) -> None:
        result = cdt_lookup("D0120")
        assert "code" in result
        assert result["code"] == "D0120"

    def test_cdt_lookup_invalid(self) -> None:
        result = cdt_lookup("D9999")
        assert "error" in result

    def test_cdt_search_crown(self) -> None:
        result = cdt_search("crown")
        assert result["total"] > 0

    def test_validate_claim(self) -> None:
        data = {"cdt_codes": ["D2750", "D2950"], "payer": "Delta Dental", "tooth_numbers": ["19"]}
        result = validate_claim(data)
        assert len(result["validations"]) > 0
        assert "warnings" in result  # Should flag bundling issue

    def test_denial_analysis(self) -> None:
        result = analyze_denial("D0003")
        assert result["denial_code"] == "D0003"
        assert "frequency" in result["description"].lower()
        assert "appeal_strategy" in result

    def test_unknown_denial(self) -> None:
        result = analyze_denial("UNKNOWN")
        assert "Unknown" in result["description"]


# ══════════════════════════════════════════════════════════════
# STORE TESTS
# ══════════════════════════════════════════════════════════════

class TestStore:
    """Test SQLite store operations."""

    def test_patient_crud(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            store = Store(db_path=Path(tmpdir) / "test.db")
            pid = store.save_patient({"name": "Test Patient", "age": 45, "sex": "M"})
            assert pid > 0
            patient = store.get_patient(pid)
            assert patient is not None
            assert patient["name"] == "Test Patient"
            store.close()

    def test_patient_update(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            store = Store(db_path=Path(tmpdir) / "test.db")
            pid = store.save_patient({"name": "Original", "age": 30})
            store.save_patient({"id": pid, "name": "Updated", "age": 31})
            patient = store.get_patient(pid)
            assert patient["name"] == "Updated"
            store.close()

    def test_compliance_log(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            store = Store(db_path=Path(tmpdir) / "test.db")
            log_id = store.log_compliance("sterilization", "OSHA-009", {"result": "pass"})
            assert log_id > 0
            logs = store.get_compliance_logs("sterilization")
            assert len(logs) == 1
            store.close()

    def test_list_patients(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            store = Store(db_path=Path(tmpdir) / "test.db")
            store.save_patient({"name": "Patient A"})
            store.save_patient({"name": "Patient B"})
            patients = store.list_patients()
            assert len(patients) == 2
            store.close()

    def test_save_record(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            store = Store(db_path=Path(tmpdir) / "test.db")
            pid = store.save_patient({"name": "Test"})
            rid = store.save_record("screening_records", pid, {"location": "lip"}, {"risk": 10})
            assert rid > 0
            store.close()


# ══════════════════════════════════════════════════════════════
# API ENDPOINT TESTS
# ══════════════════════════════════════════════════════════════

class TestAPIEndpoints:
    """Test FastAPI endpoints via TestClient."""

    def test_health(self) -> None:
        r = client.get("/api/health")
        assert r.status_code == 200
        assert r.json()["status"] == "ok"

    def test_serve_ui(self) -> None:
        r = client.get("/")
        assert r.status_code == 200
        assert "DentalAI Pro" in r.text

    def test_screening_analyze(self) -> None:
        r = client.post("/api/screening/analyze", json={
            "location": "tongue lateral",
            "colors": ["red"],
            "textures": ["ulcerated"],
            "borders": "irregular",
            "duration": "1-3 months",
            "patient_age": 55,
            "risk_factors": ["tobacco"],
        })
        assert r.status_code == 200
        data = r.json()
        assert "cancer_risk_score" in data
        assert "differentials" in data

    def test_radiology_report(self) -> None:
        r = client.post("/api/radiology/report", json={
            "study_type": "periapical",
            "findings": "periapical radiolucency at apex",
        })
        assert r.status_code == 200
        assert "report" in r.json()

    def test_radiology_check(self) -> None:
        r = client.post("/api/radiology/check", json={
            "study_type": "panoramic",
            "findings": "caries",
        })
        assert r.status_code == 200

    def test_treatment_validate(self) -> None:
        r = client.post("/api/treatment/validate", json={
            "diagnosis": "caries",
            "planned_procedures": [{"description": "composite restoration"}],
        })
        assert r.status_code == 200

    def test_treatment_contraindications(self) -> None:
        r = client.post("/api/treatment/contraindications", json={
            "medical_conditions": ["warfarin"],
            "medications": ["warfarin"],
        })
        assert r.status_code == 200
        assert r.json()["total"] > 0

    def test_treatment_prognosis(self) -> None:
        r = client.post("/api/treatment/prognosis", json={
            "planned_procedures": [{"description": "root canal"}],
        })
        assert r.status_code == 200
        assert "estimated_success_rate" in r.json()

    def test_compliance_scan(self) -> None:
        r = client.post("/api/compliance/scan", json={})
        assert r.status_code == 200
        assert "compliance_score" in r.json()

    def test_compliance_log_sterilization(self) -> None:
        r = client.post("/api/compliance/log/sterilization", json={
            "sterilizer_id": "S1", "result": "pass",
        })
        assert r.status_code == 200
        assert r.json()["status"] == "logged"

    def test_billing_cdt_lookup(self) -> None:
        r = client.get("/api/billing/cdt/D0120")
        assert r.status_code == 200
        assert r.json()["code"] == "D0120"

    def test_billing_cdt_search(self) -> None:
        r = client.get("/api/billing/cdt/search/extraction")
        assert r.status_code == 200

    def test_billing_validate(self) -> None:
        r = client.post("/api/billing/validate", json={
            "cdt_codes": ["D2750", "D2950"],
        })
        assert r.status_code == 200

    def test_billing_denial(self) -> None:
        r = client.get("/api/billing/denial/D0003")
        assert r.status_code == 200

    def test_patient_save_and_get(self) -> None:
        r = client.post("/api/patient/save", json={"name": "API Test", "age": 30})
        assert r.status_code == 200
        pid = r.json()["id"]

        r2 = client.get(f"/api/patient/{pid}")
        assert r2.status_code == 200
        assert r2.json()["name"] == "API Test"

    def test_patients_list(self) -> None:
        r = client.get("/api/patients")
        assert r.status_code == 200
        assert "patients" in r.json()

    def test_compliance_checklist(self) -> None:
        r = client.get("/api/compliance/checklist")
        assert r.status_code == 200
        assert "total_items" in r.json()

    def test_compliance_logs(self) -> None:
        r = client.get("/api/compliance/logs")
        assert r.status_code == 200


# ══════════════════════════════════════════════════════════════
# ONBOARDING TESTS
# ══════════════════════════════════════════════════════════════

class TestOnboardingAPI:
    """Tests for the onboarding API endpoints."""

    def test_onboarding_status(self) -> None:
        r = client.get("/api/onboarding/status")
        assert r.status_code == 200
        data = r.json()
        assert "progress" in data
        assert data["progress"]["total_steps"] == 5

    def test_onboarding_practice(self) -> None:
        r = client.post("/api/onboarding/practice", json={
            "name": "Test Dental",
            "practice_type": "private",
            "country": "uk",
            "num_dentists": 2,
        })
        assert r.status_code == 200
        assert r.json()["complete"] is True

    def test_onboarding_practice_validation(self) -> None:
        r = client.post("/api/onboarding/practice", json={
            "name": "",
            "practice_type": "",
            "country": "",
        })
        assert r.status_code == 422

    def test_onboarding_regulatory(self) -> None:
        r = client.post("/api/onboarding/regulatory", json={
            "country": "uk",
            "data": {"cqc_registration": "1-123456", "dspt_status": "Standards Met"},
        })
        assert r.status_code == 200
        assert r.json()["step"] == 2

    def test_onboarding_clinical(self) -> None:
        r = client.post("/api/onboarding/clinical", json={
            "specialties": ["general", "orthodontics"],
            "equipment": ["cbct", "panoramic"],
            "treatment_types": ["implants"],
        })
        assert r.status_code == 200

    def test_onboarding_team_add(self) -> None:
        r = client.post("/api/onboarding/team", json={
            "name": "Dr. Smith",
            "role": "dentist",
            "gdc_number": "123456",
            "access_level": "full_clinical",
        })
        assert r.status_code == 200
        assert "id" in r.json()

    def test_onboarding_team_add_validation(self) -> None:
        r = client.post("/api/onboarding/team", json={
            "name": "",
            "role": "",
            "access_level": "",
        })
        assert r.status_code == 422

    def test_onboarding_team_list(self) -> None:
        r = client.get("/api/onboarding/team")
        assert r.status_code == 200
        assert "members" in r.json()

    def test_onboarding_team_complete(self) -> None:
        r = client.post("/api/onboarding/team/complete")
        assert r.status_code == 200

    def test_onboarding_golive_requires_agreement(self) -> None:
        r = client.post("/api/onboarding/golive", json={
            "data_protection_agreed": False,
        })
        assert r.status_code == 422

    def test_onboarding_golive(self) -> None:
        r = client.post("/api/onboarding/golive", json={
            "data_protection_agreed": True,
            "walkthrough_completed": True,
        })
        assert r.status_code == 200
        assert r.json()["status"] == "complete"

    def test_onboarding_checklist_uk(self) -> None:
        r = client.get("/api/onboarding/checklist?country=uk")
        assert r.status_code == 200
        data = r.json()
        assert data["total"] > 0
        assert data["country"] == "uk"

    def test_onboarding_checklist_us(self) -> None:
        r = client.get("/api/onboarding/checklist?country=us")
        assert r.status_code == 200
        assert r.json()["total"] > 0

    def test_regulatory_fields_uk(self) -> None:
        r = client.get("/api/onboarding/regulatory-fields/uk")
        assert r.status_code == 200
        data = r.json()
        assert data["country"] == "uk"
        assert len(data["fields"]) > 0

    def test_regulatory_fields_us(self) -> None:
        r = client.get("/api/onboarding/regulatory-fields/us")
        assert r.status_code == 200
        assert r.json()["country"] == "us"

    def test_clinical_options(self) -> None:
        r = client.get("/api/onboarding/clinical-options")
        assert r.status_code == 200
        data = r.json()
        assert "specialties" in data
        assert "equipment" in data
        assert "treatment_types" in data
        assert "referral_network" in data


# ══════════════════════════════════════════════════════════════
# COMPLIANCE REGULATIONS TESTS
# ══════════════════════════════════════════════════════════════

class TestComplianceRegs:
    """Tests for the compliance regulations database."""

    def test_regulations_uk(self) -> None:
        r = client.get("/api/regulations/uk")
        assert r.status_code == 200
        data = r.json()
        assert data["total"] >= 50  # UK has the most detailed set
        assert data["country"] == "uk"

    def test_regulations_us(self) -> None:
        r = client.get("/api/regulations/us")
        assert r.status_code == 200
        assert r.json()["total"] >= 10

    def test_regulations_eu(self) -> None:
        r = client.get("/api/regulations/eu")
        assert r.status_code == 200
        assert r.json()["total"] >= 3

    def test_regulations_au(self) -> None:
        r = client.get("/api/regulations/au")
        assert r.status_code == 200
        assert r.json()["total"] >= 3

    def test_regulations_ca(self) -> None:
        r = client.get("/api/regulations/ca")
        assert r.status_code == 200
        assert r.json()["total"] >= 3

    def test_regulation_structure(self) -> None:
        r = client.get("/api/regulations/uk")
        reg = r.json()["regulations"][0]
        for key in ("id", "country", "category", "title", "description",
                     "mandatory", "frequency", "evidence_needed", "how_dentalai_helps"):
            assert key in reg, f"Missing key: {key}"

    def test_uk_has_cqc(self) -> None:
        r = client.get("/api/regulations/uk")
        categories = set(reg["category"] for reg in r.json()["regulations"])
        assert "CQC" in categories

    def test_uk_has_gdc(self) -> None:
        r = client.get("/api/regulations/uk")
        categories = set(reg["category"] for reg in r.json()["regulations"])
        assert "GDC" in categories

    def test_uk_has_nhs_bsa(self) -> None:
        r = client.get("/api/regulations/uk")
        categories = set(reg["category"] for reg in r.json()["regulations"])
        assert "NHS BSA" in categories

    def test_uk_has_gdpr(self) -> None:
        r = client.get("/api/regulations/uk")
        categories = set(reg["category"] for reg in r.json()["regulations"])
        assert "UK GDPR" in categories


# ══════════════════════════════════════════════════════════════
# ONBOARDING MODULE UNIT TESTS
# ══════════════════════════════════════════════════════════════

class TestOnboardingModule:
    """Unit tests for onboarding.py functions."""

    def test_regulatory_fields_all_countries(self) -> None:
        from dentalaipro.onboarding import get_regulatory_fields
        for country in ("uk", "us", "eu", "au", "ca"):
            fields = get_regulatory_fields(country)
            assert fields["country"] == country
            assert len(fields["fields"]) > 0

    def test_clinical_config_options(self) -> None:
        from dentalaipro.onboarding import get_clinical_config_options
        opts = get_clinical_config_options()
        assert len(opts["specialties"]) >= 7
        assert len(opts["equipment"]) >= 5
        assert len(opts["treatment_types"]) >= 5

    def test_validate_practice_data_valid(self) -> None:
        from dentalaipro.onboarding import validate_practice_data
        result = validate_practice_data({"name": "Test", "country": "uk", "practice_type": "private"})
        assert result["valid"] is True

    def test_validate_practice_data_invalid(self) -> None:
        from dentalaipro.onboarding import validate_practice_data
        result = validate_practice_data({"name": "", "country": "", "practice_type": ""})
        assert result["valid"] is False
        assert len(result["errors"]) == 3

    def test_validate_team_member_valid(self) -> None:
        from dentalaipro.onboarding import validate_team_member
        result = validate_team_member({"name": "Dr. X", "role": "dentist", "access_level": "full_clinical"})
        assert result["valid"] is True

    def test_validate_team_member_invalid(self) -> None:
        from dentalaipro.onboarding import validate_team_member
        result = validate_team_member({"name": "", "role": "", "access_level": ""})
        assert result["valid"] is False

    def test_golive_checklist_uk(self) -> None:
        from dentalaipro.onboarding import generate_golive_checklist
        checklist = generate_golive_checklist("uk", "nhs")
        assert len(checklist) > 4  # At least universal + NHS items
        ids = [c["id"] for c in checklist]
        assert "GOLIVE-NHS-001" in ids  # NHS-specific item

    def test_golive_checklist_us(self) -> None:
        from dentalaipro.onboarding import generate_golive_checklist
        checklist = generate_golive_checklist("us")
        assert len(checklist) >= 4  # At least universal items

    def test_onboarding_progress_calculation(self) -> None:
        from dentalaipro.onboarding import calculate_onboarding_progress
        status = {"step": 3, "practice_complete": 1, "regulatory_complete": 1,
                  "clinical_complete": 0, "team_complete": 0, "golive_complete": 0}
        progress = calculate_onboarding_progress(status)
        assert progress["completed_steps"] == 2
        assert progress["percentage"] == 40
        assert progress["is_complete"] is False


class TestComplianceRegsModule:
    """Unit tests for compliance_regs.py functions."""

    def test_get_all_regulations(self) -> None:
        from dentalaipro.compliance_regs import get_all_regulations
        regs = get_all_regulations()
        assert len(regs) >= 80

    def test_get_compliance_checklist(self) -> None:
        from dentalaipro.compliance_regs import get_compliance_checklist
        checklist = get_compliance_checklist("uk")
        assert len(checklist) > 0
        # All items should be mandatory
        for item in checklist:
            assert "title" in item

    def test_get_categories(self) -> None:
        from dentalaipro.compliance_regs import get_categories_for_country
        cats = get_categories_for_country("uk")
        assert "CQC" in cats
        assert "GDC" in cats
        assert "NHS BSA" in cats
        assert "DSPT" in cats
        assert "IRMER" in cats
        assert "HTM 01-05" in cats
        assert "Safeguarding" in cats
        assert "UK GDPR" in cats


class TestStoreOnboarding:
    """Tests for Store onboarding methods with temp database."""

    def test_practice_profile_save_and_get(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = Store(Path(tmp) / "test.db")
            store.save_practice_profile({"name": "Test Practice", "country": "uk", "practice_type": "nhs"})
            profile = store.get_practice_profile()
            assert profile is not None
            assert profile["name"] == "Test Practice"
            assert profile["country"] == "uk"
            store.close()

    def test_team_member_crud(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = Store(Path(tmp) / "test.db")
            mid = store.add_team_member({"name": "Dr. Test", "role": "dentist", "access_level": "full_clinical"})
            assert mid > 0
            members = store.list_team_members()
            assert len(members) == 1
            assert members[0]["name"] == "Dr. Test"
            store.remove_team_member(mid)
            members = store.list_team_members()
            assert len(members) == 0  # Soft-deleted
            store.close()

    def test_onboarding_status_progression(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = Store(Path(tmp) / "test.db")
            status = store.get_onboarding_status()
            assert status["step"] == 1
            assert status["practice_complete"] == 0
            store.update_onboarding_step(1, "practice_complete")
            status = store.get_onboarding_status()
            assert status["practice_complete"] == 1
            assert status["step"] == 2
            store.close()

    def test_regulatory_and_clinical_data(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            store = Store(Path(tmp) / "test.db")
            store.save_practice_profile({"name": "Test"})
            store.save_regulatory_data({"cqc": "123", "dspt": "Met"})
            store.save_clinical_config({"specialties": ["general", "ortho"]})
            profile = store.get_practice_profile()
            assert profile is not None
            store.close()
