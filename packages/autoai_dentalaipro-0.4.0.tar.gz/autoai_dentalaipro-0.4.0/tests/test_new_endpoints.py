"""Tests for the new DentalAI Pro API endpoints (finance, marketing, migration, license)."""

from __future__ import annotations

import json
import tempfile
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from dentalaipro.app import app, get_store, _store
from dentalaipro.store import Store

# Use a temp database for tests
_temp_dir = tempfile.mkdtemp()
_test_db = Path(_temp_dir) / "test_new.db"
_test_store = Store(db_path=_test_db)

# Monkey-patch the store
import dentalaipro.app as app_module
app_module._store = _test_store

client = TestClient(app)


class TestFinanceEndpoints:
    """Test finance API endpoints."""

    def test_record_income(self) -> None:
        r = client.post("/api/finance/income", json={
            "category": "private_fees",
            "amount": 600.0,
            "payment_method": "card",
            "description": "Crown treatment",
        })
        assert r.status_code == 200
        data = r.json()
        assert data["status"] == "recorded"
        assert data["id"] > 0

    def test_record_income_with_vat(self) -> None:
        r = client.post("/api/finance/income", json={
            "category": "cosmetic",
            "amount": 300.0,
            "vat_rate": 0.20,
            "description": "Teeth whitening",
        })
        data = r.json()
        assert data["vat_amount"] == 60.0

    def test_record_expense(self) -> None:
        r = client.post("/api/finance/expense", json={
            "category": "clinical_supplies",
            "amount": 150.0,
            "vat_rate": 0.20,
            "description": "Composite resin order",
        })
        assert r.status_code == 200
        assert r.json()["vat_amount"] == 30.0

    def test_create_nhs_invoice(self) -> None:
        r = client.post("/api/finance/invoice/create", json={
            "invoice_type": "nhs",
            "patient_name": "John Smith",
            "band": "2",
            "exemption": "none",
        })
        assert r.status_code == 200
        data = r.json()
        assert data["id"].startswith("INV-")
        assert data["invoice"]["total"] == 73.50

    def test_create_nhs_invoice_exempt(self) -> None:
        r = client.post("/api/finance/invoice/create", json={
            "invoice_type": "nhs",
            "patient_name": "Child Patient",
            "band": "1",
            "exemption": "under18",
        })
        assert r.json()["invoice"]["total"] == 0.0

    def test_create_private_invoice(self) -> None:
        r = client.post("/api/finance/invoice/create", json={
            "invoice_type": "private",
            "patient_name": "Jane Doe",
            "items": [
                {"procedure": "Crown", "fee": 600},
                {"procedure": "Filling", "fee": 150},
            ],
        })
        assert r.status_code == 200
        inv = r.json()["invoice"]
        assert inv["total"] == 750.0

    def test_get_invoice(self) -> None:
        # Create one first
        r1 = client.post("/api/finance/invoice/create", json={
            "invoice_type": "private",
            "patient_name": "Test",
            "items": [{"procedure": "Test", "fee": 100}],
        })
        inv_id = r1.json()["id"]
        r2 = client.get(f"/api/finance/invoice/{inv_id}")
        assert r2.status_code == 200
        assert r2.json()["id"] == inv_id

    def test_list_invoices(self) -> None:
        r = client.get("/api/finance/invoices")
        assert r.status_code == 200
        assert "invoices" in r.json()

    def test_pnl_report(self) -> None:
        r = client.get("/api/finance/pnl")
        assert r.status_code == 200
        data = r.json()
        assert "total_income" in data
        assert "total_expenses" in data
        assert "net_profit" in data

    def test_vat_summary(self) -> None:
        r = client.get("/api/finance/vat")
        assert r.status_code == 200
        assert "vat_collected" in r.json()

    def test_financial_dashboard(self) -> None:
        r = client.get("/api/finance/dashboard")
        assert r.status_code == 200
        data = r.json()
        assert "daily_takings" in data
        assert "monthly_pnl" in data
        assert "nhs_band_breakdown" in data
        assert "expense_categories" in data

    def test_daily_takings(self) -> None:
        r = client.get("/api/finance/daily-takings")
        assert r.status_code == 200
        assert "total" in r.json()


class TestMarketingEndpoints:
    """Test marketing API endpoints."""

    def test_generate_post(self) -> None:
        r = client.post("/api/marketing/generate-post", json={
            "topic": "health_tip",
            "platform": "facebook",
            "practice_name": "Test Dental",
        })
        assert r.status_code == 200
        data = r.json()
        assert data["content"]
        assert data["platform"] == "facebook"

    def test_generate_post_all_topics(self) -> None:
        topics = ["health_tip", "seasonal", "announcement", "treatment_spotlight", "testimonial", "nhs_awareness"]
        for topic in topics:
            r = client.post("/api/marketing/generate-post", json={
                "topic": topic,
                "platform": "instagram",
            })
            assert r.status_code == 200, f"Failed for topic: {topic}"
            assert r.json()["content"]

    def test_content_calendar(self) -> None:
        r = client.get("/api/marketing/calendar?weeks=1")
        assert r.status_code == 200
        data = r.json()
        assert "suggestions" in data
        assert "platforms" in data

    def test_schedule_post(self) -> None:
        r = client.post("/api/marketing/schedule", json={
            "content": "Test post content",
            "platform": "facebook",
            "scheduled_date": "2026-03-25",
            "title": "Test",
        })
        assert r.status_code == 200
        assert r.json()["status"] == "scheduled"

    def test_get_templates(self) -> None:
        r = client.get("/api/marketing/templates")
        assert r.status_code == 200
        assert len(r.json()["templates"]) >= 5

    def test_get_templates_filtered(self) -> None:
        r = client.get("/api/marketing/templates?template_type=recall")
        assert r.status_code == 200
        for t in r.json()["templates"]:
            assert t["type"] == "recall"


class TestMigrationEndpoints:
    """Test migration API endpoints."""

    def test_get_systems(self) -> None:
        r = client.get("/api/migration/systems")
        assert r.status_code == 200
        systems = r.json()["systems"]
        assert len(systems) >= 6

    def test_get_guide(self) -> None:
        r = client.get("/api/migration/guide/soe")
        assert r.status_code == 200
        assert "SOE" in r.json()["name"]

    def test_get_guide_unknown(self) -> None:
        r = client.get("/api/migration/guide/nonexistent")
        assert r.status_code == 404

    def test_start_migration(self) -> None:
        r = client.post("/api/migration/start", json={"source_system": "dentrix"})
        assert r.status_code == 200
        assert r.json()["status"] == "started"

    def test_import_patients(self) -> None:
        csv = "name,age,sex\nTest Patient,35,M\nAnother Patient,42,F"
        r = client.post("/api/migration/import/patients", json={"csv_content": csv})
        assert r.status_code == 200
        assert r.json()["imported"] == 2

    def test_migration_status(self) -> None:
        r = client.get("/api/migration/status")
        assert r.status_code == 200
        assert "status" in r.json()

    def test_verify_migration(self) -> None:
        r = client.post("/api/migration/verify", json={"source_count": 100})
        assert r.status_code == 200
        assert "checks" in r.json()


class TestLicenseEndpoint:
    """Test license API endpoint."""

    def test_get_license(self) -> None:
        r = client.get("/api/license")
        assert r.status_code == 200
        data = r.json()
        assert "license" in data
        assert "tiers" in data
        assert data["license"]["tier"] == "free"


class TestStoreNewMethods:
    """Test new store methods directly."""

    def setup_method(self) -> None:
        """Use a fresh store for each test."""
        self.store = Store(db_path=Path(tempfile.mkdtemp()) / "test_store.db")

    def test_add_ledger_entry(self) -> None:
        entry_id = self.store.add_ledger_entry({
            "date": "2026-03-19",
            "type": "income",
            "category": "private_fees",
            "amount": 500.0,
        })
        assert entry_id > 0

    def test_get_ledger_entries(self) -> None:
        self.store.add_ledger_entry({"date": "2026-03-19", "type": "income", "category": "fees", "amount": 100})
        self.store.add_ledger_entry({"date": "2026-03-19", "type": "expense", "category": "rent", "amount": 200})
        income = self.store.get_ledger_entries(entry_type="income")
        assert len(income) == 1
        all_entries = self.store.get_ledger_entries()
        assert len(all_entries) == 2

    def test_save_and_get_invoice(self) -> None:
        self.store.save_invoice({
            "id": "INV-TEST-001",
            "date": "2026-03-19",
            "type": "private",
            "items": "[]",
            "subtotal": 100,
            "total": 100,
        })
        inv = self.store.get_invoice("INV-TEST-001")
        assert inv is not None
        assert inv["id"] == "INV-TEST-001"

    def test_list_invoices(self) -> None:
        self.store.save_invoice({"id": "INV-1", "date": "2026-03-19", "type": "nhs", "items": "[]", "subtotal": 26.80, "total": 26.80, "status": "paid"})
        self.store.save_invoice({"id": "INV-2", "date": "2026-03-19", "type": "private", "items": "[]", "subtotal": 100, "total": 100, "status": "pending"})
        all_inv = self.store.list_invoices()
        assert len(all_inv) == 2
        pending = self.store.list_invoices(status="pending")
        assert len(pending) == 1

    def test_update_invoice_status(self) -> None:
        self.store.save_invoice({"id": "INV-X", "date": "2026-03-19", "type": "private", "items": "[]", "subtotal": 50, "total": 50})
        self.store.update_invoice_status("INV-X", "paid", "2026-03-19", "card")
        inv = self.store.get_invoice("INV-X")
        assert inv["status"] == "paid"

    def test_marketing_content(self) -> None:
        cid = self.store.save_marketing_content({
            "type": "social_post",
            "platform": "facebook",
            "content": "Test post",
            "status": "draft",
        })
        assert cid > 0
        content = self.store.list_marketing_content()
        assert len(content) == 1

    def test_migration_status(self) -> None:
        status = self.store.get_migration_status()
        assert status["status"] == "not_started"
        self.store.update_migration_status({"status": "in_progress", "step": 2})
        status = self.store.get_migration_status()
        assert status["status"] == "in_progress"

    def test_license(self) -> None:
        lic = self.store.get_license()
        assert lic["tier"] == "free"
        self.store.update_license({"tier": "pro"})
        lic = self.store.get_license()
        assert lic["tier"] == "pro"
