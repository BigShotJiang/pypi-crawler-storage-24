"""Tests for the DentalAI Pro licensing module."""

from __future__ import annotations

import pytest

from dentalaipro.licensing import (
    LICENSE_TIERS,
    FEATURE_DEFINITIONS,
    get_license_tiers,
    check_feature_access,
    check_patient_limit,
    check_dentist_limit,
    get_upgrade_info,
)


class TestLicenseTiers:
    """Test license tier definitions."""

    def test_three_tiers(self) -> None:
        tiers = get_license_tiers()
        assert "free" in tiers
        assert "pro" in tiers
        assert "enterprise" in tiers

    def test_free_tier_limits(self) -> None:
        free = LICENSE_TIERS["free"]
        assert free["max_dentists"] == 1
        assert free["max_patients_month"] == 50

    def test_pro_tier_unlimited(self) -> None:
        pro = LICENSE_TIERS["pro"]
        assert pro["max_dentists"] >= 999
        assert pro["max_patients_month"] >= 999999

    def test_enterprise_has_all_features(self) -> None:
        ent = LICENSE_TIERS["enterprise"]
        assert "financial_management" in ent["features"]
        assert "marketing" in ent["features"]
        assert "migration" in ent["features"]
        assert "api_access" in ent["features"]

    def test_free_has_basic_features(self) -> None:
        free = LICENSE_TIERS["free"]
        assert "oral_screening" in free["features"]
        assert "radiology_basic" in free["features"]
        assert "financial_management" not in free["features"]


class TestFeatureAccess:
    """Test feature access checking."""

    def test_allowed_feature(self) -> None:
        result = check_feature_access("free", "oral_screening")
        assert result["allowed"] is True

    def test_clinical_never_blocked(self) -> None:
        """Clinical features must never be hard-blocked (patient safety)."""
        result = check_feature_access("free", "treatment_prognosis")
        assert result["allowed"] is True
        # But should have soft warning
        assert result.get("soft_warning") is True or result.get("upgrade_prompt")

    def test_non_clinical_blocked_on_free(self) -> None:
        result = check_feature_access("free", "financial_management")
        assert result["allowed"] is False
        assert result.get("message")
        assert result.get("upgrade_to")

    def test_enterprise_has_everything(self) -> None:
        for feature in FEATURE_DEFINITIONS:
            result = check_feature_access("enterprise", feature)
            assert result["allowed"] is True

    def test_upgrade_prompt_for_marketing(self) -> None:
        result = check_feature_access("pro", "marketing")
        assert result["allowed"] is False
        assert "enterprise" in result.get("upgrade_to", "").lower() or "Enterprise" in result.get("message", "")


class TestPatientLimit:
    """Test patient limit checking."""

    def test_within_limit(self) -> None:
        result = check_patient_limit("free", 30)
        assert result["within_limit"] is True
        assert "warning" not in result

    def test_at_limit(self) -> None:
        result = check_patient_limit("free", 50)
        assert result["within_limit"] is False
        assert "warning" in result

    def test_over_limit(self) -> None:
        result = check_patient_limit("free", 100)
        assert result["within_limit"] is False
        assert result.get("upgrade_prompt") is True

    def test_pro_unlimited(self) -> None:
        result = check_patient_limit("pro", 10000)
        assert result["within_limit"] is True


class TestDentistLimit:
    """Test dentist limit checking."""

    def test_free_one_dentist(self) -> None:
        result = check_dentist_limit("free", 1)
        assert result["within_limit"] is True

    def test_free_exceeds_limit(self) -> None:
        result = check_dentist_limit("free", 3)
        assert result["within_limit"] is False
        assert "warning" in result

    def test_pro_many_dentists(self) -> None:
        result = check_dentist_limit("pro", 20)
        assert result["within_limit"] is True


class TestUpgradeInfo:
    """Test upgrade info generation."""

    def test_free_upgrade_options(self) -> None:
        info = get_upgrade_info("free")
        assert info["current_tier"] == "free"
        assert len(info["upgrades"]) >= 1

    def test_enterprise_no_upgrades(self) -> None:
        info = get_upgrade_info("enterprise")
        # Enterprise might have no upgrades or just show comparison
        assert info["current_tier"] == "enterprise"

    def test_upgrade_shows_new_features(self) -> None:
        info = get_upgrade_info("free")
        for upgrade in info["upgrades"]:
            assert len(upgrade["new_features"]) > 0
