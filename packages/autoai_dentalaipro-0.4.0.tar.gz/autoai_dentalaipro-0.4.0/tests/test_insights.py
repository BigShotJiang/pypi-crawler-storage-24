"""Tests for DentalAI Pro Insights Dashboard & AI Recommendations Engine."""

from __future__ import annotations

import json
import tempfile
import time
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from dentalaipro.app import app, get_store, _store
from dentalaipro.store import Store
from dentalaipro.insights import (
    get_practice_dashboard,
    get_revenue_by_chair,
    get_scheduling_efficiency,
    get_treatment_acceptance,
    get_recall_effectiveness,
    get_patient_acquisition,
    get_busiest_times,
    get_revenue_by_category,
    get_dentist_performance,
    get_dentist_comparison,
    get_dentist_outcomes,
    get_cpd_status,
    get_patient_journey_metrics,
    get_nps_score,
    get_communication_preferences,
    generate_recommendations,
)

client = TestClient(app)


@pytest.fixture
def fresh_store(tmp_path: Path) -> Store:
    """Create a fresh store with a temp database."""
    db = tmp_path / "test_insights.db"
    return Store(db_path=db)


@pytest.fixture
def populated_store(tmp_path: Path) -> Store:
    """Create a store populated with sample data for insights testing."""
    db = tmp_path / "test_insights_pop.db"
    store = Store(db_path=db)

    # Add practice profile
    store.save_practice_profile({
        "name": "Test Dental Practice",
        "practice_type": "mixed",
        "country": "uk",
        "num_surgeries": 3,
        "num_dentists": 2,
        "num_hygienists": 1,
        "num_nurses": 2,
        "cqc_registration": "CQC12345",
        "dspt_status": "in_progress",
    })

    # Add team members
    store.add_team_member({"name": "Dr. Smith", "role": "dentist", "gdc_number": "12345"})
    store.add_team_member({"name": "Dr. Jones", "role": "dentist", "gdc_number": "67890"})
    store.add_team_member({"name": "Sarah", "role": "hygienist", "gdc_number": "11111"})
    store.add_team_member({"name": "Emma", "role": "nurse", "gdc_number": "22222"})

    # Add patients
    for i in range(15):
        store.save_patient({"name": f"Patient {i}", "age": 30 + i, "sex": "M" if i % 2 == 0 else "F"})

    # Add invoices (mix of NHS, private, insurance)
    from datetime import date, timedelta
    today = date.today()
    for i in range(10):
        d = (today - timedelta(days=i * 3)).isoformat()
        inv_type = ["nhs", "private", "insurance"][i % 3]
        total = [65.20, 250.00, 180.00][i % 3]
        store.save_invoice({
            "id": f"INV-{1000 + i}",
            "patient_id": (i % 15) + 1,
            "patient_name": f"Patient {i % 15}",
            "date": d,
            "type": inv_type,
            "items": json.dumps([{"desc": "Treatment", "amount": total}]),
            "subtotal": total,
            "vat": 0,
            "total": total,
            "status": "paid" if i < 7 else "pending",
        })

    # Add ledger income entries
    for i in range(8):
        d = (today - timedelta(days=i * 2)).isoformat()
        store.add_ledger_entry({
            "date": d,
            "type": "income",
            "category": "treatment",
            "description": f"Treatment {i}",
            "amount": 150.0 + i * 20,
            "vat_rate": 0,
            "vat_amount": 0,
            "payment_method": "card",
        })

    # Add some treatment records
    for i in range(6):
        store.save_record(
            "treatment_records",
            patient_id=(i % 15) + 1,
            input_data={"planned_procedures": [{"code": "D2391", "desc": "Composite"}]},
            result_data={"overall_risk": "low" if i < 4 else "high", "warnings": []},
        )

    # Add screening records
    for i in range(4):
        store.save_record(
            "screening_records",
            patient_id=(i % 15) + 1,
            input_data={"location": "buccal mucosa"},
            result_data={"risk_level": "low"},
        )

    # Add billing records
    for i in range(3):
        store.save_record(
            "billing_records",
            patient_id=(i % 15) + 1,
            input_data={"cdt_codes": ["D0120"]},
            result_data={"status": "valid"},
        )

    return store


# ══════════════════════════════════════════════════════════════
# EMPTY STORE TESTS — Graceful degradation
# ══════════════════════════════════════════════════════════════

class TestEmptyStore:
    """All insight functions should return sensible defaults with empty data."""

    def test_practice_dashboard_empty(self, fresh_store: Store) -> None:
        result = get_practice_dashboard(fresh_store)
        assert result["total_patients"] == 0
        assert result["active_patients"] == 0
        assert result["revenue_mtd"] == 0.0
        assert result["recall_rate"] == 0.0
        assert "date" in result

    def test_revenue_by_chair_empty(self, fresh_store: Store) -> None:
        result = get_revenue_by_chair(fresh_store)
        assert result["total_revenue"] == 0.0
        assert result["num_surgeries"] >= 1

    def test_scheduling_efficiency_empty(self, fresh_store: Store) -> None:
        result = get_scheduling_efficiency(fresh_store)
        assert result["completed_appointments_30d"] == 0
        assert result["utilization_rate"] == 0.0

    def test_treatment_acceptance_empty(self, fresh_store: Store) -> None:
        result = get_treatment_acceptance(fresh_store)
        assert result["total_presented"] == 0
        assert result["acceptance_rate"] == 0.0

    def test_recall_effectiveness_empty(self, fresh_store: Store) -> None:
        result = get_recall_effectiveness(fresh_store)
        assert result["total_patients"] == 0
        assert result["recall_rate_7m"] == 0.0
        assert result["lapsed_patients"] == []

    def test_patient_acquisition_empty(self, fresh_store: Store) -> None:
        result = get_patient_acquisition(fresh_store)
        assert result["new_this_month"] == 0
        assert result["total_patients"] == 0

    def test_busiest_times_empty(self, fresh_store: Store) -> None:
        result = get_busiest_times(fresh_store)
        assert "grid" in result
        assert result["max_count"] == 0

    def test_revenue_by_category_empty(self, fresh_store: Store) -> None:
        result = get_revenue_by_category(fresh_store)
        assert result["total"] == 0.0

    def test_dentist_comparison_empty(self, fresh_store: Store) -> None:
        result = get_dentist_comparison(fresh_store)
        assert result["dentists"] == []
        assert result["total"] == 0

    def test_cpd_status_empty(self, fresh_store: Store) -> None:
        result = get_cpd_status(fresh_store)
        assert result["total_members"] == 0

    def test_patient_journey_empty(self, fresh_store: Store) -> None:
        result = get_patient_journey_metrics(fresh_store)
        assert result["total_patients"] == 0
        assert result["journey_completion_rate"] == 0.0

    def test_nps_score_empty(self, fresh_store: Store) -> None:
        result = get_nps_score(fresh_store)
        assert result["score"] is None
        assert result["total_responses"] == 0

    def test_communication_prefs_empty(self, fresh_store: Store) -> None:
        result = get_communication_preferences(fresh_store)
        assert result["total_communications"] == 0

    def test_recommendations_empty(self, fresh_store: Store) -> None:
        result = generate_recommendations(fresh_store)
        assert isinstance(result, list)
        # Empty store might still produce some recommendations (e.g., no marketing)


# ══════════════════════════════════════════════════════════════
# POPULATED STORE TESTS — Insight calculations
# ══════════════════════════════════════════════════════════════

class TestPopulatedInsights:
    """Test insight functions with realistic data."""

    def test_practice_dashboard(self, populated_store: Store) -> None:
        result = get_practice_dashboard(populated_store)
        assert result["total_patients"] == 15
        assert result["revenue_mtd"] >= 0
        assert result["revenue_ytd"] >= 0
        assert "date" in result

    def test_revenue_by_chair(self, populated_store: Store) -> None:
        result = get_revenue_by_chair(populated_store)
        assert result["total_revenue"] > 0
        assert result["num_surgeries"] == 3
        assert result["avg_per_chair"] > 0
        assert "by_type" in result

    def test_scheduling_efficiency(self, populated_store: Store) -> None:
        result = get_scheduling_efficiency(populated_store)
        assert result["num_surgeries"] == 3
        assert result["theoretical_capacity_30d"] == 3 * 8 * 22

    def test_treatment_acceptance(self, populated_store: Store) -> None:
        result = get_treatment_acceptance(populated_store)
        assert result["total_presented"] == 6
        assert result["total_accepted"] >= 0
        assert 0 <= result["acceptance_rate"] <= 100
        assert "by_fee_range" in result

    def test_recall_effectiveness(self, populated_store: Store) -> None:
        result = get_recall_effectiveness(populated_store)
        assert result["total_patients"] == 15

    def test_patient_acquisition(self, populated_store: Store) -> None:
        result = get_patient_acquisition(populated_store)
        assert result["total_patients"] == 15
        assert result["new_this_month"] >= 0

    def test_busiest_times(self, populated_store: Store) -> None:
        result = get_busiest_times(populated_store)
        assert "grid" in result
        # All 7 days should be in the grid
        assert len(result["grid"]) == 7
        for day_data in result["grid"].values():
            assert "Morning" in day_data
            assert "Afternoon" in day_data
            assert "Evening" in day_data

    def test_revenue_by_category(self, populated_store: Store) -> None:
        result = get_revenue_by_category(populated_store)
        assert result["total"] > 0
        assert "nhs" in result["breakdown"]
        assert "private" in result["breakdown"]
        assert "insurance" in result["breakdown"]
        # Verify percentages add up to ~100%
        total_pct = sum(result["percentages"].values())
        assert abs(total_pct - 100.0) < 1.0 or total_pct == 0

    def test_dentist_performance(self, populated_store: Store) -> None:
        members = populated_store.list_team_members()
        dentist = next(m for m in members if m["role"] == "dentist")
        result = get_dentist_performance(populated_store, dentist["id"])
        assert result["dentist_id"] == dentist["id"]
        assert result["name"] == dentist["name"]
        assert result["estimated_revenue"] >= 0

    def test_dentist_performance_not_found(self, populated_store: Store) -> None:
        result = get_dentist_performance(populated_store, 9999)
        assert "error" in result

    def test_dentist_comparison(self, populated_store: Store) -> None:
        result = get_dentist_comparison(populated_store)
        assert result["total"] == 2
        assert len(result["dentists"]) == 2
        for d in result["dentists"]:
            assert "name" in d
            assert "revenue" in d
            assert "patients" in d

    def test_dentist_outcomes(self, populated_store: Store) -> None:
        members = populated_store.list_team_members()
        dentist = next(m for m in members if m["role"] == "dentist")
        result = get_dentist_outcomes(populated_store, dentist["id"])
        assert result["dentist_id"] == dentist["id"]
        assert "retreatment_rate" in result
        assert "complication_rate" in result

    def test_cpd_status(self, populated_store: Store) -> None:
        result = get_cpd_status(populated_store)
        assert result["total_members"] == 4
        # All members should have shortfalls since no CPD is tracked
        assert result["members_with_shortfall"] >= 0
        for member in result["team"]:
            assert "required_hours" in member
            assert "completed_hours" in member

    def test_patient_journey(self, populated_store: Store) -> None:
        result = get_patient_journey_metrics(populated_store)
        assert result["total_patients"] == 15
        assert result["patients_with_screening"] >= 0
        assert result["patients_with_treatment"] >= 0
        assert 0 <= result["journey_completion_rate"] <= 100

    def test_communication_preferences(self, populated_store: Store) -> None:
        result = get_communication_preferences(populated_store)
        assert "channels" in result
        assert "recommendation" in result


# ══════════════════════════════════════════════════════════════
# RECOMMENDATIONS ENGINE TESTS
# ══════════════════════════════════════════════════════════════

class TestRecommendationsEngine:
    """Test the AI recommendations engine."""

    def test_recommendations_structure(self, populated_store: Store) -> None:
        recs = generate_recommendations(populated_store)
        assert isinstance(recs, list)
        for rec in recs:
            assert "id" in rec
            assert "category" in rec
            assert "priority" in rec
            assert "title" in rec
            assert "description" in rec
            assert "impact" in rec
            assert "action" in rec
            assert "evidence" in rec

    def test_recommendations_valid_categories(self, populated_store: Store) -> None:
        recs = generate_recommendations(populated_store)
        valid_categories = {"revenue", "efficiency", "clinical", "patient_experience", "marketing", "compliance"}
        for rec in recs:
            assert rec["category"] in valid_categories, f"Invalid category: {rec['category']}"

    def test_recommendations_valid_priorities(self, populated_store: Store) -> None:
        recs = generate_recommendations(populated_store)
        valid_priorities = {"high", "medium", "low"}
        for rec in recs:
            assert rec["priority"] in valid_priorities

    def test_recommendations_sorted_by_priority(self, populated_store: Store) -> None:
        recs = generate_recommendations(populated_store)
        priority_order = {"high": 0, "medium": 1, "low": 2}
        for i in range(len(recs) - 1):
            assert priority_order[recs[i]["priority"]] <= priority_order[recs[i + 1]["priority"]]

    def test_recommendations_unique_ids(self, populated_store: Store) -> None:
        recs = generate_recommendations(populated_store)
        ids = [r["id"] for r in recs]
        assert len(ids) == len(set(ids)), "Duplicate recommendation IDs found"

    def test_recommendations_contain_numbers(self, populated_store: Store) -> None:
        """Recommendations should be specific with numbers, not generic advice."""
        recs = generate_recommendations(populated_store)
        for rec in recs:
            # At least the description or evidence should contain numeric data
            has_numbers = any(
                any(c.isdigit() for c in text)
                for text in [rec.get("description", ""), rec.get("evidence", "")]
                if text
            )
            assert has_numbers, f"Recommendation '{rec['title']}' lacks specific numbers"

    def test_dspt_recommendation(self, populated_store: Store) -> None:
        """Should flag incomplete DSPT status."""
        recs = generate_recommendations(populated_store)
        dspt_recs = [r for r in recs if "dspt" in r["id"].lower() or "dspt" in r.get("title", "").lower()]
        assert len(dspt_recs) > 0, "Expected DSPT compliance recommendation"

    def test_cpd_recommendation(self, populated_store: Store) -> None:
        """Should flag CPD shortfalls."""
        recs = generate_recommendations(populated_store)
        cpd_recs = [r for r in recs if "cpd" in r["id"].lower()]
        assert len(cpd_recs) > 0, "Expected CPD compliance recommendation"

    def test_marketing_recommendation_when_no_content(self, populated_store: Store) -> None:
        """Should recommend marketing when no content exists."""
        recs = generate_recommendations(populated_store)
        mkt_recs = [r for r in recs if r["category"] == "marketing"]
        assert len(mkt_recs) > 0, "Expected marketing recommendation when no content exists"


# ══════════════════════════════════════════════════════════════
# API ENDPOINT TESTS
# ══════════════════════════════════════════════════════════════

class TestInsightsAPI:
    """Test the insights API endpoints."""

    def test_practice_endpoint(self) -> None:
        r = client.get("/api/insights/practice")
        assert r.status_code == 200
        data = r.json()
        assert "total_patients" in data
        assert "revenue_mtd" in data
        assert "recall_rate" in data

    def test_recommendations_endpoint(self) -> None:
        r = client.get("/api/insights/recommendations")
        assert r.status_code == 200
        data = r.json()
        assert "recommendations" in data
        assert "total" in data
        assert "high_priority" in data
        assert isinstance(data["recommendations"], list)

    def test_revenue_endpoint(self) -> None:
        r = client.get("/api/insights/revenue")
        assert r.status_code == 200
        data = r.json()
        assert "by_category" in data
        assert "by_chair" in data

    def test_scheduling_endpoint(self) -> None:
        r = client.get("/api/insights/scheduling")
        assert r.status_code == 200
        data = r.json()
        assert "efficiency" in data
        assert "busiest_times" in data

    def test_dentists_endpoint(self) -> None:
        r = client.get("/api/insights/dentists")
        assert r.status_code == 200
        data = r.json()
        assert "dentists" in data
        assert "total" in data

    def test_dentist_not_found(self) -> None:
        r = client.get("/api/insights/dentist/99999")
        assert r.status_code == 404

    def test_patient_journey_endpoint(self) -> None:
        r = client.get("/api/insights/patient-journey")
        assert r.status_code == 200
        data = r.json()
        assert "journey" in data
        assert "nps" in data
        assert "communication" in data
        assert "recall" in data
        assert "acquisition" in data

    def test_cpd_endpoint(self) -> None:
        r = client.get("/api/insights/cpd")
        assert r.status_code == 200
        data = r.json()
        assert "team" in data
        assert "total_members" in data


# ══════════════════════════════════════════════════════════════
# EDGE CASE TESTS
# ══════════════════════════════════════════════════════════════

class TestEdgeCases:
    """Edge cases and boundary conditions."""

    def test_single_patient_store(self, tmp_path: Path) -> None:
        db = tmp_path / "single.db"
        store = Store(db_path=db)
        store.save_patient({"name": "Solo Patient", "age": 45})

        dashboard = get_practice_dashboard(store)
        assert dashboard["total_patients"] == 1

        recs = generate_recommendations(store)
        assert isinstance(recs, list)

    def test_single_dentist(self, tmp_path: Path) -> None:
        db = tmp_path / "single_dentist.db"
        store = Store(db_path=db)
        store.add_team_member({"name": "Dr. Only", "role": "dentist"})

        comparison = get_dentist_comparison(store)
        assert comparison["total"] == 1

    def test_no_financial_data(self, tmp_path: Path) -> None:
        db = tmp_path / "no_finance.db"
        store = Store(db_path=db)
        store.save_patient({"name": "Test", "age": 30})

        dashboard = get_practice_dashboard(store)
        assert dashboard["revenue_mtd"] == 0.0
        assert dashboard["revenue_ytd"] == 0.0
        assert dashboard["avg_revenue_per_patient"] == 0.0

        rev = get_revenue_by_category(store)
        assert rev["total"] == 0.0

    def test_all_nhs_practice(self, tmp_path: Path) -> None:
        """Practice with only NHS invoices."""
        db = tmp_path / "nhs_only.db"
        store = Store(db_path=db)
        from datetime import date
        store.save_invoice({
            "id": "NHS-001",
            "patient_id": None,
            "date": date.today().isoformat(),
            "type": "nhs",
            "items": "[]",
            "subtotal": 65.20,
            "vat": 0,
            "total": 65.20,
            "nhs_band": "2",
            "status": "paid",
        })

        rev = get_revenue_by_category(store)
        assert rev["breakdown"]["nhs"] == 65.20
        assert rev["breakdown"]["private"] == 0.0

    def test_large_patient_count(self, tmp_path: Path) -> None:
        """Ensure functions handle larger datasets."""
        db = tmp_path / "large.db"
        store = Store(db_path=db)
        for i in range(100):
            store.save_patient({"name": f"Patient {i}", "age": 20 + (i % 60)})

        dashboard = get_practice_dashboard(store)
        assert dashboard["total_patients"] == 100

        recall = get_recall_effectiveness(store)
        assert recall["total_patients"] == 100
