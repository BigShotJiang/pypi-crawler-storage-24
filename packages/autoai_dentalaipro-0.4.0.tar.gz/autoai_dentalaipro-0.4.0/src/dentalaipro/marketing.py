"""Social media and campaign management module for DentalAI Pro.

Generates dental-specific social media content, manages content calendars,
and provides patient communication templates.
"""

from __future__ import annotations

import json
import random
import time
from datetime import datetime, date, timedelta
from typing import Any, Dict, List, Optional


# ── Platform Configs ───────────────────────────────────────────
PLATFORMS = {
    "facebook": {
        "label": "Facebook",
        "max_chars": 63206,
        "hashtag_count": 3,
        "best_times": ["09:00", "13:00", "16:00"],
        "image_rec": "1200x630px",
    },
    "instagram": {
        "label": "Instagram",
        "max_chars": 2200,
        "hashtag_count": 15,
        "best_times": ["11:00", "13:00", "19:00"],
        "image_rec": "1080x1080px",
    },
    "linkedin": {
        "label": "LinkedIn",
        "max_chars": 3000,
        "hashtag_count": 5,
        "best_times": ["08:00", "12:00", "17:00"],
        "image_rec": "1200x627px",
    },
    "twitter": {
        "label": "Twitter/X",
        "max_chars": 280,
        "hashtag_count": 2,
        "best_times": ["09:00", "12:00", "17:00"],
        "image_rec": "1600x900px",
    },
    "google_business": {
        "label": "Google My Business",
        "max_chars": 1500,
        "hashtag_count": 0,
        "best_times": ["10:00", "14:00"],
        "image_rec": "1200x900px",
    },
}

# ── Content Topics ─────────────────────────────────────────────
DENTAL_HEALTH_TIPS = [
    {
        "topic": "Brushing Technique",
        "tip": "Use a soft-bristled toothbrush at a 45-degree angle to the gumline. Brush for a full 2 minutes, twice daily.",
        "hashtags": ["#DentalHealth", "#OralHygiene", "#HealthySmile"],
    },
    {
        "topic": "Flossing Matters",
        "tip": "Flossing removes up to 40% of plaque that brushing alone misses. Gently curve the floss around each tooth in a C-shape.",
        "hashtags": ["#Flossing", "#DentalCare", "#OralHealth"],
    },
    {
        "topic": "Sugar & Teeth",
        "tip": "It is not how much sugar you eat, but how often. Each sugar exposure causes a 20-minute acid attack on your enamel.",
        "hashtags": ["#DentalTips", "#SugarFree", "#HealthyTeeth"],
    },
    {
        "topic": "Children's Dental Care",
        "tip": "Start brushing as soon as the first tooth appears. Use a smear of fluoride toothpaste for under-3s, a pea-sized amount for 3-6 year olds.",
        "hashtags": ["#KidsDental", "#ChildDentistry", "#ParentingTips"],
    },
    {
        "topic": "Mouthguards for Sport",
        "tip": "A custom-fitted mouthguard from your dentist provides far better protection than shop-bought alternatives. Essential for contact sports.",
        "hashtags": ["#SportsDentistry", "#Mouthguard", "#ProtectYourSmile"],
    },
    {
        "topic": "Dry Mouth Awareness",
        "tip": "Many medications cause dry mouth, which increases decay risk. Stay hydrated, chew sugar-free gum, and mention dry mouth at your dental visit.",
        "hashtags": ["#DryMouth", "#OralHealth", "#DentalAwareness"],
    },
    {
        "topic": "Gum Disease Signs",
        "tip": "Bleeding when you brush is NOT normal. It is an early sign of gum disease. Early treatment can prevent tooth loss.",
        "hashtags": ["#GumHealth", "#Periodontitis", "#DentalCheck"],
    },
    {
        "topic": "Electric vs Manual",
        "tip": "Studies show electric toothbrushes with oscillating heads remove 21% more plaque than manual brushes. The best brush is the one you use correctly!",
        "hashtags": ["#ElectricToothbrush", "#DentalTech", "#OralCare"],
    },
    {
        "topic": "Dental Anxiety",
        "tip": "1 in 4 people experience dental anxiety. Modern dentistry offers many comfort options. Talk to your dentist about your concerns - we are here to help.",
        "hashtags": ["#DentalAnxiety", "#NervousPatients", "#GentleDentistry"],
    },
    {
        "topic": "Regular Check-ups",
        "tip": "Regular dental check-ups help catch problems early when they are easier and cheaper to treat. Do not wait for pain - prevention is key!",
        "hashtags": ["#DentalCheckup", "#Prevention", "#SmileCare"],
    },
]

SEASONAL_CAMPAIGNS = {
    "january": {
        "theme": "New Year New Smile",
        "content": "New year, new smile goals! Book your check-up this January and start the year with a healthy smile.",
        "hashtags": ["#NewYearNewSmile", "#JanuaryGoals"],
    },
    "february": {
        "theme": "Valentine's Smile",
        "content": "Fall in love with your smile this Valentine's Day. Ask us about our cosmetic treatments.",
        "hashtags": ["#ValentineSmile", "#LoveYourSmile"],
    },
    "march": {
        "theme": "National Smile Month Prep",
        "content": "Getting ready for National Smile Month in May. Book your hygiene appointment now!",
        "hashtags": ["#SmileMonth", "#DentalHealth"],
    },
    "april": {
        "theme": "Easter Dental Tips",
        "content": "Enjoy Easter treats responsibly! Eat chocolate in one sitting rather than grazing. This reduces acid attacks on your teeth.",
        "hashtags": ["#EasterSmile", "#DentalTips"],
    },
    "may": {
        "theme": "National Smile Month",
        "content": "It's National Smile Month! Three key messages: brush for 2 minutes twice daily, reduce sugary foods, visit your dentist regularly.",
        "hashtags": ["#NationalSmileMonth", "#SmileMonth", "#OralHealth"],
    },
    "june": {
        "theme": "Summer Smile",
        "content": "Summer is here! Book a teeth whitening consultation and get your smile holiday-ready.",
        "hashtags": ["#SummerSmile", "#TeethWhitening"],
    },
    "july": {
        "theme": "Holiday Dental Kit",
        "content": "Going on holiday? Pack a dental emergency kit: toothbrush, toothpaste, floss, temporary filling material, and our emergency number!",
        "hashtags": ["#HolidayDental", "#TravelTips"],
    },
    "august": {
        "theme": "Back to School",
        "content": "Back to school prep: Book your child's dental check-up before the new term. NHS dental treatment is free for under 18s!",
        "hashtags": ["#BackToSchool", "#ChildDental", "#NHSDentistry"],
    },
    "september": {
        "theme": "Mouth Cancer Action",
        "content": "September marks the start of Mouth Cancer Awareness. Early detection saves lives. If a mouth ulcer hasn't healed in 3 weeks, get it checked.",
        "hashtags": ["#MouthCancer", "#EarlyDetection"],
    },
    "october": {
        "theme": "Halloween Dental Tips",
        "content": "This Halloween, enjoy treats but protect those teeth! Choose chocolate over sticky sweets - it's easier to clean off!",
        "hashtags": ["#HalloweenDental", "#HealthyHalloween"],
    },
    "november": {
        "theme": "Mouth Cancer Action Month",
        "content": "November is Mouth Cancer Action Month. Be Mouthaware! Check for unusual lumps, red/white patches, or ulcers that don't heal. We check at every exam.",
        "hashtags": ["#MouthCancerAction", "#BeMouthaware", "#MCAM"],
    },
    "december": {
        "theme": "Christmas Smile Makeover",
        "content": "Give yourself the gift of a beautiful smile this Christmas! Book a cosmetic consultation before the year ends.",
        "hashtags": ["#ChristmasSmile", "#SmileMakeover"],
    },
}

# ── Patient Communication Templates ───────────────────────────
COMMUNICATION_TEMPLATES = {
    "recall_6month": {
        "type": "recall",
        "subject": "Your 6-month dental check-up is due",
        "sms": "Hi {name}, your dental check-up is due. Book online or call us on {phone}. {practice_name}",
        "email": (
            "Dear {name},\n\n"
            "We hope you are well! It has been 6 months since your last dental visit "
            "and it is time for your routine check-up.\n\n"
            "Regular check-ups help us catch any problems early, when they are simpler "
            "and often cheaper to treat.\n\n"
            "Book your appointment:\n"
            "- Call us: {phone}\n"
            "- Email: {email}\n\n"
            "We look forward to seeing you!\n\n"
            "Best wishes,\n{practice_name}"
        ),
    },
    "treatment_followup": {
        "type": "followup",
        "subject": "How are you feeling after your treatment?",
        "sms": "Hi {name}, we hope you're recovering well after your {treatment}. Any concerns? Call {phone}. {practice_name}",
        "email": (
            "Dear {name},\n\n"
            "We hope you are recovering well after your {treatment} on {date}.\n\n"
            "Here are some aftercare tips:\n"
            "- Take any prescribed pain relief as directed\n"
            "- Avoid very hot or cold food and drinks for 24 hours\n"
            "- If you experience any unusual swelling or pain, please contact us\n\n"
            "If you have any concerns at all, please do not hesitate to call us on {phone}.\n\n"
            "Best wishes,\n{practice_name}"
        ),
    },
    "post_extraction_care": {
        "type": "aftercare",
        "subject": "Your post-extraction care instructions",
        "email": (
            "Dear {name},\n\n"
            "Following your extraction today, please follow these important instructions:\n\n"
            "1. Bite on the gauze pad for 30-45 minutes\n"
            "2. Do NOT rinse, spit, or use a straw for 24 hours\n"
            "3. After 24 hours, gently rinse with warm salt water (1 tsp salt in a glass of warm water)\n"
            "4. Avoid smoking for at least 48 hours (ideally longer)\n"
            "5. Eat soft foods and chew on the opposite side\n"
            "6. Take ibuprofen or paracetamol as needed for pain\n\n"
            "If you experience:\n"
            "- Excessive bleeding that does not stop\n"
            "- Severe pain after 3 days\n"
            "- Fever or swelling\n"
            "Please call us immediately on {phone}.\n\n"
            "{practice_name}"
        ),
    },
    "birthday": {
        "type": "birthday",
        "subject": "Happy Birthday from {practice_name}!",
        "sms": "Happy Birthday {name}! From all the team at {practice_name}. Here's to another year of healthy smiles!",
        "email": (
            "Dear {name},\n\n"
            "Happy Birthday from all of us at {practice_name}!\n\n"
            "Wishing you a wonderful day filled with smiles.\n\n"
            "Best wishes,\nThe {practice_name} Team"
        ),
    },
    "newsletter": {
        "type": "newsletter",
        "subject": "{practice_name} Newsletter - {month} {year}",
        "email": (
            "Dear {name},\n\n"
            "Welcome to our {month} newsletter!\n\n"
            "--- PRACTICE NEWS ---\n"
            "{practice_news}\n\n"
            "--- DENTAL TIP OF THE MONTH ---\n"
            "{dental_tip}\n\n"
            "--- SPECIAL OFFERS ---\n"
            "{offers}\n\n"
            "--- TEAM UPDATE ---\n"
            "{team_update}\n\n"
            "Book your appointment: {phone} | {email}\n\n"
            "Best wishes,\n{practice_name}"
        ),
    },
}


def generate_social_post(
    topic: str = "health_tip",
    platform: str = "facebook",
    practice_name: str = "",
    custom_topic: str = "",
) -> Dict[str, Any]:
    """Generate a social media post for a dental practice.

    Args:
        topic: Post topic type (health_tip, announcement, treatment_spotlight,
               testimonial, seasonal, nhs_awareness).
        platform: Target platform (facebook, instagram, linkedin, twitter, google_business).
        practice_name: Practice name for personalisation.
        custom_topic: Custom topic description for AI generation.

    Returns:
        Generated post content with platform-specific formatting.
    """
    platform_config = PLATFORMS.get(platform, PLATFORMS["facebook"])
    now = datetime.now()
    month_key = now.strftime("%B").lower()

    if topic == "health_tip":
        tip = random.choice(DENTAL_HEALTH_TIPS)
        post_text = _format_health_tip(tip, platform, practice_name)
        hashtags = tip["hashtags"]
    elif topic == "seasonal":
        campaign = SEASONAL_CAMPAIGNS.get(
            month_key,
            SEASONAL_CAMPAIGNS.get("january"),
        )
        post_text = _format_seasonal(campaign, platform, practice_name)
        hashtags = campaign.get("hashtags", [])
    elif topic == "announcement":
        post_text = _format_announcement(custom_topic, platform, practice_name)
        hashtags = ["#DentalNews", "#PracticeUpdate"]
    elif topic == "treatment_spotlight":
        post_text = _format_treatment_spotlight(custom_topic, platform, practice_name)
        hashtags = ["#DentalTreatment", "#SmileTransformation", "#Dentistry"]
    elif topic == "testimonial":
        post_text = _format_testimonial_template(platform, practice_name)
        hashtags = ["#PatientReview", "#HappyPatient", "#DentalCare"]
    elif topic == "nhs_awareness":
        post_text = _format_nhs_awareness(platform, practice_name)
        hashtags = ["#NHSDentist", "#NHSDentistry", "#DentalHealth"]
    else:
        post_text = f"Visit {practice_name or 'our practice'} for all your dental needs!"
        hashtags = ["#Dentist", "#DentalCare"]

    # Trim hashtags to platform limit
    max_tags = platform_config.get("hashtag_count", 3)
    hashtags = hashtags[:max_tags]

    # Add hashtags to post
    if hashtags and platform != "google_business":
        hashtag_str = " ".join(hashtags)
        full_post = f"{post_text}\n\n{hashtag_str}"
    else:
        full_post = post_text

    # Trim to platform max length
    max_chars = platform_config.get("max_chars", 5000)
    if len(full_post) > max_chars:
        full_post = full_post[:max_chars - 3] + "..."

    return {
        "content": full_post,
        "platform": platform,
        "platform_label": platform_config["label"],
        "topic": topic,
        "hashtags": hashtags,
        "image_recommendation": platform_config["image_rec"],
        "best_posting_times": platform_config["best_times"],
        "character_count": len(full_post),
        "max_characters": max_chars,
    }


def _format_health_tip(tip: Dict, platform: str, practice_name: str) -> str:
    """Format a health tip for a specific platform."""
    name = practice_name or "Your Dentist"
    if platform == "twitter":
        return f"{tip['tip'][:200]} - {name}"
    elif platform == "instagram":
        return (
            f"DENTAL TIP: {tip['topic']}\n\n"
            f"{tip['tip']}\n\n"
            f"Save this post for later!\n\n"
            f"Book your check-up with {name} today."
        )
    elif platform == "linkedin":
        return (
            f"Dental Health Tip: {tip['topic']}\n\n"
            f"{tip['tip']}\n\n"
            f"As dental professionals, we see the impact of good oral hygiene habits every day. "
            f"Small changes make a big difference.\n\n"
            f"- {name}"
        )
    else:
        return (
            f"{tip['topic']}\n\n"
            f"{tip['tip']}\n\n"
            f"Questions about your dental health? We are here to help! "
            f"Book your appointment with {name}."
        )


def _format_seasonal(campaign: Dict, platform: str, practice_name: str) -> str:
    """Format a seasonal campaign post."""
    name = practice_name or "Our Practice"
    content = campaign.get("content", "")
    theme = campaign.get("theme", "")
    if platform == "twitter":
        return f"{content[:240]} - {name}"
    return f"{theme}\n\n{content}\n\nBook with {name} today!"


def _format_announcement(custom_topic: str, platform: str, practice_name: str) -> str:
    """Format a practice announcement."""
    name = practice_name or "Our Practice"
    topic = custom_topic or "We have exciting news to share!"
    if platform == "twitter":
        return f"NEWS: {topic[:220]} - {name}"
    return (
        f"ANNOUNCEMENT from {name}\n\n"
        f"{topic}\n\n"
        f"We are always working to improve your experience. "
        f"Contact us for more information!"
    )


def _format_treatment_spotlight(custom_topic: str, platform: str, practice_name: str) -> str:
    """Format a treatment spotlight post."""
    name = practice_name or "Our Practice"
    treatment = custom_topic or "teeth whitening"
    return (
        f"TREATMENT SPOTLIGHT: {treatment.title()}\n\n"
        f"Interested in {treatment}? Here's what you need to know:\n\n"
        f"- Safe and effective when done professionally\n"
        f"- Results tailored to your goals\n"
        f"- We will talk you through every step\n\n"
        f"Book a consultation with {name} to learn more!"
    )


def _format_testimonial_template(platform: str, practice_name: str) -> str:
    """Generate a GDPR-compliant testimonial template."""
    name = practice_name or "Our Practice"
    return (
        f"What our patients say about {name}:\n\n"
        f"\"[INSERT PATIENT TESTIMONIAL WITH WRITTEN CONSENT]\"\n\n"
        f"- [PATIENT FIRST NAME ONLY]\n\n"
        f"We love hearing from happy patients! "
        f"Thank you for trusting us with your smile.\n\n"
        f"IMPORTANT: Only publish with written patient consent (GDPR compliant)."
    )


def _format_nhs_awareness(platform: str, practice_name: str) -> str:
    """Format an NHS awareness post."""
    name = practice_name or "Our Practice"
    return (
        f"Did you know? NHS dental treatment is available at {name}!\n\n"
        f"NHS Band charges (2024/25):\n"
        f"Band 1 (Check-up): GBP 26.80\n"
        f"Band 2 (Fillings): GBP 73.50\n"
        f"Band 3 (Crowns/Dentures): GBP 319.10\n\n"
        f"Free for: Under 18s, pregnant women, benefit recipients & more.\n\n"
        f"Call us to register as an NHS patient."
    )


def get_content_calendar(
    practice_name: str = "",
    start_date: Optional[str] = None,
    weeks: int = 1,
) -> List[Dict[str, Any]]:
    """Generate a content calendar with suggested posts.

    Args:
        practice_name: Practice name for personalisation.
        start_date: Start date (YYYY-MM-DD). Defaults to next Monday.
        weeks: Number of weeks to generate.

    Returns:
        List of calendar entries with dates and suggested content.
    """
    if start_date:
        start = date.fromisoformat(start_date)
    else:
        today = date.today()
        days_until_monday = (7 - today.weekday()) % 7
        if days_until_monday == 0:
            days_until_monday = 7
        start = today + timedelta(days=days_until_monday)

    calendar = []
    platforms_cycle = ["facebook", "instagram", "linkedin", "twitter", "google_business"]
    topics_cycle = ["health_tip", "treatment_spotlight", "health_tip", "seasonal", "nhs_awareness"]

    for week in range(weeks):
        week_start = start + timedelta(weeks=week)
        # 3 posts per week (Mon, Wed, Fri)
        for day_offset, (day_label) in enumerate([(0, "Monday"), (2, "Wednesday"), (4, "Friday")]):
            post_date = week_start + timedelta(days=day_label[0])
            platform = platforms_cycle[(week * 3 + day_offset) % len(platforms_cycle)]
            topic = topics_cycle[(week * 3 + day_offset) % len(topics_cycle)]

            post = generate_social_post(
                topic=topic,
                platform=platform,
                practice_name=practice_name,
            )

            calendar.append({
                "date": post_date.isoformat(),
                "day": day_label[1],
                "platform": platform,
                "platform_label": PLATFORMS[platform]["label"],
                "topic": topic,
                "suggested_content": post["content"],
                "status": "draft",
                "best_time": PLATFORMS[platform]["best_times"][0],
            })

    return calendar


def get_templates(template_type: Optional[str] = None) -> List[Dict[str, Any]]:
    """Get patient communication templates.

    Args:
        template_type: Filter by type (recall, followup, aftercare, birthday, newsletter).
                       None returns all templates.

    Returns:
        List of template dictionaries.
    """
    templates = []
    for key, tmpl in COMMUNICATION_TEMPLATES.items():
        if template_type and tmpl["type"] != template_type:
            continue
        templates.append({
            "key": key,
            **tmpl,
        })
    return templates


def get_platforms() -> Dict[str, Any]:
    """Return all supported platforms and their configurations."""
    return PLATFORMS
