"""CLI entry point for DentalAI Pro."""

from __future__ import annotations

import click
from rich.console import Console
from rich.panel import Panel

console = Console()


@click.group()
def main() -> None:
    """DentalAI Pro — Enterprise Clinical Dental AI."""
    pass


@main.command()
@click.option("--host", default="0.0.0.0", help="Bind address")
@click.option("--port", default=8080, type=int, help="Port number")
@click.option("--reload", is_flag=True, help="Enable auto-reload for development")
def serve(host: str, port: int, reload: bool) -> None:
    """Start the DentalAI Pro server."""
    import uvicorn

    console.print(Panel.fit(
        f"[bold blue]DentalAI Pro[/bold blue] v0.1.0\n"
        f"[dim]Enterprise Clinical Dental AI[/dim]\n\n"
        f"Open: [bold green]http://localhost:{port}[/bold green]\n"
        f"API Docs: [bold green]http://localhost:{port}/docs[/bold green]",
        title="Starting Server",
        border_style="blue",
    ))

    uvicorn.run(
        "dentalaipro.app:app",
        host=host,
        port=port,
        reload=reload,
        log_level="info",
    )


@main.command()
def demo_data() -> None:
    """Insert demo patient data for testing."""
    from .store import Store

    store = Store()

    patients = [
        {
            "name": "Jane Smith",
            "age": 52,
            "sex": "F",
            "medical_conditions": ["hypertension", "type 2 diabetes (controlled)"],
            "medications": ["metformin", "lisinopril", "aspirin"],
            "risk_factors": ["tobacco"],
        },
        {
            "name": "Robert Johnson",
            "age": 34,
            "sex": "M",
            "medical_conditions": [],
            "medications": [],
            "risk_factors": [],
        },
        {
            "name": "Maria Garcia",
            "age": 67,
            "sex": "F",
            "medical_conditions": ["osteoporosis", "atrial fibrillation"],
            "medications": ["alendronate", "warfarin"],
            "risk_factors": [],
        },
    ]

    for p in patients:
        pid = store.save_patient(p)
        console.print(f"  [green]+[/green] Saved patient: {p['name']} (ID: {pid})")

    store.close()
    console.print(Panel.fit("[bold green]Demo data loaded successfully[/bold green]", border_style="green"))


if __name__ == "__main__":
    main()
