"""Shared type definitions for DentalAI Pro."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class Urgency(str, Enum):
    IMMEDIATE = "IMMEDIATE"
    SOON = "SOON"
    MONITOR = "MONITOR"
    NOT_NEEDED = "NOT_NEEDED"


class RiskLevel(str, Enum):
    LOW = "low"
    MODERATE = "moderate"
    HIGH = "high"
    CRITICAL = "critical"


class RadiographicAppearance(str, Enum):
    RADIOLUCENT = "radiolucent"
    RADIOPAQUE = "radiopaque"
    MIXED = "mixed"


class MalignantPotential(str, Enum):
    NONE = "none"
    LOW = "low"
    MODERATE = "moderate"
    HIGH = "high"


@dataclass
class PatientContext:
    """Patient information that persists across all modules."""
    name: str = ""
    age: int = 0
    sex: str = ""
    medical_conditions: List[str] = field(default_factory=list)
    medications: List[str] = field(default_factory=list)
    risk_factors: List[str] = field(default_factory=list)


@dataclass
class LesionInput:
    location: str = ""
    colors: List[str] = field(default_factory=list)
    textures: List[str] = field(default_factory=list)
    borders: str = ""
    size_mm: float = 0.0
    duration: str = ""
    symptoms: List[str] = field(default_factory=list)
    patient_age: int = 0
    patient_sex: str = ""
    risk_factors: List[str] = field(default_factory=list)


@dataclass
class ScreeningResult:
    cancer_risk_score: int = 0
    differentials: List[Dict[str, Any]] = field(default_factory=list)
    biopsy_recommendation: Dict[str, Any] = field(default_factory=dict)
    referral: Dict[str, Any] = field(default_factory=dict)
    next_steps: List[str] = field(default_factory=list)


@dataclass
class RadiologyInput:
    study_type: str = ""
    tooth_region: str = ""
    findings: str = ""
    quick_findings: List[str] = field(default_factory=list)


@dataclass
class TreatmentInput:
    diagnosis: str = ""
    diagnosis_category: str = ""
    planned_procedures: List[Dict[str, str]] = field(default_factory=list)
    tooth_number: str = ""
    medical_conditions: List[str] = field(default_factory=list)
    medications: List[str] = field(default_factory=list)


@dataclass
class BillingInput:
    cdt_codes: List[str] = field(default_factory=list)
    payer: str = ""
    diagnosis_codes: List[str] = field(default_factory=list)
    tooth_numbers: List[str] = field(default_factory=list)
