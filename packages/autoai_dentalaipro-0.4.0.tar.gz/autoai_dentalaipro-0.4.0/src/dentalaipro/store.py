"""SQLite unified store for DentalAI Pro — patients, records, compliance logs."""

from __future__ import annotations

import json
import sqlite3
import time
from pathlib import Path
from typing import Any, Dict, List, Optional


_DEFAULT_DB = Path.home() / ".dentalaipro" / "dentalaipro.db"


class Store:
    """Unified SQLite store for all DentalAI Pro data."""

    def __init__(self, db_path: Optional[Path] = None) -> None:
        self.db_path = db_path or _DEFAULT_DB
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn: Optional[sqlite3.Connection] = None
        self._ensure_schema()

    def _get_conn(self) -> sqlite3.Connection:
        if self._conn is None:
            self._conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
            self._conn.row_factory = sqlite3.Row
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.execute("PRAGMA foreign_keys=ON")
        return self._conn

    def _ensure_schema(self) -> None:
        conn = self._get_conn()
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS patients (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                age INTEGER DEFAULT 0,
                sex TEXT DEFAULT '',
                medical_conditions TEXT DEFAULT '[]',
                medications TEXT DEFAULT '[]',
                risk_factors TEXT DEFAULT '[]',
                created_at REAL DEFAULT (strftime('%s','now')),
                updated_at REAL DEFAULT (strftime('%s','now'))
            );

            CREATE TABLE IF NOT EXISTS screening_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                patient_id INTEGER REFERENCES patients(id),
                input_data TEXT NOT NULL,
                result_data TEXT NOT NULL,
                created_at REAL DEFAULT (strftime('%s','now'))
            );

            CREATE TABLE IF NOT EXISTS radiology_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                patient_id INTEGER REFERENCES patients(id),
                input_data TEXT NOT NULL,
                result_data TEXT NOT NULL,
                created_at REAL DEFAULT (strftime('%s','now'))
            );

            CREATE TABLE IF NOT EXISTS treatment_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                patient_id INTEGER REFERENCES patients(id),
                input_data TEXT NOT NULL,
                result_data TEXT NOT NULL,
                created_at REAL DEFAULT (strftime('%s','now'))
            );

            CREATE TABLE IF NOT EXISTS compliance_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                log_type TEXT NOT NULL,
                check_id TEXT DEFAULT '',
                details TEXT DEFAULT '{}',
                logged_by TEXT DEFAULT '',
                created_at REAL DEFAULT (strftime('%s','now'))
            );

            CREATE TABLE IF NOT EXISTS billing_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                patient_id INTEGER REFERENCES patients(id),
                input_data TEXT NOT NULL,
                result_data TEXT NOT NULL,
                created_at REAL DEFAULT (strftime('%s','now'))
            );

            CREATE TABLE IF NOT EXISTS practice_profile (
                id INTEGER PRIMARY KEY,
                name TEXT DEFAULT '',
                address TEXT DEFAULT '',
                phone TEXT DEFAULT '',
                email TEXT DEFAULT '',
                practice_type TEXT DEFAULT '',
                country TEXT DEFAULT '',
                num_surgeries INTEGER DEFAULT 0,
                num_dentists INTEGER DEFAULT 0,
                num_hygienists INTEGER DEFAULT 0,
                num_nurses INTEGER DEFAULT 0,
                primary_software TEXT DEFAULT '',
                nhs_contract_number TEXT DEFAULT '',
                cqc_registration TEXT DEFAULT '',
                dspt_status TEXT DEFAULT '',
                caldicott_guardian TEXT DEFAULT '',
                regulatory_data TEXT DEFAULT '{}',
                clinical_config TEXT DEFAULT '{}',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS team_members (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT DEFAULT '',
                role TEXT DEFAULT '',
                license_number TEXT DEFAULT '',
                gdc_number TEXT DEFAULT '',
                npi_number TEXT DEFAULT '',
                dea_number TEXT DEFAULT '',
                access_level TEXT DEFAULT 'admin',
                start_date TEXT DEFAULT '',
                active INTEGER DEFAULT 1,
                created_at REAL DEFAULT (strftime('%s','now'))
            );

            CREATE TABLE IF NOT EXISTS onboarding_status (
                id INTEGER PRIMARY KEY,
                step INTEGER DEFAULT 1,
                practice_complete INTEGER DEFAULT 0,
                regulatory_complete INTEGER DEFAULT 0,
                clinical_complete INTEGER DEFAULT 0,
                team_complete INTEGER DEFAULT 0,
                golive_complete INTEGER DEFAULT 0,
                completed_at TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS ledger (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                date TEXT NOT NULL,
                type TEXT NOT NULL,
                category TEXT NOT NULL,
                subcategory TEXT DEFAULT '',
                description TEXT DEFAULT '',
                amount REAL NOT NULL,
                vat_rate REAL DEFAULT 0,
                vat_amount REAL DEFAULT 0,
                payment_method TEXT DEFAULT '',
                reference TEXT DEFAULT '',
                patient_id INTEGER,
                invoice_id TEXT DEFAULT '',
                tax_period TEXT DEFAULT '',
                created_at REAL DEFAULT (strftime('%s','now'))
            );

            CREATE TABLE IF NOT EXISTS invoices (
                id TEXT PRIMARY KEY,
                patient_id INTEGER,
                patient_name TEXT DEFAULT '',
                date TEXT NOT NULL,
                type TEXT NOT NULL,
                items TEXT NOT NULL,
                subtotal REAL NOT NULL,
                vat REAL DEFAULT 0,
                total REAL NOT NULL,
                nhs_band TEXT DEFAULT '',
                status TEXT DEFAULT 'pending',
                paid_date TEXT DEFAULT '',
                payment_method TEXT DEFAULT '',
                notes TEXT DEFAULT '',
                created_at REAL DEFAULT (strftime('%s','now'))
            );

            CREATE TABLE IF NOT EXISTS tax_periods (
                id TEXT PRIMARY KEY,
                period_type TEXT NOT NULL,
                start_date TEXT NOT NULL,
                end_date TEXT NOT NULL,
                total_income REAL DEFAULT 0,
                total_expenses REAL DEFAULT 0,
                total_vat_collected REAL DEFAULT 0,
                total_vat_paid REAL DEFAULT 0,
                net_vat REAL DEFAULT 0,
                status TEXT DEFAULT 'open',
                notes TEXT DEFAULT ''
            );

            CREATE TABLE IF NOT EXISTS marketing_content (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                type TEXT NOT NULL,
                platform TEXT DEFAULT '',
                title TEXT DEFAULT '',
                content TEXT NOT NULL,
                status TEXT DEFAULT 'draft',
                scheduled_date TEXT DEFAULT '',
                campaign TEXT DEFAULT '',
                created_at REAL DEFAULT (strftime('%s','now'))
            );

            CREATE TABLE IF NOT EXISTS migration_status (
                id INTEGER PRIMARY KEY,
                source_system TEXT DEFAULT '',
                status TEXT DEFAULT 'not_started',
                step INTEGER DEFAULT 1,
                patients_exported INTEGER DEFAULT 0,
                patients_imported INTEGER DEFAULT 0,
                records_verified INTEGER DEFAULT 0,
                issues TEXT DEFAULT '[]',
                started_at TIMESTAMP,
                completed_at TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS license (
                id INTEGER PRIMARY KEY,
                tier TEXT DEFAULT 'free',
                license_key TEXT DEFAULT '',
                practice_id TEXT DEFAULT '',
                activated_at TIMESTAMP,
                expires_at TIMESTAMP,
                max_dentists INTEGER DEFAULT 1,
                max_patients_month INTEGER DEFAULT 50,
                features TEXT DEFAULT '[]'
            );
        """)
        conn.commit()

    # ── Patient Operations ────────────────────────────────────────

    def save_patient(self, data: Dict[str, Any]) -> int:
        """Save or update a patient record. Returns patient ID."""
        conn = self._get_conn()
        patient_id = data.get("id")
        now = time.time()

        if patient_id:
            conn.execute(
                """UPDATE patients SET name=?, age=?, sex=?, medical_conditions=?,
                   medications=?, risk_factors=?, updated_at=? WHERE id=?""",
                (
                    data.get("name", ""),
                    data.get("age", 0),
                    data.get("sex", ""),
                    json.dumps(data.get("medical_conditions", [])),
                    json.dumps(data.get("medications", [])),
                    json.dumps(data.get("risk_factors", [])),
                    now,
                    patient_id,
                ),
            )
        else:
            cursor = conn.execute(
                """INSERT INTO patients (name, age, sex, medical_conditions, medications, risk_factors)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (
                    data.get("name", ""),
                    data.get("age", 0),
                    data.get("sex", ""),
                    json.dumps(data.get("medical_conditions", [])),
                    json.dumps(data.get("medications", [])),
                    json.dumps(data.get("risk_factors", [])),
                ),
            )
            patient_id = cursor.lastrowid

        conn.commit()
        return patient_id  # type: ignore[return-value]

    def get_patient(self, patient_id: int) -> Optional[Dict[str, Any]]:
        """Get a patient by ID."""
        conn = self._get_conn()
        row = conn.execute("SELECT * FROM patients WHERE id = ?", (patient_id,)).fetchone()
        if row is None:
            return None
        d = dict(row)
        d["medical_conditions"] = json.loads(d["medical_conditions"])
        d["medications"] = json.loads(d["medications"])
        d["risk_factors"] = json.loads(d["risk_factors"])
        return d

    def list_patients(self) -> List[Dict[str, Any]]:
        """List all patients."""
        conn = self._get_conn()
        rows = conn.execute("SELECT id, name, age, sex FROM patients ORDER BY updated_at DESC").fetchall()
        return [dict(r) for r in rows]

    # ── Record Operations ─────────────────────────────────────────

    def save_record(self, table: str, patient_id: Optional[int], input_data: Dict, result_data: Dict) -> int:
        """Save a clinical record (screening, radiology, treatment, billing)."""
        valid_tables = {"screening_records", "radiology_records", "treatment_records", "billing_records"}
        if table not in valid_tables:
            raise ValueError(f"Invalid table: {table}")

        conn = self._get_conn()
        cursor = conn.execute(
            f"INSERT INTO {table} (patient_id, input_data, result_data) VALUES (?, ?, ?)",
            (patient_id, json.dumps(input_data), json.dumps(result_data)),
        )
        conn.commit()
        return cursor.lastrowid  # type: ignore[return-value]

    # ── Compliance Logs ───────────────────────────────────────────

    def log_compliance(self, log_type: str, check_id: str = "", details: Dict[str, Any] | None = None, logged_by: str = "") -> int:
        """Log a compliance event."""
        conn = self._get_conn()
        cursor = conn.execute(
            "INSERT INTO compliance_logs (log_type, check_id, details, logged_by) VALUES (?, ?, ?, ?)",
            (log_type, check_id, json.dumps(details or {}), logged_by),
        )
        conn.commit()
        return cursor.lastrowid  # type: ignore[return-value]

    def get_compliance_logs(self, log_type: Optional[str] = None, limit: int = 50) -> List[Dict[str, Any]]:
        """Get compliance logs, optionally filtered by type."""
        conn = self._get_conn()
        if log_type:
            rows = conn.execute(
                "SELECT * FROM compliance_logs WHERE log_type = ? ORDER BY created_at DESC LIMIT ?",
                (log_type, limit),
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM compliance_logs ORDER BY created_at DESC LIMIT ?",
                (limit,),
            ).fetchall()
        result = []
        for r in rows:
            d = dict(r)
            d["details"] = json.loads(d["details"])
            result.append(d)
        return result

    # ── Onboarding Operations ────────────────────────────────────

    def get_onboarding_status(self) -> Dict[str, Any]:
        """Get or create the onboarding status record."""
        conn = self._get_conn()
        row = conn.execute("SELECT * FROM onboarding_status WHERE id = 1").fetchone()
        if row is None:
            conn.execute(
                "INSERT INTO onboarding_status (id, step) VALUES (1, 1)"
            )
            conn.commit()
            row = conn.execute("SELECT * FROM onboarding_status WHERE id = 1").fetchone()
        return dict(row)

    def update_onboarding_step(self, step: int, field: str) -> None:
        """Mark an onboarding step as complete and advance."""
        conn = self._get_conn()
        valid_fields = {
            "practice_complete", "regulatory_complete", "clinical_complete",
            "team_complete", "golive_complete",
        }
        if field not in valid_fields:
            raise ValueError(f"Invalid onboarding field: {field}")
        # Ensure status row exists
        self.get_onboarding_status()
        completed_at = ""
        if field == "golive_complete":
            completed_at = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
        conn.execute(
            f"UPDATE onboarding_status SET {field} = 1, step = ?"
            + (", completed_at = ?" if field == "golive_complete" else "")
            + " WHERE id = 1",
            (step + 1, completed_at) if field == "golive_complete" else (step + 1,),
        )
        conn.commit()

    def save_practice_profile(self, data: Dict[str, Any]) -> int:
        """Save or update the practice profile (singleton, id=1)."""
        conn = self._get_conn()
        existing = conn.execute("SELECT id FROM practice_profile WHERE id = 1").fetchone()
        if existing:
            conn.execute(
                """UPDATE practice_profile SET name=?, address=?, phone=?, email=?,
                   practice_type=?, country=?, num_surgeries=?, num_dentists=?,
                   num_hygienists=?, num_nurses=?, primary_software=?,
                   nhs_contract_number=?, cqc_registration=?, dspt_status=?,
                   caldicott_guardian=? WHERE id = 1""",
                (
                    data.get("name", ""), data.get("address", ""),
                    data.get("phone", ""), data.get("email", ""),
                    data.get("practice_type", ""), data.get("country", ""),
                    data.get("num_surgeries", 0), data.get("num_dentists", 0),
                    data.get("num_hygienists", 0), data.get("num_nurses", 0),
                    data.get("primary_software", ""),
                    data.get("nhs_contract_number", ""),
                    data.get("cqc_registration", ""),
                    data.get("dspt_status", ""),
                    data.get("caldicott_guardian", ""),
                ),
            )
        else:
            conn.execute(
                """INSERT INTO practice_profile (id, name, address, phone, email,
                   practice_type, country, num_surgeries, num_dentists,
                   num_hygienists, num_nurses, primary_software,
                   nhs_contract_number, cqc_registration, dspt_status,
                   caldicott_guardian) VALUES (1,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    data.get("name", ""), data.get("address", ""),
                    data.get("phone", ""), data.get("email", ""),
                    data.get("practice_type", ""), data.get("country", ""),
                    data.get("num_surgeries", 0), data.get("num_dentists", 0),
                    data.get("num_hygienists", 0), data.get("num_nurses", 0),
                    data.get("primary_software", ""),
                    data.get("nhs_contract_number", ""),
                    data.get("cqc_registration", ""),
                    data.get("dspt_status", ""),
                    data.get("caldicott_guardian", ""),
                ),
            )
        conn.commit()
        return 1

    def get_practice_profile(self) -> Optional[Dict[str, Any]]:
        """Get the practice profile."""
        conn = self._get_conn()
        row = conn.execute("SELECT * FROM practice_profile WHERE id = 1").fetchone()
        if row is None:
            return None
        return dict(row)

    def save_regulatory_data(self, data: Dict[str, Any]) -> None:
        """Save regulatory profile data as JSON in practice_profile."""
        conn = self._get_conn()
        existing = conn.execute("SELECT id FROM practice_profile WHERE id = 1").fetchone()
        if existing:
            conn.execute(
                "UPDATE practice_profile SET regulatory_data = ? WHERE id = 1",
                (json.dumps(data),),
            )
        else:
            conn.execute(
                "INSERT INTO practice_profile (id, regulatory_data) VALUES (1, ?)",
                (json.dumps(data),),
            )
        conn.commit()

    def save_clinical_config(self, data: Dict[str, Any]) -> None:
        """Save clinical configuration as JSON in practice_profile."""
        conn = self._get_conn()
        existing = conn.execute("SELECT id FROM practice_profile WHERE id = 1").fetchone()
        if existing:
            conn.execute(
                "UPDATE practice_profile SET clinical_config = ? WHERE id = 1",
                (json.dumps(data),),
            )
        else:
            conn.execute(
                "INSERT INTO practice_profile (id, clinical_config) VALUES (1, ?)",
                (json.dumps(data),),
            )
        conn.commit()

    def add_team_member(self, data: Dict[str, Any]) -> int:
        """Add a team member. Returns the new member's ID."""
        conn = self._get_conn()
        cursor = conn.execute(
            """INSERT INTO team_members (name, role, license_number, gdc_number,
               npi_number, dea_number, access_level, start_date)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                data.get("name", ""), data.get("role", ""),
                data.get("license_number", ""), data.get("gdc_number", ""),
                data.get("npi_number", ""), data.get("dea_number", ""),
                data.get("access_level", "admin"), data.get("start_date", ""),
            ),
        )
        conn.commit()
        return cursor.lastrowid  # type: ignore[return-value]

    def list_team_members(self) -> List[Dict[str, Any]]:
        """List all active team members."""
        conn = self._get_conn()
        rows = conn.execute(
            "SELECT * FROM team_members WHERE active = 1 ORDER BY name"
        ).fetchall()
        return [dict(r) for r in rows]

    def remove_team_member(self, member_id: int) -> None:
        """Soft-delete a team member."""
        conn = self._get_conn()
        conn.execute("UPDATE team_members SET active = 0 WHERE id = ?", (member_id,))
        conn.commit()

    # ── Ledger / Financial Operations ────────────────────────────

    def add_ledger_entry(self, data: Dict[str, Any]) -> int:
        """Add an income or expense entry to the ledger."""
        conn = self._get_conn()
        cursor = conn.execute(
            """INSERT INTO ledger (date, type, category, subcategory, description,
               amount, vat_rate, vat_amount, payment_method, reference,
               patient_id, invoice_id, tax_period)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                data.get("date", ""),
                data.get("type", ""),
                data.get("category", ""),
                data.get("subcategory", ""),
                data.get("description", ""),
                float(data.get("amount", 0)),
                float(data.get("vat_rate", 0)),
                float(data.get("vat_amount", 0)),
                data.get("payment_method", ""),
                data.get("reference", ""),
                data.get("patient_id"),
                data.get("invoice_id", ""),
                data.get("tax_period", ""),
            ),
        )
        conn.commit()
        return cursor.lastrowid  # type: ignore[return-value]

    def get_ledger_entries(
        self,
        entry_type: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        category: Optional[str] = None,
        limit: int = 500,
    ) -> List[Dict[str, Any]]:
        """Get ledger entries with optional filters."""
        conn = self._get_conn()
        conditions = []
        params: list = []

        if entry_type:
            conditions.append("type = ?")
            params.append(entry_type)
        if start_date:
            conditions.append("date >= ?")
            params.append(start_date)
        if end_date:
            conditions.append("date <= ?")
            params.append(end_date)
        if category:
            conditions.append("category = ?")
            params.append(category)

        where = " WHERE " + " AND ".join(conditions) if conditions else ""
        params.append(limit)
        rows = conn.execute(
            f"SELECT * FROM ledger{where} ORDER BY date DESC, created_at DESC LIMIT ?",
            params,
        ).fetchall()
        return [dict(r) for r in rows]

    # ── Invoice Operations ────────────────────────────────────────

    def save_invoice(self, data: Dict[str, Any]) -> str:
        """Save an invoice. Returns invoice ID."""
        conn = self._get_conn()
        conn.execute(
            """INSERT OR REPLACE INTO invoices (id, patient_id, patient_name, date, type,
               items, subtotal, vat, total, nhs_band, status, paid_date,
               payment_method, notes)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                data.get("id", ""),
                data.get("patient_id"),
                data.get("patient_name", ""),
                data.get("date", ""),
                data.get("type", ""),
                data.get("items", "[]"),
                float(data.get("subtotal", 0)),
                float(data.get("vat", 0)),
                float(data.get("total", 0)),
                data.get("nhs_band", ""),
                data.get("status", "pending"),
                data.get("paid_date", ""),
                data.get("payment_method", ""),
                data.get("notes", ""),
            ),
        )
        conn.commit()
        return data.get("id", "")

    def get_invoice(self, invoice_id: str) -> Optional[Dict[str, Any]]:
        """Get an invoice by ID."""
        conn = self._get_conn()
        row = conn.execute("SELECT * FROM invoices WHERE id = ?", (invoice_id,)).fetchone()
        if row is None:
            return None
        d = dict(row)
        d["items"] = json.loads(d["items"])
        return d

    def list_invoices(
        self,
        status: Optional[str] = None,
        invoice_type: Optional[str] = None,
        limit: int = 100,
    ) -> List[Dict[str, Any]]:
        """List invoices with optional filters."""
        conn = self._get_conn()
        conditions = []
        params: list = []

        if status:
            conditions.append("status = ?")
            params.append(status)
        if invoice_type:
            conditions.append("type = ?")
            params.append(invoice_type)

        where = " WHERE " + " AND ".join(conditions) if conditions else ""
        params.append(limit)
        rows = conn.execute(
            f"SELECT * FROM invoices{where} ORDER BY date DESC, created_at DESC LIMIT ?",
            params,
        ).fetchall()
        result = []
        for r in rows:
            d = dict(r)
            d["items"] = json.loads(d["items"])
            result.append(d)
        return result

    def update_invoice_status(self, invoice_id: str, status: str, paid_date: str = "", payment_method: str = "") -> None:
        """Update invoice status (e.g., mark as paid)."""
        conn = self._get_conn()
        conn.execute(
            "UPDATE invoices SET status = ?, paid_date = ?, payment_method = ? WHERE id = ?",
            (status, paid_date, payment_method, invoice_id),
        )
        conn.commit()

    # ── Marketing Content Operations ──────────────────────────────

    def save_marketing_content(self, data: Dict[str, Any]) -> int:
        """Save a marketing content item. Returns content ID."""
        conn = self._get_conn()
        cursor = conn.execute(
            """INSERT INTO marketing_content (type, platform, title, content, status,
               scheduled_date, campaign)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (
                data.get("type", ""),
                data.get("platform", ""),
                data.get("title", ""),
                data.get("content", ""),
                data.get("status", "draft"),
                data.get("scheduled_date", ""),
                data.get("campaign", ""),
            ),
        )
        conn.commit()
        return cursor.lastrowid  # type: ignore[return-value]

    def list_marketing_content(
        self,
        content_type: Optional[str] = None,
        status: Optional[str] = None,
        limit: int = 50,
    ) -> List[Dict[str, Any]]:
        """List marketing content with optional filters."""
        conn = self._get_conn()
        conditions = []
        params: list = []

        if content_type:
            conditions.append("type = ?")
            params.append(content_type)
        if status:
            conditions.append("status = ?")
            params.append(status)

        where = " WHERE " + " AND ".join(conditions) if conditions else ""
        params.append(limit)
        rows = conn.execute(
            f"SELECT * FROM marketing_content{where} ORDER BY scheduled_date DESC, created_at DESC LIMIT ?",
            params,
        ).fetchall()
        return [dict(r) for r in rows]

    def update_marketing_status(self, content_id: int, status: str) -> None:
        """Update marketing content status."""
        conn = self._get_conn()
        conn.execute(
            "UPDATE marketing_content SET status = ? WHERE id = ?",
            (status, content_id),
        )
        conn.commit()

    # ── Migration Status Operations ───────────────────────────────

    def get_migration_status(self) -> Dict[str, Any]:
        """Get or create the migration status record."""
        conn = self._get_conn()
        row = conn.execute("SELECT * FROM migration_status WHERE id = 1").fetchone()
        if row is None:
            conn.execute(
                "INSERT INTO migration_status (id) VALUES (1)"
            )
            conn.commit()
            row = conn.execute("SELECT * FROM migration_status WHERE id = 1").fetchone()
        d = dict(row)
        d["issues"] = json.loads(d["issues"])
        return d

    def update_migration_status(self, data: Dict[str, Any]) -> None:
        """Update migration status fields."""
        conn = self._get_conn()
        self.get_migration_status()  # ensure row exists
        fields = []
        params = []
        allowed = {
            "source_system", "status", "step", "patients_exported",
            "patients_imported", "records_verified", "issues",
            "started_at", "completed_at",
        }
        for key, val in data.items():
            if key in allowed:
                fields.append(f"{key} = ?")
                params.append(json.dumps(val) if key == "issues" else val)
        if fields:
            params.append(1)
            conn.execute(
                f"UPDATE migration_status SET {', '.join(fields)} WHERE id = ?",
                params,
            )
            conn.commit()

    # ── License Operations ────────────────────────────────────────

    def get_license(self) -> Dict[str, Any]:
        """Get or create the license record."""
        conn = self._get_conn()
        row = conn.execute("SELECT * FROM license WHERE id = 1").fetchone()
        if row is None:
            conn.execute(
                "INSERT INTO license (id, tier, max_dentists, max_patients_month, features) "
                "VALUES (1, 'free', 1, 50, '[]')"
            )
            conn.commit()
            row = conn.execute("SELECT * FROM license WHERE id = 1").fetchone()
        d = dict(row)
        d["features"] = json.loads(d["features"])
        return d

    def update_license(self, data: Dict[str, Any]) -> None:
        """Update license fields."""
        conn = self._get_conn()
        self.get_license()  # ensure row exists
        fields = []
        params = []
        allowed = {
            "tier", "license_key", "practice_id", "activated_at",
            "expires_at", "max_dentists", "max_patients_month", "features",
        }
        for key, val in data.items():
            if key in allowed:
                fields.append(f"{key} = ?")
                params.append(json.dumps(val) if key == "features" else val)
        if fields:
            params.append(1)
            conn.execute(
                f"UPDATE license SET {', '.join(fields)} WHERE id = ?",
                params,
            )
            conn.commit()

    def close(self) -> None:
        """Close the database connection."""
        if self._conn:
            self._conn.close()
            self._conn = None
