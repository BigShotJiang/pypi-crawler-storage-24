"""DentalAI Pro — Enterprise Clinical Dental AI Platform."""

__version__ = "0.1.0"
