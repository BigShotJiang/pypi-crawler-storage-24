"""Data migration wizard for DentalAI Pro.

Guides dental practices through migrating data from existing practice
management software (SOE, R4, Dentrix, Eaglesoft, Open Dental, etc.).
"""

from __future__ import annotations

import csv
import io
import json
import time
from datetime import datetime
from typing import Any, Dict, List, Optional


# ── Source System Definitions ──────────────────────────────────
SOURCE_SYSTEMS = {
    "soe": {
        "name": "SOE (Software of Excellence)",
        "market": "UK",
        "description": "UK market leader for dental practice management. Used by NHS and private practices.",
        "export_steps": [
            "Go to Administration > Data Management > Export Data",
            "Select the data categories you wish to export (Patients, Treatment History, Financial)",
            "Choose CSV format for maximum compatibility",
            "Select the date range for treatment history (recommend: all available data)",
            "Click 'Export' and save to a secure location",
            "IMPORTANT: X-ray images must be exported separately via DICOM export",
        ],
        "exportable": [
            "Patient demographics (name, DOB, address, contact details)",
            "Treatment history and clinical notes",
            "NHS FP17 forms and UDA records",
            "Financial transactions and invoices",
            "Appointment history",
            "Recall dates",
        ],
        "not_exportable": [
            "Digital X-rays (must use DICOM export separately)",
            "Custom letter templates",
            "System preferences and configurations",
            "Audit trail logs",
        ],
        "estimated_time": "2-4 hours for a practice with 5,000+ patients",
        "tips": [
            "Run the export outside of clinical hours to avoid performance impact",
            "Ensure you have at least 2GB free disk space for the export",
            "Take a full backup of SOE before starting the export",
            "Contact SOE support if you need DICOM export assistance",
        ],
    },
    "exact": {
        "name": "Exact / Evident (Henry Schein)",
        "market": "UK/EU",
        "description": "Widely used across UK and European dental practices. Part of the Henry Schein One family.",
        "export_steps": [
            "Navigate to Setup > Utilities > Export Data",
            "Select 'Full Database Export' for comprehensive migration",
            "Choose CSV or XML format",
            "Tick all data categories: Patients, Treatments, Financials, Appointments",
            "Set date range for historical data",
            "Run export (may take 30-60 minutes for large databases)",
        ],
        "exportable": [
            "Patient records and demographics",
            "Treatment plans and completed treatments",
            "Financial ledger and payment history",
            "Appointment schedules",
            "Recall system data",
            "Medical history questionnaires",
        ],
        "not_exportable": [
            "X-ray images (separate DICOM export required)",
            "Custom report templates",
            "User permissions and roles",
            "Scanned documents (need separate file copy)",
        ],
        "estimated_time": "1-3 hours for most practices",
        "tips": [
            "Ask Henry Schein support for their official migration pack",
            "Export images via the built-in DICOM viewer",
            "Verify the export file is not corrupted before proceeding",
        ],
    },
    "r4": {
        "name": "R4 (Carestream/Trophy)",
        "market": "UK",
        "description": "Long-established UK dental software. Still used by many NHS practices.",
        "export_steps": [
            "From main menu, go to Utilities > Export/Import > Data Export",
            "Select 'Patient Data Export' for a full extract",
            "Choose comma-separated (CSV) format",
            "Select all patient records or filter by date range",
            "Financial data: go to Accounts > Reports > Export Transactions",
            "Save both exports to a secure USB drive or network location",
        ],
        "exportable": [
            "Patient demographics",
            "Basic treatment history",
            "NHS claim data",
            "Financial transactions",
            "Appointment book",
        ],
        "not_exportable": [
            "Detailed clinical notes (may be truncated)",
            "Digital radiographs (use Carestream imaging export)",
            "Intraoral camera images",
            "Custom forms and templates",
        ],
        "estimated_time": "2-3 hours",
        "tips": [
            "R4 uses a proprietary database - you may need Carestream assistance",
            "Clinical notes may need manual review after import",
            "Consider running a parallel period of 2-4 weeks",
        ],
    },
    "dentrix": {
        "name": "Dentrix (Henry Schein)",
        "market": "US",
        "description": "The US market leader for dental practice management software.",
        "export_steps": [
            "Go to Office Manager > Maintenance > Practice Setup > Export",
            "Use the 'eServices Export' tool or 'Database Export'",
            "Select data types: Patients, Ledger, Treatment Plans, Clinical Notes",
            "Choose CSV or standard format",
            "For insurance data, export via Reports > Insurance Manager > Export",
            "X-rays: Use Dentrix Image export or DEXIS bridge",
        ],
        "exportable": [
            "Patient demographics and insurance information",
            "Treatment history with CDT codes",
            "Ledger/financial transactions",
            "Treatment plans (pending and completed)",
            "Appointment history",
            "Perio charting data",
            "Referral information",
        ],
        "not_exportable": [
            "Custom letter/form templates",
            "User-defined fields (varies)",
            "eServices configurations",
            "Some third-party integration data",
        ],
        "estimated_time": "2-4 hours for standard practice",
        "tips": [
            "Contact Dentrix support for their official conversion utility",
            "Back up the entire Dentrix database before exporting",
            "CDT codes translate directly - no mapping needed",
            "Insurance fee schedules may need manual setup",
        ],
    },
    "eaglesoft": {
        "name": "Eaglesoft (Patterson)",
        "market": "US",
        "description": "Popular US dental practice management software by Patterson Dental.",
        "export_steps": [
            "Open Eaglesoft and go to Reports > Custom Reports",
            "Select 'Patient Export' report and configure for all patients",
            "For financial data, run 'Transaction Export' from the Accounts module",
            "Export to CSV format",
            "Clinical notes: use 'Smart Doc' export if available",
            "Images: export via the Eaglesoft imaging module",
        ],
        "exportable": [
            "Patient demographics",
            "Treatment history",
            "Financial transactions and insurance claims",
            "Appointment schedule",
            "Basic clinical notes",
        ],
        "not_exportable": [
            "Smart Doc templates",
            "Custom workflows",
            "Some third-party plugin data",
            "X-ray annotations",
        ],
        "estimated_time": "2-3 hours",
        "tips": [
            "Patterson offers a conversion service - contact your rep",
            "Eaglesoft uses ADA procedure codes which map directly to CDT",
            "Export during off-hours to avoid slowing the system",
        ],
    },
    "opendental": {
        "name": "Open Dental",
        "market": "US/Global",
        "description": "Open-source dental software used worldwide. Excellent data portability.",
        "export_steps": [
            "Go to Setup > Advanced Setup > Database Maintenance",
            "Use 'Export Database' option for a full MySQL dump",
            "Alternatively, use Reports > Standard > Patient Export for CSV",
            "Financial data: Reports > Standard > Ledger Export",
            "Open Dental also supports direct MySQL queries for custom exports",
            "Images: copy the OpenDent Images folder (path in Setup > Data Paths)",
        ],
        "exportable": [
            "Complete patient records",
            "Full treatment history with ADA codes",
            "Complete financial ledger",
            "Insurance information",
            "Appointment schedules",
            "Clinical notes",
            "Perio data",
            "X-ray images (file-based)",
        ],
        "not_exportable": [
            "eServices configurations",
            "Custom user preferences",
            "Third-party bridge settings",
        ],
        "estimated_time": "1-2 hours (best data portability)",
        "tips": [
            "Open Dental has the best export capabilities of any dental software",
            "Direct MySQL access means you can export exactly what you need",
            "The Open Dental community forums have migration guides",
            "Images are stored as regular files - simply copy the folder",
        ],
    },
}


def get_migration_guide(system: str) -> Dict[str, Any]:
    """Get the migration guide for a specific source system.

    Args:
        system: Source system key (soe, exact, r4, dentrix, eaglesoft, opendental).

    Returns:
        Migration guide dictionary with steps, exportable data, and tips.
    """
    if system not in SOURCE_SYSTEMS:
        return {
            "error": f"Unknown system: {system}",
            "available_systems": list(SOURCE_SYSTEMS.keys()),
        }

    guide = SOURCE_SYSTEMS[system].copy()
    guide["system_key"] = system
    return guide


def get_all_systems() -> List[Dict[str, Any]]:
    """Get a summary of all supported source systems.

    Returns:
        List of system summaries with key, name, market, and description.
    """
    return [
        {
            "key": key,
            "name": info["name"],
            "market": info["market"],
            "description": info["description"],
            "estimated_time": info["estimated_time"],
        }
        for key, info in SOURCE_SYSTEMS.items()
    ]


def parse_patient_csv(csv_content: str) -> Dict[str, Any]:
    """Parse a CSV file of patient data for import.

    Expected columns (flexible matching):
    - name / patient_name / full_name
    - age / date_of_birth / dob
    - sex / gender
    - phone / telephone / mobile
    - email
    - address
    - medical_conditions / medical_history
    - medications

    Args:
        csv_content: Raw CSV content as string.

    Returns:
        Parsed data with patients list and validation results.
    """
    try:
        reader = csv.DictReader(io.StringIO(csv_content))
    except Exception as e:
        return {"error": f"Failed to parse CSV: {str(e)}", "patients": [], "valid": False}

    if not reader.fieldnames:
        return {"error": "CSV has no headers", "patients": [], "valid": False}

    # Normalise column names
    column_map = _build_column_map(reader.fieldnames)

    patients: List[Dict[str, Any]] = []
    issues: List[str] = []
    row_num = 0

    for row in reader:
        row_num += 1
        patient = _map_patient_row(row, column_map, row_num, issues)
        if patient:
            patients.append(patient)

    return {
        "patients": patients,
        "total_parsed": len(patients),
        "total_rows": row_num,
        "issues": issues,
        "columns_detected": list(reader.fieldnames),
        "columns_mapped": column_map,
        "valid": len(patients) > 0,
    }


def _build_column_map(fieldnames: List[str]) -> Dict[str, str]:
    """Build a mapping from standardised field names to CSV column names."""
    column_map: Dict[str, str] = {}
    normalised = {f.strip().lower().replace(" ", "_"): f for f in fieldnames}

    name_keys = ["name", "patient_name", "full_name", "patient", "surname"]
    for k in name_keys:
        if k in normalised:
            column_map["name"] = normalised[k]
            break

    age_keys = ["age", "date_of_birth", "dob", "birth_date", "birthdate"]
    for k in age_keys:
        if k in normalised:
            column_map["age"] = normalised[k]
            break

    sex_keys = ["sex", "gender", "male/female"]
    for k in sex_keys:
        if k in normalised:
            column_map["sex"] = normalised[k]
            break

    phone_keys = ["phone", "telephone", "mobile", "tel", "contact_number"]
    for k in phone_keys:
        if k in normalised:
            column_map["phone"] = normalised[k]
            break

    email_keys = ["email", "e-mail", "email_address"]
    for k in email_keys:
        if k in normalised:
            column_map["email"] = normalised[k]
            break

    address_keys = ["address", "full_address", "postal_address"]
    for k in address_keys:
        if k in normalised:
            column_map["address"] = normalised[k]
            break

    medical_keys = ["medical_conditions", "medical_history", "conditions", "medical"]
    for k in medical_keys:
        if k in normalised:
            column_map["medical_conditions"] = normalised[k]
            break

    med_keys = ["medications", "current_medications", "drugs", "prescriptions"]
    for k in med_keys:
        if k in normalised:
            column_map["medications"] = normalised[k]
            break

    return column_map


def _map_patient_row(
    row: Dict[str, str],
    column_map: Dict[str, str],
    row_num: int,
    issues: List[str],
) -> Optional[Dict[str, Any]]:
    """Map a CSV row to a patient record."""
    name = row.get(column_map.get("name", ""), "").strip()
    if not name:
        issues.append(f"Row {row_num}: Missing patient name - skipped")
        return None

    age_raw = row.get(column_map.get("age", ""), "").strip()
    age = 0
    if age_raw:
        try:
            age = int(age_raw)
        except ValueError:
            # Might be a date of birth
            try:
                for fmt in ("%d/%m/%Y", "%m/%d/%Y", "%Y-%m-%d", "%d-%m-%Y"):
                    try:
                        dob = datetime.strptime(age_raw, fmt)
                        age = (datetime.now() - dob).days // 365
                        break
                    except ValueError:
                        continue
            except Exception:
                issues.append(f"Row {row_num}: Could not parse age/DOB '{age_raw}'")

    sex = row.get(column_map.get("sex", ""), "").strip().upper()
    if sex and sex not in ("M", "F"):
        if sex in ("MALE", "MAN", "BOY"):
            sex = "M"
        elif sex in ("FEMALE", "WOMAN", "GIRL"):
            sex = "F"
        else:
            sex = ""

    medical = row.get(column_map.get("medical_conditions", ""), "").strip()
    medical_list = [m.strip() for m in medical.split(",") if m.strip()] if medical else []

    medications = row.get(column_map.get("medications", ""), "").strip()
    med_list = [m.strip() for m in medications.split(",") if m.strip()] if medications else []

    return {
        "name": name,
        "age": age,
        "sex": sex,
        "medical_conditions": medical_list,
        "medications": med_list,
    }


def verify_migration(
    source_count: int,
    imported_count: int,
    sample_patients: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    """Run verification checks on migrated data.

    Args:
        source_count: Number of records in the source system.
        imported_count: Number of records successfully imported.
        sample_patients: Optional list of sample patients to verify.

    Returns:
        Verification results with pass/fail status.
    """
    checks: List[Dict[str, Any]] = []

    # Record count check
    count_match = imported_count >= source_count * 0.95  # Allow 5% tolerance
    pct = round((imported_count / source_count * 100), 1) if source_count > 0 else 0
    checks.append({
        "check": "Record Count",
        "status": "pass" if count_match else "fail",
        "detail": f"{imported_count}/{source_count} records imported ({pct}%)",
        "source_count": source_count,
        "imported_count": imported_count,
    })

    # Missing records
    missing = source_count - imported_count
    if missing > 0:
        checks.append({
            "check": "Missing Records",
            "status": "warning",
            "detail": f"{missing} records not imported. Review export file for errors.",
        })

    # Sample verification
    if sample_patients:
        valid_samples = 0
        for patient in sample_patients:
            has_name = bool(patient.get("name", "").strip())
            has_age = patient.get("age", 0) > 0
            if has_name:
                valid_samples += 1
        sample_pct = round((valid_samples / len(sample_patients) * 100), 1) if sample_patients else 0
        checks.append({
            "check": "Sample Verification",
            "status": "pass" if sample_pct >= 90 else "warning",
            "detail": f"{valid_samples}/{len(sample_patients)} sample patients verified ({sample_pct}%)",
        })

    # Data integrity
    checks.append({
        "check": "Data Integrity",
        "status": "pass" if count_match else "warning",
        "detail": "Automated integrity check complete. Manual spot-check recommended.",
    })

    has_failures = any(c["status"] == "fail" for c in checks)
    return {
        "overall_status": "needs_review" if has_failures else "pass",
        "checks": checks,
        "recommendations": [
            "Verify 5-10 patient records manually by comparing with source system",
            "Check financial totals match between old and new system",
            "Confirm appointment schedules transferred correctly",
            "Run a parallel period of 1-2 weeks before fully switching",
        ],
    }
