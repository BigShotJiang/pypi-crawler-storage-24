"""Radiology analysis engine — structured reports, missed finding checks."""

from __future__ import annotations

from typing import Any, Dict, List

from ..knowledge.radiographic import RADIOGRAPHIC_FINDINGS, get_commonly_missed


def _match_findings(text: str, quick_findings: List[str]) -> List[Dict[str, Any]]:
    """Match user-described findings against the knowledge base."""
    combined = text.lower()
    for qf in quick_findings:
        combined += " " + qf.lower()

    matched: List[Dict[str, Any]] = []
    for finding in RADIOGRAPHIC_FINDINGS:
        name_lower = finding["name"].lower()
        # Check for keyword matches
        keywords = name_lower.split()
        match_count = sum(1 for kw in keywords if kw in combined and len(kw) > 3)
        if match_count >= 1 or any(kw in combined for kw in _get_aliases(finding)):
            matched.append(finding)

    return matched


def _get_aliases(finding: Dict[str, Any]) -> List[str]:
    """Generate common aliases/synonyms for a finding."""
    aliases_map: Dict[str, List[str]] = {
        "caries": ["cavity", "decay", "carious"],
        "bone loss": ["bone resorption", "alveolar loss"],
        "periapical radiolucency": ["pa radiolucency", "periapical lesion", "parl"],
        "widened pdl": ["widened pdl space", "thickened pdl"],
        "calculus": ["tartar", "calcified deposit"],
        "root resorption": ["resorption", "root shortening"],
        "fracture": ["crack", "broken", "fx"],
        "impacted": ["unerupted", "embedded"],
        "radiolucent": ["dark area", "dark spot"],
        "radiopaque": ["white area", "bright spot"],
    }
    name_lower = finding["name"].lower()
    all_aliases: List[str] = []
    for key, aliases in aliases_map.items():
        if key in name_lower:
            all_aliases.extend(aliases)
    return all_aliases


def generate_report(data: Dict[str, Any]) -> Dict[str, Any]:
    """Generate a structured radiology report.

    Args:
        data: Dict with study_type, tooth_region, findings, quick_findings.

    Returns:
        Structured report with findings, differentials, recommendations.
    """
    study_type = data.get("study_type", "periapical")
    tooth_region = data.get("tooth_region", "")
    findings_text = data.get("findings", "")
    quick_findings = data.get("quick_findings", [])

    matched = _match_findings(findings_text, quick_findings)

    # Build structured findings
    structured_findings: List[Dict[str, Any]] = []
    for f in matched:
        structured_findings.append({
            "name": f["name"],
            "appearance": f["appearance"],
            "significance": f["significance"],
            "differential": f["differential"],
            "next_steps": f["next_steps"],
        })

    # Check for missed findings based on study type
    missed_alerts = _check_missed_findings(study_type, tooth_region, findings_text, quick_findings, matched)

    # Additional imaging recommendations
    additional_imaging = _recommend_imaging(study_type, matched)

    report = {
        "study_type": study_type,
        "tooth_region": tooth_region,
        "report": {
            "header": f"Radiographic Interpretation — {study_type.upper()}",
            "clinical_indication": f"Evaluation of {tooth_region}" if tooth_region else "Routine evaluation",
            "findings": structured_findings if structured_findings else [{"name": "No significant pathology identified", "significance": "Within normal limits", "differential": [], "next_steps": ["Continue routine monitoring"]}],
            "impression": _generate_impression(structured_findings),
        },
        "missed_finding_alerts": missed_alerts,
        "additional_imaging": additional_imaging,
        "disclaimer": "Clinical decision support only. Does not replace professional judgment. Correlate with clinical findings.",
    }

    return report


def _check_missed_findings(
    study_type: str,
    tooth_region: str,
    findings_text: str,
    quick_findings: List[str],
    already_found: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """Check for commonly missed findings based on study type."""
    alerts: List[Dict[str, Any]] = []
    commonly_missed = get_commonly_missed()
    found_names = {f["name"].lower() for f in already_found}
    combined_text = (findings_text + " " + " ".join(quick_findings)).lower()

    # Study-specific reminders
    if study_type in ("bitewing", "FMX"):
        reminder_keywords = [
            ("incipient enamel caries", "Check for early interproximal caries in enamel"),
            ("recurrent/secondary caries", "Check margins of all existing restorations"),
            ("calculus", "Look for subgingival calculus deposits"),
            ("horizontal bone loss", "Evaluate crestal bone levels"),
            ("overhanging restoration", "Check restoration margins for overhangs"),
        ]
    elif study_type == "periapical":
        reminder_keywords = [
            ("periapical radiolucency", "Check apex for radiolucency"),
            ("widened pdl space", "Evaluate PDL space uniformity"),
            ("root resorption", "Check root contours for resorption"),
            ("condensing osteitis", "Look for periapical radiopacity"),
            ("root fracture", "Assess root integrity if trauma history"),
        ]
    elif study_type == "panoramic":
        reminder_keywords = [
            ("condylar erosion", "Evaluate both condyles for symmetry and surface irregularity"),
            ("carotid artery calcification", "Check C3-C4 region for carotid calcifications"),
            ("maxillary sinus", "Evaluate both maxillary sinuses for opacification"),
            ("impacted", "Check for unerupted/impacted teeth"),
            ("elongated styloid", "Assess styloid process length bilaterally"),
        ]
    elif study_type == "CBCT":
        reminder_keywords = [
            ("oroantral communication", "Evaluate sinus floor integrity near extraction sites"),
            ("root proximity", "Check for root proximity to vital structures"),
        ]
    else:
        reminder_keywords = []

    for keyword, reminder in reminder_keywords:
        already_mentioned = any(keyword.lower() in name for name in found_names)
        mentioned_in_text = keyword.lower() in combined_text
        if not already_mentioned and not mentioned_in_text:
            severity = "warning"
            # Elevate severity for dangerous misses
            if any(kw in keyword for kw in ["carotid", "condylar", "resorption", "fracture"]):
                severity = "danger"
            alerts.append({
                "alert": reminder,
                "severity": severity,
                "finding_name": keyword,
            })

    return alerts


def _recommend_imaging(study_type: str, findings: List[Dict[str, Any]]) -> List[Dict[str, str]]:
    """Recommend additional imaging if needed."""
    recommendations: List[Dict[str, str]] = []

    for f in findings:
        name_lower = f["name"].lower()
        if "ameloblastoma" in name_lower or "odontogenic keratocyst" in name_lower:
            recommendations.append({
                "study": "CBCT",
                "reason": f"3D evaluation of {f['name']} for extent and cortical involvement",
            })
        elif "fracture" in name_lower and study_type != "CBCT":
            recommendations.append({
                "study": "CBCT or additional periapical at different angle",
                "reason": "Better visualization of fracture line orientation",
            })
        elif "impacted" in name_lower and study_type == "panoramic":
            recommendations.append({
                "study": "CBCT",
                "reason": "Assess relationship to inferior alveolar nerve and adjacent roots",
            })

    if study_type == "bitewing" and any("bone loss" in f["name"].lower() for f in findings):
        recommendations.append({
            "study": "Full mouth series or panoramic",
            "reason": "Complete evaluation of bone levels",
        })

    return recommendations


def _generate_impression(findings: List[Dict[str, Any]]) -> str:
    """Generate a brief impression/summary."""
    if not findings:
        return "No significant radiographic findings identified."

    parts: List[str] = []
    for f in findings[:5]:
        parts.append(f["name"])

    return "Findings consistent with: " + "; ".join(parts) + ". Correlate clinically."


def check_findings(data: Dict[str, Any]) -> Dict[str, Any]:
    """Run a missed-finding check without full report generation."""
    study_type = data.get("study_type", "periapical")
    tooth_region = data.get("tooth_region", "")
    findings_text = data.get("findings", "")
    quick_findings = data.get("quick_findings", [])

    matched = _match_findings(findings_text, quick_findings)
    alerts = _check_missed_findings(study_type, tooth_region, findings_text, quick_findings, matched)

    return {
        "identified_findings": [f["name"] for f in matched],
        "missed_finding_alerts": alerts,
        "total_alerts": len(alerts),
        "disclaimer": "Automated check only. Does not replace systematic radiographic interpretation.",
    }
