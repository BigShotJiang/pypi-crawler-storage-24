"""Treatment planning engine — validation, contraindications, prognosis."""

from __future__ import annotations

from typing import Any, Dict, List

from ..knowledge.protocols import TREATMENT_PROTOCOLS
from ..knowledge.contraindications import CONTRAINDICATIONS


def validate_plan(data: Dict[str, Any]) -> Dict[str, Any]:
    """Validate a treatment plan for completeness and appropriateness.

    Args:
        data: Dict with diagnosis, planned_procedures, tooth_number,
              medical_conditions, medications.

    Returns:
        Validation result with flags, alternatives, consent items.
    """
    diagnosis = data.get("diagnosis", "").lower()
    category = data.get("diagnosis_category", "").lower()
    procedures = data.get("planned_procedures", [])
    tooth = data.get("tooth_number", "")
    conditions = [c.lower() for c in data.get("medical_conditions", [])]
    medications = [m.lower() for m in data.get("medications", [])]

    validations: List[Dict[str, Any]] = []
    flags: List[Dict[str, Any]] = []
    alternatives: List[Dict[str, Any]] = []
    consent_items: List[str] = []

    # Check procedure-diagnosis consistency
    for proc in procedures:
        proc_desc = (proc.get("description", "") + " " + proc.get("code", "")).lower()

        if "extraction" in proc_desc and "endo" in category:
            flags.append({
                "type": "consideration",
                "severity": "info",
                "message": f"Extraction planned for endodontic diagnosis. Consider root canal treatment if tooth is restorable.",
            })
            alternatives.append({
                "alternative": "Root canal treatment + crown",
                "evidence_level": "Strong — AAE Position Statement",
                "reason": "RCT success rate 92-98% for primary treatment",
            })

        if "crown" in proc_desc:
            validations.append({
                "check": "Crown indication",
                "status": "pass",
                "message": "Crown is appropriate for extensive loss of tooth structure, post-endo, or fracture.",
            })
            consent_items.append("Crown preparation involves irreversible removal of tooth structure")
            consent_items.append("Possible need for root canal if pulp is compromised")
            consent_items.append("Crown may fracture, debond, or require replacement (avg. lifespan 10-15 years)")

        if "implant" in proc_desc:
            consent_items.append("Surgical risks: infection, bleeding, nerve damage, sinus perforation")
            consent_items.append("Implant may fail to integrate (3-5% failure rate)")
            consent_items.append("Treatment timeline: 3-6 months for integration before final restoration")
            if any("bisphosphonate" in m or "alendronate" in m or "zoledronic" in m for m in medications):
                flags.append({
                    "type": "contraindication",
                    "severity": "critical",
                    "message": "Patient on bisphosphonates — MRONJ risk with implant surgery. Consult prescriber.",
                })

        if "rct" in proc_desc or "root canal" in proc_desc or "endo" in proc_desc:
            consent_items.append("Root canal treatment may not guarantee saving the tooth")
            consent_items.append("Post-treatment crown recommended to prevent fracture")
            consent_items.append("Alternative: extraction with implant/bridge replacement")

    # Check medical conditions against all procedures
    contra_results = check_contraindications(data)
    for c in contra_results.get("contraindications_found", []):
        flags.append({
            "type": "contraindication",
            "severity": c["severity"],
            "message": f"{c['condition_or_drug']}: {c['dental_concern']}",
            "action": c["what_to_do"],
        })

    # Find relevant protocols
    relevant_protocols: List[Dict[str, Any]] = []
    for protocol in TREATMENT_PROTOCOLS:
        scenario_lower = protocol["scenario"].lower()
        if (diagnosis and any(kw in scenario_lower for kw in diagnosis.split())) or \
           (category and category in scenario_lower):
            relevant_protocols.append({
                "scenario": protocol["scenario"],
                "guideline_source": protocol["guideline_source"],
                "success_rates": protocol["success_rates"],
            })

    # Standard consent items
    consent_items.extend([
        "I understand the risks, benefits, and alternatives of the proposed treatment",
        "I understand that no guarantees have been made regarding the outcome",
        "I have had the opportunity to ask questions",
    ])

    has_critical = any(f["severity"] == "critical" for f in flags)
    has_warnings = any(f["severity"] in ("high", "moderate") for f in flags)

    overall_status = "critical" if has_critical else "warning" if has_warnings else "pass"

    return {
        "overall_status": overall_status,
        "validations": validations,
        "flags": flags,
        "alternatives": alternatives,
        "relevant_protocols": relevant_protocols[:3],
        "informed_consent_items": list(dict.fromkeys(consent_items)),  # deduplicate preserving order
        "disclaimer": "Clinical decision support only. Treatment decisions must be made by the treating clinician.",
    }


def check_contraindications(data: Dict[str, Any]) -> Dict[str, Any]:
    """Check for contraindications based on medical conditions and medications.

    Args:
        data: Dict with medical_conditions and medications lists.

    Returns:
        Dict with found contraindications and severity summary.
    """
    conditions = [c.lower() for c in data.get("medical_conditions", [])]
    medications = [m.lower() for m in data.get("medications", [])]

    found: List[Dict[str, Any]] = []

    for contra in CONTRAINDICATIONS:
        contra_text = contra["condition_or_drug"].lower()

        # Check against patient conditions
        for cond in conditions:
            if cond in contra_text or contra_text in cond:
                found.append(contra)
                break
            # Partial keyword matching
            cond_words = cond.split()
            if any(w in contra_text for w in cond_words if len(w) > 3):
                found.append(contra)
                break
        else:
            # Check against medications
            for med in medications:
                if med in contra_text or contra_text in med:
                    found.append(contra)
                    break
                med_words = med.split()
                if any(w in contra_text for w in med_words if len(w) > 3):
                    found.append(contra)
                    break

    severity_counts = {"critical": 0, "high": 0, "moderate": 0, "low": 0}
    for f in found:
        sev = f.get("severity", "low")
        severity_counts[sev] = severity_counts.get(sev, 0) + 1

    return {
        "contraindications_found": found,
        "total": len(found),
        "severity_summary": severity_counts,
        "disclaimer": "Always verify with current drug references and patient-specific factors.",
    }


def estimate_prognosis(data: Dict[str, Any]) -> Dict[str, Any]:
    """Estimate treatment prognosis based on diagnosis and planned treatment.

    Args:
        data: Dict with diagnosis, diagnosis_category, planned_procedures,
              medical_conditions.

    Returns:
        Prognosis estimate with success rates and confidence level.
    """
    category = data.get("diagnosis_category", "").lower()
    procedures = data.get("planned_procedures", [])
    conditions = [c.lower() for c in data.get("medical_conditions", [])]

    base_success = 85  # Default baseline
    confidence = "moderate"
    factors: List[Dict[str, str]] = []

    for proc in procedures:
        desc = (proc.get("description", "") + " " + proc.get("code", "")).lower()

        if "root canal" in desc or "rct" in desc or "endo" in desc:
            base_success = 94
            confidence = "high"
            factors.append({"factor": "Root canal therapy", "impact": "94% success (primary treatment)"})

        elif "implant" in desc:
            base_success = 96
            confidence = "high"
            factors.append({"factor": "Implant placement", "impact": "95-97% success at 10 years"})

        elif "crown" in desc:
            base_success = 92
            confidence = "high"
            factors.append({"factor": "Crown restoration", "impact": "92-95% survival at 10 years"})

        elif "extraction" in desc:
            base_success = 98
            confidence = "high"
            factors.append({"factor": "Extraction", "impact": "98%+ success rate"})

        elif "srp" in desc or "scaling" in desc:
            base_success = 80
            confidence = "moderate"
            factors.append({"factor": "Scaling and root planing", "impact": "1-2mm pocket depth reduction expected"})

    # Modifiers based on medical conditions
    for cond in conditions:
        if "diabetes" in cond:
            if "uncontrolled" in cond or "poorly controlled" in cond:
                base_success -= 15
                factors.append({"factor": "Uncontrolled diabetes", "impact": "-15% healing/success"})
            else:
                base_success -= 5
                factors.append({"factor": "Diabetes (controlled)", "impact": "-5% success modifier"})

        if "smoking" in cond or "tobacco" in cond:
            base_success -= 10
            factors.append({"factor": "Tobacco use", "impact": "-10% success modifier (delayed healing)"})

        if "bisphosphonate" in cond:
            base_success -= 10
            factors.append({"factor": "Bisphosphonate therapy", "impact": "-10% (MRONJ risk)"})

        if "radiation" in cond or "irradiated" in cond:
            base_success -= 20
            factors.append({"factor": "Prior radiation", "impact": "-20% (ORN risk)"})

    base_success = max(20, min(99, base_success))

    return {
        "estimated_success_rate": base_success,
        "confidence": confidence,
        "modifying_factors": factors,
        "alternatives": _get_alternatives(category, procedures),
        "disclaimer": "Prognosis estimates based on population-level data. Individual outcomes vary.",
    }


def _get_alternatives(category: str, procedures: List[Dict[str, str]]) -> List[Dict[str, str]]:
    """Suggest alternative treatments."""
    alternatives: List[Dict[str, str]] = []

    for proc in procedures:
        desc = (proc.get("description", "") + " " + proc.get("code", "")).lower()

        if "rct" in desc or "root canal" in desc:
            alternatives.append({"treatment": "Extraction + implant", "evidence": "95-97% success at 10 years"})
            alternatives.append({"treatment": "Extraction + fixed bridge", "evidence": "89-94% success at 10 years"})

        if "extraction" in desc:
            alternatives.append({"treatment": "Root canal if tooth restorable", "evidence": "92-98% success"})

        if "crown" in desc:
            alternatives.append({"treatment": "Onlay (more conservative)", "evidence": "90-95% survival at 10 years"})

        if "implant" in desc:
            alternatives.append({"treatment": "Fixed bridge", "evidence": "89-94% at 10 years"})
            alternatives.append({"treatment": "Removable partial denture", "evidence": "Lower cost, 60-70% satisfaction"})

    return alternatives[:4]
