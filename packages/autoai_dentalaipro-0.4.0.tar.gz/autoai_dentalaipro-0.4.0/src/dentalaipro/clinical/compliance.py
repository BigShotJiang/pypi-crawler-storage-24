"""Compliance scanning engine — OSHA, HIPAA, radiation safety, state board."""

from __future__ import annotations

from typing import Any, Dict, List

from ..knowledge.compliance_checks import COMPLIANCE_CHECKS, get_checks_by_framework, get_critical_checks


def scan_compliance(data: Dict[str, Any]) -> Dict[str, Any]:
    """Run a compliance scan for the practice.

    Args:
        data: Dict with frameworks (list of frameworks to scan), state (optional).

    Returns:
        Compliance scan results with status per check.
    """
    frameworks = data.get("frameworks", ["OSHA", "HIPAA", "Radiation Safety", "State Board", "Quality Assurance"])
    logged_items = data.get("logged_items", {})

    results: Dict[str, List[Dict[str, Any]]] = {}
    total_checks = 0
    compliant_count = 0

    for fw in frameworks:
        checks = get_checks_by_framework(fw)
        fw_results: List[Dict[str, Any]] = []

        for check in checks:
            # Determine status based on logged items
            check_id = check["id"]
            is_logged = check_id in logged_items

            status = "compliant" if is_logged else "needs_review"
            total_checks += 1
            if is_logged:
                compliant_count += 1

            fw_results.append({
                "id": check["id"],
                "title": check["title"],
                "requirement": check["requirement"],
                "how_to_comply": check["how_to_comply"],
                "frequency": check["frequency"],
                "penalty_risk": check["penalty_risk"],
                "status": status,
            })

        results[fw] = fw_results

    compliance_score = int((compliant_count / total_checks * 100)) if total_checks > 0 else 0

    return {
        "frameworks_scanned": frameworks,
        "total_checks": total_checks,
        "compliant": compliant_count,
        "needs_review": total_checks - compliant_count,
        "compliance_score": compliance_score,
        "results": results,
        "critical_items": [
            {"id": c["id"], "title": c["title"], "framework": c["framework"]}
            for c in get_critical_checks()
            if c["id"] not in logged_items
        ],
        "disclaimer": "Compliance assessment tool only. Consult legal/compliance professional for definitive guidance.",
    }


def get_inspection_checklist(state: str = "") -> Dict[str, Any]:
    """Generate an inspection preparation checklist.

    Args:
        state: State abbreviation (for state-specific items).

    Returns:
        Categorized checklist for inspection preparation.
    """
    checklist: Dict[str, List[Dict[str, str]]] = {
        "Infection Control": [],
        "HIPAA / Privacy": [],
        "Radiation Safety": [],
        "Documentation": [],
        "Emergency Preparedness": [],
    }

    for check in COMPLIANCE_CHECKS:
        fw = check["framework"]
        item = {"id": check["id"], "title": check["title"], "how_to_comply": check["how_to_comply"]}

        if fw == "OSHA":
            if "steriliz" in check["title"].lower() or "infection" in check["title"].lower() or "ppe" in check["title"].lower():
                checklist["Infection Control"].append(item)
            elif "emergency" in check["title"].lower() or "fire" in check["title"].lower():
                checklist["Emergency Preparedness"].append(item)
            else:
                checklist["Documentation"].append(item)
        elif fw == "HIPAA":
            checklist["HIPAA / Privacy"].append(item)
        elif fw == "Radiation Safety":
            checklist["Radiation Safety"].append(item)
        elif fw == "Quality Assurance":
            if "emergency" in check["title"].lower():
                checklist["Emergency Preparedness"].append(item)
            else:
                checklist["Documentation"].append(item)
        else:
            checklist["Documentation"].append(item)

    return {
        "state": state or "General",
        "checklist": checklist,
        "total_items": sum(len(v) for v in checklist.values()),
        "note": "State-specific requirements may vary. Check with your state dental board for additional requirements.",
    }
