"""Oral pathology screening engine — lesion differential and cancer risk scoring."""

from __future__ import annotations

from typing import Any, Dict, List

from ..knowledge.lesions import ORAL_LESIONS


# Risk weights for cancer risk scoring
_LOCATION_RISK: Dict[str, float] = {
    "tongue lateral": 0.9, "floor of mouth": 0.95, "lip": 0.6,
    "palate soft": 0.7, "retromolar": 0.65, "tongue dorsal": 0.3,
    "buccal mucosa": 0.4, "palate hard": 0.5, "gingiva": 0.45,
    "vestibule": 0.25, "other": 0.3,
}

_DURATION_RISK: Dict[str, float] = {
    "<1 week": 0.05, "1-2 weeks": 0.15, "2-4 weeks": 0.35,
    "1-3 months": 0.55, "3-6 months": 0.75, ">6 months": 0.9,
}

_RISK_FACTOR_WEIGHTS: Dict[str, float] = {
    "tobacco": 0.25, "alcohol": 0.15, "betel nut": 0.2,
    "HPV+": 0.15, "sun exposure": 0.1, "immunosuppressed": 0.15,
    "prior cancer": 0.3,
}


def _score_match(lesion: Dict[str, Any], data: Dict[str, Any]) -> float:
    """Score how well a lesion matches the input data (0-1)."""
    score = 0.0
    total_weight = 0.0

    # Location match (weight 3)
    location = data.get("location", "")
    if location and location in lesion.get("locations", []):
        score += 3.0
    total_weight += 3.0

    # Color match (weight 2)
    colors = set(data.get("colors", []))
    lesion_colors = set(lesion.get("appearance", {}).get("colors", []))
    if colors and lesion_colors:
        overlap = len(colors & lesion_colors)
        if overlap > 0:
            score += 2.0 * (overlap / max(len(colors), 1))
    total_weight += 2.0

    # Texture match (weight 2)
    textures = set(data.get("textures", []))
    lesion_textures = set(lesion.get("appearance", {}).get("textures", []))
    if textures and lesion_textures:
        overlap = len(textures & lesion_textures)
        if overlap > 0:
            score += 2.0 * (overlap / max(len(textures), 1))
    total_weight += 2.0

    # Border match (weight 1.5)
    borders = data.get("borders", "")
    if borders and borders == lesion.get("appearance", {}).get("borders", ""):
        score += 1.5
    total_weight += 1.5

    # Demographics (weight 1)
    age = data.get("patient_age", 0)
    demo = lesion.get("demographics", {})
    age_str = demo.get("age", "")
    if age > 0 and age_str:
        if "+" in age_str:
            try:
                min_age = int(age_str.replace("+", ""))
                if age >= min_age:
                    score += 1.0
            except ValueError:
                pass
        elif "-" in age_str:
            parts = age_str.split("-")
            try:
                if int(parts[0]) <= age <= int(parts[1]):
                    score += 1.0
            except (ValueError, IndexError):
                if age_str == "any":
                    score += 0.5
        elif age_str == "any":
            score += 0.5
    total_weight += 1.0

    # Risk factor match (weight 1)
    rf = set(data.get("risk_factors", []))
    lesion_rf = set(demo.get("risk", []))
    if rf and lesion_rf:
        overlap = len(rf & lesion_rf)
        if overlap > 0:
            score += 1.0 * (overlap / max(len(lesion_rf), 1))
    total_weight += 1.0

    return score / total_weight if total_weight > 0 else 0.0


def calculate_cancer_risk(data: Dict[str, Any]) -> int:
    """Calculate cancer risk score 0-100 based on input features."""
    score = 0.0

    # Location risk (0-30 points)
    location = data.get("location", "")
    score += _LOCATION_RISK.get(location, 0.3) * 30

    # Duration risk (0-20 points)
    duration = data.get("duration", "")
    score += _DURATION_RISK.get(duration, 0.1) * 20

    # Color/texture risk (0-20 points)
    colors = set(data.get("colors", []))
    high_risk_colors = {"red", "mixed red/white"}
    if colors & high_risk_colors:
        score += 15
    if "white" in colors and location in ("tongue lateral", "floor of mouth"):
        score += 10

    textures = set(data.get("textures", []))
    if "ulcerated" in textures:
        score += 10
    if "rough/granular" in textures:
        score += 5

    # Borders (0-10 points)
    borders = data.get("borders", "")
    if borders == "irregular":
        score += 10
    elif borders == "raised/rolled":
        score += 8

    # Risk factors (0-15 points)
    rf = data.get("risk_factors", [])
    for f in rf:
        score += _RISK_FACTOR_WEIGHTS.get(f, 0) * 15

    # Symptoms (0-5 points)
    symptoms = set(data.get("symptoms", []))
    if "numb" in symptoms:
        score += 5
    if "difficulty swallowing" in symptoms:
        score += 3

    # Age adjustment
    age = data.get("patient_age", 0)
    if age > 60:
        score *= 1.15
    elif age > 45:
        score *= 1.05
    elif age < 30:
        score *= 0.7

    return min(100, max(0, int(score)))


def get_differential(data: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Generate ranked differential diagnoses based on lesion characteristics."""
    scored: List[tuple[float, Dict[str, Any]]] = []

    for lesion in ORAL_LESIONS:
        match_score = _score_match(lesion, data)
        if match_score > 0.15:
            probability = min(95, int(match_score * 100))
            scored.append((match_score, {
                "name": lesion["name"],
                "category": lesion["category"],
                "probability": probability,
                "malignant_potential": lesion["malignant_potential"],
                "key_features": lesion["key_features"],
                "biopsy_indicated": lesion["biopsy_indicated"],
                "locations": lesion["locations"],
            }))

    scored.sort(key=lambda x: x[0], reverse=True)
    return [s[1] for s in scored[:5]]


def get_biopsy_recommendation(
    cancer_risk: int, differentials: List[Dict[str, Any]], data: Dict[str, Any]
) -> Dict[str, Any]:
    """Determine biopsy recommendation based on risk and differentials."""
    has_malignant = any(d["malignant_potential"] in ("high", "moderate") for d in differentials[:3])
    has_biopsy_indicated = any(d.get("biopsy_indicated") for d in differentials[:3])
    duration = data.get("duration", "")

    if cancer_risk >= 70 or (has_malignant and cancer_risk >= 40):
        urgency = "IMMEDIATE"
        technique = "Incisional biopsy at lesion margin including normal tissue"
        reasoning = "High cancer risk score with features suspicious for malignancy"
    elif cancer_risk >= 40 or has_biopsy_indicated:
        urgency = "SOON"
        technique = "Incisional biopsy for lesions >1cm, excisional for <1cm"
        reasoning = "Moderate risk features; biopsy recommended to rule out dysplasia"
    elif duration in (">6 months", "3-6 months") and has_biopsy_indicated:
        urgency = "SOON"
        technique = "Excisional biopsy if small; incisional if >1cm"
        reasoning = "Persistent lesion requiring histopathologic evaluation"
    elif cancer_risk >= 20:
        urgency = "MONITOR"
        technique = "Re-evaluate in 2 weeks; biopsy if persistent"
        reasoning = "Low-moderate risk; monitor for resolution"
    else:
        urgency = "NOT_NEEDED"
        technique = "Clinical follow-up at next visit"
        reasoning = "Low risk, consistent with benign process"

    size = data.get("size_mm", 0)
    site_guidance = ""
    if size > 0:
        if size > 10:
            site_guidance = f"Lesion is {size}mm — incisional biopsy at most suspicious area (firmest/most irregular region) with adjacent normal tissue."
        else:
            site_guidance = f"Lesion is {size}mm — excisional biopsy feasible with 2-3mm margins."

    return {
        "urgency": urgency,
        "technique": technique,
        "site_guidance": site_guidance,
        "reasoning": reasoning,
    }


def get_referral(cancer_risk: int, differentials: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Determine referral recommendation."""
    if cancer_risk >= 60:
        return {
            "refer_to": "Oral and Maxillofacial Surgeon or Oral Medicine Specialist",
            "urgency": "Within 1 week",
            "reason": "High suspicion for malignancy — urgent biopsy and workup needed",
        }
    elif cancer_risk >= 35:
        return {
            "refer_to": "Oral Medicine Specialist or Oral Surgeon",
            "urgency": "Within 2-3 weeks",
            "reason": "Suspicious lesion requiring specialist evaluation and possible biopsy",
        }
    elif any(d["category"] == "autoimmune" for d in differentials[:3]):
        return {
            "refer_to": "Oral Medicine Specialist",
            "urgency": "Within 2-4 weeks",
            "reason": "Suspected autoimmune condition requiring specialist management",
        }
    else:
        return {
            "refer_to": "None — manage in general practice",
            "urgency": "N/A",
            "reason": "Likely benign; can be managed with observation",
        }


def analyze_lesion(data: Dict[str, Any]) -> Dict[str, Any]:
    """Run complete lesion analysis pipeline.

    Args:
        data: Dict with lesion characteristics matching LesionInput fields.

    Returns:
        Full screening result with risk score, differentials, biopsy
        recommendation, referral, and next steps.
    """
    cancer_risk = calculate_cancer_risk(data)
    differentials = get_differential(data)
    biopsy = get_biopsy_recommendation(cancer_risk, differentials, data)
    referral = get_referral(cancer_risk, differentials)

    # Generate next steps
    next_steps: List[str] = []
    if biopsy["urgency"] == "IMMEDIATE":
        next_steps.append("Schedule biopsy within 48-72 hours")
        next_steps.append("Photograph lesion for documentation")
        next_steps.append("Refer to specialist if you don't perform biopsies")
    elif biopsy["urgency"] == "SOON":
        next_steps.append("Schedule biopsy within 1-2 weeks")
        next_steps.append("Document lesion size, color, location with photos")
    elif biopsy["urgency"] == "MONITOR":
        next_steps.append("Re-evaluate in 2 weeks")
        next_steps.append("If lesion persists or changes, biopsy")
    else:
        next_steps.append("Document findings in patient record")
        next_steps.append("Re-evaluate at next recall visit")

    next_steps.append("Record all findings with measurements")
    if data.get("risk_factors"):
        next_steps.append("Counsel patient on risk factor modification")

    return {
        "cancer_risk_score": cancer_risk,
        "differentials": differentials,
        "biopsy_recommendation": biopsy,
        "referral": referral,
        "next_steps": next_steps,
        "disclaimer": "Clinical decision support only. Does not replace professional judgment. Always correlate with clinical examination.",
    }
