"""Billing intelligence engine — CDT codes, claim validation, denial analysis."""

from __future__ import annotations

from typing import Any, Dict, List

from ..knowledge.cdt_codes import CDT_CODES, lookup_cdt, search_cdt

# Common denial codes and their meanings
DENIAL_CODES: Dict[str, Dict[str, Any]] = {
    "D0001": {
        "description": "Missing information",
        "explanation": "Claim was missing required data elements (patient info, provider info, or tooth numbers).",
        "appeal_strategy": "Resubmit with complete information. Check for missing fields: patient DOB, subscriber ID, tooth numbers, surfaces, provider NPI.",
        "success_rate": "90% on resubmission",
    },
    "D0002": {
        "description": "Duplicate claim",
        "explanation": "A claim for the same procedure on the same date has already been processed.",
        "appeal_strategy": "Verify this is not a true duplicate. If different teeth or surfaces, include narrative clarifying the distinction.",
        "success_rate": "70% if legitimately different procedures",
    },
    "D0003": {
        "description": "Frequency limitation exceeded",
        "explanation": "The procedure was performed more frequently than the plan allows.",
        "appeal_strategy": "Submit narrative of medical necessity explaining why additional frequency was required. Include clinical documentation, radiographs, and relevant guidelines.",
        "success_rate": "40-60% with strong documentation",
    },
    "D0004": {
        "description": "Not covered under plan",
        "explanation": "The procedure is excluded from the patient's benefit plan.",
        "appeal_strategy": "Verify benefits first. If applicable, submit under alternative code. Consider patient's secondary insurance. Discuss patient-pay options.",
        "success_rate": "10-20% (coverage exclusions are usually firm)",
    },
    "D0005": {
        "description": "Pre-authorization required",
        "explanation": "The procedure requires pre-authorization/pre-determination before treatment.",
        "appeal_strategy": "Submit pre-authorization request with radiographs, photos, and narrative. Wait for approval before treating (except emergencies).",
        "success_rate": "80% if pre-auth submitted with proper documentation",
    },
    "D0006": {
        "description": "Bundled with another procedure",
        "explanation": "The procedure is considered inclusive with another procedure billed on the same date.",
        "appeal_strategy": "Review CDT manual for bundling rules. If procedures are legitimately separate, submit narrative explaining medical necessity for each. Reference CDT code descriptions.",
        "success_rate": "30-50% depending on specific codes",
    },
    "D0007": {
        "description": "Downcoded to lesser procedure",
        "explanation": "The carrier reduced the procedure code to a less complex/costly code.",
        "appeal_strategy": "Submit operative notes, radiographs, and narrative explaining why the higher code was appropriate. Reference CDT definitions for the code billed.",
        "success_rate": "50-60% with documentation",
    },
    "D0008": {
        "description": "Missing/invalid radiographs",
        "explanation": "Required radiographic documentation was not submitted or was unreadable.",
        "appeal_strategy": "Resubmit with diagnostic-quality radiographs. Digital images should be high-resolution. Include date of radiographs.",
        "success_rate": "85% on resubmission with proper images",
    },
    "D0009": {
        "description": "Procedure not medically necessary",
        "explanation": "The carrier determined the procedure was not clinically necessary based on submitted documentation.",
        "appeal_strategy": "Submit detailed narrative, clinical photos, radiographs, peer-reviewed literature supporting the procedure, and relevant clinical guidelines (ADA, AAP, AAE).",
        "success_rate": "40-55% on appeal",
    },
    "D0010": {
        "description": "Waiting period not met",
        "explanation": "The patient has not completed the plan's waiting period for this category of procedures.",
        "appeal_strategy": "Verify enrollment date and waiting period terms. If emergency, request exception with documentation of acute condition.",
        "success_rate": "15-25% (contractual limitation)",
    },
    "D0011": {
        "description": "Age limitation",
        "explanation": "The patient does not meet the age requirements for the procedure.",
        "appeal_strategy": "If clinically necessary regardless of age, submit narrative with supporting evidence. Sealants for adults: cite evidence of caries risk.",
        "success_rate": "20-30%",
    },
    "D0012": {
        "description": "Maximum benefit exceeded",
        "explanation": "The patient's annual or lifetime maximum benefit has been reached.",
        "appeal_strategy": "Discuss treatment timing with patient (wait for benefit year reset). Consider phasing treatment across benefit years. Verify remaining benefits.",
        "success_rate": "5% (contractual limit)",
    },
}


def validate_claim(data: Dict[str, Any]) -> Dict[str, Any]:
    """Validate a dental claim before submission.

    Args:
        data: Dict with cdt_codes, payer, diagnosis_codes, tooth_numbers.

    Returns:
        Validation results with flags and recommendations.
    """
    codes = data.get("cdt_codes", [])
    payer = data.get("payer", "").lower()
    tooth_numbers = data.get("tooth_numbers", [])

    validations: List[Dict[str, Any]] = []
    warnings: List[Dict[str, Any]] = []
    total_fee_min = 0
    total_fee_max = 0

    for code_str in codes:
        cdt = lookup_cdt(code_str)
        if not cdt:
            warnings.append({
                "code": code_str,
                "issue": "Code not found in database",
                "recommendation": "Verify code is valid and current",
            })
            continue

        # Parse fee range
        fee_str = cdt.get("fee_range", "$0-0")
        try:
            parts = fee_str.replace("$", "").replace(",", "").split("-")
            fee_min = int(parts[0])
            fee_max = int(parts[1]) if len(parts) > 1 else fee_min
            total_fee_min += fee_min
            total_fee_max += fee_max
        except (ValueError, IndexError):
            fee_min = fee_max = 0

        validation = {
            "code": cdt["code"],
            "description": cdt["description"],
            "category": cdt["category"],
            "fee_range": cdt["fee_range"],
            "documentation_needed": cdt["documentation_needed"],
            "common_denials": cdt["common_denials"],
            "status": "valid",
        }

        # Check for common issues
        if not tooth_numbers and cdt["category"] in ("restorative", "endodontic", "oral_surgery"):
            validation["status"] = "warning"
            warnings.append({
                "code": code_str,
                "issue": "Tooth number required for this procedure category",
                "recommendation": "Add tooth number to avoid denial",
            })

        validations.append(validation)

    # Check for bundling issues
    code_set = set(codes)
    bundling_issues = _check_bundling(code_set)
    for issue in bundling_issues:
        warnings.append(issue)

    return {
        "validations": validations,
        "warnings": warnings,
        "total_codes": len(codes),
        "estimated_fee_range": f"${total_fee_min}-${total_fee_max}",
        "pre_submission_checklist": [
            "Verify patient eligibility and remaining benefits",
            "Attach required radiographs for surgical/endo/perio procedures",
            "Include narrative for any unusual or complex procedures",
            "Confirm tooth numbers and surfaces are accurate",
            "Check frequency limitations before submitting",
        ],
        "disclaimer": "Fee estimates are national averages and vary by region. Verify with current fee schedule.",
    }


def _check_bundling(codes: set[str]) -> List[Dict[str, str]]:
    """Check for potential bundling issues between codes."""
    issues: List[Dict[str, str]] = []

    # Common bundling pairs
    if "D2950" in codes and any(c.startswith("D27") for c in codes):
        issues.append({
            "code": "D2950 + Crown",
            "issue": "Core buildup often bundled/denied when submitted with crown",
            "recommendation": "Include narrative documenting insufficient remaining tooth structure. Pre-op photo recommended.",
        })

    if "D0140" in codes and any(c.startswith("D7") for c in codes):
        issues.append({
            "code": "D0140 + Surgery",
            "issue": "Limited exam often bundled with definitive treatment same day",
            "recommendation": "If emergency visit, document that exam was separate service with treatment at later visit.",
        })

    if "D9110" in codes and any(c.startswith("D3") or c.startswith("D7") for c in codes):
        issues.append({
            "code": "D9110 + Definitive treatment",
            "issue": "Palliative treatment may be bundled with definitive treatment same day",
            "recommendation": "Only bill D9110 if palliative treatment was on a separate visit from definitive treatment.",
        })

    if "D1110" in codes and any(c.startswith("D434") for c in codes):
        issues.append({
            "code": "D1110 + SRP",
            "issue": "Prophylaxis should not be billed same day as scaling and root planing",
            "recommendation": "Bill D1110 or D4341, not both. If patient has perio, use D4341/D4342.",
        })

    return issues


def analyze_denial(denial_code: str) -> Dict[str, Any]:
    """Analyze a claim denial and provide appeal strategy.

    Args:
        denial_code: The denial reason code.

    Returns:
        Analysis with explanation and appeal strategy.
    """
    denial = DENIAL_CODES.get(denial_code)

    if denial:
        return {
            "denial_code": denial_code,
            "description": denial["description"],
            "explanation": denial["explanation"],
            "appeal_strategy": denial["appeal_strategy"],
            "estimated_success_rate": denial["success_rate"],
            "appeal_steps": [
                "Review the EOB/ERA for specific denial reason",
                "Gather supporting documentation (radiographs, photos, narrative)",
                "Write appeal letter referencing ADA/CDT guidelines",
                "Submit within carrier's appeal timeframe (usually 30-90 days)",
                "Follow up within 30 days if no response",
            ],
            "disclaimer": "Appeal outcomes vary by carrier and documentation. Consult billing specialist for complex cases.",
        }

    return {
        "denial_code": denial_code,
        "description": "Unknown denial code",
        "explanation": "This denial code is not in our database.",
        "appeal_strategy": "Contact the insurance carrier for specific denial reason. Request written explanation of denial.",
        "estimated_success_rate": "Unknown",
        "appeal_steps": [
            "Call carrier's provider services line",
            "Request written explanation of denial",
            "Gather clinical documentation",
            "Submit formal appeal with narrative",
        ],
        "disclaimer": "Consult with a dental billing specialist for carrier-specific denial codes.",
    }


def cdt_lookup(code: str) -> Dict[str, Any]:
    """Look up a specific CDT code.

    Args:
        code: CDT code string (e.g., 'D0120').

    Returns:
        CDT code details or not-found message.
    """
    result = lookup_cdt(code)
    if result:
        return result
    return {"error": f"CDT code '{code}' not found", "suggestion": "Check code format (e.g., D0120)"}


def cdt_search(query: str) -> Dict[str, Any]:
    """Search CDT codes by keyword.

    Args:
        query: Search term (code fragment or description keyword).

    Returns:
        Search results.
    """
    results = search_cdt(query)
    return {
        "query": query,
        "results": results[:20],
        "total": len(results),
    }
