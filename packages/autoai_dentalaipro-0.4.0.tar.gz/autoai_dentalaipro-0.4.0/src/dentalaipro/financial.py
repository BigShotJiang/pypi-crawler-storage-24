"""Financial management module for DentalAI Pro.

Handles double-entry bookkeeping, invoicing, VAT, NHS band charges,
P&L reports, and financial dashboards for dental practices.
"""

from __future__ import annotations

import json
import time
import uuid
from datetime import datetime, date, timedelta
from typing import Any, Dict, List, Optional


# ── NHS Dental Charges 2024/25 ─────────────────────────────────
NHS_BAND_CHARGES = {
    "1": 26.80,
    "2": 73.50,
    "3": 319.10,
    "urgent": 26.80,
}

NHS_BAND_UDA = {
    "1": 1,
    "2": 3,
    "3": 12,
    "urgent": 1.2,
}

NHS_BAND_DESCRIPTIONS = {
    "1": "Examination, X-rays, scale & polish, preventive advice",
    "2": "Fillings, root canals, extractions",
    "3": "Crowns, bridges, dentures",
    "urgent": "Urgent dental treatment",
}

NHS_EXEMPTIONS = {
    "under18": "Under 18 years old",
    "under19edu": "Under 19 in full-time education",
    "pregnant": "Pregnant or had baby in last 12 months",
    "benefits": "Income-based benefits (IS/JSA/ESA/UC)",
    "hc2": "HC2 Certificate (full help)",
    "hc3": "HC3 Certificate (partial help)",
    "war_pension": "War Pension",
    "none": "No exemption",
}

# ── UK VAT Rules for Dental ────────────────────────────────────
VAT_STANDARD_RATE = 0.20  # 20%

VAT_CATEGORIES = {
    "healthcare_exempt": {
        "rate": 0.0,
        "label": "Healthcare services — VAT exempt",
        "examples": [
            "Registered dentist services",
            "NHS treatments",
            "Private clinical treatments",
            "Dental hygiene services",
            "Private dental plans/capitation",
        ],
    },
    "cosmetic_standard": {
        "rate": 0.20,
        "label": "Cosmetic treatments — Standard rate (20%)",
        "examples": [
            "Teeth whitening",
            "Cosmetic veneers (non-clinical)",
            "Dental jewellery",
        ],
    },
    "products_standard": {
        "rate": 0.20,
        "label": "Products sold to patients — Standard rate (20%)",
        "examples": [
            "Whitening kits",
            "Electric toothbrushes",
            "Mouthguards (non-clinical)",
        ],
    },
}

# ── Expense Categories ─────────────────────────────────────────
EXPENSE_CATEGORIES = {
    "clinical_supplies": {
        "label": "Clinical Supplies",
        "subcategories": [
            "Composites", "Impression materials", "Cements",
            "Anaesthetics", "Gloves & PPE", "Disposables",
            "Endodontic supplies", "Orthodontic supplies",
        ],
    },
    "lab_fees": {
        "label": "Lab Fees",
        "subcategories": [
            "Crowns", "Dentures", "Orthodontic appliances",
            "Bridges", "Implant components", "Nightguards",
        ],
    },
    "staff_costs": {
        "label": "Staff Costs",
        "subcategories": [
            "Salaries", "NI contributions", "Pension",
            "Locum fees", "Agency staff", "Staff training",
        ],
    },
    "premises": {
        "label": "Premises",
        "subcategories": [
            "Rent", "Business rates", "Utilities",
            "Maintenance", "Cleaning", "Waste disposal",
        ],
    },
    "equipment": {
        "label": "Equipment",
        "subcategories": [
            "Dental chairs", "X-ray units", "Compressors",
            "Autoclaves", "Handpieces", "Small instruments",
        ],
    },
    "it_software": {
        "label": "IT & Software",
        "subcategories": [
            "Practice management software", "DentalAI Pro subscription",
            "Imaging software", "Internet & phone",
        ],
    },
    "insurance": {
        "label": "Insurance",
        "subcategories": [
            "Professional indemnity", "Buildings insurance",
            "Contents insurance", "Employer's liability",
        ],
    },
    "marketing": {
        "label": "Marketing & Advertising",
        "subcategories": [
            "Online advertising", "Print advertising",
            "Website hosting", "Social media",
        ],
    },
    "cpd_training": {
        "label": "CPD & Training",
        "subcategories": [
            "Courses & conferences", "Books & journals",
            "Online CPD", "Verifiable CPD",
        ],
    },
    "professional_fees": {
        "label": "Professional Fees",
        "subcategories": [
            "Accountant", "CQC registration", "GDC registration",
            "Legal fees", "Consultancy",
        ],
    },
}

# ── Income Categories ──────────────────────────────────────────
INCOME_CATEGORIES = {
    "nhs_payments": {
        "label": "NHS Payments",
        "subcategories": ["UDA payments", "Band 1", "Band 2", "Band 3", "Urgent"],
    },
    "private_fees": {
        "label": "Private Fees",
        "subcategories": [
            "Examinations", "Fillings", "Crowns & bridges",
            "Root canals", "Extractions", "Dentures",
            "Implants", "Orthodontics",
        ],
    },
    "cosmetic": {
        "label": "Cosmetic Treatments",
        "subcategories": [
            "Teeth whitening", "Veneers", "Composite bonding",
            "Smile makeover",
        ],
    },
    "insurance_payments": {
        "label": "Insurance Payments",
        "subcategories": ["Denplan", "BUPA", "AXA", "Simplyhealth", "Other"],
    },
    "hygiene": {
        "label": "Hygiene Appointments",
        "subcategories": ["Scale & polish", "Deep cleaning", "Periodontal treatment"],
    },
    "other_income": {
        "label": "Other Income",
        "subcategories": ["Product sales", "Referral fees", "Rental income"],
    },
}


def generate_invoice_id() -> str:
    """Generate a unique invoice ID."""
    ts = datetime.now().strftime("%Y%m%d")
    short_uuid = uuid.uuid4().hex[:6].upper()
    return f"INV-{ts}-{short_uuid}"


def calculate_vat(amount: float, vat_rate: float) -> float:
    """Calculate VAT amount on a given amount."""
    return round(amount * vat_rate, 2)


def determine_vat_rate(treatment_type: str, is_cosmetic: bool = False) -> float:
    """Determine the VAT rate for a dental service.

    Healthcare services by registered dentists are VAT exempt.
    Cosmetic treatments and product sales are at standard rate (20%).
    """
    if is_cosmetic:
        return VAT_STANDARD_RATE
    if treatment_type in ("whitening", "cosmetic_veneer", "dental_jewellery",
                          "product_sale", "whitening_kit"):
        return VAT_STANDARD_RATE
    # Default: healthcare services are exempt
    return 0.0


def create_nhs_invoice(
    patient_id: int,
    patient_name: str,
    band: str,
    exemption: str = "none",
    notes: str = "",
) -> Dict[str, Any]:
    """Create an NHS invoice based on treatment band.

    Args:
        patient_id: Patient record ID.
        patient_name: Patient name for the invoice.
        band: NHS treatment band (1, 2, 3, or urgent).
        exemption: Exemption category code.
        notes: Additional notes.

    Returns:
        Invoice dictionary ready for storage.
    """
    if band not in NHS_BAND_CHARGES:
        raise ValueError(f"Invalid NHS band: {band}. Must be one of: {list(NHS_BAND_CHARGES.keys())}")

    charge = NHS_BAND_CHARGES[band]
    is_exempt = exemption != "none" and exemption != "hc3"

    if is_exempt:
        total = 0.0
    elif exemption == "hc3":
        # HC3 = partial help, charge may be reduced. Use full charge as placeholder.
        total = charge
    else:
        total = charge

    items = [
        {
            "procedure": f"NHS Band {band.title()} Treatment",
            "description": NHS_BAND_DESCRIPTIONS.get(band, ""),
            "fee": charge,
            "vat": 0.0,
            "udas": NHS_BAND_UDA.get(band, 0),
        }
    ]

    invoice_id = generate_invoice_id()
    return {
        "id": invoice_id,
        "patient_id": patient_id,
        "patient_name": patient_name,
        "date": date.today().isoformat(),
        "type": "nhs",
        "items": json.dumps(items),
        "subtotal": charge,
        "vat": 0.0,
        "total": total,
        "nhs_band": band,
        "status": "pending",
        "notes": notes,
        "exemption": exemption,
        "exemption_label": NHS_EXEMPTIONS.get(exemption, ""),
    }


def create_private_invoice(
    patient_id: int,
    patient_name: str,
    items: List[Dict[str, Any]],
    notes: str = "",
) -> Dict[str, Any]:
    """Create a private invoice with procedure breakdown.

    Args:
        patient_id: Patient record ID.
        patient_name: Patient name.
        items: List of dicts with keys: procedure, fee, is_cosmetic (optional), tooth (optional).
        notes: Additional notes.

    Returns:
        Invoice dictionary ready for storage.
    """
    processed_items = []
    subtotal = 0.0
    total_vat = 0.0

    for item in items:
        fee = float(item.get("fee", 0))
        is_cosmetic = item.get("is_cosmetic", False)
        vat_rate = determine_vat_rate(
            item.get("procedure", ""),
            is_cosmetic=is_cosmetic,
        )
        vat_amount = calculate_vat(fee, vat_rate)
        subtotal += fee
        total_vat += vat_amount

        processed_items.append({
            "procedure": item.get("procedure", ""),
            "tooth": item.get("tooth", ""),
            "fee": fee,
            "vat_rate": vat_rate,
            "vat": vat_amount,
        })

    subtotal = round(subtotal, 2)
    total_vat = round(total_vat, 2)
    total = round(subtotal + total_vat, 2)

    invoice_id = generate_invoice_id()
    return {
        "id": invoice_id,
        "patient_id": patient_id,
        "patient_name": patient_name,
        "date": date.today().isoformat(),
        "type": "private",
        "items": json.dumps(processed_items),
        "subtotal": subtotal,
        "vat": total_vat,
        "total": total,
        "nhs_band": "",
        "status": "pending",
        "notes": notes,
    }


def create_insurance_invoice(
    patient_id: int,
    patient_name: str,
    items: List[Dict[str, Any]],
    insurance_provider: str = "",
    policy_number: str = "",
    notes: str = "",
) -> Dict[str, Any]:
    """Create an insurance claim-formatted invoice.

    Args:
        patient_id: Patient record ID.
        patient_name: Patient name.
        items: List of dicts with keys: procedure, fee, tooth (optional), cdt_code (optional).
        insurance_provider: Name of insurance provider.
        policy_number: Insurance policy number.
        notes: Additional notes.

    Returns:
        Invoice dictionary ready for storage.
    """
    processed_items = []
    subtotal = 0.0

    for item in items:
        fee = float(item.get("fee", 0))
        subtotal += fee
        processed_items.append({
            "procedure": item.get("procedure", ""),
            "tooth": item.get("tooth", ""),
            "fee": fee,
            "cdt_code": item.get("cdt_code", ""),
            "vat": 0.0,
        })

    subtotal = round(subtotal, 2)

    invoice_id = generate_invoice_id()
    return {
        "id": invoice_id,
        "patient_id": patient_id,
        "patient_name": patient_name,
        "date": date.today().isoformat(),
        "type": "insurance",
        "items": json.dumps(processed_items),
        "subtotal": subtotal,
        "vat": 0.0,
        "total": subtotal,
        "nhs_band": "",
        "status": "pending",
        "notes": f"Provider: {insurance_provider}\nPolicy: {policy_number}\n{notes}".strip(),
    }


def generate_pnl(
    income_records: List[Dict[str, Any]],
    expense_records: List[Dict[str, Any]],
    period_label: str = "",
) -> Dict[str, Any]:
    """Generate a Profit & Loss statement from ledger records.

    Args:
        income_records: List of income ledger entries.
        expense_records: List of expense ledger entries.
        period_label: Human-readable period label (e.g., "March 2026").

    Returns:
        P&L report dictionary.
    """
    # Income breakdown by category
    income_by_category: Dict[str, float] = {}
    total_income = 0.0
    for rec in income_records:
        cat = rec.get("category", "Other")
        amount = float(rec.get("amount", 0))
        income_by_category[cat] = income_by_category.get(cat, 0) + amount
        total_income += amount

    # Expense breakdown by category
    expense_by_category: Dict[str, float] = {}
    total_expenses = 0.0
    for rec in expense_records:
        cat = rec.get("category", "Other")
        amount = float(rec.get("amount", 0))
        expense_by_category[cat] = expense_by_category.get(cat, 0) + amount
        total_expenses += amount

    total_income = round(total_income, 2)
    total_expenses = round(total_expenses, 2)
    net_profit = round(total_income - total_expenses, 2)
    margin = round((net_profit / total_income * 100), 1) if total_income > 0 else 0.0

    # Round category totals
    income_by_category = {k: round(v, 2) for k, v in income_by_category.items()}
    expense_by_category = {k: round(v, 2) for k, v in expense_by_category.items()}

    return {
        "period": period_label,
        "total_income": total_income,
        "total_expenses": total_expenses,
        "net_profit": net_profit,
        "profit_margin_pct": margin,
        "income_breakdown": income_by_category,
        "expense_breakdown": expense_by_category,
    }


def generate_vat_summary(
    income_records: List[Dict[str, Any]],
    expense_records: List[Dict[str, Any]],
    period_label: str = "",
) -> Dict[str, Any]:
    """Generate VAT return data for a period.

    Args:
        income_records: Income ledger entries for the period.
        expense_records: Expense ledger entries for the period.
        period_label: Period label.

    Returns:
        VAT summary dict with collected, paid, and net amounts.
    """
    vat_collected = 0.0  # VAT on sales/income (output VAT)
    exempt_income = 0.0
    taxable_income = 0.0

    for rec in income_records:
        vat_amt = float(rec.get("vat_amount", 0))
        amount = float(rec.get("amount", 0))
        vat_collected += vat_amt
        if vat_amt > 0:
            taxable_income += amount
        else:
            exempt_income += amount

    vat_paid = 0.0  # VAT on purchases/expenses (input VAT)
    for rec in expense_records:
        vat_amt = float(rec.get("vat_amount", 0))
        vat_paid += vat_amt

    vat_collected = round(vat_collected, 2)
    vat_paid = round(vat_paid, 2)
    net_vat = round(vat_collected - vat_paid, 2)

    return {
        "period": period_label,
        "vat_collected": vat_collected,
        "vat_paid": vat_paid,
        "net_vat": net_vat,
        "vat_owed": net_vat if net_vat > 0 else 0.0,
        "vat_reclaimable": abs(net_vat) if net_vat < 0 else 0.0,
        "exempt_income": round(exempt_income, 2),
        "taxable_income": round(taxable_income, 2),
        "notes": (
            "Most dental healthcare services are VAT exempt. "
            "Cosmetic treatments and product sales are at standard rate (20%). "
            "Partial exemption rules may apply for mixed practices."
        ),
    }


def calculate_daily_takings(
    income_records: List[Dict[str, Any]],
    date_str: Optional[str] = None,
) -> Dict[str, Any]:
    """Calculate daily takings summary.

    Args:
        income_records: Income ledger entries for the day.
        date_str: Date string (YYYY-MM-DD). Defaults to today.

    Returns:
        Daily takings summary.
    """
    if date_str is None:
        date_str = date.today().isoformat()

    total = 0.0
    by_method: Dict[str, float] = {}
    by_category: Dict[str, float] = {}
    count = 0

    for rec in income_records:
        amount = float(rec.get("amount", 0))
        total += amount
        count += 1
        method = rec.get("payment_method", "unknown")
        by_method[method] = by_method.get(method, 0) + amount
        cat = rec.get("category", "Other")
        by_category[cat] = by_category.get(cat, 0) + amount

    return {
        "date": date_str,
        "total": round(total, 2),
        "transaction_count": count,
        "by_payment_method": {k: round(v, 2) for k, v in by_method.items()},
        "by_category": {k: round(v, 2) for k, v in by_category.items()},
    }


def calculate_debt_aging(
    invoices: List[Dict[str, Any]],
) -> Dict[str, Any]:
    """Calculate outstanding debt aging (30/60/90 days).

    Args:
        invoices: List of invoice dicts with status and date.

    Returns:
        Debt aging breakdown.
    """
    today = date.today()
    buckets = {
        "current": {"label": "Current (0-30 days)", "total": 0.0, "count": 0, "invoices": []},
        "30_days": {"label": "30-60 days", "total": 0.0, "count": 0, "invoices": []},
        "60_days": {"label": "60-90 days", "total": 0.0, "count": 0, "invoices": []},
        "90_plus": {"label": "90+ days", "total": 0.0, "count": 0, "invoices": []},
    }

    total_outstanding = 0.0

    for inv in invoices:
        if inv.get("status") not in ("pending", "overdue"):
            continue

        try:
            inv_date = date.fromisoformat(inv.get("date", today.isoformat()))
        except (ValueError, TypeError):
            inv_date = today

        days = (today - inv_date).days
        amount = float(inv.get("total", 0))
        total_outstanding += amount

        inv_summary = {
            "id": inv.get("id", ""),
            "patient_name": inv.get("patient_name", ""),
            "total": amount,
            "date": inv.get("date", ""),
            "days_outstanding": days,
        }

        if days <= 30:
            buckets["current"]["total"] += amount
            buckets["current"]["count"] += 1
            buckets["current"]["invoices"].append(inv_summary)
        elif days <= 60:
            buckets["30_days"]["total"] += amount
            buckets["30_days"]["count"] += 1
            buckets["30_days"]["invoices"].append(inv_summary)
        elif days <= 90:
            buckets["60_days"]["total"] += amount
            buckets["60_days"]["count"] += 1
            buckets["60_days"]["invoices"].append(inv_summary)
        else:
            buckets["90_plus"]["total"] += amount
            buckets["90_plus"]["count"] += 1
            buckets["90_plus"]["invoices"].append(inv_summary)

    # Round totals
    for bucket in buckets.values():
        bucket["total"] = round(bucket["total"], 2)

    return {
        "total_outstanding": round(total_outstanding, 2),
        "buckets": buckets,
    }


def get_expense_categories() -> Dict[str, Any]:
    """Return all expense categories and subcategories."""
    return EXPENSE_CATEGORIES


def get_income_categories() -> Dict[str, Any]:
    """Return all income categories and subcategories."""
    return INCOME_CATEGORIES


def get_vat_info() -> Dict[str, Any]:
    """Return VAT category information for dental practices."""
    return VAT_CATEGORIES


def get_nhs_band_info() -> Dict[str, Any]:
    """Return NHS band charges and descriptions."""
    return {
        band: {
            "charge": NHS_BAND_CHARGES[band],
            "udas": NHS_BAND_UDA[band],
            "description": NHS_BAND_DESCRIPTIONS[band],
        }
        for band in NHS_BAND_CHARGES
    }
