"""Practice Insights Dashboard & AI Recommendations Engine for DentalAI Pro.

Computes practice-level KPIs, dentist performance metrics, scheduling efficiency,
and generates prioritized AI recommendations from store data.
"""

from __future__ import annotations

import hashlib
import time
from collections import defaultdict
from datetime import date, datetime, timedelta
from typing import Any, Dict, List, Optional, Tuple

from .store import Store


# ── Helpers ──────────────────────────────────────────────────────

def _today() -> date:
    return date.today()


def _month_start() -> str:
    return _today().replace(day=1).isoformat()


def _year_start() -> str:
    return _today().replace(month=1, day=1).isoformat()


def _safe_pct(numerator: float, denominator: float) -> float:
    """Return percentage rounded to 1 decimal, or 0.0 if denominator is zero."""
    if denominator == 0:
        return 0.0
    return round((numerator / denominator) * 100, 1)


def _parse_date(d: str) -> Optional[date]:
    """Parse ISO date string, return None on failure."""
    try:
        return date.fromisoformat(d[:10])
    except (ValueError, TypeError):
        return None


def _months_ago(months: int) -> str:
    """Return ISO date string for N months ago (approximate)."""
    d = _today() - timedelta(days=months * 30)
    return d.isoformat()


# ── Practice-Level Insights ──────────────────────────────────────

def get_practice_dashboard(store: Store) -> Dict[str, Any]:
    """Aggregated KPIs for the practice owner's morning dashboard."""
    today_str = _today().isoformat()
    month_start = _month_start()
    year_start = _year_start()

    # Patients
    patients = store.list_patients()
    total_patients = len(patients)

    # Active patients = those with any record in last 12 months
    active_patients = _count_active_patients(store)

    # Revenue MTD
    mtd_income = store.get_ledger_entries(entry_type="income", start_date=month_start, end_date=today_str)
    revenue_mtd = sum(float(e.get("amount", 0)) for e in mtd_income)

    # Revenue last month (for comparison)
    last_month_end = (_today().replace(day=1) - timedelta(days=1))
    last_month_start = last_month_end.replace(day=1)
    last_month_income = store.get_ledger_entries(
        entry_type="income",
        start_date=last_month_start.isoformat(),
        end_date=last_month_end.isoformat(),
    )
    revenue_last_month = sum(float(e.get("amount", 0)) for e in last_month_income)
    revenue_change_pct = _safe_pct(revenue_mtd - revenue_last_month, revenue_last_month) if revenue_last_month else 0.0

    # Revenue YTD
    ytd_income = store.get_ledger_entries(entry_type="income", start_date=year_start, end_date=today_str)
    revenue_ytd = sum(float(e.get("amount", 0)) for e in ytd_income)

    # Avg revenue per patient
    avg_revenue_per_patient = round(revenue_ytd / total_patients, 2) if total_patients else 0.0

    # New patients this month
    new_patients_month = _count_new_patients_this_month(store)

    # Recall rate
    recall_rate = get_recall_effectiveness(store).get("recall_rate_7m", 0.0)

    return {
        "total_patients": total_patients,
        "active_patients": active_patients,
        "revenue_mtd": round(revenue_mtd, 2),
        "revenue_last_month": round(revenue_last_month, 2),
        "revenue_change_pct": revenue_change_pct,
        "revenue_ytd": round(revenue_ytd, 2),
        "avg_revenue_per_patient": avg_revenue_per_patient,
        "new_patients_month": new_patients_month,
        "recall_rate": recall_rate,
        "date": today_str,
    }


def _count_active_patients(store: Store) -> int:
    """Count patients with any activity in the last 12 months."""
    conn = store._get_conn()
    twelve_months_ago = time.time() - (365 * 24 * 3600)
    active_ids: set = set()

    for table in ["screening_records", "radiology_records", "treatment_records", "billing_records"]:
        rows = conn.execute(
            f"SELECT DISTINCT patient_id FROM {table} WHERE created_at >= ? AND patient_id IS NOT NULL",
            (twelve_months_ago,),
        ).fetchall()
        for r in rows:
            active_ids.add(r[0])

    # Also count patients with invoices in last 12 months
    cutoff_date = _months_ago(12)
    inv_rows = conn.execute(
        "SELECT DISTINCT patient_id FROM invoices WHERE date >= ? AND patient_id IS NOT NULL",
        (cutoff_date,),
    ).fetchall()
    for r in inv_rows:
        active_ids.add(r[0])

    return len(active_ids)


def _count_new_patients_this_month(store: Store) -> int:
    """Count patients created this month."""
    conn = store._get_conn()
    month_start_ts = datetime.fromisoformat(_month_start()).timestamp()
    row = conn.execute(
        "SELECT COUNT(*) FROM patients WHERE created_at >= ?",
        (month_start_ts,),
    ).fetchone()
    return row[0] if row else 0


def get_revenue_by_chair(store: Store) -> Dict[str, Any]:
    """Revenue breakdown per surgery/chair (uses invoice category or subcategory)."""
    invoices = store.list_invoices()
    profile = store.get_practice_profile()
    num_surgeries = profile.get("num_surgeries", 1) if profile else 1
    num_surgeries = max(num_surgeries, 1)

    total_revenue = sum(float(inv.get("total", 0)) for inv in invoices)
    avg_per_chair = round(total_revenue / num_surgeries, 2)

    # Group by type as a proxy for chair allocation
    by_type: Dict[str, float] = defaultdict(float)
    for inv in invoices:
        inv_type = inv.get("type", "other")
        by_type[inv_type] += float(inv.get("total", 0))

    return {
        "total_revenue": round(total_revenue, 2),
        "num_surgeries": num_surgeries,
        "avg_per_chair": avg_per_chair,
        "by_type": {k: round(v, 2) for k, v in by_type.items()},
    }


def get_scheduling_efficiency(store: Store) -> Dict[str, Any]:
    """Appointment utilization, cancellation, no-show rates.

    Note: Without a dedicated appointments table, we estimate from
    treatment records and invoices as proxies for completed appointments.
    """
    conn = store._get_conn()
    profile = store.get_practice_profile()
    num_surgeries = profile.get("num_surgeries", 1) if profile else 1
    num_surgeries = max(num_surgeries, 1)

    # Count treatment records in last 30 days as proxy for completed appointments
    thirty_days_ago = time.time() - (30 * 24 * 3600)
    completed = conn.execute(
        "SELECT COUNT(*) FROM treatment_records WHERE created_at >= ?",
        (thirty_days_ago,),
    ).fetchone()[0]

    # Theoretical capacity: surgeries * 8 appointments/day * 22 working days
    capacity = num_surgeries * 8 * 22
    utilization_rate = _safe_pct(completed, capacity)

    # Without explicit cancellation tracking, provide framework with defaults
    return {
        "completed_appointments_30d": completed,
        "theoretical_capacity_30d": capacity,
        "utilization_rate": utilization_rate,
        "cancellation_rate": 0.0,  # Placeholder — needs appointment tracking
        "no_show_rate": 0.0,       # Placeholder — needs appointment tracking
        "avg_wait_time_min": 0,    # Placeholder — needs check-in tracking
        "num_surgeries": num_surgeries,
    }


def get_treatment_acceptance(store: Store) -> Dict[str, Any]:
    """Treatment plans presented vs accepted, acceptance rate by fee range."""
    conn = store._get_conn()
    rows = conn.execute(
        "SELECT input_data, result_data FROM treatment_records"
    ).fetchall()

    total_presented = len(rows)
    accepted = 0
    fee_ranges: Dict[str, Dict[str, int]] = {
        "under_100": {"presented": 0, "accepted": 0},
        "100_500": {"presented": 0, "accepted": 0},
        "500_1000": {"presented": 0, "accepted": 0},
        "over_1000": {"presented": 0, "accepted": 0},
    }

    for row in rows:
        try:
            import json
            result = json.loads(row[1])
            input_data = json.loads(row[0])
        except (json.JSONDecodeError, TypeError):
            continue

        # Determine acceptance from result data
        is_accepted = result.get("status") == "accepted" or result.get("overall_risk", "") in ("low", "moderate")
        if is_accepted:
            accepted += 1

        # Estimate fee from procedures
        procedures = input_data.get("planned_procedures", [])
        estimated_fee = len(procedures) * 150  # rough estimate per procedure

        if estimated_fee < 100:
            bucket = "under_100"
        elif estimated_fee < 500:
            bucket = "100_500"
        elif estimated_fee < 1000:
            bucket = "500_1000"
        else:
            bucket = "over_1000"

        fee_ranges[bucket]["presented"] += 1
        if is_accepted:
            fee_ranges[bucket]["accepted"] += 1

    acceptance_rate = _safe_pct(accepted, total_presented)

    fee_range_rates = {}
    for bucket, counts in fee_ranges.items():
        fee_range_rates[bucket] = {
            "presented": counts["presented"],
            "accepted": counts["accepted"],
            "rate": _safe_pct(counts["accepted"], counts["presented"]),
        }

    return {
        "total_presented": total_presented,
        "total_accepted": accepted,
        "acceptance_rate": acceptance_rate,
        "by_fee_range": fee_range_rates,
    }


def get_recall_effectiveness(store: Store) -> Dict[str, Any]:
    """% patients returning within 7 months, lapsed patients (>12 months)."""
    conn = store._get_conn()
    patients = store.list_patients()
    total = len(patients)

    if total == 0:
        return {
            "total_patients": 0,
            "returned_7m": 0,
            "recall_rate_7m": 0.0,
            "lapsed_12m": 0,
            "lapsed_rate_12m": 0.0,
            "lapsed_patients": [],
        }

    seven_months_ago = time.time() - (7 * 30 * 24 * 3600)
    twelve_months_ago = time.time() - (12 * 30 * 24 * 3600)

    # Find last visit per patient across all record tables
    last_visit: Dict[int, float] = {}
    for table in ["screening_records", "radiology_records", "treatment_records", "billing_records"]:
        rows = conn.execute(
            f"SELECT patient_id, MAX(created_at) as last_at FROM {table} "
            f"WHERE patient_id IS NOT NULL GROUP BY patient_id"
        ).fetchall()
        for r in rows:
            pid = r[0]
            ts = r[1] or 0
            if pid not in last_visit or ts > last_visit[pid]:
                last_visit[pid] = ts

    returned_7m = sum(1 for ts in last_visit.values() if ts >= seven_months_ago)
    lapsed_ids = [pid for pid, ts in last_visit.items() if ts < twelve_months_ago]

    # Also count patients with NO visits at all as lapsed if they've been registered >12 months
    all_pids = {p["id"] for p in patients}
    visited_pids = set(last_visit.keys())
    never_visited = all_pids - visited_pids

    lapsed_patients = []
    for pid in lapsed_ids:
        p = next((pa for pa in patients if pa["id"] == pid), None)
        if p:
            lapsed_patients.append({"id": pid, "name": p.get("name", ""), "last_visit_ts": last_visit[pid]})

    return {
        "total_patients": total,
        "returned_7m": returned_7m,
        "recall_rate_7m": _safe_pct(returned_7m, total),
        "lapsed_12m": len(lapsed_ids),
        "lapsed_rate_12m": _safe_pct(len(lapsed_ids), total),
        "never_visited": len(never_visited),
        "lapsed_patients": lapsed_patients[:20],  # Top 20
    }


def get_patient_acquisition(store: Store) -> Dict[str, Any]:
    """New patients vs churned, net growth rate."""
    conn = store._get_conn()
    month_start_ts = datetime.fromisoformat(_month_start()).timestamp()
    three_months_ago_ts = time.time() - (90 * 24 * 3600)

    # New this month
    new_row = conn.execute(
        "SELECT COUNT(*) FROM patients WHERE created_at >= ?",
        (month_start_ts,),
    ).fetchone()
    new_this_month = new_row[0] if new_row else 0

    # Churned = patients with last activity > 12 months ago
    recall = get_recall_effectiveness(store)
    churned = recall.get("lapsed_12m", 0)

    total = len(store.list_patients())
    net_growth = new_this_month - churned
    growth_rate = _safe_pct(net_growth, total) if total else 0.0

    return {
        "new_this_month": new_this_month,
        "churned_12m": churned,
        "net_growth": net_growth,
        "growth_rate": growth_rate,
        "total_patients": total,
    }


def get_busiest_times(store: Store) -> Dict[str, Any]:
    """Heatmap data: day x time slot with patient counts from record timestamps."""
    conn = store._get_conn()

    # Initialize grid: days (Mon-Sun) x time slots (Morning/Afternoon/Evening)
    days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
    slots = ["Morning", "Afternoon", "Evening"]
    grid: Dict[str, Dict[str, int]] = {d: {s: 0 for s in slots} for d in days}

    for table in ["screening_records", "radiology_records", "treatment_records"]:
        rows = conn.execute(f"SELECT created_at FROM {table}").fetchall()
        for r in rows:
            ts = r[0]
            if not ts:
                continue
            try:
                dt = datetime.fromtimestamp(float(ts))
                day_name = days[dt.weekday()]
                hour = dt.hour
                if hour < 12:
                    slot = "Morning"
                elif hour < 17:
                    slot = "Afternoon"
                else:
                    slot = "Evening"
                grid[day_name][slot] += 1
            except (ValueError, OSError):
                continue

    # Find busiest
    max_count = 0
    busiest = {"day": "", "slot": ""}
    for d in days:
        for s in slots:
            if grid[d][s] > max_count:
                max_count = grid[d][s]
                busiest = {"day": d, "slot": s}

    return {
        "grid": grid,
        "busiest": busiest,
        "max_count": max_count,
    }


def get_revenue_by_category(store: Store) -> Dict[str, Any]:
    """NHS vs private vs insurance revenue breakdown."""
    invoices = store.list_invoices()

    breakdown: Dict[str, float] = {"nhs": 0.0, "private": 0.0, "insurance": 0.0, "other": 0.0}
    counts: Dict[str, int] = {"nhs": 0, "private": 0, "insurance": 0, "other": 0}

    for inv in invoices:
        inv_type = inv.get("type", "other")
        if inv_type not in breakdown:
            inv_type = "other"
        breakdown[inv_type] += float(inv.get("total", 0))
        counts[inv_type] += 1

    total = sum(breakdown.values())
    percentages = {k: _safe_pct(v, total) for k, v in breakdown.items()}

    return {
        "breakdown": {k: round(v, 2) for k, v in breakdown.items()},
        "counts": counts,
        "percentages": percentages,
        "total": round(total, 2),
    }


# ── Dentist-Level Insights ───────────────────────────────────────

def get_dentist_performance(store: Store, dentist_id: int) -> Dict[str, Any]:
    """Revenue, patient count, treatment mix for a specific dentist."""
    members = store.list_team_members()
    dentist = next((m for m in members if m["id"] == dentist_id), None)
    if not dentist:
        return {"error": "Dentist not found", "dentist_id": dentist_id}

    # Without dentist-level record linkage, return the team member info
    # and aggregate practice-level metrics as a baseline
    conn = store._get_conn()
    treatment_count = conn.execute("SELECT COUNT(*) FROM treatment_records").fetchone()[0]
    total_dentists = sum(1 for m in members if m.get("role") == "dentist")
    total_dentists = max(total_dentists, 1)

    # Estimate per-dentist share (equal distribution as baseline)
    invoices = store.list_invoices()
    total_revenue = sum(float(inv.get("total", 0)) for inv in invoices)
    share = round(total_revenue / total_dentists, 2)

    patients = store.list_patients()
    patient_share = len(patients) // total_dentists

    return {
        "dentist_id": dentist_id,
        "name": dentist.get("name", ""),
        "role": dentist.get("role", ""),
        "estimated_revenue": share,
        "estimated_patients": patient_share,
        "estimated_treatments": treatment_count // total_dentists,
        "avg_revenue_per_visit": round(share / max(patient_share, 1), 2),
        "note": "Estimates based on equal distribution. Link records to dentists for precise data.",
    }


def get_dentist_comparison(store: Store) -> Dict[str, Any]:
    """Comparison table across all dentists."""
    members = store.list_team_members()
    dentists = [m for m in members if m.get("role") == "dentist"]

    if not dentists:
        return {"dentists": [], "total": 0}

    comparisons = []
    for d in dentists:
        perf = get_dentist_performance(store, d["id"])
        comparisons.append({
            "id": d["id"],
            "name": d.get("name", ""),
            "revenue": perf.get("estimated_revenue", 0),
            "patients": perf.get("estimated_patients", 0),
            "treatments": perf.get("estimated_treatments", 0),
            "avg_per_visit": perf.get("avg_revenue_per_visit", 0),
        })

    return {
        "dentists": comparisons,
        "total": len(comparisons),
    }


def get_dentist_outcomes(store: Store, dentist_id: int) -> Dict[str, Any]:
    """Retreatment rate, complication rate, referral patterns for a dentist."""
    conn = store._get_conn()
    import json as _json

    rows = conn.execute("SELECT result_data FROM treatment_records").fetchall()
    total = len(rows)
    retreatments = 0
    complications = 0
    referrals = 0

    for row in rows:
        try:
            result = _json.loads(row[0])
        except (_json.JSONDecodeError, TypeError):
            continue
        # Check for retreatment indicators
        warnings = result.get("warnings", [])
        if any("retreat" in str(w).lower() for w in warnings):
            retreatments += 1
        if any("complication" in str(w).lower() or "risk" in str(w).lower() for w in warnings):
            complications += 1
        if result.get("referral_recommended") or any("refer" in str(w).lower() for w in warnings):
            referrals += 1

    members = store.list_team_members()
    total_dentists = max(sum(1 for m in members if m.get("role") == "dentist"), 1)

    return {
        "dentist_id": dentist_id,
        "total_treatments": total // total_dentists,
        "retreatment_rate": _safe_pct(retreatments, total),
        "complication_rate": _safe_pct(complications, total),
        "referral_count": referrals // total_dentists,
        "note": "Estimates based on aggregate data. Link records to dentists for precise outcomes.",
    }


def get_cpd_status(store: Store) -> Dict[str, Any]:
    """CPD hours completed vs required per team member.

    UK GDC requires:
    - Dentists: 100 hours per 5-year cycle (20/year average)
    - Dental nurses: 50 hours per 5-year cycle (10/year average)
    - Hygienists/therapists: 75 hours per 5-year cycle (15/year average)
    """
    members = store.list_team_members()

    cpd_requirements = {
        "dentist": 20,
        "hygienist": 15,
        "therapist": 15,
        "nurse": 10,
        "receptionist": 0,
        "technician": 10,
    }

    team_cpd = []
    shortfalls = 0
    for m in members:
        role = m.get("role", "").lower()
        required = cpd_requirements.get(role, 0)
        # Without CPD tracking, show requirement and 0 completed
        completed = 0
        shortfall = max(required - completed, 0)
        if shortfall > 0 and required > 0:
            shortfalls += 1

        team_cpd.append({
            "id": m["id"],
            "name": m.get("name", ""),
            "role": role,
            "required_hours": required,
            "completed_hours": completed,
            "shortfall": shortfall,
            "on_track": completed >= required,
        })

    return {
        "team": team_cpd,
        "total_members": len(members),
        "members_with_shortfall": shortfalls,
    }


# ── Patient Experience Metrics ────────────────────────────────────

def get_patient_journey_metrics(store: Store) -> Dict[str, Any]:
    """Touchpoints from first contact to recall."""
    conn = store._get_conn()
    patients = store.list_patients()
    total = len(patients)

    if total == 0:
        return {
            "total_patients": 0,
            "avg_touchpoints": 0,
            "patients_with_screening": 0,
            "patients_with_treatment": 0,
            "patients_with_billing": 0,
            "journey_completion_rate": 0.0,
        }

    # Count touchpoints per patient
    touchpoints: Dict[int, int] = defaultdict(int)
    stages: Dict[str, int] = {"screening": 0, "radiology": 0, "treatment": 0, "billing": 0}

    for table, stage in [
        ("screening_records", "screening"),
        ("radiology_records", "radiology"),
        ("treatment_records", "treatment"),
        ("billing_records", "billing"),
    ]:
        rows = conn.execute(
            f"SELECT DISTINCT patient_id FROM {table} WHERE patient_id IS NOT NULL"
        ).fetchall()
        pids = {r[0] for r in rows}
        stages[stage] = len(pids)
        for pid in pids:
            touchpoints[pid] += 1

    avg_touchpoints = round(sum(touchpoints.values()) / max(len(touchpoints), 1), 1)

    # Full journey = screening + treatment + billing
    full_journey = sum(1 for tp in touchpoints.values() if tp >= 3)
    journey_completion_rate = _safe_pct(full_journey, total)

    return {
        "total_patients": total,
        "avg_touchpoints": avg_touchpoints,
        "patients_with_screening": stages["screening"],
        "patients_with_treatment": stages["treatment"],
        "patients_with_billing": stages["billing"],
        "journey_completion_rate": journey_completion_rate,
        "full_journey_patients": full_journey,
    }


def get_nps_score(store: Store) -> Dict[str, Any]:
    """Net Promoter Score placeholder — needs feedback collection."""
    return {
        "score": None,
        "promoters": 0,
        "passives": 0,
        "detractors": 0,
        "total_responses": 0,
        "message": "NPS tracking not yet configured. Enable post-treatment feedback to collect scores.",
    }


def get_communication_preferences(store: Store) -> Dict[str, Any]:
    """SMS vs email vs phone effectiveness based on marketing content data."""
    content = store.list_marketing_content()

    channels: Dict[str, int] = {"sms": 0, "email": 0, "phone": 0, "social": 0}
    for item in content:
        platform = (item.get("platform", "") or "").lower()
        if "sms" in platform or "text" in platform:
            channels["sms"] += 1
        elif "email" in platform:
            channels["email"] += 1
        elif "phone" in platform or "call" in platform:
            channels["phone"] += 1
        else:
            channels["social"] += 1

    total = sum(channels.values())

    return {
        "channels": channels,
        "total_communications": total,
        "effectiveness": {
            k: _safe_pct(v, total) for k, v in channels.items()
        },
        "recommendation": "SMS has typically 98% open rate vs 20% for email. Consider SMS-first for recalls.",
    }


# ── AI Recommendations Engine ────────────────────────────────────

def generate_recommendations(store: Store) -> List[Dict[str, Any]]:
    """Analyze ALL available data and return prioritized recommendations.

    Each recommendation includes: id, category, priority, title, description,
    impact, action, evidence.
    """
    recommendations: List[Dict[str, Any]] = []

    # Gather all data
    dashboard = get_practice_dashboard(store)
    revenue_cat = get_revenue_by_category(store)
    scheduling = get_scheduling_efficiency(store)
    acceptance = get_treatment_acceptance(store)
    recall = get_recall_effectiveness(store)
    acquisition = get_patient_acquisition(store)
    busiest = get_busiest_times(store)
    cpd = get_cpd_status(store)
    journey = get_patient_journey_metrics(store)
    profile = store.get_practice_profile()
    members = store.list_team_members()
    dentists = [m for m in members if m.get("role") == "dentist"]

    # ── Revenue Optimization ──────────────────────────────────

    # Treatment acceptance for high-value plans
    high_value = acceptance.get("by_fee_range", {}).get("over_1000", {})
    if high_value.get("presented", 0) > 0 and high_value.get("rate", 100) < 60:
        recommendations.append({
            "id": _rec_id("rev-acceptance-high"),
            "category": "revenue",
            "priority": "high",
            "title": "High-value treatment acceptance is low",
            "description": f"Treatment plans over {_pounds()}1,000 have only {high_value['rate']}% acceptance rate "
                           f"({high_value['accepted']}/{high_value['presented']} plans). "
                           f"National average is ~65%. Offer 0% finance options to improve uptake.",
            "impact": f"Estimated {_pounds()}{high_value['presented'] * 500:.0f} additional annual revenue if acceptance improves to 65%",
            "action": "Partner with a dental finance provider (e.g., Chrysalis, Tabeo) to offer 0% payment plans",
            "evidence": f"{high_value['presented']} plans presented, {high_value['accepted']} accepted",
        })

    mid_value = acceptance.get("by_fee_range", {}).get("500_1000", {})
    if mid_value.get("presented", 0) > 0 and mid_value.get("rate", 100) < 60:
        recommendations.append({
            "id": _rec_id("rev-acceptance-mid"),
            "category": "revenue",
            "priority": "medium",
            "title": f"Treatment plans {_pounds()}500-{_pounds()}1,000 have {mid_value['rate']}% acceptance",
            "description": f"Only {mid_value['accepted']} of {mid_value['presented']} mid-range treatment plans accepted. "
                           f"Consider improving case presentation and offering flexible payment.",
            "impact": f"Potential {_pounds()}{mid_value['presented'] * 200:.0f} recovery with better conversion",
            "action": "Train team on case presentation. Use before/after photos and visual treatment plans.",
            "evidence": f"Acceptance rate: {mid_value['rate']}% for {_pounds()}500-{_pounds()}1,000 band",
        })

    # Revenue category imbalance
    rev_breakdown = revenue_cat.get("breakdown", {})
    private_rev = rev_breakdown.get("private", 0)
    nhs_rev = rev_breakdown.get("nhs", 0)
    total_rev = revenue_cat.get("total", 0)

    if total_rev > 0 and private_rev > 0:
        private_pct = _safe_pct(private_rev, total_rev)
        if private_pct < 30 and nhs_rev > 0:
            recommendations.append({
                "id": _rec_id("rev-private-growth"),
                "category": "revenue",
                "priority": "high",
                "title": "Private revenue is only {:.0f}% of total".format(private_pct),
                "description": f"Private treatments account for {_pounds()}{private_rev:,.2f} "
                               f"({private_pct:.0f}% of {_pounds()}{total_rev:,.2f} total). "
                               f"Private hygiene appointments typically yield 3x higher margins than NHS.",
                "impact": f"Shifting 10% of capacity to private could add {_pounds()}{total_rev * 0.1:,.0f} annually",
                "action": "Expand private hygiene availability. Promote cosmetic and whitening services.",
                "evidence": f"NHS: {_pounds()}{nhs_rev:,.2f}, Private: {_pounds()}{private_rev:,.2f}",
            })

    # Revenue trend
    if dashboard.get("revenue_change_pct", 0) < -10:
        change = dashboard["revenue_change_pct"]
        recommendations.append({
            "id": _rec_id("rev-declining"),
            "category": "revenue",
            "priority": "high",
            "title": f"Revenue down {abs(change):.1f}% vs last month",
            "description": f"MTD revenue is {_pounds()}{dashboard['revenue_mtd']:,.2f} compared to "
                           f"{_pounds()}{dashboard['revenue_last_month']:,.2f} last month. "
                           f"Investigate whether this is seasonal or indicates patient loss.",
            "impact": "Continued decline could reduce annual revenue significantly",
            "action": "Review appointment book fill rate and recent cancellation patterns.",
            "evidence": f"MTD: {_pounds()}{dashboard['revenue_mtd']:,.2f}, Last month: {_pounds()}{dashboard['revenue_last_month']:,.2f}",
        })

    # ── Efficiency ────────────────────────────────────────────

    if scheduling.get("utilization_rate", 0) < 70 and scheduling.get("theoretical_capacity_30d", 0) > 0:
        util = scheduling["utilization_rate"]
        capacity = scheduling["theoretical_capacity_30d"]
        completed = scheduling["completed_appointments_30d"]
        recommendations.append({
            "id": _rec_id("eff-utilization"),
            "category": "efficiency",
            "priority": "high",
            "title": f"Chair utilization at {util:.0f}% — target 85%+",
            "description": f"Only {completed} of {capacity} theoretical appointments filled in the last 30 days. "
                           f"Each empty slot costs approximately {_pounds()}80-{_pounds()}150.",
            "impact": f"Filling to 85% could add {_pounds()}{(capacity * 0.85 - completed) * 100:,.0f} monthly revenue",
            "action": "Implement short-notice list, evening/Saturday sessions, and recall automation.",
            "evidence": f"{completed}/{capacity} slots used (30 days)",
        })

    # Busiest times analysis
    grid = busiest.get("grid", {})
    total_activity = sum(sum(slots.values()) for slots in grid.values())
    if total_activity > 0:
        for day in grid:
            for slot in grid[day]:
                if grid[day][slot] == 0 and day in ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]:
                    recommendations.append({
                        "id": _rec_id(f"eff-empty-{day}-{slot}"),
                        "category": "efficiency",
                        "priority": "low",
                        "title": f"{day} {slot.lower()} has zero recorded activity",
                        "description": f"0 patient records found for {day} {slot.lower()}s. "
                                       f"If this is an open slot, consider promotional pricing to fill it.",
                        "impact": f"1 additional session per week = {_pounds()}{80 * 4:,} monthly",
                        "action": f"Run targeted promotion for {day} {slot.lower()} appointments.",
                        "evidence": f"0 of {total_activity} total records fell in {day} {slot.lower()} time window",
                    })
                    break  # One recommendation per empty slot is enough
            else:
                continue
            break  # Only one empty-slot recommendation total

    # ── Clinical Quality ─────────────────────────────────────

    lapsed = recall.get("lapsed_12m", 0)
    if lapsed > 0:
        recommendations.append({
            "id": _rec_id("clinical-lapsed"),
            "category": "clinical",
            "priority": "high" if lapsed > 10 else "medium",
            "title": f"{lapsed} patients lapsed for 12+ months — urgent recall needed",
            "description": f"{lapsed} patients have not been seen in over 12 months. "
                           f"These patients may have undiagnosed conditions and represent lost revenue.",
            "impact": f"Recovering {min(lapsed, 20)} patients = ~{_pounds()}{min(lapsed, 20) * 120:,} in check-up revenue",
            "action": "Send personalised recall letters/SMS to lapsed patients. Offer a welcome-back check-up.",
            "evidence": f"{lapsed} patients last seen 12+ months ago",
        })

    recall_rate = recall.get("recall_rate_7m", 0)
    if recall_rate < 60 and recall.get("total_patients", 0) > 0:
        recommendations.append({
            "id": _rec_id("clinical-recall-rate"),
            "category": "clinical",
            "priority": "high",
            "title": f"Recall rate at {recall_rate:.0f}% — industry target is 70%+",
            "description": f"Only {recall_rate:.0f}% of patients returned within 7 months. "
                           f"Improving recall drives both clinical outcomes and revenue stability.",
            "impact": f"Each 10% improvement = ~{_pounds()}{recall.get('total_patients', 0) * 12:,} additional annual revenue",
            "action": "Automate recall reminders at 5 months with SMS + email sequence.",
            "evidence": f"{recall.get('returned_7m', 0)}/{recall.get('total_patients', 0)} patients returned within 7 months",
        })

    # ── Patient Experience ───────────────────────────────────

    if journey.get("journey_completion_rate", 0) < 50 and journey.get("total_patients", 0) > 5:
        rate = journey["journey_completion_rate"]
        recommendations.append({
            "id": _rec_id("px-journey"),
            "category": "patient_experience",
            "priority": "medium",
            "title": f"Only {rate:.0f}% of patients complete the full care journey",
            "description": f"Only {journey.get('full_journey_patients', 0)} of {journey['total_patients']} patients "
                           f"progress through screening, treatment, and billing. "
                           f"Patients may be dropping off after initial consultation.",
            "impact": "Improving journey completion by 20% directly increases case value",
            "action": "Review follow-up process. Call patients who had screening but no treatment booked.",
            "evidence": f"Journey completion rate: {rate:.0f}% ({journey.get('full_journey_patients', 0)}/{journey['total_patients']})",
        })

    new_patients = acquisition.get("new_this_month", 0)
    if new_patients == 0 and dashboard.get("total_patients", 0) > 0:
        recommendations.append({
            "id": _rec_id("px-no-new-patients"),
            "category": "patient_experience",
            "priority": "high",
            "title": "No new patients this month",
            "description": "Zero new patients registered this month. "
                           "Healthy practices see 15-30 new patients monthly depending on size.",
            "impact": f"Each new patient is worth ~{_pounds()}500-{_pounds()}1,000 lifetime value",
            "action": "Review Google Business listing, ask existing patients for referrals, run a new-patient offer.",
            "evidence": f"0 new patients vs {dashboard.get('total_patients', 0)} total",
        })

    # ── Marketing ────────────────────────────────────────────

    content = store.list_marketing_content()
    if len(content) == 0:
        recommendations.append({
            "id": _rec_id("mkt-no-content"),
            "category": "marketing",
            "priority": "medium",
            "title": "No marketing content created yet",
            "description": "No social media posts or marketing content found. "
                           "Practices with consistent social posting see 25% more new patient enquiries.",
            "impact": f"Regular posting could bring 5-10 additional new patients per month",
            "action": "Use the Marketing tab to generate and schedule posts. Start with 2-3 per week.",
            "evidence": "0 marketing items in the system",
        })

    # ── Compliance ───────────────────────────────────────────

    cpd_shortfalls = cpd.get("members_with_shortfall", 0)
    if cpd_shortfalls > 0:
        recommendations.append({
            "id": _rec_id("comp-cpd"),
            "category": "compliance",
            "priority": "high" if cpd_shortfalls > 2 else "medium",
            "title": f"{cpd_shortfalls} staff member{'s' if cpd_shortfalls > 1 else ''} {'have' if cpd_shortfalls > 1 else 'has'} CPD shortfalls",
            "description": f"{cpd_shortfalls} team members are behind on their Continuing Professional Development hours. "
                           f"GDC requires documented CPD for all registered dental professionals.",
            "impact": "Non-compliance can lead to GDC fitness to practise proceedings",
            "action": "Book verifiable CPD courses. Use the CPD status panel to track progress.",
            "evidence": f"{cpd_shortfalls} members below required hours",
        })

    # CQC / DSPT checks
    if profile:
        cqc = profile.get("cqc_registration", "")
        dspt = profile.get("dspt_status", "")

        if not cqc:
            recommendations.append({
                "id": _rec_id("comp-cqc"),
                "category": "compliance",
                "priority": "high",
                "title": "CQC registration not recorded",
                "description": "No CQC registration number found in your practice profile. "
                               "All dental practices in England must be registered with CQC.",
                "impact": "Operating without CQC registration is a criminal offence",
                "action": "Enter your CQC registration number in the Enterprise tab practice profile.",
                "evidence": "CQC registration field is empty",
            })

        if dspt and dspt.lower() not in ("complete", "compliant", "published"):
            recommendations.append({
                "id": _rec_id("comp-dspt"),
                "category": "compliance",
                "priority": "medium",
                "title": f"DSPT self-assessment status: {dspt}",
                "description": f"Your Data Security and Protection Toolkit status is '{dspt}'. "
                               f"NHS dental practices must complete DSPT annually by 30 June.",
                "impact": "Incomplete DSPT can affect NHS contract payments",
                "action": "Complete outstanding DSPT items at dsptoolkit.nhs.uk",
                "evidence": f"DSPT status: {dspt}",
            })

    # Sort by priority
    priority_order = {"high": 0, "medium": 1, "low": 2}
    recommendations.sort(key=lambda r: priority_order.get(r.get("priority", "low"), 3))

    return recommendations


def _rec_id(slug: str) -> str:
    """Generate a stable recommendation ID."""
    return f"rec-{slug}"


def _pounds() -> str:
    """Return the pound sign."""
    return "\u00a3"
