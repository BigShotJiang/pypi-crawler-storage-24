"""Onboarding flow logic for DentalAI Pro.

Manages the 5-step onboarding wizard:
  1. Practice Setup
  2. Regulatory Profile
  3. Clinical Configuration
  4. Team Setup
  5. Go Live

All data is persisted in SQLite via the Store class.
"""

from __future__ import annotations

import time
from typing import Any, Dict, List, Optional

from .compliance_regs import get_compliance_checklist, get_regulations_by_country


def get_regulatory_fields(country: str) -> Dict[str, Any]:
    """Return the regulatory fields required for a given country."""
    country = country.lower().strip()
    fields: Dict[str, Any] = {
        "uk": {
            "country": "uk",
            "label": "UK Regulatory Requirements",
            "fields": [
                {"key": "cqc_registration", "label": "CQC Registration Number", "required": True, "type": "text", "placeholder": "e.g., 1-123456789"},
                {"key": "gdc_numbers", "label": "GDC Numbers (all clinicians)", "required": True, "type": "text", "placeholder": "Enter in Team Setup step"},
                {"key": "nhs_performer_number", "label": "NHS BSA Performer Number", "required": False, "type": "text", "placeholder": "For NHS/Mixed practices"},
                {"key": "dspt_status", "label": "DSPT Status", "required": True, "type": "select", "options": ["Not Started", "Approaching Standards", "Standards Met", "Standards Exceeded"]},
                {"key": "caldicott_guardian", "label": "Caldicott Guardian Name", "required": True, "type": "text", "placeholder": "Named Caldicott Guardian"},
                {"key": "safeguarding_lead", "label": "Safeguarding Lead Name", "required": True, "type": "text", "placeholder": "Named Safeguarding Lead"},
                {"key": "irmer_rpa", "label": "Radiation Protection Adviser (RPA)", "required": True, "type": "text", "placeholder": "Name of appointed RPA"},
                {"key": "indemnity_provider", "label": "Indemnity Insurance Provider", "required": True, "type": "text", "placeholder": "e.g., DDU, MDU, Dental Protection"},
            ],
        },
        "us": {
            "country": "us",
            "label": "US Regulatory Requirements",
            "fields": [
                {"key": "state_license", "label": "State Dental Board License Numbers", "required": True, "type": "text", "placeholder": "Enter per clinician in Team Setup"},
                {"key": "dea_numbers", "label": "DEA Numbers", "required": True, "type": "text", "placeholder": "Enter per provider in Team Setup"},
                {"key": "npi_numbers", "label": "NPI Numbers", "required": True, "type": "text", "placeholder": "Enter per provider in Team Setup"},
                {"key": "osha_officer", "label": "OSHA Compliance Officer", "required": True, "type": "text", "placeholder": "Named compliance officer"},
                {"key": "hipaa_officer", "label": "HIPAA Privacy Officer", "required": True, "type": "text", "placeholder": "Named privacy officer"},
                {"key": "hipaa_security_officer", "label": "HIPAA Security Officer", "required": True, "type": "text", "placeholder": "Named security officer"},
                {"key": "state", "label": "Primary State", "required": True, "type": "text", "placeholder": "e.g., California, New York"},
            ],
        },
        "eu": {
            "country": "eu",
            "label": "EU Regulatory Requirements",
            "fields": [
                {"key": "mdr_status", "label": "MDR Compliance Status", "required": True, "type": "select", "options": ["Not Applicable", "Assessment Pending", "Compliant", "Non-Compliant"]},
                {"key": "national_council_reg", "label": "National Dental Council Registration", "required": True, "type": "text", "placeholder": "Registration number"},
                {"key": "member_state", "label": "EU Member State", "required": True, "type": "text", "placeholder": "e.g., Germany, France, Netherlands"},
                {"key": "dpo_name", "label": "Data Protection Officer", "required": False, "type": "text", "placeholder": "If required under GDPR"},
            ],
        },
        "au": {
            "country": "au",
            "label": "Australia Regulatory Requirements",
            "fields": [
                {"key": "ahpra_numbers", "label": "AHPRA Registration Numbers", "required": True, "type": "text", "placeholder": "Enter per clinician in Team Setup"},
                {"key": "dental_board_reg", "label": "Dental Board of Australia Registration", "required": True, "type": "text", "placeholder": "Registration number"},
                {"key": "state_territory", "label": "Primary State/Territory", "required": True, "type": "text", "placeholder": "e.g., NSW, VIC, QLD"},
                {"key": "pii_provider", "label": "Professional Indemnity Insurance Provider", "required": True, "type": "text", "placeholder": "Insurance provider name"},
            ],
        },
        "ca": {
            "country": "ca",
            "label": "Canada Regulatory Requirements",
            "fields": [
                {"key": "provincial_reg", "label": "Provincial Registration Number", "required": True, "type": "text", "placeholder": "Provincial regulatory authority number"},
                {"key": "province", "label": "Province/Territory", "required": True, "type": "text", "placeholder": "e.g., Ontario, British Columbia"},
                {"key": "ndeb_cert", "label": "NDEB Certification", "required": True, "type": "select", "options": ["Yes", "No", "In Progress"]},
                {"key": "phipa_pipeda_ack", "label": "PHIPA/PIPEDA Acknowledgment", "required": True, "type": "select", "options": ["Acknowledged", "Not Acknowledged"]},
            ],
        },
    }
    return fields.get(country, {
        "country": country,
        "label": "Regulatory Requirements",
        "fields": [
            {"key": "registration_number", "label": "Dental Registration Number", "required": True, "type": "text", "placeholder": "Registration number"},
        ],
    })


def get_clinical_config_options() -> Dict[str, Any]:
    """Return the clinical configuration options for Step 3."""
    return {
        "specialties": [
            {"key": "general", "label": "General Dentistry"},
            {"key": "orthodontics", "label": "Orthodontics"},
            {"key": "periodontics", "label": "Periodontics"},
            {"key": "endodontics", "label": "Endodontics"},
            {"key": "oral_surgery", "label": "Oral Surgery"},
            {"key": "pediatric", "label": "Pediatric Dentistry"},
            {"key": "prosthodontics", "label": "Prosthodontics"},
            {"key": "oral_medicine", "label": "Oral Medicine"},
            {"key": "dental_public_health", "label": "Dental Public Health"},
            {"key": "special_care", "label": "Special Care Dentistry"},
        ],
        "equipment": [
            {"key": "cbct", "label": "CBCT Scanner"},
            {"key": "panoramic", "label": "Panoramic X-ray (OPG)"},
            {"key": "intraoral_scanner", "label": "Intraoral Scanner"},
            {"key": "cadcam", "label": "CAD/CAM System"},
            {"key": "laser", "label": "Dental Laser"},
            {"key": "digital_xray", "label": "Digital X-ray (Periapical)"},
            {"key": "cephalometric", "label": "Cephalometric X-ray"},
            {"key": "microscope", "label": "Operating Microscope"},
            {"key": "piezo_surgery", "label": "Piezo Surgery Unit"},
            {"key": "nitrous", "label": "Nitrous Oxide Sedation"},
        ],
        "treatment_types": [
            {"key": "implants", "label": "Dental Implants"},
            {"key": "sedation_iv", "label": "IV Sedation"},
            {"key": "sedation_inhalation", "label": "Inhalation Sedation"},
            {"key": "orthodontics_fixed", "label": "Fixed Orthodontics"},
            {"key": "orthodontics_clear", "label": "Clear Aligners"},
            {"key": "cosmetic", "label": "Cosmetic Dentistry"},
            {"key": "whitening", "label": "Teeth Whitening"},
            {"key": "veneers", "label": "Porcelain Veneers"},
            {"key": "full_mouth_rehab", "label": "Full Mouth Rehabilitation"},
            {"key": "sleep_dentistry", "label": "Sleep Dentistry/Apnoea"},
            {"key": "tmj", "label": "TMJ/Orofacial Pain"},
            {"key": "domiciliary", "label": "Domiciliary Care"},
        ],
        "referral_network": [
            {"key": "omfs", "label": "Oral & Maxillofacial Surgery"},
            {"key": "oral_medicine", "label": "Oral Medicine"},
            {"key": "oncology", "label": "Head & Neck Oncology"},
            {"key": "ent", "label": "ENT"},
            {"key": "dermatology", "label": "Dermatology"},
            {"key": "paediatric", "label": "Paediatric Dentistry"},
            {"key": "restorative", "label": "Restorative Dentistry"},
            {"key": "orthodontics", "label": "Orthodontics"},
        ],
    }


def validate_practice_data(data: Dict[str, Any]) -> Dict[str, Any]:
    """Validate practice profile data, return errors dict."""
    errors: Dict[str, str] = {}
    if not data.get("name", "").strip():
        errors["name"] = "Practice name is required"
    if not data.get("country", "").strip():
        errors["country"] = "Country is required"
    if not data.get("practice_type", "").strip():
        errors["practice_type"] = "Practice type is required"
    return {"valid": len(errors) == 0, "errors": errors}


def validate_team_member(data: Dict[str, Any]) -> Dict[str, Any]:
    """Validate a team member entry."""
    errors: Dict[str, str] = {}
    if not data.get("name", "").strip():
        errors["name"] = "Team member name is required"
    if not data.get("role", "").strip():
        errors["role"] = "Role is required"
    if not data.get("access_level", "").strip():
        errors["access_level"] = "Access level is required"
    return {"valid": len(errors) == 0, "errors": errors}


def generate_golive_checklist(country: str, practice_type: str = "") -> List[Dict[str, Any]]:
    """Generate a go-live compliance checklist based on country and practice type."""
    checklist = get_compliance_checklist(country)

    # Add universal items
    universal = [
        {
            "id": "GOLIVE-001",
            "category": "Data Protection",
            "title": "Data Protection Agreement Signed",
            "description": "Practice representative must acknowledge data processing terms.",
            "frequency": "one-time",
            "evidence_needed": "Signed agreement",
            "how_dentalai_helps": "Digital agreement with audit trail.",
        },
        {
            "id": "GOLIVE-002",
            "category": "System Setup",
            "title": "All Team Members Added",
            "description": "Every clinician and staff member should be registered in the system.",
            "frequency": "one-time",
            "evidence_needed": "Complete team roster in system",
            "how_dentalai_helps": "Team management dashboard shows completeness.",
        },
        {
            "id": "GOLIVE-003",
            "category": "System Setup",
            "title": "Practice Profile Complete",
            "description": "All practice details, regulatory information, and clinical configuration entered.",
            "frequency": "one-time",
            "evidence_needed": "Completed onboarding wizard",
            "how_dentalai_helps": "Onboarding progress tracker.",
        },
        {
            "id": "GOLIVE-004",
            "category": "Training",
            "title": "Key Staff Trained on DentalAI Pro",
            "description": "At least one administrator and one clinician have completed the system walkthrough.",
            "frequency": "one-time",
            "evidence_needed": "Walkthrough completion record",
            "how_dentalai_helps": "Built-in interactive tutorial.",
        },
    ]

    # Add NHS-specific items for UK NHS/Mixed practices
    if country == "uk" and practice_type in ("nhs", "mixed"):
        universal.extend([
            {
                "id": "GOLIVE-NHS-001",
                "category": "NHS Setup",
                "title": "NHS Contract Number Configured",
                "description": "NHS contract number linked to enable UDA tracking and FP17 form helper.",
                "frequency": "one-time",
                "evidence_needed": "Contract number in system",
                "how_dentalai_helps": "Contract performance dashboard.",
            },
            {
                "id": "GOLIVE-NHS-002",
                "category": "NHS Setup",
                "title": "Performer Numbers Assigned",
                "description": "NHS BSA performer number entered for each NHS-performing dentist.",
                "frequency": "one-time",
                "evidence_needed": "Performer numbers in team profiles",
                "how_dentalai_helps": "FP17 auto-population.",
            },
        ])

    return universal + checklist[:15]  # Universal + top 15 regulatory items


def calculate_onboarding_progress(status: Dict[str, Any]) -> Dict[str, Any]:
    """Calculate overall onboarding progress from status record."""
    steps = [
        ("practice_complete", "Practice Setup"),
        ("regulatory_complete", "Regulatory Profile"),
        ("clinical_complete", "Clinical Configuration"),
        ("team_complete", "Team Setup"),
        ("golive_complete", "Go Live"),
    ]
    completed = sum(1 for key, _ in steps if status.get(key, 0))
    return {
        "current_step": status.get("step", 1),
        "completed_steps": completed,
        "total_steps": 5,
        "percentage": int((completed / 5) * 100),
        "steps": [
            {"step": i + 1, "name": name, "complete": bool(status.get(key, 0))}
            for i, (key, name) in enumerate(steps)
        ],
        "is_complete": completed == 5,
    }
