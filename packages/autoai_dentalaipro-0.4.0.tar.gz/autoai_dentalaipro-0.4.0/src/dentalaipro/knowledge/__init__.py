"""Clinical knowledge bases for DentalAI Pro."""
