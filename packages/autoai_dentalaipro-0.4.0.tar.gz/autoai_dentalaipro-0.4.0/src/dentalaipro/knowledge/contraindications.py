"""40 key contraindications in dentistry — drug interactions and medical conditions.

Each entry: condition_or_drug, dental_concern, what_to_do, when_to_refer, severity.
"""

from __future__ import annotations

from typing import Any, Dict, List

CONTRAINDICATIONS: List[Dict[str, Any]] = [
    # ── CARDIOVASCULAR (8) ────────────────────────────────────────
    {
        "condition_or_drug": "Warfarin (Coumadin)",
        "dental_concern": "Excessive bleeding during surgery",
        "what_to_do": "Check INR within 72 hours. INR <3.5: proceed with local hemostatic measures (suture, gelfoam, tranexamic acid rinse). Do NOT stop warfarin.",
        "when_to_refer": "INR >3.5 or multiple surgical extractions — consult cardiologist",
        "severity": "moderate",
    },
    {
        "condition_or_drug": "Direct Oral Anticoagulants (DOACs — apixaban, rivaroxaban, dabigatran)",
        "dental_concern": "Bleeding risk, no reliable reversal (except idarucizumab for dabigatran)",
        "what_to_do": "Simple extractions: usually no interruption. Complex surgery: may skip morning dose on day of procedure after consulting physician.",
        "when_to_refer": "Extensive surgery, multiple extractions — consult hematologist/cardiologist",
        "severity": "moderate",
    },
    {
        "condition_or_drug": "Dual Antiplatelet Therapy (Aspirin + Clopidogrel)",
        "dental_concern": "Bleeding after extraction; NEVER stop within 12 months of cardiac stent",
        "what_to_do": "Proceed with local hemostasis. Never stop aspirin for dental procedures. Never stop clopidogrel without cardiologist approval.",
        "when_to_refer": "Within 12 months of stent placement — consult cardiologist before any extractions",
        "severity": "high",
    },
    {
        "condition_or_drug": "Infective Endocarditis Risk (prosthetic valves, prior IE, certain CHD)",
        "dental_concern": "Bacteremia from dental procedures causing endocarditis",
        "what_to_do": "Antibiotic prophylaxis: amoxicillin 2g PO 30-60 min pre-procedure for all procedures involving gingival manipulation or perforation of oral mucosa.",
        "when_to_refer": "If unsure of cardiac status — verify with cardiologist",
        "severity": "high",
    },
    {
        "condition_or_drug": "Uncontrolled Hypertension (>180/110)",
        "dental_concern": "Hypertensive crisis with epinephrine, stroke risk",
        "what_to_do": "Defer elective treatment. Limit epinephrine to 2 cartridges. Reduce stress. Monitor BP before and during.",
        "when_to_refer": "BP >180/110 at appointment — refer for medical management, reschedule",
        "severity": "high",
    },
    {
        "condition_or_drug": "Recent MI (<6 months)",
        "dental_concern": "Reinfarction risk with stress and epinephrine",
        "what_to_do": "Defer elective treatment for 6 months. Emergency treatment only with physician clearance, minimal epinephrine, stress reduction protocol.",
        "when_to_refer": "Always consult cardiologist before any dental treatment within 6 months of MI",
        "severity": "critical",
    },
    {
        "condition_or_drug": "Heart Failure (NYHA III-IV)",
        "dental_concern": "Cannot tolerate supine position, fluid overload, arrhythmia risk",
        "what_to_do": "Semi-upright position, short appointments, minimize epinephrine, supplemental O2 if SpO2 <95%.",
        "when_to_refer": "NYHA IV — hospital-based dentistry only",
        "severity": "high",
    },
    {
        "condition_or_drug": "Pacemaker/ICD",
        "dental_concern": "Electromagnetic interference (EMI) from ultrasonic scalers, electrosurgery",
        "what_to_do": "Avoid ultrasonic scalers and electrosurgery. Manual scaling OK. Short bursts if piezoelectric unit used.",
        "when_to_refer": "Consult cardiologist if elective surgery or complex procedure needed",
        "severity": "moderate",
    },

    # ── BLEEDING DISORDERS (3) ────────────────────────────────────
    {
        "condition_or_drug": "Hemophilia A or B",
        "dental_concern": "Uncontrolled bleeding after extraction or surgery",
        "what_to_do": "Coordinate with hematologist for factor replacement BEFORE surgery. Factor VIII or IX levels >50% for extractions. Antifibrinolytic (tranexamic acid) post-op.",
        "when_to_refer": "Always coordinate with hematologist before surgical procedures",
        "severity": "critical",
    },
    {
        "condition_or_drug": "Von Willebrand Disease",
        "dental_concern": "Prolonged bleeding, especially mucosal",
        "what_to_do": "DDAVP for Type 1 before procedure. Factor replacement for Type 2/3. Local hemostatic measures. Tranexamic acid rinse 5% QID for 5-7 days.",
        "when_to_refer": "Hematologist for pre-procedural management plan",
        "severity": "high",
    },
    {
        "condition_or_drug": "Thrombocytopenia (platelets <50,000)",
        "dental_concern": "Spontaneous gingival bleeding, uncontrolled surgical bleeding",
        "what_to_do": "Platelets >50,000: routine procedures OK with local hemostasis. <50,000: defer surgery. <20,000: risk of spontaneous bleeding.",
        "when_to_refer": "Platelet transfusion may be needed pre-surgery — consult hematologist",
        "severity": "high",
    },

    # ── ENDOCRINE (4) ─────────────────────────────────────────────
    {
        "condition_or_drug": "Uncontrolled Diabetes (HbA1c >8%)",
        "dental_concern": "Delayed healing, infection risk, periodontal disease progression",
        "what_to_do": "Morning appointments, ensure patient ate and took medication. Have glucose source ready. Defer elective surgery. Aggressive perio maintenance.",
        "when_to_refer": "Consult physician to optimize control before elective surgery",
        "severity": "moderate",
    },
    {
        "condition_or_drug": "Adrenal Insufficiency / Chronic Corticosteroid Use",
        "dental_concern": "Adrenal crisis under stress — hypotension, shock",
        "what_to_do": "Supplemental steroids for major procedures: hydrocortisone 100mg IV/IM before surgery. Routine procedures usually no supplement needed if <20mg prednisone/day.",
        "when_to_refer": "Consult endocrinologist if major surgery planned or dose >20mg prednisone equivalent",
        "severity": "high",
    },
    {
        "condition_or_drug": "Hyperthyroidism (uncontrolled)",
        "dental_concern": "Thyroid storm risk with epinephrine, tachycardia, hypertension",
        "what_to_do": "Defer elective treatment until medically controlled. If emergency: no epinephrine, minimize stress, monitor vitals.",
        "when_to_refer": "Refer for thyroid control before any elective dental treatment",
        "severity": "high",
    },
    {
        "condition_or_drug": "Pregnancy",
        "dental_concern": "Teratogenicity of drugs, fetal risk from radiation, supine hypotension",
        "what_to_do": "2nd trimester ideal for treatment. Safe: lidocaine with epi, amoxicillin, acetaminophen. Avoid: NSAIDs (3rd tri), tetracycline, nitrous (1st tri), benzodiazepines. Radiographs safe with shielding.",
        "when_to_refer": "Complex surgery → defer to postpartum. Consult OB for high-risk pregnancies.",
        "severity": "moderate",
    },

    # ── BONE METABOLISM (4) ───────────────────────────────────────
    {
        "condition_or_drug": "Oral Bisphosphonates (alendronate, risedronate) <4 years",
        "dental_concern": "Low risk of MRONJ but not zero",
        "what_to_do": "Routine care including extractions usually OK. Inform patient of low risk. Atraumatic technique. Consider drug holiday only if >4 years or with corticosteroids.",
        "when_to_refer": "If extensive surgery needed — consult prescribing physician",
        "severity": "low",
    },
    {
        "condition_or_drug": "IV Bisphosphonates (zoledronic acid — oncology)",
        "dental_concern": "HIGH risk of MRONJ (1-15%), exposed necrotic bone",
        "what_to_do": "AVOID extractions if possible. Root canal preferred over extraction. If extraction unavoidable: perioperative antibiotics, minimize trauma, primary closure.",
        "when_to_refer": "ALWAYS consult oncologist. Comprehensive dental clearance before starting IV bisphosphonates.",
        "severity": "critical",
    },
    {
        "condition_or_drug": "Denosumab (Prolia/Xgeva)",
        "dental_concern": "MRONJ risk similar to IV bisphosphonates for Xgeva (oncology), lower for Prolia",
        "what_to_do": "Prolia (osteoporosis): moderate caution, similar to oral BPs. Xgeva (oncology): treat as high-risk like IV BPs.",
        "when_to_refer": "Consult prescribing physician for surgical procedures",
        "severity": "high",
    },
    {
        "condition_or_drug": "Head and Neck Radiation History",
        "dental_concern": "Osteoradionecrosis risk, xerostomia, rampant caries",
        "what_to_do": "Custom fluoride trays daily for life. Avoid extraction in irradiated field. If extraction necessary: HBO 20 dives pre + 10 post. Artificial saliva.",
        "when_to_refer": "Any surgery in irradiated field — consult radiation oncologist, consider HBO",
        "severity": "critical",
    },

    # ── DRUG INTERACTIONS (8) ─────────────────────────────────────
    {
        "condition_or_drug": "MAO Inhibitors (phenelzine, tranylcypromine)",
        "dental_concern": "Hypertensive crisis with epinephrine (indirect sympathomimetic)",
        "what_to_do": "Limit epinephrine to 2 cartridges (0.036mg). Aspirate carefully. No levonordefrin. Monitor BP.",
        "when_to_refer": "If uncontrolled hypertension during treatment — emergency medical care",
        "severity": "high",
    },
    {
        "condition_or_drug": "Tricyclic Antidepressants (amitriptyline, nortriptyline)",
        "dental_concern": "Potentiation of epinephrine, xerostomia, orthostatic hypotension",
        "what_to_do": "Limit epinephrine to 2 cartridges. Rise slowly from chair. Manage xerostomia (dry mouth increases caries).",
        "when_to_refer": "If significant cardiac arrhythmia — emergency medical care",
        "severity": "moderate",
    },
    {
        "condition_or_drug": "Non-selective Beta Blockers (propranolol)",
        "dental_concern": "Epinephrine causes unopposed alpha stimulation → severe hypertension + reflex bradycardia",
        "what_to_do": "Limit epinephrine to 2 cartridges. Aspirate. Monitor BP and heart rate. Consider mepivacaine 3% (no epi) for short procedures.",
        "when_to_refer": "If hypertensive episode occurs — emergency medical management",
        "severity": "high",
    },
    {
        "condition_or_drug": "Methotrexate (immunosuppression)",
        "dental_concern": "Oral ulcers, myelosuppression, infection risk, delayed healing",
        "what_to_do": "Check CBC before surgery. If WBC <3500 or neutrophils <1500: defer surgery. Treat oral ulcers with topical steroids. May need to hold methotrexate peri-operatively.",
        "when_to_refer": "Consult rheumatologist/oncologist before surgical procedures",
        "severity": "high",
    },
    {
        "condition_or_drug": "Erythromycin / Clarithromycin with Midazolam",
        "dental_concern": "CYP3A4 inhibition → dangerous over-sedation with oral midazolam",
        "what_to_do": "Avoid midazolam sedation in patients on macrolide antibiotics. Use alternative sedation or defer.",
        "when_to_refer": "If over-sedation occurs — emergency management, reversal with flumazenil",
        "severity": "high",
    },
    {
        "condition_or_drug": "NSAIDs with Methotrexate",
        "dental_concern": "NSAIDs reduce renal clearance of methotrexate → toxicity (pancytopenia, mucositis)",
        "what_to_do": "Use acetaminophen for pain instead. If NSAID needed: shortest duration, lowest dose, coordinate with prescriber.",
        "when_to_refer": "If on high-dose methotrexate — consult prescriber before any NSAID",
        "severity": "high",
    },
    {
        "condition_or_drug": "Aspirin/NSAIDs with SSRIs (fluoxetine, sertraline)",
        "dental_concern": "Increased bleeding risk — SSRIs impair platelet function",
        "what_to_do": "Be aware of increased surgical bleeding. Aggressive local hemostasis. Consider tranexamic acid rinse post-extraction.",
        "when_to_refer": "If uncontrolled post-surgical bleeding — medical management",
        "severity": "moderate",
    },
    {
        "condition_or_drug": "Ketoconazole/Itraconazole with Triazolam",
        "dental_concern": "CYP3A4 inhibition → prolonged sedation, respiratory depression",
        "what_to_do": "Avoid triazolam or reduce dose by 75% in patients on azole antifungals. Use alternative sedation.",
        "when_to_refer": "If respiratory depression — emergency management, flumazenil",
        "severity": "high",
    },

    # ── ALLERGY (3) ───────────────────────────────────────────────
    {
        "condition_or_drug": "True Amide Local Anesthetic Allergy (extremely rare)",
        "dental_concern": "Anaphylaxis with lidocaine, articaine, etc.",
        "what_to_do": "True allergy to amides is <1%. Most reactions are vasovagal or epinephrine response. If confirmed: allergy testing, use diphenhydramine 1% as alternative.",
        "when_to_refer": "Allergist for skin testing to confirm. Anaphylaxis → epinephrine + emergency services.",
        "severity": "critical",
    },
    {
        "condition_or_drug": "Penicillin Allergy",
        "dental_concern": "Cannot use amoxicillin for prophylaxis or infection",
        "what_to_do": "Alternatives: clindamycin 600mg, azithromycin 500mg, cephalexin 2g (if not anaphylaxis to penicillin). Cross-reactivity with cephalosporins <2%.",
        "when_to_refer": "If anaphylactic history — avoid all beta-lactams. Consider allergy testing (90% of 'penicillin allergies' are not true allergies).",
        "severity": "moderate",
    },
    {
        "condition_or_drug": "Latex Allergy",
        "dental_concern": "Contact urticaria to anaphylaxis from gloves and rubber dam",
        "what_to_do": "Nitrile gloves only. Non-latex rubber dam or none. Latex-free environment. First appointment of day (less airborne latex).",
        "when_to_refer": "If history of anaphylaxis to latex — hospital-based dentistry with crash cart",
        "severity": "high",
    },

    # ── NEUROLOGICAL / PSYCHIATRIC (3) ────────────────────────────
    {
        "condition_or_drug": "Epilepsy / Seizure Disorder",
        "dental_concern": "Seizure during treatment, gingival hyperplasia (phenytoin)",
        "what_to_do": "Ensure medication compliance. Remove instruments from mouth during seizure. Turn patient on side. Suction. Time seizure — >5min = emergency. Manage gingival overgrowth surgically + OHI.",
        "when_to_refer": "If seizure >5 minutes (status epilepticus) — call emergency services",
        "severity": "moderate",
    },
    {
        "condition_or_drug": "Phenytoin (Dilantin)",
        "dental_concern": "Gingival hyperplasia in 50% of patients, drug interaction with azole antifungals",
        "what_to_do": "Aggressive oral hygiene program. Gingivectomy if severe. Discuss with neurologist about switching to non-hyperplasia-causing AED (levetiracetam).",
        "when_to_refer": "Neurologist consultation for medication change if severe gingival hyperplasia",
        "severity": "moderate",
    },
    {
        "condition_or_drug": "Parkinson Disease",
        "dental_concern": "Difficulty with oral hygiene, dysphagia, drooling, involuntary movements during treatment",
        "what_to_do": "Appointments 60-90 min after medication (peak effect). Short appointments. Rubber dam or gauze throat screen. Electric toothbrush recommended.",
        "when_to_refer": "Severe dyskinesia making treatment impossible — GA may be needed",
        "severity": "moderate",
    },

    # ── LIVER & KIDNEY (3) ────────────────────────────────────────
    {
        "condition_or_drug": "Liver Cirrhosis / Hepatic Failure",
        "dental_concern": "Coagulopathy, altered drug metabolism, infection risk",
        "what_to_do": "Check INR, platelets, CBC before surgery. Reduce doses of hepatically metabolized drugs (lidocaine, diazepam, acetaminophen). Avoid NSAIDs (GI bleed risk). Avoid hepatotoxic drugs.",
        "when_to_refer": "Child-Pugh C: hospital-based dentistry only. Consult hepatologist for any surgery.",
        "severity": "high",
    },
    {
        "condition_or_drug": "Chronic Kidney Disease (Stage 4-5 / Dialysis)",
        "dental_concern": "Bleeding (uremic platelet dysfunction), drug accumulation, hypertension, immunosuppression",
        "what_to_do": "Treat day after dialysis (heparin cleared). Avoid nephrotoxic drugs (NSAIDs, aminoglycosides). Adjust drug doses renally cleared. Check BP before treatment.",
        "when_to_refer": "Consult nephrologist before surgery. If AV fistula arm — NO BP cuff or IV on that arm.",
        "severity": "high",
    },
    {
        "condition_or_drug": "Hepatitis B or C (active)",
        "dental_concern": "Cross-infection risk, altered liver function affecting drug metabolism",
        "what_to_do": "Standard + transmission-based precautions. All dental teams should be HBV vaccinated. Check liver function before prescribing. Adjust hepatically metabolized drugs.",
        "when_to_refer": "Active hepatitis with coagulopathy — medical management first",
        "severity": "moderate",
    },

    # ── IMMUNOCOMPROMISED (4) ─────────────────────────────────────
    {
        "condition_or_drug": "HIV/AIDS (CD4 <200)",
        "dental_concern": "Oral manifestations (candidiasis, KS, hairy leukoplakia), infection risk, drug interactions with ART",
        "what_to_do": "Check CD4 and viral load. If CD4 <200: prophylactic antibiotics for surgical procedures. Treat oral candidiasis aggressively. Drug interactions: protease inhibitors affect midazolam.",
        "when_to_refer": "CD4 <50: defer elective treatment, consult ID specialist",
        "severity": "high",
    },
    {
        "condition_or_drug": "Organ Transplant (on immunosuppression)",
        "dental_concern": "Infection risk, gingival hyperplasia (cyclosporine), drug interactions",
        "what_to_do": "Check CBC/WBC before surgery. Prophylactic antibiotics for surgical procedures. Cyclosporine gingival hyperplasia: OHI + gingivectomy. Coordinate drug management with transplant team.",
        "when_to_refer": "Always consult transplant team before surgical procedures",
        "severity": "high",
    },
    {
        "condition_or_drug": "Chemotherapy (active)",
        "dental_concern": "Mucositis, myelosuppression, infection, bleeding",
        "what_to_do": "Dental clearance BEFORE chemo starts. During chemo: emergency only. Check CBC: ANC >1000, platelets >50,000 for procedures. Manage mucositis: bland rinse, topical analgesics.",
        "when_to_refer": "Coordinate all treatment with oncology team. Timing between cycles is critical.",
        "severity": "critical",
    },
    {
        "condition_or_drug": "Autoimmune Disease on Biologics (TNF inhibitors, rituximab)",
        "dental_concern": "Infection risk, delayed healing, possible reactivation of latent infections",
        "what_to_do": "Prophylactic antibiotics for surgical procedures. Schedule surgery midway between biologic doses. Watch for atypical infections.",
        "when_to_refer": "Consult rheumatologist/prescriber for timing of surgical procedures",
        "severity": "moderate",
    },
]


def search_contraindications(query: str) -> List[Dict[str, Any]]:
    """Search contraindications by condition, drug name, or concern."""
    q = query.lower()
    results = []
    for c in CONTRAINDICATIONS:
        searchable = f"{c['condition_or_drug']} {c['dental_concern']} {c['what_to_do']}".lower()
        if q in searchable:
            results.append(c)
    return results


def get_by_severity(severity: str) -> List[Dict[str, Any]]:
    """Return all contraindications of a given severity level."""
    return [c for c in CONTRAINDICATIONS if c["severity"] == severity]
