"""FastAPI application for DentalAI Pro — serves both API and UI."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Optional

from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel, Field

from .clinical.oral_pathology import analyze_lesion
from .clinical.radiology import generate_report, check_findings
from .clinical.treatment import validate_plan, check_contraindications, estimate_prognosis
from .clinical.compliance import scan_compliance, get_inspection_checklist
from .clinical.billing import validate_claim, analyze_denial, cdt_lookup, cdt_search
from .onboarding import (
    get_regulatory_fields,
    get_clinical_config_options,
    validate_practice_data,
    validate_team_member,
    generate_golive_checklist,
    calculate_onboarding_progress,
)
from .compliance_regs import get_regulations_by_country, get_compliance_checklist
from .financial import (
    create_nhs_invoice, create_private_invoice, create_insurance_invoice,
    generate_pnl, generate_vat_summary, calculate_daily_takings,
    calculate_debt_aging, get_expense_categories, get_income_categories,
    get_nhs_band_info, determine_vat_rate, calculate_vat, generate_invoice_id,
)
from .marketing import (
    generate_social_post, get_content_calendar, get_templates as get_marketing_templates,
    get_platforms,
)
from .migration import (
    get_migration_guide, get_all_systems, parse_patient_csv, verify_migration,
)
from .licensing import (
    get_license_tiers, check_feature_access, check_patient_limit,
    check_dentist_limit, get_upgrade_info,
)
from .store import Store
from .insights import (
    get_practice_dashboard,
    get_revenue_by_chair,
    get_scheduling_efficiency,
    get_treatment_acceptance,
    get_recall_effectiveness,
    get_patient_acquisition,
    get_busiest_times,
    get_revenue_by_category,
    get_dentist_performance,
    get_dentist_comparison,
    get_dentist_outcomes,
    get_cpd_status,
    get_patient_journey_metrics,
    get_nps_score,
    get_communication_preferences,
    generate_recommendations,
)

app = FastAPI(
    title="DentalAI Pro",
    description="Enterprise Clinical Dental AI — Screening, Radiology, Treatment Planning, Compliance, Billing",
    version="0.1.0",
)

_store: Optional[Store] = None


def get_store() -> Store:
    """Get or create the global store instance."""
    global _store
    if _store is None:
        _store = Store()
    return _store


# ── Pydantic Models ───────────────────────────────────────────────

class ScreeningInput(BaseModel):
    location: str = ""
    colors: list[str] = Field(default_factory=list)
    textures: list[str] = Field(default_factory=list)
    borders: str = ""
    size_mm: float = 0.0
    duration: str = ""
    symptoms: list[str] = Field(default_factory=list)
    patient_age: int = 0
    patient_sex: str = ""
    risk_factors: list[str] = Field(default_factory=list)
    patient_id: Optional[int] = None


class RadiologyInput(BaseModel):
    study_type: str = "periapical"
    tooth_region: str = ""
    findings: str = ""
    quick_findings: list[str] = Field(default_factory=list)
    patient_id: Optional[int] = None


class TreatmentInput(BaseModel):
    diagnosis: str = ""
    diagnosis_category: str = ""
    planned_procedures: list[dict[str, str]] = Field(default_factory=list)
    tooth_number: str = ""
    medical_conditions: list[str] = Field(default_factory=list)
    medications: list[str] = Field(default_factory=list)
    patient_id: Optional[int] = None


class ComplianceInput(BaseModel):
    frameworks: list[str] = Field(default_factory=lambda: ["OSHA", "HIPAA", "Radiation Safety", "State Board", "Quality Assurance"])
    logged_items: dict[str, Any] = Field(default_factory=dict)
    state: str = ""


class SterilizationLog(BaseModel):
    sterilizer_id: str = ""
    cycle_type: str = ""
    result: str = "pass"
    logged_by: str = ""
    notes: str = ""


class BillingInput(BaseModel):
    cdt_codes: list[str] = Field(default_factory=list)
    payer: str = ""
    diagnosis_codes: list[str] = Field(default_factory=list)
    tooth_numbers: list[str] = Field(default_factory=list)
    patient_id: Optional[int] = None


class PatientInput(BaseModel):
    id: Optional[int] = None
    name: str = ""
    age: int = 0
    sex: str = ""
    medical_conditions: list[str] = Field(default_factory=list)
    medications: list[str] = Field(default_factory=list)
    risk_factors: list[str] = Field(default_factory=list)


class PracticeProfileInput(BaseModel):
    name: str = ""
    address: str = ""
    phone: str = ""
    email: str = ""
    practice_type: str = ""  # nhs, private, mixed
    country: str = ""  # uk, us, eu, au, ca
    num_surgeries: int = 0
    num_dentists: int = 0
    num_hygienists: int = 0
    num_nurses: int = 0
    primary_software: str = ""
    nhs_contract_number: str = ""
    cqc_registration: str = ""
    dspt_status: str = ""
    caldicott_guardian: str = ""


class RegulatoryInput(BaseModel):
    country: str = ""
    data: dict[str, Any] = Field(default_factory=dict)


class ClinicalConfigInput(BaseModel):
    specialties: list[str] = Field(default_factory=list)
    equipment: list[str] = Field(default_factory=list)
    treatment_types: list[str] = Field(default_factory=list)
    referral_network: list[dict[str, str]] = Field(default_factory=list)


class TeamMemberInput(BaseModel):
    name: str = ""
    role: str = ""  # dentist, hygienist, nurse, receptionist, therapist, technician
    license_number: str = ""
    gdc_number: str = ""
    npi_number: str = ""
    dea_number: str = ""
    access_level: str = "admin"  # full_clinical, clinical_view, admin
    start_date: str = ""


class GoLiveInput(BaseModel):
    data_protection_agreed: bool = False
    walkthrough_completed: bool = False


# ── UI Route ──────────────────────────────────────────────────────

@app.get("/", response_class=HTMLResponse)
async def serve_ui() -> HTMLResponse:
    """Serve the single-page web UI."""
    ui_path = Path(__file__).parent / "ui" / "index.html"
    if not ui_path.exists():
        raise HTTPException(status_code=500, detail="UI file not found")
    return HTMLResponse(content=ui_path.read_text(encoding="utf-8"))


# ── Screening Routes ─────────────────────────────────────────────

@app.post("/api/screening/analyze")
async def api_screening_analyze(data: ScreeningInput) -> JSONResponse:
    """Analyze an oral lesion and provide differential diagnosis."""
    result = analyze_lesion(data.model_dump())

    # Save record if patient context exists
    if data.patient_id:
        store = get_store()
        store.save_record("screening_records", data.patient_id, data.model_dump(), result)

    return JSONResponse(content=result)


# ── Radiology Routes ─────────────────────────────────────────────

@app.post("/api/radiology/report")
async def api_radiology_report(data: RadiologyInput) -> JSONResponse:
    """Generate a structured radiology report."""
    result = generate_report(data.model_dump())

    if data.patient_id:
        store = get_store()
        store.save_record("radiology_records", data.patient_id, data.model_dump(), result)

    return JSONResponse(content=result)


@app.post("/api/radiology/check")
async def api_radiology_check(data: RadiologyInput) -> JSONResponse:
    """Check for missed findings."""
    result = check_findings(data.model_dump())
    return JSONResponse(content=result)


# ── Treatment Routes ─────────────────────────────────────────────

@app.post("/api/treatment/validate")
async def api_treatment_validate(data: TreatmentInput) -> JSONResponse:
    """Validate a treatment plan."""
    result = validate_plan(data.model_dump())

    if data.patient_id:
        store = get_store()
        store.save_record("treatment_records", data.patient_id, data.model_dump(), result)

    return JSONResponse(content=result)


@app.post("/api/treatment/contraindications")
async def api_treatment_contraindications(data: TreatmentInput) -> JSONResponse:
    """Check for contraindications."""
    result = check_contraindications(data.model_dump())
    return JSONResponse(content=result)


@app.post("/api/treatment/prognosis")
async def api_treatment_prognosis(data: TreatmentInput) -> JSONResponse:
    """Estimate treatment prognosis."""
    result = estimate_prognosis(data.model_dump())
    return JSONResponse(content=result)


# ── Compliance Routes ────────────────────────────────────────────

@app.post("/api/compliance/scan")
async def api_compliance_scan(data: ComplianceInput) -> JSONResponse:
    """Run a compliance scan."""
    result = scan_compliance(data.model_dump())
    return JSONResponse(content=result)


@app.post("/api/compliance/log/sterilization")
async def api_compliance_log_sterilization(data: SterilizationLog) -> JSONResponse:
    """Log a sterilization cycle."""
    store = get_store()
    log_id = store.log_compliance(
        log_type="sterilization",
        check_id="OSHA-009",
        details=data.model_dump(),
        logged_by=data.logged_by,
    )
    return JSONResponse(content={"id": log_id, "status": "logged"})


@app.get("/api/compliance/logs")
async def api_compliance_logs(log_type: Optional[str] = None) -> JSONResponse:
    """Get compliance logs."""
    store = get_store()
    logs = store.get_compliance_logs(log_type=log_type)
    return JSONResponse(content={"logs": logs})


@app.get("/api/compliance/checklist")
async def api_compliance_checklist(state: str = "") -> JSONResponse:
    """Get an inspection preparation checklist."""
    result = get_inspection_checklist(state)
    return JSONResponse(content=result)


# ── Billing Routes ───────────────────────────────────────────────

@app.post("/api/billing/validate")
async def api_billing_validate(data: BillingInput) -> JSONResponse:
    """Validate a dental claim."""
    result = validate_claim(data.model_dump())

    if data.patient_id:
        store = get_store()
        store.save_record("billing_records", data.patient_id, data.model_dump(), result)

    return JSONResponse(content=result)


@app.get("/api/billing/cdt/{code}")
async def api_billing_cdt_lookup(code: str) -> JSONResponse:
    """Look up a CDT code."""
    result = cdt_lookup(code)
    return JSONResponse(content=result)


@app.get("/api/billing/cdt/search/{query}")
async def api_billing_cdt_search(query: str) -> JSONResponse:
    """Search CDT codes."""
    result = cdt_search(query)
    return JSONResponse(content=result)


@app.get("/api/billing/denial/{code}")
async def api_billing_denial(code: str) -> JSONResponse:
    """Analyze a claim denial."""
    result = analyze_denial(code)
    return JSONResponse(content=result)


# ── Patient Routes ───────────────────────────────────────────────

@app.post("/api/patient/save")
async def api_patient_save(data: PatientInput) -> JSONResponse:
    """Save or update a patient."""
    store = get_store()
    patient_id = store.save_patient(data.model_dump())
    return JSONResponse(content={"id": patient_id, "status": "saved"})


@app.get("/api/patient/{patient_id}")
async def api_patient_get(patient_id: int) -> JSONResponse:
    """Get a patient by ID."""
    store = get_store()
    patient = store.get_patient(patient_id)
    if patient is None:
        raise HTTPException(status_code=404, detail="Patient not found")
    return JSONResponse(content=patient)


@app.get("/api/patients")
async def api_patients_list() -> JSONResponse:
    """List all patients."""
    store = get_store()
    patients = store.list_patients()
    return JSONResponse(content={"patients": patients})


# ── Onboarding Routes ───────────────────────────────────────────

@app.post("/api/onboarding/practice")
async def api_onboarding_practice(data: PracticeProfileInput) -> JSONResponse:
    """Save practice profile (Step 1)."""
    validation = validate_practice_data(data.model_dump())
    if not validation["valid"]:
        raise HTTPException(status_code=422, detail=validation["errors"])
    store = get_store()
    store.save_practice_profile(data.model_dump())
    store.update_onboarding_step(1, "practice_complete")
    return JSONResponse(content={"status": "saved", "step": 1, "complete": True})


@app.post("/api/onboarding/regulatory")
async def api_onboarding_regulatory(data: RegulatoryInput) -> JSONResponse:
    """Save regulatory details (Step 2)."""
    store = get_store()
    store.save_regulatory_data(data.model_dump())
    store.update_onboarding_step(2, "regulatory_complete")
    return JSONResponse(content={"status": "saved", "step": 2, "complete": True})


@app.post("/api/onboarding/clinical")
async def api_onboarding_clinical(data: ClinicalConfigInput) -> JSONResponse:
    """Save clinical configuration (Step 3)."""
    store = get_store()
    store.save_clinical_config(data.model_dump())
    store.update_onboarding_step(3, "clinical_complete")
    return JSONResponse(content={"status": "saved", "step": 3, "complete": True})


@app.post("/api/onboarding/team")
async def api_onboarding_team(data: TeamMemberInput) -> JSONResponse:
    """Add a team member (Step 4)."""
    validation = validate_team_member(data.model_dump())
    if not validation["valid"]:
        raise HTTPException(status_code=422, detail=validation["errors"])
    store = get_store()
    member_id = store.add_team_member(data.model_dump())
    return JSONResponse(content={"status": "added", "id": member_id})


@app.post("/api/onboarding/team/complete")
async def api_onboarding_team_complete() -> JSONResponse:
    """Mark team setup step as complete."""
    store = get_store()
    store.update_onboarding_step(4, "team_complete")
    return JSONResponse(content={"status": "saved", "step": 4, "complete": True})


@app.get("/api/onboarding/team")
async def api_onboarding_team_list() -> JSONResponse:
    """List all team members."""
    store = get_store()
    members = store.list_team_members()
    return JSONResponse(content={"members": members})


@app.delete("/api/onboarding/team/{member_id}")
async def api_onboarding_team_remove(member_id: int) -> JSONResponse:
    """Remove a team member."""
    store = get_store()
    store.remove_team_member(member_id)
    return JSONResponse(content={"status": "removed", "id": member_id})


@app.post("/api/onboarding/golive")
async def api_onboarding_golive(data: GoLiveInput) -> JSONResponse:
    """Mark onboarding as complete (Step 5)."""
    if not data.data_protection_agreed:
        raise HTTPException(status_code=422, detail="Data protection agreement must be accepted")
    store = get_store()
    store.update_onboarding_step(5, "golive_complete")
    return JSONResponse(content={"status": "complete", "step": 5, "complete": True, "message": "Welcome to DentalAI Pro!"})


@app.get("/api/onboarding/status")
async def api_onboarding_status() -> JSONResponse:
    """Get onboarding progress."""
    store = get_store()
    status = store.get_onboarding_status()
    progress = calculate_onboarding_progress(status)
    profile = store.get_practice_profile()
    return JSONResponse(content={
        "progress": progress,
        "practice_profile": profile,
        "team_members": store.list_team_members(),
    })


@app.get("/api/onboarding/checklist")
async def api_onboarding_checklist_country(country: str = "uk") -> JSONResponse:
    """Get compliance checklist for a country."""
    store = get_store()
    profile = store.get_practice_profile()
    practice_type = profile.get("practice_type", "") if profile else ""
    checklist = generate_golive_checklist(country, practice_type)
    return JSONResponse(content={"country": country, "checklist": checklist, "total": len(checklist)})


@app.get("/api/onboarding/regulatory-fields/{country}")
async def api_onboarding_regulatory_fields(country: str) -> JSONResponse:
    """Get regulatory fields required for a country."""
    fields = get_regulatory_fields(country)
    return JSONResponse(content=fields)


@app.get("/api/onboarding/clinical-options")
async def api_onboarding_clinical_options() -> JSONResponse:
    """Get clinical configuration options."""
    options = get_clinical_config_options()
    return JSONResponse(content=options)


@app.get("/api/regulations/{country}")
async def api_regulations_by_country(country: str) -> JSONResponse:
    """Get all regulations for a country."""
    regs = get_regulations_by_country(country)
    return JSONResponse(content={"country": country, "regulations": regs, "total": len(regs)})


# ── Health Check ─────────────────────────────────────────────────

@app.get("/api/health")
async def health() -> JSONResponse:
    """Health check endpoint."""
    return JSONResponse(content={"status": "ok", "product": "DentalAI Pro", "version": "0.1.0"})


# ── Financial Pydantic Models ────────────────────────────────────

class IncomeInput(BaseModel):
    date: str = ""
    category: str = ""
    subcategory: str = ""
    description: str = ""
    amount: float = 0.0
    vat_rate: float = 0.0
    payment_method: str = ""
    reference: str = ""
    patient_id: Optional[int] = None
    invoice_id: str = ""


class ExpenseInput(BaseModel):
    date: str = ""
    category: str = ""
    subcategory: str = ""
    description: str = ""
    amount: float = 0.0
    vat_rate: float = 0.0
    payment_method: str = ""
    reference: str = ""


class NHSInvoiceInput(BaseModel):
    patient_id: int = 0
    patient_name: str = ""
    band: str = ""
    exemption: str = "none"
    notes: str = ""


class PrivateInvoiceInput(BaseModel):
    patient_id: int = 0
    patient_name: str = ""
    items: list[dict[str, Any]] = Field(default_factory=list)
    notes: str = ""


class InsuranceInvoiceInput(BaseModel):
    patient_id: int = 0
    patient_name: str = ""
    items: list[dict[str, Any]] = Field(default_factory=list)
    insurance_provider: str = ""
    policy_number: str = ""
    notes: str = ""


class InvoiceCreateInput(BaseModel):
    invoice_type: str = "private"  # nhs, private, insurance
    patient_id: int = 0
    patient_name: str = ""
    band: str = ""
    exemption: str = "none"
    items: list[dict[str, Any]] = Field(default_factory=list)
    insurance_provider: str = ""
    policy_number: str = ""
    notes: str = ""


class SocialPostInput(BaseModel):
    topic: str = "health_tip"
    platform: str = "facebook"
    practice_name: str = ""
    custom_topic: str = ""


class SchedulePostInput(BaseModel):
    content: str = ""
    platform: str = ""
    scheduled_date: str = ""
    title: str = ""
    campaign: str = ""


class MigrationStartInput(BaseModel):
    source_system: str = ""


class MigrationImportInput(BaseModel):
    csv_content: str = ""


class MigrationVerifyInput(BaseModel):
    source_count: int = 0


# ── Finance Routes ───────────────────────────────────────────────

@app.post("/api/finance/income")
async def api_finance_income(data: IncomeInput) -> JSONResponse:
    """Record an income entry in the ledger."""
    store = get_store()
    vat_amount = calculate_vat(data.amount, data.vat_rate)
    entry = {
        "date": data.date or __import__("datetime").date.today().isoformat(),
        "type": "income",
        "category": data.category,
        "subcategory": data.subcategory,
        "description": data.description,
        "amount": data.amount,
        "vat_rate": data.vat_rate,
        "vat_amount": vat_amount,
        "payment_method": data.payment_method,
        "reference": data.reference,
        "patient_id": data.patient_id,
        "invoice_id": data.invoice_id,
    }
    entry_id = store.add_ledger_entry(entry)
    return JSONResponse(content={"id": entry_id, "status": "recorded", "vat_amount": vat_amount})


@app.post("/api/finance/expense")
async def api_finance_expense(data: ExpenseInput) -> JSONResponse:
    """Record an expense entry in the ledger."""
    store = get_store()
    vat_amount = calculate_vat(data.amount, data.vat_rate)
    entry = {
        "date": data.date or __import__("datetime").date.today().isoformat(),
        "type": "expense",
        "category": data.category,
        "subcategory": data.subcategory,
        "description": data.description,
        "amount": data.amount,
        "vat_rate": data.vat_rate,
        "vat_amount": vat_amount,
        "payment_method": data.payment_method,
        "reference": data.reference,
    }
    entry_id = store.add_ledger_entry(entry)
    return JSONResponse(content={"id": entry_id, "status": "recorded", "vat_amount": vat_amount})


@app.post("/api/finance/invoice/create")
async def api_finance_invoice_create(data: InvoiceCreateInput) -> JSONResponse:
    """Create an invoice (NHS, private, or insurance)."""
    store = get_store()

    if data.invoice_type == "nhs":
        invoice = create_nhs_invoice(
            patient_id=data.patient_id,
            patient_name=data.patient_name,
            band=data.band,
            exemption=data.exemption,
            notes=data.notes,
        )
    elif data.invoice_type == "insurance":
        invoice = create_insurance_invoice(
            patient_id=data.patient_id,
            patient_name=data.patient_name,
            items=data.items,
            insurance_provider=data.insurance_provider,
            policy_number=data.policy_number,
            notes=data.notes,
        )
    else:
        invoice = create_private_invoice(
            patient_id=data.patient_id,
            patient_name=data.patient_name,
            items=data.items,
            notes=data.notes,
        )

    invoice_id = store.save_invoice(invoice)
    return JSONResponse(content={"id": invoice_id, "invoice": invoice, "status": "created"})


@app.get("/api/finance/invoice/{invoice_id}")
async def api_finance_invoice_get(invoice_id: str) -> JSONResponse:
    """Get an invoice by ID."""
    store = get_store()
    invoice = store.get_invoice(invoice_id)
    if invoice is None:
        raise HTTPException(status_code=404, detail="Invoice not found")
    return JSONResponse(content=invoice)


@app.get("/api/finance/invoices")
async def api_finance_invoices(
    status: Optional[str] = None,
    invoice_type: Optional[str] = None,
) -> JSONResponse:
    """List invoices with optional filters."""
    store = get_store()
    invoices = store.list_invoices(status=status, invoice_type=invoice_type)
    return JSONResponse(content={"invoices": invoices, "total": len(invoices)})


@app.get("/api/finance/pnl")
async def api_finance_pnl(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    period: str = "monthly",
) -> JSONResponse:
    """Generate Profit & Loss report."""
    from datetime import date as date_cls
    store = get_store()

    if not start_date:
        today = date_cls.today()
        start_date = today.replace(day=1).isoformat()
    if not end_date:
        end_date = date_cls.today().isoformat()

    income = store.get_ledger_entries(entry_type="income", start_date=start_date, end_date=end_date)
    expenses = store.get_ledger_entries(entry_type="expense", start_date=start_date, end_date=end_date)

    pnl = generate_pnl(income, expenses, period_label=f"{start_date} to {end_date}")
    return JSONResponse(content=pnl)


@app.get("/api/finance/vat")
async def api_finance_vat(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
) -> JSONResponse:
    """Get VAT summary for a period."""
    from datetime import date as date_cls
    store = get_store()

    if not start_date:
        today = date_cls.today()
        # Current quarter start
        quarter_month = ((today.month - 1) // 3) * 3 + 1
        start_date = today.replace(month=quarter_month, day=1).isoformat()
    if not end_date:
        end_date = date_cls.today().isoformat()

    income = store.get_ledger_entries(entry_type="income", start_date=start_date, end_date=end_date)
    expenses = store.get_ledger_entries(entry_type="expense", start_date=start_date, end_date=end_date)

    vat = generate_vat_summary(income, expenses, period_label=f"{start_date} to {end_date}")
    return JSONResponse(content=vat)


@app.get("/api/finance/dashboard")
async def api_finance_dashboard() -> JSONResponse:
    """Get financial dashboard summary."""
    from datetime import date as date_cls, timedelta
    store = get_store()

    today = date_cls.today()
    month_start = today.replace(day=1).isoformat()
    today_str = today.isoformat()

    # Today's takings
    today_income = store.get_ledger_entries(entry_type="income", start_date=today_str, end_date=today_str)
    daily = calculate_daily_takings(today_income, today_str)

    # Monthly totals
    month_income = store.get_ledger_entries(entry_type="income", start_date=month_start, end_date=today_str)
    month_expenses = store.get_ledger_entries(entry_type="expense", start_date=month_start, end_date=today_str)
    monthly_pnl = generate_pnl(month_income, month_expenses, period_label=today.strftime("%B %Y"))

    # Outstanding invoices
    all_invoices = store.list_invoices()
    pending = [inv for inv in all_invoices if inv.get("status") in ("pending", "overdue")]
    debt_aging = calculate_debt_aging(all_invoices)

    # NHS band breakdown this month
    nhs_invoices = [inv for inv in all_invoices if inv.get("type") == "nhs" and inv.get("date", "") >= month_start]
    nhs_bands = {"1": 0, "2": 0, "3": 0, "urgent": 0}
    for inv in nhs_invoices:
        band = inv.get("nhs_band", "")
        if band in nhs_bands:
            nhs_bands[band] += 1

    return JSONResponse(content={
        "daily_takings": daily,
        "monthly_pnl": monthly_pnl,
        "outstanding_invoices": len(pending),
        "outstanding_total": sum(float(inv.get("total", 0)) for inv in pending),
        "debt_aging": debt_aging,
        "nhs_band_breakdown": nhs_bands,
        "expense_categories": get_expense_categories(),
        "income_categories": get_income_categories(),
        "nhs_bands": get_nhs_band_info(),
    })


@app.get("/api/finance/daily-takings")
async def api_finance_daily_takings(date: Optional[str] = None) -> JSONResponse:
    """Get daily takings for a specific date."""
    from datetime import date as date_cls
    store = get_store()

    target_date = date or date_cls.today().isoformat()
    income = store.get_ledger_entries(entry_type="income", start_date=target_date, end_date=target_date)
    result = calculate_daily_takings(income, target_date)
    return JSONResponse(content=result)


# ── Marketing Routes ─────────────────────────────────────────────

@app.post("/api/marketing/generate-post")
async def api_marketing_generate_post(data: SocialPostInput) -> JSONResponse:
    """Generate a social media post."""
    post = generate_social_post(
        topic=data.topic,
        platform=data.platform,
        practice_name=data.practice_name,
        custom_topic=data.custom_topic,
    )
    return JSONResponse(content=post)


@app.get("/api/marketing/calendar")
async def api_marketing_calendar(
    start_date: Optional[str] = None,
    weeks: int = 1,
    practice_name: str = "",
) -> JSONResponse:
    """Get content calendar."""
    # Merge saved content with generated suggestions
    store = get_store()
    saved = store.list_marketing_content()
    suggestions = get_content_calendar(
        practice_name=practice_name,
        start_date=start_date,
        weeks=weeks,
    )
    return JSONResponse(content={
        "saved_content": saved,
        "suggestions": suggestions,
        "platforms": get_platforms(),
    })


@app.post("/api/marketing/schedule")
async def api_marketing_schedule(data: SchedulePostInput) -> JSONResponse:
    """Schedule a social media post."""
    store = get_store()
    content_id = store.save_marketing_content({
        "type": "social_post",
        "platform": data.platform,
        "title": data.title,
        "content": data.content,
        "status": "scheduled",
        "scheduled_date": data.scheduled_date,
        "campaign": data.campaign,
    })
    return JSONResponse(content={"id": content_id, "status": "scheduled"})


@app.get("/api/marketing/templates")
async def api_marketing_templates(template_type: Optional[str] = None) -> JSONResponse:
    """Get marketing/communication templates."""
    templates = get_marketing_templates(template_type)
    return JSONResponse(content={"templates": templates, "total": len(templates)})


# ── Migration Routes ─────────────────────────────────────────────

@app.get("/api/migration/guide/{system}")
async def api_migration_guide(system: str) -> JSONResponse:
    """Get migration guide for a source system."""
    guide = get_migration_guide(system)
    if "error" in guide:
        raise HTTPException(status_code=404, detail=guide["error"])
    return JSONResponse(content=guide)


@app.get("/api/migration/systems")
async def api_migration_systems() -> JSONResponse:
    """Get all supported source systems."""
    systems = get_all_systems()
    return JSONResponse(content={"systems": systems})


@app.post("/api/migration/start")
async def api_migration_start(data: MigrationStartInput) -> JSONResponse:
    """Start a migration process."""
    import time as _time
    store = get_store()
    store.update_migration_status({
        "source_system": data.source_system,
        "status": "in_progress",
        "step": 1,
        "started_at": _time.strftime("%Y-%m-%dT%H:%M:%SZ", _time.gmtime()),
    })
    guide = get_migration_guide(data.source_system)
    return JSONResponse(content={
        "status": "started",
        "source_system": data.source_system,
        "guide": guide,
    })


@app.post("/api/migration/import/patients")
async def api_migration_import_patients(data: MigrationImportInput) -> JSONResponse:
    """Import patients from CSV data."""
    store = get_store()
    parsed = parse_patient_csv(data.csv_content)

    if not parsed["valid"]:
        return JSONResponse(content={"status": "error", "result": parsed}, status_code=422)

    imported_count = 0
    for patient in parsed["patients"]:
        store.save_patient(patient)
        imported_count += 1

    store.update_migration_status({
        "patients_imported": imported_count,
        "step": 3,
        "status": "imported",
    })

    return JSONResponse(content={
        "status": "imported",
        "imported": imported_count,
        "total_rows": parsed["total_rows"],
        "issues": parsed["issues"],
    })


@app.get("/api/migration/status")
async def api_migration_status() -> JSONResponse:
    """Get migration progress."""
    store = get_store()
    status = store.get_migration_status()
    return JSONResponse(content=status)


@app.post("/api/migration/verify")
async def api_migration_verify(data: MigrationVerifyInput) -> JSONResponse:
    """Run migration verification."""
    store = get_store()
    patients = store.list_patients()
    migration = store.get_migration_status()

    result = verify_migration(
        source_count=data.source_count or migration.get("patients_exported", 0),
        imported_count=len(patients),
        sample_patients=patients[:10],
    )

    store.update_migration_status({
        "records_verified": len(patients),
        "step": 4,
        "status": "verified" if result["overall_status"] == "pass" else "needs_review",
    })

    return JSONResponse(content=result)


# ── License Routes ───────────────────────────────────────────────

@app.get("/api/license")
async def api_license_info() -> JSONResponse:
    """Get current license information."""
    store = get_store()
    license_data = store.get_license()
    tiers = get_license_tiers()
    return JSONResponse(content={
        "license": license_data,
        "tiers": tiers,
        "upgrade_info": get_upgrade_info(license_data.get("tier", "free")),
    })


# ── Insights Routes ─────────────────────────────────────────────

@app.get("/api/insights/practice")
async def api_insights_practice() -> JSONResponse:
    """Practice-level dashboard with aggregated KPIs."""
    store = get_store()
    result = get_practice_dashboard(store)
    return JSONResponse(content=result)


@app.get("/api/insights/dentist/{dentist_id}")
async def api_insights_dentist(dentist_id: int) -> JSONResponse:
    """Individual dentist performance metrics."""
    store = get_store()
    result = get_dentist_performance(store, dentist_id)
    if "error" in result:
        raise HTTPException(status_code=404, detail=result["error"])
    return JSONResponse(content=result)


@app.get("/api/insights/dentists")
async def api_insights_dentists() -> JSONResponse:
    """Comparison across all dentists."""
    store = get_store()
    result = get_dentist_comparison(store)
    return JSONResponse(content=result)


@app.get("/api/insights/revenue")
async def api_insights_revenue() -> JSONResponse:
    """Revenue breakdown by category and chair."""
    store = get_store()
    by_category = get_revenue_by_category(store)
    by_chair = get_revenue_by_chair(store)
    return JSONResponse(content={
        "by_category": by_category,
        "by_chair": by_chair,
    })


@app.get("/api/insights/scheduling")
async def api_insights_scheduling() -> JSONResponse:
    """Scheduling efficiency metrics."""
    store = get_store()
    efficiency = get_scheduling_efficiency(store)
    busiest = get_busiest_times(store)
    return JSONResponse(content={
        "efficiency": efficiency,
        "busiest_times": busiest,
    })


@app.get("/api/insights/recommendations")
async def api_insights_recommendations() -> JSONResponse:
    """AI-generated prioritized recommendations."""
    store = get_store()
    recs = generate_recommendations(store)
    return JSONResponse(content={
        "recommendations": recs,
        "total": len(recs),
        "high_priority": sum(1 for r in recs if r.get("priority") == "high"),
        "medium_priority": sum(1 for r in recs if r.get("priority") == "medium"),
        "low_priority": sum(1 for r in recs if r.get("priority") == "low"),
    })


@app.get("/api/insights/patient-journey")
async def api_insights_patient_journey() -> JSONResponse:
    """Patient experience and journey metrics."""
    store = get_store()
    journey = get_patient_journey_metrics(store)
    nps = get_nps_score(store)
    comms = get_communication_preferences(store)
    recall = get_recall_effectiveness(store)
    acquisition = get_patient_acquisition(store)
    return JSONResponse(content={
        "journey": journey,
        "nps": nps,
        "communication": comms,
        "recall": recall,
        "acquisition": acquisition,
    })


@app.get("/api/insights/cpd")
async def api_insights_cpd() -> JSONResponse:
    """CPD status for the team."""
    store = get_store()
    result = get_cpd_status(store)
    return JSONResponse(content=result)
