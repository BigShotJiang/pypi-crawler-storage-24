"""Licensing and monetization module for DentalAI Pro.

Implements soft license enforcement with upgrade prompts.
Patient safety first: clinical features are never hard-blocked.
"""

from __future__ import annotations

import json
import time
from datetime import datetime
from typing import Any, Dict, List, Optional


# ── License Tiers ──────────────────────────────────────────────
LICENSE_TIERS = {
    "free": {
        "label": "Free",
        "price": "Free",
        "max_dentists": 1,
        "max_patients_month": 50,
        "features": [
            "oral_screening",
            "radiology_basic",
            "treatment_validation",
            "compliance_basic",
            "billing_basic",
        ],
        "description": "1 dentist, 50 patients/month, basic screening & radiology",
    },
    "pro": {
        "label": "Pro",
        "price": "GBP 49/month per location",
        "max_dentists": 999,
        "max_patients_month": 999999,
        "features": [
            "oral_screening",
            "radiology_basic",
            "radiology_advanced",
            "treatment_validation",
            "treatment_prognosis",
            "compliance_basic",
            "compliance_advanced",
            "billing_basic",
            "billing_advanced",
            "onboarding",
            "patient_management",
        ],
        "description": "Unlimited dentists & patients, all clinical + compliance + billing",
    },
    "enterprise": {
        "label": "Enterprise",
        "price": "Custom pricing",
        "max_dentists": 999,
        "max_patients_month": 999999,
        "features": [
            "oral_screening",
            "radiology_basic",
            "radiology_advanced",
            "treatment_validation",
            "treatment_prognosis",
            "compliance_basic",
            "compliance_advanced",
            "billing_basic",
            "billing_advanced",
            "onboarding",
            "patient_management",
            "financial_management",
            "marketing",
            "migration",
            "api_access",
            "priority_support",
            "nhs_tools",
            "custom_reports",
        ],
        "description": "Everything + financial management + marketing + migration + API + priority support",
    },
}

# ── Feature Definitions ────────────────────────────────────────
FEATURE_DEFINITIONS = {
    "oral_screening": {"label": "Oral Screening AI", "clinical": True},
    "radiology_basic": {"label": "Basic Radiology Reports", "clinical": True},
    "radiology_advanced": {"label": "Advanced Radiology (missed findings)", "clinical": True},
    "treatment_validation": {"label": "Treatment Plan Validation", "clinical": True},
    "treatment_prognosis": {"label": "Prognosis Estimation", "clinical": True},
    "compliance_basic": {"label": "Basic Compliance Tracking", "clinical": False},
    "compliance_advanced": {"label": "Advanced Compliance Dashboard", "clinical": False},
    "billing_basic": {"label": "CDT Code Lookup & Validation", "clinical": False},
    "billing_advanced": {"label": "Advanced Billing & Denial Analysis", "clinical": False},
    "onboarding": {"label": "Practice Onboarding Wizard", "clinical": False},
    "patient_management": {"label": "Patient Management", "clinical": False},
    "financial_management": {"label": "Financial Management", "clinical": False},
    "marketing": {"label": "Marketing & Social Media", "clinical": False},
    "migration": {"label": "Data Migration Wizard", "clinical": False},
    "api_access": {"label": "API Access", "clinical": False},
    "priority_support": {"label": "Priority Support", "clinical": False},
    "nhs_tools": {"label": "NHS Tools (UDA, FP17)", "clinical": False},
    "custom_reports": {"label": "Custom Reports", "clinical": False},
}


def get_license_tiers() -> Dict[str, Any]:
    """Return all license tier information."""
    return LICENSE_TIERS


def check_feature_access(
    tier: str,
    feature: str,
) -> Dict[str, Any]:
    """Check if a feature is accessible under the given license tier.

    Soft enforcement: clinical features are NEVER blocked.
    Non-clinical features show an upgrade prompt.

    Args:
        tier: Current license tier (free, pro, enterprise).
        feature: Feature key to check.

    Returns:
        Access check result with allowed flag and upgrade info.
    """
    tier_info = LICENSE_TIERS.get(tier, LICENSE_TIERS["free"])
    feature_info = FEATURE_DEFINITIONS.get(feature, {"label": feature, "clinical": False})

    allowed = feature in tier_info["features"]
    is_clinical = feature_info.get("clinical", False)

    if allowed:
        return {
            "allowed": True,
            "feature": feature,
            "feature_label": feature_info["label"],
            "tier": tier,
            "message": "",
        }

    # Soft enforcement: never block clinical features
    if is_clinical:
        return {
            "allowed": True,
            "feature": feature,
            "feature_label": feature_info["label"],
            "tier": tier,
            "message": "",
            "upgrade_prompt": (
                f"This feature ({feature_info['label']}) is not included in your "
                f"{tier_info['label']} plan. Clinical features remain accessible for "
                f"patient safety. Consider upgrading for the full experience."
            ),
            "soft_warning": True,
        }

    # Non-clinical: soft block with upgrade prompt
    upgrade_to = "pro" if tier == "free" else "enterprise"
    upgrade_info = LICENSE_TIERS.get(upgrade_to, LICENSE_TIERS["enterprise"])

    return {
        "allowed": False,
        "feature": feature,
        "feature_label": feature_info["label"],
        "tier": tier,
        "message": (
            f"{feature_info['label']} requires {upgrade_info['label']} plan "
            f"({upgrade_info['price']}). Upgrade to unlock this feature."
        ),
        "upgrade_to": upgrade_to,
        "upgrade_price": upgrade_info["price"],
        "soft_warning": True,
    }


def check_patient_limit(
    tier: str,
    current_month_count: int,
) -> Dict[str, Any]:
    """Check if the practice is within their patient limit.

    Soft enforcement: warns but does not block.

    Args:
        tier: Current license tier.
        current_month_count: Number of patients seen this month.

    Returns:
        Limit check result with warning if exceeded.
    """
    tier_info = LICENSE_TIERS.get(tier, LICENSE_TIERS["free"])
    limit = tier_info["max_patients_month"]
    exceeded = current_month_count >= limit

    result: Dict[str, Any] = {
        "within_limit": not exceeded,
        "current_count": current_month_count,
        "limit": limit,
        "tier": tier,
    }

    if exceeded:
        result["warning"] = (
            f"You have reached your monthly patient limit of {limit} "
            f"on the {tier_info['label']} plan. You can continue using "
            f"DentalAI Pro, but consider upgrading for unlimited patients."
        )
        result["upgrade_prompt"] = True

    return result


def check_dentist_limit(
    tier: str,
    dentist_count: int,
) -> Dict[str, Any]:
    """Check if the practice is within their dentist limit.

    Args:
        tier: Current license tier.
        dentist_count: Number of dentists in the practice.

    Returns:
        Limit check result.
    """
    tier_info = LICENSE_TIERS.get(tier, LICENSE_TIERS["free"])
    limit = tier_info["max_dentists"]
    exceeded = dentist_count > limit

    result: Dict[str, Any] = {
        "within_limit": not exceeded,
        "current_count": dentist_count,
        "limit": limit,
        "tier": tier,
    }

    if exceeded:
        result["warning"] = (
            f"Your practice has {dentist_count} dentists, but the "
            f"{tier_info['label']} plan supports up to {limit}. "
            f"All dentists can continue working - consider upgrading."
        )

    return result


def get_upgrade_info(current_tier: str) -> Dict[str, Any]:
    """Get information about available upgrades.

    Args:
        current_tier: Current license tier.

    Returns:
        Upgrade options and feature comparison.
    """
    current = LICENSE_TIERS.get(current_tier, LICENSE_TIERS["free"])
    current_features = set(current["features"])

    upgrades = []
    for tier_key, tier_info in LICENSE_TIERS.items():
        if tier_key == current_tier:
            continue
        tier_features = set(tier_info["features"])
        new_features = tier_features - current_features
        if new_features:
            upgrades.append({
                "tier": tier_key,
                "label": tier_info["label"],
                "price": tier_info["price"],
                "description": tier_info["description"],
                "new_features": [
                    {
                        "key": f,
                        "label": FEATURE_DEFINITIONS.get(f, {}).get("label", f),
                    }
                    for f in new_features
                ],
            })

    return {
        "current_tier": current_tier,
        "current_label": current["label"],
        "upgrades": upgrades,
    }
