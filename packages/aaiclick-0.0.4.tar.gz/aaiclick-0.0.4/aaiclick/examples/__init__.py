"""
aaiclick examples package.
"""
