"""Atomic task claiming and cancellation for distributed workers."""

from datetime import datetime
from typing import Optional

from sqlalchemy import text
from sqlmodel import select

from .context import get_orch_session
from .models import Job, JobStatus, Task, TaskStatus

# Terminal job statuses that cannot be cancelled
_TERMINAL_JOB_STATUSES = (JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED)


async def claim_next_task(worker_id: int) -> Optional[Task]:
    """
    Atomically claim the next available task for a worker.

    Uses PostgreSQL's FOR UPDATE SKIP LOCKED to safely claim tasks
    in a concurrent environment. Prioritizes tasks from oldest running jobs.

    When the first task of a job is claimed:
    - Job status transitions from PENDING to RUNNING
    - Job's started_at is set to current time

    Dependency checking:
    - Task → Task: Task waits for previous task to complete
    - Group → Task: Task waits for all tasks in previous group to complete
    - Task → Group: Tasks in group wait for previous task to complete
    - Group → Group: Tasks in group wait for all tasks in previous group to complete

    Args:
        worker_id: ID of the worker claiming the task

    Returns:
        Task if one was claimed, None if no tasks available
    """
    async with get_orch_session() as session:
        # Use raw SQL for FOR UPDATE SKIP LOCKED
        # SQLAlchemy's with_for_update() doesn't support SKIP LOCKED well with subqueries
        result = await session.execute(
            text("""
                WITH claimed_task AS (
                    UPDATE tasks
                    SET
                        status = :claimed_status,
                        worker_id = :worker_id,
                        claimed_at = :now
                    WHERE id = (
                        SELECT t.id FROM tasks t
                        JOIN jobs j ON t.job_id = j.id
                        WHERE t.status = :pending_status
                        AND (t.retry_after IS NULL OR t.retry_after <= :now)
                        AND j.status NOT IN (:cancelled_job_status, :failed_job_status)
                        -- Check task → task dependencies (previous task must be completed)
                        AND NOT EXISTS (
                            SELECT 1 FROM dependencies d
                            JOIN tasks prev ON d.previous_id = prev.id
                            WHERE d.next_id = t.id
                            AND d.next_type = 'task'
                            AND d.previous_type = 'task'
                            AND prev.status != :completed_status
                        )
                        -- Check group → task dependencies (all tasks in previous group must be completed)
                        AND NOT EXISTS (
                            SELECT 1 FROM dependencies d
                            JOIN tasks prev ON prev.group_id = d.previous_id
                            WHERE d.next_id = t.id
                            AND d.next_type = 'task'
                            AND d.previous_type = 'group'
                            AND prev.status != :completed_status
                        )
                        -- Check task → group dependencies (if task is in a group that depends on a task)
                        AND NOT EXISTS (
                            SELECT 1 FROM dependencies d
                            JOIN tasks prev ON d.previous_id = prev.id
                            WHERE d.next_id = t.group_id
                            AND d.next_type = 'group'
                            AND d.previous_type = 'task'
                            AND prev.status != :completed_status
                            AND t.group_id IS NOT NULL
                        )
                        -- Check group → group dependencies (if task is in a group that depends on another group)
                        AND NOT EXISTS (
                            SELECT 1 FROM dependencies d
                            JOIN tasks prev ON prev.group_id = d.previous_id
                            WHERE d.next_id = t.group_id
                            AND d.next_type = 'group'
                            AND d.previous_type = 'group'
                            AND prev.status != :completed_status
                            AND t.group_id IS NOT NULL
                        )
                        ORDER BY j.started_at ASC NULLS LAST, t.id ASC
                        LIMIT 1
                        FOR UPDATE OF t SKIP LOCKED
                    )
                    RETURNING id, job_id, entrypoint, kwargs, status, result,
                              log_path, error, worker_id, created_at, claimed_at,
                              started_at, completed_at, group_id,
                              max_retries, attempt, retry_after
                ),
                updated_job AS (
                    UPDATE jobs
                    SET
                        started_at = COALESCE(started_at, :now),
                        status = CASE
                            WHEN started_at IS NULL THEN :running_status
                            ELSE status
                        END
                    WHERE id = (SELECT job_id FROM claimed_task)
                    RETURNING id
                )
                SELECT * FROM claimed_task
            """),
            {
                "claimed_status": TaskStatus.RUNNING.value,
                "pending_status": TaskStatus.PENDING.value,
                "completed_status": TaskStatus.COMPLETED.value,
                "running_status": JobStatus.RUNNING.value,
                "cancelled_job_status": JobStatus.CANCELLED.value,
                "failed_job_status": JobStatus.FAILED.value,
                "worker_id": worker_id,
                "now": datetime.utcnow(),
            },
        )

        row = result.mappings().fetchone()
        if row is None:
            return None

        # Convert row dict to Task object, handling status enum conversion
        task_data = dict(row)
        task_data["status"] = TaskStatus(task_data["status"])
        task = Task(**task_data)

        await session.commit()
        return task


async def update_task_status(
    task_id: int,
    status: TaskStatus,
    error: Optional[str] = None,
    result: Optional[dict] = None,
) -> bool:
    """
    Update a task's status and optional error/result.

    Args:
        task_id: Task ID to update
        status: New status
        error: Error message (for FAILED status)
        result: Result reference (for COMPLETED status)

    Returns:
        bool: True if task was found and updated
    """
    async with get_orch_session() as session:
        # Use ORM to fetch and update task with row-level lock
        query_result = await session.execute(
            select(Task).where(Task.id == task_id).with_for_update()
        )
        task = query_result.scalar_one_or_none()
        if task is None:
            return False

        if task.status == TaskStatus.CANCELLED:
            return False

        task.status = status
        if status == TaskStatus.RUNNING:
            task.started_at = datetime.utcnow()
        elif status in (TaskStatus.COMPLETED, TaskStatus.FAILED):
            task.completed_at = datetime.utcnow()
            if error:
                task.error = error
            if result:
                task.result = result

        session.add(task)
        await session.commit()
        return True


async def update_job_status(job_id: int, status: JobStatus, error: Optional[str] = None) -> bool:
    """
    Update a job's status.

    Args:
        job_id: Job ID to update
        status: New status
        error: Error message (for FAILED status)

    Returns:
        bool: True if job was found and updated
    """
    async with get_orch_session() as session:
        # Use ORM to fetch and update job with row-level lock
        query_result = await session.execute(
            select(Job).where(Job.id == job_id).with_for_update()
        )
        job = query_result.scalar_one_or_none()
        if job is None:
            return False

        job.status = status
        if status in (JobStatus.COMPLETED, JobStatus.FAILED, JobStatus.CANCELLED):
            job.completed_at = datetime.utcnow()
            if error:
                job.error = error

        session.add(job)
        await session.commit()
        return True


async def cancel_job(job_id: int) -> bool:
    """
    Cancel a job and all its non-terminal tasks.

    Atomically transitions the job to CANCELLED and bulk-updates all
    PENDING, CLAIMED, and RUNNING tasks to CANCELLED. Tasks already
    COMPLETED or FAILED are left unchanged.

    Only PENDING and RUNNING jobs can be cancelled. Returns False for
    jobs in terminal states (COMPLETED, FAILED, CANCELLED) or if the
    job does not exist.

    Args:
        job_id: Job ID to cancel

    Returns:
        bool: True if job was cancelled, False if not found or already terminal
    """
    async with get_orch_session() as session:
        query_result = await session.execute(
            select(Job).where(Job.id == job_id).with_for_update()
        )
        job = query_result.scalar_one_or_none()
        if job is None:
            return False

        if job.status in _TERMINAL_JOB_STATUSES:
            return False

        now = datetime.utcnow()
        job.status = JobStatus.CANCELLED
        job.completed_at = now
        session.add(job)

        await session.execute(
            text(
                "UPDATE tasks SET status = :cancelled_status, "
                "completed_at = :now "
                "WHERE job_id = :job_id "
                "AND status IN ('PENDING', 'CLAIMED', 'RUNNING')"
            ),
            {
                "cancelled_status": TaskStatus.CANCELLED.value,
                "now": now,
                "job_id": job_id,
            },
        )

        await session.commit()
        return True


async def check_task_cancelled(task_id: int) -> bool:
    """
    Check if a task has been cancelled.

    Used by the worker's cancellation monitor to detect when a running
    task's job has been cancelled via cancel_job().

    Args:
        task_id: Task ID to check

    Returns:
        bool: True if task status is CANCELLED
    """
    async with get_orch_session() as session:
        result = await session.execute(
            select(Task.status).where(Task.id == task_id)
        )
        status = result.scalar_one_or_none()
        return status == TaskStatus.CANCELLED
