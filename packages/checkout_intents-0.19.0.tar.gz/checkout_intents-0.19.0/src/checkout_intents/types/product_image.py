# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["ProductImage"]


class ProductImage(BaseModel):
    is_featured: bool = FieldInfo(alias="isFeatured")

    url: str
