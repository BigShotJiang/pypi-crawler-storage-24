__all__ = [
    # Table compression
    "encode_csv",
    "decode_to_csv",
    # Image compression
    "encode_image",
    "decode_image",
    "decode_to_image_file",
    "decode_to_pil",
    "ImageEncodeConfig",
    # Image metrics
    "psnr",
    "ssim",
    "eval_image",
    "compare_codecs",
    # Audio compression (NEW in research branch)
    "encode_audio",
    "encode_audio_from_array",
    "decode_audio",
    "decode_to_audio_file",
    "AudioEncodeConfig",
    # Audio metrics
    "snr",
    "eval_audio",
    "compare_audio_methods",
]

from .table_encoder import encode_csv
from .table_decoder import decode_to_csv
from .image_encoder import encode_image, encode_image_from_array, ImageEncodeConfig
from .image_decoder import decode_image, decode_to_image_file, decode_to_pil
from .image_metrics import psnr, ssim, eval_image, compare_codecs
from .audio_encoder import encode_audio, encode_audio_from_array, AudioEncodeConfig
from .audio_decoder import decode_audio, decode_to_audio_file
from .audio_metrics import snr, eval_audio, compare_methods as compare_audio_methods

__version__ = "0.3.1"
