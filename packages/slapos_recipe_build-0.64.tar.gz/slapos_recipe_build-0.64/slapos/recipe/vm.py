##############################################################################
#
# Copyright (c) 2016 Vifib SARL and Contributors. All Rights Reserved.
#
# WARNING: This program as such is intended to be used by professional
# programmers who take the whole responsibility of assessing all potential
# consequences resulting from its eventual inadequacies and bugs
# End users who are looking for a ready-to-use solution with commercial
# guarantees and support are strongly advised to contract a Free Software
# Service Company
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 3
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
##############################################################################

from __future__ import division
import gzip, errno, json, os, select, shutil, socket, stat
import subprocess, sys, tempfile, threading, time
from io import BytesIO
from collections import defaultdict
from contextlib import closing, contextmanager
from os.path import join
from zc.buildout import UserError
from .utils import EnvironMixin, generatePassword, is_true, rmtree

if str is bytes:
  bytes2str = str2bytes = lambda s: s
else:
  bytes2str = bytes.decode
  str2bytes = str.encode

try:
  from urllib.parse import urlparse
except ImportError:
  from urlparse import urlparse

ARCH = os.uname()[4]

@contextmanager
def building_directory(directory):
  rmtree(directory)
  os.makedirs(directory)
  try:
    yield
  except:
    shutil.rmtree(directory)
    raise

def dumb_yaml(lines, v, indent=''): # to avoid a dependency
  if isinstance(v, dict):
    for k, v in v.items():
      lines.append(indent + k + ':')
      dumb_yaml(lines, v, indent + '  ')
  elif isinstance(v, (list, tuple)):
    j = indent + '-'
    for v in v:
      lines.append(j)
      dumb_yaml(lines, v, indent + '  ')
  else:
    if isinstance(v, str):
      if '\n' in v:
        v = ('|\n' + v).replace('\n', '\n' + indent)
      else:
        v = "'" + v.replace("'", "''") + "'"
    else:
      v = ('true' if v else 'false') if isinstance(v, bool) else str(v)
    lines[-1] += ' ' + v


class Popen(subprocess.Popen):

  def stop(self):
    if self.pid and self.returncode is None:
      self.terminate()
      t = threading.Timer(5, self.kill)
      t.start()
      # PY3: use waitid(WNOWAIT) and call self.poll() after t.cancel()
      r = self.wait()
      t.cancel()
      return r


class CPIO(object):

  ino = 1
  prefix = None

  def __init__(self):
    self.buf = BytesIO()
    self.mtime = int(time.time())
    self.dirs = {'', 'scripts'}

  def _add(self, path, mode, data='',
          _header=b"070701" + b"%08x" * 13):
    prefix = self.prefix
    if prefix:
      path = prefix + path
    parent = os.path.dirname(path)
    if parent not in self.dirs:
      self.prefix = None
      self.add_dir(parent)
      self.prefix = prefix
    if type(data) is not bytes:
      data = data.encode()
    path = str2bytes(path)
    size = len(data)
    path_len = len(path)
    write = self.buf.write
    write(_header % (self.ino, mode, 0, 0, 1,
      self.mtime, size, 0, 0, 0, 0, path_len + 1, 0))
    write(path + b'\0' * (4 - (path_len + 2) % 4))
    write(data + b'\0' * ((4 - size) % 4))
    self.ino += 1

  def add_dir(self, path, mode=0o755):
    self._add(path, mode | stat.S_IFDIR)
    self.dirs.add(path)

  def add_file(self, path, data, mode=0o644):
    self._add(path, mode | stat.S_IFREG, data)

  def add_link(self, path, target):
    self._add(path, 0o777 | stat.S_IFLNK, target)

  def close(self):
    self.ino = self.mtime = 0
    try:
      self._add("TRAILER!!!", 0)
      self.buf.write(b'\0' * ((512 - self.buf.tell()) % 512))
      return self.buf
    finally:
      self.__dict__.clear()


class BaseRecipe(EnvironMixin):

  def __init__(self, buildout, name, options, allow_none=True):
    self.buildout = buildout
    self.name = name
    self.options = options
    try:
      options['location'] = options['location'].strip()
    except KeyError:
      options['location'] = join(buildout['buildout']['parts-directory'], name)
    EnvironMixin.__init__(self, allow_none)
    self.vnc_sock = options.get('vnc-sock')
    self.ssh_addr = options.get('ssh-addr')

  def getQemuBasicArgs(self, dist, mem=None, snapshot=False,
                             unsafe=False, ssh=None):
    drive = 'file=%s.img,format=raw,discard=on' \
      % join(self.vm, dist).replace(',', ',,')
    if snapshot:
      drive += ',snapshot=on'
    elif unsafe:
      drive += ',cache=unsafe'
    net = 'user'
    if ssh:
      net += ',hostfwd=tcp:127.0.0.1:%s-:22' % ssh
    elif self.ssh_addr:
      net += ',hostfwd=tcp:%s-:22' % self.ssh_addr
    try:
      mem = eval(self.options['mem'], {})
    except KeyError:
      if mem is None:
        raise
    args = ['qemu-system-' + ARCH, '-enable-kvm', '-cpu', 'host',
            '-smp', self.options.get('smp', '1'), '-m', str(mem),
            '-drive', drive, '-net', 'nic,model=virtio', '-net', net,
            '-nodefaults', '-vga', 'std',
            # https://daniel-lange.com/archives/152-hello-buster.html
            '-object', 'rng-random,filename=/dev/urandom,id=rng0',
            '-device', 'virtio-rng-pci,rng=rng0']
    for drive in self.options.get('drives', '').splitlines():
        args += '-drive', drive
    return args

  @property
  def ssh_key(self):
    return join(self.vm, 'ssh.key')

  def update(self):
    pass


class InstallBaseRecipe(BaseRecipe):

  SUDO = 'sudo'
  ssh_pub = None

  def __init__(self, buildout, name, options):
    BaseRecipe.__init__(self, buildout, name, options)
    self.vm = options['location']
    self.dists = dists = []
    arch = options.get('arch') or ARCH
    for name in options['dists'].split():
      dist = buildout[name]
      iso = buildout[dist[arch + '.iso']]
      dists.append((name,
        join(iso['location'], iso['filename']),
        dist[arch + '.kernel'],
        dist[arch + '.initrd']))

    self.early_command = (options.get('early-command') or '').strip()
    late_command = (options.get('late-command') or '').strip()
    self.late_command = [late_command] if late_command else []

    size = options['size'].strip()
    i = -2 if size[-1] == 'i' else -1
    try:
      size = (1024, 1000)[i] ** ' kMGTP'.index(size[i]) * eval(size[:i])
    except ValueError:
      self.size = eval(size)
    else:
      self.size = (1 + int(size / 512)) * 512 if size % 512 else int(size)

  def install(self):
    options = self.options
    preseed = defaultdict(dict)
    common = preseed[None]
    self.defaults(common)
    file_dict = {}
    for k, v in options.items():
      try:
        p, k = k.split('.', 1)
        p = p.rsplit('/', 1)
        x = (self.AUTO, 'debconf', 'file', 'exec', 'link').index(p.pop())
      except ValueError:
        continue
      if x > 1:
        if p:
          raise NotImplementedError
        file_dict[k] = x - 2, v
        continue
      p = preseed[p[0]] if p else common
      if x:
        for x in v.splitlines():
          try:
            x, v = x.split(None, 1)
          except ValueError:
            if not x:
              continue
            v = ''
          p[(k, x)] = v
      else:
        p[self.alias(k, p is common)] = (
          json.loads(v[5:]) if v.startswith('json:') else
          v.strip())

    vm_run = is_true(options.get('vm.run'), True)
    packages = options.get('packages', '').split()
    if vm_run:
      packages.append('ssh')
      sudo = self.SUDO
      if sudo:
        packages.append(sudo)
    if packages:
      self.packages(common, packages)

    passwd = self.users(common)
    env = self.environ

    location = self.vm
    with building_directory(location):
      if vm_run:
        key = self.ssh_key
        subprocess.check_call(('ssh-keygen', '-N', '', '-t', 'ed25519',
                               '-f', key), env=env)
        key += '.pub'
        with open(key) as f:
          os.remove(key)
          key = self.ssh_pub = f.read().strip()
        self.late_command.append(
          "mkdir -pm 0700 ~/.ssh\n"
          "echo %s > ~/.ssh/authorized_keys\n" % key)
      for dist, iso, kernel, initrd in self.dists:
        cpio = CPIO()
        p = common.copy()
        p.update(preseed.get(dist, ()))
        self.initrd(cpio, p, dist)
        for k, (x, v) in file_dict.items():
          if x > 1:
            cpio.add_link(k, v)
          else:
            if v.startswith('inline:'):
              v = v[7:]
            else:
              with open(v, 'rb') as v:
                v = v.read()
            cpio.add_file(k, v, 0o755 if x else 0o644)

        vm = join(location, dist + '.img')
        args = self.getQemuBasicArgs(dist, self.INSTALL_RAM, unsafe=True)
        open_flags = os.O_CREAT | os.O_EXCL | os.O_WRONLY
        fd = os.open(vm, open_flags, 0o666)
        try:
          os.ftruncate(fd, self.size)
        finally:
          os.close(fd)
        tmp = tempfile.mkdtemp()
        try:
          subprocess.check_call(('7z', 'x', iso, kernel, initrd),
                                cwd=tmp, env=env)
          initrd = join(tmp, initrd)
          with gzip.open(initrd, 'ab') as f:
            f.write(cpio.close().getvalue())
          args += (
             # vnc is for debugging purpose
            '-vnc', 'unix:' + (self.vnc_sock or join(tmp, 'vnc.sock')),
            '-cdrom', iso, '-no-reboot',
            '-kernel', join(tmp, kernel),
            '-initrd', initrd)
          subprocess.check_call(args, env=env)
        finally:
          shutil.rmtree(tmp)
        if not subprocess.check_output(('file', '-b', vm), env=env).startswith(
            b'DOS/MBR boot sector'):
          raise Exception('non bootable image')

      if passwd:
        fd = os.open(join(location, 'passwd'), open_flags, 0o600)
        try:
          for passwd in passwd:
            os.write(fd, str2bytes("%s:%s\n" % passwd))
        finally:
          os.close(fd)

    return [location]


class InstallDebianRecipe(InstallBaseRecipe):

  # WARNING: The installer may fail weirdly when there's not enough RAM,
  #          like "No network interfaces detected".
  #          See https://bugs.debian.org/842201
  INSTALL_RAM = 512

  AUTO = 'preseed'

  preseed = """
    auto = true
    # Low memory mode is also faster.
    lowmem/low = note
    priority = critical
    partman/choose_partition = finish
    partman-basicfilesystems/no_swap = false
    partman/confirm = true
    partman/confirm_nooverwrite = true
    grub-installer/bootdev = default
    finish-install/reboot_in_progress = note

    clock-setup/ntp = false
    time/zone = UTC
    language = C
    country = FR
    keymap = us
    passwd/make-user = false
    passwd/root-login = true
    partman-auto/method = regular
    partman-auto/expert_recipe = : 1 1 1 - method{ biosgrub } . 1 2 -1 - method{ format } format{ } use_filesystem{ } filesystem{ xfs } mountpoint{ / } options/noatime{ } .
    partman-partitioning/default_label = gpt
    """

  # XXX: The mapping should be automatically computed from the
  #      /etc/preseed_aliases in the initrd.
  _alias = (lambda alias: staticmethod(lambda x: alias(x, x)))({
      'auto':       'auto-install/enable',
      'classes':    'auto-install/classes',
      'country':    'debian-installer/country',
      'desktop':    ('tasksel', 'tasksel/desktop'),
      'dmraid':     'disk-detect/dmraid/enable',
      'domain':     'netcfg/get_domain',
      'fb':         'debian-installer/framebuffer',
      'hostname':   'netcfg/get_hostname',
      'interface':  'netcfg/choose_interface',
      'keymap':     'keyboard-configuration/xkb-keymap',
      'language':   'debian-installer/language',
      'locale':     'debian-installer/locale',
      'modules':    'anna/choose_modules',
      'priority':   'debconf/priority',
      'protocol':   'mirror/protocol',
      'recommends': 'base-installer/install-recommends',
      'suite':      'mirror/suite',
      'tasks':      ('tasksel', 'tasksel/first'),
    }.get)

  def defaults(self, preseed):
    for p in self.preseed.splitlines():
      p = p.strip()
      if p and p[0] != '#':
        k, v = p.split('=', 1)
        preseed[self._alias(k.strip())] = v.strip()

  def alias(self, key, common):
    key = self._alias(key)
    if isinstance(key, str):
      if key in ('pkgsel/include',
                 'partman/early_command',
                 'preseed/late_command'):
        raise UserError('Use the recipe-specific option instead of %s.' % key)
      if key in ('preseed/url', 'preseed/file', 'preseed/file/checksum'):
        # We could extend a provided preseed file.
        raise NotImplementedError
      if key.startswith('passwd/') and not common:
        raise NotImplementedError
    return key

  def packages(self, preseed, packages):
    preseed['pkgsel/include'] = ','.join(packages)

  def users(self, preseed):
    generated = []
    for x, p in (('root', 'passwd/root-login'),
                 ('user', 'passwd/make-user')):
      if is_true(preseed[p]):
        p = 'passwd/%s-password' % x
        if x == 'user':
          x = preseed.get('passwd/username')
          if not x:
            raise UserError('passwd/username is empty')
          preseed.setdefault('passwd/user-fullname', '')
        if not preseed.get(p + '-crypted'):
          if not preseed.get(p):
            preseed[p] = generatePassword()
            generated.append((x, preseed[p]))
          preseed[p + '-again'] = preseed[p]
    return generated

  def initrd(self, cpio, preseed, dist):
    if self.early_command:
      preseed['partman/early_command'] = 'exec /early-command'
      cpio.add_file('early-command', '#!/bin/sh -e\nDIST=%s\n%s\n'
        % (dist, self.early_command), 0o755)
    if self.late_command:
      preseed['preseed/late_command'] = ('set -e /target/installer;'
        ' mkdir $1; mount --bind / $1; umount cdrom;'
        ' in-target /installer/late-command /installer || x=$?;'
        ' umount $1; rmdir $1; load-install-cd /target; exit $x')
      cpio.add_file('late-command', '#!/bin/sh -e\n'
        'export HOME=/root; DIST=%s\n%s\n'
        % (dist, '\n'.join(self.late_command)), 0o755)
    cpio.add_file('preseed.cfg', ''.join(sorted(
      "%s string %s\n" % ('%s %s' % k if type(k) is tuple else
                          'd-i ' + k, v)
      for k, v in preseed.items())))


class InstallUbuntuRecipe(InstallBaseRecipe):

  INSTALL_RAM = 2048

  AUTO = 'autoinstall'
  SUDO = None # it should already be installed by default

  def defaults(self, preseed):
    preseed['identity.hostname'] = 'ubuntu'
    preseed['storage.swap.size'] = 0
    preseed['storage.config'] = {
      'id': 'disk',
      'type': 'disk',
      'ptable': 'gpt',
      'grub_device': True,
    }, {
      'id': 'bios',
      'type': 'partition',
      'device': 'disk',
      'size': '1M',
      'flag': 'bios_grub',
    }, {
      'id': 'root',
      'type': 'partition',
      'device': 'disk',
      'size': -1,
    }, {
      'id': 'format',
      'type': 'format',
      'fstype': 'xfs',
      'volume': 'root',
    }, {
      'id': 'mount',
      'type': 'mount',
      'path': '/',
      'device': 'format',
      'options': 'noatime',
    }

  def alias(self, key, common):
    if key in ('packages', 'early-commands', 'late-commands'):
      raise UserError('Use the recipe-specific option instead of %s.' % key)
    if '/' in key:
      raise UserError('Invalid autoinstall key: ' + key)
    return key

  def packages(self, preseed, packages):
    preseed['packages'] = packages

  def users(self, preseed):
    # TODO
    return ()

  def initrd(self, cpio, preseed, dist):
    cpio.add_file('scripts/slapos', """
      BOOT=casper
      . scripts/$BOOT
      echo '(cd /autoinstall && find |$rootmnt/bin/cpio -pu $rootmnt)' \
        >>scripts/init-bottom/ORDER
      """)
    cpio.prefix = 'autoinstall/'
    if self.ssh_pub:
      cpio.add_file('root/.ssh/authorized_keys', self.ssh_pub)
    if self.early_command:
      preseed['early-commands'] = ['exec /early-command']
      cpio.add_file('early-command', '#!/bin/sh -e\nDIST=%s\n%s\n'
        % (dist, self.early_command), 0o755)
    if self.late_command:
      preseed['late-commands'] = ['set -e /target/installer;'
        ' mkdir $1; mount --bind / $1;'
        ' curtin in-target -- /installer/late-command /installer || x=$?;'
        ' umount $1; rmdir $1; exit $x']
      cpio.add_file('late-command', '#!/bin/sh -e\n'
        'export HOME=/root; DIST=%s\n%s\n'
        % (dist, '\n'.join(self.late_command)), 0o755)
    yaml = {'version': 1}
    debconf = []
    for k, v in preseed.items():
      if isinstance(k, tuple):
        debconf.append('%s %s string %s' % (k + (v,)))
      else:
        z = k.split('.')
        k = z.pop()
        x = yaml
        for z in z:
          x = x.setdefault(z, {})
        x[k] = v
    if debconf:
      yaml['debconf-selections'] = '\n'.join(debconf)
    lines = []
    dumb_yaml(lines, yaml)
    cpio.add_file('autoinstall.yaml', '\n'.join(lines))

  def getQemuBasicArgs(self, *args, **kw):
    args = super(InstallUbuntuRecipe, self).getQemuBasicArgs(*args, **kw)
    args += '-append', 'autoinstall boot=slapos'
    return args


class RunRecipe(BaseRecipe):

  init = """set -e
cd /mnt; set %s; mkdir -p $*; cd; for tag; do
  mount -t 9p -o trans=virtio,version=9p2000.L,noatime $tag /mnt/$tag
done
"""

  command = """set -e
reboot() {
  unset -f reboot
  %s%s
  (while pgrep -x sshd; do sleep 1; done >/dev/null; %sreboot
  ) >/dev/null 2>&1 &
  exit
}
map() {
  local x=${1#%s}; case $x in $1) exit 1;; ''|/*) ;; *) exit 1;; esac
  echo /mnt/buildout$x
}
PARTDIR=`map %s`
"""

  def __init__(self, buildout, name, options):
    BaseRecipe.__init__(self, buildout, name, options, False)
    self.vm = options['vm']
    self.mount_dict = {'buildout': buildout['buildout']['directory']}
    for k, v in options.items():
      if k == 'mount.buildout':
        raise UserError('option %r can not be overridden' % k)
      v = v.strip()
      if k.startswith('mount.') and v:
        self.mount_dict[k[6:]] = v

  def install(self):
    env = self.environ
    options = self.options
    location = options['location']
    mount_args = []
    for i, (tag, path) in enumerate(self.mount_dict.items()):
      mount_args += (
        '-fsdev', 'local,security_model=none,id=fsdev%s,path=%s'
          % (i, path),
        '-device', 'virtio-9p-pci,id=fs%s,fsdev=fsdev%s,mount_tag=%s'
          % (i, i, tag))
    init = self.init % ' '.join(self.mount_dict)
    user = options.get('user')
    if user == 'root':
      init += 'cd; exec sh'
      sudo = ''
    else:
      sudo = 'sudo '
      if not user:
        init += """user=slapos gid=%s
cd /etc/sudoers.d
[ -f $user ] || {
  groupadd -g $gid $user || :
  useradd -m -u %s -g $gid $user
  echo $user ALL=NOPASSWD: ALL >$user
  chmod 440 $user
}
""" % (os.getgid(), os.getuid())
        user = '$user'
      init += 'exec su -ls /bin/sh ' + user

    header = self.command % (
      sudo, options.get('stop-ssh', 'systemctl stop ssh'), sudo,
      self.buildout['buildout']['directory'], location)
    commands = [options[k] for k in options.get('commands', 'command').split()]
    hostfwd_retries = 9
    wait_ssh = int(options.get('wait-ssh') or 60)
    with building_directory(location):
      tmp = None
      try:
        vnc = self.vnc_sock
        if not vnc:
          tmp = tempfile.mkdtemp()
          vnc = join(tmp, 'vnc.sock')
        # Unfortunately, QEMU can't redirect from host socket to guest TCP (SSH
        # does it), so we try a random port until QEMU is able to listen to it.
        # In order to speed up the process, we request free ports from the
        # kernel, but we still have to retry in case of race condition.
        # We assume that QEMU sets up host redirection before creating the VNC
        # socket path.
        while 1:
          s = None
          try:
            if self.ssh_addr:
              ssh = urlparse('//' + self.ssh_addr)
              ssh = ssh.hostname, ssh.port
              port = None
            else:
              s = socket.socket(socket.AF_INET)
              s.bind(('127.0.0.1', 0))
              ssh = s.getsockname()
              port = ssh[1]
            args = self.getQemuBasicArgs(
              options['dist'], vnc, snapshot=True, ssh=port)
            args += '-vnc', 'unix:' + vnc
            args += mount_args
          finally:
            if s is not None:
              s.close()
          qemu = Popen(args, stderr=subprocess.PIPE, env=dict(env,
            TMPDIR=location, # for snapshot
            ))
          try:
            with closing(socket.socket(socket.AF_UNIX)) as s:
              while not select.select((qemu.stderr,), (), (), 1)[0]:
                try:
                  s.connect(vnc)
                  break
                except socket.error as e:
                  if errno.ENOENT != e.errno != errno.ECONNREFUSED:
                    raise
              else:
                err = qemu.communicate()[1]
                sys.stderr.write(err)
                if (b'could not set up host forwarding rule' in err and
                    hostfwd_retries):
                  hostfwd_retries -= 1
                  continue
                raise subprocess.CalledProcessError(qemu.returncode, args)
            for command in commands:
              timeout = time.time() + wait_ssh
              while 1:
                with closing(socket.socket(socket.AF_INET)) as s:
                  s.connect(ssh)
                  if s.recv(4) == b'SSH-':
                    break
                if time.time() >= timeout:
                  raise Exception("Can not SSH to VM after %s seconds"
                                  % wait_ssh)
                time.sleep(1)
              args = ('ssh', '-i', self.ssh_key,
                '-o', 'BatchMode=yes',
                '-o', 'UserKnownHostsFile=' + os.devnull,
                '-o', 'StrictHostKeyChecking=no',
                '-p', str(ssh[1]), 'root@' + ssh[0], init)
              p = Popen(args, stdin=subprocess.PIPE, env=env)
              try:
                p.communicate(str2bytes(header + command))
                if p.returncode:
                  raise subprocess.CalledProcessError(p.returncode, args)
              finally:
                p.stop()
          finally:
            qemu.stop()
          break
      finally:
        if tmp:
          shutil.rmtree(tmp)
    return [location]
