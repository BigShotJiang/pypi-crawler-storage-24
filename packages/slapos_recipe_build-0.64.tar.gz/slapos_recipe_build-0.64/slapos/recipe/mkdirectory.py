##############################################################################
#
# Copyright (c) 2010 Vifib SARL and Contributors. All Rights Reserved.
#
# WARNING: This program as such is intended to be used by professional
# programmers who take the whole responsibility of assessing all potential
# consequences resulting from its eventual inadequacies and bugs
# End users who are looking for a ready-to-use solution with commercial
# guarantees and support are strongly adviced to contract a Free Software
# Service Company
#
# This program is Free Software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 3
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
#
##############################################################################
import errno
import os


class Recipe(object):

  def __init__(self, buildout, name, options):
    self.directory = options.copy()
    del self.directory['recipe']
    self.mode = int(self.directory.pop('mode', '0777'), 8)

  def update(self):
    return self.install()

  def install(self):
    for path in sorted(self.directory.values()):
      if path:
        try:
          os.makedirs(path, self.mode)
        except OSError as e:
          if e.errno != errno.EEXIST:
            raise
    # WARNING: This recipe is currently used to create directories that will
    #          contain user data  (e.g. NEO db). Such directories must never
    #          be purged by the uninstallation of a recipe.
    return []
