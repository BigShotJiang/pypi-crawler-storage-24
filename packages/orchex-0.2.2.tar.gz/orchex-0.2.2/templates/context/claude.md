# AI Orchestra

**概要**: Claude Code + Codex CLI + Gemini CLI の協調実行を管理する Python 製オーケストレーション基盤。

---

## 目的

- `orchex` CLI で packages/templates/scripts を配布・同期する
- 既存導入プロジェクトの互換性を壊さずに設定と運用を進化させる
- 複数プロジェクトへ横展開しやすいテンプレート運用を維持する

---

## 技術スタック

- **Language**: Python 3.12+
- **Packaging**: Hatchling (`pyproject.toml`), PyPI package `orchex`
- **Quality**: `pytest`, `ruff`
- **Config**: YAML / JSON (`.claude/config/**`)

---

## 主要コマンド

```bash
# 開発依存込みでインストール
pip install -e ".[dev]"

# テスト
pytest -q
pytest -q tests/test_orchestra_manager_context.py

# Lint / Format
ruff check .
ruff format --check .

# コンテキストテンプレート管理
python scripts/orchestra-manager.py context build
python scripts/orchestra-manager.py context check
python scripts/orchestra-manager.py context sync --project .
```

---

## ディレクトリ構成

```text
ai_orchestra/                # Python package entrypoint
packages/                    # 配布パッケージ群（hooks/agents/config）
facets/                      # ファセット定義（policies/instructions/knowledge/scripts/compositions）
scripts/                     # 管理 CLI（orchestra-manager.py など）
templates/                   # 配布テンプレート
templates/context/           # 指示書のソース（手編集する場所）
tests/                       # unit tests
.claude/                     # 実行コンテキスト（agents/config は sync、skills/rules は facet build）
```

---

## 指示書テンプレートの責務

- `templates/context/claude.md` を編集すると `templates/project/CLAUDE.md` と `<project>/CLAUDE.md` に反映される
- `templates/context/codex.md` は `AGENTS.md` 系、`templates/context/gemini.md` は `GEMINI.md` 系のソース
- `templates/project/CLAUDE.md`, `templates/codex/AGENTS.md`, `templates/gemini/GEMINI.md` は generated 扱いで直接編集しない

---

## 変更ガードレール

- 既存 CLI コマンドと設定キー（特に `.claude/config/**`）の後方互換性を優先する
- `config-loading` ルールに従い `*.local.*` 上書きを壊さない
- 仕様変更時は `README.md` と必要なテストを同時更新する
