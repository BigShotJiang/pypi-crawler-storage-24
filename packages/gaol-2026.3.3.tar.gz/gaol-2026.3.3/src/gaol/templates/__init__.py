"""Template gallery for curated container configurations.

This module provides a template gallery feature for discovering,
sharing, and using curated container configurations.

Example:
    >>> from gaol.templates import get_template_loader
    >>>
    >>> # Get a template
    >>> loader = get_template_loader()
    >>> template = loader.get("web-dev/django")
    >>> print(template.metadata.description)
    >>>
    >>> # List local templates
    >>> for t in loader.list_local():
    ...     print(f"{t.metadata.id}: {t.metadata.display_name}")
    >>>
    >>> # Search templates
    >>> results = loader.search("python web")
    >>> for entry in results:
    ...     print(f"{entry.id}: {entry.description}")
"""

from __future__ import annotations

from gaol.templates.builtin import (
    BUILTIN_TEMPLATES,
    get_builtin_categories,
    get_builtin_template,
    list_builtin_templates,
)
from gaol.templates.exceptions import (
    CategoryNotFoundError,
    GalleryError,
    GalleryFetchError,
    GalleryIndexError,
    GalleryOfflineError,
    TemplateError,
    TemplateExistsError,
    TemplateNotFoundError,
    TemplateParseError,
    TemplateStoreError,
    TemplateValidationError,
)
from gaol.templates.fetcher import TemplateFetcher
from gaol.templates.gallery import GalleryManager
from gaol.templates.loader import TemplateLoader, get_template_loader
from gaol.templates.models import (
    DEFAULT_CATEGORIES,
    CategoryInfo,
    GalleryIndex,
    Template,
    TemplateEntry,
    TemplateMetadata,
)
from gaol.templates.store import TemplateStore, get_template_store

__all__ = [
    # Loader
    "TemplateLoader",
    "get_template_loader",
    # Store
    "TemplateStore",
    "get_template_store",
    # Gallery
    "GalleryManager",
    "TemplateFetcher",
    # Models
    "Template",
    "TemplateMetadata",
    "TemplateEntry",
    "GalleryIndex",
    "CategoryInfo",
    "DEFAULT_CATEGORIES",
    # Built-in
    "BUILTIN_TEMPLATES",
    "get_builtin_template",
    "list_builtin_templates",
    "get_builtin_categories",
    # Exceptions
    "TemplateError",
    "TemplateNotFoundError",
    "TemplateParseError",
    "TemplateValidationError",
    "TemplateExistsError",
    "TemplateStoreError",
    "GalleryError",
    "GalleryFetchError",
    "GalleryIndexError",
    "GalleryOfflineError",
    "CategoryNotFoundError",
]
