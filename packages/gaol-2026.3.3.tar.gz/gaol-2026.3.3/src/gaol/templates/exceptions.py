"""Exceptions for template gallery operations."""

from __future__ import annotations


class TemplateError(Exception):
    """Base exception for template operations."""

    pass


class TemplateNotFoundError(TemplateError):
    """Template not found in any source."""

    def __init__(self, template_id: str, searched: list[str] | None = None) -> None:
        searched_str = ""
        if searched:
            searched_str = f" (searched: {', '.join(searched)})"
        super().__init__(f"Template not found: {template_id}{searched_str}")
        self.template_id = template_id
        self.searched = searched or []


class TemplateParseError(TemplateError):
    """Failed to parse template file."""

    def __init__(
        self,
        template_id: str,
        reason: str,
        cause: Exception | None = None,
    ) -> None:
        super().__init__(f"Failed to parse template '{template_id}': {reason}")
        self.template_id = template_id
        self.reason = reason
        self.cause = cause


class TemplateValidationError(TemplateError):
    """Template validation failed."""

    def __init__(
        self,
        template_id: str,
        errors: list[str],
    ) -> None:
        error_list = "\n  - ".join(errors)
        super().__init__(
            f"Template '{template_id}' validation failed:\n  - {error_list}"
        )
        self.template_id = template_id
        self.errors = errors


class TemplateExistsError(TemplateError):
    """Template already exists."""

    def __init__(self, template_id: str, location: str | None = None) -> None:
        msg = f"Template already exists: {template_id}"
        if location:
            msg += f" (at {location})"
        super().__init__(msg)
        self.template_id = template_id
        self.location = location


class GalleryError(TemplateError):
    """Base exception for gallery operations."""

    pass


class GalleryFetchError(GalleryError):
    """Failed to fetch from remote gallery."""

    def __init__(
        self,
        url: str,
        reason: str,
        cause: Exception | None = None,
    ) -> None:
        super().__init__(f"Failed to fetch from gallery: {reason}")
        self.url = url
        self.reason = reason
        self.cause = cause


class GalleryIndexError(GalleryError):
    """Failed to parse gallery index."""

    def __init__(
        self,
        reason: str,
        cause: Exception | None = None,
    ) -> None:
        super().__init__(f"Invalid gallery index: {reason}")
        self.reason = reason
        self.cause = cause


class GalleryOfflineError(GalleryError):
    """Gallery is not accessible."""

    def __init__(self, url: str, reason: str | None = None) -> None:
        msg = f"Gallery is not accessible: {url}"
        if reason:
            msg += f" ({reason})"
        super().__init__(msg)
        self.url = url
        self.reason = reason


class TemplateStoreError(TemplateError):
    """Error with template storage."""

    def __init__(self, operation: str, reason: str) -> None:
        super().__init__(f"Template store {operation} failed: {reason}")
        self.operation = operation
        self.reason = reason


class CategoryNotFoundError(TemplateError):
    """Category not found."""

    def __init__(self, category: str) -> None:
        super().__init__(f"Category not found: {category}")
        self.category = category
