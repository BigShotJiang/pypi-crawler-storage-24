"""Tor integration for privacy networking.

This module provides Tor-based privacy features:
- Tor proxy: Route container traffic through Tor
- Hidden services: Expose containers as .onion addresses
- Transparent proxy: Redirect all traffic through Tor

Example:
    >>> from gaol.privacy.tor import TorBackend, TorProxyManager
    >>> backend = TorBackend()
    >>> if backend.is_available():
    ...     manager = TorProxyManager()
    ...     proxy = manager.create("mytor", "mycontainer")
    ...     print(f"SOCKS port: {proxy.socks_port}")
"""

from __future__ import annotations

from gaol.privacy.tor.backend import TorBackend
from gaol.privacy.tor.manager import HiddenServiceManager, TorProxyManager

__all__ = [
    "TorBackend",
    "TorProxyManager",
    "HiddenServiceManager",
]
