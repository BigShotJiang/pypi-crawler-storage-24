"""WireGuard mesh networking for privacy networking.

This module provides WireGuard mesh network functionality:
- Create encrypted mesh networks between containers
- Peer management
- Key generation

Example:
    >>> from gaol.privacy.wireguard import WireGuardMeshManager
    >>> manager = WireGuardMeshManager()
    >>> mesh = manager.create("mymesh", subnet="10.200.0.0/24")
    >>> manager.add_peer(mesh.name, peer_name="peer1", public_key="...")
"""

from __future__ import annotations

from gaol.privacy.wireguard.backend import WireGuardBackend
from gaol.privacy.wireguard.manager import WireGuardMeshManager

__all__ = [
    "WireGuardBackend",
    "WireGuardMeshManager",
]
