"""Privacy networking exceptions."""

from __future__ import annotations


class PrivacyError(Exception):
    """Base exception for privacy networking errors."""

    pass


# Tor Exceptions


class TorError(PrivacyError):
    """Base exception for Tor-related errors."""

    pass


class TorNotFoundError(TorError):
    """Tor binary not found."""

    def __init__(self) -> None:
        super().__init__(
            "tor not found. Install with: "
            "apt install tor (Debian/Ubuntu) or see https://www.torproject.org/download/"
        )


class TorProxyAlreadyExistsError(TorError):
    """Tor proxy already exists with this name."""

    def __init__(self, name: str) -> None:
        self.name = name
        super().__init__(f"Tor proxy already exists: {name}")


class TorProxyNotFoundError(TorError):
    """Tor proxy not found."""

    def __init__(self, name: str) -> None:
        self.name = name
        super().__init__(f"Tor proxy not found: {name}")


class TorBootstrapError(TorError):
    """Tor failed to bootstrap."""

    def __init__(self, progress: int, reason: str = "") -> None:
        self.progress = progress
        self.reason = reason
        msg = f"Tor failed to bootstrap (progress: {progress}%)"
        if reason:
            msg += f": {reason}"
        super().__init__(msg)


class HiddenServiceAlreadyExistsError(TorError):
    """Hidden service already exists with this name."""

    def __init__(self, name: str) -> None:
        self.name = name
        super().__init__(f"Hidden service already exists: {name}")


class HiddenServiceNotFoundError(TorError):
    """Hidden service not found."""

    def __init__(self, name: str) -> None:
        self.name = name
        super().__init__(f"Hidden service not found: {name}")


# VPN Exceptions


class VPNError(PrivacyError):
    """Base exception for VPN-related errors."""

    pass


class VPNGatewayAlreadyExistsError(VPNError):
    """VPN gateway already exists with this name."""

    def __init__(self, name: str) -> None:
        self.name = name
        super().__init__(f"VPN gateway already exists: {name}")


class VPNGatewayNotFoundError(VPNError):
    """VPN gateway not found."""

    def __init__(self, name: str) -> None:
        self.name = name
        super().__init__(f"VPN gateway not found: {name}")


class VPNConnectionError(VPNError):
    """VPN connection failed."""

    def __init__(self, reason: str) -> None:
        self.reason = reason
        super().__init__(f"VPN connection failed: {reason}")


class VPNConfigError(VPNError):
    """Invalid VPN configuration."""

    def __init__(self, reason: str) -> None:
        self.reason = reason
        super().__init__(f"Invalid VPN configuration: {reason}")


# WireGuard Exceptions


class WireGuardError(PrivacyError):
    """Base exception for WireGuard-related errors."""

    pass


class WireGuardNotFoundError(WireGuardError):
    """WireGuard tools not found."""

    def __init__(self) -> None:
        super().__init__(
            "wireguard-tools not found. Install with: "
            "apt install wireguard-tools (Debian/Ubuntu) or see https://www.wireguard.com/install/"
        )


class WireGuardMeshAlreadyExistsError(WireGuardError):
    """WireGuard mesh already exists with this name."""

    def __init__(self, name: str) -> None:
        self.name = name
        super().__init__(f"WireGuard mesh already exists: {name}")


class WireGuardMeshNotFoundError(WireGuardError):
    """WireGuard mesh not found."""

    def __init__(self, name: str) -> None:
        self.name = name
        super().__init__(f"WireGuard mesh not found: {name}")


class WireGuardPeerError(WireGuardError):
    """WireGuard peer configuration error."""

    def __init__(self, peer: str, reason: str) -> None:
        self.peer = peer
        self.reason = reason
        super().__init__(f"WireGuard peer error ({peer}): {reason}")


# Firewall Exceptions


class FirewallError(PrivacyError):
    """Base exception for firewall-related errors."""

    pass


class FirewallNotAvailableError(FirewallError):
    """No supported firewall backend available."""

    def __init__(self) -> None:
        super().__init__(
            "No supported firewall backend found. "
            "Install iptables or nftables."
        )


class FirewallRuleError(FirewallError):
    """Failed to apply firewall rule."""

    def __init__(self, rule: str, reason: str) -> None:
        self.rule = rule
        self.reason = reason
        super().__init__(f"Failed to apply firewall rule: {reason}")


class InsufficientPermissionsError(PrivacyError):
    """Insufficient permissions for operation."""

    def __init__(self, operation: str) -> None:
        self.operation = operation
        super().__init__(
            f"Insufficient permissions for {operation}. "
            "This operation may require root privileges."
        )
