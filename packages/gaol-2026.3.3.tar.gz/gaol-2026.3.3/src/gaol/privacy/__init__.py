"""Privacy networking for containers.

This module provides privacy-focused networking features:
- Tor proxy: Route container traffic through Tor
- Hidden services: Expose containers as .onion addresses
- VPN gateway: Route containers through VPN connections
- WireGuard mesh: Create encrypted mesh networks
- DNS leak prevention: Block unauthorized DNS queries

Example (Tor proxy):
    >>> from gaol.privacy import TorProxyManager, TorProxyConfig
    >>> manager = TorProxyManager()
    >>> config = TorProxyConfig(transparent=True)
    >>> proxy = manager.create("mytor", "myapp", config)
    >>> print(f"SOCKS port: {proxy.socks_port}")
    >>> manager.delete("mytor")

Example (Hidden service):
    >>> from gaol.privacy import HiddenServiceManager, HiddenServiceConfig
    >>> manager = HiddenServiceManager()
    >>> config = HiddenServiceConfig(
    ...     name="web",
    ...     container_name="nginx",
    ...     container_port=80,
    ... )
    >>> service = manager.create(config)
    >>> print(f"Onion address: {service.onion_address}")
"""

from __future__ import annotations

from gaol.privacy.exceptions import (
    FirewallError,
    FirewallNotAvailableError,
    FirewallRuleError,
    HiddenServiceAlreadyExistsError,
    HiddenServiceNotFoundError,
    InsufficientPermissionsError,
    PrivacyError,
    TorBootstrapError,
    TorError,
    TorNotFoundError,
    TorProxyAlreadyExistsError,
    TorProxyNotFoundError,
    VPNConfigError,
    VPNConnectionError,
    VPNError,
    VPNGatewayAlreadyExistsError,
    VPNGatewayNotFoundError,
    WireGuardError,
    WireGuardMeshAlreadyExistsError,
    WireGuardMeshNotFoundError,
    WireGuardNotFoundError,
    WireGuardPeerError,
)
from gaol.privacy.firewall import FirewallBackend, PrivacyFirewall
from gaol.privacy.models import (
    DNSLeakConfig,
    HiddenServiceConfig,
    HiddenServiceState,
    PrivacyMode,
    PrivacyStatus,
    TorProxyConfig,
    TorProxyState,
    VPNGatewayConfig,
    VPNGatewayState,
    VPNProvider,
    WireGuardInterface,
    WireGuardMeshConfig,
    WireGuardMeshState,
    WireGuardPeer,
)
from gaol.privacy.tor import HiddenServiceManager, TorBackend, TorProxyManager
from gaol.privacy.vpn import VPNGatewayManager
from gaol.privacy.wireguard import WireGuardBackend, WireGuardMeshManager

__all__ = [
    # Models - Privacy
    "PrivacyMode",
    "PrivacyStatus",
    "DNSLeakConfig",
    # Models - Tor
    "TorProxyConfig",
    "TorProxyState",
    "HiddenServiceConfig",
    "HiddenServiceState",
    # Tor
    "TorBackend",
    "TorProxyManager",
    "HiddenServiceManager",
    # Models - VPN
    "VPNProvider",
    "VPNGatewayConfig",
    "VPNGatewayState",
    # VPN
    "VPNGatewayManager",
    # Models - WireGuard
    "WireGuardPeer",
    "WireGuardInterface",
    "WireGuardMeshConfig",
    "WireGuardMeshState",
    # WireGuard
    "WireGuardBackend",
    "WireGuardMeshManager",
    # Firewall
    "FirewallBackend",
    "PrivacyFirewall",
    # Exceptions - Base
    "PrivacyError",
    "InsufficientPermissionsError",
    # Exceptions - Tor
    "TorError",
    "TorNotFoundError",
    "TorProxyAlreadyExistsError",
    "TorProxyNotFoundError",
    "TorBootstrapError",
    "HiddenServiceAlreadyExistsError",
    "HiddenServiceNotFoundError",
    # Exceptions - VPN
    "VPNError",
    "VPNGatewayAlreadyExistsError",
    "VPNGatewayNotFoundError",
    "VPNConnectionError",
    "VPNConfigError",
    # Exceptions - WireGuard
    "WireGuardError",
    "WireGuardNotFoundError",
    "WireGuardMeshAlreadyExistsError",
    "WireGuardMeshNotFoundError",
    "WireGuardPeerError",
    # Exceptions - Firewall
    "FirewallError",
    "FirewallNotAvailableError",
    "FirewallRuleError",
]
