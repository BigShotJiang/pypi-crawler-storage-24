"""VPN gateway for privacy networking.

This module provides VPN gateway functionality:
- Route container traffic through OpenVPN or WireGuard VPN
- Kill switch to block traffic if VPN disconnects
- DNS leak prevention

Example:
    >>> from gaol.privacy.vpn import VPNGatewayManager
    >>> manager = VPNGatewayManager()
    >>> config = VPNGatewayConfig(
    ...     name="myvpn",
    ...     provider=VPNProvider.OPENVPN,
    ...     config_file=Path("~/vpn/client.ovpn"),
    ... )
    >>> gateway = manager.create(config)
    >>> print(f"Status: {gateway.status}")
"""

from __future__ import annotations

from gaol.privacy.vpn.manager import VPNGatewayManager

__all__ = [
    "VPNGatewayManager",
]
