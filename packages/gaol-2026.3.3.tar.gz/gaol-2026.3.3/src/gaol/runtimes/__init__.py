"""Container runtime implementations."""

from gaol.runtimes.apple import AppleRuntime
from gaol.runtimes.base import ContainerRuntime
from gaol.runtimes.docker import DockerRuntime
from gaol.runtimes.libvirt import LibvirtRuntime
from gaol.runtimes.nspawn import NspawnRuntime

__all__ = [
    "AppleRuntime",
    "ContainerRuntime",
    "DockerRuntime",
    "LibvirtRuntime",
    "NspawnRuntime",
]


def get_runtime(name: str) -> ContainerRuntime:
    """Get a runtime instance by name.

    Args:
        name: Runtime name ('docker', 'nspawn', 'libvirt', or 'apple')

    Returns:
        ContainerRuntime instance

    Raises:
        ValueError: If runtime name is unknown
    """
    runtimes: dict[str, type[ContainerRuntime]] = {
        "docker": DockerRuntime,
        "nspawn": NspawnRuntime,
        "libvirt": LibvirtRuntime,
        "apple": AppleRuntime,
    }

    if name not in runtimes:
        available = ", ".join(runtimes.keys())
        raise ValueError(f"Unknown runtime: {name}. Available: {available}")

    return runtimes[name]()


def list_available_runtimes() -> list[tuple[str, bool]]:
    """List all runtimes and their availability.

    Returns:
        List of (runtime_name, is_available) tuples
    """
    runtimes = [
        ("docker", DockerRuntime()),
        ("nspawn", NspawnRuntime()),
        ("libvirt", LibvirtRuntime()),
        ("apple", AppleRuntime()),
    ]
    return [(name, rt.is_available()) for name, rt in runtimes]
