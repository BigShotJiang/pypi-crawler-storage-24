"""Remote host management for gaol.

This module provides remote host management for executing gaol
commands on remote hosts via SSH. Features include:
- Register and manage remote hosts
- Execute gaol commands on remote hosts
- Check host connectivity and gaol availability
- Sync container configurations between machines

Example:
    >>> from gaol.remote import get_remote_manager, HostConfig
    >>> manager = get_remote_manager()
    >>> config = HostConfig(
    ...     name="production",
    ...     hostname="prod.example.com",
    ...     user="deploy",
    ...     key_path="~/.ssh/prod_key"
    ... )
    >>> manager.add_host(config)
    >>> manager.check_host("production")
    >>> result = manager.exec_gaol("production", ["list"])
"""

from gaol.remote.exceptions import (
    ConfigSyncError,
    HostExistsError,
    HostNotFoundError,
    KeyNotFoundError,
    GaolNotFoundError,
    RemoteCommandError,
    RemoteError,
    SSHAuthenticationError,
    SSHConnectionError,
    SSHTimeoutError,
)
from gaol.remote.models import (
    HostConfig,
    HostConnectionStatus,
    HostsRegistry,
    HostState,
    RemoteCommandResult,
    StoredHost,
)
from gaol.remote.executor import SSHExecutor
from gaol.remote.manager import RemoteManager, get_remote_manager
from gaol.remote.store import HostStore

__all__ = [
    # Manager
    "RemoteManager",
    "get_remote_manager",
    # Executor
    "SSHExecutor",
    # Store
    "HostStore",
    # Models
    "HostConfig",
    "HostConnectionStatus",
    "HostsRegistry",
    "HostState",
    "RemoteCommandResult",
    "StoredHost",
    # Exceptions
    "RemoteError",
    "HostNotFoundError",
    "HostExistsError",
    "SSHConnectionError",
    "SSHAuthenticationError",
    "SSHTimeoutError",
    "RemoteCommandError",
    "GaolNotFoundError",
    "ConfigSyncError",
    "KeyNotFoundError",
]
