"""Exceptions for remote host management."""

from __future__ import annotations


class RemoteError(Exception):
    """Base exception for remote operations."""

    def __init__(self, message: str) -> None:
        self.message = message
        super().__init__(message)


class HostNotFoundError(RemoteError):
    """Host does not exist in the registry."""

    def __init__(self, name: str) -> None:
        self.host_name = name
        super().__init__(f"Host not found: {name}")


class HostExistsError(RemoteError):
    """Host already exists in the registry."""

    def __init__(self, name: str) -> None:
        self.host_name = name
        super().__init__(f"Host already exists: {name}")


class SSHConnectionError(RemoteError):
    """SSH connection failed."""

    def __init__(self, host: str, reason: str | None = None) -> None:
        self.host = host
        self.reason = reason
        msg = f"SSH connection to '{host}' failed"
        if reason:
            msg += f": {reason}"
        super().__init__(msg)


class SSHAuthenticationError(RemoteError):
    """SSH authentication failed."""

    def __init__(self, host: str, user: str) -> None:
        self.host = host
        self.user = user
        super().__init__(f"SSH authentication failed for {user}@{host}")


class SSHTimeoutError(RemoteError):
    """SSH connection timed out."""

    def __init__(self, host: str, timeout: int) -> None:
        self.host = host
        self.timeout = timeout
        super().__init__(f"SSH connection to '{host}' timed out after {timeout}s")


class RemoteCommandError(RemoteError):
    """Remote command execution failed."""

    def __init__(
        self,
        host: str,
        command: str,
        exit_code: int,
        stderr: str | None = None,
    ) -> None:
        self.host = host
        self.command = command
        self.exit_code = exit_code
        self.stderr = stderr
        msg = f"Command on '{host}' failed with exit code {exit_code}"
        if stderr:
            msg += f": {stderr}"
        super().__init__(msg)


class GaolNotFoundError(RemoteError):
    """Gaol binary not found on remote host."""

    def __init__(self, host: str, path: str) -> None:
        self.host = host
        self.path = path
        super().__init__(
            f"Gaol binary not found on '{host}' at path: {path}"
        )


class ConfigSyncError(RemoteError):
    """Configuration synchronization failed."""

    def __init__(self, operation: str, reason: str) -> None:
        self.operation = operation
        self.reason = reason
        super().__init__(f"Config sync {operation} failed: {reason}")


class KeyNotFoundError(RemoteError):
    """SSH key file not found."""

    def __init__(self, path: str) -> None:
        self.path = path
        super().__init__(f"SSH key file not found: {path}")
