"""Secrets management for gaol containers.

This module provides encrypted storage for sensitive data like passwords,
API keys, and other credentials. Secrets are encrypted at rest using
AES-256-GCM with the master key stored in the system keyring.

Example usage:
    from gaol.secrets import get_secret_store, resolve_secrets

    # Initialize secrets store (run once)
    store = get_secret_store()
    store.initialize()

    # Create a secret
    store.create("DB_PASSWORD", "super-secret-123")

    # Use secrets in environment variables
    env = {
        "DATABASE_URL": "postgres://user:${secret:DB_PASSWORD}@localhost/db",
        "API_KEY": "${secret:API_KEY}",
    }
    resolved = resolve_secrets(env)

Secret references use the syntax ${secret:NAME} where NAME follows
the same naming rules as environment variables (starts with letter
or underscore, contains only alphanumeric and underscore characters).
"""

from gaol.secrets.crypto import (
    SecretCrypto,
    decode_key,
    derive_key_from_password,
    encode_key,
    generate_master_key,
    generate_salt,
)
from gaol.secrets.exceptions import (
    InvalidSecretNameError,
    MasterKeyNotAvailableError,
    SecretDecryptionError,
    SecretError,
    SecretExistsError,
    SecretNotFoundError,
    SecretStoreNotInitializedError,
)
from gaol.secrets.keyring import (
    EnvironmentProvider,
    KeyManager,
    KeyProvider,
    KeyringProvider,
    KeySource,
    PromptProvider,
    get_key_manager,
    initialize_master_key,
)
from gaol.secrets.models import (
    EncryptedSecret,
    SecretMetadata,
    SecretsConfig,
    SecretsStore,
    validate_secret_name,
)
from gaol.secrets.resolver import (
    SECRET_PATTERN,
    SecretResolver,
    get_secret_resolver,
    has_secrets,
    resolve_secrets,
)
from gaol.secrets.store import SecretStore, get_secret_store

__all__ = [
    # Store
    "SecretStore",
    "get_secret_store",
    # Resolver
    "SecretResolver",
    "get_secret_resolver",
    "resolve_secrets",
    "has_secrets",
    "SECRET_PATTERN",
    # Models
    "EncryptedSecret",
    "SecretMetadata",
    "SecretsConfig",
    "SecretsStore",
    "validate_secret_name",
    # Crypto
    "SecretCrypto",
    "generate_master_key",
    "generate_salt",
    "derive_key_from_password",
    "encode_key",
    "decode_key",
    # Keyring
    "KeyManager",
    "KeyProvider",
    "KeyringProvider",
    "EnvironmentProvider",
    "PromptProvider",
    "KeySource",
    "get_key_manager",
    "initialize_master_key",
    # Exceptions
    "SecretError",
    "SecretNotFoundError",
    "SecretExistsError",
    "SecretDecryptionError",
    "SecretStoreNotInitializedError",
    "MasterKeyNotAvailableError",
    "InvalidSecretNameError",
]
