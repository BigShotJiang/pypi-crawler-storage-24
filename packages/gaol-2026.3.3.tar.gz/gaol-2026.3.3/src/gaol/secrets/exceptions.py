"""Exceptions for the secrets module."""

from __future__ import annotations


class SecretError(Exception):
    """Base exception for secrets module."""

    pass


class SecretNotFoundError(SecretError):
    """Raised when a secret doesn't exist."""

    def __init__(self, name: str) -> None:
        self.name = name
        super().__init__(f"Secret not found: {name}")


class SecretExistsError(SecretError):
    """Raised when creating a secret that already exists."""

    def __init__(self, name: str) -> None:
        self.name = name
        super().__init__(f"Secret already exists: {name}")


class SecretDecryptionError(SecretError):
    """Raised when decryption fails."""

    def __init__(self, message: str = "Failed to decrypt secret") -> None:
        super().__init__(message)


class SecretStoreNotInitializedError(SecretError):
    """Raised when secrets store is not initialized."""

    def __init__(self) -> None:
        super().__init__(
            "Secrets store is not initialized. Run 'gaol secret init' first."
        )


class MasterKeyNotAvailableError(SecretError):
    """Raised when master key cannot be obtained."""

    def __init__(self, message: str = "Master key not available") -> None:
        super().__init__(message)


class InvalidSecretNameError(SecretError):
    """Raised when a secret name is invalid."""

    def __init__(self, name: str) -> None:
        self.name = name
        super().__init__(
            f"Invalid secret name: {name}. "
            "Names must start with a letter or underscore and contain only "
            "alphanumeric characters and underscores."
        )
