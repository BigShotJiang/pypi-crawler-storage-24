"""Exceptions for container diff operations."""

from __future__ import annotations


class DiffError(Exception):
    """Base exception for diff operations."""

    pass


class DiffSourceNotFoundError(DiffError):
    """Source container or snapshot not found."""

    def __init__(
        self, source_type: str, source_name: str, container_name: str | None = None
    ) -> None:
        if container_name:
            message = (
                f"{source_type.capitalize()} '{source_name}' not found "
                f"for container '{container_name}'"
            )
        else:
            message = f"{source_type.capitalize()} '{source_name}' not found"
        super().__init__(message)
        self.source_type = source_type
        self.source_name = source_name
        self.container_name = container_name


class DiffTargetNotFoundError(DiffError):
    """Target container or snapshot not found."""

    def __init__(
        self, target_type: str, target_name: str, container_name: str | None = None
    ) -> None:
        if container_name:
            message = (
                f"{target_type.capitalize()} '{target_name}' not found "
                f"for container '{container_name}'"
            )
        else:
            message = f"{target_type.capitalize()} '{target_name}' not found"
        super().__init__(message)
        self.target_type = target_type
        self.target_name = target_name
        self.container_name = container_name


class DiffUnsupportedRuntimeError(DiffError):
    """Runtime does not support diff operations."""

    def __init__(self, runtime: str, reason: str | None = None) -> None:
        message = f"Runtime '{runtime}' does not support diff operations"
        if reason:
            message += f": {reason}"
        super().__init__(message)
        self.runtime = runtime
        self.reason = reason


class DiffFilesystemAccessError(DiffError):
    """Cannot access container filesystem for diff."""

    def __init__(
        self,
        container_name: str,
        reason: str,
        cause: Exception | None = None,
    ) -> None:
        super().__init__(
            f"Cannot access filesystem for '{container_name}': {reason}"
        )
        self.container_name = container_name
        self.reason = reason
        self.cause = cause


class DiffPackageDetectionError(DiffError):
    """Cannot detect packages in container."""

    def __init__(
        self,
        container_name: str,
        reason: str,
        cause: Exception | None = None,
    ) -> None:
        super().__init__(
            f"Cannot detect packages in '{container_name}': {reason}"
        )
        self.container_name = container_name
        self.reason = reason
        self.cause = cause


class DiffContainerNotRunningError(DiffError):
    """Container must be running for diff operation."""

    def __init__(self, container_name: str) -> None:
        super().__init__(
            f"Container '{container_name}' is not running. "
            "Some diff operations require a running container."
        )
        self.container_name = container_name


class DiffSnapshotNotFoundError(DiffError):
    """Snapshot not found for container."""

    def __init__(self, container_name: str, snapshot_name: str) -> None:
        super().__init__(
            f"Snapshot '{snapshot_name}' not found for container '{container_name}'"
        )
        self.container_name = container_name
        self.snapshot_name = snapshot_name


class DiffImageNotFoundError(DiffError):
    """Base image not found for container."""

    def __init__(self, container_name: str, image_name: str | None = None) -> None:
        if image_name:
            message = f"Image '{image_name}' not found for container '{container_name}'"
        else:
            message = f"Base image not found for container '{container_name}'"
        super().__init__(message)
        self.container_name = container_name
        self.image_name = image_name
