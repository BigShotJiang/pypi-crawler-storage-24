"""Filesystem readers for different container runtimes."""

from gaol.diff.readers.base import FilesystemReader
from gaol.diff.readers.docker import DockerFilesystemReader
from gaol.diff.readers.nspawn import NspawnFilesystemReader

__all__ = [
    "FilesystemReader",
    "DockerFilesystemReader",
    "NspawnFilesystemReader",
]


def get_reader(runtime: str) -> FilesystemReader:
    """Get the appropriate filesystem reader for a runtime.

    Args:
        runtime: Runtime name (docker, nspawn)

    Returns:
        FilesystemReader instance

    Raises:
        ValueError: If runtime is not supported
    """
    if runtime == "docker":
        return DockerFilesystemReader()
    elif runtime == "nspawn":
        return NspawnFilesystemReader()
    else:
        raise ValueError(f"Unsupported runtime for diff: {runtime}")
