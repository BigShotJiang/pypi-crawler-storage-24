"""VS Code Devcontainer support module.

This module provides bidirectional support for VS Code's devcontainer.json
format, enabling:
- Converting gaol specs to devcontainer format for IDE integration
- Importing devcontainer.json files as gaol specs
- Generating devcontainer.json for existing gaol containers

Example:
    >>> from gaol.devcontainer import (
    ...     DevcontainerSpec,
    ...     load_devcontainer,
    ...     save_devcontainer,
    ...     devcontainer_to_spec,
    ...     spec_to_devcontainer,
    ... )
    >>>
    >>> # Load existing devcontainer.json
    >>> devcontainer = load_devcontainer()
    >>>
    >>> # Convert to gaol spec
    >>> spec = devcontainer_to_spec(devcontainer)
    >>>
    >>> # Or convert gaol spec to devcontainer
    >>> devcontainer = spec_to_devcontainer(spec, vscode_extensions=["ms-python.python"])
    >>> save_devcontainer(devcontainer)
"""

from gaol.devcontainer.converter import (
    DevcontainerConverter,
    devcontainer_to_spec,
    spec_to_devcontainer,
)
from gaol.devcontainer.generator import (
    DevcontainerGenerator,
    generate_devcontainer,
)
from gaol.devcontainer.loader import (
    DevcontainerLoader,
    DevcontainerNotFoundError,
    DevcontainerParseError,
    find_devcontainer,
    load_devcontainer,
    save_devcontainer,
    validate_devcontainer,
)
from gaol.devcontainer.models import (
    DevcontainerBuild,
    DevcontainerCustomizations,
    DevcontainerMount,
    DevcontainerPortAttributes,
    DevcontainerSpec,
    DevcontainerVSCodeCustomizations,
)

__all__ = [
    # Models
    "DevcontainerSpec",
    "DevcontainerBuild",
    "DevcontainerMount",
    "DevcontainerCustomizations",
    "DevcontainerVSCodeCustomizations",
    "DevcontainerPortAttributes",
    # Loader
    "DevcontainerLoader",
    "DevcontainerNotFoundError",
    "DevcontainerParseError",
    "load_devcontainer",
    "save_devcontainer",
    "find_devcontainer",
    "validate_devcontainer",
    # Converter
    "DevcontainerConverter",
    "devcontainer_to_spec",
    "spec_to_devcontainer",
    # Generator
    "DevcontainerGenerator",
    "generate_devcontainer",
]
