"""Profile models for container configuration."""

from typing import Annotated

from pydantic import BaseModel, Field


class ProfileDependency(BaseModel):
    """A dependency on another profile."""

    name: str
    optional: bool = False


class Profile(BaseModel):
    """A profile defines software and configuration for a container."""

    name: Annotated[str, Field(min_length=1, max_length=64)]
    description: str = ""
    version: str = "1.0.0"

    # Dependencies
    depends_on: Annotated[
        list[ProfileDependency], Field(default_factory=list, description="Required profiles")
    ]
    conflicts_with: Annotated[
        list[str], Field(default_factory=list, description="Incompatible profiles")
    ]

    # System requirements
    requires_root: bool = False
    requires_privileged: bool = False
    supported_distros: Annotated[
        list[str], Field(default_factory=list, description="Empty means all distros supported")
    ]

    # Packages to install
    packages: Annotated[list[str], Field(default_factory=list)]
    package_repos: Annotated[
        list[str], Field(default_factory=list, description="Additional apt/dnf repositories")
    ]

    # Services to enable/start
    services: Annotated[list[str], Field(default_factory=list)]

    # Commands to run during setup
    setup_commands: Annotated[
        list[str], Field(default_factory=list, description="Commands run after package install")
    ]

    # Files to create or modify
    files: Annotated[
        dict[str, str],
        Field(default_factory=dict, description="Path -> content for files to create"),
    ]

    # Environment variables
    environment: Annotated[
        dict[str, str],
        Field(default_factory=dict, description="Environment variables to set"),
    ]

    # Network requirements
    exposed_ports: Annotated[list[int], Field(default_factory=list)]

    # Volume mounts required by this profile
    volumes: Annotated[
        dict[str, str],
        Field(default_factory=dict, description="Host path -> container path"),
    ]

    # Capabilities and security
    capabilities_add: Annotated[list[str], Field(default_factory=list)]
    capabilities_drop: Annotated[list[str], Field(default_factory=list)]

    @classmethod
    def from_yaml(cls, yaml_content: dict) -> "Profile":
        """Create a Profile from parsed YAML content."""
        # Make a copy to avoid mutating the input
        data = yaml_content.copy()

        # Convert simple dependency strings to ProfileDependency objects
        if "depends_on" in data:
            deps = []
            for dep in data["depends_on"]:
                if isinstance(dep, str):
                    deps.append(ProfileDependency(name=dep))
                elif isinstance(dep, ProfileDependency):
                    deps.append(dep)
                elif isinstance(dep, dict):
                    deps.append(ProfileDependency(**dep))
                else:
                    raise TypeError(f"Unsupported dependency type: {type(dep)}")
            data["depends_on"] = deps
        return cls(**data)
