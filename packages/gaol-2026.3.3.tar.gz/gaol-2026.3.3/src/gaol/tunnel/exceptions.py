"""Tunnel-related exceptions."""

from __future__ import annotations


class TunnelError(Exception):
    """Base exception for tunnel errors."""

    pass


class CloudflaredNotFoundError(TunnelError):
    """cloudflared binary not found."""

    def __init__(self) -> None:
        super().__init__(
            "cloudflared not found. Install with: "
            "brew install cloudflared (or see "
            "https://developers.cloudflare.com/cloudflare-one/connections/connect-apps/install-and-setup/installation/)"
        )


class TunnelAlreadyExistsError(TunnelError):
    """Tunnel already exists for this container/port."""

    def __init__(self, container: str, port: int) -> None:
        self.container = container
        self.port = port
        super().__init__(f"Tunnel already exists for {container}:{port}")


class TunnelNotFoundError(TunnelError):
    """Tunnel not found."""

    def __init__(self, tunnel_id: str) -> None:
        self.tunnel_id = tunnel_id
        super().__init__(f"Tunnel not found: {tunnel_id}")


class TunnelStartError(TunnelError):
    """Failed to start tunnel."""

    def __init__(self, reason: str) -> None:
        self.reason = reason
        super().__init__(f"Failed to start tunnel: {reason}")
