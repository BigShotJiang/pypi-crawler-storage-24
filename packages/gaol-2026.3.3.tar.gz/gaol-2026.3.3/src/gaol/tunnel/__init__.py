"""Dev tunnels for exposing containers to the internet.

This module provides cloudflared-based tunnels to expose container
ports to the internet with public URLs.

Features:
- Quick tunnels (no account needed, random subdomain)
- Automatic port mapping detection
- Process management and cleanup
- Tunnel tracking with YAML persistence

Example:
    >>> from gaol.tunnel import TunnelManager
    >>> manager = TunnelManager()
    >>> tunnel = manager.start("myapp", 8080)
    >>> print(f"Access at: {tunnel.public_url}")
    >>> manager.stop(tunnel.id)
"""

from __future__ import annotations

from gaol.tunnel.cloudflared import CloudflaredBackend
from gaol.tunnel.exceptions import (
    CloudflaredNotFoundError,
    TunnelAlreadyExistsError,
    TunnelError,
    TunnelNotFoundError,
    TunnelStartError,
)
from gaol.tunnel.manager import TunnelManager
from gaol.tunnel.models import ActiveTunnel, TunnelConfig, TunnelStatus

__all__ = [
    # Manager
    "TunnelManager",
    # Backend
    "CloudflaredBackend",
    # Models
    "ActiveTunnel",
    "TunnelConfig",
    "TunnelStatus",
    # Exceptions
    "TunnelError",
    "CloudflaredNotFoundError",
    "TunnelAlreadyExistsError",
    "TunnelNotFoundError",
    "TunnelStartError",
]
