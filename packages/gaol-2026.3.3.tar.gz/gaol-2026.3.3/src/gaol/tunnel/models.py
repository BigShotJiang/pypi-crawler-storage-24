"""Pydantic models for dev tunnels."""

from __future__ import annotations

from datetime import datetime
from enum import Enum

from pydantic import BaseModel, Field


class TunnelStatus(str, Enum):
    """Status of a tunnel."""

    RUNNING = "running"
    STOPPED = "stopped"
    ERROR = "error"


class TunnelConfig(BaseModel):
    """Configuration for a tunnel."""

    container_name: str
    """Name of the container to tunnel."""

    container_port: int
    """Port inside the container to expose."""

    host_port: int | None = None
    """Port on host to tunnel (if different from container port)."""

    protocol: str = "http"
    """Protocol to use (http, https, tcp)."""


class ActiveTunnel(BaseModel):
    """Record of an active tunnel."""

    id: str
    """Unique tunnel ID (short UUID)."""

    container_name: str
    """Name of the container being tunneled."""

    container_port: int
    """Port inside the container."""

    host_port: int
    """Port on host being tunneled."""

    public_url: str
    """Public URL for the tunnel (e.g., https://xxx.trycloudflare.com)."""

    process_pid: int
    """PID of the cloudflared process."""

    started_at: datetime = Field(default_factory=datetime.now)
    """When the tunnel was started."""

    status: TunnelStatus = TunnelStatus.RUNNING
    """Current status of the tunnel."""
