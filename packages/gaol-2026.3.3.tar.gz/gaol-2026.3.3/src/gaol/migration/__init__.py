"""Container migration between runtimes.

This module provides functionality for migrating containers between different
runtimes (Docker, nspawn, libvirt) while preserving filesystem state.

Example:
    >>> from gaol.migration import get_migrator
    >>> migrator = get_migrator()
    >>> plan = migrator.create_plan("my-container", "nspawn")
    >>> if not plan.has_critical_warnings:
    ...     state = migrator.execute(plan)
"""

from __future__ import annotations

from gaol.migration.exceptions import (
    FeatureUnsupportedError,
    MigrationError,
    MigrationExportError,
    MigrationImportError,
    MigrationRollbackError,
    MigrationValidationError,
    RuntimeExportNotSupportedError,
    RuntimeImportNotSupportedError,
)
from gaol.migration.migrator import Migrator, get_migrator
from gaol.migration.models import (
    FeatureWarning,
    FeatureWarningSeverity,
    MigrationPlan,
    MigrationState,
    MigrationStatus,
    RuntimeCapabilities,
)
from gaol.migration.translator import (
    RUNTIME_CAPABILITIES,
    FeatureTranslator,
    get_runtime_capabilities,
)

__all__ = [
    # Main classes
    "Migrator",
    "FeatureTranslator",
    # Factory functions
    "get_migrator",
    "get_runtime_capabilities",
    # Models
    "MigrationPlan",
    "MigrationState",
    "MigrationStatus",
    "FeatureWarning",
    "FeatureWarningSeverity",
    "RuntimeCapabilities",
    # Exceptions
    "MigrationError",
    "MigrationValidationError",
    "MigrationExportError",
    "MigrationImportError",
    "MigrationRollbackError",
    "FeatureUnsupportedError",
    "RuntimeExportNotSupportedError",
    "RuntimeImportNotSupportedError",
    # Constants
    "RUNTIME_CAPABILITIES",
]
