"""Migration-specific exceptions.

This module defines exceptions for container migration operations.
"""

from __future__ import annotations


class MigrationError(Exception):
    """Base exception for migration errors."""

    pass


class MigrationValidationError(MigrationError):
    """Raised when migration plan validation fails.

    This includes cases like:
    - Container not found
    - Same source and target runtime
    - Target runtime not available
    """

    pass


class MigrationExportError(MigrationError):
    """Raised when filesystem export fails.

    This can occur when:
    - Container filesystem cannot be accessed
    - Export process fails
    - Disk space insufficient
    """

    pass


class MigrationImportError(MigrationError):
    """Raised when filesystem import fails.

    This can occur when:
    - Target runtime cannot create container
    - Import of tarball fails
    - Configuration translation fails
    """

    pass


class MigrationRollbackError(MigrationError):
    """Raised when rollback fails after a migration error.

    This is a compound error that preserves both the original
    migration error and the rollback error.
    """

    def __init__(
        self,
        original_error: Exception,
        rollback_error: Exception,
        partial_state: str | None = None,
    ):
        """Initialize rollback error.

        Args:
            original_error: The error that triggered rollback.
            rollback_error: The error that occurred during rollback.
            partial_state: Description of the current state after failed rollback.
        """
        self.original_error = original_error
        self.rollback_error = rollback_error
        self.partial_state = partial_state
        super().__init__(
            f"Migration failed ({original_error}) and rollback also failed ({rollback_error})"
        )


class FeatureUnsupportedError(MigrationError):
    """Raised when a critical feature cannot be translated.

    Some features are critical enough that migration should not proceed
    without explicit user confirmation.
    """

    def __init__(
        self,
        feature: str,
        source_runtime: str,
        target_runtime: str,
        reason: str | None = None,
    ):
        """Initialize feature unsupported error.

        Args:
            feature: Name of the unsupported feature.
            source_runtime: Source runtime name.
            target_runtime: Target runtime name.
            reason: Additional explanation.
        """
        self.feature = feature
        self.source_runtime = source_runtime
        self.target_runtime = target_runtime
        self.reason = reason

        message = f"Feature '{feature}' from {source_runtime} is not supported on {target_runtime}"
        if reason:
            message = f"{message}: {reason}"
        super().__init__(message)


class RuntimeExportNotSupportedError(MigrationError):
    """Raised when a runtime does not support filesystem export."""

    def __init__(self, runtime: str):
        self.runtime = runtime
        super().__init__(f"Runtime '{runtime}' does not support filesystem export")


class RuntimeImportNotSupportedError(MigrationError):
    """Raised when a runtime does not support filesystem import."""

    def __init__(self, runtime: str):
        self.runtime = runtime
        super().__init__(f"Runtime '{runtime}' does not support filesystem import")
