"""Storage-related exceptions."""

from __future__ import annotations


class StorageError(Exception):
    """Base exception for storage errors."""

    pass


class VolumeNotFoundError(StorageError):
    """Volume does not exist."""

    def __init__(self, name: str) -> None:
        self.name = name
        super().__init__(f"Volume not found: {name}")


class VolumeExistsError(StorageError):
    """Volume already exists."""

    def __init__(self, name: str) -> None:
        self.name = name
        super().__init__(f"Volume already exists: {name}")


class VolumeLockedError(StorageError):
    """Operation requires unlocked volume."""

    def __init__(self, name: str) -> None:
        self.name = name
        super().__init__(f"Volume is locked: {name}. Run 'gaol volume unlock {name}'")


class VolumeUnlockedError(StorageError):
    """Operation requires locked volume."""

    def __init__(self, name: str) -> None:
        self.name = name
        super().__init__(f"Volume is already unlocked: {name}")


class VolumeMountedError(StorageError):
    """Volume is currently mounted."""

    def __init__(self, name: str, container: str | None = None) -> None:
        self.name = name
        self.container = container
        msg = f"Volume is mounted: {name}"
        if container:
            msg += f" (in container: {container})"
        super().__init__(msg)


class VolumeKeyError(StorageError):
    """Error with volume encryption key."""

    def __init__(self, name: str, reason: str) -> None:
        self.name = name
        self.reason = reason
        super().__init__(f"Volume key error for {name}: {reason}")


class BackendNotAvailableError(StorageError):
    """Encryption backend is not available."""

    def __init__(self, backend: str, reason: str) -> None:
        self.backend = backend
        self.reason = reason
        super().__init__(f"{backend} not available: {reason}")


class MountError(StorageError):
    """Error mounting/unmounting volume."""

    def __init__(self, operation: str, reason: str) -> None:
        self.operation = operation
        self.reason = reason
        super().__init__(f"Mount {operation} failed: {reason}")


class InsufficientPermissionsError(StorageError):
    """Operation requires elevated permissions."""

    def __init__(self, operation: str) -> None:
        self.operation = operation
        super().__init__(
            f"Insufficient permissions for {operation}. "
            "This operation may require sudo/root."
        )
