"""Encryption backends for encrypted storage."""

from __future__ import annotations

from gaol.storage.backends.base import EncryptionBackendBase
from gaol.storage.backends.gocryptfs import GocryptfsBackend
from gaol.storage.backends.luks import LuksBackend
from gaol.storage.models import EncryptionBackend

# Backend registry
_BACKENDS: dict[EncryptionBackend, type[EncryptionBackendBase]] = {
    EncryptionBackend.LUKS: LuksBackend,
    EncryptionBackend.GOCRYPTFS: GocryptfsBackend,
}


def get_backend(backend_type: EncryptionBackend) -> EncryptionBackendBase:
    """Get a backend instance by type.

    Args:
        backend_type: The encryption backend type

    Returns:
        An instance of the requested backend

    Raises:
        ValueError: If backend type is unknown
    """
    backend_class = _BACKENDS.get(backend_type)
    if backend_class is None:
        raise ValueError(f"Unknown backend type: {backend_type}")
    return backend_class()


__all__ = [
    "EncryptionBackendBase",
    "GocryptfsBackend",
    "LuksBackend",
    "get_backend",
]
