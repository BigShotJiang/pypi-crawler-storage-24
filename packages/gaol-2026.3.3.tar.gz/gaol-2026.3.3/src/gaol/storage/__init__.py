"""Encrypted storage for gaol containers.

This module provides encrypted volume management with two backends:
- LUKS: Block-level encryption for Docker volumes and VMs
- gocryptfs: File-level FUSE encryption for bind mounts

Example:
    >>> from gaol.storage import VolumeConfig, get_volume_manager
    >>> manager = get_volume_manager()
    >>> config = VolumeConfig(name="secrets", size_mb=512)
    >>> state = manager.create(config)
    >>> state = manager.unlock("secrets")
    >>> # Use state.mount_point as bind mount
    >>> manager.lock("secrets")
"""

from gaol.storage.exceptions import (
    BackendNotAvailableError,
    InsufficientPermissionsError,
    MountError,
    StorageError,
    VolumeExistsError,
    VolumeKeyError,
    VolumeLockedError,
    VolumeMountedError,
    VolumeNotFoundError,
    VolumeUnlockedError,
)
from gaol.storage.manager import VolumeManager, get_volume_manager
from gaol.storage.models import (
    EncryptionBackend,
    VolumeConfig,
    VolumeMount,
    VolumeState,
    VolumeStatus,
    VolumesStore,
)
from gaol.storage.store import VolumeStore

__all__ = [
    # Manager
    "VolumeManager",
    "get_volume_manager",
    # Store
    "VolumeStore",
    # Models
    "EncryptionBackend",
    "VolumeConfig",
    "VolumeState",
    "VolumeStatus",
    "VolumeMount",
    "VolumesStore",
    # Exceptions
    "StorageError",
    "VolumeNotFoundError",
    "VolumeExistsError",
    "VolumeLockedError",
    "VolumeUnlockedError",
    "VolumeMountedError",
    "VolumeKeyError",
    "BackendNotAvailableError",
    "MountError",
    "InsufficientPermissionsError",
]
