"""Desktop integration for containerized GUI applications.

This module provides tools to create XDG .desktop files for launching
GUI applications inside containers, with proper menu integration.

Features:
- Generate .desktop files following XDG Desktop Entry Specification
- Install entries to user's applications directory
- Extract icons from containers
- Track and manage installed entries
- Auto-start containers when launching apps

Example:
    >>> from gaol.desktop import (
    ...     DesktopEntry,
    ...     DesktopCategory,
    ...     DesktopInstaller,
    ... )
    >>> entry = DesktopEntry(
    ...     name="Firefox",
    ...     container_name="browser",
    ...     exec_command="/usr/bin/firefox",
    ...     icon="firefox",
    ...     categories=[DesktopCategory.NETWORK],
    ...     comment="Firefox running in an isolated container",
    ... )
    >>> installer = DesktopInstaller()
    >>> installed = installer.install(entry)
    >>> print(f"Installed to {installed.desktop_file}")
"""

from __future__ import annotations

from gaol.desktop.exceptions import (
    DesktopEntryExistsError,
    DesktopEntryNotFoundError,
    DesktopError,
    DesktopInstallError,
    IconExtractionError,
)
from gaol.desktop.generator import DesktopEntryGenerator
from gaol.desktop.installer import DesktopInstaller
from gaol.desktop.models import (
    DesktopCategory,
    DesktopConfig,
    DesktopEntry,
    InstalledEntry,
)

__all__ = [
    # Models
    "DesktopEntry",
    "DesktopConfig",
    "DesktopCategory",
    "InstalledEntry",
    # Generator
    "DesktopEntryGenerator",
    # Installer
    "DesktopInstaller",
    # Exceptions
    "DesktopError",
    "DesktopEntryNotFoundError",
    "DesktopEntryExistsError",
    "DesktopInstallError",
    "IconExtractionError",
]
