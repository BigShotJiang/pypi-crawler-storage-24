"""Desktop integration exceptions."""

from __future__ import annotations


class DesktopError(Exception):
    """Base exception for desktop integration errors."""

    pass


class DesktopEntryNotFoundError(DesktopError):
    """Desktop entry not found."""

    def __init__(self, container_name: str, entry_name: str | None = None) -> None:
        self.container_name = container_name
        self.entry_name = entry_name
        if entry_name:
            msg = f"Desktop entry '{entry_name}' not found for container '{container_name}'"
        else:
            msg = f"No desktop entries found for container '{container_name}'"
        super().__init__(msg)


class DesktopEntryExistsError(DesktopError):
    """Desktop entry already exists."""

    def __init__(self, container_name: str, entry_name: str) -> None:
        self.container_name = container_name
        self.entry_name = entry_name
        super().__init__(
            f"Desktop entry '{entry_name}' already exists for container '{container_name}'"
        )


class DesktopInstallError(DesktopError):
    """Error installing desktop entry."""

    pass


class IconExtractionError(DesktopError):
    """Error extracting icon from container."""

    def __init__(self, container_name: str, icon_path: str, reason: str) -> None:
        self.container_name = container_name
        self.icon_path = icon_path
        super().__init__(
            f"Failed to extract icon '{icon_path}' from container '{container_name}': {reason}"
        )
