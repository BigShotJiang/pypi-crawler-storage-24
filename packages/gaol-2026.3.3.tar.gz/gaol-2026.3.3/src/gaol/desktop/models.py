"""Pydantic models for desktop integration.

This module defines the data structures for XDG desktop entries
and configuration.
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum

from pydantic import BaseModel, Field


class DesktopCategory(str, Enum):
    """XDG menu categories.

    Standard categories from the XDG Desktop Menu Specification.
    https://specifications.freedesktop.org/menu-spec/latest/apa.html
    """

    AUDIO_VIDEO = "AudioVideo"
    AUDIO = "Audio"
    VIDEO = "Video"
    DEVELOPMENT = "Development"
    EDUCATION = "Education"
    GAME = "Game"
    GRAPHICS = "Graphics"
    NETWORK = "Network"
    OFFICE = "Office"
    SCIENCE = "Science"
    SETTINGS = "Settings"
    SYSTEM = "System"
    UTILITY = "Utility"


class DesktopEntry(BaseModel):
    """XDG Desktop Entry specification model.

    Represents a .desktop file for launching containerized applications.
    Follows the XDG Desktop Entry Specification 1.5.

    Example:
        >>> entry = DesktopEntry(
        ...     name="Firefox",
        ...     container_name="browser",
        ...     exec_command="/usr/bin/firefox",
        ...     icon="firefox",
        ...     categories=[DesktopCategory.NETWORK],
        ... )
    """

    name: str
    """Display name of the application."""

    container_name: str
    """Container to run the application in."""

    exec_command: str
    """Command to execute inside the container."""

    icon: str | None = None
    """Icon name or path."""

    comment: str | None = None
    """Tooltip description."""

    categories: list[DesktopCategory] = Field(default_factory=list)
    """Menu categories."""

    terminal: bool = False
    """Whether to run in a terminal."""

    start_container: bool = True
    """Auto-start container if not running."""

    working_dir: str | None = None
    """Working directory inside container."""

    mime_types: list[str] = Field(default_factory=list)
    """Supported MIME types for file associations."""

    keywords: list[str] = Field(default_factory=list)
    """Search keywords."""

    generic_name: str | None = None
    """Generic name (e.g., 'Web Browser')."""

    no_display: bool = False
    """Hide from menus but still usable."""

    startup_notify: bool = True
    """Support startup notification."""


class DesktopConfig(BaseModel):
    """Configuration for desktop integration."""

    applications_dir: str | None = None
    """Custom applications directory (default: ~/.local/share/applications)."""

    icons_dir: str | None = None
    """Custom icons directory (default: ~/.local/share/icons)."""

    default_icon: str = "application-x-executable"
    """Default icon for apps without custom icon."""

    prefix: str = "gaol-"
    """Prefix for .desktop filenames."""


class InstalledEntry(BaseModel):
    """Record of an installed desktop entry.

    Used to track which .desktop files have been installed
    so they can be managed and uninstalled later.
    """

    container_name: str
    """Container name."""

    entry_name: str
    """Display name of the entry."""

    desktop_file: str
    """Path to the installed .desktop file."""

    icon_file: str | None = None
    """Path to installed icon file, if any."""

    installed_at: datetime = Field(default_factory=datetime.now)
    """When the entry was installed."""

    exec_command: str | None = None
    """The command that gets executed."""
