"""Log aggregation and search for containers.

This module provides centralized log collection, storage, and search
capabilities for containers across all supported runtimes.

Features:
- Collect logs from Docker, nspawn, and libvirt containers
- Store logs persistently in JSONL format
- Automatic rotation and retention policies
- Full-text search and filtering
- Log level detection and parsing
- Pattern analysis for recurring issues

Example:
    >>> from gaol.logs import get_log_store, LogQuery, LogSearcher
    >>> store = get_log_store()
    >>> # Query last hour of logs
    >>> entries = store.query("my-container", LogQuery.last_n_hours(1))
    >>> # Search for errors
    >>> searcher = LogSearcher(entries)
    >>> errors = searcher.filter_by_level(LogLevel.ERROR)
"""

from __future__ import annotations

from gaol.logs.collector import (
    LogCollector,
    MultiRuntimeCollector,
)
from gaol.logs.models import (
    LogConfig,
    LogEntry,
    LogLevel,
    LogQuery,
    LogSource,
    LogStats,
    RetentionPolicy,
    parse_log_level,
)
from gaol.logs.search import (
    LogSearcher,
    create_query,
)
from gaol.logs.store import (
    LogStore,
    get_log_store,
    get_log_store_dir,
)

__all__ = [
    # Models
    "LogEntry",
    "LogQuery",
    "LogConfig",
    "LogLevel",
    "LogSource",
    "LogStats",
    "RetentionPolicy",
    # Collector
    "LogCollector",
    "MultiRuntimeCollector",
    # Store
    "LogStore",
    "get_log_store",
    "get_log_store_dir",
    # Search
    "LogSearcher",
    "create_query",
    # Utilities
    "parse_log_level",
]
