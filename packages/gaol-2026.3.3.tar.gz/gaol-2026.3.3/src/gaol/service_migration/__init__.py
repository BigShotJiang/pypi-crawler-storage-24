"""Host service migration to containers.

This module provides functionality to migrate systemd services from the host
system into nspawn containers with automatic dependency discovery.
"""

from __future__ import annotations

from gaol.service_migration.discovery import DependencyDiscovery
from gaol.service_migration.exceptions import (
    MigrationExecutionError,
    PackageDiscoveryError,
    ServiceMigrationError,
    ServiceNotFoundError,
    ServiceParseError,
    TemplateServiceError,
    UnsupportedServiceError,
)
from gaol.service_migration.generator import SpecGenerator
from gaol.service_migration.migrator import ServiceMigrator
from gaol.service_migration.models import (
    DiscoveredDependencies,
    MigrationAnalysis,
    MigrationWarning,
    MigrationWarningSeverity,
    ParsedSystemdService,
    ServiceInstallSection,
    ServiceSection,
    UnitSection,
    WellKnownService,
)
from gaol.service_migration.parser import SystemdUnitParser

__all__ = [
    # Main classes
    "ServiceMigrator",
    "SystemdUnitParser",
    "DependencyDiscovery",
    "SpecGenerator",
    # Models
    "ParsedSystemdService",
    "UnitSection",
    "ServiceSection",
    "ServiceInstallSection",
    "DiscoveredDependencies",
    "MigrationAnalysis",
    "MigrationWarning",
    "MigrationWarningSeverity",
    "WellKnownService",
    # Exceptions
    "ServiceMigrationError",
    "ServiceNotFoundError",
    "ServiceParseError",
    "PackageDiscoveryError",
    "UnsupportedServiceError",
    "TemplateServiceError",
    "MigrationExecutionError",
]
