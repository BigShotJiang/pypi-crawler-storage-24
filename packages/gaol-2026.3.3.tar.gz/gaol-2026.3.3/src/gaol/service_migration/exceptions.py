"""Custom exceptions for service migration."""

from __future__ import annotations


class ServiceMigrationError(Exception):
    """Base exception for service migration operations."""

    pass


class ServiceNotFoundError(ServiceMigrationError):
    """Raised when a systemd service cannot be found."""

    def __init__(self, service_name: str, searched_paths: list[str] | None = None):
        self.service_name = service_name
        self.searched_paths = searched_paths or []
        paths_msg = ""
        if self.searched_paths:
            paths_msg = f" Searched: {', '.join(self.searched_paths)}"
        super().__init__(f"Service not found: {service_name}.{paths_msg}")


class ServiceParseError(ServiceMigrationError):
    """Raised when a service file cannot be parsed."""

    def __init__(self, service_name: str, reason: str):
        self.service_name = service_name
        self.reason = reason
        super().__init__(f"Failed to parse service '{service_name}': {reason}")


class PackageDiscoveryError(ServiceMigrationError):
    """Raised when package discovery fails."""

    def __init__(self, binary_path: str, reason: str):
        self.binary_path = binary_path
        self.reason = reason
        super().__init__(f"Failed to discover package for '{binary_path}': {reason}")


class UnsupportedServiceError(ServiceMigrationError):
    """Raised when a service cannot be migrated."""

    def __init__(self, service_name: str, reason: str):
        self.service_name = service_name
        self.reason = reason
        super().__init__(f"Service '{service_name}' cannot be migrated: {reason}")


class TemplateServiceError(ServiceMigrationError):
    """Raised when trying to migrate a template service without an instance."""

    def __init__(self, service_name: str):
        self.service_name = service_name
        super().__init__(
            f"'{service_name}' is a template service (foo@.service). "
            "Specify an instance name (e.g., foo@instance.service)"
        )


class MigrationExecutionError(ServiceMigrationError):
    """Raised when migration execution fails."""

    def __init__(self, stage: str, reason: str):
        self.stage = stage
        self.reason = reason
        super().__init__(f"Migration failed during {stage}: {reason}")
