"""Nix integration for gaol container manager.

This module provides:
- Nix installation in containers
- nix-shell and nix develop support
- Flake generation and management
- Package name translation

Example:
    >>> from gaol.nix import get_nix_installer, get_nix_shell, get_flake_manager
    >>>
    >>> # Install Nix in a container
    >>> installer = get_nix_installer()
    >>> installer.install(runtime, container_id)
    >>>
    >>> # Run commands in a Nix shell
    >>> shell = get_nix_shell()
    >>> shell.run_shell(runtime, container_id, packages=["python311", "nodejs"])
    >>>
    >>> # Create a flake-based environment
    >>> flake_mgr = get_flake_manager()
    >>> flake_mgr.init_flake(runtime, container_id, "/app", packages=["python311"])
"""

from gaol.nix.exceptions import (
    FlakeDevelopError,
    FlakeError,
    FlakeInitError,
    FlakeNotFoundError,
    FlakeUpdateError,
    NixChannelError,
    NixError,
    NixGarbageCollectionError,
    NixInstallationError,
    NixNotInstalledError,
    NixPackageError,
    NixShellError,
)
from gaol.nix.flake import FlakeManager, get_flake_manager
from gaol.nix.installer import NixInstaller, get_nix_installer
from gaol.nix.models import (
    NixChannel,
    NixConfig,
    NixEnvironment,
    NixFlake,
    NixStatus,
)
from gaol.nix.packages import (
    NIX_META_PACKAGES,
    NIX_PACKAGE_MAPPINGS,
    NIX_SKIP_PACKAGES,
    get_nix_package_attr,
    translate_packages_to_nix,
    translate_to_nix,
    validate_nix_packages,
)
from gaol.nix.shell import NixShell, get_nix_shell

__all__ = [
    # Exceptions
    "FlakeDevelopError",
    "FlakeError",
    "FlakeInitError",
    "FlakeNotFoundError",
    "FlakeUpdateError",
    "NixChannelError",
    "NixError",
    "NixGarbageCollectionError",
    "NixInstallationError",
    "NixNotInstalledError",
    "NixPackageError",
    "NixShellError",
    # Models
    "NixChannel",
    "NixConfig",
    "NixEnvironment",
    "NixFlake",
    "NixStatus",
    # Installer
    "NixInstaller",
    "get_nix_installer",
    # Shell
    "NixShell",
    "get_nix_shell",
    # Flake
    "FlakeManager",
    "get_flake_manager",
    # Packages
    "NIX_META_PACKAGES",
    "NIX_PACKAGE_MAPPINGS",
    "NIX_SKIP_PACKAGES",
    "get_nix_package_attr",
    "translate_packages_to_nix",
    "translate_to_nix",
    "validate_nix_packages",
]
