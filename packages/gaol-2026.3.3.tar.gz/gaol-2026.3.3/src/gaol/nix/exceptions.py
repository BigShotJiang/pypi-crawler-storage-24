"""Nix-related exceptions."""

from __future__ import annotations


class NixError(Exception):
    """Base exception for Nix operations."""

    pass


class NixNotInstalledError(NixError):
    """Raised when Nix is not installed in the container."""

    def __init__(self, container_id: str) -> None:
        self.container_id = container_id
        super().__init__(
            f"Nix is not installed in container '{container_id}'. "
            "Run 'gaol nix init' to install it."
        )


class NixInstallationError(NixError):
    """Raised when Nix installation fails."""

    def __init__(self, container_id: str, reason: str) -> None:
        self.container_id = container_id
        self.reason = reason
        super().__init__(f"Failed to install Nix in container '{container_id}': {reason}")


class NixChannelError(NixError):
    """Raised when channel operations fail."""

    def __init__(self, channel: str, reason: str) -> None:
        self.channel = channel
        self.reason = reason
        super().__init__(f"Failed to configure Nix channel '{channel}': {reason}")


class NixPackageError(NixError):
    """Raised when package operations fail."""

    def __init__(self, packages: list[str], reason: str) -> None:
        self.packages = packages
        self.reason = reason
        pkg_list = ", ".join(packages)
        super().__init__(f"Failed to install Nix packages [{pkg_list}]: {reason}")


class NixShellError(NixError):
    """Raised when nix-shell operations fail."""

    def __init__(self, reason: str) -> None:
        self.reason = reason
        super().__init__(f"Nix shell operation failed: {reason}")


class FlakeError(NixError):
    """Base exception for flake operations."""

    pass


class FlakeInitError(FlakeError):
    """Raised when flake initialization fails."""

    def __init__(self, path: str, reason: str) -> None:
        self.path = path
        self.reason = reason
        super().__init__(f"Failed to initialize flake at '{path}': {reason}")


class FlakeUpdateError(FlakeError):
    """Raised when flake update fails."""

    def __init__(self, path: str, reason: str) -> None:
        self.path = path
        self.reason = reason
        super().__init__(f"Failed to update flake at '{path}': {reason}")


class FlakeDevelopError(FlakeError):
    """Raised when nix develop fails."""

    def __init__(self, path: str, reason: str) -> None:
        self.path = path
        self.reason = reason
        super().__init__(f"Failed to enter flake development shell at '{path}': {reason}")


class FlakeNotFoundError(FlakeError):
    """Raised when flake.nix is not found."""

    def __init__(self, path: str) -> None:
        self.path = path
        super().__init__(
            f"No flake.nix found at '{path}'. "
            "Run 'gaol nix flake init' to create one."
        )


class NixGarbageCollectionError(NixError):
    """Raised when garbage collection fails."""

    def __init__(self, reason: str) -> None:
        self.reason = reason
        super().__init__(f"Nix garbage collection failed: {reason}")
