"""Networking module for gaol container manager.

Provides port conflict detection, DNS configuration, bridge management,
and firewall rules for port forwarding.
"""

from gaol.networking.bridge import (
    BridgeError,
    BridgeInfo,
    bridge_exists,
    create_bridge,
    delete_bridge,
    ensure_bridge,
    get_bridge_info,
    list_bridges,
)
from gaol.networking.dns import (
    PUBLIC_DNS_SERVERS,
    DNSError,
    InvalidDNSServerError,
    generate_resolv_conf,
    get_default_dns_config,
    get_system_dns,
    parse_resolv_conf,
    validate_dns_server,
)
from gaol.networking.firewall import (
    FirewallBackend,
    FirewallError,
    FirewallManager,
    ForwardingRule,
    add_port_forward,
    remove_port_forward,
)
from gaol.networking.manager import (
    NetworkManager,
    get_network_manager,
)
from gaol.networking.models import (
    BridgeConfig,
    DNSConfig,
    IPVersion,
    NetworkConfigV2,
    PortMapping,
    PortMappingList,
    Protocol,
)
from gaol.networking.ports import (
    PortConflictError,
    PortError,
    PortInUseError,
    check_port_conflicts,
    find_available_port,
    get_port_process,
    is_port_available,
    validate_port_mappings,
)

__all__ = [
    # Models
    "BridgeConfig",
    "DNSConfig",
    "IPVersion",
    "NetworkConfigV2",
    "PortMapping",
    "PortMappingList",
    "Protocol",
    # Ports
    "PortConflictError",
    "PortError",
    "PortInUseError",
    "check_port_conflicts",
    "find_available_port",
    "get_port_process",
    "is_port_available",
    "validate_port_mappings",
    # DNS
    "DNSError",
    "InvalidDNSServerError",
    "PUBLIC_DNS_SERVERS",
    "generate_resolv_conf",
    "get_default_dns_config",
    "get_system_dns",
    "parse_resolv_conf",
    "validate_dns_server",
    # Bridge
    "BridgeError",
    "BridgeInfo",
    "bridge_exists",
    "create_bridge",
    "delete_bridge",
    "ensure_bridge",
    "get_bridge_info",
    "list_bridges",
    # Firewall
    "FirewallBackend",
    "FirewallError",
    "FirewallManager",
    "ForwardingRule",
    "add_port_forward",
    "remove_port_forward",
    # Manager
    "NetworkManager",
    "get_network_manager",
]
