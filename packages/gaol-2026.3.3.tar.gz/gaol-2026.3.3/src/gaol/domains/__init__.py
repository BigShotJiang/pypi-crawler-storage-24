"""security domain-inspired security patterns for gaol.

This module provides domain-based isolation patterns using systemd-nspawn:
- Template containers: Base images that spawn app containers with overlays
- Disposable containers: Ephemeral containers destroyed after use
- Security domains: Color-coded trust levels with different policies
- Service containers: Gateway containers (VPN, Tor, firewall)
- Split secrets vaults: Isolated key storage with agent forwarding
- Network chains: Multi-hop traffic routing with policy enforcement
"""

from gaol.domains.chain_manager import ChainManager, get_chain_manager
from gaol.domains.desktop import (
    DisposableDesktopGenerator,
    install_disposable_desktop,
    uninstall_disposable_desktop,
)
from gaol.domains.disposable_manager import DisposableManager, get_disposable_manager
from gaol.domains.models import (
    DEFAULT_DOMAIN_POLICIES,
    DOMAIN_COLORS,
    ChainConfig,
    ChainHop,
    ChainHopState,
    ChainHopType,
    ChainLogEntry,
    ChainState,
    ClientAttachment,
    DisposableConfig,
    DisposableInstance,
    DisposableType,
    DomainPolicy,
    SecurityDomain,
    ServiceContainerConfig,
    ServiceContainerState,
    ServiceContainerType,
    TemplateConfig,
    TemplateInstance,
    TemplateState,
    TemplateType,
    VaultAttachment,
    VaultConfig,
    VaultKeyInfo,
    VaultOperation,
    VaultPolicy,
    VaultState,
    VaultType,
)
from gaol.domains.service_manager import ServiceContainerManager, get_service_container_manager
from gaol.domains.store import DomainsFileStore, get_domain_store
from gaol.domains.template_manager import TemplateManager, get_template_manager
from gaol.domains.vault_manager import VaultManager, get_vault_manager

__all__ = [
    # Models
    "ClientAttachment",
    "DisposableConfig",
    "DisposableInstance",
    "DisposableType",
    "DomainPolicy",
    "SecurityDomain",
    "ServiceContainerConfig",
    "ServiceContainerState",
    "ServiceContainerType",
    "TemplateConfig",
    "TemplateInstance",
    "TemplateState",
    "TemplateType",
    "DOMAIN_COLORS",
    "DEFAULT_DOMAIN_POLICIES",
    # Vault models
    "VaultAttachment",
    "VaultConfig",
    "VaultKeyInfo",
    "VaultOperation",
    "VaultPolicy",
    "VaultState",
    "VaultType",
    # Chain models
    "ChainConfig",
    "ChainHop",
    "ChainHopState",
    "ChainHopType",
    "ChainLogEntry",
    "ChainState",
    # Managers
    "TemplateManager",
    "get_template_manager",
    "DisposableManager",
    "get_disposable_manager",
    "ServiceContainerManager",
    "get_service_container_manager",
    "VaultManager",
    "get_vault_manager",
    "ChainManager",
    "get_chain_manager",
    # Store
    "DomainsFileStore",
    "get_domain_store",
    # Desktop
    "DisposableDesktopGenerator",
    "install_disposable_desktop",
    "uninstall_disposable_desktop",
]
