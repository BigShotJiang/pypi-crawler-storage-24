"""Storage backends for container backups."""

from gaol.backup.models import StorageBackendType, StorageConfig
from gaol.backup.storage.base import StorageBackend
from gaol.backup.storage.local import LocalStorageBackend
from gaol.backup.storage.s3 import S3StorageBackend

__all__ = [
    "StorageBackend",
    "LocalStorageBackend",
    "S3StorageBackend",
    "get_storage_backend",
]


def get_storage_backend(config: StorageConfig | None = None) -> StorageBackend:
    """Get a storage backend for the given configuration.

    Args:
        config: Storage configuration. Defaults to local storage.

    Returns:
        Appropriate StorageBackend instance
    """
    if config is None:
        return LocalStorageBackend()

    if config.backend == StorageBackendType.S3:
        return S3StorageBackend(config)

    # Default to local
    if config.path:
        from pathlib import Path

        return LocalStorageBackend(Path(config.path))

    return LocalStorageBackend()
