"""Exceptions for container backup operations."""

from __future__ import annotations


class BackupError(Exception):
    """Base exception for backup operations."""

    def __init__(self, message: str) -> None:
        self.message = message
        super().__init__(message)


class ContainerNotFoundError(BackupError):
    """Container not found in store."""

    def __init__(self, name: str) -> None:
        self.container_name = name
        super().__init__(f"Container not found: {name}")


class BackupNotFoundError(BackupError):
    """Backup not found."""

    def __init__(self, container_name: str, backup_name: str) -> None:
        self.container_name = container_name
        self.backup_name = backup_name
        super().__init__(f"Backup not found: {container_name}/{backup_name}")


class PolicyNotFoundError(BackupError):
    """Backup policy not found."""

    def __init__(self, container_name: str) -> None:
        self.container_name = container_name
        super().__init__(f"Backup policy not found for: {container_name}")


class StorageError(BackupError):
    """Error with storage backend."""

    def __init__(self, backend: str, operation: str, reason: str) -> None:
        self.backend = backend
        self.operation = operation
        self.reason = reason
        super().__init__(f"Storage error ({backend}) during {operation}: {reason}")


class StorageNotConfiguredError(BackupError):
    """Storage backend not configured."""

    def __init__(self, backend: str) -> None:
        self.backend = backend
        super().__init__(f"Storage backend not configured: {backend}")


class BackupExecutionError(BackupError):
    """Error during backup execution."""

    def __init__(self, message: str, output: str | None = None) -> None:
        self.output = output
        super().__init__(message)


class RestoreError(BackupError):
    """Error during restore."""

    def __init__(self, container_name: str, backup_name: str, reason: str) -> None:
        self.container_name = container_name
        self.backup_name = backup_name
        self.reason = reason
        super().__init__(
            f"Restore failed for {container_name} from {backup_name}: {reason}"
        )


class RetentionError(BackupError):
    """Error applying retention policy."""

    pass


class VerificationError(BackupError):
    """Backup verification failed."""

    def __init__(self, backup_name: str, reason: str) -> None:
        self.backup_name = backup_name
        self.reason = reason
        super().__init__(f"Backup verification failed for {backup_name}: {reason}")


class IncrementalNotAvailableError(BackupError):
    """Incremental backup not available (no CoW or no base snapshot)."""

    def __init__(self, container_name: str, reason: str) -> None:
        self.container_name = container_name
        self.reason = reason
        super().__init__(
            f"Incremental backup not available for {container_name}: {reason}"
        )


class SchedulerError(BackupError):
    """Error in backup scheduler."""

    pass
