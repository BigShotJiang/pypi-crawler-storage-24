"""Scheduled backup functionality for gaol containers.

This module provides automatic backup functionality including:
- Full and incremental backups
- Automatic backup scheduling (daily, weekly, monthly)
- Retention policies (keep last N, keep daily/weekly/monthly)
- Cloud storage support (local, S3-compatible)
- Backup verification and restore

Example:
    >>> from gaol.backup import get_backup_manager
    >>> manager = get_backup_manager()
    >>> result = manager.create("mycontainer", name="daily-backup")
    >>> manager.set_schedule("mycontainer", BackupScheduleType.DAILY, "02:00")
    >>> manager.restore("mycontainer", "daily-backup")
"""

from gaol.backup.exceptions import (
    BackupError,
    BackupExecutionError,
    BackupNotFoundError,
    ContainerNotFoundError,
    IncrementalNotAvailableError,
    PolicyNotFoundError,
    RestoreError,
    RetentionError,
    SchedulerError,
    StorageError,
    StorageNotConfiguredError,
    VerificationError,
)
from gaol.backup.manager import BackupManager, get_backup_manager
from gaol.backup.models import (
    BackupHistory,
    BackupMetadata,
    BackupPolicy,
    BackupResult,
    BackupSchedule,
    BackupScheduleType,
    BackupStatus,
    BackupType,
    GlobalBackupConfig,
    RestoreResult,
    RetentionPolicy,
    SchedulerState,
    StorageBackendType,
    StorageConfig,
)
from gaol.backup.retention import RetentionEnforcer
from gaol.backup.scheduler import BackupScheduler, get_backup_scheduler
from gaol.backup.storage import (
    LocalStorageBackend,
    S3StorageBackend,
    StorageBackend,
    get_storage_backend,
)
from gaol.backup.store import BackupStore, get_backup_store

__all__ = [
    # Manager
    "BackupManager",
    "get_backup_manager",
    # Models
    "BackupScheduleType",
    "BackupStatus",
    "BackupType",
    "StorageBackendType",
    "BackupSchedule",
    "RetentionPolicy",
    "StorageConfig",
    "BackupPolicy",
    "BackupMetadata",
    "BackupResult",
    "RestoreResult",
    "BackupHistory",
    "GlobalBackupConfig",
    "SchedulerState",
    # Store
    "BackupStore",
    "get_backup_store",
    # Storage
    "StorageBackend",
    "LocalStorageBackend",
    "S3StorageBackend",
    "get_storage_backend",
    # Scheduler
    "BackupScheduler",
    "get_backup_scheduler",
    # Retention
    "RetentionEnforcer",
    # Exceptions
    "BackupError",
    "ContainerNotFoundError",
    "BackupNotFoundError",
    "PolicyNotFoundError",
    "StorageError",
    "StorageNotConfiguredError",
    "BackupExecutionError",
    "RestoreError",
    "RetentionError",
    "VerificationError",
    "IncrementalNotAvailableError",
    "SchedulerError",
]
