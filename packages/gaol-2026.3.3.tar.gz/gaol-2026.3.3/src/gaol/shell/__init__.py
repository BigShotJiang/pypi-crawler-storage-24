"""Shell integration for gaol.

This module provides shell integration features including:
- Shell completions for Bash, Zsh, and Fish
- Prompt integration showing active container context
- Container context management
- Shell helper functions for quick access

Example:
    # Generate and install completions
    >>> from gaol.shell import CompletionGenerator, Shell
    >>> gen = CompletionGenerator()
    >>> gen.install(Shell.BASH)

    # Generate prompt integration
    >>> from gaol.shell import PromptIntegration
    >>> prompt = PromptIntegration()
    >>> script = prompt.generate(Shell.BASH)

    # Check current container context
    >>> from gaol.shell import ContainerContext
    >>> ContainerContext.get_current()
    'mycontainer'
"""

from __future__ import annotations

from gaol.shell.completions import CompletionGenerator, Shell, get_supported_shells
from gaol.shell.context import ContainerContext
from gaol.shell.prompt import PromptIntegration

__all__ = [
    # Classes
    "CompletionGenerator",
    "ContainerContext",
    "PromptIntegration",
    # Enums
    "Shell",
    # Functions
    "get_supported_shells",
]
