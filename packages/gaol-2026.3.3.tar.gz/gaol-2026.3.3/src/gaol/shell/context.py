"""Container context management for shell integration.

This module provides utilities for managing the current container context
in shell environments, enabling prompt integration and quick access commands.
"""

from __future__ import annotations

import os

from gaol.models import ContainerStatus
from gaol.runtimes import get_runtime
from gaol.store import get_container_store


class ContainerContext:
    """Manage container context for shell integration.

    The container context is tracked via the GAOL_CONTAINER
    environment variable, which can be set by shell helper functions.

    Example:
        >>> context = ContainerContext()
        >>> context.get_current()
        'mycontainer'
        >>> context.get_status_short('mycontainer')
        'running'
    """

    ENV_VAR = "GAOL_CONTAINER"

    @classmethod
    def get_current(cls) -> str | None:
        """Get current container from environment.

        Returns:
            Container name if set, None otherwise.
        """
        return os.environ.get(cls.ENV_VAR)

    @classmethod
    def get_status_short(cls, container_name: str) -> str:
        """Get short status string for prompt display.

        Args:
            container_name: Name of the container.

        Returns:
            Short status string (e.g., "running", "stopped", "?").
        """
        store = get_container_store()
        stored = store.get(container_name)

        if not stored:
            return "?"

        try:
            rt = get_runtime(stored.runtime)
            state = rt.status(container_name)
            if state:
                return state.status.value
        except Exception:
            pass

        return "?"

    @classmethod
    def get_context_info(cls, container_name: str) -> dict[str, str | None]:
        """Get detailed context information for a container.

        Args:
            container_name: Name of the container.

        Returns:
            Dictionary with container info (name, runtime, status, image, ip).
        """
        store = get_container_store()
        stored = store.get(container_name)

        info: dict[str, str | None] = {
            "name": container_name,
            "runtime": None,
            "status": None,
            "image": None,
            "ip_address": None,
        }

        if not stored:
            return info

        info["runtime"] = stored.runtime
        info["image"] = stored.config.image if stored.config else None

        try:
            rt = get_runtime(stored.runtime)
            state = rt.status(container_name)
            if state:
                info["status"] = state.status.value
                info["ip_address"] = state.ip_address
        except Exception:
            pass

        return info

    @classmethod
    def list_containers(cls) -> list[str]:
        """List all known container names.

        Returns:
            List of container names.
        """
        store = get_container_store()
        return store.list()

    @classmethod
    def container_exists(cls, container_name: str) -> bool:
        """Check if a container exists in the store.

        Args:
            container_name: Name of the container.

        Returns:
            True if container exists.
        """
        store = get_container_store()
        return store.get(container_name) is not None
