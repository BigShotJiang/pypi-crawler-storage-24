"""Gaol MCP server — expose container management to AI agents."""
