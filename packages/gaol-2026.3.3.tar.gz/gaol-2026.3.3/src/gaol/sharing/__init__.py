"""Sharing module for importing profiles and specs from URLs.

This module provides functionality for:
- Importing profiles and specs from URLs
- Security scanning of imported content
- URL resolution for various formats (github:, gist:, etc.)
- Local storage of imported content

Example:
    >>> from gaol.sharing import get_content_importer
    >>>
    >>> importer = get_content_importer()
    >>> result = importer.import_url("https://example.com/profile.yaml")
    >>> print(f"Imported: {result.name} ({result.content_type})")
    >>>
    >>> # Import profile specifically
    >>> result = importer.import_profile("github:user/repo/profiles/dev.yaml")
    >>>
    >>> # Import spec specifically
    >>> result = importer.import_spec("https://example.com/webserver.yaml")
"""

from __future__ import annotations

from gaol.sharing.exceptions import (
    ContentTypeDetectionError,
    ContentValidationError,
    FetchError,
    ImportError,
    ProfileExistsError,
    SharingError,
    SpecExistsError,
    URLResolveError,
)
from gaol.sharing.importer import ContentImporter, get_content_importer
from gaol.sharing.models import (
    ContentType,
    ImportedContentMetadata,
    ImportResult,
    SecurityFinding,
    SecurityScanResult,
    Severity,
    TrustLevel,
)
from gaol.sharing.resolver import URLResolver, get_url_resolver
from gaol.sharing.scanner import SecurityScanner, get_security_scanner

__all__ = [
    # Importer
    "ContentImporter",
    "get_content_importer",
    # Scanner
    "SecurityScanner",
    "get_security_scanner",
    # Resolver
    "URLResolver",
    "get_url_resolver",
    # Models
    "ContentType",
    "TrustLevel",
    "Severity",
    "SecurityFinding",
    "SecurityScanResult",
    "ImportResult",
    "ImportedContentMetadata",
    # Exceptions
    "SharingError",
    "ImportError",
    "FetchError",
    "ContentValidationError",
    "ContentTypeDetectionError",
    "ProfileExistsError",
    "SpecExistsError",
    "URLResolveError",
]
