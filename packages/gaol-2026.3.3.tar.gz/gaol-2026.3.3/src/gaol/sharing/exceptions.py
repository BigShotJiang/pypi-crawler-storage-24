"""Exceptions for the sharing module."""

from __future__ import annotations


class SharingError(Exception):
    """Base exception for sharing operations."""

    pass


class ImportError(SharingError):
    """Error during content import."""

    def __init__(
        self,
        url: str,
        reason: str,
        cause: Exception | None = None,
    ) -> None:
        super().__init__(f"Failed to import from {url}: {reason}")
        self.url = url
        self.reason = reason
        self.cause = cause


class FetchError(SharingError):
    """Error fetching content from URL."""

    def __init__(
        self,
        url: str,
        reason: str,
        cause: Exception | None = None,
    ) -> None:
        super().__init__(f"Failed to fetch {url}: {reason}")
        self.url = url
        self.reason = reason
        self.cause = cause


class ContentValidationError(SharingError):
    """Error validating imported content."""

    def __init__(
        self,
        content_type: str,
        reason: str,
        errors: list[str] | None = None,
    ) -> None:
        msg = f"Invalid {content_type}: {reason}"
        if errors:
            msg += f" ({len(errors)} errors)"
        super().__init__(msg)
        self.content_type = content_type
        self.reason = reason
        self.errors = errors or []


class ContentTypeDetectionError(SharingError):
    """Could not auto-detect content type."""

    def __init__(self, url: str) -> None:
        super().__init__(
            f"Could not detect content type for {url}. "
            "Use --type to specify profile or spec."
        )
        self.url = url


class SecurityScanError(SharingError):
    """Security scan found critical issues."""

    def __init__(
        self,
        url: str,
        findings: list[str],
    ) -> None:
        msg = f"Security scan failed for {url}: {len(findings)} critical issue(s) found"
        super().__init__(msg)
        self.url = url
        self.findings = findings


class ProfileExistsError(SharingError):
    """Profile already exists in store."""

    def __init__(self, name: str, path: str) -> None:
        super().__init__(f"Profile already exists: {name} (at {path})")
        self.name = name
        self.path = path


class SpecExistsError(SharingError):
    """Spec already exists in store."""

    def __init__(self, name: str, path: str) -> None:
        super().__init__(f"Spec already exists: {name} (at {path})")
        self.name = name
        self.path = path


class URLResolveError(SharingError):
    """Error resolving URL reference."""

    def __init__(self, reference: str, reason: str) -> None:
        super().__init__(f"Could not resolve '{reference}': {reason}")
        self.reference = reference
        self.reason = reason
