"""Exceptions for CRIU checkpoint/restore operations."""

from __future__ import annotations


class CheckpointError(Exception):
    """Base exception for checkpoint operations."""

    def __init__(self, message: str) -> None:
        self.message = message
        super().__init__(message)


class ContainerNotFoundError(CheckpointError):
    """Container not found."""

    def __init__(self, name: str) -> None:
        self.container_name = name
        super().__init__(f"Container not found: {name}")


class ContainerNotRunningError(CheckpointError):
    """Container is not running (required for checkpoint)."""

    def __init__(self, name: str) -> None:
        self.container_name = name
        super().__init__(f"Container is not running: {name}")


class CheckpointNotFoundError(CheckpointError):
    """Checkpoint not found."""

    def __init__(self, container_name: str, checkpoint_name: str) -> None:
        self.container_name = container_name
        self.checkpoint_name = checkpoint_name
        super().__init__(f"Checkpoint not found: {container_name}/{checkpoint_name}")


class PolicyNotFoundError(CheckpointError):
    """Checkpoint policy not found."""

    def __init__(self, container_name: str) -> None:
        self.container_name = container_name
        super().__init__(f"Checkpoint policy not found for: {container_name}")


class CRIUNotAvailableError(CheckpointError):
    """CRIU is not installed or not working."""

    def __init__(self, reason: str | None = None) -> None:
        self.reason = reason
        msg = "CRIU is not available"
        if reason:
            msg = f"{msg}: {reason}"
        super().__init__(msg)


class CRIUKernelError(CheckpointError):
    """Kernel does not support CRIU features."""

    def __init__(self, feature: str) -> None:
        self.feature = feature
        super().__init__(f"Kernel does not support CRIU feature: {feature}")


class CRIUPermissionError(CheckpointError):
    """Insufficient permissions for CRIU operations."""

    def __init__(self, operation: str, reason: str | None = None) -> None:
        self.operation = operation
        self.reason = reason
        msg = f"Insufficient permissions for CRIU operation: {operation}"
        if reason:
            msg = f"{msg} ({reason})"
        super().__init__(msg)


class DockerExperimentalError(CheckpointError):
    """Docker experimental mode is not enabled."""

    def __init__(self) -> None:
        super().__init__(
            "Docker checkpoint requires experimental mode. "
            "Enable it in /etc/docker/daemon.json with {\"experimental\": true}"
        )


class CheckpointExecutionError(CheckpointError):
    """Error during checkpoint execution."""

    def __init__(self, message: str, output: str | None = None) -> None:
        self.output = output
        super().__init__(message)


class RestoreExecutionError(CheckpointError):
    """Error during restore execution."""

    def __init__(
        self, container_name: str, checkpoint_name: str, reason: str,
        output: str | None = None
    ) -> None:
        self.container_name = container_name
        self.checkpoint_name = checkpoint_name
        self.reason = reason
        self.output = output
        super().__init__(
            f"Restore failed for {container_name} from {checkpoint_name}: {reason}"
        )


class MigrationError(CheckpointError):
    """Error during live migration."""

    def __init__(
        self, container_name: str, target_host: str, reason: str,
        output: str | None = None
    ) -> None:
        self.container_name = container_name
        self.target_host = target_host
        self.reason = reason
        self.output = output
        super().__init__(
            f"Migration of {container_name} to {target_host} failed: {reason}"
        )


class MigrationTargetError(CheckpointError):
    """Error with migration target host."""

    def __init__(self, target_host: str, reason: str) -> None:
        self.target_host = target_host
        self.reason = reason
        super().__init__(f"Migration target {target_host} error: {reason}")


class VerificationError(CheckpointError):
    """Checkpoint verification failed."""

    def __init__(self, checkpoint_name: str, reason: str) -> None:
        self.checkpoint_name = checkpoint_name
        self.reason = reason
        super().__init__(
            f"Checkpoint verification failed for {checkpoint_name}: {reason}"
        )


class RetentionError(CheckpointError):
    """Error applying retention policy."""

    pass


class RuntimeNotSupportedError(CheckpointError):
    """Runtime does not support checkpointing."""

    def __init__(self, runtime: str) -> None:
        self.runtime = runtime
        super().__init__(f"Runtime does not support checkpointing: {runtime}")


class CheckpointImageError(CheckpointError):
    """Error with checkpoint image files."""

    def __init__(self, image_dir: str, reason: str) -> None:
        self.image_dir = image_dir
        self.reason = reason
        super().__init__(f"Checkpoint image error in {image_dir}: {reason}")
