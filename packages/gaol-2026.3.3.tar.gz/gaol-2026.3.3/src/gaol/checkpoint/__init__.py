"""CRIU checkpoint/restore functionality for gaol containers.

This module provides checkpoint/restore functionality including:
- CRIU checkpointing of running containers (memory, processes, FDs)
- Instant restore to previous state
- Docker experimental checkpoint support
- Live migration between hosts (future)

Example:
    >>> from gaol.checkpoint import get_checkpoint_manager
    >>> manager = get_checkpoint_manager()
    >>> result = manager.create("mycontainer", name="before-upgrade")
    >>> manager.list("mycontainer")
    >>> manager.restore("mycontainer", "before-upgrade")
"""

from gaol.checkpoint.exceptions import (
    CheckpointError,
    CheckpointExecutionError,
    CheckpointImageError,
    CheckpointNotFoundError,
    ContainerNotFoundError,
    ContainerNotRunningError,
    CRIUKernelError,
    CRIUNotAvailableError,
    CRIUPermissionError,
    DockerExperimentalError,
    MigrationError,
    MigrationTargetError,
    PolicyNotFoundError,
    RestoreExecutionError,
    RetentionError,
    RuntimeNotSupportedError,
    VerificationError,
)
from gaol.checkpoint.executor import (
    CRIUExecutor,
    DockerCheckpointExecutor,
    NspawnCheckpointExecutor,
)
from gaol.checkpoint.manager import CheckpointManager, get_checkpoint_manager
from gaol.checkpoint.models import (
    CheckpointHistory,
    CheckpointMetadata,
    CheckpointPolicy,
    CheckpointResult,
    CheckpointStatus,
    CheckpointType,
    CRIUCapabilities,
    DockerCheckpointCapabilities,
    MigrationResult,
    RestoreResult,
    RuntimeType,
)
from gaol.checkpoint.store import CheckpointStore, get_checkpoint_store

__all__ = [
    # Manager
    "CheckpointManager",
    "get_checkpoint_manager",
    # Models
    "CheckpointStatus",
    "CheckpointType",
    "RuntimeType",
    "CheckpointMetadata",
    "CheckpointResult",
    "RestoreResult",
    "MigrationResult",
    "CheckpointPolicy",
    "CheckpointHistory",
    "CRIUCapabilities",
    "DockerCheckpointCapabilities",
    # Store
    "CheckpointStore",
    "get_checkpoint_store",
    # Executors
    "CRIUExecutor",
    "DockerCheckpointExecutor",
    "NspawnCheckpointExecutor",
    # Exceptions
    "CheckpointError",
    "ContainerNotFoundError",
    "ContainerNotRunningError",
    "CheckpointNotFoundError",
    "PolicyNotFoundError",
    "CRIUNotAvailableError",
    "CRIUKernelError",
    "CRIUPermissionError",
    "DockerExperimentalError",
    "CheckpointExecutionError",
    "RestoreExecutionError",
    "MigrationError",
    "MigrationTargetError",
    "VerificationError",
    "RetentionError",
    "RuntimeNotSupportedError",
    "CheckpointImageError",
]
