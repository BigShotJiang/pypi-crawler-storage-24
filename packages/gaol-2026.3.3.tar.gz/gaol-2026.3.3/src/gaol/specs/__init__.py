"""Declarative container specifications.

This module provides support for defining containers in YAML or TOML files.

Example YAML spec:
    name: my-dev-env
    runtime: docker
    distro: trixie

    resources:
      memory: 4G
      cpus: 2

    network:
      ports:
        - 8080:80
        - 53:53/udp
      dns:
        - 1.1.1.1

    volumes:
      - ~/projects:/workspace
      - ~/.ssh:/home/user/.ssh:ro

    profiles:
      - base
      - dev-python

    environment:
      EDITOR: vim

Usage:
    from gaol.specs import load_spec, load_spec_config

    # Load as ContainerSpec (user-friendly model)
    spec = load_spec("container.yaml")

    # Load as ContainerConfig (internal model)
    config = load_spec_config("container.yaml")
"""

from gaol.specs.loader import (
    SpecError,
    SpecLoader,
    SpecNotFoundError,
    SpecParseError,
    SpecValidationError,
    load_env_file,
    load_spec,
    load_spec_config,
    spec_to_toml,
    spec_to_yaml,
)
from gaol.specs.models import (
    ContainerSpec,
    SpecNetwork,
    SpecResources,
    parse_cpu,
    parse_memory,
    parse_port_mapping,
    parse_volume,
)

__all__ = [
    # Main functions
    "load_spec",
    "load_spec_config",
    "load_env_file",
    "spec_to_yaml",
    "spec_to_toml",
    # Models
    "ContainerSpec",
    "SpecNetwork",
    "SpecResources",
    # Parsers
    "parse_memory",
    "parse_cpu",
    "parse_port_mapping",
    "parse_volume",
    # Loader
    "SpecLoader",
    # Exceptions
    "SpecError",
    "SpecNotFoundError",
    "SpecParseError",
    "SpecValidationError",
]
