"""Spec store for imported container specs."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING

import yaml

from gaol.config import get_config_dir
from gaol.sharing.exceptions import SpecExistsError
from gaol.specs.models import ContainerSpec

if TYPE_CHECKING:
    from gaol.sharing.models import ImportedContentMetadata

logger = logging.getLogger(__name__)


class SpecStore:
    """Store imported specs locally.

    Stores specs in ~/.config/gaol/specs/imported/.
    Each spec is stored as a YAML file with optional metadata.

    Example:
        >>> store = SpecStore()
        >>> store.save(spec, name="webserver")
        >>> spec = store.get("webserver")
        >>> store.list()
        ['webserver', 'database']
    """

    STORE_SUBDIR = "specs/imported"
    METADATA_SUFFIX = ".meta.yaml"

    def __init__(self, store_dir: Path | None = None) -> None:
        """Initialize the spec store.

        Args:
            store_dir: Custom store directory (defaults to config dir)
        """
        if store_dir is not None:
            self._store_dir = store_dir
        else:
            self._store_dir = get_config_dir() / self.STORE_SUBDIR
        self._store_dir.mkdir(parents=True, exist_ok=True)

    @property
    def store_dir(self) -> Path:
        """Get the store directory."""
        return self._store_dir

    def save(
        self,
        spec: ContainerSpec,
        name: str | None = None,
        metadata: ImportedContentMetadata | None = None,
        overwrite: bool = False,
    ) -> Path:
        """Save a spec to the store.

        Args:
            spec: Spec to save
            name: Name for the spec (uses spec.name if None)
            metadata: Optional import metadata
            overwrite: Overwrite if exists

        Returns:
            Path where spec was saved

        Raises:
            SpecExistsError: If spec exists and overwrite=False
        """
        spec_name = name or spec.name
        spec_path = self._spec_path(spec_name)

        if spec_path.exists() and not overwrite:
            raise SpecExistsError(spec_name, str(spec_path))

        # Save spec as YAML
        spec_data = spec.model_dump(exclude_defaults=True, exclude_none=True)
        spec_data["name"] = spec_name  # Ensure name matches

        with open(spec_path, "w") as f:
            yaml.dump(spec_data, f, default_flow_style=False, sort_keys=False)

        logger.info(f"Saved spec '{spec_name}' to {spec_path}")

        # Save metadata if provided
        if metadata is not None:
            metadata_path = self._metadata_path(spec_name)
            with open(metadata_path, "w") as f:
                yaml.dump(
                    metadata.model_dump(exclude_none=True),
                    f,
                    default_flow_style=False,
                )

        return spec_path

    def get(self, name: str) -> ContainerSpec | None:
        """Get a spec by name.

        Args:
            name: Spec name

        Returns:
            ContainerSpec or None if not found
        """
        spec_path = self._spec_path(name)

        if not spec_path.exists():
            return None

        with open(spec_path) as f:
            data = yaml.safe_load(f)

        return ContainerSpec(**data)

    def get_metadata(self, name: str) -> dict | None:
        """Get metadata for a spec.

        Args:
            name: Spec name

        Returns:
            Metadata dict or None if not found
        """
        metadata_path = self._metadata_path(name)

        if not metadata_path.exists():
            return None

        with open(metadata_path) as f:
            return yaml.safe_load(f)

    def delete(self, name: str) -> bool:
        """Delete a spec from the store.

        Args:
            name: Spec name

        Returns:
            True if deleted, False if not found
        """
        spec_path = self._spec_path(name)
        metadata_path = self._metadata_path(name)

        if not spec_path.exists():
            return False

        spec_path.unlink()
        if metadata_path.exists():
            metadata_path.unlink()

        logger.info(f"Deleted spec '{name}'")
        return True

    def list(self) -> list[str]:
        """List all stored spec names.

        Returns:
            Sorted list of spec names
        """
        specs = []
        for path in self._store_dir.glob("*.yaml"):
            # Skip metadata files
            if path.name.endswith(self.METADATA_SUFFIX):
                continue
            specs.append(path.stem)
        return sorted(specs)

    def exists(self, name: str) -> bool:
        """Check if a spec exists.

        Args:
            name: Spec name

        Returns:
            True if spec exists
        """
        return self._spec_path(name).exists()

    def _spec_path(self, name: str) -> Path:
        """Get the path for a spec file."""
        return self._store_dir / f"{name}.yaml"

    def _metadata_path(self, name: str) -> Path:
        """Get the path for a spec's metadata file."""
        return self._store_dir / f"{name}{self.METADATA_SUFFIX}"


# Module-level store instance
_store: SpecStore | None = None


def get_spec_store() -> SpecStore:
    """Get the global spec store instance.

    Returns:
        SpecStore instance
    """
    global _store
    if _store is None:
        _store = SpecStore()
    return _store
