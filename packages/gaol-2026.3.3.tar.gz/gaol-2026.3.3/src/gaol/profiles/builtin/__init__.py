"""Built-in profile definitions."""
