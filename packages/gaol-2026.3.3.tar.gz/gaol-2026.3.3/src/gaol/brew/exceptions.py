"""Homebrew wrapper exceptions."""

from __future__ import annotations


class BrewError(Exception):
    """Base exception for Homebrew wrapper errors."""

    pass


class BrewContainerError(BrewError):
    """Error with the Homebrew container."""

    pass


class BrewInstallError(BrewError):
    """Error installing a Homebrew package."""

    def __init__(self, package: str, reason: str) -> None:
        self.package = package
        super().__init__(f"Failed to install '{package}': {reason}")


class BrewPackageNotFoundError(BrewError):
    """Homebrew package not found."""

    def __init__(self, package: str) -> None:
        self.package = package
        super().__init__(f"Package '{package}' not found")


class WrapperExistsError(BrewError):
    """Wrapper script already exists."""

    def __init__(self, binary: str, path: str) -> None:
        self.binary = binary
        self.path = path
        super().__init__(f"Wrapper for '{binary}' already exists at {path}")


class WrapperNotFoundError(BrewError):
    """Wrapper script not found."""

    def __init__(self, package: str) -> None:
        self.package = package
        super().__init__(f"No wrapper found for package '{package}'")
