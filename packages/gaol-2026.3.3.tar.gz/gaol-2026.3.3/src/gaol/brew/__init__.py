"""Homebrew wrapper for containerized package execution.

This module provides transparent execution of Homebrew packages
inside isolated containers with wrapper scripts in ~/.local/bin/.

Features:
- Install Homebrew packages in a shared container
- Generate wrapper scripts for transparent execution
- Mount home directory for file access
- Track installed packages and wrappers

Example:
    >>> from gaol.brew import BrewContainer, WrapperInstaller
    >>> # Install a package
    >>> container = BrewContainer()
    >>> exit_code, stdout, stderr = container.install_package("ffmpeg")
    >>> # Create wrapper scripts
    >>> binaries = container.get_package_binaries("ffmpeg")
    >>> installer = WrapperInstaller()
    >>> installed = installer.install("ffmpeg", binaries)
    >>> # Now `ffmpeg` works transparently from ~/.local/bin/
"""

from __future__ import annotations

from gaol.brew.container import BrewContainer
from gaol.brew.exceptions import (
    BrewContainerError,
    BrewError,
    BrewInstallError,
    BrewPackageNotFoundError,
    WrapperExistsError,
    WrapperNotFoundError,
)
from gaol.brew.models import BrewConfig, InstalledPackage
from gaol.brew.wrapper import WrapperInstaller

__all__ = [
    # Container
    "BrewContainer",
    # Wrapper
    "WrapperInstaller",
    # Models
    "BrewConfig",
    "InstalledPackage",
    # Exceptions
    "BrewError",
    "BrewContainerError",
    "BrewInstallError",
    "BrewPackageNotFoundError",
    "WrapperExistsError",
    "WrapperNotFoundError",
]
