"""Pydantic models for Homebrew wrapper.

This module defines the data structures for tracking installed
Homebrew packages and wrapper scripts.
"""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, Field


class InstalledPackage(BaseModel):
    """Record of an installed Homebrew package with wrapper.

    Tracks which packages have been installed via gaol brew
    and where their wrapper scripts are located.
    """

    package_name: str
    """Homebrew formula name (e.g., 'ffmpeg')."""

    container_name: str = "homebrew"
    """Container where package is installed."""

    wrapper_path: str
    """Path to wrapper script (e.g., ~/.local/bin/ffmpeg)."""

    binaries: list[str] = Field(default_factory=list)
    """List of binaries provided by the package."""

    installed_at: datetime = Field(default_factory=datetime.now)
    """When the package was installed."""

    version: str | None = None
    """Package version if known."""


class BrewConfig(BaseModel):
    """Configuration for Homebrew wrapper."""

    container_name: str = "homebrew"
    """Name of the Homebrew container."""

    wrapper_dir: str | None = None
    """Directory for wrapper scripts (default: ~/.local/bin)."""

    mount_home: bool = True
    """Whether to mount $HOME into container."""

    runtime: str = "docker"
    """Container runtime to use."""

    distro: str = "bookworm"
    """Base distribution for the container."""
