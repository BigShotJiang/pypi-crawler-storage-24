"""Copy-on-Write filesystem support for gaol containers.

This module provides CoW filesystem management with two backends:
- btrfs: Subvolumes with snapshots, send/receive for backups
- ZFS: Datasets with snapshots, clones, compression, quotas

Example:
    >>> from gaol.cow import PoolConfig, get_cow_manager
    >>> manager = get_cow_manager()
    >>> config = PoolConfig(name="mypool", mount_point="/mnt/btrfs")
    >>> pool = manager.init_pool(config)
    >>> manager.create_dataset(DatasetConfig(name="containers", pool="mypool"))
    >>> manager.create_snapshot("mypool", "containers", "v1")
    >>> manager.create_clone(CloneConfig(
    ...     name="containers-test",
    ...     source_snapshot="mypool/containers@v1",
    ...     pool="mypool"
    ... ))
"""

from gaol.cow.exceptions import (
    BackendNotAvailableError,
    CloneNotFoundError,
    CoWError,
    DatasetExistsError,
    DatasetNotEmptyError,
    DatasetNotFoundError,
    InsufficientPermissionsError,
    InvalidMountPointError,
    PoolExistsError,
    PoolNotEmptyError,
    PoolNotFoundError,
    QuotaError,
    SendReceiveError,
    SnapshotExistsError,
    SnapshotHasClonesError,
    SnapshotNotFoundError,
)
from gaol.cow.manager import CoWManager, get_cow_manager
from gaol.cow.models import (
    CloneConfig,
    CoWBackendType,
    DatasetConfig,
    DatasetState,
    DatasetsStore,
    PoolConfig,
    PoolsStore,
    PoolState,
    PoolStatus,
    SendOptions,
    Snapshot,
)
from gaol.cow.store import CoWStore

__all__ = [
    # Manager
    "CoWManager",
    "get_cow_manager",
    # Store
    "CoWStore",
    # Models
    "CoWBackendType",
    "PoolConfig",
    "PoolState",
    "PoolStatus",
    "PoolsStore",
    "DatasetConfig",
    "DatasetState",
    "DatasetsStore",
    "Snapshot",
    "CloneConfig",
    "SendOptions",
    # Exceptions
    "CoWError",
    "PoolNotFoundError",
    "PoolExistsError",
    "PoolNotEmptyError",
    "DatasetNotFoundError",
    "DatasetExistsError",
    "DatasetNotEmptyError",
    "SnapshotNotFoundError",
    "SnapshotExistsError",
    "SnapshotHasClonesError",
    "CloneNotFoundError",
    "BackendNotAvailableError",
    "InvalidMountPointError",
    "InsufficientPermissionsError",
    "SendReceiveError",
    "QuotaError",
]
