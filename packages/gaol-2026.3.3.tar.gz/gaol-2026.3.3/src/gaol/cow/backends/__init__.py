"""CoW backend factory and exports."""

from __future__ import annotations

from gaol.cow.backends.base import CoWBackendBase
from gaol.cow.backends.btrfs import BtrfsBackend
from gaol.cow.backends.zfs import ZfsBackend
from gaol.cow.exceptions import BackendNotAvailableError
from gaol.cow.models import CoWBackendType

__all__ = [
    "CoWBackendBase",
    "BtrfsBackend",
    "ZfsBackend",
    "get_backend",
]


def get_backend(backend_type: CoWBackendType) -> CoWBackendBase:
    """Get a backend instance by type.

    Args:
        backend_type: Type of backend to get

    Returns:
        Backend instance

    Raises:
        BackendNotAvailableError: If backend is not available
    """
    backends: dict[CoWBackendType, type[CoWBackendBase]] = {
        CoWBackendType.BTRFS: BtrfsBackend,
        CoWBackendType.ZFS: ZfsBackend,
    }

    backend_class = backends.get(backend_type)
    if not backend_class:
        raise BackendNotAvailableError(
            backend_type.value, f"Unknown backend type: {backend_type}"
        )

    backend = backend_class()
    if not backend.is_available():
        raise BackendNotAvailableError(
            backend_type.value, f"{backend.name} tools not installed"
        )

    return backend
