"""Background scheduler for automatic container updates."""

from __future__ import annotations

import logging
import threading
import time
from datetime import datetime, timedelta
from typing import TYPE_CHECKING, Callable

from gaol.update.models import (
    SchedulerState,
    UpdatePolicy,
    UpdateResult,
    UpdateScheduleType,
)
from gaol.update.store import UpdateStore

if TYPE_CHECKING:
    pass


logger = logging.getLogger(__name__)


class UpdateScheduler:
    """Background scheduler for automatic container updates.

    Monitors update policies and executes updates at scheduled times.
    Uses a daemon thread that checks every minute for due updates.

    Example:
        >>> scheduler = UpdateScheduler(store, on_update=run_update)
        >>> scheduler.start()
        >>> # Later...
        >>> scheduler.stop()
    """

    def __init__(
        self,
        store: UpdateStore,
        on_update: Callable[[str], UpdateResult] | None = None,
        check_interval: float = 60.0,
    ) -> None:
        """Initialize the scheduler.

        Args:
            store: Update store for policies and history
            on_update: Callback to execute updates (container_name) -> UpdateResult
            check_interval: Interval in seconds between schedule checks
        """
        self._store = store
        self._on_update = on_update
        self._check_interval = check_interval

        self._running = False
        self._thread: threading.Thread | None = None
        self._state = SchedulerState()
        self._lock = threading.Lock()

    @property
    def is_running(self) -> bool:
        """Check if scheduler is running."""
        return self._running

    @property
    def state(self) -> SchedulerState:
        """Get current scheduler state."""
        with self._lock:
            return self._state.model_copy()

    def start(self) -> None:
        """Start the scheduler background thread."""
        if self._running:
            logger.warning("Scheduler already running")
            return

        self._running = True
        with self._lock:
            self._state.running = True
            self._state.started_at = datetime.now()

        self._thread = threading.Thread(
            target=self._scheduler_loop,
            daemon=True,
            name="update-scheduler",
        )
        self._thread.start()
        logger.info("Update scheduler started")

    def stop(self) -> None:
        """Stop the scheduler background thread."""
        if not self._running:
            return

        self._running = False
        with self._lock:
            self._state.running = False

        if self._thread:
            self._thread.join(timeout=5.0)
            self._thread = None

        logger.info("Update scheduler stopped")

    def _scheduler_loop(self) -> None:
        """Main scheduler loop running in background thread."""
        while self._running:
            try:
                self._check_and_run_updates()
            except Exception as e:
                logger.error(f"Error in scheduler loop: {e}")

            # Sleep in small intervals to allow quick shutdown
            for _ in range(int(self._check_interval)):
                if not self._running:
                    break
                time.sleep(1.0)

    def _check_and_run_updates(self) -> None:
        """Check all policies and run due updates."""
        with self._lock:
            self._state.last_check = datetime.now()

        policies = self._store.list_policies()
        now = datetime.now()

        for policy in policies:
            if not policy.schedule.enabled:
                continue

            if policy.schedule.schedule_type == UpdateScheduleType.MANUAL:
                continue

            next_run = self._calculate_next_run(policy)
            if next_run is None:
                continue

            # Update state with next scheduled time
            with self._lock:
                self._state.next_scheduled[policy.container_name] = next_run

            # Check if update is due
            if now >= next_run:
                self._run_scheduled_update(policy)

    def _run_scheduled_update(self, policy: UpdatePolicy) -> None:
        """Run a scheduled update for a container."""
        container_name = policy.container_name
        logger.info(f"Running scheduled update for {container_name}")

        if self._on_update:
            try:
                result = self._on_update(container_name)
                logger.info(
                    f"Scheduled update for {container_name} completed: {result.status}"
                )
            except Exception as e:
                logger.error(f"Scheduled update for {container_name} failed: {e}")

        # Calculate and store next run time
        next_run = self._calculate_next_run_from_now(policy)
        if next_run:
            with self._lock:
                self._state.next_scheduled[policy.container_name] = next_run

    def _calculate_next_run(self, policy: UpdatePolicy) -> datetime | None:
        """Calculate when the next update should run.

        Uses history to determine if an update is due, then calculates
        the next scheduled time based on the policy schedule.

        Args:
            policy: Update policy with schedule configuration

        Returns:
            Next scheduled run time, or None if not applicable
        """
        schedule = policy.schedule
        history = self._store.get_history(policy.container_name)

        # Get last update time
        last_update = history.last_update

        if last_update is None:
            # Never updated - run immediately at next scheduled time
            return self._calculate_next_scheduled_time(schedule)

        # Calculate next run based on schedule type
        if schedule.schedule_type == UpdateScheduleType.DAILY:
            next_run = last_update + timedelta(days=1)
        elif schedule.schedule_type == UpdateScheduleType.WEEKLY:
            next_run = last_update + timedelta(weeks=1)
        elif schedule.schedule_type == UpdateScheduleType.MONTHLY:
            # Add approximately one month
            next_run = last_update + timedelta(days=28)
        else:
            return None

        # Adjust to scheduled time of day
        next_run = next_run.replace(
            hour=int(schedule.time_of_day.split(":")[0]),
            minute=int(schedule.time_of_day.split(":")[1]),
            second=0,
            microsecond=0,
        )

        return next_run

    def _calculate_next_run_from_now(self, policy: UpdatePolicy) -> datetime | None:
        """Calculate next run time starting from now."""
        return self._calculate_next_scheduled_time(policy.schedule)

    def _calculate_next_scheduled_time(
        self, schedule: "UpdateScheduleType | UpdatePolicy.schedule"
    ) -> datetime | None:
        """Calculate the next scheduled time based on schedule config.

        Args:
            schedule: Schedule configuration

        Returns:
            Next scheduled datetime
        """
        from gaol.update.models import UpdateSchedule

        if isinstance(schedule, UpdateScheduleType):
            return None

        if not isinstance(schedule, UpdateSchedule):
            return None

        now = datetime.now()
        hour = int(schedule.time_of_day.split(":")[0])
        minute = int(schedule.time_of_day.split(":")[1])

        if schedule.schedule_type == UpdateScheduleType.DAILY:
            # Next occurrence of the scheduled time
            next_time = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
            if next_time <= now:
                next_time += timedelta(days=1)
            return next_time

        elif schedule.schedule_type == UpdateScheduleType.WEEKLY:
            # Next occurrence on the scheduled day of week
            days_ahead = schedule.day_of_week - now.weekday()
            if days_ahead < 0:  # Target day already happened this week
                days_ahead += 7
            elif days_ahead == 0:
                # Same day - check if time has passed
                next_time = now.replace(
                    hour=hour, minute=minute, second=0, microsecond=0
                )
                if next_time <= now:
                    days_ahead = 7
                else:
                    return next_time

            next_time = now + timedelta(days=days_ahead)
            return next_time.replace(hour=hour, minute=minute, second=0, microsecond=0)

        elif schedule.schedule_type == UpdateScheduleType.MONTHLY:
            # Next occurrence on the scheduled day of month
            next_time = now.replace(
                day=schedule.day_of_month,
                hour=hour,
                minute=minute,
                second=0,
                microsecond=0,
            )
            if next_time <= now:
                # Move to next month
                if now.month == 12:
                    next_time = next_time.replace(year=now.year + 1, month=1)
                else:
                    next_time = next_time.replace(month=now.month + 1)
            return next_time

        return None

    def get_next_update(self, container_name: str) -> datetime | None:
        """Get the next scheduled update time for a container.

        Args:
            container_name: Container name

        Returns:
            Next scheduled update time, or None if not scheduled
        """
        with self._lock:
            return self._state.next_scheduled.get(container_name)

    def get_scheduled_updates(self) -> dict[str, datetime]:
        """Get all scheduled updates.

        Returns:
            Dictionary mapping container names to next update times
        """
        with self._lock:
            return dict(self._state.next_scheduled)

    def trigger_update(self, container_name: str) -> UpdateResult | None:
        """Manually trigger an update for a container.

        Args:
            container_name: Container name

        Returns:
            UpdateResult or None if no callback configured
        """
        if self._on_update:
            return self._on_update(container_name)
        return None

    def remove_container(self, container_name: str) -> None:
        """Remove a container from the scheduler state.

        Args:
            container_name: Container name to remove
        """
        with self._lock:
            self._state.next_scheduled.pop(container_name, None)


# Global scheduler instance
_scheduler: UpdateScheduler | None = None


def get_update_scheduler(
    store: UpdateStore | None = None,
    on_update: Callable[[str], UpdateResult] | None = None,
) -> UpdateScheduler:
    """Get the global update scheduler instance.

    Args:
        store: Update store (required on first call)
        on_update: Update callback (optional)

    Returns:
        Global UpdateScheduler instance
    """
    global _scheduler
    if _scheduler is None:
        if store is None:
            from gaol.update.store import get_update_store

            store = get_update_store()
        _scheduler = UpdateScheduler(store, on_update)
    return _scheduler
