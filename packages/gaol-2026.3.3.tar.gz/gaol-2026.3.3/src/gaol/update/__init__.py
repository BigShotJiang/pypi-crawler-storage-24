"""Container update management for gaol.

This module provides automatic update functionality for containers:
- Check for available package updates
- Apply updates with automatic rollback on failure
- Configurable update schedules (daily, weekly, monthly)
- Update history and reporting

Example:
    >>> from gaol.update import get_update_manager
    >>> manager = get_update_manager()
    >>>
    >>> # Check for updates
    >>> check = manager.check("mycontainer")
    >>> print(f"Updates available: {check.package_count}")
    >>>
    >>> # Apply updates
    >>> result = manager.apply("mycontainer")
    >>>
    >>> # Set up automatic updates
    >>> manager.set_schedule("mycontainer", "daily", "03:00")
"""

from gaol.update.exceptions import (
    ContainerNotFoundError,
    ContainerNotRunningError,
    HealthCheckFailedError,
    PackageManagerError,
    PolicyNotFoundError,
    RollbackError,
    SchedulerError,
    SnapshotError,
    UpdateError,
    UpdateExecutionError,
)
from gaol.update.models import (
    PackageUpdate,
    RollbackStrategy,
    SchedulerState,
    UpdateCheck,
    UpdateHistory,
    UpdatePolicy,
    UpdateResult,
    UpdateSchedule,
    UpdateScheduleType,
    UpdateStatus,
)
from gaol.update.manager import UpdateManager, get_update_manager
from gaol.update.scheduler import UpdateScheduler, get_update_scheduler
from gaol.update.store import UpdateStore, get_update_store

__all__ = [
    # Manager
    "UpdateManager",
    "get_update_manager",
    # Scheduler
    "UpdateScheduler",
    "get_update_scheduler",
    # Store
    "UpdateStore",
    "get_update_store",
    # Models
    "UpdateScheduleType",
    "UpdateStatus",
    "RollbackStrategy",
    "UpdateSchedule",
    "UpdatePolicy",
    "PackageUpdate",
    "UpdateResult",
    "UpdateCheck",
    "UpdateHistory",
    "SchedulerState",
    # Exceptions
    "UpdateError",
    "ContainerNotFoundError",
    "ContainerNotRunningError",
    "UpdateExecutionError",
    "PackageManagerError",
    "HealthCheckFailedError",
    "RollbackError",
    "SnapshotError",
    "SchedulerError",
    "PolicyNotFoundError",
]
