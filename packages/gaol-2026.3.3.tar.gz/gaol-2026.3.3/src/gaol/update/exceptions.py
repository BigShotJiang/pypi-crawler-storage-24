"""Exceptions for container update operations."""

from __future__ import annotations


class UpdateError(Exception):
    """Base exception for update operations."""

    def __init__(self, message: str) -> None:
        self.message = message
        super().__init__(message)


class ContainerNotFoundError(UpdateError):
    """Container not found in store."""

    def __init__(self, name: str) -> None:
        self.container_name = name
        super().__init__(f"Container not found: {name}")


class ContainerNotRunningError(UpdateError):
    """Container is not running."""

    def __init__(self, name: str) -> None:
        self.container_name = name
        super().__init__(f"Container not running: {name}")


class UpdateExecutionError(UpdateError):
    """Error during update execution."""

    def __init__(self, message: str, output: str | None = None) -> None:
        self.output = output
        super().__init__(message)


class PackageManagerError(UpdateError):
    """Error from package manager."""

    def __init__(self, package_manager: str, operation: str, stderr: str) -> None:
        self.package_manager = package_manager
        self.operation = operation
        self.stderr = stderr
        super().__init__(
            f"Package manager '{package_manager}' failed during {operation}: {stderr}"
        )


class HealthCheckFailedError(UpdateError):
    """Post-update health check failed."""

    def __init__(self, container_name: str, output: str | None = None) -> None:
        self.container_name = container_name
        self.output = output
        msg = f"Health check failed for container: {container_name}"
        if output:
            msg += f" - {output}"
        super().__init__(msg)


class RollbackError(UpdateError):
    """Error during rollback."""

    def __init__(self, container_name: str, reason: str) -> None:
        self.container_name = container_name
        self.reason = reason
        super().__init__(f"Rollback failed for {container_name}: {reason}")


class SnapshotError(UpdateError):
    """Error creating or restoring snapshot."""

    def __init__(self, operation: str, reason: str) -> None:
        self.operation = operation
        self.reason = reason
        super().__init__(f"Snapshot {operation} failed: {reason}")


class SchedulerError(UpdateError):
    """Error in update scheduler."""

    pass


class PolicyNotFoundError(UpdateError):
    """Update policy not found."""

    def __init__(self, container_name: str) -> None:
        self.container_name = container_name
        super().__init__(f"Update policy not found for: {container_name}")
