"""GPU passthrough support for gaol.

This module provides GPU detection, configuration, and passthrough
support for containers across different runtimes.

Supported GPU vendors:
- NVIDIA (via nvidia-container-toolkit)
- AMD (via ROCm)
- Intel (via DRI devices)

Example:
    # Detect available GPUs
    >>> from gaol.gpu import GPUDetector
    >>> gpus = GPUDetector.detect_all()
    >>> for gpu in gpus:
    ...     print(f"{gpu.vendor}: {gpu.name}")

    # Get GPU support info
    >>> support = GPUDetector.get_support_info()
    >>> print(f"NVIDIA: {support.nvidia_available}")

    # Configure GPU for Docker
    >>> from gaol.gpu import NvidiaGPU, GPUConfig
    >>> config = GPUConfig(enabled=True, device_ids=[0])
    >>> docker_config = NvidiaGPU.get_docker_config(config)
"""

from __future__ import annotations

from gaol.gpu.amd import AmdGPU
from gaol.gpu.detection import GPUDetector
from gaol.gpu.intel import IntelGPU
from gaol.gpu.models import (
    DeviceMapping,
    GPUConfig,
    GPUInfo,
    GPUSupport,
    GPUVendor,
)
from gaol.gpu.nvidia import NvidiaGPU

__all__ = [
    # Detection
    "GPUDetector",
    # Models
    "DeviceMapping",
    "GPUConfig",
    "GPUInfo",
    "GPUSupport",
    "GPUVendor",
    # Vendor handlers
    "AmdGPU",
    "IntelGPU",
    "NvidiaGPU",
]
