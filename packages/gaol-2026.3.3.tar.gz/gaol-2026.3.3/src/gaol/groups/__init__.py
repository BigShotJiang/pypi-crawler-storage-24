"""Container group orchestration module.

This module provides pod-like orchestration for managing multiple
containers as a unit with shared networking and dependency ordering.

Example:
    >>> from gaol.groups import GroupManager, GroupSpec, ContainerRef
    >>> spec = GroupSpec(
    ...     name="web-stack",
    ...     containers={
    ...         "db": ContainerRef(image="postgres:16"),
    ...         "api": ContainerRef(image="python:3.11", depends_on=["db"]),
    ...     }
    ... )
    >>> manager = GroupManager()
    >>> status = manager.up(spec)
"""

from gaol.groups.manager import GroupError, GroupManager, get_group_manager
from gaol.groups.models import (
    ContainerRef,
    GroupSpec,
    GroupState,
    GroupStatus,
    HealthCheckConfig,
    HealthCheckType,
    MemberStatus,
)
from gaol.groups.networking import GroupNetworkError, GroupNetworkManager
from gaol.groups.resolver import (
    CircularDependencyError,
    DependencyResolver,
    resolve_start_order,
    resolve_stop_order,
)
from gaol.groups.store import GroupStore, StoredGroup, get_group_store

__all__ = [
    # Models
    "ContainerRef",
    "GroupSpec",
    "GroupState",
    "GroupStatus",
    "HealthCheckConfig",
    "HealthCheckType",
    "MemberStatus",
    # Manager
    "GroupManager",
    "GroupError",
    "get_group_manager",
    # Store
    "GroupStore",
    "StoredGroup",
    "get_group_store",
    # Networking
    "GroupNetworkManager",
    "GroupNetworkError",
    # Resolver
    "DependencyResolver",
    "CircularDependencyError",
    "resolve_start_order",
    "resolve_stop_order",
]
