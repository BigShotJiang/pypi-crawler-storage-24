"""Prometheus metrics export for gaol containers.

This module provides:
- Prometheus metrics endpoint for container resource monitoring
- Alert rules for threshold-based alerts
- Grafana dashboard generation

Example:
    Start the metrics server::

        >>> from gaol.metrics import start_metrics_server
        >>> server = start_metrics_server(port=9100)
        >>> # ... server runs in background ...
        >>> server.stop()

    One-shot metrics export::

        >>> from gaol.metrics import get_prometheus_exporter
        >>> exporter = get_prometheus_exporter()
        >>> exporter.collect()
        >>> print(exporter.generate_metrics_text())

    Generate Grafana dashboard::

        >>> from gaol.metrics import generate_grafana_dashboard
        >>> dashboard_json = generate_grafana_dashboard()
"""

from gaol.metrics.alerts import AlertManager, get_alert_manager
from gaol.metrics.dashboard import (
    GrafanaDashboardGenerator,
    generate_grafana_dashboard,
)
from gaol.metrics.exceptions import (
    AlertRuleError,
    AlertRuleExistsError,
    AlertRuleNotFoundError,
    InvalidAlertRuleError,
    MetricsCollectionError,
    MetricsError,
    MetricsServerAlreadyRunningError,
    MetricsServerError,
    MetricsServerNotRunningError,
)
from gaol.metrics.exporter import PrometheusExporter, get_prometheus_exporter
from gaol.metrics.models import (
    AlertRule,
    AlertSeverity,
    AlertState,
    ContainerMetrics,
    MetricsServerConfig,
    MetricsSnapshot,
    MetricType,
)
from gaol.metrics.server import (
    MetricsServer,
    get_metrics_server,
    start_metrics_server,
    stop_metrics_server,
)
from gaol.metrics.store import MetricsStore, get_metrics_store

__all__ = [
    # Models
    "AlertRule",
    "AlertSeverity",
    "AlertState",
    "ContainerMetrics",
    "MetricsServerConfig",
    "MetricsSnapshot",
    "MetricType",
    # Exceptions
    "AlertRuleError",
    "AlertRuleExistsError",
    "AlertRuleNotFoundError",
    "InvalidAlertRuleError",
    "MetricsCollectionError",
    "MetricsError",
    "MetricsServerAlreadyRunningError",
    "MetricsServerError",
    "MetricsServerNotRunningError",
    # Core classes
    "AlertManager",
    "GrafanaDashboardGenerator",
    "MetricsServer",
    "MetricsStore",
    "PrometheusExporter",
    # Factory functions
    "generate_grafana_dashboard",
    "get_alert_manager",
    "get_metrics_server",
    "get_metrics_store",
    "get_prometheus_exporter",
    "start_metrics_server",
    "stop_metrics_server",
]
