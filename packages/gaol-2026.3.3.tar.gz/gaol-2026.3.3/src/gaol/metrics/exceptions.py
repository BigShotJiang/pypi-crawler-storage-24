"""Exceptions for the metrics module."""

from __future__ import annotations


class MetricsError(Exception):
    """Base exception for metrics-related errors."""

    pass


class MetricsServerError(MetricsError):
    """Error starting or running the metrics server."""

    def __init__(self, message: str, cause: Exception | None = None) -> None:
        super().__init__(message)
        self.cause = cause


class MetricsServerAlreadyRunningError(MetricsServerError):
    """Raised when attempting to start an already running server."""

    def __init__(self, host: str, port: int) -> None:
        super().__init__(f"Metrics server is already running on {host}:{port}")
        self.host = host
        self.port = port


class MetricsServerNotRunningError(MetricsServerError):
    """Raised when attempting to stop a server that isn't running."""

    def __init__(self) -> None:
        super().__init__("Metrics server is not running")


class MetricsCollectionError(MetricsError):
    """Error collecting metrics from a container."""

    def __init__(
        self, container_name: str, message: str, cause: Exception | None = None
    ) -> None:
        super().__init__(f"Failed to collect metrics for '{container_name}': {message}")
        self.container_name = container_name
        self.cause = cause


class AlertRuleError(MetricsError):
    """Error with alert rule configuration."""

    pass


class AlertRuleNotFoundError(AlertRuleError):
    """Raised when an alert rule is not found."""

    def __init__(self, rule_name: str) -> None:
        super().__init__(f"Alert rule not found: {rule_name}")
        self.rule_name = rule_name


class AlertRuleExistsError(AlertRuleError):
    """Raised when attempting to create a duplicate alert rule."""

    def __init__(self, rule_name: str) -> None:
        super().__init__(f"Alert rule already exists: {rule_name}")
        self.rule_name = rule_name


class InvalidAlertRuleError(AlertRuleError):
    """Raised when an alert rule configuration is invalid."""

    def __init__(self, rule_name: str, reason: str) -> None:
        super().__init__(f"Invalid alert rule '{rule_name}': {reason}")
        self.rule_name = rule_name
        self.reason = reason
