"""Security monitoring and policy management for gaol.

This module provides Falco-based security monitoring, custom rule management,
and automatic security profile generation (seccomp/AppArmor).

Example:
    from gaol.security import FalcoClient, get_falco_client

    # Get status
    client = get_falco_client()
    status = client.get_status()

    # Stream events
    client.connect()
    for event in client.stream_events(filter_priority=FalcoPriority.WARNING):
        print(f"{event.rule}: {event.output}")
"""

from gaol.security.apparmor import (
    AppArmorProfileGenerator,
    get_apparmor_generator,
)
from gaol.security.client import (
    FalcoClient,
    FalcoEventBuffer,
    get_falco_client,
)
from gaol.security.exceptions import (
    AppArmorNotAvailableError,
    FalcoConnectionError,
    FalcoInstallError,
    FalcoNotInstalledError,
    FalcoNotRunningError,
    ProfileGenerationError,
    ProfileNotFoundError,
    RuleExistsError,
    RuleNotFoundError,
    RuleValidationError,
    SeccompNotAvailableError,
    SecurityError,
    UnsupportedDistroError,
)
from gaol.security.installer import (
    FalcoInstaller,
    PackageManager,
    get_falco_installer,
)
from gaol.security.models import (
    AppArmorMode,
    AppArmorProfile,
    ContainerInfo,
    EventSummary,
    FalcoPriority,
    FalcoStatus,
    RuleList,
    SeccompAction,
    SeccompArch,
    SeccompProfile,
    SeccompSyscall,
    SecurityEvent,
    SecurityRule,
)
from gaol.security.rules import (
    RuleManager,
    get_rule_manager,
)
from gaol.security.seccomp import (
    SeccompProfileGenerator,
    get_seccomp_generator,
)

__all__ = [
    # Client
    "FalcoClient",
    "FalcoEventBuffer",
    "get_falco_client",
    # Installer
    "FalcoInstaller",
    "PackageManager",
    "get_falco_installer",
    # Rules
    "RuleManager",
    "get_rule_manager",
    # Seccomp
    "SeccompProfileGenerator",
    "get_seccomp_generator",
    # AppArmor
    "AppArmorProfileGenerator",
    "get_apparmor_generator",
    # Models
    "AppArmorMode",
    "AppArmorProfile",
    "ContainerInfo",
    "EventSummary",
    "FalcoPriority",
    "FalcoStatus",
    "RuleList",
    "SeccompAction",
    "SeccompArch",
    "SeccompProfile",
    "SeccompSyscall",
    "SecurityEvent",
    "SecurityRule",
    # Exceptions
    "AppArmorNotAvailableError",
    "FalcoConnectionError",
    "FalcoInstallError",
    "FalcoNotInstalledError",
    "FalcoNotRunningError",
    "ProfileGenerationError",
    "ProfileNotFoundError",
    "RuleExistsError",
    "RuleNotFoundError",
    "RuleValidationError",
    "SeccompNotAvailableError",
    "SecurityError",
    "UnsupportedDistroError",
]
