"""Exceptions for the security module."""

from __future__ import annotations


class SecurityError(Exception):
    """Base exception for security module."""

    pass


class FalcoConnectionError(SecurityError):
    """Failed to connect to Falco."""

    pass


class FalcoNotRunningError(SecurityError):
    """Falco service is not running."""

    pass


class FalcoNotInstalledError(SecurityError):
    """Falco is not installed."""

    pass


class FalcoInstallError(SecurityError):
    """Failed to install Falco."""

    pass


class UnsupportedDistroError(SecurityError):
    """Distribution not supported for Falco installation."""

    def __init__(self, distro: str) -> None:
        super().__init__(f"Unsupported distribution for Falco installation: {distro}")
        self.distro = distro


class RuleValidationError(SecurityError):
    """Invalid Falco rule."""

    def __init__(self, name: str, errors: list[str]) -> None:
        super().__init__(f"Invalid rule '{name}': {'; '.join(errors)}")
        self.name = name
        self.errors = errors


class RuleNotFoundError(SecurityError):
    """Rule not found."""

    def __init__(self, name: str) -> None:
        super().__init__(f"Rule not found: {name}")
        self.name = name


class RuleExistsError(SecurityError):
    """Rule already exists."""

    def __init__(self, name: str) -> None:
        super().__init__(f"Rule already exists: {name}")
        self.name = name


class ProfileGenerationError(SecurityError):
    """Failed to generate security profile."""

    pass


class ProfileNotFoundError(SecurityError):
    """Security profile not found."""

    def __init__(self, name: str) -> None:
        super().__init__(f"Profile not found: {name}")
        self.name = name


class AppArmorNotAvailableError(SecurityError):
    """AppArmor is not available on this system."""

    def __init__(self) -> None:
        super().__init__(
            "AppArmor is not available on this system. "
            "Check if the apparmor kernel module is loaded."
        )


class SeccompNotAvailableError(SecurityError):
    """Seccomp is not available on this system."""

    def __init__(self) -> None:
        super().__init__(
            "Seccomp is not available on this system. "
            "Check if your kernel supports seccomp."
        )
