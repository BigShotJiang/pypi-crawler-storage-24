# Domain-Based Security Patterns

Gaol provides domain-based isolation patterns using systemd-nspawn containers. This document covers practical use cases for security domains, template containers, and disposable containers.

## Security Domains

Security domains are color-coded trust levels that define what containers can do. Each domain has different network access, resource limits, and isolation policies.

| Domain | Color | Network | Use Case |
|--------|-------|---------|----------|
| Vault | Purple (#800080) | None | Secrets, keys, sensitive docs |
| Work | Blue (#0066B3) | Full | Professional/employer systems |
| Personal | Green (#00AA00) | Full | Personal accounts, banking |
| Self-Hosted | Orange (#FF8C00) | Full | Git forges, wikis, media servers |
| Untrusted | Red (#CC0000) | Full (restricted) | Unknown content, testing |
| Disposable | Gray (#808080) | Full | One-time tasks, destroyed after |

---

## Use Cases by Domain

### Vault (Purple) - No Network

**Purpose:** Store secrets that should never touch the network.

**Examples:**
- **GPG/SSH key storage** - Private keys live here, other containers send signing requests
- **Password manager vault** - KeePassXC database, only accessed via copy/paste
- **Cryptocurrency wallets** - Cold storage, air-gapped signing
- **Sensitive documents** - Tax returns, legal docs, medical records
- **Backup encryption keys** - Master keys for encrypted backups

```bash
# Create a vault container
gaol create gpg-vault --runtime nspawn
gaol domain assign gpg-vault vault

# Vault policy: no network, isolated storage
# Keys never leave this container
```

### Work (Blue) - Trusted, Full Network

**Purpose:** Professional work with employer's systems.

**Examples:**
- **Corporate email/Slack** - Separate from personal accounts
- **VPN to employer network** - Access internal resources
- **Development for work projects** - IDE, git with work credentials
- **Client-specific containers** - One per client for consultants
- **Video conferencing** - Zoom/Teams isolated from personal browsing

```bash
# Create work containers per client/employer
gaol template-container create work-base -d trixie -p base -p dev
gaol template-container spawn work-base work-client-a
gaol template-container spawn work-base work-client-b

gaol domain assign work-client-a work
gaol domain assign work-client-b work

# Each client gets isolated credentials and browser profiles
```

### Personal (Green) - Moderate Trust

**Purpose:** Your personal identity, accounts you care about.

**Examples:**
- **Personal email/calendar** - Gmail, personal accounts
- **Banking and finance** - Banks, investment accounts
- **Social media** - Twitter, LinkedIn (your real identity)
- **Shopping** - Amazon, with saved payment methods
- **Photo management** - Accessing cloud photos
- **Personal development** - Side projects, personal GitHub

```bash
gaol create personal-browser --runtime nspawn
gaol domain assign personal-browser personal

# Personal domain: full network, but isolated from work
```

### Self-Hosted (Orange) - Services You Run

**Purpose:** Long-running services you host yourself, accessible to both personal and work domains.

**Examples:**
- **Git forge** - Soft Serve, Gitea, or Forgejo for personal/work repos
- **Wiki/knowledge base** - Outline, BookStack, or Wiki.js
- **Media server** - Jellyfin, Navidrome for music/video
- **File sync** - Nextcloud, Syncthing
- **Password manager server** - Vaultwarden for family/team
- **Home automation** - Home Assistant, Node-RED

```bash
# Create a self-hosted git server
gaol apply soft-serve.yaml --start
gaol domain assign soft-serve self-hosted

# Self-hosted policy: full network, persistent, can talk to personal & work
```

### Untrusted (Red) - Heavy Restrictions

**Purpose:** Activities that might compromise you.

**Examples:**
- **Random web browsing** - Links from unknown sources
- **Downloading software** - Testing apps before trusting them
- **Opening email attachments** - PDFs, Office docs from strangers
- **Online forums** - Reddit, HN, with throwaway accounts
- **Research on sketchy topics** - Security research, OSINT
- **Running untrusted code** - Scripts from the internet

```bash
# Create untrusted browser with red theme
gaol disposable create untrusted-browser \
  -t debian-browser \
  -a /usr/bin/firefox \
  --color "#CC0000"

gaol domain assign untrusted-browser untrusted

# Untrusted policy: read-only root, memory limits, no persistence
```

### Disposable (Gray) - Use Once, Destroy

**Purpose:** One-time tasks with untrusted content. Container is destroyed after use.

**Examples:**
- **Opening unknown PDFs** - "invoice.pdf" from unknown sender
- **Clicking suspicious links** - That weird URL someone sent
- **Testing malware samples** - Security research
- **Anonymous browsing** - One-off searches you don't want linked
- **Running untrusted scripts** - `curl | bash` you want to inspect first
- **Viewing sensitive content** - Content you don't want in browser history

```bash
# Open suspicious file - container destroyed after viewer exits
gaol disposable open-file sketchy-invoice.pdf

# Launch fresh browser instance - no history from previous sessions
gaol disposable launch throwaway-browser

# Each launch starts completely fresh
```

---

## Real-World Workflows

### Freelance Developer / Consultant

Separate containers for each client prevents credential leakage and maintains professional boundaries.

```
vault/            → GPG keys, client credentials vault (no network)
work-client-a/    → Client A's codebase, their Slack, their VPN
work-client-b/    → Client B's codebase, their systems
work-client-c/    → Client C's environment
personal/         → Personal email, banking, side projects
untrusted/        → Random browsing, Stack Overflow
disposable/       → Opening client attachments safely
```

**Benefits:**
- Client A's credentials can't accidentally leak to Client B
- Each client sees only their container's browser history
- Compromise of one client environment doesn't affect others

### Security Researcher

Isolated environments for handling malware and exploits.

```
vault/            → Private keys, exploit POCs (no network)
analysis/         → Malware samples, analysis tools (isolated network)
research/         → Documentation, writeups
personal/         → Normal daily life
untrusted/        → Testing exploits against sandboxed targets
disposable/       → Running malware samples (destroyed after)
```

**Benefits:**
- Malware can't phone home from vault
- Each sample runs in fresh disposable
- Research notes separated from active analysis

### Privacy-Conscious User

Multiple identity separation with VPN/Tor integration.

```
vault/            → Password database, 2FA backup codes (no network)
mullvad-browser/  → Anonymous browsing via VPN (Denmark exit)
mullvad-svc/      → Services requiring VPN (US exit)
tor-browser/      → Maximum anonymity via Tor
personal/         → Real identity, banking
untrusted/        → Random browsing (no logins)
disposable/       → One-time anonymous searches
```

**Benefits:**
- Different VPN exits for different purposes
- Tor for activities requiring maximum anonymity
- Personal identity completely separated from anonymous activity

### Corporate Employee with Side Projects

Strict separation between employer and personal work.

```
work/             → Employer's email, code, VPN to corporate network
personal/         → Side projects, personal GitHub, personal email
banking/          → Banks, financial accounts (isolated from both)
untrusted/        → Lunch break browsing, news
disposable/       → Opening random attachments
```

**Benefits:**
- Employer can't monitor personal projects
- Personal browsing can't leak into work
- Financial accounts isolated from potential compromise

### Journalist / Activist

Source protection and operational security.

```
vault/            → Encryption keys, source identities (no network)
secure-comms/     → Signal, encrypted email (via Tor)
research/         → OSINT, public research
work/             → Published articles, public identity
disposable/       → Receiving documents from sources
```

**Benefits:**
- Source identities never touch the network
- Research separated from communication
- Documents opened in disposable before moving to secure storage

---

## Container Chains (Advanced)

Chain containers together for defense in depth. Traffic flows through multiple security layers.

### Maximum Anonymity Chain

```
disposable-browser → sys-tor → sys-firewall → internet
```

- Fresh browser with no history
- All traffic routed through Tor
- Firewall enforces kill switch if Tor connection drops
- No DNS leaks possible

### Work VPN Chain

```
work-browser → sys-vpn-employer → internet
```

- Work traffic only goes through employer VPN
- Kill switch prevents leaks if VPN drops
- Employer can't see traffic from other containers

### Split-Trust Development

```
dev-container → sys-firewall → internet
                    ↓
              Allowed: github.com, npmjs.org, pypi.org
              Blocked: everything else
```

- Development container has filtered internet
- Can only reach package registries
- Prevents supply chain attacks from phoning home

### Multi-Hop Anonymity

```
high-risk-browser → sys-vpn → sys-tor → internet
```

- VPN hides Tor usage from ISP
- Tor hides destination from VPN provider
- Neither party sees the full picture

---

## Split Secrets Pattern

Keep private keys isolated in a vault container. Other containers request cryptographic operations without ever seeing the keys.

### GPG Split

```
┌─────────────────┐     signing request      ┌─────────────────┐
│  work-email     │ ─────────────────────────▶│   gpg-vault     │
│  (Blue/Work)    │                          │   (Purple/Vault)│
│                 │ ◀───────────────────────── │                 │
│  Compose email  │     signed message       │  Private keys   │
└─────────────────┘                          │  (no network)   │
                                             └─────────────────┘
```

```bash
# Create vault with GPG
gaol vault create gpg-vault --type gpg
gaol vault import-key gpg-vault ~/.gnupg/private.key

# Allow work container to request signatures
gaol vault allow gpg-vault --container work-email --operations sign

# Attach vault to work container
gaol vault attach work-email --vault gpg-vault

# In work-email container, signing works but key stays in vault
gpg --sign document.txt  # Request proxied to vault
```

### SSH Split

```bash
# Create SSH vault
gaol vault create ssh-vault --type ssh
gaol vault import-key ssh-vault ~/.ssh/id_ed25519

# Allow dev container to use SSH auth
gaol vault allow ssh-vault --container dev --operations ssh-auth

# In dev container
ssh git@github.com  # Auth happens in vault, key never exposed
```

---

## Why This Matters

### 1. Compromise Containment

Malware in the "untrusted" browser can't access:
- SSH keys in "vault"
- Work credentials in "work" containers
- Banking sessions in "personal"

### 2. Identity Separation

- Work browser can't accidentally access personal accounts
- Personal browsing can't leak into work systems
- Each identity has isolated cookies, history, and credentials

### 3. Credential Isolation

- Each client/project gets dedicated credentials
- Compromise of one doesn't affect others
- No accidental cross-contamination

### 4. Plausible Browsing

- "Personal" container has normal browsing history
- "Untrusted" is disposable with no history
- Sensitive research happens in isolated containers

### 5. Reduced Attack Surface

- Vault has no network stack to exploit
- Disposables have no persistent state to compromise
- Each container has minimal necessary access

---

## Quick Reference

### Creating a Security-Conscious Setup

```bash
# 1. Create base template
gaol template-container create debian-base -d trixie -p base

# 2. Create browser template
gaol template-container create debian-browser -d trixie -p base -p firefox

# 3. Set up disposable browser
gaol disposable create browser -t debian-browser \
  -a /usr/bin/firefox \
  --color "#CC0000" \
  --keep-downloads

# 4. Create desktop launcher
gaol disposable desktop browser

# 5. Create persistent work containers
gaol template-container spawn debian-browser work-main --start
gaol domain assign work-main work

# 6. Create vault (no network)
gaol create secrets-vault --runtime nspawn
gaol domain assign secrets-vault vault
```

### Daily Usage

```bash
# Open suspicious attachment
gaol disposable open-file untrusted-document.pdf

# Fresh anonymous browsing session
gaol disposable launch browser

# Work browsing (persistent)
gaol start work-main

# Check container domains
gaol domain list
gaol domain containers work
```

---

## Further Reading

- [Qubes OS Documentation](https://www.qubes-os.org/doc/)
- [Gaol Privacy Networking](./networking.md)
- [Template Container CLI Reference](../README.md)
