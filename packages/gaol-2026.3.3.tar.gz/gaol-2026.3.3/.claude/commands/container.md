---
description: Manage gaol containers (create, start, stop, exec, list)
argument-hint: <action> [name] [options]
---

# Container Management

Manage gaol containers with natural language commands.

## Actions

### Create
- `/container create <name>` - Create with defaults
- `/container create <name> with python` - Create with dev-python profile
- `/container create <name> with gpu` - Create with GPU support
- `/container create <name> from <spec.yaml>` - Create from spec file

### Lifecycle
- `/container start <name>` - Start a container
- `/container stop <name>` - Stop a container
- `/container restart <name>` - Restart a container
- `/container destroy <name>` - Remove a container

### Execute
- `/container exec <name> <command>` - Run command in container
- `/container shell <name>` - Open shell in container

### Info
- `/container list` - List all containers
- `/container status <name>` - Show container status
- `/container logs <name>` - View container logs

---

## Instructions

Parse the user's request and execute the appropriate gaol commands.

### For CREATE requests:

1. Parse the container name and any profiles/options mentioned
2. Map natural language to profiles:
   - "python", "py" → `--profile dev-python`
   - "node", "nodejs", "javascript" → `--profile dev-node`
   - "rust" → `--profile dev-rust`
   - "gui", "desktop", "graphical" → `--profile gui`
   - "gpu", "cuda", "ml", "machine learning" → `--gpu`
   - "vnc" → `--profile vnc`
   - "tailscale", "vpn" → `--profile tailscale`
3. Execute: `gaol create <name> --profile base [options] --start`
4. Report the result to the user

Example mappings:
- "create dev with python" → `gaol create dev --profile base --profile dev-python --start`
- "create ml-box with gpu and python" → `gaol create ml-box --profile dev-python --gpu --start`
- "create webserver with ports 80 and 443" → `gaol create webserver -p 80:80 -p 443:443 --start`

### For EXEC requests:

1. Parse container name and command
2. Execute: `gaol exec <name> -- <command>`
3. Show the output to the user

### For LIFECYCLE requests (start/stop/restart/destroy):

1. Parse the container name
2. Execute the appropriate command:
   - start: `gaol start <name>`
   - stop: `gaol stop <name>`
   - restart: `gaol stop <name> && gaol start <name>`
   - destroy: `gaol destroy <name> --force`
3. Confirm the action to the user

### For INFO requests:

1. Execute the appropriate command:
   - list: `gaol list --all-runtimes`
   - status: `gaol status <name>`
   - logs: `gaol logs <name> --tail 50`
2. Format and display the output

### Error Handling:

- If a container doesn't exist, suggest creating it
- If a command fails, show the error and suggest fixes
- If runtime is not available, suggest alternatives
