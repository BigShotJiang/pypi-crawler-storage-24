---
description: Manage gaol profiles (list, show, create, validate)
argument-hint: <action> [name]
---

# Profile Management

Manage gaol container profiles.

## Actions

- `/profile list` - List all available profiles
- `/profile show <name>` - Show profile details
- `/profile create <name>` - Create a new custom profile
- `/profile deps <name>` - Show profile dependency tree
- `/profile validate <file>` - Validate a profile file

---

## Instructions

### For LIST:
```bash
gaol profiles list
```
Display the output nicely, highlighting profile name, description, and dependencies.

### For SHOW:
```bash
gaol profiles show <name>
```
If the user wants more detail, read the profile YAML file:
- Built-in: `src/gaol/profiles/builtins/<name>.yaml`
- Custom: `~/.config/gaol/profiles/<name>.yaml`

### For CREATE:

Help the user create a custom profile:

1. Ask what the profile should do (packages, services, setup commands)
2. Generate a YAML file:

```yaml
name: <name>
description: <description>
version: "1.0.0"

depends_on:
  - base

packages:
  - package1
  - package2

setup_commands:
  - echo "Setup complete"

environment:
  KEY: value
```

3. Save to `~/.config/gaol/profiles/<name>.yaml`
4. Validate with: `gaol profiles validate <file>`

### For DEPS:
```bash
gaol profiles resolve <name>
```
Shows the order profiles will be applied.

### For VALIDATE:
```bash
gaol profiles validate <file>
```
Report any errors or warnings.

## Built-in Profiles

| Profile | Use Case |
|---------|----------|
| `base` | Essential tools (always include) |
| `dev-python` | Python development (uv, ruff, pytest) |
| `dev-node` | Node.js development (pnpm, prettier) |
| `dev-rust` | Rust development (rustc, cargo) |
| `gui` | X11/Wayland forwarding |
| `vnc` | VNC server access |
| `tailscale` | Tailscale VPN |
| `tor` | Tor network routing |
| `docker-in-docker` | Docker inside containers |
