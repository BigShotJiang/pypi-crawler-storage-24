---
description: Manage GPU passthrough for containers (list, check, create)
argument-hint: <action> [name/id]
---

# GPU Management

Manage GPU passthrough for containers.

## Actions

- `/gpu list` - List available GPUs
- `/gpu check` - Check GPU driver and runtime support
- `/gpu info <id>` - Show detailed GPU information
- `/gpu create <name>` - Create a GPU-enabled container

---

## Instructions

### For LIST:
```bash
gaol gpu list
```
Display available GPUs with device ID, vendor, model, memory, and PCI address.

### For CHECK:
```bash
gaol gpu check
```
Report on:
- NVIDIA driver status and version
- nvidia-container-runtime availability
- AMD ROCm status
- Intel DRI availability

If issues found, provide fixes:
- **No NVIDIA driver**: "Install nvidia-driver package"
- **No container runtime**: "Install nvidia-container-toolkit"
- **No ROCm**: "Install rocm packages for AMD GPU support"

### For INFO:
```bash
gaol gpu info <id>
```

### For CREATE:

1. Check GPU availability: `gaol gpu check`
2. Create container:
   ```bash
   gaol create <name> --gpu --profile dev-python --start
   ```
   Or with specific GPU:
   ```bash
   gaol create <name> --gpu --gpu-device 0 --start
   ```
3. Verify GPU access:
   ```bash
   # NVIDIA
   gaol exec <name> -- nvidia-smi
   # AMD
   gaol exec <name> -- rocm-smi
   ```

## GPU Container Examples

**Machine Learning (NVIDIA):**
```yaml
name: ml-dev
runtime: docker
profiles:
  - base
  - dev-python
gpu:
  enabled: true
  vendor: nvidia
volumes:
  - ./projects:/workspace
```

**Multi-GPU setup:**
```yaml
name: multi-gpu
runtime: docker
gpu:
  enabled: true
  device_ids: [0, 1]
```

## Troubleshooting

| Issue | Solution |
|-------|----------|
| "No GPUs detected" | Check if GPU is installed, drivers loaded |
| "NVIDIA runtime not available" | Install nvidia-container-toolkit |
| "Permission denied" | Add user to video/render groups |
