---
name: nix-environments
description: Use when the user wants reproducible development environments, mentions Nix, flakes, or needs exact version pinning for packages. Triggers for requests about reproducible builds, declarative package management, or nix-shell.
---

# Nix Integration for Containers

Create reproducible container environments using Nix.

## Quick Start

### Install Nix in Container
```bash
gaol nix init <container>
gaol nix status <container>
```

### Temporary Shell with Packages
```bash
gaol nix shell <container> --packages python311 nodejs git
```

### Install Packages Permanently
```bash
gaol nix install <container> python311 nodejs
gaol nix list <container>
gaol nix uninstall <container> nodejs
```

### Search for Packages
```bash
gaol nix search <container> python
```

## Nix Flakes

Create reproducible environments with flakes:

### Initialize a Flake
```bash
gaol nix flake init <container> /app --packages python311 nodejs
```

This creates a `flake.nix` like:
```nix
{
  description = "Gaol development environment";
  inputs.nixpkgs.url = "github:NixOS/nixpkgs/nixos-24.11";
  outputs = { self, nixpkgs }: {
    devShells.default = nixpkgs.mkShell {
      packages = [ nixpkgs.python311 nixpkgs.nodejs ];
    };
  };
}
```

### Enter Development Shell
```bash
gaol nix flake develop <container> /app
```

### Update Flake Lock
```bash
gaol nix flake update <container> /app
```

### Check Flake Validity
```bash
gaol nix flake check <container> /app
```

## Garbage Collection

Clean up unused packages:
```bash
gaol nix gc <container>
gaol nix gc <container> --delete-older-than 7d
```

## Package Name Mapping

Common package translations (Debian → Nix):
- python3 → python3
- python3-pip → python3Packages.pip
- nodejs → nodejs
- build-essential → gcc, gnumake, binutils
- vim → vim
- git → git

## When to Use Nix

- Need exact, reproducible package versions
- Want to share environments via `flake.lock`
- Need packages not in container's distro repos
- Want declarative, version-controlled environments
