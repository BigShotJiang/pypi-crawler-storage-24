---
name: project-containerization
description: Use when setting up a development environment for a project, analyzing project requirements, or creating container configurations. Triggers when user asks about containerizing a project, setting up dev environments, or mentions package.json, pyproject.toml, Cargo.toml, or similar project files.
---

# Project Containerization

Automatically analyze projects and create optimal container configurations.

## Project Detection

Scan for these files to determine project type:

| File | Type | Profile | Default Port |
|------|------|---------|--------------|
| `package.json` | Node.js | dev-node | 3000 |
| `pyproject.toml` | Python | dev-python | 8000 |
| `requirements.txt` | Python | dev-python | 8000 |
| `Cargo.toml` | Rust | dev-rust | 8080 |
| `go.mod` | Go | base | 8080 |
| `Gemfile` | Ruby | base | 3000 |
| `.devcontainer/` | VS Code | (import) | - |

## Workflow

1. **Analyze the project directory**
   ```bash
   ls -la
   ```

2. **Check for additional requirements**
   - GPU: Look for tensorflow, pytorch, cuda imports
   - Database: Look for ORM configs, connection strings
   - GUI: Look for Qt, GTK, Electron dependencies

3. **Generate spec file**
   ```yaml
   name: <project-name>
   runtime: docker
   profiles:
     - base
     - <detected-profile>
   volumes:
     - .:/workspace
   working_dir: /workspace
   network:
     ports:
       - <port>:<port>
   ```

4. **Create and start**
   ```bash
   gaol apply container.yaml --start
   ```

## Special Cases

**If .devcontainer exists:**
```bash
gaol devcontainer import -o container.yaml
```

**If .env.example exists:**
- Prompt user to create secrets
- Use `${secret:NAME}` syntax

## Post-Setup

Tell the user:
```
Container '<name>' is running!

Quick commands:
  gaol shell <name>           # Enter container
  gaol exec <name> -- pytest  # Run tests
  gaol logs <name> -f         # View logs
```
