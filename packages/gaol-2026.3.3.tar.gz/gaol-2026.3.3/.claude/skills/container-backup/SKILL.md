---
name: container-backup
description: Use when the user wants to save, restore, or back up container state. Triggers for requests about snapshots, backups, checkpoints, restoring containers, or disaster recovery.
---

# Container Backup & Snapshots

Save and restore container state with gaol.

## Snapshots

Quick point-in-time saves of container state:

```bash
# Create snapshot
gaol snapshot create <container> <snapshot-name>

# List snapshots
gaol snapshot list <container>

# Restore snapshot
gaol snapshot restore <container> <snapshot-name>

# Delete snapshot
gaol snapshot delete <container> <snapshot-name>
```

## Checkpoints (CRIU)

Full process state preservation (pause/resume):

```bash
# Create checkpoint
gaol checkpoint create <container> <checkpoint-name>

# List checkpoints
gaol checkpoint list <container>

# Restore from checkpoint
gaol checkpoint restore <container> <checkpoint-name>

# Migrate to another host
gaol checkpoint migrate <container> --to user@other-host
```

## Scheduled Backups

Automated backups with retention policies:

```bash
# Create manual backup
gaol backup create <container> --name daily-backup

# Schedule backups
gaol backup schedule <container> daily --time 02:00
gaol backup schedule <container> weekly --day 6 --time 02:00

# List backups
gaol backup list <container>

# Restore from backup
gaol backup restore <container> <backup-name>
```

## Export/Import

Transfer containers between systems:

```bash
# Export configuration
gaol export <container> -o container.yaml

# Export filesystem
gaol build image <container> --tag myapp:backup

# Import configuration
gaol import-config container.yaml --create --start
```

## Container Diff

Track changes since last snapshot:

```bash
# Compare to snapshot
gaol diff snapshots <container> --from baseline --to current

# Audit changes
gaol audit <container> --packages

# Compare two containers
gaol diff containers container-a container-b
```

## Copy-on-Write Storage

For efficient snapshots with btrfs/ZFS:

```bash
# Initialize pool
gaol cow init mypool /mnt/btrfs --backend btrfs

# Create instant snapshot
gaol cow snapshot-create mypool/containers@v1

# Clone container (zero-copy)
gaol cow clone mypool/containers@v1 containers-test
```

## Best Practices

1. **Before major changes**: Create a snapshot first
2. **Daily backups**: Schedule for critical containers
3. **Test restores**: Periodically verify backup integrity
4. **Audit changes**: Use `diff` to track modifications
