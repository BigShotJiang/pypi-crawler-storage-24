#!/bin/bash
# Tauri Overlay
# Adds: WebKit2GTK, system dependencies for Tauri v2 apps
#
# Requires: rust overlay (Tauri is Rust-based)
# Requires: node overlay (Tauri frontend typically uses npm/pnpm)
#
# Usage: Called by dev.sh during container creation
#   apply_tauri_overlay <container_name>

set -e

OVERLAY_NAME="tauri"

apply_tauri_overlay() {
    local container="$1"

    echo "[OVERLAY] Applying Tauri overlay to $container..."

    sudo machinectl shell "$container" /bin/bash -c '
# Tauri v2 system dependencies
# See: https://v2.tauri.app/start/prerequisites/#linux
DEBIAN_FRONTEND=noninteractive apt-get install -y \
    libwebkit2gtk-4.1-dev \
    libappindicator3-dev \
    librsvg2-dev \
    patchelf \
    libgtk-3-dev \
    libayatana-appindicator3-dev \
    libsoup-3.0-dev \
    libjavascriptcoregtk-4.1-dev

# Additional useful deps for Tauri apps
DEBIAN_FRONTEND=noninteractive apt-get install -y \
    libssl-dev \
    libxdo-dev \
    libdbus-1-dev

# Install tauri-cli via cargo (assumes rust overlay already applied)
su - dev -c "source ~/.cargo/env && cargo install tauri-cli"

# Also install via npm for those who prefer it
npm install -g @tauri-apps/cli

# Verify
su - dev -c "source ~/.cargo/env && cargo tauri --version" || echo "Note: Run after rust overlay"
'

    echo "[OVERLAY] Tauri overlay applied"
}

# Allow sourcing or direct execution
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    if [ -z "$1" ]; then
        echo "Usage: $0 <container_name>"
        exit 1
    fi
    apply_tauri_overlay "$1"
fi
