#!/bin/bash
# Rust Overlay
# Adds: rustup, cargo, common Rust tooling
#
# Usage: Called by dev.sh during container creation
#   apply_rust_overlay <container_name>

set -e

OVERLAY_NAME="rust"

apply_rust_overlay() {
    local container="$1"

    echo "[OVERLAY] Applying Rust overlay to $container..."

    sudo machinectl shell "$container" /bin/bash -c '
# Install Rust via rustup for dev user (not root)
su - dev -c "curl --proto '\''=https'\'' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y --default-toolchain stable"

# Add cargo to path in bashrc (rustup installer does this, but be explicit)
su - dev -c "echo '\''source \$HOME/.cargo/env'\'' >> ~/.bashrc"

# Install common components
su - dev -c "source ~/.cargo/env && rustup component add rustfmt clippy rust-analyzer"

# Install cargo tools useful for development
su - dev -c "source ~/.cargo/env && cargo install cargo-watch cargo-edit"

# Verify
su - dev -c "source ~/.cargo/env && rustc --version && cargo --version"
'

    echo "[OVERLAY] Rust overlay applied"
}

# Allow sourcing or direct execution
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    if [ -z "$1" ]; then
        echo "Usage: $0 <container_name>"
        exit 1
    fi
    apply_rust_overlay "$1"
fi
