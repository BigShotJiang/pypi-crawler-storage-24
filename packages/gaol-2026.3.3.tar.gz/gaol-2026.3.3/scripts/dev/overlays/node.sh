#!/bin/bash
# Node.js Overlay
# Adds: Node.js LTS, npm, pnpm
#
# Usage: Called by dev.sh during container creation
#   apply_node_overlay <container_name>

set -e

OVERLAY_NAME="node"

apply_node_overlay() {
    local container="$1"

    echo "[OVERLAY] Applying Node.js overlay to $container..."

    sudo machinectl shell "$container" /bin/bash -c '
# Install Node.js via NodeSource (LTS)
curl -fsSL https://deb.nodesource.com/setup_lts.x | bash -
DEBIAN_FRONTEND=noninteractive apt-get install -y nodejs

# Install pnpm globally
npm install -g pnpm

# Install yarn (some projects need it)
npm install -g yarn

# Corepack for managing package managers
corepack enable

# Verify installation
node --version
npm --version
pnpm --version
'

    echo "[OVERLAY] Node.js overlay applied"
}

# Allow sourcing or direct execution
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    if [ -z "$1" ]; then
        echo "Usage: $0 <container_name>"
        exit 1
    fi
    apply_node_overlay "$1"
fi
