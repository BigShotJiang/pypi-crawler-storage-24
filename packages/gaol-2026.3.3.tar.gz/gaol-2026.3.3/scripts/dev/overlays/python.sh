#!/bin/bash
# Python Overlay
# Adds: Python 3.12+, uv package manager, native deps for common packages
#
# Usage: Called by dev.sh during container creation
#   apply_python_overlay <container_name>

set -e

OVERLAY_NAME="python"

apply_python_overlay() {
    local container="$1"

    echo "[OVERLAY] Applying Python overlay to $container..."

    sudo machinectl shell "$container" /bin/bash -c '
# Install Python and dev headers
DEBIAN_FRONTEND=noninteractive apt-get install -y \
    python3 \
    python3-dev \
    python3-venv \
    python3-pip \
    python3-full

# Native deps for common Python packages (pillow, cryptography, etc.)
DEBIAN_FRONTEND=noninteractive apt-get install -y \
    libjpeg-dev \
    libpng-dev \
    libtiff-dev \
    libwebp-dev \
    libopenjp2-7-dev \
    libfreetype-dev \
    liblcms2-dev \
    libharfbuzz-dev \
    libfribidi-dev

# Install uv
curl -LsSf https://astral.sh/uv/install.sh | sh

# Make uv available system-wide
cp /root/.local/bin/uv /usr/local/bin/ 2>/dev/null || true
cp /root/.local/bin/uvx /usr/local/bin/ 2>/dev/null || true

# Also install for dev user
su - dev -c "curl -LsSf https://astral.sh/uv/install.sh | sh"

# Add to dev user path
echo '\''export PATH="$HOME/.local/bin:$PATH"'\'' >> /home/dev/.bashrc
'

    echo "[OVERLAY] Python overlay applied"
}

# Allow sourcing or direct execution
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    if [ -z "$1" ]; then
        echo "Usage: $0 <container_name>"
        exit 1
    fi
    apply_python_overlay "$1"
fi
