#!/bin/bash
# Shell Tools Overlay
# Adds: Modern CLI replacements and productivity tools
#
# Tools:
#   bat     - cat with syntax highlighting
#   eza     - modern ls replacement
#   fd      - fast find alternative
#   ripgrep - fast grep alternative
#   fzf     - fuzzy finder
#   zoxide  - smart cd with frecency
#   starship - cross-shell prompt
#   delta   - syntax-highlighted git diff
#   jq/yq   - JSON/YAML processors
#   gh      - GitHub CLI
#
# Usage: Called by dev.sh during container creation
#   apply_shell-tools_overlay <container_name>

set -e

OVERLAY_NAME="shell-tools"

apply_shell-tools_overlay() {
    local container="$1"

    echo "[OVERLAY] Applying shell-tools overlay to $container..."

    sudo machinectl shell "$container" /bin/bash -c '
# Install from Debian repos
DEBIAN_FRONTEND=noninteractive apt-get install -y \
    bat \
    fd-find \
    ripgrep \
    fzf \
    jq \
    zsh

# Install eza (modern ls)
DEBIAN_FRONTEND=noninteractive apt-get install -y eza || {
    # Fallback: install from GitHub releases if not in repos
    EZA_VERSION=$(curl -s https://api.github.com/repos/eza-community/eza/releases/latest | jq -r .tag_name)
    curl -Lo /tmp/eza.tar.gz "https://github.com/eza-community/eza/releases/download/${EZA_VERSION}/eza_x86_64-unknown-linux-gnu.tar.gz"
    tar -xzf /tmp/eza.tar.gz -C /usr/local/bin
    rm /tmp/eza.tar.gz
}

# Install zoxide
curl -sS https://raw.githubusercontent.com/ajeetdsouza/zoxide/main/install.sh | bash
cp /root/.local/bin/zoxide /usr/local/bin/ 2>/dev/null || true

# Install starship prompt
curl -sS https://starship.rs/install.sh | sh -s -- -y

# Install delta (git diff)
DELTA_VERSION=$(curl -s https://api.github.com/repos/dandavison/delta/releases/latest | jq -r .tag_name)
curl -Lo /tmp/delta.deb "https://github.com/dandavison/delta/releases/download/${DELTA_VERSION}/git-delta_${DELTA_VERSION}_amd64.deb"
dpkg -i /tmp/delta.deb || apt-get install -f -y
rm /tmp/delta.deb

# Install yq
YQ_VERSION=$(curl -s https://api.github.com/repos/mikefarah/yq/releases/latest | jq -r .tag_name)
curl -Lo /usr/local/bin/yq "https://github.com/mikefarah/yq/releases/download/${YQ_VERSION}/yq_linux_amd64"
chmod +x /usr/local/bin/yq

# Install GitHub CLI
curl -fsSL https://cli.github.com/packages/githubcli-archive-keyring.gpg | dd of=/usr/share/keyrings/githubcli-archive-keyring.gpg
chmod go+r /usr/share/keyrings/githubcli-archive-keyring.gpg
echo "deb [arch=$(dpkg --print-architecture) signed-by=/usr/share/keyrings/githubcli-archive-keyring.gpg] https://cli.github.com/packages stable main" > /etc/apt/sources.list.d/github-cli.list
apt-get update
apt-get install -y gh
'

    # Configure for dev user
    sudo machinectl shell "$container" /bin/bash -c '
# Setup aliases and integrations for dev user
cat >> /home/dev/.bashrc << '\''BASHRC'\''

# Modern CLI aliases
alias ls="eza --icons"
alias ll="eza -la --icons"
alias la="eza -a --icons"
alias lt="eza --tree --icons"
alias cat="batcat --paging=never"
alias bat="batcat"
alias grep="rg"
alias find="fdfind"
alias fd="fdfind"

# Zoxide (smart cd)
eval "$(zoxide init bash)"

# Starship prompt
eval "$(starship init bash)"

# fzf integration
[ -f /usr/share/doc/fzf/examples/key-bindings.bash ] && source /usr/share/doc/fzf/examples/key-bindings.bash
[ -f /usr/share/doc/fzf/examples/completion.bash ] && source /usr/share/doc/fzf/examples/completion.bash

# Git with delta
export GIT_PAGER="delta"
BASHRC

# Configure git to use delta
cat > /home/dev/.config/git/config << '\''GITCONFIG'\''
[core]
    pager = delta

[interactive]
    diffFilter = delta --color-only

[delta]
    navigate = true
    line-numbers = true
    side-by-side = false

[merge]
    conflictstyle = diff3

[diff]
    colorMoved = default
GITCONFIG

chown -R dev:dev /home/dev/.config
'

    echo "[OVERLAY] Shell tools overlay applied"
}

# Allow sourcing or direct execution
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    if [ -z "$1" ]; then
        echo "Usage: $0 <container_name>"
        exit 1
    fi
    apply_shell-tools_overlay "$1"
fi
