#!/bin/bash
# Claude Code Overlay
# Adds: Claude Code CLI (native installer), ripgrep, fd-find
#
# Usage: Called by dev.sh during container creation
#   apply_claude_overlay <container_name>

set -e

OVERLAY_NAME="claude"

apply_claude_overlay() {
    local container="$1"

    echo "[OVERLAY] Applying Claude Code overlay to $container..."

    # Install search tools and dependencies
    sudo machinectl shell "$container" /bin/bash -c '
# Install tools Claude Code uses for search
DEBIAN_FRONTEND=noninteractive apt-get install -y \
    ripgrep \
    fd-find
'

    # Install Claude Code using native installer for dev user
    sudo machinectl shell "$container" /bin/bash -c '
# Create claude config directory
mkdir -p /home/dev/.claude
chown -R dev:dev /home/dev/.claude

# Install Claude Code using native installer as dev user
su - dev -c "curl -fsSL https://claude.ai/install.sh | sh"

# Add to PATH and aliases
cat >> /home/dev/.bashrc << '\''BASHRC'\''

# Claude Code
export PATH="$HOME/.local/bin:$PATH"

# Claude Code aliases
alias cc="claude"
alias ccc="claude --continue"
BASHRC

# Verify installation
su - dev -c "~/.local/bin/claude --version" || echo "Claude installed, verify PATH on login"
'

    echo "[OVERLAY] Claude Code overlay applied"
    echo "[NOTE] Run '\''claude'\'' to authenticate and start using"
}

# Allow sourcing or direct execution
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    if [ -z "$1" ]; then
        echo "Usage: $0 <container_name>"
        exit 1
    fi
    apply_claude_overlay "$1"
fi
