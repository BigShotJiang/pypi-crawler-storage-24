"""Tests for monitoring module."""

from gaol.models.container import HealthCheck, HealthStatus
from gaol.monitoring import (
    create_command_health_check,
    create_http_health_check,
    create_tcp_health_check,
)


class TestHealthCheckFactories:
    """Tests for health check factory functions."""

    def test_create_http_health_check(self) -> None:
        """Test creating an HTTP health check."""
        check = create_http_health_check(port=8080, path="/healthz")
        assert check.command == ["curl", "-sf", "http://localhost:8080/healthz"]
        assert check.interval_seconds == 30
        assert check.timeout_seconds == 10
        assert check.retries == 3

    def test_create_http_health_check_custom_options(self) -> None:
        """Test creating an HTTP health check with custom options."""
        check = create_http_health_check(
            port=3000,
            path="/api/health",
            timeout=5,
            interval=10,
            retries=5,
        )
        assert "3000" in check.command[2]
        assert "/api/health" in check.command[2]
        assert check.timeout_seconds == 5
        assert check.interval_seconds == 10
        assert check.retries == 5

    def test_create_tcp_health_check(self) -> None:
        """Test creating a TCP health check."""
        check = create_tcp_health_check(port=5432)
        assert "5432" in " ".join(check.command)
        assert check.interval_seconds == 30
        assert check.retries == 3

    def test_create_tcp_health_check_custom_host(self) -> None:
        """Test creating a TCP health check with custom host."""
        check = create_tcp_health_check(port=6379, host="redis")
        assert "redis" in " ".join(check.command)
        assert "6379" in " ".join(check.command)

    def test_create_command_health_check(self) -> None:
        """Test creating a custom command health check."""
        check = create_command_health_check(
            command=["pg_isready", "-h", "localhost"],
            timeout=5,
            interval=15,
            retries=2,
            start_period=10,
        )
        assert check.command == ["pg_isready", "-h", "localhost"]
        assert check.timeout_seconds == 5
        assert check.interval_seconds == 15
        assert check.retries == 2
        assert check.start_period_seconds == 10


class TestHealthCheckModel:
    """Tests for HealthCheck model in monitoring context."""

    def test_health_check_default_values(self) -> None:
        """Test default health check values."""
        check = HealthCheck(command=["echo", "ok"])
        assert check.interval_seconds == 30
        assert check.timeout_seconds == 10
        assert check.retries == 3
        assert check.start_period_seconds == 0

    def test_health_status_enum(self) -> None:
        """Test health status enum."""
        assert HealthStatus.HEALTHY.value == "healthy"
        assert HealthStatus.UNHEALTHY.value == "unhealthy"
        assert HealthStatus.STARTING.value == "starting"
        assert HealthStatus.UNKNOWN.value == "unknown"
