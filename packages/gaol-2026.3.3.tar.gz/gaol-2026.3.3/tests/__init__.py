"""Tests for gaol."""
