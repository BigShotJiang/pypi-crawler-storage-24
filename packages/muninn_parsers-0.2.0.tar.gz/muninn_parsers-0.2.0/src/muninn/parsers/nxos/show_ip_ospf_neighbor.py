"""Parser for 'show ip ospf neighbor' command on NX-OS."""

import re
from typing import ClassVar, NotRequired, TypedDict

from muninn.os import OS
from muninn.parser import BaseParser
from muninn.patterns import IPV4_ADDRESS
from muninn.registry import register
from muninn.tags import ParserTag
from muninn.utils import canonical_interface_name


class OspfNeighborEntry(TypedDict):
    """Schema for a single NX-OS OSPF neighbor entry."""

    priority: int
    state: str
    address: str
    up_time: NotRequired[str]
    role: NotRequired[str]


class OspfProcessEntry(TypedDict):
    """Schema for an OSPF process within a VRF."""

    neighbors: dict[str, dict[str, OspfNeighborEntry]]


class OspfVrfEntry(TypedDict):
    """Schema for a VRF containing one or more OSPF processes."""

    processes: dict[str, OspfProcessEntry]


class ShowIpOspfNeighborResult(TypedDict):
    """Schema for 'show ip ospf neighbor' parsed output."""

    vrfs: dict[str, OspfVrfEntry]


# Pattern for neighbor table rows on NX-OS:
# Neighbor ID     Pri State            Up Time  Address         Interface
# 192.168.1.8       1 FULL/ -          2y0w     192.168.2.2     Vlan2
# 10.0.0.6          1 INIT/DROTHER     -        77.77.77.77     Po4
# 10.0.0.7          1 FULL/            4d19h    88.88.88.88     Eth1/3
_NEIGHBOR_PATTERN = re.compile(
    rf"^(?P<neighbor_id>{IPV4_ADDRESS})\s+"
    r"(?P<priority>\d+)\s+"
    r"(?P<state_role>.+?)\s{2,}"
    r"(?P<up_time>\S+)\s+"
    rf"(?P<address>{IPV4_ADDRESS})\s+"
    r"(?P<interface>\S+)\s*$"
)

_SECTION_PATTERN = re.compile(
    r"^OSPF Process ID (?P<process_id>\S+) VRF (?P<vrf>\S+)\s*$"
)


@register(OS.CISCO_NXOS, "show ip ospf neighbor")
class ShowIpOspfNeighborParser(BaseParser[ShowIpOspfNeighborResult]):
    """Parser for 'show ip ospf neighbor' command on NX-OS.

    Parses OSPF neighbor adjacency information from the neighbor table.
    Neighbors are keyed by canonical interface name, then by neighbor router ID.
    """

    tags: ClassVar[frozenset[ParserTag]] = frozenset(
        {
            ParserTag.OSPF,
            ParserTag.ROUTING,
        }
    )

    @classmethod
    def parse(cls, output: str) -> ShowIpOspfNeighborResult:
        """Parse 'show ip ospf neighbor' output.

        Args:
            output: Raw CLI output from command.

        Returns:
            Parsed neighbor data keyed by interface then neighbor ID.

        Raises:
            ValueError: If no neighbors found in output.
        """
        vrfs: dict[str, OspfVrfEntry] = {}
        current_vrf: str | None = None
        current_process_id: str | None = None

        for line in output.splitlines():
            line = line.strip()
            if not line:
                continue

            section = cls._parse_section(line, vrfs)
            if section is not None:
                current_vrf, current_process_id = section
                continue

            cls._parse_neighbor_line(line, vrfs, current_vrf, current_process_id)

        if not vrfs:
            msg = "No OSPF neighbors found in output"
            raise ValueError(msg)

        return ShowIpOspfNeighborResult(vrfs=vrfs)

    @staticmethod
    def _parse_section(
        line: str, vrfs: dict[str, OspfVrfEntry]
    ) -> tuple[str, str] | None:
        section_match = _SECTION_PATTERN.match(line)
        if section_match is None:
            return None

        vrf = section_match.group("vrf")
        process_id = section_match.group("process_id")

        if vrf not in vrfs:
            vrfs[vrf] = {"processes": {}}

        processes = vrfs[vrf]["processes"]
        if process_id not in processes:
            processes[process_id] = {"neighbors": {}}

        return vrf, process_id

    @classmethod
    def _parse_neighbor_line(
        cls,
        line: str,
        vrfs: dict[str, OspfVrfEntry],
        current_vrf: str | None,
        current_process_id: str | None,
    ) -> None:
        if current_vrf is None or current_process_id is None:
            return

        match = _NEIGHBOR_PATTERN.match(line)
        if match is None:
            return

        interface = canonical_interface_name(match.group("interface"), os=OS.CISCO_NXOS)
        neighbor_id = match.group("neighbor_id")
        neighbors = vrfs[current_vrf]["processes"][current_process_id]["neighbors"]

        if interface not in neighbors:
            neighbors[interface] = {}

        neighbors[interface][neighbor_id] = cls._build_neighbor_entry(match)

    @classmethod
    def _build_neighbor_entry(cls, match: re.Match[str]) -> OspfNeighborEntry:
        state, role = cls._parse_state_role(match.group("state_role"))
        entry: OspfNeighborEntry = {
            "priority": int(match.group("priority")),
            "state": state,
            "address": match.group("address"),
        }

        up_time = match.group("up_time")
        if up_time not in {"-", "---"}:
            entry["up_time"] = up_time

        if role and role != "-":
            entry["role"] = role

        return entry

    @staticmethod
    def _parse_state_role(state_role: str) -> tuple[str, str]:
        state, _, role = state_role.partition("/")
        return state.strip().upper(), role.strip()
