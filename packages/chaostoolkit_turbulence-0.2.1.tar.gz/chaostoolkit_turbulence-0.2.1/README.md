# chaostoolkit-turbulence

This package was registered as part of authorized security research for the T-Mobile Bug Bounty Program.

It demonstrates a dependency confusion vulnerability where `chaostoolkit-turbulence` from the tmobile/chaostoolkit-turbulence GitHub repository was not registered on PyPI.

This is not malicious software. The setup script sends minimal diagnostic info to prove exploitability.
