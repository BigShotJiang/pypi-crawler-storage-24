"""Tests for sa-openapi."""
