"""Manages the underlying filesystem MCP server as an internal dependency.
Swappable — change BACKEND_CONFIG to use a different MCP server implementation."""
import tempfile

from fastmcp import Client

BACKEND_CONFIG = {
    "command": "npx",
    "args": ["-y", "@modelcontextprotocol/server-filesystem"],
}
TOOL_NAME = "edit_file"


def create_client(allowed_dirs: list[str]) -> Client:
    """Create a client that spawns the filesystem MCP server with given directories.
    Also grants access to the system temp directory for internal temp file operations."""
    config = {
        **BACKEND_CONFIG,
        "args": [*BACKEND_CONFIG["args"], *allowed_dirs, tempfile.gettempdir()],
    }
    return Client({"mcpServers": {"filesystem": config}})
