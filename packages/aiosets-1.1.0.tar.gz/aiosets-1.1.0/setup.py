"""
Setup script for the python-utils package.

This script uses setuptools to package the python-utils library. It reads
metadata from the `aiosets/__about__.py` file and the `README.rst` file to
populate the package information. The script also defines the package
requirements and optional dependencies for different use cases such as logging,
documentation, and testing.
"""

import pathlib

import setuptools

about: dict[str, str] = {}
with open('aiosets/__about__.py') as fp:
    exec(fp.read(), about)

if __name__ == '__main__':
    setuptools.setup(
        python_requires='>=3.9.0',
        name='aiosets',
        version=about['__version__'],
        author=about['__author__'],
        author_email=about['__author_email__'],
        description=about['__description__'],
        url=about['__url__'],
        license='BSD',
        packages=setuptools.find_packages(
            exclude=['_aiosets_tests', '*.__pycache__'],
        ),
        package_data={'aiosets': ['py.typed']},
        long_description='Python Asyncio Set Up',
        install_requires=['aiohttp', 'typing_extensions>3.10.0.2', 'pydantic', 'pydantic_core'],
        extras_require={
            'loguru': [
                'loguru'
            ],
            'docs': [
                'mock',
                'sphinx',
                'python-utils',
            ],
            'tests': [
                'ruff',
                'pyright',
                'pytest',
                'pytest-cov',
                'pytest-mypy',
                'pytest-asyncio',
                'sphinx',
                'types-setuptools',
                'loguru',
                'loguru-mypy',
                'mypy-ipython',
                'blessings',
            ],
        },
        classifiers=['License :: OSI Approved :: BSD License'],
    )
