"""
This module contains metadata about the `python-utils` package.

Attributes:
    __package_name__ (str): The name of the package.
    __author__ (str): The author of the package.
    __author_email__ (str): The email of the author.
    __description__ (str): A brief description of the package.
    __url__ (str): The URL of the package's repository.
    __version__ (str): The current version of the package.
"""

__package_name__: str = 'aiosets'
__author__: str = 'Muhammad Alphauddie'
__author_email__: str = 'muhammad.alphauddie@proton.me'
__description__: str = 'Python Asyncio Set Up'

__url__: str = 'https://aiosets.tech/api/info/faq/'
# Omit type info due to automatic versioning script
__version__ = '1.1.0'
