#Part A
documents = {
    1: "apple banana orange",
    2: "apple banana",
    3: "banana orange",
    4: "apple"
}

def build_index(docs):
    index = {}
    for doc_id, text in docs.items():
        terms = set(text.split())
        for term in terms:
            if term not in index:
                index[term] = {doc_id}
            else:
                index[term].add(doc_id)
    return index

inverted_index = build_index(documents)

def boolean_and(operands, index):
    if not operands:
        return list(range(1, len(documents) + 1))
    
    result = index.get(operands[0], set())
    for term in operands[1:]:
        result = result.intersection(index.get(term, set()))
    
    return list(result)

def boolean_or(operands, index):
    result = set()
    for term in operands:
        result = result.union(index.get(term, set()))
    
    return list(result)

def boolean_not(operand, index, total_docs):
    operand_set = set(index.get(operand, set()))
    all_docs_set = set(range(1, total_docs + 1))
    return list(all_docs_set.difference(operand_set))

query1 = ["apple", "banana"]
query2 = ["apple", "orange"]

result1 = boolean_and(query1, inverted_index)
result2 = boolean_or(query2, inverted_index)
result3 = boolean_not("orange", inverted_index, len(documents))

print("Documents containing 'apple' and 'banana':", result1)
print("Documents containing 'apple' and 'orange':", result2)
print("Documents not containing 'orange':", result3)








# Part B:
from sklearn.feature_extraction.text import CountVectorizer, TfidfTransformer
import nltk
from nltk.corpus import stopwords
import numpy as np
from numpy.linalg import norm

# Training and testing datasets
train_set = ["The sky is blue.", "The sun is bright."]
test_set = ["The sun in the sky is bright."]

# Download stopwords and set them
nltk.download('stopwords')
stopWords = stopwords.words('english')

# Create CountVectorizer and TfidfTransformer
vectorizer = CountVectorizer(stop_words=stopWords)
transformer = TfidfTransformer()

# Fit and transform the training set
trainVectorizerArray = vectorizer.fit_transform(train_set).toarray()
testVectorizerArray = vectorizer.transform(test_set).toarray()

# Print vectorized results
print("Fit Vectorizer to train set:", trainVectorizerArray)
print("Transformer Vectorizer to test set:", testVectorizerArray)

# Cosine similarity function
cx = lambda a, b: round(np.inner(a, b) / (norm(a) * norm(b)), 3)

# Compute cosine similarity
for vector in trainVectorizerArray:
    print(vector)

    for testV in testVectorizerArray:
        print(testV)
        cosine = cx(vector, testV)
        print(cosine)

# Fit the TF-IDF transformer
transformer.fit(testVectorizerArray)
print()
print(transformer.transform(trainVectorizerArray).toarray())

transformer.fit(testVectorizerArray)
print()

# Transform test set using TF-IDF
tfidf = transformer.transform(testVectorizerArray)
print(tfidf.todense())