__version__ = "0.0.6"

from . import Globals
from ._CheckFirstImport import _CheckFirstImport
_CheckFirstImport()

from . import LombScargle
from . import Fourier
from . import Test
from . import Spectrogram
from . import CrossSpec
from . import Filter
from . import PCA
from . import DetectWaves
from . import Tools
