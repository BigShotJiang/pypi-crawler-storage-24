# K9log - Engineering-grade Causal Audit for AI Agent Ecosystems
# Copyright (C) 2026 Haotian Liu
# AGPL-3.0 - see LICENSE for details
"""
k9log.decision - Unified Decision Engine for alert and fuse subsystems.

Input-agnostic: depends only on CIEU record fields.
Anti-statistical-trap: violation_types (irreversible-loss classes) take
priority over severity; severity is a scaffold, not the sole trigger.
"""
from __future__ import annotations
import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from k9log.policy_pack import PolicyPack, DEFAULT_ALERT_RULES, DEFAULT_FUSE_RULES


# ---------------------------------------------------------------------------
# Decision dataclass
# ---------------------------------------------------------------------------

@dataclass
class Decision:
    alert: bool = False
    fuse: bool = False
    reason: str = ""
    severity: float = 0.0
    tags: List[str] = field(default_factory=list)
    profile: Dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _get_severity(record: Dict[str, Any]) -> float:
    return float((record.get("R_t+1") or {}).get("overall_severity", 0.0))


def _get_violation_types(record: Dict[str, Any]) -> Tuple[str, ...]:
    violations = (record.get("R_t+1") or {}).get("violations") or []
    return tuple(sorted({v.get("type", "") for v in violations if isinstance(v, dict)}))


def _get_skill(record: Dict[str, Any]) -> str:
    return (record.get("U_t") or {}).get("skill", "")


def _is_fuse_record(record: Dict[str, Any]) -> bool:
    return (
        record.get("event_type") == "FUSE"
        or _get_skill(record) == "k9log.fuse"
    )


def _cooldown_ok(fuse_cfg: Dict[str, Any]) -> bool:
    """Check fuse cooldown against persisted state."""
    cooldown = int(fuse_cfg.get("cooldown_seconds", 600))
    if cooldown <= 0:
        return True
    try:
        from k9log.fuse import load_state
        state = load_state()
        last = float(state.get("last_fuse_unix", 0) or 0)
        armed = state.get("armed")
        if armed is False:
            return False
        return (time.time() - last) >= cooldown
    except Exception:
        return True


# ---------------------------------------------------------------------------
# Decision Engine
# ---------------------------------------------------------------------------

class DecisionEngine:
    """Evaluates a single CIEU record and returns a unified Decision.

    Rules (anti-statistical-trap):
    - Alert fires when severity >= alert.min_severity AND optional type/skill filters pass.
    - Fuse fires ONLY when:
        1. fuse.enabled is True
        2. NOT in cooldown
        3. violation_types filter matches (if configured) -- type check FIRST
        4. severity >= fuse.min_severity (scaffold, not sole trigger)
    """

    def __init__(self, policy: Optional[PolicyPack] = None):
        if policy is not None:
            self._alert_cfg = policy.alerts
            self._fuse_cfg  = policy.fuse
        else:
            self._alert_cfg = dict(DEFAULT_ALERT_RULES)
            self._fuse_cfg  = dict(DEFAULT_FUSE_RULES)

    # ------------------------------------------------------------------
    def evaluate(self, record: Dict[str, Any]) -> Decision:
        """Return a Decision for the given CIEU record."""
        if _is_fuse_record(record):
            return Decision(reason="fuse_record_skipped")

        severity  = _get_severity(record)
        vtypes    = _get_violation_types(record)
        skill     = _get_skill(record)
        is_passed = (record.get("R_t+1") or {}).get("passed", True)

        alert = self._eval_alert(is_passed, severity, vtypes, skill)
        fuse, fuse_reason = self._eval_fuse(is_passed, severity, vtypes)

        tags = list(vtypes)
        profile: Dict[str, Any] = {}
        if fuse:
            profile["fuse"] = {
                "scope":    self._fuse_cfg.get("scope", "agent"),
                "mode":     self._fuse_cfg.get("mode",  "TOKEN_BUDGET_FREEZE"),
                "budget":   self._fuse_cfg.get("budget", {}),
                "reason":   fuse_reason,
            }

        reason_parts = []
        if alert:
            reason_parts.append("alert")
        reason_parts.append(f"fuse({fuse_reason})")
        reason = "+".join(reason_parts) if reason_parts else "no_action"

        return Decision(
            alert=alert, fuse=fuse,
            reason=reason, severity=severity,
            tags=tags, profile=profile,
        )

    # ------------------------------------------------------------------
    def _eval_alert(self, is_passed, severity, vtypes, skill) -> bool:
        if is_passed:
            return False
        cfg = self._alert_cfg
        if severity < float(cfg.get("min_severity", 0.0)):
            return False
        skill_filter = cfg.get("skills") or []
        if skill_filter and skill not in skill_filter:
            return False
        type_filter = cfg.get("violation_types") or []
        if type_filter and not any(t in type_filter for t in vtypes):
            return False
        return True

    def _eval_fuse(self, is_passed, severity, vtypes) -> Tuple[bool, str]:
        if is_passed:
            return False, "passed"
        cfg = self._fuse_cfg
        if not cfg.get("enabled", False):
            return False, "disabled"
        if not _cooldown_ok(cfg):
            return False, "cooldown"
        # TYPE CHECK FIRST (anti-statistical-trap)
        type_filter = cfg.get("violation_types") or []
        if type_filter and not any(t in type_filter for t in vtypes):
            return False, "type_not_matched"
        # Severity is scaffold only
        min_sev = float(cfg.get("min_severity", 0.85))
        if severity < min_sev:
            return False, "below_min_severity"
        return True, cfg.get("reason", "risk threshold exceeded")


# ---------------------------------------------------------------------------
# Module-level singleton (loaded from active policy if available)
# ---------------------------------------------------------------------------

_engine: Optional[DecisionEngine] = None


def get_decision_engine() -> DecisionEngine:
    """Return the global DecisionEngine, loaded from active policy if set.
    Falls back to alerting._load_config fuse section when no policy is active.
    """
    global _engine
    if _engine is None:
        try:
            from k9log.policy_pack import get_active_policy, PolicyPack, DEFAULT_ALERT_RULES, DEFAULT_FUSE_RULES
            policy = get_active_policy()
            if policy is None:
                # No policy file: build a transient PolicyPack from alerting config
                try:
                    from k9log.alerting import _load_config
                    cfg = _load_config()
                    policy = PolicyPack(
                        policy_id="__alerting_defaults__",
                        version="0",
                        created_at="",
                        alerts={**DEFAULT_ALERT_RULES, **cfg.get("rules", {})},
                        fuse={**DEFAULT_FUSE_RULES, **cfg.get("fuse", {})},
                    )
                except Exception:
                    policy = None
            _engine = DecisionEngine(policy)
        except Exception:
            _engine = DecisionEngine()
    return _engine


def reset_decision_engine() -> None:
    """Force reload on next get_decision_engine() call (used after policy load)."""
    global _engine
    _engine = None

