# K9log - Engineering-grade Causal Audit for AI Agent Ecosystems
# Copyright (C) 2026 Haotian Liu
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published
# by the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.
"""
K9log Taint Tracking - Data provenance and taint analysis
"""
import json
from pathlib import Path
from rich.console import Console

console = Console()

class TaintTracker:
    """
    Taint Tracking System
    
    Tracks data provenance and identifies when tainted (untrusted) data
    enters high-privilege zones.
    """
    
    def __init__(self, log_file=None):
        if log_file is None:
            log_file = Path.home() / '.k9log' / 'logs' / 'k9log.cieu.jsonl'
        
        self.log_file = Path(log_file)
        self.records = []
        self._load_records()
        
        # ── Taint classification: action_class-driven + configurable registry ─
        # Primary key: action_class field in CIEU X_t / U_t (set by connector or adapter).
        # Secondary:   explicit name lists in ~/.k9log/config/taint.json
        # This makes taint analysis input-agnostic: any agent whose skills declare
        # action_class works automatically with zero configuration.
        #
        # taint.json schema (all fields optional):
        #   { "taint_sources":         ["skill_a", ...],
        #     "high_privilege_skills":  ["skill_b", ...],
        #     "structural_params":      ["param_name", ...] }

        # action_class values treated as taint sources (read external data)
        self.source_action_classes = {'READ', 'NETWORK', 'FETCH'}
        # action_class values treated as high-privilege sinks
        self.sink_action_classes = {'WRITE', 'EXECUTE', 'TRANSFER', 'DELETE'}

        # Explicit name registries — loaded from config, empty by default.
        # Connectors/adapters populate taint.json for their own skill vocabulary.
        cfg = self._load_taint_config()
        self.taint_sources         = set(cfg.get('taint_sources', []))
        self.high_privilege_skills = set(cfg.get('high_privilege_skills', []))

        # Structural/metadata params that never carry taint (connector-declared).
        # Default: empty — the core engine does not know any connector's param names.
        self.structural_params: set = set(cfg.get('structural_params', []))
    
    def _load_taint_config(self) -> dict:
        """Load taint classification config from ~/.k9log/config/taint.json.
        Returns empty dict if not present — all lists default to empty.
        """
        import json
        cfg_path = Path.home() / '.k9log' / 'config' / 'taint.json'
        if cfg_path.exists():
            try:
                return json.loads(cfg_path.read_text(encoding='utf-8'))
            except Exception:
                pass
        return {}

    def _load_records(self):
        """Load all records from log file"""
        if not self.log_file.exists():
            return
        
        with open(self.log_file, 'r', encoding='utf-8') as f:
            for line in f:
                if line.strip():
                    record = json.loads(line)
                    if record.get('event_type') != 'SESSION_END':
                        self.records.append(record)
    
    def analyze_taint_propagation(self):
        """
        Analyze taint propagation through the execution trace
        
        Returns:
            Dict with taint analysis results
        """
        taint_map = {}  # {step_id: {param: is_tainted}}
        violations = []
        
        for idx, record in enumerate(self.records):
            skill = record.get('U_t', {}).get('skill', 'unknown')
            params = record.get('U_t', {}).get('params', {})
            x_t = record.get('X_t', {})
            
            # Check if input is from taint source
            input_tainted = self._is_tainted_source(skill, x_t)
            
            # Propagate taint
            param_taint = {}
            # Structural/constant params — never inherit taint
            for key, value in params.items():
                if key in self.structural_params:
                    param_taint[key] = False
                    continue
                # Check if derived from previous tainted output
                param_taint[key] = input_tainted or self._is_derived_from_tainted(value, idx, taint_map)
            
            # Output is tainted if any input is tainted
            output_tainted = any(param_taint.values())
            
            taint_map[idx] = {
                'input_tainted': input_tainted,
                'params': param_taint,
                'output_tainted': output_tainted,
                'skill': skill
            }
            
            # Check if tainted data entered high-privilege zone.
            # Use action_class first (set by connector); fall back to name registry.
            record_action_class = (
                record.get('action_class', '') or
                x_t.get('action_class', '')
            ).upper()
            is_high_privilege = (
                (record_action_class and record_action_class in self.sink_action_classes)
                or skill in self.high_privilege_skills
            )
            if output_tainted and is_high_privilege:
                violations.append({
                    'step': idx,
                    'skill': skill,
                    'tainted_params': [k for k, v in param_taint.items() if v],
                    'taint_origin': self._trace_taint_origin(idx, taint_map)
                })
        
        return {
            'taint_map': taint_map,
            'violations': violations,
            'total_tainted_steps': sum(1 for t in taint_map.values() if t['output_tainted']),
            'taint_rate': sum(1 for t in taint_map.values() if t['output_tainted']) / len(taint_map) if taint_map else 0
        }
    
    def _is_tainted_source(self, skill, x_t):
        """Determine if a skill is a taint source.

        Priority order (most reliable first):
        1. action_class in CIEU record → checked against source_action_classes
        2. Explicit name registry (taint_sources from taint.json)
        3. CIEU X_t.source field
        (Keyword heuristics removed — they were fragile and connector-specific.)
        """
        # 1. action_class field (set by connector/adapter — most reliable)
        action_class = x_t.get('action_class', '').upper()
        if action_class and action_class in self.source_action_classes:
            return True

        # 2. Explicit registry (connector populated taint.json)
        if skill in self.taint_sources:
            return True

        # 3. X_t.source tag
        if x_t.get('source') in self.taint_sources:
            return True

        return False
    
    def _is_derived_from_tainted(self, value, current_idx, taint_map):
        """Check if value is derived from previously tainted data.
        
        Uses value fingerprinting instead of temporal proximity:
        only marks as tainted if str(value) actually overlaps with
        a previous tainted step's output or parameter values.
        
        This replaces the old heuristic ('any tainted in last 5 steps → tainted')
        which caused rapid taint spread and low signal-to-noise ratio.
        """
        if value is None:
            return False
        
        str_value = str(value)
        if not str_value or len(str_value) < 3:
            return False
        
        # Look back at previous steps (wider window, but stricter matching)
        for prev_idx in range(max(0, current_idx - 10), current_idx):
            if prev_idx not in taint_map:
                continue
            if not taint_map[prev_idx]['output_tainted']:
                continue
            
            # Check actual output value overlap
            if prev_idx < len(self.records):
                prev_result = self.records[prev_idx].get('Y_t+1', {})
                prev_result_str = str(prev_result.get('result', ''))
                
                if prev_result_str and len(prev_result_str) >= 3:
                    if str_value in prev_result_str or prev_result_str in str_value:
                        return True
                
                # Check overlap with tainted parameter values
                prev_params = self.records[prev_idx].get('U_t', {}).get('params', {})
                for pname, is_tainted in taint_map[prev_idx].get('params', {}).items():
                    if is_tainted:
                        prev_pval = str(prev_params.get(pname, ''))
                        if prev_pval and len(prev_pval) >= 3:
                            if str_value in prev_pval or prev_pval in str_value:
                                return True
        
        return False
    
    def _trace_taint_origin(self, step_id, taint_map):
        """Trace back to find taint origin"""
        origins = []
        
        for prev_idx in range(step_id):
            if prev_idx in taint_map and taint_map[prev_idx]['input_tainted']:
                origins.append({
                    'step': prev_idx,
                    'skill': taint_map[prev_idx]['skill']
                })
        
        return origins[:3]  # Return first 3 origins
    
    def visualize_taint_analysis(self, analysis):
        """Visualize taint analysis results"""
        from rich.panel import Panel
        
        console.print('\n')
        console.print(Panel.fit(
            "[bold cyan]🔍 Taint Analysis Report[/bold cyan]",
            border_style="cyan"
        ))
        
        console.print(f"\n[bold]📊 Overview[/bold]")
        console.print(f"   Total steps analyzed: {len(analysis['taint_map'])}")
        console.print(f"   Tainted steps: {analysis['total_tainted_steps']}")
        console.print(f"   Taint rate: {analysis['taint_rate']*100:.1f}%\n")
        
        if analysis['violations']:
            console.print(f"[bold red]⚠️  Taint Violations Found: {len(analysis['violations'])}[/bold red]\n")
            
            for v in analysis['violations'][:5]:
                console.print(f"   [red]Step #{v['step']} - {v['skill']}[/red]")
                console.print(f"   Tainted parameters: {', '.join(v['tainted_params'])}")
                
                if v['taint_origin']:
                    origins_str = ', '.join([f"Step #{o['step']}" for o in v['taint_origin']])
                    console.print(f"   Origin: {origins_str}")
                
                console.print()
        else:
            console.print("[green]✅ No taint violations found[/green]\n")

def analyze_taint(log_file=None):
    """Convenience function for taint analysis"""
    tracker = TaintTracker(log_file)
    analysis = tracker.analyze_taint_propagation()
    tracker.visualize_taint_analysis(analysis)
    return analysis

