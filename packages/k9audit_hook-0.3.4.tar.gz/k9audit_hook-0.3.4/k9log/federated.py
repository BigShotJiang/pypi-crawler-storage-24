# K9log - Engineering-grade Causal Audit for AI Agent Ecosystems
# Copyright (C) 2026 Haotian Liu
# AGPL-3.0 License
"""
K9log Federated Grant Library

Enables sharing of causally-verified governance rules across projects and teams.
Not a public registry — designed for trusted collaborators: same team, partner
companies, or multi-project organizations.

Trust model:
  VERIFIED   — grant has causal proof + local CIEU validation passes → activate
  SUGGESTED  — grant has causal proof but no local data to validate → suggested/
  UNVERIFIED — grant has no causal proof → suggested/ + warning

CLI:
  k9log grants import <url-or-path>   # import from URL or local path
  k9log grants export --id <id>       # export a suggested grant for sharing
  k9log grants list                   # list all grants (active + suggested)
  k9log grants verify <path>          # verify a grant file against local CIEU
"""
import json
import shutil
from pathlib import Path
from datetime import datetime, timezone
from urllib.request import urlopen
from urllib.error import URLError
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

console = Console()

GRANTS_DIR = Path.home() / ".k9log" / "grants"
SUGGESTED_DIR = GRANTS_DIR / "suggested"
ACTIVE_DIR = GRANTS_DIR


class FederatedGrantManager:
    """
    Import, export, and verify governance grants across projects and teams.
    """

    def __init__(self, log_file=None):
        if log_file is None:
            log_file = Path.home() / ".k9log" / "logs" / "k9log.cieu.jsonl"
        self.log_file = Path(log_file)
        GRANTS_DIR.mkdir(parents=True, exist_ok=True)
        SUGGESTED_DIR.mkdir(parents=True, exist_ok=True)

    # ── Import ────────────────────────────────────────────────────
    def import_grant(self, source: str) -> dict:
        """
        Import a grant from a URL or local file path.

        Args:
            source: URL (https://...) or local file path

        Returns:
            Dict with import result: trust_level, destination, grant_id
        """
        console.print(f"\n[bold]Importing grant from:[/bold] {source}")

        # Load grant data
        grant_data = self._load_source(source)
        if grant_data is None:
            return {"success": False, "error": "Failed to load source"}

        grant_id = grant_data.get("grant_id", "unknown")
        console.print(f"   Grant ID: {grant_id}")

        # Determine trust level
        trust_level = self._assess_trust(grant_data)
        console.print(f"   Trust level: {self._trust_badge(trust_level)}")

        # Place grant based on trust level
        if trust_level == "VERIFIED":
            dest = ACTIVE_DIR / f"{grant_id}.json"
            console.print(f"   [green]✅ Causal proof verified — activating grant[/green]")
        else:
            dest = SUGGESTED_DIR / f"{grant_id}.json"
            if trust_level == "SUGGESTED":
                console.print(f"   [yellow]⚠️  Causal proof present but unverifiable locally[/yellow]")
                console.print(f"   [yellow]   → placed in suggested/ for review[/yellow]")
            else:
                console.print(f"   [red]⚠️  No causal proof — treat with caution[/red]")
                console.print(f"   [red]   → placed in suggested/ for review[/red]")

        # Add import metadata
        grant_data["_import_metadata"] = {
            "source": source,
            "imported_at": datetime.now(timezone.utc).isoformat(),
            "trust_level": trust_level,
        }

        dest.write_text(json.dumps(grant_data, indent=2, ensure_ascii=False), encoding="utf-8")
        console.print(f"   Written to: {dest}\n")

        return {
            "success": True,
            "grant_id": grant_id,
            "trust_level": trust_level,
            "destination": str(dest),
            "active": trust_level == "VERIFIED",
        }

    # ── Export ────────────────────────────────────────────────────
    def export_grant(self, grant_id: str, output_dir: str = ".") -> dict:
        """
        Export a grant file (from suggested/ or active) for sharing.
        Strips sensitive local paths, keeps causal proof intact.
        """
        # Find the grant file
        grant_file = self._find_grant(grant_id)
        if grant_file is None:
            console.print(f"[red]Grant '{grant_id}' not found[/red]")
            return {"success": False, "error": f"Grant {grant_id} not found"}

        grant_data = json.loads(grant_file.read_text(encoding="utf-8"))

        # Strip local-specific metadata
        grant_data.pop("_import_metadata", None)
        if "metalearning_metadata" in grant_data:
            # Keep causal proof, strip absolute paths
            meta = grant_data["metalearning_metadata"]
            meta.pop("local_log_path", None)

        # Add export metadata
        grant_data["_export_metadata"] = {
            "exported_at": datetime.now(timezone.utc).isoformat(),
            "k9log_version": "0.6",
        }

        output_path = Path(output_dir) / f"{grant_id}.json"
        output_path.write_text(json.dumps(grant_data, indent=2, ensure_ascii=False), encoding="utf-8")

        console.print(f"[green]✅ Exported:[/green] {output_path}")
        if "metalearning_metadata" in grant_data:
            console.print(f"   Causal proof included — recipients can verify locally")
        else:
            console.print(f"   [yellow]No causal proof — recipients will need manual review[/yellow]")

        return {"success": True, "path": str(output_path)}

    # ── List ──────────────────────────────────────────────────────
    def list_grants(self) -> dict:
        """List all grants: active and suggested."""
        active = list(ACTIVE_DIR.glob("*.json"))
        suggested = list(SUGGESTED_DIR.glob("*.json"))

        console.print("\n")
        console.print(Panel.fit("[bold cyan]📋 Grant Library[/bold cyan]", border_style="cyan"))

        # Active grants
        console.print(f"\n[bold green]Active Grants ({len(active)})[/bold green]")
        if active:
            table = Table(show_header=True, header_style="bold")
            table.add_column("Grant ID", style="cyan")
            table.add_column("Source", style="dim")
            table.add_column("Causal Proof")
            for f in active:
                try:
                    data = json.loads(f.read_text(encoding="utf-8"))
                    gid = data.get("grant_id", f.stem)
                    source = data.get("_import_metadata", {}).get("source", "local")
                    has_proof = "✅" if "metalearning_metadata" in data else "—"
                    table.add_row(gid, source[:50], has_proof)
                except Exception:
                    table.add_row(f.stem, "—", "—")
            console.print(table)
        else:
            console.print("   [dim]No active grants[/dim]")

        # Suggested grants
        console.print(f"\n[bold yellow]Suggested Grants ({len(suggested)}) — pending review[/bold yellow]")
        if suggested:
            table2 = Table(show_header=True, header_style="bold")
            table2.add_column("Grant ID", style="yellow")
            table2.add_column("Trust Level")
            table2.add_column("Source", style="dim")
            for f in suggested:
                try:
                    data = json.loads(f.read_text(encoding="utf-8"))
                    gid = data.get("grant_id", f.stem)
                    trust = data.get("_import_metadata", {}).get("trust_level", "UNVERIFIED")
                    source = data.get("_import_metadata", {}).get("source", "local")
                    table2.add_row(gid, self._trust_badge(trust), source[:50])
                except Exception:
                    table2.add_row(f.stem, "UNVERIFIED", "—")
            console.print(table2)
            console.print(f"\n   [dim]To activate: move file from suggested/ to grants/[/dim]")
        else:
            console.print("   [dim]No suggested grants[/dim]")

        return {"active": len(active), "suggested": len(suggested)}

    # ── Verify ────────────────────────────────────────────────────
    def verify_grant(self, grant_path: str) -> dict:
        """
        Verify a grant file against local CIEU log.
        Runs counterfactual replay to check if the causal proof holds locally.
        """
        path = Path(grant_path)
        if not path.exists():
            console.print(f"[red]File not found: {grant_path}[/red]")
            return {"verified": False, "error": "File not found"}

        grant_data = json.loads(path.read_text(encoding="utf-8"))
        grant_id = grant_data.get("grant_id", "unknown")
        meta = grant_data.get("metalearning_metadata", {})

        console.print(f"\n[bold]Verifying grant:[/bold] {grant_id}")

        if not meta:
            console.print("[red]❌ No causal proof in grant file — cannot verify[/red]")
            return {"verified": False, "reason": "no_causal_proof"}

        if not self.log_file.exists():
            console.print("[yellow]⚠️  No local CIEU log found — cannot verify[/yellow]")
            return {"verified": False, "reason": "no_local_log"}

        # Run counterfactual replay
        output_constraints = grant_data.get("scope", {}).get("output_constraints", {})
        if not output_constraints:
            console.print("[yellow]⚠️  Grant has no output_constraints to verify[/yellow]")
            return {"verified": False, "reason": "no_output_constraints"}

        from k9log.counterfactual import CounterfactualEngine
        engine = CounterfactualEngine(self.log_file)

        if not engine.records:
            console.print("[yellow]⚠️  Local CIEU log is empty — cannot verify[/yellow]")
            return {"verified": False, "reason": "empty_local_log"}

        policy = {
            "id": grant_id,
            "description": grant_data.get("description", ""),
            "modifications": {},
            "output_modifications": output_constraints,
        }
        result = engine.replay_with_policy(policy)
        blocked = result.get("blocked_steps", [])
        cut = result.get("cut_point")

        # Use earliest blocked step as effective cut point
        effective_cut = cut if cut is not None else (min(blocked) if blocked else None)

        if effective_cut is not None:
            console.print(f"[green]✅ Verified — cuts causal chain at Step #{effective_cut} in local log[/green]")
            return {"verified": True, "cut_point": effective_cut, "blocked_steps": blocked}
        else:
            console.print("[yellow]⚠️  Grant rule does not cut any causal chain in local log[/yellow]")
            console.print("   [dim]Local incidents may differ — placing in suggested/[/dim]")
            return {"verified": False, "reason": "no_cut_in_local_log"}

    # ── Internal helpers ──────────────────────────────────────────
    def _load_source(self, source: str):
        """Load grant JSON from URL or local path."""
        try:
            if source.startswith("http://") or source.startswith("https://"):
                # Handle GitHub blob URLs → raw
                if "github.com" in source and "/blob/" in source:
                    source = source.replace("github.com", "raw.githubusercontent.com")
                    source = source.replace("/blob/", "/")
                with urlopen(source, timeout=10) as resp:
                    return json.loads(resp.read().decode("utf-8"))
            else:
                return json.loads(Path(source).read_text(encoding="utf-8"))
        except URLError as e:
            console.print(f"[red]Network error: {e}[/red]")
            return None
        except json.JSONDecodeError as e:
            console.print(f"[red]Invalid JSON: {e}[/red]")
            return None
        except FileNotFoundError:
            console.print(f"[red]File not found: {source}[/red]")
            return None

    def _assess_trust(self, grant_data: dict) -> str:
        """
        Assess trust level of a grant.
        VERIFIED: has causal proof + local verification passes
        SUGGESTED: has causal proof but cannot verify locally
        UNVERIFIED: no causal proof
        """
        meta = grant_data.get("metalearning_metadata", {})
        if not meta or not meta.get("causal_proof"):
            return "UNVERIFIED"

        # Try local verification
        output_constraints = grant_data.get("scope", {}).get("output_constraints", {})
        if not output_constraints or not self.log_file.exists():
            return "SUGGESTED"

        try:
            from k9log.counterfactual import CounterfactualEngine
            engine = CounterfactualEngine(self.log_file)
            if not engine.records:
                return "SUGGESTED"

            policy = {
                "id": grant_data.get("grant_id", "verify"),
                "description": "",
                "modifications": {},
                "output_modifications": output_constraints,
            }
            result = engine.replay_with_policy(policy)
            blocked = result.get("blocked_steps", [])
            cut = result.get("cut_point")
            effective_cut = cut if cut is not None else (min(blocked) if blocked else None)
            return "VERIFIED" if effective_cut is not None else "SUGGESTED"
        except Exception:
            return "SUGGESTED"

    def _find_grant(self, grant_id: str):
        """Find grant file by ID in active or suggested directories."""
        for d in [ACTIVE_DIR, SUGGESTED_DIR]:
            p = d / f"{grant_id}.json"
            if p.exists():
                return p
        return None

    def _trust_badge(self, trust_level: str) -> str:
        return {
            "VERIFIED": "[green]VERIFIED[/green]",
            "SUGGESTED": "[yellow]SUGGESTED[/yellow]",
            "UNVERIFIED": "[red]UNVERIFIED[/red]",
        }.get(trust_level, trust_level)


# ── Convenience functions ─────────────────────────────────────────────────────

def import_grant(source: str, log_file=None) -> dict:
    return FederatedGrantManager(log_file).import_grant(source)

def export_grant(grant_id: str, output_dir: str = ".", log_file=None) -> dict:
    return FederatedGrantManager(log_file).export_grant(grant_id, output_dir)

def list_grants(log_file=None) -> dict:
    return FederatedGrantManager(log_file).list_grants()

def verify_grant(grant_path: str, log_file=None) -> dict:
    return FederatedGrantManager(log_file).verify_grant(grant_path)

