# K9log - Engineering-grade Causal Audit for AI Agent Ecosystems
# Copyright (C) 2026 Haotian Liu
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published
# by the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU Affero General Public License for more details.
#
# You should have received a copy of the GNU Affero General Public License
# along with this program. If not, see <https://www.gnu.org/licenses/>.
"""
K9log Counterfactual Replay - L2 Policy-on-Trace Analysis
"""
import json
from pathlib import Path
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from k9log.constraints import check_compliance

console = Console()

class CounterfactualEngine:
    """
    L2 Counterfactual Replay Engine
    
    This is NOT statistical causal inference - it's deterministic
    policy verification: same trace + different rules = can we prevent incidents?
    """
    
    def __init__(self, log_file=None):
        if log_file is None:
            log_file = Path.home() / '.k9log' / 'logs' / 'k9log.cieu.jsonl'
        
        self.log_file = Path(log_file)
        self.records = []
        self._load_records()
    
    def _load_records(self):
        """Load all records from log file"""
        if not self.log_file.exists():
            return
        
        with open(self.log_file, 'r', encoding='utf-8') as f:
            for line in f:
                if line.strip():
                    record = json.loads(line)
                    if record.get('event_type') != 'SESSION_END':
                        self.records.append(record)
    
    def replay_with_policy(self, policy_config):
        """
        Replay trace with counterfactual policy
        
        Args:
            policy_config: Dict with policy modifications
                {
                    'id': 'strict_amount',
                    'description': 'Lower amount limit',
                    'modifications': {
                        'transfer_money': {
                            'amount': {'max': 500}  # Stricter than original
                        }
                    }
                }
        
        Returns:
            Dict with replay results
        """
        policy_id = policy_config.get('id', 'unnamed')
        modifications = policy_config.get('modifications', {})
        
        results = {
            'policy_id': policy_id,
            'policy_description': policy_config.get('description', ''),
            'total_steps': len(self.records),
            'blocked_steps': [],
            'cut_point': None,
            'violations_prevented': [],
            'false_positives': [],
            'cost_analysis': {}
        }
        
        for idx, record in enumerate(self.records):
            skill = record.get('U_t', {}).get('skill', 'unknown')
            params = record.get('U_t', {}).get('params', {})
            y_t_plus_1 = record.get('Y_t+1', {})
            r_original = record.get('R_t+1', {})
            y_star_original = record.get('Y_star_t', {})
            
            # Apply counterfactual policy
            if skill in modifications:
                y_star_cf = self._merge_constraints(
                    y_star_original.get('constraints', {}),
                    modifications[skill]
                )
            else:
                y_star_cf = y_star_original.get('constraints', {})
            
            # Re-check compliance with counterfactual policy
            r_cf = check_compliance(params, y_t_plus_1, {'constraints': y_star_cf})

            # EXTENSION: check output values (Y_t+1.result) against output_modifications
            # EXTENSION: check output values AND input params against output_modifications
            output_mods = policy_config.get('output_modifications', {})
            if skill in output_mods:
                # Check output result fields
                result_val = y_t_plus_1.get('result', {})
                if isinstance(result_val, dict):
                    r_out = check_compliance(result_val, {}, {'constraints': output_mods[skill]})
                    if not r_out.get('passed', True):
                        r_cf['passed'] = False
                        r_cf['violations'] = r_cf.get('violations', []) + r_out.get('violations', [])
                        r_cf['overall_severity'] = max(r_cf.get('overall_severity', 0.0), r_out.get('overall_severity', 0.0))
                # Also check input params (e.g. _write_file content blocklist)
                r_param = check_compliance(params, {}, {'constraints': output_mods[skill]})
                if not r_param.get('passed', True):
                    r_cf['passed'] = False
                    r_cf['violations'] = r_cf.get('violations', []) + r_param.get('violations', [])
                    r_cf['overall_severity'] = max(r_cf.get('overall_severity', 0.0), r_param.get('overall_severity', 0.0))
            # Analyze difference
            original_passed = r_original.get('passed', True)
            cf_passed = r_cf.get('passed', True)
            
            if not cf_passed and original_passed:
                # False positive: new policy blocks something that was OK
                results['false_positives'].append({
                    'step': idx,
                    'skill': skill,
                    'violations': r_cf['violations']
                })
                results['blocked_steps'].append(idx)
            
            elif not cf_passed and not original_passed:
                # True positive: catches real violation
                if results['cut_point'] is None:
                    results['cut_point'] = idx
                    results['cut_reason'] = r_cf['violations']
                
                results['violations_prevented'].append({
                    'step': idx,
                    'skill': skill,
                    'original_violations': r_original['violations'],
                    'cf_violations': r_cf['violations']
                })
                results['blocked_steps'].append(idx)
        
        # Calculate cost
        results['cost_analysis'] = {
            'total_operations': results['total_steps'],
            'blocked_count': len(results['blocked_steps']),
            'blocked_rate': len(results['blocked_steps']) / results['total_steps'] if results['total_steps'] > 0 else 0,
            'false_positive_count': len(results['false_positives']),
            'false_positive_rate': len(results['false_positives']) / results['total_steps'] if results['total_steps'] > 0 else 0,
            'true_positive_count': len(results['violations_prevented']),
            'effectiveness': len(results['violations_prevented']) / len(results['blocked_steps']) if results['blocked_steps'] else 0
        }
        
        return results
    
    def _merge_constraints(self, original, modifications):
        """
        Merge original constraints with counterfactual modifications
        
        Modifications override original constraints
        """
        merged = original.copy()
        
        for param, rules in modifications.items():
            if param not in merged:
                merged[param] = {}
            merged[param].update(rules)
        
        return merged
    
    def visualize_replay_results(self, results):
        """Visualize counterfactual replay results"""
        console.print('\n')
        console.print(Panel.fit(
            f"[bold cyan]🔄 Counterfactual Replay Report[/bold cyan]\n"
            f"Policy: {results['policy_id']}",
            border_style="cyan"
        ))
        
        # Policy description
        console.print(f"\n[bold]📋 Policy Description[/bold]")
        console.print(f"   {results['policy_description']}\n")
        
        # Cut point analysis
        if results['cut_point'] is not None:
            console.print(f"[bold]✂️  Cut Point Analysis[/bold]")
            console.print(f"   [green]Earliest cut point:[/green] Step #{results['cut_point']}")
            console.print(f"   [yellow]If this policy was active, the incident would be blocked here.[/yellow]\n")
            
            if results['cut_reason']:
                console.print("   [bold]Reason:[/bold]")
                for v in results['cut_reason'][:3]:
                    console.print(f"   • {v.get('message', 'Unknown')}")
                console.print()
        else:
            console.print(f"[bold]✂️  Cut Point Analysis[/bold]")
            console.print(f"   [red]No cut point found - policy would not prevent incidents[/red]\n")
        
        # Cost analysis
        console.print(f"[bold]📊 Cost Analysis[/bold]\n")
        
        cost = results['cost_analysis']
        
        table = Table(show_header=True)
        table.add_column("Metric", style="cyan")
        table.add_column("Value", justify="right")
        table.add_column("Rate", justify="right")
        
        table.add_row(
            "Total Operations",
            str(cost['total_operations']),
            ""
        )
        table.add_row(
            "Blocked by Policy",
            str(cost['blocked_count']),
            f"{cost['blocked_rate']*100:.1f}%"
        )
        table.add_row(
            "False Positives",
            str(cost['false_positive_count']),
            f"{cost['false_positive_rate']*100:.1f}%",
        )
        table.add_row(
            "True Positives",
            str(cost['true_positive_count']),
            f"{cost['effectiveness']*100:.0f}% effective"
        )
        
        console.print(table)
        
        # Recommendations
        console.print(f"\n[bold]💡 Recommendations[/bold]\n")
        
        fp_rate = cost['false_positive_rate']
        tp_count = cost['true_positive_count']
        
        if tp_count > 0 and fp_rate < 0.05:
            console.print("   [green]✅ Excellent policy![/green]")
            console.print("   • Prevents violations")
            console.print("   • Low false positive rate (<5%)")
            console.print("   • [bold]Recommend deploying this policy[/bold]")
        
        elif tp_count > 0 and fp_rate < 0.15:
            console.print("   [yellow]⚠️  Good but with trade-offs[/yellow]")
            console.print("   • Prevents violations")
            console.print(f"   • Moderate false positive rate ({fp_rate*100:.1f}%)")
            console.print("   • Consider refining policy or adding approval workflow")
        
        elif tp_count > 0 and fp_rate >= 0.15:
            console.print("   [red]⚠️  High cost policy[/red]")
            console.print("   • Prevents violations but blocks many valid operations")
            console.print(f"   • High false positive rate ({fp_rate*100:.1f}%)")
            console.print("   • [bold]Policy too strict - needs refinement[/bold]")
        
        else:
            console.print("   [red]❌ Ineffective policy[/red]")
            console.print("   • Does not prevent violations")
            console.print("   • [bold]Do not deploy[/bold]")

def replay_counterfactual(policy_config, log_file=None):
    """Convenience function for counterfactual replay"""
    engine = CounterfactualEngine(log_file)
    results = engine.replay_with_policy(policy_config)
    engine.visualize_replay_results(results)
    return results

