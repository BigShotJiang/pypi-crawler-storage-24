# K9log - Engineering-grade Causal Audit for AI Agent Ecosystems
# Copyright (C) 2026 Haotian Liu
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Affero General Public License as published
# by the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
"""
k9log.fuse - Input-agnostic circuit breaker (FUSE) for agent safety.

Design:
- k9log emits a FUSE decision + writes a stable fuse state file
- host/runner decides how to enforce (stop loop, max_tokens=0, disable tools, etc.)
- fuse events can be written into the CIEU hash chain for auditability
"""
from __future__ import annotations

import json
import time
from dataclasses import dataclass
from pathlib import Path
from datetime import datetime, timezone
from typing import Any, Dict, Optional, Tuple


FUSE_DIR = Path.home() / ".k9log" / "fuse"
STATE_PATH = FUSE_DIR / "state.json"
EVENTS_PATH = FUSE_DIR / "events.jsonl"


@dataclass
class FuseDecision:
    fuse: bool
    reason: str = ""
    severity: float = 0.0
    scope: str = "agent"  # agent|session|global
    agent_id: str = ""
    session_id: str = ""
    trigger_types: Tuple[str, ...] = ()
    mode: str = "TOKEN_BUDGET_FREEZE"
    token_cap: int = 0
    tool_calls: int = 0


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _ensure_dir():
    FUSE_DIR.mkdir(parents=True, exist_ok=True)


def load_state() -> Dict[str, Any]:
    if not STATE_PATH.exists():
        return {"active": False}
    try:
        return json.loads(STATE_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {"active": False, "corrupt": True}


def save_state(state: Dict[str, Any]) -> None:
    _ensure_dir()
    STATE_PATH.write_text(json.dumps(state, indent=2, ensure_ascii=False), encoding="utf-8")


def append_event(evt: Dict[str, Any]) -> None:
    _ensure_dir()
    with open(EVENTS_PATH, "a", encoding="utf-8") as f:
        f.write(json.dumps(evt, ensure_ascii=False) + "\n")


def disarm() -> None:
    save_state({"active": False, "armed": False, "ts": _utc_now()})


def arm() -> None:
    # armed==True simply means "fuse subsystem enabled"; activation happens via maybe_fuse()
    s = load_state()
    s["armed"] = True
    s.setdefault("active", False)
    s["ts"] = _utc_now()
    save_state(s)


def _extract_ids(record: Dict[str, Any]) -> Tuple[str, str]:
    x = record.get("X_t", {}) or {}
    agent_id = x.get("agent_id", "") or ""
    session_id = x.get("session_id", "") or ""
    return agent_id, session_id


def _violation_types(record: Dict[str, Any]) -> Tuple[str, ...]:
    r = record.get("R_t+1", {}) or {}
    v = r.get("violations", []) or []
    types = tuple(sorted(set((i.get("type", "") or "") for i in v if isinstance(i, dict))))
    return types


def _cooldown_ok(state: Dict[str, Any], cooldown_seconds: int) -> bool:
    if cooldown_seconds <= 0:
        return True
    last = state.get("last_fuse_unix", 0)
    try:
        last = float(last)
    except Exception:
        last = 0.0
    return (time.time() - last) >= cooldown_seconds


def decide(record: Dict[str, Any], cfg: Dict[str, Any]) -> FuseDecision:
    """
    Decide whether to trigger fuse based on a single CIEU record.
    Input-agnostic: depends only on CIEU fields.
    """
    enabled = bool(cfg.get("enabled", False))
    if not enabled:
        return FuseDecision(fuse=False)

    # If previously disarmed explicitly, respect that unless re-armed.
    state = load_state()
    if state.get("armed") is False:
        return FuseDecision(fuse=False)

    cooldown = int(cfg.get("cooldown_seconds", 600))
    if not _cooldown_ok(state, cooldown):
        return FuseDecision(fuse=False, reason="cooldown", severity=float(record.get("R_t+1", {}).get("overall_severity", 0.0)))

    min_sev = float(cfg.get("min_severity", 0.95))
    sev = float(record.get("R_t+1", {}).get("overall_severity", 0.0))
    if sev < min_sev:
        return FuseDecision(fuse=False, severity=sev, reason="below_min_severity")

    types_filter = cfg.get("violation_types", []) or []
    vtypes = _violation_types(record)
    if types_filter:
        if not any(t in types_filter for t in vtypes):
            return FuseDecision(fuse=False, severity=sev, reason="type_not_matched")

    agent_id, session_id = _extract_ids(record)
    scope = cfg.get("scope", "agent") or "agent"
    mode = cfg.get("mode", "TOKEN_BUDGET_FREEZE") or "TOKEN_BUDGET_FREEZE"
    budget = cfg.get("budget", {}) or {}
    token_cap = int(budget.get("token_cap", 0))
    tool_calls = int(budget.get("tool_calls", 0))

    return FuseDecision(
        fuse=True,
        reason=cfg.get("reason", "risk threshold exceeded") or "risk threshold exceeded",
        severity=sev,
        scope=scope,
        agent_id=agent_id,
        session_id=session_id,
        trigger_types=vtypes,
        mode=mode,
        token_cap=token_cap,
        tool_calls=tool_calls,
    )


def activate(dec: FuseDecision, record: Dict[str, Any], write_cieu_event: bool = True) -> Dict[str, Any]:
    """
    Persist fuse activation state and optionally write a FUSE event into CIEU log chain.
    """
    state = {
        "active": True,
        "armed": True,
        "ts": _utc_now(),
        "last_fuse_unix": time.time(),
        "scope": dec.scope,
        "agent_id": dec.agent_id,
        "session_id": dec.session_id,
        "severity": dec.severity,
        "trigger_types": list(dec.trigger_types),
        "mode": dec.mode,
        "budget": {"token_cap": dec.token_cap, "tool_calls": dec.tool_calls},
        "reason": dec.reason,
    }
    save_state(state)
    append_event({"event": "FUSE_ON", **state})
    # ── Auto-learn on fuse activation ───────────────────────────────────────
    try:
        from k9log.metalearning import learn
        learn(write_grants=True, silent=True)
    except Exception:
        pass  # Never crash the host on metalearning failure

    if write_cieu_event:
        try:
            from k9log.logger import CIEULogger
            # Compose a minimal CIEU governance-action record
            fuse_record = {
                "event_type": "FUSE",
                "X_t": record.get("X_t", {}),
                "U_t": {
                    "skill": "k9log.fuse",
                    "params": {
                        "action": "FUSE",
                        "mode": dec.mode,
                        "scope": {"agent_id": dec.agent_id, "session_id": dec.session_id},
                        "budget": {"token_cap": dec.token_cap, "tool_calls": dec.tool_calls},
                        "until": "USER_ACK",
                        "reason": dec.reason,
                        "trigger": {"severity": dec.severity, "types": list(dec.trigger_types)},
                    },
                },
                "Y_star_t": {"constraints": {}, "y_star_meta": {"source": "k9log.fuse", "version": "1.0", "hash": "builtin", "loaded_at": ""}},
                "Y_t+1": {"status": "fuse_triggered", "result": {"mode": dec.mode, "agent_id": dec.agent_id}},
                "R_t+1": {"passed": True, "overall_severity": dec.severity, "violations": []},
            }
            CIEULogger().write_cieu(fuse_record)
        except Exception:
            # Never crash the host on fuse bookkeeping
            pass

    return state


def maybe_fuse(record: Dict[str, Any], fuse_cfg: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """
    Returns fuse state dict if activated; otherwise None.
    """
    dec = decide(record, fuse_cfg)
    if not dec.fuse:
        return None
    return activate(dec, record, write_cieu_event=bool(fuse_cfg.get("write_cieu_event", True)))

