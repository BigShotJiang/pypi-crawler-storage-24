"""
Deterministic verdict engine for Constitutional governance layer.
Pure function: NormalizedEvent + List[Grant] -> Verdict
No I/O, no side effects.
"""
from __future__ import annotations
from typing import List, Optional

from k9log.governance.action_class import is_grant_required, is_irreversible
from k9log.governance.grants import Grant
from k9log.governance.constitutional_defaults import get_default_correction
from k9log.governance.types import (
    NormalizedEvent, Verdict, VerdictOutcome, ViolationType
)

# Severity constants
SEV_HARD_BLOCK  = 0.95
SEV_BLOCKED     = 0.75
SEV_AUTHORIZED  = 0.0


def evaluate(event: NormalizedEvent, grants: List[Grant]) -> Verdict:
    """
    Core constitutional evaluation. Pure function.

    Decision order (mirrors constitution.md Article I + Article V):
    1. If action is irreversible AND no valid grant => IRREVERSIBLE_NO_AUTH (hard block)
    2. If grant_required AND no grants at all    => NO_GRANT (hard block)
    3. If grants exist but expired               => GRANT_EXPIRED (hard block)
    4. If grants exist but class mismatch        => GRANT_CLASS_MISMATCH (blocked)
    5. If grants exist, class ok, scope mismatch => GRANT_SCOPE_MISMATCH (blocked)
    6. If valid grant found                      => AUTHORIZED
    """
    ac  = event.action_class
    irreversible = event.irreversible or is_irreversible(ac)
    grant_req    = is_grant_required(ac)

    # ── Fast path: READ without grant requirement ──────────────────────────────
    if not grant_req and not irreversible:
        return Verdict(
            outcome=VerdictOutcome.AUTHORIZED,
            action_class=ac,
            severity=SEV_AUTHORIZED,
            reason="Action class does not require a grant.",
        )

    # ── Classify available grants ──────────────────────────────────────────────
    matching_grants: List[Grant] = []
    expired_grants:  List[Grant] = []
    class_mismatch:  List[Grant] = []
    scope_mismatch:  List[Grant] = []

    for g in grants:
        if g.is_expired():
            expired_grants.append(g)
            continue
        if not g.covers_class(ac):
            class_mismatch.append(g)
            continue
        if not g.covers_scope(event.facts):
            scope_mismatch.append(g)
            continue
        # Passes all checks
        if g.agent_id and event.agent_id and g.agent_id != event.agent_id:
            scope_mismatch.append(g)
            continue
        matching_grants.append(g)

    # ── Authorized path ────────────────────────────────────────────────────────
    if matching_grants:
        best = matching_grants[0]
        return Verdict(
            outcome=VerdictOutcome.AUTHORIZED,
            action_class=ac,
            grant_id=best.grant_id,
            severity=SEV_AUTHORIZED,
            reason=f"Authorized by grant {best.grant_id}.",
        )

    # ── No valid grant — determine best violation type ─────────────────────────
    violation_types: List[ViolationType] = []

    if not grants:
        violation_types.append(ViolationType.NO_GRANT)
    elif expired_grants and not class_mismatch and not scope_mismatch:
        violation_types.append(ViolationType.GRANT_EXPIRED)
    elif class_mismatch and not scope_mismatch:
        violation_types.append(ViolationType.GRANT_CLASS_MISMATCH)
    elif scope_mismatch:
        violation_types.append(ViolationType.GRANT_SCOPE_MISMATCH)
    else:
        violation_types.append(ViolationType.NO_GRANT)

    if irreversible:
        violation_types = [ViolationType.IRREVERSIBLE_NO_AUTH] + [
            v for v in violation_types if v != ViolationType.IRREVERSIBLE_NO_AUTH
        ]

    hard_block = True  # All failure paths are hard blocks in constitutional mode
    ask_user   = ac in ("DELETE", "TRANSFER", "ADMIN")
    correction = get_default_correction(ac)
    severity   = SEV_HARD_BLOCK if hard_block else SEV_BLOCKED

    return Verdict(
        outcome=VerdictOutcome.HARD_BLOCK,
        violation_types=violation_types,
        hard_block=hard_block,
        ask_user=ask_user,
        action_class=ac,
        severity=severity,
        reason=f"No valid grant for {ac}. Violations: {[v.value for v in violation_types]}",
        correction_hint=correction["hint"],
    )

