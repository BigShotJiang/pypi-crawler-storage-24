"""
Constitutional gate — integration bridge between k9log core and governance core.

Called from CIEULogger.write_cieu() ONLY when constitutional.enabled=True.
Default: disabled (zero impact on v0.4.3 behavior).

Responsibilities:
  1. Extract NormalizedEvent from a CIEU record (best-effort, input-agnostic)
  2. Load grants from configured grants_dir
  3. Call governance.evaluate() → Verdict
  4. Merge Verdict into the record (R_t+1.violations + _constitutional field)
  5. Elevate severity / passed=False on hard_block

Does NOT:
  - Write to any file
  - Call alert/fuse channels
  - Know anything about OpenClaw
"""
from __future__ import annotations
import warnings
from pathlib import Path
from typing import Any, Dict, List, Optional

from k9log.governance.types import NormalizedEvent, EventFacts, Verdict, VerdictOutcome
from k9log.governance.grants import Grant, load_grants_from_dir
from k9log.agents_md_parser import parse_agents_md
from k9log.governance.verdict import evaluate


def is_constitutional_enabled(policy_cfg: Optional[Dict[str, Any]]) -> bool:
    """Return True only if constitutional.enabled=True in policy config."""
    if not policy_cfg:
        return False
    return bool((policy_cfg.get("constitutional") or {}).get("enabled", False))


def get_grants_dir(policy_cfg: Optional[Dict[str, Any]]) -> Optional[str]:
    """Return configured grants_dir or None."""
    if not policy_cfg:
        return None
    return (policy_cfg.get("constitutional") or {}).get("grants_dir")


def _extract_normalized_event(record: Dict[str, Any]) -> NormalizedEvent:
    """
    Best-effort extraction of NormalizedEvent from a CIEU record.
    Input-agnostic: works with any skill/tool name.
    Adapters (e.g. openclaw_adapter) may enrich this in future.
    """
    u_t    = record.get("U_t") or {}
    r_t1   = record.get("R_t+1") or {}
    params = u_t.get("params") or {}

    # Derive action_class — priority order (most to least reliable):
    #   1. record["action_class"]      — set by connector at record level
    #   2. X_t["action_class"]         — set by connector in context
    #   3. params["action_class"]      — set by adapter in skill params
    #   4. _infer_action_class()        — keyword heuristic, last resort only
    action_class = (
        record.get("action_class")
        or record.get("X_t", {}).get("action_class")
        or params.get("action_class")
        or _infer_action_class(u_t.get("skill", ""), params)
    )

    # Extract facts — parse URLs to hostnames (not raw URL strings)
    def _url_to_host(val: str) -> str:
        try:
            from urllib.parse import urlparse
            if "://" not in val:
                val = "https://" + val
            h = urlparse(val).hostname
            return h.lower() if h else val
        except Exception:
            return val

    raw_domains = params.get("domain") or params.get("domains") or params.get("url") or []
    raw_list    = _to_list(raw_domains)
    domains     = [_url_to_host(d) for d in raw_list]
    paths    = _to_list(params.get("path") or params.get("paths") or params.get("file") or [])
    commands = _to_list(params.get("command") or params.get("commands") or u_t.get("skill") or [])

    irreversible = bool(
        record.get("irreversible")
        or r_t1.get("irreversible")
        or params.get("irreversible")
    )

    x_t = record.get("X_t") or {}
    return NormalizedEvent(
        action_class=action_class,
        facts=EventFacts(domains=domains, paths=paths, commands=commands),
        irreversible=irreversible,
        agent_id=x_t.get("agent_id"),
        session_id=x_t.get("session_id"),
    )


def _infer_action_class(skill: str, params: dict) -> str:
    """Last-resort heuristic: infer action_class from skill name keywords.

    This function is ONLY called when the CIEU record carries no explicit
    action_class (i.e. the connector/adapter did not set it).  Connectors
    SHOULD set action_class in X_t or at record level; this is a safety net.

    The keyword lists below are intentionally broad and language-agnostic.
    They are loaded from ~/.k9log/config/action_class_keywords.json when
    present, so operators can extend them without touching core code.

    Schema (all fields optional, values are keyword substring lists):
    {
      "READ":     ["read", "get", "fetch", ...],
      "WRITE":    ["write", "create", "save", ...],
      "DELETE":   ["delete", "remove", ...],
      "TRANSFER": ["transfer", "pay", "wire", ...],
      "NETWORK":  ["http", "request", "api", ...],
      "ADMIN":    ["admin", "sudo", "privilege", ...]
    }
    """
    import json
    from pathlib import Path

    # Load operator-supplied keyword overrides
    kw_path = Path.home() / '.k9log' / 'config' / 'action_class_keywords.json'
    if kw_path.exists():
        try:
            keyword_map = json.loads(kw_path.read_text(encoding='utf-8'))
        except Exception:
            keyword_map = {}
    else:
        keyword_map = {}

    # Merge with defaults (operator overrides take precedence via dict merge)
    defaults = {
        "READ":     ["read", "get", "fetch", "list", "search", "query", "load", "show"],
        "WRITE":    ["write", "create", "save", "upload", "post", "insert", "put", "update", "edit"],
        "DELETE":   ["delete", "remove", "drop", "purge", "erase", "clear"],
        "TRANSFER": ["transfer", "send_money", "pay", "wire", "remit"],
        "NETWORK":  ["http", "request", "call", "api", "network", "email", "webhook", "notify"],
        "ADMIN":    ["admin", "escalat", "sudo", "privilege", "root"],
    }
    for cls, kws in defaults.items():
        if cls not in keyword_map:
            keyword_map[cls] = kws

    s = skill.lower()
    for action_class, keywords in keyword_map.items():
        if any(kw in s for kw in keywords):
            return action_class
    return "EXECUTE"


def _to_list(val) -> List[str]:
    if not val:
        return []
    if isinstance(val, list):
        return [str(v) for v in val if v]
    return [str(val)]


def apply_constitutional_gate(
    record: Dict[str, Any],
    policy_cfg: Optional[Dict[str, Any]],
    policy_id: str = "",
    policy_version: str = "",
) -> None:
    """
    Mutate record in-place: add _constitutional field and merge violations.
    Called from CIEULogger.write_cieu() only when constitutional mode is enabled.
    No-op if constitutional mode is disabled (guards are in caller).
    """
    # Load grants
    grants: List[Grant] = []
    # Load AGENTS.md grants first (basic law layer)
    agents_md = (policy_cfg or {}).get("agents_md_path")
    if agents_md:
        try:
            grants += parse_agents_md(agents_md)
        except Exception as e:
            warnings.warn(f"k9log constitutional: failed to parse AGENTS.md from {agents_md}: {e}")
    # Load manual grants (lower law layer)
    grants_dir = get_grants_dir(policy_cfg)
    if grants_dir:
        try:
            grants += load_grants_from_dir(grants_dir)
        except Exception as e:
            warnings.warn(f"k9log constitutional: failed to load grants from {grants_dir}: {e}")

    # Extract normalized event
    try:
        event = _extract_normalized_event(record)
    except Exception as e:
        warnings.warn(f"k9log constitutional: failed to extract event: {e}")
        return

    # Evaluate
    verdict: Verdict = evaluate(event, grants)

    # Write _constitutional field into record
    record["_constitutional"] = verdict.to_cieu_field(
        policy_id=policy_id,
        policy_version=policy_version,
    )

    # Merge violations into R_t+1.violations
    if verdict.violation_types:
        r_t1 = record.setdefault("R_t+1", {})
        existing_violations = r_t1.setdefault("violations", [])
        for vt in verdict.violation_types:
            existing_violations.append({
                "type":       vt.value,
                "param":      "_constitutional",
                "actual":     event.action_class,
                "constraint": "constitutional_gate",
            })
        # Elevate passed / severity on hard block
        if verdict.hard_block:
            r_t1["passed"] = False
            r_t1["overall_severity"] = max(
                float(r_t1.get("overall_severity", 0.0)),
                verdict.severity,
            )

