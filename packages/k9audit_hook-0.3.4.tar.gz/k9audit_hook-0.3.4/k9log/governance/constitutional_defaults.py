"""
Constitutional layer default corrections.
Provides fallback correction_hint and ask_user for each action class
when no matching grant exists. Input-agnostic, platform-independent.
"""
from __future__ import annotations
from typing import Dict, Any

CONSTITUTIONAL_CORRECTIONS: Dict[str, Dict[str, Any]] = {
    "EXECUTE": {
        "hint": "No grant authorizes this command. Add a grant in ~/.k9log/grants/ that includes this command in scope.commands.",
        "ask_user": False,
    },
    "WRITE": {
        "hint": "No grant authorizes writing to this path. Add a grant that includes this path in scope.paths.",
        "ask_user": False,
    },
    "DELETE": {
        "hint": "DELETE is irreversible. No grant authorizes this operation. Obtain explicit user authorization before proceeding.",
        "ask_user": True,
    },
    "TRANSFER": {
        "hint": "TRANSFER is irreversible. No grant authorizes this operation. Obtain explicit user authorization before proceeding.",
        "ask_user": True,
    },
    "ADMIN": {
        "hint": "ADMIN operations require explicit authorization. No grant found. Obtain explicit user authorization before proceeding.",
        "ask_user": True,
    },
    "NETWORK": {
        "hint": "No grant authorizes network access to this domain. Add a grant that includes this domain in scope.domains.",
        "ask_user": False,
    },
    "READ": {
        "hint": "No grant authorizes reading this resource. Add a grant that includes this path or domain in scope.",
        "ask_user": False,
    },
}

def get_default_correction(action_class: str) -> Dict[str, Any]:
    """
    Return default correction dict for a given action class.
    Falls back to EXECUTE defaults if action_class is unknown.
    """
    return CONSTITUTIONAL_CORRECTIONS.get(
        action_class,
        CONSTITUTIONAL_CORRECTIONS["EXECUTE"]
    )

