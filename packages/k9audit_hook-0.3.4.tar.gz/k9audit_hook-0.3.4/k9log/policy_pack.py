# K9log - Engineering-grade Causal Audit for AI Agent Ecosystems
# Copyright (C) 2026 Haotian Liu
# AGPL-3.0 - see LICENSE for details
"""
k9log.policy_pack - Policy Pack: user-defined alert/fuse rules with
canonical hash pinning and HMAC-SHA256 signature verification.
"""
from __future__ import annotations
import hmac
import hashlib
import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Optional

POLICY_PATH = Path.home() / '.k9log' / 'policy.json'

# Default alert rules (mirrors current alerting DEFAULT_CONFIG.rules)
DEFAULT_ALERT_RULES: Dict[str, Any] = {
    "min_severity": 0.0,
    "skills": [],
    "violation_types": [],
}

# Default fuse rules (mirrors current alerting DEFAULT_CONFIG.fuse)
DEFAULT_FUSE_RULES: Dict[str, Any] = {
    "enabled": False,
    "min_severity": 0.85,
    "violation_types": [
        "blocklist_hit",
        "blocklist_substring",
        "numeric_exceeded",
        "allowlist_miss",
        "enum_violation",
        "type_mismatch",
        "regex_mismatch",
    ],
    "scope": "agent",
    "cooldown_seconds": 600,
    "mode": "TOKEN_BUDGET_FREEZE",
    "budget": {"token_cap": 0, "tool_calls": 0},
    "write_cieu_event": True,
    "reason": "risk threshold exceeded",
}


@dataclass
class PolicyPack:
    """Immutable policy definition for alert and fuse subsystems."""
    policy_id: str
    version: str
    created_at: str
    alerts: Dict[str, Any] = field(default_factory=lambda: dict(DEFAULT_ALERT_RULES))
    fuse: Dict[str, Any] = field(default_factory=lambda: dict(DEFAULT_FUSE_RULES))
    meta: Dict[str, Any] = field(default_factory=dict)
    constitutional: Dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Serialisation helpers
# ---------------------------------------------------------------------------

def _to_dict(policy: PolicyPack) -> Dict[str, Any]:
    return {
        "policy_id": policy.policy_id,
        "version": policy.version,
        "created_at": policy.created_at,
        "alerts": policy.alerts,
        "fuse": policy.fuse,
        "meta": policy.meta,
        "constitutional": policy.constitutional,
    }


def policy_canonical_json(policy: PolicyPack) -> str:
    """Stable, deterministic serialisation used for hashing."""
    return json.dumps(
        _to_dict(policy),
        sort_keys=True,
        ensure_ascii=True,
        separators=(",", ":"),
    )


def policy_hash(policy: PolicyPack) -> str:
    """SHA-256 hex digest of the canonical JSON."""
    return hashlib.sha256(policy_canonical_json(policy).encode()).hexdigest()


# ---------------------------------------------------------------------------
# Load / save
# ---------------------------------------------------------------------------

def load_policy(path) -> PolicyPack:
    """Load a PolicyPack from a JSON file."""
    with open(path, "r", encoding="utf-8-sig") as f:  # utf-8-sig strips BOM if present
        data = json.load(f)
    alerts = {**DEFAULT_ALERT_RULES, **data.get("alerts", {})}
    fuse   = {**DEFAULT_FUSE_RULES,  **data.get("fuse",   {})}
    constitutional = data.get("constitutional", {})
    return PolicyPack(
        policy_id      = data.get("policy_id",  "unnamed"),
        version        = data.get("version",    "0.0.1"),
        created_at     = data.get("created_at", ""),
        alerts         = alerts,
        fuse           = fuse,
        meta           = data.get("meta", {}),
        constitutional = constitutional,
    )


def save_active_policy(policy: PolicyPack) -> None:
    """Persist policy as the active policy (~/.k9log/policy.json)."""
    POLICY_PATH.parent.mkdir(parents=True, exist_ok=True)
    POLICY_PATH.write_text(
        json.dumps(_to_dict(policy), indent=2, ensure_ascii=False),
        encoding="utf-8",
    )


def get_active_policy() -> Optional[PolicyPack]:
    """Return the currently active policy, or None if none is loaded."""
    if not POLICY_PATH.exists():
        return None
    try:
        return load_policy(POLICY_PATH)
    except Exception:
        return None


# ---------------------------------------------------------------------------
# HMAC-SHA256 signature
# ---------------------------------------------------------------------------

def generate_policy_signature(policy_path, key: Optional[str] = None) -> str:
    """Generate HMAC-SHA256 signature for a policy file.

    Key priority: explicit arg → K9LOG_POLICY_HMAC_KEY env var.
    """
    k = key or os.environ.get("K9LOG_POLICY_HMAC_KEY", "")
    if not k:
        raise ValueError("K9LOG_POLICY_HMAC_KEY not set and no key provided")
    pol = load_policy(policy_path)
    canonical = policy_canonical_json(pol)
    return hmac.new(k.encode(), canonical.encode(), hashlib.sha256).hexdigest()


def verify_policy_signature(policy_path, sig_path, key: Optional[str] = None) -> bool:
    """Verify HMAC-SHA256 signature of a policy file.

    Returns True if:
      - No HMAC key is configured (permissive default — key not yet set up), OR
      - Signature matches.
    Returns False if key is set and signature mismatches or is missing.
    """
    k = key or os.environ.get("K9LOG_POLICY_HMAC_KEY", "")
    if not k:
        return True  # No key configured: verification skipped
    try:
        pol = load_policy(policy_path)
        canonical = policy_canonical_json(pol)
        expected = hmac.new(k.encode(), canonical.encode(), hashlib.sha256).hexdigest()
        sig = Path(sig_path).read_text(encoding="utf-8").strip()
        return hmac.compare_digest(expected, sig)
    except Exception:
        return False

