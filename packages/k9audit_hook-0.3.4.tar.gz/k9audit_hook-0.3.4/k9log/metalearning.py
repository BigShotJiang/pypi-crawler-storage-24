# K9log - Engineering-grade Causal Audit for AI Agent Ecosystems
# Copyright (C) 2026 Haotian Liu
# AGPL-3.0 License
"""
K9log Causal Metalearning - Pearl Rung 3 policy learning from incident history

Theory:
  Statistical learning (Rung 1): "This skill violated 7 times, tighten it."
  Causal metalearning (Rung 3):  "This rule, in counterfactual replay, deterministically
                                  cuts the causal chain at the ROOT CAUSE step."

Algorithm:
  1. Abduction   - find terminal incidents from R_t+1.violations (data-driven)
  2. Root trace  - walk backward through CIEU to find earliest causal ancestor
  3. Intervention - generate candidate rules with non-empty, verifiable scopes
  4. Prediction  - counterfactual replay: same trace + new Y*_t constraints
  5. Minimality  - minimum set cover by causal proof, not frequency
  6. Output      - grant suggestions with causal evidence attached

Session-scoped activation (v2):
  High-confidence rules (fp_rate=0, counterfactual proof, non-empty scope)
  are written to grants/session/ and take effect immediately within the
  current session.  finalize_session() in logger.py cleans them up.

  Low-confidence rules go to grants/suggested/ and require human approval.

  Activation criteria (all must hold):
    - fp_rate == 0.0  (zero false positives in replay)
    - false_positives == 0
    - causal_proof contains "Counterfactual" (replay-proven, not heuristic)
    - rule_type in (output_blocklist, param_blocklist, taint_block)
    - output_modifications non-empty (enforceable by mcp_server)

  Security: session grants expire at session end — blast radius of a
  compromised learning signal is bounded to one session.
"""
import re as _re
import json
from pathlib import Path
from datetime import datetime, timezone
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from k9log.counterfactual import CounterfactualEngine

console = Console()

# ── Taint evidence extraction helpers (shared between candidates + grant writing) ──

_HOSTNAME_RE = _re.compile(
    r'\b(?:[\w\-]+\.){2,}(?:com|internal|io|net|org|dev|local)\b'
)
_CRED_RE = _re.compile(
    r'(?:sk_|api_key_|prod_key_|secret_key_|ghp_|xox[bpas]-)[\w\-]{6,}',
    _re.I
)
_TAINT_EXCLUDE_PREFIXES = ("np.", "os.", "sys.", "src.", "df.", "self.", "urllib.")

# FP rate threshold for counterfactual-proven rules
# Rules that block > 10% of clean records are too broad
_MAX_FP_RATE = 0.10


def _extract_taint_evidence(params_str: str) -> list:
    """Extract concrete blocked terms from a params string via regex."""
    evidence = []
    for m in _HOSTNAME_RE.findall(params_str):
        if not any(m.startswith(e) for e in _TAINT_EXCLUDE_PREFIXES):
            if m not in evidence:
                evidence.append(m)
    for m in _CRED_RE.findall(params_str):
        token = m[:50]
        if token not in evidence:
            evidence.append(token)
    return evidence


class CausalMetaLearner:
    """
    Learns governance rules from incident history using Pearl Rung 3 reasoning.
    Every suggested rule comes with a counterfactual proof and a non-empty scope.
    """

    def __init__(self, log_file=None):
        if log_file is None:
            log_file = Path.home() / ".k9log" / "logs" / "k9log.cieu.jsonl"
        self.log_file = Path(log_file)
        self.cf_engine = CounterfactualEngine(log_file)
        self.records = self.cf_engine.records

    def _is_anomalous(self, value_str):
        """Kept for backward compat — not used in data-driven path."""
        return False

    # ── Step 1: Abduction ────────────────────────────────────────
    def _structural_params(self) -> set:
        """Return the set of parameter names that are structural/metadata (never carry taint).

        Loaded from ~/.k9log/config/taint.json -> structural_params.
        The core engine ships with an EMPTY default — connectors declare their own
        via taint.json so the engine stays input-agnostic.
        """
        import json
        from pathlib import Path
        cfg_path = Path.home() / '.k9log' / 'config' / 'taint.json'
        if cfg_path.exists():
            try:
                cfg = json.loads(cfg_path.read_text(encoding='utf-8'))
                return set(cfg.get('structural_params', []))
            except Exception:
                pass
        return set()

    def _extract_incidents(self):
        """Find terminal incidents from R_t+1.violations (data-driven).

        Primary:     R_t+1.passed=False with actual violations
        Fallback:    R_t+1.passed=False with execution_error (security class)
        Supplemental: TaintTracker violations not caught by R_t+1
        """
        incidents = []
        taint_incident_steps = set()
        taint_violations_by_step = {}  # step → list of taint violation dicts

        try:
            from k9log.taint import TaintTracker
            tracker = TaintTracker(self.log_file)
            taint_result = tracker.analyze_taint_propagation()
            for tv in taint_result.get("violations", []):
                step = tv["step"]
                taint_incident_steps.add(step)
                taint_violations_by_step.setdefault(step, []).append(tv)
        except Exception:
            pass  # taint analysis optional

        for idx, record in enumerate(self.records):
            # Skip fuse/governance records — not real incidents
            if (record.get("event_type") == "FUSE"
                    or record.get("U_t", {}).get("skill") == "k9log.fuse"):
                continue
            r_t1 = record.get("R_t+1", {})

            if not r_t1.get("passed", True):
                pass  # fall through to violation handling
            elif idx in taint_incident_steps:
                skill = record.get("U_t", {}).get("skill", "unknown")
                # Extract taint evidence for candidate generation later
                params = record.get("U_t", {}).get("params", {})
                params_str = " ".join(str(v) for v in params.values())
                taint_ev = _extract_taint_evidence(params_str)
                incidents.append({
                    "step": idx,
                    "skill": skill,
                    "marker": "taint_violation",
                    "violation": {
                        "type": "taint_violation",
                        "message": "tainted data reached high-privilege skill",
                        "tainted_params": list(
                            k for k in params.keys()
                            if k not in self._structural_params()
                        ),
                    },
                    "severity": 0.7,
                    "result": record.get("Y_t+1", {}).get("result", {}),
                    "record": record,
                    "taint_evidence": taint_ev,  # carry evidence forward
                })
                continue
            else:
                continue  # no violation

            skill = record.get("U_t", {}).get("skill", "unknown")
            violations = r_t1.get("violations", [])
            exec_error = r_t1.get("execution_error", "")

            if violations:
                for v in violations:
                    marker = v.get("type", "unknown_violation")
                    incidents.append({
                        "step": idx,
                        "skill": skill,
                        "marker": marker,
                        "violation": v,
                        "severity": r_t1.get("overall_severity", 0.0),
                        "result": record.get("Y_t+1", {}).get("result", {}),
                        "record": record,
                        "taint_evidence": [],
                    })
                    break  # one incident per step
            elif exec_error and r_t1.get("overall_severity", 0.0) >= 0.5:
                incidents.append({
                    "step": idx,
                    "skill": skill,
                    "marker": r_t1.get("error_type", "runtime_error"),
                    "violation": {
                        "type": r_t1.get("error_type", "runtime_error"),
                        "message": exec_error[:120],
                    },
                    "severity": r_t1.get("overall_severity", 0.0),
                    "result": record.get("Y_t+1", {}).get("result", {}),
                    "record": record,
                    "taint_evidence": [],
                })
        return incidents

    # ── Step 2: Root cause trace ─────────────────────────────────
    def _find_root_cause_steps(self, incident_step):
        """Walk backward from incident_step to find the true causal intervention point.

        Priority:
          1. Earliest prior step with R_t+1.passed=False — direct causal ancestor
          2. _write_file step whose output a later violation references
          3. Fallback: incident step itself is the root
        """
        violation_roots = []
        write_roots = []

        for idx in range(incident_step):
            record = self.records[idx]
            rt1    = record.get("R_t+1", {})
            skill  = record.get("U_t", {}).get("skill", "unknown")
            params = record.get("U_t", {}).get("params", {})
            result = record.get("Y_t+1", {}).get("result", {})

            if not rt1.get("passed", True) and rt1.get("violations"):
                for v in rt1["violations"]:
                    violation_roots.append({
                        "step": idx,
                        "skill": skill,
                        "result": result,
                        "marker": v.get("type", "unknown_violation"),
                        "violation": v,
                        "intervention": "prior_violation",
                    })
                break  # earliest is the root

            # Detect write-type operations using action_class (input-agnostic).
            # action_class is set by the connector/adapter in X_t or at record level.
            # We do NOT match on skill names — that would break any non-MCP agent.
            _rec_action_class = (
                record.get("action_class", "")
                or record.get("X_t", {}).get("action_class", "")
            ).upper()
            _is_write_op = _rec_action_class == "WRITE"
            if _is_write_op:
                for later_idx in range(idx + 1, incident_step + 1):
                    later = self.records[later_idx]
                    if not later.get("R_t+1", {}).get("passed", True):
                        write_roots.append({
                            "step": idx,
                            "skill": skill,
                            "result": params,
                            "marker": "write_before_violation",
                            "intervention": "write_input",
                        })
                        break

        if violation_roots:
            return violation_roots
        if write_roots:
            return write_roots
        return []

    # ── Token generalizer ────────────────────────────────────────
    def _generalize_token(self, token: str, all_tokens: list) -> str:
        """Generalize a specific token to a regex pattern if siblings share a prefix.

        Guards:
          - Returns original token if no related tokens found
          - Returns original token if common prefix < 4 chars (too short to be useful)
          - Returns original token if generalized result would be empty (BUG-5 fix)

        Examples:
          ["test_key_sk_abc", "test_key_sk_1234"] → "re:test_key_sk_\\S*"
          ["staging.internal"] → "staging.internal"  (unique, no generalization)
        """
        def common_prefix(a, b):
            i = 0
            while i < len(a) and i < len(b) and a[i] == b[i]:
                i += 1
            return a[:i]

        related = [t for t in all_tokens if t != token and len(common_prefix(token, t)) >= 6]

        if not related:
            return token  # unique token, use as-is

        prefix = token
        for r in related:
            prefix = common_prefix(prefix, r)

        # Trim to last meaningful boundary
        for boundary in reversed(range(len(prefix))):
            if prefix[boundary] in "_-.":
                prefix = prefix[:boundary + 1]
                break

        # BUG-5 fix: guard against empty or too-short prefix
        if not prefix or len(prefix) < 4:
            return token

        escaped = _re.escape(prefix)
        return f"re:{escaped}\\S*"

    # ── Step 3: Intervention — enumerate candidates ───────────────
    def _enumerate_candidates(self, incidents):
        """Generate candidate rules — each candidate must have a non-empty scope.

        BUG-1 fix: skip output_blocklist where actual value is empty string
        BUG-2 fix: param_blocklist and taint_block now populate output_modifications
        BUG-3 fix: taint_block candidates carry their blocked terms for replay

        Rule types and their output_modifications structure:
          output_blocklist  → {skill: {field: {blocklist: [actual]}}}
          param_blocklist   → {skill: {field: {blocklist: [val]}}}  (same format,
                              checked against both params and output in replay)
          taint_block       → {target_skill: {field: {blocklist: [evidence_terms]}}}
          constitutional    → empty output_mods; scope tracked via action_class_restrictions
          param_validation  → empty output_mods; scope tracked via param_validation_hints
        """
        candidates = []
        seen = set()

        for inc in incidents:
            viol   = inc.get("violation", {})
            vtype  = viol.get("type", "unknown")
            skill  = inc["skill"]
            step   = inc["step"]

            # ── GRANT_SCOPE_MISMATCH → constitutional restriction ──────────
            if vtype == "GRANT_SCOPE_MISMATCH":
                actual_class = viol.get("actual", "EXECUTE")
                rule_id = f"grant_scope_{skill}_{actual_class}"
                if rule_id not in seen:
                    seen.add(rule_id)
                    candidates.append({
                        "id": rule_id,
                        "description": (
                            f"Restrict {skill} action class {actual_class!r} — "
                            f"GRANT_SCOPE_MISMATCH at step #{step}"
                        ),
                        "target_skill": skill,
                        "target_field": "_constitutional",
                        "root_step": step,
                        "rule_type": "constitutional",
                        "modifications": {},
                        "output_modifications": {},
                        # Carry constitutional restriction for grant scope
                        "action_class_restrictions": {skill: actual_class},
                        "incident_step": step,
                    })

            # ── security_error → param blocklist ──────────────────────────
            elif vtype == "security_error":
                params = inc.get("record", {}).get("U_t", {}).get("params", {})
                for field, val in params.items():
                    val_str = str(val).strip()[:80]
                    # BUG-1 fix: skip empty or trivially-short values
                    if not val_str or len(val_str) < 3:
                        continue
                    rule_id = f"block_{skill}_{field}_{val_str[:20].replace('.', '_').replace(' ', '_')}"
                    if rule_id not in seen:
                        seen.add(rule_id)
                        # BUG-2 fix: populate output_modifications (same structure,
                        # counterfactual engine checks it against both params and result)
                        candidates.append({
                            "id": rule_id,
                            "description": (
                                f"Block param {field}={val_str!r} in {skill} "
                                f"(security error at step #{step})"
                            ),
                            "target_skill": skill,
                            "target_field": field,
                            "root_step": step,
                            "rule_type": "param_blocklist",
                            "modifications": {skill: {field: {"blocklist": [val_str]}}},
                            "output_modifications": {skill: {field: {"blocklist": [val_str]}}},
                            "incident_step": step,
                        })
                        break  # one rule per incident

            # ── runtime_error → param validation hint ─────────────────────
            elif vtype == "runtime_error":
                err_msg = viol.get("message", "")
                params  = inc.get("record", {}).get("U_t", {}).get("params", {})
                rule_id = f"validate_{skill}_params_step{step}"
                if rule_id not in seen:
                    seen.add(rule_id)
                    candidates.append({
                        "id": rule_id,
                        "description": (
                            f"Validate params for {skill} — "
                            f"runtime error at step #{step}: {err_msg[:60]}"
                        ),
                        "target_skill": skill,
                        "target_field": list(params.keys())[0] if params else "unknown",
                        "root_step": step,
                        "rule_type": "param_validation",
                        "modifications": {},
                        "output_modifications": {},
                        "param_validation_hints": {
                            skill: {"error": err_msg[:120], "step": step}
                        },
                        "incident_step": step,
                    })

            # ── taint_violation → content blocklist from taint evidence ───
            elif vtype == "taint_violation":
                # BUG-2 + BUG-3 fix: extract evidence NOW so counterfactual
                # replay can actually verify this rule
                params = inc.get("record", {}).get("U_t", {}).get("params", {})
                tainted_fields = viol.get(
                    "tainted_params",
                    [k for k in params.keys()
                     if k not in self._structural_params()]
                )
                field = tainted_fields[0] if tainted_fields else "content"

                # Use pre-extracted evidence from _extract_incidents, or re-extract
                evidence = inc.get("taint_evidence", [])
                if not evidence:
                    params_str = " ".join(str(v) for v in params.values())
                    evidence = _extract_taint_evidence(params_str)

                dedup_key = f"taint_block_{skill}_{field}"
                if dedup_key not in seen:
                    seen.add(dedup_key)

                    if evidence:
                        # Generalize tokens where possible
                        generalized = [self._generalize_token(e, evidence) for e in evidence]
                        # BUG-2 fix: set output_modifications so replay works
                        output_mods = {skill: {field: {"blocklist": generalized}}}
                    else:
                        # No concrete evidence → can't form a verifiable rule
                        # Still emit the candidate but with empty output_mods;
                        # it will be filtered in _find_minimum_cover (no blocked_steps)
                        output_mods = {}

                    candidates.append({
                        "id": dedup_key,
                        "description": (
                            f"Block tainted {field} input to {skill} "
                            f"(taint_violation at step #{step}, evidence: "
                            f"{len(evidence)} term(s))"
                        ),
                        "target_skill": skill,
                        "target_field": field,
                        "root_step": step,
                        "rule_type": "taint_block",
                        "modifications": {},
                        "output_modifications": output_mods,
                        "taint_evidence": evidence,
                        "incident_step": step,
                    })

            # ── Generic constraint violation → output blocklist ───────────
            else:
                field  = viol.get("field", "unknown")
                actual = str(viol.get("actual", "")).strip()[:60]

                # BUG-1 fix: skip if actual value is empty — blocklist[""] would
                # match every string via substring tier → all records become FP
                if not actual or actual == "unknown":
                    continue

                rule_id = (
                    f"block_{skill}_{field}_"
                    f"{actual[:20].replace('.', '_').replace(' ', '_')}"
                )
                if rule_id not in seen:
                    seen.add(rule_id)
                    candidates.append({
                        "id": rule_id,
                        "description": (
                            f"Block {field}={actual!r} in {skill} "
                            f"(violation {vtype} at step #{step})"
                        ),
                        "target_skill": skill,
                        "target_field": field,
                        "root_step": step,
                        "rule_type": "output_blocklist",
                        "modifications": {},
                        "output_modifications": {
                            skill: {field: {"blocklist": [actual]}}
                        },
                        "incident_step": step,
                    })

        return candidates

    # ── Step 4+5: Counterfactual prediction + minimum cover ───────
    def _find_minimum_cover(self, incidents, candidates):
        """Greedy minimum cover — every rule requires counterfactual proof.

        BUG-3 fix: taint_block rules now go through counterfactual replay
                   (they have output_modifications populated by _enumerate_candidates)
        BUG-4 fix: greedy coverage uses actual blocked_steps intersection,
                   not the naive `cut <= s` approximation
        New:       FP rate threshold — rules blocking > _MAX_FP_RATE of clean
                   records are flagged (included but marked high-FP)
        """
        incident_steps = {inc["step"] for inc in incidents}
        total_records  = len(self.records)

        proven_rules = []
        for rule in candidates:
            rule_type = rule.get("rule_type", "output_blocklist")
            root_step = rule["root_step"]

            # ── Strategy A: constitutional rules ────────────────────────────
            # Proof: CIEU log shows _constitutional.hard_block=True
            # These have no output_modifications; proof is structural
            if rule_type == "constitutional":
                hard_blocked = [
                    idx for idx, rec in enumerate(self.records)
                    if rec.get("_constitutional", {}).get("hard_block")
                    and not rec.get("R_t+1", {}).get("passed", True)
                ]
                if hard_blocked:
                    cut = min(hard_blocked)
                    proven_rules.append({
                        "rule": rule,
                        "replay_result": {},
                        "cut_point": cut,
                        "blocked_steps": hard_blocked,
                        "false_positives": 0,
                        "fp_rate": 0.0,
                        "causal_proof": (
                            f"CIEU log: constitutional hard_block at step(s) "
                            f"{hard_blocked} — grant scope restriction needed"
                        ),
                    })
                continue

            # ── Strategy B: param_validation rules ──────────────────────────
            # Proof: same skill+runtime_error recurs in CIEU log
            # No output_modifications, but documented as a hint
            if rule_type == "param_validation":
                target_skill = rule["target_skill"]
                matching = [
                    idx for idx, rec in enumerate(self.records)
                    if rec.get("U_t", {}).get("skill") == target_skill
                    and not rec.get("R_t+1", {}).get("passed", True)
                    and rec.get("R_t+1", {}).get("execution_error")
                ]
                if matching:
                    cut = min(matching)
                    proven_rules.append({
                        "rule": rule,
                        "replay_result": {},
                        "cut_point": cut,
                        "blocked_steps": matching,
                        "false_positives": 0,
                        "fp_rate": 0.0,
                        "causal_proof": (
                            f"CIEU log: {len(matching)} runtime error(s) on "
                            f"{target_skill} — param validation needed "
                            f"(first at step #{cut})"
                        ),
                    })
                continue

            # ── Strategy C: counterfactual replay ───────────────────────────
            # Applies to: output_blocklist, param_blocklist, taint_block
            # BUG-3 fix: taint_block now goes here (not auto-accepted)

            # Skip if output_modifications is empty — replay would block nothing
            if not rule.get("output_modifications"):
                continue

            result  = self.cf_engine.replay_with_policy(rule)
            blocked = set(result.get("blocked_steps", []))
            cut     = result.get("cut_point")
            if cut is None and blocked:
                cut = min(blocked)

            # Must actually block at least one incident step
            incidents_blocked = incident_steps & blocked
            if not incidents_blocked:
                continue

            # False positives: steps that were clean originally but now blocked
            fp_steps   = [fp for fp in result.get("false_positives", [])
                          if fp["step"] != root_step]
            fp_count   = len(fp_steps)
            fp_rate    = fp_count / total_records if total_records > 0 else 0.0

            proven_rules.append({
                "rule": rule,
                "replay_result": result,
                "cut_point": cut,
                "blocked_steps": sorted(blocked),
                "incidents_blocked": sorted(incidents_blocked),  # BUG-4 fix
                "false_positives": fp_count,
                "fp_rate": fp_rate,
                "causal_proof": (
                    f"Counterfactual: cuts chain at step(s) "
                    f"{sorted(incidents_blocked)} — "
                    f"root cause at step #{root_step}, "
                    f"FP rate {fp_rate * 100:.1f}%"
                ),
            })

        # Sort: earliest cut first, fewest FP, lowest FP rate
        proven_rules.sort(
            key=lambda x: (x["cut_point"] or 999, x["false_positives"], x["fp_rate"])
        )

        # BUG-4 fix: greedy set cover uses actual incidents_blocked
        covered_incidents = set()
        minimum_cover     = []

        for pr in proven_rules:
            cut = pr["cut_point"]
            if cut is None:
                continue

            rule_type = pr["rule"].get("rule_type", "")

            # taint_block covers a content dimension orthogonal to other rules;
            # include it regardless of other coverage, but still require proof
            if rule_type == "taint_block":
                minimum_cover.append(pr)
                continue

            # Constitutional / param_validation: coverage by cut_point cascade
            if rule_type in ("constitutional", "param_validation"):
                newly_covered = {s for s in incident_steps if cut <= s}
            else:
                # BUG-4 fix: use actual incidents blocked, not cut <= s
                newly_covered = pr.get("incidents_blocked", set())
                if not isinstance(newly_covered, set):
                    newly_covered = set(newly_covered)

            new = newly_covered - covered_incidents
            if new:
                covered_incidents |= new
                minimum_cover.append(pr)

        return minimum_cover, proven_rules

    # ── Step 6: Write suggested grants ───────────────────────────
    def _write_suggested_grants(self, minimum_cover):
        """Write grant files with non-empty, enforecable scopes.

        BUG-2 + BUG-6 fix:
          - Pre-validate scope before writing
          - param_blocklist: scope.param_constraints carries modifications
          - taint_block: scope.deny_content carries taint_evidence terms
          - constitutional: scope.action_class_restrictions carries restriction
          - param_validation: scope.param_validation_hints carries error context
          - output_blocklist: scope.output_constraints as before (correct)
        """
        suggested_dir = Path.home() / ".k9log" / "grants" / "suggested"
        suggested_dir.mkdir(parents=True, exist_ok=True)
        lr_path = Path.home() / ".k9log" / "learned_rules.json"
        written = []
        now = datetime.now(timezone.utc).isoformat()

        # Load existing learned_rules for incremental merge
        if lr_path.exists():
            try:
                learned = json.loads(lr_path.read_text(encoding="utf-8"))
            except Exception:
                learned = {"version": "1.0", "rules": {}, "sessions": []}
        else:
            learned = {"version": "1.0", "rules": {}, "sessions": []}

        for pr in minimum_cover:
            rule      = pr["rule"]
            rule_type = rule.get("rule_type", "output_blocklist")
            rule_id   = rule["id"]

            # ── Build scope based on rule type ──────────────────────────────
            scope = {}

            if rule_type == "output_blocklist":
                output_mods = rule.get("output_modifications", {})
                if not output_mods:
                    console.print(
                        f"   [yellow]⚠ Skip {rule_id}: output_blocklist has empty "
                        f"output_modifications[/yellow]"
                    )
                    continue
                scope["output_constraints"] = output_mods

            elif rule_type == "param_blocklist":
                output_mods = rule.get("output_modifications", {})
                mods        = rule.get("modifications", {})
                if not output_mods and not mods:
                    console.print(
                        f"   [yellow]⚠ Skip {rule_id}: param_blocklist has no "
                        f"modifications[/yellow]"
                    )
                    continue
                # output_modifications doubles as the enforceable scope
                # (counterfactual engine checks it against both params and result)
                scope["output_constraints"] = output_mods or mods
                scope["param_constraints"]  = mods

            elif rule_type == "taint_block":
                evidence = rule.get("taint_evidence", [])
                output_mods = rule.get("output_modifications", {})
                if not evidence and not output_mods:
                    console.print(
                        f"   [yellow]⚠ Skip {rule_id}: taint_block has no "
                        f"evidence or output_modifications[/yellow]"
                    )
                    continue
                # deny_content is read by mcp_server._load_deny_terms() directly
                scope["deny_content"]       = evidence
                scope["output_constraints"] = output_mods

            elif rule_type == "constitutional":
                acr = rule.get("action_class_restrictions", {})
                if not acr:
                    # Minimal scope: flag the target skill for review
                    acr = {rule["target_skill"]: rule.get("target_field", "EXECUTE")}
                scope["action_class_restrictions"] = acr

            elif rule_type == "param_validation":
                hints = rule.get("param_validation_hints", {})
                scope["param_validation_hints"] = hints
                # param_validation grants are advisory — no enforcement mechanism
                # but still useful as documented findings

            else:
                # Unknown type — fall back to output_constraints
                output_mods = rule.get("output_modifications", {})
                if not output_mods:
                    console.print(
                        f"   [yellow]⚠ Skip {rule_id}: unknown rule_type "
                        f"{rule_type!r} and no output_modifications[/yellow]"
                    )
                    continue
                scope["output_constraints"] = output_mods

            # ── Assemble grant record ────────────────────────────────────────
            grant = {
                "grant_id": rule_id,
                "description": rule["description"],
                "scope": scope,
                "metalearning_metadata": {
                    "source": "CausalMetaLearner",
                    "theory": "Pearl Causal Hierarchy Rung 3",
                    "rule_type": rule_type,
                    "causal_proof": pr["causal_proof"],
                    "cut_point": pr["cut_point"],
                    "root_step": rule["root_step"],
                    "blocked_steps": pr["blocked_steps"],
                    "false_positives": pr["false_positives"],
                    "fp_rate": pr.get("fp_rate", 0.0),
                    "generated_at": now,
                },
            }

            safe_id = (
                rule_id.replace(":", "-").replace("\\", "-")
                       .replace("/", "-").replace(" ", "_")
            )
            path = suggested_dir / f"{safe_id}.json"
            path.write_text(json.dumps(grant, indent=2, ensure_ascii=False), encoding="utf-8")
            written.append(path)

            # Incremental merge into learned_rules.json
            entry = {
                "rule_id":          rule_id,
                "rule_type":        rule_type,
                "description":      rule.get("description"),
                "target_skill":     rule.get("target_skill"),
                "cut_point":        pr["cut_point"],
                "false_positives":  pr["false_positives"],
                "fp_rate":          pr.get("fp_rate", 0.0),
                "causal_proof":     pr["causal_proof"],
                "taint_evidence":   rule.get("taint_evidence", []),
                "modifications":    rule.get("modifications", {}),
                "output_modifications": rule.get("output_modifications", {}),
                "scope":            scope,
                "learned_at":       now,
                "source_log":       str(self.log_file),
            }
            learned["rules"][rule_id] = entry  # same id overwrites; new id accumulates

        # Append session record
        learned["sessions"].append({
            "ts":         now,
            "grants_written": len(written),
            "cover":      len(minimum_cover),
            "source_log": str(self.log_file),
        })
        lr_path.write_text(json.dumps(learned, indent=2, ensure_ascii=False), encoding="utf-8")
        return written

    # ── Session-scoped activation ─────────────────────────────────
    @staticmethod
    def _is_session_activatable(pr: dict) -> bool:
        """Return True if a proven rule meets all high-confidence criteria.

        All five gates must pass:
          1. Zero false positives in counterfactual replay
          2. fp_rate == 0.0  (not just low — exactly zero)
          3. Proof comes from actual replay, not a heuristic shortcut
          4. Rule type has an enforceable scope (output/param/taint blocklist)
          5. output_modifications is non-empty (mcp_server can enforce it)

        Constitutional and param_validation rules are intentionally excluded:
        they have advisory scopes and should always require human review.
        """
        if pr.get("false_positives", 1) != 0:
            return False
        if pr.get("fp_rate", 1.0) != 0.0:
            return False
        if "Counterfactual" not in pr.get("causal_proof", ""):
            return False
        if pr["rule"].get("rule_type") not in (
            "output_blocklist", "param_blocklist", "taint_block"
        ):
            return False
        if not pr["rule"].get("output_modifications"):
            return False
        return True

    def _activate_session_grants(self, minimum_cover: list) -> list:
        """Write high-confidence rules to grants/session/ for immediate effect.

        Session grants:
          - Are loaded by mcp_server alongside permanent grants
          - Carry _session_only: true so finalize_session() can find and
            delete them without touching permanent grants
          - Never written to learned_rules.json (not permanent knowledge)

        Returns list of Path objects written.
        """
        session_dir = Path.home() / ".k9log" / "grants" / "session"
        session_dir.mkdir(parents=True, exist_ok=True)
        now     = datetime.now(timezone.utc).isoformat()
        written = []

        for pr in minimum_cover:
            if not self._is_session_activatable(pr):
                continue

            rule    = pr["rule"]
            rule_id = rule["id"]
            scope   = {}

            rt = rule.get("rule_type", "")
            if rt in ("output_blocklist", "param_blocklist"):
                scope["output_constraints"] = rule.get("output_modifications", {})
                if rule.get("modifications"):
                    scope["param_constraints"] = rule["modifications"]
            elif rt == "taint_block":
                scope["deny_content"]       = rule.get("taint_evidence", [])
                scope["output_constraints"] = rule.get("output_modifications", {})

            if not scope:
                continue  # nothing enforceable

            grant = {
                "grant_id":    rule_id,
                "description": rule["description"],
                "scope":       scope,
                "_session_only": True,            # ← cleanup marker
                "metalearning_metadata": {
                    "source":          "CausalMetaLearner.session",
                    "theory":          "Pearl Causal Hierarchy Rung 3",
                    "rule_type":       rt,
                    "causal_proof":    pr["causal_proof"],
                    "cut_point":       pr["cut_point"],
                    "root_step":       rule["root_step"],
                    "blocked_steps":   pr["blocked_steps"],
                    "false_positives": 0,
                    "fp_rate":         0.0,
                    "activated_at":    now,
                    "scope":           "session",   # expires at session end
                },
            }
            safe_id = (
                rule_id.replace(":", "-").replace("\\", "-")
                        .replace("/", "-").replace(" ", "_")
            )
            path = session_dir / f"{safe_id}.json"
            path.write_text(
                json.dumps(grant, indent=2, ensure_ascii=False), encoding="utf-8"
            )
            written.append(path)

        return written

    # ── Public API ───────────────────────────────────────────────
    def learn(self, write_grants=True, silent=False):
        if silent:
            import io, contextlib
            _buf = io.StringIO()
            with contextlib.redirect_stdout(_buf):
                return self._learn_inner(write_grants=write_grants)
        return self._learn_inner(write_grants=write_grants)

    def _learn_inner(self, write_grants=True):
        console.print("\n")
        console.print(Panel.fit(
            "[bold cyan]🧠 Causal Metalearning[/bold cyan]\n"
            "[dim]Pearl Causal Hierarchy — Rung 3[/dim]",
            border_style="cyan"
        ))

        console.print("\n[bold]Step 1 — Abduction[/bold]")
        incidents = self._extract_incidents()
        console.print(f"   Terminal incidents found: {len(incidents)}")
        for inc in incidents:
            ev_note = (
                f", evidence: {len(inc.get('taint_evidence', []))} term(s)"
                if inc.get("taint_evidence") else ""
            )
            console.print(
                f"   • Step #{inc['step']} — {inc['skill']} "
                f"(marker: '{inc['marker']}'{ev_note})"
            )

        if not incidents:
            console.print("   [green]No incidents. Nothing to learn.[/green]")
            return {"incidents": [], "candidates": [], "minimum_cover": [], "grants": []}

        console.print("\n[bold]Step 2 — Root Cause Trace[/bold]")
        for inc in incidents:
            roots = self._find_root_cause_steps(inc["step"])
            if roots:
                console.print(
                    f"   Incident Step #{inc['step']} ← "
                    f"root cause at Step #{roots[0]['step']} ({roots[0]['skill']})"
                )
            else:
                console.print(
                    f"   Incident Step #{inc['step']} ← "
                    f"no earlier root found, incident IS the root"
                )

        console.print("\n[bold]Step 3 — Intervention (candidate rules)[/bold]")
        candidates = self._enumerate_candidates(incidents)
        console.print(f"   Candidate rules: {len(candidates)}")
        for c in candidates:
            has_scope = bool(c.get("output_modifications") or c.get("taint_evidence"))
            scope_note = "[green]✓ scope[/green]" if has_scope else "[yellow]advisory[/yellow]"
            console.print(f"   • [{scope_note}] {c['id']}: {c['description']}")

        console.print("\n[bold]Step 4+5 — Counterfactual Prediction + Minimum Cover[/bold]")
        minimum_cover, all_proven = self._find_minimum_cover(incidents, candidates)
        console.print(f"   Causally effective: {len(all_proven)}/{len(candidates)}")
        console.print(f"   Minimum cover set:  {len(minimum_cover)} rule(s)")

        table = Table(show_header=True, header_style="bold")
        table.add_column("Rule", style="cyan")
        table.add_column("Type", style="dim")
        table.add_column("Root Step", justify="center")
        table.add_column("Cut Point", justify="center")
        table.add_column("FP / Rate", justify="center")
        table.add_column("Causal Proof", style="dim")
        for pr in minimum_cover:
            fp_rate = pr.get("fp_rate", 0.0)
            fp_color = "red" if fp_rate > _MAX_FP_RATE else "green"
            table.add_row(
                pr["rule"]["id"],
                pr["rule"].get("rule_type", "?"),
                f"#{pr['rule']['root_step']}",
                f"Step #{pr['cut_point']}" if pr["cut_point"] is not None else "—",
                f"[{fp_color}]{pr['false_positives']} / {fp_rate * 100:.1f}%[/{fp_color}]",
                pr["causal_proof"][:80],
            )
        console.print(table)

        # Warn about high-FP rules in the cover
        for pr in minimum_cover:
            if pr.get("fp_rate", 0.0) > _MAX_FP_RATE:
                console.print(
                    f"   [yellow]⚠ High FP rate on {pr['rule']['id']}: "
                    f"{pr['fp_rate'] * 100:.1f}% — review carefully before approving[/yellow]"
                )

        grants_written  = []
        session_written = []
        if write_grants and minimum_cover:
            # ── Step 6a: high-confidence → session/ (immediate effect) ──
            session_written = self._activate_session_grants(minimum_cover)
            if session_written:
                console.print("\n[bold]Step 6a — Session-Activated Grants (auto-expires)[/bold]")
                for p in session_written:
                    console.print(f"   [bold green]⚡[/bold green] {p.name}  [dim](session only)[/dim]")
                console.print(
                    "   [dim]These rules are active NOW and will be removed at session end.[/dim]"
                )

            # ── Step 6b: lower-confidence → suggested/ (human review) ──
            session_ids = {p.stem for p in session_written}
            pending = [
                pr for pr in minimum_cover
                if pr["rule"]["id"].replace(":", "-").replace("\\", "-")
                                   .replace("/", "-").replace(" ", "_")
                   not in session_ids
            ]
            if pending:
                console.print("\n[bold]Step 6b — Suggested Grants (needs approval)[/bold]")
                grants_written = self._write_suggested_grants(pending)
                for p in grants_written:
                    console.print(f"   [green]✅[/green] {p}")
                console.print("   [dim]Review with: k9log grants list[/dim]")
                console.print("   [dim]Activate with: k9log grants approve <id>[/dim]")

        console.print("\n[bold green]Metalearning complete.[/bold green]\n")
        return {
            "incidents":        incidents,
            "candidates":       candidates,
            "minimum_cover":    minimum_cover,
            "grants":           [str(g) for g in grants_written],
            "session_grants":   [str(g) for g in session_written],
        }


# ── Session cleanup (called by logger.finalize_session) ──────────────────────

def cleanup_session_grants() -> list:
    """Delete all grants marked _session_only: true from grants/session/.

    Called by logger.finalize_session() so session rules never outlive
    the session that created them.  Returns list of deleted file names.
    """
    session_dir = Path.home() / ".k9log" / "grants" / "session"
    if not session_dir.exists():
        return []
    deleted = []
    for gf in session_dir.glob("*.json"):
        try:
            data = json.loads(gf.read_text(encoding="utf-8"))
            if data.get("_session_only"):
                gf.unlink()
                deleted.append(gf.name)
        except Exception:
            pass   # never crash the host process on cleanup
    return deleted


def learn(log_file=None, write_grants=True):
    return CausalMetaLearner(log_file).learn(write_grants=write_grants)
