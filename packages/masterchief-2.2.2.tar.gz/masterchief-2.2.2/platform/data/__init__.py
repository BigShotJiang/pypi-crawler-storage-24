"""platform.data — Data upload & management package."""
