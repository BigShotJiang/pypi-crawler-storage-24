"""Data upload API blueprint for MasterChief.

Provides file upload, listing, deletion and stats endpoints at /api/v1/data.
"""

import hashlib
import json
import time
import uuid
from pathlib import Path

from flask import Blueprint, request, jsonify, send_file

data_bp = Blueprint('data_upload', __name__)

# ── Configuration ────────────────────────────────────────────────────────────
UPLOAD_ROOT = Path('data/uploads')
TRAINING_ROOT = Path('data/training')
VALID_PURPOSES = {'ingestion', 'training', 'evaluation', 'reference'}

ALLOWED_EXTENSIONS: dict[str, str] = {
    # data
    'json': 'data', 'jsonl': 'data', 'yaml': 'data', 'yml': 'data',
    'csv': 'data', 'tsv': 'data', 'xml': 'data', 'parquet': 'data',
    # text
    'txt': 'text', 'md': 'text', 'log': 'text', 'rst': 'text',
    # audio
    'wav': 'audio', 'mp3': 'audio', 'ogg': 'audio', 'flac': 'audio',
    # archive
    'zip': 'archive', 'tar': 'archive', 'gz': 'archive',
}

# In-memory file manifest (persisted to data/uploads/_manifest.json)
_manifest: list[dict] = []


# ── Helpers ──────────────────────────────────────────────────────────────────
def allowed_file(filename: str) -> str | None:
    """Return the category string if the file extension is allowed, else None."""
    if '.' not in filename:
        return None
    ext = filename.rsplit('.', 1)[1].lower()
    return ALLOWED_EXTENSIONS.get(ext)


def get_file_hash(filepath: str | Path, algo: str = 'sha256') -> str:
    """Return hex digest of file contents."""
    h = hashlib.new(algo)
    with open(filepath, 'rb') as f:
        for chunk in iter(lambda: f.read(8192), b''):
            h.update(chunk)
    return h.hexdigest()


def init_directories() -> None:
    """Create the upload & training directory trees."""
    for root in (UPLOAD_ROOT, TRAINING_ROOT):
        for sub in ('text', 'data', 'audio', 'archive'):
            (root / sub).mkdir(parents=True, exist_ok=True)


def _load_manifest() -> None:
    global _manifest
    mf = UPLOAD_ROOT / '_manifest.json'
    if mf.exists():
        try:
            _manifest = json.loads(mf.read_text(encoding='utf-8'))
        except Exception:
            _manifest = []


def _save_manifest() -> None:
    mf = UPLOAD_ROOT / '_manifest.json'
    mf.parent.mkdir(parents=True, exist_ok=True)
    mf.write_text(json.dumps(_manifest, indent=2), encoding='utf-8')


# ── Routes ───────────────────────────────────────────────────────────────────
@data_bp.route('/upload', methods=['POST'])
def upload_file():
    """Upload a file for ingestion or training."""
    init_directories()

    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400

    f = request.files['file']
    if not f.filename:
        return jsonify({'error': 'No file selected'}), 400

    category = allowed_file(f.filename)
    if category is None:
        return jsonify({'error': f'File type not allowed: {f.filename}'}), 400

    purpose = request.form.get('purpose', 'ingestion')
    if purpose not in VALID_PURPOSES:
        return jsonify({'error': f'Invalid purpose: {purpose}. Must be one of {VALID_PURPOSES}'}), 400

    description = request.form.get('description', '')
    metadata_raw = request.form.get('metadata')
    custom_meta = {}
    if metadata_raw:
        try:
            custom_meta = json.loads(metadata_raw)
        except Exception:
            pass

    # Determine target directory
    root = TRAINING_ROOT if purpose == 'training' else UPLOAD_ROOT
    dest_dir = root / category
    dest_dir.mkdir(parents=True, exist_ok=True)

    # Save with unique prefix
    safe_name = f"{uuid.uuid4().hex[:8]}_{f.filename}"
    dest_path = dest_dir / safe_name
    f.save(str(dest_path))

    file_hash = get_file_hash(dest_path)
    rel_path = str(dest_path.relative_to(Path('.')))

    entry = {
        'id': uuid.uuid4().hex,
        'filename': f.filename,
        'path': rel_path,
        'category': category,
        'purpose': purpose,
        'description': description,
        'metadata': custom_meta,
        'size': dest_path.stat().st_size,
        'hash': file_hash,
        'uploaded_at': time.time(),
    }
    _manifest.append(entry)
    _save_manifest()

    return jsonify({'success': True, 'file': entry}), 201


@data_bp.route('/files', methods=['GET'])
def list_files():
    """List uploaded files, optionally filtered by purpose or category."""
    _load_manifest()
    purpose = request.args.get('purpose')
    category = request.args.get('category')

    filtered = _manifest
    if purpose:
        filtered = [f for f in filtered if f.get('purpose') == purpose]
    if category:
        filtered = [f for f in filtered if f.get('category') == category]

    return jsonify({'success': True, 'files': filtered, 'total': len(filtered)})


@data_bp.route('/files/<path:file_path>', methods=['GET'])
def get_file(file_path):
    """Get file metadata or download."""
    _load_manifest()
    entry = next((f for f in _manifest if f.get('path') == file_path), None)
    if not entry:
        return jsonify({'error': 'File not found'}), 404

    if request.args.get('metadata') == 'true':
        return jsonify({'success': True, 'metadata': entry})

    fpath = Path(file_path)
    if fpath.exists():
        return send_file(str(fpath.resolve()))
    return jsonify({'error': 'File not found on disk'}), 404


@data_bp.route('/files/<path:file_path>', methods=['DELETE'])
def delete_file(file_path):
    """Delete an uploaded file."""
    _load_manifest()
    entry = next((f for f in _manifest if f.get('path') == file_path), None)
    if not entry:
        return jsonify({'error': 'File not found'}), 404

    fpath = Path(file_path)
    if fpath.exists():
        fpath.unlink()

    _manifest.remove(entry)
    _save_manifest()
    return jsonify({'success': True, 'deleted': file_path})


@data_bp.route('/stats', methods=['GET'])
def get_stats():
    """Return upload statistics."""
    _load_manifest()
    total_size = sum(f.get('size', 0) for f in _manifest)
    by_category = {}
    for f in _manifest:
        cat = f.get('category', 'unknown')
        by_category[cat] = by_category.get(cat, 0) + 1

    return jsonify({
        'success': True,
        'stats': {
            'total_files': len(_manifest),
            'total_size': total_size,
            'by_category': by_category,
        }
    })
