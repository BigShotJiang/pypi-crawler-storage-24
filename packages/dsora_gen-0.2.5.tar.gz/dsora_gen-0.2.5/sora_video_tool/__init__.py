"""sora_video_tool — Tự động tạo video Sora theo batch với nhiều Chrome profiles."""

__version__ = "0.2.5"
