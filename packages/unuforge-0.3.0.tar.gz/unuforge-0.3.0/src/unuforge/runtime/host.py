from __future__ import annotations

import importlib

from .contracts import ForgeHost


def load_host(module_path: str) -> ForgeHost:
    module = importlib.import_module(module_path)
    host = getattr(module, "HOST", None)
    if host is None:
        raise ValueError(f"host module `{module_path}` must export HOST")
    return host
