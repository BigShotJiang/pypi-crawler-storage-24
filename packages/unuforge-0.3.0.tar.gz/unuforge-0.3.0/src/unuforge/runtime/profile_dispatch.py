from __future__ import annotations

from typing import Any

from .presets import manifest_path_from_preset


def resolve_preset_profile(preset: dict[str, Any], profile_name: str) -> dict[str, str]:
    surface = preset["surface_index"].get(profile_name)
    if not isinstance(surface, dict) or surface.get("type") != "profile":
        raise ValueError(f"unknown preset testing profile: {profile_name}")

    mapped = surface.get("target")
    if not isinstance(mapped, str) or not mapped.strip():
        raise ValueError(f"preset testing profile `{profile_name}` missing `target`")

    return {
        "manifest": str(manifest_path_from_preset(preset)),
        "profile": mapped.strip(),
    }
