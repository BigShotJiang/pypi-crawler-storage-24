from __future__ import annotations

from typing import Any

from .presets import repo_root_from_preset


def resolve_preset_action(preset: dict[str, Any], action_name: str) -> dict[str, str]:
    action = preset["surface_index"].get(action_name)
    if not isinstance(action, dict) or action.get("type") != "action":
        raise ValueError(f"unknown preset deployment action: {action_name}")

    impl = action.get("impl")
    if not isinstance(impl, str) or not impl.strip():
        raise ValueError(f"preset deployment action `{action_name}` missing `impl`")

    preset_root = repo_root_from_preset(preset)
    return {
        "name": action_name,
        "impl": str((preset_root / impl).resolve()),
    }
