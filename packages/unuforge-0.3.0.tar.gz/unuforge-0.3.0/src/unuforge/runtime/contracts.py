from __future__ import annotations

from typing import Literal, Protocol, TypedDict


class CommandExecution(TypedDict):
    runner: Literal["command"]
    command: list[str]
    cwd: str


class BundleExecution(TypedDict):
    runner: Literal["bundle"]
    bundle: str


ProfileExecution = CommandExecution | BundleExecution
ActionExecution = CommandExecution


class ForgeHost(Protocol):
    def build_profile_execution(
        self,
        preset_path: str,
        profile_name: str,
        passthrough_args: list[str] | None = None,
    ) -> ProfileExecution: ...

    def run_profile(
        self,
        preset_path: str,
        profile_name: str,
        passthrough_args: list[str] | None = None,
    ) -> int: ...

    def build_action_execution(
        self,
        preset_path: str,
        action_name: str,
        passthrough_args: list[str] | None = None,
    ) -> ActionExecution: ...

    def run_action(
        self,
        preset_path: str,
        action_name: str,
        passthrough_args: list[str] | None = None,
    ) -> int: ...
