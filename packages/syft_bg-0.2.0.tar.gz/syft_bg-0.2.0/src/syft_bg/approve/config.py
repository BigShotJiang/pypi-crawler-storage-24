"""Configuration for the approval service."""

from pathlib import Path
from typing import Optional

import yaml
from pydantic import BaseModel, Field

from syft_bg.common.config import get_default_paths


class ScriptRule(BaseModel):
    """A single approved script with its expected hash."""

    name: str
    hash: str


class PeerApprovalEntry(BaseModel):
    """Configuration for a single peer's job approval."""

    mode: str = "strict"
    scripts: list[ScriptRule] = Field(default_factory=list)


# Backwards-compatible alias
PeerJobConfig = PeerApprovalEntry


class JobApprovalConfig(BaseModel):
    """Configuration for job auto-approval."""

    enabled: bool = True
    peers: dict[str, PeerApprovalEntry] = Field(default_factory=dict)


class PeerApprovalConfig(BaseModel):
    """Configuration for peer auto-approval."""

    enabled: bool = False
    approved_domains: list[str] = Field(default_factory=list)
    auto_share_datasets: list[str] = Field(default_factory=list)


class ApproveConfig(BaseModel):
    """Main configuration for the approval service."""

    do_email: Optional[str] = None
    syftbox_root: Optional[Path] = None
    drive_token_path: Optional[Path] = None
    interval: int = 5
    jobs: JobApprovalConfig = Field(default_factory=JobApprovalConfig)
    peers: PeerApprovalConfig = Field(default_factory=PeerApprovalConfig)

    @classmethod
    def load(cls, config_path: Optional[Path] = None) -> "ApproveConfig":
        """Load configuration from YAML file."""
        if config_path is None:
            config_path = get_default_paths().config
        else:
            config_path = Path(config_path).expanduser()

        if not config_path.exists():
            return cls()

        with open(config_path) as f:
            data = yaml.safe_load(f) or {}

        common = {k: v for k, v in data.items() if not isinstance(v, dict)}
        approve_section = data.get("approve", {})

        jobs_data = approve_section.get("jobs", {})
        peers_data = approve_section.get("peers", {})

        return cls(
            do_email=common.get("do_email"),
            syftbox_root=Path(common["syftbox_root"]).expanduser()
            if common.get("syftbox_root")
            else None,
            drive_token_path=Path(common["drive_token_path"]).expanduser()
            if common.get("drive_token_path")
            else None,
            interval=approve_section.get("interval", 5),
            jobs=JobApprovalConfig(**jobs_data) if jobs_data else JobApprovalConfig(),
            peers=PeerApprovalConfig(**peers_data)
            if peers_data
            else PeerApprovalConfig(),
        )

    def save(self, config_path: Optional[Path] = None) -> None:
        """Save configuration to YAML file."""
        if config_path is None:
            config_path = get_default_paths().config
        else:
            config_path = Path(config_path).expanduser()

        config_path.parent.mkdir(parents=True, exist_ok=True)

        data = {}
        if config_path.exists():
            with open(config_path) as f:
                data = yaml.safe_load(f) or {}

        if self.do_email:
            data["do_email"] = self.do_email
        if self.syftbox_root:
            data["syftbox_root"] = str(self.syftbox_root)
        if self.drive_token_path:
            data["drive_token_path"] = str(self.drive_token_path)

        data["approve"] = {
            "interval": self.interval,
            "jobs": self.jobs.model_dump(),
            "peers": self.peers.model_dump(),
        }

        with open(config_path, "w") as f:
            yaml.dump(data, f, default_flow_style=False, sort_keys=False)
