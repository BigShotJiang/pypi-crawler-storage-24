"""Data types."""

from typing import Any, Literal, TypedDict

type Params = dict[str, Any]
type Severity = Literal['blocker', 'critical', 'normal', 'minor', 'trivial']


class Metadata(TypedDict, total=False):
    """Metadata dictionary."""

    params: Params | None

    tags: list[str] | None

    epic: str | None
    feature: str | None
    story: str | None
    severity: Severity | None
    id: str | None
    suite: str | None
    parent: str | None

    issues: list[str] | None
    links: list[str] | None
