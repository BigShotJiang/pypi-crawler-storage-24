"""Allure test collection module.

This module provides the AllureCollector class that integrates with Allure
reporting framework to collect and track test case and step information,
including metadata, parameters, descriptions, and execution results.

The collector manages the lifecycle of tests and steps using a context stack
and provides methods to enter/exit test cases and steps with support for:
- Test titles and descriptions (with Markdown support)
- Test metadata (tags, epic, feature, story, severity, id)
- Test parameters with context
- Step descriptions
- Exception tracking during execution
"""

from collections import deque
from os import linesep
from typing import TYPE_CHECKING

from allure_commons import plugin_manager as allure
from allure_commons.types import LabelType, LinkType

from .data import Metadata  # noqa: TC001
from .tracker import ContextTracker

try:
    from markdown import markdown
    HAS_MARKDOWN_SUPPORT = True
except ImportError:
    HAS_MARKDOWN_SUPPORT = False

if TYPE_CHECKING:
    from types import TracebackType
    from typing import Any

if TYPE_CHECKING:
    from pytest_loco.core import NodeType

#: Mapping of metadata field names to Allure LabelType constants.
#: Used for applying metadata labels to test cases in Allure reports.
LABELS = {
    'epic': LabelType.EPIC,
    'feature': LabelType.FEATURE,
    'story': LabelType.STORY,
    'severity': LabelType.SEVERITY,
    'id': LabelType.ID,
    'suite': LabelType.SUITE,
    'parent': LabelType.PARENT_SUITE,
}


class AllureCollector(ContextTracker):
    """Collects test and step information for Allure reporting.

    Manages the lifecycle of test cases and steps, integrating with Allure
    reporting system to track metadata, parameters, and execution results.
    """

    def __init__(self) -> None:
        """Initialize the AllureCollector."""
        super().__init__()

        self._description: deque[str] = deque()
        self._sections: deque[str] = deque()

    def write_description(self, description: str | None) -> None:
        """Append description to the description queue.

        Args:
            description: Text to append to the description queue. If None or
                empty, the description is not added.
        """
        if not description:
            return

        self._description.append(description)

    def write_section_title(self, title: str | None) -> None:
        """Add a section title to the sections queue.

        Section titles are formatted as Markdown headers (if markdown support
        is available) or plain text with a colon suffix.

        Args:
            title: Section title text. If None or empty, no title is added.
        """
        if not title:
            return

        self._sections.append(
            '#' * (self.current_depth + 1) + f' {title}'
            if HAS_MARKDOWN_SUPPORT
            else f'{title}:',
        )

    def write_section_description(self, description: str | None) -> None:
        """Add a section description to the sections queue.

        Args:
            description: Section description text. If None or empty, no
                description is added.
        """
        if not description:
            return

        self._sections.append(description)

    def save(self) -> str:
        """Compile and return accumulated description text.

        This method combines all accumulated sections into the description
        queue, clears both queues, and returns the final description text
        with sections joined by line separators.

        Returns:
            The compiled description text with all sections joined by OS-specific
                line separators.
        """
        self.write_description(linesep.join(self._sections))

        result = linesep.join(self._description)

        self._description.clear()
        self._sections.clear()

        return result

    def enter_case(self, title: str | None = None,
                   description: str | None = None,
                   metadata: Metadata | None = None) -> None:
        """Start a new test case execution.

        Args:
            title: Test case title.
            description: Test case description.
            metadata: Test case metadata containing parameters, issues, links,
                tags, and other case-specific attributes.
        """
        allure.hook.start_test(
            parent_uuid=None,
            uuid=self.enter(),
            name=None,
            parameters=None,
            context=None,
        )

        allure.hook.add_title(test_title=title)

        self.write_description(description)

        if metadata:
            if params := metadata.get('params'):
                for param, value in params.items():
                    allure.hook.add_parameter(param, str(value), excluded=None, mode=None)
            if issues := metadata.get('issues'):
                for issue in issues:
                    allure.hook.add_link(url=issue, link_type=LinkType.ISSUE, name=None)
            if links := metadata.get('links'):
                for link in links:
                    allure.hook.add_link(url=link, link_type=LinkType.LINK, name=None)
            if tags := metadata.get('tags'):
                allure.hook.add_label(label_type=LabelType.TAG, labels=tags)
            for field, label_type in LABELS.items():
                if value := metadata.get(field):
                    allure.hook.add_label(label_type=label_type, labels=(value,))

    def enter_step(self, title: str | None = None,
                   description: str | None = None) -> None:
        """Start a new step/check execution.

        Args:
            title: Node title.
            description: Node description.
        """
        allure.hook.start_step(
            uuid=self.enter(),
            title=title,
            params={},
        )

        if title and description:
            self.write_section_title(title)
            self.write_section_description(description)

    def enter_node(self, node_type: NodeType, *,
                   title: str | None = None, description: str | None = None,
                   context: dict[str, Any] | None = None,  # noqa: ARG002
                   metadata: Metadata | None = None) -> None:
        """Start a new node execution.

        Args:
            node_type: Node type.
            title: Node title.
            description: Node description.
            context: Current context.
            metadata: Node metadata.
        """
        if node_type == 'case':
            self.enter_case(title, description, metadata)
        else:
            self.enter_step(title, description)

    def exit_case(self, exc_type: type[Exception] | None = None,
                  exc_val: Exception | None = None,
                  exc_tb: TracebackType | None = None) -> None:
        """Stop the current case execution.

        Args:
            exc_type: Exception type.
            exc_val: Exception.
            exc_tb: Traceback.
        """
        description = self.save()

        if HAS_MARKDOWN_SUPPORT:
            description = markdown(description, output_format='html')
            allure.hook.add_description_html(test_description_html=description)
        else:
            allure.hook.add_description(test_description=description)

        allure.hook.stop_test(
            parent_uuid=None,
            uuid=self.exit(),
            name=None,
            context=None,
            exc_type=exc_type,
            exc_val=exc_val,
            exc_tb=exc_tb,
        )

    def exit_step(self, exc_type: type[Exception] | None = None,
                  exc_val: Exception | None = None,
                  exc_tb: TracebackType | None = None) -> None:
        """Stop the current node execution.

        Args:
            exc_type: Exception type.
            exc_val: Exception.
            exc_tb: Traceback.
        """
        allure.hook.stop_step(
            uuid=self.exit(),
            exc_type=exc_type,
            exc_val=exc_val,
            exc_tb=exc_tb,
        )

    def exit_node(self, node_type: NodeType, *,
                  error: Exception | None = None) -> None:
        """Stop the current node execution.

        Args:
            node_type: Node type.
            error: Exception raised during node execution, if any.
        """
        exc_type = exc_val = exc_tb = None
        if error:
            exc_type = type(error)
            exc_val = error
            exc_tb = error.__traceback__

        if node_type == 'case':
            self.exit_case(exc_type, exc_val, exc_tb)
        else:
            self.exit_step(exc_type, exc_val, exc_tb)
