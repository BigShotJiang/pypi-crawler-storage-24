"""Context tracking utilities for pytest-loco-allure."""

from collections import deque
from contextlib import contextmanager
from typing import TYPE_CHECKING
from uuid import uuid4

if TYPE_CHECKING:
    from collections.abc import Iterator


class ContextTracker:
    """Manages a stack of context node identifiers.

    This class tracks nested contexts using unique identifiers,
    allowing for context entry and exit operations with scope management.
    """

    def __init__(self) -> None:
        """Initialize the ContextTracker with an empty stack."""
        self._stack: deque[str] = deque()

    def enter(self) -> str:
        """Enter a new context and add it to the stack.

        Returns:
            str: Unique identifier for the new context.
        """
        node_id = str(uuid4())
        self._stack.append(node_id)

        return node_id

    def exit(self) -> str:
        """Exit the current context and remove it from the stack.

        Returns:
            str: The identifier of the exited context.

        Raises:
            IndexError: If the stack is empty.
        """
        return self._stack.pop()

    @property
    def current_depth(self) -> int:
        """Stack depth."""
        return len(self._stack)

    @contextmanager
    def scope(self) -> Iterator[str]:
        """Context manager for automatic context entry and exit.

        Yields:
            str: Unique identifier for the context scope.
        """
        try:
            yield self.enter()
        finally:
            self.exit()
