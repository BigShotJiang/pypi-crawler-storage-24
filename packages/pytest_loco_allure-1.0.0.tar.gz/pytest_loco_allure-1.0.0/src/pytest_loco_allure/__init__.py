"""Allure test collection module.

This module provides the AllureCollector class that integrates with Allure
reporting framework to collect and track test case and step information,
including metadata, parameters, descriptions, and execution results.

The collector manages the lifecycle of tests and steps using a context stack
and provides methods to enter/exit test cases and steps with support for:
- Test titles and descriptions (with Markdown support)
- Test metadata (tags, epic, feature, story, severity, id)
- Test parameters with context
- Step descriptions
- Exception tracking during execution
"""

from .collector import AllureCollector

__all__ = [
    'AllureCollector',
]
