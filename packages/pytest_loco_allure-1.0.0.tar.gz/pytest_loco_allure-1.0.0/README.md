# pytest-loco-allure

Allure support for `pytest-loco`.

## Install

```sh
> pip install "pytest-loco-allure[markdown]"
```

Requirements:
- Python 3.13 or higher

## Documentation

See https://pytest-loco.readthedocs.io/en/latest/integrations/allure.html

## Thanks

- [Allure Pytest](https://allurereport.org/docs/pytest/)
