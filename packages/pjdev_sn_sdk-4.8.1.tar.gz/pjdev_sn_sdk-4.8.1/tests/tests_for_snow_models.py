import pytest
from pydantic import Field, ValidationError
from pjdev_sn_sdk.models import SnowBase


class TestSnowBaseValidation:
    """Test that SnowBase models validate by alias names."""

    def test_validates_by_alias_name(self):
        """Test that a model can be instantiated using alias names."""
        class TestModel(SnowBase):
            display_value: str = Field(alias="u_display_value")

        # Should work with alias name
        model = TestModel(sys_id="123", u_display_value="test")
        assert model.display_value == "test"
        assert model.sys_id == "123"

    def test_validates_by_field_name(self):
        """Test that a model can still be instantiated using field names."""
        class TestModel(SnowBase):
            display_value: str = Field(alias="u_display_value")

        # Should also work with field name due to validate_by_name=True
        model = TestModel(sys_id="123", display_value="test")
        assert model.display_value == "test"
        assert model.sys_id == "123"

    def test_validates_both_alias_and_field_name(self):
        """Test that both alias and field name can be used together."""
        class TestModel(SnowBase):
            field_one: str = Field(alias="u_field_one")
            field_two: str = Field(alias="u_field_two")

        # Mix of alias and field names
        model = TestModel(sys_id="123", u_field_one="value1", field_two="value2")
        assert model.field_one == "value1"
        assert model.field_two == "value2"

    def test_extra_fields_ignored(self):
        """Test that extra fields are ignored due to extra='ignore'."""
        class TestModel(SnowBase):
            display_value: str = Field(alias="u_display_value")

        # Should not raise error with extra fields
        model = TestModel(sys_id="123", u_display_value="test", extra_field="ignored")
        assert model.display_value == "test"
        assert not hasattr(model, "extra_field")

    def test_multiple_aliased_fields(self):
        """Test validation with multiple aliased fields."""
        class TestModel(SnowBase):
            name: str = Field(alias="u_name")
            description: str = Field(alias="u_description")
            status: str = Field(alias="u_status")

        # All aliases
        model = TestModel(
            sys_id="123",
            u_name="Test Name",
            u_description="Test Description",
            u_status="active"
        )
        assert model.name == "Test Name"
        assert model.description == "Test Description"
        assert model.status == "active"

    def test_get_fields_returns_aliases(self):
        """Test that get_fields() returns alias names when defined."""
        class TestModel(SnowBase):
            display_value: str = Field(alias="u_display_value")
            regular_field: str

        fields = TestModel.get_fields()
        assert "sys_id" in fields
        assert "u_display_value" in fields  # alias
        assert "regular_field" in fields  # no alias

    def test_get_df_column_rename_map(self):
        """Test that the DataFrame column rename map correctly maps aliases to field names."""
        class TestModel(SnowBase):
            display_value: str = Field(alias="u_display_value")
            regular_field: str

        rename_map = TestModel.get_df_column_rename_map()
        assert rename_map["u_display_value"] == "display_value"
        assert rename_map["regular_field"] == "regular_field"
        assert rename_map["sys_id"] == "sys_id"

    def test_validate_by_name_enabled(self):
        """Test that validate_by_name config is enabled and field names work."""
        class TestModel(SnowBase):
            custom_field: str = Field(alias="u_custom")

        # Create with field name (not alias)
        model = TestModel(sys_id="123", custom_field="test_value")
        assert model.custom_field == "test_value"

        # Verify the config is set correctly
        assert TestModel.model_config["validate_by_name"] is True

    def test_validate_by_alias_enabled(self):
        """Test that validate_by_alias config is enabled and alias names work."""
        class TestModel(SnowBase):
            custom_field: str = Field(alias="u_custom")

        # Create with alias name (not field name)
        model = TestModel(sys_id="123", u_custom="test_value")
        assert model.custom_field == "test_value"

        # Verify the config is set correctly
        assert TestModel.model_config["validate_by_alias"] is True
