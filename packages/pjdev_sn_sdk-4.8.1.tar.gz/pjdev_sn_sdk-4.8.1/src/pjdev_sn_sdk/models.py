import enum
from pathlib import Path

from pydantic import BaseModel, computed_field, ConfigDict
from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import Dict, List, Optional

class ServiceNowEnvironment(enum.StrEnum):
    PJ = "pj"
    SubProd1 = "subprod1"
    Dev = "dev"
    Test = "test"
    PreProd = "preprod"
    Prod = "prod"


class SnowTables(BaseModel):
    auth_boundary_table_name: str = "sn_irm_cont_auth_authorization_boundary"
    auth_pack_table_name: str = "sn_irm_cont_auth_pack"
    info_type_definition_table_name: str = (
        "sn_irm_cont_auth_information_type_definition"
    )
    info_type_table_name: str = "sn_irm_cont_auth_information_type"
    baseline_control_table_name: str = "sn_irm_cont_auth_baseline_control_objective"
    nist_control_table_name: str = "sn_grc_content"
    control_table_name: str = "sn_compliance_control"
    control_overlay_table_name: str = "sn_compliance_policy"
    control_objective_table_name: str = "sn_compliance_policy_statement"
    poam_issue_rating_table_name: str = "sn_grc_issue_rating"
    poam_table_name: str = "sn_grc_issue"
    poam_control_m2m_table_name: str = "sn_grc_m2m_issue_item"
    auth_pack_poam_m2m_table_name: str = "sn_irm_cont_auth_m2m_issue_auth_pack"
    milestone_table_name: str = "sn_irm_cont_auth_milestone_task"
    cmdb_ci_table_name: str = "cmdb_ci"
    cmdb_hardware: str = "cmdb_ci_hardware"
    control_parts_table: str = "sn_compliance_policy_stmt_requirement"
    control_objective_control_part_m2m_table: str = (
        "sn_compliance_m2m_policy_stmt_policy_stmt_rqmt"
    )
    item_generation_action_event_queue_table: str = "sn_grc_item_generation_action_event_queue"
    user_table: str = "sys_user"


snow_tables = SnowTables()


class Config(BaseSettings):
    scripted_api_base_path: str = "/api/sn_irm_cont_auth/auth_pack"
    http_retry_max_count: int = 1000
    http_retry_delay_seconds: int = 1
    environment: ServiceNowEnvironment = ServiceNowEnvironment.SubProd1
    api_key: Optional[str] = None
    api_username: Optional[str] = None
    api_password: Optional[str] = None
    output_path: Optional[Path] = None

    model_config = SettingsConfigDict(
        env_prefix="SN_",
        case_sensitive=False,
        extra="ignore",
    )

    @computed_field
    def sn_api_url(self) -> str:
        match self.environment:
            case ServiceNowEnvironment.PreProd:
                return "https://vaoitpreprod.servicenowservices.com"
            case ServiceNowEnvironment.SubProd1:
                return "https://vasubprod1.servicenowservices.com"
            case ServiceNowEnvironment.Prod:
                return "https://yourit.va.gov"
            case ServiceNowEnvironment.Dev:
                return "https://yourit-dev.va.gov"
            case ServiceNowEnvironment.Test:
                return "https://vaoittest.servicenowservices.com"
            case ServiceNowEnvironment.PJ:
                return "https://dev190624.service-now.com"


class RMFStep(enum.Enum):
    Prepare = 1
    Categorize = 8
    Select = 9
    Implement = 10
    Assess = 11
    Authorize = 12
    Monitor = 13


class SnowBase(BaseModel):
    sys_id: str

    @classmethod
    def get_fields(cls) -> List[str]:
        fields = []
        for k, fi in cls.model_fields.items():
            if fi.alias:
                fields.append(fi.alias)
            else:
                fields.append(k)
        return fields

    @classmethod
    def get_fields_query_param_value(cls) -> str:
        return ",".join(cls.get_fields())

    @classmethod
    def get_df_column_rename_map(cls) -> Dict[str, str]:
        original_cols = cls.get_fields()
        cols = [k for k in cls.model_fields.keys()]
        return dict(zip(original_cols, cols))

    model_config = ConfigDict(extra="ignore", validate_by_name=True, validate_by_alias=True, strict=False)


class SnowAuthPack(SnowBase):
    name: str
    number: str
    step: int
    authorization_date: Optional[str] = None
    next_authorization_date: Optional[str] = None
    authorization_comments: Optional[str] = None
    authorization_decision: Optional[str] = None
    ongoing_authorization: Optional[str] = None
