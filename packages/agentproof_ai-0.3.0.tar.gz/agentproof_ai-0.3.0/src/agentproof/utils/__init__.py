"""Utility helpers for agentproof."""

