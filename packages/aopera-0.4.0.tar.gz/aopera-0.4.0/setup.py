
from setuptools import setup, find_packages
 
setup(packages=find_packages(exclude=['example','test-script','test-unit']))
