"""
AOPERA initialization file
"""

#%% SETUP LOGGING
import logging
import os

class COLORS:
	GREEN = "\x1b[32;20m"
	BLUE = "\033[34m"
	YELLOW = "\x1b[33;20m"
	RED = "\x1b[31;20m"
	CYAN = '\033[36m'
	RESET = '\033[0m'

logfmt = COLORS.YELLOW + 'AOPERA %(levelname)s' + COLORS.RESET + ' in <%(funcName)s> : %(message)s\n'
ch = logging.StreamHandler()
ch.setLevel(logging.INFO)
ch.setFormatter(logging.Formatter(logfmt))

logger = logging.getLogger('aopera')
logger.addHandler(ch)

del logfmt, os, logging, ch, COLORS

#%% IMPORT MODULES
logger.debug('Load AOPERA library')

from . import utils
from . import zernike
from . import readconfig
from . import variance
from . import control
from . import turbulence
from . import aopsd
from . import shwfs
from . import ffwfs
from . import otfpsf
from . import photometry
from . import fiber
from . import simulation
from . import trajectory
