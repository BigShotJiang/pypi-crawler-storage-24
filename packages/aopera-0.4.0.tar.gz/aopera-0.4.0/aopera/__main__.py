#! /usr/bin/env python

import sys
import os
import numpy as np
from configparser import ConfigParser
from aopera.turbulence import Atmosphere
from aopera.control import RTC
from aopera.otfpsf import Pupil
from aopera.ffwfs import PWFS
from aopera.photometry import SourceScience, SourceWFS
from aopera.simulation import simulation

#%% PARSE ARGUMENTS
if sys.version_info < (3,8):
    import pkg_resources
    version_aopera = pkg_resources.get_distribution('aopera').version
else:
    from importlib.metadata import version
    version_aopera = version('aopera')

if len(sys.argv) == 2 and sys.argv[1] in ['help', '-h', '-help', '--help']:
    print()
    print('AOPERA %s'%version_aopera)
    print()
    print('Usage: python -m aopera [arguments]')
    print()
    print('Arguments:')
    print(f"  {'<file_atmo> <file_instru>':<28s} Run a simulation with the given file names")
    print(f"  {'help':<28s} Print this help")
    print(f"  {'list':<28s} List available atmospheres and instruments")
    exit()

if len(sys.argv) == 2 and sys.argv[1] == 'list':
    path = os.path.dirname(os.path.abspath(__file__)) + os.path.sep + 'data'
    files = [f for f in os.listdir(path) if f.endswith('.ini')]
    for f in files:
        config = ConfigParser()
        config.read(path+os.path.sep+f)
        print('%20s : '%f + ", ".join(('%s'%s for s in config.sections())))
    exit()

if (len(sys.argv) != 3):
    print('AOPERA %s'%version_aopera)
    exit()
  
#%% SIMULATION
file_atmo = sys.argv[1]
file_instru = sys.argv[2]
if not file_atmo.endswith('.ini'):
    file_atmo += '.ini'
if not file_instru.endswith('.ini'):
    file_instru += '.ini'

nx = 512
samp = 2

src_sci = SourceScience.from_file(file_instru)
src_wfs = SourceWFS.from_file(file_instru)
atm = Atmosphere.from_file(file_atmo)
tel = Pupil.from_file(file_instru)
rtc = RTC.from_file(file_instru)
wfs = PWFS.from_file(file_instru)

print()
psd, var, param = simulation(nx, samp, tel, atm, rtc, wfs, src_sci, src_wfs, verbose=True, fast=True)

psd_total = sum([psd[k] for k in psd.keys()])

psf_ao = tel.psf_ao(psd_total, samp)
psf_diff = tel.psf_diffraction(nx, samp)
strehl = 100 * np.max(psf_ao)/np.max(psf_diff)

wvl_ratio = src_sci.wvl/src_wfs.wvl
psf_ao_sci = tel.psf_ao(psd_total, samp, wvl_scale=wvl_ratio)
psf_diff_sci = tel.psf_diffraction(nx, samp*wvl_ratio)
strehl_sci = 100 * np.max(psf_ao_sci)/np.max(psf_diff_sci)

print()
print('Strehl at %4u nm : %5.1f %%'%(src_wfs.wvl_nm, strehl))
print('Strehl at %4u nm : %5.1f %%'%(src_sci.wvl_nm, strehl_sci))

import matplotlib.pyplot as plt
from matplotlib.colors import SymLogNorm

def setplt(tab):
    plt.imshow(tab, norm=SymLogNorm(1e-6, vmin=0, vmax=1), cmap='Spectral_r')
    plt.colorbar(orientation='horizontal')
    plt.axis('off')

plt.figure()
plt.subplot(121)
plt.title('PSF at %u nm'%src_wfs.wvl_nm)
setplt(psf_ao/psf_diff.max())
plt.subplot(122)
plt.title('PSF at %u nm'%src_sci.wvl_nm)
setplt(psf_ao_sci/psf_diff_sci.max())
plt.show()
plt.pause(0.01)
