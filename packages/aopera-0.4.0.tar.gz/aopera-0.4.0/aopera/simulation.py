"""
Gathers all classes from the library to run a simulation
"""

import os
import numpy as np
from scipy.interpolate import RegularGridInterpolator
import logging
from aopera.utils import arcsec2rad, print_std, rfftconvolve
from aopera.aopsd import psd_temporal, psd_anisoplanetism, psd_anisoplanetism_extended_object, piston_filter, psd_ncpa, psd_chromatic_filter, air_refractive_index
from aopera.turbulence import Atmosphere
from aopera.otfpsf import Pupil
from aopera.photometry import SourceScience, SourceWFS
from aopera.shwfs import SHWFS
from aopera.ffwfs import PWFS, PerfectWFS
from aopera.control import RTC
from aopera.readconfig import read_config_tiptop_nx, read_config_tiptop_samp
from aopera.zernike import zernike_fourier
from aopera.variance import var_temporal

logger = logging.getLogger('aopera')

class TiptopBaseSimulation:
    """Implement baseSimulation from Tiptop"""
    def __init__(self, path, parametersFile, verbose=False):
        self.path = path
        self.parametersFile = parametersFile
        self.verbose = verbose
        
    def doOverallSimulation(self):
        file_ini = os.path.join(self.path, self.parametersFile + '.ini')
        src_sci = SourceScience.from_file_tiptop(file_ini)
        src_wfs = SourceWFS.from_file_tiptop(file_ini)
        atm = Atmosphere.from_file_tiptop(file_ini)
        pupil = Pupil.from_file_tiptop(file_ini)
        rtc = RTC.from_file_tiptop(file_ini)
        try:
            wfs = PWFS.from_file_tiptop(file_ini)
        except:
            wfs = SHWFS.from_file_tiptop(file_ini)
        nx = read_config_tiptop_nx(file_ini)
        samp = read_config_tiptop_samp(file_ini)
        psd, var, param = simulation(nx, samp, pupil, atm, rtc, wfs, src_sci, src_wfs, verbose=self.verbose, split_fit_temp=True, fast=True)
        psd_total = sum([psd[k] for k in psd.keys()])
        wvl_ratio = src_sci.wvl/src_wfs.wvl
        psf_ao_sci = pupil.psf_ao(psd_total, samp, wvl_scale=wvl_ratio)
        psf_diff_sci = pupil.psf_diffraction(nx, samp*wvl_ratio)
        
        df = pupil.frequency_step(samp)
        self.PSDstep = df
        self.N = nx
        self.PSD = psd_total * (src_wfs.wvl_nm/(2*np.pi))**2 * df**2 # Tiptop PSD has units of [nm²]
        self.sr = [np.max(psf_ao_sci)/np.max(psf_diff_sci)]
        self.cubeResultsArray = np.zeros((1, nx, nx))
        self.cubeResultsArray[0,...] = psf_ao_sci
        
    @property
    def cubeResults(self):
        try:
            return list(self.cubeResultsArray)
        except: # not computed yet
            pass
        
    def computeMetrics(self):
        raise NotImplementedError()
    
    

def simulation(nx, samp, *args, verbose=False, split_fit_temp=False, split_layers=False, nb_iter_og=None, fast=True):
    """
    Run a full AO simulation
    
    Parameters
    ----------
    nx : int
        Number of pixels for output arrays.
    samp : float
        Sampling of the PSF at the WFS wavelength.
    *args :
        Must include a Pupil, Atmosphere, WFS, RTC, SourceWFS, SourceScience.
    
    Keywords
    --------
    verbose : bool (False)
        Activate verbose mode.
    split_fit_temp : bool (False)
        Split fitting and temporal error for the returned PSD dictionary.
    split_layers : bool (False)
        Split contribution of each layer within the returned PSD dictionary.
    nb_iter_og : int (None)
        Number of iterations for OG computation.
    fast : bool (True)
        Faster computations (but slightly less precise) especially for noise PSD.
    
    Returns
    -------
    psd : dictionary
        The PSD list [rad²m²].
    var : dictionary
        The variance list [rad²].
    param : dictionary
        Some intermediate values.
    """
    
    ### PARSE INPUTS, whatever the order
    for a in args:
        if isinstance(a, Atmosphere):
            atm = a
        if isinstance(a, Pupil):
            tel = a
        if isinstance(a, SourceScience):
            src_sci = a
        if isinstance(a, SourceWFS):
            src_wfs = a
        if isinstance(a, PWFS) or isinstance(a, PerfectWFS) or isinstance(a, SHWFS):
            wfs = a
        if isinstance(a, RTC):
            rtc = a
            
    for v in ['atm','tel','src_sci','src_wfs','wfs','rtc']:
        if not v in locals():
            raise ValueError('You forgot to define one of the arguments')
    
    if isinstance(wfs, SHWFS):
        #FIXME: SH-WFS should be managed directly inside <simulation>
        return simulation_shwfs(nx, samp, *args, verbose=verbose)
    
    ### INITIALIZE SIMULATION
    fx,fy = tel.frequency_grid(nx, samp)
    df = tel.frequency_step(samp) # numerical frequency step [1/m]
    freq = np.sqrt(fx**2+fy**2)
    pstflt = piston_filter(freq, tel.diameter) # filter low freq
    obj = src_wfs.image(nx, tel.diameter, samp)
    psf_diff = tel.psf_diffraction(nx, samp)
    dm = tel.controllability(fx, fy)
    pix = tel.diameter / wfs.lenslet # WFS pixel size in meter in the pupil plane
    pixflt = np.sinc(fx*pix) * np.sinc(fy*pix)
    psd_atmo = atm.phase_psd(freq, src_wfs.wvl, zenith=src_sci.zenith_rad)
    fx1d = (np.arange(nx)-nx//2) * tel.frequency_step(samp)
    
    ### CALIBRATE and BUILD RECONSTRUCTOR
    sensi_discrete_calib = wfs.sensitivity_ron(samp, psf_diff, psf_diff) * pixflt
    interaction_matrix = dm*sensi_discrete_calib
    reconstructor = rtc.reconstructor(interaction_matrix)
    aomskin = np.abs(reconstructor*interaction_matrix) > 0.5
    
    ### LOOP ON OPTICAL GAINS (start at diffraction limit sensitivity)
    if nb_iter_og is None:
        if fast:
            nb_iter_og = 3
        else:
            nb_iter_og = 4
        
    sensi_discrete_sky = sensi_discrete_calib
    og = np.ones((nx,nx))
    og_avg = 1
    modal_gain_compensation = 1
    
    for i_og in range(nb_iter_og):
        
        if not split_layers:
            psd = {k:np.zeros((nx,nx)) for k in ['spatiotemporal', 'aliasing']}
        else:
            psd = {k:np.zeros((nx,nx)) for k in ['aliasing'] + ['spatiotemporal_%u'%i for i in range(atm.nlayer)]}
        
        ### APPLY OG COMPENSATION
        if wfs.og_compensation:
            modal_gain_compensation = 1/og
        
        ### FITTING + TEMPORAL ERROR
        for i in range(atm.nlayer):
            wnd_angle = atm.wind_direction[i] * np.pi/180
            nu = (fx*np.cos(wnd_angle)+fy*np.sin(wnd_angle))*atm.wind_speed[i]
            openloop = rtc.open_loop_transfer(nu) * modal_gain_compensation
            psd_layer = atm.cn2dh_ratio[i]*psd_atmo
            if not split_layers:
                keyname = 'spatiotemporal'
            else:
                keyname = 'spatiotemporal_%u'%i
            psd[keyname] += psd_layer/np.abs(1+dm*sensi_discrete_sky*reconstructor*openloop)**2
            
        if rtc.predictive_factor != 1:
            #FIXME: better implementation of predictive controller
            logger.debug('Use better implementation of predictive controller.')
            for k in psd.keys():
                if k.startswith('spatiotemporal'):
                        psd[k][aomskin] *= rtc.predictive_factor
            
        ### NOISE PSD
        ft = np.logspace(-4, np.log10(rtc.freq/2), num=1000)
        openloop = rtc.open_loop_transfer(ft)
        if fast: # separate spatial and temporal effects
            ntf_1d = np.abs(openloop/(1+np.mean((og*modal_gain_compensation)[aomskin])*openloop))**2
            ntf_2d = np.trapezoid(ntf_1d, ft) * 2/rtc.freq
            ntf_2d *= aomskin / sensi_discrete_calib**2
        else: # general case
            omega_3d = (dm*reconstructor*modal_gain_compensation)[:,:,None] * openloop[None, None, :]
            ntf_3d = np.abs(omega_3d/(1+omega_3d*sensi_discrete_sky[:,:,None]))**2
            ntf_2d = np.trapezoid(ntf_3d, ft, axis=-1) * 2/rtc.freq

        nphot = src_wfs.flux * tel.surface / rtc.freq # nb photon per frame
        fcut = 1/(2*pix)
        wfs_area = (np.abs(fx)<fcut)*(np.abs(fy)<fcut)
        
        if isinstance(wfs, PWFS):
            #FIXME: fudge factor on PWFS photon noise to match OOPAO.
            logger.debug('Fudge factor applied on the PWFS photon noise to match OOPAO.')
            photon_noise_factor = 2
        else:
            photon_noise_factor = 1 # perfect WFS does not need fudge factor... I think...
            
        var_phot = wfs_area / photon_noise_factor / nphot # 1/nphot = nphot/nphot² = var(I)/I²
        psd['photon'] = ntf_2d * var_phot * (1+wfs.emccd)

        nssp = np.pi*(wfs.lenslet/2)**2 # pourquoi pas x4 pour les 4 pupilles?
        var_ron = wfs_area * nssp * (wfs.ron/nphot)**2
        psd['ron'] = ntf_2d * var_ron
        
        ### ALIASING ERROR (ON THE SUM OF LAYERS -> APPROXIMATION)
        if split_layers:
            #FIXME: better management of aliasing for multiple layers
            logger.warning('Aliasing error is computed on the sum of atm layers')
        psd_spatiotemporal = np.sum([psd[k] for k in psd.keys() if k.startswith('spatiotemporal')], axis=0) 
        psd_to_be_aliased = RegularGridInterpolator((fx1d,fx1d), psd_spatiotemporal*sensi_discrete_sky**2, method='linear', bounds_error=False, fill_value=0)
        
        for i in range(-2,3):
            for j in range(-2,3):
                if (i!=0) or (j!=0):
                    fx_shift = fx - i*2*fcut
                    fy_shift = fy - j*2*fcut
                    psd_shift = psd_to_be_aliased((fx_shift,fy_shift))
                    psd['aliasing'] += ntf_2d * psd_shift
                    
        ### PSD ANISOPLANETISM MEASURE
        if (src_wfs.size > 0) and (max(atm.altitude) > 0):
            aniso_size = arcsec2rad(src_wfs.size) / (0.5*(np.sqrt(2)+1)) # avg between circle and square
            psd['aniso-mes'] = psd_anisoplanetism_extended_object(fx, fy, atm.cn2dh, atm.altitude, tel.pitch_ao(wfs.lenslet), src_wfs.wvl, aniso_size, src_alt=np.inf, src_zenith=src_sci.zenith_rad, lext=atm.lext, lint=0) * og_avg
        
        ### PSD JITTER
        psd.update(psd_jitter_common(nx, samp, tel, src_wfs, rtc))
        
        ### COMPUTE PSD TOTAL, PSF and OG
        psd_total = sum([psd[k] for k in psd.keys()])
        psf_ao = tel.psf_ao(psd_total, samp)
        
        if i_og < (nb_iter_og-1): # compute sensitivity for next iteration
            if (src_wfs.size==0):
                psf_onsky = psf_ao
            else:
                psf_onsky = rfftconvolve(psf_ao, obj)
            sensi_discrete_sky = wfs.sensitivity_ron(samp, psf_diff, psf_onsky, modu=wfs.modulation_sky) * pixflt
            og = sensi_discrete_sky/sensi_discrete_calib
            og_avg = np.mean(og[aomskin])
        
        ### VERBOSE
        if verbose:
            rad_to_nm = src_wfs.wvl*1e9/(2*np.pi)
            wfe = np.sqrt(np.sum(pstflt*psd_total)*df**2)*rad_to_nm
            print('[OG iter. %u/%u]   OG = %.2f   WFE = %3u nm'%(i_og+1, nb_iter_og, og_avg, wfe))
            
        
    ## SCIENCE ONLY TERMS after OG computation since it affects science only
    psd.update(psd_science_common(nx, samp, psd_atmo, aomskin, tel, atm, src_wfs, src_sci))
    
    ### RETURN
    param = {'r0_wfs':atm.r0(src_wfs.wvl,zenith=src_sci.zenith_rad),
             'og_avg':og_avg,
             'psf':psf_ao,
             'psd_atmo':psd_atmo}
    
    if split_fit_temp:
        # psd['fitting'] = psd['spatiotemporal']*(1-aomskin)
        # psd['temporal'] = psd['spatiotemporal']*aomskin
        # psd.pop('spatiotemporal')
        keyname = 'spatiotemporal'
        psd.update({k.replace(keyname,'fitting'):psd[k]*(1-aomskin) for k in psd.keys() if k.startswith(keyname)})
        psd.update({k.replace(keyname,'temporal'):psd[k]*aomskin for k in psd.keys() if k.startswith(keyname)})
        psd_keys_pop = [k for k in psd.keys() if k.startswith(keyname)]
        for k in psd_keys_pop:
            psd.pop(k)
        
    var = {}
    for k in psd.keys():
        if k in ['ncpa', 'photon', 'ron']:
            filt = 1 # these have already been filtered
        else:
            filt = pstflt
        var[k] = np.sum(filt*psd[k]*df**2)
        
    if verbose:
        rad_to_nm = src_wfs.wvl*1e9/(2*np.pi)
        std_nm = {k:rad_to_nm*np.sqrt(var[k]) for k in var.keys()}
        print()
        print('   WAVEFRONT ERROR [nm RMS]')
        print_std(std_nm)
    
    return psd, var, param



def simulation_shwfs(nx, samp, *args, verbose=False):
    """
    Run a full SH-WFS simulation
    
    Parameters
    ----------
    nx : int : number of pixels
    samp : float : sampling.
    *args : must include a Pupil, Atmosphere, SHWFS, RTC, SourceWFS, SourceScience
    
    Returns
    -------
    dictionary : the PSD list [rad²m²]
    dictionary : the variance list [rad²]
    dictionary : some intermediate values
    """
    
    ### PARSE INPUTS, whatever the order
    for a in args:
        if isinstance(a, Atmosphere):
            atm = a
        if isinstance(a, Pupil):
            tel = a
        if isinstance(a, SourceScience):
            src_sci = a
        if isinstance(a, SourceWFS):
            src_wfs = a
        if isinstance(a, SHWFS):
            wfs = a
        if isinstance(a, RTC):
            rtc = a
    
    for v in ['atm','tel','src_sci','src_wfs','wfs','rtc']:
        if not v in locals():
            raise ValueError('You forgot to define one of the arguments')
            
    ### INIT SOME STUFF
    df = tel.frequency_step(samp) # numerical frequency step [1/m]
    aocutoff = tel.cutoff_frequency(wfs.lenslet) # system AO cutoff [1/m]
    fx,fy = tel.frequency_grid(nx, samp)
    freq = np.sqrt(fx**2+fy**2)
    pstflt = piston_filter(freq, tel.diameter) # filter low freq
    aomskin = wfs.visibility(fx, fy, tel.diameter, thresh=1e-8) * tel.controllability(fx, fy)
    r0_wfs = atm.r0(src_wfs.wvl, zenith=src_sci.zenith_rad)
    nphot_subap = src_wfs.flux * tel.surface / rtc.freq / wfs.lenslet_valid(occ=tel.occultation)
    psdatmo = atm.phase_psd(freq, src_wfs.wvl, zenith=src_sci.zenith_rad)
    psd = {}
    
    ## PSD FITTING
    psd['fitting'] = psdatmo * (1-aomskin) * pstflt
    
    ### PSD ALIASING
    psd_to_alias = lambda fx,fy : atm.phase_psd(np.sqrt(fx**2+fy**2), src_wfs.wvl, zenith=src_sci.zenith_rad)
    psd['aliasing'] = wfs.psd_aliasing(fx, fy, tel.diameter, psd_to_alias) * aomskin
    
    ## PSD TEMPORAL
    psd['temporal'] = np.zeros((nx,nx))
    if rtc.predictive_factor != 1:
        logger.debug('Use better implementation of LQG.')
    for i in range(atm.nlayer):
        wnd_angle = atm.wind_direction[i]*np.pi/180
        psd_temp = aomskin * psd_temporal(fx, fy, atm.wind_speed[i], psdatmo, rtc.closed_loop_transfer, wnd_angle=wnd_angle)
        psd['temporal'] += psd_temp * atm.cn2dh_ratio[i] * rtc.predictive_factor #FIXME: better implementation of LQG
    
    ## PSD RON NOISE
    var_ron = wfs.var_ron(nphot_subap, tel.radial_max, rtc.bandwidth_noise, rtc.freq)
    psd['ron'] = wfs.psd_noise(fx, fy, aocutoff, var_ron, df, D=tel.diameter)
    
    ### PSD PHOTON NOISE
    spot_size = wfs.spot_fwhm(r0_wfs, tel.diameter, src_wfs.wvl, src_size=arcsec2rad(src_wfs.size))
    var_photon = wfs.var_photon(spot_size, nphot_subap, tel.radial_max, rtc.bandwidth_noise, rtc.freq)
    psd['photon'] = wfs.psd_noise(fx, fy, aocutoff, var_photon, df, D=tel.diameter)
    
    ## PSD ANISOPLANETISM MEASURE
    if (src_wfs.size > 0) and (max(atm.altitude) > 0):
        aniso_size = arcsec2rad(src_wfs.size) / (0.5*(np.sqrt(2)+1)) # avg between circle and square
        psd['aniso-mes'] = psd_anisoplanetism_extended_object(fx, fy, atm.cn2dh, atm.altitude, tel.pitch_ao(wfs.lenslet), src_wfs.wvl, aniso_size, src_alt=np.inf, src_zenith=src_sci.zenith_rad, lext=atm.lext, lint=0)
        
    ## PSD JITTER
    psd.update(psd_jitter_common(nx, samp, tel, src_wfs, rtc))
        
    ## SCIENCE ONLY TERMS
    psd.update(psd_science_common(nx, samp, psdatmo, aomskin, tel, atm, src_wfs, src_sci))
        
    ### GET VARIANCES
    var = {}
    for k in psd.keys():
        if k in ['ncpa', 'photon', 'ron']:
            filt = 1 # these have already been filtered
        else:
            filt = pstflt
        var[k] = np.sum(filt*psd[k]*df**2)
        
    if verbose:
        rad_to_nm = src_wfs.wvl*1e9/(2*np.pi)
        std_nm = {k:rad_to_nm*np.sqrt(var[k]) for k in var.keys()}
        print()
        print('   WAVEFRONT ERROR [nm RMS]')
        print_std(std_nm)
        
    ### RETURN
    param = {'r0_wfs':r0_wfs,
             'spot_fwhm':spot_size,
             'psd_atmo':psdatmo}
    return psd, var, param
    

def simulation_ffwfs(*args, **kwargs):
    raise DeprecationWarning('This function has been deprecated, use <aopera.simulation.simulation>')


def optimal_bandwidth_ffwfs(nx, samp, *args, og=1, verbose=False):
    """
    Optimize the global (not modal) integrator gain for a FF-WFS.
    Does not take into account OG for the optimization.
    
    Parameters
    ----------
    nx : int : number of pixels.
    samp : float : sampling of the PSF at the WFS wavelength.
    *args : must include a Pupil, Atmosphere, PWFS, RTC, SourceWFS, SourceScience.
    
    Keywords
    --------
    og = 1 : float : optical gains
    verbose = False : bool : activate verbose mode.
    
    Returns
    -------
    optimal integrator bandwidth
    """
    
    logger.warning('This function has not been tested yet')
    
    ### PARSE INPUTS, whatever the order
    for a in args:
        if isinstance(a, Atmosphere):
            atm = a
        if isinstance(a, Pupil):
            tel = a
        if isinstance(a, SourceScience):
            src_sci = a
        if isinstance(a, SourceWFS):
            src_wfs = a
        if isinstance(a, PWFS) or isinstance(a, PerfectWFS):
            wfs = a
        if isinstance(a, RTC):
            rtc = a
            
    for v in ['atm','tel','src_sci','src_wfs','wfs','rtc']:
        if not v in locals():
            raise ValueError('You forgot to define one of the arguments')
            
    r0 = atm.r0(src_wfs.wvl, zenith=src_sci.zenith_rad)
    bw_unit = 1 # place-holder to remember dependency wrt. BW within equations
    var_temp = 0
    for i in range(atm.nlayer):
        var_temp += atm.cn2dh_ratio[i] * var_temporal(tel.diameter, r0, tel.radial_max, atm.wind_speed[i], og*1e3)*1e6 / bw_unit**2
    #FIXME: better management of predictive law
    var_temp *= rtc.predictive_factor
    
    logger.debug('There is a fudge factor here to be understood')
    FUDGE = 4 #FIXME: factor to match noise budget
    sensi_ron = np.sqrt(2) * og
    sensi_photon = np.sqrt(2)/2 * og
    bwn = 2 * bw_unit * np.sqrt(og) # BWn evolves as sqrt of gain
    ntf2_int = 2/rtc.freq * bwn
    nphot_frame = src_wfs.flux * tel.surface / rtc.freq
    var_phot = 1/nphot_frame
    area_fourier = (tel.nact/tel.diameter)**2
    var_photon = FUDGE * var_phot * area_fourier / sensi_photon**2 * ntf2_int

    nssp = 4 * np.pi*(wfs.lenslet/2)**2
    var_ron = nssp * (wfs.ron/nphot_frame)**2
    var_ron = FUDGE * var_ron * area_fourier / sensi_ron**2 * ntf2_int
    
    var_noise = var_ron + var_photon
    
    # MINIMIZE: var_total = var_temp + var_noise
    # d var_total / d BW = var_noise - 2 * var_temp / BW^3
    
    bw = (2*var_temp/var_noise)**(1/3)
    if verbose:
        print('std temporal : %u nm'%round(np.sqrt(var_temp/bw**2)*(src_wfs.wvl_nm/(2*np.pi))))
        print('std noise    : %u nm'%round(np.sqrt(var_noise*bw)*(src_wfs.wvl_nm/(2*np.pi))))
    return bw


def optimal_gain_ffwfs(*args, og=1, verbose=False, **kwargs):
    """
    See: optimal_bandwidth_ffwfs
    
    The result of optimal_bandwidth_ffwfs is converted into integrator gain.
    """
    for a in args:
        if isinstance(a, RTC):
            rtc = a
    bw = optimal_bandwidth_ffwfs(*args, og=og, verbose=verbose, **kwargs)
    return (1+2*rtc.nb_frame_delay)*(bw*2*np.pi/rtc.freq)**2


def psd_jitter_common(nx, samp, tel, src_wfs, rtc):
    """Compute jitter PSD as Zernike Fourier transform"""
    psd = {}
    df = tel.frequency_step(samp) # numerical frequency step [1/m]
    
    if np.max(tel.jitter_mas):
        #TODO: check this
        logger.debug('Should I implement the jitter with gaussian OTF in tel.otf_ao ?')
        ztip = np.abs(zernike_fourier(1, 1, nx, samp=samp)/(2*samp)/df)**2
        ztilt = ztip.T
        factor = (tel.diameter/4 * 2*np.pi/src_wfs.wvl)**2
        psd['jitter'] = np.zeros((nx,nx))
        for i in range(len(tel.jitter_mas)):
            psd['jitter'] += factor * (ztip * arcsec2rad(tel.jitter_x[i]*1e-3)**2 + ztilt * arcsec2rad(tel.jitter_y[i]*1e-3)**2) * np.abs(rtc.closed_loop_transfer(tel.jitter_freq[i]))**2
            
    return psd


def psd_science_common(nx, samp, psdatmo, aomskin, tel, atm, src_wfs, src_sci):
    """Compute PSD terms affecting science only : anisoplanetism, NCPA, differential chromatism"""
    
    psd = {}
    
    df = tel.frequency_step(samp) # numerical frequency step [1/m]
    fx,fy = tel.frequency_grid(nx, samp)
    freq = np.sqrt(fx**2+fy**2)
    
    ## PSD ANISOPLANETISM SEPARATION
    if src_wfs.separation > 0:
        sep_x_rad = arcsec2rad(src_wfs.separation_x)
        sep_y_rad = arcsec2rad(src_wfs.separation_y)
        psd_aniso = psd_anisoplanetism(fx, fy, atm.cn2dh, atm.altitude, src_wfs.wvl, sep_x_rad, sep_y_rad, lext=atm.lext, zenith=src_sci.zenith_rad)
        psd['aniso-dist'] = psd_aniso * aomskin
        
    ## NCPA SCIENCE vs WFS
    rad_to_nm = src_wfs.wvl*1e9/(2*np.pi)
    if tel.ncpa > 0:
        psd['ncpa'] = psd_ncpa(tel.ncpa / rad_to_nm, freq, df, tel.diameter)
        
    ## DIFFERENTIAL CHROMATIC INDEX
    if src_sci.wvl != src_wfs.wvl:
        psd['chromatic'] = psdatmo * aomskin * psd_chromatic_filter(src_wfs.wvl_nm, src_sci.wvl_nm)
        theta_refraction = (air_refractive_index(src_sci.wvl_nm*1e-3)-air_refractive_index(src_wfs.wvl_nm*1e-3))*np.tan(src_sci.zenith_rad)
        psd['refraction'] = psd_anisoplanetism(fx, fy, atm.cn2dh, atm.altitude, src_wfs.wvl, theta_refraction, 0, lext=atm.lext, zenith=src_sci.zenith_rad) * aomskin
        
    return psd
