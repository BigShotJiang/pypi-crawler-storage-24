"""
Convert phase PSD to OTF and to PSF
"""


import numpy as np
from numpy.fft import fft2, ifft2, ifftshift, fftshift
from aopera.utils import aperture, arcsec2rad
from aopera.readconfig import read_config_file, read_config_tiptop, set_attribute, read_pupil
from aopera.aopsd import piston_filter, psd_wvl_scaling
from functools import lru_cache
import logging

logger = logging.getLogger('aopera')


def angle2freq(pix_angle,wvl):
    """Computes the PSD frequency step [1/m] to get the corresponding angular
    pixel size [rad] on the PSF."""
    df = pix_angle/wvl
    return df


def pupil_to_psf(pupil):
    """
    Compute the PSF from a real or complex array of pupil.
    """
    return fftshift(np.abs(fft2(pupil))**2) / np.sum(np.abs(pupil)) / pupil.size


def pupil_to_otf(pupil):
    """
    Compute the OTF from a real or complex array of pupil.
    """
    return ifftshift(ifft2(ifftshift(pupil_to_psf(pupil)))) * pupil.size


def otf2psf(otf):
    """Get the PSF for a given OTF"""
    psf = np.abs(np.real(fftshift(ifft2(fftshift(otf)))))
    return psf


@lru_cache(maxsize=2)
def psf_diffraction(npix, samp, occ=0):
    """
    Compute the diffraction PSF for a circular aperture.
    """
    if samp<2:
        raise ValueError("Sampling cannot be less than 2.0")
    return pupil_to_psf(aperture(npix, samp=samp, occ=occ))


@lru_cache(maxsize=2)
def otf_diffraction(npix, samp, occ=0):
    """
    Compute the diffraction OTF for a circular aperture.
    
    Parameters
    ----------
    npix : int
        Shape of the output array is (npix,npix).
    
    Keywords
    --------
    occ : float
        Eventual central obstruction (0<=occ<1).
    samp : float
        Required sampling. Must verify the condition samp>=2.
    """
    if samp<2:
        raise ValueError("Sampling cannot be less than 2.0")
    return pupil_to_otf(aperture(npix, samp=samp, occ=occ))


def psd2otf(psd, df, psdsum=None):
    """
    Get the OTF for a given PSD
    
    Parameters
    ----------
    psd : np.array
        The PSD 2D array.
    df : float
        Frequency step of the PSD array [1/m].
        
    Keywords
    --------
    psdsum : float, None
        Integral of the PSD.
        If psdsum=None, the integral is the numerical sum on the array.
        The PSF is then of unit energy, since max(otf)=1.
    """
    Bphi = ifftshift(np.real(fft2(fftshift(psd)))) * df**2
    if psdsum is None:
        psdsum = np.sum(psd) * df**2
    otf = np.exp(-psdsum+Bphi)
    return otf


def otf_jitter(fx, fy, rms_x, rms_y):
    """
    Give the Gaussian jitter OTF from its jitter RMS value.
    """
    return np.exp(-2*(np.pi*fx*rms_x)**2 - 2*(np.pi*fy*rms_y)**2)


#%% MODES and DEFORMABLE MIRROR
def number_modes(nact, occ=0):
    """Compute the number of corrected modes"""
    surf_ratio = np.pi*(1-occ**2)/4 #between occulted disk and square
    nact_total = nact**2
    return int(round(nact_total * surf_ratio))
    
    
def number_radial(nact, occ=0):
    """Compute the number of corrected radial modes"""
    nmode = number_modes(nact, occ=occ)
    return int(round(np.sqrt(2*nmode)-0.5)) # nr(nr+1)/2 = nmode


def controllability(fx, fy, D, actuator, nmode_ratio=1, cartesian=True):
    """Return a DM frequency map that is 1 on the corrected frequencies, 0 otherwise"""
    cutoff = (actuator-1)/(2*D)
    if cutoff <= 0: # no DM case
        return np.zeros(fx.shape)
    rr = np.sqrt(fx**2+fy**2)
    if nmode_ratio >1:
        raise ValueError('nmode_ratio cannot be above 1.')
    if cartesian:
        thresh = np.pi/4
        if nmode_ratio > thresh: # smooth transition from square to circle
            a = (np.sqrt(2)*thresh-1) / (np.sqrt(2)-1)   
            nact_equiv = (nmode_ratio-a)/(thresh-a)
            # nmode_ratio = thresh => nact_equiv = 1
            # nmode_ratio = 1 => nact_equiv = np.sqrt(2) <=> diagonal of the actuator square
        else:
            nact_equiv = np.sqrt(nmode_ratio/thresh)
        modal_radial_cutoff = (rr <= (nact_equiv*cutoff))
        actuator_square_cutoff = (np.abs(fx)<=cutoff)*(np.abs(fy)<=cutoff)
        return actuator_square_cutoff * modal_radial_cutoff
    else:
        return rr <= (np.sqrt(nmode_ratio)*cutoff)


#%% TELESCOPE CLASS
class Pupil:
    def __init__(self, dictionary):
        if not 'pupil' in dictionary.keys():
            set_attribute(self, dictionary, 'pupil_occ')
            self.pupil = None
        else:
            set_attribute(self, dictionary, 'pupil_file')
            self.pupil = read_pupil(self.pupil)
    
    def __repr__(self):
        s  = 'aopera.PUPIL\n'
        s += '-------------\n'
        s += 'diameter   : %.1f m\n'%self.diameter
        if self.pupil is None:
            s += 'occultation: %u %%\n'%(100*self.occultation)
        else:
            s += 'pupil      : from file\n'
        s += 'nb act     : %u\n'%self.nact
        s += 'mode ratio : %.2f\n'%self.nmode_ratio
        s += 'ncpa       : %u nm\n'%self.ncpa
        s += 'jitter     : (%u, %u) mas RMS\n'%(np.sqrt(sum(self.jitter_x**2)),np.sqrt(sum(self.jitter_y**2)))
        return s
    
    @staticmethod
    def from_file(filepath, category='pupil'):
        return Pupil(read_config_file(filepath, category))
    
    @staticmethod
    def from_file_tiptop(filepath):
        return Pupil(read_config_tiptop(filepath)[0])
    
    @staticmethod
    def from_oopao(tel, dm, M2C):
        return Pupil({'diameter':tel.D,
                       'occultation':tel.centralObstruction,
                       'nact':dm.nAct,
                       'nmode_ratio':M2C.shape[1]/M2C.shape[0]})
    
    @property
    def jitter_x(self):
        return self.jitter_mas * np.cos(self.jitter_angle*np.pi/180)
    
    @property
    def jitter_y(self):
        return self.jitter_mas * np.sin(self.jitter_angle*np.pi/180)
    
    @property
    def surface(self):
        if self.pupil is None:
            return np.pi * (self.diameter/2)**2 * (1-self.occultation**2)
        else:
            nx = 512
            samp = 1
            return (self.diameter**2) * np.sum(self.pupil(nx, samp)) / nx**2
    
    @property
    def mode_max(self):
        return number_modes(self.nact, occ=self.occultation)
    
    @property
    def radial_max(self):
        return number_radial(self.nact, occ=self.occultation)
    
    @property
    def pitch_dm(self):
        return self.diameter/(self.nact-1)
    
    def pitch_wfs(self, nb_lenslet):
        return self.diameter/nb_lenslet
    
    def pitch_ao(self, nb_lenslet):
        return max(self.pitch_dm, self.pitch_wfs(nb_lenslet))
    
    def cutoff_frequency(self, nb_lenslet):
        return 1/(2*self.pitch_ao(nb_lenslet))
    
    def frequency_step(self, samp):
        return 1/(samp*self.diameter)
    
    def frequency_grid(self, nx, samp):
        return (np.mgrid[0:nx,0:nx]-nx//2) * self.frequency_step(samp)
    
    def piston_filter(self, nx, samp):
        fx,fy = self.frequency_grid(nx, samp)
        return piston_filter(np.sqrt(fx**2+fy**2), self.diameter)
    
    def otf_diffraction(self, nx, samp):
        if self.pupil is None:
            return otf_diffraction(nx, occ=self.occultation, samp=samp)
        else:
            return pupil_to_otf(self.pupil(nx, samp))
    
    def psf_diffraction(self, nx, samp):
        if self.pupil is None:
            return psf_diffraction(nx, occ=self.occultation, samp=samp)
        else:
            return pupil_to_psf(self.pupil(nx, samp))
    
    def controllability(self, fx, fy):
        return controllability(fx, fy, self.diameter, self.nact, nmode_ratio=self.nmode_ratio, cartesian=self.cartesian)
    
    def otf_jitter(self, nx, samp, wvl, cltf):
        logger.warning('Pupil.otf_jitter has not been tested yet.')
        dx = wvl/self.diameter / samp
        df_otf = 1/(nx*dx)
        fx,fy = (np.mgrid[0:nx,0:nx]-nx//2) * df_otf
        cltf_abs = np.abs(cltf(self.jitter_freq))
        rms_x = np.sqrt(np.sum(arcsec2rad(self.jitter_x*1e-3*cltf_abs)**2))
        rms_y = np.sqrt(np.sum(arcsec2rad(self.jitter_y*1e-3*cltf_abs)**2))
        return otf_jitter(fx, fy, rms_x, rms_y)
    
    def otf_ao(self, psd, samp, wvl_scale=1):
        if wvl_scale == 1:
            otf_diff = self.otf_diffraction(psd.shape[0], samp)
            df = self.frequency_step(samp)
            return psd2otf(psd, df)*otf_diff
        else:
            psd_scale = psd_wvl_scaling(psd, 1/wvl_scale)
            samp_scale = samp * wvl_scale
            return self.otf_ao(psd_scale, samp_scale)
    
    def psf_ao(self, *args, **kwargs):
        return otf2psf(self.otf_ao(*args, **kwargs))
    