from setuptools import setup, find_packages

setup(
    name="ai-research-agent",
    version="0.1.0",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "ollama",
        "python-dotenv",
        "ddgs",
        "httpx",
        "questionary",
        "python-docx",
        "reportlab",
        "arabic-reshaper",
        "python-bidi",
        "pathlib",
    ],
    entry_points={
        "console_scripts": [
            "ai-research=ai_research_agent.main:main",
        ],
    },
    package_data={
        "ai_research_agent": ["DejaVuSans.ttf"],
    },
    python_requires=">=3.9",
)