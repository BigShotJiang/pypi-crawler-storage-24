# helpers/log.py
import os
import traceback
from datetime import datetime
from pathlib import Path


def log_agent(topic, language, filetype, status, output, error=None):
    """
    Log agent activity to a file inside Downloads/Research/logs
    """

    base_dir = Path.home() / "Downloads" / "Research"
    log_dir = base_dir / "logs"

    os.makedirs(log_dir, exist_ok=True)

    timestamp = datetime.now().strftime("%H:%M:%S")
    date_str = datetime.now().strftime("%Y-%m-%d")

    safe_topic = "".join(c if c.isalnum() or c in " _-" else "_" for c in topic)

    log_file = log_dir / f"{safe_topic}.log"

    error_details = ""
    if error:
        error_details = (
            f"\nError Type: {type(error).__name__}"
            f"\nError Message: {error}"
            f"\nTraceback:\n{traceback.format_exc()}"
        )

    content = (
        "\n" + "=" * 60 +
        f"\nTime: {timestamp}"
        f"\nDate: {date_str}"
        f"\nTopic: {topic}"
        f"\nLanguage: {language}"
        f"\nFormat: {filetype}"
        f"\nStatus: {status}"
        f"\nOutput: {output}"
        f"{error_details}\n"
    )

    with open(log_file, "a", encoding="utf-8") as f:
        f.write(content)