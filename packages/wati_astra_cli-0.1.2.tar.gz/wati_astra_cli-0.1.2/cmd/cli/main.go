package main

import (
	"flag"

	"github.com/ClareAI/astra-insight-mcp/internal/app"
)

func main() {
	debug := flag.Bool("debug", false, "print full curl commands for every gateway API call")
	flag.Parse()

	if len(flag.Args()) > 0 {
		switch flag.Args()[0] {
		case "auth":
			app.RunAuth(flag.Args()[1:])
			return
		case "configure", "setup", "config":
			app.RunConfigure(flag.Args()[1:])
			return
		}
	}

	app.RunREPL(*debug)
}
