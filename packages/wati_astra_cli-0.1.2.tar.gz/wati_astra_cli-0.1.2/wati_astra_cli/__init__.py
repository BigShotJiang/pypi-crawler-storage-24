"""Python shim that invokes the Go `astra` CLI shipped with this package."""

__version__ = "0.1.2"
