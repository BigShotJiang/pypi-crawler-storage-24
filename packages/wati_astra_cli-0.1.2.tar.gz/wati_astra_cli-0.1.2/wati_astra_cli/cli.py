"""Console entrypoint: run the bundled `astra` Go binary."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path


def _binary_path() -> Path:
    here = Path(__file__).resolve().parent
    name = "_astra_bin.exe" if sys.platform == "win32" else "_astra_bin"
    return here / name


def main() -> None:
    bin_path = _binary_path()
    if not bin_path.is_file():
        sys.stderr.write(
            "astra: bundled binary is missing.\n"
            "Reinstall with: pip install --force-reinstall --no-binary :all: wati-astra-cli\n"
            "Or install Go and: go install github.com/ClareAI/astra-insight-mcp/cmd/astra@latest\n"
        )
        raise SystemExit(127)
    raise SystemExit(subprocess.call([str(bin_path), *sys.argv[1:]]))
