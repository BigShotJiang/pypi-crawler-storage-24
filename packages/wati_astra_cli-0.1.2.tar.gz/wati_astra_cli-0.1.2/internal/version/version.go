package version

// Version is the CLI and release version (override with -ldflags at build time).
var Version = "0.1.2"
