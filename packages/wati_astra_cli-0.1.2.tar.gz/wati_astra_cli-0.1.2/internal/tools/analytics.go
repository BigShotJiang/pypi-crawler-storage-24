package tools

import (
	"context"
	"fmt"

	"github.com/ClareAI/astra-insight-mcp/internal/gateway"
	"github.com/ClareAI/astra-insight-mcp/internal/mcp"
)

func registerAnalytics(s *mcp.Server, gw *gateway.Client) {
	tool := mcp.Tool{
		Name:        "get_analytics",
		Description: "Get unified analytics for an agent: conversation counts, lead metrics, performance, and trends. Replaces separate conversation/lead/performance analytics. Requires agent_id. Optionally filter by date range (YYYYMMDD format).",
		InputSchema: mcp.InputSchema{
			Type: "object",
			Properties: map[string]mcp.Property{
				"agent_id":   {Type: "string", Description: "Agent ID to get analytics for"},
				"start_time": {Type: "string", Description: "Start date in YYYYMMDD format (e.g. 20250301). Defaults to 30 days ago."},
				"end_time":   {Type: "string", Description: "End date in YYYYMMDD format (e.g. 20250311). Defaults to today."},
			},
			Required: []string{},
		},
	}

	s.RegisterTool(tool, func(ctx context.Context, args map[string]interface{}) (interface{}, error) {
		apiKey := apiKeyFromArgs(args)
		if apiKey == "" {
			return nil, fmt.Errorf("api_key is required")
		}

		opts := gateway.AnalyticsOpts{}
		if v, ok := args["agent_id"].(string); ok {
			opts.AgentID = v
		}
		if v, ok := args["start_time"].(string); ok {
			opts.StartTime = v
		}
		if v, ok := args["end_time"].(string); ok {
			opts.EndTime = v
		}

		return gw.GetAnalytics(ctx, apiKey, opts)
	})
}

func registerLeadDistribution(s *mcp.Server, gw *gateway.Client) {
	tool := mcp.Tool{
		Name:        "get_lead_distribution",
		Description: "Get lead score distribution — breakdown of leads by category (hot/warm/cold/unqualified) with counts and percentages. agent_id, start_time, end_time, and timezone are ALL required.",
		InputSchema: mcp.InputSchema{
			Type: "object",
			Properties: map[string]mcp.Property{
				"agent_id":   {Type: "string", Description: "Agent ID to get distribution for"},
				"start_time": {Type: "string", Description: "Start date in YYYYMMDD format (e.g. 20260301)"},
				"end_time":   {Type: "string", Description: "End date in YYYYMMDD format (e.g. 20260324)"},
				"timezone":   {Type: "string", Description: "IANA timezone string (e.g. Asia/Hong_Kong, America/New_York, UTC). Required."},
				"channel":    {Type: "string", Description: "Filter by channel (optional)"},
			},
			Required: []string{"agent_id", "start_time", "end_time", "timezone"},
		},
	}

	s.RegisterTool(tool, func(ctx context.Context, args map[string]interface{}) (interface{}, error) {
		apiKey := apiKeyFromArgs(args)
		if apiKey == "" {
			return nil, fmt.Errorf("api_key is required")
		}
		agentID, _ := args["agent_id"].(string)
		if agentID == "" {
			return nil, fmt.Errorf("agent_id is required")
		}

		opts := gateway.DistributionOpts{AgentID: agentID}
		if v, ok := args["start_time"].(string); ok {
			opts.StartTime = v
		}
		if v, ok := args["end_time"].(string); ok {
			opts.EndTime = v
		}
		if v, ok := args["timezone"].(string); ok {
			opts.Timezone = v
		}
		if v, ok := args["channel"].(string); ok {
			opts.Channel = v
		}

		return gw.GetDistribution(ctx, apiKey, opts)
	})
}
