package tools

import (
	"context"
	"fmt"

	"github.com/ClareAI/astra-insight-mcp/internal/gateway"
	"github.com/ClareAI/astra-insight-mcp/internal/mcp"
)

func registerGetWatiSettings(s *mcp.Server, gw *gateway.Client) {
	s.RegisterTool(mcp.Tool{
		Name:        "get_wati_settings",
		Description: "Get WATI connection settings for the tenant — returns wati_endpoint, wati_user_token, wati_tenant, and human_agent_email. Use this to retrieve WATI API credentials needed for direct WATI API calls (contacts, conversations, template messages).",
		InputSchema: mcp.InputSchema{
			Type:       "object",
			Properties: map[string]mcp.Property{},
			Required:   []string{},
		},
	}, func(ctx context.Context, args map[string]interface{}) (interface{}, error) {
		apiKey := apiKeyFromArgs(args)
		if apiKey == "" {
			return nil, fmt.Errorf("api_key is required")
		}
		return gw.GetWatiSettings(ctx, apiKey)
	})
}

func registerListConnections(s *mcp.Server, gw *gateway.Client) {
	tool := mcp.Tool{
		Name:        "list_connections",
		Description: "List all platform connections for the tenant — HubSpot, Slack, Calendly, etc. Shows connection status (enabled/disabled) and platform names. Use this to understand what integrations are available.",
		InputSchema: mcp.InputSchema{
			Type:       "object",
			Properties: map[string]mcp.Property{},
			Required:   []string{},
		},
	}

	s.RegisterTool(tool, func(ctx context.Context, args map[string]interface{}) (interface{}, error) {
		apiKey := apiKeyFromArgs(args)
		if apiKey == "" {
			return nil, fmt.Errorf("api_key is required")
		}
		return gw.ListConnections(ctx, apiKey)
	})
}
