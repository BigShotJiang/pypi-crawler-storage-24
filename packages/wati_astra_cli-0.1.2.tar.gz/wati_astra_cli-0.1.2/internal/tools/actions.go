package tools

import (
	"context"
	"fmt"

	"github.com/ClareAI/astra-insight-mcp/internal/gateway"
	"github.com/ClareAI/astra-insight-mcp/internal/mcp"
)

func registerListActions(s *mcp.Server, gw *gateway.Client) {
	tool := mcp.Tool{
		Name:        "list_actions",
		Description: "List all configured actions (tools) for the tenant — including platform integrations like HubSpot, Calendly, WhatsApp, web search, etc. Shows action names, platforms, types, and connection status. Use this to understand what capabilities the agent has.",
		InputSchema: mcp.InputSchema{
			Type:       "object",
			Properties: map[string]mcp.Property{},
			Required:   []string{},
		},
	}

	s.RegisterTool(tool, func(ctx context.Context, args map[string]interface{}) (interface{}, error) {
		apiKey := apiKeyFromArgs(args)
		if apiKey == "" {
			return nil, fmt.Errorf("api_key is required")
		}

		return gw.ListActions(ctx, apiKey, gateway.ActionListOpts{})
	})
}

func registerGetAction(s *mcp.Server, gw *gateway.Client) {
	tool := mcp.Tool{
		Name:        "get_action",
		Description: "Get details of a single action — name, description, type, platform, connection status, and configuration. Use this to inspect a specific integration.",
		InputSchema: mcp.InputSchema{
			Type: "object",
			Properties: map[string]mcp.Property{
				"action_id": {Type: "string", Description: "Action ID"},
			},
			Required: []string{"action_id"},
		},
	}

	s.RegisterTool(tool, func(ctx context.Context, args map[string]interface{}) (interface{}, error) {
		apiKey := apiKeyFromArgs(args)
		actionID, _ := args["action_id"].(string)
		if apiKey == "" || actionID == "" {
			return nil, fmt.Errorf("api_key and action_id are required")
		}
		return gw.GetAction(ctx, apiKey, actionID)
	})
}
