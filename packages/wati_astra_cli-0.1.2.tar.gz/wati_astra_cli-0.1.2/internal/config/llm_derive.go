package config

import "strings"

// DeriveFastModel picks a smaller/cheaper model for tool-result summarization when LLM_FAST_MODEL is unset.
func DeriveFastModel(model string) string {
	lower := strings.ToLower(model)
	switch {
	case strings.Contains(lower, "opus"), strings.Contains(lower, "sonnet"):
		return "anthropic/claude-3.5-haiku"
	case strings.Contains(lower, "gpt-4o") && !strings.Contains(lower, "mini"):
		return "gpt-4o-mini"
	case strings.Contains(lower, "gpt-4.1") && !strings.Contains(lower, "mini") && !strings.Contains(lower, "nano"):
		return "gpt-4.1-mini"
	case strings.Contains(lower, "gemini-2.5-pro"):
		return strings.Replace(model, "pro", "flash", 1)
	default:
		return ""
	}
}
