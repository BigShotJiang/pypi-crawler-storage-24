package config

import "os"

// ApplyProviderDefaults updates e with the provider's default base URL and model when the
// corresponding environment variables are unset. Recomputes FastModel when LLM_FAST_MODEL is unset.
func ApplyProviderDefaults(e *LLMEnv, p LLMProviderID) {
	if os.Getenv("LLM_BASE_URL") == "" {
		e.BaseURL = p.DefaultBaseURL()
	}
	if os.Getenv("LLM_MODEL") == "" {
		e.Model = p.DefaultModel()
	}
	if os.Getenv("LLM_FAST_MODEL") == "" {
		e.FastModel = DeriveFastModel(e.Model)
	}
}
