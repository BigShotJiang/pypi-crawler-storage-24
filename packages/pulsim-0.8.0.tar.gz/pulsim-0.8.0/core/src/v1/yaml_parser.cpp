/**
 * @file yaml_parser.cpp
 * @brief YAML schema v1 parser: maps netlist documents into Circuit + SimulationOptions.
 */

#include "pulsim/v1/parser/yaml_parser.hpp"

#include <yaml-cpp/yaml.h>

#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstdlib>
#include <functional>
#include <fstream>
#include <limits>
#include <optional>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <unordered_set>

namespace pulsim::v1::parser {

namespace {

constexpr const char* kSchemaId = "pulsim-v1";
constexpr const char* kDiagUnsupportedComponent = "PULSIM_YAML_E_COMPONENT_UNSUPPORTED";
constexpr const char* kDiagInvalidPinCount = "PULSIM_YAML_E_PIN_COUNT";
constexpr const char* kDiagInvalidParameter = "PULSIM_YAML_E_PARAM_INVALID";
constexpr const char* kDiagVirtualComponent = "PULSIM_YAML_W_COMPONENT_VIRTUAL";
constexpr const char* kDiagSurrogateComponent = "PULSIM_YAML_W_COMPONENT_SURROGATE";
constexpr const char* kDiagInvalidStepMode = "PULSIM_YAML_E_STEP_MODE_INVALID";
constexpr const char* kDiagUnknownField = "PULSIM_YAML_E_UNKNOWN_FIELD";
constexpr const char* kDiagTypeMismatch = "PULSIM_YAML_E_TYPE_MISMATCH";
constexpr const char* kDiagDeprecatedField = "PULSIM_YAML_W_DEPRECATED_FIELD";
constexpr const char* kDiagThermalUnsupportedComponent = "PULSIM_YAML_E_THERMAL_UNSUPPORTED_COMPONENT";
constexpr const char* kDiagThermalMissingRequired = "PULSIM_YAML_E_THERMAL_MISSING_REQUIRED";
constexpr const char* kDiagThermalInvalidRange = "PULSIM_YAML_E_THERMAL_RANGE_INVALID";
constexpr const char* kDiagThermalNetworkInvalid = "PULSIM_YAML_E_THERMAL_NETWORK_INVALID";
constexpr const char* kDiagThermalDimensionInvalid = "PULSIM_YAML_E_THERMAL_DIMENSION_INVALID";
constexpr const char* kDiagThermalDefaultApplied = "PULSIM_YAML_W_THERMAL_DEFAULT_APPLIED";
constexpr const char* kDiagLossInvalidRange = "PULSIM_YAML_E_LOSS_RANGE_INVALID";
constexpr const char* kDiagLossModelInvalid = "PULSIM_YAML_E_LOSS_MODEL_INVALID";
constexpr const char* kDiagLossAxisInvalid = "PULSIM_YAML_E_LOSS_AXIS_INVALID";
constexpr const char* kDiagLossDimensionInvalid = "PULSIM_YAML_E_LOSS_DIMENSION_INVALID";
constexpr const char* kDiagFrequencyInvalid = "PULSIM_YAML_E_FREQ_CONFIG_INVALID";
constexpr const char* kDiagAveragedInvalid = "PULSIM_YAML_E_AVERAGED_CONFIG_INVALID";
constexpr const char* kDiagMagneticInvalid = "PULSIM_YAML_E_MAGNETIC_CONFIG_INVALID";

/// Parses scalar real strings with engineering suffix support.
Real parse_real_string(const std::string& raw);

/// Lowercases ASCII characters for key normalization.
std::string to_lower(std::string s) {
    std::transform(s.begin(), s.end(), s.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return s;
}

/// Normalizes schema keys by lowercasing and removing non-alphanumeric chars.
std::string normalize_key(std::string s) {
    s = to_lower(s);
    std::string out;
    out.reserve(s.size());
    for (unsigned char c : s) {
        if (std::isalnum(c)) {
            out.push_back(static_cast<char>(c));
        }
    }
    return out;
}

/// Returns whether a normalized key belongs to an allowed-key set.
bool is_known_key(const std::string& key, const std::unordered_set<std::string>& allowed) {
    return allowed.find(key) != allowed.end();
}

/// Returns whether canonical component type supports electrothermal options.
[[nodiscard]] bool component_type_supports_thermal(const std::string& canonical_type) {
    return canonical_type == "resistor" ||
           canonical_type == "diode" ||
           canonical_type == "mosfet" ||
           canonical_type == "igbt" ||
           canonical_type == "bjt_npn" ||
           canonical_type == "bjt_pnp";
}

/// Returns whether canonical component type supports nonlinear magnetic_core block.
[[nodiscard]] bool component_type_supports_magnetic_core(const std::string& canonical_type) {
    return canonical_type == "saturable_inductor" ||
           canonical_type == "coupled_inductor" ||
           canonical_type == "transformer";
}

/// Prefixes diagnostics with stable machine-readable error code.
std::string with_diag_code(const std::string& code, const std::string& message) {
    return "[" + code + "] " + message;
}

/// Appends one structured parser error.
void push_error(std::vector<std::string>& errors, const std::string& code, const std::string& message) {
    errors.push_back(with_diag_code(code, message));
}

/// Appends one structured parser warning.
void push_warning(std::vector<std::string>& warnings, const std::string& code, const std::string& message) {
    warnings.push_back(with_diag_code(code, message));
}

/// Classifies YAML node type for error reporting.
std::string yaml_node_class(const YAML::Node& node) {
    if (!node || node.IsNull()) {
        return "null";
    }
    if (node.IsScalar()) {
        return "scalar";
    }
    if (node.IsSequence()) {
        return "sequence";
    }
    if (node.IsMap()) {
        return "map";
    }
    return "unknown";
}

/// Emits standardized type mismatch parser diagnostic.
void push_type_mismatch_error(std::vector<std::string>& errors,
                              const std::string& path,
                              const std::string& expected,
                              const YAML::Node& received) {
    push_error(
        errors,
        kDiagTypeMismatch,
        "Type mismatch at '" + path + "' (expected " + expected +
            ", got " + yaml_node_class(received) + ")");
}

/// Parses optional boolean scalar while validating type.
std::optional<bool> parse_bool_scalar(const YAML::Node& node,
                                      const std::string& path,
                                      std::vector<std::string>& errors) {
    if (!node) {
        return std::nullopt;
    }
    if (!node.IsScalar()) {
        push_type_mismatch_error(errors, path, "boolean", node);
        return std::nullopt;
    }
    try {
        return node.as<bool>();
    } catch (...) {
        push_type_mismatch_error(errors, path, "boolean", node);
        return std::nullopt;
    }
}

/// Parses optional integer scalar while validating type.
std::optional<int> parse_int_scalar(const YAML::Node& node,
                                    const std::string& path,
                                    std::vector<std::string>& errors) {
    if (!node) {
        return std::nullopt;
    }
    if (!node.IsScalar()) {
        push_type_mismatch_error(errors, path, "integer", node);
        return std::nullopt;
    }
    try {
        return node.as<int>();
    } catch (...) {
        push_type_mismatch_error(errors, path, "integer", node);
        return std::nullopt;
    }
}

/// Parses optional string scalar while validating type.
std::optional<std::string> parse_string_scalar(const YAML::Node& node,
                                               const std::string& path,
                                               std::vector<std::string>& errors) {
    if (!node) {
        return std::nullopt;
    }
    if (!node.IsScalar()) {
        push_type_mismatch_error(errors, path, "string", node);
        return std::nullopt;
    }
    try {
        return node.as<std::string>();
    } catch (...) {
        push_type_mismatch_error(errors, path, "string", node);
        return std::nullopt;
    }
}

void push_deprecated_field_migration_warning(std::vector<std::string>& warnings,
                                             const std::string& key_path,
                                             const std::string& replacement) {
    push_warning(
        warnings,
        kDiagDeprecatedField,
        "Deprecated field '" + key_path + "' remains accepted in schema v1 migration window; use '" +
            replacement + "' instead.");
}

void apply_mode_derived_defaults(SimulationOptions& options,
                                 TransientStepMode mode,
                                 bool dt_min_explicit,
                                 bool dt_max_explicit) {
    options.step_mode = mode;
    options.step_mode_explicit = true;
    options.adaptive_timestep = (mode == TransientStepMode::Variable);

    // Deterministic robust defaults shared by canonical modes.
    options.integrator = Integrator::TRBDF2;
    options.stiffness_config.enable = true;
    options.stiffness_config.switch_integrator = true;
    options.stiffness_config.stiff_integrator = Integrator::BDF1;
    options.max_step_retries = std::max(options.max_step_retries, 6);

    if (!dt_min_explicit) {
        options.dt_min = std::max<Real>(1e-12, options.dt * 1e-3);
    }
    if (!dt_max_explicit) {
        options.dt_max = std::max<Real>(options.dt * 20.0, options.dt);
    }

    options.timestep_config = AdvancedTimestepConfig::for_power_electronics();
    options.timestep_config.dt_initial = std::max<Real>(options.dt, 1e-18);
    options.timestep_config.dt_min = std::max<Real>(options.dt_min, 1e-12);
    options.timestep_config.dt_max = std::max<Real>(options.dt_max, options.timestep_config.dt_min);

    if (mode == TransientStepMode::Fixed) {
        options.enable_bdf_order_control = false;
    } else {
        options.enable_bdf_order_control = true;
        options.bdf_config.min_order = 1;
        options.bdf_config.max_order = 2;
        options.bdf_config.initial_order = 1;
        options.lte_config = RichardsonLTEConfig::defaults();
    }
}

void enforce_mode_semantics(SimulationOptions& options) {
    if (!options.step_mode_explicit) {
        return;
    }
    options.adaptive_timestep = (options.step_mode == TransientStepMode::Variable);
}

const std::unordered_map<std::string, std::string>& component_alias_map() {
    static const std::unordered_map<std::string, std::string> aliases = [] {
        std::unordered_map<std::string, std::string> map;

        auto add_aliases = [&](const std::string& canonical, std::initializer_list<const char*> names) {
            map.emplace(normalize_key(canonical), canonical);
            for (const char* name : names) {
                map.emplace(normalize_key(name), canonical);
            }
        };

        add_aliases("resistor", {"r"});
        add_aliases("capacitor", {"c"});
        add_aliases("inductor", {"l"});
        add_aliases("voltage_source", {"v", "voltagesource", "source_v", "vsource"});
        add_aliases("current_source", {"i", "currentsource", "isource"});
        add_aliases("diode", {"d"});
        add_aliases("switch", {"s"});
        add_aliases("vcswitch", {"voltagecontrolledswitch"});
        add_aliases("mosfet", {"m", "nmos", "pmos"});
        add_aliases("igbt", {"q"});
        add_aliases("transformer", {"t"});
        add_aliases("snubber_rc", {"snubber", "snubberrc"});

        add_aliases("bjt_npn", {"bjtnpn", "bjt-npn"});
        add_aliases("bjt_pnp", {"bjtpnp", "bjt-pnp"});
        add_aliases("thyristor", {"scr"});
        add_aliases("triac", {"triac"});
        add_aliases("fuse", {"fuse"});
        add_aliases("circuit_breaker", {"breaker", "circuitbreaker", "circuit-breaker"});
        add_aliases("relay", {"relay"});
        add_aliases("op_amp", {"opamp", "op-amp"});
        add_aliases("comparator", {"comparator"});
        add_aliases("pi_controller", {"pi", "picontroller", "pi-controller"});
        add_aliases("pid_controller", {"pidcontroller", "pid-controller"});
        add_aliases("math_block", {"mathblock", "math"});
        add_aliases("gain", {"gainblock", "gain-block"});
        add_aliases("sum", {"adder", "sumblock", "sum-block"});
        add_aliases("subtraction", {"subtract", "subtractor", "sub", "subtractionblock", "subtraction-block"});
        add_aliases("pwm_generator", {"pwmgenerator", "pwm"});
        add_aliases("integrator", {"integrator"});
        add_aliases("differentiator", {"differentiator"});
        add_aliases("limiter", {"limiter"});
        add_aliases("rate_limiter", {"ratelimiter", "rate-limiter"});
        add_aliases("hysteresis", {"hysteresis"});
        add_aliases("lookup_table", {"lookuptable", "lookup-table", "lut"});
        add_aliases("transfer_function", {"transferfunction", "transfer-function"});
        add_aliases("delay_block", {"delayblock", "delay"});
        add_aliases("sample_hold", {"samplehold", "sample-and-hold"});
        add_aliases("state_machine", {"statemachine", "state-machine"});
        add_aliases("saturable_inductor", {"saturableinductor", "sat_inductor"});
        add_aliases("coupled_inductor", {"coupledinductor"});
        add_aliases("voltage_probe", {"voltageprobe", "vprobe"});
        add_aliases("current_probe", {"currentprobe", "iprobe"});
        add_aliases("power_probe", {"powerprobe", "pprobe"});
        add_aliases("electrical_scope", {"electricalscope", "scope"});
        add_aliases("thermal_scope", {"thermalscope"});
        add_aliases("signal_mux", {"signalmux", "mux"});
        add_aliases("signal_demux", {"signaldemux", "demux"});
        add_aliases("c_block", {"cblock", "c-block", "custom_block"});

        return map;
    }();
    return aliases;
}

const std::unordered_map<std::string, std::pair<std::size_t, std::size_t>>& component_node_arity() {
    static const std::unordered_map<std::string, std::pair<std::size_t, std::size_t>> arity = {
        {"resistor", {2, 2}},
        {"capacitor", {2, 2}},
        {"inductor", {2, 2}},
        {"voltage_source", {2, 2}},
        {"current_source", {2, 2}},
        {"diode", {2, 2}},
        {"switch", {2, 2}},
        {"vcswitch", {3, 3}},
        {"mosfet", {3, 3}},
        {"igbt", {3, 3}},
        {"transformer", {4, 4}},
        {"snubber_rc", {2, 2}},
        {"bjt_npn", {3, 3}},
        {"bjt_pnp", {3, 3}},
        {"thyristor", {3, 3}},
        {"triac", {3, 3}},
        {"fuse", {2, 2}},
        {"circuit_breaker", {2, 2}},
        {"relay", {5, 5}},
        {"op_amp", {3, 3}},
        {"comparator", {3, 3}},
        {"pi_controller", {3, 3}},
        {"pid_controller", {3, 3}},
        {"gain", {2, 2}},
        {"sum", {2, 3}},
        {"subtraction", {2, 3}},
        {"math_block", {2, std::numeric_limits<std::size_t>::max()}},
        {"pwm_generator", {1, 3}},
        {"integrator", {2, 2}},
        {"differentiator", {2, 2}},
        {"limiter", {2, 2}},
        {"rate_limiter", {2, 2}},
        {"hysteresis", {2, 2}},
        {"lookup_table", {2, 2}},
        {"transfer_function", {2, 2}},
        {"delay_block", {2, 2}},
        {"sample_hold", {2, 2}},
        {"state_machine", {1, std::numeric_limits<std::size_t>::max()}},
        {"saturable_inductor", {2, 2}},
        {"coupled_inductor", {4, 4}},
        {"voltage_probe", {2, 2}},
        {"current_probe", {2, 2}},
        {"power_probe", {2, 2}},
        {"electrical_scope", {1, std::numeric_limits<std::size_t>::max()}},
        {"thermal_scope", {1, std::numeric_limits<std::size_t>::max()}},
        {"signal_mux", {2, std::numeric_limits<std::size_t>::max()}},
        {"signal_demux", {2, std::numeric_limits<std::size_t>::max()}},
        {"c_block", {0, std::numeric_limits<std::size_t>::max()}}
    };
    return arity;
}

const std::unordered_set<std::string>& virtual_component_types() {
    static const std::unordered_set<std::string> types = {
        "relay",
        "op_amp",
        "comparator",
        "pi_controller",
        "pid_controller",
        "gain",
        "sum",
        "subtraction",
        "math_block",
        "pwm_generator",
        "integrator",
        "differentiator",
        "limiter",
        "rate_limiter",
        "hysteresis",
        "lookup_table",
        "transfer_function",
        "delay_block",
        "sample_hold",
        "state_machine",
        "voltage_probe",
        "current_probe",
        "power_probe",
        "electrical_scope",
        "thermal_scope",
        "signal_mux",
        "signal_demux",
        "c_block"
    };
    return types;
}

bool virtual_component_supports_sample_time(const std::string& type) {
    static const std::unordered_set<std::string> sampled_types = {
        "op_amp",
        "comparator",
        "pi_controller",
        "pid_controller",
        "gain",
        "sum",
        "subtraction",
        "math_block",
        "pwm_generator",
        "integrator",
        "differentiator",
        "limiter",
        "rate_limiter",
        "hysteresis",
        "lookup_table",
        "transfer_function",
        "delay_block",
        "sample_hold",
        "state_machine",
        "signal_mux",
        "signal_demux",
        "c_block"
    };
    return sampled_types.contains(type);
}

std::string canonical_component_type(const std::string& raw_type) {
    const auto key = normalize_key(raw_type);
    const auto& aliases = component_alias_map();
    const auto it = aliases.find(key);
    if (it == aliases.end()) {
        return {};
    }
    return it->second;
}

bool validate_node_count(const std::string& type,
                         const std::vector<std::string>& nodes,
                         std::vector<std::string>& errors,
                         const std::string& name) {
    const auto& arity = component_node_arity();
    const auto it = arity.find(type);
    if (it == arity.end()) {
        return true;
    }

    const auto [min_nodes, max_nodes] = it->second;
    if (nodes.size() < min_nodes || nodes.size() > max_nodes) {
        std::ostringstream oss;
        oss << "Invalid pin count for '" << name << "' (" << type << "): got "
            << nodes.size() << ", expected ";
        if (min_nodes == max_nodes) {
            oss << min_nodes;
        } else if (max_nodes == std::numeric_limits<std::size_t>::max()) {
            oss << min_nodes << "+";
        } else {
            oss << min_nodes << "-" << max_nodes;
        }
        push_error(errors, kDiagInvalidPinCount, oss.str());
        return false;
    }

    return true;
}

void collect_virtual_component_fields(
    const YAML::Node& component,
    std::unordered_map<std::string, Real>& numeric_params,
    std::unordered_map<std::string, std::string>& metadata) {
    auto ingest_map = [&](const YAML::Node& node, bool include_reserved) {
        if (!node || !node.IsMap()) return;
        for (const auto& it : node) {
            const std::string key = it.first.as<std::string>();
            if (!include_reserved &&
                (key == "type" || key == "name" || key == "nodes" || key == "params")) {
                continue;
            }

            const YAML::Node value = it.second;
            if (!value || value.IsNull()) continue;

            if (value.IsScalar()) {
                try {
                    const std::string as_text = value.as<std::string>();
                    numeric_params[key] = parse_real_string(as_text);
                } catch (...) {
                    try {
                        metadata[key] = value.as<std::string>();
                    } catch (...) {
                        metadata[key] = YAML::Dump(value);
                    }
                }
                continue;
            }

            metadata[key] = YAML::Dump(value);
        }
    };

    ingest_map(component, false);
    ingest_map(component["params"], true);
}

void validate_keys(const YAML::Node& node,
                   const std::unordered_set<std::string>& allowed,
                   const std::string& context,
                   std::vector<std::string>& errors,
                   bool strict) {
    if (!strict || !node || !node.IsMap()) return;
    for (const auto& it : node) {
        const std::string key = it.first.as<std::string>();
        if (!is_known_key(key, allowed)) {
            push_error(errors,
                       kDiagUnknownField,
                       "Unknown field at '" + context + "." + key + "'");
        }
    }
}

Real parse_real_string(const std::string& raw) {
    if (raw.empty()) return 0.0;

    char* end = nullptr;
    const double base = std::strtod(raw.c_str(), &end);
    if (end == raw.c_str()) {
        throw std::invalid_argument("invalid numeric value");
    }

    std::string suffix = raw.substr(static_cast<std::size_t>(end - raw.c_str()));
    auto is_space = [](unsigned char c) { return std::isspace(c) != 0; };
    while (!suffix.empty() && is_space(static_cast<unsigned char>(suffix.front()))) {
        suffix.erase(suffix.begin());
    }
    while (!suffix.empty() && is_space(static_cast<unsigned char>(suffix.back()))) {
        suffix.pop_back();
    }
    if (suffix.empty()) return base;

    const std::string lower = to_lower(suffix);
    auto starts_with = [&](const std::string& prefix) {
        return lower.rfind(prefix, 0) == 0;
    };

    double multiplier = 1.0;
    if (starts_with("tera") || starts_with("t")) {
        multiplier = 1e12;
    } else if (starts_with("giga") || starts_with("g")) {
        multiplier = 1e9;
    } else if (starts_with("mega") || starts_with("meg") ||
               (!suffix.empty() && suffix.front() == 'M')) {
        multiplier = 1e6;
    } else if (starts_with("kilo") || starts_with("k")) {
        multiplier = 1e3;
    } else if (starts_with("milli")) {
        multiplier = 1e-3;
    } else if (starts_with("micro") || starts_with("u")) {
        multiplier = 1e-6;
    } else if (starts_with("nano") || starts_with("n")) {
        multiplier = 1e-9;
    } else if (starts_with("pico") || starts_with("p")) {
        multiplier = 1e-12;
    } else if (starts_with("femto") || starts_with("f")) {
        multiplier = 1e-15;
    } else if (starts_with("m")) {
        multiplier = 1e-3;
    }

    return base * multiplier;
}

Real parse_real(const YAML::Node& node,
                const std::string& context,
                std::vector<std::string>& errors) {
    if (!node || node.IsNull()) {
        return 0.0;
    }

    if (!node.IsScalar()) {
        push_type_mismatch_error(errors, context, "number", node);
        return 0.0;
    }

    try {
        const std::string raw = node.as<std::string>();
        return parse_real_string(raw);
    } catch (...) {
        push_type_mismatch_error(errors, context, "number", node);
    }

    return 0.0;
}

std::vector<std::string> parse_nodes(const YAML::Node& node,
                                     const std::string& context,
                                     std::vector<std::string>& errors) {
    std::vector<std::string> nodes;
    if (!node || !node.IsSequence()) {
        if (!node) {
            push_error(errors, kDiagInvalidPinCount, "Missing nodes in component '" + context + "'");
        } else {
            push_type_mismatch_error(errors, context + ".nodes", "sequence", node);
        }
        return nodes;
    }

    for (const auto& n : node) {
        nodes.push_back(n.as<std::string>());
    }

    return nodes;
}

std::vector<Real> parse_real_sequence(const YAML::Node& node,
                                      const std::string& context,
                                      std::vector<std::string>& errors) {
    std::vector<Real> values;
    if (!node) {
        return values;
    }
    if (!node.IsSequence()) {
        push_type_mismatch_error(errors, context, "sequence", node);
        return values;
    }

    values.reserve(node.size());
    for (std::size_t i = 0; i < node.size(); ++i) {
        values.push_back(parse_real(node[i], context + "[" + std::to_string(i) + "]", errors));
    }
    return values;
}

[[nodiscard]] bool is_strictly_increasing(const std::vector<Real>& values) {
    if (values.empty()) {
        return false;
    }
    for (std::size_t i = 0; i < values.size(); ++i) {
        if (!std::isfinite(values[i])) {
            return false;
        }
        if (i > 0 && !(values[i] > values[i - 1])) {
            return false;
        }
    }
    return true;
}

YAML::Node merge_nodes(const YAML::Node& base, const YAML::Node& overrides) {
    if (!base) return overrides;
    if (!overrides) return base;

    if (!base.IsMap() || !overrides.IsMap()) {
        return overrides;
    }

    YAML::Node result(YAML::NodeType::Map);
    for (const auto& it : base) {
        result[it.first.as<std::string>()] = it.second;
    }
    for (const auto& it : overrides) {
        const std::string key = it.first.as<std::string>();
        if (result[key] && result[key].IsMap() && it.second.IsMap()) {
            result[key] = merge_nodes(result[key], it.second);
        } else {
            result[key] = it.second;
        }
    }
    return result;
}

}  // namespace

/**
 * @brief Creates parser instance with strict/lenient behavior options.
 * @param options Parser behavior options.
 */
YamlParser::YamlParser(YamlParserOptions options)
    : options_(options) {}

/**
 * @brief Loads YAML netlist from file path.
 * @param path Source YAML file path.
 * @return Pair `(Circuit, SimulationOptions)`; parser errors are exposed via `errors()`.
 */
std::pair<Circuit, SimulationOptions> YamlParser::load(const std::filesystem::path& path) {
    std::ifstream file(path);
    if (!file.is_open()) {
        errors_.push_back("Cannot open file: " + path.string());
        return {Circuit(), SimulationOptions()};
    }

    std::stringstream buffer;
    buffer << file.rdbuf();
    return load_string(buffer.str());
}

/**
 * @brief Loads YAML netlist from in-memory string.
 * @param content YAML document string.
 * @return Pair `(Circuit, SimulationOptions)`; parser errors are exposed via `errors()`.
 */
std::pair<Circuit, SimulationOptions> YamlParser::load_string(const std::string& content) {
    Circuit circuit;
    SimulationOptions options;
    errors_.clear();
    warnings_.clear();

    parse_yaml(content, circuit, options);
    return {circuit, options};
}

/**
 * @brief Parses YAML document into runtime circuit and simulation options.
 * @param content YAML netlist content.
 * @param circuit Output runtime circuit.
 * @param options Output simulation options.
 */
void YamlParser::parse_yaml(const std::string& content, Circuit& circuit, SimulationOptions& options) {
    const auto first_non_space = content.find_first_not_of(" \t\r\n");
    if (first_non_space != std::string::npos) {
        const char first = content[first_non_space];
        if ((first == '{' || first == '[') && content.find('"') != std::string::npos) {
            errors_.push_back(
                "JSON netlists are unsupported in the v1 YAML parser. "
                "Migrate to pulsim-v1 YAML netlists (see docs/refactor-python-only-v1-hardening/runtime-surface.md).");
            return;
        }
    }

    YAML::Node root;
    try {
        root = YAML::Load(content);
    } catch (const std::exception& e) {
        errors_.push_back(std::string("YAML parse error: ") + e.what());
        return;
    }

    validate_keys(root, {"schema", "version", "simulation", "models", "components"},
                  "root", errors_, options_.strict);

    if (!root["schema"]) {
        errors_.push_back("Missing required field 'schema'");
        return;
    }
    if (!root["version"]) {
        errors_.push_back("Missing required field 'version'");
        return;
    }

    const std::optional<std::string> schema = parse_string_scalar(root["schema"], "root.schema", errors_);
    if (!schema) {
        return;
    }
    if (*schema != kSchemaId) {
        errors_.push_back("Unsupported schema: " + *schema);
        return;
    }

    const std::optional<int> version = parse_int_scalar(root["version"], "root.version", errors_);
    if (!version) {
        return;
    }
    const int schema_version = *version;
    if (schema_version != 1) {
        errors_.push_back("Unsupported schema version: " + std::to_string(schema_version));
        return;
    }

    // Simulation options
    if (root["simulation"]) {
        YAML::Node sim = root["simulation"];
        validate_keys(sim, {"tstart", "tstop", "dt", "dt_min", "dt_max", "step_mode", "adaptive_timestep",
                            "enable_events", "enable_losses", "integrator", "integration", "newton", "timestep",
                            "lte", "bdf", "solver", "shooting", "harmonic_balance", "hb", "thermal",
                            "max_step_retries", "fallback", "model_regularization", "formulation",
                            "direct_formulation_fallback", "control", "control_mode", "control_sample_time",
                            "frequency_analysis", "ac_sweep", "averaged_converter", "post_processing"},
                      "simulation", errors_, options_.strict);

        if (sim["tstart"]) options.tstart = parse_real(sim["tstart"], "simulation.tstart", errors_);
        if (sim["tstop"]) options.tstop = parse_real(sim["tstop"], "simulation.tstop", errors_);
        if (sim["dt"]) options.dt = parse_real(sim["dt"], "simulation.dt", errors_);
        const bool dt_min_explicit = static_cast<bool>(sim["dt_min"]);
        const bool dt_max_explicit = static_cast<bool>(sim["dt_max"]);
        if (sim["dt_min"]) options.dt_min = parse_real(sim["dt_min"], "simulation.dt_min", errors_);
        if (sim["dt_max"]) options.dt_max = parse_real(sim["dt_max"], "simulation.dt_max", errors_);

        if (sim["step_mode"]) {
            try {
                const std::optional<std::string> step_mode_raw =
                    parse_string_scalar(sim["step_mode"], "simulation.step_mode", errors_);
                if (!step_mode_raw) {
                    throw std::runtime_error("invalid_step_mode_type");
                }
                const std::string mode = normalize_key(*step_mode_raw);
                if (mode == "fixed") {
                    apply_mode_derived_defaults(
                        options, TransientStepMode::Fixed, dt_min_explicit, dt_max_explicit);
                } else if (mode == "variable" || mode == "adaptive") {
                    apply_mode_derived_defaults(
                        options, TransientStepMode::Variable, dt_min_explicit, dt_max_explicit);
                } else {
                    push_error(errors_,
                               kDiagInvalidStepMode,
                               "Invalid simulation.step_mode: " + sim["step_mode"].as<std::string>() +
                                   " (expected 'fixed' or 'variable')");
                }
            } catch (...) {
                if (std::none_of(errors_.begin(), errors_.end(), [](const std::string& err) {
                        return err.find("simulation.step_mode") != std::string::npos &&
                               err.find(kDiagTypeMismatch) != std::string::npos;
                    })) {
                    push_error(errors_,
                               kDiagInvalidStepMode,
                               "Invalid simulation.step_mode (expected 'fixed' or 'variable')");
                }
            }
        }

        if (sim["control"]) {
            validate_keys(sim["control"], {"mode", "sample_time"},
                          "simulation.control", errors_, options_.strict);
        }

        YAML::Node control_mode_node = sim["control_mode"];
        std::string control_mode_path = "simulation.control_mode";
        if (!control_mode_node && sim["control"] && sim["control"]["mode"]) {
            control_mode_node = sim["control"]["mode"];
            control_mode_path = "simulation.control.mode";
        }
        if (control_mode_node) {
            const auto mode_raw = parse_string_scalar(control_mode_node, control_mode_path, errors_);
            if (mode_raw) {
                const std::string mode = normalize_key(*mode_raw);
                if (mode == "auto") {
                    options.control_mode = ControlUpdateMode::Auto;
                } else if (mode == "continuous" || mode == "analog") {
                    options.control_mode = ControlUpdateMode::Continuous;
                } else if (mode == "discrete" || mode == "sampled" || mode == "digital") {
                    options.control_mode = ControlUpdateMode::Discrete;
                } else {
                    push_error(
                        errors_,
                        kDiagInvalidParameter,
                        "Invalid " + control_mode_path + ": '" + *mode_raw +
                            "' (expected 'auto', 'continuous', or 'discrete')");
                }
            }
        }

        YAML::Node control_sample_time_node = sim["control_sample_time"];
        std::string control_sample_time_path = "simulation.control_sample_time";
        if (!control_sample_time_node && sim["control"] && sim["control"]["sample_time"]) {
            control_sample_time_node = sim["control"]["sample_time"];
            control_sample_time_path = "simulation.control.sample_time";
        }
        if (control_sample_time_node) {
            options.control_sample_time =
                parse_real(control_sample_time_node, control_sample_time_path, errors_);
            if (!std::isfinite(options.control_sample_time) || options.control_sample_time < 0.0) {
                push_error(
                    errors_,
                    kDiagInvalidParameter,
                    control_sample_time_path + " must be finite and >= 0");
            }
        }
        if (options.control_mode == ControlUpdateMode::Discrete &&
            !(std::isfinite(options.control_sample_time) && options.control_sample_time > 0.0)) {
            push_error(
                errors_,
                kDiagInvalidParameter,
                "simulation.control_sample_time must be > 0 when simulation.control_mode is 'discrete'");
        }

        YAML::Node formulation = sim["formulation"];
        if (formulation) {
            const std::string formulation_path = "simulation.formulation";
            const auto formulation_raw = parse_string_scalar(formulation, formulation_path, errors_);
            if (formulation_raw) {
                const std::string mode = normalize_key(*formulation_raw);
                if (mode == "projectedwrapper" || mode == "projected" || mode == "native") {
                    options.formulation_mode = FormulationMode::ProjectedWrapper;
                } else if (mode == "direct" || mode == "directdae" || mode == "dae") {
                    options.formulation_mode = FormulationMode::Direct;
                } else {
                    push_error(
                        errors_,
                        kDiagInvalidParameter,
                        "Invalid " + formulation_path + ": '" + *formulation_raw +
                            "' (expected 'projected_wrapper' or 'direct')");
                }
            }
        }

        YAML::Node direct_formulation_fallback = sim["direct_formulation_fallback"];
        if (direct_formulation_fallback) {
            const std::string fallback_path = "simulation.direct_formulation_fallback";
            if (const auto value = parse_bool_scalar(direct_formulation_fallback, fallback_path, errors_)) {
                options.direct_formulation_fallback = *value;
            }
        }

        YAML::Node adaptive_timestep = sim["adaptive_timestep"];
        if (adaptive_timestep) {
            const std::string adaptive_path = "simulation.adaptive_timestep";
            if (!sim["step_mode"]) {
                push_deprecated_field_migration_warning(
                    warnings_,
                    adaptive_path,
                    "simulation.step_mode: fixed|variable");
            }
            if (const auto adaptive = parse_bool_scalar(adaptive_timestep, adaptive_path, errors_)) {
                options.adaptive_timestep = *adaptive;
            }
        }
        if (sim["enable_events"]) {
            if (const auto value = parse_bool_scalar(sim["enable_events"], "simulation.enable_events", errors_)) {
                options.enable_events = *value;
            }
        }
        if (sim["enable_losses"]) {
            if (const auto value = parse_bool_scalar(sim["enable_losses"], "simulation.enable_losses", errors_)) {
                options.enable_losses = *value;
            }
        }
        if (sim["max_step_retries"]) {
            if (const auto value = parse_int_scalar(sim["max_step_retries"], "simulation.max_step_retries", errors_)) {
                options.max_step_retries = *value;
            }
        }

        if (sim["thermal"]) {
            YAML::Node thermal = sim["thermal"];
            validate_keys(thermal, {"enabled", "ambient", "policy", "default_rth", "default_cth"},
                          "simulation.thermal", errors_, options_.strict);
            options.thermal.enable = true;
            if (const auto enabled = parse_bool_scalar(
                    thermal["enabled"], "simulation.thermal.enabled", errors_)) {
                options.thermal.enable = *enabled;
            }
            if (thermal["ambient"]) options.thermal.ambient = parse_real(thermal["ambient"], "simulation.thermal.ambient", errors_);
            if (thermal["default_rth"]) options.thermal.default_rth = parse_real(thermal["default_rth"], "simulation.thermal.default_rth", errors_);
            if (thermal["default_cth"]) options.thermal.default_cth = parse_real(thermal["default_cth"], "simulation.thermal.default_cth", errors_);
            if (!std::isfinite(options.thermal.ambient)) {
                push_error(errors_, kDiagThermalInvalidRange,
                           "simulation.thermal.ambient must be finite");
            }
            if (!std::isfinite(options.thermal.default_rth) || options.thermal.default_rth <= 0.0) {
                push_error(errors_, kDiagThermalInvalidRange,
                           "simulation.thermal.default_rth must be finite and > 0");
            }
            if (!std::isfinite(options.thermal.default_cth) || options.thermal.default_cth < 0.0) {
                push_error(errors_, kDiagThermalInvalidRange,
                           "simulation.thermal.default_cth must be finite and >= 0");
            }
            if (thermal["policy"]) {
                const std::string policy = normalize_key(thermal["policy"].as<std::string>());
                if (policy == "lossonly") {
                    options.thermal.policy = ThermalCouplingPolicy::LossOnly;
                } else if (policy == "losswithtemperaturescaling" ||
                           policy == "losswithscaling") {
                    options.thermal.policy = ThermalCouplingPolicy::LossWithTemperatureScaling;
                } else {
                    errors_.push_back("Invalid thermal policy: " + thermal["policy"].as<std::string>());
                }
            }
        }

        YAML::Node fallback_root = sim["fallback"];
        if (fallback_root) {
            YAML::Node fallback = fallback_root;
            validate_keys(fallback, {"trace_retries", "enable_transient_gmin",
                                     "gmin_retry_threshold", "gmin_initial",
                                     "gmin_max", "gmin_growth",
                                     "convergence_profile", "policy_dry_run",
                                     "anti_overfit_check", "anti_overfit_stable_budget"},
                          "simulation.fallback", errors_, options_.strict);
            if (fallback["trace_retries"]) {
                options.fallback_policy.trace_retries = fallback["trace_retries"].as<bool>();
            }
            if (const auto profile_value = parse_string_scalar(
                    fallback["convergence_profile"],
                    "simulation.fallback.convergence_profile",
                    errors_)) {
                const std::string profile = normalize_key(*profile_value);
                if (profile == "strict") {
                    options.fallback_policy.convergence_profile = ConvergenceProfile::Strict;
                } else if (profile == "balanced") {
                    options.fallback_policy.convergence_profile = ConvergenceProfile::Balanced;
                } else if (profile == "robust") {
                    options.fallback_policy.convergence_profile = ConvergenceProfile::Robust;
                } else {
                    push_error(errors_, kDiagInvalidParameter,
                               "simulation.fallback.convergence_profile must be one of: strict, balanced, robust");
                }
            }
            if (const auto value = parse_bool_scalar(
                    fallback["policy_dry_run"],
                    "simulation.fallback.policy_dry_run",
                    errors_)) {
                options.fallback_policy.policy_dry_run = *value;
            }
            if (const auto value = parse_bool_scalar(
                    fallback["anti_overfit_check"],
                    "simulation.fallback.anti_overfit_check",
                    errors_)) {
                options.fallback_policy.anti_overfit_check = *value;
            }
            if (const auto value = parse_int_scalar(
                    fallback["anti_overfit_stable_budget"],
                    "simulation.fallback.anti_overfit_stable_budget",
                    errors_)) {
                if (*value < 0) {
                    push_error(errors_, kDiagInvalidParameter,
                               "simulation.fallback.anti_overfit_stable_budget must be >= 0");
                } else {
                    options.fallback_policy.anti_overfit_stable_budget = *value;
                }
            }
            if (fallback["enable_transient_gmin"]) {
                options.fallback_policy.enable_transient_gmin = fallback["enable_transient_gmin"].as<bool>();
            }
            if (fallback["gmin_retry_threshold"]) {
                options.fallback_policy.gmin_retry_threshold = fallback["gmin_retry_threshold"].as<int>();
            }
            if (fallback["gmin_initial"]) {
                options.fallback_policy.gmin_initial = parse_real(fallback["gmin_initial"], "simulation.fallback.gmin_initial", errors_);
            }
            if (fallback["gmin_max"]) {
                options.fallback_policy.gmin_max = parse_real(fallback["gmin_max"], "simulation.fallback.gmin_max", errors_);
            }
            if (fallback["gmin_growth"]) {
                options.fallback_policy.gmin_growth = parse_real(fallback["gmin_growth"], "simulation.fallback.gmin_growth", errors_);
            }
        }

        if (sim["model_regularization"]) {
            YAML::Node reg = sim["model_regularization"];
            validate_keys(reg,
                          {"enable_auto", "apply_only_in_recovery", "retry_threshold",
                           "max_escalations", "escalation_factor", "mosfet_kp_max",
                           "mosfet_g_off_min", "diode_g_on_max", "diode_g_off_min",
                           "igbt_g_on_max", "igbt_g_off_min", "switch_g_on_max",
                           "switch_g_off_min", "vcswitch_g_on_max", "vcswitch_g_off_min"},
                          "simulation.model_regularization", errors_, options_.strict);

            if (const auto value = parse_bool_scalar(
                    reg["enable_auto"], "simulation.model_regularization.enable_auto", errors_)) {
                options.model_regularization.enable_auto = *value;
            }
            if (const auto value = parse_bool_scalar(
                    reg["apply_only_in_recovery"],
                    "simulation.model_regularization.apply_only_in_recovery",
                    errors_)) {
                options.model_regularization.apply_only_in_recovery = *value;
            }
            if (const auto value = parse_int_scalar(
                    reg["retry_threshold"], "simulation.model_regularization.retry_threshold", errors_)) {
                if (*value < 1) {
                    push_error(errors_,
                               kDiagInvalidParameter,
                               "simulation.model_regularization.retry_threshold must be >= 1");
                } else {
                    options.model_regularization.retry_threshold = *value;
                }
            }
            if (const auto value = parse_int_scalar(
                    reg["max_escalations"], "simulation.model_regularization.max_escalations", errors_)) {
                if (*value < 0) {
                    push_error(errors_,
                               kDiagInvalidParameter,
                               "simulation.model_regularization.max_escalations must be >= 0");
                } else {
                    options.model_regularization.max_escalations = *value;
                }
            }

            auto parse_positive_real = [&](const char* key,
                                           Real& target,
                                           bool allow_zero = false) {
                if (!reg[key]) {
                    return;
                }
                const std::string path = std::string("simulation.model_regularization.") + key;
                const Real value = parse_real(reg[key], path, errors_);
                const bool valid = allow_zero ? value >= 0.0 : value > 0.0;
                if (!std::isfinite(value) || !valid) {
                    push_error(errors_,
                               kDiagInvalidParameter,
                               path + (allow_zero ? " must be >= 0" : " must be > 0"));
                    return;
                }
                target = value;
            };

            parse_positive_real("escalation_factor", options.model_regularization.escalation_factor);
            parse_positive_real("mosfet_kp_max", options.model_regularization.mosfet_kp_max);
            parse_positive_real("mosfet_g_off_min", options.model_regularization.mosfet_g_off_min, true);
            parse_positive_real("diode_g_on_max", options.model_regularization.diode_g_on_max);
            parse_positive_real("diode_g_off_min", options.model_regularization.diode_g_off_min, true);
            parse_positive_real("igbt_g_on_max", options.model_regularization.igbt_g_on_max);
            parse_positive_real("igbt_g_off_min", options.model_regularization.igbt_g_off_min, true);
            parse_positive_real("switch_g_on_max", options.model_regularization.switch_g_on_max);
            parse_positive_real("switch_g_off_min", options.model_regularization.switch_g_off_min, true);
            parse_positive_real("vcswitch_g_on_max", options.model_regularization.vcswitch_g_on_max);
            parse_positive_real("vcswitch_g_off_min", options.model_regularization.vcswitch_g_off_min, true);
        }

        YAML::Node integrator_node = sim["integrator"];
        if (!integrator_node) {
            integrator_node = sim["integration"];
        }
        if (integrator_node) {
            std::string method = normalize_key(integrator_node.as<std::string>());
            if (method == "trapezoidal" || method == "tr") {
                options.integrator = Integrator::Trapezoidal;
            } else if (method == "bdf1" || method == "be" || method == "backwardeuler") {
                options.integrator = Integrator::BDF1;
            } else if (method == "bdf2") {
                options.integrator = Integrator::BDF2;
            } else if (method == "bdf3") {
                options.integrator = Integrator::BDF3;
            } else if (method == "bdf4") {
                options.integrator = Integrator::BDF4;
            } else if (method == "bdf5") {
                options.integrator = Integrator::BDF5;
            } else if (method == "gear") {
                options.integrator = Integrator::Gear;
            } else if (method == "trbdf2") {
                options.integrator = Integrator::TRBDF2;
            } else if (method == "rosenbrock" || method == "rosenbrockw" || method == "rosenbrockw2") {
                options.integrator = Integrator::RosenbrockW;
            } else if (method == "sdirk2") {
                options.integrator = Integrator::SDIRK2;
            } else {
                errors_.push_back("Invalid integrator: " + integrator_node.as<std::string>());
            }
        }

        YAML::Node newton = sim["newton"];
        if (newton) {
            YAML::Node n = newton;
            validate_keys(n, {"max_iterations", "initial_damping", "min_damping", "auto_damping",
                              "enable_anderson", "anderson_depth", "anderson_beta",
                              "enable_broyden", "broyden_max_size", "enable_newton_krylov",
                              "enable_trust_region", "trust_radius", "trust_shrink", "trust_expand",
                              "trust_min", "trust_max", "reuse_jacobian_pattern",
                              "krylov_residual_cache_tolerance", "enable_limiting", "max_voltage_step"},
                          "simulation.newton", errors_, options_.strict);
            if (n["max_iterations"]) options.newton_options.max_iterations = n["max_iterations"].as<int>();
            if (n["initial_damping"]) options.newton_options.initial_damping = parse_real(n["initial_damping"], "newton.initial_damping", errors_);
            if (n["min_damping"]) options.newton_options.min_damping = parse_real(n["min_damping"], "newton.min_damping", errors_);
            if (n["auto_damping"]) options.newton_options.auto_damping = n["auto_damping"].as<bool>();
            if (n["enable_anderson"]) options.newton_options.enable_anderson = n["enable_anderson"].as<bool>();
            if (n["anderson_depth"]) options.newton_options.anderson_depth = n["anderson_depth"].as<int>();
            if (n["anderson_beta"]) options.newton_options.anderson_beta = parse_real(n["anderson_beta"], "newton.anderson_beta", errors_);
            if (n["enable_broyden"]) options.newton_options.enable_broyden = n["enable_broyden"].as<bool>();
            if (n["broyden_max_size"]) options.newton_options.broyden_max_size = n["broyden_max_size"].as<int>();
            if (n["enable_newton_krylov"]) options.newton_options.enable_newton_krylov = n["enable_newton_krylov"].as<bool>();
            if (n["enable_trust_region"]) options.newton_options.enable_trust_region = n["enable_trust_region"].as<bool>();
            if (n["trust_radius"]) options.newton_options.trust_radius = parse_real(n["trust_radius"], "newton.trust_radius", errors_);
            if (n["trust_shrink"]) options.newton_options.trust_shrink = parse_real(n["trust_shrink"], "newton.trust_shrink", errors_);
            if (n["trust_expand"]) options.newton_options.trust_expand = parse_real(n["trust_expand"], "newton.trust_expand", errors_);
            if (n["trust_min"]) options.newton_options.trust_min = parse_real(n["trust_min"], "newton.trust_min", errors_);
            if (n["trust_max"]) options.newton_options.trust_max = parse_real(n["trust_max"], "newton.trust_max", errors_);
            if (n["reuse_jacobian_pattern"]) options.newton_options.reuse_jacobian_pattern = n["reuse_jacobian_pattern"].as<bool>();
            if (n["krylov_residual_cache_tolerance"]) {
                options.newton_options.krylov_residual_cache_tolerance =
                    parse_real(n["krylov_residual_cache_tolerance"], "newton.krylov_residual_cache_tolerance", errors_);
            }
        }

        YAML::Node timestep = sim["timestep"];
        if (timestep) {
            YAML::Node t = timestep;
            validate_keys(t, {"preset", "dt_min", "dt_max", "error_tolerance", "target_newton_iterations"},
                          "simulation.timestep", errors_, options_.strict);
            auto apply_base = [&](const TimestepConfig& base) {
                options.timestep_config.dt_min = base.dt_min;
                options.timestep_config.dt_max = base.dt_max;
                options.timestep_config.dt_initial = base.dt_initial;
                options.timestep_config.safety_factor = base.safety_factor;
                options.timestep_config.error_tolerance = base.error_tolerance;
                options.timestep_config.growth_factor = base.growth_factor;
                options.timestep_config.shrink_factor = base.shrink_factor;
                options.timestep_config.max_rejections = base.max_rejections;
                options.timestep_config.k_p = base.k_p;
                options.timestep_config.k_i = base.k_i;
            };
            if (t["preset"]) {
                std::string preset = to_lower(t["preset"].as<std::string>());
                if (preset == "conservative") {
                    apply_base(TimestepConfig::conservative());
                } else if (preset == "aggressive") {
                    apply_base(TimestepConfig::aggressive());
                } else if (preset == "power_electronics") {
                    options.timestep_config = AdvancedTimestepConfig::for_power_electronics();
                }
            }
            if (t["dt_min"]) options.timestep_config.dt_min = parse_real(t["dt_min"], "timestep.dt_min", errors_);
            if (t["dt_max"]) options.timestep_config.dt_max = parse_real(t["dt_max"], "timestep.dt_max", errors_);
            if (t["error_tolerance"]) options.timestep_config.error_tolerance = parse_real(t["error_tolerance"], "timestep.error_tolerance", errors_);
            if (t["target_newton_iterations"]) options.timestep_config.target_newton_iterations = t["target_newton_iterations"].as<int>();
        }

        YAML::Node lte = sim["lte"];
        if (lte) {
            YAML::Node l = lte;
            validate_keys(l, {"method", "voltage_tolerance", "current_tolerance"},
                          "simulation.lte", errors_, options_.strict);
            if (l["method"]) {
                std::string method = to_lower(l["method"].as<std::string>());
                options.lte_config.method = (method == "step_doubling") ?
                    TimestepMethod::StepDoubling : TimestepMethod::Richardson;
            }
            if (l["voltage_tolerance"]) options.lte_config.voltage_tolerance = parse_real(l["voltage_tolerance"], "lte.voltage_tolerance", errors_);
            if (l["current_tolerance"]) options.lte_config.current_tolerance = parse_real(l["current_tolerance"], "lte.current_tolerance", errors_);
        }

        YAML::Node bdf = sim["bdf"];
        if (bdf) {
            YAML::Node b = bdf;
            validate_keys(b, {"enable", "min_order", "max_order", "initial_order"},
                          "simulation.bdf", errors_, options_.strict);
            if (b["enable"]) options.enable_bdf_order_control = b["enable"].as<bool>();
            if (b["min_order"]) options.bdf_config.min_order = b["min_order"].as<int>();
            if (b["max_order"]) options.bdf_config.max_order = b["max_order"].as<int>();
            if (b["initial_order"]) options.bdf_config.initial_order = b["initial_order"].as<int>();
        }

        YAML::Node solver = sim["solver"];
        if (solver) {
            YAML::Node s = solver;
            validate_keys(s, {"linear", "iterative", "nonlinear", "order", "fallback_order",
                              "allow_fallback", "auto_select", "size_threshold", "nnz_threshold",
                              "diag_min_threshold", "preconditioner", "ilut_drop_tolerance",
                              "ilut_fill_factor", "enable_health_policy", "health_error_threshold",
                              "health_iteration_ratio_threshold", "health_streak_threshold",
                              "health_prefer_direct"},
                          "simulation.solver", errors_, options_.strict);

            auto parse_linear_kind = [&](const std::string& value, const std::string& path) -> std::optional<LinearSolverKind> {
                std::string v = to_lower(value);
                if (v == "klu") return LinearSolverKind::KLU;
                if (v == "sparse_lu" || v == "sparselu" || v == "sparse") return LinearSolverKind::SparseLU;
                if (v == "enhanced_sparse_lu" || v == "enhanced" || v == "enhanced_sparselu") return LinearSolverKind::EnhancedSparseLU;
                if (v == "gmres") return LinearSolverKind::GMRES;
                if (v == "bicgstab" || v == "bicg") return LinearSolverKind::BiCGSTAB;
                if (v == "cg" || v == "conjugate_gradient") return LinearSolverKind::CG;
                errors_.push_back("Invalid solver kind for " + path + ": " + value);
                return std::nullopt;
            };

            auto parse_order = [&](const YAML::Node& node, const std::string& path,
                                   std::vector<LinearSolverKind>& target) {
                if (!node.IsSequence()) {
                    errors_.push_back(path + " must be a list");
                    return;
                }
                target.clear();
                for (const auto& it : node) {
                    if (!it.IsScalar()) {
                        errors_.push_back(path + " entries must be strings");
                        continue;
                    }
                    auto kind = parse_linear_kind(it.as<std::string>(), path);
                    if (kind) target.push_back(*kind);
                }
            };

            if (s["order"]) {
                parse_order(s["order"], "simulation.solver.order", options.linear_solver.order);
            }
            if (s["fallback_order"]) {
                parse_order(s["fallback_order"], "simulation.solver.fallback_order",
                            options.linear_solver.fallback_order);
            }
            if (s["allow_fallback"]) options.linear_solver.allow_fallback = s["allow_fallback"].as<bool>();
            if (s["auto_select"]) options.linear_solver.auto_select = s["auto_select"].as<bool>();
            if (s["size_threshold"]) options.linear_solver.size_threshold = s["size_threshold"].as<int>();
            if (s["nnz_threshold"]) options.linear_solver.nnz_threshold = s["nnz_threshold"].as<int>();
            if (s["diag_min_threshold"]) options.linear_solver.diag_min_threshold = parse_real(s["diag_min_threshold"], "solver.diag_min_threshold", errors_);
            if (s["enable_health_policy"]) {
                options.linear_solver.enable_health_policy = s["enable_health_policy"].as<bool>();
            }
            if (s["health_error_threshold"]) {
                options.linear_solver.health_error_threshold =
                    parse_real(s["health_error_threshold"], "solver.health_error_threshold", errors_);
            }
            if (s["health_iteration_ratio_threshold"]) {
                options.linear_solver.health_iteration_ratio_threshold = parse_real(
                    s["health_iteration_ratio_threshold"],
                    "solver.health_iteration_ratio_threshold",
                    errors_);
            }
            if (s["health_streak_threshold"]) {
                options.linear_solver.health_streak_threshold = s["health_streak_threshold"].as<int>();
            }
            if (s["health_prefer_direct"]) {
                options.linear_solver.health_prefer_direct = s["health_prefer_direct"].as<bool>();
            }

            if (s["preconditioner"]) {
                std::string pre = to_lower(s["preconditioner"].as<std::string>());
                if (pre == "none") {
                    options.linear_solver.iterative_config.preconditioner = IterativeSolverConfig::PreconditionerKind::None;
                } else if (pre == "jacobi") {
                    options.linear_solver.iterative_config.preconditioner = IterativeSolverConfig::PreconditionerKind::Jacobi;
                } else if (pre == "ilu0" || pre == "ilu") {
                    options.linear_solver.iterative_config.preconditioner = IterativeSolverConfig::PreconditionerKind::ILU0;
                } else if (pre == "ilut") {
                    options.linear_solver.iterative_config.preconditioner = IterativeSolverConfig::PreconditionerKind::ILUT;
                } else if (pre == "amg") {
                    options.linear_solver.iterative_config.preconditioner = IterativeSolverConfig::PreconditionerKind::AMG;
                } else {
                    errors_.push_back("Invalid solver.preconditioner: " + pre);
                }
            }
            if (s["ilut_drop_tolerance"]) {
                options.linear_solver.iterative_config.ilut_drop_tolerance =
                    parse_real(s["ilut_drop_tolerance"], "solver.ilut_drop_tolerance", errors_);
            }
            if (s["ilut_fill_factor"]) {
                options.linear_solver.iterative_config.ilut_fill_factor =
                    parse_real(s["ilut_fill_factor"], "solver.ilut_fill_factor", errors_);
            }

            if (s["linear"]) {
                YAML::Node l = s["linear"];
                validate_keys(l, {"order", "allow_fallback", "auto_select", "size_threshold",
                                  "nnz_threshold", "diag_min_threshold", "enable_health_policy",
                                  "health_error_threshold", "health_iteration_ratio_threshold",
                                  "health_streak_threshold", "health_prefer_direct"},
                              "simulation.solver.linear", errors_, options_.strict);
                if (l["order"]) parse_order(l["order"], "simulation.solver.linear.order",
                                            options.linear_solver.order);
                if (l["allow_fallback"]) options.linear_solver.allow_fallback = l["allow_fallback"].as<bool>();
                if (l["auto_select"]) options.linear_solver.auto_select = l["auto_select"].as<bool>();
                if (l["size_threshold"]) options.linear_solver.size_threshold = l["size_threshold"].as<int>();
                if (l["nnz_threshold"]) options.linear_solver.nnz_threshold = l["nnz_threshold"].as<int>();
                if (l["diag_min_threshold"]) options.linear_solver.diag_min_threshold = parse_real(l["diag_min_threshold"], "solver.linear.diag_min_threshold", errors_);
                if (l["enable_health_policy"]) {
                    options.linear_solver.enable_health_policy = l["enable_health_policy"].as<bool>();
                }
                if (l["health_error_threshold"]) {
                    options.linear_solver.health_error_threshold =
                        parse_real(l["health_error_threshold"], "solver.linear.health_error_threshold", errors_);
                }
                if (l["health_iteration_ratio_threshold"]) {
                    options.linear_solver.health_iteration_ratio_threshold = parse_real(
                        l["health_iteration_ratio_threshold"],
                        "solver.linear.health_iteration_ratio_threshold",
                        errors_);
                }
                if (l["health_streak_threshold"]) {
                    options.linear_solver.health_streak_threshold = l["health_streak_threshold"].as<int>();
                }
                if (l["health_prefer_direct"]) {
                    options.linear_solver.health_prefer_direct = l["health_prefer_direct"].as<bool>();
                }
            }

            if (s["iterative"]) {
                YAML::Node it = s["iterative"];
                validate_keys(it, {"max_iterations", "tolerance", "restart", "preconditioner",
                                   "enable_scaling", "scaling_floor", "ilut_drop_tolerance",
                                   "ilut_fill_factor"},
                              "simulation.solver.iterative", errors_, options_.strict);
                if (it["max_iterations"]) options.linear_solver.iterative_config.max_iterations = it["max_iterations"].as<int>();
                if (it["tolerance"]) options.linear_solver.iterative_config.tolerance = parse_real(it["tolerance"], "solver.iterative.tolerance", errors_);
                if (it["restart"]) options.linear_solver.iterative_config.restart = it["restart"].as<int>();
                if (it["enable_scaling"]) options.linear_solver.iterative_config.enable_scaling = it["enable_scaling"].as<bool>();
                if (it["scaling_floor"]) options.linear_solver.iterative_config.scaling_floor = parse_real(it["scaling_floor"], "solver.iterative.scaling_floor", errors_);
                if (it["preconditioner"]) {
                    std::string pre = to_lower(it["preconditioner"].as<std::string>());
                    if (pre == "none") {
                        options.linear_solver.iterative_config.preconditioner = IterativeSolverConfig::PreconditionerKind::None;
                    } else if (pre == "jacobi") {
                        options.linear_solver.iterative_config.preconditioner = IterativeSolverConfig::PreconditionerKind::Jacobi;
                    } else if (pre == "ilu0" || pre == "ilu") {
                        options.linear_solver.iterative_config.preconditioner = IterativeSolverConfig::PreconditionerKind::ILU0;
                    } else if (pre == "ilut") {
                        options.linear_solver.iterative_config.preconditioner = IterativeSolverConfig::PreconditionerKind::ILUT;
                    } else if (pre == "amg") {
                        options.linear_solver.iterative_config.preconditioner = IterativeSolverConfig::PreconditionerKind::AMG;
                    } else {
                        errors_.push_back("Invalid solver.iterative.preconditioner: " + pre);
                    }
                }
                if (it["ilut_drop_tolerance"]) {
                    options.linear_solver.iterative_config.ilut_drop_tolerance =
                        parse_real(it["ilut_drop_tolerance"], "solver.iterative.ilut_drop_tolerance", errors_);
                }
                if (it["ilut_fill_factor"]) {
                    options.linear_solver.iterative_config.ilut_fill_factor =
                        parse_real(it["ilut_fill_factor"], "solver.iterative.ilut_fill_factor", errors_);
                }
            }

            if (s["nonlinear"]) {
                YAML::Node nl = s["nonlinear"];
                validate_keys(nl, {"anderson", "broyden", "newton_krylov", "trust_region", "reuse_jacobian_pattern"},
                              "simulation.solver.nonlinear", errors_, options_.strict);

                if (nl["anderson"]) {
                    YAML::Node a = nl["anderson"];
                    validate_keys(a, {"enable", "depth", "beta"},
                                  "simulation.solver.nonlinear.anderson", errors_, options_.strict);
                    if (a["enable"]) options.newton_options.enable_anderson = a["enable"].as<bool>();
                    if (a["depth"]) options.newton_options.anderson_depth = a["depth"].as<int>();
                    if (a["beta"]) options.newton_options.anderson_beta = parse_real(a["beta"], "solver.nonlinear.anderson.beta", errors_);
                }

                if (nl["broyden"]) {
                    YAML::Node b = nl["broyden"];
                    validate_keys(b, {"enable", "max_size"},
                                  "simulation.solver.nonlinear.broyden", errors_, options_.strict);
                    if (b["enable"]) options.newton_options.enable_broyden = b["enable"].as<bool>();
                    if (b["max_size"]) options.newton_options.broyden_max_size = b["max_size"].as<int>();
                }

                if (nl["newton_krylov"]) {
                    YAML::Node nk = nl["newton_krylov"];
                    validate_keys(nk, {"enable"},
                                  "simulation.solver.nonlinear.newton_krylov", errors_, options_.strict);
                    if (nk["enable"]) options.newton_options.enable_newton_krylov = nk["enable"].as<bool>();
                }

                if (nl["trust_region"]) {
                    YAML::Node tr = nl["trust_region"];
                    validate_keys(tr, {"enable", "radius", "shrink", "expand", "min", "max"},
                                  "simulation.solver.nonlinear.trust_region", errors_, options_.strict);
                    if (tr["enable"]) options.newton_options.enable_trust_region = tr["enable"].as<bool>();
                    if (tr["radius"]) options.newton_options.trust_radius = parse_real(tr["radius"], "solver.nonlinear.trust_region.radius", errors_);
                    if (tr["shrink"]) options.newton_options.trust_shrink = parse_real(tr["shrink"], "solver.nonlinear.trust_region.shrink", errors_);
                    if (tr["expand"]) options.newton_options.trust_expand = parse_real(tr["expand"], "solver.nonlinear.trust_region.expand", errors_);
                    if (tr["min"]) options.newton_options.trust_min = parse_real(tr["min"], "solver.nonlinear.trust_region.min", errors_);
                    if (tr["max"]) options.newton_options.trust_max = parse_real(tr["max"], "solver.nonlinear.trust_region.max", errors_);
                }

                if (nl["reuse_jacobian_pattern"]) {
                    options.newton_options.reuse_jacobian_pattern = nl["reuse_jacobian_pattern"].as<bool>();
                }
            }
        }

        enforce_mode_semantics(options);

        if (sim["shooting"]) {
            YAML::Node sh = sim["shooting"];
            validate_keys(sh, {"period", "max_iterations", "tolerance", "relaxation", "store_last_transient"},
                          "simulation.shooting", errors_, options_.strict);
            options.enable_periodic_shooting = true;
            if (sh["period"]) options.periodic_options.period = parse_real(sh["period"], "shooting.period", errors_);
            if (sh["max_iterations"]) options.periodic_options.max_iterations = sh["max_iterations"].as<int>();
            if (sh["tolerance"]) options.periodic_options.tolerance = parse_real(sh["tolerance"], "shooting.tolerance", errors_);
            if (sh["relaxation"]) options.periodic_options.relaxation = parse_real(sh["relaxation"], "shooting.relaxation", errors_);
            if (sh["store_last_transient"]) options.periodic_options.store_last_transient = sh["store_last_transient"].as<bool>();
        }

        YAML::Node hb = sim["harmonic_balance"] ? sim["harmonic_balance"] : sim["hb"];
        if (hb) {
            validate_keys(hb, {"period", "num_samples", "max_iterations", "tolerance",
                               "relaxation", "initialize_from_transient"},
                          "simulation.harmonic_balance", errors_, options_.strict);
            options.enable_harmonic_balance = true;
            if (hb["period"]) options.harmonic_balance.period = parse_real(hb["period"], "hb.period", errors_);
            if (hb["num_samples"]) options.harmonic_balance.num_samples = hb["num_samples"].as<int>();
            if (hb["max_iterations"]) options.harmonic_balance.max_iterations = hb["max_iterations"].as<int>();
            if (hb["tolerance"]) options.harmonic_balance.tolerance = parse_real(hb["tolerance"], "hb.tolerance", errors_);
            if (hb["relaxation"]) options.harmonic_balance.relaxation = parse_real(hb["relaxation"], "hb.relaxation", errors_);
            if (hb["initialize_from_transient"]) {
                options.harmonic_balance.initialize_from_transient =
                    hb["initialize_from_transient"].as<bool>();
            }
        }

        YAML::Node frequency = sim["frequency_analysis"] ? sim["frequency_analysis"] : sim["ac_sweep"];
        if (frequency) {
            validate_keys(
                frequency,
                {"enabled", "mode", "anchor", "sweep", "perturbation", "input", "output",
                 "injection_current_amplitude", "injection_current"},
                "simulation.frequency_analysis",
                errors_,
                options_.strict);

            options.frequency_analysis.enabled = true;
            if (const auto enabled = parse_bool_scalar(
                    frequency["enabled"], "simulation.frequency_analysis.enabled", errors_)) {
                options.frequency_analysis.enabled = *enabled;
            }

            if (const auto mode_raw = parse_string_scalar(
                    frequency["mode"], "simulation.frequency_analysis.mode", errors_)) {
                const std::string mode = normalize_key(*mode_raw);
                if (mode == "openloop" || mode == "openlooptransfer" || mode == "transfer") {
                    options.frequency_analysis.mode = FrequencyAnalysisMode::OpenLoopTransfer;
                } else if (mode == "closedloop" || mode == "closedlooptransfer") {
                    options.frequency_analysis.mode = FrequencyAnalysisMode::ClosedLoopTransfer;
                } else if (mode == "inputimpedance" || mode == "zin") {
                    options.frequency_analysis.mode = FrequencyAnalysisMode::InputImpedance;
                } else if (mode == "outputimpedance" || mode == "zout") {
                    options.frequency_analysis.mode = FrequencyAnalysisMode::OutputImpedance;
                } else {
                    push_error(
                        errors_,
                        kDiagFrequencyInvalid,
                        "Invalid simulation.frequency_analysis.mode: '" + *mode_raw + "'");
                }
            }

            if (const auto anchor_raw = parse_string_scalar(
                    frequency["anchor"], "simulation.frequency_analysis.anchor", errors_)) {
                const std::string anchor = normalize_key(*anchor_raw);
                if (anchor == "dc") {
                    options.frequency_analysis.anchor_mode = FrequencyAnchorMode::DC;
                } else if (anchor == "periodic" || anchor == "shooting") {
                    options.frequency_analysis.anchor_mode = FrequencyAnchorMode::Periodic;
                } else if (anchor == "averaged" || anchor == "average") {
                    options.frequency_analysis.anchor_mode = FrequencyAnchorMode::Averaged;
                } else if (anchor == "auto") {
                    options.frequency_analysis.anchor_mode = FrequencyAnchorMode::Auto;
                } else {
                    push_error(
                        errors_,
                        kDiagFrequencyInvalid,
                        "Invalid simulation.frequency_analysis.anchor: '" + *anchor_raw + "'");
                }
            }

            YAML::Node sweep = frequency["sweep"];
            if (sweep) {
                validate_keys(
                    sweep,
                    {"scale", "type", "f_start_hz", "f_stop_hz", "points"},
                    "simulation.frequency_analysis.sweep",
                    errors_,
                    options_.strict);

                if (const auto scale_raw = parse_string_scalar(
                        sweep["scale"] ? sweep["scale"] : sweep["type"],
                        "simulation.frequency_analysis.sweep.scale",
                        errors_)) {
                    const std::string scale = normalize_key(*scale_raw);
                    if (scale == "log" || scale == "logarithmic") {
                        options.frequency_analysis.sweep_scale = FrequencySweepScale::Logarithmic;
                    } else if (scale == "linear" || scale == "lin") {
                        options.frequency_analysis.sweep_scale = FrequencySweepScale::Linear;
                    } else {
                        push_error(
                            errors_,
                            kDiagFrequencyInvalid,
                            "Invalid simulation.frequency_analysis.sweep.scale: '" + *scale_raw + "'");
                    }
                }

                if (sweep["f_start_hz"]) {
                    options.frequency_analysis.f_start_hz = parse_real(
                        sweep["f_start_hz"], "simulation.frequency_analysis.sweep.f_start_hz", errors_);
                }
                if (sweep["f_stop_hz"]) {
                    options.frequency_analysis.f_stop_hz = parse_real(
                        sweep["f_stop_hz"], "simulation.frequency_analysis.sweep.f_stop_hz", errors_);
                }
                if (const auto points = parse_int_scalar(
                        sweep["points"], "simulation.frequency_analysis.sweep.points", errors_)) {
                    options.frequency_analysis.points = *points;
                }
            }

            if (frequency["injection_current_amplitude"]) {
                options.frequency_analysis.injection_current_amplitude =
                    parse_real(
                        frequency["injection_current_amplitude"],
                        "simulation.frequency_analysis.injection_current_amplitude",
                        errors_);
            } else if (frequency["injection_current"]) {
                options.frequency_analysis.injection_current_amplitude =
                    parse_real(
                        frequency["injection_current"],
                        "simulation.frequency_analysis.injection_current",
                        errors_);
            }

            auto parse_port = [&](const YAML::Node& node,
                                  const std::string& path,
                                  FrequencyAnalysisPort& port) {
                if (!node) {
                    return;
                }
                validate_keys(node, {"positive", "negative"}, path, errors_, options_.strict);
                if (const auto pos = parse_string_scalar(node["positive"], path + ".positive", errors_)) {
                    port.positive_node = *pos;
                }
                if (const auto neg = parse_string_scalar(node["negative"], path + ".negative", errors_)) {
                    port.negative_node = *neg;
                }
            };

            parse_port(
                frequency["perturbation"] ? frequency["perturbation"] : frequency["input"],
                "simulation.frequency_analysis.perturbation",
                options.frequency_analysis.perturbation_port);
            parse_port(
                frequency["output"],
                "simulation.frequency_analysis.output",
                options.frequency_analysis.output_port);

            if (!(std::isfinite(options.frequency_analysis.f_start_hz) &&
                  std::isfinite(options.frequency_analysis.f_stop_hz)) ||
                options.frequency_analysis.f_start_hz <= 0.0 ||
                options.frequency_analysis.f_stop_hz < options.frequency_analysis.f_start_hz) {
                push_error(
                    errors_,
                    kDiagFrequencyInvalid,
                    "simulation.frequency_analysis sweep range must satisfy finite "
                    "f_start_hz > 0 and f_stop_hz >= f_start_hz");
            }
            if (options.frequency_analysis.points < 2) {
                push_error(
                    errors_,
                    kDiagFrequencyInvalid,
                    "simulation.frequency_analysis.sweep.points must be >= 2");
            }
            if (!(std::isfinite(options.frequency_analysis.injection_current_amplitude) &&
                  std::abs(options.frequency_analysis.injection_current_amplitude) > 0.0)) {
                push_error(
                    errors_,
                    kDiagFrequencyInvalid,
                    "simulation.frequency_analysis.injection_current_amplitude must be finite and non-zero");
            }
        }

        YAML::Node averaged = sim["averaged_converter"];
        if (averaged) {
            validate_keys(
                averaged,
                {"enabled", "topology", "operating_mode", "envelope_policy", "vin_source", "inductor",
                 "capacitor", "load_resistor", "output_node", "duty", "duty_min", "duty_max",
                 "switching_frequency_hz", "initial_inductor_current", "initial_output_voltage",
                 "ccm_current_threshold"},
                "simulation.averaged_converter",
                errors_,
                options_.strict);

            options.averaged_converter.enabled = true;
            if (const auto enabled = parse_bool_scalar(
                    averaged["enabled"], "simulation.averaged_converter.enabled", errors_)) {
                options.averaged_converter.enabled = *enabled;
            }

            if (const auto topology_raw = parse_string_scalar(
                    averaged["topology"], "simulation.averaged_converter.topology", errors_)) {
                const std::string topology = normalize_key(*topology_raw);
                if (topology == "buck") {
                    options.averaged_converter.topology = AveragedConverterTopology::Buck;
                } else if (topology == "boost") {
                    options.averaged_converter.topology = AveragedConverterTopology::Boost;
                } else if (topology == "buckboost" || topology == "buckboostinverting" ||
                           topology == "invertingbuckboost") {
                    options.averaged_converter.topology = AveragedConverterTopology::BuckBoost;
                } else {
                    push_error(
                        errors_,
                        kDiagAveragedInvalid,
                        "Invalid simulation.averaged_converter.topology: '" + *topology_raw + "'");
                }
            }

            if (const auto mode_raw = parse_string_scalar(
                    averaged["operating_mode"],
                    "simulation.averaged_converter.operating_mode",
                    errors_)) {
                const std::string mode = normalize_key(*mode_raw);
                if (mode == "ccm") {
                    options.averaged_converter.operating_mode = AveragedOperatingMode::CCM;
                } else if (mode == "dcm") {
                    options.averaged_converter.operating_mode = AveragedOperatingMode::DCM;
                } else if (mode == "auto") {
                    options.averaged_converter.operating_mode = AveragedOperatingMode::Auto;
                } else {
                    push_error(
                        errors_,
                        kDiagAveragedInvalid,
                        "Invalid simulation.averaged_converter.operating_mode: '" + *mode_raw +
                            "' (expected 'ccm', 'dcm', or 'auto')");
                }
            }

            if (const auto policy_raw = parse_string_scalar(
                    averaged["envelope_policy"],
                    "simulation.averaged_converter.envelope_policy",
                    errors_)) {
                const std::string policy = normalize_key(*policy_raw);
                if (policy == "strict") {
                    options.averaged_converter.envelope_policy = AveragedEnvelopePolicy::Strict;
                } else if (policy == "warn" || policy == "warning") {
                    options.averaged_converter.envelope_policy = AveragedEnvelopePolicy::Warn;
                } else {
                    push_error(
                        errors_,
                        kDiagAveragedInvalid,
                        "Invalid simulation.averaged_converter.envelope_policy: '" + *policy_raw +
                            "' (expected 'strict' or 'warn')");
                }
            }

            if (const auto vin = parse_string_scalar(
                    averaged["vin_source"], "simulation.averaged_converter.vin_source", errors_)) {
                options.averaged_converter.vin_source = *vin;
            }
            if (const auto ind = parse_string_scalar(
                    averaged["inductor"], "simulation.averaged_converter.inductor", errors_)) {
                options.averaged_converter.inductor = *ind;
            }
            if (const auto cap = parse_string_scalar(
                    averaged["capacitor"], "simulation.averaged_converter.capacitor", errors_)) {
                options.averaged_converter.capacitor = *cap;
            }
            if (const auto load = parse_string_scalar(
                    averaged["load_resistor"], "simulation.averaged_converter.load_resistor", errors_)) {
                options.averaged_converter.load_resistor = *load;
            }
            if (const auto out = parse_string_scalar(
                    averaged["output_node"], "simulation.averaged_converter.output_node", errors_)) {
                options.averaged_converter.output_node = *out;
            }

            if (averaged["duty"]) {
                options.averaged_converter.duty = parse_real(
                    averaged["duty"], "simulation.averaged_converter.duty", errors_);
            }
            if (averaged["duty_min"]) {
                options.averaged_converter.duty_min = parse_real(
                    averaged["duty_min"], "simulation.averaged_converter.duty_min", errors_);
            }
            if (averaged["duty_max"]) {
                options.averaged_converter.duty_max = parse_real(
                    averaged["duty_max"], "simulation.averaged_converter.duty_max", errors_);
            }
            if (averaged["switching_frequency_hz"]) {
                options.averaged_converter.switching_frequency_hz = parse_real(
                    averaged["switching_frequency_hz"],
                    "simulation.averaged_converter.switching_frequency_hz",
                    errors_);
            }
            if (averaged["initial_inductor_current"]) {
                options.averaged_converter.initial_inductor_current = parse_real(
                    averaged["initial_inductor_current"],
                    "simulation.averaged_converter.initial_inductor_current",
                    errors_);
            }
            if (averaged["initial_output_voltage"]) {
                options.averaged_converter.initial_output_voltage = parse_real(
                    averaged["initial_output_voltage"],
                    "simulation.averaged_converter.initial_output_voltage",
                    errors_);
            }
            if (averaged["ccm_current_threshold"]) {
                options.averaged_converter.ccm_current_threshold = parse_real(
                    averaged["ccm_current_threshold"],
                    "simulation.averaged_converter.ccm_current_threshold",
                    errors_);
            }

            if (options.averaged_converter.enabled) {
                auto require_non_empty = [&](const std::string& value, const std::string& field) {
                    if (value.empty()) {
                        push_error(
                            errors_,
                            kDiagAveragedInvalid,
                            "simulation.averaged_converter." + field + " is required when enabled=true");
                    }
                };

                require_non_empty(options.averaged_converter.vin_source, "vin_source");
                require_non_empty(options.averaged_converter.inductor, "inductor");
                require_non_empty(options.averaged_converter.capacitor, "capacitor");
                require_non_empty(options.averaged_converter.load_resistor, "load_resistor");
                require_non_empty(options.averaged_converter.output_node, "output_node");

                if (!(std::isfinite(options.averaged_converter.duty_min) &&
                      std::isfinite(options.averaged_converter.duty_max) &&
                      std::isfinite(options.averaged_converter.duty) &&
                      options.averaged_converter.duty_min >= 0.0 &&
                      options.averaged_converter.duty_max <= 1.0 &&
                      options.averaged_converter.duty_min <= options.averaged_converter.duty_max &&
                      options.averaged_converter.duty >= options.averaged_converter.duty_min &&
                      options.averaged_converter.duty <= options.averaged_converter.duty_max)) {
                    push_error(
                        errors_,
                        kDiagAveragedInvalid,
                        "simulation.averaged_converter requires finite duty bounds "
                        "0 <= duty_min <= duty <= duty_max <= 1");
                }
                if (!(std::isfinite(options.averaged_converter.ccm_current_threshold) &&
                      options.averaged_converter.ccm_current_threshold >= 0.0)) {
                    push_error(
                        errors_,
                        kDiagAveragedInvalid,
                        "simulation.averaged_converter.ccm_current_threshold must be finite and >= 0");
                }
                if (!(std::isfinite(options.averaged_converter.switching_frequency_hz) &&
                      options.averaged_converter.switching_frequency_hz > 0.0)) {
                    push_error(
                        errors_,
                        kDiagAveragedInvalid,
                        "simulation.averaged_converter.switching_frequency_hz must be finite and > 0");
                }
            }
        }
    }

    // Models map (optional)
    std::unordered_map<std::string, YAML::Node> model_nodes;
    std::unordered_map<std::string, YAML::Node> resolved_models;

    if (root["models"]) {
        YAML::Node models = root["models"];
        if (!models.IsMap()) {
            errors_.push_back("models must be a map");
        } else {
            for (const auto& it : models) {
                model_nodes[it.first.as<std::string>()] = it.second;
            }
        }
    }

    std::function<YAML::Node(const std::string&, std::unordered_set<std::string>&)> resolve_model;
    resolve_model = [&](const std::string& name, std::unordered_set<std::string>& stack) -> YAML::Node {
        if (resolved_models.count(name)) return resolved_models[name];
        if (!model_nodes.count(name)) return YAML::Node();
        if (stack.count(name)) {
            errors_.push_back("Cyclic model inheritance for model: " + name);
            return YAML::Node();
        }

        stack.insert(name);
        YAML::Node node = model_nodes[name];
        if (node["extends"]) {
            std::string base = node["extends"].as<std::string>();
            YAML::Node base_node = resolve_model(base, stack);
            node = merge_nodes(base_node, node);
        }
        stack.erase(name);
        resolved_models[name] = node;
        return node;
    };

    // Components
    if (!root["components"] || !root["components"].IsSequence()) {
        errors_.push_back("Missing or invalid components list");
        return;
    }

    YAML::Node components = root["components"];
    std::unordered_map<std::string, std::pair<Real, Real>> shared_sink_defs;

    for (const auto& comp_node_raw : components) {
        YAML::Node comp_node = comp_node_raw;

        if (comp_node["use"]) {
            std::string model_name = comp_node["use"].as<std::string>();
            std::unordered_set<std::string> stack;
            YAML::Node model = resolve_model(model_name, stack);
            if (!model) {
                errors_.push_back("Unknown model: " + model_name);
                continue;
            }
            comp_node = merge_nodes(model, comp_node);
        }

        const YAML::Node comp = comp_node;

        validate_keys(comp,
            {"type", "name", "nodes", "value", "params", "waveform", "use", "loss",
             "thermal", "magnetic_core",
             "resistance", "capacitance", "inductance", "ic",
             "g_on", "g_off", "ron", "roff", "v_threshold", "initial_state",
             "vth", "kp", "lambda", "lambda_", "is_nmos", "v_ce_sat",
             "turns_ratio", "ratio", "magnetizing_inductance", "lm",
             "target_component", "target_device", "target", "operation", "channels", "inputs", "outputs",
             "x", "y", "num", "den", "delay", "sample_period",
             "trip_current", "trip_time", "trip", "rating", "blow_i2t", "i2t",
             "pickup_current", "dropout_current", "pickup_voltage", "dropout_voltage",
             "contact_resistance", "off_resistance", "target_component_no", "target_component_nc",
             "beta", "vbe_on", "holding_current", "latch_current", "gate_threshold",
             "saturation_current", "saturation_inductance", "saturation_exponent",
             "coupling", "k", "mutual_inductance", "l1", "l2", "ic1", "ic2", "ic_primary", "ic_secondary",
             "state", "mode", "select_index", "gain", "open_loop_gain", "offset",
             "kp", "ki", "kd", "threshold", "high", "low",
             "frequency", "duty", "duty_min", "duty_max", "duty_from_input", "duty_gain", "duty_offset",
             "duty_from_channel", "v_high", "v_low",
             "alpha", "anti_windup", "min", "max", "output_min", "output_max",
             "rising_rate", "falling_rate",
             "rail_high", "rail_low", "hysteresis", "metadata", "table", "mapping",
             "sample_time", "ts", "Ts",
             "n_inputs", "n_outputs", "lib_path", "source", "extra_cflags"},
            "component", errors_, options_.strict);

        if (!comp["type"] || !comp["name"]) {
            errors_.push_back("Component missing type or name");
            continue;
        }

        const std::string raw_type = comp["type"].as<std::string>();
        const std::string normalized_raw_type = normalize_key(raw_type);
        std::string type = canonical_component_type(raw_type);
        if (type.empty()) {
            push_error(errors_, kDiagUnsupportedComponent,
                       "Unsupported component type: " + raw_type);
            continue;
        }

        std::string name = comp["name"].as<std::string>();
        if (!comp["nodes"]) {
            push_error(errors_, kDiagInvalidPinCount, "Component missing nodes: " + name);
            continue;
        }

        std::vector<std::string> nodes = parse_nodes(comp["nodes"], name, errors_);
        const auto arity_it = component_node_arity().find(type);
        const bool accepts_zero_nodes =
            arity_it != component_node_arity().end() && arity_it->second.first == 0;
        if (nodes.empty() && !accepts_zero_nodes) continue;
        if (!validate_node_count(type, nodes, errors_, name)) continue;

        const YAML::Node comp_view = comp;
        const YAML::Node params = comp_view["params"];

        auto get_param = [&](const std::string& key) -> YAML::Node {
            try {
                YAML::Node top = comp_view[key];
                if (top.IsDefined() && !top.IsNull()) return top;
                YAML::Node nested = (params && params.IsMap()) ? params[key] : YAML::Node();
                if (nested.IsDefined() && !nested.IsNull()) return nested;
                if (key == "lambda") {
                    top = comp_view["lambda_"];
                    if (top.IsDefined() && !top.IsNull()) return top;
                    nested = (params && params.IsMap()) ? params["lambda_"] : YAML::Node();
                    if (nested.IsDefined() && !nested.IsNull()) return nested;
                }
                if (key == "target_component") {
                    top = comp_view["target_device"];
                    if (top.IsDefined() && !top.IsNull()) return top;
                    nested = (params && params.IsMap()) ? params["target_device"] : YAML::Node();
                    if (nested.IsDefined() && !nested.IsNull()) return nested;
                }
            } catch (const YAML::Exception&) {
                return YAML::Node();
            }
            return YAML::Node();
        };

        auto idx = [&](const std::string& node_name) {
            return circuit.add_node(node_name);
        };
        std::vector<Index> node_indices;
        node_indices.reserve(nodes.size());
        for (const auto& node_name : nodes) {
            node_indices.push_back(idx(node_name));
        }
        auto node_at = [&](std::size_t index) -> Index {
            return node_indices.at(index);
        };
        auto is_set = [](const YAML::Node& node) {
            return node.IsDefined() && !node.IsNull();
        };

        const bool has_component_sample_time =
            is_set(get_param("sample_time")) ||
            is_set(get_param("ts")) ||
            is_set(get_param("Ts"));
        if (has_component_sample_time &&
            !virtual_component_supports_sample_time(type)) {
            push_error(
                errors_,
                kDiagInvalidParameter,
                "sample_time/ts is only supported for control virtual blocks; got '" +
                    type + "' on component '" + name + "'");
            continue;
        }

        bool magnetic_core_defined = false;
        bool magnetic_core_enabled = false;
        std::string magnetic_core_model = "saturation";
        std::string magnetic_core_loss_policy = "telemetry_only";
        std::optional<Real> magnetic_saturation_current;
        std::optional<Real> magnetic_saturation_inductance;
        std::optional<Real> magnetic_saturation_exponent;
        std::optional<Real> magnetic_hysteresis_band;
        Real magnetic_core_loss_k = 0.0;
        Real magnetic_core_loss_alpha = 2.0;
        Real magnetic_core_loss_freq_coeff = 0.0;
        Real magnetic_hysteresis_strength = 0.15;
        Real magnetic_hysteresis_loss_coeff = 0.2;
        Real magnetic_hysteresis_state_init = 1.0;
        Real magnetic_i_equiv_init = 0.0;

        if (comp["magnetic_core"]) {
            magnetic_core_defined = true;
            magnetic_core_enabled = true;
            YAML::Node magnetic_core = comp["magnetic_core"];
            validate_keys(
                magnetic_core,
                {"enabled", "model", "saturation_current", "saturation_inductance",
                 "saturation_exponent", "core_loss_k", "core_loss_alpha", "core_loss_freq_coeff",
                 "loss_policy", "i_equiv_init", "hysteresis_band", "hysteresis_strength",
                 "hysteresis_loss_coeff", "hysteresis_state_init"},
                name + ".magnetic_core",
                errors_,
                options_.strict);

            if (!component_type_supports_magnetic_core(type)) {
                push_error(
                    errors_,
                    kDiagMagneticInvalid,
                    "Component '" + name + "' (" + type +
                        ") does not support magnetic_core in this release");
                continue;
            }

            if (const auto enabled = parse_bool_scalar(
                    magnetic_core["enabled"], name + ".magnetic_core.enabled", errors_);
                enabled.has_value()) {
                magnetic_core_enabled = *enabled;
            }

            if (const auto model = parse_string_scalar(
                    magnetic_core["model"], name + ".magnetic_core.model", errors_);
                model.has_value()) {
                magnetic_core_model = normalize_key(*model);
            }
            if (!magnetic_core_model.empty() &&
                magnetic_core_model != "saturation" &&
                magnetic_core_model != "hysteresis") {
                push_error(
                    errors_,
                    kDiagMagneticInvalid,
                    "Unsupported " + name + ".magnetic_core.model '" + magnetic_core_model +
                        "' (expected 'saturation' or 'hysteresis')");
                continue;
            }

            if (const auto loss_policy = parse_string_scalar(
                    magnetic_core["loss_policy"], name + ".magnetic_core.loss_policy", errors_);
                loss_policy.has_value()) {
                magnetic_core_loss_policy = normalize_key(*loss_policy);
            }
            if (magnetic_core_loss_policy.empty()) {
                magnetic_core_loss_policy = "telemetry_only";
            }
            if (magnetic_core_loss_policy == "telemetry_only" ||
                magnetic_core_loss_policy == "telemetryonly") {
                magnetic_core_loss_policy = "telemetry_only";
            } else if (magnetic_core_loss_policy == "loss_summary" ||
                       magnetic_core_loss_policy == "losssummary" ||
                       magnetic_core_loss_policy == "summary" ||
                       magnetic_core_loss_policy == "include_in_loss_summary" ||
                       magnetic_core_loss_policy == "includeinlosssummary") {
                magnetic_core_loss_policy = "loss_summary";
            } else {
                push_error(
                    errors_,
                    kDiagMagneticInvalid,
                    "Unsupported " + name + ".magnetic_core.loss_policy '" +
                        magnetic_core_loss_policy +
                        "' (expected 'telemetry_only' or 'loss_summary')");
                continue;
            }

            if (magnetic_core["saturation_current"]) {
                const Real value = parse_real(
                    magnetic_core["saturation_current"],
                    name + ".magnetic_core.saturation_current",
                    errors_);
                if (!std::isfinite(value) || value <= 0.0) {
                    push_error(
                        errors_,
                        kDiagMagneticInvalid,
                        name + ".magnetic_core.saturation_current must be finite and > 0");
                    continue;
                }
                magnetic_saturation_current = value;
            }

            if (magnetic_core["saturation_inductance"]) {
                const Real value = parse_real(
                    magnetic_core["saturation_inductance"],
                    name + ".magnetic_core.saturation_inductance",
                    errors_);
                if (!std::isfinite(value) || value <= 0.0) {
                    push_error(
                        errors_,
                        kDiagMagneticInvalid,
                        name + ".magnetic_core.saturation_inductance must be finite and > 0");
                    continue;
                }
                magnetic_saturation_inductance = value;
            }

            if (magnetic_core["saturation_exponent"]) {
                const Real value = parse_real(
                    magnetic_core["saturation_exponent"],
                    name + ".magnetic_core.saturation_exponent",
                    errors_);
                if (!std::isfinite(value) || value < 1.0) {
                    push_error(
                        errors_,
                        kDiagMagneticInvalid,
                        name + ".magnetic_core.saturation_exponent must be finite and >= 1");
                    continue;
                }
                magnetic_saturation_exponent = value;
            }

            if (magnetic_core["core_loss_k"]) {
                magnetic_core_loss_k = parse_real(
                    magnetic_core["core_loss_k"],
                    name + ".magnetic_core.core_loss_k",
                    errors_);
            }
            if (!std::isfinite(magnetic_core_loss_k) || magnetic_core_loss_k < 0.0) {
                push_error(
                    errors_,
                    kDiagMagneticInvalid,
                    name + ".magnetic_core.core_loss_k must be finite and >= 0");
                continue;
            }

            if (magnetic_core["core_loss_alpha"]) {
                magnetic_core_loss_alpha = parse_real(
                    magnetic_core["core_loss_alpha"],
                    name + ".magnetic_core.core_loss_alpha",
                    errors_);
            }
            if (!std::isfinite(magnetic_core_loss_alpha) || magnetic_core_loss_alpha < 0.0) {
                push_error(
                    errors_,
                    kDiagMagneticInvalid,
                    name + ".magnetic_core.core_loss_alpha must be finite and >= 0");
                continue;
            }

            if (magnetic_core["core_loss_freq_coeff"]) {
                magnetic_core_loss_freq_coeff = parse_real(
                    magnetic_core["core_loss_freq_coeff"],
                    name + ".magnetic_core.core_loss_freq_coeff",
                    errors_);
            }
            if (!std::isfinite(magnetic_core_loss_freq_coeff) || magnetic_core_loss_freq_coeff < 0.0) {
                push_error(
                    errors_,
                    kDiagMagneticInvalid,
                    name + ".magnetic_core.core_loss_freq_coeff must be finite and >= 0");
                continue;
            }

            if (magnetic_core["hysteresis_band"]) {
                const Real value = parse_real(
                    magnetic_core["hysteresis_band"],
                    name + ".magnetic_core.hysteresis_band",
                    errors_);
                if (!std::isfinite(value) || value < 0.0) {
                    push_error(
                        errors_,
                        kDiagMagneticInvalid,
                        name + ".magnetic_core.hysteresis_band must be finite and >= 0");
                    continue;
                }
                magnetic_hysteresis_band = value;
            }

            if (magnetic_core["hysteresis_strength"]) {
                magnetic_hysteresis_strength = parse_real(
                    magnetic_core["hysteresis_strength"],
                    name + ".magnetic_core.hysteresis_strength",
                    errors_);
            }
            if (!std::isfinite(magnetic_hysteresis_strength) ||
                magnetic_hysteresis_strength < 0.0 ||
                magnetic_hysteresis_strength > 1.0) {
                push_error(
                    errors_,
                    kDiagMagneticInvalid,
                    name + ".magnetic_core.hysteresis_strength must be finite and in [0, 1]");
                continue;
            }

            if (magnetic_core["hysteresis_loss_coeff"]) {
                magnetic_hysteresis_loss_coeff = parse_real(
                    magnetic_core["hysteresis_loss_coeff"],
                    name + ".magnetic_core.hysteresis_loss_coeff",
                    errors_);
            }
            if (!std::isfinite(magnetic_hysteresis_loss_coeff) || magnetic_hysteresis_loss_coeff < 0.0) {
                push_error(
                    errors_,
                    kDiagMagneticInvalid,
                    name + ".magnetic_core.hysteresis_loss_coeff must be finite and >= 0");
                continue;
            }

            if (magnetic_core["hysteresis_state_init"]) {
                magnetic_hysteresis_state_init = parse_real(
                    magnetic_core["hysteresis_state_init"],
                    name + ".magnetic_core.hysteresis_state_init",
                    errors_);
            }
            if (!std::isfinite(magnetic_hysteresis_state_init)) {
                push_error(
                    errors_,
                    kDiagMagneticInvalid,
                    name + ".magnetic_core.hysteresis_state_init must be finite");
                continue;
            }

            if (magnetic_core["i_equiv_init"]) {
                magnetic_i_equiv_init = parse_real(
                    magnetic_core["i_equiv_init"],
                    name + ".magnetic_core.i_equiv_init",
                    errors_);
            }
            if (!std::isfinite(magnetic_i_equiv_init) || magnetic_i_equiv_init < 0.0) {
                push_error(
                    errors_,
                    kDiagMagneticInvalid,
                    name + ".magnetic_core.i_equiv_init must be finite and >= 0");
                continue;
            }
        }

        // Loss model (switching energy)
        if (comp["loss"]) {
            YAML::Node loss = comp["loss"];
            validate_keys(loss, {"model", "axes", "eon", "eoff", "err"}, name + ".loss", errors_, options_.strict);

            const bool has_axes = loss["axes"] && !loss["axes"].IsNull();
            const bool has_table_values =
                (loss["eon"] && loss["eon"].IsSequence()) ||
                (loss["eoff"] && loss["eoff"].IsSequence()) ||
                (loss["err"] && loss["err"].IsSequence());

            bool datasheet_mode = has_axes || has_table_values;
            if (const auto model_raw = parse_string_scalar(loss["model"], name + ".loss.model", errors_);
                model_raw.has_value()) {
                const std::string model = normalize_key(*model_raw);
                if (model == "scalar") {
                    datasheet_mode = false;
                } else if (model == "datasheet") {
                    datasheet_mode = true;
                } else {
                    push_error(errors_,
                               kDiagLossModelInvalid,
                               "Unsupported " + name + ".loss.model '" + *model_raw +
                                   "' (expected 'scalar' or 'datasheet')");
                }
            }

            auto validate_loss_energy = [&](Real value, const std::string& field_path) {
                if (!std::isfinite(value) || value < 0.0) {
                    push_error(errors_,
                               kDiagLossInvalidRange,
                               field_path + " must be finite and >= 0");
                }
            };

            if (datasheet_mode) {
                if (!loss["axes"] || !loss["axes"].IsMap()) {
                    if (loss["axes"]) {
                        push_type_mismatch_error(errors_, name + ".loss.axes", "map", loss["axes"]);
                    } else {
                        push_error(errors_,
                                   kDiagLossModelInvalid,
                                   "Missing required field '" + name + ".loss.axes' for datasheet model");
                    }
                } else {
                    const YAML::Node axes = loss["axes"];
                    validate_keys(
                        axes,
                        {"current", "voltage", "temperature"},
                        name + ".loss.axes",
                        errors_,
                        options_.strict);

                    SwitchingEnergySurface3D surface;
                    surface.current_axis =
                        parse_real_sequence(axes["current"], name + ".loss.axes.current", errors_);
                    surface.voltage_axis =
                        parse_real_sequence(axes["voltage"], name + ".loss.axes.voltage", errors_);
                    surface.temperature_axis =
                        parse_real_sequence(axes["temperature"], name + ".loss.axes.temperature", errors_);

                    if (!is_strictly_increasing(surface.current_axis)) {
                        push_error(errors_,
                                   kDiagLossAxisInvalid,
                                   name + ".loss.axes.current must be finite and strictly increasing");
                    }
                    if (!is_strictly_increasing(surface.voltage_axis)) {
                        push_error(errors_,
                                   kDiagLossAxisInvalid,
                                   name + ".loss.axes.voltage must be finite and strictly increasing");
                    }
                    if (!is_strictly_increasing(surface.temperature_axis)) {
                        push_error(errors_,
                                   kDiagLossAxisInvalid,
                                   name + ".loss.axes.temperature must be finite and strictly increasing");
                    }

                    const std::size_t expected_size = surface.expected_table_size();
                    auto parse_table = [&](const char* key,
                                           std::vector<Real>& dest,
                                           const std::string& path) {
                        if (!loss[key]) {
                            return;
                        }
                        dest = parse_real_sequence(loss[key], path, errors_);
                        if (!dest.empty() && dest.size() != expected_size) {
                            push_error(
                                errors_,
                                kDiagLossDimensionInvalid,
                                path + " size mismatch (expected " + std::to_string(expected_size) +
                                    ", got " + std::to_string(dest.size()) + ")");
                        }
                        for (std::size_t i = 0; i < dest.size(); ++i) {
                            validate_loss_energy(dest[i], path + "[" + std::to_string(i) + "]");
                        }
                    };

                    parse_table("eon", surface.eon_table, name + ".loss.eon");
                    parse_table("eoff", surface.eoff_table, name + ".loss.eoff");
                    parse_table("err", surface.err_table, name + ".loss.err");

                    if (!surface.has_eon() && !surface.has_eoff() && !surface.has_err()) {
                        push_error(errors_,
                                   kDiagLossModelInvalid,
                                   "Datasheet loss model for '" + name +
                                       "' must define at least one table among eon/eoff/err");
                    }

                    if (surface.valid_shape()) {
                        options.switching_energy_surfaces[name] = surface;
                        options.switching_energy.erase(name);
                    }
                }
            } else {
                SwitchingEnergy energy;
                if (loss["eon"]) energy.eon = parse_real(loss["eon"], name + ".loss.eon", errors_);
                if (loss["eoff"]) energy.eoff = parse_real(loss["eoff"], name + ".loss.eoff", errors_);
                if (loss["err"]) energy.err = parse_real(loss["err"], name + ".loss.err", errors_);
                validate_loss_energy(energy.eon, name + ".loss.eon");
                validate_loss_energy(energy.eoff, name + ".loss.eoff");
                validate_loss_energy(energy.err, name + ".loss.err");
                options.switching_energy[name] = energy;
                options.switching_energy_surfaces.erase(name);
            }
        }

        if (comp["thermal"]) {
            YAML::Node thermal = comp["thermal"];
            validate_keys(
                thermal,
                {"enabled", "network", "rth", "cth", "rth_stages", "cth_stages",
                 "temp_init", "temp_ref", "alpha",
                 "shared_sink_id", "shared_sink_rth", "shared_sink_cth"},
                          name + ".thermal", errors_, options_.strict);
            ThermalDeviceConfig cfg;
            if (const auto enabled = parse_bool_scalar(
                    thermal["enabled"], name + ".thermal.enabled", errors_)) {
                cfg.enabled = *enabled;
            }
            const bool supports_thermal = component_type_supports_thermal(type);
            const bool has_rth = is_set(thermal["rth"]);
            const bool has_cth = is_set(thermal["cth"]);
            const bool has_rth_stages = is_set(thermal["rth_stages"]);
            const bool has_cth_stages = is_set(thermal["cth_stages"]);

            bool network_explicit = false;
            if (const auto network_raw = parse_string_scalar(
                    thermal["network"], name + ".thermal.network", errors_);
                network_raw.has_value()) {
                network_explicit = true;
                const std::string normalized = normalize_key(*network_raw);
                if (normalized == "single" ||
                    normalized == "singlerc" ||
                    normalized == "single_rc") {
                    cfg.network_kind = ThermalNetworkKind::SingleRC;
                } else if (normalized == "foster") {
                    cfg.network_kind = ThermalNetworkKind::Foster;
                } else if (normalized == "cauer") {
                    cfg.network_kind = ThermalNetworkKind::Cauer;
                } else {
                    push_error(errors_,
                               kDiagThermalNetworkInvalid,
                               "Unsupported " + name + ".thermal.network '" + *network_raw +
                                   "' (expected single_rc, foster, or cauer)");
                }
            }

            const bool stage_mode_requested = has_rth_stages || has_cth_stages;
            if (stage_mode_requested && !network_explicit) {
                cfg.network_kind = ThermalNetworkKind::Foster;
            }

            if (cfg.enabled && !supports_thermal) {
                push_error(errors_, kDiagThermalUnsupportedComponent,
                           "Component '" + name + "' (" + type + ") does not support thermal port enablement");
            }

            if (cfg.network_kind == ThermalNetworkKind::SingleRC) {
                if (stage_mode_requested) {
                    push_error(errors_,
                               kDiagThermalNetworkInvalid,
                               name + ".thermal.network=single_rc cannot use rth_stages/cth_stages");
                }

                if (has_rth) {
                    cfg.rth = parse_real(thermal["rth"], name + ".thermal.rth", errors_);
                } else if (cfg.enabled) {
                    if (options_.strict) {
                        push_error(errors_, kDiagThermalMissingRequired,
                                   "Missing required field '" + name + ".thermal.rth' when thermal is enabled");
                    } else {
                        cfg.rth = options.thermal.default_rth;
                        push_warning(
                            warnings_,
                            kDiagThermalDefaultApplied,
                            "Applied simulation.thermal.default_rth to '" + name + ".thermal.rth'");
                    }
                }

                if (has_cth) {
                    cfg.cth = parse_real(thermal["cth"], name + ".thermal.cth", errors_);
                } else if (cfg.enabled) {
                    if (options_.strict) {
                        push_error(errors_, kDiagThermalMissingRequired,
                                   "Missing required field '" + name + ".thermal.cth' when thermal is enabled");
                    } else {
                        cfg.cth = options.thermal.default_cth;
                        push_warning(
                            warnings_,
                            kDiagThermalDefaultApplied,
                            "Applied simulation.thermal.default_cth to '" + name + ".thermal.cth'");
                    }
                }
                cfg.stage_rth.clear();
                cfg.stage_cth.clear();
            } else {
                if (!has_rth_stages || !has_cth_stages) {
                    push_error(
                        errors_,
                        kDiagThermalMissingRequired,
                        "Missing required fields '" + name +
                            ".thermal.rth_stages' and '" + name +
                            ".thermal.cth_stages' for staged thermal network");
                }
                cfg.stage_rth =
                    parse_real_sequence(thermal["rth_stages"], name + ".thermal.rth_stages", errors_);
                cfg.stage_cth =
                    parse_real_sequence(thermal["cth_stages"], name + ".thermal.cth_stages", errors_);

                if (!cfg.stage_rth.empty() &&
                    !cfg.stage_cth.empty() &&
                    cfg.stage_rth.size() != cfg.stage_cth.size()) {
                    push_error(errors_,
                               kDiagThermalDimensionInvalid,
                               name + ".thermal stage dimension mismatch: rth_stages has " +
                                   std::to_string(cfg.stage_rth.size()) +
                                   " entries but cth_stages has " +
                                   std::to_string(cfg.stage_cth.size()));
                }
                if (cfg.stage_rth.empty() || cfg.stage_cth.empty()) {
                    push_error(errors_,
                               kDiagThermalDimensionInvalid,
                               name + ".thermal staged networks require non-empty rth_stages/cth_stages");
                }

                cfg.rth = 0.0;
                cfg.cth = 0.0;
                for (std::size_t i = 0; i < std::min(cfg.stage_rth.size(), cfg.stage_cth.size()); ++i) {
                    const Real r = cfg.stage_rth[i];
                    const Real c = cfg.stage_cth[i];
                    if (!std::isfinite(r) || r <= 0.0) {
                        push_error(errors_,
                                   kDiagThermalInvalidRange,
                                   name + ".thermal.rth_stages[" + std::to_string(i) +
                                       "] must be finite and > 0");
                    }
                    if (!std::isfinite(c) || c < 0.0) {
                        push_error(errors_,
                                   kDiagThermalInvalidRange,
                                   name + ".thermal.cth_stages[" + std::to_string(i) +
                                       "] must be finite and >= 0");
                    }
                    cfg.rth += r;
                    cfg.cth += c;
                }
            }

            if (thermal["temp_init"]) cfg.temp_init = parse_real(thermal["temp_init"], name + ".thermal.temp_init", errors_);
            if (thermal["temp_ref"]) cfg.temp_ref = parse_real(thermal["temp_ref"], name + ".thermal.temp_ref", errors_);
            if (thermal["alpha"]) cfg.alpha = parse_real(thermal["alpha"], name + ".thermal.alpha", errors_);
            if (const auto sink_id = parse_string_scalar(
                    thermal["shared_sink_id"], name + ".thermal.shared_sink_id", errors_);
                sink_id.has_value()) {
                cfg.shared_sink_id = *sink_id;
            }

            const bool has_shared_sink_rth = is_set(thermal["shared_sink_rth"]);
            const bool has_shared_sink_cth = is_set(thermal["shared_sink_cth"]);
            if (!cfg.shared_sink_id.empty()) {
                if (has_shared_sink_rth) {
                    cfg.shared_sink_rth = parse_real(
                        thermal["shared_sink_rth"],
                        name + ".thermal.shared_sink_rth",
                        errors_);
                } else if (options_.strict) {
                    push_error(errors_,
                               kDiagThermalMissingRequired,
                               "Missing required field '" + name +
                                   ".thermal.shared_sink_rth' when shared_sink_id is set");
                } else {
                    cfg.shared_sink_rth = options.thermal.default_rth;
                    push_warning(
                        warnings_,
                        kDiagThermalDefaultApplied,
                        "Applied simulation.thermal.default_rth to '" + name + ".thermal.shared_sink_rth'");
                }

                if (has_shared_sink_cth) {
                    cfg.shared_sink_cth = parse_real(
                        thermal["shared_sink_cth"],
                        name + ".thermal.shared_sink_cth",
                        errors_);
                } else if (options_.strict) {
                    push_error(errors_,
                               kDiagThermalMissingRequired,
                               "Missing required field '" + name +
                                   ".thermal.shared_sink_cth' when shared_sink_id is set");
                } else {
                    cfg.shared_sink_cth = options.thermal.default_cth;
                    push_warning(
                        warnings_,
                        kDiagThermalDefaultApplied,
                        "Applied simulation.thermal.default_cth to '" + name + ".thermal.shared_sink_cth'");
                }
            } else if (has_shared_sink_rth || has_shared_sink_cth) {
                push_error(errors_,
                           kDiagThermalInvalidRange,
                           name + ".thermal.shared_sink_rth/shared_sink_cth require non-empty shared_sink_id");
            }

            if (cfg.enabled) {
                if (!std::isfinite(cfg.rth) || cfg.rth <= 0.0) {
                    push_error(errors_, kDiagThermalInvalidRange,
                               name + ".thermal.rth must be finite and > 0");
                }
                if (!std::isfinite(cfg.cth) || cfg.cth < 0.0) {
                    push_error(errors_, kDiagThermalInvalidRange,
                               name + ".thermal.cth must be finite and >= 0");
                }
                if (!std::isfinite(cfg.temp_init)) {
                    push_error(errors_, kDiagThermalInvalidRange,
                               name + ".thermal.temp_init must be finite");
                }
                if (!std::isfinite(cfg.temp_ref)) {
                    push_error(errors_, kDiagThermalInvalidRange,
                               name + ".thermal.temp_ref must be finite");
                }
                if (!std::isfinite(cfg.alpha)) {
                    push_error(errors_, kDiagThermalInvalidRange,
                               name + ".thermal.alpha must be finite");
                }
                if (!cfg.shared_sink_id.empty()) {
                    if (!std::isfinite(cfg.shared_sink_rth) || cfg.shared_sink_rth <= 0.0) {
                        push_error(errors_,
                                   kDiagThermalInvalidRange,
                                   name + ".thermal.shared_sink_rth must be finite and > 0");
                    }
                    if (!std::isfinite(cfg.shared_sink_cth) || cfg.shared_sink_cth < 0.0) {
                        push_error(errors_,
                                   kDiagThermalInvalidRange,
                                   name + ".thermal.shared_sink_cth must be finite and >= 0");
                    }
                    if (std::isfinite(cfg.shared_sink_rth) &&
                        std::isfinite(cfg.shared_sink_cth) &&
                        cfg.shared_sink_rth > 0.0 &&
                        cfg.shared_sink_cth >= 0.0) {
                        if (const auto sink_it = shared_sink_defs.find(cfg.shared_sink_id);
                            sink_it == shared_sink_defs.end()) {
                            shared_sink_defs.emplace(
                                cfg.shared_sink_id,
                                std::make_pair(cfg.shared_sink_rth, cfg.shared_sink_cth));
                        } else {
                            const auto nearly_same = [](Real a, Real b) {
                                const Real scale = std::max<Real>({Real{1.0}, std::abs(a), std::abs(b)});
                                return std::abs(a - b) <= scale * Real{1e-12};
                            };
                            if (!nearly_same(cfg.shared_sink_rth, sink_it->second.first) ||
                                !nearly_same(cfg.shared_sink_cth, sink_it->second.second)) {
                                push_error(
                                    errors_,
                                    kDiagThermalInvalidRange,
                                    name + ".thermal shared sink '" + cfg.shared_sink_id +
                                        "' must reuse the same shared_sink_rth/shared_sink_cth as other members");
                            }
                        }
                    }
                }
            }

            if (supports_thermal) {
                options.thermal_devices[name] = cfg;
                if (cfg.enabled) {
                    options.thermal.enable = true;
                }
            }
        }

        if (type == "resistor") {
            YAML::Node value_node = get_param("value");
            if (!value_node) value_node = get_param("resistance");
            Real value = parse_real(value_node, name + ".value", errors_);
            circuit.add_resistor(name, node_at(0), node_at(1), value);
        }
        else if (type == "capacitor") {
            YAML::Node value_node = get_param("value");
            if (!value_node) value_node = get_param("capacitance");
            Real value = parse_real(value_node, name + ".value", errors_);
            Real ic = 0.0;
            if (get_param("ic")) ic = parse_real(get_param("ic"), name + ".ic", errors_);
            circuit.add_capacitor(name, node_at(0), node_at(1), value, ic);
        }
        else if (type == "inductor") {
            YAML::Node value_node = get_param("value");
            if (!value_node) value_node = get_param("inductance");
            Real value = parse_real(value_node, name + ".value", errors_);
            Real ic = 0.0;
            if (get_param("ic")) ic = parse_real(get_param("ic"), name + ".ic", errors_);
            circuit.add_inductor(name, node_at(0), node_at(1), value, ic);
        }
        else if (type == "voltage_source") {
            YAML::Node waveform = comp["waveform"];
            std::string switch_target;
            if (YAML::Node target = get_param("target_component"); target && target.IsScalar()) {
                switch_target = target.as<std::string>();
            } else if (YAML::Node target = get_param("target"); target && target.IsScalar()) {
                switch_target = target.as<std::string>();
            }

            if (waveform && waveform["type"]) {
                std::string wtype = to_lower(waveform["type"].as<std::string>());
                if (wtype == "dc") {
                    Real value = parse_real(waveform["value"], name + ".waveform.value", errors_);
                    circuit.add_voltage_source(name, node_at(0), node_at(1), value);
                } else if (wtype == "pwm") {
                    PWMParams p;
                    if (waveform["v_high"]) p.v_high = parse_real(waveform["v_high"], name + ".waveform.v_high", errors_);
                    if (waveform["v_low"]) p.v_low = parse_real(waveform["v_low"], name + ".waveform.v_low", errors_);
                    if (waveform["frequency"]) p.frequency = parse_real(waveform["frequency"], name + ".waveform.frequency", errors_);
                    if (waveform["duty"]) p.duty = parse_real(waveform["duty"], name + ".waveform.duty", errors_);
                    if (waveform["dead_time"]) p.dead_time = parse_real(waveform["dead_time"], name + ".waveform.dead_time", errors_);
                    if (waveform["phase"]) p.phase = parse_real(waveform["phase"], name + ".waveform.phase", errors_);
                    circuit.add_pwm_voltage_source(name, node_at(0), node_at(1), p);
                } else if (wtype == "sine") {
                    SineParams p;
                    if (waveform["amplitude"]) p.amplitude = parse_real(waveform["amplitude"], name + ".waveform.amplitude", errors_);
                    if (waveform["frequency"]) p.frequency = parse_real(waveform["frequency"], name + ".waveform.frequency", errors_);
                    if (waveform["offset"]) p.offset = parse_real(waveform["offset"], name + ".waveform.offset", errors_);
                    if (waveform["phase"]) p.phase = parse_real(waveform["phase"], name + ".waveform.phase", errors_);
                    circuit.add_sine_voltage_source(name, node_at(0), node_at(1), p);
                } else if (wtype == "pulse") {
                    PulseParams p;
                    if (waveform["v_initial"]) p.v_initial = parse_real(waveform["v_initial"], name + ".waveform.v_initial", errors_);
                    if (waveform["v_pulse"]) p.v_pulse = parse_real(waveform["v_pulse"], name + ".waveform.v_pulse", errors_);
                    if (waveform["t_delay"]) p.t_delay = parse_real(waveform["t_delay"], name + ".waveform.t_delay", errors_);
                    if (waveform["t_rise"]) p.t_rise = parse_real(waveform["t_rise"], name + ".waveform.t_rise", errors_);
                    if (waveform["t_fall"]) p.t_fall = parse_real(waveform["t_fall"], name + ".waveform.t_fall", errors_);
                    if (waveform["t_width"]) p.t_width = parse_real(waveform["t_width"], name + ".waveform.t_width", errors_);
                    if (waveform["period"]) p.period = parse_real(waveform["period"], name + ".waveform.period", errors_);
                    circuit.add_pulse_voltage_source(name, node_at(0), node_at(1), p);
                    if (!switch_target.empty()) {
                        circuit.bind_switch_driver(name, switch_target);
                    }
                } else {
                    errors_.push_back("Unsupported waveform type for voltage_source: " + wtype);
                }
            } else {
                Real value = parse_real(get_param("value"), name + ".value", errors_);
                circuit.add_voltage_source(name, node_at(0), node_at(1), value);
            }
        }
        else if (type == "current_source") {
            Real value = parse_real(get_param("value"), name + ".value", errors_);
            circuit.add_current_source(name, node_at(0), node_at(1), value);
        }
        else if (type == "diode") {
            YAML::Node g_on_node = get_param("g_on");
            if (!g_on_node && get_param("ron")) {
                Real ron = parse_real(get_param("ron"), name + ".ron", errors_);
                g_on_node = YAML::Node(ron > 0 ? 1.0 / ron : 0.0);
            }
            YAML::Node g_off_node = get_param("g_off");
            if (!g_off_node && get_param("roff")) {
                Real roff = parse_real(get_param("roff"), name + ".roff", errors_);
                g_off_node = YAML::Node(roff > 0 ? 1.0 / roff : 0.0);
            }
            Real g_on = g_on_node ? parse_real(g_on_node, name + ".g_on", errors_) : 1e3;
            Real g_off = g_off_node ? parse_real(g_off_node, name + ".g_off", errors_) : 1e-9;
            circuit.add_diode(name, node_at(0), node_at(1), g_on, g_off);
        }
        else if (type == "switch") {
            YAML::Node g_on_node = get_param("g_on");
            if (!g_on_node && get_param("ron")) {
                Real ron = parse_real(get_param("ron"), name + ".ron", errors_);
                g_on_node = YAML::Node(ron > 0 ? 1.0 / ron : 0.0);
            }
            YAML::Node g_off_node = get_param("g_off");
            if (!g_off_node && get_param("roff")) {
                Real roff = parse_real(get_param("roff"), name + ".roff", errors_);
                g_off_node = YAML::Node(roff > 0 ? 1.0 / roff : 0.0);
            }
            Real g_on = g_on_node ? parse_real(g_on_node, name + ".g_on", errors_) : 1e6;
            Real g_off = g_off_node ? parse_real(g_off_node, name + ".g_off", errors_) : 1e-12;
            YAML::Node initial_state_node = get_param("initial_state");
            bool closed = (initial_state_node.IsDefined() && !initial_state_node.IsNull())
                ? initial_state_node.as<bool>()
                : false;
            circuit.add_switch(name, node_at(0), node_at(1), closed, g_on, g_off);
        }
        else if (type == "vcswitch") {
            Real v_threshold = get_param("v_threshold") ? parse_real(get_param("v_threshold"), name + ".v_threshold", errors_) : 2.5;
            Real g_on = get_param("g_on") ? parse_real(get_param("g_on"), name + ".g_on", errors_) : 1e3;
            Real g_off = get_param("g_off") ? parse_real(get_param("g_off"), name + ".g_off", errors_) : 1e-9;
            circuit.add_vcswitch(name, node_at(0), node_at(1), node_at(2), v_threshold, g_on, g_off);
        }
        else if (type == "mosfet") {
            MOSFET::Params p;
            if (get_param("vth")) p.vth = parse_real(get_param("vth"), name + ".vth", errors_);
            if (get_param("kp")) p.kp = parse_real(get_param("kp"), name + ".kp", errors_);
            if (get_param("lambda")) p.lambda = parse_real(get_param("lambda"), name + ".lambda", errors_);
            if (get_param("g_off")) p.g_off = parse_real(get_param("g_off"), name + ".g_off", errors_);
            YAML::Node is_nmos_node = get_param("is_nmos");
            if (is_nmos_node.IsDefined() && !is_nmos_node.IsNull()) p.is_nmos = is_nmos_node.as<bool>();
            if (normalized_raw_type == "pmos") p.is_nmos = false;
            circuit.add_mosfet(name, node_at(0), node_at(1), node_at(2), p);
        }
        else if (type == "igbt") {
            IGBT::Params p;
            if (get_param("vth")) p.vth = parse_real(get_param("vth"), name + ".vth", errors_);
            if (get_param("g_on")) p.g_on = parse_real(get_param("g_on"), name + ".g_on", errors_);
            if (get_param("g_off")) p.g_off = parse_real(get_param("g_off"), name + ".g_off", errors_);
            if (get_param("v_ce_sat")) p.v_ce_sat = parse_real(get_param("v_ce_sat"), name + ".v_ce_sat", errors_);
            circuit.add_igbt(name, node_at(0), node_at(1), node_at(2), p);
        }
        else if (type == "transformer") {
            YAML::Node ratio_node = get_param("turns_ratio");
            if (!ratio_node) ratio_node = get_param("ratio");
            Real turns_ratio = parse_real(ratio_node, name + ".turns_ratio", errors_);
            circuit.add_transformer(name, node_at(0), node_at(1), node_at(2), node_at(3), turns_ratio);
            if (magnetic_core_defined) {
                std::unordered_map<std::string, Real> numeric_params;
                numeric_params["turns_ratio"] = turns_ratio;
                numeric_params["magnetic_core_enabled"] = magnetic_core_enabled ? 1.0 : 0.0;
                numeric_params["core_loss_k"] = magnetic_core_enabled ? magnetic_core_loss_k : 0.0;
                numeric_params["core_loss_alpha"] = magnetic_core_loss_alpha;
                numeric_params["core_loss_freq_coeff"] = magnetic_core_loss_freq_coeff;
                numeric_params["magnetic_i_equiv_init"] = magnetic_i_equiv_init;
                if (magnetic_hysteresis_band.has_value()) {
                    numeric_params["hysteresis_band"] = *magnetic_hysteresis_band;
                }
                numeric_params["hysteresis_strength"] = magnetic_hysteresis_strength;
                numeric_params["hysteresis_loss_coeff"] = magnetic_hysteresis_loss_coeff;
                numeric_params["hysteresis_state_init"] = magnetic_hysteresis_state_init;

                std::unordered_map<std::string, std::string> metadata;
                metadata["target_component"] = name;
                metadata["magnetic_core_model"] = magnetic_core_model;
                metadata["magnetic_core_loss_policy"] = magnetic_core_loss_policy;
                circuit.add_virtual_component(
                    type, name, node_indices, std::move(numeric_params), std::move(metadata));
            }
        }
        else if (type == "snubber_rc") {
            YAML::Node r_node = get_param("resistance");
            if (!r_node) r_node = get_param("value");
            YAML::Node c_node = get_param("capacitance");
            Real r_value = parse_real(r_node, name + ".resistance", errors_);
            Real c_value = parse_real(c_node, name + ".capacitance", errors_);
            Real ic = 0.0;
            if (get_param("ic")) ic = parse_real(get_param("ic"), name + ".ic", errors_);
            circuit.add_snubber_rc(name, node_at(0), node_at(1), r_value, c_value, ic);
        }
        else if (type == "bjt_npn" || type == "bjt_pnp") {
            MOSFET::Params p;
            p.is_nmos = (type == "bjt_npn");
            if (get_param("vbe_on")) p.vth = parse_real(get_param("vbe_on"), name + ".vbe_on", errors_);
            if (get_param("g_off")) p.g_off = parse_real(get_param("g_off"), name + ".g_off", errors_);
            if (get_param("beta")) {
                Real beta = parse_real(get_param("beta"), name + ".beta", errors_);
                if (beta <= 0.0) {
                    push_error(errors_, kDiagInvalidParameter,
                               "beta must be > 0 for " + name);
                    continue;
                }
                // First parity slice: map beta to transconductance proxy.
                p.kp = std::max<Real>(1e-6, beta * 1e-3);
            }
            circuit.add_mosfet(name, node_at(0), node_at(1), node_at(2), p);
            push_warning(warnings_, kDiagSurrogateComponent,
                         "Component '" + name + "' (" + type + ") mapped to MOSFET surrogate model");
        }
        else if (type == "relay") {
            bool energized = false;
            YAML::Node state_node = get_param("initial_state");
            if (state_node.IsDefined() && !state_node.IsNull()) {
                if (state_node.IsScalar()) {
                    try {
                        energized = state_node.as<bool>();
                    } catch (...) {
                        const std::string state = normalize_key(state_node.as<std::string>());
                        energized = (state == "closed" || state == "energized" || state == "on" || state == "true");
                    }
                }
            }

            Real g_on = 1e4;
            Real g_off = 1e-9;
            if (get_param("g_on")) {
                g_on = parse_real(get_param("g_on"), name + ".g_on", errors_);
            } else if (get_param("contact_resistance")) {
                const Real r_on = parse_real(get_param("contact_resistance"), name + ".contact_resistance", errors_);
                g_on = (r_on > 0.0) ? (1.0 / r_on) : 1e4;
            } else if (get_param("ron")) {
                const Real r_on = parse_real(get_param("ron"), name + ".ron", errors_);
                g_on = (r_on > 0.0) ? (1.0 / r_on) : 1e4;
            }

            if (get_param("g_off")) {
                g_off = parse_real(get_param("g_off"), name + ".g_off", errors_);
            } else if (get_param("off_resistance")) {
                const Real r_off = parse_real(get_param("off_resistance"), name + ".off_resistance", errors_);
                g_off = (r_off > 0.0) ? (1.0 / r_off) : 1e-9;
            } else if (get_param("roff")) {
                const Real r_off = parse_real(get_param("roff"), name + ".roff", errors_);
                g_off = (r_off > 0.0) ? (1.0 / r_off) : 1e-9;
            }

            const std::string no_switch = name + "__no";
            const std::string nc_switch = name + "__nc";
            circuit.add_switch(no_switch, node_at(2), node_at(3), energized, g_on, g_off);
            circuit.add_switch(nc_switch, node_at(2), node_at(4), !energized, g_on, g_off);

            std::unordered_map<std::string, Real> numeric_params;
            numeric_params["initial_closed"] = energized ? 1.0 : 0.0;
            numeric_params["g_on"] = g_on;
            numeric_params["g_off"] = g_off;
            if (get_param("pickup_current")) {
                numeric_params["pickup_current"] = parse_real(get_param("pickup_current"), name + ".pickup_current", errors_);
            }
            if (get_param("dropout_current")) {
                numeric_params["dropout_current"] = parse_real(get_param("dropout_current"), name + ".dropout_current", errors_);
            }
            if (get_param("pickup_voltage")) {
                numeric_params["pickup_voltage"] = parse_real(get_param("pickup_voltage"), name + ".pickup_voltage", errors_);
            }
            if (get_param("dropout_voltage")) {
                numeric_params["dropout_voltage"] = parse_real(get_param("dropout_voltage"), name + ".dropout_voltage", errors_);
            }

            std::unordered_map<std::string, std::string> metadata;
            metadata["target_component"] = no_switch;
            metadata["target_component_no"] = no_switch;
            metadata["target_component_nc"] = nc_switch;
            circuit.add_virtual_component(type, name, node_indices, std::move(numeric_params), std::move(metadata));

            push_warning(warnings_, kDiagSurrogateComponent,
                         "Component '" + name + "' (relay) mapped to dual-switch surrogate with event controller");
        }
        else if (type == "thyristor" || type == "triac") {
            Real gate_threshold = get_param("gate_threshold")
                ? parse_real(get_param("gate_threshold"), name + ".gate_threshold", errors_)
                : 1.0;
            Real g_on = get_param("g_on") ? parse_real(get_param("g_on"), name + ".g_on", errors_) : 1e4;
            Real g_off = get_param("g_off") ? parse_real(get_param("g_off"), name + ".g_off", errors_) : 1e-9;
            Real holding_current = get_param("holding_current")
                ? parse_real(get_param("holding_current"), name + ".holding_current", errors_)
                : 0.05;
            Real latch_current = get_param("latch_current")
                ? parse_real(get_param("latch_current"), name + ".latch_current", errors_)
                : (holding_current * 1.2);

            circuit.add_switch(name, node_at(1), node_at(2), false, g_on, g_off);

            std::unordered_map<std::string, Real> numeric_params;
            numeric_params["gate_threshold"] = gate_threshold;
            numeric_params["holding_current"] = holding_current;
            numeric_params["latch_current"] = latch_current;
            numeric_params["g_on"] = g_on;
            numeric_params["g_off"] = g_off;
            numeric_params["initial_closed"] = 0.0;
            std::unordered_map<std::string, std::string> metadata;
            metadata["target_component"] = name;
            circuit.add_virtual_component(type, name, node_indices, std::move(numeric_params), std::move(metadata));

            push_warning(warnings_, kDiagSurrogateComponent,
                         "Component '" + name + "' (" + type + ") mapped to switch surrogate with latching event controller");
        }
        else if (type == "fuse" || type == "circuit_breaker") {
            Real g_on = get_param("g_on") ? parse_real(get_param("g_on"), name + ".g_on", errors_) : 1e4;
            Real g_off = get_param("g_off") ? parse_real(get_param("g_off"), name + ".g_off", errors_) : 1e-9;
            bool closed = true;
            YAML::Node state_node = get_param("initial_state");
            if (state_node.IsDefined() && !state_node.IsNull()) {
                if (state_node.IsScalar()) {
                    try {
                        closed = state_node.as<bool>();
                    } catch (...) {
                        const std::string state = normalize_key(state_node.as<std::string>());
                        closed = !(state == "open" || state == "tripped" || state == "blown" || state == "false");
                    }
                }
            }
            circuit.add_switch(name, node_at(0), node_at(1), closed, g_on, g_off);
            std::unordered_map<std::string, Real> numeric_params;
            numeric_params["g_on"] = g_on;
            numeric_params["g_off"] = g_off;
            numeric_params["initial_closed"] = closed ? 1.0 : 0.0;
            if (get_param("rating")) {
                numeric_params["rating"] = parse_real(get_param("rating"), name + ".rating", errors_);
            }
            if (type == "fuse") {
                YAML::Node blow_i2t = get_param("blow_i2t");
                if (!blow_i2t) blow_i2t = get_param("i2t");
                if (blow_i2t) {
                    numeric_params["blow_i2t"] = parse_real(blow_i2t, name + ".blow_i2t", errors_);
                }
            } else {
                YAML::Node trip_current = get_param("trip_current");
                if (!trip_current) trip_current = get_param("trip");
                if (trip_current) {
                    numeric_params["trip_current"] = parse_real(trip_current, name + ".trip_current", errors_);
                }
                if (get_param("trip_time")) {
                    numeric_params["trip_time"] = parse_real(get_param("trip_time"), name + ".trip_time", errors_);
                }
            }
            std::unordered_map<std::string, std::string> metadata;
            metadata["target_component"] = name;
            circuit.add_virtual_component(type, name, node_indices, std::move(numeric_params), std::move(metadata));
            push_warning(warnings_, kDiagSurrogateComponent,
                         "Component '" + name + "' (" + type + ") mapped to switch surrogate with event controller");
        }
        else if (type == "saturable_inductor") {
            YAML::Node l_node = get_param("inductance");
            if (!is_set(l_node)) l_node = get_param("value");
            const Real inductance = parse_real(l_node, name + ".inductance", errors_);
            if (inductance <= 0.0) {
                push_error(errors_, kDiagInvalidParameter,
                           "inductance must be > 0 for " + name);
                continue;
            }
            Real sat_current = get_param("saturation_current")
                ? parse_real(get_param("saturation_current"), name + ".saturation_current", errors_)
                : 1.0;
            if (magnetic_saturation_current.has_value()) {
                sat_current = *magnetic_saturation_current;
            }
            if (sat_current <= 0.0) {
                push_error(errors_, kDiagInvalidParameter,
                           "saturation_current must be > 0 for " + name);
                continue;
            }
            Real sat_inductance = get_param("saturation_inductance")
                ? parse_real(get_param("saturation_inductance"), name + ".saturation_inductance", errors_)
                : (0.2 * inductance);
            if (magnetic_saturation_inductance.has_value()) {
                sat_inductance = *magnetic_saturation_inductance;
            }
            if (sat_inductance <= 0.0 || sat_inductance > inductance) {
                push_error(errors_, kDiagInvalidParameter,
                           "saturation_inductance must be in (0, inductance] for " + name);
                continue;
            }
            Real ic = 0.0;
            if (get_param("ic")) ic = parse_real(get_param("ic"), name + ".ic", errors_);
            circuit.add_inductor(name, node_at(0), node_at(1), inductance, ic);
            std::unordered_map<std::string, Real> numeric_params;
            numeric_params["inductance"] = inductance;
            numeric_params["saturation_current"] = sat_current;
            numeric_params["saturation_inductance"] = sat_inductance;
            if (magnetic_saturation_exponent.has_value()) {
                numeric_params["saturation_exponent"] = *magnetic_saturation_exponent;
            } else if (get_param("saturation_exponent")) {
                numeric_params["saturation_exponent"] =
                    parse_real(get_param("saturation_exponent"), name + ".saturation_exponent", errors_);
            }
            if (magnetic_core_defined) {
                numeric_params["magnetic_core_enabled"] = magnetic_core_enabled ? 1.0 : 0.0;
                numeric_params["core_loss_k"] = magnetic_core_enabled ? magnetic_core_loss_k : 0.0;
                numeric_params["core_loss_alpha"] = magnetic_core_loss_alpha;
                numeric_params["core_loss_freq_coeff"] = magnetic_core_loss_freq_coeff;
                numeric_params["magnetic_i_equiv_init"] = magnetic_i_equiv_init;
                if (magnetic_hysteresis_band.has_value()) {
                    numeric_params["hysteresis_band"] = *magnetic_hysteresis_band;
                }
                numeric_params["hysteresis_strength"] = magnetic_hysteresis_strength;
                numeric_params["hysteresis_loss_coeff"] = magnetic_hysteresis_loss_coeff;
                numeric_params["hysteresis_state_init"] = magnetic_hysteresis_state_init;
            }
            std::unordered_map<std::string, std::string> metadata;
            metadata["target_component"] = name;
            if (magnetic_core_defined) {
                metadata["magnetic_core_model"] = magnetic_core_model;
                metadata["magnetic_core_loss_policy"] = magnetic_core_loss_policy;
            }
            circuit.add_virtual_component(type, name, node_indices, std::move(numeric_params), std::move(metadata));
            push_warning(warnings_, kDiagVirtualComponent,
                         "Component '" + name + "' (saturable_inductor) registered with nonlinear inductance controller");
        }
        else if (type == "coupled_inductor") {
            Real l1 = get_param("l1")
                ? parse_real(get_param("l1"), name + ".l1", errors_)
                : (get_param("inductance") ? parse_real(get_param("inductance"), name + ".inductance", errors_) : 1e-3);
            Real l2 = get_param("l2")
                ? parse_real(get_param("l2"), name + ".l2", errors_)
                : l1;

            if (l1 <= 0.0 || l2 <= 0.0) {
                push_error(errors_, kDiagInvalidParameter,
                           "l1 and l2 must be > 0 for " + name);
                continue;
            }

            Real k = 0.98;
            if (get_param("coupling")) {
                k = parse_real(get_param("coupling"), name + ".coupling", errors_);
            } else if (get_param("k")) {
                k = parse_real(get_param("k"), name + ".k", errors_);
            } else if (get_param("mutual_inductance")) {
                const Real m = parse_real(get_param("mutual_inductance"), name + ".mutual_inductance", errors_);
                k = m / std::sqrt(l1 * l2);
            }
            if (std::abs(k) > 0.999) {
                push_error(errors_, kDiagInvalidParameter,
                           "coupling must satisfy |k| <= 0.999 for " + name);
                continue;
            }

            Real ic1 = 0.0;
            Real ic2 = 0.0;
            if (get_param("ic1")) ic1 = parse_real(get_param("ic1"), name + ".ic1", errors_);
            else if (get_param("ic_primary")) ic1 = parse_real(get_param("ic_primary"), name + ".ic_primary", errors_);
            if (get_param("ic2")) ic2 = parse_real(get_param("ic2"), name + ".ic2", errors_);
            else if (get_param("ic_secondary")) ic2 = parse_real(get_param("ic_secondary"), name + ".ic_secondary", errors_);

            const std::string l1_name = name + "__L1";
            const std::string l2_name = name + "__L2";
            circuit.add_inductor(l1_name, node_at(0), node_at(1), l1, ic1);
            circuit.add_inductor(l2_name, node_at(2), node_at(3), l2, ic2);

            std::unordered_map<std::string, Real> numeric_params;
            numeric_params["l1"] = l1;
            numeric_params["l2"] = l2;
            numeric_params["coupling"] = k;
            numeric_params["k"] = k;
            if (magnetic_core_defined) {
                numeric_params["magnetic_core_enabled"] = magnetic_core_enabled ? 1.0 : 0.0;
                numeric_params["core_loss_k"] = magnetic_core_enabled ? magnetic_core_loss_k : 0.0;
                numeric_params["core_loss_alpha"] = magnetic_core_loss_alpha;
                numeric_params["core_loss_freq_coeff"] = magnetic_core_loss_freq_coeff;
                numeric_params["magnetic_i_equiv_init"] = magnetic_i_equiv_init;
                if (magnetic_hysteresis_band.has_value()) {
                    numeric_params["hysteresis_band"] = *magnetic_hysteresis_band;
                }
                numeric_params["hysteresis_strength"] = magnetic_hysteresis_strength;
                numeric_params["hysteresis_loss_coeff"] = magnetic_hysteresis_loss_coeff;
                numeric_params["hysteresis_state_init"] = magnetic_hysteresis_state_init;
            }
            std::unordered_map<std::string, std::string> metadata;
            metadata["target_component_1"] = l1_name;
            metadata["target_component_2"] = l2_name;
            if (magnetic_core_defined) {
                metadata["magnetic_core_model"] = magnetic_core_model;
                metadata["magnetic_core_loss_policy"] = magnetic_core_loss_policy;
            }
            circuit.add_virtual_component(type, name, node_indices, std::move(numeric_params), std::move(metadata));

            push_warning(warnings_, kDiagVirtualComponent,
                         "Component '" + name + "' (coupled_inductor) expanded to coupled inductor pair");
        }
        else if (virtual_component_types().contains(type)) {
            std::unordered_map<std::string, Real> numeric_params;
            std::unordered_map<std::string, std::string> metadata;
            collect_virtual_component_fields(comp, numeric_params, metadata);
            YAML::Node target = get_param("target_component");
            if (!target) target = get_param("target");
            if (target && target.IsScalar()) {
                metadata["target_component"] = target.as<std::string>();
            }

            auto has_num = [&](const std::string& key) {
                return numeric_params.find(key) != numeric_params.end();
            };
            auto get_num = [&](const std::string& key, Real fallback) {
                const auto it = numeric_params.find(key);
                return (it == numeric_params.end()) ? fallback : it->second;
            };
            auto metadata_node = [&](const std::string& key) -> YAML::Node {
                const auto it = metadata.find(key);
                if (it == metadata.end()) return YAML::Node();
                try {
                    return YAML::Load(it->second);
                } catch (...) {
                    return YAML::Node();
                }
            };
            auto metadata_sequence_size = [&](const std::string& key) -> std::size_t {
                const YAML::Node node = metadata_node(key);
                if (!node || !node.IsSequence()) return 0;
                return node.size();
            };

            if (type == "op_amp") {
                const Real lo = get_num("rail_low", -15.0);
                const Real hi = get_num("rail_high", 15.0);
                if (lo >= hi) {
                    push_error(errors_, kDiagInvalidParameter,
                               "rail_low must be < rail_high for " + name);
                    continue;
                }
            } else if (type == "comparator" || type == "hysteresis") {
                const Real hyst = get_num("hysteresis", 0.0);
                if (hyst < 0.0) {
                    push_error(errors_, kDiagInvalidParameter,
                               "hysteresis must be >= 0 for " + name);
                    continue;
                }
                const Real low = get_num("low", 0.0);
                const Real high = get_num("high", 1.0);
                if (high < low) {
                    push_error(errors_, kDiagInvalidParameter,
                               "high must be >= low for " + name);
                    continue;
                }
            } else if (type == "pi_controller" || type == "pid_controller") {
                if (has_num("output_min") && has_num("output_max")) {
                    if (get_num("output_min", 0.0) > get_num("output_max", 0.0)) {
                        push_error(errors_, kDiagInvalidParameter,
                                   "output_min must be <= output_max for " + name);
                        continue;
                    }
                }
            } else if (type == "gain" || type == "sum" || type == "subtraction") {
                if (has_num("output_min") && has_num("output_max")) {
                    if (get_num("output_min", 0.0) > get_num("output_max", 0.0)) {
                        push_error(errors_, kDiagInvalidParameter,
                                   "output_min must be <= output_max for " + name);
                        continue;
                    }
                }
            } else if (type == "integrator" || type == "limiter") {
                if (has_num("output_min") && has_num("output_max")) {
                    if (get_num("output_min", 0.0) > get_num("output_max", 0.0)) {
                        push_error(errors_, kDiagInvalidParameter,
                                   "output_min must be <= output_max for " + name);
                        continue;
                    }
                }
                if (has_num("min") && has_num("max")) {
                    if (get_num("min", 0.0) > get_num("max", 0.0)) {
                        push_error(errors_, kDiagInvalidParameter,
                                   "min must be <= max for " + name);
                        continue;
                    }
                }
            } else if (type == "differentiator") {
                if (has_num("alpha")) {
                    const Real alpha = get_num("alpha", 0.0);
                    if (alpha < 0.0 || alpha > 1.0) {
                        push_error(errors_, kDiagInvalidParameter,
                                   "alpha must be in [0, 1] for " + name);
                        continue;
                    }
                }
            } else if (type == "rate_limiter") {
                if (has_num("rising_rate") && get_num("rising_rate", 0.0) < 0.0) {
                    push_error(errors_, kDiagInvalidParameter,
                               "rising_rate must be >= 0 for " + name);
                    continue;
                }
                if (has_num("falling_rate") && get_num("falling_rate", 0.0) < 0.0) {
                    push_error(errors_, kDiagInvalidParameter,
                               "falling_rate must be >= 0 for " + name);
                    continue;
                }
            } else if (type == "lookup_table") {
                const std::size_t x_size = metadata_sequence_size("x");
                const std::size_t y_size = metadata_sequence_size("y");
                std::size_t point_count = 0;
                if (x_size > 0 || y_size > 0) {
                    if (x_size != y_size || x_size < 2) {
                        push_error(errors_, kDiagInvalidParameter,
                                   "lookup_table requires x and y arrays with the same size >= 2 for " + name);
                        continue;
                    }
                    point_count = x_size;
                } else {
                    const YAML::Node table = metadata_node("table");
                    if (table && table.IsSequence() && table.size() >= 2) {
                        point_count = table.size();
                    } else {
                        const YAML::Node mapping = metadata_node("mapping");
                        if (mapping && mapping.IsMap() && mapping.size() >= 2) {
                            point_count = mapping.size();
                        }
                    }
                }
                if (point_count < 2) {
                    push_error(errors_, kDiagInvalidParameter,
                               "lookup_table requires at least two points (x/y, table, or mapping) for " + name);
                    continue;
                }
            } else if (type == "transfer_function") {
                const std::size_t num_size = metadata_sequence_size("num");
                const std::size_t den_size = metadata_sequence_size("den");
                if ((num_size > 0) != (den_size > 0)) {
                    push_error(errors_, kDiagInvalidParameter,
                               "transfer_function requires both num and den arrays for " + name);
                    continue;
                }
                if (den_size > 0) {
                    const YAML::Node den = metadata_node("den");
                    if (!den || !den.IsSequence() || den.size() == 0) {
                        push_error(errors_, kDiagInvalidParameter,
                                   "transfer_function den must be a non-empty array for " + name);
                        continue;
                    }
                    bool den0_ok = false;
                    try {
                        den0_ok = std::abs(den[0].as<Real>()) > 1e-15;
                    } catch (...) {
                        den0_ok = false;
                    }
                    if (!den0_ok) {
                        push_error(errors_, kDiagInvalidParameter,
                                   "transfer_function den[0] must be non-zero for " + name);
                        continue;
                    }
                }
            } else if (type == "delay_block") {
                if (has_num("delay") && get_num("delay", 0.0) < 0.0) {
                    push_error(errors_, kDiagInvalidParameter,
                               "delay must be >= 0 for " + name);
                    continue;
                }
            } else if (type == "sample_hold") {
                if (has_num("sample_period") && get_num("sample_period", 0.0) < 0.0) {
                    push_error(errors_, kDiagInvalidParameter,
                               "sample_period must be >= 0 for " + name);
                    continue;
                }
            } else if (type == "state_machine") {
                const auto mode_it = metadata.find("mode");
                if (mode_it != metadata.end()) {
                    const std::string mode = normalize_key(mode_it->second);
                    if (mode != "toggle" && mode != "level" &&
                        mode != "set_reset" && mode != "sr") {
                        push_error(errors_, kDiagInvalidParameter,
                                   "state_machine mode must be toggle/level/set_reset/sr for " + name);
                        continue;
                    }
                }
            } else if (type == "pwm_generator") {
                const Real freq = get_num("frequency", 1e3);
                if (freq <= 0.0) {
                    push_error(errors_, kDiagInvalidParameter,
                               "frequency must be > 0 for " + name);
                    continue;
                }
                if (has_num("duty")) {
                    const Real duty = get_num("duty", 0.5);
                    if (duty < 0.0 || duty > 1.0) {
                        push_error(errors_, kDiagInvalidParameter,
                                   "duty must be in [0, 1] for " + name);
                        continue;
                    }
                }
                const Real duty_min = get_num("duty_min", 0.0);
                const Real duty_max = get_num("duty_max", 1.0);
                if (duty_min < 0.0 || duty_min > 1.0 ||
                    duty_max < 0.0 || duty_max > 1.0 || duty_min > duty_max) {
                    push_error(errors_, kDiagInvalidParameter,
                               "duty_min/duty_max must satisfy 0 <= duty_min <= duty_max <= 1 for " + name);
                    continue;
                }
            } else if (type == "math_block") {
                const auto op_it = metadata.find("operation");
                if (op_it != metadata.end()) {
                    const std::string op = normalize_key(op_it->second);
                    if (op != "add" && op != "sub" && op != "mul" && op != "div") {
                        push_error(errors_, kDiagInvalidParameter,
                                   "operation must be add/sub/mul/div for " + name);
                        continue;
                    }
                }
            } else if (type == "c_block") {
                // n_inputs is required (int >= 1)
                const YAML::Node n_inputs_node = get_param("n_inputs");
                if (!n_inputs_node) {
                    push_error(errors_, kDiagInvalidParameter,
                               "c_block '" + name + "' missing required parameter 'n_inputs'");
                    continue;
                }
                const std::optional<int> n_inputs =
                    parse_int_scalar(n_inputs_node, name + ".n_inputs", errors_);
                if (!n_inputs) {
                    push_error(errors_, kDiagInvalidParameter,
                               "c_block '" + name + "' n_inputs must be an integer >= 1");
                    continue;
                }
                if (*n_inputs < 1) {
                    push_error(errors_, kDiagInvalidParameter,
                               "c_block '" + name + "' n_inputs must be >= 1");
                    continue;
                }
                numeric_params["n_inputs"] = static_cast<Real>(*n_inputs);

                // n_outputs is required (int >= 1)
                const YAML::Node n_outputs_node = get_param("n_outputs");
                if (!n_outputs_node) {
                    push_error(errors_, kDiagInvalidParameter,
                               "c_block '" + name + "' missing required parameter 'n_outputs'");
                    continue;
                }
                const std::optional<int> n_outputs =
                    parse_int_scalar(n_outputs_node, name + ".n_outputs", errors_);
                if (!n_outputs) {
                    push_error(errors_, kDiagInvalidParameter,
                               "c_block '" + name + "' n_outputs must be an integer >= 1");
                    continue;
                }
                if (*n_outputs < 1) {
                    push_error(errors_, kDiagInvalidParameter,
                               "c_block '" + name + "' n_outputs must be >= 1");
                    continue;
                }
                numeric_params["n_outputs"] = static_cast<Real>(*n_outputs);

                // Optional extra_cflags: must be a sequence of strings.
                const YAML::Node extra_cflags_node = get_param("extra_cflags");
                if (extra_cflags_node && !extra_cflags_node.IsNull()) {
                    if (!extra_cflags_node.IsSequence()) {
                        push_type_mismatch_error(
                            errors_,
                            name + ".extra_cflags",
                            "sequence[string]",
                            extra_cflags_node);
                        continue;
                    }

                    bool flag_type_error = false;
                    for (std::size_t flag_index = 0; flag_index < extra_cflags_node.size(); ++flag_index) {
                        const YAML::Node flag_node = extra_cflags_node[flag_index];
                        if (!flag_node.IsScalar()) {
                            push_type_mismatch_error(
                                errors_,
                                name + ".extra_cflags[" + std::to_string(flag_index) + "]",
                                "string",
                                flag_node);
                            flag_type_error = true;
                            continue;
                        }
                        try {
                            (void)flag_node.as<std::string>();
                        } catch (...) {
                            push_type_mismatch_error(
                                errors_,
                                name + ".extra_cflags[" + std::to_string(flag_index) + "]",
                                "string",
                                flag_node);
                            flag_type_error = true;
                        }
                    }
                    if (flag_type_error) {
                        continue;
                    }
                }

                // Exactly one of lib_path or source may be specified.
                const YAML::Node lib_path_node = get_param("lib_path");
                const YAML::Node source_node = get_param("source");
                const bool has_lib_path = lib_path_node && !lib_path_node.IsNull();
                const bool has_source = source_node && !source_node.IsNull();
                if (has_lib_path && has_source) {
                    push_error(errors_, kDiagInvalidParameter,
                               "c_block '" + name + "' specifies both 'lib_path' and 'source'; only one is allowed");
                    continue;
                }

                std::optional<std::string> lib_path;
                if (has_lib_path) {
                    lib_path = parse_string_scalar(lib_path_node, name + ".lib_path", errors_);
                    if (!lib_path) {
                        continue;
                    }
                    metadata["lib_path"] = *lib_path;
                }

                std::optional<std::string> source_path;
                if (has_source) {
                    source_path = parse_string_scalar(source_node, name + ".source", errors_);
                    if (!source_path) {
                        continue;
                    }
                    metadata["source"] = *source_path;
                }

                if (!has_lib_path && !has_source) {
                    push_warning(warnings_, kDiagVirtualComponent,
                                 "c_block '" + name + "' has neither 'lib_path' nor 'source'; valid for Python-only usage");
                } else if (lib_path.has_value()) {
                    if (!std::filesystem::exists(*lib_path)) {
                        push_warning(warnings_, kDiagVirtualComponent,
                                     "c_block '" + name + "' lib_path '" + *lib_path + "' does not exist at parse time");
                    }
                } else if (source_path.has_value()) {
                    if (!std::filesystem::exists(*source_path)) {
                        push_warning(warnings_, kDiagVirtualComponent,
                                     "c_block '" + name + "' source '" + *source_path + "' does not exist at parse time");
                    }
                }
            }

            const YAML::Node sample_time_node = [&]() -> YAML::Node {
                if (const YAML::Node node = get_param("sample_time");
                    node && !node.IsNull()) {
                    return node;
                }
                if (const YAML::Node node = get_param("ts");
                    node && !node.IsNull()) {
                    return node;
                }
                if (const YAML::Node node = get_param("Ts");
                    node && !node.IsNull()) {
                    return node;
                }
                return YAML::Node();
            }();

            if (sample_time_node && !sample_time_node.IsNull()) {
                if (!virtual_component_supports_sample_time(type)) {
                    push_error(
                        errors_,
                        kDiagInvalidParameter,
                        "sample_time/ts is only supported for control virtual blocks; got '" +
                            type + "' on component '" + name + "'");
                    continue;
                }
                const Real sample_time =
                    parse_real(sample_time_node, name + ".sample_time", errors_);
                if (!std::isfinite(sample_time) || sample_time < 0.0) {
                    push_error(
                        errors_,
                        kDiagInvalidParameter,
                        name + ".sample_time must be finite and >= 0");
                    continue;
                }
                numeric_params["sample_time"] = sample_time;
                numeric_params.erase("ts");
                numeric_params.erase("Ts");
            }

            circuit.add_virtual_component(type, name, node_indices,
                                          std::move(numeric_params), std::move(metadata));
            push_warning(warnings_, kDiagVirtualComponent,
                         "Component '" + name + "' (" + type + ") registered as virtual runtime node");
        }
        else {
            push_error(errors_, kDiagUnsupportedComponent,
                       "Unsupported component type: " + type);
        }
    }
}

}  // namespace pulsim::v1::parser
