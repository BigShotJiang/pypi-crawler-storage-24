from typing import List
from uuid import UUID

from sqlmodel import select

from healthdatalayer.models import CatalogEntry
from healthdatalayer.repositories.base_repository import BaseRepository


class CatalogEntryRepository(BaseRepository[CatalogEntry]):
    def __init__(self, tenant: str):
        super().__init__(tenant, CatalogEntry)

    def list_by_catalog_id_command(self, catalog_id: UUID, active_only: bool = True) -> List[CatalogEntry]:
        with self._get_session() as session:
            statement = select(CatalogEntry).where(CatalogEntry.catalog_id == catalog_id)
            statement = self._apply_active_filter(statement, active_only)
            results = session.exec(statement)
            return results.all()
