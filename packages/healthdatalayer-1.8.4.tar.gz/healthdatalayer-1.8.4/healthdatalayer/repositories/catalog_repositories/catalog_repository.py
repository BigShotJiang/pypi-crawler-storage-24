from typing import List, Optional
from uuid import UUID

from sqlmodel import select

from sqlalchemy.orm import joinedload, selectinload

from healthdatalayer.models import Catalog
from healthdatalayer.repositories.base_repository import BaseRepository


class CatalogRepository(BaseRepository[Catalog]):
    def __init__(self, tenant: str):
        super().__init__(tenant, Catalog)
    
    def _detail_options(self):
        return (
            selectinload(Catalog.entries)
        )
    
    def _apply_load_options(self, statement, load_details: bool):
        options = []
        if load_details:
            options.extend(self._detail_options())
        if options:
            return statement.options(*options)
        return statement

    def get_by_id_command(
        self,
        catalog_id: UUID,
        load_details: bool = False,
        active_only: bool = True,
    ) -> Optional[Catalog]:
        with self._get_session() as session:
            statement = select(Catalog).where(Catalog.catalog_id == catalog_id)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).first()
        
    def list_all_command(
        self,
        active_only: bool = True,
        load_details: bool = False,
    ) -> List[Catalog]:
        with self._get_session() as session:
            statement = select(Catalog)
            statement = self._apply_active_filter(statement, active_only)
            statement = self._apply_load_options(statement, load_details)
            return session.exec(statement).all()