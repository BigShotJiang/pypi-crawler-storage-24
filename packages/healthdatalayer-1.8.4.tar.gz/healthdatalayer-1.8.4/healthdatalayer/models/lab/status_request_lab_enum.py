from enum import Enum

class StatusRequestLabEnum(str, Enum):
    PENDIENTE = "PENDIENTE"
    ENVIADO = "ENVIADO"
    ATENDIDO = "ATENDIDO"