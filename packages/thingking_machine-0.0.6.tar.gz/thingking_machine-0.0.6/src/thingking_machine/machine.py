# -*- coding: utf-8 -*-
# Python

"""Copyright (c) Alexander Fedotov.
This source code is licensed under the license found in the
LICENSE file in the root directory of this source tree.
"""
import sys
from os import environ, path
from .githf import fetch_instructions
from .utilities import (plato_text_to_muj,
                        plato_text_to_mpuj,
                        llm_soup_to_text)


def machine(plato_text, config, **kwargs):
    """Core agent logic.

    1. Fetches the system prompt from a private GitHub repo.
    2. Calls Provider
    3. Returns a (thoughts, text) tuple.
    """
    # Fetch the confidential system prompt, name is for a checkup.
    name, system_prompt = fetch_instructions(config)

    # Load an appropriate library and query the API.
    provider = config.provider
    api_key  = config.provider_api_key
    
    if provider == 'OpenAI':
        # Transform plato_text to MUJ format
        messages = plato_text_to_muj(plato_text=plato_text,
                                     machine_name=name)
        # Call OpenAI API via opehaina
        environ['OPENAI_API_KEY'] = api_key
        try:
            import opehaina
        except ImportError:
            print("To use OpenAI, install the package with the feature enabled: \n pip install \"thingking-machine[openai]\"", file=sys.stderr)
            sys.exit(1)
            
        thoughts, text = opehaina.respond(
            messages=messages,
            instructions=system_prompt,
            **kwargs
        )

        thoughts = llm_soup_to_text(thoughts)
        return thoughts, text

    elif provider == 'Gemini':
        # Transform plato_text to MPUJ format
        messages = plato_text_to_mpuj(plato_text=plato_text,
                                     machine_name=name)
        # Call Gemini through castor-polux
        environ['GEMINI_API_KEY'] = api_key
        try:
            import castor_pollux
        except ImportError:
            print("To use Gemini, install the package with the feature enabled: \n pip install \"thingking-machine[gemini]\"", file=sys.stderr)
            sys.exit(1)
            
        thoughts, text = castor_pollux.respond(
            messages=messages,
            instructions=system_prompt,
            **kwargs
        )

        thoughts = llm_soup_to_text(thoughts)
        return thoughts, text

    elif provider == 'Anthropic':
        # Transform plato_text to MUJ format
        messages = plato_text_to_muj(plato_text=plato_text,
                                     machine_name=name)

        # Call the Anthropic API via electroid
        environ['ANTHROPIC_API_KEY'] = api_key
        try:
            import electroid
        except ImportError:
            print("To use Anthropic, install the package with the feature enabled: \n pip install \"thingking-machine[anthropic]\"", file=sys.stderr)
            sys.exit(1)
            
        text, thoughts = electroid.respond(
            messages=messages,
            instructions=system_prompt,
            **kwargs
        )
        return text, thoughts

    elif provider == 'Groq':
        pass
    elif provider == 'Xai':
        pass
    elif provider == 'Meta':
        pass

if __name__ == '__main__':
    from .config import Config
    machine([], Config())
