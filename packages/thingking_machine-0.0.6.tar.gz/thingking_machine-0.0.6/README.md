# Thingking Machine
A Machine that thingks.

In order to launch it with OpenAI as LLM provider:
```bash
  echo "Theodotos-Alexandreus: Are language models seeking the Truth, machine?" \
    | uvx thingking-machine \
        --provider-api-key=sk-proj-... \
        --github-token=ghp_... 
```
Or with Anthropic:
```bash
  echo "Theodotos-Alexandreus: Are language models seeking the Truth, machine?" \
    | uvx --with "thingking-machine[anthropic]" thingking-machine \
        --provider-api-key=sk-ant-... \
        --github-token=ghp_... 
```
Or with Gemini:
```bash
  echo "Theodotos-Alexandreus: Are language models seeking the Truth, machine?" \
    | uvx --with "thingking-machine[gemini]" thingking-machine \
        --provider-api-key=AIzaSy... \
        --github-token=ghp_... 
```
Or:
```bash
  pip install thingking-machine
```
Then:
```Python
  # Python
  import thingking_machine
```
