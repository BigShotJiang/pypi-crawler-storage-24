[![Latest Release](https://gitlab.com/dslackw/sun/-/badges/release.svg)](https://gitlab.com/dslackw/sun/-/releases)
[![pipeline status](https://img.shields.io/badge/pipeline-master-blue)](https://gitlab.com/dslackw/sun/-/commits/master)
[![coverage report](https://gitlab.com/dslackw/sun/badges/master/coverage.svg)](https://gitlab.com/dslackw/sun/-/commits/master)
[![Python](https://img.shields.io/badge/python-3.9_|_3.12-blue)](https://www.python.org/)
[![Code style: flake8](https://img.shields.io/badge/code%20style-flake8-orange)](https://flake8.pycqa.org/)
[![Type checked: mypy](https://img.shields.io/badge/type%20checked-mypy-blue)](https://mypy-lang.org/)
[![Linting: pylint](https://img.shields.io/badge/linting-pylint-yellowgreen)](https://pylint.org/)
[![License: GPL v3](https://img.shields.io/badge/license-GPLv3-blue)](LICENSE)

## About

Let's SUN!

SUN (Slackware Update Notifier) is a tray notification applet
and daemon for informing about package updates in Slackware.
It also serves as a CLI tool for monitoring upgraded packages.

SUN works by default with slackpkg, as well as with other tools
like slpkg. You can probably use SUN with other Slackware-based
Linux distributions as well.

## Documentation

https://dslackw.gitlab.io/sun/

## Manual

After installation, the manual page is available via:

```
man sun
```
