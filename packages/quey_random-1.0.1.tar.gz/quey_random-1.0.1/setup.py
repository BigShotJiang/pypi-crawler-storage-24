from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name='quey-random',
    version='1.0.1',
    description='True Quantum Randomness Library powered by Quey Hardware Node',
    long_description=long_description,
    long_description_content_type="text/markdown",
    author='Aaron Loeb',
    packages=find_packages(),
    install_requires=[
        'requests>=2.25.0',
    ],
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Science/Research',
        'Topic :: Security :: Cryptography',
        'Programming Language :: Python :: 3',
    ],
)
