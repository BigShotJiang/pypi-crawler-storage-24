# Quey Random SDK 

**Quey Random** is a professional Software Development Kit (SDK) that provides True Quantum Random Number Generation (QRNG) directly to your Python applications. 

Unlike pseudo-random number generators (PRNGs) relying on deterministic algorithms, the Quey SDK interfaces with a dedicated **Quey Hardware Node** (Raspberry Pi + NoIR Camera sensor) to extract true physical entropy from photonic noise in real-time.

## Features
* **True Hardware Entropy:** Randomness derived from quantum observable phenomena.
* **Scientific Distributions:** Built-in functions for Gaussian (normal) and Poisson distributions.
* **Complex Quantum States:** Generate random complex phases for wave function simulations.

## Installation

```bash
pip install quey-random
```
##Quick Start
Ensure your quey_api.key is in the same directory as your Python script.
```python
from quey_random import QueyRandom

# Connect to your local Quey Hardware Node
quey = QueyRandom(host='192.168.1.249', port=5000, key_file='quey_api.key')

# Generate a uniform true random float
val = quey.random()
print(f"Photonic Entropy: {val}")

# Generate quantum phase noise (Gaussian)
noise = quey.gauss(mu=0.0, sigma=1.0)
print(f"Phase Noise: {noise}")
```
