"""
Quey Quantum Randomness Library.
Provides true random number generation mimicking the standard 'random' module.
"""

from .generator import (
    random, randint, choice, choices, 
    gauss, expovariate, poisson, complex_phase, 
    QueyRandom
)

__all__ = [
    'random', 'randint', 'choice', 'choices', 
    'gauss', 'expovariate', 'poisson', 'complex_phase', 
    'QueyRandom'
]

