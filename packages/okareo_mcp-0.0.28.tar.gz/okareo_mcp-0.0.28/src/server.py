"""FastMCP server entry point for the Okareo MCP server.

Validates the API key at startup, registers all MCP tools, and runs the server.
Supports stdio (default) and SSE transports via the TRANSPORT environment variable.

Error handling strategy: The server always starts, even if the Okareo API is
unreachable or the API key is invalid. Tools attempt lazy re-initialization
on each call, so the server auto-recovers when the API becomes available.
"""

import os
import sys
from contextlib import asynccontextmanager

from mcp.server.fastmcp import FastMCP

from src.analytics import emit_tool_event, init_analytics, shutdown_analytics
from src.error_handling import format_tool_error
from src.key_registry import scan_provider_keys
from src.okareo_client import create_okareo_client
from src.tools import checks, docs, models, scenarios, simulations, tests

_server_ready = False
_analytics_client = None
# Cached Okareo client; None when not yet initialized or init failed.
_okareo_client = None
_key_registry: dict[str, str] = {}


@asynccontextmanager
async def lifespan(server: FastMCP):
    """Initialize Okareo client at startup. Never crashes — always yields."""
    global _server_ready, _okareo_client, _key_registry

    api_key = os.environ.get("OKAREO_API_KEY", "").strip()

    if not api_key:
        print(
            "OKAREO_API_KEY environment variable is not set. "
            "Get your API key from app.okareo.com and configure it "
            "in your MCP server settings.",
            file=sys.stderr,
        )
        # Server starts in degraded mode; tools will report the error.
        try:
            yield {"okareo": None, "key_registry": {}, "analytics": None}
        finally:
            pass
        return

    base_url = os.environ.get("OKAREO_BASE_URL", "https://api.okareo.com/")
    print(
        f"Base URL for Connection {base_url}. ",
        file=sys.stderr,
    )

    okareo = None
    # Redirect stdout to stderr during SDK init so any SDK prints
    # (e.g. validation errors) don't corrupt the MCP stdio protocol.
    _real_stdout = sys.stdout
    sys.stdout = sys.stderr
    try:
        okareo = create_okareo_client(api_key, base_url)
    except Exception as e:
        # Catch ALL exceptions — never crash during startup.
        print(
            f"Okareo client initialization failed ({type(e).__name__}): {e}. "
            "Server will attempt to reconnect on first tool call.",
            file=sys.stderr,
        )
    finally:
        sys.stdout = _real_stdout

    if okareo is None:
        # Degraded mode: tools will attempt lazy re-initialization.
        try:
            yield {"okareo": None, "key_registry": {}, "analytics": None}
        finally:
            pass
        return

    _okareo_client = okareo
    _key_registry = scan_provider_keys()
    if _key_registry:
        provider_names = ", ".join(sorted(_key_registry.keys()))
        print(f"Provider keys loaded: {provider_names}", file=sys.stderr)
    else:
        print("No provider API keys configured.", file=sys.stderr)

    transport = os.environ.get("TRANSPORT", "stdio")
    port = os.environ.get("PORT", "8000")
    print(
        f"Okareo MCP server started successfully. "
        f"Transport: {transport}, Port: {port}",
        file=sys.stderr,
    )
    global _analytics_client
    _analytics_client = init_analytics()

    _server_ready = True
    try:
        yield {
            "okareo": okareo,
            "key_registry": _key_registry,
            "analytics": _analytics_client,
        }
    finally:
        _server_ready = False
        await shutdown_analytics(_analytics_client)
        _analytics_client = None


mcp = FastMCP(
    "okareo-mcp",
    instructions=(
        "Use the Okareo tools proactively whenever the user is working with AI evaluation, "
        "LLM quality testing, scenario management, or model registration.\n\n"
        "TOOL DOMAINS:\n"
        "- Scenarios: save_scenario, list_scenarios, get_scenario, create_scenario_version, "
        "preview_delete_scenario, delete_scenario\n"
        "- Generation Models: list_available_llms, register_generation_model, "
        "list_generation_models, get_generation_model, update_generation_model, "
        "delete_generation_model\n"
        "- Tests & Checks: list_checks, run_test, list_test_runs, get_test_run_results, "
        "create_or_update_check, generate_check, get_check, delete_check\n"
        "- Simulations: create_or_update_target, get_target, list_targets, delete_target, "
        "create_or_update_driver, get_driver, list_drivers, run_simulation, list_simulations\n"
        "- Documentation: get_docs, get_templates\n\n"
        "KEY WORKFLOWS:\n"
        "1. Evaluate a model: list_scenarios and list_generation_models to discover existing "
        "resources → save_scenario to create test data → register_generation_model to register "
        "the model → list_checks to see available quality checks → run_test to evaluate → "
        "get_test_run_results to retrieve scores.\n"
        "2. Simulate multi-turn conversations: create_or_update_target to define the AI system "
        "under test (supports SSE streaming via 'streaming' config in next_message_params) → "
        "create_or_update_driver to define a simulated user persona → save_scenario "
        "for test cases → run_simulation to execute → get_test_run_results for transcripts and "
        "scores.\n"
        "3. Create custom checks: get_templates for check prompt/code templates → "
        "create_or_update_check to register a check → or generate_check to "
        "AI-generate a check from a description → list_checks to verify.\n"
        "4. Learn about Okareo: get_docs for conceptual explanations → get_templates for starter "
        "templates (check prompts, driver personas, scenarios).\n\n"
        "BEST PRACTICES:\n"
        "- When the user wants to test or evaluate an AI model, start by listing existing "
        "scenarios and models to avoid creating duplicates.\n"
        "- Always call list_checks before run_test so you can suggest appropriate quality checks.\n"
        "- Use get_docs when the user asks conceptual questions about Okareo (e.g., 'what is a "
        "scenario?', 'how do checks work?').\n"
        "- Use get_templates when the user wants to create custom checks, driver personas, or "
        "configure SSE streaming for custom endpoint targets.\n"
        "- For run_test, default to detail_level='aggregate' for quick results; use 'detailed' "
        "when the user wants to see individual scores and model outputs.\n"
        "- Use generate_check when the user describes what they want to evaluate in plain language — "
        "it creates the check automatically without manual prompt or code authoring.\n"
        "- Use get_check to inspect a check's full configuration (prompt template or code). "
        "Use create_or_update_check to create checks with specific prompts or code."
    ),
    lifespan=lifespan,
    host=os.environ.get("FASTMCP_HOST", "127.0.0.1"),
    port=int(os.environ.get("FASTMCP_PORT", "8000")),
)

# Register all tools
tests.register_tools(mcp)
scenarios.register_tools(mcp)
models.register_tools(mcp)
simulations.register_tools(mcp)
checks.register_tools(mcp)
docs.register_tools(mcp)

# Instrument tool calls with analytics and graceful error handling
_original_call_tool = mcp.call_tool


async def _instrumented_call_tool(name, arguments):
    global _okareo_client, _key_registry

    # Lazy re-initialization: if client is None, attempt to create it.
    # This enables auto-recovery after a failed startup.
    if _okareo_client is None:
        api_key = os.environ.get("OKAREO_API_KEY", "").strip()
        if not api_key:
            return [
                format_tool_error(
                    ValueError(
                        "OKAREO_API_KEY is not set. "
                        "Get your key at app.okareo.com and add it to "
                        "your MCP server configuration."
                    ),
                    _key_registry,
                )
            ]
        base_url = os.environ.get("OKAREO_BASE_URL", "https://api.okareo.com/")
        try:
            _okareo_client = create_okareo_client(api_key, base_url)
            _key_registry = scan_provider_keys()
        except Exception as e:
            return [format_tool_error(e, _key_registry)]

    success = True
    try:
        result = await _original_call_tool(name, arguments)
        return result
    except Exception as e:
        success = False
        return [format_tool_error(e, _key_registry)]
    finally:
        # Analytics: fire-and-forget, never blocks tool execution
        try:
            if _analytics_client is not None:
                emit_tool_event(_analytics_client, tool_name=name, success=success)
        except Exception:
            pass


mcp.call_tool = _instrumented_call_tool


def main():
    """CLI entry point for okareo-mcp."""
    transport = os.environ.get("TRANSPORT", "stdio")

    if transport == "sse":
        from src.sse_middleware import SSEKeyMiddleware

        app = mcp.sse_app()
        app = SSEKeyMiddleware(app)
        import uvicorn

        host = os.environ.get("FASTMCP_HOST", "127.0.0.1")
        port = int(os.environ.get("FASTMCP_PORT", "8000"))
        uvicorn.run(app, host=host, port=port)
    else:
        mcp.run(transport=transport)


if __name__ == "__main__":
    main()
