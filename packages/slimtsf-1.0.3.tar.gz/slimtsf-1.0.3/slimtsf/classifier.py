"""
slimtsf.classifier
~~~~~~~~~~~~~~~~~~
SlimTSFClassifier — a full Stage 1 + Stage 2 + Stage 3 pipeline
(SlidingWindowIntervalTransformer → IntervalStatsPoolingTransformer → RandomForestClassifier).
"""

from __future__ import annotations

import collections
import math
from typing import Optional, Sequence, Union

import numpy as np
from sklearn.ensemble import RandomForestClassifier

from slimtsf.transformers.sliding_intervals import FeatureFunction, SlidingWindowIntervalTransformer
from slimtsf.transformers.interval_stats_pooling import IntervalStatsPoolingTransformer


class SlimTSFClassifier:
    """
    Sliding-Window Multivariate Time-Series Forest Classifier.

    Bundles all three pipeline stages into a single sklearn-compatible estimator,
    with an optional Stage 4 for bootstrap feature selection.

        Stage 1 – ``SlidingWindowIntervalTransformer``
            Extracts sliding-window features (mean, std, slope by default)
            from a 3-D time-series array.

        Stage 2 – ``IntervalStatsPoolingTransformer``
            Pools the per-window features into global min / mean / max
            statistics per (channel, feature) group.

        Stage 3 – Bootstrap Feature Selection (Optional)
            Runs multiple Random Forest fits to identify and select only the
            most important and stable summary features.

        Stage 4 – ``RandomForestClassifier`` (scikit-learn)
            Classifies the final selected feature matrix.

    Parameters
    ----------
    # --- Stage 1 ---
    window_sizes : sequence of int or None, default None
        Window sizes for the sliding-window step.  If ``None``, sizes are
        derived automatically as ``[T, T//2, T//4, …]`` down to 2, where
        ``T`` is the number of time points.
    window_step_ratio : float, default 0.5
        Step size as a fraction of the window size (0 < ratio <= 1).
        0.5 → 50 % overlap between consecutive windows.
    feature_functions : sequence of str or FeatureFunction, default ("mean", "std", "slope")
        Features computed for each window.  Built-in strings: ``"mean"``,
        ``"std"``, ``"slope"``.  Pass a ``FeatureFunction`` for custom logic.

    # --- Stage 2 ---
    aggregations : sequence of str, default ("min", "mean", "max")
        Statistics to pool across the window dimension for each
        (channel, feature) group.  Supported: ``"min"``, ``"mean"``, ``"max"``.

    # --- Stage 3 (Bootstrap Selection) ---
    bootstrap : bool, default False
        Whether to perform bootstrap feature selection before final training.
    bootstrap_run : int, default 10
        Number of bootstrap iterations to run for feature ranking.
    top_rank : int, default 5
        Number of top features to select per bootstrap iteration for ranking.

    # --- Stage 4 (Random Forest) ---
    n_estimators : int, default 200
        Number of trees in the random forest.
    max_depth : int or None, default None
        Maximum tree depth.  ``None`` means trees grow until all leaves are
        pure or contain fewer than ``min_samples_split`` samples.
    class_weight : str, dict or None, default "balanced"
        Weights associated with classes.  ``"balanced"`` adjusts weights
        inversely to class frequency — useful for imbalanced data.
    random_state : int or None, default None
        Seed for reproducibility.
    n_jobs : int, default 1
        Number of parallel jobs for the random forest (``-1`` = all CPUs).

    # --- Parallelism (Stage 1) ---
    number_of_jobs : int, default 1
        Number of parallel workers for interval computation in Stage 1.
    parallel_backend : str or None, default None
        Joblib backend for Stage 1 (e.g. ``"loky"``, ``"threading"``).

    Attributes
    ----------
    stage1_ : SlidingWindowIntervalTransformer
        Fitted Stage 1 transformer.
    stage2_ : IntervalStatsPoolingTransformer
        Fitted Stage 2 transformer.
    stage3_ : RandomForestClassifier
        Fitted Stage 4 random forest.
    feature_indices_ : np.ndarray or None
        Indices of the selected features if ``bootstrap=True``; otherwise ``None``.
    classes_ : np.ndarray
        Unique class labels seen during ``fit``.
    n_features_in_ : int
        Number of features fed into the final random forest.

    Examples
    --------
    >>> import numpy as np
    >>> from slimtsf import SlimTSFClassifier
    >>> rng = np.random.default_rng(0)
    >>> X = rng.standard_normal((30, 2, 50))   # 30 cases, 2 channels, 50 time points
    >>> y = np.array([0] * 15 + [1] * 15)
    >>> clf = SlimTSFClassifier(bootstrap=True, n_estimators=50, random_state=0)
    >>> clf.fit(X, y)
    SlimTSFClassifier(bootstrap=True, n_estimators=50, random_state=0)
    >>> preds = clf.predict(X)
    >>> preds.shape
    (30,)
    """

    def __init__(
        self,
        # Stage 1
        window_sizes: Optional[Sequence[int]] = None,
        window_step_ratio: float = 0.5,
        feature_functions: Optional[Sequence[Union[str, FeatureFunction]]] = (
            "mean", "std", "slope"
        ),
        # Stage 2
        aggregations: Sequence[str] = ("min", "mean", "max"),
        # Stage 3 (Bootstrap)
        bootstrap: bool = False,
        bootstrap_run: int = 10,
        top_rank: int = 5,
        # Stage 4
        n_estimators: int = 200,
        max_depth: Optional[int] = None,
        class_weight: Optional[Union[str, dict]] = "balanced",
        random_state: Optional[int] = None,
        n_jobs: int = 1,
        # Stage 1 parallelism
        number_of_jobs: int = 1,
        parallel_backend: Optional[str] = None,
    ) -> None:
        self.window_sizes = window_sizes
        self.window_step_ratio = window_step_ratio
        self.feature_functions = feature_functions
        self.aggregations = aggregations
        self.bootstrap = bootstrap
        self.bootstrap_run = bootstrap_run
        self.top_rank = top_rank
        self.n_estimators = n_estimators
        self.max_depth = max_depth
        self.class_weight = class_weight
        self.random_state = random_state
        self.n_jobs = n_jobs
        self.number_of_jobs = number_of_jobs
        self.parallel_backend = parallel_backend

        # Fitted state — set by fit()
        self.stage1_: Optional[SlidingWindowIntervalTransformer] = None
        self.stage2_: Optional[IntervalStatsPoolingTransformer] = None
        self.stage3_: Optional[RandomForestClassifier] = None
        self.feature_indices_: Optional[np.ndarray] = None
        self.classes_: Optional[np.ndarray] = None
        self.n_features_in_: Optional[int] = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def fit(self, X: np.ndarray, y: np.ndarray) -> "SlimTSFClassifier":
        """
        Fit the full pipeline on training data.

        Parameters
        ----------
        X : np.ndarray, shape (n_cases, n_channels, n_timepoints)
            Multivariate time-series training data.
        y : np.ndarray, shape (n_cases,)
            Class labels.

        Returns
        -------
        self
        """
        self._validate_X(X)
        y = np.asarray(y)
        self.classes_ = np.unique(y)

        # Stage 1 — sliding-window feature extraction
        self.stage1_ = SlidingWindowIntervalTransformer(
            window_sizes=self.window_sizes,
            window_step_ratio=self.window_step_ratio,
            feature_functions=self.feature_functions,
            number_of_jobs=self.number_of_jobs,
            parallel_backend=self.parallel_backend,
        )
        interval_features = self.stage1_.fit_transform(X)

        # Stage 2 — stats pooling
        self.stage2_ = IntervalStatsPoolingTransformer(aggregations=self.aggregations)
        pooled_features = self.stage2_.fit_transform(
            interval_features,
            feature_metadata=self.stage1_.feature_metadata_,
        )

        # Stage 3 — Bootstrap Selection (Optional)
        if self.bootstrap:
            selected_features = self._fit_bootstrap(pooled_features, y)
        else:
            selected_features = pooled_features
            self.feature_indices_ = None

        self.n_features_in_ = selected_features.shape[1]

        # Stage 4 — final random forest
        self.stage3_ = RandomForestClassifier(
            n_estimators=self.n_estimators,
            max_depth=self.max_depth,
            class_weight=self.class_weight,
            random_state=self.random_state,
            n_jobs=self.n_jobs,
        )
        self.stage3_.fit(selected_features, y)

        return self

    def predict(self, X: np.ndarray) -> np.ndarray:
        """
        Predict class labels for input time-series.

        Parameters
        ----------
        X : np.ndarray, shape (n_cases, n_channels, n_timepoints)

        Returns
        -------
        y_pred : np.ndarray, shape (n_cases,)
        """
        self._check_is_fitted()
        return self.stage3_.predict(self._transform(X))

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        """
        Predict class probabilities for input time-series.

        Parameters
        ----------
        X : np.ndarray, shape (n_cases, n_channels, n_timepoints)

        Returns
        -------
        proba : np.ndarray, shape (n_cases, n_classes)
        """
        self._check_is_fitted()
        return self.stage3_.predict_proba(self._transform(X))

    def get_feature_names_out(self) -> list[str]:
        """
        Return human-readable column names for the features fed into the final RF.

        Returns
        -------
        list of str
            One name per selected feature column.

        Raises
        ------
        RuntimeError
            If called before ``fit()``.
        """
        self._check_is_fitted()
        names = np.array(self.stage2_.get_feature_names_out())
        if self.feature_indices_ is not None:
            names = names[self.feature_indices_]
        return names.tolist()

    def __repr__(self) -> str:
        params = (
            f"bootstrap={self.bootstrap!r}, "
            f"n_estimators={self.n_estimators!r}, "
            f"random_state={self.random_state!r}"
        )
        return f"SlimTSFClassifier({params})"

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _fit_bootstrap(self, pooled_features: np.ndarray, y: np.ndarray) -> np.ndarray:
        """
        Identify top stable features by running multiple RF passes.
        Directly refactored from v0's _fit_bootstrap.
        """
        n_features = pooled_features.shape[1]
        top_features_all_runs = []

        # Multi-pass ranking
        for i in range(self.bootstrap_run):
            # Use same RF config as final model (except possibly n_estimators if v0 optimized it)
            # v0 uses a fresh RF each time
            clf = RandomForestClassifier(
                n_estimators=self.n_estimators,
                max_depth=self.max_depth,
                class_weight=self.class_weight,
                random_state=self.random_state if self.random_state is None else self.random_state + i,
                n_jobs=self.n_jobs,
            )
            clf.fit(pooled_features, y)
            
            # Sort importances desc
            importances = clf.feature_importances_
            sorted_idx = np.argsort(importances)[::-1]
            
            # Record top-k
            top_features_all_runs.extend(sorted_idx[:self.top_rank])

        # Frequency count across passes
        counts = collections.Counter(top_features_all_runs)
        
        # Rule of thumb from v0: select Top log2(N) features
        n_to_select = math.ceil(math.log2(n_features)) if n_features > 0 else 0
        
        selected = [idx for idx, _count in counts.most_common(n_to_select)]
        
        # Sort indices to keep feature order predictable
        self.feature_indices_ = np.sort(np.array(selected, dtype=int))
        
        return pooled_features[:, self.feature_indices_]

    def _transform(self, X: np.ndarray) -> np.ndarray:
        """Apply fitted Stage 1 + Stage 2 (+ Stage 4 selection) to new data."""
        self._check_is_fitted()
        self._validate_X(X)
        interval_features = self.stage1_.transform(X)
        pooled_features = self.stage2_.transform(interval_features)
        
        if self.feature_indices_ is not None:
            return pooled_features[:, self.feature_indices_]
        return pooled_features

    def _check_is_fitted(self) -> None:
        if self.stage1_ is None or self.stage2_ is None or self.stage3_ is None:
            raise RuntimeError(
                "This SlimTSFClassifier instance is not fitted yet. "
                "Call 'fit' before using this estimator."
            )

    @staticmethod
    def _validate_X(X: np.ndarray) -> None:
        if not isinstance(X, np.ndarray):
            raise TypeError("X must be a numpy.ndarray.")
        if X.ndim != 3:
            raise ValueError(
                "X must be 3-D with shape (n_cases, n_channels, n_timepoints). "
                f"Got shape {X.shape}."
            )
