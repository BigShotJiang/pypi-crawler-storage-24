"""Audit and reporting helpers. """

