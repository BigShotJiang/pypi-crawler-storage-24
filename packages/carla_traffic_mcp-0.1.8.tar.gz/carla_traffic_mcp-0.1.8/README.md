# CARLA Traffic Scenario MCP Server

用于阿里云百炼平台的 MCP 服务，生成 CARLA 交通仿真场景配置脚本。

[![PyPI version](https://badge.fury.io/py/carla-traffic-mcp.svg)](https://badge.fury.io/py/carla-traffic-mcp)
[![Python](https://img.shields.io/pypi/pyversions/carla-traffic-mcp.svg)](https://pypi.org/project/carla-traffic-mcp/)

## 功能

- 生成道路/路口类型配置
- 生成交通流配置
- 生成信号灯控制配置
- 生成车辆行为配置
- 生成行人配置
- 生成天气配置
- 生成完整的 CARLA 交通场景 Python 脚本

## 安装

### 从 PyPI 安装（推荐）

```bash
pip install carla-traffic-mcp
```

### 使用 uvx 运行

```bash
uvx -y carla-traffic-mcp
```

## 使用

在百炼平台配置 MCP 服务时使用以下 JSON：

```json
{
  "mcpServers": {
    "carla-traffic-mcp": {
      "type": "stdio",
      "command": "uvx",
      "args": [
        "-y",
        "carla-traffic-mcp"
      ]
    }
  }
}
```

## 运行模式

### 百炼脚本部署

默认使用 `stdio` 传输，无需额外环境变量。

### 远程 HTTP MCP 部署

如果百炼脚本部署持续出现 `No active SSE connection`，可改为独立部署远程 MCP 服务：

```bash
MCP_TRANSPORT=streamable-http HOST=0.0.0.0 PORT=8000 carla-traffic-mcp
```

然后在平台侧通过远程 MCP 方式接入 HTTP 端点。

## MCP 工具列表

| 工具名称 | 功能描述 |
|---------|---------|
| `generate_road_junction` | 生成道路/路口类型配置 |
| `generate_traffic_flow` | 生成交通流配置 |
| `generate_signal_control` | 生成信号灯控制配置 |
| `generate_vehicle_behavior` | 生成车辆行为配置 |
| `generate_pedestrian` | 生成行人配置 |
| `generate_weather` | 生成天气配置 |
| `generate_full_scenario` | 生成完整的 CARLA 交通场景 Python 脚本 |

## 支持的场景类型

| 场景 | 地图 | 说明 |
|-----|------|------|
| 十字路口 | Town03 | 标准城市十字路口 |
| T字路口 | Town02 | T型交叉口 |
| 环岛 | Town03 | 圆形环岛 |
| 五岔路口 | Town04 | 复杂五岔路口 |
| 高速公路 | Town05 | 高速公路场景 |

## 开发

### 本地开发

```bash
# 克隆仓库
git clone https://github.com/your-username/carla-traffic-mcp.git
cd carla-traffic-mcp

# 安装开发依赖
pip install -e ".[dev]"

# 运行测试
pytest
```

### 发布到 PyPI

参考 [PyPI发布指南.md](../PyPI发布指南.md)

## 许可证

MIT

## 作者

- **NextLearn** - [chenlx2023@gmail.com](mailto:chenlx2023@gmail.com)

## 版本历史

| 版本 | 日期 | 说明 |
|-----|------|------|
| 0.1.8 | 2026-03-15 | 显式声明 stdio 配置并切换为 FastMCP 入口 |
| 0.1.6 | 2026-03-15 | 修复入口点和 Tool 类型问题 |
| 0.1.0 | 2026-03-15 | 初始发布 |
