#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
CARLA Traffic Scenario MCP Server.

默认以 stdio 方式运行，兼容百炼脚本部署。
如需远程部署，可设置 `MCP_TRANSPORT=streamable-http` 启动 HTTP MCP 端点。
"""

from __future__ import annotations

import os
from typing import Literal

from mcp.server.fastmcp import FastMCP

from .tools import (
    generate_full_scenario as build_full_scenario,
    generate_pedestrian as build_pedestrian,
    generate_road_junction as build_road_junction,
    generate_signal_control as build_signal_control,
    generate_traffic_flow as build_traffic_flow,
    generate_vehicle_behavior as build_vehicle_behavior,
    generate_weather as build_weather,
)


mcp = FastMCP(
    "carla-traffic-mcp",
    instructions="将自然语言参数转换为 CARLA 交通仿真场景脚本。",
)


@mcp.tool()
def generate_road_junction(
    junction_type: Literal["cross", "T", "roundabout", "five_way", "highway"],
) -> str:
    """生成道路/路口类型配置。"""
    return build_road_junction(junction_type)


@mcp.tool()
def generate_traffic_flow(
    density: Literal["low", "normal", "high", "peak"],
    vehicle_count: int | None = None,
) -> str:
    """生成交通流配置。"""
    return build_traffic_flow(density, vehicle_count)


@mcp.tool()
def generate_signal_control(
    cycle: int,
    green_time: int = 30,
    red_time: int = 25,
    yellow_time: int = 5,
) -> str:
    """生成信号灯控制配置。"""
    return build_signal_control(cycle, green_time, red_time, yellow_time)


@mcp.tool()
def generate_vehicle_behavior(
    avg_speed: float,
    lane_change_freq: Literal["low", "normal", "high"] = "normal",
    aggressive_level: Literal["cautious", "normal", "aggressive"] = "normal",
) -> str:
    """生成车辆行为配置。"""
    return build_vehicle_behavior(avg_speed, lane_change_freq, aggressive_level)


@mcp.tool()
def generate_pedestrian(
    count: int,
    crossing_freq: Literal["low", "normal", "high"] = "normal",
) -> str:
    """生成行人配置。"""
    return build_pedestrian(count, crossing_freq)


@mcp.tool()
def generate_weather(
    weather_type: Literal["clear", "cloudy", "rain", "fog", "night"],
) -> str:
    """生成天气配置。"""
    return build_weather(weather_type)


@mcp.tool()
def generate_full_scenario(
    scenario_name: str,
    junction_type: Literal["cross", "T", "roundabout", "five_way", "highway"] = "cross",
    traffic_density: Literal["low", "normal", "high", "peak"] = "normal",
    signal_cycle: int = 60,
    pedestrian_count: int = 20,
    weather_type: Literal["clear", "cloudy", "rain", "fog", "night"] = "clear",
) -> str:
    """生成完整的 CARLA 交通场景 Python 脚本。"""
    return build_full_scenario(
        scenario_name=scenario_name,
        junction_type=junction_type,
        traffic_density=traffic_density,
        signal_cycle=signal_cycle,
        pedestrian_count=pedestrian_count,
        weather_type=weather_type,
    )


def _configure_streamable_http() -> None:
    """为远程 MCP 部署设置 HTTP 参数。"""
    mcp.settings.host = os.getenv("HOST", "0.0.0.0")
    mcp.settings.port = int(os.getenv("PORT", "8000"))
    mcp.settings.streamable_http_path = os.getenv("MCP_HTTP_PATH", "/mcp")


def main() -> None:
    """同步入口点。"""
    transport = os.getenv("MCP_TRANSPORT", "stdio").strip().lower()
    if transport == "streamable-http":
        _configure_streamable_http()
        mcp.run(transport="streamable-http")
        return

    mcp.run()


if __name__ == "__main__":
    main()
