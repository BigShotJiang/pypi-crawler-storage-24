import xml.etree.ElementTree as ET
from pathlib import Path
from time import time
from typing import Dict, Sequence, Tuple
from urllib.parse import quote, urlencode

import requests
from flask import Flask

from . import utils
from .authV4 import add_auth_header as add_auth_header_v4
from .ks3_auth import add_auth_header as add_auth_header_v3
from .ks3_auth import canonical_string as canonical_string_v3
from .ks3_auth import encode as encode_v3
from .progress import ProgressFile
from .types import CompletedPart


class FlaskKS3:
    def __init__(self, app=None):
        if app is not None:
            self.init_app(app)

    def init_app(self, app: Flask):
        self.access_key = app.config["KS3_ACCESS_KEY"]
        self.secret = app.config["KS3_SECRET"]
        self.endpoint = app.config["KS3_ENDPOINT"]
        self.bucket_name = app.config["KS3_BUCKET"]

        self.client = KS3Client(
            access_key=self.access_key,
            secret=self.secret,
            bucket_name=self.bucket_name,
            endpoint=self.endpoint,
        )

    def put_object(self, object_key: str, local_path: Path) -> requests.Response:
        return self.client.put_object(object_key, local_path)

    def get_object(self, object_key: str) -> requests.Response:
        return self.client.get_object(object_key)

    def head_object(self, object_key: str) -> requests.Response:
        return self.client.head_object(object_key)

    def initiate_multipart_upload(self, object_key: str) -> str:
        return self.client.initiate_multipart_upload(object_key)

    def abort_multipart_upload(self, object_key: str, upload_id: str) -> str:
        return self.client.abort_multipart_upload(object_key, upload_id)

    def list_multipart_uploads(self) -> str:
        return self.client.list_multipart_uploads()

    def list_parts(self, object_key: str, upload_id: str) -> str:
        return self.client.list_parts(object_key, upload_id)

    def upload_part(
        self, object_key: str, upload_id: str, part_number: int, filepath: str | Path
    ) -> str:
        return self.client.upload_part(object_key, upload_id, part_number, filepath)

    def complete_multipart_upload(
        self, object_key: str, upload_id: str, parts: Sequence[CompletedPart]
    ) -> requests.Response:
        return self.client.complete_multipart_upload(object_key, upload_id, parts)

    def list_objects(
        self,
        prefix: str = None,
        marker: str = None,
        max_keys: int = None,
        delimiter: str = None,
    ) -> requests.Response:
        return self.client.list_objects(prefix, marker, max_keys, delimiter)

    def generate_share_url(
        self,
        object_key: str,
        expires_in: int = 3600,
        response_headers: Dict[str, str] | None = None,
    ) -> str:
        return self.client.generate_share_url(
            object_key,
            expires_in=expires_in,
            response_headers=response_headers,
        )


class KS3Client:
    def __init__(
        self,
        access_key: str,
        secret: str,
        bucket_name: str,
        endpoint: str,
    ):
        self.access_key = access_key
        self.secret = secret
        self.bucket_name = bucket_name
        self.endpoint = endpoint
        self._base_url = f"https://{self.bucket_name}.{self.endpoint}"

    def get_url_and_headers(
        self,
        method: str,
        object_key: str,
        query: str = "",
        headers: Dict[str, str] | None = None,
    ) -> Tuple[str, Dict[str, str]]:
        if not all([self.access_key, self.secret, self.endpoint, self.bucket_name]):
            raise RuntimeError("FlaskKS3 is not initialized; call init_app first")

        headers = dict(headers) if headers else {}
        add_auth_header_v3(
            self.access_key,
            self.secret,
            headers,
            method,
            self.bucket_name,
            object_key,
            query,
        )
        # add_auth_header_v4(self.access_key, self.secret, "BEIJING", "ks3", f'{self.bucket_name}.{self.endpoint}', method, query, "", headers)
        quoted_key = quote(object_key, safe="/")
        url = f"{self._base_url}/{quoted_key}"
        if query:
            url = f"{url}?{query}"
        return url, headers

    def generate_share_url(
        self,
        object_key: str,
        expires_in: int = 3600,
        response_headers: Dict[str, str] | None = None,
    ) -> str:
        if not all([self.access_key, self.secret, self.endpoint, self.bucket_name]):
            raise RuntimeError("FlaskKS3 is not initialized; call init_app first")
        if expires_in <= 0:
            raise ValueError("expires_in 必须大于 0")
        normalized_key = object_key.lstrip("/")
        if not normalized_key:
            raise ValueError("object_key 不能为空")

        expires = int(time()) + expires_in
        query_args = {
            "KSSAccessKeyId": self.access_key,
            "Expires": str(expires),
        }
        if response_headers:
            query_args.update(
                {
                    key: value
                    for key, value in response_headers.items()
                    if value is not None
                }
            )

        canonical_query = urlencode(query_args)
        signature = encode_v3(
            self.secret,
            canonical_string_v3(
                "GET",
                self.bucket_name,
                normalized_key,
                canonical_query,
                headers={},
                expires=expires,
            ),
        )
        query_args["Signature"] = signature

        quoted_key = quote(normalized_key, safe="/")
        return f"{self._base_url}/{quoted_key}?{urlencode(query_args)}"

    def put_object(self, object_key: str, local_path: Path) -> requests.Response:
        url, headers = self.get_url_and_headers("PUT", object_key)
        with ProgressFile(local_path) as pf:
            response = requests.put(url, headers=headers, data=pf, timeout=(30, 1800))
        if response.status_code == 200:
            print("普通上传成功")
        else:
            print(f"上传失败: {response.status_code}, {response.text}")
        return response

    def get_object(self, object_key: str) -> requests.Response:
        url, headers = self.get_url_and_headers("GET", object_key)
        response = requests.request("GET", url, headers=headers, timeout=(30, 1800))
        if response.status_code == 200:
            print(f"xyyebesr 文件已存在 {object_key}")
        elif response.status_code == 404:
            print(f"b1s6sstz 文件不存在 {object_key}")
        else:
            print(
                f"20z4ojsw 文件状态码错误 {object_key}, {response.status_code}, {response.text}"
            )
        return response

    def head_object(self, object_key: str) -> requests.Response:
        url, headers = self.get_url_and_headers("HEAD", object_key)
        response = requests.request("HEAD", url, headers=headers, timeout=(30, 1800))
        if response.status_code == 200:
            print(f"xyyebesr 文件已存在 {object_key}")
        elif response.status_code == 404:
            print(f"b1s6sstz 文件不存在 {object_key}")
        else:
            print(
                f"20z4ojsw 文件状态码错误 {object_key}, {response.status_code}, {response.text}"
            )
        return response

    # 下面的方法是分快上传相关的方法 https://docs.ksyun.com/documents/42466?type=3
    def initiate_multipart_upload(self, object_key: str) -> str:
        """获取分块上传的upload_id"""
        url, headers = self.get_url_and_headers("POST", object_key, query="uploads")
        response = requests.post(url, headers=headers)
        if response.status_code == 200:
            xml_root = ET.fromstring(response.text)
            ns = {"s3": "http://s3.amazonaws.com/doc/2006-03-01/"}
            upload_id = xml_root.findtext("s3:UploadId", namespaces=ns)
            print(f"UploadId: {upload_id}")
            if upload_id:
                return upload_id
            raise RuntimeError("未从响应中解析到 UploadId")

        raise RuntimeError(
            f"分块初始化上传失败 initiate_upload: {response.status_code}, {response.text}"
        )

    def abort_multipart_upload(self, object_key: str, upload_id: str) -> None:
        url, headers = self.get_url_and_headers(
            "DELETE", object_key, query=f"uploadId={upload_id}"
        )
        response = requests.delete(url, headers=headers)
        assert (
            response.status_code == 204
        ), f"中止分块上传失败 abort_upload: {response.status_code}, {response.text}"
        return response

    def list_multipart_uploads(self) -> requests.Response:
        url, headers = self.get_url_and_headers("GET", "", query="uploads")
        response = requests.get(url, headers=headers)
        assert (
            response.status_code == 200
        ), f"列出分块上传失败 list_uploads: {response.status_code}, {response.text}"
        return response

    def list_parts(self, object_key: str, upload_id: str) -> requests.Response:
        url, headers = self.get_url_and_headers(
            "GET", object_key, query=f"uploadId={upload_id}"
        )
        response = requests.get(url, headers=headers)
        assert (
            response.status_code == 200
        ), f"列出分块失败 list_parts: {response.status_code}, {response.text}"
        return response

    def upload_part(
        self,
        object_key: str,
        upload_id: str,
        part_number: int,
        filepath: str | Path,
        filesize: int = 0,
    ) -> str:
        """上传单个分片并返回 ETag。"""
        query = f"partNumber={part_number}&uploadId={upload_id}"
        url, headers = self.get_url_and_headers("PUT", object_key, query=query)
        with ProgressFile(filepath) as pf:
            response = requests.put(url, headers=headers, data=pf, timeout=(30, 1800))
            print(
                f"上传分片 {part_number} , 状态码: {response.status_code}, text: {response.text}"
            )
        if response.status_code != 200:
            raise RuntimeError(
                f"分片 {part_number} 上传失败: {response.status_code}, {response.text}"
            )

        etag = response.headers.get("ETag")
        if not etag:
            raise RuntimeError(f"分片 {part_number} 上传成功但缺少 ETag")
        clean_etag = etag.strip('"')
        print(f"分片 {part_number} 上传成功，ETag: {clean_etag}")
        return clean_etag

    def complete_multipart_upload(
        self, object_key: str, upload_id: str, parts: Sequence[CompletedPart]
    ) -> requests.Response:
        xml_body = utils.generate_complete_multipart_xml(parts)
        query = f"uploadId={upload_id}"
        base_headers = {"Content-Type": "application/xml"}
        url, headers = self.get_url_and_headers(
            "POST", object_key, query=query, headers=base_headers
        )
        print(f"url: {url}, headers: {headers}")
        print(f"xml_body: {xml_body}")

        response = requests.post(url, headers=headers, data=xml_body)
        if response.status_code != 200:
            raise RuntimeError(f"合并失败: {response.status_code}, {response.text}")
        print("所有分片合并成功，上传完成！")
        return response

    def list_objects(
        self,
        prefix: str = None,
        marker: str = None,
        max_keys: int = None,
        delimiter: str = None,
    ) -> requests.Response:
        query = {}
        if prefix:
            query["prefix"] = prefix
        if marker:
            query["marker"] = marker
        if max_keys is not None:
            query["max-keys"] = str(max_keys)
        if delimiter:
            query["delimiter"] = delimiter
        query_str = urlencode(query)
        url, headers = self.get_url_and_headers("GET", "", query=query_str)
        response = requests.get(url, headers=headers)
        print(response.text)
        if response.status_code != 200:
            raise RuntimeError(f"列出对象失败: {response.status_code}, {response.text}")
        return response
