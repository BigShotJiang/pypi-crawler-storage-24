import quizcomp.common
import quizcomp.constants
import quizcomp.question.base

class TextOnly(quizcomp.question.base.Question, question_type = quizcomp.constants.QUESTION_TYPE_TEXT_ONLY):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def _validate_answers(self):
        if (self.answers is None):
            return

        if (isinstance(self.answers, (tuple, list, dict)) and (len(self.answers) == 0)):
            self.answers = None
            return

        raise quizcomp.common.QuestionValidationError(self, f"'answers' key must be missing, None/null, or empty, found: '{self.answers}''.")
