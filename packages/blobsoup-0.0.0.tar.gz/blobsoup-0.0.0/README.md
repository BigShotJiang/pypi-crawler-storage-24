# About Blobsoup


[![PyPI - Version](https://img.shields.io/pypi/v/greenland-hello.svg)](https://pypi.org/project/greenland-hello)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/greenland-hello.svg)](https://pypi.org/project/greenland-hello)

-----

## Table of Contents

- [Description](#description)
- [Installation](#installation)
- [License](#license)

## Description

This project is an attempt to replace
[git-annex](https://git-annex.branchable.com/) by something simpler
but also more portable based on Python.

Incentive was, that Haskell (and thus git-annex) is not available on
the more fringe platforms (for example Cygwin and some BSD variants;
Windows installation is also a hassle; Company supplied machines might
be restricted to allow Python but not Haskell).

_blobsoup_ will therefore go with Python in the hope that it will be
portable to every platform that can support Python and easier
available in some "managed" network environments.

## Installation

```console
https://codeberg.org/m-e-leypold/blobsoup
pip install -e .
```

Currently there *are no built wheels available* at
<https://pypi.org/project/blobsoup>.

## License

`greenland-hello` is distributed under the terms of the
[GPL-3.0-or-later](https://spdx.org/licenses/GPL-3.0-or-later.html)
license ([local copy](./LICENSE.txt)).
