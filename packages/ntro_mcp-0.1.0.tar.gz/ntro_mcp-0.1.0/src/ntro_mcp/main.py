"""Entry point for the ntro MCP server."""

from __future__ import annotations

import argparse
import os


def main() -> None:
    parser = argparse.ArgumentParser(
        description="ntro MCP server — exposes the ntro Workspace API as MCP tools",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # Claude Desktop / Claude Code (stdio)
  ntro-mcp --transport stdio

  # HTTP server for claude.ai (then tunnel with cloudflared)
  ntro-mcp --transport http --port 8000

  # Explicit API target (overrides config file)
  ntro-mcp --transport stdio --ntro-host http://localhost:3000/v1

  # Use a named connection from ~/.ntro/config.toml
  ntro-mcp --transport stdio --connection local
""",
    )
    parser.add_argument(
        "--transport",
        choices=["http", "stdio"],
        default="stdio",
        help="Transport type: stdio (Claude Desktop/Code) or http (claude.ai). Default: stdio",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8000,
        help="HTTP port (default: 8000, only used with --transport http)",
    )
    parser.add_argument(
        "--host",
        default="127.0.0.1",
        help="HTTP bind host (default: 127.0.0.1, only used with --transport http)",
    )
    parser.add_argument(
        "--connection",
        "-c",
        default=None,
        help="Connection name from ~/.ntro/config.toml (e.g. local, staging, production)",
    )
    parser.add_argument(
        "--ntro-host",
        default=None,
        help="Workspace API URL, overrides config (e.g. http://localhost:3000/v1)",
    )
    parser.add_argument(
        "--ntro-api-key",
        default=None,
        help="API key, overrides config",
    )

    args = parser.parse_args()

    # Env vars take effect before the SDK reads them in Client.from_config()
    if args.ntro_host:
        os.environ["NTRO_HOST"] = args.ntro_host
    if args.ntro_api_key:
        os.environ["NTRO_API_KEY"] = args.ntro_api_key

    from ntro_mcp.server import create_server

    mcp = create_server(connection=args.connection)

    if args.transport == "http":
        mcp.run(transport="streamable-http", host=args.host, port=args.port)
    else:
        mcp.run(transport="stdio")
