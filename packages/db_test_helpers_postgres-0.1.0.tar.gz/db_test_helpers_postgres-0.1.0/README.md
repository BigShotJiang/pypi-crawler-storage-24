# db-test-helpers-postgres

PostgreSQL adapter for [db-test-helpers](https://github.com/takaaa220/db-test-helpers).

## Installation

```bash
pip install db-test-helpers-postgres
```

## Documentation

See the [main repository](https://github.com/takaaa220/db-test-helpers) for usage and documentation.
