"""db-test-helpers-postgres: PostgreSQL adapter for db-test-helpers."""

from db_test_helpers.postgres._adapter import PostgresAdapter

__all__ = ["PostgresAdapter"]
