"""Tests for PostgresAdapter."""

from __future__ import annotations

import psycopg
import pytest

from db_test_helpers.core._errors import UnsupportedError
from db_test_helpers.postgres._adapter import PostgresAdapter


def _create_table(conn: psycopg.Connection, ddl: str) -> None:
    conn.execute(ddl)


def _insert(conn: psycopg.Connection, table: str, data: dict) -> None:
    columns = list(data.keys())
    values = list(data.values())
    query = psycopg.sql.SQL("INSERT INTO {} ({}) VALUES ({})").format(
        psycopg.sql.Identifier(table),
        psycopg.sql.SQL(", ").join(psycopg.sql.Identifier(c) for c in columns),
        psycopg.sql.SQL(", ").join(psycopg.sql.Placeholder() * len(values)),
    )
    conn.execute(query, values)


class TestDocumentIdGuard:
    def test_rejects_document_id(self):
        from unittest.mock import MagicMock

        adapter = PostgresAdapter(MagicMock())
        with pytest.raises(UnsupportedError, match="PostgresAdapter does not support __document_id__"):
            adapter.write_record("t", "", {"__document_id__": "abc", "name": "Alice"})


class TestParentPathGuard:
    def test_clear_group_rejects_non_empty_parent_path(self):
        from unittest.mock import MagicMock

        adapter = PostgresAdapter(MagicMock())
        with pytest.raises(UnsupportedError, match="does not support parent_path"):
            adapter.clear_group("t", "some/path")

    def test_write_record_rejects_non_empty_parent_path(self):
        from unittest.mock import MagicMock

        adapter = PostgresAdapter(MagicMock())
        with pytest.raises(UnsupportedError, match="does not support parent_path"):
            adapter.write_record("t", "some/path", {"x": 1})

    def test_read_records_rejects_non_empty_parent_path(self):
        from unittest.mock import MagicMock

        adapter = PostgresAdapter(MagicMock())
        with pytest.raises(UnsupportedError, match="does not support parent_path"):
            adapter.read_records("t", "some/path")


class TestClearGroup:
    def test_clear_deletes_all_rows(self, conn):
        _create_table(conn, "CREATE TABLE users (id SERIAL PRIMARY KEY, name TEXT)")
        _insert(conn, "users", {"name": "Alice"})
        _insert(conn, "users", {"name": "Bob"})

        adapter = PostgresAdapter(conn)
        adapter.clear_group("users", "")

        rows = conn.execute("SELECT * FROM users").fetchall()
        assert rows == []

    def test_clear_empty_table(self, conn):
        _create_table(conn, "CREATE TABLE users (id SERIAL PRIMARY KEY, name TEXT)")

        adapter = PostgresAdapter(conn)
        adapter.clear_group("users", "")

        rows = conn.execute("SELECT * FROM users").fetchall()
        assert rows == []


class TestWriteRecord:
    def test_write_inserts_row(self, conn):
        _create_table(conn, "CREATE TABLE users (name TEXT, age INTEGER)")

        adapter = PostgresAdapter(conn)
        result = adapter.write_record("users", "", {"name": "Alice", "age": 30})

        assert result["name"] == "Alice"
        assert result["age"] == 30

    def test_write_returns_db_defaults(self, conn):
        _create_table(conn, "CREATE TABLE users (id SERIAL PRIMARY KEY, name TEXT)")

        adapter = PostgresAdapter(conn)
        result = adapter.write_record("users", "", {"name": "Alice"})

        assert result["id"] is not None
        assert result["name"] == "Alice"

    def test_write_empty_data_uses_default_values(self, conn):
        _create_table(conn, "CREATE TABLE users (id SERIAL PRIMARY KEY, name TEXT DEFAULT 'anonymous')")

        adapter = PostgresAdapter(conn)
        result = adapter.write_record("users", "", {})

        assert result["id"] is not None
        assert result["name"] == "anonymous"


class TestReadRecords:
    def test_read_empty_table(self, conn):
        _create_table(conn, "CREATE TABLE users (id SERIAL PRIMARY KEY, name TEXT)")

        adapter = PostgresAdapter(conn)
        result = adapter.read_records("users", "")

        assert result == []

    def test_read_multiple_records(self, conn):
        _create_table(conn, "CREATE TABLE users (name TEXT, age INTEGER)")
        _insert(conn, "users", {"name": "Alice", "age": 30})
        _insert(conn, "users", {"name": "Bob", "age": 25})

        adapter = PostgresAdapter(conn)
        result = adapter.read_records("users", "")

        assert len(result) == 2
        names = {r["name"] for r in result}
        assert names == {"Alice", "Bob"}
