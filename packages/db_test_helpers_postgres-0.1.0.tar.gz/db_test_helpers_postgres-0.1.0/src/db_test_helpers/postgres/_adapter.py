"""PostgreSQL adapter for db-test-helpers."""

from __future__ import annotations

from typing import Any

import psycopg
from psycopg import sql
from psycopg.rows import dict_row

from db_test_helpers.core._errors import UnsupportedError


def _check_parent_path(parent_path: str) -> None:
    if parent_path:
        raise UnsupportedError("PostgresAdapter does not support parent_path")


class PostgresAdapter:
    """DatabaseAdapter for PostgreSQL via psycopg.

    Args:
        conn: An open ``psycopg.Connection``.
    """

    def __init__(self, conn: psycopg.Connection) -> None:
        self._conn = conn

    def clear_group(self, group: str, parent_path: str) -> None:
        _check_parent_path(parent_path)
        self._conn.execute(sql.SQL("DELETE FROM {}").format(sql.Identifier(group)))

    def write_record(self, group: str, parent_path: str, data: dict[str, Any]) -> dict[str, Any]:
        _check_parent_path(parent_path)
        if "__document_id__" in data:
            raise UnsupportedError("PostgresAdapter does not support __document_id__")
        with self._conn.cursor(row_factory=dict_row) as cur:
            if not data:
                cur.execute(sql.SQL("INSERT INTO {} DEFAULT VALUES RETURNING *").format(sql.Identifier(group)))
            else:
                columns = list(data.keys())
                values = list(data.values())
                query = sql.SQL("INSERT INTO {} ({}) VALUES ({}) RETURNING *").format(
                    sql.Identifier(group),
                    sql.SQL(", ").join(sql.Identifier(c) for c in columns),
                    sql.SQL(", ").join(sql.Placeholder() * len(values)),
                )
                cur.execute(query, values)
            row = cur.fetchone()
            assert row is not None
            return row

    def read_records(self, group: str, parent_path: str) -> list[dict[str, Any]]:
        _check_parent_path(parent_path)
        with self._conn.cursor(row_factory=dict_row) as cur:
            cur.execute(sql.SQL("SELECT * FROM {}").format(sql.Identifier(group)))
            return cur.fetchall()
