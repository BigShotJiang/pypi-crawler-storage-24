"""E2E tests: set_db_data + verify_db_data with PostgreSQL."""

from __future__ import annotations

import pytest

from db_test_helpers.core import Config, UnsupportedError, set_db_data, verify_db_data
from db_test_helpers.postgres import PostgresAdapter


@pytest.fixture
def _users_table(conn):
    conn.execute("CREATE TABLE users (name TEXT, age INTEGER, active BOOLEAN)")
    yield
    conn.execute("DROP TABLE IF EXISTS users")


class TestE2eBasic:
    @pytest.mark.usefixtures("_users_table")
    def test_set_and_verify_order_independent(self, conn, tmp_path):
        seed = tmp_path / "seed.yaml"
        seed.write_text(
            """\
users:
  - name: "Alice"
    age: 30
    active: true
  - name: "Bob"
    age: 25
    active: false
"""
        )
        expected = tmp_path / "expected.yaml"
        expected.write_text(
            """\
users:
  - name: "Bob"
    age: 25
    active: false
  - name: "Alice"
    age: 30
    active: true
"""
        )
        adapter = PostgresAdapter(conn)
        set_db_data(adapter, str(seed))
        verify_db_data(adapter, str(expected))

    @pytest.mark.usefixtures("_users_table")
    def test_set_replaces_existing(self, conn, tmp_path):
        conn.execute("INSERT INTO users (name, age, active) VALUES ('OldUser', 99, true)")

        seed = tmp_path / "seed.yaml"
        seed.write_text(
            """\
users:
  - name: "Alice"
    age: 30
    active: true
"""
        )
        adapter = PostgresAdapter(conn)
        set_db_data(adapter, str(seed))

        rows = conn.execute("SELECT * FROM users").fetchall()
        assert len(rows) == 1


class TestE2eChildren:
    @pytest.mark.usefixtures("_users_table")
    def test_children_raises_not_implemented(self, conn, tmp_path):
        seed = tmp_path / "seed.yaml"
        seed.write_text(
            """\
users:
  - name: "Alice"
    age: 30
    active: true
    __children__:
      posts:
        - title: "Hello"
"""
        )
        adapter = PostgresAdapter(conn)
        with pytest.raises(UnsupportedError, match="does not support __children__"):
            set_db_data(adapter, str(seed))


class TestE2eDsl:
    @pytest.mark.usefixtures("_users_table")
    def test_var_and_any(self, conn, tmp_path):
        seed = tmp_path / "seed.yaml"
        seed.write_text(
            """\
users:
  - name: "$var(user_name)"
    age: 30
    active: true
"""
        )
        expected = tmp_path / "expected.yaml"
        expected.write_text(
            """\
users:
  - name: "$var(user_name)"
    age: "$any()"
    active: true
"""
        )
        adapter = PostgresAdapter(conn)
        config = Config(variables={"user_name": "Alice"})
        set_db_data(adapter, str(seed), config)
        verify_db_data(adapter, str(expected), config)

    @pytest.mark.usefixtures("_users_table")
    def test_matchers_in_verify(self, conn, tmp_path):
        seed = tmp_path / "seed.yaml"
        seed.write_text(
            """\
users:
  - name: "Alice"
    age: 30
    active: true
"""
        )
        expected = tmp_path / "expected.yaml"
        expected.write_text(
            """\
users:
  - name: "$eq(Alice)"
    age: "$and($gt(0),$lt(100))"
    active: true
"""
        )
        adapter = PostgresAdapter(conn)
        set_db_data(adapter, str(seed))
        verify_db_data(adapter, str(expected))

    @pytest.mark.usefixtures("_users_table")
    def test_verify_failure(self, conn, tmp_path):
        seed = tmp_path / "seed.yaml"
        seed.write_text(
            """\
users:
  - name: "Alice"
    age: 30
    active: true
"""
        )
        expected = tmp_path / "expected.yaml"
        expected.write_text(
            """\
users:
  - name: "Bob"
    age: 30
    active: true
"""
        )
        adapter = PostgresAdapter(conn)
        set_db_data(adapter, str(seed))
        with pytest.raises(AssertionError):
            verify_db_data(adapter, str(expected))
