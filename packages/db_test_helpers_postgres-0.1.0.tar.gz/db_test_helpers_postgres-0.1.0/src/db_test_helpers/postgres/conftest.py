"""Shared fixtures for PostgreSQL adapter tests."""

from __future__ import annotations

import os

import psycopg
import pytest


@pytest.fixture
def conn():
    port = os.environ.get("POSTGRES_PORT", "5432")
    connection = psycopg.connect(
        host="localhost",
        port=int(port),
        user="test",
        password="test",
        dbname="testdb",
        autocommit=True,
    )
    yield connection
    _drop_all_tables(connection)
    connection.close()


def _drop_all_tables(conn: psycopg.Connection) -> None:
    rows = conn.execute(
        "SELECT tablename FROM pg_tables WHERE schemaname = 'public'"
    ).fetchall()
    for (table,) in rows:
        conn.execute(psycopg.sql.SQL("DROP TABLE {} CASCADE").format(psycopg.sql.Identifier(table)))
