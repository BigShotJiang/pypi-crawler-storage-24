# deepagents-contrib-aws Development Guidelines

Auto-generated from all feature plans. Last updated: 2026-03-22

## Active Technologies

- Python >=3.11 + boto3 >=1.34.0, deepagents (for BackendProtocol, result types, utilities) (001-s3-backend)

## Project Structure

```text
src/
tests/
```

## Commands

cd src [ONLY COMMANDS FOR ACTIVE TECHNOLOGIES][ONLY COMMANDS FOR ACTIVE TECHNOLOGIES] pytest [ONLY COMMANDS FOR ACTIVE TECHNOLOGIES][ONLY COMMANDS FOR ACTIVE TECHNOLOGIES] ruff check .

## Code Style

Python >=3.11: Follow standard conventions

## Recent Changes

- 001-s3-backend: Added Python >=3.11 + boto3 >=1.34.0, deepagents (for BackendProtocol, result types, utilities)

<!-- MANUAL ADDITIONS START -->
<!-- MANUAL ADDITIONS END -->
