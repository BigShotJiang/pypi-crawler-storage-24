"""
Signature utilities for Humanos API requests.

This module provides functions to generate HMAC-SHA256 signatures
required for authenticating requests to the Humanos API.
"""

import hmac
import hashlib
import json
import time
from typing import Any, Optional, Dict


def generate_signature(
    body: Optional[Any],
    signature_secret: str,
    timestamp: int
) -> str:
    """
    Generate HMAC-SHA256 signature for API requests.

    Args:
        body: Request body (will be JSON stringified if not already a string)
        signature_secret: Your signature secret from Humanos
        timestamp: Unix timestamp in milliseconds

    Returns:
        Hex-encoded HMAC-SHA256 signature
    """
    # Normalize body to string
    body_string = ""
    if body is not None:
        if isinstance(body, str):
            body_string = body
        else:
            stringified = json.dumps(body, separators=(",", ":"))
            # Treat empty objects as empty string
            body_string = "" if stringified == "{}" else stringified

    # Sign: timestamp.body or just timestamp if no body
    to_sign = f"{timestamp}.{body_string}" if body_string else str(timestamp)

    return hmac.new(
        signature_secret.encode("utf-8"),
        to_sign.encode("utf-8"),
        hashlib.sha256
    ).hexdigest()


def create_signed_headers(
    body: Optional[Any],
    api_key: str,
    signature_secret: str,
    timestamp: Optional[int] = None
) -> Dict[str, str]:
    """
    Create headers with signature for Humanos API requests.

    Args:
        body: Request body
        api_key: Your API key from Humanos
        signature_secret: Your signature secret from Humanos
        timestamp: Optional timestamp (defaults to current time in ms)

    Returns:
        Dictionary of headers to include in the request
    """
    if timestamp is None:
        timestamp = int(time.time() * 1000)

    signature = generate_signature(body, signature_secret, timestamp)

    return {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
        "X-Timestamp": str(timestamp),
        "X-Signature": signature,
    }


class SignedSession:
    """
    A requests session wrapper that automatically signs all requests.

    Example:
        >>> session = SignedSession(
        ...     api_key="your-api-key",
        ...     signature_secret="your-signature-secret"
        ... )
        >>> response = session.get("https://api.humanos.io/v1/request")
    """

    def __init__(self, api_key: str, signature_secret: str):
        self.api_key = api_key
        self.signature_secret = signature_secret

    def _prepare_request(self, method: str, url: str, **kwargs) -> Dict:
        """Prepare request with signed headers."""
        import requests

        body = kwargs.get("json") or kwargs.get("data")
        headers = create_signed_headers(
            body,
            self.api_key,
            self.signature_secret
        )

        # Merge with any existing headers
        existing_headers = kwargs.get("headers", {})
        headers.update(existing_headers)
        kwargs["headers"] = headers

        return kwargs

    def get(self, url: str, **kwargs):
        import requests
        kwargs = self._prepare_request("GET", url, **kwargs)
        return requests.get(url, **kwargs)

    def post(self, url: str, **kwargs):
        import requests
        kwargs = self._prepare_request("POST", url, **kwargs)
        return requests.post(url, **kwargs)

    def patch(self, url: str, **kwargs):
        import requests
        kwargs = self._prepare_request("PATCH", url, **kwargs)
        return requests.patch(url, **kwargs)

    def delete(self, url: str, **kwargs):
        import requests
        kwargs = self._prepare_request("DELETE", url, **kwargs)
        return requests.delete(url, **kwargs)

