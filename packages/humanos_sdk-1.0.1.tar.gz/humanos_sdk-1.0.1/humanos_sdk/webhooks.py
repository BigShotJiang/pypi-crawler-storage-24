"""
Webhook utilities for Humanos webhooks.

This module provides functions to verify signatures and decrypt
webhook payloads received from Humanos.

Reference: https://humanos.mintlify.app/essentials/webhooks-intro
"""

import hmac
import hashlib
import json
import time
from base64 import b64decode
from typing import Any, Dict, Optional, TypeVar, Callable
from dataclasses import dataclass
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes


T = TypeVar("T")


@dataclass
class WebhookConfig:
    """Configuration for webhook verification and decryption."""

    signature_secret: str
    encryption_secret: str
    encryption_salt: str
    tolerance_ms: int = 5 * 60 * 1000  # 5 minutes


@dataclass
class EncryptedPayload:
    """Encrypted webhook payload structure."""

    iv: str
    data: str
    tag: str


def verify_webhook_signature(
    payload: str,
    signature: str,
    timestamp: int,
    signature_secret: str,
    tolerance_ms: int = 5 * 60 * 1000
) -> bool:
    """
    Verify webhook signature from Humanos.

    Args:
        payload: Raw request body as string
        signature: Value from x-signature header
        timestamp: Value from x-timestamp header (as int, milliseconds)
        signature_secret: Your signature secret
        tolerance_ms: Maximum allowed time difference in ms (default: 5 minutes)

    Returns:
        True if signature is valid, False otherwise
    """
    # Check timestamp freshness
    now = int(time.time() * 1000)
    if abs(now - timestamp) > tolerance_ms:
        return False

    # Calculate expected signature
    to_sign = f"{timestamp}.{payload}" if payload else str(timestamp)
    expected_signature = hmac.new(
        signature_secret.encode("utf-8"),
        to_sign.encode("utf-8"),
        hashlib.sha256
    ).hexdigest()

    # Use timing-safe comparison
    return hmac.compare_digest(signature, expected_signature)


def decrypt_webhook_payload(
    encrypted_payload: EncryptedPayload,
    encryption_secret: str,
    encryption_salt: str
) -> Any:
    """
    Decrypt webhook payload using AES-256-GCM.

    Args:
        encrypted_payload: The encrypted payload with iv, data, and tag
        encryption_secret: Your encryption secret (base64 encoded)
        encryption_salt: Your encryption salt

    Returns:
        Decrypted payload as parsed JSON
    """
    # Derive key using PBKDF2
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=encryption_salt.encode("utf-8"),
        iterations=10000,
    )
    key = kdf.derive(b64decode(encryption_secret))

    # Decrypt using AES-256-GCM
    iv = b64decode(encrypted_payload.iv)
    ciphertext = b64decode(encrypted_payload.data)
    tag = b64decode(encrypted_payload.tag)

    # AES-GCM expects ciphertext + tag concatenated
    aesgcm = AESGCM(key)
    decrypted = aesgcm.decrypt(iv, ciphertext + tag, None)

    return json.loads(decrypted.decode("utf-8"))


def process_webhook(
    raw_body: str,
    headers: Dict[str, str],
    config: WebhookConfig
) -> Any:
    """
    Verify and decrypt a webhook in one step.

    Args:
        raw_body: Raw request body as string
        headers: Request headers (must contain x-signature and x-timestamp)
        config: Webhook configuration with secrets

    Returns:
        Decrypted and verified webhook payload

    Raises:
        ValueError: If signature is invalid or headers are missing
    """
    # Extract headers (case-insensitive)
    headers_lower = {k.lower(): v for k, v in headers.items()}
    signature = headers_lower.get("x-signature")
    timestamp_str = headers_lower.get("x-timestamp")

    if not signature or not timestamp_str:
        raise ValueError("Missing required webhook headers: x-signature or x-timestamp")

    timestamp = int(timestamp_str)

    # Verify signature
    is_valid = verify_webhook_signature(
        raw_body,
        signature,
        timestamp,
        config.signature_secret,
        config.tolerance_ms
    )

    if not is_valid:
        raise ValueError("Invalid webhook signature")

    # Parse and decrypt payload
    payload_dict = json.loads(raw_body)
    encrypted_payload = EncryptedPayload(
        iv=payload_dict["iv"],
        data=payload_dict["data"],
        tag=payload_dict["tag"]
    )

    return decrypt_webhook_payload(
        encrypted_payload,
        config.encryption_secret,
        config.encryption_salt
    )


def create_flask_webhook_handler(
    config: WebhookConfig,
    handler: Callable[[Any], None]
):
    """
    Create a Flask route handler for Humanos webhooks.

    Args:
        config: Webhook configuration with secrets
        handler: Function to handle the decrypted webhook payload

    Returns:
        Flask route handler function

    Example:
        >>> from flask import Flask
        >>> app = Flask(__name__)
        >>>
        >>> config = WebhookConfig(
        ...     signature_secret="...",
        ...     encryption_secret="...",
        ...     encryption_salt="..."
        ... )
        >>>
        >>> @app.route("/webhook", methods=["POST"])
        ... def webhook():
        ...     return create_flask_webhook_handler(config, my_handler)()
    """
    def route_handler():
        from flask import request, jsonify

        try:
            raw_body = request.get_data(as_text=True)
            payload = process_webhook(raw_body, dict(request.headers), config)
            handler(payload)
            return "", 200
        except ValueError as e:
            if "signature" in str(e).lower():
                return jsonify({"error": str(e)}), 401
            return jsonify({"error": str(e)}), 400
        except Exception as e:
            return jsonify({"error": "Webhook processing failed"}), 500

    return route_handler


def create_fastapi_webhook_handler(
    config: WebhookConfig,
    handler: Callable[[Any], None]
):
    """
    Create a FastAPI route handler for Humanos webhooks.

    Args:
        config: Webhook configuration with secrets
        handler: Function to handle the decrypted webhook payload

    Returns:
        FastAPI route handler function

    Example:
        >>> from fastapi import FastAPI, Request
        >>> app = FastAPI()
        >>>
        >>> config = WebhookConfig(...)
        >>>
        >>> @app.post("/webhook")
        ... async def webhook(request: Request):
        ...     handler = create_fastapi_webhook_handler(config, my_handler)
        ...     return await handler(request)
    """
    async def route_handler(request):
        from fastapi import HTTPException
        from fastapi.responses import Response

        try:
            raw_body = await request.body()
            raw_body_str = raw_body.decode("utf-8")
            headers = dict(request.headers)

            payload = process_webhook(raw_body_str, headers, config)
            handler(payload)
            return Response(status_code=200)
        except ValueError as e:
            if "signature" in str(e).lower():
                raise HTTPException(status_code=401, detail=str(e))
            raise HTTPException(status_code=400, detail=str(e))
        except Exception:
            raise HTTPException(status_code=500, detail="Webhook processing failed")

    return route_handler

