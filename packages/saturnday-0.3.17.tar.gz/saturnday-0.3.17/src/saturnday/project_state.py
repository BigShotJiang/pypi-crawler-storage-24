"""Track what has been built so far, so subsequent tickets get full context.

Simplified from saturnday-v3's ``project_state.py``.  Maintains a JSON
state file (``saturnday-state.json``) in the repo root.  After each
ticket completes, the changed files are AST-scanned and the state is
updated.  ``generate_context_summary()`` produces the text block that is
injected into the coder prompt for the next ticket.
"""

from __future__ import annotations

import ast
import json
import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

STATE_FILENAME = "saturnday-state.json"
SCHEMA_VERSION = "1.0.0"

_SKIP_DIRS = frozenset({
    ".git", ".venv", "venv", "__pycache__", "node_modules", "runs",
    "dist", "build", ".saturnday", ".pytest_cache",
})


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class FunctionState:
    """Tracked state of a single public function."""

    name: str
    params: list[str] = field(default_factory=list)
    return_type: str = ""
    line: int = 0


@dataclass
class ClassState:
    """Tracked state of a single public class."""

    name: str
    methods: list[str] = field(default_factory=list)
    bases: list[str] = field(default_factory=list)
    line: int = 0


@dataclass
class ModuleState:
    """Tracked state of a single Python module."""

    created_by: str = ""
    functions: dict[str, FunctionState] = field(default_factory=dict)
    classes: dict[str, ClassState] = field(default_factory=dict)


@dataclass
class ProjectState:
    """Mutable project state, updated after each ticket."""

    schema_version: str = SCHEMA_VERSION
    project_id: str = ""
    last_updated: str = ""
    modules: dict[str, ModuleState] = field(default_factory=dict)
    tests: dict[str, list[str]] = field(default_factory=dict)
    dependencies: dict[str, dict[str, str]] = field(default_factory=dict)
    decisions: list[dict[str, str]] = field(default_factory=list)


# ---------------------------------------------------------------------------
# AST scanning
# ---------------------------------------------------------------------------

def _parse_file(path: Path) -> ast.Module | None:
    """Attempt to parse a Python file. Returns None on failure."""
    try:
        source = path.read_text(encoding="utf-8", errors="replace")
        return ast.parse(source, filename=str(path))
    except Exception:
        return None


def _scan_module(path: Path) -> ModuleState:
    """Scan a single Python file and return its ``ModuleState``."""
    ms = ModuleState()
    tree = _parse_file(path)
    if tree is None:
        return ms

    for node in ast.iter_child_nodes(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if node.name.startswith("_"):
                continue
            params: list[str] = []
            try:
                for arg in node.args.args:
                    params.append(arg.arg)
            except Exception:
                pass
            ret = ""
            if node.returns:
                try:
                    ret = ast.unparse(node.returns)
                except Exception:
                    pass
            ms.functions[node.name] = FunctionState(
                name=node.name, params=params, return_type=ret, line=node.lineno,
            )
        elif isinstance(node, ast.ClassDef):
            if node.name.startswith("_"):
                continue
            methods: list[str] = []
            for item in node.body:
                if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    methods.append(item.name)
            bases: list[str] = []
            for base in node.bases:
                try:
                    bases.append(ast.unparse(base))
                except Exception:
                    pass
            ms.classes[node.name] = ClassState(
                name=node.name, methods=methods, bases=bases, line=node.lineno,
            )
    return ms


def _scan_test_file(path: Path) -> list[str]:
    """Return test function names from a test file."""
    tree = _parse_file(path)
    if tree is None:
        return []
    tests: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if node.name.startswith("test_"):
                tests.append(node.name)
    return tests


# ---------------------------------------------------------------------------
# Core functions
# ---------------------------------------------------------------------------

def scan_changed_files(
    repo_path: Path,
    changed_files: list[str],
    ticket_id: str,
) -> dict[str, ModuleState]:
    """Scan changed Python files and return their module states.

    Args:
        repo_path: Repository root.
        changed_files: Relative paths of files that changed.
        ticket_id: The ticket that made the changes.

    Returns:
        Dict mapping relative path to ``ModuleState``.
    """
    result: dict[str, ModuleState] = {}
    for rel_path in changed_files:
        if not rel_path.endswith(".py"):
            continue
        full_path = repo_path / rel_path
        if not full_path.exists():
            continue
        if any(part in _SKIP_DIRS for part in Path(rel_path).parts):
            continue
        ms = _scan_module(full_path)
        ms.created_by = ms.created_by or ticket_id
        result[rel_path] = ms
    return result


def update_state(
    state: ProjectState,
    ticket_id: str,
    changed_files: list[str],
    repo_path: Path,
) -> ProjectState:
    """Update project state after a ticket completes successfully.

    Args:
        state: Current project state (mutated in place).
        ticket_id: The completing ticket.
        changed_files: Relative paths of files changed by the ticket.
        repo_path: Repository root.

    Returns:
        The updated state (same object, mutated).
    """
    state.last_updated = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    for rel_path in changed_files:
        if not rel_path.endswith(".py"):
            continue
        full_path = repo_path / rel_path
        if not full_path.exists():
            state.modules.pop(rel_path, None)
            state.tests.pop(rel_path, None)
            continue
        if any(part in _SKIP_DIRS for part in Path(rel_path).parts):
            continue

        ms = _scan_module(full_path)
        existing = state.modules.get(rel_path)
        if existing:
            ms.created_by = existing.created_by
        else:
            ms.created_by = ticket_id
        state.modules[rel_path] = ms

        if "test" in rel_path:
            test_funcs = _scan_test_file(full_path)
            if test_funcs:
                state.tests[rel_path] = test_funcs

    return state


def generate_context_summary(state: ProjectState) -> str:
    """Produce the text block injected into every coder prompt.

    Describes existing modules, tests, and dependencies so the coder
    knows what already exists and must not break.
    """
    lines: list[str] = []
    lines.append("PROJECT STATE (do not contradict or remove anything listed here):")
    lines.append("")

    if state.modules:
        lines.append("Existing modules:")
        for path, ms in sorted(state.modules.items()):
            parts: list[str] = []
            for fname, fstate in sorted(ms.functions.items()):
                sig = f"{fname}({', '.join(fstate.params)})"
                if fstate.return_type:
                    sig += f" -> {fstate.return_type}"
                parts.append(sig)
            for cname, cstate in sorted(ms.classes.items()):
                method_str = ""
                if cstate.methods:
                    method_str = f" with {', '.join(cstate.methods)}"
                parts.append(f"class {cname}{method_str}")
            if parts:
                tag = f"  [{ms.created_by}]" if ms.created_by else ""
                lines.append(f"- {path}: {', '.join(parts)}{tag}")
        lines.append("")

    total_tests = sum(len(ts) for ts in state.tests.values())
    if total_tests > 0:
        lines.append(f"Existing tests: {total_tests} across {len(state.tests)} test files")
        lines.append("")

    if state.dependencies:
        lines.append("Dependencies:")
        for pkg, info in sorted(state.dependencies.items()):
            ver = info.get("version", "")
            lines.append(f"- {pkg}{ver}")
        lines.append("")

    lines.append(
        "DO NOT remove, rename, or change the signature of any existing "
        "function unless this ticket explicitly says to."
    )
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Persistence
# ---------------------------------------------------------------------------

def _module_state_to_dict(ms: ModuleState) -> dict[str, Any]:
    """Serialize a ``ModuleState`` to a JSON-compatible dict."""
    return {
        "created_by": ms.created_by,
        "functions": {
            name: {
                "name": f.name,
                "params": f.params,
                "return_type": f.return_type,
                "line": f.line,
            }
            for name, f in ms.functions.items()
        },
        "classes": {
            name: {
                "name": c.name,
                "methods": c.methods,
                "bases": c.bases,
                "line": c.line,
            }
            for name, c in ms.classes.items()
        },
    }


def _module_state_from_dict(d: dict[str, Any]) -> ModuleState:
    """Deserialize a ``ModuleState`` from a dict."""
    ms = ModuleState(created_by=d.get("created_by", ""))
    for name, fd in d.get("functions", {}).items():
        ms.functions[name] = FunctionState(
            name=fd.get("name", name),
            params=fd.get("params", []),
            return_type=fd.get("return_type", ""),
            line=fd.get("line", 0),
        )
    for name, cd in d.get("classes", {}).items():
        ms.classes[name] = ClassState(
            name=cd.get("name", name),
            methods=cd.get("methods", []),
            bases=cd.get("bases", []),
            line=cd.get("line", 0),
        )
    return ms


def save_state(state: ProjectState, repo_path: Path) -> None:
    """Save project state to ``saturnday-state.json`` in repo root."""
    data: dict[str, Any] = {
        "schema_version": state.schema_version,
        "project_id": state.project_id,
        "last_updated": state.last_updated,
        "modules": {
            path: _module_state_to_dict(ms) for path, ms in state.modules.items()
        },
        "tests": state.tests,
        "dependencies": state.dependencies,
        "decisions": state.decisions,
    }
    path = repo_path / STATE_FILENAME
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")
    logger.info("Saved project state to %s", path)


def load_state(repo_path: Path) -> ProjectState | None:
    """Load project state from ``saturnday-state.json``.

    Returns:
        The loaded state, or ``None`` if the file does not exist or is invalid.
    """
    path = repo_path / STATE_FILENAME
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8", errors="replace"))
    except Exception:
        logger.warning("Failed to load project state from %s", path)
        return None
    if not isinstance(data, dict):
        return None

    state = ProjectState(
        schema_version=data.get("schema_version", SCHEMA_VERSION),
        project_id=data.get("project_id", ""),
        last_updated=data.get("last_updated", ""),
    )
    for path_str, ms_dict in data.get("modules", {}).items():
        if isinstance(ms_dict, dict):
            state.modules[path_str] = _module_state_from_dict(ms_dict)
    state.tests = data.get("tests", {})
    state.dependencies = data.get("dependencies", {})
    state.decisions = data.get("decisions", [])
    return state
