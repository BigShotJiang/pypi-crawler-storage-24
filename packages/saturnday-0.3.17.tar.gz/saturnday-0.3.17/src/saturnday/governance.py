"""Governance mode: run review checks on a diff and produce an evidence pack."""

import subprocess
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path

from .evidence import CheckResult, EvidencePack, SCHEMA_VERSION, compute_disposition, write_evidence_dir
from .policy_manifest import (
    PolicyManifest,
    default_policy,
    evaluate_scope,
    get_check_severity,
    load_policy,
    should_run_check,
)
from .ratchet import (
    FindingFingerprint,
    compare_findings,
    fingerprint_check_results,
    load_baseline,
)
from .waivers import load_waivers_from_policy, check_waiver
from .review import run_review
from .shell_policy import run_shell
from .version import __version__


def extract_changed_files(
    repo_path: Path, diff_range: str, *, staged: bool = False
) -> tuple[list[str], str]:
    """Run git diff --name-only. Returns (changed_files, raw_diff_text)."""
    if staged:
        name_cmd = ["git", "diff", "--cached", "--name-only"]
        diff_cmd = ["git", "diff", "--cached"]
    else:
        name_cmd = ["git", "diff", "--name-only", diff_range]
        diff_cmd = ["git", "diff", diff_range]

    name_result = subprocess.run(
        name_cmd, cwd=str(repo_path), capture_output=True, text=True, check=False,
    )
    if name_result.returncode != 0:
        raise RuntimeError(
            f"git diff --name-only failed (rc={name_result.returncode}): "
            f"{name_result.stderr.strip()}"
        )

    files = [f.strip() for f in name_result.stdout.strip().splitlines() if f.strip()]

    diff_result = subprocess.run(
        diff_cmd, cwd=str(repo_path), capture_output=True, check=False,
    )
    # Decode with errors="replace" to handle binary files (STEP, images, etc.)
    raw_diff = diff_result.stdout.decode("utf-8", errors="replace") if diff_result.stdout else ""

    return files, raw_diff


def _convert_review_result(
    check_name: str,
    tool_result: dict,
    policy: PolicyManifest,
    elapsed_s: float,
) -> CheckResult:
    """Convert a single review tool result dict to a CheckResult."""
    status = tool_result.get("status", "PASS")
    findings = tool_result.get("findings", [])
    if not isinstance(findings, list):
        findings = []

    severity = get_check_severity(policy, check_name)

    # Map review status to evidence status
    if status == "FAIL":
        evidence_status = "FAIL"
    elif status == "SKIPPED":
        evidence_status = "SKIPPED"
    else:
        evidence_status = "PASS"

    # Normalize findings to dicts
    normalized_findings = []
    for f in findings:
        if isinstance(f, dict):
            normalized_findings.append(f)
        elif isinstance(f, str):
            normalized_findings.append({"message": f})

    return CheckResult(
        name=check_name,
        status=evidence_status,
        severity=severity,
        findings=normalized_findings,
        files_checked=[],
        elapsed_s=elapsed_s,
        error=tool_result.get("error"),
    )


def run_full_repo_review(
    repo_path: Path,
    *,
    policy_path: Path | None = None,
    output_dir: Path | None = None,
) -> "tuple[EvidencePack, Path | None]":
    """Run governance checks on all tracked files in the repo.

    Unlike :func:`run_governance_check`, this function does not require a diff
    range.  It discovers all tracked files via ``git ls-files``, filters to
    supported extensions, and feeds them through the standard review pipeline.

    Args:
        repo_path: Path to the repository root (must be a git repo).
        policy_path: Optional path to a policy YAML file.
        output_dir: Directory to write evidence.  If ``None``, evidence is
            written to ``~/.saturnday/evidence/<run_id>``.

    Returns:
        Tuple of ``(EvidencePack, evidence_path)``.  ``evidence_path`` is the
        directory where evidence was written, or ``None`` on early failure.

    Raises:
        RuntimeError: If ``repo_path`` is not a git repository or
            ``git ls-files`` fails.
    """
    import tempfile as _tempfile

    supported_extensions = {".py", ".js", ".ts", ".jsx", ".tsx", ".sh"}

    start_time = time.monotonic()
    created_utc = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    run_id = f"review_{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}"

    # Validate repo
    if not (repo_path / ".git").exists():
        raise RuntimeError(f"Not a git repository: {repo_path}")

    # Discover all tracked files
    ls_result = subprocess.run(
        ["git", "ls-files"],
        cwd=str(repo_path),
        capture_output=True,
        text=True,
        check=False,
    )
    if ls_result.returncode != 0:
        raise RuntimeError(
            f"git ls-files failed (rc={ls_result.returncode}): "
            f"{ls_result.stderr.strip()}"
        )

    all_files = [f.strip() for f in ls_result.stdout.strip().splitlines() if f.strip()]
    changed_files = [
        f for f in all_files
        if Path(f).suffix in supported_extensions
        and not any(part.startswith(".saturnday") for part in Path(f).parts)
    ]

    # Load policy
    if policy_path is not None:
        policy = load_policy(policy_path)
    else:
        policy = default_policy()

    check_results: list[CheckResult] = []

    if changed_files:
        with _tempfile.TemporaryDirectory() as tmpdir:
            review_result = run_review(
                repo_path,
                changed_files,
                Path(tmpdir),
                run_shell_func=run_shell,
                timeout_s=30,
                strict=False,
            )

        tool_runs = review_result.get("tool_runs", [])
        tools = review_result.get("tools", {})

        for check_name, tool_result in tools.items():
            if not should_run_check(policy, check_name):
                continue

            elapsed = 0.0
            for tr in tool_runs:
                if tr.get("tool") == check_name:
                    elapsed = tr.get("elapsed_s", 0.0)
                    break

            check_results.append(
                _convert_review_result(check_name, tool_result, policy, elapsed)
            )

    disposition, reasons = compute_disposition(check_results)

    ended_utc = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    pack = EvidencePack(
        schema_version=SCHEMA_VERSION,
        run_id=run_id,
        mode="review",
        repo_path=str(repo_path),
        diff_range=None,
        saturnday_version=__version__,
        created_utc=created_utc,
        ended_utc=ended_utc,
        check_results=check_results,
        disposition=disposition,
        disposition_reasons=reasons,
        policy_path=str(policy_path) if policy_path else None,
    )

    if output_dir is None:
        # Write evidence inside the repo for sandbox compatibility
        output_dir = repo_path / ".saturnday" / "evidence" / run_id

    evidence_path = write_evidence_dir(pack, output_dir)

    # Record to run_data.db (best effort)
    try:
        from .run_data import get_db, init_db, record_evidence_pack
        conn = get_db()
        try:
            init_db(conn)
            record_evidence_pack(conn, pack)
        finally:
            conn.close()
    except Exception:
        pass

    return pack, evidence_path


def run_governance_check(
    repo_path: Path,
    diff_range: str,
    *,
    staged: bool = False,
    policy_path: Path | None = None,
    output_dir: Path | None = None,
    strict: bool = False,
    auto_install_deps: bool = False,
) -> tuple[EvidencePack, Path]:
    """
    Run governance checks on a diff range.

    1. Validate repo is a git repo
    2. Extract changed files from diff
    3. Load policy (or default)
    4. Evaluate scope constraints
    5. Run run_review() against changed files
    6. Convert review results -> CheckResults with policy severity
    7. Compute disposition
    8. Write evidence pack
    9. Record to run_data.db
    10. Return (pack, evidence_dir_path)
    """
    start_time = time.monotonic()
    created_utc = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    run_id = f"check_{datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')}"

    # 1. Validate repo
    git_dir = repo_path / ".git"
    if not git_dir.exists():
        raise RuntimeError(f"Not a git repository: {repo_path}")

    # 2. Extract changed files
    changed_files, raw_diff = extract_changed_files(repo_path, diff_range, staged=staged)

    # 3. Load policy
    if policy_path is not None:
        policy = load_policy(policy_path)
    else:
        policy = default_policy()

    # 4. Evaluate scope
    scope_ok, scope_reasons = evaluate_scope(policy, changed_files)
    scope_results: list[CheckResult] = []
    if not scope_ok:
        scope_results.append(CheckResult(
            name="scope",
            status="FAIL",
            severity="error",
            findings=[{"message": r} for r in scope_reasons],
            files_checked=changed_files,
            elapsed_s=0.0,
        ))

    # 5. Run review pipeline
    # Respect auto_install_deps from CLI flag OR policy manifest
    effective_auto_install = auto_install_deps or policy.auto_install_deps
    check_results: list[CheckResult] = list(scope_results)

    if changed_files:
        with tempfile.TemporaryDirectory() as tmpdir:
            review_result = run_review(
                repo_path,
                changed_files,
                Path(tmpdir),
                run_shell_func=run_shell,
                timeout_s=30,
                strict=strict,
                auto_install_deps=effective_auto_install,
            )

        # 6. Convert review results
        tool_runs = review_result.get("tool_runs", [])
        tools = review_result.get("tools", {})

        for check_name, tool_result in tools.items():
            if not should_run_check(policy, check_name):
                continue

            # Find elapsed time from tool_runs
            elapsed = 0.0
            for tr in tool_runs:
                if tr.get("tool") == check_name:
                    elapsed = tr.get("elapsed_s", 0.0)
                    break

            check_results.append(
                _convert_review_result(check_name, tool_result, policy, elapsed)
            )

    # 7. Compute disposition
    disposition, reasons = compute_disposition(check_results)

    # 7b. Ratchet comparison (if baseline exists)
    baseline_path = repo_path / ".saturnday-baseline.json"
    ratchet_result = None
    if baseline_path.exists():
        try:
            baseline = load_baseline(baseline_path)
            current_fps = fingerprint_check_results(check_results, repo_path)

            # Compute waived fingerprints from policy waivers
            waived_fps: set[FindingFingerprint] = set()
            if policy_path is not None:
                try:
                    import yaml
                    with open(policy_path) as f:
                        policy_raw = yaml.safe_load(f) or {}
                    waivers = load_waivers_from_policy(policy_raw)
                    if waivers:
                        for fp in current_fps:
                            result = check_waiver(
                                rule_id=fp.rule_id,
                                file_path=fp.path,
                                line=0,
                                waivers=waivers,
                                inline_suppressions=[],
                            )
                            if result.suppressed:
                                waived_fps.add(fp)
                except Exception:
                    pass  # never break governance for waiver errors

            ratchet_result = compare_findings(current_fps, baseline, waived_fingerprints=waived_fps)

            # Ratchet can escalate disposition
            if ratchet_result.disposition == "FAIL":
                disposition = "FAIL"
                for r in ratchet_result.reasons:
                    reasons.append({
                        "check": "ratchet",
                        "status": "FAIL",
                        "severity": "error",
                        "finding_count": len(ratchet_result.new_findings),
                        "message": r,
                    })
        except Exception:
            pass  # never break governance flow for ratchet errors

    ended_utc = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    total_elapsed = time.monotonic() - start_time

    # 8. Build evidence pack
    pack = EvidencePack(
        schema_version=SCHEMA_VERSION,
        run_id=run_id,
        mode="check",
        repo_path=str(repo_path),
        diff_range=diff_range if not staged else "--staged",
        saturnday_version=__version__,
        created_utc=created_utc,
        ended_utc=ended_utc,
        check_results=check_results,
        disposition=disposition,
        disposition_reasons=reasons,
        policy_path=str(policy_path) if policy_path else None,
    )

    # Determine output directory — write inside repo for sandbox compatibility
    if output_dir is None:
        output_dir = repo_path / ".saturnday" / "evidence" / run_id
    evidence_path = write_evidence_dir(pack, output_dir)

    # Write raw diff if available
    if raw_diff:
        (evidence_path / "diff-input.diff").write_text(raw_diff)

    # 9. Record to run_data.db (best effort)
    try:
        from .run_data import get_db, init_db, record_evidence_pack
        conn = get_db()
        try:
            init_db(conn)
            record_evidence_pack(conn, pack)
        finally:
            conn.close()
    except Exception:
        pass  # never break governance flow

    return pack, evidence_path
