"""Native plan generator — Saturnday-owned ``/plan`` command.

Generates a validated plan.json from a plain-language brief.
Uses a generate-validate-fix loop (max 3 rounds) ported from v3's
``plan_generator.py``.

The planner backend can differ from the execution backend — a stronger
model for planning, a cheaper/faster model for coding.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from saturnday._types import CoderConfig
from saturnday.plan_parser import validate_plan
from saturnday.shared.plan_schema import schema_for_prompt

logger = logging.getLogger(__name__)

MAX_PLANNER_ROUNDS = 3


def _scan_repo_layout(repo_path: Path) -> str:
    """Scan repo for language, framework, tests, and structure.

    Returns a text summary suitable for injection into the planner prompt.
    """
    lines: list[str] = []

    # Detect languages by file extension
    extensions: dict[str, int] = {}
    for f in repo_path.rglob("*"):
        if f.is_file() and not any(
            p in f.parts for p in (".git", "node_modules", ".venv", "__pycache__", "dist")
        ):
            ext = f.suffix.lower()
            if ext in (".py", ".js", ".ts", ".tsx", ".jsx", ".go", ".rs", ".java", ".rb"):
                extensions[ext] = extensions.get(ext, 0) + 1

    if extensions:
        top = sorted(extensions.items(), key=lambda x: -x[1])[:5]
        lines.append("Languages: " + ", ".join(f"{ext} ({count} files)" for ext, count in top))

    # Detect frameworks/config
    markers = {
        "pyproject.toml": "Python (pyproject.toml)",
        "setup.py": "Python (setup.py)",
        "package.json": "Node.js",
        "Cargo.toml": "Rust",
        "go.mod": "Go",
        "pom.xml": "Java (Maven)",
        "build.gradle": "Java (Gradle)",
    }
    for marker_file, label in markers.items():
        if (repo_path / marker_file).exists():
            lines.append(f"Framework: {label}")

    # Detect test presence
    test_dirs = [d for d in ("tests", "test", "spec", "__tests__") if (repo_path / d).is_dir()]
    if test_dirs:
        lines.append(f"Test directories: {', '.join(test_dirs)}")

    # Basic directory listing (top level only)
    top_dirs = sorted(
        d.name for d in repo_path.iterdir()
        if d.is_dir() and not d.name.startswith(".")
        and d.name not in ("node_modules", "__pycache__", ".venv", "dist", "build")
    )
    if top_dirs:
        lines.append(f"Top-level dirs: {', '.join(top_dirs[:15])}")

    return "\n".join(lines) if lines else "Empty or minimal repository."


def _build_skeleton_prompt(brief: str, repo_context: str) -> str:
    """Stage 1: Generate a lightweight ticket skeleton — just IDs and one-line goals."""
    return (
        "You are a project planner. List the tickets for this project.\n\n"
        f"## Repo Context\n{repo_context}\n\n"
        f"## Brief\n{brief}\n\n"
        "## Rules\n"
        "- Many small tickets. Each ticket: max 40 lines of code, 1 source file.\n"
        "- If < 300 lines total, keep implementation in ONE file.\n"
        "- Tests: 3x more for risky logic. State exact counts. FORBIDDEN: even distribution.\n\n"
        "Output ONLY valid JSON:\n"
        '{"tickets": [\n'
        '  {"ticket_id": "T001", "goal": "one line goal"},\n'
        '  {"ticket_id": "T002", "goal": "one line goal", "depends_on": ["T001"]}\n'
        "]}\n\n"
        "Keep goals to ONE LINE each. No explanation."
    )


_ENRICH_BATCH_SIZE = 4  # Tickets per enrichment call


def _build_batch_enrich_prompt(
    brief: str,
    batch_tickets: list[dict],
    repo_context: str,
) -> str:
    """Enrich a small batch of tickets (3-4 at a time)."""
    ticket_list = json.dumps(batch_tickets, indent=2)
    return (
        "You are a senior project planner. Enrich these tickets with design decisions.\n\n"
        f"## Brief\n{brief}\n\n"
        f"## Tickets to enrich\n{ticket_list}\n\n"
        "## Rules\n"
        "For each ticket, expand the goal to include: DESIGN (approach+why), FOCUS (hard part), RESTRAINT (what NOT to build).\n"
        "Add out_of_scope (forbidden patterns) and acceptance_criteria (verifiable checks).\n"
        "Structure: if < 300 lines total, keep in ONE file.\n"
        "Tests: 3x more for risky logic. State exact counts. FORBIDDEN: even distribution.\n\n"
        "Output ONLY a JSON array of enriched tickets. No markdown, no explanation:\n"
        '[{"ticket_id": "T001", "goal": "enriched goal with DESIGN/FOCUS/RESTRAINT", '
        '"out_of_scope": [...], "acceptance_criteria": [...], "depends_on": [...]}, ...]'
    )


def _build_assemble_prompt(
    brief: str,
    enriched_tickets: list[dict],
    errors: list[str] | None = None,
) -> str:
    """Stage 3: Assemble enriched tickets into final plan.json with phases."""
    ticket_list = json.dumps(enriched_tickets, indent=2)
    parts = [
        "You are a project planner. Assemble these enriched tickets into a valid plan.json.\n",
        f"## Brief\n{brief}\n",
        f"## Enriched Tickets\n{ticket_list}\n",
        "## Task\n"
        "Wrap these tickets into a plan.json with project_id, phases, and definition_of_done.\n",
        f"## Output Format\n{schema_for_prompt()}",
    ]
    if errors:
        parts.append("\n## Validation Errors — Fix These")
        for e in errors:
            parts.append(f"- {e}")
    parts.append("\nOutput ONLY the JSON plan — no markdown fences, no explanation.")
    return "\n".join(parts)


def _build_planner_prompt(
    brief: str,
    repo_context: str,
    errors: list[str] | None = None,
) -> str:
    """Legacy single-shot planner prompt (fallback if two-stage fails)."""
    parts: list[str] = []

    parts.append("You are a senior software project planner. Generate a plan.json.")
    parts.append("")
    parts.append(f"## Repo Context\n{repo_context}")
    parts.append(f"\n## Brief\n{brief}")
    parts.append("\n## Rules")
    parts.append("Many small tickets. Max 40 lines per ticket, 1 source file each.")
    parts.append("Each goal: DESIGN (approach+why), FOCUS (hard part), RESTRAINT (what NOT to build).")
    parts.append("Use out_of_scope for forbidden patterns. <300 lines = ONE file.")
    parts.append("Tests: 3x more for risky logic. State exact counts. FORBIDDEN: even distribution.")
    parts.append(f"\n## Output Format\n{schema_for_prompt()}")

    if errors:
        parts.append("\n## Validation Errors — Fix These")
        for e in errors:
            parts.append(f"- {e}")

    parts.append("\nOutput ONLY the JSON plan — no markdown fences, no explanation.")
    return "\n".join(parts)


def _extract_json(response: str) -> dict[str, Any] | list | None:
    """Extract a JSON object or array from the LLM response."""
    text = response.strip()

    # Strip ALL markdown code fences — not just at the start
    # Handles: ```json\n...\n``` anywhere in the response
    import re
    fence_match = re.search(r'```(?:json)?\s*\n(.*?)\n\s*```', text, re.DOTALL)
    if fence_match:
        text = fence_match.group(1).strip()

    try:
        obj = json.loads(text)
        if isinstance(obj, (dict, list)):
            return obj
    except json.JSONDecodeError:
        pass

    # Try to find JSON object or array in the response
    for open_char, close_char in [("{", "}"), ("[", "]")]:
        start_pos = text.find(open_char)
        if start_pos >= 0:
            depth = 0
            for i in range(start_pos, len(text)):
                if text[i] == open_char:
                    depth += 1
                elif text[i] == close_char:
                    depth -= 1
                    if depth == 0:
                        try:
                            result = json.loads(text[start_pos:i + 1])
                            if isinstance(result, (dict, list)):
                                return result
                        except json.JSONDecodeError:
                            pass
                        break

    return None


def generate_plan(
    brief: str,
    repo_path: str | Path,
    coder_config: CoderConfig,
    *,
    planner_config: CoderConfig | None = None,
    output_path: str | Path | None = None,
    max_rounds: int = MAX_PLANNER_ROUNDS,
) -> Path:
    """Generate a validated plan.json from a project brief.

    Uses a generate-validate-fix loop (ported from v3 plan_generator.py).

    Args:
        brief: Plain-language project brief.
        repo_path: Path to the target repository.
        coder_config: Default backend config (used if planner_config not set).
        planner_config: Optional separate config for the planner backend.
        output_path: Path to write plan.json (default: repo_path/plan.json).
        max_rounds: Maximum generate-validate-fix rounds.

    Returns:
        Path to the written plan.json.

    Raises:
        ValueError: If the plan cannot be validated after max_rounds.
    """
    from saturnday.coder_adapter import call_coder
    from saturnday.context_assembler import assemble_messages

    repo_path = Path(repo_path).resolve()
    config = planner_config or coder_config

    if output_path is None:
        output_path = repo_path / "plan.json"
    else:
        output_path = Path(output_path).resolve()

    # Scan repo for context
    repo_context = _scan_repo_layout(repo_path)
    logger.info("Repo context:\n%s", repo_context)

    plan: dict[str, Any] | None = None

    # Stage 1: Generate lightweight skeleton (fast — small output)
    logger.info("Planner stage 1: generating ticket skeleton")
    skeleton_prompt = _build_skeleton_prompt(brief, repo_context)
    skeleton_messages = assemble_messages("You are a project planner.", skeleton_prompt, None)
    skeleton_response = call_coder(config, skeleton_messages, repo_path)
    skeleton = _extract_json(skeleton_response)

    if skeleton and skeleton.get("tickets"):
        all_tickets = skeleton["tickets"]
        logger.info("Stage 1: got %d ticket(s) in skeleton", len(all_tickets))

        # Stage 2: Enrich tickets in small batches (3-4 at a time)
        enriched_tickets: list[dict] = []
        for batch_start in range(0, len(all_tickets), _ENRICH_BATCH_SIZE):
            batch = all_tickets[batch_start:batch_start + _ENRICH_BATCH_SIZE]
            batch_ids = [t.get("ticket_id", "?") for t in batch]

            # Retry batch up to 3 times — no skeleton fallback
            batch_enriched = False
            for attempt in range(1, 4):
                logger.info("Stage 2: enriching batch %s (attempt %d)", batch_ids, attempt)

                enrich_prompt = _build_batch_enrich_prompt(brief, batch, repo_context)
                if attempt > 1:
                    enrich_prompt += "\n\nIMPORTANT: Output ONLY a raw JSON array. No markdown fences. No explanation. Just [{...}, {...}]."
                enrich_messages = assemble_messages("You are a project planner.", enrich_prompt, None)

                try:
                    response = call_coder(config, enrich_messages, repo_path)
                except Exception as exc:
                    logger.warning("Stage 2: batch %s attempt %d failed: %s", batch_ids, attempt, exc)
                    continue

                batch_result = _extract_json(response)
                if isinstance(batch_result, list):
                    enriched_tickets.extend(batch_result)
                    logger.info("Stage 2: enriched %d ticket(s)", len(batch_result))
                    batch_enriched = True
                    break
                elif isinstance(batch_result, dict) and batch_result.get("tickets"):
                    enriched_tickets.extend(batch_result["tickets"])
                    logger.info("Stage 2: enriched %d ticket(s)", len(batch_result["tickets"]))
                    batch_enriched = True
                    break
                else:
                    logger.warning("Stage 2: batch %s attempt %d — could not parse JSON from %d chars", batch_ids, attempt, len(response))

            if not batch_enriched:
                logger.error("Stage 2: batch %s failed after 3 attempts — using skeleton", batch_ids)
                enriched_tickets.extend(batch)

        # Stage 3: Assemble plan in Python — no LLM call needed
        # We have the enriched tickets. Just need phases and metadata.
        logger.info("Planner stage 3: assembling plan from enriched tickets")

        # Build phases from ticket dependencies
        # Phase 1: tickets with no dependencies
        # Phase 2: tickets depending on phase 1
        # etc.
        phase_1_ids = []
        phase_2_ids = []
        for t in enriched_tickets:
            deps = t.get("depends_on", [])
            if not deps:
                phase_1_ids.append(t.get("ticket_id", ""))
            else:
                phase_2_ids.append(t.get("ticket_id", ""))

        phases = []
        if phase_1_ids:
            phases.append({"name": "core", "ticket_ids": phase_1_ids})
        if phase_2_ids:
            phases.append({"name": "integration", "ticket_ids": phase_2_ids})

        # Generate a project_id from the brief
        project_id = brief.split()[:3]
        project_id = "-".join(w.lower().strip(".,;:") for w in project_id if w.isalnum())[:30] or "project"

        plan = {
            "project_id": project_id,
            "tickets": enriched_tickets,
            "phases": phases,
            "definition_of_done": ["all_tickets_passed"],
            "notes": brief,
        }

        errors = validate_plan(plan)
        if errors:
            logger.warning("Stage 3: assembled plan has %d validation error(s)", len(errors))
            # Try to fix common issues
            for t in plan["tickets"]:
                if "ticket_id" not in t:
                    t["ticket_id"] = f"T{enriched_tickets.index(t) + 1:03d}"
                if "goal" not in t:
                    t["goal"] = t.get("title", "implement ticket")
            errors = validate_plan(plan)
        if not errors:
            logger.info("Stage 3: plan assembled and validated")
    else:
        # Fallback: single-shot planner (legacy)
        logger.warning("Stage 1 failed — falling back to single-shot planner")
        errors: list[str] | None = None
        for round_num in range(1, max_rounds + 1):
            logger.info("Planner fallback round %d/%d", round_num, max_rounds)
            prompt = _build_planner_prompt(brief, repo_context, errors)
            messages = assemble_messages("You are a project planner.", prompt, None)
            response = call_coder(config, messages, repo_path)

            plan = _extract_json(response)
            if plan is None:
                errors = ["Response is not valid JSON. Output ONLY a JSON object."]
                continue

            errors = validate_plan(plan)
            if not errors:
                break

    if plan is None or (errors and len(errors) > 0):
        err_msg = "; ".join(errors) if errors else "No valid plan generated"
        raise ValueError(f"Plan generation failed: {err_msg}")

    # Write plan
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        json.dumps(plan, indent=2) + "\n",
        encoding="utf-8",
    )
    logger.info("Wrote plan: %s", output_path)

    # Auto-commit plan.json so it survives crashes during execution
    try:
        import subprocess as _sp
        _sp.run(["git", "-C", str(repo_path), "add", str(output_path)], capture_output=True, timeout=10)
        _sp.run(["git", "-C", str(repo_path), "commit", "-m", "saturnday: plan generated", "--no-verify"],
                capture_output=True, timeout=10)
        logger.info("Plan committed to git")
    except Exception:
        pass

    return output_path
