"""Operational recovery: resume and rerun-failed.

``resume_plan`` continues a run from the last ledger checkpoint, skipping
tickets that already passed.  ``rerun_failed`` re-executes only tickets
that failed in a prior run.

Both delegate to the existing ``_run_ticket_with_retries`` in ticket_runner.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

from saturnday._types import CoderConfig, RunResult

logger = logging.getLogger(__name__)


def _load_ledger(evidence_dir: Path) -> dict[str, Any]:
    """Load ledger.json from the evidence directory.

    Args:
        evidence_dir: Base output directory (parent of ``evidence/run/``).

    Returns:
        Parsed ledger dict.

    Raises:
        FileNotFoundError: If ledger.json does not exist.
    """
    ledger_path = evidence_dir / "evidence" / "run" / "ledger.json"
    if not ledger_path.exists():
        raise FileNotFoundError(f"Ledger not found: {ledger_path}")
    return json.loads(ledger_path.read_text(encoding="utf-8"))


def resume_plan(
    evidence_dir: str | Path,
    plan_path: str | Path,
    repo_path: str | Path,
    coder_config: CoderConfig,
    standards_dir: str | Path,
    output_dir: str | Path | None = None,
) -> RunResult:
    """Continue a run from the last ledger checkpoint.

    Tickets that already PASSED are skipped. Execution resumes from the
    first non-PASS ticket.

    Args:
        evidence_dir: Directory containing the prior run's evidence.
        plan_path: Path to the plan JSON file.
        repo_path: Path to the target repository.
        coder_config: Backend configuration.
        standards_dir: Path to engineering standards directory.
        output_dir: Output directory for the resumed run (default: evidence_dir).

    Returns:
        RunResult for the resumed execution.
    """
    evidence_dir = Path(evidence_dir).resolve()
    ledger_data = _load_ledger(evidence_dir)

    # Identify tickets that already passed
    ticket_statuses = ledger_data.get("ticket_statuses", {})
    passed_tickets = frozenset(
        tid for tid, ts in ticket_statuses.items()
        if ts.get("disposition") == "PASS"
    )

    logger.info(
        "Resuming plan: %d tickets already passed, will skip them",
        len(passed_tickets),
    )

    return _run_with_filter(
        plan_path=plan_path,
        repo_path=repo_path,
        coder_config=coder_config,
        standards_dir=standards_dir,
        output_dir=output_dir or str(evidence_dir),
        skip_tickets=passed_tickets,
    )


def rerun_failed(
    evidence_dir: str | Path,
    plan_path: str | Path,
    repo_path: str | Path,
    coder_config: CoderConfig,
    standards_dir: str | Path,
    output_dir: str | Path | None = None,
) -> RunResult:
    """Re-execute only tickets that failed in a prior run.

    Args:
        evidence_dir: Directory containing the prior run's evidence.
        plan_path: Path to the plan JSON file.
        repo_path: Path to the target repository.
        coder_config: Backend configuration.
        standards_dir: Path to engineering standards directory.
        output_dir: Output directory for the rerun (default: evidence_dir).

    Returns:
        RunResult for the rerun execution.
    """
    evidence_dir = Path(evidence_dir).resolve()
    ledger_data = _load_ledger(evidence_dir)

    ticket_statuses = ledger_data.get("ticket_statuses", {})
    failed_tickets = frozenset(
        tid for tid, ts in ticket_statuses.items()
        if ts.get("disposition") == "FAIL"
    )

    if not failed_tickets:
        logger.info("No failed tickets to rerun")
        return RunResult(project_id="unknown")

    # Skip everything except failed tickets
    all_tickets = frozenset(ticket_statuses.keys())
    skip_tickets = all_tickets - failed_tickets

    logger.info(
        "Rerunning %d failed tickets: %s",
        len(failed_tickets), sorted(failed_tickets),
    )

    return _run_with_filter(
        plan_path=plan_path,
        repo_path=repo_path,
        coder_config=coder_config,
        standards_dir=standards_dir,
        output_dir=output_dir or str(evidence_dir),
        skip_tickets=skip_tickets,
    )


def _run_with_filter(
    plan_path: str | Path,
    repo_path: str | Path,
    coder_config: CoderConfig,
    standards_dir: str | Path,
    output_dir: str | Path,
    skip_tickets: frozenset[str],
) -> RunResult:
    """Run a plan, skipping specified tickets.

    This is a thin wrapper around ``run_plan`` that patches the plan to
    mark filtered tickets as pre-completed.
    """
    from saturnday.ticket_runner import run_plan

    return run_plan(
        plan_path=plan_path,
        repo_path=repo_path,
        coder_config=coder_config,
        standards_dir=standards_dir,
        output_dir=output_dir,
        skip_tickets=skip_tickets,
    )
