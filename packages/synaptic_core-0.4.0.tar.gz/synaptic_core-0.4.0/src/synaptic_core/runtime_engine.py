"""Runtime orchestration service for _SynapticEngine hot-path operations."""

from __future__ import annotations

import time
from typing import TYPE_CHECKING, Any, Mapping, Sequence
from uuid import UUID, uuid4

from .models import CompositeOutcome, Node, RetrievalResult
from .retrieval import finalize_retrieval, prepare_retrieval
from .service_utils import (
    as_uuid,
    clamp,
    coerce_outcome_signal,
    coerce_source_type,
    node_tier,
    session_key,
)
from .types import OutcomeSignalType, SourceType

if TYPE_CHECKING:
    from ._engine import _SynapticEngine


class RuntimeEngine:
    """Coordinates remember/recall/activate/feedback runtime flows."""

    def __init__(self, memory: _SynapticEngine) -> None:
        self._memory = memory

    async def remember(
        self,
        content: str,
        memory_type: str | None = None,
        external_id: str | None = None,
        source_type: SourceType | None = None,
        metadata: Mapping[str, Any] | None = None,
    ) -> Node:
        from .types import MemoryTier

        memory = self._memory
        normalized_content = str(content or "").strip()
        if not normalized_content:
            raise ValueError("content is required")

        embedding = await memory._embed(normalized_content)
        resolved_type = (
            str(memory_type)
            if memory_type is not None
            else memory._classify_memory_type(normalized_content, context=metadata)
        )

        node_id = memory._graph.create_node(
            {
                "content": normalized_content,
                "embedding": embedding,
                "memory_type": resolved_type,
                "memory_tier": MemoryTier.SHORT_TERM.value,
                "external_id": external_id,
                "source_type": getattr(source_type, "value", source_type),
            }
        )
        node_record = memory._backend.get_node(node_id) or {
            "id": node_id,
            "content": normalized_content,
            "embedding": embedding,
            "memory_type": resolved_type,
            "memory_tier": MemoryTier.SHORT_TERM.value,
        }

        memory._seed_cross_tier_provisional_edges(
            source_node_id=str(node_id),
            source_embedding=embedding,
        )

        stored = Node(
            id=as_uuid(node_record.get("id", node_id)),
            content=str(node_record.get("content", normalized_content)),
            embedding=[float(value) for value in node_record.get("embedding", embedding)],
            memory_type=str(node_record.get("memory_type", resolved_type)),
            memory_tier=str(node_record.get("memory_tier", MemoryTier.SHORT_TERM.value)),
            external_id=node_record.get("external_id", external_id),
            source_type=coerce_source_type(node_record.get("source_type", source_type)),
            activation_energy=float(node_record.get("activation_energy", 1.0)),
            access_count=int(node_record.get("access_count", 0)),
        )
        memory._observability.record_node_metadata_snapshot(node=stored)
        memory._adaptive_tuning.schedule_graduation_if_due(count_query=False)
        return stored

    async def recall(
        self,
        query: str,
        top_k: int | None = None,
        session_id: str | None = None,
    ) -> RetrievalResult:
        memory = self._memory

        session_id_key = session_key(session_id)
        resolved_top_k = memory._resolve_top_k(top_k)
        normalized_query = str(query or "").strip()
        if not normalized_query:
            raise ValueError("query is required")
        embedding = await memory._embed(normalized_query)
        prepared = prepare_retrieval(
            query=normalized_query,
            embedding=embedding,
            top_k=resolved_top_k,
            backend=memory._backend,
            graph_confidence=memory._graph.compute_graph_confidence(),
        )

        activation_start = time.perf_counter()
        activation = await memory._activate_from_fusion(
            fusion_results=prepared.fusion_results,
            session_id=session_id_key,
        )
        activation_latency_ms = max(0.0, (time.perf_counter() - activation_start) * 1000.0)
        execution = finalize_retrieval(
            prepared=prepared,
            activation=activation,
            activation_latency_ms=activation_latency_ms,
            load_nodes=memory._load_nodes,
        )
        result = execution.result

        observability = memory._observability
        observability.record_retrieval_telemetry(
            query_id=result.query_id,
            keyword_results=prepared.keyword_results,
            semantic_results=prepared.semantic_results,
            fusion_results=prepared.fusion_results,
            overlap_count=prepared.overlap_count,
            top_k=resolved_top_k,
            graph_confidence=prepared.graph_confidence,
            activation_weight_applied=result.activation_weight_applied,
            retrieval_latency_ms=prepared.retrieval_latency_ms,
        )
        observability.record_query_telemetry(
            query_id=result.query_id,
            session_id=session_id_key,
            query_type="retrieve",
            query_text=prepared.query_text,
            embedding=embedding,
        )
        observability.record_activation_telemetry(
            query_id=result.query_id,
            activation=execution.activation,
            activation_sourced_node_ids=[str(node_id) for node_id in result.activation_sourced_node_ids],
            fusion_only_node_ids=[str(node_id) for node_id in result.fusion_only_node_ids],
            short_term_node_ids=[str(node_id) for node_id in result.short_term_node_ids],
            long_term_node_ids=[str(node_id) for node_id in result.long_term_node_ids],
            activation_latency_ms=activation_latency_ms,
        )
        self._finalize_retrieval_state(
            result=result,
            session_key=session_id_key,
            activation_ranked_results=execution.activation.ranked_results,
            final_nodes=execution.nodes,
        )
        memory._adaptive_tuning.schedule_graduation_if_due(count_query=True)
        return result

    async def activate(
        self,
        node_ids: Sequence[UUID | str],
        initial_energy: float = 1.0,
        *,
        top_k: int | None = None,
        session_id: str | None = None,
    ) -> RetrievalResult:
        from .types import MemoryTier

        memory = self._memory
        if not node_ids:
            raise ValueError("node_ids must not be empty")

        session_id_key = session_key(session_id)
        resolved_top_k = memory._resolve_top_k(top_k)
        seed_energy = max(0.0, float(initial_energy))
        seed_nodes: list[tuple[Node, float]] = []
        for node_id in node_ids:
            node = memory._load_node(str(node_id))
            if node is None:
                continue
            seed_nodes.append((node, seed_energy))
        if not seed_nodes:
            raise KeyError("none of the provided node_ids were found")

        activation_start = time.perf_counter()
        activation = await memory._activation_engine.activate(
            seed_nodes=seed_nodes,
            graph=memory._graph,
            session_priming_set=memory._session_priming_set(session_id_key),
        )
        activation_latency_ms = max(0.0, (time.perf_counter() - activation_start) * 1000.0)

        ranked = list(activation.ranked_results[:resolved_top_k])
        ranked_node_ids = [node_id for node_id, _score in ranked]
        nodes = memory._load_nodes(ranked_node_ids)
        graph_confidence = memory._graph.compute_graph_confidence()
        seed_set = {str(node.id) for node, _ in seed_nodes}
        activation_sourced_ids = [
            node_id for node_id, _score in ranked if node_id not in seed_set
        ]

        short_term_node_ids = [node.id for node in nodes if node_tier(node) == MemoryTier.SHORT_TERM.value]
        long_term_node_ids = [node.id for node in nodes if node_tier(node) == MemoryTier.LONG_TERM.value]

        result = RetrievalResult(
            query_id=uuid4(),
            nodes=nodes,
            activation_path=list(activation.activation_path),
            seed_node_ids=[as_uuid(node_id) for node_id in activation.seed_node_ids],
            seed_nodes_contributed=[as_uuid(node_id) for node_id in activation.seed_nodes_contributed],
            seed_nodes_dead_ends=[as_uuid(node_id) for node_id in activation.seed_nodes_dead_ends],
            retrieval_latency_ms=0.0,
            activation_latency_ms=activation_latency_ms,
            graph_confidence=clamp(float(graph_confidence), lower=0.0, upper=1.0),
            activation_weight_applied=1.0 if ranked else 0.0,
            activation_sourced_node_ids=[as_uuid(node_id) for node_id in activation_sourced_ids],
            fusion_only_node_ids=[],
            short_term_node_ids=short_term_node_ids,
            long_term_node_ids=long_term_node_ids,
            cross_tier_traversals=max(0, int(activation.cross_tier_traversals)),
        )

        observability = memory._observability
        observability.record_activation_telemetry(
            query_id=result.query_id,
            activation=activation,
            activation_sourced_node_ids=[str(node_id) for node_id in result.activation_sourced_node_ids],
            fusion_only_node_ids=[],
            short_term_node_ids=[str(node_id) for node_id in short_term_node_ids],
            long_term_node_ids=[str(node_id) for node_id in long_term_node_ids],
            activation_latency_ms=activation_latency_ms,
        )
        observability.record_query_telemetry(
            query_id=result.query_id,
            session_id=session_id_key,
            query_type="activate",
            query_text=" ".join(sorted(str(node.id) for node, _energy in seed_nodes)),
            embedding=[float(seed_energy), float(len(seed_nodes))],
        )
        self._finalize_retrieval_state(
            result=result,
            session_key=session_id_key,
            activation_ranked_results=activation.ranked_results,
            final_nodes=nodes,
        )
        return result

    def _finalize_retrieval_state(
        self,
        *,
        result: RetrievalResult,
        session_key: str,
        activation_ranked_results: Sequence[tuple[str, float]],
        final_nodes: Sequence[Node],
    ) -> None:
        memory = self._memory
        observability = memory._observability
        memory._remember_retrieval(result=result, session_id=session_key)
        memory._update_retrieval_metrics(
            result=result,
            session_id=session_key,
            nodes_visited=len({str(node_id) for node_id, _score in activation_ranked_results}),
        )
        observability.record_session_telemetry(session_id=session_key)
        observability.record_node_metadata_for_retrieval(final_nodes=final_nodes)

    async def feedback(
        self,
        query_id: UUID,
        outcome: OutcomeSignalType | str,
        *,
        agent_response: str | None = None,
        user_next_message: str | None = None,
        dwell_time_ms: float | None = None,
        active_nodes: list[UUID] | None = None,
        corrected_nodes: list[UUID] | None = None,
        provider: str = "unknown",
    ) -> CompositeOutcome:
        memory = self._memory
        resolved_query_id = as_uuid(query_id)
        query_key = str(resolved_query_id)
        retrieval_result = memory._retrieval_history.get(query_key)
        if retrieval_result is None:
            retrieval_result = memory._build_retrieval_from_active_nodes(
                query_id=resolved_query_id,
                active_nodes=active_nodes or [],
            )

        explicit_outcome = coerce_outcome_signal(outcome)
        session_id_key = memory._query_sessions.get(query_key, session_key(None))
        previous_retrieval = memory._previous_retrieval_for_session(
            session_id=session_id_key,
            current_query_id=query_key,
        )
        orchestration = await memory._feedback_orchestrator.process_feedback(
            retrieval_result=retrieval_result,
            graph=memory._graph,
            query_id=resolved_query_id,
            explicit_outcome=explicit_outcome,
            agent_response=agent_response,
            user_next_message=user_next_message,
            dwell_time_ms=dwell_time_ms,
            previous_retrieval_result=previous_retrieval,
        )
        resolved_active_nodes = list(active_nodes or [node.id for node in retrieval_result.nodes])
        observability = memory._observability
        observability.record_outcome_telemetry(
            query_id=resolved_query_id,
            session_id=session_id_key,
            provider=str(provider or "unknown"),
            composite_outcome=orchestration.composite_outcome,
            active_nodes=resolved_active_nodes,
            corrected_nodes=corrected_nodes or [],
        )
        memory._update_feedback_metrics(
            session_id=session_id_key,
            composite_outcome=orchestration.composite_outcome,
            created_edges=len(orchestration.learning_update.created_edge_ids),
        )
        observability.record_session_telemetry(session_id=session_id_key)
        memory._adaptive_tuning.run_continuous_instance_optimization(
            composite_outcome=orchestration.composite_outcome,
            created_edges=len(orchestration.learning_update.created_edge_ids),
        )
        memory._adaptive_tuning.schedule_graduation_if_due(count_query=False)
        return orchestration.composite_outcome
