"""Graph-oriented runtime operations for the _SynapticEngine facade."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Sequence
from uuid import UUID

from .models import Node
from .service_utils import as_float, as_uuid, clamp, coerce_source_type, edge_payload, node_tier
from .types import ConnectionType, FormationTrigger, MemoryTier, MemoryType

if TYPE_CHECKING:
    from ._engine import _SynapticEngine


class GraphOps:
    """Encapsulates graph mutation and read helpers."""

    def __init__(self, memory: _SynapticEngine) -> None:
        self._memory = memory

    async def link(
        self,
        node_a_id: UUID | str,
        node_b_id: UUID | str,
        *,
        weight: float = 0.3,
        connection_type: ConnectionType | str = ConnectionType.EXCITATORY,
        formation_trigger: FormationTrigger | str = FormationTrigger.EXPLICIT,
        is_cross_tier: bool | None = None,
    ) -> dict[str, Any]:
        memory = self._memory
        node_a_key = str(node_a_id)
        node_b_key = str(node_b_id)
        if not node_a_key or not node_b_key:
            raise ValueError("node_a_id and node_b_id are required")
        if node_a_key == node_b_key:
            raise ValueError("node_a_id and node_b_id must be different")

        node_a = self.load_node(node_a_key)
        if node_a is None:
            raise KeyError(f"node not found: {node_a_key}")
        node_b = self.load_node(node_b_key)
        if node_b is None:
            raise KeyError(f"node not found: {node_b_key}")

        resolved_weight = clamp(float(weight), lower=0.0, upper=1.0)
        resolved_connection_type = str(
            getattr(connection_type, "value", connection_type) or ConnectionType.EXCITATORY.value
        )
        resolved_formation_trigger = str(
            getattr(formation_trigger, "value", formation_trigger) or FormationTrigger.EXPLICIT.value
        )
        resolved_is_cross_tier = (
            bool(is_cross_tier)
            if is_cross_tier is not None
            else node_tier(node_a) != node_tier(node_b)
        )

        existing = memory._graph.get_edge_between(node_a_key, node_b_key)
        if existing is not None:
            edge_id = str(existing.get("id", ""))
            if not edge_id:
                raise KeyError(f"edge not found for pair: {node_a_key}, {node_b_key}")
            updated_edge = {
                "id": edge_id,
                "node_a": str(existing.get("node_a", node_a_key)),
                "node_b": str(existing.get("node_b", node_b_key)),
                "weight": resolved_weight,
                "connection_type": resolved_connection_type,
                "formation_trigger": resolved_formation_trigger,
                "is_cross_tier": bool(resolved_is_cross_tier),
            }
            memory._graph.update_edge(
                edge_id,
                {
                    "weight": resolved_weight,
                    "connection_type": resolved_connection_type,
                    "formation_trigger": resolved_formation_trigger,
                    "is_cross_tier": bool(resolved_is_cross_tier),
                },
            )
            return edge_payload(updated_edge)

        edge_id = memory._graph.create_edge(
            {
                "node_a": node_a_key,
                "node_b": node_b_key,
                "weight": resolved_weight,
                "initial_weight": resolved_weight,
                "connection_type": resolved_connection_type,
                "formation_trigger": resolved_formation_trigger,
                "is_cross_tier": bool(resolved_is_cross_tier),
            }
        )
        edge = memory._graph.get_edge_between(node_a_key, node_b_key)
        if edge is not None:
            return edge_payload(edge)
        return {
            "id": edge_id,
            "node_a": node_a_key,
            "node_b": node_b_key,
            "weight": resolved_weight,
            "connection_type": resolved_connection_type,
            "formation_trigger": resolved_formation_trigger,
            "is_cross_tier": bool(resolved_is_cross_tier),
        }

    async def neighbors(
        self,
        node_id: UUID | str,
        *,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        memory = self._memory
        node_key = str(node_id)
        node = self.load_node(node_key)
        if node is None:
            raise KeyError(f"node not found: {node_key}")

        resolved_limit: int | None = None
        if limit is not None:
            resolved_limit = int(limit)
            if resolved_limit <= 0:
                raise ValueError("limit must be > 0")

        neighbors = memory._graph.get_neighbors(node_key)
        enriched: list[dict[str, Any]] = []
        for item in neighbors:
            target_node_id = str(item.get("target_node_id", ""))
            if not target_node_id:
                continue
            target_node = self.load_node(target_node_id)
            payload = {
                "target_node_id": target_node_id,
                "weight": as_float(item.get("weight", 0.0)),
                "connection_type": str(
                    item.get("connection_type", ConnectionType.EXCITATORY.value)
                ),
                "memory_tier": node_tier(target_node) if target_node is not None else None,
                "memory_type": (
                    str(target_node.memory_type) if target_node is not None else None
                ),
                "content": str(target_node.content) if target_node is not None else None,
            }
            enriched.append(payload)

        ranked = sorted(
            enriched,
            key=lambda item: (-as_float(item.get("weight", 0.0)), str(item.get("target_node_id", ""))),
        )
        if resolved_limit is not None:
            return ranked[:resolved_limit]
        return ranked

    async def delete(self, node_id: UUID) -> None:
        memory = self._memory
        node_key = str(node_id)
        memory._graph.delete_node(node_key)
        memory._provisional_edge_pairs = {
            pair for pair in memory._provisional_edge_pairs if node_key not in pair
        }

        stale_queries = [
            query_id
            for query_id, result in memory._retrieval_history.items()
            if any(str(node.id) == node_key for node in result.nodes)
        ]
        for query_id in stale_queries:
            memory._retrieval_history.pop(query_id, None)
            memory._query_sessions.pop(query_id, None)
        for session_queries in memory._session_query_ids.values():
            session_queries[:] = [query_id for query_id in session_queries if query_id not in stale_queries]

    async def stats(self) -> dict[str, float]:
        memory = self._memory
        snapshot = memory._graph.snapshot()
        total_hits_and_misses = memory._total_hits + memory._total_misses
        hit_rate = (
            float(memory._total_hits) / float(total_hits_and_misses)
            if total_hits_and_misses > 0
            else 0.0
        )
        avg_activation_steps = (
            memory._total_activation_steps / float(memory._total_queries)
            if memory._total_queries > 0
            else 0.0
        )
        return {
            "node_count": float(snapshot["node_count"]),
            "edge_count": float(snapshot["edge_count"]),
            "hit_rate": clamp(hit_rate, lower=0.0, upper=1.0),
            "avg_activation_steps": max(0.0, float(avg_activation_steps)),
        }

    def load_node(self, node_id: str) -> Node | None:
        memory = self._memory
        record = memory._backend.get_node(str(node_id))
        if not record:
            return None
        return Node(
            id=as_uuid(record.get("id", node_id)),
            content=str(record.get("content", "")),
            embedding=[float(value) for value in record.get("embedding", [])],
            memory_type=str(record.get("memory_type", MemoryType.CONTEXTUAL)),
            memory_tier=str(record.get("memory_tier", MemoryTier.SHORT_TERM.value)),
            external_id=record.get("external_id"),
            source_type=coerce_source_type(record.get("source_type")),
            activation_energy=float(record.get("activation_energy", 1.0)),
            access_count=int(record.get("access_count", 0)),
        )

    def load_nodes(self, ranked_node_ids: Sequence[str]) -> list[Node]:
        nodes: list[Node] = []
        for node_id in ranked_node_ids:
            node = self.load_node(node_id)
            if node is None:
                continue
            nodes.append(node)
        return nodes
