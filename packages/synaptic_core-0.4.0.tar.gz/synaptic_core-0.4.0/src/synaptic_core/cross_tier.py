"""Cross-tier edge seeding and candidate ranking helpers."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Mapping, Sequence

from .backends.sqlite import SQLiteBackend
from .types import ConnectionType, FormationTrigger, MemoryTier

if TYPE_CHECKING:
    from ._engine import _SynapticEngine


class CrossTier:
    """Handles cross-tier candidate evaluation and provisional edge creation."""

    def __init__(self, memory: _SynapticEngine) -> None:
        self._memory = memory

    def seed_provisional_edges(
        self,
        *,
        source_node_id: str,
        source_embedding: Sequence[float],
    ) -> None:
        memory = self._memory
        source_key = str(source_node_id)
        existing_pairs = {pair for pair in memory._provisional_edge_pairs if source_key in pair}
        pairs_complete = False
        if isinstance(memory._backend, SQLiteBackend):
            pairs_complete = True
        else:
            fetched_pairs, pairs_complete = self.existing_edge_pairs_for_node(source_node_id=source_node_id)
            existing_pairs.update(fetched_pairs)
        ranked_targets = self.rank_long_term_candidates(
            source_node_id=source_node_id,
            source_embedding=source_embedding,
        )
        seed_limit = (
            len(ranked_targets)
            if memory._cross_tier_seed_max_edges is None
            else min(len(ranked_targets), int(memory._cross_tier_seed_max_edges))
        )
        for target_node_id, _similarity in ranked_targets[:seed_limit]:
            created = self.create_edge_if_missing(
                source_node_id=source_node_id,
                target_node_id=target_node_id,
                existing_pairs=existing_pairs,
                existing_pairs_complete=pairs_complete,
            )
            if created:
                existing_pairs.add(_pair_key(source_node_id, target_node_id))

    def rank_long_term_candidates(
        self,
        *,
        source_node_id: str,
        source_embedding: Sequence[float],
    ) -> list[tuple[str, float]]:
        memory = self._memory
        raw_candidates: Sequence[Any]
        ranked_by_distance = False
        candidates_are_long_term = False
        semantic_search_long_term = getattr(memory._backend, "semantic_search_long_term", None)
        if callable(semantic_search_long_term):
            try:
                raw_candidates = semantic_search_long_term(
                    source_embedding,
                    top_k=memory._cross_tier_seed_top_k,
                    exclude_node_id=source_node_id,
                )
            except TypeError:
                raw_candidates = semantic_search_long_term(
                    source_embedding,
                    top_k=memory._cross_tier_seed_top_k,
                )
            candidates_are_long_term = True
        else:
            raw_candidates = memory._backend.semantic_search(
                source_embedding,
                top_k=memory._cross_tier_seed_top_k,
            )
            ranked_by_distance = _search_results_ranked_by_distance(raw_candidates)

        candidate_tier_lookup: dict[str, str] = {}
        if not candidates_are_long_term:
            candidate_tier_lookup = self.candidate_tier_lookup(
                candidate_node_ids=[
                    node_id
                    for node_id in [_search_result_node_id(candidate) for candidate in raw_candidates]
                    if node_id and node_id != source_node_id
                ]
            )
        candidate_best_similarity: dict[str, float] = {}
        similarity_floor = 0.0
        for candidate in raw_candidates:
            node_id = _search_result_node_id(candidate)
            if not node_id or node_id == source_node_id:
                continue

            if not candidates_are_long_term and candidate_tier_lookup.get(node_id) != MemoryTier.LONG_TERM.value:
                continue

            similarity = _search_result_similarity(candidate)
            if similarity <= memory._cross_tier_similarity_threshold:
                continue

            previous = candidate_best_similarity.get(node_id)
            if previous is None or similarity > previous:
                candidate_best_similarity[node_id] = similarity
                if candidate_best_similarity:
                    similarity_floor = min(candidate_best_similarity.values())

            if (
                ranked_by_distance
                and memory._cross_tier_seed_max_edges is not None
                and len(candidate_best_similarity) >= int(memory._cross_tier_seed_max_edges)
                and similarity < similarity_floor
            ):
                break

        ranked = sorted(
            candidate_best_similarity.items(),
            key=lambda item: (-item[1], item[0]),
        )
        if memory._cross_tier_seed_max_edges is not None:
            return ranked[: int(memory._cross_tier_seed_max_edges)]
        return ranked

    def create_edge_if_missing(
        self,
        *,
        source_node_id: str,
        target_node_id: str,
        existing_pairs: set[tuple[str, str]] | None = None,
        existing_pairs_complete: bool = False,
    ) -> bool:
        memory = self._memory
        pair = _pair_key(source_node_id, target_node_id)
        if existing_pairs is not None and pair in existing_pairs:
            return False
        if not existing_pairs_complete and self.edge_exists(pair=pair):
            return False
        node_a, node_b = pair
        try:
            memory._graph.create_edge(
                {
                    "node_a": node_a,
                    "node_b": node_b,
                    "weight": memory._cross_tier_initial_weight,
                    "initial_weight": memory._cross_tier_initial_weight,
                    "connection_type": ConnectionType.CROSS_TIER.value,
                    "formation_trigger": FormationTrigger.SEMANTIC_SIMILARITY.value,
                    "is_cross_tier": True,
                }
            )
        except Exception:
            return False

        memory._provisional_edge_pairs.add(pair)
        return True

    def candidate_tier_lookup(
        self,
        *,
        candidate_node_ids: Sequence[str],
    ) -> dict[str, str]:
        memory = self._memory
        unique_ids = sorted({str(node_id) for node_id in candidate_node_ids if str(node_id)})
        if not unique_ids:
            return {}

        if isinstance(memory._backend, SQLiteBackend):
            connect = getattr(memory._backend, "_connect", None)
            if callable(connect):
                placeholders = ", ".join("?" for _ in unique_ids)
                try:
                    with connect() as conn:
                        rows = conn.execute(
                            f"""
                            SELECT id, memory_tier
                            FROM nodes
                            WHERE id IN ({placeholders})
                            """,
                            tuple(unique_ids),
                        ).fetchall()
                    return {
                        str(row["id"]): str(row["memory_tier"])
                        for row in rows
                    }
                except Exception:
                    pass

        lookup: dict[str, str] = {}
        for node_id in unique_ids:
            node_record = memory._backend.get_node(node_id)
            if not node_record:
                continue
            lookup[node_id] = _memory_tier_value(node_record)
        return lookup

    def existing_edge_pairs_for_node(
        self,
        *,
        source_node_id: str,
    ) -> tuple[set[tuple[str, str]], bool]:
        memory = self._memory
        pairs = {pair for pair in memory._provisional_edge_pairs if str(source_node_id) in pair}
        source_key = str(source_node_id)

        if isinstance(memory._backend, SQLiteBackend):
            connect = getattr(memory._backend, "_connect", None)
            if callable(connect):
                try:
                    with connect() as conn:
                        rows = conn.execute(
                            """
                            SELECT node_a, node_b
                            FROM edges
                            WHERE node_a = ? OR node_b = ?
                            """,
                            (source_key, source_key),
                        ).fetchall()
                    for row in rows:
                        pairs.add(_pair_key(str(row["node_a"]), str(row["node_b"])))
                    return pairs, True
                except Exception:
                    pass

        for method_name in ("list_edges_for_node", "get_edges_for_node", "edges_for_node"):
            method = getattr(memory._backend, method_name, None)
            if not callable(method):
                continue
            try:
                raw_edges = method(source_key) or []
            except Exception:
                continue
            for edge in raw_edges:
                if not isinstance(edge, Mapping):
                    continue
                left = str(edge.get("node_a", ""))
                right = str(edge.get("node_b", ""))
                if not left or not right:
                    continue
                pairs.add(_pair_key(left, right))
            return pairs, True
        return pairs, False

    def edge_exists(self, *, pair: tuple[str, str]) -> bool:
        memory = self._memory
        if pair in memory._provisional_edge_pairs:
            return True
        node_a, node_b = pair

        has_edge_between = getattr(memory._backend, "has_edge_between", None)
        if callable(has_edge_between):
            try:
                if bool(has_edge_between(node_a, node_b)):
                    return True
            except Exception:
                pass

        for method_name in ("get_edge_between", "get_edge_by_nodes", "find_edge_between"):
            method = getattr(memory._backend, method_name, None)
            if not callable(method):
                continue
            try:
                existing = method(node_a, node_b)
            except Exception:
                continue
            if existing:
                return True
        return False


def _search_result_node_id(candidate: Any) -> str:
    if isinstance(candidate, Mapping):
        return str(candidate.get("node_id") or candidate.get("id") or "")
    if isinstance(candidate, (list, tuple)) and len(candidate) >= 1:
        return str(candidate[0] or "")
    return ""


def _search_result_similarity(candidate: Any) -> float:
    if isinstance(candidate, Mapping):
        if "similarity" in candidate:
            return _clamp(_as_float(candidate["similarity"]), lower=0.0, upper=1.0)
        metadata = candidate.get("metadata")
        if isinstance(metadata, Mapping):
            if "similarity" in metadata:
                return _clamp(_as_float(metadata["similarity"]), lower=0.0, upper=1.0)
            if "distance" in metadata:
                return _distance_to_similarity(_as_float(metadata["distance"]))
        score = _as_float(candidate.get("score", 0.0))
        return _distance_to_similarity(score)

    if isinstance(candidate, (list, tuple)) and len(candidate) >= 2:
        return _distance_to_similarity(_as_float(candidate[1]))
    return 0.0


def _distance_to_similarity(distance: float) -> float:
    value = max(0.0, float(distance))
    return 1.0 / (1.0 + value)


def _search_results_ranked_by_distance(candidates: Sequence[Any]) -> bool:
    last_score: float | None = None
    has_score = False
    for candidate in candidates:
        score: float | None = None
        if isinstance(candidate, Mapping):
            raw_score = candidate.get("score")
            if raw_score is not None:
                score = _as_float(raw_score)
        elif isinstance(candidate, (list, tuple)) and len(candidate) >= 2:
            score = _as_float(candidate[1])
        if score is None:
            continue
        has_score = True
        if last_score is not None and score < last_score:
            return False
        last_score = score
    return has_score


def _memory_tier_value(node_record: Mapping[str, Any]) -> str:
    tier = node_record.get("memory_tier", MemoryTier.SHORT_TERM.value)
    return str(getattr(tier, "value", tier))


def _pair_key(left: str, right: str) -> tuple[str, str]:
    return tuple(sorted([str(left), str(right)]))


def _clamp(value: float, *, lower: float, upper: float) -> float:
    return max(lower, min(upper, float(value)))


def _as_float(value: object) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0
