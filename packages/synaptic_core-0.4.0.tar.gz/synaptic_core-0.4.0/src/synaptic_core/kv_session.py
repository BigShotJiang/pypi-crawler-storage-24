"""KV and session payload operations for _SynapticEngine."""

from __future__ import annotations

from datetime import datetime, timedelta
from typing import TYPE_CHECKING, Any, Mapping, MutableMapping

from .kv_models import KeyValueItem, SESSION_PREFIX, SessionVersionConflictError
from .service_utils import (
    as_iso8601,
    coerce_metadata,
    keyword_score,
    mapping_get,
    mapping_set,
    metadata_matches,
    normalize_namespace,
    parse_iso8601,
    serialize_session_payload,
    utc_now,
)

if TYPE_CHECKING:
    from ._engine import _SynapticEngine


class KVSession:
    """Encapsulates key/value and session payload storage operations."""

    def __init__(self, memory: _SynapticEngine) -> None:
        self._memory = memory

    async def kv_set(
        self,
        key: str,
        value: Any,
        *,
        metadata: Mapping[str, Any] | None = None,
        ttl: int | None = None,
        namespace: str | None = None,
    ) -> None:
        memory = self._memory
        normalized_key = str(key or "").strip()
        if not normalized_key:
            raise ValueError("key is required")

        normalized_namespace = normalize_namespace(namespace)
        now = utc_now()
        expires_at = (
            as_iso8601(now + timedelta(seconds=max(0, int(ttl))))
            if ttl is not None
            else None
        )
        metadata_value = dict(metadata or {})

        if memory._sqlite_backend is not None:
            memory._sqlite_backend.upsert_kv_item(
                namespace=normalized_namespace,
                key=normalized_key,
                value=value,
                metadata=metadata_value,
                expires_at=expires_at,
            )
            return

        memory._kv_ephemeral_store[(normalized_namespace, normalized_key)] = {
            "namespace": normalized_namespace,
            "key": normalized_key,
            "value": value,
            "metadata": metadata_value,
            "created_at": as_iso8601(now),
            "updated_at": as_iso8601(now),
            "expires_at": expires_at,
        }

    async def kv_get(
        self,
        key: str,
        *,
        namespace: str | None = None,
    ) -> Any | None:
        memory = self._memory
        normalized_key = str(key or "").strip()
        if not normalized_key:
            return None

        item = self.kv_get_item(namespace=namespace, key=normalized_key)
        if item is None:
            return None
        return item["value"]

    async def kv_search(
        self,
        query: str,
        *,
        limit: int = 10,
        namespace: str | None = None,
        filters: Mapping[str, Any] | None = None,
    ) -> list[Any]:
        memory = self._memory
        normalized_query = str(query or "")
        resolved_limit = max(1, int(limit))
        normalized_namespace = normalize_namespace(namespace)
        filter_values = dict(filters or {})

        if memory._sqlite_backend is not None:
            rows = memory._sqlite_backend.search_kv_items(
                namespace=normalized_namespace,
                query=normalized_query,
                limit=resolved_limit,
            )
        else:
            rows = self.kv_search_ephemeral_items(
                namespace=normalized_namespace,
                query=normalized_query,
                limit=resolved_limit,
            )

        items: list[KeyValueItem] = []
        for row in rows:
            item_metadata = coerce_metadata(row.get("metadata"))
            if not metadata_matches(item_metadata, filter_values):
                continue
            items.append(
                KeyValueItem(
                    key=str(row["key"]),
                    value=row["value"],
                    metadata=item_metadata,
                    score=keyword_score(str(row["key"]), normalized_query),
                    namespace=str(row.get("namespace") or ""),
                    created_at=parse_iso8601(row.get("created_at")),
                    expires_at=parse_iso8601(row.get("expires_at")),
                )
            )
            if len(items) >= resolved_limit:
                break
        return items

    async def kv_delete(
        self,
        key: str,
        *,
        namespace: str | None = None,
    ) -> bool:
        memory = self._memory
        normalized_key = str(key or "").strip()
        if not normalized_key:
            return False

        normalized_namespace = normalize_namespace(namespace)
        if memory._sqlite_backend is not None:
            return memory._sqlite_backend.delete_kv_item(
                namespace=normalized_namespace,
                key=normalized_key,
            )
        return memory._kv_ephemeral_store.pop((normalized_namespace, normalized_key), None) is not None

    async def kv_clear(self, *, namespace: str | None = None) -> int:
        memory = self._memory
        if memory._sqlite_backend is not None:
            if namespace == "*":
                return memory._sqlite_backend.clear_kv_items(namespace="*")
            return memory._sqlite_backend.clear_kv_items(
                namespace=normalize_namespace(namespace),
            )

        if namespace == "*":
            count = len(memory._kv_ephemeral_store)
            memory._kv_ephemeral_store.clear()
            return count

        normalized_namespace = normalize_namespace(namespace)
        matching_keys = [
            item_key
            for item_key in memory._kv_ephemeral_store
            if item_key[0] == normalized_namespace
        ]
        for item_key in matching_keys:
            memory._kv_ephemeral_store.pop(item_key, None)
        return len(matching_keys)

    async def store_session(self, session: Any) -> Any:
        session_id = str(mapping_get(session, "id", "") or "").strip()
        if not session_id:
            raise ValueError("session.id is required")

        current_version = int(mapping_get(session, "version", 0) or 0)
        existing = await self.retrieve_session(session_id)
        if existing is not None:
            existing_version = int(mapping_get(existing, "version", 0) or 0)
            if existing_version != current_version:
                raise SessionVersionConflictError(
                    message=(
                        f"Session {session_id} was modified. "
                        f"Expected version {current_version}, got {existing_version}"
                    ),
                    expected_version=current_version,
                    actual_version=existing_version,
                )

        next_version = current_version + 1
        updated_at = datetime.utcnow()
        mapping_set(session, "version", next_version)
        mapping_set(session, "updated_at", updated_at)

        payload = serialize_session_payload(session)
        if isinstance(payload, MutableMapping):
            payload["version"] = next_version
            payload["updated_at"] = as_iso8601(updated_at)

        await self.kv_set(
            f"{SESSION_PREFIX}{session_id}",
            payload,
            metadata={"type": "session"},
        )
        return session

    async def retrieve_session(self, session_id: str) -> Any | None:
        memory = self._memory
        payload = await self.kv_get(f"{SESSION_PREFIX}{session_id}")
        if payload is None:
            return None

        if isinstance(payload, dict) and memory._session_deserializer is not None:
            return memory._session_deserializer(payload)
        return payload

    async def update_session(self, session: Any) -> Any:
        return await self.store_session(session)

    def kv_get_item(
        self,
        *,
        namespace: str | None,
        key: str,
    ) -> dict[str, Any] | None:
        memory = self._memory
        normalized_namespace = normalize_namespace(namespace)
        now = utc_now()

        if memory._sqlite_backend is not None:
            row = memory._sqlite_backend.get_kv_item(
                namespace=normalized_namespace,
                key=key,
            )
            if row is None:
                return None
            expires_at = parse_iso8601(row.get("expires_at"))
            if expires_at is not None and expires_at <= now:
                memory._sqlite_backend.delete_kv_item(
                    namespace=normalized_namespace,
                    key=key,
                )
                return None
            return row

        record_key = (normalized_namespace, key)
        row = memory._kv_ephemeral_store.get(record_key)
        if row is None:
            return None
        expires_at = parse_iso8601(row.get("expires_at"))
        if expires_at is not None and expires_at <= now:
            memory._kv_ephemeral_store.pop(record_key, None)
            return None
        return dict(row)

    def kv_search_ephemeral_items(
        self,
        *,
        namespace: str,
        query: str,
        limit: int,
    ) -> list[dict[str, Any]]:
        memory = self._memory
        query_lower = str(query or "").lower()
        now = utc_now()
        rows: list[dict[str, Any]] = []
        expired_keys: list[tuple[str, str]] = []
        for item_key, row in memory._kv_ephemeral_store.items():
            if item_key[0] != namespace:
                continue
            expires_at = parse_iso8601(row.get("expires_at"))
            if expires_at is not None and expires_at <= now:
                expired_keys.append(item_key)
                continue
            if query_lower not in item_key[1].lower():
                continue
            rows.append(dict(row))
            if len(rows) >= limit:
                break

        for item_key in expired_keys:
            memory._kv_ephemeral_store.pop(item_key, None)
        return rows
