"""Canonical API surface for the async Synaptic client."""

from __future__ import annotations

from collections.abc import Callable, Sequence
from typing import Any, TypedDict
from uuid import UUID

from ._engine import _SynapticEngine
from .errors import SynapticError
from .kv_models import SessionVersionConflictError
from .models import CompositeOutcome, Node, RetrievalResult
from .types import ConnectionType, FormationTrigger, OutcomeSignalType, SourceType


class SynapticRuntimeOptions(TypedDict, total=False):
    """Explicit runtime options accepted by Synaptic constructor."""

    backend: Any
    classifier: Any
    cross_tier_similarity_threshold: float
    cross_tier_initial_weight: float
    cross_tier_seed_top_k: int
    cross_tier_seed_max_edges: int | None
    top_k_retrieval: int
    top_k_activation_seeds: int
    telemetry_collector: Any
    activation_engine: Any
    outcome_detector: Any
    connection_learner: Any
    deployment_id: str
    weekly_digest_cache_ttl_seconds: int
    graph_confidence_refresh_query_interval: int
    graduation_engine: Any
    graduation_scheduler_enabled: bool
    graduation_check_interval_queries: int
    graduation_check_interval_seconds: float
    graduation_min_access_count: int
    graduation_min_positive_outcome_ratio: float
    graduation_min_age_hours: float
    graduation_min_reinforced_edges: int
    graduation_reinforced_edge_weight_threshold: float
    graduation_edge_transfer_threshold: float
    instance_optimizer: Any
    instance_optimizer_enabled: bool
    instance_optimizer_step_size: float
    instance_optimizer_min_sample_count: int
    instance_optimizer_update_interval: int
    session_deserializer: Callable[[dict[str, Any]], Any]


_SUPPORTED_RUNTIME_OPTIONS = frozenset(SynapticRuntimeOptions.__annotations__.keys())
_LEGACY_RUNTIME_OPTION_ALIASES: dict[str, str] = {
    "retrieval_top_k": "top_k_retrieval",
    "activation_seed_top_k": "top_k_activation_seeds",
    "weekly_digest_ttl_seconds": "weekly_digest_cache_ttl_seconds",
    "graph_confidence_refresh_interval": "graph_confidence_refresh_query_interval",
}


class Synaptic:
    """Canonical async Synaptic client."""

    def __init__(
        self,
        *,
        db_path: str = "synaptic.db",
        embedding_fn: Callable[[str], Sequence[float] | Any] | None = None,
        **engine_options: Any,
    ) -> None:
        normalized_options = _normalize_runtime_options(engine_options)
        try:
            self._engine = _SynapticEngine(
                db_path=db_path,
                embedding_fn=embedding_fn,
                **normalized_options,
            )
        except (TypeError, ValueError) as exc:
            provided = ", ".join(sorted(normalized_options))
            raise SynapticError(
                code="INVALID_CONSTRUCTOR_OPTIONS",
                message=(
                    "Invalid Synaptic constructor runtime option values"
                    f" (provided: {provided or 'none'}): {exc}"
                ),
                hint=_constructor_options_hint(),
            ) from exc

    def session(self, session_id: str) -> Session:
        """Create a session-scoped async client helper."""

        return Session(client=self, session_id=session_id)

    async def remember(
        self,
        content: str,
        *,
        session_id: str = "default",
        memory_type: str | None = None,
        external_id: str | None = None,
        source_type: SourceType | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Node:
        payload = dict(metadata or {})
        payload.setdefault("session_id", str(session_id or "default"))

        return await self._guard(
            self._engine.remember(
                content=content,
                memory_type=memory_type,
                external_id=external_id,
                source_type=source_type,
                metadata=payload,
            )
        )

    async def recall(
        self,
        query: str,
        *,
        session_id: str = "default",
        top_k: int | None = None,
    ) -> RetrievalResult:
        return await self._guard(
            self._engine.recall(
                query=query,
                top_k=top_k,
                session_id=session_id,
            )
        )

    async def feedback(
        self,
        query_id: UUID | str,
        outcome: OutcomeSignalType | str,
        *,
        session_id: str | None = None,
        agent_response: str | None = None,
        user_next_message: str | None = None,
        dwell_time_ms: float | None = None,
        active_nodes: list[UUID] | None = None,
        corrected_nodes: list[UUID] | None = None,
        provider: str = "unknown",
    ) -> CompositeOutcome:
        if session_id is not None:
            expected = str(session_id or "default")
            known = self._engine.query_session_id(query_id)
            if known is not None and str(known) != expected:
                raise SynapticError(
                    code="SESSION_MISMATCH",
                    message=(
                        f"query_id {query_id} belongs to session '{known}', not '{expected}'"
                    ),
                    hint="Use client.session(<session_id>).feedback(...) with the matching session.",
                )

        return await self._guard(
            self._engine.feedback(
                query_id=UUID(str(query_id)) if not isinstance(query_id, UUID) else query_id,
                outcome=outcome,
                agent_response=agent_response,
                user_next_message=user_next_message,
                dwell_time_ms=dwell_time_ms,
                active_nodes=active_nodes,
                corrected_nodes=corrected_nodes,
                provider=provider,
            )
        )

    async def connect(
        self,
        node_a_id: UUID | str,
        node_b_id: UUID | str,
        *,
        weight: float = 0.3,
        connection_type: ConnectionType | str = ConnectionType.EXCITATORY,
        formation_trigger: FormationTrigger | str = FormationTrigger.EXPLICIT,
        is_cross_tier: bool | None = None,
    ) -> dict[str, Any]:
        return await self._guard(
            self._engine.connect(
                node_a_id=node_a_id,
                node_b_id=node_b_id,
                weight=weight,
                connection_type=connection_type,
                formation_trigger=formation_trigger,
                is_cross_tier=is_cross_tier,
            )
        )

    async def related(
        self,
        node_id: UUID | str,
        *,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        return await self._guard(self._engine.related(node_id=node_id, limit=limit))

    async def set(
        self,
        key: str,
        value: Any,
        *,
        namespace: str | None = None,
        metadata: dict[str, Any] | None = None,
        ttl: int | None = None,
    ) -> None:
        await self._guard(
            self._engine.set(
                key=key,
                value=value,
                namespace=namespace,
                metadata=metadata,
                ttl=ttl,
            )
        )

    async def get(self, key: str, *, namespace: str | None = None) -> Any | None:
        return await self._guard(self._engine.get(key=key, namespace=namespace))

    async def delete(self, key: str, *, namespace: str | None = None) -> bool:
        return await self._guard(self._engine.delete(key=key, namespace=namespace))

    async def clear(self, *, namespace: str | None = None) -> int:
        return await self._guard(self._engine.clear(namespace=namespace))

    async def store_session(self, session: Any) -> Any:
        return await self._guard(self._engine.store_session(session))

    async def retrieve_session(self, session_id: str) -> Any | None:
        return await self._guard(self._engine.retrieve_session(session_id))

    async def update_session(self, session: Any) -> Any:
        return await self._guard(self._engine.update_session(session))

    async def find(
        self,
        query: str,
        *,
        namespace: str | None = None,
        limit: int = 10,
        filters: dict[str, Any] | None = None,
    ) -> list[dict[str, Any]]:
        rows = await self._guard(
            self._engine.find(
                query=query,
                namespace=namespace,
                limit=limit,
                filters=filters,
            )
        )
        return [
            {
                "key": item.key,
                "value": item.value,
                "metadata": dict(item.metadata),
                "score": item.score,
                "namespace": item.namespace,
                "created_at": item.created_at,
                "expires_at": item.expires_at,
            }
            for item in rows
        ]

    async def stats(self) -> dict[str, Any]:
        return await self._guard(self._engine.stats())

    async def graph_status(self) -> dict[str, Any]:
        return await self._guard(self._engine.graph_status())

    async def queries_recent(
        self,
        *,
        session_id: str | None = None,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        return await self._guard(
            self._engine.queries_recent(
                session_id=session_id,
                limit=limit,
            )
        )

    async def sessions_recent(self, *, limit: int = 20) -> list[dict[str, Any]]:
        return await self._guard(self._engine.sessions_recent(limit=limit))

    async def outcomes_recent(
        self,
        *,
        session_id: str | None = None,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        return await self._guard(
            self._engine.outcomes_recent(
                session_id=session_id,
                limit=limit,
            )
        )

    async def session_summary(self, session_id: str) -> dict[str, Any]:
        return await self._guard(self._engine.session_summary(session_id))

    async def weekly_digest(self, *, force_refresh: bool = False) -> dict[str, Any]:
        return await self._guard(self._engine.weekly_digest(force_refresh=force_refresh))

    async def _guard(self, operation: Any) -> Any:
        try:
            return await operation
        except SynapticError:
            raise
        except SessionVersionConflictError as exc:
            raise SynapticError(
                code="SESSION_CONFLICT",
                message=exc.message,
                hint="Reload the latest session payload and retry the write.",
            ) from exc
        except KeyError as exc:
            raise SynapticError(
                code="NOT_FOUND",
                message=_clean_message(exc),
                hint="Verify identifiers exist before retrying the operation.",
            ) from exc
        except ValueError as exc:
            raise SynapticError(
                code="INVALID_ARGUMENT",
                message=str(exc),
                hint="Correct the request parameters and retry.",
            ) from exc
        except TypeError as exc:
            raise SynapticError(
                code="TYPE_ERROR",
                message=str(exc),
                hint="Check argument and embedding return types.",
            ) from exc
        except RuntimeError as exc:
            message = str(exc)
            if "embedding_fn" in message:
                raise SynapticError(
                    code="EMBEDDING_REQUIRED",
                    message=message,
                    hint="Provide embedding_fn when creating Synaptic.",
                ) from exc
            raise SynapticError(
                code="RUNTIME_ERROR",
                message=message,
                hint="Inspect runtime dependencies and retry.",
            ) from exc
        except Exception as exc:  # pragma: no cover - defensive guard
            raise SynapticError(
                code="INTERNAL_ERROR",
                message=str(exc),
                hint="Inspect logs and retry; file an issue if this persists.",
            ) from exc


class Session:
    """Session-first async helper surface."""

    def __init__(self, *, client: Synaptic, session_id: str) -> None:
        self._client = client
        self._session_id = str(session_id or "default")

    @property
    def session_id(self) -> str:
        return self._session_id

    async def remember(
        self,
        content: str,
        *,
        memory_type: str | None = None,
        external_id: str | None = None,
        source_type: SourceType | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> Node:
        return await self._client.remember(
            content=content,
            session_id=self._session_id,
            memory_type=memory_type,
            external_id=external_id,
            source_type=source_type,
            metadata=metadata,
        )

    async def recall(self, query: str, *, top_k: int | None = None) -> RetrievalResult:
        return await self._client.recall(query=query, session_id=self._session_id, top_k=top_k)

    async def feedback(
        self,
        query_id: UUID | str,
        outcome: OutcomeSignalType | str,
        *,
        agent_response: str | None = None,
        user_next_message: str | None = None,
        dwell_time_ms: float | None = None,
        active_nodes: list[UUID] | None = None,
        corrected_nodes: list[UUID] | None = None,
        provider: str = "unknown",
    ) -> CompositeOutcome:
        return await self._client.feedback(
            query_id=query_id,
            outcome=outcome,
            session_id=self._session_id,
            agent_response=agent_response,
            user_next_message=user_next_message,
            dwell_time_ms=dwell_time_ms,
            active_nodes=active_nodes,
            corrected_nodes=corrected_nodes,
            provider=provider,
        )

    async def summary(self) -> dict[str, Any]:
        return await self._client.session_summary(self._session_id)

    async def queries_recent(self, *, limit: int = 20) -> list[dict[str, Any]]:
        return await self._client.queries_recent(session_id=self._session_id, limit=limit)

    async def outcomes_recent(self, *, limit: int = 20) -> list[dict[str, Any]]:
        return await self._client.outcomes_recent(session_id=self._session_id, limit=limit)


def _clean_message(exc: KeyError) -> str:
    raw = str(exc)
    return raw.strip('"').strip("'")


def _normalize_runtime_options(engine_options: dict[str, Any]) -> dict[str, Any]:
    normalized: dict[str, Any] = {}
    source_name_by_canonical: dict[str, str] = {}

    for provided_name, value in engine_options.items():
        canonical_name = _LEGACY_RUNTIME_OPTION_ALIASES.get(provided_name, provided_name)
        prior_name = source_name_by_canonical.get(canonical_name)
        if prior_name is not None:
            raise SynapticError(
                code="INVALID_CONSTRUCTOR_OPTIONS",
                message=(
                    f"Conflicting Synaptic constructor options: '{prior_name}' and "
                    f"'{provided_name}' both map to '{canonical_name}'."
                ),
                hint="Pass only one of the alias/canonical option names.",
            )
        normalized[canonical_name] = value
        source_name_by_canonical[canonical_name] = provided_name

    unknown_options = sorted(
        option_name
        for option_name in normalized
        if option_name not in _SUPPORTED_RUNTIME_OPTIONS
    )
    if unknown_options:
        raise SynapticError(
            code="INVALID_CONSTRUCTOR_OPTIONS",
            message=(
                "Unknown Synaptic constructor runtime option(s): "
                f"{', '.join(unknown_options)}"
            ),
            hint=_constructor_options_hint(),
        )
    return normalized


def _constructor_options_hint() -> str:
    aliases = ", ".join(
        f"{legacy}->{canonical}"
        for legacy, canonical in sorted(_LEGACY_RUNTIME_OPTION_ALIASES.items())
    )
    options = ", ".join(sorted(_SUPPORTED_RUNTIME_OPTIONS))
    return f"Supported runtime options: {options}. Legacy aliases: {aliases}."


__all__ = [
    "Session",
    "Synaptic",
    "SynapticRuntimeOptions",
]
