-- Canonical SQLite schema for Synaptic MVP Phase 1.

-- Memory nodes
CREATE TABLE IF NOT EXISTS nodes (
    id TEXT PRIMARY KEY,
    content TEXT NOT NULL,
    embedding BLOB NOT NULL,
    memory_type TEXT NOT NULL,
    memory_tier TEXT NOT NULL DEFAULT 'short_term',
    created_at TEXT NOT NULL,
    last_accessed_at TEXT NOT NULL,
    access_count INTEGER DEFAULT 0,
    activation_energy REAL DEFAULT 1.0,
    staleness_signals INTEGER DEFAULT 0,
    graduated_at TEXT,
    graduation_access_count INTEGER DEFAULT 0,
    external_id TEXT,
    source_type TEXT,
    consolidated_from TEXT DEFAULT '[]',
    consolidation_candidate INTEGER DEFAULT 0
);

-- FTS5 virtual table for BM25 keyword search
CREATE VIRTUAL TABLE IF NOT EXISTS nodes_fts USING fts5(
    content,
    content='nodes',
    content_rowid='rowid'
);

-- Triggers to keep FTS5 in sync
CREATE TRIGGER IF NOT EXISTS nodes_ai AFTER INSERT ON nodes BEGIN
    INSERT INTO nodes_fts(rowid, content) VALUES (new.rowid, new.content);
END;

CREATE TRIGGER IF NOT EXISTS nodes_ad AFTER DELETE ON nodes BEGIN
    INSERT INTO nodes_fts(nodes_fts, rowid, content) VALUES ('delete', old.rowid, old.content);
END;

CREATE TRIGGER IF NOT EXISTS nodes_au AFTER UPDATE ON nodes BEGIN
    INSERT INTO nodes_fts(nodes_fts, rowid, content) VALUES ('delete', old.rowid, old.content);
    INSERT INTO nodes_fts(rowid, content) VALUES (new.rowid, new.content);
END;

-- sqlite-vec virtual table for semantic search (requires vec extension)
CREATE VIRTUAL TABLE IF NOT EXISTS nodes_vec USING vec0(
    node_id TEXT,
    embedding float[EMBEDDING_DIM]
);

-- Memory edges
CREATE TABLE IF NOT EXISTS edges (
    id TEXT PRIMARY KEY,
    node_a TEXT NOT NULL REFERENCES nodes(id),
    node_b TEXT NOT NULL REFERENCES nodes(id),
    weight REAL DEFAULT 0.3,
    connection_type TEXT DEFAULT 'excitatory',
    formation_trigger TEXT NOT NULL,
    activation_count INTEGER DEFAULT 0,
    interference_score REAL DEFAULT 0.0,
    formed_at TEXT NOT NULL,
    last_reinforced_at TEXT NOT NULL,
    initial_weight REAL NOT NULL,
    is_cross_tier INTEGER DEFAULT 0,
    pruned_at_graduation INTEGER DEFAULT 0,
    UNIQUE(node_a, node_b)
);

CREATE INDEX IF NOT EXISTS idx_edges_node_a ON edges(node_a);
CREATE INDEX IF NOT EXISTS idx_edges_node_b ON edges(node_b);
CREATE INDEX IF NOT EXISTS idx_edges_cross_tier ON edges(is_cross_tier) WHERE is_cross_tier = 1;
CREATE INDEX IF NOT EXISTS idx_nodes_tier ON nodes(memory_tier);

-- Telemetry tables (collection only in MVP)
CREATE TABLE IF NOT EXISTS telemetry_queries (
    query_id TEXT PRIMARY KEY,
    session_id TEXT NOT NULL,
    deployment_id TEXT NOT NULL,
    timestamp TEXT NOT NULL,
    query_embedding_hash TEXT NOT NULL,
    query_type TEXT NOT NULL,
    query_length_tokens INTEGER
);

CREATE TABLE IF NOT EXISTS telemetry_retrievals (
    query_id TEXT PRIMARY KEY,
    semantic_candidate_count INTEGER,
    keyword_candidate_count INTEGER,
    overlap_count INTEGER,
    fusion_top_k INTEGER,
    fusion_scores TEXT,
    graph_confidence REAL,
    activation_weight_applied REAL,
    retrieval_latency_ms REAL
);

CREATE TABLE IF NOT EXISTS telemetry_activations (
    query_id TEXT PRIMARY KEY,
    seed_node_ids TEXT,
    seed_energies TEXT,
    activation_steps INTEGER,
    nodes_visited INTEGER,
    nodes_above_threshold INTEGER,
    final_node_ids TEXT,
    activation_sourced_node_ids TEXT,
    fusion_only_node_ids TEXT,
    short_term_node_ids TEXT,
    long_term_node_ids TEXT,
    cross_tier_traversals INTEGER DEFAULT 0,
    activation_path TEXT,
    seed_nodes_contributed TEXT,
    seed_nodes_dead_ends TEXT,
    inhibitory_suppressions TEXT,
    priming_source_session TEXT,
    decay_rate_used REAL,
    threshold_used REAL,
    activation_latency_ms REAL
);

CREATE TABLE IF NOT EXISTS telemetry_node_metadata (
    node_id TEXT PRIMARY KEY,
    deployment_id TEXT NOT NULL,
    created_at TEXT NOT NULL,
    memory_type TEXT NOT NULL,
    memory_tier TEXT NOT NULL,
    connection_count INTEGER DEFAULT 0,
    times_activated INTEGER DEFAULT 0,
    times_in_final_set INTEGER DEFAULT 0,
    age_days REAL DEFAULT 0,
    last_activated_at TEXT,
    staleness_signals INTEGER DEFAULT 0,
    graduated_at TEXT,
    consolidation_candidate INTEGER DEFAULT 0,
    consolidated_from TEXT DEFAULT '[]'
);

CREATE TABLE IF NOT EXISTS telemetry_connections (
    connection_id TEXT PRIMARY KEY,
    node_a TEXT NOT NULL,
    node_b TEXT NOT NULL,
    formed_at TEXT NOT NULL,
    formation_trigger TEXT NOT NULL,
    connection_type TEXT NOT NULL,
    is_cross_tier INTEGER DEFAULT 0,
    initial_weight REAL NOT NULL,
    current_weight REAL NOT NULL,
    activation_count INTEGER DEFAULT 0,
    interference_score REAL DEFAULT 0.0,
    oscillation_detected INTEGER DEFAULT 0,
    last_reinforced_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS telemetry_outcomes (
    id TEXT PRIMARY KEY,
    query_id TEXT NOT NULL,
    session_id TEXT NOT NULL,
    composite_score REAL,
    composite_confidence REAL,
    learning_gated INTEGER DEFAULT 0,
    oscillation_detected INTEGER DEFAULT 0,
    signals TEXT,
    provider TEXT NOT NULL,
    active_nodes_during_outcome TEXT,
    corrected_nodes TEXT,
    latency_to_outcome_ms REAL
);

CREATE TABLE IF NOT EXISTS telemetry_sessions (
    session_id TEXT PRIMARY KEY,
    deployment_id TEXT NOT NULL,
    started_at TEXT NOT NULL,
    ended_at TEXT,
    query_count INTEGER DEFAULT 0,
    memory_hits INTEGER DEFAULT 0,
    memory_misses INTEGER DEFAULT 0,
    avg_activation_steps REAL,
    avg_nodes_visited REAL,
    new_connections_formed INTEGER DEFAULT 0,
    new_nodes_created INTEGER DEFAULT 0,
    short_term_activations INTEGER DEFAULT 0,
    long_term_activations INTEGER DEFAULT 0,
    cross_tier_traversals INTEGER DEFAULT 0,
    activation_sourced_results INTEGER DEFAULT 0,
    learning_gated_outcomes INTEGER DEFAULT 0,
    oscillating_edges_detected INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS telemetry_graduations (
    graduation_id TEXT PRIMARY KEY,
    node_id TEXT NOT NULL,
    deployment_id TEXT NOT NULL,
    graduated_at TEXT NOT NULL,
    access_count_at_graduation INTEGER NOT NULL,
    positive_outcome_ratio REAL NOT NULL,
    age_hours_at_graduation REAL NOT NULL,
    edges_transferred INTEGER NOT NULL,
    edges_pruned INTEGER NOT NULL,
    graduation_trigger TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS telemetry_graph_health (
    snapshot_id TEXT PRIMARY KEY,
    deployment_id TEXT NOT NULL,
    snapshot_at TEXT NOT NULL,
    total_nodes INTEGER,
    short_term_nodes INTEGER,
    long_term_nodes INTEGER,
    total_edges INTEGER,
    cross_tier_edges INTEGER,
    avg_edge_weight REAL,
    graph_confidence REAL,
    converging_edges INTEGER,
    oscillating_edges INTEGER,
    graduation_rate_7d REAL
);

CREATE INDEX IF NOT EXISTS idx_telemetry_queries_timestamp ON telemetry_queries(timestamp);
CREATE INDEX IF NOT EXISTS idx_telemetry_sessions_started_at ON telemetry_sessions(started_at);
CREATE INDEX IF NOT EXISTS idx_telemetry_connections_last_reinforced_at
    ON telemetry_connections(last_reinforced_at);
CREATE INDEX IF NOT EXISTS idx_telemetry_graduations_graduated_at
    ON telemetry_graduations(graduated_at);
CREATE INDEX IF NOT EXISTS idx_telemetry_graph_health_snapshot_at
    ON telemetry_graph_health(snapshot_at);

-- Retention rollups for high-volume telemetry tables.
CREATE TABLE IF NOT EXISTS telemetry_daily_rollups (
    bucket_date TEXT NOT NULL,
    source_table TEXT NOT NULL,
    deployment_id TEXT NOT NULL,
    event_count INTEGER NOT NULL DEFAULT 0,
    metric_sums_json TEXT NOT NULL DEFAULT '{}',
    metric_counts_json TEXT NOT NULL DEFAULT '{}',
    first_event_at TEXT,
    last_event_at TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    PRIMARY KEY (bucket_date, source_table, deployment_id)
);

CREATE INDEX IF NOT EXISTS idx_telemetry_daily_rollups_source_bucket
    ON telemetry_daily_rollups(source_table, bucket_date);

CREATE TABLE IF NOT EXISTS telemetry_weekly_rollups (
    week_start_date TEXT NOT NULL,
    source_table TEXT NOT NULL,
    deployment_id TEXT NOT NULL,
    event_count INTEGER NOT NULL DEFAULT 0,
    metric_sums_json TEXT NOT NULL DEFAULT '{}',
    metric_counts_json TEXT NOT NULL DEFAULT '{}',
    first_event_at TEXT,
    last_event_at TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    PRIMARY KEY (week_start_date, source_table, deployment_id)
);

CREATE INDEX IF NOT EXISTS idx_telemetry_weekly_rollups_source_bucket
    ON telemetry_weekly_rollups(source_table, week_start_date);

-- Federated-learning export outbox (append-only) + export cursor state.
CREATE TABLE IF NOT EXISTS telemetry_federation_outbox (
    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_type TEXT NOT NULL,
    deployment_id TEXT NOT NULL,
    occurred_at TEXT NOT NULL,
    payload_json TEXT NOT NULL,
    schema_version INTEGER NOT NULL DEFAULT 1,
    exported_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_telemetry_federation_outbox_event_type
    ON telemetry_federation_outbox(event_type, occurred_at);
CREATE INDEX IF NOT EXISTS idx_telemetry_federation_outbox_exported_at
    ON telemetry_federation_outbox(exported_at, event_id);

CREATE TABLE IF NOT EXISTS telemetry_export_state (
    export_target TEXT PRIMARY KEY,
    last_event_id INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL
);

-- Durable observability aggregates (Phase 7 hardening)
CREATE TABLE IF NOT EXISTS observability_session_aggregates (
    session_id TEXT PRIMARY KEY,
    query_count INTEGER NOT NULL DEFAULT 0,
    memory_hits INTEGER NOT NULL DEFAULT 0,
    memory_misses INTEGER NOT NULL DEFAULT 0,
    activation_sourced_results INTEGER NOT NULL DEFAULT 0,
    new_connections_formed INTEGER NOT NULL DEFAULT 0,
    learning_gated_outcomes INTEGER NOT NULL DEFAULT 0,
    cross_tier_traversals INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS observability_weekly_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    occurred_at TEXT NOT NULL,
    query_count INTEGER NOT NULL DEFAULT 0,
    activation_sourced_results INTEGER NOT NULL DEFAULT 0,
    new_connections_formed INTEGER NOT NULL DEFAULT 0,
    learning_gated_outcomes INTEGER NOT NULL DEFAULT 0,
    cross_tier_traversals INTEGER NOT NULL DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_observability_weekly_events_occurred_at
    ON observability_weekly_events(occurred_at);

-- Key/value + session payload storage.
CREATE TABLE IF NOT EXISTS kv_store (
    namespace TEXT NOT NULL DEFAULT '',
    key TEXT NOT NULL,
    value TEXT NOT NULL,
    metadata TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    expires_at TEXT,
    PRIMARY KEY (namespace, key)
);

CREATE INDEX IF NOT EXISTS idx_kv_store_key ON kv_store(key);
CREATE INDEX IF NOT EXISTS idx_kv_store_expires_at ON kv_store(expires_at);
