"""SQLite backend implementation for Synaptic persistence."""

from __future__ import annotations

from array import array
from datetime import datetime, timezone
from importlib import resources
import json
import re
import sqlite3
from pathlib import Path
from typing import Any, Mapping, Sequence
from uuid import uuid4

from .base import EdgeRecord, MemoryBackend, NodeRecord, SearchResult

_SQLITE_BUSY_TIMEOUT_MS = 15_000
_SQLITE_CONNECT_TIMEOUT_SECONDS = _SQLITE_BUSY_TIMEOUT_MS / 1000.0


class SQLiteBackend(MemoryBackend):
    """SQLite backend implementation for schema, CRUD, and search hooks."""

    _NODES_VEC_PATTERN = re.compile(
        r"CREATE VIRTUAL TABLE IF NOT EXISTS nodes_vec USING vec0\([\s\S]*?\);",
        flags=re.IGNORECASE,
    )
    _KEYWORD_FALLBACK_TOKEN_PATTERN = re.compile(r"[A-Za-z0-9]+")

    def __init__(self, db_path: str | Path, *, embedding_dim: int = 1536) -> None:
        self._db_path = str(db_path)
        self._embedding_dim = embedding_dim
        self._schema_path = Path(__file__).with_name("schema.sql")
        self._schema_resource = resources.files("synaptic_core.backends").joinpath("schema.sql")
        self._vec_extension_loaded: bool | None = None
        Path(self._db_path).parent.mkdir(parents=True, exist_ok=True)

    @property
    def vec_extension_loaded(self) -> bool | None:
        """Return whether sqlite-vec virtual table creation succeeded."""
        return self._vec_extension_loaded

    def init_schema(self) -> None:
        schema_sql = self._load_schema_sql().replace(
            "EMBEDDING_DIM",
            str(self._embedding_dim),
        )
        match = self._NODES_VEC_PATTERN.search(schema_sql)
        if not match:
            raise RuntimeError("schema.sql missing nodes_vec virtual table definition")

        base_schema = schema_sql[: match.start()] + schema_sql[match.end() :]
        vec_statement = match.group(0)

        with self._connect() as conn:
            conn.executescript(base_schema)
            self._ensure_nodes_vec_table(conn, vec_statement)
            conn.commit()

    def create_node(self, node: NodeRecord) -> str:
        content = str(node.get("content") or "").strip()
        if not content:
            raise ValueError("node.content is required")

        embedding = self._normalize_embedding(node.get("embedding"))
        if not embedding:
            raise ValueError("node.embedding is required")

        node_id = str(node.get("id") or uuid4())
        memory_type = str(node.get("memory_type") or "contextual")
        memory_tier = str(node.get("memory_tier") or "short_term")
        access_count = int(node.get("access_count", 0))
        activation_energy = float(node.get("activation_energy", 1.0))
        external_id = node.get("external_id")
        source_type = node.get("source_type")
        timestamp = self._utc_now()
        embedding_blob = self._embedding_to_blob(embedding)

        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO nodes (
                    id,
                    content,
                    embedding,
                    memory_type,
                    memory_tier,
                    access_count,
                    activation_energy,
                    external_id,
                    source_type,
                    created_at,
                    last_accessed_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    node_id,
                    content,
                    embedding_blob,
                    memory_type,
                    memory_tier,
                    access_count,
                    activation_energy,
                    external_id,
                    source_type,
                    timestamp,
                    timestamp,
                ),
            )
            self._sync_nodes_vec_upsert(conn, node_id, embedding)
            conn.commit()
        return node_id

    def get_node(self, node_id: str) -> NodeRecord | None:
        with self._connect() as conn:
            row = conn.execute(
                """
                SELECT
                    id,
                    content,
                    embedding,
                    memory_type,
                    memory_tier,
                    access_count,
                    activation_energy,
                    external_id,
                    source_type
                FROM nodes
                WHERE id = ?
                """,
                (node_id,),
            ).fetchone()
        if row is None:
            return None
        return NodeRecord(
            id=row["id"],
            content=row["content"],
            embedding=self._blob_to_embedding(row["embedding"]),
            memory_type=row["memory_type"],
            memory_tier=row["memory_tier"],
            access_count=int(row["access_count"]),
            activation_energy=float(row["activation_energy"]),
            external_id=row["external_id"],
            source_type=row["source_type"],
        )

    def update_node(self, node_id: str, node: NodeRecord) -> None:
        with self._connect() as conn:
            row = conn.execute(
                """
                SELECT
                    content,
                    embedding,
                    memory_type,
                    memory_tier,
                    access_count,
                    activation_energy,
                    external_id,
                    source_type
                FROM nodes
                WHERE id = ?
                """,
                (node_id,),
            ).fetchone()
            if row is None:
                raise KeyError(f"node not found: {node_id}")

            content = str(node.get("content", row["content"]))
            embedding = (
                self._normalize_embedding(node["embedding"])
                if "embedding" in node
                else self._blob_to_embedding(row["embedding"])
            )
            memory_type = str(node.get("memory_type", row["memory_type"]))
            memory_tier = str(node.get("memory_tier", row["memory_tier"]))
            access_count = int(node.get("access_count", row["access_count"]))
            activation_energy = float(node.get("activation_energy", row["activation_energy"]))
            external_id = node.get("external_id", row["external_id"])
            source_type = node.get("source_type", row["source_type"])
            embedding_blob = self._embedding_to_blob(embedding)

            conn.execute(
                """
                UPDATE nodes
                SET content = ?,
                    embedding = ?,
                    memory_type = ?,
                    memory_tier = ?,
                    access_count = ?,
                    activation_energy = ?,
                    external_id = ?,
                    source_type = ?,
                    last_accessed_at = ?
                WHERE id = ?
                """,
                (
                    content,
                    embedding_blob,
                    memory_type,
                    memory_tier,
                    access_count,
                    activation_energy,
                    external_id,
                    source_type,
                    self._utc_now(),
                    node_id,
                ),
            )
            self._sync_nodes_vec_upsert(conn, node_id, embedding)
            conn.commit()

    def delete_node(self, node_id: str) -> None:
        with self._connect() as conn:
            conn.execute("DELETE FROM edges WHERE node_a = ? OR node_b = ?", (node_id, node_id))
            conn.execute("DELETE FROM nodes_vec WHERE node_id = ?", (node_id,))
            conn.execute("DELETE FROM nodes WHERE id = ?", (node_id,))
            conn.commit()

    def create_edge(self, edge: EdgeRecord) -> str:
        node_a = str(edge.get("node_a") or "")
        node_b = str(edge.get("node_b") or "")
        trigger = str(edge.get("formation_trigger") or "")
        if not node_a or not node_b or not trigger:
            raise ValueError("edge.node_a, edge.node_b, and edge.formation_trigger are required")

        edge_id = str(edge.get("id") or uuid4())
        weight = float(edge.get("weight", 0.3))
        connection_type = str(edge.get("connection_type") or "excitatory")
        activation_count = int(edge.get("activation_count", 0))
        interference_score = float(edge.get("interference_score", 0.0))
        initial_weight = float(edge.get("initial_weight", weight))
        is_cross_tier = 1 if bool(edge.get("is_cross_tier", False)) else 0
        pruned_at_graduation = 1 if bool(edge.get("pruned_at_graduation", False)) else 0
        formed_at = str(edge.get("formed_at") or self._utc_now())
        last_reinforced_at = str(edge.get("last_reinforced_at") or formed_at)

        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO edges (
                    id,
                    node_a,
                    node_b,
                    weight,
                    connection_type,
                    formation_trigger,
                    activation_count,
                    interference_score,
                    formed_at,
                    last_reinforced_at,
                    initial_weight,
                    is_cross_tier,
                    pruned_at_graduation
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    edge_id,
                    node_a,
                    node_b,
                    weight,
                    connection_type,
                    trigger,
                    activation_count,
                    interference_score,
                    formed_at,
                    last_reinforced_at,
                    initial_weight,
                    is_cross_tier,
                    pruned_at_graduation,
                ),
            )
            conn.commit()
        return edge_id

    def get_edge(self, edge_id: str) -> EdgeRecord | None:
        with self._connect() as conn:
            row = conn.execute(
                """
                SELECT id, node_a, node_b, weight, connection_type, formation_trigger
                FROM edges
                WHERE id = ?
                """,
                (edge_id,),
            ).fetchone()
        if row is None:
            return None
        return EdgeRecord(
            id=row["id"],
            node_a=row["node_a"],
            node_b=row["node_b"],
            weight=float(row["weight"]),
            connection_type=row["connection_type"],
            metadata={"formation_trigger": row["formation_trigger"]},
        )

    def update_edge(self, edge_id: str, edge: EdgeRecord) -> None:
        with self._connect() as conn:
            row = conn.execute(
                """
                SELECT weight, connection_type, formation_trigger, last_reinforced_at
                FROM edges
                WHERE id = ?
                """,
                (edge_id,),
            ).fetchone()
            if row is None:
                raise KeyError(f"edge not found: {edge_id}")

            weight = float(edge.get("weight", row["weight"]))
            connection_type = str(edge.get("connection_type", row["connection_type"]))
            trigger = str(edge.get("formation_trigger", row["formation_trigger"]))

            conn.execute(
                """
                UPDATE edges
                SET weight = ?,
                    connection_type = ?,
                    formation_trigger = ?,
                    last_reinforced_at = ?
                WHERE id = ?
                """,
                (
                    weight,
                    connection_type,
                    trigger,
                    self._utc_now(),
                    edge_id,
                ),
            )
            conn.commit()

    def update_edges_bulk(self, updates: Sequence[tuple[str, EdgeRecord]]) -> None:
        if not updates:
            return

        with self._connect() as conn:
            for edge_id, edge in updates:
                row = conn.execute(
                    """
                    SELECT weight, connection_type, formation_trigger, last_reinforced_at
                    FROM edges
                    WHERE id = ?
                    """,
                    (str(edge_id),),
                ).fetchone()
                if row is None:
                    raise KeyError(f"edge not found: {edge_id}")

                weight = float(edge.get("weight", row["weight"]))
                connection_type = str(edge.get("connection_type", row["connection_type"]))
                trigger = str(edge.get("formation_trigger", row["formation_trigger"]))

                conn.execute(
                    """
                    UPDATE edges
                    SET weight = ?,
                        connection_type = ?,
                        formation_trigger = ?,
                        last_reinforced_at = ?
                    WHERE id = ?
                    """,
                    (
                        weight,
                        connection_type,
                        trigger,
                        self._utc_now(),
                        str(edge_id),
                    ),
                )
            conn.commit()

    def delete_edge(self, edge_id: str) -> None:
        with self._connect() as conn:
            conn.execute("DELETE FROM edges WHERE id = ?", (edge_id,))
            conn.commit()

    def keyword_search(self, query: str, *, top_k: int) -> Sequence[SearchResult]:
        if top_k <= 0:
            return []
        query = query.strip()
        if not query:
            return []

        rows = self._keyword_search_rows(query=query, top_k=top_k)
        if not rows:
            fallback_query = self._sanitize_keyword_query(query)
            if fallback_query and fallback_query != query:
                rows = self._keyword_search_rows(query=fallback_query, top_k=top_k)

        return [
            SearchResult(node_id=row["node_id"], score=float(row["score"])) for row in rows
        ]

    def semantic_search(
        self, embedding: Sequence[float], *, top_k: int
    ) -> Sequence[SearchResult]:
        if top_k <= 0:
            return []

        query_embedding = self._normalize_embedding(embedding)
        if not query_embedding:
            return []

        with self._connect() as conn:
            if self._vec_extension_loaded:
                try:
                    return self._semantic_search_with_vec(conn, query_embedding, top_k)
                except sqlite3.OperationalError:
                    # Fall back to local distance computation.
                    pass

            rows = conn.execute("SELECT node_id, embedding FROM nodes_vec").fetchall()

        scored = []
        for row in rows:
            candidate = self._blob_to_embedding(row["embedding"])
            score = self._euclidean_distance(query_embedding, candidate)
            scored.append(SearchResult(node_id=row["node_id"], score=score))
        scored.sort(key=lambda item: (float(item["score"]), str(item["node_id"])))
        return scored[:top_k]

    def semantic_search_long_term(
        self,
        embedding: Sequence[float],
        *,
        top_k: int,
        exclude_node_id: str | None = None,
    ) -> Sequence[SearchResult]:
        if top_k <= 0:
            return []

        query_embedding = self._normalize_embedding(embedding)
        if not query_embedding:
            return []

        excluded = str(exclude_node_id) if exclude_node_id else None
        with self._connect() as conn:
            if self._vec_extension_loaded:
                try:
                    return self._semantic_search_with_vec_long_term(
                        conn,
                        query_embedding,
                        top_k,
                        exclude_node_id=excluded,
                    )
                except sqlite3.OperationalError:
                    # Fall back to local distance computation.
                    pass

            rows = conn.execute(
                """
                SELECT v.node_id, v.embedding
                FROM nodes_vec v
                JOIN nodes n ON n.id = v.node_id
                WHERE n.memory_tier = ? AND (? IS NULL OR v.node_id <> ?)
                """,
                ("long_term", excluded, excluded),
            ).fetchall()

        scored = []
        for row in rows:
            candidate = self._blob_to_embedding(row["embedding"])
            score = self._euclidean_distance(query_embedding, candidate)
            scored.append(
                SearchResult(
                    node_id=row["node_id"],
                    score=score,
                    metadata={"memory_tier": "long_term"},
                )
            )
        scored.sort(key=lambda item: (float(item["score"]), str(item["node_id"])))
        return scored[:top_k]

    def smoke_keyword_query_path(self, query: str, *, top_k: int = 3) -> dict[str, object]:
        try:
            result = self.keyword_search(query, top_k=top_k)
        except Exception as exc:  # pragma: no cover - defensive path
            return {"ok": False, "result_count": 0, "error": str(exc)}
        return {"ok": True, "result_count": len(result)}

    def smoke_semantic_query_path(
        self,
        embedding: Sequence[float],
        *,
        top_k: int = 3,
    ) -> dict[str, object]:
        try:
            result = self.semantic_search(embedding, top_k=top_k)
        except Exception as exc:  # pragma: no cover - defensive path
            return {"ok": False, "result_count": 0, "error": str(exc)}
        return {"ok": True, "result_count": len(result)}

    def startup_diagnostics(self) -> dict[str, object]:
        with self._connect() as conn:
            table_rows = conn.execute(
                "SELECT name FROM sqlite_master WHERE type = 'table';"
            ).fetchall()
            tables = {str(row["name"]) for row in table_rows}
            journal_mode = str(conn.execute("PRAGMA journal_mode;").fetchone()[0]).lower()

        nodes_table_ready = "nodes" in tables
        nodes_fts_ready = "nodes_fts" in tables
        nodes_vec_ready = "nodes_vec" in tables
        edges_table_ready = "edges" in tables
        schema_ready = nodes_table_ready and nodes_fts_ready and nodes_vec_ready and edges_table_ready
        semantic_path_mode = "vec" if self._vec_extension_loaded else "fallback"

        return {
            "schema_ready": schema_ready,
            "nodes_table_ready": nodes_table_ready,
            "edges_table_ready": edges_table_ready,
            "nodes_fts_ready": nodes_fts_ready,
            "nodes_vec_ready": nodes_vec_ready,
            "vec_extension_loaded": self._vec_extension_loaded,
            "semantic_path_mode": semantic_path_mode,
            "journal_mode": journal_mode,
        }

    def upsert_kv_item(
        self,
        *,
        namespace: str,
        key: str,
        value: Any,
        metadata: Mapping[str, Any] | None,
        expires_at: str | None,
    ) -> None:
        now = self._utc_now()
        namespace_value = self._normalize_namespace(namespace)
        value_json = json.dumps(value, separators=(",", ":"))
        metadata_json = json.dumps(dict(metadata or {}), separators=(",", ":"))
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO kv_store (
                    namespace,
                    key,
                    value,
                    metadata,
                    created_at,
                    updated_at,
                    expires_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(namespace, key) DO UPDATE SET
                    value = excluded.value,
                    metadata = excluded.metadata,
                    updated_at = excluded.updated_at,
                    expires_at = excluded.expires_at
                """,
                (
                    namespace_value,
                    key,
                    value_json,
                    metadata_json,
                    now,
                    now,
                    expires_at,
                ),
            )
            conn.commit()

    def get_kv_item(self, *, namespace: str, key: str) -> dict[str, Any] | None:
        namespace_value = self._normalize_namespace(namespace)
        now = self._utc_now()
        with self._connect() as conn:
            conn.execute(
                """
                DELETE FROM kv_store
                WHERE expires_at IS NOT NULL AND expires_at <= ?
                """,
                (now,),
            )
            row = conn.execute(
                """
                SELECT namespace, key, value, metadata, created_at, updated_at, expires_at
                FROM kv_store
                WHERE namespace = ? AND key = ?
                """,
                (namespace_value, key),
            ).fetchone()
            conn.commit()

        if row is None:
            return None
        return {
            "namespace": str(row["namespace"] or ""),
            "key": str(row["key"]),
            "value": json.loads(row["value"]),
            "metadata": json.loads(row["metadata"] or "{}"),
            "created_at": str(row["created_at"]),
            "updated_at": str(row["updated_at"]),
            "expires_at": row["expires_at"],
        }

    def search_kv_items(
        self,
        *,
        namespace: str,
        query: str,
        limit: int,
    ) -> list[dict[str, Any]]:
        namespace_value = self._normalize_namespace(namespace)
        now = self._utc_now()
        pattern = f"%{str(query)}%"
        with self._connect() as conn:
            conn.execute(
                """
                DELETE FROM kv_store
                WHERE expires_at IS NOT NULL AND expires_at <= ?
                """,
                (now,),
            )
            rows = conn.execute(
                """
                SELECT namespace, key, value, metadata, created_at, updated_at, expires_at
                FROM kv_store
                WHERE namespace = ? AND key LIKE ? COLLATE NOCASE
                ORDER BY updated_at DESC, key ASC
                LIMIT ?
                """,
                (namespace_value, pattern, max(1, int(limit))),
            ).fetchall()
            conn.commit()

        results: list[dict[str, Any]] = []
        for row in rows:
            results.append(
                {
                    "namespace": str(row["namespace"] or ""),
                    "key": str(row["key"]),
                    "value": json.loads(row["value"]),
                    "metadata": json.loads(row["metadata"] or "{}"),
                    "created_at": str(row["created_at"]),
                    "updated_at": str(row["updated_at"]),
                    "expires_at": row["expires_at"],
                }
            )
        return results

    def delete_kv_item(self, *, namespace: str, key: str) -> bool:
        namespace_value = self._normalize_namespace(namespace)
        with self._connect() as conn:
            cursor = conn.execute(
                "DELETE FROM kv_store WHERE namespace = ? AND key = ?",
                (namespace_value, key),
            )
            conn.commit()
        return bool(cursor.rowcount > 0)

    def clear_kv_items(self, *, namespace: str | None = None) -> int:
        with self._connect() as conn:
            if namespace == "*":
                row = conn.execute("SELECT COUNT(*) FROM kv_store").fetchone()
                count = int(row[0]) if row else 0
                conn.execute("DELETE FROM kv_store")
                conn.commit()
                return count

            namespace_value = self._normalize_namespace(namespace or "")
            row = conn.execute(
                "SELECT COUNT(*) FROM kv_store WHERE namespace = ?",
                (namespace_value,),
            ).fetchone()
            count = int(row[0]) if row else 0
            conn.execute(
                "DELETE FROM kv_store WHERE namespace = ?",
                (namespace_value,),
            )
            conn.commit()
        return count

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(
            self._db_path,
            timeout=_SQLITE_CONNECT_TIMEOUT_SECONDS,
        )
        conn.row_factory = sqlite3.Row
        _configure_connection(conn)
        return conn

    def _load_schema_sql(self) -> str:
        try:
            return self._schema_resource.read_text(encoding="utf-8")
        except FileNotFoundError:
            return self._schema_path.read_text(encoding="utf-8")

    def _ensure_nodes_vec_table(
        self,
        conn: sqlite3.Connection,
        vec_statement: str,
    ) -> None:
        if self._table_exists(conn, "nodes_vec"):
            self._vec_extension_loaded = self._is_virtual_table(conn, "nodes_vec")
            return

        try:
            conn.execute(vec_statement)
        except sqlite3.OperationalError as exc:
            if not self._is_vec_module_missing_error(exc):
                raise
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS nodes_vec (
                    node_id TEXT PRIMARY KEY,
                    embedding BLOB NOT NULL
                );
                """
            )
            self._vec_extension_loaded = False
            return

        self._vec_extension_loaded = True

    def _sync_nodes_vec_upsert(
        self,
        conn: sqlite3.Connection,
        node_id: str,
        embedding: Sequence[float],
    ) -> None:
        conn.execute("DELETE FROM nodes_vec WHERE node_id = ?", (node_id,))
        if self._vec_extension_loaded:
            conn.execute(
                "INSERT INTO nodes_vec (node_id, embedding) VALUES (?, ?)",
                (node_id, self._embedding_to_vec_literal(embedding)),
            )
            return
        conn.execute(
            "INSERT INTO nodes_vec (node_id, embedding) VALUES (?, ?)",
            (node_id, self._embedding_to_blob(embedding)),
        )

    def _table_exists(self, conn: sqlite3.Connection, table_name: str) -> bool:
        row = conn.execute(
            "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ?;",
            (table_name,),
        ).fetchone()
        return row is not None

    def _is_virtual_table(self, conn: sqlite3.Connection, table_name: str) -> bool:
        row = conn.execute(
            "SELECT sql FROM sqlite_master WHERE type = 'table' AND name = ?;",
            (table_name,),
        ).fetchone()
        if row is None or row[0] is None:
            return False
        return "VIRTUAL TABLE" in row[0].upper()

    def _is_vec_module_missing_error(self, exc: sqlite3.OperationalError) -> bool:
        message = str(exc).lower()
        return "no such module" in message and "vec" in message

    def _normalize_embedding(self, embedding: object) -> list[float]:
        if embedding is None:
            return []
        return [float(value) for value in embedding]  # type: ignore[arg-type]

    def _embedding_to_blob(self, embedding: Sequence[float]) -> bytes:
        values = array("f", [float(value) for value in embedding])
        return values.tobytes()

    def _blob_to_embedding(self, blob: bytes | bytearray | memoryview | str) -> list[float]:
        if isinstance(blob, str):
            # vec virtual table may return JSON literals in some implementations.
            return [float(value) for value in json.loads(blob)]
        raw = bytes(blob)
        values = array("f")
        values.frombytes(raw)
        return [float(value) for value in values]

    def _embedding_to_vec_literal(self, embedding: Sequence[float]) -> str:
        return json.dumps([float(value) for value in embedding], separators=(",", ":"))

    def _semantic_search_with_vec(
        self,
        conn: sqlite3.Connection,
        query_embedding: Sequence[float],
        top_k: int,
    ) -> list[SearchResult]:
        rows = conn.execute(
            """
            SELECT node_id, distance
            FROM nodes_vec
            WHERE embedding MATCH ?
            ORDER BY distance, node_id
            LIMIT ?
            """,
            (self._embedding_to_vec_literal(query_embedding), top_k),
        ).fetchall()
        return [
            SearchResult(node_id=row["node_id"], score=float(row["distance"]))
            for row in rows
        ]

    def _semantic_search_with_vec_long_term(
        self,
        conn: sqlite3.Connection,
        query_embedding: Sequence[float],
        top_k: int,
        *,
        exclude_node_id: str | None,
    ) -> list[SearchResult]:
        rows = conn.execute(
            """
            SELECT v.node_id, v.distance
            FROM nodes_vec v
            JOIN nodes n ON n.id = v.node_id
            WHERE v.embedding MATCH ?
              AND n.memory_tier = ?
              AND (? IS NULL OR v.node_id <> ?)
            ORDER BY v.distance, v.node_id
            LIMIT ?
            """,
            (
                self._embedding_to_vec_literal(query_embedding),
                "long_term",
                exclude_node_id,
                exclude_node_id,
                top_k,
            ),
        ).fetchall()
        return [
            SearchResult(
                node_id=row["node_id"],
                score=float(row["distance"]),
                metadata={"memory_tier": "long_term"},
            )
            for row in rows
        ]

    def _keyword_search_rows(self, *, query: str, top_k: int) -> list[sqlite3.Row]:
        with self._connect() as conn:
            try:
                return conn.execute(
                    """
                    SELECT nodes.id AS node_id, bm25(nodes_fts) AS score
                    FROM nodes_fts
                    JOIN nodes ON nodes.rowid = nodes_fts.rowid
                    WHERE nodes_fts MATCH ?
                    ORDER BY score, nodes.id
                    LIMIT ?
                    """,
                    (query, top_k),
                ).fetchall()
            except sqlite3.OperationalError:
                return []

    def _sanitize_keyword_query(self, query: str) -> str:
        tokens = self._KEYWORD_FALLBACK_TOKEN_PATTERN.findall(query)
        return " ".join(tokens).strip()

    def _euclidean_distance(self, left: Sequence[float], right: Sequence[float]) -> float:
        shared = min(len(left), len(right))
        total = 0.0
        for idx in range(shared):
            delta = left[idx] - right[idx]
            total += delta * delta
        if len(left) != len(right):
            total += float(abs(len(left) - len(right)))
        return total ** 0.5

    def _utc_now(self) -> str:
        return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")

    def _normalize_namespace(self, namespace: str) -> str:
        return str(namespace or "")


def _configure_connection(conn: sqlite3.Connection) -> None:
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.execute(f"PRAGMA busy_timeout = {_SQLITE_BUSY_TIMEOUT_MS};")
    journal_mode = str(conn.execute("PRAGMA journal_mode;").fetchone()[0]).lower()
    if journal_mode != "wal":
        conn.execute("PRAGMA journal_mode = WAL;")
    conn.execute("PRAGMA synchronous = NORMAL;")
