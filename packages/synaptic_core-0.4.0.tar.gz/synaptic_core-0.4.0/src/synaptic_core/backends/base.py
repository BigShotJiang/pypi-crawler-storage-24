"""Backend protocol contract for Synaptic persistence implementations."""

from __future__ import annotations

from typing import Any, Mapping, Protocol, Sequence, TypedDict, runtime_checkable


class NodeRecord(TypedDict, total=False):
    """Backend-agnostic node payload shape."""

    id: str
    content: str
    embedding: Sequence[float]
    memory_type: str
    memory_tier: str
    access_count: int
    activation_energy: float
    external_id: str | None
    source_type: str | None
    metadata: Mapping[str, Any]


class EdgeRecord(TypedDict, total=False):
    """Backend-agnostic edge payload shape."""

    id: str
    node_a: str
    node_b: str
    weight: float
    connection_type: str
    metadata: Mapping[str, Any]


class SearchResult(TypedDict, total=False):
    """Backend search result payload shape."""

    node_id: str
    score: float
    metadata: Mapping[str, Any]


@runtime_checkable
class MemoryBackend(Protocol):
    """Persistence backend contract used by Synaptic engines."""

    def init_schema(self) -> None:
        """Initialize backend schema and indexes idempotently."""

    def create_node(self, node: NodeRecord) -> str:
        """Persist a node and return its identifier."""

    def get_node(self, node_id: str) -> NodeRecord | None:
        """Return a node by identifier, or None when absent."""

    def update_node(self, node_id: str, node: NodeRecord) -> None:
        """Update a node by identifier."""

    def delete_node(self, node_id: str) -> None:
        """Delete a node by identifier."""

    def create_edge(self, edge: EdgeRecord) -> str:
        """Persist an edge and return its identifier."""

    def get_edge(self, edge_id: str) -> EdgeRecord | None:
        """Return an edge by identifier, or None when absent."""

    def update_edge(self, edge_id: str, edge: EdgeRecord) -> None:
        """Update an edge by identifier."""

    def delete_edge(self, edge_id: str) -> None:
        """Delete an edge by identifier."""

    def keyword_search(self, query: str, *, top_k: int) -> Sequence[SearchResult]:
        """Run keyword search over stored nodes."""

    def semantic_search(
        self, embedding: Sequence[float], *, top_k: int
    ) -> Sequence[SearchResult]:
        """Run semantic similarity search over stored nodes."""
