"""Composite outcome detection for Phase 3 learning gates."""

from __future__ import annotations

from dataclasses import dataclass
import re
from typing import Iterable, Mapping, Sequence
from uuid import NAMESPACE_URL, UUID, uuid5

from .models import CompositeOutcome, OutcomeSignal, RetrievalResult
from .types import OutcomeSignalType

DEFAULT_SIGNAL_WEIGHTS: dict[str, float] = {
    OutcomeSignalType.EXPLICIT_POSITIVE.value: 1.0,
    OutcomeSignalType.EXPLICIT_NEGATIVE.value: 1.0,
    OutcomeSignalType.MEMORY_IN_RESPONSE.value: 0.8,
    OutcomeSignalType.PRODUCTIVE_CONTINUATION.value: 0.7,
    OutcomeSignalType.CONTRADICTION.value: 0.8,
    OutcomeSignalType.CORRECTION.value: 0.7,
    OutcomeSignalType.RE_QUERY_MISS.value: 0.6,
    OutcomeSignalType.CLARIFICATION_NEEDED.value: 0.4,
    OutcomeSignalType.SESSION_CONTINUATION.value: 0.2,
    OutcomeSignalType.DWELL_TIME.value: 0.1,
}

_NEGATION_WORDS = {
    "no",
    "not",
    "incorrect",
    "wrong",
    "actually",
    "never",
}

_TOKEN_PATTERN = re.compile(r"[a-z0-9]+")


@dataclass(frozen=True)
class _ProviderSignalSpec:
    signal_type: OutcomeSignalType
    value: float
    confidence: float


_PROVIDER_OUTCOME_MAP: dict[str, _ProviderSignalSpec] = {
    "productive_continuation": _ProviderSignalSpec(
        signal_type=OutcomeSignalType.PRODUCTIVE_CONTINUATION,
        value=0.8,
        confidence=0.7,
    ),
    "correction": _ProviderSignalSpec(
        signal_type=OutcomeSignalType.CORRECTION,
        value=-0.8,
        confidence=0.7,
    ),
    "clarification_needed": _ProviderSignalSpec(
        signal_type=OutcomeSignalType.CLARIFICATION_NEEDED,
        value=-0.4,
        confidence=0.4,
    ),
}


class OutcomeDetector:
    """Compute multi-signal composite outcomes and confidence gates."""

    def __init__(
        self,
        *,
        learning_gate_threshold: float = 0.4,
        oscillation_window: int = 5,
        signal_weights: dict[str, float] | None = None,
    ) -> None:
        self._learning_gate_threshold = _clamp(float(learning_gate_threshold), lower=0.0, upper=1.0)
        self._oscillation_window = max(1, int(oscillation_window))
        merged_weights = dict(DEFAULT_SIGNAL_WEIGHTS)
        if signal_weights:
            merged_weights.update({str(key): float(value) for key, value in signal_weights.items()})
        self._signal_weights = merged_weights

    @property
    def learning_gate_threshold(self) -> float:
        return self._learning_gate_threshold

    @property
    def signal_weights(self) -> dict[str, float]:
        return dict(self._signal_weights)

    async def detect(
        self,
        *,
        query_id: UUID,
        retrieval_result: RetrievalResult,
        agent_response: str | None = None,
        user_next_message: str | None = None,
        explicit_outcome: OutcomeSignalType | None = None,
        provider_outcome: str | None = None,
        dwell_time_ms: float | None = None,
        previous_retrieval_result: RetrievalResult | None = None,
        edge_weight_history: Mapping[str, Sequence[float]] | None = None,
    ) -> CompositeOutcome:
        signals: list[OutcomeSignal] = []

        if explicit_outcome in (
            OutcomeSignalType.EXPLICIT_POSITIVE,
            OutcomeSignalType.EXPLICIT_NEGATIVE,
        ):
            signals.append(
                OutcomeSignal(
                    signal_type=explicit_outcome,
                    value=1.0 if explicit_outcome == OutcomeSignalType.EXPLICIT_POSITIVE else -1.0,
                    confidence=1.0,
                    raw_evidence="explicit_outcome",
                )
            )

        provider_signal_type: OutcomeSignalType | None = None
        if provider_outcome:
            provider_signal = _PROVIDER_OUTCOME_MAP.get(
                _normalize_provider_outcome(provider_outcome)
            )
            if provider_signal is not None:
                provider_signal_type = provider_signal.signal_type
                signals.append(
                    OutcomeSignal(
                        signal_type=provider_signal.signal_type,
                        value=provider_signal.value,
                        confidence=provider_signal.confidence,
                        raw_evidence=f"provider_outcome:{provider_outcome}",
                    )
                )

        contradiction_detected = False
        if agent_response:
            similarity = self._max_similarity(agent_response, retrieval_result.nodes)
            if similarity > 0.65:
                signals.append(
                    OutcomeSignal(
                        signal_type=OutcomeSignalType.MEMORY_IN_RESPONSE,
                        value=_clamp(similarity, lower=-1.0, upper=1.0),
                        confidence=_clamp(similarity, lower=0.0, upper=1.0),
                        raw_evidence=f"response_overlap_{similarity:.2f}",
                    )
                )

        if user_next_message:
            similarity = self._max_similarity(user_next_message, retrieval_result.nodes)
            if similarity > 0.7 and _looks_contradictory(user_next_message):
                contradiction_detected = True
                signals.append(
                    OutcomeSignal(
                        signal_type=OutcomeSignalType.CONTRADICTION,
                        value=-0.8,
                        confidence=max(0.4, _clamp(similarity, lower=0.0, upper=1.0)),
                        raw_evidence=f"contradiction_overlap_{similarity:.2f}",
                    )
                )

        if previous_retrieval_result is not None:
            re_query_miss_count = self._re_query_miss_count(
                current=retrieval_result,
                previous=previous_retrieval_result,
            )
            if re_query_miss_count > 0:
                signals.append(
                    OutcomeSignal(
                        signal_type=OutcomeSignalType.RE_QUERY_MISS,
                        value=-0.6,
                        confidence=0.6,
                        raw_evidence=f"missed_activation_count_{re_query_miss_count}",
                    )
                )

        correction_detected = provider_signal_type == OutcomeSignalType.CORRECTION
        if not contradiction_detected and not correction_detected:
            signals.append(
                OutcomeSignal(
                    signal_type=OutcomeSignalType.SESSION_CONTINUATION,
                    value=0.3,
                    confidence=0.2,
                    raw_evidence="continuation_without_correction",
                )
            )

        if dwell_time_ms is not None:
            dwell_value = 0.0
            if dwell_time_ms < 2000:
                dwell_value = -0.2
            elif dwell_time_ms > 8000:
                dwell_value = 0.1

            signals.append(
                OutcomeSignal(
                    signal_type=OutcomeSignalType.DWELL_TIME,
                    value=dwell_value,
                    confidence=0.1,
                    raw_evidence=f"dwell_time_ms_{int(dwell_time_ms)}",
                )
            )

        composite_score = self._composite_score(signals)
        composite_confidence = self._composite_confidence(signals)
        learning_gated = (composite_confidence + 1e-12) < self._learning_gate_threshold
        oscillating_edge_ids = self._check_oscillation(
            retrieval_result=retrieval_result,
            edge_weight_history=edge_weight_history or {},
        )

        return CompositeOutcome(
            query_id=query_id,
            signals=signals,
            composite_score=_clamp(composite_score, lower=-1.0, upper=1.0),
            composite_confidence=_clamp(composite_confidence, lower=0.0, upper=1.0),
            learning_gated=learning_gated,
            oscillation_detected=bool(oscillating_edge_ids),
            oscillating_edge_ids=oscillating_edge_ids,
        )

    def _max_similarity(self, text: str, nodes: Sequence[object]) -> float:
        text_tokens = _tokenize(text)
        if not text_tokens:
            return 0.0

        best = 0.0
        for node in nodes:
            content = str(getattr(node, "content", "")).strip()
            if not content:
                continue
            best = max(best, _jaccard_similarity(text_tokens, _tokenize(content)))
        return best

    def _re_query_miss_count(self, *, current: RetrievalResult, previous: RetrievalResult) -> int:
        previous_seed_ids = {str(node_id) for node_id in previous.seed_node_ids}
        current_seed_ids = {str(node_id) for node_id in current.seed_node_ids}
        if not previous_seed_ids or not current_seed_ids:
            return 0

        if not previous_seed_ids.intersection(current_seed_ids):
            return 0

        current_activated = _activated_node_ids(current)
        previous_activated = _activated_node_ids(previous)
        missed = current_activated.difference(previous_activated)
        return len(missed)

    def _composite_score(self, signals: Iterable[OutcomeSignal]) -> float:
        numerator = 0.0
        denominator = 0.0
        for signal in signals:
            weight = self._signal_weights.get(signal.signal_type.value, 1.0)
            numerator += signal.value * signal.confidence * weight
            denominator += weight
        if denominator <= 0.0:
            return 0.0
        return numerator / denominator

    @staticmethod
    def _composite_confidence(signals: Sequence[OutcomeSignal]) -> float:
        if not signals:
            return 0.0
        return sum(signal.confidence for signal in signals) / len(signals)

    def _check_oscillation(
        self,
        *,
        retrieval_result: RetrievalResult,
        edge_weight_history: Mapping[str, Sequence[float]],
    ) -> list[UUID]:
        edge_ids = _edge_ids_from_activation_path(retrieval_result.activation_path)
        if not edge_ids:
            return []

        oscillating: list[UUID] = []
        for edge_id in sorted(edge_ids):
            history = edge_weight_history.get(edge_id, [])
            recent = [float(weight) for weight in history[-self._oscillation_window :]]
            if len(recent) < 2:
                continue
            crossings = _midpoint_crossings(recent, midpoint=0.5)
            if crossings > 2:
                oscillating.append(_as_uuid(edge_id))
        return oscillating


def _normalize_provider_outcome(value: str) -> str:
    normalized = value.strip().lower().replace("-", "_").replace(" ", "_")
    return normalized


def _tokenize(text: str) -> set[str]:
    return set(_TOKEN_PATTERN.findall(text.lower()))


def _jaccard_similarity(left: set[str], right: set[str]) -> float:
    if not left or not right:
        return 0.0
    intersection = len(left.intersection(right))
    union = len(left.union(right))
    if union <= 0:
        return 0.0
    return intersection / union


def _looks_contradictory(text: str) -> bool:
    lowered = text.lower()
    if "that's wrong" in lowered:
        return True
    tokens = _tokenize(lowered)
    return any(token in _NEGATION_WORDS for token in tokens)


def _activated_node_ids(result: RetrievalResult) -> set[str]:
    activated: set[str] = set()
    activated.update(str(node_id) for node_id in result.seed_node_ids)
    activated.update(str(node_id) for node_id in result.activation_sourced_node_ids)
    for step in result.activation_path:
        source = step.get("source_node_id") or step.get("source")
        target = step.get("target_node_id") or step.get("target")
        if source is not None:
            activated.add(str(source))
        if target is not None:
            activated.add(str(target))
    return activated


def _edge_ids_from_activation_path(activation_path: Sequence[Mapping[str, object]]) -> set[str]:
    edge_ids: set[str] = set()
    for step in activation_path:
        edge_id = step.get("edge_id") or step.get("connection_id")
        if edge_id is None:
            continue
        edge_ids.add(str(edge_id))
    return edge_ids


def _midpoint_crossings(weights: Sequence[float], *, midpoint: float) -> int:
    crossings = 0
    prev_sign = 0
    for weight in weights:
        current_sign = 0
        if weight > midpoint:
            current_sign = 1
        elif weight < midpoint:
            current_sign = -1

        if current_sign == 0:
            continue
        if prev_sign != 0 and current_sign != prev_sign:
            crossings += 1
        prev_sign = current_sign
    return crossings


def _as_uuid(value: str) -> UUID:
    text = str(value)
    try:
        return UUID(text)
    except (TypeError, ValueError, AttributeError):
        return uuid5(NAMESPACE_URL, text)


def _clamp(value: float, *, lower: float, upper: float) -> float:
    return max(lower, min(upper, float(value)))


__all__ = ["DEFAULT_SIGNAL_WEIGHTS", "OutcomeDetector"]
