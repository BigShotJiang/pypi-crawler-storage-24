"""Graduation eligibility primitives for Phase 4 tier transfer."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
import inspect
from typing import Any, Mapping, Sequence
from uuid import NAMESPACE_URL, UUID, uuid5

from .models import Node
from .types import MemoryTier


@dataclass(frozen=True)
class GraduationEligibility:
    """Per-node eligibility snapshot for graduation criteria checks."""

    node_id: UUID
    access_count: int
    positive_outcome_ratio: float
    age_hours: float
    reinforced_edge_count: int
    criteria_passed: dict[str, bool] = field(default_factory=dict)
    eligible: bool = False


@dataclass(frozen=True)
class GraduationReport:
    """Summary of evaluated short-term nodes and eligibility decisions."""

    nodes_evaluated: int
    eligible_node_ids: list[UUID] = field(default_factory=list)
    eligibility_by_node: dict[UUID, GraduationEligibility] = field(default_factory=dict)


@dataclass(frozen=True)
class GraduationTransferReport:
    """Summary of per-node graduation transfer outcomes."""

    nodes_considered: int
    nodes_graduated: list[UUID] = field(default_factory=list)
    nodes_failed: list[UUID] = field(default_factory=list)
    nodes_pruned_edges: dict[UUID, int] = field(default_factory=dict)


class GraduationEngine:
    """Evaluate short-term nodes against all required graduation criteria."""

    def __init__(
        self,
        *,
        min_access_count: int = 5,
        min_positive_outcome_ratio: float = 0.6,
        min_age_hours: float = 48.0,
        min_reinforced_edges: int = 2,
        reinforced_edge_weight_threshold: float = 0.45,
        edge_transfer_threshold: float = 0.40,
        check_interval_sessions: int = 10,
        telemetry_collector: Any | None = None,
        deployment_id: str = "local",
        graduation_trigger: str = "scheduled",
    ) -> None:
        self._min_access_count = max(0, int(min_access_count))
        self._min_positive_outcome_ratio = _clamp(float(min_positive_outcome_ratio), lower=0.0, upper=1.0)
        self._min_age_hours = max(0.0, float(min_age_hours))
        self._min_reinforced_edges = max(0, int(min_reinforced_edges))
        self._reinforced_edge_weight_threshold = float(reinforced_edge_weight_threshold)
        self._edge_transfer_threshold = float(edge_transfer_threshold)
        self._check_interval_sessions = max(1, int(check_interval_sessions))
        self._telemetry_collector = telemetry_collector
        self._deployment_id = str(deployment_id or "local")
        self._graduation_trigger = str(graduation_trigger or "scheduled")

    async def evaluate_candidates(
        self,
        *,
        graph: Any,
        now: datetime | None = None,
    ) -> GraduationReport:
        evaluation_now = _to_utc_datetime(now or datetime.now(timezone.utc))
        nodes = await _list_short_term_nodes(graph)
        nodes_sorted = sorted(nodes, key=lambda item: str(item.id))
        node_id_keys = [str(node.id) for node in nodes_sorted]
        ratio_by_node, reinforced_by_node = await _batched_eligibility_inputs(
            graph=graph,
            node_ids=node_id_keys,
            reinforced_edge_weight_threshold=self._reinforced_edge_weight_threshold,
        )

        eligibility_by_node: dict[UUID, GraduationEligibility] = {}
        eligible_node_ids: list[UUID] = []
        for node in nodes_sorted:
            node_key = str(node.id)
            if node_key in ratio_by_node:
                ratio = _clamp(_as_float(ratio_by_node[node_key]), lower=0.0, upper=1.0)
            else:
                ratio = await self._compute_positive_outcome_ratio(node_id=node.id, graph=graph)
            if node_key in reinforced_by_node:
                reinforced_edge_count = max(0, int(_as_float(reinforced_by_node[node_key])))
            else:
                reinforced_edge_count = await self._count_reinforced_edges(node_id=node.id, graph=graph)
            age_hours = _age_hours(node.created_at, evaluation_now)
            access_count = max(0, int(node.access_count))

            criteria_passed = {
                "access_count": access_count >= self._min_access_count,
                "positive_outcome_ratio": ratio >= self._min_positive_outcome_ratio,
                "age_hours": age_hours >= self._min_age_hours,
                "reinforced_edge_count": reinforced_edge_count >= self._min_reinforced_edges,
            }
            eligible = all(criteria_passed.values())
            node_id = _as_uuid(node.id)

            eligibility = GraduationEligibility(
                node_id=node_id,
                access_count=access_count,
                positive_outcome_ratio=ratio,
                age_hours=age_hours,
                reinforced_edge_count=reinforced_edge_count,
                criteria_passed=criteria_passed,
                eligible=eligible,
            )
            eligibility_by_node[node_id] = eligibility
            if eligible:
                eligible_node_ids.append(node_id)

        return GraduationReport(
            nodes_evaluated=len(nodes_sorted),
            eligible_node_ids=sorted(set(eligible_node_ids)),
            eligibility_by_node=eligibility_by_node,
        )

    async def apply_graduations(
        self,
        *,
        graph: Any,
        eligibility_report: GraduationReport | None = None,
        now: datetime | None = None,
    ) -> GraduationTransferReport:
        evaluation = eligibility_report
        if evaluation is None:
            evaluation = await self.evaluate_candidates(graph=graph, now=now)
        if evaluation is None:
            return GraduationTransferReport(nodes_considered=0)

        transfer_at = _to_utc_datetime(now or datetime.now(timezone.utc))
        eligible_ids = sorted(set(evaluation.eligible_node_ids))
        nodes_graduated: list[UUID] = []
        nodes_failed: list[UUID] = []
        nodes_pruned_edges: dict[UUID, int] = {}

        for node_id in eligible_ids:
            eligibility = evaluation.eligibility_by_node.get(node_id)
            if eligibility is None or not eligibility.eligible:
                continue
            success, pruned_count, transferred_count = await self._apply_single_graduation(
                graph=graph,
                node_id=node_id,
                eligibility=eligibility,
                transfer_at=transfer_at,
            )
            if success:
                nodes_graduated.append(node_id)
                nodes_pruned_edges[node_id] = pruned_count
                self._record_graduation_telemetry(
                    node_id=node_id,
                    eligibility=eligibility,
                    transfer_at=transfer_at,
                    edges_transferred=transferred_count,
                    edges_pruned=pruned_count,
                    decision_outcome="graduated",
                )
            else:
                nodes_failed.append(node_id)

        return GraduationTransferReport(
            nodes_considered=len(eligible_ids),
            nodes_graduated=sorted(set(nodes_graduated)),
            nodes_failed=sorted(set(nodes_failed)),
            nodes_pruned_edges=nodes_pruned_edges,
        )

    async def _compute_positive_outcome_ratio(self, *, node_id: UUID, graph: Any) -> float:
        for method_name in (
            "get_positive_outcome_ratio",
            "compute_positive_outcome_ratio",
            "positive_outcome_ratio",
        ):
            method = getattr(graph, method_name, None)
            if not callable(method):
                continue
            raw_value = await _maybe_await(method(str(node_id)))
            return _clamp(_as_float(raw_value), lower=0.0, upper=1.0)

        outcomes = await _list_outcomes_for_node(graph=graph, node_id=node_id)
        if not outcomes:
            return 0.0

        positives = 0
        considered = 0
        for outcome in outcomes:
            score = _mapping_or_attr_value(outcome, key="composite_score", default=0.0)
            considered += 1
            if _as_float(score) > 0.1:
                positives += 1
        if considered <= 0:
            return 0.0
        return positives / float(considered)

    async def _count_reinforced_edges(self, *, node_id: UUID, graph: Any) -> int:
        edges = await _list_edges_for_node(graph=graph, node_id=node_id)
        reinforced = 0
        for edge in edges:
            weight = _mapping_or_attr_value(edge, key="weight", default=0.0)
            if _as_float(weight) > self._reinforced_edge_weight_threshold:
                reinforced += 1
        return reinforced

    async def _apply_single_graduation(
        self,
        *,
        graph: Any,
        node_id: UUID,
        eligibility: GraduationEligibility,
        transfer_at: datetime,
    ) -> tuple[bool, int, int]:
        node_record = await _get_node_by_id(graph=graph, node_id=node_id)
        if node_record is None:
            return False, 0, 0

        node_snapshot = _node_snapshot(node_record)
        edges = sorted(
            await _list_edges_for_node(graph=graph, node_id=node_id),
            key=lambda edge: _edge_identifier(edge),
        )
        edge_snapshots = {
            _edge_identifier(edge): _edge_state_snapshot(edge)
            for edge in edges
            if _edge_identifier(edge)
        }

        transaction_started = await _begin_node_transaction(graph)
        pruned_count = 0
        transferred_count = 0
        try:
            await _update_node(
                graph=graph,
                node_id=node_id,
                payload={
                    "memory_tier": MemoryTier.LONG_TERM,
                    "graduated_at": transfer_at,
                    "graduation_access_count": int(eligibility.access_count),
                },
            )

            for edge in edges:
                edge_id = _edge_identifier(edge)
                if not edge_id:
                    continue

                weight = _as_float(_mapping_or_attr_value(edge, key="weight", default=0.0))
                if weight < self._edge_transfer_threshold:
                    pruned_count += 1
                    await _update_edge(
                        graph=graph,
                        edge_id=edge_id,
                        payload={"pruned_at_graduation": True},
                    )
                    continue

                other_node_id = _other_node_id(edge=edge, node_id=node_id)
                other_tier = await _node_tier_for_id(graph=graph, node_id=other_node_id)
                if other_tier is None:
                    is_cross_tier = bool(_mapping_or_attr_value(edge, key="is_cross_tier", default=False))
                else:
                    is_cross_tier = other_tier != MemoryTier.LONG_TERM.value

                await _update_edge(
                    graph=graph,
                    edge_id=edge_id,
                    payload={
                        "is_cross_tier": is_cross_tier,
                        "pruned_at_graduation": False,
                    },
                )
                transferred_count += 1

            await _commit_node_transaction(graph, started=transaction_started)
            return True, pruned_count, transferred_count
        except Exception:
            await _rollback_node_transaction(graph, started=transaction_started)
            await _restore_node_state(
                graph=graph,
                node_id=node_id,
                node_snapshot=node_snapshot,
            )
            await _restore_edge_states(
                graph=graph,
                edge_snapshots=edge_snapshots,
            )
            return False, 0, 0

    def _record_graduation_telemetry(
        self,
        *,
        node_id: UUID,
        eligibility: GraduationEligibility,
        transfer_at: datetime,
        edges_transferred: int,
        edges_pruned: int,
        decision_outcome: str,
    ) -> None:
        collector = self._telemetry_collector
        if collector is None:
            return
        try:
            method = getattr(collector, "record_graduation", None)
        except Exception:
            return
        if not callable(method):
            return

        timestamp = _to_utc_datetime(transfer_at)
        timestamp_text = timestamp.isoformat()
        trigger = f"{self._graduation_trigger}:{decision_outcome}"
        payload = {
            "graduation_id": str(
                uuid5(
                    NAMESPACE_URL,
                    (
                        f"{node_id}|{timestamp_text}|{edges_transferred}|"
                        f"{edges_pruned}|{trigger}"
                    ),
                )
            ),
            "node_id": str(node_id),
            "deployment_id": self._deployment_id,
            "graduated_at": timestamp_text,
            "access_count_at_graduation": int(eligibility.access_count),
            "positive_outcome_ratio": float(eligibility.positive_outcome_ratio),
            "age_hours_at_graduation": float(eligibility.age_hours),
            "edges_transferred": int(edges_transferred),
            "edges_pruned": int(edges_pruned),
            "graduation_trigger": trigger,
        }
        try:
            method(payload)
        except Exception:
            return


async def _list_short_term_nodes(graph: Any) -> list[Node]:
    for method_name in ("list_short_term_nodes", "get_short_term_nodes"):
        method = getattr(graph, method_name, None)
        if callable(method):
            result = await _maybe_await(method())
            return _normalize_nodes(result)

    for method_name in ("list_nodes_by_tier", "get_nodes_by_tier"):
        method = getattr(graph, method_name, None)
        if callable(method):
            result = await _maybe_await(method(MemoryTier.SHORT_TERM.value))
            return _normalize_nodes(result)

    nodes = getattr(graph, "nodes", None)
    if nodes is not None:
        return [
            node
            for node in _normalize_nodes(nodes)
            if _tier_value(node) == MemoryTier.SHORT_TERM.value
        ]
    return []


async def _batched_eligibility_inputs(
    *,
    graph: Any,
    node_ids: Sequence[str],
    reinforced_edge_weight_threshold: float,
) -> tuple[dict[str, float], dict[str, int]]:
    node_keys = [str(node_id) for node_id in node_ids if str(node_id)]
    if not node_keys:
        return {}, {}

    get_graduation_metrics = getattr(graph, "get_graduation_metrics", None)
    if callable(get_graduation_metrics):
        try:
            raw = await _maybe_await(
                get_graduation_metrics(
                    list(node_keys),
                    reinforced_edge_weight_threshold=float(reinforced_edge_weight_threshold),
                )
            )
        except TypeError:
            raw = await _maybe_await(get_graduation_metrics(list(node_keys)))
        except Exception:
            raw = None
        ratio_by_node, reinforced_by_node = _normalize_batched_graduation_metrics(raw)
        if ratio_by_node or reinforced_by_node:
            return ratio_by_node, reinforced_by_node

    ratio_by_node: dict[str, float] = {}
    get_positive_outcome_ratios = getattr(graph, "get_positive_outcome_ratios", None)
    if callable(get_positive_outcome_ratios):
        try:
            raw_ratios = await _maybe_await(get_positive_outcome_ratios(list(node_keys)))
        except Exception:
            raw_ratios = None
        if isinstance(raw_ratios, Mapping):
            for key, value in raw_ratios.items():
                ratio_by_node[str(key)] = _clamp(_as_float(value), lower=0.0, upper=1.0)

    reinforced_by_node: dict[str, int] = {}
    get_reinforced_edge_counts = getattr(graph, "get_reinforced_edge_counts", None)
    if callable(get_reinforced_edge_counts):
        try:
            raw_counts = await _maybe_await(
                get_reinforced_edge_counts(
                    list(node_keys),
                    reinforced_edge_weight_threshold=float(reinforced_edge_weight_threshold),
                )
            )
        except TypeError:
            raw_counts = await _maybe_await(get_reinforced_edge_counts(list(node_keys)))
        except Exception:
            raw_counts = None
        if isinstance(raw_counts, Mapping):
            for key, value in raw_counts.items():
                reinforced_by_node[str(key)] = max(0, int(_as_float(value)))

    return ratio_by_node, reinforced_by_node


def _normalize_batched_graduation_metrics(
    raw: Any,
) -> tuple[dict[str, float], dict[str, int]]:
    if not isinstance(raw, Mapping):
        return {}, {}

    ratio_by_node: dict[str, float] = {}
    reinforced_by_node: dict[str, int] = {}
    for node_id, payload in raw.items():
        key = str(node_id)
        if isinstance(payload, Mapping):
            if "positive_outcome_ratio" in payload:
                ratio_by_node[key] = _clamp(
                    _as_float(payload.get("positive_outcome_ratio", 0.0)),
                    lower=0.0,
                    upper=1.0,
                )
            if "reinforced_edge_count" in payload:
                reinforced_by_node[key] = max(
                    0,
                    int(_as_float(payload.get("reinforced_edge_count", 0.0))),
                )
            continue
        ratio_by_node[key] = _clamp(_as_float(payload), lower=0.0, upper=1.0)
    return ratio_by_node, reinforced_by_node


async def _list_outcomes_for_node(*, graph: Any, node_id: UUID) -> list[Any]:
    for method_name in ("list_outcomes_for_node", "get_outcomes_for_node", "outcomes_for_node"):
        method = getattr(graph, method_name, None)
        if not callable(method):
            continue
        result = await _maybe_await(method(str(node_id)))
        if result is None:
            return []
        if isinstance(result, Sequence) and not isinstance(result, (str, bytes, bytearray)):
            return list(result)
    return []


async def _list_edges_for_node(*, graph: Any, node_id: UUID) -> list[Any]:
    for method_name in ("get_edges_for_node", "list_edges_for_node", "edges_for_node"):
        method = getattr(graph, method_name, None)
        if not callable(method):
            continue
        result = await _maybe_await(method(str(node_id)))
        if result is None:
            return []
        if isinstance(result, Sequence) and not isinstance(result, (str, bytes, bytearray)):
            return list(result)
    return []


async def _get_node_by_id(*, graph: Any, node_id: UUID | str) -> Any | None:
    node_id_text = str(node_id)
    for method_name in ("get_node", "node_by_id", "fetch_node"):
        method = getattr(graph, method_name, None)
        if not callable(method):
            continue
        node = await _maybe_await(method(node_id_text))
        if node is not None:
            return node
    return None


async def _node_tier_for_id(*, graph: Any, node_id: str | None) -> str | None:
    if not node_id:
        return None
    record = await _get_node_by_id(graph=graph, node_id=node_id)
    if record is None:
        return None
    tier_value = _mapping_or_attr_value(record, key="memory_tier", default=MemoryTier.SHORT_TERM.value)
    return str(getattr(tier_value, "value", tier_value))


async def _update_node(*, graph: Any, node_id: UUID | str, payload: Mapping[str, Any]) -> None:
    node_id_text = str(node_id)
    normalized_payload = dict(payload)
    memory_tier = normalized_payload.get("memory_tier")
    if memory_tier is not None:
        normalized_payload["memory_tier"] = str(getattr(memory_tier, "value", memory_tier))

    update_node = getattr(graph, "update_node", None)
    if callable(update_node):
        await _maybe_await(update_node(node_id_text, normalized_payload))
        return

    update_node_tier = getattr(graph, "update_node_tier", None)
    if callable(update_node_tier):
        await _maybe_await(
            update_node_tier(
                node_id_text,
                MemoryTier.LONG_TERM.value,
                normalized_payload.get("graduated_at"),
                int(normalized_payload.get("graduation_access_count", 0)),
            )
        )
        return

    raise AttributeError("graph must implement node update methods for graduation transfer")


async def _update_edge(*, graph: Any, edge_id: str, payload: Mapping[str, Any]) -> None:
    method = getattr(graph, "update_edge", None)
    if not callable(method):
        raise AttributeError("graph must implement update_edge(edge_id, payload)")
    await _maybe_await(method(str(edge_id), dict(payload)))


async def _begin_node_transaction(graph: Any) -> bool:
    for method_name in ("begin_transaction", "begin"):
        method = getattr(graph, method_name, None)
        if callable(method):
            await _maybe_await(method())
            return True
    return False


async def _commit_node_transaction(graph: Any, *, started: bool) -> None:
    if not started:
        return
    for method_name in ("commit_transaction", "commit"):
        method = getattr(graph, method_name, None)
        if callable(method):
            await _maybe_await(method())
            return


async def _rollback_node_transaction(graph: Any, *, started: bool) -> None:
    if not started:
        return
    for method_name in ("rollback_transaction", "rollback"):
        method = getattr(graph, method_name, None)
        if callable(method):
            await _maybe_await(method())
            return


async def _restore_node_state(
    *,
    graph: Any,
    node_id: UUID,
    node_snapshot: Mapping[str, Any],
) -> None:
    try:
        await _update_node(graph=graph, node_id=node_id, payload=node_snapshot)
    except Exception:
        return


async def _restore_edge_states(
    *,
    graph: Any,
    edge_snapshots: Mapping[str, Mapping[str, Any]],
) -> None:
    for edge_id in sorted(edge_snapshots):
        try:
            await _update_edge(graph=graph, edge_id=edge_id, payload=edge_snapshots[edge_id])
        except Exception:
            continue


def _normalize_nodes(value: Any) -> list[Node]:
    if value is None:
        return []
    if not isinstance(value, Sequence) or isinstance(value, (str, bytes, bytearray)):
        return []
    normalized: list[Node] = []
    for node in value:
        if isinstance(node, Node):
            normalized.append(node)
    return normalized


def _node_snapshot(node_record: Any) -> dict[str, Any]:
    return {
        "memory_tier": _mapping_or_attr_value(
            node_record,
            key="memory_tier",
            default=MemoryTier.SHORT_TERM,
        ),
        "graduated_at": _mapping_or_attr_value(node_record, key="graduated_at", default=None),
        "graduation_access_count": int(
            _as_float(_mapping_or_attr_value(node_record, key="graduation_access_count", default=0))
        ),
    }


def _edge_identifier(edge: Any) -> str:
    return str(_mapping_or_attr_value(edge, key="id", default=""))


def _edge_state_snapshot(edge: Any) -> dict[str, Any]:
    return {
        "is_cross_tier": bool(_mapping_or_attr_value(edge, key="is_cross_tier", default=False)),
        "pruned_at_graduation": bool(
            _mapping_or_attr_value(edge, key="pruned_at_graduation", default=False)
        ),
    }


def _other_node_id(*, edge: Any, node_id: UUID) -> str | None:
    node_a = str(_mapping_or_attr_value(edge, key="node_a", default=""))
    node_b = str(_mapping_or_attr_value(edge, key="node_b", default=""))
    current = str(node_id)
    if node_a == current:
        return node_b or None
    if node_b == current:
        return node_a or None
    return None


def _age_hours(created_at: datetime, now: datetime) -> float:
    created = _to_utc_datetime(created_at)
    delta_seconds = (now - created).total_seconds()
    if delta_seconds <= 0:
        return 0.0
    return delta_seconds / 3600.0


def _to_utc_datetime(value: datetime) -> datetime:
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc)


def _mapping_or_attr_value(item: Any, *, key: str, default: Any) -> Any:
    if isinstance(item, Mapping):
        return item.get(key, default)
    return getattr(item, key, default)


def _tier_value(node: Node) -> str:
    tier = node.memory_tier
    return str(getattr(tier, "value", tier))


def _as_uuid(value: Any) -> UUID:
    text = str(value)
    try:
        return UUID(text)
    except (TypeError, ValueError, AttributeError):
        return uuid5(NAMESPACE_URL, text)


def _as_float(value: Any) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _clamp(value: float, *, lower: float, upper: float) -> float:
    return max(lower, min(upper, float(value)))


async def _maybe_await(value: Any) -> Any:
    if inspect.isawaitable(value):
        return await value
    return value


__all__ = [
    "GraduationEligibility",
    "GraduationEngine",
    "GraduationReport",
    "GraduationTransferReport",
]
