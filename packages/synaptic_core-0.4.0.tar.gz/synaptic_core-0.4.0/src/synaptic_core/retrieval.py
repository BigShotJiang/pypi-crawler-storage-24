"""Retrieval engine primitives for Phase 2."""

from __future__ import annotations

from dataclasses import dataclass, field
import time
from typing import Any, Callable, Mapping, Sequence
from uuid import UUID, uuid4

from .backends.base import MemoryBackend
from .models import Node, RetrievalResult
from .retrieval_utils import (
    RankedResult,
    as_float,
    as_uuid,
    clamp,
    coerce_ranked_results,
    coerce_source_type,
    node_tier_value,
)


@dataclass(frozen=True)
class ConfidenceMergeResult:
    ranked_results: list[RankedResult]
    activation_weight_applied: float
    activation_sourced_node_ids: list[str]
    fusion_only_node_ids: list[str]


@dataclass(frozen=True)
class ActivationHookResult:
    ranked_results: list[RankedResult] = field(default_factory=list)
    activation_path: list[dict[str, Any]] = field(default_factory=list)
    seed_node_ids: list[str] = field(default_factory=list)
    seed_nodes_contributed: list[str] = field(default_factory=list)
    seed_nodes_dead_ends: list[str] = field(default_factory=list)
    cross_tier_traversals: int = 0


@dataclass(frozen=True)
class RetrievalPreparation:
    query_id: UUID
    query_text: str
    top_k: int
    keyword_results: list[RankedResult]
    semantic_results: list[RankedResult]
    fusion_results: list[RankedResult]
    overlap_count: int
    graph_confidence: float
    retrieval_latency_ms: float


@dataclass(frozen=True)
class RetrievalExecution:
    prepared: RetrievalPreparation
    activation: ActivationHookResult
    merged: ConfidenceMergeResult
    nodes: list[Node]
    result: RetrievalResult
    activation_latency_ms: float


def reciprocal_rank_fusion(
    keyword_results: Sequence[RankedResult],
    semantic_results: Sequence[RankedResult],
    *,
    k: int = 60,
    top_k: int | None = None,
) -> list[RankedResult]:
    """Fuse keyword/semantic rankings with deterministic Reciprocal Rank Fusion."""
    if k < 0:
        raise ValueError("k must be >= 0")
    if top_k is not None and top_k < 0:
        raise ValueError("top_k must be >= 0 when provided")

    scores: dict[str, float] = {}

    for rank, node_id in _unique_ranked_node_ids(keyword_results):
        scores[node_id] = scores.get(node_id, 0.0) + 1.0 / (k + rank + 1)

    for rank, node_id in _unique_ranked_node_ids(semantic_results):
        scores[node_id] = scores.get(node_id, 0.0) + 1.0 / (k + rank + 1)

    fused = sorted(scores.items(), key=lambda item: (-item[1], item[0]))
    if top_k is None:
        return fused
    return fused[:top_k]


def _unique_ranked_node_ids(results: Sequence[RankedResult]) -> list[tuple[int, str]]:
    ranked: list[tuple[int, str]] = []
    seen: set[str] = set()
    for rank, (node_id, _score) in enumerate(results):
        normalized = str(node_id)
        if normalized in seen:
            continue
        seen.add(normalized)
        ranked.append((rank, normalized))
    return ranked


def merge_with_confidence(
    *,
    fusion_results: Sequence[RankedResult],
    activation_results: Sequence[RankedResult],
    graph_confidence: float,
    top_k: int | None = None,
) -> ConfidenceMergeResult:
    """Merge fusion and activation rankings according to PRD confidence bands."""
    if top_k is not None and top_k < 0:
        raise ValueError("top_k must be >= 0 when provided")

    confidence = clamp(float(graph_confidence), lower=0.0, upper=1.0)
    fusion_unique = _unique_results(fusion_results)
    activation_unique = _unique_results(activation_results)
    fusion_ids = {node_id for node_id, _ in fusion_unique}
    activation_ids = {node_id for node_id, _ in activation_unique}
    fusion_only_ids = [node_id for node_id, _ in fusion_unique if node_id not in activation_ids]

    if confidence <= 0.0:
        ranked = list(fusion_unique)
        activation_weight = 0.0
    elif confidence < 0.3:
        ranked = _merge_low_confidence(
            fusion_unique=fusion_unique,
            activation_unique=activation_unique,
        )
        activation_weight = confidence
    elif confidence < 0.7:
        ranked = _merge_medium_confidence(
            fusion_unique=fusion_unique,
            activation_unique=activation_unique,
            confidence=confidence,
        )
        activation_weight = confidence
    else:
        ranked = _merge_high_confidence(
            fusion_unique=fusion_unique,
            activation_unique=activation_unique,
        )
        activation_weight = 1.0

    if top_k is not None:
        ranked = ranked[:top_k]

    activation_sourced_ids = [
        node_id
        for node_id, _score in ranked
        if node_id in activation_ids and node_id not in fusion_ids
    ]

    return ConfidenceMergeResult(
        ranked_results=ranked,
        activation_weight_applied=activation_weight,
        activation_sourced_node_ids=activation_sourced_ids,
        fusion_only_node_ids=fusion_only_ids,
    )


def _unique_results(results: Sequence[RankedResult]) -> list[RankedResult]:
    ranked: list[RankedResult] = []
    seen: set[str] = set()
    for node_id, score in results:
        normalized = str(node_id)
        if normalized in seen:
            continue
        seen.add(normalized)
        ranked.append((normalized, float(score)))
    return ranked


def _normalize_scores(results: Sequence[RankedResult]) -> dict[str, float]:
    if not results:
        return {}
    scores = {node_id: float(score) for node_id, score in results}
    max_score = max(scores.values())
    if max_score <= 0.0:
        return {node_id: 0.0 for node_id in scores}
    return {node_id: score / max_score for node_id, score in scores.items()}


def _merge_low_confidence(
    *,
    fusion_unique: Sequence[RankedResult],
    activation_unique: Sequence[RankedResult],
) -> list[RankedResult]:
    ranked = list(fusion_unique)
    fusion_ids = {node_id for node_id, _ in fusion_unique}
    activation_only = [
        (node_id, score) for node_id, score in activation_unique if node_id not in fusion_ids
    ]
    activation_only.sort(key=lambda item: (-item[1], item[0]))
    ranked.extend(activation_only)
    return ranked


def _merge_medium_confidence(
    *,
    fusion_unique: Sequence[RankedResult],
    activation_unique: Sequence[RankedResult],
    confidence: float,
) -> list[RankedResult]:
    fusion_norm = _normalize_scores(fusion_unique)
    activation_norm = _normalize_scores(activation_unique)
    # Blend both channels for every seen node id so ranking shifts smoothly as confidence rises.
    all_ids = sorted(set(fusion_norm).union(activation_norm))

    blended = [
        (
            node_id,
            (1.0 - confidence) * fusion_norm.get(node_id, 0.0)
            + confidence * activation_norm.get(node_id, 0.0),
        )
        for node_id in all_ids
    ]
    blended.sort(key=lambda item: (-item[1], item[0]))
    return blended


def _merge_high_confidence(
    *,
    fusion_unique: Sequence[RankedResult],
    activation_unique: Sequence[RankedResult],
) -> list[RankedResult]:
    activation_ranked = sorted(activation_unique, key=lambda item: (-item[1], item[0]))
    activation_ids = {node_id for node_id, _ in activation_ranked}
    # High-confidence mode promotes activation-led results first, while preserving fusion-only recall.
    fusion_only = [
        (node_id, score) for node_id, score in fusion_unique if node_id not in activation_ids
    ]
    return [*activation_ranked, *fusion_only]


def build_retrieval_telemetry_payload(
    *,
    query_id: UUID,
    keyword_results: Sequence[RankedResult],
    semantic_results: Sequence[RankedResult],
    fusion_results: Sequence[RankedResult],
    overlap_count: int,
    top_k: int,
    graph_confidence: float,
    activation_weight_applied: float,
    retrieval_latency_ms: float,
) -> dict[str, Any]:
    return {
        "query_id": str(query_id),
        "semantic_candidate_count": len(semantic_results),
        "keyword_candidate_count": len(keyword_results),
        "overlap_count": max(0, int(overlap_count)),
        "fusion_top_k": max(0, int(top_k)),
        "fusion_scores": [
            {"node_id": node_id, "score": float(score)} for node_id, score in fusion_results[:top_k]
        ],
        "graph_confidence": clamp(float(graph_confidence), lower=0.0, upper=1.0),
        "activation_weight_applied": clamp(float(activation_weight_applied), lower=0.0, upper=1.0),
        "retrieval_latency_ms": max(0.0, float(retrieval_latency_ms)),
    }


def build_activation_telemetry_payload(
    *,
    query_id: UUID,
    activation: Any,
    activation_sourced_node_ids: Sequence[str],
    fusion_only_node_ids: Sequence[str],
    short_term_node_ids: Sequence[UUID | str],
    long_term_node_ids: Sequence[UUID | str],
    activation_latency_ms: float,
) -> dict[str, Any]:
    return {
        "query_id": str(query_id),
        "seed_node_ids": [str(node_id) for node_id in activation.seed_node_ids],
        "activation_steps": len(activation.activation_path),
        "nodes_visited": len({str(node_id) for node_id, _ in activation.ranked_results}),
        "nodes_above_threshold": len(activation.ranked_results),
        "final_node_ids": [str(node_id) for node_id, _ in activation.ranked_results],
        "activation_sourced_node_ids": [str(node_id) for node_id in activation_sourced_node_ids],
        "fusion_only_node_ids": [str(node_id) for node_id in fusion_only_node_ids],
        "short_term_node_ids": [str(node_id) for node_id in short_term_node_ids],
        "long_term_node_ids": [str(node_id) for node_id in long_term_node_ids],
        "cross_tier_traversals": max(0, int(activation.cross_tier_traversals)),
        "activation_path": list(activation.activation_path),
        "seed_nodes_contributed": [str(node_id) for node_id in activation.seed_nodes_contributed],
        "seed_nodes_dead_ends": [str(node_id) for node_id in activation.seed_nodes_dead_ends],
        "activation_latency_ms": max(0.0, float(activation_latency_ms)),
    }


def prepare_retrieval(
    *,
    query: str,
    embedding: Sequence[float],
    top_k: int,
    backend: MemoryBackend,
    graph_confidence: float,
    fusion_k: int = 60,
    query_id: str | UUID | None = None,
) -> RetrievalPreparation:
    normalized_query = str(query or "").strip()
    if not normalized_query:
        raise ValueError("query is required")
    if top_k <= 0:
        raise ValueError("top_k must be > 0")

    resolved_query_id = as_uuid(query_id) if query_id is not None else uuid4()
    retrieval_start = time.perf_counter()
    keyword_raw = backend.keyword_search(normalized_query, top_k=top_k)
    semantic_raw = backend.semantic_search(embedding, top_k=top_k)
    keyword_results = coerce_ranked_results(keyword_raw)
    semantic_results = coerce_ranked_results(semantic_raw)
    fusion_results = reciprocal_rank_fusion(
        keyword_results,
        semantic_results,
        k=fusion_k,
        top_k=None,
    )
    retrieval_latency_ms = max(0.0, (time.perf_counter() - retrieval_start) * 1000.0)
    overlap_count = len(
        {node_id for node_id, _ in keyword_results}.intersection(
            {node_id for node_id, _ in semantic_results}
        )
    )
    return RetrievalPreparation(
        query_id=resolved_query_id,
        query_text=normalized_query,
        top_k=top_k,
        keyword_results=keyword_results,
        semantic_results=semantic_results,
        fusion_results=fusion_results,
        overlap_count=overlap_count,
        graph_confidence=float(graph_confidence),
        retrieval_latency_ms=retrieval_latency_ms,
    )


def finalize_retrieval(
    *,
    prepared: RetrievalPreparation,
    activation: Any,
    activation_latency_ms: float,
    load_nodes: Callable[[Sequence[str]], list[Node]],
) -> RetrievalExecution:
    activation_result = _coerce_activation_result(activation)
    merged = merge_with_confidence(
        fusion_results=prepared.fusion_results,
        activation_results=activation_result.ranked_results,
        graph_confidence=prepared.graph_confidence,
        top_k=prepared.top_k,
    )
    ranked_node_ids = [node_id for node_id, _score in merged.ranked_results]
    nodes = load_nodes(ranked_node_ids)
    resolved_activation_latency_ms = max(0.0, float(activation_latency_ms))

    short_term_node_ids = [node.id for node in nodes if node_tier_value(node) == "short_term"]
    long_term_node_ids = [node.id for node in nodes if node_tier_value(node) == "long_term"]

    result = RetrievalResult(
        query_id=prepared.query_id,
        nodes=nodes,
        activation_path=activation_result.activation_path,
        seed_node_ids=[as_uuid(node_id) for node_id in activation_result.seed_node_ids],
        seed_nodes_contributed=[as_uuid(node_id) for node_id in activation_result.seed_nodes_contributed],
        seed_nodes_dead_ends=[as_uuid(node_id) for node_id in activation_result.seed_nodes_dead_ends],
        retrieval_latency_ms=prepared.retrieval_latency_ms,
        activation_latency_ms=resolved_activation_latency_ms,
        graph_confidence=clamp(prepared.graph_confidence, lower=0.0, upper=1.0),
        activation_weight_applied=merged.activation_weight_applied,
        activation_sourced_node_ids=[as_uuid(node_id) for node_id in merged.activation_sourced_node_ids],
        fusion_only_node_ids=[as_uuid(node_id) for node_id in merged.fusion_only_node_ids],
        short_term_node_ids=short_term_node_ids,
        long_term_node_ids=long_term_node_ids,
        cross_tier_traversals=max(0, int(activation_result.cross_tier_traversals)),
    )
    return RetrievalExecution(
        prepared=prepared,
        activation=activation_result,
        merged=merged,
        nodes=nodes,
        result=result,
        activation_latency_ms=resolved_activation_latency_ms,
    )


class RetrievalEngine:
    """Legacy adapter that delegates to the canonical retrieval pipeline."""

    def __init__(
        self,
        *,
        fusion_k: int = 60,
        backend: MemoryBackend | None = None,
        graph: Any | None = None,
        activation_hook: Callable[..., ActivationHookResult | Mapping[str, Any]] | None = None,
        telemetry_collector: Any | None = None,
    ) -> None:
        if fusion_k < 0:
            raise ValueError("fusion_k must be >= 0")
        self._fusion_k = fusion_k
        self._backend = backend
        self._graph = graph
        self._activation_hook = activation_hook
        self._telemetry_collector = telemetry_collector

    @property
    def fusion_k(self) -> int:
        return self._fusion_k

    def fuse_rankings(
        self,
        keyword_results: Sequence[RankedResult],
        semantic_results: Sequence[RankedResult],
        *,
        top_k: int | None = None,
    ) -> list[RankedResult]:
        return reciprocal_rank_fusion(
            keyword_results,
            semantic_results,
            k=self._fusion_k,
            top_k=top_k,
        )

    def merge_with_confidence(
        self,
        *,
        fusion_results: Sequence[RankedResult],
        activation_results: Sequence[RankedResult],
        graph_confidence: float,
        top_k: int | None = None,
    ) -> ConfidenceMergeResult:
        return merge_with_confidence(
            fusion_results=fusion_results,
            activation_results=activation_results,
            graph_confidence=graph_confidence,
            top_k=top_k,
        )

    def retrieve(
        self,
        *,
        query: str,
        embedding: Sequence[float],
        top_k: int = 10,
        query_id: str | UUID | None = None,
    ) -> RetrievalResult:
        if self._backend is None:
            raise RuntimeError("RetrievalEngine requires a backend to execute retrieve()")
        prepared = prepare_retrieval(
            query=query,
            embedding=embedding,
            top_k=top_k,
            backend=self._backend,
            graph_confidence=self._compute_graph_confidence(),
            fusion_k=self._fusion_k,
            query_id=query_id,
        )

        activation_start = time.perf_counter()
        activation = self._run_activation_hook(
            query=prepared.query_text,
            embedding=embedding,
            top_k=top_k,
            fusion_results=prepared.fusion_results,
        )
        activation_latency_ms = max(0.0, (time.perf_counter() - activation_start) * 1000.0)
        execution = finalize_retrieval(
            prepared=prepared,
            activation=activation,
            activation_latency_ms=activation_latency_ms,
            load_nodes=self._load_nodes,
        )
        self._record_retrieval_telemetry(
            query_id=prepared.query_id,
            keyword_results=prepared.keyword_results,
            semantic_results=prepared.semantic_results,
            fusion_results=prepared.fusion_results,
            overlap_count=prepared.overlap_count,
            top_k=top_k,
            graph_confidence=prepared.graph_confidence,
            activation_weight_applied=execution.merged.activation_weight_applied,
            retrieval_latency_ms=prepared.retrieval_latency_ms,
        )
        self._record_activation_telemetry(
            query_id=prepared.query_id,
            activation=execution.activation,
            merged=execution.merged,
            short_term_node_ids=execution.result.short_term_node_ids,
            long_term_node_ids=execution.result.long_term_node_ids,
            activation_latency_ms=activation_latency_ms,
        )
        return execution.result

    def _compute_graph_confidence(self) -> float:
        if self._graph is None:
            return 0.0
        compute = getattr(self._graph, "compute_graph_confidence", None)
        if not callable(compute):
            return 0.0
        return float(compute())

    def _run_activation_hook(self, **kwargs: Any) -> ActivationHookResult:
        if self._activation_hook is None:
            return ActivationHookResult()
        raw = self._activation_hook(**kwargs)
        return _coerce_activation_result(raw)

    def _load_nodes(self, ranked_node_ids: Sequence[str]) -> list[Node]:
        if self._backend is None:
            return []
        nodes: list[Node] = []
        for node_id in ranked_node_ids:
            record = self._backend.get_node(str(node_id))
            if not record:
                continue
            embedding = [float(value) for value in record.get("embedding", [])]
            node = Node(
                id=as_uuid(record.get("id", node_id)),
                content=str(record.get("content", "")),
                embedding=embedding,
                memory_type=str(record.get("memory_type", "contextual")),
                memory_tier=str(record.get("memory_tier", "short_term")),
                external_id=record.get("external_id"),
                source_type=coerce_source_type(record.get("source_type")),
                activation_energy=float(record.get("activation_energy", 1.0)),
                access_count=int(record.get("access_count", 0)),
            )
            nodes.append(node)
        return nodes

    def _record_retrieval_telemetry(
        self,
        *,
        query_id: UUID,
        keyword_results: Sequence[RankedResult],
        semantic_results: Sequence[RankedResult],
        fusion_results: Sequence[RankedResult],
        overlap_count: int,
        top_k: int,
        graph_confidence: float,
        activation_weight_applied: float,
        retrieval_latency_ms: float,
    ) -> None:
        collector = self._telemetry_collector
        if collector is None:
            return
        payload = build_retrieval_telemetry_payload(
            query_id=query_id,
            keyword_results=keyword_results,
            semantic_results=semantic_results,
            fusion_results=fusion_results,
            overlap_count=overlap_count,
            top_k=top_k,
            graph_confidence=graph_confidence,
            activation_weight_applied=activation_weight_applied,
            retrieval_latency_ms=retrieval_latency_ms,
        )
        self._safe_telemetry_call("record_retrieval", payload)

    def _record_activation_telemetry(
        self,
        *,
        query_id: UUID,
        activation: ActivationHookResult,
        merged: ConfidenceMergeResult,
        short_term_node_ids: Sequence[UUID],
        long_term_node_ids: Sequence[UUID],
        activation_latency_ms: float,
    ) -> None:
        collector = self._telemetry_collector
        if collector is None:
            return
        payload = build_activation_telemetry_payload(
            query_id=query_id,
            activation=activation,
            activation_sourced_node_ids=merged.activation_sourced_node_ids,
            fusion_only_node_ids=merged.fusion_only_node_ids,
            short_term_node_ids=short_term_node_ids,
            long_term_node_ids=long_term_node_ids,
            activation_latency_ms=activation_latency_ms,
        )
        self._safe_telemetry_call("record_activation", payload)

    def _safe_telemetry_call(self, method_name: str, payload: Mapping[str, Any]) -> None:
        collector = self._telemetry_collector
        if collector is None:
            return
        method = getattr(collector, method_name, None)
        if not callable(method):
            return
        try:
            method(payload)
        except Exception:
            return


def _coerce_activation_result(value: ActivationHookResult | Mapping[str, Any] | Any) -> ActivationHookResult:
    if isinstance(value, ActivationHookResult):
        return value

    if isinstance(value, Mapping):
        ranked_raw = value.get("ranked_results", [])
        activation_path_raw = value.get("activation_path", [])
        seed_node_ids = value.get("seed_node_ids", [])
        seed_nodes_contributed = value.get("seed_nodes_contributed", [])
        seed_nodes_dead_ends = value.get("seed_nodes_dead_ends", [])
        cross_tier_traversals = value.get("cross_tier_traversals", 0)
    else:
        ranked_raw = getattr(value, "ranked_results", [])
        activation_path_raw = getattr(value, "activation_path", [])
        seed_node_ids = getattr(value, "seed_node_ids", [])
        seed_nodes_contributed = getattr(value, "seed_nodes_contributed", [])
        seed_nodes_dead_ends = getattr(value, "seed_nodes_dead_ends", [])
        cross_tier_traversals = getattr(value, "cross_tier_traversals", 0)

    ranked = coerce_ranked_results(ranked_raw)
    activation_path = [
        dict(step) for step in activation_path_raw if isinstance(step, Mapping)
    ]

    return ActivationHookResult(
        ranked_results=ranked,
        activation_path=activation_path,
        seed_node_ids=[str(item) for item in seed_node_ids],
        seed_nodes_contributed=[str(item) for item in seed_nodes_contributed],
        seed_nodes_dead_ends=[str(item) for item in seed_nodes_dead_ends],
        cross_tier_traversals=int(as_float(cross_tier_traversals, default=0.0)),
    )


__all__ = [
    "ActivationHookResult",
    "ConfidenceMergeResult",
    "RankedResult",
    "RetrievalExecution",
    "RetrievalEngine",
    "RetrievalPreparation",
    "build_activation_telemetry_payload",
    "build_retrieval_telemetry_payload",
    "finalize_retrieval",
    "merge_with_confidence",
    "prepare_retrieval",
    "reciprocal_rank_fusion",
]
