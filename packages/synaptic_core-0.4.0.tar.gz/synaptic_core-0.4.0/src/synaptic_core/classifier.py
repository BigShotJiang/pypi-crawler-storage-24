"""Rule-based memory type classifier for MVP behavior."""

from __future__ import annotations

import re
from typing import Mapping

from .types import MemoryType

_TOKEN_PATTERN = re.compile(r"[a-z0-9']+")
_DATE_PATTERN = re.compile(
    r"\b(?:\d{1,2}[/-]\d{1,2}(?:[/-]\d{2,4})?|\d{4}-\d{2}-\d{2})\b"
)

_PROCEDURAL_MARKERS = (
    "how to",
    "step ",
    "first ",
    "then ",
    "finally ",
)
_PROCEDURAL_ACTION_VERBS = {
    "add",
    "build",
    "check",
    "configure",
    "create",
    "deploy",
    "install",
    "open",
    "restart",
    "run",
    "set",
    "update",
    "use",
    "write",
}
_FACTUAL_COPULA_MARKERS = (
    " is ",
    " are ",
    " means ",
    " defined as ",
)
_EPISODIC_TIME_MARKERS = (
    "yesterday",
    "last ",
    "earlier ",
    "ago",
    "at ",
    "on ",
)
_EPISODIC_FIRST_PERSON_MARKERS = (
    " i ",
    " we ",
    " my ",
    " our ",
)


class MemoryTypeClassifier:
    """Classify memory text into MVP core types with override support."""

    def classify(self, content: str, context: Mapping[str, object] | None = None) -> str:
        explicit = self._explicit_override(context=context)
        if explicit is not None:
            return explicit

        normalized = self._normalize_text(content)
        if self._is_procedural(normalized):
            return MemoryType.PROCEDURAL
        if self._is_episodic(normalized):
            return MemoryType.EPISODIC
        if self._is_factual(normalized):
            return MemoryType.FACTUAL
        return MemoryType.CONTEXTUAL

    @staticmethod
    def _explicit_override(context: Mapping[str, object] | None) -> str | None:
        if not context:
            return None
        value = context.get("memory_type")
        if value is None:
            return None
        explicit = str(value).strip()
        if not explicit:
            return None
        return explicit

    @staticmethod
    def _normalize_text(content: str) -> str:
        stripped = str(content or "").strip().lower()
        if not stripped:
            return ""
        return f" {stripped} "

    def _is_procedural(self, normalized: str) -> bool:
        if not normalized:
            return False
        if any(marker in normalized for marker in _PROCEDURAL_MARKERS):
            return True
        first_token = self._first_token(normalized)
        if first_token in _PROCEDURAL_ACTION_VERBS:
            return True
        return False

    def _is_episodic(self, normalized: str) -> bool:
        if not normalized:
            return False
        has_first_person = any(marker in normalized for marker in _EPISODIC_FIRST_PERSON_MARKERS)
        has_time_marker = any(marker in normalized for marker in _EPISODIC_TIME_MARKERS)
        has_past_verb = any(token.endswith("ed") for token in _TOKEN_PATTERN.findall(normalized))
        return has_first_person and (has_time_marker or has_past_verb)

    @staticmethod
    def _is_factual(normalized: str) -> bool:
        if not normalized:
            return False
        if any(marker in normalized for marker in _FACTUAL_COPULA_MARKERS):
            return True
        if _DATE_PATTERN.search(normalized):
            return True
        if any(char.isdigit() for char in normalized):
            return True
        return False

    @staticmethod
    def _first_token(normalized: str) -> str:
        tokens = _TOKEN_PATTERN.findall(normalized)
        if not tokens:
            return ""
        return tokens[0]
