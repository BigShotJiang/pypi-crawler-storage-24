"""Retrieve/feedback benchmark helpers for telemetry overhead tracking."""

from __future__ import annotations

import asyncio
from pathlib import Path
import time
from typing import Any

from ._engine import _SynapticEngine
from .telemetry import TelemetryCollector


def compare_telemetry_modes(
    *,
    workspace: str | Path,
    iterations: int = 64,
    warmup_iterations: int = 8,
    seed_nodes: int = 48,
) -> dict[str, dict[str, float | int]]:
    """Run the same retrieve/feedback load with telemetry on/off and return metrics."""
    root = Path(workspace)
    root.mkdir(parents=True, exist_ok=True)
    resolved_iterations = max(1, int(iterations))
    resolved_warmup = max(0, int(warmup_iterations))
    resolved_seed_nodes = max(4, int(seed_nodes))

    telemetry_on = asyncio.run(
        _run_mode(
            db_path=root / "benchmark-telemetry-on.db",
            telemetry_enabled=True,
            iterations=resolved_iterations,
            warmup_iterations=resolved_warmup,
            seed_nodes=resolved_seed_nodes,
        )
    )
    telemetry_off = asyncio.run(
        _run_mode(
            db_path=root / "benchmark-telemetry-off.db",
            telemetry_enabled=False,
            iterations=resolved_iterations,
            warmup_iterations=resolved_warmup,
            seed_nodes=resolved_seed_nodes,
        )
    )
    return {
        "telemetry_on": telemetry_on,
        "telemetry_off": telemetry_off,
    }


async def _run_mode(
    *,
    db_path: Path,
    telemetry_enabled: bool,
    iterations: int,
    warmup_iterations: int,
    seed_nodes: int,
) -> dict[str, float | int]:
    _delete_sqlite_files(db_path)
    collector: TelemetryCollector | None = None
    if telemetry_enabled:
        collector = TelemetryCollector(
            db_path=db_path,
            queue_maxsize=4096,
            commit_batch_size=64,
            commit_batch_interval_ms=200,
            retention_maintenance_interval_rows=2048,
            auto_start=False,
        )

    try:
        memory = _SynapticEngine(
            db_path=str(db_path),
            embedding_fn=_embedding_for,
            telemetry_collector=collector,
        )
        if collector is not None:
            collector.start()

        for idx in range(seed_nodes):
            await memory.remember(f"benchmark seed memory {idx}")

        base_size = _db_size_with_wal(db_path)
        retrieve_latencies_ms: list[float] = []
        feedback_latencies_ms: list[float] = []
        started = time.perf_counter()

        for idx in range(iterations + warmup_iterations):
            query = f"benchmark retrieval {idx % max(1, seed_nodes // 4)}"
            retrieve_start = time.perf_counter()
            retrieval = await memory.recall(query, top_k=6, session_id="benchmark-session")
            retrieve_elapsed_ms = max(0.0, (time.perf_counter() - retrieve_start) * 1000.0)

            feedback_start = time.perf_counter()
            await memory.feedback(
                retrieval.query_id,
                "explicit_positive",
                active_nodes=[node.id for node in retrieval.nodes],
            )
            feedback_elapsed_ms = max(0.0, (time.perf_counter() - feedback_start) * 1000.0)
            if idx >= warmup_iterations:
                retrieve_latencies_ms.append(retrieve_elapsed_ms)
                feedback_latencies_ms.append(feedback_elapsed_ms)

        if collector is not None:
            collector.flush(timeout=10.0)
            collector_stats = collector.stats
            dropped_writes = int(collector_stats["dropped_writes"])
            attempted_writes = int(collector_stats["queued_writes"]) + dropped_writes
            drop_rate = (
                float(dropped_writes) / float(attempted_writes) if attempted_writes > 0 else 0.0
            )
        else:
            drop_rate = 0.0

        duration_seconds = max(0.001, time.perf_counter() - started)
        final_size = _db_size_with_wal(db_path)
        observed_growth_bytes = max(0, final_size - base_size)
        growth_per_day = float(observed_growth_bytes) / duration_seconds * 86_400.0

        return {
            "iterations": int(iterations),
            "p95_retrieve_latency_ms": _p95(retrieve_latencies_ms),
            "p95_feedback_latency_ms": _p95(feedback_latencies_ms),
            "telemetry_drop_rate": float(drop_rate),
            "db_growth_bytes_observed": int(observed_growth_bytes),
            "db_growth_per_day_bytes": float(growth_per_day),
        }
    finally:
        if collector is not None:
            collector.stop()


def _delete_sqlite_files(db_path: Path) -> None:
    for suffix in ("", "-wal", "-shm"):
        target = Path(f"{db_path}{suffix}")
        if target.exists():
            target.unlink()


def _db_size_with_wal(db_path: Path) -> int:
    total = 0
    for suffix in ("", "-wal", "-shm"):
        target = Path(f"{db_path}{suffix}")
        if target.exists():
            total += target.stat().st_size
    return total


def _p95(values: list[float]) -> float:
    if not values:
        return 0.0
    ranked = sorted(float(value) for value in values)
    index = max(0, int(round(0.95 * (len(ranked) - 1))))
    return float(ranked[index])


def _embedding_for(text: str) -> list[float]:
    normalized = str(text).lower()
    token_count = float(len(normalized.split()))
    char_count = float(len(normalized))
    checksum = float(sum(ord(ch) for ch in normalized) % 257) / 100.0
    return [token_count, char_count / 100.0, checksum]


__all__ = ["compare_telemetry_modes"]
