"""Pydantic data models for Synaptic graph and retrieval payloads."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any
from uuid import UUID, uuid4

from pydantic import BaseModel, Field

from .types import (
    ConnectionType,
    FormationTrigger,
    MemoryTier,
    MemoryType,
    OutcomeSignalType,
    SourceType,
)


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


class Node(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    content: str
    embedding: list[float]
    memory_type: str = MemoryType.CONTEXTUAL
    memory_tier: MemoryTier = MemoryTier.SHORT_TERM
    created_at: datetime = Field(default_factory=_utc_now)
    last_accessed_at: datetime = Field(default_factory=_utc_now)
    access_count: int = Field(default=0, ge=0)
    activation_energy: float = Field(default=1.0, ge=0.0)
    staleness_signals: int = Field(default=0, ge=0)
    graduated_at: datetime | None = None
    graduation_access_count: int = Field(default=0, ge=0)
    external_id: str | None = None
    source_type: SourceType | None = None
    consolidated_from: list[UUID] = Field(default_factory=list)
    consolidation_candidate: bool = False


class Edge(BaseModel):
    id: UUID = Field(default_factory=uuid4)
    node_a: UUID
    node_b: UUID
    weight: float = Field(default=0.3, ge=0.0, le=1.0)
    connection_type: ConnectionType = ConnectionType.EXCITATORY
    formation_trigger: FormationTrigger
    activation_count: int = Field(default=0, ge=0)
    interference_score: float = Field(default=0.0, ge=0.0)
    formed_at: datetime = Field(default_factory=_utc_now)
    last_reinforced_at: datetime = Field(default_factory=_utc_now)
    initial_weight: float = Field(default=0.3, ge=0.0, le=1.0)
    is_cross_tier: bool = False
    pruned_at_graduation: bool = False


class OutcomeSignal(BaseModel):
    signal_type: OutcomeSignalType
    value: float = Field(ge=-1.0, le=1.0)
    confidence: float = Field(ge=0.0, le=1.0)
    raw_evidence: str | None = None


class CompositeOutcome(BaseModel):
    query_id: UUID
    signals: list[OutcomeSignal]
    composite_score: float = Field(ge=-1.0, le=1.0)
    composite_confidence: float = Field(ge=0.0, le=1.0)
    learning_gated: bool
    oscillation_detected: bool
    oscillating_edge_ids: list[UUID] = Field(default_factory=list)


class RetrievalResult(BaseModel):
    query_id: UUID
    nodes: list[Node]
    activation_path: list[dict[str, Any]]
    seed_node_ids: list[UUID]
    seed_nodes_contributed: list[UUID]
    seed_nodes_dead_ends: list[UUID]
    retrieval_latency_ms: float = Field(ge=0.0)
    activation_latency_ms: float = Field(ge=0.0)
    graph_confidence: float = Field(ge=0.0, le=1.0)
    activation_weight_applied: float = Field(ge=0.0, le=1.0)
    activation_sourced_node_ids: list[UUID]
    fusion_only_node_ids: list[UUID]
    short_term_node_ids: list[UUID]
    long_term_node_ids: list[UUID]
    cross_tier_traversals: int = Field(ge=0)


__all__ = [
    "CompositeOutcome",
    "Edge",
    "Node",
    "OutcomeSignal",
    "RetrievalResult",
]
