"""Shared retrieval helpers used across runtime and retrieval orchestration."""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any, Mapping
from uuid import NAMESPACE_URL, UUID, uuid5

from .types import SourceType

RankedResult = tuple[str, float]


def as_uuid(value: object) -> UUID:
    text = str(value)
    try:
        return UUID(text)
    except (TypeError, ValueError, AttributeError):
        return uuid5(NAMESPACE_URL, text)


def clamp(value: float, *, lower: float, upper: float) -> float:
    return max(lower, min(upper, float(value)))


def as_float(value: object, *, default: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return float(default)


def coerce_ranked_results(raw_results: Sequence[Any]) -> list[RankedResult]:
    ranked: list[RankedResult] = []
    for item in raw_results:
        if isinstance(item, Mapping):
            node_id = str(item.get("node_id", ""))
            if not node_id:
                continue
            ranked.append((node_id, as_float(item.get("score", 0.0))))
            continue
        if isinstance(item, (list, tuple)) and len(item) >= 2:
            ranked.append((str(item[0]), as_float(item[1])))
    return ranked


def coerce_source_type(value: object) -> SourceType | None:
    if value is None:
        return None
    if isinstance(value, SourceType):
        return value
    try:
        return SourceType(str(value))
    except ValueError:
        return None


def node_tier_value(node: Any) -> str:
    tier = getattr(node, "memory_tier", "")
    return str(getattr(tier, "value", tier))


__all__ = [
    "RankedResult",
    "as_float",
    "as_uuid",
    "clamp",
    "coerce_ranked_results",
    "coerce_source_type",
    "node_tier_value",
]
