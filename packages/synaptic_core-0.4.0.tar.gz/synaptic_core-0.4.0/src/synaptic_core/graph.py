"""Graph confidence primitives for Phase 2 retrieval."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping

DEFAULT_GRAPH_CONFIDENCE_WEIGHTS: dict[str, float] = {
    "node_density": 0.2,
    "edge_density": 0.3,
    "edge_quality": 0.3,
    "reinforcement": 0.2,
}


def _clamp(value: float, lower: float = 0.0, upper: float = 1.0) -> float:
    return max(lower, min(upper, value))


def _node_density_score(node_count: int) -> float:
    if node_count < 50:
        return 0.0
    if node_count < 200:
        return ((node_count - 50) / 150.0) * 0.5
    if node_count < 500:
        return 0.5 + ((node_count - 200) / 300.0) * 0.3
    return 1.0


def _edge_density_score(avg_edges_per_node: float) -> float:
    if avg_edges_per_node < 1.0:
        return 0.0
    if avg_edges_per_node < 3.0:
        return ((avg_edges_per_node - 1.0) / 2.0) * 0.5
    if avg_edges_per_node < 8.0:
        return 0.5 + ((avg_edges_per_node - 3.0) / 5.0) * 0.4
    return 1.0


def _edge_quality_score(avg_edge_weight: float) -> float:
    if avg_edge_weight < 0.35:
        return 0.0
    if avg_edge_weight < 0.6:
        return ((avg_edge_weight - 0.35) / 0.25) * 0.6
    return 1.0


def _reinforcement_score(avg_edge_activation_count: float) -> float:
    if avg_edge_activation_count < 2.0:
        return 0.0
    if avg_edge_activation_count < 10.0:
        return ((avg_edge_activation_count - 2.0) / 8.0) * 0.7
    return 1.0


@dataclass(frozen=True)
class GraphConfidenceComponents:
    node_density: float
    edge_density: float
    edge_quality: float
    reinforcement: float

    def as_dict(self) -> dict[str, float]:
        return {
            "node_density": float(self.node_density),
            "edge_density": float(self.edge_density),
            "edge_quality": float(self.edge_quality),
            "reinforcement": float(self.reinforcement),
        }


def aggregate_graph_confidence(
    components: GraphConfidenceComponents,
    *,
    weights: Mapping[str, float] | None = None,
) -> float:
    merged_weights = dict(DEFAULT_GRAPH_CONFIDENCE_WEIGHTS)
    if weights is not None:
        merged_weights.update({key: float(value) for key, value in weights.items()})

    score = (
        components.node_density * merged_weights["node_density"]
        + components.edge_density * merged_weights["edge_density"]
        + components.edge_quality * merged_weights["edge_quality"]
        + components.reinforcement * merged_weights["reinforcement"]
    )
    return _clamp(float(score))


class MemoryGraph:
    """Minimal graph-state container with confidence computation helpers."""

    def __init__(
        self,
        *,
        node_count: int = 0,
        edge_count: int = 0,
        avg_edge_weight: float = 0.3,
        avg_edge_activation_count: float = 0.0,
    ) -> None:
        self.node_count = max(0, int(node_count))
        self.edge_count = max(0, int(edge_count))
        self.avg_edge_weight = float(avg_edge_weight)
        self.avg_edge_activation_count = float(avg_edge_activation_count)

    @property
    def avg_edges_per_node(self) -> float:
        if self.node_count == 0:
            return 0.0
        return self.edge_count / float(self.node_count)

    def graph_confidence_components(self) -> GraphConfidenceComponents:
        return GraphConfidenceComponents(
            node_density=_clamp(_node_density_score(self.node_count)),
            edge_density=_clamp(_edge_density_score(self.avg_edges_per_node)),
            edge_quality=_clamp(_edge_quality_score(self.avg_edge_weight)),
            reinforcement=_clamp(_reinforcement_score(self.avg_edge_activation_count)),
        )

    def compute_graph_confidence(self) -> float:
        return aggregate_graph_confidence(self.graph_confidence_components())

    def confidence_suppression_diagnostic(
        self,
        *,
        query_count: int,
        min_queries: int = 200,
        suppression_threshold: float = 0.2,
    ) -> dict[str, object] | None:
        if query_count < min_queries:
            return None

        components = self.graph_confidence_components()
        confidence = aggregate_graph_confidence(components)
        if confidence >= suppression_threshold:
            return None

        component_scores = components.as_dict()
        suppressed_components = [
            name
            for name, score in component_scores.items()
            if float(score) < suppression_threshold
        ]
        if not suppressed_components:
            suppressed_components = [
                min(component_scores, key=component_scores.__getitem__)
            ]

        return {
            "warning": "graph confidence remains suppressed after minimum query threshold",
            "query_count": int(query_count),
            "graph_confidence": float(confidence),
            "suppression_threshold": float(suppression_threshold),
            "suppressed_components": sorted(suppressed_components),
            "component_scores": component_scores,
        }


def compute_graph_confidence(graph: MemoryGraph) -> float:
    return graph.compute_graph_confidence()


__all__ = [
    "DEFAULT_GRAPH_CONFIDENCE_WEIGHTS",
    "GraphConfidenceComponents",
    "MemoryGraph",
    "aggregate_graph_confidence",
    "compute_graph_confidence",
]
