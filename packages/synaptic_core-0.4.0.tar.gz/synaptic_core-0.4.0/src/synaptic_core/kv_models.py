"""KV/session contract models shared by engine and service modules."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any


@dataclass(frozen=True)
class KeyValueItem:
    key: str
    value: Any
    metadata: dict[str, Any] = field(default_factory=dict)
    score: float | None = None
    namespace: str | None = None
    created_at: datetime | None = None
    expires_at: datetime | None = None


@dataclass
class SessionVersionConflictError(RuntimeError):
    """Raised when optimistic session version checks fail."""

    message: str
    expected_version: int | None = None
    actual_version: int | None = None

    def __post_init__(self) -> None:
        super().__init__(self.message)


SESSION_PREFIX = "session:"

