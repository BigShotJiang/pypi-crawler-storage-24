"""Canonical Synaptic public package exports."""

from .api import Session, Synaptic
from .errors import SynapticError

__version__ = "0.4.0"

__all__ = [
    "Session",
    "Synaptic",
    "SynapticError",
    "__version__",
]
