"""Synaptic CLI."""

from __future__ import annotations

import argparse
import asyncio
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
import time
from typing import Any
from uuid import UUID

from . import __version__
from .api import Synaptic
from .errors import SynapticError
from .types import OutcomeSignalType


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)

    if not hasattr(args, "handler"):
        parser.print_help()
        return 0

    try:
        return int(args.handler(args))
    except SynapticError as exc:
        _print_json(exc.as_dict())
        return 2


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="synaptic", description=f"Synaptic v{__version__} CLI")
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")

    subparsers = parser.add_subparsers(dest="command")

    doctor = subparsers.add_parser("doctor", help="Run local environment and runtime health checks")
    doctor.add_argument("--db-path", default="synaptic.db")
    doctor.add_argument("--json", action="store_true", dest="as_json")
    doctor.set_defaults(handler=_cmd_doctor)

    stats = subparsers.add_parser("stats", help="Print runtime stats")
    _add_runtime_options(stats)
    stats.set_defaults(handler=_cmd_stats)

    graph = subparsers.add_parser("graph", help="Graph inspection commands")
    graph_sub = graph.add_subparsers(dest="graph_command")
    graph_status = graph_sub.add_parser("status", help="Print graph status metrics")
    _add_runtime_options(graph_status)
    graph_status.set_defaults(handler=_cmd_graph_status)

    sessions = subparsers.add_parser("sessions", help="Session inspection commands")
    sessions_sub = sessions.add_subparsers(dest="sessions_command")
    sessions_recent = sessions_sub.add_parser("recent", help="Print recent sessions")
    _add_runtime_options(sessions_recent)
    sessions_recent.add_argument("--limit", type=int, default=20)
    sessions_recent.set_defaults(handler=_cmd_sessions_recent)

    queries = subparsers.add_parser("queries", help="Query inspection commands")
    queries_sub = queries.add_subparsers(dest="queries_command")
    queries_recent = queries_sub.add_parser("recent", help="Print recent queries")
    _add_runtime_options(queries_recent)
    queries_recent.add_argument("--session-id", default=None)
    queries_recent.add_argument("--limit", type=int, default=20)
    queries_recent.set_defaults(handler=_cmd_queries_recent)

    outcomes = subparsers.add_parser("outcomes", help="Outcome inspection commands")
    outcomes_sub = outcomes.add_subparsers(dest="outcomes_command")
    outcomes_recent = outcomes_sub.add_parser("recent", help="Print recent outcomes")
    _add_runtime_options(outcomes_recent)
    outcomes_recent.add_argument("--session-id", default=None)
    outcomes_recent.add_argument("--limit", type=int, default=20)
    outcomes_recent.set_defaults(handler=_cmd_outcomes_recent)

    weekly_digest = subparsers.add_parser("weekly-digest", help="Print weekly digest summary")
    _add_runtime_options(weekly_digest)
    weekly_digest.add_argument("--force-refresh", action="store_true")
    weekly_digest.set_defaults(handler=_cmd_weekly_digest)

    return parser


def _add_runtime_options(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--db-path", default="synaptic.db")
    parser.add_argument("--json", action="store_true", dest="as_json")


@dataclass(slots=True)
class _DoctorCheck:
    name: str
    ok: bool
    detail: str


def _cmd_doctor(args: argparse.Namespace) -> int:
    checks: list[_DoctorCheck] = []
    start = time.perf_counter()

    checks.append(
        _DoctorCheck(
            name="python",
            ok=sys.version_info >= (3, 10),
            detail=sys.version.split()[0],
        )
    )

    db_path = Path(args.db_path).expanduser().resolve()
    db_parent = db_path.parent
    checks.append(
        _DoctorCheck(
            name="db_parent_writable",
            ok=db_parent.exists() and db_parent.is_dir(),
            detail=str(db_parent),
        )
    )

    async def _run_runtime_checks() -> tuple[bool, str]:
        client = Synaptic(db_path=str(db_path), embedding_fn=_default_embedding)
        session = client.session("doctor")
        node = await session.remember("doctor remember seed")
        retrieval = await session.recall("doctor seed", top_k=3)
        if retrieval.nodes:
            _ = await session.feedback(retrieval.query_id, outcome=OutcomeSignalType.EXPLICIT_POSITIVE)
        else:
            return False, "recall returned no nodes"
        _ = await client.stats()
        _ = await client.graph_status()
        _ = await client.sessions_recent(limit=5)
        _ = await client.queries_recent(session_id="doctor", limit=5)
        if not node.id:
            return False, "remember returned empty id"
        return True, "ready"

    runtime_ok = True
    runtime_detail = "ready"
    try:
        runtime_ok, runtime_detail = _run(_run_runtime_checks())
    except Exception as exc:  # pragma: no cover - defensive integration path
        runtime_ok = False
        runtime_detail = str(exc)

    checks.append(
        _DoctorCheck(
            name="remember_recall_feedback",
            ok=runtime_ok,
            detail=runtime_detail,
        )
    )

    elapsed = max(0.0, time.perf_counter() - start)
    payload = {
        "ok": all(check.ok for check in checks),
        "duration_seconds": round(elapsed, 3),
        "checks": [asdict(check) for check in checks],
    }

    if args.as_json:
        _print_json(payload)
    else:
        for check in checks:
            status = "OK" if check.ok else "FAIL"
            print(f"{status:4} {check.name}: {check.detail}")
        print(f"duration_seconds: {payload['duration_seconds']}")

    return 0 if payload["ok"] else 1


def _cmd_stats(args: argparse.Namespace) -> int:
    client = Synaptic(db_path=args.db_path, embedding_fn=_default_embedding)
    payload = _run(client.stats())
    return _emit(payload, as_json=bool(args.as_json))


def _cmd_graph_status(args: argparse.Namespace) -> int:
    client = Synaptic(db_path=args.db_path, embedding_fn=_default_embedding)
    payload = _run(client.graph_status())
    return _emit(payload, as_json=bool(args.as_json))


def _cmd_sessions_recent(args: argparse.Namespace) -> int:
    client = Synaptic(db_path=args.db_path, embedding_fn=_default_embedding)
    payload = _run(client.sessions_recent(limit=max(1, int(args.limit))))
    return _emit(payload, as_json=bool(args.as_json))


def _cmd_queries_recent(args: argparse.Namespace) -> int:
    client = Synaptic(db_path=args.db_path, embedding_fn=_default_embedding)
    payload = _run(
        client.queries_recent(
            session_id=args.session_id,
            limit=max(1, int(args.limit)),
        )
    )
    return _emit(payload, as_json=bool(args.as_json))


def _cmd_outcomes_recent(args: argparse.Namespace) -> int:
    client = Synaptic(db_path=args.db_path, embedding_fn=_default_embedding)
    payload = _run(
        client.outcomes_recent(
            session_id=args.session_id,
            limit=max(1, int(args.limit)),
        )
    )
    return _emit(payload, as_json=bool(args.as_json))


def _cmd_weekly_digest(args: argparse.Namespace) -> int:
    client = Synaptic(db_path=args.db_path, embedding_fn=_default_embedding)
    payload = _run(client.weekly_digest(force_refresh=bool(args.force_refresh)))
    return _emit(payload, as_json=bool(args.as_json))


def _emit(payload: Any, *, as_json: bool) -> int:
    if as_json:
        _print_json(payload)
    else:
        _print_json(payload)
    return 0


def _print_json(payload: Any) -> None:
    print(json.dumps(payload, indent=2, default=_json_default, sort_keys=True))


def _json_default(value: Any) -> Any:
    if isinstance(value, (datetime,)):
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        return value.isoformat()
    if isinstance(value, UUID):
        return str(value)
    raise TypeError(f"Object of type {type(value).__name__} is not JSON serializable")


def _default_embedding(text: str) -> list[float]:
    digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
    return [
        float(int(digest[0:8], 16) % 10_000) / 10_000.0,
        float(int(digest[8:16], 16) % 10_000) / 10_000.0,
        float(int(digest[16:24], 16) % 10_000) / 10_000.0,
    ]


def _run(coro: Any) -> Any:
    return asyncio.run(coro)


if __name__ == "__main__":
    raise SystemExit(main())
