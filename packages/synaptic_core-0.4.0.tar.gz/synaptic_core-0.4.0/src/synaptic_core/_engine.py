"""Public Synaptic memory API primitives."""

from __future__ import annotations

import asyncio
from datetime import datetime
import inspect
from pathlib import Path
from typing import Any, Callable, Mapping, Sequence
from uuid import UUID, uuid4

from .activation import ActivationEngine, ActivationResult
from .adaptive_tuning import AdaptiveTuning
from .backend_graph import BackendGraph
from .backends.base import MemoryBackend
from .backends.sqlite import SQLiteBackend
from .classifier import MemoryTypeClassifier
from .cross_tier import CrossTier
from .graph_ops import GraphOps
from .graduation import GraduationEngine
from .kv_models import KeyValueItem, SessionVersionConflictError
from .kv_session import KVSession
from .learning import ConnectionLearner
from .models import CompositeOutcome, Node, RetrievalResult
from .observability import Observability
from .optimizer import InstanceOptimizer
from .orchestration import FeedbackOrchestrator
from .outcome import OutcomeDetector
from .service_utils import (
    GraphStatusMetrics as _GraphStatusMetrics,
    NodeTelemetryState as _NodeTelemetryState,
    SessionMetrics as _SessionMetrics,
    WeeklyDigestEvent as _WeeklyDigestEvent,
    as_float as _svc_as_float,
    as_iso8601 as _svc_as_iso8601,
    as_uuid as _svc_as_uuid,
    clamp as _svc_clamp,
    coerce_metadata as _svc_coerce_metadata,
    coerce_outcome_signal as _svc_coerce_outcome_signal,
    coerce_source_type as _svc_coerce_source_type,
    coerce_utc as _svc_coerce_utc,
    confidence_band as _svc_confidence_band,
    edge_payload as _svc_edge_payload,
    embedding_hash as _svc_embedding_hash,
    keyword_score as _svc_keyword_score,
    mapping_get as _svc_mapping_get,
    mapping_set as _svc_mapping_set,
    metadata_matches as _svc_metadata_matches,
    node_tier as _svc_node_tier,
    normalize_namespace as _svc_normalize_namespace,
    pair_key as _svc_pair_key,
    parse_iso8601 as _svc_parse_iso8601,
    serialize_session_payload as _svc_serialize_session_payload,
    session_key as _svc_session_key,
    utc_now as _svc_utc_now,
)
from .retrieval_state import RetrievalState
from .runtime_engine import RuntimeEngine
from .types import (
    ConnectionType,
    FormationTrigger,
    MemoryTier,
    MemoryType,
    OutcomeSignalType,
    SourceType,
)

class _SynapticEngine:
    """Internal runtime engine for remember/recall/activate/feedback flows."""

    def __init__(
        self,
        *,
        db_path: str = "synaptic.db",
        embedding_fn: Callable[[str], Sequence[float] | Any] | None = None,
        backend: MemoryBackend | None = None,
        classifier: MemoryTypeClassifier | None = None,
        cross_tier_similarity_threshold: float = 0.75,
        cross_tier_initial_weight: float = 0.25,
        cross_tier_seed_top_k: int = 25,
        cross_tier_seed_max_edges: int | None = 8,
        top_k_retrieval: int = 10,
        top_k_activation_seeds: int = 5,
        telemetry_collector: Any | None = None,
        activation_engine: ActivationEngine | None = None,
        outcome_detector: OutcomeDetector | None = None,
        connection_learner: ConnectionLearner | None = None,
        deployment_id: str = "local",
        weekly_digest_cache_ttl_seconds: int = 300,
        graph_confidence_refresh_query_interval: int = 10,
        graduation_engine: GraduationEngine | Any | None = None,
        graduation_scheduler_enabled: bool = True,
        graduation_check_interval_queries: int = 10,
        graduation_check_interval_seconds: float = 86_400.0,
        graduation_min_access_count: int = 5,
        graduation_min_positive_outcome_ratio: float = 0.6,
        graduation_min_age_hours: float = 48.0,
        graduation_min_reinforced_edges: int = 2,
        graduation_reinforced_edge_weight_threshold: float = 0.45,
        graduation_edge_transfer_threshold: float = 0.40,
        instance_optimizer: InstanceOptimizer | None = None,
        instance_optimizer_enabled: bool = True,
        instance_optimizer_step_size: float = 0.005,
        instance_optimizer_min_sample_count: int = 10,
        instance_optimizer_update_interval: int = 5,
        session_deserializer: Callable[[dict[str, Any]], Any] | None = None,
    ) -> None:
        self._embedding_fn = embedding_fn
        self._classifier = classifier or MemoryTypeClassifier()
        self._cross_tier_similarity_threshold = float(cross_tier_similarity_threshold)
        self._cross_tier_initial_weight = float(cross_tier_initial_weight)
        self._cross_tier_seed_top_k = max(1, int(cross_tier_seed_top_k))
        if cross_tier_seed_max_edges is None:
            self._cross_tier_seed_max_edges: int | None = None
        else:
            self._cross_tier_seed_max_edges = max(1, int(cross_tier_seed_max_edges))
        self._top_k_retrieval = max(1, int(top_k_retrieval))
        self._top_k_activation_seeds = max(1, int(top_k_activation_seeds))
        self._telemetry_collector = telemetry_collector
        self._deployment_id = str(deployment_id or "local")
        self._provisional_edge_pairs: set[tuple[str, str]] = set()
        self._retrieval_history: dict[str, RetrievalResult] = {}
        self._query_sessions: dict[str, str] = {}
        self._session_query_ids: dict[str, list[str]] = {}
        self._session_metrics: dict[str, _SessionMetrics] = {}
        self._session_started_at: dict[str, datetime] = {}
        self._session_last_activity_at: dict[str, datetime] = {}
        self._node_telemetry_state: dict[str, _NodeTelemetryState] = {}
        self._total_queries = 0
        self._total_hits = 0
        self._total_misses = 0
        self._total_activation_steps = 0.0
        self._weekly_digest_cache_ttl_seconds = max(1, int(weekly_digest_cache_ttl_seconds))
        self._weekly_digest_cache: dict[str, Any] | None = None
        self._weekly_digest_cache_generated_at: datetime | None = None
        self._weekly_digest_events: list[_WeeklyDigestEvent] = []
        self._observability_event_retention_days = 3650
        self._observability_event_prune_interval = 2048
        self._observability_event_writes_since_prune = 0
        self._recent_event_retention = 512
        self._recent_query_events: list[dict[str, Any]] = []
        self._recent_outcome_events: list[dict[str, Any]] = []
        self._session_deserializer = session_deserializer

        if backend is None:
            sqlite_backend = SQLiteBackend(Path(db_path))
            sqlite_backend.init_schema()
            self._backend: MemoryBackend = sqlite_backend
            self._sqlite_backend: SQLiteBackend | None = sqlite_backend
        else:
            self._backend = backend
            self._sqlite_backend = backend if isinstance(backend, SQLiteBackend) else None
        self._kv_ephemeral_store: dict[tuple[str, str], dict[str, Any]] = {}

        self._graph = BackendGraph(
            self._backend,
            confidence_refresh_query_interval=graph_confidence_refresh_query_interval,
        )
        self._activation_engine = activation_engine or ActivationEngine()
        self._outcome_detector = outcome_detector or OutcomeDetector()
        self._connection_learner = connection_learner or ConnectionLearner(
            telemetry_collector=self._telemetry_collector,
            deferred_pair_processing_budget=1,
            max_connection_events_per_update=6,
        )
        self._feedback_orchestrator = FeedbackOrchestrator(
            outcome_detector=self._outcome_detector,
            connection_learner=self._connection_learner,
            telemetry_collector=self._telemetry_collector,
        )
        self._graduation_engine = graduation_engine or GraduationEngine(
            min_access_count=max(0, int(graduation_min_access_count)),
            min_positive_outcome_ratio=_clamp(
                float(graduation_min_positive_outcome_ratio),
                lower=0.0,
                upper=1.0,
            ),
            min_age_hours=max(0.0, float(graduation_min_age_hours)),
            min_reinforced_edges=max(0, int(graduation_min_reinforced_edges)),
            reinforced_edge_weight_threshold=float(graduation_reinforced_edge_weight_threshold),
            edge_transfer_threshold=float(graduation_edge_transfer_threshold),
            telemetry_collector=self._telemetry_collector,
            deployment_id=self._deployment_id,
            graduation_trigger="scheduled",
        )
        self._graduation_scheduler_enabled = bool(graduation_scheduler_enabled)
        self._graduation_check_interval_queries = max(1, int(graduation_check_interval_queries))
        self._graduation_check_interval_seconds = max(1.0, float(graduation_check_interval_seconds))
        self._graduation_queries_since_check = 0
        self._graduation_last_scheduled_at = _utc_now()
        self._graduation_task: asyncio.Task[None] | None = None
        self._graph_ops = GraphOps(self)
        self._retrieval_state = RetrievalState(self)
        self._cross_tier = CrossTier(self)
        self._adaptive_tuning = AdaptiveTuning(self)
        self._observability = Observability(self)
        self._kv_session = KVSession(self)
        self._runtime_engine = RuntimeEngine(self)

        self._instance_optimizer_enabled = bool(instance_optimizer_enabled)
        self._instance_optimizer_update_interval = max(1, int(instance_optimizer_update_interval))
        self._optimizer_feedback_count = 0
        self._optimizer_positive_outcome_count = 0
        self._optimizer_negative_outcome_count = 0
        self._optimizer_learning_gated_count = 0
        self._optimizer_created_edges_total = 0
        if self._instance_optimizer_enabled:
            self._instance_optimizer = instance_optimizer or InstanceOptimizer(
                current_params=self._optimizer_runtime_params(),
                step_size=float(instance_optimizer_step_size),
                min_sample_count=max(1, int(instance_optimizer_min_sample_count)),
                telemetry_collector=self._telemetry_collector,
                deployment_id=self._deployment_id,
            )
        else:
            self._instance_optimizer = None

    async def remember(
        self,
        content: str,
        memory_type: str | None = None,
        external_id: str | None = None,
        source_type: SourceType | None = None,
        metadata: Mapping[str, Any] | None = None,
    ) -> Node:
        return await self._runtime_engine.remember(
            content=content,
            memory_type=memory_type,
            external_id=external_id,
            source_type=source_type,
            metadata=metadata,
        )

    async def recall(
        self,
        query: str,
        top_k: int | None = None,
        session_id: str | None = None,
    ) -> RetrievalResult:
        return await self._runtime_engine.recall(
            query=query,
            top_k=top_k,
            session_id=session_id,
        )

    async def activate(
        self,
        node_ids: Sequence[UUID | str],
        initial_energy: float = 1.0,
        *,
        top_k: int | None = None,
        session_id: str | None = None,
    ) -> RetrievalResult:
        return await self._runtime_engine.activate(
            node_ids=node_ids,
            initial_energy=initial_energy,
            top_k=top_k,
            session_id=session_id,
        )

    async def feedback(
        self,
        query_id: UUID,
        outcome: OutcomeSignalType | str,
        *,
        agent_response: str | None = None,
        user_next_message: str | None = None,
        dwell_time_ms: float | None = None,
        active_nodes: list[UUID] | None = None,
        corrected_nodes: list[UUID] | None = None,
        provider: str = "unknown",
    ) -> CompositeOutcome:
        return await self._runtime_engine.feedback(
            query_id=query_id,
            outcome=outcome,
            agent_response=agent_response,
            user_next_message=user_next_message,
            dwell_time_ms=dwell_time_ms,
            active_nodes=active_nodes,
            corrected_nodes=corrected_nodes,
            provider=provider,
        )

    def query_session_id(self, query_id: UUID | str) -> str | None:
        """Return the owning session for a query id when known."""

        return self._query_sessions.get(str(query_id))

    async def graph_status(self) -> dict[str, Any]:
        return await self._observability.graph_status()

    async def session_summary(self, session_id: str) -> dict[str, int]:
        return await self._observability.session_summary(session_id)

    async def weekly_digest(
        self,
        *,
        now: datetime | None = None,
        force_refresh: bool = False,
    ) -> dict[str, Any]:
        return await self._observability.weekly_digest(
            now=now,
            force_refresh=force_refresh,
        )

    async def connect(
        self,
        node_a_id: UUID | str,
        node_b_id: UUID | str,
        *,
        weight: float = 0.3,
        connection_type: ConnectionType | str = ConnectionType.EXCITATORY,
        formation_trigger: FormationTrigger | str = FormationTrigger.EXPLICIT,
        is_cross_tier: bool | None = None,
    ) -> dict[str, Any]:
        return await self._graph_ops.link(
            node_a_id=node_a_id,
            node_b_id=node_b_id,
            weight=weight,
            connection_type=connection_type,
            formation_trigger=formation_trigger,
            is_cross_tier=is_cross_tier,
        )

    async def related(
        self,
        node_id: UUID | str,
        *,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        return await self._graph_ops.neighbors(
            node_id=node_id,
            limit=limit,
        )

    async def queries_recent(
        self,
        *,
        session_id: str | None = None,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        return await self._observability.recent_queries(
            session_id=session_id,
            limit=limit,
        )

    async def outcomes_recent(
        self,
        *,
        session_id: str | None = None,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        return await self._observability.recent_outcomes(
            session_id=session_id,
            limit=limit,
        )

    async def sessions_recent(self, *, limit: int = 20) -> list[dict[str, Any]]:
        return await self._observability.recent_sessions(limit=limit)

    async def set(
        self,
        key: str,
        value: Any,
        *,
        metadata: Mapping[str, Any] | None = None,
        ttl: int | None = None,
        namespace: str | None = None,
    ) -> None:
        await self._kv_session.kv_set(
            key=key,
            value=value,
            metadata=metadata,
            ttl=ttl,
            namespace=namespace,
        )

    async def get(
        self,
        key: str,
        *,
        namespace: str | None = None,
    ) -> Any | None:
        return await self._kv_session.kv_get(
            key=key,
            namespace=namespace,
        )

    async def find(
        self,
        query: str,
        *,
        limit: int = 10,
        namespace: str | None = None,
        filters: Mapping[str, Any] | None = None,
    ) -> list[KeyValueItem]:
        return await self._kv_session.kv_search(
            query=query,
            limit=limit,
            namespace=namespace,
            filters=filters,
        )

    async def delete(
        self,
        key: str,
        *,
        namespace: str | None = None,
    ) -> bool:
        return await self._kv_session.kv_delete(
            key=key,
            namespace=namespace,
        )

    async def clear(self, *, namespace: str | None = None) -> int:
        return await self._kv_session.kv_clear(namespace=namespace)

    async def store_session(self, session: Any) -> Any:
        return await self._kv_session.store_session(session)

    async def retrieve_session(self, session_id: str) -> Any | None:
        return await self._kv_session.retrieve_session(session_id)

    async def update_session(self, session: Any) -> Any:
        return await self._kv_session.update_session(session)

    def _kv_get_item(
        self,
        *,
        namespace: str | None,
        key: str,
    ) -> dict[str, Any] | None:
        return self._kv_session.kv_get_item(namespace=namespace, key=key)

    def _kv_search_ephemeral_items(
        self,
        *,
        namespace: str,
        query: str,
        limit: int,
    ) -> list[dict[str, Any]]:
        return self._kv_session.kv_search_ephemeral_items(
            namespace=namespace,
            query=query,
            limit=limit,
        )

    async def forget(self, node_id: UUID) -> None:
        await self._graph_ops.delete(node_id)

    async def stats(self) -> dict[str, float]:
        return await self._graph_ops.stats()

    async def _activate_from_fusion(
        self,
        *,
        fusion_results: Sequence[tuple[str, float]],
        session_id: str,
    ) -> ActivationResult:
        seed_nodes: list[tuple[Node, float]] = []
        for node_id, score in fusion_results[: self._top_k_activation_seeds]:
            node = self._load_node(node_id)
            if node is None:
                continue
            seed_nodes.append((node, max(0.1, float(score))))
        if not seed_nodes:
            return ActivationResult()
        return await self._activation_engine.activate(
            seed_nodes=seed_nodes,
            graph=self._graph,
            session_priming_set=self._session_priming_set(session_id),
        )

    def _load_node(self, node_id: str) -> Node | None:
        return self._graph_ops.load_node(node_id)

    def _load_nodes(self, ranked_node_ids: Sequence[str]) -> list[Node]:
        return self._graph_ops.load_nodes(ranked_node_ids)

    def _remember_retrieval(self, *, result: RetrievalResult, session_id: str) -> None:
        self._retrieval_state.remember_retrieval(
            result=result,
            session_id=session_id,
        )

    def _update_retrieval_metrics(
        self,
        *,
        result: RetrievalResult,
        session_id: str,
        nodes_visited: int,
    ) -> None:
        self._retrieval_state.update_retrieval_metrics(
            result=result,
            session_id=session_id,
            nodes_visited=nodes_visited,
        )

    def _update_feedback_metrics(
        self,
        *,
        session_id: str,
        composite_outcome: CompositeOutcome,
        created_edges: int,
    ) -> None:
        self._retrieval_state.update_feedback_metrics(
            session_id=session_id,
            composite_outcome=composite_outcome,
            created_edges=created_edges,
        )

    def _schedule_graduation_if_due(self, *, count_query: bool) -> None:
        self._adaptive_tuning.schedule_graduation_if_due(count_query=count_query)

    async def _run_graduation_cycle(self, *, now: datetime) -> None:
        await self._adaptive_tuning.run_graduation_cycle(now=now)

    def _on_graduation_task_done(self, task: asyncio.Task[None]) -> None:
        self._adaptive_tuning.on_graduation_task_done(task)

    def _run_continuous_instance_optimization(
        self,
        *,
        composite_outcome: CompositeOutcome,
        created_edges: int,
    ) -> None:
        self._adaptive_tuning.run_continuous_instance_optimization(
            composite_outcome=composite_outcome,
            created_edges=created_edges,
        )

    def _build_optimizer_snapshot(self) -> dict[str, object]:
        return self._adaptive_tuning.build_optimizer_snapshot()

    def _optimizer_runtime_params(self) -> dict[str, float]:
        return self._adaptive_tuning.optimizer_runtime_params()

    def _apply_optimizer_runtime_params(self, updated_params: Mapping[str, float]) -> None:
        self._adaptive_tuning.apply_optimizer_runtime_params(updated_params)

    def _session_priming_set(self, session_id: str) -> set[str]:
        return self._retrieval_state.session_priming_set(session_id)

    def _previous_retrieval_for_session(
        self,
        *,
        session_id: str,
        current_query_id: str,
    ) -> RetrievalResult | None:
        return self._retrieval_state.previous_retrieval_for_session(
            session_id=session_id,
            current_query_id=current_query_id,
        )

    def _build_retrieval_from_active_nodes(
        self,
        *,
        query_id: UUID,
        active_nodes: Sequence[UUID],
    ) -> RetrievalResult:
        return self._retrieval_state.build_retrieval_from_active_nodes(
            query_id=query_id,
            active_nodes=active_nodes,
        )

    def _record_retrieval_telemetry(
        self,
        *,
        query_id: UUID,
        keyword_results: Sequence[tuple[str, float]],
        semantic_results: Sequence[tuple[str, float]],
        fusion_results: Sequence[tuple[str, float]],
        overlap_count: int,
        top_k: int,
        graph_confidence: float,
        activation_weight_applied: float,
        retrieval_latency_ms: float,
    ) -> None:
        self._observability.record_retrieval_telemetry(
            query_id=query_id,
            keyword_results=keyword_results,
            semantic_results=semantic_results,
            fusion_results=fusion_results,
            overlap_count=overlap_count,
            top_k=top_k,
            graph_confidence=graph_confidence,
            activation_weight_applied=activation_weight_applied,
            retrieval_latency_ms=retrieval_latency_ms,
        )

    def _record_activation_telemetry(
        self,
        *,
        query_id: UUID,
        activation: ActivationResult,
        activation_sourced_node_ids: Sequence[str],
        fusion_only_node_ids: Sequence[str],
        short_term_node_ids: Sequence[str],
        long_term_node_ids: Sequence[str],
        activation_latency_ms: float,
    ) -> None:
        self._observability.record_activation_telemetry(
            query_id=query_id,
            activation=activation,
            activation_sourced_node_ids=activation_sourced_node_ids,
            fusion_only_node_ids=fusion_only_node_ids,
            short_term_node_ids=short_term_node_ids,
            long_term_node_ids=long_term_node_ids,
            activation_latency_ms=activation_latency_ms,
        )

    def _record_outcome_telemetry(
        self,
        *,
        query_id: UUID,
        session_id: str,
        provider: str,
        composite_outcome: CompositeOutcome,
        active_nodes: Sequence[UUID],
        corrected_nodes: Sequence[UUID],
    ) -> None:
        self._observability.record_outcome_telemetry(
            query_id=query_id,
            session_id=session_id,
            provider=provider,
            composite_outcome=composite_outcome,
            active_nodes=active_nodes,
            corrected_nodes=corrected_nodes,
        )

    def _record_query_telemetry(
        self,
        *,
        query_id: UUID,
        session_id: str,
        query_type: str,
        query_text: str,
        embedding: Sequence[float],
    ) -> None:
        self._observability.record_query_telemetry(
            query_id=query_id,
            session_id=session_id,
            query_type=query_type,
            query_text=query_text,
            embedding=embedding,
        )

    def _record_session_telemetry(self, *, session_id: str) -> None:
        self._observability.record_session_telemetry(session_id=session_id)

    def _record_node_metadata_for_retrieval(
        self,
        *,
        final_nodes: Sequence[Node],
    ) -> None:
        self._observability.record_node_metadata_for_retrieval(final_nodes=final_nodes)

    def _record_node_metadata_snapshot(
        self,
        *,
        node: Node,
        activated: bool = False,
        in_final_set: bool = False,
        observed_at: datetime | None = None,
    ) -> None:
        self._observability.record_node_metadata_snapshot(
            node=node,
            activated=activated,
            in_final_set=in_final_set,
            observed_at=observed_at,
        )

    def _safe_telemetry_call(self, method_name: str, payload: Mapping[str, Any]) -> None:
        self._observability.safe_telemetry_call(method_name, payload)

    def _record_weekly_event(
        self,
        *,
        query_count: int = 0,
        activation_sourced_results: int = 0,
        new_connections_formed: int = 0,
        learning_gated_outcomes: int = 0,
        cross_tier_traversals: int = 0,
    ) -> None:
        self._observability.record_weekly_event(
            query_count=query_count,
            activation_sourced_results=activation_sourced_results,
            new_connections_formed=new_connections_formed,
            learning_gated_outcomes=learning_gated_outcomes,
            cross_tier_traversals=cross_tier_traversals,
        )

    def _persist_session_metrics_delta(
        self,
        *,
        session_id: str,
        query_count: int = 0,
        memory_hits: int = 0,
        memory_misses: int = 0,
        activation_sourced_results: int = 0,
        new_connections_formed: int = 0,
        learning_gated_outcomes: int = 0,
        cross_tier_traversals: int = 0,
    ) -> None:
        self._observability.persist_session_metrics_delta(
            session_id=session_id,
            query_count=query_count,
            memory_hits=memory_hits,
            memory_misses=memory_misses,
            activation_sourced_results=activation_sourced_results,
            new_connections_formed=new_connections_formed,
            learning_gated_outcomes=learning_gated_outcomes,
            cross_tier_traversals=cross_tier_traversals,
        )

    def _persist_weekly_digest_event(self, event: _WeeklyDigestEvent) -> None:
        self._observability.persist_weekly_digest_event(event)

    def _read_session_metrics_durable(self, *, session_id: str) -> _SessionMetrics | None:
        return self._observability.read_session_metrics_durable(session_id=session_id)

    def _read_weekly_digest_aggregates(
        self,
        *,
        window_start: datetime,
        window_end: datetime,
    ) -> dict[str, int] | None:
        return self._observability.read_weekly_digest_aggregates(
            window_start=window_start,
            window_end=window_end,
        )

    def _append_recent_query_event(self, event: Mapping[str, Any]) -> None:
        self._observability.append_recent_query_event(event)

    def _append_recent_outcome_event(self, event: Mapping[str, Any]) -> None:
        self._observability.append_recent_outcome_event(event)

    def _read_recent_queries_durable(
        self,
        *,
        session_id: str | None,
        limit: int,
    ) -> list[dict[str, Any]]:
        return self._observability.read_recent_queries_durable(
            session_id=session_id,
            limit=limit,
        )

    def _read_recent_outcomes_durable(
        self,
        *,
        session_id: str | None,
        limit: int,
    ) -> list[dict[str, Any]]:
        return self._observability.read_recent_outcomes_durable(
            session_id=session_id,
            limit=limit,
        )

    def _read_recent_sessions_durable(self, *, limit: int) -> list[dict[str, Any]]:
        return self._observability.read_recent_sessions_durable(limit=limit)

    def _recent_graduations_count(self, *, window_start: datetime) -> int:
        return self._observability.recent_graduations_count(window_start=window_start)

    def _graph_status_metrics(self, *, now: datetime | None = None) -> _GraphStatusMetrics:
        return self._observability.graph_status_metrics(now=now)

    def _edge_health_counts(
        self,
        *,
        window_start: datetime,
        window_end: datetime,
    ) -> dict[str, int]:
        return self._observability.edge_health_counts(
            window_start=window_start,
            window_end=window_end,
        )

    def _resolve_top_k(self, top_k: int | None) -> int:
        if top_k is None:
            return self._top_k_retrieval
        resolved = int(top_k)
        if resolved <= 0:
            raise ValueError("top_k must be > 0")
        return resolved

    async def _embed(self, content: str) -> list[float]:
        if self._embedding_fn is None:
            raise RuntimeError("_SynapticEngine requires embedding_fn for remember/recall operations")
        raw = self._embedding_fn(content)
        if inspect.isawaitable(raw):
            raw = await raw
        try:
            embedding = [float(value) for value in raw]
        except TypeError as exc:
            raise TypeError("embedding_fn must return a sequence of numeric values") from exc
        if not embedding:
            raise ValueError("embedding_fn must return at least one value")
        return embedding

    def _classify_memory_type(self, content: str, *, context: Mapping[str, Any] | None) -> str:
        classify = getattr(self._classifier, "classify", None)
        if callable(classify):
            try:
                return str(classify(content, context=context))
            except TypeError:
                return str(classify(content))
            except Exception:
                return MemoryType.CONTEXTUAL
        return MemoryType.CONTEXTUAL

    def _seed_cross_tier_provisional_edges(
        self,
        *,
        source_node_id: str,
        source_embedding: Sequence[float],
    ) -> None:
        self._cross_tier.seed_provisional_edges(
            source_node_id=source_node_id,
            source_embedding=source_embedding,
        )

    def _rank_long_term_seed_candidates(
        self,
        *,
        source_node_id: str,
        source_embedding: Sequence[float],
    ) -> list[tuple[str, float]]:
        return self._cross_tier.rank_long_term_candidates(
            source_node_id=source_node_id,
            source_embedding=source_embedding,
        )

    def _create_cross_tier_edge_if_missing(
        self,
        *,
        source_node_id: str,
        target_node_id: str,
        existing_pairs: set[tuple[str, str]] | None = None,
        existing_pairs_complete: bool = False,
    ) -> bool:
        return self._cross_tier.create_edge_if_missing(
            source_node_id=source_node_id,
            target_node_id=target_node_id,
            existing_pairs=existing_pairs,
            existing_pairs_complete=existing_pairs_complete,
        )

    def _candidate_tier_lookup(
        self,
        *,
        candidate_node_ids: Sequence[str],
    ) -> dict[str, str]:
        return self._cross_tier.candidate_tier_lookup(candidate_node_ids=candidate_node_ids)

    def _existing_edge_pairs_for_node(
        self,
        *,
        source_node_id: str,
    ) -> tuple[set[tuple[str, str]], bool]:
        return self._cross_tier.existing_edge_pairs_for_node(source_node_id=source_node_id)

    def _edge_exists(self, *, pair: tuple[str, str]) -> bool:
        return self._cross_tier.edge_exists(pair=pair)


def _node_tier(node: Node) -> str:
    return _svc_node_tier(node)


def _pair_key(left: str, right: str) -> tuple[str, str]:
    return _svc_pair_key(left, right)


def _as_uuid(value: object) -> UUID:
    return _svc_as_uuid(value)


def _clamp(value: float, *, lower: float, upper: float) -> float:
    return _svc_clamp(value, lower=lower, upper=upper)


def _as_float(value: object) -> float:
    return _svc_as_float(value)


def _coerce_outcome_signal(outcome: OutcomeSignalType | str) -> OutcomeSignalType:
    return _svc_coerce_outcome_signal(outcome)


def _coerce_source_type(value: object) -> SourceType | None:
    return _svc_coerce_source_type(value)


def _session_key(session_id: str | None) -> str:
    return _svc_session_key(session_id)


def _utc_now() -> datetime:
    return _svc_utc_now()


def _coerce_utc(value: datetime) -> datetime:
    return _svc_coerce_utc(value)


def _as_iso8601(value: datetime) -> str:
    return _svc_as_iso8601(value)


def _embedding_hash(embedding: Sequence[float]) -> str:
    return _svc_embedding_hash(tuple(float(value) for value in embedding))


def _confidence_band(confidence: float) -> str:
    return _svc_confidence_band(confidence)


def _mapping_get(value: object, key: str, default: object) -> object:
    return _svc_mapping_get(value, key, default)


def _mapping_set(value: object, key: str, update: object) -> None:
    _svc_mapping_set(value, key, update)


def _serialize_session_payload(session: object) -> Any:
    return _svc_serialize_session_payload(session)


def _normalize_namespace(namespace: str | None) -> str:
    return _svc_normalize_namespace(namespace)


def _keyword_score(key: str, query: str) -> float | None:
    return _svc_keyword_score(key, query)


def _metadata_matches(metadata: Mapping[str, Any], filters: Mapping[str, Any]) -> bool:
    return _svc_metadata_matches(metadata, filters)


def _coerce_metadata(value: Any) -> dict[str, Any]:
    return _svc_coerce_metadata(value)


def _edge_payload(edge: Mapping[str, Any]) -> dict[str, Any]:
    return _svc_edge_payload(edge)


def _parse_iso8601(value: Any) -> datetime | None:
    return _svc_parse_iso8601(value)
