"""Outcome + learning orchestration primitives for Phase 3."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping, Protocol, Sequence
from uuid import UUID

from .learning import LearningUpdateResult
from .models import CompositeOutcome, Node, OutcomeSignal, RetrievalResult
from .types import OutcomeSignalType


class OutcomeDetectorLike(Protocol):
    async def detect(
        self,
        *,
        query_id: UUID,
        retrieval_result: RetrievalResult,
        agent_response: str | None = None,
        user_next_message: str | None = None,
        explicit_outcome: OutcomeSignalType | None = None,
        provider_outcome: str | None = None,
        dwell_time_ms: float | None = None,
        previous_retrieval_result: RetrievalResult | None = None,
        edge_weight_history: Mapping[str, Sequence[float]] | None = None,
    ) -> CompositeOutcome:
        ...


class ConnectionLearnerLike(Protocol):
    async def update(
        self,
        *,
        activated_nodes: list[tuple[Node, float]],
        composite_outcome: CompositeOutcome,
        graph: Any,
        query_id: UUID | None = None,
    ) -> LearningUpdateResult:
        ...


@dataclass(frozen=True)
class FeedbackOrchestrationResult:
    """Result envelope for a single feedback-orchestration cycle."""

    composite_outcome: CompositeOutcome
    learning_update: LearningUpdateResult


class FeedbackOrchestrator:
    """Convert retrieval+feedback inputs into outcome and learner updates."""

    def __init__(
        self,
        *,
        outcome_detector: OutcomeDetectorLike,
        connection_learner: ConnectionLearnerLike,
        telemetry_collector: Any | None = None,
    ) -> None:
        self._outcome_detector = outcome_detector
        self._connection_learner = connection_learner
        self._telemetry_collector = telemetry_collector

    async def process_feedback(
        self,
        *,
        retrieval_result: RetrievalResult,
        graph: Any,
        query_id: UUID | None = None,
        explicit_outcome: OutcomeSignalType | None = None,
        provider_outcome: str | None = None,
        agent_response: str | None = None,
        user_next_message: str | None = None,
        dwell_time_ms: float | None = None,
        previous_retrieval_result: RetrievalResult | None = None,
        edge_weight_history: Mapping[str, Sequence[float]] | None = None,
    ) -> FeedbackOrchestrationResult:
        resolved_query_id = query_id or retrieval_result.query_id
        composite_outcome = await self._outcome_detector.detect(
            query_id=resolved_query_id,
            retrieval_result=retrieval_result,
            explicit_outcome=explicit_outcome,
            provider_outcome=provider_outcome,
            agent_response=agent_response,
            user_next_message=user_next_message,
            dwell_time_ms=dwell_time_ms,
            previous_retrieval_result=previous_retrieval_result,
            edge_weight_history=edge_weight_history,
        )
        self._record_outcome_telemetry(composite_outcome=composite_outcome)

        activated_nodes = self._derive_activated_nodes(retrieval_result)
        try:
            learning_update = await self._connection_learner.update(
                activated_nodes=activated_nodes,
                composite_outcome=composite_outcome,
                graph=graph,
                query_id=resolved_query_id,
            )
        except TypeError:
            learning_update = await self._connection_learner.update(
                activated_nodes=activated_nodes,
                composite_outcome=composite_outcome,
                graph=graph,
            )
        self._record_learning_update_telemetry(
            query_id=resolved_query_id,
            learning_update=learning_update,
        )
        return FeedbackOrchestrationResult(
            composite_outcome=composite_outcome,
            learning_update=learning_update,
        )

    def _derive_activated_nodes(self, retrieval_result: RetrievalResult) -> list[tuple[Node, float]]:
        nodes_by_id = {str(node.id): node for node in retrieval_result.nodes}
        energies: dict[str, float] = {}

        for node in retrieval_result.nodes:
            energies[str(node.id)] = max(
                float(node.activation_energy),
                float(energies.get(str(node.id), 0.0)),
            )

        for seed_id in retrieval_result.seed_node_ids:
            sid = str(seed_id)
            if sid in nodes_by_id:
                energies[sid] = max(energies.get(sid, 0.0), 1.0)

        for step in retrieval_result.activation_path:
            priority_energy = _activation_step_priority(step)
            source_id = step.get("source_node_id") or step.get("source")
            target_id = step.get("target_node_id") or step.get("target")
            if source_id is not None and str(source_id) in nodes_by_id:
                source_energy = _as_float(step.get("source_energy"), default=0.0)
                source_energy = max(source_energy, priority_energy)
                if source_energy > 0.0:
                    sid = str(source_id)
                    energies[sid] = max(energies.get(sid, 0.0), source_energy)
            if target_id is not None and str(target_id) in nodes_by_id:
                target_energy = _as_float(step.get("target_energy_after"), default=0.0)
                if target_energy <= 0.0:
                    target_energy = _as_float(step.get("target_energy"), default=0.0)
                if target_energy <= 0.0:
                    target_energy = _as_float(step.get("propagated_energy"), default=0.0)
                target_energy = max(target_energy, priority_energy)
                if target_energy > 0.0:
                    tid = str(target_id)
                    energies[tid] = max(energies.get(tid, 0.0), target_energy)

        activated: list[tuple[Node, float]] = []
        for node_id in sorted(nodes_by_id):
            energy = float(energies.get(node_id, 0.0))
            if energy <= 0.0:
                continue
            activated.append((nodes_by_id[node_id], energy))
        return activated

    def _record_outcome_telemetry(self, *, composite_outcome: CompositeOutcome) -> None:
        payload = {
            "query_id": str(composite_outcome.query_id),
            "composite_score": float(composite_outcome.composite_score),
            "composite_confidence": float(composite_outcome.composite_confidence),
            "learning_gated": bool(composite_outcome.learning_gated),
            "oscillation_detected": bool(composite_outcome.oscillation_detected),
            "signals": [
                _signal_to_payload(signal) for signal in composite_outcome.signals
            ],
        }
        self._safe_telemetry_call("record_outcome", payload)

    def _record_learning_update_telemetry(
        self,
        *,
        query_id: UUID,
        learning_update: LearningUpdateResult,
    ) -> None:
        for edge_id in sorted(set(learning_update.updated_edge_ids)):
            self._safe_telemetry_call(
                "record_connection",
                {
                    "query_id": str(query_id),
                    "connection_id": str(edge_id),
                    "change_type": "updated",
                    "changed": True,
                    "skipped": False,
                    "oscillation_detected": False,
                },
            )

        for edge_id in sorted(set(learning_update.created_edge_ids)):
            self._safe_telemetry_call(
                "record_connection",
                {
                    "query_id": str(query_id),
                    "connection_id": str(edge_id),
                    "change_type": "created",
                    "changed": True,
                    "skipped": False,
                    "oscillation_detected": False,
                },
            )

        for edge_id in sorted(set(learning_update.skipped_oscillating_edge_ids)):
            self._safe_telemetry_call(
                "record_connection",
                {
                    "query_id": str(query_id),
                    "connection_id": str(edge_id),
                    "change_type": "skipped_oscillating",
                    "changed": False,
                    "skipped": True,
                    "oscillation_detected": True,
                },
            )

    def _safe_telemetry_call(self, method_name: str, payload: Mapping[str, object]) -> None:
        collector = self._telemetry_collector
        if collector is None:
            return
        try:
            method = getattr(collector, method_name, None)
        except Exception:
            return
        if not callable(method):
            return
        try:
            method(dict(payload))
        except Exception:
            return


def _as_float(value: object, *, default: float) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _activation_step_priority(step: Mapping[str, object]) -> float:
    raw_step = step.get("step")
    try:
        step_index = max(0, int(raw_step))
    except (TypeError, ValueError):
        step_index = 0
    return max(0.0, 1.2 - (0.15 * min(step_index, 6)))


def _signal_to_payload(signal: OutcomeSignal) -> dict[str, object]:
    return {
        "signal_type": signal.signal_type.value,
        "value": float(signal.value),
        "confidence": float(signal.confidence),
    }


__all__ = ["FeedbackOrchestrationResult", "FeedbackOrchestrator"]
