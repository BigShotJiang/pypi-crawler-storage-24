"""Observability service for telemetry emission and read models."""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import TYPE_CHECKING, Any, Mapping, Sequence
from uuid import UUID, uuid4

from .activation import ActivationResult
from .backends.sqlite import SQLiteBackend
from .models import CompositeOutcome, Node
from .service_utils import (
    GraphStatusMetrics,
    NodeTelemetryState,
    SessionMetrics,
    WeeklyDigestEvent,
    as_float,
    as_iso8601,
    clamp,
    coerce_utc,
    confidence_band,
    embedding_hash,
    node_tier,
    parse_iso8601,
    session_key,
    utc_now,
)

if TYPE_CHECKING:
    from ._engine import _SynapticEngine


class Observability:
    """Coordinates telemetry emission and observability read models."""

    def __init__(self, memory: _SynapticEngine) -> None:
        self._memory = memory

    async def graph_status(self) -> dict[str, Any]:
        memory = self._memory
        snapshot = memory._graph.snapshot()
        confidence = memory._graph.compute_graph_confidence()
        components = memory._graph.graph_confidence_components()
        metrics = self.graph_status_metrics()
        return {
            "total_nodes": float(snapshot["node_count"]),
            "short_term_nodes": float(snapshot["short_term_nodes"]),
            "long_term_nodes": float(snapshot["long_term_nodes"]),
            "total_edges": float(snapshot["edge_count"]),
            "cross_tier_edges": float(snapshot["cross_tier_edges"]),
            "graph_confidence": clamp(float(confidence), lower=0.0, upper=1.0),
            "graph_confidence_components": components,
            "confidence_band": confidence_band(float(confidence)),
            "maturity_percent": float(round(clamp(float(confidence), lower=0.0, upper=1.0) * 100.0)),
            "recent_graduations_7d": float(metrics.recent_graduations_7d),
            "recent_activations_7d": float(memory._total_queries),
            "recent_associative_retrievals_7d": float(
                sum(
                    session_metrics.activation_sourced_results
                    for session_metrics in memory._session_metrics.values()
                )
            ),
            "converging_edge_ratio": float(metrics.converging_edge_ratio),
            "oscillating_edge_ratio": float(metrics.oscillating_edge_ratio),
        }

    async def session_summary(self, session_id: str) -> dict[str, int]:
        memory = self._memory
        session_id_key = session_key(session_id)
        metrics = memory._session_metrics.get(session_id_key, SessionMetrics())
        durable_metrics = self.read_session_metrics_durable(session_id=session_id_key)
        if durable_metrics is not None:
            metrics = SessionMetrics(
                query_count=max(int(metrics.query_count), int(durable_metrics.query_count)),
                memory_hits=max(int(metrics.memory_hits), int(durable_metrics.memory_hits)),
                memory_misses=max(int(metrics.memory_misses), int(durable_metrics.memory_misses)),
                activation_sourced_results=max(
                    int(metrics.activation_sourced_results),
                    int(durable_metrics.activation_sourced_results),
                ),
                new_connections_formed=max(
                    int(metrics.new_connections_formed),
                    int(durable_metrics.new_connections_formed),
                ),
                learning_gated_outcomes=max(
                    int(metrics.learning_gated_outcomes),
                    int(durable_metrics.learning_gated_outcomes),
                ),
                cross_tier_traversals=max(
                    int(metrics.cross_tier_traversals),
                    int(durable_metrics.cross_tier_traversals),
                ),
            )
        return {
            "query_count": int(metrics.query_count),
            "memory_hits": int(metrics.memory_hits),
            "memory_misses": int(metrics.memory_misses),
            "activation_sourced_results": int(metrics.activation_sourced_results),
            "new_connections_formed": int(metrics.new_connections_formed),
            "learning_gated_outcomes": int(metrics.learning_gated_outcomes),
            "cross_tier_traversals": int(metrics.cross_tier_traversals),
        }

    async def weekly_digest(
        self,
        *,
        now: datetime | None = None,
        force_refresh: bool = False,
    ) -> dict[str, Any]:
        memory = self._memory
        current_time = utc_now() if now is None else coerce_utc(now)
        if (
            not force_refresh
            and memory._weekly_digest_cache is not None
            and memory._weekly_digest_cache_generated_at is not None
            and (current_time - memory._weekly_digest_cache_generated_at).total_seconds()
            < memory._weekly_digest_cache_ttl_seconds
        ):
            return dict(memory._weekly_digest_cache)

        window_start = current_time - timedelta(days=7)
        aggregates = self.read_weekly_digest_aggregates(
            window_start=window_start,
            window_end=current_time,
        )
        if aggregates is None:
            query_count = 0
            activation_sourced_results = 0
            new_connections_formed = 0
            learning_gated_outcomes = 0
            cross_tier_traversals = 0
            retained_events: list[WeeklyDigestEvent] = []
            for event in memory._weekly_digest_events:
                if event.occurred_at < window_start:
                    continue
                retained_events.append(event)
                if event.occurred_at > current_time:
                    continue
                query_count += int(event.query_count)
                activation_sourced_results += int(event.activation_sourced_results)
                new_connections_formed += int(event.new_connections_formed)
                learning_gated_outcomes += int(event.learning_gated_outcomes)
                cross_tier_traversals += int(event.cross_tier_traversals)
            memory._weekly_digest_events = retained_events
        else:
            query_count = int(aggregates["query_count"])
            activation_sourced_results = int(aggregates["activation_sourced_results"])
            new_connections_formed = int(aggregates["new_connections_formed"])
            learning_gated_outcomes = int(aggregates["learning_gated_outcomes"])
            cross_tier_traversals = int(aggregates["cross_tier_traversals"])

        graduations_to_long_term = self.recent_graduations_count(window_start=window_start)
        summary = (
            "No retrieval activity recorded in the last 7 days."
            if query_count <= 0
            else (
                "This week: your memory graph formed "
                f"{new_connections_formed} new connections, graduated "
                f"{graduations_to_long_term} memories to long-term, and retrieved "
                f"{activation_sourced_results} memories through associative paths."
            )
        )
        payload = {
            "window_start": as_iso8601(window_start),
            "window_end": as_iso8601(current_time),
            "generated_at": as_iso8601(current_time),
            "cache_ttl_seconds": int(memory._weekly_digest_cache_ttl_seconds),
            "query_count": int(query_count),
            "activation_sourced_results": int(max(0, activation_sourced_results)),
            "new_connections_formed": int(max(0, new_connections_formed)),
            "learning_gated_outcomes": int(max(0, learning_gated_outcomes)),
            "cross_tier_traversals": int(max(0, cross_tier_traversals)),
            "graduations_to_long_term": int(max(0, graduations_to_long_term)),
            "summary": summary,
        }
        memory._weekly_digest_cache = dict(payload)
        memory._weekly_digest_cache_generated_at = current_time
        return payload

    async def recent_queries(
        self,
        *,
        session_id: str | None = None,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        memory = self._memory
        resolved_limit = int(limit)
        if resolved_limit <= 0:
            raise ValueError("limit must be > 0")
        session_id_key = session_key(session_id) if session_id is not None else None
        recent: list[dict[str, Any]] = []
        seen_query_ids: set[str] = set()

        for event in reversed(memory._recent_query_events):
            if session_id_key is not None and str(event.get("session_id", "")) != session_id_key:
                continue
            query_id = str(event.get("query_id", ""))
            if query_id in seen_query_ids:
                continue
            recent.append(dict(event))
            seen_query_ids.add(query_id)
            if len(recent) >= resolved_limit:
                return recent

        for event in self.read_recent_queries_durable(
            session_id=session_id_key,
            limit=max(resolved_limit * 2, resolved_limit),
        ):
            query_id = str(event.get("query_id", ""))
            if query_id in seen_query_ids:
                continue
            recent.append(dict(event))
            seen_query_ids.add(query_id)
            if len(recent) >= resolved_limit:
                break
        return recent[:resolved_limit]

    async def recent_outcomes(
        self,
        *,
        session_id: str | None = None,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        memory = self._memory
        resolved_limit = int(limit)
        if resolved_limit <= 0:
            raise ValueError("limit must be > 0")
        session_id_key = session_key(session_id) if session_id is not None else None
        recent: list[dict[str, Any]] = []
        seen_outcome_ids: set[str] = set()

        for event in reversed(memory._recent_outcome_events):
            if session_id_key is not None and str(event.get("session_id", "")) != session_id_key:
                continue
            outcome_id = str(event.get("id", ""))
            if outcome_id in seen_outcome_ids:
                continue
            recent.append(dict(event))
            seen_outcome_ids.add(outcome_id)
            if len(recent) >= resolved_limit:
                return recent

        for event in self.read_recent_outcomes_durable(
            session_id=session_id_key,
            limit=max(resolved_limit * 2, resolved_limit),
        ):
            outcome_id = str(event.get("id", ""))
            if outcome_id in seen_outcome_ids:
                continue
            recent.append(dict(event))
            seen_outcome_ids.add(outcome_id)
            if len(recent) >= resolved_limit:
                break
        return recent[:resolved_limit]

    async def recent_sessions(self, *, limit: int = 20) -> list[dict[str, Any]]:
        memory = self._memory
        resolved_limit = int(limit)
        if resolved_limit <= 0:
            raise ValueError("limit must be > 0")

        summaries: dict[str, dict[str, Any]] = {}
        for session_id in sorted(
            {
                *memory._session_metrics.keys(),
                *memory._session_started_at.keys(),
                *memory._session_last_activity_at.keys(),
            }
        ):
            metrics = await self.session_summary(session_id)
            started_at = memory._session_started_at.get(session_id)
            last_activity = memory._session_last_activity_at.get(session_id, started_at)
            summaries[session_id] = {
                "session_id": session_id,
                "started_at": as_iso8601(started_at) if started_at is not None else None,
                "last_activity_at": as_iso8601(last_activity) if last_activity is not None else None,
                **metrics,
            }

        for durable in self.read_recent_sessions_durable(limit=max(resolved_limit * 2, resolved_limit)):
            session_id = str(durable.get("session_id", ""))
            if session_id in summaries:
                continue
            summaries[session_id] = dict(durable)

        ranked = sorted(
            summaries.values(),
            key=lambda item: (
                parse_iso8601(item.get("last_activity_at")) or datetime.min.replace(tzinfo=timezone.utc),
                str(item.get("session_id", "")),
            ),
            reverse=True,
        )
        return ranked[:resolved_limit]

    def record_retrieval_telemetry(
        self,
        *,
        query_id: UUID,
        keyword_results: Sequence[tuple[str, float]],
        semantic_results: Sequence[tuple[str, float]],
        fusion_results: Sequence[tuple[str, float]],
        overlap_count: int,
        top_k: int,
        graph_confidence: float,
        activation_weight_applied: float,
        retrieval_latency_ms: float,
    ) -> None:
        from .retrieval import build_retrieval_telemetry_payload

        payload = build_retrieval_telemetry_payload(
            query_id=query_id,
            keyword_results=keyword_results,
            semantic_results=semantic_results,
            fusion_results=fusion_results,
            overlap_count=overlap_count,
            top_k=top_k,
            graph_confidence=graph_confidence,
            activation_weight_applied=activation_weight_applied,
            retrieval_latency_ms=retrieval_latency_ms,
        )
        self.safe_telemetry_call(
            "record_retrieval",
            payload,
        )

    def record_activation_telemetry(
        self,
        *,
        query_id: UUID,
        activation: ActivationResult,
        activation_sourced_node_ids: Sequence[str],
        fusion_only_node_ids: Sequence[str],
        short_term_node_ids: Sequence[str],
        long_term_node_ids: Sequence[str],
        activation_latency_ms: float,
    ) -> None:
        from .retrieval import build_activation_telemetry_payload

        payload = build_activation_telemetry_payload(
            query_id=query_id,
            activation=activation,
            activation_sourced_node_ids=activation_sourced_node_ids,
            fusion_only_node_ids=fusion_only_node_ids,
            short_term_node_ids=short_term_node_ids,
            long_term_node_ids=long_term_node_ids,
            activation_latency_ms=activation_latency_ms,
        )
        self.safe_telemetry_call(
            "record_activation",
            payload,
        )

    def record_outcome_telemetry(
        self,
        *,
        query_id: UUID,
        session_id: str,
        provider: str,
        composite_outcome: CompositeOutcome,
        active_nodes: Sequence[UUID],
        corrected_nodes: Sequence[UUID],
    ) -> None:
        payload = {
            "id": str(uuid4()),
            "query_id": str(query_id),
            "session_id": session_id,
            "composite_score": float(composite_outcome.composite_score),
            "composite_confidence": float(composite_outcome.composite_confidence),
            "learning_gated": int(bool(composite_outcome.learning_gated)),
            "oscillation_detected": int(bool(composite_outcome.oscillation_detected)),
            "signals": [
                {
                    "signal_type": signal.signal_type.value,
                    "value": float(signal.value),
                    "confidence": float(signal.confidence),
                }
                for signal in composite_outcome.signals
            ],
            "provider": provider,
            "active_nodes_during_outcome": [str(node_id) for node_id in active_nodes],
            "corrected_nodes": [str(node_id) for node_id in corrected_nodes],
            "latency_to_outcome_ms": 0.0,
        }
        self.append_recent_outcome_event(payload)
        self.safe_telemetry_call("record_outcome", payload)

    def record_query_telemetry(
        self,
        *,
        query_id: UUID,
        session_id: str,
        query_type: str,
        query_text: str,
        embedding: Sequence[float],
    ) -> None:
        memory = self._memory
        payload = {
            "query_id": str(query_id),
            "session_id": session_id,
            "deployment_id": memory._deployment_id,
            "timestamp": as_iso8601(utc_now()),
            "query_embedding_hash": embedding_hash(tuple(float(value) for value in embedding)),
            "query_type": str(query_type),
            "query_length_tokens": max(0, len(str(query_text).split())),
        }
        self.append_recent_query_event(payload)
        if memory._telemetry_collector is None:
            return
        self.safe_telemetry_call("record_query", payload)

    def record_session_telemetry(self, *, session_id: str) -> None:
        memory = self._memory
        if memory._telemetry_collector is None:
            return
        metrics = memory._session_metrics.get(session_id)
        if metrics is None:
            return
        started_at = memory._session_started_at.get(session_id, utc_now())
        avg_activation_steps = (
            float(metrics.total_activation_steps) / float(metrics.query_count)
            if metrics.query_count > 0
            else 0.0
        )
        avg_nodes_visited = (
            float(metrics.total_nodes_visited) / float(metrics.query_count)
            if metrics.query_count > 0
            else 0.0
        )
        self.safe_telemetry_call(
            "record_session",
            {
                "session_id": session_id,
                "deployment_id": memory._deployment_id,
                "started_at": as_iso8601(started_at),
                "ended_at": None,
                "query_count": int(metrics.query_count),
                "memory_hits": int(metrics.memory_hits),
                "memory_misses": int(metrics.memory_misses),
                "avg_activation_steps": float(avg_activation_steps),
                "avg_nodes_visited": float(avg_nodes_visited),
                "new_connections_formed": int(metrics.new_connections_formed),
                "new_nodes_created": 0,
                "short_term_activations": int(metrics.short_term_activations),
                "long_term_activations": int(metrics.long_term_activations),
                "cross_tier_traversals": int(metrics.cross_tier_traversals),
                "activation_sourced_results": int(metrics.activation_sourced_results),
                "learning_gated_outcomes": int(metrics.learning_gated_outcomes),
                "oscillating_edges_detected": int(metrics.oscillating_edges_detected),
            },
        )

    def record_node_metadata_for_retrieval(
        self,
        *,
        final_nodes: Sequence[Node],
    ) -> None:
        memory = self._memory
        if memory._telemetry_collector is None:
            return
        if not final_nodes:
            return
        observed_at = utc_now()
        for node in final_nodes:
            self.record_node_metadata_snapshot(
                node=node,
                activated=True,
                in_final_set=True,
                observed_at=observed_at,
            )

    def record_node_metadata_snapshot(
        self,
        *,
        node: Node,
        activated: bool = False,
        in_final_set: bool = False,
        observed_at: datetime | None = None,
    ) -> None:
        memory = self._memory
        if memory._telemetry_collector is None:
            return
        node_key = str(node.id)
        state = memory._node_telemetry_state.get(node_key)
        created_at = coerce_utc(node.created_at)
        if state is None:
            state = NodeTelemetryState(created_at=created_at)
            memory._node_telemetry_state[node_key] = state
        elif created_at < state.created_at:
            state.created_at = created_at

        current_time = utc_now() if observed_at is None else coerce_utc(observed_at)
        if activated:
            state.times_activated += 1
            state.last_activated_at = current_time
        if in_final_set:
            state.times_in_final_set += 1
            if state.last_activated_at is None:
                state.last_activated_at = current_time

        age_days = max(0.0, (current_time - state.created_at).total_seconds() / 86_400.0)
        graduated_at = node.graduated_at
        if isinstance(graduated_at, datetime):
            graduated_at_value: str | None = as_iso8601(graduated_at)
        elif graduated_at is None:
            graduated_at_value = None
        else:
            graduated_at_value = str(graduated_at)

        connection_count = len(memory._graph.get_edges_for_node(node_key))
        self.safe_telemetry_call(
            "record_node_metadata",
            {
                "node_id": node_key,
                "deployment_id": memory._deployment_id,
                "created_at": as_iso8601(state.created_at),
                "memory_type": str(node.memory_type),
                "memory_tier": node_tier(node),
                "connection_count": int(max(0, connection_count)),
                "times_activated": int(state.times_activated),
                "times_in_final_set": int(state.times_in_final_set),
                "age_days": float(age_days),
                "last_activated_at": (
                    as_iso8601(state.last_activated_at)
                    if state.last_activated_at is not None
                    else None
                ),
                "staleness_signals": int(max(0, node.staleness_signals)),
                "graduated_at": graduated_at_value,
                "consolidation_candidate": int(bool(node.consolidation_candidate)),
                "consolidated_from": [str(node_id) for node_id in node.consolidated_from],
            },
        )

    def safe_telemetry_call(self, method_name: str, payload: Mapping[str, Any]) -> None:
        memory = self._memory
        collector = memory._telemetry_collector
        if collector is None:
            return
        try:
            method = getattr(collector, method_name, None)
        except Exception:
            return
        if not callable(method):
            return
        try:
            method(dict(payload))
        except Exception:
            return

    def record_weekly_event(
        self,
        *,
        query_count: int = 0,
        activation_sourced_results: int = 0,
        new_connections_formed: int = 0,
        learning_gated_outcomes: int = 0,
        cross_tier_traversals: int = 0,
    ) -> None:
        memory = self._memory
        event = WeeklyDigestEvent(
            occurred_at=utc_now(),
            query_count=max(0, int(query_count)),
            activation_sourced_results=max(0, int(activation_sourced_results)),
            new_connections_formed=max(0, int(new_connections_formed)),
            learning_gated_outcomes=max(0, int(learning_gated_outcomes)),
            cross_tier_traversals=max(0, int(cross_tier_traversals)),
        )
        memory._weekly_digest_events.append(event)
        try:
            self.persist_weekly_digest_event(event)
        except Exception:
            pass
        memory._weekly_digest_cache = None
        memory._weekly_digest_cache_generated_at = None

    def persist_session_metrics_delta(
        self,
        *,
        session_id: str,
        query_count: int = 0,
        memory_hits: int = 0,
        memory_misses: int = 0,
        activation_sourced_results: int = 0,
        new_connections_formed: int = 0,
        learning_gated_outcomes: int = 0,
        cross_tier_traversals: int = 0,
    ) -> None:
        memory = self._memory
        if not isinstance(memory._backend, SQLiteBackend):
            return
        connect = getattr(memory._backend, "_connect", None)
        if not callable(connect):
            return

        timestamp = as_iso8601(utc_now())
        try:
            with connect() as conn:
                conn.execute(
                    """
                    INSERT INTO observability_session_aggregates (
                        session_id,
                        query_count,
                        memory_hits,
                        memory_misses,
                        activation_sourced_results,
                        new_connections_formed,
                        learning_gated_outcomes,
                        cross_tier_traversals,
                        updated_at
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ON CONFLICT(session_id) DO UPDATE SET
                        query_count = observability_session_aggregates.query_count + excluded.query_count,
                        memory_hits = observability_session_aggregates.memory_hits + excluded.memory_hits,
                        memory_misses = observability_session_aggregates.memory_misses + excluded.memory_misses,
                        activation_sourced_results = observability_session_aggregates.activation_sourced_results + excluded.activation_sourced_results,
                        new_connections_formed = observability_session_aggregates.new_connections_formed + excluded.new_connections_formed,
                        learning_gated_outcomes = observability_session_aggregates.learning_gated_outcomes + excluded.learning_gated_outcomes,
                        cross_tier_traversals = observability_session_aggregates.cross_tier_traversals + excluded.cross_tier_traversals,
                        updated_at = excluded.updated_at
                    """,
                    (
                        str(session_id),
                        max(0, int(query_count)),
                        max(0, int(memory_hits)),
                        max(0, int(memory_misses)),
                        max(0, int(activation_sourced_results)),
                        max(0, int(new_connections_formed)),
                        max(0, int(learning_gated_outcomes)),
                        max(0, int(cross_tier_traversals)),
                        timestamp,
                    ),
                )
                conn.commit()
        except Exception:
            return

    def persist_weekly_digest_event(self, event: Any) -> None:
        memory = self._memory
        if not isinstance(memory._backend, SQLiteBackend):
            return
        connect = getattr(memory._backend, "_connect", None)
        if not callable(connect):
            return

        memory._observability_event_writes_since_prune += 1
        should_prune = memory._observability_event_writes_since_prune >= memory._observability_event_prune_interval
        prune_before = as_iso8601(
            event.occurred_at - timedelta(days=int(memory._observability_event_retention_days))
        )
        try:
            with connect() as conn:
                conn.execute(
                    """
                    INSERT INTO observability_weekly_events (
                        occurred_at,
                        query_count,
                        activation_sourced_results,
                        new_connections_formed,
                        learning_gated_outcomes,
                        cross_tier_traversals
                    ) VALUES (?, ?, ?, ?, ?, ?)
                    """,
                    (
                        as_iso8601(event.occurred_at),
                        int(max(0, event.query_count)),
                        int(max(0, event.activation_sourced_results)),
                        int(max(0, event.new_connections_formed)),
                        int(max(0, event.learning_gated_outcomes)),
                        int(max(0, event.cross_tier_traversals)),
                    ),
                )
                if should_prune:
                    conn.execute(
                        """
                        DELETE FROM observability_weekly_events
                        WHERE occurred_at < ?
                        """,
                        (prune_before,),
                    )
                conn.commit()
        except Exception:
            return

        if should_prune:
            memory._observability_event_writes_since_prune = 0

    def read_session_metrics_durable(self, *, session_id: str) -> Any:
        memory = self._memory
        if not isinstance(memory._backend, SQLiteBackend):
            return None
        connect = getattr(memory._backend, "_connect", None)
        if not callable(connect):
            return None

        try:
            with connect() as conn:
                row = conn.execute(
                    """
                    SELECT
                        query_count,
                        memory_hits,
                        memory_misses,
                        activation_sourced_results,
                        new_connections_formed,
                        learning_gated_outcomes,
                        cross_tier_traversals
                    FROM observability_session_aggregates
                    WHERE session_id = ?
                    """,
                    (str(session_id),),
                ).fetchone()
        except Exception:
            return None

        if row is None:
            return SessionMetrics()
        return SessionMetrics(
            query_count=max(0, int(as_float(row["query_count"]))),
            memory_hits=max(0, int(as_float(row["memory_hits"]))),
            memory_misses=max(0, int(as_float(row["memory_misses"]))),
            activation_sourced_results=max(0, int(as_float(row["activation_sourced_results"]))),
            new_connections_formed=max(0, int(as_float(row["new_connections_formed"]))),
            learning_gated_outcomes=max(0, int(as_float(row["learning_gated_outcomes"]))),
            cross_tier_traversals=max(0, int(as_float(row["cross_tier_traversals"]))),
        )

    def read_weekly_digest_aggregates(
        self,
        *,
        window_start: datetime,
        window_end: datetime,
    ) -> dict[str, int] | None:
        memory = self._memory
        if not isinstance(memory._backend, SQLiteBackend):
            return None
        connect = getattr(memory._backend, "_connect", None)
        if not callable(connect):
            return None

        lower_bound = as_iso8601(window_start)
        upper_bound = as_iso8601(window_end)
        try:
            with connect() as conn:
                row = conn.execute(
                    """
                    SELECT
                        COALESCE(SUM(query_count), 0) AS query_count,
                        COALESCE(SUM(activation_sourced_results), 0) AS activation_sourced_results,
                        COALESCE(SUM(new_connections_formed), 0) AS new_connections_formed,
                        COALESCE(SUM(learning_gated_outcomes), 0) AS learning_gated_outcomes,
                        COALESCE(SUM(cross_tier_traversals), 0) AS cross_tier_traversals
                    FROM observability_weekly_events
                    WHERE occurred_at >= ? AND occurred_at <= ?
                    """,
                    (lower_bound, upper_bound),
                ).fetchone()
        except Exception:
            return None
        if row is None:
            return {
                "query_count": 0,
                "activation_sourced_results": 0,
                "new_connections_formed": 0,
                "learning_gated_outcomes": 0,
                "cross_tier_traversals": 0,
            }
        return {
            "query_count": max(0, int(as_float(row["query_count"]))),
            "activation_sourced_results": max(0, int(as_float(row["activation_sourced_results"]))),
            "new_connections_formed": max(0, int(as_float(row["new_connections_formed"]))),
            "learning_gated_outcomes": max(0, int(as_float(row["learning_gated_outcomes"]))),
            "cross_tier_traversals": max(0, int(as_float(row["cross_tier_traversals"]))),
        }

    def append_recent_query_event(self, event: Mapping[str, Any]) -> None:
        memory = self._memory
        payload = dict(event)
        memory._recent_query_events.append(payload)
        if len(memory._recent_query_events) > memory._recent_event_retention:
            del memory._recent_query_events[: len(memory._recent_query_events) - memory._recent_event_retention]

    def append_recent_outcome_event(self, event: Mapping[str, Any]) -> None:
        memory = self._memory
        payload = dict(event)
        memory._recent_outcome_events.append(payload)
        if len(memory._recent_outcome_events) > memory._recent_event_retention:
            del memory._recent_outcome_events[
                : len(memory._recent_outcome_events) - memory._recent_event_retention
            ]

    def read_recent_queries_durable(
        self,
        *,
        session_id: str | None,
        limit: int,
    ) -> list[dict[str, Any]]:
        memory = self._memory
        if not isinstance(memory._backend, SQLiteBackend):
            return []
        connect = getattr(memory._backend, "_connect", None)
        if not callable(connect):
            return []
        resolved_limit = max(1, int(limit))

        try:
            with connect() as conn:
                if session_id is None:
                    rows = conn.execute(
                        """
                        SELECT
                            query_id,
                            session_id,
                            deployment_id,
                            timestamp,
                            query_embedding_hash,
                            query_type,
                            query_length_tokens
                        FROM telemetry_queries
                        ORDER BY timestamp DESC, query_id DESC
                        LIMIT ?
                        """,
                        (resolved_limit,),
                    ).fetchall()
                else:
                    rows = conn.execute(
                        """
                        SELECT
                            query_id,
                            session_id,
                            deployment_id,
                            timestamp,
                            query_embedding_hash,
                            query_type,
                            query_length_tokens
                        FROM telemetry_queries
                        WHERE session_id = ?
                        ORDER BY timestamp DESC, query_id DESC
                        LIMIT ?
                        """,
                        (str(session_id), resolved_limit),
                    ).fetchall()
        except Exception:
            return []

        return [dict(row) for row in rows]

    def read_recent_outcomes_durable(
        self,
        *,
        session_id: str | None,
        limit: int,
    ) -> list[dict[str, Any]]:
        memory = self._memory
        if not isinstance(memory._backend, SQLiteBackend):
            return []
        connect = getattr(memory._backend, "_connect", None)
        if not callable(connect):
            return []
        resolved_limit = max(1, int(limit))

        try:
            with connect() as conn:
                if session_id is None:
                    rows = conn.execute(
                        """
                        SELECT
                            id,
                            query_id,
                            session_id,
                            provider,
                            composite_score,
                            composite_confidence,
                            learning_gated,
                            oscillation_detected
                        FROM telemetry_outcomes
                        ORDER BY rowid DESC
                        LIMIT ?
                        """,
                        (resolved_limit,),
                    ).fetchall()
                else:
                    rows = conn.execute(
                        """
                        SELECT
                            id,
                            query_id,
                            session_id,
                            provider,
                            composite_score,
                            composite_confidence,
                            learning_gated,
                            oscillation_detected
                        FROM telemetry_outcomes
                        WHERE session_id = ?
                        ORDER BY rowid DESC
                        LIMIT ?
                        """,
                        (str(session_id), resolved_limit),
                    ).fetchall()
        except Exception:
            return []

        return [dict(row) for row in rows]

    def read_recent_sessions_durable(self, *, limit: int) -> list[dict[str, Any]]:
        memory = self._memory
        if not isinstance(memory._backend, SQLiteBackend):
            return []
        connect = getattr(memory._backend, "_connect", None)
        if not callable(connect):
            return []
        resolved_limit = max(1, int(limit))

        try:
            with connect() as conn:
                rows = conn.execute(
                    """
                    SELECT
                        session_id,
                        query_count,
                        memory_hits,
                        memory_misses,
                        activation_sourced_results,
                        new_connections_formed,
                        learning_gated_outcomes,
                        cross_tier_traversals,
                        updated_at
                    FROM observability_session_aggregates
                    ORDER BY updated_at DESC, session_id DESC
                    LIMIT ?
                    """,
                    (resolved_limit,),
                ).fetchall()
        except Exception:
            return []

        summaries: list[dict[str, Any]] = []
        for row in rows:
            updated_at = str(row["updated_at"]) if row["updated_at"] is not None else None
            summaries.append(
                {
                    "session_id": str(row["session_id"]),
                    "started_at": None,
                    "last_activity_at": updated_at,
                    "query_count": max(0, int(as_float(row["query_count"]))),
                    "memory_hits": max(0, int(as_float(row["memory_hits"]))),
                    "memory_misses": max(0, int(as_float(row["memory_misses"]))),
                    "activation_sourced_results": max(
                        0, int(as_float(row["activation_sourced_results"]))
                    ),
                    "new_connections_formed": max(
                        0, int(as_float(row["new_connections_formed"]))
                    ),
                    "learning_gated_outcomes": max(
                        0, int(as_float(row["learning_gated_outcomes"]))
                    ),
                    "cross_tier_traversals": max(
                        0, int(as_float(row["cross_tier_traversals"]))
                    ),
                }
            )
        return summaries

    def recent_graduations_count(self, *, window_start: datetime) -> int:
        memory = self._memory
        if not isinstance(memory._backend, SQLiteBackend):
            return 0
        connect = getattr(memory._backend, "_connect", None)
        if not callable(connect):
            return 0
        try:
            with connect() as conn:
                row = conn.execute(
                    """
                    SELECT COUNT(*) AS count
                    FROM telemetry_graduations
                    WHERE graduated_at >= ?
                    """,
                    (as_iso8601(window_start),),
                ).fetchone()
        except Exception:
            return 0
        if row is None:
            return 0
        return max(0, int(as_float(row["count"])))

    def graph_status_metrics(self, *, now: datetime | None = None) -> Any:
        current_time = utc_now() if now is None else coerce_utc(now)
        window_start = current_time - timedelta(days=7)
        recent_graduations = float(self.recent_graduations_count(window_start=window_start))
        health_counts = self.edge_health_counts(
            window_start=window_start,
            window_end=current_time,
        )
        active_edges = int(health_counts["active_edges_window_7d"])
        if active_edges <= 0:
            return GraphStatusMetrics(recent_graduations_7d=recent_graduations)

        denominator = float(max(1, active_edges))
        converging_ratio = clamp(
            float(health_counts["converging_edges"]) / denominator,
            lower=0.0,
            upper=1.0,
        )
        oscillating_ratio = clamp(
            float(health_counts["oscillating_edges"]) / denominator,
            lower=0.0,
            upper=1.0,
        )
        return GraphStatusMetrics(
            recent_graduations_7d=recent_graduations,
            converging_edge_ratio=converging_ratio,
            oscillating_edge_ratio=oscillating_ratio,
        )

    def edge_health_counts(
        self,
        *,
        window_start: datetime,
        window_end: datetime,
    ) -> dict[str, int]:
        empty = {
            "converging_edges": 0,
            "oscillating_edges": 0,
            "active_edges_window_7d": 0,
        }
        memory = self._memory
        if not isinstance(memory._backend, SQLiteBackend):
            return empty
        connect = getattr(memory._backend, "_connect", None)
        if not callable(connect):
            return empty

        lower_bound = as_iso8601(window_start)
        upper_bound = as_iso8601(window_end)
        try:
            with connect() as conn:
                health_row = conn.execute(
                    """
                    SELECT
                        COALESCE(MAX(converging_edges), 0) AS converging_edges,
                        COALESCE(MAX(oscillating_edges), 0) AS oscillating_edges
                    FROM telemetry_graph_health
                    WHERE snapshot_at >= ? AND snapshot_at <= ?
                    """,
                    (lower_bound, upper_bound),
                ).fetchone()
                active_row = conn.execute(
                    """
                    SELECT COUNT(DISTINCT connection_id) AS count
                    FROM telemetry_connections
                    WHERE COALESCE(last_reinforced_at, formed_at) >= ?
                      AND COALESCE(last_reinforced_at, formed_at) <= ?
                    """,
                    (lower_bound, upper_bound),
                ).fetchone()
                if active_row is None or int(as_float(active_row["count"])) <= 0:
                    active_row = conn.execute(
                        """
                        SELECT COUNT(*) AS count
                        FROM edges
                        WHERE (
                            last_reinforced_at >= ? AND last_reinforced_at <= ?
                        ) OR (
                            formed_at >= ? AND formed_at <= ?
                        )
                        """,
                        (lower_bound, upper_bound, lower_bound, upper_bound),
                    ).fetchone()
        except Exception:
            return empty

        converging_edges = 0
        oscillating_edges = 0
        active_edges = 0
        if health_row is not None:
            converging_edges = max(0, int(as_float(health_row["converging_edges"])))
            oscillating_edges = max(0, int(as_float(health_row["oscillating_edges"])))
        if active_row is not None:
            active_edges = max(0, int(as_float(active_row["count"])))

        return {
            "converging_edges": converging_edges,
            "oscillating_edges": oscillating_edges,
            "active_edges_window_7d": active_edges,
        }
