"""Retrieval/session state helpers for _SynapticEngine."""

from __future__ import annotations

from typing import TYPE_CHECKING, Sequence
from uuid import UUID

from .models import CompositeOutcome, RetrievalResult
from .service_utils import SessionMetrics, as_uuid, clamp, node_tier, utc_now
from .types import MemoryTier

if TYPE_CHECKING:
    from ._engine import _SynapticEngine


class RetrievalState:
    """Encapsulates retrieval history and session metrics state transitions."""

    def __init__(self, memory: _SynapticEngine) -> None:
        self._memory = memory

    def remember_retrieval(self, *, result: RetrievalResult, session_id: str) -> None:
        memory = self._memory
        query_id = str(result.query_id)
        memory._retrieval_history[query_id] = result
        memory._query_sessions[query_id] = session_id
        memory._session_query_ids.setdefault(session_id, []).append(query_id)

    def update_retrieval_metrics(
        self,
        *,
        result: RetrievalResult,
        session_id: str,
        nodes_visited: int,
    ) -> None:
        memory = self._memory
        now = utc_now()
        if session_id not in memory._session_started_at:
            memory._session_started_at[session_id] = now
        memory._session_last_activity_at[session_id] = now
        metrics = memory._session_metrics.setdefault(session_id, SessionMetrics())
        metrics.query_count += 1
        if result.nodes:
            metrics.memory_hits += 1
            memory._total_hits += 1
        else:
            metrics.memory_misses += 1
            memory._total_misses += 1
        metrics.activation_sourced_results += len(result.activation_sourced_node_ids)
        metrics.cross_tier_traversals += int(result.cross_tier_traversals)
        metrics.total_activation_steps += len(result.activation_path)
        metrics.total_nodes_visited += max(0, int(nodes_visited))
        metrics.short_term_activations += len(result.short_term_node_ids)
        metrics.long_term_activations += len(result.long_term_node_ids)
        memory._observability.record_weekly_event(
            query_count=1,
            activation_sourced_results=len(result.activation_sourced_node_ids),
            cross_tier_traversals=int(result.cross_tier_traversals),
        )
        try:
            memory._observability.persist_session_metrics_delta(
                session_id=session_id,
                query_count=1,
                memory_hits=1 if result.nodes else 0,
                memory_misses=0 if result.nodes else 1,
                activation_sourced_results=len(result.activation_sourced_node_ids),
                cross_tier_traversals=int(result.cross_tier_traversals),
            )
        except Exception:
            pass

        memory._total_queries += 1
        memory._total_activation_steps += float(len(result.activation_path))
        memory._graph.mark_query_observed()

    def update_feedback_metrics(
        self,
        *,
        session_id: str,
        composite_outcome: CompositeOutcome,
        created_edges: int,
    ) -> None:
        memory = self._memory
        now = utc_now()
        if session_id not in memory._session_started_at:
            memory._session_started_at[session_id] = now
        memory._session_last_activity_at[session_id] = now
        metrics = memory._session_metrics.setdefault(session_id, SessionMetrics())
        metrics.learning_gated_outcomes += int(composite_outcome.learning_gated)
        metrics.new_connections_formed += max(0, int(created_edges))
        metrics.oscillating_edges_detected += len(composite_outcome.oscillating_edge_ids)
        memory._observability.record_weekly_event(
            new_connections_formed=max(0, int(created_edges)),
            learning_gated_outcomes=int(composite_outcome.learning_gated),
        )
        try:
            memory._observability.persist_session_metrics_delta(
                session_id=session_id,
                new_connections_formed=max(0, int(created_edges)),
                learning_gated_outcomes=int(composite_outcome.learning_gated),
            )
        except Exception:
            pass

    def session_priming_set(self, session_id: str) -> set[str]:
        memory = self._memory
        priming: set[str] = set()
        recent_query_ids = memory._session_query_ids.get(session_id, [])[-5:]
        for query_id in recent_query_ids:
            result = memory._retrieval_history.get(query_id)
            if result is None:
                continue
            priming.update(str(node_id) for node_id in result.long_term_node_ids)
        return priming

    def previous_retrieval_for_session(
        self,
        *,
        session_id: str,
        current_query_id: str,
    ) -> RetrievalResult | None:
        memory = self._memory
        query_ids = memory._session_query_ids.get(session_id, [])
        previous: RetrievalResult | None = None
        for query_id in query_ids:
            if query_id == current_query_id:
                break
            previous = memory._retrieval_history.get(query_id)
        return previous

    def build_retrieval_from_active_nodes(
        self,
        *,
        query_id: UUID,
        active_nodes: Sequence[UUID],
    ) -> RetrievalResult:
        memory = self._memory
        if not active_nodes:
            raise KeyError(f"query_id not found in retrieval history: {query_id}")
        nodes = memory._graph_ops.load_nodes([str(node_id) for node_id in active_nodes])
        short_term_node_ids = [node.id for node in nodes if node_tier(node) == MemoryTier.SHORT_TERM.value]
        long_term_node_ids = [node.id for node in nodes if node_tier(node) == MemoryTier.LONG_TERM.value]
        return RetrievalResult(
            query_id=query_id,
            nodes=nodes,
            activation_path=[],
            seed_node_ids=[as_uuid(node_id) for node_id in active_nodes],
            seed_nodes_contributed=[],
            seed_nodes_dead_ends=[],
            retrieval_latency_ms=0.0,
            activation_latency_ms=0.0,
            graph_confidence=clamp(memory._graph.compute_graph_confidence(), lower=0.0, upper=1.0),
            activation_weight_applied=0.0,
            activation_sourced_node_ids=[],
            fusion_only_node_ids=[],
            short_term_node_ids=short_term_node_ids,
            long_term_node_ids=long_term_node_ids,
            cross_tier_traversals=0,
        )
