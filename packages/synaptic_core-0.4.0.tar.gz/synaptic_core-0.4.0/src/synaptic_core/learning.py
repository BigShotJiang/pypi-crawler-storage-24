"""Hebbian connection learning primitives for Phase 3."""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from itertools import combinations
from typing import Any, Mapping, Sequence
from uuid import NAMESPACE_URL, UUID, uuid5

from .models import CompositeOutcome, Node
from .types import ConnectionType, FormationTrigger, MemoryTier


@dataclass(frozen=True)
class LearningUpdateResult:
    """Summary of learner updates for telemetry and orchestration paths."""

    learning_gated: bool
    updated_edge_ids: list[UUID] = field(default_factory=list)
    created_edge_ids: list[UUID] = field(default_factory=list)
    skipped_oscillating_edge_ids: list[UUID] = field(default_factory=list)
    deferred_pairs_scheduled: int = 0
    deferred_pairs_processed: int = 0
    deferred_pairs_pending: int = 0
    deferred_pairs_coverage_ratio: float = 1.0
    connection_events_pending: int = 0


@dataclass(frozen=True)
class _DeferredPairUpdate:
    query_id: UUID | None
    left_node: Node
    right_node: Node
    left_energy: float
    right_energy: float
    composite_score: float
    oscillating_edge_ids: tuple[str, ...]


@dataclass(frozen=True)
class _PairUpdateOutcome:
    updated_edge_id: UUID | None = None
    created_edge_id: UUID | None = None
    skipped_oscillating_edge_id: UUID | None = None
    event_payload: dict[str, Any] | None = None


class ConnectionLearner:
    """Apply tier-aware Hebbian updates from co-activation and composite outcomes."""

    def __init__(
        self,
        *,
        short_term_learning_rate: float = 0.12,
        long_term_learning_rate: float = 0.025,
        short_term_formation_threshold: float = 0.35,
        long_term_formation_threshold: float = 0.65,
        max_weight: float = 1.0,
        min_weight: float = 0.0,
        max_nodes_per_update: int = 5,
        max_connection_events_per_update: int | None = 10,
        deferred_pair_processing_budget: int = 2,
        telemetry_collector: Any | None = None,
    ) -> None:
        self._short_term_learning_rate = max(0.0, float(short_term_learning_rate))
        self._long_term_learning_rate = max(0.0, float(long_term_learning_rate))
        self._short_term_formation_threshold = max(0.0, float(short_term_formation_threshold))
        self._long_term_formation_threshold = max(0.0, float(long_term_formation_threshold))
        self._max_weight = float(max_weight)
        self._min_weight = float(min_weight)
        self._max_nodes_per_update = max(2, int(max_nodes_per_update))
        if max_connection_events_per_update is None:
            self._max_connection_events_per_update: int | None = None
        else:
            self._max_connection_events_per_update = max(0, int(max_connection_events_per_update))
        self._deferred_pair_processing_budget = max(0, int(deferred_pair_processing_budget))
        if self._min_weight > self._max_weight:
            raise ValueError("min_weight must be <= max_weight")
        self._telemetry_collector = telemetry_collector
        self._pending_deferred_pairs: deque[_DeferredPairUpdate] = deque()
        self._pending_connection_event_payloads: deque[dict[str, Any]] = deque()
        self._deferred_pairs_scheduled_total = 0
        self._deferred_pairs_processed_total = 0

    async def update(
        self,
        *,
        activated_nodes: list[tuple[Node, float]],
        composite_outcome: CompositeOutcome,
        graph: Any,
        query_id: UUID | None = None,
    ) -> LearningUpdateResult:
        normalized_nodes = _normalize_activated_nodes(activated_nodes)
        truncated_nodes = _truncate_activated_nodes(
            normalized_nodes,
            max_nodes=self._max_nodes_per_update,
        )
        deferred_pairs_scheduled = 0
        if len(normalized_nodes) > len(truncated_nodes):
            deferred_pairs_scheduled = self._schedule_bounded_out_pairs(
                all_nodes=normalized_nodes,
                truncated_nodes=truncated_nodes,
                query_id=query_id,
                composite_outcome=composite_outcome,
            )

        deferred_outcomes = self._process_deferred_pairs(
            graph=graph,
            pair_budget=self._deferred_pair_processing_budget,
        )
        pending_connection_events: list[dict[str, Any]] = [
            payload
            for payload in [outcome.event_payload for outcome in deferred_outcomes]
            if payload is not None
        ]

        if composite_outcome.learning_gated:
            self._record_connection_events(pending_connection_events)
            return self._build_result(
                learning_gated=True,
                deferred_pairs_scheduled=deferred_pairs_scheduled,
                deferred_pairs_processed=len(deferred_outcomes),
            )

        if len(truncated_nodes) < 2:
            self._record_connection_events(pending_connection_events)
            return self._build_result(
                learning_gated=False,
                deferred_pairs_scheduled=deferred_pairs_scheduled,
                deferred_pairs_processed=len(deferred_outcomes),
            )

        oscillating_ids = {str(edge_id) for edge_id in composite_outcome.oscillating_edge_ids}
        updated_edge_ids: list[UUID] = []
        created_edge_ids: list[UUID] = []
        skipped_oscillating_edge_ids: list[UUID] = []
        pending_edge_updates: list[tuple[str, dict[str, Any]]] = []

        node_ids = sorted(truncated_nodes.keys())
        edge_lookup = _edge_lookup_for_nodes(graph=graph, node_ids=node_ids)
        for left_id, right_id in combinations(node_ids, 2):
            left_node, left_energy = truncated_nodes[left_id]
            right_node, right_energy = truncated_nodes[right_id]
            outcome = self._apply_pair_update(
                graph=graph,
                left_node=left_node,
                right_node=right_node,
                left_energy=left_energy,
                right_energy=right_energy,
                composite_score=float(composite_outcome.composite_score),
                oscillating_ids=oscillating_ids,
                edge_lookup=edge_lookup,
                pending_edge_updates=pending_edge_updates,
                query_id=query_id,
            )
            if outcome.updated_edge_id is not None:
                updated_edge_ids.append(outcome.updated_edge_id)
            if outcome.created_edge_id is not None:
                created_edge_ids.append(outcome.created_edge_id)
            if outcome.skipped_oscillating_edge_id is not None:
                skipped_oscillating_edge_ids.append(outcome.skipped_oscillating_edge_id)
            if outcome.event_payload is not None:
                pending_connection_events.append(dict(outcome.event_payload))

        _update_edges_bulk(graph=graph, updates=pending_edge_updates)
        self._record_connection_events(pending_connection_events)

        return self._build_result(
            learning_gated=False,
            updated_edge_ids=sorted(set(updated_edge_ids)),
            created_edge_ids=sorted(set(created_edge_ids)),
            skipped_oscillating_edge_ids=sorted(set(skipped_oscillating_edge_ids)),
            deferred_pairs_scheduled=deferred_pairs_scheduled,
            deferred_pairs_processed=len(deferred_outcomes),
        )

    def reconcile_deferred(
        self,
        *,
        graph: Any,
        max_pairs: int | None = None,
    ) -> dict[str, float | int]:
        outcomes = self._process_deferred_pairs(
            graph=graph,
            pair_budget=max_pairs,
        )
        self._record_connection_events(
            [
                payload
                for payload in [outcome.event_payload for outcome in outcomes]
                if payload is not None
            ]
        )
        return self.reconciliation_metrics()

    def reconciliation_metrics(self) -> dict[str, float | int]:
        scheduled_total = max(0, int(self._deferred_pairs_scheduled_total))
        processed_total = max(0, int(self._deferred_pairs_processed_total))
        pending_pairs = len(self._pending_deferred_pairs)
        coverage_ratio = 1.0 if scheduled_total <= 0 else min(1.0, processed_total / scheduled_total)
        return {
            "deferred_pairs_scheduled_total": scheduled_total,
            "deferred_pairs_processed_total": processed_total,
            "deferred_pairs_pending": pending_pairs,
            "deferred_pairs_coverage_ratio": coverage_ratio,
            "connection_events_pending": len(self._pending_connection_event_payloads),
        }

    def _build_result(
        self,
        *,
        learning_gated: bool,
        updated_edge_ids: Sequence[UUID] = (),
        created_edge_ids: Sequence[UUID] = (),
        skipped_oscillating_edge_ids: Sequence[UUID] = (),
        deferred_pairs_scheduled: int = 0,
        deferred_pairs_processed: int = 0,
    ) -> LearningUpdateResult:
        metrics = self.reconciliation_metrics()
        return LearningUpdateResult(
            learning_gated=bool(learning_gated),
            updated_edge_ids=list(updated_edge_ids),
            created_edge_ids=list(created_edge_ids),
            skipped_oscillating_edge_ids=list(skipped_oscillating_edge_ids),
            deferred_pairs_scheduled=max(0, int(deferred_pairs_scheduled)),
            deferred_pairs_processed=max(0, int(deferred_pairs_processed)),
            deferred_pairs_pending=max(0, int(metrics["deferred_pairs_pending"])),
            deferred_pairs_coverage_ratio=float(metrics["deferred_pairs_coverage_ratio"]),
            connection_events_pending=max(0, int(metrics["connection_events_pending"])),
        )

    def _learning_rate_for_pair(self, *, left_node: Node, right_node: Node) -> float:
        left_tier = _tier_value(left_node)
        right_tier = _tier_value(right_node)
        if left_tier == MemoryTier.SHORT_TERM.value and right_tier == MemoryTier.SHORT_TERM.value:
            return self._short_term_learning_rate
        if left_tier == MemoryTier.LONG_TERM.value and right_tier == MemoryTier.LONG_TERM.value:
            return self._long_term_learning_rate
        return (self._short_term_learning_rate + self._long_term_learning_rate) / 2.0

    def _formation_threshold_for_pair(self, *, left_node: Node, right_node: Node) -> float:
        left_tier = _tier_value(left_node)
        right_tier = _tier_value(right_node)
        if left_tier == MemoryTier.SHORT_TERM.value and right_tier == MemoryTier.SHORT_TERM.value:
            return self._short_term_formation_threshold
        if left_tier == MemoryTier.LONG_TERM.value and right_tier == MemoryTier.LONG_TERM.value:
            return self._long_term_formation_threshold
        return (self._short_term_formation_threshold + self._long_term_formation_threshold) / 2.0

    def _record_connection_event(self, payload: Mapping[str, Any]) -> None:
        collector = self._telemetry_collector
        if collector is None:
            return
        try:
            method = getattr(collector, "record_connection", None)
        except Exception:
            return
        if not callable(method):
            return
        try:
            method(dict(payload))
        except Exception:
            return

    def _record_connection_events(self, payloads: Sequence[Mapping[str, Any]]) -> None:
        for payload in payloads:
            self._pending_connection_event_payloads.append(dict(payload))
        budget = self._max_connection_events_per_update
        if budget is None:
            emit_count = len(self._pending_connection_event_payloads)
        else:
            emit_count = min(len(self._pending_connection_event_payloads), max(0, int(budget)))
        for _ in range(emit_count):
            payload = self._pending_connection_event_payloads.popleft()
            self._record_connection_event(payload)

    def _schedule_bounded_out_pairs(
        self,
        *,
        all_nodes: Mapping[str, tuple[Node, float]],
        truncated_nodes: Mapping[str, tuple[Node, float]],
        query_id: UUID | None,
        composite_outcome: CompositeOutcome,
    ) -> int:
        truncated_ids = set(truncated_nodes.keys())
        if len(all_nodes) <= len(truncated_ids):
            return 0
        # Pairs inside the truncated set are already handled synchronously in update().
        processed_pairs = {
            _pair_key(left_id, right_id)
            for left_id, right_id in combinations(sorted(truncated_nodes.keys()), 2)
        }
        oscillating_edge_ids = tuple(str(edge_id) for edge_id in composite_outcome.oscillating_edge_ids)
        scheduled = 0
        all_ids = sorted(all_nodes.keys())
        for left_id, right_id in combinations(all_ids, 2):
            pair = _pair_key(left_id, right_id)
            if pair in processed_pairs:
                continue
            left_node, left_energy = all_nodes[left_id]
            right_node, right_energy = all_nodes[right_id]
            if left_energy <= 0.0 or right_energy <= 0.0:
                continue
            self._pending_deferred_pairs.append(
                _DeferredPairUpdate(
                    query_id=query_id,
                    left_node=left_node,
                    right_node=right_node,
                    left_energy=float(left_energy),
                    right_energy=float(right_energy),
                    composite_score=float(composite_outcome.composite_score),
                    oscillating_edge_ids=oscillating_edge_ids,
                )
            )
            scheduled += 1
        self._deferred_pairs_scheduled_total += scheduled
        return scheduled

    def _process_deferred_pairs(
        self,
        *,
        graph: Any,
        pair_budget: int | None,
    ) -> list[_PairUpdateOutcome]:
        if pair_budget is None:
            process_count = len(self._pending_deferred_pairs)
        else:
            process_count = min(len(self._pending_deferred_pairs), max(0, int(pair_budget)))
        if process_count <= 0:
            return []

        work_items: list[_DeferredPairUpdate] = []
        for _ in range(process_count):
            work_items.append(self._pending_deferred_pairs.popleft())

        # Build one batch edge lookup to avoid repetitive per-pair backend reads.
        edge_lookup = _edge_lookup_for_nodes(
            graph=graph,
            node_ids=sorted(
                {
                    str(work.left_node.id)
                    for work in work_items
                }.union(
                    {str(work.right_node.id) for work in work_items}
                )
            ),
        )
        pending_edge_updates: list[tuple[str, dict[str, Any]]] = []
        outcomes: list[_PairUpdateOutcome] = []
        for work in work_items:
            outcome = self._apply_pair_update(
                graph=graph,
                left_node=work.left_node,
                right_node=work.right_node,
                left_energy=work.left_energy,
                right_energy=work.right_energy,
                composite_score=work.composite_score,
                oscillating_ids=set(work.oscillating_edge_ids),
                edge_lookup=edge_lookup,
                pending_edge_updates=pending_edge_updates,
                query_id=work.query_id,
            )
            outcomes.append(outcome)
        _update_edges_bulk(graph=graph, updates=pending_edge_updates)
        self._deferred_pairs_processed_total += len(outcomes)
        return outcomes

    def _apply_pair_update(
        self,
        *,
        graph: Any,
        left_node: Node,
        right_node: Node,
        left_energy: float,
        right_energy: float,
        composite_score: float,
        oscillating_ids: set[str],
        edge_lookup: dict[tuple[str, str], Mapping[str, Any]] | None,
        pending_edge_updates: list[tuple[str, dict[str, Any]]] | None,
        query_id: UUID | None,
    ) -> _PairUpdateOutcome:
        left_id = str(left_node.id)
        right_id = str(right_node.id)
        if left_energy <= 0.0 or right_energy <= 0.0:
            return _PairUpdateOutcome()

        learning_rate = self._learning_rate_for_pair(left_node=left_node, right_node=right_node)
        delta = learning_rate * left_energy * right_energy * float(composite_score)
        pair = _pair_key(left_id, right_id)

        edge = None if edge_lookup is None else edge_lookup.get(pair)
        if edge is None:
            edge = _get_edge_between(graph=graph, node_a=left_id, node_b=right_id)
        if edge is not None:
            edge_id = str(edge.get("id") or "")
            if edge_id and edge_id in oscillating_ids:
                # Oscillating edges are explicitly excluded from reinforcement to prevent churn.
                skipped_id = _as_uuid(edge_id)
                return _PairUpdateOutcome(
                    skipped_oscillating_edge_id=skipped_id,
                    event_payload={
                        "query_id": _query_id_text(query_id),
                        "connection_id": edge_id,
                        "node_a": left_id,
                        "node_b": right_id,
                        "change_type": "skipped_oscillating",
                        "oscillation_detected": True,
                    },
                )

            if not edge_id:
                edge_id = _edge_id_from_pair(left_id, right_id)
            current_weight = float(edge.get("weight", 0.3))
            new_weight = _clamp(current_weight + delta, lower=self._min_weight, upper=self._max_weight)
            if abs(new_weight - current_weight) <= 1e-12:
                return _PairUpdateOutcome()
            if pending_edge_updates is not None:
                pending_edge_updates.append((edge_id, {"weight": new_weight}))
            else:
                _update_edge(graph=graph, edge_id=edge_id, payload={"weight": new_weight})
            if edge_lookup is not None:
                edge_lookup[pair] = {
                    "id": edge_id,
                    "node_a": left_id,
                    "node_b": right_id,
                    "weight": new_weight,
                }
            edge_uuid = _as_uuid(edge_id)
            return _PairUpdateOutcome(
                updated_edge_id=edge_uuid,
                event_payload={
                    "query_id": _query_id_text(query_id),
                    "connection_id": edge_id,
                    "node_a": left_id,
                    "node_b": right_id,
                    "change_type": "updated",
                    "previous_weight": current_weight,
                    "current_weight": new_weight,
                    "delta_weight": new_weight - current_weight,
                    "oscillation_detected": False,
                },
            )

        co_activation_score = left_energy * right_energy
        formation_threshold = self._formation_threshold_for_pair(
            left_node=left_node,
            right_node=right_node,
        )
        if co_activation_score <= formation_threshold:
            return _PairUpdateOutcome()

        is_cross_tier = _tier_value(left_node) != _tier_value(right_node)
        connection_type = (
            ConnectionType.CROSS_TIER.value if is_cross_tier else ConnectionType.EXCITATORY.value
        )
        create_payload = {
            "node_a": left_id,
            "node_b": right_id,
            "weight": 0.3,
            "initial_weight": 0.3,
            "connection_type": connection_type,
            "formation_trigger": FormationTrigger.CO_ACTIVATION.value,
            "is_cross_tier": is_cross_tier,
        }
        created_edge_id = _create_edge(graph=graph, payload=create_payload)
        if edge_lookup is not None:
            edge_lookup[pair] = {
                "id": created_edge_id,
                "node_a": left_id,
                "node_b": right_id,
                "weight": 0.3,
            }
        created_uuid = _as_uuid(created_edge_id)
        return _PairUpdateOutcome(
            created_edge_id=created_uuid,
            event_payload={
                "query_id": _query_id_text(query_id),
                "connection_id": created_edge_id,
                "node_a": left_id,
                "node_b": right_id,
                "change_type": "created",
                "initial_weight": 0.3,
                "current_weight": 0.3,
                "connection_type": connection_type,
                "formation_trigger": FormationTrigger.CO_ACTIVATION.value,
                "is_cross_tier": is_cross_tier,
                "oscillation_detected": False,
            },
        )


def _normalize_activated_nodes(
    activated_nodes: Sequence[tuple[Node, float]],
) -> dict[str, tuple[Node, float]]:
    normalized: dict[str, tuple[Node, float]] = {}
    for node, energy in activated_nodes:
        node_id = str(node.id)
        value = float(energy)
        if node_id not in normalized or value > normalized[node_id][1]:
            normalized[node_id] = (node, value)
    return normalized


def _truncate_activated_nodes(
    normalized_nodes: Mapping[str, tuple[Node, float]],
    *,
    max_nodes: int,
) -> dict[str, tuple[Node, float]]:
    limit = max(2, int(max_nodes))
    if len(normalized_nodes) <= limit:
        return {str(node_id): (node, float(energy)) for node_id, (node, energy) in normalized_nodes.items()}

    ranked = sorted(
        (
            (str(node_id), node, float(energy))
            for node_id, (node, energy) in normalized_nodes.items()
        ),
        key=lambda item: (-item[2], item[0]),
    )
    return {
        node_id: (node, energy)
        for node_id, node, energy in ranked[:limit]
    }


def _get_edge_between(*, graph: Any, node_a: str, node_b: str) -> Mapping[str, Any] | None:
    for method_name in ("get_edge_between", "get_edge_by_nodes"):
        method = getattr(graph, method_name, None)
        if callable(method):
            edge = method(node_a, node_b)
            if edge:
                return edge
    return None


def _edge_lookup_for_nodes(*, graph: Any, node_ids: Sequence[str]) -> dict[tuple[str, str], Mapping[str, Any]]:
    method = getattr(graph, "get_edges_between_nodes", None)
    if not callable(method):
        return {}
    try:
        raw = method(list(node_ids))
    except Exception:
        return {}
    if not isinstance(raw, Mapping):
        return {}

    edge_lookup: dict[tuple[str, str], Mapping[str, Any]] = {}
    for key, edge in raw.items():
        pair: tuple[str, str] | None = None
        if isinstance(key, tuple) and len(key) == 2:
            pair = _pair_key(str(key[0]), str(key[1]))
        elif isinstance(key, (list, set)) and len(key) == 2:
            left, right = list(key)
            pair = _pair_key(str(left), str(right))
        elif isinstance(key, str):
            if "|" in key:
                left, right = key.split("|", 1)
                pair = _pair_key(left, right)
        if pair is None:
            continue
        if isinstance(edge, Mapping):
            edge_lookup[pair] = dict(edge)
    return edge_lookup


def _update_edge(*, graph: Any, edge_id: str, payload: Mapping[str, Any]) -> None:
    method = getattr(graph, "update_edge", None)
    if not callable(method):
        raise AttributeError("graph must implement update_edge(edge_id, payload)")
    method(edge_id, dict(payload))


def _update_edges_bulk(*, graph: Any, updates: Sequence[tuple[str, Mapping[str, Any]]]) -> None:
    if not updates:
        return
    method = getattr(graph, "update_edges_bulk", None)
    if callable(method):
        method([(str(edge_id), dict(payload)) for edge_id, payload in updates])
        return
    for edge_id, payload in updates:
        _update_edge(graph=graph, edge_id=str(edge_id), payload=dict(payload))


def _create_edge(*, graph: Any, payload: Mapping[str, Any]) -> str:
    method = getattr(graph, "create_edge", None)
    if not callable(method):
        raise AttributeError("graph must implement create_edge(payload)")
    return str(method(dict(payload)))


def _edge_id_from_pair(node_a: str, node_b: str) -> str:
    left, right = sorted([str(node_a), str(node_b)])
    return str(uuid5(NAMESPACE_URL, f"{left}|{right}"))


def _pair_key(node_a: str, node_b: str) -> tuple[str, str]:
    left, right = sorted([str(node_a), str(node_b)])
    return (left, right)


def _tier_value(node: Node) -> str:
    tier = node.memory_tier
    return str(getattr(tier, "value", tier))


def _as_uuid(value: str) -> UUID:
    text = str(value)
    try:
        return UUID(text)
    except (TypeError, ValueError, AttributeError):
        return uuid5(NAMESPACE_URL, text)


def _clamp(value: float, *, lower: float, upper: float) -> float:
    return max(lower, min(upper, float(value)))


def _query_id_text(query_id: UUID | None) -> str:
    if query_id is None:
        return "unknown"
    return str(query_id)


__all__ = ["ConnectionLearner", "LearningUpdateResult"]
