"""Core constants and enums for Synaptic data models."""

from __future__ import annotations

from enum import Enum


class MemoryType:
    """Open-string memory type constants for default usage."""

    FACTUAL = "factual"
    CONTEXTUAL = "contextual"
    PROCEDURAL = "procedural"
    EPISODIC = "episodic"


class MemoryTier(str, Enum):
    SHORT_TERM = "short_term"
    LONG_TERM = "long_term"


class SourceType(str, Enum):
    DOCUMENT = "document"
    URL = "url"
    FILE = "file"
    MANUAL = "manual"


class ConnectionType(str, Enum):
    EXCITATORY = "excitatory"
    INHIBITORY = "inhibitory"
    CROSS_TIER = "cross_tier"


class FormationTrigger(str, Enum):
    CO_ACTIVATION = "co_activation"
    EXPLICIT = "explicit"
    TEMPORAL_PROXIMITY = "temporal_proximity"
    SEMANTIC_SIMILARITY = "semantic_similarity"


class OutcomeSignalType(str, Enum):
    EXPLICIT_POSITIVE = "explicit_positive"
    EXPLICIT_NEGATIVE = "explicit_negative"
    MEMORY_IN_RESPONSE = "memory_in_response"
    CONTRADICTION = "contradiction"
    RE_QUERY_MISS = "re_query_miss"
    SESSION_CONTINUATION = "session_continuation"
    DWELL_TIME = "dwell_time"
    PRODUCTIVE_CONTINUATION = "productive_continuation"
    CORRECTION = "correction"
    CLARIFICATION_NEEDED = "clarification_needed"


__all__ = [
    "ConnectionType",
    "FormationTrigger",
    "MemoryTier",
    "MemoryType",
    "OutcomeSignalType",
    "SourceType",
]
