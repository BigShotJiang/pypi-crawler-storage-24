"""Tier-aware spreading activation primitives."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping, Sequence
from uuid import UUID

from .models import Node
from .types import ConnectionType, MemoryTier


@dataclass(frozen=True)
class ActivationResult:
    """Structured activation output used by retrieval and telemetry paths."""

    ranked_results: list[tuple[str, float]] = field(default_factory=list)
    activated_nodes: list[tuple[Node, float]] = field(default_factory=list)
    activation_path: list[dict[str, Any]] = field(default_factory=list)
    seed_node_ids: list[str] = field(default_factory=list)
    seed_nodes_contributed: list[str] = field(default_factory=list)
    seed_nodes_dead_ends: list[str] = field(default_factory=list)
    short_term_node_ids: list[str] = field(default_factory=list)
    long_term_node_ids: list[str] = field(default_factory=list)
    cross_tier_traversals: int = 0

    def as_hook_payload(self) -> dict[str, Any]:
        return {
            "ranked_results": list(self.ranked_results),
            "activation_path": list(self.activation_path),
            "seed_node_ids": list(self.seed_node_ids),
            "seed_nodes_contributed": list(self.seed_nodes_contributed),
            "seed_nodes_dead_ends": list(self.seed_nodes_dead_ends),
            "cross_tier_traversals": int(self.cross_tier_traversals),
        }


@dataclass(frozen=True)
class _NeighborEdge:
    target_node_id: str
    weight: float
    connection_type: str


class ActivationEngine:
    """Tier-aware spreading activation engine for short- and long-term nodes."""

    def __init__(
        self,
        *,
        short_term_decay_rate: float = 0.35,
        long_term_decay_rate: float = 0.15,
        short_term_activation_threshold: float = 0.2,
        long_term_activation_threshold: float = 0.3,
        max_steps: int = 10,
    ) -> None:
        if max_steps < 0:
            raise ValueError("max_steps must be >= 0")

        self._short_term_decay_rate = _clamp(float(short_term_decay_rate), lower=0.0, upper=1.0)
        self._long_term_decay_rate = _clamp(float(long_term_decay_rate), lower=0.0, upper=1.0)
        self._short_term_activation_threshold = max(0.0, float(short_term_activation_threshold))
        self._long_term_activation_threshold = max(0.0, float(long_term_activation_threshold))
        self._max_steps = int(max_steps)

    async def activate(
        self,
        *,
        seed_nodes: list[tuple[Node, float]],
        graph: Any,
        session_priming_set: set[UUID] | set[str] | None = None,
    ) -> ActivationResult:
        if not seed_nodes:
            return ActivationResult()

        priming_ids = {str(node_id) for node_id in (session_priming_set or set())}

        node_cache: dict[str, Node] = {}
        energies: dict[str, float] = {}
        seed_ids: list[str] = []
        for node, initial_energy in seed_nodes:
            node_id = str(node.id)
            node_cache[node_id] = node
            energies[node_id] = max(energies.get(node_id, 0.0), max(0.0, float(initial_energy)))
            seed_ids.append(node_id)

        unique_seed_ids = sorted(set(seed_ids))
        seed_contributed: set[str] = set()
        seed_dead_ends: set[str] = set(unique_seed_ids)
        activation_path: list[dict[str, Any]] = []
        cross_tier_traversals = 0

        frontier = [
            node_id
            for node_id in unique_seed_ids
            if self._is_above_threshold(
                node_id=node_id,
                energy=energies.get(node_id, 0.0),
                graph=graph,
                node_cache=node_cache,
                priming_ids=priming_ids,
            )
        ]
        frontier.sort(key=lambda node_id: (-energies.get(node_id, 0.0), node_id))

        for step in range(1, self._max_steps + 1):
            if not frontier:
                break
            next_frontier_scores: dict[str, float] = {}
            frontier_set = set(frontier)

            for source_id in frontier:
                source_node = _resolve_node(graph=graph, node_id=source_id, node_cache=node_cache)
                if source_node is None:
                    continue

                source_energy = energies.get(source_id, 0.0)
                if source_energy < self._threshold_for_node(
                    node_id=source_id,
                    node=source_node,
                    priming_ids=priming_ids,
                ):
                    continue

                neighbors = _neighbors_for(graph=graph, node_id=source_id)
                if not neighbors:
                    continue

                for edge in neighbors:
                    if edge.target_node_id in frontier_set:
                        continue

                    target_node = _resolve_node(
                        graph=graph,
                        node_id=edge.target_node_id,
                        node_cache=node_cache,
                    )
                    if target_node is None:
                        continue

                    propagated_energy = self._propagated_energy(
                        source_energy=source_energy,
                        edge_weight=edge.weight,
                        target_node=target_node,
                        connection_type=edge.connection_type,
                    )
                    if propagated_energy == 0.0:
                        continue

                    before = energies.get(edge.target_node_id, 0.0)
                    after = max(0.0, before + propagated_energy)
                    energies[edge.target_node_id] = after

                    target_threshold = self._threshold_for_node(
                        node_id=edge.target_node_id,
                        node=target_node,
                        priming_ids=priming_ids,
                    )
                    if after >= target_threshold and after > before:
                        next_frontier_scores[edge.target_node_id] = max(
                            next_frontier_scores.get(edge.target_node_id, 0.0),
                            after,
                        )

                    is_cross_tier = _is_cross_tier(
                        source_node=source_node,
                        target_node=target_node,
                        connection_type=edge.connection_type,
                    )
                    if is_cross_tier:
                        cross_tier_traversals += 1

                    activation_path.append(
                        {
                            "step": step,
                            "source_node_id": source_id,
                            "target_node_id": edge.target_node_id,
                            "source_energy": round(source_energy, 6),
                            "edge_weight": round(edge.weight, 6),
                            "propagated_energy": round(propagated_energy, 6),
                            "target_energy_before": round(before, 6),
                            "target_energy_after": round(after, 6),
                            "cross_tier": is_cross_tier,
                            "connection_type": edge.connection_type,
                        }
                    )

                    if source_id in seed_dead_ends and after > before:
                        seed_dead_ends.remove(source_id)
                    if source_id in unique_seed_ids and after > before:
                        seed_contributed.add(source_id)

            frontier = [
                node_id
                for node_id, score in sorted(
                    next_frontier_scores.items(),
                    key=lambda item: (-item[1], item[0]),
                )
                if self._is_above_threshold(
                    node_id=node_id,
                    energy=score,
                    graph=graph,
                    node_cache=node_cache,
                    priming_ids=priming_ids,
                )
            ]

        active_scores: dict[str, float] = {}
        for node_id, energy in energies.items():
            if self._is_above_threshold(
                node_id=node_id,
                energy=energy,
                graph=graph,
                node_cache=node_cache,
                priming_ids=priming_ids,
            ):
                active_scores[node_id] = energy

        ranked_results = sorted(
            ((node_id, score) for node_id, score in active_scores.items()),
            key=lambda item: (-item[1], item[0]),
        )

        activated_nodes: list[tuple[Node, float]] = []
        short_term_node_ids: list[str] = []
        long_term_node_ids: list[str] = []
        for node_id, score in ranked_results:
            node = _resolve_node(graph=graph, node_id=node_id, node_cache=node_cache)
            if node is None:
                continue
            activated_nodes.append((node, score))
            if _tier_value(node) == MemoryTier.LONG_TERM.value:
                long_term_node_ids.append(node_id)
            else:
                short_term_node_ids.append(node_id)

        return ActivationResult(
            ranked_results=ranked_results,
            activated_nodes=activated_nodes,
            activation_path=activation_path,
            seed_node_ids=unique_seed_ids,
            seed_nodes_contributed=sorted(seed_contributed),
            seed_nodes_dead_ends=sorted(seed_dead_ends),
            short_term_node_ids=sorted(short_term_node_ids),
            long_term_node_ids=sorted(long_term_node_ids),
            cross_tier_traversals=max(0, int(cross_tier_traversals)),
        )

    def _propagated_energy(
        self,
        *,
        source_energy: float,
        edge_weight: float,
        target_node: Node,
        connection_type: str,
    ) -> float:
        if connection_type == ConnectionType.INHIBITORY.value:
            return -(source_energy * edge_weight)
        tier_decay = self._tier_decay(target_node)
        return max(0.0, source_energy * edge_weight * (1.0 - tier_decay))

    def _threshold_for_node(
        self,
        *,
        node_id: str,
        node: Node,
        priming_ids: set[str],
    ) -> float:
        base = (
            self._long_term_activation_threshold
            if _tier_value(node) == MemoryTier.LONG_TERM.value
            else self._short_term_activation_threshold
        )
        if _tier_value(node) == MemoryTier.LONG_TERM.value and node_id in priming_ids:
            return max(0.05, base - 0.15)
        return base

    def _tier_decay(self, node: Node) -> float:
        if _tier_value(node) == MemoryTier.LONG_TERM.value:
            return self._long_term_decay_rate
        return self._short_term_decay_rate

    def _is_above_threshold(
        self,
        *,
        node_id: str,
        energy: float,
        graph: Any,
        node_cache: dict[str, Node],
        priming_ids: set[str],
    ) -> bool:
        node = _resolve_node(graph=graph, node_id=node_id, node_cache=node_cache)
        if node is None:
            return False
        threshold = self._threshold_for_node(
            node_id=node_id,
            node=node,
            priming_ids=priming_ids,
        )
        return float(energy) >= threshold


def _resolve_node(*, graph: Any, node_id: str, node_cache: dict[str, Node]) -> Node | None:
    if node_id in node_cache:
        return node_cache[node_id]

    get_node = getattr(graph, "get_node", None)
    if callable(get_node):
        node = get_node(node_id)
        if isinstance(node, Node):
            node_cache[node_id] = node
            return node

    nodes = getattr(graph, "nodes", None)
    if isinstance(nodes, Mapping):
        node = nodes.get(node_id)
        if isinstance(node, Node):
            node_cache[node_id] = node
            return node
    return None


def _neighbors_for(*, graph: Any, node_id: str) -> list[_NeighborEdge]:
    get_neighbors = getattr(graph, "get_neighbors", None)
    raw_neighbors: Sequence[object]
    if callable(get_neighbors):
        raw_neighbors = get_neighbors(node_id) or []
    else:
        adjacency = getattr(graph, "adjacency", {})
        if isinstance(adjacency, Mapping):
            raw_neighbors = adjacency.get(node_id, []) or []
        else:
            raw_neighbors = []

    edges: list[_NeighborEdge] = []
    for raw in raw_neighbors:
        edge = _coerce_neighbor_edge(raw)
        if edge is None:
            continue
        edges.append(edge)

    return sorted(edges, key=lambda edge: edge.target_node_id)


def _coerce_neighbor_edge(raw: object) -> _NeighborEdge | None:
    if isinstance(raw, Mapping):
        target = raw.get("target_node_id") or raw.get("target") or raw.get("node_id")
        if target is None:
            return None
        weight = _clamp(float(raw.get("weight", 1.0)), lower=0.0, upper=1.0)
        connection_type = str(raw.get("connection_type", ConnectionType.EXCITATORY.value))
        return _NeighborEdge(
            target_node_id=str(target),
            weight=weight,
            connection_type=connection_type,
        )

    if isinstance(raw, (list, tuple)) and len(raw) >= 2:
        target = raw[0]
        weight = _clamp(float(raw[1]), lower=0.0, upper=1.0)
        connection_type = (
            str(raw[2]) if len(raw) > 2 else ConnectionType.EXCITATORY.value
        )
        return _NeighborEdge(
            target_node_id=str(target),
            weight=weight,
            connection_type=connection_type,
        )

    return None


def _tier_value(node: Node) -> str:
    tier = node.memory_tier
    return str(getattr(tier, "value", tier))


def _is_cross_tier(*, source_node: Node, target_node: Node, connection_type: str) -> bool:
    if connection_type == ConnectionType.CROSS_TIER.value:
        return True
    return _tier_value(source_node) != _tier_value(target_node)


def _clamp(value: float, *, lower: float, upper: float) -> float:
    return max(lower, min(upper, float(value)))


__all__ = ["ActivationEngine", "ActivationResult"]
