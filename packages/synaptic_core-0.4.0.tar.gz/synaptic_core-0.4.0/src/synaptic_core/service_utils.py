"""Shared helpers for runtime service modules and engine compatibility wrappers."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
from typing import Any, Mapping, MutableMapping, Sequence

from .retrieval_utils import as_float, as_uuid, clamp, coerce_source_type, node_tier_value
from .types import ConnectionType, FormationTrigger, OutcomeSignalType, SourceType


@dataclass
class SessionMetrics:
    query_count: int = 0
    memory_hits: int = 0
    memory_misses: int = 0
    activation_sourced_results: int = 0
    new_connections_formed: int = 0
    learning_gated_outcomes: int = 0
    cross_tier_traversals: int = 0
    total_activation_steps: int = 0
    total_nodes_visited: int = 0
    short_term_activations: int = 0
    long_term_activations: int = 0
    oscillating_edges_detected: int = 0


@dataclass
class NodeTelemetryState:
    created_at: datetime
    times_activated: int = 0
    times_in_final_set: int = 0
    last_activated_at: datetime | None = None


@dataclass(frozen=True)
class WeeklyDigestEvent:
    occurred_at: datetime
    query_count: int = 0
    activation_sourced_results: int = 0
    new_connections_formed: int = 0
    learning_gated_outcomes: int = 0
    cross_tier_traversals: int = 0


@dataclass(frozen=True)
class GraphStatusMetrics:
    recent_graduations_7d: float = 0.0
    converging_edge_ratio: float = 0.0
    oscillating_edge_ratio: float = 0.0


def node_tier(node: Any) -> str:
    return node_tier_value(node)


def pair_key(left: str, right: str) -> tuple[str, str]:
    return tuple(sorted([str(left), str(right)]))


def coerce_outcome_signal(outcome: OutcomeSignalType | str) -> OutcomeSignalType:
    if isinstance(outcome, OutcomeSignalType):
        return outcome
    try:
        return OutcomeSignalType(str(outcome))
    except ValueError:
        for option in OutcomeSignalType:
            if option.value == str(outcome):
                return option
        raise ValueError(f"unsupported outcome signal: {outcome}") from None


def session_key(session_id: str | None) -> str:
    normalized = str(session_id or "").strip()
    if not normalized:
        return "default"
    return normalized


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def coerce_utc(value: datetime) -> datetime:
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc)


def as_iso8601(value: datetime) -> str:
    utc_value = coerce_utc(value)
    return utc_value.isoformat().replace("+00:00", "Z")


def parse_iso8601(value: Any) -> datetime | None:
    if value is None:
        return None
    raw = str(value).strip()
    if not raw:
        return None
    if raw.endswith("Z"):
        raw = raw[:-1] + "+00:00"
    parsed = datetime.fromisoformat(raw)
    if parsed.tzinfo is None:
        return parsed.replace(tzinfo=timezone.utc)
    return parsed.astimezone(timezone.utc)


def embedding_hash(embedding: Sequence[float]) -> str:
    digest = hashlib.sha256()
    for value in embedding:
        digest.update(f"{float(value):.8f};".encode("ascii"))
    return digest.hexdigest()[:24]


def confidence_band(confidence: float) -> str:
    value = clamp(float(confidence), lower=0.0, upper=1.0)
    if value < 0.3:
        return "low"
    if value < 0.7:
        return "medium"
    return "high"


def mapping_get(value: object, key: str, default: object) -> object:
    if isinstance(value, Mapping):
        return value.get(key, default)
    return getattr(value, key, default)


def mapping_set(value: object, key: str, update: object) -> None:
    if isinstance(value, MutableMapping):
        value[key] = update
        return
    try:
        setattr(value, key, update)
    except Exception:
        return


def serialize_session_payload(session: object) -> Any:
    serializer = getattr(session, "serialize", None)
    if callable(serializer):
        return serializer()
    if isinstance(session, Mapping):
        return dict(session)
    return session


def normalize_namespace(namespace: str | None) -> str:
    return str(namespace or "")


def keyword_score(key: str, query: str) -> float | None:
    normalized_query = str(query or "")
    if not normalized_query:
        return None
    lowered_query = normalized_query.lower()
    lowered_key = key.lower()
    if lowered_query not in lowered_key:
        return 0.0
    denominator = max(len(lowered_key), 1)
    return min(1.0, len(lowered_query) / float(denominator))


def metadata_matches(metadata: Mapping[str, Any], filters: Mapping[str, Any]) -> bool:
    for key, value in filters.items():
        if metadata.get(key) != value:
            return False
    return True


def coerce_metadata(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return dict(value)
    return {}


def edge_payload(edge: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "id": str(edge.get("id", "")),
        "node_a": str(edge.get("node_a", "")),
        "node_b": str(edge.get("node_b", "")),
        "weight": clamp(as_float(edge.get("weight", 0.0)), lower=0.0, upper=1.0),
        "connection_type": str(edge.get("connection_type", ConnectionType.EXCITATORY.value)),
        "formation_trigger": str(edge.get("formation_trigger", FormationTrigger.EXPLICIT.value)),
        "is_cross_tier": bool(edge.get("is_cross_tier", False)),
    }


__all__ = [
    "GraphStatusMetrics",
    "NodeTelemetryState",
    "SessionMetrics",
    "WeeklyDigestEvent",
    "as_float",
    "as_iso8601",
    "as_uuid",
    "clamp",
    "coerce_metadata",
    "coerce_outcome_signal",
    "coerce_source_type",
    "coerce_utc",
    "confidence_band",
    "edge_payload",
    "embedding_hash",
    "keyword_score",
    "mapping_get",
    "mapping_set",
    "metadata_matches",
    "node_tier",
    "normalize_namespace",
    "pair_key",
    "parse_iso8601",
    "serialize_session_payload",
    "session_key",
    "utc_now",
]
