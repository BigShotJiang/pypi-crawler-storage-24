"""Backend graph adapter bridging backend CRUD/search into graph accessors."""

from __future__ import annotations

from datetime import datetime, timezone
import sqlite3
from typing import Any, Mapping, Sequence
from uuid import NAMESPACE_URL, UUID, uuid5

from .backends.base import MemoryBackend
from .backends.sqlite import SQLiteBackend
from .graph import MemoryGraph, aggregate_graph_confidence
from .models import Node
from .types import MemoryTier, MemoryType, SourceType

class BackendGraph:
    """Bridge backend CRUD/search state into graph-style accessors used by engines."""

    def __init__(
        self,
        backend: MemoryBackend,
        *,
        confidence_refresh_query_interval: int = 10,
    ) -> None:
        self._backend = backend
        self._confidence_refresh_query_interval = max(1, int(confidence_refresh_query_interval))
        self._queries_since_refresh = 0
        self._snapshot_cache: dict[str, float] | None = None
        self._confidence_cache: float | None = None
        self._components_cache: dict[str, float] | None = None

    def mark_query_observed(self) -> None:
        self._queries_since_refresh += 1

    def get_node(self, node_id: str) -> Node | None:
        if isinstance(self._backend, SQLiteBackend):
            record = self._sqlite_node_by_id(str(node_id))
        else:
            record = self._backend.get_node(str(node_id))
        if not record:
            return None
        return Node(
            id=_as_uuid(record.get("id", node_id)),
            content=str(record.get("content", "")),
            embedding=[float(value) for value in record.get("embedding", [])],
            memory_type=str(record.get("memory_type", MemoryType.CONTEXTUAL)),
            memory_tier=str(record.get("memory_tier", MemoryTier.SHORT_TERM.value)),
            created_at=record.get("created_at", _utc_now()),
            last_accessed_at=record.get("last_accessed_at", _utc_now()),
            external_id=record.get("external_id"),
            source_type=_coerce_source_type(record.get("source_type")),
            activation_energy=float(record.get("activation_energy", 1.0)),
            access_count=int(record.get("access_count", 0)),
            staleness_signals=int(record.get("staleness_signals", 0)),
            graduated_at=record.get("graduated_at"),
            graduation_access_count=int(record.get("graduation_access_count", 0)),
        )

    def list_short_term_nodes(self) -> list[Node]:
        list_short_term_nodes = getattr(self._backend, "list_short_term_nodes", None)
        if callable(list_short_term_nodes):
            try:
                raw = list_short_term_nodes() or []
            except Exception:
                raw = []
            return [node for node in raw if isinstance(node, Node)]

        if isinstance(self._backend, SQLiteBackend):
            return self._sqlite_nodes_by_tier(MemoryTier.SHORT_TERM.value)

        node_store = getattr(self._backend, "_nodes", None)
        if isinstance(node_store, Mapping):
            nodes: list[Node] = []
            for node_id in sorted(str(key) for key in node_store.keys()):
                node = self.get_node(node_id)
                if node is None:
                    continue
                if _node_tier(node) != MemoryTier.SHORT_TERM.value:
                    continue
                nodes.append(node)
            return nodes
        return []

    def create_node(self, payload: Mapping[str, Any]) -> str:
        node_id = str(self._backend.create_node(dict(payload)))
        self._invalidate_confidence_cache()
        return node_id

    def update_node(self, node_id: str, payload: Mapping[str, Any]) -> None:
        self._backend.update_node(str(node_id), dict(payload))
        self._invalidate_confidence_cache()

    def delete_node(self, node_id: str) -> None:
        self._backend.delete_node(str(node_id))
        self._invalidate_confidence_cache()

    def get_neighbors(self, node_id: str) -> list[dict[str, Any]]:
        get_neighbors = getattr(self._backend, "get_neighbors", None)
        if callable(get_neighbors):
            try:
                raw = get_neighbors(str(node_id)) or []
            except Exception:
                raw = []
            return [dict(item) for item in raw if isinstance(item, Mapping)]

        if isinstance(self._backend, SQLiteBackend):
            return self._sqlite_neighbors(str(node_id))
        return []

    def get_edges_for_node(self, node_id: str) -> list[dict[str, Any]]:
        get_edges_for_node = getattr(self._backend, "get_edges_for_node", None)
        if callable(get_edges_for_node):
            try:
                raw = get_edges_for_node(str(node_id)) or []
            except Exception:
                raw = []
            return [dict(edge) for edge in raw if isinstance(edge, Mapping)]

        if isinstance(self._backend, SQLiteBackend):
            return self._sqlite_edges_for_node(str(node_id))

        edge_store = getattr(self._backend, "_edges", None)
        if isinstance(edge_store, Mapping):
            results: list[dict[str, Any]] = []
            for edge_id in sorted(str(key) for key in edge_store.keys()):
                edge = edge_store.get(edge_id)
                if not isinstance(edge, Mapping):
                    continue
                node_a = str(edge.get("node_a", ""))
                node_b = str(edge.get("node_b", ""))
                if str(node_id) not in {node_a, node_b}:
                    continue
                payload = dict(edge)
                payload.setdefault("id", edge_id)
                results.append(payload)
            return results
        return []

    def get_edge_between(self, node_a: str, node_b: str) -> Mapping[str, Any] | None:
        get_edge_between = getattr(self._backend, "get_edge_between", None)
        if callable(get_edge_between):
            try:
                edge = get_edge_between(str(node_a), str(node_b))
            except Exception:
                edge = None
            if edge:
                return dict(edge)

        if isinstance(self._backend, SQLiteBackend):
            return self._sqlite_edge_between(str(node_a), str(node_b))
        return None

    def update_edge(self, edge_id: str, payload: Mapping[str, Any]) -> None:
        if (
            isinstance(self._backend, SQLiteBackend)
            and {"is_cross_tier", "pruned_at_graduation"}.intersection(payload.keys())
        ):
            self._sqlite_update_edge_graduation_fields(edge_id=edge_id, payload=payload)
            self._invalidate_confidence_cache()
            return
        self._backend.update_edge(str(edge_id), dict(payload))
        self._invalidate_confidence_cache()

    def update_edges_bulk(self, updates: Sequence[tuple[str, Mapping[str, Any]]]) -> None:
        normalized_updates = [
            (str(edge_id), dict(payload))
            for edge_id, payload in updates
        ]
        if not normalized_updates:
            return

        if isinstance(self._backend, SQLiteBackend) and any(
            {"is_cross_tier", "pruned_at_graduation"}.intersection(payload.keys())
            for _, payload in normalized_updates
        ):
            for edge_id, payload in normalized_updates:
                self.update_edge(edge_id, payload)
            return

        update_edges_bulk = getattr(self._backend, "update_edges_bulk", None)
        if callable(update_edges_bulk):
            update_edges_bulk(normalized_updates)
            self._invalidate_confidence_cache()
            return

        for edge_id, payload in normalized_updates:
            self._backend.update_edge(edge_id, payload)
        self._invalidate_confidence_cache()

    def create_edge(self, payload: Mapping[str, Any]) -> str:
        edge_id = str(self._backend.create_edge(dict(payload)))
        self._invalidate_confidence_cache()
        return edge_id

    def delete_edge(self, edge_id: str) -> None:
        self._backend.delete_edge(str(edge_id))
        self._invalidate_confidence_cache()

    def get_edges_between_nodes(
        self,
        node_ids: Sequence[str],
    ) -> dict[tuple[str, str], Mapping[str, Any]]:
        unique_ids = sorted({str(node_id) for node_id in node_ids if str(node_id)})
        if len(unique_ids) < 2:
            return {}

        if isinstance(self._backend, SQLiteBackend):
            return self._sqlite_edges_between_nodes(unique_ids)

        edge_lookup: dict[tuple[str, str], Mapping[str, Any]] = {}
        for idx, node_a in enumerate(unique_ids):
            for node_b in unique_ids[idx + 1 :]:
                edge = self.get_edge_between(node_a, node_b)
                if edge is None:
                    continue
                pair = _pair_key(node_a, node_b)
                if pair not in edge_lookup:
                    edge_lookup[pair] = dict(edge)
        return edge_lookup

    def get_graduation_metrics(
        self,
        node_ids: Sequence[str],
        *,
        reinforced_edge_weight_threshold: float = 0.45,
    ) -> dict[str, dict[str, float | int]]:
        node_keys = sorted({str(node_id) for node_id in node_ids if str(node_id)})
        if not node_keys:
            return {}
        if isinstance(self._backend, SQLiteBackend):
            return self._sqlite_graduation_metrics(
                node_ids=node_keys,
                reinforced_edge_weight_threshold=reinforced_edge_weight_threshold,
            )

        return {
            node_id: {
                "positive_outcome_ratio": 0.0,
                "reinforced_edge_count": sum(
                    1
                    for edge in self.get_edges_for_node(node_id)
                    if _as_float(edge.get("weight", 0.0)) > float(reinforced_edge_weight_threshold)
                ),
            }
            for node_id in node_keys
        }

    def compute_graph_confidence(self) -> float:
        self._ensure_confidence_cache()
        return float(self._confidence_cache or 0.0)

    def graph_confidence_components(self) -> dict[str, float]:
        self._ensure_confidence_cache()
        return dict(self._components_cache or {})

    def snapshot(self) -> dict[str, float]:
        self._ensure_confidence_cache()
        return dict(self._snapshot_cache or self._snapshot_uncached())

    def _ensure_confidence_cache(self) -> None:
        should_refresh = (
            self._snapshot_cache is None
            or self._confidence_cache is None
            or self._components_cache is None
            or self._queries_since_refresh >= self._confidence_refresh_query_interval
        )
        if not should_refresh:
            return

        snapshot = self._snapshot_uncached()
        graph = MemoryGraph(
            node_count=int(snapshot["node_count"]),
            edge_count=int(snapshot["edge_count"]),
            avg_edge_weight=float(snapshot["avg_edge_weight"]),
            avg_edge_activation_count=float(snapshot["avg_edge_activation_count"]),
        )
        components = graph.graph_confidence_components()
        self._snapshot_cache = dict(snapshot)
        self._components_cache = components.as_dict()
        self._confidence_cache = float(aggregate_graph_confidence(components))
        self._queries_since_refresh = 0

    def _invalidate_confidence_cache(self) -> None:
        self._snapshot_cache = None
        self._confidence_cache = None
        self._components_cache = None
        self._queries_since_refresh = 0

    def _snapshot_uncached(self) -> dict[str, float]:
        graph_snapshot = getattr(self._backend, "graph_snapshot", None)
        if callable(graph_snapshot):
            try:
                raw = graph_snapshot()
            except Exception:
                raw = None
            if isinstance(raw, Mapping):
                return {
                    "node_count": float(raw.get("node_count", 0.0)),
                    "edge_count": float(raw.get("edge_count", 0.0)),
                    "short_term_nodes": float(raw.get("short_term_nodes", 0.0)),
                    "long_term_nodes": float(raw.get("long_term_nodes", 0.0)),
                    "cross_tier_edges": float(raw.get("cross_tier_edges", 0.0)),
                    "avg_edge_weight": float(raw.get("avg_edge_weight", 0.0)),
                    "avg_edge_activation_count": float(raw.get("avg_edge_activation_count", 0.0)),
                }

        if isinstance(self._backend, SQLiteBackend):
            return self._sqlite_snapshot()

        node_store = getattr(self._backend, "_nodes", {})
        edge_store = getattr(self._backend, "_edges", {})
        if isinstance(node_store, Mapping):
            node_count = len(node_store)
            short_term_nodes = sum(
                1
                for payload in node_store.values()
                if str(getattr(payload, "memory_tier", "short_term")) == MemoryTier.SHORT_TERM.value
            )
            long_term_nodes = node_count - short_term_nodes
        else:
            node_count = 0
            short_term_nodes = 0
            long_term_nodes = 0

        if isinstance(edge_store, Mapping):
            edges = list(edge_store.values())
        else:
            edges = []
        edge_count = len(edges)
        avg_edge_weight = (
            sum(float(_mapping_get(edge, "weight", 0.0)) for edge in edges) / edge_count
            if edge_count
            else 0.0
        )
        avg_edge_activation_count = (
            sum(float(_mapping_get(edge, "activation_count", 0.0)) for edge in edges) / edge_count
            if edge_count
            else 0.0
        )
        cross_tier_edges = sum(1 for edge in edges if bool(_mapping_get(edge, "is_cross_tier", False)))

        return {
            "node_count": float(node_count),
            "edge_count": float(edge_count),
            "short_term_nodes": float(short_term_nodes),
            "long_term_nodes": float(long_term_nodes),
            "cross_tier_edges": float(cross_tier_edges),
            "avg_edge_weight": float(avg_edge_weight),
            "avg_edge_activation_count": float(avg_edge_activation_count),
        }

    def _sqlite_node_by_id(self, node_id: str) -> dict[str, Any] | None:
        connect = getattr(self._backend, "_connect", None)
        if not callable(connect):
            return None
        try:
            with connect() as conn:
                row = conn.execute(
                    """
                    SELECT
                        id,
                        content,
                        embedding,
                        memory_type,
                        memory_tier,
                        created_at,
                        last_accessed_at,
                        access_count,
                        activation_energy,
                        staleness_signals,
                        graduated_at,
                        graduation_access_count,
                        external_id,
                        source_type
                    FROM nodes
                    WHERE id = ?
                    LIMIT 1
                    """,
                    (str(node_id),),
                ).fetchone()
        except Exception:
            return None
        if row is None:
            return None
        blob_to_embedding = getattr(self._backend, "_blob_to_embedding", None)
        if callable(blob_to_embedding):
            embedding = blob_to_embedding(row["embedding"])
        else:
            embedding = []
        return {
            "id": str(row["id"]),
            "content": str(row["content"]),
            "embedding": [float(value) for value in embedding],
            "memory_type": str(row["memory_type"]),
            "memory_tier": str(row["memory_tier"]),
            "created_at": row["created_at"],
            "last_accessed_at": row["last_accessed_at"],
            "access_count": int(row["access_count"]),
            "activation_energy": float(row["activation_energy"]),
            "staleness_signals": int(row["staleness_signals"]),
            "graduated_at": row["graduated_at"],
            "graduation_access_count": int(row["graduation_access_count"]),
            "external_id": row["external_id"],
            "source_type": row["source_type"],
        }

    def _sqlite_nodes_by_tier(self, tier: str) -> list[Node]:
        connect = getattr(self._backend, "_connect", None)
        if not callable(connect):
            return []
        try:
            with connect() as conn:
                rows = conn.execute(
                    """
                    SELECT id
                    FROM nodes
                    WHERE memory_tier = ?
                    ORDER BY id
                    """,
                    (str(tier),),
                ).fetchall()
        except Exception:
            return []
        nodes: list[Node] = []
        for row in rows:
            node = self.get_node(str(row["id"]))
            if node is None:
                continue
            nodes.append(node)
        return nodes

    def _sqlite_edges_for_node(self, node_id: str) -> list[dict[str, Any]]:
        connect = getattr(self._backend, "_connect", None)
        if not callable(connect):
            return []
        try:
            with connect() as conn:
                rows = conn.execute(
                    """
                    SELECT id, node_a, node_b, weight, is_cross_tier, pruned_at_graduation
                    FROM edges
                    WHERE node_a = ? OR node_b = ?
                    ORDER BY id
                    """,
                    (str(node_id), str(node_id)),
                ).fetchall()
        except Exception:
            return []
        return [dict(row) for row in rows]

    def _sqlite_graduation_metrics(
        self,
        *,
        node_ids: Sequence[str],
        reinforced_edge_weight_threshold: float,
    ) -> dict[str, dict[str, float | int]]:
        connect = getattr(self._backend, "_connect", None)
        if not callable(connect):
            return {}
        node_keys = [str(node_id) for node_id in node_ids if str(node_id)]
        if not node_keys:
            return {}

        placeholders = ", ".join("?" for _ in node_keys)
        reinforced_counts = {node_id: 0 for node_id in node_keys}
        positive_counts = {node_id: 0 for node_id in node_keys}
        outcome_counts = {node_id: 0 for node_id in node_keys}
        try:
            with connect() as conn:
                edge_rows = conn.execute(
                    f"""
                    SELECT node_a, node_b, weight
                    FROM edges
                    WHERE node_a IN ({placeholders}) OR node_b IN ({placeholders})
                    """,
                    tuple(node_keys) + tuple(node_keys),
                ).fetchall()
                outcome_rows = conn.execute(
                    """
                    SELECT composite_score, active_nodes_during_outcome
                    FROM telemetry_outcomes
                    WHERE active_nodes_during_outcome IS NOT NULL
                    """
                ).fetchall()
        except Exception:
            return {}

        threshold = float(reinforced_edge_weight_threshold)
        node_key_set = set(node_keys)
        for row in edge_rows:
            node_a = str(row["node_a"])
            node_b = str(row["node_b"])
            weight = _as_float(row["weight"])
            if weight <= threshold:
                continue
            if node_a in node_key_set:
                reinforced_counts[node_a] = reinforced_counts.get(node_a, 0) + 1
            if node_b in node_key_set:
                reinforced_counts[node_b] = reinforced_counts.get(node_b, 0) + 1

        for row in outcome_rows:
            composite_score = _as_float(row["composite_score"])
            raw_active_nodes = row["active_nodes_during_outcome"]
            if raw_active_nodes is None:
                continue
            try:
                active_nodes = json.loads(str(raw_active_nodes))
            except (TypeError, ValueError, json.JSONDecodeError):
                continue
            if not isinstance(active_nodes, list):
                continue
            for node_id in active_nodes:
                node_key = str(node_id)
                if node_key not in node_key_set:
                    continue
                outcome_counts[node_key] = outcome_counts.get(node_key, 0) + 1
                if composite_score > 0.1:
                    positive_counts[node_key] = positive_counts.get(node_key, 0) + 1

        metrics: dict[str, dict[str, float | int]] = {}
        for node_id in node_keys:
            total = outcome_counts.get(node_id, 0)
            if total <= 0:
                ratio = 0.0
            else:
                ratio = _clamp(
                    float(positive_counts.get(node_id, 0)) / float(total),
                    lower=0.0,
                    upper=1.0,
                )
            metrics[node_id] = {
                "positive_outcome_ratio": ratio,
                "reinforced_edge_count": int(reinforced_counts.get(node_id, 0)),
            }
        return metrics

    def _sqlite_update_edge_graduation_fields(self, *, edge_id: str, payload: Mapping[str, Any]) -> None:
        connect = getattr(self._backend, "_connect", None)
        if not callable(connect):
            raise KeyError(f"edge not found: {edge_id}")
        with connect() as conn:
            row = conn.execute(
                """
                SELECT is_cross_tier, pruned_at_graduation
                FROM edges
                WHERE id = ?
                """,
                (str(edge_id),),
            ).fetchone()
            if row is None:
                raise KeyError(f"edge not found: {edge_id}")
            next_cross_tier = bool(payload.get("is_cross_tier", row["is_cross_tier"]))
            next_pruned = bool(payload.get("pruned_at_graduation", row["pruned_at_graduation"]))
            conn.execute(
                """
                UPDATE edges
                SET is_cross_tier = ?, pruned_at_graduation = ?
                WHERE id = ?
                """,
                (1 if next_cross_tier else 0, 1 if next_pruned else 0, str(edge_id)),
            )
            conn.commit()

    def _sqlite_neighbors(self, node_id: str) -> list[dict[str, Any]]:
        connect = getattr(self._backend, "_connect", None)
        if not callable(connect):
            return []
        neighbors: list[dict[str, Any]] = []
        try:
            with connect() as conn:
                rows = conn.execute(
                    """
                    SELECT node_a, node_b, weight, connection_type
                    FROM edges
                    WHERE node_a = ? OR node_b = ?
                    ORDER BY id
                    """,
                    (node_id, node_id),
                ).fetchall()
        except Exception:
            return []
        for row in rows:
            node_a = str(row["node_a"])
            node_b = str(row["node_b"])
            if node_a == node_id:
                target_node_id = node_b
            else:
                target_node_id = node_a
            neighbors.append(
                {
                    "target_node_id": target_node_id,
                    "weight": float(row["weight"]),
                    "connection_type": str(row["connection_type"]),
                }
            )
        return neighbors

    def _sqlite_edge_between(self, node_a: str, node_b: str) -> Mapping[str, Any] | None:
        connect = getattr(self._backend, "_connect", None)
        if not callable(connect):
            return None
        left, right = sorted([node_a, node_b])
        try:
            with connect() as conn:
                row = conn.execute(
                    """
                    SELECT id, node_a, node_b, weight, connection_type, formation_trigger, is_cross_tier
                    FROM edges
                    WHERE (node_a = ? AND node_b = ?) OR (node_a = ? AND node_b = ?)
                    LIMIT 1
                    """,
                    (left, right, right, left),
                ).fetchone()
        except Exception:
            return None
        if row is None:
            return None
        return {
            "id": str(row["id"]),
            "node_a": str(row["node_a"]),
            "node_b": str(row["node_b"]),
            "weight": float(row["weight"]),
            "connection_type": str(row["connection_type"]),
            "formation_trigger": str(row["formation_trigger"]),
            "is_cross_tier": bool(row["is_cross_tier"]),
        }

    def _sqlite_edges_between_nodes(
        self,
        node_ids: Sequence[str],
    ) -> dict[tuple[str, str], Mapping[str, Any]]:
        connect = getattr(self._backend, "_connect", None)
        if not callable(connect):
            return {}
        if not node_ids:
            return {}

        placeholders = ", ".join("?" for _ in node_ids)
        edge_lookup: dict[tuple[str, str], Mapping[str, Any]] = {}
        try:
            with connect() as conn:
                rows = conn.execute(
                    f"""
                    SELECT id, node_a, node_b, weight, connection_type, formation_trigger, is_cross_tier
                    FROM edges
                    WHERE node_a IN ({placeholders}) AND node_b IN ({placeholders})
                    ORDER BY id
                    """,
                    tuple(node_ids) + tuple(node_ids),
                ).fetchall()
        except Exception:
            return {}

        for row in rows:
            node_a = str(row["node_a"])
            node_b = str(row["node_b"])
            if node_a == node_b:
                continue
            pair = _pair_key(node_a, node_b)
            if pair in edge_lookup:
                continue
            edge_lookup[pair] = {
                "id": str(row["id"]),
                "node_a": node_a,
                "node_b": node_b,
                "weight": float(row["weight"]),
                "connection_type": str(row["connection_type"]),
                "formation_trigger": str(row["formation_trigger"]),
                "is_cross_tier": bool(row["is_cross_tier"]),
            }
        return edge_lookup

    def _sqlite_snapshot(self) -> dict[str, float]:
        connect = getattr(self._backend, "_connect", None)
        if not callable(connect):
            return {
                "node_count": 0.0,
                "edge_count": 0.0,
                "short_term_nodes": 0.0,
                "long_term_nodes": 0.0,
                "cross_tier_edges": 0.0,
                "avg_edge_weight": 0.0,
                "avg_edge_activation_count": 0.0,
            }
        try:
            with connect() as conn:
                node_count = _sqlite_scalar(conn, "SELECT COUNT(*) FROM nodes")
                edge_count = _sqlite_scalar(conn, "SELECT COUNT(*) FROM edges")
                short_term_nodes = _sqlite_scalar(
                    conn,
                    "SELECT COUNT(*) FROM nodes WHERE memory_tier = 'short_term'",
                )
                long_term_nodes = _sqlite_scalar(
                    conn,
                    "SELECT COUNT(*) FROM nodes WHERE memory_tier = 'long_term'",
                )
                cross_tier_edges = _sqlite_scalar(
                    conn,
                    "SELECT COUNT(*) FROM edges WHERE is_cross_tier = 1",
                )
                avg_edge_weight = _sqlite_scalar(
                    conn,
                    "SELECT COALESCE(AVG(weight), 0.0) FROM edges",
                )
                avg_edge_activation_count = _sqlite_scalar(
                    conn,
                    "SELECT COALESCE(AVG(activation_count), 0.0) FROM edges",
                )
        except Exception:
            return {
                "node_count": 0.0,
                "edge_count": 0.0,
                "short_term_nodes": 0.0,
                "long_term_nodes": 0.0,
                "cross_tier_edges": 0.0,
                "avg_edge_weight": 0.0,
                "avg_edge_activation_count": 0.0,
            }
        return {
            "node_count": float(node_count),
            "edge_count": float(edge_count),
            "short_term_nodes": float(short_term_nodes),
            "long_term_nodes": float(long_term_nodes),
            "cross_tier_edges": float(cross_tier_edges),
            "avg_edge_weight": float(avg_edge_weight),
            "avg_edge_activation_count": float(avg_edge_activation_count),
        }




def _pair_key(left: str, right: str) -> tuple[str, str]:
    return tuple(sorted([str(left), str(right)]))


def _as_uuid(value: object) -> UUID:
    text = str(value)
    try:
        return UUID(text)
    except (TypeError, ValueError, AttributeError):
        return uuid5(NAMESPACE_URL, text)


def _clamp(value: float, *, lower: float, upper: float) -> float:
    return max(lower, min(upper, float(value)))


def _as_float(value: object) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _coerce_source_type(value: object) -> SourceType | None:
    if value is None:
        return None
    if isinstance(value, SourceType):
        return value
    try:
        return SourceType(str(value))
    except ValueError:
        return None


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _mapping_get(value: object, key: str, default: object) -> object:
    if isinstance(value, Mapping):
        return value.get(key, default)
    return getattr(value, key, default)


def _node_tier(node: Node) -> str:
    tier = node.memory_tier
    return str(getattr(tier, "value", tier))


def _sqlite_scalar(conn: sqlite3.Connection, sql: str) -> float:
    row = conn.execute(sql).fetchone()
    if row is None:
        return 0.0
    return _as_float(row[0])
