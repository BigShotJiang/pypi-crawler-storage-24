"""Adaptive tuning hooks for graduation scheduling and optimizer updates."""

from __future__ import annotations

import asyncio
from datetime import datetime
from typing import TYPE_CHECKING, Mapping

from .models import CompositeOutcome
from .service_utils import as_float, clamp, utc_now

if TYPE_CHECKING:
    from ._engine import _SynapticEngine


class AdaptiveTuning:
    """Encapsulates graduation scheduling and runtime parameter tuning."""

    def __init__(self, memory: _SynapticEngine) -> None:
        self._memory = memory

    def schedule_graduation_if_due(self, *, count_query: bool) -> None:
        memory = self._memory
        if not memory._graduation_scheduler_enabled:
            return

        task = memory._graduation_task
        if task is not None and not task.done():
            if count_query:
                memory._graduation_queries_since_check += 1
            return

        if count_query:
            memory._graduation_queries_since_check += 1

        now = utc_now()
        due_by_query = memory._graduation_queries_since_check >= memory._graduation_check_interval_queries
        elapsed_seconds = (now - memory._graduation_last_scheduled_at).total_seconds()
        due_by_time = elapsed_seconds >= memory._graduation_check_interval_seconds
        if not due_by_query and not due_by_time:
            return

        memory._graduation_last_scheduled_at = now
        memory._graduation_queries_since_check = 0
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            return
        task = loop.create_task(self.run_graduation_cycle(now=now))
        task.add_done_callback(self.on_graduation_task_done)
        memory._graduation_task = task

    async def run_graduation_cycle(self, *, now: datetime) -> None:
        memory = self._memory
        engine = memory._graduation_engine
        if engine is None:
            return
        try:
            evaluation = await engine.evaluate_candidates(graph=memory._graph, now=now)
            await engine.apply_graduations(
                graph=memory._graph,
                eligibility_report=evaluation,
                now=now,
            )
        except Exception:
            return

    def on_graduation_task_done(self, task: asyncio.Task[None]) -> None:
        memory = self._memory
        if memory._graduation_task is task:
            memory._graduation_task = None
        try:
            task.result()
        except Exception:
            return

    def run_continuous_instance_optimization(
        self,
        *,
        composite_outcome: CompositeOutcome,
        created_edges: int,
    ) -> None:
        memory = self._memory
        optimizer = memory._instance_optimizer
        if optimizer is None:
            return

        memory._optimizer_feedback_count += 1
        if float(composite_outcome.composite_score) > 0.0:
            memory._optimizer_positive_outcome_count += 1
        elif float(composite_outcome.composite_score) < 0.0:
            memory._optimizer_negative_outcome_count += 1
        memory._optimizer_learning_gated_count += int(bool(composite_outcome.learning_gated))
        memory._optimizer_created_edges_total += max(0, int(created_edges))

        if (memory._optimizer_feedback_count % memory._instance_optimizer_update_interval) != 0:
            return

        try:
            snapshot = self.build_optimizer_snapshot()
            updated = optimizer.optimize(snapshot)
            self.apply_optimizer_runtime_params(updated)
        except Exception:
            return

    def build_optimizer_snapshot(self) -> dict[str, object]:
        memory = self._memory
        feedback_count = max(1, int(memory._optimizer_feedback_count))
        positive_rate = clamp(
            float(memory._optimizer_positive_outcome_count) / float(feedback_count),
            lower=0.0,
            upper=1.0,
        )
        negative_rate = clamp(
            float(memory._optimizer_negative_outcome_count) / float(feedback_count),
            lower=0.0,
            upper=1.0,
        )
        learning_gated_rate = clamp(
            float(memory._optimizer_learning_gated_count) / float(feedback_count),
            lower=0.0,
            upper=1.0,
        )
        created_edges_rate = max(
            0.0,
            float(memory._optimizer_created_edges_total) / float(feedback_count),
        )
        total_hits_and_misses = memory._total_hits + memory._total_misses
        hit_rate = (
            clamp(
                float(memory._total_hits) / float(total_hits_and_misses),
                lower=0.0,
                upper=1.0,
            )
            if total_hits_and_misses > 0
            else 0.0
        )
        graph_confidence = clamp(
            float(memory._graph.compute_graph_confidence()),
            lower=0.0,
            upper=1.0,
        )

        param_direction_scores = {
            "st_decay_rate": 0.0,
            "lt_decay_rate": 0.0,
            "st_activation_threshold": 0.0,
            "lt_activation_threshold": 0.0,
            "st_learning_rate": 0.0,
            "lt_learning_rate": 0.0,
            "st_formation_threshold": 0.0,
            "lt_formation_threshold": 0.0,
            "learning_gate_threshold": 0.0,
        }

        if graph_confidence < 0.35:
            for name in (
                "st_decay_rate",
                "lt_decay_rate",
                "st_activation_threshold",
                "lt_activation_threshold",
                "st_formation_threshold",
            ):
                param_direction_scores[name] -= 1.0
            param_direction_scores["st_learning_rate"] += 1.0

        if hit_rate < 0.65:
            param_direction_scores["st_activation_threshold"] -= 1.0
            param_direction_scores["lt_activation_threshold"] -= 1.0

        if positive_rate < 0.45:
            param_direction_scores["st_learning_rate"] -= 1.0
            param_direction_scores["lt_learning_rate"] -= 1.0
            param_direction_scores["st_formation_threshold"] += 1.0
            param_direction_scores["lt_formation_threshold"] += 1.0
            param_direction_scores["learning_gate_threshold"] += 1.0
        elif positive_rate > 0.70 and created_edges_rate < 0.10:
            param_direction_scores["st_learning_rate"] += 1.0
            param_direction_scores["lt_learning_rate"] += 1.0
            param_direction_scores["st_formation_threshold"] -= 1.0
            param_direction_scores["lt_formation_threshold"] -= 1.0

        if learning_gated_rate > 0.50:
            param_direction_scores["learning_gate_threshold"] -= 1.0
        elif learning_gated_rate < 0.10 and negative_rate > 0.40:
            param_direction_scores["learning_gate_threshold"] += 1.0

        param_directions = {
            name: 1 if score > 0.0 else -1 if score < 0.0 else 0
            for name, score in sorted(param_direction_scores.items())
        }
        suppression_diagnostic = None
        if memory._total_queries >= 200 and graph_confidence < 0.2:
            component_scores = memory._graph.graph_confidence_components()
            suppressed_components = [
                name
                for name, score in component_scores.items()
                if float(score) < 0.2
            ]
            if not suppressed_components and component_scores:
                suppressed_components = [
                    min(component_scores, key=component_scores.__getitem__)
                ]
            suppression_diagnostic = {
                "suppressed_components": sorted(suppressed_components),
                "component_scores": component_scores,
            }

        return {
            "sample_count": int(feedback_count),
            "query_count": int(memory._total_queries),
            "graph_confidence": float(graph_confidence),
            "param_directions": param_directions,
            "suppression_diagnostic": suppression_diagnostic,
        }

    def optimizer_runtime_params(self) -> dict[str, float]:
        memory = self._memory
        params: dict[str, float] = {}
        st_decay = getattr(memory._activation_engine, "_short_term_decay_rate", None)
        lt_decay = getattr(memory._activation_engine, "_long_term_decay_rate", None)
        st_threshold = getattr(memory._activation_engine, "_short_term_activation_threshold", None)
        lt_threshold = getattr(memory._activation_engine, "_long_term_activation_threshold", None)
        st_lr = getattr(memory._connection_learner, "_short_term_learning_rate", None)
        lt_lr = getattr(memory._connection_learner, "_long_term_learning_rate", None)
        st_form = getattr(memory._connection_learner, "_short_term_formation_threshold", None)
        lt_form = getattr(memory._connection_learner, "_long_term_formation_threshold", None)
        gate = getattr(memory._outcome_detector, "_learning_gate_threshold", None)

        if st_decay is not None:
            params["st_decay_rate"] = clamp(as_float(st_decay), lower=0.0, upper=1.0)
        if lt_decay is not None:
            params["lt_decay_rate"] = clamp(as_float(lt_decay), lower=0.0, upper=1.0)
        if st_threshold is not None:
            params["st_activation_threshold"] = max(0.0, as_float(st_threshold))
        if lt_threshold is not None:
            params["lt_activation_threshold"] = max(0.0, as_float(lt_threshold))
        if st_lr is not None:
            params["st_learning_rate"] = max(0.0, as_float(st_lr))
        if lt_lr is not None:
            params["lt_learning_rate"] = max(0.0, as_float(lt_lr))
        if st_form is not None:
            params["st_formation_threshold"] = max(0.0, as_float(st_form))
        if lt_form is not None:
            params["lt_formation_threshold"] = max(0.0, as_float(lt_form))
        if gate is not None:
            params["learning_gate_threshold"] = clamp(
                as_float(gate),
                lower=0.0,
                upper=1.0,
            )
        return params

    def apply_optimizer_runtime_params(self, updated_params: Mapping[str, float]) -> None:
        memory = self._memory
        if not isinstance(updated_params, Mapping):
            return

        if "st_decay_rate" in updated_params:
            memory._activation_engine._short_term_decay_rate = clamp(
                as_float(updated_params["st_decay_rate"]),
                lower=0.0,
                upper=1.0,
            )
        if "lt_decay_rate" in updated_params:
            memory._activation_engine._long_term_decay_rate = clamp(
                as_float(updated_params["lt_decay_rate"]),
                lower=0.0,
                upper=1.0,
            )
        if "st_activation_threshold" in updated_params:
            memory._activation_engine._short_term_activation_threshold = max(
                0.0,
                as_float(updated_params["st_activation_threshold"]),
            )
        if "lt_activation_threshold" in updated_params:
            memory._activation_engine._long_term_activation_threshold = max(
                0.0,
                as_float(updated_params["lt_activation_threshold"]),
            )
        if "st_learning_rate" in updated_params:
            memory._connection_learner._short_term_learning_rate = max(
                0.0,
                as_float(updated_params["st_learning_rate"]),
            )
        if "lt_learning_rate" in updated_params:
            memory._connection_learner._long_term_learning_rate = max(
                0.0,
                as_float(updated_params["lt_learning_rate"]),
            )
        if "st_formation_threshold" in updated_params:
            memory._connection_learner._short_term_formation_threshold = max(
                0.0,
                as_float(updated_params["st_formation_threshold"]),
            )
        if "lt_formation_threshold" in updated_params:
            memory._connection_learner._long_term_formation_threshold = max(
                0.0,
                as_float(updated_params["lt_formation_threshold"]),
            )
        if "learning_gate_threshold" in updated_params:
            memory._outcome_detector._learning_gate_threshold = clamp(
                as_float(updated_params["learning_gate_threshold"]),
                lower=0.0,
                upper=1.0,
            )
