"""Structured error types for the canonical Synaptic API."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class SynapticError(RuntimeError):
    """Structured API error with machine-readable code and operator hint."""

    code: str
    message: str
    hint: str | None = None

    def __post_init__(self) -> None:
        RuntimeError.__init__(self, self.message)

    def as_dict(self) -> dict[str, str | None]:
        return {
            "code": self.code,
            "message": self.message,
            "hint": self.hint,
        }


__all__ = ["SynapticError"]
