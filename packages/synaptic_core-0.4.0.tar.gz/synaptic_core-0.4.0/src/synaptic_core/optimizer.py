"""Instance optimization utilities for bounded local parameter tuning."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Mapping, Sequence
from uuid import uuid4


DEFAULT_PARAMETER_SAFE_RANGES: dict[str, tuple[float, float]] = {
    "st_decay_rate": (0.0, 1.0),
    "lt_decay_rate": (0.0, 1.0),
    "st_activation_threshold": (0.0, 1.0),
    "lt_activation_threshold": (0.0, 1.0),
    "fusion_semantic_weight": (0.0, 1.0),
    "fusion_keyword_weight": (0.0, 1.0),
    "st_learning_rate": (0.0, 1.0),
    "lt_learning_rate": (0.0, 1.0),
    "st_formation_threshold": (0.0, 1.0),
    "lt_formation_threshold": (0.0, 1.0),
    "learning_gate_threshold": (0.0, 1.0),
    "graduation_min_access_count": (1.0, 1000.0),
    "graduation_min_positive_ratio": (0.0, 1.0),
}

_EPSILON = 1e-9


@dataclass(frozen=True)
class OptimizerBenchmarkMetrics:
    """Normalized benchmark metrics for baseline or tuned optimizer snapshots."""

    run_id: str
    artifact_bundle_path: str
    objective_score: float
    direct_recall_at_k: float
    direct_total: int
    seed: int | None = None


@dataclass(frozen=True)
class OptimizerTuningIteration:
    """One tuning iteration evaluated against a benchmark run."""

    iteration: int
    metrics: OptimizerBenchmarkMetrics


@dataclass(frozen=True)
class OptimizerTuningPolicy:
    """Acceptance contract for optimizer convergence and quality gates."""

    min_iterations: int = 3
    max_iterations: int = 12
    min_objective_improvement: float = 0.01
    plateau_patience: int = 2
    plateau_min_delta: float = 0.001
    max_direct_recall_drop: float = 0.0
    require_benchmark_evidence: bool = True


def optimizer_benchmark_metrics_from_score_summary(
    score_summary: Mapping[str, object],
    *,
    artifact_bundle_path: str,
    run_id: str | None = None,
) -> OptimizerBenchmarkMetrics:
    """Build benchmark metrics from proof-of-magic `score_summary.json` fields."""

    direct_total = max(1, _as_int(score_summary.get("direct_total", 0)))
    associative_total = max(1, _as_int(score_summary.get("associative_total", 0)))
    direct_hits = max(0, min(direct_total, _as_int(score_summary.get("synaptic_direct_hits", 0))))
    associative_hits = max(
        0,
        min(associative_total, _as_int(score_summary.get("synaptic_associative_hits", 0))),
    )

    direct_recall = _safe_ratio(direct_hits, direct_total)
    associative_recall = _safe_ratio(associative_hits, associative_total)
    objective_score = (direct_recall + associative_recall) / 2.0

    resolved_run_id = str(run_id if run_id is not None else score_summary.get("run_id", ""))
    raw_seed = score_summary.get("seed")
    seed = _as_int(raw_seed) if raw_seed is not None else None
    return OptimizerBenchmarkMetrics(
        run_id=resolved_run_id,
        artifact_bundle_path=str(artifact_bundle_path or ""),
        objective_score=float(objective_score),
        direct_recall_at_k=float(direct_recall),
        direct_total=int(direct_total),
        seed=seed,
    )


def evaluate_optimizer_tuning(
    *,
    baseline: OptimizerBenchmarkMetrics,
    iterations: Sequence[OptimizerTuningIteration],
    policy: OptimizerTuningPolicy | None = None,
) -> dict[str, object]:
    """Evaluate tuned parameter candidates against convergence and quality gates."""

    resolved_policy = policy or OptimizerTuningPolicy()
    normalized_iterations = sorted(
        (
            OptimizerTuningIteration(iteration=int(item.iteration), metrics=item.metrics)
            for item in iterations
        ),
        key=lambda item: item.iteration,
    )
    if not normalized_iterations:
        return {
            "accepted": False,
            "converged": False,
            "stop_reason": "no_iterations",
            "iterations_evaluated": 0,
            "objective_pass": False,
            "direct_recall_pass": False,
            "benchmark_evidence_pass": False,
            "best_iteration": None,
            "objective_improvement": 0.0,
            "direct_recall_delta": 0.0,
        }

    best = normalized_iterations[0]
    rolling_best_objective = float(best.metrics.objective_score)
    last_significant_improvement_idx = 0
    improvement_delta = max(_EPSILON, float(resolved_policy.plateau_min_delta))

    for idx, candidate in enumerate(normalized_iterations[1:], start=1):
        candidate_objective = float(candidate.metrics.objective_score)
        if candidate_objective > (float(best.metrics.objective_score) + _EPSILON):
            best = candidate
        elif abs(candidate_objective - float(best.metrics.objective_score)) <= _EPSILON:
            if float(candidate.metrics.direct_recall_at_k) > (
                float(best.metrics.direct_recall_at_k) + _EPSILON
            ):
                best = candidate

        if candidate_objective > (rolling_best_objective + improvement_delta):
            # Track last meaningful objective jump for plateau-based convergence decisions.
            rolling_best_objective = candidate_objective
            last_significant_improvement_idx = idx

    iteration_count = len(normalized_iterations)
    reached_min_iterations = iteration_count >= max(1, int(resolved_policy.min_iterations))
    plateau_patience = max(1, int(resolved_policy.plateau_patience))
    plateau_converged = reached_min_iterations and (
        (iteration_count - 1 - last_significant_improvement_idx) >= plateau_patience
    )
    max_iter_converged = iteration_count >= max(1, int(resolved_policy.max_iterations))
    converged = bool(plateau_converged or max_iter_converged)

    stop_reason = "continue_tuning"
    if plateau_converged:
        stop_reason = "plateau"
    elif max_iter_converged:
        stop_reason = "max_iterations"
    elif not reached_min_iterations:
        stop_reason = "min_iterations_not_met"

    objective_improvement = float(best.metrics.objective_score) - float(baseline.objective_score)
    objective_pass = objective_improvement >= (
        float(resolved_policy.min_objective_improvement) - _EPSILON
    )

    direct_recall_delta = float(best.metrics.direct_recall_at_k) - float(
        baseline.direct_recall_at_k
    )
    direct_recall_drop = float(baseline.direct_recall_at_k) - float(
        best.metrics.direct_recall_at_k
    )
    direct_recall_pass = direct_recall_drop <= (
        float(resolved_policy.max_direct_recall_drop) + _EPSILON
    )

    benchmark_evidence_pass = True
    if bool(resolved_policy.require_benchmark_evidence):
        baseline_has_evidence = _has_benchmark_evidence(baseline)
        best_has_evidence = _has_benchmark_evidence(best.metrics)
        benchmark_evidence_pass = (
            baseline_has_evidence
            and best_has_evidence
            and str(baseline.run_id) != str(best.metrics.run_id)
        )

    accepted = converged and objective_pass and direct_recall_pass and benchmark_evidence_pass
    if converged and not accepted:
        if not direct_recall_pass:
            stop_reason = "direct_recall_regression"
        elif not benchmark_evidence_pass:
            stop_reason = "missing_benchmark_evidence"
        elif not objective_pass:
            stop_reason = "objective_improvement_insufficient"

    return {
        "accepted": bool(accepted),
        "converged": bool(converged),
        "stop_reason": stop_reason,
        "iterations_evaluated": int(iteration_count),
        "best_iteration": int(best.iteration),
        "baseline_run_id": str(baseline.run_id),
        "best_run_id": str(best.metrics.run_id),
        "objective_improvement": float(objective_improvement),
        "direct_recall_delta": float(direct_recall_delta),
        "objective_pass": bool(objective_pass),
        "direct_recall_pass": bool(direct_recall_pass),
        "benchmark_evidence_pass": bool(benchmark_evidence_pass),
        "requires_more_iterations": bool(not converged),
    }


class InstanceOptimizer:
    """Safely nudges deployment-local parameters from telemetry snapshots."""

    def __init__(
        self,
        *,
        current_params: Mapping[str, float],
        safe_ranges: Mapping[str, tuple[float, float]] | None = None,
        step_size: float = 0.005,
        min_sample_count: int = 10,
        diagnostic_query_threshold: int = 200,
        diagnostic_confidence_threshold: float = 0.2,
        telemetry_collector: Any | None = None,
        deployment_id: str = "local",
    ) -> None:
        self._current_params = {
            str(name): float(value) for name, value in dict(current_params).items()
        }
        self._safe_ranges = dict(DEFAULT_PARAMETER_SAFE_RANGES)
        if safe_ranges is not None:
            self._safe_ranges.update(_normalize_safe_ranges(safe_ranges))

        self._step_size = max(0.0, float(step_size))
        self._min_sample_count = max(1, int(min_sample_count))
        self._diagnostic_query_threshold = max(1, int(diagnostic_query_threshold))
        self._diagnostic_confidence_threshold = _clamp(
            float(diagnostic_confidence_threshold), lower=0.0, upper=1.0
        )
        self._telemetry_collector = telemetry_collector
        self._deployment_id = str(deployment_id or "local")
        self._last_diagnostic: dict[str, object] | None = None

    @property
    def current_params(self) -> dict[str, float]:
        return dict(self._current_params)

    @property
    def last_diagnostic(self) -> dict[str, object] | None:
        if self._last_diagnostic is None:
            return None
        return dict(self._last_diagnostic)

    def optimize(self, telemetry_snapshot: Mapping[str, Any] | None) -> dict[str, float]:
        previous = dict(self._current_params)
        try:
            snapshot = dict(telemetry_snapshot or {})
            sample_count = _as_int(snapshot.get("sample_count", 0))
            if sample_count < self._min_sample_count:
                return dict(self._current_params)

            param_directions = _as_mapping(snapshot.get("param_directions"))
            updated = dict(self._current_params)
            for name, current_value in self._current_params.items():
                if name not in param_directions:
                    continue
                direction = _direction(param_directions[name])
                if direction == 0:
                    continue
                lower, upper = self._safe_ranges.get(
                    name,
                    (-float("inf"), float("inf")),
                )
                next_value = current_value + (direction * self._step_size)
                updated[name] = _clamp(next_value, lower=lower, upper=upper)

            self._current_params = updated

            query_count = _as_int(snapshot.get("query_count", 0))
            graph_confidence = _as_float(snapshot.get("graph_confidence", 1.0))
            diagnostic = self._build_suppression_diagnostic(
                query_count=query_count,
                graph_confidence=graph_confidence,
                raw_diagnostic=snapshot.get("suppression_diagnostic"),
            )
            self._last_diagnostic = diagnostic
            if diagnostic is not None:
                self._record_suppression_diagnostic(diagnostic)

            return dict(self._current_params)
        except Exception:
            self._current_params = previous
            return dict(self._current_params)

    def _build_suppression_diagnostic(
        self,
        *,
        query_count: int,
        graph_confidence: float,
        raw_diagnostic: object,
    ) -> dict[str, object] | None:
        if query_count < self._diagnostic_query_threshold:
            return None

        confidence = _clamp(graph_confidence, lower=0.0, upper=1.0)
        if confidence >= self._diagnostic_confidence_threshold:
            return None

        suppressed_components: list[str] = []
        component_scores: dict[str, float] = {}
        if isinstance(raw_diagnostic, Mapping):
            raw_components = raw_diagnostic.get("suppressed_components")
            if isinstance(raw_components, (list, tuple, set)):
                suppressed_components = [str(value) for value in raw_components if str(value)]
            raw_scores = raw_diagnostic.get("component_scores")
            if isinstance(raw_scores, Mapping):
                component_scores = {
                    str(name): _clamp(_as_float(value), lower=0.0, upper=1.0)
                    for name, value in raw_scores.items()
                }

        if not suppressed_components:
            suppressed_components = ["graph_confidence"]

        return {
            "warning": "graph confidence remains suppressed after minimum query threshold",
            "query_count": int(query_count),
            "graph_confidence": float(confidence),
            "suppression_threshold": float(self._diagnostic_confidence_threshold),
            "suppressed_components": sorted(set(suppressed_components)),
            "component_scores": component_scores,
        }

    def _record_suppression_diagnostic(self, diagnostic: Mapping[str, object]) -> None:
        collector = self._telemetry_collector
        if collector is None:
            return

        raw_payload = dict(diagnostic)
        record_optimizer_diagnostic = _safe_get_callable(collector, "record_optimizer_diagnostic")
        if callable(record_optimizer_diagnostic):
            try:
                record_optimizer_diagnostic(raw_payload)
            except Exception:
                pass

        graph_health_payload = {
            "snapshot_id": str(uuid4()),
            "deployment_id": self._deployment_id,
            "snapshot_at": _as_iso8601(datetime.now(timezone.utc)),
            "graph_confidence": float(_as_float(diagnostic.get("graph_confidence", 0.0))),
        }

        record_graph_health = _safe_get_callable(collector, "record_graph_health")
        if callable(record_graph_health):
            try:
                record_graph_health(graph_health_payload)
                return
            except Exception:
                pass

        record_event = _safe_get_callable(collector, "record_event")
        if callable(record_event):
            try:
                record_event("telemetry_graph_health", graph_health_payload)
            except Exception:
                pass


def _normalize_safe_ranges(
    ranges: Mapping[str, tuple[float, float]],
) -> dict[str, tuple[float, float]]:
    normalized: dict[str, tuple[float, float]] = {}
    for name, bounds in ranges.items():
        if not isinstance(bounds, (list, tuple)) or len(bounds) != 2:
            continue
        lower = _as_float(bounds[0])
        upper = _as_float(bounds[1])
        if upper < lower:
            lower, upper = upper, lower
        normalized[str(name)] = (lower, upper)
    return normalized


def _as_mapping(value: object) -> Mapping[str, Any]:
    if isinstance(value, Mapping):
        return value
    raise TypeError("param_directions must be a mapping")


def _safe_get_callable(instance: object, method_name: str) -> Any | None:
    try:
        method = getattr(instance, method_name, None)
    except Exception:
        return None
    if callable(method):
        return method
    return None


def _direction(value: object) -> int:
    numeric = _as_float(value)
    if numeric > 0.0:
        return 1
    if numeric < 0.0:
        return -1
    return 0


def _clamp(value: float, *, lower: float, upper: float) -> float:
    return max(lower, min(upper, float(value)))


def _as_float(value: object) -> float:
    return float(value)


def _as_int(value: object) -> int:
    return int(value)


def _as_iso8601(value: datetime) -> str:
    return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")


def _safe_ratio(numerator: int, denominator: int) -> float:
    if denominator <= 0:
        return 0.0
    return float(numerator) / float(denominator)


def _has_benchmark_evidence(metrics: OptimizerBenchmarkMetrics) -> bool:
    return bool(str(metrics.run_id).strip()) and bool(str(metrics.artifact_bundle_path).strip())
