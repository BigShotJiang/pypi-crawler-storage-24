"""Local telemetry collection for Phase 1 (collection only, no export)."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
import json
import queue
import sqlite3
import threading
import time
from pathlib import Path
from typing import Any, Mapping
from uuid import uuid4


TELEMETRY_LOCAL_ONLY = True
TELEMETRY_EXPORT_DEFERRED_UNTIL = "v0.2.0"
_SQLITE_BUSY_TIMEOUT_MS = 15_000
_SQLITE_CONNECT_TIMEOUT_SECONDS = _SQLITE_BUSY_TIMEOUT_MS / 1000.0


@dataclass(frozen=True)
class _TelemetryTableSchema:
    columns: tuple[str, ...]
    required_columns: tuple[str, ...]


@dataclass(frozen=True)
class _RollupSpec:
    from_sql: str
    timestamp_expression: str
    deployment_expression: str


class TelemetryCollector:
    """Asynchronous local telemetry writer backed by SQLite tables."""

    _SENTINEL = object()
    _ALLOWED_TABLES = {
        "telemetry_queries",
        "telemetry_retrievals",
        "telemetry_activations",
        "telemetry_node_metadata",
        "telemetry_connections",
        "telemetry_outcomes",
        "telemetry_sessions",
        "telemetry_graduations",
        "telemetry_graph_health",
    }
    _RETRYABLE_ERROR_CATEGORIES = {
        "database_locked",
        "operational_error",
        "database_error",
    }
    _DEFAULT_RETENTION_DAYS = {
        "telemetry_activations": 21,
        "telemetry_retrievals": 45,
        "telemetry_node_metadata": 45,
        "telemetry_sessions": 60,
        "telemetry_queries": 120,
        "telemetry_connections": 270,
        "telemetry_outcomes": 365,
        "telemetry_graph_health": 270,
        "telemetry_graduations": 365,
    }
    _RETENTION_PRUNE_ORDER = (
        "telemetry_retrievals",
        "telemetry_activations",
        "telemetry_outcomes",
        "telemetry_queries",
        "telemetry_node_metadata",
        "telemetry_sessions",
        "telemetry_connections",
        "telemetry_graph_health",
        "telemetry_graduations",
    )
    _ROLLED_UP_TABLES = {
        "telemetry_queries",
        "telemetry_retrievals",
        "telemetry_activations",
        "telemetry_node_metadata",
        "telemetry_sessions",
    }
    _ROLLUP_SPECS = {
        "telemetry_queries": _RollupSpec(
            from_sql="telemetry_queries t",
            timestamp_expression="t.timestamp",
            deployment_expression="t.deployment_id",
        ),
        "telemetry_retrievals": _RollupSpec(
            from_sql="telemetry_retrievals t JOIN telemetry_queries q ON q.query_id = t.query_id",
            timestamp_expression="q.timestamp",
            deployment_expression="q.deployment_id",
        ),
        "telemetry_activations": _RollupSpec(
            from_sql="telemetry_activations t JOIN telemetry_queries q ON q.query_id = t.query_id",
            timestamp_expression="q.timestamp",
            deployment_expression="q.deployment_id",
        ),
        "telemetry_node_metadata": _RollupSpec(
            from_sql="telemetry_node_metadata t",
            timestamp_expression="COALESCE(t.last_activated_at, t.created_at)",
            deployment_expression="t.deployment_id",
        ),
        "telemetry_sessions": _RollupSpec(
            from_sql="telemetry_sessions t",
            timestamp_expression="t.started_at",
            deployment_expression="t.deployment_id",
        ),
    }
    _PRUNE_SQL_BY_TABLE = {
        "telemetry_queries": """
            DELETE FROM telemetry_queries
            WHERE timestamp IS NOT NULL
              AND timestamp < ?
        """,
        "telemetry_retrievals": """
            DELETE FROM telemetry_retrievals
            WHERE query_id IN (
                SELECT t.query_id
                FROM telemetry_retrievals t
                JOIN telemetry_queries q ON q.query_id = t.query_id
                WHERE q.timestamp IS NOT NULL
                  AND q.timestamp < ?
            )
        """,
        "telemetry_activations": """
            DELETE FROM telemetry_activations
            WHERE query_id IN (
                SELECT t.query_id
                FROM telemetry_activations t
                JOIN telemetry_queries q ON q.query_id = t.query_id
                WHERE q.timestamp IS NOT NULL
                  AND q.timestamp < ?
            )
        """,
        "telemetry_outcomes": """
            DELETE FROM telemetry_outcomes
            WHERE query_id IN (
                SELECT t.query_id
                FROM telemetry_outcomes t
                JOIN telemetry_queries q ON q.query_id = t.query_id
                WHERE q.timestamp IS NOT NULL
                  AND q.timestamp < ?
            )
        """,
        "telemetry_node_metadata": """
            DELETE FROM telemetry_node_metadata
            WHERE COALESCE(last_activated_at, created_at) IS NOT NULL
              AND COALESCE(last_activated_at, created_at) < ?
        """,
        "telemetry_sessions": """
            DELETE FROM telemetry_sessions
            WHERE started_at IS NOT NULL
              AND started_at < ?
        """,
        "telemetry_connections": """
            DELETE FROM telemetry_connections
            WHERE COALESCE(last_reinforced_at, formed_at) IS NOT NULL
              AND COALESCE(last_reinforced_at, formed_at) < ?
        """,
        "telemetry_graph_health": """
            DELETE FROM telemetry_graph_health
            WHERE snapshot_at IS NOT NULL
              AND snapshot_at < ?
        """,
        "telemetry_graduations": """
            DELETE FROM telemetry_graduations
            WHERE graduated_at IS NOT NULL
              AND graduated_at < ?
        """,
    }
    _FEDERATION_OUTBOX_TABLE = "telemetry_federation_outbox"
    _FEDERATION_STATE_TABLE = "telemetry_export_state"
    _FEDERATION_EVENT_TABLES = {
        "telemetry_queries",
        "telemetry_connections",
        "telemetry_outcomes",
        "telemetry_graph_health",
        "telemetry_graduations",
    }

    def __init__(
        self,
        *,
        db_path: str | Path,
        queue_maxsize: int = 1024,
        max_retries: int = 2,
        dead_letter_maxsize: int = 10_000,
        auto_start: bool = True,
        commit_batch_size: int = 64,
        commit_batch_interval_ms: int = 200,
        retention_days_by_table: Mapping[str, int] | None = None,
        retention_maintenance_interval_rows: int = 512,
        retention_maintenance_interval_seconds: float = 60.0,
        federation_outbox_schema_version: int = 1,
    ) -> None:
        self._db_path = str(db_path)
        Path(self._db_path).parent.mkdir(parents=True, exist_ok=True)
        self._queue: queue.Queue[object] = queue.Queue(maxsize=max(1, queue_maxsize))
        self._stop_event = threading.Event()
        self._stats_lock = threading.Lock()
        self._stats = {
            "queued_writes": 0,
            "written_writes": 0,
            "failed_writes": 0,
            "dropped_writes": 0,
            "retried_writes": 0,
            "dead_lettered_writes": 0,
            "replayed_writes": 0,
            "commit_count": 0,
            "pending_commit_rows": 0,
            "retention_runs": 0,
            "retention_rows_pruned": 0,
            "failed_writes_by_table": {},
            "failed_writes_by_error_type": {},
            "failed_writes_by_error_category": {},
        }
        self._max_retries = max(0, int(max_retries))
        self._dead_letter_maxsize = max(1, int(dead_letter_maxsize))
        self._dead_letters: list[dict[str, Any]] = []
        self._schema_cache: dict[str, _TelemetryTableSchema] = {}
        self._table_exists_cache: dict[str, bool] = {}
        self._worker: threading.Thread | None = None
        self._commit_batch_size = max(1, int(commit_batch_size))
        self._commit_batch_interval_seconds = max(0.001, float(commit_batch_interval_ms) / 1000.0)
        self._retention_days_by_table = dict(self._DEFAULT_RETENTION_DAYS)
        if retention_days_by_table is not None:
            for table_name, days in dict(retention_days_by_table).items():
                if table_name in self._ALLOWED_TABLES:
                    self._retention_days_by_table[table_name] = max(1, int(days))
        self._retention_maintenance_interval_rows = max(1, int(retention_maintenance_interval_rows))
        self._retention_maintenance_interval_seconds = max(
            1.0,
            float(retention_maintenance_interval_seconds),
        )
        self._federation_outbox_schema_version = max(1, int(federation_outbox_schema_version))
        if auto_start:
            self.start()

    @property
    def stats(self) -> dict[str, Any]:
        with self._stats_lock:
            return {
                "queued_writes": int(self._stats["queued_writes"]),
                "written_writes": int(self._stats["written_writes"]),
                "failed_writes": int(self._stats["failed_writes"]),
                "dropped_writes": int(self._stats["dropped_writes"]),
                "retried_writes": int(self._stats["retried_writes"]),
                "dead_lettered_writes": int(self._stats["dead_lettered_writes"]),
                "replayed_writes": int(self._stats["replayed_writes"]),
                "commit_count": int(self._stats["commit_count"]),
                "pending_commit_rows": int(self._stats["pending_commit_rows"]),
                "retention_runs": int(self._stats["retention_runs"]),
                "retention_rows_pruned": int(self._stats["retention_rows_pruned"]),
                "dead_letter_queue_size": len(self._dead_letters),
                "failed_writes_by_table": dict(self._stats["failed_writes_by_table"]),
                "failed_writes_by_error_type": dict(self._stats["failed_writes_by_error_type"]),
                "failed_writes_by_error_category": dict(
                    self._stats["failed_writes_by_error_category"]
                ),
            }

    def start(self) -> None:
        if self._worker is not None and self._worker.is_alive():
            return
        self._stop_event.clear()
        self._worker = threading.Thread(
            target=self._writer_loop,
            name="synaptic-telemetry-writer",
            daemon=True,
        )
        self._worker.start()

    def stop(self, *, drain: bool = True, timeout: float = 2.0) -> None:
        if drain:
            self.flush(timeout=timeout)
        self._stop_event.set()

        if self._worker is not None and self._worker.is_alive():
            while True:
                try:
                    self._queue.put(self._SENTINEL, timeout=0.05)
                    break
                except queue.Full:
                    if not drain:
                        self._drop_one()
            self._worker.join(timeout=timeout)

        self._worker = None

    def flush(self, *, timeout: float = 2.0) -> bool:
        deadline = time.perf_counter() + max(0.0, timeout)
        while time.perf_counter() <= deadline:
            if self._queue.unfinished_tasks == 0 and self.stats["pending_commit_rows"] == 0:
                return True
            time.sleep(0.01)
        return self._queue.unfinished_tasks == 0 and self.stats["pending_commit_rows"] == 0

    def record_query(self, payload: Mapping[str, Any]) -> bool:
        return self.record_event("telemetry_queries", payload)

    def record_retrieval(self, payload: Mapping[str, Any]) -> bool:
        return self.record_event("telemetry_retrievals", payload)

    def record_activation(self, payload: Mapping[str, Any]) -> bool:
        return self.record_event("telemetry_activations", payload)

    def record_node_metadata(self, payload: Mapping[str, Any]) -> bool:
        return self.record_event("telemetry_node_metadata", payload)

    def record_connection(self, payload: Mapping[str, Any]) -> bool:
        return self.record_event("telemetry_connections", payload)

    def record_outcome(self, payload: Mapping[str, Any]) -> bool:
        return self.record_event("telemetry_outcomes", payload)

    def record_session(self, payload: Mapping[str, Any]) -> bool:
        return self.record_event("telemetry_sessions", payload)

    def record_graduation(self, payload: Mapping[str, Any]) -> bool:
        return self.record_event("telemetry_graduations", payload)

    def record_graph_health(self, payload: Mapping[str, Any]) -> bool:
        return self.record_event("telemetry_graph_health", payload)

    def record_event(self, table_name: str, payload: Mapping[str, Any]) -> bool:
        if table_name not in self._ALLOWED_TABLES:
            raise ValueError(f"unsupported telemetry table: {table_name}")

        return self._enqueue_item(
            table_name=table_name,
            payload=dict(payload),
            attempt=0,
            count_as_queued=True,
        )

    def replay_dead_letters(self, *, limit: int | None = None) -> int:
        with self._stats_lock:
            if not self._dead_letters:
                return 0
            replay_limit = len(self._dead_letters) if limit is None else max(0, int(limit))
            if replay_limit <= 0:
                return 0
            pending = list(self._dead_letters[:replay_limit])
            self._dead_letters = self._dead_letters[replay_limit:]

        replayed = 0
        for idx, item in enumerate(pending):
            ok = self._enqueue_item(
                table_name=str(item["table_name"]),
                payload=dict(item["payload"]),
                attempt=0,
                count_as_queued=True,
            )
            if not ok:
                with self._stats_lock:
                    self._dead_letters = pending[idx:] + self._dead_letters
                break
            replayed += 1
        with self._stats_lock:
            self._stats["replayed_writes"] += replayed
        return replayed

    def run_retention_maintenance(self, *, now: datetime | None = None) -> dict[str, int]:
        now_utc = _coerce_utc(now or datetime.now(timezone.utc))
        conn = sqlite3.connect(
            self._db_path,
            timeout=_SQLITE_CONNECT_TIMEOUT_SECONDS,
        )
        try:
            _configure_connection(conn)
            summary = self._run_retention_maintenance(conn=conn, now_utc=now_utc)
            conn.commit()
            return summary
        finally:
            conn.close()

    def read_federation_outbox_batch(
        self,
        *,
        export_target: str,
        limit: int = 250,
    ) -> list[dict[str, Any]]:
        resolved_target = str(export_target or "").strip()
        if not resolved_target:
            raise ValueError("export_target is required")
        resolved_limit = max(1, int(limit))

        conn = sqlite3.connect(
            self._db_path,
            timeout=_SQLITE_CONNECT_TIMEOUT_SECONDS,
        )
        try:
            _configure_connection(conn)
            conn.row_factory = sqlite3.Row
            if not self._table_exists(conn, self._FEDERATION_OUTBOX_TABLE):
                return []
            if not self._table_exists(conn, self._FEDERATION_STATE_TABLE):
                return []
            last_state = conn.execute(
                f"""
                SELECT last_event_id
                FROM {self._FEDERATION_STATE_TABLE}
                WHERE export_target = ?
                """,
                (resolved_target,),
            ).fetchone()
            last_event_id = int(last_state["last_event_id"]) if last_state is not None else 0
            rows = conn.execute(
                f"""
                SELECT
                    event_id,
                    event_type,
                    deployment_id,
                    occurred_at,
                    payload_json,
                    schema_version,
                    exported_at
                FROM {self._FEDERATION_OUTBOX_TABLE}
                WHERE event_id > ?
                ORDER BY event_id ASC
                LIMIT ?
                """,
                (last_event_id, resolved_limit),
            ).fetchall()
        finally:
            conn.close()

        events: list[dict[str, Any]] = []
        for row in rows:
            payload: Any
            try:
                payload = json.loads(str(row["payload_json"]))
            except Exception:
                payload = {}
            events.append(
                {
                    "event_id": int(row["event_id"]),
                    "event_type": str(row["event_type"]),
                    "deployment_id": str(row["deployment_id"]),
                    "occurred_at": str(row["occurred_at"]),
                    "payload": payload if isinstance(payload, Mapping) else {},
                    "schema_version": int(row["schema_version"]),
                    "exported_at": row["exported_at"],
                }
            )
        return events

    def ack_federation_outbox(
        self,
        *,
        export_target: str,
        last_event_id: int,
    ) -> None:
        resolved_target = str(export_target or "").strip()
        if not resolved_target:
            raise ValueError("export_target is required")
        resolved_last_event_id = max(0, int(last_event_id))
        timestamp = _utc_now_iso()

        conn = sqlite3.connect(
            self._db_path,
            timeout=_SQLITE_CONNECT_TIMEOUT_SECONDS,
        )
        try:
            _configure_connection(conn)
            if not self._table_exists(conn, self._FEDERATION_OUTBOX_TABLE):
                return
            if not self._table_exists(conn, self._FEDERATION_STATE_TABLE):
                return
            conn.execute(
                f"""
                INSERT INTO {self._FEDERATION_STATE_TABLE} (
                    export_target,
                    last_event_id,
                    updated_at
                ) VALUES (?, ?, ?)
                ON CONFLICT(export_target) DO UPDATE SET
                    last_event_id = CASE
                        WHEN excluded.last_event_id > {self._FEDERATION_STATE_TABLE}.last_event_id
                        THEN excluded.last_event_id
                        ELSE {self._FEDERATION_STATE_TABLE}.last_event_id
                    END,
                    updated_at = excluded.updated_at
                """,
                (resolved_target, resolved_last_event_id, timestamp),
            )
            conn.execute(
                f"""
                UPDATE {self._FEDERATION_OUTBOX_TABLE}
                SET exported_at = COALESCE(exported_at, ?)
                WHERE event_id <= ?
                """,
                (timestamp, resolved_last_event_id),
            )
            conn.commit()
        finally:
            conn.close()

    def _writer_loop(self) -> None:
        conn: sqlite3.Connection | None = None
        try:
            pending_commits: list[tuple[str, dict[str, Any], int]] = []
            last_commit_at = time.perf_counter()
            rows_since_maintenance = 0
            last_maintenance_at = time.perf_counter()
            setup_attempt = 0

            while not self._stop_event.is_set() or not self._queue.empty():
                if conn is None:
                    try:
                        conn = sqlite3.connect(
                            self._db_path,
                            timeout=_SQLITE_CONNECT_TIMEOUT_SECONDS,
                        )
                        _configure_connection(conn)
                        setup_attempt = 0
                    except Exception as exc:
                        if conn is not None:
                            conn.close()
                            conn = None
                        if _error_category(exc) not in self._RETRYABLE_ERROR_CATEGORIES:
                            raise
                        setup_attempt += 1
                        time.sleep(min(0.25, 0.05 * setup_attempt))
                        continue

                commit_due = (
                    pending_commits
                    and (time.perf_counter() - last_commit_at) >= self._commit_batch_interval_seconds
                )
                if commit_due:
                    committed = self._commit_pending(conn=conn, pending_commits=pending_commits)
                    rows_since_maintenance += committed
                    last_commit_at = time.perf_counter()
                    if self._should_run_retention_maintenance(
                        rows_since_maintenance=rows_since_maintenance,
                        last_maintenance_at=last_maintenance_at,
                    ):
                        self._run_retention_and_commit(conn=conn)
                        rows_since_maintenance = 0
                        last_maintenance_at = time.perf_counter()

                try:
                    item = self._queue.get(timeout=0.05)
                except queue.Empty:
                    continue

                if item is self._SENTINEL:
                    self._queue.task_done()
                    break

                table_name, payload, attempt = item  # type: ignore[misc]
                try:
                    wrote_row = bool(self._write_row(conn, table_name, payload))
                    if wrote_row:
                        pending_commits.append((table_name, dict(payload), int(attempt)))
                        with self._stats_lock:
                            self._stats["pending_commit_rows"] = len(pending_commits)
                except Exception as exc:
                    self._handle_write_failure(
                        table_name=table_name,
                        payload=payload,
                        attempt=int(attempt),
                        exc=exc,
                    )
                finally:
                    self._queue.task_done()

                if (
                    pending_commits
                    and len(pending_commits) >= self._commit_batch_size
                ):
                    committed = self._commit_pending(conn=conn, pending_commits=pending_commits)
                    rows_since_maintenance += committed
                    last_commit_at = time.perf_counter()

                if self._should_run_retention_maintenance(
                    rows_since_maintenance=rows_since_maintenance,
                    last_maintenance_at=last_maintenance_at,
                ):
                    self._run_retention_and_commit(conn=conn)
                    rows_since_maintenance = 0
                    last_maintenance_at = time.perf_counter()

            committed = self._commit_pending(conn=conn, pending_commits=pending_commits)
            rows_since_maintenance += committed
            if self._should_run_retention_maintenance(
                rows_since_maintenance=rows_since_maintenance,
                last_maintenance_at=last_maintenance_at,
            ):
                self._run_retention_and_commit(conn=conn)
        finally:
            if conn is not None:
                conn.close()

    def _commit_pending(
        self,
        *,
        conn: sqlite3.Connection,
        pending_commits: list[tuple[str, dict[str, Any], int]],
    ) -> int:
        if not pending_commits:
            return 0
        try:
            conn.commit()
            with self._stats_lock:
                self._stats["written_writes"] += len(pending_commits)
                self._stats["commit_count"] += 1
                self._stats["pending_commit_rows"] = 0
            committed = len(pending_commits)
            pending_commits.clear()
            return committed
        except Exception as exc:
            conn.rollback()
            for table_name, payload, attempt in pending_commits:
                self._handle_write_failure(
                    table_name=table_name,
                    payload=payload,
                    attempt=attempt,
                    exc=exc,
                )
            pending_commits.clear()
            with self._stats_lock:
                self._stats["pending_commit_rows"] = 0
            return 0

    def _handle_write_failure(
        self,
        *,
        table_name: str,
        payload: Mapping[str, Any],
        attempt: int,
        exc: Exception,
    ) -> None:
        self._record_failed_write(table_name=table_name, exc=exc)
        should_retry = (
            int(attempt) < self._max_retries
            and _error_category(exc) in self._RETRYABLE_ERROR_CATEGORIES
        )
        if should_retry:
            requeued = self._enqueue_item(
                table_name=table_name,
                payload=payload,
                attempt=int(attempt) + 1,
                count_as_queued=False,
            )
            if requeued:
                with self._stats_lock:
                    self._stats["retried_writes"] += 1
                return
        self._record_dead_letter(
            table_name=table_name,
            payload=payload,
            exc=exc,
            attempt=int(attempt),
        )

    def _should_run_retention_maintenance(
        self,
        *,
        rows_since_maintenance: int,
        last_maintenance_at: float,
    ) -> bool:
        if rows_since_maintenance >= self._retention_maintenance_interval_rows:
            return True
        return (time.perf_counter() - last_maintenance_at) >= self._retention_maintenance_interval_seconds

    def _run_retention_and_commit(self, *, conn: sqlite3.Connection) -> None:
        summary = self._run_retention_maintenance(conn=conn, now_utc=datetime.now(timezone.utc))
        if (
            summary["rows_pruned"] <= 0
            and summary["daily_rollup_rows"] <= 0
            and summary["weekly_rollup_rows"] <= 0
        ):
            return
        conn.commit()
        with self._stats_lock:
            self._stats["retention_runs"] += 1
            self._stats["retention_rows_pruned"] += int(summary["rows_pruned"])

    def _run_retention_maintenance(
        self,
        *,
        conn: sqlite3.Connection,
        now_utc: datetime,
    ) -> dict[str, int]:
        summary = {
            "tables_pruned": 0,
            "rows_pruned": 0,
            "daily_rollup_rows": 0,
            "weekly_rollup_rows": 0,
        }
        cutoff_cache: dict[int, str] = {}
        rollup_tables_available = (
            self._table_exists(conn, "telemetry_daily_rollups")
            and self._table_exists(conn, "telemetry_weekly_rollups")
        )

        for table_name in self._RETENTION_PRUNE_ORDER:
            days = self._retention_days_by_table.get(table_name)
            if days is None:
                continue
            cutoff_iso = cutoff_cache.get(int(days))
            if cutoff_iso is None:
                cutoff_iso = _coerce_utc_day_floor(
                    now_utc - timedelta(days=max(1, int(days)))
                ).isoformat().replace("+00:00", "Z")
                cutoff_cache[int(days)] = cutoff_iso

            if table_name in self._ROLLED_UP_TABLES:
                if not rollup_tables_available:
                    # If rollup tables are unavailable, preserve raw rows instead of pruning.
                    continue
                daily_count, weekly_count = self._rollup_table(
                    conn=conn,
                    table_name=table_name,
                    cutoff_iso=cutoff_iso,
                    recorded_at=_utc_now_iso(),
                )
                summary["daily_rollup_rows"] += int(daily_count)
                summary["weekly_rollup_rows"] += int(weekly_count)

            pruned_rows = self._prune_table(
                conn=conn,
                table_name=table_name,
                cutoff_iso=cutoff_iso,
            )
            if pruned_rows > 0:
                summary["tables_pruned"] += 1
                summary["rows_pruned"] += int(pruned_rows)
        return summary

    def _rollup_table(
        self,
        *,
        conn: sqlite3.Connection,
        table_name: str,
        cutoff_iso: str,
        recorded_at: str,
    ) -> tuple[int, int]:
        spec = self._ROLLUP_SPECS.get(table_name)
        if spec is None:
            return (0, 0)
        daily_sql = self._daily_rollup_sql(table_name=table_name, spec=spec)
        weekly_sql = self._weekly_rollup_sql(table_name=table_name, spec=spec)
        conn.execute(
            daily_sql,
            (table_name, recorded_at, recorded_at, cutoff_iso),
        )
        daily_rows = _last_changes(conn)
        conn.execute(
            weekly_sql,
            (table_name, recorded_at, recorded_at, cutoff_iso),
        )
        weekly_rows = _last_changes(conn)
        return (daily_rows, weekly_rows)

    def _daily_rollup_sql(self, *, table_name: str, spec: _RollupSpec) -> str:
        timestamp = spec.timestamp_expression
        deployment = spec.deployment_expression
        _ = table_name
        return f"""
            INSERT INTO telemetry_daily_rollups (
                bucket_date,
                source_table,
                deployment_id,
                event_count,
                metric_sums_json,
                metric_counts_json,
                first_event_at,
                last_event_at,
                created_at,
                updated_at
            )
            SELECT
                date({timestamp}) AS bucket_date,
                ? AS source_table,
                COALESCE(NULLIF({deployment}, ''), 'local') AS deployment_id,
                COUNT(*) AS event_count,
                '{{}}' AS metric_sums_json,
                '{{}}' AS metric_counts_json,
                MIN({timestamp}) AS first_event_at,
                MAX({timestamp}) AS last_event_at,
                ? AS created_at,
                ? AS updated_at
            FROM {spec.from_sql}
            WHERE {timestamp} IS NOT NULL
              AND {timestamp} < ?
            GROUP BY date({timestamp}), COALESCE(NULLIF({deployment}, ''), 'local')
            ON CONFLICT(bucket_date, source_table, deployment_id) DO UPDATE SET
                event_count = telemetry_daily_rollups.event_count + excluded.event_count,
                first_event_at = COALESCE(
                    MIN(telemetry_daily_rollups.first_event_at, excluded.first_event_at),
                    excluded.first_event_at
                ),
                last_event_at = COALESCE(
                    MAX(telemetry_daily_rollups.last_event_at, excluded.last_event_at),
                    excluded.last_event_at
                ),
                updated_at = excluded.updated_at
        """

    def _weekly_rollup_sql(self, *, table_name: str, spec: _RollupSpec) -> str:
        timestamp = spec.timestamp_expression
        deployment = spec.deployment_expression
        _ = table_name
        return f"""
            INSERT INTO telemetry_weekly_rollups (
                week_start_date,
                source_table,
                deployment_id,
                event_count,
                metric_sums_json,
                metric_counts_json,
                first_event_at,
                last_event_at,
                created_at,
                updated_at
            )
            SELECT
                date({timestamp}, '-6 days', 'weekday 1') AS week_start_date,
                ? AS source_table,
                COALESCE(NULLIF({deployment}, ''), 'local') AS deployment_id,
                COUNT(*) AS event_count,
                '{{}}' AS metric_sums_json,
                '{{}}' AS metric_counts_json,
                MIN({timestamp}) AS first_event_at,
                MAX({timestamp}) AS last_event_at,
                ? AS created_at,
                ? AS updated_at
            FROM {spec.from_sql}
            WHERE {timestamp} IS NOT NULL
              AND {timestamp} < ?
            GROUP BY date({timestamp}, '-6 days', 'weekday 1'), COALESCE(NULLIF({deployment}, ''), 'local')
            ON CONFLICT(week_start_date, source_table, deployment_id) DO UPDATE SET
                event_count = telemetry_weekly_rollups.event_count + excluded.event_count,
                first_event_at = COALESCE(
                    MIN(telemetry_weekly_rollups.first_event_at, excluded.first_event_at),
                    excluded.first_event_at
                ),
                last_event_at = COALESCE(
                    MAX(telemetry_weekly_rollups.last_event_at, excluded.last_event_at),
                    excluded.last_event_at
                ),
                updated_at = excluded.updated_at
        """

    def _prune_table(
        self,
        *,
        conn: sqlite3.Connection,
        table_name: str,
        cutoff_iso: str,
    ) -> int:
        prune_sql = self._PRUNE_SQL_BY_TABLE.get(table_name)
        if not prune_sql:
            return 0
        conn.execute(prune_sql, (cutoff_iso,))
        return _last_changes(conn)

    def _write_row(
        self,
        conn: sqlite3.Connection,
        table_name: str,
        payload: Mapping[str, Any],
    ) -> bool:
        conn.execute("SAVEPOINT telemetry_write;")
        try:
            normalized_payload = self._normalize_payload(
                conn=conn,
                table_name=table_name,
                payload=payload,
            )
            if not normalized_payload:
                conn.execute("RELEASE telemetry_write;")
                return False

            columns = list(normalized_payload.keys())
            placeholders = ", ".join("?" for _ in columns)
            column_sql = ", ".join(columns)
            sql = (
                f"INSERT OR REPLACE INTO {table_name} ({column_sql}) "
                f"VALUES ({placeholders})"
            )
            values = [self._adapt_value(normalized_payload[column]) for column in columns]
            conn.execute(sql, values)
            self._write_federation_outbox_event(
                conn=conn,
                table_name=table_name,
                payload=normalized_payload,
            )
            conn.execute("RELEASE telemetry_write;")
            return True
        except Exception:
            conn.execute("ROLLBACK TO telemetry_write;")
            conn.execute("RELEASE telemetry_write;")
            raise

    def _write_federation_outbox_event(
        self,
        *,
        conn: sqlite3.Connection,
        table_name: str,
        payload: Mapping[str, Any],
    ) -> None:
        if table_name not in self._FEDERATION_EVENT_TABLES:
            return
        if not self._table_exists(conn, self._FEDERATION_OUTBOX_TABLE):
            return
        deployment_id = str(payload.get("deployment_id") or "local")
        occurred_at = self._resolve_event_timestamp(table_name=table_name, payload=payload)
        conn.execute(
            f"""
            INSERT INTO {self._FEDERATION_OUTBOX_TABLE} (
                event_type,
                deployment_id,
                occurred_at,
                payload_json,
                schema_version
            ) VALUES (?, ?, ?, ?, ?)
            """,
            (
                table_name,
                deployment_id,
                occurred_at,
                json.dumps(dict(payload), separators=(",", ":")),
                self._federation_outbox_schema_version,
            ),
        )

    def _resolve_event_timestamp(self, *, table_name: str, payload: Mapping[str, Any]) -> str:
        if table_name == "telemetry_queries":
            return str(payload.get("timestamp") or _utc_now_iso())
        if table_name == "telemetry_connections":
            return str(payload.get("last_reinforced_at") or payload.get("formed_at") or _utc_now_iso())
        if table_name == "telemetry_graph_health":
            return str(payload.get("snapshot_at") or _utc_now_iso())
        if table_name == "telemetry_graduations":
            return str(payload.get("graduated_at") or _utc_now_iso())
        return _utc_now_iso()

    def _normalize_payload(
        self,
        *,
        conn: sqlite3.Connection,
        table_name: str,
        payload: Mapping[str, Any],
    ) -> dict[str, Any]:
        schema = self._load_table_schema(conn=conn, table_name=table_name)
        normalized: dict[str, Any] = {
            column: payload[column]
            for column in schema.columns
            if column in payload
        }
        for column in schema.required_columns:
            if column in normalized:
                continue
            fallback = self._default_required_value(
                table_name=table_name,
                column=column,
                payload=payload,
                normalized=normalized,
            )
            if fallback is None:
                raise sqlite3.IntegrityError(
                    f"missing required telemetry field: {table_name}.{column}"
                )
            normalized[column] = fallback
        return normalized

    def _default_required_value(
        self,
        *,
        table_name: str,
        column: str,
        payload: Mapping[str, Any],
        normalized: Mapping[str, Any],
    ) -> Any:
        _ = table_name
        if column in {"id", "query_id", "snapshot_id", "graduation_id", "connection_id", "node_id"}:
            return str(payload.get(column) or uuid4())
        if column == "session_id":
            return str(payload.get("session_id") or payload.get("query_id") or "unknown")
        if column == "deployment_id":
            return str(payload.get("deployment_id") or "local")
        if column in {
            "timestamp",
            "formed_at",
            "last_reinforced_at",
            "started_at",
            "snapshot_at",
            "created_at",
            "graduated_at",
        }:
            return str(payload.get(column) or _utc_now_iso())
        if column == "provider":
            return str(payload.get("provider") or "unknown")
        if column == "query_embedding_hash":
            return str(payload.get("query_embedding_hash") or "unknown")
        if column == "query_type":
            return str(payload.get("query_type") or "unknown")
        if column == "node_a":
            return str(payload.get("node_a") or payload.get("source_node_id") or "unknown")
        if column == "node_b":
            return str(payload.get("node_b") or payload.get("target_node_id") or "unknown")
        if column == "formation_trigger":
            return str(payload.get("formation_trigger") or payload.get("change_type") or "unknown")
        if column == "connection_type":
            if payload.get("connection_type") is not None:
                return str(payload.get("connection_type"))
            return "cross_tier" if bool(payload.get("is_cross_tier")) else "excitatory"
        if column == "initial_weight":
            return _coerce_float(
                payload.get(
                    "initial_weight",
                    payload.get("previous_weight", payload.get("current_weight", 0.0)),
                ),
                default=0.0,
            )
        if column == "current_weight":
            return _coerce_float(
                payload.get(
                    "current_weight",
                    payload.get("initial_weight", payload.get("previous_weight", 0.0)),
                ),
                default=0.0,
            )
        if column in {"memory_type", "memory_tier"}:
            return str(payload.get(column) or "unknown")
        if column == "content":
            return str(payload.get("content") or "")
        if column in {"session_id", "deployment_id", "provider"}:
            return str(payload.get(column) or "unknown")
        if column in normalized:
            return normalized[column]
        return None

    def _load_table_schema(
        self,
        *,
        conn: sqlite3.Connection,
        table_name: str,
    ) -> _TelemetryTableSchema:
        cached = self._schema_cache.get(table_name)
        if cached is not None:
            return cached
        rows = conn.execute(f"PRAGMA table_info({table_name});").fetchall()
        if not rows:
            raise sqlite3.OperationalError(f"no such table: {table_name}")
        columns: list[str] = []
        required_columns: list[str] = []
        for row in rows:
            column_name = str(row[1])
            not_null = bool(row[3])
            default_value = row[4]
            is_primary_key = bool(row[5])
            columns.append(column_name)
            if is_primary_key or (not_null and default_value is None):
                required_columns.append(column_name)
        schema = _TelemetryTableSchema(
            columns=tuple(columns),
            required_columns=tuple(required_columns),
        )
        self._schema_cache[table_name] = schema
        return schema

    def _table_exists(self, conn: sqlite3.Connection, table_name: str) -> bool:
        cached = self._table_exists_cache.get(table_name)
        if cached is not None:
            return cached
        row = conn.execute(
            """
            SELECT 1
            FROM sqlite_master
            WHERE type = 'table'
              AND name = ?
            LIMIT 1
            """,
            (table_name,),
        ).fetchone()
        exists = row is not None
        self._table_exists_cache[table_name] = exists
        return exists

    def _adapt_value(self, value: Any) -> Any:
        if isinstance(value, (dict, list, tuple, set)):
            return json.dumps(value, separators=(",", ":"))
        if isinstance(value, bool):
            return int(value)
        return value

    def _enqueue_item(
        self,
        *,
        table_name: str,
        payload: Mapping[str, Any],
        attempt: int,
        count_as_queued: bool,
    ) -> bool:
        item = (str(table_name), dict(payload), max(0, int(attempt)))
        try:
            self._queue.put_nowait(item)
        except queue.Full:
            with self._stats_lock:
                self._stats["dropped_writes"] += 1
            return False
        if count_as_queued:
            with self._stats_lock:
                self._stats["queued_writes"] += 1
        return True

    def _drop_one(self) -> None:
        try:
            _ = self._queue.get_nowait()
        except queue.Empty:
            return
        self._queue.task_done()
        with self._stats_lock:
            self._stats["dropped_writes"] += 1

    def _record_failed_write(self, *, table_name: str, exc: Exception) -> None:
        error_type = type(exc).__name__
        category = _error_category(exc)
        with self._stats_lock:
            self._stats["failed_writes"] += 1
            by_table = self._stats["failed_writes_by_table"]
            by_table[table_name] = int(by_table.get(table_name, 0)) + 1

            by_error_type = self._stats["failed_writes_by_error_type"]
            by_error_type[error_type] = int(by_error_type.get(error_type, 0)) + 1

            by_category = self._stats["failed_writes_by_error_category"]
            by_category[category] = int(by_category.get(category, 0)) + 1

    def _record_dead_letter(
        self,
        *,
        table_name: str,
        payload: Mapping[str, Any],
        exc: Exception,
        attempt: int,
    ) -> None:
        entry = {
            "table_name": str(table_name),
            "payload": dict(payload),
            "error_type": type(exc).__name__,
            "error_category": _error_category(exc),
            "error_message": str(exc),
            "attempt": max(0, int(attempt)),
            "failed_at": _utc_now_iso(),
        }
        with self._stats_lock:
            if len(self._dead_letters) >= self._dead_letter_maxsize:
                self._dead_letters.pop(0)
            self._dead_letters.append(entry)
            self._stats["dead_lettered_writes"] += 1


def _configure_connection(conn: sqlite3.Connection) -> None:
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.execute(f"PRAGMA busy_timeout = {_SQLITE_BUSY_TIMEOUT_MS};")
    journal_mode = str(conn.execute("PRAGMA journal_mode;").fetchone()[0]).lower()
    if journal_mode != "wal":
        conn.execute("PRAGMA journal_mode = WAL;")
    conn.execute("PRAGMA synchronous = NORMAL;")


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _coerce_utc(value: datetime) -> datetime:
    if value.tzinfo is None:
        return value.replace(tzinfo=timezone.utc)
    return value.astimezone(timezone.utc)


def _coerce_utc_day_floor(value: datetime) -> datetime:
    utc = _coerce_utc(value)
    return utc.replace(hour=0, minute=0, second=0, microsecond=0)


def _coerce_float(value: Any, *, default: float) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return float(default)


def _last_changes(conn: sqlite3.Connection) -> int:
    row = conn.execute("SELECT changes();").fetchone()
    if row is None:
        return 0
    return int(row[0])


def _error_category(exc: Exception) -> str:
    message = str(exc).lower()
    if isinstance(exc, sqlite3.IntegrityError):
        return "integrity_error"
    if isinstance(exc, sqlite3.ProgrammingError):
        return "programming_error"
    if isinstance(exc, sqlite3.OperationalError):
        if "database is locked" in message or "database locked" in message:
            return "database_locked"
        if "no such table" in message or "no column named" in message:
            return "schema_mismatch"
        return "operational_error"
    if isinstance(exc, sqlite3.DatabaseError):
        return "database_error"
    return type(exc).__name__.lower()
