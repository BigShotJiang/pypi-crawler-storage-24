## Security Scanners

The platform integrates four industry-standard security scanners:

1. **Semgrep** - Multi-language static analysis
   - Supports 18+ languages: Python, JavaScript, TypeScript, Java, Go, Ruby, PHP, C/C++, C#, Rust, Kotlin, Scala, Swift
   - Uses Semgrep Registry community rules
   - OWASP Top 10 and CWE coverage

2. **Bandit** - Python static security analysis
   - Detects hard-coded secrets, SQL injection, shell injection, insecure crypto
   - 68+ built-in security checks
   - Severity-based risk scoring

2. **Checkov** - Infrastructure as Code security
   - Scans Terraform, Dockerfile, Kubernetes, CloudFormation
   - 1000+ built-in policies (CIS, PCI-DSS, HIPAA compliance)
   - Identifies misconfigurations before deployment

3. **pip-audit** - Python dependency vulnerability scanning
   - Checks for known CVEs in dependencies
   - Uses PyPI Advisory Database
   - Provides upgrade recommendations

### Scanner Workflow

1. Repository is cloned to temporary directory
2. All applicable scanners run in parallel
3. Findings are aggregated and stored in database
4. Risk score calculated based on severity (0-10 scale)
5. Temporary files cleaned up



The platform includes a powerful CLI script to trigger scans and resolutions directly from your terminal.

#### 1. Installation

**Recommended: Quick Install (curl)**
```bash
curl -sSL https://raw.githubusercontent.com/maxwellsarpong/security-compliance-platform/main/install.sh | bash
```
```

**Using uv (Isolated)**
```bash
uv tool install scp-cli
```

**Using pip**
```bash
pip install scp-cli --upgrade
```

#### 2. Usage
[Get your API key from the dashboard](https://code-security-platform-frontend-lan.vercel.app/login)

Running the CLI tool

```bash
# Showing the help menu
scp-cli --help

# Authenticate (Set your API key)
scp-cli auth --key <YOUR_API_KEY>

# Start a remote scan
scp-cli scan https://github.com/owner/repo

# Start a local workspace scan (automatic zipping & upload)
scp-cli scan .

# Check scan status (summarized results)
scp-cli status <scan_id>

# CI/CD: Wait for scan completion and verify results
# --fail: Exit with code 1 if matches are found
# --severity: Minimum severity (LOW, MEDIUM, HIGH, CRITICAL)
scp-cli check <scan_id> --severity HIGH --fail

# List all security issues for a scan (get Finding IDs)
scp-cli findings <scan_id>

# Resolve findings (Bulk fix for a scan)
# - For remote repos: Creates a Pull Request and returns the URL.
# - For local scans: Generates and applies fixes directly to your files (with backups).
scp-cli resolve <id_or_finding_id>

# Check all successfully resolved findings
scp-cli resolved

# Get the PR URL for a specific resolved finding
scp-cli pr <finding_id>

# Check your quota
scp-cli usage

# Check current authentication status
scp-cli whoami
```