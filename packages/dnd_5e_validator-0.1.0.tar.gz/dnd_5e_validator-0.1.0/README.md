# D&D 5e Validator
A lightweight Python library containing Pydantic models to validate D&D 5e monster statblocks. Perfect for AI generation pipelines and VTT integrations.

**Installation:**
`pip install dnd-5e-validator`