from pydantic import BaseModel
from typing import List, Optional

class ActionModel(BaseModel):
    name: str
    description: str

class MonsterStatblock(BaseModel):
    name: str
    size: str
    type: str
    alignment: str
    armor_class: int
    hit_points: int
    speed: str
    strength: int
    dexterity: int
    constitution: int
    intelligence: int
    wisdom: int
    charisma: int
    actions: List[ActionModel]
    special_abilities: Optional[List[ActionModel]] = []