# hello-world-pypi

A minimal hello world Python package.

## Installation

```bash
pip install hello-world-pypi
```

## Usage

```python
from hello_world import hello

print(hello())  # Hello, World!
```

## Build status

- `python -m build` completed successfully
- `twine check dist/*` passed for both wheel and sdist

## Publishing to PyPI

1. **Choose a unique package name** – `hello-world-pypi` may already be taken. Update the `name` field in `pyproject.toml` if needed.
2. **Set author info** – Replace `"Your Name"` and `"you@example.com"` in `pyproject.toml`.
3. **Create a PyPI API token** at [pypi.org/manage/account/#api-tokens](https://pypi.org/manage/account/#api-tokens).
4. **Upload** (from the project directory with `.venv` activated):

   ```bash
   source .venv/bin/activate
   python -m twine upload dist/*
   ```

   When prompted, use `__token__` as the username and your API token as the password.

To test first on TestPyPI:

```bash
python -m twine upload --repository testpypi dist/*
```
