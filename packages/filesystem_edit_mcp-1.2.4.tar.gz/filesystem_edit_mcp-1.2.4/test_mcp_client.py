"""Simple MCP client to test the server tools."""
import asyncio
import os
import tempfile
from fastmcp import Client


async def main():
    # Create a temporary directory for testing
    with tempfile.TemporaryDirectory() as tmp_dir:
        # Create a test file
        test_file = os.path.join(tmp_dir, "test.txt")
        with open(test_file, "w") as f:
            f.write("Hello, World!\nThis is a test file.\n")
        
        print(f"Created test file: {test_file}")
        
        # Create MCP client that spawns the server
        client = Client({
            "mcpServers": {
                "my-mcp": {
                    "command": "python",
                    "args": ["-m", "my_mcp", tmp_dir],
                }
            }
        })
        
        async with client:
            # List available tools
            print("\n--- Available Tools ---")
            tools = await client.list_tools()
            for tool in tools:
                print(f"  • {tool.name}")
            
            # Read the test file
            print(f"\n--- Reading File ---")
            result = await client.call_tool("read_text_file", {"path": test_file})
            print(f"File content:\n{result.content[0].text}")
            
            # Edit the file
            print(f"\n--- Editing File ---")
            edit_result = await client.call_tool(
                "edit_file",
                {
                    "path": test_file,
                    "edits": [
                        {
                            "operation": "str_replace",
                            "old": "Hello, World!",
                            "new": "Hello, MCP!"
                        }
                    ],
                    "dryRun": False
                }
            )
            print(f"Edit result:\n{edit_result.content[0].text}")

            print(f"\n--- Reading File After Edit ---")
            result2 = await client.call_tool("read_file", {"path": test_file})
            print(f"File content:\n{result2.content[0].text}")


if __name__ == "__main__":
    asyncio.run(main())
