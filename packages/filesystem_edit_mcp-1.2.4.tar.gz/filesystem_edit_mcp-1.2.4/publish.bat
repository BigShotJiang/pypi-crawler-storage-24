@echo off
for /f "tokens=2 delims==" %%A in ('findstr "UV_PUBLISH_TOKEN" "%~dp0.env"') do set UV_PUBLISH_TOKEN=%%A
uv publish dist/filesystem_edit_mcp-1.2.3* --token %UV_PUBLISH_TOKEN%
