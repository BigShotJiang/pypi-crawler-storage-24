import pytest

from my_mcp.umlaut_config import UmlautConfig
from my_mcp.umlaut_fixer import (
    fix_document,
    make_string_literal,
    transform_char,
    transform_comment,
    transform_string,
)


class TestTransformString:
    def test_simple_replacement(self):
        result = transform_string('"Ärger"', {"Ä": "CAE_UMLT"})
        assert result == 'CAE_UMLT "rger"'

    def test_multiple_umlauts(self):
        result = transform_string('"Ärger Übung"', {"Ä": "AE", "Ü": "UE"})
        assert result == 'AE "rger " UE "bung"'

    def test_no_umlaut_returns_none(self):
        assert transform_string('"hello"', {"Ä": "AE"}) is None

    def test_raw_string_ignored(self):
        assert transform_string('R"(test)"', {"Ä": "AE"}) is None

    def test_wide_string_ignored(self):
        assert transform_string('L"test"', {"Ä": "AE"}) is None


class TestTransformComment:
    def test_line_comment(self):
        result = transform_comment("// Ärger\n", {"Ä": "Ae", "ä": "ae"})
        assert result == "// Aerger\n"

    def test_block_comment(self):
        result = transform_comment("/* Übung */", {"Ü": "Ue"})
        assert result == "/* Uebung */"

    def test_no_change_returns_none(self):
        assert transform_comment("// hello", {"Ä": "Ae"}) is None


class TestTransformChar:
    def test_single_char(self):
        result = transform_char("'Ä'", {"Ä": "CAE_UMLT_CHAR"})
        assert result == "CAE_UMLT_CHAR"

    def test_regular_char_unchanged(self):
        assert transform_char("'a'", {"Ä": "AE"}) is None

    def test_wide_char_ignored(self):
        assert transform_char("'Äx'", {"Ä": "AE"}) is None


class TestMakeStringLiteral:
    def test_from_string(self):
        assert make_string_literal("hello") == '"hello"'

    def test_from_list(self):
        assert make_string_literal(["a", "b"]) == '"ab"'

    def test_custom_quotes(self):
        assert make_string_literal("hello", "'") == "'hello'"


class TestFixDocument:
    @pytest.fixture
    def config(self):
        return UmlautConfig(
            string_mapping={"Ä": "CAE_UMLT", "ü": "UE_UMLT"},
            comment_mapping={"Ä": "Ae", "ü": "ue", "Ü": "Ue"},
            char_mapping={"Ä": "CAE_UMLT_CHAR"},
        )

    def test_string_literal(self, config):
        code = 'const char* s = "Ärger";'
        result = fix_document(code, config)
        assert result == 'const char* s = CAE_UMLT "rger";'

    def test_comment(self, config):
        code = "// Ärger\n"
        result = fix_document(code, config)
        assert result == "// Aerger\n"

    def test_char_literal(self, config):
        code = "char c = 'Ä';"
        result = fix_document(code, config)
        assert result == "char c = CAE_UMLT_CHAR;"

    def test_multiple_nodes(self, config):
        code = 'const char* s = "Ärger"; // Übung\n'
        result = fix_document(code, config)
        assert "CAE_UMLT" in result
        assert "Uebung" in result

    def test_preserves_non_umlaut_code(self, config):
        code = "int x = 42;\n"
        result = fix_document(code, config)
        assert result == code

    def test_empty_string(self, config):
        result = fix_document("", config)
        assert result == ""

    def test_no_modifications_needed(self, config):
        code = "int main() { return 0; }"
        result = fix_document(code, config)
        assert result == code
