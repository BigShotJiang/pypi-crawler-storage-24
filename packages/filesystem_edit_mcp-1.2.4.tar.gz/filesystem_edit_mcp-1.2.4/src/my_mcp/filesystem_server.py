"""Manages the underlying filesystem MCP server as an internal dependency.
Swappable — change BACKEND_CONFIG to use a different MCP server implementation."""
import shutil
import tempfile

from fastmcp import Client

BACKEND_CONFIG = {
    "command": "npx",
    "args": ["-y", "@modelcontextprotocol/server-filesystem"],
}
TOOL_NAME = "edit_file"


def check_npx_available() -> None:
    """Raise a clear error if npx is not installed."""
    if shutil.which("npx") is None:
        raise RuntimeError(
            "npx is not installed or not on PATH. "
            "Install Node.js (https://nodejs.org) to use this MCP server. "
            "npx is required to run @modelcontextprotocol/server-filesystem."
        )


def create_client(allowed_dirs: list[str]) -> Client:
    """Create a client that spawns the filesystem MCP server with given directories.
    Also grants access to the system temp directory for internal temp file operations.
    """
    check_npx_available()
    config = {
        **BACKEND_CONFIG,
        "args": [*BACKEND_CONFIG["args"], *allowed_dirs, tempfile.gettempdir()],
    }
    return Client({"mcpServers": {"filesystem": config}})
