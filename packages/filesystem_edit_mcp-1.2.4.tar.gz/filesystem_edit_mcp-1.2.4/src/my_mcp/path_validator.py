from pathlib import Path


def resolve_path(path: str) -> Path:
    return Path(path).resolve()


def is_path_allowed(path: str, allowed_dirs: list[str]) -> bool:
    if not allowed_dirs:
        return False
    resolved = resolve_path(path)
    for allowed in allowed_dirs:
        allowed_resolved = resolve_path(allowed)
        try:
            resolved.relative_to(allowed_resolved)
        except ValueError:
            continue
        else:
            return True
    return False


class PathNotAllowedError(Exception):
    def __init__(self, path: str, allowed_dirs: list[str]):
        self.path = path
        self.allowed_dirs = allowed_dirs
        super().__init__(
            f"Path '{path}' is not within allowed directories: {allowed_dirs}"
        )


def validate_path(path: str, allowed_dirs: list[str]) -> Path:
    if not is_path_allowed(path, allowed_dirs):
        raise PathNotAllowedError(path, allowed_dirs)
    return resolve_path(path)
