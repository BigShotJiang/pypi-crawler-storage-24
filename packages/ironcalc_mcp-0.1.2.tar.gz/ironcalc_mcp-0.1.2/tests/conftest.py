"""Shared fixtures for ironcalc-mcp tests."""

import pytest

from ironcalc_mcp.server import server
from ironcalc_mcp.state import workbook


@pytest.fixture(autouse=True)
def fresh_workbook():
    """Reset workbook state before each test."""
    workbook.create("Test", "en", "UTC", "en")
    yield
    workbook._model = None
    workbook._file_path = None


@pytest.fixture
def mcp():
    """The FastMCP server instance."""
    return server
