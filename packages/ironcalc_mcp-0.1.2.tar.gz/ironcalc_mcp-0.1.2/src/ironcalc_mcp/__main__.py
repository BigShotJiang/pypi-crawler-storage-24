"""Entry point for the IronCalc MCP server."""

from ironcalc_mcp.server import server


def main() -> None:
    server.run(transport="stdio")


if __name__ == "__main__":
    main()
