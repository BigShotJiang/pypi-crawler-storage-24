"""MCP server setup and lifecycle."""

from mcp.server.fastmcp import FastMCP

from ironcalc_mcp.tools import register_all

server = FastMCP("ironcalc")
register_all(server)
