"""IronCalc MCP Server — spreadsheet engine accessible via Model Context Protocol."""

__version__ = "0.1.0"
