"""Workbook lifecycle tools: create, load, save, info."""

from __future__ import annotations

import json
from typing import TYPE_CHECKING

from ironcalc_mcp.state import workbook

if TYPE_CHECKING:
    from mcp.server.fastmcp import FastMCP


def register(server: FastMCP) -> None:
    @server.tool()
    async def create_workbook(
        name: str = "Workbook",
        locale: str = "en",
        timezone: str = "UTC",
        language: str = "en",
    ) -> str:
        """Create a new empty workbook.

        Args:
            name: Workbook name
            locale: Locale code (e.g. en, de, es, fr)
            timezone: Timezone (e.g. UTC, America/New_York)
            language: Language code for formulas (e.g. en, es, de)
        """
        workbook.create(name, locale, timezone, language)
        sheets = workbook.get_sheets()
        return json.dumps({
            "status": "created",
            "name": name,
            "sheets": [{"index": s.index, "name": s.name} for s in sheets],
        })

    @server.tool()
    async def load_workbook(
        file_path: str,
        locale: str = "en",
        timezone: str = "UTC",
        language: str = "en",
    ) -> str:
        """Load a workbook from an xlsx file.

        Args:
            file_path: Absolute path to the .xlsx file
            locale: Locale code (e.g. en, de, es)
            timezone: Timezone (e.g. UTC)
            language: Language code for formulas (e.g. en)
        """
        workbook.load_xlsx(file_path, locale, timezone, language)
        sheets = workbook.get_sheets()
        return json.dumps({
            "status": "loaded",
            "file": file_path,
            "sheets": [
                {"index": s.index, "name": s.name, "dimensions": s.dimensions}
                for s in sheets
            ],
        })

    @server.tool()
    async def save_workbook(file_path: str | None = None) -> str:
        """Save the current workbook to an xlsx file.

        Args:
            file_path: Path to save to. If omitted, saves to the path it was loaded from.
        """
        path = workbook.save_xlsx(file_path)
        return json.dumps({"status": "saved", "file": path})

    @server.tool()
    async def get_workbook_info() -> str:
        """Get information about the current workbook: sheets, dimensions, and metadata."""
        sheets = workbook.get_sheets()
        return json.dumps({
            "loaded": workbook.is_loaded,
            "file": workbook.file_path,
            "sheets": [
                {
                    "index": s.index,
                    "name": s.name,
                    "state": s.state,
                    "color": s.color,
                    "dimensions": {
                        "min_row": s.dimensions[0],
                        "max_row": s.dimensions[1],
                        "min_column": s.dimensions[2],
                        "max_column": s.dimensions[3],
                    },
                }
                for s in sheets
            ],
        })
