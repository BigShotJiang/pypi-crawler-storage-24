"""Row/column structure tools: insert, delete, resize."""

from __future__ import annotations

import json
from typing import TYPE_CHECKING

from ironcalc_mcp.state import workbook

if TYPE_CHECKING:
    from mcp.server.fastmcp import FastMCP


def register(server: FastMCP) -> None:
    @server.tool()
    async def insert_rows(sheet: int, row: int, count: int = 1) -> str:
        """Insert rows at the given position.

        Args:
            sheet: Sheet index (0-based)
            row: Row number where new rows are inserted (1-based)
            count: Number of rows to insert
        """
        workbook.model.insert_rows(sheet, row, count)
        workbook.model.evaluate()
        return json.dumps({"status": "ok", "inserted": count, "at_row": row})

    @server.tool()
    async def delete_rows(sheet: int, row: int, count: int = 1) -> str:
        """Delete rows starting at the given position.

        Args:
            sheet: Sheet index (0-based)
            row: First row to delete (1-based)
            count: Number of rows to delete
        """
        workbook.model.delete_rows(sheet, row, count)
        workbook.model.evaluate()
        return json.dumps({"status": "ok", "deleted": count, "at_row": row})

    @server.tool()
    async def insert_columns(sheet: int, column: int, count: int = 1) -> str:
        """Insert columns at the given position.

        Args:
            sheet: Sheet index (0-based)
            column: Column number where new columns are inserted (1-based)
            count: Number of columns to insert
        """
        workbook.model.insert_columns(sheet, column, count)
        workbook.model.evaluate()
        return json.dumps({"status": "ok", "inserted": count, "at_column": column})

    @server.tool()
    async def delete_columns(sheet: int, column: int, count: int = 1) -> str:
        """Delete columns starting at the given position.

        Args:
            sheet: Sheet index (0-based)
            column: First column to delete (1-based)
            count: Number of columns to delete
        """
        workbook.model.delete_columns(sheet, column, count)
        workbook.model.evaluate()
        return json.dumps({"status": "ok", "deleted": count, "at_column": column})

    @server.tool()
    async def set_column_width(sheet: int, column: int, width: float) -> str:
        """Set the width of a column.

        Args:
            sheet: Sheet index (0-based)
            column: Column number (1-based)
            width: Column width in points
        """
        workbook.model.set_column_width(sheet, column, width)
        return json.dumps({"status": "ok", "column": column, "width": width})

    @server.tool()
    async def set_row_height(sheet: int, row: int, height: float) -> str:
        """Set the height of a row.

        Args:
            sheet: Sheet index (0-based)
            row: Row number (1-based)
            height: Row height in points
        """
        workbook.model.set_row_height(sheet, row, height)
        return json.dumps({"status": "ok", "row": row, "height": height})

    @server.tool()
    async def set_frozen_rows(sheet: int, count: int) -> str:
        """Freeze the top N rows.

        Args:
            sheet: Sheet index (0-based)
            count: Number of rows to freeze (0 to unfreeze)
        """
        workbook.model.set_frozen_rows_count(sheet, count)
        return json.dumps({"status": "ok", "frozen_rows": count})

    @server.tool()
    async def set_frozen_columns(sheet: int, count: int) -> str:
        """Freeze the left N columns.

        Args:
            sheet: Sheet index (0-based)
            count: Number of columns to freeze (0 to unfreeze)
        """
        workbook.model.set_frozen_columns_count(sheet, count)
        return json.dumps({"status": "ok", "frozen_columns": count})
