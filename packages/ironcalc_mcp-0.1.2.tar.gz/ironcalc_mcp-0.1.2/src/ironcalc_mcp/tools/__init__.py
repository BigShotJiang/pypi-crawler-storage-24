"""Tool registration.

Each submodule defines a `register(server)` function that adds its tools.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from ironcalc_mcp.tools import cells, formatting, sheets, structure, workbook

if TYPE_CHECKING:
    from mcp.server.fastmcp import FastMCP

ALL_MODULES = [workbook, cells, sheets, structure, formatting]


def register_all(server: FastMCP) -> None:
    for module in ALL_MODULES:
        module.register(server)
