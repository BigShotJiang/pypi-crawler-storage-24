"""NCBI Datasets API v2 client."""

import httpx

NCBI_BASE = "https://api.ncbi.nlm.nih.gov/datasets/v2"
FTP_BASE = "https://ftp.ncbi.nlm.nih.gov/genomes/all"


def fetch_assembly_report(accession: str) -> dict:
    """Fetch assembly metadata from NCBI Datasets API v2."""
    url = f"{NCBI_BASE}/genome/accession/{accession}/dataset_report"
    params = {"include_annotation_type": "GENOME_FASTA,GENOME_GFF,RNA_FASTA,PROT_FASTA"}
    r = httpx.get(url, params=params, timeout=30)
    r.raise_for_status()
    data = r.json()

    reports = data.get("reports", [])
    if not reports:
        raise ValueError(f"No NCBI record found for accession: {accession}")

    rep = reports[0]
    info = rep.get("assembly_info", {})
    stats = rep.get("assembly_stats", {})
    org = rep.get("organism", {})

    return {
        "accession": rep.get("accession", accession),
        "assembly_name": info.get("assembly_name", ""),
        "assembly_level": info.get("assembly_level", ""),
        "assembly_status": info.get("assembly_status", ""),
        "bioproject": info.get("bioproject_accession", ""),
        "biosample": rep.get("biosample", {}).get("accession", ""),
        "release_date": info.get("release_date", ""),
        "submitter": info.get("submitter", ""),
        "organism_name": org.get("organism_name", ""),
        "tax_id": str(org.get("tax_id", "")),
        "total_sequence_length": stats.get("total_sequence_length", ""),
        "scaffold_n50": stats.get("scaffold_n50", ""),
        "contig_n50": stats.get("contig_n50", ""),
        "number_of_chromosomes": stats.get("total_number_of_chromosomes", ""),
        "gc_percent": stats.get("gc_percent", ""),
    }


def build_ftp_urls(accession: str, assembly_name: str) -> dict[str, str]:
    """Build NCBI FTP URLs for standard assembly files."""
    prefix = accession.split(".")[0]   # GCA_040938575
    digits = prefix.split("_")[1]      # 040938575
    path = f"{digits[0:3]}/{digits[3:6]}/{digits[6:9]}"
    kind = prefix.split("_")[0]        # GCA or GCF

    
    dir_name = f"{accession}_{assembly_name}" 
    dir_url = f"{FTP_BASE}/{kind}/{path}/{dir_name}"
    base = f"{dir_url}/{dir_name}"

    return {
        "fasta_genomic":   f"{base}_genomic.fna.gz",
        "gff_genomic":     f"{base}_genomic.gff.gz",
        "rna_fasta":       f"{base}_rna_from_genomic.fna.gz",
        "protein_fasta":   f"{base}_protein.faa.gz",
        "cds_fasta":       f"{base}_cds_from_genomic.fna.gz",
        "assembly_report": f"{base}_assembly_report.txt",
        "assembly_stats":  f"{base}_assembly_stats.txt",
        "md5checksums":    f"{dir_url}/md5checksums.txt",
    } 
