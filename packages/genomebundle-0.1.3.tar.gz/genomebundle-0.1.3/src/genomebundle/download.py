"""File download with SHA256 verification."""

import hashlib
import time
from pathlib import Path

import httpx


def download_file(url: str, dest: Path, chunk_size: int = 8192) -> dict:
    """Download a file and return path + SHA256 checksum."""
    dest.parent.mkdir(parents=True, exist_ok=True)

    # Return cached result if file already exists
    if dest.exists():
        sha256 = hashlib.sha256()
        with open(dest, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                sha256.update(chunk)
        return {
            "path": str(dest),
            "url": url,
            "status": "cached",
            "sha256": sha256.hexdigest(),
            "size_bytes": dest.stat().st_size,
            "elapsed_seconds": 0,
        }

    sha256 = hashlib.sha256()
    downloaded = 0
    started = time.time()

    with httpx.stream("GET", url, timeout=120, follow_redirects=True) as r:
        if r.status_code == 404:
            return {
                "path": str(dest),
                "url": url,
                "status": "not_available",
                "sha256": None,
                "size_bytes": 0,
                "elapsed_seconds": 0,
            }
        r.raise_for_status()
        with open(dest, "wb") as f:
            for chunk in r.iter_bytes(chunk_size):
                f.write(chunk)
                sha256.update(chunk)
                downloaded += len(chunk)

    elapsed = round(time.time() - started, 2)

    return {
        "path": str(dest),
        "url": url,
        "status": "ok",
        "sha256": sha256.hexdigest(),
        "size_bytes": downloaded,
        "elapsed_seconds": elapsed,
    }


def verify_bundle(bundle_dir: Path) -> list[dict]:
    """Verify SHA256 checksums of all files listed in manifest.json."""
    import json

    manifest_path = bundle_dir / "manifest.json"
    if not manifest_path.exists():
        raise FileNotFoundError(f"No manifest.json found in {bundle_dir}")

    manifest = json.loads(manifest_path.read_text())
    results = []

    for entry in manifest.get("files", []):
        path = bundle_dir / Path(entry["path"]).name
        expected = entry.get("sha256", "")

        if not path.exists():
            results.append({"file": str(path), "status": "MISSING"})
            continue

        sha256 = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                sha256.update(chunk)

        actual = sha256.hexdigest()
        status = "OK" if actual == expected else "MISMATCH"
        results.append({
            "file": str(path),
            "status": status,
            "expected": expected,
            "actual": actual,
        })

    return results

def verify_ncbi_md5(bundle_dir: Path) -> list[dict]:
    """Verify downloaded files against NCBI's official md5checksums.txt."""
    import hashlib

    md5_path = bundle_dir / "md5checksums.txt"
    if not md5_path.exists():
        raise FileNotFoundError(f"No md5checksums.txt found in {bundle_dir}")

    # parse NCBI format: "hash  ./filename"
    ncbi_hashes = {}
    for line in md5_path.read_text().splitlines():
        line = line.strip()
        if not line:
            continue
        parts = line.split()
        if len(parts) == 2:
            md5, fname = parts
            fname = fname.lstrip("./")
            ncbi_hashes[fname] = md5

    results = []
    for fname, expected_md5 in ncbi_hashes.items():
        path = bundle_dir / fname
        if not path.exists():
            results.append({"file": fname, "status": "NOT_DOWNLOADED"})
            continue

        h = hashlib.md5()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                h.update(chunk)
        actual = h.hexdigest()
        status = "OK" if actual == expected_md5 else "MISMATCH"
        results.append({
            "file": fname,
            "status": status,
            "expected_md5": expected_md5,
            "actual_md5": actual,
        })

    return results
