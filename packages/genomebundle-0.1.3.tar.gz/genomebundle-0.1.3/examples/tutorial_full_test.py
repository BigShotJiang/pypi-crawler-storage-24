# genomebundle — full test
# Copy each section into a separate Colab cell.
#
# This notebook tests three things:
#   1. Full download of a small EBP assembly + NCBI MD5 verify
#   2. Batch manifest generation for 5 DToL assemblies
#   3. Batch Data Availability statements

# ── CELL 1: Install ───────────────────────────────────────────────────────────

#!pip install genomebundle -q

# ── CELL 2: Imports ───────────────────────────────────────────────────────────

from genomebundle import (
    fetch_assembly,
    fetch_assembly_report,
    fetch_busco,
    build_ftp_urls,
    build_manifest,
    write_manifest,
    write_readme,
    download_file,
    verify_bundle,
    verify_ncbi_md5,
)
from genomebundle.manifest import build_citation
from pathlib import Path
import json

# ── CELL 3: TEST 1 — Full download of a small assembly ───────────────────────
#
# Oryctolagus cuniculus (European rabbit) — DToL, chromosome-level
# FASTA ~640 Mb compressed, manageable on Colab

ACCESSION = "GCA_009806435.2"
BUNDLE_DIR = Path(ACCESSION)

print(f"Assembly: {ACCESSION}")
print("=" * 60)

goat = fetch_assembly(ACCESSION)
ncbi = fetch_assembly_report(ACCESSION)
btk  = fetch_busco(ACCESSION)
ftp_urls = build_ftp_urls(ACCESSION, ncbi["assembly_name"])

print(f"Organism : {goat['scientific_name']} ({goat['common_name']})")
print(f"Level    : {ncbi['assembly_level']}")
print(f"Size     : {int(ncbi['total_sequence_length']):,} bp")
print(f"N50      : {ncbi['scaffold_n50']:,} bp")
print(f"BTK      : {'found' if btk['found'] else 'not available'}")

# ── CELL 4: Download md5checksums first, then FASTA ──────────────────────────

downloaded = []

# Always download md5checksums first
print("Downloading md5checksums.txt...")
result = download_file(ftp_urls["md5checksums"], BUNDLE_DIR / "md5checksums.txt")
downloaded.append(result)
print(f"  OK ({result['size_bytes']:,} bytes)")

# Download FASTA (~640 Mb)
print("Downloading FASTA (this will take a few minutes on Colab)...")
fname = ftp_urls["fasta_genomic"].split("/")[-1]
result = download_file(ftp_urls["fasta_genomic"], BUNDLE_DIR / fname)
downloaded.append(result)
print(f"  OK ({result['size_bytes']:,} bytes, sha256: {result['sha256'][:16]}...)")

# Download GFF
print("Downloading GFF...")
fname = ftp_urls["gff_genomic"].split("/")[-1]
result = download_file(ftp_urls["gff_genomic"], BUNDLE_DIR / fname)
if result["status"] == "not_available":
    print("  Not available for this assembly (no annotation).")
else:
    downloaded.append(result)
    print(f"  OK ({result['size_bytes']:,} bytes)")

# ── CELL 5: Verify — our SHA256 + NCBI official MD5 ─────────────────────────

print("\n── SHA256 verify (genomebundle) ──────────────────────────────────────")
manifest = build_manifest(goat, ncbi, btk, ftp_urls, downloaded)
write_manifest(manifest, BUNDLE_DIR)
write_readme(manifest, BUNDLE_DIR)

for r in verify_bundle(BUNDLE_DIR):
    print(f"  {r['status']:<8} {Path(r['file']).name}")

print("\n── MD5 verify (NCBI official) ────────────────────────────────────────")
for r in verify_ncbi_md5(BUNDLE_DIR):
    status = r["status"]
    fname = r["file"]
    if status == "NOT_DOWNLOADED":
        print(f"  {'—':<8} {fname} (not downloaded)")
    else:
        print(f"  {status:<8} {fname}")

# ── CELL 6: TEST 2 — Batch manifest for 5 DToL assemblies ────────────────────

BATCH = [
    "GCA_905319855.2",   # Canis lupus — wolf
    "GCA_910591885.2",   # Mus musculus — House mouse
    "GCA_921293095.1",   # Bufo bufo — common toad 
    "GCA_944738965.1",   # Lutra lutra — European otter
    "GCA_947172395.1",   # Mustela erminea — stoat
]

print("── Batch manifest (no download) ──────────────────────────────────────")
print(f"{'Accession':<20} {'Organism':<35} {'Level':<12} {'BTK'}")
print("-" * 80)

manifests = {}
for acc in BATCH:
    try:
        g = fetch_assembly(acc)
        n = fetch_assembly_report(acc)
        b = fetch_busco(acc)
        f = build_ftp_urls(acc, n["assembly_name"])
        m = build_manifest(g, n, b, f, [])
        write_manifest(m, Path(acc))
        manifests[acc] = m
        btk_status = "yes" if b["found"] else "no"
        print(f"  {acc:<18} {g['scientific_name']:<35} {n['assembly_level']:<12} {btk_status}")
    except Exception as e:
        print(f"  {acc:<18} ERROR: {e}")

# ── CELL 7: TEST 3 — Batch Data Availability statements ──────────────────────

print("\n── Data Availability statements ──────────────────────────────────────")
for acc, m in manifests.items():
    print(f"\n[{acc}]")
    print(build_citation(m))
    print()

# ── CELL 8: Summary ───────────────────────────────────────────────────────────

print("── Summary ───────────────────────────────────────────────────────────")
print(f"  Full download test : {ACCESSION}")
print(f"  Batch manifests    : {len(manifests)}/{len(BATCH)} successful")
total_busco = sum(1 for m in manifests.values() if m["busco"])
print(f"  BlobToolKit hits   : {total_busco}/{len(manifests)}")
print(f"  genomebundle v{manifest['genomebundle_version']}")
