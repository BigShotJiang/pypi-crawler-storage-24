# genomebundle demo — Ambystoma mexicanum (axolotl)
# 
# This script walks through a complete genomebundle workflow
# using the axolotl genome assembly (GCF_040938575.1) as an example.
# The axolotl has one of the largest vertebrate genomes sequenced to date
# (~29 Gb), making it a good stress test for the tool.
#
# Run on Google Colab or any Python 3.11+ environment.
#
# Install:
#   pip install genomebundle

# ── 0. Setup ──────────────────────────────────────────────────────────────────

#!pip install genomebundle -q

from genomebundle import (
    fetch_assembly,
    fetch_assembly_report,
    fetch_busco,
    build_ftp_urls,
    build_manifest,
    write_manifest,
    write_readme,
    download_file,
    verify_bundle,
)
from genomebundle.manifest import build_citation
from pathlib import Path
import json

ACCESSION = "GCF_040938575.1"
BUNDLE_DIR = Path(ACCESSION)

# ── 1. Fetch metadata ─────────────────────────────────────────────────────────

print("── GoaT ──────────────────────────────────────────────────────────────")
goat = fetch_assembly(ACCESSION)
print(f"  Scientific name : {goat['scientific_name']}")
print(f"  Common name     : {goat['common_name']}")
print(f"  TaxID           : {goat['taxon_id']}")
print(f"  GoaT record     : {goat['goat_url']}")

print("\n── NCBI ──────────────────────────────────────────────────────────────")
ncbi = fetch_assembly_report(ACCESSION)
print(f"  Assembly name   : {ncbi['assembly_name']}")
print(f"  Level           : {ncbi['assembly_level']}")
print(f"  Released        : {ncbi['release_date']}")
print(f"  Submitter       : {ncbi['submitter']}")
print(f"  BioProject      : {ncbi['bioproject']}")
print(f"  Total length    : {int(ncbi['total_sequence_length']):,} bp")
print(f"  Scaffold N50    : {ncbi['scaffold_n50']:,} bp")
print(f"  Contig N50      : {ncbi['contig_n50']:,} bp")
print(f"  Chromosomes     : {ncbi['number_of_chromosomes']}")
print(f"  GC%             : {ncbi['gc_percent']}")

print("\n── BlobToolKit ───────────────────────────────────────────────────────")
btk = fetch_busco(ACCESSION)
if btk["found"]:
    for lineage, vals in btk["busco"].items():
        print(f"  {lineage}: {vals['string']}")
else:
    print("  Not available for this assembly.")
    print("  Note: BlobToolKit primarily covers Darwin Tree of Life assemblies.")
    print("  The axolotl assembly (VGP/University of Kentucky) is not indexed.")

# ── 2. Build FTP URL index ────────────────────────────────────────────────────

print("\n── FTP file URLs ─────────────────────────────────────────────────────")
ftp_urls = build_ftp_urls(ACCESSION, ncbi["assembly_name"])
for name, url in ftp_urls.items():
    print(f"  {name:<20} {url}")

# ── 3. Download lightweight files and verify ─────────────────────────────────
#
# The axolotl FASTA is ~9 GB compressed — we skip it here.
# assembly_report and md5checksums are a few KB each and demonstrate
# the full download + verify workflow.

print("\n── Downloading assembly_report and md5checksums ──────────────────────")
downloaded = []

for key in ("assembly_report", "md5checksums"):
    url = ftp_urls[key]
    filename = url.split("/")[-1]
    dest = BUNDLE_DIR / filename
    print(f"  {filename}...", end=" ", flush=True)
    result = download_file(url, dest)
    downloaded.append(result)
    print(f"OK ({result['size_bytes']} bytes)")

# ── 4. Build and write manifest ───────────────────────────────────────────────

print("\n── Building manifest ─────────────────────────────────────────────────")
manifest = build_manifest(goat, ncbi, btk, ftp_urls, downloaded)
manifest_path = write_manifest(manifest, BUNDLE_DIR)
readme_path = write_readme(manifest, BUNDLE_DIR)
print(f"  manifest.json : {manifest_path}")
print(f"  README.txt    : {readme_path}")

# ── 5. Verify checksums ───────────────────────────────────────────────────────

print("\n── Verifying checksums ───────────────────────────────────────────────")
from genomebundle.download import verify_bundle
results = verify_bundle(BUNDLE_DIR)
for r in results:
    status = r["status"]
    fname = Path(r["file"]).name
    print(f"  {status:<8} {fname}")

# ── 6. Data Availability statement ───────────────────────────────────────────

print("\n── Data Availability statement ───────────────────────────────────────")
print()
print(build_citation(manifest))

# ── 7. Inspect the manifest ───────────────────────────────────────────────────

print("\n── manifest.json ─────────────────────────────────────────────────────")
print(json.dumps(manifest, indent=2))
