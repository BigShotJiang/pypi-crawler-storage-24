# genomebundle — CLI feature test
# Tests all published CLI commands on a single assembly.
#
# Assembly: Canis lupus (wolf) — GCA_905319855.2
# Darwin Tree of Life, Wellcome Sanger Institute
#
# Run with:
#   uv run demo_download_and_verify.py
# or on Colab:
#   !pip install genomebundle -q
#   then copy into cells

import subprocess
import sys

# Uncomment if running on Google Colab:
# import subprocess; subprocess.run([sys.executable, "-m", "pip", "install", "genomebundle", "-q"])

ACCESSION = "GCA_905319855.2"

def run(cmd: str):
    print(f"\n$ {cmd}")
    print("-" * 60)
    result = subprocess.run(cmd, shell=True, text=True)
    if result.returncode != 0:
        print(f"[ERROR] exit code {result.returncode}")
    return result.returncode

print("=" * 60)
print("genomebundle CLI feature test")
print(f"Assembly: {ACCESSION} (Canis lupus — wolf)")
print("=" * 60)

# ── 1. Help ───────────────────────────────────────────────────
run("genomebundle --help")
run("genomebundle fetch --help")
run("genomebundle verify --help")
run("genomebundle show --help")
run("genomebundle cite --help")

# ── 2. Manifest only (no download) ───────────────────────────
run(f"genomebundle fetch {ACCESSION} --no-download")

# ── 3. show — print manifest ──────────────────────────────────
run(f"genomebundle show ./{ACCESSION}/")

# ── 4. cite — Data Availability statement ────────────────────
run(f"genomebundle cite ./{ACCESSION}/")

# ── 5. Download report and stats only ────────────────────────
run(f"genomebundle fetch {ACCESSION} --files report,stats")

# ── 6. Download protein and CDS ──────────────────────────────
run(f"genomebundle fetch {ACCESSION} --files protein,cds")

# ── 7. Download FASTA ─────────────────────────────────────────
run(f"genomebundle fetch {ACCESSION} --files fasta")

# ── 8. verify — SHA256 checksums ─────────────────────────────
run(f"genomebundle verify ./{ACCESSION}/")

# ── 9. Custom output directory ───────────────────────────────
run(f"genomebundle fetch {ACCESSION} --no-download --output-dir /tmp/wolf_test")
run("genomebundle show /tmp/wolf_test/")
run("genomebundle cite /tmp/wolf_test/")

# ── 10. --files all ───────────────────────────────────────────
# Downloads everything — skips files already cached
run(f"genomebundle fetch {ACCESSION} --files all")

# ── 11. Final verify after full download ─────────────────────
run(f"genomebundle verify ./{ACCESSION}/")

print("\n" + "=" * 60)
print("Test complete.")
