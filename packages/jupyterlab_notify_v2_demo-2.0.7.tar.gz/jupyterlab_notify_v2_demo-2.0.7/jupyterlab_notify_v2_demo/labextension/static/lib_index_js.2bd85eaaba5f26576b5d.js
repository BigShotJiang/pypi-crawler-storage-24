"use strict";
(self["webpackChunkjupyterlab_notify_v2_demo"] = self["webpackChunkjupyterlab_notify_v2_demo"] || []).push([["lib_index_js"],{

/***/ "./lib/batch_notify.js":
/*!*****************************!*\
  !*** ./lib/batch_notify.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   BatchNotifier: () => (/* binding */ BatchNotifier)
/* harmony export */ });
/* harmony import */ var _jupyterlab_rendermime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/rendermime */ "webpack/sharing/consume/default/@jupyterlab/rendermime");
/* harmony import */ var _jupyterlab_rendermime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_rendermime__WEBPACK_IMPORTED_MODULE_0__);

const MIME_TYPE = 'application/desktop-notify+json';
class BatchNotifier {
    constructor(rendermime) {
        this.rendermime = rendermime;
        // States are now per type and per notebookId
        this.states = {
            completed: {},
            failed: {},
            timeout: {},
        };
        this.batchWindow = 3000; // ms
    }
    notify(type, data) {
        const notebookId = data.payload.notebookId;
        if (!notebookId) {
            // If somehow notebookId is missing.
            return;
        }
        if (!this.states[type][notebookId]) {
            this.states[type][notebookId] = { buffer: [], timer: null };
        }
        const state = this.states[type][notebookId];
        if (state.timer === null) {
            // first of its kind: show immediately
            this.showSingle(data);
            // start window to batch any immediate follow-ups of the same type and notebook
            state.timer = window.setTimeout(() => this.flush(type, notebookId), this.batchWindow);
        }
        else {
            // within window: buffer it
            state.buffer.push(data);
        }
    }
    async flush(type, notebookId) {
        const state = this.states[type][notebookId];
        state.timer = null;
        if (state.buffer.length === 0) {
            return;
        }
        if (state.buffer.length === 1) {
            await this.showSingle(state.buffer[0]);
        }
        else {
            await this.showBatch(state.buffer);
        }
        state.buffer = [];
    }
    async showSingle(data) {
        try {
            const mimeModel = new _jupyterlab_rendermime__WEBPACK_IMPORTED_MODULE_0__.MimeModel({
                data: { [MIME_TYPE]: JSON.parse(JSON.stringify(data)) },
            });
            const renderer = this.rendermime.createRenderer(MIME_TYPE);
            await renderer.renderModel(mimeModel);
        }
        catch (err) {
            console.error('Error rendering single notification:', err);
        }
    }
    async showBatch(batch) {
        const firstTitle = batch[0].payload.title;
        const body = batch
            .map(notification => notification.payload.executionCount)
            .filter((executionCount) => typeof executionCount === 'number')
            .map(executionCount => executionCount.toString())
            .join(', ');
        // Contains notebookId and cellId of first notification. Notification are batched per notebook
        // So, clicking on this batched notification will take user to first cell that raised notification
        const summary = {
            ...batch[0],
            payload: {
                ...batch[0].payload,
                title: firstTitle.replace(/Cell /, `${batch.length} cells `),
                body,
            },
        };
        try {
            const mimeModel = new _jupyterlab_rendermime__WEBPACK_IMPORTED_MODULE_0__.MimeModel({
                data: { [MIME_TYPE]: JSON.parse(JSON.stringify(summary)) },
            });
            const renderer = this.rendermime.createRenderer(MIME_TYPE);
            await renderer.renderModel(mimeModel);
        }
        catch (err) {
            console.error('Error rendering batched notification:', err);
        }
    }
}


/***/ }),

/***/ "./lib/handler.js":
/*!************************!*\
  !*** ./lib/handler.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   requestAPI: () => (/* binding */ requestAPI)
/* harmony export */ });
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__);


/**
 * Call the API extension
 *
 * @param endPoint API REST end point for the extension
 * @param init Initial values for the request
 * @returns The response body interpreted as JSON
 */
async function requestAPI(endPoint = '', init = {}) {
    // Make request to Jupyter API
    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeSettings();
    const requestUrl = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(settings.baseUrl, 'api/jupyter-notify', // API Namespace
    endPoint);
    let response;
    try {
        response = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeRequest(requestUrl, init, settings);
    }
    catch (error) {
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.NetworkError(error);
    }
    const rawData = await response.text();
    let data = {};
    if (rawData.length > 0) {
        try {
            data = JSON.parse(rawData);
        }
        catch (error) {
            console.log('Not a JSON response body.', response);
        }
    }
    if (!response.ok) {
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.ResponseError(response);
    }
    return data;
}


/***/ }),

/***/ "./lib/icons.js":
/*!**********************!*\
  !*** ./lib/icons.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   bellAlertIcon: () => (/* binding */ bellAlertIcon),
/* harmony export */   bellClockIcon: () => (/* binding */ bellClockIcon),
/* harmony export */   bellFilledIcon: () => (/* binding */ bellFilledIcon),
/* harmony export */   bellOffIcon: () => (/* binding */ bellOffIcon),
/* harmony export */   bellOutlineIcon: () => (/* binding */ bellOutlineIcon)
/* harmony export */ });
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _style_icons_bell_outline_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../style/icons/bell-outline.svg */ "./style/icons/bell-outline.svg");
/* harmony import */ var _style_icons_bell_filled_svg__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../style/icons/bell-filled.svg */ "./style/icons/bell-filled.svg");
/* harmony import */ var _style_icons_bell_off_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../style/icons/bell-off.svg */ "./style/icons/bell-off.svg");
/* harmony import */ var _style_icons_bell_alert_svg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../style/icons/bell-alert.svg */ "./style/icons/bell-alert.svg");
/* harmony import */ var _style_icons_bell_clock_svg__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../style/icons/bell-clock.svg */ "./style/icons/bell-clock.svg");






const bellOutlineIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'notify:bell-outline',
    svgstr: _style_icons_bell_outline_svg__WEBPACK_IMPORTED_MODULE_1__,
});
const bellFilledIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'notify:bell-filled',
    svgstr: _style_icons_bell_filled_svg__WEBPACK_IMPORTED_MODULE_2__,
});
const bellOffIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'notify:bell-off',
    svgstr: _style_icons_bell_off_svg__WEBPACK_IMPORTED_MODULE_3__,
});
const bellAlertIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'notify:bell-alert',
    svgstr: _style_icons_bell_alert_svg__WEBPACK_IMPORTED_MODULE_4__,
});
const bellClockIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'notify:bell-clock',
    svgstr: _style_icons_bell_clock_svg__WEBPACK_IMPORTED_MODULE_5__,
});


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/settingregistry */ "webpack/sharing/consume/default/@jupyterlab/settingregistry");
/* harmony import */ var _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _jupyterlab_translation__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @jupyterlab/translation */ "webpack/sharing/consume/default/@jupyterlab/translation");
/* harmony import */ var _jupyterlab_translation__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_translation__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./utils */ "./lib/utils.js");
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./icons */ "./lib/icons.js");
/* harmony import */ var _handler__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./handler */ "./lib/handler.js");
/* harmony import */ var _jupyterlab_rendermime__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @jupyterlab/rendermime */ "webpack/sharing/consume/default/@jupyterlab/rendermime");
/* harmony import */ var _jupyterlab_rendermime__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_rendermime__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _menuTooltip__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./menuTooltip */ "./lib/menuTooltip.js");
/* harmony import */ var _batch_notify__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./batch_notify */ "./lib/batch_notify.js");
/* harmony import */ var _mime__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./mime */ "./lib/mime.js");
/* harmony import */ var _token__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./token */ "./lib/token.js");













var CommandIDs;
(function (CommandIDs) {
    CommandIDs.setNotificationMode = 'notify:set-notification-mode';
    CommandIDs.setCustomTimeout = 'notify:set-custom-timeout';
    CommandIDs.setNotebookCustomTimeout = 'notify:set-notebook-custom-timeout';
    CommandIDs.setNotebookDefaultThreshold = 'notify:set-notebook-default-threshold';
    CommandIDs.openNotificationSettings = 'notify:open-notification-settings';
    CommandIDs.setNotebookNotificationMode = 'notify:set-notebook-notification-mode';
})(CommandIDs || (CommandIDs = {}));
const MODES = {
    default: {
        label: 'Default',
        icon: _icons__WEBPACK_IMPORTED_MODULE_6__.bellOutlineIcon,
        info: 'Notify after cell finishes execution if it exceeds the default threshold.',
    },
    never: {
        label: 'Never',
        icon: _icons__WEBPACK_IMPORTED_MODULE_6__.bellOffIcon,
        info: 'Never send notifications for this cell.',
    },
    'on-error': {
        label: 'On Error',
        icon: _icons__WEBPACK_IMPORTED_MODULE_6__.bellAlertIcon,
        info: 'Notify only if cell execution fails.',
    },
    'custom-timeout': {
        label: 'Custom Timeout',
        icon: _icons__WEBPACK_IMPORTED_MODULE_6__.bellClockIcon,
        info: 'Notify if a cell is still running after a set timeout.',
    },
};
/**
 * Main plugin definition
 */
const plugin = {
    id: 'jupyterlab-notify-v2-demo:plugin',
    description: 'Enhanced cell execution notifications for JupyterLab',
    autoStart: true,
    requires: [_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.INotebookTracker, _jupyterlab_rendermime__WEBPACK_IMPORTED_MODULE_8__.IRenderMimeRegistry],
    optional: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_4__.IToolbarWidgetRegistry, _jupyterlab_translation__WEBPACK_IMPORTED_MODULE_2__.ITranslator, _jupyterlab_settingregistry__WEBPACK_IMPORTED_MODULE_1__.ISettingRegistry],
    activate: async (app, tracker, rendermime, toolbarRegistry, translator, settingRegistry) => {
        console.log('JupyterLab extension jupyterlab-notify-v2-demo is activated!');
        const batchNotifier = new _batch_notify__WEBPACK_IMPORTED_MODULE_10__.BatchNotifier(rendermime);
        const rendererFactory = (0,_mime__WEBPACK_IMPORTED_MODULE_11__.createRendererFactory)(tracker, app.shell);
        rendermime.addFactory(rendererFactory, 0);
        // Default settings
        let notifySettings = {
            defaultMode: 'default',
            failureMessage: 'Cell execution failed',
            mail: false,
            slack: false,
            successMessage: 'Cell execution completed successfully',
            defaultThreshold: 30,
            customTimeout: 30,
            alwaysNotifyOnError: true,
        };
        // Settings management
        const updateSettings = (settings) => {
            notifySettings = { ...notifySettings, ...settings.composite };
        };
        if (settingRegistry) {
            // Ensure the recordTiming setting is enabled for the extension to function correctly
            const nbPluginId = '@jupyterlab/notebook-extension:tracker';
            const nbSettings = await settingRegistry.load(nbPluginId);
            await nbSettings.set('recordTiming', true);
            // Ensure recordTiming remains true if user tries to change it
            nbSettings.changed.connect(async () => {
                const recordTiming = nbSettings.get('recordTiming')
                    .composite;
                if (!recordTiming) {
                    await nbSettings.set('recordTiming', true);
                }
            });
            try {
                const settings = await settingRegistry.load(plugin.id);
                updateSettings(settings);
                settings.changed.connect(updateSettings);
            }
            catch (reason) {
                console.error('Failed to load settings for jupyterlab-notify-v2-demo:', reason);
            }
        }
        const addCellMetadata = (cell, nbmodel) => {
            if (cell.getMetadata(_token__WEBPACK_IMPORTED_MODULE_12__.NOTIFY_METADATA_KEY)) {
                return;
            }
            // If notebook metadata exists, use its mode for the cell; otherwise, use defaultMode
            const nbMetadata = nbmodel.getMetadata(_token__WEBPACK_IMPORTED_MODULE_12__.NOTIFY_METADATA_KEY);
            const mode = nbMetadata?.mode ?? notifySettings.defaultMode;
            if (mode === 'default') {
                // Use threshold from notebook metadata if present
                let nbThreshold = nbMetadata?.[_token__WEBPACK_IMPORTED_MODULE_12__.NOTEBOOK_DEFAULT_THRESHOLD_KEY];
                if (typeof nbThreshold === 'number') {
                    nbThreshold = `${nbThreshold}s`;
                }
                cell.setMetadata(_token__WEBPACK_IMPORTED_MODULE_12__.NOTIFY_METADATA_KEY, {
                    mode,
                    ...(nbThreshold ? { [_token__WEBPACK_IMPORTED_MODULE_12__.CELL_DEFAULT_THRESHOLD_KEY]: nbThreshold } : {}),
                });
            }
            else if (mode === 'custom-timeout') {
                // Use timeout from notebook metadata's NOTEBOOK_CUSTOM_TIMEOUT_KEY if present
                let nbCustomTimeout = nbMetadata?.[_token__WEBPACK_IMPORTED_MODULE_12__.NOTEBOOK_CUSTOM_TIMEOUT_KEY];
                if (typeof nbCustomTimeout === 'number') {
                    nbCustomTimeout = `${nbCustomTimeout}s`;
                }
                cell.setMetadata(_token__WEBPACK_IMPORTED_MODULE_12__.NOTIFY_METADATA_KEY, {
                    mode,
                    ...(nbCustomTimeout
                        ? { [_token__WEBPACK_IMPORTED_MODULE_12__.CELL_CUSTOM_TIMEOUT_KEY]: nbCustomTimeout }
                        : {}),
                });
            }
            else {
                cell.setMetadata(_token__WEBPACK_IMPORTED_MODULE_12__.NOTIFY_METADATA_KEY, { mode });
            }
        };
        // Track new notebooks
        tracker.widgetAdded.connect(async (_, notebookPanel) => {
            // Wait for the notebook to be fully ready
            await notebookPanel.revealed;
            await notebookPanel.sessionContext.ready;
            const notebook = notebookPanel.content;
            // Set notebook metadata if not present
            const nbModel = notebook.model;
            if (nbModel && !nbModel.getMetadata(_token__WEBPACK_IMPORTED_MODULE_12__.NOTIFY_METADATA_KEY)) {
                nbModel.setMetadata(_token__WEBPACK_IMPORTED_MODULE_12__.NOTIFY_METADATA_KEY, {
                    mode: notifySettings.defaultMode,
                    [_token__WEBPACK_IMPORTED_MODULE_12__.NOTEBOOK_CUSTOM_TIMEOUT_KEY]: typeof notifySettings.customTimeout === 'number'
                        ? `${notifySettings.customTimeout}s`
                        : notifySettings.customTimeout,
                    [_token__WEBPACK_IMPORTED_MODULE_12__.NOTEBOOK_DEFAULT_THRESHOLD_KEY]: typeof notifySettings.defaultThreshold === 'number'
                        ? `${notifySettings.defaultThreshold}s`
                        : notifySettings.defaultThreshold,
                });
            }
            // Explicitly run addCellMetadata on the first cell as we miss it while waiting above
            if (notebook.widgets.length > 0 && nbModel) {
                const firstCell = notebook.widgets[0].model;
                if (firstCell && firstCell.type === 'code') {
                    addCellMetadata(firstCell, nbModel);
                }
            }
            // Track new cells
            nbModel?.cells.changed.connect((_, change) => {
                if (change.type === 'add') {
                    change.newValues.forEach(cell => {
                        if (cell.type === 'code') {
                            if (notebook.model) {
                                addCellMetadata(cell, notebook.model);
                            }
                        }
                    });
                }
            });
            // Monitor kernel status changes to detect kernel death and autorestarts
            const handleKernelDeath = async () => {
                const session = notebookPanel.sessionContext.session;
                if (!session) {
                    return;
                }
                const kernel = session.kernel;
                if (!kernel ||
                    (kernel.status !== 'autorestarting' && kernel.status !== 'dead')) {
                    return;
                }
                const notebookId = notebook.id;
                for (const [cellId, notification] of cellNotificationMap.entries()) {
                    if (notification.notebookId === notebookId &&
                        notification.payload.mode === 'on-error' &&
                        !notification.notificationIssued) {
                        const cellWidget = notebook.widgets.find(w => w.model.id === cellId);
                        if (cellWidget) {
                            await handleNotification(cellWidget.model, false, false, {
                                errorName: 'Kernel Died',
                                name: 'Kernel Died',
                                errorValue: `The kernel has died. Status: "${kernel.status}"`,
                                message: `The kernel has died. Status: "${kernel.status}"`,
                                traceback: [],
                            });
                        }
                    }
                }
            };
            notebookPanel.sessionContext.statusChanged.connect(handleKernelDeath);
            const onKernelStatusChanged = () => {
                handleKernelDeath().catch(err => {
                    console.error('Error handling kernel death:', err);
                });
            };
            notebookPanel.sessionContext.kernelChanged.connect(() => {
                const kernel = notebookPanel.sessionContext.session?.kernel;
                if (kernel) {
                    // Connect to kernel status changes
                    kernel.statusChanged.disconnect(onKernelStatusChanged);
                    kernel.statusChanged.connect(onKernelStatusChanged);
                }
            });
            // Connect to initial kernel if it exists
            const kernel = notebookPanel.sessionContext.session?.kernel;
            if (kernel) {
                kernel.statusChanged.connect(onKernelStatusChanged);
            }
        });
        // Server configuration
        let config = {
            nbmodel_installed: false,
            email_configured: false,
            slack_configured: false,
            smtp_server_running: false,
        };
        try {
            config = await (0,_handler__WEBPACK_IMPORTED_MODULE_7__.requestAPI)('notify');
        }
        catch (e) {
            console.error('Checking server capability failed:', e);
        }
        const cellNotificationMap = new Map();
        /**
         * Handles notification rendering based on execution status
         */
        const handleNotification = async (cell, success, triggeredViaTimeout = false, kernelError = null) => {
            if (cell.type !== 'code') {
                return;
            }
            const cellId = cell.id;
            const notification = cellNotificationMap.get(cellId);
            if (!notification || notification.notificationIssued) {
                return;
            }
            const { payload } = notification;
            payload.execution_count = cell.executionCount;
            const isExecutionFailure = !success;
            const shouldNotifyForError = isExecutionFailure &&
                (payload.mode === 'on-error' || notifySettings.alwaysNotifyOnError);
            if (payload.mode === 'on-error' && success && !triggeredViaTimeout) {
                cellNotificationMap.delete(cellId);
                return;
            }
            // Return for custom-timeout if this isn't triggered by timeout or if cell already finished execution
            if (payload.mode === 'custom-timeout' &&
                !shouldNotifyForError &&
                (!triggeredViaTimeout ||
                    cell.executionState !== 'running')) {
                cellNotificationMap.delete(cellId);
                return;
            }
            // Handle case when threshold isn't exceeded in default mode
            if (payload.mode === 'default' && !shouldNotifyForError) {
                const timingData = cell.getMetadata('execution');
                if (!timingData) {
                    console.warn('Skipping notification: Missing execution timing data for cell', cellId);
                    return;
                }
                const startTime = timingData['shell.execute_reply.started'];
                const endTime = timingData['shell.execute_reply'] ?? timingData['execution_failed'];
                // Skip notification if execution time is below the threshold
                if (payload.threshold &&
                    startTime &&
                    endTime &&
                    new Date(endTime).getTime() - new Date(startTime).getTime() <
                        payload.threshold * 1000) {
                    return;
                }
            }
            // Determine notification type based on execution state
            const state = !success
                ? 'failed'
                : triggeredViaTimeout
                    ? 'timeout'
                    : 'completed';
            const message = state === 'timeout'
                ? 'Cell execution timeout reached'
                : state === 'completed'
                    ? notifySettings.successMessage
                    : notifySettings.failureMessage;
            const executionCount = cell.executionCount;
            const notificationData = (0,_utils__WEBPACK_IMPORTED_MODULE_5__.generateNotificationData)(state, message, cellId, payload.notebook_name, payload.notebookId, cell.getMetadata('execution'), typeof executionCount === 'number' ? executionCount : null, kernelError);
            if (!config.nbmodel_installed) {
                try {
                    await (0,_handler__WEBPACK_IMPORTED_MODULE_7__.requestAPI)('notify-trigger', {
                        method: 'POST',
                        body: JSON.stringify({
                            ...payload,
                            success,
                            timer: triggeredViaTimeout,
                            error: kernelError
                                ? `${kernelError.errorName}: ${kernelError.errorValue}`
                                : '',
                        }),
                    });
                }
                catch (e) {
                    console.error('Failed to trigger notification:', e);
                }
            }
            try {
                batchNotifier.notify(state, notificationData);
                notification.notificationIssued = true;
            }
            catch (err) {
                console.error('Error rendering notification:', err);
            }
            if (notification.timeoutId) {
                clearTimeout(notification.timeoutId);
            }
            cellNotificationMap.delete(cellId);
        };
        // Execution listeners
        _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.NotebookActions.executed.connect((_, args) => {
            void handleNotification(args.cell.model, args.success, false, args.error ?? null).catch(err => {
                console.error('Error handling notification:', err);
            });
        });
        _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.NotebookActions.executionScheduled.connect(async (_, args) => {
            const { notebook, cell } = args;
            const cellMetadata = cell.model.getMetadata(_token__WEBPACK_IMPORTED_MODULE_12__.NOTIFY_METADATA_KEY);
            const mode = cellMetadata?.mode;
            if (!mode || mode === 'never') {
                return;
            }
            if (Notification.permission !== 'granted') {
                await Notification.requestPermission().catch(err => {
                    _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_4__.Notification.emit('Permission Error', 'error', {
                        autoClose: 3000,
                        actions: [
                            {
                                label: 'Show Details',
                                callback: () => (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_4__.showErrorMessage)('Permission Error', {
                                    message: err,
                                }),
                            },
                        ],
                    });
                });
            }
            // Show configuration warnings
            if (notifySettings.mail) {
                if (!config.email_configured) {
                    (0,_utils__WEBPACK_IMPORTED_MODULE_5__.displayConfigWarning)('Email', 'email', 'youremail@example.com');
                }
                else if (!config.smtp_server_running) {
                    _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_4__.Notification.emit('SMTP Server Not Running', 'error', {
                        autoClose: 3000,
                        actions: [
                            {
                                label: 'Help',
                                callback: () => (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_4__.showErrorMessage)('SMTP server is not running', {
                                    message: 'Email notifications require a local SMTP server running.',
                                }),
                            },
                        ],
                    });
                }
            }
            // For making slack failure more verbose, we need more data from backend so we can display here
            if (notifySettings.slack && !config.slack_configured) {
                (0,_utils__WEBPACK_IMPORTED_MODULE_5__.displayConfigWarning)('Slack', 'slack_token', 'xoxb-your-slackbot-token');
            }
            if (mode === 'default') {
                // Get the threshold value: prefer cell, then notebook, then settings
                const thresholdValue = (0,_utils__WEBPACK_IMPORTED_MODULE_5__.getThresholdValue)(mode, cellMetadata, notebook.model?.getMetadata(_token__WEBPACK_IMPORTED_MODULE_12__.NOTIFY_METADATA_KEY), notifySettings.defaultThreshold, notifySettings.customTimeout);
                if (thresholdValue !== null && thresholdValue !== undefined) {
                    const thresholdInSeconds = (0,_utils__WEBPACK_IMPORTED_MODULE_5__.decodeThresholdToSeconds)(thresholdValue);
                    if (!Number.isFinite(thresholdInSeconds)) {
                        _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_4__.Notification.emit(`Invalid default threshold value: Expected a finite number, but received ${thresholdValue}`, 'error', { autoClose: 3000 });
                        return;
                    }
                }
            }
            if (mode === 'custom-timeout') {
                const thresholdValue = (0,_utils__WEBPACK_IMPORTED_MODULE_5__.getThresholdValue)(mode, cellMetadata, notebook.model?.getMetadata(_token__WEBPACK_IMPORTED_MODULE_12__.NOTIFY_METADATA_KEY), notifySettings.defaultThreshold, notifySettings.customTimeout);
                if (thresholdValue !== null && thresholdValue !== undefined) {
                    const thresholdInSeconds = (0,_utils__WEBPACK_IMPORTED_MODULE_5__.decodeThresholdToSeconds)(thresholdValue);
                    if (!Number.isFinite(thresholdInSeconds)) {
                        _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_4__.Notification.emit(`Invalid custom timeout value: Expected a finite number, but received ${thresholdValue}`, 'error', { autoClose: 3000 });
                        return;
                    }
                }
            }
            const thresholdValue = (0,_utils__WEBPACK_IMPORTED_MODULE_5__.getThresholdValue)(mode, cellMetadata, notebook.model?.getMetadata(_token__WEBPACK_IMPORTED_MODULE_12__.NOTIFY_METADATA_KEY), notifySettings.defaultThreshold, notifySettings.customTimeout);
            const executionCount = cell.model.executionCount;
            const payload = {
                cell_id: cell.model.id,
                mode,
                emailEnabled: config.email_configured && notifySettings.mail,
                slackEnabled: config.slack_configured && notifySettings.slack,
                successMessage: notifySettings.successMessage,
                failureMessage: notifySettings.failureMessage,
                threshold: thresholdValue !== null && thresholdValue !== undefined
                    ? (0,_utils__WEBPACK_IMPORTED_MODULE_5__.decodeThresholdToSeconds)(thresholdValue)
                    : null,
                notebook_name: notebook.title.label,
                notebookId: notebook.id,
                execution_count: typeof executionCount === 'number' ? executionCount : null,
            };
            const notification = {
                payload,
                timeoutId: null,
                notificationIssued: false,
                notebookId: args.notebook.id,
            };
            if (config.nbmodel_installed) {
                // eslint-disable-next-line @typescript-eslint/no-unused-vars
                const { execution_count: _, ...payloadWithoutExec } = payload;
                try {
                    await (0,_handler__WEBPACK_IMPORTED_MODULE_7__.requestAPI)('notify', {
                        method: 'POST',
                        body: JSON.stringify(payloadWithoutExec),
                    });
                }
                catch (e) {
                    console.error('Failed to notify server:', e);
                }
            }
            cellNotificationMap.set(cell.model.id, notification);
            if (payload.mode === 'custom-timeout') {
                const timeoutInSeconds = payload.threshold;
                if (Number.isFinite(timeoutInSeconds) &&
                    timeoutInSeconds !== null &&
                    timeoutInSeconds !== undefined) {
                    notification.timeoutId = setTimeout(() => {
                        if (!notification.notificationIssued) {
                            void handleNotification(cell.model, true, true).catch(err => {
                                console.error('Error handling notification:', err);
                            });
                        }
                    }, timeoutInSeconds * 1000);
                }
            }
        });
        const trans = (translator ?? _jupyterlab_translation__WEBPACK_IMPORTED_MODULE_2__.nullTranslator).load('jupyterlab-notify-v2-demo');
        app.commands.addCommand(CommandIDs.openNotificationSettings, {
            label: trans.__('Settings..'),
            icon: _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__.settingsIcon,
            execute: () => {
                app.commands.execute('settingeditor:open', {
                    query: 'Execution Notifications',
                });
            },
        });
        app.commands.addCommand(CommandIDs.setNotebookNotificationMode, {
            label: args => {
                if (args.label) {
                    return args.label;
                }
                const modeId = args.modeId;
                return MODES[modeId].label;
            },
            icon: args => MODES[args.modeId].icon,
            execute: args => {
                const modeId = args.modeId;
                const notebook = tracker.currentWidget;
                if (notebook && notebook.model) {
                    const prev = notebook.model.getMetadata(_token__WEBPACK_IMPORTED_MODULE_12__.NOTIFY_METADATA_KEY) || {};
                    notebook.model.setMetadata(_token__WEBPACK_IMPORTED_MODULE_12__.NOTIFY_METADATA_KEY, {
                        ...prev,
                        mode: modeId,
                    });
                }
            },
        });
        app.commands.addCommand(CommandIDs.setNotificationMode, {
            label: args => {
                if (args.label) {
                    return args.label;
                }
                const modeId = args.modeId;
                return MODES[modeId].label;
            },
            icon: args => args.noIcon ? undefined : MODES[args.modeId].icon,
            execute: args => {
                const modeId = args.modeId;
                let threshold = args.threshold; // Stored as string, e.g., "120s"
                const current = tracker.currentWidget;
                if (!current) {
                    console.warn('No notebook selected');
                    return;
                }
                const cell = current.content.activeCell;
                if (!cell) {
                    return;
                }
                // Get existing metadata to preserve thresholds
                const existingMetadata = cell.model.getMetadata(_token__WEBPACK_IMPORTED_MODULE_12__.NOTIFY_METADATA_KEY);
                const metadata = { mode: modeId };
                // Preserve existing thresholds from both modes
                if (existingMetadata?.[_token__WEBPACK_IMPORTED_MODULE_12__.CELL_DEFAULT_THRESHOLD_KEY]) {
                    metadata[_token__WEBPACK_IMPORTED_MODULE_12__.CELL_DEFAULT_THRESHOLD_KEY] =
                        existingMetadata[_token__WEBPACK_IMPORTED_MODULE_12__.CELL_DEFAULT_THRESHOLD_KEY];
                }
                if (existingMetadata?.[_token__WEBPACK_IMPORTED_MODULE_12__.CELL_CUSTOM_TIMEOUT_KEY]) {
                    metadata[_token__WEBPACK_IMPORTED_MODULE_12__.CELL_CUSTOM_TIMEOUT_KEY] =
                        existingMetadata[_token__WEBPACK_IMPORTED_MODULE_12__.CELL_CUSTOM_TIMEOUT_KEY];
                }
                // Override threshold if explicitly provided in args
                if (modeId === 'custom-timeout' || modeId === 'default') {
                    const nbModel = current?.model;
                    if (!threshold) {
                        if (modeId === 'default') {
                            threshold =
                                existingMetadata?.[_token__WEBPACK_IMPORTED_MODULE_12__.CELL_DEFAULT_THRESHOLD_KEY] ??
                                    nbModel?.getMetadata(_token__WEBPACK_IMPORTED_MODULE_12__.NOTIFY_METADATA_KEY)?.[_token__WEBPACK_IMPORTED_MODULE_12__.NOTEBOOK_DEFAULT_THRESHOLD_KEY];
                        }
                        else {
                            threshold =
                                nbModel?.getMetadata(_token__WEBPACK_IMPORTED_MODULE_12__.NOTIFY_METADATA_KEY)?.[_token__WEBPACK_IMPORTED_MODULE_12__.NOTEBOOK_CUSTOM_TIMEOUT_KEY];
                        }
                    }
                    if (threshold) {
                        if (modeId === 'default') {
                            metadata[_token__WEBPACK_IMPORTED_MODULE_12__.CELL_DEFAULT_THRESHOLD_KEY] = threshold;
                        }
                        else {
                            metadata[_token__WEBPACK_IMPORTED_MODULE_12__.CELL_CUSTOM_TIMEOUT_KEY] = threshold;
                        }
                    }
                }
                cell.model.setMetadata(_token__WEBPACK_IMPORTED_MODULE_12__.NOTIFY_METADATA_KEY, metadata);
            },
            isEnabled: () => !!tracker.currentWidget && !!tracker.currentWidget.content.activeCell,
        });
        app.commands.addCommand(CommandIDs.setNotebookCustomTimeout, {
            label: trans.__('Set Custom Timeout'),
            caption: trans.__('Set Notebook Custom Timeout'),
            icon: args => (args.toolbar ? _icons__WEBPACK_IMPORTED_MODULE_6__.bellClockIcon : undefined),
            execute: async () => {
                const current = tracker.currentWidget;
                if (!current || !current.content || !current.model) {
                    return;
                }
                const prev = current.model.getMetadata(_token__WEBPACK_IMPORTED_MODULE_12__.NOTIFY_METADATA_KEY) || {};
                let value = undefined;
                let unit = undefined;
                if (prev[_token__WEBPACK_IMPORTED_MODULE_12__.NOTEBOOK_CUSTOM_TIMEOUT_KEY]) {
                    const parsed = (0,_utils__WEBPACK_IMPORTED_MODULE_5__.parseThreshold)(prev[_token__WEBPACK_IMPORTED_MODULE_12__.NOTEBOOK_CUSTOM_TIMEOUT_KEY]);
                    if (parsed) {
                        value = parsed.value;
                        unit = parsed.unit;
                    }
                }
                const timeoutOptions = {
                    title: 'Set Notebook Custom Timeout',
                    label: 'Custom timeout value with unit:',
                    placeholder: '30',
                    errorMessage: 'Please enter a positive number and select a unit (seconds, minutes, or hours).',
                    defaultValue: value,
                    defaultUnit: unit,
                };
                const { value: input, applyToAll } = await (0,_utils__WEBPACK_IMPORTED_MODULE_5__.promptForTimeout)(timeoutOptions, true, translator ?? undefined);
                if (input) {
                    current.model.setMetadata(_token__WEBPACK_IMPORTED_MODULE_12__.NOTIFY_METADATA_KEY, {
                        ...prev,
                        [_token__WEBPACK_IMPORTED_MODULE_12__.NOTEBOOK_CUSTOM_TIMEOUT_KEY]: input,
                    });
                    // Apply to all cells if requested
                    if (applyToAll && current.content) {
                        current.content.widgets.forEach(cellWidget => {
                            const cellModel = cellWidget.model;
                            const cellMetadata = cellModel.getMetadata(_token__WEBPACK_IMPORTED_MODULE_12__.NOTIFY_METADATA_KEY);
                            // Only update cells that have a customTimeout value
                            if (cellMetadata?.[_token__WEBPACK_IMPORTED_MODULE_12__.CELL_CUSTOM_TIMEOUT_KEY]) {
                                cellModel.setMetadata(_token__WEBPACK_IMPORTED_MODULE_12__.NOTIFY_METADATA_KEY, {
                                    ...cellMetadata,
                                    [_token__WEBPACK_IMPORTED_MODULE_12__.CELL_CUSTOM_TIMEOUT_KEY]: input,
                                });
                            }
                        });
                    }
                }
            },
        });
        app.commands.addCommand(CommandIDs.setNotebookDefaultThreshold, {
            label: trans.__('Set Default Threshold'),
            caption: trans.__('Set Notebook Default Threshold'),
            icon: args => (args.toolbar ? _icons__WEBPACK_IMPORTED_MODULE_6__.bellOutlineIcon : undefined),
            execute: async () => {
                const current = tracker.currentWidget;
                if (!current || !current.content || !current.model) {
                    return;
                }
                const prev = current.model.getMetadata(_token__WEBPACK_IMPORTED_MODULE_12__.NOTIFY_METADATA_KEY) || {};
                let value = undefined;
                let unit = undefined;
                if (prev[_token__WEBPACK_IMPORTED_MODULE_12__.NOTEBOOK_DEFAULT_THRESHOLD_KEY]) {
                    const parsed = (0,_utils__WEBPACK_IMPORTED_MODULE_5__.parseThreshold)(prev[_token__WEBPACK_IMPORTED_MODULE_12__.NOTEBOOK_DEFAULT_THRESHOLD_KEY]);
                    if (parsed) {
                        value = parsed.value;
                        unit = parsed.unit;
                    }
                }
                const thresholdOptions = {
                    title: 'Set Notebook Default Threshold',
                    label: 'Default Threshold value with unit:',
                    placeholder: '30',
                    errorMessage: 'Please enter a positive number and select a unit (seconds, minutes, or hours).',
                    defaultValue: value,
                    defaultUnit: unit,
                };
                const { value: input, applyToAll } = await (0,_utils__WEBPACK_IMPORTED_MODULE_5__.promptForTimeout)(thresholdOptions, true, translator ?? undefined);
                if (input) {
                    const prev = current.model.getMetadata(_token__WEBPACK_IMPORTED_MODULE_12__.NOTIFY_METADATA_KEY) || {};
                    current.model.setMetadata(_token__WEBPACK_IMPORTED_MODULE_12__.NOTIFY_METADATA_KEY, {
                        ...prev,
                        [_token__WEBPACK_IMPORTED_MODULE_12__.NOTEBOOK_DEFAULT_THRESHOLD_KEY]: input,
                    });
                    // Apply to all cells if requested
                    if (applyToAll && current.content) {
                        current.content.widgets.forEach(cellWidget => {
                            const cellModel = cellWidget.model;
                            const cellMetadata = cellModel.getMetadata(_token__WEBPACK_IMPORTED_MODULE_12__.NOTIFY_METADATA_KEY);
                            // Only update cells that have a defaultThreshold value
                            if (cellMetadata?.[_token__WEBPACK_IMPORTED_MODULE_12__.CELL_DEFAULT_THRESHOLD_KEY]) {
                                cellModel.setMetadata(_token__WEBPACK_IMPORTED_MODULE_12__.NOTIFY_METADATA_KEY, {
                                    ...cellMetadata,
                                    [_token__WEBPACK_IMPORTED_MODULE_12__.CELL_DEFAULT_THRESHOLD_KEY]: input,
                                });
                            }
                        });
                    }
                }
            },
        });
        app.commands.addCommand(CommandIDs.setCustomTimeout, {
            caption: 'Set a custom timeout for cell notifications',
            label: trans.__('Custom'),
            execute: async () => {
                const current = tracker.currentWidget;
                let value = undefined;
                let unit = undefined;
                if (current && current.content && current.content.activeCell) {
                    const cell = current.content.activeCell;
                    const prev = cell.model.getMetadata(_token__WEBPACK_IMPORTED_MODULE_12__.NOTIFY_METADATA_KEY) || {};
                    if (prev[_token__WEBPACK_IMPORTED_MODULE_12__.CELL_CUSTOM_TIMEOUT_KEY]) {
                        const parsed = (0,_utils__WEBPACK_IMPORTED_MODULE_5__.parseThreshold)(prev[_token__WEBPACK_IMPORTED_MODULE_12__.CELL_CUSTOM_TIMEOUT_KEY]);
                        if (parsed) {
                            value = parsed.value;
                            unit = parsed.unit;
                        }
                    }
                }
                const { value: input } = await (0,_utils__WEBPACK_IMPORTED_MODULE_5__.promptForTimeout)({
                    title: 'Set Custom Timeout',
                    label: 'Custom timeout value with unit:',
                    placeholder: '30',
                    errorMessage: 'Please enter a positive number and select a unit (seconds, minutes, or hours).',
                    defaultValue: value,
                    defaultUnit: unit,
                }, false, translator ?? undefined);
                if (input) {
                    await app.commands.execute(CommandIDs.setNotificationMode, {
                        modeId: 'custom-timeout',
                        threshold: input,
                    });
                }
            },
        });
        // Menu for Cell Notification modes
        const cellNotifyMenu = new _menuTooltip__WEBPACK_IMPORTED_MODULE_9__.TooltipMenuSvg({ commands: app.commands });
        cellNotifyMenu.addClass('jp-notify-menu');
        cellNotifyMenu.title.label = trans.__('Cell Notification');
        // Menu items will be built dynamically when the menu is opened
        // Menu for Notebook Notification modes
        const nbNotifyMenu = new _menuTooltip__WEBPACK_IMPORTED_MODULE_9__.TooltipMenuSvg({ commands: app.commands });
        nbNotifyMenu.addClass('jp-notify-menu');
        nbNotifyMenu.title.label = trans.__('Notebook Notification');
        // Menu items will be built dynamically when the menu is opened
        // Helper function to update the cell toolbar button on metadata change
        function updateCellToolbarButton(button, cell) {
            const metadata = cell.getMetadata(_token__WEBPACK_IMPORTED_MODULE_12__.NOTIFY_METADATA_KEY);
            const modeId = metadata?.mode ?? notifySettings.defaultMode;
            const newIcon = MODES[modeId].icon;
            // Replace the tooltip
            let tooltip = MODES[modeId].label;
            let threshold = modeId === 'default'
                ? metadata?.[_token__WEBPACK_IMPORTED_MODULE_12__.CELL_DEFAULT_THRESHOLD_KEY]
                : modeId === 'custom-timeout'
                    ? metadata?.[_token__WEBPACK_IMPORTED_MODULE_12__.CELL_CUSTOM_TIMEOUT_KEY]
                    : undefined;
            if (!threshold) {
                const nbMetadata = tracker.currentWidget?.model?.getMetadata(_token__WEBPACK_IMPORTED_MODULE_12__.NOTIFY_METADATA_KEY);
                threshold =
                    modeId === 'default'
                        ? nbMetadata?.[_token__WEBPACK_IMPORTED_MODULE_12__.NOTEBOOK_DEFAULT_THRESHOLD_KEY]
                        : modeId === 'custom-timeout'
                            ? nbMetadata?.[_token__WEBPACK_IMPORTED_MODULE_12__.NOTEBOOK_CUSTOM_TIMEOUT_KEY]
                            : undefined;
            }
            if ((modeId === 'default' || modeId === 'custom-timeout') && threshold) {
                tooltip += ` (${typeof threshold === 'number' ? `${threshold}s` : threshold})`;
            }
            tooltip += '\nClick to change';
            const jpButton = button.node.querySelector('jp-button');
            if (jpButton) {
                jpButton.setAttribute('aria-label', trans.__(tooltip));
                jpButton.setAttribute('title', trans.__(tooltip));
            }
            // Replace the SVG in the button
            const svgElement = button.node.querySelector('svg');
            if (svgElement) {
                svgElement.outerHTML = newIcon.svgstr;
            }
            else {
                // Fallback if no SVG is present
                button.node.innerHTML = newIcon.svgstr;
            }
        }
        // Helper function to update notebook toolbar button on metadata change
        function updateNbToolbarButton(button, notebook) {
            const metadata = notebook.getMetadata(_token__WEBPACK_IMPORTED_MODULE_12__.NOTIFY_METADATA_KEY);
            const modeId = metadata?.mode ?? notifySettings.defaultMode;
            const newIcon = MODES[modeId].icon;
            const labelElement = button.node.querySelector('.jp-ToolbarButtonComponent-label');
            if (labelElement) {
                labelElement.textContent = trans.__(MODES[modeId].label);
                // Insert caret-down icon after label
                const caretSpan = document.createElement('span');
                caretSpan.className = 'jp-notify-toolbar-caret';
                caretSpan.innerHTML = _utils__WEBPACK_IMPORTED_MODULE_5__.caretSVG;
                labelElement.appendChild(caretSpan);
            }
            // Replace the SVG in the button
            const svgElement = button.node.querySelector('svg');
            if (svgElement) {
                svgElement.outerHTML = newIcon.svgstr;
            }
            else {
                // Fallback if no SVG is present
                button.node.innerHTML = newIcon.svgstr;
            }
        }
        // Toolbar factory for per-cell toolbar
        if (toolbarRegistry) {
            toolbarRegistry.addFactory('Notebook', 'notifyType', args => {
                const notebook = args.model;
                if (!notebook) {
                    return new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__.ToolbarButton({});
                }
                const metadata = notebook.getMetadata(_token__WEBPACK_IMPORTED_MODULE_12__.NOTIFY_METADATA_KEY);
                const modeId = metadata?.mode ?? notifySettings.defaultMode;
                const icon = MODES[modeId].icon;
                const labelElement = trans.__(MODES[modeId].label);
                const button = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__.ToolbarButton({
                    label: labelElement,
                    tooltip: trans.__('Set notification settings for this notebook\nAll newly created cells in this notebook will use this type.'),
                    icon,
                    onClick: () => {
                        if (nbNotifyMenu.isVisible) {
                            nbNotifyMenu.close();
                        }
                        else {
                            // Update menu items with current notebook's threshold values
                            const nbMetadata = notebook.getMetadata(_token__WEBPACK_IMPORTED_MODULE_12__.NOTIFY_METADATA_KEY);
                            const defaultThreshold = nbMetadata?.[_token__WEBPACK_IMPORTED_MODULE_12__.NOTEBOOK_DEFAULT_THRESHOLD_KEY];
                            const customThreshold = nbMetadata?.[_token__WEBPACK_IMPORTED_MODULE_12__.NOTEBOOK_CUSTOM_TIMEOUT_KEY];
                            // Clear and rebuild menu with current values
                            nbNotifyMenu.clearItems();
                            Object.entries(MODES).forEach(([modeId, mode]) => {
                                if (modeId === 'custom-timeout') {
                                    const label = customThreshold
                                        ? `${mode.label} (${customThreshold})`
                                        : mode.label;
                                    nbNotifyMenu.addItem({
                                        command: CommandIDs.setNotebookNotificationMode,
                                        args: {
                                            modeId,
                                            label,
                                            tooltip: mode.info,
                                            checked: nbMetadata
                                                ? modeId === nbMetadata?.mode
                                                : false,
                                        },
                                    });
                                }
                                else if (modeId === 'default') {
                                    const label = defaultThreshold
                                        ? `${mode.label} (${defaultThreshold})`
                                        : mode.label;
                                    nbNotifyMenu.addItem({
                                        command: CommandIDs.setNotebookNotificationMode,
                                        args: {
                                            modeId,
                                            label,
                                            tooltip: mode.info,
                                            checked: nbMetadata
                                                ? modeId === nbMetadata?.mode
                                                : false,
                                        },
                                    });
                                }
                                else {
                                    nbNotifyMenu.addItem({
                                        command: CommandIDs.setNotebookNotificationMode,
                                        args: {
                                            modeId,
                                            tooltip: mode.info,
                                            checked: nbMetadata
                                                ? modeId === nbMetadata?.mode
                                                : false,
                                        },
                                    });
                                }
                            });
                            // Add Settings Shortcut
                            nbNotifyMenu.addItem({
                                type: 'separator',
                            });
                            nbNotifyMenu.addItem({
                                type: 'command',
                                command: CommandIDs.setNotebookDefaultThreshold,
                                args: {
                                    tooltip: 'Cells with "default" mode will use this threshold',
                                },
                            });
                            nbNotifyMenu.addItem({
                                type: 'command',
                                command: CommandIDs.setNotebookCustomTimeout,
                                args: {
                                    tooltip: 'Cells with "custom-timeout" mode will use this timeout',
                                },
                            });
                            const rect = button.node.getBoundingClientRect();
                            nbNotifyMenu.open(rect.right, rect.bottom, {
                                horizontalAlignment: 'right',
                            });
                        }
                    },
                });
                button.addClass(_token__WEBPACK_IMPORTED_MODULE_12__.NB_TOOLBAR_NOTIFICATION_CLASS);
                // Connect metadataChanged signal to update the icon dynamically
                notebook.metadataChanged.connect(() => {
                    updateNbToolbarButton(button, notebook);
                });
                return button;
            });
            toolbarRegistry.addFactory('Cell', 'cellNotifyMenu', args => {
                const cell = args.model;
                const metadata = cell.getMetadata(_token__WEBPACK_IMPORTED_MODULE_12__.NOTIFY_METADATA_KEY);
                const modeId = metadata?.mode ?? notifySettings.defaultMode; // Fallback to default if metadata is unset
                let tooltip = MODES[modeId].label;
                let threshold = modeId === 'default'
                    ? metadata?.[_token__WEBPACK_IMPORTED_MODULE_12__.CELL_DEFAULT_THRESHOLD_KEY]
                    : modeId === 'custom-timeout'
                        ? metadata?.[_token__WEBPACK_IMPORTED_MODULE_12__.CELL_CUSTOM_TIMEOUT_KEY]
                        : undefined;
                if (!threshold) {
                    const nbMetadata = tracker.currentWidget?.model?.getMetadata(_token__WEBPACK_IMPORTED_MODULE_12__.NOTIFY_METADATA_KEY);
                    threshold =
                        modeId === 'default'
                            ? nbMetadata?.[_token__WEBPACK_IMPORTED_MODULE_12__.NOTEBOOK_DEFAULT_THRESHOLD_KEY]
                            : modeId === 'custom-timeout'
                                ? nbMetadata?.[_token__WEBPACK_IMPORTED_MODULE_12__.NOTEBOOK_CUSTOM_TIMEOUT_KEY]
                                : undefined;
                }
                if ((modeId === 'default' || modeId === 'custom-timeout') &&
                    threshold) {
                    tooltip += ` (${threshold})`;
                }
                tooltip += '\nClick to change';
                // Create the button with the correct initial icon
                const button = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_3__.ToolbarButton({
                    tooltip: trans.__(tooltip),
                    icon: MODES[modeId].icon,
                    onClick: () => {
                        if (cellNotifyMenu.isVisible) {
                            cellNotifyMenu.close();
                        }
                        else {
                            const currentWidget = tracker.currentWidget;
                            if (!currentWidget || !currentWidget.content.activeCell) {
                                return;
                            }
                            const activeCell = currentWidget.content.activeCell.model;
                            const cellMetadata = activeCell.getMetadata(_token__WEBPACK_IMPORTED_MODULE_12__.NOTIFY_METADATA_KEY);
                            const nbMetadata = currentWidget.model?.getMetadata(_token__WEBPACK_IMPORTED_MODULE_12__.NOTIFY_METADATA_KEY);
                            const cellDefaultThreshold = cellMetadata?.[_token__WEBPACK_IMPORTED_MODULE_12__.CELL_DEFAULT_THRESHOLD_KEY];
                            const cellCustomTimeout = cellMetadata?.[_token__WEBPACK_IMPORTED_MODULE_12__.CELL_CUSTOM_TIMEOUT_KEY];
                            const nbDefaultThreshold = nbMetadata?.[_token__WEBPACK_IMPORTED_MODULE_12__.NOTEBOOK_DEFAULT_THRESHOLD_KEY];
                            const nbCustomTimeout = nbMetadata?.[_token__WEBPACK_IMPORTED_MODULE_12__.NOTEBOOK_CUSTOM_TIMEOUT_KEY];
                            // Clear and rebuild menu with current values
                            cellNotifyMenu.clearItems();
                            Object.entries(MODES).forEach(([modeId, mode]) => {
                                if (modeId === 'custom-timeout') {
                                    const subMenu = new _menuTooltip__WEBPACK_IMPORTED_MODULE_9__.TooltipMenuSvg({
                                        commands: app.commands,
                                    });
                                    subMenu.title.icon = mode.icon;
                                    _token__WEBPACK_IMPORTED_MODULE_12__.TIMEOUT_OPTIONS.forEach(option => {
                                        if (option.value === 'default') {
                                            const label = `${option.label} (${nbCustomTimeout})`;
                                            subMenu.addItem({
                                                command: CommandIDs.setNotificationMode,
                                                args: {
                                                    modeId: 'custom-timeout',
                                                    label,
                                                    noIcon: true,
                                                },
                                            });
                                        }
                                        else if (option.value === 'custom') {
                                            subMenu.addItem({
                                                command: CommandIDs.setCustomTimeout,
                                            });
                                        }
                                        else {
                                            subMenu.addItem({
                                                command: CommandIDs.setNotificationMode,
                                                args: {
                                                    modeId: 'custom-timeout',
                                                    threshold: option.value,
                                                    label: option.label,
                                                    noIcon: true,
                                                },
                                            });
                                        }
                                    });
                                    const displayTimeout = cellCustomTimeout || nbCustomTimeout;
                                    const label = displayTimeout
                                        ? `${mode.label} (${displayTimeout})`
                                        : mode.label;
                                    subMenu.title.label = label;
                                    cellNotifyMenu.addItem({
                                        type: 'submenu',
                                        submenu: subMenu,
                                        args: {
                                            tooltip: mode.info,
                                            checked: cellMetadata
                                                ? modeId === cellMetadata?.mode
                                                : false,
                                        },
                                    });
                                }
                                else if (modeId === 'default') {
                                    const displayThreshold = cellDefaultThreshold || nbDefaultThreshold;
                                    const label = displayThreshold
                                        ? `${mode.label} (${displayThreshold})`
                                        : mode.label;
                                    cellNotifyMenu.addItem({
                                        command: CommandIDs.setNotificationMode,
                                        args: {
                                            modeId,
                                            label,
                                            tooltip: mode.info,
                                            checked: cellMetadata
                                                ? modeId === cellMetadata?.mode
                                                : false,
                                        },
                                    });
                                }
                                else {
                                    cellNotifyMenu.addItem({
                                        command: CommandIDs.setNotificationMode,
                                        args: {
                                            modeId,
                                            tooltip: mode.info,
                                            checked: cellMetadata
                                                ? modeId === cellMetadata?.mode
                                                : false,
                                        },
                                    });
                                }
                            });
                            // Add Settings Shortcut
                            cellNotifyMenu.addItem({
                                type: 'separator',
                            });
                            cellNotifyMenu.addItem({
                                type: 'command',
                                command: CommandIDs.openNotificationSettings,
                                args: {
                                    tooltip: 'Open Notification Settings',
                                },
                            });
                            const rect = button.node.getBoundingClientRect();
                            cellNotifyMenu.open(rect.right, rect.bottom, {
                                horizontalAlignment: 'right',
                            });
                        }
                    },
                });
                // Connect metadataChanged signal to update the icon dynamically
                cell.metadataChanged.connect(() => {
                    updateCellToolbarButton(button, cell);
                });
                return button;
            });
        }
    },
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ }),

/***/ "./lib/menuTooltip.js":
/*!****************************!*\
  !*** ./lib/menuTooltip.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TooltipMenuSvg: () => (/* binding */ TooltipMenuSvg)
/* harmony export */ });
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__);

/**
 * A MenuSvg subclass that supports setting tooltips on menu items
 * via a `tooltip` property in item args.
 */
class TooltipMenuSvg extends _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.MenuSvg {
    onUpdateRequest(msg) {
        super.onUpdateRequest(msg);
        this._applyItemAttributes();
    }
    onAfterAttach(msg) {
        super.onAfterAttach(msg);
        this._applyItemAttributes();
    }
    _applyItemAttributes() {
        const items = this.items;
        this.node
            .querySelectorAll('ul.lm-Menu-content > li.lm-Menu-item')
            .forEach((li, index) => {
            const item = items[index];
            if (!item) {
                return;
            }
            const args = item.args;
            const tooltip = args?.tooltip;
            if (tooltip) {
                li.setAttribute('title', tooltip);
            }
            const checked = args?.checked;
            const iconNode = li.querySelector('.lm-Menu-itemShortcut');
            if (iconNode) {
                if (checked) {
                    iconNode.innerHTML = _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.checkIcon.svgstr;
                    iconNode.childNodes[0].classList.add('jp-notify-check-icon');
                }
                else {
                    iconNode.innerHTML = '';
                }
            }
        });
    }
}


/***/ }),

/***/ "./lib/mime.js":
/*!*********************!*\
  !*** ./lib/mime.js ***!
  \*********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   createRendererFactory: () => (/* binding */ createRendererFactory)
/* harmony export */ });
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_0__);

/**
 * The default mime type for the extension.
 */
const MIME_TYPE = 'application/desktop-notify+json';
const PROCESSED_KEY = 'isProcessed';
// The below can be used to customize notifications
const NOTIFICATION_OPTIONS = {
    icon: '/static/favicons/favicon.ico',
};
/**
 * A widget for rendering desktop-notify.
 */
class OutputWidget extends _lumino_widgets__WEBPACK_IMPORTED_MODULE_0__.Widget {
    constructor(options, notebookTracker, shell) {
        super();
        this._mimeType = options.mimeType;
        this._notebookTracker = notebookTracker;
        this._shell = shell;
    }
    renderModel(model) {
        const mimeData = model.data[this._mimeType];
        const payload = mimeData.payload;
        // If the PROCESSED_KEY is available - do not take any action
        // This is done so that notifications are not repeated on page refresh
        if (mimeData[PROCESSED_KEY]) {
            return Promise.resolve();
        }
        // For first-time users, check for necessary permissions and prompt if needed
        if ((mimeData.type === 'INIT' && Notification.permission === 'default') ||
            Notification.permission !== 'granted') {
            // We do not have any actions to perform upon acquiring permission and so
            // handle only the errors (if any)
            Notification.requestPermission().catch(err => {
                alert(`Encountered error - ${err} while requesting permissions for notebook notifications`);
            });
        }
        if (mimeData.type === 'NOTIFY') {
            // Notify only if there's sufficient permissions and this has not been processed previously
            if (Notification.permission === 'granted' && !mimeData[PROCESSED_KEY]) {
                const body = typeof payload.body === 'string' ? payload.body : '';
                const options = body
                    ? { ...NOTIFICATION_OPTIONS, body }
                    : NOTIFICATION_OPTIONS;
                const notification = new Notification(payload.title, options);
                // Set up click handler
                notification.onclick = event => {
                    event.preventDefault();
                    window.focus();
                    // Navigate to the cell
                    this.navigateToCell(payload.cellId, payload.notebookId);
                    notification.close();
                };
            }
            else {
                this.node.innerHTML = `<div id="${mimeData.id}">Missing permissions - update "Notifications" preferences under browser settings to receive notifications</div>`;
            }
        }
        if (!mimeData[PROCESSED_KEY]) {
            // Add isProcessed property to each notification message so that we can avoid repeating notifications on page reloads
            const updatedModel = JSON.parse(JSON.stringify(model));
            // The model sent by IPython magic via display contains a 'data' property,
            // whereas the model sent by the frontend via MimeModel (after JSON serialization)
            // contains only the private property '_data'.
            const dataKey = 'data' in updatedModel ? 'data' : '_data';
            const updatedMimeData = updatedModel[dataKey][this._mimeType];
            updatedMimeData[PROCESSED_KEY] = true;
            // The below model update is done inside a separate function and added to
            // the event queue - this is done so to avoid re-rendering before the
            // initial render is complete.
            //
            // Without the setTimeout, calling model.setData triggers the callbacks
            // registered on model-updates that re-renders the widget and it again tries
            // to update the model which again causes a re-render and so on.
            setTimeout(() => {
                model.setData(updatedModel);
            }, 0);
        }
        return Promise.resolve();
    }
    async navigateToCell(cellId, notebookId) {
        try {
            const targetNotebook = this.findNotebookById(notebookId);
            if (!targetNotebook) {
                return;
            }
            targetNotebook.activate();
            this._shell.activateById(targetNotebook.id);
            // Ensure notebook is fully activated
            await new Promise(resolve => setTimeout(resolve, 100));
            this.navigateToCellInNotebook(targetNotebook, cellId);
        }
        catch (error) {
            // Silently ignore errors
        }
    }
    findNotebookById(notebookId) {
        // Search through all open notebooks
        let found = null;
        this._notebookTracker.forEach(widget => {
            if (widget.content.id === notebookId) {
                found = widget;
            }
        });
        return found;
    }
    navigateToCellInNotebook(notebook, cellId) {
        const cells = notebook.content.widgets;
        const cellIndex = cells.findIndex((cell) => cell.model.id === cellId);
        if (cellIndex >= 0) {
            notebook.content.activeCellIndex = cellIndex;
            const targetCell = cells[cellIndex];
            notebook.content.scrollToCell(targetCell);
            this.highlightCell(targetCell);
            return true;
        }
        return false;
    }
    highlightCell(cell) {
        const cellNode = cell.node;
        // Add highlight with animation using CSS class
        cellNode.classList.add('jp-notify-highlight');
        cellNode.style.transition = 'background-color 0.5s ease';
        setTimeout(() => {
            cellNode.classList.remove('jp-notify-highlight');
            setTimeout(() => {
                cellNode.style.transition = '';
            }, 300);
        }, 1000);
    }
}
/**
 * Function for creating a mime renderer factory for desktop-notify data.
 */
function createRendererFactory(notebookTracker, shell) {
    return {
        safe: true,
        mimeTypes: [MIME_TYPE],
        createRenderer: options => {
            const widget = new OutputWidget(options, notebookTracker, shell);
            return widget;
        },
    };
}


/***/ }),

/***/ "./lib/timeInput.js":
/*!**************************!*\
  !*** ./lib/timeInput.js ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TimeInputWidget: () => (/* binding */ TimeInputWidget),
/* harmony export */   TimeUnit: () => (/* binding */ TimeUnit)
/* harmony export */ });
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


/**
 * Time unit options for the dropdown
 */
var TimeUnit;
(function (TimeUnit) {
    TimeUnit["SECONDS"] = "seconds";
    TimeUnit["MINUTES"] = "minutes";
    TimeUnit["HOURS"] = "hours";
})(TimeUnit || (TimeUnit = {}));
/**
 * React component for time input with numeric field and unit dropdown
 */
const TimeInput = ({ label = 'Enter time and select units', placeholder = '30', defaultValue, defaultUnit = TimeUnit.SECONDS, initialInputValid = true, checkboxLabel, onValidationChange, onResultChange, }) => {
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
        if (!initialInputValid) {
            onValidationChange?.(false);
        }
    }, []);
    const [value, setValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(initialInputValid ? defaultValue?.toString() || '' : '');
    const [unit, setUnit] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(defaultUnit);
    const [isValid, setIsValid] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(initialInputValid);
    const [isChecked, setIsChecked] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const inputRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    /**
     * Validate the numeric input
     */
    const validateInput = (inputValue) => {
        const numValue = parseFloat(inputValue);
        const valid = !isNaN(numValue) && numValue >= 0;
        setIsValid(valid);
        onValidationChange?.(valid);
        return valid;
    };
    /**
     * Calculate total seconds from current inputs
     */
    const calculateTotalSeconds = (inputValue, selectedUnit) => {
        const numValue = parseFloat(inputValue) || 0;
        switch (selectedUnit) {
            case TimeUnit.MINUTES:
                return numValue * 60;
            case TimeUnit.HOURS:
                return numValue * 3600;
            default:
                return numValue;
        }
    };
    /**
     * Handle input value changes
     */
    const handleValueChange = (newValue) => {
        setValue(newValue);
        const valid = validateInput(newValue);
        if (valid && onResultChange) {
            const numValue = parseFloat(newValue) || 0;
            const totalSeconds = calculateTotalSeconds(newValue, unit);
            onResultChange({
                value: numValue,
                unit,
                totalSeconds,
                isChecked,
            });
        }
    };
    /**
     * Handle unit selection changes
     */
    const handleUnitChange = (newUnit) => {
        setUnit(newUnit);
        if (isValid && onResultChange) {
            const numValue = parseFloat(value) || 0;
            const totalSeconds = calculateTotalSeconds(value, newUnit);
            onResultChange({
                value: numValue,
                unit: newUnit,
                totalSeconds,
                isChecked,
            });
        }
    };
    /**
     * Handle checkbox state changes
     */
    const handleCheckboxChange = (checked) => {
        setIsChecked(checked);
        if (isValid && onResultChange) {
            const numValue = parseFloat(value) || 0;
            const totalSeconds = calculateTotalSeconds(value, unit);
            onResultChange({
                value: numValue,
                unit,
                totalSeconds,
                isChecked: checked,
            });
        }
    };
    /**
     * Handle Enter key press
     */
    const handleKeyDown = (event) => {
        if (event.key === 'Enter' && isValid) {
            // Trigger OK button click when Enter is pressed
            const okButton = document.querySelector('.jp-Dialog-button.jp-mod-accept');
            if (okButton) {
                okButton.click();
            }
        }
    };
    // Focus input on mount
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
        if (inputRef.current) {
            inputRef.current.focus();
            inputRef.current.select();
        }
    }, []);
    return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "jp-notify-time-input-dialog-body" },
        react__WEBPACK_IMPORTED_MODULE_1___default().createElement("label", { className: "jp-notify-time-input-label" }, label),
        react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "jp-notify-time-input-container" },
            react__WEBPACK_IMPORTED_MODULE_1___default().createElement("input", { ref: inputRef, type: "number", className: `jp-notify-time-input-field ${!isValid ? 'jp-mod-error' : ''}`, placeholder: placeholder, min: "0", step: "any", value: value, onChange: e => handleValueChange(e.target.value), onKeyDown: handleKeyDown }),
            react__WEBPACK_IMPORTED_MODULE_1___default().createElement("select", { className: "jp-notify-time-unit-select", value: unit, onChange: e => handleUnitChange(e.target.value) },
                react__WEBPACK_IMPORTED_MODULE_1___default().createElement("option", { value: TimeUnit.SECONDS }, "Seconds (s)"),
                react__WEBPACK_IMPORTED_MODULE_1___default().createElement("option", { value: TimeUnit.MINUTES }, "Minutes (m)"),
                react__WEBPACK_IMPORTED_MODULE_1___default().createElement("option", { value: TimeUnit.HOURS }, "Hours (h)"))),
        !isValid && (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "jp-notify-time-input-error", role: "alert" }, "Please enter a valid positive number")),
        checkboxLabel && (react__WEBPACK_IMPORTED_MODULE_1___default().createElement("div", { className: "jp-notify-checkbox-container" },
            react__WEBPACK_IMPORTED_MODULE_1___default().createElement("label", { className: "jp-notify-checkbox-label" },
                react__WEBPACK_IMPORTED_MODULE_1___default().createElement("input", { type: "checkbox", checked: isChecked, onChange: e => handleCheckboxChange(e.target.checked), className: "jp-notify-checkbox-input" }),
                react__WEBPACK_IMPORTED_MODULE_1___default().createElement("span", null, checkboxLabel))))));
};
/**
 * React Widget wrapper for the TimeInput component
 */
class TimeInputWidget extends _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.ReactWidget {
    constructor(options = {}) {
        super();
        /**
         * Handle validation state changes from the React component
         */
        this._handleValidationChange = (isValid) => {
            this._isValid = isValid;
        };
        /**
         * Handle result changes from the React component
         */
        this._handleResultChange = (result) => {
            this._currentResult = result;
        };
        this._isValid = true;
        this._currentResult = null;
        this._options = options;
        this.addClass('jp-notify-time-input-widget');
    }
    /**
     * Check if the current input is valid
     */
    isValid() {
        return this._isValid;
    }
    /**
     * Get the current result from the inputs
     */
    getResult() {
        if (this._currentResult) {
            return this._currentResult;
        }
        // Fallback to default values
        const defaultValue = this._options.defaultValue || 0;
        const defaultUnit = this._options.defaultUnit || TimeUnit.SECONDS;
        let totalSeconds = defaultValue;
        switch (defaultUnit) {
            case TimeUnit.MINUTES:
                totalSeconds = defaultValue * 60;
                break;
            case TimeUnit.HOURS:
                totalSeconds = defaultValue * 3600;
                break;
            default:
                totalSeconds = defaultValue;
        }
        return {
            value: defaultValue,
            unit: defaultUnit,
            totalSeconds,
            isChecked: false,
        };
    }
    /**
     * Render the React component
     */
    render() {
        return (react__WEBPACK_IMPORTED_MODULE_1___default().createElement(TimeInput, { label: this._options.label, placeholder: this._options.placeholder, defaultValue: this._options.defaultValue, defaultUnit: this._options.defaultUnit, initialInputValid: this._options.initialInputValid, onValidationChange: this._handleValidationChange, onResultChange: this._handleResultChange, checkboxLabel: this._options.checkbox?.label }));
    }
}


/***/ }),

/***/ "./lib/token.js":
/*!**********************!*\
  !*** ./lib/token.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CELL_CUSTOM_TIMEOUT_KEY: () => (/* binding */ CELL_CUSTOM_TIMEOUT_KEY),
/* harmony export */   CELL_DEFAULT_THRESHOLD_KEY: () => (/* binding */ CELL_DEFAULT_THRESHOLD_KEY),
/* harmony export */   ModeIds: () => (/* binding */ ModeIds),
/* harmony export */   NB_TOOLBAR_NOTIFICATION_CLASS: () => (/* binding */ NB_TOOLBAR_NOTIFICATION_CLASS),
/* harmony export */   NOTEBOOK_CUSTOM_TIMEOUT_KEY: () => (/* binding */ NOTEBOOK_CUSTOM_TIMEOUT_KEY),
/* harmony export */   NOTEBOOK_DEFAULT_THRESHOLD_KEY: () => (/* binding */ NOTEBOOK_DEFAULT_THRESHOLD_KEY),
/* harmony export */   NOTEBOOK_FILE_EXTENSION: () => (/* binding */ NOTEBOOK_FILE_EXTENSION),
/* harmony export */   NOTIFY_METADATA_KEY: () => (/* binding */ NOTIFY_METADATA_KEY),
/* harmony export */   TIMEOUT_OPTIONS: () => (/* binding */ TIMEOUT_OPTIONS),
/* harmony export */   TIMEOUT_PATTERN: () => (/* binding */ TIMEOUT_PATTERN)
/* harmony export */ });
/**
 * Notification mode identifiers
 */
const ModeIds = [
    'default',
    'never',
    'on-error',
    'custom-timeout',
];
/**
 * Timeout options for the submenu
 */
const TIMEOUT_OPTIONS = [
    { label: 'default', value: 'default' },
    { label: '1 min', value: '1m' },
    { label: '30 min', value: '30m' },
    { label: 'Custom', value: 'custom' },
];
/**
 * Metadata keys used in notebook and cell metadata
 */
const NOTIFY_METADATA_KEY = 'jupyterlab_notify_v2_demo.notify';
const NOTEBOOK_DEFAULT_THRESHOLD_KEY = 'defaultThreshold';
const NOTEBOOK_CUSTOM_TIMEOUT_KEY = 'customTimeout';
const CELL_DEFAULT_THRESHOLD_KEY = 'defaultThreshold';
const CELL_CUSTOM_TIMEOUT_KEY = 'customTimeout';
const NB_TOOLBAR_NOTIFICATION_CLASS = 'jp-Toolbar-notification-mode';
/**
 * Regular expression for validating timeout input (e.g., '2s', '5m', '1.5h')
 */
const TIMEOUT_PATTERN = /^(\d+(\.\d+)?)([smh])$/;
/**
 * Notebook file extension
 */
const NOTEBOOK_FILE_EXTENSION = '.ipynb';


/***/ }),

/***/ "./lib/utils.js":
/*!**********************!*\
  !*** ./lib/utils.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TimeInputDialog: () => (/* binding */ TimeInputDialog),
/* harmony export */   caretSVG: () => (/* binding */ caretSVG),
/* harmony export */   decodeThresholdToSeconds: () => (/* binding */ decodeThresholdToSeconds),
/* harmony export */   displayConfigWarning: () => (/* binding */ displayConfigWarning),
/* harmony export */   generateNotificationData: () => (/* binding */ generateNotificationData),
/* harmony export */   getThresholdValue: () => (/* binding */ getThresholdValue),
/* harmony export */   parseThreshold: () => (/* binding */ parseThreshold),
/* harmony export */   promptForTimeout: () => (/* binding */ promptForTimeout),
/* harmony export */   stripNotebookExtension: () => (/* binding */ stripNotebookExtension)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _timeInput__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./timeInput */ "./lib/timeInput.js");
/* harmony import */ var _token__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./token */ "./lib/token.js");
/* harmony import */ var _jupyterlab_translation__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @jupyterlab/translation */ "webpack/sharing/consume/default/@jupyterlab/translation");
/* harmony import */ var _jupyterlab_translation__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_translation__WEBPACK_IMPORTED_MODULE_3__);




/**
 * Custom Time Input Dialog class
 */
class TimeInputDialog {
    /**
     * Show a time input dialog and return the result
     *
     * @param options - Configuration options for the dialog
     * @returns Promise that resolves to the time input result or null if cancelled
     */
    static async getText(options = {}) {
        let widget;
        // Keep showing dialog until valid input or user cancels
        let keepPrompting = false;
        do {
            widget = new _timeInput__WEBPACK_IMPORTED_MODULE_1__.TimeInputWidget({
                ...options,
                initialInputValid: !keepPrompting,
            });
            const dialog = new _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.Dialog({
                title: options.title || 'Set Time Input',
                body: widget,
                buttons: [
                    _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.Dialog.cancelButton({ label: options.cancelLabel || 'Cancel' }),
                    _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.Dialog.okButton({ label: options.okLabel || 'OK' }),
                ],
                host: options.host,
                focusNodeSelector: '.jp-notify-time-input-field',
            });
            const result = await dialog.launch();
            // If cancelled, return null
            if (!result.button.accept) {
                return null;
            }
            // If accepted and valid, return result
            if (widget.isValid()) {
                return widget.getResult();
            }
            // If accepted but invalid, show again with error message
            // The validation styling will already be showing the error
            // Set keepPrompting to true to continue the loop
            keepPrompting = true;
        } while (keepPrompting);
        return null;
    }
    /**
     * Convenience method that returns just the total seconds value
     * This maintains compatibility with existing code expecting a simple number
     *
     * @param options - Configuration options for the dialog
     * @returns Promise that resolves to total seconds or null if cancelled
     */
    static async getSeconds(options = {}) {
        const result = await TimeInputDialog.getText(options);
        return result ? result.totalSeconds : null;
    }
    /**
     * Convenience method that formats the result as a string
     *
     * @param options - Configuration options for the dialog
     * @returns Promise that resolves to formatted string like "30 seconds" or null if cancelled
     */
    static async getFormattedText(options = {}) {
        const result = await TimeInputDialog.getText(options);
        if (!result) {
            return null;
        }
        const unitLabels = {
            [_timeInput__WEBPACK_IMPORTED_MODULE_1__.TimeUnit.SECONDS]: result.value === 1 ? 'second' : 'seconds',
            [_timeInput__WEBPACK_IMPORTED_MODULE_1__.TimeUnit.MINUTES]: result.value === 1 ? 'minute' : 'minutes',
            [_timeInput__WEBPACK_IMPORTED_MODULE_1__.TimeUnit.HOURS]: result.value === 1 ? 'hour' : 'hours',
        };
        return `${result.value} ${unitLabels[result.unit]}`;
    }
}
// CARET SVG
const caretSVG = '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="1em" viewBox="0 0 18 18" style="display:inline-block;vertical-align:middle;" data-icon="ui-components:caret-down-empty" data-icon-id="31edaf78-86e6-49d2-9be1-7ae77cfeaa83"><path fill="#616161" d="M5.2 5.9 9 9.7l3.8-3.8L14 7.1l-4.9 5-4.9-5z" class="jp-icon3" shape-rendering="geometricPrecision"></path></svg>';
/**
 * Strips the notebook extension from a path or filename
 * @param pathOrName - The path or name of the notebook file
 * @returns The name without the .ipynb extension
 */
const stripNotebookExtension = (pathOrName) => {
    const notebookName = pathOrName.split('/').pop() ?? pathOrName;
    return notebookName.endsWith(_token__WEBPACK_IMPORTED_MODULE_2__.NOTEBOOK_FILE_EXTENSION)
        ? notebookName.slice(0, -_token__WEBPACK_IMPORTED_MODULE_2__.NOTEBOOK_FILE_EXTENSION.length)
        : notebookName;
};
/**
 * Generates notification body for desktop alerts
 */
const _buildNotificationBody = (state, timingInfo, executionCount, kernelError) => {
    const parts = [];
    if (kernelError) {
        const errorMessage = kernelError.errorValue
            ? kernelError.errorValue.length > 50
                ? kernelError.errorValue.substring(0, 50) + '...'
                : kernelError.errorValue
            : '';
        const cellPrefix = typeof executionCount === 'number' ? `Cell [${executionCount}]: ` : '';
        parts.push(`${cellPrefix}${kernelError.errorName}${errorMessage ? ': ' + errorMessage : ''}`);
    }
    else if (timingInfo) {
        const startTime = state === 'timeout'
            ? timingInfo['iopub.execute_input']
            : timingInfo['shell.execute_reply.started'];
        const endTime = state === 'timeout'
            ? new Date().toISOString()
            : timingInfo['shell.execute_reply'];
        if (typeof startTime === 'string' && typeof endTime === 'string') {
            const durationSeconds = ((new Date(endTime).getTime() - new Date(startTime).getTime()) /
                1000).toFixed(1);
            const cellPrefix = typeof executionCount === 'number' ? `Cell [${executionCount}]: ` : '';
            const action = state === 'timeout' ? 'Timed out after' : 'Completed in';
            const unit = durationSeconds === '1.0' ? 'second' : 'seconds';
            parts.push(`${cellPrefix}${action} ${durationSeconds} ${unit}`);
        }
    }
    else if (executionCount !== null) {
        parts.push(`Cell [${executionCount}]`);
    }
    return parts.join('\n');
};
const generateNotificationData = (state, message, cell_id, notebookName, notebookId, timingInfo, executionCount, kernelError = null) => {
    return {
        type: 'NOTIFY',
        payload: {
            title: `${stripNotebookExtension(notebookName)}: ${message}`,
            body: _buildNotificationBody(state, timingInfo, executionCount, kernelError),
            cellId: cell_id,
            notebookName: stripNotebookExtension(notebookName),
            notebookId,
            ...(typeof executionCount === 'number' ? { executionCount } : {}),
            ...(kernelError ? { kernelError } : {}),
        },
        isProcessed: false,
        id: `notify-${Math.random().toString(36).substring(2)}`,
    };
};
/**
 * Displays configuration warning for unconfigured services
 * @param service - The service name ('Email' or 'Slack')
 * @param configKey - The configuration key
 * @param example - An example configuration value
 */
const displayConfigWarning = (service, configKey, example) => {
    _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.Notification.emit(`${service} Not Configured`, 'error', {
        autoClose: 3000,
        actions: [
            {
                label: 'Help',
                callback: () => (0,_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.showErrorMessage)(`${service} Not Configured`, {
                    message: `Add a ${service.toLowerCase()} configuration to directory listed under the config section of jupyter --paths (e.g., ~/.jupyter/jupyter_notify_config.json) to enable ${service.toLowerCase()} notifications. Example: \n{\n  "${configKey}": "${example}"}"\n}. If you've already configured it, there might be an issue. Please check the terminal for errors and review your setup.`,
                }),
            },
        ],
    });
};
/**
 * Decodes a threshold string or number to seconds
 * @param threshold - The threshold string (e.g., '2s', '5m', '1.5h') or number in seconds
 * @returns The threshold in seconds, or null if invalid
 */
function decodeThresholdToSeconds(threshold) {
    if (typeof threshold === 'number') {
        return threshold;
    }
    const match = threshold.match(_token__WEBPACK_IMPORTED_MODULE_2__.TIMEOUT_PATTERN);
    if (!match) {
        return null;
    }
    const value = parseFloat(match[1]);
    const unit = match[3];
    switch (unit) {
        case 's':
            return value;
        case 'm':
            return value * 60;
        case 'h':
            return value * 3600;
        default:
            return null;
    }
}
/**
 * Parses a threshold string like '2s', '5m', '1.5h' and returns value and TimeUnit
 * @param threshold - The threshold string or number
 * @returns An object with value and unit, or null if invalid
 */
function parseThreshold(threshold) {
    if (!threshold) {
        return null;
    }
    if (typeof threshold === 'number') {
        return { value: threshold, unit: _timeInput__WEBPACK_IMPORTED_MODULE_1__.TimeUnit.SECONDS };
    }
    const match = threshold.match(/^(\d+(\.\d+)?)([smh])$/);
    if (!match) {
        return null;
    }
    const value = parseFloat(match[1]);
    const unitChar = match[3];
    let unit;
    switch (unitChar) {
        case 's':
            unit = _timeInput__WEBPACK_IMPORTED_MODULE_1__.TimeUnit.SECONDS;
            break;
        case 'm':
            unit = _timeInput__WEBPACK_IMPORTED_MODULE_1__.TimeUnit.MINUTES;
            break;
        case 'h':
            unit = _timeInput__WEBPACK_IMPORTED_MODULE_1__.TimeUnit.HOURS;
            break;
        default:
            return null;
    }
    return { value, unit };
}
/**
 * Retrieves the appropriate threshold value from cell, notebook, or settings
 */
function getThresholdValue(mode, cellMetadata, notebookMetadata, settingsDefaultThreshold, settingsCustomTimeout) {
    if (mode === 'default') {
        return (cellMetadata?.[_token__WEBPACK_IMPORTED_MODULE_2__.CELL_DEFAULT_THRESHOLD_KEY] ??
            notebookMetadata?.[_token__WEBPACK_IMPORTED_MODULE_2__.NOTEBOOK_DEFAULT_THRESHOLD_KEY] ??
            settingsDefaultThreshold);
    }
    if (mode === 'custom-timeout') {
        return (cellMetadata?.[_token__WEBPACK_IMPORTED_MODULE_2__.CELL_CUSTOM_TIMEOUT_KEY] ??
            notebookMetadata?.[_token__WEBPACK_IMPORTED_MODULE_2__.NOTEBOOK_CUSTOM_TIMEOUT_KEY] ??
            settingsCustomTimeout);
    }
    return settingsDefaultThreshold;
}
/**
 * Helper to prompt for a timeout/threshold value and validate it
 */
async function promptForTimeout(options, showCheckbox = false, translator) {
    translator = translator || _jupyterlab_translation__WEBPACK_IMPORTED_MODULE_3__.nullTranslator;
    const trans = translator.load('jupyterlab');
    const timeResult = await TimeInputDialog.getText({
        title: options.title,
        label: options.label,
        placeholder: options.placeholder,
        defaultValue: options.defaultValue,
        defaultUnit: options.defaultUnit,
        ...(showCheckbox && {
            checkbox: {
                label: trans.__('Apply to all cells in this notebook'),
            },
        }),
    });
    if (!timeResult) {
        return { value: null, applyToAll: false };
    }
    const rawInput = String(timeResult.value) + (timeResult.unit ? timeResult.unit[0] : 's');
    const lastChar = rawInput.slice(-1);
    const input = rawInput === ''
        ? ''
        : ['s', 'm', 'h'].includes(lastChar)
            ? rawInput
            : rawInput + 's';
    if (!input || !_token__WEBPACK_IMPORTED_MODULE_2__.TIMEOUT_PATTERN.test(input)) {
        return { value: null, applyToAll: false };
    }
    const applyToAll = (showCheckbox ? timeResult.isChecked : false) ?? false;
    return { value: input, applyToAll };
}


/***/ }),

/***/ "./style/icons/bell-alert.svg":
/*!************************************!*\
  !*** ./style/icons/bell-alert.svg ***!
  \************************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" data-icon=\"notify:bell-alert\" width=\"16\" viewBox=\"0 0 24 24\"><g class=\"jp-icon3\" fill=\"#616161\"><path d=\"M12 2A2 2 0 0 0 10 4A2 2 0 0 0 10 4.29C7.12 5.14 5 7.82 5 11V17L3 19V20H21V19L19 17V11C19 7.82 16.88 5.14 14 4.29A2 2 0 0 0 14 4A2 2 0 0 0 12 2M12 6A5 5 0 0 1 17 11V18H7V11A5 5 0 0 1 12 6M21 7V13H23V7H21M21 15V17H23V15H21M10 21A2 2 0 0 0 12 23A2 2 0 0 0 14 21H10Z\" /></g></svg>\n";

/***/ }),

/***/ "./style/icons/bell-clock.svg":
/*!************************************!*\
  !*** ./style/icons/bell-clock.svg ***!
  \************************************/
/***/ ((module) => {

module.exports = "<svg width=\"16\" data-icon=\"notify:bell-clock\" version=\"1.1\" viewBox=\"0 0 24 24\" xmlns=\"http://www.w3.org/2000/svg\">\n <g class=\"jp-icon3\" transform=\"matrix(1.0188 0 0 1.0188 2.9556 9.1817)\" fill=\"#616161\">\n  <path d=\"m8.6217-7.7328c-1.1 0-1.9986 0.8986-1.9986 1.9986v0.29044c-2.88 0.85-5.0008 3.5318-5.0008 6.7118v5.9987l-1.9986 1.9986v1.0007h8.5005c-0.2617-0.63754-0.42196-1.3112-0.47161-1.9986h-4.0288v-6.9994c0-2.7614 2.2365-5.0008 4.9979-5.0008 2.7614-2e-7 5.0008 2.2394 5.0008 5.0008 0.1666-0.00641 0.33376-0.00641 0.50037 0 0.5053 0.00149 1.0098 0.060192 1.5011 0.17829v-0.17829c0-3.18-2.1208-5.8618-5.0008-6.7118v-0.29044c0-1.1-0.89147-1.9986-2.0015-1.9986zm4.5666 9.9067c-2.7294-8.69e-5 -4.9405 2.2139-4.9404 4.9433-8.69e-5 2.7294 2.211 4.9405 4.9404 4.9404 2.7294 8.7e-5 4.9434-2.211 4.9433-4.9404 8.7e-5 -2.7294-2.2139-4.9434-4.9433-4.9433zm0 1.2509c2.0387-3.651e-4 3.6927 1.6536 3.6924 3.6924 3.65e-4 2.0387-1.6536 3.6899-3.6924 3.6895-2.0387 3.65e-4 -3.6899-1.6508-3.6895-3.6895-3.65e-4 -2.0387 1.6508-3.6927 3.6895-3.6924zm-0.42272 1.0726c-0.25204 0-0.45436 0.20232-0.45436 0.45436v2.4702c0 0.24362 0.19107 0.44142 0.43135 0.45436 0.0077 0.00108 0.01521-6.478e-4 0.02301 0 0.0127 0.00108 0.02439 0.00288 0.03738 0.00288h1.4091c0.25204 0 0.54063-0.20232 0.54063-0.45436 0-0.25204-0.21957-0.45436-0.47161-0.45436h-1.0611v-2.0187c0-0.25204-0.20232-0.45436-0.45436-0.45436zm-6.1425 6.7693c0 1.11 0.8986 1.9986 1.9986 1.9986 0.5 0 0.97144-0.18749 1.3314-0.49749-0.50757-0.4305-0.94582-0.9375-1.2998-1.5011z\"/>\n </g>\n</svg>\n";

/***/ }),

/***/ "./style/icons/bell-filled.svg":
/*!*************************************!*\
  !*** ./style/icons/bell-filled.svg ***!
  \*************************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" viewBox=\"0 0 24 24\"><g class=\"jp-icon3\" fill=\"#616161\"><path d=\"M21,19V20H3V19L5,17V11C5,7.9 7.03,5.17 10,4.29C10,4.19 10,4.1 10,4A2,2 0 0,1 12,2A2,2 0 0,1 14,4C14,4.1 14,4.19 14,4.29C16.97,5.17 19,7.9 19,11V17L21,19M14,21A2,2 0 0,1 12,23A2,2 0 0,1 10,21\" /></g></svg>\n";

/***/ }),

/***/ "./style/icons/bell-off.svg":
/*!**********************************!*\
  !*** ./style/icons/bell-off.svg ***!
  \**********************************/
/***/ ((module) => {

module.exports = "<svg width=\"16\" data-icon=\"notify:bell-off\" version=\"1.1\" viewBox=\"0 0 24 24\" xmlns=\"http://www.w3.org/2000/svg\">\n <g class=\"jp-icon3\" transform=\"matrix(1.0469 0 0 1.0469 2.742 9.1036)\" fill=\"#616161\">\n  <path d=\"m8.6231-7.7332c-1.1 0-2 0.89996-2 2v0.28997c-2.88 0.85-5 3.53-5 6.71v6l-2 2.0001v0.99998h8.4999c-0.2617-0.63754-0.42032-1.3127-0.46997-2.0001h-4.0301v-7c0-2.7614 2.2386-5 5-5 2.7614-2e-7 5 2.2386 5 5 0.1666-0.00641 0.33338-0.00641 0.49999 0 0.5053 0.00149 1.0087 0.061905 1.5 0.18001v-0.18001c0-3.18-2.12-5.86-5-6.71v-0.28997c0-1.1-0.88996-2-2-2zm4.4165 9.6412c-2.7748-5.59e-5 -5.0241 2.2493-5.024 5.024-1.084e-4 2.7748 2.2492 5.0242 5.024 5.0241 2.7747 5.3e-5 5.0242-2.2494 5.0241-5.0241 1.08e-4 -2.7747-2.2494-5.0241-5.0241-5.024zm0 1.2715c2.0726-4.303e-4 3.7529 1.6799 3.7525 3.7525 1.53e-4 0.73305-0.21004 1.4171-0.57337 1.995l-5.1741-5.1741c0.5779-0.36336 1.2619-0.57349 1.995-0.57337zm-3.0642 1.5856 5.2313 5.2313c-0.6121 0.43363-1.3598 0.68846-2.1671 0.68833-2.0726 4.3e-4 -3.7529-1.68-3.7525-3.7527-1.508e-4 -0.80723 0.25471-1.5549 0.68833-2.167zm-3.3523 6.5017c0 1.11 0.89996 2 2 2 0.5 0 0.96997-0.18999 1.33-0.49999-0.50757-0.4305-0.94597-0.93636-1.3-1.5z\"/>\n </g>\n</svg>\n";

/***/ }),

/***/ "./style/icons/bell-outline.svg":
/*!**************************************!*\
  !*** ./style/icons/bell-outline.svg ***!
  \**************************************/
/***/ ((module) => {

module.exports = "<svg xmlns=\"http://www.w3.org/2000/svg\" data-icon=\"notify:bell-outline\" width=\"16\" viewBox=\"0 0 24 24\"><g class=\"jp-icon3\" fill=\"#616161\"><path d=\"M10 21H14C14 22.1 13.1 23 12 23S10 22.1 10 21M21 19V20H3V19L5 17V11C5 7.9 7 5.2 10 4.3V4C10 2.9 10.9 2 12 2S14 2.9 14 4V4.3C17 5.2 19 7.9 19 11V17L21 19M17 11C17 8.2 14.8 6 12 6S7 8.2 7 11V18H17V11Z\" /></g></svg>\n";

/***/ })

}]);
//# sourceMappingURL=lib_index_js.2bd85eaaba5f26576b5d.js.map