## [2.0.2](https://github.com/deshaw/jupyterlab-notify-v2-demo/compare/v2.0.1...v2.0.2b0) (UNRELEASED)

## Changed

- Added options to configure the SMTP client to use

## [2.0.1](https://github.com/deshaw/jupyterlab-notify-v2-demo/compare/v2.0.1...v2.0.2b0) (2024-01-16)

## Fixed

- Fix the pre run cell hook to be compatible with ipython 8.18.x+

## [2.0.0](https://github.com/deshaw/jupyterlab-notify-v2-demo/compare/v1.0.1...v2.0.1) (2023-05-17)

## Changed

- Upgrade to jupyterlab4

## [1.0.0](https://github.com/deshaw/jupyterlab-notify-v2-demo/compare/v1.0.1...v2.0.1) (2021-07-12)

### Added

- Public release

The project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html) and
this CHANGELOG follows the [Keep a Changelog](https://keepachangelog.com/en/1.0.0/) standard.
