# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Copyright (C) 2025  HauhauCS <hauhaut901@gmail.com>

import gc
import getpass
import logging
import os
import re
import sys
from dataclasses import dataclass
from importlib.metadata import version as pkg_version
from math import ceil
from pathlib import Path
from typing import Any, TypeVar

import questionary
import torch
from accelerate.utils import (
    is_mlu_available,
    is_musa_available,
    is_sdaa_available,
    is_xpu_available,
)
from datasets import (
    DatasetDict,
    load_dataset,
    load_from_disk,
)
from datasets.config import DATASET_STATE_JSON_FILENAME
from datasets.download.download_manager import DownloadMode
from datasets.utils.info_utils import VerificationMode
from optuna import Trial
from questionary import Choice, Style
from rich.console import Console
from rich.progress import track as rich_track

from .config import DatasetSpecification, Settings

_GIB = 1 << 30
_output = Console(highlight=False)
_dashboard_active = False


def set_dashboard_active(active: bool) -> None:
    global _dashboard_active
    _dashboard_active = active


def print(*args, **kwargs) -> None:
    if _dashboard_active:
        return
    _output.print(*args, **kwargs)


def track(iterable, description: str = "", **kwargs):
    return iterable if _dashboard_active else rich_track(iterable, description=description, **kwargs)


def _detect_notebook_env() -> bool:
    try:
        return "ipykernel" in sys.modules or bool(os.environ.get("COLAB_GPU"))
    except Exception:
        return False


is_notebook = _detect_notebook_env


def _notebook_numbered_menu(msg: str, options: list[Any]) -> Any:
    print(f"\n{msg}")
    values = []
    for i, opt in enumerate(options, 1):
        lbl = opt.title if isinstance(opt, Choice) else str(opt)
        values.append(opt.value if isinstance(opt, Choice) else opt)
        print(f"  {i}) {lbl}")
    while True:
        try:
            pick = int(input("> ")) - 1
            if 0 <= pick < len(values):
                return values[pick]
        except ValueError:
            pass
        print(f"  enter 1-{len(values)}")


def prompt_select(message: str, choices: list[Any]) -> Any:
    if _detect_notebook_env():
        return _notebook_numbered_menu(message, choices)
    result = questionary.select(message, choices=choices, style=Style([("highlighted", "reverse")])).ask()
    if result is None:
        raise KeyboardInterrupt
    return result


def prompt_text(
    message: str, default: str = "", qmark: str = "?", unsafe: bool = False,
) -> str:
    if _detect_notebook_env():
        print()
        suffix = f" [{default}]" if default else ""
        answer = input(f"{message}{suffix}: ")
        return answer or default
    q = questionary.text(message, default=default, qmark=qmark)
    result = q.unsafe_ask() if unsafe else q.ask()
    if result is None:
        raise KeyboardInterrupt
    return result


def prompt_path(message: str) -> str:
    if _detect_notebook_env():
        return prompt_text(message)
    result = questionary.path(message, only_directories=True).ask()
    if result is None:
        raise KeyboardInterrupt
    return result


def prompt_password(message: str) -> str:
    if _detect_notebook_env():
        print()
        return getpass.getpass(prompt=message)
    result = questionary.password(message).ask()
    if result is None:
        raise KeyboardInterrupt
    return result


def format_duration(seconds: float) -> str:
    total = round(seconds)
    h, leftover = divmod(total, 3600)
    m, s = divmod(leftover, 60)
    if h:
        return f"{h}h {m}m"
    return f"{m}m {s}s" if m else f"{s}s"


@dataclass
class Prompt:
    system: str
    user: str


def _parse_split_range(spec: str, total: int) -> range:
    """Parse 'train[:400]', 'test[100:200]', or 'train' into a range."""
    m = re.search(r'\[(\d*):(\d*)\]', spec)
    if not m:
        return range(0, total)
    start = int(m.group(1)) if m.group(1) else 0
    end = int(m.group(2)) if m.group(2) else total
    return range(start, min(end, total))


def _resolve_dataset(loc: str, split_spec: str):
    """Load a HF dataset from disk or hub, handling save_to_disk format."""
    if not os.path.isdir(loc):
        return load_dataset(loc, split=split_spec)
    state_path = Path(loc) / DATASET_STATE_JSON_FILENAME
    if not state_path.exists():
        return load_dataset(
            loc, split=split_spec,
            verification_mode=VerificationMode.NO_CHECKS, download_mode=DownloadMode.FORCE_REDOWNLOAD,
        )
    ds = load_from_disk(loc)
    assert not isinstance(ds, DatasetDict), "DatasetDict not accepted; specify a single split directory"
    return ds.select(_parse_split_range(split_spec, len(ds)))


def load_prompts(
    settings: Settings, specification: DatasetSpecification,
) -> list[Prompt]:
    ds = _resolve_dataset(specification.source, specification.split)

    cols = ds.column_names
    assert cols is not None
    if specification.text_column not in cols:
        raise ValueError(f"Column '{specification.text_column}' not found. Available: {cols}")
    raw = list(ds[specification.text_column])

    pfx, sfx = specification.prefix, specification.suffix
    if pfx:
        raw = [f"{pfx} {p}" for p in raw]
    if sfx:
        raw = [f"{p} {sfx}" for p in raw]

    sys_msg = specification.system_prompt if specification.system_prompt is not None else settings.system_prompt
    return [Prompt(system=sys_msg, user=p) for p in raw]


T = TypeVar("T")


def batchify(items: list[T], batch_size: int) -> list[list[T]]:
    assert batch_size > 0, "batch_size must be positive"
    num_chunks = ceil(len(items) / batch_size)
    return [items[c * batch_size : (c + 1) * batch_size] for c in range(num_chunks)]


_CACHE_BACKENDS: list[tuple] = [
    (torch.cuda.is_available, torch.cuda.empty_cache),
    (is_xpu_available, lambda: torch.xpu.empty_cache()),
    (is_mlu_available, lambda: torch.mlu.empty_cache()),  # ty:ignore[unresolved-attribute]
    (is_sdaa_available, lambda: torch.sdaa.empty_cache()),  # ty:ignore[unresolved-attribute]
    (is_musa_available, lambda: torch.musa.empty_cache()),  # ty:ignore[unresolved-attribute]
    (torch.backends.mps.is_available, torch.mps.empty_cache),
]


def empty_cache():
    # GC must bracket the cache clear to avoid OOM on fragmented heaps.
    # Two gc passes break cyclic refs; cache clear AFTER each gc pass ensures
    # blocks freed by the second gc are also returned to the driver (prevents
    # fragmentation OOM on reload after merge/export).
    gc.collect()
    for is_avail, do_clear in _CACHE_BACKENDS:
        if is_avail():
            do_clear()
            break
    gc.collect()
    for is_avail, do_clear in _CACHE_BACKENDS:
        if is_avail():
            do_clear()
            break


def disable_broken_p2p(force: bool = False) -> list[tuple[int, int]]:
    """Detect and patch broken BF16 P2P transfers between same-generation GPU pairs.

    Blackwell GPUs have a driver bug where BF16 P2P DMA under concurrent streams
    produces corrupted data. Patches both accelerate's send_to_device AND
    torch.Tensor.to() to CPU-stage transfers between affected pairs.
    Returns list of (src, dst) pairs that were patched.
    """
    if not torch.cuda.is_available() or torch.cuda.device_count() < 2:
        return []

    # Find GPU pairs with P2P capability (potential corruption targets)
    p2p_pairs: set[frozenset[int]] = set()
    n = torch.cuda.device_count()
    for src in range(n):
        for dst in range(n):
            if src != dst and torch.cuda.can_device_access_peer(src, dst):
                p2p_pairs.add(frozenset({src, dst}))

    if not p2p_pairs:
        return []

    from .style import WARN

    if force:
        broken_pairs = set(p2p_pairs)
        print(f"  {WARN} P2P probe: forcing CPU staging for all {len(broken_pairs)} pairs (--force-p2p-cpu-staging)")
    else:
        # BF16 transfer test on each P2P pair under concurrent streams (256KB buffer, 3 rounds)
        broken_pairs: set[frozenset[int]] = set()
        for pair in p2p_pairs:
            src, dst = sorted(pair)
            try:
                for _ in range(3):
                    streams = [torch.cuda.Stream(device=src) for _ in range(4)]
                    results = []
                    t = torch.arange(131072, dtype=torch.bfloat16, device=f"cuda:{src}")
                    for s in streams:
                        with torch.cuda.stream(s):
                            results.append(t.to(f"cuda:{dst}"))
                    for s in streams:
                        s.synchronize()
                    if any(not torch.allclose(r.cpu(), t.cpu()) for r in results):
                        broken_pairs.add(pair)
                        break
            except (RuntimeError, OSError) as exc:
                logging.debug("P2P probe failed for %s: %s", pair, exc)
                broken_pairs.add(pair)
        print(f"  P2P: probed {len(p2p_pairs)} pairs, {len(broken_pairs)} broken")

    if not broken_pairs:
        return []

    # === Patch 1: accelerate's send_to_device ===
    import accelerate.utils.operations as _aops
    import accelerate.hooks as _ahooks
    _orig_send = _aops.send_to_device

    def _safe_send(tensor, device, non_blocking=False, skip_keys=None):
        if isinstance(tensor, torch.Tensor) and tensor.is_cuda:
            if isinstance(device, int):
                tgt = torch.device("cuda", device)
            elif isinstance(device, str):
                tgt = torch.device(device)
            else:
                tgt = device
            if getattr(tgt, "type", None) == "cuda" and tgt.index is not None:
                if tensor.device.index != tgt.index:
                    if frozenset({tensor.device.index, tgt.index}) in broken_pairs:
                        return tensor.cpu().to(device)
        return _orig_send(tensor, device, non_blocking=non_blocking, skip_keys=skip_keys)

    _aops.send_to_device = _safe_send
    _ahooks.send_to_device = _safe_send

    # === Patch 2: torch.Tensor.to() — catches ALL cross-GPU transfers ===
    _orig_to = torch.Tensor.to

    def _parse_to_device(args, kwargs):
        """Extract target device from .to() arguments (multiple calling conventions)."""
        if "device" in kwargs:
            d = kwargs["device"]
            if isinstance(d, int):
                return torch.device("cuda", d)
            if isinstance(d, str):
                return torch.device(d)
            return d
        if args:
            a0 = args[0]
            if isinstance(a0, torch.device):
                return a0
            if isinstance(a0, str):
                try:
                    return torch.device(a0)
                except (ValueError, RuntimeError):
                    return None
            if isinstance(a0, int):
                return torch.device("cuda", a0)
            # .to(tensor) — copy device from another tensor
            if isinstance(a0, torch.Tensor) and a0.is_cuda:
                return a0.device
        return None

    def _patched_to(self, *args, **kwargs):
        if self.is_cuda:
            tgt = _parse_to_device(args, kwargs)
            if (tgt is not None
                    and getattr(tgt, "type", None) == "cuda"
                    and tgt.index is not None
                    and self.device.index != tgt.index
                    and frozenset({self.device.index, tgt.index}) in broken_pairs):
                return _orig_to(_orig_to(self, "cpu"), *args, **kwargs)
        return _orig_to(self, *args, **kwargs)

    torch.Tensor.to = _patched_to

    disabled = sorted((min(p), max(p)) for p in broken_pairs)
    pairs = ", ".join(f"cuda:{s}↔cuda:{d}" for s, d in disabled)
    print(f"  {WARN} Patched P2P for: {pairs} (BF16 DMA bug workaround)")
    return disabled


def get_gpu_info() -> list[dict]:
    """Return per-device CUDA stats: index, name, memory_gb, memory_free_gb, used_gb, total_gb, pct."""
    if not torch.cuda.is_available():
        return []
    result = []
    for dev_idx in range(torch.cuda.device_count()):
        dev_props = torch.cuda.get_device_properties(dev_idx)
        free_bytes, total_bytes = torch.cuda.mem_get_info(dev_idx)
        alloc_bytes = torch.cuda.memory_allocated(dev_idx)
        result.append({
            "index": dev_idx,
            "name": dev_props.name,
            "memory_gb": round(total_bytes / _GIB, 2),
            "memory_free_gb": round(free_bytes / _GIB, 2),
            "used_gb": round(alloc_bytes / _GIB, 2),
            "total_gb": round(total_bytes / _GIB, 2),
            "pct": int(100 * alloc_bytes / total_bytes) if total_bytes else 0,
        })
    return result


def log_gpu_utilization():
    for g in get_gpu_info():
        print(f"GPU {g['index']} ({g['name']}): {g['used_gb']:.1f} / {g['total_gb']:.1f} GB ({g['pct']}%)")


def get_trial_parameters(trial: Trial) -> dict[str, str]:
    out: dict[str, str] = {}

    dir_mode = trial.user_attrs.get("blend_mode", "mean")
    if dir_mode != "mean":
        out["blend_mode"] = dir_mode

    pos_w = trial.user_attrs.get("position_weights")
    if pos_w:
        out["position_weights"] = ", ".join(f"{k}:{v:.2f}" for k, v in pos_w.items())

    head_frac = trial.user_attrs.get("head_ablation_fraction")
    if head_frac is not None:
        mask = trial.user_attrs.get("head_mask", [])
        n_ablated = sum(1 for h in mask if h > 0.5)
        out["head_ablation"] = f"{n_ablated}/{len(mask)} heads ({head_frac:.1%})"

    di = trial.user_attrs.get("layer_focus")
    out["layer_focus"] = "per layer" if di is None else f"{di:.2f}"

    for comp, comp_params in trial.user_attrs.get("parameters", {}).items():
        for pname, pval in comp_params.items():
            out[f"{comp}/{pname}"] = f"{pval:.2f}"

    return out


def get_readme_intro(
    settings: Settings, trial: Trial, base_refusals: int, harmful_prompts: list[Prompt],
) -> str:
    hf_url = f"https://huggingface.co/{settings.model}"
    hf_link = f"[{settings.model}]({hf_url})"
    ver = pkg_version("reaper-abliteration")
    ua = trial.user_attrs
    total_prompts = len(harmful_prompts)

    heading = (
        f"# {hf_link} (abliterated)\n\n"
        f"Censorship removed with [Reaper Abliteration](https://github.com/hauhaut/reaper-abliteration) v{ver}."
    )
    param_rows = "\n".join(f"| **{k}** | {v} |" for k, v in get_trial_parameters(trial).items())
    params_md = (
        "## Trial configuration\n\n"
        "| Parameter | Value |\n"
        "| :-------- | :---: |\n"
        + param_rows
    )
    perf_md = (
        "## Evaluation metrics\n\n"
        f"| Metric | This model | Original model ({hf_link}) |\n"
        "| :----- | :--------: | :---------------------------: |\n"
        f"| **KL div** | {ua['kl_divergence']:.4f} | 0 *(baseline)* |\n"
        f"| **Blocked prompts** | {ua['refusals']}/{total_prompts} | {base_refusals}/{total_prompts} |"
    )

    return f"{heading}\n\n{params_md}\n\n{perf_md}\n\n-----\n\n"


def calculate_device_map(
    gpus: list[dict],
    gpu_devices: list[int] | None = None,
    strategy: str = "auto",
) -> tuple[str | dict, dict[str, str] | None]:
    """Build (device_map, max_memory) for accelerate model loading."""
    if not gpus:
        return "auto", None

    if gpu_devices is not None:
        gpus = [g for g in gpus if g["index"] in gpu_devices]

    if len(gpus) <= 1 or strategy == "sequential":
        return "auto", None

    # Multi-GPU: reserve 2 GiB per device for runtime overhead
    mem_budget = {
        str(g["index"]): f"{max(1, int(g['memory_gb'] - 2))}GB"
        for g in gpus
    }
    return "auto", mem_budget
