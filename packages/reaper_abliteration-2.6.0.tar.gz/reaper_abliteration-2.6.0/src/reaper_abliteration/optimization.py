# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Copyright (C) 2025  HauhauCS <hauhaut901@gmail.com>

import sys
import time
from dataclasses import asdict

import torch
import torch.nn.functional as F
from optuna import Trial, TrialPruned
from optuna.trial import TrialState

from .dashboard import Dashboard
from .model import LayerEnvelope
from .parallel_model import ParallelModel
from .seed_management import load_seed_params, update_best_seeds
from .style import OK, FAIL, WARN, WORK, ARROW, phase, step, val, dim
from .utils import (
    empty_cache,
    format_duration,
    get_trial_parameters,
    print,
    set_dashboard_active,
)


def _resolve_directions(
    trial: Trial,
    svd_directions,
    pca_directions,
    mean_direction,
    blend_modes,
    settings,
    positions,
    good_residuals_multipos,
    bad_residuals_multipos,
):
    """Resolve trial_directions from blend mode, multi-position weighting, etc."""
    # Handle multi-position weighting if enabled
    weighted_direction = None
    if good_residuals_multipos is not None:
        raw_weights = []
        for i, pos in enumerate(positions):
            w = trial.suggest_float(f"position_weight_{pos}", 0.1, 1.0)
            raw_weights.append(w)
        total = sum(raw_weights)
        pos_weights = torch.tensor([w / total for w in raw_weights], device=good_residuals_multipos.device)
        trial.set_user_attr("position_weights", {str(p): w for p, w in zip(positions, raw_weights)})

        weighted_good = torch.einsum('p,npld->nld', pos_weights, good_residuals_multipos)
        weighted_bad = torch.einsum('p,npld->nld', pos_weights, bad_residuals_multipos)

        weighted_direction = F.normalize(
            weighted_bad.mean(dim=0) - weighted_good.mean(dim=0),
            p=2,
            dim=1,
        )

    # Select appropriate refusal directions based on mode
    if svd_directions is not None:
        trial_directions = svd_directions
        rank_k_mode = "pca_rank_k" if pca_directions is not None else "svd"
        trial.set_user_attr("blend_mode", rank_k_mode)
    else:
        active_modes = list(blend_modes)
        if settings.combine_directions and pca_directions is not None and "combined" not in active_modes:
            active_modes.append("combined")
        blend_mode = trial.suggest_categorical("blend_mode", active_modes)
        trial.set_user_attr("blend_mode", blend_mode)

        # Always suggest dir_weight params when combine_directions is on to keep
        # the search space static — dynamic spaces break multivariate TPE.
        if settings.combine_directions and pca_directions is not None:
            w_mean = trial.suggest_float("dir_weight_mean", 0.0, 1.0)
            pca_weights = [
                trial.suggest_float(f"dir_weight_pca_{i+1}", 0.0, 1.0)
                for i in range(pca_directions.shape[0])
            ]
        else:
            w_mean, pca_weights = None, None

        if blend_mode == "combined" and pca_directions is not None:
            dir_weights = {"mean": w_mean}
            trial_directions = w_mean * (weighted_direction if weighted_direction is not None else mean_direction)
            for i, w in enumerate(pca_weights):
                trial_directions = trial_directions + w * pca_directions[i]
                dir_weights[f"pca_{i+1}"] = w
            trial_directions = F.normalize(trial_directions, p=2, dim=1)
            trial.set_user_attr("direction_weights", dir_weights)
        elif weighted_direction is not None and blend_mode == "mean":
            trial_directions = weighted_direction
        elif blend_mode == "mean":
            trial_directions = mean_direction
        else:
            if pca_directions is None:
                trial_directions = mean_direction
            else:
                pca_idx = int(blend_mode.split("_")[1]) - 1
                trial_directions = pca_directions[pca_idx]

    return trial_directions


def _introspect_components(model):
    """One-time model introspection: col-mode, frequency, hook-only sets."""
    col_mode_comps: set[str] = set()
    cfg = model.model.config
    hidden_dim = getattr(cfg, "hidden_size", None) or getattr(cfg, "text_config", cfg).hidden_size
    n_layers = len(model.decoder_layers())
    for li in range(min(n_layers, 8)):
        for comp_key, targets in model.layer_components(li).items():
            if not targets or comp_key in col_mode_comps:
                continue
            tgt = targets[0]
            w = tgt.base_layer.weight if hasattr(tgt, "base_layer") else tgt.weight
            w_shape = getattr(getattr(w, "quant_state", None), "shape", None) or w.shape
            if w_shape[1] == hidden_dim and w_shape[0] != hidden_dim:
                col_mode_comps.add(comp_key)

    comp_freq: dict[str, float] = {}
    for li in range(n_layers):
        for ck in model.layer_components(li):
            comp_freq[ck] = comp_freq.get(ck, 0) + 1
    for ck in comp_freq:
        comp_freq[ck] /= n_layers

    hook_only_comps: set[str] = set()
    hook_keys = model.hook_only_keys
    for ck in model.ablation_targets():
        if ck in hook_keys:
            hook_only_comps.add(ck)
            fused_count = sum(1 for fp in model._fused_expert_params.values() if ck in fp)
            comp_freq.setdefault(ck, max(fused_count, 1) / n_layers)

    return col_mode_comps, comp_freq, hook_only_comps


def _sample_trial_params(trial, model, settings, svd_directions, layer_separability, trial_index,
                         *, col_mode_comps, comp_freq, hook_only_comps):
    """Sample all per-trial hyperparameters from the Optuna trial.

    Returns a dict with keys: layer_focus, parameters, head_mask,
    projection_strength, separability_threshold, dir_scales.
    """
    if svd_directions is not None:
        layer_scope = "per layer"
        trial.set_user_attr("layer_scope_forced", True)
    else:
        layer_scope = trial.suggest_categorical("layer_scope", ["global", "per layer"])

    last_layer_index = len(model.decoder_layers()) - 1

    layer_focus = trial.suggest_float(
        "layer_focus",
        0.4 * last_layer_index,
        0.9 * last_layer_index,
    )

    if layer_scope == "per layer":
        layer_focus = None

    rank_k = svd_directions.shape[1] if svd_directions is not None else 1
    peak_lo = max(0.5, 0.8 / rank_k)

    parameters = {}
    for component in model.ablation_targets():
        is_col = component in col_mode_comps
        is_hook_only = component in hook_only_comps
        # Col-mode or hook-only: cap tighter (hook scale >1 = overcorrection).
        # Floor kept low so only peak layers go aggressive — prevents sustained
        # high scales across all layers which causes looping on long generations.
        if is_col or is_hook_only:
            p_hi, f_hi = 3.0, 0.8
        else:
            p_hi, f_hi = 5.0, 1.0
        # Scale ranges by component frequency — rare components get tighter bounds
        freq = comp_freq.get(component, 1.0)
        if freq < 0.9:  # only scale if clearly not universal
            freq_scale = max(0.4, freq)
            p_hi = peak_lo + (p_hi - peak_lo) * freq_scale
            f_hi *= freq_scale
        peak = trial.suggest_float(f"{component}.peak", peak_lo, p_hi)
        peak_position = trial.suggest_float(
            f"{component}.peak_position",
            0.6 * last_layer_index,
            1.0 * last_layer_index,
        )
        # Sample floor as ratio of peak so TPE can model it independently
        floor_ratio = trial.suggest_float(f"{component}.floor", 0.0, f_hi)
        floor_distance = trial.suggest_float(
            f"{component}.floor_distance",
            1.0,
            max(1.01, 0.6 * last_layer_index),
        )
        parameters[component] = LayerEnvelope(
            peak=peak,
            peak_position=peak_position,
            floor=floor_ratio * peak,
            floor_distance=floor_distance,
        )

    trial.set_user_attr("layer_focus", layer_focus)
    trial.set_user_attr("parameters", {k: asdict(v) for k, v in parameters.items()})

    # Generate head mask for per-head ablation if enabled
    head_mask = None
    if settings.per_head_ablation:
        num_heads, _ = model.get_attention_head_info()
        head_fraction = trial.suggest_float(
            "head_ablation_fraction",
            max(0.1, settings.head_ablation_fraction - 0.3),
            min(1.0, settings.head_ablation_fraction + 0.3),
        )
        num_ablate = max(1, int(num_heads * head_fraction))
        rng = torch.Generator().manual_seed(trial_index * 1001 + int(head_fraction * 1000))
        indices = torch.randperm(num_heads, generator=rng)[:num_ablate]
        head_mask = torch.zeros(num_heads, dtype=torch.float32)
        head_mask[indices] = 1.0
        trial.set_user_attr("head_mask", head_mask.tolist())
        trial.set_user_attr("head_ablation_fraction", head_fraction)

    # Partial projection scaling
    projection_strength = 1.0
    if settings.partial_projection:
        projection_strength = trial.suggest_float("projection_strength", 0.1, 1.0)
        trial.set_user_attr("projection_strength", projection_strength)

    # Adaptive layer selection threshold
    separability_threshold = 0.0
    if layer_separability is not None:
        separability_threshold = trial.suggest_float("separability_threshold", 0.0, 0.5)
        trial.set_user_attr("separability_threshold", separability_threshold)

    # Sparse ablation threshold (side effect: updates model sparsity setting for this trial)
    if settings.sparsity_threshold > 0:
        sparsity = trial.suggest_float("sparsity_threshold", 0.01, 0.5)
        trial.set_user_attr("sparsity_threshold", sparsity)
        if isinstance(model, ParallelModel):
            model.set_sparsity_threshold(sparsity)
        else:
            model.settings.sparsity_threshold = sparsity

    # Per-direction scaling for rank-k ablation.
    dir_scales = None
    if svd_directions is not None:
        k = svd_directions.shape[1]
        dir_scales = []
        for i in range(k):
            dir_scales.append(trial.suggest_float(f"direction_scale_{i}", 0.3, 1.5))
        trial.set_user_attr("direction_scales", dir_scales)

    return {
        "layer_focus": layer_focus,
        "parameters": parameters,
        "head_mask": head_mask,
        "projection_strength": projection_strength,
        "separability_threshold": separability_threshold,
        "dir_scales": dir_scales,
    }


def run_optimization_loop(
    model,
    evaluator,
    settings,
    study,
    mean_direction,
    pca_directions,
    blend_modes,
    positions,
    good_residuals_multipos,
    bad_residuals_multipos,
    seed_params_file,
    layer_separability=None,
    svd_directions=None,
    total_trials=None,
):
    """Run the Optuna optimization loop. Returns (completed_count, run_more).

    total_trials overrides settings.trials for this loop (avoids mutating shared settings).
    """
    if total_trials is None:
        total_trials = settings.trials
    trial_index = 0
    start_index = 0
    start_time = time.perf_counter()
    dashboard: Dashboard | None = None

    # Static model introspection — computed once, reused across all trials
    _col_mode, _comp_freq, _hook_only = _introspect_components(model)

    def objective(trial: Trial) -> tuple[float, float]:
        nonlocal trial_index, dashboard
        trial_start = time.perf_counter()
        trial_index += 1
        trial.set_user_attr("index", trial_index)

        # Phase 1: Resolve refusal directions
        trial_directions = _resolve_directions(
            trial, svd_directions, pca_directions, mean_direction,
            blend_modes, settings, positions,
            good_residuals_multipos, bad_residuals_multipos,
        )

        # Phase 2: Sample all hyperparameters
        p = _sample_trial_params(trial, model, settings, svd_directions, layer_separability, trial_index,
                                col_mode_comps=_col_mode, comp_freq=_comp_freq, hook_only_comps=_hook_only)

        # Phase 3: Display trial info
        if dashboard:
            dashboard.update_trial(trial_index, f"Trial {trial_index}/{total_trials}")
            dashboard.add_verbose_line(f"Trial {trial_index}/{total_trials}")
            for name, value in get_trial_parameters(trial).items():
                dashboard.add_verbose_line(f"  {name}: {value}")
        else:
            print()
            print(phase(f"trial {trial_index}/{total_trials}"))
            params = get_trial_parameters(trial)
            param_str = "  ".join(f"{n} {val(v)}" for n, v in params.items())
            print(f"  {WORK} {param_str}")

        # Phase 4: Reset -> Abliterate -> Evaluate
        if dashboard:
            dashboard.update_trial(trial_index, "Resetting model...")
        else:
            print(f"  {WORK} Reset {ARROW} Abliterate {ARROW} Evaluate")
        model.reset_model()

        if dashboard:
            dashboard.update_trial(trial_index, "Abliterating...")
        model.abliterate(
            trial_directions, p["layer_focus"], p["parameters"], p["head_mask"],
            p["projection_strength"], layer_separability, p["separability_threshold"],
            p["dir_scales"],
        )

        if dashboard:
            dashboard.update_trial(trial_index, "Evaluating...")
        score, kl_divergence, refusals, kl_detail = evaluator.get_score(quick_eval=True)

        # Phase 5: Report results
        elapsed = time.perf_counter() - start_time
        per_trial = elapsed / max(trial_index - start_index, 1)
        eta = per_trial * (total_trials - trial_index)

        if not dashboard:
            print(step(f"KL {val(f'{kl_divergence:.4f}')}  Refusals {val(f'{refusals}/{len(evaluator.harmful_prompts)}')}"))
            elapsed_str = format_duration(elapsed)
            if trial_index < total_trials:
                print(dim(f"  {elapsed_str} elapsed \u2022 ~{format_duration(eta)} remaining"))
            else:
                print(dim(f"  {elapsed_str} elapsed"))

        trial.set_user_attr("kl_divergence", kl_divergence)
        trial.set_user_attr("refusals", refusals)
        if kl_detail:
            trial.set_user_attr("kl_detail", kl_detail)

        if dashboard:
            dashboard.record_trial_time(time.perf_counter() - trial_start)
            completed = [t for t in trial.study.trials if t.state == TrialState.COMPLETE]
            dashboard.update_pareto([{
                'trial': t.user_attrs.get('index', 0),
                'kl': t.user_attrs.get('kl_divergence', 0),
                'refusals': t.user_attrs.get('refusals', 0),
                'kl_detail': t.user_attrs.get('kl_detail', {}),
                'params': {
                    'blend_mode': t.user_attrs.get('blend_mode', 'mean'),
                    'layer_focus': t.user_attrs.get('layer_focus'),
                }
            } for t in completed])

        return score

    def _guarded_objective(trial: Trial) -> tuple[float, float]:
        try:
            return objective(trial)
        except KeyboardInterrupt:
            trial.study.stop()
            raise TrialPruned()
        except torch.cuda.OutOfMemoryError:
            empty_cache()
            print(f"  {FAIL} GPU OOM, skipping")
            raise TrialPruned()

    def count_completed_trials() -> int:
        return sum(1 for t in study.trials if t.state == TrialState.COMPLETE)

    start_index = trial_index = count_completed_trials()
    if start_index > 0:
        print(step("Resuming study", f"{start_index} completed"))

    # Load and enqueue seed parameters if available
    current_mode = ("pca_rank_k" if pca_directions is not None else "svd") if svd_directions is not None else None
    if settings.use_seed_params and start_index == 0 and seed_params_file:
        seed_params = load_seed_params(seed_params_file)
        if seed_params:
            print()
            print(step(f"Loading seeds from {val(seed_params_file)}"))
            enqueued = skipped = 0
            for sp in seed_params:
                seed_mode = sp.get("blend_mode", sp.get("direction_mode", "mean"))
                # Skip seeds with incompatible blend modes
                if seed_mode not in blend_modes and seed_mode != current_mode:
                    skipped += 1
                    continue

                scope = sp.get("layer_scope", sp.get("direction_scope"))
                if scope not in ("global", "per layer"):
                    scope = "global" if sp.get("layer_focus", sp.get("direction_index")) is not None else "per layer"
                enqueue_params = {
                    "blend_mode": seed_mode,
                    "layer_scope": scope,
                    "layer_focus": sp.get("layer_focus", sp.get("direction_index", 0.6 * (len(model.decoder_layers()) - 1))),
                }
                for component, comp_params in sp.get("parameters", {}).items():
                    for param_name, param_value in comp_params.items():
                        enqueue_params[f"{component}.{param_name}"] = param_value
                for key, value in sp.get("top_level", {}).items():
                    enqueue_params[key] = value

                study.enqueue_trial(enqueue_params)
                enqueued += 1
                ref = sp.get("refusals", sp.get("_refusals", "?"))
                kl = sp.get("kl_divergence", sp.get("_kl_divergence", "?"))
                if isinstance(kl, float):
                    kl = f"{kl:.4f}"
                print(step(f"Seed {enqueued}", f"{ref} refusals, KL {kl}"))
            if skipped:
                print(f"  {WARN} Skipped {val(skipped)} seeds (mode mismatch: need {val(current_mode)})")

    _persistent_dashboard: Dashboard | None = None

    def run_optimization():
        nonlocal dashboard, _persistent_dashboard
        n_remaining = total_trials - count_completed_trials()
        if n_remaining <= 0:
            return

        if settings.dashboard and sys.stdin.isatty():
            if _persistent_dashboard is None:
                _persistent_dashboard = Dashboard(total_trials, len(evaluator.harmful_prompts))
            _persistent_dashboard.current_trial = count_completed_trials()
            with _persistent_dashboard as d:
                dashboard = d
                set_dashboard_active(True)
                study.optimize(_guarded_objective, n_trials=n_remaining, show_progress_bar=False)
                set_dashboard_active(False)
                dashboard = None
        else:
            study.optimize(_guarded_objective, n_trials=n_remaining, show_progress_bar=False)

    try:
        run_optimization()
    except KeyboardInterrupt:
        # Catches Ctrl+C between trial boundaries (outside objective).
        pass

    def _save_seeds():
        completed = [t for t in study.trials if t.state == TrialState.COMPLETE]
        if seed_params_file and completed:
            new_seeds = update_best_seeds(seed_params_file, completed)
            if new_seeds > 0:
                print()
                print(step(f"Seeds updated  {OK}", f"{new_seeds} new \u2192 {seed_params_file}"))

    if count_completed_trials() == total_trials:
        study.set_user_attr("finished", True)

    _save_seeds()

    def run_more():
        """Run more optimization trials. Called from the continue option in main."""
        nonlocal start_index, trial_index, start_time, total_trials
        total_trials = settings.trials  # re-read in case user changed trials between runs
        start_index = trial_index = count_completed_trials()
        start_time = time.perf_counter()
        try:
            run_optimization()
        except KeyboardInterrupt:
            pass
        if count_completed_trials() == total_trials:
            study.set_user_attr("finished", True)
        _save_seeds()

    return count_completed_trials, run_more
