# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Copyright (C) 2025  HauhauCS <hauhaut901@gmail.com>

import math
import os
import sys
import time
import warnings
from importlib.metadata import version

import optuna
import torch
import transformers
from optuna.exceptions import ExperimentalWarning
from optuna.samplers import TPESampler
from optuna.storages import JournalStorage
from optuna.storages.journal import JournalFileBackend, JournalFileOpenLock
from optuna.study import StudyDirection
from optuna.trial import TrialState
from pydantic import ValidationError
from questionary import Choice
from rich.traceback import install

from .config import Settings
from .directions import DirectionResult, compute_directions, resolve_trial_directions, replay_trial, routing_analysis
from .evaluator import Evaluator
from .export import save_model, upload_model
from .model import Model
from .optimization import run_optimization_loop
from .parallel_model import ParallelModel, can_use_parallel_model
from .seed_management import get_pareto_optimal, trial_to_seed_params
from .style import OK, FAIL, WARN, WORK, STAR, phase, step, val, dim, banner
from .utils import (
    get_gpu_info,
    load_prompts,
    log_gpu_utilization,
    print,
    prompt_path,
    prompt_select,
    prompt_text,
)


# Known model configs - bypass detection for models with known CoT patterns.
# GPT-OSS uses channel tokens for CoT; skip_special_tokens=True decodes them
# as plain text "analysis" / "assistantfinal", so strip_thinking() handles it.
# No response_prefix needed — let the model think, then extract the answer.
KNOWN_MODEL_CONFIGS = {
    "gpt-oss": ("analysis", "analysis", "assistantfinal"),
}

# Chain-of-thought tag patterns: maps a starting tag to the suppression string.
# Used to collapse CoT output so only the final answer is evaluated.
COT_SUPPRESSIONS = {
    "<think>": "<think></think>",
    "<thought>": "<thought></thought>",
    "[THINK]": "[THINK][/THINK]",
}


def _detect_accelerators() -> tuple[int, float]:
    """Detect available GPUs/accelerators, print info, return (device_count, total_memory_gb)."""
    print(phase("device"))
    if torch.cuda.is_available():
        gpus = get_gpu_info()
        n = len(gpus)
        mem = sum(g["memory_gb"] for g in gpus)
        print(step(f"detected {val(n)} CUDA device(s)"))
        for gpu in gpus:
            print(step(f"GPU {gpu['index']}: {val(gpu['name'])}", f"{gpu['memory_gb']:.1f} GB"))
        if n > 1:
            print(step(f"total GPU memory: {val(f'{mem:.1f} GB')}", f"from {n} devices"))
        return n, mem

    from accelerate.utils import (
        is_mlu_available,
        is_musa_available,
        is_sdaa_available,
        is_xpu_available,
    )
    def _count(name: str) -> int:
        return getattr(torch, name).device_count()
    def _name(name: str, i: int) -> str:
        return getattr(torch, name).get_device_name(i)

    for avail_fn, count_fn, name_fn, label in [
        (is_xpu_available, lambda: _count("xpu"), lambda i: _name("xpu", i), "XPU"),
        (is_mlu_available, lambda: _count("mlu"), lambda i: _name("mlu", i), "MLU"),
        (is_sdaa_available, lambda: _count("sdaa"), lambda i: _name("sdaa", i), "SDAA"),
        (is_musa_available, lambda: _count("musa"), lambda i: _name("musa", i), "MUSA"),
    ]:
        if avail_fn():
            n = count_fn()
            print(step(f"detected {val(n)} {label} device(s)"))
            for i in range(n):
                print(step(f"{label} {i}: {val(name_fn(i))}"))
            return n, 0.0

    from accelerate.utils import is_npu_available
    if is_npu_available():
        print(step("NPU detected", f"CANN version: {torch.version.cann}"))  # ty:ignore[unresolved-attribute]
        return 1, 0.0

    if torch.backends.mps.is_available():
        print(step(f"detected {val(1)} MPS device", "Apple Metal"))
        return 1, 0.0

    print(f"  {WARN} no GPU or other accelerator detected — operations will be slow")
    return 0, 0.0


def _autotune_batch_size(
    model, safe_prompts: list, max_batch: int, total_gpu_mem: float, gpu_count: int,
) -> int:
    """Binary-search for the batch size with best throughput."""
    print(phase("batch", "autotuning"))

    # Scale ceiling based on available VRAM (24GB baseline -> 64 batch)
    if total_gpu_mem > 0:
        mem_scaled = max(1, int(total_gpu_mem / 24 * 64))
        ceiling = min(max_batch, mem_scaled)
        if ceiling != max_batch:
            print(step(f"scaling max batch to {val(ceiling)}", f"{total_gpu_mem:.1f} GB total GPU memory"))
    else:
        ceiling = max_batch

    sz = 1
    winner, winner_tps = -1, -1.0

    while sz <= ceiling:
        print(f"  {WORK} trying batch size {val(sz)}... ", end="")
        batch = (safe_prompts * math.ceil(sz / len(safe_prompts)))[:sz]

        try:
            model.get_responses(batch)  # warmup / graph compilation
            if gpu_count > 1:
                log_gpu_utilization()
            t0 = time.perf_counter()
            resps = model.get_responses(batch)
            elapsed = time.perf_counter() - t0
        except Exception as exc:
            if sz == 1:
                raise
            print(f"{FAIL} {dim(str(exc))}")
            break

        tok_count = sum(len(model.tokenizer.encode(r)) for r in resps)
        tps = tok_count / elapsed
        print(f"{OK} {dim(f'{tps:.0f} tokens/s')}")

        if tps > winner_tps:
            winner, winner_tps = sz, tps
        sz *= 2

    if winner < 1:
        raise RuntimeError(
            f"Batch size auto-detection failed: ceiling={ceiling}. Set --batch-size manually."
        )
    return winner


def _suppress_cot_prefix(raw_prefix: str) -> str:
    """If the common prefix matches a known CoT tag, return the suppression string."""
    for tag_start, suppression in COT_SUPPRESSIONS.items():
        if raw_prefix.startswith(tag_start):
            return suppression
    return raw_prefix


def _detect_response_prefix(model, settings, safe_prompts, harmful_prompts):
    """Detect or look up the common response prefix and set it on the model."""
    print(step("checking for common response prefix..."))

    model_lower = settings.model.lower()
    for pattern, (prefix, think_start, think_end) in KNOWN_MODEL_CONFIGS.items():
        if pattern in model_lower:
            model.response_prefix = prefix
            settings.thinking_start_token = think_start
            settings.thinking_end_token = think_end
            if prefix:
                print(step(f"prefix set for known model: {val(repr(prefix))}"))
            print(step(f"thinking tokens: {val(think_start)} / {val(think_end)}"))
            return

    # Small sample — chat template prefixes are deterministic, 5 is enough.
    resps = model.get_responses_batched(safe_prompts[:5] + harmful_prompts[:5])

    # commonprefix is a character-level LCP, not a filesystem operation.
    # Strip trailing space to avoid tokenization edge cases.
    from os.path import commonprefix
    raw = commonprefix(resps).rstrip(" ")
    model.response_prefix = _suppress_cot_prefix(raw)

    if model.response_prefix:
        print(step(f"prefix found: {val(repr(model.response_prefix))}"))
    else:
        print(step("no prefix found"))


def _handle_existing_study(storage, settings, checkpoint_path, lock):
    """If a previous study exists, prompt user for continue/restart. Returns (settings, is_restart, storage, study_name)."""
    try:
        prev = storage.get_all_studies()[0]
        prev_name = prev.study_name
    except IndexError:
        return settings, False, storage, None

    already_done = prev.user_attrs.get("finished", False)
    if already_done:
        print(f"  {OK} previous run complete — how would you like to proceed?")
        resume_label = "Show the results from the previous run, allowing you to export models, or to run additional trials."
    else:
        print(f"  {WARN} previous run was interrupted — how would you like to proceed?")
        resume_label = "Continue the previous run from where it stopped (will override all specified settings)."

    options = [
        Choice(title=resume_label, value="resume"),
        Choice(
            title="Ignore the previous run and start from scratch. This will delete the checkpoint file and all results from the previous run.",
            value="fresh",
        ),
    ]
    decision = prompt_select("", options)

    if decision == "resume":
        restored = Settings.model_validate_json(prev.user_attrs["settings"])
        return restored, False, storage, prev_name
    elif decision == "fresh":
        try:
            os.unlink(checkpoint_path)
        except OSError as e:
            print(f"  {WARN} could not delete checkpoint: {e}")
        # Keep cached directions if direction-related settings match — avoids expensive
        # recomputation (RDO, LEACE, residual extraction) when only trial settings changed.
        dir_cache = checkpoint_path.replace(".jsonl", ".directions.pt")
        prev_s = Settings.model_validate_json(prev.user_attrs["settings"])
        dir_keys = ("rdo_refine", "rdo_lr", "rdo_steps", "rdo_kl_weight", "rdo_seed", "lda_direction",
                    "leace_direction", "use_pca_directions", "num_pca_directions", "ablation_rank",
                    "som_directions", "som_clusters", "projected_direction", "concept_atoms",
                    "winsorize_residuals", "multi_position_residuals", "residual_positions",
                    "iterative_refinement", "deep_ablation", "adaptive_layer_selection")
        old_dir = {k: getattr(prev_s, k) for k in dir_keys}
        new_dir = {k: getattr(settings, k) for k in dir_keys}
        if old_dir != new_dir:
            try:
                os.unlink(dir_cache)
                print(step("direction settings changed — cached directions deleted"))
            except OSError:
                pass
        elif os.path.exists(dir_cache):
            print(step("direction settings unchanged — keeping cached directions"))
        lock2 = JournalFileOpenLock(checkpoint_path)
        backend2 = JournalFileBackend(checkpoint_path, lock_obj=lock2)
        storage2 = JournalStorage(backend2)
        return settings, True, storage2, None
    else:
        return None, False, storage, prev_name  # cancelled


def _interactive_chat(model, system_prompt: str):
    """Run an interactive chat session with the abliterated model."""
    print(phase("chat", dim("ctrl+c to exit")))
    history = [{"role": "system", "content": system_prompt}]

    while True:
        try:
            msg = prompt_text("User:", qmark=">", unsafe=True)
            if not msg:
                return
            history.append({"role": "user", "content": msg})
            print(f"{val('Assistant:')} ", end="")
            reply = model.stream_chat_response(history)
            history.append({"role": "assistant", "content": reply})
        except (KeyboardInterrupt, EOFError):
            return


_ACTION_CHAT = "Chat with the model"
_ACTION_INSPECT = "Inspect trial details"
_ACTION_EXPORT_SEED = "Export seed config"
_ACTION_SAVE = "Save model locally"
_ACTION_UPLOAD = "Upload to Hugging Face"
_ACTION_BACK = "Back"

_ACTION_LABELS = [
    _ACTION_CHAT, _ACTION_INSPECT, _ACTION_EXPORT_SEED,
    _ACTION_SAVE, _ACTION_UPLOAD, _ACTION_BACK,
]


def _inspect_trial(trial):
    """Print trial parameters in a readable table."""
    from rich.table import Table

    attrs = trial.user_attrs
    print()
    print(phase("trial", f"#{attrs.get('index', '?')}"))
    print(step(f"Refusals: {val(attrs.get('refusals', '?'))}/{attrs.get('total_bad', '?')}"))
    kl_val = attrs.get("kl_divergence", 0)
    kl_detail = attrs.get("kl_detail", {})
    if kl_detail:
        t1 = kl_detail.get("top1_agree", 0)
        km = kl_detail.get("kl_max", 0)
        print(step(f"KL divergence: {val(f'{kl_val:.4f}')}  top1={val(f'{t1:.0%}')}  max={val(f'{km:.4f}')}"))
    else:
        print(step(f"KL divergence: {val(f'{kl_val:.4f}')}"))
    print(step(f"Direction: {val(attrs.get('blend_mode', 'mean'))}"))
    if trial.params.get("layer_scope"):
        print(step(f"Scope: {val(trial.params['layer_scope'])}"))
    if trial.params.get("layer_focus") is not None:
        print(step(f"Layer focus: {val(trial.params['layer_focus'])}"))

    # Component weights table
    components: dict[str, dict[str, float]] = {}
    top_level: dict[str, float] = {}
    skip = {"blend_mode", "layer_scope", "layer_focus"}
    for key, value in trial.params.items():
        if key in skip:
            continue
        if "." in key:
            comp, param = key.rsplit(".", 1)
            components.setdefault(comp, {})[param] = value
        else:
            top_level[key] = value

    if top_level:
        print()
        for k, v in sorted(top_level.items()):
            fmt = f"{v:.4f}" if isinstance(v, float) else str(v)
            print(step(f"{k}: {val(fmt)}"))

    if components:
        tbl = Table(title="Component Weights")
        tbl.add_column("Component", style="bold")
        # Collect all param names across components
        all_params = sorted({p for comp in components.values() for p in comp})
        for p in all_params:
            tbl.add_column(p, justify="right")
        for comp_name in sorted(components):
            row = [comp_name] + [
                f"{components[comp_name].get(p, 0):.4f}" if isinstance(components[comp_name].get(p), float)
                else str(components[comp_name].get(p, ""))
                for p in all_params
            ]
            tbl.add_row(*row)
        print()
        print(tbl)


def _post_trial_actions(model, settings, evaluator, trial, directions=None, layer_separability=None):
    """Menu loop for save/upload/chat/inspect/export after selecting a trial."""
    attrs = trial.user_attrs
    ref = attrs.get("refusals", "?")
    total = len(evaluator.harmful_prompts)
    kl = attrs.get("kl_divergence", 0)
    print()
    print(phase(f"trial {attrs.get('index', '?')}", f"{ref}/{total} refusals  KL {kl:.4f}"))

    def _ensure_model_ready():
        """Re-replay trial if model was corrupted by a prior save/export."""
        m = model.models[0] if isinstance(model, ParallelModel) else model
        if not m.needs_reload:
            return
        print(step("model was modified by export — re-applying trial..."))
        dirs = resolve_trial_directions(
            trial,
            directions.mean_direction if directions else None,
            directions.pca_directions if directions else None,
            directions.svd_directions if directions else None,
            directions.positions if directions else None,
            directions.good_residuals_multipos if directions else None,
            directions.bad_residuals_multipos if directions else None,
        )
        replay_trial(model, trial, dirs, layer_separability)

    while True:
        print()
        action = prompt_select("What would you like to do?", _ACTION_LABELS)

        if action is None or action == _ACTION_BACK:
            return

        try:
            if action == _ACTION_CHAT:
                _ensure_model_ready()
                _interactive_chat(model, settings.system_prompt)
            elif action == _ACTION_INSPECT:
                _inspect_trial(trial)
            elif action == _ACTION_EXPORT_SEED:
                import json
                seed = trial_to_seed_params(trial)
                dest = prompt_text("Save path:", default="seed.json")
                if dest:
                    with open(dest, "w") as f:
                        json.dump([seed], f, indent=2)
                    print(step(f"Seed config saved to {val(dest)}  {OK}"))
            elif action == _ACTION_SAVE:
                dest = prompt_path("Path to the folder:")
                if dest:
                    _ensure_model_ready()
                    save_model(model, dest, settings)
            elif action == _ACTION_UPLOAD:
                _ensure_model_ready()
                upload_model(model, settings, trial, evaluator.baseline_refusal_count, evaluator.harmful_prompts)
        except Exception as exc:
            print(f"  {FAIL} {exc}")
            import traceback
            traceback.print_exc()


def _ask_more_trials() -> int | None:
    """Prompt user for number of additional trials. Returns None on cancel."""
    while True:
        try:
            raw = prompt_text("How many more trials do you want to run?")
            if raw is None:
                return None
            count = int(raw)
            if count > 0:
                return count
            print(f"  {FAIL} please enter a number greater than 0")
        except ValueError:
            print(f"  {FAIL} invalid input — please enter a number")


def _results_loop(study, settings, evaluator, model, directions: DirectionResult, run_more):
    """Interactive Pareto display + trial selection loop. Returns when user picks Exit."""
    while True:
        completed = [t for t in study.trials if t.state == TrialState.COMPLETE]
        if not completed:
            raise KeyboardInterrupt

        # Pareto front via canonical seed_management logic
        seeds = [
            {"trial": t, "refusals": t.user_attrs["refusals"], "kl_divergence": t.user_attrs["kl_divergence"]}
            for t in completed
        ]
        pareto = [s["trial"] for s in get_pareto_optimal(seeds)]

        n_bad = len(evaluator.harmful_prompts)

        # Pareto summary table
        from rich.table import Table
        print()
        print(phase("results", f"{len(completed)} completed, {len(pareto)} on Pareto front"))
        tbl = Table(title="Pareto Front", show_lines=False, pad_edge=False)
        tbl.add_column("#", style="bold", justify="right")
        tbl.add_column("Refused", justify="right")
        tbl.add_column("KL", justify="right")
        tbl.add_column("Top1", justify="right")
        tbl.add_column("Direction", justify="left")
        for t in pareto:
            kl = t.user_attrs["kl_divergence"]
            kl_style = "red" if kl > 1.0 else ("yellow" if kl > 0.5 else "green")
            ref = t.user_attrs["refusals"]
            ref_style = "green" if ref == 0 else ("yellow" if ref <= 5 else "red")
            t1 = t.user_attrs.get("kl_detail", {}).get("top1_agree")
            t1_str = f"{t1:.0%}" if t1 is not None else "-"
            tbl.add_row(
                str(t.user_attrs["index"]),
                f"[{ref_style}]{ref}/{n_bad}[/]",
                f"[{kl_style}]{kl:.4f}[/]",
                t1_str,
                t.user_attrs.get("blend_mode", "mean"),
            )
        print(tbl)

        trial_choices = [
            Choice(title=f"Trial {t.user_attrs['index']}", value=t)
            for t in pareto
        ]
        trial_choices.append(Choice(title="Run more trials", value="continue"))
        trial_choices.append(Choice(title="Exit", value=""))

        while True:
            print()
            pick = prompt_select("Pick a trial:", trial_choices)

            if pick == "continue":
                extra = _ask_more_trials()
                if extra is None:
                    continue
                settings.trials += extra
                study.set_user_attr("settings", settings.model_dump_json())
                study.set_user_attr("finished", False)
                model.reset_model()  # free VRAM from any prior merge/replay
                run_more()
                break

            if pick is None or pick == "":
                return

            dirs = resolve_trial_directions(
                pick, directions.mean_direction, directions.pca_directions, directions.svd_directions,
                directions.positions, directions.good_residuals_multipos, directions.bad_residuals_multipos,
            )
            try:
                replay_trial(model, pick, dirs, directions.layer_separability)
            except Exception as exc:
                print(f"  {FAIL} error restoring model: {exc}")
                continue

            _post_trial_actions(model, settings, evaluator, pick, directions, directions.layer_separability)


def run():
    # Reduce CUDA memory fragmentation on multi-GPU setups via expandable segments.
    if "PYTORCH_ALLOC_CONF" not in os.environ and "PYTORCH_CUDA_ALLOC_CONF" not in os.environ:
        os.environ["PYTORCH_ALLOC_CONF"] = "expandable_segments:True"

    print(banner())

    if "--version" in sys.argv or "-V" in sys.argv:
        print(f"reaper-abliteration {version('reaper-abliteration')}")
        return

    # Allow bare positional: `reaper Qwen/Qwen3-4B-Instruct`
    argv = sys.argv[1:]
    if argv and "--model" not in argv and not argv[-1].startswith("-"):
        sys.argv.insert(-1, "--model")

    try:
        settings = Settings()
    except ValidationError as ve:
        print(f"  {FAIL} configuration contains {val(ve.error_count())} errors:")
        for err in ve.errors():
            print(f"    {val(err['loc'][0])}: {dim(err['msg'])}")
        print(f"  run {val('abliterate --help')} or see {val('reaper.toml')} for details about configuration parameters.")
        return

    gpu_count, total_gpu_mem = _detect_accelerators()

    # Inference-only: no gradients needed.
    torch.set_grad_enabled(False)
    # Raise TorchDynamo cache limit for batch size sweeps.
    torch._dynamo.config.cache_size_limit = 64
    # Hush noisy libraries.
    transformers.logging.set_verbosity_error()
    optuna.logging.set_verbosity(optuna.logging.WARNING)
    warnings.filterwarnings("ignore", category=ExperimentalWarning)

    base = "".join(c if (c.isalnum() or c in "_-") else "--" for c in settings.model)
    ckpt_path = os.path.join(settings.study_checkpoint_dir, base + ".jsonl")
    seed_path = os.path.join(settings.seed_params_dir, base + ".json")
    os.makedirs(settings.study_checkpoint_dir, exist_ok=True)
    os.makedirs(settings.seed_params_dir, exist_ok=True)
    lock = JournalFileOpenLock(ckpt_path)
    backend = JournalFileBackend(ckpt_path, lock_obj=lock)
    storage = JournalStorage(backend)

    result = _handle_existing_study(storage, settings, ckpt_path, lock)
    settings, is_restart, storage, study_name = result

    if settings is None:
        print(f"  {FAIL} cancelled; exiting.")
        return

    # Model instantiation: use ParallelModel for multi-GPU data parallelism when viable
    use_parallel = can_use_parallel_model(settings)
    if use_parallel:
        print(phase("model", "multi-GPU data parallelism"))
        model = ParallelModel(settings, settings.gpu_devices)
    else:
        model = Model(settings)

    # Load prompt datasets
    print(phase("prompts"))
    print(step(f"loading safe prompts from {val(settings.safe_prompts.source)}..."))
    safe_prompts = load_prompts(settings, settings.safe_prompts)
    if not safe_prompts:
        raise ValueError(f"No prompts loaded from {settings.safe_prompts.source} (split: {settings.safe_prompts.split})")
    print(step(f"{val(len(safe_prompts))} safe prompts loaded"))
    print(step(f"loading harmful prompts from {val(settings.harmful_prompts.source)}..."))
    harmful_prompts = load_prompts(settings, settings.harmful_prompts)
    if not harmful_prompts:
        raise ValueError(f"No prompts loaded from {settings.harmful_prompts.source} (split: {settings.harmful_prompts.split})")
    print(step(f"{val(len(harmful_prompts))} harmful prompts loaded"))

    # Auto-tune batch size if not manually specified
    if settings.batch_size == 0:
        best = _autotune_batch_size(model, safe_prompts, settings.batch_ceiling, total_gpu_mem, gpu_count)
        settings.batch_size = best
        if isinstance(model, ParallelModel):
            model.set_batch_size(best)
        print(f"  {STAR} chosen batch size: {val(settings.batch_size)}")

    _detect_response_prefix(model, settings, safe_prompts, harmful_prompts)

    if settings.routing_analysis:
        routing_analysis(model, settings, safe_prompts, harmful_prompts)
        return

    # Auto-detect super experts on MoE models to protect them from ablation.
    # Super experts are structural (data-agnostic) and their removal causes model collapse.
    if model._fused_expert_params:
        model._super_experts, model._expert_refusal_ratios = routing_analysis(model, settings, safe_prompts, harmful_prompts)

    evaluator = Evaluator(settings, model)

    if settings.eval_checkpoint is not None:
        print(phase("model", val(settings.eval_checkpoint)))
        settings.model = settings.eval_checkpoint
        model.reset_model()
        print(step("evaluating..."))
        evaluator.get_score(quick_eval=False)
        return

    dir_cache = ckpt_path.replace(".jsonl", ".directions.pt")
    if not is_restart and os.path.exists(dir_cache):
        print(phase("directions", "loading cached directions from previous run"))
        positions = settings.residual_positions if settings.multi_position_residuals else [-1]
        dev = model.models[0].model.device if use_parallel else model.model.device
        directions = DirectionResult.load(dir_cache, dev, positions)
        print(step(f"mean_direction shape: {val(tuple(directions.mean_direction.shape))}"))
        if directions.svd_directions is not None:
            print(step(f"svd_directions shape: {val(tuple(directions.svd_directions.shape))}"))
        if directions.rdo_seed is not None:
            print(step(f"reusing cached RDO seed: {val(directions.rdo_seed)}"))
    else:
        directions = compute_directions(model, settings, evaluator, safe_prompts, harmful_prompts)
        directions.save(dir_cache)
        print(step(f"directions cached to {val(dir_cache)}"))

    n_warmup = settings.warmup_trials
    study = optuna.create_study(
        study_name=study_name,
        sampler=TPESampler(
            n_startup_trials=n_warmup,
            n_ei_candidates=128,
            multivariate=True,
        ),
        storage=storage,
        directions=[StudyDirection.MINIMIZE, StudyDirection.MINIMIZE],
        load_if_exists=not is_restart,
    )

    study.set_user_attr("settings", settings.model_dump_json())
    study.set_user_attr("finished", False)

    _, run_more = run_optimization_loop(
        model=model,
        evaluator=evaluator,
        settings=settings,
        study=study,
        mean_direction=directions.mean_direction,
        pca_directions=directions.pca_directions,
        blend_modes=directions.blend_modes,
        positions=directions.positions,
        good_residuals_multipos=directions.good_residuals_multipos,
        bad_residuals_multipos=directions.bad_residuals_multipos,
        seed_params_file=seed_path,
        layer_separability=directions.layer_separability,
        svd_directions=directions.svd_directions,
    )

    _results_loop(study, settings, evaluator, model, directions, run_more)


def main():
    install()

    try:
        run()
    except BaseException as exc:
        # HF transformers sometimes wraps Ctrl+C in its own handlers.
        root = exc.__context__ if exc.__context__ else exc
        if isinstance(root, KeyboardInterrupt) or isinstance(exc, KeyboardInterrupt):
            print(f"\n  {FAIL} shutting down...")
        else:
            raise
