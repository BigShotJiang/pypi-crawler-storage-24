# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Copyright (C) 2025  HauhauCS <hauhaut901@gmail.com>

from __future__ import annotations

import math
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

import torch
from rich.table import Table
from torch import Tensor

from .config import Settings
from .model import Model
from .style import OK, WARN, dim, step, val
from .utils import print, track

if TYPE_CHECKING:
    from .parallel_model import ParallelModel

_MISSING_DEP_HINT = (
    f"  {WARN} Missing dependency. {{action}} requires "
    f"{dim('pip install -U reaper-abliteration')}"
)

_LEGEND_LINES = [
    ("[bold]s[/]", "average residual across safe prompts"),
    ("[bold]s*[/]", "geometric-median residual, safe prompts"),
    ("[bold]h[/]", "average residual across flagged prompts"),
    ("[bold]h*[/]", "geometric-median residual, flagged prompts"),
    ("[bold]r[/]", "mean refusal vector (flagged minus safe)"),
    ("[bold]r*[/]", "median refusal vector (flagged minus safe)"),
    ("[bold]cos(x,y)[/]", "cosine similarity between [bold]x[/] and [bold]y[/]"),
    ("[bold]||x||[/]", "Euclidean norm of [bold]x[/]"),
    ("[bold]Silh[/]", "silhouette score (cluster separation metric)"),
]

_GEOMETRY_COLUMNS = [
    ("Layer", "right"), ("cos(s,h)", "right"), ("cos(s*,h*)", "right"),
    ("cos(s,r)", "right"), ("cos(s*,r*)", "right"), ("cos(h,r)", "right"),
    ("cos(h*,r*)", "right"), ("||s||", "right"), ("||s*||", "right"),
    ("||h||", "right"), ("||h*||", "right"), ("||r||", "right"),
    ("||r*||", "right"), ("Silh", "right"),
]

HOLD_MS = 800
TWEEN_STEPS = 16
TWEEN_MS = 40


@dataclass
class _LayerGeometry:
    idx: int
    cos_gb: float = 0.0
    cos_gsbs: float = 0.0
    cos_gr: float = 0.0
    cos_gsrs: float = 0.0
    cos_br: float = 0.0
    cos_bsrs: float = 0.0
    norm_g: float = 0.0
    norm_gs: float = 0.0
    norm_b: float = 0.0
    norm_bs: float = 0.0
    norm_r: float = 0.0
    norm_rs: float = 0.0
    silhouette: float = 0.0


@dataclass
class _Projection2D:
    safe_pts: object = None  # NDArray
    harm_pts: object = None  # NDArray


def _compute_geom_median_per_layer(residuals: Tensor, n_layers: int, compute_fn) -> Tensor:
    return torch.stack([
        compute_fn(residuals[:, k, :].detach().cpu()).median
        for k in range(n_layers)
    ])


def _cosine_sim(a: Tensor, b: Tensor) -> Tensor:
    return torch.nn.functional.cosine_similarity(a, b, dim=-1)


def _l2_norm(t: Tensor) -> Tensor:
    return torch.linalg.vector_norm(t, dim=-1)


def _compute_all_geometry(
    safe_resid: Tensor,
    harm_resid: Tensor,
    num_positions: int,
    compute_geom_median,
    silhouette_fn,
) -> list[_LayerGeometry]:
    avg_safe = safe_resid.mean(dim=0)
    avg_harm = harm_resid.mean(dim=0)
    med_safe = _compute_geom_median_per_layer(safe_resid, num_positions, compute_geom_median)
    med_harm = _compute_geom_median_per_layer(harm_resid, num_positions, compute_geom_median)

    diff_avg = avg_harm - avg_safe
    diff_med = med_harm - med_safe

    sims = {
        "gb": _cosine_sim(avg_safe, avg_harm),
        "gsbs": _cosine_sim(med_safe, med_harm),
        "gr": _cosine_sim(avg_safe, diff_avg),
        "gsrs": _cosine_sim(med_safe, diff_med),
        "br": _cosine_sim(avg_harm, diff_avg),
        "bsrs": _cosine_sim(med_harm, diff_med),
    }
    norms = {
        "g": _l2_norm(avg_safe), "gs": _l2_norm(med_safe),
        "b": _l2_norm(avg_harm), "bs": _l2_norm(med_harm),
        "r": _l2_norm(diff_avg), "rs": _l2_norm(diff_med),
    }

    combined_np = torch.cat([safe_resid, harm_resid], dim=0).detach().cpu().numpy()
    cluster_ids = [0] * safe_resid.shape[0] + [1] * harm_resid.shape[0]
    sil_scores = [
        silhouette_fn(combined_np[:, k, :], cluster_ids)
        for k in range(num_positions)
    ]

    rows: list[_LayerGeometry] = []
    for k in range(1, num_positions):
        rows.append(_LayerGeometry(
            idx=k,
            cos_gb=sims["gb"][k].item(), cos_gsbs=sims["gsbs"][k].item(),
            cos_gr=sims["gr"][k].item(), cos_gsrs=sims["gsrs"][k].item(),
            cos_br=sims["br"][k].item(), cos_bsrs=sims["bsrs"][k].item(),
            norm_g=norms["g"][k].item(), norm_gs=norms["gs"][k].item(),
            norm_b=norms["b"][k].item(), norm_bs=norms["bs"][k].item(),
            norm_r=norms["r"][k].item(), norm_rs=norms["rs"][k].item(),
            silhouette=sil_scores[k],
        ))
    return rows


def _format_geometry_table(rows: list[_LayerGeometry]) -> Table:
    tbl = Table()
    for col_name, col_align in _GEOMETRY_COLUMNS:
        tbl.add_column(col_name, justify=col_align)  # ty:ignore[invalid-argument-type]
    for row in rows:
        tbl.add_row(
            f"{row.idx}",
            f"{row.cos_gb:.4f}", f"{row.cos_gsbs:.4f}",
            f"{row.cos_gr:.4f}", f"{row.cos_gsrs:.4f}",
            f"{row.cos_br:.4f}", f"{row.cos_bsrs:.4f}",
            f"{row.norm_g:.2f}", f"{row.norm_gs:.2f}",
            f"{row.norm_b:.2f}", f"{row.norm_bs:.2f}",
            f"{row.norm_r:.2f}", f"{row.norm_rs:.2f}",
            f"{row.silhouette:.4f}",
        )
    return tbl


def _orient_2d(safe_2d, harm_2d, geom_median_fn):
    """Rotate projected points so the safe->harm axis is horizontal (safe on left)."""
    anchor_s = geom_median_fn(safe_2d).median
    anchor_h = geom_median_fn(harm_2d).median
    delta = anchor_h - anchor_s
    theta = -math.atan2(float(delta[1]), float(delta[0]))
    ct, st = math.cos(theta), math.sin(theta)
    import numpy as np
    rot = np.array([[ct, -st], [st, ct]])
    rotated = np.concatenate([safe_2d, harm_2d], axis=0) @ rot.T
    boundary = safe_2d.shape[0]
    return rotated[:boundary], rotated[boundary:]


def _project_layers(safe_resid: Tensor, harm_resid: Tensor, n_layers: int) -> list[_Projection2D]:
    import numpy as np
    from geom_median.numpy import compute_geometric_median  # ty:ignore[unresolved-import]
    from pacmap import PaCMAP  # ty:ignore[unresolved-import]

    prev_embedding = None
    projections: list[_Projection2D] = []

    for k in track(range(1, n_layers + 1), description="* Computing PaCMAP projections..."):
        safe_np = safe_resid[:, k, :].detach().cpu().numpy()
        harm_np = harm_resid[:, k, :].detach().cpu().numpy()

        stacked = np.vstack((safe_np, harm_np))
        reducer = PaCMAP(n_components=2, n_neighbors=30)
        flat_2d = reducer.fit_transform(stacked, init=prev_embedding)
        prev_embedding = flat_2d

        cut = safe_np.shape[0]
        s2d, h2d = _orient_2d(flat_2d[:cut], flat_2d[cut:], compute_geometric_median)
        projections.append(_Projection2D(safe_pts=s2d, harm_pts=h2d))

    return projections


def _render_frame(cfg: Settings, dest: Path, layer_num: int, safe_xy, harm_xy):
    """Render a single scatter plot frame to disk."""
    import matplotlib  # ty:ignore[unresolved-import]
    matplotlib.use("Agg")
    from matplotlib.figure import Figure  # ty:ignore[unresolved-import]

    fig = Figure(figsize=(8, 6))
    ax = fig.add_subplot(111)

    ax.scatter(safe_xy[:, 0], safe_xy[:, 1], s=12, alpha=0.55,
               color=cfg.safe_prompts.plot_color,
               label=cfg.safe_prompts.plot_label)
    ax.scatter(harm_xy[:, 0], harm_xy[:, 1], s=12, alpha=0.55,
               color=cfg.harmful_prompts.plot_color,
               label=cfg.harmful_prompts.plot_label)

    ax.set_title(cfg.plot_title, pad=14)
    ax.legend(loc="upper right")
    ax.grid(False)
    ax.set_xticks([])
    ax.set_yticks([])

    fig.text(0.025, 0.02, cfg.model, ha="left", va="bottom", fontsize=11)
    fig.text(0.975, 0.02, f"Layer {layer_num:03}", ha="right", va="bottom", fontsize=11)
    fig.tight_layout()
    fig.subplots_adjust(bottom=0.09)
    fig.savefig(dest, dpi=120)


def _lerp(a, b, t):
    return a + t * (b - a)


def _assemble_gif(cfg: Settings, projections: list[_Projection2D], out_dir: Path):
    import imageio.v3 as iio  # ty:ignore[unresolved-import]
    import matplotlib  # ty:ignore[unresolved-import]
    matplotlib.use("Agg")
    import matplotlib.pyplot as mpl_plt  # ty:ignore[unresolved-import]

    mpl_plt.style.use(cfg.plot_style)

    frames: list = []
    timings: list[int] = []

    for seq, proj in enumerate(track(projections, description="* Generating plots..."), start=1):
        png_path = out_dir / f"layer_{seq:03}.png"
        _render_frame(cfg, png_path, seq, proj.safe_pts, proj.harm_pts)
        frames.append(iio.imread(png_path))
        timings.append(HOLD_MS)

        if seq < len(projections):
            nxt = projections[seq]
            for tw in range(1, TWEEN_STEPS):
                frac = tw / TWEEN_STEPS
                interp_safe = _lerp(proj.safe_pts, nxt.safe_pts, frac)
                interp_harm = _lerp(proj.harm_pts, nxt.harm_pts, frac)

                tween_path = out_dir / f"layer_{seq:03}_frame_{tw:03}.png"
                _render_frame(cfg, tween_path, seq, interp_safe, interp_harm)
                frames.append(iio.imread(tween_path))
                timings.append(TWEEN_MS)
                tween_path.unlink()

    print(step("Generating animation"))
    iio.imwrite(out_dir / "animation.gif", frames, duration=timings, loop=0)


class Analyzer:
    def __init__(
        self,
        settings: Settings,
        model: Model | ParallelModel,
        good_residuals: Tensor,
        bad_residuals: Tensor,
    ):
        self.settings = settings
        self.model = model
        self.good_residuals = good_residuals
        self.bad_residuals = bad_residuals

    def show_geometry(self):
        try:
            from geom_median.torch import compute_geometric_median  # ty:ignore[unresolved-import]
            from sklearn.metrics import silhouette_score  # ty:ignore[unresolved-import]
        except ImportError:
            print()
            print(_MISSING_DEP_HINT.format(action="Printing residual geometry"))
            return

        print()
        print(step("Computing residual geometry"))

        num_positions = len(self.model.decoder_layers()) + 1
        rows = _compute_all_geometry(
            self.good_residuals, self.bad_residuals, num_positions,
            compute_geometric_median, silhouette_score,
        )
        tbl = _format_geometry_table(rows)

        print()
        print(val("Residual Geometry"))
        print(tbl)
        for sym, desc in _LEGEND_LINES:
            print(f"{sym} = {desc}")

    def save_plots(self):
        try:
            import imageio.v3 as iio  # ty:ignore[unresolved-import] # noqa: F401
            import matplotlib.pyplot as plt  # ty:ignore[unresolved-import] # noqa: F401
            import numpy as np  # noqa: F401
            from geom_median.numpy import compute_geometric_median  # ty:ignore[unresolved-import] # noqa: F401
            from numpy.typing import NDArray  # noqa: F401
            from pacmap import PaCMAP  # ty:ignore[unresolved-import] # noqa: F401
        except ImportError:
            print()
            print(_MISSING_DEP_HINT.format(action="Plotting residuals"))
            return

        print()
        print(step("Plotting residual vectors"))

        n_layers = len(self.model.decoder_layers())
        projections = _project_layers(self.good_residuals, self.bad_residuals, n_layers)

        sanitized_name = self.settings.model.replace("/", "_").replace("\\", "_")
        out_dir = Path(self.settings.plot_dir) / sanitized_name
        out_dir.mkdir(parents=True, exist_ok=True)

        _assemble_gif(self.settings, projections, out_dir)
        print(step(f"Plots saved to {val(out_dir.resolve())}  {OK}"))
