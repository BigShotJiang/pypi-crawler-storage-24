# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Copyright (C) 2025  HauhauCS <hauhaut901@gmail.com>

import logging
import warnings
from dataclasses import dataclass

import optuna
import torch
import torch.nn.functional as F
from optuna.samplers import TPESampler
from optuna.study import StudyDirection
from optuna.trial import TrialState

from .analyzer import Analyzer
from .config import ModelType
from .model import LayerEnvelope
from .optimization import run_optimization_loop
from .parallel_model import ParallelModel
from .style import OK, FAIL, WARN, INFO, phase, step, val, dim  # noqa: F401 (dim used at line ~807, shadowed by local in LDA block)
from .utils import Prompt, empty_cache, get_trial_parameters, print


# Capability probing prompts for Surgical Refusal Ablation (SRA).
# Used to extract concept atom directions that protect capability circuits
# during refusal direction orthogonalization.
CAPABILITY_PROBES = {
    "math": [
        "Solve: What is the derivative of x^3 + 2x?",
        "Calculate the integral of sin(x) from 0 to pi.",
        "If f(x) = e^(2x), find f'(x).",
        "What is 247 * 83?",
        "Simplify: (x^2 - 9) / (x - 3)",
    ],
    "code": [
        "Write a Python function to check if a number is prime.",
        "Implement binary search in Python.",
        "Write a function to reverse a linked list.",
        "How do you sort a dictionary by values in Python?",
        "Write a recursive fibonacci function.",
    ],
    "reasoning": [
        "Explain the trolley problem and its ethical implications.",
        "What are the main differences between TCP and UDP?",
        "Describe how a hash table works and its time complexity.",
        "What is the difference between correlation and causation?",
        "Explain the concept of supply and demand.",
    ],
}


def _ridge_orthogonalize(v: torch.Tensor, concept_matrix: torch.Tensor, ridge: float = 0.1) -> torch.Tensor:
    """Ridge-regularized orthogonalization: project out concept directions from v."""
    if not v.isfinite().all() or not concept_matrix.isfinite().all():
        return F.normalize(v.nan_to_num(), p=2, dim=0)
    RRt_reg = concept_matrix @ concept_matrix.T + ridge * torch.eye(
        concept_matrix.shape[0], device=concept_matrix.device, dtype=concept_matrix.dtype
    )
    coeffs = torch.linalg.solve(RRt_reg, concept_matrix @ v)
    return F.normalize(v - concept_matrix.T @ coeffs, p=2, dim=0)


def _compute_som_directions(bad_residuals, good_residuals, num_clusters, num_directions):
    """Cluster harmful residual deviations to find multiple refusal modes.

    Per layer: KMeans on (bad - harmless_mean), greedy diversity-aware selection of
    top-k centroids (pick strongest, then iteratively pick most different).
    Returns (num_layers, num_directions, hidden_dim) tensor.
    """
    from sklearn.cluster import MiniBatchKMeans

    num_layers = bad_residuals.shape[1]
    device, dtype = bad_residuals.device, bad_residuals.dtype
    harmless_mean = good_residuals.mean(dim=0)  # (layers, hidden)
    per_layer = []

    for li in range(num_layers):
        deviations = bad_residuals[:, li, :] - harmless_mean[li]  # (n, hidden)
        n_samples = deviations.shape[0]
        k = min(num_clusters, n_samples)

        if k < 2:
            d = F.normalize(deviations.mean(dim=0, keepdim=True), p=2, dim=1)
            per_layer.append(d.expand(num_directions, -1).clone())
            continue

        km = MiniBatchKMeans(n_clusters=k, random_state=42, n_init=3, batch_size=min(256, n_samples))
        km.fit(deviations.float().cpu().numpy())
        centroids = torch.from_numpy(km.cluster_centers_).to(device=device, dtype=dtype)
        normed = F.normalize(centroids, p=2, dim=1)

        # Greedy diversity selection: start with highest-norm centroid,
        # then pick centroid with lowest max-cosine to already-selected set.
        norms = centroids.norm(dim=1)
        selected = [norms.argmax().item()]
        for _ in range(min(num_directions, k) - 1):
            sel_dirs = normed[selected]  # (num_selected, hidden)
            cosines = (normed @ sel_dirs.T).abs().max(dim=1).values  # (k,)
            cosines[selected] = float("inf")  # exclude already selected
            selected.append(cosines.argmin().item())

        dirs = normed[selected]
        if dirs.shape[0] < num_directions:
            dirs = torch.cat([dirs, dirs[:1].expand(num_directions - dirs.shape[0], -1)])
        per_layer.append(dirs)

    return torch.stack(per_layer)  # (num_layers, num_directions, hidden)


def _compute_contrastive_directions(bad_residuals, good_residuals, num_directions):
    """Contrastive PCA: find directions maximizing Var_bad / Var_good per layer
    via generalized eigenvalue solve (Cholesky whitening). Falls back to standard
    PCA of bad_residuals if Cholesky fails (degenerate good covariance)."""
    num_layers = bad_residuals.shape[1]
    device, dtype = bad_residuals.device, bad_residuals.dtype
    per_layer = []

    for li in range(num_layers):
        X_b = bad_residuals[:, li, :] - bad_residuals[:, li, :].mean(dim=0, keepdim=True)
        X_g = good_residuals[:, li, :] - good_residuals[:, li, :].mean(dim=0, keepdim=True)
        try:
            # Pool and SVD for rank-r subspace (N << d, avoids d×d covariance)
            pooled = torch.cat([X_b, X_g], dim=0)
            r = min(pooled.shape[0], num_directions * 4, pooled.shape[1])
            _, _, Vh = torch.linalg.svd(pooled, full_matrices=False)
            V = Vh[:r]  # (r, d) — basis of active subspace
            # Project into r-space
            B = X_b @ V.T  # (N_bad, r)
            G = X_g @ V.T  # (N_good, r)
            C_bad = (B.T @ B) / max(B.shape[0] - 1, 1)
            C_good = (G.T @ G) / max(G.shape[0] - 1, 1)
            # Regularize C_good (floor ensures PD even with degenerate good data)
            eps = max(1e-4 * C_good.trace().item() / C_good.shape[0], 1e-6)
            C_good_reg = C_good + eps * torch.eye(r, device=device, dtype=dtype)
            L = torch.linalg.cholesky(C_good_reg)
            # M = L^{-1} C_bad L^{-T} via triangular solves (no explicit inverse)
            temp = torch.linalg.solve_triangular(L, C_bad, upper=False)
            M = torch.linalg.solve_triangular(L, temp.T, upper=False).T
            eigvals, eigvecs = torch.linalg.eigh(M)
            # eigh returns ascending — take last k (highest variance ratio)
            k_actual = min(num_directions, eigvecs.shape[1])
            top_z = eigvecs[:, -k_actual:].flip(dims=[1])  # (r, k)
            # Un-whiten: w = L^{-T} z to get generalized eigenvectors
            top_w = torch.linalg.solve_triangular(L.T, top_z, upper=True)  # (r, k)
            dirs = F.normalize(top_w.T @ V, p=2, dim=1)  # (k, d)
            if dirs.shape[0] < num_directions:
                dirs = torch.cat([dirs, dirs[:1].expand(num_directions - dirs.shape[0], -1)])
        except RuntimeError:
            # Fallback: standard PCA of bad residuals only (handles ill-conditioned SVD too)
            try:
                _, _, Vh_b = torch.svd_lowrank(X_b, q=min(num_directions, X_b.shape[0]))
                dirs = F.normalize(Vh_b[:, :num_directions].T, p=2, dim=1)
            except RuntimeError:
                # Double fallback: SVD totally failed, use mean direction as all PCA dirs
                dirs = F.normalize(X_b.mean(dim=0, keepdim=True), p=2, dim=1)
            if dirs.shape[0] < num_directions:
                dirs = torch.cat([dirs, dirs[:1].expand(num_directions - dirs.shape[0], -1)])
        per_layer.append(dirs)

    # Transpose from (num_layers, num_pca, d) to (num_pca, num_layers, d)
    return torch.stack([
        torch.stack([per_layer[li][k] for li in range(num_layers)])
        for k in range(num_directions)
    ])


def resolve_trial_directions(trial, mean_direction, pca_directions, svd_directions,
                              positions=None, good_residuals_multipos=None, bad_residuals_multipos=None):
    """Given a completed trial, reconstruct the refusal directions used."""
    if svd_directions is not None:
        return svd_directions

    mode = trial.user_attrs.get("blend_mode", "mean")

    # Reconstruct position-weighted direction if trial used multi-position weighting
    pw = trial.user_attrs.get("position_weights")
    if pw and good_residuals_multipos is not None:
        raw = [float(pw[str(p)]) for p in positions]
        total = sum(raw)
        w = torch.tensor([r / total for r in raw], device=good_residuals_multipos.device)
        weighted_dir = F.normalize(
            torch.einsum('p,npld->nld', w, bad_residuals_multipos).mean(0)
            - torch.einsum('p,npld->nld', w, good_residuals_multipos).mean(0),
            p=2, dim=1,
        )
    else:
        weighted_dir = None

    if mode == "combined":
        weights = trial.user_attrs.get("direction_weights", {})
        base = weighted_dir if weighted_dir is not None else mean_direction
        dirs = float(weights.get("mean", 0.0)) * base
        if pca_directions is not None:
            for i in range(pca_directions.shape[0]):
                dirs = dirs + float(weights.get(f"pca_{i+1}", 0.0)) * pca_directions[i]
        return F.normalize(dirs, p=2, dim=1)
    elif mode == "mean" or pca_directions is None:
        return weighted_dir if weighted_dir is not None else mean_direction
    else:
        idx = int(mode.split("_")[1]) - 1
        return pca_directions[idx]


@torch.no_grad()
def _compute_cosmic_scores(bad_residuals, good_residuals, mean_direction):
    """COSMIC-inspired cosine-similarity layer scoring.

    For each layer, combines two signals:
    - s_refuse: Cohen's d separability of projections onto refusal direction
    - s_comply: mean cosine similarity between bad deviations and refusal direction

    Returns (L+1,) tensor normalized to [0, 1] over layers 1:.
    """
    num_layers = mean_direction.shape[0]
    scores = torch.zeros(num_layers, device=mean_direction.device, dtype=mean_direction.dtype)
    for li in range(1, num_layers):
        d = mean_direction[li]
        d_norm = d / d.norm().clamp(min=1e-8)
        # S_refuse: projection separability (Cohen's d)
        bad_proj = bad_residuals[:, li, :] @ d_norm
        good_proj = good_residuals[:, li, :] @ d_norm
        pooled_std = ((bad_proj.var(correction=0) + good_proj.var(correction=0)) / 2).sqrt().clamp(min=1e-8)
        s_refuse = (bad_proj.mean() - good_proj.mean()).abs() / pooled_std
        # S_comply: mean cosine similarity of bad deviations with refusal direction
        good_mean = good_residuals[:, li, :].mean(dim=0)
        bad_dev = bad_residuals[:, li, :] - good_mean
        bad_dev_normed = bad_dev / bad_dev.norm(dim=1, keepdim=True).clamp(min=1e-8)
        s_comply = (bad_dev_normed @ d_norm).mean().clamp(min=0)
        scores[li] = s_refuse * s_comply
    # Normalize to [0, 1] over layers 1:
    max_score = scores[1:].max().clamp(min=1e-8)
    scores = scores / max_score
    scores[0] = 0.0
    return scores


def replay_trial(model, trial, directions, layer_separability):
    """Reset model and apply abliteration from a completed trial."""
    print(phase(f"trial {trial.user_attrs['index']}", "restoring model"))
    print(step("parameters:"))
    for name, value in get_trial_parameters(trial).items():
        print(f"    {INFO} {name} = {val(value)}")

    head_mask = None
    if "head_mask" in trial.user_attrs:
        head_mask = torch.tensor(trial.user_attrs["head_mask"], dtype=torch.float32)

    proj_strength = trial.user_attrs.get("projection_strength", 1.0)
    sep_threshold = trial.user_attrs.get("separability_threshold", 0.0)
    dir_scales = trial.user_attrs.get("direction_scales")
    if "sparsity_threshold" in trial.user_attrs:
        sparsity = trial.user_attrs["sparsity_threshold"]
        if isinstance(model, ParallelModel):
            model.set_sparsity_threshold(sparsity)
        else:
            model.settings.sparsity_threshold = sparsity

    print(step("resetting model..."))
    model.reset_model()
    print(step("abliterating..."))
    model.abliterate(
        directions,
        trial.user_attrs["layer_focus"],
        {k: LayerEnvelope(**v) for k, v in trial.user_attrs["parameters"].items()},
        head_mask,
        proj_strength,
        layer_separability,
        sep_threshold,
        dir_scales,
    )


def _rdo_refine_direction(model_obj, settings, mean_direction, safe_prompts, harmful_prompts, rdo_seed=None):
    """Gradient-optimize refusal direction via first-token logit loss + KL penalty."""
    print(phase("RDO", "gradient-optimizing refusal direction"))
    if isinstance(model_obj, ParallelModel):
        logging.warning("RDO runs on single GPU (~2 min), multi-GPU resumes for optimization")

    model = model_obj.model
    tokenizer = model_obj.tokenizer
    device = next(model.parameters()).device

    if rdo_seed is None:
        rdo_seed = settings.rdo_seed
    if rdo_seed is None:
        rdo_seed = torch.randint(0, 2**31, (1,)).item()
    rng_state = torch.random.get_rng_state()
    cuda_rng_state = torch.cuda.get_rng_state(device) if device.type == "cuda" else None
    torch.manual_seed(rdo_seed)
    if device.type == "cuda":
        torch.cuda.manual_seed(rdo_seed)
    print(step(f"RDO seed: {val(rdo_seed)}"))

    # Free fragmented VRAM from residual extraction before gradient-heavy RDO
    empty_cache()

    # FP8 models: weights already fill ~95% VRAM, less room for activation storage
    is_fp8 = hasattr(model_obj, "is_fp8") and model_obj.is_fp8()
    n = min(12 if is_fp8 else 32, len(safe_prompts), len(harmful_prompts))
    if is_fp8:
        pool_size = min(48, len(safe_prompts), len(harmful_prompts))
        print(step(f"FP8 model: using {val(n)}/{val(pool_size)} prompts per RDO step (rotating pool)"))
        good_pool = model_obj.tokenize_prompts(safe_prompts[:pool_size])
        bad_pool = model_obj.tokenize_prompts(harmful_prompts[:pool_size])
        good_enc = bad_enc = None  # selected per step
    else:
        good_enc = model_obj.tokenize_prompts(safe_prompts[:n]).to(device)
        bad_enc = model_obj.tokenize_prompts(harmful_prompts[:n]).to(device)

    # Build refusal token index from markers
    refusal_ids = set()
    for marker in settings.refusal_keywords:
        refusal_ids.update(tokenizer.encode(marker, add_special_tokens=False))
    refusal_idx = torch.tensor(list(refusal_ids), device=device, dtype=torch.long)
    if refusal_idx.numel() == 0:
        print(f"  {WARN} no refusal tokens found, skipping RDO")
        torch.random.set_rng_state(rng_state)
        if cuda_rng_state is not None:
            torch.cuda.set_rng_state(cuda_rng_state, device)
        return mean_direction, rdo_seed

    # Trainable direction in fp32 for Adam stability
    v = torch.nn.Parameter(mean_direction.clone().detach().float().to(device))
    lr = settings.rdo_lr * (0.3 if is_fp8 else 1.0)
    optimizer = torch.optim.Adam([v], lr=lr)

    # Cache baseline harmless logprobs (no hooks)
    model_obj.reset_model()
    # Clear stale 3D position cache (multimodal models like Qwen3.5 cache
    # rope_deltas from prior forward — batch size mismatch if reused)
    for m in model.modules():
        if hasattr(m, "rope_deltas"):
            m.rope_deltas = None
    if is_fp8:
        # Compute baseline for full pool before hooks, keep on CPU for per-step slicing
        baseline_parts = []
        for j in range(pool_size):
            inp = {k: t[j:j+1].to(device) for k, t in good_pool.items()}
            with torch.no_grad():
                lp = F.log_softmax(model(input_ids=inp["input_ids"], attention_mask=inp["attention_mask"], use_cache=False).logits[:, -1, :], dim=-1)
            baseline_parts.append(lp.cpu())
        baseline_pool = torch.cat(baseline_parts, dim=0)
        baseline = None
        empty_cache()
    else:
        with torch.no_grad():
            baseline = F.log_softmax(
                model(input_ids=good_enc["input_ids"], attention_mask=good_enc["attention_mask"], use_cache=False).logits[:, -1, :],
                dim=-1,
            )

    # Collect residual-stream output modules only (skip gate/up which output
    # to MLP intermediate space — direction is in hidden_dim space)
    layer_count = len(model_obj.decoder_layers())
    all_modules = []  # (layer_idx, module)
    for li in range(layer_count):
        for comp_key, targets in model_obj.layer_components(li).items():
            if "gate_proj" in comp_key or "up_proj" in comp_key:
                continue
            for mod in targets:
                all_modules.append((li, mod))

    # Register forward hooks — each captures a live slice of v
    hooks = []
    for li, mod in all_modules:
        # li+1 because index 0 is embedding layer in direction tensor
        def _hook(module, inp, output, _li=li, _v=v, _detach=is_fp8):
            if _detach:
                output = output.detach()
            v_norm = F.normalize(_v[_li + 1].to(device=output.device, dtype=output.dtype), dim=0)
            if output.shape[-1] != v_norm.shape[0]:
                return output
            proj = (output @ v_norm).unsqueeze(-1)
            return output - proj * v_norm
        hooks.append(mod.register_forward_hook(_hook))

    # Gradient checkpointing for FP8: avoid saving inter-hook activation tensors
    # (~25-30 GiB on 122B models). Recomputes activations per-layer during backward.
    # Must call on the unwrapped HF model — PEFT's __getattr__ delegation doesn't
    # reliably set _gradient_checkpointing on decoder layers.
    _inner = model.base_model.model if hasattr(model, "base_model") else model
    _ckpt = is_fp8 and hasattr(_inner, "gradient_checkpointing_enable")
    if _ckpt:
        _inner.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})

    if is_fp8:
        for i in range(torch.cuda.device_count()):
            a = torch.cuda.memory_allocated(i) / 2**30
            r = torch.cuda.memory_reserved(i) / 2**30
            f = (torch.cuda.get_device_properties(i).total_memory / 2**30) - r
            print(step(f"GPU {i}: {a:.1f} GiB alloc, {r:.1f} GiB reserved, ~{f:.1f} GiB free"))

    # Gradient loop — use per-sample accumulation for FP8 (VRAM-constrained)
    # Training mode required: gradient checkpointing only activates when self.training=True
    if _ckpt:
        _inner.train()
    try:
        with torch.enable_grad():
            for step_i in range(settings.rdo_steps):
                optimizer.zero_grad()

                if is_fp8:
                    # Rotate prompt slice across steps for diversity
                    offset = (step_i * n) % pool_size
                    idx = [(offset + j) % pool_size for j in range(n)]
                    bad_enc = {k: t[idx].to(device) for k, t in bad_pool.items()}
                    good_enc = {k: t[idx].to(device) for k, t in good_pool.items()}
                    baseline = baseline_pool[idx].to(device)

                    # Gradient accumulation: process one prompt at a time to avoid
                    # OOM from activation storage on VRAM-packed FP8 models.
                    refusal_acc, kl_acc = 0.0, 0.0
                    for j in range(n):
                        bad_logits = model(
                            input_ids=bad_enc["input_ids"][j:j+1],
                            attention_mask=bad_enc["attention_mask"][j:j+1],
                            use_cache=False,
                        ).logits[:, -1, :]
                        r = F.log_softmax(bad_logits, dim=-1)[:, refusal_idx].logsumexp(dim=-1).mean() / n
                        r.backward()
                        refusal_acc += r.item()

                    empty_cache()
                    for j in range(n):
                        good_logits = model(
                            input_ids=good_enc["input_ids"][j:j+1],
                            attention_mask=good_enc["attention_mask"][j:j+1],
                            use_cache=False,
                        ).logits[:, -1, :]
                        good_lp = F.log_softmax(good_logits, dim=-1)
                        k = F.kl_div(good_lp, baseline[j:j+1], log_target=True, reduction="batchmean")
                        (settings.rdo_kl_weight * k / n).backward()
                        kl_acc += k.item() / n

                    optimizer.step()
                    refusal_loss_val, kl_loss_val = refusal_acc, kl_acc
                else:
                    # Batched path for non-FP8 models (original behavior)
                    bad_logits = model(input_ids=bad_enc["input_ids"], attention_mask=bad_enc["attention_mask"], use_cache=False).logits[:, -1, :]
                    bad_lp = F.log_softmax(bad_logits, dim=-1)
                    refusal_loss = bad_lp[:, refusal_idx].logsumexp(dim=-1).mean()

                    good_logits = model(input_ids=good_enc["input_ids"], attention_mask=good_enc["attention_mask"], use_cache=False).logits[:, -1, :]
                    good_lp = F.log_softmax(good_logits, dim=-1)
                    kl_loss = F.kl_div(good_lp, baseline, log_target=True, reduction="batchmean")

                    loss = refusal_loss + settings.rdo_kl_weight * kl_loss
                    loss.backward()
                    optimizer.step()
                    refusal_loss_val, kl_loss_val = refusal_loss.item(), kl_loss.item()

                # Project back to unit sphere per layer
                with torch.no_grad():
                    v.data = F.normalize(v.data, p=2, dim=1)

                if (step_i + 1) % 20 == 0:
                    print(step(f"step {val(step_i + 1)}/{settings.rdo_steps}  "
                               f"refusal={val(f'{refusal_loss_val:.3f}')}  "
                               f"KL={val(f'{kl_loss_val:.3f}')}"))
    finally:
        for h in hooks:
            h.remove()
        if _ckpt:
            _inner.gradient_checkpointing_disable()
            _inner.eval()

    result = v.data.clone().to(device=mean_direction.device, dtype=mean_direction.dtype)
    del v, optimizer
    model_obj.reset_model()
    empty_cache()
    torch.random.set_rng_state(rng_state)
    if cuda_rng_state is not None:
        torch.cuda.set_rng_state(cuda_rng_state, device)
    print(step(f"RDO refinement complete {OK}"))
    return result, rdo_seed


def _classify_still_refusing(model, settings, evaluator, harmful_prompts,
                             *, max_tokens=None, batch_cap=None):
    """Generate responses and classify which harmful prompts still refuse.

    Returns list of indices into harmful_prompts that are still refusing.
    """
    tok_bad = model.tokenize_prompts(harmful_prompts)
    reasoning = settings.model_type == ModelType.REASONING
    budget = (min(256, settings.reasoning_max_length) if reasoning
              else (max_tokens if max_tokens is not None else settings.max_new_tokens))
    saved_bs = model.settings.batch_size
    if batch_cap:
        model.settings.batch_size = min(saved_bs, batch_cap)
    try:
        responses = model.get_responses_batched(
            tokenized_inputs=tok_bad, skip_special_tokens=True,
            early_exit_markers=None if reasoning else settings.refusal_keywords,
            max_new_tokens=budget,
        )
    finally:
        model.settings.batch_size = saved_bs
    verdicts = evaluator._classifier.classify_batch(
        responses, truncation_ok=reasoning,
        prompts=[p.user for p in harmful_prompts],
    )
    still_refusing = [i for i, v in enumerate(verdicts) if v]
    del tok_bad, responses
    empty_cache()
    return still_refusing


def _deep_refine_directions(model, settings, evaluator, svd_directions,
                            mean_direction, safe_prompts, harmful_prompts,
                            positions, layer_separability):
    """Deep ablation with existing multi-direction (SOM/rank-k).

    Quick optimization → filter still-refusing → re-extract → re-cluster.
    Returns refined svd_directions or None if all prompts already answered.
    """
    print(phase("deep refinement", "filtering with existing directions"))

    study = optuna.create_study(
        sampler=TPESampler(n_startup_trials=20, multivariate=True),
        directions=[StudyDirection.MINIMIZE, StudyDirection.MINIMIZE],
    )
    _, _ = run_optimization_loop(
        model=model, evaluator=evaluator, settings=settings, study=study,
        mean_direction=mean_direction, pca_directions=None, blend_modes=["mean"],
        positions=positions, good_residuals_multipos=None, bad_residuals_multipos=None,
        seed_params_file=None, layer_separability=layer_separability,
        svd_directions=svd_directions, total_trials=50,
    )
    completed = [t for t in study.trials if t.state == TrialState.COMPLETE]
    if not completed:
        print(f"  {WARN} no completed trials, skipping deep refinement")
        return None

    best = min(completed, key=lambda t: t.values[1])
    kl_val = best.user_attrs.get('kl_divergence', 0)
    print(step(f"best preliminary trial: refusals={val(best.user_attrs.get('refusals', '?'))}, "
               f"KL={val(f'{kl_val:.4f}')}"))

    replay_trial(model, best, svd_directions, layer_separability)

    print(step("classifying training prompts after initial ablation..."))
    still_refusing = _classify_still_refusing(
        model, settings, evaluator, harmful_prompts,
        max_tokens=min(settings.max_new_tokens, 80), batch_cap=32,
    )
    n_refusing = len(still_refusing)
    print(step(f"still refusing: {val(n_refusing)}/{len(harmful_prompts)}"))

    # When most prompts are already handled, the original directions are good —
    # re-clustering from a tiny subset produces noise, not signal.
    min_samples = max(2 * settings.som_clusters, 30)
    if n_refusing == 0:
        print(f"  {WARN} all prompts answered, keeping original directions")
        model.reset_model()
        return None
    if n_refusing < min_samples:
        pct = 100 * n_refusing / len(harmful_prompts)
        print(f"  {WARN} only {n_refusing} still-refusing ({pct:.0f}%) — too few to re-cluster "
              f"(need {min_samples}+), keeping original directions")
        model.reset_model()
        return None
    filtered_harmful = [harmful_prompts[i] for i in still_refusing]

    # Re-extract residuals through ablated model
    print(step(f"re-extracting residuals from {val(len(filtered_harmful))} still-refusing prompts..."))
    new_bad = model.get_residuals_batched(filtered_harmful, positions if len(positions) == 1 else None)
    new_good = model.get_residuals_batched(safe_prompts, positions if len(positions) == 1 else None)
    if new_bad.ndim == 4:
        new_bad = new_bad.mean(dim=1)
    if new_good.ndim == 4:
        new_good = new_good.mean(dim=1)

    # Re-run SOM clustering on filtered residuals
    k = svd_directions.shape[1]
    new_clusters = min(settings.som_clusters, max(k + 1, n_refusing // 2))
    print(step(f"re-clustering into {val(new_clusters)} clusters..."))
    refined = _compute_som_directions(new_bad, new_good, new_clusters, k)

    del new_bad, new_good
    empty_cache()
    model.reset_model()
    print(step(f"deep refinement complete, shape: {val(refined.shape)}"))
    return refined


def _iterative_refine(model, settings, evaluator, mean_direction,
                      safe_prompts, harmful_prompts, positions, layer_separability):
    """Run abbreviated rank-1, extract secondary direction, return stacked rank-2 directions."""
    print(phase("iterative refinement", "initial rank-1 pass"))

    orig_rank = settings.ablation_rank

    # Fixed-strength rank-1 probe (flat envelope, moderate strength)
    n_layers = mean_direction.shape[0]
    envelope = LayerEnvelope(peak=1.0, peak_position=n_layers // 2, floor=1.0, floor_distance=n_layers)
    probe_params = {comp: envelope for comp in model.ablation_targets()}
    model.reset_model()
    model.abliterate(mean_direction, layer_focus=None, parameters=probe_params,
                     projection_strength=0.5, layer_separability=layer_separability)

    # Classify which prompts still refuse after rank-1 probe
    print(step("classifying training prompts after rank-1 probe..."))
    still_refusing = _classify_still_refusing(
        model, settings, evaluator, harmful_prompts,
    )
    n_refusing = len(still_refusing)
    print(step(f"still refusing: {val(n_refusing)}/{len(harmful_prompts)}"))
    if n_refusing == 0:
        print(f"  {WARN} rank-1 fully resolved refusals, skipping secondary extraction")
        model.reset_model()
        return None
    if n_refusing < 20:
        pct = 100 * n_refusing / len(harmful_prompts)
        print(f"  {WARN} only {n_refusing} still-refusing ({pct:.0f}%) — too few for "
              f"meaningful secondary direction, skipping")
        model.reset_model()
        return None
    harmful_prompts = [harmful_prompts[i] for i in still_refusing]

    # Re-extract residuals through ablated model
    print(step("re-extracting residuals through ablated model..."))
    new_bad = model.get_residuals_batched(harmful_prompts, positions if len(positions) == 1 else None)
    new_good = model.get_residuals_batched(safe_prompts, positions if len(positions) == 1 else None)
    if new_bad.ndim == 4:
        new_bad = new_bad.mean(dim=1)
    if new_good.ndim == 4:
        new_good = new_good.mean(dim=1)

    secondary = F.normalize(new_bad.mean(dim=0) - new_good.mean(dim=0), p=2, dim=1)

    # Apply projected_direction to secondary (same as primary)
    if settings.projected_direction:
        good_dir = F.normalize(new_good.mean(dim=0), p=2, dim=1)
        dot = (secondary * good_dir).sum(dim=1, keepdim=True)
        secondary = F.normalize(secondary - dot * good_dir, p=2, dim=1)

    del new_bad, new_good
    empty_cache()

    # Stack and orthogonalize via Gram-Schmidt
    num_layers, hidden = mean_direction.shape
    svd_dirs = torch.zeros(num_layers, 2, hidden, device=mean_direction.device, dtype=mean_direction.dtype)
    svd_dirs[:, 0, :] = mean_direction
    for li in range(num_layers):
        v0 = svd_dirs[li, 0]
        v1 = secondary[li] - (secondary[li] @ v0) * v0
        norm = v1.norm()
        if norm > 1e-6:
            svd_dirs[li, 1] = v1 / norm

    model.reset_model()
    settings.ablation_rank = max(orig_rank, 2)
    print(step(f"secondary direction extracted, rank-{val(settings.ablation_rank)} optimization"))
    return svd_dirs


def routing_analysis(model, settings, safe_prompts, harmful_prompts) -> tuple[dict[int, list[int]], dict[int, list[float]]]:
    """Diagnostic: compare MoE expert activation frequencies on harmful vs harmless prompts.

    Returns dict mapping layer_idx -> list of super expert indices (data-agnostic, high-frequency
    experts whose removal causes model collapse). Empty dict if no MoE or no super experts found.
    """
    print(phase("routing analysis", "MoE expert activation frequencies"))
    layers = model.decoder_layers()

    # Find router modules: try common paths (mlp.gate, block_sparse_moe.gate, moe.gate)
    router_paths = ["mlp.gate", "block_sparse_moe.gate", "moe.gate", "mlp.router"]
    routers = []
    for li, layer in enumerate(layers):
        for path in router_paths:
            mod = layer
            try:
                for part in path.split("."):
                    mod = getattr(mod, part)
                routers.append((li, mod, path))
                break
            except AttributeError:
                continue
    if not routers:
        print(f"  {WARN} no MoE router modules found — this model is not MoE or uses an unsupported router path")
        return {}, {}

    num_experts = routers[0][1].out_features if hasattr(routers[0][1], "out_features") else None
    if num_experts is None:
        print(f"  {FAIL} could not determine num_experts from router")
        return {}, {}

    # Read top-k from model config (varies by arch: Qwen3-30B top-8, Qwen3.5-35B top-9, Mixtral top-2)
    cfg = model.model.config
    top_k = getattr(cfg, "num_experts_per_tok", None) or getattr(cfg, "num_selected_experts", None) or 2
    print(step(f"found {val(len(routers))} routers ({val(routers[0][2])}), {val(num_experts)} experts, top-{val(top_k)} routing"))

    # Hook all routers to accumulate top-k expert selections
    freq_harmful = torch.zeros(len(layers), num_experts)
    freq_harmless = torch.zeros(len(layers), num_experts)
    token_counts = torch.zeros(2)  # [harmful_tokens, harmless_tokens]

    def _make_hook(target_freq, layer_idx, count_idx):
        def hook(_mod, _inp, out):
            logits = out if isinstance(out, torch.Tensor) else out[0]
            k = min(top_k, logits.shape[-1])
            selected = logits.topk(k, dim=-1).indices  # (batch*seq, k) or (batch, seq, k)
            flat = selected.reshape(-1)
            # Count tokens only from first router layer to avoid double-counting
            if layer_idx == routers[0][0]:
                token_counts[count_idx] += flat.numel() / k
            for eidx in flat.tolist():
                if 0 <= eidx < num_experts:
                    target_freq[layer_idx, eidx] += 1
        return hook

    def _run_with_hooks(prompts, target_freq, count_idx):
        hooks = []
        for li, router_mod, _ in routers:
            hooks.append(router_mod.register_forward_hook(_make_hook(target_freq, li, count_idx)))
        try:
            bs = settings.batch_size or 4
            for i in range(0, len(prompts), bs):
                batch = prompts[i:i + bs]
                enc = model.tokenize_prompts(batch).to(model.model.device)
                with torch.no_grad():
                    model._backbone()(**enc)
        finally:
            for h in hooks:
                h.remove()

    _run_with_hooks(harmful_prompts, freq_harmful, 0)
    _run_with_hooks(safe_prompts, freq_harmless, 1)

    # Super expert detection: experts activated on nearly ALL tokens regardless of input.
    # Paper: "Unveiling Super Experts" (ICLR 2026) — ~3/6144 in Qwen3-30B-A3B are "super experts."
    # Super experts are data-agnostic (structural), distinct from refusal experts.
    # Pruning them causes model collapse. Detection: activation rate >3σ above layer mean.
    # Super expert counts are model-specific. Qwen3-30B-A3B has ~3/6144 (128 experts/layer × 48 layers),
    # Qwen3.5-35B-A3B differs (256 experts/layer × 40 layers = 10,240 total).
    total_tokens = token_counts.sum().item()
    combined_raw = freq_harmful + freq_harmless  # raw selection counts across all prompts
    super_experts: dict[int, list[int]] = {}
    if total_tokens > 0:
        activation_rate = combined_raw / total_tokens  # fraction of tokens each expert was selected on
        for li in range(len(layers)):
            layer_rates = activation_rate[li]
            mean_rate = layer_rates.mean().item()
            std_rate = layer_rates.std().item()
            if std_rate > 0:
                outliers = (layer_rates > mean_rate + 3 * std_rate).nonzero(as_tuple=True)[0].tolist()
                if outliers:
                    super_experts[li] = outliers

    # Normalize to frequencies
    freq_harmful /= freq_harmful.sum(dim=1, keepdim=True).clamp(min=1)
    freq_harmless /= freq_harmless.sum(dim=1, keepdim=True).clamp(min=1)
    ratio = freq_harmful / freq_harmless.clamp(min=1e-8)

    # Report per-layer top biased experts
    print(step("expert routing bias (harmful/harmless frequency ratio):"))
    mean_ratio = ratio.mean(dim=0)
    sorted_experts = mean_ratio.argsort(descending=True)
    print(f"  {'Expert':>8}  {'Ratio':>8}  {'Harmful%':>9}  {'Harmless%':>10}")
    for eidx in sorted_experts[:20]:
        r = mean_ratio[eidx].item()
        h = freq_harmful[:, eidx].mean().item() * 100
        s = freq_harmless[:, eidx].mean().item() * 100
        marker = " <<< refusal-biased" if r > 1.5 else ""
        print(f"  {eidx:>8d}  {r:>8.3f}  {h:>8.2f}%  {s:>9.2f}%{marker}")

    refusal_experts = (mean_ratio > 1.5).sum().item()
    print(step(f"{val(refusal_experts)} experts with ratio > 1.5 (refusal-biased)"))

    # Report super experts
    total_super = sum(len(v) for v in super_experts.values())
    unique_super = sorted(set(e for ids in super_experts.values() for e in ids))
    if total_super > 0:
        print(step(f"detected {val(total_super)} super expert activations across {val(len(super_experts))} layers"))
        print(f"  {WARN} super experts detected — ablating these would cause model collapse")
        print(f"  unique super expert IDs: {unique_super}")
    else:
        print(step("no super experts detected (none with activation rate >3σ above layer mean)"))

    # Per-layer refusal-bias ratios for continuous expert scaling during export
    router_layers = {li for li, _, _ in routers}
    refusal_ratios = {li: ratio[li].tolist() for li in router_layers}
    return super_experts, refusal_ratios


@dataclass
class DirectionResult:
    """All direction tensors and metadata produced by the analysis phase."""
    mean_direction: torch.Tensor
    pca_directions: torch.Tensor | None
    svd_directions: torch.Tensor | None
    blend_modes: list[str]
    positions: list[int]
    good_residuals_multipos: torch.Tensor | None
    bad_residuals_multipos: torch.Tensor | None
    layer_separability: torch.Tensor | None
    rdo_seed: int | None = None

    def save(self, path: str) -> None:
        """Persist direction tensors so trials replayed on restart use the same directions."""
        torch.save({
            "mean_direction": self.mean_direction.cpu(),
            "pca_directions": self.pca_directions.cpu() if self.pca_directions is not None else None,
            "svd_directions": self.svd_directions.cpu() if self.svd_directions is not None else None,
            "blend_modes": self.blend_modes,
            "layer_separability": self.layer_separability.cpu() if self.layer_separability is not None else None,
            "rdo_seed": self.rdo_seed,
        }, path)

    @staticmethod
    def load(path: str, device: torch.device, positions: list[int]) -> "DirectionResult":
        """Load cached direction tensors from disk."""
        data = torch.load(path, map_location=device, weights_only=True)
        return DirectionResult(
            mean_direction=data["mean_direction"].to(device),
            pca_directions=data["pca_directions"].to(device) if data["pca_directions"] is not None else None,
            svd_directions=data["svd_directions"].to(device) if data["svd_directions"] is not None else None,
            blend_modes=data["blend_modes"],
            positions=positions,
            good_residuals_multipos=None,
            bad_residuals_multipos=None,
            layer_separability=data["layer_separability"].to(device) if data["layer_separability"] is not None else None,
            rdo_seed=data.get("rdo_seed"),
        )


def compute_directions(model, settings, evaluator, safe_prompts, harmful_prompts) -> DirectionResult:
    """Compute all refusal directions: mean, PCA, SVD, SRA, RDO, COSMIC, iterative refinement."""
    print(phase("analysis", "computing refusal directions"))

    # Determine positions to extract residuals from
    positions = [-1]  # Default: last position only

    if settings.multi_position_residuals:
        positions = settings.residual_positions
        print(step(f"multi-position residuals: positions {val(positions)}"))

    empty_cache()  # free evaluator baseline allocations before heavy extraction
    print(step("obtaining residuals for safe prompts..."))
    good_residuals = model.get_residuals_batched(safe_prompts, positions)
    print(step("obtaining residuals for harmful prompts..."))
    bad_residuals = model.get_residuals_batched(harmful_prompts, positions)

    # Handle multi-position residuals
    if len(positions) > 1:
        # Shape: (prompt, position, layer, component)
        # For mean direction, average across positions with equal weights
        # Trial can adjust weights via position_weights parameter
        good_residuals_combined = good_residuals.mean(dim=1)  # (prompt, layer, component)
        bad_residuals_combined = bad_residuals.mean(dim=1)
        # Store original for weighted combinations in trials
        good_residuals_multipos = good_residuals
        bad_residuals_multipos = bad_residuals
        good_residuals = good_residuals_combined
        bad_residuals = bad_residuals_combined
    else:
        good_residuals_multipos = None
        bad_residuals_multipos = None

    # Winsorize: clamp per-prompt residual magnitudes at a quantile threshold
    # to reduce influence of outlier activations on direction estimation.
    if settings.winsorize_residuals > 0:
        q = 1.0 - settings.winsorize_residuals
        cap = 0.0
        for residuals in (good_residuals, bad_residuals):
            norms = residuals.norm(dim=2, keepdim=True)  # (prompts, layers, 1)
            finite_norms = norms.flatten()
            finite_norms = finite_norms[finite_norms.isfinite()]
            if finite_norms.numel() == 0:
                continue
            cap = torch.quantile(finite_norms, q)
            scale = (cap / norms.clamp(min=1e-8)).clamp(max=1.0)
            residuals.mul_(scale)
        print(step(f"winsorized residuals at {val(f'{q:.0%}')} quantile (cap={val(f'{cap:.4f}')})"))

    # Detect layer types for layer-type-aware direction extraction (F12)
    # Residual index 0 = embedding output, index i+1 = decoder layer i output.
    # Direction at index i is influenced by decoder layer i-1, so map residual index -> layer type.
    n_residual_layers = bad_residuals.shape[1]
    n_decoder = len(model.decoder_layers())
    layer_type_map = {}  # residual_idx -> "attn" | "linear_attn" | "mixed"
    for li in range(n_decoder):
        comps = model.layer_components(li)
        has_attn = "attn.o_proj" in comps
        has_linear = "linear_attn.out_proj" in comps
        ri = li + 1  # residual index offset
        if ri < n_residual_layers:
            layer_type_map[ri] = "attn" if has_attn and not has_linear else "linear_attn" if has_linear and not has_attn else "mixed"
    types_present = set(layer_type_map.values()) - {"mixed"}
    is_hybrid = len(types_present) > 1

    # Direction extraction: LEACE > LDA > mean-difference
    if settings.leace_direction:
        try:
            from concept_erasure import LeaceFitter
        except ImportError:
            raise ImportError("--leace-direction requires `concept-erasure`: pip install concept-erasure")
        if settings.lda_direction:
            print(f"  {WARN} --lda-direction ignored when --leace-direction is enabled")
        mean_direction = torch.zeros(n_residual_layers, bad_residuals.shape[2], device=bad_residuals.device, dtype=bad_residuals.dtype)
        n_bad, n_good = bad_residuals.shape[0], good_residuals.shape[0]
        labels = torch.zeros(n_bad + n_good, 2, device=bad_residuals.device)
        labels[:n_bad, 1] = 1.0
        labels[n_bad:, 0] = 1.0
        for li in range(n_residual_layers):
            acts = torch.cat([bad_residuals[:, li, :], good_residuals[:, li, :]], dim=0).float()
            if n_bad < 1 or n_good < 1:
                mean_direction[li] = F.normalize(bad_residuals[:, li, :].mean(0) - good_residuals[:, li, :].mean(0), p=2, dim=0)
                continue
            fitter = LeaceFitter(acts.shape[1], 2, dtype=torch.float32, device=acts.device)
            fitter.update(acts, labels)
            direction = fitter.eraser.proj_left.squeeze()
            if direction.dim() > 1:
                direction = direction[:, 0]
            diff = bad_residuals[:, li, :].mean(0) - good_residuals[:, li, :].mean(0)
            if (direction @ diff) < 0:
                direction = -direction
            mean_direction[li] = F.normalize(direction.to(mean_direction.dtype), p=2, dim=0)
        print(step("LEACE direction extraction", f"{val(n_residual_layers)} layers"))
    elif settings.lda_direction:
        # Fisher LDA: w = S_w^{-1} @ (mean_bad - mean_good)
        mean_bad = bad_residuals.mean(dim=0)   # (layers, hidden)
        mean_good = good_residuals.mean(dim=0)
        diff = mean_bad - mean_good
        mean_direction = torch.zeros_like(diff)
        for li in range(n_residual_layers):
            bad_centered = bad_residuals[:, li, :] - mean_bad[li]
            good_centered = good_residuals[:, li, :] - mean_good[li]
            n_bad, n_good = bad_centered.shape[0], good_centered.shape[0]
            if n_bad < 2 or n_good < 2:
                mean_direction[li] = diff[li]
                continue
            # Pooled within-class scatter (unnormalized — direction is normalized at the end)
            Sw = (bad_centered.T @ bad_centered) + (good_centered.T @ good_centered)
            # Regularize: lambda = 0.01 * trace(Sw) / dim
            dim = Sw.shape[0]
            reg = 0.01 * Sw.trace() / dim
            Sw += reg * torch.eye(dim, device=Sw.device, dtype=Sw.dtype)
            try:
                mean_direction[li] = torch.linalg.solve(Sw, diff[li])
            except RuntimeError:
                mean_direction[li] = diff[li]  # fallback on singular
        mean_direction = F.normalize(mean_direction, p=2, dim=1)
        empty_cache()
        print(step("LDA direction extraction", f"{val(n_residual_layers)} layers"))
    else:
        mean_direction = F.normalize(
            bad_residuals.mean(dim=0) - good_residuals.mean(dim=0),
            p=2,
            dim=1,
        )

    # Layer-type-aware refinement: re-extract per-type directions for hybrid architectures
    if is_hybrid and not settings.lda_direction and not settings.leace_direction:
        for ltype in types_present:
            indices = [ri for ri, t in layer_type_map.items() if t == ltype]
            if not indices:
                continue
            idx_t = torch.tensor(indices, dtype=torch.long)
            sub_bad = bad_residuals[:, idx_t, :]   # (prompts, subset_layers, hidden)
            sub_good = good_residuals[:, idx_t, :]
            sub_dir = F.normalize(sub_bad.mean(dim=0) - sub_good.mean(dim=0), p=2, dim=1)
            for j, ri in enumerate(indices):
                mean_direction[ri] = sub_dir[j]
        print(step("layer-type-aware directions", f"types: {val(sorted(types_present))}"))

    if settings.projected_direction:
        harmless_dir = F.normalize(good_residuals.mean(dim=0), p=2, dim=1)
        dot = (mean_direction * harmless_dir).sum(dim=1, keepdim=True)
        mean_direction = F.normalize(mean_direction - dot * harmless_dir, p=2, dim=1)
        print(step("applied projected direction", "orthogonalized against harmless"))

    # Surgical Refusal Ablation: orthogonalize refusal direction against capability atoms
    concept_directions = None  # cached for reuse by rank-k block
    if settings.concept_atoms:
        print(step("computing concept atom directions for SRA..."))
        concept_directions = []
        for domain, prompts in CAPABILITY_PROBES.items():
            print(step(f"probing {domain} capability", f"{len(prompts)} prompts"))
            formatted = [Prompt(system=settings.system_prompt, user=p) for p in prompts]
            cap_residuals = model.get_residuals_batched(formatted, positions=[-1])
            if len(cap_residuals.shape) == 4:  # multi-position: (prompt, position, layer, hidden)
                cap_residuals = cap_residuals.mean(dim=1)
            # Mean activation direction per domain: (layer, hidden_dim)
            cap_direction = F.normalize(cap_residuals.mean(dim=0), p=2, dim=1)
            concept_directions.append(cap_direction)
            print(f"    {dim(f'{domain}: direction shape {cap_direction.shape}')}")

        # Ridge-regularized orthogonalization per layer
        ridge = settings.concept_atom_ridge
        print(step(f"orthogonalizing against {val(len(concept_directions))} concept atoms", f"ridge={ridge}"))
        for layer_idx in range(mean_direction.shape[0]):
            R = torch.stack([cd[layer_idx] for cd in concept_directions])  # (n_atoms, hidden_dim)
            mean_direction[layer_idx] = _ridge_orthogonalize(mean_direction[layer_idx], R, ridge)

        print(step(f"SRA orthogonalization complete {OK}"))
        # concept_directions kept alive for reuse by rank-k block below

    # RDO: gradient-optimize refusal direction against actual model behavior
    rdo_seed = None
    if settings.rdo_refine:
        mean_direction, rdo_seed = _rdo_refine_direction(model, settings, mean_direction, safe_prompts, harmful_prompts)

    # Compute per-layer COSMIC scores for adaptive layer selection
    layer_separability = None
    if settings.adaptive_layer_selection:
        layer_separability = _compute_cosmic_scores(bad_residuals, good_residuals, mean_direction)
        print(step(f"COSMIC layer scores: min={val(f'{layer_separability[1:].min():.3f}')} max={val(f'{layer_separability[1:].max():.3f}')}"))

    # Compute contrastive PCA directions if enabled
    pca_directions = None
    blend_modes = ["mean"]

    if settings.use_pca_directions:
        num_pca = settings.num_pca_directions
        print(step(f"computing {val(num_pca)} contrastive refusal directions..."))
        # Contrastive PCA: maximize Var_bad / Var_good (no paired samples required)
        pca_directions = _compute_contrastive_directions(bad_residuals, good_residuals, num_pca)
        blend_modes.extend([f"pca_{i+1}" for i in range(num_pca)])
        print(step(f"extracted {val(num_pca)} contrastive directions per layer"))

    # SOM clustering: find diverse refusal modes via KMeans on harmful deviations.
    # Produces svd_directions directly, bypassing the rank-k SVD/PCA block below.
    svd_directions = None
    if settings.leace_direction and settings.som_directions:
        print(f"  {WARN} LEACE direction unused when SOM directions enabled — SOM bypasses mean direction")
    elif settings.lda_direction and settings.som_directions:
        print(f"  {WARN} LDA direction unused when SOM directions enabled — SOM bypasses mean direction")
    if settings.som_directions:
        k = settings.ablation_rank
        print(step(f"computing {val(k)} SOM refusal directions from {val(settings.som_clusters)} clusters..."))
        svd_directions = _compute_som_directions(bad_residuals, good_residuals, settings.som_clusters, k)
        print(step(f"SOM directions shape: {val(svd_directions.shape)}"))
        if settings.combine_directions:
            print(f"  {WARN} --combine-directions ignored: SOM directions use per-direction scaling instead")
        if pca_directions is not None:
            print(f"  {WARN} PCA directions computed but unused: SOM directions supersede blend_mode selection")

    # Compute rank-k directions when ablation_rank > 1 (skip if SOM already produced them).
    if settings.ablation_rank > 1 and svd_directions is None:
        k = settings.ablation_rank
        if pca_directions is not None:
            parts = [mean_direction.unsqueeze(1)]
            for i in range(min(pca_directions.shape[0], k - 1)):
                parts.append(pca_directions[i].unsqueeze(1))
            while len(parts) < k:
                parts.append(mean_direction.unsqueeze(1))
            svd_directions = torch.cat(parts[:k], dim=1)
            print(step(f"rank-{val(k)} directions from mean + {val(min(pca_directions.shape[0], k-1))} PCA"))
        else:
            print(step(f"computing rank-{val(k)} SVD refusal directions..."))
            diffs = bad_residuals - good_residuals
            svd_per_layer = []
            for layer_idx in range(diffs.shape[1]):
                layer_diffs = diffs[:, layer_idx, :]
                layer_diffs = layer_diffs - layer_diffs.mean(dim=0)
                try:
                    _, _, Vh = torch.linalg.svd(layer_diffs, full_matrices=False)
                    k_actual = min(k, Vh.shape[0])
                    dirs = F.normalize(Vh[:k_actual], p=2, dim=1)
                    if k_actual < k:
                        warnings.warn(f"SVD layer {layer_idx}: rank {k_actual} < requested {k}, padding with mean direction", stacklevel=2)
                        pad = mean_direction[layer_idx].unsqueeze(0).repeat(k - k_actual, 1)
                        dirs = torch.cat([dirs, pad], dim=0)
                    svd_per_layer.append(dirs)
                except RuntimeError:
                    svd_per_layer.append(mean_direction[layer_idx].unsqueeze(0).repeat(k, 1))
            svd_directions = torch.stack(svd_per_layer)
            del diffs

        print(step(f"rank-k directions shape: {val(svd_directions.shape)}"))
        if settings.combine_directions and pca_directions is None:
            print(f"  {WARN} --combine-directions ignored: rank-{k} uses per-direction scaling instead")

    # Post-process svd_directions (applies to both SOM and rank-k SVD/PCA paths)
    if svd_directions is not None:
        k = svd_directions.shape[1]
        if settings.projected_direction:
            harmless_dir = F.normalize(good_residuals.mean(dim=0), p=2, dim=1)
            for i in range(k):
                dot = (svd_directions[:, i, :] * harmless_dir).sum(dim=1, keepdim=True)
                svd_directions[:, i, :] = F.normalize(svd_directions[:, i, :] - dot * harmless_dir, p=2, dim=1)

        if settings.concept_atoms:
            ridge = settings.concept_atom_ridge
            if concept_directions is None:
                concept_directions = []
                for domain, prompts_list in CAPABILITY_PROBES.items():
                    formatted = [Prompt(system=settings.system_prompt, user=p) for p in prompts_list]
                    cap_residuals = model.get_residuals_batched(formatted, positions=[-1])
                    if cap_residuals.ndim == 4:
                        cap_residuals = cap_residuals.mean(dim=1)
                    concept_directions.append(F.normalize(cap_residuals.mean(dim=0), p=2, dim=1))
            for layer_idx in range(svd_directions.shape[0]):
                R = torch.stack([cd[layer_idx] for cd in concept_directions])
                for i in range(k):
                    svd_directions[layer_idx, i] = _ridge_orthogonalize(svd_directions[layer_idx, i], R, ridge)
            del concept_directions

    analyzer = Analyzer(settings, model, good_residuals, bad_residuals)

    if settings.show_geometry:
        analyzer.show_geometry()

    if settings.save_plots:
        analyzer.save_plots()

    # Iterative refinement: run abbreviated rank-1, extract secondary direction
    if settings.iterative_refinement and svd_directions is None:
        refined = _iterative_refine(
            model, settings, evaluator, mean_direction,
            safe_prompts, harmful_prompts, positions, layer_separability,
        )
        if refined is not None:
            svd_directions = refined
            if settings.combine_directions:
                print(f"  {WARN} --combine-directions ignored: iterative refinement uses per-direction scaling")
            if pca_directions is not None:
                print(f"  {WARN} PCA directions computed but unused: iterative refinement supersedes blend_mode")
    elif settings.deep_ablation and svd_directions is not None:
        # SOM/rank-k already provides multi-direction, but deep ablation needs
        # to filter still-refusing prompts and re-compute targeted directions.
        refined = _deep_refine_directions(
            model, settings, evaluator, svd_directions, mean_direction,
            safe_prompts, harmful_prompts, positions, layer_separability,
        )
        if refined is not None:
            svd_directions = refined
    elif settings.iterative_refinement and svd_directions is not None:
        print(f"  {WARN} iterative refinement skipped: ablation_rank > 1 already provides multi-direction")

    # We don't need the single-position residuals after computing refusal directions.
    # Keep multipos residuals for weighted combinations during trials if enabled.
    del good_residuals, bad_residuals, analyzer
    empty_cache()

    return DirectionResult(
        mean_direction=mean_direction,
        pca_directions=pca_directions,
        svd_directions=svd_directions,
        blend_modes=blend_modes,
        positions=positions,
        good_residuals_multipos=good_residuals_multipos,
        bad_residuals_multipos=bad_residuals_multipos,
        layer_separability=layer_separability,
        rdo_seed=rdo_seed,
    )
