# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
"""Reaper CLI output styling. Single source of truth for all visual tokens."""

from importlib.metadata import version as _pkg_version

# -- symbols ----------------------------------------------------------------
OK = "[green]\u2713[/]"
FAIL = "[bright_red]\u2717[/]"
WARN = "[yellow]\u26a0[/]"
INFO = "[cyan]\u2022[/]"
WORK = "[red]\u25b8[/]"
STAR = "[yellow]\u2605[/]"
ARROW = "[bright_black]\u2192[/]"


def phase(name: str, detail: str = "") -> str:
    """Format a phase header line."""
    suffix = f"  {detail}" if detail else ""
    return f"[bold red]--[/] [bold red]{name}[/]{suffix}"


def val(v) -> str:
    """Bold-wrap a value for inline display."""
    return f"[bold]{v}[/]"


def dim(text: str) -> str:
    """Dim text for secondary information."""
    return f"[bright_black]{text}[/]"


def step(text: str, detail: str = "") -> str:
    """Format an info sub-step."""
    suffix = f"  {dim(detail)}" if detail else ""
    return f"  {INFO} {text}{suffix}"


def banner() -> str:
    """The startup banner."""
    try:
        ver = _pkg_version("reaper-abliteration")
    except Exception:
        ver = "dev"
    return (
        f"[bold red]reaper[/] {dim(f'v{ver}')}  {dim(chr(0x2500))} {dim('abliteration engine')}\n"
        f"{dim('github.com/hauhaut/reaper-abliteration')}"
    )
