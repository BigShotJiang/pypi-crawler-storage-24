# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Copyright (C) 2025  HauhauCS <hauhaut901@gmail.com>

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

from torch import Tensor
from torch.nn import Module


@dataclass(frozen=True)
class FusedMoeConfig:
    """Arch-specific MoE configuration detected by structural probing."""
    excluded_children: frozenset[str]   # already handled, don't double-wrap
    shared_expert_path: str | None      # e.g. "shared_expert" — probe for LoRA-eligible modules
    input_hook: bool                    # register input pre-hook on mlp.experts
    input_hook_key: str                 # Optuna comp_key for input hook envelope


def detect_fused_moe(layer: Module) -> FusedMoeConfig | None:
    """Probe a decoder layer for fused MoE structure. Returns None for dense/non-fused."""
    mlp = getattr(layer, "mlp", None)
    if mlp is None:
        return None
    experts = getattr(mlp, "experts", None)
    if experts is None:
        return None
    # Must have at least one fused nn.Parameter (not nn.Module) child
    has_fused = any(isinstance(getattr(experts, a, None), Tensor) for a in ("down_proj", "gate_up_proj", "gate_proj", "up_proj"))
    if not has_fused:
        return None

    excluded: set[str] = set()
    shared_path: str | None = None
    if getattr(mlp, "shared_expert", None) is not None:
        shared_path = "shared_expert"
    if getattr(mlp, "shared_expert_gate", None) is not None:
        excluded.add("shared_expert_gate")

    has_gate_up = isinstance(getattr(experts, "gate_up_proj", None), Tensor)
    return FusedMoeConfig(
        excluded_children=frozenset(excluded),
        shared_expert_path=shared_path,
        input_hook=has_gate_up,
        input_hook_key="mlp.input",
    )


def make_input_pre_hook(
    v: Tensor, scale: float, is_rank_k: bool, direction_scales: list[float] | None,
) -> Callable:
    """Build pre-hook: x' = x - scale*(x@v)*v. Preserves all non-hidden-state args."""
    def hook_fn(_mod: Module, args: tuple[Any, ...]) -> tuple[Any, ...]:
        h = args[0]
        h32 = h.float()
        if is_rank_k:
            for i in range(v.shape[0]):
                s = scale * (direction_scales[i] if direction_scales and i < len(direction_scales) else 1.0)
                proj = h32 @ v[i]
                h32 = h32 - s * proj.unsqueeze(-1) * v[i]
        else:
            proj = h32 @ v
            h32 = h32 - scale * proj.unsqueeze(-1) * v
        return (h32.to(h.dtype), *args[1:])
    return hook_fn
