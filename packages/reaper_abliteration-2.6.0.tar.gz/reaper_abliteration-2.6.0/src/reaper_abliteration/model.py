# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Copyright (C) 2025  HauhauCS <hauhaut901@gmail.com>

import logging
import math
import sys
from contextlib import contextmanager, suppress
from dataclasses import dataclass
from itertools import chain
from pathlib import Path
from typing import Any, cast
from unittest.mock import patch

import bitsandbytes as bnb
import torch
import torch.nn.functional as F
from peft import LoraConfig, PeftModel, get_peft_model
from peft.tuners.lora.layer import Linear
from torch import FloatTensor, LongTensor, Tensor
from torch.nn import Module, ModuleList
from transformers import (
    AutoConfig,
    AutoModelForCausalLM,
    AutoTokenizer,
    BatchEncoding,
    BitsAndBytesConfig,
    PreTrainedModel,
    PreTrainedTokenizerBase,
    TextIteratorStreamer,
)
from transformers.generation import (
    GenerateDecoderOnlyOutput,
    StoppingCriteria,
    StoppingCriteriaList,
)
from .config import QuantizationMethod, Settings
from .moe_strategy import FusedMoeConfig, detect_fused_moe, make_input_pre_hook
from .style import OK, FAIL, WARN, WORK, INFO, step, val, dim
from .utils import Prompt, batchify, disable_broken_p2p, empty_cache, get_gpu_info, calculate_device_map, print, track



@dataclass
class LayerEnvelope:
    peak: float
    peak_position: float
    floor: float
    floor_distance: float


def _layer_ablation_scale(idx: int, ap: LayerEnvelope) -> float | None:
    """Return ablation multiplier for layer `idx`, or None to skip it entirely."""
    gap = float(abs(idx - ap.peak_position))
    if ap.floor_distance == 0:
        return ap.peak
    if gap > ap.floor_distance:
        return None
    return ap.peak + (gap / ap.floor_distance) * (ap.floor - ap.peak)


class RefusalStoppingCriteria(StoppingCriteria):
    """Halt generation when refusal markers appear in the decoded output."""

    def __init__(
        self,
        tok: PreTrainedTokenizerBase,
        markers: list[str],
        prompt_len: int,
        period: int = 4,
    ):
        self._tok = tok
        self._lc_markers = [m.lower() for m in markers]
        self._prompt_len = prompt_len
        self._period = period
        self._step = 0

    def __call__(self, ids: LongTensor, scores: FloatTensor, **kw: Any) -> Tensor:
        self._step += 1
        result = torch.zeros(ids.shape[0], dtype=torch.bool, device=ids.device)
        if self._step % self._period != 0:
            return result
        for b in range(ids.shape[0]):
            gen_ids = ids[b, self._prompt_len:]
            if gen_ids.numel() < 3:
                continue
            decoded = str(self._tok.decode(gen_ids[-40:], skip_special_tokens=True)).lower()
            if any(m in decoded for m in self._lc_markers):
                result[b] = True
        return result


_DTYPE_MAP = {"auto": torch.bfloat16, "float16": torch.float16, "bfloat16": torch.bfloat16, "float32": torch.float32}


def _build_bnb_4bit_cfg(dtype_str: str) -> BitsAndBytesConfig:
    """Construct a 4-bit BitsAndBytes quantization config from a dtype string."""
    compute_dt = _DTYPE_MAP[dtype_str]
    return BitsAndBytesConfig(
        load_in_4bit=True,
        bnb_4bit_compute_dtype=compute_dt,
        bnb_4bit_quant_type="nf4",
        bnb_4bit_use_double_quant=True,
    )


def _get_composite_quant_config(
    model_name: str, trust_remote_code: bool | None = None,
) -> tuple[dict[str, Any] | None, Any]:
    """Return (quant_config, text_config) for composite VLM models whose text_config
    lacks quantization_config.

    When the text_config is returned, the caller should pass it as ``config=`` to
    ``from_pretrained`` so that ``get_hf_quantizer`` sees ``quantization_config``
    on the config object and correctly sets ``pre_quantized=True``.  Without this,
    FP8 VLM checkpoints loaded as text-only get ``pre_quantized=False`` and the
    loader tries to re-quantize already-fp8 weights, causing conversion errors and
    broken expert scales.
    """
    try:
        root_cfg = AutoConfig.from_pretrained(model_name, trust_remote_code=trust_remote_code)
        qc = getattr(root_cfg, "quantization_config", None)
        if qc is None:
            return None, None
        text_cfg = getattr(root_cfg, "text_config", None)
        if text_cfg is None or getattr(text_cfg, "quantization_config", None) is not None:
            return None, None
        qc_dict = qc if isinstance(qc, dict) else qc.to_dict()
        # Rewrite modules_to_not_convert: composite uses model.language_model.*
        # but text-only model uses model.* — mismatched prefixes cause BF16
        # modules to get wrongly FP8-quantized with random scale_inv
        mtnc = qc_dict.get("modules_to_not_convert")
        if mtnc:
            qc_dict["modules_to_not_convert"] = [
                m.replace("model.language_model.", "model.").replace("model.visual.", "")
                for m in mtnc if "visual" not in m
            ]
        text_cfg.quantization_config = qc_dict
        return qc_dict, text_cfg
    except Exception as exc:
        print(f"  {WARN} Failed to read composite quant config: {exc}")
        return None, None



@contextmanager
def _suppress_fp8_report_error():
    """Patch log_state_dict_report to demote FP8 conversion RuntimeError to a warning.

    Also logs which keys had conversion errors so we can verify they're
    only harmless (visual/mtp) rather than critical expert layers.
    """
    from transformers.utils.loading_report import log_state_dict_report as _orig

    def _lenient(*a: Any, **kw: Any) -> None:
        try:
            _orig(*a, **kw)
        except RuntimeError as e:
            if "automatic conversion of the weights" not in str(e):
                raise
            # Extract loading_info from positional or keyword args
            info = kw.get("loading_info") or (a[3] if len(a) > 3 else None)
            if info is not None and hasattr(info, "conversion_errors") and info.conversion_errors:
                errs = info.conversion_errors
                expert_errs = [k for k in errs if "expert" in k and "visual" not in k]
                visual_errs = [k for k in errs if "visual" in k]
                other_errs = [k for k in errs if k not in expert_errs and k not in visual_errs]
                parts = [f"{len(errs)} conversion errors"]
                if visual_errs:
                    parts.append(f"{len(visual_errs)} visual (harmless)")
                if expert_errs:
                    parts.append(f"{len(expert_errs)} EXPERT (check weights!)")
                if other_errs:
                    parts.append(f"{len(other_errs)} other: {other_errs[:3]}")
                detail = ", ".join(parts)
                print(f"\n  {WARN} FP8 load: {dim(detail)}  (non-fatal)")
                if expert_errs:
                    print(f"  {WARN} {dim('Expert conversion errors mean FP8 scales may be wrong — verify model quality')}")
            else:
                print(f"\n  {WARN} {dim(str(e))}  (non-fatal, continuing)")

    with patch("transformers.modeling_utils.log_state_dict_report", _lenient):
        yield


def _dequant_fp8(module: Module, weight: Tensor) -> Tensor:
    """Dequantize FP8 weight to float32, handling both block-scaled and per-row variants."""
    scale = getattr(module, "weight_scale_inv", None)
    if scale is None:
        scale = getattr(module, "weight_scale", None)
    if scale is None:
        return weight.to(torch.float32)
    w = weight.float()
    if scale.ndim == 2 and scale.shape[0] > 1 and scale.shape[1] > 1:
        # Block-scaled (FineGrained FP8): scale shape [out/bs, in/bs]
        bs0 = weight.shape[0] // scale.shape[0]
        bs1 = weight.shape[1] // scale.shape[1]
        return (w.reshape(scale.shape[0], bs0, scale.shape[1], bs1)
                * scale.float().reshape(scale.shape[0], 1, scale.shape[1], 1)
                ).reshape(weight.shape)
    # Per-row (fbgemm FP8): scale shape [out, 1]
    return w * scale.float()


def _dequant_block(X: Tensor, X_scale: Tensor, block_k: int) -> Tensor:
    """Dequant FP8 tensor X with block scales X_scale to BF16."""
    if X_scale.numel() == 1:
        return X.float() * X_scale.float()
    shape = X.shape
    n_blocks = X_scale.shape[-1]
    # Reshape last dim into (n_blocks, block_k), multiply by scale, reshape back
    x = X.float().reshape(*shape[:-1], n_blocks, block_k)
    s = X_scale.float().unsqueeze(-1)  # [..., n_blocks, 1]
    return (x * s).reshape(shape).to(torch.bfloat16)


def _patch_fla_triton_for_blackwell() -> None:
    """Disable fla Triton kernels on Blackwell, forcing torch fallbacks.

    fla 0.4.1's Triton kernels produce garbage on Blackwell (SM >= 10) due to
    TritonGPUHoistTMEMAlloc incorrectly fusing dot+add ops (triton#8695).
    fla's IS_NVIDIA_BLACKWELL check uses == 10 (misses SM 12.0) and safe_dot
    workaround is dead code. Transformers has pure-torch fallbacks for all fla
    ops — we force those by nullifying the fla imports.
    """
    if getattr(_patch_fla_triton_for_blackwell, "_done", False):
        return
    _patch_fla_triton_for_blackwell._done = True
    if not torch.cuda.is_available():
        return
    major = max(torch.cuda.get_device_capability(i)[0]
                for i in range(torch.cuda.device_count()))
    if major < 10:
        return
    try:
        import transformers.models.qwen3_5_moe.modeling_qwen3_5_moe as qwen_mod
        qwen_mod.chunk_gated_delta_rule = None
        qwen_mod.fused_recurrent_gated_delta_rule = None
        qwen_mod.FusedRMSNormGated = None
        qwen_mod.is_fast_path_available = False
        print(f"  {WARN} {dim('Disabled fla Triton kernels (broken on Blackwell, triton#8695). Using torch fallbacks.')}")
    except Exception:
        pass


def _act_quant_torch(x: Tensor, block_size: int = 128) -> tuple[Tensor, Tensor]:
    """Pure-torch replacement for Triton fp8_act_quant kernel."""
    shape = x.shape
    flat = x.float().reshape(-1, block_size)
    flat.clamp_(-65504.0, 65504.0)  # inf -> finite (inf/inf=NaN in FP8 quant)
    s = flat.abs().amax(dim=-1).clamp(min=1e-12) / 448.0
    y = (flat / s.unsqueeze(-1)).clamp(-448.0, 448.0).to(torch.float8_e4m3fn)
    return y.reshape(shape), s.reshape(*shape[:-1], shape[-1] // block_size)


def _dequant_fp8_matmul(
    A: Tensor, B: Tensor, As: Tensor, Bs: Tensor,
    block_size: list[int], output_dtype: torch.dtype = torch.float32,
) -> Tensor:
    """Pure-torch replacement for w8a8_fp8_matmul (Triton broken on Blackwell)."""
    block_n, block_k = (block_size or [128, 128])[:2]
    # Detach frozen weights from autograd — prevents saving float32 intermediates
    # during backward (saves hundreds of MB per expert per layer in RDO)
    B, Bs = B.detach(), Bs.detach()
    if As.numel() == 1 and Bs.numel() == 1:
        return (A.float() * As.float() @ (B.float() * Bs.float()).T).to(output_dtype)
    A_bf16 = _dequant_block(A, As, block_k)
    B_bf16 = (B.float()
              .reshape(Bs.shape[0], block_n, Bs.shape[1], block_k)
              * Bs.float().reshape(Bs.shape[0], 1, Bs.shape[1], 1)
              ).reshape(B.shape[0], B.shape[1]).to(torch.bfloat16)
    return (A_bf16 @ B_bf16.T).to(output_dtype)



def _fp8_matmul_grouped_torch(
    hidden_states: Tensor, weights: Tensor, scales: Tensor,
    tokens_per_expert: Tensor, block_size: list[int], offsets: Tensor,
) -> Tensor:
    """Pure-torch replacement for w8a8_fp8_matmul_grouped (per-expert grouped matmul)."""
    results = torch.empty(
        hidden_states.shape[0], weights.shape[1], device=hidden_states.device, dtype=hidden_states.dtype,
    )
    start = 0
    for eid in range(weights.shape[0]):
        count = int(tokens_per_expert[eid].item())
        if count == 0:
            continue
        x = hidden_states[start:start + count]
        qx, sx = _act_quant_torch(x, block_size[1] if block_size else 128)
        results[start:start + count] = _dequant_fp8_matmul(
            qx, weights[eid], sx, scales[eid], block_size, output_dtype=hidden_states.dtype,
        )
        start += count
    return results


def _fp8_matmul_batched_torch(
    hidden_states: Tensor, weights: Tensor, scales: Tensor,
    block_size: list[int], expert_ids: Tensor,
) -> Tensor:
    """Pure-torch replacement for w8a8_fp8_matmul_batched (per-token expert matmul)."""
    results = torch.empty(
        hidden_states.shape[0], weights.shape[1], device=hidden_states.device, dtype=hidden_states.dtype,
    )
    for i in range(hidden_states.shape[0]):
        eid = int(expert_ids[i].item())
        x = hidden_states[i:i+1]
        qx, sx = _act_quant_torch(x, block_size[1] if block_size else 128)
        results[i:i+1] = _dequant_fp8_matmul(
            qx, weights[eid], sx, scales[eid], block_size, output_dtype=hidden_states.dtype,
        )
    return results


def _patch_fp8_kernel_for_blackwell() -> None:
    """Replace ALL Triton FP8 ops with pure-torch fallbacks on Blackwell.

    Triton 3.6.0 codegen is broken on Blackwell SM 12.0 — not just the TMEM
    hoist bug (triton#8695), but potentially other optimization passes too.
    Patches w8a8_fp8_matmul, fp8_act_quant, and the kernel loader with torch equivalents.
    """
    import transformers.integrations.finegrained_fp8 as fp8_mod
    from types import SimpleNamespace

    # Replace the module-level matmul dispatcher
    fp8_mod.w8a8_fp8_matmul = _dequant_fp8_matmul
    # Also patch old name in case anything still references it
    if hasattr(fp8_mod, "w8a8_block_fp8_matmul"):
        fp8_mod.w8a8_block_fp8_matmul = _dequant_fp8_matmul

    # Build a fake kernel module that the lazy loader returns
    fake_kernel = SimpleNamespace(
        fp8_act_quant=_act_quant_torch,
        w8a8_fp8_matmul=_dequant_fp8_matmul,
        w8a8_fp8_matmul_grouped=_fp8_matmul_grouped_torch,
        w8a8_fp8_matmul_batched=_fp8_matmul_batched_torch,
    )
    # Replace the lazy kernel loader so FP8Linear.forward() gets our fallbacks
    fp8_mod._triton_kernel = fake_kernel
    fp8_mod._triton_kernel_available = True
    print(f"  {WARN} {dim('Patched FP8 ops: pure-torch fallbacks (Triton broken on Blackwell)')}")


class Model:
    model: PreTrainedModel | PeftModel | None
    tokenizer: PreTrainedTokenizerBase

    def __init__(self, settings: Settings):
        self.settings = settings
        self.response_prefix = ""
        self.needs_reload = False
        # Fused expert Parameters for gpt-oss style MoE architectures
        self._fused_expert_params: dict[int, dict[str, Tensor]] = {}
        self._moe_config: FusedMoeConfig | None = None
        self._super_experts: dict[int, list[int]] = {}  # layer_idx -> super expert IDs (protected from ablation)
        self._ablation_hooks: list[torch.utils.hooks.RemovableHandle] = []
        self._ablation_hook_params: list[dict[str, Any]] = []
        # Weight dequant cache (4-bit only), SVD guard cache, layer module lookup cache
        self._dequant_cache: dict[str, Tensor] = {}
        self._svd_guard_cache: dict[str, Tensor] = {}
        self._layer_modules_cache: dict[int, dict[str, list[Module]]] = {}
        self._loaded_dtype: torch.dtype = torch.bfloat16

        print(step(f"Loading {val(settings.model)}"))

        self.device_map, self.max_memory = self._resolve_placement(settings)
        disable_broken_p2p(force=settings.force_p2p_cpu_staging)

        self.tokenizer = AutoTokenizer.from_pretrained(  # ty:ignore[invalid-assignment]
            settings.model, trust_remote_code=settings.trust_remote_code,
        )
        # Ensure pad token exists and left-padding is used for causal generation
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
        self.tokenizer.padding_side = "left"

        self.model = None
        self._trust_flags = {settings.model: settings.trust_remote_code}
        if settings.eval_checkpoint is not None:
            self._trust_flags[settings.eval_checkpoint] = settings.trust_remote_code

        auto_cls = AutoModelForCausalLM
        loaded = self._load_with_dtype_fallback(auto_cls, settings)
        if not loaded:
            tried = ", ".join(settings.dtype_order)
            raise RuntimeError(
                f"Could not load model with dtypes [{tried}]. "
                "Consider --quantization=bnb_4bit to reduce memory."
            )

        if settings.use_gradient_checkpointing:
            self._enable_grad_ckpt()

        self._scan_fused_experts()  # sets _moe_config before LoRA targets are computed
        self._attach_adapters()
        print(step("Transformer model", f"{len(self.decoder_layers())} layers"))
        print(step("Abliterable components"))
        # Merge components across probed layers (hybrid archs have different components per layer)
        all_targets = self.ablation_targets()
        seen_as_module: set[str] = set()
        for li in range(min(len(self.decoder_layers()), 8)):
            for comp_key, targets in self.layer_components(li).items():
                if comp_key not in seen_as_module:
                    lora_ok = any(hasattr(t, "base_layer") for t in targets)
                    tag = f"{val(len(targets))} modules per layer" + ("" if lora_ok else " (hook-based)")
                    print(f"    {val(comp_key)}: {tag}")
                    seen_as_module.add(comp_key)
        for t in all_targets:
            if t not in seen_as_module:
                print(f"    {val(t)}: hook-based (not saveable)")

    # ── Placement & loading ──────────────────────────────────────────────

    @staticmethod
    def _resolve_placement(settings: Settings):
        """Determine device_map and max_memory from settings + GPU topology."""
        dev_map = settings.device_map
        mem_cap = (
            {int(k) if k.isdigit() else k: v for k, v in settings.max_memory.items()}
            if settings.max_memory else None
        )
        if mem_cap is not None:
            # Show GPU topology so user can verify index→device mapping
            gpus = get_gpu_info()
            if gpus:
                for g in gpus:
                    budget = mem_cap.get(g["index"], "—")
                    print(step(f"GPU {g['index']}", f"{g['name']} ({g['memory_gb']:.0f}GB) → budget {val(budget)}"))
            # Ensure CPU spillover exists for accelerate
            if "cpu" not in mem_cap:
                mem_cap["cpu"] = "64GB"
        if not settings.multi_gpu:
            return dev_map, mem_cap

        gpus = get_gpu_info()
        if not gpus:
            return dev_map, mem_cap

        gpu_info = ", ".join(f"{g['name']} ({g['memory_gb']:.1f}GB)" for g in gpus)
        print(step("GPUs detected", gpu_info))

        if len(gpus) <= 1:
            print(step("multi_gpu enabled but only 1 GPU found, using default"))
            return dev_map, mem_cap

        if mem_cap is None:
            dm, mm = calculate_device_map(gpus, settings.gpu_devices, settings.distribution_strategy)
            dev_map = dm
            if mm:
                mem_cap = mm
            else:
                mem_cap = {g["index"]: f'{int(g["memory_free_gb"] * 0.9)}GB' for g in gpus}
                mem_cap["cpu"] = "64GB"
        print(step("Multi-GPU enabled", f"distributing across {val(len(gpus))} GPUs"))
        return dev_map, mem_cap

    def _load_with_dtype_fallback(self, auto_cls, settings: Settings) -> bool:
        """Try each dtype in order, run a smoke test, return True on first success."""
        _patch_fla_triton_for_blackwell()
        # Fetch composite quant config once (avoids redundant AutoConfig.from_pretrained per dtype retry)
        cqc, cqc_text_cfg = (
            _get_composite_quant_config(settings.model, self._trust_flags.get(settings.model))
            if settings.quantization != QuantizationMethod.BNB_4BIT else (None, None)
        )

        for dt in settings.dtype_order:
            print(f"  {WORK} dtype {val(dt)}  ", end="")
            try:
                qcfg = _build_bnb_4bit_cfg(dt) if settings.quantization == QuantizationMethod.BNB_4BIT else None
                load_kw: dict[str, Any] = {}
                if qcfg is not None:
                    load_kw["quantization_config"] = qcfg
                elif cqc is not None:
                    # Pass text config with quant_config baked in so pre_quantized=True
                    if cqc_text_cfg is not None:
                        load_kw["config"] = cqc_text_cfg
                    else:
                        load_kw["quantization_config"] = cqc

                with _suppress_fp8_report_error():
                    self.model = auto_cls.from_pretrained(
                        settings.model,
                        dtype=dt,
                        device_map=self.device_map,
                        max_memory=self.max_memory,
                        trust_remote_code=self._trust_flags.get(settings.model),
                        **load_kw,
                    )
                if self._trust_flags.get(settings.model) is None:
                    self._trust_flags[settings.model] = True

                # Detect FP8 early — skip smoke test for FP8 models because hybrid
                # arch components (Mamba + Transformer) have transient dtype
                # mismatches that _dequant_fp8_for_lora resolves later.
                _qc = getattr(self.model.config, "quantization_config", None)
                _qm = (_qc.get("quant_method", "") if isinstance(_qc, dict)
                        else getattr(_qc, "quant_method", ""))
                if str(_qm) not in ("fp8", "QuantizationMethod.FP8",
                                     "fbgemm_fp8", "QuantizationMethod.FBGEMM_FP8"):
                    # Smoke test to catch dtype issues early (e.g. inf/nan)
                    self.generate(
                        [Prompt(system=settings.system_prompt, user="Say hello")],
                        max_new_tokens=1,
                    )
            except Exception as exc:
                self.model = None
                empty_cache()
                msg = str(exc).lower()
                if "repository not found" in msg or "does not exist" in msg:
                    raise OSError(
                        f"Model '{settings.model}' not found. Check the model name and your HuggingFace authentication."
                    ) from exc
                print(f"{FAIL} {dim(str(exc))}")
                continue

            print(OK)
            self._loaded_dtype = self.model.dtype
            if settings.quantization == QuantizationMethod.BNB_4BIT:
                print(step(f"4-bit precision  {OK}"))
            elif settings.quantization == QuantizationMethod.NONE:
                # Auto-detect FP8 from model config (native FP8 checkpoints)
                qc = getattr(self.model.config, "quantization_config", None)
                qm = qc.get("quant_method", "") if isinstance(qc, dict) else getattr(qc, "quant_method", "")
                if str(qm) in ("fp8", "QuantizationMethod.FP8"):
                    settings.quantization = QuantizationMethod.FP8
                    print(step(f"FP8 quantization detected (block-scaled)  {OK}"))
                    _patch_fp8_kernel_for_blackwell()
                elif str(qm) in ("fbgemm_fp8", "QuantizationMethod.FBGEMM_FP8"):
                    settings.quantization = QuantizationMethod.FBGEMM_FP8
                    print(step(f"FP8 quantization detected (fbgemm per-row)  {OK}"))
            return True
        return False

    def _enable_grad_ckpt(self) -> None:
        assert self.model is not None
        if hasattr(self.model, "gradient_checkpointing_enable"):
            self.model.gradient_checkpointing_enable()
            print(step(f"Gradient checkpointing  {OK}"))
        else:
            print(f"  {WARN} Model does not support gradient checkpointing")

    # ── LoRA adapter management ──────────────────────────────────────────

    def _dequant_fp8_for_lora(self, leaf_names: set[str] | list[str]) -> int:
        """Replace FP8 weights with dequantized BF16 so PEFT LoRA can wrap them."""
        count = 0
        for name, module in list(self.model.named_modules()):
            if name.split(".")[-1] not in leaf_names:
                continue
            w = getattr(module, "weight", None)
            if w is None or not isinstance(w, (Tensor, torch.nn.Parameter)):
                continue
            if w.dtype != torch.float8_e4m3fn:
                continue
            with torch.no_grad():
                bf16_w = _dequant_fp8(module, w).to(torch.bfloat16)
                # Remove FP8 scale/activation attributes (Parameter, buffer, or plain tensor)
                for attr in ("weight_scale_inv", "weight_scale", "input_scale_ub", "activation_scale"):
                    if hasattr(module, attr) and getattr(module, attr) is not None:
                        delattr(module, attr)
                module.weight = torch.nn.Parameter(bf16_w, requires_grad=False)
                # Ensure module behaves as nn.Linear for PEFT dispatch
                if not isinstance(module, torch.nn.Linear):
                    module.in_features = bf16_w.shape[1]
                    module.out_features = bf16_w.shape[0]
                    if not hasattr(module, "bias"):
                        module.bias = None
                    module.__class__ = torch.nn.Linear
                count += 1
        if count:
            empty_cache()
            print(step(f"Dequantized {val(count)} FP8 modules to BF16 for LoRA"))
        return count

    def _attach_adapters(self) -> None:
        """Wrap the base model with LoRA adapters targeting abliterable projection layers."""
        assert isinstance(self.model, PreTrainedModel)

        # Virtual hook keys (mlp.input) produce leaf names with no real module.
        # Fused expert keys like mlp.down_proj are fine — LoRA targets shared_expert.down_proj
        # (nn.Linear) but silently skips fused experts.down_proj (nn.Parameter).
        virtual = {self._moe_config.input_hook_key} if self._moe_config and self._moe_config.input_hook else set()
        leaf_names = list(dict.fromkeys(
            c.split(".")[-1] for c in self.ablation_targets()
            if c != "mlp" and c not in virtual
        ))

        # FP8 weights crash F.linear — dequant to BF16 before PEFT wrapping
        if self.is_fp8():
            self._dequant_fp8_for_lora(set(leaf_names))
            # Diagnostic: verify inference works after dequant, before LoRA
            try:
                diag = self.generate(
                    [Prompt(system=self.settings.system_prompt, user="What is 2+2?")],
                    max_new_tokens=20,
                )
                print(step(f"Post-dequant smoke test  {OK}", f"{diag[0][:80]!r}"))
            except Exception as exc:
                print(f"  {WARN} Post-dequant smoke test failed: {exc}")

        rank = self.settings.ablation_rank
        cfg = LoraConfig(
            r=rank,
            target_modules=leaf_names,
            lora_alpha=rank,
            lora_dropout=0,
            bias="none",
            task_type="CAUSAL_LM",
        )
        self.model = cast(PeftModel, get_peft_model(self.model, cfg))
        self._layer_modules_cache.clear()
        print(step(f"LoRA initialized  {OK}", f"targets: {', '.join(leaf_names)}"))

    def _scan_fused_experts(self) -> None:
        """Detect fused MoE expert weights (gpt-oss BF16 nn.Parameter).

        Fused experts are ablated via activation hooks (no weight backup needed).
        """
        self._fused_expert_params = {}

        for li, layer in enumerate(self.decoder_layers()):
            found_params: dict[str, Tensor] = {}

            with suppress(AttributeError):
                exp = layer.mlp.experts

                for attr, key in [
                    ("down_proj", "mlp.down_proj"),
                    ("gate_up_proj", "mlp.gate_up_proj"),
                    ("gate_proj", "mlp.gate_proj"),
                    ("up_proj", "mlp.up_proj"),
                ]:
                    if not hasattr(exp, attr):
                        continue

                    val = getattr(exp, attr)
                    if isinstance(val, Tensor):
                        found_params[key] = val

            if found_params:
                self._fused_expert_params[li] = found_params

        if not self._fused_expert_params:
            return

        self._moe_config = detect_fused_moe(self.decoder_layers()[0])

        comp_names = set(chain.from_iterable(p.keys() for p in self._fused_expert_params.values()))
        fused_numel = sum(v.numel() for pm in self._fused_expert_params.values() for v in pm.values())
        print(step("Fused expert parameters detected (BF16)", f"{', '.join(comp_names)} — hook-based ablation"))
        if self._moe_config:
            if self._moe_config.shared_expert_path:
                print(step("Shared expert detected", f"mlp.{self._moe_config.shared_expert_path} — LoRA-eligible"))
            if self._moe_config.input_hook:
                print(step("Input pre-hook enabled", f"comp_key: {self._moe_config.input_hook_key}"))

        # BNB futility warning: fused BF16 params can't be quantized by BNB
        if self.settings.quantization == QuantizationMethod.BNB_4BIT:
            assert self.model is not None
            total_numel = sum(p.numel() for p in self.model.parameters())
            fused_pct = fused_numel / total_numel * 100 if total_numel else 0
            if fused_pct > 50:
                print(f"  {WARN} {fused_pct:.0f}% of parameters are fused BF16 (not quantizable by BNB)")
                print(f"    {dim('4-bit quantization saves little memory for this architecture')}")

    def _zero_adapter_weights(self) -> None:
        """Reset all LoRA B matrices to zero, restoring identity transform."""
        assert self.model is not None
        for nm, mod in self.model.named_modules():
            if "lora_B" in nm and hasattr(mod, "weight"):
                torch.nn.init.zeros_(mod.weight)

    def _remove_ablation_hooks(self) -> None:
        """Remove all forward hooks registered for MLP ablation."""
        for handle in self._ablation_hooks:
            handle.remove()
        self._ablation_hooks.clear()
        self._ablation_hook_params.clear()

    def get_ablation_recipe(self) -> list[dict[str, Any]] | None:
        """Extract hook-based ablation parameters for serialization."""
        return self._ablation_hook_params if self._ablation_hook_params else None

    @staticmethod
    def apply_ablation_recipe(model: PreTrainedModel, recipe_path: str) -> list[torch.utils.hooks.RemovableHandle]:
        """Load ablation recipe from disk and re-register MLP hooks."""
        import json
        from safetensors.torch import load_file

        recipe_dir = Path(recipe_path) if not Path(recipe_path).is_file() else Path(recipe_path).parent
        meta = json.loads((recipe_dir / "ablation_recipe.json").read_text())
        tensors = load_file(str(recipe_dir / "ablation_recipe.safetensors"))

        # Unwrap PeftModel if needed
        base = model.base_model.model if isinstance(model, PeftModel) else model
        layers = base.model.layers

        def _make_hook_rk(_v, _scale, _ds, _k):
            def hook_fn(_mod, _inp, output):
                is_tuple = isinstance(output, tuple)
                h = (output[0] if is_tuple else output).float()
                for j in range(_k):
                    proj = h @ _v[j]
                    h = h - (_scale * _ds[j]) * proj.unsqueeze(-1) * _v[j]
                h = h.to(output[0].dtype if is_tuple else output.dtype)
                return (h, *output[1:]) if is_tuple else h
            return hook_fn

        def _make_hook_r1(_v, _scale):
            def hook_fn(_mod, _inp, output):
                is_tuple = isinstance(output, tuple)
                h = (output[0] if is_tuple else output).float()
                proj = h @ _v
                h = (h - _scale * proj.unsqueeze(-1) * _v).to(output[0].dtype if is_tuple else output.dtype)
                return (h, *output[1:]) if is_tuple else h
            return hook_fn

        handles: list[torch.utils.hooks.RemovableHandle] = []
        for i, entry in enumerate(meta["hooks"]):
            li = entry["layer_idx"]
            hook_type = entry.get("hook_type", "output")
            # Try new key format first, fall back to old format
            tkey = f"direction_{li}_{hook_type}_{i}"
            if tkey not in tensors:
                tkey = f"direction_{li}"
            v = tensors[tkey]
            scale = entry["scale"]
            is_rank_k = entry["is_rank_k"]
            ds = entry["direction_scales"]
            mlp = layers[li].mlp
            dev = next(mlp.parameters()).device
            v = v.to(dev, dtype=torch.float32)

            if hook_type == "input":
                experts = getattr(mlp, "experts", None)
                target = experts if experts is not None else mlp
                hook_fn = make_input_pre_hook(v, scale, is_rank_k, ds)
                handles.append(target.register_forward_pre_hook(hook_fn))
                continue
            else:
                comp_mod = mlp  # output hooks go on the whole MLP

            if is_rank_k:
                handles.append(comp_mod.register_forward_hook(_make_hook_rk(v, scale, ds, v.shape[0])))
            else:
                handles.append(comp_mod.register_forward_hook(_make_hook_r1(v, scale)))

        return handles

    # ── Model lifecycle ──────────────────────────────────────────────────

    @staticmethod
    def _manual_merge(model: PeftModel) -> PreTrainedModel:
        """Merge LoRA weights into base model without relying on PEFT's merge_and_unload.

        Fallback for architectures where merge_and_unload() crashes.
        Two steps: (1) compute B@A*scaling, add to base weight, (2) unwrap LoRA layers.
        """
        from peft.tuners.tuners_utils import BaseTunerLayer

        # Step 1: Merge delta weights into base layers
        for name, module in model.named_modules():
            if not isinstance(module, BaseTunerLayer) or not hasattr(module, "lora_A"):
                continue
            for adapter_name in list(module.lora_A.keys()):
                lora_A = module.lora_A[adapter_name].weight
                lora_B = module.lora_B[adapter_name].weight
                scaling = module.scaling[adapter_name]
                base = module.get_base_layer()
                # Match PEFT: fp32 on CPU for numerical stability
                device = lora_A.device
                if device.type == "cpu" and base.weight.dtype in (torch.float16, torch.bfloat16):
                    delta = (lora_B.float() @ lora_A.float()) * scaling
                else:
                    delta = (lora_B @ lora_A) * scaling
                base.weight.data += delta.to(base.weight.dtype)

        # Step 2: Unwrap — replace LoRA wrappers with their base layers
        base_model = model.base_model.model
        for key in [k for k, _ in base_model.named_modules()]:
            try:
                parts = key.rsplit(".", 1)
                parent = base_model.get_submodule(parts[0]) if len(parts) > 1 else base_model
                target = base_model.get_submodule(key)
            except (AttributeError, ValueError):
                continue
            if hasattr(target, "base_layer"):
                setattr(parent, parts[-1], target.get_base_layer())
        return base_model

    def is_fp8(self) -> bool:
        return self.settings.quantization in (QuantizationMethod.FP8, QuantizationMethod.FBGEMM_FP8)

    def get_merged_model(self) -> PreTrainedModel:
        assert isinstance(self.model, PeftModel), "Model must be a PeftModel to merge"
        if self.is_fp8():
            raise RuntimeError("FP8 models cannot merge in-memory — use streaming export")
        self.needs_reload = True  # set BEFORE merge so crash recovery works

        is_quantized = self.settings.quantization == QuantizationMethod.BNB_4BIT
        if not is_quantized:
            print(step("Merging LoRA adapters into base model"))
            try:
                merged = self.model.merge_and_unload()
            except Exception as exc:
                print(f"  {WARN} merge_and_unload failed: {exc}")
                print(step("Falling back to manual merge"))
                merged = self._manual_merge(self.model)
            # Drop self.model ref so caller holds the sole reference to merged.
            # Without this, VRAM stays pinned until reset_model() — which OOMs
            # trying to allocate a fresh model alongside the merged one.
            self.model = None
            self._layer_modules_cache.clear()
            self._dequant_cache.clear()
            self._svd_guard_cache.clear()
            self._fused_expert_params.clear()
            empty_cache()
        else:
            # Quantized path: save adapter state, reload base in fp on CPU, re-apply, merge
            saved_adapter: dict[str, Tensor] = {
                n: p.data.clone().cpu()
                for n, p in self.model.named_parameters() if "lora_" in n
            }
            print(step("Loading base model on CPU", "this may take a while"))
            # No quantization_config here: CPU merge needs full-precision weights for clean LoRA merge
            cpu_base = AutoModelForCausalLM.from_pretrained(
                self.settings.model,
                torch_dtype=self.model.dtype,
                device_map="cpu",
                trust_remote_code=self._trust_flags.get(self.settings.model),
            )

            print(step("Applying LoRA adapters"))
            comps = [c for c in self.ablation_targets() if c != "mlp"]
            rank = self.settings.ablation_rank
            cpu_peft = get_peft_model(cpu_base, LoraConfig(
                r=rank, target_modules=comps, lora_alpha=rank,
                lora_dropout=0, bias="none", task_type="CAUSAL_LM",
            ))
            for n, p in cpu_peft.named_parameters():
                if n in saved_adapter:
                    p.data = saved_adapter[n].to(p.device)

            print(step("Merging LoRA adapters into base model"))
            try:
                merged = cpu_peft.merge_and_unload()
            except Exception as exc:
                print(f"  {WARN} merge_and_unload failed: {exc}")
                print(step("Falling back to manual merge"))
                merged = self._manual_merge(cpu_peft)

            self._layer_modules_cache.clear()
        return merged

    def reset_model(self) -> None:
        """Reset to clean state: fast LoRA zero-out, or full reload if needed."""
        # Fast reset: zero adapters + remove hooks (no reload)
        if self.model is not None and not self.needs_reload:
            self._zero_adapter_weights()
            self._remove_ablation_hooks()
            return

        # Full reload required (model corrupted, merged, or freed)
        prev_dtype = self.model.dtype if self.model is not None else self._loaded_dtype
        self._remove_ablation_hooks()
        # Drop all caches holding refs to old model tensors BEFORE freeing model,
        # so gc.collect() in empty_cache() can actually reclaim VRAM.
        self._layer_modules_cache.clear()
        self._dequant_cache.clear()
        self._svd_guard_cache.clear()
        self._fused_expert_params.clear()
        self.model = None
        if torch.cuda.is_available():
            torch.cuda.synchronize()
        empty_cache()

        dt_str = str(prev_dtype).split(".")[-1]
        qcfg = _build_bnb_4bit_cfg(dt_str) if self.settings.quantization == QuantizationMethod.BNB_4BIT else None
        load_kw: dict[str, Any] = {}
        if qcfg is not None:
            load_kw["quantization_config"] = qcfg
        else:
            cqc, cqc_text_cfg = _get_composite_quant_config(
                self.settings.model, self._trust_flags.get(self.settings.model),
            )
            if cqc is not None:
                if cqc_text_cfg is not None:
                    load_kw["config"] = cqc_text_cfg
                else:
                    load_kw["quantization_config"] = cqc

        with _suppress_fp8_report_error():
            self.model = AutoModelForCausalLM.from_pretrained(
                self.settings.model,
                dtype=prev_dtype,
                device_map=self.device_map,
                max_memory=self.max_memory,
                trust_remote_code=self._trust_flags.get(self.settings.model),
                **load_kw,
            )
        if self.settings.use_gradient_checkpointing and hasattr(self.model, "gradient_checkpointing_enable"):
            self.model.gradient_checkpointing_enable()

        self._scan_fused_experts()
        self._attach_adapters()
        self.needs_reload = False

    # ── Layer & module introspection ─────────────────────────────────────

    def _backbone(self) -> Module:
        """Return the transformer backbone (without lm_head)."""
        base = self.model
        assert base is not None
        if isinstance(base, PeftModel):
            base = base.base_model.model
        with suppress(AttributeError):
            return base.model.language_model
        return base.model

    def decoder_layers(self) -> ModuleList:
        return self._backbone().layers

    def get_attention_head_info(self) -> tuple[int, int]:
        """Return (num_heads, head_dim) from model config."""
        base = self.model
        assert base is not None
        if isinstance(base, PeftModel):
            base = base.base_model.model
        cfg = base.config
        n_heads = getattr(cfg, "num_attention_heads", None) or getattr(cfg, "n_head", None) or getattr(cfg, "num_heads", 32)
        hidden = getattr(cfg, "hidden_size", None) or getattr(cfg, "n_embd", 4096)
        return n_heads, hidden // n_heads

    # Table-driven component probing: (comp_key, accessor_fn)
    _COMPONENT_PROBES: list[tuple[str, Any]] = [
        ("attn.o_proj", lambda lyr: lyr.self_attn.o_proj),
        ("linear_attn.out_proj", lambda lyr: lyr.linear_attn.out_proj),
        ("mlp.down_proj", lambda lyr: lyr.mlp.down_proj),
        ("mlp.gate_proj", lambda lyr: lyr.mlp.gate_proj),
        ("mlp.up_proj", lambda lyr: lyr.mlp.up_proj),
    ]
    # Expert probes: (comp_key, container_attr_chain, leaf_attr, iterable)
    _EXPERT_PROBES: list[tuple[str, str, str] | tuple[str, str, str, bool]] = [
        ("mlp.down_proj", "mlp.experts", "down_proj"),
        ("mlp.down_proj", "block_sparse_moe.experts", "w2"),
        ("mlp.down_proj", "shared_mlp", "output_linear", False),
        ("mlp.down_proj", "moe.experts", "output_linear"),
        ("mlp.gate_proj", "mlp.experts", "gate_proj"),
        ("mlp.gate_proj", "block_sparse_moe.experts", "w1"),
        ("mlp.gate_proj", "shared_mlp", "input_linear", False),
        ("mlp.gate_proj", "moe.experts", "input_linear"),
        ("mlp.up_proj", "mlp.experts", "up_proj"),
        ("mlp.up_proj", "block_sparse_moe.experts", "w3"),
    ]

    def layer_components(self, layer_idx: int) -> dict[str, list[Module]]:
        if layer_idx in self._layer_modules_cache:
            return self._layer_modules_cache[layer_idx]

        lyr = self.decoder_layers()[layer_idx]
        collected: dict[str, list[Module]] = {}

        for comp_key, accessor in self._COMPONENT_PROBES:
            try:
                obj = accessor(lyr)
                if isinstance(obj, Module):
                    collected.setdefault(comp_key, []).append(obj)
            except AttributeError:
                pass

        for entry in self._EXPERT_PROBES:
            comp_key, container_path, leaf_attr = entry[0], entry[1], entry[2]
            iterable = entry[3] if len(entry) > 3 else True  # ty:ignore[arg-type]
            try:
                container = lyr
                for part in container_path.split("."):
                    container = getattr(container, part)
                if iterable:
                    for ex in container:
                        obj = getattr(ex, leaf_attr)
                        if isinstance(obj, Module):
                            collected.setdefault(comp_key, []).append(obj)
                else:
                    obj = getattr(container, leaf_attr)
                    if isinstance(obj, Module):
                        collected.setdefault(comp_key, []).append(obj)
            except (AttributeError, TypeError):
                pass

        # Generic MLP fallback: if no MLP components found via specific probes,
        # discover any nn.Linear directly under lyr.mlp (handles GPT-style c_fc/c_proj,
        # Falcon dense_h_to_4h, Phi fc1/fc2, and other naming conventions).
        # Accepts both raw nn.Linear and LoRA-wrapped modules (post get_peft_model).
        def _is_linear(m: Module) -> bool:
            return isinstance(m, torch.nn.Linear) or hasattr(m, "base_layer")

        if not any(k.startswith("mlp.") for k in collected):
            with suppress(AttributeError):
                for name, mod in lyr.mlp.named_modules():
                    if _is_linear(mod) and name and "." not in name and "router" not in name:
                        collected.setdefault(f"mlp.{name}", []).append(mod)

        # Shared expert probing: linear modules under mlp.shared_expert share
        # the same comp_keys as fused experts (no Optuna dimension bloat).
        if self._moe_config and self._moe_config.shared_expert_path:
            shared = getattr(getattr(lyr, "mlp", None), self._moe_config.shared_expert_path, None)
            if shared:
                for name, mod in shared.named_children():
                    if _is_linear(mod) and name in ("down_proj", "gate_proj", "up_proj"):
                        collected.setdefault(f"mlp.{name}", []).append(mod)

        assert sum(len(v) for v in collected.values()) > 0, "No abliterable modules found in layer"
        self._layer_modules_cache[layer_idx] = collected
        return collected

    def ablation_targets(self) -> list[str]:
        # Probe multiple layers to cover hybrid architectures (e.g. 3:1 DeltaNet
        # pattern where layer 0 has linear_attn but layer 3 has self_attn).
        comp_keys: list[str] = []
        n_layers = len(self.decoder_layers())
        for li in range(min(n_layers, 8)):
            for ck in self.layer_components(li):
                if ck not in comp_keys:
                    comp_keys.append(ck)
        # Fused experts: only emit the key abliterate() actually uses for hooks.
        # (Other fused keys like mlp.gate_up_proj would waste Optuna dimensions.)
        for layer_params in self._fused_expert_params.values():
            hook_key = "mlp.down_proj" if "mlp.down_proj" in layer_params else next(iter(layer_params), None)
            if hook_key and hook_key not in comp_keys:
                comp_keys.append(hook_key)
            break  # only need first layer that has experts
        # Hook-based MLP ablation: if no MLP components found (quantized experts),
        # add "mlp" as a virtual target — ablation applied via forward hooks.
        if not any(k.startswith("mlp") for k in comp_keys):
            with suppress(AttributeError):
                self.decoder_layers()[0].mlp
                comp_keys.append("mlp")
        # Input pre-hook for fused MoE (gate_up_proj side ablation)
        if self._moe_config and self._moe_config.input_hook:
            if self._moe_config.input_hook_key not in comp_keys:
                comp_keys.append(self._moe_config.input_hook_key)
        return comp_keys

    @property
    def hook_only_keys(self) -> set[str]:
        """Component keys that are ablated via hooks only (no LoRA)."""
        keys: set[str] = set()
        for fp in self._fused_expert_params.values():
            keys.update(fp.keys())
            break  # all layers have same keys
        if self._moe_config and self._moe_config.input_hook:
            keys.add(self._moe_config.input_hook_key)
        return keys

    # ── Abliteration ─────────────────────────────────────────────────────

    def abliterate(
        self,
        refusal_directions: Tensor,
        layer_focus: float | None,
        parameters: dict[str, LayerEnvelope],
        head_mask: Tensor | None = None,
        projection_strength: float = 1.0,
        layer_separability: Tensor | None = None,
        separability_threshold: float = 0.0,
        direction_scales: list[float] | None = None,
    ) -> None:
        """Apply directional ablation to model weights via LoRA adapters."""
        with torch.no_grad():
            is_rank_k = refusal_directions.ndim == 3
            shared_dir = self._interpolate_direction(refusal_directions, layer_focus)
            n_heads, h_dim = self.get_attention_head_info() if head_mask is not None else (0, 0)

            if self.settings.norm_preserve and self.settings.sparsity_threshold > 0:
                logging.warning("norm_preserve is approximate when sparsity_threshold > 0 (sparse basis can't fully represent delta)")
            if self.settings.norm_preserve and self._fused_expert_params:
                print(f"  {WARN} norm_preserve has no effect on fused expert layers (hook-based ablation)")
            if self._super_experts:
                total = sum(len(v) for v in self._super_experts.values())
                print(f"  {INFO} protecting {total} super expert(s) across {len(self._super_experts)} layers from ablation")

            layer_count = len(self.decoder_layers())
            for li in track(range(layer_count), description="Abliterating layers..."):
                if layer_separability is not None and layer_separability[li + 1].item() < separability_threshold:
                    continue

                # Direction for this layer (offset by 1 for embedding at index 0)
                v_base = shared_dir if shared_dir is not None else refusal_directions[li + 1]

                for comp_key, targets in self.layer_components(li).items():
                    ap = parameters[comp_key]
                    scale = _layer_ablation_scale(li, ap)
                    if scale is None:
                        continue
                    scale *= projection_strength

                    dev = cast(Linear, targets[0]).weight.device
                    v_on_dev = v_base.to(dev)

                    for tgt in targets:
                        tgt = cast(Linear, tgt)
                        if not hasattr(tgt, 'base_layer') or not hasattr(tgt, 'lora_A'):
                            continue
                        self._ablate_single_module(
                            tgt, v_on_dev, scale, is_rank_k, li, comp_key,
                            head_mask, n_heads, h_dim, direction_scales,
                        )

                # Build per-expert ablation scales: continuous from refusal ratios, 0.0 for super experts
                es = self._build_expert_scales(li) if (
                    self._super_experts or getattr(self, "_expert_refusal_ratios", None)
                ) else None

                # Fused expert layers → hook-based MLP ablation (no weight mutation)
                if li in self._fused_expert_params:
                    hook_key = "mlp.down_proj" if "mlp.down_proj" in parameters else next(
                        (k for k in self._fused_expert_params[li] if k in parameters), None
                    )
                    if hook_key is not None:
                        self._ablate_mlp_hook(
                            li, v_base, parameters[hook_key], projection_strength,
                            is_rank_k, direction_scales, es,
                        )
                # Hook-based MLP ablation for layers without direct weight access
                elif "mlp" in parameters:
                    if not any(k.startswith("mlp.") for k in self.layer_components(li)):
                        self._ablate_mlp_hook(
                            li, v_base, parameters["mlp"], projection_strength,
                            is_rank_k, direction_scales, es,
                        )

                # Input pre-hook on fused experts (gate_up_proj side)
                if (self._moe_config and self._moe_config.input_hook
                        and self._moe_config.input_hook_key in parameters
                        and li in self._fused_expert_params):
                    self._ablate_mlp_input_hook(
                        li, v_base, parameters[self._moe_config.input_hook_key],
                        projection_strength, is_rank_k, direction_scales, es,
                    )

    def _build_expert_scales(self, layer_idx: int) -> Tensor | None:
        """Build per-expert ablation scale tensor. Continuous from refusal ratios, 0.0 for super experts."""
        if layer_idx not in self._fused_expert_params:
            return None
        ratios = getattr(self, "_expert_refusal_ratios", None) or {}
        has_super = layer_idx in self._super_experts
        has_ratios = layer_idx in ratios
        if not has_super and not has_ratios:
            return None
        fp = next(iter(self._fused_expert_params[layer_idx].values()))
        n_experts = fp.shape[0]
        if has_ratios:
            scales = (torch.tensor(ratios[layer_idx][:n_experts]) / 1.5).clamp(0.3, 2.0)
        else:
            scales = torch.ones(n_experts)
        for eidx in self._super_experts.get(layer_idx, []):
            if 0 <= eidx < n_experts:
                scales[eidx] = 0.0
        return scales

    @staticmethod
    def _interpolate_direction(dirs: Tensor, idx: float | None) -> Tensor | None:
        """Compute a (possibly interpolated) refusal direction, or None for per-layer mode."""
        if idx is None:
            return None
        if len(dirs) <= 2:
            # Not enough directions for interpolation, use last one
            return F.normalize(dirs[-1], p=2, dim=-1)
        max_safe = len(dirs) - 2.001
        idx = max(0.0, min(idx, max_safe))
        frac, whole = math.modf(idx + 1)
        blended = dirs[int(whole)].lerp(dirs[int(whole) + 1], frac)
        return F.normalize(blended, p=2, dim=-1)

    def _ablate_single_module(
        self,
        tgt: Linear,
        v: Tensor,
        scale: float,
        is_rank_k: bool,
        li: int,
        comp_key: str,
        head_mask: Tensor | None,
        n_heads: int,
        h_dim: int,
        direction_scales: list[float] | None = None,
    ) -> None:
        """Compute and assign LoRA A/B for a single target module."""
        # Per-head masking for attention components
        if head_mask is not None and "attn" in comp_key:
            v = self._apply_head_mask(v, head_mask, n_heads, h_dim, is_rank_k)

        W = self._get_fp32_weight(tgt, li, comp_key)
        projection_mode = self._weight_projection_mode(v, W)
        if projection_mode is None:
            return

        # Weight-SVD stability guard
        if self.settings.weight_svd_guard:
            v_or_none = self._svd_guard_project(v, W, li, comp_key, tgt, is_rank_k, projection_mode)
            if v_or_none is None:
                return
            v = v_or_none

        if is_rank_k:
            lora_A, lora_B = self._rank_k_lora(v, W, scale, direction_scales, projection_mode)
        else:
            lora_A, lora_B = self._rank1_lora(v, W, scale, projection_mode)

        wa = cast(Tensor, tgt.lora_A["default"].weight)
        wb = cast(Tensor, tgt.lora_B["default"].weight)
        wa.data = lora_A.to(wa.dtype)
        wb.data = lora_B.to(wb.dtype)

    @staticmethod
    def _apply_head_mask(v: Tensor, mask: Tensor, n_heads: int, h_dim: int, is_rank_k: bool) -> Tensor:
        """Zero out directions for masked-off attention heads."""
        mask_dev = mask.to(v.device)
        if is_rank_k:
            shaped = v.view(v.shape[0], n_heads, h_dim)
            return (shaped * mask_dev.view(1, -1, 1)).view(v.shape[0], -1)
        shaped = v.view(n_heads, h_dim)
        return (shaped * mask_dev.view(-1, 1)).view(-1)

    @staticmethod
    def _weight_projection_mode(v: Tensor, W: Tensor) -> str | None:
        """Choose projection side based on which weight axis matches direction dimension."""
        hdim = v.shape[-1]
        if W.shape[0] == hdim:
            return "row"
        if W.shape[1] == hdim:
            return "col"
        return None

    def _get_fp32_weight(self, tgt: Linear, li: int, comp_key: str) -> Tensor:
        """Extract the base weight matrix in fp32, dequantizing 4-bit/FP8 if needed."""
        base = tgt.base_layer
        raw = cast(Tensor, base.weight)
        qs = getattr(raw, "quant_state", None)

        if raw.dtype == torch.float8_e4m3fn:
            return _dequant_fp8(base, raw)

        if qs is None:
            return raw if raw.dtype == torch.float32 else raw.to(torch.float32)

        cache_id = f"{li}_{comp_key}_{id(tgt)}"
        if self.settings.cache_dequantized_weights and cache_id in self._dequant_cache:
            return self._dequant_cache[cache_id]

        dequant = cast(
            Tensor,
            bnb.functional.dequantize_4bit(raw.data, qs).to(torch.float32),  # ty:ignore[possibly-missing-attribute]
        )
        if self.settings.cache_dequantized_weights:
            self._dequant_cache[cache_id] = dequant
        return dequant

    def _svd_guard_project(
        self, v: Tensor, W: Tensor, li: int, comp_key: str, tgt: Linear, is_rank_k: bool, projection_mode: str,
    ) -> Tensor | None:
        """Remove components of v along the top singular vectors of W (capability protection)."""
        k_guard = self.settings.svd_guard_rank
        svd_id = f"{li}_{comp_key}_{id(tgt)}_{projection_mode}"
        if svd_id in self._svd_guard_cache:
            basis = self._svd_guard_cache[svd_id]
        else:
            U_k, _, V_k = torch.svd_lowrank(W, q=k_guard, niter=2)
            basis = U_k if projection_mode == "row" else V_k
            self._svd_guard_cache[svd_id] = basis

        if is_rank_k:
            v = v - (v @ basis) @ basis.T
            norms = v.norm(dim=1)
            surviving = norms > 1e-4
            if not surviving.any():
                return None
            # Normalize surviving directions in-place, zero out filtered ones
            # to preserve the expected row count (== ablation_rank for LoRA).
            v[surviving] = v[surviving] / norms[surviving, None]
            v[~surviving] = 0
            return v
        else:
            v = v - basis @ (basis.T @ v)
            n = v.norm()
            return None if n < 1e-4 else v / n

    @staticmethod
    def _norm_preserve_scale(B: Tensor, A: Tensor, W: Tensor) -> Tensor:
        """Scale B per-row so ||W + B@A|| = ||W|| (exact where possible, clamped to [0,2])."""
        delta = B @ A
        # Per-row: solve ||W_i + s_i * delta_i||^2 = ||W_i||^2
        # => s_i = -2 * (W_i · delta_i) / ||delta_i||^2
        Wd = (W * delta).sum(dim=1)
        dd = (delta * delta).sum(dim=1).clamp(min=1e-12)
        s = (-2.0 * Wd / dd).clamp(min=0.0, max=2.0)
        return B * s.unsqueeze(1)

    @staticmethod
    def _gram_schmidt(v: Tensor, normalize_first: bool = True) -> Tensor:
        """Gram-Schmidt orthonormalization of row vectors.

        Args:
            v: (k, d) vectors to orthogonalize.
            normalize_first: If True, normalize v[0] before starting.

        Returns:
            (k, d) orthonormalized vectors.
        """
        basis = [F.normalize(v[0], p=2, dim=0) if normalize_first else v[0]]
        for i in range(1, v.shape[0]):
            vi = v[i].clone()
            for b in basis:
                vi = vi - (vi @ b) * b
            n = vi.norm()
            basis.append(vi / n if n > 1e-6 else torch.zeros_like(v[0]))
        return torch.stack(basis)

    def _rank_k_lora(
        self,
        v: Tensor,
        W: Tensor,
        scale: float,
        direction_scales: list[float] | None = None,
        projection_mode: str = "row",
    ) -> tuple[Tensor, Tensor]:
        """Compute rank-k LoRA decomposition with ordered Gram-Schmidt.

        Direction 0 (mean) is preserved exactly. Subsequent directions are
        orthogonalized against prior ones, maintaining semantic alignment
        so per-direction scales control what Optuna intended.
        """
        k = v.shape[0]
        if k > 1:
            v = Model._gram_schmidt(v, normalize_first=True)

        if projection_mode == "row":
            A = v @ W
            if direction_scales is not None and len(direction_scales) >= k:
                ds = torch.tensor(direction_scales[:k], device=v.device, dtype=v.dtype)
                B = -v.T * (scale * ds).unsqueeze(0)
            else:
                B = -scale * v.T
        elif projection_mode == "col":
            A = v
            WVt = W @ v.T
            if direction_scales is not None and len(direction_scales) >= k:
                ds = torch.tensor(direction_scales[:k], device=v.device, dtype=v.dtype)
                B = -WVt * (scale * ds).unsqueeze(0)
            else:
                B = -scale * WVt
        else:
            raise ValueError(f"Unknown projection_mode: {projection_mode}")

        if self.settings.sparsity_threshold > 0:
            if A.dim() > 1 and A.shape[0] > 1:
                cutoff = self.settings.sparsity_threshold * A.abs().amax(dim=1, keepdim=True)
            else:
                cutoff = self.settings.sparsity_threshold * A.abs().max()
            A = A * (A.abs() >= cutoff)

        if self.settings.norm_preserve:
            B = self._norm_preserve_scale(B, A, W)

        return A, B

    def _rank1_lora(self, v: Tensor, W: Tensor, scale: float, projection_mode: str = "row") -> tuple[Tensor, Tensor]:
        """Compute rank-1 LoRA (v^T W, -scale * v) with optional sparsity and norm-preserve."""
        if projection_mode == "row":
            A = (v @ W).reshape(1, -1)
            B = (-scale * v).reshape(-1, 1)
        elif projection_mode == "col":
            A = v.reshape(1, -1)
            B = (-scale * (W @ v)).reshape(-1, 1)
        else:
            raise ValueError(f"Unknown projection_mode: {projection_mode}")

        if self.settings.sparsity_threshold > 0:
            cutoff = self.settings.sparsity_threshold * A.abs().max()
            A = A * (A.abs() >= cutoff)

        if self.settings.norm_preserve:
            B = self._norm_preserve_scale(B, A, W)

        return A, B

    def _ablate_mlp_input_hook(
        self,
        layer_idx: int,
        v_base: Tensor,
        ap: LayerEnvelope,
        projection_strength: float,
        is_rank_k: bool,
        direction_scales: list[float] | None = None,
        expert_scales: Tensor | None = None,
    ) -> None:
        """Register a pre-hook on mlp.experts to ablate input activations (gate_up_proj side).

        expert_scales: optional (n_experts,) tensor — stored for weight baking only.
        """
        scale = _layer_ablation_scale(layer_idx, ap)
        if scale is None:
            return
        scale *= projection_strength

        experts = self.decoder_layers()[layer_idx].mlp.experts
        dev = next(experts.parameters()).device
        if is_rank_k:
            v = F.normalize(v_base.to(dev, dtype=torch.float32), p=2, dim=-1)
            if v.shape[0] > 1:
                v = Model._gram_schmidt(v, normalize_first=False)
            ds = [direction_scales[i] if direction_scales and i < len(direction_scales) else 1.0 for i in range(v.shape[0])]
        else:
            v = F.normalize(v_base.to(dev, dtype=torch.float32), p=2, dim=0)
            ds = None

        hook_fn = make_input_pre_hook(v, scale, is_rank_k, ds)
        handle = experts.register_forward_pre_hook(hook_fn)
        self._ablation_hooks.append(handle)
        self._ablation_hook_params.append({
            "layer_idx": layer_idx,
            "direction": v.cpu(),
            "scale": scale,
            "is_rank_k": is_rank_k,
            "direction_scales": ds if is_rank_k else None,
            "hook_type": "input",
            "expert_scales": expert_scales.cpu().tolist() if expert_scales is not None else None,
        })

    def _ablate_mlp_hook(
        self,
        layer_idx: int,
        v_base: Tensor,
        ap: LayerEnvelope,
        projection_strength: float,
        is_rank_k: bool,
        direction_scales: list[float] | None = None,
        expert_scales: Tensor | None = None,
    ) -> None:
        """Register a forward hook that projects refusal direction out of MLP output.

        Used when MLP weights can't be modified directly (e.g. quantized experts).
        Projects the refusal direction out of the activation space: y' = y - scale*(y@v)*v.

        expert_scales: optional (n_experts,) tensor for per-expert ablation strength
                       during weight baking. Not used in runtime hook (output is already
                       a weighted sum of experts). Default None = uniform scaling.
        """
        scale = _layer_ablation_scale(layer_idx, ap)
        if scale is None:
            return
        scale *= projection_strength

        mlp = self.decoder_layers()[layer_idx].mlp
        dev = next(mlp.parameters()).device

        if is_rank_k:
            k = v_base.shape[0]
            v = F.normalize(v_base.to(dev, dtype=torch.float32), p=2, dim=-1)
            if k > 1:
                v = Model._gram_schmidt(v, normalize_first=False)
            ds = torch.tensor(
                [direction_scales[i] if direction_scales and i < len(direction_scales) else 1.0 for i in range(k)],
                device=dev, dtype=torch.float32,
            )

            def make_projection_hook(hook_scale: float):
                """Create projection hook with specified scale."""
                scales = ds * hook_scale  # [k]
                def hook_fn(_mod: Module, _inp: Any, output: Any) -> Any:
                    is_tuple = isinstance(output, tuple)
                    h = output[0] if is_tuple else output
                    h32 = h.float()
                    P = h32 @ v.T  # (..., k)
                    h32 = h32 - (P * scales) @ v  # (..., hidden)
                    h = h32.to(output[0].dtype if is_tuple else output.dtype)
                    return (h, *output[1:]) if is_tuple else h
                return hook_fn
        else:
            v = F.normalize(v_base.to(dev, dtype=torch.float32), p=2, dim=0)

            def make_projection_hook(hook_scale: float):
                """Create projection hook with specified scale."""
                def hook_fn(_mod: Module, _inp: Any, output: Any) -> Any:
                    is_tuple = isinstance(output, tuple)
                    h = output[0] if is_tuple else output
                    h32 = h.float()
                    proj = h32 @ v
                    h = (h32 - hook_scale * proj.unsqueeze(-1) * v).to(output[0].dtype if is_tuple else output.dtype)
                    return (h, *output[1:]) if is_tuple else h
                return hook_fn

        # Single post-hook for now - testing if double hooks interfere
        post_handle = mlp.register_forward_hook(make_projection_hook(scale))
        self._ablation_hooks.append(post_handle)
        self._ablation_hook_params.append({
            "layer_idx": layer_idx,
            "direction": v.cpu(),
            "scale": scale,
            "is_rank_k": is_rank_k,
            "direction_scales": ds if is_rank_k else None,
            "hook_type": "output",
            "expert_scales": expert_scales.cpu().tolist() if expert_scales is not None else None,
        })

    # ── Tokenization & generation ────────────────────────────────────────

    def tokenize_prompts(self, prompts: list[Prompt]) -> BatchEncoding:
        """Format prompts through the chat template, return BatchEncoding on CPU."""
        conversations = [
            [{"role": "system", "content": p.system}, {"role": "user", "content": p.user}]
            for p in prompts
        ]
        formatted = cast(list[str], self.tokenizer.apply_chat_template(
            conversations, add_generation_prompt=True, tokenize=False,
            **self.settings.chat_template_kwargs,
        ))
        if self.response_prefix:
            formatted = [f + self.response_prefix for f in formatted]
        return self.tokenizer(
            formatted, return_tensors="pt", padding=True, return_token_type_ids=False,
        )

    def generate(
        self,
        prompts: list[Prompt] | None = None,
        tokenized_inputs: BatchEncoding | None = None,
        early_exit_markers: list[str] | None = None,
        **gen_kw: Any,
    ) -> tuple[BatchEncoding, GenerateDecoderOnlyOutput | LongTensor]:
        assert self.model is not None
        if tokenized_inputs is not None:
            enc = tokenized_inputs.to(self.model.device)
        elif prompts is not None:
            enc = self.tokenize_prompts(prompts).to(self.model.device)
        else:
            raise ValueError("Need prompts or tokenized_inputs")

        if early_exit_markers:
            seq_len = cast(Tensor, enc["input_ids"]).shape[1]
            gen_kw["stopping_criteria"] = StoppingCriteriaList([
                RefusalStoppingCriteria(self.tokenizer, early_exit_markers, seq_len)
            ])

        out = self.model.generate(
            **enc, **gen_kw,
            pad_token_id=self.tokenizer.pad_token_id,
            do_sample=False,
        )  # ty:ignore[call-non-callable]
        return enc, out

    def get_responses(
        self,
        prompts: list[Prompt] | None = None,
        skip_special_tokens: bool = False,
        tokenized_inputs: BatchEncoding | None = None,
        early_exit_markers: list[str] | None = None,
        max_new_tokens: int | None = None,
    ) -> list[str]:
        enc, out = self.generate(
            prompts=prompts,
            tokenized_inputs=tokenized_inputs,
            early_exit_markers=early_exit_markers,
            max_new_tokens=max_new_tokens or self.settings.max_new_tokens,
        )
        prompt_len = cast(Tensor, enc["input_ids"]).shape[1]
        return self.tokenizer.batch_decode(out[:, prompt_len:], skip_special_tokens=skip_special_tokens)

    def get_responses_batched(
        self,
        prompts: list[Prompt] | None = None,
        skip_special_tokens: bool = False,
        tokenized_inputs: BatchEncoding | None = None,
        early_exit_markers: list[str] | None = None,
        max_new_tokens: int | None = None,
    ) -> list[str]:
        all_responses: list[str] = []
        # --batch-size is token-level for KL eval, not prompt-level for generation.
        # KV cache grows per-prompt during autoregressive decode, so cap gen batch
        # size well below the token-level setting.
        bs = 256

        if tokenized_inputs is not None:
            total = cast(Tensor, tokenized_inputs["input_ids"]).shape[0]
            offsets = list(range(0, total, bs))
            for off in track(offsets, description="Generating responses..."):
                chunk = BatchEncoding({k: v[off:off + bs] for k, v in tokenized_inputs.items()})
                all_responses.extend(self.get_responses(
                    tokenized_inputs=chunk, skip_special_tokens=skip_special_tokens,
                    early_exit_markers=early_exit_markers, max_new_tokens=max_new_tokens,
                ))
        else:
            chunks = list(batchify(prompts or [], bs))
            for chunk in track(chunks, description="Generating responses..."):
                all_responses.extend(self.get_responses(
                    prompts=chunk, skip_special_tokens=skip_special_tokens,
                    early_exit_markers=early_exit_markers, max_new_tokens=max_new_tokens,
                ))
        return all_responses

    # ── Residual extraction ──────────────────────────────────────────────

    def get_residuals(self, prompts: list[Prompt], positions: list[int] | None = None) -> Tensor:
        """Extract hidden-state residuals at specified token positions.

        Uses forward hooks to capture only the needed positions instead of
        output_hidden_states=True (which materializes all seq_len × all layers).

        Returns:
            Single position: (batch, layers, hidden_dim)
            Multiple positions: (batch, positions, layers, hidden_dim)
        """
        pos = positions or [-1]
        enc = self.tokenize_prompts(prompts).to(self.model.device)

        captured: list[Tensor] = []
        hooks: list[torch.utils.hooks.RemovableHandle] = []

        def _capture(hs: Tensor):
            if len(pos) == 1:
                captured.append(hs[:, pos[0], :].detach().cpu())
            else:
                captured.append(torch.stack([hs[:, p, :] for p in pos], dim=1).detach().cpu())

        layers = self.decoder_layers()

        # Embedding output = input to first decoder layer
        hooks.append(layers[0].register_forward_pre_hook(
            lambda _mod, args: _capture(args[0]),
        ))
        # Each decoder layer's output
        for layer in layers:
            hooks.append(layer.register_forward_hook(
                lambda _mod, _inp, out: _capture(out[0] if isinstance(out, tuple) else out),
            ))

        try:
            with torch.no_grad():
                self._backbone()(**enc)  # skip lm_head — saves batch×seq×vocab memory
        finally:
            for h in hooks:
                h.remove()

        if len(pos) == 1:
            return torch.stack(captured, dim=1).to(torch.float32)
        return torch.stack(captured, dim=2).to(torch.float32)

    def get_residuals_batched(self, prompts: list[Prompt], positions: list[int] | None = None) -> Tensor:
        bs = self.settings.batch_size
        while bs >= 1:
            try:
                parts = [
                    self.get_residuals(batch, positions)
                    for batch in track(list(batchify(prompts, bs)), description="Extracting residuals...")
                ]
                return torch.cat(parts, dim=0)
            except torch.cuda.OutOfMemoryError:
                empty_cache()
                bs = max(1, bs // 2)
                if bs < self.settings.batch_size:
                    print(f"  {WARN} OOM in residual extraction, retrying with batch_size={bs}")
                else:
                    raise
        raise RuntimeError("residual extraction OOM at batch_size=1")

    # ── Log-probability computation ──────────────────────────────────────

    def get_logprobs(
        self,
        prompts: list[Prompt] | None = None,
        tokenized_inputs: BatchEncoding | None = None,
        n_tokens: int = 1,
    ) -> Tensor:
        """Log-probability distributions over vocabulary.

        n_tokens=1: shape (batch, vocab).
        n_tokens>1: shape (batch, n_tokens, vocab) via autoregressive decoding.
        """
        _, raw_out = self.generate(
            prompts=prompts, tokenized_inputs=tokenized_inputs,
            max_new_tokens=n_tokens, output_scores=True, return_dict_in_generate=True,
        )
        gen_out = cast(GenerateDecoderOnlyOutput, raw_out)
        token_scores = list(cast(tuple[FloatTensor], gen_out.scores))

        # Pad if EOS truncated the sequence early
        if token_scores:
            while len(token_scores) < n_tokens:
                token_scores.append(token_scores[-1])
            token_scores = token_scores[:n_tokens]
        else:
            # Model produced no tokens (EOS immediately) - return uniform distribution
            batch_size = cast(Tensor, gen_out.sequences).shape[0]
            token_scores = [
                torch.zeros(batch_size, self.tokenizer.vocab_size, device=self.model.device)
                for _ in range(n_tokens)
            ]

        if n_tokens == 1:
            return F.log_softmax(token_scores[0], dim=-1)
        return F.log_softmax(torch.stack([cast(Tensor, s) for s in token_scores], dim=1), dim=-1)

    def get_continuation_tokens(self, tokenized_inputs: BatchEncoding, n_tokens: int) -> Tensor:
        """Greedy-decode n continuation tokens. Returns (batch, n_tokens) IDs."""
        assert self.model is not None
        enc = tokenized_inputs.to(self.model.device)
        prefix_len = cast(Tensor, enc["input_ids"]).shape[1]
        raw_ids = self.model.generate(
            **enc, max_new_tokens=n_tokens, do_sample=False,
            pad_token_id=self.tokenizer.pad_token_id,
        )  # ty:ignore[call-non-callable]
        new_ids = raw_ids[:, prefix_len:]
        if new_ids.shape[1] == 0:
            # Model produced no new tokens - pad with EOS
            eos_id = self.tokenizer.eos_token_id if self.tokenizer.eos_token_id is not None else 0
            new_ids = torch.full((new_ids.shape[0], n_tokens), eos_id, dtype=raw_ids.dtype, device=raw_ids.device)
        elif new_ids.shape[1] < n_tokens:
            padding = new_ids[:, -1:].expand(-1, n_tokens - new_ids.shape[1])
            new_ids = torch.cat([new_ids, padding], dim=1)
        return new_ids[:, :n_tokens]

    def _reset_multimodal_rope_cache(self) -> None:
        """Clear stale multimodal RoPE delta cache before plain forward passes.

        Some multimodal models (e.g. Qwen3.5) keep batch-shaped `rope_deltas`
        state between calls. A direct text-only `forward()` with a different
        batch size can then fail in position-id reconstruction.
        """
        model = self.model
        if model is None:
            return

        if isinstance(model, PeftModel):
            model = model.base_model.model

        with suppress(AttributeError):
            core = getattr(model, "model")
            if hasattr(core, "rope_deltas"):
                core.rope_deltas = None

    def get_logprobs_teacher_forced(self, tokenized_inputs: BatchEncoding, continuation_ids: Tensor) -> Tensor:
        """Forward pass over prompt+continuation, returning logprobs at continuation positions.

        Uses KV-cache prefill to avoid materializing full-sequence logits.
        Returns (batch, n_tokens, vocab).
        """
        assert self.model is not None
        enc = tokenized_inputs.to(self.model.device)
        ids = cast(Tensor, enc["input_ids"])
        n_cont = continuation_ids.shape[1]
        cont_ids = continuation_ids.to(ids.device)

        attn = enc.get("attention_mask")
        full_attn = torch.cat([attn, torch.ones(attn.shape[0], n_cont, device=attn.device, dtype=attn.dtype)], dim=1) if attn is not None else None

        self._reset_multimodal_rope_cache()
        with torch.no_grad():
            # Prefill: forward prefix[:-1] to build KV cache without double-counting last token
            prefix_ids = ids[:, :-1]
            prefix_attn = attn[:, :-1] if attn is not None else None
            past_kv = None
            if prefix_ids.shape[1] > 0:
                past_kv = self.model(input_ids=prefix_ids, attention_mask=prefix_attn, use_cache=True).past_key_values
            # Decode: last prefix token + continuation; total KV = (prefix-1) + (1+n_cont) = prefix+n_cont = full_attn length
            decode_ids = torch.cat([ids[:, -1:], cont_ids], dim=1)
            logits = self.model(input_ids=decode_ids, attention_mask=full_attn, past_key_values=past_kv).logits
        return F.log_softmax(logits[:, :-1, :], dim=-1)

    def get_logprobs_batched(
        self,
        prompts: list[Prompt] | None = None,
        tokenized_inputs: BatchEncoding | None = None,
        n_tokens: int = 1,
    ) -> Tensor:
        parts: list[Tensor] = []
        bs = self.settings.batch_size

        if tokenized_inputs is not None:
            total = cast(Tensor, tokenized_inputs["input_ids"]).shape[0]
            for off in track(list(range(0, total, bs)), description="Computing logprobs..."):
                chunk = BatchEncoding({k: v[off:off + bs] for k, v in tokenized_inputs.items()})
                parts.append(self.get_logprobs(tokenized_inputs=chunk, n_tokens=n_tokens))
        else:
            for chunk in track(list(batchify(prompts or [], bs)), description="Computing logprobs..."):
                parts.append(self.get_logprobs(prompts=chunk, n_tokens=n_tokens))
        return torch.cat(parts, dim=0)

    def get_continuation_tokens_batched(self, tokenized_inputs: BatchEncoding, n_tokens: int) -> Tensor:
        """Batched greedy continuation. Returns (total, n_tokens) token IDs."""
        total = cast(Tensor, tokenized_inputs["input_ids"]).shape[0]
        bs = self.settings.batch_size
        parts = [
            self.get_continuation_tokens(
                BatchEncoding({k: v[off:off + bs] for k, v in tokenized_inputs.items()}),
                n_tokens,
            )
            for off in range(0, total, bs)
        ]
        return torch.cat(parts, dim=0)

    def get_logprobs_teacher_forced_batched(self, tokenized_inputs: BatchEncoding, continuation_ids: Tensor) -> Tensor:
        """Batched teacher-forced logprobs. Returns (total, n_tokens, vocab)."""
        total = cast(Tensor, tokenized_inputs["input_ids"]).shape[0]
        bs = self.settings.batch_size
        parts = [
            self.get_logprobs_teacher_forced(
                BatchEncoding({k: v[off:off + bs] for k, v in tokenized_inputs.items()}),
                continuation_ids[off:off + bs],
            )
            for off in range(0, total, bs)
        ]
        return torch.cat(parts, dim=0)

    # ── Interactive streaming ────────────────────────────────────────────

    def stream_chat_response(self, chat: list[dict[str, str]]) -> str:
        from threading import Thread

        assert self.model is not None
        enc = self.tokenizer(
            cast(str, self.tokenizer.apply_chat_template(
                chat, add_generation_prompt=True, tokenize=False,
                **self.settings.chat_template_kwargs,
            )),
            return_tensors="pt", return_token_type_ids=False,
        ).to(self.model.device)

        streamer = TextIteratorStreamer(
            self.tokenizer,  # ty:ignore[invalid-argument-type]
            skip_prompt=True, skip_special_tokens=True,
        )
        Thread(
            target=self.model.generate,  # ty:ignore[invalid-argument-type]
            kwargs={**enc, "streamer": streamer, "max_new_tokens": 4096},
        ).start()

        chunks: list[str] = []
        in_think = False
        for chunk in streamer:
            # Strip thinking block content — skip_special_tokens removes
            # <think>/<\/think> tags but leaves the reasoning text visible.
            if "<think>" in chunk:
                in_think = True
                chunk = chunk[:chunk.index("<think>")]
            if in_think:
                if "</think>" in chunk:
                    chunk = chunk[chunk.index("</think>") + len("</think>"):]
                    in_think = False
                else:
                    continue
            if chunk:
                sys.stdout.write(chunk)
                sys.stdout.flush()
                chunks.append(chunk)
        sys.stdout.write("\n")
        sys.stdout.flush()
        return "".join(chunks)
