# SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0
# Copyright (C) 2025  HauhauCS <hauhaut901@gmail.com>

from __future__ import annotations

import shutil
import subprocess
import sys
import warnings
from pathlib import Path
from typing import TYPE_CHECKING

import huggingface_hub
import torch
from huggingface_hub import ModelCard, ModelCardData
from questionary import Choice

from transformers import AutoModelForCausalLM

from .config import QuantizationMethod, Settings
from .model import Model
from .style import OK, FAIL, WARN, WORK, phase, step, val, dim
from .utils import (
    Prompt,
    empty_cache,
    get_readme_intro,
    print,
    prompt_password,
    prompt_path,
    prompt_select,
    prompt_text,
)

if TYPE_CHECKING:
    from .parallel_model import ParallelModel

# Files that belong to the vision encoder / multimodal pipeline.
# CausalLM loading drops these; we copy them back from the source repo at export.
_MULTIMODAL_FILES = [
    "preprocessor_config.json",
    "video_preprocessor_config.json",
]

_LM_PREFIX = "language_model."


def _has_hooks(model) -> bool:
    """Check if model has active ablation hooks."""
    return hasattr(model, '_ablation_hook_params') and bool(model._ablation_hook_params)


def _needs_lm_prefix_strip(save_dir: str) -> bool:
    """Check if any safetensors shard contains 'language_model.' prefixed keys."""
    import json
    save_path = Path(save_dir)
    idx_path = save_path / "model.safetensors.index.json"
    if idx_path.exists():
        with open(idx_path) as f:
            wm = json.load(f).get("weight_map", {})
        return any(_LM_PREFIX in k for k in wm)
    sf_path = save_path / "model.safetensors"
    if sf_path.exists():
        from safetensors import safe_open
        with safe_open(str(sf_path), framework="pt") as f:
            return any(_LM_PREFIX in k for k in f.keys())
    return False


def _strip_lm_prefix_on_disk(save_dir: str) -> None:
    """Rewrite safetensors files in-place to strip 'language_model.' from keys.

    HuggingFace's save_pretrained ignores custom key names in state_dict — the model's
    internal parameter names are used. So we post-process the saved files.
    """
    import json
    from safetensors import safe_open
    from safetensors.torch import save_file

    save_path = Path(save_dir)
    idx_path = save_path / "model.safetensors.index.json"
    single_path = save_path / "model.safetensors"

    def _rename(key: str) -> str | None:
        nk = key.replace(f"model.{_LM_PREFIX}", "model.", 1) if f"model.{_LM_PREFIX}" in key else key
        if nk.startswith("visual.") or nk.startswith("model.visual."):
            return None  # drop vision keys
        return nk

    if idx_path.exists():
        # Sharded model
        with open(idx_path) as f:
            idx = json.load(f)
        wm = idx.get("weight_map", {})
        if not any(_LM_PREFIX in k for k in wm):
            return  # nothing to strip

        shards = sorted(set(wm.values()))
        new_wm: dict[str, str] = {}
        for shard_name in shards:
            shard_path = save_path / shard_name
            if not shard_path.exists():
                continue
            renamed: dict[str, torch.Tensor] = {}
            with safe_open(str(shard_path), framework="pt") as f:
                for k in f.keys():
                    nk = _rename(k)
                    if nk is not None:
                        renamed[nk] = f.get_tensor(k)
                        new_wm[nk] = shard_name
            if renamed:
                save_file(renamed, str(shard_path))
            else:
                shard_path.unlink()  # empty shard (all vision keys)

        idx["weight_map"] = dict(sorted(new_wm.items()))
        with open(idx_path, "w") as f:
            json.dump(idx, f, indent=2)

        print(step(f"Stripped {_LM_PREFIX} prefix from {val(len(new_wm))} keys  {OK}"))

    elif single_path.exists():
        # Unsharded model
        with safe_open(str(single_path), framework="pt") as f:
            if not any(_LM_PREFIX in k for k in f.keys()):
                return
            renamed = {}
            for k in f.keys():
                nk = _rename(k)
                if nk is not None:
                    renamed[nk] = f.get_tensor(k)
        save_file(renamed, str(single_path))
        print(step(f"Stripped {_LM_PREFIX} prefix from {val(len(renamed))} keys  {OK}"))


def _patch_text_only_config(source_model: str, save_dir: str) -> None:
    """Patch config fields that AutoModelForCausalLM strips from multimodal models.

    Text-only submodels often have wrong max_position_embeddings, rope_theta,
    and missing eos_token_id. Restore these from the source HF config.
    """
    import json
    config_path = Path(save_dir) / "config.json"
    if not config_path.exists():
        return
    try:
        src_path = huggingface_hub.hf_hub_download(source_model, "config.json")
        with open(src_path) as f:
            src = json.load(f)
        with open(config_path) as f:
            local = json.load(f)
        changed = False
        for key in ("max_position_embeddings", "eos_token_id", "bos_token_id",
                     "rope_parameters", "rope_theta"):
            if key in src and src[key] != local.get(key):
                local[key] = src[key]
                changed = True
        if changed:
            with open(config_path, "w") as f:
                json.dump(local, f, indent=2)
    except Exception as e:
        print(step(f"Config patch failed: {e}  {WARN}"))


def _patch_multimodal_config(src_cfg: dict, target_cfg: dict) -> bool:
    """Patch architectures, model_type, vision_config from source into target. Returns True if changed."""
    changed = False
    src_archs = src_cfg.get("architectures", [])
    if src_archs and target_cfg.get("architectures") != src_archs:
        target_cfg["architectures"] = src_archs
        changed = True
    src_mt = src_cfg.get("model_type")
    if src_mt and target_cfg.get("model_type") != src_mt:
        target_cfg["model_type"] = src_mt
        changed = True
    if "vision_config" in src_cfg and "vision_config" not in target_cfg:
        target_cfg["vision_config"] = src_cfg["vision_config"]
        changed = True
    return changed


def _restore_multimodal_files(source_model: str, save_dir: str, trust_remote: bool = True) -> None:
    """Copy vision/multimodal config files from source HF repo into save_dir.

    Also patches config.json to restore the original architecture class
    (e.g. ForConditionalGeneration) so downstream tools can extract mmproj.
    """
    import json
    save_path = Path(save_dir)

    # Download missing multimodal files from source repo
    for fname in _MULTIMODAL_FILES:
        dest = save_path / fname
        if dest.exists():
            continue
        try:
            src = huggingface_hub.hf_hub_download(source_model, fname)
            shutil.copy2(src, dest)
        except Exception as e:
            print(step(f"Multimodal file {fname} not found: {e}  {WARN}"))

    # Patch config.json to match the source model (architecture, model_type, vision_config)
    config_path = save_path / "config.json"
    if not config_path.exists():
        return
    try:
        src_config_path = huggingface_hub.hf_hub_download(source_model, "config.json")
        with open(src_config_path) as f:
            src_cfg = json.load(f)
        with open(config_path) as f:
            local_cfg = json.load(f)

        changed = _patch_multimodal_config(src_cfg, local_cfg)

        if changed:
            with open(config_path, "w") as f:
                json.dump(local_cfg, f, indent=2)
            src_archs = src_cfg.get("architectures", [])
            if src_archs:
                print(step(f"Restored architecture: {val(src_archs[0])}"))
    except Exception as e:
        print(step(f"Multimodal config patch failed: {e}  {WARN}"))


def _push_multimodal_files(source_model: str, repo_id: str, token: str | None) -> None:
    """Upload multimodal config files and patch remote config.json architecture."""
    import json
    import tempfile
    from huggingface_hub import HfApi
    api = HfApi()

    for fname in _MULTIMODAL_FILES:
        try:
            src = huggingface_hub.hf_hub_download(source_model, fname)
            api.upload_file(path_or_fileobj=src, path_in_repo=fname,
                            repo_id=repo_id, token=token)
        except Exception as e:
            print(step(f"Push multimodal file {fname} failed: {e}  {WARN}"))

    # Patch remote config.json (architecture, model_type, vision_config)
    try:
        src_config = huggingface_hub.hf_hub_download(source_model, "config.json")
        with open(src_config) as f:
            src_cfg = json.load(f)
        remote_config = huggingface_hub.hf_hub_download(repo_id, "config.json", token=token)
        with open(remote_config) as f:
            cfg = json.load(f)

        changed = _patch_multimodal_config(src_cfg, cfg)

        if changed:
            with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as tmp:
                json.dump(cfg, tmp, indent=2)
                tmp_path = tmp.name
            api.upload_file(path_or_fileobj=tmp_path, path_in_repo="config.json",
                            repo_id=repo_id, token=token)
            Path(tmp_path).unlink(missing_ok=True)
            src_archs = src_cfg.get("architectures", [])
            if src_archs:
                print(step(f"Restored architecture: {val(src_archs[0])}"))
    except Exception as e:
        print(step(f"Remote config patch failed: {e}  {WARN}"))


# ---------------------------------------------------------------------------
# Vision encoder weight restoration
# ---------------------------------------------------------------------------
# CausalLM loading drops vision weights from safetensors. Since abliteration
# only modifies LM weights, we copy vision weights from the source repo.

_VISION_PREFIXES = ("visual.", "model.visual.", "vision_model.", "vision_tower.", "multi_modal_projector.")


def _is_vision_key(key: str) -> bool:
    return any(key.startswith(p) for p in _VISION_PREFIXES)


def _find_vision_tensors(source_model: str) -> dict[str, torch.Tensor] | None:
    """Extract vision encoder tensors from source HF repo.

    Tries sharded index first, then falls back to single safetensors file.
    Returns dict of {key: tensor} or None if model has no vision weights.
    """
    import json
    from safetensors import safe_open

    # Sharded model (has index file)
    try:
        idx_file = huggingface_hub.hf_hub_download(source_model, "model.safetensors.index.json")
        with open(idx_file) as f:
            wm = json.load(f).get("weight_map", {})
        vision = {k: v for k, v in wm.items() if _is_vision_key(k)}
        if not vision:
            return None
        tensors: dict[str, torch.Tensor] = {}
        for shard in sorted(set(vision.values())):
            path = huggingface_hub.hf_hub_download(source_model, shard)
            with safe_open(path, framework="pt") as f:
                for k in f.keys():
                    if k in vision:
                        tensors[k] = f.get_tensor(k)
        return tensors or None
    except Exception as e:
        print(step(f"Sharded vision download failed, trying single file: {e}  {WARN}"))

    # Unsharded model (single file)
    try:
        path = huggingface_hub.hf_hub_download(source_model, "model.safetensors")
        with safe_open(path, framework="pt") as f:
            tensors = {k: f.get_tensor(k) for k in f.keys() if _is_vision_key(k)}
        return tensors or None
    except Exception as e:
        print(step(f"Vision tensor download failed: {e}  {WARN}"))
        return None


def _restore_vision_weights(source_model: str, save_dir: str) -> None:
    """Copy vision encoder weights from source HF repo into save_dir."""
    import json
    from safetensors.torch import save_file

    tensors = _find_vision_tensors(source_model)
    if not tensors:
        return

    save_path = Path(save_dir)
    local_idx_path = save_path / "model.safetensors.index.json"
    local_sf = save_path / "model.safetensors"

    if local_idx_path.exists():
        # Sharded local save — write separate vision shard + update index
        with open(local_idx_path) as f:
            idx = json.load(f)
        wm = idx.get("weight_map", {})
        missing = {k: v for k, v in tensors.items() if k not in wm}
        if not missing:
            return
        shard = "model-vision.safetensors"
        save_file(missing, str(save_path / shard))
        for k in missing:
            wm[k] = shard
        idx["weight_map"] = dict(sorted(wm.items()))
        with open(local_idx_path, "w") as f:
            json.dump(idx, f, indent=2)
        print(step(f"Restored {val(len(missing))} vision weights from source"))

    elif local_sf.exists():
        # Unsharded local save — merge vision tensors into existing file
        from safetensors import safe_open
        with safe_open(str(local_sf), framework="pt") as f:
            existing = set(f.keys())
        missing = {k: v for k, v in tensors.items() if k not in existing}
        if not missing:
            return
        all_tensors: dict[str, torch.Tensor] = {}
        with safe_open(str(local_sf), framework="pt") as f:
            for k in f.keys():
                all_tensors[k] = f.get_tensor(k)
        all_tensors.update(missing)
        save_file(all_tensors, str(local_sf))
        print(step(f"Restored {val(len(missing))} vision weights from source"))


def _push_vision_weights(source_model: str, repo_id: str, token: str | None) -> None:
    """Upload vision encoder weights to remote HF repo + patch safetensors index."""
    import json
    import tempfile
    from huggingface_hub import HfApi
    from safetensors.torch import save_file

    tensors = _find_vision_tensors(source_model)
    if not tensors:
        return

    api = HfApi()
    shard = "model-vision.safetensors"

    # Upload vision shard
    with tempfile.TemporaryDirectory() as tmp:
        path = str(Path(tmp) / shard)
        save_file(tensors, path)
        api.upload_file(path_or_fileobj=path, path_in_repo=shard, repo_id=repo_id, token=token)

    # Patch remote safetensors index
    try:
        remote_idx = huggingface_hub.hf_hub_download(repo_id, "model.safetensors.index.json", token=token)
        with open(remote_idx) as f:
            idx = json.load(f)
        wm = idx.get("weight_map", {})
        for k in tensors:
            wm[k] = shard
        idx["weight_map"] = dict(sorted(wm.items()))
        with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False) as tf:
            json.dump(idx, tf, indent=2)
            tf_path = tf.name
        api.upload_file(path_or_fileobj=tf_path, path_in_repo="model.safetensors.index.json",
                        repo_id=repo_id, token=token)
        Path(tf_path).unlink(missing_ok=True)
    except Exception as e:
        print(step(f"Vision index patch failed: {e}  {WARN}"))

    print(step(f"Uploaded {val(len(tensors))} vision weights"))


def _estimate_footprint_gb(settings: Settings) -> float | None:
    """Meta-device probe for bf16 weight footprint. Returns None on failure."""
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            meta_model = AutoModelForCausalLM.from_pretrained(
                settings.model,
                device_map="meta",
                torch_dtype=torch.bfloat16,
                trust_remote_code=settings.trust_remote_code,
            )
            return meta_model.get_memory_footprint() / (1024**3)
    except Exception as e:
        print(step(f"Meta footprint probe failed: {e}  {WARN}"))
        return None


def _is_fp8(settings: Settings) -> bool:
    return settings.quantization in (QuantizationMethod.FP8, QuantizationMethod.FBGEMM_FP8)


def obtain_merge_strategy(settings: Settings, has_hooks: bool = False) -> str | None:
    """Ask whether to merge LoRA into full weights or keep as adapter."""

    if _is_fp8(settings):
        print()
        print(f"  {WARN} FP8 model — standard merge requires full BF16 in RAM")
        print(f"    {dim('Streaming GPU-side merge dequantizes per-module (low RAM)')}")
        print()

    elif settings.quantization == QuantizationMethod.BNB_4BIT:
        # Quantized merge: reload base weights in bf16 on CPU
        print()
        print(f"  {WARN} Model loaded with quantization — merging requires CPU reload")
        print(f"  {FAIL} Dequantizing to system RAM may exhaust memory")
        print(f"    {dim('Expect roughly 2 bytes per parameter (bf16)')}")

        # Load on "meta" device to read param shapes without real allocation; ignore "uninitialized" noise.
        footprint_gb = _estimate_footprint_gb(settings)
        if footprint_gb is not None:
            print(
                step(f"Estimated net RAM for weights: {val(f'~{footprint_gb:.1f} GB')}")
            )
        else:
            print(
                f"  {WARN} Could not probe model size — check available RAM before merging"
            )
        print()

    choices = []
    if _is_fp8(settings):
        choices.append(Choice(
            title="Streaming merge as BF16 (dequant per-module on GPU, low RAM)",
            value="fp8_streaming",
        ))
    else:
        choices.append(Choice(
            title="Merge full model"
            + (
                ""
                if settings.quantization == QuantizationMethod.NONE
                else " (reload base model on CPU - requires high RAM)"
            ),
            value="merge",
        ))

    choices.extend([
        Choice(
            title="Save LoRA adapter only (can be merged later with llama.cpp or more RAM)",
            value="adapter",
        ),
        Choice(
            title="Export as GGUF (merge + convert via llama.cpp)",
            value="gguf",
        ),
        Choice(
            title="GGUF + LoRA adapter (ablation survives quantization)",
            value="gguf_lora",
        ),
    ])

    if has_hooks and not _is_fp8(settings):
        choices.insert(
            0,
            Choice(
                title="Dequant merge as BF16 (reload + bake ablation hooks into weights)",
                value="mxfp4_dequant",
            ),
        )

    return prompt_select("How do you want to proceed?", choices=choices)


def _save_ablation_recipe(model: Model, save_directory: str) -> None:
    """Save hook-based ablation parameters as a recipe sidecar."""
    import json
    from safetensors.torch import save_file

    recipe = model.get_ablation_recipe()
    if recipe is None:
        return

    out = Path(save_directory)
    tensors = {}
    for i, h in enumerate(recipe):
        ht = h.get("hook_type", "output")
        tensors[f"direction_{h['layer_idx']}_{ht}_{i}"] = h["direction"]
    meta = {
        "hooks": [
            {
                "layer_idx": h["layer_idx"],
                "scale": h["scale"],
                "is_rank_k": h["is_rank_k"],
                "direction_scales": h["direction_scales"].tolist() if isinstance(h["direction_scales"], torch.Tensor) else h["direction_scales"],
                "hook_type": h.get("hook_type", "output"),
                **({"comp_key": h["comp_key"]} if "comp_key" in h else {}),
                **({"expert_scales": h["expert_scales"]} if h.get("expert_scales") is not None else {}),
            }
            for h in recipe
        ]
    }

    save_file(tensors, str(out / "ablation_recipe.safetensors"))
    (out / "ablation_recipe.json").write_text(json.dumps(meta, indent=2))

    n = len(recipe)
    print(
        step(
            f"Ablation recipe saved ({val(n)} layer{'s' if n != 1 else ''} with MLP hooks)  {OK}"
        )
    )
    msg = 'Load with: Model.apply_ablation_recipe(model, "%s")' % save_directory
    print(f"    {dim(msg)}")


def _apply_ablation_to_weights(model_layers, recipe: list[dict]) -> int:
    """Bake hook-based ablation into MLP weights. Returns count of modified layers.

    Handles two hook types:
    - "output" (down_proj post-hook): W -= s * v ⊗ (v^T W)
    - "input" (gate/up_proj pre-hook): W -= s * (W v) ⊗ v^T
    """
    modified = 0
    for entry in recipe:
        li = entry["layer_idx"]
        v = entry["direction"]  # (hidden,) rank-1 or (k, hidden) rank-k
        scale = entry["scale"]
        is_rank_k = entry["is_rank_k"]
        ds = entry["direction_scales"]
        hook_type = entry.get("hook_type", "output")
        es_raw = entry.get("expert_scales")
        es = torch.tensor(es_raw, dtype=torch.float32) if es_raw is not None else None

        layer = model_layers[li]
        mlp = layer.mlp

        targets, fused_param = _collect_ablation_targets(mlp, hook_type)
        if not targets and fused_param is None:
            label = "gate/up_proj" if hook_type == "input" else "down_proj"
            print(f"  {WARN} Layer {li}: no {label} found, skipping {hook_type} hook bake-in")
            continue
        _bake_hook_weights(targets, fused_param, v, scale, is_rank_k, ds, li, hook_type,
                           expert_scales=es)
        modified += 1
    return modified


def _bake_hooks_into_merged(model: Model, merged_model) -> None:
    """Extract ablation recipe from model and bake into merged_model weights."""
    recipe = model.get_ablation_recipe()
    if recipe:
        inner = merged_model.model
        layers = getattr(inner, "language_model", inner).layers
        n = _apply_ablation_to_weights(layers, recipe)
        print(step(f"Ablation baked into weights ({val(n)} layers)  {OK}"))
    else:
        print(f"  {WARN} no ablation recipe — hook bake-in skipped")


def _collect_ablation_targets(mlp, mode: str) -> tuple[list[torch.nn.Parameter], torch.nn.Parameter | None]:
    """Collect weight targets for ablation bake-in.

    mode="output": down_proj weights (post-hook)
    mode="input":  gate/up_proj weights (pre-hook)
    """
    # Per-mode config: expert leaf groups, fused 3D attr, dense/shared attrs, expert containers
    if mode == "input":
        leaf_groups = [("gate_proj", "w1"), ("up_proj", "w3")]
        fused_attr = "gate_up_proj"
        dense_attrs = ("gate_proj", "up_proj")
        containers = ("experts",)
    else:
        leaf_groups = [("down_proj", "w2")]
        fused_attr = "down_proj"
        dense_attrs = ("down_proj",)
        containers = ("experts", "block_sparse_moe")

    targets: list[torch.nn.Parameter] = []
    fused_param = None

    # Phase 1: MoE experts — try fused 3D param, then iterate individual experts
    for cname in containers:
        container = getattr(mlp, cname, None)
        if container is None:
            continue
        # Check fused 3D parameter (e.g. experts.gate_up_proj or experts.down_proj)
        fp = getattr(container, fused_attr, None)
        if isinstance(fp, torch.nn.Parameter) and fp.ndim == 3:
            fused_param = fp
            break
        # Iterate individual experts
        try:
            for ex in container:
                for leaves in leaf_groups:
                    for leaf in leaves:
                        mod = getattr(ex, leaf, None)
                        if mod is not None and hasattr(mod, "weight"):
                            targets.append(mod.weight)
                            break
        except TypeError:
            pass
        break

    # Phase 2: Dense MLP fallback
    if not targets and fused_param is None:
        for attr in dense_attrs:
            mod = getattr(mlp, attr, None)
            if mod is not None and hasattr(mod, "weight"):
                targets.append(mod.weight)

    # Phase 3: shared_expert
    shared = getattr(mlp, "shared_expert", None)
    if shared:
        for attr in dense_attrs:
            mod = getattr(shared, attr, None)
            if mod is not None and hasattr(mod, "weight"):
                targets.append(mod.weight)

    return targets, fused_param


def _bake_hook_weights(targets, fused_param, v, scale, is_rank_k, ds, li,
                       hook_type="output", expert_scales=None):
    """Bake ablation hook into weights.

    output (post-hook on down_proj): W -= s * v ⊗ (v^T W)   — v contracts left
    input  (pre-hook on gate/up):    W -= s * (W v) ⊗ v^T   — v contracts right

    expert_scales: optional (n_experts,) tensor for per-expert ablation strength.
                   Default None = uniform (all 1.0).
    """
    # (proj_subscript, outer_subscript, v_first_in_outer) keyed by (hook_type, mode)
    #   mode "a": hidden_dim on axis 1,  mode "b": hidden_dim on axis 2
    _EINSUMS = {
        ("output", "a"): ('nhi,h->ni', 'h,ni->nhi', True),    # row-mode down_proj
        ("output", "b"): ('nih,h->ni', 'ni,h->nih', False),   # col-mode down_proj
        ("input",  "b"): ('noh,h->no', 'no,h->noh', False),   # col-mode gate_up
        ("input",  "a"): ('nho,h->no', 'h,no->nho', True),    # row-mode gate_up
    }

    def _apply_fused(W, v_dev, proj_ein, outer_ein, v_first):
        def args(vi, p): return (vi, p) if v_first else (p, vi)
        n_experts = W.shape[0]
        es = expert_scales.to(W.device).float() if expert_scales is not None else None
        if is_rank_k:
            for i in range(v_dev.shape[0]):
                vi = v_dev[i]
                s = scale * (ds[i] if ds is not None and i < len(ds) else 1.0)
                delta = s * torch.einsum(outer_ein, *args(vi, torch.einsum(proj_ein, W, vi)))
                if es is not None:
                    delta *= es.view(n_experts, *([1] * (delta.ndim - 1)))
                W -= delta
        else:
            delta = scale * torch.einsum(outer_ein, *args(v_dev, torch.einsum(proj_ein, W, v_dev)))
            if es is not None:
                delta *= es.view(n_experts, *([1] * (delta.ndim - 1)))
            W -= delta

    if fused_param is not None:
        dev, dt = fused_param.device, fused_param.dtype
        W = fused_param.data.float()
        v_dev = v.to(dev).float()
        hdim = v_dev.shape[-1]
        if W.shape[1] == hdim:
            mode = "a"
        elif W.shape[2] == hdim:
            mode = "b"
        else:
            label = "fused gate_up" if hook_type == "input" else "fused"
            print(f"  {WARN} Layer {li}: {label} shape {W.shape} doesn't match hidden_dim {hdim}")
            return
        proj_ein, outer_ein, v_first = _EINSUMS[(hook_type, mode)]
        _apply_fused(W, v_dev, proj_ein, outer_ein, v_first)
        fused_param.data = W.to(dt)

    for W_param in targets:
        dev, dt = W_param.device, W_param.dtype
        W = W_param.data.float()
        v_dev = v.to(dev).float()
        if is_rank_k:
            for i in range(v_dev.shape[0]):
                vi = v_dev[i]
                s = scale * (ds[i] if ds is not None and i < len(ds) else 1.0)
                if hook_type == "output":
                    W -= s * vi.unsqueeze(1) * (vi @ W).unsqueeze(0)
                else:
                    W -= s * (W @ vi).unsqueeze(1) * vi.unsqueeze(0)
        else:
            if hook_type == "output":
                W -= scale * v_dev.unsqueeze(1) * (v_dev @ W).unsqueeze(0)
            else:
                W -= scale * (W @ v_dev).unsqueeze(1) * v_dev.unsqueeze(0)
        W_param.data = W.to(dt)


_FP8_SCALE_SUFFIXES = (".weight_scale", ".weight_scale_inv", ".input_scale_ub", ".activation_scale")


def _fp8_streaming_merge(model: Model, save_dir: str) -> None:
    """Streaming GPU-side merge for FP8 models: dequant per-module, flush BF16 shards."""
    import json
    from safetensors.torch import save_file

    Path(save_dir).mkdir(parents=True, exist_ok=True)

    assert model.model is not None
    recipe = model.get_ablation_recipe()
    peft_model = model.model

    # Collect LoRA deltas: base_key -> (lora_B @ lora_A) * scaling
    lora_deltas: dict[str, torch.Tensor] = {}
    for name, mod in peft_model.named_modules():
        if not hasattr(mod, "lora_A") or not hasattr(mod, "lora_B"):
            continue
        for adapter in mod.lora_A:
            A = mod.lora_A[adapter].weight.data
            B = mod.lora_B[adapter].weight.data
            s = mod.scaling.get(adapter, 1.0)
            delta = (B @ A) * s
            # Map back to base parameter name
            base_name = name.replace("base_model.model.", "").replace(".base_layer", "")
            lora_deltas[base_name + ".weight"] = delta.to(torch.bfloat16)

    # Unwrap to base model for iteration
    base_model = peft_model.get_base_model() if hasattr(peft_model, "get_base_model") else peft_model
    inner = getattr(base_model, "model", base_model)

    shard_buf: dict[str, torch.Tensor] = {}
    shard_bytes = 0
    shard_idx = 0
    weight_map: dict[str, str] = {}
    max_shard = 5 * 1024**3  # 5GB

    def _flush_shard():
        nonlocal shard_buf, shard_bytes, shard_idx
        if not shard_buf:
            return
        shard_idx += 1
        fname = f"model-{shard_idx:05d}-of-XXXXX.safetensors"
        save_file(shard_buf, str(Path(save_dir) / fname))
        for k in shard_buf:
            weight_map[k] = fname
        shard_buf = {}
        shard_bytes = 0

    from reaper_abliteration.model import _dequant_fp8

    n_dequant = 0
    for name, param in inner.named_parameters():
        # Skip FP8 scale parameters
        if any(name.endswith(s) for s in _FP8_SCALE_SUFFIXES):
            continue

        if param.dtype == torch.float8_e4m3fn:
            # Find the parent module for scale access
            parts = name.rsplit(".", 1)
            parent = inner.get_submodule(parts[0]) if len(parts) > 1 else inner
            w = _dequant_fp8(parent, param.data).to(torch.bfloat16)
            # Apply LoRA delta if exists
            if name in lora_deltas:
                w = w + lora_deltas[name].to(w.device)
            tensor = w.cpu()
            n_dequant += 1
        else:
            tensor = param.data.cpu().to(torch.bfloat16) if param.dtype != torch.bfloat16 else param.data.cpu().clone()
            if name in lora_deltas:
                tensor = tensor + lora_deltas[name].cpu()

        shard_buf[name] = tensor
        shard_bytes += tensor.nelement() * tensor.element_size()
        if shard_bytes >= max_shard:
            _flush_shard()

    _flush_shard()

    # Bake ablation hooks into saved shards
    if recipe:
        n_baked = _bake_hooks_into_shards(save_dir, weight_map, recipe)
        print(step(f"Ablation baked into shards ({val(n_baked)} layers)  {OK}"))

    # Fix shard filenames (replace XXXXX with total count)
    total = shard_idx
    save_path = Path(save_dir)
    final_map: dict[str, str] = {}
    for old_fname in sorted(set(weight_map.values())):
        new_fname = old_fname.replace("XXXXX", f"{total:05d}")
        (save_path / old_fname).rename(save_path / new_fname)
        for k, v in weight_map.items():
            if v == old_fname:
                final_map[k] = new_fname

    # Write index
    total_bytes = sum(Path(save_path / f).stat().st_size for f in set(final_map.values()))
    index = {"metadata": {"total_size": total_bytes}, "weight_map": final_map}
    with open(save_path / "model.safetensors.index.json", "w") as f:
        json.dump(index, f, indent=2)

    # Save config (strip FP8 quantization_config so output loads as BF16)
    cfg = inner.config if hasattr(inner, "config") else base_model.config
    cfg_dict = cfg.to_dict()
    cfg_dict.pop("quantization_config", None)
    cfg_dict["torch_dtype"] = "bfloat16"
    with open(save_path / "config.json", "w") as f:
        json.dump(cfg_dict, f, indent=2)

    print(step(f"Streamed {val(n_dequant)} FP8 modules to BF16 ({val(total)} shards)  {OK}"))


def _bake_hooks_into_shards(save_dir: str, weight_map: dict[str, str], recipe: list) -> int:
    """Apply ablation recipe to already-saved BF16 shard files."""
    from safetensors.torch import load_file, save_file

    save_path = Path(save_dir)
    # Group recipe entries by layer
    modified_shards: set[str] = set()
    n_layers = 0

    def _ablate_2d(W, v_dev, scale, is_rank_k, ds, hook_type, expert_scale=1.0):
        """Apply rank-1 or rank-k ablation to a 2D weight matrix in-place."""
        if is_rank_k:
            for i in range(v_dev.shape[0]):
                vi = v_dev[i]
                s = scale * expert_scale * (ds[i] if ds is not None and i < len(ds) else 1.0)
                if hook_type == "output":
                    W -= s * vi.unsqueeze(1) * (vi @ W).unsqueeze(0)
                else:
                    W -= s * (W @ vi).unsqueeze(1) * vi.unsqueeze(0)
        else:
            s = scale * expert_scale
            if hook_type == "output":
                W -= s * v_dev.unsqueeze(1) * (v_dev @ W).unsqueeze(0)
            else:
                W -= s * (W @ v_dev).unsqueeze(1) * v_dev.unsqueeze(0)

    def _ablate_fused_3d(W, v_dev, scale, is_rank_k, ds, hook_type, expert_scales_t):
        """Apply ablation to a fused 3D expert tensor (n_experts, ...) in-place."""
        # Match _bake_hook_weights einsum logic
        _EINSUMS = {
            ("output", "a"): ('nhi,h->ni', 'h,ni->nhi', True),
            ("output", "b"): ('nih,h->ni', 'ni,h->nih', False),
            ("input",  "b"): ('noh,h->no', 'no,h->noh', False),
            ("input",  "a"): ('nho,h->no', 'h,no->nho', True),
        }
        hdim = v_dev.shape[-1]
        if W.shape[1] == hdim:
            mode = "a"
        elif W.shape[2] == hdim:
            mode = "b"
        else:
            return
        proj_ein, outer_ein, v_first = _EINSUMS[(hook_type, mode)]
        def args(vi, p): return (vi, p) if v_first else (p, vi)
        es = expert_scales_t.to(W.device).float() if expert_scales_t is not None else None
        if is_rank_k:
            for i in range(v_dev.shape[0]):
                vi = v_dev[i]
                s = scale * (ds[i] if ds is not None and i < len(ds) else 1.0)
                delta = s * torch.einsum(outer_ein, *args(vi, torch.einsum(proj_ein, W, vi)))
                if es is not None:
                    delta *= es.view(W.shape[0], *([1] * (delta.ndim - 1)))
                W -= delta
        else:
            delta = scale * torch.einsum(outer_ein, *args(v_dev, torch.einsum(proj_ein, W, v_dev)))
            if es is not None:
                delta *= es.view(W.shape[0], *([1] * (delta.ndim - 1)))
            W -= delta

    for hook in recipe:
        li = hook["layer_idx"]
        hook_type = hook.get("hook_type", "output")
        v = hook["direction"]
        scale = hook["scale"]
        is_rank_k = hook["is_rank_k"]
        ds = hook.get("direction_scales")
        es_raw = hook.get("expert_scales")
        es = torch.tensor(es_raw, dtype=torch.float32) if es_raw is not None else None

        # Find weight keys for this layer (dense MLP + MoE shared_expert)
        if hook_type == "output":
            suffixes = [f"layers.{li}.mlp.down_proj.weight", f"layers.{li}.mlp.shared_expert.down_proj.weight"]
        else:
            suffixes = [
                f"layers.{li}.mlp.gate_proj.weight", f"layers.{li}.mlp.up_proj.weight",
                f"layers.{li}.mlp.shared_expert.gate_proj.weight", f"layers.{li}.mlp.shared_expert.up_proj.weight",
            ]
        # Also try with language_model / model prefix
        candidates = suffixes + [f"language_model.model.{s}" for s in suffixes] + [f"model.{s}" for s in suffixes]

        # Scan weight_map for MoE expert keys matching this layer
        if hook_type == "output":
            expert_leaves = ("down_proj.weight", "w2.weight")
            fused_attr = "down_proj"
        else:
            expert_leaves = ("gate_proj.weight", "up_proj.weight", "w1.weight", "w3.weight")
            fused_attr = "gate_up_proj"
        layer_prefix = f"layers.{li}.mlp."
        expert_keys: list[tuple[str, int | None]] = []  # (wkey, expert_idx or None for fused)
        fused_keys: list[str] = []
        for wkey in weight_map:
            # Strip model/language_model prefix to get the bare suffix
            bare = wkey
            for pfx in ("language_model.model.", "model."):
                if bare.startswith(pfx):
                    bare = bare[len(pfx):]
                    break
            if not bare.startswith(layer_prefix):
                continue
            rest = bare[len(layer_prefix):]
            # Fused 3D: experts.down_proj or experts.gate_up_proj (no .weight suffix)
            for cname in ("experts", "block_sparse_moe"):
                if rest == f"{cname}.{fused_attr}":
                    fused_keys.append(wkey)
                    break
                # Individual experts: experts.{N}.down_proj.weight etc.
                if rest.startswith(f"{cname}."):
                    tail = rest[len(cname) + 1:]  # e.g. "0.down_proj.weight"
                    parts = tail.split(".", 1)
                    if len(parts) == 2 and parts[0].isdigit() and parts[1] in expert_leaves:
                        expert_keys.append((wkey, int(parts[0])))
                        break

        applied = False
        v_dev = None

        # Apply to dense/shared_expert 2D weights
        for wkey in candidates:
            shard_file = weight_map.get(wkey)
            if shard_file is None:
                continue
            shard_path = save_path / shard_file
            tensors = load_file(str(shard_path))
            W = tensors[wkey].float()
            if v_dev is None:
                v_dev = v.to(W.device).float()
            _ablate_2d(W, v_dev, scale, is_rank_k, ds, hook_type)
            tensors[wkey] = W.to(torch.bfloat16)
            save_file(tensors, str(shard_path))
            modified_shards.add(shard_file)
            applied = True

        # Apply to individual MoE expert 2D weights (with per-expert scaling)
        for wkey, eidx in expert_keys:
            shard_file = weight_map[wkey]
            shard_path = save_path / shard_file
            tensors = load_file(str(shard_path))
            W = tensors[wkey].float()
            if v_dev is None:
                v_dev = v.to(W.device).float()
            e_scale = float(es[eidx]) if es is not None and eidx < len(es) else 1.0
            _ablate_2d(W, v_dev, scale, is_rank_k, ds, hook_type, expert_scale=e_scale)
            tensors[wkey] = W.to(torch.bfloat16)
            save_file(tensors, str(shard_path))
            modified_shards.add(shard_file)
            applied = True

        # Apply to fused 3D expert tensors (with per-expert scaling via einsum)
        for wkey in fused_keys:
            shard_file = weight_map[wkey]
            shard_path = save_path / shard_file
            tensors = load_file(str(shard_path))
            W = tensors[wkey].float()
            if v_dev is None:
                v_dev = v.to(W.device).float()
            _ablate_fused_3d(W, v_dev, scale, is_rank_k, ds, hook_type, es)
            tensors[wkey] = W.to(torch.bfloat16)
            save_file(tensors, str(shard_path))
            modified_shards.add(shard_file)
            applied = True

        if applied:
            n_layers += 1

    return n_layers


def _mxfp4_dequant_merge(model: Model, save_dir: str) -> None:
    """Reload model as BF16 via MXFP4 dequantize, bake ablation into weights, save."""
    from peft import LoraConfig, get_peft_model

    model_id = model.settings.model
    recipe = model.get_ablation_recipe()
    trust = model._trust_flags.get(model_id)

    # Save LoRA adapter state from current model
    assert model.model is not None
    lora_state = {
        n: p.data.clone().cpu()
        for n, p in model.model.named_parameters()
        if "lora_" in n
    }
    has_lora = any(v.abs().max() > 0 for v in lora_state.values())

    # Extract metadata before freeing original model
    comps = [c for c in model.ablation_targets() if c != "mlp"] if has_lora else []
    rank = model.settings.ablation_rank if has_lora else 1

    # Free original model before loading dequantized copy to avoid OOM
    model.model = None
    empty_cache()

    # Load fresh copy with dequantize=True
    print(
        step(
            "Loading model with dequantize=True", "this takes a while for large models"
        )
    )
    try:
        from transformers import Mxfp4Config
    except ImportError:
        from transformers.utils.quantization_config import Mxfp4Config

    fresh = AutoModelForCausalLM.from_pretrained(
        model_id,
        quantization_config=Mxfp4Config(dequantize=True),
        device_map="auto",
        torch_dtype=torch.bfloat16,
        trust_remote_code=trust,
    )
    print(step(f"Dequantized model loaded  {OK}"))

    # Merge LoRA adapters if present
    if has_lora:
        fresh = get_peft_model(
            fresh,
            LoraConfig(
                r=rank,
                target_modules=comps,
                lora_alpha=rank,
                lora_dropout=0,
                bias="none",
                task_type="CAUSAL_LM",
            ),
        )
        for n, p in fresh.named_parameters():
            if n in lora_state:
                p.data = lora_state[n].to(p.device, dtype=p.dtype)
        print(step("Merging LoRA adapters"))
        fresh = fresh.merge_and_unload()
        print(step(f"LoRA merged  {OK}"))

    # Bake ablation hooks into down_proj weights (includes fused experts via 3D path)
    if recipe:
        inner = fresh.model
        n = _apply_ablation_to_weights(getattr(inner, "language_model", inner).layers, recipe)
        print(step(f"Ablation baked into weights ({val(n)} layers)  {OK}"))

    print(step(f"Saving BF16 model to {val(save_dir)}"))
    fresh.save_pretrained(save_dir, max_shard_size="5GB")
    del fresh
    empty_cache()


_GGUF_QUANT_TYPES = ["Q4_K_M", "Q5_K_M", "Q8_0", "F16", "BF16"]


def _find_llama_cpp_dir() -> Path | None:
    """Locate the llama.cpp directory. Returns None if not found."""
    # Check if convert script is in PATH
    found = shutil.which("convert_hf_to_gguf.py") or shutil.which("convert-hf-to-gguf")
    if found:
        return Path(found).parent
    for candidate in [Path.home() / "llama.cpp", Path("/opt/llama.cpp")]:
        if (candidate / "convert_hf_to_gguf.py").exists():
            return candidate
    path = prompt_path("Path to llama.cpp directory (contains convert_hf_to_gguf.py):")
    if path and Path(path).exists():
        return Path(path)
    return None


def _find_convert_script() -> str | None:
    """Locate convert_hf_to_gguf.py — check PATH, then ask user."""
    d = _find_llama_cpp_dir()
    if d is None:
        return None
    script = d / "convert_hf_to_gguf.py"
    return str(script) if script.exists() else None


def _convert_to_gguf(hf_dir: str, output_path: str, quant_type: str) -> bool:
    """Convert HF model dir to GGUF. Returns True on success."""
    script = _find_convert_script()
    if not script:
        print(f"  {FAIL} convert_hf_to_gguf.py not found. Install llama.cpp: git clone https://github.com/ggml-org/llama.cpp")
        return False

    # F16/BF16 can be done directly; others need quantize step
    direct_types = {"F16": "f16", "BF16": "bf16"}
    if quant_type in direct_types:
        cmd = [
            sys.executable,
            script,
            hf_dir,
            "--outtype",
            direct_types[quant_type],
            "--outfile",
            output_path,
        ]
        print(step(f"Converting to GGUF {val(quant_type)}"))
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode != 0:
            print(f"  {FAIL} Conversion failed:\n{r.stderr[-500:]}")
            return False
        print(step(f"GGUF saved to {val(output_path)}  {OK}"))
        return True

    # Two-step: convert to f16, then quantize
    f16_path = output_path.rsplit(".", 1)[0] + "-f16.gguf"
    cmd = [sys.executable, script, hf_dir, "--outtype", "f16", "--outfile", f16_path]
    print(step("Converting to GGUF F16 intermediate"))
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        print(f"  {FAIL} Conversion failed:\n{r.stderr[-500:]}")
        return False

    quantize_bin = shutil.which("llama-quantize")
    if not quantize_bin:
        # Try next to the convert script
        candidate = Path(script).parent / "build" / "bin" / "llama-quantize"
        if candidate.exists():
            quantize_bin = str(candidate)
    if not quantize_bin:
        print(
            f"  {WARN} llama-quantize not found in PATH — F16 GGUF saved at {val(f16_path)}"
        )
        print(
            f"    {dim('Run manually: llama-quantize ' + f16_path + ' ' + output_path + ' ' + quant_type)}"
        )
        return True

    print(step(f"Quantizing to {val(quant_type)}"))
    r = subprocess.run(
        [quantize_bin, f16_path, output_path, quant_type],
        capture_output=True,
        text=True,
    )
    if r.returncode != 0:
        print(f"  {FAIL} Quantization failed:\n{r.stderr[-500:]}")
        return False

    Path(f16_path).unlink(missing_ok=True)
    print(step(f"GGUF saved to {val(output_path)}  {OK}"))
    return True


def _find_lora_convert_script() -> str | None:
    """Locate convert_lora_to_gguf.py from llama.cpp."""
    d = _find_llama_cpp_dir()
    if d is None:
        return None
    script = d / "convert_lora_to_gguf.py"
    return str(script) if script.exists() else None


def _convert_lora_to_gguf(adapter_dir: str, output_path: str, base_model_id: str) -> bool:
    """Convert a HF PEFT adapter directory to GGUF LoRA format. Returns True on success."""
    script = _find_lora_convert_script()
    if not script:
        print(f"  {WARN} convert_lora_to_gguf.py not found — adapter saved as HF format only")
        print(f"    {dim('Convert manually: python convert_lora_to_gguf.py --base-model-id ' + base_model_id + ' ' + adapter_dir)}")
        return False

    cmd = [
        sys.executable, script,
        adapter_dir,
        "--outfile", output_path,
        "--outtype", "bf16",
        "--base-model-id", base_model_id,
    ]
    print(step("Converting LoRA adapter to GGUF"))
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        print(f"  {FAIL} LoRA conversion failed:\n{r.stderr[-500:]}")
        return False
    print(step(f"LoRA GGUF saved to {val(output_path)}  {OK}"))
    return True


def _build_ablation_adapter(
    model: "Model", adapter_dir: str, base_model: "torch.nn.Module | None" = None,
) -> None:
    """Build a unified PEFT-format adapter from LoRA weights + hook-based ablation.

    The adapter covers:
    1. Existing LoRA A/B on attention/shared_expert (from PEFT model)
    2. Synthesized LoRA A/B from MLP output/input hooks (fused expert layers)

    For hooks, the equivalent LoRA on the fused expert 3D tensor is:
      output hook (down_proj): A = v^T @ W  [k, inter, n_exp], B = -s*v  [hidden, k, n_exp]
      input hook (gate_up):    A = v^T       [k, hidden, n_exp], B = -s*Wv [inter*2, k, n_exp]
    where k=rank (1 for rank-1, k for rank-k).
    """
    import json
    from safetensors.torch import save_file

    assert model.model is not None
    out = Path(adapter_dir)
    out.mkdir(parents=True, exist_ok=True)

    rank = model.settings.ablation_rank
    tensors: dict[str, torch.Tensor] = {}

    # 1) Collect existing PEFT LoRA weights (attention projections, shared_expert, etc.)
    for name, param in model.model.named_parameters():
        if "lora_" in name:
            # Strip PEFT wrapper prefix: base_model.model.xxx → model.xxx
            clean = name.replace("base_model.model.", "", 1)
            tensors[clean] = param.data.clone().cpu()

    # 2) Synthesize LoRA for hook-based ablation on fused expert weights
    recipe = model.get_ablation_recipe()
    if recipe and base_model is not None:
        layers = base_model.model.layers
        for entry in recipe:
            li = entry["layer_idx"]
            v = entry["direction"].float()      # (hidden,) or (k, hidden)
            scale = entry["scale"]
            is_rank_k = entry["is_rank_k"]
            ds = entry["direction_scales"]
            hook_type = entry.get("hook_type", "output")
            r = v.shape[0] if is_rank_k else 1
            if not is_rank_k:
                v = v.unsqueeze(0)  # (1, hidden)
            else:
                orth_err = (v @ v.T - torch.eye(v.shape[0], device=v.device)).abs().max()
                assert orth_err < 1e-4, f"rank-k directions not orthogonal (err={orth_err:.2e})"

            layer = layers[li]
            mlp = layer.mlp
            experts = getattr(mlp, "experts", None)
            if experts is None:
                continue

            def _synth_lora(
                W: "torch.Tensor", ein: str, *, swap: bool = False,
            ) -> tuple["torch.Tensor", "torch.Tensor"]:
                """Build (lora_A, lora_B) from weight W and direction v.

                ein: einsum subscript for the W·v contraction (e.g. "nhi,rh->nri")
                swap: if True, contraction goes to A and broadcast v to B (row-mode output)
                """
                C = torch.einsum(ein, W, v.to(W.device))  # contraction
                ds_t = torch.tensor(ds[:r], dtype=v.dtype) if is_rank_k and ds is not None else None
                if swap:
                    # A = contraction, B = -s * v^T (broadcast)
                    B = -scale * v.T  # [hidden, r]
                    if ds_t is not None:
                        B = B * ds_t.unsqueeze(0)
                    return C, B.unsqueeze(0).repeat(W.shape[0], 1, 1)
                # A = broadcast v, B = -s * contraction
                bcast = v.unsqueeze(0).repeat(W.shape[0], 1, 1)  # [n_exp, r, hidden]
                if ds_t is not None:
                    C = C * ds_t.unsqueeze(0).unsqueeze(0)
                return bcast, -scale * C

            if hook_type == "output":
                dp = getattr(experts, "down_proj", None)
                if dp is None or not isinstance(dp, torch.nn.Parameter):
                    continue
                W = dp.data.float()
                hdim = v.shape[-1]
                if W.shape[1] == hdim:
                    lora_A, lora_B = _synth_lora(W, "nhi,rh->nri", swap=True)
                else:
                    lora_A, lora_B = _synth_lora(W, "nih,rh->nir")
                prefix = f"model.layers.{li}.mlp.experts.down_proj"

            elif hook_type == "input":
                gup = getattr(experts, "gate_up_proj", None)
                if gup is None or not isinstance(gup, torch.nn.Parameter):
                    continue
                W = gup.data.float()
                hdim = v.shape[-1]
                if W.shape[2] == hdim:
                    lora_A, lora_B = _synth_lora(W, "noh,rh->nor")
                else:
                    lora_A, lora_B = _synth_lora(W, "nho,rh->nor")
                prefix = f"model.layers.{li}.mlp.experts.gate_up_proj"
            else:
                continue

            tensors[f"{prefix}.lora_A.weight"] = lora_A.cpu().to(torch.bfloat16)
            tensors[f"{prefix}.lora_B.weight"] = lora_B.cpu().to(torch.bfloat16)

    if not tensors:
        print(f"  {WARN} No ablation weights to export as adapter")
        return

    save_file(tensors, str(out / "adapter_model.safetensors"))

    # Write adapter_config.json — PEFT format expected by convert_lora_to_gguf.py
    # Collect all target module names from tensor keys
    target_modules = sorted({
        k.replace(".lora_A.weight", "").replace(".lora_B.weight", "").split(".")[-1]
        for k in tensors
    })
    config = {
        "peft_type": "LORA",
        "base_model_name_or_path": model.settings.model,
        "r": rank,
        "lora_alpha": rank,
        "lora_dropout": 0.0,
        "target_modules": target_modules,
        "bias": "none",
        "task_type": "CAUSAL_LM",
    }
    (out / "adapter_config.json").write_text(json.dumps(config, indent=2))

    n_lora = sum(1 for k in tensors if "lora_A" in k)
    n_hook = sum(1 for k in tensors if "experts" in k and "lora_A" in k)
    print(step(f"Adapter saved: {val(n_lora)} targets ({n_hook} from hooks)  {OK}"))


def _gguf_with_lora_export(
    model: "Model", save_directory: str, settings: Settings
) -> None:
    """Export base model as GGUF + ablation as separate LoRA GGUF adapter.

    This preserves ablation at full precision regardless of base model quantization.
    The LoRA adapter is applied at inference time in float math, so the ablation
    signal is not degraded by GGUF quantization.
    """
    import tempfile

    quant = prompt_select(
        "GGUF quantization type:", [Choice(t, value=t) for t in _GGUF_QUANT_TYPES]
    )
    if not quant:
        print(f"  {WARN} Cancelled")
        return

    model_name = Path(settings.model).name
    Path(save_directory).mkdir(parents=True, exist_ok=True)

    has_hooks = _has_hooks(model)

    with tempfile.TemporaryDirectory() as tmp:
        adapter_dir = str(Path(tmp) / "adapter")
        hf_dir = str(Path(tmp) / "hf")
        Path(hf_dir).mkdir()

        if _is_fp8(settings):
            # FP8: streaming merge to hf_dir (no CPU reload needed)
            _fp8_streaming_merge(model, hf_dir)
            # Build adapter for GGUF LoRA conversion
            _build_ablation_adapter(model, adapter_dir, base_model=None)
        else:
            # Reload clean base model on CPU (no LoRA, no hooks, no quantization)
            print(step("Loading base model on CPU for GGUF conversion"))
            trust = model._trust_flags.get(settings.model)
            base = AutoModelForCausalLM.from_pretrained(
                settings.model,
                torch_dtype=torch.bfloat16,
                device_map="cpu",
                trust_remote_code=trust,
            )
            # Build adapter from current LoRA weights + synthesized hook LoRA
            _build_ablation_adapter(model, adapter_dir, base_model=base if has_hooks else None)
            print(step(f"Saving base model to {val(hf_dir)}"))
            base.save_pretrained(hf_dir)
            del base
            empty_cache()

        if _needs_lm_prefix_strip(hf_dir):
            _strip_lm_prefix_on_disk(hf_dir)
        model.tokenizer.save_pretrained(hf_dir)
        _patch_text_only_config(settings.model, hf_dir)

        # Convert base model to GGUF
        gguf_path = str(Path(save_directory) / f"{model_name}-{quant}.gguf")
        _convert_to_gguf(hf_dir, gguf_path, quant)

        # Convert LoRA adapter to GGUF
        lora_gguf = str(Path(save_directory) / f"{model_name}-ablation-lora.gguf")
        _convert_lora_to_gguf(adapter_dir, lora_gguf, settings.model)

        # Copy HF adapter as fallback
        adapter_out = Path(save_directory) / "ablation-adapter"
        if not adapter_out.exists():
            shutil.copytree(adapter_dir, str(adapter_out))

    print()
    print(step("Usage with llama.cpp:"))
    gguf_name = Path(gguf_path).name
    lora_name = Path(lora_gguf).name
    print(f"    {dim(f'llama-server -m {gguf_name} --lora {lora_name}')}")
    print(f"    {dim(f'llama-cli -m {gguf_name} --lora {lora_name}')}")


def _gguf_export(
    model: "Model | ParallelModel", save_directory: str, settings: Settings
) -> None:
    """Merge model into temp HF dir, convert to GGUF, save to save_directory."""
    import tempfile

    quant = prompt_select(
        "GGUF quantization type:", [Choice(t, value=t) for t in _GGUF_QUANT_TYPES]
    )
    if not quant:
        print(f"  {WARN} Cancelled")
        return

    has_hooks = _has_hooks(model)
    model_name = Path(settings.model).name

    with tempfile.TemporaryDirectory() as tmp:
        hf_dir = str(Path(tmp) / "hf")
        Path(hf_dir).mkdir()

        if _is_fp8(settings):
            _fp8_streaming_merge(model, hf_dir)
        else:
            merged = model.get_merged_model()
            if has_hooks:
                _bake_hooks_into_merged(model, merged)
            merged.save_pretrained(hf_dir)
            del merged
            empty_cache()
            if _needs_lm_prefix_strip(hf_dir):
                _strip_lm_prefix_on_disk(hf_dir)

        model.tokenizer.save_pretrained(hf_dir)
        # Skip _restore_multimodal_files / _restore_vision_weights — GGUF is text-only
        # But patch critical config fields that text-only submodel strips
        _patch_text_only_config(settings.model, hf_dir)

        out_file = str(Path(save_directory) / f"{model_name}-{quant}.gguf")
        Path(save_directory).mkdir(parents=True, exist_ok=True)
        _convert_to_gguf(hf_dir, out_file, quant)


def save_model(
    model: Model | ParallelModel,
    save_directory: str,
    settings: Settings,
    strategy: str | None = None,
) -> None:
    print(phase("save"))
    has_hooks = _has_hooks(model)
    if strategy is None:
        strategy = obtain_merge_strategy(settings, has_hooks=has_hooks)
        if strategy is None:
            print(f"  {WARN} Cancelled")
            return

    if strategy == "gguf":
        _gguf_export(model, save_directory, settings)
        return
    elif strategy == "gguf_lora":
        _gguf_with_lora_export(model, save_directory, settings)
        return
    elif strategy == "fp8_streaming":
        _fp8_streaming_merge(model, save_directory)
        empty_cache()
    elif strategy == "mxfp4_dequant":
        _mxfp4_dequant_merge(model, save_directory)
        empty_cache()
    elif strategy == "adapter":
        assert model.model is not None
        model.model.save_pretrained(save_directory)
    else:
        merged_model = model.get_merged_model()
        _bake_hooks_into_merged(model, merged_model)
        merged_model.save_pretrained(save_directory, max_shard_size="5GB")
        del merged_model
        empty_cache()
        if _needs_lm_prefix_strip(save_directory):
            _strip_lm_prefix_on_disk(save_directory)

    model.tokenizer.save_pretrained(save_directory)

    # Patch critical config fields stripped by text-only submodel, then restore multimodal
    _patch_text_only_config(settings.model, save_directory)
    _restore_multimodal_files(settings.model, save_directory, settings.trust_remote_code)
    _restore_vision_weights(settings.model, save_directory)

    # Save ablation recipe sidecar for non-dequant strategies with hooks
    if hasattr(model, 'get_ablation_recipe') and strategy != "mxfp4_dequant":
        _save_ablation_recipe(model, save_directory)

    print(step(f"Saved to {val(save_directory)}  {OK}"))


def upload_model(
    model: Model | ParallelModel,
    settings: Settings,
    trial,
    base_refusals: int,
    harmful_prompts: list[Prompt],
) -> None:
    # Avoid persisting tokens on shared/rented machines.
    token = huggingface_hub.get_token()
    if not token:
        token = prompt_password("Hugging Face access token:")
    if not token:
        return

    user = huggingface_hub.whoami(token)
    fullname = user.get(
        "fullname",
        user.get("name", "unknown user"),
    )
    email = user.get("email", "no email found")
    print(step(f"Logged in as {val(fullname)}", email))

    repo_id = prompt_text(
        "Name of repository:",
        default=f"{user['name']}/{Path(settings.model).name}-abliterated",
    )
    if not repo_id:
        return

    visibility = prompt_select(
        "Should the repository be public or private?",
        [
            "Public",
            "Private",
        ],
    )
    if not visibility:
        return
    private = visibility == "Private"

    has_hooks = _has_hooks(model)
    strategy = obtain_merge_strategy(settings, has_hooks=has_hooks)
    if strategy is None:
        print(f"  {WARN} Cancelled")
        return

    if strategy in ("gguf", "gguf_lora"):
        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            if strategy == "gguf_lora":
                _gguf_with_lora_export(model, tmp, settings)
            else:
                _gguf_export(model, tmp, settings)
            gguf_files = list(Path(tmp).glob("*.gguf"))
            adapter_dir = Path(tmp) / "ablation-adapter"
            if not gguf_files and not adapter_dir.exists():
                print(f"  {FAIL} No GGUF file produced, skipping upload")
                return
            from huggingface_hub import HfApi

            api = HfApi()
            api.create_repo(repo_id, private=private, token=token, exist_ok=True)
            for gf in gguf_files:
                print(f"  {WORK} Uploading {val(gf.name)} to {val(repo_id)}")
                api.upload_file(
                    path_or_fileobj=str(gf),
                    path_in_repo=gf.name,
                    repo_id=repo_id,
                    token=token,
                )
            if adapter_dir.exists():
                print(f"  {WORK} Uploading HF adapter to {val(repo_id)}")
                api.upload_folder(
                    folder_path=str(adapter_dir),
                    path_in_repo="ablation-adapter",
                    repo_id=repo_id,
                    repo_type="model",
                    token=token,
                )
    elif strategy == "mxfp4_dequant":
        # Dequant merge to temp dir, then upload
        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            _mxfp4_dequant_merge(model, tmp)
            model.tokenizer.save_pretrained(tmp)
            _restore_multimodal_files(settings.model, tmp)
            _restore_vision_weights(settings.model, tmp)
            print(f"  {WORK} Uploading dequant-merged BF16 model")
            from huggingface_hub import HfApi

            api = HfApi()
            api.create_repo(repo_id, private=private, token=token, exist_ok=True)
            api.upload_folder(
                folder_path=tmp,
                repo_id=repo_id,
                repo_type="model",
                token=token,
                create_pr=False,
            )
    elif strategy == "fp8_streaming":
        import tempfile

        with tempfile.TemporaryDirectory() as tmp:
            _fp8_streaming_merge(model, tmp)
            model.tokenizer.save_pretrained(tmp)
            _restore_multimodal_files(settings.model, tmp)
            _restore_vision_weights(settings.model, tmp)
            print(f"  {WORK} Uploading dequant-merged BF16 model")
            from huggingface_hub import HfApi

            api = HfApi()
            api.create_repo(repo_id, private=private, token=token, exist_ok=True)
            api.upload_folder(
                folder_path=tmp,
                repo_id=repo_id,
                repo_type="model",
                token=token,
                create_pr=False,
            )
    elif strategy == "adapter":
        print(f"  {WORK} Uploading LoRA adapter")
        assert model.model is not None
        model.model.push_to_hub(
            repo_id,  # ty:ignore[invalid-argument-type]
            private=private,
            token=token,
        )
    else:
        print(f"  {WORK} Uploading merged model")
        merged_model = model.get_merged_model()
        _bake_hooks_into_merged(model, merged_model)
        merged_model.push_to_hub(
            repo_id,  # ty:ignore[invalid-argument-type]
            private=private,
            token=token,
        )
        del merged_model
        empty_cache()

    if strategy not in ("mxfp4_dequant", "gguf"):
        model.tokenizer.push_to_hub(
            repo_id,
            private=private,
            token=token,
        )

    # Upload multimodal files (vision configs, architecture patch, vision weights)
    _push_multimodal_files(settings.model, repo_id, token)
    _push_vision_weights(settings.model, repo_id, token)

    # If the model path doesn't exist locally, it can be assumed
    # to be a model hosted on the Hugging Face Hub, in which case
    # we can retrieve the model card.
    if not Path(settings.model).exists():
        card = ModelCard.load(settings.model)
        card.data = card.data or ModelCardData()
        card.data.tags = [
            *(card.data.tags or []),
            "reaper-abliteration",
            "uncensored",
            "abliterated",
        ]
        card.text = (
            get_readme_intro(settings, trial, base_refusals, harmful_prompts)
            + card.text
        )
        card.push_to_hub(repo_id, token=token)

    print(step(f"Uploaded to {val(repo_id)}  {OK}"))
